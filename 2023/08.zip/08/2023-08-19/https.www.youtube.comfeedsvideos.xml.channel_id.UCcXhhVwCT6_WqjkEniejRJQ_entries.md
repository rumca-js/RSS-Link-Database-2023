# Source:Wintergatan, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ, language:en-US

## Faster Flywheel Plays Tighter Music
 - [https://www.youtube.com/watch?v=9X2J8JN9g-k](https://www.youtube.com/watch?v=9X2J8JN9g-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcXhhVwCT6_WqjkEniejRJQ
 - date published: 2023-08-19T15:08:16+00:00

As expected.

Follow the Trainerds adventure: https://www.youtube.com/@Trainerds

The prototype is designed to answer the age old question: Can I play tight music using a very strong flywheel? The new flywheel have 20x more moment of inertia compared to the MMX Flywheel.

We are recording at the wonderful location of Siegfrieds Mechanical Music Museum in Rudesheim Am Rhein, Germany. Check out their youtube channel: https://www.youtube.com/@Musikkabinett

Edited By the Glorious Hannes Knutsson From the @Trainerds Youtube Channel
Trainerds: https://www.youtube.com/@Trainerds

—
MUSIC DOWNLOADS ► https://wintergatan.bandcamp.com 
WINTERGATAN RECORDS ► http://www.wintergatan.net/#/shop
SPOTIFY ► http://bit.ly/2oKxXWd 
ITUNES ► http://apple.co/2ntWNsZ 
MERCH ► https://teespring.com/stores/wintergatan
DISCORD ► https://discord.gg/wintergatan
SECOND OFFICIAL CHANNEL:► https://www.youtube.com/c/Wintergatan2021
—

