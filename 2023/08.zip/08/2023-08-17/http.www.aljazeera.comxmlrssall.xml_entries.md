# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## ‘Meaningful work’: Volunteers clean Ho Chi Minh City’s fetid canals by hand
 - [https://www.aljazeera.com/news/2023/8/17/meaningful-work-volunteers-clean-ho-chi-minh-citys-fetid-canals-by-hand](https://www.aljazeera.com/news/2023/8/17/meaningful-work-volunteers-clean-ho-chi-minh-citys-fetid-canals-by-hand)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T23:23:31+00:00

Vietnam&#039;s largest city is plagued by rubbish but eager young volunteers are doing their bit to clean up the environment.

## Ecuador presidential candidates make final push to woo voters
 - [https://www.aljazeera.com/news/2023/8/17/ecuador-presidential-candidates-make-final-push-to-woo-voters](https://www.aljazeera.com/news/2023/8/17/ecuador-presidential-candidates-make-final-push-to-woo-voters)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T22:14:36+00:00

Ahead of vote on Sunday, presidential hopefuls are promising improved security in country struggling with surging crime.

## US escalates trade dispute with Mexico over genetically modified corn
 - [https://www.aljazeera.com/news/2023/8/17/us-escalates-trade-dispute-with-mexico-over-genetically-modified-corn](https://www.aljazeera.com/news/2023/8/17/us-escalates-trade-dispute-with-mexico-over-genetically-modified-corn)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T19:40:57+00:00

Washington requests settlement panel under North American trade deal in push against Mexican curbs on corn imports.

## Hurricane Hilary to dump heavy rain on Mexico, southwest US
 - [https://www.aljazeera.com/news/2023/8/17/hurricane-hilary-to-dump-heavy-rain-on-mexico-southwest-us](https://www.aljazeera.com/news/2023/8/17/hurricane-hilary-to-dump-heavy-rain-on-mexico-southwest-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T19:29:33+00:00

The hurricane is expected to strengthen rapidly as it travels through the Pacific Ocean, meteorologists warn.

## HRW, UN raise alarm over rape accusations against Sudan’s RSF
 - [https://www.aljazeera.com/news/2023/8/17/hrw-un-raise-alarm-over-rape-accusations-against-sudans-rsf](https://www.aljazeera.com/news/2023/8/17/hrw-un-raise-alarm-over-rape-accusations-against-sudans-rsf)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T19:21:07+00:00

New York-based Human Rights Watch says it documented 78 victims of rape between April 24 and June 26.

## What does Libya’s political future hold?
 - [https://www.aljazeera.com/program/inside-story/2023/8/17/what-does-libyas-political-future-hold](https://www.aljazeera.com/program/inside-story/2023/8/17/what-does-libyas-political-future-hold)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T18:31:17+00:00

Dozens of people killed in fighting between rival armed groups in Tripoli.

## Thousands flee as ‘unprecedented’ fires hit Canada’s Northwest Territories
 - [https://www.aljazeera.com/news/2023/8/17/thousands-flee-as-unprecedented-fires-hit-canadas-northwest-territories](https://www.aljazeera.com/news/2023/8/17/thousands-flee-as-unprecedented-fires-hit-canadas-northwest-territories)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T17:45:42+00:00

Officials say 20,000 residents of Yellowknife are leaving via land and air, but northern city not in &#039;immediate danger&#039;.

## After early World Cup exit, US women’s team coach Andonovski steps down
 - [https://www.aljazeera.com/sports/2023/8/17/after-early-world-cup-exit-us-womens-team-coach-andonovski-steps-down](https://www.aljazeera.com/sports/2023/8/17/after-early-world-cup-exit-us-womens-team-coach-andonovski-steps-down)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T17:35:12+00:00

The US team lost to Sweden in the World Cup&#039;s round of 16, a disappointing departure for a tournament favourite.

## Iran FM in Saudi Arabia, says relations ‘on the right track’
 - [https://www.aljazeera.com/news/2023/8/17/iran-fm-in-saudi-arabia-says-relations-on-the-right-track](https://www.aljazeera.com/news/2023/8/17/iran-fm-in-saudi-arabia-says-relations-on-the-right-track)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T17:10:51+00:00

Saudi Arabia&#039;s and Iran&#039;s foreign ministers meet as both counties seek to overcome past hostility and boost cooperation.

## UK’s Sunak, Saudi crown prince to meet ‘at the earliest opportunity’
 - [https://www.aljazeera.com/news/2023/8/17/uks-sunak-saudi-crown-prince-to-meet-at-the-earliest-opportunity](https://www.aljazeera.com/news/2023/8/17/uks-sunak-saudi-crown-prince-to-meet-at-the-earliest-opportunity)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T16:56:51+00:00

Mohammed bin Salman has not visited Britain since March 2018 before the killing of Saudi journalist Jamal Khashoggi.

## Ukraine: Ground Zero
 - [https://www.aljazeera.com/program/people-power/2023/8/17/ukraine-ground-zero](https://www.aljazeera.com/program/people-power/2023/8/17/ukraine-ground-zero)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T16:30:39+00:00

People and Power investigates the toxic legacy of war on Ukraine’s fragile environment.

## Five key issues to look out for at first US Republican debate
 - [https://www.aljazeera.com/news/2023/8/17/five-key-issues-to-look-out-for-at-first-us-republican-debate](https://www.aljazeera.com/news/2023/8/17/five-key-issues-to-look-out-for-at-first-us-republican-debate)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T16:25:34+00:00

Candidates will look to narrow former President Donald Trump&#039;s lead in race for 2024 Republican presidential nomination.

## Messi, Haaland make shortlist for UEFA’s best player award
 - [https://www.aljazeera.com/sports/2023/8/17/messi-haaland-make-shortlist-for-uefas-best-player-award](https://www.aljazeera.com/sports/2023/8/17/messi-haaland-make-shortlist-for-uefas-best-player-award)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T16:11:53+00:00

The three-man shortlist also includes Kevin De Bruyne; Pep Guardiola is favourite for the men&#039;s coaching award.

## ‘He said he’d surrender’: A family in shock after Israeli raid kills son
 - [https://www.aljazeera.com/news/2023/8/17/he-said-hed-surrender-family-in-shock-after-israeli-raid-kills-son](https://www.aljazeera.com/news/2023/8/17/he-said-hed-surrender-family-in-shock-after-israeli-raid-kills-son)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T15:52:19+00:00

Mustafa al-Kastoni, a commander of Al-Aqsa Martyrs Brigades, was killed after Israeli forces besieged his house.

## Pakistan election body to draw new boundaries as polls likely to be delayed
 - [https://www.aljazeera.com/news/2023/8/17/pakistan-election-body-to-draw-new-boundaries-as-polls-likely-to-be-delayed](https://www.aljazeera.com/news/2023/8/17/pakistan-election-body-to-draw-new-boundaries-as-polls-likely-to-be-delayed)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T15:38:00+00:00

Pakistan&#039;s Election Commission says new constituencies would be finalised by December 14, according to state TV.

## Ten killed after private jet crashes on a highway in Malaysia
 - [https://www.aljazeera.com/news/2023/8/17/ten-killed-after-private-jet-crashes-on-a-highway-in-malaysia](https://www.aljazeera.com/news/2023/8/17/ten-killed-after-private-jet-crashes-on-a-highway-in-malaysia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T15:20:34+00:00

Plane was heading from Langkawi island to Selangor&#039;s Sultan Abdul Aziz Shah Airport near Kuala Lumpur.

## Two dozen Nigerian troops die in air crash and evacuation mission gone awry
 - [https://www.aljazeera.com/news/2023/8/17/two-dozen-nigerian-troops-die-in-air-crash-as-evacuation-mission-goes-awry](https://www.aljazeera.com/news/2023/8/17/two-dozen-nigerian-troops-die-in-air-crash-as-evacuation-mission-goes-awry)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T15:01:03+00:00

A helicopter has crashed in the Nigerian state of Niger, killing more than two dozen officers, military authorities say.

## Haitian gang leader warns potential foreign force against any abuses
 - [https://www.aljazeera.com/news/2023/8/17/haitian-gang-leader-warns-potential-foreign-force-against-any-abuses](https://www.aljazeera.com/news/2023/8/17/haitian-gang-leader-warns-potential-foreign-force-against-any-abuses)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T14:59:20+00:00

Jimmy &#039;Barbecue&#039; Cherizier says Haitians will rise up against international force if human rights abuses committed.

## Hawaii’s governor promises to prevent ‘land grabs’ after Maui wildfires
 - [https://www.aljazeera.com/news/2023/8/17/hawaii-governor-promises-to-prevent-land-grabs-after-maui-wildfires](https://www.aljazeera.com/news/2023/8/17/hawaii-governor-promises-to-prevent-land-grabs-after-maui-wildfires)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:42:48+00:00

As US state assesses wide destruction, residents on Maui say they fear being pushed out in favour of wealthy visitors.

## Middle East Roundup: The Rabaa massacre remembered
 - [https://www.aljazeera.com/news/2023/8/17/middle-east-roundup-the-rabaa-massacre-remembered](https://www.aljazeera.com/news/2023/8/17/middle-east-roundup-the-rabaa-massacre-remembered)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:33:35+00:00

Ten years since the Rabaa massacre in Egypt, dozens killed in Libya- here’s the Middle East this week.

## After backlash, NATO chief says only Ukraine can decide on talks to end war
 - [https://www.aljazeera.com/news/2023/8/17/nato-chief-says-ukraine-decides-on-negotiations-following-backlash](https://www.aljazeera.com/news/2023/8/17/nato-chief-says-ukraine-decides-on-negotiations-following-backlash)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:23:18+00:00

Stoltenberg&#039;s chief of staff suggested earlier that Kyiv could give up land to Russia in return for NATO membership.

## Spain Socialists win first parliamentary battle, securing speaker role
 - [https://www.aljazeera.com/news/2023/8/17/spain-socialists-win-first-parliamentary-battle-securing-speaker-role](https://www.aljazeera.com/news/2023/8/17/spain-socialists-win-first-parliamentary-battle-securing-speaker-role)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:12:41+00:00

Francina Armengol&#039;s election augurs well for Pedro Sanchez&#039;s efforts to return as Spain&#039;s prime minister.

## ‘Captured the nation’: Australia-England match breaks broadcast records
 - [https://www.aljazeera.com/news/2023/8/17/captured-the-nation-australia-england-match-breaks-broadcast-records](https://www.aljazeera.com/news/2023/8/17/captured-the-nation-australia-england-match-breaks-broadcast-records)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:10:49+00:00

The Women&#039;s World Cup semifinal racked up 11.5 million viewers, Australian broadcaster Seven said.

## The New Greatness Case: Russian teenagers on trial
 - [https://www.aljazeera.com/program/witness/2023/8/17/the-new-greatness-case-russian-teenagers-on-trial](https://www.aljazeera.com/program/witness/2023/8/17/the-new-greatness-case-russian-teenagers-on-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T13:04:00+00:00

A Russian filmmaker follows the court case of a teenage girl who is accused of conspiring to overthrow the government.

## ‘New milestone’: Leaders of US, Japan and South Korea to meet at Camp David
 - [https://www.aljazeera.com/news/2023/8/17/new-milestone-leaders-of-us-japan-and-south-korea-to-meet-at-camp-david](https://www.aljazeera.com/news/2023/8/17/new-milestone-leaders-of-us-japan-and-south-korea-to-meet-at-camp-david)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T12:53:41+00:00

Amid Japan-South Korea detente, summit presents chance to shore up trilateral alliance to counter China and North Korea.

## Rohingya refugees fled Myanmar only to ‘live in fear’ in India
 - [https://www.aljazeera.com/news/2023/8/17/rohingya-refugees-fled-myanmar-only-to-live-in-fear-in-india](https://www.aljazeera.com/news/2023/8/17/rohingya-refugees-fled-myanmar-only-to-live-in-fear-in-india)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T12:44:18+00:00

In Nuh, the only Muslim-majority district in Haryana, Rohingya refugees live in fear of violence and detention.

## Most of West Africa ready to join standby force in Niger: ECOWAS
 - [https://www.aljazeera.com/news/2023/8/17/most-ecowas-members-ready-to-join-standby-force-in-niger-commissioner](https://www.aljazeera.com/news/2023/8/17/most-ecowas-members-ready-to-join-standby-force-in-niger-commissioner)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:59:22+00:00

ECOWAS commissioner says all member states will join the force except those under military rule and Cape Verde.

## Does artificial intelligence pose a risk to humans?
 - [https://www.aljazeera.com/program/the-bottom-line/2023/8/17/does-artificial-intelligence-pose-a-risk-to-humans](https://www.aljazeera.com/program/the-bottom-line/2023/8/17/does-artificial-intelligence-pose-a-risk-to-humans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:46:50+00:00

Jaan Tallinn, one of the co-founders of hit software like Skype and Kazaa, says AI poses an existential risk to humans.

## Liberia has suffered 20 years of ‘negative peace’. It’s time for change
 - [https://www.aljazeera.com/opinions/2023/8/17/liberia-has-suffered-20-years-of-negative-peace-its-time-for-change](https://www.aljazeera.com/opinions/2023/8/17/liberia-has-suffered-20-years-of-negative-peace-its-time-for-change)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:43:57+00:00

The root causes of Liberia&#039;s wars have remained unaddressed; the first step to changing that is rebuilding trust.

## Pakistan arrests 146 as it launches probe into church attacks
 - [https://www.aljazeera.com/news/2023/8/17/pakistan-arrests-146-as-it-launches-probe-into-church-attacks](https://www.aljazeera.com/news/2023/8/17/pakistan-arrests-146-as-it-launches-probe-into-church-attacks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:42:24+00:00

Some 6,000 police and troops deployed to control mob violence as Christian community reels in shock over attacks.

## Amid Quran burnings, Sweden raises ‘terror’ threat
 - [https://www.aljazeera.com/news/2023/8/17/amid-quran-burnings-sweden-raises-terror-threat](https://www.aljazeera.com/news/2023/8/17/amid-quran-burnings-sweden-raises-terror-threat)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:28:46+00:00

Sweden has faced international condemnation after a string of desecrations of the holy book by anti-Islam activists.

## Indian moon lander module splits from propulsion section in key step
 - [https://www.aljazeera.com/news/2023/8/17/indian-lunar-lander-splits-from-propulsion-module-in-key-step](https://www.aljazeera.com/news/2023/8/17/indian-lunar-lander-splits-from-propulsion-module-in-key-step)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:06:59+00:00

The lander module of the Chandrayaan-3 has successfully separated ahead of a planned moon landing slated for August 23.

## Ukraine’s Kuleba promises to ‘free Africa from Russia’s grip’
 - [https://www.aljazeera.com/news/2023/8/17/ukraines-kuleba-promises-to-free-africa-from-russias-grip](https://www.aljazeera.com/news/2023/8/17/ukraines-kuleba-promises-to-free-africa-from-russias-grip)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T11:00:54+00:00

Foreign minister says Kyiv intends to conduct a diplomatic &#039;counteroffensive&#039; against Russia&#039;s efforts to woo Africa.

## US approves landmark missile defence deal between Israel and Germany
 - [https://www.aljazeera.com/news/2023/8/17/us-approves-landmark-missile-defence-deal-between-israel-and-germany](https://www.aljazeera.com/news/2023/8/17/us-approves-landmark-missile-defence-deal-between-israel-and-germany)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T10:57:06+00:00

The $3.5bn deal will provide US-Israeli developed Arrow 3s, designed to shoot down targets above Earth&#039;s atmosphere.

## Heavy rain causes flight cancellations, floods in Germany
 - [https://www.aljazeera.com/news/2023/8/17/heavy-rain-causes-flight-cancellations-floods-in-germany](https://www.aljazeera.com/news/2023/8/17/heavy-rain-causes-flight-cancellations-floods-in-germany)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T10:08:09+00:00

Parts of Germany see streets deluged and trees toppled as storm leads to dozens of flight cancellations in Frankfurt.

## Armenia, Azerbaijan clash over plight of people in Nagorno-Karabakh
 - [https://www.aljazeera.com/news/2023/8/17/armenia-azerbaijan-clash-over-plight-of-people-in-nagorno-karabakh](https://www.aljazeera.com/news/2023/8/17/armenia-azerbaijan-clash-over-plight-of-people-in-nagorno-karabakh)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T10:04:40+00:00

At a UN Security Council meeting, Yerevan accuses Baku of starving the region dominated by ethnic Armenians.

## South African play revives complex stories of women in apartheid era
 - [https://www.aljazeera.com/features/2023/8/17/south-african-play-revives-complex-stories-of-women-in-apartheid-era](https://www.aljazeera.com/features/2023/8/17/south-african-play-revives-complex-stories-of-women-in-apartheid-era)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T10:01:52+00:00

Isidlamlilo is a one-woman play on untold angles of black-on-black violence in South African townships during apartheid.

## Inside Thailand’s Child Sex Tourism Trade
 - [https://www.aljazeera.com/program/101-east/2023/8/17/inside-thailands-child-sex-tourism-trade](https://www.aljazeera.com/program/101-east/2023/8/17/inside-thailands-child-sex-tourism-trade)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T09:41:11+00:00

101 East investigates Thailand’s sex tourism trade and how vulnerable children are exploited.

## Why did clashes break out in Libya’s Tripoli?
 - [https://www.aljazeera.com/news/2023/8/17/why-did-clashes-break-out-in-libyas-tripoli](https://www.aljazeera.com/news/2023/8/17/why-did-clashes-break-out-in-libyas-tripoli)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T09:25:53+00:00

Fighting between the 444 Brigade and the Special Deterrence Force has raged this week after months of relative peace.

## ‘We need power’: Zimbabweans hope for end to blackouts as election nears
 - [https://www.aljazeera.com/features/2023/8/17/we-need-power-zimbabweans-hope-for-end-to-blackouts-as-election-nears](https://www.aljazeera.com/features/2023/8/17/we-need-power-zimbabweans-hope-for-end-to-blackouts-as-election-nears)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T09:07:54+00:00

For many businesses in Zimbabwe where the economy is in free fall, electricity outages have been the norm for years.

## Taliban’s ties with Pakistan fraying amid mounting security concerns
 - [https://www.aljazeera.com/news/2023/8/17/talibans-ties-with-pakistan-fraying-amid-mounting-security-concerns](https://www.aljazeera.com/news/2023/8/17/talibans-ties-with-pakistan-fraying-amid-mounting-security-concerns)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T08:49:03+00:00

Two years since the Taliban took over Afghanistan, ties between the neighbours deteriorate amid rise in armed attacks.

## French mistakes helped create Africa’s coup belt
 - [https://www.aljazeera.com/opinions/2023/8/17/french-mistakes-helped-create-africas-coup-belt](https://www.aljazeera.com/opinions/2023/8/17/french-mistakes-helped-create-africas-coup-belt)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T08:45:31+00:00

Across the Sahel, public anger against France has helped putschists gain legitimacy and Russia expand its influence.

## Ukraine air force says no use of US-built F-16 fighter jets this year
 - [https://www.aljazeera.com/news/2023/8/17/ukraine-air-force-says-no-use-of-us-built-f-16-fighter-jets-this-year](https://www.aljazeera.com/news/2023/8/17/ukraine-air-force-says-no-use-of-us-built-f-16-fighter-jets-this-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T08:20:37+00:00

Air force spokesperson Yuriy Ihnat says F-16 warplanes will not be part of Ukraine&#039;s defence during &#039;autumn and winter&#039;.

## Pakistan’s Christian community reels from violent attacks
 - [https://www.aljazeera.com/gallery/2023/8/17/photos-pakistans-christian-community-reels-from-violent-attacks](https://www.aljazeera.com/gallery/2023/8/17/photos-pakistans-christian-community-reels-from-violent-attacks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T08:14:45+00:00

Churches and homes belonging to Christians attacked by Muslim mob in Punjab province following claims of blasphemy.

## Spain battles ‘out of control’ wildfire on Tenerife
 - [https://www.aljazeera.com/gallery/2023/8/17/photos-spain-battles-out-of-control-wildfire-on-tenerife](https://www.aljazeera.com/gallery/2023/8/17/photos-spain-battles-out-of-control-wildfire-on-tenerife)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T08:12:49+00:00

Last week, a heatwave in the Canary Islands left many areas bone dry, heightening the risk of wildfires.

## North Korea could take military action around key summit: South Korea
 - [https://www.aljazeera.com/news/2023/8/17/north-korea-could-take-military-action-around-key-summit-south-korea](https://www.aljazeera.com/news/2023/8/17/north-korea-could-take-military-action-around-key-summit-south-korea)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T07:30:43+00:00

Actions could include ICBM and spy satellite launch amid signs of activity at key launch sites.

## Will Modi’s Uniform Civil Code kill Indian ‘secularism’?
 - [https://www.aljazeera.com/features/2023/8/17/will-a-uniform-civil-code-end-indian-secularism](https://www.aljazeera.com/features/2023/8/17/will-a-uniform-civil-code-end-indian-secularism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T05:06:21+00:00

The Indian PM says common laws will help women, but many fear the proposal is an election weapon to target minorities.

## Singapore arrests 10, seizes $737m in assets in money laundering raids
 - [https://www.aljazeera.com/news/2023/8/17/singapore-arrests-10-seizes-737m-in-assets-in-money-laundering-raids](https://www.aljazeera.com/news/2023/8/17/singapore-arrests-10-seizes-737m-in-assets-in-money-laundering-raids)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T05:05:01+00:00

Police say the group is suspected of involvement in organised crime activities &#039;including scams and online gambling&#039;.

## Russian spacecraft reaches lunar orbit in preparation for moon landing
 - [https://www.aljazeera.com/news/2023/8/17/russian-spacecraft-reaches-lunar-orbit-in-preparation-for-moon-landing](https://www.aljazeera.com/news/2023/8/17/russian-spacecraft-reaches-lunar-orbit-in-preparation-for-moon-landing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T04:59:51+00:00

Russia’s Luna-25 space probe enters lunar orbit in first Russian mission to the moon in almost 50 years.

## Lithuania closes two border crossings with Belarus amid growing tensions
 - [https://www.aljazeera.com/news/2023/8/17/lithuania-closes-two-border-crossings-with-belarus-amid-growing-tensions](https://www.aljazeera.com/news/2023/8/17/lithuania-closes-two-border-crossings-with-belarus-amid-growing-tensions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T04:19:14+00:00

Lithuania temporarily shuts two of six checkpoints located on shared 680km border with Belarus over security concerns.

## China urged to tackle online racism targeting Black people
 - [https://www.aljazeera.com/news/2023/8/17/china-urged-to-tackle-online-racism-targeting-black-people](https://www.aljazeera.com/news/2023/8/17/china-urged-to-tackle-online-racism-targeting-black-people)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T03:30:37+00:00

Human Rights Watch says racist tropes &#039;common&#039; across Chinese social media, and that platforms and government must act.

## Georgia prosecutor seeks March trial for Trump in election meddling case
 - [https://www.aljazeera.com/news/2023/8/17/georgia-prosecutor-seeks-march-trial-for-trump-in-election-meddling-case](https://www.aljazeera.com/news/2023/8/17/georgia-prosecutor-seeks-march-trial-for-trump-in-election-meddling-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T03:16:47+00:00

Proposed date would have trial start a day before &#039;Super Tuesday&#039;, when over a dozen states hold Republican primaries.

## Huge wildfire forces evacuation of Canada’s Northwest Territories capital
 - [https://www.aljazeera.com/news/2023/8/17/huge-wildfire-forces-evacuation-of-canadas-northwest-territories-capital](https://www.aljazeera.com/news/2023/8/17/huge-wildfire-forces-evacuation-of-canadas-northwest-territories-capital)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T03:16:05+00:00

Residents of Northwest Territories capital, Yellowknife, told to evacuate city by noon on Friday as wildfire approaches.

## Manchester City score victory over Sevilla to win first UEFA Super Cup
 - [https://www.aljazeera.com/news/2023/8/17/manchester-city-score-victory-over-sevilla-to-win-first-uefa-super-cup](https://www.aljazeera.com/news/2023/8/17/manchester-city-score-victory-over-sevilla-to-win-first-uefa-super-cup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T02:03:59+00:00

Manchester City beat Sevilla in a 5-4 penalty shootout following game that ended in a 1-1 draw after regulation time.

## Russia-Ukraine war: List of key events, day 540
 - [https://www.aljazeera.com/news/2023/8/17/russia-ukraine-war-list-of-key-events-day-540](https://www.aljazeera.com/news/2023/8/17/russia-ukraine-war-list-of-key-events-day-540)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T01:32:06+00:00

As the war enters its 540th day, these are the main developments.

## Ukraine probes Kherson defences, advances in east and south
 - [https://www.aljazeera.com/news/2023/8/17/ukraine-probes-kherson-defences-advances-in-east-and-south](https://www.aljazeera.com/news/2023/8/17/ukraine-probes-kherson-defences-advances-in-east-and-south)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T01:20:40+00:00

Ukrainian reconnaissance land on left bank of the Dnipro, probing Russian defences and suggesting a new front may open.

## Nicaragua seizes Catholic university accused of being ‘centre of terrorism’
 - [https://www.aljazeera.com/news/2023/8/17/nicaragua-seizes-catholic-university-accused-of-being-centre-of-terrorism](https://www.aljazeera.com/news/2023/8/17/nicaragua-seizes-catholic-university-accused-of-being-centre-of-terrorism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-17T01:10:20+00:00

Critics have accused the government of President Daniel Ortega of continuing its attacks on education and religion.

