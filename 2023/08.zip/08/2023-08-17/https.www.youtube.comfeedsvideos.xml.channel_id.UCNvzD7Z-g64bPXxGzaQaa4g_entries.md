# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## Red Dead Redemption (Switch/PlayStation) - Before You Buy
 - [https://www.youtube.com/watch?v=cTCvoH0HuO4](https://www.youtube.com/watch?v=cTCvoH0HuO4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-08-17T19:38:25+00:00

The original Red Dead Redemption has been ported to PS5, PS4 and Nintendo Switch. How is it? Let's talk.
Subscribe for more: http://youtube.com/gameranxtv ▼

 

Watch more 'Before You Buy': https://bit.ly/2kfdxI6

