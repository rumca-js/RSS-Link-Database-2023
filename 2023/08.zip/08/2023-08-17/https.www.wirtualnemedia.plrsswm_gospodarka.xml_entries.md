# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Pirat telewizyjny zapłaci grzywnę. Zidentyfikowano ponad 400 klientów
 - [https://www.wirtualnemedia.pl/artykul/pirat-sad-grzywna-mandaty-iptv-listy-m3u](https://www.wirtualnemedia.pl/artykul/pirat-sad-grzywna-mandaty-iptv-listy-m3u)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T12:02:26.266083+00:00

Sąd w Getyndze skazał 33-latka na grzywnę w wysokości 10 tys. euro za dystrybucję i sprzedaż nielegalnego dostępu do platformy cyfrowej Sky Deutschland. Niemiecka prokuratura domagała się siedmiu miesięcy więzienia z warunkowym zawieszeniem wykonania kary.

## Uwaga od września ważne zmiany w przepisach dotyczących punktów karnych!
 - [https://www.wirtualnemedia.pl/artykul/uwaga-od-wrzesnia-wazne-zmiany-w-przepisach-dotyczacych-punktow-karnych](https://www.wirtualnemedia.pl/artykul/uwaga-od-wrzesnia-wazne-zmiany-w-przepisach-dotyczacych-punktow-karnych)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T07:42:21.201618+00:00

Zaledwie dwa niewłaściwe ruchy za kierownicą i już możesz stanąć w obliczu utraty prawa jazdy. Sprawdź 21 wykroczeń, za które przyznawane jest aż 15 punktów karnych. Do tego musisz pamiętać, że najcięższe przewinienia drogowe obciążone są surowymi mandatami, które w przypadku recydywy liczone są podwójnie. Choć kara może być surowa, istnieje sposób, aby nie tylko uniknąć mandatów, ale jeszcze dodatkowo zdobywać nagrody za przestrzeganie przepisów. Kasa Wraca z LINK4 to narzędzie, które wspiera nas w utrzymaniu bezpieczeństwa w trasie i daje szansę na oszczędności oraz dodatkowe korzyści.

## Wojny streamingowe – w USA się skończyły, w Polsce są przyszłością
 - [https://www.wirtualnemedia.pl/artykul/wojny-streamingowe-ranking-serwisow-vod](https://www.wirtualnemedia.pl/artykul/wojny-streamingowe-ranking-serwisow-vod)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T07:05:00+00:00

Streaming wideo na żądanie to tylko 6,5 proc. całkowitej oglądalności na ekranach telewizorów w Polsce, a w USA – ponad 34 proc. Ta różnica będzie się zmniejszać, choć nie tak szybko.

## W 2024 roku na emeryturę pomostową będzie mogło przejść 7,3 tys. osób
 - [https://www.wirtualnemedia.pl/artykul/jak-przejsc-na-emeryture-pomostowa](https://www.wirtualnemedia.pl/artykul/jak-przejsc-na-emeryture-pomostowa)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T06:37:38.691055+00:00

Według szacunków po uchyleniu wygasającego charakteru emerytur pomostowych na to świadczenie przejdzie w 2024 r. około 7,3 tys. osób - podał Zakład Ubezpieczeń Społecznych. Pod koniec czerwca 2023 r. emerytury pomostowe pobierało łącznie 40,8 tys. osób.

## 26 proc. mikrofirm sięgało w ostatnim roku po finansowanie zewnętrzne
 - [https://www.wirtualnemedia.pl/artykul/finansowanie-zewnetrzne](https://www.wirtualnemedia.pl/artykul/finansowanie-zewnetrzne)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T05:32:17.179995+00:00

26 proc. spośród ponad 500 przebadanych jednoosobowych mikrofirm sięgało w ubiegłym roku po finansowanie zewnętrzne, głównie na zakup towarów lub spłatę zobowiązań - wynika z badania "Barometr wydatków firmowych".

## Cyfrowy Polsat bez 97 proc. zysku. Ma mniej abonentów
 - [https://www.wirtualnemedia.pl/artykul/cyfrowy-polsat-mniej-abonentow-zysk-w-dol-o-97-proc](https://www.wirtualnemedia.pl/artykul/cyfrowy-polsat-mniej-abonentow-zysk-w-dol-o-97-proc)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T05:32:17.177635+00:00

W zeszłym kwartale grupa Cyfrowy Polsat zwiększyła wpływy sprzedażowe o 1,9 proc. do 3,29 mld zł, a jej zysk netto skurczył się z 282,7 do 8,1 mln zł, głównie wskutek 300 mln zł kosztów finansowych.

## Pirat telewizyjny zapłaci grzywnę. Zidentyfikowano ponad 400 klientów
 - [https://www.wirtualnemedia.pl/artykul/pirat-sad-grzywna-mandaty-piractwo-telewizyjne-piractwo-iptv-listy-m3u](https://www.wirtualnemedia.pl/artykul/pirat-sad-grzywna-mandaty-piractwo-telewizyjne-piractwo-iptv-listy-m3u)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T05:32:17.175330+00:00

Sąd w Getyndze skazał 33-latka na grzywnę w wysokości 10 tys. euro za dystrybucję i sprzedaż nielegalnego dostępu do platformy cyfrowej Sky Deutschland. Niemiecka prokuratura domagała się siedmiu miesięcy więzienia z warunkowym zawieszeniem wykonania kary.

## Listy wyborcze Koalicji Obywatelskiej: Michał Kołodziejczak "jedynką" w Koninie, Grzegorz Schetyna powalczy o Senat
 - [https://www.wirtualnemedia.pl/artykul/lista-wyborcza-koalicja-obywatelsk-donald-tusk-warszawa-michal-kolodziejczak-konin-grzegorz-schetyna-senat](https://www.wirtualnemedia.pl/artykul/lista-wyborcza-koalicja-obywatelsk-donald-tusk-warszawa-michal-kolodziejczak-konin-grzegorz-schetyna-senat)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T05:32:17.172884+00:00

Lider Agrounii Michał Kołodziejczak będzie "jedynką" na liście wyborczej KO do Sejmu w Koninie; Bogusław Wołoszański - w Piotrkowie Trybunalskim, a marszałek woj. lubuskiego Elżbieta Polak w Zielonej Górze. Na liście KO do Sejmu znajdzie się też b. prezes PZN Apoloniusz Tajner. Poseł Grzegorza Schetyna powalczy o Senat.

## Bank Pekao z odświeżoną wersją Kantoru Pekao24
 - [https://www.wirtualnemedia.pl/artykul/kantor-pekao24-aplikacja](https://www.wirtualnemedia.pl/artykul/kantor-pekao24-aplikacja)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-17T04:27:18.233528+00:00

Bank Pekao S.A. udostępnił klientom detalicznym nową odsłonę internetowego kantoru, który zastąpił dotychczasowe rozwiązanie służące do wymiany walut. Z nowego Kantoru Pekao24 mogą korzystać nowi i obecni klienci banku od razu po zalogowaniu się do aplikacji mobilnej PeoPay lub bankowości internetowej Pekao24.

