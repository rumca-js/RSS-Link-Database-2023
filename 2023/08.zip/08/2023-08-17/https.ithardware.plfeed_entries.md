# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Blisko połowa Amerykanów chce zakazu TikToka
 - [https://ithardware.pl/aktualnosci/blisko_polowa_amerykanow_chce_zakazu_tiktoka-28836.html](https://ithardware.pl/aktualnosci/blisko_polowa_amerykanow_chce_zakazu_tiktoka-28836.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T21:58:20+00:00

<img src="https://ithardware.pl/artykuly/min/28836_1.jpg" />            Według najnowszego badania przeprowadzonego przez Reuters/Ipsos, blisko połowa dorosłych obywateli Stan&oacute;w Zjednoczonych popiera wprowadzenie zakazu korzystania z chińskiej aplikacji społecznościowej TikTok. Ankieta jednocześnie pytała...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/blisko_polowa_amerykanow_chce_zakazu_tiktoka-28836.html">https://ithardware.pl/aktualnosci/blisko_polowa_amerykanow_chce_zakazu_tiktoka-28836.html</a></p>

## Pierwszy patch do Baldur's Gate III będzie zawierał ponad 1000 poprawek
 - [https://ithardware.pl/aktualnosci/pierwszy_patch_do_baldur_s_gate_iii_bedzie_zawieral_ponad_1000_poprawek-28835.html](https://ithardware.pl/aktualnosci/pierwszy_patch_do_baldur_s_gate_iii_bedzie_zawieral_ponad_1000_poprawek-28835.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T21:43:40+00:00

<img src="https://ithardware.pl/artykuly/min/28835_1.jpg" />            Tw&oacute;rcy Baldur's Gate III przygotowują&nbsp;się do wydania&nbsp;pierwszego patcha i wygląda na to, że będzie on&nbsp;ogromny.&nbsp;Dyrektor generalny Larian Studios, Swen Vincke, potwierdził harmonogrm na Twitterze, obiecując naprawić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwszy_patch_do_baldur_s_gate_iii_bedzie_zawieral_ponad_1000_poprawek-28835.html">https://ithardware.pl/aktualnosci/pierwszy_patch_do_baldur_s_gate_iii_bedzie_zawieral_ponad_1000_poprawek-28835.html</a></p>

## Call of Duty: Modern Warfare 3 - Activision Blizzard ujawnia cenę, edycje i szczegóły gry
 - [https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_3_activision_blizzard_ujawnia_cene_edycje_i_szczegoly_gry-28834.html](https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_3_activision_blizzard_ujawnia_cene_edycje_i_szczegoly_gry-28834.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T19:50:00+00:00

<img src="https://ithardware.pl/artykuly/min/28834_1.jpg" />            Activision Blizzard ujawnił najważniejsze informacje o Call of Duty: Modern Warfare 3 w tym listę map do trybu wieloosobowego, a także cenę. Niestety za aktualizację do Modern Warfare 2 sprzedawaną jako oddzielną grę przyjdzie nam zapłacić...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_3_activision_blizzard_ujawnia_cene_edycje_i_szczegoly_gry-28834.html">https://ithardware.pl/aktualnosci/call_of_duty_modern_warfare_3_activision_blizzard_ujawnia_cene_edycje_i_szczegoly_gry-28834.html</a></p>

## Windows 11 ułatwi skasowanie domyślnych aplikacji
 - [https://ithardware.pl/aktualnosci/windows_11_ulatwi_skasowanie_domyslnych_aplikacji-28833.html](https://ithardware.pl/aktualnosci/windows_11_ulatwi_skasowanie_domyslnych_aplikacji-28833.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T18:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/28833_1.jpg" />            Microsoft ułatwi usuwanie jeszcze większej ilości domyślnie zainstalowanych program&oacute;w w Windowsie 11. Są osoby, kt&oacute;re denerwuje baza takich aplikacji, więc firma z Redmond wyszła im naprzeciw. Stosowne udogodnienie jest już obecne w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/windows_11_ulatwi_skasowanie_domyslnych_aplikacji-28833.html">https://ithardware.pl/aktualnosci/windows_11_ulatwi_skasowanie_domyslnych_aplikacji-28833.html</a></p>

## Mały i szybki AOC 24G15N -  23,8-calowy monitor VA z odświeżaniem 180 Hz
 - [https://ithardware.pl/aktualnosci/aoc_24g15n_23_8_calowy_monitor_va_z_odswiezaniem_na_poziomie_180_hz-28832.html](https://ithardware.pl/aktualnosci/aoc_24g15n_23_8_calowy_monitor_va_z_odswiezaniem_na_poziomie_180_hz-28832.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T17:59:50+00:00

<img src="https://ithardware.pl/artykuly/min/28832_1.jpg" />            AOC zaprezentowało sw&oacute;j najnowszy monitor dedykowany graczom, o nazwie AOC 24G15N. Nowe urządzenie posiada panel VA, wysoką częstotliwość&nbsp;odświeżania oraz szybki czas&nbsp;reakcji.

Monitor jest przeznaczony dla os&oacute;b,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aoc_24g15n_23_8_calowy_monitor_va_z_odswiezaniem_na_poziomie_180_hz-28832.html">https://ithardware.pl/aktualnosci/aoc_24g15n_23_8_calowy_monitor_va_z_odswiezaniem_na_poziomie_180_hz-28832.html</a></p>

## Czy to już gamingowy projektor? Samsung Freestyle Gen 2 z opcją grania w chmurze
 - [https://ithardware.pl/aktualnosci/czy_to_juz_gamingowy_projektor_samsung_freestyle_gen_2_z_opcja_grania_w_chmurze-28831.html](https://ithardware.pl/aktualnosci/czy_to_juz_gamingowy_projektor_samsung_freestyle_gen_2_z_opcja_grania_w_chmurze-28831.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T17:49:10+00:00

<img src="https://ithardware.pl/artykuly/min/28831_1.jpg" />            Samsung przedstawił sw&oacute;j nowy projektor z gamingowym akcentem. Urządzenie może wyświetlić obraz o rozmiarze do 100 cali. Co najciekawsze, pozwala r&oacute;wnież na dostęp do platform ze streamingiem gier. Sprzęt dostępny jest już w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/czy_to_juz_gamingowy_projektor_samsung_freestyle_gen_2_z_opcja_grania_w_chmurze-28831.html">https://ithardware.pl/aktualnosci/czy_to_juz_gamingowy_projektor_samsung_freestyle_gen_2_z_opcja_grania_w_chmurze-28831.html</a></p>

## Baterie z płynnym metalem już w 2024 roku. Są tanie, niepalne i trwałe
 - [https://ithardware.pl/aktualnosci/baterie_z_plynnym_metalem_juz_w_2024_roku_sa_tanie_niepalne_i_trwale-28830.html](https://ithardware.pl/aktualnosci/baterie_z_plynnym_metalem_juz_w_2024_roku_sa_tanie_niepalne_i_trwale-28830.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T17:09:40+00:00

<img src="https://ithardware.pl/artykuly/min/28830_1.jpg" />            Ambri opracowuje alternatywę dla obecnie stosowanych baterii litowych. W przypadku tej innowacji kluczowym elementem jest wykorzystanie płynnego metalu oraz soli chlorkowo-wapniowej. Celem&nbsp;jest zapewnienie znacząco wydłużonej trwałości...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/baterie_z_plynnym_metalem_juz_w_2024_roku_sa_tanie_niepalne_i_trwale-28830.html">https://ithardware.pl/aktualnosci/baterie_z_plynnym_metalem_juz_w_2024_roku_sa_tanie_niepalne_i_trwale-28830.html</a></p>

## Google ułatwia czytanie długich treści. Wszystko dzięki sztucznej inteligencji
 - [https://ithardware.pl/aktualnosci/google_ulatwia_czytanie_dlugich_tresci_wszystko_dzieki_sztucznej_inteligencji-28828.html](https://ithardware.pl/aktualnosci/google_ulatwia_czytanie_dlugich_tresci_wszystko_dzieki_sztucznej_inteligencji-28828.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T16:08:20+00:00

<img src="https://ithardware.pl/artykuly/min/28828_1.jpg" />            Google zdradził nowe informacje na temat technologii Search Generative Experience, kt&oacute;rej zadaniem jest pom&oacute;c użytkownikom w czytaniu długich artykuł&oacute;w i innych treści. Narzędzie potrafi tworzyć kluczowe punkty wynikające z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_ulatwia_czytanie_dlugich_tresci_wszystko_dzieki_sztucznej_inteligencji-28828.html">https://ithardware.pl/aktualnosci/google_ulatwia_czytanie_dlugich_tresci_wszystko_dzieki_sztucznej_inteligencji-28828.html</a></p>

## Ile sezonów dostanie serial The Last of Us. Twórca podaje idealny numer
 - [https://ithardware.pl/aktualnosci/ile_sezonow_dostanie_serial_the_last_of_us_tworca_podaje_idealny_numer-28829.html](https://ithardware.pl/aktualnosci/ile_sezonow_dostanie_serial_the_last_of_us_tworca_podaje_idealny_numer-28829.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T15:50:22+00:00

<img src="https://ithardware.pl/artykuly/min/28829_1.jpg" />            Pierwszy sezon serialu The Last of Us odni&oacute;sł duży sukces i niebawem doczeka się kontynuacji. Tymczasem showrunner Craig Mazin zasugerował, ile jeszcze może potrwać produkcja. Nie będzie to tasiemiec, choć otrzyma więcej czasu niż...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ile_sezonow_dostanie_serial_the_last_of_us_tworca_podaje_idealny_numer-28829.html">https://ithardware.pl/aktualnosci/ile_sezonow_dostanie_serial_the_last_of_us_tworca_podaje_idealny_numer-28829.html</a></p>

## HP kontra pozew zbiorowy. Chodzi o blokowanie drukarek wielofunkcyjnych
 - [https://ithardware.pl/aktualnosci/hp_kontra_pozew_zbiorowy_chodzi_o_blokowanie_drukarek_wielofunkcyjnych-28827.html](https://ithardware.pl/aktualnosci/hp_kontra_pozew_zbiorowy_chodzi_o_blokowanie_drukarek_wielofunkcyjnych-28827.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T14:20:30+00:00

<img src="https://ithardware.pl/artykuly/min/28827_1.jpg" />            Sąd federalny postanowił, że HP będzie musiało zmierzyć się z pozwem zbiorowym dotyczącym ich drukarek wielofunkcyjnych. W oskarżeniu chodzi o wyłączanie niekt&oacute;rych możliwości urządzeń,&nbsp;takich jak na przykład skanowanie, gdy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hp_kontra_pozew_zbiorowy_chodzi_o_blokowanie_drukarek_wielofunkcyjnych-28827.html">https://ithardware.pl/aktualnosci/hp_kontra_pozew_zbiorowy_chodzi_o_blokowanie_drukarek_wielofunkcyjnych-28827.html</a></p>

## Test Endorfy Thock Onyx White. Wielki powrót białej edycji po długiej przerwie
 - [https://ithardware.pl/testyirecenzje/endorfy_thock_onyx_white_test_recenzja-28808.html](https://ithardware.pl/testyirecenzje/endorfy_thock_onyx_white_test_recenzja-28808.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T13:23:40+00:00

<img src="https://ithardware.pl/artykuly/min/28808_1.jpg" />            Marki Endorfy chyba nikomu z was nie muszę przedstawiać, gdyż każdy z nas powinien ją w mniejszym bądź większym stopniu kojarzyć. Już niebawem stuknie pierwszy rok od jej powstania, czyli moment, w kt&oacute;rym to wygaszono Silentium PC oraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/endorfy_thock_onyx_white_test_recenzja-28808.html">https://ithardware.pl/testyirecenzje/endorfy_thock_onyx_white_test_recenzja-28808.html</a></p>

## 440 MP sensor od Samsunga? Firma podobno planuje 3 nowe jednostki
 - [https://ithardware.pl/aktualnosci/440_mp_sensor_od_samsunga_firma_podobno_planuje_3_nowe_jednostki-28826.html](https://ithardware.pl/aktualnosci/440_mp_sensor_od_samsunga_firma_podobno_planuje_3_nowe_jednostki-28826.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T12:01:20+00:00

<img src="https://ithardware.pl/artykuly/min/28826_1.jpg" />            Jeden ze znanych leakster&oacute;w, Revegnus, zdradził, że Samsung rozpocznie masową produkcję 3 nowych sensor&oacute;w ISOCELL w przyszłym roku. Jeden z nich ma być jednostką cechującą się rozdzielczością 200 MP. To jednak nie jest maksimum,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/440_mp_sensor_od_samsunga_firma_podobno_planuje_3_nowe_jednostki-28826.html">https://ithardware.pl/aktualnosci/440_mp_sensor_od_samsunga_firma_podobno_planuje_3_nowe_jednostki-28826.html</a></p>

## Nowy Jork zakazał TikToka. Pracownicy mają 30 dni na usunięcie aplikacji
 - [https://ithardware.pl/aktualnosci/nowy_jork_zakazal_tiktoka_pracownicy_maja_30_dni_na_usuniecie_aplikacji-28824.html](https://ithardware.pl/aktualnosci/nowy_jork_zakazal_tiktoka_pracownicy_maja_30_dni_na_usuniecie_aplikacji-28824.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T11:03:50+00:00

<img src="https://ithardware.pl/artykuly/min/28824_1.jpg" />            Miasto Nowy Jork musiało uznać, że TikTok stanowi realne zagrożenie. Władze zakazały tej aplikacji na urządzeniach należących do miasta. Oznacza to, że pracownicy korzystających ze służbowych telefon&oacute;w&nbsp;będą musieli pozbyć się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_jork_zakazal_tiktoka_pracownicy_maja_30_dni_na_usuniecie_aplikacji-28824.html">https://ithardware.pl/aktualnosci/nowy_jork_zakazal_tiktoka_pracownicy_maja_30_dni_na_usuniecie_aplikacji-28824.html</a></p>

## AMD Ryzen 5 7500F pojawił się w sprzedaży w USA i w Europie
 - [https://ithardware.pl/aktualnosci/amd_ryzen_5_7500f_pojawil_sie_w_sprzedazy_w_usa_i_w_europie-28821.html](https://ithardware.pl/aktualnosci/amd_ryzen_5_7500f_pojawil_sie_w_sprzedazy_w_usa_i_w_europie-28821.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T10:28:01+00:00

<img src="https://ithardware.pl/artykuly/min/28821_1.jpg" />            Kiedy AMD wypuściło w zeszłym miesiącu sześciordzeniowy procesor Ryzen 5 7500F, ten zapowiadany był jako produkt na wyłączność dla Chin i poza Państwem Środka dostępny miał być tylko w gotowych komputerach. Wygląda na to, że te...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_5_7500f_pojawil_sie_w_sprzedazy_w_usa_i_w_europie-28821.html">https://ithardware.pl/aktualnosci/amd_ryzen_5_7500f_pojawil_sie_w_sprzedazy_w_usa_i_w_europie-28821.html</a></p>

## Steam wprowadza zmiany, które mogą spowodować wzrosty cen w niektórych krajach
 - [https://ithardware.pl/aktualnosci/steam_wprowadza_zmiany_ktore_moga_spowodowac_wzrosty_cen_w_niektorych_krajach-28820.html](https://ithardware.pl/aktualnosci/steam_wprowadza_zmiany_ktore_moga_spowodowac_wzrosty_cen_w_niektorych_krajach-28820.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T10:19:01+00:00

<img src="https://ithardware.pl/artykuly/min/28820_1.jpg" />            Valve zaktualizowało politykę minimalnych cen na platformie Steam dla niekt&oacute;rych walut innych niż USD, co może mieć wpływ na tych, kt&oacute;rzy sprzedają gry i rozszerzenia za mniej niż r&oacute;wnowartość 5 USD.&nbsp;

Firma...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/steam_wprowadza_zmiany_ktore_moga_spowodowac_wzrosty_cen_w_niektorych_krajach-28820.html">https://ithardware.pl/aktualnosci/steam_wprowadza_zmiany_ktore_moga_spowodowac_wzrosty_cen_w_niektorych_krajach-28820.html</a></p>

## Tak wygląda Lenovo Legion Go. Kolejny handheld rzuci wyzwanie Steam Deckowi
 - [https://ithardware.pl/aktualnosci/tak_wyglada_lenovo_legion_go_kolejny_handheld_rzuci_wyzwanie_steam_deckowi-28823.html](https://ithardware.pl/aktualnosci/tak_wyglada_lenovo_legion_go_kolejny_handheld_rzuci_wyzwanie_steam_deckowi-28823.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T09:36:33+00:00

<img src="https://ithardware.pl/artykuly/min/28823_1.jpg" />            Na początku sierpnia pisaliśmy, że Lenovo to kolejny duży producent, kt&oacute;ry chce rzucić wyzwanie Valve i jego Steam Deckowi i teraz WindowsReport opublikowało pierwsze rendery urządzenia, prezentując nadchodzący handheld w całej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tak_wyglada_lenovo_legion_go_kolejny_handheld_rzuci_wyzwanie_steam_deckowi-28823.html">https://ithardware.pl/aktualnosci/tak_wyglada_lenovo_legion_go_kolejny_handheld_rzuci_wyzwanie_steam_deckowi-28823.html</a></p>

## Łatka dla luki Inception w procesorach AMD powoduje spadki wydajności nawet o 54%
 - [https://ithardware.pl/aktualnosci/latka_dla_luki_inception_w_procesorach_cpu_powoduje_spadki_wydajnosci_nawet_o_54-28819.html](https://ithardware.pl/aktualnosci/latka_dla_luki_inception_w_procesorach_cpu_powoduje_spadki_wydajnosci_nawet_o_54-28819.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T09:00:20+00:00

<img src="https://ithardware.pl/artykuly/min/28819_1.jpg" />            W ubiegłym tygodniu pojawiła się wiadomość o luce w procesorach AMD o nazwie Inception i wygląda na to, że jej załatanie potrafi bardzo mocno wpływać na wydajność CPU w niekt&oacute;rych zastosowaniach.&nbsp;

AMD nie wypuściło jeszcze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/latka_dla_luki_inception_w_procesorach_cpu_powoduje_spadki_wydajnosci_nawet_o_54-28819.html">https://ithardware.pl/aktualnosci/latka_dla_luki_inception_w_procesorach_cpu_powoduje_spadki_wydajnosci_nawet_o_54-28819.html</a></p>

## AMD Ryzen Threadripper PRO 7995WX z 96 rdzeniami potwierdzony. CPU przetestowane w benchmarku
 - [https://ithardware.pl/aktualnosci/amd_ryzen_threadripper_pro_7995wx_z_96_rdzeniami_potwierdzony_cpu_przetestowane_w_benchmarku-28818.html](https://ithardware.pl/aktualnosci/amd_ryzen_threadripper_pro_7995wx_z_96_rdzeniami_potwierdzony_cpu_przetestowane_w_benchmarku-28818.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T08:49:00+00:00

<img src="https://ithardware.pl/artykuly/min/28818_1.jpg" />            Wszystko wskazuje na to, że AMD szykuje się właśnie do wypuszczenia nowych procesor&oacute;w z segmentu HEDT, kt&oacute;re oferować będą jeszcze więcej rdzeni i wyższe częstotliwości taktowania.&nbsp;

Ryzen&nbsp;Threadripper PRO...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_threadripper_pro_7995wx_z_96_rdzeniami_potwierdzony_cpu_przetestowane_w_benchmarku-28818.html">https://ithardware.pl/aktualnosci/amd_ryzen_threadripper_pro_7995wx_z_96_rdzeniami_potwierdzony_cpu_przetestowane_w_benchmarku-28818.html</a></p>

## Jeden z największych technologicznych kanałów oskarżany o nierzetelność, kradzież i molestowanie
 - [https://ithardware.pl/aktualnosci/jeden_z_najwiekszych_technologicznych_kanalow_oskarazany_o_nierzetelnosc_kradziez_i_molestowanie-28822.html](https://ithardware.pl/aktualnosci/jeden_z_najwiekszych_technologicznych_kanalow_oskarazany_o_nierzetelnosc_kradziez_i_molestowanie-28822.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T07:41:06+00:00

<img src="https://ithardware.pl/artykuly/min/28822_1.jpg" />            Youtubowe imperium Linusa Sebastiana (Linus Media Group) w YouTube przeżywa obecnie bardzo poważny kryzys, a wszystko za sprawą pojawiających się oskarżeń o kradzież, uchybienia w etyce zawodowej, a ostatnio nawet molestowanie. Firma wstrzymała...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/jeden_z_najwiekszych_technologicznych_kanalow_oskarazany_o_nierzetelnosc_kradziez_i_molestowanie-28822.html">https://ithardware.pl/aktualnosci/jeden_z_najwiekszych_technologicznych_kanalow_oskarazany_o_nierzetelnosc_kradziez_i_molestowanie-28822.html</a></p>

## AMD potiwerdza duże ogłoszenia na Gamescom. Czego się spodziewać?
 - [https://ithardware.pl/aktualnosci/amd_potiwerdza_duze_ogloszenia_na_gamescom_czego_sie_spodziewac-28817.html](https://ithardware.pl/aktualnosci/amd_potiwerdza_duze_ogloszenia_na_gamescom_czego_sie_spodziewac-28817.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T07:03:13+00:00

<img src="https://ithardware.pl/artykuly/min/28817_1.jpg" />            Scott Herkelman, starszy wiceprezes i dyrektor generalny działu General Manager Graphics Business Unit w AMD, potwierdził właśnie, że jego firma ogłosi nowe produkty na targach Gamescom. Biorąc pod uwagę ostatnie przecieki, spodziewamy się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_potiwerdza_duze_ogloszenia_na_gamescom_czego_sie_spodziewac-28817.html">https://ithardware.pl/aktualnosci/amd_potiwerdza_duze_ogloszenia_na_gamescom_czego_sie_spodziewac-28817.html</a></p>

## Intel rezygnuje z dużego przejęcia. Chiny zablokowały plan amerykańskiego giganta
 - [https://ithardware.pl/aktualnosci/intel_rezygnuje_z_duzego_przejecia_chiny_zablokowaly_plan_amerykanskiego_giganta-28816.html](https://ithardware.pl/aktualnosci/intel_rezygnuje_z_duzego_przejecia_chiny_zablokowaly_plan_amerykanskiego_giganta-28816.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-17T06:16:26+00:00

<img src="https://ithardware.pl/artykuly/min/28816_1.jpg" />            Przejęcie przez Intel izraelskiego producenta chip&oacute;w specjalnych Tower Semiconductor za 5,4 miliarda dolar&oacute;w zostało odwołane, ponieważ gigant z Santa Clara nie uzyskał na czas zgody organ&oacute;w regulacyjnych z Chin. To kładzie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_rezygnuje_z_duzego_przejecia_chiny_zablokowaly_plan_amerykanskiego_giganta-28816.html">https://ithardware.pl/aktualnosci/intel_rezygnuje_z_duzego_przejecia_chiny_zablokowaly_plan_amerykanskiego_giganta-28816.html</a></p>

