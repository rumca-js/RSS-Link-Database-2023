# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Zderzenie dwóch tramwajów w Portugalii. Kilkunastu rannych, w tym dzieci
 - [https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-tramwajow-w-portugalii-kilkunastu-rannych-w-,nId,6969293](https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-tramwajow-w-portugalii-kilkunastu-rannych-w-,nId,6969293)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T21:36:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zderzenie-dwoch-tramwajow-w-portugalii-kilkunastu-rannych-w-,nId,6969293"><img align="left" alt="Zderzenie dwóch tramwajów w Portugalii. Kilkunastu rannych, w tym dzieci" src="https://i.iplsc.com/zderzenie-dwoch-tramwajow-w-portugalii-kilkunastu-rannych-w/000HJSF0QQJEFXIO-C321.jpg" /></a>Groźne zderzenie dwóch tramwajów w centrum Lizbony w Portugalii. W wypadku poszkodowanych zostało co najmniej 13 osób, w tym obcokrajowcy i troje dzieci. Żaden z pasażerów nie został poważnie ranny, jednak ośmiu podróżnych przewieziono do szpitala. Przyczyny wypadku nie są obecnie znane, wyjaśnieniem okoliczności zdarzenia zajmują się służby.</p><br clear="all" />

## Dotarli do akt z rosyjskiej fabryki. "W Ukrainę będą uderzać setki dronów"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dotarli-do-akt-z-rosyjskiej-fabryki-w-ukraine-beda-uderzac-s,nId,6969260](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dotarli-do-akt-z-rosyjskiej-fabryki-w-ukraine-beda-uderzac-s,nId,6969260)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T20:04:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dotarli-do-akt-z-rosyjskiej-fabryki-w-ukraine-beda-uderzac-s,nId,6969260"><img align="left" alt="Dotarli do akt z rosyjskiej fabryki. &quot;W Ukrainę będą uderzać setki dronów&quot;" src="https://i.iplsc.com/dotarli-do-akt-z-rosyjskiej-fabryki-w-ukraine-beda-uderzac-s/000HJS4OEVBUFLPT-C321.jpg" /></a>Rosjanie produkują na własnym terytorium setki irańskich dronów Shahed i w najbliższym czasie mogą znacząco zwiększyć swoje możliwości atakowania z powietrza - wynika z tajnych dokumentów, które dziennikarzom &quot;The Washington Post&quot; przekazał jeden z pracowników tajnego zakładu. Ujawniona dokumentacja dostarcza analitykom wielu cennych danych, ale przede wszystkim jest ostrzeżeniem dla samej Ukrainy. - Rosjanie mogą wkrótce przejść od okresowego wystrzeliwania importowanych dronów do regularnego zrzucania na Ukrainę setek maszyn - ocenia...</p><br clear="all" />

## Ujawniła zwyczaj swój i męża. Chciała wiedzieć, czy inni też robią
 - [https://wydarzenia.interia.pl/zagranica/news-ujawnila-zwyczaj-swoj-i-meza-chciala-wiedziec-czy-inni-tez-r,nId,6969272](https://wydarzenia.interia.pl/zagranica/news-ujawnila-zwyczaj-swoj-i-meza-chciala-wiedziec-czy-inni-tez-r,nId,6969272)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T20:01:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ujawnila-zwyczaj-swoj-i-meza-chciala-wiedziec-czy-inni-tez-r,nId,6969272"><img align="left" alt="Ujawniła zwyczaj swój i męża. Chciała wiedzieć, czy inni też robią " src="https://i.iplsc.com/ujawnila-zwyczaj-swoj-i-meza-chciala-wiedziec-czy-inni-tez-r/000HJSB29TGSMR0N-C321.jpg" /></a>Kalifornijska TikTokerka Angelina Murphy, która na platformie udziela się jako @renovatingourhome podzieliła się w internecie sypialnianym zwyczajem, jaki ma wraz ze swoim mężem. Kobieta zdecydowała się na wyznanie, ponieważ chciała wiedzieć, czy inni też tak robią.  </p><br clear="all" />

## Referendum w Sejmie. "Demokracja w świątecznym nastroju" vs "bojkot"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-referendum-w-sejmie-demokracja-w-swiatecznym-nastroju-vs-boj,nId,6969209](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-referendum-w-sejmie-demokracja-w-swiatecznym-nastroju-vs-boj,nId,6969209)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T19:58:56+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-referendum-w-sejmie-demokracja-w-swiatecznym-nastroju-vs-boj,nId,6969209"><img align="left" alt="Referendum w Sejmie. &quot;Demokracja w świątecznym nastroju&quot; vs &quot;bojkot&quot;" src="https://i.iplsc.com/referendum-w-sejmie-demokracja-w-swiatecznym-nastroju-vs-boj/000HJS8TRGW7B014-C321.jpg" /></a>- Demokracja jest dzisiaj w świątecznym nastroju - mówił minister edukacji narodowej i nauki Przemysław Czarnek, a we wpisie dodał: &quot;Opozycja boi się jak ognia tych pytań, bo są dla nich obciążające&quot;. W taki sposób odniósł się do przyjęcia przez Sejm daty 15 października, jako dnia, w którym odbędzie się referendum. Z kolei opozycja wyraża swoje niezadowolenie. &quot;Referendum Kaczyńskiego trzeba zbojkotować!&quot; - podano na Twitterze Lewicy, co oznajmił również wiceszef klubu Krzysztof Śmiszek i dodał, że nadal będą mówić, że &quot;to referendum jest...</p><br clear="all" />

## Łukaszenka grozi Polsce. Mówi też o broni atomowej
 - [https://wydarzenia.interia.pl/zagranica/news-lukaszenka-grozi-polsce-mowi-tez-o-broni-atomowej,nId,6969253](https://wydarzenia.interia.pl/zagranica/news-lukaszenka-grozi-polsce-mowi-tez-o-broni-atomowej,nId,6969253)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T19:23:40+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lukaszenka-grozi-polsce-mowi-tez-o-broni-atomowej,nId,6969253"><img align="left" alt="Łukaszenka grozi Polsce. Mówi też o broni atomowej" src="https://i.iplsc.com/lukaszenka-grozi-polsce-mowi-tez-o-broni-atomowej/000HJS2KY5UWY3IB-C321.jpg" /></a>- Jeśli agresja na Białoruś zostanie rozpoczęta od strony Polski, natychmiast odpowiemy wszystkim, co mamy - grozi w najnowszym wywiadzie Alaksandr Łukaszenka. Białoruski przywódca ujawnia swoje plany wobec rosyjskiej broni, zdeponowanej w jego kraju oraz wzywa do rozmów pokojowych w Ukrainie.</p><br clear="all" />

## Bezpardonowy ruch Polski i krajów bałtyckich. Kluczowe rozmowy w Warszawie
 - [https://wydarzenia.interia.pl/zagranica/news-bezpardonowy-ruch-polski-i-krajow-baltyckich-kluczowe-rozmow,nId,6969231](https://wydarzenia.interia.pl/zagranica/news-bezpardonowy-ruch-polski-i-krajow-baltyckich-kluczowe-rozmow,nId,6969231)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T19:16:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bezpardonowy-ruch-polski-i-krajow-baltyckich-kluczowe-rozmow,nId,6969231"><img align="left" alt="Bezpardonowy ruch Polski i krajów bałtyckich. Kluczowe rozmowy w Warszawie" src="https://i.iplsc.com/bezpardonowy-ruch-polski-i-krajow-baltyckich-kluczowe-rozmow/000HJS0PNPN6VX1C-C321.jpg" /></a>Litwa zamknęła tymczasowo dwa przejścia graniczne z Białorusią z uwagi na &quot;względy bezpieczeństwa&quot;. Jednocześnie zapowiedziano kolejne działania, które rozważają zarówno kraje bałtyckie, jak i Polska. Mowa tutaj o opcji całkowitego zamknięcia granic z Białorusią. Spotkanie w tej sprawie ma odbyć się w Warszawie jeszcze w tym miesiącu. Tymczasem Białoruś decyzję Litwy o wyłączeniu z ruchu dwóch punktów granicznych nazwała &quot;nieprzyjaznym krokiem&quot;.</p><br clear="all" />

## Symetryści na cenzurowanym. Campus odwołuje debatę
 - [https://wydarzenia.interia.pl/kraj/news-symetrysci-na-cenzurowanym-campus-odwoluje-debate,nId,6969273](https://wydarzenia.interia.pl/kraj/news-symetrysci-na-cenzurowanym-campus-odwoluje-debate,nId,6969273)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T19:14:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-symetrysci-na-cenzurowanym-campus-odwoluje-debate,nId,6969273"><img align="left" alt="Symetryści na cenzurowanym. Campus odwołuje debatę" src="https://i.iplsc.com/symetrysci-na-cenzurowanym-campus-odwoluje-debate/000HJSAT9AQV9K3S-C321.jpg" /></a>Marcin Meller poinformował w mediach społecznościowych, że debata symetrystów na Campus Polska Przyszłości została odwołana. Dziennikarz ujawnił, że organizatorzy naciskali na zorganizowanie rozmowy bez udziału Grzegorza Sroczyńskiego, w związku z czym kategorycznie odmówił.</p><br clear="all" />

## Rosja na cenzurowanym. Erdogan zareagował
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-na-cenzurowanym-erdogan-zareagowal,nId,6969240](https://wydarzenia.interia.pl/zagranica/news-rosja-na-cenzurowanym-erdogan-zareagowal,nId,6969240)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T18:52:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-na-cenzurowanym-erdogan-zareagowal,nId,6969240"><img align="left" alt="Rosja na cenzurowanym. Erdogan zareagował" src="https://i.iplsc.com/rosja-na-cenzurowanym-erdogan-zareagowal/000HJRY05V0F225L-C321.jpg" /></a>Napięcie między Ankarą a Moskwą rośnie. Recep Tayyip Erdogan wezwał Władimira Putina do powstrzymania się od większej eskalacji na Morzu Czarnym. To pierwsza reakcja z prezydenckiego obozu po oddaniu strzałów ostrzegawczych w stronę tureckiego statku.</p><br clear="all" />

## Była stałą klientką. Sklep tracił na jej "zakupach"
 - [https://wydarzenia.interia.pl/mazowieckie/news-byla-stala-klientka-sklep-tracil-na-jej-zakupach,nId,6969244](https://wydarzenia.interia.pl/mazowieckie/news-byla-stala-klientka-sklep-tracil-na-jej-zakupach,nId,6969244)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T18:24:04+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-byla-stala-klientka-sklep-tracil-na-jej-zakupach,nId,6969244"><img align="left" alt="Była stałą klientką. Sklep tracił na jej &quot;zakupach&quot;" src="https://i.iplsc.com/byla-stala-klientka-sklep-tracil-na-jej-zakupach/0004T2WHXAMAL4RK-C321.jpg" /></a>Pracownicy jednej z drogerii w Piasecznie myśleli, że mają stałą klientkę. Wszystko zmieniło się, kiedy 41-latka została przyłapana na kradzieży. Na miejsce wezwano policję, która po przeglądnięciu monitoringu oświadczyła, ze kobieta w przeszłości kilkukrotnie wychodziła ze sklepu bez płacenia. Teraz grozi jej do pięciu lat więzienia.</p><br clear="all" />

## Krakowscy radni chcą specjalnych stref. Biorą przykład z Warszawy
 - [https://wydarzenia.interia.pl/malopolskie/news-krakowscy-radni-chca-specjalnych-stref-biora-przyklad-z-wars,nId,6969227](https://wydarzenia.interia.pl/malopolskie/news-krakowscy-radni-chca-specjalnych-stref-biora-przyklad-z-wars,nId,6969227)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T18:07:59+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-krakowscy-radni-chca-specjalnych-stref-biora-przyklad-z-wars,nId,6969227"><img align="left" alt="Krakowscy radni chcą specjalnych stref. Biorą przykład z Warszawy" src="https://i.iplsc.com/krakowscy-radni-chca-specjalnych-stref-biora-przyklad-z-wars/0005NOWN9AOJQ1WH-C321.jpg" /></a>Dwóch lokalnych polityków z Krakowa chce wyznaczenia w stolicy małopolski stref w miejscach publicznych, w których będzie można pić alkohol. W czwartek przedstawili projekt uchwały dotyczącej przeprowadzenia konsultacji w tej sprawie.  </p><br clear="all" />

## Mówił o "dawaniu w szyję". Sejm zajął się immunitetem Kaczyńskiego
 - [https://wydarzenia.interia.pl/kraj/news-mowil-o-dawaniu-w-szyje-sejm-zajal-sie-immunitetem-kaczynski,nId,6969217](https://wydarzenia.interia.pl/kraj/news-mowil-o-dawaniu-w-szyje-sejm-zajal-sie-immunitetem-kaczynski,nId,6969217)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T17:55:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mowil-o-dawaniu-w-szyje-sejm-zajal-sie-immunitetem-kaczynski,nId,6969217"><img align="left" alt="Mówił o &quot;dawaniu w szyję&quot;. Sejm zajął się immunitetem Kaczyńskiego" src="https://i.iplsc.com/mowil-o-dawaniu-w-szyje-sejm-zajal-sie-immunitetem-kaczynski/000HJRS3YF6NPO71-C321.jpg" /></a>Jarosław Kaczyński nie stanie przed sądem za swoje słowa o młodych bezdzietnych kobietach &quot;dających w szyję&quot;. Wniosek o uchylenie immunitetu odrzuciło 238 posłów. Część klubu PSL wstrzymała się od głosu, do rozłamu doszło też w Konfederacji. </p><br clear="all" />

## Azjatyckie szerszenie szturmują Europę. Zaczęły zalewać kolejny kraj
 - [https://wydarzenia.interia.pl/zagranica/news-azjatyckie-szerszenie-szturmuja-europe-zaczely-zalewac-kolej,nId,6969187](https://wydarzenia.interia.pl/zagranica/news-azjatyckie-szerszenie-szturmuja-europe-zaczely-zalewac-kolej,nId,6969187)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T17:51:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-azjatyckie-szerszenie-szturmuja-europe-zaczely-zalewac-kolej,nId,6969187"><img align="left" alt="Azjatyckie szerszenie szturmują Europę. Zaczęły zalewać kolejny kraj" src="https://i.iplsc.com/azjatyckie-szerszenie-szturmuja-europe-zaczely-zalewac-kolej/000HJRRHJX2F210U-C321.jpg" /></a>Azjatyckie szerszenie zaczęły zdecydowanie szybciej rozprzestrzeniać się w Wielkiej Brytanii, co potwierdzają prowadzone statystyki. Na przestrzeni lat widać wyraźny wzrost liczby zaobserwowanych osobników, co niepokoi władze i ekspertów, bo pochodzące z Azji owady są wysoce ekspansywne i zagrażają innym gatunkom. Potwierdzają to choćby zdarzenia z Francji, gdzie szerszenie zdziesiątkowały populację pszczoły miodnej. W związku z tym podjęto konkretne działania, które mają ograniczyć rozmnażanie się gatunku na Wyspach Brytyjskich.</p><br clear="all" />

## Zniknął z Ikei. Kilka godzin później był martwy
 - [https://wydarzenia.interia.pl/zagranica/news-zniknal-z-ikei-kilka-godzin-pozniej-byl-martwy,nId,6969198](https://wydarzenia.interia.pl/zagranica/news-zniknal-z-ikei-kilka-godzin-pozniej-byl-martwy,nId,6969198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T17:26:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zniknal-z-ikei-kilka-godzin-pozniej-byl-martwy,nId,6969198"><img align="left" alt="Zniknął z Ikei. Kilka godzin później był martwy " src="https://i.iplsc.com/zniknal-z-ikei-kilka-godzin-pozniej-byl-martwy/000GCW300HHYF6NS-C321.jpg" /></a>W środę w jednym ze sklepów sieci Ikea w nowojorskim Brooklynie zaginął dziewięcioletni chłopiec. Po trzech godzinach poszukiwań został wyłowiony w krytycznym stanie z pobliskiego kanału.</p><br clear="all" />

## Zniknął ze sklepu. Kilka godzin później był martwy
 - [https://wydarzenia.interia.pl/zagranica/news-zniknal-ze-sklepu-kilka-godzin-pozniej-byl-martwy,nId,6969198](https://wydarzenia.interia.pl/zagranica/news-zniknal-ze-sklepu-kilka-godzin-pozniej-byl-martwy,nId,6969198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T17:26:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zniknal-ze-sklepu-kilka-godzin-pozniej-byl-martwy,nId,6969198"><img align="left" alt="Zniknął ze sklepu. Kilka godzin później był martwy " src="https://i.iplsc.com/zniknal-ze-sklepu-kilka-godzin-pozniej-byl-martwy/000C60Y7QMWNKVPW-C321.jpg" /></a>W środę w jednym ze sklepów meblowych w nowojorskim Brooklynie zaginął dziewięcioletni chłopiec. Po trzech godzinach poszukiwań został wyłowiony w krytycznym stanie z pobliskiego kanału.</p><br clear="all" />

## Wyborcza uchwała PiS przyjęta przez Sejm
 - [https://wydarzenia.interia.pl/kraj/news-wyborcza-uchwala-pis-przyjeta-przez-sejm,nId,6969197](https://wydarzenia.interia.pl/kraj/news-wyborcza-uchwala-pis-przyjeta-przez-sejm,nId,6969197)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T17:09:27+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wyborcza-uchwala-pis-przyjeta-przez-sejm,nId,6969197"><img align="left" alt="Wyborcza uchwała PiS przyjęta przez Sejm" src="https://i.iplsc.com/wyborcza-uchwala-pis-przyjeta-przez-sejm/000HJRPHPBGCCOG6-C321.jpg" /></a>PiS przeforsował przez Sejm uchwałę ws. obcej ingerencji w proces wyborczy w Polsce. Za dokumentem głosowało 234 posłów, wstrzymała się część koła Konfederacji oraz posłanka KP PSL Magdalena Sroka. </p><br clear="all" />

## Ogłosił start w wyborach. Zdjęto jego program, prezes IPN wbił szpilę
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-oglosil-start-w-wyborach-zdjeto-jego-program-prezes-ipn-wbil,nId,6969007](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-oglosil-start-w-wyborach-zdjeto-jego-program-prezes-ipn-wbil,nId,6969007)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T16:47:48+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-oglosil-start-w-wyborach-zdjeto-jego-program-prezes-ipn-wbil,nId,6969007"><img align="left" alt="Ogłosił start w wyborach. Zdjęto jego program, prezes IPN wbił szpilę" src="https://i.iplsc.com/oglosil-start-w-wyborach-zdjeto-jego-program-prezes-ipn-wbil/000HJRPBMGFSRG0L-C321.jpg" /></a>Dzień po tym, jak dziennikarz historyczny Bogusław Wołoszański ogłosił start w wyborach do Sejmu z list Koalicji Obywatelskiej, jego program &quot;Sensacje XX wieku&quot; zniknął z anteny TVP Historia. Kandydatowi do niższej izby parlamentu KO szpilę wbił również prezes Instytutu Pamięci Narodowej Karol Nawrocki, który zarzucił Wołoszańskiemu współpracę ze Służbą Bezpieczeństwa w okresie PRL. Podobne odwołania pojawiły się w wieczornym wydaniu środowych &quot;Wiadomości&quot;.</p><br clear="all" />

## Lex Czarnek 3.0 w Sejmie. Posłowie podjęli decyzję
 - [https://wydarzenia.interia.pl/kraj/news-lex-czarnek-3-0-w-sejmie-poslowie-podjeli-decyzje,nId,6968850](https://wydarzenia.interia.pl/kraj/news-lex-czarnek-3-0-w-sejmie-poslowie-podjeli-decyzje,nId,6968850)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T16:35:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-lex-czarnek-3-0-w-sejmie-poslowie-podjeli-decyzje,nId,6968850"><img align="left" alt="Lex Czarnek 3.0 w Sejmie. Posłowie podjęli decyzję" src="https://i.iplsc.com/lex-czarnek-3-0-w-sejmie-poslowie-podjeli-decyzje/000HJPII5P7WY4O3-C321.jpg" /></a>Po raz trzeci w ciągu ostatnich miesięcy Sejm zajmował się nowelizacją ustawy Prawo oświatowe, znaną szerzej jako &quot;lex Czarnek 3.0&quot;. W czwartek 243 posłów poparło zmiany w szkolnictwie, 202 było przeciw. </p><br clear="all" />

## Rosjanie uderzyli w ukraiński pociąg. Pokazali nagranie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-uderzyli-w-ukrainski-pociag-pokazali-nagranie,nId,6969022](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-uderzyli-w-ukrainski-pociag-pokazali-nagranie,nId,6969022)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T16:08:38+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-uderzyli-w-ukrainski-pociag-pokazali-nagranie,nId,6969022"><img align="left" alt="Rosjanie uderzyli w ukraiński pociąg. Pokazali nagranie" src="https://i.iplsc.com/rosjanie-uderzyli-w-ukrainski-pociag-pokazali-nagranie/000HJR8ACT3XHKHP-C321.jpg" /></a>Siły rosyjskie ponownie zaatakowały na terytorium Ukrainy. Tym razem ich celem stał się pociąg, którym, jak podaje rosyjskie Ministerstwo Obrony, przewożono amunicję. Nagranie z uderzenia trafiło do sieci, początkowo widać na nim pożar, a po chwili wagon eksploduje.</p><br clear="all" />

## Były prezydent Francji zaskakuje. Mówi o referendach w okupowanej Ukrainie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-byly-prezydent-francji-zaskakuje-mowi-o-referendach-w-okupow,nId,6968988](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-byly-prezydent-francji-zaskakuje-mowi-o-referendach-w-okupow,nId,6968988)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T15:57:07+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-byly-prezydent-francji-zaskakuje-mowi-o-referendach-w-okupow,nId,6968988"><img align="left" alt="Były prezydent Francji zaskakuje. Mówi o referendach w okupowanej Ukrainie" src="https://i.iplsc.com/byly-prezydent-francji-zaskakuje-mowi-o-referendach-w-okupow/00099LP3AVLBS1T3-C321.jpg" /></a>Rosja i Ukraina powinny znaleźć kompromis, żeby doprowadzić do zakończenia wojny - powiedział w wywiadzie dla francuskiego dziennika &quot;Le Figaro&quot; były francuski prezydent Nicolas Sarkozy. Francuski polityk stwierdził również, że na terytoriach okupowanych obecnie przez Rosję powinny zostać zorganizowane referenda.  </p><br clear="all" />

## Klamka zapadła. Sejm zdecydował ws. referendum
 - [https://wydarzenia.interia.pl/kraj/news-klamka-zapadla-sejm-zdecydowal-ws-referendum,nId,6969003](https://wydarzenia.interia.pl/kraj/news-klamka-zapadla-sejm-zdecydowal-ws-referendum,nId,6969003)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T15:45:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-klamka-zapadla-sejm-zdecydowal-ws-referendum,nId,6969003"><img align="left" alt="Klamka zapadła. Sejm zdecydował ws. referendum" src="https://i.iplsc.com/klamka-zapadla-sejm-zdecydowal-ws-referendum/000HJRGYQYL3O7X5-C321.jpg" /></a>15 października - w dniu wyborów parlamentarnych - odbędzie się ogólnokrajowe referendum. Zgodę wyraził w czwartek Sejm. Uchwała w tej sprawie wkrótce trafi do Dziennika Ustaw. </p><br clear="all" />

## Zbigniew Ziobro odwołał kolejnego prokuratora. W tle nękanie sąsiadów
 - [https://wydarzenia.interia.pl/podkarpackie/news-zbigniew-ziobro-odwolal-kolejnego-prokuratora-w-tle-nekanie-,nId,6968992](https://wydarzenia.interia.pl/podkarpackie/news-zbigniew-ziobro-odwolal-kolejnego-prokuratora-w-tle-nekanie-,nId,6968992)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T15:28:12+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-zbigniew-ziobro-odwolal-kolejnego-prokuratora-w-tle-nekanie-,nId,6968992"><img align="left" alt="Zbigniew Ziobro odwołał kolejnego prokuratora. W tle nękanie sąsiadów" src="https://i.iplsc.com/zbigniew-ziobro-odwolal-kolejnego-prokuratora-w-tle-nekanie/000HJR220YT7MHJC-C321.jpg" /></a>Minister sprawiedliwości i prokurator generalny Zbigniew Ziobro zdecydował o odwołaniu ze stanowiska prokuratora rejonowego w Dębicy. Jak przekazał dział prasowy Prokuratury Krajowej, odwołanie z funkcji ma związek z licznymi zaniedbaniami dotyczącymi postępowań procesowych w gminie Czarna. Mowa o sprawach uporczywego nękania sąsiadów - incydenty były zgłaszane kilka razy, ale dopiero po interwencji Prokuratury Generalnej podjęto w tym zakresie odpowiednie działania.</p><br clear="all" />

## Ogólnokrajowe referendum 15 października. Sejm idzie jak burza
 - [https://wydarzenia.interia.pl/kraj/news-ogolnokrajowe-referendum-15-pazdziernika-sejm-idzie-jak-burz,nId,6968882](https://wydarzenia.interia.pl/kraj/news-ogolnokrajowe-referendum-15-pazdziernika-sejm-idzie-jak-burz,nId,6968882)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T14:59:59+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ogolnokrajowe-referendum-15-pazdziernika-sejm-idzie-jak-burz,nId,6968882"><img align="left" alt="Ogólnokrajowe referendum 15 października. Sejm idzie jak burza" src="https://i.iplsc.com/ogolnokrajowe-referendum-15-pazdziernika-sejm-idzie-jak-burz/000HJR460GCDU434-C321.jpg" /></a>Sejm, w rekordowym tempie przeszedł przez pierwsze czytanie nad ustawą o zorganizowaniu ogólnokrajowego referendum w dniu wyborów parlamentarnych 15 października. </p><br clear="all" />

## Mężczyźni chętniej jadą do biura. "Chcą uciec od rodziny"
 - [https://wydarzenia.interia.pl/zagranica/news-mezczyzni-chetniej-jada-do-biura-chca-uciec-od-rodziny,nId,6968983](https://wydarzenia.interia.pl/zagranica/news-mezczyzni-chetniej-jada-do-biura-chca-uciec-od-rodziny,nId,6968983)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T14:30:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mezczyzni-chetniej-jada-do-biura-chca-uciec-od-rodziny,nId,6968983"><img align="left" alt="Mężczyźni chętniej jadą do biura. &quot;Chcą uciec od rodziny&quot;" src="https://i.iplsc.com/mezczyzni-chetniej-jada-do-biura-chca-uciec-od-rodziny/000HJQZXESSKK4XA-C321.jpg" /></a>Darmowe artykuły papiernicze, lepsza kawa, możliwość konwersacji, a także... ucieczka od rodziny - to tylko niektóre z powodów, które wskazywali ankietowani w Wielkiej Brytanii na pytanie dlaczego preferują pracę stacjonarną. Z badań jednoznacznie wynika, że częściej na powrót do biura decydują się mężczyźni. Kobiety z kolei zaoszczędzony czas z reguły wykorzystują na uporządkowanie domu.</p><br clear="all" />

## Janusz Kowalski ostro do opozycji. "Wy nawet nie udajecie"
 - [https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-ostro-do-opozycji-wy-nawet-nie-udajecie,nId,6968929](https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-ostro-do-opozycji-wy-nawet-nie-udajecie,nId,6968929)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T14:17:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janusz-kowalski-ostro-do-opozycji-wy-nawet-nie-udajecie,nId,6968929"><img align="left" alt="Janusz Kowalski ostro do opozycji. &quot;Wy nawet nie udajecie&quot;" src="https://i.iplsc.com/janusz-kowalski-ostro-do-opozycji-wy-nawet-nie-udajecie/000HJQ4NW658NOG9-C321.jpg" /></a>- Wy nawet nie udajecie, wy stoicie murem za Niemcami, za Berlinem, za Manfredem Weberem - grzmiał z sejmowej mównicy polityk Suwerennej Polski Janusz Kowalski w stronę opozycji. Następnie dodał, że Platforma Obywatelska jest &quot;partią stuprocentowo niemiecką&quot; i tak też &quot;przejdą do historii w podręczniku do HiT&quot;. We wtorek na stronie Sejmu pojawił się projekt uchwały autorstwa partii rządzącej, dotyczący obcej ingerencji w proces wyborczy w naszym kraju.</p><br clear="all" />

## Krzysztof Lisiecki nie żyje. Miał 68 lat
 - [https://wydarzenia.interia.pl/lodzkie/news-krzysztof-lisiecki-nie-zyje-mial-68-lat,nId,6968892](https://wydarzenia.interia.pl/lodzkie/news-krzysztof-lisiecki-nie-zyje-mial-68-lat,nId,6968892)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T13:37:03+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-krzysztof-lisiecki-nie-zyje-mial-68-lat,nId,6968892"><img align="left" alt="Krzysztof Lisiecki nie żyje. Miał 68 lat" src="https://i.iplsc.com/krzysztof-lisiecki-nie-zyje-mial-68-lat/000HJQ3EAL5XCWK3-C321.jpg" /></a>Nie żyje znany sieradzki dziennikarz Krzysztof Lisiecki. Mężczyzna przez lata związany był m.in. z Radiem Łódź. Dziennikarz odszedł w środę popołudniu w wieku 68 lat.  </p><br clear="all" />

## Wulgarnie zwrócił się do Chińczyków. Teraz ma naprawić relacje z Pekinem
 - [https://wydarzenia.interia.pl/zagranica/news-wulgarnie-zwrocil-sie-do-chinczykow-teraz-ma-naprawic-relacj,nId,6968890](https://wydarzenia.interia.pl/zagranica/news-wulgarnie-zwrocil-sie-do-chinczykow-teraz-ma-naprawic-relacj,nId,6968890)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T13:16:04+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wulgarnie-zwrocil-sie-do-chinczykow-teraz-ma-naprawic-relacj,nId,6968890"><img align="left" alt="Wulgarnie zwrócił się do Chińczyków. Teraz ma naprawić relacje z Pekinem" src="https://i.iplsc.com/wulgarnie-zwrocil-sie-do-chinczykow-teraz-ma-naprawic-relacj/000HJPWVW51PG6HW-C321.jpg" /></a>Były minister spraw zagranicznych Filipin - znany z nieparlamentarnego języka, jakiego użył wobec Chin - został specjalnym wysłannikiem filipińskiego prezydenta... do Pekinu. Ma rozmawiać o załagodzeniu sporu na Morzu Południowochińskim.</p><br clear="all" />

## Ścigali go z Polski do Niemiec. W busie wiózł osiemnaście osób
 - [https://wydarzenia.interia.pl/kraj/news-scigali-go-z-polski-do-niemiec-w-busie-wiozl-osiemnascie-oso,nId,6968913](https://wydarzenia.interia.pl/kraj/news-scigali-go-z-polski-do-niemiec-w-busie-wiozl-osiemnascie-oso,nId,6968913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T13:09:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-scigali-go-z-polski-do-niemiec-w-busie-wiozl-osiemnascie-oso,nId,6968913"><img align="left" alt="Ścigali go z Polski do Niemiec. W busie wiózł osiemnaście osób" src="https://i.iplsc.com/scigali-go-z-polski-do-niemiec-w-busie-wiozl-osiemnascie-oso/000HJPWYK8FH436N-C321.jpg" /></a>Kierowca dostawczego busa nie zatrzymał się do kontroli, zignorował służby i z dużą prędkością zaczął oddalać się w kierunku granicy. Strażnicy graniczni ze Zgorzelca podjęli pościg, a za uciekinierem wjechali na terytorium Niemiec. Gdy ostatecznie kierowca porzucił swój pojazd, okazało się, że przewoził kilkunastu cudzoziemców.</p><br clear="all" />

## Polscy pseudokibice zatrzymani w Czechach. Jechali na mecz
 - [https://wydarzenia.interia.pl/zagranica/news-polscy-pseudokibice-zatrzymani-w-czechach-jechali-na-mecz,nId,6968840](https://wydarzenia.interia.pl/zagranica/news-polscy-pseudokibice-zatrzymani-w-czechach-jechali-na-mecz,nId,6968840)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T13:08:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polscy-pseudokibice-zatrzymani-w-czechach-jechali-na-mecz,nId,6968840"><img align="left" alt="Polscy pseudokibice zatrzymani w Czechach. Jechali na mecz" src="https://i.iplsc.com/polscy-pseudokibice-zatrzymani-w-czechach-jechali-na-mecz/000HJPTP8D3FTW4T-C321.jpg" /></a>Polskich kibiców Lecha Poznań, zmierzających na mecz wyjazdowy zespołu do słowackiej Trnawy, spotkała niemiła niespodzianka. W drodze na wydarzenie postanowili zmierzyć się we własnej &quot;bitwie&quot; w pobliżu czeskiego Jistebníka w kraju morawsko-śląskim. Szykujących się do starcia chuliganów przyłapała czeska policja. Skontrolowano 168 osób. </p><br clear="all" />

## Szwecja podniosła stopień zagrożenia. W kraju niespokojnie
 - [https://wydarzenia.interia.pl/zagranica/news-szwecja-podniosla-stopien-zagrozenia-w-kraju-niespokojnie,nId,6968848](https://wydarzenia.interia.pl/zagranica/news-szwecja-podniosla-stopien-zagrozenia-w-kraju-niespokojnie,nId,6968848)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T12:56:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szwecja-podniosla-stopien-zagrozenia-w-kraju-niespokojnie,nId,6968848"><img align="left" alt="Szwecja podniosła stopień zagrożenia. W kraju niespokojnie" src="https://i.iplsc.com/szwecja-podniosla-stopien-zagrozenia-w-kraju-niespokojnie/000HJPPO1KR4A6YD-C321.jpg" /></a>Szwecja podniosła stopień zagrożenia terrorystycznego z trzeciego do czwartego stopnia - przekazuje agencja Reutera w czwartek. To pokłosie palenia świętej księgi Islamu, do którego dochodziło w ostatnich tygodniach w tym skandynawskim kraju. Podnosząc stopień z trzeciego na czwarty w pięciostopniowej skali poinformowano, że odzwierciedla on &quot;wysokie zagrożenie&quot;.</p><br clear="all" />

## Samolot runął na drogę, wielu zginęło. Tragiczny wypadek w Malezji
 - [https://wydarzenia.interia.pl/zagranica/news-samolot-runal-na-droge-wielu-zginelo-tragiczny-wypadek-w-mal,nId,6968802](https://wydarzenia.interia.pl/zagranica/news-samolot-runal-na-droge-wielu-zginelo-tragiczny-wypadek-w-mal,nId,6968802)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T12:20:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-samolot-runal-na-droge-wielu-zginelo-tragiczny-wypadek-w-mal,nId,6968802"><img align="left" alt="Samolot runął na drogę, wielu zginęło. Tragiczny wypadek w Malezji" src="https://i.iplsc.com/samolot-runal-na-droge-wielu-zginelo-tragiczny-wypadek-w-mal/000HJPASUP0XMCWH-C321.jpg" /></a>Mały samolot runął na drogę niedaleko lotniska w Malezji, uderzając w samochód oraz motocykl. Kierowcy obu staranowanych pojazdów nie żyją. Zginęło co najmniej 10 osób, w tym cała załoga samolotu. Na miejscu unoszą się kłęby dymu. Świadkowie zdarzenia mówili o poczuciu bezradności oraz przerażającym krzyku płonącego motocyklisty.</p><br clear="all" />

## Białoruskie manewry przy granicy z Polską. Zrzucono spadochroniarzy
 - [https://wydarzenia.interia.pl/zagranica/news-bialoruskie-manewry-przy-granicy-z-polska-zrzucono-spadochro,nId,6968839](https://wydarzenia.interia.pl/zagranica/news-bialoruskie-manewry-przy-granicy-z-polska-zrzucono-spadochro,nId,6968839)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T12:06:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialoruskie-manewry-przy-granicy-z-polska-zrzucono-spadochro,nId,6968839"><img align="left" alt="Białoruskie manewry przy granicy z Polską. Zrzucono spadochroniarzy" src="https://i.iplsc.com/bialoruskie-manewry-przy-granicy-z-polska-zrzucono-spadochro/000HJPM9Y6YBQPEU-C321.jpg" /></a>Białoruski śmigłowiec przeleciał w pobliżu polskiej granicy i zrzucił skoczków spadochronowych. Z treści oficjalnego komunikatu resortu wynika, że ćwiczenie desantu to element pięciodniowego szkolenia oficerów w bazie w rejonie Brześcia. W tej samej jednostce szkolenia prowadzi Grupa Wagnera.</p><br clear="all" />

## Stracona dekada, tykająca bomba. Czarne chmury nad gospodarczym mocarstwem
 - [https://wydarzenia.interia.pl/zagranica/news-stracona-dekada-tykajaca-bomba-czarne-chmury-nad-gospodarczy,nId,6968800](https://wydarzenia.interia.pl/zagranica/news-stracona-dekada-tykajaca-bomba-czarne-chmury-nad-gospodarczy,nId,6968800)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T11:56:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stracona-dekada-tykajaca-bomba-czarne-chmury-nad-gospodarczy,nId,6968800"><img align="left" alt="Stracona dekada, tykająca bomba. Czarne chmury nad gospodarczym mocarstwem" src="https://i.iplsc.com/stracona-dekada-tykajaca-bomba-czarne-chmury-nad-gospodarczy/000HJPE1CE226MNF-C321.jpg" /></a>Zła passa chińskiej gospodarki trwa. Do wielu niepokojących danych z ostatnich miesięcy teraz doszły te dotyczące deflacji. Wbrew pozorom, realny spadek cen rok do roku wcale nie jest dla chińskich władz powodem do zadowolenia. Zarówno chińscy, jak i zachodni ekonomiści biją na alarm: chińska gospodarka hamuje i wpada w stagnację. Sytuacja jest na tyle poważna, że w kontekście Chin już mówi się o widmie &quot;straconej dekady&quot;, czyli tego, co z podobnych powodów spotkało Japonię w latach 90.</p><br clear="all" />

## Niemcy kupują od Izraela system przeciwrakietowy. Największa umowa w historii
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-kupuja-od-izraela-system-przeciwrakietowy-najwieksza-,nId,6968753](https://wydarzenia.interia.pl/zagranica/news-niemcy-kupuja-od-izraela-system-przeciwrakietowy-najwieksza-,nId,6968753)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T11:56:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-kupuja-od-izraela-system-przeciwrakietowy-najwieksza-,nId,6968753"><img align="left" alt="Niemcy kupują od Izraela system przeciwrakietowy. Największa umowa w historii" src="https://i.iplsc.com/niemcy-kupuja-od-izraela-system-przeciwrakietowy-najwieksza/000HJPAWLNHGSP4H-C321.jpg" /></a>Izrael sprzeda Niemcom system obrony przeciwrakietowej Arrow-3. Chodzi o największą w historii bliskowschodniego państwa transakcję zbrojeniową. Negocjacje między Tel-Awiwem i Berlinem trwały od miesięcy, jednak dopiero teraz Stany Zjednoczone wyraziły zgodę na sprzedaż. </p><br clear="all" />

## Internauci zachwyceni: To zwierzę myje się zupełnie jak człowiek
 - [https://wydarzenia.interia.pl/kraj/news-internauci-zachwyceni-to-zwierze-myje-sie-zupelnie-jak-czlow,nId,6968832](https://wydarzenia.interia.pl/kraj/news-internauci-zachwyceni-to-zwierze-myje-sie-zupelnie-jak-czlow,nId,6968832)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T11:38:08+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-internauci-zachwyceni-to-zwierze-myje-sie-zupelnie-jak-czlow,nId,6968832"><img align="left" alt="Internauci zachwyceni: To zwierzę myje się zupełnie jak człowiek" src="https://i.iplsc.com/internauci-zachwyceni-to-zwierze-myje-sie-zupelnie-jak-czlow/000HJPETQ94PCLXY-C321.jpg" /></a>Miłośnik przyrody nagrał bobra kąpiącego się w rzece w wyjątkowy sposób. Zwierzę zachowuje się niemal zupełnie jak człowiek. Widać również, że ciepła kąpiel sprawia mu wyraźną frajdę. Dowiedz się, jak powstał ten niezwykły film. Obejrzyj jedyne w swoim rodzaju nagranie sympatycznego zwierzęcia wykonane przez miłośnika przyrody.</p><br clear="all" />

## Rekordzista ze Słubic. Uzbierał 241 punktów karnych, w aucie niemowlę
 - [https://wydarzenia.interia.pl/lubuskie/news-rekordzista-ze-slubic-uzbieral-241-punktow-karnych-w-aucie-n,nId,6968786](https://wydarzenia.interia.pl/lubuskie/news-rekordzista-ze-slubic-uzbieral-241-punktow-karnych-w-aucie-n,nId,6968786)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T11:19:13+00:00

<p><a href="https://wydarzenia.interia.pl/lubuskie/news-rekordzista-ze-slubic-uzbieral-241-punktow-karnych-w-aucie-n,nId,6968786"><img align="left" alt="Rekordzista ze Słubic. Uzbierał 241 punktów karnych, w aucie niemowlę" src="https://i.iplsc.com/rekordzista-ze-slubic-uzbieral-241-punktow-karnych-w-aucie-n/000HJP9C04KJX5W6-C321.jpg" /></a>Gdy policjanci ze Słubic zobaczyli za kierownicą BMW znanego im 20-latka bez uprawnień do prowadzenia pojazdów, nakazali mu zatrzymanie. Ten jednak rozpoczął ucieczkę. Nie zważając na innych uczestników ruchu drogowego pędził po ulicach miasta, powodując 30 wykroczeń drogowych i uzyskując w sumie... 241 punktów karnych. Po pościgu okazało się także, że w samochodzie przewoził niemowlę.</p><br clear="all" />

## Tragiczny wypadek na Podkarpaciu. Jedna osoba zginęła, cztery są ranne
 - [https://wydarzenia.interia.pl/podkarpackie/news-tragiczny-wypadek-na-podkarpaciu-jedna-osoba-zginela-cztery-,nId,6968814](https://wydarzenia.interia.pl/podkarpackie/news-tragiczny-wypadek-na-podkarpaciu-jedna-osoba-zginela-cztery-,nId,6968814)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T11:16:02+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-tragiczny-wypadek-na-podkarpaciu-jedna-osoba-zginela-cztery-,nId,6968814"><img align="left" alt="Tragiczny wypadek na Podkarpaciu. Jedna osoba zginęła, cztery są ranne" src="https://i.iplsc.com/tragiczny-wypadek-na-podkarpaciu-jedna-osoba-zginela-cztery/000HJPC263YJTKC3-C321.jpg" /></a>Jedna osoba nie żyje, a cztery zostały ranne po czołowym zderzeniu dwóch aut w miejscowości Mała. Ofiara to 22-latek, z kolei wśród rannych jest dwoje małych dzieci.

</p><br clear="all" />

## "Bolesna prawda dla Ukrainy". Rosja chwali amerykańskiego wojskowego
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bolesna-prawda-dla-ukrainy-rosja-chwali-amerykanskiego-wojsk,nId,6968796](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bolesna-prawda-dla-ukrainy-rosja-chwali-amerykanskiego-wojsk,nId,6968796)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T10:59:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-bolesna-prawda-dla-ukrainy-rosja-chwali-amerykanskiego-wojsk,nId,6968796"><img align="left" alt="&quot;Bolesna prawda dla Ukrainy&quot;. Rosja chwali amerykańskiego wojskowego" src="https://i.iplsc.com/bolesna-prawda-dla-ukrainy-rosja-chwali-amerykanskiego-wojsk/000HJP96SCCPHCAC-C321.jpg" /></a>Nie istnieje racjonalna droga do zwycięstwa Ukrainy nad Rosją na froncie - twierdzi Daniel L. Davis podpułkownik US Army w stanie spoczynku i współpracownik think tanku Defense Priorities. Tezy wojskowego o nieskuteczności kontrofensywy i konieczności &quot;rozpoczęcia negocjacji&quot; podchwyciła rosyjska propaganda.</p><br clear="all" />

## Mimo wojny w Ukrainie Rosja się bogaci. Europa i USA tracą biliony
 - [https://wydarzenia.interia.pl/zagranica/news-mimo-wojny-w-ukrainie-rosja-sie-bogaci-europa-i-usa-traca-bi,nId,6968791](https://wydarzenia.interia.pl/zagranica/news-mimo-wojny-w-ukrainie-rosja-sie-bogaci-europa-i-usa-traca-bi,nId,6968791)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T10:52:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mimo-wojny-w-ukrainie-rosja-sie-bogaci-europa-i-usa-traca-bi,nId,6968791"><img align="left" alt="Mimo wojny w Ukrainie Rosja się bogaci. Europa i USA tracą biliony" src="https://i.iplsc.com/mimo-wojny-w-ukrainie-rosja-sie-bogaci-europa-i-usa-traca-bi/000HJPAGRBDU7GP9-C321.jpg" /></a>Mimo trwającej od ponad roku wojny w Ukrainie, Rosja wzbogaciła się w 2022 roku o 600 mld dolarów. Wzrosła również znacząco liczba milionerów w tym kraju. Tymczasem Stany Zjednoczone i Europa straciły biliony dolarów. </p><br clear="all" />

## Nie żyje rosyjski generał. Druga śmierć wśród dowódców w ciągu kilku dni
 - [https://wydarzenia.interia.pl/zagranica/news-nie-zyje-rosyjski-general-druga-smierc-wsrod-dowodcow-w-ciag,nId,6968653](https://wydarzenia.interia.pl/zagranica/news-nie-zyje-rosyjski-general-druga-smierc-wsrod-dowodcow-w-ciag,nId,6968653)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T10:29:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-zyje-rosyjski-general-druga-smierc-wsrod-dowodcow-w-ciag,nId,6968653"><img align="left" alt="Nie żyje rosyjski generał. Druga śmierć wśród dowódców w ciągu kilku dni" src="https://i.iplsc.com/nie-zyje-rosyjski-general-druga-smierc-wsrod-dowodcow-w-ciag/000HJOKBNAGGXBT6-C321.jpg" /></a>Nie żyje Giennadij Łopyriew, generał Federalnej Służby Bezpieczeństwa Federacji Rosyjskiej, który w ostatnich latach przebywał w kolonii karnej za przyjmowanie łapówek. Łopyriew miał być &quot;strażnikiem tajemnic budowy pałacu Putina w Gelendżyku&quot;, wcześniej nie borykał się z żadnymi konkretnymi problemami zdrowotnymi. Jego syn podejrzewa, że mógł on zostać otruty, jako że wkrótce kwalifikowałby się do zwolnienia warunkowego.</p><br clear="all" />

## Kanada: Ogień coraz bliżej. Ewakuują całe miasto
 - [https://wydarzenia.interia.pl/zagranica/news-kanada-ogien-coraz-blizej-ewakuuja-cale-miasto,nId,6968734](https://wydarzenia.interia.pl/zagranica/news-kanada-ogien-coraz-blizej-ewakuuja-cale-miasto,nId,6968734)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T09:47:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kanada-ogien-coraz-blizej-ewakuuja-cale-miasto,nId,6968734"><img align="left" alt="Kanada: Ogień coraz bliżej. Ewakuują całe miasto" src="https://i.iplsc.com/kanada-ogien-coraz-blizej-ewakuuja-cale-miasto/000HJOWDL5TSJBWP-C321.jpg" /></a>Największe miasto Terytoriów Północno-Zachodnich w Kanadzie zostanie ewakuowane w najbliższych godzinach. Z zagrożonego pożarem lasów miasta Yellowknife mają wyjechać wszyscy mieszkańcy. To największa ewakuacja w historii tych terenów. O pomocy w akcji zapewnił premier Kanady. Wywiezienie tysięcy osób jest prawdziwym wyzwaniem, ponieważ na bezpieczne południe obecnie prowadzi tylko jedna droga.</p><br clear="all" />

## Duży pożar w Rosji. Płoną zakłady metalurgiczne
 - [https://wydarzenia.interia.pl/zagranica/news-duzy-pozar-w-rosji-plona-zaklady-metalurgiczne,nId,6968633](https://wydarzenia.interia.pl/zagranica/news-duzy-pozar-w-rosji-plona-zaklady-metalurgiczne,nId,6968633)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T09:36:03+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-duzy-pozar-w-rosji-plona-zaklady-metalurgiczne,nId,6968633"><img align="left" alt="Duży pożar w Rosji. Płoną zakłady metalurgiczne" src="https://i.iplsc.com/duzy-pozar-w-rosji-plona-zaklady-metalurgiczne/000HJOSGGLOKR8UM-C321.jpg" /></a>Płoną zakłady metalurgiczne w rosyjskim Wołgogradzie. W sieci pojawiły się nagrania. To już kolejny pożar w Rosji w ostatnich dniach. </p><br clear="all" />

## Miał być wspólny start, Michał Kołodziejczak dokonał wolty. "Oszukał nas"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-mial-byc-wspolny-start-michal-kolodziejczak-dokonal-wolty-os,nId,6968687](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-mial-byc-wspolny-start-michal-kolodziejczak-dokonal-wolty-os,nId,6968687)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T09:23:26+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-mial-byc-wspolny-start-michal-kolodziejczak-dokonal-wolty-os,nId,6968687"><img align="left" alt="Miał być wspólny start, Michał Kołodziejczak dokonał wolty. &quot;Oszukał nas&quot;" src="https://i.iplsc.com/mial-byc-wspolny-start-michal-kolodziejczak-dokonal-wolty-os/000HJOP1NVJ0E21Y-C321.jpg" /></a>- Michał Kołodziejczak nas oszukał. Uczciwym podejściem byłoby przekazanie informacji, że kończymy współpracę, przestajemy zbierać podpisy, mówimy ludziom. Widać jednak, że sposób, w jakim zostało to zrobione, niewielu przypadł do gustu. A to bardzo delikatne określenie - mówi w rozmowie z Interią Marek Materek, który jeszcze niedawno miał startować w wyborach parlamentarnych w sojuszu z AgroUnią. W środę lider ugrupowania wystąpił na Radzie Krajowej Platformy Obywatelskiej i przekazał Interii, że &quot;na listach KO pojawią się również inni...</p><br clear="all" />

## Rosjanie mają dość. Przyjęli zupełnie nową taktykę
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-maja-dosc-przyjeli-zupelnie-nowa-taktyke,nId,6968708](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-maja-dosc-przyjeli-zupelnie-nowa-taktyke,nId,6968708)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T09:21:27+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-maja-dosc-przyjeli-zupelnie-nowa-taktyke,nId,6968708"><img align="left" alt="Rosjanie mają dość. Przyjęli zupełnie nową taktykę" src="https://i.iplsc.com/rosjanie-maja-dosc-przyjeli-zupelnie-nowa-taktyke/000HJORX0RV65AY2-C321.jpg" /></a>Bazy lotnicze, pasy startowe, ośrodki szkolenia w zachodniej Ukrainie - to według źródeł &quot;Financial Times&quot; nowe cele rosyjskiej armii. Zmiana taktyki wymusza na ukraińskich pilotach ciągłe kursowanie między różnymi punktami. Uderzenia okupantów mają jeden cel - chcą zapobiec kolejnym atakom na Półwysep Krymski.</p><br clear="all" />

## Pakt senacki. Znamy nazwiska kandydatów PSL
 - [https://wydarzenia.interia.pl/kraj/news-pakt-senacki-znamy-nazwiska-kandydatow-psl,nId,6968681](https://wydarzenia.interia.pl/kraj/news-pakt-senacki-znamy-nazwiska-kandydatow-psl,nId,6968681)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T08:40:57+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pakt-senacki-znamy-nazwiska-kandydatow-psl,nId,6968681"><img align="left" alt="Pakt senacki. Znamy nazwiska kandydatów PSL" src="https://i.iplsc.com/pakt-senacki-znamy-nazwiska-kandydatow-psl/000HJOPGL5YD0XQU-C321.jpg" /></a>Dwadzieścia nazwisk zawiera lista kandydatów PSL do Senatu, do jakiej dotarła Interia. Wejdą oni w skład tzw. paktu senackiego, który zawarły KO, Polska 2050, Nowa Lewica, PSL oraz Ruch Samorządowy &quot;Tak! Dla Polski&quot;.</p><br clear="all" />

## Debata nad referendum. M. Kierwiński wskazał na ławy rządowe
 - [https://wydarzenia.interia.pl/kraj/news-debata-nad-referendum-m-kierwinski-wskazal-na-lawy-rzadowe,nId,6968630](https://wydarzenia.interia.pl/kraj/news-debata-nad-referendum-m-kierwinski-wskazal-na-lawy-rzadowe,nId,6968630)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T08:13:52+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-debata-nad-referendum-m-kierwinski-wskazal-na-lawy-rzadowe,nId,6968630"><img align="left" alt="Debata nad referendum. M. Kierwiński wskazał na ławy rządowe " src="https://i.iplsc.com/debata-nad-referendum-m-kierwinski-wskazal-na-lawy-rzadowe/000HJOEFQ0QOAF7R-C321.jpg" /></a>Podczas debaty w sprawie wniosku rządu o przeprowadzenie referendum 15 października głos zabrał poseł KO Marcin Kierwiński. Wskazywał na puste ławy rządowe. - Jarosław Kaczyński i Mateusz Morawiecki mogli przyjść na debatę - przekonywał. Oskarżał rządzących o &quot;gigantyczny nepotyzm i dokonywanie prywatyzacji na rzecz własnych ludzi&quot; oraz podważał sens zaproponowanych pytań referendalnych. Parlamentarzysta złożył wniosek o odrzucenie propozycji przeprowadzenia referendum ogólnokrajowego.</p><br clear="all" />

## Myślał, że to normalna kontrola. Niemiecki policjant okradł kierowcę
 - [https://wydarzenia.interia.pl/zagranica/news-myslal-ze-to-normalna-kontrola-niemiecki-policjant-okradl-ki,nId,6968636](https://wydarzenia.interia.pl/zagranica/news-myslal-ze-to-normalna-kontrola-niemiecki-policjant-okradl-ki,nId,6968636)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T07:49:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-myslal-ze-to-normalna-kontrola-niemiecki-policjant-okradl-ki,nId,6968636"><img align="left" alt="Myślał, że to normalna kontrola. Niemiecki policjant okradł kierowcę" src="https://i.iplsc.com/myslal-ze-to-normalna-kontrola-niemiecki-policjant-okradl-ki/000HJODW5W51NAGG-C321.jpg" /></a>Kierowca zatrzymany przez policjanta na niemieckiej autostradzie był przekonany, że czeka go rutynowa kontrola. Chwilę później 62-latek został zakuty w kajdanki i wsadzony do radiowozu, a mundurowy przeszukał jego auto. Po &quot;interwencji&quot; z pojazdu zniknęły telefony komórkowe i ponad 50 tys. euro. Sprawą kradzieży zajęła się prokuratura, która przeszukała mieszkanie funkcjonariusza.</p><br clear="all" />

## Miedwiediew uderza w Zachód: Zarabiają na wojnie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-miedwiediew-uderza-w-zachod-zarabiaja-na-wojnie,nId,6968590](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-miedwiediew-uderza-w-zachod-zarabiaja-na-wojnie,nId,6968590)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T07:45:03+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-miedwiediew-uderza-w-zachod-zarabiaja-na-wojnie,nId,6968590"><img align="left" alt="Miedwiediew uderza w Zachód: Zarabiają na wojnie" src="https://i.iplsc.com/miedwiediew-uderza-w-zachod-zarabiaja-na-wojnie/000GDVM206VVRA3K-C321.jpg" /></a>Były prezydent Rosji Dmitrij Miedwiediew odwiedził wystawę zachodniego sprzętu przejętego przez Rosjan podczas działań wojennych i skomentował sytuację na froncie ukraińskim. Oskarżył Zachód o przebiegłość i robienie interesów na wojnie. - Osiągają gigantyczne zyski, dostarczając swój sprzęt Ukrainie. Zarabiają na tej wojnie - wskazywał polityk. Podkreślił, że przeciwnicy Kremla nie chcą rozmów pokojowych w sprawie zakończenie konfliktu.</p><br clear="all" />

## Masowo wychodzą na ulice. Niemiecka skrajna prawica na fali wznoszącej
 - [https://wydarzenia.interia.pl/zagranica/news-masowo-wychodza-na-ulice-niemiecka-skrajna-prawica-na-fali-w,nId,6968551](https://wydarzenia.interia.pl/zagranica/news-masowo-wychodza-na-ulice-niemiecka-skrajna-prawica-na-fali-w,nId,6968551)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T07:39:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-masowo-wychodza-na-ulice-niemiecka-skrajna-prawica-na-fali-w,nId,6968551"><img align="left" alt="Masowo wychodzą na ulice. Niemiecka skrajna prawica na fali wznoszącej" src="https://i.iplsc.com/masowo-wychodza-na-ulice-niemiecka-skrajna-prawica-na-fali-w/000HJNSES335J9ME-C321.jpg" /></a>Niemiecka skrajna prawica znacznie częściej wychodzi na ulice miast i protestuje - wynika z danych opublikowanych przez Federalne Ministerstwo Spraw Wewnętrznych. Demonstranci sprzeciwiają się polityce uchodźczej i podwyżce cen, chcą też zniesienia sankcji nałożonych na Rosję. - Rok po pandemii COVID-19 siła mobilizacyjna skrajnej prawicy ponownie ogromnie wzrasta - alarmuje posłanka niemieckiej Lewicy Petra Pau.</p><br clear="all" />

## Debata nad wnioskiem o referendum. "Dlaczego się pan drze jak głupi?"
 - [https://wydarzenia.interia.pl/kraj/news-debata-nad-wnioskiem-o-referendum-dlaczego-sie-pan-drze-jak-,nId,6968555](https://wydarzenia.interia.pl/kraj/news-debata-nad-wnioskiem-o-referendum-dlaczego-sie-pan-drze-jak-,nId,6968555)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T07:15:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-debata-nad-wnioskiem-o-referendum-dlaczego-sie-pan-drze-jak-,nId,6968555"><img align="left" alt="Debata nad wnioskiem o referendum. &quot;Dlaczego się pan drze jak głupi?&quot;" src="https://i.iplsc.com/debata-nad-wnioskiem-o-referendum-dlaczego-sie-pan-drze-jak/000HJO8PF35H0L1A-C321.jpg" /></a>- Od PSL przez Platformę Obywatelską po Lewicę kwestionujecie zasadność tego referendum, wyszydzacie je, bojkotuje, a wasz guru – zastępca Webera w Polsce, Donald Tusk – próbuje je unieważniać zanim jeszcze  doszło do skutku. A wiecie państwo z jakiego powodu? Bo wszystkie cztery pytania są niezwykle ważne dla narodu polskiego,  jego przyszłości i przyszłości Europy, która jest absolutnie rujnowana przez absurdalną politykę lewackich biurokratycznych elit w Brukseli, zarządzanych przez Niemców - powiedział minister edukacji Przemysław...</p><br clear="all" />

## Sejm przegłosował wniosek ws. referendum. Ruszają prace
 - [https://wydarzenia.interia.pl/kraj/news-sejm-przeglosowal-wniosek-ws-referendum-ruszaja-prace,nId,6968555](https://wydarzenia.interia.pl/kraj/news-sejm-przeglosowal-wniosek-ws-referendum-ruszaja-prace,nId,6968555)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T07:15:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-przeglosowal-wniosek-ws-referendum-ruszaja-prace,nId,6968555"><img align="left" alt="Sejm przegłosował wniosek ws. referendum. Ruszają prace" src="https://i.iplsc.com/sejm-przeglosowal-wniosek-ws-referendum-ruszaja-prace/000HJOP82RN2A9FF-C321.jpg" /></a>Podczas debaty sejmowej, dotyczącej rządowego wniosku o zarządzenie referendum ogólnokrajowego, na sali nie brakowało emocji. Wicemarszałek Sejmu Ryszard Terlecki upomniał jednego z posłów, pytając: &quot;dlaczego drze się jak głupi?&quot;, a posłanka Joanna Senyszyn stwierdziła, że &quot;psim obowiązkiem Terleckiego jest przyjęcie wniosku bez chamskiego pyskowania.&quot; Z kolei do posła KO Radosława Lubczyka krzyczano, by &quot;oddał ferrari&quot;. Po głosowaniu Sejm przyjął rządowy wniosek.</p><br clear="all" />

## Niemcy: Ważne lotnisko zalane. Dziesiątki lotów odwołanych
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-wazne-lotnisko-zalane-dziesiatki-lotow-odwolanych,nId,6968596](https://wydarzenia.interia.pl/zagranica/news-niemcy-wazne-lotnisko-zalane-dziesiatki-lotow-odwolanych,nId,6968596)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T06:56:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-wazne-lotnisko-zalane-dziesiatki-lotow-odwolanych,nId,6968596"><img align="left" alt="Niemcy: Ważne lotnisko zalane. Dziesiątki lotów odwołanych" src="https://i.iplsc.com/niemcy-wazne-lotnisko-zalane-dziesiatki-lotow-odwolanych/000HJO6CMHH1NAHI-C321.jpg" /></a>Potężne burze i ulewy w Niemczech poważnie zakłóciły pracę lotniska we Frankfurcie. Stojąca na pasie startowym woda unieruchomiła samoloty pasażerskie. Kilkadziesiąt lotów trzeba było odwołać. W mediach społecznościowych pojawiły się niezwykłe nagrania ukazujące samoloty, które nie mogły kołować po płycie lotniska. Władze portu lotniczego ostrzegają podróżnych, że utrudnienia w funkcjonowaniu obiektu potrwają również w czwartek.</p><br clear="all" />

## Trąba powietrzna i nawałnice w Łódzkiem. Dziesiątki interwencji strażaków
 - [https://wydarzenia.interia.pl/lodzkie/news-traba-powietrzna-i-nawalnice-w-lodzkiem-dziesiatki-interwenc,nId,6968570](https://wydarzenia.interia.pl/lodzkie/news-traba-powietrzna-i-nawalnice-w-lodzkiem-dziesiatki-interwenc,nId,6968570)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T06:34:02+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-traba-powietrzna-i-nawalnice-w-lodzkiem-dziesiatki-interwenc,nId,6968570"><img align="left" alt="Trąba powietrzna i nawałnice w Łódzkiem. Dziesiątki interwencji strażaków" src="https://i.iplsc.com/traba-powietrzna-i-nawalnice-w-lodzkiem-dziesiatki-interwenc/000HJO1YPCM5TRBB-C321.jpg" /></a>To była trudna noc dla mieszkańców zachodnio-południowych powiatów województwa łódzkiego. Po burzach, które przeszły w nocy nad tymi terenami pozostały zerwane dachy i połamane drzewa. Strażacy musieli interweniować w sumie niemal 50 razy. Najwięcej wyjazdów było koniecznych w powiecie sieradzkim, gdzie przeszła trąba powietrzna. Ostrzeżenia przed burzami w tym rejonie wydano także na czwartek.</p><br clear="all" />

## Ukraina oburzona "warunkiem" wejścia do NATO. USA reagują
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-oburzona-warunkiem-wejscia-do-nato-usa-reaguja,nId,6968558](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-oburzona-warunkiem-wejscia-do-nato-usa-reaguja,nId,6968558)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T06:27:17+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-oburzona-warunkiem-wejscia-do-nato-usa-reaguja,nId,6968558"><img align="left" alt="Ukraina oburzona &quot;warunkiem&quot; wejścia do NATO. USA reagują" src="https://i.iplsc.com/ukraina-oburzona-warunkiem-wejscia-do-nato-usa-reaguja/000HJNYBKSB88GKI-C321.jpg" /></a>Nie trwają żadne rozmowy o ewentualnym przyznaniu Ukrainie członkostwa w NATO w przypadku rezygnacji z części jej terytoriów na rzecz Rosji - powiedział rzecznik Rady Bezpieczeństwa Narodowego John Kirby. Zdementował tym samym słowa szefa kancelarii NATO Stiana Jenssena, który stwierdził, że taka kwestia była podnoszona w Sojuszu. Jego wypowiedź spotkała się z ostrą reakcją Kijowa.</p><br clear="all" />

## Politycy KO przed stacjami metra. Zbierają podpisy
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-politycy-ko-przed-stacjami-metra-zbieraja-podpisy,nId,6968549](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-politycy-ko-przed-stacjami-metra-zbieraja-podpisy,nId,6968549)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T05:57:07+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-politycy-ko-przed-stacjami-metra-zbieraja-podpisy,nId,6968549"><img align="left" alt="Politycy KO przed stacjami metra. Zbierają podpisy" src="https://i.iplsc.com/politycy-ko-przed-stacjami-metra-zbieraja-podpisy/000GNQUKR7Q5GW50-C321.jpg" /></a>- Rusza zbiórka podpisów koalicyjnego komitetu wyborczego Koalicji Obywatelskiej - powiedział w czwartek rano Borys Budka podczas czwartkowego briefingu prasowego przed wejściem do stacji metra Centrum w Warszawie. Dodał, że już teraz dziękuje wszystkim, którzy &quot;zdecydują się udzielić poparcia naszym kandydatom i kandydatkom&quot;, bo &quot;to ważny gest&quot;.</p><br clear="all" />

## Seria kradzieży na cmentarzach. Znikają całe nagrobki
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-seria-kradziezy-na-cmentarzach-znikaja-cale-nagrobki,nId,6968536](https://wydarzenia.interia.pl/dolnoslaskie/news-seria-kradziezy-na-cmentarzach-znikaja-cale-nagrobki,nId,6968536)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T05:33:14+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-seria-kradziezy-na-cmentarzach-znikaja-cale-nagrobki,nId,6968536"><img align="left" alt="Seria kradzieży na cmentarzach. Znikają całe nagrobki" src="https://i.iplsc.com/seria-kradziezy-na-cmentarzach-znikaja-cale-nagrobki/000HJNQ0L3O5NXQU-C321.jpg" /></a>Lubińska policja otrzymała zgłoszenie o kradzieży nagrobków na cmentarzach w trzech pobliskich miejscowościach. Złodzieje zdemontowali płyty nagrobne, a następnie je wynieśli. Funkcjonariusze poszukują sprawców i proszą świadków o kontakt. </p><br clear="all" />

## Pogodowy rollercoaster. Burze, deszcz i upał
 - [https://wydarzenia.interia.pl/kraj/news-pogodowy-rollercoaster-burze-deszcz-i-upal,nId,6968535](https://wydarzenia.interia.pl/kraj/news-pogodowy-rollercoaster-burze-deszcz-i-upal,nId,6968535)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T05:19:22+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogodowy-rollercoaster-burze-deszcz-i-upal,nId,6968535"><img align="left" alt="Pogodowy rollercoaster. Burze, deszcz i upał" src="https://i.iplsc.com/pogodowy-rollercoaster-burze-deszcz-i-upal/000HJNRCYNCT3WE8-C321.jpg" /></a>Upały na razie nie odpuszczą. W czwartek termometry pokażą nawet 32 stopnie we wschodniej części kraju. Na południu i południowym zachodzie nieco ochłody przyniosą deszcze i burze. Noc w części kraju będzie tropikalna, ale też zagrzmi i popada.</p><br clear="all" />

## Zaginięcie eksponatów z British Museum. Zwolniono pracownika placówki
 - [https://wydarzenia.interia.pl/zagranica/news-zaginiecie-eksponatow-z-british-museum-zwolniono-pracownika-,nId,6967203](https://wydarzenia.interia.pl/zagranica/news-zaginiecie-eksponatow-z-british-museum-zwolniono-pracownika-,nId,6967203)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T04:34:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaginiecie-eksponatow-z-british-museum-zwolniono-pracownika-,nId,6967203"><img align="left" alt="Zaginięcie eksponatów z British Museum. Zwolniono pracownika placówki" src="https://i.iplsc.com/zaginiecie-eksponatow-z-british-museum-zwolniono-pracownika/000HJML99C15NT7I-C321.jpg" /></a>Z British Museum zniknęło co najmniej kilka eksponatów, w tym złota biżuteria i klejnoty. Placówka poinformowała, że zwolniła pracownika, który miał być odpowiedzialny za zniknięcie artefaktów. - To bardzo nietypowy incydent - podkreślił dyrektor muzeum Hartwig Fischer.</p><br clear="all" />

## Ponownie zbadali prehistoryczną mumię. Wyniki badań wprawiają w osłupienie
 - [https://wydarzenia.interia.pl/zagranica/news-ponownie-zbadali-prehistoryczna-mumie-wyniki-badan-wprawiaja,nId,6967185](https://wydarzenia.interia.pl/zagranica/news-ponownie-zbadali-prehistoryczna-mumie-wyniki-badan-wprawiaja,nId,6967185)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T04:26:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ponownie-zbadali-prehistoryczna-mumie-wyniki-badan-wprawiaja,nId,6967185"><img align="left" alt="Ponownie zbadali prehistoryczną mumię. Wyniki badań wprawiają w osłupienie" src="https://i.iplsc.com/ponownie-zbadali-prehistoryczna-mumie-wyniki-badan-wprawiaja/000HJMGMSLME5GU0-C321.jpg" /></a>Odkryte we włoskim lodowcu jeszcze w XX wieku szczątki prehistorycznego człowieka naukowcy poddali ponownym badaniom. Jak się okazało, rzucają one całkiem nowe światło na wiele aspektów, bo za pierwszym razem do badań wykorzystano zanieczyszczone próbki DNA. Naukowcy mówią otwarcie, że nie kryli zaskoczenia. Nowe testy pozwoliły zrewidować twierdzenia dotyczące przodków żyjącego ponad 5000 lat temu człowieka, a także koloru jego skóry czy obecności owłosienia.</p><br clear="all" />

## Popularna wśród turystów wyspa w ogniu. "Sytuacja wymknęła się spod kontroli"
 - [https://wydarzenia.interia.pl/zagranica/news-popularna-wsrod-turystow-wyspa-w-ogniu-sytuacja-wymknela-sie,nId,6968532](https://wydarzenia.interia.pl/zagranica/news-popularna-wsrod-turystow-wyspa-w-ogniu-sytuacja-wymknela-sie,nId,6968532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-17T03:46:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-popularna-wsrod-turystow-wyspa-w-ogniu-sytuacja-wymknela-sie,nId,6968532"><img align="left" alt="Popularna wśród turystów wyspa w ogniu. &quot;Sytuacja wymknęła się spod kontroli&quot;" src="https://i.iplsc.com/popularna-wsrod-turystow-wyspa-w-ogniu-sytuacja-wymknela-sie/000HJNOSUEF0QPET-C321.jpg" /></a>Strażacy wspierani przez wojsko oraz ochotników Czerwonego Krzyża walczą z potężnymi pożarami na Teneryfie. Władze alarmują, że sytuacja wymknęła się spod kontroli, zarządzono ewakuację mieszkańców w niektórych gminach. Ogień pojawił się m.in. w rejonie popularnego wśród turystów wulkanu Teide.</p><br clear="all" />

