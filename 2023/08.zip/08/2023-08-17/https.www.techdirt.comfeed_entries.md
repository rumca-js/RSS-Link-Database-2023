# Source:Techdirt, URL:https://www.techdirt.com/feed/, language:en-US

## Sexy Sandwiches: PornHub Goes After Kebab Shop Over Signs, Logos
 - [https://www.techdirt.com/2023/08/17/sexy-sandwiches-pornhub-goes-after-kebab-shop-over-signs-logos/](https://www.techdirt.com/2023/08/17/sexy-sandwiches-pornhub-goes-after-kebab-shop-over-signs-logos/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T22:33:00+00:00

One of the common tests for whether something is trademark infringement is whether or not the public will be confused as to association between the infringer and another trademark owner. This typically comes down to several factors, such as the similarity within the uses and, importantly, whether the two entities compete in the same marketplace. [&#8230;]

## NY Times Considering A Potentially Very Dumb Lawsuit Against OpenAI Because It Learned From NY Times Content
 - [https://www.techdirt.com/2023/08/17/ny-times-considering-a-potentially-very-dumb-lawsuit-against-openai-because-it-learned-from-ny-times-content/](https://www.techdirt.com/2023/08/17/ny-times-considering-a-potentially-very-dumb-lawsuit-against-openai-because-it-learned-from-ny-times-content/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T20:36:00+00:00

A few weeks ago, the NY Times published a very nice profile piece about me, which starts off with the story of how I recently got pulled into a group chat with a bunch of Hollywood writers, directors, and actors, who were trying to understand how to deal with the rise of generative AI tools. [&#8230;]

## Masculine Policy: The GOP’s Plan To Outlaw ‘Porn’ And Suspend The First Amendment
 - [https://www.techdirt.com/2023/08/17/masculine-policy-the-gops-plan-to-outlaw-porn-and-suspend-the-first-amendment/](https://www.techdirt.com/2023/08/17/masculine-policy-the-gops-plan-to-outlaw-porn-and-suspend-the-first-amendment/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T19:09:00+00:00

Does watching porn threaten your masculinity? Science says it doesn’t.&#160; Is porn addictive? No, it’s not. Is sexual expression that is consenting legally protected by the First Amendment? Yes, it is.&#160; So, why do Republicans fight to restrict or outlaw pornography across the United States?&#160; There are several reasons. First, religious conservatives have long argued [&#8230;]

## County Attorney Rejects Warrant Used In Raid Of Small Kansas Newspaper, Asks Court To Force Cops To Return Seized Devices
 - [https://www.techdirt.com/2023/08/17/county-attorney-rejects-warrant-used-in-raid-of-small-kansas-newspaper-asks-court-to-force-cops-to-return-seized-devices/](https://www.techdirt.com/2023/08/17/county-attorney-rejects-warrant-used-in-raid-of-small-kansas-newspaper-asks-court-to-force-cops-to-return-seized-devices/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T17:55:00+00:00

Last week, cops in a small Kansas town decided they&#8217;d just toss aside the First Amendment and raid a local newspaper. There were competing narratives. The first was that the paper was in possession of information related to the drunk driving arrest of local business owner Kari Newell, who had allegedly been convicted of DUI [&#8230;]

## Daily Deal: The 2023 Complete Python Boot Camp Bundle
 - [https://www.techdirt.com/2023/08/17/daily-deal-the-2023-complete-python-boot-camp-bundle/](https://www.techdirt.com/2023/08/17/daily-deal-the-2023-complete-python-boot-camp-bundle/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T17:52:28+00:00

The 2023 Complete Python Boot Camp Bundle has 12 courses to help you strengthen your Python coding skills. Python is a high-level, general-purpose language with an emphasis on readability and extensibility. Its versatility provides developers with a robust skill-set that can be adapted to numerous projects, making it a highly desirable language to pursue. Whether [&#8230;]

## Are People More Upset About ExTwitter Allowing A ‘Verified Pro-Hitler’ Account, Or That Big Company Ads Are Appearing Next To That Account?
 - [https://www.techdirt.com/2023/08/17/are-people-more-upset-about-extwitter-allowing-a-verified-pro-hitler-account-or-that-big-company-ads-are-appearing-next-to-that-account/](https://www.techdirt.com/2023/08/17/are-people-more-upset-about-extwitter-allowing-a-verified-pro-hitler-account-or-that-big-company-ads-are-appearing-next-to-that-account/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T16:38:28+00:00

Elon Musk hired Linda Yaccarino to be “CEO” of exTwitter (despite saying he doesn’t believe in the role of a CEO) because he desperately needed someone who worked well with advertisers to try to lure back some of the many, many, many advertisers who had fled the platform in disgust at what Elon has done [&#8230;]

## Comcast, AT&T Try To Kill New Requirements To Be Transparent About Their Shitty Pricing
 - [https://www.techdirt.com/2023/08/17/comcast-att-try-to-kill-new-requirements-to-be-transparent-about-their-shitty-pricing/](https://www.techdirt.com/2023/08/17/comcast-att-try-to-kill-new-requirements-to-be-transparent-about-their-shitty-pricing/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T12:34:28+00:00

The 2021 infrastructure bill did some very good things for broadband. Not only did it include a massive, $42 billion investment in broadband deployment and require better mapping, it demanded that the FCC impose a new &#8220;nutrition label for broadband,&#8221; requiring that ISPs be transparent about all of the weird restrictions, caps, fees, and limitations [&#8230;]

## Russian State Media Ponders Taking Over Trademark Name, Logo For Liberal Radio Station
 - [https://www.techdirt.com/2023/08/16/russian-state-media-ponders-taking-over-trademark-name-logo-for-liberal-radio-station/](https://www.techdirt.com/2023/08/16/russian-state-media-ponders-taking-over-trademark-name-logo-for-liberal-radio-station/)
 - RSS feed: https://www.techdirt.com/feed/
 - date published: 2023-08-17T02:47:00+00:00

Let me do a bit of throat-clearing at the top of this post. As a reminder, the general purpose of trademark laws around the world is to serve as a source-identifier for the public in those markets. In other words, allowing someone to trademark a unique identifier as to a source of a good or [&#8230;]

