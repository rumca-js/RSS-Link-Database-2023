# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Debian's Swirl Was Made In Adobe Illustrator
 - [https://www.youtube.com/watch?v=rdcsPx0N0eM](https://www.youtube.com/watch?v=rdcsPx0N0eM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-08-17T21:00:29+00:00

Will all know about the famous Debian swirl logo but have you ever wondered how it was made, well someone told me it was made in Adobe Illustrator and I didn't believe them so I had to look into it and I was surprised it was true.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Debian Logo: https://wiki.debian.org/DebianLogo
Symobolism: https://lists.debian.org/debian-devel/2005/01/msg00111.html
2005 Mailing List: https://lists.debian.org/debian-legal/2005/06/msg00340.html
2005 Logo Creation: https://lists.debian.org/debian-legal/2005/06/pngmTIAmm6MWW.png
Stolen Logo: https://i.imgur.com/gFKfs.jpg
Trademark Violation: https://lists.debian.org/debian-legal/2010/11/msg00062.html
Creation Steps: https://lists.debian.org/debian-legal/2010/12/msg00015.html

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

#Debian #Adobe #OpenSource #Linux #FOSS #adobeillustrator 

🎵 Ending music
Track: Debris & Jonth - Game Time [NCS Release]
Music provided by NoCopyrightSounds.
Watch:  https://www.youtube.com/watch?v=yDTvvOTie0w 
Free Download / Stream: http://ncs.io/GameTime

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

