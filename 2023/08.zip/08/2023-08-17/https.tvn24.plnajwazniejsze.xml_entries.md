# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Trener Legii pęka z dumy. "Magiczna noc"
 - [https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/austria-wieden-legia-warszawa.-kosta-runjaic-trener-legii-o-meczu-eliminacje-ligi-konferencji_sto9746926/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/austria-wieden-legia-warszawa.-kosta-runjaic-trener-legii-o-meczu-eliminacje-ligi-konferencji_sto9746926/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T20:49:50+00:00

<img alt="Trener Legii pęka z dumy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4yobjr-kosta-runjaic-7296630/alternates/LANDSCAPE_1280" />
    Legia Warszawa awansowała do czwartej rundy kwalifikacji Ligi Konferencji.

## Problemy tylko na początku. Świątek ma ćwierćfinał
 - [https://eurosport.tvn24.pl/tenis/wta-cincinnati/2023/iga-swiatek-qinwen-zheng-wynik-i-relacja-z-meczu-1-8-finalu-turnieju-wta-1000-w-cincinnati_sto9746695/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-cincinnati/2023/iga-swiatek-qinwen-zheng-wynik-i-relacja-z-meczu-1-8-finalu-turnieju-wta-1000-w-cincinnati_sto9746695/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T20:16:53+00:00

<img alt="Problemy tylko na początku. Świątek ma ćwierćfinał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fptq5r-iga-swiatek-7296617/alternates/LANDSCAPE_1280" />
    WTA 1000 w Cincinnati.

## Koniec pucharowej przygody Lecha
 - [https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/spartak-trnava-lech-poznan-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferencji_sto9746651/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/spartak-trnava-lech-poznan-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferencji_sto9746651/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T20:04:35+00:00

<img alt="Koniec pucharowej przygody Lecha" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrejvv-lech-poznan-odpadl-z-eliminacji-ligi-konferencji-7296613/alternates/LANDSCAPE_1280" />
    Bolesna porażka na Słowacji.

## Zalane posesje i wezbrane rzeki
 - [https://tvn24.pl/tvnmeteo/polska/burze-w-polsce-kilkadziesiat-interwencji-na-dolnym-slasku-zalane-posesje-i-wezbrane-rzeki-7296576?source=rss](https://tvn24.pl/tvnmeteo/polska/burze-w-polsce-kilkadziesiat-interwencji-na-dolnym-slasku-zalane-posesje-i-wezbrane-rzeki-7296576?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T19:32:43+00:00

<img alt="Zalane posesje i wezbrane rzeki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uf7l2v-17-2046-avi-kamienna-gor_01-01_00-04-172032-0052-7296590/alternates/LANDSCAPE_1280" />
    Burze w Polsce.

## Legia strzeliła pięć goli i wyszarpała awans
 - [https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/austria-wieden-legia-warszawa-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferenc_sto9746649/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/austria-wieden-legia-warszawa-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferenc_sto9746649/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T19:10:42+00:00

<img alt="Legia strzeliła pięć goli i wyszarpała awans" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c5ygbt-legia-warszawa-austria-wieden-w-3-7296583/alternates/LANDSCAPE_1280" />
    Szalony mecz w Wiedniu.

## Wielka niespodzianka. Pierwszy set dla rywalki Świątek
 - [https://eurosport.tvn24.pl/tenis/wta-cincinnati/2023/live-iga-swiatek-zheng-qinwen_mtc1463290/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-cincinnati/2023/live-iga-swiatek-zheng-qinwen_mtc1463290/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T19:03:00+00:00

<img alt="Wielka niespodzianka. Pierwszy set dla rywalki Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tppsxc-iga-swiatek-7290074/alternates/LANDSCAPE_1280" />
    Relacja i wyniki na żywo w eurosport.pl.

## "Niektórym wydaje się, że wystarczy wygrać z PiS-em"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-komorowski-o-wszystkim-zadecyduje-to-kto-bedzie-trzeci-7296429?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-komorowski-o-wszystkim-zadecyduje-to-kto-bedzie-trzeci-7296429?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T18:29:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-feaa9d-bronislaw-komorowski-7296479/alternates/LANDSCAPE_1280" />
    Były prezydent Bronisław Komorowski był gościem "Faktów po Faktach".

## Wielkie zwycięstwo Hurkacza
 - [https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/stefanos-tsitsipas-hubert-hurkacz-wynik-i-relacja-z-meczu-1-8-finalu-turnieju-atp-1000-w-cincinnati_sto9746692/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/stefanos-tsitsipas-hubert-hurkacz-wynik-i-relacja-z-meczu-1-8-finalu-turnieju-atp-1000-w-cincinnati_sto9746692/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T18:24:25+00:00

<img alt="Wielkie zwycięstwo Hurkacza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yt8lpz-hubert-hurkacz-7296544/alternates/LANDSCAPE_1280" />
     Czwarta rakieta świata pokonana.

## Wyjątkowy marsz, by pomóc Olinkowi. "Potrzebujemy przede wszystkim środków na rehabilitację"
 - [https://fakty.tvn24.pl/zobacz-fakty/wyjatkowy-marsz-by-pomoc-olinkowi-potrzebujemy-przede-wszystkim-srodkow-na-rehabilitacje-7296313?source=rss](https://fakty.tvn24.pl/zobacz-fakty/wyjatkowy-marsz-by-pomoc-olinkowi-potrzebujemy-przede-wszystkim-srodkow-na-rehabilitacje-7296313?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T18:20:51+00:00

<img alt="Wyjątkowy marsz, by pomóc Olinkowi. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-aw9per-170819-kijowska-cz-000589-7296414/alternates/LANDSCAPE_1280" />
    Pomaga i wspiera kto może, bo razem można więcej.

## Sejm za zwiększeniem władzy Prokuratora Krajowego
 - [https://tvn24.pl/polska/sejm-za-zwiekszeniem-wladzy-prokuratora-krajowego-opozycja-probuja-sie-tam-zabarykadowac-7296425?source=rss](https://tvn24.pl/polska/sejm-za-zwiekszeniem-wladzy-prokuratora-krajowego-opozycja-probuja-sie-tam-zabarykadowac-7296425?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T18:04:36+00:00

<img alt="Sejm za zwiększeniem władzy Prokuratora Krajowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1vkddk-warszawa-24022023-minister-sprawiedliwosci-prokurator-generalny-zbigniew-ziobro-p-i-prokurator-krajowy-dariusz-barski-l-podczas-konferencji-prasowej-w-prokuraturze-krajowej-7296411/alternates/LANDSCAPE_1280" />
    Opozycja: próbują się tam zabarykadować.

## Rewelacyjny Hurkacz. Świątek dopiero zaczyna walkę
 - [https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/live-stefanos-tsitsipas-hubert-hurkacz_mtc1463144/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/live-stefanos-tsitsipas-hubert-hurkacz_mtc1463144/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T18:01:00+00:00

<img alt="Rewelacyjny Hurkacz. Świątek dopiero zaczyna walkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-itrew4-iga-swiatek-i-hubert-hurkacz-7296311/alternates/LANDSCAPE_1280" />
    Relacja i wyniki na żywo w eurosport.pl.

## Honorowe pożegnanie Pogoni z Europą
 - [https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/pogon-szczecin-kaa-gent-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferencji_sto9746615/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/pogon-szczecin-kaa-gent-wynik-i-relacja-z-rewanzowego-meczu-3.-rundy-eliminacji-ligi-konferencji_sto9746615/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T17:58:27+00:00

<img alt="Honorowe pożegnanie Pogoni z Europą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a7icuu-pogon-szczecin-walczyla-o-honorowe-pozegnanie-z-lk-7296513/alternates/LANDSCAPE_1280" />
    Rezerwowy bohaterem Portowców.

## Forbes: Ukraińcy rzucili do boju swoją najsilniejszą jednostkę szturmową
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-rzucono-do-walki-elitarna-82-brygade-desantowo-szturmowa-forbes-7296327?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-rzucono-do-walki-elitarna-82-brygade-desantowo-szturmowa-forbes-7296327?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T17:33:54+00:00

<img alt="Forbes: Ukraińcy rzucili do boju swoją najsilniejszą jednostkę szturmową" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ajx65v-zolnierze-82-brygady-desantowo-szturmowej-7296328/alternates/LANDSCAPE_1280" />
    Elitarna brygada miała wejść do walki w rejonie miejscowości Robotyne.

## Historie chorób dla więźniów i... mundurowych. Lekarz zatrzymany
 - [https://tvn24.pl/polska/policja-zatrzymala-lekarza-ktory-za-lapowki-mial-tworzyc-historie-chorob-dla-wiezniow-i-mundurowych-7293293?source=rss](https://tvn24.pl/polska/policja-zatrzymala-lekarza-ktory-za-lapowki-mial-tworzyc-historie-chorob-dla-wiezniow-i-mundurowych-7293293?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T17:03:50+00:00

<img alt="Historie chorób dla więźniów i... mundurowych. Lekarz zatrzymany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zc3bao-policja-7296341/alternates/LANDSCAPE_1280" />
    Banalne z pozoru śledztwo może zakończy dziesiątki, jeśli nie setki karier - wynika z nieoficjalnych informacji tvn24.pl.

## Wiceszef MON o białoruskich śmigłowcach nad Polską: ich wykrycie było niemożliwe
 - [https://tvn24.pl/polska/bialoruskie-smiglowce-nad-bialowieza-ich-wykrycie-bylo-niemozliwe-wojciech-skurkiewicz-7296244?source=rss](https://tvn24.pl/polska/bialoruskie-smiglowce-nad-bialowieza-ich-wykrycie-bylo-niemozliwe-wojciech-skurkiewicz-7296244?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T16:35:03+00:00

<img alt="Wiceszef MON o białoruskich śmigłowcach nad Polską: ich wykrycie było niemożliwe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vvk101-bialoruski-smiglowiec-w-polskiej-przestrzeni-powietrznej-1-sierpnia-2023-7275108/alternates/LANDSCAPE_1280" />
    Do naruszenia polskiej przestrzeni powietrznej doszło 1 sierpnia.

## Fizyczne interwencje, wykluczanie posłów, zakulisowe konsultacje
 - [https://fakty.tvn24.pl/fakty-po-poludniu/fizyczne-interwencje-wykluczanie-poslow-zakulisowe-konsultacje-parlamentaryzm-za-rzadow-pis-7296055?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/fizyczne-interwencje-wykluczanie-poslow-zakulisowe-konsultacje-parlamentaryzm-za-rzadow-pis-7296055?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T16:08:47+00:00

<img alt="Fizyczne interwencje, wykluczanie posłów, zakulisowe konsultacje" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6mdnmi-1708n252x-pupiec-podszepty-000689-7296167/alternates/LANDSCAPE_1280" />
    Parlamentaryzm za rządów PiS.

## Europa bez rakiety. "Gdy przyszły kłopoty, to nie miała sobie jak z tym poradzić"
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-88,S00E88,1138692?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-88,S00E88,1138692?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T16:00:53+00:00

<img alt="Europa bez rakiety. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dbrslg-rakieta-esa-7296312/alternates/LANDSCAPE_1280" />
    Gdzie na kosmicznej arenie jest Stary Kontynent?

## Laser, broń pogodowa i HAARP. Fałszywe informacje wokół pożarów na Hawajach
 - [https://konkret24.tvn24.pl/swiat/pozary-na-hawajach-laser-bron-pogodowa-i-haarp-falszywe-informacje-wokol-katastrofy-na-maui-st7294269?source=rss](https://konkret24.tvn24.pl/swiat/pozary-na-hawajach-laser-bron-pogodowa-i-haarp-falszywe-informacje-wokol-katastrofy-na-maui-st7294269?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:45:07+00:00

<img alt="Laser, broń pogodowa i HAARP. Fałszywe informacje wokół pożarów na Hawajach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sktx3e-pozary-na-hawajach-teorie-spiskowe-7294298/alternates/LANDSCAPE_1280" />
    Pożary na wyspie Maui rzekomo zostały sztucznie wywołane przy użyciu zaawansowanych broni.

## Była stałą "klientką", każdą jej wizytę nagrywały kamery. Po ostatniej, gdy minęła kasy, została zatrzymana
 - [https://tvn24.pl/tvnwarszawa/praga-polnoc/piaseczno-stala-klientke-drogerii-czeka-wizyta-w-sadzie-7295883?source=rss](https://tvn24.pl/tvnwarszawa/praga-polnoc/piaseczno-stala-klientke-drogerii-czeka-wizyta-w-sadzie-7295883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:25:45+00:00

<img alt="Była stałą " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-t9bn7n-41-latke-czeka-teraz-wizyta-w-sadzie-7295896/alternates/LANDSCAPE_1280" />
    Grozi jej nawet pięć lat więzienia.

## Była stałą "klientką", każdą jej wizytę nagrywały kamery. Po ostatniej, gdy minęła kasy, została zatrzymana
 - [https://tvn24.pl/tvnwarszawa/okolice/piaseczno-stala-klientke-drogerii-czeka-wizyta-w-sadzie-7295883?source=rss](https://tvn24.pl/tvnwarszawa/okolice/piaseczno-stala-klientke-drogerii-czeka-wizyta-w-sadzie-7295883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:25:45+00:00

<img alt="Była stałą " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-t9bn7n-41-latke-czeka-teraz-wizyta-w-sadzie-7295896/alternates/LANDSCAPE_1280" />
    Grozi jej nawet pięć lat więzienia.

## Opozycja pytała, minister opuścił salę. "Obraził się i wyszedł"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pytania-o-finansowanie-kampanii-pis-minister-schreiber-opuscil-sale-7295965?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pytania-o-finansowanie-kampanii-pis-minister-schreiber-opuscil-sale-7295965?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:24:54+00:00

<img alt="Opozycja pytała, minister opuścił salę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-by4syb-schreiber-7296019/alternates/LANDSCAPE_1280" />
    Pytano o finansowanie kampanii wyborczej PiS z budżetu.

## Problemy Barcelony u progu sezonu
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/obronca-barcelony-ronald-araujo-kontuzjowany.-jak-dluga-przerwa-czeka-pilkarza_sto9746421/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/obronca-barcelony-ronald-araujo-kontuzjowany.-jak-dluga-przerwa-czeka-pilkarza_sto9746421/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:21:24+00:00

<img alt="Problemy Barcelony u progu sezonu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2r37wt-ronald-araujo-bedzie-pauzowal-ze-wzgledu-na-kontuzje-7296211/alternates/LANDSCAPE_1280" />
    Podstawowy obrońca kontuzjowany.

## Apple zapłaci właścicielom iPhone'ów. Gigant przegrał głośną sprawę
 - [https://tvn24.pl/biznes/tech/apple-wyplaci-odszkodowania-klientom-chodzi-o-modele-iphone-6-6-plus-6s-6s-plus-se-iphone-7-i-7-plus-7296085?source=rss](https://tvn24.pl/biznes/tech/apple-wyplaci-odszkodowania-klientom-chodzi-o-modele-iphone-6-6-plus-6s-6s-plus-se-iphone-7-i-7-plus-7296085?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T15:11:56+00:00

<img alt="Apple zapłaci właścicielom iPhone'ów. Gigant przegrał głośną sprawę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y60alz-iphone-shutterstock_485074438-7296092/alternates/LANDSCAPE_1280" />
    Finał afery "batterygate".

## Kibice rywala Rakowa nie obejrzą meczu w Polsce
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/rakow-czestochowa-fc-kopenhaga.-mecz-w-sosnowcu-bez-udzialu-kibicow-z-danii-eliminacje-ligi-mistrzow_sto9746435/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-mistrzow/2023-2024/rakow-czestochowa-fc-kopenhaga.-mecz-w-sosnowcu-bez-udzialu-kibicow-z-danii-eliminacje-ligi-mistrzow_sto9746435/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:46:12+00:00

<img alt="Kibice rywala Rakowa nie obejrzą meczu w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-df48hq-kibice-fc-kopenhaga-7296164/alternates/LANDSCAPE_1280" />
    UEFA potwierdziła karę.

## To wtedy polskiej demokracji "PiS zadało mocny cios". "Sprawa jest paskudna"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2433,S00E2433,1138673?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2433,S00E2433,1138673?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:36:22+00:00

<img alt="To wtedy polskiej demokracji " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aknpqv-czarno-na-bialym-reasumpcja-7296140/alternates/LANDSCAPE_1280" />
    Przepychanie ustaw przez Sejm, chaos i podporządkowanie przepisów politycznej woli. Dlaczego tak jest? Reportaż Artura Zakrzewskiego.

## Kampanie wyborcza i referendalna: skąd pieniądze, ile, jaka kontrola?
 - [https://konkret24.tvn24.pl/polityka/wybory-2023-kampanie-wyborcza-i-referendalna-skad-pieniadze-ile-jaka-kontrola-st7294477?source=rss](https://konkret24.tvn24.pl/polityka/wybory-2023-kampanie-wyborcza-i-referendalna-skad-pieniadze-ile-jaka-kontrola-st7294477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:34:52+00:00

<img alt="Kampanie wyborcza i referendalna: skąd pieniądze, ile, jaka kontrola? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uu8oc6-wybory-rownoczesnie-z-referendum-jakie-zasady-finansowania-7283824/alternates/LANDSCAPE_1280" />
    Analizujemy, czym różni się finansowanie i rozliczanie obu tych kampanii.

## Znana sieć wycofuje produkt
 - [https://tvn24.pl/biznes/z-kraju/pepco-wycofuje-produkt-dla-dzieci-z-powodu-mozliwosci-uwalniania-niklu-7296073?source=rss](https://tvn24.pl/biznes/z-kraju/pepco-wycofuje-produkt-dla-dzieci-z-powodu-mozliwosci-uwalniania-niklu-7296073?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:22:45+00:00

<img alt="Znana sieć wycofuje produkt" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-u4lq2q-pepco-sklep-debiut-na-gpw-5104236/alternates/LANDSCAPE_1280" />
    Komunikat.

## Poważne konsekwencje po feralnym meczu. Trener i piłkarz Barcelony zawieszeni
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/xavi-hernandez-i-raphinha-zawieszeni-po-meczu-getafe-fc-barcelona_sto9746135/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/xavi-hernandez-i-raphinha-zawieszeni-po-meczu-getafe-fc-barcelona_sto9746135/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:13:43+00:00

<img alt="Poważne konsekwencje po feralnym meczu. Trener i piłkarz Barcelony zawieszeni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jw2t8e-xavi-hernandez-podczas-meczu-z-getafe-7296101/alternates/LANDSCAPE_1280" />
    Decyzją Komisji ds. Rozgrywek.

## Auto zatrzymuje się na środkowym pasie. Wtedy z impetem wjeżdża w nie ciężarówka. Nagranie
 - [https://tvn24.pl/bialystok/panienszczyzna-zatrzymal-sie-nagle-na-srodkowym-pasie-drogi-ekspresowej-wjechala-w-niego-ciezarowka-nagranie-7296000?source=rss](https://tvn24.pl/bialystok/panienszczyzna-zatrzymal-sie-nagle-na-srodkowym-pasie-drogi-ekspresowej-wjechala-w-niego-ciezarowka-nagranie-7296000?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T14:12:11+00:00

<img alt="Auto zatrzymuje się na środkowym pasie. Wtedy z impetem wjeżdża w nie ciężarówka. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8m1qka-sila-uderzenia-byla-bardzo-duza-7296047/alternates/LANDSCAPE_1280" />
    Groźna kolizja w miejscowości Panieńszczyzna (woj. lubelskie).

## Rosjanie od początku inwazji stracili już ponad 250 tysięcy żołnierzy
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-straty-rosji-przekroczyly-250-tysiecy-zolnierzy-dane-armii-ukrainskiej-7295856?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-straty-rosji-przekroczyly-250-tysiecy-zolnierzy-dane-armii-ukrainskiej-7295856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T13:55:14+00:00

<img alt="Rosjanie od początku inwazji stracili już ponad 250 tysięcy żołnierzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-47p8oq-zniszczony-rosyjski-czolg-w-obwodzie-zaporoskim-7295886/alternates/LANDSCAPE_1280" />
    Sprawozdanie sztabu generalnego ukraińskich sił zbrojnych.

## Reprezentant Polski odszedł z Pogoni
 - [https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/mateusz-legowski-odchodzi-z-pogoni-szczecin-do-salernitany_sto9746330/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/serie-a/2023-2024/mateusz-legowski-odchodzi-z-pogoni-szczecin-do-salernitany_sto9746330/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T13:51:44+00:00

<img alt="Reprezentant Polski odszedł z Pogoni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v378lc-mateusz-legowski-to-byly-pilkarz-pogoni-szczecin-7296044/alternates/LANDSCAPE_1280" />
    Zagra we włoskiej Serie A.

## Klub Koalicji Obywatelskiej przyjął nowych parlamentarzystów
 - [https://tvn24.pl/polska/klub-koalicji-obywatelskiej-przyjal-nowych-poslow-hanna-gill-piatek-karolina-pawliczak-michal-wypij-gabriela-morawska-stanecka-7295939?source=rss](https://tvn24.pl/polska/klub-koalicji-obywatelskiej-przyjal-nowych-poslow-hanna-gill-piatek-karolina-pawliczak-michal-wypij-gabriela-morawska-stanecka-7295939?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T13:30:19+00:00

<img alt="Klub Koalicji Obywatelskiej przyjął nowych parlamentarzystów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-87bwev-sklejka-politycy-7295966/alternates/LANDSCAPE_1280" />
    Dołączyło do niego troje posłów i wicemarszałek Senatu.

## "Sternik próbował uniknąć zderzenia". Prokuratura o tragedii, w której zginęły dwie 15-latki
 - [https://tvn24.pl/lodz/zalew-sulejowski-dwie-15-latki-nie-zyja-po-zderzeniu-lodzi-i-skutera-wodnego-prokuratura-o-wstepnych-ustaleniach-7295948?source=rss](https://tvn24.pl/lodz/zalew-sulejowski-dwie-15-latki-nie-zyja-po-zderzeniu-lodzi-i-skutera-wodnego-prokuratura-o-wstepnych-ustaleniach-7295948?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T13:15:03+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oufqs-o-smierci-nastolatek-poinformowal-rzecznik-matki-polki-w%20lodzi-7293628/alternates/LANDSCAPE_1280" />
    Kierujący motorówką był trzeźwy i posiadał uprawnienia.

## Do uduszenia dziewczyny skłonił go "wewnętrzny głos". Prokuratura o sekcji zwłok
 - [https://tvn24.pl/katowice/radzionkow-udusil-poznana-w-autobusie-dziewczyne-mial-go-sklonic-do-tego-wewnetrzny-glos-prokuratura-o-sekcji-zwlok-7295894?source=rss](https://tvn24.pl/katowice/radzionkow-udusil-poznana-w-autobusie-dziewczyne-mial-go-sklonic-do-tego-wewnetrzny-glos-prokuratura-o-sekcji-zwlok-7295894?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:56:52+00:00

<img alt="Do uduszenia dziewczyny skłonił go " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t7cnwt-19-letni-mateusz-h-uslyszal-zarzut-zabojstwa-18-letniej-mieszkanki-bytomia-7291778/alternates/LANDSCAPE_1280" />
    19-latkowi grozi dożywocie.

## PiS wykorzystało wizerunek dziennikarza "Faktów" TVN w spocie wyborczym. TVN24: stanowczo protestujemy
 - [https://tvn24.pl/wybory-parlamentarne-2023/pis-wykorzystalo-wizerunek-dziennikarza-faktow-tvn-w-spocie-wyborczym-oswiadczenie-tvn24-7295542?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/pis-wykorzystalo-wizerunek-dziennikarza-faktow-tvn-w-spocie-wyborczym-oswiadczenie-tvn24-7295542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:41:01+00:00

<img alt="PiS wykorzystało wizerunek dziennikarza " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uxc7xi-tvn24-7295644/alternates/LANDSCAPE_1280" />
    Wcześniej PiS wykorzystało do innego spotu fragmenty audycji Radia Zet, czemu sprzeciwił się zarząd Grupy Eurozet. W podobnych sprawach dwoje dziennikarzy skierowało pozwy przeciwko partii.

## Mistrzostwa świata w lekkoatletyce od soboty na żywo w Eurosporcie 1 i Playerze
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-od-soboty-na-zywo-w-eurosporcie-1-i-playerze_sto9746263/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-od-soboty-na-zywo-w-eurosporcie-1-i-playerze_sto9746263/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:36:34+00:00

<img alt="Mistrzostwa świata w lekkoatletyce od soboty na żywo w Eurosporcie 1 i Playerze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hk6bqs-mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023-7295904/alternates/LANDSCAPE_1280" />
    Codziennie do 27 sierpnia.

## "Słyszę brzęczenie przed serwisem". Niedorzeczna sytuacja na meczu rywala Hurkacza
 - [https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/stefanos-tsitsipas-domagal-sie-wyrzucenia-kibicki-z-trybun-w-meczu-z-benem-sheltonem-wideo_sto9746213/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/stefanos-tsitsipas-domagal-sie-wyrzucenia-kibicki-z-trybun-w-meczu-z-benem-sheltonem-wideo_sto9746213/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:23:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gf3m7x-tsitsipas-mial-problem-z-jedna-z-kibicek-7295871/alternates/LANDSCAPE_1280" />
    Stefanos Tsitsipas miał problemy nie tylko z przeciwnikiem.

## Masakry rozpoczęły się w całym mieście. Tylko pierwszego dnia zginęło tysiąc osób
 - [https://tvn24.pl/swiat/sudan-masakra-cywilow-w-al-dzunajnie-pierwszego-dnia-zginal-tysiac-cywilow-cnn-7295560?source=rss](https://tvn24.pl/swiat/sudan-masakra-cywilow-w-al-dzunajnie-pierwszego-dnia-zginal-tysiac-cywilow-cnn-7295560?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:18:44+00:00

<img alt="Masakry rozpoczęły się w całym mieście. Tylko pierwszego dnia zginęło tysiąc osób" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ruyd5-waki-w-sudanie-7277695/alternates/LANDSCAPE_1280" />
    Ustalenia dziennikarskiego śledztwa CNN.

## Chciał tylko pozdrowić kierowcę. Rowerzysta zderzył się czołowo z autobusem, zginął na miejscu
 - [https://tvn24.pl/tvnwarszawa/ulice/podlecze-rowerzysta-zderzyl-sie-czolowo-z-autobusem-miejskim-sledztwo-7295544?source=rss](https://tvn24.pl/tvnwarszawa/ulice/podlecze-rowerzysta-zderzyl-sie-czolowo-z-autobusem-miejskim-sledztwo-7295544?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:14:59+00:00

<img alt="Chciał tylko pozdrowić kierowcę. Rowerzysta zderzył się czołowo z autobusem, zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vgcujk-rower-droga-7279293/alternates/LANDSCAPE_1280" />
    Śledztwo w sprawie nieumyślnego spowodowania śmiertelnego wypadku.

## Pakt senacki. Lista kandydatek i kandydatów partii opozycyjnych
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pakt-senacki-lista-kandydatow-opozycji-nazwiska-7295713?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-pakt-senacki-lista-kandydatow-opozycji-nazwiska-7295713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T12:00:43+00:00

<img alt="Pakt senacki. Lista kandydatek i kandydatów partii opozycyjnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ggrljz-pakt-senacki-7295848/alternates/LANDSCAPE_1280" />
    Koalicja Obywatelska, Nowa Lewica, PSL, Polska 2050 oraz Ruch Samorządowy "Tak! Dla Polski" zawarli porozumienie w sprawie paktu senackiego.

## Kto może zostać członkiem obwodowej komisji wyborczej i na jakie wynagrodzenie może liczyć?
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-kto-moze-zostac-czlonkiem-obwodowej-komisji-wyborczej-i-ile-zarobi-7295464?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-kto-moze-zostac-czlonkiem-obwodowej-komisji-wyborczej-i-ile-zarobi-7295464?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T11:58:51+00:00

<img alt="Kto może zostać członkiem obwodowej komisji wyborczej i na jakie wynagrodzenie może liczyć?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1fx0qv-pap_20191013_162-7286222/alternates/LANDSCAPE_1280" />
    Wybory parlamentarne zostaną przeprowadzone 15 października.

## Czołowe zderzenie dwóch bmw. Nie żyje młody kierowca. Są też ranni, w tym dzieci
 - [https://tvn24.pl/krakow/mala-czolowe-zderzenie-dwoch-bmw-nie-zyje-mlody-kierowca-cztery-osoby-ranne-w-tym-dwoje-dzieci-7295687?source=rss](https://tvn24.pl/krakow/mala-czolowe-zderzenie-dwoch-bmw-nie-zyje-mlody-kierowca-cztery-osoby-ranne-w-tym-dwoje-dzieci-7295687?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T11:52:35+00:00

<img alt="Czołowe zderzenie dwóch bmw. Nie żyje młody kierowca. Są też ranni, w tym dzieci  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wpnuxz-22-letni-kierowca-zginal-z-czolowym-zderzeniu-dwoch-bmw-7295688/alternates/LANDSCAPE_1280" />
    W miejscowości Mała (woj. podkarpackie).

## Zginęło 20 tysięcy mieszkańców okupowanego miasta. Władze skarżą się Moskwie
 - [https://tvn24.pl/swiat/ukraina-tysiace-zmobilizowanych-mieszkancow-okupowanej-gorlowki-zginelo-media-7295720?source=rss](https://tvn24.pl/swiat/ukraina-tysiace-zmobilizowanych-mieszkancow-okupowanej-gorlowki-zginelo-media-7295720?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T11:49:02+00:00

<img alt="Zginęło 20 tysięcy mieszkańców okupowanego miasta. Władze skarżą się Moskwie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ty20mq-rosyjscy-zolnierze-7291320/alternates/LANDSCAPE_1280" />
    Gorłówka jest okupowana przez Rosjan do 2014 roku.

## Oglądał telewizję z byłą żoną. Nagle postrzelił ją na oczach córki
 - [https://tvn24.pl/krakow/sandomierz-postrzelona-na-oczach-corki-48-latka-wciaz-walczy-o-zycie-w-szpitalu-prokuratura-o-postepach-w-sledztwie-7295481?source=rss](https://tvn24.pl/krakow/sandomierz-postrzelona-na-oczach-corki-48-latka-wciaz-walczy-o-zycie-w-szpitalu-prokuratura-o-postepach-w-sledztwie-7295481?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T11:16:43+00:00

<img alt="Oglądał telewizję z byłą żoną. Nagle postrzelił ją na oczach córki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ggl63w-cialo-zostalo-znalezione-na-ulicy-zdjecie-ilustracyjne-7200697/alternates/LANDSCAPE_1280" />
    Ustalenia prokuratury dotyczące rodzinnej tragedii w Sandomierzu.

## Rocznica tragedii. 25 lat temu polska lekkoatletyka straciła dwie wielkie gwiazdy
 - [https://eurosport.tvn24.pl/lekkoatletyka/25-lat-temu-zgineli-mistrzowie-olimpijscy-wladyslaw-komar-i-tadeusz-slusarski_sto9746216/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/25-lat-temu-zgineli-mistrzowie-olimpijscy-wladyslaw-komar-i-tadeusz-slusarski_sto9746216/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T11:11:00+00:00

<img alt="Rocznica tragedii. 25 lat temu polska lekkoatletyka straciła dwie wielkie gwiazdy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jacq49-wladyslaw-komar-7295743/alternates/LANDSCAPE_1280" />
    17 sierpnia 1998 roku w wypadku drogowym zginęli Władysław Komar i Tadeusz Ślusarski.

## Genetycznie zmodyfikowana nerka świni od ponad miesiąca działa w ciele człowieka
 - [https://tvn24.pl/swiat/usa-lekarze-z-nowego-jorku-przeszczepili-genetycznie-zmodyfikowana-nerke-swini-pacjentowi-ze-smiercia-mozgu-7295667?source=rss](https://tvn24.pl/swiat/usa-lekarze-z-nowego-jorku-przeszczepili-genetycznie-zmodyfikowana-nerke-swini-pacjentowi-ze-smiercia-mozgu-7295667?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:59:36+00:00

<img alt="Genetycznie zmodyfikowana nerka świni od ponad miesiąca działa w ciele człowieka" src="https://tvn24.pl/najnowsze/cdn-zdjecied1f7c0e5fe3dc9564cea75aef321a295-na-przeszczep-w-polsce-trzeba-dlugo-czekac-3815191/alternates/LANDSCAPE_1280" />
    Wszczepiono ją mężczyźnie, u którego stwierdzono wcześniej śmierć mózgu.

## Jest decyzja prokuratury w sprawie koncertu Maty nad Wisłą
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-koncert-maty-nad-wisla-prokuratura-zakonczyla-sledztwo-7295671?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-koncert-maty-nad-wisla-prokuratura-zakonczyla-sledztwo-7295671?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:56:33+00:00

<img alt="Jest decyzja prokuratury w sprawie koncertu Maty nad Wisłą" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-y2z7tz-koncert-maty-na-bulwarach-wislanych-5725623/alternates/LANDSCAPE_1280" />
    Raper zorganizował koncert na barce.

## Skokowy wzrost liczby pracujących cudzoziemców
 - [https://tvn24.pl/biznes/z-kraju/liczba-pracujacych-cudzoziemcow-w-polsce-na-koniec-2022-roku-dane-gus-7295660?source=rss](https://tvn24.pl/biznes/z-kraju/liczba-pracujacych-cudzoziemcow-w-polsce-na-koniec-2022-roku-dane-gus-7295660?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:54:05+00:00

<img alt="Skokowy wzrost liczby pracujących cudzoziemców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fj970p-budowa-praca-mieszkania-shutterstock_2024007179-5645852/alternates/LANDSCAPE_1280" />
    Najnowsze dane GUS.

## Wielkie wyczyny Guardioli. Przed nim już tylko jedna legenda
 - [https://eurosport.tvn24.pl/pilka-nozna/superpuchar-europy/2023-2024/pep-guardiola-z-kolejnym-sukcesem.-ile-ma-tytulow-jako-trener-liczba-trofeow_sto9746059/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/superpuchar-europy/2023-2024/pep-guardiola-z-kolejnym-sukcesem.-ile-ma-tytulow-jako-trener-liczba-trofeow_sto9746059/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:45:25+00:00

<img alt="Wielkie wyczyny Guardioli. Przed nim już tylko jedna legenda" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wvg64k-guardiola-ma-powody-do-radosci-oto-jesgo-36-7295703/alternates/LANDSCAPE_1280" />
    Osiągnięcia Hiszpana robią wrażenie.

## Rybacy rekreacyjni blokowali krajową szóstkę. Domagają się odszkodowań
 - [https://tvn24.pl/pomorze/wielistowo-blokada-krajowej-szostki-protest-rybakow-rekreacyjnych-7295414?source=rss](https://tvn24.pl/pomorze/wielistowo-blokada-krajowej-szostki-protest-rybakow-rekreacyjnych-7295414?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:28:11+00:00

<img alt="Rybacy rekreacyjni blokowali krajową szóstkę. Domagają się odszkodowań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cu1bw0-protest-rybakow-7295418/alternates/LANDSCAPE_1280" />
    Chodzi o zakaz połowu dorsza.

## Cena wzrosła o 400 procent. Kolejna wielka sieć wycofuje produkt z oferty
 - [https://tvn24.pl/biznes/ze-swiata/indie-niedobor-pomidorow-i-drozyzna-burger-king-wycofuje-podstawowy-skladnik-kuchni-indyjskiej-7295599?source=rss](https://tvn24.pl/biznes/ze-swiata/indie-niedobor-pomidorow-i-drozyzna-burger-king-wycofuje-podstawowy-skladnik-kuchni-indyjskiej-7295599?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T10:25:55+00:00

<img alt="Cena wzrosła o 400 procent. Kolejna wielka sieć wycofuje produkt z oferty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-756cex-mieso-wyhodowane-w-laboratorium-6227465/alternates/LANDSCAPE_1280" />
    W Indiach.

## Duża plantacja konopi za krzakami. Właściciele wpadli podczas ścinania roślin
 - [https://tvn24.pl/krakow/haczow-policja-zlikwidowala-nielegalna-plantacje-konopi-indyjskich-i-zatrzymala-dwoch-podejrzanych-7295229?source=rss](https://tvn24.pl/krakow/haczow-policja-zlikwidowala-nielegalna-plantacje-konopi-indyjskich-i-zatrzymala-dwoch-podejrzanych-7295229?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:58:22+00:00

<img alt="Duża plantacja konopi za krzakami. Właściciele wpadli podczas ścinania roślin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ipmtd5-policja-zlikwidowala-nielegalna-plantacje-konopi-7295273/alternates/LANDSCAPE_1280" />
    Gdyby marihuana trafiła na rynek, mogła osiągnąć wartość nawet 2 milionów złotych.

## Pakt senacki zawarty
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-opozycja-zawarla-pakt-senacki-7295444?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-opozycja-zawarla-pakt-senacki-7295444?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:56:32+00:00

<img alt="Pakt senacki zawarty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1cpfff-17-1115-senat-konfa-0027-7295573/alternates/LANDSCAPE_1280" />
    Konferencja prasowa w Senacie.

## Nowy sezon "Kuchennych rewolucji". "Będzie szał!"
 - [https://tvn24.pl/kultura-i-styl/kuchenne-rewolucje-magdy-gessler-nowy-sezon-kiedy-premiera-w-jakim-lokalu-pierwsza-rewolucja-7295355?source=rss](https://tvn24.pl/kultura-i-styl/kuchenne-rewolucje-magdy-gessler-nowy-sezon-kiedy-premiera-w-jakim-lokalu-pierwsza-rewolucja-7295355?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:46:15+00:00

<img alt="Nowy sezon " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xj2qo8-magda-gessler-7295364/alternates/LANDSCAPE_1280" />
    Jakie lokale restauratorka odmieni tym razem?

## Sekunda od uderzenia na nagraniu. Wcześniej przeszedł z hulajnogą pod szlabanem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/nowa-iwiczna-szlaban-byl-zamkniety-wjechal-hulajnoga-na-tory-wideo-7295349?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/nowa-iwiczna-szlaban-byl-zamkniety-wjechal-hulajnoga-na-tory-wideo-7295349?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:43:45+00:00

<img alt="Sekunda od uderzenia na nagraniu. Wcześniej przeszedł z hulajnogą pod szlabanem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kcvy4h-przejechal-hulajnoga-tuz-przed-pociagiem-7295369/alternates/LANDSCAPE_1280" />
    Bezmyślne zachowanie mężczyzny.

## "Czasami płaczę. Kiedy zasypiam, widzę to wszystko znowu"
 - [https://tvn24.pl/swiat/ukraina-traumy-zolnierzy-wracajacych-z-frontu-jak-z-kryzysem-radzi-sobie-panstwo-7295182?source=rss](https://tvn24.pl/swiat/ukraina-traumy-zolnierzy-wracajacych-z-frontu-jak-z-kryzysem-radzi-sobie-panstwo-7295182?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:42:52+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v7ejqs-zajecia-sportowe-dla-weteranow-7295260/alternates/LANDSCAPE_1280" />
    "New York Times" w rozmowie z wojskowymi i terapeutami z Ukrainy.

## Bajeczny kontrakt to dopiero początek. Lista życzeń Neymara
 - [https://eurosport.tvn24.pl/pilka-nozna/saudyjska-premier-league/2023-2024/bajeczny-kontrakt-to-dopiero-poczatek.-neymar-w-arabii-bedzie-sie-plawil-w-luksusie_sto9746162/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/saudyjska-premier-league/2023-2024/bajeczny-kontrakt-to-dopiero-poczatek.-neymar-w-arabii-bedzie-sie-plawil-w-luksusie_sto9746162/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:30:41+00:00

<img alt="Bajeczny kontrakt to dopiero początek. Lista życzeń Neymara" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5uokrf-neymar-podpisal-dwuletni-kontrakt-z-saudyjskim-al-hilal-7295534/alternates/LANDSCAPE_1280" />
    Brazylijczyk będzie się pławił w luksusie.

## To ma być bat na oszustów. Nowe obowiązki operatorów
 - [https://tvn24.pl/biznes/najnowsze/cyberbezpieczenstwo-ustawa-o-zwalczaniu-naduzyc-w-komunikacji-elektronicznej-niedlugo-wchodzi-w-zycie-7295175?source=rss](https://tvn24.pl/biznes/najnowsze/cyberbezpieczenstwo-ustawa-o-zwalczaniu-naduzyc-w-komunikacji-elektronicznej-niedlugo-wchodzi-w-zycie-7295175?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:22:34+00:00

<img alt="To ma być bat na oszustów. Nowe obowiązki operatorów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7cpzc2-kobieta-nawiazala-znajomosc-z-niemieckim-lekarzem-stracila-200-tysiecy-zlotych-6792412/alternates/LANDSCAPE_1280" />
    Ustawa wejdzie w życie pod koniec sierpnia.

## Kaczyński: liczba dzieci zagrożonych nędzą spadła dziesięciokrotnie. Dane nie potwierdzają
 - [https://konkret24.tvn24.pl/polska/ubostwo-kaczynski-liczba-dzieci-zagrozonych-nedza-spadla-dziesieciokrotnie-dane-nie-potwierdzaja-st7293897?source=rss](https://konkret24.tvn24.pl/polska/ubostwo-kaczynski-liczba-dzieci-zagrozonych-nedza-spadla-dziesieciokrotnie-dane-nie-potwierdzaja-st7293897?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:16:42+00:00

<img alt="Kaczyński: liczba dzieci zagrożonych nędzą spadła dziesięciokrotnie. Dane nie potwierdzają" src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-6nrvyy-jaroslaw-kaczynski-w-uniejowie-7294315/alternates/LANDSCAPE_1280" />
    Statystyki Głównego Urzędu Statystycznego i Eurostatu nie są tak optymistyczne

## Bóbr mył się jak człowiek. "Nagranie jedno na milion"
 - [https://tvn24.pl/tvnmeteo/polska/bobr-myl-sie-w-rzece-jak-czlowiek-wyjatkowe-nagranie-7295213?source=rss](https://tvn24.pl/tvnmeteo/polska/bobr-myl-sie-w-rzece-jak-czlowiek-wyjatkowe-nagranie-7295213?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:14:34+00:00

<img alt="Bóbr mył się jak człowiek. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-lobdct-bobr-kapal-sie-w-rzece-7295321/alternates/LANDSCAPE_1280" />
    Uchwyciła go fotopułapka Reportera 24.

## Auto dachowało. Zatrzymało się w przejściu podziemnym
 - [https://tvn24.pl/poznan/poznan-dabrowskiego-auto-dachowalo-i-wpadlo-do-przejscia-podziemnego-7295410?source=rss](https://tvn24.pl/poznan/poznan-dabrowskiego-auto-dachowalo-i-wpadlo-do-przejscia-podziemnego-7295410?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T09:06:13+00:00

<img alt="Auto dachowało. Zatrzymało się w przejściu podziemnym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-duouyu-kierowca-trafil-do-szpitala-7295411/alternates/LANDSCAPE_1280" />
    W Poznaniu.

## Państwowa spółka pozywa prezesa NIK
 - [https://tvn24.pl/biznes/z-kraju/pfr-pozywa-prezesa-nik-donosi-dgp-7295068?source=rss](https://tvn24.pl/biznes/z-kraju/pfr-pozywa-prezesa-nik-donosi-dgp-7295068?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:58:56+00:00

<img alt="Państwowa spółka pozywa prezesa NIK" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aeybw8-marian-banas-7295435/alternates/LANDSCAPE_1280" />
    "Potwierdzamy, że spółka złożyła w tej sprawie pozew".

## Groził matce spaleniem domu, podpalił słomę i wsiadł na skuter. Pijany 18-latek zatrzymany
 - [https://tvn24.pl/tvnwarszawa/okolice/powiat-mlawski-na-mazowszu-pijany-18-latek-grozil-matce-ze-spali-dom-uciekal-przed-policjantami-skuterem-7295341?source=rss](https://tvn24.pl/tvnwarszawa/okolice/powiat-mlawski-na-mazowszu-pijany-18-latek-grozil-matce-ze-spali-dom-uciekal-przed-policjantami-skuterem-7295341?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:41:27+00:00

<img alt="Groził matce spaleniem domu, podpalił słomę i wsiadł na skuter. Pijany 18-latek zatrzymany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-265p5p-407-wypadkow-45-ofiar-i-463-osoby-ranne-tragiczny-bilans-drogowy-po-dlugim-weekendzie-7287715/alternates/LANDSCAPE_1280" />
    Grozi mu kara do pięciu lat pozbawienia wolności.

## Jest projekt budowy nowego szpitala, ale nie ma pieniędzy. Miasto czeka na środki z KPO
 - [https://tvn24.pl/katowice/gliwice-jest-projekt-budowy-nowego-szpitala-ale-nie-ma-pieniedzy-miasto-czeka-na-srodki-z-kpo-7295087?source=rss](https://tvn24.pl/katowice/gliwice-jest-projekt-budowy-nowego-szpitala-ale-nie-ma-pieniedzy-miasto-czeka-na-srodki-z-kpo-7295087?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:39:56+00:00

<img alt="Jest projekt budowy nowego szpitala, ale nie ma pieniędzy. Miasto czeka na środki z KPO " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t2p9fs-w-gliwicach-moze-powstac-nowoczesny-szpital-wizualizacja-7295118/alternates/LANDSCAPE_1280" />
    "Liczymy na to, że kolejny rząd będzie w stanie porozumieć się z Brukselą."

## Był taki szybki, że podejrzewano awarię stopera
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2022/marek-zakrzewski-wielki-talent-w-biegu-na-100-i-200-m.-tomasz-czubak-jego-trener-marek-zasluzyl-na-m_sto9745013/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2022/marek-zakrzewski-wielki-talent-w-biegu-na-100-i-200-m.-tomasz-czubak-jego-trener-marek-zasluzyl-na-m_sto9745013/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:39:00+00:00

<img alt="Był taki szybki, że podejrzewano awarię stopera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ybm6xu-marek-zakrzewski-wielka-nadzieja-polskiego-sprintu-7295377/alternates/LANDSCAPE_1280" />
    Sprinter Marek Zakrzewski, ma zaledwie 17 lat, wynikami już zadziwia.

## Kraje z najbogatszymi mieszkańcami. Zmiana na czele rankingu
 - [https://tvn24.pl/biznes/ze-swiata/belgia-i-szwajcaria-najbogatsi-mieszkancy-milionerzy-global-wealth-report-2023-7295002?source=rss](https://tvn24.pl/biznes/ze-swiata/belgia-i-szwajcaria-najbogatsi-mieszkancy-milionerzy-global-wealth-report-2023-7295002?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:34:22+00:00

<img alt="Kraje z najbogatszymi mieszkańcami. Zmiana na czele rankingu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fqx8vk-brugia-7282730/alternates/LANDSCAPE_1280" />
    Według "Global Wealth Report".

## Dzieci bez opieki, zderzenie ze skuterem, race na łodzi. 40 interwencji WOPR w długi weekend nad Zegrzem
 - [https://tvn24.pl/tvnwarszawa/okolice/jezioro-zegrzynskie-40-interwencji-wopr-w-dlugi-weekend-czego-dotyczyly-7295201?source=rss](https://tvn24.pl/tvnwarszawa/okolice/jezioro-zegrzynskie-40-interwencji-wopr-w-dlugi-weekend-czego-dotyczyly-7295201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T08:25:24+00:00

<img alt="Dzieci bez opieki, zderzenie ze skuterem, race na łodzi. 40 interwencji WOPR w długi weekend nad Zegrzem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6he8r2-legionowskie-wopr-podsumowalo-dlugi-weekend-7295218/alternates/LANDSCAPE_1280" />
    Legionowscy ratownicy apelują o rozwagę.

## Dochodzenie w słynnym muzeum. Z magazynu zniknęły "złota biżuteria i klejnoty"
 - [https://tvn24.pl/swiat/wielka-brytania-cenne-przedmioty-z-kolekcji-muzeum-brytyjskiego-zaginely-zostaly-skradzione-lub-uszkodzone-7294969?source=rss](https://tvn24.pl/swiat/wielka-brytania-cenne-przedmioty-z-kolekcji-muzeum-brytyjskiego-zaginely-zostaly-skradzione-lub-uszkodzone-7294969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:55:13+00:00

<img alt="Dochodzenie w słynnym muzeum. Z magazynu zniknęły " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qah4bp-muzeum-brytyjskie-british-museum-london-londyn-uk-wielka-brytania-shutterstock_470203151-7295101/alternates/LANDSCAPE_1280" />
    "Bardzo nietypowy incydent".

## Gorąco topiło samochody. "Jest bezpieczne okno czasowe na opuszczenie miasta"
 - [https://tvn24.pl/tvnmeteo/swiat/kanada-goraco-topilo-samochody-jest-bezpieczne-okno-czasowe-na-opuszczenie-miasta-7294910?source=rss](https://tvn24.pl/tvnmeteo/swiat/kanada-goraco-topilo-samochody-jest-bezpieczne-okno-czasowe-na-opuszczenie-miasta-7294910?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:53:14+00:00

<img alt="Gorąco topiło samochody. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9upy3-pozary-w-kanadzie-7295173/alternates/LANDSCAPE_1280" />
    Ogień trawi północną Kanadę.

## Ślady na zdjęciach satelitarnych. Chiny budują na spornej wyspie
 - [https://tvn24.pl/swiat/tajwan-agencja-ap-chiny-buduja-lotnisko-na-spornej-wyspie-trition-7294904?source=rss](https://tvn24.pl/swiat/tajwan-agencja-ap-chiny-buduja-lotnisko-na-spornej-wyspie-trition-7294904?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:52:21+00:00

<img alt="Ślady na zdjęciach satelitarnych. Chiny budują na spornej wyspie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ptawck-na-wyspie-trition-powstaje-chinskie-lotnisko-7294958/alternates/LANDSCAPE_1280" />
    Przekazała agencja Associated Press.

## Rosjanie "wywołują prawdziwe ryzyko eskalacji do wojny morskiej" z NATO
 - [https://tvn24.pl/swiat/ukraina-byly-dowodca-sil-nato-w-europie-rosja-ryzykuje-wojna-z-nato-na-morzu-czarnym-7295091?source=rss](https://tvn24.pl/swiat/ukraina-byly-dowodca-sil-nato-w-europie-rosja-ryzykuje-wojna-z-nato-na-morzu-czarnym-7295091?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:37:26+00:00

<img alt="Rosjanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xnedrc-wladimir-putin-wizytuje-flote-czarnomorska-zdjecie-archiwalne-6230928/alternates/LANDSCAPE_1280" />
    Ocenił były naczelny dowódca sił zbrojnych NATO w Europie (SACEUR).

## Koniec małżeństwa Britney Spears. Media: Sam Asghari wniósł pozew o rozwód
 - [https://tvn24.pl/kultura-i-styl/britney-spears-maz-piosenkarki-sam-asghari-wniosl-pozew-o-rozwod-twierdza-media-7295145?source=rss](https://tvn24.pl/kultura-i-styl/britney-spears-maz-piosenkarki-sam-asghari-wniosl-pozew-o-rozwod-twierdza-media-7295145?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:27:06+00:00

<img alt="Koniec małżeństwa Britney Spears. Media: Sam Asghari wniósł pozew o rozwód" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hx0k6m-britney-spears-i-sam-asghari-5745393/alternates/LANDSCAPE_1280" />
    Małżeństwo piosenkarki i modela trwało 14 miesięcy.

## Szalona ucieczka 20-letniego pirata drogowego. W aucie wiózł niemowlaka. Nagranie
 - [https://tvn24.pl/poznan/slubice-poscig-za-piratem-drogowym-wiozl-niemowle-dostal-241-punktow-karnych-nagranie-7295083?source=rss](https://tvn24.pl/poznan/slubice-poscig-za-piratem-drogowym-wiozl-niemowle-dostal-241-punktow-karnych-nagranie-7295083?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:02:55+00:00

<img alt="Szalona ucieczka 20-letniego pirata drogowego. W aucie wiózł niemowlaka. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2269li-kierowca-zostal-aresztowany-7295084/alternates/LANDSCAPE_1280" />
    Dostał 241 punktów karnych.

## Koalicja Obywatelska rozpoczyna zbieranie podpisów
 - [https://tvn24.pl/wybory-parlamentarne-2023/koalicja-obywatelska-rozpoczyna-zbieranie-podpisow-na-wybory-2023-borys-budka-to-wazne-by-juz-na-pierwszym-etapie-pokazac-sile-7295070?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/koalicja-obywatelska-rozpoczyna-zbieranie-podpisow-na-wybory-2023-borys-budka-to-wazne-by-juz-na-pierwszym-etapie-pokazac-sile-7295070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T07:01:07+00:00

<img alt="Koalicja Obywatelska rozpoczyna zbieranie podpisów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pvulz1-szef-ko-borys-budka-i-politycy-koalicji-na-konferencji-przed-wejsciem-do-stacji-metra-centrum-w-warszawie-7295134/alternates/LANDSCAPE_1280" />
    Ogłosił szef klubu KO Borys Budka.

## Polskie kluby walczą o Ligę Konferencji. O której dziś mecze?
 - [https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/legia-lech-i-pogon-graja-rewanze-w-3.-rundzie-eliminacji-ligi-konferencji-kiedy-i-o-ktorej-mecze_sto9746002/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/uefa-europa-conference-league/2023-2024/legia-lech-i-pogon-graja-rewanze-w-3.-rundzie-eliminacji-ligi-konferencji-kiedy-i-o-ktorej-mecze_sto9746002/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:44:00+00:00

<img alt="Polskie kluby walczą o Ligę Konferencji. O której dziś mecze?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aycazy-lech-legia-i-pogon-graja-w-trzeciej-rundzie-eliminacji-7278038/alternates/LANDSCAPE_1280" />
    Bardzo ważny czwartek dla naszego futbolu. Lech, Legia i Pogoń zagrają rewanże 3. rundy eliminacji Ligi Konferencji.

## Nie żyje Jan Greber. Aktor, znany z seriali "Zmiennicy" czy "07 zgłoś się", miał 83 lata
 - [https://tvn24.pl/kultura-i-styl/jan-greber-nie-zyje-aktor-mial-83-lata-7295027?source=rss](https://tvn24.pl/kultura-i-styl/jan-greber-nie-zyje-aktor-mial-83-lata-7295027?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:38:51+00:00

<img alt="Nie żyje Jan Greber. Aktor, znany z seriali " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t96sfq-jan-greber-7295038/alternates/LANDSCAPE_1280" />
    "Zawsze pomocny i wrażliwy na potrzeby środowiska artystycznego".

## Ogień na Teneryfie, ewakuacje ludności. "Sytuacja wymknęła się spod kontroli"
 - [https://tvn24.pl/tvnmeteo/swiat/wyspy-kanaryjskie-teneryfa-plomienie-blisko-atrakcji-turystycznych-sytuacja-wymknela-sie-spod-kontroli-7294971?source=rss](https://tvn24.pl/tvnmeteo/swiat/wyspy-kanaryjskie-teneryfa-plomienie-blisko-atrakcji-turystycznych-sytuacja-wymknela-sie-spod-kontroli-7294971?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:36:53+00:00

<img alt="Ogień na Teneryfie, ewakuacje ludności. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-px9hd0-ogien-szaleje-na-teneryfie-7295054/alternates/LANDSCAPE_1280" />
    Pożar szaleje od wtorku.

## Nowy asfalt na rondzie Radosława. "Największe frezowanie w tym roku"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-rondzie-radoslawa-ulozyli-11-tysiecy-metrow-kwadratowych-asfaltu-7294995?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-na-rondzie-radoslawa-ulozyli-11-tysiecy-metrow-kwadratowych-asfaltu-7294995?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:30:13+00:00

<img alt="Nowy asfalt na rondzie Radosława. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-t7xe3c-zmiany-na-rondzie-radoslawa-7294975/alternates/LANDSCAPE_1280" />
    Trwa jeszcze naprawa chodników i dróg dla rowerów wokół ronda.

## Dwa słowa od Ryszarda Terleckiego. Uchwyciły je mikrofony
 - [https://tvn24.pl/polska/sejm-interwencja-ryszarda-terleckiego-u-marszalek-sejmu-elzbiety-witek-w-sprawie-poslow-lewicy-7295058?source=rss](https://tvn24.pl/polska/sejm-interwencja-ryszarda-terleckiego-u-marszalek-sejmu-elzbiety-witek-w-sprawie-poslow-lewicy-7295058?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:29:27+00:00

<img alt="Dwa słowa od Ryszarda Terleckiego. Uchwyciły je mikrofony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jwc6et-ryszard-terlecki-interweniowal-u-marszalek-witek-7295056/alternates/LANDSCAPE_1280" />
    W sprawie posłów Lewicy.

## Sejm zdecyduje dziś o referendum. Najpierw debata, później głosowanie
 - [https://tvn24.pl/wybory-parlamentarne-2023/referendum-w-dniu-wyborow-2023-debata-i-glosowanie-nad-wnioskiem-w-sprawie-zarzadzenia-referendum-w-sejmie-7294998?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/referendum-w-dniu-wyborow-2023-debata-i-glosowanie-nad-wnioskiem-w-sprawie-zarzadzenia-referendum-w-sejmie-7294998?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T06:21:41+00:00

<img alt="Sejm zdecyduje dziś o referendum. Najpierw debata, później głosowanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-46uq9b-sejm-16-sierpnia-2023-7295049/alternates/LANDSCAPE_1280" />
    Referendum miałoby odbyć się w dniu wyborów parlamentarnych, czyli 15 października.

## Biedroń: dzisiaj o 11 podpisanie paktu senackiego
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-robert-biedron-o-pakcie-senackim-7295013?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-robert-biedron-o-pakcie-senackim-7295013?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:57:21+00:00

<img alt="Biedroń: dzisiaj o 11 podpisanie paktu senackiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sgiuvu-17-0730-1na1-cl-0005-7294983/alternates/LANDSCAPE_1280" />
    Europoseł, współprzewodniczący Lewicy był gościem Agaty Adamek.

## Ta droga nie wybacza błędów. Wracamy na trasę 631
 - [https://tvn24.pl/premium/trasa-631-na-mazowszu-liczba-ofiar-plany-przebudowy-7287063?source=rss](https://tvn24.pl/premium/trasa-631-na-mazowszu-liczba-ofiar-plany-przebudowy-7287063?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:56:43+00:00

<img alt="Ta droga nie wybacza błędów. Wracamy na trasę 631" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ofje4p-na-trasie-zginelo-juz-kilkadziesiat-osob-7287555/alternates/LANDSCAPE_1280" />
    Urzędnicy mają pomysł na poprawę bezpieczeństwa. Czy będzie skuteczny?

## Ukraina nie zostanie zaproszona na szczyt G20 w Delhi
 - [https://tvn24.pl/swiat/indie-ukraina-nie-zostanie-zaproszona-na-szczytg20w-delhi-szef-msz-indii-wyjasnia-powod-7294881?source=rss](https://tvn24.pl/swiat/indie-ukraina-nie-zostanie-zaproszona-na-szczytg20w-delhi-szef-msz-indii-wyjasnia-powod-7294881?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:53:43+00:00

<img alt="Ukraina nie zostanie zaproszona na szczyt G20 w Delhi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-68jw6o-wolodymyr-zelenski-i-andrij-jermak-z-ukrainskimi-zolnierzami-7293437/alternates/LANDSCAPE_1280" />
    Oświadczył szef indyjskiego MSZ Subrahmanyam Jaishankar.

## Niemal 100 tysięcy złotych na kilometrówkę, choć w oświadczeniach nie ma auta. Wydatki minister Sójki
 - [https://tvn24.pl/polska/katarzyna-sojka-nowa-minister-zdrowia-wp-wydala-niemal-100-tysiecy-na-kilometrowke-choc-w-oswiadczeniach-nie-ma-auta-7294946?source=rss](https://tvn24.pl/polska/katarzyna-sojka-nowa-minister-zdrowia-wp-wydala-niemal-100-tysiecy-na-kilometrowke-choc-w-oswiadczeniach-nie-ma-auta-7294946?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:49:16+00:00

<img alt="Niemal 100 tysięcy złotych na kilometrówkę, choć w oświadczeniach nie ma auta. Wydatki minister Sójki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fmy2zd-minister-zdrowia-katarzyna-sojka-7294959/alternates/LANDSCAPE_1280" />
    Ustaliła Wirtualna Polska.

## Bardzo niewygodny rywal na drodze Hurkacza. O której dzisiaj mecz Polaka?
 - [https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/hubert-hurkacz-stefanos-tsitsipas-kiedy-i-o-ktorej-mecz-gdzie-relacja-online-montreal-2023_sto9745939/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/hubert-hurkacz-stefanos-tsitsipas-kiedy-i-o-ktorej-mecz-gdzie-relacja-online-montreal-2023_sto9745939/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:31:45+00:00

<img alt="Bardzo niewygodny rywal na drodze Hurkacza. O której dzisiaj mecz Polaka?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pz5e9q-hurkacz-tym-razem-pokona-tsistipasa-7294992/alternates/LANDSCAPE_1280" />
    Hubert Hurkacz kontra Stefanos Tsitsipas w Cincinnati. Kiedy i o której mecz?

## "Najgorsze, co może być, to jest cierpienie pożegnań"
 - [https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-getcie-w-bialymstoku-dyskusja-z-udzialem-marka-brzezinskiego-mariana-turskiego-leah-pisar-haas-i-ryszarda-schnepfa-7294829?source=rss](https://tvn24.pl/polska/80-rocznica-wybuchu-powstania-w-getcie-w-bialymstoku-dyskusja-z-udzialem-marka-brzezinskiego-mariana-turskiego-leah-pisar-haas-i-ryszarda-schnepfa-7294829?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:29:14+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2jwl7u-marian-turski-7294841/alternates/LANDSCAPE_1280" />
    Dyskusja wokół książki "Z krwi i nadziei" Samuela Pisara - polsko-amerykańskiego pisarza ocalałego z zagłady.

## Szef sił NATO w Europie i pierwszy żołnierz Wielkiej Brytanii z wizytą w Ukrainie
 - [https://tvn24.pl/swiat/ukraina-szef-sil-nato-w-europie-i-pierwszy-zolnierz-wielkiej-brytanii-spotkali-sie-z-ukrainskim-dowodztwem-7294928?source=rss](https://tvn24.pl/swiat/ukraina-szef-sil-nato-w-europie-i-pierwszy-zolnierz-wielkiej-brytanii-spotkali-sie-z-ukrainskim-dowodztwem-7294928?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:18:10+00:00

<img alt="Szef sił NATO w Europie i pierwszy żołnierz Wielkiej Brytanii z wizytą w Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4tcfle-zachodni-dowodcy-z-wizyta-w-ukrainie-7294938/alternates/LANDSCAPE_1280" />
    Spotkali się z ukraińskim dowództwem.

## Woda zalała płytę lotniska we Frankfurcie. Ciąg dalszy utrudnień
 - [https://tvn24.pl/tvnmeteo/swiat/frankfurt-niemcy-woda-zebrala-sie-na-plycie-lotniska-pasazerowie-powinni-sprawdzic-godziny-lotow-7294932?source=rss](https://tvn24.pl/tvnmeteo/swiat/frankfurt-niemcy-woda-zebrala-sie-na-plycie-lotniska-pasazerowie-powinni-sprawdzic-godziny-lotow-7294932?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:17:38+00:00

<img alt="Woda zalała płytę lotniska we Frankfurcie. Ciąg dalszy utrudnień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m3ur2-twitter-7294945/alternates/LANDSCAPE_1280" />
    Ulewy we Frankfurcie nad Menem.

## "Afera rozporkowa". 25 lat temu Bill Clinton przyznał się do romansu z Monicą Lewinsky
 - [https://tvn24.pl/swiat/usa-bill-clinton-przyznal-sie-do-romansu-z-monica-lewinsky-25-lat-temu-afera-rozporkowa-7293604?source=rss](https://tvn24.pl/swiat/usa-bill-clinton-przyznal-sie-do-romansu-z-monica-lewinsky-25-lat-temu-afera-rozporkowa-7293604?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:15:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r90jdi-bill-2-to-byl-news-2023-7294132/alternates/LANDSCAPE_1280" />
    "Niewłaściwe relacje intymne" z młodą stażystką niemal pozbawiły go urzędu.

## "Cenny element lokalnej historii ulicy". Kamienica przy Grójeckiej 184 w rejestrze zabytków
 - [https://tvn24.pl/tvnwarszawa/ochota/warszawa-obok-toczyly-sie-walki-powstancze-kamienica-przy-grojeckiej-184-w-rejestrze-zabytkow-7294922?source=rss](https://tvn24.pl/tvnwarszawa/ochota/warszawa-obok-toczyly-sie-walki-powstancze-kamienica-przy-grojeckiej-184-w-rejestrze-zabytkow-7294922?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:01:48+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-k6n7vh-kamienica-przy-grojeckiej-184-w-rejestrze-zabytkow-7294916/alternates/LANDSCAPE_1280" />
    Uniknie rozbiórki.

## "Każdy, kto oddaje krew, jest cichym bohaterem"
 - [https://tvn24.pl/programy/apel-o-oddawanie-krwi-kazdy-kto-ja-oddaje-jest-cichym-bohaterem-7294856?source=rss](https://tvn24.pl/programy/apel-o-oddawanie-krwi-kazdy-kto-ja-oddaje-jest-cichym-bohaterem-7294856?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T05:00:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3608jt-apel-o-oddawanie-krwi-5152365/alternates/LANDSCAPE_1280" />
    Jest potrzebna szczególnie w wakacje.

## Na Białorusi zarejestrowano spółkę pod nazwą Grupa Wagner. "Inne rodzaje kształcenia"
 - [https://tvn24.pl/swiat/bialorus-grupa-wagnera-zarejestrowano-spolke-pod-nazwa-grupa-wagner-ma-swiadczyc-uslugi-szkoleniowe-7294875?source=rss](https://tvn24.pl/swiat/bialorus-grupa-wagnera-zarejestrowano-spolke-pod-nazwa-grupa-wagner-ma-swiadczyc-uslugi-szkoleniowe-7294875?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T04:49:28+00:00

<img alt="Na Białorusi zarejestrowano spółkę pod nazwą Grupa Wagner. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nap5fg-en_01591629_0932-1-7294929/alternates/LANDSCAPE_1280" />
    To już druga firma zarejestrowana w tym kraju przez Jewgienija Prigożyna.

## "Na boisku jesteśmy tacy jak inni". Ampfutbolowy Junior Camp wraca do Polski
 - [https://tvn24.pl/programy/ampfutbolowy-junior-camp-wraca-do-polski-na-boisku-jestesmy-tacy-jak-inni-7294853?source=rss](https://tvn24.pl/programy/ampfutbolowy-junior-camp-wraca-do-polski-na-boisku-jestesmy-tacy-jak-inni-7294853?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T04:49:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jutex8-ampfutbolisci-7294855/alternates/LANDSCAPE_1280" />
    To podczas tych zgrupowań wychowywały się największe gwiazdy europejskiego ampfutbolu.

## Kolejny polityk nie żyje, został zastrzelony w swoim domu
 - [https://tvn24.pl/swiat/ekwador-wybory-prezydenckie-kolejny-polityk-zabity-pedro-briones-zastrzelony-we-wlasnym-domu-7294876?source=rss](https://tvn24.pl/swiat/ekwador-wybory-prezydenckie-kolejny-polityk-zabity-pedro-briones-zastrzelony-we-wlasnym-domu-7294876?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T04:19:36+00:00

<img alt="Kolejny polityk nie żyje, został zastrzelony w swoim domu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-stmz5x-stan-wyjatkowy-w-ekwadorze-7294877/alternates/LANDSCAPE_1280" />
    Przed wyborami w Ekwadorze.

## Polska kandydatka do medalu: wszystko wskazuje, że będę w lepszej formie
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-natalia-kaczmarek-o-przygotowaniach-formie-i-meda_sto9745325/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-natalia-kaczmarek-o-przygotowaniach-formie-i-meda_sto9745325/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T04:12:29+00:00

<img alt="Polska kandydatka do medalu: wszystko wskazuje, że będę w lepszej formie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tq4a5d-natalia-kaczmarek-7294908/alternates/LANDSCAPE_1280" />
    Zapowiada w rozmowie z Eurosportem Natalia Kaczmarek.

## "Jeżeli tu zostaniemy, zrobią nam pranie mózgu"
 - [https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1254,S00E1254,1137960?source=rss](https://tvn24.pl/go/programy,7/filmy-dokumentalne-odcinki,74501/odcinek-1254,S00E1254,1137960?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T04:00:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9zlzy8-hongkong-zycie-pod-opresja-7294851/alternates/LANDSCAPE_1280" />
    W filmie dla BBC News World Service korespondent Danny Vincent śledzi losy tych, którzy przeżyli protesty uliczne w Hongkongu.

## Wzrosła liczba ofiar eksplozji w San Cristobal. Prezydent ogłosił dzień żałoby narodowej
 - [https://tvn24.pl/swiat/dominikana-san-cristobal-eksplozja-ofiary-nagranie-z-miejsca-zdarzenia-7293416?source=rss](https://tvn24.pl/swiat/dominikana-san-cristobal-eksplozja-ofiary-nagranie-z-miejsca-zdarzenia-7293416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T03:47:00+00:00

<img alt="Wzrosła liczba ofiar eksplozji w San Cristobal. Prezydent ogłosił dzień żałoby narodowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-p40dje-skutki-eksplozji-na-targu-w-dominikanskim-san-cristobal-7293423/alternates/LANDSCAPE_1280" />
    Do wybuchu doszło na hali targowej.

## Co wydarzyło się w Ukrainie w czasie ostatniej doby
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-17-sierpnia-2023-7294885?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-17-sierpnia-2023-7294885?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T03:35:25+00:00

<img alt="Co wydarzyło się w Ukrainie w czasie ostatniej doby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4rs09m-ukraina-zolnierz-ukrainski-zolnierz-7279591/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja trwa od 540 dni.

## Znamy kandydatów KO, ostrzeżenie przed pogodą, karne w Superpucharze Europy
 - [https://tvn24.pl/polska/piecrzeczy-ktore-warto-wiedziec-17-sierpnia-2023-roku-7294883?source=rss](https://tvn24.pl/polska/piecrzeczy-ktore-warto-wiedziec-17-sierpnia-2023-roku-7294883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T03:30:25+00:00

<img alt="Znamy kandydatów KO, ostrzeżenie przed pogodą, karne w Superpucharze Europy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wy9l4v-23816060-7293780/alternates/LANDSCAPE_1280" />
    Pięć rzeczy, które warto wiedzieć 17 sierpnia.

## Sytuacja "coraz trudniejsza", ale podjęto "kilka ważnych decyzji", które wzmocnią ukraińską obronę
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-czwartek-17-sierpnia-2023-roku-7294887?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-czwartek-17-sierpnia-2023-roku-7294887?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-17T03:18:28+00:00

<img alt="Sytuacja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-glwt79-ukraina-wojsko-7290658/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

