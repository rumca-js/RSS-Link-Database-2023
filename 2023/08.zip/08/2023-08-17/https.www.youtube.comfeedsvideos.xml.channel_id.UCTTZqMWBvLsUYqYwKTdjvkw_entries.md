# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 🇵🇱 Mamy wreszcie swoje CNA!
 - [https://www.youtube.com/watch?v=j3nrEdHe9yg](https://www.youtube.com/watch?v=j3nrEdHe9yg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-08-17T04:00:19+00:00

Mamy w końcu swoje CNA! Ale o co właściwie chodzi?
 
Źródła:
https://tinyurl.com/m5dpjdbj

 
#CERT #Polska #CVE #CNA

