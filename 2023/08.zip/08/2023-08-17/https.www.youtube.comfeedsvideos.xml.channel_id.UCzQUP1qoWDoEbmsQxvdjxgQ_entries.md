# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Will Gas Powered Vehicles Ever Be Outlawed?
 - [https://www.youtube.com/watch?v=ovDuX-qRn8M](https://www.youtube.com/watch?v=ovDuX-qRn8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-08-17T17:07:50+00:00

Taken from JRE #2022 w/Jeremy Gerber, Phil Gerber, and Josh Henning:
https://open.spotify.com/episode/62tozdFpzt1iSmia1KlCfm?si=df7095750c48439e

