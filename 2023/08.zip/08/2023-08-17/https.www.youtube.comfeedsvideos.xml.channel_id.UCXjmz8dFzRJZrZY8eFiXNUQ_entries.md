# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## the mcu's big marvel problem #shorts
 - [https://www.youtube.com/watch?v=AtR5py3zrl4](https://www.youtube.com/watch?v=AtR5py3zrl4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-08-17T15:00:06+00:00

Check Out the Full Video: https://youtu.be/gQmoyeYgL0I

Subscribe to Nerdstalgic! https://www.youtube.com/@UCXjmz8dFzRJZrZY8eFiXNUQ 

#marvel #marvelcinematicuniverse #mcu #phase5 #phase4 #disneyplus #comics #comicbooks #nerdstalgic

