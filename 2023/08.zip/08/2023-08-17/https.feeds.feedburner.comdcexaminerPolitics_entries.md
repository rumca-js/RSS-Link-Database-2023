# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## Republican Brad Chambers joins packed Indiana governor race
 - [https://www.washingtonexaminer.com/news/campaigns/republican-brad-chambers-joins-packed-indiana-governor-race](https://www.washingtonexaminer.com/news/campaigns/republican-brad-chambers-joins-packed-indiana-governor-race)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-08-17T22:26:39+00:00

The former Indiana secretary of commerce announced he’s entered the state's 2024 governor's race, jumping into an already crowded Republican field.

