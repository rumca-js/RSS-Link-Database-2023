# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Defending the apostrophe
 - [https://seths.blog/2023/08/defending-the-apostrophe/](https://seths.blog/2023/08/defending-the-apostrophe/)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-08-17T08:19:00+00:00

Does it need defending? The sign on some bushes near a park in my town says, Beware: Bee&#8217;s. A local merchant adds a note to some receipts that says, Your awesome. It&#8217;s tempting to speak up and point out that the sky comma is showing up where it shouldn&#8217;t. And missing when it might be [&#8230;]

