# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## How to Pack an Entire, Comfortable Campsite Into a Backpack
 - [https://www.wsj.com/articles/how-to-pack-an-entire-comfortable-campsite-into-a-backpack-eb559d2b?mod=rss_Technology](https://www.wsj.com/articles/how-to-pack-an-entire-comfortable-campsite-into-a-backpack-eb559d2b?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-08-17T18:00:00+00:00

Ten lightweight, compressible and collapsible essentials for your next outdoor adventure

## Match Group and Background-Checking Nonprofit End Safety Partnership
 - [https://www.wsj.com/articles/tinder-match-group-background-checks-nonprofit-end-46779f8b?mod=rss_Technology](https://www.wsj.com/articles/tinder-match-group-background-checks-nonprofit-end-46779f8b?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-08-17T16:42:00+00:00

After a news report that sex offenders were using its dating apps, the company funded a nonprofit tool meant to protect users. Now that tool is shutting down.

## Microsoft Struggles to Gain on Google Despite Its Head Start in AI Search
 - [https://www.wsj.com/articles/microsoft-bing-search-artificial-intelligence-google-competition-6e51ec04?mod=rss_Technology](https://www.wsj.com/articles/microsoft-bing-search-artificial-intelligence-google-competition-6e51ec04?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-08-17T12:00:00+00:00

The new Bing with an AI chatbot is called “cute, but not a game changer.”

## Alphabet's Verily Plans Cost Cuts Amid Pressure on Other Bets to Rein In Spending
 - [https://www.wsj.com/articles/alphabets-verily-plans-cost-cuts-amid-pressure-on-other-bets-to-rein-in-spending-fe7b3fa?mod=rss_Technology](https://www.wsj.com/articles/alphabets-verily-plans-cost-cuts-amid-pressure-on-other-bets-to-rein-in-spending-fe7b3fa?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-08-17T03:26:00+00:00

Google’s parent is focusing on turning companies that are developing ambitious technology into commercial successes.

