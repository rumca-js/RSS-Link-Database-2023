# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## A Letter Prompted Talk of AI Doomsday. Many Who Signed Weren't Actually AI Doomers
 - [https://www.wired.com/story/letter-prompted-talk-of-ai-doomsday-many-who-signed-werent-actually-doomers/](https://www.wired.com/story/letter-prompted-talk-of-ai-doomsday-many-who-signed-werent-actually-doomers/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-08-17T16:00:00+00:00

In March a viral letter called for a pause on AI development, warning that algorithms could outsmart humanity—but many experts who signed on did not believe the technology poses an existential risk.

## Fake Meat Is Bleeding, but It’s Not Dead Yet
 - [https://www.wired.com/story/beyond-plant-based-meat/](https://www.wired.com/story/beyond-plant-based-meat/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-08-17T06:00:00+00:00

Beyond Meat’s weak sales led to headlines about “peak veganism” and the end of plant-based meats. But demand in Europe shows there’s still life in alternative proteins.

