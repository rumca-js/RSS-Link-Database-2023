# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## Already 2.2 Million Have USED THIS!!
 - [https://www.youtube.com/watch?v=14y5kyntSSU](https://www.youtube.com/watch?v=14y5kyntSSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-08-17T23:00:00+00:00



## Maui Hawaii Fires - What REALLY Happened?
 - [https://www.youtube.com/watch?v=VShhVJZyUrM](https://www.youtube.com/watch?v=VShhVJZyUrM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-08-17T17:00:17+00:00

Visit https://www.expressvpn.com/BRAND to get three extra months free

Claims about the deadly wildfires in Hawaii - blaming celebrity “elites” including Bill Gates for orchestrating the disaster with a laser beam – have been dubbed “disgusting conspiracy theories”. But, as with all conspiracies, is there any basis to them? And is an elite landgrab occurring independently of this disaster? #hawaii #fire #disaster 
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## HOLY SH*T…HAWAII BURNS! But Are The Conspiracies TRUE?! - Stay Free #192 PREVIEW
 - [https://www.youtube.com/watch?v=_BXeQczxqXs](https://www.youtube.com/watch?v=_BXeQczxqXs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-08-17T13:51:44+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE: https://bit.ly/stayfree-192-Hawaii

TODAY - The cultural revolt over the country singer who’s gone viral, Oliver Anthony. YouTube are changing their policy over medical misinformation. PLUS, We look at the conspiracy theories around the wildfires in Maui.

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Join us at 'Community 2024' https://www.russellbrand.com/community/

Join The STAY FREE Community: https://russellbrand.locals.com/

NEW MERCH! https://stuff.russellbrand.com/

