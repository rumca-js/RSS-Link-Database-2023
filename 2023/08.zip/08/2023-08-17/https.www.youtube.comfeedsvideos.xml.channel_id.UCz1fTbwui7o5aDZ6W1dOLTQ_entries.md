# Source:Literature Devil, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ, language:en-US

## Morning Nonsense: Return to the Golden Age!
 - [https://www.youtube.com/watch?v=fGgLF2KSHUc](https://www.youtube.com/watch?v=fGgLF2KSHUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCz1fTbwui7o5aDZ6W1dOLTQ
 - date published: 2023-08-17T06:46:44+00:00

MAIN RULE: Please do NOT attack or insult other members of the chat with superchats.

Get Dr. Alpha: Dead Man's Lullaby: https://www.indiegogo.com/projects/dr-alpha-dead-man-s-lullaby-vol-1/coming_soon/x/22169562

Dr. Alpha: Miracle Child on Amazon: https://www.amazon.com/dp/B0B7F95YF3

Rumble: https://rumble.com/c/c-2621304

MUSIC:
There You Are (POGO): https://www.youtube.com/watch?v=5tOAZkrkuVA
Surrender (First to Eleven): https://www.youtube.com/watch?v=nUk6ARY7dSg
Walk Like An Egyptian (Bangles): https://www.youtube.com/watch?v=tMnGmoLS6zo
Saturday Night's Alright for Fighting (Elton John): https://www.youtube.com/watch?v=26wEWSUUsUc
Smells Like Teen Spirit Major Key (Nirvana/Sleep Good): https://www.youtube.com/watch?v=dVehv_LDWaE
Surface Pressure JoJo Remix (Thai McGrath): https://www.youtube.com/watch?v=MVOrUkLOEOI
Segata Sanshiro: https://www.youtube.com/watch?v=POkU70cjYI8
Out to Lunch: https://www.youtube.com/watch?v=Vn1pf0Xi3nU
Walking Around in Circles: https://www.youtube.com/watch?v=S0-coASIjkQ
Gorilla for Sale: https://www.youtube.com/watch?v=r_oaVD4NzYo
Feather&amp;BigPoppa by Chillappines g2ollopA: https://www.youtube.com/watch?v=FsB5LiqXERE&amp;list=RDMMulfeM8JGq7s&amp;index=24
Dirty Deeds by Joan Jett: https://www.youtube.com/watch?v=4Ikf3gclG7w


STREAMLABS Link: https://streamlabs.com/literaturedevil

Twitch: https://www.twitch.tv/literaturedevil

Thumbnail: Nerd Wonder

Minds: https://www.minds.com/literaturedevil/

Twitter: https://twitter.com/literaturedevil

Discord server: https://discord.gg/CYZZTFS

Fight Censorship shirt (Color): https://teespring.com/fight-censorship-color?pid=387&amp;cid=100163&amp;sid=front

Fight Censorship: https://teespring.com/new-fight-censorship?pid=387&amp;cid=101810&amp;sid=front

Fight Censorship Mask: https://teespring.com/fight-censprship-mask?pid=972&amp;cid=103974

Fight Censorship Mug (colored): https://teespring.com/fight-censorship-mug-colored?pid=658&amp;cid=102908

Fight Censorship Mug: https://teespring.com/fight-censorship-mug-black?pid=658&amp;cid=102950

SubscribeStar: https://www.subscribestar.com/literature-devil

Smudboy: https://www.youtube.com/user/smudboy
Shiney FX:https://www.youtube.com/channel/UCS4jTMx3GHWZLlT7Rqy5GTQ
Voice in the Radio: https://www.youtube.com/channel/UCvc8Ikvyuj_lHNWAo4Gu_lg
Glib: https://www.youtube.com/channel/UC9zuyLdn1FncxrKnDuErYeA
Lord Commander Dunn: https://www.youtube.com/channel/UCbRyEIfMmJ2oWUMyOlrg4CA

Reylo Tears Mug (White): https://teespring.com/reylo-tears-mug-white?pid=658&amp;cid=102908

Reylo Tears Mug (Black): https://teespring.com/reylo-tears-mug-black?pid=658&amp;cid=102950

