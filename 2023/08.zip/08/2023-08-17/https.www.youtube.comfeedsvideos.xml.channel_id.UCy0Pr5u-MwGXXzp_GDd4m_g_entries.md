# Source:Julie Nolke, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g, language:en-US

## Romeo and... Nancy?!
 - [https://www.youtube.com/watch?v=0kGsHrKa_Yc](https://www.youtube.com/watch?v=0kGsHrKa_Yc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCy0Pr5u-MwGXXzp_GDd4m_g
 - date published: 2023-08-17T13:00:02+00:00



