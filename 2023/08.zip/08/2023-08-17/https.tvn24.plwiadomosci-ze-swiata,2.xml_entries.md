# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## 3-letnie dziecko przyszło do przedszkola z pistoletem w plecaku. Ojciec z zarzutami
 - [https://tvn24.pl/swiat/usa-pistolet-w-plecaku-3-letniego-dziecka-w-przedszkolu-ojciec-z-zarzutami-7295160?source=rss](https://tvn24.pl/swiat/usa-pistolet-w-plecaku-3-letniego-dziecka-w-przedszkolu-ojciec-z-zarzutami-7295160?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-08-17T09:33:43+00:00

<img alt="3-letnie dziecko przyszło do przedszkola z pistoletem w plecaku. Ojciec z zarzutami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n7ct7o-w-plecakach-znajda-sie-miedzy-innymi-gry-edukacyjne-5702587/alternates/LANDSCAPE_1280" />
    Policja w San Antonio aresztowała 35-letniego mężczyznę, którego 3-letnie dziecko przyszło do przedszkola z pistoletem w plecaku, informuje CNN. Władze placówki podały, iż dziecko nie wiedziało, że w jego plecaku znajduje się broń.

