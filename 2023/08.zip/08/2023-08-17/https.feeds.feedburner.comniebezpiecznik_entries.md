# Source:Niebezpiecznik, URL:https://feeds.feedburner.com/niebezpiecznik/, language:pl-PL

## QRishing &#8211; trudniej go wykryć i rzadziej się przed nim ostrzega
 - [https://niebezpiecznik.pl/post/qrishing-trudniej-go-wykryc-i-rzadziej-sie-przed-nim-ostrzega/](https://niebezpiecznik.pl/post/qrishing-trudniej-go-wykryc-i-rzadziej-sie-przed-nim-ostrzega/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-08-17T09:35:46+00:00

<a href="https://niebezpiecznik.pl/post/qrishing-trudniej-go-wykryc-i-rzadziej-sie-przed-nim-ostrzega/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/08/figure1-sample2-AND-FEATURED-IMAGE-150x150.webp" width="100" /></a>&#8220;Nie klikaj w linki w mailach. Włącz 2FA&#8221; &#8211; takie porady słyszy się coraz częściej. Niestety oszuści mogą wykorzystać właśnie motyw włączania 2FA w celu wykradania haseł i nie będzie to wymagać typowego klikania w linki. Ta technika oszustw znana jest od lat, ale wydaje się ostatnio zdobywać popularność. Firma Cofense poinformowała o zidentyfikowaniu dużej [&#8230;]

