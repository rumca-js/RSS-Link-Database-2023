# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Does Anybody Care About Call of Duty? (Whimsu Live)
 - [https://www.youtube.com/watch?v=IpBw9ny81QU](https://www.youtube.com/watch?v=IpBw9ny81QU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2023-08-17T06:18:53+00:00

COD?

