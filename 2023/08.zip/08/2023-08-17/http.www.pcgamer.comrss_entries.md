# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## This free Vampire Survivors clone has one thing nobody knew it needed: Vtubers
 - [https://www.pcgamer.com/this-free-vampire-survivors-clone-has-one-thing-nobody-knew-it-needed-vtubers](https://www.pcgamer.com/this-free-vampire-survivors-clone-has-one-thing-nobody-knew-it-needed-vtubers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T22:47:18+00:00

Become the anime girl streamer you've always wanted to be.

## You'll finally have a chance to try Sega's extraction shooter Hyenas for yourself at the end of August
 - [https://www.pcgamer.com/youll-finally-have-a-chance-to-try-segas-extraction-shooter-hyenas-for-yourself-at-the-end-of-august](https://www.pcgamer.com/youll-finally-have-a-chance-to-try-segas-extraction-shooter-hyenas-for-yourself-at-the-end-of-august)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T22:04:46+00:00

A closed beta test is set to run for two weeks on Steam, beginning on August 31.

## 'I don't think players expect this': Warhammer 40K: Darktide is adding RPG-style skill trees full of new abilities to its 4 classes
 - [https://www.pcgamer.com/i-dont-think-players-expect-this-warhammer-40k-darktide-is-adding-rpg-style-skill-trees-full-of-new-abilities-to-its-4-classes](https://www.pcgamer.com/i-dont-think-players-expect-this-warhammer-40k-darktide-is-adding-rpg-style-skill-trees-full-of-new-abilities-to-its-4-classes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T22:00:19+00:00

Darktide's developers have spent the last 10 months working on a complete overhaul of its disappointing class system.

## Believe it or not, Ubisoft is doing another Skull and Bones closed beta later this month
 - [https://www.pcgamer.com/believe-it-or-not-ubisoft-is-doing-another-skull-and-bones-closed-beta-later-this-month](https://www.pcgamer.com/believe-it-or-not-ubisoft-is-doing-another-skull-and-bones-closed-beta-later-this-month)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T19:50:02+00:00

Signups for the latest closed beta are now open.

## This adorable Bluetooth controller could be just the thing for people with itty bitty baby hands
 - [https://www.pcgamer.com/this-adorable-bluetooth-controller-could-be-just-the-thing-for-people-with-itty-bitty-baby-hands](https://www.pcgamer.com/this-adorable-bluetooth-controller-could-be-just-the-thing-for-people-with-itty-bitty-baby-hands)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T19:43:01+00:00

Game anywhere thanks to this pocket-sized 8BitDo controller, assuming you have doll hands.

## Modern Warfare 3 is bringing back Warzone's most beloved map, but not in the way you're hoping
 - [https://www.pcgamer.com/modern-warfare-3-is-bringing-back-warzones-most-beloved-map-but-not-in-the-way-youre-hoping](https://www.pcgamer.com/modern-warfare-3-is-bringing-back-warzones-most-beloved-map-but-not-in-the-way-youre-hoping)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T19:13:39+00:00

All 16 launch maps from classic Modern Warfare 2 are there day one, too.

## Baldur's Gate 3's chaotic Dark Urge origin is 'potentially the most heroic playthrough,' says lead writer
 - [https://www.pcgamer.com/baldurs-gate-3s-chaotic-dark-urge-origin-is-potentially-the-most-heroic-playthrough-says-lead-writer](https://www.pcgamer.com/baldurs-gate-3s-chaotic-dark-urge-origin-is-potentially-the-most-heroic-playthrough-says-lead-writer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T19:04:55+00:00

I'm just going to have to trust him on this one.

## Hitman's latest update frees a whole bonus campaign from PS4 purgatory after 7 years and intentionally restores an old exploit
 - [https://www.pcgamer.com/hitmans-latest-patch-frees-a-whole-bonus-campaign-from-ps4-purgatory-after-7-years-and-intentionally-restores-an-old-exploit](https://www.pcgamer.com/hitmans-latest-patch-frees-a-whole-bonus-campaign-from-ps4-purgatory-after-7-years-and-intentionally-restores-an-old-exploit)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:51:27+00:00

The greatest weapon in the assassin's toolbox is Alt+F4.

## Modder accuses Take-Two of hypocrisy after lawyers obliterate all trace of their GTA 5 AI mod: 'Rather than chasing small mods, perhaps they should focus on creating proper remakes with better pricing'
 - [https://www.pcgamer.com/modder-accuses-take-two-of-hypocrisy-after-lawyers-obliterate-all-trace-of-their-gta-5-ai-mod-rather-than-chasing-small-mods-perhaps-they-should-focus-on-creating-proper-remakes-with-better-pricing](https://www.pcgamer.com/modder-accuses-take-two-of-hypocrisy-after-lawyers-obliterate-all-trace-of-their-gta-5-ai-mod-rather-than-chasing-small-mods-perhaps-they-should-focus-on-creating-proper-remakes-with-better-pricing)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:40:03+00:00

Sentient Streets used AI to let you chat with the citizens of Los Santos, but now there's barely a speck of it left online.

## 'We owe them a huge debt': Baldur's Gate 3 lead writer hopes they did '90s BioWare proud
 - [https://www.pcgamer.com/we-owe-them-a-huge-debt-baldurs-gate-3-lead-writer-hopes-they-did-90s-bioware-proud](https://www.pcgamer.com/we-owe-them-a-huge-debt-baldurs-gate-3-lead-writer-hopes-they-did-90s-bioware-proud)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:27:13+00:00

Larian Studios' lead writer Adam Smith reflects on the long shadow of Baldur's Gate.

## Lenovo's new handheld will smush together our favorite bits of the Steam Deck and Nintendo Switch
 - [https://www.pcgamer.com/lenovos-new-handheld-will-smush-together-our-favorite-bits-of-the-steam-deck-and-nintendo-switch](https://www.pcgamer.com/lenovos-new-handheld-will-smush-together-our-favorite-bits-of-the-steam-deck-and-nintendo-switch)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:17:39+00:00

Leaked images of the Legion Go shows it will have detachable gamepads and perhaps a larger screen than its portable rivals.

## PC Gamer Chat Log Episode 25: Baldur's Gate 3 lead writer Adam Smith joins the pod!
 - [https://www.pcgamer.com/pc-gamer-chat-log-episode-25-baldurs-gate-3-lead-writer-adam-smith-joins-the-pod](https://www.pcgamer.com/pc-gamer-chat-log-episode-25-baldurs-gate-3-lead-writer-adam-smith-joins-the-pod)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:05:10+00:00

We have our first ever special guest, and boy is it a good one!

## Alan Wake 2 is delayed by 10 days because there are just way too many games coming in October
 - [https://www.pcgamer.com/alan-wake-2-is-delayed-by-10-days-because-there-are-just-way-too-many-games-coming-in-october](https://www.pcgamer.com/alan-wake-2-is-delayed-by-10-days-because-there-are-just-way-too-many-games-coming-in-october)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T16:02:00+00:00

Remedy's next big thing is now set to arrive on October 27.

## How to save the Iron Throne prisoners in Baldur's Gate 3
 - [https://www.pcgamer.com/baldurs-gate-3-iron-throne-prisoners-duke-ravengard](https://www.pcgamer.com/baldurs-gate-3-iron-throne-prisoners-duke-ravengard)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T15:20:47+00:00

Rescue Duke Ravengard and the Gondian families.

## Scott Pilgrim vs. the World's upcoming animated series just dropped an explosive new trailer
 - [https://www.pcgamer.com/scott-pilgrim-vs-the-worlds-upcoming-animated-series-just-dropped-an-explosive-new-trailer](https://www.pcgamer.com/scott-pilgrim-vs-the-worlds-upcoming-animated-series-just-dropped-an-explosive-new-trailer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T15:07:29+00:00

It's shaping up to be the Sex Bob-Omb.

## Baldur's Gate 3's Astarion, Neil Newbon, on acting the truth of trauma as a survivor: 'There's a lot of stuff that came very close to home'
 - [https://www.pcgamer.com/baldurs-gate-3s-astarion-neil-newbon-on-acting-the-truth-of-trauma-as-a-survivor-theres-a-lot-of-stuff-that-came-very-close-to-home](https://www.pcgamer.com/baldurs-gate-3s-astarion-neil-newbon-on-acting-the-truth-of-trauma-as-a-survivor-theres-a-lot-of-stuff-that-came-very-close-to-home)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T14:55:34+00:00

What it means to endure.

## Folky survival RTS game Gord has crept onto Steam
 - [https://www.pcgamer.com/folky-survival-rts-game-gord-has-crept-onto-steam](https://www.pcgamer.com/folky-survival-rts-game-gord-has-crept-onto-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T14:31:29+00:00

In Gord, each of your subjects has their own needs, vices, and stories to tell.

## The best thing about Baldur's Gate 3's companions is that they keep getting in your way
 - [https://www.pcgamer.com/the-best-thing-about-baldurs-gate-3s-companions-is-that-they-keep-getting-in-your-way](https://www.pcgamer.com/the-best-thing-about-baldurs-gate-3s-companions-is-that-they-keep-getting-in-your-way)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T14:12:13+00:00

Nobody was sworn to carry your burdens.

## This free, PS1-style Twin Peaks demake absolutely nails the dreamy vibes of the show
 - [https://www.pcgamer.com/this-free-ps1-style-twin-peaks-demake-absolutely-nails-the-dreamy-vibes-of-the-show](https://www.pcgamer.com/this-free-ps1-style-twin-peaks-demake-absolutely-nails-the-dreamy-vibes-of-the-show)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T13:50:20+00:00

What year is this?

## The best CRPGs to play after Baldur's Gate 3
 - [https://www.pcgamer.com/the-best-crpgs-to-play-after-baldurs-gate-3](https://www.pcgamer.com/the-best-crpgs-to-play-after-baldurs-gate-3)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T12:15:59+00:00

Defeated the Absolute already? Here are some options for your next adventure.

## Sign me up for Starfield's snake worshipping death cult, which communes to its god via cool low-grav jumps
 - [https://www.pcgamer.com/sign-me-up-for-starfields-snake-worshipping-death-cult-which-communes-to-its-god-via-cool-low-grav-jumps](https://www.pcgamer.com/sign-me-up-for-starfields-snake-worshipping-death-cult-which-communes-to-its-god-via-cool-low-grav-jumps)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T11:43:18+00:00

Todd Howard's space Ragnarök cometh.

## Starfield will tantalise you with a bunch of mechs you can't use
 - [https://www.pcgamer.com/starfield-will-tantalise-you-with-a-bunch-of-mechs-you-cant-use](https://www.pcgamer.com/starfield-will-tantalise-you-with-a-bunch-of-mechs-you-cant-use)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T11:06:16+00:00

Mechs were outlawed a decade or two before Starfield starts, so all that's left are a few unusable battlefield relics.

## Where to find Lumidouce Bells in Genshin Impact 4.0
 - [https://www.pcgamer.com/genshin-impact-lumidouce-bell-locations](https://www.pcgamer.com/genshin-impact-lumidouce-bell-locations)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T10:52:43+00:00

Snag these Fontaine Flowers to level up the new free character Lynette.

## Baldur's Gate 3: How to get into Wyrm's Rock and the Lower City
 - [https://www.pcgamer.com/baldurs-gate-3-lower-city-wyrms-rock-entrance](https://www.pcgamer.com/baldurs-gate-3-lower-city-wyrms-rock-entrance)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T10:35:30+00:00

Bridge the gap.

## Magic: The Gathering returns to fairytales for Wilds of Eldraine
 - [https://www.pcgamer.com/magic-the-gathering-returns-to-fairytales-for-wilds-of-eldraine](https://www.pcgamer.com/magic-the-gathering-returns-to-fairytales-for-wilds-of-eldraine)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T06:55:57+00:00

"Enchantment!"

## All recent AMD CPUs are affected by the 'Inception' vulnerability
 - [https://www.pcgamer.com/all-recent-amd-cpus-are-affected-by-the-inception-cpu-vulnerability](https://www.pcgamer.com/all-recent-amd-cpus-are-affected-by-the-inception-cpu-vulnerability)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T05:46:54+00:00

But there's a sign gamers will emerge unscathed.

## AMD to announce its new graphics cards at Gamescom
 - [https://www.pcgamer.com/amd-to-announce-its-new-graphics-cards-at-gamescom](https://www.pcgamer.com/amd-to-announce-its-new-graphics-cards-at-gamescom)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T03:30:34+00:00

Just a few days from now.

## Today's Wordle hint and answer #789: Thursday, August 17
 - [https://www.pcgamer.com/wordle-answer-today-hint-789-august-17](https://www.pcgamer.com/wordle-answer-today-hint-789-august-17)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T03:04:07+00:00

Help with the #789 Wordle if you need it.

## Linus Tech Tips temporarily halts operations, puts out apology video: 'Linus made a clear and egregious judgment error'
 - [https://www.pcgamer.com/linus-tech-tips-temporarily-halts-operations-puts-out-apology-video-linus-made-a-clear-and-egregious-judgment-error](https://www.pcgamer.com/linus-tech-tips-temporarily-halts-operations-puts-out-apology-video-linus-made-a-clear-and-egregious-judgment-error)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T00:38:49+00:00

The popular YouTube channel is also "hiring an outside investigator" in response to an ex-employee's allegations.

## Starfield won't support full pacifist runs, but 'there are some good non-lethal options,' says quest designer
 - [https://www.pcgamer.com/starfield-wont-support-full-pacifist-runs-but-there-are-some-good-non-lethal-options-says-quest-designer](https://www.pcgamer.com/starfield-wont-support-full-pacifist-runs-but-there-are-some-good-non-lethal-options-says-quest-designer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-17T00:02:54+00:00

Bethesda decided early that supporting fully non-lethal playthroughs 'wasn't totally feasible' for Starfield.

