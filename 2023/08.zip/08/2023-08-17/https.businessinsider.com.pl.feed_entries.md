# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Wielka Brytania. Polki na czwartym miejscu wśród zagranicznych matek
 - [https://businessinsider.com.pl/wiadomosci/wielka-brytania-polki-na-czwartym-miejscu-wsrod-zagranicznych-matek/n4rw4yy](https://businessinsider.com.pl/wiadomosci/wielka-brytania-polki-na-czwartym-miejscu-wsrod-zagranicznych-matek/n4rw4yy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T20:08:57+00:00

30 proc. dzieci, które przyszły na świat w Anglii i Walii w ubiegłym roku, zostało urodzone przez matki pochodzące spoza Wielkiej Brytanii, co jest najwyższym odsetkiem w historii — podał w czwartek brytyjski urząd statystyczny ONS. Polki są na czwartym miejscu, jeśli chodzi o kraj pochodzenia zagranicznych matek.

## Strzały w kierunku statku handlowego. Turcja ostrzegła Rosję
 - [https://businessinsider.com.pl/wiadomosci/incydent-na-morzu-czarnym-kancelaria-erdogana-ostrzeglismy-rosje/l13zld2](https://businessinsider.com.pl/wiadomosci/incydent-na-morzu-czarnym-kancelaria-erdogana-ostrzeglismy-rosje/l13zld2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T19:35:34+00:00

Strona rosyjska została w odpowiedni sposób ostrzeżona, by unikać tego rodzaju posunięć — poinformowała w czwartek kancelaria tureckiego prezydenta Recepa Tayyipa Erdogana. Rosyjski okręt strzelał w kierunku statku handlowego płynącego do ukraińskiego portu. Napięcie na Morzu Czarnym wzrosło, odkąd w połowie lipca Rosja jednostronnie wycofała się z umowy zbożowej.

## Sejm zmienił zasady kredytu 2 proc. Wrzutka do ustawy
 - [https://businessinsider.com.pl/prawo/sejm-zmienil-zasady-kredytu-2-proc-wrzutka-do-ustawy-sprawdz-co-sie-zmieni/1ww3r06](https://businessinsider.com.pl/prawo/sejm-zmienil-zasady-kredytu-2-proc-wrzutka-do-ustawy-sprawdz-co-sie-zmieni/1ww3r06)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T19:24:47+00:00

Kredytu 2 proc. nie dostanie osoba, która zaciągnęła inny kredyt hipoteczny na budowę domu. To jedna ze zmian, jaką właśnie przyjął Sejm. Na finiszu kadencji posłowie przegłosowali wrzutkę do ustawy o rodzinnym kredycie mieszkaniowym i bezpiecznym kredycie 2 proc.

## Rewolucja budowlana. Duży dom bez pozwolenia. Sejm przyjął przepisy
 - [https://businessinsider.com.pl/nieruchomosci/rewolucja-budowlana-coraz-blizej-duzy-dom-bez-pozwolenia-sejm-przyjal-przepisy/lc0pvwv](https://businessinsider.com.pl/nieruchomosci/rewolucja-budowlana-coraz-blizej-duzy-dom-bez-pozwolenia-sejm-przyjal-przepisy/lc0pvwv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T18:40:29+00:00

Domy jednorodzinne o powierzchni zabudowy powyżej 70 m kw. będzie można wznosić bez pozwolenia na budowę, podobnie jak ma to dziś miejsce w przypadku domów do 70 m kw. Sejm przyjął w czwartek przepisy w tej sprawie. "Jeszcze w tym roku zaoferujemy nowe, bezpłatne projekty do pobrania dla wszystkich chętnych" — zapewnia minister rozwoju i technologii Waldemar Buda.

## Prąd ma być jeszcze tańszy. Sejm poparł zmianę cen od początku 2023 r.
 - [https://businessinsider.com.pl/wiadomosci/rachunki-za-prad-w-2023-maja-byc-nizsze-sejm-przyjal-zaskakujacy-pomysl-pis/4gscfbh](https://businessinsider.com.pl/wiadomosci/rachunki-za-prad-w-2023-maja-byc-nizsze-sejm-przyjal-zaskakujacy-pomysl-pis/4gscfbh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T17:43:46+00:00

Sejm przyjął w czwartek przepisy przewidujące 5-procentową, obowiązującą wstecznie od początku 2023 r., obniżkę cen energii elektrycznej. Sprzedawcy prądu do gospodarstw domowych i tzw. odbiorców uprawnionych mają stosować ceny równe 95 proc. ceny stosowanej obecnie.

## Buda o drożejących mieszkaniach "Skoro drożeje jogurt, trudno, by mieszkania taniały"
 - [https://businessinsider.com.pl/gospodarka/buda-o-drozejacych-mieszkaniach-skoro-drozeje-jogurt-trudno-by-mieszkania-tanialy/xzb2m61](https://businessinsider.com.pl/gospodarka/buda-o-drozejacych-mieszkaniach-skoro-drozeje-jogurt-trudno-by-mieszkania-tanialy/xzb2m61)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T16:30:57+00:00

Minister rozwoju i technologii w rozmowie z "Dziennikiem Gazetą Prawną" mówił o cenach mieszkań. Wskazując na szereg problemów, posłużył się co najmniej zaskakującym argumentem. — Skoro drożeje jogurt czy wędlina, trudno, by mieszkania taniały — mówił Buda o cenach, co jest dość zaskakującym argumentem.

## Referendum w dniu wyborów. Jest decyzja Sejmu
 - [https://businessinsider.com.pl/wiadomosci/referendum-15-pazdziernika-jest-ostateczna-decyzja-sejmu/6zysxkg](https://businessinsider.com.pl/wiadomosci/referendum-15-pazdziernika-jest-ostateczna-decyzja-sejmu/6zysxkg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:55:38+00:00

Sejm przyjął w czwartek uchwałę o zarządzeniu referendum ogólnokrajowego na 15 października, czyli w dniu wyborów parlamentarnych. Teraz dokument zostanie opublikowany w Dzienniku Ustaw. W referendum padną cztery pytania.

## Rubel szoruje po dnie. Kwitnie handel przygraniczny
 - [https://businessinsider.com.pl/gospodarka/rubel-szoruje-po-dnie-estonczycy-ruszyli-na-zakupy-do-rosji/6tk3rke](https://businessinsider.com.pl/gospodarka/rubel-szoruje-po-dnie-estonczycy-ruszyli-na-zakupy-do-rosji/6tk3rke)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:45:40+00:00

Słaby rubel pobudza transgraniczny handel — mieszkańcy wschodniej Estonii jeżdżą na zakupy do Rosji, gdzie ceny są obecnie znacznie niższe. "Prawie wszystkie produkty spożywcze są tam co najmniej dwa razy tańsze" — mówi jeden z nich. Chociaż to praktyka znana od lat, teraz jednak konsumenci muszą uważać na to, czy kupowane produkty nie są objęte sankcjami — zauważa estońska telewizja ERR.

## Gdzie mieszkają milionerzy? Milionerskie zagłębie niedaleko Polski
 - [https://businessinsider.com.pl/wiadomosci/gdzie-mieszkaja-milionerzy-milionerskie-zaglebie-niedaleko-polski/tkjxvrn](https://businessinsider.com.pl/wiadomosci/gdzie-mieszkaja-milionerzy-milionerskie-zaglebie-niedaleko-polski/tkjxvrn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:45:29+00:00

Najbogatszym narodem na świecie, narodem milionerów, jeśli pod uwagę weźmiemy przeciętny majątek mieszkańca, są Belgowie — wynika najnowszego raportu "Global Wealth Report" przygotowanego przez UBS i Credit Suisse. Co więcej, Belgia jest też krajem, w którym nierówności majątkowe są najmniejsze na świecie.

## Wojna o skarby: archeolodzy kontra poszukiwacze. Jest decyzja Sejmu
 - [https://businessinsider.com.pl/prawo/wojna-o-skarby-archeolodzy-kontra-poszukiwacze-sprawdz-co-zdecydowal-sejm/cw7xqsq](https://businessinsider.com.pl/prawo/wojna-o-skarby-archeolodzy-kontra-poszukiwacze-sprawdz-co-zdecydowal-sejm/cw7xqsq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:20:42+00:00

Sejm nie zgodził się na odrzucenie nowelizacji ustawy o ochronie zabytków. Tym samym poszukiwanie przedmiotów przy użyciu np. wykrywacza metali nie będzie już wymagało zgody konserwatora. Wprowadzone zostaną za to inne obostrzenia, w tym wymóg zgłoszenia poszukiwań do odpowiedniego rejestru.

## W kioskach Ruchu kupowaliśmy gazety. Teraz będzie pizza
 - [https://businessinsider.com.pl/finanse/handel/w-kioskach-ruchu-kupowalismy-gazety-teraz-bedzie-pizza/thg3x3h](https://businessinsider.com.pl/finanse/handel/w-kioskach-ruchu-kupowalismy-gazety-teraz-bedzie-pizza/thg3x3h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:20:36+00:00

Ruch zmienia strategię. Będzie mnie gazet, a więcej pizzy i hot dogów. — Chcemy skupić się na poprawieniu efektywności sprzedaży. Dlatego będziemy ograniczać zbyt szeroki do tej pory asortyment — mówi w rozmowie z serwisem wiadomoscihandlowe.pl członek zarządu marki Rafał Bałazy.

## 92-letni Rupert Murdoch znów randkuje. Cztery miesiące temu zerwał zaręczyny
 - [https://businessinsider.com.pl/lifestyle/rupert-murdoch-znow-randkuje-nowa-dziewczyna-92-latka-byla-zona-miliardera/d4t8b46](https://businessinsider.com.pl/lifestyle/rupert-murdoch-znow-randkuje-nowa-dziewczyna-92-latka-byla-zona-miliardera/d4t8b46)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:16:51+00:00

92-letni Rupert Murdoch po tym, jak cztery miesiące temu zerwał zaręczyny z Ann Lesley Smith, ponownie umawia się na randki.

## Inteligentny smartwatch o klasycznym wyglądzie - w sam raz dla stylowego mężczyzny?
 - [https://businessinsider.com.pl/technologie/nowe-technologie/inteligentny-smartwatch-o-klasycznym-wygladzie-w-sam-raz-dla-stylowego-mezczyzny/4ck11p9](https://businessinsider.com.pl/technologie/nowe-technologie/inteligentny-smartwatch-o-klasycznym-wygladzie-w-sam-raz-dla-stylowego-mezczyzny/4ck11p9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T15:08:00+00:00

Te trzy eleganckie smartwatche posiadają w sobie coś ponadczasowego, a ich nowoczesne funkcje wspierają użytkownika w codziennym monitoringu zdrowia, w kontaktach społecznych i biznesowych. Poznajmy je bliżej.

## Oczyszcza i ujędrnia skórę, a nie jest kosmetykiem. Co to takiego?
 - [https://businessinsider.com.pl/technologie/nowe-technologie/oczyszcza-i-ujedrnia-skore-a-nie-jest-kosmetykiem-co-to-takiego/bchwtq9](https://businessinsider.com.pl/technologie/nowe-technologie/oczyszcza-i-ujedrnia-skore-a-nie-jest-kosmetykiem-co-to-takiego/bchwtq9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T14:24:16+00:00

Głęboko oczyszczają skórę z martwego naskórka i sebum. Sprawiają, że jest gładsza i bardziej miękka, dodatkowo napinają ją i ujędrniają, a nawet redukują zmarszczki. Mowa nie o kosmetykach, lecz o zaawansowanych technologicznie urządzeniach służących do peelingu kawitacyjnego - przenoszą domową pielęgnację na wyższy poziom. W tym tekście przedstawiamy kilka takich urządzeń. Co ciekawe, najtańsze można kupić za mniej niż 90 zł.

## Biedronka zaskakuje: w sklepie wypłacisz gotówkę. Ale jest haczyk
 - [https://businessinsider.com.pl/twoje-pieniadze/biedronka-z-zaskoczenia-wprowadzila-nowa-usluge-koniec-z-szukaniem-bankomatu/l45shxd](https://businessinsider.com.pl/twoje-pieniadze/biedronka-z-zaskoczenia-wprowadzila-nowa-usluge-koniec-z-szukaniem-bankomatu/l45shxd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T14:21:25+00:00

Biedronka zdecydowała się na posunięcie, które powinno spodobać się jej klientom. Portugalska sieć wdrożyła program, dzięki któremu można będzie wypłacać gotówkę podczas zakupów. Usługa jest dostępna dla wszystkich, którzy za zakupy płacą kartami lub za pośrednictwem smartfonów. Jest jednak jeden haczyk.

## Właściciele domów korzystają z programu Moja Woda. Pula środków może być większa
 - [https://businessinsider.com.pl/twoje-pieniadze/program-moja-woda-dla-wlascicieli-domow-co-dalej-z-doplatami/vzw29d0](https://businessinsider.com.pl/twoje-pieniadze/program-moja-woda-dla-wlascicieli-domow-co-dalej-z-doplatami/vzw29d0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T14:04:35+00:00

W trzeciej edycji programu Moja Woda zarejestrowano już wnioski na 70 proc. środków.— W razie wyczerpania puli będziemy działać, aby została zwiększona — poinformowała w czwartek w Sejmie wiceminister klimatu i środowiska Małgorzata Golińska.

## Ekonomista podważa wiarygodność danych o PKB. Mówi o "dyskusyjnych" metodach
 - [https://businessinsider.com.pl/gospodarka/pkb-polski-mocno-spadl-to-problem-gospodarki-czy-gus-ekonomista-ostrzega/eqs0tes](https://businessinsider.com.pl/gospodarka/pkb-polski-mocno-spadl-to-problem-gospodarki-czy-gus-ekonomista-ostrzega/eqs0tes)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T13:51:41+00:00

Kwartalny spadek PKB Polski o prawie 4 proc. to niepokojący sygnał, ale zdaniem dyrektora PIE nie są to wiarygodne statystyki i będą musiały być zrewidowane. Wskazuje, że prezentowane przez GUS dane dotyczące sektora zakwaterowania i gastronomii, w których wahania są 30 razy większe niż w pozostałych branżach, są niewiarygodne. Zwraca przy tym uwagę na "efekt wakacji".

## Wielka awaria. Problem z wyrobieniem dowodu i rejestracją urodzenia
 - [https://businessinsider.com.pl/wiadomosci/wielka-awaria-problem-z-wyrobieniem-dowodu-i-rejestracja-urodzenia/bvw56cr](https://businessinsider.com.pl/wiadomosci/wielka-awaria-problem-z-wyrobieniem-dowodu-i-rejestracja-urodzenia/bvw56cr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T13:46:44+00:00

16 i 17 sierpnia doszło do ogólnopolskiej awarii dostępu do Centralnych Rejestrów Państwowych — informuje portalsamorzadowy.pl. Jak dodaje, z tego powodu są trudności w sprawach związanych z dowodem osobistym, rejestracją zgonu czy urodzenia.

## Pięć najpopularniejszych smartbandów w sierpniu
 - [https://businessinsider.com.pl/technologie/piec-najpopularniejszych-smartbandow-w-sierpniu/lstrc0e](https://businessinsider.com.pl/technologie/piec-najpopularniejszych-smartbandow-w-sierpniu/lstrc0e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:58:37+00:00

Smartbandy cieszą się ogromną popularnością, bo są praktyczne, lekkie i niedrogie. Przedstawiamy najnowszy ranking opasek sportowych według danych z porównywarki cen Skąpiec.pl.

## Czy ekwiwalent za pracę zdalną jest przychodem? Fiskus rozwiewa wątpliwości
 - [https://businessinsider.com.pl/twoje-pieniadze/prawo-i-podatki/ryczalt-za-prace-zdalna-fiskus-rozwial-watpliwosci/flk1rsv](https://businessinsider.com.pl/twoje-pieniadze/prawo-i-podatki/ryczalt-za-prace-zdalna-fiskus-rozwial-watpliwosci/flk1rsv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:57:59+00:00

Praca zdalna nie będzie wiązać się z dodatkowymi kosztami podatkowymi. Interpretacje fiskusa są tutaj zgodnie — ryczałt za pracę z domu nie podlega opodatkowaniu PIT — donosi "Rzeczpospolita". Dziennik zauważa też, że skarbówka wyjątkowo liberalnie podchodzi do dokumentowania wydatków na prąd i internet.

## Skandaliczne ceny cebuli.  "Przesada"
 - [https://businessinsider.com.pl/gospodarka/cena-cebuli-wprawia-klientow-w-oslupienie-nawet-8-zl-za-kilogram/d0985lh](https://businessinsider.com.pl/gospodarka/cena-cebuli-wprawia-klientow-w-oslupienie-nawet-8-zl-za-kilogram/d0985lh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:49:34+00:00

Ceny cebuli jeszcze nigdy nie były takie wysokie. Warzywo, które przez lata kojarzyło nam się z bardzo niską ceną, od ponad roku notuje rekordowe wzrosty. Obecnie w sklepach trzeba zapłacić nawet 8 zł za kilogram, co wprawia klientów w osłupienie i wywołuje złość.

## Ceny w większości wzrosły, a obłożenie w hotelach spadło. Oto liczby na półmetku wakacji
 - [https://businessinsider.com.pl/biznes/wakacje-2023-wolne-miejsca-w-hotelach-i-ceny-na-polmetku-sezonu/b94hy8z](https://businessinsider.com.pl/biznes/wakacje-2023-wolne-miejsca-w-hotelach-i-ceny-na-polmetku-sezonu/b94hy8z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:46:29+00:00

W lipcu nie było najazdu turystów na hotele. Choć 63 proc. właścicieli dobrze ocenia pierwszą połowę sezonu wakacyjnego, dla blisko połowy obiektów wskaźnik obłożenia się pogorszył względem ubiegłego roku. Jednocześnie w 78 proc. hoteli wzrosły ceny.

## Regeneracja ciała i ducha w otoczeniu górskiej przyrody. Specjalne ceny
 - [https://businessinsider.com.pl/lifestyle/podroze/regeneracja-ciala-i-ducha-w-otoczeniu-gorskiej-przyrody-specjalne-ceny/yszehhg](https://businessinsider.com.pl/lifestyle/podroze/regeneracja-ciala-i-ducha-w-otoczeniu-gorskiej-przyrody-specjalne-ceny/yszehhg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:41:35+00:00

Zaplanuj regenerujący pobyt w sercu Gór Izerskich, w uzdrowisku. St. Lukas Medical &amp; Spa w Świeradowie-Zdroju to nie tylko sanatorium, ale także luksusowy obiekt SPA, który gwarantuje odnowę zarówno dla ciała, jak i ducha. W tym miejscu tradycyjne metody leczenia łączą się z nowoczesnymi technikami relaksu. To idealne miejsce dla osób poszukujących odnowy biologicznej, rodzin pragnących spędzić czas w otoczeniu górskiego krajobrazu oraz dla wszystkich, którzy cenią sobie zdrowie i dobre samopoczucie. Co więcej? St. Lukas Medical &amp; Spa i serwis Triverna przygotowali specjalne ceny rezerwacji dla czytelników tego artykułu. Za pośrednictwem linków partnerskich w poniższym artykule, dokonasz rezerwacji ze specjalną zniżką. Zapraszamy!

## Boom na kierunki lekarskie. Próbują nawet ci z kiepsko zdaną maturą
 - [https://businessinsider.com.pl/twoje-pieniadze/boom-na-kierunki-lekarskie-probuja-nawet-ci-z-kiepsko-zdana-matura/nyxvnbz](https://businessinsider.com.pl/twoje-pieniadze/boom-na-kierunki-lekarskie-probuja-nawet-ci-z-kiepsko-zdana-matura/nyxvnbz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T12:12:25+00:00

Liczba uczelni oferujących kierunki lekarskie wzrosła w ciągu ostatnich 8 lat z 12 do 34. Mimo tak dużej liczby nowych uczelni kształcących przyszłych lekarzy, konkurencja o miejsce pozostaje ogromna. Eksperci jednak przestrzegają przed drogą na skróty. Niektóre instytucje oferują możliwość studiów na kierunkach lekarskich nawet osobom, które nie osiągnęły dobrych wyników z matur.

## Cenówki papierowe to już przeszłość. Czas na elektronikę
 - [https://businessinsider.com.pl/gospodarka/papierowe-cenowki-odchodza-do-przeszlosci-technologia-wkracza-na-polki/cexm69f](https://businessinsider.com.pl/gospodarka/papierowe-cenowki-odchodza-do-przeszlosci-technologia-wkracza-na-polki/cexm69f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:53:41+00:00

Cenówki papierowe wkrótce będą tylko wspomnieniem w sklepach? I tak, i nie. Na razie elektroniczne cenówki we wszystkich swoich sklepach wprowadzi Lidl. Inne sieci nie chcą być gorsze i przeprowadzają testy, które zapewne zakończy się także wdrożeniem nowych technologii.

## Szwecja podnosi stopień zagrożenia terrorystycznego. Czwarty w pięciostopniowej skali
 - [https://businessinsider.com.pl/gospodarka/szwecja-podnosi-stopien-zagrozenia-terrorystycznego/me1r2sl](https://businessinsider.com.pl/gospodarka/szwecja-podnosi-stopien-zagrozenia-terrorystycznego/me1r2sl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:50:04+00:00

"Podnosimy poziom zagrożenia terrorystycznego ze stopnia trzeciego (podwyższonego) do czwartego (wysokiego) w pięcioskalowym alercie" - poinformowały w czwartek służby specjalne SAPO.

## Miliardy uciekają z Chin. Takiej serii wcześniej nie notowano
 - [https://businessinsider.com.pl/gielda/wiadomosci/chiny-maja-problem-wystraszeni-inwestorzy-uciekaja-z-pieniedzmi/9pzbkek](https://businessinsider.com.pl/gielda/wiadomosci/chiny-maja-problem-wystraszeni-inwestorzy-uciekaja-z-pieniedzmi/9pzbkek)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:47:07+00:00

Zagraniczne fundusze inwestycyjne uciekają z Chin, a dokładniej wyprzedają akcje tamtejszych spółek w nadzwyczajnie szybkim tempie. W niecałe dwa tygodnie z rynku "wyparowało" kilkadziesiąt miliardów juanów. Wszystko przez obawy dotyczące gospodarki.

## Jak singiel lub para bez ślubu może skorzystać z kredytu 2 proc.? Wyjaśniamy niuanse
 - [https://businessinsider.com.pl/prawo/jak-singiel-moze-skorzystac-z-kredytu-2-proc-odpowiadamy-na-pytania/nrq2e4j](https://businessinsider.com.pl/prawo/jak-singiel-moze-skorzystac-z-kredytu-2-proc-odpowiadamy-na-pytania/nrq2e4j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:30:00+00:00

Bezpieczny kredyt 2 proc. cieszy się dużym zainteresowaniem. Ruszył 3 lipca, a już banki zarejestrowały ponad 4 tys.wniosków. Może się o niego starać osoba, która ma mniej niż 45 lat i nie ma mieszkania lub domu. Dzięki temu także singiel czy osoba w związku nieformalnym może kupić swoje pierwsze lokum. Do naszej redakcji wpłynęło jednak wiele maili z pytaniami o szczegóły. Odpowiadamy na wszystkie.

## Chiny ukrywają kluczowe dane i udają, że ich gospodarka ma się dobrze
 - [https://businessinsider.com.pl/gospodarka/chiny-ukrywaja-kluczowe-dane-i-udaja-ze-ich-gospodarka-ma-sie-dobrze/kbzl67v](https://businessinsider.com.pl/gospodarka/chiny-ukrywaja-kluczowe-dane-i-udaja-ze-ich-gospodarka-ma-sie-dobrze/kbzl67v)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:18:16+00:00

Chińska gospodarka rozwija się bardzo szybko i bez większych problemów. To wersja oficjalna. Prawda jest jednak inna. Pekin ukrywa kluczowe dane i próbuje udawać przed światem, że wszystko jest w porządku. Zabrania nawet ekonomistom dyskusji na temat tempa wzrostu PKB.

## Wiceminister finansów wyklucza recesję. Jest gotów założyć się o jednocyfrową inflację
 - [https://businessinsider.com.pl/finanse/wiceminister-finansow-wyklucza-recesje-jest-gotow-zalozyc-sie-o-jednocyfrowa-inflacje/70wkz6r](https://businessinsider.com.pl/finanse/wiceminister-finansow-wyklucza-recesje-jest-gotow-zalozyc-sie-o-jednocyfrowa-inflacje/70wkz6r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:08:19+00:00

Wiceminister finansów Artur Soboń chwalił się dynamiką PKB w czasie rządów PIS. Zwrócił uwagę, że w latach 2016-2022 średnie tempo wzrostu PKB Unii Europejskiej wyniosło 1,7 proc., podczas gdy polska gospodarka rosła w tym czasie średnio o 4 proc. Soboń podkreślił też, że w tym czasie skumulowany wzrost PKB w Polsce to 31,9 proc, podczas gdy w Unii było to zaledwie 12,3 proc.

## Wiceminister finansów wyklucza recesję. Jest gotów założyć się o jednocyfrową inflację
 - [https://businessinsider.com.pl/finanse/wiceminister-finansow-wyklucza-recesje-jest-gotow-sie-o-to-zalozyc/70wkz6r](https://businessinsider.com.pl/finanse/wiceminister-finansow-wyklucza-recesje-jest-gotow-sie-o-to-zalozyc/70wkz6r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T11:08:19+00:00

Wiceminister finansów Artur Soboń chwalił się dynamiką PKB w czasie rządów PiS. Zwrócił uwagę, że w latach 2016-2022 średnie tempo wzrostu PKB Unii Europejskiej wyniosło 1,7 proc., podczas gdy polska gospodarka rosła w tym czasie średnio o 4 proc. Soboń podkreślił też, że w tym czasie skumulowany wzrost PKB w Polsce to 31,9 proc., podczas gdy w Unii było to zaledwie 12,3 proc.

## Dyskryminacja kobiet w Kauflandzie potwierdzona. Żądają rekompensat
 - [https://businessinsider.com.pl/wiadomosci/dyskryminacja-kobiet-w-kauflandzie-potwierdzona-zadaja-rekompensat/ghgptrn](https://businessinsider.com.pl/wiadomosci/dyskryminacja-kobiet-w-kauflandzie-potwierdzona-zadaja-rekompensat/ghgptrn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:58:35+00:00

Państwowa Inspekcja Pracy oficjalnie potwierdziła, że w Kauflandzie dochodziło do dyskryminacji pracownic posiadających dzieci. Efektem tego jest skierowanie 50 wniosków o rekompensatę skierowanych przeciwko sieci do sądu, choć może być to dopiero początek problemów. Jak donosi bankier.pl, poszkodowanych może być nawet tysiąc kobiet.

## Ile w tym roku kosztuje wyprawka szkolna? Rządowe programy mogą nie wystarczyć
 - [https://businessinsider.com.pl/twoje-pieniadze/wyprawka-szkolna-2023-ile-kosztuje-jak-uzyskac-dofinansowanie/hbvwlzk](https://businessinsider.com.pl/twoje-pieniadze/wyprawka-szkolna-2023-ile-kosztuje-jak-uzyskac-dofinansowanie/hbvwlzk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:49:00+00:00

Jak co roku, w drugiej połowie sierpnia, myśli wielu rodziców krążą wokół wyprawienia swoich pociech do placówek edukacyjnych. Zakup wyprawki szkolnej wiąże się z niemałymi kosztami, a jeśli w jednej rodzinie jest kilku uczniów, to wydatek robi się już bardzo poważny. Ile w tym roku kosztuje wyprawka szkolna? Jak zdobyć dofinansowanie? Podpowiadamy.

## Młodzi ludzie akceptują płacenie pod stołem. Starsi boją się głównie jednego
 - [https://businessinsider.com.pl/praca/wynagrodzenia/dostajesz-wynagrodzenie-pod-stolem-w-tej-grupie-wiekowej-jest-na-to-zgoda/96kbprm](https://businessinsider.com.pl/praca/wynagrodzenia/dostajesz-wynagrodzenie-pod-stolem-w-tej-grupie-wiekowej-jest-na-to-zgoda/96kbprm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:48:46+00:00

Prawie połowa młodych ludzi akceptuje płacenie wynagrodzenia pod stołem, z pominięciem oficjalnej procedury związanej m.in. z opodatkowaniem dochodów. Wraz z wiekiem podejście się zmienia. Do głosu dochodzą np. obawy związane z niską emeryturą.

## Iga Świątek nawiązała współpracę ze światowym gigantem
 - [https://businessinsider.com.pl/media/marketing/iga-swiatek-nawiazala-wspolprace-ze-swiatowym-gigantem/lzf69zh](https://businessinsider.com.pl/media/marketing/iga-swiatek-nawiazala-wspolprace-ze-swiatowym-gigantem/lzf69zh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:46:52+00:00

Iga Świątek rozpoczęła współpracę z Visą. Dołączyła do niej jako globalna ambasadorka marki. Stało się to na niecały rok przed Igrzyskami Olimpijskimi w Paryżu

## W Rosji mimo sankcji przybyło 56 tys. milionerów. Oto powód
 - [https://businessinsider.com.pl/gospodarka/w-rosji-mimo-sankcji-przybylo-56-tys-milionerow-oto-powod/2g8v8tj](https://businessinsider.com.pl/gospodarka/w-rosji-mimo-sankcji-przybylo-56-tys-milionerow-oto-powod/2g8v8tj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:37:20+00:00

W 2022 r. w Rosji było już ponad 400 tys. milionerów. To o 56 tys. więcej niż jeszcze rok wcześniej. Jednocześnie w krajach Europy i w USA biliony dolarów wręcz wyparowały z prywatnych majątków. Powód? W dużej mierze drożejąca ropa i inne surowce.

## Zgrzyt na linii rząd - MON. Niemcy wycofują się z ustawowego zapisu dotyczącego obronności
 - [https://businessinsider.com.pl/wiadomosci/wydatki-na-armie-niemcy-wycofuja-sie-z-twardego-zapisu-w-ustawie/krpcdem](https://businessinsider.com.pl/wiadomosci/wydatki-na-armie-niemcy-wycofuja-sie-z-twardego-zapisu-w-ustawie/krpcdem)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:15:42+00:00

Agresja Rosji w Ukrainie przekonała wiele krajów do zwiększonych wydatków na obronność. Niemiecki resort obrony chciał twardo zapisać w ustawie takie wydatki na poziomie minimum 2 proc. PKB. Rząd się jednak z tego wycofuje.

## Ile pieniędzy ma polska rodzina? Tyle według ministra edukacji
 - [https://businessinsider.com.pl/wiadomosci/ile-pieniedzy-ma-polska-rodzina-tyle-wedlug-ministra-edukacji/gsvzryl](https://businessinsider.com.pl/wiadomosci/ile-pieniedzy-ma-polska-rodzina-tyle-wedlug-ministra-edukacji/gsvzryl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T10:05:23+00:00

W 2015 r. cały budżet czteroosobowej polskiej rodziny wynosił 3500 zł. W 2023 r. w sumie mają 8,4 tys. zł — powiedział w czwartek w Sejmie minister edukacji i nauki Przemysław Czarnek zabierając głos po debacie i pytaniach posłów w kwestii wniosku o przeprowadzenie referendum ogólnokrajowego.

## Hawajskie firmy energetyczne wiedziały o zagrożeniu pożarami - i nic z tym nie zrobiły
 - [https://businessinsider.com.pl/wiadomosci/hawajskie-firmy-energetyczne-wiedzialy-o-zagrozeniu-pozarami-i-nic-z-tym-nie-zrobily/qxlwlf9](https://businessinsider.com.pl/wiadomosci/hawajskie-firmy-energetyczne-wiedzialy-o-zagrozeniu-pozarami-i-nic-z-tym-nie-zrobily/qxlwlf9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:55:58+00:00

Największe przedsiębiorstwo energetyczne na Hawajach — Hawaiian Electric — mierzy się z oskarżeniami o swoją rolę w pożarach, które zniszczyły znaczną część wyspy Maui. Przeciwko firmie skierowany został pozew, w którym zarzucono jej niepodjęcie działań mogących ograniczyć skutki katastrofy mimo świadomości istnienia ryzyka. Firma na razie odmawia komentarza.

## Zauważyła dopisek na paragonie. Restauratorka: płacimy również za zmywarkę
 - [https://businessinsider.com.pl/gospodarka/oburzyl-ja-dopisek-na-paragonie-tlumaczenie-wlascicielki/s1vb7sp](https://businessinsider.com.pl/gospodarka/oburzyl-ja-dopisek-na-paragonie-tlumaczenie-wlascicielki/s1vb7sp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:42:44+00:00

Wyjeżdżając na wakacje, warto zadbać o nieco większy budżet, by nie zdziwić się, kiedy na rachunkach będzie informacja o dodatkowych kosztach. Czasem to zaledwie kilka złotych, jednak opłacenie nawet takich kwot jest dla niektórych kuriozalne. Przekonała się tym kobieta, która musiała dopłacić za kolejny talerz, o który poprosiła.

## Śmierć i zatrucia po zjedzeniu kebabów. Mięso miało pochodzić z Polski
 - [https://businessinsider.com.pl/wiadomosci/smierc-i-zatrucia-po-zjedzeniu-kebabow-mieso-mialo-pochodzic-z-polski/jv4txwx](https://businessinsider.com.pl/wiadomosci/smierc-i-zatrucia-po-zjedzeniu-kebabow-mieso-mialo-pochodzic-z-polski/jv4txwx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:31:46+00:00

Jedna osoba nie żyje, a ponad 20 zakaziło się salmonellą w Austrii. Tamtejsze władze jako prawdopodobną przyczynę podają spożycie kebabów z mięsem z kurczaka, które miało być dostarczone z Polski. Przypadki zatrucia miały wystąpić też w Niemczech.

## To koniec galopady cen materiałów budowlanych? Idzie przełom
 - [https://businessinsider.com.pl/gospodarka/to-koniec-galopady-cen-materialow-budowlanych-idzie-przelom/8t9ne4s](https://businessinsider.com.pl/gospodarka/to-koniec-galopady-cen-materialow-budowlanych-idzie-przelom/8t9ne4s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:31:20+00:00

Materiały budowlane mogą przestać drożeć. Co więcej, pojawiła się nawet niewielka nadzieja na spadki cen. Ale z hurraoptymizmem warto poczekać. Nawet jeśli tak się stanie, to nie będzie to długotrwała tendencja — twierdzą eksperci portalu RynekPierwotny.pl.

## Kredyt 2 proc. na budowę domu. Jest kilka haczyków. Sprawdź, na co uważać
 - [https://businessinsider.com.pl/prawo/kredyt-2-procent-na-budowe-domu-uwaga-na-haczyki/n7g87t4](https://businessinsider.com.pl/prawo/kredyt-2-procent-na-budowe-domu-uwaga-na-haczyki/n7g87t4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:30:00+00:00

Kredyt z dopłatą dostanie osoba, która ma mniej niż 45 lat i nie ma mieszkania lub domu. Pieniądze można przeznaczyć np. na zakup działki, budowę domu jednorodzinnego, w tym jego wykończenie. Aby dostać kredyt 2 proc., trzeba spełnić ustawowe warunki, ale nie tylko. W przypadku budowy domu ważny też jest koszt jednego metra kwadratowego. Wyjaśniamy, dlaczego i na co uważać.

## Sejm zgadza się na referendum. Teraz kolejny krok
 - [https://businessinsider.com.pl/wiadomosci/glosowanie-ws-referendum-decyzja-sejmu/qbdp59l](https://businessinsider.com.pl/wiadomosci/glosowanie-ws-referendum-decyzja-sejmu/qbdp59l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:25:26+00:00

W czwartek Sejm przyjął wniosek rządu o zarządzenie referendum ogólnokrajowego. Teraz Komisja Ustawodawcza przygotuje projekt uchwały Sejmu.

## Polska na plusie. Do Niemiec wysyłamy więcej towarów niż łącznie do pięciu kolejnych krajów
 - [https://businessinsider.com.pl/gospodarka/w-handlu-polak-i-niemiec-to-dwa-bratanki-mowa-o-poteznych-sumach/640603k](https://businessinsider.com.pl/gospodarka/w-handlu-polak-i-niemiec-to-dwa-bratanki-mowa-o-poteznych-sumach/640603k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T09:10:04+00:00

Za granicę sprzedaliśmy towary warte o prawie 31 mld zł więcej niż te, które sprowadziliśmy do Polski. Rośnie eksport, maleje import, ale niezmienne jest jedno — Niemcy są naszym najważniejszym partnerem w handlu. Mowa o potężnych kwotach.

## Ukraińcy spojrzeli na zdjęcia z ćwiczeń i ostrzegają Polaków. "Zagrożenie dla tego systemu w boju"
 - [https://businessinsider.com.pl/wiadomosci/ukraincy-spojrzeli-na-zdjecia-z-cwiczen-i-ostrzegaja-polakow-zagrozenia-dla-systemu/4qtrkkc](https://businessinsider.com.pl/wiadomosci/ukraincy-spojrzeli-na-zdjecia-z-cwiczen-i-ostrzegaja-polakow-zagrozenia-dla-systemu/4qtrkkc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T08:44:22+00:00

Polskie wojsko powinno lepiej przyłożyć się do manewrów z użyciem systemu rakietowego Patriot — wynika z analizy zdjęć przeprowadzonej przez ukraiński portal Defense Express. Jak czytamy, w warunkach bojowych mielibyśmy poważne problemy.

## Oto najbardziej niebezpieczne miasta w Europie. Są znane kurorty
 - [https://businessinsider.com.pl/wiadomosci/oto-najbardziej-niebezpieczne-miasta-w-europie-sa-znane-kurorty/gew3r30](https://businessinsider.com.pl/wiadomosci/oto-najbardziej-niebezpieczne-miasta-w-europie-sa-znane-kurorty/gew3r30)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T08:35:19+00:00

W sieci pojawił się nowy ranking najbardziej niebezpiecznych miast w Europie i na świecie. Wśród nich są takie, do których Polacy uwielbiają jeździć na wakacje. Nasze rodzime metropolie w tym zestawieniu są na odległych miejscach. Najwyżej jest Łódź, która otwiera trzecią setkę zestawienia.

## Niespodziewany lider drożyzny w Polsce. Właściciele zwierząt rwą włosy z głów
 - [https://businessinsider.com.pl/lifestyle/chcesz-miec-psa-badz-kota-utrzymanie-zwierzat-ostro-w-gore/hb2r9e9](https://businessinsider.com.pl/lifestyle/chcesz-miec-psa-badz-kota-utrzymanie-zwierzat-ostro-w-gore/hb2r9e9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T08:30:00+00:00

W ciągu roku karma dla zwierząt drożeje szybciej niż żywność i jest jednym z liderów drożyzny. W efekcie utrzymanie domowych pupili staje się nie lada wyzwaniem dla portfeli ich właścicieli. Do jedzenia trzeba bowiem doliczyć wizyty u weterynarza czy inne usługi, których ceny idą równie mocno w górę.

## Guru inwestorów znowu to zrobił. Postawił wielkie pieniądze na krach
 - [https://businessinsider.com.pl/gielda/wiadomosci/michael-burry-z-big-short-znowu-to-robi-gigantyczne-pieniadze-na-krach/3qz0b7m](https://businessinsider.com.pl/gielda/wiadomosci/michael-burry-z-big-short-znowu-to-robi-gigantyczne-pieniadze-na-krach/3qz0b7m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T08:17:11+00:00

Amerykańską giełdę czeka krach i powtórka z "Big Short"? Na to wskazują działania słynnego inwestora, który wyłożył na stół 1,6 mld dol. Michael Burry już w tym roku przyznał się do błędu, ale ostatnie wydarzenia w USA sprzyjają jego teorii.

## Kim jest Aleksandra K. Wiśniewska? Córka znanego biznesmena na listach KO
 - [https://businessinsider.com.pl/wiadomosci/kim-jest-aleksandra-k-wisniewska-corka-znanego-biznesmena-na-listach-ko/v2yw4vn](https://businessinsider.com.pl/wiadomosci/kim-jest-aleksandra-k-wisniewska-corka-znanego-biznesmena-na-listach-ko/v2yw4vn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T07:59:26+00:00

Koalicja Obywatelska pokazała listy wyborcze do Sejmu i Senatu. Najwięcej uwagi zebrała kandydatura Michała Kołodziejczaka oraz inne "lokomotywy" z pierwszych miejsc list. Ciekawe postacie można jednak znaleźć na niższych pozycja. Jedną z nich jest Aleksandra K. Wiśniewska, działaczka humanitarna i córka znanego biznesmena.

## NBP wprowadzi do obiegu monety z flagą Ukrainy. "Przyjaźń i braterstwo to największe bogactwo"
 - [https://businessinsider.com.pl/wiadomosci/nbp-wprowadzi-do-obiegu-monety-z-flaga-ukrainy-przyjazn-i-braterstwo-to-najwieksze/f7me5nb](https://businessinsider.com.pl/wiadomosci/nbp-wprowadzi-do-obiegu-monety-z-flaga-ukrainy-przyjazn-i-braterstwo-to-najwieksze/f7me5nb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T07:52:31+00:00

Narodowy Bank Polski we współpracy z Narodowym Bankiem Ukrainy wprowadzi do obiegu okolicznościowe monety o nominale 10 zł i 10 hrywien z okazji Dnia Niepodległości Ukrainy. Emisja zaplanowana jest na 24 sierpnia, a moneta ma mieć kształt serca z napisem "Przyjaźń i braterstwo to największe bogactwo". Pieniądze z jej sprzedaży NBP przekaże Ukrainie w ramach wsparcia humanitarnego.

## Mocny regres w wynikach grupy Polsatu. Zobacz, ile płacą klienci
 - [https://businessinsider.com.pl/gielda/wiadomosci/polsat-plus-pokazuje-statystyki-i-wyniki-zobacz-ile-placa-klienci/31x466h](https://businessinsider.com.pl/gielda/wiadomosci/polsat-plus-pokazuje-statystyki-i-wyniki-zobacz-ile-placa-klienci/31x466h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T07:32:30+00:00

Biznes Zygmunta Solorza zanotował w ostatnich miesiącach spory regres, jeśli chodzi o finalne wyniki finansowe w odniesieniu do zysków sprzed roku. Grupa Polsat Plus narzeka na utrzymującą się po stronie kosztowej presję inflacyjną i wyższe koszty obsługi zadłużenia. Pokazuje liczbę świadczonych usług i wpływy od klientów.

## Myślisz o pompie ciepła? Urzędnicy ostrzegają
 - [https://businessinsider.com.pl/poradnik-finansowy/myslisz-o-pompie-ciepla-urzednicy-ostrzegaja/nx25ydz](https://businessinsider.com.pl/poradnik-finansowy/myslisz-o-pompie-ciepla-urzednicy-ostrzegaja/nx25ydz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T07:08:11+00:00

Popyt na pompy ciepła w Polsce w ostatnich latach wystrzelił, więc pojawiło się mnóstwo firm oferujących ich dostawę i montaż. Nie ma jednak co kierować się wyłącznie ceną przy ich wyborze. Pochopna decyzja może nastręczyć problemów w przyszłości.

## Nauczyciele rzutem na taśmę dostaną "ekstrapodwyżki"? Są konkrety
 - [https://businessinsider.com.pl/gospodarka/nauczyciele-rzutem-na-tasme-dostana-podwyzke-mowa-nawet-o-10-proc/d9kb637](https://businessinsider.com.pl/gospodarka/nauczyciele-rzutem-na-tasme-dostana-podwyzke-mowa-nawet-o-10-proc/d9kb637)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T06:10:15+00:00

"Solidarność" negocjuje z rządem, a szef związku Piotr Duda ma nawet indywidualnie rozmawiać na ten temat z premierem Morawieckim. Chodzi o podwyżki dla nauczycieli. Organizacje pracownicze wierzą, że uda się je wywalczyć jeszcze nawet od września.

## Kurs dolara 17 sierpnia w okolicy 4,1 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-17-sierpnia-2023/y51gfzg](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-17-sierpnia-2023/y51gfzg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T06:09:30+00:00

Kurs dolara w okolicy 4,1 zł. W czwartek rano 17 sierpnia 2023 r. rano kurs USD/PLN wynosi 4,1081.

## Kurs franka 17 sierpnia powyżej 4,6 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-17-sierpnia-2023/hxp3jbh](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-17-sierpnia-2023/hxp3jbh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T06:06:36+00:00

Frank szwajcarski powyżej 4,6 zł W czwartek 17 sierpnia 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,6685.

## Nowe dane ze sklepów. Tylko jedna kategoria produktów tanieje
 - [https://businessinsider.com.pl/wiadomosci/nowe-dane-ze-sklepow-tylko-jedna-kategoria-produktow-tanieje/lfzvh6m](https://businessinsider.com.pl/wiadomosci/nowe-dane-ze-sklepow-tylko-jedna-kategoria-produktow-tanieje/lfzvh6m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:36:21+00:00

W sklepach w lipcu widać było mniejsze wzrosty cen niż te notowane w czerwcu czy maju, ale konsumenci wciąż słono płacą za podstawowe produkty. Na 17 obserwowanych kategorii podrożało aż 16 i to przeważnie dwucyfrowo.

## Co dalej z lotniskiem Chopina? "Teren można zagospodarować na inny cel"
 - [https://businessinsider.com.pl/wiadomosci/co-dalej-z-lotniskiem-chopina-teren-mozna-zagospodarowac-na-inny-cel/rpj87vm](https://businessinsider.com.pl/wiadomosci/co-dalej-z-lotniskiem-chopina-teren-mozna-zagospodarowac-na-inny-cel/rpj87vm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:35:50+00:00

Co dalej z lotniskiem na Okęciu? — Metropolia warszawska będzie miała szansę, by duży kawałek terenu od A do Z zagospodarować na ten czy inny cel — tak o przyszłości portu im. Fryderyka Chopina w Warszawie mówi pełnomocnik rządu ds. CPK Marcin Horała.

## Generał Giennadij Żydko nie żyje. Kolejna tajemnicza śmierć w rosyjskiej armii
 - [https://businessinsider.com.pl/wiadomosci/general-giennadij-zydko-nie-zyje-kolejna-tajemnicza-smierc-w-rosyjskiej-armii/n0yf5vr](https://businessinsider.com.pl/wiadomosci/general-giennadij-zydko-nie-zyje-kolejna-tajemnicza-smierc-w-rosyjskiej-armii/n0yf5vr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:12:29+00:00

W wieku 58 lat zmarł w Moskwie wysoki rangą wojskowy Giennadij Żydko. W przeszłości był wiceministrem obrony Rosji, a w 2022 r. pełnił funkcję dowódcy zgrupowania wojsk w Ukrainie.

## Zamiast Ukraińców w Polsce pracują obywatele Azji
 - [https://businessinsider.com.pl/wiadomosci/juz-nie-ukraincy-w-polsce-pracuja-obywatele-azji/tv4z607](https://businessinsider.com.pl/wiadomosci/juz-nie-ukraincy-w-polsce-pracuja-obywatele-azji/tv4z607)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:10:00+00:00

Jak informuje "Rzeczpospolita" w środę, w fabrykach, hotelach i na budowach, gdzie do niedawna obok Polaków dominowali pracownicy z Ukrainy, obserwuje się coraz większą liczbę imigrantów, w tym także z bardzo odległych krajów.

## PFR szykuje pozew przeciwko NIK i Banasiowi. Wszystko przez korupcję
 - [https://businessinsider.com.pl/wiadomosci/pfr-kontra-nik-i-marian-banas-bedzie-pozew/w025j6h](https://businessinsider.com.pl/wiadomosci/pfr-kontra-nik-i-marian-banas-bedzie-pozew/w025j6h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:09:51+00:00

Polski Fundusz Rozwoju pozywa Najwyższą Izbę Kontroli. Informuje o tym "Dziennik Gazeta Prawna". Powód? PFR nie zgadza się z sugestiami prezesa Izby Mariana Banasia, który daje do zrozumienia, że przy wydawaniu publicznych pieniędzy z tzw. tarcz mogło dojść do procederu korupcyjnego.

## Kurs EUR/PLN 17 sierpnia 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-17-sierpnia-2023-r/zj1zh9g](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-17-sierpnia-2023-r/zj1zh9g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T05:00:01+00:00

Przedstawiamy bieżące notowania kursu waluty EUR oraz zmiany w ujęciu tygodniowym i dzień po dniu na 17 sierpnia 2023. Pokazujemy, jak zmienia się kurs euro w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs EUR wynosił: 4,4692 zł. Wszystkiego dowiesz się z poniższego artykułu.

## Dla kogo emerytury pomostowe? Wiemy, ile osób może skorzystać w 2024 r.
 - [https://businessinsider.com.pl/wiadomosci/dla-kogo-emerytury-pomostowe-wiemy-ile-osob-moze-skorzystac-w-2024-r/jbzm939](https://businessinsider.com.pl/wiadomosci/dla-kogo-emerytury-pomostowe-wiemy-ile-osob-moze-skorzystac-w-2024-r/jbzm939)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:54:35+00:00

Pod ustawą o emeryturach pomostowych jest już podpis prezydenta. Według szacunków ZUS z odświeżonego świadczenia może w przyszłym roku skorzystać kilka tysięcy osób.

## Emerytury pomostowe. Wiemy, ile osób może skorzystać w 2024 r.
 - [https://businessinsider.com.pl/wiadomosci/emerytury-pomostowe-wiemy-ile-osob-moze-skorzystac-w-2024-r/jbzm939](https://businessinsider.com.pl/wiadomosci/emerytury-pomostowe-wiemy-ile-osob-moze-skorzystac-w-2024-r/jbzm939)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:54:35+00:00

Pod ustawą o emeryturach pomostowych jest już podpis prezydenta. Według szacunków ZUS z odświeżonego świadczenia może w przyszłym roku skorzystać kilka tysięcy osób.

## RPO bada wpis Niedzielskiego. Wiemy, jak tłumaczy się były minister
 - [https://businessinsider.com.pl/wiadomosci/rpo-bada-wpis-niedzielskiego-wiemy-jak-tlumaczy-sie-byly-minister/mfddl78](https://businessinsider.com.pl/wiadomosci/rpo-bada-wpis-niedzielskiego-wiemy-jak-tlumaczy-sie-byly-minister/mfddl78)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:46:53+00:00

Choć Adam Niedzielski nie jest już szefem resortu zdrowia, to wciąż może ponieść odpowiedzialność za swój wpis na temat jednego z lekarzy. Rzecznik Praw Obywatelskich opublikował właśnie odpowiedź eksministra na postępowanie w tej sprawie.

## Jak liczyć dochód z IP Box? Jest ważny wyrok NSA
 - [https://businessinsider.com.pl/prawo/podatki/jak-liczyc-dochod-z-ip-box-jest-wazny-wyrok-nsa/gkmd3x3](https://businessinsider.com.pl/prawo/podatki/jak-liczyc-dochod-z-ip-box-jest-wazny-wyrok-nsa/gkmd3x3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:24:39+00:00

Ulga IP Box pozwala opodatkować dochody z praw własności intelektualnej 5-procentowym podatkiem. To bardzo atrakcyjna preferencja podatkowa dla podatników PIT i CIT, którzy prowadzą działalność badawczo-rozwojową. NSA rozstrzygnął w wyroku, jak liczyć dochód opodatkowany preferencją, jeśli jednym z elementów ceny towaru jest IP, czyli prawo intelektualne.

## Darowizna w banku? Zwolnienia z podatku nie będzie
 - [https://businessinsider.com.pl/prawo/podatki/masz-dostac-darowizne-nie-popelnij-tego-bledu-fiskus-potwierdza/mzh6pzt](https://businessinsider.com.pl/prawo/podatki/masz-dostac-darowizne-nie-popelnij-tego-bledu-fiskus-potwierdza/mzh6pzt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:16:26+00:00

Darowizny od najbliższej rodziny są zwolnione z podatku, ale trzeba spełnić warunki określone w ustawie o podatku od spadków i darowizn. Jeśli masz dostać pieniądze, to nie wystarczy pójść do banku. Potwierdza to najnowsza interpretacja indywidualna, niestety niekorzystna dla podatników.

## Oto nowe twarze w ekipie Tuska. Oni mają powalczyć o wygraną
 - [https://businessinsider.com.pl/wiadomosci/oto-nowe-twarze-w-ekipie-tuska-oni-maja-powalczyc-o-sejm/msx3hf4](https://businessinsider.com.pl/wiadomosci/oto-nowe-twarze-w-ekipie-tuska-oni-maja-powalczyc-o-sejm/msx3hf4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:10:00+00:00

Koalicja Obywatelska pokazała listy wyborcze do Sejmu i Senatu. A w nich sporo zaskoczeń. Donald Tusk przewietrzył partyjne towarzystwo i dał szansę nowym twarzom. Część z nich Polacy kojarzą z działalności na zupełnie innych polach niż w polityce. Sprawdziliśmy, na czym się dorobili i co mają ci, którzy w październiku powalczą o miejsce w parlamencie.

## Referendum mogłoby mieć sens, gdyby padły te oto pytania [OPINIA]
 - [https://businessinsider.com.pl/wiadomosci/referendum-mogloby-miec-sens-gdyby-padly-te-oto-pytania-opinia/pcd2jme](https://businessinsider.com.pl/wiadomosci/referendum-mogloby-miec-sens-gdyby-padly-te-oto-pytania-opinia/pcd2jme)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:10:00+00:00

Idea referendum nie ma w Polsce szczęścia. W tym roku partia rządząca postanowiła wykorzystać to narzędzie do partyjnej propagandy. A szkoda, bo jest kilka kwestii, o których Polacy powinni się w ten sposób wypowiedzieć. Oto nasza lista.

## Najnowszy blok w Jaworznie znów działa w kratkę. Łataliśmy dziurę importem prądu
 - [https://businessinsider.com.pl/gospodarka/najnowszy-blok-w-jaworznie-znow-dziala-w-kratke-latalismy-dziure-importem-pradu/e9v62lc](https://businessinsider.com.pl/gospodarka/najnowszy-blok-w-jaworznie-znow-dziala-w-kratke-latalismy-dziure-importem-pradu/e9v62lc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:05:00+00:00

Przez Polskę przechodzi fala upałów i choć możemy liczyć w tych dniach na wzmożoną pracę paneli słonecznych, to są godziny, w których dostępnych elektrowni mamy zbyt mało, by zaspokoić krajowe zapotrzebowanie na prąd. Z trudną sytuacją mierzyliśmy się we wtorek wieczorem, gdy z powodu kolejnej awarii z sieci wypadł najnowszy blok w Elektrowni Jaworzno. Operator krajowej sieci musiał w trybie pilnym sprowadzać energię z zagranicy.

## Ceny prądu, emerytury, referendum. Co przegłosował Sejm?
 - [https://businessinsider.com.pl/prawo/ceny-pradu-emerytury-referendum-sprawdz-jakie-zmiany-przyjal-sejm/8jbnrg8](https://businessinsider.com.pl/prawo/ceny-pradu-emerytury-referendum-sprawdz-jakie-zmiany-przyjal-sejm/8jbnrg8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-08-17T04:02:00+00:00

Za nami pracowita środa w Sejmie. Na finiszu kadencji posłowie przegłosowali przepisy, które są ważne m.in. dla opłacających rachunki za prąd, pracujących za granicą, planujących dodatkowe odkładanie na emeryturę. Powody do zadowolenia mają też m.in. kredytobiorcy, którzy skorzystali z wakacji kredytowych.

