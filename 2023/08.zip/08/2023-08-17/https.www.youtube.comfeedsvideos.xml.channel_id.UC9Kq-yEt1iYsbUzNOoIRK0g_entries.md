# Source:Pitch Meeting, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC9Kq-yEt1iYsbUzNOoIRK0g, language:en-US

## Meg 2: The Trench Pitch Meeting
 - [https://www.youtube.com/watch?v=q9zVYXxffCg](https://www.youtube.com/watch?v=q9zVYXxffCg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC9Kq-yEt1iYsbUzNOoIRK0g
 - date published: 2023-08-17T23:20:35+00:00

Step inside the Pitch Meeting that led to Meg 2: The Trench!

Subscribe for more Pitch Meetings: https://www.youtube.com/channel/UC9Kq-yEt1iYsbUzNOoIRK0g

Jason Statham fighting giant prehistoric sharks. That’s maybe the easiest pitch that’s ever been made, and first Meg movie made over half a billion dollars thanks to that awesome sounding premise. And when something makes half a billion dollars, you can bet we’re going to see some more of it.

Meg 2: The Trench definitely raises some questions. Like why is this shark movie mostly about humans running around doing sketchy stuff? How did Jason Statham free dive at 25,000 feet? Wait, these movies are based on books? Where did that Kraken come from and why isn’t anyone talking about it?

To answer all these questions, check out the pitch meeting that led to Meg 2: The Trench!

Check Out These Other Videos:

Barbenheimer Pitch Meeting
https://www.youtube.com/watch?v=saj2Q92wBkU

The Flash Pitch Meeting
https://www.youtube.com/watch?v=nzlSBBVpbS4

Our Social Media:
https://twitter.com/screenrant
https://www.facebook.com/PitchMeeting

Our Website
http://screenrant.com/

