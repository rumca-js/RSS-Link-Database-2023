# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Dino pokazało wyniki. Wzrosły zyski i przychody rdr
 - [https://www.bankier.pl/wiadomosc/Dino-Polska-mialo-w-II-kw-362-2-mln-zl-zysku-netto-wobec-konsensusu-386-9-mln-zl-zysku-8596383.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dino-Polska-mialo-w-II-kw-362-2-mln-zl-zysku-netto-wobec-konsensusu-386-9-mln-zl-zysku-8596383.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T18:02:12.509489+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/c0cc4aef447f55-945-560-0-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zysk netto grupy Dino Polska wyniósł w drugim kwartale 2023 roku 362,2 mln zł wobec 273,1 mln zł zysku rok wcześniej - podała spółka w raporcie półrocznym. Konsensus PAP Biznes zakładał 386,9 mln zł zysku netto.</p>

## Polacy zapłacą mniej za prąd... i to wstecz
 - [https://www.bankier.pl/wiadomosc/Polacy-zaplaca-mniej-za-prad-i-to-wstecz-8596376.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-zaplaca-mniej-za-prad-i-to-wstecz-8596376.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T18:02:12.501791+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/72c8f400c59dfb-948-568-0-0-1765-1059.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm przyjął w czwartek przepisy przewidujące 5-procentową, obowiązującą wstecznie od początku 2023 r., obniżkę cen energii elektrycznej dla gospodarstw domowych i odbiorców uprawnionych, korzystających - w ramach określonych limitów zużycia - z zamrożonych cen.</p>

## Sejm uchwalił ustawę o gwarancjach finansowych dla NABE
 - [https://www.bankier.pl/wiadomosc/Sejm-uchwalil-ustawe-o-gwarancjach-finansowych-dla-NABE-8596362.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-uchwalil-ustawe-o-gwarancjach-finansowych-dla-NABE-8596362.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T17:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/2ff99517593661-948-568-0-252-3878-2326.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił w czwartek ustawę o gwarancjach finansowych dla zobowiązań Narodowej Agencji Bezpieczeństwa Energetycznego. Suma gwarancji ma sięgnąć 70 mld zł.</p>

## Lex Czarnek przegłosowane. Szkoły czekają zmiany
 - [https://www.bankier.pl/wiadomosc/Lex-Czarnek-przeglosowane-Szkoly-czekaja-zmiany-8596360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lex-Czarnek-przeglosowane-Szkoly-czekaja-zmiany-8596360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T17:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/d605d4f80fb62f-948-568-0-196-3024-1814.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartek Sejm uchwalił nowelizację ustawy Prawo oświatowe, tzw. Chrońmy dzieci. Ma ona na celu wzmocnienie pozycji i głosu rodziców oraz ich przedstawicieli w szkolnej radzie rodziców w zakresie sprzeciwiania się niepożądanym treściom kierowanym do ich dzieci przez stowarzyszenia lub inne organizacje, prowadzące działalność m.in. w szkołach.</p>

## Bezpłatne leki dla dzieci i seniorów. Sejm podjął decyzję
 - [https://www.bankier.pl/wiadomosc/Bezplatne-leki-dla-dzieci-i-seniorow-Sejm-podjal-decyzje-8596329.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezplatne-leki-dla-dzieci-i-seniorow-Sejm-podjal-decyzje-8596329.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:57:12.668303+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/28ea4cf070287c-948-568-440-0-3483-2090.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm nie poparł w czwartek poprawek Senatu do nowelizacji ustawy o świadczeniach opieki zdrowotnej finansowanych ze środków publicznych oraz ustawy o refundacji leków, środków spożywczych specjalnego przeznaczenia żywieniowego oraz wyrobów medycznych.</p>

## Idą zmiany w OZE. Skorzystać mają mieszkańcy bloków
 - [https://www.bankier.pl/wiadomosc/Ida-zmiany-w-OZE-Bedzie-mozliwy-m-in-cable-pooling-8596347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ida-zmiany-w-OZE-Bedzie-mozliwy-m-in-cable-pooling-8596347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:57:12.659332+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/a/201248a4bf55f8-948-568-7-30-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm poparł w czwartek wszystkie poprawki Senatu do nowelizacji ustawy o OZE, w tym pakiet regulacji pozwalających na cable pooling - włączenie do sieci kilku źródeł na jednym przyłączu. Ustawa trafi teraz do prezydenta.</p>

## System kaucyjny w Polsce. Sejm przegłosował termin
 - [https://www.bankier.pl/wiadomosc/System-kaucyjny-w-Polsce-Sejm-przeglosowal-termin-8596348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/System-kaucyjny-w-Polsce-Sejm-przeglosowal-termin-8596348.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:57:12.652040+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/e0f49b1b367881-948-568-2-5-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm odrzucił w czwartek poprawki Senatu do ustawy o systemie kaucyjnym opakowań. Nowela przewiduje, że system kaucyjny zostanie wprowadzony w Polsce 1 stycznia 2025 r. Ustawa trafi teraz do prezydenta.</p>

## To już pewne. Sejm przegłosował zarządzenie referendum
 - [https://www.bankier.pl/wiadomosc/Sejm-przeglosowal-zarzadzenie-referendum-15-pazdziernika-2023-8596306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-przeglosowal-zarzadzenie-referendum-15-pazdziernika-2023-8596306.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:47:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/8e742471e031d8-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm przyjął w czwartek uchwałę o zarządzeniu referendum ogólnokrajowego na 15 października, czyli w dniu wyborów parlamentarnych. Padną w nim cztery pytania: o wyprzedaż majątku państwowego, o podniesienie wieku emerytalnego, o likwidację bariery na granicy z Białorusią oraz o relokację migrantów.</p>

## Sejm chce sztrzelnic na uczelniach. Przegłosowano ustawę w tej sprawie
 - [https://www.bankier.pl/wiadomosc/Sejm-chce-sztrzelnic-na-uczelniach-Przeglosowano-ustawe-w-tej-sprawie-8596293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-chce-sztrzelnic-na-uczelniach-Przeglosowano-ustawe-w-tej-sprawie-8596293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/c553944c9fce98-948-568-8-36-1576-945.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm opowiedział się w czwartek przeciwko uchwale Senatu o odrzucenie ustawy o budowie strzelnic przez uczelnie. Ustawa trafi teraz do podpisu przez prezydenta.</p>

## Zysk netto KGHM-u runął. Wyniki gorsze niż przewidywano
 - [https://www.bankier.pl/wiadomosc/Skorygowana-EBITDA-grupy-KGHM-wyniosla-w-II-kw-1-266-mld-zl-wobec-konsensusu-1-325-mld-zl-8596292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skorygowana-EBITDA-grupy-KGHM-wyniosla-w-II-kw-1-266-mld-zl-wobec-konsensusu-1-325-mld-zl-8596292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/18519cb4abfd68-948-568-165-0-2835-1700.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skorygowana EBITDA grupy KGHM wyniosła w drugim kwartale 2023 roku 1,266 mld zł wobec 2,176 mld zł w analogicznym okresie 2022 r. - podała spółka w raporcie półrocznym. Wynik okazał się ok. 4 proc. niższy od konsensusu PAP Biznes, który zakładał 1,325 mld zł skorygowanej EBITDA.</p>

## Powstanie kolejny duży rejestr Polaków. Ustawa trafi do podpisu przez prezydenta
 - [https://www.bankier.pl/wiadomosc/Powstanie-Centralna-Informacja-Emerytalna-Sejm-przeglosowal-nowy-rejestr-8596291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powstanie-Centralna-Informacja-Emerytalna-Sejm-przeglosowal-nowy-rejestr-8596291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T16:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/7f87e6ffbd5314-948-568-7-62-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm opowiedział się w czwartek przeciwko uchwale Senatu o odrzucenie ustawy o Centralnej Informacji Emerytalnej. Ustawa trafi teraz do podpisu przez prezydenta Andrzeja Dudę. Za CIE odpowiadał będzie Polski Fundusz Rozwoju.</p>

## Rosja ma problemy z amunicją? "Prosto z fabryki na front"
 - [https://www.bankier.pl/wiadomosc/Rosja-ma-problemy-z-amunicja-Prosto-z-fabryki-na-front-8596269.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-ma-problemy-z-amunicja-Prosto-z-fabryki-na-front-8596269.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T15:52:09.498999+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/69df213923b15a-945-567-0-0-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na północy Ukrainy znaleziono rosyjski pocisk do wieloprowadnicowej wyrzutni Tornado-S wyprodukowany w maju, co może świadczyć o tym, że Rosjanom kurczą się zapasy niektórych rodzajów nowoczesnej amunicji i Moskwa spieszy się z produkcją nowych pocisków - informuje w czwartek agencja Bloomberga.</p>

## Kolejna z rzędu spadkowa sesja WIG20. Na GPW znów przewaga czerwieni
 - [https://www.bankier.pl/wiadomosc/Kolejna-z-rzedu-spadkowa-sesja-WIG20-Na-GPW-znow-przewaga-czerwieni-8596287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kolejna-z-rzedu-spadkowa-sesja-WIG20-Na-GPW-znow-przewaga-czerwieni-8596287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T15:52:09.479663+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/3cc9527bb6ac5b-945-567-663-768-3543-2126.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To już czwarta z rzędu sesja ze spadkiem WIG20, co pogłębia korektę indeksu blue chipów do poziomu 2000 pkt. Dzień znów przyniósł szerokie spadki portfela największych spółek.  Rynkowe nastroje popsuły „jastrzębie” minutki Fedu opublikowane w środę wieczorem.</p>

## CD Projekt zaprezentuje nowy fragment "Widma Wolności". Padł termin
 - [https://www.bankier.pl/wiadomosc/CD-Projekt-zaprezentuje-nowy-fragment-Widma-Wolnosci-podczas-otwarcia-targow-gamescom-8596247.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CD-Projekt-zaprezentuje-nowy-fragment-Widma-Wolnosci-podczas-otwarcia-targow-gamescom-8596247.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T15:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/91acc4dac00dab-948-568-0-94-4193-2515.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />CD Projekt pokaże nowy fragment wideo z zapisem rozgrywki z "Cyberpunk 2077" Widmo Wolności" podczas gamescom Opening Night Live - podała spółka na platformie X (dawniej Twitter). Otwarcie targów gamescom w Kolonii będzie miało miejsce 22 sierpnia. Wydarzenie potrwa do 27 sierpnia.</p>

## Rainbow Tours szacuje zysk za I półrocze. Przychody wzrosły ponad 50 proc. rdr
 - [https://www.bankier.pl/wiadomosc/Rainbow-Tours-szacuje-ze-EBITDA-w-I-pol-23-wyniosla-78-7-mln-zl-8596242.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rainbow-Tours-szacuje-ze-EBITDA-w-I-pol-23-wyniosla-78-7-mln-zl-8596242.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T15:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/50af8312785e08-948-568-105-0-1800-1079.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rainbow Tours szacuje, że w I połowie 2023 roku jednostkowa EBITDA wyniosła 78,7 mln zł, a zysk netto jednostki dominującej wyniósł 56,6 mln zł - podała spółka w komunikacie.</p>

## Niemcy zapowiadają dalsze wsparcie Ukrainy. Przekażą m.in. system obrony powietrznej Iris-T
 - [https://www.bankier.pl/wiadomosc/Niemcy-zapowiadaja-dalsze-wsparcie-Ukrainy-Przekaza-m-in-system-obrony-powietrznej-Iris-T-8596208.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-zapowiadaja-dalsze-wsparcie-Ukrainy-Przekaza-m-in-system-obrony-powietrznej-Iris-T-8596208.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T14:47:06.843717+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/2/c8bf2011a97ac8-948-568-0-0-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraińska obrona powietrzna otrzyma dalsze wsparcie w sprzęcie wojskowym, w tym dwie wyrzutnie systemu obrony powietrznej Iris-T - wynika ze zaktualizowanej w czwartek listy pomocy wojskowej niemieckiego rządu, o czym informuje agencja dpa.</p>

## Brytyjską demografię ratują zagraniczne matki. Polki na 4. miejscu
 - [https://www.bankier.pl/wiadomosc/Brytyjska-demografie-ratuja-zagraniczne-matki-Polki-na-4-miejscu-8596195.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjska-demografie-ratuja-zagraniczne-matki-Polki-na-4-miejscu-8596195.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T14:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/603903678c21e8-948-568-0-269-2622-1573.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />30,3 proc. dzieci, które przyszły na świat w Anglii i Walii w ubiegłym roku, zostało urodzone przez matki pochodzące spoza Wielkiej Brytanii, co jest najwyższym odsetkiem w historii - podał w czwartek urząd statystyczny ONS. Polki są na czwartym miejscu, jeśli chodzi o kraj pochodzenia zagranicznych matek.</p>

## Rekordowy weekend w PKP Intercity. 300 tys. pasażerów więcej niż rok temu
 - [https://www.bankier.pl/wiadomosc/Rekordowy-weekend-w-PKP-Intercity-300-tys-pasazerow-wiecej-niz-rok-temu-8596161.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rekordowy-weekend-w-PKP-Intercity-300-tys-pasazerow-wiecej-niz-rok-temu-8596161.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T13:42:05.177172+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/4d88369bfb3a05-948-568-0-62-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W długi weekend sierpniowy z połączeń PKP Intercity skorzystało ponad 1,2 miliona pasażerów – poinformowała w czwartkowym komunikacie spółka PKP Intercity. To o 300 tys. więcej niż w analogicznym okresie poprzedniego roku i najwyższy wynik w historii spółki - dodano.</p>

## Stoltenberg: Ukraina sama zdecyduje, kiedy będą dobre warunki do rozmów pokojowych
 - [https://www.bankier.pl/wiadomosc/Stoltenberg-Ukraina-sama-zdecyduje-kiedy-beda-dobre-warunki-do-rozmow-pokojowych-8596128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stoltenberg-Ukraina-sama-zdecyduje-kiedy-beda-dobre-warunki-do-rozmow-pokojowych-8596128.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.823346+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/c1433f0d85123c-948-568-0-186-2488-1492.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina sama zdecyduje, kiedy nastaną odpowiednie warunki w celu podjęcia jakichkolwiek rozmów pokojowych z Rosją - oznajmił w czwartek sekretarz generalny NATO Jens Stoltenberg na konferencji w norweskim mieście Arendal.</p>

## Telus: Przeznaczyliśmy 1,2 mld euro na odtworzenie polskiego przetwórstwa
 - [https://www.bankier.pl/wiadomosc/Telus-Przeznaczylismy-1-2-mld-euro-na-odtworzenie-polskiego-przetworstwa-8596119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Telus-Przeznaczylismy-1-2-mld-euro-na-odtworzenie-polskiego-przetworstwa-8596119.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.820568+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/95e3bea5cf6415-948-568-14-0-1093-656.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O cenie produktów kupowanych od polskiego rolnika powinny decydować polskie firmy. Dlatego przeznaczyliśmy 1,2 mld euro na odtworzenie polskiego przetwórstwa - przekazał minister rolnictwa i rozwoju wsi Robert Telus.</p>

## Projekt ustawy o NABE przy okazji zniesie pozwolenia na budowę domów powyżej 70 m kw.
 - [https://www.bankier.pl/wiadomosc/Ustawa-o-NABE-z-wazna-wrzutka-o-budowie-domow-i-schronow-8596144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ustawa-o-NABE-z-wazna-wrzutka-o-budowie-domow-i-schronow-8596144.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.811554+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/8cc04897c6ec9f-948-568-71-368-3925-2355.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zwolnienie z pozwolenia na budowę domów powyżej 70 m kw. i przydomowych schronów - zakładają poprawki zgłoszone do projektu ustawy ws. Narodowej Agencji Bezpieczeństwa Energetycznego. Poprawki dotyczą również wykupu lokali z programu Mieszkanie Plus.</p>

## PIE: Dane GUS-u są wątpliwe i nie odzwierciedlają w pełni rzeczywistości gospodarczej
 - [https://www.bankier.pl/wiadomosc/PIE-Dane-GUS-sa-watpliwe-i-nie-odzwierciedlaja-w-pelni-rzeczywistosci-gospodarczej-8596129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIE-Dane-GUS-sa-watpliwe-i-nie-odzwierciedlaja-w-pelni-rzeczywistosci-gospodarczej-8596129.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.793313+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/5/b389bc3c1a5554-608-365-0-115-608-365.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Opublikowane przez GUS dane PKB za I i II kw. 2023 r. są wątpliwe i nie odzwierciedlają w pełni rzeczywistości gospodarczej. Problem GUS-u z odsezonowaniem trwa od kilku kwartałów – stwierdzono w czwartkowym komentarzu PIE.</p>

## Obniżki stóp proc. w Polsce stopniowe. Pierwsza możliwa już we wrześniu
 - [https://www.bankier.pl/wiadomosc/Obnizki-stop-proc-w-Polsce-stopniowe-Pierwsza-mozliwa-juz-we-wrzesniu-8596100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Obnizki-stop-proc-w-Polsce-stopniowe-Pierwsza-mozliwa-juz-we-wrzesniu-8596100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.788711+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/cc7892f10b3d4d-948-569-95-0-1816-1090.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wraz z postępującą dezinflacją tempo obniżek stóp procentowych będzie szybsze niż wcześniej prognozował rynek - prognozuje główna ekonomistka Alior Banku Agata Filipowicz-Rybicka. Jej zdaniem, obniżki stóp będą jednak stopniowe, po 25 pb na kwartał, co nie zmieni znacząco projekcji inflacji, a pierwsza obniżka może nastąpić już we wrześniu.</p>

## Norwegowie jeszcze bogatsi. Megafundusz "zarobił" dla nich więcej, niż wynoszą roczne dochody budżetu Polski
 - [https://www.bankier.pl/wiadomosc/Norwegowie-jeszcze-bogatsi-Megafundusz-zarobil-dla-nich-wiecej-niz-wynosza-roczne-dochody-budzetu-Polski-8596110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Norwegowie-jeszcze-bogatsi-Megafundusz-zarobil-dla-nich-wiecej-niz-wynosza-roczne-dochody-budzetu-Polski-8596110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:37:05.781092+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/7d4fdb529a1ea2-948-568-0-0-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skala działania Norweskiego Państwowego Funduszu Majątkowego jest tak duża, że przy dobrej koniunkturze na rynkach potrafi on przynieść zwrot, który nominalnie jest większy niż całoroczne dochody budżetu państwa polskiego.</p>

## Ruszył program "Moja woda". Środki już prawie się rozeszły
 - [https://www.bankier.pl/wiadomosc/Ruszyl-program-Moja-woda-Srodki-juz-prawie-sie-rozeszly-8596093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ruszyl-program-Moja-woda-Srodki-juz-prawie-sie-rozeszly-8596093.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/6937889135228b-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarejestrowane do środy wnioski w trzeciej edycji programu Moja Woda stanowią 70 proc. udostępnionych środków w kwocie 160 mln zł. W razie wyczerpania puli będziemy działać, aby została zwiększona - poinformowała w czwartek w Sejmie wiceminister klimatu i środowiska Małgorzata Golińska.</p>

## Nastroje w budowlance pogorszyły się. Powodem m.in. wysokie ceny produkcji
 - [https://www.bankier.pl/wiadomosc/Nastroje-w-budowlance-pogorszyly-sie-Powodem-m-in-wysokie-ceny-produkcji-8596088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nastroje-w-budowlance-pogorszyly-sie-Powodem-m-in-wysokie-ceny-produkcji-8596088.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T12:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/65ba91f27ccf99-948-568-0-129-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W sektorze budowlanym odnotowano w III kwartale symptomy pogorszenia sytuacji - wynika z badania Instytutu Rozwoju Gospodarczego SGH.</p>

## Recesja w Polsce? Nie ma mowy. Soboń optymistycznie o PKB
 - [https://www.bankier.pl/wiadomosc/Recesja-w-Polsce-Nie-ma-mowy-Sobon-optymistycznie-o-PKB-8596068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Recesja-w-Polsce-Nie-ma-mowy-Sobon-optymistycznie-o-PKB-8596068.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T11:32:02.454619+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/58df0ded9f0301-948-568-0-28-3820-2291.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska gospodarka w 2023 r. urośnie o ok. 1 proc., nie będzie recesji - poinformował podczas briefingu wiceminister finansów Artur Soboń, podtrzymując wcześniejsze prognozy resortu finansów. Dodał, że w 2024 r. PKB Polski wzrośnie o co najmniej 3 proc.</p>

## Kreml znów może manipulować kursem rubla. Kontrola kapitału powróci?
 - [https://www.bankier.pl/wiadomosc/Kreml-znow-moze-manipulowac-kursem-rubla-Kontrola-kapitalu-powroci-8596002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kreml-znow-moze-manipulowac-kursem-rubla-Kontrola-kapitalu-powroci-8596002.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T11:32:02.429566+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/6f030133f79309-948-568-0-148-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaledwie dzień po decyzji Banku Rosji o gwałtownej podwyżce stóp procentowych w celu przerwania deprecjacji rubla pojawiły się informacje o możliwym powrocie kontroli kapitału, którą rok temu Kreml zastosował, by wesprzeć krajową walutę w obliczu kumulacji sankcji.</p>

## Nie tylko filmy i seriale. Będę grał w grę... na Netfliksie
 - [https://www.bankier.pl/wiadomosc/Nie-tylko-filmy-i-seriale-Bede-gral-w-gre-na-Netfliksie-8596054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-tylko-filmy-i-seriale-Bede-gral-w-gre-na-Netfliksie-8596054.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T11:32:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/2753c9df60252e-948-568-2-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Netflix poinformował, że w ciągu kilku tygodni rozpoczną się testy związane z udostępnianiem gier w chmurze. Co ciekawe, nie będzie to dotyczyło urządzeń mobilnych, a telewizorów oraz komputerów - informuje portal Wirtualnemedia.pl.</p>

## Pakt Senacki zawarty. Koniec targów opozycji
 - [https://www.bankier.pl/wiadomosc/Pakt-Senacki-zawarty-Koniec-targow-opozycji-8596021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pakt-Senacki-zawarty-Koniec-targow-opozycji-8596021.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T10:52:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/d9dea1e282ee61-948-568-0-75-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zakończyły się prace nad drugą edycją Paktu Senackiego. - Pakt senacki ma wymiar symboliczny. Jestem przekonany, że tak jak udało nam się ze wzajemnym szacunkiem, zrozumieniem własnych racji ustalić wspólną listę do Senatu, tak po wygranych wyborach będzie nam łatwiej ustalić współpracę - powiedział w czwartek przewodniczący PO Donald Tusk.</p>

## Rosja wzbogaciła się o 600 miliardów dolarów. USA i Europa straciły biliony
 - [https://www.bankier.pl/wiadomosc/Rosja-wzbogacila-sie-o-600-miliardow-dolarow-USA-i-Europa-stracily-biliony-8596036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-wzbogacila-sie-o-600-miliardow-dolarow-USA-i-Europa-stracily-biliony-8596036.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T10:26:59.832068+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/71a7cfbf88ad0e-948-568-0-160-3200-1919.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rosja wzbogaciła się w ubiegłym roku o 600 miliardów dolarów, a liczba milionerów i osób o bardzo wysokim dochodzie rośnie, pomimo trwającej inwazji Rosji na Ukrainę - dowodzi w najnowszym raporcie szwajcarski bank UBS. W tym samym czasie Stany Zjednoczone i Europa straciły majątek warty biliony dolarów.</p>

## "Budżet czteroosobowej polskiej rodziny to 8 tys. 400 zł". Tak wyliczył minister Czarnek
 - [https://www.bankier.pl/wiadomosc/Budzet-czteroosobowej-polskiej-rodziny-to-8-tys-400-zl-Tak-wyliczyl-minister-Czarnek-8596024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Budzet-czteroosobowej-polskiej-rodziny-to-8-tys-400-zl-Tak-wyliczyl-minister-Czarnek-8596024.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T10:26:59.815979+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/e/2bd47734cb8b57-948-568-585-198-2714-1628.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2015 roku cały budżet czteroosobowej polskiej rodziny wynosił 3500 zł. W 2023 roku w sumie mają 8 tys. 400 zł - powiedział w czwartek w Sejmie minister edukacji i nauki Przemysław Czarnek, zabierając głos po debacie i pytaniach posłów w kwestii wniosku o przeprowadzenie referendum ogólnokrajowego.</p>

## Sejm przyjął wniosek rządu o przeprowadzenie referendum. Ruszą prace w Komisji Ustawodawczej
 - [https://www.bankier.pl/wiadomosc/Sejm-przyjal-wniosek-rzadu-o-przeprowadzenie-referendum-Rusza-prace-w-Komisji-Ustawodawczej-8595992.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-przyjal-wniosek-rzadu-o-przeprowadzenie-referendum-Rusza-prace-w-Komisji-Ustawodawczej-8595992.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T10:25:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/6/372f80b4a3644e-945-560-3-0-1496-897.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm przyjął w czwartek wniosek rządu o przeprowadzenie referendum ogólnokrajowego. Nie oznacza to jeszcze zarządzenia referendum. Teraz wniosek rządu trafi do Komisji Ustawodawczej, która przygotuje projekt uchwały o zarządzeniu referendum.</p>

## Dolar najdroższy od początku lipca. Scenariuszem bazowym jest wzrost kursu EUR/PLN
 - [https://www.bankier.pl/wiadomosc/Dolar-najdrozszy-od-poczatku-lipca-Scenariuszem-bazowym-jest-wzrost-kursu-EUR-PLN-8595956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dolar-najdrozszy-od-poczatku-lipca-Scenariuszem-bazowym-jest-wzrost-kursu-EUR-PLN-8595956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T09:21:57.804846+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/0024dfd64ae747-948-568-0-97-3550-2129.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Złoty dalej pozostaje słaby do głównych walut, a napływające dane makroekonomiczne nie dają podstaw do umocnienia polskiej waluty. Najwięcej zależy jednak od notowań eurodolara, który zniżkuje po publikowanych w środę wieczorem tzw. minutkach Fedu.</p>

## Apple zapłaci posiadaczom iPhone’ów za ich spowalnianie nawet 500 mln dol.
 - [https://www.bankier.pl/wiadomosc/Apple-zaplaci-posiadaczom-iPhone-ow-za-ich-spowalnianie-8595930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Apple-zaplaci-posiadaczom-iPhone-ow-za-ich-spowalnianie-8595930.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T08:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/d2a003eab91442-948-568-0-54-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Apple zapłaci od 310 do 500 mln dolarów użytkownikom iPhone’ów, którzy złożyli pozew zbiorowy w sprawie spowalniania urządzeń przez firmę z Cupertino – informuje Business Insider. Każdy z właścicieli wadliwych urządzeń otrzyma ok. 65 dolarów.</p>

## Wynagrodzenia w Popeyes. Tyle płaci konkurencja McDonald’s
 - [https://www.bankier.pl/wiadomosc/Wynagrodzenia-w-Popeyes-Tyle-placi-konkurencja-McDonald-s-8595915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wynagrodzenia-w-Popeyes-Tyle-placi-konkurencja-McDonald-s-8595915.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T08:16:58.124062+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/96700a9d566198-948-568-0-34-1157-694.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańska sieć Popeyes otworzyła w lipcu w Polsce swoją pierwszą placówkę, ale już planowana jest dalsza ekspansja. Portal eska.pl podaje, na jakie dokładnie stawki mogą liczyć pracownicy, którzy zdecydują się na pracę w jednej z tych restauracji fast food.</p>

## 40 tys. zł premii dla zarządu PKP, a systemu nie ma. "W obecnym tempie prace potrwają 645 lat"
 - [https://www.bankier.pl/wiadomosc/Zarzad-PKP-otrzymal-premie-a-systemu-z-pieniedzy-UE-dalej-nie-ma-W-obecnym-tempie-prace-potrwaja-645-lat-8595904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zarzad-PKP-otrzymal-premie-a-systemu-z-pieniedzy-UE-dalej-nie-ma-W-obecnym-tempie-prace-potrwaja-645-lat-8595904.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T08:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/0/82d75e67524047-948-568-0-0-2812-1687.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ośmiu członków zarządu PKP otrzymało premię w wysokości 36,7 tys. zł. Dodatek został wypłacony, pomimo iż narodowy przewoźnik nie zainstalował specjalnej łączności cyfrowej przeznaczonej dla kolei (systemu GSM-R) na żadnym z zaplanowanych 14 tys. km linii. A opóźnienia w realizacji inwestycji sięgają blisko trzech lat. Najwyższa Izba Kontroli żąda zwrotu pobranych pieniędzy.</p>

## Tornister kupiony na zeszyt? Tak Polacy zarabiają na szkolne wyprawki
 - [https://www.bankier.pl/wiadomosc/Tornister-kupiony-na-zeszyt-Tak-Polacy-zarabiaja-na-szkolne-wyprawki-8595898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tornister-kupiony-na-zeszyt-Tak-Polacy-zarabiaja-na-szkolne-wyprawki-8595898.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T07:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/68ddd72b4b19d8-945-560-0-30-1743-1045.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 4 mln uczniów już niebawem zasiądzie w ławkach polskich szkół. Gdy dzieci i młodzież korzystają jeszcze z wolnego, rodzice kompletują wyprawki. Żeby domowy budżet za bardzo nie odczuł tego wydatku,...</p>

## Zwykłe cenówki odchodzą do lamusa. W tych marketach zastąpią je wyświetlacze
 - [https://www.bankier.pl/wiadomosc/Zwykle-cenowki-odchodza-do-lamusa-W-tych-marketach-zastapia-je-wyswietlacze-8595883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zwykle-cenowki-odchodza-do-lamusa-W-tych-marketach-zastapia-je-wyswietlacze-8595883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T07:11:55.256553+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/e951fce5619451-948-568-17-988-2727-1636.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nowe rozwiązania technologiczne pojawiają się praktycznie w każdej branży. Nie inaczej jest w handlu. Okazuje się, że już niebawem jeden z największych graczy na rynku, Lidl Polska, wprowadzi system elektronicznych oznaczeń cenowych we wszystkich swoich placówkach - informuje portalspozywczy.pl.</p>

## W USA ropa zalicza duży spadek cen. Ceny paliw w Polsce rosną
 - [https://www.bankier.pl/wiadomosc/W-USA-ropa-zalicza-duzy-spadek-cen-Ceny-paliw-w-Polsce-rosna-8595875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-USA-ropa-zalicza-duzy-spadek-cen-Ceny-paliw-w-Polsce-rosna-8595875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T07:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/af26799598de3a-948-568-0-247-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku zniżkują kolejną sesję i są już poniżej 80 USD za baryłkę - wskazują maklerzy. Tymczasem średnia cena benzyny PB95 w Polsce w ciągu miesiąca wzrosła o 0,14 zł</p>

## "Nieprzyzwoite" greckie wakacje Ursuli von der Leyen? Europosłowie podnoszą alarm
 - [https://www.bankier.pl/wiadomosc/Nieprzyzwoite-greckie-wakacje-Ursuli-von-der-Leyen-Europoslowie-podnosza-alarm-8595847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nieprzyzwoite-greckie-wakacje-Ursuli-von-der-Leyen-Europoslowie-podnosza-alarm-8595847.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T06:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/c5c74ec95e5dcd-948-568-30-270-3970-2381.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szefowa Komisji Europejskiej Ursula von der Leyen spędziła ostatni weekend wraz z mężem na Krecie, jako gość greckiego premiera Kyriakosa Mitsotakisa. To "poważne naruszenie traktatów, przyzwoitości politycznej i neutralności" - oceniła holenderska europosłanka z liberalnej frakcji Renew, Sophie in 't Veld, w rozmowie z portalem informacyjnym Politico.</p>

## Mikrofirmy w tarapatach. Co czwarta sięgnęła w zeszłym roku po finansowanie zewnętrzne
 - [https://www.bankier.pl/wiadomosc/Mikrofirmy-w-tarapatach-Co-czwarta-siegala-w-zeszlym-roku-po-finansowanie-zewnetrzne-8595841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mikrofirmy-w-tarapatach-Co-czwarta-siegala-w-zeszlym-roku-po-finansowanie-zewnetrzne-8595841.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T06:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/1192fda1d3bd2f-945-560-148-5-1899-1139.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />26 proc. spośród ponad 500 przebadanych jednoosobowych mikrofirm sięgało w ubiegłym roku po finansowanie zewnętrzne, głównie na zakup towarów lub spłatę zobowiązań - wynika z badania "Barometr wydatków firmowych".</p>

## Burger King zmienia menu. Winny wzrost cen warzyw
 - [https://www.bankier.pl/wiadomosc/Burger-King-zmienia-menu-Winny-wzrost-cen-warzyw-8595655.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Burger-King-zmienia-menu-Winny-wzrost-cen-warzyw-8595655.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/9/360d8200c1ddce-948-568-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Burger King dołącza do sieci fast foodów, które wycofały pomidory ze swoich burgerów. Powodem są czterokrotnie wyższe ceny, związane z nieurodzajem - poinformowała agencja Reutera.</p>

## Druga odsłona kryzysu zbożowego. Tranzyt ukraińskiego zboża zablokuje polski eksport
 - [https://www.bankier.pl/wiadomosc/Druga-doslona-kryzysu-zbozowego-Tranzyt-ukrainskiego-zboza-zablokuje-polski-eksport-8595830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Druga-doslona-kryzysu-zbozowego-Tranzyt-ukrainskiego-zboza-zablokuje-polski-eksport-8595830.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/4784e5059555b0-948-568-10-60-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- Zostaniemy jeśli nie ze zbożem ukraińskim, to z naszym polskim. To jest sytuacja, która absolutnie wymaga rozwiązania - podkreśla Monika Piątkowska, prezes Izby Zbożowo-Paszowej. Zwraca uwagę na fakt, że po tegorocznych żniwach ok. 10 mln t nadwyżki z Polski trzeba będzie wyeksportować. Jednocześnie Ukraina - ze względu na zerwanie przez Rosję umowy zbożowej - będzie musiała transportować swoje zboże przez granicę lądową UE. To zaś oznacza większy tranzyt przez Polskę oraz większe obciążenie infrastruktury portowej i kolejowej.</p>

## Potrącenie dopłat za internet i prąd? Fiskus odpuszcza pracującym zdalnie
 - [https://www.bankier.pl/wiadomosc/Potracenie-doplat-za-internet-i-prad-Fiskus-odpuszcza-pracujacym-zdalnie-8595829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Potracenie-doplat-za-internet-i-prad-Fiskus-odpuszcza-pracujacym-zdalnie-8595829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/07c0e375811f26-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pracodawca powinien zapewnić pracującym zdalnie odpowiednie narzędzia i materiały, a w praktyce np. wypłacać ryczałty na pokrycie części kosztów. Fiskus przyznaje, że nie musi potrącać PIT od rekompensat za internet i prąd zużyty podczas home office - pisze w czwartek "Rzeczpospolita".</p>

## Ile osób będzie mogło przejść na emeryturę pomostową w 2024 r.?
 - [https://www.bankier.pl/wiadomosc/Ile-osob-bedzie-moglo-przejsc-na-emeryture-pomostowa-w-2024-r-8595815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ile-osob-bedzie-moglo-przejsc-na-emeryture-pomostowa-w-2024-r-8595815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/af1124b4cea3ad-948-568-0-84-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według szacunków po uchyleniu wygasającego charakteru emerytur pomostowych na to świadczenie przejdzie w 2024 r. około 7,3 tys. osób - przekazał PAP Zakład Ubezpieczeń Społecznych. Pod koniec czerwca 2023 r. emerytury pomostowe pobierało łącznie 40,8 tys. osób.</p>

## Oczekiwania sprzedających mieszkania rozmijają się z rzeczywistością. Średnio o kilkanaście procent
 - [https://www.bankier.pl/wiadomosc/Oczekiwania-sprzedajacych-mieszkania-rozmijaja-sie-z-rzeczywistoscia-Srednio-o-kilkanascie-procent-8595426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oczekiwania-sprzedajacych-mieszkania-rozmijaja-sie-z-rzeczywistoscia-Srednio-o-kilkanascie-procent-8595426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/8be85c6be4f3bf-948-568-0-124-1996-1197.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsza połowa 2023 r. przyniosła powiększenie się rozwarstwienia pomiędzy średnimi oczekiwaniami sprzedających mieszkania z drugiej ręki a średnimi kwotami faktycznie płaconymi za nie – wynika z danych Narodowego Banku Polskiego. W największych polskich miastach normą są kilkunastoprocentowe różnice.</p>

## Ranking kont z wypłatami z bankomatów. Który bank stoi na czele tabeli?
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-sierpien-2023-Najtansze-konta-bankowe-ROR-8595413.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-osobistych-sierpien-2023-Najtansze-konta-bankowe-ROR-8595413.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/fbc2d9f1519e81-948-568-0-210-2271-1362.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spośród najtańszych kont osobistych w poszczególnych bankach, tylko dwa dają możliwość dokonywania całkowicie bezpłatnych wypłat ze wszystkich bankomatów w Polsce oraz za granicą. Standardem jest natomiast pobieranie opłaty sięgającej co najmniej kilka złotych.</p>

## Życie po "Bezpiecznym kredycie 2 proc.". Czy po wygaśnięciu dopłat rata dobije korzystających z programu?
 - [https://www.bankier.pl/wiadomosc/Zycie-po-Bezpiecznym-kredycie-2-proc-Czy-po-wygasnieciu-doplat-rata-dobije-korzystajacych-z-programu-8595214.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zycie-po-Bezpiecznym-kredycie-2-proc-Czy-po-wygasnieciu-doplat-rata-dobije-korzystajacych-z-programu-8595214.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T05:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/f2577cda54a348-948-568-8-214-3571-2142.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W lipcu wystartował program „Pierwsze
mieszkanie”, którego elementem jest program „Bezpieczny kredyt 2 proc.”. W
ramach kredytu można otrzymać dopłaty od BGK obowiązujące przez 10
lat. W e-mailach do redakcji pytają Państwo, jakiego rzędu wzrostu rat należy się
spodziewać po tym okresie.</p>

## Duży pożar lasów na Teneryfie, trwa ewakuacja ludności. "Sytuacja wymknęła się spod kontroli"
 - [https://www.bankier.pl/wiadomosc/Hiszpania-Pozar-lasow-na-Teneryfie-Sytuacja-wymknela-sie-spod-kontroli-8595802.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Hiszpania-Pozar-lasow-na-Teneryfie-Sytuacja-wymknela-sie-spod-kontroli-8595802.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T01:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/290aef33bddb60-948-568-50-90-3950-2369.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 150 osób ewakuowały władze Wysp Kanaryjskich w środę wieczorem w związku z groźnym pożarem lasów w środkowo-północnej części Teneryfy, w gminach Arafo i Candelaria.</p>

## Ulewa nad lotniskiem we Frankfurcie. "Płyta zmieniona w jezioro"
 - [https://www.bankier.pl/wiadomosc/Ulewa-nad-lotniskiem-we-Frankfurcie-Plyta-zmieniona-w-jezioro-8595800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ulewa-nad-lotniskiem-we-Frankfurcie-Plyta-zmieniona-w-jezioro-8595800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-17T00:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/0/5260b01de9b92c-948-568-0-168-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z powodu intensywnych opadów deszczu odwołano w środę wieczorem na lotnisku we Frankfurcie dziesiątki lotów - poinformował rzecznik lotniska.</p>

