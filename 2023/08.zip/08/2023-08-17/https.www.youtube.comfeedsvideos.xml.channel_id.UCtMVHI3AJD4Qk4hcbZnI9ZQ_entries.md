# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Please Don't Buy Red Dead Redemption...
 - [https://www.youtube.com/watch?v=nHWv8d_D2KU](https://www.youtube.com/watch?v=nHWv8d_D2KU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-08-17T23:23:42+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at the release of a nearly 10 year old game known as Red Dead Redemption for a near full price with the most minimal of enhancements. This is not something you want to support. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the podcast merch: https://someordinarymerch.com/

