# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## RTE has 'no plans' to bring back Ireland's biggest TV star after scandal over salary
 - [https://news.sky.com/story/ryan-tubridy-rte-has-no-plans-to-bring-back-tv-star-after-talks-break-down-12941976](https://news.sky.com/story/ryan-tubridy-rte-has-no-plans-to-bring-back-tv-star-after-talks-break-down-12941976)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T18:43:00+00:00

Ireland's national broadcaster RTE says it has no plans to bring back star presenter Ryan Tubridy - after negotiations with the TV host broke down.

## This star could become one of the most powerful magnets in the universe
 - [https://news.sky.com/story/this-star-could-become-one-of-the-most-powerful-magnets-in-the-universe-12940005](https://news.sky.com/story/this-star-could-become-one-of-the-most-powerful-magnets-in-the-universe-12940005)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T18:00:00+00:00

Astronomers have uncovered a star that appears on course to become one of the strongest magnets in the universe.

## Thousands evacuated as 'out of control' wildfire burns in Tenerife
 - [https://news.sky.com/story/tenerife-wildfire-thousands-evacuated-as-firefighters-battle-out-of-control-blaze-12941891](https://news.sky.com/story/tenerife-wildfire-thousands-evacuated-as-firefighters-battle-out-of-control-blaze-12941891)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T16:08:00+00:00

Thousands of people have been evacuated in Tenerife as firefighters and the army struggle to contain an "out of control" wildfire.

## What is the 'Pi' COVID variant dubbed 'BA.6' &#8211; and should we be worried about it?
 - [https://news.sky.com/story/what-is-the-pi-covid-variant-dubbed-ba6-8211-and-should-we-be-worried-about-it-12941809](https://news.sky.com/story/what-is-the-pi-covid-variant-dubbed-ba6-8211-and-should-we-be-worried-about-it-12941809)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T15:25:00+00:00

Another new Omicron variant has got scientists talking.

## Flash flooding and landslides kill at least 72 in India's Himalayan region
 - [https://news.sky.com/story/india-flooding-at-least-72-killed-after-torrential-rain-triggers-flash-floods-and-landslides-in-himalayan-region-12941799](https://news.sky.com/story/india-flooding-at-least-72-killed-after-torrential-rain-triggers-flash-floods-and-landslides-in-himalayan-region-12941799)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T13:44:00+00:00

At least 72 people have died in India's Himalayan region after days of torrential rain triggered landslides and flash floods.

## Fake 'beach closed' signs installed in Mallorca to keep tourists away from popular spots
 - [https://news.sky.com/story/mallorca-fake-beach-closed-signs-installed-to-keep-tourists-away-from-popular-spots-12941770](https://news.sky.com/story/mallorca-fake-beach-closed-signs-installed-to-keep-tourists-away-from-popular-spots-12941770)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T12:56:00+00:00

Activists in Mallorca have put up fake signs warning of jellyfish and falling rocks to try to keep English-speaking tourists away from popular beaches.

## Sweden 'averts planned attacks' as terror alert level raised to second highest after Koran burnings
 - [https://news.sky.com/story/sweden-averts-planned-attacks-as-terror-alert-level-raised-to-second-highest-after-koran-burnings-12941709](https://news.sky.com/story/sweden-averts-planned-attacks-as-terror-alert-level-raised-to-second-highest-after-koran-burnings-12941709)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T11:26:00+00:00

Sweden's prime minister says planned attacks against his country have been averted as the security service raised the terror threat level to its second highest.

## Several dogs die after becoming trapped in flooded day care centre
 - [https://news.sky.com/story/washington-dc-several-dogs-die-after-becoming-trapped-in-flooded-day-care-centre-12941579](https://news.sky.com/story/washington-dc-several-dogs-die-after-becoming-trapped-in-flooded-day-care-centre-12941579)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T09:28:00+00:00

The deaths of several dogs at a day care centre during a flash flood was an "entirely preventable tragedy", a grief-stricken pet owner has said.

## 'I buried my sister 54 days after she was killed': How mass graves haunt a once thriving capital
 - [https://news.sky.com/story/i-buried-my-sister-54-days-after-she-was-killed-mass-graves-in-west-darfurs-capital-haunt-remaining-residents-12941508](https://news.sky.com/story/i-buried-my-sister-54-days-after-she-was-killed-mass-graves-in-west-darfurs-capital-haunt-remaining-residents-12941508)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T07:46:00+00:00

Once the thriving capital of West Darfur, al Geneina is now nearly deserted.

## Pig kidney keeps working in human body for over a month
 - [https://news.sky.com/story/pig-kidney-keeps-working-in-human-body-for-over-a-month-12941501](https://news.sky.com/story/pig-kidney-keeps-working-in-human-body-for-over-a-month-12941501)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T07:34:00+00:00

A genetically modified pig kidney transplanted into a brain-dead patient over a month ago is still working normally, researchers have found.

## World's longest rail tunnel will be closed for months after freight train derailed
 - [https://news.sky.com/story/gotthard-tunnel-in-switzerland-will-be-closed-for-months-after-freight-train-derailed-12941478](https://news.sky.com/story/gotthard-tunnel-in-switzerland-will-be-closed-for-months-after-freight-train-derailed-12941478)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T06:26:00+00:00

The world's longest rail tunnel has closed for repairs after a freight train derailed - and it is not expected to open for months.

## Thousands urged to evacuate by road and air as wildfire nears Canada's most northern city
 - [https://news.sky.com/story/canada-wildfires-thousands-urged-to-evacuate-by-road-and-air-as-blaze-nears-countrys-most-northern-city-12941470](https://news.sky.com/story/canada-wildfires-thousands-urged-to-evacuate-by-road-and-air-as-blaze-nears-countrys-most-northern-city-12941470)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T05:41:00+00:00

Thousands of people are being urged to leave a major city in Canada's Northwest Territories as a huge wildfire approaches.

## At least 60 migrants feared dead off the coast of Cape Verde after boat capsizes
 - [https://news.sky.com/story/at-least-60-migrants-feared-dead-off-the-coast-of-cape-verde-after-boat-capsizes-12941435](https://news.sky.com/story/at-least-60-migrants-feared-dead-off-the-coast-of-cape-verde-after-boat-capsizes-12941435)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-17T01:40:00+00:00

More than 60 people are feared dead after a boat carrying mostly Senegalese migrants capsized off the coast of Cape Verde in the Atlantic Ocean.

