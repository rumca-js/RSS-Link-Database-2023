# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## A Blood Factor Can Rejuvenate the Aging Brain
 - [https://www.insideprecisionmedicine.com/topics/molecular-dx-topic/a-blood-factor-can-rejuvenate-the-aging-brain/](https://www.insideprecisionmedicine.com/topics/molecular-dx-topic/a-blood-factor-can-rejuvenate-the-aging-brain/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T22:57:54+00:00

<p>Article URL: <a href="https://www.insideprecisionmedicine.com/topics/molecular-dx-topic/a-blood-factor-can-rejuvenate-the-aging-brain/">https://www.insideprecisionmedicine.com/topics/molecular-dx-topic/a-blood-factor-can-rejuvenate-the-aging-brain/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37169371">https://news.ycombinator.com/item?id=37169371</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## SUSE to Go Private
 - [https://opensourcewatch.beehiiv.com/p/suse-go-private](https://opensourcewatch.beehiiv.com/p/suse-go-private)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T22:51:33+00:00

<p>Article URL: <a href="https://opensourcewatch.beehiiv.com/p/suse-go-private">https://opensourcewatch.beehiiv.com/p/suse-go-private</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37169303">https://news.ycombinator.com/item?id=37169303</a></p>
<p>Points: 55</p>
<p># Comments: 20</p>

## The Aging Brain: Is Misplaced DNA to Blame?
 - [https://www.science.org/content/blog-post/aging-brain-misplaced-dna-blame](https://www.science.org/content/blog-post/aging-brain-misplaced-dna-blame)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T22:43:11+00:00

<p>Article URL: <a href="https://www.science.org/content/blog-post/aging-brain-misplaced-dna-blame">https://www.science.org/content/blog-post/aging-brain-misplaced-dna-blame</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37169226">https://news.ycombinator.com/item?id=37169226</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## The richest Americans account for 40 percent of U.S. climate emissions
 - [https://www.washingtonpost.com/climate-environment/2023/08/17/greenhouse-emissions-income-inequality/](https://www.washingtonpost.com/climate-environment/2023/08/17/greenhouse-emissions-income-inequality/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T21:55:15+00:00

<p>Article URL: <a href="https://www.washingtonpost.com/climate-environment/2023/08/17/greenhouse-emissions-income-inequality/">https://www.washingtonpost.com/climate-environment/2023/08/17/greenhouse-emissions-income-inequality/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37168704">https://news.ycombinator.com/item?id=37168704</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## “Green Smoothie Cleanse” Causing Acute Oxalate Nephropathy
 - [https://pubmed.ncbi.nlm.nih.gov/29203127/](https://pubmed.ncbi.nlm.nih.gov/29203127/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T21:11:46+00:00

<p>Article URL: <a href="https://pubmed.ncbi.nlm.nih.gov/29203127/">https://pubmed.ncbi.nlm.nih.gov/29203127/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37168142">https://news.ycombinator.com/item?id=37168142</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## How the Army tried and failed to build a bicycle corps (2020)
 - [https://www.armytimes.com/news/your-army/2020/02/25/how-the-army-tried-and-failed-to-build-a-bicycle-corps/](https://www.armytimes.com/news/your-army/2020/02/25/how-the-army-tried-and-failed-to-build-a-bicycle-corps/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T20:54:34+00:00

<p>Article URL: <a href="https://www.armytimes.com/news/your-army/2020/02/25/how-the-army-tried-and-failed-to-build-a-bicycle-corps/">https://www.armytimes.com/news/your-army/2020/02/25/how-the-army-tried-and-failed-to-build-a-bicycle-corps/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37167922">https://news.ycombinator.com/item?id=37167922</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Most React components offered by products aren’t usable
 - [https://blog.dopt.com/why-our-components-are-different](https://blog.dopt.com/why-our-components-are-different)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T20:48:15+00:00

<p>Article URL: <a href="https://blog.dopt.com/why-our-components-are-different">https://blog.dopt.com/why-our-components-are-different</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37167835">https://news.ycombinator.com/item?id=37167835</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## RoboAgent: A universal agent with 12 Skills
 - [https://robopen.github.io/](https://robopen.github.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T20:39:58+00:00

<p>Article URL: <a href="https://robopen.github.io/">https://robopen.github.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37167698">https://news.ycombinator.com/item?id=37167698</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## An underwater landslide knocked out two critical submarine cables serving Africa
 - [https://www.kentik.com/blog/dual-subsea-cable-cuts-disrupt-african-internet/](https://www.kentik.com/blog/dual-subsea-cable-cuts-disrupt-african-internet/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T20:31:38+00:00

<p>Article URL: <a href="https://www.kentik.com/blog/dual-subsea-cable-cuts-disrupt-african-internet/">https://www.kentik.com/blog/dual-subsea-cable-cuts-disrupt-african-internet/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37167562">https://news.ycombinator.com/item?id=37167562</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Fresh evidence of ChatGPT’s political bias: study
 - [https://www.uea.ac.uk/news/-/article/fresh-evidence-of-chatgpts-political-bias-revealed-by-comprehensive-new-study](https://www.uea.ac.uk/news/-/article/fresh-evidence-of-chatgpts-political-bias-revealed-by-comprehensive-new-study)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T20:03:13+00:00

<p>Article URL: <a href="https://www.uea.ac.uk/news/-/article/fresh-evidence-of-chatgpts-political-bias-revealed-by-comprehensive-new-study">https://www.uea.ac.uk/news/-/article/fresh-evidence-of-chatgpts-political-bias-revealed-by-comprehensive-new-study</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37167185">https://news.ycombinator.com/item?id=37167185</a></p>
<p>Points: 76</p>
<p># Comments: 101</p>

## Ancient Fires Drove Large Mammals Extinct, Study Suggests
 - [https://www.nytimes.com/2023/08/17/science/climate-paleontology-mammals.html](https://www.nytimes.com/2023/08/17/science/climate-paleontology-mammals.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T19:48:31+00:00

<p>Article URL: <a href="https://www.nytimes.com/2023/08/17/science/climate-paleontology-mammals.html">https://www.nytimes.com/2023/08/17/science/climate-paleontology-mammals.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166986">https://news.ycombinator.com/item?id=37166986</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## How to Communicate When Trust Is Low Without Digging Yourself into a Deeper Hole
 - [https://charity.wtf/2023/08/17/how-to-communicate-when-trust-is-low-without-digging-yourself-into-a-deeper-hole/](https://charity.wtf/2023/08/17/how-to-communicate-when-trust-is-low-without-digging-yourself-into-a-deeper-hole/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T19:44:47+00:00

<p>Article URL: <a href="https://charity.wtf/2023/08/17/how-to-communicate-when-trust-is-low-without-digging-yourself-into-a-deeper-hole/">https://charity.wtf/2023/08/17/how-to-communicate-when-trust-is-low-without-digging-yourself-into-a-deeper-hole/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166946">https://news.ycombinator.com/item?id=37166946</a></p>
<p>Points: 66</p>
<p># Comments: 9</p>

## Private equity firm announces a purchase offer with the intent to delist SUSE
 - [https://www.suse.com/news/EQT-announces-voluntary-public-purchase-offer-and-intention-to-delist-SUSE/](https://www.suse.com/news/EQT-announces-voluntary-public-purchase-offer-and-intention-to-delist-SUSE/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T19:40:41+00:00

<p>Article URL: <a href="https://www.suse.com/news/EQT-announces-voluntary-public-purchase-offer-and-intention-to-delist-SUSE/">https://www.suse.com/news/EQT-announces-voluntary-public-purchase-offer-and-intention-to-delist-SUSE/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166885">https://news.ycombinator.com/item?id=37166885</a></p>
<p>Points: 87</p>
<p># Comments: 53</p>

## Consensus: Use AI to find insights in research papers
 - [https://consensus.app/](https://consensus.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T19:40:32+00:00

<p>Article URL: <a href="https://consensus.app/">https://consensus.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166880">https://news.ycombinator.com/item?id=37166880</a></p>
<p>Points: 20</p>
<p># Comments: 2</p>

## JobCorps.Gov: free job training, food, housing and living allowance
 - [https://www.jobcorps.gov/](https://www.jobcorps.gov/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T19:07:45+00:00

<p>Article URL: <a href="https://www.jobcorps.gov/">https://www.jobcorps.gov/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166478">https://news.ycombinator.com/item?id=37166478</a></p>
<p>Points: 86</p>
<p># Comments: 56</p>

## Going back to the old (pre-X) Twitter iOS app
 - [https://blog.gingerbeardman.com/2023/08/17/going-back-to-the-old-pre-x-twitter-ios-app/](https://blog.gingerbeardman.com/2023/08/17/going-back-to-the-old-pre-x-twitter-ios-app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T18:44:10+00:00

<p>Article URL: <a href="https://blog.gingerbeardman.com/2023/08/17/going-back-to-the-old-pre-x-twitter-ios-app/">https://blog.gingerbeardman.com/2023/08/17/going-back-to-the-old-pre-x-twitter-ios-app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37166181">https://news.ycombinator.com/item?id=37166181</a></p>
<p>Points: 14</p>
<p># Comments: 11</p>

## SpaceX Revenue Doubled to $4.6B in 2022 Versus 2021
 - [https://www.wsj.com/tech/behind-the-curtain-of-elon-musks-secretive-spacex-revenue-growth-and-rising-costs-2c828e2b](https://www.wsj.com/tech/behind-the-curtain-of-elon-musks-secretive-spacex-revenue-growth-and-rising-costs-2c828e2b)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T18:24:03+00:00

<p>Article URL: <a href="https://www.wsj.com/tech/behind-the-curtain-of-elon-musks-secretive-spacex-revenue-growth-and-rising-costs-2c828e2b">https://www.wsj.com/tech/behind-the-curtain-of-elon-musks-secretive-spacex-revenue-growth-and-rising-costs-2c828e2b</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37165933">https://news.ycombinator.com/item?id=37165933</a></p>
<p>Points: 84</p>
<p># Comments: 79</p>

## Policy Engines: Open Policy Agent vs. AWS Cedar vs. Google Zanzibar
 - [https://www.permit.io/blog/policy-engines](https://www.permit.io/blog/policy-engines)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T18:06:44+00:00

<p>Article URL: <a href="https://www.permit.io/blog/policy-engines">https://www.permit.io/blog/policy-engines</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37165713">https://news.ycombinator.com/item?id=37165713</a></p>
<p>Points: 28</p>
<p># Comments: 7</p>

## Beautiful data visualization of the US stock market
 - [https://marketmap.one](https://marketmap.one)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T18:05:20+00:00

<p>Article URL: <a href="https://marketmap.one">https://marketmap.one</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37165697">https://news.ycombinator.com/item?id=37165697</a></p>
<p>Points: 55</p>
<p># Comments: 16</p>

## Too Many Fonts in Windows 10 Can Cause Slow Application Starts
 - [https://bigdanzblog.wordpress.com/2023/08/16/too-many-fonts-in-windows-10-can-cause-slow-application-starts/](https://bigdanzblog.wordpress.com/2023/08/16/too-many-fonts-in-windows-10-can-cause-slow-application-starts/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T17:22:21+00:00

<p>Article URL: <a href="https://bigdanzblog.wordpress.com/2023/08/16/too-many-fonts-in-windows-10-can-cause-slow-application-starts/">https://bigdanzblog.wordpress.com/2023/08/16/too-many-fonts-in-windows-10-can-cause-slow-application-starts/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37165119">https://news.ycombinator.com/item?id=37165119</a></p>
<p>Points: 25</p>
<p># Comments: 14</p>

## A Guide to Undefined Behavior in C and C++
 - [https://blog.regehr.org/archives/213](https://blog.regehr.org/archives/213)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T17:18:08+00:00

<p>Article URL: <a href="https://blog.regehr.org/archives/213">https://blog.regehr.org/archives/213</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37165042">https://news.ycombinator.com/item?id=37165042</a></p>
<p>Points: 25</p>
<p># Comments: 25</p>

## Show HN: Shadeform – Single Platform and API for Provisioning GPUs
 - [https://www.shadeform.ai/](https://www.shadeform.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T17:07:21+00:00

<p>Hi HN, we are Ed, Zach, and Ronald, creators of Shadeform (<a href="https://www.shadeform.ai/">https://www.shadeform.ai/</a>), a GPU marketplace to see live availability and prices across the GPU market, as well as to deploy and reserve on-demand instances. We have aggregated 8+ GPU providers into a single platform and API, so you can easily provision instances like A100s and H100s where they are available.<p>From our experience working at AWS and Azure, we believe that cloud could evolve from all-encompassing hyperscalers (AWS, Azure, GCP) to specialized clouds for high-performance use cases. After the launch of ChatGPT, we noticed GPU capacity thinning across major providers and emerging GPU and HPC clouds, so we decided it was the right time to build a single interface for IaaS across clouds.<p>With the explosion of Llama 2 and open source models, we are seeing individuals, startups, and organizations struggling to access A100s and H100s for model fine-tuning, training, and inference.<p>This encouraged us to help everyone access compute and increase flexibility with their cloud infra. Right now, we’ve built a platform that allows users to find GPU availability and launch instances from a unified platform. Our long term goal is to build a hardwareless GPU cloud where you can leverage managed ML services to train and infer in different clouds, reducing vendor lock-in.<p>We shipped a few features to help teams access GPUs today:<p>- a “single plane of glass” for GPU availability and prices;<p>- a “single control plane” for provisioning GPUs in any cloud through our platform and API;<p>- a reservation system that monitors real time availability and launches GPUs as soon as they become available.<p>Next up, we’re building multi-cloud load balanced inference, streamlining self hosting open source models, and more.<p>You can try our platform at <a href="https://platform.shadeform.ai">https://platform.shadeform.ai</a>. You can provision instances in your accounts by adding your cloud credentials and api keys, or you can leverage “ShadeCloud” and provision GPUs in our accounts. If you deploy in your account, it is free. If you deploy in our accounts, we charge a 5% platform fee.<p>We’d love your feedback on how we’re approaching this problem. What do you think?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164864">https://news.ycombinator.com/item?id=37164864</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Show HN: Not My Cows – Save your cows. Blast the meteors. Giddy up
 - [https://notmycows.com/](https://notmycows.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:55:36+00:00

<p>I made this straight vanilla JS game for a game jam a few years ago. Considering coming back to it and fixing the bugs and gameplay.<p><a href="https://github.com/jonfranco224/not-my-cows">https://github.com/jonfranco224/not-my-cows</a> if anyone wants to check the source.<p>Edit: y'all seem to be enjoying this! I spun up a quick Twitter/X for game updates if anyone is interested - <a href="https://twitter.com/notmycowsgame" rel="nofollow noreferrer">https://twitter.com/notmycowsgame</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164650">https://news.ycombinator.com/item?id=37164650</a></p>
<p>Points: 21</p>
<p># Comments: 19</p>

## Adyen Plummets as Sales Miss Erases $20B of Market Value
 - [https://finance.yahoo.com/news/adyen-plunges-20-hiring-inflation-072432744.html](https://finance.yahoo.com/news/adyen-plunges-20-hiring-inflation-072432744.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:45:16+00:00

<p>Article URL: <a href="https://finance.yahoo.com/news/adyen-plunges-20-hiring-inflation-072432744.html">https://finance.yahoo.com/news/adyen-plunges-20-hiring-inflation-072432744.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164452">https://news.ycombinator.com/item?id=37164452</a></p>
<p>Points: 27</p>
<p># Comments: 18</p>

## Is Slack Down?
 - [https://news.ycombinator.com/item?id=37164249](https://news.ycombinator.com/item?id=37164249)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:32:04+00:00

<p>I'm still receiving bot messages but can't seem to send anything</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164249">https://news.ycombinator.com/item?id=37164249</a></p>
<p>Points: 24</p>
<p># Comments: 7</p>

## My resignation letter as R7RS-large chair
 - [https://groups.google.com/g/scheme-reports-wg2/c/xGd0_eeKmGI/m/q-xM5fbuAQAJ](https://groups.google.com/g/scheme-reports-wg2/c/xGd0_eeKmGI/m/q-xM5fbuAQAJ)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:31:56+00:00

<p>Article URL: <a href="https://groups.google.com/g/scheme-reports-wg2/c/xGd0_eeKmGI/m/q-xM5fbuAQAJ">https://groups.google.com/g/scheme-reports-wg2/c/xGd0_eeKmGI/m/q-xM5fbuAQAJ</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164243">https://news.ycombinator.com/item?id=37164243</a></p>
<p>Points: 16</p>
<p># Comments: 3</p>

## YOLO-Driven Development Manifesto
 - [https://andersoncardoso.github.io/ydd/](https://andersoncardoso.github.io/ydd/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:28:16+00:00

<p>Article URL: <a href="https://andersoncardoso.github.io/ydd/">https://andersoncardoso.github.io/ydd/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164173">https://news.ycombinator.com/item?id=37164173</a></p>
<p>Points: 63</p>
<p># Comments: 33</p>

## Have you seen these dehumidifiers? Stop using them or you might die
 - [https://www.theverge.com/2023/8/16/23835116/have-you-seen-these-dehumidifiers-stop-using-them-or-you-might-die](https://www.theverge.com/2023/8/16/23835116/have-you-seen-these-dehumidifiers-stop-using-them-or-you-might-die)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:27:26+00:00

<p>Article URL: <a href="https://www.theverge.com/2023/8/16/23835116/have-you-seen-these-dehumidifiers-stop-using-them-or-you-might-die">https://www.theverge.com/2023/8/16/23835116/have-you-seen-these-dehumidifiers-stop-using-them-or-you-might-die</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37164155">https://news.ycombinator.com/item?id=37164155</a></p>
<p>Points: 31</p>
<p># Comments: 6</p>

## Fuzz testing: the best thing to happen to our application tests
 - [https://questdb.io/blog/fuzz-testing-questdb/](https://questdb.io/blog/fuzz-testing-questdb/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:15:29+00:00

<p>Article URL: <a href="https://questdb.io/blog/fuzz-testing-questdb/">https://questdb.io/blog/fuzz-testing-questdb/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37163980">https://news.ycombinator.com/item?id=37163980</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Why does email development have to suck? – Explaining all the <tr>'s and <td>'s
 - [https://dodov.dev/blog/why-does-email-development-have-to-suck](https://dodov.dev/blog/why-does-email-development-have-to-suck)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T16:03:23+00:00

<p>Article URL: <a href="https://dodov.dev/blog/why-does-email-development-have-to-suck">https://dodov.dev/blog/why-does-email-development-have-to-suck</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37163784">https://news.ycombinator.com/item?id=37163784</a></p>
<p>Points: 11</p>
<p># Comments: 9</p>

## Older mouse brains rejuvenated by protein found in young blood
 - [https://www.nature.com/articles/d41586-023-02563-z](https://www.nature.com/articles/d41586-023-02563-z)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:56:58+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-02563-z">https://www.nature.com/articles/d41586-023-02563-z</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37163684">https://news.ycombinator.com/item?id=37163684</a></p>
<p>Points: 69</p>
<p># Comments: 75</p>

## Straightforward Thai Railway Safety Posters
 - [https://www.thaitrainguide.com/2022/06/10/railway-safety-posters/](https://www.thaitrainguide.com/2022/06/10/railway-safety-posters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:47:52+00:00

<p>Article URL: <a href="https://www.thaitrainguide.com/2022/06/10/railway-safety-posters/">https://www.thaitrainguide.com/2022/06/10/railway-safety-posters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37163489">https://news.ycombinator.com/item?id=37163489</a></p>
<p>Points: 31</p>
<p># Comments: 20</p>

## Turmoil, a framework for developing and testing distributed systems
 - [https://tokio.rs/blog/2023-01-03-announcing-turmoil](https://tokio.rs/blog/2023-01-03-announcing-turmoil)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:28:39+00:00

<p>Article URL: <a href="https://tokio.rs/blog/2023-01-03-announcing-turmoil">https://tokio.rs/blog/2023-01-03-announcing-turmoil</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37163187">https://news.ycombinator.com/item?id=37163187</a></p>
<p>Points: 45</p>
<p># Comments: 6</p>

## I am afraid to inform you that you have built a compiler (2022)
 - [https://rachit.pl/post/you-have-built-a-compiler/](https://rachit.pl/post/you-have-built-a-compiler/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:10:50+00:00

<p>Article URL: <a href="https://rachit.pl/post/you-have-built-a-compiler/">https://rachit.pl/post/you-have-built-a-compiler/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37162898">https://news.ycombinator.com/item?id=37162898</a></p>
<p>Points: 84</p>
<p># Comments: 26</p>

## Three security teams just hacked a US Air Force satellite in space
 - [https://www.space.com/satellite-hacking-hack-a-sat-competition-winners](https://www.space.com/satellite-hacking-hack-a-sat-competition-winners)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:04:35+00:00

<p>Article URL: <a href="https://www.space.com/satellite-hacking-hack-a-sat-competition-winners">https://www.space.com/satellite-hacking-hack-a-sat-competition-winners</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37162811">https://news.ycombinator.com/item?id=37162811</a></p>
<p>Points: 30</p>
<p># Comments: 4</p>

## A proposal for much faster aircraft exit – “Fill and Flush”
 - [https://www.fillandflush.com](https://www.fillandflush.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:02:10+00:00

<p>Article URL: <a href="https://www.fillandflush.com">https://www.fillandflush.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37162774">https://news.ycombinator.com/item?id=37162774</a></p>
<p>Points: 33</p>
<p># Comments: 42</p>

## AMD Ryzen APU turned into a 16GB VRAM GPU and it can run Stable Diffusion
 - [https://old.reddit.com/r/Amd/comments/15t0lsm/i_turned_a_95_amd_apu_into_a_16gb_vram_gpu_and_it/](https://old.reddit.com/r/Amd/comments/15t0lsm/i_turned_a_95_amd_apu_into_a_16gb_vram_gpu_and_it/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T15:01:24+00:00

<p>Article URL: <a href="https://old.reddit.com/r/Amd/comments/15t0lsm/i_turned_a_95_amd_apu_into_a_16gb_vram_gpu_and_it/">https://old.reddit.com/r/Amd/comments/15t0lsm/i_turned_a_95_amd_apu_into_a_16gb_vram_gpu_and_it/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37162762">https://news.ycombinator.com/item?id=37162762</a></p>
<p>Points: 21</p>
<p># Comments: 7</p>

## Inflation Reduction Act impacts on the economics of hydrogen and liquid fuels
 - [https://arxiv.org/abs/2305.00946](https://arxiv.org/abs/2305.00946)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T14:50:59+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2305.00946">https://arxiv.org/abs/2305.00946</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37162588">https://news.ycombinator.com/item?id=37162588</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## The TextFX Project
 - [https://textfx.withgoogle.com/](https://textfx.withgoogle.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T13:43:45+00:00

<p>Article URL: <a href="https://textfx.withgoogle.com/">https://textfx.withgoogle.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37161441">https://news.ycombinator.com/item?id=37161441</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## We Don’t Need a New Twitter
 - [https://www.newyorker.com/culture/cultural-comment/we-dont-need-a-new-twitter](https://www.newyorker.com/culture/cultural-comment/we-dont-need-a-new-twitter)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T13:36:37+00:00

<p>Article URL: <a href="https://www.newyorker.com/culture/cultural-comment/we-dont-need-a-new-twitter">https://www.newyorker.com/culture/cultural-comment/we-dont-need-a-new-twitter</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37161347">https://news.ycombinator.com/item?id=37161347</a></p>
<p>Points: 36</p>
<p># Comments: 52</p>

## Show HN: Strich – Barcode scanning for web apps
 - [https://strich.io](https://strich.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T13:24:40+00:00

<p>Hi, I'm Alex - the creator of STRICH (<a href="https://strich.io" rel="nofollow noreferrer">https://strich.io</a>), a barcode scanning library for web apps.
Barcode scanning in web apps is nothing new. In my previous work experience, I've had the opportunity to use both high-end commercial offerings (e.g. Scandit) and OSS libraries like QuaggaJS or ZXing-JS in a wide range of customer projects, mainly in logistics.<p>I became dissatisfied with both. The established commercial offerings had five- to six-figure license fees and the developer experience was not always optimal. The web browser as a platform also seemed not to be the main priority for these players. The open source libraries are essentially unmaintained and not suitable for commercial use due to the lack of support. Also the recognition performance is not enough for some cases - for a detailed comparison see <a href="https://strich.io/comparison-with-oss.html" rel="nofollow noreferrer">https://strich.io/comparison-with-oss.html</a><p>Having dabbled a bit in Computer Vision topics before, and armed with an understanding of the market situation, I set out to build an alternative to fill the gap between the two worlds. After almost two years of on-and-off development and 6 months of piloting with a key customer, STRICH launched at beginning of this year.<p>STRICH is built exclusively for web browsers running on smartphones. I believe the vast majority of barcode scanning apps are in-house line of business apps that benefit from distribution outside of app stores and a single codebase with abundant developer resources. Barcode scanning in web apps is efficient and avoids platform risk and unnecessary costs associated with developing and publishing native apps.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37161184">https://news.ycombinator.com/item?id=37161184</a></p>
<p>Points: 21</p>
<p># Comments: 11</p>

## Google Chrome will summarize articles for you
 - [https://blog.google/products/search/google-search-generative-ai-learning-features/](https://blog.google/products/search/google-search-generative-ai-learning-features/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T13:17:16+00:00

<p>Article URL: <a href="https://blog.google/products/search/google-search-generative-ai-learning-features/">https://blog.google/products/search/google-search-generative-ai-learning-features/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37161097">https://news.ycombinator.com/item?id=37161097</a></p>
<p>Points: 38</p>
<p># Comments: 37</p>

## Faith Healers Are Back, and They’re Getting Rich
 - [https://thewalrus.ca/faith-healers-are-back-and-theyre-getting-rich/](https://thewalrus.ca/faith-healers-are-back-and-theyre-getting-rich/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T13:08:34+00:00

<p>Article URL: <a href="https://thewalrus.ca/faith-healers-are-back-and-theyre-getting-rich/">https://thewalrus.ca/faith-healers-are-back-and-theyre-getting-rich/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160981">https://news.ycombinator.com/item?id=37160981</a></p>
<p>Points: 10</p>
<p># Comments: 3</p>

## Retrieving 1TB of data from a bad Seagate Firecuda drive with woodworking tools
 - [https://blog.jgc.org/2023/08/retrieving-1tb-of-data-from-faulty.html](https://blog.jgc.org/2023/08/retrieving-1tb-of-data-from-faulty.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:51:00+00:00

<p>Article URL: <a href="https://blog.jgc.org/2023/08/retrieving-1tb-of-data-from-faulty.html">https://blog.jgc.org/2023/08/retrieving-1tb-of-data-from-faulty.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160783">https://news.ycombinator.com/item?id=37160783</a></p>
<p>Points: 65</p>
<p># Comments: 34</p>

## AI bots are now better than humans at decoding CAPTCHAs
 - [https://qz.com/ai-bots-recaptcha-turing-test-websites-authenticity-1850734350](https://qz.com/ai-bots-recaptcha-turing-test-websites-authenticity-1850734350)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:47:16+00:00

<p>Article URL: <a href="https://qz.com/ai-bots-recaptcha-turing-test-websites-authenticity-1850734350">https://qz.com/ai-bots-recaptcha-turing-test-websites-authenticity-1850734350</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160744">https://news.ycombinator.com/item?id=37160744</a></p>
<p>Points: 21</p>
<p># Comments: 6</p>

## Amazon's overcomplicated new product star ratings are no bright idea
 - [https://www.androidpolice.com/amazon-tests-new-star-ratings/](https://www.androidpolice.com/amazon-tests-new-star-ratings/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:43:02+00:00

<p>Article URL: <a href="https://www.androidpolice.com/amazon-tests-new-star-ratings/">https://www.androidpolice.com/amazon-tests-new-star-ratings/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160696">https://news.ycombinator.com/item?id=37160696</a></p>
<p>Points: 11</p>
<p># Comments: 11</p>

## Israeli Researchers Produce Green Hydrogen with 90% Efficiency
 - [https://www.autoevolution.com/news/israeli-researchers-produce-green-hydrogen-with-90-efficiency-without-electrolysis-218644.html](https://www.autoevolution.com/news/israeli-researchers-produce-green-hydrogen-with-90-efficiency-without-electrolysis-218644.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:41:23+00:00

<p>Article URL: <a href="https://www.autoevolution.com/news/israeli-researchers-produce-green-hydrogen-with-90-efficiency-without-electrolysis-218644.html">https://www.autoevolution.com/news/israeli-researchers-produce-green-hydrogen-with-90-efficiency-without-electrolysis-218644.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160677">https://news.ycombinator.com/item?id=37160677</a></p>
<p>Points: 32</p>
<p># Comments: 12</p>

## Cellphone Radiation Is Harmful, but Few Want to Believe It
 - [https://neurosciencenews.com/cellphone-radiation-brain-cancer-18889/](https://neurosciencenews.com/cellphone-radiation-brain-cancer-18889/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:39:44+00:00

<p>Article URL: <a href="https://neurosciencenews.com/cellphone-radiation-brain-cancer-18889/">https://neurosciencenews.com/cellphone-radiation-brain-cancer-18889/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160651">https://news.ycombinator.com/item?id=37160651</a></p>
<p>Points: 17</p>
<p># Comments: 12</p>

## Debian Celebrates 30 Years
 - [https://bits.debian.org/2023/08/debian-turns-30.html](https://bits.debian.org/2023/08/debian-turns-30.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T12:31:39+00:00

<p>Article URL: <a href="https://bits.debian.org/2023/08/debian-turns-30.html">https://bits.debian.org/2023/08/debian-turns-30.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37160580">https://news.ycombinator.com/item?id=37160580</a></p>
<p>Points: 86</p>
<p># Comments: 24</p>

## Fusion Foolery
 - [https://dothemath.ucsd.edu/2023/08/fusion-foolery/](https://dothemath.ucsd.edu/2023/08/fusion-foolery/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T11:12:45+00:00

<p>Article URL: <a href="https://dothemath.ucsd.edu/2023/08/fusion-foolery/">https://dothemath.ucsd.edu/2023/08/fusion-foolery/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37159887">https://news.ycombinator.com/item?id=37159887</a></p>
<p>Points: 34</p>
<p># Comments: 5</p>

## We've Teamed Up with Mullvad VPN to Launch the Mullvad Browser
 - [https://blog.torproject.org/releasing-mullvad-browser/](https://blog.torproject.org/releasing-mullvad-browser/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T10:51:56+00:00

<p>Article URL: <a href="https://blog.torproject.org/releasing-mullvad-browser/">https://blog.torproject.org/releasing-mullvad-browser/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37159744">https://news.ycombinator.com/item?id=37159744</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Asteroid crater 520km in diameter buried deep in southeast Australia
 - [https://www.australiangeographic.com.au/topics/science-environment/2023/08/asteroid-crater-520km-in-diameter-buried-deep-in-southeast-australia-scientists-say/](https://www.australiangeographic.com.au/topics/science-environment/2023/08/asteroid-crater-520km-in-diameter-buried-deep-in-southeast-australia-scientists-say/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T10:39:52+00:00

<p>Article URL: <a href="https://www.australiangeographic.com.au/topics/science-environment/2023/08/asteroid-crater-520km-in-diameter-buried-deep-in-southeast-australia-scientists-say/">https://www.australiangeographic.com.au/topics/science-environment/2023/08/asteroid-crater-520km-in-diameter-buried-deep-in-southeast-australia-scientists-say/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37159680">https://news.ycombinator.com/item?id=37159680</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Software Engineering Lessons from RCAs of greatest disasters
 - [https://anoopdixith.com/disasters/](https://anoopdixith.com/disasters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T08:38:30+00:00

<p>Article URL: <a href="https://anoopdixith.com/disasters/">https://anoopdixith.com/disasters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158827">https://news.ycombinator.com/item?id=37158827</a></p>
<p>Points: 7</p>
<p># Comments: 6</p>

## We Ruined Status LEDs; Here’s Why That Needs to Change
 - [https://hackaday.com/2020/02/20/we-ruined-status-leds-heres-why-that-needs-to-change/](https://hackaday.com/2020/02/20/we-ruined-status-leds-heres-why-that-needs-to-change/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T08:27:30+00:00

<p>Article URL: <a href="https://hackaday.com/2020/02/20/we-ruined-status-leds-heres-why-that-needs-to-change/">https://hackaday.com/2020/02/20/we-ruined-status-leds-heres-why-that-needs-to-change/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158745">https://news.ycombinator.com/item?id=37158745</a></p>
<p>Points: 37</p>
<p># Comments: 20</p>

## Petition to stop France from forcing browsers like Firefox to censor websites
 - [https://foundation.mozilla.org/en/campaigns/sign-our-petition-to-stop-france-from-forcing-browsers-like-mozillas-firefox-to-censor-websites/](https://foundation.mozilla.org/en/campaigns/sign-our-petition-to-stop-france-from-forcing-browsers-like-mozillas-firefox-to-censor-websites/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T08:23:22+00:00

<p>Article URL: <a href="https://foundation.mozilla.org/en/campaigns/sign-our-petition-to-stop-france-from-forcing-browsers-like-mozillas-firefox-to-censor-websites/">https://foundation.mozilla.org/en/campaigns/sign-our-petition-to-stop-france-from-forcing-browsers-like-mozillas-firefox-to-censor-websites/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158710">https://news.ycombinator.com/item?id=37158710</a></p>
<p>Points: 57</p>
<p># Comments: 14</p>

## Long Covid in a highly vaccinated population – Australia, 2022
 - [https://www.medrxiv.org/content/10.1101/2023.08.06.23293706v1](https://www.medrxiv.org/content/10.1101/2023.08.06.23293706v1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T08:08:33+00:00

<p>Article URL: <a href="https://www.medrxiv.org/content/10.1101/2023.08.06.23293706v1">https://www.medrxiv.org/content/10.1101/2023.08.06.23293706v1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158605">https://news.ycombinator.com/item?id=37158605</a></p>
<p>Points: 21</p>
<p># Comments: 5</p>

## Getting a job at Apple without going to college or doing LeetCode
 - [https://aheze.substack.com/p/getting-a-job-at-apple-without-going](https://aheze.substack.com/p/getting-a-job-at-apple-without-going)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T07:33:35+00:00

<p>Article URL: <a href="https://aheze.substack.com/p/getting-a-job-at-apple-without-going">https://aheze.substack.com/p/getting-a-job-at-apple-without-going</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158398">https://news.ycombinator.com/item?id=37158398</a></p>
<p>Points: 44</p>
<p># Comments: 35</p>

## DIY Espresso (2020)
 - [https://www.fourbardesign.com/2020/10/diy-espresso.html](https://www.fourbardesign.com/2020/10/diy-espresso.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T07:21:40+00:00

<p>Article URL: <a href="https://www.fourbardesign.com/2020/10/diy-espresso.html">https://www.fourbardesign.com/2020/10/diy-espresso.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158317">https://news.ycombinator.com/item?id=37158317</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## German Cabinet approves liberalization of Cannabis Possession
 - [https://www.politico.eu/article/germany-bundestag-cabinet-approves-liberalization-of-cannabis-rules/](https://www.politico.eu/article/germany-bundestag-cabinet-approves-liberalization-of-cannabis-rules/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T07:19:36+00:00

<p>Article URL: <a href="https://www.politico.eu/article/germany-bundestag-cabinet-approves-liberalization-of-cannabis-rules/">https://www.politico.eu/article/germany-bundestag-cabinet-approves-liberalization-of-cannabis-rules/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158306">https://news.ycombinator.com/item?id=37158306</a></p>
<p>Points: 47</p>
<p># Comments: 36</p>

## Dart 3.1 and a retrospective on functional style programming in Dart
 - [https://medium.com/dartlang/dart-3-1-a-retrospective-on-functional-style-programming-in-dart-3-a1f4b3a7cdda](https://medium.com/dartlang/dart-3-1-a-retrospective-on-functional-style-programming-in-dart-3-a1f4b3a7cdda)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T06:46:30+00:00

<p>Article URL: <a href="https://medium.com/dartlang/dart-3-1-a-retrospective-on-functional-style-programming-in-dart-3-a1f4b3a7cdda">https://medium.com/dartlang/dart-3-1-a-retrospective-on-functional-style-programming-in-dart-3-a1f4b3a7cdda</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37158068">https://news.ycombinator.com/item?id=37158068</a></p>
<p>Points: 20</p>
<p># Comments: 11</p>

## New York Times considers legal action against OpenAI as copyright tensions swirl
 - [https://text.npr.org/1194202562](https://text.npr.org/1194202562)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T06:33:18+00:00

<p>Article URL: <a href="https://text.npr.org/1194202562">https://text.npr.org/1194202562</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37157989">https://news.ycombinator.com/item?id=37157989</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## A world to win: WebAssembly for the rest of us
 - [https://wingolog.org/archives/2023/03/20/a-world-to-win-webassembly-for-the-rest-of-us](https://wingolog.org/archives/2023/03/20/a-world-to-win-webassembly-for-the-rest-of-us)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T05:19:31+00:00

<p>Article URL: <a href="https://wingolog.org/archives/2023/03/20/a-world-to-win-webassembly-for-the-rest-of-us">https://wingolog.org/archives/2023/03/20/a-world-to-win-webassembly-for-the-rest-of-us</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37157552">https://news.ycombinator.com/item?id=37157552</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## DeepEval – Unit Testing for LLMs
 - [https://github.com/mr-gpt/deepeval](https://github.com/mr-gpt/deepeval)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T04:42:38+00:00

<p>Article URL: <a href="https://github.com/mr-gpt/deepeval">https://github.com/mr-gpt/deepeval</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37157323">https://news.ycombinator.com/item?id=37157323</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## Mastermind Solver
 - [https://stefanabikaram.com/blog/mastermind-solver/](https://stefanabikaram.com/blog/mastermind-solver/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T03:33:41+00:00

<p>Article URL: <a href="https://stefanabikaram.com/blog/mastermind-solver/">https://stefanabikaram.com/blog/mastermind-solver/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156842">https://news.ycombinator.com/item?id=37156842</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## 1834: The First Cyberattack (2017)
 - [https://www.economist.com/1843/2017/10/05/the-crooked-timber-of-humanity](https://www.economist.com/1843/2017/10/05/the-crooked-timber-of-humanity)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T03:22:30+00:00

<p>Article URL: <a href="https://www.economist.com/1843/2017/10/05/the-crooked-timber-of-humanity">https://www.economist.com/1843/2017/10/05/the-crooked-timber-of-humanity</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156763">https://news.ycombinator.com/item?id=37156763</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## NP-hard does not mean hard (2017)
 - [https://jeremykun.com/2017/12/29/np-hard-does-not-mean-hard/](https://jeremykun.com/2017/12/29/np-hard-does-not-mean-hard/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T03:11:36+00:00

<p>Article URL: <a href="https://jeremykun.com/2017/12/29/np-hard-does-not-mean-hard/">https://jeremykun.com/2017/12/29/np-hard-does-not-mean-hard/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156696">https://news.ycombinator.com/item?id=37156696</a></p>
<p>Points: 14</p>
<p># Comments: 4</p>

## Harvard Tells Grad Students to Get Food Stamps
 - [https://www.vice.com/en/article/93kwaa/harvard-tells-grad-students-to-get-food-stamps-to-supplement-the-unlivable-wages-it-pays-them](https://www.vice.com/en/article/93kwaa/harvard-tells-grad-students-to-get-food-stamps-to-supplement-the-unlivable-wages-it-pays-them)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:54:43+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/93kwaa/harvard-tells-grad-students-to-get-food-stamps-to-supplement-the-unlivable-wages-it-pays-them">https://www.vice.com/en/article/93kwaa/harvard-tells-grad-students-to-get-food-stamps-to-supplement-the-unlivable-wages-it-pays-them</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156603">https://news.ycombinator.com/item?id=37156603</a></p>
<p>Points: 31</p>
<p># Comments: 19</p>

## Zed: Leveraging Data Types to Process Eclectic Data [pdf]
 - [https://www.cidrdb.org/cidr2023/papers/p52-ousterhout.pdf](https://www.cidrdb.org/cidr2023/papers/p52-ousterhout.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:53:23+00:00

<p>Article URL: <a href="https://www.cidrdb.org/cidr2023/papers/p52-ousterhout.pdf">https://www.cidrdb.org/cidr2023/papers/p52-ousterhout.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156592">https://news.ycombinator.com/item?id=37156592</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The Princeton Companion to Mathematics [pdf]
 - [https://sites.math.rutgers.edu/~zeilberg/akherim/PCM.pdf](https://sites.math.rutgers.edu/~zeilberg/akherim/PCM.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:36:58+00:00

<p>Article URL: <a href="https://sites.math.rutgers.edu/~zeilberg/akherim/PCM.pdf">https://sites.math.rutgers.edu/~zeilberg/akherim/PCM.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156496">https://news.ycombinator.com/item?id=37156496</a></p>
<p>Points: 32</p>
<p># Comments: 8</p>

## Poland’s ‘anti-vampire’ graves
 - [https://www.atlasobscura.com/articles/anti-vampire-graves-poland](https://www.atlasobscura.com/articles/anti-vampire-graves-poland)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:24:57+00:00

<p>Article URL: <a href="https://www.atlasobscura.com/articles/anti-vampire-graves-poland">https://www.atlasobscura.com/articles/anti-vampire-graves-poland</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156425">https://news.ycombinator.com/item?id=37156425</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## A Search for Technosignatures Around 11,680 Nearby Stars
 - [https://arxiv.org/abs/2308.02712](https://arxiv.org/abs/2308.02712)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:18:15+00:00

<p>Article URL: <a href="https://arxiv.org/abs/2308.02712">https://arxiv.org/abs/2308.02712</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156373">https://news.ycombinator.com/item?id=37156373</a></p>
<p>Points: 27</p>
<p># Comments: 25</p>

## Ask HN: Any interesting books you have read lately?
 - [https://news.ycombinator.com/item?id=37156372](https://news.ycombinator.com/item?id=37156372)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:18:00+00:00

<p>Mine would be The Utopians trilogy[1], I recommend it to anyone looking for a good sci-fi read.<p>[1]: https://stallman.org/Bob-Chassell</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156372">https://news.ycombinator.com/item?id=37156372</a></p>
<p>Points: 11</p>
<p># Comments: 11</p>

## Unit (Visual Programming System) [video]
 - [https://www.youtube.com/watch?v=lvvzolKHt2E](https://www.youtube.com/watch?v=lvvzolKHt2E)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T02:13:25+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=lvvzolKHt2E">https://www.youtube.com/watch?v=lvvzolKHt2E</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156337">https://news.ycombinator.com/item?id=37156337</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## CATL reveals ‘Superfast Charging Battery,’ boasts 250mi range with 10-min charge
 - [https://electrek.co/2023/08/16/catl-new-fast-charging-battery-250-mi-10-min/](https://electrek.co/2023/08/16/catl-new-fast-charging-battery-250-mi-10-min/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T01:58:38+00:00

<p>Article URL: <a href="https://electrek.co/2023/08/16/catl-new-fast-charging-battery-250-mi-10-min/">https://electrek.co/2023/08/16/catl-new-fast-charging-battery-250-mi-10-min/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156232">https://news.ycombinator.com/item?id=37156232</a></p>
<p>Points: 9</p>
<p># Comments: 4</p>

## Ask HN: Tell us about your project that's not done yet but you want feedback on
 - [https://news.ycombinator.com/item?id=37156101](https://news.ycombinator.com/item?id=37156101)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T01:37:38+00:00

<p>A lot of times with side projects I wished I had gotten feedback early on, before I spent a lot of time on an inefficient direction. I wonder if people wait too long to publish something before it is fully polished, then realized that the polishing wasn't needed.<p>I'm interested to see things that people would have never published otherwise. I know a lot of my projects never make it to a published phase, but I still would have been interested in knowing the general reception. Please drop your projects here!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37156101">https://news.ycombinator.com/item?id=37156101</a></p>
<p>Points: 45</p>
<p># Comments: 86</p>

## StarFive VisionFive 2 Quad-Core RISC-V Performance Benchmarks
 - [https://www.phoronix.com/review/visionfive2-riscv-benchmarks](https://www.phoronix.com/review/visionfive2-riscv-benchmarks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T01:19:13+00:00

<p>Article URL: <a href="https://www.phoronix.com/review/visionfive2-riscv-benchmarks">https://www.phoronix.com/review/visionfive2-riscv-benchmarks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37155969">https://news.ycombinator.com/item?id=37155969</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Tape Storage Might Be Computing’s Climate Savior
 - [https://spectrum.ieee.org/tape-storage-sustainable-option](https://spectrum.ieee.org/tape-storage-sustainable-option)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T01:16:48+00:00

<p>Article URL: <a href="https://spectrum.ieee.org/tape-storage-sustainable-option">https://spectrum.ieee.org/tape-storage-sustainable-option</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37155957">https://news.ycombinator.com/item?id=37155957</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## Captain Zilog Crushed: The Story of the Z8000
 - [https://thechipletter.substack.com/p/captain-zilog-crushed-the-story-of](https://thechipletter.substack.com/p/captain-zilog-crushed-the-story-of)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T00:42:50+00:00

<p>Article URL: <a href="https://thechipletter.substack.com/p/captain-zilog-crushed-the-story-of">https://thechipletter.substack.com/p/captain-zilog-crushed-the-story-of</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37155752">https://news.ycombinator.com/item?id=37155752</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## A charged battery won't bounce but partially discharged one will (2015) [video]
 - [https://www.youtube.com/watch?v=nwfFBUVxpac](https://www.youtube.com/watch?v=nwfFBUVxpac)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T00:25:46+00:00

<p>Article URL: <a href="https://www.youtube.com/watch?v=nwfFBUVxpac">https://www.youtube.com/watch?v=nwfFBUVxpac</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37155657">https://news.ycombinator.com/item?id=37155657</a></p>
<p>Points: 15</p>
<p># Comments: 9</p>

## QR codes appearing in Google street view?
 - [https://nso.group/@haifisch/110901720830132689#.](https://nso.group/@haifisch/110901720830132689#.)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-17T00:12:48+00:00

<p>Article URL: <a href="https://nso.group/@haifisch/110901720830132689#.">https://nso.group/@haifisch/110901720830132689#.</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37155574">https://news.ycombinator.com/item?id=37155574</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

