# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Pakt senacki. Opozycja ogłosiła zawarcie porozumienia
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pakt-senacki-opozycja-oglosila-zawarcie-porozumienia,nId,6968654](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pakt-senacki-opozycja-oglosila-zawarcie-porozumienia,nId,6968654)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-08-17T09:49:50+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pakt-senacki-opozycja-oglosila-zawarcie-porozumienia,nId,6968654"><img align="left" alt="Pakt senacki. Opozycja ogłosiła zawarcie porozumienia" src="https://i.iplsc.com/pakt-senacki-opozycja-oglosila-zawarcie-porozumienia/000FZ899M2IC99HN-C321.jpg" /></a>Liderzy ugrupowań opozycyjnych (Nowa Lewica, KO, PSL, Polska 2050) ogłosili, że ustalili nazwiska kandydatów do wyższej izby parlamentu, którzy wystartują w ramach paktu senackiego. Porozumienie ma zapewnić utrzymanie obecnej większości w Senacie. </p><br clear="all" />

## Traumy ukraińskich żołnierzy. Wstrząsająca relacja z frontu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-traumy-ukrainskich-zolnierzy-wstrzasajaca-relacja-z-frontu,nId,6968568](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-traumy-ukrainskich-zolnierzy-wstrzasajaca-relacja-z-frontu,nId,6968568)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-08-17T08:00:48+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-traumy-ukrainskich-zolnierzy-wstrzasajaca-relacja-z-frontu,nId,6968568"><img align="left" alt="Traumy ukraińskich żołnierzy. Wstrząsająca relacja z frontu" src="https://i.iplsc.com/traumy-ukrainskich-zolnierzy-wstrzasajaca-relacja-z-frontu/000HJO9L976AY05N-C321.jpg" /></a>Wizerunek dzielnych ukraińskich żołnierzy, który utrwalił się w przekazach medialnych po inwazji Rosji na Ukrainę, ma też swoją drugą, ciemniejszą stronę. Wojskowi mówią o traumach, atakach paniki, psychicznym wyczerpaniu i myślach samobójczych, które wniosła w ich życie wojenna codzienność. Żołnierzom brakuje pomocy psychologicznej. </p><br clear="all" />

