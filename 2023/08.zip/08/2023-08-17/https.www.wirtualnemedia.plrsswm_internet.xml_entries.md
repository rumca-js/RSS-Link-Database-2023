# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Na Campus Polska Przyszłości nie chcą Sroczyńskiego, Meller rezygnuje z panelu o symetrystach
 - [https://www.wirtualnemedia.pl/artykul/campus-polska-grzegorz-sroczynski-marcin-meller-symetrysci](https://www.wirtualnemedia.pl/artykul/campus-polska-grzegorz-sroczynski-marcin-meller-symetrysci)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T21:47:45.691600+00:00

Dziennikarz Marcin Meller wycofał się z prowadzenia panelu o symetrystach na zbliżającym się wydarzeniu Campus Polska Przyszłości, organizowanym przez prezydenta Warszawy Rafała Trzaskowskiego. Powodem było wykluczenie z dyskusji, którą Meller miał prowadzić, Grzegorza Sroczyńskiego.

## Wirtualna Polska i Radio ZET ze wspólnym programem „Gra o głosy”, premiera 20 sierpnia
 - [https://www.wirtualnemedia.pl/artykul/gra-o-glosy-radio-zet-wirtualna-polska-beata-lubecka-patrycjusz-wyzga-patryk-michalski-michal-wroblewski](https://www.wirtualnemedia.pl/artykul/gra-o-glosy-radio-zet-wirtualna-polska-beata-lubecka-patrycjusz-wyzga-patryk-michalski-michal-wroblewski)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T18:32:39.649018+00:00

W niedzielę, 20 sierpnia wystartuje wspólny program Wirtualnej Polski i Radia ZET, w ramach którego duet prowadzących będzie gościł polityków reprezentujących partie i komitety wyborcze startujące w nadchodzących wyborach parlamentarnych. Cykl będzie dostępny na stronie głównej WP, w Telewizji WP i Radiu ZET.

## Elon Musk robi rewolucję na X i traci setki milionów dolarów. Ogranicza także ruch nielubianym mediom
 - [https://www.wirtualnemedia.pl/artykul/elon-musk-x-koniec-promowanie-kont-za-pomoca-wiadomosci-tekstowych-ogranicza-ruch-nielubianym-mediom](https://www.wirtualnemedia.pl/artykul/elon-musk-x-koniec-promowanie-kont-za-pomoca-wiadomosci-tekstowych-ogranicza-ruch-nielubianym-mediom)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T12:02:26.620020+00:00

Elon Musk, właściciel serwisu X (dawniej Twitter), zamyka usługę promowania kont za pomocą wiadomości tekstowych. Analitycy oceniają, że straci na tym 100 milionów dolarów rocznie. "Absolutysta wolności słowa", jak sam siebie określa, ograniczył także w serwisie ruch dla linków pochodzących z nielubianych przez siebie witryn. - Taki zabieg wydawał się jedną z tych rzeczy, które są zbyt szalone, aby mogły być prawdziwe, nawet na Twitterze - skomentował Yoel Roth, były szef ds. bezpieczeństwa w Twitterze.

## Rekordowy udział streamingu na ekranie telewizora w lipcu. YouTube przed Netfliksem
 - [https://www.wirtualnemedia.pl/artykul/rekordowy-udzial-streamingu-na-ekranie-telewizora-w-lipcu-youtube-przed-netfliksem](https://www.wirtualnemedia.pl/artykul/rekordowy-udzial-streamingu-na-ekranie-telewizora-w-lipcu-youtube-przed-netfliksem)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T05:32:17.625989+00:00

W lipcu 2023 roku 6,9 proc. udziału w całkowitej oglądalności na ekranie telewizora w Polsce stanowił streaming. Jest to wynik o 0,5 pkt. proc. wyższy niż w czerwcu br. Najchętniej oglądane były treści na YouTube z 1,9 proc. udziału, a drugie miejsce zajął Netflix - 1,7 proc. - wynika z badania Nielsen The Gauge.

## Elon Musk robi rewolucję na X i traci setki milionów dolarów. Ogranicza także ruch nielubianym mediom
 - [https://www.wirtualnemedia.pl/artykul/elon-musk-x-koniec-twitter-promowanie-kont-za-pomoca-wiadomosci-tekstowych-ogranicza-ruch-nielubianym-mediom](https://www.wirtualnemedia.pl/artykul/elon-musk-x-koniec-twitter-promowanie-kont-za-pomoca-wiadomosci-tekstowych-ogranicza-ruch-nielubianym-mediom)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T05:32:17.623361+00:00

Elon Musk, właściciel serwisu X (dawniej Twitter), zamyka usługę promowania kont za pomocą wiadomości tekstowych. Analitycy oceniają, że straci na tym 100 milionów dolarów rocznie. "Absolutysta wolności słowa", jak sam siebie określa, ograniczył także w serwisie ruch dla linków pochodzących z nielubianych przez siebie witryn. - Taki zabieg wydawał się jedną z tych rzeczy, które są zbyt szalone, aby mogły być prawdziwe, nawet na Twitterze - skomentował Yoel Roth, były szef ds. bezpieczeństwa w Twitterze.

## „Rzeczpospolita” najczęściej cytowana. Wirtualnemedia.pl w pierwszej piętnastce mediów w Polsce
 - [https://www.wirtualnemedia.pl/artykul/rzeczpospolita-najczesciej-cytowana-wirtualnemedia-pl-w-pierwszej-pietnastce-mediow-w-polsce](https://www.wirtualnemedia.pl/artykul/rzeczpospolita-najczesciej-cytowana-wirtualnemedia-pl-w-pierwszej-pietnastce-mediow-w-polsce)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-17T05:32:17.618562+00:00

Dziennik „Rzeczpospolita” zajął pierwszą pozycję rankingu najbardziej opiniotwórczych mediów Instytutu Monitorowania Mediów. Na podium znalazły się także TVN24 i Wirtualna Polska. Wirtualnemedia.pl kolejny raz zakwalifikowały się do rankingu TOP15.

