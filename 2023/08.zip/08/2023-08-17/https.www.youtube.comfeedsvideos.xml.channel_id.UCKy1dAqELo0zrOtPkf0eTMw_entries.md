# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## First Baldur's Gate 3 Sex Speeedrun completed #baldursgate3 #gaming #speedrun #pcgamign #shorts
 - [https://www.youtube.com/watch?v=5Jd-S16LOZE](https://www.youtube.com/watch?v=5Jd-S16LOZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T23:03:10+00:00



## She Came to Me - Official Trailer (2023) Peter Dinklage, Marisa Tomei, Anne Hathaway
 - [https://www.youtube.com/watch?v=57c0Y_a2Bq8](https://www.youtube.com/watch?v=57c0Y_a2Bq8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T21:59:51+00:00

Check out the trailer for She Came To Me, an upcoming movie starring Peter Dinklage, Marisa Tomei, Joanna Kulig, Brian d’Arcy James, Anne Hathaway, Harlow Jane, and Evan A. Ellison.

Just weeks before the deadline for his latest commission, composer Steven Lauddem (Peter Dinklage) has lost the creative spark that brought him international acclaim. At the urging of his ever-patient wife Patricia (Anne Hathaway), he searches for inspiration on the Brooklyn waterfront and finds it in Katrina (Marisa Tomei), a thrill-seeking tugboat captain docked in Red Hook, who soon has Steven questioning everything in his life.

Meanwhile, Patricia is experiencing a spiritual crisis of her own that she conceals under a mask of tranquil perfection. As Patricia and Steven wrestle separately with their doubts, their 18-year-old son Julian (Evan Ellison) embarks on a romance with 16-year-old Tereza (Harlow Jane) which threatens to derail both their futures. Also starring Joanna Kulig and Brian d’Arcy James as the girl’s disapproving parents, She Came to Me is a giddy and unforgettable portrayal of the transformational power of love.

The film is produced by Damon Cardasis, Pamela Koffler, Christine Vachon, Rebecca Miller, Len Blavatnik, and Anne Hathaway. It is co-produced by Cindy Tolan and Ged Dickersin. Danny Cohen, Amanda Ghost, and Vince Holden serve as executive producers.

She Came to Me, written and directed by Rebecca Miller, opens in theaters on September 29, 2023.

#IGN #Movies

## IGN voted on the best of Hulu Animayhem shows #familyguy #clevelandshow #animation #shorts
 - [https://www.youtube.com/watch?v=A1gi1DkwY38](https://www.youtube.com/watch?v=A1gi1DkwY38)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T19:56:19+00:00

Presented by Hulu

## Modern Warfare 3 Shadow Siege Reveal Event - FULL Warzone Gameplay
 - [https://www.youtube.com/watch?v=Ff0olPft9mw](https://www.youtube.com/watch?v=Ff0olPft9mw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T19:14:38+00:00

Call of Duty: Modern Warfare 3 was revealed to be launching November 11th 2023 and Warzone 2.0 held an event called Shadow Siege that lasts from August 17th to the 21st. Shadow Siege reveals details on what Modern Warfare 3 will hold and is an entirely separate game mode on Warzone that players can queue into to earn rewards and battle pass tier skips. Here is a full match of Shadow Siege.

#IGN #Gaming

## The biggest video game event in the world #gamescom #gamescom2023 #gaming #ign #shorts
 - [https://www.youtube.com/watch?v=ef5Qq6hGw18](https://www.youtube.com/watch?v=ef5Qq6hGw18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T18:24:53+00:00



## Call of Duty: Modern Warfare 3 - Official Gameplay Reveal Trailer
 - [https://www.youtube.com/watch?v=RtZ8LsbFNIk](https://www.youtube.com/watch?v=RtZ8LsbFNIk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T18:11:20+00:00

Watch the latest trailer for Call of Duty: Modern Warfare III ahead of the game's launch on November 10, 2023. Call of Duty: Modern Warfare III will feature a campaign with new open combat missions, iconic multiplayer maps, and the largest Call of Duty Zombies map.

#IGN #Gaming #CallOfDuty

## Hello Engineer - Official Launch Trailer
 - [https://www.youtube.com/watch?v=5jFJgcN8-L8](https://www.youtube.com/watch?v=5jFJgcN8-L8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T17:23:24+00:00

Hello Engineer is available now on Steam, Xbox, PlayStation, and Nintendo Switch. Watch the launch trailer to see building elements and more from this vehicle construction game. In Hello Engineer, get ready to "engineer" your way to a world of wacky wonders! Craft wild machines from scrap, dream up crazy contraptions, and team up with friends for engineering fun.

## Vampire Survivors - Official Nintendo Switch Launch Trailer
 - [https://www.youtube.com/watch?v=O46fALQpP-k](https://www.youtube.com/watch?v=O46fALQpP-k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T16:10:33+00:00

Vampire Survivors is a gothic horror casual game with rogue-lite elements developed by Poncle. The hit 2D pixel-art game comes packed with all the latest updates, including the 4-player couch co-op update, of the indie mega-hit. The DLCs Legacy of the Moonspell and Tides of the Foscari are also available for purchase. Vampire Survivors is available now for Nintendo Switch.

#VampireSurvivors #NintendoSwitch

## Netflix’s The Monkey King - Exclusive Official Clip (2023) Jimmy O. Yang, Bowen Yang, Stephanie Hsu
 - [https://www.youtube.com/watch?v=X5gC1Wse7Ao](https://www.youtube.com/watch?v=X5gC1Wse7Ao)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T16:00:33+00:00

Inspired by an epic Chinese tale, The Monkey King follows a charismatic Monkey and his magical fighting Stick on an epic quest for victory over 100 demons, an eccentric Dragon King, and Monkey’s greatest foe of all —his own ego! Along the way, a young village girl challenges his self-centered attitude and shows him that even the smallest pebble can have a big effect on the world. The voice cast includes Jimmy O. Yang, Bowen Yang, Jo Koy, Jolie Hoang-Rappaport, and Stephanie Hsu. The Monkey King launches on Netflix on August 18.

#Netflix

## Baldur's Gate 3 and Our Dumbest D&D Moments - Beyond Clips
 - [https://www.youtube.com/watch?v=Hmc5EtwytwU](https://www.youtube.com/watch?v=Hmc5EtwytwU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T16:00:24+00:00

The Podcast Beyond crew just couldn't wait for Baldur's Gate 3 to release on PlayStation 5, so naturally, they've been messing around with the game on PC! What kind of dumb, wacky s*** have they been up to in BG3? Only one way to find out, and it's in this clip from this week's episode.

## F1 23 - Official Braking Point Story Recap Trailer
 - [https://www.youtube.com/watch?v=cfU73wSKszk](https://www.youtube.com/watch?v=cfU73wSKszk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T15:45:02+00:00

Watch the latest trailer for F1 23 to get a recap of the story of Aiden Jackson before he joined the Konnersport Butler Racing Team in F1 23. Braking Point 2 builds on the narrative of the original and introduces the groundbreaking Formula 2 champion Callie Mayer.

F1 23 is available now.

#EAF123 #F123 #BrakingPoint

## EA Sports FC 24 - Official Clubs Deep Dive Trailer
 - [https://www.youtube.com/watch?v=GWLZAdyLP78](https://www.youtube.com/watch?v=GWLZAdyLP78)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T15:35:00+00:00

Get a deep dive into clubs in EA Sports FC 24, including new ways to play like crossplay, a new seasonal format for clubs league, new match intros, playoffs, fans and reputations, pro personalization, and more.

#EASportsFC24 #ClubsDeepDive

## The First Descendant - Official PlayStation 5 Next Gen Immersion Trailer
 - [https://www.youtube.com/watch?v=sd0ShPq9K24](https://www.youtube.com/watch?v=sd0ShPq9K24)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T15:00:43+00:00

The First Descendant is a next-gen, cross-platform, third-person looter shooter developed by NEXON Games. Become a Descendant and fight for the survival of humanity with unique abilities to tackle both solo and co-op missions. The First Descendant takes full advantage of PlayStation 5 with adaptive trigger and haptic feedback support for the DualSense controller along with 3D Audio. The First Descendant is launching soon for PlayStation 4, PlayStation 5, Xbox One, Xbox Series S|X, and PC with an Open Beta running from September 19 through September 25.

#TheFirstDescendant #PS5

## The Lord of the Rings: The Rings of Power - Official Behind the Scenes Orc Time-Lapse (2023)
 - [https://www.youtube.com/watch?v=fAgR40Fj7mg](https://www.youtube.com/watch?v=fAgR40Fj7mg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T14:30:13+00:00

The Lord of the Rings: The Rings of Power took practical effects to the next level in Season 1 by outfitting hundreds of actors in their own individual orc getups. Watch as the masters at Weta Workshop bring the creatures of Middle-earth to life in this orc time lapse.

Rings of Power Season 1 brought J.R.R. Tolkein's world to the small screen in a brand new way and explored the world he created long before Lord Sauron would use the orcs to chase down some hobbits and a certain well-known fellowship. Diving into the never before seen Second Age, the series gives us a glimpse of peace before war would ravage everything from its stunning forests to its deepest mines.

#IGN

## Underdog Defeats Pokémon TCG's Greatest Player to Become World Champion
 - [https://www.youtube.com/watch?v=QdWDB-_zuww](https://www.youtube.com/watch?v=QdWDB-_zuww)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T14:00:15+00:00

IGN's resident Pokemaniac Joshua Yehl interviews the brand new Pokemon TCG World Champion, Vance Kelley, after his big win over the man many consider to be the GOAT, Tord Reklev. Going into the Pokemon TCG finals, Vance Kelley was considered the underdog with his Mew VMAX deck, but he was able to prevail over multi-time champion Tord Reklev and his Gardevoir deck. Vance Kelley tells us how he managed to pull off this huge upset and shares his secret to success.

## Red Dead Redemption - Official Nintendo Switch and PS4 Launch Trailer
 - [https://www.youtube.com/watch?v=IFyc7USUWbY](https://www.youtube.com/watch?v=IFyc7USUWbY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T13:23:35+00:00

Rockstar Games' Western adventure Red Dead Redemption and the zombie-horror add-on Undead Nightmare are available now on Nintendo Switch and PlayStation 4, with backwards compatibility for the PS5. Check out the launch trailer.

#RedDeadRedemption #PS4 #NintendoSwitch

## The Walking Dead: Destinies - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=Z9wFWWZrOhA](https://www.youtube.com/watch?v=Z9wFWWZrOhA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T13:00:34+00:00

Get your first look at The Walking Dead: Destinies, the new choice-driven action-adventure game where you'll have a chance to rewrite the story of The Walking Dead as you know it, reliving the biggest moments from seasons 1-4 of the TV show. Destinies is in development for PC, PlayStation, Xbox, and Nintendo Switch.

## Eon Rush - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=PgSkrx3qZ_8](https://www.youtube.com/watch?v=PgSkrx3qZ_8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T13:00:31+00:00

Enjoy the debut trailer for Eon Rush, a new sci-fi/fantasy cooperative action-RPG from a new game development studio staffed by veterans of Far Cry, Watch Dogs, Pokémon, and more. Players must fight to destroy the Chronophage, a monster that consumes time itself and devours entire realms. Eon Rush is in development for PC.

## Tintin Reporter – Cigars of the Pharaoh Might Be the First Good Tintin Game
 - [https://www.youtube.com/watch?v=NUdPbfHW8rc](https://www.youtube.com/watch?v=NUdPbfHW8rc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T13:00:28+00:00

We got our first hands-on with Tintin Reporter - Cigars of the Pharaoh, and found a charming all-ages puzzle adventure game that looks like it's remaining remarkably faithful to the classic comic that inspired it. Previewed on PC by Travis Northup.

#IGN #Gaming

## Blasphemous 2 Review
 - [https://www.youtube.com/watch?v=mhkESLb1boo](https://www.youtube.com/watch?v=mhkESLb1boo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T12:00:41+00:00

Blasphemous 2 reviewed by Travis Northup on PC. Also available on Xbox Series X/S, PlayStation 5, and Nintendo Switch.

"Blasphemous 2 is an excellent Metroidvania and a marked improvement over the original, even if it did occasionally make me cancel my lunch plans with its grotesqueries. What it lacks in originality with its design it more than makes up for with its bizarre world, appalling story, and inspired look and sound. The new weapons and focus on platforming definitely helped sustain my enjoyment for the campaign’s sizable duration, even when underwhelming enemy variety and unchallenging bosses leave something to be desired. Its stomach-churning religious torture porn might be as far as you can get from the adorable world of Hollow Knight, but you’d be hard-pressed to find something better to play while you continue your interminable wait for Silksong."

## Spider-Verse producers defend multiple versions of film #acrossthespiderverse #spiderman #shorts
 - [https://www.youtube.com/watch?v=WVZMbUoNoG4](https://www.youtube.com/watch?v=WVZMbUoNoG4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:43:59+00:00



## How he got a perfect Smash combo score playing with his foot #supersmash #smashbros #gaming #shorts
 - [https://www.youtube.com/watch?v=Q8HzEwM3bNo](https://www.youtube.com/watch?v=Q8HzEwM3bNo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:42:49+00:00



## Scott Pilgrim Anime vs Movie #scottpilgrim #anime #netflix #shorts
 - [https://www.youtube.com/watch?v=ptdkU69d4vQ](https://www.youtube.com/watch?v=ptdkU69d4vQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:42:08+00:00



## What's inside the Baldur's Gate 3 Collector's Edition #baldursgate3 #unboxing #gaming #shorts
 - [https://www.youtube.com/watch?v=mavbJ_pQJMw](https://www.youtube.com/watch?v=mavbJ_pQJMw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:41:24+00:00



## Baldur's Gate 3's most overlooked ability #baldursgate3 #gaming #shorts
 - [https://www.youtube.com/watch?v=_M8W0Dwn9PI](https://www.youtube.com/watch?v=_M8W0Dwn9PI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:40:14+00:00



## How to do the highest damage move in Baldur's Gate 3 #baldursgate3 #gaming #shorts
 - [https://www.youtube.com/watch?v=jzHa9MLJORY](https://www.youtube.com/watch?v=jzHa9MLJORY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T05:39:27+00:00



## Starfield Preload Times Confirmed - IGN Daily Fix
 - [https://www.youtube.com/watch?v=ZHbCgjxb8vg](https://www.youtube.com/watch?v=ZHbCgjxb8vg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T00:43:34+00:00

In today's Daily Fix:
Hard to believe, but Starfield's release is almost here. Bethesda is helping gamers get ready by allowing preloads to begin tomorrow. If you preordered or have a Game Pass sub, you can start downloading now so you don't have to wait on launch day. In Call of Duty news, zombies are back! Although not 100% officially announced, a CoD Youtuber found some very compelling evidence via the recent teaser trailer. And fun fact: the upcoming Modern Warfare 3 will be the first Modern Warfare game to get a zombies mode. What are you most excited to play this fall? Starfield or Modern Warfare 3 with zombies? Let us know in the comments

## New Details on Rick and Morty Season 7 - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=kiLof2QW4nU](https://www.youtube.com/watch?v=kiLof2QW4nU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-17T00:10:24+00:00

We’ve got our first teaser trailer for the upcoming Rick and Morty season 7. There’s no release date just yet, but expect to see the multiverse-traveling duo return sometime in the fall. Roiland voiced many characters from #RickandMorty on #adultswim, including the titular heroes. Roiland was let go by Adult Swim earlier this year after domestic abuse charges were levied against him. He’s since been cleared of all charges, and released this statement on Twitter following the dismissal of the domestic abuse charges. At this year’s Comic-Con, producer Steve Levy gave fans an update on where the team’s at with recasting the characters voiced by Justin Roiland. "We are closing in on the end of our process of the recast. It’s going to be great… I’m thoroughly impressed… That’s the thing I don’t want to be overshadowed." We also fill you in on what to expect from Netflix’s Scott Pilgrim anime series. All this and more in today’s fix with Akeem Lawanson!

#IGN

