# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Jonathan Van-Tam joins Covid vaccine maker Moderna
 - [https://www.telegraph.co.uk/business/2023/08/17/jonathan-van-tam-joins-covid-vaccine-maker-moderna/](https://www.telegraph.co.uk/business/2023/08/17/jonathan-van-tam-joins-covid-vaccine-maker-moderna/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T22:37:54+00:00



## Tourist tax is hurting our casinos, says Grosvenor chief
 - [https://www.telegraph.co.uk/business/2023/08/17/rishi-sunak-tourist-tax-blamed-sales-grosvenor-casino/](https://www.telegraph.co.uk/business/2023/08/17/rishi-sunak-tourist-tax-blamed-sales-grosvenor-casino/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T17:49:57+00:00



## Americans will run out of pandemic savings next month, Fed warns
 - [https://www.telegraph.co.uk/business/2023/08/17/americans-run-out-pandemic-savings-next-month-fed-warns/](https://www.telegraph.co.uk/business/2023/08/17/americans-run-out-pandemic-savings-next-month-fed-warns/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T17:20:45+00:00



## China downturn drags smartphone sales to their lowest level in a decade
 - [https://www.telegraph.co.uk/business/2023/08/17/china-downturn-drags-smartphone-sales-to-their-lowest-level/](https://www.telegraph.co.uk/business/2023/08/17/china-downturn-drags-smartphone-sales-to-their-lowest-level/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T10:09:25+00:00



## Train strikes 2023: Walkout dates and the services affected
 - [https://www.telegraph.co.uk/business/2023/08/17/train-strikes-overtime-ban-2023-dates-rail-services-affected/](https://www.telegraph.co.uk/business/2023/08/17/train-strikes-overtime-ban-2023-dates-rail-services-affected/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T07:00:06+00:00



## China property fears drive Asian stocks to nine-month low
 - [https://www.telegraph.co.uk/business/2023/08/17/ftse-100-markets-news-china-property-uk-economy-pound/](https://www.telegraph.co.uk/business/2023/08/17/ftse-100-markets-news-china-property-uk-economy-pound/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T06:27:04+00:00



## ChatGPT is ‘systemically left-wing biased’
 - [https://www.telegraph.co.uk/business/2023/08/17/openai-chatgpt-left-wing-bias-labour-party-democrats/](https://www.telegraph.co.uk/business/2023/08/17/openai-chatgpt-left-wing-bias-labour-party-democrats/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-08-17T05:00:00+00:00



