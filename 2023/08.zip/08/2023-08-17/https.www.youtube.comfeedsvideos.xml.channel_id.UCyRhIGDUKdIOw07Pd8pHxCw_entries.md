# Source:Shut Up & Sit Down, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyRhIGDUKdIOw07Pd8pHxCw, language:en-US

## Golem is an Alright Game
 - [https://www.youtube.com/watch?v=xJApU3RRNhs](https://www.youtube.com/watch?v=xJApU3RRNhs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyRhIGDUKdIOw07Pd8pHxCw
 - date published: 2023-08-17T18:34:05+00:00

Support the Show: https://bit.ly/SupportSUSD / https://www.patreon.com/shutupandsitdown
Buy Golem: https://tinyurl.com/SUSDGolem In US: https://tinyurl.com/US-Golem
In UK & Europe: https://tinyurl.com/UKGolem
Visit SU&amp;SD for more cardboard antics: http://www.shutupandsitdown.com/

~FOLLOW US AROUND, WHY DON'T YOU~
Twitter: https://www.twitter.com/shutupshow
Instagram: https://www.instagram.com/shut.up.and.sit.down
Twitch: https://www.twitch.tv/shutupandsitdown
TikTok: https://www.tiktok.com/@shutupshow

