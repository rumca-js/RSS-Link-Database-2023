# Source:ABC News, URL:http://feeds.abcnews.com/abcnews/topstories, language:en-US

## Los Angeles launching task force to address organized retail crime
 - [https://abcnews.go.com/US/los-angeles-task-force-organized-retail-crime/story?id=102354884](https://abcnews.go.com/US/los-angeles-task-force-organized-retail-crime/story?id=102354884)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T23:03:53+00:00

Los Angeles is launching a new task force to address organized retail crime in the region, officials announced Thursday.

## Suspect in New Jersey councilwoman's slaying indicted on murder, weapons charges
 - [https://abcnews.go.com/US/wireStory/suspect-new-jersey-councilwomans-slaying-indicted-murder-weapons-102353941](https://abcnews.go.com/US/wireStory/suspect-new-jersey-councilwomans-slaying-indicted-murder-weapons-102353941)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T20:42:34+00:00

A church associate charged with gunning down a New Jersey councilwoman has been indicted on murder and weapons charges

## Grand jurors in Trump Georgia case face threats as identities shared online: Sheriff
 - [https://abcnews.go.com/US/fulton-county-authorities-aware-identities-trump-grand-jurors/story?id=102352837](https://abcnews.go.com/US/fulton-county-authorities-aware-identities-trump-grand-jurors/story?id=102352837)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T20:07:46+00:00

Fulton County grand jurors that voted to indict former President Trump on Monday are facing threats after their personal information was shared online, authorities say.

## 2 Florida men sentenced to federal prison for participating in US Capitol riot
 - [https://abcnews.go.com/Politics/wireStory/2-florida-men-sentenced-federal-prison-participating-us-102353698](https://abcnews.go.com/Politics/wireStory/2-florida-men-sentenced-federal-prison-participating-us-102353698)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T20:05:50+00:00

Two Florida men have been sentenced on felony charges related to storming the U.S. Capitol during the January 2021 insurrection

## Iran arrests women's rights activists ahead of 'Woman, Life, Freedom' anniversary
 - [https://abcnews.go.com/International/iran-arrests-womens-rights-activists-ahead-woman-life/story?id=102334170](https://abcnews.go.com/International/iran-arrests-womens-rights-activists-ahead-woman-life/story?id=102334170)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T20:02:00+00:00

Iranian officials say 2 women's rights activists were arrested by security forces in the northern Iranian province of Gilan Wednesday.

## Ex-wife of slain Microsoft exec charged with his murder
 - [https://abcnews.go.com/US/wife-slain-microsoft-exec-jared-bridegan-charged-murder/story?id=102348013](https://abcnews.go.com/US/wife-slain-microsoft-exec-jared-bridegan-charged-murder/story?id=102348013)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T18:52:13+00:00

The ex-wife of slain Microsoft executive Jared Bridegan has been indicted for first-degree murder in what prosecutors called a "cold, calculated" murder.

## Pilots made errors before crash near Lake Tahoe that killed all 6 on board, investigators say
 - [https://abcnews.go.com/Business/wireStory/pilots-made-errors-crash-lake-tahoe-killed-6-102349826](https://abcnews.go.com/Business/wireStory/pilots-made-errors-crash-lake-tahoe-killed-6-102349826)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T18:37:17+00:00

Investigators are blaming pilot error for the 2021 crash of a private jet in California that killed all six people on board

## Ukraine taking heavy casualties in its counteroffensive, soldiers say
 - [https://abcnews.go.com/International/ukraine-taking-heavy-casualties-counteroffensive-soldiers/story?id=102347740](https://abcnews.go.com/International/ukraine-taking-heavy-casualties-counteroffensive-soldiers/story?id=102347740)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T18:34:43+00:00

There is mounting evidence that Ukraine has been taking heavy casualties in its counteroffensive, which began roughly ten weeks ago.

## Mortgage rates surge to 21-year high
 - [https://abcnews.go.com/Business/mortgage-rates-surge-21-year-high/story?id=102348330](https://abcnews.go.com/Business/mortgage-rates-surge-21-year-high/story?id=102348330)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T18:34:24+00:00

The 30-year fixed-rate mortgage averaged 7.09% over the week ending on Thursday, Freddie Mac data shows.

## Woman sentenced to nearly 22 years for 2020 ricin letter sent to Trump in White House
 - [https://abcnews.go.com/US/wireStory/canadian-woman-sentenced-22-years-2020-ricin-letter-102348326](https://abcnews.go.com/US/wireStory/canadian-woman-sentenced-22-years-2020-ricin-letter-102348326)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T18:16:48+00:00

A Canadian woman has been sentenced to nearly 22 years in prison for mailing a threatening letter containing the poison ricin to then-President Donald Trump at the White House

## WATCH:  Climber scales wall in impressive 'no-hands' challenge
 - [https://abcnews.go.com/Lifestyle/video/climber-scales-wall-impressive-hands-challenge-102348533](https://abcnews.go.com/Lifestyle/video/climber-scales-wall-impressive-hands-challenge-102348533)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T17:57:07+00:00

As if getting up this wall wasn't already going to be tough enough, this guy smashed a climbing challenge set by his bouldering gym by scaling it with his hands behind his back.

## Kansas City Superfan 'ChiefsAholic' charged with stealing almost $700,000 in bank heists
 - [https://abcnews.go.com/Sports/wireStory/kansas-city-superfan-chiefsaholic-charged-stealing-700000-bank-102346720](https://abcnews.go.com/Sports/wireStory/kansas-city-superfan-chiefsaholic-charged-stealing-700000-bank-102346720)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T17:33:32+00:00

A Kansas City Chiefs superfan known as &ldquo;ChiefsAholic&rdquo; and familiar for attending games dressed as a wolf in the NFL team&rsquo;s gear has been indicted by a federal grand jury that accuses him of armed robbery and money laundering in a string of bank heists ...

## NYC bans use of TikTok on city-owned phones, joining federal government, majority of states
 - [https://abcnews.go.com/Technology/wireStory/nyc-bans-tiktok-city-owned-phones-joining-federal-102346538](https://abcnews.go.com/Technology/wireStory/nyc-bans-tiktok-city-owned-phones-joining-federal-102346538)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T17:31:54+00:00

New York City has directed its employees to delete TikTok from their city-issued phones

## Maui official explains why sirens were not sounded during wildfires
 - [https://abcnews.go.com/US/maui-official-defends-sirens-deadly-wildfires/story?id=102344576](https://abcnews.go.com/US/maui-official-defends-sirens-deadly-wildfires/story?id=102344576)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T17:31:30+00:00

Maui Emergency Management Agency Administrator Herman Andaya said the protocol is to use the coastal sirens only during tsunami warnings, and not during wildfires.

## Average long-term US mortgage rate climbs to 7.09% this week to highest level in more than 20 years
 - [https://abcnews.go.com/Business/wireStory/average-long-term-us-mortgage-rate-hits-highest-102345726](https://abcnews.go.com/Business/wireStory/average-long-term-us-mortgage-rate-hits-highest-102345726)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T16:49:49+00:00

The average long-term U.S. mortgage rate jumped this week to its highest level in 20 years, grim news for would-be homebuyers already facing high home prices caused a lack of supply

## US sanctions 4 Russians allegedly involved in poisoning of Alexey Navalny
 - [https://abcnews.go.com/Politics/us-sanctions-4-russians-allegedly-involved-poisoning-alexey/story?id=102342806](https://abcnews.go.com/Politics/us-sanctions-4-russians-allegedly-involved-poisoning-alexey/story?id=102342806)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T16:38:06+00:00

The U.S. on Thursday sanctioned four Russians they say were involved in the 2020 poisoning of Alexey Navalny, the country's most well-known opposition leader.

## Twila Kilgore tapped as interim coach for U.S. women's national soccer team
 - [https://abcnews.go.com/Sports/wireStory/twila-kilgore-tapped-interim-coach-us-womens-national-102343246](https://abcnews.go.com/Sports/wireStory/twila-kilgore-tapped-interim-coach-us-womens-national-102343246)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T16:13:32+00:00

The move follows the resignation of coach Vlatko Andonovski

## Judge declares mistrial in trial of 2 men charged with shooting at FedEx driver
 - [https://abcnews.go.com/US/judge-declares-mistrial-trial-2-men-charged-shooting/story?id=102309013](https://abcnews.go.com/US/judge-declares-mistrial-trial-2-men-charged-shooting/story?id=102309013)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T15:25:51+00:00

A judge declared a mistrial in the case of a father and son charged with attempted murder for shooting at a Black FedEx driver in Brookhaven, Mississippi.

## North Korea preparing for new round of weapons tests, South Korean spy agency says
 - [https://abcnews.go.com/International/wireStory/south-koreas-spy-agency-north-korea-preparing-icbm-102334523](https://abcnews.go.com/International/wireStory/south-koreas-spy-agency-north-korea-preparing-icbm-102334523)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T15:20:00+00:00

South Korea&rsquo;s spy service has told lawmakers that North Korea is preparing for a new round of provocative weapons tests as it ramps up illicit activities to support its fragile economy

## Israel clinches largest-ever defense deal with Germany for $3.5 billion after securing US approval
 - [https://abcnews.go.com/Business/wireStory/israel-clinches-largest-defense-deal-germany-35-billion-102342723](https://abcnews.go.com/Business/wireStory/israel-clinches-largest-defense-deal-germany-35-billion-102342723)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T15:02:41+00:00

Israel&rsquo;s Defense Ministry says it has secured its largest-ever defense deal selling a sophisticated missile defense system to Germany for $3.5 billion

## New Jersey shutters 27 Boston Market restaurants over unpaid wages, related worker issues
 - [https://abcnews.go.com/Business/wireStory/new-jersey-shutters-27-boston-market-restaurants-unpaid-102340776](https://abcnews.go.com/Business/wireStory/new-jersey-shutters-27-boston-market-restaurants-unpaid-102340776)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T14:31:18+00:00

State labor officials have temporarily shut down more than two dozen Boston Market restaurants in New Jersey

## Over 1.5 million dehumidifiers are under recall after fire reports
 - [https://abcnews.go.com/Business/wireStory/15-million-dehumidifiers-recall-after-fire-reports-102340475](https://abcnews.go.com/Business/wireStory/15-million-dehumidifiers-recall-after-fire-reports-102340475)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T14:14:33+00:00

More than 1.5 million dehumidifiers are under recall following reports of nearly two dozen fires, the U.S. Consumer Product Safety Commission said Wednesday

## U.S. jobless claims applications fall as labor market continues to show resiliency
 - [https://abcnews.go.com/Business/wireStory/us-jobless-claims-applications-fall-labor-market-continues-102338810](https://abcnews.go.com/Business/wireStory/us-jobless-claims-applications-fall-labor-market-continues-102338810)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T13:26:25+00:00

The U.S. labor market continues to flex its muscle, as applications for jobless claims fell again last week and remain at healthy levels despite high interest rates and elevated inflation

## China: Welcome visit by US commerce secretary after imposition of investment controls
 - [https://abcnews.go.com/US/wireStory/china-visit-us-commerce-secretary-after-imposition-investment-102335298](https://abcnews.go.com/US/wireStory/china-visit-us-commerce-secretary-after-imposition-investment-102335298)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T12:39:08+00:00

China says it would welcome a visit by U.S. Commerce Secretary Gina Raimondo following the imposition of foreign investment controls by her agency that have stung numerous Chinese companies

## Majority of Americans think Trump's Ga. election interference case is serious: POLL
 - [https://abcnews.go.com/Politics/majority-americans-trumps-charges-ga-election-interference-case/story?id=102328543](https://abcnews.go.com/Politics/majority-americans-trumps-charges-ga-election-interference-case/story?id=102328543)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T11:10:50+00:00

A majority (63%) of Americans say Trump's charges approved by a grand jury in Georgia are serious (47%) or somewhat serious (16%), according to a new ABC News/Ipsos poll

## China's Xi calls for patience as Communist Party tries to reverse economic slump
 - [https://abcnews.go.com/International/wireStory/chinas-xi-calls-patience-communist-party-reverse-economic-102333857](https://abcnews.go.com/International/wireStory/chinas-xi-calls-patience-communist-party-reverse-economic-102333857)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T08:14:35+00:00

Chinese leader Xi Jinping has called for patience in a speech released as the ruling Communist Party tries to reverse a deepening economic slump and said the West&rsquo;s pursuit of material wealth led to &ldquo;spiritual poverty.&rdquo;

## 63 presumed dead after boat carrying migrants sinks off the coast of Senegal
 - [https://abcnews.go.com/US/63-presumed-dead-after-boat-carrying-migrants-sinks/story?id=102323246](https://abcnews.go.com/US/63-presumed-dead-after-boat-carrying-migrants-sinks/story?id=102323246)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T07:37:35+00:00

Sixty-three people are presumed dead after a boat carrying about 100 people from Senegal sank near Cabo Verde.

## Texas woman arrested for alleged death threats to DC judge in Trump case
 - [https://abcnews.go.com/US/texas-woman-arrested-alleged-death-threats-dc-judge/story?id=102329019](https://abcnews.go.com/US/texas-woman-arrested-alleged-death-threats-dc-judge/story?id=102329019)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T03:22:17+00:00

A Texas woman was arrested last week for allegedly threatening to kill the judge assigned to oversee former President Trump's 2020 election interference case.

## 1st reported Maui fire may have been caused by damaged power lines: Report
 - [https://abcnews.go.com/US/1st-reported-maui-fire-caused-damaged-power-lines/story?id=102326367](https://abcnews.go.com/US/1st-reported-maui-fire-caused-damaged-power-lines/story?id=102326367)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T02:17:41+00:00

A power monitoring company released a report that may show a correlation between a power outage and one of the Maui wildfires.

## US women’s national team coach resigns after early World Cup exit, AP source says
 - [https://abcnews.go.com/US/wireStory/us-womens-national-team-coach-vlatko-andonovski-resigns-102329437](https://abcnews.go.com/US/wireStory/us-womens-national-team-coach-vlatko-andonovski-resigns-102329437)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T02:16:56+00:00

U.S. women&rsquo;s national team coach Vlatko Andonovski has resigned, a person familiar with the decision told The Associated Press on Wednesday

## Cost of security prompted by Idaho college killings tops $1.2M for university
 - [https://abcnews.go.com/US/cost-security-prompted-idaho-college-killings-tops-12m/story?id=102324219](https://abcnews.go.com/US/cost-security-prompted-idaho-college-killings-tops-12m/story?id=102324219)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T02:13:25+00:00

The cost of Idaho college killings tops $1.2 million for the University of Idaho.

## Lake Mead sees 'significant improvement' in water levels
 - [https://abcnews.go.com/US/lake-mead-significant-improvement-water-levels/story?id=102323139](https://abcnews.go.com/US/lake-mead-significant-improvement-water-levels/story?id=102323139)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T01:38:20+00:00

Investments to enhance system conservation has led to "significant improvements" for Lake Mead this year, despite the reservoir being at historic lows.

## Starbucks ordered to pay extra $2.7M to woman who said she was fired for being white
 - [https://abcnews.go.com/US/starbucks-ordered-pay-extra-27m-employee-fired-white/story?id=102327372](https://abcnews.go.com/US/starbucks-ordered-pay-extra-27m-employee-fired-white/story?id=102327372)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-08-17T00:08:05+00:00

A New Jersey federal judge has ordered Starbucks to pay a former employee who was awarded $25.6 million in a wrongful termination suit an extra $2.7 million in damages.

