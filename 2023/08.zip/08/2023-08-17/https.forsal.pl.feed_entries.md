# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Reuters: Kolejny Amerykanin aresztowany w Moskwie za szpiegostwo
 - [https://forsal.pl/swiat/rosja/artykuly/9277668,reuters-kolejny-amerykanin-aresztowany-w-moskwie-za-szpiegostwo.html](https://forsal.pl/swiat/rosja/artykuly/9277668,reuters-kolejny-amerykanin-aresztowany-w-moskwie-za-szpiegostwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T19:50:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CMUktkuTURBXy9lMDUwYmU4NS04Y2QzLTQ0YjAtOTExNS02ZTJmYmE3ZWFkNDYuanBlZ5GTBc0BHcyg" />Sąd w Moskwie nakazał umieszczenie w areszcie obywatela USA urodzonego w ZSRR Gene'a Spectora z powodu podejrzeń o szpiegostwo - podała w czwartek agencja Reutera. Mężczyzna był już wcześniej skazany w Rosji w związku ze sprawą korupcyjną.

## Korytarz humanitarny na Morzu Czarnym: Turcja przestrzegła Rosję przed kolejnym ostrzałem statków cywilnych
 - [https://forsal.pl/swiat/rosja/artykuly/9277654,korytarz-humanitarny-na-morzu-czarnym-turcja-przestrzegla-rosje-przed.html](https://forsal.pl/swiat/rosja/artykuly/9277654,korytarz-humanitarny-na-morzu-czarnym-turcja-przestrzegla-rosje-przed.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T19:22:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CifktkuTURBXy9lN2U5MDY0MC1kY2I4LTRlYmQtOTRlNy1kMzc1Yjc0MWM1ODEuanBlZ5GTBc0BHcyg" />Turcja &quot;ostrzegła&quot; Rosję po tym, gdy w niedzielę jej okręt oddał strzały ostrzegawcze w kierunku statku handlowego na Morzu Czarnym i zapowiedziała, że taki incydenty mogą zwiększyć napięcie na tym akwenie - poinformowała w czwartek kancelaria tureckiego prezydenta Recepa Tayyipa Erdogana.

## Fala upałów nad Francją zagraża funkcjonowaniu państwa. Elektrownie jądrowe mogą ograniczyć produkcję
 - [https://forsal.pl/biznes/energetyka/artykuly/9277578,fala-upalow-nad-francja-zagraza-funkcjonowaniu-panstwa-elektrownie-ja.html](https://forsal.pl/biznes/energetyka/artykuly/9277578,fala-upalow-nad-francja-zagraza-funkcjonowaniu-panstwa-elektrownie-ja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T18:35:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K8TktkuTURBXy81NjQxZTUzOC1lY2U3LTRjODMtYWNlYS02MDNiZTI5MDBjMGMuanBlZ5GTBc0BHcyg" />Premier Francji Elisabeth Borne powołała w czwartek międzyresortową jednostkę kryzysową, która ma zająć się łagodzeniem skutków nadchodzącej fali upałów w części kraju – poinformowały francuskie media. Z powodu wysokich temperatur niektóre elektrownie jądrowe mogą ograniczyć produkcję.

## Niemcy tracą zaufanie do demokracji i do partii politycznych [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9277503,niemcy-traca-zaufanie-do-demokracji-i-do-partii-politycznych-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9277503,niemcy-traca-zaufanie-do-demokracji-i-do-partii-politycznych-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T18:12:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2cgktkuTURBXy85ZGYzOWZiYi1hOGFiLTQzYTktYTUxNi1jM2M2YTJhNmQ3NjQuanBlZ5GTBc0BHcyg" />Zaufanie obywateli Niemiec do demokracji gwałtownie spada. Podczas gdy jesienią 2021 roku nieco mniej niż jedna trzecia ankietowanych stwierdziła, że ma mniejsze lub niewielkie zaufanie do niemieckiej demokracji, tego lata już 54 proc. zgodziło się z tym stwierdzeniem - wynika z sondażu zleconego przez Fundację Koerbera. Utrata zaufania do partii jest jeszcze bardziej dramatyczna.

## Węgry: Orban i jego rząd mimo negatywnej retoryki otwiera szeroko drzwi dla imigrantów zarobkowych
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9277492,wegry-orban-i-jego-rzad-mimo-negatywnej-retoryki-otwiera-szeroko-drzw.html](https://forsal.pl/swiat/unia-europejska/artykuly/9277492,wegry-orban-i-jego-rzad-mimo-negatywnej-retoryki-otwiera-szeroko-drzw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T17:42:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/i_gktkuTURBXy81ZTQxZWYyMC1iMjE0LTQ2ZDUtOGVhNS02NjQzMWUxMjUxMTEuanBlZ5GTBc0BHcyg" />Pomimo retoryki wymierzonej w imigrantów rząd Węgier wprowadza szereg środków, aby szeroko otworzyć drzwi dla gastarbeiterów – napisał w czwartek dziennik „Nepszava”. Według mediów węgierska gospodarka będzie potrzebować ok. 200-300 tys. pracowników zagranicznych.

## Czesi zakończyli negocjacje w sprawie zakupu samolotów F-35. Amerykańskie myśliwce zastąpią szwedzkie Gripeny
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277486,czesi-zakonczyli-negocjacje-w-sprawie-zakupu-samolotow-f-35-amerykans.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277486,czesi-zakonczyli-negocjacje-w-sprawie-zakupu-samolotow-f-35-amerykans.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T17:13:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GVnktkuTURBXy9mOThiM2FkOS02YjJhLTQ1YTktOTkyZC1mNTlmMjg2ZmE0YmMuanBlZ5GTBc0BHcyg" />Czeska minister obrony Jana Czernochova powiedziała w czwartek, że finalizowane są rozmowy o zakupie 24 amerykańskich samolotów F-35. W ciągu kilku tygodni szefowa resortu ma poinformować rząd o rezultatach negocjacji. Kontrakt ma być realizowany przez dziesięć lat.

## Coraz więcej zakażonych koronawirusem w Niemczech. Eksperci łączą to zjawisko z dwoma kinowymi hitami
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9277481,coraz-wiecej-zakazonych-koronawirusem-w-niemczech-eksperci-lacza-to-z.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9277481,coraz-wiecej-zakazonych-koronawirusem-w-niemczech-eksperci-lacza-to-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T17:05:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NfUktkuTURBXy8zZmIwN2YxNy0yYTMxLTRmNGYtYjVlZC04YTIyODFjNjAyOWEuanBlZ5GTBc0BHcyg" />Pandemia się skończyła, ale koronawirus pozostał i w kilku krajach związkowych RFN wzrosła liczba przypadków Covid-19. Eksperci podejrzewają, że to tzw. efekt Barbenheimera – popularne ostatnio w kinach łączone seanse filmów „Barbie” i „Oppenheimer” – pisze portal tygodnika „Spiegel”.

## Mohamad bin Salman prawdopodobnie odwiedzi Wielką Brytanię. Wizyta saudyjskiego księcia odbędzie się w październiku
 - [https://forsal.pl/swiat/brexit/artykuly/9277475,mohamad-bin-salman-prawdopodobnie-odwiedzi-wielka-brytanie-wizyta-sau.html](https://forsal.pl/swiat/brexit/artykuly/9277475,mohamad-bin-salman-prawdopodobnie-odwiedzi-wielka-brytanie-wizyta-sau.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T16:51:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tiaktkuTURBXy83YzFmNmVkMS0xMzNiLTQ0YzktYjRkZS01MGIwOGE0YzE3ODEuanBlZ5GTBc0BHcyg" />Następca tronu Arabii Saudyjskiej i faktyczny władca tego państwa książę Mohammed bin Salman został zaproszony przez premiera Rishiego Sunaka do złożenia pierwszej od 2018 roku wizyty w Wielkiej Brytanii - podały w czwartek brytyjskie media.

## Ceny materiałów budowlanych ustabilizują się do końca roku [RAPORT]
 - [https://forsal.pl/biznes/handel/artykuly/9277459,ceny-materialow-budowlanych-ustabilizuja-sie-do-konca-roku-raport.html](https://forsal.pl/biznes/handel/artykuly/9277459,ceny-materialow-budowlanych-ustabilizuja-sie-do-konca-roku-raport.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T16:38:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qgDktkuTURBXy9lYmRkYjQ2Ny1jOTE0LTRiNGEtOTk4NC01YjkwYTU5MGEzYWMuanBlZ5GTBc0BHcyg" />Do końca roku można oczekiwać stabilizacji cen materiałów budowlanych, niewykluczone są też niewielkie obniżki. W przyszłym roku trudno jednak będzie uniknąć wzrostu popytu i cen - wynika z raportu serwisu RynekPierwotny.pl.

## Państwa ECOWAS są gotowe do interwencji w Nigrze. Trwa spotkanie dowódców armii bloku w Ghanie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277450,panstwa-ecowas-sa-gotowe-do-interwencji-w-nigrze-trwa-spotkanie-dowod.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277450,panstwa-ecowas-sa-gotowe-do-interwencji-w-nigrze-trwa-spotkanie-dowod.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T16:02:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3dyktkuTURBXy83N2JhODg3NC05ODgzLTQ2MzktYTEwOS1jNDc0ZjFmMTg5OTUuanBlZ5GTBc0BHcyg" />Państwa należące do bloku ECOWAS (Wspólnoty Gospodarczej Państw Afryki Zachodniej) są gotowe do udziału w siłach rezerwowych, które mogłyby interweniować w Nigrze, &quot;jeżeli zawiodą inne środki&quot; - oświadczył w czwartek komisarz ECOWAS Abdel-Fatau Musah.

## Jedzenie mięsa: za i przeciw
 - [https://forsal.pl/biznes/ekologia/artykuly/9277443,jedzenie-miesa-za-i-przeciw.html](https://forsal.pl/biznes/ekologia/artykuly/9277443,jedzenie-miesa-za-i-przeciw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T15:54:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uAAktkuTURBXy9lMmRjYTllYy1mNTZmLTQ1M2ItOGZhNy03NmY5ZDY5Y2U0YzYuanBlZ5GTBc0BHcyg" />Od zarania dziejów człowiek spożywał mięso. To źródło białka było nieodłączną częścią ludzkiej diety przez tysiące lat. Współczesne społeczeństwo stoi jednak przed wyborem: kontynuować tradycję, czy zrewidować swoje nawyki żywieniowe w świetle współczesnych problemów? Istnieją ważne argumenty za i przeciw jedzeniu mięsa, ale przewaga korzyści płynących z rezygnacji staje się coraz bardziej oczywista.

## Trwają przygotowania Air Show w Radomiu. Gen. Kukuła: Wszystkie rodzaje SZ będą obecne na imprezie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277441,trwaja-przygotowania-air-show-w-radomiu-gen-kukula-wszystkie-rodzaj.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277441,trwaja-przygotowania-air-show-w-radomiu-gen-kukula-wszystkie-rodzaj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T15:52:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2fPktkuTURBXy9iNTA5N2YyZS01ODU3LTRmZjQtOTBiYS0yZDVjZTFiZWRlOTAuanBlZ5GTBc0BHcyg" />Wszystkie rodzaje Sił Zbrojnych zaangażowane są w Air Show - powiedział w czwartek w Dęblinie dowódca generalny Rodzajów SZ gen. broni Wiesław Kukuła. Międzynarodowe pokazy lotnicze z udziałem ok. 150 maszyn odbędą się 26-27 sierpnia w Radomiu.

## Polki chcą rodzić dzieci. Gdzie? W Wielkiej Brytanii
 - [https://forsal.pl/gospodarka/demografia/artykuly/9277437,polki-chca-rodzic-dzieci-gdzie-w-wielkiej-brytanii.html](https://forsal.pl/gospodarka/demografia/artykuly/9277437,polki-chca-rodzic-dzieci-gdzie-w-wielkiej-brytanii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T15:37:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OPdktkuTURBXy9kYjhhNDU0Zi1lM2Y1LTQwZjUtYmYzZS02NWQwNzUwYTQxZTcuanBlZ5GTBc0BHcyg" />30,3 proc. dzieci, które przyszły na świat w Anglii i Walii w ubiegłym roku, zostało urodzone przez matki pochodzące spoza Wielkiej Brytanii, co jest najwyższym odsetkiem w historii - podał w czwartek urząd statystyczny ONS. Polki są na czwartym miejscu, jeśli chodzi o kraj pochodzenia zagranicznych matek.

## Szwecja uniknęła planowanych ataków terrorystycznych. Premier Kristersson nie podał żadnych szczegółów
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9277434,szwecja-uniknela-planowanych-atakow-terrorystycznych-premier-kristers.html](https://forsal.pl/swiat/unia-europejska/artykuly/9277434,szwecja-uniknela-planowanych-atakow-terrorystycznych-premier-kristers.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T15:23:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7NKktkuTURBXy85YTQ1ZmI3OS1jOTU2LTQ3MTctOGVmNS0wNWE0ZWQ2ZjI0MDEuanBlZ5GTBc0BHcyg" />Premier Szwecji Ulf Kristersson poinformował w czwartek, że udało się zapobiec planowanym atakom terrorystycznym w kraju. Nasze władze, w szczególności służby specjalne oraz policja ciężko pracują, aby zagwarantować Szwecji bezpieczeństwo - oświadczył szef rządu.

## ChatGPT ma własny światopogląd? Jeśli tak, to znacząco i systemowo faworyzuje lewicowe poglądy [BADANIE]
 - [https://forsal.pl/lifestyle/technologie/artykuly/9277420,chatgpt-ma-wlasny-swiatopoglad-jesli-tak-to-znaczaco-i-systemowo-faw.html](https://forsal.pl/lifestyle/technologie/artykuly/9277420,chatgpt-ma-wlasny-swiatopoglad-jesli-tak-to-znaczaco-i-systemowo-faw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T15:00:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qgQktkuTURBXy9iYzliN2Q4Ny03MjhlLTQzNmQtYTkzMC01NjE4NmFkZGUwYzcuanBlZ5GTBc0BHcyg" />ChatGPT, popularny chatbot oparty na sztucznej inteligencji (AI), w sposób znaczący i systemowy faworyzuje lewicowe poglądy, co może wpływać na rezultaty wyborów - stwierdzili naukowcy z University of East Anglia.

## Najdłuższy konflikt współczesnej Europy: Czy liderzy Turcji i Grecji wykorzystają szansę na pokój?
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277403,najdluzszy-konflikt-wspolczesnej-europy-czy-liderzy-turcji-i-grecji-w.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277403,najdluzszy-konflikt-wspolczesnej-europy-czy-liderzy-turcji-i-grecji-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T14:34:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/B81ktkuTURBXy9iNTE0NzExMC1hYjk2LTQxNDMtOTMzMy0yMDMxYzA4NWJjMDcuanBlZ5GTBc0BHcyg" />Przywódcy Turcji oraz Grecji są szczerzy w podejmowanych próbach rozwiązania konfliktu pomiędzy państwami i zdolni do osiągnięcia w tej sprawie porozumienia - ocenił prof. Alexis Heraclides, cytowany w czwartek przez turecką agencję Anatolia.

## Marsylia opanowana przez narkotykowe gangi. Bezpieczeństwo na ulicach ma przywrócić specjednostka CRS 8
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9277399,marsylia-opanowana-przez-narkotykowe-gangi-bezpieczenstwo-na-ulicach.html](https://forsal.pl/swiat/unia-europejska/artykuly/9277399,marsylia-opanowana-przez-narkotykowe-gangi-bezpieczenstwo-na-ulicach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T14:18:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AxektkuTURBXy8xZjNhMDNiNS1kMWY4LTQwZjMtYWJhNC1kNWE4MTc1MGU3MDguanBlZ5GTBc0BHcyg" />Szef MSW Francji Gerald Darmanin poinformował w czwartek na platformie X (dawniej Twitter) o wysłaniu do Marsylii specjalnych jednostek CRS 8 do tłumienia miejskiej przemocy. Od początku roku w departamencie Bouches-du-Rhone, którego stolicą jest Marsylia, zginęło w strzelaninach więcej osób niż w całym 2022 roku.

## Stoltenberg o rozmowach pokojowych: Decyzja o rozpoczęciu negocjacji pozostaje w rękach Kijowa
 - [https://forsal.pl/swiat/ukraina/artykuly/9277380,stoltenberg-o-rozmowach-pokojowych-decyzja-o-rozpoczeciu-negocjacji-p.html](https://forsal.pl/swiat/ukraina/artykuly/9277380,stoltenberg-o-rozmowach-pokojowych-decyzja-o-rozpoczeciu-negocjacji-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:38:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TXJktkuTURBXy83NTY1ZTc3Zi1lMWJjLTQ1YjMtOWJkNS04MGJjYjQ3Zjc0YTMuanBlZ5GTBc0BHcyg" />Ukraina sama zdecyduje, kiedy nastaną odpowiednie warunki w celu podjęcia jakichkolwiek rozmów pokojowych z Rosją - oznajmił w czwartek sekretarz generalny NATO Jens Stoltenberg na konferencji w norweskim mieście Arendal.

## Kryzys parlamentarny na Łotwie. Premier Karinsz złożył dymisję
 - [https://forsal.pl/gospodarka/polityka/artykuly/9277378,kryzys-parlamentarny-na-lotwie-premier-karinsz-zlozyl-dymisje.html](https://forsal.pl/gospodarka/polityka/artykuly/9277378,kryzys-parlamentarny-na-lotwie-premier-karinsz-zlozyl-dymisje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:33:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejxktkuTURBXy9hNzg3NzA0ZS0wMjhiLTRkMzctOGZiNS1iODdhZGEyMWMyNjIuanBlZ5GTBc0BHcyg" />Premier Łotwy Kriszjanis Karinsz złożył w czwartek na ręce prezydenta Edgarsa Rinkeviczsa rezygnację z urzędu. W kraju będzie formowany nowy gabinet.

## Biedni kontra bogaci. Gdzie na świecie nierówności majątkowe są najwyższe? [RAPORT]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9277372,biedni-kontra-bogaci-gdzie-na-swiecie-nierownosci-majatkowe-sa-najwyz.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9277372,biedni-kontra-bogaci-gdzie-na-swiecie-nierownosci-majatkowe-sa-najwyz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:22:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o99ktkuTURBXy83OWJiNWFjZC0zNzQ1LTQyMzAtYWM2ZC1kNWEwN2EzNzEzOTkuanBlZ5GTBc0BHcyg" />Jak wynika z najnowszego raportu Global Wealth Report nierówności finansowe między mieszkańcami są najwyższe ze wszystkich badanych państw w Brazylii, USA oraz Indiach. Najlepiej wypada pod tym względem Belgia, gdzie są ona najmniejsze.

## Polwax miał wstępnie 9,6 mln zł straty netto, 8,3 mln zł straty EBITDA w I poł. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277364,polwax-mial-wstepnie-96-mln-zl-straty-netto-83-mln-zl-straty-ebitda.html](https://forsal.pl/finanse/gielda/artykuly/9277364,polwax-mial-wstepnie-96-mln-zl-straty-netto-83-mln-zl-straty-ebitda.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:14:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MVtktkuTURBXy83MTI0ZjhiZi03NzU5LTRlNWItYjQ2Yi05ZmRlZmZhODA5NDUuanBlZ5GTBc0BHcyg" />undefined

## Mo-Bruk spodziewa się przejęcia co najmniej jednej spółki w IV kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277361,mo-bruk-spodziewa-sie-przejecia-co-najmniej-jednej-spolki-w-iv-kw-202.html](https://forsal.pl/finanse/gielda/artykuly/9277361,mo-bruk-spodziewa-sie-przejecia-co-najmniej-jednej-spolki-w-iv-kw-202.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:12:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Benefit Systems liczy na typowo lepszą wynikowo II połowę roku
 - [https://forsal.pl/finanse/gielda/artykuly/9277360,benefit-systems-liczy-na-typowo-lepsza-wynikowo-ii-polowe-roku.html](https://forsal.pl/finanse/gielda/artykuly/9277360,benefit-systems-liczy-na-typowo-lepsza-wynikowo-ii-polowe-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:10:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DY5ktkuTURBXy84NDBhOTYwNS00ZjY1LTRlNzMtOGQ0NS0xODQ0OTQ3MDdmNTYuanBlZ5GTBc0BHcyg" />undefined

## Schińszczanie Tybetu. Chińscy naukowcy chcą, by region przyjął nazwę "Xizang"
 - [https://forsal.pl/swiat/chiny/artykuly/9277359,schinszczanie-tybetu-chinscy-naukowcy-chca-by-region-przyjal-nazwe-.html](https://forsal.pl/swiat/chiny/artykuly/9277359,schinszczanie-tybetu-chinscy-naukowcy-chca-by-region-przyjal-nazwe-.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T13:09:47+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UhiktkuTURBXy8wNzc2MTU0Zi0zOGJkLTRhY2ItYmMxZC00NmNjZTczNjNjMGEuanBlZ5GTBc0BHcyg" />Zebrani na konferencji naukowej w Pekinie naukowcy zaapelowali do swojego środowiska, aby w publikacjach anglojęzycznych zastąpić &quot;wprowadzającą w błąd&quot; nazwę Tybet transliteracją chińskiej nazwy regionu Xizang – informuje w środę hongkoński dziennik &quot;South China Morning Post&quot;. Taka zmiana byłaby przejawem pogłębiającego się schińszczenia regionu.

## WHO zaakceptował medycynę ludową. W Indiach rozpoczął się pierwszy w historii Światowy Szczyt Medycyny Tradycyjnej
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9277349,who-zaakceptowal-medycyne-ludowa-w-indiach-rozpoczal-sie-pierwszy-w-h.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9277349,who-zaakceptowal-medycyne-ludowa-w-indiach-rozpoczal-sie-pierwszy-w-h.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T12:58:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Zi0ktkuTURBXy8yYmM3ZWIyNi1kNGE1LTRjNDEtOTA4NS0yMDRhYTAxOWJhZTYuanBlZ5GTBc0BHcyg" />Światowa Organizacja Zdrowia (WHO) otworzyła w czwartek w mieście Gandhinagar w zachodnich Indiach pierwszą konferencję poświęconą medycynie tradycyjnej, która ma na celu zbieranie dowodów i danych w celu umożliwienia bezpiecznego stosowania takich metod leczenia - poinformowała agencja AFP.

## Brygada Azow wróciła na front. Walczy pod Kreminną
 - [https://forsal.pl/swiat/ukraina/artykuly/9277323,brygada-azow-wrocila-na-front-walczy-pod-kreminna.html](https://forsal.pl/swiat/ukraina/artykuly/9277323,brygada-azow-wrocila-na-front-walczy-pod-kreminna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T12:29:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gzZktkuTURBXy8zZTlmNDQ5NS00M2RjLTQ4YWYtYmQ4Ni04MTMxNTk1Nzg4YTcuanBlZ5GTBc0BHcyg" />Legendarna brygada Azow, która wiosną 2022 roku wsławiła się bohaterską obroną zakładów metalurgicznych Azowstal w Mariupolu, powróciła do wypełniania zadań bojowych; żołnierze Azowa walczą w okolicach rezerwatu Serebriańskiego pod Kreminną w obwodzie ługańskim - oznajmił w czwartek przedstawiciel ukraińskiej Gwardii Narodowej płk Mykoła Urszałowicz.

## Nieudany test rakietowy na Tajwanie. Patriot eksplodował w trakcie lotu
 - [https://forsal.pl/swiat/chiny/artykuly/9277300,nieudany-test-rakietowy-na-tajwanie-patriot-eksplodowal-w-trakcie-lot.html](https://forsal.pl/swiat/chiny/artykuly/9277300,nieudany-test-rakietowy-na-tajwanie-patriot-eksplodowal-w-trakcie-lot.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T12:16:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/P-vktkuTURBXy9iYjkzMjRiOC1mOTYxLTRkMWItYWRmZS1iYTFjYzUzYTg1ZjMuanBlZ5GTBc0BHcyg" />Amerykańska rakieta Patriot MIM-104F (PAC-3), którą wystrzelono podczas testów, eksplodowała przed osiągnięciem celu – podaje tajwański portal Taipei Times w środę. Doniesienia lokalnych mediów potwierdził szef sztabu wojsk lotniczych Tsao Chin-Ping.

## Ukraina jest coraz bliżej otrzymania samolotów F-16?
 - [https://forsal.pl/swiat/ukraina/artykuly/9277282,ukraina-jest-coraz-blizej-otrzymania-samolotow-f-16.html](https://forsal.pl/swiat/ukraina/artykuly/9277282,ukraina-jest-coraz-blizej-otrzymania-samolotow-f-16.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T11:50:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4WEktkuTURBXy9iMzAxM2YzMi1jNDdjLTQ4N2ItYmY3My05ZmNlNDZmNjMxZDUuanBlZ5GTBc0BHcyg" />Wkrótce nadejdą dobre wiadomości na temat przekazania Ukrainie samolotów F-16 – oświadczył w czwartek szef ukraińskiej dyplomacji Dmytro Kułeba. Wyraził opinię, że maszyny te dotrą do jego kraju wraz z zakończeniem szkolenia pilotów.

## Soboń: Inflacja CPI osiągnie poziom jednocyfrowy we wrześniu
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9277256,sobon-inflacja-cpi-osiagnie-poziom-jednocyfrowy-we-wrzesniu.html](https://forsal.pl/gospodarka/inflacja/artykuly/9277256,sobon-inflacja-cpi-osiagnie-poziom-jednocyfrowy-we-wrzesniu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T11:19:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PqQktkuTURBXy80NWQ0ZGIwZi02ZjlkLTRjNjUtYTgxOS04ZTBhNGIzMzM2YzkuanBlZ5GTBc0BHcyg" />undefined

## El Niño – gorączka oceanu
 - [https://forsal.pl/lifestyle/nauka/artykuly/9277254,el-nino-goraczka-oceanu.html](https://forsal.pl/lifestyle/nauka/artykuly/9277254,el-nino-goraczka-oceanu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T11:16:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hXrktkuTURBXy82NzMyYzE1OS1jMDUyLTRjOTEtODhlNy05NzViMjQzYmNkNDQuanBlZ5GTBc0BHcyg" />El Niño to zjawisko klimatyczne charakteryzujące się nieregularnymi zmianami temperatury wody w środkowej i wschodniej części Pacyfiku. Możemy je postrzegać jako &quot;gorączkę&quot; oceanu. Efektem El Niño jest nie tylko wzrost temperatury powierzchni oceanu, ale także wpływ na globalne warunki pogodowe, często prowadzący do ekstremalnych zjawisk, takich jak susze, powodzie czy burze.

## PKB w UE w II kwartale 2023 roku. Polska z największym spadkiem
 - [https://forsal.pl/gospodarka/pkb/artykuly/9277215,pkb-w-ue-w-ii-kwartale-2023-roku-polska-z-najwiekszym-spadkiem.html](https://forsal.pl/gospodarka/pkb/artykuly/9277215,pkb-w-ue-w-ii-kwartale-2023-roku-polska-z-najwiekszym-spadkiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T10:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QyktkuTURBXy8zZDdmYjZhNy02YmQ1LTRiMWEtODc0OC1mZTUwODU1Zjg1ZDIuanBlZ5GTBc0BHcyg" />Według wstępnych szacunków opublikowanych przez Eurostat, w drugim kwartale 2023 r. PKB wyrównany sezonowo wzrósł w strefie euro o 0,3 proc. i nie zmienił się w UE w porównaniu z poprzednim kwartałem. W ujęciu kwartalnym PKB Polski spadło najwięcej w całej UE.

## Majątek gospodarstw domowych skurczył się po raz pierwszy od kryzysu finansowego z 2008 roku
 - [https://forsal.pl/finanse/artykuly/9276452,majatek-gospodarstw-domowych-skurczyl-sie-po-raz-pierwszy-od-kryzysu-f.html](https://forsal.pl/finanse/artykuly/9276452,majatek-gospodarstw-domowych-skurczyl-sie-po-raz-pierwszy-od-kryzysu-f.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T10:15:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NlqktkuTURBXy8yMjA2ZDkwOC1lZTYxLTRmYjYtYjFkOC0wYmUzNWM4Y2MyOGQuanBlZ5GTBc0BHcyg" />Globalny majątek gospodarstw domowych zmniejszył się w zeszłym roku po raz pierwszy od kryzysu finansowego z 2008 r., kiedy inflacja i aprecjacja dolara amerykańskiego zmniejszyły wartość aktywów gospodarstw domowych o około 11,3 biliona dolarów.

## Chińskie koncerny zbrojeniowe robią interesy z Rosją? Te drony dziwnie przypominają irańskie
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277208,chinskie-koncerny-zbrojeniowe-robia-interesy-z-rosja-te-drony-dziwnie.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9277208,chinskie-koncerny-zbrojeniowe-robia-interesy-z-rosja-te-drony-dziwnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T10:06:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/X8_ktkuTURBXy9jOTY1NWY4MS0yMmZlLTQ4N2ItYmM4Ny1hOTk2OWY4NzhhMzkuanBlZ5GTBc0BHcyg" />Na międzynarodowym forum wojskowo-technicznym Armia-2023 pod Moskwą nieokreślona chińska firma zaprezentowała samoloty bezzałogowe przypominające irańskie drony kamikadze Shahed-136 – poinformował w środę portal Defence Express, powołując się na udostępnione zdjęcia. Sam fakt prezentacji broni budzi obawy, że chińskie koncerny zbrojeniowe mogą robić interesy z Rosją.

## Niemcy nie zamierzają wydawać 2 proc. PKB na obronność? Rząd wycofuje się ze zmian w ustawie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9277204,niemcy-nie-zamierzaja-wydawac-2-proc-pkb-na-obronnosc-rzad-wycofuje.html](https://forsal.pl/swiat/aktualnosci/artykuly/9277204,niemcy-nie-zamierzaja-wydawac-2-proc-pkb-na-obronnosc-rzad-wycofuje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T10:02:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3RYktkuTURBXy80ZDg5NTk0Ni00NjMwLTQ0YjMtYWE4YS1lNmUwNGNmMjNiNjUuanBlZ5GTBc0BHcyg" />Niemcy zapowiadały przeznaczenie 2 proc. PKB rocznie na cele obronności i zapisanie tego w prawie. Ale teraz rząd wycofał się z tego planu – informuje w czwartek portal RedaktionsNetzwerk Deutschland (RND).

## Sejm przyjął wniosek rządu o przeprowadzenie referendum ogólnokrajowego
 - [https://forsal.pl/gospodarka/polityka/artykuly/9277201,sejm-przyjal-wniosek-rzadu-o-przeprowadzenie-referendum-ogolnokrajoweg.html](https://forsal.pl/gospodarka/polityka/artykuly/9277201,sejm-przyjal-wniosek-rzadu-o-przeprowadzenie-referendum-ogolnokrajoweg.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T10:00:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1_0ktkuTURBXy9mMzZiZTFkMi1iZTU0LTRiNmEtYmJkMC0yNTM3YTY0OTRjMGQuanBlZ5GTBc0BHcyg" />Sejm przyjął w czwartek wniosek rządu o przeprowadzenie referendum ogólnokrajowego. Nie oznacza to jeszcze zarządzenia referendum. Teraz wniosek rządu trafi do Komisji Ustawodawczej, która przygotuje projekt uchwały o zarządzeniu referendum.

## Pakt Senacki 2023. Jest porozumienie ws. wszystkich 100 okręgów
 - [https://forsal.pl/gospodarka/polityka/artykuly/9277198,pakt-senacki-2023-jest-porozumienie-ws-wszystkich-100-okregow.html](https://forsal.pl/gospodarka/polityka/artykuly/9277198,pakt-senacki-2023-jest-porozumienie-ws-wszystkich-100-okregow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T09:58:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nqOktkuTURBXy9hYzg3YjBjOC03OWJlLTQ5ZjQtYmU5MS1iYjRjOTM1NjcyN2YuanBlZ5GTBc0BHcyg" />Zakończyły się prace nad drugą edycją Paktu Senackiego. Najważniejsze jest to, że po długich przygotowaniach doszliśmy do porozumienia, kierując się przede wszystkim optymalizacją wyniku - powiedział w czwartek senator Zygmunt Frankiewicz. Uzyskaliśmy porozumienie w sprawie wszystkich stu okręgów - oświadczył.

## Koronawirus w Polsce: 49 zakażenia, nie było przypadków śmiertelnych [DANE Z 17.08]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-49-zakazenia-nie-bylo-przypadkow-smiertelnych-.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-49-zakazenia-nie-bylo-przypadkow-smiertelnych-.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T08:37:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 49 zakażeń koronawirusem, w tym 15 ponownych. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w czwartek na stronach rządowych. Wykonano 711 testów w kierunku SARS-CoV-2.

## Jakie pytania zadałaby Konfederacja, gdyby to ona organizowała referendum?
 - [https://forsal.pl/gospodarka/polityka/artykuly/9277142,jakie-pytania-zadalaby-konfederacja-gdyby-to-ona-organizowala-referen.html](https://forsal.pl/gospodarka/polityka/artykuly/9277142,jakie-pytania-zadalaby-konfederacja-gdyby-to-ona-organizowala-referen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T08:33:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V47ktkuTURBXy9hYTI3YmY1Mi1jZjc5LTQ0ZDctOWZjYi02M2RhYTlmYzExNWMuanBlZ5GTBc0BHcyg" />Pytania referendalne są sformułowane w sposób widocznie chytry, przewrotny i cwany. Konfederacja prezentuje rozsądne pytania, które można by zadać – powiedział w czwartek w Sejmie szef koła poselskiego Konfederacji Krzysztof Bosak.

## Ukraina zapewne zdoła zgromadzić zapasy paliwa na zimę
 - [https://forsal.pl/swiat/ukraina/artykuly/9277107,ukraina-zapewne-zdola-zgromadzic-zapasy-paliwa-na-zime.html](https://forsal.pl/swiat/ukraina/artykuly/9277107,ukraina-zapewne-zdola-zgromadzic-zapasy-paliwa-na-zime.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:50:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vFektkuTURBXy83NDU4N2JmZC0zNmIyLTQ3MTEtOTU5Mi01OWQ2MTZmNzE5OWIuanBlZ5GTBc0BHcyg" />Mimo ciągłej presji wojennej, ukraińskie wysiłki w celu gromadzenia zapasów paliwa prawdopodobnie zakończą się sukcesem, zapewniając wystarczające rezerwy paliwa podczas zbliżającego się okresu zimowego - przekazało w czwartek brytyjskie ministerstwo obrony.

## Mo-Bruk spodziewa się ponad 100 mln zł nakładów inwestycyjnych w 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277100,mo-bruk-spodziewa-sie-ponad-100-mln-zl-nakladow-inwestycyjnych-w-2023.html](https://forsal.pl/finanse/gielda/artykuly/9277100,mo-bruk-spodziewa-sie-ponad-100-mln-zl-nakladow-inwestycyjnych-w-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:45:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OCpktkuTURBXy9kNTZlOGE1Yy00OTEyLTQ1YjktYTZiNS1lN2Y2YTk1YzIzNDYuanBlZ5GTBc0BHcyg" />undefined

## Mo-Bruk miał 40,65 mln zł zysku netto, 53,66 mln zł zysku EBITDA w I poł. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277095,mo-bruk-mial-4065-mln-zl-zysku-netto-5366-mln-zl-zysku-ebitda-w-i-p.html](https://forsal.pl/finanse/gielda/artykuly/9277095,mo-bruk-mial-4065-mln-zl-zysku-netto-5366-mln-zl-zysku-ebitda-w-i-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:43:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fOzktkuTURBXy85MjNlMTUxMy03YjVmLTRmMDEtYWQxYS1lN2IzZDQ5Nzc2OWQuanBlZ5GTBc0BHcyg" />undefined

## Inter Cars miał wstępnie ok. 155 mln zł zysku netto w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277092,inter-cars-mial-wstepnie-ok-155-mln-zl-zysku-netto-w-ii-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9277092,inter-cars-mial-wstepnie-ok-155-mln-zl-zysku-netto-w-ii-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:40:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xh_ktkuTURBXy8zNjY5ODllOS1lMTVlLTQ5MTMtYjNmZS05MWE0MWYyZmZiOGQuanBlZ5GTBc0BHcyg" />undefined

## Alumetal miał 10,16 mln zł zysku netto, 24,1 mln zł zysku EBITDA w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277089,alumetal-mial-1016-mln-zl-zysku-netto-241-mln-zl-zysku-ebitda-w-ii.html](https://forsal.pl/finanse/gielda/artykuly/9277089,alumetal-mial-1016-mln-zl-zysku-netto-241-mln-zl-zysku-ebitda-w-ii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:39:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yfaktkuTURBXy9jN2E5ZTliNS05MWE0LTRlNzgtYjVjZS04ZTdkNDdkMDRjMzQuanBlZ5GTBc0BHcyg" />undefined

## Atende miało wstępnie 2,32 mln zł zysku netto, 6,63 mln zł zysku EBITDA w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277086,atende-mialo-wstepnie-232-mln-zl-zysku-netto-663-mln-zl-zysku-ebitd.html](https://forsal.pl/finanse/gielda/artykuly/9277086,atende-mialo-wstepnie-232-mln-zl-zysku-netto-663-mln-zl-zysku-ebitd.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:36:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Boryszew miał 78,65 mln zł zysku netto z dział. kont. w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277085,boryszew-mial-7865-mln-zl-zysku-netto-z-dzial-kont-w-ii-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9277085,boryszew-mial-7865-mln-zl-zysku-netto-z-dzial-kont-w-ii-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:35:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2-9ktkuTURBXy8yODU2ZDUxZS1hZjRlLTQ5MDktODlmNC05M2Y0OGYyNWI4MGIuanBlZ5GTBc0BHcyg" />undefined

## Grupa Polsat Plus miała 7,3 mln zł straty netto, 798,5 mln zł skoryg zysku EBITDA w II kw.
 - [https://forsal.pl/finanse/gielda/artykuly/9277084,grupa-polsat-plus-miala-73-mln-zl-straty-netto-7985-mln-zl-skoryg-z.html](https://forsal.pl/finanse/gielda/artykuly/9277084,grupa-polsat-plus-miala-73-mln-zl-straty-netto-7985-mln-zl-skoryg-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:33:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n5_ktkuTURBXy9lYjI5ZmQ4NS1iZWQwLTQ2MjItOGEyZi0wMTc0MTQxYzhiNjUuanBlZ5GTBc0BHcyg" />undefined

## Benefit Systems miał 129,47 mln zł zysku netto, 215,61 mln zł zysku EBITDA w II kw. 2023
 - [https://forsal.pl/finanse/gielda/artykuly/9277080,benefit-systems-mial-12947-mln-zl-zysku-netto-21561-mln-zl-zysku-eb.html](https://forsal.pl/finanse/gielda/artykuly/9277080,benefit-systems-mial-12947-mln-zl-zysku-netto-21561-mln-zl-zysku-eb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:29:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bfEktkuTURBXy81MTY0NTc4MS01MDE0LTRjYjMtOTk0MS1kYjRiNDVjN2E3MjYuanBlZ5GTBc0BHcyg" />undefined

## Creepy Jar miał wstępnie 12,8 mln zł zysku netto w I poł. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9277075,creepy-jar-mial-wstepnie-128-mln-zl-zysku-netto-w-i-pol-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9277075,creepy-jar-mial-wstepnie-128-mln-zl-zysku-netto-w-i-pol-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T07:23:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OCpktkuTURBXy9kNTZlOGE1Yy00OTEyLTQ1YjktYTZiNS1lN2Y2YTk1YzIzNDYuanBlZ5GTBc0BHcyg" />undefined

## Nieaktualne standardy bezpieczeństwa, przestarzały sprzęt - oto realia polskich kąpielisk
 - [https://forsal.pl/lifestyle/turystyka/artykuly/9276576,nieaktualne-standardy-bezpieczenstwa-przestarzaly-sprzet-oto-realia.html](https://forsal.pl/lifestyle/turystyka/artykuly/9276576,nieaktualne-standardy-bezpieczenstwa-przestarzaly-sprzet-oto-realia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:53:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/P-sktkuTURBXy9mNjg2NTViYi04OWI1LTQzYjgtYjJhNi1hZWNjYzFhNGRiNGIuanBlZ5GTBc0BHcyg" />Brak jednego systemu informującego o akcjach ratowniczych, nieaktualne standardy bezpieczeństwa nad wodą, przestarzały i niepotrzebny sprzęt – to główne grzechy ratownictwa wodnego. Wiele działań zależy tylko od dobrej woli samorządów lokalnych, policji czy straży pożarnej

## Polska gospodarka w dołku, ekonomiści obniżają prognozy wzrostu
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9276669,polska-gospodarka-w-dolku-ekonomisci-obnizaja-prognozy-wzrostu.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9276669,polska-gospodarka-w-dolku-ekonomisci-obnizaja-prognozy-wzrostu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:44:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S8PktkuTURBXy9lNjI4MGNmMC0zMGIzLTQzYTMtYmI5Ni1iOWIxZTQyNTNmODYuanBlZ5GTBc0BHcyg" />Słabe dane za II kw. skłaniają ekonomistów do obniżenia prognoz wzrostu na cały 2023 r.

## Skoro drożeje jogurt, trudno, by mieszkania taniały [WYWIAD]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9276641,skoro-drozeje-jogurt-trudno-by-mieszkania-tanialy-wywiad.html](https://forsal.pl/gospodarka/polityka/artykuly/9276641,skoro-drozeje-jogurt-trudno-by-mieszkania-tanialy-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:39:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZM-ktktTURBXy9iY2YwYTk3MS1jYmM1LTQ0MjQtODUwYS1hNTk4MDY4Yzg2Y2IucG5nkZMFzQEdzKA" />&quot;Jeśli doprowadzimy do wybudowania 1,5 mln mieszkań w perspektywie pięciu–siedmiu lat, to rozwiąże się nam mnóstwo problemów, chociażby ze wzrostem cen czy z drogim najmem&quot;. Wywiad z ministrem rozwoju i technologii Waldemarem Budą.

## Ile osób będzie mogło przejść na emeryturę pomostową w 2024 roku? ZUS podał dane
 - [https://forsal.pl/gospodarka/artykuly/9277025,ile-osob-bedzie-moglo-przejsc-na-emeryture-pomostowa-w-2024-roku-zus.html](https://forsal.pl/gospodarka/artykuly/9277025,ile-osob-bedzie-moglo-przejsc-na-emeryture-pomostowa-w-2024-roku-zus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:37:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d9JktkuTURBXy8xYWVhNjM5MS04OGE0LTQyOWUtYWU0My04NzM3ZGZiMjM2NDcuanBlZ5GTBc0BHcyg" />Według szacunków po uchyleniu wygasającego charakteru emerytur pomostowych na to świadczenie przejdzie w 2024 r. około 7,3 tys. osób - przekazał PAP Zakład Ubezpieczeń Społecznych. Pod koniec czerwca 2023 r. emerytury pomostowe pobierało łącznie 40,8 tys. osób.

## Paweł Borys pozywa Mariana Banasia. Za rozpowszechnianie informacji nt. rzekomych nieprawidłowości w PFR
 - [https://forsal.pl/gospodarka/polityka/artykuly/9276653,pawel-borys-pozywa-mariana-banasia-za-rozpowszechnianie-informacji-nt.html](https://forsal.pl/gospodarka/polityka/artykuly/9276653,pawel-borys-pozywa-mariana-banasia-za-rozpowszechnianie-informacji-nt.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:10:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hh7ktkuTURBXy8wY2Q3MTMwZS1lM2JhLTQ0MjYtOGQwNi0wZGQ0NTdkOWYxNGUuanBlZ5GTBc0BHcyg" />Pozew został złożony wczoraj w warszawskim sądzie okręgowym. Wskazuje, że Marian Banaś publicznie rozpowszechnia twierdzenia na temat rzekomych nieprawidłowości w działalności funduszu.

## Receptomaty. Biznes opłacalny także dla osób, które z medycyną nie miały dotąd wiele wspólnego
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9276637,receptomaty-biznes-oplacalny-takze-dla-osob-ktore-z-medycyna-nie-mia.html](https://forsal.pl/biznes/aktualnosci/artykuly/9276637,receptomaty-biznes-oplacalny-takze-dla-osob-ktore-z-medycyna-nie-mia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T06:05:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2kGktkuTURBXy9lNTAyN2YyOS0zZTllLTQwMzQtYWJmNy0xOGJjZTdjZmM1MGYuanBlZ5GTBc0BHcyg" />Ten biznes stał się opłacalny także dla osób, które z medycyną nie miały dotąd wiele wspólnego. Przeanalizowaliśmy rynek firm pośredniczących w handlu receptami.

## Kursy walut: Złoty w czwartek osłabił się w stosunku do euro, dolara i franka
 - [https://forsal.pl/finanse/waluty/artykuly/9276976,kursy-walut-zloty-w-czwartek-oslabil-sie-w-stosunku-do-euro-dolara-i.html](https://forsal.pl/finanse/waluty/artykuly/9276976,kursy-walut-zloty-w-czwartek-oslabil-sie-w-stosunku-do-euro-dolara-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:55:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qJuktkuTURBXy84OGVlN2Y5ZC1jMzY1LTQ5M2ItYjY1NC03ZDdkNmIzODhhZDYuanBlZ5GTBc0BHcyg" />W czwartek ok. godz. 7.15 złoty osłabił się względem euro o 0,03 proc. Za euro trzeba było zapłacić około 4,47 zł. Polska waluta potaniała także w stosunku do dolara o 0,18 proc. Dolar był wyceniany na 4,11 zł. W górę poszły także notowania franka szwajcarskiego o 0,09 proc., za którego trzeba było zapłacić 4,67 zł.

## Jeden lokal wyborczy i jedna urna, czyli logistyka październikowych wyborów i referendum
 - [https://forsal.pl/gospodarka/polityka/artykuly/9276968,jeden-lokal-wyborczy-i-jedna-urna-czyli-logistyka-pazdziernikowych-wy.html](https://forsal.pl/gospodarka/polityka/artykuly/9276968,jeden-lokal-wyborczy-i-jedna-urna-czyli-logistyka-pazdziernikowych-wy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:52:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZCyktkuTURBXy80M2NjMzhiZS1lZTJmLTQ3NmEtYjViMy0xMDA1NTU4YTg0NmIuanBlZ5GTBc0BHcyg" />W przypadku przeprowadzenia referendum razem z wyborami do Sejmu i Senatu, głosowanie będzie odbywało się w tych samych lokalach wyborczych, przy użyciu jednej urny. Wyborca sam zdecyduje, w których głosowaniach weźmie udział. Szefowa KBW Magdalena Pietrzak zwraca uwagę na wydłużenie się pracy obwodowych komisji ustalających wyniki głosowania.

## Afera korupcyjna w Portugalii. Osoby związane z ministerstwem obrony i sektorem zbrojeniowym usłyszały zarzuty
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9276966,afera-korupcyjna-w-portugalii-osoby-zwiazane-z-ministerstwem-obrony-i.html](https://forsal.pl/swiat/aktualnosci/artykuly/9276966,afera-korupcyjna-w-portugalii-osoby-zwiazane-z-ministerstwem-obrony-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:47:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Z9VktkuTURBXy9iNWRlMTQ0ZC1jOGM1LTQ5ODQtOWExNy02ZjJiOTkyMjMxY2MuanBlZ5GTBc0BHcyg" />Prokuratura generalna Portugalii postawiła w środę wieczorem zarzuty 73 osobom związanym z ministerstwem obrony tego kraju oraz jego sektorem zbrojeniowym.

## Pożary w Kanadzie. Zarządzono ewakuację największego miasta na północy kraju
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9276958,pozary-w-kanadzie-zarzadzono-ewakuacje-najwiekszego-miasta-na-polnocy.html](https://forsal.pl/swiat/aktualnosci/artykuly/9276958,pozary-w-kanadzie-zarzadzono-ewakuacje-najwiekszego-miasta-na-polnocy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:41:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PdnktkuTURBXy82NTgwZjI3YS04OTViLTQ1NDYtYjZjOC04Y2QwMGJiZWVmZTUuanBlZ5GTBc0BHcyg" />Mieszkańcy Yellowknife, największego miasta na północy Kanady, muszą się ewakuować. Jeśli nie spadnie deszcz, pożary mogą tam dotrzeć przed weekendem – poinformował w środę wieczorem minister środowiska Terytoriów Północno-Zachodnich Shane Thompson.

## Teneryfa płonie. Trwa ewakuacja ludności
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9276956,teneryfa-plonie-trwa-ewakuacja-ludnosci.html](https://forsal.pl/swiat/aktualnosci/artykuly/9276956,teneryfa-plonie-trwa-ewakuacja-ludnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:38:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MxxktkuTURBXy8yYmUwYWIzYi1iMTk4LTQ5NDEtYjhlYi1iNDIyZGM0NWZhMjcuanBlZ5GTBc0BHcyg" />Ponad 150 osób ewakuowały władze Wysp Kanaryjskich w środę wieczorem w związku z groźnym pożarem lasów w środkowo-północnej części Teneryfy, w gminach Arafo i Candelaria.

## Jan Hartman nie będzie startował z list Lewicy. Reakcja na wpis o pedofilach
 - [https://forsal.pl/gospodarka/polityka/artykuly/9276954,jan-hartman-nie-bedzie-startowal-z-list-lewicy-reakcja-na-wpis-o-pedo.html](https://forsal.pl/gospodarka/polityka/artykuly/9276954,jan-hartman-nie-bedzie-startowal-z-list-lewicy-reakcja-na-wpis-o-pedo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:34:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6eEktkuTURBXy84NDhlODI3Yy1hMjdmLTQyMzEtOGIxYy0yMDkzNTE3MzU0NjcuanBlZ5GTBc0BHcyg" />Prof. Jan Hartman nie będzie kandydował w żadnym z okręgów list Lewicy w najbliższych wyborach parlamentarnych - poinformował współprzewodniczący małopolskiej Nowej Lewicy Ryszard Śmiałek.

## Na Wall Street drugi dzień zniżek z rzędu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9276947,na-wall-street-drugi-dzien-znizek-z-rzedu.html](https://forsal.pl/biznes/aktualnosci/artykuly/9276947,na-wall-street-drugi-dzien-znizek-z-rzedu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:30:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v-FktkuTURBXy8xYTUyMjdiOC0wOTNiLTRmZDktOGE5MS01OTQzNzdiMDcxN2QuanBlZ5GTBc0BHcyg" />Środowa sesja na Wall Street zakończyła się spadkami głównych indeksów. To drugi dzień zniżek na amerykańskich giełdach z rzędu. W centrum uwagi był protokół z ostatniego posiedzenia Fed, z którego wynika, że większość jego członków obawia się, że inflacja może wymusić kolejne podwyżki stóp proc.

## Szczyt G20 w Delhi bez Ukrainy? "Zajmujemy się rozwojem gospodarczym, nie rozwiązywaniem konfliktów"
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9276945,szczyt-g20-w-delhi-bez-ukrainy-zajmujemy-sie-rozwojem-gospodarczym.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9276945,szczyt-g20-w-delhi-bez-ukrainy-zajmujemy-sie-rozwojem-gospodarczym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T05:24:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/x08ktkuTURBXy9jN2Q4ZDJkMC02NDRlLTQxZDQtOWQ0NC1jMGVkYjJjOGVjMTcuanBlZ5GTBc0BHcyg" />Ukraina nie otrzyma zaproszenia na szczyt grupy G20 w stolicy Indii Delhi, planowany w dniach 9-10 września; podjęliśmy taką decyzję, ponieważ G20 zajmuje się kwestiami wzrostu i rozwoju gospodarczego, a rozwiązywanie konfliktów to kompetencja Rady Bezpieczeństwa ONZ - oświadczył w środę szef indyjskiego MSZ Subrahmanyam Jaishankar.

## Jak Polacy odpoczywają tego lata? Inflacja poważnym problemem
 - [https://forsal.pl/lifestyle/artykuly/9276391,jak-polacy-odpoczywaja-tego-lata-inflacja-powaznym-problemem.html](https://forsal.pl/lifestyle/artykuly/9276391,jak-polacy-odpoczywaja-tego-lata-inflacja-powaznym-problemem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/edhktkuTURBXy9iNGFlZGJlZS1kNTEyLTQ0OWEtOTVhMy1iMTE5ZmQzODlhNzIuanBlZ5GTBc0BHcyg" />Polacy w większości na wakacjach, choć jak pokazują wyniki badania PAYBACK Opinion Poll, wiele osób musiało zmodyfikować swoje plany z powodu inflacji. Mimo, że nieco ponad połowa Polaków (51%) spędzi wakacje w kraju, to nie są przekonani, czy są one tańsze niż wczasy za granicą.

## Znikająca Hiszpania
 - [https://forsal.pl/gospodarka/demografia/artykuly/9220831,znikajaca-hiszpania.html](https://forsal.pl/gospodarka/demografia/artykuly/9220831,znikajaca-hiszpania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_UAktkuTURBXy9iYzMxNjBjNS03OWYxLTQ3NGItYjdkMC05MGMwMTZmNGQ2NTcuanBlZ5GTBc0BHcyg" />Obumierające miasteczka czy nawet zupełnie opustoszałe miejscowości to coraz częstszy obraz Hiszpanii. Choć podobną sytuację można zaobserwować w różnych krajach – szczególnie na południu Europy – to jednak największy kraj Półwyspu Iberyjskiego jest wyróżniającym się przykładem.

## Specjalny "śledzący" bot i zamknięta sieć tylko dla Rosjan. Jak Kreml cenzuruje Internet?
 - [https://forsal.pl/lifestyle/technologie/artykuly/9276297,specjalny-sledzacy-bot-i-zamknieta-siec-tylko-dla-rosjan-jak-kreml.html](https://forsal.pl/lifestyle/technologie/artykuly/9276297,specjalny-sledzacy-bot-i-zamknieta-siec-tylko-dla-rosjan-jak-kreml.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LNCktkuTURBXy9kZWU2NzQ2Ny03Nzk3LTQwNmYtYTQ4Ni1hNDcyOWZhMDAzMzcuanBlZ5GTBc0BHcyg" />Kreml bardzo ściśle cenzuruje działanie Rosjan w sieci. Pomagają w tym specjalne rozwiązania, jak stworzenie specjalnego bota służącego do przeczesywania Internetu i indeksowania stron oraz koncepcja wprowadzenia zamkniętej sieci tylko dla rosyjskich obywateli.

## Czy deweloperzy planują zwiększyć liczbę budowanych mieszkań?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9276373,czy-deweloperzy-planuja-zwiekszyc-liczbe-budowanych-mieszkan.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9276373,czy-deweloperzy-planuja-zwiekszyc-liczbe-budowanych-mieszkan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w46ktkuTURBXy8zYzM3MDQ4Mi0zMGZkLTRiMDItYjFmNS1iMzU0ZmQ2NjgyMzEuanBlZ5GTBc0BHcyg" />Czy firmy deweloperskie zamierzają zintensyfikować działalność i wprowadzić na rynek więcej mieszkań? Jakie projekty zaproponują w tym roku? Jakie znajdą się w nich mieszkania? W jakiej cenie? Sondę przygotował serwis nieruchomości dompress.pl.

## Ekonomiczne skutki kryzysu demograficznego
 - [https://forsal.pl/gospodarka/demografia/artykuly/9276205,ekonomiczne-skutki-kryzysu-demograficznego.html](https://forsal.pl/gospodarka/demografia/artykuly/9276205,ekonomiczne-skutki-kryzysu-demograficznego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oVfktkuTURBXy84MTBiNTZkYS03OWUyLTQ2MzEtYTI1NC1mZDk4NWJlZDU0YWEuanBlZ5GTBc0BHcyg" />Liczba ludności świata 15 listopada 2022 r. przekroczyła już 8 mld. Wzrost wydaje się błyskawiczny, jeśli zauważymy, że jeszcze w 2010 r. ludzi na świecie było jedynie 7 mld. Według szacunków światowa populacja będzie rosła przez znaczną część XXI w., lecz w coraz wolniejszym tempie. Wśród znawców tematu coraz częściej pojawia się przekonanie, że to spadek populacji, a nie jej wzrost będzie głównym problemem przyszłości. Także w aspekcie ekonomicznym.

## Dostosowanie stylu, długości i obiektywności odpowiedzi. Skorzystają wszyscy użytkownicy ChatGPT
 - [https://forsal.pl/lifestyle/technologie/artykuly/9275237,dostosowanie-stylu-dlugosci-i-obiektywnosci-odpowiedzi-skorzystaja-w.html](https://forsal.pl/lifestyle/technologie/artykuly/9275237,dostosowanie-stylu-dlugosci-i-obiektywnosci-odpowiedzi-skorzystaja-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-17T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LcQktkuTURBXy9lN2M1NzFmYi05MmE4LTQ1ZjgtODYwMy1kNmM3MDJmMjFhZjEuanBlZ5GTBc0BHcyg" />OpenAI, twórca narzędzi korzystających z technologii sztucznej inteligencji, ogłosił rozszerzenie funkcji &quot;Własne Instrukcje&quot; dla popularnego modelu językowego ChatGPT. Jak podaje firma, decyzja o poszerzeniu możliwości użytkowania narzędzia powstała w wyniku rozmów z użytkownikami z 22 krajów. Podczas nich zauważono, jak istotna jest możliwość sterowania oraz wykonywania niestandardowych próśb w celu skutecznego dostosowania odpowiedzi chatbota do różnorodnych kontekstów i potrzeb użytkowników.

