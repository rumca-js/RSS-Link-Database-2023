# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## Lindsey Stirling - Kashmir
 - [https://www.youtube.com/watch?v=1KDWTw41BxU](https://www.youtube.com/watch?v=1KDWTw41BxU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2023-08-17T00:45:19+00:00

Come see me on my Summer Tour with Walk Off The Earth! Tickets and VIP packages on sale now at http://www.lindseystirling.com/ 

CREDITS
Director: Navire Argo
Cameras: Nils Nicolet, Thibault Pailler, Emile Phelizot 

Donate to The Upside Fund: https://www.lindseystirling.com/theup...
Learn more about "Crystallize" Lindsey Stirling Signature Yamaha Violin https://found.ee/LS_Violin

Follow me here:
https://www.facebook.com/lindseystirl...
https://twitter.com/LindseyStirling
http://www.instagram.com/LindseyStirling
http://www.tiktok.com/@lindseystirling
http://www.lindseystirling.com

Sheet Music Here: https://lindseystirlingsheetmusic.com

Sign up for my super-cool newsletter here:
https://found.ee/lindsey_newsletter

#LindseyStirling #kashmir #LedZeppelin

