# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## The EU is Days Away From Dictating What People Can See Online
 - [https://reclaimthenet.org/the-eu-is-days-away-from-dictating-what-people-can-see-online](https://reclaimthenet.org/the-eu-is-days-away-from-dictating-what-people-can-see-online)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T19:11:58+00:00

<a href="https://reclaimthenet.org/the-eu-is-days-away-from-dictating-what-people-can-see-online" rel="nofollow" title="The EU is Days Away From Dictating What People Can See Online"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/eudsa.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Starting this month.</p>
<p>The post <a href="https://reclaimthenet.org/the-eu-is-days-away-from-dictating-what-people-can-see-online" rel="nofollow">The EU is Days Away From Dictating What People Can See Online</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Investigating State Attorneys General Collusion With Pro-Censorship Group
 - [https://reclaimthenet.org/investigating-state-attorneys-general-collusion-with-pro-censorship-group](https://reclaimthenet.org/investigating-state-attorneys-general-collusion-with-pro-censorship-group)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T18:49:58+00:00

<a href="https://reclaimthenet.org/investigating-state-attorneys-general-collusion-with-pro-censorship-group" rel="nofollow" title="Investigating State Attorneys General Collusion With Pro-Censorship Group"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/uk-censor-group.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Peeling back the layers.</p>
<p>The post <a href="https://reclaimthenet.org/investigating-state-attorneys-general-collusion-with-pro-censorship-group" rel="nofollow">Investigating State Attorneys General Collusion With Pro-Censorship Group</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## State Department Shares Heavily-Redacted Records About Shadowy Pro-Censorship Group
 - [https://reclaimthenet.org/dos-shares-heavily-redacted-records-about-pro-censorship-group](https://reclaimthenet.org/dos-shares-heavily-redacted-records-about-pro-censorship-group)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T18:06:45+00:00

<a href="https://reclaimthenet.org/dos-shares-heavily-redacted-records-about-pro-censorship-group" rel="nofollow" title="State Department Shares Heavily-Redacted Records About Shadowy Pro-Censorship Group"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/blinken908239.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Dragging its feet.</p>
<p>The post <a href="https://reclaimthenet.org/dos-shares-heavily-redacted-records-about-pro-censorship-group" rel="nofollow">State Department Shares Heavily-Redacted Records About Shadowy Pro-Censorship Group</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Minds Partners With Livepeer to Introduce Live-Streaming
 - [https://reclaimthenet.org/minds-partners-with-livepeer-to-introduce-live-streaming](https://reclaimthenet.org/minds-partners-with-livepeer-to-introduce-live-streaming)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T17:10:44+00:00

<a href="https://reclaimthenet.org/minds-partners-with-livepeer-to-introduce-live-streaming" rel="nofollow" title="Minds Partners With Livepeer to Introduce Live-Streaming"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/steam-on-minds.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A new feature for the private and free-speech focused social platform.</p>
<p>The post <a href="https://reclaimthenet.org/minds-partners-with-livepeer-to-introduce-live-streaming" rel="nofollow">Minds Partners With Livepeer to Introduce Live-Streaming</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## New York State Senator Wants Biometric Digital ID Scans For Alcohol and Tobacco Purchases
 - [https://reclaimthenet.org/new-york-state-senator-wants-biometric-digital-id](https://reclaimthenet.org/new-york-state-senator-wants-biometric-digital-id)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T16:18:12+00:00

<a href="https://reclaimthenet.org/new-york-state-senator-wants-biometric-digital-id" rel="nofollow" title="New York State Senator Wants Biometric Digital ID Scans For Alcohol and Tobacco Purchases"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/ny-bod.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The slippery slope.</p>
<p>The post <a href="https://reclaimthenet.org/new-york-state-senator-wants-biometric-digital-id" rel="nofollow">New York State Senator Wants Biometric Digital ID Scans For Alcohol and Tobacco Purchases</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Tennessee School That Suspended Student Over Memes Reverses Decision As First Amendment Lawsuit Progresses
 - [https://reclaimthenet.org/tennessee-school-that-suspended-student-over-memes-update](https://reclaimthenet.org/tennessee-school-that-suspended-student-over-memes-update)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-17T15:11:25+00:00

<a href="https://reclaimthenet.org/tennessee-school-that-suspended-student-over-memes-update" rel="nofollow" title="Tennessee School That Suspended Student Over Memes Reverses Decision As First Amendment Lawsuit Progresses"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/student-case.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The first win in the ongoing lawsuit.</p>
<p>The post <a href="https://reclaimthenet.org/tennessee-school-that-suspended-student-over-memes-update" rel="nofollow">Tennessee School That Suspended Student Over Memes Reverses Decision As First Amendment Lawsuit Progresses</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

