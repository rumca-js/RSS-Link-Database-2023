# Source:Eli the Computer Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ, language:en-US

## ChatGPT API Introduction
 - [https://www.youtube.com/watch?v=8X_GXJtV4o0](https://www.youtube.com/watch?v=8X_GXJtV4o0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCD4EOyXKjfDUhCI6jlOZZYQ
 - date published: 2023-08-17T21:09:56+00:00

Support Silicon Dojo at: https://donorbox.org/etcg
RSVP for Classes at: http://www.silicondojo.com
LinkedIN at: https://www.linkedin.com/in/eli-etherton-a15362211/

00:00 Introduction
07:17 Demonstration of ChatGPT and DALL E API
12:20 What is ChatGPT
25:33 Pricing and Requirements for OpenAI API
37:11 Explaining ChatGPT Python Code
50:31 Why ChatGPT API Matter for Coders
56:25 Final Thoughts

