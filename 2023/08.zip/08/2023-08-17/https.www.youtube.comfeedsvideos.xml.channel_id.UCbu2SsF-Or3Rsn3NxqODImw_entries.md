# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Call of Duty: Modern Warfare 3 - Shadow Siege Reveal Warzone Event
 - [https://www.youtube.com/watch?v=lytHY1oEK5U](https://www.youtube.com/watch?v=lytHY1oEK5U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-17T18:31:54+00:00

Phillip Graves is back from the dead to lead Shadow Company on an assault to recover chemical weapons. Players need to arm missile launchers, assault a secret underground complex, and extract. 
#gaming #gamespot #modernwarfare3 #warzone2 
00:00 - 01:57 Mission Briefing
01:57 - 07:42 Shadow Siege Event
07:42 - 10:44 Modern Warfare 3 Reveal Trailer

## Call of Duty: Modern Warfare III | Official Gameplay Reveal Trailer
 - [https://www.youtube.com/watch?v=pWY6Q3h5UA4](https://www.youtube.com/watch?v=pWY6Q3h5UA4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-17T18:01:18+00:00

A dark new chapter begins in Call of Duty: Modern Warfare III. Check out the official gameplay reveal that was showcased during an in game event in Call of Duty Warzone 2.0. 

Call of Duty: Modern Warfare 3 will include a blockbuster campaign with new open combat missions. The return of iconic multiplayer maps, and also the largest Call of Duty Zombies map ever!

Plus so much more. Ready up for #MW3 soldier!

## 20 Minutes Of Red Dead Redemption Nintendo Switch Gameplay
 - [https://www.youtube.com/watch?v=QRhvxdi9V-g](https://www.youtube.com/watch?v=QRhvxdi9V-g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-17T09:00:14+00:00

Check out 20 minutes from the early hours of Red Dead Redemption running on Nintendo Switch. 

Timestamps:
00:00 - Opening
01:43 - Armadillo
02:57 - Riding to Fort Mercer
07:02 - Horse Race on the Ranch
10:18 - Vista
10:58 - Meeting the Marshal
17:23 - Combat

#gaming #RedDeadRedemption #gamespot

