# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## In Trump’s Georgia Indictment, a Tale of Two Election Workers
 - [https://theintercept.com/2023/08/17/trump-indictment-georgia-election/](https://theintercept.com/2023/08/17/trump-indictment-georgia-election/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-08-17T18:09:01+00:00

<p>Ruby Freeman resisted Trump, while Misty Hampton embraced him. </p>
<p>The post <a href="https://theintercept.com/2023/08/17/trump-indictment-georgia-election/" rel="nofollow">In Trump’s Georgia Indictment, a Tale of Two Election Workers</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

