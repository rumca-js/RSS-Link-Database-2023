# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Open Bar #61 - Snow White Backlash, Disney's Financial Woes, Blue Beetle Set To Flop
 - [https://www.youtube.com/watch?v=-cV5IBrAG54](https://www.youtube.com/watch?v=-cV5IBrAG54)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-08-17T12:19:15+00:00

It seems Snow White star Rachel Zegler is in hot water as old interviews resurface, and the backlash shows no sign of letting up. Meanwhile massive problems loom on the horizon for Disney as the Hulu sale approaches. And the Blue Beetle director gets desperate, begging people to go see his movie. 

Subscribe to Little Platoon: https://www.youtube.com/watch?v=v0e9Bm2VcKg&amp;t=7461s
Subscribe to CAMELOT331: https://www.youtube.com/@CAMELOT331
Subscribe to Disparu: https://www.youtube.com/@disparutoo
Grab a MauLer vinyl figurine: https://www.makeship.com/products/mauler-vinyl-figure

