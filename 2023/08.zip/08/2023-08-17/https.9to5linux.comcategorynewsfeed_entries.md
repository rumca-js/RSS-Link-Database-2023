# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## OBS Studio 30.0 Promises Intel QSV Support on Linux, HDR Playback for DeckLink
 - [https://9to5linux.com/obs-studio-30-0-promises-intel-qsv-support-on-linux-hdr-playback-for-decklink](https://9to5linux.com/obs-studio-30-0-promises-intel-qsv-support-on-linux-hdr-playback-for-decklink)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-08-17T05:23:38+00:00

<p>OBS Studio 30.0 is now available for public beta testing with Intel QSV support on Linux, WHIP/WebRTC output, 10-bit capture and HDR playback support for DeckLink output, and more.</p>
<p>The post <a href="https://9to5linux.com/obs-studio-30-0-promises-intel-qsv-support-on-linux-hdr-playback-for-decklink" rel="nofollow">OBS Studio 30.0 Promises Intel QSV Support on Linux, HDR Playback for DeckLink</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

