# Source:Matt Rickard, URL:https://matt-rickard.com/rss, language:en-US

## Akin's Laws of Spacecraft Design
 - [https://matt-rickard.com/akins-law-of](https://matt-rickard.com/akins-law-of)
 - RSS feed: https://matt-rickard.com/rss
 - date published: 2023-08-17T13:30:29+00:00

I've been involved in spacecraft and space systems design and development for my entire career, including teaching the senior-level capstone spacecraft design course, for ten years at MIT and now at the University of Maryland for more than three decades. These are some bits of wisdom that I have gleaned during that time, some by picking up on the experience of others, but mostly by screwing up myself. I originally wrote these up and handed them out to my senior design class, as a strong hint on

## Akin's Laws of Spacecraft Design
 - [https://matt-rickard.com/akins-law-of-spacecraft-design](https://matt-rickard.com/akins-law-of-spacecraft-design)
 - RSS feed: https://matt-rickard.com/rss
 - date published: 2023-08-17T13:30:29+00:00

I've been involved in spacecraft and space systems design and development for my entire career, including teaching the senior-level capstone spacecraft design course, for ten years at MIT and now at the University of Maryland for more than three decades. These are some bits of wisdom that I have gleaned during that time, some by picking up on the experience of others, but mostly by screwing up myself. I originally wrote these up and handed them out to my senior design class, as a strong hint on

