# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Tragiczny wypadek na Mazowszu. Mężczyzna wpadł do kanału samochodowego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30091036,tragiczny-wypadek-na-mazowszu-mezczyzna-wpadl-do-kanalu-samochodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30091036,tragiczny-wypadek-na-mazowszu-mezczyzna-wpadl-do-kanalu-samochodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T20:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/27/b2/1c/z30091047M,Zdjecie-ilustracyjne.jpg" vspace="2" />Trwa wyjaśnianie okoliczności śmierci mężczyzny, który wpadł do kanału samochodowego. Do tragedii doszło w czwartek po południu we wsi Chrosna w woj. mazowieckim.

## Nawałnice przeszły nad Jelenią Górą. Zalane drogi i posesje. "Szykowane są worki z piaskiem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090791,nawalnice-przeszly-nad-jelenia-gora-zalane-drogi-i-posesje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090791,nawalnice-przeszly-nad-jelenia-gora-zalane-drogi-i-posesje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T19:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/b2/1c/z30090951M,W-Jeleniej-Gorze-zalane-sa-posesje-i-ulice.jpg" vspace="2" />Potężne ulewy przeszły nad Jelenią Górą, w wyniku czego gwałtownie podniósł się poziom wody w Radomierce. Ulice i gospodarstwa są zalane. "Szykowane są worki z piaskiem, by woda nie dostała się do domów mieszkańców" - napisał Jerzy Łużniak, prezydent Jeleniej Góry.

## Świętokrzyskie. Nad regionem przeszły gwałtowne burze. Nie żyje kobieta rażona piorunem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090817,swietokrzyskie-nad-regionem-przeszly-gwaltowne-burze-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090817,swietokrzyskie-nad-regionem-przeszly-gwaltowne-burze-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T19:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/49/b0/1c/z30083145M,Pogoda-na-dzis---czwartek--17-sierpnia--IMGW-ostrz.jpg" vspace="2" />W miejscowości Aleksandrów w powiecie jędrzejowskim w czasie czwartkowej burzy piorun prawdopodobnie uderzył w kobietę. Niestety mimo reanimacji poszkodowana zmarła. Służby ustalają okoliczności zdarzenia.

## Dzierżoniów. Policja apeluje o pomoc w poszukiwaniach. Chodzi o mężczyznę, który zaatakował kobietę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090754,dzierzoniow-policja-apeluje-o-pomoc-w-poszukiwaniach-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090754,dzierzoniow-policja-apeluje-o-pomoc-w-poszukiwaniach-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T18:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/b2/1c/z30090764M,Dzierzoniow--Policja-poszukuje-napastnika--ktory-z.jpg" vspace="2" />Policja z Dzierżoniowa apeluje o pomoc w poszukiwaniach mężczyzny, który 15 sierpnia zaatakował kobietę w miejskim parku. Funkcjonariusze opublikowali portret pamięciowy mężczyzny. Szczególnie cenne dla służb są informacje od osób, które posiadają w aucie wideorejestrator i tego dnia przejeżdżały w pobliżu miejsca zdarzenia.

## Zabójstwo w Radzionkowie. Prokuratura ujawnia nowe szczegóły. Co miało skłonić 19-latka do zbrodni?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090655,zabojstwo-w-radzionkowie-prokuratura-ujawnia-nowe-szczegoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090655,zabojstwo-w-radzionkowie-prokuratura-ujawnia-nowe-szczegoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T18:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ee/b2/1c/z30090734M,Zabojstwo-w-Radzionkowie--Prokuratura-ujawnia-nowe.jpg" vspace="2" />Prokuratura ujawniła nowe ustalenia w sprawie zabójstwa 18-letniej dziewczyny w Radzionkowie. Z informacji przekazanych mediom wynika, że podejrzanego do zbrodni mógł "skłonić wewnętrzny głos".

## W wypadku na Lubelszczyźnie zginęły trzy aktorki. Jechały na pogrzeb. Mieszkańcy żegnają kobiety
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090617,w-wypadku-na-lubelszczyznie-zginely-trzy-aktorki-jechaly-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090617,w-wypadku-na-lubelszczyznie-zginely-trzy-aktorki-jechaly-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T17:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/ae/1c/z30076727M,Wypadek-dwoch-samochodow--Nie-zyja-trzy-osoby.jpg" vspace="2" />W poniedziałek na obwodnicy Chodla na Lubelszczyźnie doszło do tragicznego wypadku. W zderzeniu dwóch samochodów zmarły trzy kobiety. Okazuje się, że to aktorki z poniatowskiej grupy teatralnej "Fajna Ferajna".

## Wypadek kolumny z Szydło. Wraca śledztwo ws. zbiórki na zakup seicento dla Sebastiana Kościelnika
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090335,wypadek-kolumny-z-szydlo-wraca-sledztwo-ws-zbiorki-na-zakup.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090335,wypadek-kolumny-z-szydlo-wraca-sledztwo-ws-zbiorki-na-zakup.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T16:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/18/1c/z29462423M,Sebastian-Koscielnik.jpg" vspace="2" />W 2017 roku samochód, który wiózł Beatę Szydło przez Oświęcim, zderzył się w fiatem seicento, którym poruszał się Sebastian Kościelnik. W sieci została założona zbiórka pieniędzy na zakup nowego auta dla mężczyzny. Zebrano w niej 140 tys. zł, jednak Kościelnik pieniędzy nigdy nie otrzymał, a organizator zrzutki zniknął. Teraz prokuratura ma wrócić do sprawy.

## Samochód wpadł do podziemnego przejścia w Poznaniu w trakcie burzy. 24-latek jest w ciężkim stanie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090234,samochod-wpadl-do-podziemnego-przejscia-w-poznaniu-24-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090234,samochod-wpadl-do-podziemnego-przejscia-w-poznaniu-24-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T15:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/b2/1c/z30090346M,W-Poznaniu-samochod-wpadl-do-podziemnego-przejscia.jpg" vspace="2" />Podczas silnej ulewy, która miała miejsce w Poznaniu, kierowca prawdopodobnie wpadł w poślizg i stracił panowanie nad pojazdem, po czym wjechał do podziemnego przejścia. Samochód dachował, a kierowca w ciężkim stanie został przewieziony do szpitala.

## Samochód uderzył w motocyklistę. Kierowca wyleciał w powietrze i zderzył się z autobusem [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30089123,samochod-uderzyl-w-motocykliste-kierowca-wylecial-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30089123,samochod-uderzyl-w-motocykliste-kierowca-wylecial-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T13:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/05/b2/1c/z30089477M,Wlynkowko--Motocyklista-uderzyl-w-autobus-i-wyleci.jpg" vspace="2" />Siła zderzenia była tak duża, że motocyklista wyleciał w powietrze. Kamera z samochodu, który był w pobliżu, zarejestrowała poniedziałkowy wypadek, który wydarzył się w miejscowości Włynkówko. Wstrząsające wideo trafiło do sieci. Policja wstępnie ustaliła, co było powodem zdarzenia.

## Na Mazurach roi się od os. W sierpniu jest ich mnóstwo. Ratownicy interweniują każdego dnia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085314,na-mazurach-roi-sie-od-os-w-sierpniu-jest-ich-mnostwo-ratownicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085314,na-mazurach-roi-sie-od-os-w-sierpniu-jest-ich-mnostwo-ratownicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T09:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/b1/1c/z30085727M,Jezioro-Rynskie--zdjecie-ilustracyjne-.jpg" vspace="2" />Mazurskie Ochotnicze Pogotowie Ratunkowe poinformowało o wysokiej liczbie przypadków użądlenia przez osy. Dyżurna pogotowia przekazała PAP informację, że w ciągu dnia otrzymują kilka wezwań do takich przypadków. W większości sytuacji użądlenie osy jest niegroźne i prowadzi wyłącznie do swędzenia i obrzęku. Osoby uczulone na jad os wymagają jednak jak najszybszego kontaktu z lekarzem.

## Śledztwo ws. koncertu Maty nad Wisłą. Jest decyzja prokuratury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30028200,sledztwo-ws-koncertu-maty-nad-wisla-jest-decyzja-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30028200,sledztwo-ws-koncertu-maty-nad-wisla-jest-decyzja-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T09:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/95/1b/z28922293M,Mata-Tour-Torun-.jpg" vspace="2" />Prokuratura Rejonowa Warszawa - Śródmieście umorzyła śledztwo ws. ubiegłegorocznego koncertu rapera Maty, który odbył się nad Wisłą - dowiedział się portal Gazeta.pl. Jak przekazał nam rzecznik Prokuratury Okręgowej, śledczy nie stwierdzili "znamion czynu zabronionego".

## Pogoda? Wysoka temperatura i gwałtowne burze. Kiedy skończy się upał? Nieprędko
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085135,pogoda-wysoka-temperatura-i-gwaltowne-burze-kiedy-skonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085135,pogoda-wysoka-temperatura-i-gwaltowne-burze-kiedy-skonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T07:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/b1/1c/z30085244M,Upaly-moga-nie-ustapic-do-konca-sierpnia.jpg" vspace="2" />Według ostatnich doniesień synoptyków ciut niższych temperatur możemy podziewać się podczas weekendu oraz na początku przyszłego tygodnia. Inne prognozy mówią o tym, że z męczącymi upałami będziemy mierzyć się aż do końca sierpnia. IMGW podtrzymuje ostrzeżenia przed wysokimi temperaturami w zachodniej Polsce. Ostrzega jednocześnie przed zbliżającymi się burzami.

## Lasy Państwowe przygotowały regulamin dla leśników. Na liście wymogów m.in. zakaz brody i makijażu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085131,lasy-panstwowe-przygotowaly-regulamin-dla-lesnikow-na-liscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085131,lasy-panstwowe-przygotowaly-regulamin-dla-lesnikow-na-liscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T07:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/b1/1c/z30085140M.jpg" vspace="2" />Internet obiegły zdjęcia nowego regulaminu przygotowanego przez Lasy Państwowe. Dokument zakazuje między innymi "ekstrawaganckich fryzur", "intensywnego makijażu", tatuaży i piercingu. W sieci zawrzało.

## Rośnie liczba ugryzień przez kleszcze. Jak się chronić i co zrobić w przypadku ukąszenia?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30082396,kleszcze-rosnie-liczba-ugryzien-i-powiklan-jak-sie-chronic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30082396,kleszcze-rosnie-liczba-ugryzien-i-powiklan-jak-sie-chronic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T05:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a3/b0/1c/z30084515M,Rosnie-liczba-ugryzien-kleszczy--zdjecie-ilustracy.jpg" vspace="2" />Sezon wakacyjny szczególnie sprzyja wędrówkom w lasach czy spacerach po parkach lub łąkach. Każda wyprawa w tereny z dużą ilością zieleni może jednak wiązać się z ryzykiem ugryzienia przez kleszcza. Dane opublikowane przez NFZ wskazują, że z roku na rok rośnie również liczba zachorowań na choroby odkleszczowe, które mogą mieć poważne powikłania. Czym może grozić ugryzienie i co mieć na uwadze?

## Potrącił 11-latkę na hulajnodze i odjechał, "bo mu się spieszy". Policja szuka świadków zajścia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30084678,potracil-11-latke-na-hulajnodze-i-odjechal-bo-mu-sie-spieszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30084678,potracil-11-latke-na-hulajnodze-i-odjechal-bo-mu-sie-spieszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-17T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/83/1c/z29897261M,Hulajnogi-elektryczne--zdjecie-ilustracyjne-.jpg" vspace="2" />W Płońsku doszło do potrącenia 11-latki podróżującej hulajnogą. Kierowca, który brał udział w zdarzeniu, odjechał z jego miejsca. Śledczy apelują do świadków zdarzenia o kontakt z komisariatem policji.

