# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## Bob Iger, Disney, Kickstarter campaign! Make Disney solvent again.
 - [https://www.youtube.com/watch?v=jEVtIWhY_K4](https://www.youtube.com/watch?v=jEVtIWhY_K4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2023-08-17T16:17:16+00:00

#FormerNetworkExec #CallMeChato #disney 
It looks like Disney is trying to use Kickstarter to dig itself out of its financial problems. Are you going to help?

Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

