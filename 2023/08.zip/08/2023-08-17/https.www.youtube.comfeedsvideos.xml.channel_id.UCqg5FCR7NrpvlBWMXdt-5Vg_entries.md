# Source:The Escapist, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg, language:en-US

## The Cosmic Wheel Sisterhood | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=-paKCagFFzs](https://www.youtube.com/watch?v=-paKCagFFzs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-08-17T21:00:00+00:00

Join our Patreon for a week of Early Access to all of our Premium video series including Zero Punctuation, Cold Take, Extra Punctuation, Adventure is Nigh and more! Just $2/month with a 7 day free trial. ►► https://www.patreon.com/the_escapist

Amy Campbell reviews The Cosmic Wheel Sisterhood, developed by Deconstructeam. 

The Cosmic Wheel Sisterhood on Steam: https://store.steampowered.com/app/1340480/The_Cosmic_Wheel_Sisterhood/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Blasphemous II | Review in 3 Minutes
 - [https://www.youtube.com/watch?v=Muvcd-w7FSU](https://www.youtube.com/watch?v=Muvcd-w7FSU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-08-17T17:00:13+00:00

Join our Patreon for a week of Early Access to all of our Premium video series including Zero Punctuation, Cold Take, Extra Punctuation, Adventure is Nigh and more! Just $2/month with a 7 day free trial. ►► https://www.patreon.com/the_escapist

Sebastian Ruiz reviews Blasphemous 2, developed by The Game Kitchen.

Blasphemous 2 on Steam: https://store.steampowered.com/app/2114740/Blasphemous_2/

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Revisiting Uncharted: Drake's Fortune with Nick and Frost - Part 3
 - [https://www.youtube.com/watch?v=H3PH2D8hWyE](https://www.youtube.com/watch?v=H3PH2D8hWyE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-08-17T15:53:56+00:00

We've wrapped up our Xbox 360 replays and are now moving onto PS3, starting with Uncharted! 

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Revisiting Portal 2 with KC & Marty - Part 2
 - [https://www.youtube.com/watch?v=6RRGpmszIEE](https://www.youtube.com/watch?v=6RRGpmszIEE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-08-17T15:24:04+00:00

With the Metal Gear series completed, KC and Marty are moving onto their next series playthrough... Half-Life and Portal.

Join our YouTube Membership program for Early Access to videos, badges, emojis, bonus content and more. ►► https://www.youtube.com/channel/UCqg5FCR7NrpvlBWMXdt-5Vg/join

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

Want to see the next episode a week early? Check out http://www.escapistmagazine.com for the latest episodes of your favorite shows.

---



---


Zero Punctuation Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/escapistmagazine 
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

## Blue Dragon: Xbox's Failed Attempt to Win Japan | Lost in Time
 - [https://www.youtube.com/watch?v=NHUiEgrMcOY](https://www.youtube.com/watch?v=NHUiEgrMcOY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCqg5FCR7NrpvlBWMXdt-5Vg
 - date published: 2023-08-17T15:00:15+00:00

Welcome to Lost in Time, a new every other week series here on The Escapist where we explore video games that were forgotten overtime but deserve to be remembered either as a hidden gem, a cultural impact, or a critical failure. 

Hosted by Colin Munch from The Escapist, this new series on The Escapist will air every other Thursday as Destructoid's first premium video essay series.

Join our Patreon for a week of Early Access to all of our Premium video series including Zero Punctuation, Cold Take, Extra Punctuation, Adventure is Nigh and more! Just $2/month with a 7 day free trial. ►► https://www.patreon.com/the_escapist

Join our growing Discord community: https://discord.gg/A6T2gKrDwB

Subscribe to Escapist Magazine! ►► http://bit.ly/Sub2Escapist

---



---

The Escapist Merch Store ►►https://teespring.com/stores/the-escapist-store
Join us on Twitch ►► https://www.twitch.tv/the_escapist_official
Like us on Facebook ►► http://www.facebook.com/EscapistMag
Follow us on Twitter ►► https://twitter.com/EscapistMag

