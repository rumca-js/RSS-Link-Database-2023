# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## The Official Podcast #350: Game Dev Hard
 - [https://www.youtube.com/watch?v=8I33FkCLiSQ](https://www.youtube.com/watch?v=8I33FkCLiSQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-08-17T18:15:00+00:00

Four close man friends gather around to talk about game development.

This is the Official Podcast. Links Below.

---

Get additional episodes and bonus content with early access:
go to https://www.PATREON.com/THEOFFICIALPODCAST

Brought to you by the following sponsors:

VISIT ADAM AND EVE AND RECEIVE 50% OFF 1 ITEM AND FREE SHIPPING (18+ ONLY):
go to https://www.ADAMANDEVE.com and use code DEFENSE

VISIT HELIXSLEEP AND GET 20% OFF AND TWO FREE PILLOWS:
go to https://www.HELIXSLEEP.com/OFFICIAL

GET GODSLAP AND PLAGUE SEEKER RIGHT NOW:
go to https://www.BADEGG.co

---

Timestamps:

00:00 Intro
02:29 Overwatch 2 (and other flops on Steam)
07:35 Baldur’s Gate 3 is “Too Good”
16:50 Starfield/Bethesda
22:55 Do Animals Form Opinions?
25:13 Adam & Eve
27:13 Helix Sleep
29:17 Do Animals Form Opinions? (continued)
31:25 Starfield/Bethesda (continued)
37:04 Game of the Year Predictions
39:19 Nintendo & Development Hell
42:13 Have You Ever Seen a Dead Body?
44:59 Were There More Killers 50 Years Ago?
47:04 The Mushroom Killer
53:10 Anti-Criminal Technology
55:37 The Fear of 13
57:42 Make-A-Wish Murder
1:06:09 Stealing
1:10:59 High Fashion is a Scam
1:15:31 Zuck vs. Musk
1:28:39 Billion Dollar Porno
---

Hosts: 

Jackson: https://twitter.com/zealotonpc 
Andrew: https://twitter.com/huggbeestv 
Charlie: https://twitter.com/moistcr1tikal 
Kaya: https://twitter.com/kayaorsan

---

The Official Podcast Links: 

SubReddit: https://reddit.com/r/theofficialpodcast 
Google Play: https://play.google.com/music/m/Iv4af6j46ldkjja7vwnvljbyiw4?t=The_Official_Podcast 
Google Podcasts: https://www.google.com/podcasts?feed=aHR0cHM6Ly9mZWVkcy5tZWdhcGhvbmUuZm0vVE9QNzc4NDYyNTk4MA%3D%3D 
Spotify: https://open.spotify.com/show/6TXzjtMTEopiGjIsCfvv6W 
iTunes: https://itunes.apple.com/au/podcast/the-official-podcast/id1186089636 
Patreon: https://www.patreon.com/theofficialpodcast
Intro by: https://www.youtube.com/c/Derpmii
Music by: https://soundcloud.com/inst1nctive
Thumbnail by: https://www.instagram.com/nook_eilyk/
Edited by: https://www.instagram.com/00zaya

## Big day
 - [https://www.youtube.com/watch?v=GPATi3HbWnk](https://www.youtube.com/watch?v=GPATi3HbWnk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-08-17T05:47:30+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

## Big day
 - [https://www.youtube.com/watch?v=GZJ_vUoahBI](https://www.youtube.com/watch?v=GZJ_vUoahBI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-08-17T01:36:22+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

## IShowSpeed Situation is Crazy
 - [https://www.youtube.com/watch?v=85WgO428JVI](https://www.youtube.com/watch?v=85WgO428JVI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-08-17T00:15:01+00:00

This is the greatest stream mistake of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/

