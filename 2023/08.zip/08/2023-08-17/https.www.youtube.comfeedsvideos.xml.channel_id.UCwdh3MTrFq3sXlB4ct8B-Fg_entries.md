# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## How to Paint: Cities of Sigmar - Greywater Fastness Cloth & Shield
 - [https://www.youtube.com/watch?v=L05H44k8j0I](https://www.youtube.com/watch?v=L05H44k8j0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-17T15:00:49+00:00

Greywater Fastness is an ambitious stronghold in the swamps of Ghyran, its soldiers clad in wrought iron and marching with artillery support. In this video we'll be showing you how to quickly and easily paint the industrial yellow uniforms of troops from Greywater Fastness, to get your soldiers ready for battle in no time.  
       
If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Loremasters: Titans | Warhammer+ #shorts
 - [https://www.youtube.com/watch?v=ehaaRP_NxrU](https://www.youtube.com/watch?v=ehaaRP_NxrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-17T11:15:03+00:00

Learn about Titans! Watch the full episode of Loremasters on Warhammer+: https://bit.ly/47CUYQX

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial
- Instagram: https://www.instagram.com/warhammerofficial
- Warhammer Community: https://www.warhammer-community.com/ 

#shorts

## How to Paint: Cities of Sigmar - Settler's Gain Cloth & Shield
 - [https://www.youtube.com/watch?v=yjrm-RcnR2g](https://www.youtube.com/watch?v=yjrm-RcnR2g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-17T11:00:56+00:00

Settler's Gain is Sigmar's foremost fortress-city in the Realm of Light, closely aligned to its Lumineth patrons. Follow along with this video step-by-step and learn how to easily paint the crisp uniforms of troops from Settler's Gain, getting your soldiers ready for battle in no time.         

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## How to Paint: Cities of Sigmar - Hammerhal Ghyra Cloth & Shield
 - [https://www.youtube.com/watch?v=4wAAMU4OIM8](https://www.youtube.com/watch?v=4wAAMU4OIM8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-17T10:01:00+00:00

Hammerhal Ghyra stands proud in the Realm of Life, one half of the Twin-tailed City. The city's hard-bitten soldiers wear the uniform and heraldry of Hammerhal Ghyra with quiet pride. Follow this step-by-step guide to learn how to paint the earthy colours of Hammerhal Ghyra quickly and easily, so they'll be ready to charge into battle in no time.         

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

