# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## FirstFT: US abandons push for anti-whaling in Indo-Pacific pact
 - [https://www.ft.com/content/e37b1813-d2c1-420f-9eb0-ab2a2550be91](https://www.ft.com/content/e37b1813-d2c1-420f-9eb0-ab2a2550be91)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T21:58:50+00:00

Also in today’s newsletter, foreign investors dump China securities and ex-Google researchers pick Japan for AI start-up

## Councils in England pressed to allow pubs to open early for World Cup final
 - [https://www.ft.com/content/9d4a894c-882e-4aed-aea4-14af8b8d5de3](https://www.ft.com/content/9d4a894c-882e-4aed-aea4-14af8b8d5de3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T21:52:09+00:00

Lionesses’ Sunday morning clash with Spain means licensing extensions should be fast-tracked, says Gove

## Give public and business cash services within 3 miles or be fined, UK banks told
 - [https://www.ft.com/content/0d561374-7ac7-487d-b1eb-9d4284acd68b](https://www.ft.com/content/0d561374-7ac7-487d-b1eb-9d4284acd68b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T21:33:13+00:00

Campaigners bemoan lack of detail in new government plans to boost access to deposits and withdrawals

## Labour rows back on workers’ rights to blunt Tory ‘anti-business’ claims
 - [https://www.ft.com/content/30a8a3f1-c5ad-4b85-bb48-7b7de05470f4](https://www.ft.com/content/30a8a3f1-c5ad-4b85-bb48-7b7de05470f4)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T20:00:11+00:00

Starmer dilutes pledge to boost protections for gig economy as party focuses on winning over Britain’s corporate leaders

## Jonathan Van-Tam takes role at vaccine maker Moderna
 - [https://www.ft.com/content/a3d3e076-7d83-4e6f-ab88-52b3b4043e7c](https://www.ft.com/content/a3d3e076-7d83-4e6f-ab88-52b3b4043e7c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T19:14:05+00:00

Prominent figure in UK pandemic response becomes medical consultant at pharma group

## UK taxes: give us your views
 - [https://www.ft.com/content/d266dd69-c680-40e8-a96e-b1a875522dbd](https://www.ft.com/content/d266dd69-c680-40e8-a96e-b1a875522dbd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T17:34:25+00:00

Are you concerned about future policies as the general election looms?

## Hawaiian Electric/wildfires: old business models are no longer viable
 - [https://www.ft.com/content/dce5c8b1-0429-4b80-a7aa-ba2c7e0418f2](https://www.ft.com/content/dce5c8b1-0429-4b80-a7aa-ba2c7e0418f2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T17:10:28+00:00

Climate disasters were previously events utilities could withstand

## US drops effort to include anti-whaling language in Indo-Pacific pact
 - [https://www.ft.com/content/6001502a-9c0e-4d7e-bfa3-bb49387f254b](https://www.ft.com/content/6001502a-9c0e-4d7e-bfa3-bb49387f254b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T16:38:19+00:00

Move comes after Japan threatened to pull out of 14-nation economic deal

## EU plans to fine importers if they fail to report emissions
 - [https://www.ft.com/content/9f9e4cdd-a9f5-4d81-b722-82cc3f74e214](https://www.ft.com/content/9f9e4cdd-a9f5-4d81-b722-82cc3f74e214)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T16:35:54+00:00

Trial phase of world’s first carbon border tax will feature penalties of up to €50 a tonne

## Technology stocks suffer as real yields hit 14-year high
 - [https://www.ft.com/content/364907e7-5449-4078-833c-a9ec5c0ffd9c](https://www.ft.com/content/364907e7-5449-4078-833c-a9ec5c0ffd9c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T16:21:35+00:00

Rates make sector less attractive and weigh on indebted companies

## Scottish by-election highlights Labour and SNP differences over Brexit
 - [https://www.ft.com/content/b73bc0dc-1870-4c6b-9d5f-7ebf05b038e5](https://www.ft.com/content/b73bc0dc-1870-4c6b-9d5f-7ebf05b038e5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T16:00:49+00:00

Also in this newsletter, Scotland’s budget deficit is flattered by North Sea oil revenues

## Walmart sales rise as inflation keeps consumers hunting for bargains
 - [https://www.ft.com/content/fcac24ea-66ad-4366-97c1-ef3bbb614759](https://www.ft.com/content/fcac24ea-66ad-4366-97c1-ef3bbb614759)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T14:21:44+00:00

US retailer’s chief says ‘pockets of disinflation’ are helping customers but rising fuel and borrowing costs present risks

## Falling birth rate highlights UK’s demographic challenges
 - [https://www.ft.com/content/378253f2-a7a6-4c2d-a9e9-aa228f6ad547](https://www.ft.com/content/378253f2-a7a6-4c2d-a9e9-aa228f6ad547)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T14:18:41+00:00

Number of live births in England and Wales last year was lowest since 2002

## The perils of long-term forecasts — GMO edition
 - [https://www.ft.com/content/d119e20b-599b-49de-bb85-8f34a6f678dd](https://www.ft.com/content/d119e20b-599b-49de-bb85-8f34a6f678dd)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T14:00:49+00:00

Find someone who loves you like GMO loves EM value

## UK corporate profitability remains stable despite ‘greedflation’ claims
 - [https://www.ft.com/content/dd7a2607-6cbd-474b-bd4a-a879a4e81fd7](https://www.ft.com/content/dd7a2607-6cbd-474b-bd4a-a879a4e81fd7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T11:46:24+00:00

Official data for first 3 months of 2023 supports Bank of England’s view that profit margins not pushing up inflation

## TV chat-show host Michael Parkinson dies aged 88
 - [https://www.ft.com/content/04fe7584-5c79-4bf1-a2d8-bb72b034f7be](https://www.ft.com/content/04fe7584-5c79-4bf1-a2d8-bb72b034f7be)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T11:25:40+00:00

Popular presenter said he interviewed more than 2,000 people in career that spanned seven decades

## The EU is doing more — lots more
 - [https://www.ft.com/content/f0866993-c91e-4c66-bfe3-0d4cb5dd8c7f](https://www.ft.com/content/f0866993-c91e-4c66-bfe3-0d4cb5dd8c7f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T11:00:51+00:00

Contrary to some expectations, the forces of change in Europe have been centripetal rather than centrifugal

## The impact of the Inflation Reduction Act, one year on
 - [https://www.ft.com/content/6f83ed81-28a5-46e9-98c4-a2bcf3d5b9fc](https://www.ft.com/content/6f83ed81-28a5-46e9-98c4-a2bcf3d5b9fc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T11:00:51+00:00

Also in today’s newsletter, a look at the widening global oil supply deficit

## China smartphones: demand for long life handsets shrinks the market
 - [https://www.ft.com/content/49eeec13-9abf-4a91-9627-8d328597ecce](https://www.ft.com/content/49eeec13-9abf-4a91-9627-8d328597ecce)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T10:59:39+00:00

Better build quality of premium devices means they last longer and require replacement less often

## Is there any real prospect of negotiations between Russia and Ukraine?
 - [https://www.ft.com/content/d7ba0831-eed3-49d2-a017-b324a1122970](https://www.ft.com/content/d7ba0831-eed3-49d2-a017-b324a1122970)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T10:00:50+00:00

For Moscow, accepting Zelenskyy’s peace plan would be an unconditional surrender. But Kyiv needs security guarantees

## Paris embraces see-through clothes
 - [https://www.ft.com/content/687e1c00-5898-422d-a1e3-f8dca3391a03](https://www.ft.com/content/687e1c00-5898-422d-a1e3-f8dca3391a03)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T10:00:50+00:00

Semi-sheer garments have been a runway regular that seldom trickles down to street level — but in the French capital and on the red carpet, that’s changing

## Debt overhang economics with Chinese characteristics
 - [https://www.ft.com/content/f3476ac1-825d-45ee-8e58-281f921f2c78](https://www.ft.com/content/f3476ac1-825d-45ee-8e58-281f921f2c78)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T09:45:49+00:00

Beijing should avoid the mistakes the west makes again and again — but it probably won’t

## UK exam boards make sharp cuts to top A-level grades
 - [https://www.ft.com/content/7ec50f2a-735a-4f15-a5b8-60d5962408db](https://www.ft.com/content/7ec50f2a-735a-4f15-a5b8-60d5962408db)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T08:36:29+00:00

Return to pre-pandemic marking causes A and A* grades to fall to 27.2% of total, down 9 percentage points

## Why Sunak’s silly inflation target matters
 - [https://www.ft.com/content/8b0ee199-7c3e-4102-8479-0deb1e28dcc1](https://www.ft.com/content/8b0ee199-7c3e-4102-8479-0deb1e28dcc1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T08:30:20+00:00

Voters’ expectations for deflation mean the government will face continued anger

## China’s high hopes for AI and Vietnam’s new net clampdown
 - [https://www.ft.com/content/f54cb581-89d6-4423-8a78-da220ad7537d](https://www.ft.com/content/f54cb581-89d6-4423-8a78-da220ad7537d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T07:17:49+00:00

The inside story on the Asia tech trends that matter, from Nikkei Asia and the Financial Times

## New pain for China’s property sector
 - [https://www.ft.com/content/d22fc816-3545-4d12-bcf9-2c4f6e3de1f6](https://www.ft.com/content/d22fc816-3545-4d12-bcf9-2c4f6e3de1f6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:33+00:00

UK inflation slows to 6.8% in July as energy prices fall

## Sanctions, global terror and the drugs trade
 - [https://www.ft.com/content/43161a45-1fcf-48cb-a549-4f52e937e947](https://www.ft.com/content/43161a45-1fcf-48cb-a549-4f52e937e947)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:22+00:00

How geopolitics has blurred the lines between criminal enterprise and the state

## An afternoon on the Hollywood picket line
 - [https://www.ft.com/content/0538af2d-54db-41f8-8368-8eb7e67619ba](https://www.ft.com/content/0538af2d-54db-41f8-8368-8eb7e67619ba)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

‘Millionaires on strike’ is how some describe the standstill that has gripped Los Angeles. But the calls for action aren’t for the stars, they’re for jobbing writers and actors struggling to stay afloat

## EY warns UK staff over pay as it trims jobs
 - [https://www.ft.com/content/4cb67fd6-e92d-4417-83cb-465afc6bccc5](https://www.ft.com/content/4cb67fd6-e92d-4417-83cb-465afc6bccc5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

Big Four accounting firm has been hit by slowdown in demand for some services

## Military briefing: Russia hunts Ukraine’s western missile stocks
 - [https://www.ft.com/content/e6406478-5b30-4178-b118-4790797d8446](https://www.ft.com/content/e6406478-5b30-4178-b118-4790797d8446)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

British Storm Shadows and French Scalps have helped Kyiv in its counteroffensive, but more are needed

## Missed payments spark alarm over China’s $3tn shadow financing industry
 - [https://www.ft.com/content/d150a3c9-4d0b-4d46-b856-153a253d9dbc](https://www.ft.com/content/d150a3c9-4d0b-4d46-b856-153a253d9dbc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

Finance giant’s missed payments to investors fuel concerns of spillover effect from property sector slowdown

## Spain resumes efforts to form government after summer lull
 - [https://www.ft.com/content/85371de1-5b58-46ed-a0c3-a944bd7f3964](https://www.ft.com/content/85371de1-5b58-46ed-a0c3-a944bd7f3964)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

Congress reconvenes with Pedro Sánchez seeking to stay on as premier

## The shadowy NGO accused of manipulating Zimbabwe election process
 - [https://www.ft.com/content/b66cae06-a0da-4dbf-ae69-d91a40e69c89](https://www.ft.com/content/b66cae06-a0da-4dbf-ae69-d91a40e69c89)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

Forever Associates Zimbabwe is at the centre of vote rigging allegations aimed at keeping Emmerson Mnangagwa in power

## UK investors put £50bn into global equity at expense of regional funds
 - [https://www.ft.com/content/6b6f3600-a248-4ea6-b4f5-bb27980046ed](https://www.ft.com/content/6b6f3600-a248-4ea6-b4f5-bb27980046ed)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:21+00:00

Data reveals investors’ continuing doubts over the performance of UK stocks

## Invisible Lines — the hidden borders that really divide the world
 - [https://www.ft.com/content/5b023331-a68e-4ad8-8390-032c39c753cf](https://www.ft.com/content/5b023331-a68e-4ad8-8390-032c39c753cf)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

Unseen boundaries are the ones with the most life-changing consequences, argues Maxim Samson’s illuminating collection of case studies

## Iran grapples with unintended consequences of ultra-cheap petrol
 - [https://www.ft.com/content/455db440-8e84-46ed-8abb-3a55f62ccd5a](https://www.ft.com/content/455db440-8e84-46ed-8abb-3a55f62ccd5a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

Authorities under pressure to remove expensive subsidies that keep fuel costs as low as $0.03 a litre

## Lex in depth: how investors are underpricing climate risks
 - [https://www.ft.com/content/899472a8-e5e2-4fde-bc91-7e548ba35294](https://www.ft.com/content/899472a8-e5e2-4fde-bc91-7e548ba35294)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

The costs of inaction on global warming are potentially vast and often not sufficiently factored in to asset values

## Mainland investors help ETFs grab record share of Hong Kong trading
 - [https://www.ft.com/content/3940a37c-bf83-422a-a311-7f4f16eb9596](https://www.ft.com/content/3940a37c-bf83-422a-a311-7f4f16eb9596)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

ETF Connect scheme boosts Chinese participation despite falling Hong Kong stock trading

## NHS capital investment cuts leave England’s hospitals crumbling
 - [https://www.ft.com/content/eff98439-44ba-43a3-b9af-3ce796002c24](https://www.ft.com/content/eff98439-44ba-43a3-b9af-3ce796002c24)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

St Mary’s in London is an example of how a longtime lack of spending is being felt across the system

## Scandal-hit children’s care homes up for sale by private equity owner
 - [https://www.ft.com/content/f8e0b493-020d-426f-b60f-64443e47878a](https://www.ft.com/content/f8e0b493-020d-426f-b60f-64443e47878a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

UK authorities found young people at three Hesley establishments were subjected to abuse and neglect

## The joy and the value of venturing into other worlds
 - [https://www.ft.com/content/df2da3f8-c133-4962-aaf3-8589e121cba2](https://www.ft.com/content/df2da3f8-c133-4962-aaf3-8589e121cba2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

Holidays offer an opportunity to take us outside our own filter bubbles

## Will the rest of the world feel China’s deflation pain?
 - [https://www.ft.com/content/ceee0338-e7bd-4a25-9412-7391b079301d](https://www.ft.com/content/ceee0338-e7bd-4a25-9412-7391b079301d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T04:00:20+00:00

Falling prices will lower cost of imports but are unlikely to have a dramatic impact elsewhere

## Global investors dump Chinese securities as state support hopes fade
 - [https://www.ft.com/content/5b4e0042-49c0-463c-b679-e97de96de12d](https://www.ft.com/content/5b4e0042-49c0-463c-b679-e97de96de12d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-08-17T00:30:19+00:00

Reversal of flows reflects crumbling confidence in promises made by party leaders

