# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## Driverless Car Gets Stuck in Wet Concrete in San Francisco
 - [https://www.nytimes.com/2023/08/17/us/driverless-car-accident-sf.html](https://www.nytimes.com/2023/08/17/us/driverless-car-accident-sf.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-17T09:27:36+00:00

Though driverless cars have not been blamed for any serious injuries or crashes in the city, they have been involved in several jarring episodes.

## YouTube Ads May Have Led to Online Tracking of Children, Research Says
 - [https://www.nytimes.com/2023/08/17/technology/youtube-google-children-privacy.html](https://www.nytimes.com/2023/08/17/technology/youtube-google-children-privacy.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-17T09:00:40+00:00

YouTube’s advertising practices on kids’ channels could have resulted in companies tracking children across the web, a report said.

## Can’t Hear the Dialogue in Your Streaming Show? You’re Not Alone.
 - [https://www.nytimes.com/2023/08/17/technology/personaltech/subtitles-streaming-shows-speech-enhancers.html](https://www.nytimes.com/2023/08/17/technology/personaltech/subtitles-streaming-shows-speech-enhancers.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-17T07:00:03+00:00

Many of us stream shows and movies with the subtitles on all the time — and not because it’s cool.

