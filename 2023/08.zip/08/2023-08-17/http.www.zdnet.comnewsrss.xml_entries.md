# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## This new ZAGG stylus is a cheaper, more colorful Apple Pencil alternative
 - [https://www.zdnet.com/article/this-new-zagg-stylus-is-a-cheaper-more-colorful-apple-pencil-alternative/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-new-zagg-stylus-is-a-cheaper-more-colorful-apple-pencil-alternative/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T20:23:25+00:00

iPad owners looking to save money could bypass the Apple Pencil and get the ZAGG Pro Stylus 2 instead.

## Grab these Adobe Photoshop alternatives for just $13 at Newegg
 - [https://www.zdnet.com/article/nab-these-adobe-alternatives-for-just-13-at-newegg/#ftag=RSSbaffb68](https://www.zdnet.com/article/nab-these-adobe-alternatives-for-just-13-at-newegg/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T20:19:09+00:00

Looking for an alternative to Adobe Creative Cloud? Corel PaintShop Pro and AfterShot Pro 3 let you sketch, paint, and edit photos just like in Photoshop and Lightroom, for way less money.

## New York City just banned TikTok on government devices. Here's why
 - [https://www.zdnet.com/article/new-york-city-banned-tiktok-on-government-devices-heres-why/#ftag=RSSbaffb68](https://www.zdnet.com/article/new-york-city-banned-tiktok-on-government-devices-heres-why/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T20:14:57+00:00

New York City government officials announced that city employees have 30 days to delete TikTok from city-owned devices.

## Learn how to create a ChatGPT AI bot with this course bundle
 - [https://www.zdnet.com/article/learn-how-to-create-a-chatgpt-ai-bot-with-this-course-bundle/#ftag=RSSbaffb68](https://www.zdnet.com/article/learn-how-to-create-a-chatgpt-ai-bot-with-this-course-bundle/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T20:11:30+00:00

Upgrade your AI skills with this ChatGPT and Python coding bundle deal.

## This simple trick disables ads in Gmail - but there's a catch
 - [https://www.zdnet.com/home-and-office/work-life/this-simple-trick-disables-ads-in-gmail-but-theres-a-catch/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/this-simple-trick-disables-ads-in-gmail-but-theres-a-catch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T18:48:39+00:00

If you depend on Gmail for your email communication, but you're tired of seeing ads in your inbox, there's a simple way to get rid of them, though it may mean swapping one problem for another.

## The best headphones of 2023: Expert reviewed and compared
 - [https://www.zdnet.com/article/best-headphones/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-headphones/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T17:18:47+00:00

These top headphones turn your ordinary music- or podcast-listening sessions into surround sound experiences.

## This 4-in-1 charging cable from Nomad means I'm never without the right cable
 - [https://www.zdnet.com/home-and-office/this-4-in-1-charging-cable-from-nomad-means-im-never-without-the-right-cable/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-4-in-1-charging-cable-from-nomad-means-im-never-without-the-right-cable/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T16:56:07+00:00

Nomad's 'universal' cable is also covered in double-braided Kevlar for extra durability.

## LG just rolled out a $1,000 briefcase TV, and it's weirdly compelling
 - [https://www.zdnet.com/home-and-office/home-entertainment/lg-just-rolled-out-a-1000-briefcase-tv-and-its-weirdly-compelling/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/lg-just-rolled-out-a-1000-briefcase-tv-and-its-weirdly-compelling/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T15:45:16+00:00

Who hasn't wanted to take their TV outside occasionally?

## New CrossOver 23 out for better Windows gameplay on MacOS, ChromeOS, and Linux
 - [https://www.zdnet.com/article/new-crossover-23-out-for-better-windows-gameplay-on-macos-chromeos-and-linux/#ftag=RSSbaffb68](https://www.zdnet.com/article/new-crossover-23-out-for-better-windows-gameplay-on-macos-chromeos-and-linux/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T15:24:14+00:00

For when you really, really need to run a Windows program, but you really, really can't stand Windows.

## Google paves way for FIDO2 security keys that can resist quantum computer attacks
 - [https://www.zdnet.com/article/google-paves-way-for-fido2-security-keys-that-can-resist-quantum-computer-attacks/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-paves-way-for-fido2-security-keys-that-can-resist-quantum-computer-attacks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T15:00:52+00:00

Google wants your security keys to be up for the challenges that quantum computers will present.

## The great Flipper Zero shortage of 2023 has finally come to end
 - [https://www.zdnet.com/article/the-great-flipper-zero-shortage-of-2023-has-finally-come-to-end/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-great-flipper-zero-shortage-of-2023-has-finally-come-to-end/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T14:01:26+00:00

I like everything about the Flipper Zero, except the way it was always out of stock, pushing buyers to overpriced third-party sellers.

## Otter.ai partners with Slack to share meeting insights with your team
 - [https://www.zdnet.com/article/otter-ai-partners-with-slack-to-share-meeting-insights-with-your-team/#ftag=RSSbaffb68](https://www.zdnet.com/article/otter-ai-partners-with-slack-to-share-meeting-insights-with-your-team/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T14:00:27+00:00

The new application can take notes, assign action items, share insights, and more.

## Banks defending their right to security are missing the point about consumer trust
 - [https://www.zdnet.com/article/banks-defending-their-right-to-security-are-missing-the-point-about-consumer-trust/#ftag=RSSbaffb68](https://www.zdnet.com/article/banks-defending-their-right-to-security-are-missing-the-point-about-consumer-trust/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-17T08:58:00+00:00

When businesses overwrite a customer's security decision, does it make them fully liable when a breach occurs? That's a question banks like those in Singapore need to consider before they roll out their next security feature.

