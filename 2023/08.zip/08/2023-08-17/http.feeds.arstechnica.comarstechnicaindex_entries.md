# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## End of the road: The Xbox 360 game marketplace will shut down
 - [https://arstechnica.com/?p=1961603](https://arstechnica.com/?p=1961603)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T21:20:25+00:00

Players will still be able to download previously purchased games.

## Western Digital, SanDisk Extreme SSDs don’t store data safely, lawsuit says
 - [https://arstechnica.com/?p=1961557](https://arstechnica.com/?p=1961557)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T21:04:04+00:00

The suit is seeking class-action certification.

## Heavy, highly magnetic star may be first magnetar precursor we’ve seen
 - [https://arstechnica.com/?p=1961639](https://arstechnica.com/?p=1961639)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T20:36:19+00:00

A strange history has produced a helium-rich star with kilogauss magnetic fields.

## Microsoft AI suggests food bank as a “cannot miss” tourist spot in Canada
 - [https://arstechnica.com/?p=1961606](https://arstechnica.com/?p=1961606)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T20:14:17+00:00

AI-penned Microsoft Travel article recommends food bank as if it were a famous restaurant.

## Mars keeps spinning faster every year, NASA InSight data says
 - [https://arstechnica.com/?p=1961299](https://arstechnica.com/?p=1961299)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T20:03:23+00:00

Radio signals from the lander help us track Mars' spin as it slowly shifts.

## Buyers of Bored Ape NFTs sue after digital apes turn out to be bad investment
 - [https://arstechnica.com/?p=1961571](https://arstechnica.com/?p=1961571)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T18:59:31+00:00

Lawsuit: Sotheby's $24M sale to FTX gave Bored Ape NFTs "an air of legitimacy."

## Dealmaster: Early Labor Day deals on laptops, smartphones, and more
 - [https://arstechnica.com/?p=1961469](https://arstechnica.com/?p=1961469)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T18:35:45+00:00

Early Labor Day sales bring terrific savings on some of our tech favorites.

## Can coffee or a nap make up for sleep deprivation?
 - [https://arstechnica.com/?p=1961562](https://arstechnica.com/?p=1961562)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T18:06:57+00:00

Lack of sleep harms memory and cognition, but our easy remedies can't fix everything.

## Report: Potential NYT lawsuit could force OpenAI to wipe ChatGPT and start over
 - [https://arstechnica.com/?p=1961547](https://arstechnica.com/?p=1961547)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T17:41:49+00:00

OpenAI could be fined up to $150,000 for each piece of infringing content.

## Acura unveils its first GM-based electric vehicle, the new ZDX
 - [https://arstechnica.com/?p=1961507](https://arstechnica.com/?p=1961507)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T16:00:42+00:00

This new electric SUV shares a lot with the Cadillac Lyriq.

## Lenovo’s answer to Steam Deck, Legion Go, sports Switch-like detachable controls
 - [https://arstechnica.com/?p=1961506](https://arstechnica.com/?p=1961506)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T14:08:26+00:00

Product shots also show off kickstand, large 8" screen, and tons of buttons.

## Want to have your genes tested? It might be genetic
 - [https://arstechnica.com/?p=1961319](https://arstechnica.com/?p=1961319)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-17T13:38:01+00:00

People in a genetic database have segments of DNA in common unexpectedly often.

