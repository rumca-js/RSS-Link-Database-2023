# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## David Harbour Talks Stranger Things End and Creature Commandos Future
 - [https://gizmodo.com/david-harbour-stranger-things-end-dc-creature-commandos-1850750060](https://gizmodo.com/david-harbour-stranger-things-end-dc-creature-commandos-1850750060)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T23:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--f4cHYaa9--/c_fit,fl_progressive,q_80,w_636/26fd37c4544f5628571caeb75909795b.png" /><p>In a previously recorded appearance on Josh Horowitz’s podcast Happy Sad Confused promoting <em>Gran Tourismo, </em>the film’s star David Harbour discussed the <a href="https://gizmodo.com/universal-studios-horror-nights-stranger-things-netflix-1850636341"><em>Stranger Things</em></a> finale and joining James Gunn’s <a href="https://gizmodo.com/james-gunn-creature-commandos-cast-dc-david-harbour-1850328118"><em>Creature Commandos</em></a><em> f</em>or <a href="https://gizmodo.com/what-s-next-for-blue-beetle-in-the-dc-universe-1850734415">DC Studios</a>. Both projects are currently being paused as the WGA and SAG-AFTRA strikes continue as…</p><p><a href="https://gizmodo.com/david-harbour-stranger-things-end-dc-creature-commandos-1850750060">Read more...</a></p>

## What’s Next for Blue Beetle in the DC Universe? | io9 Interview
 - [https://gizmodo.com/what-s-next-for-blue-beetle-in-the-dc-universe-1850734415](https://gizmodo.com/what-s-next-for-blue-beetle-in-the-dc-universe-1850734415)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T22:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0pupEaqy--/c_fit,fl_progressive,q_80,w_636/61f9e92a8703669fc1cc1dbe2b87200a.jpg" /><p><a href="https://gizmodo.com/what-s-next-for-blue-beetle-in-the-dc-universe-1850734415">Read more...</a></p>

## The State of the Star Wars Galaxy Coming Into Ahsoka
 - [https://gizmodo.com/star-wars-ahsoka-timeline-setting-thrawn-disney-plus-1850749674](https://gizmodo.com/star-wars-ahsoka-timeline-setting-thrawn-disney-plus-1850749674)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--f5x1ITjI--/c_fit,fl_progressive,q_80,w_636/3b8d2f4c891c52a37ae264aa90429407.png" /><p>When <em>Ahsoka</em> <a href="https://gizmodo.com/star-wars-ahsoka-trailer-hayden-christensen-1850733415">begins next week</a>, we’re getting even further insight into a <em>Star Wars</em> galaxy at a<a href="https://gizmodo.com/star-wars-ahsoka-tano-disney-plus-disjointed-character-1850608280"> crossroads moment in time</a>—arguably the first major crisis of a nascent New Republic, and a galaxy still picking itself up after the fall of the Galactic Empire. But what do we <a href="https://gizmodo.com/a-timeline-of-everything-we-know-happened-after-return-1820781008">actually know has happened</a> in the run-up to the…</p><p><a href="https://gizmodo.com/star-wars-ahsoka-timeline-setting-thrawn-disney-plus-1850749674">Read more...</a></p>

## Pentagon Launches Study on How to Start an Economy on the Moon in the Next 10 Years
 - [https://gizmodo.com/darpa-moon-study-lunar-economy-10-years-1850747663](https://gizmodo.com/darpa-moon-study-lunar-economy-10-years-1850747663)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T21:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--x-z2Wlam--/c_fit,fl_progressive,q_80,w_636/f835e8e49f8e5f980e616c317a0786ec.png" /><p>The Moon is so hot right now, metaphorically speaking. Several <a href="https://gizmodo.com/spacex-starship-nasa-moon-landing-delays-artemis-1850519728">US government agencies</a>, <a href="https://gizmodo.com/why-japan-private-lunar-lander-crashed-moon-1850479198">private space ventures</a>, and <a href="https://gizmodo.com/china-launches-civilian-to-space-targets-2030-moon-land-1850486636">foreign governments like China</a> are plotting for mankind’s return to the lunar surface over the next decade. Unlike the days of Apollo, the modern-day race to the Moon involves establishing a sustainable…</p><p><a href="https://gizmodo.com/darpa-moon-study-lunar-economy-10-years-1850747663">Read more...</a></p>

## How birth/rebirth Explores the Joys and Horrors of Motherhood
 - [https://gizmodo.com/birth-rebirth-laura-moss-interview-horror-frankenstein-1850721268](https://gizmodo.com/birth-rebirth-laura-moss-interview-horror-frankenstein-1850721268)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T20:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--eIXuJV9y--/c_fit,fl_progressive,q_80,w_636/e91e9d9aaa6a389eff8b2b553f0c6b97.jpg" /><p>io9 first caught director and co-writer Laura Moss’ debut <a href="https://gizmodo.com/birth-rebirth-trailer-body-horror-death-frankenstein-1850638544"><em>birth/rebirth</em></a> at the Sundance Film Festival in early 2023—<a href="https://gizmodo.com/2023-sundance-horror-film-review-birth-rebirth-shudder-1850021548">read our review here</a>—and its grisly yet deeply emotional exploration of <a href="https://gizmodo.com/prevenge-delivers-a-great-horror-story-about-the-terror-1793615895">motherhood</a> has stuck with us for months. With the film about to hit theaters, we were excited to speak to Moss all about it.<br /></p><p><a href="https://gizmodo.com/birth-rebirth-laura-moss-interview-horror-frankenstein-1850721268">Read more...</a></p>

## What Did the Actors Bring to Their Back to the Future: The Musical Performances? | io9 Interview
 - [https://gizmodo.com/what-did-the-actors-bring-to-their-back-to-the-future-1850747962](https://gizmodo.com/what-did-the-actors-bring-to-their-back-to-the-future-1850747962)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--SlGqQ2N8--/c_fit,fl_progressive,q_80,w_636/fc3f307947ee5e6fc37ae3ea722b96b0.jpg" /><p><a href="https://gizmodo.com/what-did-the-actors-bring-to-their-back-to-the-future-1850747962">Read more...</a></p>

## Samsung's Freestyle Gen 2 Lets You Play Cloud Games on Your Ceiling
 - [https://gizmodo.com/samsung-freestyle-gen-2-projector-gaming-hub-1850749168](https://gizmodo.com/samsung-freestyle-gen-2-projector-gaming-hub-1850749168)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T19:57:51+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KAbCijRs--/c_fit,fl_progressive,q_80,w_636/5aec16772edcc1d08e7e7b78c93253da.png" /><p>There’s no better way to play video games than lying down. That can be hard to do when the TV is situated straight ahead. But with Samsung’s new Freestyle Gen 2 projector, you can lay on your back and indulge in your favorite cozy game projected on the ceiling above.<br /></p><p><a href="https://gizmodo.com/samsung-freestyle-gen-2-projector-gaming-hub-1850749168">Read more...</a></p>

## Draganfly’s CEO Believes Drones Will Have a Bigger Impact on War Than Tanks
 - [https://gizmodo.com/ukraine-landmines-russia-how-draganfly-drones-demine-1850747725](https://gizmodo.com/ukraine-landmines-russia-how-draganfly-drones-demine-1850747725)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T19:34:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9m83PLfE--/c_fit,fl_progressive,q_80,w_636/64b872675adc41af90f1c46646a2ef73.png" /><p>When Draganfly launched as a small drone company in 1998, its co-founders did not predict hobbyist products like theirs would one day become, in the words of CEO Cameron Chell, “bigger than the advent of the tank in World War I.” Now, 25 years later, Draganfly’s drones—which are <a href="https://www.smithsonianmag.com/air-space-magazine/this-drone-can-save-your-life-180955994/#:~:text=Founded%20by%20Zenon%20and%20Christine,flight%20in%20under%20a%20minute." rel="noopener noreferrer" target="_blank">credited</a> by the Smithsonian as being…</p><p><a href="https://gizmodo.com/ukraine-landmines-russia-how-draganfly-drones-demine-1850747725">Read more...</a></p>

## D&D Beyond's First Third-Party Product for Sale Is a Critical Role Release
 - [https://gizmodo.com/dnd-beyond-taldorei-reborn-setting-critical-role-wotc-1850748289](https://gizmodo.com/dnd-beyond-taldorei-reborn-setting-critical-role-wotc-1850748289)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T19:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6HIekv3h--/c_fit,fl_progressive,q_80,w_636/d72cdcc4d0c148a01a283bd3e702a6f5.png" /><p><em>Tal’dorei Campaign Setting Reborn</em> is <a href="https://www.dndbeyond.com/marketplace/sourcebooks/taldorei-campaign-setting-reborn?utm_campaign=DDB-Tal%E2%80%99Dorei&amp;utm_source=TWITTER&amp;utm_medium=social&amp;utm_content=11071125193" rel="noopener noreferrer" target="_blank">now available</a> digitally on <a href="https://gizmodo.com/dungeons-dragons-wizards-hasbro-ogl-open-game-license-1849981136">D&amp;D Beyond</a>. This is huge news, not just for <a href="https://gizmodo.com/critical-role-candela-obscura-ttrpg-actual-play-mercer-1850419405"><em>Critical Role</em></a> fans, but for any third-party publisher who writes with <a href="https://gizmodo.com/dnd-wizards-of-the-coast-ogl-1-1-open-gaming-license-1849950634"><em>Dungeons &amp; Dragons</em></a> in mind. For years, D&amp;D Beyond has had agreements with Wizards of the Coast to offer digital, interactive versions of…</p><p><a href="https://gizmodo.com/dnd-beyond-taldorei-reborn-setting-critical-role-wotc-1850748289">Read more...</a></p>

## San Francisco Begs California to Pause Waymo & Cruise Robotaxi Infestation
 - [https://gizmodo.com/san-francisco-asks-for-pause-waymo-cruise-1850748725](https://gizmodo.com/san-francisco-asks-for-pause-waymo-cruise-1850748725)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T19:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PZXxNJF3--/c_fit,fl_progressive,q_80,w_636/3402872e387f4db089d8ade6239ee1a5.jpg" /><p>The future is nigh, but  San Francisco wants to push it off just a little farther. The Bay Area city is asking California regulators to push pause on the expansion of robotaxi services from Waymo and Cruise.</p><p><a href="https://gizmodo.com/san-francisco-asks-for-pause-waymo-cruise-1850748725">Read more...</a></p>

## Microsoft Teases Event for September 21st
 - [https://gizmodo.com/microsoft-teases-event-for-september-21-1850748746](https://gizmodo.com/microsoft-teases-event-for-september-21-1850748746)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T18:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--nMkrdXGa--/c_fit,fl_progressive,q_80,w_636/8150544b447c4a5d783a6f546438d1c2.png" /><p>Microsoft started issuing invitations for a “special event” on Thursday where it may introduce some new hardware and software, including <a href="https://gizmodo.com/microsoft-surface-laptop-5-pro-9-studio-2-plus-1849647787">upgrades to its Surface laptops</a> and additional AI products. The event is scheduled to be held in New York City on Sept. 21, Microsoft announced in its email and will be the first…</p><p><a href="https://gizmodo.com/microsoft-teases-event-for-september-21-1850748746">Read more...</a></p>

## Barbie vs. The Super Mario Bros. Movie Is a Perfect 2023 Hollywood Microcosm
 - [https://gizmodo.com/barbie-super-mario-bros-movie-sag-aftra-wga-strikes-wb-1850743616](https://gizmodo.com/barbie-super-mario-bros-movie-sag-aftra-wga-strikes-wb-1850743616)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--63AwS6bu--/c_fit,fl_progressive,q_80,w_636/52abce584ee2783e5b90ad04e8315cc3.jpg" /><p>When all is said and done, the biggest movies of 2023 are going to be based on a 60-year-old doll and a 40-year-old video game. <a href="https://gizmodo.com/barbie-review-margot-robbie-greta-gerwig-ryan-gosling-1850660597"><em>Barbie</em></a> and <a href="https://gizmodo.com/super-mario-movie-review-nintendo-illumination-luigi-pe-1850285728"><em>The Super Mario Bros. Movie</em></a> have each, in their own unique ways, shown the best of what modern studio filmmaking can be. In an era when <a href="https://gizmodo.com/marvel-release-dates-when-to-see-upcoming-mcu-movies-a-1848196856">name brands and sequels</a> continue to be the…</p><p><a href="https://gizmodo.com/barbie-super-mario-bros-movie-sag-aftra-wga-strikes-wb-1850743616">Read more...</a></p>

## America's Favorite Killer Doll to Take the Capitol In Chucky Season 3
 - [https://gizmodo.com/chucky-season-3-syfy-usa-network-peacock-universal-hhn-1850747869](https://gizmodo.com/chucky-season-3-syfy-usa-network-peacock-universal-hhn-1850747869)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T17:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--jAeBGJu2--/c_fit,fl_progressive,q_80,w_636/30cb52e5a70f3f0e6d93604cec690349.png" /><p>Talk about a killer campaign. <a href="https://gizmodo.com/living-with-chucky-doc-horror-childs-play-jennifer-till-1850237269">Chucky</a> (Brad Dourif) takes the stage for a run—more like a run for the lives of his next victims—to tease whats next in <a href="https://gizmodo.com/chucky-reginald-the-vampire-syfy-new-seasons-1849991016"><em>Chucky</em> Season 3</a>.</p><p><a href="https://gizmodo.com/chucky-season-3-syfy-usa-network-peacock-universal-hhn-1850747869">Read more...</a></p>

## A New Walking Dead Video Game Lets Players Rewrite the Show's Story
 - [https://gizmodo.com/new-walking-dead-game-destinies-rick-shane-michonne-amc-1850747799](https://gizmodo.com/new-walking-dead-game-destinies-rick-shane-michonne-amc-1850747799)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BAKwXZ1X--/c_fit,fl_progressive,q_80,w_636/5e1254a1d670b4fae32316916b730c2f.jpg" /><p><a href="https://gizmodo.com/marvels-what-if-season-1-finale-found-a-time-and-place-1847808316">“What if?”</a> is always a fascinating question. It lets us explore our imaginations in scenarios we’ll never actually see play out. Now though, you can see them play out in <a href="https://gizmodo.com/walking-dead-recap-io9-rob-bricken-10-years-1849802025"><em>The Walking Dead</em> universe</a> and it’s arguably the <a href="https://gizmodo.com/walking-dead-dead-city-hit-ratings-amc-maggie-negan-1850561392">most intriguing thing</a> to happen to the franchise in years. </p><p><a href="https://gizmodo.com/new-walking-dead-game-destinies-rick-shane-michonne-amc-1850747799">Read more...</a></p>

## Apple Won't Be Shipping Nearly as Many iPhones When the New One Drops
 - [https://gizmodo.com/iphone-15-apple-cuts-production-slow-demand-analyst-1850748250](https://gizmodo.com/iphone-15-apple-cuts-production-slow-demand-analyst-1850748250)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:56:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--DqiZ6Voa--/c_fit,fl_progressive,q_80,w_636/748cf1ece5d2a6c09ffa4a609dab1da3.jpg" /><p>Apple’s promising several upgrades to its upcoming iPhone 15 to entice more people to upgrade, but behind the scenes, the company is reportedly expecting far fewer sales of its mainline smartphone this time around.</p><p><a href="https://gizmodo.com/iphone-15-apple-cuts-production-slow-demand-analyst-1850748250">Read more...</a></p>

## Remains of Teenage Girl May Push Back Funerary Traditions in Neolithic Iberia by a Millennium
 - [https://gizmodo.com/remains-of-teenage-girl-may-push-back-funerary-traditio-1850748159](https://gizmodo.com/remains-of-teenage-girl-may-push-back-funerary-traditio-1850748159)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:53:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ekhBGsm6--/c_fit,fl_progressive,q_80,w_636/1ca262fb68f8dddf693cb97bf399b5d0.jpg" /><p>Archaeologists studying ancient human remains in a Spanish cave system posit that one individual’s burial is the oldest Neolithic funerary site in Iberia by over 1,000 years.</p><p><a href="https://gizmodo.com/remains-of-teenage-girl-may-push-back-funerary-traditio-1850748159">Read more...</a></p>

## WokeGPT: Study Says ChatGPT Shows Liberal Bias
 - [https://gizmodo.com/chatgpt-shows-liberal-bias-study-says-1850747470](https://gizmodo.com/chatgpt-shows-liberal-bias-study-says-1850747470)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:36:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VXFfLGsO--/c_fit,fl_progressive,q_80,w_636/1beefc90a6cec5e56295ffa676d77f98.jpg" /><p>A study from researchers at the University of East Anglia in the UK suggests ChatGPT demonstrates liberal bias in some of its responses. Tech companies spent recent years desperately trying to prove their systems aren’t part of some left-wing political conspiracy. If the study’s findings are correct, ChatGPT’s…</p><p><a href="https://gizmodo.com/chatgpt-shows-liberal-bias-study-says-1850747470">Read more...</a></p>

## Xbox 360 Store to Become a Thing of the Past Starting in 2024
 - [https://gizmodo.com/xbox-360-store-will-close-in-2024-1850747842](https://gizmodo.com/xbox-360-store-will-close-in-2024-1850747842)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--6G6sUq2i--/c_fit,fl_progressive,q_80,w_636/682012547dfff16bafb674e4cdf178f1.jpg" /><p>Microsoft is bringing an end to its Xbox 360 Store and Xbox 360 Marketplace starting July 29, 2024, the company announced on Thursday. The closure brings an end to Xbox 360’s 18-year run of bringing video games and other content to players everywhere.</p><p><a href="https://gizmodo.com/xbox-360-store-will-close-in-2024-1850747842">Read more...</a></p>

## David Yost Is Returning to Power Rangers for Cosmic Fury
 - [https://gizmodo.com/power-rangers-cosmic-fury-release-date-netflix-billy-1850747873](https://gizmodo.com/power-rangers-cosmic-fury-release-date-netflix-billy-1850747873)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hqFaNHeY--/c_fit,fl_progressive,q_80,w_636/f004cf7c8885835a47d67ae25a5e85fe.png" /><p>When <em>Cosmic Fury</em>—seemingly the last iteration of <em>Power Rangers</em> as fans have known it for <a href="https://gizmodo.com/power-rangers-stunt-interview-akihiro-yuji-noguchi-dino-1848837455">the last 30 years</a> as Hasbro looks to a new <a href="https://gizmodo.com/power-rangers-newest-movie-reboot-is-now-a-tv-franchise-1845428111">movie-and-TV take</a> on the transforming teens—comes to Netflix last month, it’s bringing a legend with it: the original Blue Ranger, Billy Cranston, is back in spandex.<br /></p><p><a href="https://gizmodo.com/power-rangers-cosmic-fury-release-date-netflix-billy-1850747873">Read more...</a></p>

## Samsung Galaxy Z Fold 5 Review: The Best Folding Phone Still Costs Too Much
 - [https://gizmodo.com/samsung-galaxy-z-fold-5-review-1850744972](https://gizmodo.com/samsung-galaxy-z-fold-5-review-1850744972)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--rPzTrSgW--/c_fit,fl_progressive,q_80,w_636/4b8c7b162aada42aa42d12e373722a06.png" /><p>Over the past year of using Samsung’s <a href="https://gizmodo.com/samsung-galaxy-z-fold-4-review-price-positive-worth-it-1849449228" target="_blank">Galaxy Z Fold 4</a> out in public, people have told me that, while they think folding phones are cool, they seem like nothing more than an expensive party trick. I don’t disagree. Life is fine with just one screen in your pocket and a smartphone that doesn’t unfold into a tablet. No…</p><p><a href="https://gizmodo.com/samsung-galaxy-z-fold-5-review-1850744972">Read more...</a></p>

## South Korean University Investigating Author of Those Viral Superconductor Claims
 - [https://gizmodo.com/university-investigating-author-of-lk-99-superconductor-1850747161](https://gizmodo.com/university-investigating-author-of-lk-99-superconductor-1850747161)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ND5WREZ_--/c_fit,fl_progressive,q_80,w_636/c8340e59441dc75078eef699ce37b88e.png" /><p>A few short weeks ago, the world was taken aback by claims of a room-temperature superconductor—a scientific finding that could redefine modern physics as we know it. Those claims turned out to be bunk, and a South Korean university is investigating a complaint made against the professor who published them in a paper. </p><p><a href="https://gizmodo.com/university-investigating-author-of-lk-99-superconductor-1850747161">Read more...</a></p>

## Prey, Released Exclusively on Hulu, Will Get a Physical Release
 - [https://gizmodo.com/prey-hulu-physical-release-predator-bonus-content-1850747439](https://gizmodo.com/prey-hulu-physical-release-predator-bonus-content-1850747439)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T15:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fT_ylgVu--/c_fit,fl_progressive,q_80,w_636/63fbd09b740ddf52a73cf432eccc3072.png" /><p><em>Prey</em>, Dan Trachtenberg’s installment into the Predator franchise, is arriving on 4K UHD, Blu-ray and DVD on October 3. There will also be a collector’s edition steelbook for the 4K edition, designed by Attila Szarca, exclusively available at Best Buy. Notably, <em>Prey</em> didn’t make it to theatrical release, and was…</p><p><a href="https://gizmodo.com/prey-hulu-physical-release-predator-bonus-content-1850747439">Read more...</a></p>

## High Winds, Heavy Rain, and Tumultuous Waves Are Headed to California This Weekend
 - [https://gizmodo.com/high-winds-headed-to-california-hurricane-hilary-1850747535](https://gizmodo.com/high-winds-headed-to-california-hurricane-hilary-1850747535)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T15:29:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FPmDRVcd--/c_fit,fl_progressive,q_80,w_636/a29a92d16e939f3c9a9237797e6b0a69.jpg" /><p>Tropical storm Hilary in the Pacific Ocean has strengthened to officially become a hurricane. </p><p><a href="https://gizmodo.com/high-winds-headed-to-california-hurricane-hilary-1850747535">Read more...</a></p>

## Razer Launches Its First Hot-Swappable Mechanical Gaming Keyboard
 - [https://gizmodo.com/razer-blackwidow-v4-mechanical-gaming-keyboard-hot-swap-1850746200](https://gizmodo.com/razer-blackwidow-v4-mechanical-gaming-keyboard-hot-swap-1850746200)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WMQDJ_3M--/c_fit,fl_progressive,q_80,w_636/321f6c85405cf85ec93399643759f063.jpg" /><p>Razer has done an impressive job with its mechanical gaming keyboards. Since launching the <a href="https://gizmodo.com/razer-deathstalker-v2-pro-low-profile-mechanical-review-1849329493" target="_blank">DeathStalker V2 Pro</a> in 2021, it’s cut back on the physical bloat and opted for simpler designs so that the boards have become like blank canvasses. I’m still not on board with the decidedly masculine “esport” aesthetic, but at…</p><p><a href="https://gizmodo.com/razer-blackwidow-v4-mechanical-gaming-keyboard-hot-swap-1850746200">Read more...</a></p>

## New York Times Reportedly Considering Lawsuit That Could Throw OpenAI Into Chaos
 - [https://gizmodo.com/new-york-times-considering-legal-action-against-openai-1850747125](https://gizmodo.com/new-york-times-considering-legal-action-against-openai-1850747125)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T14:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iduEy0zl--/c_fit,fl_progressive,q_80,w_636/67d1be72b44b63decc4fe8ace0729a55.jpg" /><p>OpenAI is facing a potential lawsuit from The New York Times for an intellectual property debate over alleged copyright violations, sources told <a href="https://gizmodo.com/sarah-silverman-sues-chatgpt-and-meta-over-ai-training-1850621182">NPR</a> on Wednesday. The news outlet claims OpenAI, the owner of <a href="https://gizmodo.com/chat-gpt-openai-ai-finance-ai-everything-we-know-1850018307">ChatGPT</a>, is using the Times’ content to train its chatbot.</p><p><a href="https://gizmodo.com/new-york-times-considering-legal-action-against-openai-1850747125">Read more...</a></p>

## Leaked Images Show Lenovo's Legion Go Is a Switch and a Steam Deck Rolled Into One
 - [https://gizmodo.com/lenovo-legion-go-leaks-nintendo-switch-steam-deck-1850747061](https://gizmodo.com/lenovo-legion-go-leaks-nintendo-switch-steam-deck-1850747061)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T14:35:48+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lL6wHjUj--/c_fit,fl_progressive,q_80,w_636/3406d1af438ed58b8aae0e599c9600e8.jpg" /><p>The handheld console market is about to go full-circle. Leaked images of Lenovo’s upcoming Legion Go gaming device show that the company has taken inspiration from Nintendo and Valve for its next product, with the silhouette and controls of the Steam Deck plus the snappable, swappable controllers of the Nintendo…</p><p><a href="https://gizmodo.com/lenovo-legion-go-leaks-nintendo-switch-steam-deck-1850747061">Read more...</a></p>

## Apple TV+'s Monsterverse Series Has a Title and a Hello From Godzilla
 - [https://gizmodo.com/monsterverse-godzilla-apple-tv-show-monarch-kurt-russel-1850744992](https://gizmodo.com/monsterverse-godzilla-apple-tv-show-monarch-kurt-russel-1850744992)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_ulutZM7--/c_fit,fl_progressive,q_80,w_636/02c0691a7776f90600628897545b15ff.jpg" /><p>Something <a href="https://gizmodo.com/monsterverse-sequel-godzilla-king-kong-new-empire-title-1850353261">big, furious, and ready to fight</a> is coming to Apple TV+, and with any luck, it’ll be bringing like-minded friends along. The streamer has just lifted the lid on <a href="https://gizmodo.com/godzilla-stomps-onto-apple-tv-with-new-spinoff-series-1848395281">its 10-episode series continuing the story of Legendary’s Monsterverse</a>, revealing the title—<em>Monarch: Legacy of Monsters—</em>and some first images.</p><p><a href="https://gizmodo.com/monsterverse-godzilla-apple-tv-show-monarch-kurt-russel-1850744992">Read more...</a></p>

## From 'Race Records' to AI Drake: How Technology Entwines With Hip-Hop
 - [https://gizmodo.com/hip-hop-history-tech-50th-anniversary-1850718364](https://gizmodo.com/hip-hop-history-tech-50th-anniversary-1850718364)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-17T10:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IfTeXyOa--/c_fit,fl_progressive,q_80,w_636/16fd9ab401869641e5fc377f24d30a22.jpg" /><p><em>This story is part of our new <a href="https://www.theroot.com/culture/hip-hop-73-till-infinity" target="_blank">Hip-Hop: ’73 Till Infinity</a> series, a celebration of the genre’s 50th anniversary.<br /></em></p><p><a href="https://gizmodo.com/hip-hop-history-tech-50th-anniversary-1850718364">Read more...</a></p>

