# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## California thieves caught on camera blatantly breaking and entering into parked cars in San Francisco
 - [https://www.foxnews.com/us/california-thieves-caught-camera-blatantly-breaking-entering-parked-cars-san-francisco](https://www.foxnews.com/us/california-thieves-caught-camera-blatantly-breaking-entering-parked-cars-san-francisco)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T19:26:35+00:00

A driver trailed a pair of thieves on a robbery spree in San Francisco that spanned multiple blocks and involved a man hopping out of a vehicle and breaking into parked cars.

## Sam Asghari breaks silence on Britney Spears separation after filing for divorce: 'Wish her the best always'
 - [https://www.foxnews.com/entertainment/sam-asghari-breaks-silence-britney-spears-separation-after-filing-divorce](https://www.foxnews.com/entertainment/sam-asghari-breaks-silence-britney-spears-separation-after-filing-divorce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T19:02:27+00:00

Sam Asghari spoke out for the first time since the news of his split from Britney Spears broke, saying they will &quot;hold onto the love and respect&quot; hey have for each other.

## Biden angers social media users with refusal to offer details about his trip to Hawaii: 'Buffoon'
 - [https://www.foxnews.com/media/biden-angers-social-media-users-refusal-offer-details-trip-hawaii-buffoon](https://www.foxnews.com/media/biden-angers-social-media-users-refusal-offer-details-trip-hawaii-buffoon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T19:00:01+00:00

President Biden declined to offer details to reporters on Thursday about his upcoming trip to Hawaii following the devastating wildfires on the island of Maui.

## Ramaswamy hits DeSantis back, suggests he's a 'super PAC puppet' after leaked memo hints gov's debate attacks
 - [https://www.foxnews.com/media/ramaswamy-hits-desantis-back-suggests-hes-super-pac-puppet-after-leaked-memo-hints-govs-debate-attacks](https://www.foxnews.com/media/ramaswamy-hits-desantis-back-suggests-hes-super-pac-puppet-after-leaked-memo-hints-govs-debate-attacks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:31:03+00:00

GOP hopeful Vivek Ramaswamy took aim at Ron DeSantis after the a leaked document from the Florida governor&apos;s PAC outlined debate strategy included attacking the political outsider.

## Hawaii senator bashes federal disaster relief to state, demands FEMA come off its ‘30,000 ft cloud’ to help
 - [https://www.foxnews.com/media/hawaii-senator-bashes-federal-disaster-relief-state-demands-fema-come-off-30000-ft-cloud-help](https://www.foxnews.com/media/hawaii-senator-bashes-federal-disaster-relief-state-demands-fema-come-off-30000-ft-cloud-help)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:30:42+00:00

Hawaii state Sen. Angus McKelvey criticized the U.S. government&apos;s response to the fire disaster on the island of Maui, Hawaii during a recent CNN segment.

## Hunter Biden tax charges dismissed by federal judge following plea deal breakdown
 - [https://www.foxnews.com/politics/hunter-biden-tax-charges-dismissed-federal-judge-plea-deal-breakdown](https://www.foxnews.com/politics/hunter-biden-tax-charges-dismissed-federal-judge-plea-deal-breakdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:29:24+00:00

A federal judge in Delaware has dismissed the misdemeanor tax charges against Hunter Biden, a move that was expected after his plea deal fell through last month.

## Man involved in gruesome 1996 teen beheading case granted reduced sentence, chance for parole
 - [https://www.foxnews.com/us/man-involved-gruesome-1996-teen-beheading-case-granted-reduced-sentence-chance-parole](https://www.foxnews.com/us/man-involved-gruesome-1996-teen-beheading-case-granted-reduced-sentence-chance-parole)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:25:11+00:00

A man who committed a gruesome act of violence as a teenager, involving the killing and beheading of another teen, has been granted a reduced prison sentence and opportunity for release.

## Minnesota school police officers express concerns over new restrictions on physical holds
 - [https://www.foxnews.com/us/minnesota-school-police-officers-express-concerns-new-restrictions-physical-holds](https://www.foxnews.com/us/minnesota-school-police-officers-express-concerns-new-restrictions-physical-holds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:23:09+00:00

Amid preparations for the return of students in Minnesota schools, concerns have arisen among officers assigned to schools due to new statewide restrictions on the use of physical holds.

## Michael Oher conservatorship case raises more questions than answers, legal expert says
 - [https://www.foxnews.com/sports/michael-oher-conservatorship-case-raises-more-questions-than-answers-legal-expert-says](https://www.foxnews.com/sports/michael-oher-conservatorship-case-raises-more-questions-than-answers-legal-expert-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:23:07+00:00

Ex-NFL player Michael Oher filed a petition Monday to end Sean and Leigh Anne Tuohy&apos;s conservatorship after nearly 20 years, but the recent filings raise more questions than answers.

## New Hampshire sheriff faces felony charges for misuse of county funds and perjury
 - [https://www.foxnews.com/us/new-hampshire-sheriff-faces-felony-charges-misuse-county-funds-perjury](https://www.foxnews.com/us/new-hampshire-sheriff-faces-felony-charges-misuse-county-funds-perjury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:21:28+00:00

A New Hampshire sheriff who became the state’s sole Black sheriff in 2020, was arrested and charged with eight felonies following a probe into his alleged misuse of county credit cards.

## Mexican investigators find decapitated, burned bodies after circulation of gruesome execution video
 - [https://www.foxnews.com/world/mexican-investigators-find-decapitated-burned-bodies-circulation-gruesome-execution-video](https://www.foxnews.com/world/mexican-investigators-find-decapitated-burned-bodies-circulation-gruesome-execution-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:16:46+00:00

Mexican authorities have found four decapitated and badly burned bodies several days after the emergence of a gruesome execution believed to show five missing young men.

## Tim Anderson of White Sox has suspension for José Ramírez fight reduced to five games
 - [https://www.foxnews.com/sports/tim-anderson-white-sox-has-suspension-jose-ramirez-fight-reduced-five-games](https://www.foxnews.com/sports/tim-anderson-white-sox-has-suspension-jose-ramirez-fight-reduced-five-games)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:13:15+00:00

Chicago White Sox shortstop Tim Anderson had his six-game suspension for fighting José Ramírez of the Cleveland Guardians reduced to five games.

## Fairfax County moms say district defiance of transgender school policy puts 'special interests before safety'
 - [https://www.foxnews.com/media/fairfax-county-moms-say-district-defiance-transgender-school-policy-special-interests-safety](https://www.foxnews.com/media/fairfax-county-moms-say-district-defiance-transgender-school-policy-special-interests-safety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:00:32+00:00

Fairfax County Public School parents speak out against policy to block sex-segregated bathrooms, calling it a politicized move that can harm students.

## Fox News Poll: Voters want schools to teach more about good citizenship and less about gender identity
 - [https://www.foxnews.com/official-polls/fox-news-poll-voters-schools-teach-more-good-citizenship-less-gender-identity](https://www.foxnews.com/official-polls/fox-news-poll-voters-schools-teach-more-good-citizenship-less-gender-identity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:00:09+00:00

A new Fox News poll found American voters want schools to teach more about good citizenship and less about gender identity and sexual orientation.

## Fox News Poll: Voters sound off on what US should do when it comes to helping Ukraine
 - [https://www.foxnews.com/official-polls/fox-news-poll-voters-sound-off-us-helping-ukraine](https://www.foxnews.com/official-polls/fox-news-poll-voters-sound-off-us-helping-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:00:06+00:00

A new Fox News poll found the number of Americans saying the U.S. should be doing less to help Ukraine amid its war with Russia has grown.

## Fox News Poll: Voters feel Bidenomics making things worse
 - [https://www.foxnews.com/official-polls/fox-news-poll-voters-feel-bidenomics-making-things-worse](https://www.foxnews.com/official-polls/fox-news-poll-voters-feel-bidenomics-making-things-worse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T18:00:04+00:00

A new Fox News poll found that American voters feel President Biden&apos;s economic policies, dubbed &quot;Bidenomics,&quot; are making the economy worse.

## James Harden teases that he could play in China: 'Love is always crazy here'
 - [https://www.foxnews.com/sports/james-harden-teases-he-could-play-china-love-always-crazy-here](https://www.foxnews.com/sports/james-harden-teases-he-could-play-china-love-always-crazy-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:57:22+00:00

James Harden tried to orchestrate a trade from the Philadelphia 76ers that never came to fruition. Now, he apparently has his eye on China.

## Los Angeles sports teams come together to donate money for Maui wildfire relief
 - [https://www.foxnews.com/sports/los-angeles-sports-teams-come-together-donate-money-maui-wildfire-relief](https://www.foxnews.com/sports/los-angeles-sports-teams-come-together-donate-money-maui-wildfire-relief)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:56:41+00:00

The Los Angeles sports teams have all come together to donate $450,000 in combined funds to help Maui wildfire relief, and some are trying to raise even more money.

## Florida cold case victim identified 26 years after being found floating in Intracoastal Waterway
 - [https://www.foxnews.com/us/florida-cold-case-victim-identified-found-floating-intracoastal-waterway](https://www.foxnews.com/us/florida-cold-case-victim-identified-found-floating-intracoastal-waterway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:54:49+00:00

The Flagler County Sheriff&apos;s Office in Florida announced that a body found floating on the Intracoastal Waterway 26 years ago has been identified as Robert Bruce McPhail.

## 2 Florida men sentenced for roles in US Capitol attack
 - [https://www.foxnews.com/us/2-florida-men-sentenced-roles-us-capitol-attack](https://www.foxnews.com/us/2-florida-men-sentenced-roles-us-capitol-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:53:12+00:00

Two Florida men were convicted on felony charges including civil disorder, and entering and remaining in a restricted building during the Jan. 6 storming of the U.S. Capitol.

## Pfizer's upgraded COVID-19 vaccine shows effectiveness against emerging 'Eris' subvariant
 - [https://www.foxnews.com/us/pfizers-upgraded-covid-19-vaccine-shows-effectiveness-emerging-eris-subvariant](https://www.foxnews.com/us/pfizers-upgraded-covid-19-vaccine-shows-effectiveness-emerging-eris-subvariant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:49:47+00:00

Pfizer Inc. announced that its updated COVID-19 vaccine has demonstrated neutralizing activity against the &quot;Eris&quot; subvariant in a study conducted using mice.

## Jets' Aaron Rodgers leaves hidden Packers message in Instagram post
 - [https://www.foxnews.com/sports/jets-aaron-rodgers-puts-hidden-packers-message-instagram-post](https://www.foxnews.com/sports/jets-aaron-rodgers-puts-hidden-packers-message-instagram-post)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:41:12+00:00

New York Jets quarterback Aaron Rodgers stirred the rumor pot a bit with a hidden Green Bay Packers message in his latest Instagram post that showed appreciation to &quot;my 17s.&quot;

## Houston police search for suspect who murdered 11-year-old girl, left body in her suburban home
 - [https://www.foxnews.com/us/houston-police-search-suspect-murdered-11-year-old-girl-left-body-suburban-home](https://www.foxnews.com/us/houston-police-search-suspect-murdered-11-year-old-girl-left-body-suburban-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:11:47+00:00

Authorities are intensifying their search for the individual responsible for the sexual assault and murder of an 11-year-old girl, whose body was discovered in her home under her bed.

## 2 of the 15 wild geese found trapped in Los Angeles tar pits have survived
 - [https://www.foxnews.com/us/2-15-wild-geese-trapped-los-angeles-tar-pits-survived](https://www.foxnews.com/us/2-15-wild-geese-trapped-los-angeles-tar-pits-survived)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:10:23+00:00

Out of a group of 15 wild Canada geese that became trapped in the La Brea Tar Pits in late July, only two managed to survive after undergoing a rescue and thorough cleaning process.

## Democratic National Committee asks federal judges to dismiss case on Alabama party infighting
 - [https://www.foxnews.com/us/democratic-national-committee-asks-federal-judges-dismiss-case-alabama-party-infighting](https://www.foxnews.com/us/democratic-national-committee-asks-federal-judges-dismiss-case-alabama-party-infighting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:08:56+00:00

The Democratic National Committee has filed a request with a federal appeals court to dismiss a case focused on internal party conflicts within Alabama.

## Stefanos Tsitsipas says fan was ‘imitating a bee,’ confronts alleged culprit: ‘She needs to go’
 - [https://www.foxnews.com/sports/stefanos-tsitsipas-says-fan-imitating-bee-confronts-alleged-culprit-she-needs-to-go](https://www.foxnews.com/sports/stefanos-tsitsipas-says-fan-imitating-bee-confronts-alleged-culprit-she-needs-to-go)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:07:02+00:00

Stefanos Tsitsipas thought he was being swarmed by a bee during his match at the Cincinnati Masters on Wednesday. Instead, it was apparently a person making buzzing noises.

## Mississippi woman visiting California found dead and wrapped in plastic inside Los Angeles home
 - [https://www.foxnews.com/us/mississippi-woman-visiting-california-found-dead-wrapped-plastic-inside-los-angeles-home](https://www.foxnews.com/us/mississippi-woman-visiting-california-found-dead-wrapped-plastic-inside-los-angeles-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:01:13+00:00

A Mississippi woman was found dead and wrapped in plastic wrap by a Los Angeles mother investigating a &quot;gas small&quot; in her son&apos;s room on Sunday, police said.

## Comedy event canceled over sitcom writer’s opposition to transgender ideology: ‘Ideological cult'
 - [https://www.foxnews.com/media/comedy-event-canceled-sitcom-writers-opposition-transgender-ideology-ideological-cult](https://www.foxnews.com/media/comedy-event-canceled-sitcom-writers-opposition-transgender-ideology-ideological-cult)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:00:52+00:00

Graham Linehan called out an entertainment venue for canceling the event he would be in, asking which of his views were controversial to the local community.

## Rachel Morin murder: Maryland police to 'discuss a potential suspect' in woman's mysterious death
 - [https://www.foxnews.com/us/rachel-morin-murder-maryland-police-discuss-potential-suspect-womans-mysterious-death](https://www.foxnews.com/us/rachel-morin-murder-maryland-police-discuss-potential-suspect-womans-mysterious-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T17:00:45+00:00

Maryland officials Thursday afternoon announced an update on the murder of Rachel Morin, a Maryland mother who disappeared from a jog along a pedestrian trail Aug. 5.

## Britney Spears, Sam Asghari split: pop star's rocky relationship history
 - [https://www.foxnews.com/entertainment/britney-spears-sam-asghari-split-pop-stars-rocky-relationship-history](https://www.foxnews.com/entertainment/britney-spears-sam-asghari-split-pop-stars-rocky-relationship-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:58:49+00:00

Britney Spears&apos; third marriage is headed for divorce after 14 months of marriage. We look back at the pop star&apos;s relationship history.

## Russia arrests US citizen on espionage charges: report
 - [https://www.foxnews.com/world/russia-arrests-us-citizen-espionage-charges-report](https://www.foxnews.com/world/russia-arrests-us-citizen-espionage-charges-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:53:25+00:00

An American citizen has been jailed in Russia on spy charges, Russian news agencies said Thursday.

## Enes Freedom makes point about joining WNBA, reveals what his name would be
 - [https://www.foxnews.com/sports/enes-freedom-makes-point-joining-wnba-reveals-what-his-name-would-be](https://www.foxnews.com/sports/enes-freedom-makes-point-joining-wnba-reveals-what-his-name-would-be)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:49:09+00:00

Enes Freedom questioned when the outrage over transgender females competing in women&apos;s sports would begin and explained why he suggested playing in the WNBA.

## Kellie Pickler breaks silence after husband's death: 'Darkest time in my life'
 - [https://www.foxnews.com/entertainment/kellie-pickler-breaks-silence-after-husbands-death-darkest-time](https://www.foxnews.com/entertainment/kellie-pickler-breaks-silence-after-husbands-death-darkest-time)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:48:48+00:00

Six months after her husband&apos;s death by suicide, Kellie Pickler has broken her silence, saying she&apos;s grateful for the support from her family, friends and supporters.

## Texas father arrested after 3-year-old child brings handgun to preschool: police
 - [https://www.foxnews.com/us/texas-father-arrested-3-year-old-child-brings-handgun-preschool-backpack-police](https://www.foxnews.com/us/texas-father-arrested-3-year-old-child-brings-handgun-preschool-backpack-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:40:05+00:00

The San Antonio Police Department in Texas arrested the father of a 3-year-old child, who allegedly brought a handgun to preschool Tuesday morning.

## Bride upset after child wears white to wedding, plus man's lotto strategy pays off
 - [https://www.foxnews.com/lifestyle/bride-upset-child-wears-white-wedding-mans-lotto-strategy-pays-off](https://www.foxnews.com/lifestyle/bride-upset-child-wears-white-wedding-mans-lotto-strategy-pays-off)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:36:10+00:00

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## Critics slam federal court for blocking Idaho law barring biological males from girls' and women's sports
 - [https://www.foxnews.com/us/critics-slam-federal-court-blocking-idaho-law-barring-biological-males-from-girls-womens-sports](https://www.foxnews.com/us/critics-slam-federal-court-blocking-idaho-law-barring-biological-males-from-girls-womens-sports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:31:19+00:00

A federal court ruled against two Idaho college track athletes who are fighting to keep a law that bans biological men from playing on women&apos;s sports teams on the books.

## North Carolina bans sex change surgery for minors after GOP overrides Dem governor’s veto
 - [https://www.foxnews.com/politics/north-carolina-bans-sex-change-surgery-minors-gop-overrides-dem-governors-veto](https://www.foxnews.com/politics/north-carolina-bans-sex-change-surgery-minors-gop-overrides-dem-governors-veto)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:30:54+00:00

North Carolina has effectively banned sex change surgeries for minors after GOP lawmakers overrode opposition from Democratic Gov. Roy Cooper.

## Kim Kardashian says full-body MRI scans can be ‘life-saving,' yet many experts remain skeptical
 - [https://www.foxnews.com/health/kim-kardashian-full-body-mri-scans-can-be-life-saving-experts-remain-skeptical](https://www.foxnews.com/health/kim-kardashian-full-body-mri-scans-can-be-life-saving-experts-remain-skeptical)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:17:59+00:00

Reality star Kim Kardashian recently touted the wellness trend of whole-body MRI screening, saying these screenings can be &quot;life-saving.&quot; Health experts and medical professionals shared views.

## Arizona woman shoots, kills registered sex offender attempting to break into her home
 - [https://www.foxnews.com/us/arizona-woman-shoots-kills-registered-sex-offender-attempting-break-home](https://www.foxnews.com/us/arizona-woman-shoots-kills-registered-sex-offender-attempting-break-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:14:11+00:00

The Pima County Sheriff&apos;s Department in Arizona said a woman shot and killed a man who attempted to break into her home, and that he was a registered sex offender in Utah.

## Detransitioner warns gender ideology could have 'long-term ramifications' for kids: They 'cannot consent'
 - [https://www.foxnews.com/media/detransitioner-trans-influencer-warns-gender-ideology-long-term-ramifications-kids-cannot-consent](https://www.foxnews.com/media/detransitioner-trans-influencer-warns-gender-ideology-long-term-ramifications-kids-cannot-consent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:00:58+00:00

Oli London hits back at a psychologist&apos;s claim children can be &quot;gender hybrids,&quot; warning they are too young to comprehend the long-term ramifications of transitioning.

## Pro-life UK man charged for praying by abortion clinic has ‘chilling’ warning for US: It could happen to you
 - [https://www.foxnews.com/media/pro-life-uk-man-charged-praying-abortion-clinic-chilling-warning-us-could-happen-you](https://www.foxnews.com/media/pro-life-uk-man-charged-praying-abortion-clinic-chilling-warning-us-could-happen-you)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T16:00:30+00:00

A U.K. man who was charged for praying silently outside of an abortion clinic warned America to stand up for free speech or face &quot;thought crimes&quot; here as well.

## 'Modern Family' star Sarah Hyland claims show 'insisted' she wear heels while suffering from gout
 - [https://www.foxnews.com/entertainment/modern-family-star-sarah-hyland-claims-show-insisted-wear-heels-while-suffering-gout](https://www.foxnews.com/entertainment/modern-family-star-sarah-hyland-claims-show-insisted-wear-heels-while-suffering-gout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:51:12+00:00

&quot;Love Island USA&quot; host Sarah Hyland spoke out about the health issues she battled while filming the popular sitcom &quot;Modern Family,&quot; on her co-star Jesse Tyler Ferguson&apos;s podcast.

## New Jersey police looking for woman who allegedly threw Skee-Ball that hit child during argument
 - [https://www.foxnews.com/us/new-jersey-police-looking-woman-who-allegedly-threw-skee-ball-child-during-argument](https://www.foxnews.com/us/new-jersey-police-looking-woman-who-allegedly-threw-skee-ball-child-during-argument)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:49:00+00:00

New Jersey police said in a Facebook post they are looking for a woman who allegedly threw a Skee-Ball that ended up hitting a child during an argument at an arcade.

## Pamela Anderson, 56, laughs at her aging appearance: ‘What’s happening to me?’
 - [https://www.foxnews.com/entertainment/pamela-anderson-56-laughs-aging-appearance](https://www.foxnews.com/entertainment/pamela-anderson-56-laughs-aging-appearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:41:45+00:00

Pamela Anderson became famous for her good looks, and now, after a massive style shift from her old, wild fashion, she&apos;s explaining that she finds humor in how she looks.

## Chiefs superfan indicted on bank robbery, money laundering charges
 - [https://www.foxnews.com/sports/chiefs-superfan-indicted-bank-robbery-money-laundering-charges](https://www.foxnews.com/sports/chiefs-superfan-indicted-bank-robbery-money-laundering-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:40:23+00:00

Kansas City Chiefs superfan Xaviar &quot;ChiefsAholic&quot; Babudar faces 19 counts of money laundering and bank robbery after being arrested last month.

## Former Navy SEAL seeking to oust three-term Democratic senator builds momentum with more big name support
 - [https://www.foxnews.com/politics/former-navy-seal-democratic-senator-builds-momentum-big-name-support](https://www.foxnews.com/politics/former-navy-seal-democratic-senator-builds-momentum-big-name-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:38:52+00:00

Republican Montana Senate candidate and former Navy SEAL Tim Sheehy has received an endorsement from former House Speaker Newt Gingrich, adding to his long list of big name GOP backers.

## Ole Miss' Lane Kiffin says brutally honest approach to NIL, transfer portal 'appreciated' by fans, recruits
 - [https://www.foxnews.com/sports/ole-miss-lane-kiffin-brutally-honest-approach-nil-transfer-portal-appreciated-fans-recruits](https://www.foxnews.com/sports/ole-miss-lane-kiffin-brutally-honest-approach-nil-transfer-portal-appreciated-fans-recruits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:37:20+00:00

Ole Miss head football coach Lane Kiffin doesn&apos;t mind being brutally honest about NIL and the transfer portal because he says everyone seems to appreciate it.

## Pilots made errors before crash near Lake Tahoe that killed all 6 on board
 - [https://www.foxnews.com/us/pilots-made-errors-crash-near-lake-tahoe-killed-all-6-board](https://www.foxnews.com/us/pilots-made-errors-crash-near-lake-tahoe-killed-all-6-board)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:36:03+00:00

Critical errors by the pilots were identified by investigators as the cause behind a plane crash that killed six on a business jet, which went into an aerodynamic stall near Lake Tahoe.

## FBI arrests California police officers in civil rights investigation
 - [https://www.foxnews.com/us/fbi-arrests-california-police-officers-civil-rights-investigation](https://www.foxnews.com/us/fbi-arrests-california-police-officers-civil-rights-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:34:14+00:00

The FBI on Thursday arrested several law enforcement officers following a months-long investigation

## Groundwater treatment systems to address 'forever chemicals' planned near Michigan military base
 - [https://www.foxnews.com/us/groundwater-treatment-systems-address-forever-chemicals-planned-near-michigan-military-base](https://www.foxnews.com/us/groundwater-treatment-systems-address-forever-chemicals-planned-near-michigan-military-base)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:33:23+00:00

Efforts are underway to combat the contamination of groundwater caused by high levels of persistent and hazardous PFAS chemicals near the former Wurtsmith Air Force Base in Michigan.

## Mississippi enacts statewide burn ban at state parks and lakes amid high fire risk
 - [https://www.foxnews.com/us/mississippi-enacts-statewide-burn-ban-state-parks-lakes-amid-high-fire-risk](https://www.foxnews.com/us/mississippi-enacts-statewide-burn-ban-state-parks-lakes-amid-high-fire-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:31:03+00:00

Amidst ongoing scorching and arid conditions, state wildlife officials in Mississippi have taken action by imposing a statewide burn ban encompassing all state parks and fishing lakes.

## Taliban says women lose value if men can see their faces in public: 'should be hidden'
 - [https://www.foxnews.com/world/taliban-says-women-lose-value-men-can-see-their-faces-public](https://www.foxnews.com/world/taliban-says-women-lose-value-men-can-see-their-faces-public)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:30:05+00:00

A spokesman for Taliban&apos;s Ministry of Vice and Virtue says that women lose value if they don&apos;t wear a hijab and expose their faces in public.

## Massachusetts house suffers damage as large ice chunk falls from the sky
 - [https://www.foxnews.com/us/massachusetts-house-suffers-damage-large-ice-chunk-falls-sky](https://www.foxnews.com/us/massachusetts-house-suffers-damage-large-ice-chunk-falls-sky)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:29:28+00:00

An unusual incident unfolded in Massachusetts as a substantial chunk of ice plummeted from the sky and struck a residential dwelling, resulting in damage to the roof.

## 'Cult mom' Lori Vallow to be extradited to Arizona
 - [https://www.foxnews.com/us/cult-mom-lori-vallow-extradited-arizona](https://www.foxnews.com/us/cult-mom-lori-vallow-extradited-arizona)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:29:15+00:00

Arizona Gov. Katie Hobbs has approved Lori Vallow&apos;s extradition from Idaho about two weeks after she was sentenced to life in prison for the murders of children.

## Accusations of rape and sexual violence by Sudan's paramilitary spark outcry from rights groups and UN experts
 - [https://www.foxnews.com/world/accusations-rape-sexual-violence-sudans-paramilitary-spark-outcry-rights-groups-un-experts](https://www.foxnews.com/world/accusations-rape-sexual-violence-sudans-paramilitary-spark-outcry-rights-groups-un-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:27:14+00:00

A human rights organization and 30 United Nations experts have leveled accusations against Sudan&apos;s powerful paramilitary, citing reports of rape and sexual violence against women.

## DeSantis removed a state attorney for going 'soft' on felons, now a felon is pushing to bring her back
 - [https://www.foxnews.com/politics/florida-felon-moves-block-desantis-removing-soft-state-attorney-prosecuting-his-case](https://www.foxnews.com/politics/florida-felon-moves-block-desantis-removing-soft-state-attorney-prosecuting-his-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:23:11+00:00

A Florida felon is seeking have State Attorney Monique Worrell reinstated to prosecute his case, days after DeSantis removed her for allegedly granting lax sentences.

## Long Island leader refuses to let NYC move migrants into former NHL arena
 - [https://www.foxnews.com/us/long-island-leader-refuses-let-nyc-move-migrants-former-nhl-arena-anywhere-else-nassau](https://www.foxnews.com/us/long-island-leader-refuses-let-nyc-move-migrants-former-nhl-arena-anywhere-else-nassau)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:18:18+00:00

Nassau County Executive Bruce Blakeman said he would not allow New York City to move migrants into Nassau Coliseum or anywhere else in the county.

## Manchin ranked most bipartisan senator as he faces tough 2024 path in conservative West Virginia
 - [https://www.foxnews.com/politics/manchin-most-bipartisan-senator-tough-2024-path](https://www.foxnews.com/politics/manchin-most-bipartisan-senator-tough-2024-path)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:14:06+00:00

Sen. Joe Manchin is the most bipartisan senator, according to a nonprofit organization&apos;s annual rankings highlighting which lawmakers put politics aside to cross the aisle.

## Ex-Yankees prospect says there is 'no baseball being taught' in organization
 - [https://www.foxnews.com/sports/ex-yankees-prospect-says-no-baseball-taught-organization](https://www.foxnews.com/sports/ex-yankees-prospect-says-no-baseball-taught-organization)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:13:10+00:00

The New York Yankees are now one of Major League Baseball&apos;s laughingstocks, and one of their former prospects criticized their organizational philosophy.

## President Biden 'very obsessed' with coverage of Hunter, but aides afraid to bring him up in meetings: Report
 - [https://www.foxnews.com/media/president-biden-very-obsessed-coverage-hunter-aides-afraid-bring-him-meetings-report](https://www.foxnews.com/media/president-biden-very-obsessed-coverage-hunter-aides-afraid-bring-him-meetings-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T15:07:45+00:00

CNN&apos;s John Avlon said Thursday that President Biden was &quot;very obsessed&quot; with the negative coverage of his son Hunter and allies won&apos;t bring him up in conversation.

## How to stay connected on your phone while traveling abroad
 - [https://www.foxnews.com/tech/how-stay-connected-your-phone-traveling-abroad](https://www.foxnews.com/tech/how-stay-connected-your-phone-traveling-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:54:14+00:00

Traveling abroad can bring many charges and fees from your phone carrier, Kurt &quot;The CyberGuy&quot; Knutsson shows you some international plans and SIM card options.

## Parents of Florida teen who died in boating crash say report ruling out alcohol as factor is 'insulting'
 - [https://www.foxnews.com/us/parents-teen-died-florida-boat-crash-say-report-ruling-alcohol-factor-insulting](https://www.foxnews.com/us/parents-teen-died-florida-boat-crash-say-report-ruling-alcohol-factor-insulting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:48:04+00:00

A report has determined that alcohol was not a contributing factor in a 2022 boating accident off the coast of Miami, which left 17-year-old Luciana Fernandez dead.

## West Africa left with few options to restore order in Niger after junta takes on threats of foreign invasion
 - [https://www.foxnews.com/world/west-africa-left-few-options-restore-order-niger-junta-takes-threats-foreign-invasion](https://www.foxnews.com/world/west-africa-left-few-options-restore-order-niger-junta-takes-threats-foreign-invasion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:43:16+00:00

Nations in West Africa, which threatened to invade Niger’s junta, met in Ghana to discuss next steps after coup leaders ignored demands to step down.

## Hate speech watchdog responds to Jim Jordan's inquiry to 'set the record straight' on alleged censorship
 - [https://www.foxnews.com/politics/hate-speech-watchdog-responds-gop-inquiry-set-record-straight-alleged-censorship](https://www.foxnews.com/politics/hate-speech-watchdog-responds-gop-inquiry-set-record-straight-alleged-censorship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:38:43+00:00

The Center for Countering Digital Hate responded to an inquiry from House Judiciary Chairman Jim Jordan, denying accusations the group has acted to censor conservatives on X.

## Hurricane Hilary is 'strengthening rapidly' and will likely become 'major' storm today, forecasters say
 - [https://www.foxnews.com/us/hurricane-hilary-strengthening-rapidly-will-likely-become-major-storm-today-forecasters-say](https://www.foxnews.com/us/hurricane-hilary-strengthening-rapidly-will-likely-become-major-storm-today-forecasters-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:27:08+00:00

Hurricane Hilary, which has been upgraded to a Category 2 storm, is expected to become a major hurricane on Thursday, forecasters say.

## 'Blind Side' actor who played Michael Oher says 'blows that have been thrown' from both sides are 'shocking'
 - [https://www.foxnews.com/entertainment/blind-side-actor-played-michael-oher-says-blows-have-been-thrown-both-sides-shocking](https://www.foxnews.com/entertainment/blind-side-actor-played-michael-oher-says-blows-have-been-thrown-both-sides-shocking)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:13:56+00:00

&quot;The Blind Side&quot; star Quinton Aaron, who played Michael Oher in the film, is shocked by the feud between Oher and the Tuohy family, and hopes things can be resolved.

## Warning amid deadly clashes: Libya's prime minister calls for halt to militia violence in Tripoli
 - [https://www.foxnews.com/world/warning-amid-deadly-clashes-libyas-prime-minister-calls-halt-militia-violence-tripoli](https://www.foxnews.com/world/warning-amid-deadly-clashes-libyas-prime-minister-calls-halt-militia-violence-tripoli)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:13:54+00:00

A warning was issued by one of Libya&apos;s rival prime ministers on Thursday, emphasizing a zero-tolerance stance towards further militia clashes.

## UK prime minister plans meeting with Saudi crown prince amid trade, security talks
 - [https://www.foxnews.com/world/uk-prime-minister-plans-meeting-saudi-crown-prince-amid-trade-security-talks](https://www.foxnews.com/world/uk-prime-minister-plans-meeting-saudi-crown-prince-amid-trade-security-talks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:10:59+00:00

On Thursday, the Prime Minister of Britain announced his intention to hold a meeting with Saudi Crown Prince Mohammed bin Salman as soon as possible.

## Boehringer Ingelheim advances obesity drug candidate with up to 19% weight loss in mid-stage trial
 - [https://www.foxnews.com/world/boehringer-ingelheim-advances-obesity-drug-candidate-19-weight-loss-mid-stage-trial](https://www.foxnews.com/world/boehringer-ingelheim-advances-obesity-drug-candidate-19-weight-loss-mid-stage-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:09:25+00:00

German pharmaceutical company Boehringer Ingelheim revealed its intention to launch three advanced-stage investigations into its promising obesity drug candidate.

## Iranian foreign minister visits Saudia Arabia following countries' yearslong rivalry
 - [https://www.foxnews.com/world/iranian-foreign-minister-visits-saudia-arabia-following-countries-yearslong-rivalry](https://www.foxnews.com/world/iranian-foreign-minister-visits-saudia-arabia-following-countries-yearslong-rivalry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:06:29+00:00

Saudia Arabia and Iran are reopening diplomatic missions following yearslong tensions between the two nations. On Thursday, Iran’s foreign minister traveled to Saudi Arabia.

## House Judiciary subpoenas DOJ, FBI for documents related to alleged collusion with Big Tech companies
 - [https://www.foxnews.com/politics/house-judiciary-subpoenas-doj-fbi-for-documents-related-to-alleged-collusion-with-big-tech-companies](https://www.foxnews.com/politics/house-judiciary-subpoenas-doj-fbi-for-documents-related-to-alleged-collusion-with-big-tech-companies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:00:53+00:00

EXCLUSIVE: The House Judiciary Committee has subpoenaed the Justice Department and the FBI for documents related to its investigation into Big tech censorship, Fox News Digital has learned.

## Huckabee Sanders pushes back on criticism after Arkansas removes AP African American studies course
 - [https://www.foxnews.com/media/huckabee-sanders-pushes-back-criticism-arkansas-removes-ap-african-american-studies-course](https://www.foxnews.com/media/huckabee-sanders-pushes-back-criticism-arkansas-removes-ap-african-american-studies-course)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T14:00:17+00:00

Gov. Sarah Huckabee Sanders defends her state&apos;s removal of AP African American studies in school on &quot;America&apos;s Newsroom.&quot;

## Oliver Anthony says he's turned down 8-million dollar offers since going viral: 'Nothing special about me'
 - [https://www.foxnews.com/media/oliver-anthony-turned-down-8-million-dollar-offers-since-going-viral-nothing-special-about-me](https://www.foxnews.com/media/oliver-anthony-turned-down-8-million-dollar-offers-since-going-viral-nothing-special-about-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:59:07+00:00

Singer Oliver Anthony discussed his real name, why he&apos;s turned down enormous offers from music reps and more in a Facebook post about his newfound fame.

## Germany reneges on pledge to meet NATO spending target: report
 - [https://www.foxnews.com/world/germany-reneges-pledge-meet-nato-spending-target-report](https://www.foxnews.com/world/germany-reneges-pledge-meet-nato-spending-target-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:55:57+00:00

Germany reportedly walked back a pledge to meet NATO&apos;s target of spending 2% of GDP on defense annually, instead vowing to uphold that average over five years.

## Militants still occupying school in Lebanon’s largest Palestinian camp as clashes between factions have ended
 - [https://www.foxnews.com/world/militants-still-occupying-school-lebanons-largest-palestinian-camp-clashes-between-factions-ended](https://www.foxnews.com/world/militants-still-occupying-school-lebanons-largest-palestinian-camp-clashes-between-factions-ended)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:54:39+00:00

A school compound led by the United Nations is still being occupied by militants in Lebanon’s largest Palestinian refugee camp, two weeks after clashes between factions have ended.

## Heads of Slovakia's spy agency, other intelligence officials accused of abusing power, criminal conspiracy
 - [https://www.foxnews.com/world/heads-slovakias-spy-agency-intelligence-officials-accused-abusing-power-criminal-conspiracy](https://www.foxnews.com/world/heads-slovakias-spy-agency-intelligence-officials-accused-abusing-power-criminal-conspiracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:53:49+00:00

Multiple Slovakian officials, including the head of the country&apos;s spy agency as well as five other intelligence officers, are being accused of abuse of power and criminal conspiracy.

## North Carolina Republicans finalize wide-ranging elections bill
 - [https://www.foxnews.com/politics/north-carolina-republicans-finalize-wide-ranging-elections-bill](https://www.foxnews.com/politics/north-carolina-republicans-finalize-wide-ranging-elections-bill)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:53:20+00:00

A wide-ranging GOP measure toughening voting regulations in North Carolina has been given final approval. The bill will head to Gov. Cooper who has expressed disapproval of the changes.

## Maui wildfires seen from International Space Station
 - [https://www.foxnews.com/science/maui-wildfires-seen-international-space-station](https://www.foxnews.com/science/maui-wildfires-seen-international-space-station)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:53:12+00:00

NASA has shared an image taken from the International Space Station last weekend which shows the scene of deadly Hawaii wildfires that devastated a Maui community.

## Red Cross to cease funding 25 Afghan hospitals amid aid concerns and financial constraints
 - [https://www.foxnews.com/world/red-cross-cease-funding-25-afghan-hospitals-amid-aid-concerns-financial-constraints](https://www.foxnews.com/world/red-cross-cease-funding-25-afghan-hospitals-amid-aid-concerns-financial-constraints)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:41:17+00:00

The International Committee of the Red Cross is concluding its financial support for 25 hospitals in Afghanistan by the end of August due to funding limitations.

## Bengals' Joe Mixon found not guilty of aggravated menacing charge
 - [https://www.foxnews.com/sports/bengals-joe-mixon-found-not-guilty-aggravated-menacing-charge](https://www.foxnews.com/sports/bengals-joe-mixon-found-not-guilty-aggravated-menacing-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:40:21+00:00

The Bengals running back was accused of pulling a gun on a woman during a traffic dispute before a playoff game. A judge found him not guilty following a four-day trial.

## NYC mayor fires back at Hochul on migrants, calls for executive order
 - [https://www.foxnews.com/politics/nyc-mayor-fires-back-hochul-migrants-calls-executive-order](https://www.foxnews.com/politics/nyc-mayor-fires-back-hochul-migrants-calls-executive-order)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:40:03+00:00

New York City Mayor Eric Adams responded after lawyers for Gov. Kathy Hochul criticized his handling of the migrant crisis assailing the city and surrounding counties.

## Panama Canal extends transit restrictions, raising concerns over consumer goods prices
 - [https://www.foxnews.com/world/panama-canal-extends-transit-restrictions-raising-concerns-consumer-goods-prices](https://www.foxnews.com/world/panama-canal-extends-transit-restrictions-raising-concerns-consumer-goods-prices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:39:09+00:00

The Panama Canal Authority announced an extension of its restrictions on vessel transit through the waterway until September 2nd, maintaining a daily maximum of 32 authorized vessels.

## Suspended Nigerian central bank governor faces indictment as graft charges escalate
 - [https://www.foxnews.com/world/suspended-nigerian-central-bank-governor-faces-indictment-graft-charges-escalate](https://www.foxnews.com/world/suspended-nigerian-central-bank-governor-faces-indictment-graft-charges-escalate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:36:30+00:00

Nigeria&apos;s suspended central bank governor, Godwin Emefiele, is scheduled to make an appearance in an Abuja high court, where he is expected to respond to a 20-count indictment.

## US set to escalate trade grievance with Mexico over genetically modified corn ban
 - [https://www.foxnews.com/world/us-set-escalate-trade-grievance-mexico-genetically-modified-corn-ban](https://www.foxnews.com/world/us-set-escalate-trade-grievance-mexico-genetically-modified-corn-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:34:41+00:00

The United States is reportedly poised to escalate its grievance with Mexico&apos;s prohibition on GM corn, asserting that the ban infringes upon the nations&apos; free-trade agreement.

## Hawaiian Electric knew of wildfire threat, but focused instead on mandated shift to renewable energy
 - [https://www.foxnews.com/us/hawaiian-electric-knew-wildfire-threat-focused-instead-mandated-shift-renewable-energy](https://www.foxnews.com/us/hawaiian-electric-knew-wildfire-threat-focused-instead-mandated-shift-renewable-energy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:29:58+00:00

Hawaiian Electric set wildfire safety to the side, in favor of pursuing a state-mandated shift toward renewable energy in recent years.

## North Dakota law enforcement officials reviewing video footage of fatal Fargo shooting ambush
 - [https://www.foxnews.com/us/north-dakota-law-enforcement-officials-reviewing-video-footage-fatal-fargo-shooting-ambush](https://www.foxnews.com/us/north-dakota-law-enforcement-officials-reviewing-video-footage-fatal-fargo-shooting-ambush)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:29:50+00:00

An officer was killed, and two others were critically wounded during an ambush in Fargo, North Dakota. Fargo officers are studying video footage related to the shooting.

## North Carolina Republicans give final approval to curb  Democratic Gov. Cooper’s appointment powers
 - [https://www.foxnews.com/politics/north-carolina-republicans-give-final-approval-curb-democratic-gov-coopers-appointment-powers](https://www.foxnews.com/politics/north-carolina-republicans-give-final-approval-curb-democratic-gov-coopers-appointment-powers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:20:30+00:00

Republicans in North Carolina have finalized legislation to curb Democratic Gov. Roy Cooper’s appointment powers over several state panels such as the transportation board.

## Virginia, home to one of America's most congested highways, set to open I-95 Express Lanes extension
 - [https://www.foxnews.com/us/virginia-home-one-americas-most-congested-highways-set-open-i-95-express-lanes-extension](https://www.foxnews.com/us/virginia-home-one-americas-most-congested-highways-set-open-i-95-express-lanes-extension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:08:34+00:00

A 10-mile extension of Virginia’s I-95 Express Lanes is set to open Thursday night. The $670 million project will allow drivers to commute from Stafford County to Fredericksburg.

## New Jersey Gov. Phil Murphy blasted for 'vast arrogance' on kids gender identity: 'Make schools lie to parents
 - [https://www.foxnews.com/media/new-jersey-gov-phil-murphy-blasted-vast-arrogance-kids-gender-identity-make-schools-lie-parents](https://www.foxnews.com/media/new-jersey-gov-phil-murphy-blasted-vast-arrogance-kids-gender-identity-make-schools-lie-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T13:00:29+00:00

New Jersey Gov. Phil Murphy was blasted for his stance on not informing parents of a child’s decision to identify as a different gender at school.

## Alaskan soldier set to make court appearance in death of wife whose body was found in a storm drain
 - [https://www.foxnews.com/us/alaskan-soldier-set-make-court-appearance-death-wife-whose-body-found-storm-drain](https://www.foxnews.com/us/alaskan-soldier-set-make-court-appearance-death-wife-whose-body-found-storm-drain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:57:24+00:00

An Army soldier in Alaska is suspected of killing his wife, whose body was found in a storm drain with a gunshot wound to the head. The man is scheduled for a hearing Thursday.

## Israel's Defense Ministry secures largest-ever defense deal selling missile defense system to Germany
 - [https://www.foxnews.com/world/israels-defense-ministry-secures-largest-ever-defense-deal-selling-missile-defense-system-germany](https://www.foxnews.com/world/israels-defense-ministry-secures-largest-ever-defense-deal-selling-missile-defense-system-germany)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:56:58+00:00

The United States approved a defense deal between Israel and Germany. Israel is selling a missile defense system to Germany for $3.5B in the country&apos;s largest-ever defense deal.

## Biden's 'two lies' in speech on the economy fact-checked: 'Just cannot stop himself'
 - [https://www.foxnews.com/media/bidens-two-lies-speech-economy-fact-checked-just-cannot-stop-himself](https://www.foxnews.com/media/bidens-two-lies-speech-economy-fact-checked-just-cannot-stop-himself)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:51:56+00:00

CNN&apos;s Daniel Dale fact-checked President Biden on Wednesday after he delivered a speech on the economy in Milwaukee, Wisconsin, where he told &quot;at least two lies.&quot;

## Labor Day Weekend 2023: Relaxing destinations to book a vacation
 - [https://www.foxnews.com/lifestyle/labor-day-weekend-relaxing-destinations-book-vacation](https://www.foxnews.com/lifestyle/labor-day-weekend-relaxing-destinations-book-vacation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:51:42+00:00

Labor Day Weekend is just around the corner. Check out these 15 destinations to consider booking for your 2023 getaway, whether it&apos;s traveling in the U.S. or out of the country.

## Biden campaign, DNC to leverage GOP debate for massive political messaging operation
 - [https://www.foxnews.com/politics/biden-campaign-dnc-leverage-gop-debate-massive-political-messaging-operation](https://www.foxnews.com/politics/biden-campaign-dnc-leverage-gop-debate-massive-political-messaging-operation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:49:58+00:00

The Biden campaign and the DNC are planning to highlight the contrast between the president&apos;s policies and “MAGA Republicans&quot; ahead of the first GOP primary debate next week.

## Kentucky Democratic gubernatorial candidate Beshear, GOP rival Cameron propose competing education plans
 - [https://www.foxnews.com/politics/kentucky-democratic-gubernatorial-candidate-beshear-gop-rival-cameron-propose-competing-education-plans](https://www.foxnews.com/politics/kentucky-democratic-gubernatorial-candidate-beshear-gop-rival-cameron-propose-competing-education-plans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:44:51+00:00

Democratic Gov. Andy Beshear and Republican Attorney General Daniel Cameron, both gubernatorial candidates in Kentucky, have offered competing proposals on pay increase for teachers.

## War in Ukraine raises questions about Russian doping ahead of 2024 Paris Olympics
 - [https://www.foxnews.com/sports/war-ukraine-raises-questions-russian-doping-ahead-2024-paris-olympics](https://www.foxnews.com/sports/war-ukraine-raises-questions-russian-doping-ahead-2024-paris-olympics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:41:34+00:00

Questions remain regarding how to make sure the Russian track team will be clean once the war in Ukraine ends. A doping task force held its final meeting this week before disbanding.

## Georgia man gets convicted in 1991 cold case death of teen found shot in the head on fire escape
 - [https://www.foxnews.com/us/georgia-man-gets-convicted-1991-cold-case-death-foster-teen-found-shot-head-fire-escape](https://www.foxnews.com/us/georgia-man-gets-convicted-1991-cold-case-death-foster-teen-found-shot-head-fire-escape)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:40:52+00:00

In 1991, police in Massachusetts found a 17-year-old foster girl on a fire escape shot in the head. Georgia man Rodney Daniels was found guilty Wednesday in the girl’s cold case murder.

## How to silence Amazon Alexa's 'by the way' suggestions
 - [https://www.foxnews.com/tech/how-silence-amazon-alexa-by-the-way-suggestions](https://www.foxnews.com/tech/how-silence-amazon-alexa-by-the-way-suggestions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:39:03+00:00

Tired of hearing your Alexa device&apos;s suggestions? Kurt &quot;The CyberGuy&quot; Knutsson shares steps on how to silence Amazon&apos;s virtual assistant.

## Illinois to provide funeral, burial for migrant child who died on bus
 - [https://www.foxnews.com/world/illinois-provide-funeral-burial-migrant-child-died-bus](https://www.foxnews.com/world/illinois-provide-funeral-burial-migrant-child-died-bus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:38:45+00:00

The state-affiliated Illinois Welcoming Center will be handling the funeral and burial of a 3-year-old child who died on a migrant bus from Texas to Chicago.

## This GOP presidential candidate has a higher favorability rating among Democrats than voters in his own party
 - [https://www.foxnews.com/politics/gop-presidential-candidate-higher-favorability-rating-democrats-voters](https://www.foxnews.com/politics/gop-presidential-candidate-higher-favorability-rating-democrats-voters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:35:40+00:00

A Quinnipiac University poll found that presidential candidate Chris Christie has a higher favorability rating among Democrats than voters in the Republican Party.

## Migrant wanted by ICE, released under controversial NY bail reform, arrested again on rape charge
 - [https://www.foxnews.com/us/migrant-wanted-ice-released-controversial-ny-bail-reform-arrested-again-rape-charge](https://www.foxnews.com/us/migrant-wanted-ice-released-controversial-ny-bail-reform-arrested-again-rape-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:30:01+00:00

An illegal immigrant released in a prior felony case due to New York&apos;s bail reform laws was arrested again in an alleged violent rape in Delaware County.

## Tim McGraw and Faith Hill faced challenges in 27-year marriage but this promise kept them together
 - [https://www.foxnews.com/entertainment/tim-mcgraw-faith-hill-faced-challenges-27-year-marriage-promise-kept-them-together](https://www.foxnews.com/entertainment/tim-mcgraw-faith-hill-faced-challenges-27-year-marriage-promise-kept-them-together)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:29:04+00:00

Country star Tim McGraw revealed the secret behind his successful 27-year marriage to Faith Hill. The couple has three children together.

## White House counsel departing as House Republican investigations heat up
 - [https://www.foxnews.com/politics/white-house-counsel-departing-house-republican-investigations-heat](https://www.foxnews.com/politics/white-house-counsel-departing-house-republican-investigations-heat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:23:38+00:00

The White House announce its top counsel, who helped craft Biden&apos;s student loan handout and U.S.-Mexico border policy, would be leaving next month. His replacement was not announced.

## NY county stops accepting migrants after alleged sexual assaults: 'We are paying for all of this'
 - [https://www.foxnews.com/media/ny-county-stops-accepting-migrants-alleged-sexual-assaults-paying](https://www.foxnews.com/media/ny-county-stops-accepting-migrants-alleged-sexual-assaults-paying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:23:16+00:00

Republican candidate for Erie County executive Chrissy Casilio called out &quot;radical left&quot; leaders for not standing up to protect the community sooner.

## Major break in Microsoft exec Jared Bridegan's murder case: prosecutors
 - [https://www.foxnews.com/us/major-break-microsoft-exec-jared-bridegans-murder-case-prosecutors](https://www.foxnews.com/us/major-break-microsoft-exec-jared-bridegans-murder-case-prosecutors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:14:20+00:00

Florida authorities said Thursday there has been a significant development in the Jared Bridegan murder probe and further details will be disclosed at an afternoon press conference.

## Private jet in Malaysia crash-lands along highway, killing 10: video
 - [https://www.foxnews.com/world/private-jet-malaysia-crash-lands-highway-killing-10-video](https://www.foxnews.com/world/private-jet-malaysia-crash-lands-highway-killing-10-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:09:32+00:00

At least 10 people are dead near Kuala Lumpur, Malaysia, on Thursday after a small private jet crash landed into a highway there, striking a motorcycle and a car.

## Former Target exec says Pride 'misstep' partly responsible for recent sales dip: 'Certainly impacted them'
 - [https://www.foxnews.com/media/former-target-exec-pride-misstep-partly-responsible-recent-sales-dip-certainly-impacted-them](https://www.foxnews.com/media/former-target-exec-pride-misstep-partly-responsible-recent-sales-dip-certainly-impacted-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T12:02:27+00:00

Former Target Vice Chairman Gerald Storch explained the Target Corp.&apos;s recent sales drop, saying one contributing factor was its 2023 Pride collection.

## Short questions with Dana Perino
 - [https://www.foxnews.com/lifestyle/short-questions-dana-perino-brian-kilmeade](https://www.foxnews.com/lifestyle/short-questions-dana-perino-brian-kilmeade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:59:32+00:00

For her newest &quot;Short questions&quot; piece for Fox News Digital, Dana Perino talks to Brian Kilmeade — who reveals what inspires him to &quot;read everything&quot; and why he&apos;s optimistic about America.

## Britney Spears speaks out for first time following Sam Asghari divorce news: 'Buying a horse soon'
 - [https://www.foxnews.com/entertainment/britney-spears-speaks-out-first-time-following-sam-asghari-divorce-news-buying-horse-soon](https://www.foxnews.com/entertainment/britney-spears-speaks-out-first-time-following-sam-asghari-divorce-news-buying-horse-soon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:56:59+00:00

Britney Spears shared her first social media post since the news her husband Sam Asghari filed for divorce broke. The pop star announced plans to buy a horse.

## Colorado hiker stumbles across WWII-era land mine in forest near former US Army training facility
 - [https://www.foxnews.com/us/colorado-hiker-stumbles-land-mine-forest-near-former-us-army-training-facility](https://www.foxnews.com/us/colorado-hiker-stumbles-land-mine-forest-near-former-us-army-training-facility)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:46:58+00:00

A hiker neear an old Army training facility in Colorado found a land mine that had been left behind from training exercises during World War II.

## Hawaii governor vows to protect locals from outside buyers seeking real estate opportunities in Maui
 - [https://www.foxnews.com/us/hawaii-governor-vows-protect-locals-outsider-buyers-seeking-real-estate-opportunities-maui](https://www.foxnews.com/us/hawaii-governor-vows-protect-locals-outsider-buyers-seeking-real-estate-opportunities-maui)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:45:55+00:00

As wildfires rage through Lahaina, the governor of Hawaii has vowed to protect locals from getting displaced by affluent outsider buyers and real estate opportunists eyeing a rebuilt Maui.

## Could Trump pardon himself if convicted of Georgia charges? Experts weigh in
 - [https://www.foxnews.com/politics/could-trump-pardon-himself-from-georgia-charges-experts-weigh-in](https://www.foxnews.com/politics/could-trump-pardon-himself-from-georgia-charges-experts-weigh-in)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:38:57+00:00

Experts told Fox News Digital that former President Trump cannot pardon himself on state charges in Georgia but incarcerating him for those crimes as president could be complicated and unlikely.

## Jerry Moss, legendary A&M founder and executive, dead at 88
 - [https://www.foxnews.com/entertainment/jerry-moss-legendary-am-founder-executive-dead-88](https://www.foxnews.com/entertainment/jerry-moss-legendary-am-founder-executive-dead-88)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:37:41+00:00

Jerry Moss, a legendary recording executive and founder of A&amp;M Records, died Wednesday at his home in Bel Air, California, his family said in a statement. He was 88.

## Top conservative previews next government spending showdown, unveils demands to curb Biden 'abuse of power'
 - [https://www.foxnews.com/politics/chip-roy-government-spending-showdown-demands-to-curb-biden-abuse-of-power](https://www.foxnews.com/politics/chip-roy-government-spending-showdown-demands-to-curb-biden-abuse-of-power)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:37:27+00:00

Rep. Chip Roy is calling on House Republicans to oppose any deal to fund the government unless it includes key conservative policy demands to take on the Biden administration.

## DeSantis won't say what he'd do if one of his children is gay or trans: report
 - [https://www.foxnews.com/politics/desantis-wont-say-children-gay-trans-report](https://www.foxnews.com/politics/desantis-wont-say-children-gay-trans-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:35:35+00:00

Florida Gov. Ron DeSantis would not tell Time magazine how he would respond should one of his children be gay or transgender, in a new interview published Wednesday.

## Liberal columnists seize on 'Blind Side' controversy: 'White savior' story looks 'even more fake' 'than before
 - [https://www.foxnews.com/media/liberal-columnists-seize-blind-side-controversy-white-savior-story-looks-fake-before](https://www.foxnews.com/media/liberal-columnists-seize-blind-side-controversy-white-savior-story-looks-fake-before)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:30:20+00:00

Liberal columnists pounced on bombshell claims by former NFL player Michael Oher to attack &quot;The Blind Side,&quot; calling the inspirational film &quot;even more fake than before.&quot;

## Beverly Hills musician who co-wrote Katy Perry song vanishes without a trace: 'Could be anywhere'
 - [https://www.foxnews.com/us/beverly-hills-musician-co-wrote-katy-perry-song-vanishes-without-trace](https://www.foxnews.com/us/beverly-hills-musician-co-wrote-katy-perry-song-vanishes-without-trace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:29:01+00:00

Camela Leierth-Segura, a musician who co-wrote the Katy Perry song &quot;Walking on Air,&quot; has been missing since June, and friends are concerned

## 'Tan Mom' Patricia Krentcil is running for the US Senate in Florida
 - [https://www.foxnews.com/politics/tan-mom-patricia-krentcil-running-us-senate-florida](https://www.foxnews.com/politics/tan-mom-patricia-krentcil-running-us-senate-florida)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:26:25+00:00

Patricia Krentcil, perhaps better known as &quot;Tan Mom,&quot; announced she would be running for the U.S. Senate, using fame from her viral arrest and reality television series.

## Family of slain pregnant CO woman files suit against the police who mistook 27-year-old as robbery suspect
 - [https://www.foxnews.com/us/family-slain-pregnant-co-woman-files-suit-against-police-mistook-27-year-old-robbery-suspect](https://www.foxnews.com/us/family-slain-pregnant-co-woman-files-suit-against-police-mistook-27-year-old-robbery-suspect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:26:03+00:00

A wrongful death lawsuit has been filed against the Colorado police. In 2021, officers mistook a pregnant woman for a robbery suspect and killed her, along with her unborn child.

## Maine man sentenced to 25 years for death of infant son; Case renews criticism of state's child welfare agency
 - [https://www.foxnews.com/us/maine-man-sentenced-25-years-death-infant-son-case-renews-criticism-states-child-welfare-agency](https://www.foxnews.com/us/maine-man-sentenced-25-years-death-infant-son-case-renews-criticism-states-child-welfare-agency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:22:57+00:00

A Maine father has been sentenced to 25 years in prison for the death of his 1-year-old son. The case has renewed criticism in the state&apos;s child welfare agency.

## KS prosecutor claims police raid of newspaper wasn't supported by evidence, police should return seized items
 - [https://www.foxnews.com/us/ks-prosecutor-claims-police-raid-newspaper-wasnt-supported-evidence-police-should-return-seized-items](https://www.foxnews.com/us/ks-prosecutor-claims-police-raid-newspaper-wasnt-supported-evidence-police-should-return-seized-items)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:22:25+00:00

A prosecutor says police should return laptops and phones taken during the raid of a small Kansas weekly newspaper last week. The prosecutor says the raid wasn&apos;t supported by evidence.

## Prominent Haitian gang leader vows to fight foreign armed forces as PM calls for international intervention
 - [https://www.foxnews.com/world/prominent-haitian-gang-leader-vows-fight-foreign-armed-forces-pm-calls-international-intervention](https://www.foxnews.com/world/prominent-haitian-gang-leader-vows-fight-foreign-armed-forces-pm-calls-international-intervention)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:22:17+00:00

Gangs have taken control of most of Haiti’s capital, prompting Kenya and the US to ramp up interventional efforts. The country’s gang leader has vowed to fight any foreign troops.

## Russian authorities open criminal investigation into leader of prominent election monitoring group
 - [https://www.foxnews.com/world/russian-authorities-open-criminal-investigation-leader-prominent-election-monitoring-group](https://www.foxnews.com/world/russian-authorities-open-criminal-investigation-leader-prominent-election-monitoring-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:21:49+00:00

A criminal investigation into Grigory Melkonyants has been opened by Russian authorities. Melkonyants is one of the leaders of an independent election watchdog.

## Out-of-control wildfire on Spanish island leads to thousands of evacuations
 - [https://www.foxnews.com/world/out-of-control-wildfire-spanish-island-leads-thousands-evacuations](https://www.foxnews.com/world/out-of-control-wildfire-spanish-island-leads-thousands-evacuations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:15:31+00:00

A wildfire in the Canary Islands in Spain has led to thousands of evacuations and confinements. Around 250 firefighters and army members are trying to put the blaze out.

## Interior secretary accused of 'apparent ethical breaches' over oil and gas drilling ban
 - [https://www.foxnews.com/politics/interior-sec-hit-accused-apparent-ethical-breaches-over-oil-gas-drilling-ban](https://www.foxnews.com/politics/interior-sec-hit-accused-apparent-ethical-breaches-over-oil-gas-drilling-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:11:50+00:00

A government watchdog organization filed an IG complaint against Interior Secretary Deb Haaland alleging &quot;apparent ethical breaches&quot; regarding an oil and gas drilling ban.

## Top international chess federation bars transgender females from competing in women's events
 - [https://www.foxnews.com/sports/top-international-chess-federation-bars-transgender-females-competing-in-womens-events](https://www.foxnews.com/sports/top-international-chess-federation-bars-transgender-females-competing-in-womens-events)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T11:08:29+00:00

The International Chess Federation said the organization will bar transgender women from competing in official events for females.

## Potential candidate to lead Chicago health department apologizes for lying about having Harvard PhD
 - [https://www.foxnews.com/politics/candidate-lead-chicago-health-department-apologizes-for-lying-about-having-harvard-phd](https://www.foxnews.com/politics/candidate-lead-chicago-health-department-apologizes-for-lying-about-having-harvard-phd)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:59:23+00:00

A possible candidate to lead Chicago’s Department of Public Health, Eric Reinhart, posted a public apology for &quot;misrepresenting&quot; himself as completing his Ph.D. at Harvard.

## GOP candidate fighting for debate stage spot says candidates 'shouldn't stay' in race if they don't qualify
 - [https://www.foxnews.com/politics/gop-candidate-fighting-debate-stage-spot-says-candidates-shouldnt-stay-race-dont-qualify](https://www.foxnews.com/politics/gop-candidate-fighting-debate-stage-spot-says-candidates-shouldnt-stay-race-dont-qualify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:52:43+00:00

Mayor Francis Suarez of Miami, Florida, is optimistic he&apos;ll make the stage at next week&apos;s Fox News-hosted first Republican presidential nomination debate.

## CNN legal analyst doubts Fani Willis, says there is 'no planet' where Trump is tried in March: 'Not happening'
 - [https://www.foxnews.com/media/cnn-legal-analyst-doubts-fani-willis-no-planet-where-trump-tried-march-not-happening](https://www.foxnews.com/media/cnn-legal-analyst-doubts-fani-willis-no-planet-where-trump-tried-march-not-happening)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:47:49+00:00

CNN&apos;s Elie Honig argued on Wednesday that there was &quot;no planet&quot; in which Donald Trump&apos;s trial in Georgia would happen in March as DA Fani Willis has said.

## Chicago man seen sexually assaulting girl during remote-learning class sentenced to 11 years
 - [https://www.foxnews.com/us/chicago-man-seen-sexually-assaulting-girl-remote-learning-class-sentenced-11-years](https://www.foxnews.com/us/chicago-man-seen-sexually-assaulting-girl-remote-learning-class-sentenced-11-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:46:26+00:00

A Chicago man who sexually assaulted his 7-year-old female relative while she was participating in an online class was sentenced to serve 11 years in prison on Wednesday.

## Buffalo shooting survivors sue social media giants they argue 'addicted,' 'radicalized' killer gunman
 - [https://www.foxnews.com/us/buffalo-shooting-survivors-sue-social-media-giants-argue-addicted-radicalized-killer-gunman](https://www.foxnews.com/us/buffalo-shooting-survivors-sue-social-media-giants-argue-addicted-radicalized-killer-gunman)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:38:27+00:00

YouTube and Reddit are accused of contributing to the &quot;radicalization&quot; of the Tops supermarket shooter in Buffalo, New York, in a pair of new lawsuits.

## Police say possible murder-suicide left 5 Oklahoma City family members dead, including 3 children
 - [https://www.foxnews.com/us/police-possible-murder-suicide-left-5-oklahoma-city-family-members-dead-3-children](https://www.foxnews.com/us/police-possible-murder-suicide-left-5-oklahoma-city-family-members-dead-3-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:29:46+00:00

The Oklahoma City Police Department said five victims of the same family are dead in a possible murder-suicide at a residence near Melrose Lane and Rockwell.

## Russian lunar probe enters moon’s orbit, first time since 1976
 - [https://www.foxnews.com/world/russian-lunar-probe-enters-moons-orbit-first-time-since-1976](https://www.foxnews.com/world/russian-lunar-probe-enters-moons-orbit-first-time-since-1976)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:27:01+00:00

Russia&apos;s Luna-25 moon probe has entered lunar orbit after a successful space flight launched on Aug. 11, the first of its kind from Russia since the former Soviet Union.

## Drunken Calif. judge gunned down wife in front of son, asked cops to shoot him, court docs say: 'I f---ed up'
 - [https://www.foxnews.com/us/drunken-calif-judge-gunned-wife-front-son-asked-cops-shoot-court-docs-say](https://www.foxnews.com/us/drunken-calif-judge-gunned-wife-front-son-asked-cops-shoot-court-docs-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:25:18+00:00

Orange County Judge Jeffrey Ferguson allegedly shot his wife dead in front of their son with a handgun he kept in an ankle holster, court documents reveal.

## Miss Universe contestants sound alarm they allegedly had to strip off clothes for 'body checks'
 - [https://www.foxnews.com/world/miss-universe-contestants-sound-alarm-allegedly-had-strip-off-clothes-body-checks](https://www.foxnews.com/world/miss-universe-contestants-sound-alarm-allegedly-had-strip-off-clothes-body-checks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:22:40+00:00

At least seven Miss Universe contestants in Indonesia reported contest officials to police for sexual harassment, after allegedly being forced to take off clothing for body checks.

## CA female inmates file suit, citing prison sex abuse hasn’t stopped despite previous prosecutions of officers
 - [https://www.foxnews.com/us/ca-female-inmates-file-suit-citing-prison-sex-abuse-hasnt-stopped-despite-previous-prosecutions-officers](https://www.foxnews.com/us/ca-female-inmates-file-suit-citing-prison-sex-abuse-hasnt-stopped-despite-previous-prosecutions-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:21:25+00:00

Several inmates at a San Francisco Bay Area lockup are suing the federal government for not fulfilling its promises to stop rampant sex abuse and exploitation in its women’s prisons.

## Florida art museum files lawsuit over forged Basquiat paintings, claiming former CEO profited from sales
 - [https://www.foxnews.com/us/florida-art-museum-files-lawsuit-forged-basquiat-paintings-claiming-former-ceo-profited-sales](https://www.foxnews.com/us/florida-art-museum-files-lawsuit-forged-basquiat-paintings-claiming-former-ceo-profited-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:19:10+00:00

The Orlando Museum of Art has sued former CEO Aaron De Groft over a forged paintings scheme. The museum displayed dozens of forged artworks under the name of Jean-Michel Basquiat

## Coast Guard suspends search for missing Florida boater days after finding his empty vessel miles offshore
 - [https://www.foxnews.com/us/coast-guard-suspends-search-missing-florida-boater-days-finding-empty-vessel-miles-offshore](https://www.foxnews.com/us/coast-guard-suspends-search-missing-florida-boater-days-finding-empty-vessel-miles-offshore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:17:05+00:00

The search for Andre Nolasco, 57, was suspended Wednesday after U.S. Coast Guard crews combed 1,514 square miles off the coast of Port Richey, Florida.

## Sweden raises terrorism alert to second-highest setting following recent Quran burnings
 - [https://www.foxnews.com/world/sweden-raises-terrorism-alert-second-highest-setting-following-recent-quran-burnings](https://www.foxnews.com/world/sweden-raises-terrorism-alert-second-highest-setting-following-recent-quran-burnings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:16:45+00:00

Following Quran burnings in Sweden, the country has raised its terrorism alert level to the second-highest setting. Police have allowed the burnings, citing freedom of speech.

## Son of ex-NFL player found guilty of killing parents, sentenced to life in prison
 - [https://www.foxnews.com/sports/son-ex-nfl-player-found-guilty-killing-parents-sentenced-life-prison](https://www.foxnews.com/sports/son-ex-nfl-player-found-guilty-killing-parents-sentenced-life-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:12:19+00:00

The son of a former NFL player was found guilty of the 2016 slaying of his parents on Wednesday. He was sentenced to life in prison without parole after 40 years.

## Former Sen. McCaskill says 90-year-old Dianne Feinstein staying in office is doing 'real damage to her legacy'
 - [https://www.foxnews.com/media/former-sen-mccaskill-90-year-old-dianne-feinstein-staying-office-doing-real-damage-legacy](https://www.foxnews.com/media/former-sen-mccaskill-90-year-old-dianne-feinstein-staying-office-doing-real-damage-legacy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:03:48+00:00

Former Sen. Claire McCaskill said 90-year-old Sen. Dianne Feinstein, D-Calif., was doing “real damage to her legacy&quot; by continuing to stay in power.

## The biggest thing parents can do for back-to-school season
 - [https://www.foxnews.com/opinion/biggest-thing-parents-can-do-back-school-season](https://www.foxnews.com/opinion/biggest-thing-parents-can-do-back-school-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T10:00:31+00:00

The pressures of academic performance, social interactions and the uncertainties of the future can lead to feelings of anxiety and apprehension for many students.

## Bipartisan group of lawmakers demand Biden offload seized Iranian oil tanker
 - [https://www.foxnews.com/us/bipartisan-group-of-lawmakers-demand-biden-offload-seized-iranian-oil-tanker](https://www.foxnews.com/us/bipartisan-group-of-lawmakers-demand-biden-offload-seized-iranian-oil-tanker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:58:25+00:00

A bipartisan group of 10 lawmakers is urging President Biden to resolve delays in offloading a seized tanker off the coast of Texas containing sanctioned Iranian oil.

## Jamie Foxx says he's 'thankful' after medical complication, antisemitic controversy
 - [https://www.foxnews.com/entertainment/jamie-foxx-thankful-medical-complication-antisemitic-controversy](https://www.foxnews.com/entertainment/jamie-foxx-thankful-medical-complication-antisemitic-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:58:23+00:00

&quot;Back in Action&quot; star Jamie Foxx, 55, shared that he&apos;s &quot;finally startin to feel like myself&quot; after being hospitalized for months due to a mystery illness.

## E. coli strain linked to leafy greens associated with outbreaks, research led by CDC doctor says
 - [https://www.foxnews.com/health/e-coli-strain-linked-leafy-greens-associated-outbreaks-research-led-cdc-doctor](https://www.foxnews.com/health/e-coli-strain-linked-leafy-greens-associated-outbreaks-research-led-cdc-doctor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:48:52+00:00

A strain of E. coli associated with leafy greens has been a source of illness for years, according to an article published in a Centers for Disease Control and Prevention journal.

## 9-year-old autistic boy who went missing from Brooklyn Ikea found dead: police
 - [https://www.foxnews.com/us/9-year-old-autistic-boy-went-missing-brooklyn-ikea-found-dead-police](https://www.foxnews.com/us/9-year-old-autistic-boy-went-missing-brooklyn-ikea-found-dead-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:41:30+00:00

New York police said a 9-year-old boy who went missing in Brooklyn, New York, after he exited an Ikea in Red Hook, where his family was shopping, was found dead.

## NM bill proposes energy companies to compensate field worker's health care costs related to air pollution
 - [https://www.foxnews.com/politics/nm-bill-proposes-energy-companies-compensate-field-workers-health-care-costs-related-air-pollution](https://www.foxnews.com/politics/nm-bill-proposes-energy-companies-compensate-field-workers-health-care-costs-related-air-pollution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:40:57+00:00

New Mexico oil field workers with ailments caused by smog and methane could possibly seek health care reimbursements under a measure proposed by Democratic Rep. Gabe Vasquez.

## Multiple North Dakota newspapers cease publication following closure of century-old family business
 - [https://www.foxnews.com/us/multiple-north-dakota-newspapers-cease-publication-closure-century-old-family-business](https://www.foxnews.com/us/multiple-north-dakota-newspapers-cease-publication-closure-century-old-family-business)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:40:09+00:00

After Fordville-based Ness Press closed in early August, at least eight weekly publications in North Dakota will be forced to cease publication.

## Americans overwhelmingly oppose Biden’s handling of the economy, poll finds
 - [https://www.foxnews.com/politics/americans-overwhelmingly-oppose-bidens-handling-economy-poll-finds](https://www.foxnews.com/politics/americans-overwhelmingly-oppose-bidens-handling-economy-poll-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:39:56+00:00

President Biden&apos;s approval rating on the economy remains desperately low, despite his efforts to promote the &quot;Bidenomics&quot; message from the White House.

## Over 60 migrants who departed Senegal for Spain in monthlong voyage feared dead
 - [https://www.foxnews.com/world/over-60-migrants-who-departed-senegal-spain-monthlong-voyage-feared-dead](https://www.foxnews.com/world/over-60-migrants-who-departed-senegal-spain-monthlong-voyage-feared-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:37:56+00:00

Dozens of migrants who departed Senegal for Spain on July 10 are feared to be dead. About 38 passengers of the migrant boat were rescued off the coast of West Africa near Cape Verde.

## Over $1.4 million worth of pangolin scales were seized by Thai authorities in Kalasin
 - [https://www.foxnews.com/world/over-1-4-million-worth-pangolin-scales-seized-thai-authorities-kalasin](https://www.foxnews.com/world/over-1-4-million-worth-pangolin-scales-seized-thai-authorities-kalasin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:37:11+00:00

Over a ton of pangolin scales were seized by Thai authorities in the province of Kalasin. The scales were estimated to be worth more than $1.4 million.

## ICE agents arrest MS-13 member on El Salvador's Top 100 most-wanted
 - [https://www.foxnews.com/us/ice-agents-arrest-ms-13-member-el-salvadors-top-100-most-wanted](https://www.foxnews.com/us/ice-agents-arrest-ms-13-member-el-salvadors-top-100-most-wanted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:32:49+00:00

Immigration and Customs Enforcement officials announced two arrests of violent criminals this week, including an MS-13 member on El Salvador&apos;s Top 100 Most Wanted List

## Comer demands National Archives fork over unredacted emails involving Hunter Biden, Ukraine, Burisma
 - [https://www.foxnews.com/politics/comer-demands-national-archives-fork-over-unredacted-emails-hunter-biden-burisma](https://www.foxnews.com/politics/comer-demands-national-archives-fork-over-unredacted-emails-hunter-biden-burisma)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:30:42+00:00

House Oversight Committee Chairman Rep. James Comer is demanding unredacted emails involving then-Vice President Joe Biden and his son from the National Archives.

## Bruce Springsteen cancels concert hours before start time due to illness
 - [https://www.foxnews.com/entertainment/bruce-springsteen-cancels-concert-hours-before-start-time-illness](https://www.foxnews.com/entertainment/bruce-springsteen-cancels-concert-hours-before-start-time-illness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:20:12+00:00

Bruce Springsteen canceled a Philadelphia concert at the last minute due to an unnamed illness. Another concert scheduled for Friday was also canceled.

## Indiana test scores show nearly 20% of 3rd graders struggle to read: Education secretary calls it a 'crisis'
 - [https://www.foxnews.com/us/indiana-test-scores-show-nearly-20-3rd-graders-struggle-read-education-secretary-calls-crisis](https://www.foxnews.com/us/indiana-test-scores-show-nearly-20-3rd-graders-struggle-read-education-secretary-calls-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T09:00:45+00:00

Test scores released on Aug. 16, 2023, in Indiana, showed that nearly 20% of third graders in the state struggle to read. The state&apos;s education secretary called it a &quot;crisis.&quot;

## World's top female triathletes swim in Paris' Seine River ahead of next year's Paris Olympics
 - [https://www.foxnews.com/sports/worlds-top-female-triathletes-swim-paris-seine-river-ahead-next-years-paris-olympics](https://www.foxnews.com/sports/worlds-top-female-triathletes-swim-paris-seine-river-ahead-next-years-paris-olympics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:59:37+00:00

The top triathletes in the world swam in the Seine River in France on Aug. 17, 2023. A triathlon event in the river is scheduled to take place until Aug. 20, 2023.

## 'Blind Side' inspiration Michael Oher wrote about conservatorship in 2011 book: 'We were a family'
 - [https://www.foxnews.com/sports/blind-side-inspiration-michael-oher-wrote-conservatorship-2011-book-we-were-family](https://www.foxnews.com/sports/blind-side-inspiration-michael-oher-wrote-conservatorship-2011-book-we-were-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:57:22+00:00

Former NFL player Michael Oher, and the inspiration of &quot;The Blind Side,&quot; wrote about his conservatorship in his 2011 memoir, &quot;I Beat The Odds: From Homeless, To The Blindside.&quot;

## NYT columnist rips progressive term 'sex worker' as harmful: 'Enables sex buyers to justify their own role'
 - [https://www.foxnews.com/media/nyt-columnist-rips-progressive-term-sex-worker-harmful-enables-sex-buyers-justify-own-role](https://www.foxnews.com/media/nyt-columnist-rips-progressive-term-sex-worker-harmful-enables-sex-buyers-justify-own-role)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:52:33+00:00

New York Times columnist and “Pornified&quot; author Pamela Paul criticized the increasing popularity of the term “sex worker&quot; in a column published Thursday.

## Kim Jong Un stealing deceased grandfather’s political title, North Korean observers say
 - [https://www.foxnews.com/world/kim-jong-un-stealing-deceased-grandfathers-political-title-north-korean-observers](https://www.foxnews.com/world/kim-jong-un-stealing-deceased-grandfathers-political-title-north-korean-observers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:50:23+00:00

North Korean dictator Kim Jong Un has adopted the prestigious title of &quot;Great President&quot; of the ruling party in recent months, according to observers.

## Fox News Power Rankings: In the conversation
 - [https://www.foxnews.com/politics/fox-news-power-rankings-in-conversation](https://www.foxnews.com/politics/fox-news-power-rankings-in-conversation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:46:55+00:00

Former President Trump has a solid lead in the GOP primary in Fox News&apos; Power Rankings, but Vivek Ramaswamy, Nikki Haley, Mike Pence and others are &apos;in the conversation&apos;

## 129 Muslims arrested in Pakistan following mob attacks on churches, homes of minority Christians
 - [https://www.foxnews.com/world/129-muslims-arrested-pakistan-following-mob-attacks-churches-homes-minority-christians](https://www.foxnews.com/world/129-muslims-arrested-pakistan-following-mob-attacks-churches-homes-minority-christians)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:40:04+00:00

Over a hundred Muslims were arrested overnight for attacking Pakistan’s community of minority Christians in response to the desecration of a Quran by a Christian suspect.

## Texas deputy shot during traffic stop; authorities issue Blue Alert for 2 men
 - [https://www.foxnews.com/us/texas-deputy-shot-traffic-stop-authorities-issue-blue-alert-2-men](https://www.foxnews.com/us/texas-deputy-shot-traffic-stop-authorities-issue-blue-alert-2-men)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:28:12+00:00

A manhunt in Texas is ongoing after a Harris County Sheriff&apos;s deputy was critically wounded in a shooting during a traffic stop on Wednesday evening.

## North Korea prepares weapons tests, may launch spy satellite, South Korean spy agency says
 - [https://www.foxnews.com/world/north-korea-prepares-weapons-tests-may-launch-spy-satellite-south-korean-spy-agency-says](https://www.foxnews.com/world/north-korea-prepares-weapons-tests-may-launch-spy-satellite-south-korean-spy-agency-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:04:56+00:00

A spy agency in South Korea said that North Korea is preparing to conduct more weapons tests and may even attempt to launch a satellite for military reconnaissance.

## What is Parkinson's disease? Symptoms, causes, ways to cope with diagnosis
 - [https://www.foxnews.com/lifestyle/what-is-parkinsons-disease](https://www.foxnews.com/lifestyle/what-is-parkinsons-disease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:02:17+00:00

Parkinson&apos;s disease affects the brain, usually in older people. There is no cure for the condition, but there are things you can do to help alleviate the symptoms it brings.

## US law enforcement deaths on pace to rise as officers face increasing threats of violence
 - [https://www.foxnews.com/us/us-law-enforcement-deaths-pace-rise-officers-face-increasing-threats-violence](https://www.foxnews.com/us/us-law-enforcement-deaths-pace-rise-officers-face-increasing-threats-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T08:00:04+00:00

The national death toll of police officers killed in the line of duty this year reached 41 as of Aug. 9, on pace to eclipse last year&apos;s total, the FBI reported.

## Heat will impact central US as thunderstorms forecast across country
 - [https://www.foxnews.com/us/heat-impact-central-us-thunderstorms-forecast-across-country](https://www.foxnews.com/us/heat-impact-central-us-thunderstorms-forecast-across-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:59:32+00:00

As extreme heat expands to the central U.S. states, Tropical Storm Hilary is churning in the Pacific and is expected to bring related impacts to southern California over the weekend.

## 6th person dies following Pennsylvania home explosion
 - [https://www.foxnews.com/us/sixth-person-dies-following-pennsylvania-home-explosion](https://www.foxnews.com/us/sixth-person-dies-following-pennsylvania-home-explosion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:56:05+00:00

The co-owner of a home in Plum, Pennsylvania that exploded over the weekend has died at a local hospital after suffering burn injuries in the blast.

## Trump's proposed Atlanta court date on Super Tuesday eve 'planned and coordinated': Ex-attorney general
 - [https://www.foxnews.com/media/trumps-proposed-atlanta-court-date-super-tuesday-eve-planned-coordinated-attorney-general](https://www.foxnews.com/media/trumps-proposed-atlanta-court-date-super-tuesday-eve-planned-coordinated-attorney-general)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:55:51+00:00

Fulton County, Georgia, District Attorney Fani Willis took criticism over her proposal of a court commencement date that falls one day prior to Super Tuesday.

## Minnesota woman sentenced to over 7 years for attempting to obtain $7 million in pandemic aid
 - [https://www.foxnews.com/us/minnesota-woman-sentenced-over-7-years-attempting-obtain-7-million-pandemic-aid](https://www.foxnews.com/us/minnesota-woman-sentenced-over-7-years-attempting-obtain-7-million-pandemic-aid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:53:53+00:00

Tequisha Solomon, a 40-year-old woman from Minnesota, was sentenced to seven years in prison for attempting to obtain roughly $7 million in pandemic aid.

## Wisconsin Elections Commission declines to vote on future of state's top election official
 - [https://www.foxnews.com/politics/wisconsin-elections-commission-declines-vote-future-states-top-election-official](https://www.foxnews.com/politics/wisconsin-elections-commission-declines-vote-future-states-top-election-official)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:35:13+00:00

On Aug. 16, 2023, the state elections commission in Wisconsin declined to vote on whether Meagan Wolfe should appear before a Senate hearing on her reappointment.

## Joe Rogan claims Biden scandals are being exposed 'on purpose': Democrats 'want to get rid of him'
 - [https://www.foxnews.com/media/joe-rogan-claims-biden-scandals-exposed-purpose-democrats-rid](https://www.foxnews.com/media/joe-rogan-claims-biden-scandals-exposed-purpose-democrats-rid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:35:00+00:00

Joe Rogan spoke on a podcast about the President Biden&apos;s mounting scandals, marveling how more journalists are not calling him out for his alleged dealings.

## Ohio Secretary of State Frank LaRose fires top aide for criticizing Donald Trump on social media
 - [https://www.foxnews.com/politics/ohio-secretary-state-frank-larose-fires-top-aide-criticizing-donald-trump-social-media](https://www.foxnews.com/politics/ohio-secretary-state-frank-larose-fires-top-aide-criticizing-donald-trump-social-media)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:34:00+00:00

Frank Larose, the Ohio secretary of state, fired one of his top aides for criticizing former President Donald Trump on social media. The staffer tweeted about Trump&apos;s indictments.

## Fiery plane crash near Malaysian highway causes 9 deaths
 - [https://www.foxnews.com/world/fiery-plane-crash-malaysian-highway-causes-9-deaths](https://www.foxnews.com/world/fiery-plane-crash-malaysian-highway-causes-9-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:27:28+00:00

According to the police, all the passengers onboard an airplane in Malaysia may have died after the aircraft crashed near the main highway of a suburb. Nine bodies have been recovered.

## Georgia school board rejects calls to fire teacher over exposing elementary students gender fluidity
 - [https://www.foxnews.com/media/georgia-school-board-rejects-calls-fire-teacher-over-exposing-elementary-students-gender-fluidity](https://www.foxnews.com/media/georgia-school-board-rejects-calls-fire-teacher-over-exposing-elementary-students-gender-fluidity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:20:00+00:00

The Cobb County School Board ruled to allow an educator to return to her job, even though people in her district are concerned she is indoctrinating children.

## GOP leaders want answers on destroyed FTC docs, sex change surgery for minors bill suit and more top headlines
 - [https://www.foxnews.com/us/gop-leaders-want-answers-destroyed-ftc-docs-sex-change-surgery-minors-bill-suit](https://www.foxnews.com/us/gop-leaders-want-answers-destroyed-ftc-docs-sex-change-surgery-minors-bill-suit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:18:28+00:00

GOP leaders want answers on destroyed FTC docs, sex change surgery for minors bill suit and more top headlines

## Western Pennsylvania home explosion claims sixth victim after house's co-owner dies from injuries
 - [https://www.foxnews.com/us/western-pennsylvania-home-explosion-claims-sixth-victim-houses-co-owner-dies-injuries](https://www.foxnews.com/us/western-pennsylvania-home-explosion-claims-sixth-victim-houses-co-owner-dies-injuries)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:15:26+00:00

A sixth person has died following the home explosion in western Pennsylvania last week. The cause of the deadly blast remains under investigation.

## Biden yet to respond to proposed meeting with Gold Star families, Issa says
 - [https://www.foxnews.com/politics/biden-yet-respond-proposed-meeting-gold-star-families-issa-says](https://www.foxnews.com/politics/biden-yet-respond-proposed-meeting-gold-star-families-issa-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:00:56+00:00

Rep. Darrell Issa, R-Calif., said he still hasn&apos;t heard from the White House about a proposed meeting between President Biden and Afghanistan Gold Star families.

## Biden ridiculed for asking kids to 'talk to me afterwards' about ice cream: 'President Stranger Danger'
 - [https://www.foxnews.com/media/biden-ridiculed-asking-kids-talk-afterwards-ice-cream-president-stranger-danger](https://www.foxnews.com/media/biden-ridiculed-asking-kids-talk-afterwards-ice-cream-president-stranger-danger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T07:00:47+00:00

President Joe Biden disturbed social media users on Wednesday after asking young children present at a speech to &quot;speak to me afterwards&quot; about getting ice cream.

## Yankees hit rock bottom as they go under .500 in August for first time in almost 30 years
 - [https://www.foxnews.com/sports/yankees-hit-rock-bottom-under-500-august-first-time-almost-30-years](https://www.foxnews.com/sports/yankees-hit-rock-bottom-under-500-august-first-time-almost-30-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:53:05+00:00

The New York Yankees fell to 60-61 with their second-straight shutout on Wednesday night, marking the first time since 1995 they have been under .500 in the month of August.

## Ohio marijuana legalization proposal set to appear on statewide ballots this fall
 - [https://www.foxnews.com/politics/ohio-marijuana-legalization-proposal-set-appear-statewide-ballots-fall](https://www.foxnews.com/politics/ohio-marijuana-legalization-proposal-set-appear-statewide-ballots-fall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:47:09+00:00

Ohio voters will be able to decide whether to legalize recreational marijuana in the state during this fall&apos;s elections. Cannabis has been legal for medical use in the state since 2016.

## 'Blind Side' author Michael Lewis breaks silence on Michael Oher petition against Tuohy family
 - [https://www.foxnews.com/sports/blind-side-author-michael-lewis-breaks-silence-michael-oher-petition-against-tuohy-family](https://www.foxnews.com/sports/blind-side-author-michael-lewis-breaks-silence-michael-oher-petition-against-tuohy-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:44:34+00:00

&quot;The Blind Side&quot; author Michael Lewis broke his silence Wednesday about the drama surrounding the Tuohy family and Michael Oher stemming from the movie.

## Maui fire victims receiving scant support from all levels of government, Gabbard claims: '100% community-led'
 - [https://www.foxnews.com/media/maui-fire-victims-receiving-scant-support-from-all-levels-government-gabbard-claims-100-community-led](https://www.foxnews.com/media/maui-fire-victims-receiving-scant-support-from-all-levels-government-gabbard-claims-100-community-led)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:30:36+00:00

Former Rep. Tulsi Gabbard, D-Hawaii, who since left the Democratic Party, told &quot;The Ingraham Angle&quot; that Maui residents say the county, state and federal response is lacking.

## North Carolina overrides veto to ban trans athletes from competing in women's sports, putting law into effect
 - [https://www.foxnews.com/sports/north-carolina-overrides-veto-ban-trans-athletes-competing-womens-sports-putting-law-into-effect](https://www.foxnews.com/sports/north-carolina-overrides-veto-ban-trans-athletes-competing-womens-sports-putting-law-into-effect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:18:03+00:00

The North Carolina General Assembly overrode multiple vetoes from Gov. Roy Cooper Wednesday night, including the Fairness in Women&apos;s Sports Act.

## Lions' David Montgomery, girlfriend hit with lawsuit after alleged pitbull attack
 - [https://www.foxnews.com/sports/lions-david-montgomery-girlfriend-hit-lawsuit-alleged-pitbull-attack](https://www.foxnews.com/sports/lions-david-montgomery-girlfriend-hit-lawsuit-alleged-pitbull-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:10:00+00:00

David Montgomery and his girlfriend were hit with a civil lawsuit last month after their pitbull allegedly attacked another couple&apos;s dog.

## Hillsong Church founder Brian Houston found not guilty of failing to report father's child sex crimes
 - [https://www.foxnews.com/world/hillsong-church-founder-brian-houston-found-not-guilty-failing-report-fathers-child-sex-crimes](https://www.foxnews.com/world/hillsong-church-founder-brian-houston-found-not-guilty-failing-report-fathers-child-sex-crimes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:01:35+00:00

Brian Houston, the former senior global pastor of Hillsong Church, was found not guilty of concealing his father&apos;s sex crimes against children from the police.

## Target learns tough lesson after sales slump due to backlash from Pride merchandise fiasco
 - [https://www.foxnews.com/media/target-learns-tough-lesson-sales-slump-backlash-pride-merchandise-fiasco](https://www.foxnews.com/media/target-learns-tough-lesson-sales-slump-backlash-pride-merchandise-fiasco)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:00:55+00:00

Target experienced a sales downturn in the second quarter amid ongoing consumer backlash from the retailer’s Pride merchandise, and experts feel other brands should take notice.

## Delicious recipes with a prosecco twist
 - [https://www.foxnews.com/lifestyle/prosecco-recipes](https://www.foxnews.com/lifestyle/prosecco-recipes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:00:53+00:00

Prosecco isn&apos;t just for drinking; it can also be an added ingredient to many recipes. Keep in mind that these particular alcohol based recipes should not be served to children.

## Pediatricians' statement on transgender kids ignores three words that have guided doctors for millennia
 - [https://www.foxnews.com/opinion/pediatricians-statement-transgender-kids-ignores-three-words-guided-doctors-millennia](https://www.foxnews.com/opinion/pediatricians-statement-transgender-kids-ignores-three-words-guided-doctors-millennia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:00:34+00:00

The American Academy of Pediatrics recently reaffirmed its position on youth who suffer from gender dysphoria.

## ‘The Blind Side’ subject Michael Oher claims movie was based on lie: Other films that stretched the truth
 - [https://www.foxnews.com/entertainment/the-blind-side-subject-michael-oher-claims-movie-based-on-lie-other-films-stretched-truth](https://www.foxnews.com/entertainment/the-blind-side-subject-michael-oher-claims-movie-based-on-lie-other-films-stretched-truth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T06:00:24+00:00

Some moviegoers love films based on a true story, but the stories aren&apos;t necessarily always the whole truth as we&apos;ve seen with &quot;The Blind Side,&quot; &quot;Fargo&quot; and others.

## Brad Pitt, Jennifer Aniston's wedding: Extravagant details revealed over 20 years later
 - [https://www.foxnews.com/entertainment/brad-pitt-jennifer-anistons-wedding-extravagant-details-revealed-over-20-years-later](https://www.foxnews.com/entertainment/brad-pitt-jennifer-anistons-wedding-extravagant-details-revealed-over-20-years-later)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:54:39+00:00

Twenty-three years after Brad Pitt and Jennifer Aniston tied the knot, some of their wedding guests are still discussing the lavish event. Michael Rapaport, who worked with Pitt and Aniston, is the latest to speak out.

## California convicted felon back behind bars for 'ambush' shooting of San Jose police officer: chief
 - [https://www.foxnews.com/us/california-convicted-felon-back-behind-bars-ambush-shooting-san-jose-police-officer](https://www.foxnews.com/us/california-convicted-felon-back-behind-bars-ambush-shooting-san-jose-police-officer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:26:30+00:00

A convicted felon on probation out of Santa Clara County, California, is back behind bars after he allegedly ambushed two San Jose officers responding to a call, shooting one of them.

## 'CLOSE IT DOWN': Small Washington library could be nation's first to shutter amid battle over teens' books
 - [https://www.foxnews.com/media/close-small-washington-library-nations-first-shutter-amid-battle-teens-books](https://www.foxnews.com/media/close-small-washington-library-nations-first-shutter-amid-battle-teens-books)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:03:13+00:00

Voters in a rural Washington county will decide whether to shut down their only library following a yearlong fight over controversial books in the young adult section.

## 2024 Watch: Tim Scott laying out $8 million to run ads in key early GOP presidential nominating states
 - [https://www.foxnews.com/politics/2024-watch-tim-scott-laying-out-8-million-run-ads-key-early-gop-presidenital-nominating-states](https://www.foxnews.com/politics/2024-watch-tim-scott-laying-out-8-million-run-ads-key-early-gop-presidenital-nominating-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:00:48+00:00

Sen. Tim Scott of South Carolina is shelling out $8 million to run ads in Iowa and New Hampshire to support his campaign for the 2024 Republican presidential nomination

## How to spot the Capricornus constellation, the sea goat figure in the night sky
 - [https://www.foxnews.com/lifestyle/spot-capricornus-constellation](https://www.foxnews.com/lifestyle/spot-capricornus-constellation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:00:34+00:00

The Capricornus constellation is often thought to represent a sea goat figure. It is best seen in September or October, and a telescope is recommended.

## Rose Zhang says she was 'flabbergasted' over Tiger Woods talk, reveals advice from LPGA Tour stars
 - [https://www.foxnews.com/sports/rose-zhang-says-she-flabbergasted-tiger-woods-talk-reveals-advice-lpga-tour-stars](https://www.foxnews.com/sports/rose-zhang-says-she-flabbergasted-tiger-woods-talk-reveals-advice-lpga-tour-stars)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:00:23+00:00

LPGA Tour rising star Rose Zhang spoke to Fox News Digital in a recent interview about the Tiger Woods comparisons and the advice she&apos;s receiving from golf vets.

## Dem strategists insist Biden 'is a nice person' despite 'no comment' on Hawaii fire: 'Words don't matter'
 - [https://www.foxnews.com/politics/dem-strategists-insist-biden-is-a-nice-person-despite-no-comment-on-hawaii-fire-words-dont-matter](https://www.foxnews.com/politics/dem-strategists-insist-biden-is-a-nice-person-despite-no-comment-on-hawaii-fire-words-dont-matter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:00:19+00:00

Democratic strategists told Fox News Digital that President Biden&apos;s &quot;no comment&quot; concerning the Hawaii wildfires was uncharacteristic of the president and likely a misunderstanding.

## New Jersey mom battles with Democratic governor to keep school policy of informing parents about their kids
 - [https://www.foxnews.com/media/new-jersey-mom-battles-democratic-governor-keep-school-policy-informing-parents-kids](https://www.foxnews.com/media/new-jersey-mom-battles-democratic-governor-keep-school-policy-informing-parents-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T05:00:02+00:00

A New Jersey mom is fighting the state government to prevent them from blocking a school policy that would inform parents if their kids want to change genders.

## Tom Brady’s mental fitness coach shares 6 tips on how to ‘train your mind’ like the greats
 - [https://www.foxnews.com/lifestyle/tom-brady-mental-fitness-coach-6-tips-how-train-mind](https://www.foxnews.com/lifestyle/tom-brady-mental-fitness-coach-6-tips-how-train-mind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T04:00:48+00:00

Peak performance coach Greg Harden has mentored Super Bowl champions and gold medalists for decades. He shares with Fox News Digital some of his best tips for mental fitness.

## Youngkin rips Virginia's largest school district for the 'false notion' that they know better than parents
 - [https://www.foxnews.com/media/youngkin-rips-virginias-largest-school-district-false-notion-know-better-parents](https://www.foxnews.com/media/youngkin-rips-virginias-largest-school-district-false-notion-know-better-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T04:00:46+00:00

Virginia Gov. Glenn Youngkin&apos;s administration responded to Fairfax County Public Schools&apos; decision to defy the governor&apos;s education polices on parental rights.

## Morgan Wallen's new look likely a move to 'broaden' his appeal: expert
 - [https://www.foxnews.com/entertainment/morgan-wallens-new-look-likely-move-broaden-appeal-expert](https://www.foxnews.com/entertainment/morgan-wallens-new-look-likely-move-broaden-appeal-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T04:00:35+00:00

Morgan Wallen&apos;s new haircut sent fans into a frenzy, but he isn&apos;t the first celebrity to change his appearance. Tim McGraw and Adele lost weigh, and Keri Russell chopped her long locks.

## Biden's Ambassador Gutmann must answer for a colossal problem surrounding Penn Biden Center
 - [https://www.foxnews.com/opinion/bidens-ambassador-gutmann-must-answer-colossal-problem-surrounding-penn-biden-center](https://www.foxnews.com/opinion/bidens-ambassador-gutmann-must-answer-colossal-problem-surrounding-penn-biden-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T04:00:34+00:00

Ambassador Amy Gutmann, the former Penn president and founder of the Penn Biden Center where classified documents were found, must answer questions from Congress.

## Texas woman charged after threatening to kill federal judge overseeing election case against Trump: affidavit
 - [https://www.foxnews.com/us/texas-woman-charged-threatening-kill-federal-judge-overseeing-election-case-trump-affidavit](https://www.foxnews.com/us/texas-woman-charged-threatening-kill-federal-judge-overseeing-election-case-trump-affidavit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T03:35:32+00:00

A Texas woman was arrested after making a phone call threatening to kill U.S. District Judge Tanya Chutkan, U.S. Rep. Sheila Jackson Lee, all Democrats in D.C. and the LGBTQ community.

## Storm Chaser works to build a house that can withstand category-five hurricane winds
 - [https://www.foxnews.com/weather/storm-chaser-works-to-build-a-house-that-can-withstand-category-five-hurricane-winds](https://www.foxnews.com/weather/storm-chaser-works-to-build-a-house-that-can-withstand-category-five-hurricane-winds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T03:01:48+00:00

Mississippi storm chaser Josh Morgerman says he is confident his design will build a house that will withstand category-five hurricane winds.

## GOP voters say Trump retains support but believe controversies distract from issues
 - [https://www.foxnews.com/media/gop-voters-trump-retains-support-believe-controversies-distract-issues](https://www.foxnews.com/media/gop-voters-trump-retains-support-believe-controversies-distract-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T03:00:42+00:00

A handful of Republican voters from key swing states spoke out to Martha MacCallum on Fox News Channel&apos;s &quot;The Story&quot; on Wednesday afternoon.

## AI could dwarf Industrial Revolution's impact on 'all elements of life,' senior UK official says
 - [https://www.foxnews.com/world/ai-could-dwarf-industrial-revolutions-impact-all-elements-life-senior-uk-official-says](https://www.foxnews.com/world/ai-could-dwarf-industrial-revolutions-impact-all-elements-life-senior-uk-official-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T02:05:28+00:00

The deputy prime minister of the U.K., Oliver Dowden, speculated that artificial intelligence will have a greater impact on the nation than the Industrial Revolution.

## House, Senate Republicans team up to crack down on FTC for destroying documents related to congressional probe
 - [https://www.foxnews.com/politics/house-senate-republicans-team-up-crack-down-ftc-destroying-documents-related-congressional-probe](https://www.foxnews.com/politics/house-senate-republicans-team-up-crack-down-ftc-destroying-documents-related-congressional-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T02:00:37+00:00

Top Republicans on Capitol Hill are pushing the FTC for answers after it was revealed that the agency destroyed documents related to a congressional probe.

## House Democrats launch 'working group' on artificial intelligence
 - [https://www.foxnews.com/politics/house-democrats-launch-working-group-artificial-intelligence](https://www.foxnews.com/politics/house-democrats-launch-working-group-artificial-intelligence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T02:00:36+00:00

A House Democratic group is mounting a bid to regulate artificial intelligence, starting with a working group examining possible policy recommendations.

## Biden's Department of Justice risks the greatest threat of all
 - [https://www.foxnews.com/opinion/biden-department-justice-risks-greatest-threat-all](https://www.foxnews.com/opinion/biden-department-justice-risks-greatest-threat-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T02:00:16+00:00

Americans are losing faith in the credibility of the Department of Justice, and it is dangerous.

## On this day in history, August 17, 1945, George Orwell's 'Animal Farm' is published
 - [https://www.foxnews.com/lifestyle/this-day-history-august-17-1945-george-orwells-animal-farm-published](https://www.foxnews.com/lifestyle/this-day-history-august-17-1945-george-orwells-animal-farm-published)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-17T00:02:59+00:00

Written by visionary George Orwell, &quot;Animal Farm,&quot; a political fable still studied all over the world, was published on this day in history, Aug. 17, 1945.

