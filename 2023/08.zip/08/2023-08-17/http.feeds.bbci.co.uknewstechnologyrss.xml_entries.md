# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## The eco-friendly glass that's hard to crack
 - [https://www.bbc.co.uk/news/business-66359047?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66359047?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-08-17T23:01:05+00:00

Scientists have developed an extremely strong glass which is less energy intensive to make than regular glass.

