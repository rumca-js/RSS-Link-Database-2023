# Source:CNN World, URL:http://rss.cnn.com/rss/cnn_world.rss, language:en-US

## A quarter of humanity faces extreme water stress -- and it's poised to get worse, new report finds
 - [https://www.cnn.com/2023/08/16/world/water-stress-scarcity-climate-crisis-scn-intl/index.html](https://www.cnn.com/2023/08/16/world/water-stress-scarcity-climate-crisis-scn-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-08-17T06:07:00.835513+00:00

The world is facing an "unprecedented water crisis" driven by soaring demand and the accelerating climate crisis, according to a new report.

## Civil war is worsening Sudan's already dire humanitarian crisis. How you can help
 - [https://www.cnn.com/2023/08/16/world/how-to-help-sudan-refugees-iyw/index.html](https://www.cnn.com/2023/08/16/world/how-to-help-sudan-refugees-iyw/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-08-17T06:07:00.750630+00:00

After months of deadly fighting, Sudanese refugees are hungry, traumatized, exhausted and in need of aid. Here's what you can do to help the most vulnerable

