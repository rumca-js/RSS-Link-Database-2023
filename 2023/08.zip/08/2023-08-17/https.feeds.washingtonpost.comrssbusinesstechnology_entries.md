# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## A nonprofit fights GOP allegations that it supported a ‘censorship regime’
 - [https://www.washingtonpost.com/technology/2023/08/17/center-countering-digital-hate-gop-probe-twitter/](https://www.washingtonpost.com/technology/2023/08/17/center-countering-digital-hate-gop-probe-twitter/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-08-17T11:00:51+00:00

Documents submitted to Jim Jordan’s committee, viewed exclusively by The Post, show that the nonprofit has worked with government officials from both parties.

## Can AI summaries save you from virtual meeting hell?
 - [https://www.washingtonpost.com/technology/2023/08/17/meeting-ai-zoom-otter/](https://www.washingtonpost.com/technology/2023/08/17/meeting-ai-zoom-otter/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-08-17T10:00:00+00:00

We put meeting AI features from Zoom and Otter.ai to the test to discover how well they work and how to think about using them in the future.

