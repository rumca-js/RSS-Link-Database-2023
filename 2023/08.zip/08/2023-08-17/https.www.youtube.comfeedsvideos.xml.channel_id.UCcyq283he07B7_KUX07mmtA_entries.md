# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Champagne is associated with luxury and celebrity. But why is it so expensive? #champagne #wine
 - [https://www.youtube.com/watch?v=mpk9P5HWx0k](https://www.youtube.com/watch?v=mpk9P5HWx0k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-08-17T19:48:56+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## How Air Force Drone Pilots "Fly" The $32 Million MQ-9 Reaper | Boot Camp | Insider Business
 - [https://www.youtube.com/watch?v=7kQAnhET0ec](https://www.youtube.com/watch?v=7kQAnhET0ec)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-08-17T15:57:31+00:00

The The US Air Force’s MQ-9 Reaper drone is a remotely operated unmanned aerial vehicle, or UAV. It is used primarily for intelligence collection and precision strikes against targets on the ground. Because of its lightweight design and long wingspan, the Reaper can stay in the air for about 20 hours without refueling.

The MQ-9 Reaper has been involved in a number of missions, including the 2020 strike that killed the Iranian general Qassem Soleimani, but it has also been linked to civilian deaths. In August 2022, the Department of Defense released the Civilian Harm Mitigation and Response Action Plan to address these civilian-harm issues.
Insider was granted access to Cannon Air Force Base to observe the 12th Special Operations Squadron to see how it’s training new pilots to remotely fly this drone.

MORE BOOT CAMP VIDEOS:
How the US Military Spends Over $44 Billion On Warplanes | Boot Camp | Insider Business
https://www.youtube.com/watch?v=LdsqlMqwmGY&amp;t=0s
How Air Force Pilots Fly The $165 Million Ghostrider — the "Ultimate Battle Plane" | Boot Camp | Insider Business
https://www.youtube.com/watch?v=l0CrdJCrZ8Q&amp;t=0s
Boot Camp Season Five Marathon | Boot Camp | Insider Business
https://www.youtube.com/watch?v=VvUykli9Oqk&amp;t=0s

------------------------------------------------------

#airforce #drone #bootcamp 

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

How Air Force Drone Pilots "Fly" The $32 Million MQ-9 Reaper | Boot Camp | Insider Business

