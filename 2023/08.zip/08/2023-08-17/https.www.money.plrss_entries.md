# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## "Wrzutka" do europejskich emerytur. PiS zmienia sposób funkcjonowania SKOK-ów
 - [https://www.money.pl/pieniadze/wrzutka-do-europejskich-emerytur-pis-zmienia-sposob-funkcjonowania-skok-ow-6931668012321696a.html](https://www.money.pl/pieniadze/wrzutka-do-europejskich-emerytur-pis-zmienia-sposob-funkcjonowania-skok-ow-6931668012321696a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T19:49:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/392bb19b-b98c-439d-905a-c20fea121f12" width="308" /> Ustawa wprowadzająca w Polsce europejskie emerytury posłużyła Prawu i Sprawiedliwości do zmiany przepisów o SKOK-ach. PiS za sprawą "wrzutki" odkręcił reformę wprowadzoną przed laty przez rząd PO-PSL. SKOK-i od teraz będą miały też udziały inwestorskie – zauważyła Bianka Mikołajewska, dziennikarka WP.

## Sejm zmienia przepisy o lasach. Suwerenna Polska dopięła swego
 - [https://www.money.pl/gospodarka/sejm-zmienia-przepisy-o-lasach-suwerenna-polska-dopiela-swego-6931645633751968a.html](https://www.money.pl/gospodarka/sejm-zmienia-przepisy-o-lasach-suwerenna-polska-dopiela-swego-6931645633751968a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T18:18:13+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6ab52399-c363-4b17-8d1d-196c533d785f" width="308" /> Sejm przyjął nowelizację ustawy o lasach. Jest ona efektem działań Suwerennej Polski, która zarzucała Unii Europejskiej, że ta chce odebrać Polsce kontrolę nad krajowymi lasami. Nowe przepisy mają wzmocnić zobowiązania władz publicznych do dbałości o lasy należące do państwa.

## Wątpliwości co do przeszłości córki biznesmena startującej do Sejmu. "Machina propagandowa"
 - [https://www.money.pl/gospodarka/watpliwosci-co-do-przeszlosci-kandydatki-ko-sama-pisze-o-machinie-propagandowej-6931630858873760a.html](https://www.money.pl/gospodarka/watpliwosci-co-do-przeszlosci-kandydatki-ko-sama-pisze-o-machinie-propagandowej-6931630858873760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T17:18:05+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/73405af8-4107-4668-9c97-78273e09b27c" width="308" /> Z list Koalicji Obywatelskiej do parlamentu spróbuje się dostać Aleksandra K. Wiśniewska. Media wytknęły jej jednak nieścisłości dotyczące deklarowanej przez nią działalności humanitarnej. Powołały się przy tym m.in. na Wikipedię. Aktywistka nazwała te działania "machiną propagandową" partii rządzącej.

## PiS prze do referendum. Sejm przyjął uchwałę
 - [https://www.money.pl/gospodarka/pis-prze-do-referendum-sejm-przyjal-uchwale-6931597452962656a.html](https://www.money.pl/gospodarka/pis-prze-do-referendum-sejm-przyjal-uchwale-6931597452962656a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T15:46:06+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2bdeb2ec-b669-48a3-8412-3c2049021f25" width="308" /> Sejm głosami polityków Prawa i Sprawiedliwości i koalicjantów przyjął uchwałę o referendum ogólnokrajowym. Zgodnie z jej treścią ma się ono odbyć 15 października, czyli w dzień wyborów parlamentarnych. Polacy mają odpowiedzieć na cztery pytania.

## Nietypowa awaria w irlandzkim banku. Klienci mogli wypłacić więcej pieniędzy, niż mieli na koncie
 - [https://www.money.pl/banki/nietypowa-awaria-w-irlandzkim-banku-klienci-mogli-wyplacic-wiecej-pieniedzy-niz-mieli-na-koncie-6931575705578400a.html](https://www.money.pl/banki/nietypowa-awaria-w-irlandzkim-banku-klienci-mogli-wyplacic-wiecej-pieniedzy-niz-mieli-na-koncie-6931575705578400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T15:38:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5affcc4f-09e7-4845-b61a-bb3354636990" width="308" /> Bank of Ireland w ostatnich dniach zmagał się z nietypowym problemem systemu. Jego klienci mogli wypłacić pieniądze, których nie mieli na kontach ani na dopuszczalnych debetach. W efekcie do bankomatów ustawił się sznur chętnych, by skorzystać na usterce i "podreperować" swój budżet.

## Szybko sprawdzisz, jaką dostaniesz emeryturę. Sejm zdecydował
 - [https://www.money.pl/emerytury/szybko-sprawdzisz-jaka-dostaniesz-emeryture-sejm-zdecydowal-6931579206904736a.html](https://www.money.pl/emerytury/szybko-sprawdzisz-jaka-dostaniesz-emeryture-sejm-zdecydowal-6931579206904736a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T15:28:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/46b4bd5f-175e-45ad-9b72-739d37fada87" width="308" /> W Polsce powstanie Centralna Informacja Emerytalna. Sejm zagłosował w czwartek za przepisami, które umożliwią jej utworzenie. Za pośrednictwem CIE użytkownicy będą mieli dostęp np. do informacji poglądowej o stanie oszczędności emerytalnych i wysokości przyszłych świadczeń.

## Wielka awaria systemu. Polacy mają problemy z wyrobieniem dowodu czy rejestracją urodzenia
 - [https://www.money.pl/gospodarka/wielka-awaria-systemu-polacy-maja-problemy-z-wyrobieniem-dowodu-czy-rejestracja-urodzenia-6931593308662624a.html](https://www.money.pl/gospodarka/wielka-awaria-systemu-polacy-maja-problemy-z-wyrobieniem-dowodu-czy-rejestracja-urodzenia-6931593308662624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T14:45:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7d1d7154-7529-49a9-b57c-e009f027e64a" width="308" /> Od dwóch dni Centralny Rejestr Państwowy zmaga się z awarią – informuje portalsamorzadowy.pl. W związku z tym Polacy mogą mieć problem ze sprawami związanymi z: dowodem osobistym, rejestracją zgonu, urodzenia, wydawaniem aktów stanu cywilnego czy zameldowaniem.

## Tusk chciał uderzyć w Kaczyńskiego. O kilku faktach jednak zapomniał
 - [https://www.money.pl/gospodarka/tusk-chcial-uderzyc-w-kaczynskiego-o-kilku-faktach-jednak-zapomnial-6931522497289056a.html](https://www.money.pl/gospodarka/tusk-chcial-uderzyc-w-kaczynskiego-o-kilku-faktach-jednak-zapomnial-6931522497289056a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T12:35:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/46824b8c-697f-4a51-a61a-0b23278fc21a" width="308" /> "Byliśmy liderami Europy, dziś szorujemy po dnie" - pisał w środę Donald Tusk o danych PKB Polski za II kw. tego roku. Wpis rozpalił internet. Problem w tym, że przewodniczący Platformy Obywatelskiej zapomniał o kilku istotnych faktach.

## Wydatki na obronność. Niemiecki rząd wycofuje się z planu
 - [https://www.money.pl/gospodarka/wydatki-na-obronnosc-niemiecki-rzad-wycofuje-sie-z-planu-6931523838569376a.html](https://www.money.pl/gospodarka/wydatki-na-obronnosc-niemiecki-rzad-wycofuje-sie-z-planu-6931523838569376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T10:02:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/50eb7df9-611a-4cf1-be6c-f58924dd0f72" width="308" /> Niemcy zapowiadały przeznaczenie 2 proc. PKB rocznie na cele obronności i zapisanie tego w prawie. Ale teraz rząd wycofał się z tego planu – informuje w czwartek portal RedaktionsNetzwerk Deutschland (RND).

## Jak legalnie minimalizować obciążenia podatkowe?
 - [https://www.money.pl/gospodarka/jak-legalnie-minimalizowac-obciazenia-podatkowe-6931488031640416a.html](https://www.money.pl/gospodarka/jak-legalnie-minimalizowac-obciazenia-podatkowe-6931488031640416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T07:50:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/722c9b39-d248-4d51-84a8-5416a2ef7770" width="308" /> Każda osoba, która uzyskuje dochody, zmuszona jest do odprowadzania pewnej ich części do urzędu skarbowego tytułem podatku dochodowego. Prócz tego są jeszcze: podatek od towarów i usług, od zysków kapitałowych czy od nieruchomości. Jak legalnie minimalizować obciążenia podatkowe?

## Miliony z receptomatów. Tak zarabiają na e-receptach
 - [https://www.money.pl/gospodarka/miliony-z-receptomatow-tak-zarabiaja-na-e-receptach-6931478418275168a.html](https://www.money.pl/gospodarka/miliony-z-receptomatow-tak-zarabiaja-na-e-receptach-6931478418275168a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T06:57:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d1cb1f5e-edfb-4256-9caa-074e842d8758" width="308" /> Biznes związany z medycyną stał się atrakcyjny nie tylko dla osób związanych z tą branżą, ale także dla tych, którzy do tej pory nie mieli z nią wiele wspólnego. "Dziennik Gazeta Prawna" przeanalizował wyniki firm, które zajmują się pośrednictwem w handlu receptami.

## W Niemczech chcą zalegalizować marihuanę. Jest decyzja rządu
 - [https://www.money.pl/gospodarka/w-niemczech-chca-zalegalizowac-marihuane-jest-decyzja-rzadu-6931470513740640a.html](https://www.money.pl/gospodarka/w-niemczech-chca-zalegalizowac-marihuane-jest-decyzja-rzadu-6931470513740640a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T06:25:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/657ea89b-48ee-4977-b839-38f599914974" width="308" /> Rząd Niemiec zatwierdził  projekt ustawy o częściowej legalizacji uprawy konopi indyjskich i zażywania marihuany. Projekt przygotowany przez ministra zdrowia Karla Lauterbacha przewiduje między innymi, że posiadanie maksymalnie 25 gramów marihuany nie będzie karalne.

## Podatek od nieruchomości. Wiadomo, gdzie będą rekordowe podwyżki
 - [https://www.money.pl/podatki/podatek-od-nieruchomosci-wiadomo-gdzie-beda-rekordowe-podwyzki-6931462936546144a.html](https://www.money.pl/podatki/podatek-od-nieruchomosci-wiadomo-gdzie-beda-rekordowe-podwyzki-6931462936546144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:54:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a0760336-05c6-4a97-8734-41d8275a7a38" width="308" /> Podatek od nieruchomości związany jest ze wskaźnikiem inflacji w pierwszym  półroczu roku poprzedniego. W efekcie w przyszłym roku stawki mogą pójść do góry nawet o 15 proc. - informuje "Dziennik Gazeta Prawna", dodając, że na rekordowe podwyżki zdecydują się m.in.  Warszawa i Gdańsk.

## Kursy walut 17.08.2023. Czwartkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-17-08-2023-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6931459167718240a.html](https://www.money.pl/pieniadze/kursy-walut-17-08-2023-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6931459167718240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:39:29+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 17.08.2023. W czwartek za jednego dolara (USD) zapłacimy 4.11 zł. Cena jednego funta szterlinga (GBP) to 5.23 zł, a franka szwajcarskiego (CHF) 4.67 zł. Z kolei euro (EUR) możemy zakupić za 4.47 zł.

## Pracujący zdalnie mogą odetchnąć? Fiskus odpuszcza
 - [https://www.money.pl/podatki/pracujacy-zdalnie-moga-odetchnac-fiskus-odpuszcza-6931457276029856a.html](https://www.money.pl/podatki/pracujacy-zdalnie-moga-odetchnac-fiskus-odpuszcza-6931457276029856a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:31:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d61cc33d-5ee2-427a-947b-5f18c2d04b92" width="308" /> Po wprowadzeniu nowych przepisów wielu pracodawców obawiało się, że urzędy skarbowe mogą kwestionować ryczałty i ekwiwalenty przyznawane pracownikom. Okazuje się, według informacji "Rzeczpospolitej", że firmy nie muszą potrącać PIT od rekompensat za internet i prąd zużyty podczas home office.

## Emerytura o pięć lat wcześniej. Oto kto będzie mógł skorzystać
 - [https://www.money.pl/emerytury/emerytura-o-piec-lat-wczesniej-oto-kto-bedzie-mogl-skorzystac-6931449653291872a.html](https://www.money.pl/emerytury/emerytura-o-piec-lat-wczesniej-oto-kto-bedzie-mogl-skorzystac-6931449653291872a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:00:55+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0a58f297-2abd-434c-815b-3d78df0100a3" width="308" /> Według szacunków po uchyleniu wygasającego charakteru emerytur pomostowych na to świadczenie przejdzie w 2024 r. około 7,3 tys. osób - przekazał  Zakład Ubezpieczeń Społecznych. Pod koniec czerwca 2023 r. emerytury pomostowe pobierało łącznie 40,8 tys. osób.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 17.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-17-08-2023-6931449534331744a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-17-08-2023-6931449534331744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:00:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 17.08.2023. W czwartek za jednego dolara (USD) trzeba zapłacić 4.1104 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 17.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-17-08-2023-6931449534847904a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-17-08-2023-6931449534847904a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:00:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 17.08.2023. W czwartek za jednego franka (CHF) trzeba zapłacić 4.6694 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 17.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-17-08-2023-6931449530092384a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-17-08-2023-6931449530092384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 17.08.2023. W czwartek za jedno euro (EUR) trzeba zapłacić 4.4679 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 17.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-17-08-2023-6931449532189536a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-17-08-2023-6931449532189536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T05:00:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 17.08.2023. W czwartek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2301 zł.

## Adam Niedzielski zabiegał o wsparcie ojca Rydzyka. "Obfite ofiary"
 - [https://www.money.pl/gospodarka/adam-niedzielski-zabiegal-o-wsparcie-ojca-rydzyka-obfite-ofiary-6931444656798624a.html](https://www.money.pl/gospodarka/adam-niedzielski-zabiegal-o-wsparcie-ojca-rydzyka-obfite-ofiary-6931444656798624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-17T04:40:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0571406-570e-46c9-acc3-f0dfeed8563f" width="308" /> Adam Niedzielski stracił na początku sierpnia stanowisko ministra zdrowia po kontrowersyjnym wpisie na Twitterze, w którym ujawnił, jakiej grupy leki przepisał sobie jeden z lekarzy. "Fakt" informuje, że Adam Niedzielski  szukał wsparcia u ojca Tadeusza Rydzyka, "hojnie wspierając jego toruńskie media".

