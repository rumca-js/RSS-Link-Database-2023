# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Gary Louris on the 20th anniversary of the Jayhawks' 'Rainy Day Music' #interview
 - [https://www.youtube.com/watch?v=78HzE80sBrU](https://www.youtube.com/watch?v=78HzE80sBrU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-08-17T18:08:29+00:00

Hear from the Jayhawks' Gary Louris as he looks back on 2003's 'Rainy Day Music,' the band's best-selling album.

Video and editing by Tony Libera

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#shorts #thejayhawks #rainyday #rainydaymusic #minnesota #altcountry

