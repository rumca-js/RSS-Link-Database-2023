# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## "Jeden telefon może przerwać dramat, który trwa od lat". Areszty dla podejrzanych o znęcanie się nad bliskimi
 - [https://tvn24.pl/tvnwarszawa/okolice/przemoc-domowa-areszty-dla-podejrzanych-o-znecanie-sie-nad-bliskimi-7296602?source=rss](https://tvn24.pl/tvnwarszawa/okolice/przemoc-domowa-areszty-dla-podejrzanych-o-znecanie-sie-nad-bliskimi-7296602?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T19:55:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-otb8ch-przemoc-domowa-7122970/alternates/LANDSCAPE_1280" />
    40-latek jest podejrzany o znęcanie się nad bratem. 51-latek i 52-latek mieli natomiast dręczyć swoje żony. Wszyscy zostali zatrzymani, a sąd ich tymczasowo aresztował. Grożą im surowe kary. "Nie bójmy się prosić o pomoc, kiedy ze strony osoby najbliższej doznajemy przemocy. Apelujemy również do świadków przemocy domowej o właściwą reakcję. Jeden telefon może przerwać dramat, który trwa w danej rodzinie od wielu lat" - przypomina policja.

## Niemcy chcą zliberalizować prawo dotyczące marihuany. "Nasze rozwiązanie jest atakowane z obu stron"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/niemcy-chca-zliberalizowac-prawo-dotyczace-marihuany-nasze-rozwiazanie-jest-atakowane-z-obu-stron-7296548?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/niemcy-chca-zliberalizowac-prawo-dotyczace-marihuany-nasze-rozwiazanie-jest-atakowane-z-obu-stron-7296548?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T19:07:19+00:00

<img alt="Niemcy chcą zliberalizować prawo dotyczące marihuany. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-j7gdk5-1708b060x-fos-los-marihuana-reuters-004084-7296496/alternates/LANDSCAPE_1280" />
    Jeśli ta ustawa stanie się prawem - Niemcy będą mieli jedne z najbardziej liberalnych w Europie przepisów dotyczących marihuany. Na razie jest poparcie rządu. Berlin chce w ten sposób zneutralizować czarny rynek i walczyć z przestępstwami, które mają związek z narkotykiem. Równolegle władza planuje kampanię pod hasłem "Legalna, ale ryzykowna", która będzie uświadamiać ludziom szkody wynikające z jej zażywania.

## "Wielki Mike" składa pozew przeciwko swojej rodzinie zastępczej. Twierdzi, że wykorzystano go finansowo
 - [https://fakty.tvn24.pl/fakty-o-swiecie/wielki-mike-sklada-pozew-przeciwko-swojej-rodzinie-zastepczej-twierdzi-ze-wykorzystano-go-finansowo-7296538?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/wielki-mike-sklada-pozew-przeciwko-swojej-rodzinie-zastepczej-twierdzi-ze-wykorzystano-go-finansowo-7296538?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T18:55:26+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-shyr3h-1708b070x-fos-zuber-wielki-mike-cnn-004956-7296495/alternates/LANDSCAPE_1280" />
    Gdy ludzie oglądali film o jego życiu - widzieli historię rozczulającą i wzruszającą. Historię bezdomnego, czarnoskórego 17-latka, którego przygarnęła biała rodzina. Dzięki jej wsparciu - młody człowiek najpierw w końcu miał prawdziwy dom, potem trafił do elitarnej ligi futbolu amerykańskiego. Teraz jednak Michael Oher mówi, że rodzina wcale formalnie go nie adoptowała. Mieli go wykorzystać przez trik prawny, na mocy którego ogromnie się jego kosztem wzbogacili.

## Javier Milei sensacyjne wygrał prawybory w Argentynie. "Tylko my jesteśmy prawdziwą opozycją"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/javier-milei-sensacyjne-wygrywa-prawybory-w-argentynie-co-trzeci-wyborca-ktory-na-niego-glosowal-tak-naprawde-wcale-7296530?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/javier-milei-sensacyjne-wygrywa-prawybory-w-argentynie-co-trzeci-wyborca-ktory-na-niego-glosowal-tak-naprawde-wcale-7296530?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T18:46:09+00:00

<img alt="Javier Milei sensacyjne wygrał prawybory w Argentynie. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-bo2mhr-1708b045x-fos-stempien-reuters-002267-7296497/alternates/LANDSCAPE_1280" />
    Podziwia Donalda Trumpa, chce zlikwidować Bank Centralny i wprowadzić jako walutę narodową dolara. Proponuje ponadto zamknięcie przedsiębiorstw państwowych i popiera legalizację handlu ludzkimi narządami. Javier Milei ma szansę zostać następnym prezydentem Argentyny i sprawić, że będzie to kolejny kraj z ultra-prawicową władzą.

## Przedsiębiorcy bronią bankomatów i pytają o ogródki. Raport z konsultacji w sprawie parku kulturowego
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-konsultacje-w-sprawie-utworzenia-parku-kulturowego-przedsiebiorcy-bronia-bankomatow-i-pytaja-o-ogrodki-7296398?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-konsultacje-w-sprawie-utworzenia-parku-kulturowego-przedsiebiorcy-bronia-bankomatow-i-pytaja-o-ogrodki-7296398?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T18:18:29+00:00

<img alt="Przedsiębiorcy bronią bankomatów i pytają o ogródki. Raport z konsultacji w sprawie parku kulturowego" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6uv48s-reklama-lodow-na-placu-zamkowym-7296502/alternates/LANDSCAPE_1280" />
    Stołeczni urzędnicy opublikowali raport z konsultacji w sprawie Historycznego Centrum Warszawy i utworzenia parku kulturowego. Zgłoszone uwagi zostały przesłane do akceptacji biurom i jednostkom miejskim odpowiedzialnym za projekt uchwały.

## Problemy polskiej gospodarki. Eksperci mówią o recesji konsumenckiej
 - [https://fakty.tvn24.pl/zobacz-fakty/problemy-polskiej-gospodarki-eksperci-mowia-o-recesji-konsumenckiej-7296231?source=rss](https://fakty.tvn24.pl/zobacz-fakty/problemy-polskiej-gospodarki-eksperci-mowia-o-recesji-konsumenckiej-7296231?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T18:11:49+00:00

<img alt="Problemy polskiej gospodarki. Eksperci mówią o recesji konsumenckiej" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-yai2dp-170819-pluska-czw-003152-7296233/alternates/LANDSCAPE_1280" />
    Ekonomiści mówią o "recesji konsumenckiej", a wyniki Głównego Urzędu Statystycznego potwierdzają, że wbrew rządowej propagandzie sukcesu i dobrobytu, z naszą gospodarką nie jest dobrze. PKB zmniejszył się w drugim kwartale tego roku o niemal cztery procent w porównaniu z kwartałem pierwszym.

## Sejm przeciwny uchyleniu immunitetu Jarosławowi Kaczyńskiemu
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-o-dawaniu-w-szyje-kobiet-sejm-przeciwko-uchyleniu-immunitetu-7296402?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-o-dawaniu-w-szyje-kobiet-sejm-przeciwko-uchyleniu-immunitetu-7296402?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T17:50:45+00:00

<img alt="Sejm przeciwny uchyleniu immunitetu Jarosławowi Kaczyńskiemu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fchwvt-jaroslaw-kaczynski-7296395/alternates/LANDSCAPE_1280" />
    Sejm odrzucił wniosek o zgodę na pociągnięcie wicepremiera i prezesa PiS Jarosława Kaczyńskiego do odpowiedzialności karnej. Wniosek oskarżyciela prywatnego, aktywistki Dagmary Adamiak dotyczył jego słów o kobietach "dających w szyję". Przeciwko przyjęciu wniosku głosowało 238 posłów.

## Pogoda na jutro - piątek 18.08. Burzowo w niemal całym kraju. Do 33 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-piatek-1808-burzowo-w-niemal-calym-kraju-do-33-stopni-7296362?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-piatek-1808-burzowo-w-niemal-calym-kraju-do-33-stopni-7296362?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T17:25:39+00:00

<img alt="Pogoda na jutro - piątek 18.08. Burzowo w niemal całym kraju. Do 33 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie3625890782f448c9507e8bff420928b8-niebezpieczne-burze-5248666/alternates/LANDSCAPE_1280" />
    Pogoda na jutro. W piątek w niemal całym kraju prognozowane są burze. Na termometrach zobaczymy od 27 do 33 stopni Celsjusza. Pogoda będzie niekorzystnie wpływać na nasze samopoczucie.

## Remont elewacji kamienicy przy Chmielnej 21
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-remont-elewacji-kamienicy-przy-chmielnej-21-7296426?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-remont-elewacji-kamienicy-przy-chmielnej-21-7296426?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T17:12:56+00:00

<img alt="Remont elewacji kamienicy przy Chmielnej 21" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-of87pm-kamienica-przy-chmielnej-21-przed-remontem-7296408/alternates/LANDSCAPE_1280" />
    Kamienica przy Chmielnej 21 została wzniesiona pod koniec XIX wieku, ale na przestrzeni lat bardzo mocno się zmieniała. Obecnie trwa remont elewacji. "Prace konserwatorskie zmierzają do przywrócenia pierwotnej estetyki z czasu ostatniej przebudowy" - informuje stołeczny ratusz.

## Policja zatrzymała lekarza, który za łapówki tworzył historie chorób dla więźniów i... mundurowych
 - [https://tvn24.pl/polska/policja-zatrzymala-lekarza-ktory-za-lapowki-tworzyl-historie-chorob-dla-wiezniow-i-mundurowych-7293293?source=rss](https://tvn24.pl/polska/policja-zatrzymala-lekarza-ktory-za-lapowki-tworzyl-historie-chorob-dla-wiezniow-i-mundurowych-7293293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T17:03:50+00:00

<img alt="Policja zatrzymała lekarza, który za łapówki tworzył historie chorób dla więźniów i... mundurowych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zc3bao-policja-7296341/alternates/LANDSCAPE_1280" />
    Policjanci z Podkarpacia zatrzymali znanego w regionie lekarza psychiatrę, którego podejrzewają o branie łapówek od pacjentów. Banalne z pozoru śledztwo może zakończy dziesiątki, jeśli nie setki karier w wojsku, policji, Służbie Więziennej oraz we wszystkich służbach specjalnych - wynika z nieoficjalnych informacji tvn24.pl.

## Niemal 90 ofiar śmiertelnych pogody w Indiach. Deszcz ciągle pada
 - [https://tvn24.pl/tvnmeteo/swiat/indie-niemal-90-ofiar-smiertelnych-pogody-deszcz-ciagle-pada-7295654?source=rss](https://tvn24.pl/tvnmeteo/swiat/indie-niemal-90-ofiar-smiertelnych-pogody-deszcz-ciagle-pada-7295654?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T16:28:40+00:00

<img alt="Niemal 90 ofiar śmiertelnych pogody w Indiach. Deszcz ciągle pada" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ooruso-zniszczenia-po-osuwisku-w-miejscowosci-shimla-7296260/alternates/LANDSCAPE_1280" />
    Tegoroczna pora monsunowa jest naprawdę bezwzględna dla mieszkańców Indii. W wyniku osuwisk i powodzi błyskawicznych zginęło niemal 90 osób z kilku stanów. Mnóstwo dróg wciąż jest nieprzejezdnych, dlatego ratownicy nie są w stanie dotrzeć z pomocą do wielu regionów.

## Autostrada A2. Wojewoda wydał pozwolenie na budowę ostatniego odcinka na Mazowszu
 - [https://tvn24.pl/tvnwarszawa/ulice/autostrada-a2-wojewoda-wydal-pozwolenie-na-budowe-ostatniego-odcinka-na-mazowszu-7296236?source=rss](https://tvn24.pl/tvnwarszawa/ulice/autostrada-a2-wojewoda-wydal-pozwolenie-na-budowe-ostatniego-odcinka-na-mazowszu-7296236?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T15:55:28+00:00

<img alt="Autostrada A2. Wojewoda wydał pozwolenie na budowę ostatniego odcinka na Mazowszu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-r0zqyn-budowa-autostrady-a2-warszawa-kukuryki-5520686/alternates/LANDSCAPE_1280" />
     
Wojewoda mazowiecki wydał zezwolenie na budowę ostatniego odcinka autostrady A2 Warszawa-Kukuryki w województwie mazowieckim - poinformował w czwartek zespół prasowy wojewody. Chodzi o 12,5 kilometrową trasę pomiędzy Siedlcami i Białą Podlaską.

## Na S8 motocyklista uderzył w bariery. Zginął na miejscu
 - [https://tvn24.pl/tvnwarszawa/ulice/wolomin-wypadek-motocyklisty-na-trasie-s8-mezczyzna-nie-zyje-7296204?source=rss](https://tvn24.pl/tvnwarszawa/ulice/wolomin-wypadek-motocyklisty-na-trasie-s8-mezczyzna-nie-zyje-7296204?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T15:42:29+00:00

<img alt="Na S8 motocyklista uderzył w bariery. Zginął na miejscu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-rullk8-wypadek-motocyklisty-na-trasie-s8-7296293/alternates/LANDSCAPE_1280" />
    Do śmiertelnego wypadku z udziałem motocyklisty doszło na wjeździe na trasę S8 w kierunku Białegostoku. Jak podaje policja, mężczyzna zginął na miejscu. Są utrudnienia w ruchu.

## Saperzy zabrali 250-kilogramową bombę lotniczą, wcześniej ewakuowano mieszkańców okolicznych domów
 - [https://tvn24.pl/tvnwarszawa/najnowsze/sokolnik-cwierctonowa-bomba-lotnicza-podjeta-przez-saperow-ewakuowano-okoliczne-domy-7296178?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/sokolnik-cwierctonowa-bomba-lotnicza-podjeta-przez-saperow-ewakuowano-okoliczne-domy-7296178?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T15:21:24+00:00

<img alt="Saperzy zabrali 250-kilogramową bombę lotniczą, wcześniej ewakuowano mieszkańców okolicznych domów" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kcfu1h-w-miejscowosci-sokolnik-znaleziono-niewybuch-7296188/alternates/LANDSCAPE_1280" />
    W miejscowości Sokolnik w powiecie mińskim znaleziono ważącą 250 kilogramów bombę lotniczą z czasów drugiej wojny światowej. Została zabezpieczona przez saperów.

## PiS o sojuszu Koalicji Obywatelskiej z Agrounią: dla nas to rewelacyjna informacja
 - [https://fakty.tvn24.pl/fakty-po-poludniu/pis-o-sojuszu-koalicji-obywatelskiej-z-agrounia-dla-nas-to-rewelacyjna-informacja-7296163?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/pis-o-sojuszu-koalicji-obywatelskiej-z-agrounia-dla-nas-to-rewelacyjna-informacja-7296163?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T15:09:16+00:00

<img alt="PiS o sojuszu Koalicji Obywatelskiej z Agrounią: dla nas to rewelacyjna informacja" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-82ldfq-1708n200x-f16-kowalska-000530-7296105/alternates/LANDSCAPE_1280" />
    Po prezentacji kandydatów Koalicja Obywatelska ruszyła po podpisy pod wyborczymi listami. Wyborczy kalendarz wprawdzie daje partiom na to jeszcze dużo czasu, ale szybka rejestracja to sposób na pokazanie mobilizacji elektoratu. Zaproszenie lidera Agrounii pod szyld Koalicji Obywatelskiej ma być próbą sięgnięcia po głosy elektoratu na wsi. PiS przekonuje, że o swoje głosy wśród rolników jest spokojny.

## Ciężarówka z piaskiem przewróciła się na bok. Jezdnia zamknięta na kilka godzin
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jozefin-ciezarowka-z-piaskiem-przewrocila-sie-na-bok-jezdnia-zamknieta-na-kilka-godzin-7296099?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jozefin-ciezarowka-z-piaskiem-przewrocila-sie-na-bok-jezdnia-zamknieta-na-kilka-godzin-7296099?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T14:35:11+00:00

<img alt="Ciężarówka z piaskiem przewróciła się na bok. Jezdnia zamknięta na kilka godzin" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-x90wby-wypadek-w-miejscowosci-jozefin-7296132/alternates/LANDSCAPE_1280" />
    W miejscowości Józefin w powiecie mińskim wywróciła się ciężarówka przewożąca piasek. Straż pożarna informuje o dwóch niegroźnie rannych osobach. Akcja podnoszenia pojazdu może potrwać kilka godzin.

## Biegiem uczczą odzyskanie niepodległości. Ruszyły zapisy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rozpoczely-sie-zapisy-na-bieg-niepodleglosci-2023-7295951?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-rozpoczely-sie-zapisy-na-bieg-niepodleglosci-2023-7295951?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T14:34:00+00:00

<img alt="Biegiem uczczą odzyskanie niepodległości. Ruszyły zapisy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-pe2c71-bieg-niepodleglosci-7296082/alternates/LANDSCAPE_1280" />
    Rozpoczęły się zapisy do Biegu Niepodległości w Warszawie. 11 listopada o godzinie 11.11 biegacze – tradycyjnie w białych lub czerwonych koszulkach – uczczą Święto Niepodległości.

## Szumilas: Ministerstwo nie zrobiło nic z uwagami NIK w sprawie programu Willa Plus
 - [https://tvn24.pl/willa-plus/willa-plus-mein-na-tym-etapie-kontrola-bezcelowa-i-bezzasadna-rzymkowski-7295878?source=rss](https://tvn24.pl/willa-plus/willa-plus-mein-na-tym-etapie-kontrola-bezcelowa-i-bezzasadna-rzymkowski-7295878?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T14:18:43+00:00

<img alt="Szumilas: Ministerstwo nie zrobiło nic z uwagami NIK w sprawie programu Willa Plus " src="https://tvn24.pl/najnowsze/cdn-zdjecie-p94g8r-sklejka-sg-willa-plus-6744784/alternates/LANDSCAPE_1280" />
    Ministerstwo Edukacji i Nauki nie może udzielić szczegółowych informacji z uwagi na to, że termin na złożenie końcowego sprawozdania jeszcze nie upłynął - stwierdził wiceminister Tomasz Rzymkowski. W czwartek odpowiadał w Sejmie na pytania posłanek Katarzyny Lubnauer i Krystyny Szumilas w sprawie Willa Plus. Posłanki zarzuciły, że MEiN "nie zrobiło nic" w związku z uwagami Najwyższej Izby Kontroli która wykazała, że program był realizowany z pogwałceniem zasad.

## Otwarte okno w aucie, a w nim ręka z przedmiotem przypominającym broń. "Celują do ludzi"
 - [https://tvn24.pl/krakow/rzeszow-srebrny-samochod-w-srodku-czterech-mlodych-mezczyzn-jeden-z-nich-w-dloni-trzyma-bron-7295069?source=rss](https://tvn24.pl/krakow/rzeszow-srebrny-samochod-w-srodku-czterech-mlodych-mezczyzn-jeden-z-nich-w-dloni-trzyma-bron-7295069?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T14:04:55+00:00

<img alt="Otwarte okno w aucie, a w nim ręka z przedmiotem przypominającym broń. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fmhk3w-policja-ustalila-czterech-mezczyzn-ktorzy-jezdzili-samochodem-po-ulicach-rzeszowa-i-mieli-przy-sobie-przedmiot-przypominajacy-bron-7295861/alternates/LANDSCAPE_1280" />
    Centrum Rzeszowa, na jednej z głównych ulic srebrny nissan, a w nim czwórka młodych ludzi. Jeden z nich trzyma w dłoni przedmiot przypominający broń. Realne zagrożenie czy głupi żart? Wyjaśnia to rzeszowska policja, która prowadzi postępowanie dotyczące zakłócenia spokoju lub porządku publicznego, za co grozi areszt, ograniczenie wolności i wysoka grzywna. Mundurowi namierzyli już pasażerów samochodu.

## Sklep charytatywny okradziony. Złodzieje, udając klientów, wynieśli dwutygodniowy utarg
 - [https://tvn24.pl/pomorze/slupsk-sklep-charytatywny-okradziony-zlodzieje-udajac-klientow-wyniesli-dwutygodniowy-utarg-7295144?source=rss](https://tvn24.pl/pomorze/slupsk-sklep-charytatywny-okradziony-zlodzieje-udajac-klientow-wyniesli-dwutygodniowy-utarg-7295144?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:56:18+00:00

<img alt="Sklep charytatywny okradziony. Złodzieje, udając klientów, wynieśli dwutygodniowy utarg" src="https://tvn24.pl/pomorze/cdn-zdjecie-pk1il8-slupski-sklep-charytatywny-padl-lupem-zlodziei-ukradziono-dwutygodniowy-utarg-7295928/alternates/LANDSCAPE_1280" />
    Ponad pięć tysięcy złotych - tyle utargu wynieśli złodzieje, którzy udając zwykłych klientów, okradli sklep charytatywny w Słupsku. Fundacja Przystań, która zatrudnia w nim osoby z niepełnosprawnościami, apeluje o pomoc w odnalezieniu sprawców.

## Mężczyzna wpadł do kanału samochodowego. Nie udało się go uratować
 - [https://tvn24.pl/tvnwarszawa/okolice/chrosna-mezczyzna-wpadl-do-kanalu-samochodowego-nie-udalo-sie-go-uratowac-7296002?source=rss](https://tvn24.pl/tvnwarszawa/okolice/chrosna-mezczyzna-wpadl-do-kanalu-samochodowego-nie-udalo-sie-go-uratowac-7296002?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:48:30+00:00

<img alt="Mężczyzna wpadł do kanału samochodowego. Nie udało się go uratować" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-rrb145-do-zdarzenia-doszlo-w-miejscowosci-chrosna-7296013/alternates/LANDSCAPE_1280" />
    Do tragicznego wypadku doszło w miejscowości Chrosna w powiecie otwockim. Mężczyzna wpadł do kanału samochodowego. Jak informuje policja, w wyniku poniesionych obrażeń poszkodowany zmarł.

## "Z relacji kierowcy wynika, że nie zauważył on szynobusu". Śledztwo po wypadku na niestrzeżonym przejeździe kolejowym
 - [https://tvn24.pl/tvnwarszawa/najnowsze/dalanowek-zderzenie-ciezarowki-z-szynobusem-sledztwo-w-sprawie-nieumyslnego-spowodowania-wypadku-7295994?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/dalanowek-zderzenie-ciezarowki-z-szynobusem-sledztwo-w-sprawie-nieumyslnego-spowodowania-wypadku-7295994?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:36:17+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-esbs2f-zderzenie-na-przejezdzie-kolejowym-7287865/alternates/LANDSCAPE_1280" />
    Policja w Płońsku (Mazowieckie) prowadzi dochodzenie w sprawie wypadku na niestrzeżonym przejeździe kolejowym w Dalanówku. Samochód ciężarowy zderzył się tam z szynobusem, którym podróżowały 23 osoby, siedem trafiło do szpitala. Postępowanie nadzoruje płońska prokuratura rejonowa.

## Popularna chińska aplikacja z kolejnym zakazem
 - [https://tvn24.pl/biznes/ze-swiata/tiktok-nowy-jork-zakazuje-korzystania-z-aplikacji-urzednikom-7295903?source=rss](https://tvn24.pl/biznes/ze-swiata/tiktok-nowy-jork-zakazuje-korzystania-z-aplikacji-urzednikom-7295903?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:26:58+00:00

<img alt="Popularna chińska aplikacja z kolejnym zakazem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vmu057-shutterstock_511065229-7295998/alternates/LANDSCAPE_1280" />
    Władze Nowego Jorku zdecydowały o zakazaniu TikToka na urządzeniach wykorzystywanych przez urzędników, powołując się na obawy dotyczące bezpieczeństwa. Metropolia dołączyła do grona wielu amerykańskich miast i stanów, które nałożyły podobne ograniczenia na tę popularną aplikację do udostępniania krótkich filmów.

## Pogoda na weekend. Miejscami pełnia słońca, w innych regionach gwałtowne zjawiska
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-weekend-miejscami-pelnia-slonca-w-innych-regionach-gwaltowne-zjawiska-7295892?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-weekend-miejscami-pelnia-slonca-w-innych-regionach-gwaltowne-zjawiska-7295892?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:25:51+00:00

<img alt="Pogoda na weekend. Miejscami pełnia słońca, w innych regionach gwałtowne zjawiska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jk59ub-vent-sklej-16-7295931/alternates/LANDSCAPE_1280" />
    Pogoda na weekend zapowiada się dynamicznie. Będą regiony, w których aura dopisze, ale także takie, w których niewykluczone są burze z silniejszymi opadami i porywami wiatru. Upał wciąż będzie rozlewał się na niektóre części kraju.

## "Nadchodzi czas rozliczeń afer PiS-owskich. Mamy pierwszą odsłonę tego etapu rozliczeń"
 - [https://tvn24.pl/polska/wroclaw-wszczeto-sledztwo-w-sprawie-szpitala-covidowego-poslowie-ko-dariusz-jonski-i-michal-szczerba-o-ustaleniach-7295864?source=rss](https://tvn24.pl/polska/wroclaw-wszczeto-sledztwo-w-sprawie-szpitala-covidowego-poslowie-ko-dariusz-jonski-i-michal-szczerba-o-ustaleniach-7295864?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:24:13+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sx13xu-dariusz-jonski-i-michal-szczerba-na-konferencji-w-sejmie-7295852/alternates/LANDSCAPE_1280" />
    To pierwsza sytuacja, kiedy prokuratura polityczna, prokuratura Ziobry, po przekazaniu jej twardych dowodów na uzasadnione podejrzenie przestępstwa, wszczyna śledztwo przeciwko funkcjonariuszowi tego rządu - ogłosił w Sejmie poseł KO Michał Szczerba. W ten sposób odniósł się do decyzji prokuratury o wszczęciu śledztwa w sprawie szpitala covidowego we Wrocławiu i decyzji wojewody dolnośląskiego w tej sprawie.

## Mieli rosyjskie wizy, jechali z granicy polsko-białoruskiej. Przyznali, że chcieli się dostać do Niemiec
 - [https://tvn24.pl/tvnwarszawa/okolice/mieli-rosyjskie-wizy-jechali-z-granicy-polsko-bialoruskiej-przyznali-ze-chcieli-sie-dostac-do-niemiec-7295917?source=rss](https://tvn24.pl/tvnwarszawa/okolice/mieli-rosyjskie-wizy-jechali-z-granicy-polsko-bialoruskiej-przyznali-ze-chcieli-sie-dostac-do-niemiec-7295917?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:19:56+00:00

<img alt="Mieli rosyjskie wizy, jechali z granicy polsko-białoruskiej. Przyznali, że chcieli się dostać do Niemiec" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8t9box-straz-graniczna-zdjecie-ilustracyjne-7282614/alternates/LANDSCAPE_1280" />
    Jechali z granicy polsko-białoruskiej w kierunku Niemiec. Busem podróżowało 14 osób. Dziesięć z nich miało paszporty z rosyjską wizą. To dziewięciu Syryjczyków i Palestyńczyk. Trzej Białorusini legalnie przebywali w Polsce i to oni trafili do aresztu za "pomocnictwo w nielegalnym przekraczaniu granicy".

## Rzucił się z pięściami na ratownika, który mu pomagał. Teraz "dałby wiele, żeby to się nie wydarzyło"
 - [https://tvn24.pl/wroclaw/dziecmorowice-woj-dolnoslaskie-24-latek-rzucil-sie-na-ratownika-grozi-mu-do-trzech-lat-wiezienia-7295895?source=rss](https://tvn24.pl/wroclaw/dziecmorowice-woj-dolnoslaskie-24-latek-rzucil-sie-na-ratownika-grozi-mu-do-trzech-lat-wiezienia-7295895?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:07:17+00:00

<img alt="Rzucił się z pięściami na ratownika, który mu pomagał. Teraz " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c1tbgt-24-latkowi-grozi-do-trzech-lat-wiezienia-7295901/alternates/LANDSCAPE_1280" />
    Do trzech lat więzienia grozi 24-latkowi, który najpierw po pijanemu wpadł do strumyka, a potem zaatakował ratownika medycznego, który udzielał mu pomocy. Do zdarzenia doszło podczas imprezy zorganizowanej z okazji festiwalu odbywającego się w Dziećmorowicach (woj. dolnośląskie). - Mężczyzna był tak pijany, że trzeźwiał przez dwa dni - mówi tvn24.pl komisarz Marcin Świeży z policji w Wałbrzychu.

## Pytania o głosy Polaków za granicą. Wiceszef MSZ: przygotowania jak w latach ubiegłych
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-za-granica-wiceszef-msz-przygotowania-jak-w-latach-ubieglych-7295610?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-za-granica-wiceszef-msz-przygotowania-jak-w-latach-ubieglych-7295610?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T13:05:52+00:00

<img alt="Pytania o głosy Polaków za granicą. Wiceszef MSZ: przygotowania jak w latach ubiegłych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vtsduh-londyn-wielka-brytania-13102019-glosowanie-w-komisji-wyborczej-przy-parafii-pod-wezwaniem-nmp-matki-kosciola-na-ealingu-w-londynie-7295975/alternates/LANDSCAPE_1280" />
    Przygotowania do organizacji wyborów przebiegają według tego samego schematu jak w latach ubiegłych - zapewniał w Sejmie wiceszef MSZ Piotr Wawrzyk, pytany o głosowanie Polonii w wyborach parlamentarnych. - Po pana wystąpieniu ja nie mam pewności, że jesteście do tego dobrze przygotowani - odpowiadał mu lider partii Razem, Adrian Zandberg.

## Laptopy dla czwartoklasistów. Jakie modele dostaną uczniowie?
 - [https://tvn24.pl/biznes/tech/laptopy-dla-czwartoklasistow-jakie-modele-dostana-uczniowie-wyniki-przetargow-7295712?source=rss](https://tvn24.pl/biznes/tech/laptopy-dla-czwartoklasistow-jakie-modele-dostana-uczniowie-wyniki-przetargow-7295712?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T12:12:58+00:00

<img alt="Laptopy dla czwartoklasistów. Jakie modele dostaną uczniowie?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cr4mjk-szkola-7295846/alternates/LANDSCAPE_1280" />
    Ministerstwo Cyfryzacji poinformowało, że zostało już rozstrzygniętych 49 z 73 przetargów na dostarczenie laptopów dla czwartoklasistów. Łącznie do uczniów trafi ponad 394 tysięcy komputerów za ponad miliard złotych.

## Po porannej ulewie na samochody runęło drzewo
 - [https://tvn24.pl/poznan/poznan-drzewo-runelo-na-zaparkowane-auta-uszkodzone-trzy-samochody-7295845?source=rss](https://tvn24.pl/poznan/poznan-drzewo-runelo-na-zaparkowane-auta-uszkodzone-trzy-samochody-7295845?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T12:12:11+00:00

<img alt="Po porannej ulewie na samochody runęło drzewo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4jpq1i-drzewo-zmiazdzylo-trzy-auta-7295830/alternates/LANDSCAPE_1280" />
    Na ulicy Kochanowskiego w Poznaniu na zaparkowane samochody runęło drzewo. - W zdarzeniu nikt nie ucierpiał - mówi młodszy aspirant Jacek Kotarski z Jednostki Ratowniczo-Gaśniczej nr 2 w Poznaniu.

## Wandal wybił gaśnicą szybę w busie. Policji powiedział, że ma takie hobby
 - [https://tvn24.pl/bialystok/suwalki-dostali-zgloszenie-o-wybitej-szybie-w-busie-zatrzymany-38-latek-stwierdzil-ze-ma-takie-ma-hobby-7295548?source=rss](https://tvn24.pl/bialystok/suwalki-dostali-zgloszenie-o-wybitej-szybie-w-busie-zatrzymany-38-latek-stwierdzil-ze-ma-takie-ma-hobby-7295548?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T11:57:43+00:00

<img alt="Wandal wybił gaśnicą szybę w busie. Policji powiedział, że ma takie hobby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-we5hlh-policja-dostala-zgloszenie-o-wybitej-szybie-w-busie-7295785/alternates/LANDSCAPE_1280" />
    Kradzież i uszkodzenia mienia - takie zarzuty usłyszał 38-latek, który jest podejrzany o to, że na jednej z ulic w Suwałkach (woj. podlaskie) wybił gaśnicą szybę w busie, a wcześniej okradł sklep. Miał przy sobie plecak, a w nim m.in. artykuły drogeryjne. Będzie odpowiadał w warunkach recydywy.

## Lubiany program TVN z nowym jurorem. Co można wygrać?
 - [https://tvn24.pl/kultura-i-styl/lego-masters-z-nowym-jurorem-co-mozna-wygrac-7295655?source=rss](https://tvn24.pl/kultura-i-styl/lego-masters-z-nowym-jurorem-co-mozna-wygrac-7295655?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T11:39:26+00:00

<img alt="Lubiany program TVN z nowym jurorem. Co można wygrać?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8exk4e-wojciech-lozowski-7295742/alternates/LANDSCAPE_1280" />
    Wraca "LEGO Masters". Jesienią pasjonaci klocków już po raz czwarty będą rywalizować o tytuł mistrza LEGO, zestaw klocków o wartości 10 tysięcy zł oraz nagrodę 100 tysięcy złotych. Program poprowadzi Marcin Prokop. Umiejętności i kreatywność uczestników ocenią znana już widzom projektantka graficzna Pola Lisowicz oraz nowy juror Wojciech Łozowski. Jak się sprawdzi?

## W wypadku zginęły cztery osoby, w tym dzieci. Prokuratura wszczęła śledztwo
 - [https://tvn24.pl/bialystok/slomianka-w-wypadk-zginely-cztery-osoby-w-tym-dwoje-dzieci-prokuratura-wsczela-sledztwo-7295154?source=rss](https://tvn24.pl/bialystok/slomianka-w-wypadk-zginely-cztery-osoby-w-tym-dwoje-dzieci-prokuratura-wsczela-sledztwo-7295154?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T11:27:18+00:00

<img alt="W wypadku zginęły cztery osoby, w tym dzieci. Prokuratura wszczęła śledztwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f4np5v-ze-wstepnych-ustalen-policji-wynika-ze-doszlo-do-nieustapienia-pierszenstwa-przejazdu-7289879/alternates/LANDSCAPE_1280" />
    Na drodze wojewódzkiej 673 w miejscowości Słomianka (woj. podlaskie) zginęły cztery osoby, w tym dwoje dzieci. Prokuratura Rejonowa w Sokółce wszczęła śledztwo w sprawie wypadku. Zginęli dziadkowie i dwie wnuczki. Tymczasem władze Dąbrowy Białostockiej chcą, by na fragmencie trasy, o której mowa został wprowadzony odcinkowy pomiar prędkości.

## "Groził nożem przechodniom, wymuszał zakup alkoholu"
 - [https://tvn24.pl/tvnwarszawa/okolice/plonsk-pijany-grozil-nozem-przechodniom-wymuszajac-zakup-alkoholu-7295675?source=rss](https://tvn24.pl/tvnwarszawa/okolice/plonsk-pijany-grozil-nozem-przechodniom-wymuszajac-zakup-alkoholu-7295675?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T11:02:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xh0nw6-kierowca-mial-trzy-promile-zdjecie-ilustracyjne-7287012/alternates/LANDSCAPE_1280" />
    W Płońsku mężczyzna grożąc nożem przechodniom, wymuszał zakup wybranych artykułów, w tym alkoholu. - Napadł między innymi na 86-latka. Tuż po zdarzeniu został zatrzymany przez funkcjonariuszy, którzy znaleźli przy nim także narkotyki - przekazała rzeczniczka tamtejszej policji komisarz Kinga Drężek-Zmysłowska.

## Samochód pędził z prędkością 159 km/h w terenie zabudowanym. Za kierownicą siedział 19-latek
 - [https://tvn24.pl/krakow/mielec-pedzil-159-kmh-w-terenie-zabudowanym-19-latek-otrzymal-wysoki-mandat-i-stracil-prawo-jazdy-7295174?source=rss](https://tvn24.pl/krakow/mielec-pedzil-159-kmh-w-terenie-zabudowanym-19-latek-otrzymal-wysoki-mandat-i-stracil-prawo-jazdy-7295174?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T10:44:05+00:00

<img alt="Samochód pędził z prędkością 159 km/h w terenie zabudowanym. Za kierownicą siedział 19-latek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-682tbm-policja-policyjny-kogut-6722449/alternates/LANDSCAPE_1280" />
    19-letni kierowca mazdy pędził przez Mielec (woj. podkarpackie) z prędkością 159 kilometrów na godzinę, czym przekroczył dozwoloną prędkość w obszarze zabudowanym o 109 km/h. Stracił prawo jazdy i został ukarany wysokim mandatem oraz punktami karnymi.

## Kotek błąkał się po ruchliwej ulicy. Policjant go uratował i chce przygarnąć
 - [https://tvn24.pl/najnowsze/zbytkow-policjant-uratowal-malego-kota-blakajacego-sie-noca-po-drodze-krajowej-7295462?source=rss](https://tvn24.pl/najnowsze/zbytkow-policjant-uratowal-malego-kota-blakajacego-sie-noca-po-drodze-krajowej-7295462?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T10:23:20+00:00

<img alt="Kotek błąkał się po ruchliwej ulicy. Policjant go uratował i chce przygarnąć" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7h2c85-policjant-uratowal-malego-kota-ktory-blakal-sie-noca-po-drodze-krajowej-7295492/alternates/LANDSCAPE_1280" />
    Małego kota, który biegał po ruchliwej drodze krajowej 81 w miejscowości Zbytków (woj. śląskie), uratował policjant podczas nocnego patrolu. Zabrał go z drogi, opłacił wizytę u weterynarza i zapewnił schronienie. Trwają poszukiwania właściciela. Jeśli nikt się nie zgłosi, zwierzak zostanie u mundurowego, który go uratował.

## Na przejściu dla pieszych potrąciła pieszego. Mężczyzna zmarł w szpitalu
 - [https://tvn24.pl/tvnwarszawa/ulice/wawer-smiertelne-potracenie-72-latka-na-pasach-7295583?source=rss](https://tvn24.pl/tvnwarszawa/ulice/wawer-smiertelne-potracenie-72-latka-na-pasach-7295583?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T10:22:37+00:00

<img alt="Na przejściu dla pieszych potrąciła pieszego. Mężczyzna zmarł w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bzvlwt-smiertelny-wypadek-w-wawrze-7295580/alternates/LANDSCAPE_1280" />
    Do tragicznego wypadku doszło w środę przed południem w Wawrze. Na przejściu dla pieszych kierująca autem osobowym potrąciła mężczyznę. 72-latek trafił do szpitala, ale jego życia nie udało się uratować.

## Kłopoty pasażerów rosyjskiej linii lotniczej. "Realne zagrożenie dla zdrowia i życia"
 - [https://tvn24.pl/biznes/ze-swiata/rosja-samolot-red-wings-mial-leciec-bez-klimatyzacji-pasazerowie-mieli-mdlec-sledztwo-rosyjskiej-agencji-lotniczej-7295269?source=rss](https://tvn24.pl/biznes/ze-swiata/rosja-samolot-red-wings-mial-leciec-bez-klimatyzacji-pasazerowie-mieli-mdlec-sledztwo-rosyjskiej-agencji-lotniczej-7295269?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T09:38:24+00:00

<img alt="Kłopoty pasażerów rosyjskiej linii lotniczej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5opgh-shutterstock_2132395861-7295235/alternates/LANDSCAPE_1280" />
    Komitet Śledczy Rosji (KŚR) wszczął śledztwo przeciw liniom Red Wings z powodu świadczenia niebezpiecznych usług. Podczas lotu na trasie Antalya-Moskwa 406 osób miało podróżować samolotem z niedziałającą klimatyzacją i wiele z nich miało zemdleć - napisał "Kommersant". Od czasu rosyjskiej inwazji na Ukrainę większość wyprodukowanych na Zachodzie samolotów nadal lata w rosyjskich liniach, chociaż są odcięte od ważnych aktualizacji oprogramowania i regularnych procedur konserwacji.

## Chciał, by policja wyprosiła gości z domu. Dwóch kolegów wysłał za kratki
 - [https://tvn24.pl/pomorze/sopot-chcial-by-policja-wyprosila-gosci-z-domu-dwoch-kolegow-wyslal-za-kratki-7295103?source=rss](https://tvn24.pl/pomorze/sopot-chcial-by-policja-wyprosila-gosci-z-domu-dwoch-kolegow-wyslal-za-kratki-7295103?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T09:38:09+00:00

<img alt="Chciał, by policja wyprosiła gości z domu. Dwóch kolegów wysłał za kratki" src="https://tvn24.pl/pomorze/cdn-zdjecie-fxey8b-chcial-by-policja-wyprosila-gosci-z-domowki-dwoch-kolegow-wyslal-za-kratki-7295115/alternates/LANDSCAPE_1280" />
    Mężczyzna zaprosił do mieszkania trzech kolegów, a gdy na chwilę wyszedł, ci zamknęli się od środka i nie chcieli go wpuścić. Gdy na miejsce przyjechali mundurowi, jeden z gości wyskoczył przez okno. Okazało się, że ma do odbycia karę więzienia. Inny nie wiedział o tym, że jest poszukiwany, więc spokojnie czekał w mieszkaniu.

## Prąd poraził 15-latka. Zabrał go śmigłowiec LPR
 - [https://tvn24.pl/najnowsze/gumna-prad-porazil-15-latka-smiglowiec-lpr-zabral-go-do-szpitala-7295425?source=rss](https://tvn24.pl/najnowsze/gumna-prad-porazil-15-latka-smiglowiec-lpr-zabral-go-do-szpitala-7295425?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T09:26:09+00:00

<img alt="Prąd poraził 15-latka. Zabrał go śmigłowiec LPR " src="https://tvn24.pl/najnowsze/cdn-zdjecie-602g3f-po-mezczyzn-przylecial-smiglowiec-lpr-1789414/alternates/LANDSCAPE_1280" />
    15-letni chłopiec został porażony prądem w miejscowości Gumna na Śląsku Cieszyńskim (woj. śląskie). Cieszyńska policja podała, że stan chłopca był na tyle poważny, że wezwano Lotnicze Pogotowie Ratunkowe, które przetransportowało go do szpitala.

## Samochód dostawczy uderzył w drzewo. Kierowca nie żyje
 - [https://tvn24.pl/lodz/solca-mala-woj-lodzkie-samochod-dostawczy-zjechal-z-drogi-krajowej-nr-91-i-uderzyl-w-drzewo-kierowca-nie-zyje-7295360?source=rss](https://tvn24.pl/lodz/solca-mala-woj-lodzkie-samochod-dostawczy-zjechal-z-drogi-krajowej-nr-91-i-uderzyl-w-drzewo-kierowca-nie-zyje-7295360?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T09:17:57+00:00

<img alt="Samochód dostawczy uderzył w drzewo. Kierowca nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vb2fgo-kierowca-samochodu-dostawczego-zginal-na-miejscu-7295380/alternates/LANDSCAPE_1280" />
    Policja pod nadzorem prokuratury wyjaśnia okoliczności wypadku, do którego doszło w czwartek rano w miejscowości Solca Mała (woj. łódzkie). - Samochód dostawczy marki Iveco z niewyjaśnionych przyczyn zjechał z drogi krajowej numer 91 i zderzył się z drzewem. Życia kierowcy nie udało się uratować - przekazuje podkomisarz Robert Borowski ze zgierskiej komendy powiatowej.

## Zmiany w emeryturach. ZUS podał, ile osób ma skorzystać
 - [https://tvn24.pl/biznes/z-kraju/emerytury-pomostowe-kto-skorzysta-ile-osob-dane-zus-7294907?source=rss](https://tvn24.pl/biznes/z-kraju/emerytury-pomostowe-kto-skorzysta-ile-osob-dane-zus-7294907?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T07:24:13+00:00

<img alt="Zmiany w emeryturach. ZUS podał, ile osób ma skorzystać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fx3fnu-pap_20210807_37z-7293793/alternates/LANDSCAPE_1280" />
    Po uchyleniu wygasającego charakteru emerytur pomostowych na to świadczenie przejdzie w 2024 roku około 7,3 tysiąca osób - wynika z szacunków Zakładu Ubezpieczeń Społecznych (ZUS). Pod koniec czerwca 2023 roku emerytury pomostowe pobierało łącznie 40,8 tysiąca osób.

## Kolejna nagła śmierć w rosyjskiej armii. Nie żyje były wiceminister obrony, który dowodził zgrupowaniem wojsk w Ukrainie
 - [https://tvn24.pl/swiat/rosja-kolejna-nagla-smiercw-armii-nie-zyje-byly-wiceminister-obrony-general-giennadij-zydko-ktory-dowodzil-zgrupowaniem-wojsk-w-ukrainie-7294893?source=rss](https://tvn24.pl/swiat/rosja-kolejna-nagla-smiercw-armii-nie-zyje-byly-wiceminister-obrony-general-giennadij-zydko-ktory-dowodzil-zgrupowaniem-wojsk-w-ukrainie-7294893?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T04:02:28+00:00

<img alt="Kolejna nagła śmierć w rosyjskiej armii. Nie żyje były wiceminister obrony, który dowodził zgrupowaniem wojsk w Ukrainie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6ot603-rosyjskie-wojsko-6220484/alternates/LANDSCAPE_1280" />
    Były wiceminister obrony Rosji generał Giennadij Żydko, który od maja do lipca 2022 roku pełnił funkcję dowódcy zgrupowania rosyjskich wojsk w Ukrainie, zmarł w środę w Moskwie w wieku 58 lat - powiadomił portal Ukrainska Prawda za rosyjskimi mediami i przedstawicielami tamtejszych władz.

## Doradca Zełenskiego o trzech warunkach przyspieszenia "sprawiedliwego końca" wojny z Rosją
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-kiedy-zakonczenie-doradca-zelenskiego-o-trzech-warunkach-dla-przyspieszenia-sprawiedliwego-konca-7294882?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-kiedy-zakonczenie-doradca-zelenskiego-o-trzech-warunkach-dla-przyspieszenia-sprawiedliwego-konca-7294882?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T03:52:35+00:00

<img alt="Doradca Zełenskiego o trzech warunkach przyspieszenia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-sktr34-ukraina-zolnierz-ukrainski-zolnierz-7279576/alternates/LANDSCAPE_1280" />
    Doradca biura prezydenta Ukrainy Mychajło Podolak podał trzy warunki przyspieszenia "sprawiedliwego zakończenia" wojny z Rosją. Jak wymienił, jest to nasilenie sankcji wobec Moskwy, przyspieszenie dostaw broni dla Ukrainy oraz izolacja najwyższego kierownictwa Kremla.

## Pogoda na dziś - czwartek, 17.08. Będzie grzmieć w części kraju, temperatura sięgnie 32 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-czwartek-1708-bedzie-grzmiec-w-czesci-kraju-temperatura-siegnie-32-stopni-7294794?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-czwartek-1708-bedzie-grzmiec-w-czesci-kraju-temperatura-siegnie-32-stopni-7294794?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-17T00:00:00+00:00

<img alt="Pogoda na dziś - czwartek, 17.08. Będzie grzmieć w części kraju, temperatura sięgnie 32 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0rgwov-goraco-upal-5761708/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W czwartek 17.08 w wielu regionach kraju pojawią się przelotne opady deszczu i burze. Miejscami może spaść do 30 litrów wody na metr kwadratowy. Termometry pokażą maksymalnie 32 stopnie.

