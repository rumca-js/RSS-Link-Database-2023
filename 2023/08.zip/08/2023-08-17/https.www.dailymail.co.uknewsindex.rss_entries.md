# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Donald Trump's lawyers call on federal judge to overrule Special Counsel Jack Smith and DELAY his 2020 election interference trial until 2026 - AFTER he has chance to run for president again
 - [https://www.dailymail.co.uk/news/article-12419079/Donald-Trumps-lawyers-call-federal-judge-overrule-Special-Counsel-Jack-Smith-DELAY-2020-election-interference-trial-2026-chance-run-president-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12419079/Donald-Trumps-lawyers-call-federal-judge-overrule-Special-Counsel-Jack-Smith-DELAY-2020-election-interference-trial-2026-chance-run-president-again.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:29:42+00:00

Attorneys for former US President Donald Trump have requested an April 2026 trial date for the federal election interference case, new filings show.

## Internal fight erupts in the Labor party causing a rift at the annual conference
 - [https://www.dailymail.co.uk/news/article-12419099/Internal-fight-erupts-Labor-party-causing-rift-annual-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12419099/Internal-fight-erupts-Labor-party-causing-rift-annual-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:29:28+00:00

Labor Party faithful will air their concerns about the government's acquisition of nuclear submarines and the stalled recognition of Palestinian statehood.

## Young man dies after a fight outside a pub in Robina on the Gold Coast
 - [https://www.dailymail.co.uk/news/article-12419015/Young-man-dies-fight-outside-pub-Robina-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12419015/Young-man-dies-fight-outside-pub-Robina-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:29:00+00:00

Queensland Police attended RQ's Tavern in Robina shortly after 10pm on Thursday following reports of an altercation.

## Landlords call on ministers to let them sell alcohol from kick-off on Sunday for the World Cup final amid hopes the Lionesses could give pubs their busiest day of the year
 - [https://www.dailymail.co.uk/news/article-12418951/Pub-landlords-call-MPs-change-alcohol-licencing-laws-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418951/Pub-landlords-call-MPs-change-alcohol-licencing-laws-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:28:01+00:00

Pub owners have asked ministers to allow them to serve drink from 10am on Sunday for the World Cup Final. Most pubs can sell alcohol only after 11am, an hour after kick-off.

## Government approves plans for covid jabs to go on sale ahead of move that will see 12million people lose privilege of free NHS vaccines over winter
 - [https://www.dailymail.co.uk/news/article-12418925/Government-approves-plans-covid-jabs-sale-ahead-12million-people-lose-privilege-free-NHS-vaccines-winter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418925/Government-approves-plans-covid-jabs-sale-ahead-12million-people-lose-privilege-free-NHS-vaccines-winter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:26:45+00:00

The UK Health Security Agency (UKHSA) indicated it was happy to allow paid-for shots, which could be available next year, with interest already shown by some pharmacists and clinics.

## Is this America's most confused home? Bizarre Missouri home sparks ridicule due to its quirky layout with an upstairs FENCE and oven shoved in an ultra narrow corridor - as it goes on the market for $180,000
 - [https://www.dailymail.co.uk/news/article-12418759/Is-Americas-confused-home-Bizarre-Missouri-home-sparks-ridicule-quirky-layout-upstairs-FENCE-oven-shoved-ultra-narrow-corridor-goes-market-180-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418759/Is-Americas-confused-home-Bizarre-Missouri-home-sparks-ridicule-quirky-layout-upstairs-FENCE-oven-shoved-ultra-narrow-corridor-goes-market-180-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:25:35+00:00

A house in Kansas City, Missouri has hit the market and its bizarre fittings are baffling social media users.

## Tinker Air Force Base deaths: USAF breaks its silence to reveal 11 of 17 who mysteriously died on base passed away due to natural causes... but refuse to disclose how the other SIX were killed
 - [https://www.dailymail.co.uk/news/article-12418771/Tinker-Air-Force-base-Oklahoma-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418771/Tinker-Air-Force-base-Oklahoma-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:24:53+00:00

Tinker Air Force Base has found itself in an uncomfortable spotlight since Wednesday, when it emerged that there had been 17 deaths so far this year on the base, where more than 30,000 work.

## Joe Rogan claims Democrats are leaking scandals about Joe Biden on PURPOSE to try to get rid of 80 year-old president before 2024 election
 - [https://www.dailymail.co.uk/news/article-12418765/Joe-Rogan-claims-Democrats-leaking-scandals-Joe-Biden-PURPOSE-try-rid-80-year-old-president-2024-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418765/Joe-Rogan-claims-Democrats-leaking-scandals-Joe-Biden-PURPOSE-try-rid-80-year-old-president-2024-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:24:41+00:00

Podcaster Joe Rogan said on his popular show Wednesday tat the Democratic Party is attempting to leak scandals about Joe Biden to keep him from running in 2024.

## Banks could be fined if they don't offer access to free-to-use ATMs or bank branches within three miles of customers under new Treasury plans
 - [https://www.dailymail.co.uk/news/article-12419065/Banks-fined-dont-offer-access-free-ATMs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12419065/Banks-fined-dont-offer-access-free-ATMs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:22:59+00:00

The move to require banks to provide free-to-use ATMs and accessible branches, set to be announced by the Treasury, will ensure the 'majority' of people have either within three miles.

## Nike is accused of snubbing England goalkeeper Mary Earps after leaving her out of Instagram post congratulating the team for their win over Australia - after she called them out for not stocking replicas of her shirt
 - [https://www.dailymail.co.uk/news/article-12418947/Nike-accused-snubbing-Mary-Earps-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418947/Nike-accused-snubbing-Mary-Earps-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:22:02+00:00

Nike has been accused of snubbing England goalkeeper Mary Earps after leaving her out of an Instagram post congratulating the team for their win over Australia.

## Cloud over future pensions with warnings there will be fewer working people to support the ageing population as birth rates slump to their lowest levels for 20 years
 - [https://www.dailymail.co.uk/news/article-12419063/Cloud-future-pensions-warnings-fewer-working-people-support-ageing-population-birth-rates-slump-lowest-levels-20-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12419063/Cloud-future-pensions-warnings-fewer-working-people-support-ageing-population-birth-rates-slump-lowest-levels-20-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:21:30+00:00

Analysts warned lower birth rates meant the state pension could come under pressure if the trend continues, with fewer working people to support an ageing population

## French authorities have stopped less than 50% of Channel crossing attempts in last year - despite being given £480m from British taxpayers to solve migrant crisis
 - [https://www.dailymail.co.uk/news/article-12418939/French-authorities-stopped-50-Channel-crossing-attempts-year-despite-given-480m-British-taxpayers-solve-migrant-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418939/French-authorities-stopped-50-Channel-crossing-attempts-year-despite-given-480m-British-taxpayers-solve-migrant-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:20:56+00:00

Figures show France is intercepting fewer than 50 per cent of Channel crossing attempts in the last year - despite a £480 million deal with the French to solve the migrant crisis.

## Juror from first murder trial of ex-NFLer's son AJ Armstrong 'concerned' third jury 'didn't understand reasonable doubt' when they convicted him of killing his parents
 - [https://www.dailymail.co.uk/news/article-12418499/Juror-murder-trial-ex-NFLers-son-AJ-Armstrong-concerned-jury-didnt-understand-reasonable-doubt-convicted-killing-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418499/Juror-murder-trial-ex-NFLers-son-AJ-Armstrong-concerned-jury-didnt-understand-reasonable-doubt-convicted-killing-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:20:41+00:00

Lance Staudacher, a jury member from A.J. Armstrong's first murder trial, said in a statement Thursday that the most reason jury didn't understand 'reasonable doubt.'

## Ban on trophy hunting imports has 'less than 10% chance of becoming law' opponents claim as peers in the House of Lords table raft of amendments to 'clean up badly drafted' Bill
 - [https://www.dailymail.co.uk/news/article-12418995/Ban-trophy-hunting-imports-10-chance-law-opponents-claim-peers-House-Lords-table-raft-amendments-clean-badly-drafted-Bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418995/Ban-trophy-hunting-imports-10-chance-law-opponents-claim-peers-House-Lords-table-raft-amendments-clean-badly-drafted-Bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:15:00+00:00

The Hunting Trophies (Import Prohibition) Bill would prohibit bringing into the country hunting trophies from species deemed of conservation concern

## California paddleboarder, 14, dies after suffering a cardiac arrest then falling into Minnesota lake for four minutes during family vacation: Coroner reveals he had undiagnosed heart condition
 - [https://www.dailymail.co.uk/news/article-12418733/California-paddleboarder-14-dies-suffering-cardiac-arrest-falling-Minnesota-lake-four-minutes-family-vacation-Coroner-reveals-undiagnosed-heart-condition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418733/California-paddleboarder-14-dies-suffering-cardiac-arrest-falling-Minnesota-lake-four-minutes-family-vacation-Coroner-reveals-undiagnosed-heart-condition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:05:00+00:00

A 14-year-old died while paddleboarding on a family vacation in Minnesota - a coroner revealed he likely went into cardiac arrest due to an undiagnosed heart condition.

## Pensioner weeps while in court for killing his passenger in a romantic drive through Wales after crashing when he lost control of his 1950s Daimler and veered into oncoming traffic
 - [https://www.dailymail.co.uk/news/article-12418979/Pensioner-weeps-court-killing-passenger-romantic-drive-Wales-crashing-lost-control-1950s-Daimler-veered-oncoming-traffic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418979/Pensioner-weeps-court-killing-passenger-romantic-drive-Wales-crashing-lost-control-1950s-Daimler-veered-oncoming-traffic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T23:02:45+00:00

Andrew Newton, 69, had driven 150 miles from his home to visit beauty spot Llyn Crafnant in Snowdonia, North Wales - picking up Marilynn Kerrigan on the way.

## Wholesale beef and lamb prices plummet - so why are we still paying so much for meat at Coles and Woolworths?
 - [https://www.dailymail.co.uk/news/article-12415081/Wholesale-beef-lamb-prices-plummet-paying-meat-Coles-Woolworths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415081/Wholesale-beef-lamb-prices-plummet-paying-meat-Coles-Woolworths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:57:19+00:00

Despite farmers now only getting paid a pittance for their cattle and sheep from processors Aussie shoppers are unlikely to see a steep drop in meat prices any time soon, experts say.

## Trans row over Celebrity MasterChef contestant Cheryl Hole's previous use of the term 'terf' before her appearance on the show
 - [https://www.dailymail.co.uk/news/article-12418865/BBC-slammed-completely-inappropriate-decision-include-highly-sexualised-drag-queen-Cheryl-Hole-29-Celebrity-Masterchef.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418865/BBC-slammed-completely-inappropriate-decision-include-highly-sexualised-drag-queen-Cheryl-Hole-29-Celebrity-Masterchef.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:57:14+00:00

Cheryl Hole, 29, (pictured) featured in the debut series of RuPaul's Drag Race UK in 2019 and took part in this week's episode of the cooking show where she was eliminated.

## Johnny 5 is alive! Dad-of-two forks out £20,000 to build 200kg recreation of the walking, talking, dancing droid from the Short Circuit films
 - [https://www.dailymail.co.uk/news/article-12418889/Johnny-5-alive-Dad-two-forks-20-000-build-200kg-recreation-walking-talking-dancing-droid-Short-Circuit-films.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418889/Johnny-5-alive-Dad-two-forks-20-000-build-200kg-recreation-walking-talking-dancing-droid-Short-Circuit-films.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:52:01+00:00

Ryan Howard spent more than £20,000 and six years recreating the walking, talking, dancing robot - which renames itself from Number 5 to Johnny in Short Circuit - in his garage

## Trump mocks Biden for not being able to walk down stairs in softball TV interview with former aide Larry Kudlow where he rails against dishwasher standards and skates through indictment question
 - [https://www.dailymail.co.uk/news/article-12418681/Trump-mocks-Biden-not-able-walk-stairs-softball-TV-interview-former-aide-Larry-Kudlow-rails-against-dishwasher-standards-skates-indictment-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418681/Trump-mocks-Biden-not-able-walk-stairs-softball-TV-interview-former-aide-Larry-Kudlow-rails-against-dishwasher-standards-skates-indictment-question.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:36:31+00:00

Former President Donald Trump mocked President Joe Biden for not being able to talk or walk down stairs in an interview Thursday with Fox Business Network's Larry Kudlow.

## Adorable moment newborn mountain lions attempt to roar at scientists in California after they enter their den
 - [https://www.dailymail.co.uk/news/article-12418495/California-scientists-try-teach-mountain-lion-cub-roar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418495/California-scientists-try-teach-mountain-lion-cub-roar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:21:42+00:00

Shared to social media this month by the Santa Monica Mountains National Park Service (NPS), the clip shows the two cubs giving their best efforts to intimidate the intruding scientists.

## Graham Linehan breaks down in tears and vows to defeat 'evil trans activists' as he defiantly performs on the street at the Edinburgh festival after being cancelled by two venues over his gender critical views
 - [https://www.dailymail.co.uk/news/article-12418673/Graham-Linehan-breaks-tears-vows-defeat-evil-trans-activists-defiantly-performs-street-Edinburgh-festival-cancelled-two-venues-gender-critical-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418673/Graham-Linehan-breaks-tears-vows-defeat-evil-trans-activists-defiantly-performs-street-Edinburgh-festival-cancelled-two-venues-gender-critical-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:20:03+00:00

Father Ted writer Graham Linehan (pictured) vowed to defeat 'evil trans activists' as he broke down in tears after defiantly performing on the street after two venues cancelled an Edinburgh Fringe show.

## Woman killed alongside her dog in Mendota, California after stepping in the dark on powerline that fell to the ground after being damaged in a fire
 - [https://www.dailymail.co.uk/news/article-12418637/Woman-killed-alongside-dog-Mendota-California-stepping-dark-powerline-fell-ground-damaged-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418637/Woman-killed-alongside-dog-Mendota-California-stepping-dark-powerline-fell-ground-damaged-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:19:55+00:00

The woman, who has yet to be identified, was walking along a rural stretch of Highway 180 and San Mateo Avenue near her home at around 5am on Wednesday.

## Diane Sawyer lists stunning 20-acre Martha's Vineyard beachfront estate for $24M, 28 years after buying it for $5.3M with late husband Mike Nichols
 - [https://www.dailymail.co.uk/news/article-12418053/Diane-Sawyer-lists-Marthas-Vineyard-beachfront-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418053/Diane-Sawyer-lists-Marthas-Vineyard-beachfront-estate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:19:51+00:00

Diane Sawyer hopes to turn a $19 million profit on her Martha's Vineyard estate, named 'Chip Chop'.

## EXCLUSIVE: Photos Lindsay Shiver allegedly sent to accused hitman Faron Newbold to kill husband Robert Shiver in the Bahamas are revealed for the first time
 - [https://www.dailymail.co.uk/news/article-12418535/Photos-Lindsay-Shiver-allegedly-sent-accused-hitman-Faron-Newbold-kill-husband-Robert-Shiver-Bahamas-revealed-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418535/Photos-Lindsay-Shiver-allegedly-sent-accused-hitman-Faron-Newbold-kill-husband-Robert-Shiver-Bahamas-revealed-time.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:19:33+00:00

Snaps show Robert Shiver, 38, cozying up to a mystery blonde at local Bahamas bar Grabbers, where wife Lindsay Shiver's new bartender beau Terrance Bethel, 28, worked.

## Controversial foul-mouthed grocer causes outrage after making a disgusting slur against the Matildas
 - [https://www.dailymail.co.uk/news/article-12418563/Controversial-foul-mouthed-grocer-causes-outrage-making-disgusting-slur-against-Matildas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418563/Controversial-foul-mouthed-grocer-causes-outrage-making-disgusting-slur-against-Matildas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:16:17+00:00

St Bernards Fruit and Veg Market owner John Kapiris from Adelaide has posted a series of videos in recent weeks about the Matildas, but has sparked outrage over a disgusting slur.

## REVEALED: Cop that carried out Kansas newspaper raid 'was secretly recorded by a female officer making insulting and sexist comments before being reassigned to 'dogwatch' shift', police sources claim
 - [https://www.dailymail.co.uk/news/article-12418635/Cop-carried-Kansas-newspaper-raid-secretly-recorded-female-officer-making-insulting-sexist-comments-reassigned-dogwatch-shift-police-sources-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418635/Cop-carried-Kansas-newspaper-raid-secretly-recorded-female-officer-making-insulting-sexist-comments-reassigned-dogwatch-shift-police-sources-claim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:10:52+00:00

The police chief that carried out a raid on a small town Kansas newspaper, Gideon Cody, 54, was secretly recorded by a female officer making insulting and sexist comments.

## Record plunge in A-level grades leaves 60,000 teenagers scrambling for university places with 73,000 fewer A*s and As awarded compared to last year as those who got the grades they wanted celebrate
 - [https://www.dailymail.co.uk/news/article-12418691/Record-plunge-level-grades-leaves-60-000-teenagers-scrambling-university-places-73-000-fewer-s-awarded-compared-year-got-grades-wanted-celebrate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418691/Record-plunge-level-grades-leaves-60-000-teenagers-scrambling-university-places-73-000-fewer-s-awarded-compared-year-got-grades-wanted-celebrate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T22:06:09+00:00

Tens of thousands of A-level pupils were desperately trying to find a university place last night following a record drop in grades.

## Furious Donald Trump demands Fox News stop showing unflattering photo of him where he looks 'big and orange' with his 'chin pulled way back'
 - [https://www.dailymail.co.uk/news/article-12418749/Furious-Donald-Trump-demands-Fox-News-stop-showing-unflattering-photo-looks-big-orange-chin-pulled-way-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418749/Furious-Donald-Trump-demands-Fox-News-stop-showing-unflattering-photo-looks-big-orange-chin-pulled-way-back.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:59:07+00:00

Former US president Donald Trump (pictured) used to love the Right-wing news channel and is known to be a regular viewer of their morning show, 'Fox and Friends'.

## Hawaii Governor says state is NOT pursuing criminal probe into Maui wildfires that killed at least 111, as more victims are identified
 - [https://www.dailymail.co.uk/news/article-12418433/Hawaii-Governor-says-state-NOT-pursuing-criminal-probe-Maui-wildfires-killed-111-victims-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418433/Hawaii-Governor-says-state-NOT-pursuing-criminal-probe-Maui-wildfires-killed-111-victims-identified.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:57:51+00:00

Managers of a senior living complex in Maui where at least three elderly people died in the wildfires say some residents may have chosen not to evacuate after officials said the fires were '100% contained'.

## Lake Tahoe private jet crashed and killed six after pilot banked plane too steeply during final approach, causing it to stall and plunge to ground in fireball, report rules
 - [https://www.dailymail.co.uk/news/article-12418531/lake-tahoe-private-jet-crash-cause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418531/lake-tahoe-private-jet-crash-cause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:50:32+00:00

A private jet crashed and killed all six people on board in July 2021 following errors from both pilots, according to federal investigators.

## EXCLUSIVE: Maui wildfires: Candee Olafson reveals how she fled Lahaina on her tiny blue moped - as she slams police for 'hindering' motorists' attempts to evacuate
 - [https://www.dailymail.co.uk/news/article-12417615/Maui-wildfires-survivor-Candee-Olafson-remarkable-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417615/Maui-wildfires-survivor-Candee-Olafson-remarkable-escape.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:45:46+00:00

Wildfire survivor Candee Olafson, 65, blamed police for hindering evacuation efforts in Lahaina after cops allegedly had locals 'going in circles' for over an hour before allowing people to flee.

## Detroit auto workers strike would cost US economy nearly $6 BILLION in just 10 days, study predicts as union prepares to vote on work stoppage
 - [https://www.dailymail.co.uk/news/article-12418099/Detroit-auto-workers-strike-UAW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418099/Detroit-auto-workers-strike-UAW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:27:21+00:00

With less than a month before a September 14 deadline to reach new contracts, concerns about the impact of a walkout by UAW members at one or all of the Detroit Three are growing.

## CIA SUED for working with the Biden campaign to produce 'Dirty 51' intel letter calling Hunter's laptop disinformation
 - [https://www.dailymail.co.uk/news/article-12418699/CIA-SUED-allegedly-working-Biden-campaign-produce-Dirty-51-intel-letter-calling-Hunters-laptop-disinformation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418699/CIA-SUED-allegedly-working-Biden-campaign-produce-Dirty-51-intel-letter-calling-Hunters-laptop-disinformation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:14:08+00:00

The CIA has been sued for its role in helping to craft a letter from 51 intelligence officials discrediting Hunter Biden 's laptop as Russian disinformation.

## Tragic teenagers, 18, who lost their lives to drugs at Glasgow nightclub as families say loss is devastating
 - [https://www.dailymail.co.uk/news/article-12418629/Tragic-teenagers-18-lost-lives-drugs-Glasgow-nightclub-families-say-loss-devastating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418629/Tragic-teenagers-18-lost-lives-drugs-Glasgow-nightclub-families-say-loss-devastating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:13:55+00:00

Scott Allison and Marcus Dick, both 18, died after attending a 13-hour rave at the SWG3 venue in Glasgow on Sunday. The deaths are not linked but are being treated as related to drug use.

## Exclusive: Trump lawyer John Eastman will move to SEVER his case from 18 other defendants including Trump and Rudy Giuliani to avoid being 'tarred' by people with 'weaker' defenses
 - [https://www.dailymail.co.uk/news/article-12418127/Trump-lawyer-John-Eastman-SEVER-case-18-defendants-including-Trump-Rudy-Giuliani-avoid-tarred-people-weaker-defenses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418127/Trump-lawyer-John-Eastman-SEVER-case-18-defendants-including-Trump-Rudy-Giuliani-avoid-tarred-people-weaker-defenses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:11:10+00:00

Lawyer John Eastman, who was indicted Tuesday, is the 'only one' of 19 defendants who acted in his role as counsel, his lawyer said. He wants to sever his case form Trump, Giuliani and others.

## Albanian drug lord who called himself 'The Devil' and boasted about chopping up his rivals has FINALLY been jailed years after Mail investigation exposed him advertising his services on Instagram
 - [https://www.dailymail.co.uk/news/article-12418617/Albanian-drug-lord-called-Devil-boasted-chopping-rivals-FINALLY-jailed-years-Mail-investigation-exposed-advertising-services-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418617/Albanian-drug-lord-called-Devil-boasted-chopping-rivals-FINALLY-jailed-years-Mail-investigation-exposed-advertising-services-Instagram.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:08:27+00:00

An Albanian drug lord exposed by the Mail boasting about chopping up rivals has finally been jailed - after revelling in his notoriety and being treated as a celebrity in his homeland.

## Stunning photos show school of humpback whales 'bubble feeding' in perfect formation off Massachusetts coast
 - [https://www.dailymail.co.uk/news/article-12418489/Stunning-photos-school-humpback-whales-bubble-feeding-perfect-formation-Massachusetts-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418489/Stunning-photos-school-humpback-whales-bubble-feeding-perfect-formation-Massachusetts-coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:07:19+00:00

Stunning photographs taken by New England Aquarium cameras show four of the humongous mammals 'bubble feeding' in perfect formation off the Massachusetts coast on Monday.

## American Bar Association plans to ban law schools from allowing 'disruptive conduct that hinders free expression' after woke students hijack Stanford and Yale meetings
 - [https://www.dailymail.co.uk/news/article-12418379/American-Bar-Association-plans-ban-law-schools-allowing-disruptive-conduct-hinders-free-expression-woke-students-hijack-Stanford-Yale-meetings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418379/American-Bar-Association-plans-ban-law-schools-allowing-disruptive-conduct-hinders-free-expression-woke-students-hijack-Stanford-Yale-meetings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T21:07:08+00:00

The powerful American Bar Association is seeking to ban 'disruptive conduct that hinders free expression' after two incidents involving woke Yale and Stanford students and in some cases, staff.

## Oliver Anthony surges to GLOBAL NUMBER ONE on Apple Music as overnight sensation's stirring lament for America 'Rich Men North of Richmond' dominates airwaves
 - [https://www.dailymail.co.uk/news/article-12418129/Oliver-Anthony-GLOBAL-NUMBER-ONE-Apple-Music-overnight-sensations-stirring-lament-America-Rich-Men-North-Richmond.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418129/Oliver-Anthony-GLOBAL-NUMBER-ONE-Apple-Music-overnight-sensations-stirring-lament-America-Rich-Men-North-Richmond.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:59:16+00:00

Oliver Anthony's 'Rich Men North of Richmond' is an international hit as the song by the Virginia factory worker has hit No. 1 on Apple Music's global charts list.

## Outraged Chicago women slam 70 year-old luxury high rise resident who's FLASHED them up to 68 times while waking around his condo nude - and cops say his behavior is legal
 - [https://www.dailymail.co.uk/news/article-12418289/Outraged-Chicago-women-slam-70-year-old-luxury-high-rise-resident-whos-FLASHED-68-times-waking-condo-nude-cops-say-behavior-legal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418289/Outraged-Chicago-women-slam-70-year-old-luxury-high-rise-resident-whos-FLASHED-68-times-waking-condo-nude-cops-say-behavior-legal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:58:51+00:00

The serial flashing has gone on for years according to two women who spoke to WGNTV about the exploits of the man, who is said to be around 70-years-old.

## Is Hunter Biden a criminal? 50% of voters believe the president's son did something illegal related to his foreign business dealings
 - [https://www.dailymail.co.uk/news/article-12418615/Is-Hunter-Biden-criminal-50-voters-believe-presidents-son-did-illegal-related-foreign-business-dealings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418615/Is-Hunter-Biden-criminal-50-voters-believe-presidents-son-did-illegal-related-foreign-business-dealings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:55:02+00:00

More Americans believe the president's son is a criminal than ever before.

## Towie-obsessed Brit mother who was the first to be jailed for travelling to Syria to join ISIS poses in her attempts to become an influencer as she tells TikTok fans, 'I don't quit and failure doesn't scare me'
 - [https://www.dailymail.co.uk/news/article-12418349/Mother-jailed-ISIS-mindset-success-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418349/Mother-jailed-ISIS-mindset-success-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:40:28+00:00

Tareena Shakil , who was dubbed the 'TOWIE jihadi' due to her love of reality TV shows, took to TikTok this week to share her what she calls her 'motivation mindset for success'.

## Most popular American restaurants on TikTok revealed: LA hotspot Catch is no.1, with NYC's iconic Katz Deli second and Yacht-like The Marine Room in La Jolla third
 - [https://www.dailymail.co.uk/news/article-12417923/Most-popular-American-restaurants-TikTok-revealed-LA-hotspot-Catch-no-1-NYCs-iconic-Katz-Deli-second-Yacht-like-Marine-Room-La-Jolla-third.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417923/Most-popular-American-restaurants-TikTok-revealed-LA-hotspot-Catch-no-1-NYCs-iconic-Katz-Deli-second-Yacht-like-Marine-Room-La-Jolla-third.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:30:11+00:00

The most popular American Restaurants on TikTok have been revealed with  Hollywood hotspot Catch, Los Angeles's coolest celebrity seafood rooftop spot, landing the number one spot.

## Ozempic sales in the US are pushing manufacturer's native Denmark to keep interest rates low due to the huge influx of foreign currency
 - [https://www.dailymail.co.uk/news/article-12418195/Ozempic-wegovy-denmark-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418195/Ozempic-wegovy-denmark-economy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:26:49+00:00

Novo is exchanging US dollars from foreign sales for kroner in such an unusual quantity that it has boosted the Danish currency relative to the euro, bankers and economists said.

## DeSantis memo reveals his upcoming GOP debate strategy: 'Sledgehammer' rising star Vivek Ramaswamy, defend Trump and ATTACK media no less than 'three to five' times
 - [https://www.dailymail.co.uk/news/article-12418225/DeSantis-memo-reveals-upcoming-GOP-debate-strategy-Sledgehammer-rising-star-Vivek-Ramaswamy-defend-Trump-ATTACK-media-no-three-five-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418225/DeSantis-memo-reveals-upcoming-GOP-debate-strategy-Sledgehammer-rising-star-Vivek-Ramaswamy-defend-Trump-ATTACK-media-no-three-five-times.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:12:01+00:00

Florida Gov. Ron DeSantis was given the advice to hit surging rival Vivek Ramaswamy with a 'sledgehammer' at next week's GOP debate.

## Massachusetts' private Deerlove School where pupils have included David H Koch and King Abdullah of Jordan issues $89M in BONDS to overhaul its dining room
 - [https://www.dailymail.co.uk/news/article-12418181/Ultra-exclusive-Massachusetts-private-school-former-students-include-royals-heirs-issues-89M-BONDS-fund-new-dining-sports-facility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418181/Ultra-exclusive-Massachusetts-private-school-former-students-include-royals-heirs-issues-89M-BONDS-fund-new-dining-sports-facility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:10:33+00:00

The former school of David H Koch and King Abdullah of Jordan, says its new facility will 'support the Academy's traditional sit-down meal experience, which is unique in this day and age'.

## Black Mississippi boy, 10, is arrested and carted to jail after cops caught him peeing behind his mother's car while she visited lawyer's office
 - [https://www.dailymail.co.uk/news/article-12417973/Black-Mississippi-boy-10-arrested-carted-jail-cops-caught-peeing-mothers-car-visited-lawyers-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417973/Black-Mississippi-boy-10-arrested-carted-jail-cops-caught-peeing-mothers-car-visited-lawyers-office.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T20:06:23+00:00

Cops in Senatobia, a town set just south of Memphis, have since apologized for the incident - with the local sheriff now calling the arresting officer's actions an 'error in judgement.'

## NYC Mayor Eric Adams seeks to house migrants in notorious Manhattan MCC JAIL where Jeffrey Epstein died - two years after run-down facility was shut down due to its dilapidated condition
 - [https://www.dailymail.co.uk/news/article-12417983/NYC-Mayor-Eric-Adams-house-migrants-notorious-Manhattan-JAIL-Jeffrey-Epstein.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417983/NYC-Mayor-Eric-Adams-house-migrants-notorious-Manhattan-JAIL-Jeffrey-Epstein.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:55:56+00:00

Two years after the MCC prison was shut down due to its run-down condition and years of scandals, New York City Mayor Eric Adams has asked for permission to house the migrant influx in the jail.

## Kenneth Wayne Felt, who shot to internet fame after coming out as gay aged 90, marries man aged just THIRTY-FOUR after signing pre-nup
 - [https://www.dailymail.co.uk/news/article-12417785/Colorado-Navy-vet-shot-internet-fame-coming-gay-aged-90-marries-man-aged-just-THIRTY-FOUR-signing-pre-nup-agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417785/Colorado-Navy-vet-shot-internet-fame-coming-gay-aged-90-marries-man-aged-just-THIRTY-FOUR-signing-pre-nup-agreement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:50:25+00:00

Kenneth Wayne Felts, now 93, tied the knot with beau Johnny Javier Hau Dzib in their backyard after they first bonded over a shared internal conflict between their sexuality and family religion.

## The most audacious art heists in history: From Mona Lisa stolen by worker who simply lifted it off the wall to theft of an Edvard Munch by crooks who left note saying: 'Thank you for the poor security'
 - [https://www.dailymail.co.uk/news/article-12417985/The-audacious-art-heists-history-Mona-Lisa-stolen-worker-simply-lifted-wall-theft-Edvard-Munch-crooks-left-note-saying-Thank-poor-security.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417985/The-audacious-art-heists-history-Mona-Lisa-stolen-worker-simply-lifted-wall-theft-Edvard-Munch-crooks-left-note-saying-Thank-poor-security.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:42:02+00:00

Throughout history people have attempted to steal the priceless pieces and precious artefacts from museums. One of the most audacious heists include the Mona Lisa being stolen by a worker.

## Stormy weather ahead! Met office warns south will be hit by six hours of thunderstorms tomorrow morning as homes and business face floods
 - [https://www.dailymail.co.uk/news/article-12417777/Stormy-weather-ahead-Met-office-warns-south-hit-six-hours-thunderstorms-tomorrow-morning-homes-business-face-floods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417777/Stormy-weather-ahead-Met-office-warns-south-hit-six-hours-thunderstorms-tomorrow-morning-homes-business-face-floods.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:29:55+00:00

The Met Office issued a yellow weather warning for thunderstorms which means that homes and businesses could face flooding due to the stormy weather between 6am and 12pm on Friday.

## Coroner urges teenage Leeds festival goers to 'heed lessons' from drug tragedy
 - [https://www.dailymail.co.uk/news/article-12418265/Coroner-urges-teenage-Leeds-festival-goers-heed-lessons-drug-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418265/Coroner-urges-teenage-Leeds-festival-goers-heed-lessons-drug-tragedy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:27:24+00:00

Coroner Kevin McLoughlin issued an appeal to festival-goers ahead of the 2023 event next week as he concluded the inquest into the death of David Celino (pictured).

## Mackenzie Shirilla TikTok about 'doing drugs and not dying' before she was jailed for murdering boyfriend and friend in drugged-up 100mph crash
 - [https://www.dailymail.co.uk/news/article-12417047/Mackenzie-Shirilla-TikTok-doing-drugs-not-dying-jailed-murdering-boyfriend-friend-drugged-100mph-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417047/Mackenzie-Shirilla-TikTok-doing-drugs-not-dying-jailed-murdering-boyfriend-friend-drugged-100mph-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:08:23+00:00

The video was filmed before Shirilla, 19, was convicted of murdering her boyfriend Dominic Russo and his friend Davion Flanagan, 20, by crashing into a building at 100mph in Strongsville, Ohio.

## Graham Linehan arrives to defiantly perform outside the Scottish Parliament after outrage at two Edinburgh festival venues that cancelled him for his gender critical views
 - [https://www.dailymail.co.uk/news/article-12418303/Another-Edinburgh-festival-venue-cancels-Graham-Linehan-replacement-gig-outrage-axing-comedian-gender-critical-views-vows-perform-outside-Scottish-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418303/Another-Edinburgh-festival-venue-cancels-Graham-Linehan-replacement-gig-outrage-axing-comedian-gender-critical-views-vows-perform-outside-Scottish-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:08:13+00:00

Father Ted writer Graham Linehan (pictured) has arrived to defiantly perform outside the Scottish Parliament after outrage that another venue cancelled an Edinburgh Fringe show.

## Newly-released images show final distressing hours of five Mexican college students as cartel thugs forced one of the victims to decapitate his childhood friend
 - [https://www.dailymail.co.uk/news/article-12417537/Newly-released-images-final-distressing-hours-five-Mexican-college-students-cartel-thugs-forced-one-victims-decapitate-childhood-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417537/Newly-released-images-final-distressing-hours-five-Mexican-college-students-cartel-thugs-forced-one-victims-decapitate-childhood-friend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:06:37+00:00

The Jalisco state Attorney General's Office is investigating whether five students filmed by a cartel are the ones whose remains were found charred in an abandoned property and burned car.

## Fury as University of Liverpool sends 119 'you're placed' emails to students in error only to REVOKE them hours later
 - [https://www.dailymail.co.uk/news/article-12418239/Fury-University-Liverpool-sends-119-youre-placed-emails-students-error-REVOKE-hours-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418239/Fury-University-Liverpool-sends-119-youre-placed-emails-students-error-REVOKE-hours-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:04:19+00:00

Hopeful students have been left 'heartbroken' as University of Liverpool sent 119 'you're placed emails' to students in error, only for them to be revoked hours later.

## Pennsylvania boy Rory Ehrlich wins contest for America's best MULLET with lofty hairstyle he's dubbed 'chedder wiz'
 - [https://www.dailymail.co.uk/news/article-12418031/Pennsylvania-boy-Rory-Ehrlich-wins-contest-Americas-best-MULLET-lofty-hairstyle-hes-dubbed-chedder-wiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418031/Pennsylvania-boy-Rory-Ehrlich-wins-contest-Americas-best-MULLET-lofty-hairstyle-hes-dubbed-chedder-wiz.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T19:04:07+00:00

A six-year-old boy from Pennsylvania has been crowned a winner at the National Mullet Championship for his lofty hairstyle.

## Girl, six, loses fight for life after being hit by van in crash that also put boy, 14, and girl, 13, in hospital
 - [https://www.dailymail.co.uk/news/article-12418113/Girl-six-loses-fight-life-hit-van-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418113/Girl-six-loses-fight-life-hit-van-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:46:20+00:00

The youngster was one of three children stuck by the van in Barton, near Preston, on Tuesday. The two other children suffered less serious injuries but remain in hospital for treatment, police said.

## Hundreds of mourners attend the funeral of sailing enthusiast, 71, 'killed by her ex-husband at the grave of their teenage son'
 - [https://www.dailymail.co.uk/news/article-12418155/Hundreds-attend-funeral-woman-killed-ex-sons-grave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418155/Hundreds-attend-funeral-woman-killed-ex-sons-grave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:39:43+00:00

Ann Blackwood, 71, (pictured) was remembered by over 250 of her family and friends today as attendees at her funeral paid their respects to the 'loving, caring and kind-hearted' mother.

## Michael Oher received $100,000 profits from The Blind Side like every other member of his adopted family, Tuohys claim in filings seeking to end their conservatorship of ex-NFL star
 - [https://www.dailymail.co.uk/news/article-12417949/Michael-Oher-received-100-000-profits-Blind-like-member-adopted-family-Tuohys-claim-filings-seeking-end-conservatorship-ex-NFL-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417949/Michael-Oher-received-100-000-profits-Blind-like-member-adopted-family-Tuohys-claim-filings-seeking-end-conservatorship-ex-NFL-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:04:25+00:00

Attorneys for the family have said that Oher was paid $100,000 in profits from 'The Blind Side', after Oher filed a suit claiming his adoptive parents tricked him into making them his conservators.

## Our Butlin's family trip turned into the holiday from hell: Mother-of-four claims her whole party was struck down ill at Skegness resort
 - [https://www.dailymail.co.uk/news/article-12418037/Our-Butlins-family-trip-turned-holiday-hell-Mother-four-claims-party-struck-ill-Skegness-resort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418037/Our-Butlins-family-trip-turned-holiday-hell-Mother-four-claims-party-struck-ill-Skegness-resort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:03:58+00:00

Laura Strickland, 34, described her family's stay at the Skegness resort in July as 'horrendous'. An investigation is currently taking place at the resort as a suspected norovirus outbreak was detected.

## Jared Bridegan's ex-wife Shanna Gardner-Fernandez is charged with his murder - 18 months after he was shot dead execution style in Jacksonville Beach
 - [https://www.dailymail.co.uk/news/article-12417947/Jared-Bridegans-ex-wife-Shanna-Gardner-Fernandez-charged-murder-18-months-shot-dead-execution-style-Jacksonville-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417947/Jared-Bridegans-ex-wife-Shanna-Gardner-Fernandez-charged-murder-18-months-shot-dead-execution-style-Jacksonville-Beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:02:33+00:00

Bridegan was shot dead execution style in the street in February 2022 after dropping off his kids with his ex-wife, Shanna Gardener-Fernandez in Jacksonville Beach, Florida.

## Awkward Americans see THEMSELVES in Ron DeSantis and begin to warm to the Florida governor as his 2024 campaign is hit by claims he has no charisma
 - [https://www.dailymail.co.uk/news/article-12417319/Awkward-Americans-Ron-DeSantis-begin-warm-Florida-governor-2024-campaign-hit-claims-no-charisma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417319/Awkward-Americans-Ron-DeSantis-begin-warm-Florida-governor-2024-campaign-hit-claims-no-charisma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T18:01:40+00:00

Awkward Americans are seeing themselves in 2024 presidential hopeful Florida Gov. Ron DeSantis as his campaign has been plagued by claims he lacks charisma.

## Mourning the 'soul of Yorkshire': Moving moment Michael Parkinson is honoured with one-minute silence at Yorkshire cricket as worlds of sport and showbiz remember chat show king
 - [https://www.dailymail.co.uk/news/article-12417929/Yorkshire-moment-Michael-Parkinson-honoured-cricket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417929/Yorkshire-moment-Michael-Parkinson-honoured-cricket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:57:27+00:00

A moving one-minute silence at Yorkshire cricket ground was among emotional tributes made in the sport at showbiz world to the 'king of the chat show' Sir Michael Parkinson after his death.

## Hawaiian Electric focused obsessively on renewable energy while only spending $245,000 on wildfire safety
 - [https://www.dailymail.co.uk/news/article-12417253/Hawaii-Electric-focused-obsessively-renewable-energy-spending-245-000-wildfire-safety.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417253/Hawaii-Electric-focused-obsessively-renewable-energy-spending-245-000-wildfire-safety.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:56:18+00:00

Hawaii's largest electricity supplier prioritized its pursuit of renewable energy over wildfire prevention, regulatory filings show.

## Oklahoma man, 28, murders his ex-wife and three children aged 2, 5 and 9 before turning gun on himself in horrific murder-suicide
 - [https://www.dailymail.co.uk/news/article-12417895/Oklahoma-murders-wife-three-children-gun-horrific-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417895/Oklahoma-murders-wife-three-children-gun-horrific-murder-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:56:09+00:00

Police say Ruben Armendariz, 28, gunned down his ex-wife Cassie Flores, 29, and their three children at her home in Oklahoma City on Wednesday night.

## Mother-of-three is spared jail for a FOURTH time for attacking police
 - [https://www.dailymail.co.uk/news/article-12418033/Mother-three-spared-jail-FOURTH-time-attacking-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12418033/Mother-three-spared-jail-FOURTH-time-attacking-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:44:48+00:00

Jessica Horne (pictured), 33, also racially abused a cabin crew member while flying on a Ryanair jet from Fuerteventura to Manchester in March 2022.

## Moment stolen JCB smashes into Co-Op in ram raid burglary attempt to make off with cash machine
 - [https://www.dailymail.co.uk/news/article-12417917/Moment-stolen-JCB-Coop-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417917/Moment-stolen-JCB-Coop-burglary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:42:11+00:00

Alfie Smith was part of an operation to steal a cash machine and its contents in Barnham in the early hours of July 4. He was on temporary leave from prison at the time.

## EXCLUSIVE: Complete the border wall? Americans say: 'Yes' - Fully 87 percent of Republican voters and even a third of Democrats want to finish Donald Trump's signature barrier, as immigration drives 2024 race
 - [https://www.dailymail.co.uk/news/article-12417135/Complete-border-wall-Americans-say-Yes-Fully-87-percent-Republican-voters-Democrats-want-finish-Donald-Trumps-signature-barrier-immigration-drives-2024-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417135/Complete-border-wall-Americans-say-Yes-Fully-87-percent-Republican-voters-Democrats-want-finish-Donald-Trumps-signature-barrier-immigration-drives-2024-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:35:26+00:00

Americans have warmed up to the idea after years of record-breaking flows of undocumented migrants into the US, straining services at the border and such cities as New York and Chicago.

## Horrifying moment a California woman, Maria Denis, is beaten nearly to death by her ex-boyfriend as her daughter screams for him to stop
 - [https://www.dailymail.co.uk/news/article-12417603/California-woman-Maria-Denis-beaten-nearly-death-ex-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417603/California-woman-Maria-Denis-beaten-nearly-death-ex-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:35:25+00:00

Maria Denis of Riverside County, California sustained broken hips and other injuries in an attack allegedly perpetrated by her ex-boyfriend earlier this week in Southern California.

## America's cheapest home hits market in Pontiac, Michigan costing just ONE DOLLAR - and it comes with a huge hole in the floor, a yard full of weeds and a roof that's 'seen better days'
 - [https://www.dailymail.co.uk/news/article-12417499/Americas-cheapest-home-hits-market-Pontiac-Michigan-costing-just-ONE-DOLLAR-comes-huge-hole-floor-yard-weeds-roof-thats-seen-better-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417499/Americas-cheapest-home-hits-market-Pontiac-Michigan-costing-just-ONE-DOLLAR-comes-huge-hole-floor-yard-weeds-roof-thats-seen-better-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:29:43+00:00

The cheapest house in the United States can be yours for a mere $1 - less than a cup of coffee or a bus ticket - but it might take some imagination if you want to make it your dream home.

## O'Reilly Auto Parts is sued by Washington AG over claims it refused to let pregnant women sit down at work or new moms to pump breast milk - and fired those who complained
 - [https://www.dailymail.co.uk/news/article-12417583/OReilly-Auto-Parts-sued-Washington-AG-claims-refused-let-pregnant-women-sit-work-new-moms-pump-breast-milk-fired-complained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417583/OReilly-Auto-Parts-sued-Washington-AG-claims-refused-let-pregnant-women-sit-work-new-moms-pump-breast-milk-fired-complained.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:29:11+00:00

O'Reilly Auto Parts is being sued by the Washington Attorney General over claims it discriminated against its pregnant employees.

## Huge sinkhole in Irondequoit, New York swallows a car and its female driver after flooding as terrified woman is heard 'screaming for help'
 - [https://www.dailymail.co.uk/news/article-12417351/Huge-sinkhole-swallows-car-female-driver-New-York-flooding-terrified-woman-heard-screaming-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417351/Huge-sinkhole-swallows-car-female-driver-New-York-flooding-terrified-woman-heard-screaming-help.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:16:32+00:00

Anthony DeSalvo said he was woken up at 5am on Wednesday morning to the sounds of a woman 'screaming for help' after she accidentally drove her car into a huge 10-foot-deep sinkhole.

## Terrifying moment flames shoot out of a Southwest Airlines plane's engine moments after take-off in Texas en route to Mexico leaving terror-stricken passenger fearing 'it's gonna go down'
 - [https://www.dailymail.co.uk/news/article-12417587/Terrifying-moment-flames-shoot-Southwest-Airlines-planes-engine-moments-Texas-en-route-Mexico-leaving-terror-stricken-passenger-fearing-gonna-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417587/Terrifying-moment-flames-shoot-Southwest-Airlines-planes-engine-moments-Texas-en-route-Mexico-leaving-terror-stricken-passenger-fearing-gonna-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T17:15:55+00:00

The footage, captured on Tuesday, shows flames roaring out of the right engine of a Southwest Airlines plane travelling from Texas to Mexico. Passenger Coale Kalisek filmed the incident.

## What a load of rubbish! Police find 200 tons of waste in middle of open countryside
 - [https://www.dailymail.co.uk/news/article-12417747/What-load-rubbish-Police-200-tons-waste-middle-open-countryside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417747/What-load-rubbish-Police-200-tons-waste-middle-open-countryside.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:54:01+00:00

Shocked police discovered what they described as an 'industrial scale' heap of rubbish on a dirt track north of Congleton, Cheshire on Tuesday afternoon. A HGV found on the site has been seized.

## Biden tells Maui 'we'll be with you as long as it takes' for wildfire recovery in pre-recorded message: President headed to Hawaii Monday following backlash for initial refusal to comment on tragedy that has killed 111
 - [https://www.dailymail.co.uk/news/article-12417679/Biden-tells-Maui-long-takes-wildfire-recovery-pre-recorded-message-President-headed-Hawaii-Monday-following-backlash-initial-refusal-comment-tragedy-killed-111.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417679/Biden-tells-Maui-long-takes-wildfire-recovery-pre-recorded-message-President-headed-Hawaii-Monday-following-backlash-initial-refusal-comment-tragedy-killed-111.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:53:52+00:00

President Biden promised to offer assistance to Maui for 'as long as it takes' ahead of his trip to the island where devastating wildfires have killed at least 111.

## Massachusetts, New Hampshire and New Jersey are named America's best states to live - but New Mexico, Alaska and Louisiana have the lowest quality of life, survey claims
 - [https://www.dailymail.co.uk/news/article-12417461/Massachusetts-New-Hampshire-New-Jersey-named-Americas-best-states-lowest-quality-life-survey-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417461/Massachusetts-New-Hampshire-New-Jersey-named-Americas-best-states-lowest-quality-life-survey-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:52:54+00:00

Found in WalletHub's '2023's Best States to Live in,' the ranking took into account factors such as affordability, education, and respective economies in each state, as well as more difficult measurers like citizens' health

## Republicans including Ted Cruz mock Jo Biden over 'creepy' clip of him telling children that 'Daddy owes you'  ice cream
 - [https://www.dailymail.co.uk/news/article-12417631/Ted-Cruz-slams-Biden-clip-telling-children-Daddy-owes-ice-cream.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417631/Ted-Cruz-slams-Biden-clip-telling-children-Daddy-owes-ice-cream.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:52:17+00:00

Joe Biden raised eyebrows after he told some children their 'daddy owes' them and that he would suggest a place for ice cream.

## Walmart earnings remain strong as richer shoppers flock to the retail giant for cheaper groceries - with hot sellers including hand blenders and kitchen tools as more families cook at home
 - [https://www.dailymail.co.uk/news/article-12417487/Walmart-earnings-remain-strong-richer-shoppers-flock-retail-giant-cheaper-groceries-hot-sellers-including-hand-blenders-kitchen-tools-families-cook-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417487/Walmart-earnings-remain-strong-richer-shoppers-flock-retail-giant-cheaper-groceries-hot-sellers-including-hand-blenders-kitchen-tools-families-cook-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:48:11+00:00

On Thursday, Walmart reported second-quarter sales of $161.6 billion, up 5.7 percent from a year ago and better than expected, as the retailer grabs market share in groceries.

## What a catch! Florida fishermen rescue adorable OWL lost 20 miles out at sea after bird landed on their fishing rod
 - [https://www.dailymail.co.uk/news/article-12417489/What-catch-Florida-fishermen-rescue-adorable-OWL-lost-20-miles-sea-bird-landed-fishing-rod.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417489/What-catch-Florida-fishermen-rescue-adorable-OWL-lost-20-miles-sea-bird-landed-fishing-rod.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:47:27+00:00

Two fishermen filmed themselves having a hoot as they rescued an adorable owl which seems to have got lost out at sea - 20 miles from the coast of Sarasota, west Florida.

## State Department forks over 300 Afghanistan withdrawal documents following mounting pressure by top Republican pushing for answers for Gold Star families TWO YEARS since the botched exit killed 13 troops
 - [https://www.dailymail.co.uk/news/article-12417749/State-Department-300-Afghanistan-withdrawal-documents-pressure-Republican-pushing-answers-Gold-Star-families-two-years-botched-exit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417749/State-Department-300-Afghanistan-withdrawal-documents-pressure-Republican-pushing-answers-Gold-Star-families-two-years-botched-exit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:46:01+00:00

Secretary of State Antony Blinken handed over 300 Afghanistan exit documents to House Republicans who are demanding the Biden administration provide answers.

## One of world's most wanted illegal immigrants is caught in NEW HAMPSHIRE 'after murdering 11 in Brazil' and dodging a 275-year prison sentence: 'Thank goodness he wasn't in sanctuary city'
 - [https://www.dailymail.co.uk/news/article-12417433/One-worlds-wanted-illegal-immigrants-caught-NEW-HAMPSHIRE-murdering-11-Brazil-dodging-275-year-prison-sentence-Thank-goodness-wasnt-sanctuary-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417433/One-worlds-wanted-illegal-immigrants-caught-NEW-HAMPSHIRE-murdering-11-Brazil-dodging-275-year-prison-sentence-Thank-goodness-wasnt-sanctuary-city.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:44:12+00:00

Antonio Jose De Abreu Vidal Filho was apprehended by immigration officers in Rye, New Hampshire, on Monday after fleeing to the United States in 2019.

## Glider pilot dies in a crash during take-off in Bedfordshire: Police appeal for witnesses as man in his 40s is pronounced dead at the scene
 - [https://www.dailymail.co.uk/news/article-12417811/Glider-pilot-dies-crash-Bedfordshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417811/Glider-pilot-dies-crash-Bedfordshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:44:10+00:00

Police have launched an appeal for witnesses after a man in his 40s was pronounced dead at the London Gliding Club's base at Dunstable Downs in Bedfordshire yesterday.

## Texas woman arrested for threatening to 'kill' Jamaica-born judge Trump called 'biased and unfair' after Q-linked site doxxes Fulton County grand jurors and racist attack on Georgia prosecutor
 - [https://www.dailymail.co.uk/news/article-12417209/Texas-woman-arrested-threatening-kill-Jamaica-born-judge-Trump-called-biased-unfair-Q-linked-site-doxxes-Fulton-County-grand-jurors-racist-attack-Georgia-prosecutor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417209/Texas-woman-arrested-threatening-kill-Jamaica-born-judge-Trump-called-biased-unfair-Q-linked-site-doxxes-Fulton-County-grand-jurors-racist-attack-Georgia-prosecutor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:37:52+00:00

The Texas woman was arrested after allegedly phoning in racial slurs saying 'we want to kill' the federal judge. In Georgia, sites have posted information about grand juries in the Trump case.

## A-Level students share their reactions after grade reveals didn't quite go to plan
 - [https://www.dailymail.co.uk/news/article-12417507/A-Level-students-share-reactions-grade-reveals-didnt-quite-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417507/A-Level-students-share-reactions-grade-reveals-didnt-quite-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:36:56+00:00

Two students have taken to TikTok to share their reaction to opening their A Level results grades.

## How Sir Michael Parkinson revealed his favourite interview which stood out among the rest over his 50-year TV career - and it wasn't a celebrity
 - [https://www.dailymail.co.uk/news/article-12417105/How-Sir-Michael-Parkinson-revealed-favourite-interview-stood-rest-50-year-TV-career-wasnt-celebrity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417105/How-Sir-Michael-Parkinson-revealed-favourite-interview-stood-rest-50-year-TV-career-wasnt-celebrity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:25:53+00:00

Dubbed as the 'King of the chat show,' Michael Parkinson was one of the world's most iconic interviewers. Last year, the iconic presenter revealed which interview was his favourite.

## People think Google maps has captured a 'UFO' in Bermuda
 - [https://www.dailymail.co.uk/news/ufos/article-12417547/People-think-Google-maps-captured-UFO-Bermuda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/ufos/article-12417547/People-think-Google-maps-captured-UFO-Bermuda.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:17:41+00:00

People have been left stunned after video claimed Google Maps caught an out-of-this-world object on camera. But not everyone is in a hurry to get on a phone call with NASA anytime soon.

## Magaluf hotel where 'Brit, 18, was gang-raped by six men' breaks its silence as it vows to show 'solidarity with the alleged victim'
 - [https://www.dailymail.co.uk/news/article-12417745/Magaluf-hotel-Brit-18-gang-raped-six-men-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417745/Magaluf-hotel-Brit-18-gang-raped-six-men-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:03:58+00:00

Six holidaymakers - five French men and one Swiss national all in their twenties - were arrested on Monday over the alleged sex attack at the BH Mallorca Resort in Magaluf.

## Sir Frederick Barclay will face no punishment for not yet handing over £100million to his ex-wife, judge rules
 - [https://www.dailymail.co.uk/news/article-12417543/Sir-Frederick-Barclay-face-no-punishment-not-handing-100million-ex-wife-judge-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417543/Sir-Frederick-Barclay-face-no-punishment-not-handing-100million-ex-wife-judge-rules.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T16:01:43+00:00

A judge has decided not to punish retired businessman Sir Frederick Barclay after concluding he had breached orders made during a High Court fight over money with ex-wife Lady Hiroko Barclay.

## World chess bans trans women from all-female contests over 'unfair advantage' fears - sparking furious sexism row
 - [https://www.dailymail.co.uk/news/article-12417149/World-chess-bans-trans-women-female-contests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417149/World-chess-bans-trans-women-female-contests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:51:02+00:00

The rule states that any player who has transitioned from male to female 'has no right to participate in official FIDE events for women' until a decision, which could take up to two years, is made.

## Taxpayers should fund $300,000 UTERUS transplants to help transgender women get pregnant, suggests American Medical Association
 - [https://www.dailymail.co.uk/news/article-12417181/American-Medical-Association-suggests-taxpayers-fund-300-000-UTERUS-transplants-help-transgender-women-pregnant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417181/American-Medical-Association-suggests-taxpayers-fund-300-000-UTERUS-transplants-help-transgender-women-pregnant.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:48:49+00:00

The American Medical Association (AMA) has suggested that taxpayers should subsidize uterus transplants worth up to $300,000 to help transgender women get pregnant.

## Hollyoaks star Frankie Jules-Hough's partner welcomes sentence review of killer driver who hit 123mph shortly before he ploughed into pregnant mother-of-two
 - [https://www.dailymail.co.uk/news/article-12417643/Hollyoaks-star-Frankie-Jules-Houghs-partner-welcomes-sentence-review-killer-driver-hit-123mph-shortly-ploughed-pregnant-mother-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417643/Hollyoaks-star-Frankie-Jules-Houghs-partner-welcomes-sentence-review-killer-driver-hit-123mph-shortly-ploughed-pregnant-mother-two.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:48:39+00:00

Frankie Jules-Hough, 38, (pictured) died in May, after Adil Iqbal, 22, lost control of his father's BMW car while speeding at 123 mph on the M66 in Greater Manchester.

## Kate Middleton is seen chatting to guests and enjoying a drink at 24-hour rave on Norfolk estate of her friend Rose Hanbury the Marchioness of Cholmondeley
 - [https://www.dailymail.co.uk/femail/article-12417119/Kate-Middleton-seen-chatting-guests-enjoying-drink-24-hour-rave-Norfolk-estate-friend-Rose-Hanbury-Marchioness-Cholmondeley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12417119/Kate-Middleton-seen-chatting-guests-enjoying-drink-24-hour-rave-Norfolk-estate-friend-Rose-Hanbury-Marchioness-Cholmondeley.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:43:21+00:00

The Princess of Wales, 41, shared a drink and chatted to other guests while rocking an all-black outfit and statement earrings at the high society Norfolk event, Houghton Festival.

## Titan CEO Stockton Rush had one hour meltdown after he got another sub stuck in Andrea Doria wreck in 2016 then hurled joystick controller at safety engineer David Lochridge to save them
 - [https://www.dailymail.co.uk/news/article-12417169/Titan-CEO-Stockton-Rush-one-hour-meltdown-sub-got-stuck-Andrea-Doria-wreck-2016-hurled-joystick-controller-safety-engineer-David-Lochridge-save-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417169/Titan-CEO-Stockton-Rush-one-hour-meltdown-sub-got-stuck-Andrea-Doria-wreck-2016-hurled-joystick-controller-safety-engineer-David-Lochridge-save-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:35:48+00:00

Stockton Rush's tantrum onboard the Titan in 2016 was reported for the first time in detail today by Vanity Fair. Rush had refused help from the engineer, insisting he could guide the sub.

## Pentagon cracks down on 'toxic' hazing behavior at West Point and other academies after a FIFTH of female cadets reported sexual harassment, often at boozy campus parties
 - [https://www.dailymail.co.uk/news/article-12417129/Pentagon-cracks-toxic-hazing-behavior-West-Point-academies-FIFTH-female-cadets-reported-sexual-harassment-boozy-campus-parties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417129/Pentagon-cracks-toxic-hazing-behavior-West-Point-academies-FIFTH-female-cadets-reported-sexual-harassment-boozy-campus-parties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:15:25+00:00

Defense Secretary Lloyd Austin called the increase of assaults and harassment 'disturbing and unacceptable,' and said the military academies have 'far more work to do to halt' the scourge.

## Photo of a public toilet at Cronulla's Shelly Beach has infuriated Australian women
 - [https://www.dailymail.co.uk/news/article-12417127/Photo-public-toilet-Cronullas-Shelly-Beach-infuriated-Australian-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417127/Photo-public-toilet-Cronullas-Shelly-Beach-infuriated-Australian-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:09:11+00:00

A council's decision to introduce surf cameras outside a change room has sparked concern in the local community with fears it may provide full view into the female rooms.

## My Apple Watch saved my life: Gadget dialled 999 while married father-of-two was trapped in wreckage after head-on crash with 44-ton lorry
 - [https://www.dailymail.co.uk/news/article-12417441/My-Apple-Watch-saved-life-Gadget-dialled-999-married-father-two-trapped-wreckage-head-crash-44-ton-lorry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417441/My-Apple-Watch-saved-life-Gadget-dialled-999-married-father-two-trapped-wreckage-head-crash-44-ton-lorry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:08:20+00:00

Father-of-two Daniel Reid, 32, from Bradford, was left trapped in the wreckage of his car and unable to move following the collision with the 44-ton truck.

## Fans share their favourite Michael Parkinson moments as they recall star getting attacked by an emu, George Michael's VERY risque interview and the time he told off Kenneth Williams
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416641/Fans-share-favourite-Michael-Parkinson-moments-recall-star-getting-attacked-emu-George-Michaels-risque-interview-time-told-Kenneth-Williams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416641/Fans-share-favourite-Michael-Parkinson-moments-recall-star-getting-attacked-emu-George-Michaels-risque-interview-time-told-Kenneth-Williams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T15:01:19+00:00

Fans recalled some of Parkinson's best moments including his very risque interview with singer George Michael.

## Skipper who led rescue of four Aussie surfers stranded at sea off coast of Indonesia reveals two key things they did that saved their lives
 - [https://www.dailymail.co.uk/news/article-12417437/Skipper-led-rescue-four-Aussie-surfers-stranded-sea-coast-Indonesia-reveals-two-key-things-did-saved-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417437/Skipper-led-rescue-four-Aussie-surfers-stranded-sea-coast-Indonesia-reveals-two-key-things-did-saved-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:59:14+00:00

Elliot Foote, girlfriend Steph Weisse and friends Will Teagle and Jordan Short were left adrift in waters off Indonesia 's Sumatra island for two nights.

## Rescue dog is reunited with his owners after fleeing Maui wildfires and being burnt on his paws, legs, back and body
 - [https://www.dailymail.co.uk/news/article-12417373/Rescue-dog-reunited-owners-Maui-wildfires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417373/Rescue-dog-reunited-owners-Maui-wildfires.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:59:11+00:00

The heartwarming tale was shared by the Maui Humane Society, which has played a leading role in rescuing and caring for animals after the fires which have killed 111 people.

## It's... Rebekah Vardy's account! WAG takes to social media AGAIN with pouty selfie after Coleen Rooney called her 'odd' in bombshell interview
 - [https://www.dailymail.co.uk/tvshowbiz/article-12417415/Rebekah-Vardy-WAG-pouty-selfie-Coleen-Rooney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12417415/Rebekah-Vardy-WAG-pouty-selfie-Coleen-Rooney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:54:38+00:00

The WAG, 41, shared a sunset snap in a plunging blue sundress, after Coleen broke her silence on their £3 million libel case.

## KENNEDY: Meatball Ron! You were the snakebite antidote to Joe v. Don and their tired brands of crazy... now suddenly you're a limp dud. But here's how you CAN get your groove back (God knows America needs it)
 - [https://www.dailymail.co.uk/news/article-12417211/Ron-DeSantis-Trump-Biden-debate-KENNEDY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417211/Ron-DeSantis-Trump-Biden-debate-KENNEDY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:48:54+00:00

KENNEDY: It'll take a helluva lot more than demoting his campaign manager and shaking the staff snow globe if he's going to amount to more than the Todd Marinovich of presidential politics.

## AJ Armstrong JR trial: Wife Kate Ober flees court in tears after he is convicted of murdering NFL star father and mother as lawyer insists he's innocent
 - [https://www.dailymail.co.uk/news/article-12417071/AJ-Armstrong-JR-trial-Wife-Kate-Ober-flees-court-tears-convicted-murdering-NFL-star-father-mother-lawyer-insists-hes-innocent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417071/AJ-Armstrong-JR-trial-Wife-Kate-Ober-flees-court-tears-convicted-murdering-NFL-star-father-mother-lawyer-insists-hes-innocent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:47:25+00:00

Defense attorney Rick Detoto said Armstrong's wife and former high school sweetheart Kate Ober was 'devastated' as he was sentenced to life with no parole for 40 years

## Moment Greek tennis star Stefanos Tsitsipas confronts woman in the crowd imitating a bee to put him off his stroke every time he serves…but he still wins the match
 - [https://www.dailymail.co.uk/news/article-12417041/Stefanos-Tsitsipas-confronts-woman-imitating-bee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417041/Stefanos-Tsitsipas-confronts-woman-imitating-bee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:46:55+00:00

A woman has apologised after she was confronted by Stefanos Tsitsipas for imitating a bee in a bizarre incident during his match at the Cincinnati Masters.

## Iconic celebrity talk show pulled from air in major ITV scheduling shake-up after it was set to return in autumn
 - [https://www.dailymail.co.uk/tvshowbiz/article-12417201/Iconic-celebrity-talk-pulled-air-major-ITV-scheduling-shake-set-return-autumn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12417201/Iconic-celebrity-talk-pulled-air-major-ITV-scheduling-shake-set-return-autumn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:46:53+00:00

An iconic celebrity talk show has been pulled from air in a major ITV scheduling shake-up.

## 'We said our goodbyes': Michael Parkinson's old friend Dickie Bird reveals he spoke to the chat show king yesterday before his death at 88 - saying 'I think he knew he was coming to the end'
 - [https://www.dailymail.co.uk/news/article-12417175/We-said-goodbyes-Michael-Parkinsons-old-friend-Dickie-Bird-reveals-spoke-chat-king-yesterday-death-88-saying-think-knew-coming-end.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417175/We-said-goodbyes-Michael-Parkinsons-old-friend-Dickie-Bird-reveals-spoke-chat-king-yesterday-death-88-saying-think-knew-coming-end.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:46:05+00:00

Sir Michael Parkinson's close friend Dickie Bird today revealed that he spoke to the broadcaster yesterday hours before he died aged 88.

## Pictured: The cigar-chomping killer who convinced his partner's family she was alive for three years while he pocketed her pension and benefits
 - [https://www.dailymail.co.uk/news/article-12417107/How-husband-murdered-wife-duped-family-thinking-alive-pocketing-pension-narcissistic-sociopath-big-ego-known-sex-pest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417107/How-husband-murdered-wife-duped-family-thinking-alive-pocketing-pension-narcissistic-sociopath-big-ego-known-sex-pest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:45:19+00:00

Stuart Williamson, 56, posted a lighthearted selfie (pictured) chomping on a cigar, while his wife Diane Douglas lay buried in an unmarked grave in their garden in Colton, Norfolk.

## Lauren Hemp has realised her potential to become England's World Cup star after Sarina Wiegman's masterstroke to push her up front
 - [https://www.dailymail.co.uk/sport/football/article-12417177/Lauren-Hemp-realised-potential-Englands-World-Cup-star-Sarina-Wiegmans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12417177/Lauren-Hemp-realised-potential-Englands-World-Cup-star-Sarina-Wiegmans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:43:52+00:00

KATHRYN BATTE: Everything changed for Hemp when Wiegman altered formation for the final group game against China.

## Man, 53, who kept a pensioner's body in his freezer for almost two years pleads guilty to using his bank cards
 - [https://www.dailymail.co.uk/news/article-12417247/Man-kept-pensioners-body-freezer-two-years-pleads-guilty-using-bank-cards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417247/Man-kept-pensioners-body-freezer-two-years-pleads-guilty-using-bank-cards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:43:10+00:00

Damion Johnson, 53, pleaded guilty to three counts of fraud when he appeared on bail at Derby Crown Court on Thursday.

## REVEALED: Letter sent by heartthrob Alabama, 30, priest who was once exorcized claims JESUS told him to flee to Italy with girl, 18, he's accused of grooming after meeting her at school
 - [https://www.dailymail.co.uk/news/article-12416901/Letter-heartthrob-Alabama-priest-fled-Italy-girl-teen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416901/Letter-heartthrob-Alabama-priest-fled-Italy-girl-teen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:41:09+00:00

Released Monday by the cops Mobile County, the letters - which include a love note sent to the 18-year-old girl in question - make it clear 30-year-old Alex Crow has no intention of returning to the US.

## Anheuser-Busch heir Billy Busch blasts CEO over transgender influencer Dylan Mulvaney controversy - 'hardworking Americans' don't 'want that kind of message pushed down their throat'
 - [https://www.dailymail.co.uk/news/article-12417015/Anheuser-Busch-heir-Billy-dylan-mulvaney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417015/Anheuser-Busch-heir-Billy-dylan-mulvaney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:38:09+00:00

Billy Busch, whose family sold Anheuser-Busch to InBev in 2008 for $52 billion, took aim at the brewery's US CEO Brendan Whitworth in an interview that aired on Wednesday.

## Rockhampton 'murders': Tayla Cox and baby Murphy smile with Matthew James Cox weeks before deaths
 - [https://www.dailymail.co.uk/news/article-12415257/Rockhampton-murders-Tayla-Cox-baby-Murphy-smile-Matthew-James-Cox-weeks-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415257/Rockhampton-murders-Tayla-Cox-baby-Murphy-smile-Matthew-James-Cox-weeks-deaths.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:36:15+00:00

Police discovered the bodies of Tayla Cox, 30, and baby Murphy Margaret at their home in Rockhampton last Thursday - two days after Matthew James Cox allegedly killed them.

## California TV producer Kathryn Hoedt, 23, dies after falling 30 feet from illegal rope swing at Folsom Lake onto rocky shoreline - as her heartbroken family says she was 'such a bright light'
 - [https://www.dailymail.co.uk/news/article-12416903/California-TV-producer-Kathryn-Hoedt-23-dies-falling-30-feet-illegal-rope-swing-rocks-picturesque-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416903/California-TV-producer-Kathryn-Hoedt-23-dies-falling-30-feet-illegal-rope-swing-rocks-picturesque-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:34:55+00:00

Kathryn Hoedt, a 23-year-old news producer in California, plummeted 30 feet onto the rocky shoreline at Folsom Lake after a dangerous homemade lake swing broke on Saturday.

## Cruise driverless car gets stuck in wet concrete in San Francisco as overjoyed construction worker says it 'illustrates how creepy and weird the whole thing is'
 - [https://www.dailymail.co.uk/news/article-12417089/Driverless-car-gets-stuck-wet-concrete-San-Francisco-overjoyed-construction-worker-says-illustrates-creepy-weird-thing-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417089/Driverless-car-gets-stuck-wet-concrete-San-Francisco-overjoyed-construction-worker-says-illustrates-creepy-weird-thing-is.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:31:22+00:00

Driverless cars have again run into trouble in San Francisco as city officials tout the dystopic vehicle that have a laundry list of issues as the way of the future.

## Ethics expert reveals whether it's right to recline seat on airplane - after Delta CEO said he'd never push his back - as Americans detail their seat back wars
 - [https://www.dailymail.co.uk/news/article-12416935/Ethics-expert-reveals-right-recline-seat-airplane-Delta-CEO-said-hed-never-push-Americans-seat-wars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416935/Ethics-expert-reveals-right-recline-seat-airplane-Delta-CEO-said-hed-never-push-Americans-seat-wars.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:30:21+00:00

Ethics expert Brett Wilmot (left) has given his opinion on whether it's right to recline your seat on an airplane - after Delta CEO Ed Bastian (inset) said he never pushes his seat back.

## EXCLUSIVE: Jewish prosthetics expert SLAMS 'stupid, horribly woke' backlash against Bradley Cooper's 'anti-Semitic' Leonard Bernstein nose
 - [https://www.dailymail.co.uk/tvshowbiz/article-12413891/Jewish-prosthetics-expert-Bradley-Cooper-nose-Leonard-Bernstein-backlash-woke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12413891/Jewish-prosthetics-expert-Bradley-Cooper-nose-Leonard-Bernstein-backlash-woke.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:17:49+00:00

Bradley's appearance in the newly-released trailer for the Leonard Bernstein biopic sparked a backlash, with some calling out the actor for playing to 'Jewface' stereotypes with the facial feature.

## Rishi Sunak tells Mohammed bin Salman he wants to meet in person 'at the earliest opportunity' amid signs Saudi Arabia's Crown Prince is set to visit the UK this autumn in his first trip since the murder of journalist Jamal Khashoggi
 - [https://www.dailymail.co.uk/news/article-12417239/Rishi-Sunak-Mohammed-bin-Salman-Saudi-Arabia-Jamal-Khashoggi-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12417239/Rishi-Sunak-Mohammed-bin-Salman-Saudi-Arabia-Jamal-Khashoggi-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:16:57+00:00

The mooted trip by Mohammed bin Salman would be the first to Britain since the murder of dissident journalist Jamal Khashoggi sparked an international outcry.

## Maui boy, 7, is found burned to death in car as local lawmaker says she fears HUNDREDS of children may be dead after power cut kept them home from school on day of inferno
 - [https://www.dailymail.co.uk/news/article-12416967/Maui-boy-7-burned-death-car-local-lawmaker-says-fears-HUNDREDS-children-dead-power-cut-kept-home-school-day-inferno.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416967/Maui-boy-7-burned-death-car-local-lawmaker-says-fears-HUNDREDS-children-dead-power-cut-kept-home-school-day-inferno.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:15:21+00:00

The death toll from the fires increased to 111 on Wednesday night but lawmaker Elle Cochran, who is in the Hawaii House of Representatives, said it is likely to increase significantly.

## Professional storm chaser reveals his new Mississippi home built to withstand 200mph winds: Frame is bolted to foundations, and property is raised by 23ft to avoid storm surges
 - [https://www.dailymail.co.uk/news/article-12416921/Professional-storm-chaser-reveals-new-Mississippi-home-built-withstand-200mph-winds-Frame-bolted-foundations-property-raised-23ft-avoid-storm-surges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416921/Professional-storm-chaser-reveals-new-Mississippi-home-built-withstand-200mph-winds-Frame-bolted-foundations-property-raised-23ft-avoid-storm-surges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:12:03+00:00

Josh Morgerman, also known as iCyclone, told Fox News that he was on a mission to build a home in Bay St. Louis, Mississippi, capable of withstanding category-five hurricane winds.

## Lisa Wilkinson, Samantha Armytage and Richard Wilkins lead the Australian tributes for Michael Parkinson following his death at age 88: 'He was simply the best!'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416731/Australian-stars-pay-tribute-Michael-Parkinson-following-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416731/Australian-stars-pay-tribute-Michael-Parkinson-following-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T14:08:11+00:00

Richard Wilkins has paid tribute to Sir Michael Parkinson following his death at age 88.

## Hope Wilko could be saved after troubled High Street chain receives several last-minute rescue bids - with 400 stores on the brink of collapse
 - [https://www.dailymail.co.uk/news/article-12416703/Hope-Wilko-saved-High-Street-rescue-bids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416703/Hope-Wilko-saved-High-Street-rescue-bids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:57:43+00:00

New reports suggest that administrator PwC, which is handling the sell-off of the discount homeware chain, has received a number of offers for parts of the business after it collapsed last week.

## Michael Parkinson death: Follow the latest tributes and reaction after 'King of the chat show' dies aged 88
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416593/Michael-Parkinson-death-Latest-reaction-iconic-interviewer-dies-aged-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416593/Michael-Parkinson-death-Latest-reaction-iconic-interviewer-dies-aged-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:57:43+00:00

MAILONLINE LIVE BLOG:  Here follow MailOnline's live blog after iconic interviewer Michael Parkinson died aged 88.

## Gareth Southgate's successor as England men's manager could be a woman, says FA CEO Mark Bullingham, amid fans calling for Sarina Wiegman to turn them into winners too
 - [https://www.dailymail.co.uk/sport/football/article-12417023/Gareth-Southgates-successor-England-mens-manager-woman-says-FA-CEO-Mark-Bullingham-amid-fans-calling-Sarina-Wiegman-turn-winners-too.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12417023/Gareth-Southgates-successor-England-mens-manager-woman-says-FA-CEO-Mark-Bullingham-amid-fans-calling-Sarina-Wiegman-turn-winners-too.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:47:37+00:00

IAN HERBERT AND KATHRYN BATTE IN SYDNEY: FA chief Mark Bullingham said that he would seek to appoint 'the best person for job, when seeking a successor to Southgate.

## Connecticut doctor, 32, abducted after night out at Brooklyn Mirage is named, as it's revealed 'armed captor' made him spend $6,000 on shopping spree
 - [https://www.dailymail.co.uk/news/article-12416763/Connecticut-doctor-abducted-Brooklyn-Mirage-shopping-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416763/Connecticut-doctor-abducted-Brooklyn-Mirage-shopping-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:43:10+00:00

Optometrist Michael Bautista, 32, told cops that he was threatened by Anthony Benjamin, 42, after he helped to diffuse an argument with a taxi driver on July 22.

## Pupils fume they've been 'completely screwed over' by return to pre-Covid marking after top grades drop by 9% in a year - while universities start to run out of Clearing places as thousands miss out on their preferred choices
 - [https://www.dailymail.co.uk/news/article-12416943/Pupils-fume-theyve-completely-screwed-level-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416943/Pupils-fume-theyve-completely-screwed-level-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:38:11+00:00

This year's pupils who received their A-level results today did not sit GCSE exams two years ago and were awarded teacher-assessed grades amid the pandemic.

## Professional eater James Webb gets into tense argument with workers at a Compton Burgers in Perth
 - [https://www.dailymail.co.uk/news/article-12416207/Professional-eater-James-Webb-gets-tense-argument-workers-Compton-Burgers-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416207/Professional-eater-James-Webb-gets-tense-argument-workers-Compton-Burgers-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:37:05+00:00

A bitter dispute over a coffee has pitted an internationally known Australian burger joint against an internationally better known Australian competitive eater.

## National Archives must hand over records of then-VP Joe Biden's Ukraine activities that 'overlapped' with Hunter's: Republicans accelerate Biden family corruption probe after Devon Archer testifies Ukrainian company used Biden 'brand' for influence
 - [https://www.dailymail.co.uk/news/article-12416949/National-Archives-hand-records-VP-Joe-Bidens-Ukraine-activities-overlapped-Hunters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416949/National-Archives-hand-records-VP-Joe-Bidens-Ukraine-activities-overlapped-Hunters.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:34:44+00:00

The National Archives is being compelled to hand over records of then-Vice President Joe Biden's activities related to Ukraine, which may have overlapped with his son Hunter's business.

## People are only now realising the bizarre reason behind Snickers' name
 - [https://www.dailymail.co.uk/news/article-12416417/People-realising-bizarre-reason-Snickers-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416417/People-realising-bizarre-reason-Snickers-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:26:12+00:00

Snickers is a household name that every chocolate lover will have tried at least once - it's even dubbed 'the world's best-selling chocolate bar' by the Mars Company.

## Shocking moment farmer blasts Channel 4 Cheat Detectives star Liv Shelby when she asks him to slow down for her horse
 - [https://www.dailymail.co.uk/news/article-12416701/farmer-blasts-Cheat-Detectives-star-Liv-Shelby-asks-slow-horse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416701/farmer-blasts-Cheat-Detectives-star-Liv-Shelby-asks-slow-horse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:19:31+00:00

The star, known for her 'loyalty testing' videos in which she honeytraps unsuspecting unfaithful men, filmed the farmer jumping out of his tractor to shout at her: 'Never, never tell me how to drive.'

## Britain's baby bust laid bare: Births plummet to 20-YEAR low in trend partly blamed on cost-of-living crisis
 - [https://www.dailymail.co.uk/health/article-12416255/Births-plummet-20-YEAR-low.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-12416255/Births-plummet-20-YEAR-low.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:15:51+00:00

Around 600,000 live births were logged between the two nations last year - 3.1 per cent fewer than 2021. The figure has been trending downwards since 2012, Office for National Statistics data shows.

## TikToker describes terrifying moment she discovers a stranger had been living under her home for months and films police arresting him saying: 'Do you know how creepy it is to see an arm coming out of this hole'
 - [https://www.dailymail.co.uk/news/article-12416783/TikToker-describes-terrifying-moment-discovers-stranger-living-home-months-films-police-arresting-saying-know-creepy-arm-coming-hole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416783/TikToker-describes-terrifying-moment-discovers-stranger-living-home-months-films-police-arresting-saying-know-creepy-arm-coming-hole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:14:00+00:00

Ashly Guardino filmed as police came to investigate beneath her house in Lake Elsinore, California, after being awoken early in the morning by noises around her family home.

## Michael Parkinson's interviews were deemed offensive by the ABC when they replayed the iconic talk show's programs
 - [https://www.dailymail.co.uk/news/article-12416951/Michael-Parkinson-interviews-offensive-ABC-replayed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416951/Michael-Parkinson-interviews-offensive-ABC-replayed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T13:07:50+00:00

When the ABC replayed classic Parkinson programs to mark its 90th anniversary of broadcasting last year it warned some of what he discussed with his guests was no longer acceptable.

## George Hassett: Young farmer to have his organs donated after tragic car crash death leaves behind partner of four years and twin toddlers
 - [https://www.dailymail.co.uk/news/article-12416813/George-Hassett-Young-farmer-organs-donated-tragic-car-crash-death-leaves-partner-four-years-twin-toddlers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416813/George-Hassett-Young-farmer-organs-donated-tragic-car-crash-death-leaves-partner-four-years-twin-toddlers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:58:20+00:00

George Hassett, 30, was a passenger in a car that collided with a truck in heavy fog on the Hume Highway near Tarcutta, NSW , on August 11.

## England will play in BLUE in Sunday's Women's World Cup final after Spain were handed first-choice on kits... and it's all down to a clash with Lionesses' period-protected dark blue shorts!
 - [https://www.dailymail.co.uk/sport/football/article-12416961/England-BLUE-Womens-World-Cup-final-Spain-kits-clash-Lionesses-dark-blue-shorts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12416961/England-BLUE-Womens-World-Cup-final-Spain-kits-clash-Lionesses-dark-blue-shorts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:54:03+00:00

Sarina Wiegman's side will wear white socks, with Spain in their home kit, which has dark blue shorts, meaning England's home kit, which has dark blue shorts too, would clash.

## Who is Michael Parkinson's wife Mary and who are their three children? Late presenter enjoyed 60 years of marriage after meeting his wife on a bus
 - [https://www.dailymail.co.uk/femail/article-12416729/Who-Michael-Parkinsons-wife-Mary-three-children-Late-presenter-enjoyed-60-years-marriage-meeting-wife-bus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-12416729/Who-Michael-Parkinsons-wife-Mary-three-children-Late-presenter-enjoyed-60-years-marriage-meeting-wife-bus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:42:31+00:00

Here FEMAIL reveals how Sir Michael Parkinson fell in love with Doncaster-born Mary while travelling on a bus - before the two tied the knot in 1959 and welcoming three sons together...

## Amusement park boss sparks fury with 'misogynist' tweet showing a pile of washing up calling it 'the unseen side effects of the women's World Cup'
 - [https://www.dailymail.co.uk/news/article-12416853/Amusement-park-boss-sparks-fury-misogynist-tweet-showing-pile-washing-calling-unseen-effects-womens-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416853/Amusement-park-boss-sparks-fury-misogynist-tweet-showing-pile-washing-calling-unseen-effects-womens-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:31:18+00:00

A theme park owner whose 'misogynistic' tweet appeared to mock the Lionesses' upcoming World Cup final against Spain has sparked fury online.

## British Museum thief 'was selling stolen artefacts on eBay three years ago but bosses did nothing after expert told them he had spotted Roman jewellery for sale online'
 - [https://www.dailymail.co.uk/news/article-12416899/British-Museum-thief-selling-stolen-artefacts-eBay-three-years-ago-bosses-did-expert-told-spotted-Roman-jewellery-sale-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416899/British-Museum-thief-selling-stolen-artefacts-eBay-three-years-ago-bosses-did-expert-told-spotted-Roman-jewellery-sale-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:31:16+00:00

A member of staff who was allegedly stealing priceless items from the British Museum was named to bosses three years ago - after they went up for sale on eBay.

## How to change course or transfer university: What to do if you are not happy with your selection
 - [https://www.dailymail.co.uk/news/article-12412445/How-change-course-transfer-university-not-happy-selection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12412445/How-change-course-transfer-university-not-happy-selection.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:30:46+00:00

Thousands of students up and down the country have been eagerly awaiting their A-level results for months, and the day is finally here.

## Terrifying moment Lewis Hamilton's old supercar crashes in a tunnel
 - [https://www.dailymail.co.uk/news/article-12416761/Moment-Lewis-Hamiltons-old-supercar-crashes-Welsh-tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416761/Moment-Lewis-Hamiltons-old-supercar-crashes-Welsh-tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:30:42+00:00

A motorist who had been overtaken by the purple Pagani Zonda 760LH captured the moment of the crash on his dashcam while driving through the Penmaenbach Tunnel on the A55 in north Wales.

## Mackenzie Shirilla's mother tried to blame crash that killed two on her being DIZZY - despite cops finding magic mushrooms and weed at scene and her previous threats against her boyfriend
 - [https://www.dailymail.co.uk/news/article-12416779/Mackenzie-Shirillas-mother-tried-blame-crash-killed-two-DIZZY-despite-cops-finding-magic-mushrooms-weed-scene-previous-threats-against-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416779/Mackenzie-Shirillas-mother-tried-blame-crash-killed-two-DIZZY-despite-cops-finding-magic-mushrooms-weed-scene-previous-threats-against-boyfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:29:23+00:00

Her mother, Nathalie, said she 'completely disagrees' with the judge, and hopes McDonnell will file an appeal on behalf of her daughter.

## New poll finds 63% of Americans consider Trump's election fraud charges in Georgia 'serious' - as legal advisors urge former president to ABANDON his planned press conference refuting his latest indictment
 - [https://www.dailymail.co.uk/news/article-12416865/New-poll-finds-63-Americans-consider-Trumps-election-fraud-charges-Georgia-legal-advisors-urge-former-president-ABANDON-planned-press-conference-refuting-latest-indictment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416865/New-poll-finds-63-Americans-consider-Trumps-election-fraud-charges-Georgia-legal-advisors-urge-former-president-ABANDON-planned-press-conference-refuting-latest-indictment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:27:36+00:00

The poll follows intense media focus on Trump's fourth indictment in Georgia. Trump plans a press conference to debunk them, a move legal experts say is probably a bad idea.

## ABC warns old Michael Parkinson episodes could offend viewers in latest woke move
 - [https://www.dailymail.co.uk/news/article-10925847/ABC-warns-old-Michael-Parkinson-episodes-offend-viewers-latest-woke-move.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-10925847/ABC-warns-old-Michael-Parkinson-episodes-offend-viewers-latest-woke-move.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:26:51+00:00

The ABC is replaying classic  programs to mark its 90th anniversary of broadcasting but believes some of what Parkinson's guests had to say more than 40 years ago is no longer acceptable.

## Moorgate fire: Tube station is shut with 'thousands of people evacuated' as firefighters rush to tackle blaze
 - [https://www.dailymail.co.uk/news/article-12416883/Moorgate-tube-station-evacuated-fire-alert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416883/Moorgate-tube-station-evacuated-fire-alert.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:25:22+00:00

Around 1,200 people were evacuated from Moorgate tube station and surrounding buildings after a disused office block caught fire at 11.22am, according to London Fire Brigade.

## Europe's wild weather continues as German airport is submerged in floodwater and thunderstorms lash Italy - while France and Spain brace for scorching 40C heat dome
 - [https://www.dailymail.co.uk/news/article-12416185/Europes-wild-weather-continues-German-airport-flooded-Frankfurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416185/Europes-wild-weather-continues-German-airport-flooded-Frankfurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:21:15+00:00

The weather on the continent in recent months has been characterised by a north-south divide, with southern Europe suffering from extreme heat as parts of northern Europe are battered by storms.

## England fans pile the pressure on big-money sponsors Nike to start selling goalkeeper Mary Earps' shirt after her World Cup heroics after she slammed their 'hugely hurtful' commercial call
 - [https://www.dailymail.co.uk/sport/football/article-12416735/England-fans-pile-pressure-big-money-sponsors-Nike-start-selling-goalkeeper-Mary-Earps-shirt-World-Cup-heroics-slammed-hugely-hurtful-commercial-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12416735/England-fans-pile-pressure-big-money-sponsors-Nike-start-selling-goalkeeper-Mary-Earps-shirt-World-Cup-heroics-slammed-hugely-hurtful-commercial-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:20:20+00:00

While the post included several of the teams top stars, Earps was noticeably absent from the collaged image, with deputies Hannah Hampton and Ellie Roebuck also not included.

## BBC announces a huge schedule shake-up as hit show is cancelled for Michael Parkinson tribute following his death at 88
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416881/BBC-schedule-Michael-Parkinson-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416881/BBC-schedule-Michael-Parkinson-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:19:31+00:00

The veteran broadcaster, who passed away at the age of 88, was announced by his family on Thursday following a 'brief illness'.

## Kobie Parfitt: Mum's desperate plea for help before she was choked and beaten to death then dumped down a mineshaft
 - [https://www.dailymail.co.uk/news/article-12416511/Kobie-Parfitt-Mums-desperate-plea-help-choked-beaten-death-dumped-mineshaft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416511/Kobie-Parfitt-Mums-desperate-plea-help-choked-beaten-death-dumped-mineshaft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:18:06+00:00

Shannon Lee Jeffrey returned before the Victorian Supreme Court on Thursday after pleading guilty to manslaughter over the death of Kobie Parfitt, 42, also known as Kobie Snowball.

## Education Secretary Gillian Keegan claims students shouldn't fret about their A-level results because 'no one will ask about your grades in 10 years' time' as Labour slam her 'rude and dismissive' comments
 - [https://www.dailymail.co.uk/news/article-12416747/Education-Secretary-Gillian-Keegan-claims-students-shouldnt-fret-level-results-no-one-ask-grades-10-years-time-Labour-slam-rude-dismissive-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416747/Education-Secretary-Gillian-Keegan-claims-students-shouldnt-fret-level-results-no-one-ask-grades-10-years-time-Labour-slam-rude-dismissive-comments.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:17:40+00:00

The Cabinet minister claimed future employers will have more interest in a job candidate's time at university or in the workplace rather than school or college exam grades.

## 'So long Parky!': Stephen Fry and Dickie Bird lead showbiz and sports greats paying tribute to Michael Parkinson who has died at 88
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416507/So-long-Parky-Stephen-Fry-leads-showbiz-greats-paying-tribute-Michael-Parkinson-died-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416507/So-long-Parky-Stephen-Fry-leads-showbiz-greats-paying-tribute-Michael-Parkinson-died-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:12:07+00:00

Cricket legend Dickie Bird today led tributes to his 'dear friend' Sir Michael Parkinson following the television chat show host's death after a brief illness.

## Michael Parkinson was 'in good spirits' in one of his final public appearances to mark his old friend Dickie Bird's 90th birthday
 - [https://www.dailymail.co.uk/news/article-12416819/Michael-Parkinson-good-spirits-one-final-public-appearances-mark-old-friend-Dickie-Birds-90th-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416819/Michael-Parkinson-good-spirits-one-final-public-appearances-mark-old-friend-Dickie-Birds-90th-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:11:44+00:00

Sir Michael Parkinson was in good spirits and full of energy on one of his last public appearances.

## Wayne Rooney's £160k Lamborghini Gallardo Spyder - which he loaned to Carlos Tevez because he was 'bullied' for owning an Audi - goes up for auction
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416697/160k-Lamborghini-Gallardo-Spyder-lent-Wayne-Rooney-footballer-pal-Carlos-Tevez-bullied-owning-Audi-goes-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416697/160k-Lamborghini-Gallardo-Spyder-lent-Wayne-Rooney-footballer-pal-Carlos-Tevez-bullied-owning-Audi-goes-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T12:06:37+00:00

A Lamborghini Gallardo Spyder lent by football legend Wayne Rooney to a mate is up for auction.

## Boys reclaim their lead over girls for highest A* grade for first time since Covid - but narrowing gap of 'Hermione Granger types' outshining boys for A grades 'was to be expected' after return to pre-pandemic marking
 - [https://www.dailymail.co.uk/news/article-12416677/Boys-reclaim-lead-girls-highest-grade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416677/Boys-reclaim-lead-girls-highest-grade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:59:58+00:00

The proportion of boys who got an A* this year was 9.1 per cent, 0.3 points higher than girls (8.8 per cent), according to JCQ data for England, Wales and Northern Ireland.

## Inside Michael Parkinson's 'difficult' health battles: Veteran broadcaster battled cancer and had to learn how to walk again before his death at 88
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416693/Michael-Parkinson-health-battles-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416693/Michael-Parkinson-health-battles-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:53:37+00:00

The veteran broadcaster, who was fondly called 'Parky' by friends and fans, became one of the most famous names in Britain thanks to his seminal interviews.

## Is it safe to travel to Tenerife amid wildfires? Are there any foreign travel restrictions for the Spanish island?
 - [https://www.dailymail.co.uk/news/article-12416403/is-tenerife-holiday-safe-wildfires-travel-advice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416403/is-tenerife-holiday-safe-wildfires-travel-advice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:41:51+00:00

What exactly is the latest travel advice for Tenerife? Is it still safe to take a holiday to the island? Have Spanish authorities put any travel restrictions in place?

## The making of a TV icon: How Barnsley coalminer's son Michael Parkinson left school at 16 with two O-levels defied critics who said he would never make it to become King of the Chatshow
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416537/Michael-Parkinson-remembered-TV-King-Chatshow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416537/Michael-Parkinson-remembered-TV-King-Chatshow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:38:44+00:00

Sir Michael Parkinson was an icon of British broadcasting. His face and voice were cherished fixtures on the airwaves; his very name was synonymous with the best in entertainment.

## Heart-stopping moment hero cop saves one-month-old baby boy who was unconscious and turning blue after choking on breast milk and baby cereal
 - [https://www.dailymail.co.uk/news/article-12416497/Heart-stopping-moment-hero-cop-saves-one-month-old-baby-boy-unconscious-turning-blue-choking-breast-milk-baby-cereal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416497/Heart-stopping-moment-hero-cop-saves-one-month-old-baby-boy-unconscious-turning-blue-choking-breast-milk-baby-cereal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:30:36+00:00

The footage, captured in Centennial, Colorado, shows Deputy Nick Pacheco forcefully patting the baby on the back as he was 'blue, unconscious and not breathing'.

## From Gemma Collins in the diary room to jokes about hyperventilating into a paper bag: A Level students flood social media with hilarious memes as they collect their exam results
 - [https://www.dailymail.co.uk/news/article-12416495/From-Gemma-Collins-diary-room-jokes-hyperventilating-paper-bag-Level-students-flood-social-media-hilarious-memes-collect-exam-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416495/From-Gemma-Collins-diary-room-jokes-hyperventilating-paper-bag-Level-students-flood-social-media-hilarious-memes-collect-exam-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:29:34+00:00

The long-awaited decision day at the end of the summer holidays has arrived - and with it many emotions, from jubilation to disappointment to grudging acceptance.

## Rudy Giuliani 'personally begged ex-President Donald Trump to pay his legal bills during a face-to-face meeting in Mar-a-Lago in recent months'
 - [https://www.dailymail.co.uk/news/article-12416575/Rudy-Giuliani-personally-begged-ex-President-Donald-Trump-pay-legal-bills-face-face-meeting-Mar-Lago-recent-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416575/Rudy-Giuliani-personally-begged-ex-President-Donald-Trump-pay-legal-bills-face-face-meeting-Mar-Lago-recent-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:28:01+00:00

A desperate Rudy Giuliani reportedly travelled with his lawyer Robert Costello to Trump's Florida home at at Mar-a-Lago in April to plead their case for why he should pay for his former attorney's legal bills.

## We saw guests vomiting in the pool and rat droppings on the sun loungers: Dozens of Brits demand probe after sickness outbreak at 5-star Greek hotel - but resort blames THEM for bringing in the virus and not isolating
 - [https://www.dailymail.co.uk/news/article-12416549/We-saw-guests-vomiting-pool-rat-droppings-sun-loungers-Dozens-Brits-demand-probe-sickness-outbreak-5-star-Greek-hotel-resort-blames-bringing-virus-not-isolating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416549/We-saw-guests-vomiting-pool-rat-droppings-sun-loungers-Dozens-Brits-demand-probe-sickness-outbreak-5-star-Greek-hotel-resort-blames-bringing-virus-not-isolating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:27:49+00:00

Danielle Faulkner, 44, spent £3,000 on booking a family holiday to the  luxury Apollonian Asterias Resort and Spa in Kefalonia with her two daughters Amelie, 15, and Isobel, 17.

## Who is Michael Parkinson's wife Mary and who are their three children?
 - [https://www.dailymail.co.uk/news/article-12416547/Who-Michael-Parkinsons-wife-Mary-three-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416547/Who-Michael-Parkinsons-wife-Mary-three-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:22:13+00:00

The legendary broadcaster, Sir Michael Parkinson has passed away at the age of 88. Who is his wife Mary Parkinson? What was their marriage like, and who are their three children?

## Djiniyini Gondarra: Indigenous activist dubbed 'Australia's Gandhi' reveals why he is voting No in the Voice referendum
 - [https://www.dailymail.co.uk/news/article-12416125/Djiniyini-Gondarra-Indigenous-activist-dubbed-Australias-Gandhi-reveals-voting-No-Voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416125/Djiniyini-Gondarra-Indigenous-activist-dubbed-Australias-Gandhi-reveals-voting-No-Voice-referendum.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:19:50+00:00

Reverend Djiniyi Gondarra, a Dhurili Nation clan leader from northeast Arnhem Land, has spoken out about why he will be voting No to the Voice referendum.

## Michael Parkinson: From his admiration for Shane Warne to Ian Thorpe coming out as gay in a moving interview and his time Down Under - how Parky held a special place in the hearts of Australia's biggest names
 - [https://www.dailymail.co.uk/news/article-12416461/Michael-Parkinson-admiration-Shane-Warne-Ian-Thorpe-coming-gay-moving-interview-time-Parky-held-special-place-hearts-Australias-biggest-names.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416461/Michael-Parkinson-admiration-Shane-Warne-Ian-Thorpe-coming-gay-moving-interview-time-Parky-held-special-place-hearts-Australias-biggest-names.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:18:29+00:00

British broadcasting legend Sir Michael Parkinson, whose death was announced on Thursday, had a long affinity with, and love of Australia and some of its most famous celebrities.

## Queen Letizia will fly to Australia to cheer on Spain as they face England at World Cup Final - but Prince William 'and Rishi Sunak' will not be there to roar on the Lionesses in person
 - [https://www.dailymail.co.uk/news/article-12416589/Queen-Letizia-fly-Australia-cheer-Spain-face-England-World-Cup-Final-Prince-William-Rishi-Sunak-not-roar-Lionesses-person.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416589/Queen-Letizia-fly-Australia-cheer-Spain-face-England-World-Cup-Final-Prince-William-Rishi-Sunak-not-roar-Lionesses-person.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:17:38+00:00

Kensington Palace confirmed that Prince William, who is president of the Football Association, would not be making the trip Down Under, but instead will be roaring on the Lionesses from home.

## EXCLUSIVE: How Michael Parkinson celebrated his 88th and final birthday in style with a slap-up meal at celebrity seafood haunt Scott's in Mayfair
 - [https://www.dailymail.co.uk/news/article-12416571/How-Michael-Parkinson-celebrated-88th-final-birthday-style-slap-meal-celebrity-seafood-haunt-Scotts-Mayfair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416571/How-Michael-Parkinson-celebrated-88th-final-birthday-style-slap-meal-celebrity-seafood-haunt-Scotts-Mayfair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:16:47+00:00

Sir Michael Parkinson, whose death was announced today, was all smiles when he was pictured at celebrity haunt Scott's in Mayfair, west London, celebrating his 88th birthday on March 31.

## Spain manager Jorge Vilda is snubbed from celebrations with his stars at the Women's World Cup over his bizarre methods... as deep-rooted divisions from 15-player MUTINY show before final against England
 - [https://www.dailymail.co.uk/sport/football/article-12416017/Spain-reached-Womens-World-Cup-final-despite-MUTINY-squad-coach-Jorge-Vildas-Englands-love-Sarina-Wiegman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12416017/Spain-reached-Womens-World-Cup-final-despite-MUTINY-squad-coach-Jorge-Vildas-Englands-love-Sarina-Wiegman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T11:06:26+00:00

KATHRYN BATTE: The difference between how England and Spain's players feel about their respective managers is best summed up by their post-match celebrations.

## How Michael Parkinson sparred with Muhammad Ali, fell out with Meg Ryan and enraged Helen Mirren: Talk show giant's greatest interviews as he dies at 88
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416303/How-Michael-Parkinson-sparred-Muhammad-Ali-enraged-Helen-Mirren-fell-Meg-Ryan-Talk-giants-greatest-interviews-dies-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416303/How-Michael-Parkinson-sparred-Muhammad-Ali-enraged-Helen-Mirren-fell-Meg-Ryan-Talk-giants-greatest-interviews-dies-88.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:52:17+00:00

Affectionately known simply as Parky, Sir Michael Parkinson was one of the world's greatest interviewers.

## Game park worker, 30, is mauled to death by lions which attacked him while he was walking through their reserve at night in South Africa
 - [https://www.dailymail.co.uk/news/article-12416445/Game-park-worker-30-mauled-death-lions-attacked-walking-reserve-night-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416445/Game-park-worker-30-mauled-death-lions-attacked-walking-reserve-night-South-Africa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:48:53+00:00

The 30-year-old victim, Johannes Matshe, an employee of the reserve, met his gruesome fate while walking through Dinokeng Game Reserve in Gauteng after dark on Sunday night.

## New AI cameras catch British drivers using mobile phones at the wheel as 300 motorists are caught out in just three days
 - [https://www.dailymail.co.uk/news/article-12416383/New-AI-cameras-catch-British-drivers-using-mobile-phones-wheel-300-motorists-caught-just-three-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416383/New-AI-cameras-catch-British-drivers-using-mobile-phones-wheel-300-motorists-caught-just-three-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:43:52+00:00

The camera snapped 117 people using their mobile phones while driving and 130 in cars without seatbelts after being installed on the A30 near Launceston in Devon.

## BBC 'is probing the hiring of five presenters on its news channel' after claims the recruitment process was a 'sham'
 - [https://www.dailymail.co.uk/news/article-12415177/BBC-probing-hiring-five-presenters-news-channel-claims-recruitment-process-sham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415177/BBC-probing-hiring-five-presenters-news-channel-claims-recruitment-process-sham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:36:57+00:00

Presenters who got the top jobs, which come with salaries up to £230,000 a year, were allegedly told they were a shoe in before the appointments process officially began, several sources told The Times.

## Russia-Ukraine war: POW reveals brutal new torture technique that sees Ukrainians kicked around a yard while blindfolded - 'The guards mentioned a football game with the prisoners. I didn't know we were the footballs'
 - [https://www.dailymail.co.uk/galleries/article-12416569/Russia-Ukraine-war-POW-reveals-brutal-new-torture-technique-sees-Ukrainians-kicked-yard-blindfolded-guards-mentioned-football-game-prisoners-didnt-know-footballs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/galleries/article-12416569/Russia-Ukraine-war-POW-reveals-brutal-new-torture-technique-sees-Ukrainians-kicked-yard-blindfolded-guards-mentioned-football-game-prisoners-didnt-know-footballs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:36:55+00:00

Ukrainian prisoners of war have told of the horror of daily torture at a Russian detention camp (picutred) in the southern city of Taganrog, where inmates were 'used as footballs' by their captors

## Nearly one-third of new babies in England and Wales last year were to women born outside the UK - with India now the most common birth country for non-UK born mothers as Afghanistan moves into the top 10
 - [https://www.dailymail.co.uk/news/article-12416463/Nearly-one-new-babies-England-Wales-year-women-born-outside-UK-India-common-birth-country-non-UK-born-mothers-Afghanistan-moves-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416463/Nearly-one-new-babies-England-Wales-year-women-born-outside-UK-India-common-birth-country-non-UK-born-mothers-Afghanistan-moves-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:29:07+00:00

New data from the Office for National Statistics revealed the number of live births to non-UK born women increased from 179,726 in 2021 to 183,309 in 2022.

## Sam Asghari's cheating rumours re-emerge as Britney Spears' husband files for divorce just 14 months after the couple wed
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416369/Sam-Asghari-cheating-rumours-Britney-Spear-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416369/Sam-Asghari-cheating-rumours-Britney-Spear-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:22:51+00:00

Fans have been left reeling by the news that the couple have split after just 14 months after they tied the knot, amid claims Sam accused Britney of being unfaithful before moving out of their home.

## Tragic Aaron Carter's seven-bedroom home sells for $765,000 after bathroom where he was found dead in the bathtub after taking Xanax was completely remodeled
 - [https://www.dailymail.co.uk/news/article-12416363/Tragic-Aaron-Carters-seven-bedroom-home-sells-765-000-bathroom-dead-bathtub-taking-Xanax-completely-remodeled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416363/Tragic-Aaron-Carters-seven-bedroom-home-sells-765-000-bathroom-dead-bathtub-taking-Xanax-completely-remodeled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:19:42+00:00

The home, in Lancaster, California, sold on Wednesday for $335,000 more than Carter, who died aged 34, bought it for in 2019. He was found dead in his bathtub on November 5 2022.

## EXCLUSIVE: Men's jail sets up clothing exchange to make sure transgender prisoners can look their best on the wings
 - [https://www.dailymail.co.uk/news/article-12412237/Mens-jail-sets-clothing-exchange-make-sure-transgender-prisoners-look-best-wings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12412237/Mens-jail-sets-clothing-exchange-make-sure-transgender-prisoners-look-best-wings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:12:10+00:00

A men's prison, which has asked for women to donate their clothes to the jail for the inmates to wear, has been warned that the scheme is 'ripe for exploitation'.

## Is diesel really dead? The used diesel cars that INCREASED in value most in a year
 - [https://www.dailymail.co.uk/money/cars/article-12408461/Is-diesel-really-dead-used-diesel-cars-INCREASED-value-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/cars/article-12408461/Is-diesel-really-dead-used-diesel-cars-INCREASED-value-year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T10:08:01+00:00

EXCLUSIVE: Campaigners call them 'dirty' and makers are ditching them from line-ups, but there is still demand on the used market for diesels.

## Britney Spears' family 'fear the singer has no support system following split from Sam Asghari - as her only confidant now is her manager'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416297/Britney-Spears-family-fear-singer-no-support-following-split-Sam-Asghari-confidant-manager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416297/Britney-Spears-family-fear-singer-no-support-following-split-Sam-Asghari-confidant-manager.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:51:56+00:00

Britney Spears' family are reportedly concerned that she has no support system in place following her split from her husband Sam Asghari.

## Ireland star Ruesha Littlejohn delights in England knocking out Australia from the Women's World Cup after Aussie player went on holiday with her ex-girlfriend, leading to a handshake spat
 - [https://www.dailymail.co.uk/sport/football/article-12416311/Ireland-star-Ruesha-Littlejohn-delights-England-knocking-Australia-Womens-World-Cup-Aussie-player-went-holiday-ex-girlfriend-leading-handshake-spat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12416311/Ireland-star-Ruesha-Littlejohn-delights-England-knocking-Australia-Womens-World-Cup-Aussie-player-went-holiday-ex-girlfriend-leading-handshake-spat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:46:30+00:00

During Ireland's World Cup campaign, Littlejohn courted controversy in her refusal to shake the hand of Australian opponent Caitlin Foord before the Matildas beat the Irish side.

## Inside Britney Spears and Sam Asghari's $10 million prenup: How the superstar singer's $60 million net worth and assets will be affected as her marriage crumbles after a YEAR
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416005/Britney-Spears-Sam-Asghari-prenup-divorce-net-worth-marriage-crumbles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416005/Britney-Spears-Sam-Asghari-prenup-divorce-net-worth-marriage-crumbles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:38:48+00:00

Britney Spears has ensured her $60 million fortune is well-protected, after it was revealed her husband Sam Asghari has filed for divorce.

## Erin Patterson: Cops break their silence on mushroom chef's leaked police statement: 'This needs to be dealt with'
 - [https://www.dailymail.co.uk/news/article-12415929/Erin-Patterson-Cops-break-silence-mushroom-chefs-leaked-police-statement-needs-dealt-with.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415929/Erin-Patterson-Cops-break-silence-mushroom-chefs-leaked-police-statement-needs-dealt-with.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:28:18+00:00

Victoria's second highest ranking police officer has said the leaking of a statement from Erin Patterson about a mushroom meal thought to be linked to the deaths of three people is 'unhelpful'.

## Britney Spears breaks cover as Sam Asghari files for divorce: Singer emerges without wedding ring, hires Kim Kardashian's lawyer and vows to buy a HORSE... after he 'threatened to go public with embarrassing revelations'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12415315/Britney-Spears-breaks-cover-TOXIC-split-Singer-emerges-without-wedding-ring-hires-Kim-Kardashians-divorce-lawyer-amid-claims-Sam-Asghari-threatening-public-embarrassing-revelations-unless-prenup-changed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12415315/Britney-Spears-breaks-cover-TOXIC-split-Singer-emerges-without-wedding-ring-hires-Kim-Kardashians-divorce-lawyer-amid-claims-Sam-Asghari-threatening-public-embarrassing-revelations-unless-prenup-changed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:27:14+00:00

Asghari officially filed for divorce on Wednesday, citing 'irreconcilable differences' and listing July 28, 2023 as the date of separation.

## Michael Parkinson dead at 88: Legendary broadcaster and talk show host who interviewed the great and the good from John Lennon to Muhammad Ali passes away
 - [https://www.dailymail.co.uk/news/article-12416305/Michael-Parkinson-dead-88-Legendary-broadcaster-talk-host-interviewed-great-good-John-Lennon-Muhammad-Ali-passes-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416305/Michael-Parkinson-dead-88-Legendary-broadcaster-talk-host-interviewed-great-good-John-Lennon-Muhammad-Ali-passes-away.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:23:37+00:00

Sir Michael, who was fondly called 'Parky' by friends and fans, became one of the most famous names in Britain after his seminal interviews with Muhammed Ali, John Lennon Billy Connolly.

## Lionesses hit the beach! England squad enjoy some very well-earned downtime in Australia after knocking host nation out of Women's World Cup - ahead of final against Spain on Sunday
 - [https://www.dailymail.co.uk/news/article-12416081/Lionesses-hit-beach-England-squad-enjoy-earned-downtime-Australia-knocking-host-nation-Womens-World-Cup-ahead-final-against-Spain-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416081/Lionesses-hit-beach-England-squad-enjoy-earned-downtime-Australia-knocking-host-nation-Womens-World-Cup-ahead-final-against-Spain-Sunday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:21:36+00:00

Sarina Wiegman's side beat arch rivals Australia 3-1 in Sydney on Wednesday to progress to their maiden final, where they will face Spain in an event due to be watched by millions on Sunday.

## Is THIS the moment Maui's killer fires started? Powerline downed during storm appears to spark forest fire on night of August 7 when island's first fires were reported, security footage shows as death toll reaches 111
 - [https://www.dailymail.co.uk/news/article-12416111/Is-moment-Mauis-killer-fires-started-Powerline-downed-storm-appears-spark-forest-fire-night-August-7-islands-fires-reported-security-footage-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416111/Is-moment-Mauis-killer-fires-started-Powerline-downed-storm-appears-spark-forest-fire-night-August-7-islands-fires-reported-security-footage-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:19:28+00:00

The video, at the Maui Bird Conservation Center, near Makawao, appears to show a bright flash in the woods at the exact time ten sensors recorded a significant incident in Hawaiian Electric's grid.

## British 'gang-rape victim, 18, had grip marks on her arms after attack by five French men and a Swiss tourist in Magaluf': Spanish cops scour CCTV and examine hotel room
 - [https://www.dailymail.co.uk/news/article-12416231/British-gang-rape-victim-Magaluf-grip-marks-arms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416231/British-gang-rape-victim-Magaluf-grip-marks-arms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:19:20+00:00

Spanish police said on Wednesday that they had arrested five French tourists and a Swiss holidaymaker on suspicion of sexually assaulting the 18-year-old woman.

## Clearing frenzy begins: Ucas website crashes as A Level students log on to find fall in top grades and more than 19,000 students miss out on university offers in return to tough marking after Covid
 - [https://www.dailymail.co.uk/news/article-12416021/A-level-grades-revealed-amid-scramble-Clearing-university-places.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416021/A-level-grades-revealed-amid-scramble-Clearing-university-places.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:17:58+00:00

Students struggled to see their results on the Ucas website as it emerged the proportion of A-level entries awarded top grades was down on last year but remains above pre-pandemic levels.

## Britney Spears packs on the PDA with husband Sam Asghari in Cabo just WEEKS before shock split - after he accused her of cheating on him
 - [https://www.dailymail.co.uk/tvshowbiz/article-12416113/Britney-Spears-packs-PDA-Sam-Asghari-shock-split.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12416113/Britney-Spears-packs-PDA-Sam-Asghari-shock-split.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:13:58+00:00

The singer sported a fuchsia pink bikini as she enjoyed a break with the actor in Mexico back in June, giving no indication their marriage was set to crumble.

## Recession risk is 'very real' despite Rishi Sunak claiming struggling Brits will feel better off next year - as the PM bats away Tory demands for tax cuts
 - [https://www.dailymail.co.uk/news/article-12416263/Recession-risk-real-despite-Rishi-Sunak-claiming-struggling-Brits-feel-better-year-PM-bats-away-Tory-demands-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416263/Recession-risk-real-despite-Rishi-Sunak-claiming-struggling-Brits-feel-better-year-PM-bats-away-Tory-demands-tax-cuts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:13:14+00:00

Rishi Sunak reiterated that tackling inflation remains his top priority as economists highlighted the danger that further interest rate hikes could send UK plc into reverse.

## Tide turns against Clean Air Zones: Professor says it will be a year before anyone knows if city centre crackdowns on drivers will benefit health after Andy Burnham put Manchester scheme on hold
 - [https://www.dailymail.co.uk/news/article-12416129/Clean-Air-Zones-Professor-year-benefit-health-Andy-Burnham-Manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416129/Clean-Air-Zones-Professor-year-benefit-health-Andy-Burnham-Manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:11:14+00:00

It will be at least a year until experts can determine whether a clean air zone in Bradford has had any benefit on people's health, according to Professor Rosie McEachan (pictured)

## Father, 26, is found dead on a beach leaving behind devastated fiancée and stepdaughter
 - [https://www.dailymail.co.uk/news/article-12416085/Father-26-dead-beach-leaving-devastated-fianc-e-stepdaughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416085/Father-26-dead-beach-leaving-devastated-fianc-e-stepdaughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:06:17+00:00

Heartbroken family and friends have paid tribute to popular barman Toby Barrowcliff, 26, who was found dead on a beach in Herne Bay, Kent, last week.

## What are alternatives to university? Five opportunities to success that do not include higher education
 - [https://www.dailymail.co.uk/news/article-12412821/What-alternatives-university-Five-opportunities-success-not-include-higher-education.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12412821/What-alternatives-university-Five-opportunities-success-not-include-higher-education.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T09:00:46+00:00

After months of anxious waiting, A-level results day is finally here and many students will be setting off to their first-choice universities.

## Aussie surfers rescued: Elliot Foote issues tragic update hours after he and his friends were rescued from waters off Indonesia
 - [https://www.dailymail.co.uk/news/article-12415399/Aussie-surfers-rescued-Elliot-Foote-issues-tragic-update-hours-friends-rescued-waters-Indonesia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415399/Aussie-surfers-rescued-Elliot-Foote-issues-tragic-update-hours-friends-rescued-waters-Indonesia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:58:42+00:00

The Aussie surfers who spent 36 hours missing at sea off Indonesia are heartbroken that their guide Fifan has not been yet been found four days after their boat capsized

## Hunt for priceless gems stolen in British Museum heist: Police probe theft of treasures spanning back 3,400 years in major security blunder as suspicion centres on sacked worker who has not been arrested
 - [https://www.dailymail.co.uk/news/article-12416083/Hunt-priceless-gems-stolen-British-Museum-heist-Police-probe-theft-treasures-spanning-3-400-years-major-security-blunder-suspicion-centres-sacked-worker-not-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416083/Hunt-priceless-gems-stolen-British-Museum-heist-Police-probe-theft-treasures-spanning-3-400-years-major-security-blunder-suspicion-centres-sacked-worker-not-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:31:08+00:00

A hunt for stolen jewellery, gems and precious metals spanning 3,400 years of history is underway amid claims that detectives have 'some idea' about their whereabouts.

## Police arrest two men at unofficial Manchester Airport meet-and-greet car park for threatening to stab customer who said minibus was unsafe - then arrest third man for car theft after he used customer's vehicle to pick them up from police station
 - [https://www.dailymail.co.uk/news/article-12416167/Police-arrest-two-men-unofficial-Manchester-Airport-meet-greet-car-park-threatening-stab-customer-said-minibus-unsafe-arrest-man-car-theft-used-customers-vehicle-pick-police-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416167/Police-arrest-two-men-unofficial-Manchester-Airport-meet-greet-car-park-threatening-stab-customer-said-minibus-unsafe-arrest-man-car-theft-used-customers-vehicle-pick-police-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:18:40+00:00

Police have arrested two men at an 'unofficial' Manchester Airport car park over claims they threatened a customer with a knife after he challenged them over the safety of a minibus used to transfer people to the airport.

## Fears for girl, 13, who vanished vanished on Sydney's eastern beaches and has not been seen in 24 hours
 - [https://www.dailymail.co.uk/news/article-12416187/Fears-girl-13-vanished-vanished-Sydneys-eastern-beaches-not-seen-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416187/Fears-girl-13-vanished-vanished-Sydneys-eastern-beaches-not-seen-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:18:32+00:00

A teenage girl has gone missing from Sydney's Eastern Suburbs with fears for her safety due to her age.

## UCAS website CRASHES as millions of nervous A Level students try to log on to find out their exam results
 - [https://www.dailymail.co.uk/news/article-12416107/UCAS-website-CRASHES-millions-nervous-Level-students-try-log-exam-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416107/UCAS-website-CRASHES-millions-nervous-Level-students-try-log-exam-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:16:54+00:00

The UCAS website has reportedly crashed as millions of nervous A Level students attempted to log on to find out their exam results.

## Jeremy Clarkson shares annual 'inspirational' A Level tweet revealing his less than ideal results - and how he still succeeded despite them
 - [https://www.dailymail.co.uk/news/article-12416175/Jeremy-Clarkson-shares-annual-inspirational-Level-tweet-revealing-ideal-results-succeeded-despite-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416175/Jeremy-Clarkson-shares-annual-inspirational-Level-tweet-revealing-ideal-results-succeeded-despite-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:16:37+00:00

BREAKING: Jeremy Clarkson has given anxious A Level students another annual bout of reassurance after sharing his own results.

## Tenerife wildfires burn 'out of control' as top tourist area is closed off and more villages and holiday homes are evacuated
 - [https://www.dailymail.co.uk/news/article-12415991/Tenerife-wildfires-burn-uncontrollable-evacuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415991/Tenerife-wildfires-burn-uncontrollable-evacuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:13:33+00:00

The blaze broke out in a mountainous national park on the Spanish island on Wednesday and spread to 4,450 acres in 24 hours as firefighters struggled to contain the blaze amid difficult terrain conditions.

## Pubs could open early on Sunday for fans watching Lionesses in historic World Cup final - with calls for alcohol laws to be relaxed so pints can be served before 11am kick off
 - [https://www.dailymail.co.uk/news/article-12415923/Pubs-open-early-Sunday-fans-watching-Lionesses-historic-World-Cup-final-calls-alcohol-laws-relaxed-pints-served-11am-kick-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415923/Pubs-open-early-Sunday-fans-watching-Lionesses-historic-World-Cup-final-calls-alcohol-laws-relaxed-pints-served-11am-kick-off.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:06:45+00:00

The Home Secretary Suella Braverman has the powers to relax licensing laws for the 11am kick off if it is deemed 'an occasion of exceptional international, national or local significance'.

## Warning issued as 'perfect' fake $50 dollar note is spotted at a petrol station sparking fears of a major counterfeit ring
 - [https://www.dailymail.co.uk/news/article-12415989/Warning-issued-perfect-fake-50-dollar-note-spotted-petrol-station-sparking-fears-major-counterfeit-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415989/Warning-issued-perfect-fake-50-dollar-note-spotted-petrol-station-sparking-fears-major-counterfeit-ring.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:02:52+00:00

The Shell Chinderah Bay petrol station has issued a warning to its customers after a near-perfect fake $50 note, replicating many of the security features, was used there over the weekend.

## Jailed Russian general, 69, 'who knew secrets of Putin's £1billion Black Sea palace' dies mysteriously in prison ahead of parole bid - the second top Kremlin commander to perish within days
 - [https://www.dailymail.co.uk/news/article-12415979/Jailed-Russian-general-69-knew-secrets-Putins-1billion-Black-Sea-palace-dies-mysteriously-prison-ahead-parole-bid-second-Kremlin-commander-perish-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415979/Jailed-Russian-general-69-knew-secrets-Putins-1billion-Black-Sea-palace-dies-mysteriously-prison-ahead-parole-bid-second-Kremlin-commander-perish-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T08:01:05+00:00

General Gennady Lopyrev, 69, suddenly became ill on Monday - gasping for breath - and was told by doctors he had previously undiagnosed leukaemia.

## Three fine days and a thunderstorm! Britain to bask in 24C heat before end to brief sunny spell - with 'intense thunderstorms', heavy downpours and gales on the way
 - [https://www.dailymail.co.uk/news/article-12415963/Three-fine-days-thunderstorm-Britain-bask-24C-heat-end-brief-sunny-spell-intense-thunderstorms-heavy-downpours-gales-way.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415963/Three-fine-days-thunderstorm-Britain-bask-24C-heat-end-brief-sunny-spell-intense-thunderstorms-heavy-downpours-gales-way.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:54:18+00:00

Dry weather and sunny spells today will see the mercury hit 24C - with the entire country poised to enjoy at least a scattering of sunshine before thick cloud and humidity move in overnight.

## British woman, 19, 'is raped on a beach' during holiday on Greek island of Ios
 - [https://www.dailymail.co.uk/news/article-12416063/British-woman-19-raped-beach-holiday-Greek-island-Ios.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416063/British-woman-19-raped-beach-holiday-Greek-island-Ios.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:46:59+00:00

The teenager told the Greek authorities that she was raped sometime between 9pm and 10.30pm last night on the beach in the Mylopotas area of Ios.

## Missing child that vanished without a trace in Queensland is found safe and well
 - [https://www.dailymail.co.uk/news/article-12416007/Toddler-vanishes-without-trace-Bellara-Queensland-Urgent-police-search-underway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12416007/Toddler-vanishes-without-trace-Bellara-Queensland-Urgent-police-search-underway.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:36:37+00:00

Police have safely located a missing 18-month-old girl who went missing on Thursday afternoon. She was last seen in Pumicestone Street, Bellara at 4.24pm wearing a blue shirt.

## There was no crown for Wallis, but Edward created a £100m 'treasure chest of fantasy' including a glittering ZOO of jewelled big cats from Cartier...
 - [https://www.dailymail.co.uk/news/article-12405071/There-no-crown-Wallis-Edward-created-100m-treasure-chest-fantasy-including-glittering-ZOO-jewelled-big-cats-Cartier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12405071/There-no-crown-Wallis-Edward-created-100m-treasure-chest-fantasy-including-glittering-ZOO-jewelled-big-cats-Cartier.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:12:20+00:00

Edward had now attained his goal. Yet still the gifts of jewellery came until, as recounted here, the Duchess of Windsor had accumulated one of the most sensational collections in the world

## Keir Starmer backs calls for a Bank Holiday if the Lionesses win the World Cup despite Downing Street dismissing the idea
 - [https://www.dailymail.co.uk/news/article-12415943/England-Keir-Starmer-Bank-Holiday-Lionesses-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415943/England-Keir-Starmer-Bank-Holiday-Lionesses-World-Cup.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:09:56+00:00

Keir Starmer threw his weight behind a Bank Holiday despite Downing Street pouring cold water on the idea.

## Sydney's Royal Prince Alfred Hospital forced to apologise after IVF centre embryos were infected with bacteria
 - [https://www.dailymail.co.uk/news/article-12415719/Sydneys-Royal-Prince-Alfred-Hospital-forced-apologise-IVF-centre-embryos-infected-bacteria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415719/Sydneys-Royal-Prince-Alfred-Hospital-forced-apologise-IVF-centre-embryos-infected-bacteria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:02:21+00:00

Camperdown's Royal Prince Alfred Hospital has issued an apology to IVF patients after a bacterial infection contaminated 'several' embryos in the fertility unit on Wednesday.

## St Mary's stabbing: Sister speaks out after mum-of-four Drew Douglas was killed in her own home
 - [https://www.dailymail.co.uk/news/article-12415623/St-Marys-stabbing-Sister-speaks-mum-four-Drew-Douglas-killed-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415623/St-Marys-stabbing-Sister-speaks-mum-four-Drew-Douglas-killed-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T07:00:32+00:00

The heartbroken sister of a mother-of-four found stabbed to death 14 hours after a concern for welfare call from her home went unanswered has accused the police of failing her.

## Crime figure Raymon Youmaran to be released from prison on parole after serving 17 years for shooting that sparked a wave of violence
 - [https://www.dailymail.co.uk/news/article-12415861/Crime-figure-Raymon-Youmaran-released-prison-parole-serving-17-years-shooting-sparked-wave-violence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415861/Crime-figure-Raymon-Youmaran-released-prison-parole-serving-17-years-shooting-sparked-wave-violence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:50:38+00:00

Raymon Youmaran will be released from jail after serving 17 years for a shooting that sparked a wave of reprisal attacks across Sydney in the 2000s.

## Secret Australian coin scam is finally unravelled by police in Sydney
 - [https://www.dailymail.co.uk/news/article-12415609/Secret-Australian-coin-scam-finally-unravelled-police-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415609/Secret-Australian-coin-scam-finally-unravelled-police-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:38:20+00:00

A man, 36, and a woman, 37, were seized during the riot squad swoops at homes and businesses in Sydney's CBD, Haymarket and Strathfield over alleged imports of 'mutilated' Aussie coins.

## Voice to Parliament Yes campaign's merch is made in China and Bangladesh - despite saying it's printed in Australia on Naarm land
 - [https://www.dailymail.co.uk/news/article-12415111/Voice-Parliament-Yes-campaigns-merch-China-Bangladesh-despite-saying-printed-Australia-Naarm-land.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415111/Voice-Parliament-Yes-campaigns-merch-China-Bangladesh-despite-saying-printed-Australia-Naarm-land.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:35:57+00:00

Despite boasting their branded clothing is 'printed in Naarm' (Melbourne) it has emerged the official Yes campaign T-shirts and hoodies all come from factories in China and Bangladesh.

## Sydney woman convicted after she repeatedly allowed her pet Havanese dog to ingest meth and opioids
 - [https://www.dailymail.co.uk/news/article-12415745/Sydney-woman-convicted-repeatedly-allowed-pet-Havanese-dog-ingest-meth-opioids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415745/Sydney-woman-convicted-repeatedly-allowed-pet-Havanese-dog-ingest-meth-opioids.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:30:16+00:00

A reckless owner of a pet dog has been found guilty of allowing her pet to take drugs including meth and opioids. The woman from Sydney's west let her dog consume the illicit drug multiple times.

## Red-roofed house inexplicably left nearly untouched on Maui coast surrounded by burned out rubble and destroyed properties
 - [https://www.dailymail.co.uk/news/article-12415801/Red-roofed-house-inexplicably-left-nearly-untouched-Maui-coast-surrounded-burned-rubble-destroyed-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415801/Red-roofed-house-inexplicably-left-nearly-untouched-Maui-coast-surrounded-burned-rubble-destroyed-properties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:13:31+00:00

New photos show the two-story house with white walls and red roof, miraculously unharmed amidst the apocalyptic devastation surrounding it.

## A-level results day 2023: Pupils face 'bitter pill' of lower grades as marking returns to pre-pandemic levels with far fewer As and A*s predicted
 - [https://www.dailymail.co.uk/news/article-12415839/A-level-results-day-2023-Pupils-face-bitter-pill-lower-grades-marking-returns-pre-pandemic-levels-far-fewer-s-predicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415839/A-level-results-day-2023-Pupils-face-bitter-pill-lower-grades-marking-returns-pre-pandemic-levels-far-fewer-s-predicted.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:08:11+00:00

MAILONLINE LIVEBLOG: Students in England, Wales and Northern Ireland will receive A-level, T-level and BTec results this morning, with grades expected to plunge to pre-pandemic levels.

## California family of seven thanks local Lahaian hero who led them into the sea and floated for three hours together on plywood as firestorm killed at least 110 people
 - [https://www.dailymail.co.uk/news/article-12415651/Hawaii-wildfires-jump-ocean-Coast-Guard-rescue-family-seven-Jubee-Bedoya.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415651/Hawaii-wildfires-jump-ocean-Coast-Guard-rescue-family-seven-Jubee-Bedoya.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:05:21+00:00

Jubee Bedoya, from Lahaina, helped save a family of seven from California during the wildfires that destroyed his home and town of Lahaina. He said he is glad they survived.

## A Level students brace for 'bitter pill' with grades set to take the biggest plunge on record as stricter marking finally returns after Covid - with an estimated 100,000 fewer entries to be awarded A or A*
 - [https://www.dailymail.co.uk/news/article-12415837/A-Level-students-brace-bitter-pill-grades-biggest-plunge-record-grades-stricter-marking-returns-lockdown-leniency-estimated-100-000-fewer-entries-awarded-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415837/A-Level-students-brace-bitter-pill-grades-biggest-plunge-record-grades-stricter-marking-returns-lockdown-leniency-estimated-100-000-fewer-entries-awarded-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:03:14+00:00

A-level pupils are bracing for a 'bitter pill' as grades as top grades take the biggest plunge on record.

## Defiant Maui emergency leader, who has no experience in crisis management, says activating the island's emergency sirens would have saved NO ONE - as fears grow majority of dead were children left home alone with schools closed
 - [https://www.dailymail.co.uk/news/article-12415577/Maui-fires-emergency-sirens-children-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415577/Maui-fires-emergency-sirens-children-dead.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:02:21+00:00

Maui's emergency management chief defended his decision to not activate warning sirens during the deadly wildfire, as some question his qualifications for his position.

## Average salaries from Australian Bureau of Statistics figures show what you really need to earn to be considered rich in Australia
 - [https://www.dailymail.co.uk/news/article-12415439/Average-salaries-Australian-Bureau-Statistics-figures-really-need-earn-considered-rich-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415439/Average-salaries-Australian-Bureau-Statistics-figures-really-need-earn-considered-rich-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:00:50+00:00

An Australian earning less than $95,000 is now below-average in the full-time salary stakes. Among the 18 employment categories, seven of them are now typically in the six-figure range.

## Results day: What to do if you don't get the exam results you need. Expert advice for all A-level and GSCE students
 - [https://www.dailymail.co.uk/news/article-12404721/a-level-gcse-exam-results-day-grades-needed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12404721/a-level-gcse-exam-results-day-grades-needed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T06:00:46+00:00

Exam day can feel like the most important and daunting day of your life. Some of us leave it overjoyed, while others come away feeling glum. What should you do if your grades fell short?

## Police launch probe after more than 30 people fall ill after 'carbon monoxide poisoning' at indoor go-karting track
 - [https://www.dailymail.co.uk/news/article-12415805/30-people-fall-ill-carbon-monoxide-poisoning-indoor-karting-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415805/30-people-fall-ill-carbon-monoxide-poisoning-indoor-karting-track.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:49:43+00:00

Lincolnshire Police said that 33 people were believed to have fallen ill after attending Proport Indoor Karting in Lincoln on Tuesday.

## Lawyers for John Gotti Jr., Carmine Tramunti and Dominick Trinchera say mobsters are 'f****** thrilled' Rudy Guiliani is indicted on RICO charges - which he used to take down organized crime - as 'karma is about to crush him'
 - [https://www.dailymail.co.uk/news/article-12415697/Lawyers-John-Gotti-Jr-Carmine-Tramunti-Dominick-Trinchera-say-mobsters-f-thrilled-Rudy-Guiliani-indicted-RICO-charges-used-organized-crime-karma-crush-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415697/Lawyers-John-Gotti-Jr-Carmine-Tramunti-Dominick-Trinchera-say-mobsters-f-thrilled-Rudy-Guiliani-indicted-RICO-charges-used-organized-crime-karma-crush-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:40:47+00:00

Lawyers for mafia members who once did battle with Rudy Giuliani over the same RICO charges he used on their clients appear to be having the last laugh against the former mayor.

## Mortgage rates could soon hit 8 PERCENT - mark not seen since 2000 - as feds consider further interest rate hikes
 - [https://www.dailymail.co.uk/news/article-12415665/mortgage-rates-8-percent-cost-feds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415665/mortgage-rates-8-percent-cost-feds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:33:24+00:00

Economists have predicted mortgage rates could go above 8 percent if the economy continues to show signs of strength and the US Federal Reserve decides to raise interest rates again.

## PICTURED: Abigail Jo Shry accused of calling DC Judge Tanya Chutkan overseeing Donald Trump's federal case saying 'we want to kill you'
 - [https://www.dailymail.co.uk/news/article-12415571/Abigail-Jo-Shry-Judge-Tanya-Chutkan-message-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415571/Abigail-Jo-Shry-Judge-Tanya-Chutkan-message-election.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:32:43+00:00

A Texas woman and supporter of former President Donald Trump has been charged with threatening to kill the federal judge overseeing the criminal case against Trump.

## Historic William Crowther statue in Hobart is greenlit to be torn down by Tasmanian council after standing for more than 130 years
 - [https://www.dailymail.co.uk/news/article-12415515/Historic-William-Crowther-statue-Hobart-greenlit-torn-Tasmanian-council-standing-130-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415515/Historic-William-Crowther-statue-Hobart-greenlit-torn-Tasmanian-council-standing-130-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:29:49+00:00

A statue of a disgraced 19th century Aussie politician, who mutilated an Aboriginal man's dead body, will be torn down after a 'woke' council approved its removal.

## Family break silence after their much-loved boy is stabbed to death at Corindi Beach in NSW as mother prepares for his funeral
 - [https://www.dailymail.co.uk/news/article-12415077/Family-break-silence-loved-boy-stabbed-death-Corindi-Beach-NSW-mother-prepares-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415077/Family-break-silence-loved-boy-stabbed-death-Corindi-Beach-NSW-mother-prepares-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:18:06+00:00

The aunt of a 16-year-old who was allegedly stabbed by a 17-year-old school peer has shared her heartbreak after the teen was charged with murder.

## Victorian premier Dan Andrews' popularity plummets to lowest level in years after gas ban and Commonwealth Games cancellation
 - [https://www.dailymail.co.uk/news/article-12415555/Victorian-premier-Dan-Andrews-popularity-plummets-lowest-level-years-gas-ban-Commonwealth-Games-cancellation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415555/Victorian-premier-Dan-Andrews-popularity-plummets-lowest-level-years-gas-ban-Commonwealth-Games-cancellation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T05:10:27+00:00

Support for Daniel Andrews has plummeted following his push to ban gas in new homes, cancelling the Commonwealth Games and a string of scandals.

## Mushroom cook Erin Patterson's ex husband Simon made eerie Instagram comments before three died: 'It's only illegal if you get caught'
 - [https://www.dailymail.co.uk/news/article-12415293/Mushroom-cook-Erin-Pattersons-ex-husband-Simon-eerie-Instagram-comments-three-died-illegal-caught.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415293/Mushroom-cook-Erin-Pattersons-ex-husband-Simon-eerie-Instagram-comments-three-died-illegal-caught.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:49:50+00:00

A bizarre old Instagram post by the ex-husband of the beef wellington pie chef in the Death Cap mushroom tragedy about 'forgiveness' and 'not getting caught' has emerged.

## Chess world is rocked by ANOTHER scandal as platform Chess.com cuts ties with St Louis club for 'ignoring sexual misconduct allegations against top grandmaster'
 - [https://www.dailymail.co.uk/news/article-12415489/Chess-world-sexual-misconduct-STL-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415489/Chess-world-sexual-misconduct-STL-club.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:49:33+00:00

The chess world is facing a #MeToo reckoning as Chess.com cuts ties with the prestigious St Louis club for allegedly mishandling sexual misconduct allegations.

## Beenleigh watchhouse death: Man, 21, who died after being arrested had been jailed for running down police officer Peter McAulay in 2018
 - [https://www.dailymail.co.uk/news/article-12415325/Beenleigh-watchhouse-death-man-21-died-arrested-jailed-running-police-officer-Peter-McAulay-2018.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415325/Beenleigh-watchhouse-death-man-21-died-arrested-jailed-running-police-officer-Peter-McAulay-2018.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:44:46+00:00

A man who died in police custody after he was arrested on a return-to-prison warrant was the offender who seriously injured a police officer in a 2018 hit-and-run incident.

## EXCLUSIVE: Beverly Hills man who masterminded burglaries from the rich and famous, including Usher and Adam Lambert, with the help of his friend is seen in court
 - [https://www.dailymail.co.uk/news/article-12415491/Benjamin-Ackerman-Beverly-Hills-theft-Usher-Adam-Lambert-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415491/Benjamin-Ackerman-Beverly-Hills-theft-Usher-Adam-Lambert-trial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:30:18+00:00

Benjamin Ackerman, 37, appeared in court in Los Angeles for a pretrial hearing ahead of his August 21 trial on three counts of burglary. He has pleaded guilty to multiple other counts of theft.

## St Marys alleged stabbing update: Shaun King will remain on remand for two months following death of Drew Douglas
 - [https://www.dailymail.co.uk/news/article-12415511/St-Marys-alleged-stabbing-update-Shaun-King-remain-remand-two-months-following-death-Drew-Douglas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415511/St-Marys-alleged-stabbing-update-Shaun-King-remain-remand-two-months-following-death-Drew-Douglas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:10:44+00:00

Police allege Shaun King, 35, murdered his longtime partner Drew Douglas, 31, before 6.45am on Wednesday.

## Anheuser-Busch heir Billy Busch to buy back Bud Light after Dylan Mulvaney campaign causes $27billion loss
 - [https://www.dailymail.co.uk/news/article-12415249/Anheuser-Busch-heir-Billy-Busch-Bud-light-buy-company.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415249/Anheuser-Busch-heir-Billy-Busch-Bud-light-buy-company.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:10:21+00:00

Heir to Anheuser-Busch, Billy Busch, said his family would gladly buy back Bud Light from InBev in an effort to save the ailing brand.

## Mushroom deaths Victoria: What's next for Erin Patterson - cook of the lunch that killed three
 - [https://www.dailymail.co.uk/news/article-12414687/Mushroom-deaths-Victoria-Whats-Erin-Patterson-cook-lunch-killed-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414687/Mushroom-deaths-Victoria-Whats-Erin-Patterson-cook-lunch-killed-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T04:03:36+00:00

Former Victoria Police detective Charlie Bezzina has outlined the next possible steps in the investigation, whom officers will quiz and the many questions that remain unresolved

## Outback Wrangler Matt Wright fears his mates have turned on him and done a deal to testify - as he reveals his long list of demands from the court
 - [https://www.dailymail.co.uk/news/article-12415127/Outback-Wrangler-Matt-Wright-fears-mates-turned-deal-testify-reveals-long-list-demands-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415127/Outback-Wrangler-Matt-Wright-fears-mates-turned-deal-testify-reveals-long-list-demands-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T03:55:24+00:00

Outback Wrangler Matt Wright suspects his mates may have been done a deal to testify against him over the death of his best friend and TV co-star Chris Wilson.

## Plum house fire: Man, 56, dies four days after Rustic Ridge neighborhood was rocked by deadly blast with death toll now at six
 - [https://www.dailymail.co.uk/news/article-12415481/home-exploded-plum-sixth-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415481/home-exploded-plum-sixth-victim.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T03:52:35+00:00

A man who spent four days battling for his life in a burn unit became the sixth confirmed victim of the mystery explosion , which also killed his wife, in the Pennsylvania mining town of Plum.

## Sydney CBD speed limits could be slashed to 30km/h under proposed plans by Lord Mayor Clover Moore's council
 - [https://www.dailymail.co.uk/news/article-12415209/Sydney-CBD-speed-limits-slashed-30km-h-proposed-plans-Lord-Mayor-Clover-Moores-council.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415209/Sydney-CBD-speed-limits-slashed-30km-h-proposed-plans-Lord-Mayor-Clover-Moores-council.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T03:30:58+00:00

A new council proposal could see the speed limit in one city's CBD reduced to just 30km/h in a deliberate attempt to force drivers out of high-traffic areas.

## Indigenous Voice to Parliament: Mitcham Council in Adelaide backflips on decision to spend $40,000 on Yes campaign
 - [https://www.dailymail.co.uk/news/article-12415237/Indigenous-Voice-Parliament-Mitcham-Council-Adelaide-backflips-decision-spend-40-000-Yes-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415237/Indigenous-Voice-Parliament-Mitcham-Council-Adelaide-backflips-decision-spend-40-000-Yes-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T03:23:53+00:00

Councillors from Adelaide's Mitcham Council voted recently to allocate $40,000 from the 2023-2024 budget to promote the Yes vote ahead of the national referendum on October.

## Mystery after fit and healthy father Dave Orange from Brisbane suddenly drops dead leaving behind his wife and seven-month-old daughter
 - [https://www.dailymail.co.uk/news/article-12415135/Mystery-fit-healthy-father-Dave-Orange-Brisbane-suddenly-drops-dead-leaving-wife-seven-month-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415135/Mystery-fit-healthy-father-Dave-Orange-Brisbane-suddenly-drops-dead-leaving-wife-seven-month-old-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:59:03+00:00

A fit and healthy young cricketer who left behind a wife and baby daughter after dropping dead suddenly has been remembered for his 'zest for life'.

## Nuclear material is found during Australian Border Force raid on suburban home in south Sydney
 - [https://www.dailymail.co.uk/news/article-12415435/nuclear-isotopes-material-Australian-Border-Force-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415435/nuclear-isotopes-material-Australian-Border-Force-raid.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:51:05+00:00

Nuclear material has been uncovered during an Australian Border Force raid on a suburban Sydney home.

## Stepmother writes disturbing list of living conditions for daughter at Wagga Wagga, NSW
 - [https://www.dailymail.co.uk/news/article-12415089/Stepmother-writes-disturbing-list-living-conditions-daughter-Wagga-Wagga-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415089/Stepmother-writes-disturbing-list-living-conditions-daughter-Wagga-Wagga-NSW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:47:00+00:00

The horrifying conditions were laid out in a list that the 16-year-old girl had to follow while living at a house in Wagga Wagga, in the Riverina region, in NSW.

## Queensland mum confronted by brutal note on windscreen after she parked at Proserpine Hospital while rushing her injured son to emergency
 - [https://www.dailymail.co.uk/news/article-12414929/Queensland-mum-confronted-brutal-note-windscreen-parked-Proserpine-Hospital-rushing-injured-son-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414929/Queensland-mum-confronted-brutal-note-windscreen-parked-Proserpine-Hospital-rushing-injured-son-emergency.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:40:29+00:00

A woman was left shocked after she found a crude note that called her a b***h placed on the windshield of her car when she had just rushed her injured son to the hospital.

## Why Australian dollar is expected to plunge within a month
 - [https://www.dailymail.co.uk/news/article-12415205/Australian-dollar-expected-plunge-against-dollar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415205/Australian-dollar-expected-plunge-against-dollar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:37:44+00:00

Westpac senior currency strategist Sean Callow said the Australian dollar would hit 62 US cents 'over the next month'. He made the call amid a prediction the currency will hit 40 US cents.

## Anthony Albanese sets date for government's Help to Buy scheme for taxpayers to fund up to 40 per cent of a new home for low and middle-income families
 - [https://www.dailymail.co.uk/news/article-12415341/Anthony-Albanese-sets-date-governments-Help-Buy-scheme-taxpayers-fund-40-cent-new-home-low-middle-income-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415341/Anthony-Albanese-sets-date-governments-Help-Buy-scheme-taxpayers-fund-40-cent-new-home-low-middle-income-families.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:34:31+00:00

A national scheme to help up to 40,000 families buy a home will start in 2024. The Help to Buy scheme start date was unveiled at the opening of Labor's national conference in Brisbane on Thursday.

## Secretary of State Antony Blinken spoke by phone with jailed Marine Paul Whelan in Russia, telling him to 'keep the faith'
 - [https://www.dailymail.co.uk/news/article-12415311/Antony-Blinken-Paul-Whelan-phone-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415311/Antony-Blinken-Paul-Whelan-phone-call.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:28:22+00:00

Paul Whelan, a U.S. Marine currently being held unjustly in Russia , spoke by phone with Secretary of State Antony Blinken, though it appears no progress has been made on freeing him.

## Hurricane Hilary updates: Tropical storm could bring strong winds to Southern California coast Sunday morning
 - [https://www.dailymail.co.uk/news/article-12415245/Hurricane-Hilary-updates-Tropical-storm-bring-strong-winds-Southern-California-coast-Sunday-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415245/Hurricane-Hilary-updates-Tropical-storm-bring-strong-winds-Southern-California-coast-Sunday-morning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:26:57+00:00

A rare hurricane is set to hit Southern California as early as Sunday morning, according to forecasters. Only two other storms have hit California in the last century.

## Jeff Bezos and fiancee Lauren Sanchez are spotted hanging out with Katy Perry, Orlando Bloom and Usher in Croatia
 - [https://www.dailymail.co.uk/news/article-12415151/Jeff-Bezos-Lauren-Sanchez-Katy-Perry-Orlando-Bloom-Usher-Koru-Dubrovnik-Croatia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415151/Jeff-Bezos-Lauren-Sanchez-Katy-Perry-Orlando-Bloom-Usher-Koru-Dubrovnik-Croatia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:25:54+00:00

The Amazon founder and his fiancee were spotted in Dubrovnik on Wednesday evening with Katy Perry, Orlando Bloom, Usher and influencer Derek Blasberg. The group strolled the historic main street.

## Aussie bloke comes forward to claim $30million OzLotto prize and reveals big plan for money: 'I can't believe it!'
 - [https://www.dailymail.co.uk/news/article-12415423/Aussie-bloke-comes-forward-claim-30million-OzLotto-prize-reveals-big-plan-money-believe-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415423/Aussie-bloke-comes-forward-claim-30million-OzLotto-prize-reveals-big-plan-money-believe-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T02:17:36+00:00

A Tasmanian man has been left speechless by the revelation he's now $30 million from this week's Oz Lotto draw.

## Origin records $1billion profit after millions of Aussies were hit with higher power bills
 - [https://www.dailymail.co.uk/news/article-12415373/Origin-records-1billion-profit-millions-Aussies-hit-higher-power-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415373/Origin-records-1billion-profit-millions-Aussies-hit-higher-power-bills.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:58:22+00:00

Origin Energy has reported a net profit of $1.06 billion for FY23 as one of the largest suppliers to the east coast domestic gas market.

## Anthony Albanese accuses Liberals of having a 'pathological problem' with saying 'Yes' in desperate bid to kickstart stalled Voice to Parliament push at Labor's national conference
 - [https://www.dailymail.co.uk/news/article-12415155/Anthony-Albanese-accuses-Liberals-having-pathological-problem-saying-Yes-desperate-bid-kickstart-stalled-Voice-Parliament-push-Labors-national-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415155/Anthony-Albanese-accuses-Liberals-having-pathological-problem-saying-Yes-desperate-bid-kickstart-stalled-Voice-Parliament-push-Labors-national-conference.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:44:51+00:00

Prime Minister Anthony Albanese kicked off the national conference with a call to arms ahead of the Voice to Parliament referendum and a scathing takedown of the Liberal party.

## Hillsong founder Brian Houston is found not guilty of concealing his father's sexual abuse of a child
 - [https://www.dailymail.co.uk/news/article-12415323/Hillsong-Brian-Houston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415323/Hillsong-Brian-Houston.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:44:22+00:00

Brian Houston not guilty of covering up pedo father's abuse

## Tinker Air Force Base deaths: 17 people dead in 2023, military refuses to reveal causes
 - [https://www.dailymail.co.uk/news/article-12415005/Tinker-Air-Force-Base-deaths-causes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415005/Tinker-Air-Force-Base-deaths-causes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:42:39+00:00

An Air Force base in Oklahoma is tight-lipped after 17 people have died on the base since the beginning of 2023. Officials for the Air Force and base have refused to reveal causes of deaths.

## Texas dad finds his 11-year-old daughter Maria Gonzalez strangled to death underneath her bed after she was sexually assaulted
 - [https://www.dailymail.co.uk/news/article-12415007/Texas-dad-Maria-Gonzalez-daughter-murder-sexual-assault-bed-suspects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415007/Texas-dad-Maria-Gonzalez-daughter-murder-sexual-assault-bed-suspects.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:29:26+00:00

A father found his 11-year-old daughter strangled to death under a bed in their Texas home on Saturday - investigators determined she had also been sexually assaulted.

## Gloomy petrol price forecast: Warning fuel will remain above $2 a litre for weeks in added blow to Australian drivers
 - [https://www.dailymail.co.uk/news/article-12414933/When-fuel-cheaper-Analysts-warn-fuel-prices-high-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414933/When-fuel-cheaper-Analysts-warn-fuel-prices-high-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:20:18+00:00

Petrol prices around Australia have skyrocketed to the highest point so far this year and analysts warn relief won't be coming for weeks.

## CHRISTOPHER STEVENS: Crispy Pancakes and Angel Delight make a tasty TV supper
 - [https://www.dailymail.co.uk/tvshowbiz/article-12415069/CHRISTOPHER-STEVENS-Crispy-Pancakes-Angel-Delight-make-tasty-TV-supper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12415069/CHRISTOPHER-STEVENS-Crispy-Pancakes-Angel-Delight-make-tasty-TV-supper.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T01:11:03+00:00

CHRISTOPHER STEVENS: The 1973 advert that launched Findus Crispy Pancakes was a heartbreaking mini epic, a novel crammed into 30 seconds.

## Queen's 'stinging' remark about Kate Middleton's holiday
 - [https://www.dailymail.co.uk/femail/article-11808441/Queens-stinging-remark-Kate-Middletons-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11808441/Queens-stinging-remark-Kate-Middletons-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:55:59+00:00

Before she settled into the Royal Family, the Princess of Wales had often been was often spotted jetting off on luxurious holidays. And it was not a habit that the late Queen approved of.

## Pregnant porn star, 34, used an empty pram to steal from supermarkets during shoplifting spree to fund her cocaine addiction - and swiped £2,500 ring from jewellery store after switching it with a £30 fake
 - [https://www.dailymail.co.uk/news/article-12415173/Pregnant-porn-star-pram-shoplifting-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415173/Pregnant-porn-star-pram-shoplifting-spree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:51:06+00:00

Roma Lawson, 34, targeted various stores over a five-week period beginning in April, when she swiped items from Aldi's chiller aisle. She later raided Sainsbury's and Tesco.

## Britney Spears and Sam Asghari SPLIT! Singer and actor husband go their separate ways after one year of marriage amid claims he 'confronted her in nuclear argument over cheating allegations'
 - [https://www.dailymail.co.uk/tvshowbiz/article-12414529/Britney-Spears-Sam-Asghari-SPLIT-Singer-actor-separate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-12414529/Britney-Spears-Sam-Asghari-SPLIT-Singer-actor-separate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:50:07+00:00

Britney Spears and Sam Asghari have split after 14 months of marriage - amid claims he confronted her over cheating allegations.

## Melania Trump feels Donald's latest indictment is 'another problem for her husband and not for her' and will continue her private lifestyle in NYC while his legal problems mount
 - [https://www.dailymail.co.uk/news/article-12414995/Melania-Trump-feels-husbands-latest-indictment-problem-Donald-not-continue-private-lifestyle-NYC-legal-problems-mount.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414995/Melania-Trump-feels-husbands-latest-indictment-problem-Donald-not-continue-private-lifestyle-NYC-legal-problems-mount.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:44:18+00:00

Melania Trump believes former President Donald Trump's fourth indictment is 'another problem for her husband' and 'not for her,' as she's kept a low-profile in New York City amid the ex-president's legal woes.

## Electricity rebate: $250 Power Saving Bonus available to Victorians expires in two weeks
 - [https://www.dailymail.co.uk/news/article-12414991/Electricity-rebate-250-Power-Saving-Bonus-available-Victorians-expires-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414991/Electricity-rebate-250-Power-Saving-Bonus-available-Victorians-expires-two-weeks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:37:20+00:00

Time is running for millions of eligible Aussies in one state to claim a $250 government rebate towards power bills.

## Fight breaks out inside San Bernardino Target as four men are seen attacking one victim in shocking video
 - [https://www.dailymail.co.uk/news/article-12415041/Target-fight-video-California-brawl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415041/Target-fight-video-California-brawl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:30:51+00:00

Video taken inside a Southern California Target shows the moment a violent brawl involving nearly half a dozen men broke out while families were shopping.

## Former police constable appears in court accused of passing sensitive information to organised crime group
 - [https://www.dailymail.co.uk/news/article-12415097/Former-police-constable-appears-court-accused-passing-sensitive-information-organised-crime-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415097/Former-police-constable-appears-court-accused-passing-sensitive-information-organised-crime-group.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:25:48+00:00

Adam Davies, 28, is facing eight counts of misconduct in public office over claims he accessed information on computer systems without a policing purpose and provided details to criminals.

## US airman, 18, jailed for raping a 12-year-old autistic girl he met on Snapchat while stationed in the UK
 - [https://www.dailymail.co.uk/news/article-12415087/US-airman-18-jailed-raping-12-year-old-autistic-girl-met-Snapchat-stationed-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415087/US-airman-18-jailed-raping-12-year-old-autistic-girl-met-Snapchat-stationed-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:20:39+00:00

US airman Dennis Rocha, 18, has been jailed after he drove 140 miles from his base at RAF Mildenhall in Suffolk to meet up with the 12-year-old autistic girl he met on Snapchat while stationed in the UK.

## 9/11 terrorists - including Khalid Sheikh Mohammed- may avoid death penalty as a result of plea deals
 - [https://www.dailymail.co.uk/news/article-12414749/9-11-terrorists-including-Khalid-Sheikh-Mohammed-avoid-death-penalty-result-plea-deals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12414749/9-11-terrorists-including-Khalid-Sheikh-Mohammed-avoid-death-penalty-result-plea-deals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:18:38+00:00

The suspected architects behind the 9/11 terror attacks may never face the death penalty under new plea agreements being considered.

## Tech behemoths must take action on social media scams now, writes TSB chief executive ROBIN BULLOCH
 - [https://www.dailymail.co.uk/debate/article-12414977/Tech-behemoths-action-social-media-scams-writes-TSB-chief-executive-ROBIN-BULLOCH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-12414977/Tech-behemoths-action-social-media-scams-writes-TSB-chief-executive-ROBIN-BULLOCH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:16:53+00:00

TSB chief executive Robin Bulloch says: 'We took a bold decision at TSB: we promised to refund every innocent victim of fraud.  We are tackling the symptoms, not the causes, of fraud'

## Former justice secretary Sir Robert Buckland calls for a public inquiry into the case of Andrew Malkinson who spent 17 years in jail for a rape he did not commit
 - [https://www.dailymail.co.uk/news/article-12415123/Former-justice-secretary-Sir-Robert-Buckland-calls-public-inquiry-case-Andrew-Malkinson-spent-17-years-jail-rape-did-not-commit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415123/Former-justice-secretary-Sir-Robert-Buckland-calls-public-inquiry-case-Andrew-Malkinson-spent-17-years-jail-rape-did-not-commit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:04:20+00:00

Sir Robert Buckland said the justice system could 'not command confidence' if it 'indulges or is complicit in miscarriages of justice' such as in the case of Andrew Malkinson

## Saudi Arabia's Crown Prince is set to visit the UK this autumn in his first trip since the murder of journalist Jamal Khashoggi
 - [https://www.dailymail.co.uk/news/article-12415115/Saudi-Arabias-Crown-Prince-set-visit-UK-autumn-trip-murder-journalist-Jamal-Khashoggi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12415115/Saudi-Arabias-Crown-Prince-set-visit-UK-autumn-trip-murder-journalist-Jamal-Khashoggi.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-08-17T00:01:43+00:00

The diplomatic gesture will seek to repair relations after MBS was frozen out by the West following the ordered assassination of Khashoggi on 2 October 2018.

