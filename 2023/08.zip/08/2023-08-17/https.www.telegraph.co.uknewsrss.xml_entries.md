# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## France stops fewer Channel migrants – despite £480m funding from UK
 - [https://www.telegraph.co.uk/news/2023/08/17/france-stops-fewer-channel-migrants-480m-funding-from-uk/](https://www.telegraph.co.uk/news/2023/08/17/france-stops-fewer-channel-migrants-480m-funding-from-uk/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T21:10:54+00:00



## Twice-cancelled Graham Linehan performs outside Scottish Parliament
 - [https://www.telegraph.co.uk/news/2023/08/17/graham-linehan-edinburgh-fringe-scottish-parliament-comedy/](https://www.telegraph.co.uk/news/2023/08/17/graham-linehan-edinburgh-fringe-scottish-parliament-comedy/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T20:36:39+00:00



## Thursday evening news briefing: Prince of Wales under pressure to interrupt holidays and attend Women’s World Cup final
 - [https://www.telegraph.co.uk/news/2023/08/17/thursday-evening-news-briefing-prince-of-wales-under-pressu/](https://www.telegraph.co.uk/news/2023/08/17/thursday-evening-news-briefing-prince-of-wales-under-pressu/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T16:35:28+00:00



## Ukraine: The Latest - The forgotten war that shaped Putin's mind
 - [https://www.telegraph.co.uk/news/2023/08/17/the-forgotten-war-that-shaped-putins-mind/](https://www.telegraph.co.uk/news/2023/08/17/the-forgotten-war-that-shaped-putins-mind/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T15:58:53+00:00



## Revealed: British Museum curator of 30 years accused of stealing artefacts
 - [https://www.telegraph.co.uk/news/2023/08/17/british-museum-stolen-artefacts-peter-higgs-curator/](https://www.telegraph.co.uk/news/2023/08/17/british-museum-stolen-artefacts-peter-higgs-curator/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T12:56:53+00:00



## British Museum was told three years ago that staff member was selling stolen artefacts on eBay
 - [https://www.telegraph.co.uk/news/2023/08/17/british-museum-theft-warned-ebay-gold-antiquities-police/](https://www.telegraph.co.uk/news/2023/08/17/british-museum-theft-warned-ebay-gold-antiquities-police/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T11:35:46+00:00



## Sir Michael Parkinson dies aged 88
 - [https://www.telegraph.co.uk/news/2023/08/17/sir-michael-parkinson-broadcaster-dead-88/](https://www.telegraph.co.uk/news/2023/08/17/sir-michael-parkinson-broadcaster-dead-88/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T09:38:22+00:00



## A-level results: More pupils awarded top grades than in any pre-pandemic year
 - [https://www.telegraph.co.uk/news/2023/08/17/a-level-exam-results-day-2023-grades-university-clearing/](https://www.telegraph.co.uk/news/2023/08/17/a-level-exam-results-day-2023-grades-university-clearing/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T08:30:38+00:00



## A-level results day 2023: What time is it, what to expect and how to appeal your results?
 - [https://www.telegraph.co.uk/news/2023/08/17/a-level-results-2023-when-time-university-clearing-appeal-boundaries-ucas-hub/](https://www.telegraph.co.uk/news/2023/08/17/a-level-results-2023-when-time-university-clearing-appeal-boundaries-ucas-hub/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T06:45:54+00:00



## Ucas Clearing 2023: How to get a last-minute university place on A-level results day
 - [https://www.telegraph.co.uk/news/2023/08/17/how-ucas-clearing-2023-works-university-placements-grades-rejection/](https://www.telegraph.co.uk/news/2023/08/17/how-ucas-clearing-2023-works-university-placements-grades-rejection/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-17T06:44:54+00:00



