# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Alaksandr Łukaszenka mówi o agresji ze strony Polski: Odpowiemy natychmiast
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/lukaszenka-mowi-o-agresji-ze-strony-polski-odpowiemy-natychmiast-wszystkim/](https://www.polsatnews.pl/wiadomosc/2023-08-17/lukaszenka-mowi-o-agresji-ze-strony-polski-odpowiemy-natychmiast-wszystkim/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T20:01:00+00:00

- Może pojawić się tylko jedno zagrożenie - agresja przeciwko naszemu państwu. Jeśli agresja na nasz kraj zacznie się od Polski, Litwy, Łotwy, odpowiemy natychmiast, wszystkim, co będziemy mieć - stwierdził białoruski dyktator Alaksandr Łukaszenka, pytany o możliwość użycia broni jądrowej przez Białoruś. Ocenił również, że Władimir Putin zrealizował wszystkie cele specjalnej operacji wojskowej.

## Malezja: Katastrofa prywatnego samolotu. Nie żyje 10 osób
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/malezja-katastrofa-prywatnego-samolotu-nie-zyje-10-osob/](https://www.polsatnews.pl/wiadomosc/2023-08-17/malezja-katastrofa-prywatnego-samolotu-nie-zyje-10-osob/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T19:39:00+00:00

Prywatny samolot rozbił się na autostradzie w Malezji. Zginęło co najmniej 10 osób. Wstępne informacje wskazują, że samolot stracił kontakt z wieżą kontroli ruchu lotniczego.

## Holandia: Zakuty w kajdanki mężczyzna uciekł lokalnej policji
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/holandia-zakuty-w-kajdanki-mezczyzna-uciekl-lokalnej-policji/](https://www.polsatnews.pl/wiadomosc/2023-08-17/holandia-zakuty-w-kajdanki-mezczyzna-uciekl-lokalnej-policji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T18:47:00+00:00

Zakuty w kajdanki mężczyzna uciekł policjantom z holenderskiego miasta Helmond. Podszedł do kilku osób na ulicy i prosił o pomoc w zdjęciu elementów krępujących ruchy. Tłumaczył, że to gadżet erotyczny.

## Seria kradzieży w British Museum. Złodziejem mógł być kustosz
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/seria-kradziezy-w-british-museum-zlodziejem-moze-byc-jego-kurator/](https://www.polsatnews.pl/wiadomosc/2023-08-17/seria-kradziezy-w-british-museum-zlodziejem-moze-byc-jego-kurator/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T18:46:00+00:00

British Museum przyznało, że w ostatnim czasie zaginęło kilka eksponatów. Placówka wprowadziła środki nadzwyczajne i zaczęła współpracować z londyńską policją. Okazało się, że sprawcą kradzieży może być - już były - pracownik muzeum.

## Australia: W domu znaleziono materiały radioaktywne. Mieszkańcy trafili do szpitala
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/australia-w-domu-znaleziono-material-radioaktywny-mieszkancy-trafili-do-szpitala/](https://www.polsatnews.pl/wiadomosc/2023-08-17/australia-w-domu-znaleziono-material-radioaktywny-mieszkancy-trafili-do-szpitala/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T18:29:00+00:00

W domu w Arncliffe w południowej części Sydney znaleziono materiały radioaktywne. Trzy osoby zostały przewiezione do szpitala.

## Rosja. Dotarli do tajnych dokumentów. "Moskwa poczyniła postępy w realizacji celu"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/rosja-dotarli-do-tajnych-dokumentow-moskwa-poczynila-postepy-w-realizacji-celu/](https://www.polsatnews.pl/wiadomosc/2023-08-17/rosja-dotarli-do-tajnych-dokumentow-moskwa-poczynila-postepy-w-realizacji-celu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T18:08:00+00:00

Fabryka irańskich dornów Shahed-136, która powstaje na terenie Federacji Rosyjskiej, zmaga się z opóźnieniami - podaje w czwartek The Washington Post. Według dokumentów, do których dotarli dziennikarze, Rosja zmierza ulepszyć irańskie projekty. Moskwa poczyniła postępy w realizacji celu - przekazał WP.

## Szwecja: Podwyższono poziom zagrożenie terrorystycznego. Jest najgorzej od lat
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/szwecja-podwyzszono-poziom-zagrozenie-terrorystycznego-jest-najgorzej-od-lat/](https://www.polsatnews.pl/wiadomosc/2023-08-17/szwecja-podwyzszono-poziom-zagrozenie-terrorystycznego-jest-najgorzej-od-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T17:06:00+00:00

Szwecja podniosła poziom zagrożenia terrorystycznego do niemal najwyższego z możliwych - czwartego w pięciostopniowej skali. Władze obawiają się, że ich państwo stało się priorytetowym celem terrorystów, ponieważ uznają oni ten kraj za islamofobiczny.

## Sztokholm stawia na maszyny. W lodziarniach zaczynają pracować roboty
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/sztokholm-stawia-na-maszyny-w-lodziarniach-zaczynaja-pracowac-roboty/](https://www.polsatnews.pl/wiadomosc/2023-08-17/sztokholm-stawia-na-maszyny-w-lodziarniach-zaczynaja-pracowac-roboty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T17:03:00+00:00

Szwedzki startup przeznaczył ponad 2 miliony dolarów na rozwój zrobotyzowanych lodziarni. Inwestycja ma na celu przyzwyczaić ludzi do obecności maszyn na każdym kroku. Projekt BonBot stawia na wyższą jakość świadczonych usług oraz na podwyższenie zysku dzięki ograniczeniu personelu. Na terenie Szwecji istnieją trzy podobne punkty sprzedaży.

## Hiszpania. Niepokojące ostrzeżenia na ulicach. Wymierzone w turystów
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/hiszpania-niepokojace-tabliczki-na-ulicach-wymierzone-w-turystow/](https://www.polsatnews.pl/wiadomosc/2023-08-17/hiszpania-niepokojace-tabliczki-na-ulicach-wymierzone-w-turystow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T16:48:00+00:00

W wodzie znajdują się niebezpieczne meduzy, na plażę trzeba iść trzy godziny, a jak już tam trafisz, to i tak będzie zamknięta - to tylko niektóre z fałszywych ostrzeżeń, które stworzyli Katalończycy. Chcą dzięki nim odstraszyć turystów - szczególnie z Wielkiej Brytanii.

## Francja: 24-latek skoczył ze spadochronem z wieży Eiffla. Został aresztowany
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/francja-24-latek-skoczyl-ze-spadochronem-z-wiezy-eiffla-zostal-aresztowany/](https://www.polsatnews.pl/wiadomosc/2023-08-17/francja-24-latek-skoczyl-ze-spadochronem-z-wiezy-eiffla-zostal-aresztowany/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T15:41:00+00:00

24-letni mężczyzna został aresztowany po skoku ze spadochronem z wieży Eiffla. Skoczek wylądował na pobliskim stadionie. Jak podały media, przed policją próbował ukryć się w krzakach.

## Wojna w Ukrainie. Anton Heraszczenko: Rosja jest przygotowana na dużą i długą wojnę
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/wojna-w-ukrainie-anton-heraszczenko-rosja-jest-przygotowana-na-duza-i-dluga-wojne/](https://www.polsatnews.pl/wiadomosc/2023-08-17/wojna-w-ukrainie-anton-heraszczenko-rosja-jest-przygotowana-na-duza-i-dluga-wojne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T14:58:00+00:00

45 tys. mieszkańców Moskwy bierze obecnie udział w specjalnej operacji wojskowej - przekazał mer stolicy Rosji Siergiej Sobianin. Wypowiedź rosyjskiego polityka skomentował doradca szefa MSW Ukrainy Anton Heraszczenko. Sądząc po działaniach reżimu Putina, Rosja jest przygotowana na dużą i długą wojnę - podkreślił.

## USA: 13-latek spadł z klifu w Wielkim Kanionie. Chciał zrobić imponujące zdjęcie
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/usa-13-latek-spadl-z-klifu-w-wielkim-kanionie-chcial-zrobic-imponujace-zdjecie/](https://www.polsatnews.pl/wiadomosc/2023-08-17/usa-13-latek-spadl-z-klifu-w-wielkim-kanionie-chcial-zrobic-imponujace-zdjecie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T14:40:00+00:00

Nastolatek chciał zaimponować swoim rówieśnikom zdjęciem zrobionym na samym skraju przepaści. Spadł z ponad 30 metrów. Chłopiec przeżył, ale doznał licznych urazów. - Mamy szczęście, że możemy zabrać syna do domu samochodem, a nie w trumnie - powiedzieli rodzice nastolatka.

## Wielka Brytania: Kobieta kupiła za grosze pluszaka. Jest wart ponad 31 tysięcy
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/wielka-brytania-kobieta-kupila-za-grosze-misia-ktory-jest-wart-ponad-31-tysiecy/](https://www.polsatnews.pl/wiadomosc/2023-08-17/wielka-brytania-kobieta-kupila-za-grosze-misia-ktory-jest-wart-ponad-31-tysiecy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T14:31:00+00:00

61-letnia Brytyjka Jeannette Davies za pluszaka na pchlim targu zapłaciła 130 funtów, ale inwestycja zwróciła jej się wielokrotnie. Kupując zabawkę, uznała, że może mieć wartość kolekcjonerską i miała racje.

## Rosjanie zniszczyli ukraiński pociąg z amunicją. Pokazali nagranie
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/rosjanie-zniszczyli-ukrainski-pociag-z-amunicja-pokazali-nagranie/](https://www.polsatnews.pl/wiadomosc/2023-08-17/rosjanie-zniszczyli-ukrainski-pociag-z-amunicja-pokazali-nagranie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T12:54:00+00:00

Rosyjskim żołnierzom udało się zniszczyć ukraiński pociąg na froncie. Transport miał przewozić w rejon walk amunicję. MON Rosji opublikował nagranie z kamery z drona, na którym widać potężną eksplozję.

## Śpiewał i grał na gitarze w trakcie operacji. Lekarze usuwali mu guza mózgu
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/spiewal-i-gral-na-gitarze-w-trakcie-operacji-lekarze-usuwali-mu-guza-mozgu/](https://www.polsatnews.pl/wiadomosc/2023-08-17/spiewal-i-gral-na-gitarze-w-trakcie-operacji-lekarze-usuwali-mu-guza-mozgu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T11:40:00+00:00

Takich obrazków na sali operacyjnej nie widuje się często. 55-letni Mauricio Alkinder Stemberg śpiewał i grał na gitarze. W tym samym czasie chirurdzy usuwali mu guza mózgu.

## Kadyrow zmienia front walki. Nie chce "innowacyjnych wesel"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/kadyrow-zmienia-front-walki-nie-chce-innowacyjnych-wesel/](https://www.polsatnews.pl/wiadomosc/2023-08-17/kadyrow-zmienia-front-walki-nie-chce-innowacyjnych-wesel/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T11:01:00+00:00

Problem wprowadzania weselnych innowacji jest w naszym społeczeństwie palący - twierdzą przedstawiciele czeczeńskich władz. Ramzan Kadyrow wypowiedział walkę ze zbyt mało tradycyjnymi ceremoniami w regionie.

## Białoruski śmigłowiec przy granicy Polski. W ramach ćwiczeń zrzucił skoczków spadochronowych
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/bialoruski-smiglowiec-przy-granicy-polski-w-ramach-cwiczen-zrzucil-skoczkow-spadochronowych/](https://www.polsatnews.pl/wiadomosc/2023-08-17/bialoruski-smiglowiec-przy-granicy-polski-w-ramach-cwiczen-zrzucil-skoczkow-spadochronowych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T10:04:00+00:00

Białoruski śmigłowiec zrzucił skoczków spadochronowych tuż przy polskiej granicy. Białorusini przeprowadzili ćwiczenie desantu na poligonie w pobliżu Brześcia, który znajduje się w odległości 3-4 kilometrów od Bugu. Rzeka w tym miejscu oddziela terytorium Polski i Białorusi.

## Liban: Cały kraj odcięty od prądu. Powodem długi u operatora
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/liban-caly-kraj-odciety-od-pradu-powodem-dlugi-u-operatora/](https://www.polsatnews.pl/wiadomosc/2023-08-17/liban-caly-kraj-odciety-od-pradu-powodem-dlugi-u-operatora/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T10:02:00+00:00

Liban pogrążył się w ciemnościach od środowego wieczoru, kiedy firma Prime South zdecydowała o wstrzymaniu pracy dwóch elektrowni Deir-Ammar i Al-Zahan. Operator odciął dostawy ze względu na rosnący dług i brak spłat zaległych rachunków.

## Rosja: Ogromny pożar w Wołgogradzie. Ogień w hucie "Czerwony Październik"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/rosja-ogromny-pozar-w-wolgogradzie-ogien-w-hucie-czerwony-pazdziernik/](https://www.polsatnews.pl/wiadomosc/2023-08-17/rosja-ogromny-pozar-w-wolgogradzie-ogien-w-hucie-czerwony-pazdziernik/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T08:41:00+00:00

Rozlany olej z transformatora miał być, według oficjalnych komunikatów, powodem ogromnego pożaru na terenie zakładu Czerwony Październik w Wołgogradzie. Według służb prasowych Głównej Dyrekcji Ministerstwa ds. Sytuacji Nadzwyczajnych, ogień objął powierzchnię 50 metrów kwadratowych.

## Incydent na turnieju tenisowym. Zawodnik chciał wyprosić kobietę, bo "udawała pszczołę"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/incydent-na-turnieju-tenisowym-zawodnik-chcial-wyprosic-kobiete-bo-udawala-pszczole/](https://www.polsatnews.pl/wiadomosc/2023-08-17/incydent-na-turnieju-tenisowym-zawodnik-chcial-wyprosic-kobiete-bo-udawala-pszczole/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T07:29:00+00:00

- Słyszę bzyczenie przed serwisem. To jest ok? - pytał sędziego tenisista Stefanos Tsitsipas, który mierzył się z Benem Sheltonem w turnieju ATP w Cincinnati. Zawodnik rozpraszany przez jedną z kobiet siedzących na trybunach domagał się usunięcia jej z widowni.

## Finlandia: Powstają ogromne magazyny sprzętu ochronnego. Przygotowania na zagrożenie nuklearne
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/finlandia-powstaja-ogromne-magazyny-sprzetu-ochronnego-przygotowania-do-zagrozenia-nuklearnego/](https://www.polsatnews.pl/wiadomosc/2023-08-17/finlandia-powstaja-ogromne-magazyny-sprzetu-ochronnego-przygotowania-do-zagrozenia-nuklearnego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T07:04:00+00:00

- Finlandia otrzymała od Komisji Europejskiej znaczne dofinansowanie w wysokości 242 milionów euro na utworzenie strategicznej rezerwy CBRJ - mówi Tarja Rantal. Przedstawicielka Ministerstwa Spraw Wewnętrznych Finlandii zapowiedziała utworzenie ogromnych składów sprzętu ochronnego na wypadek konfliktu nuklearnego, chemicznego lub biologicznego.

## Grupa Wagnera zarejestrowana na Białorusi. To "centrum edukacyjne"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/grupa-wagnera-zarejestrowana-na-bialorusi-to-centrum-edukacyjne/](https://www.polsatnews.pl/wiadomosc/2023-08-17/grupa-wagnera-zarejestrowana-na-bialorusi-to-centrum-edukacyjne/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T06:18:00+00:00

Grupa Wagnera została zarejestrowana na Białorusi jako organizacja edukacyjna - informuje kanał Telegram Rotonda. W sieci pojawiło się potwierdzenie rejestracji udokumentowane przez Ministerstwo Sprawiedliwości na Białorusi.

## Ukraina. Jurij Ihnat: Tej jesieni i zimy nie będziemy w stanie ochronić Ukrainy samolotami F-16
 - [https://www.polsatnews.pl/wiadomosc/2023-08-17/ukraina-jurij-ihnat-tej-jesieni-i-zimy-nie-bedziemy-w-stanie-ochronic-ukrainy-samolotami-f-16/](https://www.polsatnews.pl/wiadomosc/2023-08-17/ukraina-jurij-ihnat-tej-jesieni-i-zimy-nie-bedziemy-w-stanie-ochronic-ukrainy-samolotami-f-16/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-17T05:24:00+00:00

Już teraz jest oczywiste, że tej jesieni i zimy nie będziemy w stanie ochronić Ukrainy samolotami F-16 - powiedział rzecznik sił powietrznych Ukrainy Jurij Ihnat, cytowany przez Ukrainską Prawdę. Jednocześnie przyznał, że sprawa szkolenia ukraińskich pilotów ruszyła z miejsca.

