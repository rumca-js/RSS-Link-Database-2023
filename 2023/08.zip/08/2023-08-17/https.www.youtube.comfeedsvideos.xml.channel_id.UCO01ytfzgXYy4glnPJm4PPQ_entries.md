# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Profanity in Music
 - [https://www.youtube.com/watch?v=TdNGO8B3qrM](https://www.youtube.com/watch?v=TdNGO8B3qrM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T23:30:05+00:00



## Crazy Suicide Rates
 - [https://www.youtube.com/watch?v=T-7Zf9GAjoc](https://www.youtube.com/watch?v=T-7Zf9GAjoc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T22:30:06+00:00



## After Being Mugged, This Family Justified Their Mugger
 - [https://www.youtube.com/watch?v=wpjIYACl3s0](https://www.youtube.com/watch?v=wpjIYACl3s0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T22:00:36+00:00

Text "WALSH" to 989898, or go to https://bit.ly/3LjDxuA, for your no-cost, no-obligation, FREE information kit.

An Asian family was mugged in NYC on the subway, but they justified their attacker because of the attackers lack of privilege. 

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1207 - https://bit.ly/3qu3L7l 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Debate Over Taking KIDS To Adult Areas Goes VIRAL
 - [https://www.youtube.com/watch?v=N1NpH5IjduQ](https://www.youtube.com/watch?v=N1NpH5IjduQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T17:00:25+00:00

This TikTok went viral for daring to tell parents not to take their kids out to public areas so that way she could be crude if she wants to.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1206 - https://bit.ly/45tdLMT 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Would I Change My Name To 'Subway' For FREE Sandwiches?
 - [https://www.youtube.com/watch?v=OEDXSVshJCo](https://www.youtube.com/watch?v=OEDXSVshJCo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T14:00:26+00:00

10,000 people are willing to change their name to "Subway" for the chance to win free sandwiches. Would you do this?

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1206 - https://bit.ly/45tdLMT 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Oliver Anthony's Fame
 - [https://www.youtube.com/watch?v=vebA4pwe0lc](https://www.youtube.com/watch?v=vebA4pwe0lc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-17T00:00:31+00:00



