# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## The Best Cheap Smartwatches You Can Buy
 - [https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601](https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T23:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VkiZrG4h--/c_fit,fl_progressive,q_80,w_636/787961c961f493f8868576d3a6b1969f.jpg" /><p>Technology has advanced to the point where most people can afford to upgrade their “dumb” watches to a decent device that can measure their sleep quality and tell them how many steps in a given day, all for relatively cheap. If you’re looking for a good deal on a smartwatch, here are some of the best current,…</p><p><a href="https://lifehacker.com/5-smartwatches-you-can-buy-for-under-200-1849905601">Read more...</a></p>

## How to Beat a Drug Test
 - [https://lifehacker.com/how-to-beat-a-drug-test-1829993785](https://lifehacker.com/how-to-beat-a-drug-test-1829993785)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T22:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--fgAZd-S_--/c_fit,fl_progressive,q_80,w_636/ccfbd1a88a0136407c9342eabff7e6b0.jpg" /><p>You or I would never do drugs, or attempt to cheat on something as important as a drug test. But perhaps you have a “friend” who is curious about how the tests work. Here’s what your “friend” needs to know.<br /></p><p><a href="https://lifehacker.com/how-to-beat-a-drug-test-1829993785">Read more...</a></p>

## How the ‘Proust Effect’ Can Help You Study
 - [https://lifehacker.com/how-the-proust-effect-can-help-you-study-1850749025](https://lifehacker.com/how-the-proust-effect-can-help-you-study-1850749025)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--jRWGnBFr--/c_fit,fl_progressive,q_80,w_636/d6c88711ee25e35be9d4a805592c17e4.jpg" /><p>When you need to remember something important, it makes sense to look around for hacks and tricks to maximize your recall. And plenty of those are out there, but do they actually work? One popular tip involves chewing a certain flavor of gum or spraying an specific scent in the air while you study or work, then using…</p><p><a href="https://lifehacker.com/how-the-proust-effect-can-help-you-study-1850749025">Read more...</a></p>

## The Best Study Gadgets for Students
 - [https://lifehacker.com/the-best-study-gadgets-for-students-1850748745](https://lifehacker.com/the-best-study-gadgets-for-students-1850748745)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T21:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5CwnO6uQ--/c_fit,fl_progressive,q_80,w_636/81dc25cb3206f764a88bb396e72f6c2a.jpg" /><p>It’s back-to-school season, which used to mean loading up on fresh pencils and notebooks—more often now, though, it means loading up on new tech. (Although, you can still buy pencils and notebooks <a href="https://lifehacker.com/why-you-should-stop-bringing-your-laptop-to-class-1850441339" target="_blank">and probably<em> should</em></a>.) There are a ton of great devices out there right now to help you study and manage your academic…</p><p><a href="https://lifehacker.com/the-best-study-gadgets-for-students-1850748745">Read more...</a></p>

## This Is the Only 'Fast' Way to Ripen an Avocado
 - [https://lifehacker.com/this-is-the-only-fast-way-to-ripen-an-avocado-1849574036](https://lifehacker.com/this-is-the-only-fast-way-to-ripen-an-avocado-1849574036)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0QAShXAG--/c_fit,fl_progressive,q_80,w_636/a28a889ceba9bc255b686837aef94e5d.jpg" /><p>Avocados have a fan club filled with people who hate to love them. They taste great; they can be sliced, mashed, or blended; and the can be used to make everything from <a href="https://www.recipetineats.com/creamy-avocado-salad-dressing/" rel="noopener noreferrer" target="_blank">salad dressings</a> to <a href="https://www.foodnetwork.com/recipes/alton-brown/avocado-ice-cream-recipe-1945087" rel="noopener noreferrer" target="_blank">ice cream</a>. But they like to play coy. Perfectly ripe for seemingly mere minutes, avocados spend most of their time on the…</p><p><a href="https://lifehacker.com/this-is-the-only-fast-way-to-ripen-an-avocado-1849574036">Read more...</a></p>

## You Can Get a Lifetime of Curiosity Stream for $200
 - [https://lifehacker.com/you-can-get-a-lifetime-of-curiosity-stream-for-200-1850743424](https://lifehacker.com/you-can-get-a-lifetime-of-curiosity-stream-for-200-1850743424)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T21:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ApfmbfNt--/c_fit,fl_progressive,q_80,w_636/596456f85331e35b7a3391073434ab97.png" /><p> Curiosity Stream is an award-winning streaming service that has a huge library of documentaries on science, history, technology, nature, biographies, and true crime, and <a href="https://shop.lifehacker.com/sales/curiosity-stream-standard-plan-lifetime-subscription?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=curiosity-stream-standard-plan-lifetime-subscription&amp;utm_term=scsf-577026&amp;utm_content=a0x1P000005OtjEQAS&amp;scsonar=1">a lifetime subscription is on sale for $199.99 right now</a>.</p><p><a href="https://lifehacker.com/you-can-get-a-lifetime-of-curiosity-stream-for-200-1850743424">Read more...</a></p>

## What People are Getting Wrong This Week: The Maui Wildfires
 - [https://lifehacker.com/maui-wildfire-myths-debunked-1850749329](https://lifehacker.com/maui-wildfire-myths-debunked-1850749329)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5QUsBBGP--/c_fit,fl_progressive,q_80,w_636/c4aa975a64e07be5a9d4f13b53f98b1b.jpg" /><p>The Maui wildlife fires are the deadliest in the U.S. in over 100 years. The rising death toll is currently 111, with thousands still missing. While much of the nation is grieving and offering support for residents of the devastated town of Lahaina, some are responding by creating and spreading lies and conspiracy…</p><p><a href="https://lifehacker.com/maui-wildfire-myths-debunked-1850749329">Read more...</a></p>

## Snack Supper Rules; Girl Dinner Drools
 - [https://lifehacker.com/it-is-the-age-of-the-snack-supper-1843157528](https://lifehacker.com/it-is-the-age-of-the-snack-supper-1843157528)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Yu3QAAMu--/c_fit,fl_progressive,q_80,w_636/xpkxdqj8h8gzftoqz2cl.jpg" /><p>Every once in a while, I start to hate cooking. Or at least I start to hate cooking for myself.  This feeling peaked during height of the pandemic and social distancing; while everyone else was finding comfort in meditative brunoise-ing and reflective baking, I was drained by the time supper rolled around. It still…</p><p><a href="https://lifehacker.com/it-is-the-age-of-the-snack-supper-1843157528">Read more...</a></p>

## Your Concrete Project Needs Cement Paint
 - [https://lifehacker.com/your-concrete-project-needs-cement-paint-1850748105](https://lifehacker.com/your-concrete-project-needs-cement-paint-1850748105)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T20:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--4hAEwGNV--/c_fit,fl_progressive,q_80,w_636/211b56b788ba231106bb3732491e23fd.jpg" /><p>Concrete is amazing. All you have to do is look at <a href="https://news.mit.edu/2023/roman-concrete-durability-lime-casts-0106" rel="noopener noreferrer" target="_blank">ancient Roman ruins</a> to realize how durable, flexible, and strong concrete can be as a building material. This can lead to the occasional moment of mental dissonance, however, when your outdoor steps are crumbling into dust while the 2,000-year-old Pantheon in Rome…</p><p><a href="https://lifehacker.com/your-concrete-project-needs-cement-paint-1850748105">Read more...</a></p>

## The Easiest, Laziest Way to Build a Fire
 - [https://lifehacker.com/the-easiest-laziest-way-to-build-a-fire-1850748804](https://lifehacker.com/the-easiest-laziest-way-to-build-a-fire-1850748804)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T19:39:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Asa-6TLK--/c_fit,fl_progressive,q_80,w_636/72969c62840865e73f7a87102a4a0f2a.jpg" /><p>If you didn’t grow up camping, you may be surprised to find out that starting a campfire isn’t as easy as it looks in the cartoons. (My daughter recently tried rubbing two sticks together, earnestly believing this would start a fire. Spoiler: It doesn’t work like that). But if you’re hoping to quickly get a fire going…</p><p><a href="https://lifehacker.com/the-easiest-laziest-way-to-build-a-fire-1850748804">Read more...</a></p>

## The Best Sangria Comes From a French Press
 - [https://lifehacker.com/the-best-sangria-comes-from-a-french-press-1850748855](https://lifehacker.com/the-best-sangria-comes-from-a-french-press-1850748855)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T19:01:51+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VUDHkLbP--/c_fit,fl_progressive,q_80,w_636/4063cf404e0dec4158cf538621872854.jpg" /><p>Sangria is the perfect candidate for a simple summer wine cocktail. For those that love sipping on this sessionable, fruit-laced alcoholic beverage, not much is required besides chopping up ripe produce and adding wine. For others, there’s a real problem here. Floating fruit chunks crowding your wine. Luckily, there’s…</p><p><a href="https://lifehacker.com/the-best-sangria-comes-from-a-french-press-1850748855">Read more...</a></p>

## These Dehumidifiers Are Being Recalled for Fire Hazard
 - [https://lifehacker.com/these-dehumidifiers-are-being-recalled-for-fire-hazard-1850748405](https://lifehacker.com/these-dehumidifiers-are-being-recalled-for-fire-hazard-1850748405)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WowZCgVY--/c_fit,fl_progressive,q_80,w_636/5acc1b41f1fde8e73f224e4ee48a0f10.jpg" /><p><a href="https://www.cpsc.gov/Recalls/2023/Gree-Recalls-1-56-Million-Dehumidifiers-Due-to-Fire-and-Burn-Hazards-Reports-of-At-Least-23-Fires" rel="noopener noreferrer" target="_blank">Gree Electric Appliances is recalling 1.56 million dehumidifiers</a>—including 42 different models from 13 brand names sold by several popular retailers—after reports of at least 23 fires breaking out. Those brand names include Kenmore, GE, SoleusAir, Norpole, and Seabreeze.</p><p><a href="https://lifehacker.com/these-dehumidifiers-are-being-recalled-for-fire-hazard-1850748405">Read more...</a></p>

## The Real History of Labor Day
 - [https://lifehacker.com/the-real-history-of-labor-day-1847614981](https://lifehacker.com/the-real-history-of-labor-day-1847614981)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T18:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--H8LmRL9w--/c_fit,fl_progressive,q_80,w_636/cd0bf7001578ad79b82f6f07f3bdf292.jpg" /><p>You probably don’t have to work on the first Monday of September, but why? The name “Labor Day” suggests<em> </em>a holiday that’s all about American workers, but most of us just see it as an excuse for a three-day weekend, and to celebrate the end of summer. </p><p><a href="https://lifehacker.com/the-real-history-of-labor-day-1847614981">Read more...</a></p>

## Make This DIY Swamp Cooler
 - [https://lifehacker.com/make-this-diy-swamp-cooler-1850747672](https://lifehacker.com/make-this-diy-swamp-cooler-1850747672)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uokZ-v1_--/c_fit,fl_progressive,q_80,w_636/9efb05a83ccbf8c0571f8256bd77bcd3.jpg" /><p>If you find yourself experiencing an unexpected heatwave and your air conditioner goes down, keeping cool can be difficult. While nothing beats the cool blast of air supplied by a traditional AC unit, there’s a DIY approach that can help out. Making your own swamp cooler for emergency use is a simple project with just…</p><p><a href="https://lifehacker.com/make-this-diy-swamp-cooler-1850747672">Read more...</a></p>

## Use Plastic Flowerpots to Make DIY Cement Planters
 - [https://lifehacker.com/use-plastic-flowerpots-to-make-diy-cement-planters-1850748101](https://lifehacker.com/use-plastic-flowerpots-to-make-diy-cement-planters-1850748101)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XkZUfzar--/c_fit,fl_progressive,q_80,w_636/cbe51136eb5547bf75a80fd58e35c2cb.jpg" /><p>Sturdy pots and planters that look nice are some of the costlier elements of expanding your houseplant or garden collection. But you don’t have to settle for cheap plastic pots or drop a fortune on fancy planters if you’re willing to put a little bit of effort into making your own.<br /></p><p><a href="https://lifehacker.com/use-plastic-flowerpots-to-make-diy-cement-planters-1850748101">Read more...</a></p>

## The Best Podcasts to Represent Every US State (Plus DC)
 - [https://lifehacker.com/best-podcast-for-every-us-state-1850741030](https://lifehacker.com/best-podcast-for-every-us-state-1850741030)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--A6tydBPr--/c_fit,fl_progressive,q_80,w_636/358cf2ba4ff709a4c35f360d5b45bb94.png" /><p>America is a land of opportunity, of contradictions, of...podcasts. In fact, there’s at least one standout podcast for each of the 50 United States (and Washington, DC, too)—niche shows dedicated to everything from the Grand Canyon to the food at the Minnesota State Fair. Each one celebrates the voices and stories…</p><p><a href="https://lifehacker.com/best-podcast-for-every-us-state-1850741030">Read more...</a></p>

## You Should Pack a Family 'Flagged' Bag for the Airport
 - [https://lifehacker.com/you-should-pack-a-family-flagged-bag-for-the-airport-1850747507](https://lifehacker.com/you-should-pack-a-family-flagged-bag-for-the-airport-1850747507)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T16:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--eIjxAtaD--/c_fit,fl_progressive,q_80,w_636/3915b9fd4a174dea933bc633f6bf979d.jpg" /><p>Getting through airport security with kids can feel like chaos, especially if each family member has their own carry-on bag packed to the brim with items they need to stay entertained on a long flight. Parents have to keep an eye on multiple bags, which may not pass through the scanners in any sort of logical order…</p><p><a href="https://lifehacker.com/you-should-pack-a-family-flagged-bag-for-the-airport-1850747507">Read more...</a></p>

## The Best Ways to Invest (or Spend) $10,000
 - [https://lifehacker.com/the-best-ways-to-spend-or-invest-that-10-000-1849461953](https://lifehacker.com/the-best-ways-to-spend-or-invest-that-10-000-1849461953)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Z8SrIhNA--/c_fit,fl_progressive,q_80,w_636/cf29fa12e85c45c9d9ff39061c81612d.jpg" /><p>Most of us don’t have  $10,000 burning a hole in our pockets. Naturally, if you have this sum laying around, your first response should be to <a href="https://lifehacker.com/how-to-get-organized-to-pay-off-your-debt-1844083637/slides/3" target="_blank">pay off any outstanding debt</a>. It’s the most risk-free, straightforward use of your funds. It’s also a good idea to <a href="https://lifehacker.com/what-you-should-do-now-to-prepare-for-a-recession-1849129353" target="_blank">pad out your emergency “rainy day” fund</a>. </p><p><a href="https://lifehacker.com/the-best-ways-to-spend-or-invest-that-10-000-1849461953">Read more...</a></p>

## Buy Your Xbox 360 Games Now, Before the Store Shuts Down
 - [https://lifehacker.com/buy-your-xbox-360-games-now-before-the-store-shuts-dow-1850747248](https://lifehacker.com/buy-your-xbox-360-games-now-before-the-store-shuts-dow-1850747248)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T16:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--62miIL-T--/c_fit,fl_progressive,q_80,w_636/75c9bd94c05e8183158c5732f6610067.jpg" /><p>It’s the end of an era: Microsoft is officially <a href="https://support.xbox.com/en-US/help/xbox-360/store/xbox-360-marketplace-update" rel="noopener noreferrer" target="_blank">planning to shut down the Xbox 360 Store and the Xbox 360 Marketplace</a>. While certainly sad news, it might not be necessarily surprising: The Xbox Games Store launched with the console <a href="https://www.engadget.com/2005-09-15-xbox-360-launch-date-is-november-22.html" rel="noopener noreferrer" target="_blank">back in 2005</a>, the same year <a href="https://www.youtube.com/watch?v=jNQXAC9IVRw" rel="noopener noreferrer" target="_blank">YouTube started</a>. It was a different world. Now, with the…</p><p><a href="https://lifehacker.com/buy-your-xbox-360-games-now-before-the-store-shuts-dow-1850747248">Read more...</a></p>

## This Is the Secret to the Best Air Fryer Steak Bites
 - [https://lifehacker.com/this-is-the-secret-to-the-best-air-fryer-steak-bites-1850747577](https://lifehacker.com/this-is-the-secret-to-the-best-air-fryer-steak-bites-1850747577)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T15:33:04+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Egize-ku--/c_fit,fl_progressive,q_80,w_636/0dbc78eec558e856c5d9bd4e9639816e.jpg" /><p>Air frying bite-sized chunks of steak might be one of the most casual ways to pop straight protein (thanks, TikTok). It’s fast, simple, and <a href="https://lifehacker.com/why-your-next-sliced-steak-needs-a-board-sauce-1846683457" target="_blank">you can toss</a> or <a href="https://lifehacker.com/this-two-ingredient-horseradish-sauce-is-perfect-for-st-1848674319" target="_blank">dip the bites</a> in any number of sauces. However, like most good ideas born on social media, there’s room for improvement. Yes, you should make some popcorn meat,…</p><p><a href="https://lifehacker.com/this-is-the-secret-to-the-best-air-fryer-steak-bites-1850747577">Read more...</a></p>

## Get a Year’s Subscription to NeuroNation for 52% Off
 - [https://lifehacker.com/get-a-year-s-subscription-to-neuronation-for-52-off-1850737598](https://lifehacker.com/get-a-year-s-subscription-to-neuronation-for-52-off-1850737598)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T15:00:04+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YY2DloVd--/c_fit,fl_progressive,q_80,w_636/d3d1e41874089d415f4d89b7d84e1321.png" /><p>Your brain isn’t a muscle, but it still benefits from daily training. Drifting focus and a foggy memory can be frustrating, but you may be able to help your brain get into gear by running it through a few specialized workouts every day. That’s the idea behind NeuroNation Brain Training. </p><p><a href="https://lifehacker.com/get-a-year-s-subscription-to-neuronation-for-52-off-1850737598">Read more...</a></p>

## Make Reddit Usable on iPhone Again With This App
 - [https://lifehacker.com/make-reddit-usable-on-iphone-again-with-this-app-1850746558](https://lifehacker.com/make-reddit-usable-on-iphone-again-with-this-app-1850746558)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uRbLi9t6--/c_fit,fl_progressive,q_80,w_636/d98f3db3d2e34f50ca0a7a1469d27d63.png" /><p>After Reddit <a href="https://lifehacker.com/the-reddit-blackout-is-over-but-the-protest-isn-t-1850539204" target="_blank">purged its free API for third-party apps</a>, the landscape of Reddit apps became quite bleak. You now have two options: You either use Reddit’s own app, which is not great and is chock-full of recommended posts and videos you don’t want to see; or you use the Reddit website, and jump through popups forcing…</p><p><a href="https://lifehacker.com/make-reddit-usable-on-iphone-again-with-this-app-1850746558">Read more...</a></p>

## This Refurbished MacBook Air Is $250 Right Now
 - [https://lifehacker.com/this-refurbished-macbook-air-is-250-right-now-1850743344](https://lifehacker.com/this-refurbished-macbook-air-is-250-right-now-1850743344)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T13:11:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dv2MccxY--/c_fit,fl_progressive,q_80,w_636/461add1eeed17df8e6b5bbc337ef1368.png" /><p>This <a href="https://shop.lifehacker.com/sales/macbook-air-1-6ghz-4gb-ram-128gb-ssd-w-black-case-refurbished?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=macbook-air-1-6ghz-4gb-ram-128gb-ssd-w-black-case-refurbished&amp;utm_term=scsf-577025&amp;utm_content=a0x1P000005OtjDQAS&amp;scsonar=1">refurbished MacBook Air is on sale for $247.99</a>. It’s from 2015, so obviously it’s on the older end, but it’s certified refurbished to look and work like new. It comes with a charger and cable, black snap-on case, an Intel Core i5 processor, and 128GB SSD. Its battery can last up to nine hours on a charge.</p><p><a href="https://lifehacker.com/this-refurbished-macbook-air-is-250-right-now-1850743344">Read more...</a></p>

## You Can Get Siri to Read Articles Out Loud Now
 - [https://lifehacker.com/you-can-get-siri-to-read-articles-out-loud-now-1850746524](https://lifehacker.com/you-can-get-siri-to-read-articles-out-loud-now-1850746524)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uUZ_d679--/c_fit,fl_progressive,q_80,w_636/283b9ab27a79cbbec8cb22e11f0979f8.png" /><p>Speech-to-text is among the most useful accessibility technologies to ever have been invented. It lets you use AI to read things out loud, which is great for people who suffer from vision loss, those who want to take a break from screen time, and those who want to listen to things while their hands are occupied (like…</p><p><a href="https://lifehacker.com/you-can-get-siri-to-read-articles-out-loud-now-1850746524">Read more...</a></p>

## Delete Your Snapchat to Escape Its Rogue AI
 - [https://lifehacker.com/how-to-delete-snapchat-android-iphone-1850745271](https://lifehacker.com/how-to-delete-snapchat-android-iphone-1850745271)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-08-17T12:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--8W8MhVLQ--/c_fit,fl_progressive,q_80,w_636/a453a980d0f3039d53ab85ecb32917ca.jpg" /><p>Earlier this week, <a href="https://lifehacker.com/snapchats-ai-bot-might-be-the-easiest-way-to-access-cha-1850362083" target="_blank">Snapchat’s AI chatbot,</a> My AI, seems to have gone rogue. With no explanation, it posted a story to all Snapchat users consisting of a one-second video of what looked like a wall and ceiling. This is not what My AI is supposed to do, and there is no explanation for why it did it.<br /></p><p><a href="https://lifehacker.com/how-to-delete-snapchat-android-iphone-1850745271">Read more...</a></p>

