# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Death Spiral of Woke Hollywood
 - [https://www.youtube.com/watch?v=rIWHFCCCbXI](https://www.youtube.com/watch?v=rIWHFCCCbXI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-08-17T19:42:20+00:00

The coming Woke Hollywood Apocalypse is here.
#Hollywood #Disney #Netflix 

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Subscribe to The Nerdrotic Network:@nerdrotic @NerdroticLive @NerdroticDaily 

Edited by @QTRBlackGarrett  

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: http://Metapcs.com/Nerdrotic/ref

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/...

