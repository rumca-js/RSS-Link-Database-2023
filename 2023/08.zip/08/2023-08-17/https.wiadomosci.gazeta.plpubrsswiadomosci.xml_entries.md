# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Tragiczny wypadek na Mazowszu. Mężczyzna wpadł do kanału samochodowego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30091036,tragiczny-wypadek-na-mazowszu-mezczyzna-wpadl-do-kanalu-samochodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30091036,tragiczny-wypadek-na-mazowszu-mezczyzna-wpadl-do-kanalu-samochodowego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T20:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/27/b2/1c/z30091047M,Zdjecie-ilustracyjne.jpg" vspace="2" />Trwa wyjaśnianie okoliczności śmierci mężczyzny, który wpadł do kanału samochodowego. Do tragedii doszło w czwartek po południu we wsi Chrosna w woj. mazowieckim.

## Z Muzeum Brytyjskiego skradziono biżuterię i klejnoty. Trop prowadzi do jednego z pracowników
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090972,z-muzeum-brytyjskiego-skradziono-bizuterie-i-klejnoty-trop.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090972,z-muzeum-brytyjskiego-skradziono-bizuterie-i-klejnoty-trop.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T20:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/b2/1c/z30091016M,Muzeum-Brytyjskie.jpg" vspace="2" />Trwa wyjaśnianie okoliczności kradzieży biżuterii i klejnotów z kolekcji z Muzeum Brytyjskiego w Londynie. Trop prowadzi do wieloletniego pracownika instytucji. Mężczyzna został zwolniony. Muzeum zapowiada podjęcie kroków prawnych.

## Nawałnice przeszły nad Jelenią Górą. Zalane drogi i posesje. "Szykowane są worki z piaskiem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090791,nawalnice-przeszly-nad-jelenia-gora-zalane-drogi-i-posesje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090791,nawalnice-przeszly-nad-jelenia-gora-zalane-drogi-i-posesje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T19:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/b2/1c/z30090951M,W-Jeleniej-Gorze-zalane-sa-posesje-i-ulice.jpg" vspace="2" />Potężne ulewy przeszły nad Jelenią Górą, w wyniku czego gwałtownie podniósł się poziom wody w Radomierce. Ulice i gospodarstwa są zalane. "Szykowane są worki z piaskiem, by woda nie dostała się do domów mieszkańców" - napisał Jerzy Łużniak, prezydent Jeleniej Góry.

## Świętokrzyskie. Nad regionem przeszły gwałtowne burze. Nie żyje kobieta rażona piorunem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090817,swietokrzyskie-nad-regionem-przeszly-gwaltowne-burze-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090817,swietokrzyskie-nad-regionem-przeszly-gwaltowne-burze-nie-zyje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T19:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/49/b0/1c/z30083145M,Pogoda-na-dzis---czwartek--17-sierpnia--IMGW-ostrz.jpg" vspace="2" />W miejscowości Aleksandrów w powiecie jędrzejowskim w czasie czwartkowej burzy piorun prawdopodobnie uderzył w kobietę. Niestety mimo reanimacji poszkodowana zmarła. Służby ustalają okoliczności zdarzenia.

## Sprawa Mariki M. Ziobro odwołał wiceszefową prokuratury rejonowej. "Ukarano osobę całkowicie niewinną"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090721,sprawa-mariki-m-ziobro-odwolal-wiceszefowa-prokuratury-rejonowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090721,sprawa-mariki-m-ziobro-odwolal-wiceszefowa-prokuratury-rejonowej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T19:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/b2/1c/z30090458M,Zbigniew-Ziobro--Zdjecie-archiwalne.jpg" vspace="2" />"Gazeta Wyborcza" rozmawiała z poznańskimi prokuratorami na temat politycznego spektaklu, który miał miejsce w sprawie Mariki M. Zdaniem Zbigniewa Ziobry doszło tutaj do nadużyć. Sprawę ws. rozboju prowadziła prokuratorka Agnieszka Kanarkowska, a wniosek o wymierzenie kary zaakceptowała wiceszefowa Anna Idziniak. Mimo to zdymisjonowano drugą wiceszefową Joannę Gosieniecką. "Jako jedyna - nie miała w prokuraturze pleców" - pisze gazeta.

## Magdalena Filiks zapowiedziała start w wyborach. "To była koszmarnie trudna decyzja"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090742,magdalena-filiks-zapowiedziala-start-w-wyborach-to-byla-koszmarnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090742,magdalena-filiks-zapowiedziala-start-w-wyborach-to-byla-koszmarnie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T19:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2f/b2/1c/z30090799M,Magdalena-Filiks.jpg" vspace="2" />"Siła, którą dostaję codziennie od was, jest dużo większa, niż była moja własna kiedy jeszcze byłam 'tamtą Magdą'"- napisała posłanka Magdalena Filiks w zapowiedzi, że wystartuje jako "dwójka" na liście Koalicji Obywatelskiej w Szczecinie. Polityczka podzieliła się planami na kampanię wyborczą i celami, które chce zrealizować.

## Pakt senacki na Podlasiu wywrócony do góry nogami. Południe dla PO, północ dla PSL [LISTA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090659,pakt-senacki-na-podlasiu-poludnie-dla-psl-polnoc-dla-po-szansa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090659,pakt-senacki-na-podlasiu-poludnie-dla-psl-polnoc-dla-po-szansa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T18:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/a0/11/z18482999M,Cezary-Cieslukowski.jpg" vspace="2" />W województwie podlaskim pojawiła się zmiana w listach wyborczych. Do tej pory zakładano, że mieszkańcy na południu województwa będą głosowali na kandydata z PSL, natomiast na północy na PO. Stanie się natomiast odwrotnie. Dzięki temu kandydaci będą mogli konkurować w znanych im regionach.

## "Panel symetrystów" na Campusie Polska Przyszłości odwołany. "Usłyszałem, że zaproszenie zostaje wycofane"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090755,panel-symetrystow-na-campusie-polska-przyszlosci-odwolany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090755,panel-symetrystow-na-campusie-polska-przyszlosci-odwolany.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T18:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4a/b2/1c/z30090826M,Marcin-Meller.jpg" vspace="2" />"Panel symetrystów", który miał odbyć się na rozpoczynającym się w przyszłym tygodniu Campusie Polska Przyszłości, został odwołany. "W największym skrócie: zadzwonili do mnie organizatorzy Campusu z pytaniem, czy mogę poprowadzić panel bez Grzegorza Sroczyńskiego. Odpowiedziałem, że nie ma takiej możliwości" - napisał Marcin Meller.

## Dzierżoniów. Policja apeluje o pomoc w poszukiwaniach. Chodzi o mężczyznę, który zaatakował kobietę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090754,dzierzoniow-policja-apeluje-o-pomoc-w-poszukiwaniach-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090754,dzierzoniow-policja-apeluje-o-pomoc-w-poszukiwaniach-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T18:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/b2/1c/z30090764M,Dzierzoniow--Policja-poszukuje-napastnika--ktory-z.jpg" vspace="2" />Policja z Dzierżoniowa apeluje o pomoc w poszukiwaniach mężczyzny, który 15 sierpnia zaatakował kobietę w miejskim parku. Funkcjonariusze opublikowali portret pamięciowy mężczyzny. Szczególnie cenne dla służb są informacje od osób, które posiadają w aucie wideorejestrator i tego dnia przejeżdżały w pobliżu miejsca zdarzenia.

## Zabójstwo w Radzionkowie. Prokuratura ujawnia nowe szczegóły. Co miało skłonić 19-latka do zbrodni?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090655,zabojstwo-w-radzionkowie-prokuratura-ujawnia-nowe-szczegoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090655,zabojstwo-w-radzionkowie-prokuratura-ujawnia-nowe-szczegoly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T18:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ee/b2/1c/z30090734M,Zabojstwo-w-Radzionkowie--Prokuratura-ujawnia-nowe.jpg" vspace="2" />Prokuratura ujawniła nowe ustalenia w sprawie zabójstwa 18-letniej dziewczyny w Radzionkowie. Z informacji przekazanych mediom wynika, że podejrzanego do zbrodni mógł "skłonić wewnętrzny głos".

## Wniosek o uchylenie immunitetu prezesa PiS. Kaczyński nie zagłosował
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090696,wniosek-o-uchylenie-immunitetu-prezesa-pis-kaczynski-nie-glosowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090696,wniosek-o-uchylenie-immunitetu-prezesa-pis-kaczynski-nie-glosowal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/b2/1c/z30090717M,Jaroslaw-Kaczynski.jpg" vspace="2" />W czwartek Sejm odrzucił wniosek o uchylenie immunitetu prezesa PiS Jarosława Kaczyńskiego. Sprawa ma związek z prywatnym aktem oskarżenia dotyczącym słów polityka o "dawaniu w szyję". Prezes PiS nie brał udziału w głosowaniu.

## Sejm przyjął uchwałę PiS ws. obcej ingerencji w proces wyborczy. "Ta uchwała to jest po prostu wstyd"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090625,sejm-przyjal-uchwale-ws-obcej-ingerencji-w-proces-wyborczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090625,sejm-przyjal-uchwale-ws-obcej-ingerencji-w-proces-wyborczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/b2/1c/z30090653M,Sejm-RP--17-sierpnia.jpg" vspace="2" />Sejm przyjął uchwałę w sprawie obcej ingerencji w proces wyborczy w Polsce. W dokumencie przygotowanym przez posłów Prawa i Sprawiedliwości napisano, że Rzeczpospolita Polska uznaje za "akt wrogi" wobec naszego państwa wszelką obcą ingerencję w polski proces wyborczy i będzie ją "zdecydowanie zwalczać".

## W wypadku na Lubelszczyźnie zginęły trzy aktorki. Jechały na pogrzeb. Mieszkańcy żegnają kobiety
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090617,w-wypadku-na-lubelszczyznie-zginely-trzy-aktorki-jechaly-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090617,w-wypadku-na-lubelszczyznie-zginely-trzy-aktorki-jechaly-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/ae/1c/z30076727M,Wypadek-dwoch-samochodow--Nie-zyja-trzy-osoby.jpg" vspace="2" />W poniedziałek na obwodnicy Chodla na Lubelszczyźnie doszło do tragicznego wypadku. W zderzeniu dwóch samochodów zmarły trzy kobiety. Okazuje się, że to aktorki z poniatowskiej grupy teatralnej "Fajna Ferajna".

## "Lex Czarnek 3.0" przyjęte przez Sejm. Ustawa zakazuje "seksualizacji" dzieci w szkołach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090600,lex-czarnek-3-0-przyjete-przez-sejm-ustawa-zakazuje-seksualizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090600,lex-czarnek-3-0-przyjete-przez-sejm-ustawa-zakazuje-seksualizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/b2/1c/z30090652M,Sejm-RP--17-sierpnia.jpg" vspace="2" />W czwartek Sejm uchwalił nowelizację prawa oświatowego zakazującą działania w szkołach organizacji, które chcą "promować zagadnienia związane z seksualizacją dzieci". Projekt Komitetu Inicjatywy Ustawodawczej "Chrońmy dzieci" został złożony w lipcu. Pełnomocniczką komitetu jest radna PiS ze Stalowej Woli Karolina Paleń. Projekt ustawy nazywany jest przez media "Lex Czarnek 3.0". Szef resortu edukacji Przemysław Czarnek formalnie nie jest związany z inicjatywą, ale wyraził dla niej jednoznaczne poparcie.

## "Sensacje XX wieku" zniknęły z TVP. Wołoszański: Ta kojarzy mi się z zagrywką Stalina
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090536,sensacje-xx-wieku-zniknely-z-tvp-woloszanski-ta-zagrywka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090536,sensacje-xx-wieku-zniknely-z-tvp-woloszanski-ta-zagrywka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fa/b1/1c/z30086906M,Woloszanski.jpg" vspace="2" />Bogusław Wołoszański wystartuje w wyborach parlamentarnych z listy Koalicji Obywatelskiej. W dniu ogłoszenia tej informacji z anteny TVP Historia zniknęły dwa prowadzone przez niego programy. - Jak widać, zostałem uznany za wroga numer jeden - skomentował dziennikarz.

## Znany piłkarz wystartuje z list PiS? Mógłby być "lokomotywą wyborczą"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090542,znany-pilkarz-wystartuje-z-list-pis-moglby-byc-lokomotywa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30090542,znany-pilkarz-wystartuje-z-list-pis-moglby-byc-lokomotywa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/61/60/18/z25559137M,Sebastian-Mila.jpg" vspace="2" />Na listach PiS mógłby wystartować były reprezentant Polski w piłce nożnej - Sebastian Mila - wynika z ustaleń Wirtualnej Polski. - Mógłby być "lokomotywą wyborczą", która zrobi dobry wynik. Bardziej wyglądało to na pomysł wciągnięcia go na listy - mówi rozmówca portalu.

## Marianna Schreiber wyrzucona z własnej partii Mam Dość 2023. "Nie będę brała udziału w tym krindżu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090498,marianna-schreiber-wyrzucona-z-wlasnej-partii-mam-dosc-2023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090498,marianna-schreiber-wyrzucona-z-wlasnej-partii-mam-dosc-2023.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T17:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/b2/1c/z30090628M,Zalozycielka-partii-Mam-Dosc-2023-Marianna-Schreib.jpg" vspace="2" />"Ta decyzja sądu jest dla mnie kolejnym przyczynkiem do mojej tezy o potrzebie całościowego zaorania sądownictwa" - napisała Marianna Schreiber po tym, jak Sąd Okręgowy w Warszawie zarejestrował partię Mam Dość 2023 bez niej na liście. Założycielka partii opowiedziała w mediach społecznościowych o przebiegu sytuacji, ale obecny wiceszef partii zdementował jedną z kwestii.

## Wypadek kolumny z Szydło. Wraca śledztwo ws. zbiórki na zakup seicento dla Sebastiana Kościelnika
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090335,wypadek-kolumny-z-szydlo-wraca-sledztwo-ws-zbiorki-na-zakup.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090335,wypadek-kolumny-z-szydlo-wraca-sledztwo-ws-zbiorki-na-zakup.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T16:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/18/1c/z29462423M,Sebastian-Koscielnik.jpg" vspace="2" />W 2017 roku samochód, który wiózł Beatę Szydło przez Oświęcim, zderzył się w fiatem seicento, którym poruszał się Sebastian Kościelnik. W sieci została założona zbiórka pieniędzy na zakup nowego auta dla mężczyzny. Zebrano w niej 140 tys. zł, jednak Kościelnik pieniędzy nigdy nie otrzymał, a organizator zrzutki zniknął. Teraz prokuratura ma wrócić do sprawy.

## Do klubu KO dołączyło pięcioro parlamentarzystów. Wśród nich m.in. były członek klubu PiS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090497,do-klubu-koalicji-obywatelskiej-dolaczylo-piecioro-parlamentarzystow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090497,do-klubu-koalicji-obywatelskiej-dolaczylo-piecioro-parlamentarzystow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T16:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/b2/1c/z30090555M,Hanna-Gill-Piatek.jpg" vspace="2" />Klub parlamentarny Koalicji Obywatelskiej powiększył się o pięć osób. Do KO dołączyli m.in. wicemarszałkini Senatu Gabriela Morawska-Stanecka i posłanka Hanna Gill-Piątek.

## Holandia. Rowerzysta z Polski wjechał na przejazd, gdy nadjeżdżał pociąg. 46-latek zmarł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090403,holandia-polak-zostal-smiertelnie-potracony-przez-pociag-burmistrz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090403,holandia-polak-zostal-smiertelnie-potracony-przez-pociag-burmistrz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T16:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fa/b2/1c/z30090490M,Holandia--Polak-zostal-smiertelnie-potracony-przez.jpg" vspace="2" />"Bardzo drastyczne, zarówno dla bliskich, jak i osób, które widziały wypadek, w tym młodych ludzi" - napisał burmistrz miasta Overveen (Holandia), w którym zginął Polak. Mężczyzna został potrącony przez pociąg. O szczegółach poinformował Elbert Roest, który zapowiedział wsparcie dla świadków tego zdarzenia.

## Kupił bilety do Pakistanu w jedną stronę, ale nie dla Sary. Dzień później znaleźli ciało 10-latki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090276,ojciec-kupil-bilety-do-pakistanu-w-jedna-strone-dzien-pozniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090276,ojciec-kupil-bilety-do-pakistanu-w-jedna-strone-dzien-pozniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T16:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/b2/1c/z30090520M,10-letnia-Sara-zostala-znaleziona-martwa-w-domu-ni.jpg" vspace="2" />Pani Olga musiała wrócić z Polski do Wielkiej Brytanii po telefonie z policji, po którym dowiedziała się o śmierci swojej córki Sary. Jak się okazuje rodzina dziewczynki, dzień przed odnalezieniem ciała dziecka, kupiła kilka biletów w jedną stronę do Pakistanu. Wśród zakupionych biletów nie było tych na dane 10-latki.

## Ziobro odwołuje prokuratora z Dębicy. W tle śledztwo ws. sąsiedzkiego nękania
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090406,ziobro-odwoluje-prokuratora-z-debicy-w-tle-sledztwo-ws-sasiedzkiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30090406,ziobro-odwoluje-prokuratora-z-debicy-w-tle-sledztwo-ws-sasiedzkiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/b2/1c/z30090458M,Zbigniew-Ziobro--Zdjecie-archiwalne.jpg" vspace="2" />Prokurator generalny Zbigniew Ziobro zdymisjonował prokuratora rejonowego w Dębicy - przekazała w czwartek Prokuratura Krajowa. Powodem tej decyzji była sprawa dotycząca nękania, którą badała dębicka prokuratura. Według Ziobry doszło do licznych uchybień.

## Sejm zdecydował: uchwała ws. referendum przyjęta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089245,sejm-zdecydowal-uchwala-ws-referendum-przyjeta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089245,sejm-zdecydowal-uchwala-ws-referendum-przyjeta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/24/b1/1c/z30087972M.jpg" vspace="2" />Sejm przyjął uchwałę o zarządzeniu na 15 października referendum ogólnokrajowego bezwzględną większością głosów. Za głosowało 226 posłów, przeciw było 210, a wstrzymało się siedmiu parlamentarzystów.

## Roman Giertych. Ewolucja, której nie było. Rok po roku [OPINIA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30089374,roman-giertych-ewolucja-ktorej-nie-bylo-rok-po-roku-opinia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30089374,roman-giertych-ewolucja-ktorej-nie-bylo-rok-po-roku-opinia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/b2/1c/z30089956M,Rok-2019--Konferencja-prasowa-w-Warszawie.jpg" vspace="2" />Roman Giertych ogłosił start w wyścigu o mandat senatora. Informacja ta podzieliła środowisko opozycji. Przeciwnicy mecenasa wytykają mu mroczną przeszłość. Zwolennicy uspokajają sceptyków, że polityk ten przeszedł głęboką ewolucję. Ale czy na pewno? - pyta w tekście na łamach Gazeta.pl jutuber i komentator Koroluk.

## Rosja. Jednej doby zmarło dwóch generałów. Jeden miał się skarżyć na te same objawy, co Nawalny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089928,w-ciagu-doby-zmarl-drugi-rosyjski-general-mial-uskarzac-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089928,w-ciagu-doby-zmarl-drugi-rosyjski-general-mial-uskarzac-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/b2/1c/z30090286M,Dwoch-rosyjskich-generalow-zmarlo-w-ciagu-tej-same.jpg" vspace="2" />Od pewnego czasu w rosyjskiej armii trwają czystki, zawieszonych zostało już 15 generałów. Tymczasem w środę zmarło dwóch byłych dowodzących. Gen. Giennadij Żidko miał umrzeć "po długiej chorobie", choć wcześniej nic nie było wiadomo, by chorował. A gen. Giennadij Łopyriew trafił do szpitala z więzienia, w którym odsiadywał wyrok za łapówkarstwo. I tego samego dnia zmarł.

## Ukraina wyzwoliła miejscowość Urożajne. Rosyjscy żołnierze rzucili się do ucieczki [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090098,ukraina-wyzwolila-miejscowosc-urozajne-rosyjscy-zolnierze-rzucili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090098,ukraina-wyzwolila-miejscowosc-urozajne-rosyjscy-zolnierze-rzucili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/b2/1c/z30090352M,Wojna-w-Ukrainie--Rosyjscy-zolnierze-uciekali--kie.jpg" vspace="2" />Rosyjscy żołnierze uciekali w środę z wyzwolonej miejscowości Urożajne (Ukraina). Ich prędki odwrót zarejestrowała 35. Samodzielna Brygada Piechoty Morskiej Ukrainy. Nagranie opublikował następnie doradca ukraińskiego MSW Anton Geraszczenko.

## Szwecja podnosi stopień zagrożenia terrorystycznego. Premier zabrał głos
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090285,szwecja-podnosi-stopien-zagrozenia-terrorystycznego-szefowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090285,szwecja-podnosi-stopien-zagrozenia-terrorystycznego-szefowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/b2/1c/z30090389M,Charlotte-von-Essen.jpg" vspace="2" />Szwedzka służba bezpieczeństwa zdecydowała o podniesieniu stopnia zagrożenia terrorystycznego z 3 do 4 (na 5-stopniowej skali). To pierwsza taka decyzja od ośmiu lat. Powodem jest narastające napięcie związane m.in. z incydentami palenia kopii Koranu podczas demonstracji. W czwartek szef rządu Ulf Kristersson zwołał konferencję prasową.

## Samochód wpadł do podziemnego przejścia w Poznaniu w trakcie burzy. 24-latek jest w ciężkim stanie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090234,samochod-wpadl-do-podziemnego-przejscia-w-poznaniu-24-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30090234,samochod-wpadl-do-podziemnego-przejscia-w-poznaniu-24-latek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T15:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/b2/1c/z30090346M,W-Poznaniu-samochod-wpadl-do-podziemnego-przejscia.jpg" vspace="2" />Podczas silnej ulewy, która miała miejsce w Poznaniu, kierowca prawdopodobnie wpadł w poślizg i stracił panowanie nad pojazdem, po czym wjechał do podziemnego przejścia. Samochód dachował, a kierowca w ciężkim stanie został przewieziony do szpitala.

## Spadochroniarze przy granicy z Polską. Białoruskie wojsko opublikowało zdjęcia z ćwiczeń
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090089,spadochroniarze-przy-granicy-z-polska-bialoruskie-wojsko-opublikowalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30090089,spadochroniarze-przy-granicy-z-polska-bialoruskie-wojsko-opublikowalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T14:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/85/b2/1c/z30090117M,Bialoruskie-cwiczenia-przy-granicy-z-Polska.jpg" vspace="2" />Białoruskie wojsko poinformowało w czwartek o ćwiczeniach prowadzonych w obwodzie brzeskim przy granicy z Polską. Wykonywano m.in. skoki spadochronowe. Tamtejszy resort obrony opublikował zdjęcia.

## Teneryfa. Polacy publikują relacje o pożarze na hiszpańskiej wyspie. "Leci popiół z nieba"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089711,teneryfa-polacy-ostrzegaja-sie-i-relacjonuja-pozary-na-wyspie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30089711,teneryfa-polacy-ostrzegaja-sie-i-relacjonuja-pozary-na-wyspie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T14:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/b2/1c/z30090077M,Teneryfa--Pozary-na-wyspie-w-Hiszpanii--16-sierpni.jpg" vspace="2" />Teneryfa od kilku dni walczy z rozprzestrzeniającym się ogniem. "Pali się za płotem od wczoraj w nocy, a dopiero dzisiaj samoloty gaśnicze widziałem" - napisał jeden z Polaków przebywających na zagrożonym obszarze wyspy. Pożary są niebezpieczne dla osób, które mieszkają na Teneryfie albo spędzają wakacje na hiszpańskiej wyspie. Wśród nich są Polacy, którzy podzielili się swoimi relacjami z miejsca zdarzenia.

## Wpadka polityka Konfederacji. "Złamałeś protokół flagowy" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089946,wpadka-polityka-konfederacji-zlamales-protokol-flagowy-wideo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089946,wpadka-polityka-konfederacji-zlamales-protokol-flagowy-wideo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T14:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e8/ab/1c/z30064360M,Konwencja-Konfederacji.jpg" vspace="2" />Sebastian Ross z Konfederacji chciał poprawić ustawienie flag w Senacie, ale popełnił przy tym błąd. "Złamałeś protokół flagowy. Przy trzech flagach flaga gospodarza jest w środku. Ty, przestawiając flagę Ukrainy, ustawiłeś je tak, jakby gospodarzem była UE" - napisał Jakub Wiech, dziennikarz gospodarczy.

## Kto z Warszawy startuje do Senatu? Opozycja się dogadała. Cztery okręgi, parytet płci zachowany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088332,kto-z-warszawy-startuje-do-senatu-liste-kandydatow-opozycji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088332,kto-z-warszawy-startuje-do-senatu-liste-kandydatow-opozycji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T14:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9f/b1/1c/z30089119M,Malgorzata-Kidawa-Blonska.jpg" vspace="2" />Kto z Warszawy startuje do Senatu? Partie opozycyjne przedstawiły w czwartek wspólną listę kandydatów, efekt paktu senackiego. Oto oni: Marek Borowski będzie się ubiegał o reelekcję. O mandat będą też walczyć: doświadczona parlamentarzystka Małgorzata Kidawa-Błońska, posłanka Lewicy Magdalena Biejat oraz były Rzecznik Praw Obywatelskich Adam Bodnar.

## Afera mailowa. Prokuratura ma trzech podejrzanych ws. przejęcia hasła do skrzynki Dworczyka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089740,afera-mailowa-prokuratura-ma-trzech-podejrzanych-ws-przejecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089740,afera-mailowa-prokuratura-ma-trzech-podejrzanych-ws-przejecia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T13:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/12/b2/1c/z30090002M,Michal-Dworczyk--Zdjecie-archiwalne.jpg" vspace="2" />Śledztwo ws. uzyskania dostępu do prywatnej skrzynki e-mailowej byłego już szefa KPRM Michała Dworczyka jest prowadzone przeciwko trzem osobom - przekazał prokurator krajowy Dariusz Barski. Prokuratura Okręgowa w Warszawie nie ujawnia na razie, kim są te osoby i jaka miała być ich rola w przestępstwie.

## Korwin-Mikke spał w trakcie przemówienia partyjnego kolegi. Bosak akurat krytykował referendum [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089128,korwin-mikke-spal-w-trakcie-przemowienia-partyjnego-kolegi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30089128,korwin-mikke-spal-w-trakcie-przemowienia-partyjnego-kolegi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T13:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/b2/1c/z30090006M,Korwin-Mikke-spi-podczas-posiedzenia-Sejmu-17-08-2.jpg" vspace="2" />Sejm poparł w czwartek wniosek rządu ws. przeprowadzenia ogólnokrajowego referendum. Wcześniej Krzysztof Bosak negatywnie wypowiedział się na temat tego pomysłu. Kiedy jednak kończył wypowiedź, a kamery skierowały się w stronę słuchaczy, okazało się, że całe wystąpienie przespał prawdopodobnie jego partyjny kolega Janusz Korwin-Mikke.

## Rzeczniczka KE: UE nie będzie tolerować żadnych prób instrumentalizacji migrantów do celów politycznych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088696,rzeczniczka-ke-ue-nie-bedzie-tolerowac-zadnych-prob-instrumentalizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088696,rzeczniczka-ke-ue-nie-bedzie-tolerowac-zadnych-prob-instrumentalizacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T13:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/b1/1c/z30088750M.jpg" vspace="2" />Anitta Hipper w rozmowie z RMF FM podkreśliła, że "podejmowanie decyzji w sprawie referendów należy do państw członkowskich". Rzeczniczka Komisji Europejskiej odniosła się też pośrednio do treści części pytań zaproponowanych przez PiS w referendum.

## Samochód uderzył w motocyklistę. Kierowca wyleciał w powietrze i zderzył się z autobusem [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30089123,samochod-uderzyl-w-motocykliste-kierowca-wylecial-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30089123,samochod-uderzyl-w-motocykliste-kierowca-wylecial-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T13:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/05/b2/1c/z30089477M,Wlynkowko--Motocyklista-uderzyl-w-autobus-i-wyleci.jpg" vspace="2" />Siła zderzenia była tak duża, że motocyklista wyleciał w powietrze. Kamera z samochodu, który był w pobliżu, zarejestrowała poniedziałkowy wypadek, który wydarzył się w miejscowości Włynkówko. Wstrząsające wideo trafiło do sieci. Policja wstępnie ustaliła, co było powodem zdarzenia.

## Kto z Krakowa startuje do Senatu? Są dwa "skuteczne" nazwiska. "To sprawdzona strategia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30088842,wybory-parlamentarne-kto-z-krakowa-startuje-do-senatu-sa-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30088842,wybory-parlamentarne-kto-z-krakowa-startuje-do-senatu-sa-dwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T12:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7d/b1/1c/z30089085M,Pakt-senacki--zdj--ilustracyjne-.jpg" vspace="2" />Jerzy Fedorowicz i Bogdan Klich są krakowskimi kandydatami opozycji do Senatu. Liderzy opozycji ogłosili w czwartek zawarcie paktu senackiego i podali nazwiska wspólnych kandydatów. - Uzyskaliśmy porozumienie w sprawie wszystkich stu okręgów - przekazał senator KO Zygmunt Frankiewicz.

## Awantura i krzyki na posiedzeniu Sejmu ws. referendum. Terlecki: Dlaczego pan się drze jak głupi?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30086880,awantura-i-krzyki-na-posiedzeniu-sejmu-ws-referendum-terlecki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30086880,awantura-i-krzyki-na-posiedzeniu-sejmu-ws-referendum-terlecki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T12:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/b1/1c/z30087036M,Wicemarszalek-Sejmu-Ryszard-Terlecki.jpg" vspace="2" />"Dlaczego pan się drze jak głupi?" - zapytał wicemarszałek Ryszard Terlecki posła PO Jakuba Rutnickiego. Podczas czwartkowego posiedzenia Sejmu tematem przewodnim był wniosek o referendum, które miałoby odbyć się w tym samym dniu, co wybory parlamentarne. Pomiędzy obecnymi na nim politykami doszło do awantury.

## Aleksandra Wiśniewska nową twarzą KO. Zachęcała do udziału w wyborach, teraz bierze w nich udział
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30086953,aleksandra-wisniewska-nowa-twarza-ko-jej-strona-zostala-usunieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30086953,aleksandra-wisniewska-nowa-twarza-ko-jej-strona-zostala-usunieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T11:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/b1/1c/z30088147M,Rada-Krajowa-Platformy-Obywatelskiej-w-Warszawie.jpg" vspace="2" />Koalicja Obywatelska zakończyła kompletowanie list wyborczych. - Potrzebne nam były autorytety, doświadczeni parlamentarzyści, ale też debiutanci - stwierdził Donald Tusk. Jedną z debiutantek jest Aleksandra Wiśniewska, która wystartuje do Sejmu z piątego miejsca w Łodzi. "Służyła w obozach dla uchodźców w Grecji, Francji, na misjach ONZ w Turcji i Jordanii" - podaje lokalny portal. Jednak administratorzy Wikipedii mają wątpliwości i usunęli ze strony jej biogram.

## Czarnek krzyczał i wymachiwał palcem. "Lewaczki, dlaczego chcecie, żeby kobiety były gwałcone?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088109,czarnek-krzyczal-i-wymachiwal-palcem-lewaczki-dlaczego-chcecie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30088109,czarnek-krzyczal-i-wymachiwal-palcem-lewaczki-dlaczego-chcecie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T11:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/b1/1c/z30088124M,Przemyslaw-Czarnek.jpg" vspace="2" />Choć tematem czwartkowych obrad Sejmu było referendum, minister edukacji i nauki Przemysław Czarnek znalazł powód, by zaatakować kobiety i społeczność osób LGBT+. - Dlaczego chcecie, żeby polskie kobiety były gwałcone? - grzmiał polityk PiS. Następnie sprawę aborcji, in vitro oraz związków partnerskich określił "bzdurami".

## Jest decyzja Sejmu ws. referendum. PiS pędzi z projektem, chce "potwierdzać swoje decyzje"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30087456,jest-decyzja-sejmu-ws-referendum-pis-pedzi-z-projektem-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30087456,jest-decyzja-sejmu-ws-referendum-pis-pedzi-z-projektem-chce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T10:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/b1/1c/z30087164M,Politycy-PIS-podczas-debaty-o-planowanym-referendu.jpg" vspace="2" />Sejm poparł wniosek rządu o przeprowadzenie referendum ogólnokrajowego i skierował go do komisji ustawodawczej. Za głosowało 233 posłów, przeciw było 211, a 8 posłów wstrzymało się od głosu.

## Kołodziejczak przytoczył treść SMS-a z propozycją od ministra rolnictwa. Telus zaprzecza
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30086620,kolodziejczak-przytaczal-tresc-sms-z-propozycja-od-ministra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30086620,kolodziejczak-przytaczal-tresc-sms-z-propozycja-od-ministra.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T10:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/36/b1/1c/z30086710M,Michal-Kolodziejczak.jpg" vspace="2" />- Miałem propozycję, Robert Telus chciał się ze mną spotkać, zapowiadał spotkanie w tamtym tygodniu - powiedział Michał Kołodziejczak na antenie Polsat News. Jednak sam minister rolnictwa ma inne zdanie na ten temat i stanowczo zaprzecza.

## Pakt senacki. Partie opozycyjne ogłosiły wspólną listę do Senatu. Znamy nazwiska [LISTA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30087426,pakt-senacki-partie-opozycyjne-oglosily-wspolna-liste-do-senatu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30087426,pakt-senacki-partie-opozycyjne-oglosily-wspolna-liste-do-senatu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T10:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/82/1b/z28845919M,Pilne.jpg" vspace="2" />Zakończyła się konferencja w sprawie paktu senackiego. Przedstawiciele partii opozycyjnych potwierdzili, że uzyskali porozumienie w kwestii wyborów do Senatu. Podczas konferencji głos zabrali liderzy ugrupowań opozycji zaangażowanych we wspólny start w wyborach. Poznaliśmy również listę kandydatów.

## Marcin Gołaszewski z Nowoczesnej oburzony swoją pozycją na listach KO. "Zostałem bezczelnie wydy***y"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085775,marcin-golaszewski-z-nowoczesnej-oburzony-swoja-pozycja-na-listach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085775,marcin-golaszewski-z-nowoczesnej-oburzony-swoja-pozycja-na-listach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/b1/1c/z30086152M,Marcin-Golaszewski-publicznie-wyrazil-swoje-niezad.jpg" vspace="2" />Po ogłoszeniu przez prezydenta RP terminu wyborów parlamentarnych rozpoczęła się walka o miejsca na listach wyborczych. Ogromne rozczarowanie w tej kwestii przeżył polityk Nowoczesnej Marcin Gołaszewski. - Zostałem bezczelnie wydy***y - skomentował swoje siódme miejsce na liście KO w Łodzi.

## Rzecznik rządu: Przygotowujemy listy wyborcze. "Wyciągnęliśmy lekcję z tego, co było cztery lata temu"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085803,rzecznik-rzadu-przygotowujemy-listy-wyborcze-wyciagnelismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085803,rzecznik-rzadu-przygotowujemy-listy-wyborcze-wyciagnelismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/b1/1c/z30086234M,Piotr-Muller.jpg" vspace="2" />- W tej chwili przygotowujemy listy wyborcze do Sejmu - poinformował w czwartek rzecznik rządu Piotr Müller. Jak zapowiedział, "listy senackie są opracowywane nawet dłużej niż poselskie". - To będą dobre kandydatury - dodał.

## Gdula w obronie Tuska: "Morawiecki ma więcej powiązań z Niemcami". I zaczął wymieniać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085257,pierwsze-czytanie-w-sejmie-ws-slow-webera-gdula-morawiecki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085257,pierwsze-czytanie-w-sejmie-ws-slow-webera-gdula-morawiecki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/b1/1c/z30087200M,Maciej-Gdula.jpg" vspace="2" />- Jeżeli byśmy porównali niemieckie powiązania Tuska i Morawieckiego, to Morawiecki ma więcej powiązań z Niemcami - mówił Maciej Gdula z Nowej Lewicy. W czwartek w Sejmie odbyło się pierwsze czytanie projektu uchwały w sprawie "obcej ingerencji w proces wyborczy w Polsce" związanej ze słowami Manfreda Webera. Gdula podczas obrad Komisji Spraw Zagranicznych postanowił wziąć w obronę Donalda Tuska.

## Z TVP do Sejmu. Magdalena Ogórek "jedynką" na listach PiS? "Wszystko w rękach prezesa"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085686,z-tvp-do-sejmu-magdalena-ogorek-jedynka-na-listach-pis-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085686,z-tvp-do-sejmu-magdalena-ogorek-jedynka-na-listach-pis-wszystko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a2/9a/1c/z29991074M,Magdalena-Ogorek-podczas--TweetupKPRM-z-premierem-.jpg" vspace="2" />Prawo i Sprawiedliwość, inaczej niż opozycja, nie zaprezentowało jeszcze list wyborczych. - Do 6 września mamy czas - przekazał rzecznik partii Rafał Bochenek. Z doniesień medialnych wynika, że czarnym koniem Jarosława Kaczyńskiego może być prezenterka TVP Info, była kandydatka SLD w wyborach prezydenckich, Magdalena Ogórek.

## Na Mazurach roi się od os. W sierpniu jest ich mnóstwo. Ratownicy interweniują każdego dnia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085314,na-mazurach-roi-sie-od-os-w-sierpniu-jest-ich-mnostwo-ratownicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085314,na-mazurach-roi-sie-od-os-w-sierpniu-jest-ich-mnostwo-ratownicy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/b1/1c/z30085727M,Jezioro-Rynskie--zdjecie-ilustracyjne-.jpg" vspace="2" />Mazurskie Ochotnicze Pogotowie Ratunkowe poinformowało o wysokiej liczbie przypadków użądlenia przez osy. Dyżurna pogotowia przekazała PAP informację, że w ciągu dnia otrzymują kilka wezwań do takich przypadków. W większości sytuacji użądlenie osy jest niegroźne i prowadzi wyłącznie do swędzenia i obrzęku. Osoby uczulone na jad os wymagają jednak jak najszybszego kontaktu z lekarzem.

## Śledztwo ws. koncertu Maty nad Wisłą. Jest decyzja prokuratury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30028200,sledztwo-ws-koncertu-maty-nad-wisla-jest-decyzja-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30028200,sledztwo-ws-koncertu-maty-nad-wisla-jest-decyzja-prokuratury.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T09:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b5/95/1b/z28922293M,Mata-Tour-Torun-.jpg" vspace="2" />Prokuratura Rejonowa Warszawa - Śródmieście umorzyła śledztwo ws. ubiegłegorocznego koncertu rapera Maty, który odbył się nad Wisłą - dowiedział się portal Gazeta.pl. Jak przekazał nam rzecznik Prokuratury Okręgowej, śledczy nie stwierdzili "znamion czynu zabronionego".

## Ile rząd przeznaczył na fundację Rydzyka? Hanna Gill-Piątek: Niedzielskiemu nie pomogły obfite ofiary
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085239,ile-rzad-przeznaczyl-na-fundacje-rydzyka-hanna-gill-piatek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30085239,ile-rzad-przeznaczyl-na-fundacje-rydzyka-hanna-gill-piatek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T08:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/30/1c/z29557372M,Premier-Mateusz-Morawiecki-i-o--Tadeusz-Rydzyk-w-W.jpg" vspace="2" />Rząd pieniędzmi podatników obsypuje fundację Lux Veritatis ks. Tadeusza Rydzyka w roku wyborów. Po 300 tys. zł dostała fundacja z kancelarii premiera i z Ministerstwa Zdrowia. A na samą realizację zadania publicznego pt. 'Wygraj małżeństwo' ministerstwo rozwoju ma przekazać fundacji Rydzyka 450 tys. zł. - To jest niesamowite, że jeden duchowny windykuje pół rządu - skomentowała posłanka Hanna Gill-Piątek, która w ramach interpelacji uzyskała te informacje.

## PiS chce do granic możliwości "grzać" referendum. Nawet kosztem programu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30084809,pis-chce-do-granic-mozliwosci-grzac-referendum-nawet-kosztem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30084809,pis-chce-do-granic-mozliwosci-grzac-referendum-nawet-kosztem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T08:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/af/1c/z30080095M,Wicepremier--prezes-PiS-Jaroslaw-Kaczynski-podczas.jpg" vspace="2" />W PiS panuje duże zadowolenie z tego, jak wypadło odpalenie pytań referendalnych. Z informacji Gazeta.pl ze źródeł bliskich Nowogrodzkiej wynika, że obóz rządzący chce wycisnąć z referendum jak najwięcej i może przesunąć dużą konwencję, a co za tym idzie także przedstawienie programu wyborczego. Pierwotnie konwencję planowano na przełom sierpnia i września.

## "Wiadomości" uderzają w Wołoszańskiego. Zapomnieli, że ponad 30 lat pracował w TVP?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085160,wiadomosci-tvp-o-decyzji-tuska-bylo-o-prorosyjskim-kolodziejczaku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30085160,wiadomosci-tvp-o-decyzji-tuska-bylo-o-prorosyjskim-kolodziejczaku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T08:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/b1/1c/z30085986M,Boguslaw-Woloszanski.jpg" vspace="2" />Kandydaci Koalicji Obywatelskiej w wyborach do Sejmu natychmiast znaleźli się na celowniku TVP. W "Wiadomościach" mówiono m.in. o "prorosyjskim" Michale Kołodziejczaku, "degradacji" Grzegorza Schetyny, ale uderzono też w Bogusława Wołoszańskiego - tego samego, który przez ponad 30 lat był pracownikiem TVP.

## Pogoda? Wysoka temperatura i gwałtowne burze. Kiedy skończy się upał? Nieprędko
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085135,pogoda-wysoka-temperatura-i-gwaltowne-burze-kiedy-skonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085135,pogoda-wysoka-temperatura-i-gwaltowne-burze-kiedy-skonczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T07:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7c/b1/1c/z30085244M,Upaly-moga-nie-ustapic-do-konca-sierpnia.jpg" vspace="2" />Według ostatnich doniesień synoptyków ciut niższych temperatur możemy podziewać się podczas weekendu oraz na początku przyszłego tygodnia. Inne prognozy mówią o tym, że z męczącymi upałami będziemy mierzyć się aż do końca sierpnia. IMGW podtrzymuje ostrzeżenia przed wysokimi temperaturami w zachodniej Polsce. Ostrzega jednocześnie przed zbliżającymi się burzami.

## Lasy Państwowe przygotowały regulamin dla leśników. Na liście wymogów m.in. zakaz brody i makijażu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085131,lasy-panstwowe-przygotowaly-regulamin-dla-lesnikow-na-liscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30085131,lasy-panstwowe-przygotowaly-regulamin-dla-lesnikow-na-liscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T07:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/b1/1c/z30085140M.jpg" vspace="2" />Internet obiegły zdjęcia nowego regulaminu przygotowanego przez Lasy Państwowe. Dokument zakazuje między innymi "ekstrawaganckich fryzur", "intensywnego makijażu", tatuaży i piercingu. W sieci zawrzało.

## Teneryfa w ogniu. Płonie park przyrody. "Sytuacja wymknęła się spod kontroli"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30085132,teneryfa-plonie-ogien-trawi-park-przyrody-sytuacja-wymknela.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30085132,teneryfa-plonie-ogien-trawi-park-przyrody-sytuacja-wymknela.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T06:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/b1/1c/z30085213M,Teneryfa-w-ogniu--zdj--ilustracyjne-.jpg" vspace="2" />Na Teneryfie służby od dwóch dni walczą z ogniem, który strawił już blisko dwa tysiące hektarów parku przyrody. - Sytuacja wymknęła się spod kontroli - poinformował szef regionalnego rządu Wysp Kanaryjskich Fernando Clavijo.

## Rośnie liczba ugryzień przez kleszcze. Jak się chronić i co zrobić w przypadku ukąszenia?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30082396,kleszcze-rosnie-liczba-ugryzien-i-powiklan-jak-sie-chronic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30082396,kleszcze-rosnie-liczba-ugryzien-i-powiklan-jak-sie-chronic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T05:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a3/b0/1c/z30084515M,Rosnie-liczba-ugryzien-kleszczy--zdjecie-ilustracy.jpg" vspace="2" />Sezon wakacyjny szczególnie sprzyja wędrówkom w lasach czy spacerach po parkach lub łąkach. Każda wyprawa w tereny z dużą ilością zieleni może jednak wiązać się z ryzykiem ugryzienia przez kleszcza. Dane opublikowane przez NFZ wskazują, że z roku na rok rośnie również liczba zachorowań na choroby odkleszczowe, które mogą mieć poważne powikłania. Czym może grozić ugryzienie i co mieć na uwadze?

## Paraliż lotniska we Frankfurcie. Po ulewie samoloty stoją w wodzie na pasie startowym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30085050,odwolane-loty-we-frankfurcie-lotnisko-zostalo-zalane-woda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30085050,odwolane-loty-we-frankfurcie-lotnisko-zostalo-zalane-woda.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T05:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c0/b0/1c/z30085056M.jpg" vspace="2" />Z powodu ogromnej ulewy w środę wieczorem odwołano kilkadziesiąt lotów na lotnisku we Frankfurcie. Niemiecka Służba Meteorologiczna wydała ostrzeżenie dla całego kraju związkowego Hesja.

## Błaszczak udziela wywiadu TVP. Nagle w tle pojawiają się żołnierze. "Co za ściema"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30084682,blaszczak-udziela-wywiadu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30084682,blaszczak-udziela-wywiadu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T04:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6a/b0/1c/z30084714M,Mariusz-Blaszczak-udziela-wywiadu-w-glownym-wydani.jpg" vspace="2" />Minister Mariusz Błaszczak udzielał wywiadu TVP, kiedy w tle nagle pojawili się żołnierze. Internauci szybko ocenili, że sytuacja mogła być ustawiona. Pod materiałem wideo nie szczędzili krytycznych uwag.

## Tak PiS wygrywa wybory. "Głos w Warszawie znaczy mniej niż w Kielcach"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30079784,tak-pis-wygrywa-wybory-glos-w-warszawie-znaczy-mniej-niz-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30079784,tak-pis-wygrywa-wybory-glos-w-warszawie-znaczy-mniej-niz-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T04:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/af/1c/z30080937M,-Glos-w-Warszawie-znaczy-mniej-niz-w-Kielcach----m.jpg" vspace="2" />Więcej wyborców może zagłosować na jedną partię, a wygra inna partia. Jesteśmy przyzwyczajeni, że coś takiego funkcjonuje w Stanach Zjednoczonych, ale ludzie raczej nie wiedzą, że u nas też - z analitykiem systemu wyborczego Leszkiem Kraszyną rozmawia Grzegorz Sroczyński.

## USA. Pilot źle się poczuł podczas lotu. Znaleziono go nieprzytomnego w toalecie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30084521,pilot-zle-sie-poczul-podczas-lotu-znaleziono-go-nieprzytomnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30084521,pilot-zle-sie-poczul-podczas-lotu-znaleziono-go-nieprzytomnego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T04:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/b0/1c/z30084620M,Smierc-w-samolocie--Pilot-zle-sie-poczul-podczas-l.jpg" vspace="2" />- Powiedzieli nam, że lądujemy, ponieważ pilot źle się poczuł, a kiedy wylądowaliśmy, poprosili nas o opuszczenie samolotu, ponieważ sytuacja się pogorszyła - powiedziała kobieta, która była na pokładzie. Pilot został znaleziony nieprzytomny w toalecie. Załoga niezwłocznie podjęła działania, aby uratować życie mężczyźnie z objawami zatrzymania akcji serca.

## Czego uczą się Rosjanie na lekcjach historii? "Nie było dysydentów, tylko zachodni agenci"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30084252,czego-ucza-sie-rosjanie-na-lekcjach-historii-nie-bylo-dysydentow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30084252,czego-ucza-sie-rosjanie-na-lekcjach-historii-nie-bylo-dysydentow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/32/a7/1c/z30044210M,Lekcja-w-szkole--zdjecia-ilustracyjne-.jpg" vspace="2" />"Znajomość historii pozwala nie tylko oceniać przeszłe wydarzenia, ale także przewidywać przyszłość" - brzmi cytat na końcu podręcznika historii w Rosji przeznaczonego dla uczniów klas 10-11. Trudno jednak wierzyć, że narracja przedstawiona w publikacji ma wiele wspólnego, chociażby z przeszłością, na co uwagę zwrócił "The Moscow Times".

## Horoskop dzienny - czwartek 17 sierpnia [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30082229,horoskop-dzienny-czwartek-17-sierpnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30082229,horoskop-dzienny-czwartek-17-sierpnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/82/1c/z29893507M,Horoskop-dzienny---czwartek.jpg" vspace="2" />Horoskop dzienny - czwartek 17 sierpnia 2023. Księżyca przybywa. Czujemy się zmotywowani i gotowi do działania. Przyszedł idealny czas na zmiany. Co cię czeka? Nie zwlekaj, sprawdź, co przygotowały gwiazdy.

## Potrącił 11-latkę na hulajnodze i odjechał, "bo mu się spieszy". Policja szuka świadków zajścia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30084678,potracil-11-latke-na-hulajnodze-i-odjechal-bo-mu-sie-spieszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30084678,potracil-11-latke-na-hulajnodze-i-odjechal-bo-mu-sie-spieszy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-17T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/83/1c/z29897261M,Hulajnogi-elektryczne--zdjecie-ilustracyjne-.jpg" vspace="2" />W Płońsku doszło do potrącenia 11-latki podróżującej hulajnogą. Kierowca, który brał udział w zdarzeniu, odjechał z jego miejsca. Śledczy apelują do świadków zdarzenia o kontakt z komisariatem policji.

