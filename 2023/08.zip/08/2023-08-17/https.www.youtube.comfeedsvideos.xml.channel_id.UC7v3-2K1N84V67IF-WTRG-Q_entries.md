# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Blue Beetle - Movie Review
 - [https://www.youtube.com/watch?v=LX3sGcw9S9Y](https://www.youtube.com/watch?v=LX3sGcw9S9Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-08-17T13:00:20+00:00

A DCU movie filmed while the DCEU was still a thing. Here's my review for BLUE BEETLE!

