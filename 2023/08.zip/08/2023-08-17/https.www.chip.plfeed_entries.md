# Source:Chip.pl, URL:https://www.chip.pl/feed, language:pl-PL

## Ten tajemniczy wzór towarzyszy ludzkości od tysięcy lat. Zajął się nim słynny fizyk
 - [https://www.chip.pl/2023/08/tajemniczy-wzor-plytki-penrosea](https://www.chip.pl/2023/08/tajemniczy-wzor-plytki-penrosea)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T19:00:59+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1062" src="https://konto.chip.pl/wp-content/uploads/2023/08/penrose.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/penrose.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Roger Penrose to jedna z najwybitniejszych postaci świata nauki. W 1973 roku opisał on specyficzne płytki, które tworzyły pewien wzór. Jak się okazało, jego istnienie sięga znacznie dalej w przeszłość niż mogłoby się wydawać. Te tzw. płytki Penrose’a stanowią dwa kształty, które połączyć tak, by tworzyły niepowtarzający się wzór. Poza intrygującym wyglądem, takie struktury miały [&#8230;]</p>

## Huawei z kolejnymi nowościami. Wielozadaniowy tablet Huawei MatePad 11,5” i słuchawki FreeBuds SE 2 już w Polsce
 - [https://www.chip.pl/2023/08/huawei-matepad-115-i-sluchawki-huawei-freebuds-se-2-premiera-w-polsce-ceny-promocja](https://www.chip.pl/2023/08/huawei-matepad-115-i-sluchawki-huawei-freebuds-se-2-premiera-w-polsce-ceny-promocja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T16:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1333" src="https://konto.chip.pl/wp-content/uploads/2023/08/HUAWEI-MatePad-11.5-Lifestyle-5711.jpg" style="margin-bottom: 10px;" width="2000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/HUAWEI-MatePad-11.5-Lifestyle-5711.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Chociaż Huawei dawno stracił swoją pozycję na rynku smartfonów, to nadal ma do zaoferowania bardzo dużo świetnych urządzeń, takich jak najnowszy tablet MatePad 11,5”, który właśnie zadebiutował w naszym kraju. Obok niego pojawiły się również słuchawki FreeBuds SE 2. Warto przyjrzeć się bliżej obu tym nowościom. Huawei MatePad 11.5” to mistrz prostej wielozadaniowości Nowy tablet [&#8230;]</p>

## Microsoft poszedł po rozum do głowy. W końcu usuniesz śmieci z Windowsa 11
 - [https://www.chip.pl/2023/08/windows-11-lista-aplikacji-usuwanie](https://www.chip.pl/2023/08/windows-11-lista-aplikacji-usuwanie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T15:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/04/windows-11-1-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/04/windows-11-1-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czuję się nieswojo, pisząc te słowa. Naiwnie sądziłem, że możliwość swobodnego usuwania dowolnej aplikacji z systemu operacyjnego jest czymś naturalnym, nad czym nie ma sensu się specjalnie zachwycać. Cytując klasyka: oczywista oczywistość. Doszliśmy jednak do dziwnego momentu w historii, kiedy oddanie takiej możliwości w ręce samych użytkowników staje się przyczynkiem do składania gratulacji. Nie rozumiem, [&#8230;]</p>

## Świetne promocje na laptopy Gigabyte. Powrót do szkoły nie musi być taki straszny i kosztowny
 - [https://www.chip.pl/2023/08/promocje-na-laptopy-gigabyte-powrot-do-szkoly](https://www.chip.pl/2023/08/promocje-na-laptopy-gigabyte-powrot-do-szkoly)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T15:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1018" src="https://konto.chip.pl/wp-content/uploads/2023/08/laptopy-gigabyte-promo-3.jpg" style="margin-bottom: 10px;" width="1856" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/laptopy-gigabyte-promo-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Choć raczej nikt nie lubi o tym myśleć, wakacje zbliżają się ku końcowi. Dla wielu osób oznacza to konieczność wyboru nowego laptopa, który będzie służył do nauki, ale też do rozrywki w wolnym czasie. Kupno nowego i dobrego sprzętu to zawsze spory wydatek, dlatego warto sprawdzić promocje, takie jak te na laptopy Gigabyte. Obniżki laptopów [&#8230;]</p>

## Test Sony a6700 – autofocus z najwyższej półki w rozsądnej cenie
 - [https://www.chip.pl/2023/08/sony-a6700-autofocus-test-recenzja-opinia](https://www.chip.pl/2023/08/sony-a6700-autofocus-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T14:00:00+00:00

<img alt="Sony a6700" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/08/Sony-a6700-009.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/Sony-a6700-009.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Sony przez długi czas traktowało po macoszemu swoje aparaty systemowe APS-C. Ostatnie pełne odświeżenie oferty miało miejsce w 2019 roku, a od tego czasu producent koncentrował siły na aparatach pełnoklatkowych. W ostatnich dwóch latach aparaty niepełnoklatkowe z serii a6XXX doczekały się jednak kilku nowych, bardzo dopracowanych i dobrych obiektywów, kwestią czasu wydawało się zatem odświeżenie [&#8230;]</p>

## Fatalna pomyłka w sprawie akumulatorów. Zapomniano o czymś, co naprawdę wpływa na baterie
 - [https://www.chip.pl/2023/08/interfaza-katoda-elektrolit-w-budowie-akumulatorow](https://www.chip.pl/2023/08/interfaza-katoda-elektrolit-w-budowie-akumulatorow)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1865" src="https://konto.chip.pl/wp-content/uploads/2023/08/2965px-Lithium-Ion_Battery_for_BMW_i3_-_Battery_Pack-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/2965px-Lithium-Ion_Battery_for_BMW_i3_-_Battery_Pack-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czy w przypadku akumulatorów litowo-jonowych wiemy już wszystko? Tak się nam tylko wydaje. Świat nauki wciąż odkrywa na nowo te urządzenia. Tym razem dowiedzieliśmy się o zapomnianym czynniku, który wpływa na jedną z elektrod akumulatora. O czym dokładnie mowa? Akumulatory litowo-jonowe, jak i ich kuzyni sodowo-jonowi, charakteryzują się przede wszystkim tym, że elektrolit będący medium [&#8230;]</p>

## Nowe smartfony i tablet w T-Mobile marki&#8230; T-Mobile
 - [https://www.chip.pl/2023/08/t-mobile-t-phone-t-tablet-5g-premiera-cena](https://www.chip.pl/2023/08/t-mobile-t-phone-t-tablet-5g-premiera-cena)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T13:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1067" src="https://konto.chip.pl/wp-content/uploads/2022/10/t-mobile-t-phone-premiera-4.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/t-mobile-t-phone-premiera-4.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Tuż przed startem roku szkolnego T-Mobile wprowadza do oferty trzy nowe urządzenia pod własną marka. To druga generacja smartfonów T Phone oraz nowość w postaci tabletu T Tablet. W dobie szalejących cen, dla wielu osób może to być ciekawy wybór. Zacznijmy od zupełnej nowości &#8211; tablet T Tablet z 5G Z danych T-Mobile wynika, że [&#8230;]</p>

## Sprawdziliśmy telewizor Samsung S95C. Czy QD-OLED to złoty standard jakości?
 - [https://www.chip.pl/2023/08/samsung-s95c-qd-oled-wrazenia-opinia](https://www.chip.pl/2023/08/samsung-s95c-qd-oled-wrazenia-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T12:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/08/samsung-qe77s95c-qd-oled-7.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/samsung-qe77s95c-qd-oled-7.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Koreańczycy weszli w segment telewizorów OLED z właściwym sobie podejściem. Dodając do swoich paneli warstwę kropki kwantowej zmienili zasady tego, jak patrzy się na telewizory z diodą organiczną. Teraz nadeszła pora, by pójść za ciosem, a najnowszy telewizor Samsung QE77S95C to mocny konkurent. Mamy pierwsze testy pokazujące możliwości nowego ekranu. W ubiegłym roku rynek OLED-ów, [&#8230;]</p>

## Opera w wersji dla telefonów z iOS dostaje inteligentnego chatbota. Aria to ChatGPT na sterydach
 - [https://www.chip.pl/2023/08/opera-ios-dostaje-inteligentnego-chatbota-aria](https://www.chip.pl/2023/08/opera-ios-dostaje-inteligentnego-chatbota-aria)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T11:58:37+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/06/Apple-WWDC23-iOS-17-Check-In-3up-230605-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/06/Apple-WWDC23-iOS-17-Check-In-3up-230605-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wszystko zaczęło się od opracowanego przez OpenAI modelu językowego GPT-3.5 (obecnie 4.0), na bazie którego nastąpiła eksplozja nowej generacji chatbotów, zaskakujących nie tylko poziomem wiedzy, lecz także zdolnością do budowania czytelnych odpowiedzi. Na bazie tego rozwiązania powstała Aria, inteligentna asystentka w przeglądarce internetowej Opera. W odróżnieniu od usługi oferowanej przez OpenAI, stan jej wiedzy nie [&#8230;]</p>

## Muzyka prosto z mózgu. Naukowcy stworzyli niezwykły &#8220;cover&#8221; utworu zespołu Pink Floyd
 - [https://www.chip.pl/2023/08/muzyka-naukowcy-pink-floyd](https://www.chip.pl/2023/08/muzyka-naukowcy-pink-floyd)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T10:30:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1208" src="https://konto.chip.pl/wp-content/uploads/2023/08/Muzyka-Pink-Floyd-rekonstrukcja-2.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/Muzyka-Pink-Floyd-rekonstrukcja-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ludzki mózg nie bez powodu pozostaje od wieków przedmiotem fascynacji oraz inspiracji przy tworzeniu np. sztucznych sieci neuronowych. Wysiłki zmierzające do rozszyfrowania niezliczonych funkcji mózgu są nieustannie podejmowane w ogromnych liczbach i jeden z najnowszych tego typu projektów zapewnił światu nowy utwór Pink Floyd… teoretycznie. Muzyka prosto z mózgu. Naukowcy odtworzyli kultowy utwór zespołu Pink [&#8230;]</p>

## Nadchodzą nowe karty graficzne Intela. Pierwsze testy dają nadzieję na godnego rywala Nvidii
 - [https://www.chip.pl/2023/08/nowe-karty-graficzne-intela-battlemage](https://www.chip.pl/2023/08/nowe-karty-graficzne-intela-battlemage)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T09:30:00+00:00

<img alt="Nowe karty graficzne Intel Battlemage" class="attachment-full size-full wp-post-image" height="1082" src="https://konto.chip.pl/wp-content/uploads/2022/12/Nowe-karty-graficzne-Battlemage-Intela.jpg" style="margin-bottom: 10px;" width="1860" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/Nowe-karty-graficzne-Battlemage-Intela.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Z najnowszych informacji wynika, że Intel zakasał już rękawy i wziął się za testowanie swoich nowych kart graficznych z serii Battlemage, która to zapoczątkuje serię Arc B, zastępując Arc A już w następnym roku. Battlemage już w testach. Nowe karty graficzne Intela nadchodzą Możecie się z tym nie zgodzić po tym, jak prezentują się sprzedawane [&#8230;]</p>

## Poznaliśmy sekret ataku na most krymski. Nowe nagrania ujawniły unikalny sprzęt Ukrainy
 - [https://www.chip.pl/2023/08/atak-most-krymski-ukraina-dron-sea-baby](https://www.chip.pl/2023/08/atak-most-krymski-ukraina-dron-sea-baby)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T09:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/08/Uszkodzony-most-krymski-Ukraina-sierpien-2023.jpg" style="margin-bottom: 10px;" width="1373" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/Uszkodzony-most-krymski-Ukraina-sierpien-2023.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ukraina przyjęła właśnie pełną odpowiedzialność za atak na most krymski, w ramach to którego znacznie go uszkodziła swoim unikalnym rodzajem broni, bo nawodnym dronem kamikadze. Na potwierdzenie tego dostaliśmy nagrania bezpośrednio z momentu ataku. Ukraina zniszczyła most krymski swoim wyjątkowym dronem Sea Baby Kosztuje cztery miliardy dolarów i jest kluczowy dla agresora do utrzymania w [&#8230;]</p>

## Kto mówi, że samochody elektryczne tanieją, ten kłamie. Sprawdziłem, o ile wzrosły ceny od zeszłego roku
 - [https://www.chip.pl/2023/08/samochody-elektryczne-tanieja-ceny-2023](https://www.chip.pl/2023/08/samochody-elektryczne-tanieja-ceny-2023)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T08:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2023/08/ceny-samochodow-elektrycznych-2023-podwyzki-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/08/ceny-samochodow-elektrycznych-2023-podwyzki-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Tesla z końcem ubiegłego roku i na początku obecnego zafundowała nam globalną falę obniżek. Volvo zaprezentowało model EX30 w zaskakująco niskiej cenie. Jeśli przyjrzymy się wypowiedziom entuzjastów elektromobilności, w wielu miejscach możemy przeczytać, że to jest ten moment. Moment, w którym auta elektryczne tanieją! Tyle że to kompletna bzdura. Samochody elektryczne nie tanieją. Spójrzcie sami. [&#8230;]</p>

## Czy prawa fizyki mogą się zmienić? Wieloletni eksperyment dostarczył odpowiedzi
 - [https://www.chip.pl/2023/08/czy-prawa-fizyki-moga-sie-zmienic-wieloletni-eksperyment-dostarczyl-odpowiedzi](https://www.chip.pl/2023/08/czy-prawa-fizyki-moga-sie-zmienic-wieloletni-eksperyment-dostarczyl-odpowiedzi)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T07:00:00+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2022/12/zegarek-piasek-czas-historia.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/12/zegarek-piasek-czas-historia.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Są rzeczy, które podobno się nie zmieniają, podczas gdy inne mogą różnić się wręcz z sekundy na sekundę. Do której kategorii zaliczają się prawa fizyki? Aby poznać odpowiedź na to pytanie, naukowcy zorganizowali trwający 14 lat eksperyment. O rezultatach przeprowadzonych badań pisali na łamach Nature. Na pierwszy rzut oka wyjaśnienie całej zagadki powinno być oczywiste, [&#8230;]</p>

## Wojsko Tajwanu utrzymywało swoją superbroń w tajemnicy przez ponad dekadę&#8230; aż do dziś
 - [https://www.chip.pl/2023/08/wojsko-tajwanu-pocisk-hsiung-fend-iie](https://www.chip.pl/2023/08/wojsko-tajwanu-pocisk-hsiung-fend-iie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-08-17T03:49:12+00:00

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/01/Chiny-kontra-Tajwan-sztuczna-inteligencja.jpg" style="margin-bottom: 10px;" width="1702" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Chiny-kontra-Tajwan-sztuczna-inteligencja.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wiedzieliśmy, że Tajwan ma na służbie swoją superbroń, ale przez ponad dekadę ani razu nie dostaliśmy okazji, aby ją zobaczyć. Dziś uległo to zmianie, a wieloletnia tajemnica wojska Tajwanu została pogrzebana. Jeden z sekretów wojska Tajwanu właśnie upadł. Oto pocisk Hsiung Feng IIE po raz pierwszy w obiektywie Jedna z najnowszych publikacji tajwańskiego dziennika United [&#8230;]</p>

