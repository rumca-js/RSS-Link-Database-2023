# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Incydent na wieży Eiffla. Interweniowała policja
 - [https://wydarzenia.interia.pl/zagranica/news-incydent-na-wiezy-eiffla-interweniowala-policja,nId,6969025](https://wydarzenia.interia.pl/zagranica/news-incydent-na-wiezy-eiffla-interweniowala-policja,nId,6969025)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-08-17T16:16:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-incydent-na-wiezy-eiffla-interweniowala-policja,nId,6969025"><img align="left" alt="Incydent na wieży Eiffla. Interweniowała policja" src="https://i.iplsc.com/incydent-na-wiezy-eiffla-interweniowala-policja/0007ILWB4MS46I56-C321.jpg" /></a>Policja aresztowała w czwartek rano mężczyznę, który wspiął się na Wieżę Eiffla i skoczył z niej na spadochronie. Jak informują lokalne media, skoczkowi udało się dolecieć do pobliskiego stadionu.  </p><br clear="all" />

