# Source:Vsauce, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA, language:en-US

## I 🟥 Quadrilaterals
 - [https://www.youtube.com/watch?v=asTywgpiSkQ](https://www.youtube.com/watch?v=asTywgpiSkQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC6nSFpj9HTCZ5t-N3Rm3-HA
 - date published: 2023-08-17T19:39:00+00:00

square rectangle rhombus kite parallelogram trapezoid geometry quadrilaterals Euler Diagram math nomenclature geometry

