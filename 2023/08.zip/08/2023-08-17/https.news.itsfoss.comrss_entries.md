# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## CrossOver 23.0 Release Adds 'Uninstall' Feature and EA App Support on Linux
 - [https://news.itsfoss.com/crossover-23-0-released/](https://news.itsfoss.com/crossover-23-0-released/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-08-17T09:49:09+00:00

Access to more games with the EA app, and more features, thanks to CrossOver 23.0 release. Check them all out here!

