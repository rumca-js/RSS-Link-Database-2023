# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Pierwszy dzień Top of the Top Sopot Festival 2023. Kto zachwycił na scenie
 - [https://tvn24.pl/najnowsze/top-of-the-top-sopot-festival-2023-koncert-i-dance-na-scenie-zalewski-przybysz-lemon-margaret-karwan-james-i-inni-7301193?source=rss](https://tvn24.pl/najnowsze/top-of-the-top-sopot-festival-2023-koncert-i-dance-na-scenie-zalewski-przybysz-lemon-margaret-karwan-james-i-inni-7301193?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T21:00:46+00:00

<img alt="Pierwszy dzień Top of the Top Sopot Festival 2023. Kto zachwycił na scenie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2goyq8-wokalistki-margaret-natalia-przybysz-sara-james-i-ania-karwan-podczas-koncertu-i-dance-w-pierwszym-dniu-top-of-the-top-sopot-festival-2023-7301499/alternates/LANDSCAPE_1280" />
    Przed nami jeszcze kolejne dni niezapomnianych koncertów.

## Emocjonalny rollercoaster Swobody
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-ewa-swoboda-zajela-szoste-miejsce-w-finale-biegu-_sto9753197/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-ewa-swoboda-zajela-szoste-miejsce-w-finale-biegu-_sto9753197/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T20:03:01+00:00

<img alt="Emocjonalny rollercoaster Swobody " src="https://tvn24.pl/najnowsze/cdn-zdjecie-krcluj-ewa-swoboda-7301532/alternates/LANDSCAPE_1280" />
    Polka nie znalazła się na podium.

## Kaczmarek niczego nie zostawiła przypadkowi. Awans w świetnym stylu
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-natalia-kaczmarek-pewnie-awansowala-do-finalu-na-_sto9753206/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-natalia-kaczmarek-pewnie-awansowala-do-finalu-na-_sto9753206/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T19:45:14+00:00

<img alt="Kaczmarek niczego nie zostawiła przypadkowi. Awans w świetnym stylu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f85qdg-natalia-kaczmarek-7301519/alternates/LANDSCAPE_1280" />
    Wygrała swój bieg półfinałowy.

## "Stagflacja ma twarz Glapińskiego i Morawieckiego"
 - [https://tvn24.pl/biznes/dlafirm/upadlosci-firm-i-slabe-dane-z-przemyslu-komentarz-w-faktach-po-faktach-w-tvn24-7301256?source=rss](https://tvn24.pl/biznes/dlafirm/upadlosci-firm-i-slabe-dane-z-przemyslu-komentarz-w-faktach-po-faktach-w-tvn24-7301256?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T18:34:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a9xhli-21-1925-fpf-cl-0003-7301337/alternates/LANDSCAPE_1280" />
    Gośćmi "Faktów po Faktach" byli Anna Popiołek i Paweł Wojciechowski.

## "Ciała zabitych pozostawiono rozrzucone na ziemi"
 - [https://tvn24.pl/swiat/arabia-saudyjska-raport-saudyjscy-straznicy-graniczni-zabili-setki-migrantow-na-granicy-z-jemenem-7301271?source=rss](https://tvn24.pl/swiat/arabia-saudyjska-raport-saudyjscy-straznicy-graniczni-zabili-setki-migrantow-na-granicy-z-jemenem-7301271?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T18:30:15+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wz4j78-wioska-na-pograniczu-jemenu-i-arabii-saudyjskiej-7301280/alternates/LANDSCAPE_1280" />
    Raport organizacji Human Rights Watch o ofiarach na granicy Jemenu i Arabii Saudyjskiej.

## Jeden z pilotów Black Hawka miał wyrok za katastrofę lotniczą
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-black-hawk-zahaczyl-o-linie-energetyczna-jeden-z-pilotow-mial-wyrok-za-katastrofe-lotnicza-7301221?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-black-hawk-zahaczyl-o-linie-energetyczna-jeden-z-pilotow-mial-wyrok-za-katastrofe-lotnicza-7301221?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T18:27:50+00:00

<img alt="Jeden z pilotów Black Hawka miał wyrok za katastrofę lotniczą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gupdeo-moment-zerwania-linii-energetycznej-przez-smiglowiec-black-hawk-7301079/alternates/LANDSCAPE_1280" />
    Dowiedział się nieoficjalnie portal tvn24.pl.

## Pech Polaka. Skończył mistrzostwa na półfinale
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-czykier-odpadl-w-polfinale-biegu-na-110-m-przez-p_sto9753077/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-czykier-odpadl-w-polfinale-biegu-na-110-m-przez-p_sto9753077/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T18:23:01+00:00

<img alt="Pech Polaka. Skończył mistrzostwa na półfinale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-74lpdf-wystep-damiana-czykiera-w-polfinale-biegu-przez-plotki-na-ms-w-budapeszcie-7301382/alternates/LANDSCAPE_1280" />
    Damian Czykier rywalizował w biegu na 110 m przez płotki.

## Przedstawicielka Agrounii do policjantów: Dlaczego państwo nas śledzą? Rzecznik tłumaczy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-przedstawicielka-agrounii-do-policjantow-dlaczego-panstwo-nas-sledza-rzecznik-tlumaczy-7301279?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-przedstawicielka-agrounii-do-policjantow-dlaczego-panstwo-nas-sledza-rzecznik-tlumaczy-7301279?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T18:10:29+00:00

<img alt="Przedstawicielka Agrounii do policjantów: Dlaczego państwo nas śledzą? Rzecznik tłumaczy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-iuvqvt-trojka-policjantow-podazala-ulicami-warszawy-za-michalem-kolodziejczakiem-z-agrounii-7301323/alternates/LANDSCAPE_1280" />
    Działo to przy dzisiejszej konferencji.

## Tragedia na zawodach Ironman. Dwóch zawodników nie żyje
 - [https://eurosport.tvn24.pl/triathlon/tragedia-na-zawodach-ironman-w-irlandii.-dwoch-zawodnikow-nie-zyje_sto9753014/story.shtml?source=rss](https://eurosport.tvn24.pl/triathlon/tragedia-na-zawodach-ironman-w-irlandii.-dwoch-zawodnikow-nie-zyje_sto9753014/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T17:55:10+00:00

<img alt="Tragedia na zawodach Ironman. Dwóch zawodników nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-74ya5n-dwie-osoby-zmarly-w-zawodach-ironman-w-irlandii-7301325/alternates/LANDSCAPE_1280" />
    Organizatorzy poinformowali, że do tragedii doszło w trakcie pływackiej części rywalizacji.

## "Zagrożenie dla bezpieczeństwa". Znów zamieszanie w systemie obsługi pacjentów
 - [https://fakty.tvn24.pl/zobacz-fakty/dane-o-receptach-dostepne-dla-kazdego-lekarza-w-systemie-gabinetgovpl-7301253?source=rss](https://fakty.tvn24.pl/zobacz-fakty/dane-o-receptach-dostepne-dla-kazdego-lekarza-w-systemie-gabinetgovpl-7301253?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T17:48:15+00:00

<img alt="" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-5l7ykg-210819-nowicki-pn-000920-7301251/alternates/LANDSCAPE_1280" />
    Kolejne zamieszanie w systemie obsługi pacjentów.

## "Powtarzał, że nie chce umierać". Nastolatek dźgnięty nożem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-17-latek-dzgniety-nozem-w-brzuch-na-ochocie-7301259?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-17-latek-dzgniety-nozem-w-brzuch-na-ochocie-7301259?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T17:46:24+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-h2lq4s-interweniowala-straz-miejska-zdjecie-ilustracyjne-7253315/alternates/LANDSCAPE_1280" />
    Zarzuty dla 16-latka.

## "Zniosło mnie na sąsiedni pas, byłem przerażony". Nagranie
 - [https://tvn24.pl/tvnmeteo/swiat/usa-tornado-rhode-island-tornado-uderzylo-w-samochod-znioslo-mnie-na-sasiedni-pas-bylem-przerazony-7301207?source=rss](https://tvn24.pl/tvnmeteo/swiat/usa-tornado-rhode-island-tornado-uderzylo-w-samochod-znioslo-mnie-na-sasiedni-pas-bylem-przerazony-7301207?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T17:07:29+00:00

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vcqh4e-tornado-7301239/alternates/LANDSCAPE_1280" />
    Tornado przeszło przez Rhode Island.

## Świetne momenty Polek to za mało. Pierwsza porażka Biało-Czerwonych
 - [https://eurosport.tvn24.pl/siatkowka/mistrzostwa-europy/2023/polska-serbia-w-meczu-fazy-grupowej-mistrzostw-europy-w-siatkowce-kobiet.-wynik-meczu-i-relacja_sto9752842/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/mistrzostwa-europy/2023/polska-serbia-w-meczu-fazy-grupowej-mistrzostw-europy-w-siatkowce-kobiet.-wynik-meczu-i-relacja_sto9752842/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:54:35+00:00

<img alt="Świetne momenty Polek to za mało. Pierwsza porażka Biało-Czerwonych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x37fg-polska-serbia-w-fazie-grupowej-mistrzostw-europy-w-pilce-siatkowej-kobiet-7301241/alternates/LANDSCAPE_1280" />
    Szans na awans do 1/8 finału turnieju będą szukać w kolejnych meczach z Belgią i Ukrainą.

## Gwałtowne ulewy uwięziły ich w kanałach. Znaleziono ciała uczestników wycieczki
 - [https://tvn24.pl/swiat/moskwa-gwaltowne-ulewy-uwiezily-uczestnikow-wycieczki-w-kanalizacji-znaleziono-ciala-7301188?source=rss](https://tvn24.pl/swiat/moskwa-gwaltowne-ulewy-uwiezily-uczestnikow-wycieczki-w-kanalizacji-znaleziono-ciala-7301188?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:24:39+00:00

<img alt="Gwałtowne ulewy uwięziły ich w kanałach. Znaleziono ciała uczestników wycieczki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-36numr-niektore-fragmenty-moskiewskiej-kanalizacji-pochodza-z-xix-wieku-7301186/alternates/LANDSCAPE_1280" />
    Kilka osób jest nadal poszukiwanych.

## Miał 11 lat, gdy wybuchła wojna. Przeżył sześć obozów koncentracyjnych
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3186,S00E3186,1141549?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-3186,S00E3186,1141549?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:23:33+00:00

<img alt="Miał 11 lat, gdy wybuchła wojna. Przeżył sześć obozów koncentracyjnych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mgqaet-ben-midler-7301203/alternates/LANDSCAPE_1280" />
    Rozmowa Adrianny Otręby z Benem Midlerem - ostatnim znanym ocalałym z białostockiego getta.

## Uśmiech od ucha do ucha
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023-wojciech-nowicki-odebral-srebrny-medal-mistrzostw-_sto9752657/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023-wojciech-nowicki-odebral-srebrny-medal-mistrzostw-_sto9752657/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:19:30+00:00

<img alt="Uśmiech od ucha do ucha " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayd9jg-wojciech-nowicki-odebral-srebrny-medal-7301200/alternates/LANDSCAPE_1280" />
    Wojciech Nowicki odebrał srebro mistrzostw świata.

## Na pikniku PiS rolnicy wylali gnojowicę? Inny kraj, inny rok
 - [https://konkret24.tvn24.pl/polska/wybory-parlamentarne-2023-na-pikniku-pis-rolnicy-wylali-gnojowice-inny-kraj-inny-rok-st7300802?source=rss](https://konkret24.tvn24.pl/polska/wybory-parlamentarne-2023-na-pikniku-pis-rolnicy-wylali-gnojowice-inny-kraj-inny-rok-st7300802?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:13:05+00:00

<img alt="Na pikniku PiS rolnicy wylali gnojowicę? Inny kraj, inny rok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y41xxy-na-pikniku-pis-rolnicy-wylali-gnojowice-nie-ten-kraj-nie-ten-rok-7301012/alternates/LANDSCAPE_1280" />
    Rolnik rzekomo rozlał gnojowicę w proteście przeciwko rządom PiS, ale popularne nagranie jest stare i nie pokazuje sytuacji z Polski.

## Nie chcą przejazdu nagich rowerzystów
 - [https://tvn24.pl/swiat/francja-nie-chca-przejazdu-nagich-rowerzystow-tour-de-france-naturystow-napotkal-problemy-7300990?source=rss](https://tvn24.pl/swiat/francja-nie-chca-przejazdu-nagich-rowerzystow-tour-de-france-naturystow-napotkal-problemy-7300990?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T16:00:04+00:00

<img alt="Nie chcą przejazdu nagich rowerzystów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pbj8eo-world-naked-bike-ride-7300992/alternates/LANDSCAPE_1280" />
    Finał imprezy planowano w Paryżu na 24 sierpnia.

## Serbki odpowiedziały Polkom. Czas na trzeci set
 - [https://eurosport.tvn24.pl/siatkowka/mistrzostwa-europy/2023/live-polska-serbia_mtc1467070/live.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/mistrzostwa-europy/2023/live-polska-serbia_mtc1467070/live.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T15:54:00+00:00

<img alt="Serbki odpowiedziały Polkom. Czas na trzeci set" src="https://tvn24.pl/najnowsze/cdn-zdjecie-njt2gp-polki-graja-w-mistrzostwach-europy-7300940/alternates/LANDSCAPE_1280" />
    Relacja i wynik na żywo w eurosport.pl.

## Karambol pod Olsztynem. Wśród poszkodowanych są dzieci
 - [https://tvn24.pl/pomorze/wojtowo-kolo-olsztyna-karambol-pieciu-samochodow-na-s16-wsrod-poszkodowanych-sa-dzieci-7301114?source=rss](https://tvn24.pl/pomorze/wojtowo-kolo-olsztyna-karambol-pieciu-samochodow-na-s16-wsrod-poszkodowanych-sa-dzieci-7301114?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T15:37:28+00:00

<img alt="Karambol pod Olsztynem. Wśród poszkodowanych są dzieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ky9ahn-21-1730-wojtowo-wypadek-0038-7301197/alternates/LANDSCAPE_1280" />
    W okolicach miejscowości Wójtowo na drodze S16.

## Kaczyński o Somalijczykach w Finlandii. "Ta narracja nie jest na temat liczb"
 - [https://konkret24.tvn24.pl/polityka/jaroslaw-kaczynski-o-somalijczykach-w-finlandii-ta-narracja-nie-jest-na-temat-liczb-st7297393?source=rss](https://konkret24.tvn24.pl/polityka/jaroslaw-kaczynski-o-somalijczykach-w-finlandii-ta-narracja-nie-jest-na-temat-liczb-st7297393?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T15:28:34+00:00

<img alt="Kaczyński o Somalijczykach w Finlandii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-np8jud-jaroslaw-kaczynski-znowu-mowil-o-somalijczykach-w-finlandii-7297250/alternates/LANDSCAPE_1280" />
    W antyimigracyjnej narracji PiS powtarza, co mówił przed laty, znowu pomijając kontekst.

## Nie żyje 87-latka przytrzaśnięta przez drzwi autobusu
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-zmarla-emerytka-przytrzasnieta-przez-drzwi-autobusu-sledztwo-7301110?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-zmarla-emerytka-przytrzasnieta-przez-drzwi-autobusu-sledztwo-7301110?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T15:17:00+00:00

<img alt="Nie żyje 87-latka przytrzaśnięta przez drzwi autobusu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-d4dzyy-kobieta-zostala-przytrzasnieta-przez-drzwi-autobusu-zdjecie-ilustracyjne-7282920/alternates/LANDSCAPE_1280" />
    Trwa śledztwo, na razie nikomu nie postawiono zarzutów.

## Pytania do Emilewicz o posadę męża
 - [https://tvn24.pl/polska/maz-jadwigi-emilewicz-z-posada-w-orlen-asfalt-pytania-do-bylej-wicepremier-7301031?source=rss](https://tvn24.pl/polska/maz-jadwigi-emilewicz-z-posada-w-orlen-asfalt-pytania-do-bylej-wicepremier-7301031?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T15:05:04+00:00

<img alt="Pytania do Emilewicz o posadę męża" src="https://tvn24.pl/najnowsze/cdn-zdjecie-klqgiw-2108n130x-emilewicz-7300936/alternates/LANDSCAPE_1280" />
    Marcin Emilewicz dostał posadę w Orlen Asfalt.

## Odpoczniemy od spiekoty. Na jak długo? Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-weekend-upaly-w-polsce-czy-upaly-odpuszcza-7300976?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-weekend-upaly-w-polsce-czy-upaly-odpuszcza-7300976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T14:49:37+00:00

<img alt="Odpoczniemy od spiekoty. Na jak długo? Pogoda na 5 dni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-2hjl48-pogoda-upal-7301037/alternates/LANDSCAPE_1280" />
    Sprawdź, co nas czeka w kolejnych dniach w pogodzie.

## Prezes federacji w ogniu krytyki za pocałowanie piłkarki
 - [https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/luis-rubiales-prezydent-hiszpanskiej-federacji-krytykowany-przez-rzad-za-pocalunek-z-pilkarka-jennif_sto9752597/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/luis-rubiales-prezydent-hiszpanskiej-federacji-krytykowany-przez-rzad-za-pocalunek-z-pilkarka-jennif_sto9752597/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T14:22:35+00:00

<img alt="Prezes federacji w ogniu krytyki za pocałowanie piłkarki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-utcfkk-luis-rubiales-und-jennifer-hermoso-7301043/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło podczas ceremonii wręczenia medali po zdobyciu przez reprezentację Hiszpanii mistrzostwa świata.

## Kolejne wypożyczenie. Barcelona pozbyła się obrońcy
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/transfery-2023.-sergino-dest-wypozyczony-z-barcelony-do-psv_sto9752429/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/transfery-2023.-sergino-dest-wypozyczony-z-barcelony-do-psv_sto9752429/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T14:00:37+00:00

<img alt="Kolejne wypożyczenie. Barcelona pozbyła się obrońcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jrkxgo-sergino-dest-przenosi-sie-do-psv-7300988/alternates/LANDSCAPE_1280" />
    Amerykanin Sergino Dest wraca do Holandii.

## Samochody po zderzeniu stanęły w płomieniach. Jeden z kierowców nie żyje
 - [https://tvn24.pl/tvnwarszawa/ulice/podgorze-wypadek-smiertelny-utrudnienia-7300962?source=rss](https://tvn24.pl/tvnwarszawa/ulice/podgorze-wypadek-smiertelny-utrudnienia-7300962?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T14:00:03+00:00

<img alt="Samochody po zderzeniu stanęły w płomieniach. Jeden z kierowców nie żyje" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vq9qkf-wypadek-zdjecie-ilustracyjne-7145815/alternates/LANDSCAPE_1280" />
    Utrudnienia mogą potrwać jeszcze kilka godzin.

## Spędzili noc nad Morskim Okiem i rozpalili ognisko. Zapłacą wysoki mandat
 - [https://tvn24.pl/krakow/tatry-wysoki-mandat-za-biwak-z-ogniskiem-nad-morskim-okiem-7300977?source=rss](https://tvn24.pl/krakow/tatry-wysoki-mandat-za-biwak-z-ogniskiem-nad-morskim-okiem-7300977?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T13:56:39+00:00

<img alt="Spędzili noc nad Morskim Okiem i rozpalili ognisko. Zapłacą wysoki mandat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fopvsm-mezczyzni-zostali-ukarani-za-noc-spedzona-w-tatrach-pod-golym-niebem-7300958/alternates/LANDSCAPE_1280" />
    "Biwakowanie w Tatrzańskim Parku Narodowym jest bezwzględnie zabronione."

## "Skazana 3" niebawem w Playerze. "Zaskoczymy państwa"
 - [https://tvn24.pl/kultura-i-styl/skazana-3-kiedy-premiera-o-czym-trzeci-sezon-serialu-playera-7300619?source=rss](https://tvn24.pl/kultura-i-styl/skazana-3-kiedy-premiera-o-czym-trzeci-sezon-serialu-playera-7300619?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T13:51:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6n2xk2-skazana-3-7300634/alternates/LANDSCAPE_1280" />
    Czy postać grana przez Agatę Kuleszę wyjdzie z więzienia?

## Ciało 12-latka w osiedlowym stawie. Wybrał się tam na ryby
 - [https://tvn24.pl/krakow/tarnobrzeg-osiedle-sobow-12-latek-wyszedl-na-ryby-nie-zyje-7300957?source=rss](https://tvn24.pl/krakow/tarnobrzeg-osiedle-sobow-12-latek-wyszedl-na-ryby-nie-zyje-7300957?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T13:45:20+00:00

<img alt="Ciało 12-latka w osiedlowym stawie. Wybrał się tam na ryby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7kpwz7-tarnobrzeg-12-latek-zmarl-po-tym-jak-wyszedl-na-ryby-7300952/alternates/LANDSCAPE_1280" />
    Przechodnie zobaczyli go nieprzytomnego w wodzie.

## Półtorametrowy pyton pełzał nocą po ulicy
 - [https://tvn24.pl/poznan/poznan-rozana-poltora-metrowy-pyton-pelzal-noca-ulicami-wildy-7300532?source=rss](https://tvn24.pl/poznan/poznan-rozana-poltora-metrowy-pyton-pelzal-noca-ulicami-wildy-7300532?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T13:37:29+00:00

<img alt="Półtorametrowy pyton pełzał nocą po ulicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v1e6st-waz-na-ulicy-7300511/alternates/LANDSCAPE_1280" />
    Na miejsce wysłano patrol straży miejskiej.

## Napadli policjantkę w tramwaju. Mówili, że "nikt jej nie obroni"
 - [https://tvn24.pl/lodz/lodz-mezczyzna-i-kobieta-napadli-na-policjantke-grozi-im-do-pieciu-lat-wiezienia-7300768?source=rss](https://tvn24.pl/lodz/lodz-mezczyzna-i-kobieta-napadli-na-policjantke-grozi-im-do-pieciu-lat-wiezienia-7300768?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T13:11:20+00:00

<img alt="Napadli policjantkę w tramwaju. Mówili, że " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n7fo0f-zatrzymanym-grozi-do-pieciu-lat-wiezienia-7300813/alternates/LANDSCAPE_1280" />
    Grozili pozbawieniem życia. Kilka razy ją uderzyli.

## Niedrogie, malownicze i niezatłoczone. Miasta "poważnie niedoceniane" przez turystów
 - [https://tvn24.pl/biznes/turystyka/wakacje-2023-miasta-niedrogie-malownicze-i-powaznie-niedoceniane-przez-turystow-7300828?source=rss](https://tvn24.pl/biznes/turystyka/wakacje-2023-miasta-niedrogie-malownicze-i-powaznie-niedoceniane-przez-turystow-7300828?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T12:31:34+00:00

<img alt="Niedrogie, malownicze i niezatłoczone. Miasta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e7thrl-slowenia-lublana-shutterstock577244593-4671812/alternates/LANDSCAPE_1280" />
    Według portalu Euronews.

## "Sama Magdalena Ogórek, co mnie niepokoi, nie chce odpowiedzieć na żadne pytanie"
 - [https://tvn24.pl/polska/magdalena-ogorek-buduje-muzeum-za-dotacje-fundacji-spolek-z-udzialem-skarbu-panstwa-robert-zielinski-ogorek-nie-chce-odpowiedziec-na-zadne-pytanie-7300744?source=rss](https://tvn24.pl/polska/magdalena-ogorek-buduje-muzeum-za-dotacje-fundacji-spolek-z-udzialem-skarbu-panstwa-robert-zielinski-ogorek-nie-chce-odpowiedziec-na-zadne-pytanie-7300744?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T12:27:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vm9hp4-en_01566647_0732-7300890/alternates/LANDSCAPE_1280" />
    Dziennikarz tvn24.pl Robert Zieliński o budowie muzeum przez fundację Magdaleny Ogórek za dotacje fundacji spółek z udziałem skarbu państwa.

## Awantura w tramwaju. Mężczyźni mieli ubliżać cudzoziemcowi. Szuka ich policja
 - [https://tvn24.pl/krakow/krakow-atak-na-obcokrajowca-w-tramwaju-policja-szuka-sprawcow-i-publikuje-wizerunki-nagrane-przez-monitoring-7300764?source=rss](https://tvn24.pl/krakow/krakow-atak-na-obcokrajowca-w-tramwaju-policja-szuka-sprawcow-i-publikuje-wizerunki-nagrane-przez-monitoring-7300764?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T12:12:58+00:00

<img alt="Awantura w tramwaju. Mężczyźni mieli ubliżać cudzoziemcowi. Szuka ich policja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5o7u0x-policja-szuka-sprawcow-zniewazenia-mezczyzny-z-powodu-jego-przynaleznosci-narodowej-7300734/alternates/LANDSCAPE_1280" />
    Mundurowi opublikowali ich wizerunki.

## Ludzie wchodzą do tego ogrodu i mdleją
 - [https://tvn24.pl/tvnmeteo/ciekawostki/wielka-brytania-alnwick-garden-trujacy-ogrod-ludzie-wchodza-do-niego-i-mdleja-7300569?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/wielka-brytania-alnwick-garden-trujacy-ogrod-ludzie-wchodza-do-niego-i-mdleja-7300569?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:55:22+00:00

<img alt="Ludzie wchodzą do tego ogrodu i mdleją" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-4cf0y4-trujacy-ogrod-w-wielkiej-brytanii-7300667/alternates/LANDSCAPE_1280" />
    Jest domem dla około 100 gatunków szkodliwych roślin.

## Dwie kawy i woda za prawie 300 zł, opłata za przekrojenie kanapki
 - [https://tvn24.pl/swiat/wakacje-2023-wlochy-rekordowe-ceny-w-kurortach-i-na-plazach-oplaty-nawet-za-pusty-talerz-7300690?source=rss](https://tvn24.pl/swiat/wakacje-2023-wlochy-rekordowe-ceny-w-kurortach-i-na-plazach-oplaty-nawet-za-pusty-talerz-7300690?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:55:02+00:00

<img alt="Dwie kawy i woda za prawie 300 zł, opłata za przekrojenie kanapki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ii8w8o-plaza-wlochy-apulia-shutterstock_775307140-7170636/alternates/LANDSCAPE_1280" />
    Drożyzna w słynnych kurortach.

## "Dziecko? Nie, dziękuję". Mówią, dlaczego nie zmienią zdania
 - [https://tvn24.pl/go/programy,7/kobiecy-punkt-widzenia--odcinki,511634/odcinek-54,S00E54,1042749?source=rss](https://tvn24.pl/go/programy,7/kobiecy-punkt-widzenia--odcinki,511634/odcinek-54,S00E54,1042749?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:42:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ki859k-kobiecy-punkt-widzenia-6901289/alternates/LANDSCAPE_1280" />
    W ciągu pięciu lat grupa kobiet, które nie mają i nie planują mieć dzieci wzrosła z 22 do 42 procent.

## "Powiedział, że idzie do Płocka"
 - [https://tvn24.pl/poznan/sulecin-pijany-spacerowal-autostrada-a2-przysiadl-na-barierce-7300446?source=rss](https://tvn24.pl/poznan/sulecin-pijany-spacerowal-autostrada-a2-przysiadl-na-barierce-7300446?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:29:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t3qtx4-autostrada-noc-7300431/alternates/LANDSCAPE_1280" />
    Pijany na A2.

## Kolejne zmiany w "Dzień Dobry TVN"
 - [https://tvn24.pl/kultura-i-styl/dzien-dobry-tvn-zmiany-od-28-sierpnia-2023-kto-poprowadzi-program-jak-wyglada-nowe-studio-7300316?source=rss](https://tvn24.pl/kultura-i-styl/dzien-dobry-tvn-zmiany-od-28-sierpnia-2023-kto-poprowadzi-program-jak-wyglada-nowe-studio-7300316?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:25:22+00:00

<img alt="Kolejne zmiany w " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z4hld-dzien-dobry-tvn-7300610/alternates/LANDSCAPE_1280" />
    Kto poprowadzi program? Kiedy pierwszy odcinek z nowego studia?

## Tusk zaprasza Kaczyńskiego na debatę. "Drogi Jarosławie, nie ma się co bać"
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-donald-tusk-zaprasza-jaroslawa-kaczynskiego-do-debaty-7300598?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-donald-tusk-zaprasza-jaroslawa-kaczynskiego-do-debaty-7300598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T11:18:50+00:00

<img alt="Tusk zaprasza Kaczyńskiego na debatę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vgti6e-donald-tusk-7298264/alternates/LANDSCAPE_1280" />
    - Godzinka debaty i po bólu - powiedział na nagraniu lider PO.

## Samochód spadł do rzeki, zginęli rodzice znanego prezentera
 - [https://tvn24.pl/kultura-i-styl/wielka-brytania-samochod-spadl-do-rzeki-nie-zyje-malzenstwo-z-blisko-60-letnim-stazem-7300341?source=rss](https://tvn24.pl/kultura-i-styl/wielka-brytania-samochod-spadl-do-rzeki-nie-zyje-malzenstwo-z-blisko-60-letnim-stazem-7300341?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:47:34+00:00

<img alt="Samochód spadł do rzeki, zginęli rodzice znanego prezentera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l27ewq-igphilspencertv-7300462/alternates/LANDSCAPE_1280" />
    O tragicznym wypadku poinformował w mediach społecznościowych syn pary Phil Spencer.

## Jarosław Kaczyński podał, ile ma wynieść "14. emerytura". Ale jest haczyk
 - [https://tvn24.pl/biznes/dla-seniora/14-emerytura-2023-netto-i-brutto-kiedy-wyplata-7300282?source=rss](https://tvn24.pl/biznes/dla-seniora/14-emerytura-2023-netto-i-brutto-kiedy-wyplata-7300282?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:43:01+00:00

<img alt="Jarosław Kaczyński podał, ile ma wynieść " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-9wlot-jaroslaw-kaczynski-7300528/alternates/LANDSCAPE_1280" />
    Wyjaśniamy.

## "Piloci tego śmigłowca złamali elementarne zasady bezpieczeństwa"
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zerwal-linie-energetyczna-lasek-piloci-zlamali-elementarne-zasady-7300545?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zerwal-linie-energetyczna-lasek-piloci-zlamali-elementarne-zasady-7300545?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:42:41+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s0wdu8-incydent-z-black-hawkiem-na-nagraniu-7300372/alternates/LANDSCAPE_1280" />
    Posłowie KO skomentowali w Sejmie incydent z udziałem policyjnego Black Hawka.

## Kołodziejczak: żyć dobrze z USA i Unią Europejską i mieć tam coś do powiedzenia to nasza racja stanu
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-michal-kolodziejczak-zyc-dobrze-z-usa-i-unia-europejska-to-nasza-racja-stanu-7300428?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-michal-kolodziejczak-zyc-dobrze-z-usa-i-unia-europejska-to-nasza-racja-stanu-7300428?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:27:20+00:00

<img alt="Kołodziejczak: żyć dobrze z USA i Unią Europejską i mieć tam coś do powiedzenia to nasza racja stanu" src="https://tvn24.pl/polska/cdn-zdjecie-vin6lo-michal-kolodziejczak-na-konferencji-7300437/alternates/LANDSCAPE_1280" />
    Konferencja lidera Agrounii.

## Kierowcy zawracali korytarzem życia. Wyjątkowo zgodnie z prawem. Nagranie
 - [https://tvn24.pl/krakow/s7-kielce-warszawa-po-wypadku-kierowcy-jechali-pod-prad-korytarzem-zycia-komentarz-policji-nagranie-7300452?source=rss](https://tvn24.pl/krakow/s7-kielce-warszawa-po-wypadku-kierowcy-jechali-pod-prad-korytarzem-zycia-komentarz-policji-nagranie-7300452?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:26:44+00:00

<img alt="Kierowcy zawracali korytarzem życia. Wyjątkowo zgodnie z prawem. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-doxs1i-kierowcy-jechali-korytarzem-zycia-po-wypadku-na-trasie-s7-pod-kielcami-7300408/alternates/LANDSCAPE_1280" />
    Film otrzymaliśmy na Kontakt 24.

## Sinice w Polsce. Zamknięte kąpieliska na terenie kraju
 - [https://tvn24.pl/pomorze/sinice-w-polsce-2023-mapa-kapieliska-i-plaze-nad-jeziorami-zamkniete-22082023-7201784?source=rss](https://tvn24.pl/pomorze/sinice-w-polsce-2023-mapa-kapieliska-i-plaze-nad-jeziorami-zamkniete-22082023-7201784?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T10:03:00+00:00

<img alt="Sinice w Polsce. Zamknięte kąpieliska na terenie kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ft4s24-baltyk-sinice-6086525/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie nie można się kąpać.

## Sopot gotowy na muzyczne święto. Cztery niezwykłe koncerty i plejada gwiazd
 - [https://tvn24.pl/pomorze/top-sopot-festival-2023-ostatnie-przygotowanie-start-juz-w-poniedzialek-7300383?source=rss](https://tvn24.pl/pomorze/top-sopot-festival-2023-ostatnie-przygotowanie-start-juz-w-poniedzialek-7300383?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:55:50+00:00

<img alt="Sopot gotowy na muzyczne święto. Cztery niezwykłe koncerty i plejada gwiazd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5amos-trwaja-ostatnie-przygotowania-7300423/alternates/LANDSCAPE_1280" />
    Rusza Top of the top Sopot Festival 2023.

## Raper Drake łapie w locie rzucony na scenę przedmiot
 - [https://tvn24.pl/kultura-i-styl/drake-w-rapera-rzucono-ksiazka-kolejny-incydent-z-rzucanymi-na-scene-przedmiotami-7300346?source=rss](https://tvn24.pl/kultura-i-styl/drake-w-rapera-rzucono-ksiazka-kolejny-incydent-z-rzucanymi-na-scene-przedmiotami-7300346?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:55:23+00:00

<img alt="Raper Drake łapie w locie rzucony na scenę przedmiot" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tiifmb-raper-drake-podczas-koncertu-7300469/alternates/LANDSCAPE_1280" />
    "To musi się skończyć".

## Lewandowski krytykowany
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-krytykowany-po-meczu-barcelona-cadiz_sto9752317/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-krytykowany-po-meczu-barcelona-cadiz_sto9752317/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:45:51+00:00

<img alt="Lewandowski krytykowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qpag1j-robert-lewandowski-krytykowany-po-meczu-barcelona-cadiz-7300457/alternates/LANDSCAPE_1280" />
    Hiszpanie o możliwej zmianie króla strzelców.

## Cofał na A4. Ugryzł innego kierowcę
 - [https://tvn24.pl/wroclaw/krapkowice-cofal-na-autostradzie-a4-doprowadzil-do-kolizji-i-ugryzl-kierowce-w-ktorego-auto-uderzyl-7300453?source=rss](https://tvn24.pl/wroclaw/krapkowice-cofal-na-autostradzie-a4-doprowadzil-do-kolizji-i-ugryzl-kierowce-w-ktorego-auto-uderzyl-7300453?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:45:04+00:00

<img alt="Cofał na A4. Ugryzł innego kierowcę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rypva8-cofal-na-a4-doprowadzil-do-kolizji-i-ugryzl-kierowce-w-ktorego-auto-uderzyl-7300404/alternates/LANDSCAPE_1280" />
    30-latek tłumaczył się policjantom "przemęczeniem, złym samopoczuciem z uwagi na panujący upał i szokiem".

## Rośnie fala upadłości firm
 - [https://tvn24.pl/biznes/dlafirm/gospodarka-ue-bankructwa-przedsiebiorstw-w-unii-europejskiej-na-najwyzszym-poziomie-od-2015-roku-7300367?source=rss](https://tvn24.pl/biznes/dlafirm/gospodarka-ue-bankructwa-przedsiebiorstw-w-unii-europejskiej-na-najwyzszym-poziomie-od-2015-roku-7300367?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:35:38+00:00

<img alt="Rośnie fala upadłości firm" src="https://tvn24.pl/najnowsze/cdn-zdjecie-spim2g-gastronomia-restauracja-shutterstock522191554-6136969/alternates/LANDSCAPE_1280" />
    Dane Eurostatu.

## Groźna bakteria w koktajlu mlecznym. Nie żyją trzy osoby
 - [https://tvn24.pl/swiat/usa-listerioza-w-lokalu-fast-food-nie-zyja-3-osoby-wypily-koktajl-mleczny-z-bakteria-7300180?source=rss](https://tvn24.pl/swiat/usa-listerioza-w-lokalu-fast-food-nie-zyja-3-osoby-wypily-koktajl-mleczny-z-bakteria-7300180?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:22:53+00:00

<img alt="Groźna bakteria w koktajlu mlecznym. Nie żyją trzy osoby" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9t40dr-bakteria-listeria-monocytogenes-6216600/alternates/LANDSCAPE_1280" />
    Wszystkie zatrucia łączone są z jedną restauracją typu fast food.

## Kolejne nagranie z Black Hawkiem. "Uciekamy, chodźcie!"
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-nagranie-7300273?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-nagranie-7300273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:14:38+00:00

<img alt="Kolejne nagranie z Black Hawkiem. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7yijpm-incydent-z-black-hawkiem-na-nagraniu-7300373/alternates/LANDSCAPE_1280" />
    Na pikniku obecny był między innymi wiceminister spraw wewnętrznych i administracji.

## Nowe nagrania z Black Hawkiem. Widać moment zerwania linii energetycznej
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zerwal-linie-energetyczna-nowe-nagranie-7300273?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zerwal-linie-energetyczna-nowe-nagranie-7300273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:14:38+00:00

<img alt="Nowe nagrania z Black Hawkiem. Widać moment zerwania linii energetycznej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cvp9ep-policyjny-black-hawk-na-pikniku-pod-sarnowa-gora-moment-przerwania-linii-energetycznej-na-nagraniu-7300965/alternates/LANDSCAPE_1280" />
    Na pikniku obecny był między innymi wiceminister spraw wewnętrznych i administracji.

## Dwoje dzieci w rozgrzanym aucie. Matka poszła do solarium
 - [https://tvn24.pl/tvnwarszawa/najnowsze/plock-dwoje-dzieci-w-rozgrzanym-aucie-matka-poszla-na-solarium-7300194?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/plock-dwoje-dzieci-w-rozgrzanym-aucie-matka-poszla-na-solarium-7300194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:11:46+00:00

<img alt="Dwoje dzieci w rozgrzanym aucie. Matka poszła do solarium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l0tojk-dziecko-w-rozgrzanym-aucie-zdj-ilustracyjne-7138269/alternates/LANDSCAPE_1280" />
    Na dodatek auto było zaparkowane na zakazie. Kobieta była zdziwiona interwencją.

## Panowanie trwa, presja rośnie
 - [https://eurosport.tvn24.pl/tenis/us-open/2023/ranking-wta-21-sieprnia-2023.-jaka-jest-przewaga-igi-swiatek-nad-aryna-sabalenka_sto9752281/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/us-open/2023/ranking-wta-21-sieprnia-2023.-jaka-jest-przewaga-igi-swiatek-nad-aryna-sabalenka_sto9752281/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T09:06:06+00:00

<img alt="Panowanie trwa, presja rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4xqbpa-iga-swiatek-i-aryna-sabalenka-walcza-o-pozycje-numer-jeden-7300370/alternates/LANDSCAPE_1280" />
    Scenariusze walki Świątek o numer 1 po US Open.

## Czy Polacy odczuwają spadek inflacji? Wyniki sondażu
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-wiekszosc-badanych-nie-odczuwa-spadku-inflacji-7300134?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-wiekszosc-badanych-nie-odczuwa-spadku-inflacji-7300134?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:54:01+00:00

<img alt="Czy Polacy odczuwają spadek inflacji? Wyniki sondażu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ebma17-inflacja-zakupy-sklep-koszyk-drozyzna-6645013/alternates/LANDSCAPE_1280" />
    Spadek tempa wzrostu inflacji oznacza, że ceny nadal rosną rok do roku, ale w wolniejszym tempie.

## Sześć twierdzeń PiS o relokacji migrantów, które wprowadzają w błąd
 - [https://konkret24.tvn24.pl/polityka/kryzys-migracyjny-szesc-twierdzen-pis-o-relokacji-migrantow-ktore-wprowadzaja-w-blad-st7295663?source=rss](https://konkret24.tvn24.pl/polityka/kryzys-migracyjny-szesc-twierdzen-pis-o-relokacji-migrantow-ktore-wprowadzaja-w-blad-st7295663?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:45:45+00:00

<img alt="Sześć twierdzeń PiS o relokacji migrantów, które wprowadzają w błąd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-alrp2c-jak-pis-manipuluje-tematem-migracji-i-relokacji-migrantow-7153898/alternates/LANDSCAPE_1280" />
    W samym pytaniu referendalnym dotyczącym relokacji migrantów są trzy nieprawdy, które manipulują opinią publiczną.

## Najnowsze dane z przemysłu
 - [https://tvn24.pl/biznes/z-kraju/produkcja-przemyslowa-w-lipcu-2023-roku-dane-gus-7300065?source=rss](https://tvn24.pl/biznes/z-kraju/produkcja-przemyslowa-w-lipcu-2023-roku-dane-gus-7300065?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:37:11+00:00

<img alt="Najnowsze dane z przemysłu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-388kzq-fabryka-przemysl-shutterstock761907061-5772063/alternates/LANDSCAPE_1280" />
    "Trzeci kwartał zaczyna się źle".

## Trzy śledztwa ws. afery mailowej. "Wyborcza": jedno może doprowadzić do postawienia zarzutów premierowi
 - [https://tvn24.pl/polska/afera-mailowa-rzadu-pis-trzy-sledztwa-jedno-moze-doprowadzic-do-postawienia-zarzutow-premierowi-wyborcza-7300100?source=rss](https://tvn24.pl/polska/afera-mailowa-rzadu-pis-trzy-sledztwa-jedno-moze-doprowadzic-do-postawienia-zarzutow-premierowi-wyborcza-7300100?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:16:22+00:00

<img alt="Trzy śledztwa ws. afery mailowej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-or7brl-forum-0557893291-1-7300188/alternates/LANDSCAPE_1280" />
    Śledztwa po wycieku maili ze skrzynki Michała Dworczyka.

## Incydent z Black Hawkiem na pikniku. "Pilna interwencja" do premiera
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-interwencja-krzysztofa-brejzy-do-premiera-7300184?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-interwencja-krzysztofa-brejzy-do-premiera-7300184?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:14:26+00:00

<img alt="Incydent z Black Hawkiem na pikniku. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-js5mtb-16-7300251/alternates/LANDSCAPE_1280" />
    Siedem pytań do Mateusza Morawieckiego.

## Samochód uderzył w drzewo. Nie żyje dwóch 21-latków
 - [https://tvn24.pl/pomorze/rybno-dwoch-mlodych-mezczyzn-zginelo-w-wypadku-7300172?source=rss](https://tvn24.pl/pomorze/rybno-dwoch-mlodych-mezczyzn-zginelo-w-wypadku-7300172?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:10:18+00:00

<img alt="Samochód uderzył w drzewo. Nie żyje dwóch 21-latków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l14dwq-w-wypadku-zginelo-dwoch-21-latkow-7300161/alternates/LANDSCAPE_1280" />
    Do wypadku doszło pod Mrągowem (Warmińsko-Mazurskie).

## "Dziwaczny atak" siekierą na szlaban na parkingu lotniska. Pilot z zarzutami
 - [https://tvn24.pl/swiat/usa-pilot-siekiera-zniszczyl-szlaban-na-parkingu-w-denver-7300082?source=rss](https://tvn24.pl/swiat/usa-pilot-siekiera-zniszczyl-szlaban-na-parkingu-w-denver-7300082?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:07:04+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4970aa-pilot-zniszczyl-szlaban-na-parkingu-przed-lotniskiem-7300105/alternates/LANDSCAPE_1280" />
    Zeznał, że awaria doprowadziła go do "punktu krytycznego".

## Tyle wyniosły przeciętne zarobki w lipcu
 - [https://tvn24.pl/biznes/dla-pracownika/przecietne-wynagrodzenie-brutto-lipiec-2023-gus-podal-nowe-dane-7300098?source=rss](https://tvn24.pl/biznes/dla-pracownika/przecietne-wynagrodzenie-brutto-lipiec-2023-gus-podal-nowe-dane-7300098?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T08:01:57+00:00

<img alt="Tyle wyniosły przeciętne zarobki w lipcu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gvzi95-pilne-5496805/alternates/LANDSCAPE_1280" />
    Nowe dane GUS.

## "W lodówce marketu spożywczego znajduje się wąż". Akcja strażaków
 - [https://tvn24.pl/wroclaw/kedzierzyn-kozle-waz-w-supermarkecie-akcja-strazy-pozarnej-7300173?source=rss](https://tvn24.pl/wroclaw/kedzierzyn-kozle-waz-w-supermarkecie-akcja-strazy-pozarnej-7300173?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T07:39:24+00:00

<img alt=" " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aqeage-kedzierzyn-kozle-waz-w-supermarkecie-akcja-strazy-pozarnej-7300168/alternates/LANDSCAPE_1280" />
    W Kędzierzynie-Koźlu (woj. opolskie).

## Niemowlak zostawiony w zamkniętym i nagrzanym samochodzie. Zarzuty dla ojca
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-niemowlak-zostawiony-w-zamknietym-i-nagrzanym-samochodzie-zarzuty-dla-ojca-7300114?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-niemowlak-zostawiony-w-zamknietym-i-nagrzanym-samochodzie-zarzuty-dla-ojca-7300114?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T07:36:24+00:00

<img alt="Niemowlak zostawiony w zamkniętym i nagrzanym samochodzie. Zarzuty dla ojca " src="https://tvn24.pl/najnowsze/cdn-zdjecie-j4pxct-termometr-na-desce-rozdzielczej-pokazal-ponad-50-stopni-celsjusza-7228988/alternates/LANDSCAPE_1280" />
    Dziecko uratowali przechodnie, którym udało się otworzyć drzwi auta.

## Właścicielka sklepu zastrzelona z powodu tęczowej flagi. Była matką dziewięciorga dzieci
 - [https://tvn24.pl/swiat/usa-laura-ann-carleton-zastrzelona-z-powodu-wywieszonej-przed-jej-sklepem-teczowej-flagi-7300073?source=rss](https://tvn24.pl/swiat/usa-laura-ann-carleton-zastrzelona-z-powodu-wywieszonej-przed-jej-sklepem-teczowej-flagi-7300073?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T07:23:47+00:00

<img alt="Właścicielka sklepu zastrzelona z powodu tęczowej flagi. Była matką dziewięciorga dzieci" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-wl6ous-teczowa-flaga-symbolizujaca-spolecznosci-lgbt-50088/alternates/LANDSCAPE_1280" />
    Przed oddaniem strzału napastnik "wygłosił kilka lekceważących uwag".

## Zaskakujące dane z Niemiec. "Deflacja!"
 - [https://tvn24.pl/biznes/ze-swiata/niemcy-inflacja-producencka-ppi-w-lipcu-odnotowano-najwiekszy-spadek-od-blisko-14-lat-nowe-dane-destatis-7300059?source=rss](https://tvn24.pl/biznes/ze-swiata/niemcy-inflacja-producencka-ppi-w-lipcu-odnotowano-najwiekszy-spadek-od-blisko-14-lat-nowe-dane-destatis-7300059?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:50:13+00:00

<img alt="Zaskakujące dane z Niemiec. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-83r889-berlin-niemcy-hanohiki-shutterstock_1109014418-7245973/alternates/LANDSCAPE_1280" />
    Spadek cen jest większy niż oczekiwano.

## "Musiałem wszystko postawić na pierwszy rzut, bo skręciłem kostkę"
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/pawel-fajdek-skomentowal-czwarte-miejsce-w-mistrzostwach-swiata-w-budapeszcie_sto9752254/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/pawel-fajdek-skomentowal-czwarte-miejsce-w-mistrzostwach-swiata-w-budapeszcie_sto9752254/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:49:59+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9j9upw-pawel-fajdek-tym-razem-bez-medalu-mistrzostw-swiata-7300101/alternates/LANDSCAPE_1280" />
    Paweł Fajdek w rozmowie z Eurosportem.

## Tancerki go-go, kelnerki i kierowniczki. 20 osób zatrzymanych za wyłudzanie fortun od klientów lokali
 - [https://tvn24.pl/krakow/wyludzenia-pieniedzy-od-klientow-klubow-go-go-cbsp-zatrzymalo-kolejnych-20-osob-7300070?source=rss](https://tvn24.pl/krakow/wyludzenia-pieniedzy-od-klientow-klubow-go-go-cbsp-zatrzymalo-kolejnych-20-osob-7300070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:39:07+00:00

<img alt="Tancerki go-go, kelnerki i kierowniczki. 20 osób zatrzymanych za wyłudzanie fortun od klientów lokali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n0xl8o-w-sledztwie-jest-juz-lacznie-129-podejrzanych-7300054/alternates/LANDSCAPE_1280" />
    Jeden z klientów stracił ponad 190 tysięcy złotych.

## Tysiące nieruchomości w rękach Watykanu. Podano dane
 - [https://tvn24.pl/biznes/ze-swiata/watykan-ponad-cztery-tysiace-nieruchomosci-nalezy-do-stolicy-apostolskiej-7300028?source=rss](https://tvn24.pl/biznes/ze-swiata/watykan-ponad-cztery-tysiace-nieruchomosci-nalezy-do-stolicy-apostolskiej-7300028?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:23:56+00:00

<img alt="Tysiące nieruchomości w rękach Watykanu. Podano dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a4qibu-watykan-5612241/alternates/LANDSCAPE_1280" />
    To przede wszystkim lokale przeznaczone na wynajem.

## Czekają nas dwie fale ochłodzenia. Pierwsza już nadciąga
 - [https://tvn24.pl/tvnmeteo/polska/pogoda-w-polsce-kiedy-bedzie-chlodniej-czekaja-nas-dwie-fale-ochlodzenia-7300021?source=rss](https://tvn24.pl/tvnmeteo/polska/pogoda-w-polsce-kiedy-bedzie-chlodniej-czekaja-nas-dwie-fale-ochlodzenia-7300021?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:09:22+00:00

<img alt="Czekają nas dwie fale ochłodzenia. Pierwsza już nadciąga" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-16r53s-idzie-ochlodzenie-7300041/alternates/LANDSCAPE_1280" />
    Tomasz Wasilewski o pogodzie na kolejne dni.

## "Doppelgänger. Sobowtór" Jana Holoubka na otwarcie 48. Festiwalu Polskich Filmów Fabularnych w Gdyni
 - [https://tvn24.pl/kultura-i-styl/doppelganger-sobowtor-jana-holoubka-na-otwarcie-48-festiwalu-polskich-filmow-fabularnych-w-gdyni-7299969?source=rss](https://tvn24.pl/kultura-i-styl/doppelganger-sobowtor-jana-holoubka-na-otwarcie-48-festiwalu-polskich-filmow-fabularnych-w-gdyni-7299969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:06:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aeoklz-kadr-z-filmu-doppelganger-sobowtor-7294921/alternates/LANDSCAPE_1280" />
    Producentem obrazu jest TVN Warner Bros. Discovery.

## "Po ośmiu latach rządów okazuje się, że emanacją imposybilizmu jest sam Kaczyński"
 - [https://tvn24.pl/polska/krajowy-plan-odbudowy-pieniadze-dla-polski-nadal-niewyplacone-izabela-leszczyna-komentuje-7300029?source=rss](https://tvn24.pl/polska/krajowy-plan-odbudowy-pieniadze-dla-polski-nadal-niewyplacone-izabela-leszczyna-komentuje-7300029?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T06:03:18+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e13mbo-1-na-1-7300024/alternates/LANDSCAPE_1280" />
    Izabela Leszczyna o nadal niewypłaconych Polsce środkach z KPO.

## Bohaterka finału mistrzostw świata nie świętowała. Tragiczna wiadomość po meczu
 - [https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/olga-carmona-dowiedziala-sie-o-smierci-ojca-po-finale-mistrzostw-swiata-kobiet-2023_sto9752243/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/mistrzostwa-swiata-kobiet/2023/olga-carmona-dowiedziala-sie-o-smierci-ojca-po-finale-mistrzostw-swiata-kobiet-2023_sto9752243/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:59:08+00:00

<img alt="Bohaterka finału mistrzostw świata nie świętowała. Tragiczna wiadomość po meczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ot8yqw-olga-carmona-byla-bohaterka-finalu-ms-7300042/alternates/LANDSCAPE_1280" />
    Olga Carmona strzeliła jedynego gola w finale mistrzostw świata kobiet.

## Kandydatka lewicy i potentat biznesowy zmierzą się w drugiej turze
 - [https://tvn24.pl/swiat/ekwador-wybory-prezydenckie-wyniki-kto-wygral-pierwsza-ture-7299972?source=rss](https://tvn24.pl/swiat/ekwador-wybory-prezydenckie-wyniki-kto-wygral-pierwsza-ture-7299972?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:55:09+00:00

<img alt="Kandydatka lewicy i potentat biznesowy zmierzą się w drugiej turze" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xtau1v-wybory-prezydenckie-w-ekwadorze-7299974/alternates/LANDSCAPE_1280" />
    Wybory prezydenckie w Ekwadorze.

## Urodziny Lewandowskiego. W tym wieku Messi wygrywał mundial, a Benzema Złotą Piłkę
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-konczy-35-lat_sto9752242/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-konczy-35-lat_sto9752242/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:44:32+00:00

<img alt="Urodziny Lewandowskiego. W tym wieku Messi wygrywał mundial, a Benzema Złotą Piłkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-edmwjq-robert-lewandowski-pozostaje-w-znakomitej-formie-7300030/alternates/LANDSCAPE_1280" />
    Kapitan reprezentacji Polski świętuje w poniedziałek 35. urodziny.

## "Pełna odpowiedzialność i poważne konsekwencje profanacji spoczywają na szwedzkim i duńskim rządzie"
 - [https://tvn24.pl/swiat/iran-charge-daffaires-szwecji-i-danii-wezwani-do-msz-7299967?source=rss](https://tvn24.pl/swiat/iran-charge-daffaires-szwecji-i-danii-wezwani-do-msz-7299967?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:27:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ypmpfn-gettyimages-1546734959-7300014/alternates/LANDSCAPE_1280" />
    Charge d'affaires Szwecji i Danii wezwani do MSZ Iranu.

## Zadyszka w gospodarce. Niepokojący trend
 - [https://tvn24.pl/biznes/dlafirm/gospodarka-polski-na-hamulcu-spowolnienie-gospodarcze-uderza-w-firmy-wiecej-firm-w-polsce-zawiesza-dzialalnosc-7300000?source=rss](https://tvn24.pl/biznes/dlafirm/gospodarka-polski-na-hamulcu-spowolnienie-gospodarcze-uderza-w-firmy-wiecej-firm-w-polsce-zawiesza-dzialalnosc-7300000?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:24:49+00:00

<img alt="Zadyszka w gospodarce. Niepokojący trend" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fj970p-budowa-praca-mieszkania-shutterstock_2024007179-5645852/alternates/LANDSCAPE_1280" />
    Oto branże, które cierpią najmocniej.

## Miliard złotych na 300 plus. "Przygotowywane są kolejne przelewy"
 - [https://tvn24.pl/biznes/pieniadze/300-plus-ile-pieniedzy-juz-wyplacono-jak-zlozyc-wniosek-dane-zus-7299999?source=rss](https://tvn24.pl/biznes/pieniadze/300-plus-ile-pieniedzy-juz-wyplacono-jak-zlozyc-wniosek-dane-zus-7299999?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:12:43+00:00

<img alt="Miliard złotych na 300 plus. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ebuxui-szkola-dziecko-plecak-rodzic-rodzice-corka-s-shutterstock1151079065-5203868/alternates/LANDSCAPE_1280" />
    Dane ZUS.

## Dokuczliwe gorąco i burze z gradem. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-upal-burze-z-gradem-pomaranczowe-i-zolte-ostrzezenia-7299983?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-upal-burze-z-gradem-pomaranczowe-i-zolte-ostrzezenia-7299983?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T05:08:25+00:00

<img alt="Dokuczliwe gorąco i burze z gradem. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ps7720-burzowo-pochmurno-bieszczady-7245284/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura może być groźna.

## Oczekiwanie na ważne dane
 - [https://tvn24.pl/biznes/z-kraju/nowe-dane-gus-wyniki-orlen-i-pko-bp-sympozjum-w-jackson-hole-w-usa-tydzien-w-gospodarce-7299985?source=rss](https://tvn24.pl/biznes/z-kraju/nowe-dane-gus-wyniki-orlen-i-pko-bp-sympozjum-w-jackson-hole-w-usa-tydzien-w-gospodarce-7299985?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T04:57:39+00:00

<img alt="Oczekiwanie na ważne dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xuqc8g-pap_20200912_2lv-7285130/alternates/LANDSCAPE_1280" />
    Co nas czeka w gospodarce w najbliższych dniach?

## Gdzie jest burza? Silnie grzmi i wieje od rana
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-2108-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7299978?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-2108-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7299978?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T04:20:21+00:00

<img alt="Gdzie jest burza? Silnie grzmi i wieje od rana" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5ii266-wyladowania-nad-polska-7299982/alternates/LANDSCAPE_1280" />
    Śledź aktualną sytuację pogodową w Polsce na tvnmeteo.pl.

## Cała nadzieja w biegaczach. Program trzeciego dnia mistrzostw świata w lekkoatletyce
 - [https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-program-3.-dnia-zawodow_sto9751996/story.shtml?source=rss](https://eurosport.tvn24.pl/lekkoatletyka/mistrzostwa-swiata/2023/mistrzostwa-swiata-w-lekkoatletyce-budapeszt-2023.-program-3.-dnia-zawodow_sto9751996/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T04:13:07+00:00

<img alt="Cała nadzieja w biegaczach. Program trzeciego dnia mistrzostw świata w lekkoatletyce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qpa9l2-natalia-kaczmarek-7299979/alternates/LANDSCAPE_1280" />
    Polska ma już pierwszy medal.

## Przywódca puczu zapowiedział przekazanie władzy cywilom
 - [https://tvn24.pl/swiat/niger-przywodca-puczu-przekazemy-wladze-rzadowi-cywilnemu-w-ciagu-trzech-lat-7299927?source=rss](https://tvn24.pl/swiat/niger-przywodca-puczu-przekazemy-wladze-rzadowi-cywilnemu-w-ciagu-trzech-lat-7299927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T04:05:36+00:00

<img alt="Przywódca puczu zapowiedział przekazanie władzy cywilom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uaslqc-niger-tysiace-zwolennikow-junty-wojskowej-demonstrowalo-w-stolicy-kraju-7299922/alternates/LANDSCAPE_1280" />
    W stolicy Nigru demonstrowało w niedzielę kilka tysięcy zwolenników junty wojskowej.

## Kim Dzong Un nadzorował testy. "Okręt trafił w cel"
 - [https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-nadzorowal-test-pociskow-manewrujacych-7299956?source=rss](https://tvn24.pl/swiat/korea-polnocna-kim-dzong-un-nadzorowal-test-pociskow-manewrujacych-7299956?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T03:58:06+00:00

<img alt="Kim Dzong Un nadzorował testy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5wki2a-korea-7299962/alternates/LANDSCAPE_1280" />
    Podała w poniedziałek rano czasu lokalnego rządowa agencja KCNA.

## Co wydarzyło się w Ukrainie w ciągu ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-21-sierpnia-2023-7299968?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-21-sierpnia-2023-7299968?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T03:52:34+00:00

<img alt="Co wydarzyło się w Ukrainie w ciągu ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ce1ux-zelenski-w-holandii-zaprezentowano-mu-f-16-7299578/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja trwa od 544 dni.

## Zawieszone loty na moskiewskich lotniskach
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-poniedzialek-21-sierpnia-2023-roku-7299929?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-poniedzialek-21-sierpnia-2023-roku-7299929?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T03:18:17+00:00

<img alt="Zawieszone loty na moskiewskich lotniskach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-byzoy3-domodedovo-airport-7300049/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Cierpiał, prosił lekarza o pomoc, aż wygrał
 - [https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/carlos-alcaraz-novak-djokovic-wynik-i-relacja-final-turnieju-w-cinncinati-tenis_sto9752151/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/atp-cincinnati/2023/carlos-alcaraz-novak-djokovic-wynik-i-relacja-final-turnieju-w-cinncinati-tenis_sto9752151/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-08-21T00:37:11+00:00

<img alt="Cierpiał, prosił lekarza o pomoc, aż wygrał" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1pd4mp-novak-djokovic-7299930/alternates/LANDSCAPE_1280" />
    Novak Djoković królem Cincinnati, pokonał lidera rankingu ATP Carlosa Alcaraza po kosmicznym meczu.

