# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Pioneering wind-powered cargo ship sets sail
 - [https://www.bbc.co.uk/news/technology-66543643?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66543643?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-08-21T05:20:05+00:00

Inventors hope maiden voyage will help usher in new era of greener shipping.

