# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Ford’s Mustang Mach-E recall to prevent power failures is under investigation
 - [https://www.theverge.com/2023/8/21/23840346/ford-mustang-mach-e-power-failure-recall-nhtsa](https://www.theverge.com/2023/8/21/23840346/ford-mustang-mach-e-power-failure-recall-nhtsa)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T22:58:02+00:00

<figure>
      <img alt="Ford Mustang Mach-E" src="https://cdn.vox-cdn.com/thumbor/uWN8vSP1Q-JQf6DoSRquB-KbF9w=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72565095/sokane_210125_4386_0025.0.jpg" />
        <figcaption>Photo by Sean O’Kane / The Verge</figcaption>
    </figure>

  <p id="mWmISk">The National Highway Traffic and Safety Administration (NHTSA) is opening a query on Ford’s response to a recall last year that affected almost 49,000 Mustang Mach-E vehicles, <a href="https://www.autonews.com/automakers-suppliers/nhtsa-probes-fords-recall-2021-22-mustang-mach-es">as reported by <em>Automotive News</em></a>. The <a href="https://www.theverge.com/2022/6/14/23167399/ford-mustang-mache-stop-sale-dealers-defect">June 2022 recall</a> was issued due to a malfunction involving overheating of the electric SUV’s high-voltage contactors, which, at worst, can make the EV suddenly lose power on the road, increasing the risk of a crash. </p>
<p id="dChj8G">Occurances would often follow high-speed battery charging or repeated fast acceleration sessions.</p>
<p id="S1bam6">Ford issued an over-the-air (OTA) software update to respond to the recall, which was designed to reduce power if the contactors got too hot — in hopes of preventing sudden power loss and possible damage to the contacts....</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840346/ford-mustang-mach-e-power-failure-recall-nhtsa">Continue reading&hellip;</a>
  </p>

## The New York Times blocks OpenAI’s web crawler
 - [https://www.theverge.com/2023/8/21/23840705/new-york-times-openai-web-crawler-ai-gpt](https://www.theverge.com/2023/8/21/23840705/new-york-times-openai-web-crawler-ai-gpt)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T22:04:37+00:00

<figure>
      <img alt="An illustration of a cartoon brain with a computer chip imposed on top." src="https://cdn.vox-cdn.com/thumbor/btsyx34NJYWiQ7f9X4P5J2sWmyI=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564965/acastro_181017_1777_brain_ai_0002.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="rmeyrg"><em>The New York Times</em> has blocked OpenAI’s web crawler, meaning that OpenAI can’t use content from the publication to train its AI models. If you check <a href="https://www.nytimes.com/robots.txt">the <em>NYT’s</em> robots.txt page</a>, you can see that the <em>NYT</em> disallows GPTBot, the crawler that OpenAI introduced <a href="https://www.theverge.com/2023/8/7/23823046/openai-data-scrape-block-ai">earlier this month</a>. Based on the Internet Archive’s Wayback Machine, it appears <em>NYT</em> blocked the crawler as early as August 17th.</p>
<div class="c-float-left c-float-hang">  <figure class="e-image">
        
      <cite>Screenshot by Jay Peters / The Verge</cite>
      <figcaption>
<em>A snippet of the </em>NYT’s<em> </em><a class="ql-link" href="https://www.nytimes.com/robots.txt" target="_blank"><em>robots.txt</em></a><em> showing that the company has disallowed GPTBot.</em>
</figcaption>
  </figure>
</div>
<p id="qPHdQZ">The change comes after the <em>NYT</em> updated its terms of service at the beginning of this month to prohibit the use of its content <a href="https://www.theverge.com/2023/8/14/23831109/the-new-york-times-ai-web-scraping-rules-terms-of-service">to train AI models</a>. The <em>NYT</em> and OpenAI didn’t immediately reply to a request for comment....</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840705/new-york-times-openai-web-crawler-ai-gpt">Continue reading&hellip;</a>
  </p>

## Tell every PC gamer you know: Dough, formerly Eve, is ready to issue refunds
 - [https://www.theverge.com/2023/8/21/22825700/dough-eve-refunds-retail-brand-perception-spectrum-v-tablet](https://www.theverge.com/2023/8/21/22825700/dough-eve-refunds-retail-brand-perception-spectrum-v-tablet)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T21:55:56+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/Dx7OG15lY_10P4bC4YAQItXwmWk=/292x45:2648x1616/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564907/EVE_Spectrum_desk.0.jpg" />
        <figcaption><em>Eve’s promised products, circa 2020.</em> | Image: Eve</figcaption>
    </figure>

  <p id="0UBhfk">Every time I write about Dough — the PC gaming monitor company <a href="https://www.theverge.com/2022/7/23/23274889/eve-dough-name-change-spectrum-monitor-eve-v-tablet">formerly known as Eve</a> — some people tell me to stop! They say Dough scammed them out of money or shipped their monitors too late to matter or ghosted their attempts to get customer support.</p>
<p id="uuanoN">Today, I’m here to tell you about an opportunity and a promise. </p>
<p id="pDf1aF"><strong>The opportunity: </strong>Dough now wants to fix its bad reputation. The company now claims that if you fill out <a href="https://forms.office.com/pages/responsepage.aspx?id=8-ZaFu_Z-UeO6bGhhFAtqavS7Tgc01pCtbGOxJ-dRX9UMUJTME01T01VQ1BWTDFUMkU0VlVBUTEzRC4u">this Customer Issue Resolution Form</a>, you can get your refund or other kinds of help <em>fast</em>. Dough tells <em>The Verge</em> it’s already issued 25,000 refunds without the form, with only 2 percent outstanding, and that it’s now taking care of customers as quickly as a few hours after they ask. </p>
<p id="0LCVg5"><strong>The promise: </strong>If you contact Dough and <em>do...</em></p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/22825700/dough-eve-refunds-retail-brand-perception-spectrum-v-tablet">Continue reading&hellip;</a>
  </p>

## X says it’s fixed the bug that broke links and images in pre-December 2014 tweets
 - [https://www.theverge.com/2023/8/21/23840640/twitter-x-2014-image-link-tweet-t-co-shortener](https://www.theverge.com/2023/8/21/23840640/twitter-x-2014-image-link-tweet-t-co-shortener)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T21:46:48+00:00

<figure>
      <img alt="An image showing the X logo with the old Twitter logo in the background" src="https://cdn.vox-cdn.com/thumbor/3D_JDgrolQMAzuL8c2WS_VpfD3U=/0x0:3001x2001/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564853/STK160_X_Twitter_008.0.jpg" />
        <figcaption>Image: The Verge</figcaption>
    </figure>

  <p id="Y7xbzR">Over the weekend, word spread about a problem affecting old tweets, and eventually, we narrowed it down to anything posted before December 2014, either with an image or a link that had been shortened by Twitter. A post <a href="https://twitter.com/tomcoates/status/1692922211416334597">by Tom Coates</a> alerted many people to the problem and he noted that a 2014 Ellen DeGeneres selfie from the Oscars that took the crown as “most retweeted ever” was even missing its image. </p>
<p id="H2WvTM">Now the @Support account at X, the company formerly known as Twitter until Elon Musk rebranded it, <a href="https://twitter.com/Support/status/1693732980324536695">says</a>, “Over the weekend we had a bug that prevented us from displaying images from before 2014. No images or data were lost. We fixed the bug, and the issue will be fully resolved in the coming days.”</p>
<p id="RpPxK6">There are no details mentioned in the...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840640/twitter-x-2014-image-link-tweet-t-co-shortener">Continue reading&hellip;</a>
  </p>

## FCC filing hints at a new Fitbit tracker — but which one?
 - [https://www.theverge.com/2023/8/21/23840308/fitbit-ace-4-luxe-google-fcc-filing-fitness-tracker](https://www.theverge.com/2023/8/21/23840308/fitbit-ace-4-luxe-google-fcc-filing-fitness-tracker)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T20:52:08+00:00

<figure>
      <img alt="Close up of Fitbit Inspire 3 screen. The Fitbit is resting on a vibrant green plant." src="https://cdn.vox-cdn.com/thumbor/uiuWhXXUgoeKhevatgfNRbVua88=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564625/226269_FITBIT_INSPIRE_3_PHO_vsong_0003.0.jpg" />
        <figcaption><em>The FCC filing seems to indicate a Bluetooth-only tracker. The Fitbit Inspire 3 (pictured) is a less likely candidate since it launched just last year.</em> | Photo by Victoria Song / The Verge</figcaption>
    </figure>

  <p id="orsHJs">It looks like the Pixel Watch 2 may not be the only wearable that Google launches this fall. A <a href="https://fccid.io/A4RG3MP5">new FCC filing</a> for what appears to be a Fitbit tracker also surfaced today. The question is which one, and what does that say about where Fitbit stands? </p>
<p id="j2HbZw">In the FCC filing, the product is listed as a “Google LLC Wireless Device G3MP5” but doesn’t appear to have anything but Bluetooth connectivity. And while there are no pictures, <a href="https://9to5google.com/2023/08/21/new-fitbit-tracker-appears-at-fcc-likely-luxe-2-or-ace-4/"><em>9to5Google</em> points out</a><em> </em>that the device’s e-label will be located in an app via “Settings &gt; Device &gt; Info &gt; Regulatory Info.” That lines up with Fitbit’s previous trackers. </p>
<p id="muS84e">While there have been a ton of Pixel Watch 2 leaks and rumors recently, it’s been quiet on the Fitbit front, so it’s unclear as to <em>which</em> Fitbit...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840308/fitbit-ace-4-luxe-google-fcc-filing-fitness-tracker">Continue reading&hellip;</a>
  </p>

## Samsung’s latest pitch for the Z Fold 5: two iPhones at the same time
 - [https://www.theverge.com/2023/8/21/23840345/samsung-try-galaxy-foldable-demo-two-iphones](https://www.theverge.com/2023/8/21/23840345/samsung-try-galaxy-foldable-demo-two-iphones)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T19:14:15+00:00

<figure>
      <img alt="Samsung Galaxy Z Fold 5 unfolded on a table showing two apps running side by side." src="https://cdn.vox-cdn.com/thumbor/AzbvftRS36WsjhdvDEBwOGLSjic=/0x0:2000x1333/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564340/DSC05370_processed.0.jpeg" />
        <figcaption><em>Imagine if this were two iPhones in a trench coat.</em> | Photo by Allison Johnson / The Verge</figcaption>
    </figure>

  <p id="0baRTf">Hey, wait a minute, that Samsung Galaxy Z Fold 5 is actually just two iPhones in a trench coat! </p>
<p id="KTDPEK">That’s the idea behind the <a href="https://news.samsung.com/global/with-new-try-galaxy-app-update-non-android-users-can-experience-samsung-galaxy-z-flip5-z-fold5">latest update</a> to the <a href="http://www.trygalaxy.com/">Try Galaxy</a> web app, which, when running on two iPhones, offers a Samsung One UI demonstration spread across both screens. Samsung says it lets iOS users try out the foldable’s benefits, like watching content on an “immersive” screen, or sample productivity features like dragging and dropping across both screens thanks to its multitasking abilities — something <a href="https://www.theverge.com/23773112/google-pixel-fold-vs-samsung-z-fold-4-comparison-head-to-head-foldable-phones">Samsung does well</a> and that even the iPad <a href="https://www.theverge.com/23787477/apple-ipados-17-stage-manager-ipad-multitasking">could use work on</a>. </p>
<p id="LUsLaE">To make it happen, you just have to <a href="http://www.trygalaxy.com/">visit the website</a> or scan a QR code on two iPhones, add the web app to your homescreen, and then tape them together (the tape is my own...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840345/samsung-try-galaxy-foldable-demo-two-iphones">Continue reading&hellip;</a>
  </p>

## Microsoft kills Kinect again
 - [https://www.theverge.com/2023/8/21/23840327/microsoft-azure-kinect-developer-kit-discontinued](https://www.theverge.com/2023/8/21/23840327/microsoft-azure-kinect-developer-kit-discontinued)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T19:00:02+00:00

<figure>
      <img alt="A photo of the Azure Kinect Developer Kit." src="https://cdn.vox-cdn.com/thumbor/CcMeHq9eKSBBS8JlKOQtd9RNlXI=/92x0:992x600/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564297/7824_ImmHeroVP3_1083x600.0.jpg" />
        <figcaption>Image: Microsoft</figcaption>
    </figure>

  <p id="SCgSnp">Microsoft is discontinuing the Kinect — again. The company officially stopped manufacturing the depth camera and microphone <a href="https://www.theverge.com/2017/10/25/16542870/microsoft-kinect-dead-stop-manufacturing">in 2017</a> and brought it back in a new form in 2019 as <a href="https://www.theverge.com/2019/2/24/18237244/microsoft-azure-kinect-developer-kit-price-release-date-mwc-2019">the Azure Kinect Developer Kit</a>. Now, Microsoft is ending production of that, too, but it has partnered with some outside companies to provide options available for people who need similar types of devices.</p>
<p id="R9fMG2">If you want to get one of the remaining Azure Kinect Developer Kits, they’ll be available to buy through the end of October or “until supplies last,” Microsoft’s Swati Mehta said <a href="https://techcommunity.microsoft.com/t5/mixed-reality-blog/microsoft-s-azure-kinect-developer-kit-technology-transfers-to/ba-p/3899122">in a post on the company’s website</a>. If you already have one, Mehta promises that you can keep using it “without disruption.”</p>
<p id="XyfdKc">“As the needs of our customers and partners evolve, we...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840327/microsoft-azure-kinect-developer-kit-discontinued">Continue reading&hellip;</a>
  </p>

## Should California expect more tropical storms like Hurricane Hilary?
 - [https://www.theverge.com/2023/8/21/23839976/california-tropical-storms-hurricane-hilary-climate-change](https://www.theverge.com/2023/8/21/23839976/california-tropical-storms-hurricane-hilary-climate-change)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T18:29:47+00:00

<figure>
      <img alt="Rain and wind lashes rows of palm trees." src="https://cdn.vox-cdn.com/thumbor/aMQGqPrWytDOpBPlqQtHpb6dlgE=/0x2:5000x3335/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72564189/1612698961.0.jpg" />
        <figcaption><em>Palms are hit by strong wind and rain from Tropical Storm Hilary in the deserts of Southern California on August 20th, 2023, in Palm Desert, California.&nbsp;</em> | Photo by David McNew / Getty Images</figcaption>
    </figure>

  <p id="SgVA9a">California is notoriously dry this time of year. Yet, over the course of a single day this weekend, some desert areas were hit with <a href="https://weather.com/news/news/2023-08-21-hilary-live-updates-hurricane-tropical-storm">more than a year’s worth</a> of rainfall.</p>
<p id="jRS5RI">Hurricane Hilary threw California into a <a href="https://www.gov.ca.gov/2023/08/19/governor-newsom-proclaims-state-of-emergency-as-hurricane-hilary-approaches-california/">state of emergency</a> after more than 80 years without a tropical storm making landfall there. This kind of storm is unusual for California, and it will probably remain a rare occurrence. Even so, strange and extreme weather is a hallmark of climate change. And experts say it could have more curveballs in store that the state should be preparing for. </p>
<p id="w6jd2a">“There probably will not be a whole lot more [hurricanes that move into the southwestern US] in the future. But when they do happen, they’ll be much more like Hilary,” says David...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839976/california-tropical-storms-hurricane-hilary-climate-change">Continue reading&hellip;</a>
  </p>

## The new Metal Gear Solid collection is coming to PS4, too
 - [https://www.theverge.com/2023/8/21/23840181/the-new-metal-gear-solid-collection-is-coming-to-ps4-too](https://www.theverge.com/2023/8/21/23840181/the-new-metal-gear-solid-collection-is-coming-to-ps4-too)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T17:43:10+00:00

<figure>
      <img alt="A screenshot from Metal Gear Solid 3 in the Metal Gear Solid: Master Collection Vol. 1." src="https://cdn.vox-cdn.com/thumbor/TjGmm4isuYWfV_fniTTroDTkBec=/150x0:1770x1080/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563993/ss_c970157813f8cc0ec6c3676895148159f27fe12c.0.jpg" />
        <figcaption>Image: Konami</figcaption>
    </figure>

  <p id="fwawoU">The new <em>Metal Gear Solid</em> collection that bundles <em>Metal Gear Solid</em>, <em>Metal Gear Solid 2: Sons of Liberty</em>, and <em>Metal Gear Solid 3: Snake Eater</em> will be coming to PS4, <a href="https://twitter.com/Metalgear/status/1693663677667545470">Konami announced on Monday</a>. The collection, which officially has the unwieldy name of <em>Metal Gear Solid: Master Collection Vol. 1</em>, had previously been announced for PS5, Xbox Series X / S, Nintendo Switch, and Steam.</p>
<p id="qUMNHL">In a post on X, the platform formerly known as Twitter, <a href="https://twitter.com/Metalgear/status/1693663677667545470">Konami said</a> it made the decision to release a PS4 version “in response to the many requests we have received from fans worldwide” but noted that it would only be available as a “download ver” (aka digital release). The post also doesn’t specify when the PS4 version might be released; on other platforms, the...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840181/the-new-metal-gear-solid-collection-is-coming-to-ps4-too">Continue reading&hellip;</a>
  </p>

## All the Pixel Watch 2 really needs is good battery life
 - [https://www.theverge.com/23836353/pixel-watch-2-battery-life-wear-os-4](https://www.theverge.com/23836353/pixel-watch-2-battery-life-wear-os-4)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T17:40:55+00:00

<figure>
      <img alt="Pixel Watch at an angle draped over Pixel 7 and Pixel 7 Pro phones" src="https://cdn.vox-cdn.com/thumbor/TEuJp8nUcii77MLUtGMI96DbfiY=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563987/226336_Pixel_Watch_AKrales_0072.0.jpg" />
        <figcaption><em>It’s a gamechanger if Google can figure out multiday battery life for the Pixel Watch 2.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="HxDOrx">While <a href="https://www.theverge.com/23818557/samsung-galaxy-watch-6-review-bezels-smartwatch-wearables">reviewing the Samsung Galaxy Watch 6</a>, I was surprised how much its small gains in battery life impacted my overall attitude toward the watch. It got me wondering whether my opinion about the <a href="https://www.theverge.com/23400779/google-pixel-watch-review-wear-os-smartwatch-wearable-fitbit">Google Pixel Watch</a> would change if its paltry battery life was <em>just</em> a smidge better. So, the second I wrapped up my Samsung review, I booted up the Pixel Watch.</p>
<p id="qgSJ4Q">I had reason to<strong> </strong>hope because Wear OS watches sometimes have the annoying quirk of getting better <em>after</em> the fact. For instance, battery life for the first day or two after setup is often the worst. Sometimes, it’s so crappy I wonder if I got a defective unit.<strong> </strong>But<strong> </strong>after a few days to about a week, the watch learns your usage patterns, and it gets a little better. Even more annoying is...</p>
  <p>
    <a href="https://www.theverge.com/23836353/pixel-watch-2-battery-life-wear-os-4">Continue reading&hellip;</a>
  </p>

## Tesla points to ‘insider wrongdoing’ as cause of massive employee data leak
 - [https://www.theverge.com/2023/8/21/23839940/tesla-data-leak-inside-job-handelsblatt](https://www.theverge.com/2023/8/21/23839940/tesla-data-leak-inside-job-handelsblatt)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T16:54:42+00:00

<figure>
      <img alt="Tesla logo in red on black background" src="https://cdn.vox-cdn.com/thumbor/8FTK7RdNFBftyfhtMYeJrNmjCRE=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563810/acastro_STK086_01.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="2LdhHf">Tesla has determined that two of its former workers are responsible for a massive data leak that includes personally identifiable information on over 75,000 employees, <a href="https://techcrunch.com/2023/08/21/tesla-breach-employee-insider/"><em>TechCrunch</em> reports</a>. According to <a href="https://apps.web.maine.gov/online/aeviewer/ME/40/014ae6db-4cb7-464b-b827-5d73f0bbc911.shtml">a filing</a> with the state of Maine’s attorney general office, Tesla’s data privacy officer, Steven Elentukh, reported the breach as “insider wrongdoing,” leaking employee information including social security numbers.</p>
<p id="EtqPyM">The Maine filing includes <a href="https://apps.web.maine.gov/online/aeviewer/ME/40/014ae6db-4cb7-464b-b827-5d73f0bbc911/5f2a16ee-b501-453d-a868-8b8fb871c7a7/document.html">a template letter</a> by Elentukh written to send to affected employees in the state. It confirms that <em>Handelsblatt</em>, the German media outlet recipient of 100GB of Tesla’s data, had notified Tesla on May 10th that it had received confidential information. </p>
<p id="RJMT4l">“The investigation revealed that two former Tesla...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839940/tesla-data-leak-inside-job-handelsblatt">Continue reading&hellip;</a>
  </p>

## T-Mobile’s new Go5G plan gets even more expensive and offers faster phone upgrades
 - [https://www.theverge.com/2023/8/21/23839982/t-mobile-go5g-next-annual-upgrade-iphone-samsung-galaxy-google-pixel](https://www.theverge.com/2023/8/21/23839982/t-mobile-go5g-next-annual-upgrade-iphone-samsung-galaxy-google-pixel)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T16:47:48+00:00

<figure>
      <img alt="Illustration of the T-Mobile logo on a tan and black background." src="https://cdn.vox-cdn.com/thumbor/Ve2PaqCBX50ykNn-Hd6CjmlopwQ=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563782/acastro_STK067__03.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="YyChr8">T-Mobile announced it’s offering a <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.t-mobile.com%2Fnews%2Fun-carrier%2Ft-mobile-unveils-go5g-next&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F8%2F21%2F23839982%2Ft-mobile-go5g-next-annual-upgrade-iphone-samsung-galaxy-google-pixel" rel="sponsored nofollow noopener" target="_blank">yearly phone upgrade plan</a> called Go5G Next for $100 per month for a single line. It’s a pricier companion to the $90-per-month Go5G Plus plan with bi-annual upgrades the carrier <a href="https://www.theverge.com/2023/4/20/23690128/t-mobile-go-5g-plus-plan-price-features">debuted earlier this year</a>. </p>
<p id="crU0zt">The prices from T-Mobile’s announcement assume you’re using automatic payments, which come with a $5 discount per line that’s separate from the company’s <a href="https://www.theverge.com/2023/7/21/23802986/t-mobile-in-store-bill-payment-fee-wireless-carrier">$5 fee for in-store payments</a>. </p>
<p id="MVZ7ov">Every other aspect of the plan looks to be the same as that lower-tier “Plus” plan: it offers unlimited calls and texts, Netflix Basic (or Standard if you’re on a family plan), Apple TV Plus, and “unlimited” data, with up to 50GB of broadband-quality data. After that, your connection slows to a crawl at 600Kbps. If you...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839982/t-mobile-go5g-next-annual-upgrade-iphone-samsung-galaxy-google-pixel">Continue reading&hellip;</a>
  </p>

## Microsoft’s new Xbox Series X console wraps include Starfield and camo options
 - [https://www.theverge.com/2023/8/21/23840110/microsoft-xbox-series-x-console-wraps-starfield-camo](https://www.theverge.com/2023/8/21/23840110/microsoft-xbox-series-x-console-wraps-starfield-camo)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T16:30:18+00:00

<figure>
      <img alt="Starfield and camo console wraps for Xbox Series X" src="https://cdn.vox-cdn.com/thumbor/DIkfEv3dyFoUx4WFEDp1k3vpb0A=/85x0:999x609/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563734/xboxconsolewraps.0.jpg" />
        <figcaption><em>The new Xbox Series X console wraps.</em> | Image: Microsoft</figcaption>
    </figure>

  <p id="d39JOC">Microsoft has created a series of Xbox Series X console wraps that are designed to be a more affordable option instead of purchasing a separate limited edition console. One of the first Xbox console wraps will be one for <em>Starfield</em>, which will <a href="https://click.linksynergy.com/deeplink?id=nOD%2FrLJHOac&amp;mid=24542&amp;u1=verge&amp;murl=https%3A%2F%2Fwww.microsoft.com%2Fen-us%2Fd%2FXbox-Series-X-Console-Wraps%2F8x08lwws1qh7%2FM2B3" rel="sponsored nofollow noopener" target="_blank">launch on October 18th</a>, priced at $49.99.</p>
<p id="1k2Foh">The console wraps aren’t stickers like you’d find from Dbrand; instead, they fasten to an Xbox Series X thanks to a velcro hook and loop enclosure. The plastic <em>Starfield </em>wrap includes panels that look similar to the limited edition <em>Starfield</em>-branded Xbox controller. “Key internal console components are highlighted through outlined access panel and game-inspired graphics,” <a href="https://news.xbox.com/en-us/2023/08/21/xbox-series-x-console-wraps-starfield-camo/">explains Monique Chatterjee</a>, senior design director at Xbox.</p>
  <figure class="e-image">
        
      <cite>Image:...</cite></figure>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840110/microsoft-xbox-series-x-console-wraps-starfield-camo">Continue reading&hellip;</a>
  </p>

## LG’s lovely 65-inch C3 OLED TV is now $700 off at Amazon
 - [https://www.theverge.com/2023/8/21/23839813/lg-c3-oled-tv-xbox-controller-anbernic-handheld-emulators-deal-sale](https://www.theverge.com/2023/8/21/23839813/lg-c3-oled-tv-xbox-controller-anbernic-handheld-emulators-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T16:21:53+00:00

<figure>
      <img alt="LG’s C3&amp;nbsp;OLED TV turned on in a spacious living room." src="https://cdn.vox-cdn.com/thumbor/QxaYPDK2H-c1AOKwXJu2jJ40HOM=/52x0:2508x1637/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563690/LG_C3_OLED_Lifestyle_Image.0.jpg" />
        <figcaption><em>The LG C3 is the jack-of-all-trades OLED TV for most people who enjoy both watching TV and playing games.</em> | Image: LG</figcaption>
    </figure>

  <p id="fP6T9R">The <strong>65-inch LG C3 OLED TV</strong> is on sale for $1,896.99 ($702 off) at <a href="https://www.amazon.com/LG-65-Inch-Processor-AI-Powered-OLED65C3PUA/dp/B0BVXDPZP3?th=1&amp;tag=theverge02-20" rel="sponsored nofollow noopener" target="_blank">Amazon</a>. The 4K TV is an exceptional jack-of-all-trades set with four HDMI 2.1 ports capable of up to 120Hz refresh  with VRR, making it ideal for gaming. It’s also got those signature deep black levels for seeing detail even in dark cinematic movies and TV shows. </p>
<div class="c-float-left c-float-hang"><aside id="Fps75s"><div></div></aside></div>
<p id="UAg2BP">The LG C3 is the follow-up to one of our go-to TVs, last year’s <a href="https://www.theverge.com/23453621/lg-c2-oled-tv-review">C2</a>. The new TV shares many similar specs with the C2, but it’s brighter, faster (thanks to a new processor), and has some user interface refinements in its webOS-based operating system — like a handy Personalized Picture Wizard that guides you through a step-by-step process to help set up the C3’s picture mode without as much fuss.</p>
<p id="xNuZC0">Between the NFL...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839813/lg-c3-oled-tv-xbox-controller-anbernic-handheld-emulators-deal-sale">Continue reading&hellip;</a>
  </p>

## Apple Podcasts now shows creators who’s really paying for their shows
 - [https://www.theverge.com/2023/8/21/23839961/apple-podcasts-subscription-analytics-linkfire-partnership](https://www.theverge.com/2023/8/21/23839961/apple-podcasts-subscription-analytics-linkfire-partnership)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T16:00:00+00:00

<figure>
      <img alt="Apple Podcasts logo illustration" src="https://cdn.vox-cdn.com/thumbor/f9t371kJv1LNsthHwfOVXymtUNE=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563557/acastro_STK461_03.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="T6bqba">Creators on Apple Podcasts will now be able to find out a lot more about who their most devoted listeners are and where they’re coming from. The company today <a href="https://podcasters.apple.com/5314-introducing-subscription-analytics-delegated-delivery-linkfire">is launching</a> subscription analytics tools that will show podcasters how many listeners started a free trial, the percentage of those who converted to a paid subscription, what type of plan they’re subscribed to, and geographic breakdowns. While Apple has made analytics on <a href="https://www.vox.com/2017/12/14/16778268/apple-podcast-find-listens-downloads-analytics-available">regular listeners</a> available since 2017, this new set of analytics will give podcasters more intel on the subscription side of their business.</p>
<p id="ZuTSHM">Creators can also see the breakdown between annual and monthly subscriptions. At a virtual briefing attended by <em>The Verge</em>, Apple’s global head of podcasts, Ben Cave, said...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839961/apple-podcasts-subscription-analytics-linkfire-partnership">Continue reading&hellip;</a>
  </p>

## Stitching together an archive of an endangered Palestinian art
 - [https://www.theverge.com/23833322/palestinian-embroidery-digital-archive-tatreez-wafa-ghnaim-tirazain](https://www.theverge.com/23833322/palestinian-embroidery-digital-archive-tatreez-wafa-ghnaim-tirazain)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T15:55:26+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/KLMC4_SFtTDjnpxc7b-B0YJrzQI=/0x0:2550x1700/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563527/236727_Palestinian_embroidery_archive_AKrales_0472.0.jpg" />
    </figure>


  		 <p>Palestinian embroidery is a centuries-old tradition. Can digitizing hard-to-access patterns help preserve it for a new generation?</p>
  <p>
    <a href="https://www.theverge.com/23833322/palestinian-embroidery-digital-archive-tatreez-wafa-ghnaim-tirazain">Continue reading&hellip;</a>
  </p>

## The Mandalorian, Loki, and WandaVision are headed to Blu-ray
 - [https://www.theverge.com/2023/8/21/23839994/disney-plus-mandalorian-loki-wandavision-blu-ray](https://www.theverge.com/2023/8/21/23839994/disney-plus-mandalorian-loki-wandavision-blu-ray)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T15:42:41+00:00

<figure>
      <img alt="An image showing The Mandalorian on Blu-ray" src="https://cdn.vox-cdn.com/thumbor/svw5KwC5McYzmpouc8XySKqmhtE=/68x0:911x562/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563472/mandalorian_physical_disc.0.jpg" />
        <figcaption>Image: Disney</figcaption>
    </figure>

  <p id="0DqWA1">Disney is releasing physical copies of <em>The Mandalorian</em>, <em>Loki</em>, and <em>WandaVision</em>. All three Disney Plus shows will become available on 4K UHD and Blu-ray later this year, marking the first time that Disney has brought its streaming-only series to home video.</p>
<p id="g9A33s">While the physical edition of <em>WandaVision</em> will include the complete series, the release of <em>Loki </em>on Blu-ray will only include the first season. Additionally, <em>The Mandalorian</em>’s first and second seasons will be split into two separate discs. </p>
  <figure class="e-image">
        
      <cite>Image: Disney</cite>
  </figure>
<p id="7d6BKm">You can preorder the physical copies starting on August 28th, with the release date for each one as follows:</p>
<ul>
<li id="WrgvuQ">
<em>Loki: The Complete First Season</em>: September 26th, 2023</li>
<li id="RTemYg">
<em>WandaVision: The Complete Series: </em>November 28th,...</li>
</ul>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839994/disney-plus-mandalorian-loki-wandavision-blu-ray">Continue reading&hellip;</a>
  </p>

## YouTube is figuring out its AI strategy by working with music labels
 - [https://www.theverge.com/2023/8/21/23840026/youtube-ai-music-copyright-monetization-universal](https://www.theverge.com/2023/8/21/23840026/youtube-ai-music-copyright-monetization-universal)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T15:41:15+00:00

<figure>
      <img alt="YouTube copyright takedown" src="https://cdn.vox-cdn.com/thumbor/vmZE7zjDKGrZs2h0HghPCZEKZ-Q=/0x12:745x509/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563462/youtube_copyright.0.png" />
    </figure>

  <p id="Hiko7x">YouTube is partnering with record labels to establish rules for how AI-generated music is treated on its platform, including monetization opportunities for both companies and creators.</p>
<p id="Sv4lmc">The platform said <a href="https://blog.youtube/inside-youtube/partnering-with-the-music-industry-on-ai/">in a blog post</a> it would invest in building its rights management system Content ID, update its policies on uploading manipulated content, and deploy generative AI  tools to help detect videos that violate its rules. </p>
<p id="TmmWS3">“Generative AI systems may amplify current challenges like trademark and copyright abuse, misinformation, spam, and more,” YouTube CEO Neal Mohan said. “But AI can also be used to identify this sort of content, and we’ll continue to invest in the AI-powered technology that helps us protect our community of viewers, creators,...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23840026/youtube-ai-music-copyright-monetization-universal">Continue reading&hellip;</a>
  </p>

## Apple’s sci-fi drama Invasion ramps up the tension in season 2
 - [https://www.theverge.com/23833132/invasion-season-2-review-apple-tv-plus](https://www.theverge.com/23833132/invasion-season-2-review-apple-tv-plus)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T15:00:00+00:00

<figure>
      <img alt="A still photo from season 2 of Invasion." src="https://cdn.vox-cdn.com/thumbor/zjPPRJvaxwD_7Fc9BMUhM0_qZoQ=/1210x0:3610x1600/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563343/Invasion_201_F00432F.0.jpg" />
        <figcaption>Image: Apple</figcaption>
    </figure>

  <p id="ii28Ac"><em>Invasion</em> was a curious addition to the sci-fi TV landscape when it debuted in 2021. For much of its runtime, it barely felt like science fiction at all. We all knew <em>something</em> alien was happening — it’s right there in the show’s title, after all — but the story was much more focused on the human-level drama going down as the world steadily succumbed to the invading forces. The result was <a href="https://www.theverge.com/22740520/invasion-review-apple-tv-plus">a show that started very slowly</a>, <a href="https://www.theverge.com/2021/11/12/22776188/invasion-apple-tv-plus-episode-6-aliens">though things did eventually pick up mid-season</a>. Ultimately, season 1 felt like <a href="https://www.theverge.com/2021/12/11/22828386/invasion-season-1-review-apple-tv-plus">a prologue to a much bigger story</a>.</p>
<p id="uLnMc7">With all of that setup out of the way, <a href="https://www.theverge.com/23808221/invasion-season-2-trailer-date-apple-tv-plus">the second season</a> starts out much more exciting — and it doesn’t let up for the first few episodes.</p>
<p id="eNAMcT"><em><strong>Note:</strong></em><em> this write-up is based on the first five (of 10) episodes of...</em></p>
  <p>
    <a href="https://www.theverge.com/23833132/invasion-season-2-review-apple-tv-plus">Continue reading&hellip;</a>
  </p>

## Amazon’s Fire TV Channels adds a sidebar and more free streaming content
 - [https://www.theverge.com/2023/8/21/23839875/amazon-fire-tv-channels-sidebar-free-streaming-content-fast](https://www.theverge.com/2023/8/21/23839875/amazon-fire-tv-channels-sidebar-free-streaming-content-fast)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T14:31:24+00:00

<figure>
      <img alt="A photo showing people on a couch using Amazon Fire TV Channels" src="https://cdn.vox-cdn.com/thumbor/lz1LX7MUDMn4iwimD8WyNgTyweY=/109x0:1291x788/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563279/amazon_fire_tv_channels_update.0.jpg" />
        <figcaption>Image: Amazon</figcaption>
    </figure>

  <p id="dBglCo"><a href="https://amazonfiretv.blog/new-fire-tv-channels-app-makes-it-easier-to-watch-free-fresh-fun-content-dd0a0b7aaffe">Amazon is updating</a> its recently launched Fire TV Channels app. The free, ad-supported streaming platform has a new sidebar that lets you navigate through different categories of content along with a new slate of shows.</p>
<p id="h5vWmL"><a href="https://amazonfiretv.blog/fire-tv-expands-instant-access-to-more-free-content-with-launch-of-fire-tv-channels-e53541f427d6">Fire TV Channels first launched in May</a> with a lineup of free shows, live news, music videos, and sports from over 400 different providers, such as ABC News, CBS Sports, Fox Sports, America’s Test Kitchen, Martha Stewart, and others. But now, Amazon says the app will also include content from <em>Variety</em>, <em>Rolling Stone</em>, <em>The Hollywood Reporter</em>, Billboard, TV Line, Funny or Die, GameSpot, Honest Trailer, and more.</p>
<div id="nqGq3r"><div style="width: 100%; height: 0; padding-bottom: 56.25%;"></div></div>
<p id="iVW8uv">Meanwhile, the new app’s sidebar lets you sift through all the different types of content available on the platform,...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839875/amazon-fire-tv-channels-sidebar-free-streaming-content-fast">Continue reading&hellip;</a>
  </p>

## The voice of Mario is stepping away from the character
 - [https://www.theverge.com/2023/8/21/23839933/mario-voice-actor-martinet-nintendo-stepping-down](https://www.theverge.com/2023/8/21/23839933/mario-voice-actor-martinet-nintendo-stepping-down)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T14:14:33+00:00

<figure>
      <img alt="Super Mario Galaxy launch" src="https://cdn.vox-cdn.com/thumbor/E8-4gkqAFciDVC8FYF4wGECY7eY=/4x0:2044x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72563217/833919084.0.jpg" />
        <figcaption><em>Martinet at the launch of </em>Super Mario Galaxy<em>.</em> | Photo by Stephen Kelly - PA Images/PA Images via Getty Images</figcaption>
    </figure>

  <p id="heDgsW">Charles Martinet, the voice of Mario for 27 years, will no longer be voicing the iconic character, according to <a href="https://twitter.com/NintendoAmerica/status/1693624002982314108">a tweet from Nintendo</a>. Martinet took on the role with 1996’s <em>Super Mario 64</em> and has voiced the character in numerous games since, including both mainline Mario releases like <em>Super Mario Odyssey</em> and <em>Super Mario Galaxy</em> as well as countless spinoffs.</p>
<p id="ws15Pw">“Charles is now moving into the brand-new role of Mario Ambassador. With this new transition, he will be stepping back from recording character voices for our games,” Nintendo’s statement reads. “It has been an honor working with Charles to help bring Mario to life for so many years and we want to thank and celebrate him.”</p>
<div id="LTMb5O">
<blockquote class="twitter-tweet">
<p dir="ltr" lang="en">We have a message for fans of the Mushroom Kingdom. Please...</p>
</blockquote>
</div>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839933/mario-voice-actor-martinet-nintendo-stepping-down">Continue reading&hellip;</a>
  </p>

## Here’s the first outdoor smart plug to work with Matter
 - [https://www.theverge.com/2023/8/21/23837585/leviton-matter-outdoor-smart-plug](https://www.theverge.com/2023/8/21/23837585/leviton-matter-outdoor-smart-plug)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T13:00:00+00:00

<figure>
      <img alt="A black outdoor smart plug plugged into an outdoor outlet." src="https://cdn.vox-cdn.com/thumbor/AyBMGY93uSj3vZHlMnBUZ41PwIs=/0x14:993x676/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72562909/D215O_Hero_Screen_2.0.jpeg" />
        <figcaption><em>Leviton’s new Decora Smart Wi-Fi Outdoor Plug-in Switch is the first to work with Matter.</em> | Image: Leviton</figcaption>
    </figure>

  <p id="vqaiWA">Smart lighting manufacturer Leviton has a new outdoor smart plug that’s the first to work with Matter. The <a href="https://www.leviton.com/en/products/D215O-1RE">Decora Smart Wi-Fi Outdoor Plug-in Switch</a> costs $54.99 and is available now at Amazon and The Home Depot. Part of Leviton’s <a href="https://www.leviton.com/en/products/brands/decora-smart">Decora Smart Wi-Fi lighting and load control line</a>, it’s the company’s fifth product to support Matter, following <a href="https://www.theverge.com/2023/7/18/23797610/leviton-decora-smart-wi-fi-switch-matter">adding Matter support to two of its in-wall switches and smart plugs</a> last month.</p>
<p id="h253jc">The outdoor smart plug works over 2.4GHz Wi-Fi, has on / off functionality (there’s no dimming), and a built-in light sensor for automating any lights you plug into it to turn on at night and off during the day. This is a neat feature you won’t find on a lot of smart plugs and means you don’t need to use any app or...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23837585/leviton-matter-outdoor-smart-plug">Continue reading&hellip;</a>
  </p>

## Samsung announces the first game to support new HDR10 Plus Gaming standard
 - [https://www.theverge.com/2023/8/21/23839768/samsung-hdr10-plus-gaming-standard-the-first-descendant-nexon](https://www.theverge.com/2023/8/21/23839768/samsung-hdr10-plus-gaming-standard-the-first-descendant-nexon)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T11:23:56+00:00

<figure>
      <img alt="Gamer sits at desk playing The First Descendant." src="https://cdn.vox-cdn.com/thumbor/mS8ezytDQvdeEcNBL2LKx77-TbE=/1x0:1999x1332/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72562721/HDR10_GAMING_dl1.0.jpg" />
        <figcaption>Image: Samsung</figcaption>
    </figure>

  <p id="0ifDum">Almost two years after its <a href="https://www.flatpanelshd.com/news.php?subaction=showfull&amp;id=1635416918">initial announcement in October 2021</a>, Samsung says the <a href="https://news.samsung.com/global/samsung-electronics-teams-up-with-nexon-to-unveil-worlds-first-hdr10-gaming-title-the-first-descendant">first game to support the HDR10 Plus Gaming</a> standard is nearing release. That game is <em>The First Descendant</em>, a free-to-play third-person shooter from Nexon which is running an open beta starting September 19th. </p>
<p id="LBc4EF">Samsung’s announcement doesn’t specify which platforms the game will support HDR10 Plus Gaming on, but we’re assuming it’s PC rather than consoles given neither Sony nor Microsoft have announced support for this latest HDR format on their platforms. On PC, Nvidia announced it was adding support for HDR10 Plus Gaming to its RTX and 16-series graphics cards <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.nvidia.com%2Fen-us%2Fgeforce%2Fnews%2Fgeforce-rtx-4080-game-ready-driver%2F%23hdr-10-plus-gaming&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F8%2F21%2F23839768%2Fsamsung-hdr10-plus-gaming-standard-the-first-descendant-nexon" rel="sponsored nofollow noopener" target="_blank">in November 2022</a>. </p>
<div class="c-float-left c-float-hang"><aside id="cz9o6b"><q>HDR calibration without the sliders</q></aside></div>
<p id="F8gAsC">The big advantage being advertised for...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23839768/samsung-hdr10-plus-gaming-standard-the-first-descendant-nexon">Continue reading&hellip;</a>
  </p>

## USDA announces $667 million in rural broadband funding
 - [https://www.theverge.com/2023/8/21/23837593/biden-broadband-usda-reconnect-internet-rural-farms](https://www.theverge.com/2023/8/21/23837593/biden-broadband-usda-reconnect-internet-rural-farms)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T09:00:00+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/hJthaTAI1qRnEKCvN1AmesV1aRQ=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72562486/acastro_170711_1777_0005.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="ukUbCv">The US Department of Agriculture announced nearly $700 million in funding Monday to expand high-speed broadband access in rural communities across the country.</p>
<p id="0RCvKL">The USDA’s ReConnect Program is providing $667 million in grants and loans for broadband projects in 22 states and the Marshall Islands in areas that lack access to speeds of at least 100Mbps down and 20Mbps up. Recipients of this funding will be required to build out infrastructure capable of providing upload and download speeds of 100Mbps, surpassing the Federal Communications Commission’s <a href="https://www.theverge.com/2021/3/4/22312065/fcc-highspeed-broadband-service-ajit-pai-bennet-angus-king-rob-portman">current speed minimums</a> of 25Mbps down and 3Mbps up. </p>
<div class="c-float-left c-float-hang"><aside id="t9CbCE"><q>“The reality is, we have faced some challenging times in rural places”</q></aside></div>
<p id="RlMJCV">“The reality is, we have faced some challenging times in rural...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/21/23837593/biden-broadband-usda-reconnect-internet-rural-farms">Continue reading&hellip;</a>
  </p>

## Meta may launch a Threads web version early this week
 - [https://www.theverge.com/2023/8/20/23839495/meta-threads-web-version-coming-this-week](https://www.theverge.com/2023/8/20/23839495/meta-threads-web-version-coming-this-week)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-08-21T01:10:31+00:00

<figure>
      <img alt="An image showing the Threads logo" src="https://cdn.vox-cdn.com/thumbor/E13u3KaBPfd3Lib0tupHLDLt74M=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72562095/STK156_Instagram_threads_1.0.jpg" />
        <figcaption>Illustration: The Verge</figcaption>
    </figure>

  <p id="6usKhp">Meta <a href="https://www.wsj.com/tech/metas-threads-app-to-launch-web-version-as-rivalry-with-x-enters-new-stage-706e8241">will launch the web version of Threads</a>, its competitor to X (formerly known as Twitter) early this week, reports <em>The Wall Street Journal. </em>A web version has been frustratingly missing since the short-form posting service began.</p>
<p id="XoS9PQ">Meta CEO Mark Zuckerberg said the company is <a href="https://www.theverge.com/2023/8/4/22381931/threads-web-search-next-few-weeks">working on adding the feature</a> along with better search (well, search at all, really — right now, you can only search for usernames on the platform) earlier this month, and that it would be ready in “the next few weeks.” </p>
<p id="czcmt0">However, <em>WSJ </em>says, its sources say the feature’s “launch plans aren’t final and could change.” Mosseri posted on Threads last week that <a href="https://www.threads.net/@mosseri/post/CvvmPqOJGFx/?igshid=MzRlODBiNWFlZA==">Meta had been testing</a> “an early version internally for a week or two,” but that it “needs some work” before wide...</p>
  <p>
    <a href="https://www.theverge.com/2023/8/20/23839495/meta-threads-web-version-coming-this-week">Continue reading&hellip;</a>
  </p>

