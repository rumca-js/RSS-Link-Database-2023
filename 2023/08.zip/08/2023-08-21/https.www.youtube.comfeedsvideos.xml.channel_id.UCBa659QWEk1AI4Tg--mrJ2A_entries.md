# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## No-one built these for 5,000 years… until now.
 - [https://www.youtube.com/watch?v=_G2Q1qsoGEU](https://www.youtube.com/watch?v=_G2Q1qsoGEU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-08-21T15:00:25+00:00

Long barrows are Neolithic constructions that might have been churches, or graveyards, or landmarks. And some are being built again: for the first time in recorded history. ■ Soulton Long Barrow: https://www.soultonhall.co.uk/page/322/soulton-long-barrow.htm ■ Sacred Stones: https://www.sacredstones.co.uk/our-locations/soulton-long-barrow/

Camera: Ryan Priestnall https://www.ryanpriestnall.com/
Editor: Julian Domanski

I'm at https://tomscott.com
on Twitter at https://twitter.com/tomscott
on Facebook at https://facebook.com/tomscott
and on Instagram as tomscottgo

