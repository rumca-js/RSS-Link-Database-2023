# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Xbox @ Gamescom 2023 Day 3 Livestream
 - [https://www.youtube.com/watch?v=AsxAUeGbg30](https://www.youtube.com/watch?v=AsxAUeGbg30)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:40:08+00:00

Xbox is LIVE for our last day of streaming from gamescom: Dev interviews, deep dives, gameplay and more.

#gamescom #xbox #gaming

## Xbox @ Gamescom 2023 Day 2 Livestream
 - [https://www.youtube.com/watch?v=I6XP0FsnQY4](https://www.youtube.com/watch?v=I6XP0FsnQY4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:36:21+00:00

Xbox is LIVE from gamescom for day 2 featuring dev interviews, deep dives, interviews and more!

#gamescom #xbox #gaming

## Xbox @ Gamescom 2023 Day 1 Livestream
 - [https://www.youtube.com/watch?v=TGlCHdfvqJQ](https://www.youtube.com/watch?v=TGlCHdfvqJQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:32:54+00:00

Xbox is LIVE from gamescom for day 1 featuring dev interviews, deep dives, interviews and more!

#gamescom #xbox #gaming

## Future Games Show @ gamescom 2023 Livestream
 - [https://www.youtube.com/watch?v=Etj_1NRPRHo](https://www.youtube.com/watch?v=Etj_1NRPRHo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:21:11+00:00

The Future Games Show at gamescom returns on Wednesday August 23, 2023 at 11am PT / 2pm ET / 7pm BST / 8pm CEST hosted by Troy Baker (The Last of Us) and Erika Ishii (Apex Legends). The 90 minute show will include 8 world premieres, exclusive trailers, a VR showcase, a ‘Ones to Play’ segment featuring titles with demos available to download and play immediately after the show, and a competition to win a PS5 or Xbox Series X.

#gamescom #gaming

## Destiny 2 Showcase 2023 Livestream (The Final Shape, Season 22, reprised raid Reveal)
 - [https://www.youtube.com/watch?v=Rq4VC2S_kvE](https://www.youtube.com/watch?v=Rq4VC2S_kvE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:13:59+00:00

On Tuesday, August 22, Bungie will host their annual Destiny 2 Showcase to share more details on the upcoming The Final Shape expansion, Season 22, the next reprised raid, and more. The pre-show begins at 8 AM PT on Tuesday, August 22, while the main Showcase will start at 9 AM PT. After the Showcase, the live post-show will begin with a roundtable discussion about what to expect in the coming year for Destiny 2.

#destiny2 #gaming

## Gamescom Opening Night Live 2023 Livestream
 - [https://www.youtube.com/watch?v=7joZauE4AvM](https://www.youtube.com/watch?v=7joZauE4AvM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T16:06:30+00:00

Tune in August 22nd at 11am PT for gamescom: Opening Night Live 2023. Geoff Keighley will once again host with new trailers, gameplay, and reveals, including Alan Wake 2 and Black Myth Wukong.

#gamescom #openingnightlive #gaming

## The Complete METAL GEAR SOLID Timeline Explained!
 - [https://www.youtube.com/watch?v=nNOsTC2IoNI](https://www.youtube.com/watch?v=nNOsTC2IoNI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-08-21T15:00:40+00:00

The Metal Gear Solid franchise features one of the most extensive and elaborate timelines in all of gaming. Konami’s epic espionage series unfurls its dense narrative across 11 games with an alternate history timeline that spans from the height of the cold war in Metal Gear Solid 3: Snake Eater all the way through to a neo-futuristic take on the 21st century in Metal Gear Rising: Revengeance.

With a remake of Metal Gear Solid 3 on the way as well as remasters of the original Metal Gear Solid and Metal Gear Solid 2: Sons of Liberty, what better time to dive back into Hideo Kojima’s iconic franchise.

This is the Metal Gear Solid timeline fully explained.

00:00 - Intro
01:00 - METAL GEAR SOLID 3: SNAKE EATER - 1964
07:31 - METAL GEAR SOLID: PORTABLE OPS - 1970
10:41 - LES ENFANTS TERRIBLES - 1971
12:11 - METAL GEAR SOLID: PEACE WALKER - 1974
15:49 - SKULL FACE
16:46 - METAL GEAR SOLID 5: GROUND ZEROES - 1975
18:39 - METAL GEAR SOLID 5: THE PHANTOM PAIN - 1984
23:25 - METAL GEAR - 1995
25:30 - METAL GEAR 2: SOLID SNAKE - 1999
27:39 - METAL GEAR SOLID - 2005
32:12 - METAL GEAR SOLID 2: SONS OF LIBERTY - 2007-2009
36:42 - METAL GEAR SOLID 4: GUNS OF THE PATRIOT - 2014
41:39 - METAL GEAR RISING: REVENGEANCE - 2018

From the origins of Big Boss and FOXHOUND through to Solid Snake’s pivotal role in the franchise via the shock twists of Metal Gear Solid 5: The Phantom Pain, this video breaks down the long and confusing timeline of the Metal Gear Solid franchise.

#TimelineExplained #MetalGearSolid #GameSpot

Timeline Playlist - https://www.youtube.com/watch?v=3gaFRoP4RUA&amp;list=PLpg6WLs8kxGN7aotOq-B5tYZWpvTZ3KRS

