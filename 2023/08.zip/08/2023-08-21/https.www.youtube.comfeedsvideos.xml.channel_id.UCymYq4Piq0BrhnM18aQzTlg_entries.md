# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## The Return of Budget 15" Laptops? Ace Magic 15" Laptop Review
 - [https://www.youtube.com/watch?v=Nu3N2svAj3A](https://www.youtube.com/watch?v=Nu3N2svAj3A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2023-08-21T22:35:50+00:00

Buy one on Amazon: https://lon.tv/gp5lw (compensated affiliate link) - The folks behind the recent Ace Magician mini PCs we've looked at recently now have a laptop powered by an Intel N95 processor. It's not perfect by any means but it's not bad for the selling price. See more laptops: https://www.youtube.com/playlist?list=PLCZHp4d1HnItLi4_4nwCJ89-aXdkVtrL5 and subscribe! http://lon.tv/s

VIDEO INDEX:
00:00 - Intro
00:42 - Price
01:03 - Display
01:27 - Processor, RAM, Storage and Internals
02:22 - WiFi Issues
03:12 - Webcam
03:36 - Keyboard & Trackpad
04:50 - Ports
05:59 - Build Quality
06:31 - Windows 11 Pro 
06:43 - Web Browsing, YouTube, Speedometer Benchmark
08:06 - Microsoft Word & Office Performance
08:25 - Gaming: Half Life 2 & No Man's Sky
09:01 - PS2 Emulation
09:49 - 3DMark TimeSpy Benchmark, Stress Test and Fan Noise
10:57 - Game Streaming
11:35 - Battery Life
12:03 - Linux
12:42 - Conclusion

Visit my Blog! https://blog.lon.tv

Subscribe to my email lists! 
Weekly Breakdown of Posted Videos:  - https://lon.tv/email
Daily Email From My Blog Posts! https://lon.tv/digest

See my second channel for supplementary content : http://lon.tv/extras

Follow me on Amazon too! http://lon.tv/amazonshop

Join the Facebook group to connect with me and other viewers! 
http://lon.tv/facebookgroup

Visit the Lon.TV store to purchase some of my previously reviewed items! http://lon.tv/store

Read more about my transparency and disclaimers: http://lon.tv/disclosures

Want to chat with other fans of the channel? Visit our Facebook Group! http://lon.tv/facebookgroup, our Discord: http://lon.tv/discord and our Telegram channel at http://lon.tv/telegram !

Want to help the channel? Start a Member subscription or give a one time tip!
http://lon.tv/support

or contribute via Venmo!
lon@lon.tv

Follow me on Facebook!
http://facebook.com/lonreviewstech

Follow me on Twitter!
http://twitter.com/lonseidman

Catch my longer interviews and wrap-ups in audio form on my podcast!
http://lon.tv/itunes
http://lon.tv/stitcher
or the feed at http://lon.tv/podcast/feed.xml

We are a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for us to earn fees by linking to Amazon.com and affiliated sites.

