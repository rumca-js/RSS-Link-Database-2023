# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## No One Is Ready For What's Coming Out Of Ukraine.
 - [https://www.youtube.com/watch?v=5rRbovnxR-M](https://www.youtube.com/watch?v=5rRbovnxR-M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-08-21T17:18:42+00:00

Genucel 3-Step Dark Spot Luxury System – 70% OFF – https://genucel.com/brand - U.S. & Canada Orders Only

As RFK Jr tells Tucker the Pentagon has used other countries like Ukraine for bioweapons research, why, when top government officials have alluded to as much, is this still labelled a conspiracy theory? And are there examples of any other “defensive” research that was converted into destructive biological weapons, in the way RFK suggests gain-of-function could be used? #biohazard #tuckercarlson #government 
--------------------------------------------------------------------------------------------------------------------------
WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## Jordan Peterson CALLS OUT TRUMP! Plus Moderna’s Multimillion dollar payout! - Stay Free #194 PREVIEW
 - [https://www.youtube.com/watch?v=Tq0HbhJk86I](https://www.youtube.com/watch?v=Tq0HbhJk86I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-08-21T15:05:48+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me live and exclusively over on RUMBLE:
https://bit.ly/stayfree-194-Trump-Peterson

TODAY - Trump chooses to skip the GOP primary debates in favour of alternative media. Moderna pays US government $400M ‘catch-up payment’ under new COVID-19 vaccine license, plus our special guest is Faiz Shakir, advisor to Bernie Sanders and exec director of ‘More Perfect Union’ to talk about the state of the Democrat party, taking on Trump, and their support for Unions.

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EDT | 9:00AM PDT

Join us at 'Community 2024' https://www.russellbrand.com/community/

Join The STAY FREE Community: https://russellbrand.locals.com/

NEW MERCH! https://stuff.russellbrand.com/

