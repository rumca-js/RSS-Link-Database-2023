# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Blue Beetle - Set Up To Fail
 - [https://www.youtube.com/watch?v=ZLWJ68p-nsk](https://www.youtube.com/watch?v=ZLWJ68p-nsk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-08-21T17:28:17+00:00

Blue Beetle has basically everything going against it: a hero nobody knows, no big stars attached, part of an almost-defunct cinematic universe and coming out at a time when superhero movies are in decline. And that's a shame, because as I'm about to show you, its not a bad movie.

