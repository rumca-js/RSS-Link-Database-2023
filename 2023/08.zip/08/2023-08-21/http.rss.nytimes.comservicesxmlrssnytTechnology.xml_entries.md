# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## What Driverless Waymo Taxi Rides Are Like in San Francisco
 - [https://www.nytimes.com/2023/08/21/technology/waymo-driverless-cars-san-francisco.html](https://www.nytimes.com/2023/08/21/technology/waymo-driverless-cars-san-francisco.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-21T23:54:45+00:00

On Monday, Waymo began letting the public pay for rides in its driverless cars in San Francisco. The New York Times dispatched three reporters around the city to test the service.

## Arm, the Chip Designer, Files for an I.P.O. Expected to Be Among the Largest
 - [https://www.nytimes.com/2023/08/21/technology/chip-designer-arm-ipo-softbank.html](https://www.nytimes.com/2023/08/21/technology/chip-designer-arm-ipo-softbank.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-21T22:25:13+00:00

The I.P.O. filing means Arm can begin to gauge investor interest, which will be critical to the share sale.

## More Screen Time Delays Development in Babies, Study Finds
 - [https://www.nytimes.com/2023/08/21/health/screen-time-developmental-delays-babies.html](https://www.nytimes.com/2023/08/21/health/screen-time-developmental-delays-babies.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-21T16:09:52+00:00

One-year-olds exposed to more than four hours of screen time a day experienced developmental delays in communication and problem-solving skills at ages 2 and 4, according to a new study

## How Nvidia Built a Competitive Moat Around A.I. Chips
 - [https://www.nytimes.com/2023/08/21/technology/nvidia-ai-chips-gpu.html](https://www.nytimes.com/2023/08/21/technology/nvidia-ai-chips-gpu.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-08-21T13:00:20+00:00

The most visible winner of the artificial intelligence boom achieved its dominance by becoming a one-stop shop for A.I. development, from chips to software to other services.

