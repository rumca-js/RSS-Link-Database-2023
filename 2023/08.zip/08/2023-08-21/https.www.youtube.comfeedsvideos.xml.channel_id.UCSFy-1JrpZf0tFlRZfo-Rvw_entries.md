# Source:Sydney Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw, language:en-US

## The age of insufferable Disney princesses...
 - [https://www.youtube.com/watch?v=OW5uSVyc6Qc](https://www.youtube.com/watch?v=OW5uSVyc6Qc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSFy-1JrpZf0tFlRZfo-Rvw
 - date published: 2023-08-21T23:42:59+00:00

Go to https://sponsr.is/wecultivate_sydneywatson_0823 and download Cultivate FOR FREE!

Links:
Director's son said his father would not be cool with this: https://news.yahoo.com/snow-white-director-son-says-173516576.html

Articles about past princesses:
https://www.teenvogue.com/story/emma-watson-explains-beauty-beast-belle-feminist
https://theconversation.com/disneys-the-little-mermaid-review-ariel-finally-finds-her-feminist-voice-206695
https://www.cbr.com/disney-little-mermaid-feminist-ariel-halle-bailey/
https://screenrant.com/little-mermaid-movie-live-action-progressive-how/

Linda Woolverton interview: https://www.youtube.com/watch?v=6w7zJYDK5DQ

Find me:
Subscribestar: https://www.subscribestar.com/sydney-watson
Facebook: https://www.facebook.com/sydneywatsonofficial 
Twitter: https://twitter.com/sydneylwatson 
Instagram: https://www.instagram.com/sydneywatson__ 

Sign up to my email list (I promise not to harass you haha): https://www.sydneywatson.com

