# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Meta Pays Supposedly Independent Australian “Fact-Checkers” 800 Dollars Per Fact-Check
 - [https://reclaimthenet.org/meta-pays-supposedly-independent-australian-fact-checkers-800-dollars-per-fact-check](https://reclaimthenet.org/meta-pays-supposedly-independent-australian-fact-checkers-800-dollars-per-fact-check)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-21T18:49:20+00:00

<a href="https://reclaimthenet.org/meta-pays-supposedly-independent-australian-fact-checkers-800-dollars-per-fact-check" rel="nofollow" title="Meta Pays Supposedly Independent Australian &#8220;Fact-Checkers&#8221; 800 Dollars Per Fact-Check"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/aus-fact-check.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Documents reveal all.</p>
<p>The post <a href="https://reclaimthenet.org/meta-pays-supposedly-independent-australian-fact-checkers-800-dollars-per-fact-check" rel="nofollow">Meta Pays Supposedly Independent Australian &#8220;Fact-Checkers&#8221; 800 Dollars Per Fact-Check</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The UN is Building a “Digital Army” To Fight What it Calls “Deadly Disinformation”
 - [https://reclaimthenet.org/the-un-is-building-a-digital-army](https://reclaimthenet.org/the-un-is-building-a-digital-army)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-21T17:42:13+00:00

<a href="https://reclaimthenet.org/the-un-is-building-a-digital-army" rel="nofollow" title="The UN is Building a &#8220;Digital Army&#8221; To Fight What it Calls &#8220;Deadly Disinformation&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/un-censor.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Another global organization trying to police speech.</p>
<p>The post <a href="https://reclaimthenet.org/the-un-is-building-a-digital-army" rel="nofollow">The UN is Building a &#8220;Digital Army&#8221; To Fight What it Calls &#8220;Deadly Disinformation&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Gates Foundation Pushes National Digital ID Tech
 - [https://reclaimthenet.org/gates-foundation-pushes-national-digital-id-tech](https://reclaimthenet.org/gates-foundation-pushes-national-digital-id-tech)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-21T16:59:30+00:00

<a href="https://reclaimthenet.org/gates-foundation-pushes-national-digital-id-tech" rel="nofollow" title="Gates Foundation Pushes National Digital ID Tech"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/gates-digital-id.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Pushing the controversial technology in India.</p>
<p>The post <a href="https://reclaimthenet.org/gates-foundation-pushes-national-digital-id-tech" rel="nofollow">Gates Foundation Pushes National Digital ID Tech</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Matt Gaetz Introduces Legislation To Shut Down Domestic Surveillance Program
 - [https://reclaimthenet.org/matt-gaetz-introduces-legislation-to-shut-down-domestic-surveillance-program](https://reclaimthenet.org/matt-gaetz-introduces-legislation-to-shut-down-domestic-surveillance-program)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-08-21T16:16:21+00:00

<a href="https://reclaimthenet.org/matt-gaetz-introduces-legislation-to-shut-down-domestic-surveillance-program" rel="nofollow" title="Matt Gaetz Introduces Legislation To Shut Down Domestic Surveillance Program"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/08/gaetz-scanning.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>After USPS was found to be monitoring social media activity.</p>
<p>The post <a href="https://reclaimthenet.org/matt-gaetz-introduces-legislation-to-shut-down-domestic-surveillance-program" rel="nofollow">Matt Gaetz Introduces Legislation To Shut Down Domestic Surveillance Program</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

