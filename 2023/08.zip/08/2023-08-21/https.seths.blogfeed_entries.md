# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Now in Spanish
 - [https://seths.blog/2023/08/now-in-spanish/](https://seths.blog/2023/08/now-in-spanish/)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-08-21T19:17:00+00:00

The Carbon Almanac is now available in Spanish. For free. Free to download, free to share and free to print a copy at home. While the book has been traditionally published around the world (in Italian, Czech, Chinese, Korean, Japanese and Dutch), no Spanish-language publisher was willing to do the work. So we purchased the [&#8230;]

## For customers vs to customers
 - [https://seths.blog/2023/08/decoding-dark-patterns-and-cognitive-load/](https://seths.blog/2023/08/decoding-dark-patterns-and-cognitive-load/)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-08-21T14:30:00+00:00

In the life of every enterprise, the moment arises when a choice has to be made: Are you here for your customers, to give them what they seek, or are you trying to do something to your customers, to squeeze out extra income? This doesn&#8217;t mean that the only path is to keep lowering your [&#8230;]

