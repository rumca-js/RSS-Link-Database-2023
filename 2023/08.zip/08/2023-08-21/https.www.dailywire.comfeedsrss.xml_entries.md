# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Fox News To No Longer Allow Trump Surrogates In Debate ‘Spin Room’ After Trump Refuses To Show Up
 - [https://www.dailywire.com/news/fox-news-to-no-longer-allow-trump-surrogates-in-debate-spin-room-after-trump-refuses-to-show-up](https://www.dailywire.com/news/fox-news-to-no-longer-allow-trump-surrogates-in-debate-spin-room-after-trump-refuses-to-show-up)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T23:11:05+00:00

Fox News has moved to restrict former President Donald Trump&#8217;s surrogates from attending the Republican Party primary debate in Milwaukee on Wednesday after the former president announced over the weekend that he would not be showing up. The network informed the Trump campaign on Monday that access to the debate &#8220;spin room&#8221; — where top ...

## Poll Trump Cited As Reason To Skip Debates Shows Majority Of Republicans Want Him To Show Up
 - [https://www.dailywire.com/news/poll-trump-cited-as-reason-to-skip-debates-shows-majority-of-republicans-want-him-to-show-up](https://www.dailywire.com/news/poll-trump-cited-as-reason-to-skip-debates-shows-majority-of-republicans-want-him-to-show-up)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T23:09:36+00:00

The poll that former President Donald Trump cited over the weekend to justify not participating in the Republican Party primary debates shows that the overwhelming majority of Republican voters want him to show up and debate. Trump cited a CBS News poll that showed him at 62%, Florida Governor Ron DeSantis at 16%, and everyone ...

## Nation’s Biggest Teachers Union ‘Coached’ Teachers To Inject Gender Identity Into Curricula, Report Says
 - [https://www.dailywire.com/news/nations-biggest-teachers-union-coached-teachers-to-inject-gender-identity-into-curricula-report-says](https://www.dailywire.com/news/nations-biggest-teachers-union-coached-teachers-to-inject-gender-identity-into-curricula-report-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T21:57:20+00:00

America&#8217;s largest teachers union &#8220;coached&#8221; teachers on how to expose students to gender identity in the curriculum, according to a new report. The American Federation of Teachers (AFT) &#8220;coached its members on how to inject gender identity politics into classroom teaching,&#8221; said the report published Wednesday by the conservative Defense of Freedom Institute. The report ...

## Conservatives Have Mixed Reactions To Trump Refusing To Debate
 - [https://www.dailywire.com/news/conservatives-have-mixed-reactions-to-trump-refusing-to-debate](https://www.dailywire.com/news/conservatives-have-mixed-reactions-to-trump-refusing-to-debate)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T21:07:26+00:00

Former President Donald Trump faced mixed reactions from conservatives after announcing over the weekend that he will not participate in the Republican Party&#8217;s primary debates. Trump cited a CBS News poll on Sunday that showed him at 62%, Florida Governor Ron DeSantis at 16%, and everyone else in the low single digits to explain why ...

## North Korea Warns US, South Korean Military Drills Could Trigger ‘Thermonuclear War’
 - [https://www.dailywire.com/news/north-korea-warns-us-south-korean-military-drills-could-trigger-thermonuclear-war](https://www.dailywire.com/news/north-korea-warns-us-south-korean-military-drills-could-trigger-thermonuclear-war)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T21:02:28+00:00

North Korean state media warned U.S. Military officials on Monday that &#8220;thermonuclear war&#8221; could break out after denouncing the U.S. and South Korea joint military drills test-firing strategic cruise missiles on the Korean Peninsula. U.S. and South Korean militaries began their annual Ulchi Freedom Shield computer-simulated command post exercise, which Navy officials said is designed ...

## Gun Control Protesters Show Up In Tennessee As ‘Public Safety’ Special Session Begins
 - [https://www.dailywire.com/news/gun-control-protesters-show-up-in-tennessee-as-public-safety-special-session-begins](https://www.dailywire.com/news/gun-control-protesters-show-up-in-tennessee-as-public-safety-special-session-begins)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T20:31:40+00:00

NASHVILLE, Tenn. — A special session of the Tennessee General Assembly called by Republican Governor Bill Lee to deal with “public safety” began on Monday as Left-leaning protesters gathered to push for more gun control. The August 21 special session comes months after a transgender-identifying shooter killed six people at The Covenant School in Nashville, ...

## Al Roker Says He’s ‘Glad To Be Alive’ On Birthday After Multiple Hospitalizations
 - [https://www.dailywire.com/news/al-roker-says-hes-glad-to-be-alive-on-birthday-after-multiple-hospitalizations](https://www.dailywire.com/news/al-roker-says-hes-glad-to-be-alive-on-birthday-after-multiple-hospitalizations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T20:00:57+00:00

Longtime &#8220;Today&#8221; show host Al Roker said he&#8217;s &#8220;glad to be alive&#8221; as he celebrated another trip around the sun this weekend following multiple hospitalizations that kept him off the air for weeks. The 69-year-old NBC host of the morning show said he&#8217;s &#8220;more than grateful&#8221; to be celebrating his birthday after he had to ...

## ‘Mission: Impossible’ And ‘Indiana Jones’ Flop At Domestic Box Office, Look To Lose $100 Million Each
 - [https://www.dailywire.com/news/mission-impossible-and-indiana-jones-flop-at-domestic-box-office-look-to-lose-100-million-each](https://www.dailywire.com/news/mission-impossible-and-indiana-jones-flop-at-domestic-box-office-look-to-lose-100-million-each)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T18:59:36+00:00

Tom Cruise&#8217;s latest &#8220;Mission: Impossible&#8221; film and Harrison Ford&#8217;s return to the &#8220;Indiana Jones&#8221; franchise are struggling at the domestic box office as the highly-anticipated summer blockbuster films are estimated to lose $100 million each. The seventh installment in the M:I franchise, &#8220;M:I-Dead Reckoning Part One,&#8221; has earned $164,626,507 at the domestic box office as of ...

## WH Spox Says Biden Has ‘Been There Since Day One’ For Maui. Here’s Where He Actually Was
 - [https://www.dailywire.com/news/wh-spox-says-biden-has-been-there-since-day-one-for-maui-heres-where-he-actually-was](https://www.dailywire.com/news/wh-spox-says-biden-has-been-there-since-day-one-for-maui-heres-where-he-actually-was)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T18:47:07+00:00

A spokesperson for President Joe Biden said that when Biden arrived in Maui — nearly two weeks after wildfires swept through western Maui — one of his priorities would be to make sure residents were aware that he had &#8220;been there since day one.&#8221; The president and First Lady Jill Biden traveled to Maui on ...

## California Mother Fired After Speaking Out Against New Sex-Ed Curriculum
 - [https://www.dailywire.com/news/california-mother-fired-after-speaking-out-against-new-sex-ed-curriculum](https://www.dailywire.com/news/california-mother-fired-after-speaking-out-against-new-sex-ed-curriculum)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T18:34:13+00:00

A California mother has recently found herself out of a job after she spoke out at her district school board meeting about the adoption of a controversial sex-ed curriculum. Janet Roberson, a real estate agent and mother of three in the northern California town of Benicia recently attended her school board meeting to voice her ...

## Republicans Subpoena FBI, IRS Agents In Probe Into Whistleblower Allegations In Hunter Biden Investigation
 - [https://www.dailywire.com/news/republicans-subpoena-fbi-irs-agents-in-probe-into-whistleblower-allegations-in-hunter-biden-investigation](https://www.dailywire.com/news/republicans-subpoena-fbi-irs-agents-in-probe-into-whistleblower-allegations-in-hunter-biden-investigation)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T18:16:23+00:00

House Judiciary Chair Jim Jordan (R-OH) and House Ways &amp; Means Chair Jason Smith (R-MO) subpoenaed four federal agents this week in their probe into IRS whistleblower allegations of corruption in the criminal investigation into President Joe Biden&#8217;s son, Hunter Biden. The four federal agents allegedly were &#8220;present at&#8221; or have &#8220;direct knowledge&#8221; of a ...

## Trump Agrees To $200,000 Bond, Other Conditions In Fulton County Indictment
 - [https://www.dailywire.com/news/trump-agrees-to-200000-bond-other-conditions-in-fulton-county-indictment](https://www.dailywire.com/news/trump-agrees-to-200000-bond-other-conditions-in-fulton-county-indictment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T18:09:32+00:00

Former President Donald Trump agreed to a $200,000 bond and other release conditions on Monday in the sweeping Georgia racketeering indictment after his legal team met with the Fulton County District Attorney’s office. Trump, who is expected to surrender at the Fulton Couty jail later this week, consented to the bond order that includes 13 ...

## Fox News Host Steve Doocy Says Trump ‘May Actually Be Helping’ Biden By Skipping Debates
 - [https://www.dailywire.com/news/fox-news-host-steve-doocy-says-trump-may-actually-be-helping-biden-by-skipping-debates](https://www.dailywire.com/news/fox-news-host-steve-doocy-says-trump-may-actually-be-helping-biden-by-skipping-debates)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T17:58:19+00:00

&#8220;Fox &amp; Friends&#8221; co-host Steve Doocy suggested this week that former President Donald Trump may be helping President Joe Biden by skipping the Republican Party&#8217;s first presidential primary this week, arguing that by doing so he opened the door for Biden to skip debating Trump if Trump becomes the Republican Party nominee. Doocy&#8217;s remarks on ...

## Muslim Group, Principals Union Say School System Lied To Stop Parents From Opting Their Children Out Of Transgender Lessons
 - [https://www.dailywire.com/news/muslim-group-principals-union-say-school-system-lied-to-stop-parents-from-opting-their-children-out-of-transgender-lessons](https://www.dailywire.com/news/muslim-group-principals-union-say-school-system-lied-to-stop-parents-from-opting-their-children-out-of-transgender-lessons)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T17:55:03+00:00

The Council on American-Islamic Relations (CAIR) also obtained documents showing that a labor union representing principals harbored similar concerns, with the principals saying that Montgomery County Public Schools (MCPS) was publicly telling parents it wouldn’t indoctrinate kids, then forcing principals to take the heat for doing the opposite.

## Biden’s Preachy Gun Control Post Hits A Hunter-Shaped Roadblock
 - [https://www.dailywire.com/news/bidens-preachy-gun-control-post-hits-a-hunter-shaped-roadblock](https://www.dailywire.com/news/bidens-preachy-gun-control-post-hits-a-hunter-shaped-roadblock)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T17:36:41+00:00

President Joe Biden called for more extensive gun control legislation in a recent post on X, ostensibly to keep children in schools safer — but ran straight into his own son&#8217;s trouble with existing federal laws regarding firearms. Biden&#8217;s post called on Congress to act, saying &#8220;Yes, there&#8217;s a right to bear arms. But our ...

## Sununu On GOP Primary: ‘I Will Do Everything I Can To Help Narrow The Field’
 - [https://www.dailywire.com/news/sununu-on-gop-primary-i-will-do-everything-i-can-to-help-narrow-the-field](https://www.dailywire.com/news/sununu-on-gop-primary-i-will-do-everything-i-can-to-help-narrow-the-field)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T17:27:30+00:00

New Hampshire Governor Chris Sununu said in an op-ed this week that Republican presidential candidates should meet two requirements by the end of the year or leave the race — and if they don&#8217;t, he&#8217;ll do &#8220;everything&#8221; he can as governor of the key primary state to force them out. Writing in The New York Times ...

## Police Release California Smash And Grab Suspect To Hospital As City Scrambles To Combat Theft
 - [https://www.dailywire.com/news/police-release-california-smash-and-grab-suspect-to-hospital-as-city-scrambles-to-combat-theft](https://www.dailywire.com/news/police-release-california-smash-and-grab-suspect-to-hospital-as-city-scrambles-to-combat-theft)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T17:23:22+00:00

Police have released to the hospital an alleged robber in one of the Los Angeles area&#8217;s recent smash-and-grab robberies as the city scrambles to curtail rampant retail theft. The Glendale Police Department released Ivan Isaac Ramirez on Thursday to a local hospital to address his &#8220;health issues&#8221; after he was arrested earlier in the day ...

## Bradley Cooper Says He’s Lucky To Have Gotten Sober After Battle With Drugs, Alcohol
 - [https://www.dailywire.com/news/bradley-cooper-says-hes-lucky-to-have-gotten-sober-after-battle-with-drugs-alcohol](https://www.dailywire.com/news/bradley-cooper-says-hes-lucky-to-have-gotten-sober-after-battle-with-drugs-alcohol)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T16:55:46+00:00

Superstar Bradley Cooper didn&#8217;t beat around the bush and said he&#8217;s lucky to have been sober — for nearly 20 years now — following a battle with alcohol and drug addiction early in his career. During the 48-year-old actor&#8217;s appearance on &#8220;Running Wild With Bear Grylls: The Challenge,&#8221; Cooper opened up about his sobriety and ...

## Canada’s ‘Mass Graves’ Hoax Is Yet Another Fabricated Narrative To Demonize Christians
 - [https://www.dailywire.com/news/canadas-mass-graves-hoax-is-yet-another-fabricated-narrative-to-demonize-christians](https://www.dailywire.com/news/canadas-mass-graves-hoax-is-yet-another-fabricated-narrative-to-demonize-christians)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T16:45:44+00:00

A couple months ago, on the first day of a major Islamic religious holiday, a man casually walked up to a mosque in Stockholm, Sweden. With hundreds of people looking on, he produced a Koran and began ripping out the pages. He wiped a few of these pages on his shoe. Then, the man set ...

## CNN Analyst Torches Special Counsel, DOJ For Making ‘An Unholy Mess’ Of Hunter Biden Case
 - [https://www.dailywire.com/news/cnn-analyst-torches-special-counsel-doj-for-making-an-unholy-mess-of-hunter-biden-case](https://www.dailywire.com/news/cnn-analyst-torches-special-counsel-doj-for-making-an-unholy-mess-of-hunter-biden-case)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:58:28+00:00

CNN legal analyst Elie Honig held nothing back during a Monday appearance on &#8220;CNN This Morning,&#8221; claiming that newly-appointed Special Counsel David Weiss and the Justice Department had made &#8220;an unholy mess&#8221; of the investigation into President Joe Biden&#8217;s son Hunter Biden. Honig spoke with host Poppy Harlow about Weiss&#8217; long history with the case, ...

## Georgia Ban On Hormone Treatment For Minors Blocked By Federal Judge
 - [https://www.dailywire.com/news/georgia-ban-on-hormone-treatment-for-minors-blocked-by-federal-judge](https://www.dailywire.com/news/georgia-ban-on-hormone-treatment-for-minors-blocked-by-federal-judge)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:54:16+00:00

A federal judge in Georgia temporarily blocked part of a new state law that bans medical providers from performing most sex-change procedures on minors after the legislation took effect last month. U.S. District Court Judge Sarah Geraghty in the Northern District of Georgia granted a preliminary injunction on Senate Bill 140 that bans providing gender ...

## Nikki Haley Bashes Ramaswamy For Saying He’d Cut Aid To Israel
 - [https://www.dailywire.com/news/nikki-haley-bashes-ramaswamy-for-saying-hed-cut-aid-to-israel](https://www.dailywire.com/news/nikki-haley-bashes-ramaswamy-for-saying-hed-cut-aid-to-israel)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:42:11+00:00

Former U.N. Ambassador to the United Nations Nikki Haley, who is running for the Republican presidential nomination, slammed fellow GOP candidate Vivek Ramaswamy for saying he would cut aid to Israel by 2028 if he were elected president. Israel receives nearly $4 billion a year in military aid from the U.S., but nearly all of ...

## ‘One-Way Street’: Kevin Sorbo Says Hollywood Canceled Him Because He’s ‘Christian’ And ‘Conservative’
 - [https://www.dailywire.com/news/one-way-street-kevin-sorbo-says-hollywood-canceled-him-because-hes-christian-and-conservative](https://www.dailywire.com/news/one-way-street-kevin-sorbo-says-hollywood-canceled-him-because-hes-christian-and-conservative)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:31:24+00:00

Kevin Sorbo said he was dropped by his agent and canceled by Hollywood because he&#8217;s a &#8220;Christian&#8221; and &#8220;conservative&#8221; after his career had taken off following his role in the &#8217;90s TV show &#8220;Hercules.&#8221; The 64-year-old actor told Fox News that he was &#8220;blackballed&#8221; in the entertainment industry, and his agent and manager told him ...

## California College Professors Sue Over State DEI Requirements
 - [https://www.dailywire.com/news/california-college-professors-sue-over-state-dei-requirements](https://www.dailywire.com/news/california-college-professors-sue-over-state-dei-requirements)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:29:26+00:00

Six California college professors are suing the state over diversity, equity, inclusion, and accessibility (DEIA) requirements they say force them to take the government&#8217;s view on “politically charged” topics.  The professors, from three Fresno-area community colleges, are being represented by the Foundation for Individual Rights and Expression (FIRE), which filed the lawsuit in federal court ...

## Illegal Immigrant Encounters Spike At Northern Border
 - [https://www.dailywire.com/news/illegal-immigrant-encounters-spike-at-northern-border](https://www.dailywire.com/news/illegal-immigrant-encounters-spike-at-northern-border)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T15:25:09+00:00

Illegal immigrant encounters on the United States’ northern border spiked approximately 36% in July, recently released federal data reveals. According to U.S. Customs and Border Protection, a total of 1,154 encounters near the northern border were recorded for July, up from 848 in June. The majority of those come from countries in Latin America. While ...

## Judge Blocks 3 New Jersey School Districts From Enforcing Mandatory Parental Notification Gender Policy
 - [https://www.dailywire.com/news/judge-blocks-3-new-jersey-school-districts-from-enforcing-mandatory-parental-notification-gender-policy](https://www.dailywire.com/news/judge-blocks-3-new-jersey-school-districts-from-enforcing-mandatory-parental-notification-gender-policy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T14:44:26+00:00

A New Jersey state judge last week blocked three school districts from enforcing a policy requiring schools to notify parents if their child changes their gender identity. On Friday, Judge David Bauman issued a preliminary injunction against the new gender transition policy recently adopted by the Manalapan-Englishtown, Marlboro, and Middletown school districts. “The state has ...

## Hilary Brings Record Rains To California: ‘Unlike Anything Our Community Has Faced Before’
 - [https://www.dailywire.com/news/hilary-brings-record-rains-to-california-unlike-anything-our-community-has-faced-before](https://www.dailywire.com/news/hilary-brings-record-rains-to-california-unlike-anything-our-community-has-faced-before)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T14:38:26+00:00

Parts of California have seen record rains from Tropical Storm Hilary after it made landfall on Sunday as Southern California faced its first tropical storm in more than 80 years.  Hilary, previously a category 4 hurricane, first reached land on Sunday, hitting Mexico and Southern California. At least one person died in Mexico and the ...

## Wynonna Judd Announces Throwback Tour, Says Music ‘Is Healing’ Her After Mom’s Death
 - [https://www.dailywire.com/news/wynonna-judd-announces-throwback-tour-says-music-is-healing-her-after-moms-death](https://www.dailywire.com/news/wynonna-judd-announces-throwback-tour-says-music-is-healing-her-after-moms-death)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T14:04:46+00:00

Wynonna Judd announced a throwback tour on Monday celebrating her first two albums, saying music has helped heal her following the death of her mom Naomi last year. The 59-year-old country singer shared a post on X about the &#8220;Back to Wy Tour,&#8221; which kicks off October 26 in Indianapolis, Indiana. &#8220;Two words&#8230;NUH-STALGIA,&#8221; Judd wrote. ...

## Biden’s ATF Has Revoked Hundreds Of Licenses In Crackdown On Gun Dealers
 - [https://www.dailywire.com/news/bidens-atf-has-revoked-hundreds-of-licenses-in-crackdown-on-gun-dealers](https://www.dailywire.com/news/bidens-atf-has-revoked-hundreds-of-licenses-in-crackdown-on-gun-dealers)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T13:33:41+00:00

The Biden administration has rescinded the licenses of hundreds of gun dealers in a crackdown on an industry that law enforcement has previously seen as a key ally. The Bureau of Alcohol, Tobacco, Firearms, and Explosives (ATF) has revoked the licenses of 122 gun dealers so far this fiscal year on top of the 90 ...

## Accused Idaho Killer Continues To Argue About DNA Found On Knife Sheath At Crime Scene
 - [https://www.dailywire.com/news/accused-idaho-killer-continues-to-argue-about-dna-found-on-knife-sheath-at-crime-scene](https://www.dailywire.com/news/accused-idaho-killer-continues-to-argue-about-dna-found-on-knife-sheath-at-crime-scene)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T12:47:54+00:00

A defense attorney for the 28-year-old man accused of killing four University of Idaho students continues to question the validity of DNA found on a knife sheath at the crime scene. Anne Taylor, the defense attorney, on Friday again argued that the prosecution had not provided full DNA information from the crime, CBS News reported. ...

## 18-Year-Old Arrested For Allegedly Killing 11-Year-Old Texas Girl
 - [https://www.dailywire.com/news/18-year-old-arrested-for-allegedly-killing-11-year-old-texas-girl](https://www.dailywire.com/news/18-year-old-arrested-for-allegedly-killing-11-year-old-texas-girl)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T12:11:15+00:00

An 18-year-old has been arrested for allegedly sexually assaulting and murdering an 11-year-old Texas girl. Juan Carlos Garcia-Rodriguez, 18, was arrested this weekend by the Shreveport Police Department in Louisiana and is expected to be charged with capital murder, KHOU 11 reported. He is currently awaiting extradition back to Pasadena, Texas. Pasadena Police Chief Josh ...

## New Document May Lead To Joe Biden’s Direct Involvement In Corruption
 - [https://www.dailywire.com/news/new-document-may-lead-to-joe-bidens-direct-involvement-in-corruption](https://www.dailywire.com/news/new-document-may-lead-to-joe-bidens-direct-involvement-in-corruption)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T12:10:43+00:00

Last week, the House Oversight Committee released a bombshell letter to the Archivist of the United States at the National Archives and Records Administration, asking for all records and emails related to a particular email address. The email address was not the official email address that Joe Biden used when he was vice president of ...

## Charlize Theron Denies Plastic Surgery Rumors: ‘I’m Just Aging!’
 - [https://www.dailywire.com/news/charlize-theron-denies-plastic-surgery-rumors-im-just-aging](https://www.dailywire.com/news/charlize-theron-denies-plastic-surgery-rumors-im-just-aging)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T11:54:00+00:00

Actress Charlize Theron says she hasn&#8217;t had plastic surgery or put fillers in her face, despite rumors claiming she has. &#8220;My face is changing, and I love that my face is changing and aging,&#8221; the 48-year-old actress said in a recent interview with Allure. Theron went on to address speculation running rampant among her fan ...

## British Nurse Sentenced For Murdering Infants Under Her Care
 - [https://www.dailywire.com/news/british-nurse-sentenced-for-murdering-infants-under-her-care](https://www.dailywire.com/news/british-nurse-sentenced-for-murdering-infants-under-her-care)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T11:22:12+00:00

A British nurse convicted last week of murdering seven infants between 2015 and 2016 and attempting to murder six more has been sentenced to life in prison. The 33-year-old nurse, who will not be named per Daily Wire policy, became the United Kingdom’s worst serial killer of babies in recent times after she was convicted ...

## Britney Spears’ Estranged Husband Jokes About Paparazzi While She Posts About ‘Pain’ Amid Divorce
 - [https://www.dailywire.com/news/britney-spears-estranged-husband-jokes-about-paparazzi-while-she-posts-about-pain-amid-divorce](https://www.dailywire.com/news/britney-spears-estranged-husband-jokes-about-paparazzi-while-she-posts-about-pain-amid-divorce)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T10:57:38+00:00

Pop star Britney Spears posted about her “pain” on social media as she goes through another divorce, while her estranged husband Hesam &#8220;Sam&#8221; Asghari joked about the need to hide from paparazzi.  “Help me choose paparazzi disguise,” Asghari, a 29-year-old Iranian-born model, shared on Instagram stories Saturday. It included Asghari sporting three options, including gray ...

## Russian Spacecraft Crashes Into Moon During First Lunar Mission In Almost 50 Years
 - [https://www.dailywire.com/news/russian-spacecraft-crashes-into-moon-during-first-lunar-mission-in-almost-50-years](https://www.dailywire.com/news/russian-spacecraft-crashes-into-moon-during-first-lunar-mission-in-almost-50-years)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T10:49:14+00:00

A Russian spacecraft crashed into the moon over the weekend, days before scientists had planned to land the craft there to test landing technology and search for water.  The Luna-25 lander was supposed to be the first Russian craft to reach the moon since the 1970s, but Russian scientists lost contact during the mission, and ...

## Dealer Who Sold Actor Michael K. Williams Fatal Dose Of Heroin Sentenced To 10 Years In Prison
 - [https://www.dailywire.com/news/dealer-who-sold-actor-michael-k-williams-fatal-dose-of-heroin-sentenced-to-10-years-in-prison](https://www.dailywire.com/news/dealer-who-sold-actor-michael-k-williams-fatal-dose-of-heroin-sentenced-to-10-years-in-prison)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T10:48:44+00:00

A man was sentenced to ten years in prison over the sale of fentanyl-laced heroin that led to the death of “The Wire” actor Michael K. Williams. Irvin “Green Eyes” Cartagena is originally from Puerto Rico. He received the sentence, including five years of supervised release, for conspiring to distribute heroin, fentanyl, and fentanyl analogue, according ...

## Chicago Dem Promotes Solution For Insane Homicide Rate: Ask Gangs To Only Shoot At Night
 - [https://www.dailywire.com/news/chicago-dem-promotes-solution-for-insane-homicide-rate-ask-gangs-to-only-shoot-at-night](https://www.dailywire.com/news/chicago-dem-promotes-solution-for-insane-homicide-rate-ask-gangs-to-only-shoot-at-night)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T10:22:34+00:00

A Democrat politician in Chicago promoted a novel suggestion to address the city’s insane homicide rate: ask gang members to restrict their shootings to the evening hours. Maria Hadden, a Chicago alderwoman — aldermen and women are elected by their constituencies to serve a four-year term —sent an email in which she promoted a proposal from ...

## Afghanistan Gold Star Mom: I Wept, Wanted Comfort From Biden. He Suggested A Photo With Him Instead.
 - [https://www.dailywire.com/news/afghanistan-gold-star-mom-i-wept-wanted-comfort-from-biden-he-suggested-a-photo-with-him-instead](https://www.dailywire.com/news/afghanistan-gold-star-mom-i-wept-wanted-comfort-from-biden-he-suggested-a-photo-with-him-instead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T09:18:37+00:00

A Gold Star mother who met President Joe Biden on the Memorial Day following her son’s death from the terrorist attack at the Kabul airport said that Biden responded by suggesting she take a photo with him when she wept during their meeting. Army Staff Sgt. Ryan Christian Knauss was killed when a bomber detonated ...

## Weekend Media Wrap, Vol. 5: What You Missed If You Weren’t Glued To The Sunday Shows
 - [https://www.dailywire.com/news/weekend-media-wrap-vol-5-what-you-missed-if-you-werent-glued-to-the-sunday-shows](https://www.dailywire.com/news/weekend-media-wrap-vol-5-what-you-missed-if-you-werent-glued-to-the-sunday-shows)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-08-21T08:14:02+00:00

Every Sunday morning, legacy media outlets are taken over by elected officials, aspiring elected officials, administration insiders, and the usual collection of talking heads — all of whom are there to discuss specific policies, push talking points, or simply promote their own campaigns. For those who don&#8217;t spend their Sunday mornings glued to the television ...

