# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Israeli missile fire allegedly injures soldier near Syrian capital Damascus
 - [https://www.aljazeera.com/news/2023/8/21/israeli-missile-fire-allegedly-injures-soldier-near-syrian-capital-damascus](https://www.aljazeera.com/news/2023/8/21/israeli-missile-fire-allegedly-injures-soldier-near-syrian-capital-damascus)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T23:41:14+00:00

The missile fire is the latest attack in an ongoing shadow conflict unfolding in Syria between Israel and Iran.

## Georgia judge sets bond at $200,000 for former US President Donald Trump
 - [https://www.aljazeera.com/news/2023/8/21/georgia-judge-sets-bond-at-two-hundred-thousand-dollars-for-former-us-president-donald-trump](https://www.aljazeera.com/news/2023/8/21/georgia-judge-sets-bond-at-two-hundred-thousand-dollars-for-former-us-president-donald-trump)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T22:41:20+00:00

The bond agreement comes ahead of a deadline for Trump and his 18 co-defendants to surrender on Friday to Fulton County.

## Strike, protests in Syria’s Sweida enter second day
 - [https://www.aljazeera.com/news/2023/8/21/strike-protests-in-syrias-sweida-enter-second-day](https://www.aljazeera.com/news/2023/8/21/strike-protests-in-syrias-sweida-enter-second-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T20:42:49+00:00

Routes into the city remain closed on Monday as protests break out over deteriorating living conditions.

## Wagner boss posts first video since Russia mutiny, hints he’s in Africa
 - [https://www.aljazeera.com/news/2023/8/21/wagner-boss-posts-first-video-since-russia-mutiny-hints-hes-in-africa](https://www.aljazeera.com/news/2023/8/21/wagner-boss-posts-first-video-since-russia-mutiny-hints-hes-in-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T20:39:30+00:00

Yevgeny Prigozhin says mercenary group is recruiting people and &#039;will fulfil the tasks that were set&#039;.

## What went wrong with the Luna 25?
 - [https://www.aljazeera.com/program/inside-story/2023/8/21/what-went-wrong-with-the-luna-25](https://www.aljazeera.com/program/inside-story/2023/8/21/what-went-wrong-with-the-luna-25)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T20:07:40+00:00

The Russian spacecraft crashed instead of making a soft landing at the lunar south pole.

## US Republican candidates clash over support for Israel
 - [https://www.aljazeera.com/news/2023/8/21/us-republican-candidates-clash-over-support-for-israel](https://www.aljazeera.com/news/2023/8/21/us-republican-candidates-clash-over-support-for-israel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T19:57:35+00:00

With first 2024 presidential debate days away, former UN envoy Nikki Haley hits out at Vivek Ramaswamy&#039;s Israel remarks.

## Somalia bans TikTok and Telegram over ‘horrific’ content, misinformation
 - [https://www.aljazeera.com/news/2023/8/21/somalia-bans-tiktok-and-telegram-over-horrific-content-misinformation](https://www.aljazeera.com/news/2023/8/21/somalia-bans-tiktok-and-telegram-over-horrific-content-misinformation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T19:08:00+00:00

Armed group al-Shabab, which wages a war against the Somali state, uses the platforms to post its activities.

## ‘Historic’: Ecuador voters reject oil drilling in Amazon protected area
 - [https://www.aljazeera.com/news/2023/8/21/historic-ecuador-voters-reject-oil-drilling-in-amazon-protected-area](https://www.aljazeera.com/news/2023/8/21/historic-ecuador-voters-reject-oil-drilling-in-amazon-protected-area)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T18:18:28+00:00

Nearly 60 percent of voters back a push to halt to drilling in Yasuni National Park, a victory for environmental groups.

## Calls for smooth transition as Arevalo wins Guatemala presidential election
 - [https://www.aljazeera.com/news/2023/8/21/calls-for-smooth-transition-as-arevalo-wins-guatemala-presidential-election](https://www.aljazeera.com/news/2023/8/21/calls-for-smooth-transition-as-arevalo-wins-guatemala-presidential-election)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T18:04:31+00:00

Left-wing candidate Bernardo Arevalo&#039;s landslide victory could face challenges despite wide margin.

## The first Republican presidential debate is nearly here. But why so early?
 - [https://www.aljazeera.com/news/2023/8/21/the-first-republican-presidential-debate-is-nearly-here-but-why-so-early](https://www.aljazeera.com/news/2023/8/21/the-first-republican-presidential-debate-is-nearly-here-but-why-so-early)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T16:29:00+00:00

First Republican debate comes amid so-called &#039;invisible primary&#039;, when candidates shore up support ahead of state votes.

## Hawaiian official says 850 on wildfire missing list ahead of Biden visit
 - [https://www.aljazeera.com/news/2023/8/21/hawaii-official-says-850-on-wildfire-missing-list-ahead-of-biden-visit](https://www.aljazeera.com/news/2023/8/21/hawaii-official-says-850-on-wildfire-missing-list-ahead-of-biden-visit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T15:57:09+00:00

Wildfires on Maui have killed at least 114 people, but emergency workers are still searching through the destruction.

## Behind Mohammed VI’s push for a more Amazigh Morocco
 - [https://www.aljazeera.com/news/2023/8/21/behind-mohammed-vis-push-for-a-more-amazigh-morocco](https://www.aljazeera.com/news/2023/8/21/behind-mohammed-vis-push-for-a-more-amazigh-morocco)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T15:34:21+00:00

Amazigh identity, culture and language have been promoted by the state in recent years, a reversal of past policies.

## Mason Greenwood to leave Manchester United following investigation
 - [https://www.aljazeera.com/sports/2023/8/21/mason-greenwood-to-leave-manchester-united-following-investigation](https://www.aljazeera.com/sports/2023/8/21/mason-greenwood-to-leave-manchester-united-following-investigation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T15:12:51+00:00

Greenwood says decision good for both parties after months-long investigation into allegations of attempted rape.

## Kenya’s young Maasai reconnect with their culture at Eunoto ceremony
 - [https://www.aljazeera.com/gallery/2023/8/21/kenyas-young-maasai-reconnect-with-their-culture-at-eunoto-ceremony](https://www.aljazeera.com/gallery/2023/8/21/kenyas-young-maasai-reconnect-with-their-culture-at-eunoto-ceremony)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T14:50:05+00:00

The five-day coming-of-age ritual features traditional chants, dances and the famous Maasai jump.

## UAE says not flouting ally sanctions as its economy warms to Russia
 - [https://www.aljazeera.com/news/2023/8/21/uae-says-not-flouting-ally-sanctions-as-its-economy-warms-to-russia](https://www.aljazeera.com/news/2023/8/21/uae-says-not-flouting-ally-sanctions-as-its-economy-warms-to-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T14:33:58+00:00

WSJ claims the UAE is benefitting from the war in Ukraine, providing a refuge for Russian money.

## The legacy of chemical attacks and other atrocities won’t give Syria peace
 - [https://www.aljazeera.com/opinions/2023/8/21/the-legacy-of-chemical-attacks-and-other-atrocities-wont-give-syria-peace](https://www.aljazeera.com/opinions/2023/8/21/the-legacy-of-chemical-attacks-and-other-atrocities-wont-give-syria-peace)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:52:28+00:00

Despite the normalisation efforts by Arab states, Syria will not be stabilised until there is justice for war crimes.

## India blocks independent news outlet The Kashmir Walla
 - [https://www.aljazeera.com/news/2023/8/21/india-blocks-independent-news-outlet-the-kashmir-walla](https://www.aljazeera.com/news/2023/8/21/india-blocks-independent-news-outlet-the-kashmir-walla)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:39:30+00:00

The Kashmir Walla says its website and social media accounts have become inaccessible in India.

## ‘My Fears and Hatred’: Navalny lambasts the 1990s democrats of Russia
 - [https://www.aljazeera.com/features/2023/8/21/my-fear-and-hatred-navalny-lambasts-russias-democrats-of-the-1990s](https://www.aljazeera.com/features/2023/8/21/my-fear-and-hatred-navalny-lambasts-russias-democrats-of-the-1990s)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:34:40+00:00

Jailed opposition leader slams those charged with rebuilding Russia&#039;s politics and economy after the Soviet collapse.

## Why did Zambia seize a mystery plane filled with cash, guns and metals?
 - [https://www.aljazeera.com/news/2023/8/21/why-did-zambia-seize-a-mystery-plane-filled-with-cash-guns-and-metals](https://www.aljazeera.com/news/2023/8/21/why-did-zambia-seize-a-mystery-plane-filled-with-cash-guns-and-metals)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:26:11+00:00

Details of the plane&#039;s flightpaths and passengers were uncovered by an Egyptian journalist who was later arrested.

## Lucy Letby, UK nurse who killed seven babies, sentenced to life in prison
 - [https://www.aljazeera.com/news/2023/8/21/lucy-letby-uk-nurse-who-killed-seven-babies-sentenced-to-life-in-prison](https://www.aljazeera.com/news/2023/8/21/lucy-letby-uk-nurse-who-killed-seven-babies-sentenced-to-life-in-prison)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:19:22+00:00

Lucy Letby, who also attempted to kill several more newborns, to spend rest of her life in jail.

## Five must-see films on the unsung heroes of women’s football
 - [https://www.aljazeera.com/news/2023/8/21/five-must-see-films-on-the-unsung-heroes-of-womens-football](https://www.aljazeera.com/news/2023/8/21/five-must-see-films-on-the-unsung-heroes-of-womens-football)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T13:00:45+00:00

These powerful stories of women breaking ground on and off the pitch are the best antidote to World Cup withdrawal.

## Japan set to decide on Fukushima water discharge on Tuesday
 - [https://www.aljazeera.com/news/2023/8/21/japan-set-to-decide-on-fukushima-water-discharge-on-tuesday](https://www.aljazeera.com/news/2023/8/21/japan-set-to-decide-on-fukushima-water-discharge-on-tuesday)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T12:00:26+00:00

Gov&#039;t to decide when to begin discharge of treated radioactive water from the Fukushima nuclear plant into the ocean.

## Spanish football chief criticised for kissing women’s team player
 - [https://www.aljazeera.com/news/2023/8/21/spanish-football-chief-criticised-over-kissing-player](https://www.aljazeera.com/news/2023/8/21/spanish-football-chief-criticised-over-kissing-player)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T11:09:22+00:00

Luis Rubiales condemned for kissing Spanish midfielder Jenni Hermoso at the World Cup&#039;s victory celebrations.

## Saudi Arabia rejects accusations of killing Ethiopians at Yemen border
 - [https://www.aljazeera.com/news/2023/8/21/saudi-arabia-rejects-accusations-of-killing-ethiopians-at-yemen-border](https://www.aljazeera.com/news/2023/8/21/saudi-arabia-rejects-accusations-of-killing-ethiopians-at-yemen-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T10:57:48+00:00

The kingdom has refuted a report that alleged possible crimes against humanity at the country&#039;s southern borders.

## Women’s World Cup champions Spain set for long run among football’s elite
 - [https://www.aljazeera.com/sports/2023/8/21/womens-world-cup-champions-spain-football-elite](https://www.aljazeera.com/sports/2023/8/21/womens-world-cup-champions-spain-football-elite)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T10:54:37+00:00

Spain&#039;s victory in the 2023 Women&#039;s World Cup shows the rest of the world is catching up to the traditional powers.

## ‘The sleeping giant has awoken’: The legacy of the 2023 Women’s World Cup
 - [https://www.aljazeera.com/sports/2023/8/21/the-legacy-of-the-2023-womens-world-cup-australia-new-zealand](https://www.aljazeera.com/sports/2023/8/21/the-legacy-of-the-2023-womens-world-cup-australia-new-zealand)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T10:25:48+00:00

As the record-breaking 2023 Women&#039;s World Cup ends, many see an exciting future - and many challenges - for the game

## ‘People foaming at the mouth’: 10 years since chemical attacks in Ghouta
 - [https://www.aljazeera.com/news/2023/8/21/people-foaming-at-the-mouth-10-years-since-chemical-attacks-in-ghouta](https://www.aljazeera.com/news/2023/8/21/people-foaming-at-the-mouth-10-years-since-chemical-attacks-in-ghouta)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T09:56:20+00:00

In 2013, the Syrian regime attacked the towns of Zamalka, Ein Tarma, and Irbin in Ghouta countryside with a nerve agent.

## Canada to deploy army to help fight wildfires in British Columbia
 - [https://www.aljazeera.com/news/2023/8/21/canada-to-deploy-army-to-help-fight-wildfires-in-british-columbia](https://www.aljazeera.com/news/2023/8/21/canada-to-deploy-army-to-help-fight-wildfires-in-british-columbia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T09:12:18+00:00

PM Justin Trudeau says military to be sent to the fire-hit region as a state of emergency declared in British Columbia.

## Ecuador elections headed for run-off with leftist Gonzalez in lead
 - [https://www.aljazeera.com/news/2023/8/21/ecuador-elections-headed-for-run-off-with-leftist-gonzalez-in-lead](https://www.aljazeera.com/news/2023/8/21/ecuador-elections-headed-for-run-off-with-leftist-gonzalez-in-lead)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T08:59:33+00:00

The vote will be held on October 15 between Luisa Gonzalez and entrepreneur Daniel Noboa.

## Germany arrests two US soldiers after man stabbed to death at funfair
 - [https://www.aljazeera.com/news/2023/8/21/germany-arrests-two-us-soldiers-after-man-stabbed-to-death-at-funfair](https://www.aljazeera.com/news/2023/8/21/germany-arrests-two-us-soldiers-after-man-stabbed-to-death-at-funfair)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T08:48:11+00:00

The murder occurred when an altercation broke out between several people at a funfair in the small town of Wittlich.

## X Blue users will need to send selfie, data to Israeli software company
 - [https://www.aljazeera.com/news/2023/8/21/x-blue-users-will-need-to-send-selfie-data-to-israeli-software-company](https://www.aljazeera.com/news/2023/8/21/x-blue-users-will-need-to-send-selfie-data-to-israeli-software-company)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T08:28:57+00:00

Subscription users of X, formerly Twitter, will need to send a selfie and copy of ID to an Israeli verification company.

## One Israeli dead, one wounded in shooting near Hebron
 - [https://www.aljazeera.com/news/2023/8/21/one-israeli-dead-one-wounded-in-shooting-near-hebron](https://www.aljazeera.com/news/2023/8/21/one-israeli-dead-one-wounded-in-shooting-near-hebron)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T08:27:15+00:00

Israeli army has set up roadblocks around Hebron, questioning all Palestinians as manhunt for shooter launched.

## South Africa won’t be bullied to side with global powers, says Ramaphosa
 - [https://www.aljazeera.com/news/2023/8/21/south-africa-wont-be-bullied-to-side-with-global-powers-says-ramaphosa](https://www.aljazeera.com/news/2023/8/21/south-africa-wont-be-bullied-to-side-with-global-powers-says-ramaphosa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T08:08:56+00:00

Ramaphosa was speaking in a televised address before the BRICS summit which begins Tuesday in Johannesburg.

## Thailand’s Pheu Thai to ally with military rivals to form new government
 - [https://www.aljazeera.com/news/2023/8/21/thailands-pheu-thai-to-ally-with-military-rivals-to-form-new-government](https://www.aljazeera.com/news/2023/8/21/thailands-pheu-thai-to-ally-with-military-rivals-to-form-new-government)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T07:21:02+00:00

Move comes as Pheu Thai founder Thaksin Shinawatra prepares to return home after 15 years in self-imposed exile.

## Who stole the Mona Lisa?
 - [https://www.aljazeera.com/gallery/2023/8/21/history-illustrated-who-stole-the-mona-lisa](https://www.aljazeera.com/gallery/2023/8/21/history-illustrated-who-stole-the-mona-lisa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T07:11:36+00:00

In what would come to be known as the &#039;art heist of the century&#039;, the plan was as audacious as it was simple.

## China’s central bank cuts key interest rate amid concerns for economy
 - [https://www.aljazeera.com/economy/2023/8/21/chinas-central-bank-cuts-key-interest-rate-amid-concerns-for-economy](https://www.aljazeera.com/economy/2023/8/21/chinas-central-bank-cuts-key-interest-rate-amid-concerns-for-economy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T07:04:03+00:00

People&#039;s Bank of China&#039;s decision to leave 5-year lending rate unchanged greeted with disappointment by markets.

## To beat the heat in Northwestern Syria, people head for the water
 - [https://www.aljazeera.com/news/2023/8/21/to-beat-the-heat-in-northwestern-syria-people-head-for-the-water](https://www.aljazeera.com/news/2023/8/21/to-beat-the-heat-in-northwestern-syria-people-head-for-the-water)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T06:56:43+00:00

In a region decimated by an earthquake and populated mostly by IDPs, the intense heat is making life harder than

## Saudi guards kill, abuse refugees at border with Yemen: HRW
 - [https://www.aljazeera.com/news/2023/8/21/hrw-report-details-saudi-arabian-guards-killing-refugees-at-yemen-border](https://www.aljazeera.com/news/2023/8/21/hrw-report-details-saudi-arabian-guards-killing-refugees-at-yemen-border)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T06:43:11+00:00

Rights group has documented targeting refugees by firearms, explosive weapons when trying to cross into Saudi Arabia.

## Why China is grappling with falling prices – and being compared to Japan
 - [https://www.aljazeera.com/economy/2023/8/21/why-china-is-grappling-with-falling-prices-and-being-compared-to-japan](https://www.aljazeera.com/economy/2023/8/21/why-china-is-grappling-with-falling-prices-and-being-compared-to-japan)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T05:40:01+00:00

The world’s second-largest economy is grappling with deflation, raising fears of Japan-style stagnation.

## Trump confirms won’t join this week’s Republican presidential debates
 - [https://www.aljazeera.com/news/2023/8/21/trump-confirms-wont-join-this-weeks-republican-presidential-debates](https://www.aljazeera.com/news/2023/8/21/trump-confirms-wont-join-this-weeks-republican-presidential-debates)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T05:12:24+00:00

Former president claims he is so well known among the public, he does not need to participate.

## I saw the tarmac murder that haunts the Philippines 40 years later
 - [https://www.aljazeera.com/opinions/2023/8/21/i-saw-the-tarmac-murder-that-haunts-the-philippines-40-years-later](https://www.aljazeera.com/opinions/2023/8/21/i-saw-the-tarmac-murder-that-haunts-the-philippines-40-years-later)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T05:06:01+00:00

Benigno Aquino Jr&#039;s killing sparked the revolt that ousted Ferdinand Marcos, the autocrat whose son now rules the nation

## China-brokered Saudi-Iran deal driving ‘wave of reconciliation’, says Wang
 - [https://www.aljazeera.com/news/2023/8/21/china-brokered-saudi-iran-deal-driving-wave-of-reconciliation-says-wang](https://www.aljazeera.com/news/2023/8/21/china-brokered-saudi-iran-deal-driving-wave-of-reconciliation-says-wang)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T04:13:43+00:00

Beijing&#039;s top diplomat lauds improving ties between Iran and Saudi Arabia, calls for full resumption of nuclear deal.

## Arevalo wins Guatemala presidency in landslide amid hopes for change
 - [https://www.aljazeera.com/news/2023/8/21/arevalo-wins-guatemala-presidency-in-landslide-amid-hopes-for-change](https://www.aljazeera.com/news/2023/8/21/arevalo-wins-guatemala-presidency-in-landslide-amid-hopes-for-change)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T03:52:18+00:00

Anti-corruption campaigner promises to tackle widespread corruption and violence that has fuelled migration to the US.

## Tropical Storm Hilary drenches usually arid southern California
 - [https://www.aljazeera.com/news/2023/8/21/tropical-storm-hilary-drenches-usually-arid-southern-california](https://www.aljazeera.com/news/2023/8/21/tropical-storm-hilary-drenches-usually-arid-southern-california)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T03:37:07+00:00

California Governor Gavin Newsom declares state of emergency as rare storm brings unprecedented rain.

## Kim Jong Un oversees cruise missile test, S Korea-US military drills start
 - [https://www.aljazeera.com/news/2023/8/21/kim-jong-un-oversees-cruise-missile-test-s-korea-us-military-drills-start](https://www.aljazeera.com/news/2023/8/21/kim-jong-un-oversees-cruise-missile-test-s-korea-us-military-drills-start)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T01:35:01+00:00

North Korean leader has pledged &#039;overwhelming&#039; response to this month&#039;s military exercises by South Korea and US.

## Singapore employers using police to threaten domestic workers, report says
 - [https://www.aljazeera.com/economy/2023/8/21/singapore-employers-using-police-to-control-domestic-workers-report-says](https://www.aljazeera.com/economy/2023/8/21/singapore-employers-using-police-to-control-domestic-workers-report-says)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T01:16:55+00:00

More than 80 percent of police reports made by bosses against their maids do not lead to charges, rights group says.

## Russia-Ukraine war: List of key events, day 544
 - [https://www.aljazeera.com/news/2023/8/21/russia-ukraine-war-list-of-key-events-day-544](https://www.aljazeera.com/news/2023/8/21/russia-ukraine-war-list-of-key-events-day-544)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-08-21T00:26:40+00:00

As the war enters its 544th day, these are the main developments.

