# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## GREG GUTFELD: A made-up pronoun is now a participation trophy for people who can't participate in actual life
 - [https://www.foxnews.com/opinion/greg-gutfeld-made-up-pronoun-now-participation-trophy-people-cant-participate-actual-life](https://www.foxnews.com/opinion/greg-gutfeld-made-up-pronoun-now-participation-trophy-people-cant-participate-actual-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T23:21:16+00:00

&apos;Gutfeld!&apos; panelists react to CNN publishing a story on how to use and understand neopronouns.

## SEAN HANNITY: David Weiss might be a pro-Biden prosecutor
 - [https://www.foxnews.com/media/sean-hannity-david-weiss-might-be-a-pro-biden-prosecutor](https://www.foxnews.com/media/sean-hannity-david-weiss-might-be-a-pro-biden-prosecutor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T22:31:17+00:00

Sean Hannity discusses how prior to the whistleblowers coming forward in the Hunter Biden case, David Weiss was prepared to not charge the president&apos;s son on &quot;Hannity.&quot;

## LAURA INGRAHAM: Democrats don't like or trust the voter
 - [https://www.foxnews.com/media/laura-ingraham-democrats-dont-like-trust-voter](https://www.foxnews.com/media/laura-ingraham-democrats-dont-like-trust-voter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T22:22:02+00:00

Laura Ingraham says Democrats are &quot;terrified&quot; that people will reject Biden and the left&apos;s &quot;illogical views.&quot;

## Coast Guard rescues man stranded on Bahamas island for three days after sailboat breaks down
 - [https://www.foxnews.com/world/coast-guard-rescues-man-stranded-bahamas-island-three-days-after-sailboat-breaks-down](https://www.foxnews.com/world/coast-guard-rescues-man-stranded-bahamas-island-three-days-after-sailboat-breaks-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T22:14:39+00:00

A man stranded on a island in the Caribbean for three days was rescued by the U.S. Coast Guard, authorities said.

## Biden uses minor fire at his house to claim he knows what it's like to lose a home while visiting Maui
 - [https://www.foxnews.com/politics/biden-uses-minor-fire-his-house-claim-he-know-what-its-like-lose-home-while-visiting-maui](https://www.foxnews.com/politics/biden-uses-minor-fire-his-house-claim-he-know-what-its-like-lose-home-while-visiting-maui)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T22:11:09+00:00

President Biden visited Maui on Monday, and while speaking to a crowd, said he has a sense of what it was like to lose a home, recalling a fire in his kitchen nearly 15 years ago.

## WATCH: Hawaii Democrat tries to get Biden to drink water in awkward moment
 - [https://www.foxnews.com/politics/watch-hawaii-democrat-biden-drink-water-awkward-moment](https://www.foxnews.com/politics/watch-hawaii-democrat-biden-drink-water-awkward-moment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:51:38+00:00

President Biden and Democratic Hawaii Sen. Brian Schatz shared an awkward moment when the latter offered a sip of water to the president who just walked away.

## JESSE WATTERS: Hunter Biden flew overseas with his dad at least eight times
 - [https://www.foxnews.com/media/jesse-watters-hunter-biden-flew-overseas-with-dad-at-least-eight-times](https://www.foxnews.com/media/jesse-watters-hunter-biden-flew-overseas-with-dad-at-least-eight-times)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:44:32+00:00

Fox News host Jesse Watters reveals Hunter Biden flew overseas with President Joe Biden at least eight times on &quot;Jesse Watters Primetime.&quot;

## COVID-19 patients face increased health risks for up to 2 years, study finds
 - [https://www.foxnews.com/health/covid-19-patients-face-increased-health-risks-2-years-study-finds](https://www.foxnews.com/health/covid-19-patients-face-increased-health-risks-2-years-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:37:34+00:00

Patients who developed COVID-19 earlier on in the pandemic will experiencing lingering health problems even two years later, according to the results of a new study.

## Spanish FA president Luis Rubiales apologizes for Jenni Hermoso kiss that caused outrage
 - [https://www.foxnews.com/sports/spanish-fa-president-luis-rubiales-apologizes-kiss-jenni-hermoso-caused-outrage](https://www.foxnews.com/sports/spanish-fa-president-luis-rubiales-apologizes-kiss-jenni-hermoso-caused-outrage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:34:38+00:00

Spanish football federation president Luis Rubiales apologized for controversially kissing soccer player Jenni Hermoso during the Women&apos;s World Cup ceremony on Sunday.

## FDA approves first maternal vaccine to prevent RSV, Pfizer's single-dose Abrysvo
 - [https://www.foxnews.com/health/fda-approves-first-maternal-vaccine-prevent-rsv-pfizer-single-dose-abrysvo](https://www.foxnews.com/health/fda-approves-first-maternal-vaccine-prevent-rsv-pfizer-single-dose-abrysvo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:05:53+00:00

The Food and Drug Administration (FDA) has approved the first vaccine for pregnant women to prevent RSV in infants, the agency announced on Monday. Abrysvo is made by Pfizer.

## Knicks sue Raptors, ex-employee who allegedly stole 'proprietary information' before joining Toronto's staff
 - [https://www.foxnews.com/sports/knicks-sue-raptors-ex-employee-allegedly-stole-proprietary-information-joining-torontos-staff](https://www.foxnews.com/sports/knicks-sue-raptors-ex-employee-allegedly-stole-proprietary-information-joining-torontos-staff)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:02:45+00:00

The New York Knicks sued the Toronto Raptors and an ex-employee, among others, after the former worker allegedly stole confidential information prior to joining Toronto&apos;s staff.

## Federal judge temporarily blocks part of a new Georgia law that bans most gender surgeries on minors
 - [https://www.foxnews.com/media/federal-judge-temporarily-blocks-part-new-georgia-law-bans-most-gender-surgeries-minors](https://www.foxnews.com/media/federal-judge-temporarily-blocks-part-new-georgia-law-bans-most-gender-surgeries-minors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T21:00:27+00:00

US District Judge Sarah Geraghty ruled a Georgia law that bars licensed medical professionals from treating minors with cross-sex hormone therapy “likely&quot; unconstitutional.

## Maui home left untouched by wildfires while Lahaina neighborhood destroyed
 - [https://www.foxnews.com/us/maui-home-left-untouched-wildfires-lahaina-neighborhood-destroyed](https://www.foxnews.com/us/maui-home-left-untouched-wildfires-lahaina-neighborhood-destroyed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:53:14+00:00

A home in Maui was left untouched while the surrounding area was destroyed in the wildfires that has killed more than 100 people.

## John Rich defends Oliver Anthony, Jason Aldean as country stars dominate music: 'Guys like us speak the truth'
 - [https://www.foxnews.com/entertainment/john-rich-defends-oliver-anthony-jason-aldean-country-stars-dominate-music](https://www.foxnews.com/entertainment/john-rich-defends-oliver-anthony-jason-aldean-country-stars-dominate-music)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:45:52+00:00

John Rich remembered being a songwriter for Jason Aldean, and celebrated his &quot;patriot&quot; friend for being a &quot;hardworking guy&quot; in the country music industry.

## Mississippi woman sentenced to life for role in beating man to death, possibly over veteran benefits: report
 - [https://www.foxnews.com/us/mississippi-woman-sentenced-life-role-brutally-beating-man-death-veteran-benefits-report](https://www.foxnews.com/us/mississippi-woman-sentenced-life-role-brutally-beating-man-death-veteran-benefits-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:30:14+00:00

A Yazoo County, Mississippi, jury found a woman guilty on Saturday for her part in brutally beating a man to death in 2017, and she was sentenced to life in prison.

## Taylor Swift's wild Jersey Shore wedding weekend
 - [https://www.foxnews.com/entertainment/taylor-swifts-wild-jersey-shore-wedding-weekend](https://www.foxnews.com/entertainment/taylor-swifts-wild-jersey-shore-wedding-weekend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:24:22+00:00

Taylor Swift led the star-studded pack at the wedding of her friend and collaborator Jack Antonoff over the weekend in New Jersey. Antonoff tied the knot with actress Margaret Qualley.

## House Republicans subpoena IRS, FBI agents involved in Hunter Biden investigation
 - [https://www.foxnews.com/politics/house-republicans-subpoena-irs-fbi-agents-involved-hunter-biden-investigation](https://www.foxnews.com/politics/house-republicans-subpoena-irs-fbi-agents-involved-hunter-biden-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:02:00+00:00

House Republicans on Monday issued subpoenas to several individuals from the FBI and IRS who are believed to be involved in the investigation into Hunter Biden.

## Bill Maher tells Vivek Ramaswamy 'you really could go far' in GOP primary: 'You're such a likable guy'
 - [https://www.foxnews.com/media/bill-maher-tells-vivek-ramaswamy-you-really-can-go-far-gop-primary](https://www.foxnews.com/media/bill-maher-tells-vivek-ramaswamy-you-really-can-go-far-gop-primary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T20:00:10+00:00

&quot;Club Random&quot; host Bill Maher offered high praise for Republican presidential candidate Vivek Ramaswamy, predicting he could &quot;go far&quot; in the GOP primary.

## Vapes disguised as school supplies worry authorities and prompt warnings as items pour into US from China
 - [https://www.foxnews.com/health/vapes-disguised-school-supplies-worry-authorities-warnings-items-pour-us-china](https://www.foxnews.com/health/vapes-disguised-school-supplies-worry-authorities-warnings-items-pour-us-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:43:11+00:00

A Chicago police officer is warning parents and teachers to be on the lookout for drugs that don’t always look like drugs — highlighters in particular as well as other everyday items

## 2 remain hospitalized after bull-running event in central Mexico leaves about 20 injured
 - [https://www.foxnews.com/world/2-remain-hospitalized-bull-running-event-central-mexico-leaves-20-injured](https://www.foxnews.com/world/2-remain-hospitalized-bull-running-event-central-mexico-leaves-20-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:18:22+00:00

Two men are currently hospitalized with serious injuries following a bull-running event in central Mexico over the weekend, during which approximately 20 people were wounded.

## San Francisco Roman Catholic archdiocese files for bankruptcy amid sex abuse lawsuits
 - [https://www.foxnews.com/us/san-francisco-roman-catholic-archdiocese-files-bankruptcy-amid-sex-abuse-lawsuits](https://www.foxnews.com/us/san-francisco-roman-catholic-archdiocese-files-bankruptcy-amid-sex-abuse-lawsuits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:17:41+00:00

The Roman Catholic Archdiocese of San Francisco filed for bankruptcy as it faces hundreds of child sex abuse lawsuits.

## 'Rare' fish endangered in two US states has researchers working to save species from extinction
 - [https://www.foxnews.com/lifestyle/rare-fish-endangered-two-us-states-researchers-working-save-species-extinction](https://www.foxnews.com/lifestyle/rare-fish-endangered-two-us-states-researchers-working-save-species-extinction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:14:15+00:00

Researchers at Pennsylvania State University are working with local wildlife agencies to boost Chesapeake logperch populations to prevent the fish from becoming federally endangered.

## NHTSA to encourage more seatbelt use by requiring warning systems for passengers
 - [https://www.foxnews.com/us/nhtsa-encourage-seatbelt-requiring-warning-systems-passengers](https://www.foxnews.com/us/nhtsa-encourage-seatbelt-requiring-warning-systems-passengers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:13:49+00:00

The National Highway Traffic Safety Administration is proposing seat belt warning system requirements for rear seat and front seat passengers to encourage more seat belt usage.

## Israeli airstrikes near Syrian capital cause injury and damage, reports say
 - [https://www.foxnews.com/world/israeli-airstrikes-near-syrian-capital-cause-injury-damage-reports-say](https://www.foxnews.com/world/israeli-airstrikes-near-syrian-capital-cause-injury-damage-reports-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:11:42+00:00

The Israeli military reportedly conducted airstrikes in close proximity to Syria&apos;s capital, Damascus, resulting in the injury of one soldier and causing material damage.

## Drive-by shooting: 4 teens charged in accidental killing of 5-year-old girl in Albuquerque
 - [https://www.foxnews.com/us/drive-by-shooting-4-teens-charged-accidental-killing-5-year-old-girl-albuquerque](https://www.foxnews.com/us/drive-by-shooting-4-teens-charged-accidental-killing-5-year-old-girl-albuquerque)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:03:16+00:00

Four teenagers are facing charges in connection with a drive-by shooting that left a 5-year-old girl dead inside a trailer home in Albuquerque last week.

## Biden economic advisor dismisses talks about inflation: Getting 'a little bit stale'
 - [https://www.foxnews.com/media/biden-economic-advisor-dismisses-talks-inflation-getting-stale](https://www.foxnews.com/media/biden-economic-advisor-dismisses-talks-inflation-getting-stale)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T19:00:21+00:00

Biden economic advisor Jared Bernstein argued that questions about the president&apos;s low approval ratings on inflation and the economy have become “stale.&quot;

## All charges dismissed in case of ND woman accused of attempted motorcyclist killing
 - [https://www.foxnews.com/us/all-charges-dismissed-case-nd-woman-accused-attempted-motorcyclist-killing](https://www.foxnews.com/us/all-charges-dismissed-case-nd-woman-accused-attempted-motorcyclist-killing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:58:07+00:00

The case against a North Dakota woman who had been accused of attempting to kill a motorcyclist in 2019 has been fully dismissed following a mental health evaluation.

## Jonathan Taylor allowed to seek trade as Colts change course with disgruntled running back: reports
 - [https://www.foxnews.com/sports/jonathan-taylor-allowed-seek-trade-colts-change-course-disgruntled-running-back](https://www.foxnews.com/sports/jonathan-taylor-allowed-seek-trade-colts-change-course-disgruntled-running-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:50:00+00:00

The Indianapolis Cols are reportedly allowing Jonathan Taylor permission to seek a trade, a surprising change of direction right as the regular season nears.

## These adult vaccines could reduce seniors’ risk of Alzheimer’s, study finds: ‘Heightened immune response’
 - [https://www.foxnews.com/health/these-adult-vaccines-could-reduce-seniors-risk-alzheimers-study-finds-heightened-immune-response](https://www.foxnews.com/health/these-adult-vaccines-could-reduce-seniors-risk-alzheimers-study-finds-heightened-immune-response)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:43:04+00:00

Getting vaccinated against shingles, pneumonia and other illnesses could potentially reduce adults’ risk of developing Alzheimer’s disease, a new study found.

## Wagner head Prigozhin says mercenary group making Russia ‘greater,’ Africa ‘freer’ in new recruitment video
 - [https://www.foxnews.com/world/wagner-head-prigozhin-says-mercenary-group-making-russia-greater-africa-freer-new-recruitment-video](https://www.foxnews.com/world/wagner-head-prigozhin-says-mercenary-group-making-russia-greater-africa-freer-new-recruitment-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:42:55+00:00

Wagner leader Yevgeny Prigozhin said in a Telegram video posted Monday that the mercenary force was making Russia &quot;greater&quot; and Africa &quot;freer&quot; while giving &quot;hell&quot; to terrorist groups.

## Escaped PA kidnapping suspect Michael Burham faces additional charges
 - [https://www.foxnews.com/us/escaped-pa-kidnapping-suspect-michael-burham-faces-additional-charges](https://www.foxnews.com/us/escaped-pa-kidnapping-suspect-michael-burham-faces-additional-charges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:27:34+00:00

A suspect who fled a northern Pennsylvania jail last month is facing additional charges related to both his escape and the original allegations against him.

## Maryland man gets long prison sentence for heinous acts with a minor, including recording: prosecutor
 - [https://www.foxnews.com/us/maryland-man-sentenced-heinous-acts-minor-recording-prosecutor](https://www.foxnews.com/us/maryland-man-sentenced-heinous-acts-minor-recording-prosecutor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:24:54+00:00

A 31-year-old Mardela Springs, Maryland man was sentenced to 35 years in prison by a Wicomico County judge for sexually abusing a minor and recording one of the acts.

## U.S. sprinter Sha'Carri Richardson wins gold in women's 100-meter race at World Championships
 - [https://www.foxnews.com/sports/u-s-sprinter-shacarri-richardson-wins-gold-womens-100-meter-race-world-championships](https://www.foxnews.com/sports/u-s-sprinter-shacarri-richardson-wins-gold-womens-100-meter-race-world-championships)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:18:01+00:00

Sha&apos;Carri Richardson is officially the world&apos;s fastest woman, as the 23-year-old shocked everyone at the World Championships winning the 100-meter race at 10.65 seconds.

## Vivek Ramaswamy preps for upcoming Republican debate with shirtless tennis
 - [https://www.foxnews.com/politics/vivek-ramaswamy-preps-upcoming-republican-debate-shirtless-tennis](https://www.foxnews.com/politics/vivek-ramaswamy-preps-upcoming-republican-debate-shirtless-tennis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:17:22+00:00

Republican presidential candidate Vivek Ramaswamy took in a game of tennis ahead of the GOP presidential primary debate.

## Russia's Luna-25 lunar mission ends in engine failure-induced crash
 - [https://www.foxnews.com/world/russias-luna-25-lunar-mission-ends-engine-failure-induced-crash](https://www.foxnews.com/world/russias-luna-25-lunar-mission-ends-engine-failure-induced-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:12:17+00:00

Russia&apos;s pilotless Luna-25 spacecraft crashed into the moon after its engines failed to shut down properly, space agency Roscosmos confirmed Monday.

## Dominican government offers financial aid to families affected by deadly factory explosion
 - [https://www.foxnews.com/world/dominican-government-offers-financial-aid-families-affected-deadly-factory-explosion](https://www.foxnews.com/world/dominican-government-offers-financial-aid-families-affected-deadly-factory-explosion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:07:16+00:00

The Dominican government has unveiled a support initiative to assist the families of the 32 people who died in a plastics factory explosion earlier this month.

## Austin police chief abruptly retires amid staffing shortages, lack of police union contract
 - [https://www.foxnews.com/us/austin-police-chief-abruptly-retires-staffing-shortages-lack-police-union-contract](https://www.foxnews.com/us/austin-police-chief-abruptly-retires-staffing-shortages-lack-police-union-contract)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:05:25+00:00

Austin Police Chief Joseph Chacon announced his retirement on Monday, amid staffing shortages, the lack of a police union contract and an unsupportive city council.

## King Charles and Prince William to have 'high-stakes’ summit following World Cup 'mistake': experts
 - [https://www.foxnews.com/entertainment/king-charles-prince-william-high-stakes-summit-world-cup-mistake-experts](https://www.foxnews.com/entertainment/king-charles-prince-william-high-stakes-summit-world-cup-mistake-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:01:13+00:00

Prince William and Kate Middleton, the Prince and Princess of Wales, are said to be meeting with King Charles III at Scotland&apos;s Balmoral Castle to discuss the monarchy&apos;s future.

## Texas Republican bashes ‘Marxist’ ideologues in public libraries: ‘Sure as hell has no place’ in the state
 - [https://www.foxnews.com/media/texas-republican-bashes-marxist-ideologues-public-libraries-sure-hell-no-place-state](https://www.foxnews.com/media/texas-republican-bashes-marxist-ideologues-public-libraries-sure-hell-no-place-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:00:32+00:00

GOP Texas State Rep. Brian Harrison is speaking out against “woke, ultra-liberal Marxist socialists&quot; in public institutions, who he claims are trying to indoctrinate children.

## IRS whistleblower's attorney: 'David Weiss has to go' over Beau Biden connections, bombshell reports
 - [https://www.foxnews.com/media/irs-whistleblower-attorney-david-weiss-has-go-over-beau-biden-connections-bombshell-nonprosecution-report](https://www.foxnews.com/media/irs-whistleblower-attorney-david-weiss-has-go-over-beau-biden-connections-bombshell-nonprosecution-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T18:00:04+00:00

David Weiss, the U.S. Attorney for the District of Delaware and special counsel in the Hunter Biden matter, is under even more scrutiny after a flood of new reports.

## After Tennessee landlord says victims must repay allegedly stolen rent checks, tenants hear promising news
 - [https://www.foxnews.com/media/landlord-tennessee-says-victims-repay-allegedly-stolen-rent-checks-tenants-hear-promising-news](https://www.foxnews.com/media/landlord-tennessee-says-victims-repay-allegedly-stolen-rent-checks-tenants-hear-promising-news)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:58:57+00:00

A Tennessee renter said her landlord backpedaled on a demand to pay again after the former property manager allegedly stole money orders used for the rent.

## Missing LA woman shot, yanked from car by kidnapper: 'We're scared,' relative says
 - [https://www.foxnews.com/us/missing-la-woman-shot-yanked-car-kidnapper-scared-relative-says](https://www.foxnews.com/us/missing-la-woman-shot-yanked-car-kidnapper-scared-relative-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:52:35+00:00

A Los Angeles woman was shot and abducted from a California park early Sunday and her family and police are desperately trying to track her down.

## Arkansas Department of Education throws down gauntlet on CRT, demands public schools turn over materials
 - [https://www.foxnews.com/politics/arkansas-department-education-throws-gauntlet-crt-demands-public-schools-turn-over-materials](https://www.foxnews.com/politics/arkansas-department-education-throws-gauntlet-crt-demands-public-schools-turn-over-materials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:45:39+00:00

The Arkansas Department of Education called on school superintendents to turn over materials for the recently pulled AP African American Studies pilot program.

## US citizens in Belarus told to ‘depart immediately’
 - [https://www.foxnews.com/world/us-citizens-belarus-told-depart-immediately](https://www.foxnews.com/world/us-citizens-belarus-told-depart-immediately)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:42:21+00:00

The U.S. Embassy in Belarus is warning Americans still in the country to leave immediately as geopolitical tensions and civil unrest create greater risk.

## Commanders' Sam Cosmi doesn't care for Ravens' insane preseason win streak: 'Who gives a s---?'
 - [https://www.foxnews.com/sports/commanders-sam-cosmi-doesnt-care-ravens-insane-preseason-win-streak](https://www.foxnews.com/sports/commanders-sam-cosmi-doesnt-care-ravens-insane-preseason-win-streak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:25:19+00:00

Washington Commanders offensive lineman Sam Cosmi don&apos;t get the hype about the Baltimore Ravens&apos; 24-game preseason streak, which he believes his team will snap tonight.

## Trump bond set at $200,000 after Georgia indictment
 - [https://www.foxnews.com/politics/trump-bond-set-at-200k-after-georgia-indictment](https://www.foxnews.com/politics/trump-bond-set-at-200k-after-georgia-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:15:40+00:00

A Georgia court set bond for former President Trump at $200,000, after he was charged by Fulton County prosecutors with 13 counts last week related to its investigation into his alleged efforts to overturn the 2020 election.

## Alabama AG calls for investigation into Biden's reversal on Space Command HQ
 - [https://www.foxnews.com/politics/alabama-ag-calls-investigation-bidens-reversal-space-command-hq](https://www.foxnews.com/politics/alabama-ag-calls-investigation-bidens-reversal-space-command-hq)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:13:35+00:00

Alabama AG Steve Marshall called for an investigation into President Biden reversing his decision to move Space Command headquarters to Huntsville, Alabama.

## Kristin Chenoweth mourns death of biological mother: 'The ten plus years I knew her were magic'
 - [https://www.foxnews.com/entertainment/kristin-chenoweth-mourns-death-biological-mother](https://www.foxnews.com/entertainment/kristin-chenoweth-mourns-death-biological-mother)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:08:19+00:00

Kristin Chenoweth is mourning the loss of her biological mother, Lynn. The &quot;Schmigadoon!&quot; actress shared that she&apos;s spent the last decade getting to know her.

## California parents protest for protection of their children amid controversial bills
 - [https://www.foxnews.com/us/california-parents-protest-at-state-capitol-for-protection-of-their-children-amid-controversial-bills](https://www.foxnews.com/us/california-parents-protest-at-state-capitol-for-protection-of-their-children-amid-controversial-bills)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T17:03:50+00:00

Several controversial California bills making its way through the legislature triggered local advocacy groups, parents, and churchgoers to protest.

## DeSantis campaign boasts endorsements, latest poll numbers as signs of momentum in Iowa
 - [https://www.foxnews.com/politics/desantis-campaign-boasts-endorsements-latest-poll-numbers-sign-momentum-iowa](https://www.foxnews.com/politics/desantis-campaign-boasts-endorsements-latest-poll-numbers-sign-momentum-iowa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:43:03+00:00

Ron DeSantis has received a historic 40 endorsements from Iowa state legislators, with 120 county-level chairs supporting him, his campaign says.

## Olivia Newton-John's daughter Chloe is suffering from 'extreme memory loss' since mom's death
 - [https://www.foxnews.com/entertainment/olivia-newton-johns-daughter-chloe-suffering-extreme-memory-loss-moms-death](https://www.foxnews.com/entertainment/olivia-newton-johns-daughter-chloe-suffering-extreme-memory-loss-moms-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:38:35+00:00

Olivia Newton-John&apos;s daughter Chloe Lattanzi is sharing how her mother&apos;s death has taken a toll on her physical health, and that she needs time away to address her problems.

## Iraqi oil minister visits Ankara to address energy issues, including resumption of oil exports
 - [https://www.foxnews.com/world/iraqi-oil-minister-visits-ankara-address-energy-issues-resumption-oil-exports](https://www.foxnews.com/world/iraqi-oil-minister-visits-ankara-address-energy-issues-resumption-oil-exports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:27:12+00:00

Iraq&apos;s oil minister has arrived in Ankara for talks on several matters, with a primary focus on reestablishing the flow of oil exports through Turkey&apos;s Ceyhan oil terminal.

## Kamala Harris thinks she gets more media scrutiny than VP predecessors: 'I think that is the case'
 - [https://www.foxnews.com/media/kamala-harris-thinks-more-media-scrutiny-vp-predecessor-think-case](https://www.foxnews.com/media/kamala-harris-thinks-more-media-scrutiny-vp-predecessor-think-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:21:30+00:00

Vice President Kamala Harris told Politico in an interview that she believes she faces more media scrutiny than her predecessors received in the position.

## Swing state Democrat cozies up to Biden ahead of consequential Senate race despite president's poor polling
 - [https://www.foxnews.com/politics/swing-state-democrat-cozies-up-biden-consequential-senate-race-president-poor-polling](https://www.foxnews.com/politics/swing-state-democrat-cozies-up-biden-consequential-senate-race-president-poor-polling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:16:40+00:00

Vulnerable Democratic Nevada Sen. Jacky Rosen is cozying up to President Biden despite his underwater approval rating in the swing state and across the country.

## Suspected Palestinian assailant kills Israeli woman, sparks renewed violence in West Bank
 - [https://www.foxnews.com/world/suspected-palestinian-assailant-kills-israeli-woman-sparks-renewed-violence-west-bank](https://www.foxnews.com/world/suspected-palestinian-assailant-kills-israeli-woman-sparks-renewed-violence-west-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:15:46+00:00

A suspected Palestinian attacker fatally shot an Israeli woman and left a man seriously wounded in the southern part of the occupied West Bank on Monday.

## Spelling quiz! How well can you spell these surprisingly tough words?
 - [https://www.foxnews.com/lifestyle/spelling-quiz-how-well-spell-surprisingly-tough-words](https://www.foxnews.com/lifestyle/spelling-quiz-how-well-spell-surprisingly-tough-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:15:20+00:00

Spelling quiz! Take this fun spelling test to see how well you know some of the most commonly misspelled words. Test yourself in this engaging lifestyle quiz!

## Turkey's Erdogan criticizes UN peacekeepers for road blockade in Cyprus, citing bias
 - [https://www.foxnews.com/world/turkeys-erdogan-criticizes-un-peacekeepers-road-blockade-cyprus-citing-bias](https://www.foxnews.com/world/turkeys-erdogan-criticizes-un-peacekeepers-road-blockade-cyprus-citing-bias)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:13:07+00:00

President Recep Tayyip Erdogan of Turkey expressed strong disapproval on Monday over the actions of U.N. peacekeepers, accusing them of hindering the construction of a Cyprus road.

## California football field flooded as Tropical Storm Hilary hammers region
 - [https://www.foxnews.com/us/california-football-field-flooded-water-tropical-storm-hilary-pours-rain-region](https://www.foxnews.com/us/california-football-field-flooded-water-tropical-storm-hilary-pours-rain-region)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:06:12+00:00

A news helicopter camera showed a Los Angeles school football field filled with water as Tropical Storm Hilary dumped rain on Southern California.

## Texas official who switched to GOP feared being called a 'traitor' for abandoning Democrat Party
 - [https://www.foxnews.com/media/texas-official-switched-gop-feared-called-traitor-abandoning-democrat-party](https://www.foxnews.com/media/texas-official-switched-gop-feared-called-traitor-abandoning-democrat-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T16:00:45+00:00

Kleberg County, Texas Attorney Kira Talip Sanchez, a Hispanic American, says the border crisis was a key breaking point in her decision to join the Republican Party.

## Ilhan Omar calls Israel lobby AIPAC a 'right-wing' PAC funded by 'dark money'
 - [https://www.foxnews.com/politics/ilhan-omar-bipartisan-israel-group-aipac-dark-money-campaign](https://www.foxnews.com/politics/ilhan-omar-bipartisan-israel-group-aipac-dark-money-campaign)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:59:30+00:00

Rep. Ilhan Omar accused pro-Israel lobbying group AIPAC of raising &apos;dark money&apos; to find a challenger to primary her.

## Suspect in 1990s Pennsylvania murder arrested in Mexico, another remains on the loose
 - [https://www.foxnews.com/us/suspect-murder-1990s-pennsylvania-murder-arrested-mexico-another-remains-loose](https://www.foxnews.com/us/suspect-murder-1990s-pennsylvania-murder-arrested-mexico-another-remains-loose)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:56:17+00:00

A man linked to a 1998 Pennsylvania killing has been arrested in Mexico and another is being sought.

## Aaron Rodgers reveals his Jets quarterback plan for future, including 'few good years here'
 - [https://www.foxnews.com/sports/aaron-rodgers-reveals-jets-quarterback-plan-future-few-good-years-here](https://www.foxnews.com/sports/aaron-rodgers-reveals-jets-quarterback-plan-future-few-good-years-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:51:06+00:00

New York Jets quarterback Aaron Rodgers is focused on the present, but he also has a succession plan for the future that includes a &quot;few good years&quot; in East Rutherford.

## 'Marxist lesbian' library group president denounced 'angry, White mob parents', in push for 'queerness'
 - [https://www.foxnews.com/politics/president-ala-parents-angry-white-mob-kids-libraries-queerness](https://www.foxnews.com/politics/president-ala-parents-angry-white-mob-kids-libraries-queerness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:43:53+00:00

ALA President Emily Drabinski is &quot;hell-bent on sexualizing and indoctrinating America&apos;s kids,&quot; according to a group who shared her long history of anti-conservative language.

## Fox News Channel to air primetime OutKick special with Clay Travis, Tomi Lahren and Charly Arnolt
 - [https://www.foxnews.com/media/fox-news-channel-air-primetime-outkick-special-clay-travis-tomi-lahren-charly-arnolt](https://www.foxnews.com/media/fox-news-channel-air-primetime-outkick-special-clay-travis-tomi-lahren-charly-arnolt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:43:07+00:00

Fox News Channel will air a one-hour special &quot;OutKick on Fox&quot; on Sunday at 10 p.m. ET with

## Undrafted rookie quarterback from DII school vying for Bears backup job: 'Everything’s open right now'
 - [https://www.foxnews.com/sports/undrafted-rookie-quarterback-d-2-school-vying-bears-backup-job-everythings-open-right-now](https://www.foxnews.com/sports/undrafted-rookie-quarterback-d-2-school-vying-bears-backup-job-everythings-open-right-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:34:59+00:00

Tyson Bagent entered the NFL as an undrafted rookie out of Shepherd University and is vying to become the Chicago Bears&apos; No. 2 quarterback.

## Oliver Anthony trolled with pro-union song 'Rich Men Earning North of a Million'
 - [https://www.foxnews.com/media/oliver-anthony-trolled-pro-union-song-rich-men-earning-north-million](https://www.foxnews.com/media/oliver-anthony-trolled-pro-union-song-rich-men-earning-north-million)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:33:20+00:00

English singer-songwriter Billy Bragg released a pro-union anthem in response to Oliver Anthony&apos;s viral hit &quot;Rich Men North of Richmond.&quot;

## Nikki Haley slams Ramaswamy over proposal to cut off most Israel aid by 2028: 'Concerning pattern'
 - [https://www.foxnews.com/politics/nikki-haley-slams-ramaswamy-proposal-cut-most-israel-aid-2028-concerning-pattern](https://www.foxnews.com/politics/nikki-haley-slams-ramaswamy-proposal-cut-most-israel-aid-2028-concerning-pattern)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:27:12+00:00

Presidential candidate Nikki Haley blasted her fellow GOP candidate Vivek Ramaswamy over his foreign policies and recent comments about Israel.

## Maui mayor says 850 people still missing after deadly wildfires
 - [https://www.foxnews.com/us/maui-mayor-says-850-people-still-missing-deadly-wildfires](https://www.foxnews.com/us/maui-mayor-says-850-people-still-missing-deadly-wildfires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:23:39+00:00

Maui County Mayor Richard Bissen said around 850 people remain missing after devastating wildfires destroyed the western half of the island.

## 'Friends' star Courteney Cox's embarrassing secret that makes her just like TV character
 - [https://www.foxnews.com/entertainment/friends-star-courteney-coxs-embarrassing-secret-makes-just-like-tv-character](https://www.foxnews.com/entertainment/friends-star-courteney-coxs-embarrassing-secret-makes-just-like-tv-character)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:19:25+00:00

Courteney Cox revealed she has a messy closet just like her &quot;Friends&quot; character Monica. The actress shared a funny video showcasing the bad habit on Instagram.

## Texas woman celebrates her 114th birthday, attributing her long life to God: 'Just the Lord keeping me here'
 - [https://www.foxnews.com/lifestyle/texas-woman-celebrates-114th-birthday-attributing-long-life-god-lord-keeping-me-here](https://www.foxnews.com/lifestyle/texas-woman-celebrates-114th-birthday-attributing-long-life-god-lord-keeping-me-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:17:05+00:00

Houston, Texas, &quot;supercentenarian,&quot; Elizabeth Francis, celebrated her 114th birthday, making her second oldest living person in America and the seventh oldest in the world.

## UK vows increased support for Iraq's anti-drug efforts, strengthening security partnership
 - [https://www.foxnews.com/world/uk-vows-increased-support-iraqs-anti-drug-efforts-strengthening-security-partnership](https://www.foxnews.com/world/uk-vows-increased-support-iraqs-anti-drug-efforts-strengthening-security-partnership)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:14:16+00:00

British Security Minister Tom Tugendhat on Monday pledged enhanced support for Iraq&apos;s security forces in their endeavors to combat drug production and trafficking.

## Ohio teen sobs as she learns fate for intentionally killing boyfriend, passenger in car wreck
 - [https://www.foxnews.com/us/ohio-teen-sobs-learns-fate-intentionally-killing-boyfriend-passenger-car-wreck](https://www.foxnews.com/us/ohio-teen-sobs-learns-fate-intentionally-killing-boyfriend-passenger-car-wreck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:08:07+00:00

Mackenzie Shirilla, 19, broke down Monday when an Ohio judge sentenced her to life in prison for intentionally killing her boyfriend and his friend in a high-speed car wreck.

## Michigan's Jim Harbaugh to serve school-imposed 3-game suspension: reports
 - [https://www.foxnews.com/sports/michigans-jim-harbaugh-serve-school-imposed-3-game-suspension](https://www.foxnews.com/sports/michigans-jim-harbaugh-serve-school-imposed-3-game-suspension)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:06:27+00:00

Michigan is suspending head coach football coach Jim Harbaugh for three games. He is accused of violating NCAA recruitment rules following an investigation.

## Best prompts to get the most out of an AI chatbot
 - [https://www.foxnews.com/tech/best-prompts-get-most-ai-chatbot](https://www.foxnews.com/tech/best-prompts-get-most-ai-chatbot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T15:00:28+00:00

Using AI-powered chatbots is very helpful. Kurt &quot;CyberGuy&quot; Knutsson helps explains some prompts to make your answers specific what questions to avoid.

## Georgia sheriff pleads guilty to groping TV Judge Hatchett, resigns
 - [https://www.foxnews.com/us/georgia-sheriff-pleads-guilty-grouping-tv-judge-hatchett-resigns](https://www.foxnews.com/us/georgia-sheriff-pleads-guilty-grouping-tv-judge-hatchett-resigns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:56:28+00:00

A Georgia sheriff pleaded guilty to group TV Judge Glenda Hatchet and then resigned from office Monday.

## Deadly exchange of fire at disputed Indo-Pakistani border in Kashmir raises tensions
 - [https://www.foxnews.com/world/deadly-exchange-fire-disputed-indo-pakistani-border-kashmir-raises-tensions](https://www.foxnews.com/world/deadly-exchange-fire-disputed-indo-pakistani-border-kashmir-raises-tensions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:55:56+00:00

Pakistan&apos;s military alleged that Indian troops initiated gunfire that killed a villager Monday along their contested border in the Himalayan region of Kashmir.

## Prince Harry criticized over new photo showing fuller head of hair after mocking Prince William in memoir
 - [https://www.foxnews.com/entertainment/prince-harry-criticized-new-photo-showing-fuller-head-hair-after-mocking-prince-william-memoir](https://www.foxnews.com/entertainment/prince-harry-criticized-new-photo-showing-fuller-head-hair-after-mocking-prince-william-memoir)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:52:39+00:00

Prince Harry&apos;s profile photo for a company he works with has been criticized for showing a seemingly fuller, darker head of hair than recent photos demonstrate.

## Utah children's author dodges death row after DA's 'careful consideration' with victim's family
 - [https://www.foxnews.com/us/utah-childrens-author-dodges-death-row-after-das-careful-consideration-victims-family](https://www.foxnews.com/us/utah-childrens-author-dodges-death-row-after-das-careful-consideration-victims-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:52:39+00:00

Utah mom and children&apos;s book author Kouri Richins won&apos;t face the death penalty after she allegedly poisoned husband Eric Richins to death in March 2022.

## Clerical work likely primary victim of generative AI, UN study finds
 - [https://www.foxnews.com/us/clerical-work-likely-primary-victim-generative-ai-un-study-finds](https://www.foxnews.com/us/clerical-work-likely-primary-victim-generative-ai-un-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:50:46+00:00

A United Nations study indicated that while the rise of generative AI is not likely to completely replace most job roles, it will instead automate specific tasks within them.

## Pentagon rejects Iranian claims of 'intercept' against US Navy vessels
 - [https://www.foxnews.com/world/pentagon-rejects-iranian-claims-intercept-us-navy-vessels](https://www.foxnews.com/world/pentagon-rejects-iranian-claims-intercept-us-navy-vessels)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:41:14+00:00

The Pentagon says Iran released heavily edited footage purporting to show Iranian fast attack vessels &quot;intercepting&quot; two U.S. Navy warships.

## Indonesia's electric vehicle push complicated by price concerns, low confidence
 - [https://www.foxnews.com/world/indonesias-electric-vehicle-push-complicated-price-concerns-low-confidence](https://www.foxnews.com/world/indonesias-electric-vehicle-push-complicated-price-concerns-low-confidence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:40:45+00:00

The Jakarta auto show provided Indonesia&apos;s government with a platform to reaffirm its commitment to boosting electric vehicle production and sales in Asia&apos;s largest auto market.

## Boaters leap overboard after yacht catches fire off Maine coast
 - [https://www.foxnews.com/us/boaters-leap-overboard-yacht-catches-fire-maine-coast](https://www.foxnews.com/us/boaters-leap-overboard-yacht-catches-fire-maine-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:35:34+00:00

Two individuals reportedly jumped from a 48-foot yacht off the coast of Seguin Island, Maine, after a fire rapidly consumed the vessel.

## Japanese health ministry panel recommends approval of Alzheimer's treatment Leqembi
 - [https://www.foxnews.com/world/japanese-health-ministry-panel-recommends-approval-of-alzheimers-treatment-leqembi](https://www.foxnews.com/world/japanese-health-ministry-panel-recommends-approval-of-alzheimers-treatment-leqembi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:30:22+00:00

A panel convened by Japan&apos;s health ministry made a recommendation Monday in favor of endorsing the Alzheimer&apos;s disease medication Leqembi.

## Students protest West Virginia University’s proposal to cut academic programs, faculty
 - [https://www.foxnews.com/us/students-protest-west-virginia-universitys-proposal-cut-academic-programs-faculty](https://www.foxnews.com/us/students-protest-west-virginia-universitys-proposal-cut-academic-programs-faculty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:28:39+00:00

The West Virginia University has proposed to eliminate 9% of its majors and 7% of its entire faculty. On Monday, students staged a walkout to protest the cutbacks.

## The voice behind Nintendo's Mario hangs up his hat: 'It has been an honor'
 - [https://www.foxnews.com/entertainment/voice-nintendos-mario-hangs-his-hat-it-has-been-honor](https://www.foxnews.com/entertainment/voice-nintendos-mario-hangs-his-hat-it-has-been-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:20:39+00:00

The voice of Mario from Nintendo&apos;s video games will soon change after the company announced the departure of voice actor Charles Martinet.

## Pakistan gives cash to nearly 100 homeless Christian families following destructive Muslim-led riot
 - [https://www.foxnews.com/world/pakistan-gives-cash-nearly-100-homeless-christian-families-following-destructive-muslim-led-riot](https://www.foxnews.com/world/pakistan-gives-cash-nearly-100-homeless-christian-families-following-destructive-muslim-led-riot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:20:32+00:00

A cash payment of $6,800 is being given out to nearly 100 Christian families in Pakistan after a riot sparked by the possible desecration of the Quran destroyed several Christian homes.

## 'Crazy plane lady' vows comeback as social media torches Dallas woman's mea culpa: 'Very strange picture'
 - [https://www.foxnews.com/us/crazy-plane-lady-vows-comeback-social-media-torches-dallas-womans-mea-culpa-very-strange-picture](https://www.foxnews.com/us/crazy-plane-lady-vows-comeback-social-media-torches-dallas-womans-mea-culpa-very-strange-picture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:19:53+00:00

American Airlines passenger behind the viral &quot;not real&quot; meltdown has racked up tens of thousands of social media followers as she seeks to repair her image.

## New York college evicts 44 migrants from campus dorms, gets accused of discrimination
 - [https://www.foxnews.com/media/new-york-college-evicts-44-migrants-campus-dorms-gets-accused-discrimination](https://www.foxnews.com/media/new-york-college-evicts-44-migrants-campus-dorms-gets-accused-discrimination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:13:52+00:00

SUNY Buffalo State University announced prior to the fall semester it planned to evict 44 migrants who have been housed in the school&apos;s campus dormitories.

## Massachusetts father drowns while trying to save mother, child in New Hampshire river, police say
 - [https://www.foxnews.com/us/massachusetts-father-drowns-while-trying-save-mother-child-new-hampshire-river-police-say](https://www.foxnews.com/us/massachusetts-father-drowns-while-trying-save-mother-child-new-hampshire-river-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:04:45+00:00

New Hampshire State Police say Vincent Parr was pronounced dead after becoming “caught in the current&quot; of the Swift River in Albany while trying to save a woman and her child.

## UK baby-killer Lucy Letby sentenced to life in prison: 'Malevolence bordering on sadism'
 - [https://www.foxnews.com/world/uk-baby-killer-lucy-letby-sentenced-life-prison-malevolence-bordering-sadism](https://www.foxnews.com/world/uk-baby-killer-lucy-letby-sentenced-life-prison-malevolence-bordering-sadism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:01:45+00:00

A judge in England sentenced Lucy Letby to life in prison with no chance of release, after she was convicted of murdering seven babies.

## Biden's DOJ 'scared to death' to charge Hunter, Andy McCarthy says: 'Would be career suicide'
 - [https://www.foxnews.com/media/bidens-doj-scared-death-charge-hunter-andy-mccarthy-says-career-suicide](https://www.foxnews.com/media/bidens-doj-scared-death-charge-hunter-andy-mccarthy-says-career-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T14:00:26+00:00

Legal expert calls out President Biden&apos;s Department of Justice officials for being &quot;afraid&quot; to charge his son Hunter

## Louisville district sees large improvement in bus program following disastrous rollout on 1st day of school
 - [https://www.foxnews.com/us/louisville-district-sees-large-improvement-bus-program-following-disastrous-rollout-1st-day-school](https://www.foxnews.com/us/louisville-district-sees-large-improvement-bus-program-following-disastrous-rollout-1st-day-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:56:46+00:00

Most students in Louisville, Kentucky, are now being dropped off at home by 7:15 p.m., following a disastrous bus program rollout on the first day of school.

## Greek patrol rescue nearly 80 migrants that tried to cross Aegean Sea in inflatable dinghies
 - [https://www.foxnews.com/world/greek-patrol-boats-rescue-nearly-80-migrants-tried-cross-aegean-sea-inflatable-dinghies](https://www.foxnews.com/world/greek-patrol-boats-rescue-nearly-80-migrants-tried-cross-aegean-sea-inflatable-dinghies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:54:05+00:00

Around 80 migrants were rescued by Greek patrol boats in the Aegean Sea on Aug. 21, 2023. The migrants were coming from Turkey in inflatable dinghies.

## Canadian firefighters making progress in battle against wildfires, thousands still evacuated from their homes
 - [https://www.foxnews.com/world/canadian-firefighters-making-progress-battle-against-wildfires-thousands-evacuated-homes](https://www.foxnews.com/world/canadian-firefighters-making-progress-battle-against-wildfires-thousands-evacuated-homes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:50:56+00:00

Hundred of fires are still burning in the Canadian wilderness, but firefighters are making progress. Canada has seen a record number of wildfires this year.

## Patriots' Bill Belichick praises 'impressive' Taylor Swift for rain-soaked performance
 - [https://www.foxnews.com/sports/patriots-bill-belichick-praises-impressive-taylor-swift-for-rain-plagued-performance](https://www.foxnews.com/sports/patriots-bill-belichick-praises-impressive-taylor-swift-for-rain-plagued-performance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:50:54+00:00

New England Patriots head coach Bill Belichick offered some praise for Taylor Swift after she persevered through rain during one of her concerts.

## Lana Del Rey's fans fall like dominos in scary concert video
 - [https://www.foxnews.com/entertainment/lana-del-reys-fans-fall-domino-effect-scary-concert-video](https://www.foxnews.com/entertainment/lana-del-reys-fans-fall-domino-effect-scary-concert-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:40:29+00:00

Lana Del Rey fans experienced a domino-like fall in the crowd at her Aug. 15 concert. Del Rey completed the first leg of her tour in Mexico City.

## US begins unloading seized Iranian oil from tanker just days after pressure from bipartisan group of lawmakers
 - [https://www.foxnews.com/us/us-begins-offloading-seized-iranian-oil-from-tanker-after-pressure-bipartisan-group-lawmakers](https://www.foxnews.com/us/us-begins-offloading-seized-iranian-oil-from-tanker-after-pressure-bipartisan-group-lawmakers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:38:40+00:00

The U.S. began the transfer of suspected sanctioned Iranian oil off of a seized oil tanker off the coast of Galveston, Texas, on Sunday after a monthslong delay.

## Fire in densely populated Maryland suburb scorches 3-story apartment building
 - [https://www.foxnews.com/us/fire-densely-populated-maryland-suburb-scorches-3-story-apartment-building](https://www.foxnews.com/us/fire-densely-populated-maryland-suburb-scorches-3-story-apartment-building)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:35:40+00:00

Firefighters battled a three-alarm apartment fire Monday in a densely populated Maryland suburb of Washington, D.C. The fire caused a massive plume of orange flames and dark smoke.

## New York Republicans demand answers from Governor Hochul on Chinese funding in state school systems
 - [https://www.foxnews.com/media/new-york-republicans-demand-answers-governor-hochul-chinese-funding-in-state-school-systems](https://www.foxnews.com/media/new-york-republicans-demand-answers-governor-hochul-chinese-funding-in-state-school-systems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:30:52+00:00

The New York GOP is demanding answers from Governor Kathy Hochul, following a report that found over $17 million in CCP funding funneled into America&apos;s K-12 schools.

## 10 homes remain uninhabitable in week following deadly Pittsburgh-area house explosion
 - [https://www.foxnews.com/us/10-homes-remain-uninhabitable-in-week-following-deadly-pittsburgh-area-house-explosion](https://www.foxnews.com/us/10-homes-remain-uninhabitable-in-week-following-deadly-pittsburgh-area-house-explosion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:29:55+00:00

A week after six people were killed in a house explosion near Pittsburgh, ten homes in the vicinity remain uninhabitable. The origin of the fire remains a mystery

## Manchester United announces Mason Greenwood will leave club following rape investigation
 - [https://www.foxnews.com/sports/manchester-united-announces-mason-greenwood-leave-club-following-rape-investigation](https://www.foxnews.com/sports/manchester-united-announces-mason-greenwood-leave-club-following-rape-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:28:57+00:00

Mason Greenwood, a 21-year-old forward for Manchester United, will not rejoin the club following a rape investigation. Greenwood hasn&apos;t played for the club since January 2022.

## Former Kentucky prosecutor accused of giving out court favors in exchange for a defendant’s nude photos
 - [https://www.foxnews.com/us/former-kentucky-prosecutor-allegedly-giving-court-favors-defendants-nude-photos](https://www.foxnews.com/us/former-kentucky-prosecutor-allegedly-giving-court-favors-defendants-nude-photos)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:23:52+00:00

Ronnie Goldy Jr., a ex-prosecutor in Kentucky, was indicted on charges of bribery and wire fraud. Goldy allegedly made decisions that benefited a defendant in exchange for nude images.

## 'Friday Night Lights' star Taylor Kitsch's move to Montana: 'Being in L.A. was never a great thing for me'
 - [https://www.foxnews.com/entertainment/friday-night-lights-star-taylor-kitschs-move-montana-being-l-a-never-great-thing](https://www.foxnews.com/entertainment/friday-night-lights-star-taylor-kitschs-move-montana-being-l-a-never-great-thing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:21:59+00:00

&quot;Friday Night Lights&quot; actor Taylor Kitsch is opening up about why he chose to leave Los Angeles and build a new space to help people in Montana.

## Chip Roy, GOP colleagues sound alarm over CCP-linked money reportedly going to NIH employees
 - [https://www.foxnews.com/politics/chip-roy-gop-colleagues-sound-alarm-ccp-linked-money-nih-employees](https://www.foxnews.com/politics/chip-roy-gop-colleagues-sound-alarm-ccp-linked-money-nih-employees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:20:38+00:00

Texas Rep. Chip Roy led a letter with 14 of his House GOP colleagues to the acting NIH director regarding the recent Open The Books report revealing foreign payments to employees.

## Portland pays out thousands to woman who railed against police
 - [https://www.foxnews.com/politics/portland-pays-thousands-woman-railed-against-police](https://www.foxnews.com/politics/portland-pays-thousands-woman-railed-against-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T13:00:39+00:00

The city of Portland agreed to pay its former &quot;defund the police&quot; commissioner $5,000 to settle its portion of a lawsuit accusing cops of leaking false information.

## St. Louis residents sound off on 'sidewalk squatters' who have lived on streets more than a decade
 - [https://www.foxnews.com/us/st-louis-residents-sound-off-sidewalk-squatters-lived-streets-more-decade](https://www.foxnews.com/us/st-louis-residents-sound-off-sidewalk-squatters-lived-streets-more-decade)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:58:26+00:00

A homeless couple squatting in a makeshift tent on the sidewalks of south St. Louis for decades have caused alarm among some residents.

## Oregon predator used social media to lure 'single women with young daughters,' assault them: police
 - [https://www.foxnews.com/us/oregon-predator-used-social-media-lure-single-women-young-daughters-assault-them-police](https://www.foxnews.com/us/oregon-predator-used-social-media-lure-single-women-young-daughters-assault-them-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:55:46+00:00

Antonio Arredondo, a registered Oregon sex offender, allegedly used social media to lure “single women with young daughters&quot; and assault them, according to authorities.

## Virginia regulators fine hemp businesses following recent legislative changes
 - [https://www.foxnews.com/us/virginia-regulators-fine-hemp-businesses-following-recent-legislative-changes](https://www.foxnews.com/us/virginia-regulators-fine-hemp-businesses-following-recent-legislative-changes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:47:11+00:00

Virginia hemp businesses have begun facing fines following a new hemp law aimed at strengthening consumer regulations around certain THC products.

## David Weiss, DOJ accused of making 'unholy mess' with Hunter Biden case: 'All over the map'
 - [https://www.foxnews.com/media/david-weis-doj-accused-making-unholy-mess-with-hunter-biden-case-all-over-map](https://www.foxnews.com/media/david-weis-doj-accused-making-unholy-mess-with-hunter-biden-case-all-over-map)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:30:23+00:00

CNN&apos;s Elie Honig sharply criticized David Weiss and the Justice Department on Monday for making an &quot;unholy mess&quot; of the Hunter Biden investigation.

## Pope Francis calls for a peaceful end to Niger’s crisis following the country's military coup
 - [https://www.foxnews.com/world/pope-francis-calls-peaceful-end-nigers-crisis-following-countrys-military-coup](https://www.foxnews.com/world/pope-francis-calls-peaceful-end-nigers-crisis-following-countrys-military-coup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:28:27+00:00

While countries in West Africa have threatened to restore order in Niger with foreign armed forces, Pope Francis is calling for a peaceful solution.

## Georgia man sentenced to 27 years for involvement in $463 million genetic testing fraud
 - [https://www.foxnews.com/us/georgia-man-sentenced-27-years-involvement-463-million-genetic-testing-fraud](https://www.foxnews.com/us/georgia-man-sentenced-27-years-involvement-463-million-genetic-testing-fraud)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:28:00+00:00

Minal Patel, a 44-year-old man from Georgia, has been sentenced to 27 years in jail for his role in a $463 million fraudulent genetic testing scheme.

## Japan vows to support fisheries during country’s decades-long process of releasing Fukushima nuclear waste
 - [https://www.foxnews.com/world/japan-vows-support-fisheries-countrys-decades-long-process-releasing-fukushima-nuclear-waste](https://www.foxnews.com/world/japan-vows-support-fisheries-countrys-decades-long-process-releasing-fukushima-nuclear-waste)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:26:49+00:00

Fishermen have feared that the release of Fukushima’s nuclear waste may damage the industry’s reputation. In response, the Japanese government has vowed to support the industry.

## 2 MD troopers, who shot a man suspected of attacking the officers with a knife, now on administrative leave
 - [https://www.foxnews.com/us/2-md-troopers-who-shot-man-suspected-attacking-officers-knife-now-administrative-leave](https://www.foxnews.com/us/2-md-troopers-who-shot-man-suspected-attacking-officers-knife-now-administrative-leave)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:26:04+00:00

A couple of state troopers in Maryland have been placed on administrative leave. The troopers shot a 22-year-old suspect who allegedly charged at them with a knife.

## 3 dead, 6 injured in Seattle hookah lounge shooting
 - [https://www.foxnews.com/us/3-dead-6-injured-seattle-hookah-lounge-shooting](https://www.foxnews.com/us/3-dead-6-injured-seattle-hookah-lounge-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:25:15+00:00

A shooting broke out around 4:30 a.m. at a Seattle, Washington, hookah lounge. Three people died and six others were wounded in the incident.

## Charlotte police kill suspect who stabbed officer in the neck with knife
 - [https://www.foxnews.com/us/charlotte-police-kill-suspect-stabbed-officer-neck-knife](https://www.foxnews.com/us/charlotte-police-kill-suspect-stabbed-officer-neck-knife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:24:39+00:00

An officer responding to a domestic violence call in Charlotte, North Carolina, shot and killed a man who used a knife to stab another officer in the neck.

## Former Missouri respiratory therapist who killed two hospital patients learns her fate
 - [https://www.foxnews.com/us/former-missouri-respiratory-therapist-killed-two-hospital-patients-learns-fate](https://www.foxnews.com/us/former-missouri-respiratory-therapist-killed-two-hospital-patients-learns-fate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:24:36+00:00

A Missouri respiratory therapist was sentenced Friday to nearly two decades in prison for killing two patients, but authorities said she&apos;s suspected of as many as nine hospital deaths.

## MLB ump Ángel Hernández under fire over egregious strike calls during Braves-Giants
 - [https://www.foxnews.com/sports/mlb-ump-angel-hernandez-under-fire-egregious-strike-calls-braves-giants](https://www.foxnews.com/sports/mlb-ump-angel-hernandez-under-fire-egregious-strike-calls-braves-giants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:18:35+00:00

MLB umpire Ángel Hernández was behind the plate for the Atlanta Braves-San Francisco Giants game Sunday, and fans didn&apos;t like his strike zone.

## WWE brand remains strong as company sells 90K tickets to upcoming WrestleMania 40
 - [https://www.foxnews.com/sports/wwe-brand-remains-strong-company-sells-90k-tickets-upcoming-wrestlemania-40](https://www.foxnews.com/sports/wwe-brand-remains-strong-company-sells-90k-tickets-upcoming-wrestlemania-40)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:16:49+00:00

WWE has already sold over $90,000 tickets to WrestleMania 40. The event will take place on April 6 and April 7, 2024, in Philadelphia, Pennsylvania.

## Cowboys' Jerry Jones backs Dak Prescott amid pursuit to get back to Super Bowl: 'We have a quarterback'
 - [https://www.foxnews.com/sports/cowboys-jerry-jones-backs-dak-prescott-pursuit-get-back-super-bowl-we-have-quarterback](https://www.foxnews.com/sports/cowboys-jerry-jones-backs-dak-prescott-pursuit-get-back-super-bowl-we-have-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:07:19+00:00

Dallas Cowboys owner Jerry Jones had big praise for Dak Prescott and said he believes the former Mississippi State standout can take the team to the promised land.

## 8 injured in Minneapolis shooting, including 6 teens
 - [https://www.foxnews.com/us/8-injured-minneapolis-shooting-including-6-teens](https://www.foxnews.com/us/8-injured-minneapolis-shooting-including-6-teens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:06:04+00:00

A total of eight people were shot in Minneapolis, Minnesota. Six of the eight people who were shot were teens. All of the victims are expected to survive.

## GOP lawmaker demands NYC drop charges against migrant shelter protestors
 - [https://www.foxnews.com/politics/gop-lawmaker-nyc-arrests-people-protesting-migrant-housing](https://www.foxnews.com/politics/gop-lawmaker-nyc-arrests-people-protesting-migrant-housing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:00:39+00:00

Rep. Nicole Malliotakis spoke with Fox News Digital about reported plans of a nursing home in her district being converted to a migrant shelter and is calling for charges to be dropped against those who protested.

## Oliver Anthony predicts US will not last ‘more than another generation’ unless country changes course
 - [https://www.foxnews.com/media/oliver-anthony-predicts-us-not-last-another-generation-unless-country-changes-course](https://www.foxnews.com/media/oliver-anthony-predicts-us-not-last-another-generation-unless-country-changes-course)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:00:35+00:00

&quot;Rich Men North of Virginia&quot; singer Oliver Anthony said that he does not believe the United States will last more than another decade at its current rate.

## Despite FBI takedown, infamous Raccoon Stealer malware returns
 - [https://www.foxnews.com/tech/despite-fbi-takedown-infamous-raccoon-stealer-malware-returns](https://www.foxnews.com/tech/despite-fbi-takedown-infamous-raccoon-stealer-malware-returns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T12:00:01+00:00

The Raccoon Stealer malware strain is proving that some cyber pests never go extinct, even after the FBI orchestrated a takedown of its digital infrastructure.

## Austin PD hundreds of officers short as crime cripples city, union warns: 'Don't have the resources'
 - [https://www.foxnews.com/media/austin-pd-hundreds-officers-short-crime-cripples-city-union-warns-resources](https://www.foxnews.com/media/austin-pd-hundreds-officers-short-crime-cripples-city-union-warns-resources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:57:24+00:00

Austin Police Association President Thomas Villarreal warns lawmakers&apos; efforts to defund the police have left the residents vulnerable to surging crime.

## Dramatic video shows drunk driver smashing into speeding train
 - [https://www.foxnews.com/world/dramatic-video-drunk-driver-smashing-into-speeding-train](https://www.foxnews.com/world/dramatic-video-drunk-driver-smashing-into-speeding-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:50:19+00:00

A driver in Taiwan was trying to get breakfast after a night out drinking when he sped through the barrier of a train crossing and smashed into the side of the train.

## More than a dozen women used firearms to protect against violent exes, criminals over 2-week stretch
 - [https://www.foxnews.com/us/more-than-dozen-women-used-firearms-protect-against-violent-exes-criminals-two-week-period](https://www.foxnews.com/us/more-than-dozen-women-used-firearms-protect-against-violent-exes-criminals-two-week-period)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:39:28+00:00

At least 13 women across the country used a firearm to protect themselves against an aggressor between July 29 and August 12, local news reports show.

## Military considers allowing calculators on entrance exam amid continued recruiting struggles: report
 - [https://www.foxnews.com/us/military-considers-allowing-calculators-entrance-exam-amid-continued-recruiting-struggles-report](https://www.foxnews.com/us/military-considers-allowing-calculators-entrance-exam-amid-continued-recruiting-struggles-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:35:47+00:00

The Pentagon is considering a change that would allow military applicants to use calculators on entrance exams as a way to alleviate the ongoing recruiting crisis.

## 3rd child dies in North Carolina following a house fire that erupted over the weekend
 - [https://www.foxnews.com/us/3rd-child-dies-north-carolina-house-fire-erupted-weekend](https://www.foxnews.com/us/3rd-child-dies-north-carolina-house-fire-erupted-weekend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:33:48+00:00

A house fire that erupted in North Carolina over the weekend has caused the deaths of three siblings. The children’s parents were not at home during the time of the blaze.

## Republicans using 'verbal jiu-jitsu' to turn liberals' language against them, analyst claims
 - [https://www.foxnews.com/media/republicans-using-verbal-jiu-jitsu-turn-liberals-language-against-them-analyst-claims](https://www.foxnews.com/media/republicans-using-verbal-jiu-jitsu-turn-liberals-language-against-them-analyst-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:31:06+00:00

CNN published a piece, “How conservatives use ‘verbal jiu-jitsu’ to turn liberals’ language against them,&quot; that detailed claims creative language has helped the GOP thrive.

## 'Jeopardy!' host Mayim Bialik shares photos from hospital: 'It's not terribly fun getting older'
 - [https://www.foxnews.com/entertainment/jeopardy-host-mayim-bialik-photos-hospital](https://www.foxnews.com/entertainment/jeopardy-host-mayim-bialik-photos-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T11:02:57+00:00

Mayim Bialik posted photos and a video to social media while she was in the hospital for a routine procedure, advising her followers to &quot;be proactive.&quot;

## Saudi border guards kill possibly hundreds of Ethiopian migrants arriving from Yemen, rights group says
 - [https://www.foxnews.com/world/saudi-border-guards-kill-possibly-hundreds-ethiopian-migrants-arriving-yemen-rights-group-says](https://www.foxnews.com/world/saudi-border-guards-kill-possibly-hundreds-ethiopian-migrants-arriving-yemen-rights-group-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:52:50+00:00

A rights group has alleged that Saudi guards near war-torn Yemen may have killed hundreds of Ethiopian migrants in the latest attack of an escalating pattern of border violence.

## Balkan leaders attend Greek meeting with top UN officials: Zelenskyy rumored to be attending
 - [https://www.foxnews.com/world/balkan-leaders-attend-greek-meeting-un-officials-zelenskyy-rumored-attending](https://www.foxnews.com/world/balkan-leaders-attend-greek-meeting-un-officials-zelenskyy-rumored-attending)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:51:50+00:00

Balkan leaders are set to meet on Aug. 21, 2023, in Greece&apos;s capital with UN officials, including Ursula von der Leyen. Ukrainian president Volodymyr Zelenskyy is expected to attend.

## Biden admin to renew push for Americans to get COVID-19 boosters
 - [https://www.foxnews.com/politics/biden-admin-renew-push-americans-get-covid-19-boosters](https://www.foxnews.com/politics/biden-admin-renew-push-americans-get-covid-19-boosters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:47:46+00:00

The White House will renew its push for Americans to get COVID-19 vaccine booster shots this fall as the CDC tracks more virus variants.

## John Fetterman blows up social media with new mustache, compared to 'Breaking Bad' character Walter White
 - [https://www.foxnews.com/media/john-fetterman-blows-up-social-media-new-mustache-compared-breaking-bad-character-walter-white](https://www.foxnews.com/media/john-fetterman-blows-up-social-media-new-mustache-compared-breaking-bad-character-walter-white)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:38:12+00:00

Sen. John Fetterman, D-Pa., is being compared to lead “Breaking Bad&quot; character &quot;Walter White&quot; after he shaved off his goatee and grew a mustache.

## 4 Mexicans killed while attempting to climb Pico de Orizaba, the country's highest peak
 - [https://www.foxnews.com/world/4-mexicans-killed-attempting-climb-pico-de-orizaba-countrys-highest-peake](https://www.foxnews.com/world/4-mexicans-killed-attempting-climb-pico-de-orizaba-countrys-highest-peake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:37:40+00:00

Four people died while climbing the highest mountain in Mexico, the Pico de Orizaba. All of the deaths appeared to have been caused by a fall.

## Ukrainian President Volodymyr Zelenskyy thanks Danish lawmakers for sending warplanes as Russian war continues
 - [https://www.foxnews.com/world/ukrainian-president-volodymyr-zelenskyy-thanks-danish-lawmakers-sending-warplanes-russian-war-continues](https://www.foxnews.com/world/ukrainian-president-volodymyr-zelenskyy-thanks-danish-lawmakers-sending-warplanes-russian-war-continues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:37:10+00:00

Volodymyr Zelenskyy, the president of Ukraine, thanked the Danish government for sending F-16 warplanes. Denmark and the Netherlands plan to deliver the planes by the end of the year.

## Riley Gaines slams men trying to 'silence' ex-college athlete at California library event
 - [https://www.foxnews.com/sports/riley-gaines-slams-men-trying-silence-ex-college-athlete-california-library-event](https://www.foxnews.com/sports/riley-gaines-slams-men-trying-silence-ex-college-athlete-california-library-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:32:28+00:00

Riley Gaines spoke out after a former college athlete Sophia Lorey&apos;s event was disrupted after Lorey was accused of &quot;misgendering&quot; during a speech about life as a soccer player.

## Trump leading DeSantis, Scott with 42% support among likely Iowa caucusgoers: poll
 - [https://www.foxnews.com/politics/trump-leading-desantis-scott-42-support-likely-iowa-caucusgoers-poll](https://www.foxnews.com/politics/trump-leading-desantis-scott-42-support-likely-iowa-caucusgoers-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:27:22+00:00

Former President Donald Trump has a more than 2-to-1 lead over his closest rival, Florida Gov. Ron DeSantis, in a new poll of likely Iowa GOP caucusgoers.

## Spanish police confirm Tenerife wildfire was started deliberately
 - [https://www.foxnews.com/world/spanish-police-confirm-tenerife-wildfire-was-started-deliberately](https://www.foxnews.com/world/spanish-police-confirm-tenerife-wildfire-was-started-deliberately)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:03:41+00:00

The Tenerife wildfire that has burned for five days was started intentionally, according to police. An investigation into who started the fire is ongoing.

## Freedom Caucus pours gasoline on Congress' heated spending fight as government shutdown fears grow
 - [https://www.foxnews.com/politics/freedom-caucus-congress-spending-fight-government-shutdown](https://www.foxnews.com/politics/freedom-caucus-congress-spending-fight-government-shutdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:00:41+00:00

The House Freedom Caucus said it will withhold support for a continuing resolution, which could be the only way to avoid a government shutdown after Sept. 30, unless several conservative policy items are attached to it.

## This prosecutor targeting Christians, putting Bible on trial, again
 - [https://www.foxnews.com/opinion/prosecutor-targeting-christians-putting-bible-trial-again](https://www.foxnews.com/opinion/prosecutor-targeting-christians-putting-bible-trial-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T10:00:37+00:00

Two people of faith head back to court on Aug. 31 to stand trial for simply being Christians. All who value Western Civilization should be gravely concerned.

## Queen classic 'Fat Bottomed Girls' dropped from band's greatest hits collection for younger audiences
 - [https://www.foxnews.com/media/queen-fat-bottomed-girls-dropped-band-greatest-hits-collection-younger-audiences](https://www.foxnews.com/media/queen-fat-bottomed-girls-dropped-band-greatest-hits-collection-younger-audiences)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:57:32+00:00

Some critics have blasted the decision to omit Queen&apos;s classic &quot;Fat Bottomed Girls&quot; from a new greatest hits track list geared toward younger audiences.

## Guatemalan presidential candidate wins in landslide but political elite could prevent him from taking office
 - [https://www.foxnews.com/world/guatemalan-presidential-candidate-wins-landslide-political-elite-could-prevent-him-taking-office](https://www.foxnews.com/world/guatemalan-presidential-candidate-wins-landslide-political-elite-could-prevent-him-taking-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:57:00+00:00

Guatemala’s governing elite could prevent the winner of Sunday&apos;s presidential election from assuming office in what has become completely new legal territory for the country.

## GOP debate moderator Martha MacCallum: 'The night is about the future of the country'
 - [https://www.foxnews.com/media/gop-debate-moderator-martha-maccallum-night-future-country](https://www.foxnews.com/media/gop-debate-moderator-martha-maccallum-night-future-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:50:27+00:00

Fox News anchor discusses her debate preparations ahead of Wednesday night&apos;s first Republican presidential primary debate in Milwaukee, Wisconsin.

## 2 men die in Ireland while competing in 1.2-mile swimming portion of Ironman event
 - [https://www.foxnews.com/sports/2-men-die-ireland-competing-1-2-mile-swimming-portion-ironman-event](https://www.foxnews.com/sports/2-men-die-ireland-competing-1-2-mile-swimming-portion-ironman-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:46:55+00:00

During the swimming portion of an Ironman event in Ireland, two male race participants, ages mid-60s and mid-40s, were pronounced dead at the scene.

## Chicago weekend shootings kill 7, including teens ahead of new school year; over 3 dozen people wounded
 - [https://www.foxnews.com/us/chicago-weekend-shootings-kill-7-including-teens-new-school-year-3-dozen-people-wounded](https://www.foxnews.com/us/chicago-weekend-shootings-kill-7-including-teens-new-school-year-3-dozen-people-wounded)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:41:56+00:00

At least 38 people were shot, seven of them fatally, in Chicago over the weekend. Those killed included teens supposed to start the new school year Monday.

## Lolita the orca dies at Miami Seaquarium as caregivers prepared to free the 57-year-captive mammal
 - [https://www.foxnews.com/us/lolita-orca-dies-miami-seaquarium-caregivers-prepared-free-57-year-captive-mammal](https://www.foxnews.com/us/lolita-orca-dies-miami-seaquarium-caregivers-prepared-free-57-year-captive-mammal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:39:20+00:00

After half a century of captivity, Lolita the orca has died at the Miami Seaquarium in Florida. Lolita died as her caregivers prepared to possibly move her to a natural sea pen.

## Musicians authorize strike against Philadelphia Orchestra
 - [https://www.foxnews.com/entertainment/musicians-authorize-strike-against-philadelphia-orchestra](https://www.foxnews.com/entertainment/musicians-authorize-strike-against-philadelphia-orchestra)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:38:00+00:00

At least 95% of voting members approved a strike against the Philadelphia Orchestra. The four-year deal is set to expire on Sept. 10, 2023.

## Protests in Syria spread as anger over increasing prices continues to grow in the war-torn country
 - [https://www.foxnews.com/world/protests-syria-spread-anger-over-increasing-prices-continues-grow-war-torn-country](https://www.foxnews.com/world/protests-syria-spread-anger-over-increasing-prices-continues-grow-war-torn-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:34:47+00:00

As anger over increasing prices across Syria continues to grow, more residents are beginning to protest. The country&apos;s president has increased wages, heightening inflation.

## 7 fans of Brazil’s Corinthians soccer team die after bus crashes, flips over
 - [https://www.foxnews.com/sports/7-fans-brazils-corinthians-soccer-team-die-bus-crashes-flips-over](https://www.foxnews.com/sports/7-fans-brazils-corinthians-soccer-team-die-bus-crashes-flips-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:34:12+00:00

At least seven people, who came to Belo Horizonte, Brazil, for a soccer championship game between teams Corinthians and Cruzeiro, have died in a bus crash.

## Ecuador votes against drilling oil in protected area of Amazon rainforest
 - [https://www.foxnews.com/world/ecuador-votes-against-drilling-oil-protected-area-amazon-rainforest](https://www.foxnews.com/world/ecuador-votes-against-drilling-oil-protected-area-amazon-rainforest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:33:44+00:00

The country of Ecuador voted to stop drilling for oil in Yasuni National Park, a protected area in the Amazon rainforest. The region is home to two uncontacted tribes.

## Block Island welcomes back vacationers a day after hotel fire spurs state of emergency
 - [https://www.foxnews.com/us/block-island-welcomes-back-vacationers-day-hotel-fire-spurs-state-emergency](https://www.foxnews.com/us/block-island-welcomes-back-vacationers-day-hotel-fire-spurs-state-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:33:15+00:00

A day after a state of emergency was declared on Block Island due to a hotel fire, the island has already reopened to vacationers. Firefighters were shipped in from around the state.

## Britney Spears gets licked by mystery man, goes topless in new videos shared days after announcing divorce
 - [https://www.foxnews.com/entertainment/britney-spears-gets-licked-mystery-man-goes-topless-new-videos-shared-days-announcing-divorce](https://www.foxnews.com/entertainment/britney-spears-gets-licked-mystery-man-goes-topless-new-videos-shared-days-announcing-divorce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:31:55+00:00

Britney Spears shared two suggestive videos to Instagram, days after she and Sam Asghari shared they had split. One video featured a man licking Spears&apos; leg.

## GOP Senator says Trump should drop out of 2024 race: ‘He will lose’
 - [https://www.foxnews.com/politics/gop-senator-says-trump-should-drop-2024-race-he-will-lose](https://www.foxnews.com/politics/gop-senator-says-trump-should-drop-2024-race-he-will-lose)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T09:22:01+00:00

A Republican senator ,called on former President Donald Trump to drop out of the 2024 presidential race, saying he would lose to President Biden.

## 1 killed, 13 injured in 3 separate Milwaukee shootings over the weekend
 - [https://www.foxnews.com/us/1-killed-13-injured-3-separate-milwaukee-shootings-weekend](https://www.foxnews.com/us/1-killed-13-injured-3-separate-milwaukee-shootings-weekend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:59:13+00:00

A person was killed, and thirteen others were injured in three different Milwaukee, Wisconsin, shootings over the weekend. Police have arrested two shooters.

## Wisconsin's role as swing state expected to be highlighted in upcoming GOP debate in Milwaukee
 - [https://www.foxnews.com/politics/wisconsins-role-swing-state-expected-highlighted-upcoming-gop-debate-milwaukee](https://www.foxnews.com/politics/wisconsins-role-swing-state-expected-highlighted-upcoming-gop-debate-milwaukee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:57:53+00:00

The Republican debate in Milwaukee is set for Aug. 23, 2023. Republicans chose to hold the debate, as well as the national convention, in the swing state.

## TikTok challenge leads to disruption of Georgia high school football game, officials say
 - [https://www.foxnews.com/sports/tiktok-challenge-leads-disruption-georgia-high-school-football-game-officials-say](https://www.foxnews.com/sports/tiktok-challenge-leads-disruption-georgia-high-school-football-game-officials-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:49:15+00:00

A game between Benedictine Military School and Herschel V. Jenkins High School on Friday night was disrupted by a TikTok challenge, according to officials.

## Last defendants set to begin Whitmer kidnapping plot trial nearly 3 years after plan was first uncovered
 - [https://www.foxnews.com/us/last-defendants-set-begin-whitmer-kidnapping-plot-trial-nearly-3-years-after-plan-first-uncovered](https://www.foxnews.com/us/last-defendants-set-begin-whitmer-kidnapping-plot-trial-nearly-3-years-after-plan-first-uncovered)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:35:45+00:00

The final defendants in the Whitmer kidnapping plot are set to go on trial on Aug. 21, 2023. Four people have already pleaded guilty for their roles in the plot.

## Michael Oher's former football coach praises Tuohy family amid drama: 'I think that’s admirable'
 - [https://www.foxnews.com/sports/michael-ohers-former-football-coach-praises-tuohy-family-drama-think-thats-admirable](https://www.foxnews.com/sports/michael-ohers-former-football-coach-praises-tuohy-family-drama-think-thats-admirable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:28:18+00:00

Auburn football coach Hugh Freeze on Thursday weighed in on the Michael Oher drama and praised the family for taking in the offensive lineman.

## Oliver Anthony says ‘Rich Men’ has ‘touched people globally’: 'Don’t have to be blue-collar’
 - [https://www.foxnews.com/media/oliver-anthony-reason-rich-men-touched-people-globally-blue-collar](https://www.foxnews.com/media/oliver-anthony-reason-rich-men-touched-people-globally-blue-collar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:25:10+00:00

&quot;Rich Men North of Virginia&quot; singer Oliver Anthony said the blue-collar anthem is a song for people around the world in his first on-camera interview.

## Mitt Romney mulls re-election bid in increasingly pro-Trump Utah
 - [https://www.foxnews.com/politics/mitt-romney-mulls-re-election-bid-increasingly-pro-trump-utah](https://www.foxnews.com/politics/mitt-romney-mulls-re-election-bid-increasingly-pro-trump-utah)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:15:25+00:00

Utah Senator Mitt Romney is considering plans to run for re-election, facing a potentially tough Republican primary in his increasingly pro-Trump state.

## China, Russia-led bloc wants to dethrone US dollar, upend world order
 - [https://www.foxnews.com/opinion/china-russia-led-bloc-wants-de-throne-us-dollar-upend-world-order](https://www.foxnews.com/opinion/china-russia-led-bloc-wants-de-throne-us-dollar-upend-world-order)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:00:47+00:00

The China, Russia-led BRICS bloc aims to challenge the U.S. by creating an alternative currency to the dollar. The group, including Brazil, India, South Africa, to meet this week.

## Negative coverage from ABC, NBC, CBS newscasts dominate GOP primary race, study finds
 - [https://www.foxnews.com/media/negative-coverage-from-abc-nbc-cbs-newscasts-dominate-gop-primary-race-study-finds](https://www.foxnews.com/media/negative-coverage-from-abc-nbc-cbs-newscasts-dominate-gop-primary-race-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:00:33+00:00

Between Jan. 1 and July 31, a whopping 90% of the coverage of former President Trump on ABC, CBS and NBC was negative, according to the Media Research Center.

## AI can guess your password with unprecedented accuracy by 'listening' to keystrokes
 - [https://www.foxnews.com/us/ai-can-guess-your-password-unprecedented-accuracy-listening-keystrokes](https://www.foxnews.com/us/ai-can-guess-your-password-unprecedented-accuracy-listening-keystrokes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:00:23+00:00

Cornell University published findings from a study Aug. 3 showing the ease with which AI can steal passwords by &quot;listening&quot; to keystrokes.

## 12 dead in Turkey after bus crashes into roadside ditch
 - [https://www.foxnews.com/world/12-dead-turkey-bus-crashes-roadside-ditch](https://www.foxnews.com/world/12-dead-turkey-bus-crashes-roadside-ditch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T08:00:11+00:00

A dozen people have died in the central Turkish city of Yozgat after a driver of a bus lost control of the vehicle, veered off the road, and crashed into a ditch.

## President Biden, Jill visit Hawaii for first time since wildfires devastated Maui
 - [https://www.foxnews.com/politics/president-biden-jill-visit-hawaii-first-time-since-wildfires-devastated-maui](https://www.foxnews.com/politics/president-biden-jill-visit-hawaii-first-time-since-wildfires-devastated-maui)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T07:35:37+00:00

President Biden and First Lady Jill Biden will visit Lahaina, on the island of Maui, for the first time Monday, after wildfires left 114 people dead.

## Bengals' Joe Mixon avoids specific reporters upon return to training camp
 - [https://www.foxnews.com/sports/bengals-joe-mixon-avoids-specific-reporters-upon-return-training-camp](https://www.foxnews.com/sports/bengals-joe-mixon-avoids-specific-reporters-upon-return-training-camp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T07:27:49+00:00

Cincinnati Bengals running back Joe Mixon was back at training camp after he was found not guilty in a recent court case, but he wasn&apos;t going to talk to every reporter.

## Maxie Baughan, NFL champion and nine-time Pro Bowler, dead at 85
 - [https://www.foxnews.com/sports/maxie-baughan-nfl-champion-nine-time-pro-bowler-dead](https://www.foxnews.com/sports/maxie-baughan-nfl-champion-nine-time-pro-bowler-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T07:15:48+00:00

NFL linebacker Maxie Baughan, who played several years in the league and was a nine-time Pro Bowler and one-time champ, has died at 85.

## South Dakota train strikes car, killing 2 passengers
 - [https://www.foxnews.com/us/south-dakota-train-strikes-car-killing-2-passengers](https://www.foxnews.com/us/south-dakota-train-strikes-car-killing-2-passengers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T07:05:14+00:00

A train in South Dakota crashed into a car, killing both of the passengers in the vehicle. The train derailed during the accident and crashed into a grain elevator.

## Ramaswamy earns second presidential endorsement from Iowa official in Treasurer Roby Smith
 - [https://www.foxnews.com/politics/ramaswamy-earns-second-presidential-endorsement-iowa-treasurer-roby-smith](https://www.foxnews.com/politics/ramaswamy-earns-second-presidential-endorsement-iowa-treasurer-roby-smith)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T07:00:52+00:00

FIRST ON FOX: Iowa Treasurer Roby Smith is backing Vivek Ramaswamy for president, marking the GOP hopeful&apos;s second endorsement in the Hawkeye State.

## Ken Cuccinelli bashes CNN for using edited clip of DeSantis: 'He wasn't talking about Trump supporters!'
 - [https://www.foxnews.com/media/ken-cuccinelli-bashes-cnn-using-edited-clip-desantis-he-wasnt-talking-about-trump-supporters](https://www.foxnews.com/media/ken-cuccinelli-bashes-cnn-using-edited-clip-desantis-he-wasnt-talking-about-trump-supporters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:56:22+00:00

Former Virginia Attorney General Ken Cuccinelli defended Ron DeSantis on CNN after the outlet showed an edited clip of the Republican presidential candidate.

## Biden's key immigration policy allowing hundreds of thousands of migrants to enter US faces trial this week
 - [https://www.foxnews.com/politics/bidens-key-immigration-policy-allowing-hundreds-thousands-migrants-enter-us-trial-week](https://www.foxnews.com/politics/bidens-key-immigration-policy-allowing-hundreds-thousands-migrants-enter-us-trial-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:47:25+00:00

A trial over a key part of President Biden&apos;s immigration policy, which Republican states argue is a violation of the U.S. Constitution, will be heard later this week.

## Spanish FA president's kiss on Jennifer Hermoso after Women's World Cup victory sparks controversy
 - [https://www.foxnews.com/sports/spanish-fa-presidents-kiss-jennifer-hermoso-womens-world-cup-victory-sparks-controversy](https://www.foxnews.com/sports/spanish-fa-presidents-kiss-jennifer-hermoso-womens-world-cup-victory-sparks-controversy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:38:55+00:00

Luis Rubiales, the president of Spain&apos;s FA, caused outrage when he kissed player Jennifer Hermoso on the lips during their Women&apos;s World Cup celebration.

## Bidens take break from vacation to tour Hawaii devastation, Hilary ravages California and more top headlines
 - [https://www.foxnews.com/us/bidens-visit-hawaii-following-lack-response-hilary-ravages-california](https://www.foxnews.com/us/bidens-visit-hawaii-following-lack-response-hilary-ravages-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:30:45+00:00

Bidens to visit Hawaii following lack of response, Hilary ravages California and more top headlines

## Spanish soccer hero Olga Carmona learns of father’s death after decisive Women's World Cup final goal
 - [https://www.foxnews.com/sports/spanish-soccer-hero-olga-carmona-learns-fathers-death-decisive-womens-world-cup-final-goal](https://www.foxnews.com/sports/spanish-soccer-hero-olga-carmona-learns-fathers-death-decisive-womens-world-cup-final-goal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:25:47+00:00

Spanish soccer star Olga Carmona scored the game-winning goal against England in the Women&apos;s World Cup Final on Sunday. Shortly after, she learned of her father&apos;s passing.

## San Francisco retailer challenges Mayor Breed to swap jobs for 180 days: 'You'd see a lot of change'
 - [https://www.foxnews.com/media/san-francisco-retailer-challenges-mayor-breed-swap-jobs-180-days](https://www.foxnews.com/media/san-francisco-retailer-challenges-mayor-breed-swap-jobs-180-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:00:35+00:00

In an interview with Fox News Digital, Gump&apos;s luxury department store owner John Chachas blasted top Democrats in California over the turmoil erupting in the streets of San Francisco.

## Biden's war against the lands, waters and American workers just got even bigger
 - [https://www.foxnews.com/opinion/bidens-war-against-lands-waters-american-workers-just-got-even-worse](https://www.foxnews.com/opinion/bidens-war-against-lands-waters-american-workers-just-got-even-worse)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T06:00:05+00:00

President Biden has declared war on U.S. lands and waters that secure our energy independence, are lifelines to rural economies, and provide a wide variety of activities and jobs.

## California Gov. Gavin Newsom meets with local leaders, first responders as Tropical Storm Hilary hits state
 - [https://www.foxnews.com/weather/california-gov-gavin-newsom-meets-local-leaders-first-responders-tropical-storm-hilary-hits-state](https://www.foxnews.com/weather/california-gov-gavin-newsom-meets-local-leaders-first-responders-tropical-storm-hilary-hits-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T05:48:36+00:00

California Gov. Gavin Newsom on Sunday met with local leaders and first responders in impacted communities as Tropical Storm Hilary made landfall.

## William Byron picks up season-leading 5th NASCAR win as playoffs loom
 - [https://www.foxnews.com/sports/william-byron-picks-up-season-leading-5th-nascar-win-playoffs-loom](https://www.foxnews.com/sports/william-byron-picks-up-season-leading-5th-nascar-win-playoffs-loom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T05:41:02+00:00

William Byron picked up his fifth win of the season, this time coming at Watkins Glen International. He beat out Denny Hamlin by nearly 3 seconds.

## Texas kindergartner dropped off at wrong bus stop, returned to school by strangers: mother
 - [https://www.foxnews.com/us/texas-kindergartner-dropped-off-wrong-bus-stop-returned-school-strangers](https://www.foxnews.com/us/texas-kindergartner-dropped-off-wrong-bus-stop-returned-school-strangers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T05:21:26+00:00

A kindergartner in Texas did not come home from his first day of school on his designated bus, but instead was let off at the wrong stop and brought back to school by a random family.

## Democrats 'extremely lucky' to run with Biden, 'not grateful enough': NYT columnist
 - [https://www.foxnews.com/media/democrats-extremely-lucky-run-biden-not-grateful-nyt-columnist](https://www.foxnews.com/media/democrats-extremely-lucky-run-biden-not-grateful-nyt-columnist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T05:00:24+00:00

New York Times columnist David Brooks argued that Democrats should be grateful to run President Biden in the 2024 election despite his low approval ratings.

## Hawaii gov agrees climate change 'amplified the cost of human error' on Maui fires
 - [https://www.foxnews.com/media/hawaii-gov-agrees-climate-change-amplified-cost-human-error-maui-fires](https://www.foxnews.com/media/hawaii-gov-agrees-climate-change-amplified-cost-human-error-maui-fires)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T04:00:47+00:00

Hawaii Gov. Josh Green agreed with “Face the Nation&quot; host Margaret Brennan on Sunday that climate change worsened the results of the Hawaii wildfires.

## Biden's open border worsens fatherhood crisis in America
 - [https://www.foxnews.com/opinion/bidens-open-border-worsens-fatherhood-crisis-in-america](https://www.foxnews.com/opinion/bidens-open-border-worsens-fatherhood-crisis-in-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T04:00:34+00:00

The fatherhood crisis in America has been exacerbated at a dramatic rate as President Biden&apos;s southern border crisis worsens and has descended into total chaos.

## Biden admin accused of abandoning 3 US residents held in Iran as part of 'ransom' payment to regime
 - [https://www.foxnews.com/world/biden-admin-accused-abandoning-3-us-residents-held-iran-part-ransom-payment-regime](https://www.foxnews.com/world/biden-admin-accused-abandoning-3-us-residents-held-iran-part-ransom-payment-regime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T04:00:33+00:00

Biden&apos;s deal to funnel $6 billion to Iran&apos;s regime in exchange for the release of five U.S. hostages if facing criticism for failing to include additional U.S. residents held by Iran.

## ‘Hercules’ actor Kevin Sorbo says Hollywood canceled him because of his Christian beliefs
 - [https://www.foxnews.com/entertainment/hercules-actor-kevin-sorbo-hollywood-canceled-christian-beliefs](https://www.foxnews.com/entertainment/hercules-actor-kevin-sorbo-hollywood-canceled-christian-beliefs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T04:00:21+00:00

Kevin Sorbo, who skyrocketed to fame in the &apos;90s portraying Greek demigod Hercules, opened up about being canceled in Hollywood because of his Christian beliefs and conservative views.

## Julian Assange supporters demand charges be dropped in vigil outside Merrick Garland’s home
 - [https://www.foxnews.com/politics/julian-assange-supporters-demand-charges-dropped-vigil-merrick-garlands-home](https://www.foxnews.com/politics/julian-assange-supporters-demand-charges-dropped-vigil-merrick-garlands-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T03:45:46+00:00

Supporters of journalist Julian Assange gathered outside Attorney General Merrick Garland&apos;s home for a vigil demanding the charges against the Wikileaks founder be dropped.

## Americans critical of Biden’s response to Maui devastation: ‘What kind of president is he?’
 - [https://www.foxnews.com/media/americans-critical-bidens-response-maui-devastation-kind-president](https://www.foxnews.com/media/americans-critical-bidens-response-maui-devastation-kind-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T02:00:58+00:00

Americans weighed in on Biden&apos;s handling of the Maui wildfires amid scrutiny over his initial response and the original aid offered to Hawaiians affected by the disaster.

## Ask a doc: 25 burning questions about AI and health care answered by an expert
 - [https://www.foxnews.com/health/ask-doc-25-burning-questions-ai-health-care-answered-expert](https://www.foxnews.com/health/ask-doc-25-burning-questions-ai-health-care-answered-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T02:00:43+00:00

As artificial intelligence continues to ramp up in health care, some patients may be uncertain or curious. Dr. Harvey Castro, a Texas ER physician, answers 25 of the most common patient questions.

## Jeffrey Epstein once said Prince Andrew 'likes sex more than me,' doc claims
 - [https://www.foxnews.com/entertainment/jeffrey-epstein-once-said-prince-andrew-likes-sex-more-me-doc-claims](https://www.foxnews.com/entertainment/jeffrey-epstein-once-said-prince-andrew-likes-sex-more-me-doc-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T02:00:26+00:00

Prince Andrew, the son of Queen Elizabeth II and Prince Philip, stepped back from royal duties in 2019 due to his connection to convicted sex offender Jeffrey Epstein.

## 5 indications Joe Biden will not run in 2024
 - [https://www.foxnews.com/opinion/5-indications-joe-biden-not-run-2024](https://www.foxnews.com/opinion/5-indications-joe-biden-not-run-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T02:00:07+00:00

Though Joe Biden was mocked for seemingly campaigning for president from his basement in 2020, this summer he appears to be campaigning from the beach.

## Who is Leni Klum? Daughter of supermodel Heidi Klum following in her mom’s footsteps
 - [https://www.foxnews.com/entertainment/leni-klum-daughter-supermodel-heidi-klum-following-moms-footsteps](https://www.foxnews.com/entertainment/leni-klum-daughter-supermodel-heidi-klum-following-moms-footsteps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T00:12:13+00:00

Heidi Klum&apos;s daughter, Leni, made headlines over the weekend with a series of bikini photos on a yacht, further adding to her role in the spotlight as an up-and-coming model.

## On this day in history, August 21, 1959, Hawaii becomes the 50th state: 'A stronger nation'
 - [https://www.foxnews.com/lifestyle/this-day-history-august-21-1959-hawaii-becomes-50th-state-nation](https://www.foxnews.com/lifestyle/this-day-history-august-21-1959-hawaii-becomes-50th-state-nation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-08-21T00:02:30+00:00

Hawaii officially became a U.S. state on this day in history, August 21, 1959, after more than half a century as a territory. The day is known as &quot;Statehood Day.&quot;

