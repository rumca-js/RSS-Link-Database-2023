# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Burmistrz Kcyni Marek Szaruga nie żyje. Miał 59 lat. "Wiadomość, w którą trudno uwierzyć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103048,burmistrz-kcyni-marek-szaruga-nie-zyje-mial-59-lat-trudno.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103048,burmistrz-kcyni-marek-szaruga-nie-zyje-mial-59-lat-trudno.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T20:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/b5/1c/z30103060M,Burmistrz-Kcyni-Marek-Szaruga.jpg" vspace="2" />Nie żyje burmistrz Kcyni Marek Szaruga. Samorządowiec zmarł 19 sierpnia podczas urlopu. "To bardzo smutna wiadomość, w którą jest nam nadal bardzo trudno uwierzyć" - napisała poinformował urząd miasta.

## Karambol pod Olsztynem. W zderzeniu pięciu pojazdów ucierpiało sześć osób. Wśród nich są dzieci
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102990,karambol-pod-olsztynem-w-zderzeniu-pieciu-pojazdow-ucierpialo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102990,karambol-pod-olsztynem-w-zderzeniu-pieciu-pojazdow-ucierpialo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T20:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/b5/1c/z30103015M,Do-poteznego-karambolu-z-udzialem-pieciu-pojazdow-.jpg" vspace="2" />Na drodze krajowej nr 16 łączącej miejscowości Olsztyn i Barczewo (woj. warmińsko-mazurskie) doszło do potężnego karambolu. W zdarzeniu uczestniczyło aż pięć pojazdów. W wyniku zdarzenia sześć osób odniosło obrażenia, z czego cztery z nich wymagały hospitalizacji. Wśród poszkodowanych są dzieci.

## Błaszczak: Departament Stanu zatwierdził sprzedaż Polsce 96 śmigłowców uderzeniowych AH-64E Apache
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103004,blaszczak-departament-stanu-zatwierdzil-sprzedaz-polsce-96.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103004,blaszczak-departament-stanu-zatwierdzil-sprzedaz-polsce-96.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T19:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/b5/1c/z30103030M,AH-64E-Apache.jpg" vspace="2" />Minister obrony narodowej Mariusz Błaszczak poinformował, że amerykański Departament Stanu zatwierdził sprzedaż Polsce 96 śmigłowców uderzeniowych AH-64E Apache.

## Prigożyn przebywa w Afryce? Jest nagranie. "Czynimy Rosję potężniejszą na wszystkich kontynentach"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102962,prigozyn-przebywa-w-afryce-jest-nagranie-czynimy-rosje-potezniejsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102962,prigozyn-przebywa-w-afryce-jest-nagranie-czynimy-rosje-potezniejsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T19:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bd/b5/1c/z30102973M,Jewgienij-Prigozyn.jpg" vspace="2" />W mediach społecznościowych pojawiło się nagrania, z którego wynika, iż Jewgienij Prigożyn ma przebywać w Afryce. Tam ma walczyć z "ISIS, Al-Kaidą i innymi bandami" o "sprawiedliwość i szczęście dla afrykańskich narodów".

## Ogromny baner Łukasza Mejzy wisi bez pozwolenia. Będzie kontrola konserwatora zabytków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102921,ogromny-baner-lukasza-mejzy-wisi-bez-pozwolenia-bedzie-kontrola.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102921,ogromny-baner-lukasza-mejzy-wisi-bez-pozwolenia-bedzie-kontrola.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T19:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c5/b5/1c/z30102981M,Plakat-Lukasza-Mejzy-w-Zaganiu.jpg" vspace="2" />Łukasz Mejza wywiesił ogromny plakat wyborczy na historycznym budynku w Żaganiu. Poseł zrobił to bez pozwolenia konserwatora zabytków. Urzędnicy zapowiadają kontrolę.

## Kołodziejczak powołuje się na słowa ojca premiera. "Nie współpracuj z Mateuszem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102858,kolodziejczak-powoluje-sie-na-slowa-ojca-premiera-nie-wspolpracuj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102858,kolodziejczak-powoluje-sie-na-slowa-ojca-premiera-nie-wspolpracuj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T19:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/61/b5/1c/z30102881M,Premier-Mateusz-Morawiecki-opublikowal-w-serwisie-.jpg" vspace="2" />Trwa wymiana zdań pomiędzy premierem Mateuszem Morawieckim a Michałem Kołodziejczakiem. - Kornel Morawiecki powiedział mi jasno: proszę uważać na mojego syna, ja nie rozumiem jego decyzji - mówił prezes Agrounii podczas konferencji pod siedzibą TVP.

## Sondaż: Prawie 50 proc. Polaków chce wziąć udział w referendum. "Sukces PiS-u"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30102863,sondaz-prawie-50-proc-polakow-chce-wziac-udzial-w-referendum.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30102863,sondaz-prawie-50-proc-polakow-chce-wziac-udzial-w-referendum.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T19:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/31/fe/1b/z29353521M,Mateusz-Morawiecki-i-Jaroslaw-Kaczynski.jpg" vspace="2" />Aż 48,1 proc. Polaków chce wziąć udział w październikowym referendum - wynika z badania UCE Reaserch. - Skoro z sondażu wynika obecnie prawie 50-procentowa frekwencja, jest to sukces PiS-u - stwierdził politolog prof. Antoni Dudek. W trakcie badań zapytano także respondentów o to, jak chcą odpowiedzieć na poszczególne pytania referendalne.

## Maciej Wąsik o zdarzeniu w Sarnowej Górze: Pomogłem ściągnąć śmigłowiec, bo mnie o to poproszono
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102873,maciej-wasik-o-zdarzeniu-w-sarnowej-gorze-pomoglem-sciagnac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102873,maciej-wasik-o-zdarzeniu-w-sarnowej-gorze-pomoglem-sciagnac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T18:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/b5/1c/z30102894M,Maciej-Wasik.jpg" vspace="2" />- Nie widziałem sytuacji, ale daleki byłbym od tego i nie radziłbym opozycji, by wydawali za wcześnie wyroki na temat pilotów - powiedział w Polsat News Maciej Wąsik. Wiceszef MSWiA komentował incydent z policyjnym śmigłowcem podczas pikniku wojskowego.

## Tysiąc złotych za nocleg pod Morskim Okiem. Biwakowicze naruszyli zakaz obowiązujący w TPN
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102592,tysiac-zlotych-za-nocleg-pod-morskim-okiem-biwakowicze-naruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102592,tysiac-zlotych-za-nocleg-pod-morskim-okiem-biwakowicze-naruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T18:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/b5/1c/z30102673M,Mezczyzni--ktorzy-biwakowali-w-poblizu-Morskiego-O.jpg" vspace="2" />"Nocleg pod gołym niebem w rejonie Morskiego Oka kosztował tych panów 1000 zł" - napisał na swoim Facebooku TPN, publikując zdjęcie dwóch mężczyzn i ich dobytku. Zatrzymując się na noc, turyści naruszyli zakaz mający chronić przyrodę i zapewniać bezpieczeństwo odwiedzającym.

## "Dlaczego państwo nas śledzą? Chodzicie za nami od TVP". Kuriozalne spotkanie Kołodziejczaka z patrolem policji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102648,policjanci-sledzili-kolodziejczaka-szukalismy-miejsca-do-rozmowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30102648,policjanci-sledzili-kolodziejczaka-szukalismy-miejsca-do-rozmowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T18:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fb/b5/1c/z30102779M,Konferencja-Michala-Kolodziejczaka.jpg" vspace="2" />Przedstawiciele AgroUnii twierdzą, że byli śledzeni przez policję po poniedziałkowej konferencji w sprawie TVP. Rzeczniczka ugrupowania Natalia Żyto opublikowała wideo, na którym widać kilkukrotne "spotkania" z funkcjonariuszami. - Przeszliśmy około pół kilometra po Świętokrzyskiej, więc to nie jest tak, że przypadkiem napotkaliśmy patrol policji kilka metrów dalej. Szukaliśmy miejsca, gdzie moglibyśmy w spokoju porozmawiać, a oni dalej szli - mówi nam Żyto.

## Tarnobrzeg. Nie żyje 12-latek znaleziony w stawie. Poszedł tam łowić ryby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102711,tarnobrzeg-nie-zyje-12-latek-znaleziony-w-stawie-poszedl-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102711,tarnobrzeg-nie-zyje-12-latek-znaleziony-w-stawie-poszedl-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T17:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/90/73/1c/z29833360M,Tasma-policyjna---zdjecie-ilustracyjne.jpg" vspace="2" />W stawie w Tarnobrzegu znaleziono nieprzytomnego 12-latka. Mimo reanimacji nie udało się go uratować. Najprawdopodobniej chłopiec udał się nad zbiornik wodny, ponieważ chciał łowić ryby.

## "Miało być duże wydarzenie, a wyszła wtopa". Złość w PiS na starcie objazdu Polski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101865,mialo-byc-duze-wydarzenie-a-wyszla-wtopa-zlosc-w-pis-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101865,mialo-byc-duze-wydarzenie-a-wyszla-wtopa-zlosc-w-pis-na.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T17:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c8/b5/1c/z30101960M,Wiec-PiS-w-Gorlicach.jpg" vspace="2" />Miało być efektowne wydarzenie w kampanii PiS, a doszło do awantury ze zwolennikami opozycji. W PiS krytyczne recenzje zebrał wiec w Gorlicach, gdzie premier Mateusz Morawiecki zainaugurował objazd Polski przez PiS-bus.

## Niedźwiedź gonił turystów w Tatrach. TPN tłumaczy, co oznacza stawanie na dwóch łapach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102372,niedzwiedz-gonil-turystow-w-tatrach-tpn-tlumaczy-co-oznacza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102372,niedzwiedz-gonil-turystow-w-tatrach-tpn-tlumaczy-co-oznacza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T16:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ab/b5/1c/z30102443M,Niedzwiedz---zdjecie-ilustracyjne.jpg" vspace="2" />Turyści poruszający się po tatrzańskiej Dolinie Jaworzynki przeżyli szok, gdy stanęli oko w oko z młodym niedźwiedziem. Zwierzę przez kilkaset metrów goniło grupę przerażonych spacerowiczów. Służby TPN tłumaczą zachowanie misia, obawiając się, że może być ono spowodowane zachowaniem ludzi.

## Półtorametrowy pyton pełzał obok budynków na poznańskiej Wildzie. Został złapany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102507,poltorametrowy-pyton-pelzal-obok-budynkow-na-poznanskiej-wildzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102507,poltorametrowy-pyton-pelzal-obok-budynkow-na-poznanskiej-wildzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T16:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/b5/1c/z30102593M,Pyton.jpg" vspace="2" />W nocy na poznańskiej Wildzie dostrzeżono pełzającego obok budynków pytona. Wąż mierzył 1,5 metra długości. Na miejsce wezwano Straż Miejską.

## Litwa zamyka przejścia graniczne, Białoruś reaguje. "Wymyśla nieistniejące zagrożenia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102413,litwa-zamyka-przejscia-graniczne-bialorus-reaguje-wymysla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102413,litwa-zamyka-przejscia-graniczne-bialorus-reaguje-wymysla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T16:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d2/ad/1c/z30068946M,Alaksandr-Lukaszenka.jpg" vspace="2" />"Decyzja strony litewskiej o zamknięciu przejść granicznych podyktowana była motywowaną politycznie chęcią stworzenia utrudnień dla własnych obywateli. (...) Władze sąsiedniego państwa są poważnie zaniepokojone tym, że ich obywatele widzą na własne oczy, że Białoruś jest bezpieczna" - napisało MSZ Białorusi.

## Incydent w Sarnowej Górze. RMF FM: Członek załogi Black Hawka spowodował śmiertelny wypadek 14 lat temu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102275,incydent-w-sarnowej-gorze-rmf-fm-czlonek-zalogi-black-hawka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102275,incydent-w-sarnowej-gorze-rmf-fm-czlonek-zalogi-black-hawka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T15:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6c/b5/1c/z30102380M,Smiglowiec-Black-Hawk---zdjecie-ilustracyjne.jpg" vspace="2" />Nowe ustalenia dotyczące incydentu z udziałem śmigłowca Black Hawk w Sarnowej Górze. Jak ustalił dziennikarz RMF FM, jednym z członków załogi był pilot, który kilkanaście lat temu spowodował śmiertelny wypadek śmigłowca wojskowego.

## Chcieli zemścić się na policjantce. Napadli na nią w tramwaju po służbie, by "nikt jej nie obronił"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101842,chcieli-zemscic-sie-na-policjantce-napadli-na-nia-w-tramwaju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101842,chcieli-zemscic-sie-na-policjantce-napadli-na-nia-w-tramwaju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T15:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/b5/1c/z30101909M,Policjantka---zdjecie-ilustracyjne.jpg" vspace="2" />Nawet pięć lat więzienia grozi parze, która w ramach zemsty zaatakowała funkcjonariuszkę. Według informacji przekazanych przez łódzką policję 28-latek i 25-latka mieli kilkakrotnie uderzyć policjantkę i grozić jej śmiercią. - Krzyczeli przy tym, że nie jest na służbie i nikt jej nie obroni - relacjonowała asp. Kamila Sowińska.

## USA wzywa swoich obywateli do opuszczenia Białorusi. "Natychmiast"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102272,usa-wzywa-swoich-obywateli-do-opuszczenia-bialorusi-natychmiast.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30102272,usa-wzywa-swoich-obywateli-do-opuszczenia-bialorusi-natychmiast.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T14:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/82/1b/z28845912M,Pilne.jpg" vspace="2" />"Obywatele USA przebywający w Białorusi powinni natychmiast wyjechać" - zaapelowała Ambasada Stanów Zjednoczonych w Mińsku. Ma to związek z zamknięciem przez Litwę dwóch przejść granicznych. Wilno podjęło tę decyzję między innymi w związku z zagrożeniem ze strony najemników z Grupy Wagnera.

## Katarzyna Sójka już dzieli i rządzi w resorcie zdrowia. "GW": Robi prywatę pod kampanię wyborczą
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30101922,katarzyna-sojka-juz-dzieli-i-rzadzi-w-resorcie-zdrowia-gw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30101922,katarzyna-sojka-juz-dzieli-i-rzadzi-w-resorcie-zdrowia-gw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T14:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/ac/1c/z30065253M,Katarzyna-Sojka.jpg" vspace="2" />Trasa prozdrowotnej kampanii "Zdrowe życie" została zmieniona. Na początku września pojedzie ona do Krotoszyna, skąd do Sejmu startuje nowa ministerka zdrowia Katarzyna Sójka - podaje "Gazeta Wyborcza". "Nieoficjalnie dowiedzieliśmy się, że PZU w sprawie zmiany lokalizacji nie miało nic do powiedzenia" - podkreśla "GW".

## Kojarzony z Sasinem, ale w PiS za nim nie przepadają. Szafarowicz wystartuje w wyborach? "Trudniej się go czepiać"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101808,kojarzony-z-sasinem-w-obozie-rzadzacym-niezbyt-lubiany-wystartuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101808,kojarzony-z-sasinem-w-obozie-rzadzacym-niezbyt-lubiany-wystartuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T14:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/b5/1c/z30102016M,Oskar-Szafarowicz.jpg" vspace="2" />Oskar Szafarowicz ma być przymierzany do startu z list Prawa i Sprawiedliwości. Jak słyszymy, w obozie rządzącym do młodego działacza nie wszyscy pałają sympatią. - Sporo osób u nas mu zazdrości - mówi nam jeden z polityków PiS.

## Wąż schował się w lodówce supermarketu. Nietypowa interwencja strażaków z Kędzierzyna-Koźla
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101431,waz-schowal-sie-w-lodowce-supermarketu-nietypowa-interwencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101431,waz-schowal-sie-w-lodowce-supermarketu-nietypowa-interwencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T13:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/b5/1c/z30101528M,Do-weza-ukrytego-w-lodowce-jednego-z-supermarketow.jpg" vspace="2" />Tego wezwania strażacy z oddziału w Kędzierzynie-Koźlu (woj. opolskie) długo nie zapomną. W jednej z lodówek należących do tamtejszego supermarketu ukrył się wąż. Przybyłe na miejsce służby odłowiły gada i przekazały go w ręce organu weterynarii.

## Tragiczny wypadek w Podgórze. Osobówka zderzyła się z ciężarówką. "Kierowca spłonął w aucie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101656,tragiczny-wypadek-w-podgorze-osobowka-zderzyla-sie-z-ciezarowka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101656,tragiczny-wypadek-w-podgorze-osobowka-zderzyla-sie-z-ciezarowka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T13:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f4/b5/1c/z30101748M,Tragiczny-wypadek-w-Podgorze--Osobowka-zderzyla-si.jpg" vspace="2" />W Podgórze doszło do tragicznego wypadku. Samochód osobowy zjechał na przeciwległy pas i zderzył się czołowo z ciężarówką. Auta stanęły w płomieniach. Kierowca osobówki zginął na miejscu.

## Incydent ze śmigłowcem Black Hawk. Prokuratura wszczyna śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101560,incydent-ze-smiglowcem-black-hawk-prokuratura-wszczyna-sledztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101560,incydent-ze-smiglowcem-black-hawk-prokuratura-wszczyna-sledztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T12:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/b5/1c/z30101661M,Smiglowiec-Black-Hawk-zerwal-linie-energetyczne.jpg" vspace="2" />Policyjny Black Hawk podczas pikniku wojskowego w Sarnowej Górze doprowadził do zerwania linii energetycznej. Prokuratura wszczęła śledztwo w tej sprawie - podaje Polsat News.

## Tusk odpowiada Kaczyńskiemu ws. debaty: Nie ma się co wstydzić, godzinka i po bólu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101203,tusk-odpowiada-kaczynskiemu-ws-debaty-nie-ma-sie-co-wstydzic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30101203,tusk-odpowiada-kaczynskiemu-ws-debaty-nie-ma-sie-co-wstydzic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T12:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/b4/1c/z30101279M,Jaroslaw-Kaczynski.jpg" vspace="2" />Jarosław Kaczyński nie chce debaty z Donaldem Tuskiem i wskazuje na innego potencjalnego rozmówcę. Lider Platformy Obywatelskiej zachęca prezesa PiS, mówiąc, że będzie to "godzinka debaty i po bólu".

## Cofał na autostradzie A4. Uderzył w inny samochód i pogryzł jego kierowcę. Tłumaczył się upałem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100968,cofal-na-autostradzie-a4-uderzyl-w-inny-samochod-i-pogryzl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100968,cofal-na-autostradzie-a4-uderzyl-w-inny-samochod-i-pogryzl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T12:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/b4/1c/z30101093M,Wypadek-na-autostradzie-A4.jpg" vspace="2" />Policjanci zatrzymali 30-letniego mężczyznę, który na opolskim odcinku autostrady A4 niespodziewanie zaczął cofać, czym powodował kolizję z innym autem. Po stłuczce mężczyzna chciał uciec pieszo. Kiedy świadkowie obecni na miejscu stłuczki próbowali go zatrzymać, 30-latek pogryzł poszkodowanego w kolizji kierowcę.

## Pielęgniarka zabijała noworodki w szpitalu w Wielkiej Brytanii. Została skazana na dożywocie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30101189,pielegniarka-zabijala-noworodki-w-szpitalu-w-wielkiej-brytanii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30101189,pielegniarka-zabijala-noworodki-w-szpitalu-w-wielkiej-brytanii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T12:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/b3/1c/z30094758M,Lucy-Letby.jpg" vspace="2" />- Zamordowałaś siedmioro dzieci i próbowałeś zamordować sześć innych, w przypadku jednego z nich podejmując próbę dwa razy. Działałaś w sposób, który był całkowicie sprzeczny z normalnymi ludzkimi instynktami - zwrócił się do pielęgniarki Lucy Letby, nieobecnej podczas odczytywania wyroku, sędzia. Kobieta, która pisała o sobie, że jest "diabłem", została skazana na dożywocie.

## Wielkopolska. Sześcioletnia dziewczynka wjechała pod samochód. Helikopter zabrał ją do szpitala
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100583,wielkopolska-szescioletnia-dziewczynka-wjechala-pod-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100583,wielkopolska-szescioletnia-dziewczynka-wjechala-pod-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T12:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/b4/1c/z30101063M,Dziewczynka-wjechala-pod-samochod-w-powiecie-ostro.jpg" vspace="2" />Sześcioletnia dziewczynka wpadła pod samochód w miejscowości Sieroszewice w Wielkopolsce. Nie usłyszała ostrzeżenia ojca przed nadjeżdżającym busem i gwałtownie skręciła na ulicę. Pogotowie przywiozło ją do szpitala w Ostrowie Wielkopolskim, gdzie lekarze wykryli złamanie kości czaszki. Sześciolatka została przetransportowana helikopterem do szpitala w Poznaniu.

## Łukaszenka o relacjach z Putinem. "Nie jest już dawnym sobą". "Polacy zacierają ręce"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30100668,lukaszenka-o-relacjach-z-putinem-nie-jest-juz-dawnym-soba.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30100668,lukaszenka-o-relacjach-z-putinem-nie-jest-juz-dawnym-soba.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T11:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/76/b4/1c/z30101110M,Alaksandr-Lukaszenka-podczas-wywiadu.jpg" vspace="2" />Alaksandr Łukaszenka opowiedział w wywiadzie o swoich relacjach z Władimirem Putinem. - Nie jest już dawnym sobą. Jest teraz mądrzejszy i bardziej przebiegły - stwierdził. Wróży także Putinowi zwycięstwo w nadchodzących wyborach prezydenckich. Rozmowę z białoruskim dyktatorem przeprowadziła prorosyjska "dziennikarka", która napędzała kremlowską propagandę. Służba Bezpieczeństwa Ukrainy wszczęła w jej sprawie śledztwo.

## Kołodziejczak przed TVP reaguje na pytanie działacza PiS, mówi o pozwie w trybie wyborczym
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30100729,kolodziejczak-przed-tvp-zapowiada-pozew-w-trybie-wyborczym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30100729,kolodziejczak-przed-tvp-zapowiada-pozew-w-trybie-wyborczym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T11:41:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/70/b4/1c/z30101104M,Kolodziejczak-przed-TVP-zapowiada-pozew-w-trybie-w.jpg" vspace="2" />Oskar Szafarowicz, młody działacz PiS-u i pracownik banku PKO BP pojawił się na poniedziałkowej konferencji Michała Kołodziejczaka i działaczy AgroUnii przed siedzibą TVP. Chciał zadać pytanie "od obywatela". Szef AgroUnii szybko mu przerwał i zapowiedział pozew w trybie wyborczym.

## W Płocku 36-latka zostawiła w rozgrzanym aucie 10-latka i niemowlę. Musiała iść do solarium
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100754,w-plocku-36-latka-zostawila-w-rozgrzanym-aucie-10-latka-i-niemowle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100754,w-plocku-36-latka-zostawila-w-rozgrzanym-aucie-10-latka-i-niemowle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T11:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/96/1c/z29975044M,Dziecko-w-samochodzie--zdjecie-ilustracyjne-.jpg" vspace="2" />36-latka z Płocka zaparkowała w niedozwolonym miejscu, po czym zostawiła w samochodzie dwójkę swoich dzieci w wieku 10 lat i 9 miesięcy. Kluczyków nie wyciągnęła ze stacyjki auta. Sama poszła do solarium.

## OKO.press: Sędzia wydał wyrok ws. okładki "Gazety Polskiej". Dostał dyscyplinarkę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30100772,oko-press-sedzia-wydal-wyrok-ws-okladki-gazety-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30100772,oko-press-sedzia-wydal-wyrok-ws-okladki-gazety-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T11:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/02/72/1b/z28781314M,Tomasz-Sakiewicz.jpg" vspace="2" />Sędzia Tomasz Jaskłowski z Warszawy dostał dyscyplinarkę po wyroku w sprawie okładki "Gazety Polskiej". Zawiadomienie na niego złożył redaktor naczelny gazety Tomasz Sakiewicz, który przegrał proces - pisze OKO.press.

## Gniezno. Nagła śmierć uczestniczki wycieczki. Przed wejściem do autokaru zemdlała. Chwilę później zmarła
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100446,mieli-wspolnie-jechac-nad-morze-jedna-z-uczestniczek-wycieczki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100446,mieli-wspolnie-jechac-nad-morze-jedna-z-uczestniczek-wycieczki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T11:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/b4/1c/z30100581M,Ambulans--zdjecie-ilustracyjne-.jpg" vspace="2" />Na parkingu przy ulicy Sobieskiego w Gnieźnie jedna z uczestniczek wyjazdu wypoczynkowego nad polskie morze zasłabła, zanim wsiadła do autokaru. Doszło do zatrzymania krążenia. Mimo podjętej reanimacji nie udało się jej uratować.

## Wstrząsające odkrycie w centrum Bytomia. Znaleziono ciało 30-latka. "Bierzemy wszystko pod uwagę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100470,wstrzasajace-odkrycie-w-centrum-bytomia-znaleziono-cialo-30-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100470,wstrzasajace-odkrycie-w-centrum-bytomia-znaleziono-cialo-30-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T10:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/b4/1c/z30099587M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W centrum Bytomia przypadkowy przechodzień natknął się w nocy z niedzieli na poniedziałek na zwłoki 30-latka. Obecnie trwa ustalanie okoliczności śmierci mężczyzny, co może utrudniać brak kamer monitoringu w miejscu znalezienia ciała. - Bierzemy wszystko pod uwagę - przekazała st. asp. Anna Lenkiewicz z KMP w Bytomiu.

## Krzyki, przekleństwa i płacz dzieci - nagranie z przelotu śmigłowca nad ludźmi. Są pytania do Morawieckiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100302,krzyki-przeklenstwa-i-placz-dzieci-nagranie-z-przelotu-smiglowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100302,krzyki-przeklenstwa-i-placz-dzieci-nagranie-z-przelotu-smiglowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T10:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8f/b4/1c/z30100623M,Krzyki--przeklenstwa-i-placz-dzieci---nagranie-z-p.jpg" vspace="2" />Najpierw słowa uznania dla policyjnego Black Hawka, podziwianego z bardzo bliska w czasie jego lotu, a za chwilę krzyki, przekleństwa, panika i płacz dzieci - to 60 sekund z pikniku wojskowego w Sarnowej Górze koło Ciechanowa, nagrane przez jednego z uczestników imprezy. Policyjny śmigłowiec doprowadził do zerwania linii energetycznej. W sprawie incydentu u premiera interweniuje jeden z senatorów opozycji, z kolei policja prowadzi "czynności wyjaśniające".

## Belgia nie zwiększy dozwolonego limitu prędkości na autostradach. Za to Czesi chcą jeździć szybciej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30100427,belgia-nie-zwiekszy-dozwolonego-limitu-predkosci-na-autostradach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30100427,belgia-nie-zwiekszy-dozwolonego-limitu-predkosci-na-autostradach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T10:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cc/a0/1c/z30018252M,Niemcy--autostrada-.jpg" vspace="2" />Belgia nie zwiększy dozwolonego limitu prędkości na autostradach do 150 km/h. Instytut Bezpieczeństwa Drogowego Vias odrzucił spekulacje w tej sprawie. Pojawiły się one po informacjach, że taki właśnie limit chcą wprowadzić Czechy od przyszłego roku.

## Pościg samochodowy w Lublinie. Mężczyzna ruszył na policjantów z maczetą. W aucie były narkotyki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100208,poscig-samochodowy-w-lublinie-mezczyzna-ruszyl-na-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100208,poscig-samochodowy-w-lublinie-mezczyzna-ruszyl-na-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T10:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d0/b4/1c/z30100432M,Mezczyzna-zatrzymany-po-poscigu.jpg" vspace="2" />Kierowca renault megane, jadący w niedzielę rano ulicami Lublina, zignorował sygnał policji do zatrzymania się i zaczął uciekać. W miejscowości Kalinówka pod Lublinem auto uciekiniera zakopało się w ziemi, a kierowca ruszył na policjantów z maczetą. Padł strzał ostrzegawczy. W samochodzie i przy zatrzymanym mężczyźnie funkcjonariusze znaleźli narkotyki.

## Kiedy skończą się upały? Synoptycy IMGW zapowiadają zbliżające się ochłodzenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099805,kiedy-skoncza-sie-upaly-synoptycy-imgw-zapowiadaja-zblizajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099805,kiedy-skoncza-sie-upaly-synoptycy-imgw-zapowiadaja-zblizajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T09:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6f/b4/1c/z30100079M,Pogody-dlugoterminowe-wskazuja-na-spadek-temperatu.jpg" vspace="2" />Ubiegły tydzień był najgorętszym w 2023 r. Prognozy opublikowane przez synoptyków IMGW wskazują, że najbliższe dni przyniosą nieznaczne ochłodzenie, podczas którego temperatura nie powinna przekraczać 30 stopni Celsjusza. Wstępne przewidywania meteorologów zdają się potwierdzać, że od zbliżającego się weekendu czeka nas koniec intensywnych upałów.

## USA. Trzy osoby zmarły po wypiciu mlecznego koktajlu w sieciowym fast foodzie. Odkryto przyczynę zgonów
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099886,usa-trzy-osoby-zmarly-po-wypiciu-mlecznego-koktajlu-odkryto.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099886,usa-trzy-osoby-zmarly-po-wypiciu-mlecznego-koktajlu-odkryto.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T09:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/b4/1c/z30100346M,Koktajl-mleczny--zdjecie-ilustracyjne-.jpg" vspace="2" />Trzy osoby zmarły, a trzy inne trafiły do szpitala po zatruciu bakterią wykrytą w koktajlach mlecznych serwowanych przez restaurację typu fast food w amerykańskiej miejscowości Tacoma w stanie Waszyngton. W mlecznych napojach stwierdzono bakterię listeria monocytogenes, przez którą co roku w Stanach Zjednoczonych umiera nawet kilkaset osób.

## Karolina Korwin-Piotrowska odwołała udział w Campusie. "Mentalny dziadocen"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30100174,karolina-korwin-piotrowska-odwolala-udzial-w-campusie-mentalny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30100174,karolina-korwin-piotrowska-odwolala-udzial-w-campusie-mentalny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T09:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1a/b4/1c/z30100250M,Campus-Polska-Przyszlosci.jpg" vspace="2" />Karolina Korwin-Piotrowska jest kolejną osobą, która postanowiła odwołać swój udział w Campusie Polska Przyszłości. "Tegoroczny kontekst i zamieszanie nie jest dla mnie" - napisała w oświadczeniu.

## Znów dron w obwodzie moskiewskim. Wstrzymano ruch na lotniskach. Rosjanie krytykują Kreml
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099940,rosjanie-krytykuja-kreml-za-brak-obrony-przeciwlotniczej-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099940,rosjanie-krytykuja-kreml-za-brak-obrony-przeciwlotniczej-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T09:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/b4/1c/z30100228M,ISW--Rosjanie-krytykuja-Kreml-za-brak-obrony-przec.jpg" vspace="2" />Kolejnym atakom dronów w Rosji towarzyszy rosnące niezadowolenie wobec Kremla. Informuje o tym amerykański Instytut Studiów nad Wojną oraz niezależni ukraińscy i rosyjscy analitycy wojskowi. W poniedziałkowym ataku drona w obwodzie moskiewskim dwie osoby zostały ranne - informuje Reuters.

## Wypadek pod Mrągowem. Samochód uderzył w drzewo. Nie żyje dwóch 21-latków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100175,wypadek-samochodowy-pod-mragowem-nie-zyje-dwoch-21-latkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100175,wypadek-samochodowy-pod-mragowem-nie-zyje-dwoch-21-latkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T08:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/b4/1c/z30100221M,Tragiczny-wypadek-pod-Mragowem--Nie-zyje-dwoch-21-.jpg" vspace="2" />Pod Mrągowem (woj. warmińsko-mazurskie) dwóch młodych mężczyzn zginęło w wypadku samochodowym. Trzeci trafił do szpitala. Policjanci ustalają przyczny zdarzenia.

## Polonia niewpuszczona na cmentarz w Rosji. Na miejscu czekała proputinowska młodzieżówka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099882,polonia-niewpuszczona-na-cmentarz-w-rosji-na-miejscu-czekala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099882,polonia-niewpuszczona-na-cmentarz-w-rosji-na-miejscu-czekala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T08:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ba/b4/1c/z30099898M,Cmentarz-ofiar-NKWD-w-Lewaszowie.jpg" vspace="2" />Przedstawiciele Polonii i organizacji "Memoriał" nie zostali wpuszczeni na teren cmentarza ofiar represji stalinowskich w Lewaszowie pod Petersburgiem. Drogę zagrodzili również proputinowscy aktywiści.

## Gdzie jest burza? Synoptycy wydali ostrzeżenia pierwszego stopnia. Może zagrzmieć, pojawi się grad
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099574,gdzie-jest-burza-synoptycy-wydali-ostrzezenia-pierwszego-stopnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099574,gdzie-jest-burza-synoptycy-wydali-ostrzezenia-pierwszego-stopnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T08:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/b4/1c/z30099804M,Kolejne-burze-pojawia-sie-na-poludniu-kraju.jpg" vspace="2" />Burze, intensywne opady deszczu i gradu będą się pojawiać od początku tygodnia na południu kraju. Synoptycy z Instytutu Meteorologii i Gospodarki Wodnej (IMGW) wydali ostrzeżenia pierwszego stopnia przed nagłymi zjawiskami atmosferycznymi. Gdzie teraz jest burza?

## Human Rights Watch: Arabia Saudyjska ostrzeliwuje migrantów z Etiopii. Zginęły setki ludzi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099564,human-rights-watch-arabia-saudyjska-ostrzeliwuje-migrantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099564,human-rights-watch-arabia-saudyjska-ostrzeliwuje-migrantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T08:04:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/b4/1c/z30099863M,Human-Rights-Watch--Arabia-Saudyjska-ostrzeliwuje-.jpg" vspace="2" />Setki migrantów z Etiopii miało zginąć podczas próby przedostania się do Arabii Saudyjskiej, po tym, jak tamtejsza Straż Graniczna otworzyła do nich ogień. Human Rights Watch opublikowała raport, z którego wynika, że do nieuzbrojonych Etiopczyków strzelano z karabinów maszynowych i moździerzy. Dane o zabitych dotyczą okresu od marca 2022 do czerwca 2023.

## Teneryfa płonie. Władze nie wykluczają podpalenia. I apelują, by chodzić w maseczkach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099561,teneryfa-plonie-wladze-nie-wykluczaja-podpalenia-i-apeluja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099561,teneryfa-plonie-wladze-nie-wykluczaja-podpalenia-i-apeluja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/b4/1c/z30099647M,Teneryfa-w-ogniu.jpg" vspace="2" />Służby od blisko tygodnia walczą z ogniem na Teneryfie, hiszpańskiej wyspie należącej do archipelagu Wysp Kanaryjskich. Wciąż dużym zagrożeniem dla mieszkańców i turystów jest znaczące pogorszenie się jakości powietrza, w którym znajduje się dym z palących się lasów. Policja nie wyklucza, że na wyspie miało miejsce celowe podpalenie.

## Poczesna. Operator koparki natknął się na ludzkie szczątki. Mieszkańcy mówią o zaginionym mężczyźnie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099462,poczesna-operator-koparki-natknal-sie-na-ludzkie-szczatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099462,poczesna-operator-koparki-natknal-sie-na-ludzkie-szczatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/b4/1c/z30099587M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Podczas prac ziemnych na terenie prywatnej posesji w miejscowości Poczesna (woj. śląskie), operator koparki odnalazł ludzkie szczątki. Prowadzący śledztwo policjanci zlecili badania DNA, których wyniki mogą być kluczowe w ustaleniu tożsamości ofiary. Mieszkańcy Poczesnej spekulują, że ciało może należeć do zaginionego dwa lata temu mężczyzny.

## Oligarcha z kręgów Kremla pojechał na safari do Kenii. Podróż zorganizowała krewna brytyjskiego króla
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099477,oligarcha-z-kregow-kremla-pojechal-na-safari-do-kenii-podroz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099477,oligarcha-z-kregow-kremla-pojechal-na-safari-do-kenii-podroz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/eb/b4/1c/z30099691M,Oleg-Deripaska.jpg" vspace="2" />Alexandra Bowes-Lyon, córka dalekiego kuzyna króla Karola III, była zaangażowana w organizację wycieczki do Afryki rosyjskiego oligarchy Olega Deripaski. Safari, w którym brał udział powiązany z Kremlem przedsiębiorca, zostało zorganizowane przez organizację charytatywną, z którą współpracuje Bowes-Lyon. W momencie wyjazdu Deripaska objęty był sankcjami nałożonymi na niego przez USA.

## Dębica. Pożar zakładu produkującego opony. Na miejscu 140 strażaków, ewakuowano ponad 200 osób
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099467,pozar-zakladu-produkujacego-opony-w-debicy-ponad-200-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099467,pozar-zakladu-produkujacego-opony-w-debicy-ponad-200-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/b4/1c/z30099542M,Pozar-w-zakladzie-produkujacym-opony-w-Debicy.jpg" vspace="2" />W Dębicy doszło do pożaru segmentu hali produkcyjnej firmy produkującej opony. Ewakuowano ponad 200 pracowników. "W kulminacyjnym momencie w akcję gaśniczą zaangażowanych było 35 zastępów, blisko 140 strażaków" - przekazali strażacy z Komendy Wojewódzkiej PSP w Rzeszowie.

## Liszna. Ciało 32-latka w zbiorniku retencyjnym. Świadek słyszał niepokojące głosy. Ruszyło śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099466,liszna-cialo-32-latka-w-zbiorniku-retencyjnym-swiadek-slyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099466,liszna-cialo-32-latka-w-zbiorniku-retencyjnym-swiadek-slyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/b4/1c/z30099512M,Liszna-na-Podkarpaciu--zdj--ilustracyjne-.jpg" vspace="2" />Ze zbiornika retencyjnego w miejscowości Liszna na Podkarpaciu strażacy- płetwonurkowie wydobyli w niedzielę ciało 32-latka. Służby zaalarmował świadek, który zobaczył pozostawione na brzegu rzeczy osobiste i usłyszał niepokojące głosy.

## Niespodzianka od Północy na początek manewrów Korei Południowej i USA. Kim Dzong Un zadowolony
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099677,test-pociskow-manewrujacych-podczas-wspolnych-cwiczen-usa-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099677,test-pociskow-manewrujacych-podczas-wspolnych-cwiczen-usa-i.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T07:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/b4/1c/z30099696M,Korea-Polnocna-przeprowadzila-test-pociskow-manewr.jpg" vspace="2" />Przywódca Korei Północnej Kim Dzong Un nadzorował test strategicznych pocisków manewrujących na pokładzie okrętu marynarki wojennej. Test przeprowadzono w czasie wspólnych ćwiczeń wojskowych Korei Południowej i USA.

## Baner kibiców uderzył w posłankę PO. "Jestem w dobrym towarzystwie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30099508,baner-kibicow-uderzyl-w-poslanke-po-jestem-w-dobrym-towarzystwie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30099508,baner-kibicow-uderzyl-w-poslanke-po-jestem-w-dobrym-towarzystwie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T06:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/b4/1c/z30099517M,Marta-Wcislo.jpg" vspace="2" />Kibice podczas meczu Górnika Łęczna i Motoru Lublin kibice zawiesili baner uderzający w Martę Wcisło. Posłanka PO uznała, że kibice zrobili jej darmową reklamę. - Kiedyś kibice grillowali Donalda Tuska, teraz mnie. Jestem w dobrym towarzystwie - skomentowała posłanka w rozmowie z Interią.

## Policyjny Black Hawk zerwał linię energetyczną. Ekspert: O włos od tragedii. Nie wolno latać nad publicznością
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099458,policyjny-black-hawk-zerwal-linie-energetyczna-w-sarnowej-gorze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099458,policyjny-black-hawk-zerwal-linie-energetyczna-w-sarnowej-gorze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T05:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/b4/1c/z30099515M,Mazowsze--Policyjny-Black-Hawk-zerwal-linie-energe.jpg" vspace="2" />- Ewidentnie nie była to profesjonalnie przygotowana impreza lotnicza - mówił o pikniku wojskowym w Sarnowej Górze koło Ciechanowa, w województwie mazowieckim publicysta lotniczy Michał Setlak. Na antenie TVN24 mówił o incydencie, do którego tam doszło - policyjny śmigłowiec Black Hawk doprowadził do zerwania linii energetycznej.

## Artur Balazs: Głosy Kołodziejczaka mogą być w wyborach decydujące [WYWIAD]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30095269,artur-balazs-glosy-kolodziejczaka-moga-byc-w-wyborach-decydujace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30095269,artur-balazs-glosy-kolodziejczaka-moga-byc-w-wyborach-decydujace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T05:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/03/eb/17/z25080835M,Artur-Balazs-podczas-otwarcia-wystawy--1989--Proba.jpg" vspace="2" />- Aby żaden głos po stronie opozycji nie był zmarnowany, to warto, by Michał Kołodziejczak znalazł takie miejsce na opozycji. By mógł z powodzeniem startować do Sejmu. Teraz ludzie dzwonią do mnie i mówią: genialny ruch Tuska! Pokazał, że jest prawdziwym liderem - mówi Artur Balazs, były minister kilku rządów, który pomógł AgroUnii i Platformie Obywatelskiej zawrzeć wyborczy sojusz.

## Ukraina dostała czołgi Leopard. Zamiast deklarowanych kilkuset - dużo mniej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099437,ukraina-dostala-czolgi-leopard-zamiast-deklarowanych-kilkuset.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099437,ukraina-dostala-czolgi-leopard-zamiast-deklarowanych-kilkuset.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T05:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dd/4b/1c/z29669085M,Szkolenia-ukrainskich-czolgistow--na-czolgach-Leop.jpg" vspace="2" />60 czołgów Leopard - tyle miało trafić do Ukrainy zamiast zadeklarowanych przez sojuszników kilkuset pojazdów. Informację podał brytyjski "The Economist", który powołuje się na źródła w Sztabie Generalnym Sił Zbrojnych Ukrainy. Wskazuje, że to jeden z powodów zmiany taktyki na froncie wojny w Ukrainie.

## Zamach stanu w Nigrze. Przywódca junty ostrzega przed interwencją: To nie będzie spacer po parku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099170,protesty-w-nigrze-w-tle-grozba-interwencji-zbrojnej-przywodca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30099170,protesty-w-nigrze-w-tle-grozba-interwencji-zbrojnej-przywodca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T04:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1f/b4/1c/z30099231M,Niger--Mlodzi-ludzie--ktorzy-zgromadzili-sie-wokol.jpg" vspace="2" />Tysiące osób popierających zamach stanu w Nigrze demonstrowały w niedzielę w Niamey. Podczas manifestacji wznoszono antyfrancuskie hasła oraz protestowano przeciwko sankcjom i ewentualnej interwencji zbrojnej ECOWAS. Dzień wcześniej przywódca junty Abdurrahman Tchiani ostrzegł, że zewnętrzna ingerencja militarna nie będzie "spacerem po parku".

## Horoskop dzienny - poniedziałek 21 ierpnia 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30098312,horoskop-dzienny-poniedzialek-21-ierpnia-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30098312,horoskop-dzienny-poniedzialek-21-ierpnia-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-08-21T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b3/85/1c/z29907379M,Horoskop-dzienny-na-poniedzialek.jpg" vspace="2" />Jaki poniedziałek czeka osoby urodzone pod znakiem Bliźniąt, Wagi i Ryb? Sprawdź horoskop dla wszystkich znaków na 21 ierpnia 2023 roku.

