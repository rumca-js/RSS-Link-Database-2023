# Source:Just Some Guy, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q, language:en-US

## Blue Beetle: Another DCEU Failure
 - [https://www.youtube.com/watch?v=cHBdj2VhTiI](https://www.youtube.com/watch?v=cHBdj2VhTiI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC337i8LcUSM4UMbLf820I8Q
 - date published: 2023-08-21T23:00:15+00:00

Blue Beetle: Another DCEU Failure
----------------------------------------------------------------------------------------------
Art and Animation by Just Some Guy

Original trailer concept: FMA Brotherhood & Black Summoner

Music: "Enkon Hakuchuumu" by Sakagami Souichi - Copyright (C) 2015 Trial & Error/Sakagami Souichi All rights reserved.

Trial & Error: http://www.tandess.com/en/music/

