# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Killer Mike on making 'Michael' #killermike #runthejewels
 - [https://www.youtube.com/watch?v=DZ7Ds7DBFWM](https://www.youtube.com/watch?v=DZ7Ds7DBFWM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-08-21T15:48:03+00:00

Rapper Killer Mike of Run the Jewels discusses making his latest solo album, 'Michael.'

Credits
Guest –  @KillerMikeGTO  
Host – Jill Riley
Producer – Derrick Stevens
Video Director – Erik Stromstad
Camera Operator – Micah Kopecky
Audio – Cameron Wiley, Josh Sauvageau
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://twitter.com/TheCurrent  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#shorts

