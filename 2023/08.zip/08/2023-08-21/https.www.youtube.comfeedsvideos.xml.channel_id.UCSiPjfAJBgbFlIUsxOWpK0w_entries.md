# Source:Pomplamoose, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w, language:en-US

## HOW IS ELIANA SO GOOD AT BASS.
 - [https://www.youtube.com/watch?v=tg5ylWwsxP8](https://www.youtube.com/watch?v=tg5ylWwsxP8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSiPjfAJBgbFlIUsxOWpK0w
 - date published: 2023-08-21T15:53:40+00:00



