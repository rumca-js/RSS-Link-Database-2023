# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Atlanta Officials Unveil Onerous Verification Requirements for Cop City Referendum
 - [https://theintercept.com/2023/08/21/atlanta-cop-city-referendum-signatures/](https://theintercept.com/2023/08/21/atlanta-cop-city-referendum-signatures/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-08-21T22:42:33+00:00

<p>The city outlined its plans for signature verification after organizers collected 100,000 signatures for a vote on the police training facility.</p>
<p>The post <a href="https://theintercept.com/2023/08/21/atlanta-cop-city-referendum-signatures/" rel="nofollow">Atlanta Officials Unveil Onerous Verification Requirements for Cop City Referendum</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Imran Khan Booked Under Pakistan State Secrets Law for Allegedly Mishandling Secret Cable in 2022
 - [https://theintercept.com/2023/08/21/imran-khan-cable-pakistan-official-secrets-act/](https://theintercept.com/2023/08/21/imran-khan-cable-pakistan-official-secrets-act/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-08-21T22:29:52+00:00

<p>A fight over recent amendments to the state secret law sent Pakistan into a constitutional crisis.</p>
<p>The post <a href="https://theintercept.com/2023/08/21/imran-khan-cable-pakistan-official-secrets-act/" rel="nofollow">Imran Khan Booked Under Pakistan State Secrets Law for Allegedly Mishandling Secret Cable in 2022</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Hacked Records Corroborate Claims in Hydroxychloroquine Wrongful Death Suit
 - [https://theintercept.com/2023/08/21/americas-frontline-doctors-hydroxychloroquine-wrongful-death/](https://theintercept.com/2023/08/21/americas-frontline-doctors-hydroxychloroquine-wrongful-death/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-08-21T10:00:00+00:00

<p>Jeremy Parker died soon after taking the drug, which was prescribed to him by a physician with the anti-vaccine group America’s Frontline Doctors.</p>
<p>The post <a href="https://theintercept.com/2023/08/21/americas-frontline-doctors-hydroxychloroquine-wrongful-death/" rel="nofollow">Hacked Records Corroborate Claims in Hydroxychloroquine Wrongful Death Suit</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

