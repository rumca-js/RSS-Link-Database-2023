# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Nowa ksiażka sekuraka – Wprowadzenie do bezpieczeństwa IT – już dostępna w przedsprzedaży.
 - [https://sekurak.pl/nowa-ksiazka-sekuraka-wprowadzenie-do-bezpieczenstwa-it-juz-dostepna-w-przedsprzedazy/](https://sekurak.pl/nowa-ksiazka-sekuraka-wprowadzenie-do-bezpieczenstwa-it-juz-dostepna-w-przedsprzedazy/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-08-21T06:51:57+00:00

<p>Więcej informacji o książce (w tym dostępne do zakupu pakiety) znajdziecie tutaj: https://ksiazka.sekurak.pl/. Całość to wspólne dzieło 18 autorów-praktyków, znanych w środowisku bezpieczeństwa IT w Polsce. Bonus: do trzech osób, które napiszą do nas na ca@securitum.pl &#8211; wysyłamy (do Polski) po jednym egzemplarzu książki z podpisami (kilku) autorów :-). Kogo...</p>
<p>Artykuł <a href="https://sekurak.pl/nowa-ksiazka-sekuraka-wprowadzenie-do-bezpieczenstwa-it-juz-dostepna-w-przedsprzedazy/" rel="nofollow">Nowa ksiażka sekuraka &#8211; Wprowadzenie do bezpieczeństwa IT &#8211; już dostępna w przedsprzedaży.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

