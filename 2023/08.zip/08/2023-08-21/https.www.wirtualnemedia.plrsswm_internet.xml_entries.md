# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Serwis młodzieżowy TVP nadal ze znikomą odwiedzalnością. Matyszkowicz: nauczyliśmy się tworzyć nowe formy
 - [https://www.wirtualnemedia.pl/artykul/serwis-mlodziezowy-tvp-swipeto-wyniki-mateusz-matyszkowicz-komentuje](https://www.wirtualnemedia.pl/artykul/serwis-mlodziezowy-tvp-swipeto-wyniki-mateusz-matyszkowicz-komentuje)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-21T04:52:25.561528+00:00

Telewizja Polska nie traktuje znikomej odwiedzalności serwisu dla młodzieży Właściciel SwipeTO jako porażki. - To unikalna próba kontaktu z młodszym odbiorcą, mogliśmy rozpoznać jego sposób działania i nauczyć się tworzenia nowych form – mówi portalowi Wirtualnemedia.pl prezes TVP Mateusz Matyszkowicz. Czy nadawca będzie utrzymywał i rozwijał portal? – Jego funkcjonalności na pewno – zapewnia Matyszkowicz.

## Janusz Schwertner odszedł z Onetu, będzie naczelnym Goniec.pl
 - [https://www.wirtualnemedia.pl/artykul/janusz-schwertner-onet-odszedl-redaktor-naczelny-goniec-pl](https://www.wirtualnemedia.pl/artykul/janusz-schwertner-onet-odszedl-redaktor-naczelny-goniec-pl)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-21T04:52:25.559097+00:00

Po odejściu z Onetu Janusz Schwertner dołączy do zespołu Iberionu, będzie dyrektorem programowym firmy i redaktorem naczelnym jej największego serwisu Goniec.pl - dowiedział się portal Wirtualnemedia.pl. Iberion w najbliższym czasie przeprowadzi rebranding.

## Zdjęcia w jakości HD na WhatsApp
 - [https://www.wirtualnemedia.pl/artykul/zdjecia-w-jakosci-hd-whatsapp](https://www.wirtualnemedia.pl/artykul/zdjecia-w-jakosci-hd-whatsapp)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-21T03:47:04.814489+00:00

Komunikator WhatsApp dodał funkcję wysyłania zdjęć w jakości HD. Użytkownicy będą sami mogli zdecydować, w jakiej jakości przesłać otrzymane obrazy.

## Elon Musk wyłączy funkcję „czarnej listy” w X
 - [https://www.wirtualnemedia.pl/artykul/elon-musk-czarna-lista-x-twitter](https://www.wirtualnemedia.pl/artykul/elon-musk-czarna-lista-x-twitter)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-21T03:47:04.809905+00:00

Elon Musk obiecał usunąć z X (dawniej Twittera) możliwość dodawania użytkowników do „czarnej listy”. Właściciel portalu społecznościowego zapowiedział nadchodzące zmiany, odpowiadając na pytanie jednego z czytelników.

## BrandLift bez ponad połowy zysku, wpływy jedną czwartą w górę
 - [https://www.wirtualnemedia.pl/artykul/brandlift-agencja-influencer-marketing-ile-zarabia-karina-hertel](https://www.wirtualnemedia.pl/artykul/brandlift-agencja-influencer-marketing-ile-zarabia-karina-hertel)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-08-21T03:47:04.807123+00:00

Agencja influencer marketingu BrandLift w ub.r. zwiększyła przychody o 24 proc. do 10,91 mln zł, natomiast przy dużo wyższym wzroście kosztów jej zysk netto zmalał z 2,41 do 1,1 mln zł.

