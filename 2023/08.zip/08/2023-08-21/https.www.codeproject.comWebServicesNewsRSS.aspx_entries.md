# Source:CodeProject, URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, language:en-US

## 40% of workers will have to reskill in the next three years due to AI, says IBM study
 - [https://www.zdnet.com/article/40-of-workers-will-have-to-reskill-in-the-next-three-years-due-to-ai-says-ibm-study/](https://www.zdnet.com/article/40-of-workers-will-have-to-reskill-in-the-next-three-years-due-to-ai-says-ibm-study/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

"Change or stagnate. Keep moving or die."

## AI threatens the billable hour revenue model
 - [https://www.axios.com/2023/08/17/ai-threatens-hourly-revenue-model](https://www.axios.com/2023/08/17/ai-threatens-hourly-revenue-model)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

"If you've got the money honey I've got the time" (but not for longer)

## Bored Ape Yacht Club NFT owners sue Sotheby's, celebs, and parent company as prices plummet
 - [https://www.techspot.com/news/99834-bored-ape-yacht-club-nft-owners-sue-sotheby.html](https://www.techspot.com/news/99834-bored-ape-yacht-club-nft-owners-sue-sotheby.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

A fool and his money are soon laughed at (minus his money)

## D.Analysis
 - [https://www.codeproject.com/Messages/5957855/D-Analysis](https://www.codeproject.com/Messages/5957855/D-Analysis)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

Have data, will analyze

## Google paves way for FIDO2 security keys that can resist quantum computer attacks
 - [https://www.zdnet.com/article/google-paves-way-for-fido2-security-keys-that-can-resist-quantum-computer-attacks/](https://www.zdnet.com/article/google-paves-way-for-fido2-security-keys-that-can-resist-quantum-computer-attacks/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

It's safe from all the quantum computers that aren't out there

## Is it just me, or are...
 - [https://www.codeproject.com/Messages/5957874/Is-it-just-me-or-are](https://www.codeproject.com/Messages/5957874/Is-it-just-me-or-are)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

The computer you want is always $5000

## Russia’s first lunar mission in decades crashes into the moon
 - [https://www.cnn.com/2023/08/20/world/luna-25-spacecraft-moon-collision-intl/index.html](https://www.cnn.com/2023/08/20/world/luna-25-spacecraft-moon-collision-intl/index.html)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

But, it landed!

## SanDisk Extreme SSDs are “worthless,” multiple lawsuits against WD say
 - [https://arstechnica.com/gadgets/2023/08/sandisk-extreme-ssds-are-worthless-multiple-lawsuits-against-wd-say/](https://arstechnica.com/gadgets/2023/08/sandisk-extreme-ssds-are-worthless-multiple-lawsuits-against-wd-say/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

Well, that's pretty extreme, isn't it?

## What DARPA wants, DARPA gets: A non-hacky way to fix bugs in legacy binaries
 - [https://www.theregister.com/2023/08/18/darpa_legacy_binary_patching/](https://www.theregister.com/2023/08/18/darpa_legacy_binary_patching/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-08-21T04:00:00+00:00

Who needs source?

