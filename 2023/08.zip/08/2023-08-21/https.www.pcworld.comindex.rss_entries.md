# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Google axes Chromebooks with discrete Nvidia GPUs
 - [https://www.pcworld.com/article/2037042/google-axes-chromebooks-with-discrete-nvidia-gpus.html](https://www.pcworld.com/article/2037042/google-axes-chromebooks-with-discrete-nvidia-gpus.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T14:51:49+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Who wants to play full-power PC games on a Chromebook? At least a few people, presumably, since Google and its manufacturing partners have made &ldquo;<a href="https://www.pcworld.com/article/1348040/google-unveils-a-wave-of-cloud-gaming-chromebooks.html" rel="noreferrer noopener" target="_blank">gaming Chromebooks</a>&rdquo; for a year or so. But with some screen upgrades and RGB keyboards, these machines are very clearly intended to be used with cloud services like GeForce Now, Xbox Game Pass, and Google&rsquo;s own ill-fated Stadia. It looks like more conventional gaming laptops, complete with dedicated graphics cards, were in the pipeline. Unfortunately, they&rsquo;ve now been unceremoniously axed in the early development process. </p>



<p>The news comes via developer commentary on <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://chromium-review.googlesource.com/c/chromiumos/platform/ec/+/4727767&amp;xcust=2-2-2037042-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Google&rsquo;s public Chromium Gerrit</a>. &ldquo;Clean house on some dead [mother]boards,&rdquo; writes the developer. &ldquo;Herobrine, Hades, and Agah are all canceled.&rdquo; As <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.aboutchromebooks.com/news/chromebooks-with-nvidia-gpus-get-the-chopping-block-too/?expand_article=1&amp;xcust=2-2-2037042-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">About Chromebooks reports</a> (via <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://arstechnica.com/gadgets/2023/08/gaming-chromebooks-with-nvidia-gpus-apparently-killed-with-little-fanfare/&amp;xcust=2-2-2037042-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Ars Technica</a>), these codenames corresponded to motherboard designs destined for future ChromeOS-powered laptops or tablets, a frequent method for eagle-eyed Google fans to get a peek at upcoming hardware specifications. These three particular motherboards had discrete Nvidia laptop GPUs powering their graphics. </p>



<p>Google has been working on <a href="https://www.pcworld.com/article/625264/heres-how-to-play-steam-games-on-a-chromebook.html" rel="noreferrer noopener" target="_blank">getting a version of Steam running in Chrome OS</a> for a while. The system is still in beta now, available to test out, but there&rsquo;s a reason that it hasn&rsquo;t graduated to the stable channel after nearly a year. Getting the complex Linux version of the software to play nice on typically low-powered Chromebooks is a bit of a headache, with the official documentation still listing issues with window placement, external monitors, UI scaling, audio and online chat, and Valve&rsquo;s ubiquitous Easy Anti-Cheat system. <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.chromium.org/chromium-os/steam-on-chromeos/&amp;xcust=2-2-2037042-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Only twenty models get the official blessing</a> and external storage still isn&rsquo;t supported, a big problem when PC game installation sizes are exploding and Chromebooks might have as little as 64 gigabytes of onboard storage. </p>



<p>And, of course, the big hurdle is that lack of discrete graphics card support, which means games played locally must be limited to older titles or new games with extremely basic visuals. The abandonment of these in-development laptop motherboards doesn&rsquo;t automatically mean that Google&rsquo;s not interested in more Chromebook gaming in the future &mdash; AMD and Intel both make discrete graphics for mobile, after all. But if you&rsquo;re hoping to fire up <em>Baldur&rsquo;s Gate III</em> on your Chromebook anytime soon, you&rsquo;ll have to do it via the cloud. </p>

Chromebooks</div>

## Save 37% on this MSI wireless gaming mouse and charging dock
 - [https://www.pcworld.com/article/2037131/2037131.html](https://www.pcworld.com/article/2037131/2037131.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T14:41:27+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If you&rsquo;re looking to upgrade your gaming space with a new wireless mouse and charging dock, you&rsquo;ve come to the right place. Amazon&rsquo;s currently selling the <a href="http://buy.geni.us/Proxy.ashx?TSID=14154&amp;GR_URL=https://www.amazon.com/dp/B094N6J1WP?ascsubtag=2-2-2037131-1-0-0" rel="nofollow">MSI Clutch GM41 wireless gaming mouse and charging dock for just $59.74</a>, which is 37 percent off of the original $94.99 price. This peripheral features a 20,000 DPI, 80 hours of battery life, and six programmable buttons. You&rsquo;re also getting a charging dock as well, making it a great value buy.</p>



<p>The MSI Clutch GM41 weighs just 74 grams, which is considered lightweight for a gaming mouse. The 20,000 DPI is on the higher side, especially if you&rsquo;re not accustomed to it. That said, high DPI mice are perfect for intensive FPS titles in which every second counts. Amazon buyers claim it&rsquo;s comfortable to use for long periods of time and the color effects are a lot of fun. I&rsquo;d recommend jumping on this deal sooner rather than later, though. I suspect it won&rsquo;t last very long.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="http://buy.geni.us/Proxy.ashx?TSID=14154&amp;GR_URL=https://www.amazon.com/dp/B094N6J1WP?ascsubtag=2-2-2037131-7-0-0" rel="nofollow" target="_blank">Get the MSI Clutch GM41 wireless gaming mouse and charging dock for $59.74 at Amazon</a></p>
Mice</div>

## O&O SafeErase 18 review: Utterly delete your data
 - [https://www.pcworld.com/article/2030966/oo-safe-erase-18-in-the-test-deleting-data-under-windows-irretrievably.html](https://www.pcworld.com/article/2030966/oo-safe-erase-18-in-the-test-deleting-data-under-windows-irretrievably.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Simple operation via function tiles</li><li>Secure deletion of files, folders, and storage drives</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Very slow on a fast test system</li><li>Deletion of internet data in Chrome, Firefox, and Opera not possible</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">Safe Erase 18 deletes data reliably, but the developer needs to improve upon the deletion of browser files. </p>
</div><h3 class="review-price" id="price-when-reviewed">Price When Reviewed</h3><p>19,90 Euro</p>


<p>According to O&amp;O, the new version of the tried-and-tested software <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.oo-software.com/en/safeerase-hard-drive-data-secure-deletion&amp;xcust=2-1-2030966-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">O&amp;O Safe Erase 18</a> has been optimized under the hood. Really? It takes a sluggish 45 seconds to start on one of our ultra-fast test systems. Otherwise, it takes five to ten seconds.</p>



<p>The interface, with six large tiles, remains exactly the same as its predecessor &mdash; where are the changes and innovations? </p>



<p>O&amp;O mentions support for the latest browser versions, but here, too, it disappoints. The current Chrome version is not even recognized by SafeErase 18, while, Firefox is partially recognized but not supported. Opera isn&rsquo;t recognized or supported either. This leaves the outdated, insecure Internet Explorer 11 and Microsoft Edge as the only browsers that delete data well like you&rsquo;d expect. The browser support is absolutely questionable.</p>



<p><strong>At least the other things work</strong>. The annoying drag and drop bug of of SafeErase 17 when deleting files and folders is fixed now. Even in earlier versions of SafeErase, SSDs were given a special place: &ldquo;SolidErase&rdquo; works in a resource-saving way because only one write process is carried out on SSDs you&rsquo;re wiping. If you need more write passes of the SSD for more a much more secure wipe, other deletion methods can also be used.</p>



<p>The secure deletion option available via the right-click context menu of Windows Explorer works without any problems. (Well, apart from the agonizingly slow start on our computer.) Two gigabytes of data with hundreds of files were safely destroyed within two minutes on a current office PC.</p>



<p><strong>Alternative:</strong> The English-language freeware <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://eraser.heidi.ie/&amp;xcust=2-1-2030966-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">Eraser</a> offers configurable secure deletion options and is also available via the Windows Explorer context menu.</p>



<h2 class="wp-block-heading" id="conclusion">Conclusion</h2>



<p><a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.oo-software.com/en/safeerase-hard-drive-data-secure-deletion&amp;xcust=2-1-2030966-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow">O&amp;O Safe Erase</a> works reliably in its core. Why the tool starts so slowly on a fast Windows 11 system with M.2 SSD and 64GB RAM remains a mystery. We&rsquo;d also like to see more interface improvements and better handling of browser data deletion in the future.</p>



<p><em>This review was translated from German to English and originally appeared on pcwelt.de.</em></p>

Personal Software</div>

## Chrome will warn you about malware-infested extensions
 - [https://www.pcworld.com/article/2036992/chrome-will-warn-you-about-malware-infested-extensions.html](https://www.pcworld.com/article/2036992/chrome-will-warn-you-about-malware-infested-extensions.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T13:31:14+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Browsers are getting more capable and more complex, becoming little software ecosystems in their own right. And that&rsquo;s increasingly making them targets. Browser extensions, while incredibly popular for the tools and tweaks they add, are an easy vector to get spyware and other nasty stuff loaded onto your computer with minimal effort. Google&rsquo;s latest security measure in Chrome aims to make it easier to spot potentially malicious extensions. </p>



<p>According to the <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://developer.chrome.com/en/blog/extension-safety-hub/&amp;xcust=2-1-2036992-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">Chrome developer blog</a>, Chrome version 117 will introduce a trio of new checks whenever a new extension is installed. It&rsquo;ll check to see if the extension has been removed from the Chrome Web Store by its developer or if it was removed manually for violating Google&rsquo;s extension policies or being marked as malware. Users will also be able to manually review the extensions they&rsquo;ve already installed via an alert in the &ldquo;Privacy and Security&rdquo; settings menu. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="chrome settings check now button" class="wp-image-2037017" height="310" src="https://b2c-contenthub.com/wp-content/uploads/2023/08/chrome-settings-check-now-button.jpg?quality=50&amp;strip=all" width="663" /></figure><p class="imageCredit">Google</p></div>



<p>The change won&rsquo;t affect the most common pain point for malicious extensions, those that are distributed and downloaded outside of Google&rsquo;s sanitized Chrome Web Store system. Such tools aren&rsquo;t always malware, but it&rsquo;s a frequent source of it, with Chrome extensions either mirroring legitimate ones with added payloads or designed to facilitate some kind of illicit activity. And finding an extension n the Chrome Web Store is no guarantee of its cleanliness, either &mdash; <a href="https://www.pcworld.com/article/443467/spammers-buy-chrome-extensions-and-turn-them-into-adware.html" rel="noreferrer noopener" target="_blank">extensions have been found loading up adware there</a>, usually when the original developer sells the tool to a new owner. </p>



<p>Even so, the extra measures will be appreciated for anyone who wants an extra layer of browser (or in the case of Chromebooks, operating system) security. The new tools will debut for most users in the next Chrome update, but <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.bleepingcomputer.com/news/google/google-chrome-to-warn-when-installed-extensions-are-malware/&amp;xcust=2-1-2036992-1-0-0&amp;sref=https://www.pcworld.com/feed" rel="nofollow" target="_blank">as Bleeping Computer notes</a>,, you can try them out in version 116 with some tweaks in the chrome://flags interface. </p>

Security Software and Services</div>

## Is an 80 Plus Platinum-rated power supply overkill?
 - [https://www.pcworld.com/article/2030959/is-a-platinum-power-supply-overkill.html](https://www.pcworld.com/article/2030959/is-a-platinum-power-supply-overkill.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T13:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>The 80 Plus rating is a voluntary certification for power supplies that indicates their efficiency and quality. A power supply with a good 80 Plus rating uses high-quality components and is usually quite reliable. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="Platinum-Netzwerk" class="wp-image-1981136" height="533" src="https://b2c-contenthub.com/wp-content/uploads/2023/07/pcw08_PSU-Komponenten.jpg?quality=50&amp;strip=all" width="800" /><figcaption class="wp-element-caption"><p>Thanks in part to their premium components, more efficiently classified power supplies operate more economically. Platinum models in particular rely on especially high-quality components here.</p>
</figcaption></figure><p class="imageCredit">IDG</p></div>



<p>An 80 Plus Gold power supply is 87 percent efficient at 100 per cent load, while an 80 Plus Platinum model is 89 percent efficient at 100 per cent load. This means that a 700-watt 80 Plus Gold power supply will draw 791 watts of power from the wall socket to deliver 700 watts to PC components. An 80 Platinum power supply, on the other hand, only needs 777 watts. In the long run, this can make a small difference in the electricity bill. In addition, Platinum-certified power supplies usually offer longer warranty periods than Gold-certified power supplies. </p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-full"><img alt="80-Plus-Netzteile" class="wp-image-1981141" height="906" src="https://b2c-contenthub.com/wp-content/uploads/2023/07/pcw08_80-Plus.jpg?quality=50&amp;strip=all" width="1024" /><figcaption class="wp-element-caption"><p>For 80-plus power supplies, you can choose between Gold and Platinum. The higher the quality of the precious metal used, the more efficiently the power supply works.</p>
</figcaption></figure><p class="imageCredit">Corsair</p></div>



<p>Is an 80 Plus Platinum power supply overkill? Basically, it always pays to invest in a good power supply. If you can afford an 80 Plus Platinum power supply and it comes from a renowned manufacturer, it is a worthwhile investment. An 80-Plus Gold power supply is also fine if it comes from brand-name manufacturers such as Be Quiet, Corsair, Seasonic or Asus.</p>


<p class="cta wp-block wp-block-button"><a class="cta__btn" href="http://buy.geni.us/Proxy.ashx?TSID=14154&amp;GR_URL=https://www.amazon.com/s?k=80+plus+gold+power+supply&amp;ascsubtag=2-1-2030959-7-0-0" rel="nofollow" target="_blank">Shop 80 Plus gold power supplies on Amazon</a></p>

<p class="cta wp-block wp-block-button"><a class="cta__btn" href="http://buy.geni.us/Proxy.ashx?TSID=14154&amp;GR_URL=https://www.amazon.com/s?k=80+plus+platinum+power+supply&amp;ascsubtag=2-1-2030959-7-0-0" rel="nofollow" target="_blank">Shop 80 plus platinum power supplies on amazon</a></p>


<p><em>This article was translated from German to English and originally appeared on pcwelt.de.</em></p>

Computer Components</div>

## Samsung Galaxy Book3 review: Too expensive for an everyday laptop
 - [https://www.pcworld.com/article/2030757/samsung-galaxy-book-3-review.html](https://www.pcworld.com/article/2030757/samsung-galaxy-book-3-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Thin and light for 15 inches</li><li>Good battery life</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Weak performance</li><li>Pale display</li><li>Rather plasticky</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">As far as specifications and quality go, this is the weakest of the Samsung computers I&rsquo;ve tested this year. However, it&rsquo;s not an outright failure, as it&rsquo;s pretty lightweight for a 15-inch laptop.</p>
</div>


<p>Samsung has had great success with its Galaxy Book computers in recent years. Several of them have received top marks in my tests and I run the lively, luxurious and above all wonderfully light OLED 13-inch <a href="https://www.pcworld.com/article/693933/samsung-galaxy-book2-pro-360-review-a-thin-light-powerful-beauty.html">Galaxy Book 2 Pro from 2022</a> as my own laptop.</p>



<p>The Galaxy Book3, released in late winter, doesn&rsquo;t have much in common with it, apart from the manufacturer and the name. This is a significantly simpler built computer that, despite a similar price, does not live up to my high expectations at all. It is indeed relatively thin and light, at least for a 15-inch computer, weighing only 3.46 pounds.</p>



<p>But where you usually see luxurious light metal chassis in Samsung&rsquo;s laptops, the Galaxy Book3 is a mix of aluminium and plastic. And it feels plasticky in the &ldquo;wrong&rdquo; places, like in the suspension and hinges for the screen, as well as in the unusually dumb keyboard.</p>



<p>Otherwise, the keyboard is neat and tidy, with a compact numeric keypad on the side, and an on button with a built-in fingerprint reader in one corner, where it&rsquo;s not likely to be accessed accidentally. On the narrow sides are what I&rsquo;d call a standard set of external connections, two type c and two type a USBs, an HDMI port and a 3.5 mm common headphone and microphone port.</p>



<blockquote class="wp-block-quote">
<p>Looking for more options? Check out PCWorld&rsquo;s roundup of the <a href="https://www.pcworld.com/article/436674/the-best-pc-laptops-of-the-year.html">best laptops</a> available today.</p>
</blockquote>



<h2 class="wp-block-heading" id="samsung-galaxy-book3-specifications">Samsung Galaxy Book3: Specifications</h2>



<p>There&rsquo;s no Thunderbolt 4 functionality on the Type-C ports like some other new laptops, but you get the main features, support for charging, USB docking and display port. A compact mobile phone charger is included. Here&rsquo;s the list of specs at a glance:</p>



<p><strong>Processor</strong>: Intel Core i5-1355U, 2pcs Performance up to 4,6 GHz + 8pcs Efficient up to 3,4 GHz<br /><strong>Graphics</strong>: Intel Iris Xe<br /><strong>Memory</strong>: 16 GB ddr4<br /><strong>Storage</strong>: 512 GB ssd, slot for micro sd card<br /><strong>Display</strong>: 15.6&Prime; matte IPS, 1920&times;1080 pixels<br /><strong>Webcam</strong>: 720p<br /><strong>Connections</strong>: 2 pcs usb 3 gen 1 type c with displayport, 2 pcs usb 3 gen 1 type a, hdmi, headset<br /><strong>Wireless</strong>: Wifi 6, bluetooth 5.1<br /><strong>Operating system</strong>: Windows 11 Home<br /><strong>Other</strong>: Fingerprint reader, backlit keyboard, numeric keypad<br /><strong>Noise level</strong>: 0-39 dBa<br /><strong>Battery life</strong>: 1 hr 50 min (high load), 17 hr 30 min (low load)<br /><strong>Size</strong>: 35.7 x 22.9 x 1.54 cm<br /><strong>Weight</strong>: 1.57 kg<br /><strong>Price</strong>: $999.99</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 st&auml;ngd" class="wp-image-2017714" height="761" src="https://b2c-contenthub.com/wp-content/uploads/2023/08/P_20230802_150630.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption class="wp-element-caption">Samsung always gets the nod for its sleek laptop design, and the Galaxy Book3 looks great too.</figcaption></figure><p class="imageCredit">Mattias Inghe</p></div>



<p>The computer is equipped with a 13th generation Intel processor. But it&rsquo;s one of the weaker ones, a Core i5-1355U, built for cooler and more power-efficient operation than for sustained high performance. It&rsquo;s great for browsing and running Office, but challenging it with high-resolution photo editing or video editing will be a challenge, and it can be a bit of a drag. Although it is possible. But with only two so-called performance cores to handle the most demanding processes, it&rsquo;s not ideal.</p>



<p>The processor, with a moderate 15 watts of base power, does a good job of keeping power consumption down when it&rsquo;s not maxed out. A full working day of browsing, Excel work, emailing, and occasional video streams is enough for the battery without much trouble. And packing the small charger for emergencies is easy.</p>



<h2 class="wp-block-heading" id="samsung-galaxy-book3-display-audio">Samsung Galaxy Book3: Display, audio</h2>



<p>A contributing factor to good battery life is an energy-efficient screen. It can light up to about 300 cd/m2, which isn&rsquo;t quite enough for daylight outdoors, but is more than enough for indoors. And if you turn down the brightness a bit, it doesn&rsquo;t strain the battery more than marginally. But then again, it&rsquo;s a pretty simple monitor. 1080p resolution, 60 Hz frame rate, and no great color space to speak of. It can handle just over 60 percent of the srgb color scale, so other than web and office graphics, the experience is limited.</p>



<p>Black surfaces are not as deeply black as some better IPS and PLS panels can manage, and there is some white point shifting at different viewing angles. However, if you don&rsquo;t have high demands on colour and dynamics, this is a pleasant, flicker-free screen you can spend many hours in front of.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 sk&auml;rm" class="wp-image-2017711" height="742" src="https://b2c-contenthub.com/wp-content/uploads/2023/08/P_20230802_150436.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption class="wp-element-caption">The screen is not a fun experience. Pale colours and mediocre viewing angles.</figcaption></figure><p class="imageCredit">Mattias Inghe</p></div>



<p>The sound is also acceptable, but not in the higher divisions. It is pleasant, provides good stereo and good balance between bass, midrange and treble. But without much pressure in either. It drops out small details in music I play, and effects and rumbles in film trailers are reproduced correctly, but without any real weight. You can get audio enhancement with Dolby Audio, but it&rsquo;s off by default. Turning it on provides some equaliser control, but the hardware is the limit.</p>



<h2 class="wp-block-heading" id="samsung-galaxy-book3-galaxy-ecosystem">Samsung Galaxy Book3: Galaxy ecosystem</h2>



<p>Samsung is keen to make the Galaxy Book computers part of its ecosystem of Galaxy mobiles, tablets and accessories. So there&rsquo;s a bunch of apps and features that enable this. You can quickly share media with other Galaxy devices, expand the screen of a Galaxy tablet, and control different devices from each other.</p>



<p>It&rsquo;s smart and convenient if you have the right gadgets around. I tested several of the features with a Galaxy Z Fold 5 I have in for testing, and they work as promised. I still haven&rsquo;t figured out how to use them, but perhaps my lack of imagination is the limit.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Samsung Galaxy Book3 tangentbord" class="wp-image-2017712" height="675" src="https://b2c-contenthub.com/wp-content/uploads/2023/08/P_20230802_150547.jpg?quality=50&amp;strip=all&amp;w=1200" width="1200" /><figcaption class="wp-element-caption">Number keys next to the regular keyboard.</figcaption></figure><p class="imageCredit">Mattias Inghe</p></div>



<p>Samsung also has its own suite of programs that are intended to add value to the computer, but I&rsquo;m more doubtful about what they actually add. Samsung Gallery is an image viewing program where Windows already has two good ones. Samsung Studio Plus allows you to edit video, but the value of that add-on has diminished as Clipchamp is now part of Windows. I can also do without the search function and Bixby support. In any case, there is no significant bloatware in the computer, except for the frequent 30-day McAfee Livesafe, and an Amazon link. </p>



<h2 class="wp-block-heading" id="samsung-galaxy-book3-performance">Samsung Galaxy Book3: Performance</h2>



<p><strong>Cinebench R23, CPU</strong>: 7,427 points<br /><strong>Cinebench</strong> <strong>R23, CPU and core</strong>: 1,661 points<br /><strong>Geekbench 6</strong>, CPU: 8,460 points<br /><strong>Geekbench 6, CPU and core</strong>: 2,223 points<br /><strong>Geekbench 6, GPU</strong>: 15,314 points<br /><strong>Disk read</strong>: 2,199.18 MB/s<br /><strong>Disk write</strong>: 1,194.66 MB/s</p>



		<div class="wp-block-product-widget-block product-widget">
			<div class="product-widget__block-title-wrapper">
				<h4 class="product-widget__block-title" id="the-pricier-book3-ultra-is-a-beautiful-beast-of-a-laptop">
					The pricier Book3 ultra is a beautiful beast of a laptop				</h4>
			</div>

			<div class="product-widget__content-wrapper">
									<div class="product-widget__title-wrapper">
						<h3 class="product-widget__title" id="samsung-galaxy-book3-ultra">Samsung Galaxy Book3 Ultra</h3>
					</div>
				
									<div class="product-widget__image-outer-wrapper">
						<div class="product-widget__image-wrapper">
							<img alt="Samsung Galaxy Book3 Ultra" class="product-widget__image" height="1039" src="https://b2c-contenthub.com/wp-content/uploads/2023/03/Samsung-Galaxy-Book3-Ultra-product.png" width="1674" />
						</div>
					</div>
				
				
				<div class="product-widget__information">
												<div class="product-widget__information--rrp-wrapper">
									<span class="product-widget__information--rrp-label">
																	</span>
									<span class="product-widget__information--rrp-value">
																		</span>
								</div>
								
											<div class="product-widget__pricing-details  ">
															<span class="product-widget__pricing-details--label">
									Best Prices Today:
								</span>
														<span class="product-widget__pricing-details--links-wrapper">
								<a class="product-widget__pricing-details--link" href="https://bestbuy.7tiv.net/c/321564/633495/10014?prodsku=6531072&amp;u=https%3A%2F%2Fapi.bestbuy.com%2Fclick%2F-%2F6531072%2Fpdp&amp;intsrc=CATF_4831&amp;subid1=2-1-2030757-5-1515863-11290" rel="nofollow" target="_blank">$2399.99 at  Best Buy</a>							</span>
						</div>
									</div>
			</div>
		</div>

		


<p><em>This review was translated from Swedish to English and originally appeared on pcforalla.se.</em></p>

Laptops</div>

## SheetGPT is ChatGPT for Google Sheets and it’s less than $50 now
 - [https://www.pcworld.com/article/2036449/sheetgpt-is-chatgpt-for-google-sheets-and-its-less-than-50-now.html](https://www.pcworld.com/article/2036449/sheetgpt-is-chatgpt-for-google-sheets-and-its-less-than-50-now.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-08-21T08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>By now you&rsquo;ve no doubt heard of ChatGPT. But what if you could apply its AI powers to other platforms, like Google Sheets? With SheetGPT, you can. SheetGPT is <a href="https://shop.pcworld.com/sales/sheetgpt-single-user-plan-lifetime-subscription?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=sheetgpt-single-user-plan-lifetime-subscription&amp;utm_term=scsf-577442&amp;utm_content=a0x1P000005OuGtQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">ChatGPT for Google Sheets</a>, allowing you to simplify how you work with data in Google Sheets.</p>



<p>With SheetGPT installed, all you have to do is call the function <em>=AI(&ldquo;Your Prompt Here&rdquo;)</em>&nbsp; and you&rsquo;ll get an answer to your prompt in a second. You can use the prompt to combine cells, input URLs into SheetGPT and get the full page content back, connect prompts between different cells, automate work, and much more. SheetGPT comes with a list of effective prompts to help you figure out how to best use it and works in all languages, just like ChatGPT.</p>



<p>SheetGPT has earned perfect 5-star rating on AppSumo and SourceForge for good reason. Find out why when you get a lifetime <a href="https://shop.pcworld.com/sales/sheetgpt-single-user-plan-lifetime-subscription?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=sheetgpt-single-user-plan-lifetime-subscription&amp;utm_term=scsf-577442&amp;utm_content=a0x1P000005OuGtQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">SheetGPT Single User Plan</a> for 83% off $299 at just $48.99.</p>



<p><a href="https://shop.pcworld.com/sales/sheetgpt-single-user-plan-lifetime-subscription?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=sheetgpt-single-user-plan-lifetime-subscription&amp;utm_term=scsf-577442&amp;utm_content=a0x1P000005OuGtQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">&nbsp;</a></p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image"><img alt="" src="https://cdnp2.stackassets.com/4591158349901a97d04ac3b625067f417a98d58e/store/182cb0515fce617d36f48c3d619b01dd9d3e91514d0577438b31385ebf12/sale_322919_primary_image.jpg" /></figure></div>



<p><strong>SheetGPT Single User Plan: Lifetime Subscription &ndash; $48.99</strong></p>



<p><a href="https://shop.pcworld.com/sales/sheetgpt-single-user-plan-lifetime-subscription?utm_source=pcworld.com&amp;utm_medium=referral-cta&amp;utm_campaign=sheetgpt-single-user-plan-lifetime-subscription&amp;utm_term=scsf-577442&amp;utm_content=a0x1P000005OuGtQAK&amp;scsonar=1" rel="noreferrer noopener" target="_blank">See Deal</a></p>



<p>Prices are subject to change.</p>

Laptop Accessories</div>

