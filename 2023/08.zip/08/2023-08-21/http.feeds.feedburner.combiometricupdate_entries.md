# Source:Biometric Update, URL:http://feeds.feedburner.com/biometricupdate, language:en-US

## Singapore considers an AML law for ‘victims’ of cybercrime
 - [https://www.biometricupdate.com/202308/singapore-considers-an-aml-law-for-victims-of-cybercrime](https://www.biometricupdate.com/202308/singapore-considers-an-aml-law-for-victims-of-cybercrime)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T20:22:55+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1036" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/04/12144641/digital-id-applications-scaled.jpg" width="2048" />
		It's human to feel for someone who reports their digital identity was stolen for financial crimes but sometimes the supposed victim was in on the scam.

Singapore is writing legislation that that would treat those people like cybercriminals the same as people organizing online fraud that misuses <a href="https://www.biometricupdate.com/202304/singpass-launches-digital-driver-licenses-for-professionals-integrated-by-okta">Singpass digital IDs</a>.

There already are at least two anti-money laundering (AML) laws on the books that address witting accomplices, but they require the government to prove the little fish in the police net knew what they were doing was wrong.

A person might agree to let someone use their bank account, turning a blind eye to the harms that ensue. The person <a href="https://www.police.gov.sg/Media-Room/News/20230816_seven_persons_to_be_charged_for_relinquishing_their_singpass_for_money_laundering" rel="noopener" target="_blank">might get a small sum</a> from the ringleaders as a reward.

Such cases are the flip side of the kind of cases most consumers hear about – the times when through software or social engineering, someone loses control of their biometric identifiers or other credentials.

A pair of proposed laws are being debated in Singapore to curb the 660.7 million Singaporean dollars (US$486.8 million) that the Singaporean Today news publisher <a href="https://www.todayonline.com/singapore/new-laws-proposed-target-money-mules-who-feign-ignorance-when-selling-singpass-bank-accounts-scammers-2152366" rel="noopener" target="_blank">says</a> was lost to cyber scams in 2022.

Some fraction of that total, apparently unknown, involves people who took actions that they knew might enrich them but would almost certainly financially harm others.

<a href="https://www.jdsupra.com/legalnews/the-sun-also-rises-anti-money-8552646/" rel="noopener" target="_blank">Analysis</a> of the AML bills by legal trade publication JD Supra, shows that they are intended to make it harder for someone to disingenuously contend they are a victim, too.

One of the new bills would hold responsible anyone who "rashly" agrees to get involved in a criminal enterprise, according to JD Supra. Singapore's penal code, says the publisher, defines rashly as when someone acts despite knowing there is a risk that they will be participating in a criminal act.

The other legislation holds people responsible for negligence. A reasonable person would know that they should take an action to stop an apparent crime but did not. In this case, the law would require individual to act more like a bank complying with KYC and AML regulations.

## UK Citizen’s Biometrics Council says ICO guidance is a step in the right direction
 - [https://www.biometricupdate.com/202308/uk-citizens-biometrics-council-says-ico-guidance-is-a-step-in-the-right-direction](https://www.biometricupdate.com/202308/uk-citizens-biometrics-council-says-ico-guidance-is-a-step-in-the-right-direction)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T19:48:52+00:00

<img alt="Ada Lovelace Institute to review governance of biometric data" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1125" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2020/01/27154734/Ada-Lovelace-Institute-to-review-governance-of-biometric-data.jpg" width="2000" />
		The Citizen’s Biometrics Council of the Ada Lovelace Institute says the UK Information Commissioner’s Office has made a good start in establishing guidance for the use of biometrics, but needs to work on enforcement, and may need legislative help.

The “<a href="https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/guidance-on-biometric-data/" rel="noopener" target="_blank">Listening to the Public</a>” report presents seven findings and five recommendations based on them for the ICO.

The council was asked for its views on the ICO’s proposal for <a href="https://ico.org.uk/for-organisations/uk-gdpr-guidance-and-resources/guidance-on-biometric-data/" rel="noopener" target="_blank">guidance and regulation of biometric data</a> use by Ada Lovelace, the ICO, and social research firm Hopkins Van Mil in late-2022. There are 30 people from diverse demographic groups and backgrounds who represented the council in presentations from the ICO and crafting feedback.

Overall, the council felt the ICO has made significant progress towards addressing the concerns and recommendations it <a href="https://www.biometricupdate.com/202103/its-all-about-trust-when-the-public-discusses-biometric-surveillance-uk-project-says" rel="noopener" target="_blank">shared in 2021</a> as a companion to the <a href="https://www.biometricupdate.com/202001/ada-lovelace-institute-to-review-governance-of-biometric-data">Ryder Review</a>.  Council members questioned how effective enforcement would be, and suggested new laws specific to biometrics may be needed. They also noted low public awareness of how biometrics are used, and the ICO’s role. Though consent is addressed in the ICO’s guidance, it remains an area of concern for some council members.

Some council members saw the potential for greater equity through biometrics, while others are concerned that poorly designed systems could have the opposite effect. More needs to be done to anticipate problems with future developments in biometrics, some say.

The considerations the council asks the ICO to take into account include moving beyond guidance to codes of conduct or legislation, advice which seems to clash with the recent decision to <a href="https://www.biometricupdate.com/202308/uk-biometrics-commissioner-resigns-in-anticipation-of-roles-elimination">eliminate the role</a> of the Surveillance Camera and Biometrics Commissioner. The council also advises the ICO to work on legislative and policy updates, public engagement and awareness, and accessibility and inclusion, and ethical and social concerns, such as those around transparency.

The ICO has also published a summary of its biometrics guidance <a href="https://ico.org.uk/media/about-the-ico/documents/4026198/biometrics-annex-20230818-2.pdf" rel="noopener" target="_blank">impact assessment</a>.

Comments on the proposed guidance will be accepted until October 20, 2023.

## From LinkedIn to government services, digital identity use set for expansion in Canada
 - [https://www.biometricupdate.com/202308/from-linkedin-to-government-services-digital-identity-use-set-for-expansion-in-canada](https://www.biometricupdate.com/202308/from-linkedin-to-government-services-digital-identity-use-set-for-expansion-in-canada)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T19:01:53+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1367" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/06/20141607/tablet-in-use-scaled.jpg" width="2048" />
		Digital identity is set to take on greater prominence in Canada, with a rollout on LinkedIn and a plan to bring numerous government services online for easier access.

<a href="https://www.biometricupdate.com/companies/clear">Clear</a> has been providing free biometric identity verification for LinkedIn users in the U.S. since earlier this year. Now, Canada has been chosen as the first country outside of America for the service to expand to. There are 22 million LinkedIn users in Canada, according to the announcement.

"When you verify your identity with Clear on LinkedIn, you're more likely to be considered for a job, have your in-mail opened, and build connections -- it's that simple," says Clear CEO Caryn Seidman Becker.

There are <a href="https://about.linkedin.com/">700 million LinkedIn</a> users outside of North America in around 200 countries, by LinkedIn’s own count.

The expansion also fits with Clear’s plans to <a href="https://www.biometricupdate.com/202304/health-gorilla-clear-join-forces-for-biometric-access-to-portable-medical-records">further diversify</a> applications of its service beyond the travel space.

Canada’s government also recently created a new cabinet position for minister of government services, and Tery Beech, first to hold the new role, says it will involve moving federal services from passports to payments online, reports the <a href="https://www.cbc.ca/news/politics/government-services-online-ai-1.6927199">CBC</a>.

Beech tells the CBC that the position was created to make government services “digital first,” though details are scant pending the issuance of a mandate letter.

The move was prompted in part by delays in passport issuance and renewals, which peaked with a backlog of 316,000 applications in 2022.

Economic efficiency is also a likely motivation. A white paper published earlier this year by ATB Ventures <a href="https://www.biometricupdate.com/202306/identifying-billions-white-paper-touts-economic-heft-of-digital-id">declared the time ripe for the adoption</a> of digital ID in both the public and private sectors, and cited DIACC’s estimate of a potential $15 billion Canadian (US$11.3 billion) annual gain in GDP.

The Department of Employment and Social Development (ESDC) will support Beech’s efforts, with Service Canada reporting to the new minister. The Canada Digital Service, which is responsible for developing government digital resources like apps, has been transferred from the Treasury Department to the ESDC.

## US studies possible accessibility hurdles for remote ID verification
 - [https://www.biometricupdate.com/202308/us-studies-possible-accessibility-hurdles-for-remote-id-verification](https://www.biometricupdate.com/202308/us-studies-possible-accessibility-hurdles-for-remote-id-verification)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T18:58:06+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1298" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/02/15111831/selfie-login-authentication-IDV-scaled.jpg" width="2048" />
		The U.S. Government Services Administration, which is responsible for the nation's <a href="https://www.biometricupdate.com/202306/us-pols-go-deeper-investigating-alleged-login-gov-fraud">problematic</a> single sign-in program, is studying how to make biometric identity verification systems work better for minority and marginalized populations.

Companies participating in the research include <a href="https://www.biometricupdate.com/companies/jumio">Jumio</a>, <a href="https://www.biometricupdate.com/companies/lexisnexis-risk-solutions">LexisNexis</a>, <a href="https://www.biometricupdate.com/companies/socure">Socure</a>, <a href="https://www.biometricupdate.com/companies/incode-technologies">Incode</a> and <a href="http://www.transunion.com/">TransUnion</a>. The National Institute of Standards and Technology's rules for remote one-to-one ID proofing – <a href="https://pages.nist.gov/800-63-3/sp800-63a.html">SP 800-63-3A</a> – set the requirements the GSA must meet.

The question is whether any demographic factors interfere with proofing. Data will be handled according to the <a href="https://incode.com/gsa/">GSA's rules</a> for collecting biometric information.

There's no heavy lifting for participants. People accepted for the study are <a href="https://identityequitystudy.gsa.gov/">asked</a> to take a picture of their ID and a selfie, repeating that process five times. They volunteer some additional personal data and then choose how they want to receive $25 in compensation.

GSA officials want all digital government identity verification processes to work equally well for all segments of the population in order to reduce fraud and operational costs and make it as easy as possible for residents to work with the government.

The private-sector partners will judge each participant's success in verifying their biometric data and send the results to the GSA.

## Scotland’s watchdog sends fresh warning over storing biometric data on Microsoft cloud
 - [https://www.biometricupdate.com/202308/scotlands-watchdog-sends-fresh-warning-over-storing-biometric-data-on-microsoft-cloud](https://www.biometricupdate.com/202308/scotlands-watchdog-sends-fresh-warning-over-storing-biometric-data-on-microsoft-cloud)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T18:56:25+00:00

<img alt="police scotland body cameras biometrics" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="777" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2019/12/17152505/police-scotland-body-cameras-biometrics.jpg" width="1200" />
		Scotland’s data protection watchdog has requested that the Scottish police assess the security of storing biometric data on Microsoft's servers.

Biometrics ­Commissioner Brian Plastow wants more information on a platform called Digital Evidence Sharing Capability (DESC). A pilot project, it is testing easier access by police and court employees to images, CCTV footage and other sensitive data used in court cases.

Plastow warned that storing sensitive data of UK citizens on a cloud server run by a United States company opens questions about U.S. government access to Scottish data. The DESC project is run by government contractor Axon and hosted on Microsoft's Azure.

“Based on the information so far provided to me by Police Scotland, I am not satisfied that biometric data within the Scottish government DESC project is being properly protected from unauthorized access,” he <a href="https://www.sundaypost.com/fp/data-protection-police-scotland/">told</a> The Sunday Post.

According to the U.S. Cloud Act, federal law enforcement agencies can compel domestic companies to provide data stored on servers regardless of whether the data is owned by a firm based outside the U.S.

“In other words, there is a risk U.S. federal authorities could compel the technology supplier to surrender very sensitive Police Scotland data without their knowledge or consent,” says Plastow.

Similar concerns <a href="https://www.biometricupdate.com/202307/scottish-police-reprimanded-for-illegally-storing-biometrics">have dogged</a> the Scottish Police Authority itself.

This could put the DESC pilot at odds with the UK data protection law and the Scottish Biometrics Commissioners Code of Practice, the commissioner says. The legality of the scheme is being reviewed by the UK’s information commissioner.

The Scottish police have said that digital evidence-sharing is limited and does not include fingerprint, bodycam or DNA evidence. The pilot is part of a £33 ­million (US$42 million) Scottish government initiative to transform how evidence is managed across the justice system.

This is not the first time Plastow has sounded an alarm over stored biometric data. Earlier this year, after the commissioner <a href="https://www.biometricupdate.com/202304/scottish-biometrics-commissioner-seeks-clarity-on-police-cloud-data-sharing-compliance">found</a> that the police had stored large amounts of biometric data from arrests on Microsoft servers, the Scottish Police Authority agreed to <a href="https://www.biometricupdate.com/202307/scottish-police-reprimanded-for-illegally-storing-biometrics">accept his recommendations</a>. This included better protection of children’s data and increasing transparency and “right to information” for data subjects.

The Cloud Act and the question of U.S. government’s access to foreign citizens' data is not only a concern in the UK. The US and the EU have <a href="https://www.biometricupdate.com/202307/us-implements-privacy-framework-for-eu-data-exchange-final-agreement-expected-mid-july">spent months</a> trying to reach a deal for the EU-U.S. data privacy framework with debates centering around concerns about U.S. spy agencies accessing Europeans’ private data. The mechanism is designed to safely transfer European Union citizens’ personal data to the United States, including biometric data.

## Why banks worldwide are turning to fingerprint biometrics
 - [https://www.biometricupdate.com/202308/why-banks-worldwide-are-turning-to-fingerprint-biometrics](https://www.biometricupdate.com/202308/why-banks-worldwide-are-turning-to-fingerprint-biometrics)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T18:30:26+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="777" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/05/03150458/biometric-data-privacy-scaled.jpg" width="2048" />
		<em>By Vito Fabbrizio, Managing Director, Biometrics Business Unit, <a href="https://www.hidglobal.com/">HID</a></em>

Banks and other financial institutions across the globe have been adopting biometrics as a way to improve the customer experience and increase security against identity fraud, such as money laundering or account takeovers.

Biometrics are used by banks to onboard customers and authenticate them after onboarding when conducting transactions, such as at ATMs. Biometric authentication can help ensure that transactions are not fraudulent -- and are less time-consuming than the traditional ways that banks reach a high level of assurance that the right person is accessing the account. Banks are also using biometrics as an internal control, securing staff access to sensitive data and restricted areas.

Fingerprints are the most common modality of choice for bank biometrics due to their speed, ease of use, high accuracy and cost-effective nature.

For example, <a href="https://www.hidglobal.com/documents/banco-supervielle-biometric-authentication-case-study">Banco Superveille</a> in Argentina uses fingerprints to verify the identity of pensioners collecting their benefits. Before adopting biometrics, the bank could only prevent fraudulent claims by the relatives of deceased pensioners by making all claimants go through a time-consuming authentication process. The decisions made by Banco Superveille to use fingerprint authentication present a good real-world example for other organizations to provide a more secure and better experience for staff and pensioners.
<h2>The benefits of biometrics in banking</h2>
The security and compliance benefits of biometrics are significant drivers of the technology’s adoption among financial institutions. All banks are subject to know your customer (KYC) and anti-money laundering (AML) regulations that involve identity verification to a high level of assurance for new customers.

Biometrics are one of the few ways of meeting the identity assurance standard these regulations require. An in-person fingerprint scan is the same method of identity verification the U.S. federal government uses to perform background checks.

The strength of identity assurance that provides regulatory compliance also protects against fraud. High-accuracy fingerprint scanners can provide this security and compliance, while improving the customer experience.

As an emerging technology, fingerprint biometrics can also help to build the brand of organizations that adopt them. The use of advanced technology creates confidence in many customers and demonstrates the bank is not stuck in the past.
<h2>Choosing the right fingerprint scanner for your bank</h2>
The standards behind KYC and AML regulations cannot be met with the fingerprint scanner on a mobile phone. Instead, banks deploy dedicated hardware to achieve the benefits of biometrics within branches.

As a relatively mature biometric modality, there are standards used throughout the world for fingerprints, notably including the U.S. Federal Bureau of Investigation’s Next Generation Identification (NGI) Image Quality Specifications (IQS). The common standard for image quality assessment is provided by the National Institute of Standards and Technology (NIST).

<a href="https://fbibiospecs.fbi.gov/certifications-1/cpl">The FBI</a> standards are often referred to in procurements around the world, with for instance the PIV (Personal Identity Verification) specification ensuring interoperability and quality of single finger scanners used for one-to-one biometric matching. The NIST Fingerprint Image Quality (NFIQ) 2 is open source software for assessing the quality of fingerprint images, with reference to the <a href="https://www.iso.org/standard/62791.html">ISO/IEC 29794-4</a> standard for biometric sample quality.

Banks in many countries must also adhere to <a href="https://fbibiospecs.fbi.gov/certifications-1/cpl">mandates</a> and fit into ecosystems that involve the specifications used for national ID cards.

The right biometric scanner must also provide sufficient accuracy to work at scale, while providing the right user experience. A financial institution with tens of millions of customers must match only the correct user to their account. While fingerprint biometrics tend to have low false accept rates, in which the wrong person would get into an account, cheap fingerprint scanners have higher false rejection rates, in which the legitimate customer is not matched. Scans should work the first time to deliver the kind of confidence and experience customers expect.

For example, Banco Superveille selected <a href="https://www.hidglobal.com/documents/multispectral-imaging-msi-fingerprint-technology-white-paper">fingerprint readers powered by multispectral imaging (MSI) technology</a> so they could consistently match the aging fingers of elderly customers in any challenging lighting conditions and harsh environments, and the bank was able to authenticate more than a million retirees faster than expected with fingerprint scanners.

Liveness detection is another important consideration, providing protection against relatively sophisticated fraud attacks. Fingerprint scanners that use advanced imaging, like <a href="https://www.hidglobal.com/documents/multispectral-imaging-msi-fingerprint-technology-white-paper">MSI</a>, can provide this capability, which is not available with some low price fingerprint scanners.

The standard for liveness, or presentation attack detection (PAD), is <a href="https://blog.hidglobal.com/2023/05/side-step-fingerprint-spoofs-iso-30107-3-pad-level-2-compliance">ISO/IEC 30107</a>. Testing for compliance to this standard is available from independent laboratories and shows the effectiveness of biometric systems against attacks with varying levels of sophistication. The highest level of testing against this standard from NIST-accredited labs is ISO 30107-3 PAD Level 2, which moves beyond simplistic fakes to consider effectiveness against 3D prosthetics and sophisticated fakes made with silicone and latex.

Independent PAD Level 2 testing to the ISO standard illustrates another way in which multispectral fingerprint scanners such as HID’s <a href="https://www.biometricupdate.com/202305/hid-globals-multispectral-fingerprint-scanners-score-perfect-level-2-pad-assessment">Lumidigm V-Series</a> are appropriate for high-security use cases like bank transactions.

<a href="https://www.hidglobal.com/documents/ebook-definitive-guide-fingerprint-technology">Multispectral fingerprint scanners</a> have been proven effective for use cases where security, consistency and accuracy are important. Leading biometrics device providers can help financial institutions integrate advanced fingerprint scanners into their business processes for improved security and customer experience.

Tightening regulations, increasing fraud concerns, and advances in biometric technology combine to make this the appropriate time for many of the banks and financial institutions that have not yet adopted fingerprints for in-branch identity verification to do so.

Read HID’s recent eBook, “<a href="https://www.biometricupdate.com/202308/a-definitive-guide-to-fingerprint-technology">A Definitive Guide to Fingerprint Technology</a>,” to explore popular fingerprint sensing technologies, common use cases and a checklist on key considerations for selecting the right readers for your bank.
<h2>About the author</h2>
Vito Fabbrizio is Managing Director of the Biometrics Business Unit at <a href="https://www.biometricupdate.com/companies/hid-global">HID Global</a>.

<em>DISCLAIMER: Biometric Update’s Industry Insights are submitted content. The views expressed in this post are that of the author, and don’t necessarily reflect the views of Biometric Update.</em>

https://www.biometricupdate.com/202308/a-definitive-guide-to-fingerprint-technology

## Australia launches platform with identity verification for betting self-exclusion
 - [https://www.biometricupdate.com/202308/australia-launches-platform-with-identity-verification-for-betting-self-exclusion](https://www.biometricupdate.com/202308/australia-launches-platform-with-identity-verification-for-betting-self-exclusion)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T17:12:50+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1367" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/11121342/online-gambling-scaled.jpg" width="2048" />
		Australia wants to help its citizens quit gambling with a new platform that players can use to exclude themselves from all online and telephone-based betting services in the country.

The National Self-Exclusion Register, “<a href="https://www.betstop.gov.au/">BetStop</a>,” was launched on Monday, August 21, and will rely on identity verification and know your customer checks to prevent gamblers from accessing their favorite pass-time for periods ranging from three months up to a lifetime.

“These measures will help to minimize the harm we see as a result of online gambling. For many people, it will change their lives,” Amanda Rishworth, minister for social services <a href="https://www.sbs.com.au/news/article/betstop-problem-gamblers-will-be-able-to-self-exclude-from-betting-platforms/59kxqobdt">explained </a>to SBS News in July.

Online gambling is the fastest-growing gambling segment in Australia, with over AU$1.4 billion (US$895 million) gambled online each year. Identity verification is aimed at preventing vulnerable people who have banned themselves from using an alias to place a bet. The new rules will apply to all 150 licensed Australian online betting companies.

Under the guidelines <a href="https://www.dss.gov.au/sites/default/files/documents/05_2022/national-policy-statement-updated-3-may-2022.docx">outlined</a> by the National Consumer Protection Framework for Online Wagering in Australia, interactive wagering operators will be required to verify each customers' identity when they sign up and before they can place a bet.

Wagering operators will have 72 hours to complete identity verification and KYC checks on players, much quicker than previously required. Operators will also have to close accounts immediately if a customer is verified as a person under 18 years of age. People also can’t self-exclude from one platform and not others.

The platform is managed by the Australian Communications and Media Authority (ACMA).

Face biometrics are <a href="https://www.biometricupdate.com/202307/australian-gaming-operator-calls-for-coordination-on-facial-recognition-for-restrictions">already used</a> for gambling restrictions in South Australia, Queensland and New South Wales, including for physical locations such as pubs and clubs. Club and hospitality organizations such as ClubsNSW and the Australian Hotels Association (AHA) have <a href="https://www.biometricupdate.com/202211/australian-state-poised-for-facial-recognition-to-tackle-problem-gambling-draws-criticism">expressed their support</a> for biometrics deployments for gambling while hospitality companies such as Endeavour Group have <a href="https://www.biometricupdate.com/202307/australian-gaming-operator-calls-for-coordination-on-facial-recognition-for-restrictions">called</a> for a nationally coordinated approach to facial recognition.

But the introduction of biometrics has also been met with criticism from some organizations.

“I don’t think the state gambling regulators have had their eyes on the ball when it comes to monitoring these matters like how data or facial recognition technology is used,” Carrol Bennett, CEO of the Alliance For Gambling Reform <a href="https://www.biometricupdate.com/202307/australian-gaming-operator-calls-for-coordination-on-facial-recognition-for-restrictions">said</a> in July.
<h2>Yoti pitches its Digital ID app for BetStop</h2>
Digital identity provider <a href="https://www.biometricupdate.com/companies/yoti">Yoti</a> says that its free Digital ID app alongside the standard player registration form can help companies comply with BetStop and complete identity checks.

The London-based firm, which provides age verification technology for companies such as <a href="https://www.biometricupdate.com/202306/yoti-greenbadg-expand-age-checks-to-free-tier-adult-site">Meta</a>, says that it can verify a person’s details to a government-issued identity document. Once verified, individuals can then share identity details straight from the app.

“This streamlines the onboarding process as players are pre-verified meaning they can sign up to a wagering site and prove their identity simultaneously,” the company says in a comment provided to <em>Biometric Update</em>. This also allows gambling platforms to prevent people who have previously banned themselves from signing up using an alias, Yoti explains.

Yoti says its Digital ID app is also privacy-preserving since customers players can just share the details the wagering operator needs without offering sensitive identity documents online.

## Mobile IDs find their way to US universities
 - [https://www.biometricupdate.com/202308/mobile-ids-find-their-way-to-us-universities](https://www.biometricupdate.com/202308/mobile-ids-find-their-way-to-us-universities)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T17:08:56+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1329" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/09/08121527/access-control-mobile-phone-UWB-scaled.jpg" width="2048" />
		Digital IDs are spreading from campus to campus with the help of HID Global. Universities across the United States have found a solution for students that keep losing their student IDs – putting them on their phones.

Clemson University in South Carolina will enable students, faculty and staff to add their IDs to Apple Wallet with the help of identity solution provider <a href="https://www.biometricupdate.com/companies/hid-global">HID Global</a>. Starting this fall, students can access campus buildings, purchase meals and use services such as printing just by swiping their Apple Watches or iPhones. HID says all student ID cards built with its Seos credential technology now support storage in Apple Wallets.

The contactless student IDs will be supported with HID’s iClass SE and HID Omnikey readers as well as protected by two-factor authentication, the company says in a release.

HID scored another win at the University of Kentucky where it plans to work with U.S. campus software maker <a href="https://www.cbord.com/">Cbord</a> to introduce student IDs into Apple and Android phones. Students will be able to use Cbord’s mobile ID app to link their mobile student IDs called WildCard, the university announced.

In May this year, the Texas-headquartered firm, owned by Swedish conglomerate <a href="https://www.biometricupdate.com/companies/assa-abloy">Assa Abloy</a>, <a href="https://www.biometricupdate.com/202305/forgerock-hid-global-launch-new-partner-programs">launched</a> its Origo Technology Partner Program focused on mobile ID and authentication solutions. Among its <a href="https://www.biometricupdate.com/202306/details-of-hid-tech-partner-program-for-mobile-solutions-revealed">first participants</a> are access control companies such as Smart Spaces and Witco.

HID Global also <a href="https://www.biometricupdate.com/202303/three-in-five-organizations-will-soon-use-biometrics-but-perception-problems-persist">published a report</a> this year exploring how businesses are adopting biometrics and digital identity for access management.

## NFL tackles access security with staff face biometrics pilot
 - [https://www.biometricupdate.com/202308/nfl-tackles-access-security-with-staff-face-biometrics-pilot](https://www.biometricupdate.com/202308/nfl-tackles-access-security-with-staff-face-biometrics-pilot)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T16:53:21+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1365" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/21124815/cleveland-browns-nfl-stadium-access-scaled.jpg" width="2048" />
		The NFL is testing a facial authentication system for credentialed staff at six stadiums this season, including the Cleveland Browns Stadium, the Cleveland Business Journal <a href="https://www.bizjournals.com/cleveland/news/2023/08/18/nfl-browns-credentialing-gameday-tech.html">reports</a>. The move to adopt biometrics for staff entry, orchestrated over two years by NFL's senior VP of security, Cathy Lanier, seeks to digitize and bolster the existing system that regulates access for workers, vendors, and media during games.

Lanier compares the NFL’s security measures to the complexity of the <a href="https://www.biometricupdate.com/tag/olympics">Olympics</a>, highlighting the intricacies of access zones and timing. Access to the field, for instance, is segmented into 20 different time slots. So, someone cleared two hours before kickoff might not have post-game access.

Says Lanier, “There’s a lot of holes in the current system. It’s a system that’s outdated and has a lot of vulnerabilities. It’s easy to pass a fake credential off. It’s difficult for security personnel to read a complex credential that’s got 27 different codes on it.”

The NFL plans to employ <a href="https://www.biometricupdate.com/companies/wicket">Wicket's</a> facial authentication technology, already adopted by the <a href="https://www.biometricupdate.com/202307/wickets-biometric-ticketing-gives-cleveland-browns-fans-some-relief">Browns</a> for fan entry, to cross-check digital photos against real-time facial scans. Real-time face biometrics authentication software will make it far more challenging to transfer credentials illicitly, a common form of fraud. Every scan will produce a straightforward red or green signal for security staff, reducing the risk of human error at checkpoints.

Wicket was ranked towards the top of NIST’s FRVT 1:1 <a href="https://www.biometricupdate.com/202306/us-facial-recognition-developers-jockey-for-position-in-nist-accuracy-testing">leaderboard as of mid-2023</a>, with an algorithm submitted in early 2022.

By the Super Bowl, the league will assess the pilot's performance. Brandon Covert, Browns’ VP of IT, noted that the technology has already proven successful at their training facility. There, it has eliminated the players’ need to remember their security cards and made things faster. “It’s been a tremendous success for us,” Covert says.

Covert estimates that around 500 individuals, primarily full-time team, NFL staff, and media, will use face biometrics on game days this season. However, given policy and legal considerations, rolling it out to the other 2,000 workers will require more time.

While Cleveland Browns Stadium is a confirmed pilot location, the NFL hasn’t disclosed the other participating venues.

## California has a shiny new app for its mDL
 - [https://www.biometricupdate.com/202308/california-has-a-shiny-new-app-for-its-mdl](https://www.biometricupdate.com/202308/california-has-a-shiny-new-app-for-its-mdl)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T16:28:34+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1187" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/21122606/CA-DMV-Wallet.jpg" width="1114" />
		California is expanding the availability of its mDL (mobile driver’s license) with a new app for mobile phones featuring face biometrics and liveness detection. To access the digital ID users can download the CA DMV Wallet app from the Apple App Store or Google Play. However, they won’t be able to add the mDL to native device mobile wallets such as those from Apple or Google, The Verge <a href="https://www.theverge.com/2023/8/18/23837596/california-digital-ids-program-mdl-expansion">reveals</a>.

The program, which aims to provide digital driver’s licenses and IDs to Californians, will allow up to 1.5 million participants, <a href="https://www.dmv.ca.gov/portal/ca-dmv-wallet/">according</a> to the local Department of Motor Vehicles (DMV). The mDL can be used for passing security at some airports with TSA PreCheck and proving your age to buy alcohol at a limited number of stores that accept TruAge capability. California residents are still urged to carry their physical IDs.

California’s DMV started <a href="https://www.biometricupdate.com/202308/california-tests-iowa-launches-digital-ids-while-michigan-considers-legislation">testing the mobile app</a> with <a href="https://www.biometricupdate.com/tag/iproov">iProov</a>’s biometrics and liveness detection at the beginning of August. The agency promises that the app “does not permanently store your personal data,” but it does keep your phone number and an “encrypted photo of your DL/ID card.”

Other states such as Iowa and Michigan are also taking steps towards offering mDL, meaning that they may soon be joining Arizona, Colorado, Louisiana, Mississippi, Georgia, Hawaii, Ohio, Utah, and Maryland.

## Liberia’s low biometric national ID card renewal rate bemoaned by authorities
 - [https://www.biometricupdate.com/202308/liberias-low-biometric-national-id-card-renewal-rate-bemoaned-by-authorities](https://www.biometricupdate.com/202308/liberias-low-biometric-national-id-card-renewal-rate-bemoaned-by-authorities)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T16:22:22+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1024" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/21122004/liberia-national-id-biometric-registration.png" width="1536" />
		The director of Liberia’s National Identification Registry (NIR), Andrew Peters, has expressed concerns over the reluctance by many Liberians and expatriates to renew their national ID cards, despite an executive order compelling them to do so.

Speaking during a recent press conference, the official said that the lack of interest goes against provisions of the National Identification Act, The New Dawn <a href="https://thenewdawnliberia.com/national-registry-frowns-at-citizens-defiance/">reports</a>.

Peters said only about 600,000 Liberians and expats have renewed their ID cards in five years, which represents just about 11.5 percent of the country’s population. The ID cards are issued to Liberians six years old and above.

The renewal entails capturing the biometric data of those concerned for the issuance of highly secured biometric national ID cards with a unique number which will be used as a social security number.

With the ID card, holders will have access to a range of services such as birth and death registrations, applications for passports and residential credentials, as well as for bank account opening.

Peters said while the low renewal rate is due largely to the unwillingness of Liberians, lack of support from relevant stakeholders such as government ministries, department and agencies, and private sector partners, is also not helping the situation.

The official said the NIR needs the full support of government and other partners to enable it open more enrollment centers in all the 15 counties of the country. Already, each of the counties has a well-equipped enrollment center, the NIR says. The official also urged the government to expand the database capacity of the NIR to be able to contain the data of all registrants.

Meanwhile, early this month, Peters stated that the NIR has the intention of taking the number of Liberians with a national ID card to one million by year end.

He noted that as part of the plan, the body has been in talks with other government agencies and partners to facilitate the process of issuing ID cards for their staff, The New Dawn writes in a different <a href="https://thenewdawnliberia.com/national-registry-unveils-plans-to-register-more-liberians/">report</a>.

Peters said a technical committee had been set up, in collaboration with the Liberia Institute for Statistics and Geo-Information Services (LISGIS), to make things work. He appealed for the cooperation of all Liberians to make the renewal exercise successful.

Liberia introduced biometrics for voter registration for the first time this year, but electoral agency official believe it is <a href="https://www.biometricupdate.com/202308/biometric-system-good-enough-for-liberia-voter-registration-not-voting-yet-govt">not yet time to use the technology</a> for voting.

## A definitive guide to fingerprint technology
 - [https://www.biometricupdate.com/202308/a-definitive-guide-to-fingerprint-technology](https://www.biometricupdate.com/202308/a-definitive-guide-to-fingerprint-technology)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T16:17:39+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1024" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/18133955/fingerprint-pink-blue-scaled.jpg" width="2048" />
		Fingerprint technology is a mature, proven method for user authentication across a range of industries, use cases and environments. Selecting the right fingerprint technology often comes down to the level of security and match accuracy required, capabilities and features needed and usability to achieve both adoption and productivity. 

This eBook by <a href="https://www.biometricupdate.com/companies/hid-global">HID Global</a> provides an overview of common fingerprint technologies available in the market today, aiming to help you make an informed decision in selecting an optimal fingerprint biometric system for your environment and needs.

## Ex-NADRA chair argues more biometrics use can greatly improve Pakistan’s elections
 - [https://www.biometricupdate.com/202308/ex-nadra-chair-argues-more-biometrics-use-can-greatly-improve-pakistans-elections](https://www.biometricupdate.com/202308/ex-nadra-chair-argues-more-biometrics-use-can-greatly-improve-pakistans-elections)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T15:38:06+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1367" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/08/21112401/pakistan-election-scaled.jpg" width="2048" />
		A former Chairman of the <a href="https://www.biometricupdate.com/companies/nadra">National Database and Registration Authority</a> of Pakistan (NADRA), Tariq Malik, has posited that the deployment of cutting-edge technologies such as biometrics can significantly change Pakistan’s elections management story for the good.

Malik, a Pakistani himself, makes the argument in a thought piece for <em><a href="https://www.undp.org/sites/g/files/zskgke326/files/2023-08/dap_-_volume_10_issue_2_-_choosing_development_14-08-2023.pdf">Development Advocate Pakistan</a></em>, a publication of the United Nations Development Program (UNDP). He believes that “by embracing technology-driven solutions, Pakistan can promote transparency, accountability, and timely electoral outcomes.”

In his article, "Buttons To Ballots: Technology and Pakistan’s Elections," Malik, who is also a former chief technical advisor at the UNDP, notes that by making the most of cutting-edge technology, the country can surmount geographical barriers, streamline the elections management process, and improve security measures, which are all necessary for entrenching trust in the democratic process.

“I believe that using digital technology can enhance electoral integrity. In Pakistan, the integration of technology into electoral politics holds tremendous potential for enhancing access, efficiency, security, and integrity in the electoral process,” Malik posits.

He acknowledges that while efforts have already been made to set the template for technology-driven elections in Pakistan through the “One CNIC – One Vote” principle championed by NADRA which increased voter participation and inclusion, the process can be made better.

“The integration of technology also promises to significantly increase the efficiency of elections in Pakistan. Biometric voter authentication systems can expedite the identification process, leading to smoother and faster voting procedures,” Malik writes.

“Furthermore, automating data collection and management can enhance efficiency in election administration, facilitating the verification of voter lists, monitoring campaign finances, and ensuring compliance with electoral regulations.”

Emphasizing the aspect of security, the ex-NADRA boss states: “technology can play a crucial role in fortifying Pakistan’s electoral system. Implementing robust cybersecurity measures, encryption protocols, and secure communication channels, can minimize the risk of tampering with voter data, results and critical election infrastructure.”

For all of these innovations to be introduced however, Malik says it is important for the Pakistani government to put in place the requisite legal framework and institutional and infrastructural investment plan.

He also suggests that given the “overpowering reactions against some radical reforms in the past, a transitional approach with vertical integration of technology in electoral processes seems to be a more viable option in Pakistan.”

With foundational blocks already in place, Malik holds that it is worthwhile to bring in innovations that cover all aspects of the electoral cycle including “data analytics for predictive analysis, real-time monitoring through video surveillance systems, education and awareness through online platforms, mobile applications and social media campaigns, among others.”

He also urges political parties in the country to embrace digital innovations which can streamline how their services are accessed, what he calls a “digital vision.”

## Biometrics Institute announces online public discussion on ethical use of AI
 - [https://www.biometricupdate.com/202308/biometrics-institute-announces-online-public-discussion-on-ethical-use-of-ai](https://www.biometricupdate.com/202308/biometrics-institute-announces-online-public-discussion-on-ethical-use-of-ai)
 - RSS feed: http://feeds.feedburner.com/biometricupdate
 - date published: 2023-08-21T15:03:04+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1366" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/06/30185300/algorithms-facial-recognition-bias-crowd-scaled.jpg" width="2048" />
		On September 13, the <a href="https://www.biometricupdate.com/companies/biometrics-institute">Biometrics Institute</a> will hold an hour-long virtual discussion on different aspects related to Artificial Intelligence, biometrics, privacy and ethics.

Dubbed “<a href="https://www.biometricsinstitute.org/event/on-the-pulse-conversation-biometrics-privacy-ethics/">On The Pulse (OTP) Conversation</a>,” the event to take place from 7:30-8:30 a.m. BST, will be open to members of the public, and will examine the responsible and ethical use of AI and biometrics, the Institute says in an announcement. Participation for non-members will require prior registration.

Resource persons will also look at measures that must be put in place to ensure data privacy as well as some important points to note for policy makers.

“The use of AI and biometrics is rapidly evolving, and it is important to have a conversation about the responsible and ethical use of these technologies,” says Isabelle Moeller, CEO of the Biometrics Institute. “This conversation will bring together experts from a variety of fields to discuss the key issues and challenges, and to develop recommendations for how to ensure that AI and biometrics are used in a way that people’s privacy and rights are protected.”

To be moderated by Terry Aulich, head of privacy expert group (PEG) at the Biometrics Institute, the conversation will feature panelists experienced in the topics to be discussed.

They include Brett Feldon, advisory council member at the Biometrics Institute; Elizabeth Coombs, human rights, privacy, governance &amp; regulation at Lloyd and Coombs; Beatriz Ruiz-Beato, Biometrics Institute privacy and policy expert group member; and Tuli Faas, Biometrics Institute privacy and policy expert group member.

The organizers say the OTP will be an opportunity for the Biometrics Institute members to share their thoughts and experiences on some of the issues addressed in recent publications such as <a href="https://www.biometricupdate.com/202303/biometrics-institute-launches-free-online-course-on-good-implementation-practices">an online course</a> on biometrics implementation good practices. They will also share their viewpoints of AI, biometrics, privacy and ethics.

“These viewpoints will help to inform the conversation and to develop recommendations for how to ensure the responsible and ethical use of AI and biometrics,” said Aulich.

Recently, <a href="https://www.linkedin.com/in/shelley-bryen-1194b84/">Shelley Bryen</a> revealed in<a href="https://www.linkedin.com/feed/update/urn:li:activity:7096178897221738496/"> a LinkedIn post</a> that she has started a role as member engagement manager at the Biometrics Institute.

Bryen joins in with 14 years of experience from <a href="https://www.biometricupdate.com/202104/worldreach-acquired-by-entrust-as-digital-identity-industry-consolidates">Entrust and WorldReach</a>, where she held different executive portfolios, the latest being that of director of product marketing for governments.

In the meantime, the <a href="https://www.biometricupdate.com/202305/biometrics-institute-congress-and-side-events">Biometrics Institute 2023 Congress</a> has been scheduled for October 17-18 in London.

