# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Burmistrz Kcyni Marek Szaruga nie żyje. Miał 59 lat. "Wiadomość, w którą trudno uwierzyć"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103048,burmistrz-kcyni-marek-szaruga-nie-zyje-mial-59-lat-trudno.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103048,burmistrz-kcyni-marek-szaruga-nie-zyje-mial-59-lat-trudno.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T20:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/b5/1c/z30103060M,Burmistrz-Kcyni-Marek-Szaruga.jpg" vspace="2" />Nie żyje burmistrz Kcyni Marek Szaruga. Samorządowiec zmarł 19 sierpnia podczas urlopu. "To bardzo smutna wiadomość, w którą jest nam nadal bardzo trudno uwierzyć" - napisała poinformował urząd miasta.

## Karambol pod Olsztynem. W zderzeniu pięciu pojazdów ucierpiało sześć osób. Wśród nich są dzieci
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102990,karambol-pod-olsztynem-w-zderzeniu-pieciu-pojazdow-ucierpialo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102990,karambol-pod-olsztynem-w-zderzeniu-pieciu-pojazdow-ucierpialo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T20:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e7/b5/1c/z30103015M,Do-poteznego-karambolu-z-udzialem-pieciu-pojazdow-.jpg" vspace="2" />Na drodze krajowej nr 16 łączącej miejscowości Olsztyn i Barczewo (woj. warmińsko-mazurskie) doszło do potężnego karambolu. W zdarzeniu uczestniczyło aż pięć pojazdów. W wyniku zdarzenia sześć osób odniosło obrażenia, z czego cztery z nich wymagały hospitalizacji. Wśród poszkodowanych są dzieci.

## Błaszczak: Departament Stanu zatwierdził sprzedaż Polsce 96 śmigłowców uderzeniowych AH-64E Apache
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103004,blaszczak-departament-stanu-zatwierdzil-sprzedaz-polsce-96.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30103004,blaszczak-departament-stanu-zatwierdzil-sprzedaz-polsce-96.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T19:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f6/b5/1c/z30103030M,AH-64E-Apache.jpg" vspace="2" />Minister obrony narodowej Mariusz Błaszczak poinformował, że amerykański Departament Stanu zatwierdził sprzedaż Polsce 96 śmigłowców uderzeniowych AH-64E Apache.

## Tysiąc złotych za nocleg pod Morskim Okiem. Biwakowicze naruszyli zakaz obowiązujący w TPN
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102592,tysiac-zlotych-za-nocleg-pod-morskim-okiem-biwakowicze-naruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102592,tysiac-zlotych-za-nocleg-pod-morskim-okiem-biwakowicze-naruszyli.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T18:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/b5/1c/z30102673M,Mezczyzni--ktorzy-biwakowali-w-poblizu-Morskiego-O.jpg" vspace="2" />"Nocleg pod gołym niebem w rejonie Morskiego Oka kosztował tych panów 1000 zł" - napisał na swoim Facebooku TPN, publikując zdjęcie dwóch mężczyzn i ich dobytku. Zatrzymując się na noc, turyści naruszyli zakaz mający chronić przyrodę i zapewniać bezpieczeństwo odwiedzającym.

## Tarnobrzeg. Nie żyje 12-latek znaleziony w stawie. Poszedł tam łowić ryby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102711,tarnobrzeg-nie-zyje-12-latek-znaleziony-w-stawie-poszedl-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102711,tarnobrzeg-nie-zyje-12-latek-znaleziony-w-stawie-poszedl-tam.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T17:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/90/73/1c/z29833360M,Tasma-policyjna---zdjecie-ilustracyjne.jpg" vspace="2" />W stawie w Tarnobrzegu znaleziono nieprzytomnego 12-latka. Mimo reanimacji nie udało się go uratować. Najprawdopodobniej chłopiec udał się nad zbiornik wodny, ponieważ chciał łowić ryby.

## Niedźwiedź gonił turystów w Tatrach. TPN tłumaczy, co oznacza stawanie na dwóch łapach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102372,niedzwiedz-gonil-turystow-w-tatrach-tpn-tlumaczy-co-oznacza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102372,niedzwiedz-gonil-turystow-w-tatrach-tpn-tlumaczy-co-oznacza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T16:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ab/b5/1c/z30102443M,Niedzwiedz---zdjecie-ilustracyjne.jpg" vspace="2" />Turyści poruszający się po tatrzańskiej Dolinie Jaworzynki przeżyli szok, gdy stanęli oko w oko z młodym niedźwiedziem. Zwierzę przez kilkaset metrów goniło grupę przerażonych spacerowiczów. Służby TPN tłumaczą zachowanie misia, obawiając się, że może być ono spowodowane zachowaniem ludzi.

## Półtorametrowy pyton pełzał obok budynków na poznańskiej Wildzie. Został złapany
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102507,poltorametrowy-pyton-pelzal-obok-budynkow-na-poznanskiej-wildzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102507,poltorametrowy-pyton-pelzal-obok-budynkow-na-poznanskiej-wildzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T16:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/b5/1c/z30102593M,Pyton.jpg" vspace="2" />W nocy na poznańskiej Wildzie dostrzeżono pełzającego obok budynków pytona. Wąż mierzył 1,5 metra długości. Na miejsce wezwano Straż Miejską.

## Incydent w Sarnowej Górze. RMF FM: Członek załogi Black Hawka spowodował śmiertelny wypadek 14 lat temu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102275,incydent-w-sarnowej-gorze-rmf-fm-czlonek-zalogi-black-hawka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30102275,incydent-w-sarnowej-gorze-rmf-fm-czlonek-zalogi-black-hawka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T15:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6c/b5/1c/z30102380M,Smiglowiec-Black-Hawk---zdjecie-ilustracyjne.jpg" vspace="2" />Nowe ustalenia dotyczące incydentu z udziałem śmigłowca Black Hawk w Sarnowej Górze. Jak ustalił dziennikarz RMF FM, jednym z członków załogi był pilot, który kilkanaście lat temu spowodował śmiertelny wypadek śmigłowca wojskowego.

## Chcieli zemścić się na policjantce. Napadli na nią w tramwaju po służbie, by "nikt jej nie obronił"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101842,chcieli-zemscic-sie-na-policjantce-napadli-na-nia-w-tramwaju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101842,chcieli-zemscic-sie-na-policjantce-napadli-na-nia-w-tramwaju.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T15:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/95/b5/1c/z30101909M,Policjantka---zdjecie-ilustracyjne.jpg" vspace="2" />Nawet pięć lat więzienia grozi parze, która w ramach zemsty zaatakowała funkcjonariuszkę. Według informacji przekazanych przez łódzką policję 28-latek i 25-latka mieli kilkakrotnie uderzyć policjantkę i grozić jej śmiercią. - Krzyczeli przy tym, że nie jest na służbie i nikt jej nie obroni - relacjonowała asp. Kamila Sowińska.

## Wąż schował się w lodówce supermarketu. Nietypowa interwencja strażaków z Kędzierzyna-Koźla
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101431,waz-schowal-sie-w-lodowce-supermarketu-nietypowa-interwencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101431,waz-schowal-sie-w-lodowce-supermarketu-nietypowa-interwencja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T13:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/18/b5/1c/z30101528M,Do-weza-ukrytego-w-lodowce-jednego-z-supermarketow.jpg" vspace="2" />Tego wezwania strażacy z oddziału w Kędzierzynie-Koźlu (woj. opolskie) długo nie zapomną. W jednej z lodówek należących do tamtejszego supermarketu ukrył się wąż. Przybyłe na miejsce służby odłowiły gada i przekazały go w ręce organu weterynarii.

## Tragiczny wypadek w Podgórze. Osobówka zderzyła się z ciężarówką. "Kierowca spłonął w aucie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101656,tragiczny-wypadek-w-podgorze-osobowka-zderzyla-sie-z-ciezarowka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101656,tragiczny-wypadek-w-podgorze-osobowka-zderzyla-sie-z-ciezarowka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T13:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f4/b5/1c/z30101748M,Tragiczny-wypadek-w-Podgorze--Osobowka-zderzyla-si.jpg" vspace="2" />W Podgórze doszło do tragicznego wypadku. Samochód osobowy zjechał na przeciwległy pas i zderzył się czołowo z ciężarówką. Auta stanęły w płomieniach. Kierowca osobówki zginął na miejscu.

## Incydent ze śmigłowcem Black Hawk. Prokuratura wszczyna śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101560,incydent-ze-smiglowcem-black-hawk-prokuratura-wszczyna-sledztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30101560,incydent-ze-smiglowcem-black-hawk-prokuratura-wszczyna-sledztwo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T12:51:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/b5/1c/z30101661M,Smiglowiec-Black-Hawk-zerwal-linie-energetyczne.jpg" vspace="2" />Policyjny Black Hawk podczas pikniku wojskowego w Sarnowej Górze doprowadził do zerwania linii energetycznej. Prokuratura wszczęła śledztwo w tej sprawie - podaje Polsat News.

## Cofał na autostradzie A4. Uderzył w inny samochód i pogryzł jego kierowcę. Tłumaczył się upałem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100968,cofal-na-autostradzie-a4-uderzyl-w-inny-samochod-i-pogryzl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100968,cofal-na-autostradzie-a4-uderzyl-w-inny-samochod-i-pogryzl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T12:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/b4/1c/z30101093M,Wypadek-na-autostradzie-A4.jpg" vspace="2" />Policjanci zatrzymali 30-letniego mężczyznę, który na opolskim odcinku autostrady A4 niespodziewanie zaczął cofać, czym powodował kolizję z innym autem. Po stłuczce mężczyzna chciał uciec pieszo. Kiedy świadkowie obecni na miejscu stłuczki próbowali go zatrzymać, 30-latek pogryzł poszkodowanego w kolizji kierowcę.

## Wielkopolska. Sześcioletnia dziewczynka wjechała pod samochód. Helikopter zabrał ją do szpitala
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100583,wielkopolska-szescioletnia-dziewczynka-wjechala-pod-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100583,wielkopolska-szescioletnia-dziewczynka-wjechala-pod-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T12:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/b4/1c/z30101063M,Dziewczynka-wjechala-pod-samochod-w-powiecie-ostro.jpg" vspace="2" />Sześcioletnia dziewczynka wpadła pod samochód w miejscowości Sieroszewice w Wielkopolsce. Nie usłyszała ostrzeżenia ojca przed nadjeżdżającym busem i gwałtownie skręciła na ulicę. Pogotowie przywiozło ją do szpitala w Ostrowie Wielkopolskim, gdzie lekarze wykryli złamanie kości czaszki. Sześciolatka została przetransportowana helikopterem do szpitala w Poznaniu.

## W Płocku 36-latka zostawiła w rozgrzanym aucie 10-latka i niemowlę. Musiała iść do solarium
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100754,w-plocku-36-latka-zostawila-w-rozgrzanym-aucie-10-latka-i-niemowle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100754,w-plocku-36-latka-zostawila-w-rozgrzanym-aucie-10-latka-i-niemowle.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T11:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/96/1c/z29975044M,Dziecko-w-samochodzie--zdjecie-ilustracyjne-.jpg" vspace="2" />36-latka z Płocka zaparkowała w niedozwolonym miejscu, po czym zostawiła w samochodzie dwójkę swoich dzieci w wieku 10 lat i 9 miesięcy. Kluczyków nie wyciągnęła ze stacyjki auta. Sama poszła do solarium.

## Gniezno. Nagła śmierć uczestniczki wycieczki. Przed wejściem do autokaru zemdlała. Chwilę później zmarła
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100446,mieli-wspolnie-jechac-nad-morze-jedna-z-uczestniczek-wycieczki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100446,mieli-wspolnie-jechac-nad-morze-jedna-z-uczestniczek-wycieczki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T11:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/b4/1c/z30100581M,Ambulans--zdjecie-ilustracyjne-.jpg" vspace="2" />Na parkingu przy ulicy Sobieskiego w Gnieźnie jedna z uczestniczek wyjazdu wypoczynkowego nad polskie morze zasłabła, zanim wsiadła do autokaru. Doszło do zatrzymania krążenia. Mimo podjętej reanimacji nie udało się jej uratować.

## Wstrząsające odkrycie w centrum Bytomia. Znaleziono ciało 30-latka. "Bierzemy wszystko pod uwagę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100470,wstrzasajace-odkrycie-w-centrum-bytomia-znaleziono-cialo-30-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100470,wstrzasajace-odkrycie-w-centrum-bytomia-znaleziono-cialo-30-latka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T10:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/b4/1c/z30099587M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W centrum Bytomia przypadkowy przechodzień natknął się w nocy z niedzieli na poniedziałek na zwłoki 30-latka. Obecnie trwa ustalanie okoliczności śmierci mężczyzny, co może utrudniać brak kamer monitoringu w miejscu znalezienia ciała. - Bierzemy wszystko pod uwagę - przekazała st. asp. Anna Lenkiewicz z KMP w Bytomiu.

## Krzyki, przekleństwa i płacz dzieci - nagranie z przelotu śmigłowca nad ludźmi. Są pytania do Morawieckiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100302,krzyki-przeklenstwa-i-placz-dzieci-nagranie-z-przelotu-smiglowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100302,krzyki-przeklenstwa-i-placz-dzieci-nagranie-z-przelotu-smiglowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T10:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8f/b4/1c/z30100623M,Krzyki--przeklenstwa-i-placz-dzieci---nagranie-z-p.jpg" vspace="2" />Najpierw słowa uznania dla policyjnego Black Hawka, podziwianego z bardzo bliska w czasie jego lotu, a za chwilę krzyki, przekleństwa, panika i płacz dzieci - to 60 sekund z pikniku wojskowego w Sarnowej Górze koło Ciechanowa, nagrane przez jednego z uczestników imprezy. Policyjny śmigłowiec doprowadził do zerwania linii energetycznej. W sprawie incydentu u premiera interweniuje jeden z senatorów opozycji, z kolei policja prowadzi "czynności wyjaśniające".

## Pościg samochodowy w Lublinie. Mężczyzna ruszył na policjantów z maczetą. W aucie były narkotyki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100208,poscig-samochodowy-w-lublinie-mezczyzna-ruszyl-na-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100208,poscig-samochodowy-w-lublinie-mezczyzna-ruszyl-na-policjantow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T10:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d0/b4/1c/z30100432M,Mezczyzna-zatrzymany-po-poscigu.jpg" vspace="2" />Kierowca renault megane, jadący w niedzielę rano ulicami Lublina, zignorował sygnał policji do zatrzymania się i zaczął uciekać. W miejscowości Kalinówka pod Lublinem auto uciekiniera zakopało się w ziemi, a kierowca ruszył na policjantów z maczetą. Padł strzał ostrzegawczy. W samochodzie i przy zatrzymanym mężczyźnie funkcjonariusze znaleźli narkotyki.

## Kiedy skończą się upały? Synoptycy IMGW zapowiadają zbliżające się ochłodzenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099805,kiedy-skoncza-sie-upaly-synoptycy-imgw-zapowiadaja-zblizajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099805,kiedy-skoncza-sie-upaly-synoptycy-imgw-zapowiadaja-zblizajace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T09:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6f/b4/1c/z30100079M,Pogody-dlugoterminowe-wskazuja-na-spadek-temperatu.jpg" vspace="2" />Ubiegły tydzień był najgorętszym w 2023 r. Prognozy opublikowane przez synoptyków IMGW wskazują, że najbliższe dni przyniosą nieznaczne ochłodzenie, podczas którego temperatura nie powinna przekraczać 30 stopni Celsjusza. Wstępne przewidywania meteorologów zdają się potwierdzać, że od zbliżającego się weekendu czeka nas koniec intensywnych upałów.

## Wypadek pod Mrągowem. Samochód uderzył w drzewo. Nie żyje dwóch 21-latków
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100175,wypadek-samochodowy-pod-mragowem-nie-zyje-dwoch-21-latkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30100175,wypadek-samochodowy-pod-mragowem-nie-zyje-dwoch-21-latkow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T08:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/b4/1c/z30100221M,Tragiczny-wypadek-pod-Mragowem--Nie-zyje-dwoch-21-.jpg" vspace="2" />Pod Mrągowem (woj. warmińsko-mazurskie) dwóch młodych mężczyzn zginęło w wypadku samochodowym. Trzeci trafił do szpitala. Policjanci ustalają przyczny zdarzenia.

## Gdzie jest burza? Synoptycy wydali ostrzeżenia pierwszego stopnia. Może zagrzmieć, pojawi się grad
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099574,gdzie-jest-burza-synoptycy-wydali-ostrzezenia-pierwszego-stopnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099574,gdzie-jest-burza-synoptycy-wydali-ostrzezenia-pierwszego-stopnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T08:06:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/b4/1c/z30099804M,Kolejne-burze-pojawia-sie-na-poludniu-kraju.jpg" vspace="2" />Burze, intensywne opady deszczu i gradu będą się pojawiać od początku tygodnia na południu kraju. Synoptycy z Instytutu Meteorologii i Gospodarki Wodnej (IMGW) wydali ostrzeżenia pierwszego stopnia przed nagłymi zjawiskami atmosferycznymi. Gdzie teraz jest burza?

## Poczesna. Operator koparki natknął się na ludzkie szczątki. Mieszkańcy mówią o zaginionym mężczyźnie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099462,poczesna-operator-koparki-natknal-sie-na-ludzkie-szczatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099462,poczesna-operator-koparki-natknal-sie-na-ludzkie-szczatki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T07:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/b4/1c/z30099587M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />Podczas prac ziemnych na terenie prywatnej posesji w miejscowości Poczesna (woj. śląskie), operator koparki odnalazł ludzkie szczątki. Prowadzący śledztwo policjanci zlecili badania DNA, których wyniki mogą być kluczowe w ustaleniu tożsamości ofiary. Mieszkańcy Poczesnej spekulują, że ciało może należeć do zaginionego dwa lata temu mężczyzny.

## Dębica. Pożar zakładu produkującego opony. Na miejscu 140 strażaków, ewakuowano ponad 200 osób
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099467,pozar-zakladu-produkujacego-opony-w-debicy-ponad-200-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099467,pozar-zakladu-produkujacego-opony-w-debicy-ponad-200-osob-zostalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T07:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/56/b4/1c/z30099542M,Pozar-w-zakladzie-produkujacym-opony-w-Debicy.jpg" vspace="2" />W Dębicy doszło do pożaru segmentu hali produkcyjnej firmy produkującej opony. Ewakuowano ponad 200 pracowników. "W kulminacyjnym momencie w akcję gaśniczą zaangażowanych było 35 zastępów, blisko 140 strażaków" - przekazali strażacy z Komendy Wojewódzkiej PSP w Rzeszowie.

## Liszna. Ciało 32-latka w zbiorniku retencyjnym. Świadek słyszał niepokojące głosy. Ruszyło śledztwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099466,liszna-cialo-32-latka-w-zbiorniku-retencyjnym-swiadek-slyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099466,liszna-cialo-32-latka-w-zbiorniku-retencyjnym-swiadek-slyszal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T07:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/38/b4/1c/z30099512M,Liszna-na-Podkarpaciu--zdj--ilustracyjne-.jpg" vspace="2" />Ze zbiornika retencyjnego w miejscowości Liszna na Podkarpaciu strażacy- płetwonurkowie wydobyli w niedzielę ciało 32-latka. Służby zaalarmował świadek, który zobaczył pozostawione na brzegu rzeczy osobiste i usłyszał niepokojące głosy.

## Policyjny Black Hawk zerwał linię energetyczną. Ekspert: O włos od tragedii. Nie wolno latać nad publicznością
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099458,policyjny-black-hawk-zerwal-linie-energetyczna-w-sarnowej-gorze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30099458,policyjny-black-hawk-zerwal-linie-energetyczna-w-sarnowej-gorze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-08-21T05:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/b4/1c/z30099515M,Mazowsze--Policyjny-Black-Hawk-zerwal-linie-energe.jpg" vspace="2" />- Ewidentnie nie była to profesjonalnie przygotowana impreza lotnicza - mówił o pikniku wojskowym w Sarnowej Górze koło Ciechanowa, w województwie mazowieckim publicysta lotniczy Michał Setlak. Na antenie TVN24 mówił o incydencie, do którego tam doszło - policyjny śmigłowiec Black Hawk doprowadził do zerwania linii energetycznej.

