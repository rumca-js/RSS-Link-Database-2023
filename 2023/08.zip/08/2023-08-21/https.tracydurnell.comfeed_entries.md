# Source:Tracy Durnell, URL:https://tracydurnell.com/feed/, language:en-US

## A quiet life, a good life
 - [https://tracydurnell.com/2023/08/21/a-quiet-life-a-good-life/](https://tracydurnell.com/2023/08/21/a-quiet-life-a-good-life/)
 - RSS feed: https://tracydurnell.com/feed/
 - date published: 2023-08-21T21:24:24+00:00

what does it mean to live well by Winnie Lim I realised there and then: this is what it means to me to live well – to learn to truly love these mundane moments. &#160; It is just how our brain works. We grow numb to things we used to desire so much for, and [&#8230;]

