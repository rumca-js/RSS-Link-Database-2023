# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## GTA 5 najczęściej kupowaną grą w Europie. 10-letnia gra Rockstara nadal zaskakuje
 - [https://ithardware.pl/aktualnosci/gta_5_najczesciej_kupowana_gra_w_europie_10_letnia_gra_rockstara_nadal_zaskakuje-28890.html](https://ithardware.pl/aktualnosci/gta_5_najczesciej_kupowana_gra_w_europie_10_letnia_gra_rockstara_nadal_zaskakuje-28890.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T21:50:53+00:00

<img src="https://ithardware.pl/artykuly/min/28890_1.jpg" />            Grand Theft Auto 5 ma na koncie dekadę, ale nie przeszkadza to grze Rockstar Games osiągać dużego sukcesu. Produkcja ostatnio ponownie trafiła na szczyt listy sprzedaży gier w Europie wygrywając m.in. z Diablo 4.

Grand Theft Auto 5 na szczycie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gta_5_najczesciej_kupowana_gra_w_europie_10_letnia_gra_rockstara_nadal_zaskakuje-28890.html">https://ithardware.pl/aktualnosci/gta_5_najczesciej_kupowana_gra_w_europie_10_letnia_gra_rockstara_nadal_zaskakuje-28890.html</a></p>

## Twórca Overwatcha 2 odnosię się do fali krytyki gry
 - [https://ithardware.pl/aktualnosci/tworca_overwatcha_2_odnosie_sie_do_fali_krytyki_gry-28888.html](https://ithardware.pl/aktualnosci/tworca_overwatcha_2_odnosie_sie_do_fali_krytyki_gry-28888.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T18:13:00+00:00

<img src="https://ithardware.pl/artykuly/min/28888_1.jpg" />            Overwatch 2 został zbombardowany negatywnymi recenzjami na Steam, co z jednej strony dziwi, ponieważ gra jest dostępna od zeszłego roku i na żadnej platformie nie wylał się na nią aż taki hejt. Do sytuacji odni&oacute;sł się jeden z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tworca_overwatcha_2_odnosie_sie_do_fali_krytyki_gry-28888.html">https://ithardware.pl/aktualnosci/tworca_overwatcha_2_odnosie_sie_do_fali_krytyki_gry-28888.html</a></p>

## TECNO przedstawia serię smartfonów SPARK 10: Edycja Magic Skin
 - [https://ithardware.pl/aktualnosci/tecno_przedstawia_serie_smartfonow_spark_10_edycja_magic_skin-28887.html](https://ithardware.pl/aktualnosci/tecno_przedstawia_serie_smartfonow_spark_10_edycja_magic_skin-28887.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T17:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/28887_1.jpg" />            Marka TECNO, kt&oacute;ra coraz aktywniej działa na polskim rynku prezentuje serię&nbsp; smartfon&oacute;w SPARK 10 Magic Skin wykonaną z eleganckiego materiału posiadającego lekko chropowatą teksturę.

W smartfonie TECNO SPARK 10 Magic Skin...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tecno_przedstawia_serie_smartfonow_spark_10_edycja_magic_skin-28887.html">https://ithardware.pl/aktualnosci/tecno_przedstawia_serie_smartfonow_spark_10_edycja_magic_skin-28887.html</a></p>

## Seria Google Pixel 8 może nie posiadać slotu na kartę SIM. Zamiast tego eSIM
 - [https://ithardware.pl/aktualnosci/seria_google_pixel_8_moze_nie_posiadac_slotu_na_karte_sim_zamiast_tego_esim-28886.html](https://ithardware.pl/aktualnosci/seria_google_pixel_8_moze_nie_posiadac_slotu_na_karte_sim_zamiast_tego_esim-28886.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T16:23:40+00:00

<img src="https://ithardware.pl/artykuly/min/28886_1.jpg" />            Istniej szansa, że nadchodzące smartfony z linii Google Pixel 8 pozbędą się tradycyjnego slotu na kartę SIM. Zamiast tego pojawić miałaby się obsługa standardu eSIM. Jeśli Google faktycznie zdecydowałoby się na taką zmianę, to najpewniej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/seria_google_pixel_8_moze_nie_posiadac_slotu_na_karte_sim_zamiast_tego_esim-28886.html">https://ithardware.pl/aktualnosci/seria_google_pixel_8_moze_nie_posiadac_slotu_na_karte_sim_zamiast_tego_esim-28886.html</a></p>

## Gogle Apple Vision Pro mogą osiągać wyższe odświeżanie ekranu. To jednak nie wszystko
 - [https://ithardware.pl/aktualnosci/gogle_apple_vision_pro_moga_osiagac_wyzsze_odswiezanie_ekranu_to_jednak_nie_wszystko-28885.html](https://ithardware.pl/aktualnosci/gogle_apple_vision_pro_moga_osiagac_wyzsze_odswiezanie_ekranu_to_jednak_nie_wszystko-28885.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T15:31:30+00:00

<img src="https://ithardware.pl/artykuly/min/28885_1.jpg" />            Chociaż do rynkowej premiery gogli Apple Vision Pro zostało jeszcze sporo czasu, już teraz znamy całkiem sporo informacji na ich temat. Już dość dawno temu dowiedzieliśmy się, że akcesorium będzie wyświetlało obraz z częstotliwością 90...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gogle_apple_vision_pro_moga_osiagac_wyzsze_odswiezanie_ekranu_to_jednak_nie_wszystko-28885.html">https://ithardware.pl/aktualnosci/gogle_apple_vision_pro_moga_osiagac_wyzsze_odswiezanie_ekranu_to_jednak_nie_wszystko-28885.html</a></p>

## Niemalże dowolny BIOS do prawie wszystkich kart NVIDII? Odkryto backdoora, który to umożliwia
 - [https://ithardware.pl/aktualnosci/niemalze_dowolny_bios_do_prawie_wszystkich_kart_nvidii_odkryto_backdoora_ktory_to_umozliwia-28883.html](https://ithardware.pl/aktualnosci/niemalze_dowolny_bios_do_prawie_wszystkich_kart_nvidii_odkryto_backdoora_ktory_to_umozliwia-28883.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T14:19:00+00:00

<img src="https://ithardware.pl/artykuly/min/28883_1.jpg" />            Modyfikacje BIOS kart graficznych NVIDII ponownie stały się możliwe. Dzięki nowym narzędziom możliwe jest ominięcie zabezpieczeń NVIDII. Pozwala to chociażby na wgranie oprogramowania BIOS dedykowanego karcie z wysokiej p&oacute;łki do modelu,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/niemalze_dowolny_bios_do_prawie_wszystkich_kart_nvidii_odkryto_backdoora_ktory_to_umozliwia-28883.html">https://ithardware.pl/aktualnosci/niemalze_dowolny_bios_do_prawie_wszystkich_kart_nvidii_odkryto_backdoora_ktory_to_umozliwia-28883.html</a></p>

## 11 GB vs 8 GB VRAM. Test GeForce GTX 1080 Ti vs RTX 2070 SUPER w 2023 roku
 - [https://ithardware.pl/testyirecenzje/gtx_1080_ti_vs_rtx_2070_super_test_kart_graficznych-28811.html](https://ithardware.pl/testyirecenzje/gtx_1080_ti_vs_rtx_2070_super_test_kart_graficznych-28811.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T13:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/28811_1.jpg" />            GTX 1080 Ti vs RTX 2070 SUPER - topowy Pascal po latach

W trzecim odcinku cyklu poświęconego starszym układom graficznym pod lupę trafiają GeForce GTX 1080 Ti, tj. flagowy przedstawiciel generacji Pascal w ramach linii GeForce GTX, kt&oacute;ry...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/gtx_1080_ti_vs_rtx_2070_super_test_kart_graficznych-28811.html">https://ithardware.pl/testyirecenzje/gtx_1080_ti_vs_rtx_2070_super_test_kart_graficznych-28811.html</a></p>

## Genesis Thor 660 - nowa wersja popularnej klawiatury z przełącznikami Gateron Brown
 - [https://ithardware.pl/aktualnosci/genesis_thor_660_nowa_wersja_popularnej_klawiatury_z_przelacznikami_gateron_brown-28882.html](https://ithardware.pl/aktualnosci/genesis_thor_660_nowa_wersja_popularnej_klawiatury_z_przelacznikami_gateron_brown-28882.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T12:57:40+00:00

<img src="https://ithardware.pl/artykuly/min/28882_1.jpg" />            Wachlarz klawiatur Genesis poszerzył się o nowy model Thor 660 z przełącznikami Gateron Brown. Urządzenie powinno zainteresować nie tylko graczy, lecz także osoby wykorzystujące komputer do pracy.

W por&oacute;wnaniu z przełącznikami Gateron...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/genesis_thor_660_nowa_wersja_popularnej_klawiatury_z_przelacznikami_gateron_brown-28882.html">https://ithardware.pl/aktualnosci/genesis_thor_660_nowa_wersja_popularnej_klawiatury_z_przelacznikami_gateron_brown-28882.html</a></p>

## Intel podkręca swoje karty za sprawą aktualizacji sterowników. +150 MHz dzięki nowej wersji
 - [https://ithardware.pl/aktualnosci/intel_podkreca_swoje_karty_za_sprawa_aktualizacji_sterownikow_150_mhz_dzieki_nowej_wersji-28881.html](https://ithardware.pl/aktualnosci/intel_podkreca_swoje_karty_za_sprawa_aktualizacji_sterownikow_150_mhz_dzieki_nowej_wersji-28881.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T12:47:40+00:00

<img src="https://ithardware.pl/artykuly/min/28881_1.jpg" />            Nowe wydanie sterownik&oacute;w Intela dla kart graficznych Arc przynosi dość standardowe ulepszenia, jak optymalizacja wydajności w grach, poprawa stabilności, czy naprawa błęd&oacute;w. Do listy zmian można jednak dopisać coś, czego mało kto...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/intel_podkreca_swoje_karty_za_sprawa_aktualizacji_sterownikow_150_mhz_dzieki_nowej_wersji-28881.html">https://ithardware.pl/aktualnosci/intel_podkreca_swoje_karty_za_sprawa_aktualizacji_sterownikow_150_mhz_dzieki_nowej_wersji-28881.html</a></p>

## Black Myth: Wukong - zobaczcie nowy gameplay. Ta gra pozamiata
 - [https://ithardware.pl/aktualnosci/black_myth_wukong_ta_gra_pozamiata_zobaczcie_nowy_gameplay-28880.html](https://ithardware.pl/aktualnosci/black_myth_wukong_ta_gra_pozamiata_zobaczcie_nowy_gameplay-28880.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T12:12:01+00:00

<img src="https://ithardware.pl/artykuly/min/28880_1.jpg" />            Black Myth: Wukong to gra, o kt&oacute;rej piszemy już od trzech lat, a choć chiński deweloper Game Science od jakiegoś czasu wypuszcza nowe materiały z gry, to wiele os&oacute;b wątpiło, czy w og&oacute;le ujrzy ona światło dzienne. Teraz...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/black_myth_wukong_ta_gra_pozamiata_zobaczcie_nowy_gameplay-28880.html">https://ithardware.pl/aktualnosci/black_myth_wukong_ta_gra_pozamiata_zobaczcie_nowy_gameplay-28880.html</a></p>

## Modder zamienił tanie APU w 16 GB GPU do obciążeń AI
 - [https://ithardware.pl/aktualnosci/modder_zamienil_tanie_apu_w_16_gb_gpu_do_obciazen_ai-28875.html](https://ithardware.pl/aktualnosci/modder_zamienil_tanie_apu_w_16_gb_gpu_do_obciazen_ai-28875.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T11:40:30+00:00

<img src="https://ithardware.pl/artykuly/min/28875_1.jpg" />            Boom na sztuczną inteligencję sprawia, że na rynku trwa zażarta walka o procesory graficzne dedykowane AI, takie jak NVIDIA H100 i A100, co sprawia, że są problemy z ich dostępnością, a to z kolei powoduje, iż ich ceny osiągają zawrotne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/modder_zamienil_tanie_apu_w_16_gb_gpu_do_obciazen_ai-28875.html">https://ithardware.pl/aktualnosci/modder_zamienil_tanie_apu_w_16_gb_gpu_do_obciazen_ai-28875.html</a></p>

## AMD Ryzen 9 7945HX3D - wyciekły wyniki testów laptopowego CPU z 3D V-Cache
 - [https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx3d_wyciekly_wyniki_testow_laptopowego_cpu_z_3d_v_cache-28877.html](https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx3d_wyciekly_wyniki_testow_laptopowego_cpu_z_3d_v_cache-28877.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T11:40:20+00:00

<img src="https://ithardware.pl/artykuly/min/28877_1.png" />            W sieci pojawiły się nowe wyniki benchmark&oacute;w procesora AMD Ryzen 9 7945HX3D do gamingowych laptop&oacute;w, pokazując, że pierwszy mobilny układ 3D V-Cach oferuje świetną wydajność wielowątkową.

Pierwszy mobilny CPU z&nbsp;3D...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx3d_wyciekly_wyniki_testow_laptopowego_cpu_z_3d_v_cache-28877.html">https://ithardware.pl/aktualnosci/amd_ryzen_9_7945hx3d_wyciekly_wyniki_testow_laptopowego_cpu_z_3d_v_cache-28877.html</a></p>

## Recenzent zachwyca się Starfield. Twierdzi, że gra wygląda świetnie i jest pozbawiona błędów
 - [https://ithardware.pl/aktualnosci/rezencent_zachwyca_sie_starfield_twierdzi_ze_gra_wyglada_swietnie_i_jest_pozbawiona_bledow-28878.html](https://ithardware.pl/aktualnosci/rezencent_zachwyca_sie_starfield_twierdzi_ze_gra_wyglada_swietnie_i_jest_pozbawiona_bledow-28878.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T09:23:40+00:00

<img src="https://ithardware.pl/artykuly/min/28878_1.jpg" />            Starfield to jedna z najbardziej oczekiwanych gier tego roku i choć Baldur's Gate 3 bardzo wysoko zawiesił poprzeczkę wszystkich tegorocznym produkcjom, to jednak liczymy na to, że nowy tytuł Bethesdy nie zawiedzie i r&oacute;wnież okaże się...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rezencent_zachwyca_sie_starfield_twierdzi_ze_gra_wyglada_swietnie_i_jest_pozbawiona_bledow-28878.html">https://ithardware.pl/aktualnosci/rezencent_zachwyca_sie_starfield_twierdzi_ze_gra_wyglada_swietnie_i_jest_pozbawiona_bledow-28878.html</a></p>

## Nowy akumulator do samochodów elektrycznych obiecuje 400 km po 10 min ładowania
 - [https://ithardware.pl/aktualnosci/nowy_akumulator_do_samochodow_elektrycznych_obiecuje_400_km_po_10_min_ladowania-28876.html](https://ithardware.pl/aktualnosci/nowy_akumulator_do_samochodow_elektrycznych_obiecuje_400_km_po_10_min_ladowania-28876.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T08:26:30+00:00

<img src="https://ithardware.pl/artykuly/min/28876_1.jpg" />            Dostawca akumulator&oacute;w EV, firma CATL, przedstawiła pierwszą na świecie superszybko ładowany akumulator LFP 4C. Według firmy, jej bateria Shenxing może zapewnić 400 kilometr&oacute;w zasięgu po 10-minutowym ładowaniu. Przy pełnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowy_akumulator_do_samochodow_elektrycznych_obiecuje_400_km_po_10_min_ladowania-28876.html">https://ithardware.pl/aktualnosci/nowy_akumulator_do_samochodow_elektrycznych_obiecuje_400_km_po_10_min_ladowania-28876.html</a></p>

## Szczoteczki soniczne Nandme NX7000 i NX8000 w super cenie!
 - [https://ithardware.pl/aktualnosci/szczoteczki_soniczne_nandme_nx7000_i_nx8000_w_super_cenie-28879.html](https://ithardware.pl/aktualnosci/szczoteczki_soniczne_nandme_nx7000_i_nx8000_w_super_cenie-28879.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T07:59:30+00:00

<img src="https://ithardware.pl/artykuly/min/28879_1.jpg" />            Planujesz zakup szczoteczki sonicznej, ale nie wiesz, na jaki model się zdecydować? Koniecznie zainteresuj się aktualnie trwającą promocją na produkty Nandme NX7000 oraz Nandme NX8000. Sprawdź, co potrafią!

Nandme NX7000 i NX8000 doczekały...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/szczoteczki_soniczne_nandme_nx7000_i_nx8000_w_super_cenie-28879.html">https://ithardware.pl/aktualnosci/szczoteczki_soniczne_nandme_nx7000_i_nx8000_w_super_cenie-28879.html</a></p>

## Poznaliśmy zwycięzców MSI Creator Awards 2023
 - [https://ithardware.pl/aktualnosci/poznalismy_zwyciezcow_msi_creator_awards_2023-28874.html](https://ithardware.pl/aktualnosci/poznalismy_zwyciezcow_msi_creator_awards_2023-28874.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T07:36:00+00:00

<img src="https://ithardware.pl/artykuly/min/28874_1.jpg" />            &nbsp;



MSI oficjalnie ogłosiło zwycięzc&oacute;w MSI Creator Awards 2023. To właśnie ci wyjątkowi artyści wykazali się niezwykłymi umiejętnościami, kreatywnością i innowacyjnością w trzech konkursowych kategoriach: Graphic Design,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poznalismy_zwyciezcow_msi_creator_awards_2023-28874.html">https://ithardware.pl/aktualnosci/poznalismy_zwyciezcow_msi_creator_awards_2023-28874.html</a></p>

## Ryzen Threadripper PRO 7955WX potwierdzony. Zanym szczegóły specyfikacji
 - [https://ithardware.pl/aktualnosci/ryzen_threadripper_pro_7955wx_potwierdzony_zanym_szczegoly_specyfikacji-28873.html](https://ithardware.pl/aktualnosci/ryzen_threadripper_pro_7955wx_potwierdzony_zanym_szczegoly_specyfikacji-28873.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T06:15:21+00:00

<img src="https://ithardware.pl/artykuly/min/28873_1.jpg" />            Jak potwierdza najnowszy przeciek, nadchodząca seria procesor&oacute;w Ryzen Threadripper ponownie oferować będzie 16-rdzeniowy model.&nbsp;

W bazie danych benchmarku Geekbench pojawił się wynik przedstawiający najnowszą, niewydaną jeszcze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ryzen_threadripper_pro_7955wx_potwierdzony_zanym_szczegoly_specyfikacji-28873.html">https://ithardware.pl/aktualnosci/ryzen_threadripper_pro_7955wx_potwierdzony_zanym_szczegoly_specyfikacji-28873.html</a></p>

## Wróć do szkoły w wielkim stylu. Laptopy do nauki i nie tylko nawet do 1400 zł w x-komie
 - [https://ithardware.pl/aktualnosci/wroc_do_szkoly_w_wielkim_stylu_laptopy_do_nauki_i_nie_tylko_nawet_do_1400_zl_w_x_komie-28872.html](https://ithardware.pl/aktualnosci/wroc_do_szkoly_w_wielkim_stylu_laptopy_do_nauki_i_nie_tylko_nawet_do_1400_zl_w_x_komie-28872.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-08-21T05:45:40+00:00

<img src="https://ithardware.pl/artykuly/min/28872_1.jpg" />            Co prawda pozostało jeszcze parę dni wakacji, ale powoli warto zacząć myśleć o zbliżającym się nowym roku szkolnym. Z tej okazji x-kom przygotował świetne promocje, dzięki kt&oacute;rym można sporo zaoszczędzić. Pierwsza obejmuje laptopy,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wroc_do_szkoly_w_wielkim_stylu_laptopy_do_nauki_i_nie_tylko_nawet_do_1400_zl_w_x_komie-28872.html">https://ithardware.pl/aktualnosci/wroc_do_szkoly_w_wielkim_stylu_laptopy_do_nauki_i_nie_tylko_nawet_do_1400_zl_w_x_komie-28872.html</a></p>

