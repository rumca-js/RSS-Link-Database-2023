# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## The Book 8088 Is A New Retro PC You Can Buy On AliExpress And Its Awesome!
 - [https://www.youtube.com/watch?v=O70vLEEOLGM](https://www.youtube.com/watch?v=O70vLEEOLGM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-08-21T14:06:00+00:00

Book 8088: https://s.click.aliexpress.com/e/_mqgrbv4
MOVESPEED SSD NVMe M.2 2280：https://s.click.aliexpress.com/e/_mqDYETc
Exclusive coupon: “ ALLONAE”  $20 off for orders over $100，valid tim（8.18-9.24 Applicable to all products

The Book 8088 Is a newly-made retro computers That you can buy  on Aliexpress! This Is Not emulation , this Is A real DOS PC running an 8088processor, Using custom PCBs with open source software projects, off-the-shelf Parts, and an injection molded enclosure.

AliExpress 828 big promotion：https://s.click.aliexpress.com/e/_mMNd8VG
The Official time is 8/21 - 8/28
$4 off for orders over $35  
$10 off for orders over $70
$20 off for orders over $100
the above info only applies to stores participating in the 828 promotion, even if your order is not from the same store.

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

30% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows 11 Pro Key($21): https://biitt.ly/RUZiX
Windows10 Home Key($14): https://biitt.ly/2tPi1
Office 2019 pro key($46): https://biitt.ly/o0OQT
Office 2021 pro key($59): https://biitt.ly/iDMHc

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME
12400 Wake Union Church Rd PMB 239
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#AliExpress #WhyPayMore #AliExpressFinds #AliExpressIRL #AliHouse#ALLONAE

## The AYANEO Pocket Air Is Getting A Snapdragon 8 Gen 2 Upgrade! A Powerful Hand-Held
 - [https://www.youtube.com/watch?v=djrdOH3vlMs](https://www.youtube.com/watch?v=djrdOH3vlMs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-08-21T12:05:00+00:00

Looks Like we will see a Major CPU upgrade for the upcoming Ayaneo Pocket Air! Originally The only CPU annoyed was the Dimensity 1200 but I have some new Info we are also going to see A Snapdragon 8 Gen 2 version of the AYANEO Pocket Air! With a 5.5” OLED screen this could turn out to be the Best Android handheld gaming console so far!

Learn More Here:https://www.ayaneo.com/product/AYANEO-Pocket-AIR.html

AYANEO Pocket Air Indigogo: https://www.indiegogo.com/projects/ayaneo-pocket-air-ultra-thin-oled-android-handheld/coming_soon

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

30% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows 11 Pro Key($21): https://biitt.ly/RUZiX
Windows10 Home Key($14): https://biitt.ly/2tPi1
Office 2019 pro key($46): https://biitt.ly/o0OQT
Office 2021 pro key($59): https://biitt.ly/iDMHc

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

Want to send me something?
ETAPRIME
12400 Wake Union Church Rd PMB 239
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#ayaneo #android #etaprime

