# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## The Most Popular Digital Abortion Clinics, Ranked by Data Privacy
 - [https://www.wired.com/story/most-popular-digital-telehealth-medication-abortion-ranked-data-privacy/](https://www.wired.com/story/most-popular-digital-telehealth-medication-abortion-ranked-data-privacy/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-08-21T12:00:00+00:00

Telehealth companies that provide abortion pills are surging in popularity. Which are as safe as they claim to be?

## Scammers Used ChatGPT to Unleash a Crypto Botnet on X
 - [https://www.wired.com/story/chat-gpt-crypto-botnet-scam/](https://www.wired.com/story/chat-gpt-crypto-botnet-scam/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-08-21T11:00:00+00:00

A botnet apparently connected to ChatGPT shows how easily, and effectively, artificial intelligence can be harnessed for disinformation.

