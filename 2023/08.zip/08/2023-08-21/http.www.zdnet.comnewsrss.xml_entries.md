# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## New 'BeFake' social media app encourages users to transform their photos with AI
 - [https://www.zdnet.com/article/new-befake-social-media-app-encourages-users-to-transform-their-photos-with-ai/#ftag=RSSbaffb68](https://www.zdnet.com/article/new-befake-social-media-app-encourages-users-to-transform-their-photos-with-ai/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T22:06:37+00:00

'Why be real when it's fun to BeFake?'

## Coros rolls out limited-edition Chamonix Apex 2 Pro, plus August 2023 update
 - [https://www.zdnet.com/article/coros-color-and-major-firmware-releases-focus-on-trail-running-and-navigation/#ftag=RSSbaffb68](https://www.zdnet.com/article/coros-color-and-major-firmware-releases-focus-on-trail-running-and-navigation/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T20:54:05+00:00

This major firmware release brings custom watch faces, turn-by-turn navigation, trail running workouts, and more.

## In a win for humans, federal judge rules that AI-generated artwork can't be copyrighted
 - [https://www.zdnet.com/article/in-a-win-for-humans-federal-judge-rules-that-ai-generated-artwork-cant-be-copyrighted/#ftag=RSSbaffb68](https://www.zdnet.com/article/in-a-win-for-humans-federal-judge-rules-that-ai-generated-artwork-cant-be-copyrighted/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T20:33:37+00:00

This isn't the first ruling of its kind, but it is a decided victory for artists in the battle against AI.

## Google Chrome 117 will let you know if you've installed malicious extensions
 - [https://www.zdnet.com/article/google-chrome-117-will-let-you-know-if-youve-installed-malicious-extensions/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-chrome-117-will-let-you-know-if-youve-installed-malicious-extensions/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T20:04:17+00:00

In the first half of 2022, 1.3 million users were affected by threats in browser extensions.

## This AI-generated crypto invoice scam almost got me, and I'm a security pro
 - [https://www.zdnet.com/article/this-ai-generated-crypto-invoice-scam-almost-got-me-and-im-a-security-pro/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-ai-generated-crypto-invoice-scam-almost-got-me-and-im-a-security-pro/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T19:33:43+00:00

Even a tech pro can fall for a well-laid phishing trap. Here's what happened to me - and how you can avoid a similar fate, too.

## The best parental control apps of 2023
 - [https://www.zdnet.com/article/best-parental-control-apps/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-parental-control-apps/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T19:17:14+00:00

ZDNET found the top parental control apps (including some free options) to help protect your children with location tracking, screen time limits, web filtering, and more.

## Buy a 6-in-1 charger for 43% off right now
 - [https://www.zdnet.com/article/buy-a-6-in-1-charger-for-43-off-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/article/buy-a-6-in-1-charger-for-43-off-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T19:14:22+00:00

Grab an InCharge X Max 100W 6-in-1 charging cable to charge almost any device quickly.

## PCLinuxOS used to be great for Linux newbies, but not anymore
 - [https://www.zdnet.com/article/pclinuxos-used-to-be-great-for-linux-newbies-but-not-anymore/#ftag=RSSbaffb68](https://www.zdnet.com/article/pclinuxos-used-to-be-great-for-linux-newbies-but-not-anymore/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T18:37:50+00:00

The experienced Linux user might find PCLinuxOS to be a breath of decades-old air that still serves its purpose and does it well.

## Debian Linux founder Ian Murdock would have been amazed at its legacy
 - [https://www.zdnet.com/article/debian-linux-founder-ian-murdock-would-have-been-amazed-at-its-legacy/#ftag=RSSbaffb68](https://www.zdnet.com/article/debian-linux-founder-ian-murdock-would-have-been-amazed-at-its-legacy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T18:16:42+00:00

Debian Linux is 30 years old. Today, it remains one of the most dominant Linux distributions. Here's how it started and where its impact is still felt today.

## This new Threads feature could bring back inactive users
 - [https://www.zdnet.com/article/this-new-threads-feature-could-bring-back-inactive-users/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-new-threads-feature-could-bring-back-inactive-users/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T17:57:33+00:00

Meta is working on a long-awaited feature to help rekindle the popularity of its latest social media app, Threads.

## SwitchBot's Curtain 3 robot to launch this week, and Curtain 2 is now 25% off
 - [https://www.zdnet.com/home-and-office/smart-home/switchbots-curtain-3-robot-to-launch-this-week-and-curtain-2-is-now-25-off/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/smart-home/switchbots-curtain-3-robot-to-launch-this-week-and-curtain-2-is-now-25-off/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T16:42:00+00:00

Want to automate your existing curtains? You can do just that with these gadgets.

## Buy a one-year Costco membership and get a free $30 gift card now
 - [https://www.zdnet.com/home-and-office/home-entertainment/buy-a-one-year-costco-membership-and-get-a-free-30-gift-card-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/buy-a-one-year-costco-membership-and-get-a-free-30-gift-card-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T16:29:25+00:00

A Costco membership can help you save money on groceries, electronics, gadgets, and more. This deal effectively gets you an annual Costco membership for 50% off.

## The best speakers for vinyl in 2023: Audioengine, Edifier, and more compared
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-speakers-for-vinyl/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-speakers-for-vinyl/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T16:22:49+00:00

The best speakers for vinyl have features like Bluetooth, customizable EQs, and remarkable sound quality.

## The best electric screwdrivers of 2023: Expert tested and reviewed
 - [https://www.zdnet.com/home-and-office/the-best-electric-screwdrivers-of-2023/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/the-best-electric-screwdrivers-of-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T15:51:55+00:00

The best electric screwdrivers can help make your DIY tasks faster and easier. ZDNET has tested some of the top options available to help you find the best option.

## The best electric screwdrivers of 2023: Expert tested and reviewed
 - [https://www.zdnet.com/home-and-office/best-electric-screwdriver/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-electric-screwdriver/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T15:51:00+00:00

The best electric screwdrivers can help make your DIY tasks faster and easier. ZDNET has tested some of the top options available to help you find the best option.

## The best Garmin watches of 2023: Expert tested and reviewed
 - [https://www.zdnet.com/article/best-garmin-watch/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-garmin-watch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T15:47:02+00:00

ZDNET tested the best Garmin watches to help you figure out which smartwatch is the right option for you.

## The best password managers of 2023
 - [https://www.zdnet.com/article/best-password-manager/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-password-manager/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T15:29:46+00:00

The best password managers keep your passwords safe and secure while allowing easier log-ins.

## How to enable Notification History on your Android (and why you should)
 - [https://www.zdnet.com/article/how-to-enable-notification-history-on-your-android-and-why-you-should/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-enable-notification-history-on-your-android-and-why-you-should/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T15:12:00+00:00

Do you find yourself frequently missing notifications on Android? Have you deleted notifications when you didn't mean to? This feature can help.

## You'll never guess how much this TCL TV costs by the looks of it
 - [https://www.zdnet.com/home-and-office/home-entertainment/youll-never-guess-how-much-this-tcl-tv-costs-by-the-looks-of-it/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/youll-never-guess-how-much-this-tcl-tv-costs-by-the-looks-of-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T14:56:00+00:00

The TCL Q7 gives you more bang for your buck than most mid-range sets, with impressive display quality and a brighter panel.

## I test hundreds of smartwatches, but this one's been on my wrist all year
 - [https://www.zdnet.com/article/i-test-hundreds-of-smartwatches-but-this-ones-been-on-my-wrist-all-year/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-test-hundreds-of-smartwatches-but-this-ones-been-on-my-wrist-all-year/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T14:51:00+00:00

Despite the release of several other flagship watches, the Garmin Enduro 2 remains one of the best for outdoor adventurists.

## The Pixel 8 camera app is getting a major overhaul
 - [https://www.zdnet.com/article/the-pixel-8-camera-app-is-getting-a-major-overhaul/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-pixel-8-camera-app-is-getting-a-major-overhaul/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T14:49:00+00:00

When the Pixel 8 is released, users will find the camera app UI isn't the same old app they're used to.

## This lightweight laptop is cheaper than a MacBook Air (and almost as good)
 - [https://www.zdnet.com/article/this-lightweight-laptop-is-cheaper-than-a-macbook-air-and-almost-as-good/#ftag=RSSbaffb68](https://www.zdnet.com/article/this-lightweight-laptop-is-cheaper-than-a-macbook-air-and-almost-as-good/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T14:20:00+00:00

Back to school shopping? The Asus Zenbook 14X has great performance, one of the best laptop displays at its price, and a slew of features.

## TikTok bans explained: Everything you need to know
 - [https://www.zdnet.com/article/tiktok-bans-explained-everything-you-need-to-know/#ftag=RSSbaffb68](https://www.zdnet.com/article/tiktok-bans-explained-everything-you-need-to-know/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T14:03:00+00:00

Federal and state governments and some universities banned TikTok. ZDNET gives you a catch up on the app's current status.

## Twitch adds a new block feature while X (aka Twitter) takes one away
 - [https://www.zdnet.com/article/twitch-adds-a-new-block-feature-while-x-aka-twitter-takes-it-away/#ftag=RSSbaffb68](https://www.zdnet.com/article/twitch-adds-a-new-block-feature-while-x-aka-twitter-takes-it-away/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T13:51:00+00:00

Here's what social media users should know about the changes coming to both platforms.

## Check your SSDs: What to know about the SanDisk/Western Digital data loss disaster
 - [https://www.zdnet.com/article/check-your-ssds-what-to-know-about-the-sandiskwestern-digital-data-loss-disaster/#ftag=RSSbaffb68](https://www.zdnet.com/article/check-your-ssds-what-to-know-about-the-sandiskwestern-digital-data-loss-disaster/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T13:28:45+00:00

If you use an SSD made by SanDisk or Western Digital, you need to check it now because you could be at risk of losing your data.

## How to add exceptions to ad blocking in Opera
 - [https://www.zdnet.com/article/how-to-add-exceptions-to-ad-blocking-in-opera/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-add-exceptions-to-ad-blocking-in-opera/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T12:46:00+00:00

Opera has one of the better ad blockers of all the web browsers, but some sites refuse to grant you access to content. To get around that issue, you must add ad blocker exceptions. Here's how.

## 4 things Claude AI can do that ChatGPT can't
 - [https://www.zdnet.com/article/4-things-claude-ai-can-do-that-chatgpt-cant/#ftag=RSSbaffb68](https://www.zdnet.com/article/4-things-claude-ai-can-do-that-chatgpt-cant/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T09:41:24+00:00

Here are the top reasons to choose Claude next time you reach for ChatGPT.

## Mark your calendar: Microsoft's fall event date is here
 - [https://www.zdnet.com/article/mark-your-calendar-microsofts-fall-event-date-is-here/#ftag=RSSbaffb68](https://www.zdnet.com/article/mark-your-calendar-microsofts-fall-event-date-is-here/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-08-21T07:33:46+00:00

Microsoft's fall "special event" date has been announced. Here's what we expect to see, including new Surface products.

