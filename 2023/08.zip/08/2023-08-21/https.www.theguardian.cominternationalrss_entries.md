# Source:The Guardian - International, URL:https://www.theguardian.com/international/rss, language:en-US

## Ødegaard edges Arsenal to win at Crystal Palace despite Tomiyasu red
 - [https://www.theguardian.com/football/2023/aug/21/crystal-palace-arsenal-premier-league-match-report](https://www.theguardian.com/football/2023/aug/21/crystal-palace-arsenal-premier-league-match-report)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T21:00:52+00:00

<p>This was a scrap and, having squeaked through it, Arsenal will not mind at all. They did so thanks to a penalty from Martin Ødegaard eight minutes into the second half and may reflect that, while a refashioned side looks short of last season’s brilliance at this early stage in the term, they merited the points on the balance of chances. Nonetheless Roy Hodgson’s Crystal Palace offered a typically challenging workout and were encouraged during the final quarter when Takehiro Tomiyasu was dismissed after picking up two needless bookings. That will have infuriated Mikel Arteta but a side that, by the end, was packed with defenders held out with relative confidence against hosts bereft of cutting edge.</p><p>In May 2021 Hodgson had bidden an emotional farewell to a Covid-restricted crowd here <a href="https://www.theguardian.com/football/2021/may/19/crystal-palace-arsenal-premier-league-match-report" title="">after a 3-1 defeat to Arsenal</a>, his retirement seemingly a certainty. If the size and volume of the crowd had swelled, red and blue flares billowing from the Holmesdale Road end at kick-off, the sight of the 76-year-old patrolling his technical area offered a constant few could have expected back then.</p> <a href="https://www.theguardian.com/football/2023/aug/21/crystal-palace-arsenal-premier-league-match-report">Continue reading...</a>

## What role did the climate crisis play in Storm Hilary – and could there be more like it?
 - [https://www.theguardian.com/us-news/2023/aug/21/california-hilary-storm-climate-crisis-explainer](https://www.theguardian.com/us-news/2023/aug/21/california-hilary-storm-climate-crisis-explainer)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T20:42:05+00:00

<p>Such storms landing on California are extremely rare – but experts say they could become more common as the ocean heats up</p><p>As Storm Hilary continues to batter California and the US south-west, questions loom about what role the climate crisis played in supercharging the storm and whether there could be more like it in the future.</p><p>After a year of weather extremes in California and the US west – including record-breaking winter rain and snowfall and punishing summer heatwaves – the tropical cyclone’s appearance in the region remains extraordinary.</p> <a href="https://www.theguardian.com/us-news/2023/aug/21/california-hilary-storm-climate-crisis-explainer">Continue reading...</a>

## Vivek Ramaswamy condemned for 9/11 and Jan 6 conspiracy theory remarks
 - [https://www.theguardian.com/us-news/2023/aug/21/vivek-ramaswamy-conspiracy-theories-9-11-jan-6-republican-presidential-candidate](https://www.theguardian.com/us-news/2023/aug/21/vivek-ramaswamy-conspiracy-theories-9-11-jan-6-republican-presidential-candidate)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T20:26:38+00:00

<p>Republican presidential contender hints at government involvement in deadly September 11 attacks</p><p>The biotech entrepreneur Vivek Ramaswamy, a contender for the Republican presidential nomination, was condemned for conspiracy-tinged remarks about the events of 9/11 and the January 6 attack on the Capitol.</p><p>“I think it is legitimate to say how many police, how many federal agents, were on the planes that hit the Twin Towers,” Ramaswamy said, in a profile published <a href="https://www.theatlantic.com/politics/archive/2023/08/vivek-ramaswamy-gop-election/675041/">by the Atlantic</a> on Monday.</p> <a href="https://www.theguardian.com/us-news/2023/aug/21/vivek-ramaswamy-conspiracy-theories-9-11-jan-6-republican-presidential-candidate">Continue reading...</a>

## Inside Low Newton: the high security prison that will house Lucy Letby
 - [https://www.theguardian.com/uk-news/2023/aug/21/inside-low-newton-the-high-security-prison-that-is-housing-lucy-letby](https://www.theguardian.com/uk-news/2023/aug/21/inside-low-newton-the-high-security-prison-that-is-housing-lucy-letby)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T19:25:20+00:00

<p> Durham facility is regarded as safe by inspectors and houses Joanna Dennehy, who also received a whole life order</p><p>The high-security prison where Lucy Letby will spend the rest of her life also houses some of Britain’s most high-profile criminals.</p><p>Letby, 33, is reportedly being sent to HMP Low Newton in Durham to serve the whole-life order that <a href="https://www.theguardian.com/uk-news/2023/aug/21/lucy-letby-sentence-whole-life-jail-term-for-murdering-seven-babies">she received on Monday</a> for murdering seven <a href="https://www.theguardian.com/uk-news/2023/aug/18/lucy-letby-trial-why-babies-remain-anonymous">babies</a> and attempting to murder six others.</p> <a href="https://www.theguardian.com/uk-news/2023/aug/21/inside-low-newton-the-high-security-prison-that-is-housing-lucy-letby">Continue reading...</a>

## Crystal Palace v Arsenal: Premier League – live
 - [https://www.theguardian.com/football/live/2023/aug/21/crystal-palace-v-arsenal-premier-league-live](https://www.theguardian.com/football/live/2023/aug/21/crystal-palace-v-arsenal-premier-league-live)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T18:05:09+00:00

<ul><li>Premier League news from the 8pm BST game at Selhurst Park</li><li><a href="https://www.theguardian.com/football/2023/aug/21/chelsea-west-ham-caicedo-premier-league">Soccer with Jonathan Wilson: a new weekly USA-based newsletter</a></li><li>Get in touch! <a href="mailto:scott.murray@theguardian.com">Send Scott an email</a> with your match thoughts</li></ul><p><strong>No changes for Crystal Palace.</strong> Roy Hodgson names the same starting XI that ran out 1-0 winners at Sheffield United on the opening day of the season.</p><p><strong>Arsenal make just one change from their opening-day 2-1 victory over Nottingham Forest.</strong> Takehiro Tomiyasu comes in at right back, replacing the injury-stricken Jurrien Timber.</p> <a href="https://www.theguardian.com/football/live/2023/aug/21/crystal-palace-v-arsenal-premier-league-live">Continue reading...</a>

## Brics group looks to expand at summit despite divisions among key members
 - [https://www.theguardian.com/world/2023/aug/21/brics-looks-to-expand-bloc-south-africa-summit-divisions-key-members-india](https://www.theguardian.com/world/2023/aug/21/brics-looks-to-expand-bloc-south-africa-summit-divisions-key-members-india)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T18:01:53+00:00

<p>Experts say India concerned about expansion and any overt anti-west turn as leaders fly into South Africa</p><p>Leaders from developing countries representing almost half the world’s population including China and Russia are to meet in South Africa for a key summit aimed at reinforcing their alliance as a counterweight to the west.</p><p>The Brics grouping summit in Johannesburg, which starts on Tuesday, will be hosted by the South African president, Cyril Ramaphosa, and brings together the prime minister of India, Narendra Modi, as well the presidents of China, Xi Jinping, and Brazil, Luiz Inácio Lula da Silva.</p> <a href="https://www.theguardian.com/world/2023/aug/21/brics-looks-to-expand-bloc-south-africa-summit-divisions-key-members-india">Continue reading...</a>

## Spanish FA chief admits kiss ‘somewhat tarnished’ Women’s World Cup win
 - [https://www.theguardian.com/world/2023/aug/21/spanish-fa-chief-admits-kiss-somewhat-tarnished-womens-world-cup-win](https://www.theguardian.com/world/2023/aug/21/spanish-fa-chief-admits-kiss-somewhat-tarnished-womens-world-cup-win)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T17:01:24+00:00

<p>Luis Rubiales strikes more conciliatory note after previously defending his kissing on lips of forward Jenni Hermoso</p><p>It was a triumphant moment across Spain and around the world, a precedent-setting show of talent that offered a tantalising preview of what lies ahead for women’s football. But the day after Spain’s women won the World Cup, it was the country’s football chief – a 45-year-old man – dominating domestic headlines.</p><p>The rumbling started soon after <a href="https://www.theguardian.com/football/2023/aug/20/womens-world-cup-final-news-spain-england">Spain’s 1-0 victory over England</a> in the final in Sydney on Sunday night. As the Spanish team collected their gold medals, Luis Rubiales, the president of the Spanish football federation, grabbed the forward Jenni Hermoso by the head, pulling her towards him and planting a kiss on her lips.</p> <a href="https://www.theguardian.com/world/2023/aug/21/spanish-fa-chief-admits-kiss-somewhat-tarnished-womens-world-cup-win">Continue reading...</a>

## The Future Tense review – film-makers’ complex reverie of English and Irish identities
 - [https://www.theguardian.com/film/2023/aug/21/the-future-tense-review-film-makers-complex-reverie-of-english-and-irish-identities](https://www.theguardian.com/film/2023/aug/21/the-future-tense-review-film-makers-complex-reverie-of-english-and-irish-identities)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T08:00:11+00:00

<p>Semi-dramatised essay film by Joe Lawlor and Christine Molloy explores complicated national loyalties alongside those of an extraordinary rebel</p><p>The intriguing, complex movies of the married writer-directors <a href="https://www.theguardian.com/film/2021/sep/14/predator-father-icy-thriller-child-of-rape-metoo-aidan-gillan">Joe Lawlor and Christine Molloy</a> have always been about imposture, concealment, double lives and alternative existences – particularly in what I think may be their masterpiece, the drama-thriller <a href="https://www.theguardian.com/film/2019/oct/04/rose-plays-julie-review-christine-molloy-joe-lawlor">Rose Plays Julie</a>. Now they have composed this fiercely personal essay movie about themselves and their family histories, loosely structured around the idea of a plane journey between London and Dublin. Lawlor and Molloy are shown separately narrating into microphones, and “interviewing” people filmed in separate locations, a conceit apparently imposed during lockdown.</p><p>It is a semi-dramatised reverie and revelation which exposes a painful new insight into their experiences as Irish expatriate artists in the UK; they are considering a return to Ireland now that post-Brexit England seems increasingly reactionary and xenophobic, while also being aware of the reactionary forces at work in Irish politics. They are also aware that their daughter, having been brought up in England, may not wish to join them. Have they also been concealing double lives as Irish people in England?</p> <a href="https://www.theguardian.com/film/2023/aug/21/the-future-tense-review-film-makers-complex-reverie-of-english-and-irish-identities">Continue reading...</a>

## HS2 and waiting for your luggage: Edith Pritchett’s week in Venn diagrams – cartoon
 - [https://www.theguardian.com/lifeandstyle/ng-interactive/2023/aug/21/hs2-and-waiting-for-your-luggage-edith-pritchetts-week-in-venn-diagrams-cartoon](https://www.theguardian.com/lifeandstyle/ng-interactive/2023/aug/21/hs2-and-waiting-for-your-luggage-edith-pritchetts-week-in-venn-diagrams-cartoon)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T05:00:08+00:00

<a href="https://www.theguardian.com/lifeandstyle/ng-interactive/2023/aug/21/hs2-and-waiting-for-your-luggage-edith-pritchetts-week-in-venn-diagrams-cartoon">Continue reading...</a>

## "I've never seen anything like this": Tropical Storm Hilary brings deluge to desert – video
 - [https://www.theguardian.com/world/video/2023/aug/21/ive-never-seen-anything-like-this-tropical-storm-hilary-brings-deluge-to-desert-video](https://www.theguardian.com/world/video/2023/aug/21/ive-never-seen-anything-like-this-tropical-storm-hilary-brings-deluge-to-desert-video)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T03:57:26+00:00

<p>In the desert town of Rancho Mirage, close to Palm Springs, a city that typically gets around 4.6 inches (12 cm) of rain in an entire year could receive 6-10 inches from this one storm. "It's quite amazing. I've never seen anything like this. And the tropical storm hasn't even hit us yet," said one resident.</p><ul><li><p><a href="https://www.theguardian.com/us-news/live/2023/aug/21/tropical-storm-hilary-california-flooding-tornado-warning-national-hurricane-center">Hilary live updates</a></p></li></ul><p></p> <a href="https://www.theguardian.com/world/video/2023/aug/21/ive-never-seen-anything-like-this-tropical-storm-hilary-brings-deluge-to-desert-video">Continue reading...</a>

## Albanese’s storytelling on the Australia-India relationship is not quite the whole tale | Daniel Flitton
 - [https://www.theguardian.com/commentisfree/2023/aug/21/anthony-albanese-narendra-modi-australia-india-relationship-home-truths](https://www.theguardian.com/commentisfree/2023/aug/21/anthony-albanese-narendra-modi-australia-india-relationship-home-truths)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T02:22:43+00:00

<p>Australian foreign policy faces challenge of the home truths of Narendra Modi’s administration – and Albanese needs to go beyond ‘the boss’ narrative</p><p>Anthony Albanese tells a great little story about going to India as a leading member of parliament a few years ago and how he sent the local Australian diplomats into a minor frenzy.</p><p>Facing a meticulously planned program of meetings and handshakes, Albanese gave officials the slip.</p> <a href="https://www.theguardian.com/commentisfree/2023/aug/21/anthony-albanese-narendra-modi-australia-india-relationship-home-truths">Continue reading...</a>

## Spanish football president’s kiss sparks outrage after Women’s World Cup final
 - [https://www.theguardian.com/football/2023/aug/21/luis-rubiales-kiss-outrage-spanish-football-fa-president-womens-world-cup-final-spain-jenni-hermoso](https://www.theguardian.com/football/2023/aug/21/luis-rubiales-kiss-outrage-spanish-football-fa-president-womens-world-cup-final-spain-jenni-hermoso)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T01:51:36+00:00

<p>Luis Rubiales rejects suggestions kissing forward Jenni Hermoso on the lips during the post-match ceremony was inappropriate</p><p>The president of the Spanish football federation, Luis Rubiales, has come in for criticism after he kissed forward Jenni Hermoso on the lips following Spain’s 1-0 victory over England in the World Cup final in Sydney on Sunday night.</p><p>The kiss – delivered on stage during the official post-match ceremony – was captured on camera and the vision prompted outrage on social media.</p> <a href="https://www.theguardian.com/football/2023/aug/21/luis-rubiales-kiss-outrage-spanish-football-fa-president-womens-world-cup-final-spain-jenni-hermoso">Continue reading...</a>

## Qantas faces class action over pandemic travel credits treated as ‘$1bn in interest-free loans’
 - [https://www.theguardian.com/business/2023/aug/21/qantas-faces-class-action-over-pandemic-travel-credits-treated-as-1bn-in-interest-free-loans](https://www.theguardian.com/business/2023/aug/21/qantas-faces-class-action-over-pandemic-travel-credits-treated-as-1bn-in-interest-free-loans)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T00:53:40+00:00

<p>Proceedings against airline ‘on behalf of hundreds of thousands’ of customers aims to force refunds for flight credits and compensation due to lost interest</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/aug/21/australia-news-live-offshore-wind-clean-energy-indigenous-voice-to-parliament-anthony-albanese-womens-world-cup-soccer-spain-lionesses-matildas">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Qantas is facing a class action lawsuit over its refund policy for flights cancelled due to the pandemic, with lawyers alleging the airline’s use of travel credits allowed them to treat their customers’ money as more than “$1bn in interest-free loans”.</p><p>On Monday, class action firm Echo Law announced it had lodged proceedings against Qantas in the federal court “on behalf of hundreds of thousands” of pandemic-affected travellers with an aim of forcing refunds for all remaining flights credits and compensation due to lost interest on customers’ money held by Qantas.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/business/2023/aug/21/qantas-faces-class-action-over-pandemic-travel-credits-treated-as-1bn-in-interest-free-loans">Continue reading...</a>

## Canada wildfires: Trudeau deploys military to tackle blazes across British Columbia
 - [https://www.theguardian.com/world/2023/aug/21/canada-wildfires-trudeau-deploys-military-to-tackle-blazes-across-british-columbia](https://www.theguardian.com/world/2023/aug/21/canada-wildfires-trudeau-deploys-military-to-tackle-blazes-across-british-columbia)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-08-21T00:14:13+00:00

<p>More than 35,000 residents under evacuation orders across province, while flames are being held at bay 15km from Yellowknife in Northwest Territories</p><p>Canada will send in armed forces to tackle fast-spreading wildfires in British Columbia, prime minister Justin Trudeau has said, as more than 35,000 people were put under evacuation orders in the western province.</p><p>British Columbia imposed a state of emergency late on Friday, giving officials more power to deal with fire risks. The main fire was centered around Kelowna, a city 300km (180 miles) east of Vancouver with a population of about 150,000.</p> <a href="https://www.theguardian.com/world/2023/aug/21/canada-wildfires-trudeau-deploys-military-to-tackle-blazes-across-british-columbia">Continue reading...</a>

