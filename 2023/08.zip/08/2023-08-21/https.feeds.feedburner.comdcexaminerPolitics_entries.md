# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## 'Watch out for young people!': Bill Nye encourages young voters to ask candidates about climate change
 - [https://www.washingtonexaminer.com/news/bill-nye-young-voters-ask-climate-change](https://www.washingtonexaminer.com/news/bill-nye-young-voters-ask-climate-change)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-08-21T22:14:18+00:00

Celebrity Bill Nye has encouraged younger voters to ask 2024 presidential candidates what they will do about climate change.

