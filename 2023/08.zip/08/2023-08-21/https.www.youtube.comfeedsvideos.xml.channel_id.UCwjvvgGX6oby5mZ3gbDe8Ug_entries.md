# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## China's banks at risk. Explosions with thought-provoking underlying reasons
 - [https://www.youtube.com/watch?v=agQHS7ob9Us](https://www.youtube.com/watch?v=agQHS7ob9Us)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-08-21T16:41:15+00:00

#Chinainsights#Chinanews
On August 13, 2023, an explosion erupted in Shandong Province. A bank and a barbecue fish restaurant were blown up and seriously damaged. The glass and facade of the 2-story building are gone, and the ground was covered in debris. 

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

