# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## This Man Loves Both Trump And Biden!
 - [https://www.youtube.com/watch?v=mzYb2N6J60g](https://www.youtube.com/watch?v=mzYb2N6J60g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2023-08-21T17:22:23+00:00

Polls show most Americans don’t like either of the likely 2024 presidential nominees, but we found the one man in the country who absolutely loves both Trump and Biden.

#trump #biden

