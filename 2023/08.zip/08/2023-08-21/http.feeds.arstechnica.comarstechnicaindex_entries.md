# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Political polarization toned down through anonymous online chats
 - [https://arstechnica.com/?p=1962109](https://arstechnica.com/?p=1962109)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T23:11:53+00:00

Republicans seem to depolarize more than Democrats.

## Vlad the Impaler may have shed tears of blood, study finds
 - [https://arstechnica.com/?p=1961945](https://arstechnica.com/?p=1961945)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T21:58:15+00:00

Letter from 1475 contains proteins suggesting he suffered from hemolacria, respiratory problems.

## Chris Kemp unplugged—Astra’s CEO dishes on the space company’s struggles
 - [https://arstechnica.com/?p=1962049](https://arstechnica.com/?p=1962049)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T21:31:02+00:00

"I’m a public company, I can’t make this shit up."

## BA.2.86 shows just how risky slacking off on COVID monitoring is
 - [https://arstechnica.com/?p=1962066](https://arstechnica.com/?p=1962066)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T20:17:10+00:00

The variant has grabbed attention, but with such limited data, the risk is unclear.

## China keeps buying hobbled Nvidia cards to train its AI models
 - [https://arstechnica.com/?p=1962036](https://arstechnica.com/?p=1962036)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T17:58:41+00:00

Nvidia’s weakened processors are still more powerful than the alternatives.

## US judge: Art created solely by artificial intelligence cannot be copyrighted
 - [https://arstechnica.com/?p=1962023](https://arstechnica.com/?p=1962023)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T17:37:41+00:00

"US copyright law protects only works of human creation," judge writes.

## The failure of Luna 25 cements Putin’s role as a disastrous space leader
 - [https://arstechnica.com/?p=1961951](https://arstechnica.com/?p=1961951)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T16:45:50+00:00

"There is no place for modernization, there is only the mission of survival."

## Ford’s recall of Mustang Mach-Es in 2022 is under investigation by feds
 - [https://arstechnica.com/?p=1961985](https://arstechnica.com/?p=1961985)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T15:34:13+00:00

There have been 12 complaints of power loss following the software update.

## It’s-a-no-longer me: Charles Martinet steps down as Mario’s voice [Updated]
 - [https://arstechnica.com/?p=1961983](https://arstechnica.com/?p=1961983)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T15:24:21+00:00

After three decades in the role, Martinet won't appear in <em>Super Mario Wonder</em>.

## Roblox facilitates “illegal gambling” for minors, according to new lawsuit
 - [https://arstechnica.com/?p=1961958](https://arstechnica.com/?p=1961958)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T12:41:28+00:00

Third-party sites use Robux transfers to power millions of dollars in wagers.

## Windows 11 has made the “clean Windows install” an oxymoron
 - [https://arstechnica.com/?p=1950522](https://arstechnica.com/?p=1950522)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-08-21T11:00:46+00:00

Op-ed: PC makers used to need to bring their own add-on bloatware—no longer.

