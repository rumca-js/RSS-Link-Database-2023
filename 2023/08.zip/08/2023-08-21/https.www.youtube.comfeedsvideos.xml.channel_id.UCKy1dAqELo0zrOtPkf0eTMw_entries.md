# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Blue Beetle Barely Beats Barbie at Box Office - IGN The Fix: Entertainment
 - [https://www.youtube.com/watch?v=-OUmx9E0jNU](https://www.youtube.com/watch?v=-OUmx9E0jNU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T23:53:24+00:00

In today’s Entertainment Fix: Blue Beetle dethrones Barbie after its historic five-week box office run, but as the last movie produced prior before James Gunn and Peter Safran’s true DCU kickstarter - Superman: Legacy - its low performance compared to other DCEU movies has it feeling like a bittersweet victory. That, plus The Last of Us showrunner Craig Mazin teases the live-action HBO series found its Abby before the ongoing SAG-AFTRA strike. And in other DC news, The Flash has a streaming date on Max.

#IGN

## Cult of the Lamb x Don't Starve Together - Official Collaboration Update Launch Trailer
 - [https://www.youtube.com/watch?v=C0TcCIoG10A](https://www.youtube.com/watch?v=C0TcCIoG10A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T22:00:06+00:00

Check out the trailer for the Cult of the Lamb x Don't Starve Together collaboration, which brings a new crossover event, available today, August 21, for both games. Cult of the Lamb will receive new decorations from the world of Don't Starve Together, as well as a new Penitence game mode in which the Lamb will need to eat and sleep to survive, along with their followers. However, a unique Webber follower form has broken free from mortal constraints and will never die of starvation.

In Don’t Starve Together, a Cult of the Lamb crown trinket can be found in the Oasis. The crown can be given as a tribute to the Antlion, which will reward players with blueprints to craft a Tabernacle base decoration, speed-boosting Brick Flooring and fancy new Gold Flooring. Additionally, a limited-time login bonus will grant players a free item and pet skins to bring the Lamb and their gear to their next world.

## Fight Crab 2 - Official Reveal Trailer | PLAYISM Game Show 2023
 - [https://www.youtube.com/watch?v=izlba12DlSw](https://www.youtube.com/watch?v=izlba12DlSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T20:00:21+00:00

Fight Crab 2 is a PvP action wrestling fighting game developed by Calappa Games. Players will need to use strategy and the ability to wield the game’s physics to their advantage. Battle it out with your friends in online multiplayer or challenge deadly foes in Career Mode. Fight Crab 2 is launching on Steam Early Access this winter.

## Endless Dungeon - Official Closed Beta Trailer
 - [https://www.youtube.com/watch?v=OkUSqqgRops](https://www.youtube.com/watch?v=OkUSqqgRops)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T19:00:09+00:00

Get another look at Endless Dungeon in this latest trailer for the upcoming rogue-lite tactical action game. The Closed beta for Endless Dungeon will be available from September 7 to September 18, 2023 with pre-orders of the game's Last Wish edition on PC.

## Naruto X Boruto Ultimate Ninja Storm Connections - Official Release Date Trailer
 - [https://www.youtube.com/watch?v=U-sN5pMxd1o](https://www.youtube.com/watch?v=U-sN5pMxd1o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T18:00:21+00:00

Naruto X Boruto Ultimate Ninja Storm Connections will be available on PlayStation 5, PlayStation 4, Xbox Series X/S, Xbox One, and Nintendo Switch on November 17, 2023, with a Steam release date to be announced. Check out the latest trailer for Naruto X Boruto Ultimate Ninja Storm Connections to see the new STORM series fighters--Delta, Boro, and Koji Kashin--in action.

## Top 7 Things You Need to Know About Final Fantasy VII Ever Crisis
 - [https://www.youtube.com/watch?v=YFHGA1YpJ0M](https://www.youtube.com/watch?v=YFHGA1YpJ0M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T17:00:30+00:00

Final Fantasy VII Ever Crisis is an upcoming RPG that includes a playable new story that revolves around a young Sephiroth. The fledgling world-famous antagonist brings a new point of view on classic moments in Final Fantasy VII's story. 

Sephiroth's story in FF7 EVER CRISIS is called "Final Fantasy VII The First SOLDIER," and it's a brand-new adventure that features three SOLDIERs named Glenn, Matt, and Lucia.  You'll also get the chance to gain a new perspective on Zack Fair from Crisis Core: Final Fantasy VII. But there's far more to Final Fantasy VII Ever Crisis than re-visiting the past. Here's the top 7 things you need to know.

For more info, check out https://en-ffviiec.onelink.me/DNRq/vet1hnut!
Advertisement by SQUARE ENIX

#FinalFantasyVIIEverCrisis #FinalFantasy7EverCrisis

## Lords of the Fallen: 8 Combat Tips from the Developers – IGN First
 - [https://www.youtube.com/watch?v=6N29FQJrcGU](https://www.youtube.com/watch?v=6N29FQJrcGU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T16:00:06+00:00

The developers of the upcoming next-gen soulslike Lords of the Fallen have passed along eight combat tips to help you survive the upcoming action-RPG. Lords of the Fallen will be released for PC, PS5, and Xbox Series X|S on October 13.

#LordsOfTheFallen #IGNFirst

## Retribution: Exclusive Clip (2023) Liam Neeson, Matthew Modine
 - [https://www.youtube.com/watch?v=-4isM4cOvs0](https://www.youtube.com/watch?v=-4isM4cOvs0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T15:00:00+00:00

Liam Neeson stars in Retribution, an immersive ticking-clock thriller that straps audiences in for a high-octane ride of redemption and revenge. When a mysterious caller puts a bomb under his car seat, Matt Turner (Neeson) begins a high-speed chase across the city to complete a specific series of tasks.

With his kids trapped in the back seat and a bomb that will explode if they get out of the car, a normal commute becomes a twisted game of life or death as Matt follows the stranger’s increasingly dangerous instructions in a race against time to save his family.

Directed by Nimrod Antal (Predators), the film also stars Matthew Modine, Noma Dumezweni, Jack Champion, Lilly Aspell, and Embeth Davidtz.

Lionsgate & Roadside Attractions' Retribution opens in theaters on August 25.

#Retribution #LiamNesson

## The Invincible - Official Release Date Reveal Trailer
 - [https://www.youtube.com/watch?v=9-KvfzwdAqw](https://www.youtube.com/watch?v=9-KvfzwdAqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T14:48:57+00:00

The Invincible will be available on PC, PlayStation 5, and Xbox Series X/S on November 6, 2023. Watch The Invincible's release date trailer for a peek at the mystery that awaits in this upcoming hard sci-fi game.

The Invincible puts you in the role of Yasna, a sharp-tongued astrobiologist forced to search for her crew and bring them back “dead or alive” as a perilous mission to the eerie planet Regis III takes an awry turn. On the surface, it may seem that Regis III is uninhabited but that doesn't mean the people who visit here can feel like unopposed rulers. The philosophical nature of the events on Regis III will make Yasna forever question the scale of humankind's ambitions.

#TheInvincible #ReleaseDate

## The Creator: Behind the Scenes Featurette (2023) John David Washington, Gemma Chan, Ken Watanabe
 - [https://www.youtube.com/watch?v=-VZil1HyoxQ](https://www.youtube.com/watch?v=-VZil1HyoxQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T14:00:00+00:00

In this behind the scenes featurette for the upcoming film The Creator, filmmaker Gareth Edwards (Godzilla, Rogue One: A Star Wars Story) and the film's stars discuss the original sci-fi epic.  John David Washington, Gemma Chan, Ken Watanabe, Sturgill Simpson, Madeleine Yuna Voyles, and Allison Janney star in the film.

Here's the official synopsis of The Creator: Amidst a future war between the human race and the forces of artificial intelligence, Joshua (Washington), a hardened ex-special forces agent grieving the disappearance of his wife (Chan), is recruited to hunt down and kill the Creator, the elusive architect of advanced AI who has developed a mysterious weapon with the power to end the war… and mankind itself.  Joshua and his team of elite operatives journey across enemy lines, into the dark heart of AI-occupied territory… only to discover the world-ending weapon he’s been instructed to destroy is an AI in the form of a young child.

#TheCreator #BehindTheScenes

## Ghostrunner 2 - Official Release Date Trailer
 - [https://www.youtube.com/watch?v=ahtQsw53Ets](https://www.youtube.com/watch?v=ahtQsw53Ets)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T13:35:44+00:00

Ghostrunner 2 will be available on PC, PlayStation 5, Xbox Series X/S, and PC (Steam, Epic, and GOG) on October 26, 2023. Watch the latest trailer for another look at this upcoming first-person cyberpunk-action thriller sequel to see enemies, battles, the new high-powered motorcycle, and vehicular combat.

#Ghostrunner2 #ReleaseDate

## TMNT: Shredder's Revenge - Dimension Shellshock - Karai and Usagi Gameplay
 - [https://www.youtube.com/watch?v=AIHLZTg_MNE](https://www.youtube.com/watch?v=AIHLZTg_MNE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T13:00:06+00:00

Tribute Games narrative designer Yannick Belzil, game designer Frederic Gemus, and publishing/marketing manager Eric Lafontaine introduce you to new gameplay of Karai and Usagi, the new player characters being added to TMNT: Shredder's Revenge as part of the Dimension Shellshock DLC that arrives on August 31.

#TMNTShreddersRevenge #DimensionShellshock #Karai #Usagi

## Menace - Official Announcement Trailer
 - [https://www.youtube.com/watch?v=bObrLMisJ-E](https://www.youtube.com/watch?v=bObrLMisJ-E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T12:00:25+00:00

Lead a strike force against numerous threats and restore order in the far reaches of space in Menace. Check out the announcement trailer to see the sci-fi world and combat from this upcoming tactical RPG. Pick your allegiances and travel from planet to planet, fielding infantry, tanks, and mechs to answer distress calls and engage in intense turn-based battles. Cut off from the core worlds, help isn’t coming but neither is oversight or repercussions. 

Menace will be coming to early access for PC via Steam and the Epic Games Store in 2024.

#Menace #TacticalRPG

## Playing Metal Gear Solid Master Collection Vol. 1 on Switch Left Us With More Questions
 - [https://www.youtube.com/watch?v=sJmAaCH5_Wg](https://www.youtube.com/watch?v=sJmAaCH5_Wg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T07:01:00+00:00

The Metal Gear Solid Master Collection Vol. 1 is a superb set of the best Metal Gear games ever made. After getting extensive hands-on time with the Switch version of the collection, we walked away impressed. While we're happy the Metal Gear games are headed to modern consoles and PC, a few questions linger about the final version.

#MetalGearSolid #MetalGearSolidMasterCollectionVol1 #Preview

## 18 Minutes of Metal Gear Solid Gameplay - Metal Gear Solid Master Collection Vol. 1
 - [https://www.youtube.com/watch?v=yb63DlobVVw](https://www.youtube.com/watch?v=yb63DlobVVw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T07:00:32+00:00

These opening minutes of Metal Gear Solid Gameplay are from the Nintendo Switch version of Metal Gear Solid Master Collection Vol. 1. This game comes with a ton of extras and it is the first time Metal Gear Solid arrives on the Switch.

#MGS1 #MetalGearSolidMasterCollectionVol1 #MetalGearSolid #MetalGearSolid1 #NintendoSwitch

## 4 Minutes of Metal Gear Solid 2 Gameplay - Metal Gear Solid Master Collection Vol. 1
 - [https://www.youtube.com/watch?v=GLYBJRJWA_g](https://www.youtube.com/watch?v=GLYBJRJWA_g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T07:00:06+00:00

Metal Gear Solid 2: Sons of Liberty is one of the core entries into the Metal Gear series. These opening moments from the Tanker Mission, are captured on the Nintendo Switch version of The Metal Gear Solid Master Collection Vol. 1. While this Metal Gear Solid 2 Gameplay is mostly cutscenes from the opening of the game, we thought we'd share what we were able to capture after spending a bit too much time with Metal Gear Solid 3: Snake Eater and the superb Metal Gear Solid that is included in this collection.

#MGS2 #MetalGearSolidMasterCollectionVol1 #MetalGearSolid2 #MetalGearSolid #NintendoSwitch

## 17 Minutes of Metal Gear Solid 3 Gameplay - Metal Gear Solid Master Collection Vol. 1
 - [https://www.youtube.com/watch?v=D10VRI0SAJg](https://www.youtube.com/watch?v=D10VRI0SAJg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-08-21T07:00:04+00:00

These first 17 Minutes of Metal Gear Solid 3 Gameplay are captured on the Nintendo Switch. Join Snake as he recovers his items in the jungle and explores the location in an attempt to stop the Shagohod.

#MGS3 #MetalGearSolidMasterCollectionVol1 #MetalGearSolid #MetalGearSolid3 #NintendoSwitch

