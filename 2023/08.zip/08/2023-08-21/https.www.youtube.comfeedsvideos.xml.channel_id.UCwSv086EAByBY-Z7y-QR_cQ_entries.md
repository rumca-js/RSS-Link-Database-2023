# Source:Uszi, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ, language:pl-PL

## Dlaczego auta dla Sił Zbrojnych Ukrainy stoją na placu w centrum Lwowa?
 - [https://www.youtube.com/watch?v=qyav_ZYpom4](https://www.youtube.com/watch?v=qyav_ZYpom4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwSv086EAByBY-Z7y-QR_cQ
 - date published: 2023-08-21T17:04:22+00:00

linki ok 21, przepraszam, musze jechać po zakupy 🥸

