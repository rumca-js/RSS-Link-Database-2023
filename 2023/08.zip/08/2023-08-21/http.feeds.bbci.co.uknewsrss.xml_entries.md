# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Katty Kay: Why bad news is good news for Trump - for now
 - [https://www.bbc.co.uk/news/world-us-canada-66574268?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66574268?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:52:37+00:00

It's not politics as usual for Biden and Trump going into the 2024 US presidential election.

## Brics summit: How China's and Russia's clout is growing in Africa
 - [https://www.bbc.co.uk/news/world-africa-66562999?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-66562999?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:39:50+00:00

China's and Russia's clout is increasing in Africa, as resentment builds towards Western nations.

## I'm not back, I'm better - Richardson's statement win
 - [https://www.bbc.co.uk/sport/athletics/66569252?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/66569252?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:30:17+00:00

Sha'Carri Richardson announces herself on the global stage by beating a star-studded 100m line-up to win world gold in Budapest.

## This baby giraffe born with no spots is incredibly rare
 - [https://www.bbc.co.uk/news/world-us-canada-66551290?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66551290?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:27:49+00:00

The spotless giraffe was born at a zoo in Tennessee and could be the only one of her kind on Earth.

## The Patch: BBC radio show's postcode lottery unearths stories in random places
 - [https://www.bbc.co.uk/news/entertainment-arts-66569001?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66569001?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:10:22+00:00

A random postcode generator decides where Polly Weston must go for her BBC Radio 4 series The Patch.

## Conservation: Lifeline for endangered insect feared extinct
 - [https://www.bbc.co.uk/news/science-environment-66531535?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-66531535?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:08:20+00:00

The tiny insect, the scarce yellow sally, is bred in a zoo, raising hopes for saving the species.

## Can narrowboat owners break with fossil fuels?
 - [https://www.bbc.co.uk/news/business-66370302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66370302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:07:30+00:00

Narrowboat owners are under pressure to find greener ways to run their craft.

## Russian mercenary leader 'posts video from Africa'
 - [https://www.bbc.co.uk/news/world-europe-66576990?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66576990?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:06:24+00:00

The clip suggests Prigozhin is in Africa, where Wagner is thought to have thousands of fighters.

## Lost luggage showing signs of recovery after hitting 10-year high
 - [https://www.bbc.co.uk/news/business-66438234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66438234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:05:13+00:00

New airline data indicates the number of lost, delayed or damaged bags is returning to pre-pandemic levels.

## Big firm bosses' pay rose 16% as workers squeezed
 - [https://www.bbc.co.uk/news/business-66574218?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66574218?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:02:05+00:00

Analysis from the High Pay Centre suggests the average pay of a FTSE 100 boss was £3.91m last year.

## A Maradona, a mission, a beacon of hope - the evolution of Naples' second club
 - [https://www.bbc.co.uk/sport/football/66271937?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66271937?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T23:01:38+00:00

Famous former players, a famous former manager, but Naples' second club are focused on more important priorities.

## UK microchip giant Arm files to sell shares in US
 - [https://www.bbc.co.uk/news/business-66574226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66574226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T22:52:24+00:00

Cambridge-based Arm files papers to list in New York after opting against London, in a blow to the UK.

## The Papers: Lucy Letby's 'final act of wickedness'
 - [https://www.bbc.co.uk/news/uk-66576828?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66576828?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T22:40:42+00:00

Tuesday's headlines are dominated by the sentencing of child serial killer Lucy Letby.

## Takehiro Tomiyasu: Arsenal boss Mikel Arteta says 'we might have to play with stop watch'
 - [https://www.bbc.co.uk/sport/football/66577099?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66577099?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T22:35:39+00:00

"We might have to play with a stop watch," says Arsenal boss Mikel Arteta after Takehiro Tomiyasu's red card.

## Garth Crooks' Team of the Week: Diaz, Foden, Sterling, Mitoma, Wissa and more
 - [https://www.bbc.co.uk/sport/football/66574117?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66574117?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T22:15:43+00:00

Which players impressed our football pundit Garth Crooks enough to make his second Team of the Week this season?

## Could decriminalisation solve Scotland's drug problem?
 - [https://www.bbc.co.uk/news/uk-scotland-66570190?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-66570190?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T22:01:41+00:00

Can lessons be learned from Portugal, which relaxed its drugs laws more than 20 years ago?

## World Athletics Championships 2023: Holly Bradshaw says pole vault is damaging her mental health
 - [https://www.bbc.co.uk/sport/athletics/66576950?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/66576950?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T21:36:16+00:00

British record holder Holly Bradshaw says she is considering her future in athletics after an early exit in the pole vault at the World Championships.

## Canada wildfires: Trudeau criticises Facebook over news ban amid crisis
 - [https://www.bbc.co.uk/news/world-us-canada-66573512?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66573512?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T21:21:10+00:00

The prime minister accuses the company of putting profits over safety amid Canada's wildfire crisis.

## Crystal Palace 0-1 Arsenal: Martin Odegaard scores only goal in Gunners win
 - [https://www.bbc.co.uk/sport/football/66495070?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66495070?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T21:09:37+00:00

Arsenal beat Crystal Palace at Selhurst Park thanks to a penalty from captain Martin Odegaard.

## Mason Greenwood: Gary Neville critical of Manchester United's handling of investigation
 - [https://www.bbc.co.uk/sport/football/66575700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66575700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:52:57+00:00

Gary Neville says Manchester United's handling of the Mason Greenwood investigation has been "pretty horrible" and lacked strong leadership.

## Women's World Cup: Spain's jubilant champions arrive in Madrid
 - [https://www.bbc.co.uk/news/world-66576890?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-66576890?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:52:18+00:00

The Spanish football team celebrate their win as they land at Madrid airport.

## Maids Moreton murderer Ben Field pays £124k to families of duped victims
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-66518951?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-66518951?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:39:09+00:00

Ben Field befriended two elderly people for financial gain in a case recently dramatised for BBC TV.

## Anglian Water bills to rise to pay for infrastructure
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-66535388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-66535388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:38:24+00:00

The East of England is "seriously water-stressed" and its biggest water firm is working on upgrades.

## World Championships 2023: Sha'Carri Richardson claims 100m gold as Dina Asher-Smith eighth
 - [https://www.bbc.co.uk/sport/athletics/66569249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/66569249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:33:50+00:00

Britain's Dina Asher-Smith misses out on a world 100m medal as American Sha'Carri Richardson claims her first major title against a star-studded field in Budapest.

## The Hundred 2023: Sam Billings hits brilliant half-century as Oval Invincibles beat Trent Rockets to reach final
 - [https://www.bbc.co.uk/sport/cricket/66576590?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66576590?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:32:40+00:00

Sam Billings hits a brilliant unbeaten half-century as Oval Invincibles seal their place in the Hundred final with a five-wicket victory over Trent Rockets.

## The Hundred 2023: Joe Root and Sam Billings big sixes lead Plays of the Day
 - [https://www.bbc.co.uk/sport/av/cricket/66576778?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/66576778?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:26:46+00:00

Watch the plays of the day from day 21 of The Hundred, including big sixes from Trend Rockets' Joe Root and Oval Invincibles' Sam Billings.

## X removes Holocaust denying post after Auschwitz Museum criticism
 - [https://www.bbc.co.uk/news/technology-66570203?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66570203?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:22:42+00:00

The Auschwitz Museum reported the post but was initially told by X it did not break safety rules.

## World Athletics Championships 2023: Sha'Carri Richardson wins gold in women's 100m final
 - [https://www.bbc.co.uk/sport/av/athletics/66576818?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/athletics/66576818?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T20:18:30+00:00

Watch USA's Sha'Carri Richardson win her first 100m world title, beating Jamaica's Shericka Jackson and Shelley-Ann Fraser-Pryce, with Dina Asher-Smith finishing eighth.

## Blackburn mum murdered by stranger as she sat on doorstep
 - [https://www.bbc.co.uk/news/uk-england-lancashire-66571302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-66571302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T18:42:52+00:00

Anthony Stinson walked up to Charlotte Wilcock's home and stabbed her 50 times with a knife.

## Greece wildfires: Authorities on alert for new spate of blazes
 - [https://www.bbc.co.uk/news/world-europe-66574476?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66574476?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T18:40:16+00:00

Officials warn that high temperatures and strong winds on Tuesday could see more devastating fires.

## Flooding from Storm Hilary cuts off Palm Springs in California
 - [https://www.bbc.co.uk/news/world-us-canada-66575237?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66575237?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T18:34:36+00:00

Major roads in and out of the California desert town are closed after over 3in of rain fell.

## No charges in Birmingham pub bombings reinvestigation
 - [https://www.bbc.co.uk/news/uk-england-birmingham-66575599?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-66575599?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T17:52:41+00:00

Prosecutors say there is insufficient evidence to bring charges over the 1974 attack.

## Hawaii wildfires: The red Lahaina house that survived Maui fires
 - [https://www.bbc.co.uk/news/world-us-canada-66575234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66575234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T17:43:00+00:00

The 100-year-old wood structure was recently renovated but not fireproofed, say owners.

## World Athletics Championships 2023: Katarina Johnson-Thompson & Zharnel Hughes congratulate each other on medals
 - [https://www.bbc.co.uk/sport/av/athletics/66574014?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/athletics/66574014?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T17:10:11+00:00

Great Britain's 100m bronze medallist Zharnel Hughes says heptathlon winner Katarina Johnson-Thompson has "inspired" him to push for gold at the World Athletics Championships.

## Sara Sharif was bubbly and confident, says school
 - [https://www.bbc.co.uk/news/uk-england-surrey-66575673?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-surrey-66575673?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T17:09:27+00:00

The body of Sara Sharif, aged 10, was found at her home in Woking, prompting a murder inquiry.

## Ukrainian drone destroys Russian supersonic bomber
 - [https://www.bbc.co.uk/news/world-europe-66573842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66573842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T16:44:46+00:00

Image shows Tu-22 "Backfire" ablaze after attack at airbase south of St Petersburg.

## Sheffield sex assault trial collapses due to 'astonishing' jury problems
 - [https://www.bbc.co.uk/news/uk-england-south-yorkshire-66573248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-south-yorkshire-66573248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T16:23:18+00:00

One juror fell asleep while another could not hear crucial evidence at Sheffield Crown Court.

## Mario: Voice of Nintendo game star Charles Martinet steps down after 27 years
 - [https://www.bbc.co.uk/news/entertainment-arts-66574424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66574424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T15:46:56+00:00

The actor will continue to work with Nintendo as a "Mario ambassador".

## Dominic Calvert-Lewin: Everton striker suffers suspected fractured cheekbone
 - [https://www.bbc.co.uk/sport/football/66574752?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66574752?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T15:39:10+00:00

Everton striker Dominic Calvert-Lewin faces another spell on the sidelines after sustaining a fractured cheekbone in Sunday's 4-0 defeat at Aston Villa.

## How Mary Earps confirmed her status as world's best goalkeeper
 - [https://www.bbc.co.uk/sport/football/66567155?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66567155?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T15:20:04+00:00

It was not the ending she deserved but Mary Earps rightly celebrated her Golden Glove award after the Women's World Cup final defeat by Spain.

## BBC science correspondent has heart age assessed by AI
 - [https://www.bbc.co.uk/news/science-environment-66565333?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-66565333?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T15:02:34+00:00

BBC science correspondent Pallab Ghosh has the age of his heart assessed by artificial intelligence.

## ‘Cruel, calculated’ Lucy Letby to spend rest of life in prison
 - [https://www.bbc.co.uk/news/uk-england-merseyside-66569311?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-66569311?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T14:57:24+00:00

Giving the nurse a whole-life sentence, the judge says there was "a malevolence bordering on sadism".

## Amadou Onana: Police investigating 'vile' racist abuse of Everton midfielder
 - [https://www.bbc.co.uk/sport/football/66571223?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66571223?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T14:47:39+00:00

Police are investigating "racist comments" directed towards Everton's Amadou Onana following Sunday's 4-0 loss at Aston Villa.

## 850 still missing after Maui fires, mayor says
 - [https://www.bbc.co.uk/news/world-us-canada-66571294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66571294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T14:37:10+00:00

President Joe Biden is expected to visit the island for the first time since the deadly wildfires.

## King and Queen begin summer stay in Scotland at Balmoral
 - [https://www.bbc.co.uk/news/uk-scotland-66570409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-66570409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T14:36:49+00:00

King Charles is continuing his mother's royal tradition of taking a summer residence in Scotland.

## Mason Greenwood: Manchester United striker will leave club after internal investigation
 - [https://www.bbc.co.uk/sport/football/66554874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66554874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T14:00:25+00:00

Mason Greenwood will leave Manchester United following an internal investigation after police dropped charges of attempted rape and assault.

## Let childminders work in own homes, landlords urged
 - [https://www.bbc.co.uk/news/uk-politics-66568493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66568493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T13:23:56+00:00

But the sector says asking landlords to review restrictive contracts will only make a small difference.

## Derby: Four arrests after violence at kabaddi match
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-66572456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-66572456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T13:06:44+00:00

The large-scale disturbance in Derby saw four people injured and taken to hospital.

## Rugby World Cup: Wales name Jac Morgan and Dewi Lake as co-captains for tournament
 - [https://www.bbc.co.uk/sport/rugby-union/66566287?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/66566287?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T12:51:57+00:00

Wales boss Warren Gatland chooses flanker Jac Morgan and hooker Dewi Lake as co-captains for the 2023 World Cup in France as he selects his final 33-man squad.

## Renting now cheaper than first-time mortgages, says Zoopla
 - [https://www.bbc.co.uk/news/business-66568528?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66568528?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T12:38:46+00:00

It is less expensive to rent than buy for the first time since 2010, but there are wide regional variations.

## Lucy Letby absence from sentencing 'one final act of wickedness from a coward'
 - [https://www.bbc.co.uk/news/uk-66568477?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66568477?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T12:22:32+00:00

Letby's court absence for her sentencing has renewed calls for the law to be changed to compel convicts to attend.

## Watch the moment Lucy Letby is sentenced
 - [https://www.bbc.co.uk/news/uk-66567603?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66567603?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T12:14:30+00:00

The nurse, who killed seven babies, is the UK's most prolific child serial killer in modern times.

## Families to Letby: 'You played God with our children'
 - [https://www.bbc.co.uk/news/uk-66570308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66570308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:51:07+00:00

Families of babies who were murdered and attacked by Lucy Letby are giving victim impact statements.

## Man appears in court over NI police data breach
 - [https://www.bbc.co.uk/news/uk-northern-ireland-66565473?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-66565473?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:46:48+00:00

Christopher Paul O'Kane was detained following a search in Dungiven, County Londonderry, on Friday.

## Hermoso kissed on lips by football boss at victory ceremony
 - [https://www.bbc.co.uk/sport/av/football/66571350?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/66571350?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:28:26+00:00

The Spanish football federation has responded after president Luis Rubiales kissed forward Jenni Hermoso after their World Cup final win.

## Women's World Cup final: England v Spain watched by peak BBC TV audience of 12 million
 - [https://www.bbc.co.uk/sport/football/66567881?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66567881?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:26:32+00:00

The Women's World Cup final between England and Spain on Sunday drew a peak audience of 12 million viewers on BBC One.

## MLB: Detroit Tigers' Riley Greene flies through air to take catch
 - [https://www.bbc.co.uk/sport/av/baseball/66569576?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/baseball/66569576?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:13:40+00:00

Watch Riley Greene fly through the air to take an incredible catch for Detroit Tigers against Cleveland Guardians in their MLB fixture on Sunday.

## Nursing manager during Letby murders suspended
 - [https://www.bbc.co.uk/news/uk-66569258?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66569258?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T11:08:50+00:00

Alison Kelly is suspended from her current role after information emerged in the Lucy Letby trial.

## Hermoso kissed on lips by Spanish FA boss at ceremony
 - [https://www.bbc.co.uk/sport/football/66568226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66568226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T10:46:08+00:00

Luis Rubiales is criticised by a Spanish government minister for kissing forward Jenni Hermoso on the lips after Spain's Women's World Cup victory.

## Car breakdowns due to potholes soar in rainy July
 - [https://www.bbc.co.uk/news/business-66569152?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66569152?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T10:35:57+00:00

The AA saw call-outs jump with drivers reporting damage after wet weather hampered road repairs.

## No police action over King Charles charity probe
 - [https://www.bbc.co.uk/news/uk-66569843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66569843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T10:34:33+00:00

The Met Police has been investigating cash-for-honours allegations involving the Prince's Foundation.

## Stormzy as a mentor gives me the guidance I need, says singer Debbie
 - [https://www.bbc.co.uk/news/newsbeat-66532456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-66532456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T10:20:16+00:00

Singer-songwriter Debbie met the award-winning rapper last year and has worked closely with him since.

## Ryder Cup 2023: USA team to face Europe contains at least three debutants
 - [https://www.bbc.co.uk/sport/golf/66570004?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/66570004?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T10:11:23+00:00

Open champion Brian Harman, US Open winner Wyndham Clark and Max Homa are among the six automatic qualifiers for the USA.

## Nadine Dorries has 'abandoned' Mid Bedfordshire voters - council
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-66568270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-66568270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T09:45:32+00:00

Another council urges the former minister to formally resign after announcing she would quit in June.

## Chris Evans: Radio DJ reveals skin cancer diagnosis
 - [https://www.bbc.co.uk/news/entertainment-arts-66522403?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66522403?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T09:36:44+00:00

The broadcaster, 57, urged his Virgin Radio listeners to get themselves checked.

## Women's World Cup: Ellen White - England Lionesses' success will have lasting legacy
 - [https://www.bbc.co.uk/sport/football/66567147?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66567147?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T08:36:20+00:00

The success of England's Lionesses at the Women's World Cup will have a lasting legacy, says record scorer Ellen White.

## Asake pays tribute to Brixton Academy crush victims at return gig
 - [https://www.bbc.co.uk/news/newsbeat-66568450?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-66568450?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T08:36:06+00:00

Asake hasn't performed in the UK since two women were killed in a crush at his O2 Academy Brixton gig.

## Canada wildfires: Drone footage shows scale of destruction in Northwest Territories
 - [https://www.bbc.co.uk/news/world-us-canada-66568903?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66568903?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T08:18:57+00:00

Enterprise in Canada's Northwest Territories is burnt to the ground as wildfires continue to grip the country.

## Storm Hilary: Hollywood and Disneyland among iconic locations hit
 - [https://www.bbc.co.uk/news/world-66568981?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-66568981?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T08:04:53+00:00

Tropical Storm Hilary is barrelling through Southern California where 26 million people face flood warnings.

## Women's World Cup 2023: Record attendance of almost two million
 - [https://www.bbc.co.uk/sport/football/66517612?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66517612?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T08:01:38+00:00

Ticket sales for the Women's World Cup in Australia and New Zealand exceeded all targets, says Fifa.

## John Stones: Manchester City defender ruled out until after international break with injury
 - [https://www.bbc.co.uk/sport/football/66567715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66567715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T07:07:29+00:00

Manchester City and England defender John Stones is ruled out of action until after the international break with a muscle injury.

## What next for England and Wiegman?
 - [https://www.bbc.co.uk/sport/football/66564402?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66564402?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T07:01:08+00:00

England return from Australia following defeat in the Women's World Cup final - but what will they be looking ahead to now?

## Cincinnati Open: Novak Djokovic wins title after beating Carlos Alcaraz as rivalry intensifies
 - [https://www.bbc.co.uk/sport/tennis/66567709?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/66567709?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T06:38:34+00:00

Novak Djokovic says his rivalry with Carlos Alcaraz is similar to the one he shared with Rafael Nadal after a classic final.

## Chandrayaan-3: India's lunar lander Vikram searches for safe Moon landing spot
 - [https://www.bbc.co.uk/news/world-asia-india-66567437?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-66567437?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:33:25+00:00

Day after Luna-25 crash, India space agency says lander trying to find area without boulders or deep trenches.

## Linda Razzell: Killer's chance to reveal what happened to missing mum
 - [https://www.bbc.co.uk/news/uk-england-wiltshire-66431217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-wiltshire-66431217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:31:23+00:00

A public parole hearing could see Glyn Razzell finally reveal what happened to his wife Linda.

## Teenage footballer gives injury payout to Helston foodbank
 - [https://www.bbc.co.uk/news/uk-england-cornwall-66547996?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cornwall-66547996?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:30:31+00:00

Osiah, 16, badly broke his leg but decided to donate a £600 insurance payout to a local charity.

## Cost of living: Chip shop's £1 meal for struggling families
 - [https://www.bbc.co.uk/news/uk-wales-66545453?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66545453?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:12:31+00:00

Sarah Lewis says summer "can be really tough on those having a hard time making ends meet".

## Black hole in Town Hall budgets rises to £5bn
 - [https://www.bbc.co.uk/news/uk-66428191?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66428191?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:09:11+00:00

Unison warns some councils will be unable to provide basic services.

## Bus: Wales could lose quarter of services, say operators
 - [https://www.bbc.co.uk/news/uk-wales-66543302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66543302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:06:17+00:00

Bus operators say passengers could face more cuts to services without further government funding.

## Lucy Letby: How could the NHS stop a future killer within?
 - [https://www.bbc.co.uk/news/uk-england-merseyside-66243542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-66243542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T05:04:10+00:00

There are striking parallels in the cases of Lucy Letby and Beverley Allitt, who killed four children.

## Hundreds of migrants killed by Saudi border guards - report
 - [https://www.bbc.co.uk/news/world-middle-east-66545787?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-66545787?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T04:08:20+00:00

Migrants tell the BBC they were shot on the Saudi border as a new report alleges "mass killings".

## Morrisons' bras and pants carry NHS cancer check label
 - [https://www.bbc.co.uk/news/health-66544229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-66544229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T03:28:55+00:00

Underwear labels urge people to contact their GP if they spot symptoms of breast or testicular cancer.

## Tommy Jessop: Line of Duty star tackles Hollywood with his own script
 - [https://www.bbc.co.uk/news/disability-66512531?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/disability-66512531?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-08-21T01:26:15+00:00

Line of Duty Actor Tommy Jessop takes his script to Hollywood in bid to get leading roles.

