# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Eksport z Estonii do Rosji dratycznie spadł, ale nadal handlują z nią setki firm
 - [https://www.bankier.pl/wiadomosc/Eksport-z-Estonii-do-Rosji-dratycznie-spadl-ale-nadal-handluja-z-nia-setki-firm-8598135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Eksport-z-Estonii-do-Rosji-dratycznie-spadl-ale-nadal-handluja-z-nia-setki-firm-8598135.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T22:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/fa06255148f33a-948-567-0-49-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Estoński eksport do Rosji spadł drastycznie w następstwie inwazji tego kraju na Ukrainę, jednak handel z nią nadal prowadzi ponad 300 zarejestrowanych w Estonii firm - poinformował estoński urząd celny, cytowany w poniedziałek przez telewizję ERR.</p>

## Przewaga wzrostów w USA. Zyskał zwłaszcza sektor technologiczny
 - [https://www.bankier.pl/wiadomosc/Przewaga-wzrostow-w-USA-Zyskal-zwlaszcza-sektor-technologiczny-8598121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przewaga-wzrostow-w-USA-Zyskal-zwlaszcza-sektor-technologiczny-8598121.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T21:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/74b3cce96b50f8-945-560-0-138-1632-979.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Giełdy w USA głównie zwyżkowały na zamknięciu poniedziałkowej sesji - zyskał zwłaszcza sektor technologiczny. Inwestorzy zwracają uwagę na rynek długu - rentowności 10-letnich obligacji USA są najwyższe od 2007 r.</p>

## Departament Stanu USA wyraził zgodę na sprzedaż Polsce 96 śmigłowców, wyceniając je na 12 mld dol.
 - [https://www.bankier.pl/wiadomosc/Departament-Stanu-USA-wyrazil-zgode-na-sprzedaz-Polsce-96-smiglowcow-wyceniajac-je-na-12-mld-dol-8598110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Departament-Stanu-USA-wyrazil-zgode-na-sprzedaz-Polsce-96-smiglowcow-wyceniajac-je-na-12-mld-dol-8598110.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T20:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/85218bf131143f-711-426-17-5-711-426.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Departament Stanu wyraził zgodę na potencjalną sprzedaż Polsce 96 śmigłowców szturmowych AH-64E Apache wraz z uzbrojeniem, wyceniając je na 12 miliardów dolarów - podała należąca do Pentagonu agencja Defense Security Cooperation Agency (DSCA).</p>

## Rentowność obligacji USA na 16-letnim szczycie
 - [https://www.bankier.pl/wiadomosc/Rentownosc-obligacji-USA-na-16-letnim-szczycie-8598112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rentownosc-obligacji-USA-na-16-letnim-szczycie-8598112.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T20:38:56.506542+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/f/b527a11faecb47-948-568-19-1300-2620-1572.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rentowności długoterminowych obligacji rządu Stanów
Zjednoczonych wybiły jesienne szczyty i znalazły się na wieloletnich maksimach.</p>

## Izrael oskarża Iran o najnowszą falę terroru. "Rozważane są wszystkie opcje"
 - [https://www.bankier.pl/wiadomosc/Izrael-oskarza-Iran-o-najnowsza-fale-terroru-Rozwazane-sa-wszystkie-opcje-8598102.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izrael-oskarza-Iran-o-najnowsza-fale-terroru-Rozwazane-sa-wszystkie-opcje-8598102.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T20:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/24ec2967cbdd8c-948-568-0-270-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wizytując w poniedziałek wieczorem miejsce dzisiejszego ataku terrorystycznego, premier Izraela Benjamin Netanjahu zarzucił Iranowi odpowiedzialność za najnowszą falę terroru.</p>

## "New Yorker": władze USA są zdane na łaskę Elona Muska w wielu obszarach
 - [https://www.bankier.pl/wiadomosc/New-Yorker-wladze-USA-sa-zdane-na-laske-Elona-Muska-w-wielu-obszarach-8598101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/New-Yorker-wladze-USA-sa-zdane-na-laske-Elona-Muska-w-wielu-obszarach-8598101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T20:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/c298e35caa4018-948-568-0-243-4631-2778.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rządowe agencje są zdane na łaskę i niełaskę miliardera Elona Muska, w obszarach od obronności po eksplorację kosmosu - zauważa w poniedziałek magazyn "New Yorker". Pismo twierdzi, że poziom uzależnienia państwa od bogacza budzi obawy, m.in. w obliczu jego coraz bardziej impulsywnego zachowania, pogardy dla zasad i "regularnych" konsultacji z Kremlem.</p>

## Chiny inwestują obecnie w Serbii tyle, ile cała UE
 - [https://www.bankier.pl/wiadomosc/Chiny-inwestuja-obecnie-w-Serbii-tyle-ile-cala-UE-8598090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-inwestuja-obecnie-w-Serbii-tyle-ile-cala-UE-8598090.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T19:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/a14fbc3a1e7e1c-948-567-5-30-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chiny inwestują obecnie w Serbii tyle, ile cała Unia Europejska łącznie; to musi budzić niepokój zachodnich dyplomatów - pisze w poniedziałek brytyjski dziennik "Times"</p>

## Właściciele pustych domów w Portugalii będą musieli je wynająć? Prezydent zawetował ustawę
 - [https://www.bankier.pl/wiadomosc/Wlasciciele-pustych-domow-w-Portugali-beda-musieli-je-wynajac-Prezydent-zawetowal-ustawe-8598079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wlasciciele-pustych-domow-w-Portugali-beda-musieli-je-wynajac-Prezydent-zawetowal-ustawe-8598079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T18:28:53.844377+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/8b61574c1db601-948-568-2-45-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Portugalii Marcelo Rebelo de Sousa zawetował w poniedziałek zatwierdzoną w lipcu przez jednoizbowy parlament ustawę o mieszkalnictwie. Regulacja ta zobowiązywała m.in. posiadaczy pustych domów do ich wynajęcia.</p>

## Turcja wyśle gaz na Węgry. Eksport surowca powinien ruszyć w przyszłym roku
 - [https://www.bankier.pl/wiadomosc/Turcja-wysle-gaz-na-Wegry-Eksport-surowca-powinien-ruszyc-w-przyszlym-roku-8598066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Turcja-wysle-gaz-na-Wegry-Eksport-surowca-powinien-ruszyc-w-przyszlym-roku-8598066.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T18:04:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/0/a73a954c3cd7d3-948-568-0-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po raz pierwszy w historii rozpoczniemy przesyłanie gazu naturalnego do kraju europejskiego, z którym nie dzielimy granicy. Eksport surowca na Węgry powinien ruszyć w przyszłym roku - poinformował w poniedziałek minister energii i zasobów naturalnych Turcji Alparslan Bayraktar.</p>

## Sąd UOKiK oddalił odwołanie Benefit Systems od decyzji prezesa Urzędu dot. wielomilionowej kary
 - [https://www.bankier.pl/wiadomosc/Sad-oddalil-odwolanie-Benefit-Systems-dot-nalozonej-na-spolke-kary-w-wys-26-9-mln-zl-8598060.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sad-oddalil-odwolanie-Benefit-Systems-dot-nalozonej-na-spolke-kary-w-wys-26-9-mln-zl-8598060.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T17:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/6002bf98f2266b-945-560-25-56-1706-1023.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd Ochrony Konkurencji i Konsumentów oddalił odwołanie Benefit Systems od decyzji wydanej przez Prezesa UOKiK dotyczącej nałożenia kary w wysokości 26,9 mln zł - podała spółka w komunikacie. Benefit planuje wnieść apelację.</p>

## Spokojnie na indeksach i emocjonująco na spółkach. Dino, XTB i Bogdanka w centrum uwagi
 - [https://www.bankier.pl/wiadomosc/Spokojnie-na-indeksach-i-emocjonujaco-na-spolkach-Dino-XTB-i-Bogdanka-w-centrum-uwagi-8598001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spokojnie-na-indeksach-i-emocjonujaco-na-spolkach-Dino-XTB-i-Bogdanka-w-centrum-uwagi-8598001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T16:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/989b4ed5276ee4-948-568-0-77-4445-2666.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poniedziałek na GPW to przede wszystkim próba przerwania spadkowej serii na WIG20, która ostatecznie się udała. Niewielkie zmiany głównych indeksów nie odzwierciedlały tego, jak wiele się działo na niektórych spółkach. Znów w centrum uwagi były akcje Dino oraz niespodziewanie XTB oraz Bogdanki.</p>

## Koszt 14. emerytury w 2023 roku będzie wyższy o 9 mld zł od planu
 - [https://www.bankier.pl/wiadomosc/Koszt-14-emerytury-w-2023-roku-bedzie-wyzszy-o-9-mld-zl-od-planu-8597971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koszt-14-emerytury-w-2023-roku-bedzie-wyzszy-o-9-mld-zl-od-planu-8597971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T15:16:35.903716+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/b/7837764d043dff-948-567-0-55-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Koszt wypłaty 14. emerytury dla budżetu państwa w 2023 r., przy świadczeniu w wysokości 2 200 zł netto, będzie wyższy o 9 mld zł od planu - poinformowała w Radiu Maryja minister rodziny i polityki społecznej.</p>

## "Pierwsze mieszkanie" hitem? Podpisano już umowy na prawie 1 mld zł
 - [https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-hitem-Podpisano-juz-umowy-na-prawie-1-mld-zl-8597963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsze-mieszkanie-hitem-Podpisano-juz-umowy-na-prawie-1-mld-zl-8597963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T15:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/6/0d4780c3becbbd-948-568-0-0-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 32 tys. osób złożyło wnioski w programie „Pierwsze Mieszkanie”; podpisano 2 tys. 709 umów na prawie 1 mld złotych - poinformował w poniedziałek minister rozwoju i technologii Waldemar Buda. Dodał, że założono też 1 tys. 331 Kont Mieszkaniowych.</p>

## Zadłużenie Skarbu Państwa nieco spadło
 - [https://www.bankier.pl/wiadomosc/Zadluzenie-Skarbu-Panstwa-nieco-spadlo-8597936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zadluzenie-Skarbu-Panstwa-nieco-spadlo-8597936.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T14:11:33.467820+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/2/53e61f61ae5aab-948-567-0-32-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zadłużenie Skarbu Państwa na koniec lipca spadło o 6,2 mld zł (-0,5 proc.) mdm i wyniosło ok. 1.271,3 mld zł  - podał resort finansów w szacunkowych danych.</p>

## Polacy polubili się z e-receptami
 - [https://www.bankier.pl/wiadomosc/Polacy-polubili-sie-z-e-receptami-8597875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-polubili-sie-z-e-receptami-8597875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T13:06:28.061279+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/7d0c523564afb3-945-560-0-51-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z cyfrowych recept korzysta trzy czwarte pytanych (76 proc.), z czego ponad dwie piąte (44 proc.) robi to często. Skierowaniami otrzymywanymi w wiadomościach SMS, e-mailach lub aplikacjach internetowych posługuje się sześciu na dziesięciu ankietowanych (61 proc.) – wynika z sondażu CBOS.</p>

## Skarb Państwa oferuje za odkupienie Bogdanki prawie 990 mln zł
 - [https://www.bankier.pl/wiadomosc/Enea-otrzymala-od-SP-oferte-nabycia-pakietu-akcji-LW-Bogdanki-za-lacznie-ok-988-3-mln-zl-8597888.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Enea-otrzymala-od-SP-oferte-nabycia-pakietu-akcji-LW-Bogdanki-za-lacznie-ok-988-3-mln-zl-8597888.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T13:06:28.031006+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/3/e404cdfa6d2529-948-568-20-230-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Enea otrzymała od Skarbu Państwa, reprezentowanego przez Ministra Aktywów Państwowych, ofertę nabycia pakietu 21.962.189 akcji LW Bogdanki należących do Enei, po cenie 45 zł za akcję, czyli łącznie ok. 988,3 mln zł - podała Enea w komunikacie.</p>

## NBP zwiększył zasoby złota. Wartość kruszcu w skarbcach banku wynosiła ponad 75 mld zł
 - [https://www.bankier.pl/wiadomosc/NBP-zwiekszyl-zasoby-zlota-Wartosc-kruszcu-w-skarbcach-banku-wynosila-ponad-75-mld-zl-8597849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-zwiekszyl-zasoby-zlota-Wartosc-kruszcu-w-skarbcach-banku-wynosila-ponad-75-mld-zl-8597849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T13:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/3d37c7dbe9ac30-937-562-45-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NBP w lipcu zwiększył zasoby złota. Na koniec tego miesiąca posiadał blisko 9,3 mln uncji złota, czyli o 0,72 mln uncji więcej niż miesiąc wcześniej – wynika z danych opublikowanych w poniedziałek przez bank centralny.</p>

## Chińczycy oszczędni w cięciu stóp. Rynek oczekiwał większej obniżki
 - [https://www.bankier.pl/wiadomosc/Chinczycy-oszczedni-w-cieciu-stop-procentowych-8597835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinczycy-oszczedni-w-cieciu-stop-procentowych-8597835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/0/74327111465054-945-560-31-170-4224-2534.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ludowy Bank Chin zdecydował się na mniejszą redukcję stóp
procentowych, niż tego oczekiwał rynek.</p>

## Tajemnicza przecena akcji XTB. Inwestorzy stawiają na hiszpański kierunek
 - [https://www.bankier.pl/wiadomosc/Tajemnicza-przecena-akcji-XTB-Inwestorzy-stawiaja-na-hiszpanski-kierunek-8597815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tajemnicza-przecena-akcji-XTB-Inwestorzy-stawiaja-na-hiszpanski-kierunek-8597815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T12:55:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/1/136427a15a645d-948-568-0-58-1800-1080.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Akcje polskiego brokera zaliczają w czasie poniedziałkowej sesji sporą przecenę, mimo że na rynkach panuje dosyć stabilna sytuacja, a ostatnim oficjalnym komunikatem ze spółki był raport finansowy za pierwsze półrocze, na który inwestorzy mieli czas już zareagować w piątek. Pojawiają się sugestie, że akcjonariuszy mogły wystraszyć zawarte w sprawozdaniu informacje o decyzji hiszpańskiego nadzorcy.</p>

## Cognor planuje redukcję etatów. Spółka zauważa techniczną recesję w Polsce
 - [https://www.bankier.pl/wiadomosc/Cognor-spodziewa-sie-wyniku-EBITDA-w-III-kw-na-poziomie-z-II-kw-planuje-redukcje-etatow-8597819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Cognor-spodziewa-sie-wyniku-EBITDA-w-III-kw-na-poziomie-z-II-kw-planuje-redukcje-etatow-8597819.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T12:01:26.212385+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/eaa5c8d2dc9dcc-948-568-0-330-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cognor Holding zakłada, że w III kw. wynik EBITDA będzie na podobnym poziomie do II kwartału; zauważa techniczną recesję w Polsce. Po zakończeniu nowych inwestycji grupa zredukuje zatrudnienie o ok. 15 proc. - poinformował na konferencji dyrektor finansowy Cognor Holding, Krzysztof Zoła.</p>

## Prokuratura postawi zarzuty premierowi i ministrom? Jest oświadczenie
 - [https://www.bankier.pl/wiadomosc/Prokuratura-postawi-zarzuty-premierowi-i-ministrom-Jest-oswiadczenie-8597800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prokuratura-postawi-zarzuty-premierowi-i-ministrom-Jest-oswiadczenie-8597800.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T12:01:26.192924+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/d4a638e2f79b52-948-568-0-163-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura Krajowa wydała oświadczenie w sprawie poniedziałkowej publikacji "Gazety Wyborczej". "Nieprawdą jest, że w toku postępowania został sporządzony plan śledztwa, z którego miało wynikać, że planowane jest postawienie zarzutów premierowi i ministrom. Dokument taki nigdy nie został sporządzony" - zaznaczył Dział Prasowy Prokuratury Krajowej.</p>

## Papierowe złoto zadebiutuje na GPW. Jest data
 - [https://www.bankier.pl/wiadomosc/Papierowe-zloto-zadebiutuje-na-GPW-Jest-data-8597794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Papierowe-zloto-zadebiutuje-na-GPW-Jest-data-8597794.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T11:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/ff3bcf46b8ce93-948-568-0-0-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na Giełdzie Papierów Wartościowych w Warszawie, 30 sierpnia 2023 r., zadebiutuje nowy produkt typu Exchange Traded Commodities (ETC) - poinformowała GPW w komunikacie. Emitentem pierwszego na GPW ETC na fizyczne złoto jest europejska platforma ETF – HANetf.</p>

## Chiny chcą, by BRICS stał się rywalem dla G7
 - [https://www.bankier.pl/wiadomosc/Chiny-chca-by-BRICS-stal-sie-rywalem-dla-G7-8597759.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-chca-by-BRICS-stal-sie-rywalem-dla-G7-8597759.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T10:56:23.561999+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/82abe14aec3a21-948-568-0-398-4433-2659.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chiny naciskają na rozszerzenie bloku BRICS (Brazylia, Rosja, Indie, Chiny, RPA) o kolejne państwa, aby stał się on pełnowymiarowym rywalem dla grupy G7, choć pomysłowi temu sprzeciwiają się Indie - pisze w poniedziałek "Financial Times".</p>

## Emerytura dla zarabiających najniższą krajową. Ile wyniesie świadczenie?
 - [https://www.bankier.pl/wiadomosc/Emerytura-dla-zarabiajacych-najnizsza-krajowa-Ile-wyniesie-swiadczenie-8597691.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Emerytura-dla-zarabiajacych-najnizsza-krajowa-Ile-wyniesie-swiadczenie-8597691.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T10:56:23.534483+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/33afbbacda486a-948-568-0-93-2496-1497.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na wysokość miesięcznej emerytury ma wpływ kilka czynników m.in. kwota zarobków, wysokość opłacanych składek i staż pracy. Wysokość świadczenia dla osoby zarabiającej najniższą krajową może zaskakiwać.</p>

## Tauron kontroluje fotowoltaikę. "Sąsiad podbija napięcie – ty nie generujesz energii"
 - [https://www.bankier.pl/wiadomosc/Tauron-kontroluje-fotowoltaike-Sasiad-podbija-napiecie-ty-nie-generujesz-energii-8597749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tauron-kontroluje-fotowoltaike-Sasiad-podbija-napiecie-ty-nie-generujesz-energii-8597749.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T10:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/d7961af2075325-948-567-0-30-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tauron Dystrybucja prowadzi kontrole mikroinstalacji fotowoltaicznych z powodu nadużyć klientów - poinformowała spółka w poniedziałek. Tauron wskazał, że tylko na obszarze gliwickim wykrył ponad 1,5 tys. niepoprawnych nastaw falowników i 1,6 tys. przypadków przekroczeń mocy zainstalowanej.</p>

## Pekao: 2023 rok pod znakiem równoważenia polskiej gospodarki
 - [https://www.bankier.pl/wiadomosc/Pekao-2023-rok-pod-znakiem-rownowazenia-polskiej-gospodarki-8597741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pekao-2023-rok-pod-znakiem-rownowazenia-polskiej-gospodarki-8597741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T10:34:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/1d91929a35faf2-948-568-13-66-1759-1055.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rok 2023 upływa pod znakiem równoważenia polskiej gospodarki i ma to konsekwencje dezinflacyjne – stwierdził ekonomista Banku Pekao Piotr Bartkiewicz. GUS poinformował w poniedziałek o fatalnym początku nowego kwartału w przemyśle oraz o najnowszych danych z rynku pracy.</p>

## Pekin zakazał importu mango z Tajwanu. "To decyzja polityczna"
 - [https://www.bankier.pl/wiadomosc/Pekin-zakazal-importu-mango-z-Tajwanu-To-decyzja-polityczna-8597734.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pekin-zakazal-importu-mango-z-Tajwanu-To-decyzja-polityczna-8597734.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T09:51:25.493320+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/c90a0664799088-948-568-0-177-3945-2366.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pekin zawiesił w poniedziałek import mango z Tajwanu – poinformował oficjalny dziennik Komunistycznej Partii Chin "Renmin Ribao". Powodem decyzji jest wykrycie pestycydów. Władze Tajwanu potępiły decyzję, twierdząc, że jest ona motywowana politycznie.</p>

## Fabryka silników elektrycznych zwalnia. Co czwarty pracownik straci pracę
 - [https://www.bankier.pl/wiadomosc/Fabryka-silnikow-elektrycznych-zwalnia-Co-czwarty-pracownik-straci-prace-8597645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fabryka-silnikow-elektrycznych-zwalnia-Co-czwarty-pracownik-straci-prace-8597645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T09:51:25.470461+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/95a69090bf0caa-948-568-0-66-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kryzys finansowy w tarnowskim przedsiębiorstwie ATB Tamel doprowadził do zwolnień. Fabryka silników elektrycznych planuje zredukować liczbę pracowników o 200 osób do końca tego roku. To jedna czwarta wszystkich zatrudnionych.</p>

## DM BDM podtrzymał rekomendację "kupuj" dla Orange Polska
 - [https://www.bankier.pl/wiadomosc/DM-BDM-podtrzymal-rekomendacje-kupuj-dla-Orange-Polska-8597710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/DM-BDM-podtrzymal-rekomendacje-kupuj-dla-Orange-Polska-8597710.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T09:44:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/33229c5cc2318e-948-568-2-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Analitycy DM BDM, w raporcie z 14 sierpnia, podtrzymali rekomendację "kupuj" dla Orange Polska i obniżyli cenę docelową dla akcji spółki do 8,87 zł, z 9,28 zł.</p>

## Darmowe projekty domów bez pozwoleń do końca roku. Część będzie musiała zostać rozebrana?
 - [https://www.bankier.pl/wiadomosc/Darmowe-projekty-domow-bez-pozwolen-do-konca-roku-Czesc-bedzie-musiala-zostac-rozebrana-8597695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Darmowe-projekty-domow-bez-pozwolen-do-konca-roku-Czesc-bedzie-musiala-zostac-rozebrana-8597695.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T09:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/a/1ebf88170c878b-948-568-0-134-1997-1198.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeszcze w 2023 r. ministerstwo rozwoju ma udostępnić bezpłatne projekty domów bez pozwoleń nawet o powierzchni 180 mkw. – zapowiedział minister Waldemar Buda. Jak jednak twierdzą przedstawiciele Krajowej Izby Gospodarczej, brak nadzoru może skutkować koniecznością rozbiórki części zbudowanych w ten sposób domów.</p>

## Płace rozczarowały ekonomistów. Ale zatrudnienie drgnęło w górę
 - [https://www.bankier.pl/wiadomosc/Przecietne-wynagrodzenei-i-zatrudnienie-w-Polsce-lipiec-2023-8597649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przecietne-wynagrodzenei-i-zatrudnienie-w-Polsce-lipiec-2023-8597649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T09:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/d76890e7ad37c4-948-568-80-86-2399-1439.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wyraźnie niższy od oczekiwań wzrost płac oraz kosmetyczny
przyrost zatrudnienia – takie są wyniki lipcowego raportu z polskiego rynku
pracy.</p>

## Wojciechowski: Transport ukraińskiego zboża przez Polskę się nie opłaca
 - [https://www.bankier.pl/wiadomosc/Wojciechowski-Transport-ukrainskiego-zboza-przez-Polske-sie-nie-oplaca-8597684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wojciechowski-Transport-ukrainskiego-zboza-przez-Polske-sie-nie-oplaca-8597684.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T08:46:19.351095+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/0/16dca065d7d22c-945-560-0-59-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Transport ziarna z Ukrainy przez Polskę się po prostu nie opłaca. Jeśli Ukraina ma swoje rynki tradycyjne w Indonezji czy Egipcie, to droga na te rynki nie prowadzi przez Polskę - stwierdził w poniedziałek w Salonie Politycznym Trójki unijny komisarz ds. rolnictwa Janusz Wojciechowski.</p>

## Fala bankructw przedsiębiorstw w UE. Tak źle nie było od 2015 roku
 - [https://www.bankier.pl/wiadomosc/Fala-bankructw-przedsiebiorstw-w-UE-Tak-zle-nie-bylo-od-2015-roku-8597672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fala-bankructw-przedsiebiorstw-w-UE-Tak-zle-nie-bylo-od-2015-roku-8597672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T08:46:19.348756+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/7769e8763dffbe-948-568-52-1192-2947-1768.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szósty kwartał z rzędu w 2023 roku wzrosła liczba wniosków o upadłość unijnych przedsiębiorstw. W porównaniu z poprzednim kwartałem liczba upadłości wzrosła o 8,4 proc. i tym samym osiągnęła najwyższy poziom od rozpoczęcia zbierania danych w 2015 roku – podał Eurostat.</p>

## Polski przemysł dalej cierpi. Fatalny początek nowego kwartału
 - [https://www.bankier.pl/wiadomosc/Produkcja-przemyslowa-Polska-lipiec-2023-r-8597650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Produkcja-przemyslowa-Polska-lipiec-2023-r-8597650.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T08:46:19.320371+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/ac8153346d4a69-945-567-11-0-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />To już szósty miesiąc z rzędu, w którym roczna dynamika produkcji przemysłowej notuje ujemny wynik i w dodatku przyspiesza. Według danych GUS w lipcu polski przemysł powrócił też do spadków w ujęciu miesiąc do miesiąca po zaledwie dwóch okresach przerwy z czerwca i maja.</p>

## Kurs euro lekko w górę. Rynek oczekuje na bankierów
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-lekko-w-gore-Rynek-oczekuje-na-bankierow-8597644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-lekko-w-gore-Rynek-oczekuje-na-bankierow-8597644.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T08:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/0a29f1a5ffdd26-948-568-22-32-977-586.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wakacyjna flauta kursu euro trwa w najlepsze. Uczestnicy rynku wyczekują
na coroczną konferencję najważniejszych bankierów centralnych świata.</p>

## Awaria aplikacji dla operatorów dronów. Nieszczęście wisi w powietrzu
 - [https://www.bankier.pl/wiadomosc/Awaria-aplikacji-dla-operatorow-dronow-Nieszczescie-wisi-w-powietrzu-8597637.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Awaria-aplikacji-dla-operatorow-dronow-Nieszczescie-wisi-w-powietrzu-8597637.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T08:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/4/08b1ae9a3355b5-948-567-0-62-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podstawowa aplikacja dla operatorów dronów, Drone Radar, nie działa od dwóch tygodni. Wnp.pl podaje, że ta awaria powinna zostać usunięta jak najszybciej i może ona być niebezpieczna między innymi dla śmigłowców Lotniczego Pogotowia Ratunkowego.</p>

## Miedź drożeje. Chińska budowlanka napędzi popyt?
 - [https://www.bankier.pl/wiadomosc/Miedz-drozeje-Chinska-budowlanka-napedzi-popyt-8597609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miedz-drozeje-Chinska-budowlanka-napedzi-popyt-8597609.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T07:41:17.947419+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/8ed17f3cbf6634-945-560-112-405-4331-2598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny miedzi na giełdzie metali LME w Londynie idą w górę  Metal na LME zyskuje 0,5 proc. wobec  8240,00 USD za tonę, notowanych na zakończenie poprzedniej sesji - podają maklerzy.</p>

## Prawie 800 tys. złotych kary za "ofertę wekslową". UOKiK ukarał Aforti Holding
 - [https://www.bankier.pl/wiadomosc/UOKiK-nalozyl-na-Aforti-Holding-ponad-790-tys-zl-kary-za-wprowadzanie-konsumentow-w-blad-8597617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UOKiK-nalozyl-na-Aforti-Holding-ponad-790-tys-zl-kary-za-wprowadzanie-konsumentow-w-blad-8597617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T07:41:17.932322+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/3/7bb21a33a67b17-945-560-3-7-1226-735.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Urząd Ochrony Konkurencji i Konsumentów uznał, że Aforti Holding, który namawiał do zainwestowania w „ofertę wekslową”, złamała prawo i nałożył na spółkę ponad 790 tys. zł  kary za wprowadzanie konsumentów w błąd  - podał UOKiK w komunikacie.</p>

## Spotify osiągnął rekordową liczbę użytkowników, ale bez większego wzrostu przychodów
 - [https://www.bankier.pl/wiadomosc/Spotify-osiagnal-rekordowa-liczbe-uzytkownikow-ale-bez-wiekszego-wzrostu-przychodow-8597583.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spotify-osiagnal-rekordowa-liczbe-uzytkownikow-ale-bez-wiekszego-wzrostu-przychodow-8597583.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T07:41:17.914136+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/d/3c03e527ac6b85-948-568-0-123-1972-1183.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spotify osiągnął rekordową liczbę aktywnych użytkowników - 551 mln miesięcznie na całym świecie. W drugim kwartale bieżącego roku firma zyskała aż 36 milionów nowych słuchaczy, co stanowi trzykrotnie większy wzrost niż ten zanotowany w analogicznym okresie rok temu. Jednak za wzrostem użytkowników nie idzie przychód.</p>

## Żniwa na finiszu, ale rosną obawy o jakość zboża
 - [https://www.bankier.pl/wiadomosc/Zbiory-zboz-na-finiszu-rosna-obawy-o-jego-jakosc-8597596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zbiory-zboz-na-finiszu-rosna-obawy-o-jego-jakosc-8597596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T07:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/f90388ed261a16-948-568-0-177-3947-2368.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zbiory zbóż na finiszu, rosną obawy o jego jakość - poinformowała Izba Zbożowo-Paszowa.</p>

## Za zbieranie grzybów można dostać mandat. Nawet 5000 zł
 - [https://www.bankier.pl/wiadomosc/Za-zbieranie-grzybow-mozna-dostac-mandat-Nawet-5000-zl-8597586.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Za-zbieranie-grzybow-mozna-dostac-mandat-Nawet-5000-zl-8597586.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T07:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/0ffc31e8b3c4e4-948-568-14-0-2938-1762.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Końcówka lata i początek jesieni to okresy, kiedy Polacy tłumnie ruszają do lasów w poszukiwaniu grzybów. Choć często traktuje się to jako coś oczywistego, to warto wiedzieć, że brak znajomości przepisów podczas grzybobrania może być kosztowny. Kwoty mandatów są wysokie i istnieje spora szansa, że nawet udane zbiory nie będą w stanie ich zrekompensować. 
</p>

## Zamrożone aktywa Iranu wędrowały przez pół świata. To część umowy z USA
 - [https://www.bankier.pl/wiadomosc/Zamrozone-aktywa-Iranu-wedrowaly-przez-pol-swiata-To-czesc-umowy-z-USA-8597582.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zamrozone-aktywa-Iranu-wedrowaly-przez-pol-swiata-To-czesc-umowy-z-USA-8597582.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T06:36:15.626958+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/ba48b7a298b59c-948-568-0-112-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zamrożone w Korei Płd. aktywa Iranu zostały przekazane do szwajcarskiego banku centralnego w ubiegłym tygodniu w celu wymiany waluty i udostępnienia tych aktywów z powrotem władzom w Teheranie w ramach umowy zawartej z USA - podała w poniedziałek południowokoreańska agencja Yonhap Infomax.</p>

## Lotniska w Moskwie zawiesiły loty. Winny ma być ukraiński dron
 - [https://www.bankier.pl/wiadomosc/Lotniska-w-Moskwie-zawiesily-loty-Winny-ma-byc-ukrainski-dron-8597580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lotniska-w-Moskwie-zawiesily-loty-Winny-ma-byc-ukrainski-dron-8597580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T06:36:15.619356+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/368e336d54a28c-948-569-155-250-1791-1075.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Moskwie w poniedziałek na lotnisku Domodiedowo czasowo ograniczono przyloty i odloty, a inny port lotniczy w rosyjskiej stolicy - Wnukowo całkiem zawiesił loty - podała agencja Reutera. Później rejsy wznowiono.</p>

## Koniec z blokowaniem innych. X (Twitter) wywarza drzwi wolności słowa
 - [https://www.bankier.pl/wiadomosc/Koniec-z-blokowaniem-innych-X-Twitter-wywarza-drzwi-wolnosci-slowa-8597574.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-blokowaniem-innych-X-Twitter-wywarza-drzwi-wolnosci-slowa-8597574.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T06:36:15.596195+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/7df7fc155aeeec-948-568-0-9-3584-2150.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Funkcja blokowania innych użytkowników na swoim profilu zostanie usunięta, bo nie ma ona sensu - tak napisał Elon Musk. Nadal za to można będzie blokować od nich wiadomości bezpośrednie. To najnowsza ze zmian, jaką miliarder wprowadza od czasu przejęcia Twittera (obecnie X), który teraz jest wart jedynie ułamek z 44 mld, które za niego zapłacił. </p>

## Dantejskie sceny w klubach go-go. "47 transakcji na ponad 650 tys. zł od jednego klienta"
 - [https://www.bankier.pl/wiadomosc/Dantejskie-sceny-w-klubach-go-go-47-transakcji-na-ponad-650-tys-zl-od-jednego-klienta-8597557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dantejskie-sceny-w-klubach-go-go-47-transakcji-na-ponad-650-tys-zl-od-jednego-klienta-8597557.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T05:31:23.033121+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/766b651bc20f9a-948-568-0-176-1726-1035.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Klientki, tancerki, kierowniczki lokali, obsługa centrów monitoringu klubów i "czyszczące konta" terminale płatnicze - to postawa oszustw, do których dochodziło w klubach go-go. Policjanci CBŚP zatrzymali kolejnych 20 osób w śledztwie prowadzonym wspólnie z dolnośląskim wydziałem Prokuratury Krajowej.</p>

## Przedsiębiorczy Ukraińcy w Polsce. Otwierają firmy na potęgę
 - [https://www.bankier.pl/wiadomosc/Przedsiebiorczy-Ukraincy-w-Polsce-Otwieraja-firmy-na-potege-8597552.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przedsiebiorczy-Ukraincy-w-Polsce-Otwieraja-firmy-na-potege-8597552.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T05:31:23.030366+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/ee9de7a5a03de1-945-560-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraińcy wciąż chętnie zakładają firmy w Polsce. W ciągu niespełna pięciu miesięcy 2023 roku powstało ich niewiele mniej niż w całym 2022 roku, ponad 13 tys. w porównaniu do niespełna 17,5 tys. Ukraińscy...</p>

## Miliard złotych na "Dobry start". ZUS kontynuuje wypłaty
 - [https://www.bankier.pl/wiadomosc/Miliard-zlotych-na-Dobry-start-ZUS-kontynuuje-wyplaty-8597538.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Miliard-zlotych-na-Dobry-start-ZUS-kontynuuje-wyplaty-8597538.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T05:12:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/b/3d830c4ec78832-948-568-0-187-3120-1871.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zakład Ubezpieczeń Społecznych wypłacił do tej pory 1 mld zł na wyprawkę szkolną w ramach programu "Dobry start". Wypłaty po 300 zł objęły dotąd 3,3 mln dzieci. Przygotowywane są kolejne przelewy – przekazał w poniedziałek ZUS. Termin składania wniosków upływa 30 listopada.</p>

## Dramatyczna sytuacja szkół. Wciąż brakuje ponad 24 tys. nauczycieli
 - [https://www.bankier.pl/wiadomosc/Dramatyczna-sytuacja-szkol-Wciaz-brakuje-ponad-24-tys-nauczycieli-8596636.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dramatyczna-sytuacja-szkol-Wciaz-brakuje-ponad-24-tys-nauczycieli-8596636.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T04:26:11.525932+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/9bf5aecef785f7-948-568-0-136-2736-1641.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sytuacja szkół w Polce jest trudna. Na dwa tygodnie przed początkiem nowego roku szkolnego w placówkach oświaty w całym kraju brakuje blisko 21,2 tys. belfrów. Najbardziej poszukiwani nauczyciele to wychowawcy przedszkolni. Brakuje również wielu psychologów i pedagogów.</p>

## Hipoteczny tetris. Czy „Bezpieczny kredyt” można nadpłacić, a mieszkanie wynająć? Trzeba uważać, żeby nie stracić dopłat do rat
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-mozna-nadplacac-Wynajem-mieszkania-jest-mozliwy-8595238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-mozna-nadplacac-Wynajem-mieszkania-jest-mozliwy-8595238.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T04:26:11.522782+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/ac6b0c039cc5a4-948-568-20-250-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niektóre osoby planujące zaciągnięcie „Bezpiecznego kredytu 2 proc.” zastanawiają się, czy raty zobowiązania będzie można nadpłacać, nie ryzykując utraty dopłat. Ustawa przewiduje pewne wyjątki w tym zakresie. Ważne są jednak terminy i kwoty nadpłat.</p>

## Na Teneryfie spłonęła ponad połowa drzewostanu. "To skutek celowych działań"
 - [https://www.bankier.pl/wiadomosc/Na-Teneryfie-splonela-ponad-polowa-drzewostanu-To-skutek-celowych-dzialan-8597527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-Teneryfie-splonela-ponad-polowa-drzewostanu-To-skutek-celowych-dzialan-8597527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T01:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/b3cd6b2e52da6b-948-568-0-202-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na Teneryfie spłonęło od wtorku do niedzieli 13 tys. hektarów lasów. To największy w historii tej kanaryjskiej wyspy obszar zajęty przez ogień - podała w niedzielę wieczorem lokalna obrona cywilna.</p>

## Pożar fabryki opon w Dębicy. Ogień gasiło 140 strażaków
 - [https://www.bankier.pl/wiadomosc/Pozar-fabryki-opon-w-Debicy-Ogien-gasilo-140-strazakow-8597525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pozar-fabryki-opon-w-Debicy-Ogien-gasilo-140-strazakow-8597525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-08-21T00:29:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/8/f730eb947798ca-948-568-0-97-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W niedziele późnym wieczorem w hali produkcyjnej firmy oponiarskiej w Dębicy wybuchł pożar. Gasiło go 30 zastępów Państwowej Straży Pożarnej i Ochotniczych Straży Pożarnych - poinformował PAP bryg. Marcin Betleja, rzecznik prasowy Podkarpackiego Komendanta Wojewódzkiego PSP. W nocy ogień opanowano.</p>

