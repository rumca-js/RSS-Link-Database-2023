# Source:Jazza, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q, language:en-US

## IT'S OVER - deleting this in an hour...
 - [https://www.youtube.com/watch?v=lxNR73IGLYo](https://www.youtube.com/watch?v=lxNR73IGLYo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCHu2KNu6TtJ0p4hpSW7Yv7Q
 - date published: 2023-08-21T22:57:41+00:00

TIME IS ALMOST UP!
https://www.kickstarter.com/projects/carryallstudio/the-carry-all-studio
Thanks everyone who has backed this on Kickstarter, it's a huge success and I'm incredibly grateful!

