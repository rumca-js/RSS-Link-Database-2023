# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Spain's victorious Women's World Cup side parade trophy through Madrid
 - [https://news.sky.com/story/a-heros-welcome-spains-victorious-womens-world-cup-side-parade-trophy-through-madrid-12944869](https://news.sky.com/story/a-heros-welcome-spains-victorious-womens-world-cup-side-parade-trophy-through-madrid-12944869)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T22:31:00+00:00

Spain began their reign as Women's World Cup champions by arriving home to a hero's welcome on the streets of Madrid.

## French airport to be renamed after Queen Elizabeth II
 - [https://news.sky.com/story/french-airport-to-be-renamed-after-queen-elizabeth-ii-12944835](https://news.sky.com/story/french-airport-to-be-renamed-after-queen-elizabeth-ii-12944835)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T20:40:00+00:00

An airport in France is being named after Queen Elizabeth.

## Triathlon Ireland says it did not 'sanction' Ironman swim race in which two men died
 - [https://news.sky.com/story/triathlon-ireland-says-it-did-not-sanction-ironman-swim-race-in-which-two-men-died-in-co-cork-12944826](https://news.sky.com/story/triathlon-ireland-says-it-did-not-sanction-ironman-swim-race-in-which-two-men-died-in-co-cork-12944826)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T20:22:00+00:00

Triathlon Ireland has said its officials did not sanction a swimming race in which two competitors died.

## Palm Springs cut off as desert Californian city deluged by Tropical Storm Hilary
 - [https://news.sky.com/story/palm-springs-cut-off-as-desert-californian-city-deluged-by-storm-hilary-12944805](https://news.sky.com/story/palm-springs-cut-off-as-desert-californian-city-deluged-by-storm-hilary-12944805)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T19:45:00+00:00

The Californian desert city of Palm Springs has been cut off after Tropical Storm Hilary flooded streets and brought down power lines across southern parts of the Golden State.

## 'Bubbly and confident': School pays tribute to 10-year-old girl found dead at home
 - [https://news.sky.com/story/sara-sharif-school-says-10-year-old-girl-found-dead-in-woking-was-bubbly-and-confident-pupil-12944806](https://news.sky.com/story/sara-sharif-school-says-10-year-old-girl-found-dead-in-woking-was-bubbly-and-confident-pupil-12944806)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T19:42:00+00:00

A 10-year-old girl found dead at her home in Woking has been described as a "bubbly and confident" pupil by her headteacher.

## Original voice of Mario in Nintendo games steps down after 27 years
 - [https://news.sky.com/story/charles-martinet-original-voice-of-mario-in-nintendo-games-steps-down-after-27-years-12944780](https://news.sky.com/story/charles-martinet-original-voice-of-mario-in-nintendo-games-steps-down-after-27-years-12944780)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T19:12:00+00:00

The original voice of Mario in Nintendo's video games is stepping down.

## Russian space agency boss blames decades of inactivity for moon crash
 - [https://news.sky.com/story/russian-space-agency-boss-blames-decades-of-inactivity-for-luna-25-moon-crash-12944777](https://news.sky.com/story/russian-space-agency-boss-blames-decades-of-inactivity-for-luna-25-moon-crash-12944777)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T19:05:00+00:00

The head of Russia's space agency has blamed the Luna-25 spacecraft crashing into the moon on the country's decades-long pause in lunar exploration.

## Inquiry into claims of unlawful killings by UK soldiers in Afghanistan to be held partly in secret
 - [https://news.sky.com/story/public-inquiry-into-allegations-of-unlawful-killings-by-british-soldiers-in-afghanistan-to-be-held-partly-in-secret-12944744](https://news.sky.com/story/public-inquiry-into-allegations-of-unlawful-killings-by-british-soldiers-in-afghanistan-to-be-held-partly-in-secret-12944744)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T18:01:00+00:00

A public inquiry into allegations of war crimes by British armed forces in Afghanistan will be held partly in secret, the chair has decided.

## Hospital patients evacuate onto ferry after burned body recovered as fresh fires hit Greece
 - [https://news.sky.com/story/wildfires-in-greece-force-hospital-patients-to-evacuate-onto-a-ferry-after-burned-body-found-12944687](https://news.sky.com/story/wildfires-in-greece-force-hospital-patients-to-evacuate-onto-a-ferry-after-burned-body-found-12944687)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T16:15:00+00:00

One person has died and dozens have been evacuated from a hospital onto a boat as wildfires scorch a portion of northeastern mainland Greece.

## Spain's FA chief says sorry after kissing player on the lips following their World Cup victory
 - [https://news.sky.com/story/womens-world-cup-spains-fa-chief-luis-rubiales-says-sorry-after-kissing-jennifer-hermoso-on-the-lips-following-victory-12944604](https://news.sky.com/story/womens-world-cup-spains-fa-chief-luis-rubiales-says-sorry-after-kissing-jennifer-hermoso-on-the-lips-following-victory-12944604)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T13:27:00+00:00

The head of Spain's football federation has apologised after kissing a player on the lips following their Women's World Cup victory.

## Lionesses' online popularity climbs despite heartbreak in Women's World Cup final
 - [https://news.sky.com/story/lionesses-online-popularity-climbs-despite-heartbreak-in-womens-world-cup-final-12944576](https://news.sky.com/story/lionesses-online-popularity-climbs-despite-heartbreak-in-womens-world-cup-final-12944576)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T12:24:00+00:00

The Lionesses may not have clinched the Women's World Cup after losing to Spain in the final, but interest in England's star players has not wavered as their online following continues to grow.

## 850 people still missing after Hawaii wildfires
 - [https://news.sky.com/story/hawaii-wildfires-850-people-still-missing-after-blaze-ripped-through-maui-12944534](https://news.sky.com/story/hawaii-wildfires-850-people-still-missing-after-blaze-ripped-through-maui-12944534)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T10:50:00+00:00

A total of 850 people are still missing following deadly wildfires in Maui, Hawaii, the county's mayor has said.

## Saudi Arabia border guards likely killed hundreds of unarmed migrants in recent years, report claims
 - [https://news.sky.com/story/saudi-arabia-border-guards-likely-killed-hundreds-of-unarmed-migrants-crossing-from-yemen-in-recent-years-report-claims-12944443](https://news.sky.com/story/saudi-arabia-border-guards-likely-killed-hundreds-of-unarmed-migrants-crossing-from-yemen-in-recent-years-report-claims-12944443)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T08:30:00+00:00

Saudi Arabian border guards launched mortars and fired machine guns at Ethiopians trying to cross into the country from Yemen and likely killed hundreds of unarmed migrants in recent years, a new report has claimed.

## Deadly Storm Hilary brings 'life-threatening' floods and record rainfall to California
 - [https://news.sky.com/story/one-dead-in-mexico-as-storm-hilary-brings-life-threatening-floods-and-record-rainfall-to-california-12944367](https://news.sky.com/story/one-dead-in-mexico-as-storm-hilary-brings-life-threatening-floods-and-record-rainfall-to-california-12944367)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T05:46:00+00:00

One person has died and another is missing as a tropical storm brings "life-threatening" floods and record rainfall to Mexico and California.

## India announces moon lander days from touching down - as Russian craft crashes
 - [https://news.sky.com/story/india-announces-moon-lander-days-from-touching-down-as-russian-craft-crashes-12944340](https://news.sky.com/story/india-announces-moon-lander-days-from-touching-down-as-russian-craft-crashes-12944340)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-08-21T01:44:00+00:00

India could be about to take one giant leap ahead of Russia in the space race - with its latest lunar mission just days away from attempting to land.

