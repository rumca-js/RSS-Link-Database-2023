# Source:Warhammer, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg, language:en-US

## Cities of Sigmar Miniatures Interview – Warhammer Age of Sigmar
 - [https://www.youtube.com/watch?v=s674KdlLLYI](https://www.youtube.com/watch?v=s674KdlLLYI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-21T14:00:51+00:00

Discover how the new Cities of Sigmar miniatures were created. Learn even more about the new range: https://ow.ly/6oaK50PBqQY

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Learn to Paint: Warhammer Heroes
 - [https://www.youtube.com/watch?v=BD1FJ6ekfS4](https://www.youtube.com/watch?v=BD1FJ6ekfS4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-21T14:00:47+00:00

Follow this step by step guide to learn how to paint Brother Vignius from Warhammer Heroes. He'll be ready to join the rest of Strike Force Justian on the gaming table in no time at all!

If you're new to painting - check out our Citadel Colour Painting Essentials videos to learn all about it: http://warhammer.me/3Vkojs6

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Coming Soon – Warhammer Preview Online: NOVA Open 2023
 - [https://www.youtube.com/watch?v=kcYoRI26sM0](https://www.youtube.com/watch?v=kcYoRI26sM0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-21T11:02:48+00:00

We're heading to the NOVA Open! See how you can catch all the big reveals live: https://bit.ly/3E6jKvg

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

## Da Biggest Boss – Warhammer Age of Sigmar
 - [https://www.youtube.com/watch?v=iOEcZSXefPI](https://www.youtube.com/watch?v=iOEcZSXefPI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwdh3MTrFq3sXlB4ct8B-Fg
 - date published: 2023-08-21T11:00:28+00:00

Look out Mortal Realms – Klonk is here! Learn more about the new anvil Squig and his big green friend: https://bit.ly/3E6jKvg

Follow for more Warhammer:
- Twitter: https://twitter.com/warhammer
- Facebook: https://www.facebook.com/WarhammerOfficial/
- Instagram: https://www.instagram.com/warhammerofficial/
- Warhammer Community: https://www.warhammer-community.com/ 

Don't forget to like, share and subscribe and to ring the bell to make sure you keep up to date with all our latest videos!

