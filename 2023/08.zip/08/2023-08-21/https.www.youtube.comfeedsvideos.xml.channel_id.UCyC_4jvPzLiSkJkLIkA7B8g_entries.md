# Source:Lindsey Stirling, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g, language:en-US

## Lindsey Stirling - Snow Waltz Tour 2023 Coming Soon! #SnowWaltzTour #lindseystirling
 - [https://www.youtube.com/watch?v=C2o0QtuNbks](https://www.youtube.com/watch?v=C2o0QtuNbks)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyC_4jvPzLiSkJkLIkA7B8g
 - date published: 2023-08-21T14:00:12+00:00

It’s an (early) Christmas miracle - the 2023 Snow Waltz Tour is ON! Sign up for pre-sale access at lindseystirling.com to grab tickets before they’re available to the public this Friday (8/25) at 10am local!

Donate to The Upside Fund: https://www.lindseystirling.com/theup...
Learn more about "Crystallize" Lindsey Stirling Signature Yamaha Violin https://found.ee/LS_Violin

Follow me here:
https://www.facebook.com/lindseystirl...
https://twitter.com/LindseyStirling
http://www.instagram.com/LindseyStirling
http://www.tiktok.com/@lindseystirling
http://www.lindseystirling.com

Sheet Music Here: https://lindseystirlingsheetmusic.com
Join my Discord: https://discord.gg/lindseystirling

Sign up for my super-cool newsletter here:
https://found.ee/lindsey_newsletter

