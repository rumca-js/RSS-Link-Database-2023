# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## Baldur's Gate 3 modder enchants Gale's underwear with one of the most devastating spells in Dungeons & Dragons
 - [https://www.pcgamer.com/baldurs-gate-3-modder-enchants-gales-underwear-with-one-of-the-most-devastating-spells-in-dungeons-and-dragons](https://www.pcgamer.com/baldurs-gate-3-modder-enchants-gales-underwear-with-one-of-the-most-devastating-spells-in-dungeons-and-dragons)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T22:14:33+00:00

Does it hurt when it goes off?

## Why people are talking about Starfield's start screen: Gaming's latest Twitter dust-up, explained
 - [https://www.pcgamer.com/why-people-are-talking-about-starfields-start-screen-gamings-latest-twitter-dust-up-explained](https://www.pcgamer.com/why-people-are-talking-about-starfields-start-screen-gamings-latest-twitter-dust-up-explained)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T20:50:08+00:00

Bethesda head of publishing Pete Hines defended the Starfield team after a former game dev criticized the startup menu.

## Forget movie night, Samsung is making the first portable projector with built-in cloud gaming
 - [https://www.pcgamer.com/forget-movie-night-samsung-is-making-the-first-portable-projector-with-built-in-cloud-gaming](https://www.pcgamer.com/forget-movie-night-samsung-is-making-the-first-portable-projector-with-built-in-cloud-gaming)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T20:02:47+00:00

Bring 100 inches of cloud gaming goodness anywhere without lugging around a TV.

## Slime Rancher is becoming a film
 - [https://www.pcgamer.com/slime-rancher-is-becoming-a-film](https://www.pcgamer.com/slime-rancher-is-becoming-a-film)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T16:14:52+00:00

In a world where slime roams free, one woman's job is to ranch it.

## You'd be forgiven for thinking this gorgeously-animated Elden Ring lore video was official
 - [https://www.pcgamer.com/youd-be-forgiven-for-thinking-this-gorgeously-animated-elden-ring-lore-video-was-official](https://www.pcgamer.com/youd-be-forgiven-for-thinking-this-gorgeously-animated-elden-ring-lore-video-was-official)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T16:07:29+00:00

The loremasters have grown too powerful.

## Leaked Logitech G Pro X Superlight 2 sheds even more weight
 - [https://www.pcgamer.com/leaked-logitech-g-pro-x-superlight-2-sheds-even-more-weight](https://www.pcgamer.com/leaked-logitech-g-pro-x-superlight-2-sheds-even-more-weight)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T15:42:50+00:00

Lighter in the hand, heavier on your wallet.

## Dark and Darker pledges to fight back against cheaters with a Discord bot with a 30-day lifespan
 - [https://www.pcgamer.com/dark-and-darker-pledges-to-fight-back-against-cheaters-with-a-discord-bot-with-a-30-day-lifespan](https://www.pcgamer.com/dark-and-darker-pledges-to-fight-back-against-cheaters-with-a-discord-bot-with-a-30-day-lifespan)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T15:39:20+00:00

The anticheat that burns twice as bright lives, well, for exactly one month.

## How to open the Sorcerous Vault in Baldur's Gate 3
 - [https://www.pcgamer.com/baldurs-gate-3-sorcerous-vault-door-puzzle](https://www.pcgamer.com/baldurs-gate-3-sorcerous-vault-door-puzzle)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T15:38:12+00:00

Solve the door puzzle to gain access to Lorroakan's treasure.

## 'Absolute Evil' simulator Dungeons 4 is coming in November, here's our first look at gameplay
 - [https://www.pcgamer.com/absolute-evil-simulator-dungeons-4-is-coming-in-november-heres-our-first-look-at-gameplay](https://www.pcgamer.com/absolute-evil-simulator-dungeons-4-is-coming-in-november-heres-our-first-look-at-gameplay)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T15:01:22+00:00

Build your dungeon, rule your minions, and inflict your evil on the innocence of the overworld.

## The Metal Gear Solid Master Collection is packed with bonuses, but the barebones ports offer little that PC emulators don't already do better
 - [https://www.pcgamer.com/the-metal-gear-solid-master-collection-is-packed-with-bonuses-but-the-barebones-ports-offer-little-that-pc-emulators-dont-already-do-better](https://www.pcgamer.com/the-metal-gear-solid-master-collection-is-packed-with-bonuses-but-the-barebones-ports-offer-little-that-pc-emulators-dont-already-do-better)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T14:44:10+00:00

Great games with great extras, but there was potential for so much more than ports of games locked at 720p.

## Desperate GTA fan erupts onto unrelated TV show in quest for GTA 6 info, gets doused by a water bottle
 - [https://www.pcgamer.com/desperate-gta-fan-erupts-onto-unrelated-tv-show-in-quest-for-gta-6-info-gets-doused-by-a-water-bottle](https://www.pcgamer.com/desperate-gta-fan-erupts-onto-unrelated-tv-show-in-quest-for-gta-6-info-gets-doused-by-a-water-bottle)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T14:43:18+00:00

The truth is out there.

## Konami ties itself up in knots trying to clarify whether the Metal Gear Solid collection will have mouse and keyboard support, but it seems like a yes
 - [https://www.pcgamer.com/konami-ties-itself-up-in-knots-trying-to-clarify-whether-the-metal-gear-solid-collection-will-have-mouse-and-keyboard-support-but-it-seems-like-a-yes](https://www.pcgamer.com/konami-ties-itself-up-in-knots-trying-to-clarify-whether-the-metal-gear-solid-collection-will-have-mouse-and-keyboard-support-but-it-seems-like-a-yes)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T14:42:55+00:00

Kept you waiting huh.

## Elon Musk says blocking, a feature both Apple and Google require on social apps, 'makes no sense'
 - [https://www.pcgamer.com/elon-musk-says-blocking-a-feature-both-apple-and-google-require-on-social-apps-makes-no-sense](https://www.pcgamer.com/elon-musk-says-blocking-a-feature-both-apple-and-google-require-on-social-apps-makes-no-sense)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T13:38:03+00:00

X gonn' remove basic functionality.

## Fresh off a fantastic Quake 2 remaster, Nightdive would once again like Tim Sweeney to know it's ready and eager to do the same to Unreal
 - [https://www.pcgamer.com/fresh-off-a-fantastic-quake-2-remaster-nightdive-would-once-again-like-tim-sweeney-to-know-its-ready-and-eager-to-do-the-same-to-unreal](https://www.pcgamer.com/fresh-off-a-fantastic-quake-2-remaster-nightdive-would-once-again-like-tim-sweeney-to-know-its-ready-and-eager-to-do-the-same-to-unreal)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T13:29:25+00:00

The studio has Cliff Bleszinski's backing, too.

## Grab yourself a 48-inch 4K LG OLED for a ridiculous $650
 - [https://www.pcgamer.com/grab-yourself-a-48-inch-4k-lg-oled-for-a-ridiculous-dollar650](https://www.pcgamer.com/grab-yourself-a-48-inch-4k-lg-oled-for-a-ridiculous-dollar650)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T12:04:49+00:00

It's not the newest model, but it makes OLED monitors look a bit silly.

## The next game from the Battle Brothers devs is a sci-fi tactical RPG that 'takes everything beloved' about their last game and 'improves it tenfold'
 - [https://www.pcgamer.com/the-next-game-from-the-battle-brothers-devs-is-a-sci-fi-tactical-rpg-that-takes-everything-beloved-about-their-last-game-and-improves-it-tenfold](https://www.pcgamer.com/the-next-game-from-the-battle-brothers-devs-is-a-sci-fi-tactical-rpg-that-takes-everything-beloved-about-their-last-game-and-improves-it-tenfold)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T12:00:00+00:00

Menace says it will "shake up the current norms of turn-based tactics games."

## How to solve the Sarin skeleton puzzle in Baldur's Gate 3
 - [https://www.pcgamer.com/baldurs-gate-3-sarin-skeleton-solution](https://www.pcgamer.com/baldurs-gate-3-sarin-skeleton-solution)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T11:21:18+00:00

Locate the missing skull and stick it back on Sarin's skeleton.

## By Tymora, it's time we recognised Baldur's Gate 3 is one of the greatest video game events ever
 - [https://www.pcgamer.com/by-tymora-its-time-we-recognised-baldurs-gate-3-is-one-of-the-greatest-video-game-events-ever](https://www.pcgamer.com/by-tymora-its-time-we-recognised-baldurs-gate-3-is-one-of-the-greatest-video-game-events-ever)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T11:17:42+00:00

It's time to step back and appreciate we're living through a seminal moment in the history of gaming

## Astarion's voice actor directed Baldur's Gate 3's infamous bear scene: 'I did not know they were gonna use Astarion as the model'
 - [https://www.pcgamer.com/astarions-voice-actor-directed-baldurs-gate-3s-infamous-bear-scene-i-did-not-know-they-were-gonna-use-astarion-as-the-model](https://www.pcgamer.com/astarions-voice-actor-directed-baldurs-gate-3s-infamous-bear-scene-i-did-not-know-they-were-gonna-use-astarion-as-the-model)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T11:09:58+00:00

Neil Newbon also talked to me about biting, thirst, and the game's intimacy direction.

## AMD preps RTX 4060-slaying 6750 GRE graphics card for $299 according to report
 - [https://www.pcgamer.com/amd-preps-rtx-4060-slaying-6750-gre-graphics-card-for-dollar299-according-to-report](https://www.pcgamer.com/amd-preps-rtx-4060-slaying-6750-gre-graphics-card-for-dollar299-according-to-report)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T09:59:19+00:00

Nice idea, but will it be widely available?

## Today's Wordle hint and answer #793: Monday, August 21
 - [https://www.pcgamer.com/wordle-answer-today-hint-793-august-21](https://www.pcgamer.com/wordle-answer-today-hint-793-august-21)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T03:05:44+00:00

Today's Wordle: Help with solving Monday's puzzle.

## Five new Steam games you probably missed (August 21, 2023)
 - [https://www.pcgamer.com/five-new-steam-games-you-probably-missed-august-21-2023](https://www.pcgamer.com/five-new-steam-games-you-probably-missed-august-21-2023)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T01:57:43+00:00

Sorting through every new game on Steam so you don't have to.

## Sling cards to save the planet in this free ecological strategy game
 - [https://www.pcgamer.com/sling-cards-to-save-the-planet-in-this-free-ecological-strategy-game](https://www.pcgamer.com/sling-cards-to-save-the-planet-in-this-free-ecological-strategy-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-08-21T00:54:18+00:00

The real-time card game has you finding a path to survive climate change

