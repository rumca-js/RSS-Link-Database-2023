# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Przyjaźń i braterstwo to największe bogactwo – wyjątkowy zestaw monet kolekcjonerskich NBP i NBU
 - [https://www.wirtualnemedia.pl/artykul/przyjazn-i-braterstwo-to-najwieksze-bogactwo-wyjatkowy-zestaw-monet-kolekcjonerskich-nbp-nbu](https://www.wirtualnemedia.pl/artykul/przyjazn-i-braterstwo-to-najwieksze-bogactwo-wyjatkowy-zestaw-monet-kolekcjonerskich-nbp-nbu)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T14:38:46.930700+00:00

24 sierpnia Narodowy Bank Polski i Narodowy Bank Ukrainy wprowadzają do obiegu srebrne monety kolekcjonerskie tworzące zestaw „Przyjaźń i braterstwo to największe bogactwo”.

## W lipcu spadek realnych wynagrodzeń. "Płace będą rosły wolniej niż inflacja"
 - [https://www.wirtualnemedia.pl/artykul/w-lipcu-spadek-realnych-wynagrodzen-place-beda-rosly-wolniej-niz-inflacja](https://www.wirtualnemedia.pl/artykul/w-lipcu-spadek-realnych-wynagrodzen-place-beda-rosly-wolniej-niz-inflacja)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T11:22:16.275165+00:00

Nasze prognozy wzrostu wynagrodzeń nie są tak optymistyczne, jak te rynkowe. Płace będą rosły, ale wolniej niż inflacja, co już zachodzi – ocenił ekspert ekonomiczny Konfederacji Lewiatan Mariusz Zielonka w komentarzu do poniedziałkowych danych GUS.

## Płytki krwi mogą naśladować korzystny wpływ ćwiczeń na mózg
 - [https://www.wirtualnemedia.pl/artykul/plytki-krwi-korzystny-wplyw-cwiczen-na-mozg-jak-dziala](https://www.wirtualnemedia.pl/artykul/plytki-krwi-korzystny-wplyw-cwiczen-na-mozg-jak-dziala)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T07:05:49.784327+00:00

Płytki krwi wydzielają białko, które odmładza neurony w mózgu myszy w podobny sposób, jak ćwiczenia fizyczne - wynika z badania, które pokazało „Nature Communications”.

## Chińskie firmy pomagają Rosji obchodzić wojenne sankcje
 - [https://www.wirtualnemedia.pl/artykul/chinskie-firmy-pomagaja-rosji-obchodzic-wojenne-sankcje](https://www.wirtualnemedia.pl/artykul/chinskie-firmy-pomagaja-rosji-obchodzic-wojenne-sankcje)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T05:57:08.763881+00:00

Chiny pomagają zaopatrywać Rosję w helikoptery, drony, celowniki optyczne i kluczowe metale wykorzystywane przez przemysł obronny. Od początku wojny rosyjskie firmy otrzymały z Chin dziesiątki tysięcy przesyłek - podaje "Sunday Telegraph".

## Pożar pochłonął połowę lasów na Teneryfie
 - [https://www.wirtualnemedia.pl/artykul/pozar-pochlonal-polowe-lasow-na-teneryfie](https://www.wirtualnemedia.pl/artykul/pozar-pochlonal-polowe-lasow-na-teneryfie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T05:57:08.761557+00:00

Na Teneryfie spłonęło od wtorku do niedzieli 13 tys. hektarów lasów. To największy w historii tej kanaryjskiej wyspy obszar zajęty przez ogień - podała w niedzielę wieczorem lokalna obrona cywilna.

## Co z porzuconymi polami? Ekspertka przestrzega przed inwazją nawłoci
 - [https://www.wirtualnemedia.pl/artykul/pola-w-polsce-inwazja-nawloci](https://www.wirtualnemedia.pl/artykul/pola-w-polsce-inwazja-nawloci)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T05:57:08.757016+00:00

Pozostawianie w naszym kraju porzuconych ziem porolnych samym sobie wcale nie jest dobrym rozwiązaniem dla przyrody. Już lepsze jest prowadzenie tam ekstensywnej gospodarki rolnej. Opuszczone tereny szybko padają ofiarą inwazji choćby nawłoci kanadyjskiej, która niszczy bioróżnorodność - mówi ekspertka z Instytutu Ochrony Przyrody PAN.

## Wkrótce ma zostać powołany zespół dla Układu Zbiorowego Pracy dla Grupy PKP
 - [https://www.wirtualnemedia.pl/artykul/praca-pkp-zarobki-podwyzka](https://www.wirtualnemedia.pl/artykul/praca-pkp-zarobki-podwyzka)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-08-21T05:57:08.752320+00:00

W najbliższym czasie zostanie powołany zespół składający się z przedstawicieli spółek, którego celem będzie wypracowanie Ponadzakładowego Układu Zbiorowego Pracy, który obejmie pracowników całej Grupy PKP - powiedział prezes PKP S.A. Krzysztof Mamiński. Dodał, że do 2030 roku założono przebudowę kolejnych 150 dworców w całym kraju, ale analizami pod kątem potrzeb inwestycyjnych objęto łącznie ponad 300 obiektów. Wstępnie szacowana wartość programu to około 4,4 mld zł brutto.

