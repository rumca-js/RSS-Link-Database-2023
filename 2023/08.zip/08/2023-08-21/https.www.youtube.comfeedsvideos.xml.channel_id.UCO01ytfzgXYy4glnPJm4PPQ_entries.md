# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## DeSantis on Trump Supporters
 - [https://www.youtube.com/watch?v=KPjOtdmaArU](https://www.youtube.com/watch?v=KPjOtdmaArU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-21T23:30:04+00:00



## Should Judy Garland Be Canceled For This?
 - [https://www.youtube.com/watch?v=By_J8281bro](https://www.youtube.com/watch?v=By_J8281bro)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-21T21:00:05+00:00

Additional Savings on a 3-month Emergency Food Kit at http://www.preparewithwalsh.com/ 

Judy Garland has found herself in trouble for something she did when she was a child decades ago.

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1209 - https://bit.ly/3QKBLXx 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Men Don't Do Anything
 - [https://www.youtube.com/watch?v=7UUuB44xKbs](https://www.youtube.com/watch?v=7UUuB44xKbs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-08-21T01:45:00+00:00



