# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Brief History Of LibreOffice & OpenOffice
 - [https://www.youtube.com/watch?v=d3iCNJWnZ1k](https://www.youtube.com/watch?v=d3iCNJWnZ1k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-08-21T21:00:18+00:00

Nowadays the open office space is dominated by Libre Office but this is absolutely not the start of the project, there were a bunch of projects before it that it forked from most notably Open Office but our history goes back before Microsoft Office.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
LibreOffice: https://www.libreoffice.org/
Apache OpenOffice: https://www.openoffice.org/
NeoOffice: https://www.neooffice.org/neojava/en/index.php

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://brodierobertson.xyz/twitter
🌐 Mastodon: https://brodierobertson.xyz/mastodon
🖥️ GitHub: https://brodierobertson.xyz/github

==========Credits==========
🎨 Channel Art:
Profile Picture:
https://www.instagram.com/supercozman_draws/

#LibreOffice #OpenOffice #Linux #FOSS #OpenSource

🎵 Ending music
Track: Debris & Jonth - Game Time [NCS Release]
Music provided by NoCopyrightSounds.
Watch:  https://www.youtube.com/watch?v=yDTvvOTie0w 
Free Download / Stream: http://ncs.io/GameTime

DISCLOSURE: Wherever possible I use referral links, which means if you click one of the links in this video or description and make a purchase I may receive a small commission or other compensation.

