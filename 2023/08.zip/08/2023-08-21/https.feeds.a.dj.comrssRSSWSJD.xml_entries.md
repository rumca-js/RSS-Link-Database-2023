# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## How to Prepare Your Phone and Other Tech for a Natural Disaster
 - [https://www.wsj.com/articles/disaster-emergency-prepare-power-out-tips-e031c0bc?mod=rss_Technology](https://www.wsj.com/articles/disaster-emergency-prepare-power-out-tips-e031c0bc?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-08-21T09:30:00+00:00

Having your tech ready to go could save your life during floods, hurricanes and wildfires.

