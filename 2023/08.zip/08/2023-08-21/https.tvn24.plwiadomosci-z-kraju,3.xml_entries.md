# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Pogoda na dziś - wtorek, 22.08. Spora dawka słońca, na termometrach do 32 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-wtorek-2208-spora-dawka-slonca-na-termometrach-do-32-stopni-7301500?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-wtorek-2208-spora-dawka-slonca-na-termometrach-do-32-stopni-7301500?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-22T00:00:00+00:00

<img alt="Pogoda na dziś - wtorek, 22.08. Spora dawka słońca, na termometrach do 32 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tik1s0-upal-goraco-w-warszawie-7290405/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Wtorek 22.08 w wielu regionach kraju upłynie pod znakiem słonecznej aury. Miejscami będzie się chmurzyć i tam też przelotnie popada deszcz. Termometry wskażą maksymalnie od 23 do 32 stopni Celsjusza.

## Czy głosy Polonii są zagrożone? Działacze apelują do władz o zmiany w przepisach
 - [https://fakty.tvn24.pl/fakty-o-swiecie/czy-glosy-polonii-sa-zagrozone-dzialacze-apeluja-do-wladz-o-zmiany-w-przepisach-7301403?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/czy-glosy-polonii-sa-zagrozone-dzialacze-apeluja-do-wladz-o-zmiany-w-przepisach-7301403?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T20:33:35+00:00

<img alt="Czy głosy Polonii są zagrożone? Działacze apelują do władz o zmiany w przepisach" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-n1lap2-2108b079x-fos-los-glosowanie-000712-7301344/alternates/LANDSCAPE_1280" />
    Czy Polacy, którzy chcą głosować za granicą, mają powody do niepokoju? W Kodeksie wyborczym nastąpiły zmiany, za sprawą których zagłosowanie może stać się trudniejsze. I za sprawą których nie ma gwarancji, że wszystkie głosy będą policzone.

## Szef MON: jest zgoda Departamentu Stanu USA na sprzedaż Polsce śmigłowców Apache
 - [https://tvn24.pl/polska/wojsko-polskie-jest-zgoda-usa-na-sprzedaz-polsce-smiglowcow-apache-7301526?source=rss](https://tvn24.pl/polska/wojsko-polskie-jest-zgoda-usa-na-sprzedaz-polsce-smiglowcow-apache-7301526?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T20:04:16+00:00

<img alt="Szef MON: jest zgoda Departamentu Stanu USA na sprzedaż Polsce śmigłowców Apache" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dfh0yw-smiglowiec-apache-6103649/alternates/LANDSCAPE_1280" />
    Departament Stanu USA zatwierdził sprzedaż Polsce 96 śmigłowców uderzeniowych AH-64E Apache - przekazał minister obrony narodowej Mariusz Błaszczak. Jak dodał szef MON, "do czasu zakończenia procedur i dostarczenia do Polski zakupionych śmigłowców, armia USA udostępni nam śmigłowce Apache z własnych zasobów".

## Najwyższy amerykański dowódca na audiencji u papieża Franciszka
 - [https://tvn24.pl/swiat/watykan-general-mark-milley-na-audiencji-u-papieza-franciszka-7301489?source=rss](https://tvn24.pl/swiat/watykan-general-mark-milley-na-audiencji-u-papieza-franciszka-7301489?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T20:00:54+00:00

<img alt="Najwyższy amerykański dowódca na audiencji u papieża Franciszka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bit1yy-papiez-franciszek-i-general-mark-milley-7301424/alternates/LANDSCAPE_1280" />
    Papież Franciszek przyjął w poniedziałek na audiencji przewodniczącego Kolegium Połączonych Szefów Sztabów sił zbrojnych Stanów Zjednoczonych generała Marka Milleya - poinformował Watykan. Tematem rozmowy była między innymi wojna w Ukrainie.

## Trzy śledztwa w sprawie afery mailowej. "Cały czas trwa brudna, wewnętrzna walka"
 - [https://fakty.tvn24.pl/zobacz-fakty/trzy-sledztwa-w-sprawie-afery-mailowej-caly-czas-trwa-brudna-wewnetrzna-walka-7301168?source=rss](https://fakty.tvn24.pl/zobacz-fakty/trzy-sledztwa-w-sprawie-afery-mailowej-caly-czas-trwa-brudna-wewnetrzna-walka-7301168?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:52:55+00:00

<img alt="Trzy śledztwa w sprawie afery mailowej. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-izdepo-tacik-003025-7301170/alternates/LANDSCAPE_1280" />
    Prokuratura prowadzi trzy postępowania w sprawie maili z poczty ministra Dworczyka. Śledztwo dotyczy między innymi "przekroczenia uprawnień przez funkcjonariuszy publicznych wykorzystujących prywatne skrzynki do spraw służbowych". O mailach dowiedzieliśmy się po raz pierwszy ponad dwa lata temu, a o śledztwie teraz - w czasie kampanii wyborczej.

## Sprzedawała dziecięcy plecak, została z pożyczką do spłacenia
 - [https://tvn24.pl/tvnwarszawa/okolice/oszustwo-sprzedawala-dzieciecy-plecak-zostala-z-pozyczka-do-splacenia-7301030?source=rss](https://tvn24.pl/tvnwarszawa/okolice/oszustwo-sprzedawala-dzieciecy-plecak-zostala-z-pozyczka-do-splacenia-7301030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:48:20+00:00

<img alt="Sprzedawała dziecięcy plecak, została z pożyczką do spłacenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4yze3n-odebrala-telefon-od-kobiety-podajacej-sie-za-pracownice-banku-zostala-oszukana-zdj-ilustracyjne-7197958/alternates/LANDSCAPE_1280" />
    Chciała w sieci sprzedać dziecięcy plecak za 30 złotych i szybko znalazła się chętna. 32-latka kliknęła w przesłany jej link i po jakimś czasie na jej konto wpłynęło sześć tysięcy złotych. Pieniądze szybko jednak zniknęły, a kobieta została z pożyczką do spłaty i plecakiem.

## Bus zderzył się z lawetą, kierowcy trafili do szpitala
 - [https://tvn24.pl/tvnwarszawa/najnowsze/szczypiorno-bus-zderzyl-sie-z-laweta-dwie-osoby-w-szpitalu-7301405?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/szczypiorno-bus-zderzyl-sie-z-laweta-dwie-osoby-w-szpitalu-7301405?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:44:08+00:00

<img alt="Bus zderzył się z lawetą, kierowcy trafili do szpitala" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ct8xfe-dwie-osoby-trafily-do-szpitala-7301397/alternates/LANDSCAPE_1280" />
    W poniedziałek wieczorem w okolicy Nowego Dworu Mazowieckiego zderzyły się dwa pojazdy. Kierowcy trafili do szpitala.

## Atak siekierą w Lesznie. Trwają poszukiwania sprawcy
 - [https://tvn24.pl/polska/atak-siekiera-w-lesznie-wielkopolska-trwaja-poszukiwania-sprawcy-7301330?source=rss](https://tvn24.pl/polska/atak-siekiera-w-lesznie-wielkopolska-trwaja-poszukiwania-sprawcy-7301330?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:43:39+00:00

<img alt="Atak siekierą w Lesznie. Trwają poszukiwania sprawcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gr3u97-ulica-obroncow-lwowa-w-lesznie-7301385/alternates/LANDSCAPE_1280" />
    W Lesznie (Wielkopolska) 27-letni mężczyzna został zaatakowany w poniedziałek siekierą – poinformowała aspirant Daria Żmuda z Komendy Miejskiej Policji w Lesznie. Dodała, że poszkodowany otrzymał pomoc medyczną i został zwolniony. - Trwają też czynności zmierzające do zatrzymania sprawcy – zaznaczyła.

## Gill-Piątek: helikopter to nie jest gadżet, który można wypożyczyć sobie na piknik wyborczy
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-black-hawka-zerwal-linie-energetyczna-na-pikniku-hanna-gill-piatek-i-piotr-zgorzelski-komentuja-7301349?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-black-hawka-zerwal-linie-energetyczna-na-pikniku-hanna-gill-piatek-i-piotr-zgorzelski-komentuja-7301349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:36:46+00:00

<img alt="Gill-Piątek: helikopter to nie jest gadżet, który można wypożyczyć sobie na piknik wyborczy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rhswd4-21-1925-fpf-cl-0052-7301315/alternates/LANDSCAPE_1280" />
    Doprowadzono do bardzo niebezpiecznej sytuacji, która mogła się skończyć tragicznie, gdyby ta przerwana sieć miała po prostu w sobie napięcie - mówił w "Faktach po Faktach" w TVN24 wicemarszałek Sejmu Piotr Zgorzelski (PSL). Odniósł się do incydentu z udziałem policyjnego Black Hawka podczas pikniku w Sarnowej Górze. Posłanka Koalicji Obywatelskiej Hanna Gill-Piątek podkreśliła, że "helikopter to nie jest gadżet, który można wypożyczyć sobie na piknik wyborczy".

## Bazgrał po wiacie przystankowej. Nie wiedział, że cały czas jest obserwowany
 - [https://tvn24.pl/tvnwarszawa/bielany/bielany-kasprowicza-bazgral-po-wiacie-przystankowej-nie-wiedzial-ze-caly-czas-jest-obserwowany-7301255?source=rss](https://tvn24.pl/tvnwarszawa/bielany/bielany-kasprowicza-bazgral-po-wiacie-przystankowej-nie-wiedzial-ze-caly-czas-jest-obserwowany-7301255?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:14:30+00:00

<img alt="Bazgrał po wiacie przystankowej. Nie wiedział, że cały czas jest obserwowany" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hizcfe-malunki-na-przystanku-w-nocy-7301248/alternates/LANDSCAPE_1280" />
    Operator monitoringu miejskiego zauważył młodego mężczyznę, który mazał flamastrem po wiacie przystankowej. Skończyło się to dla niego tylko mandatem, bo sam jeszcze tej samej nocy usunął swoje "dzieła".

## Kredyt z dopłatą do raty. Minister podaje najnowsze dane
 - [https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-program-pierwsze-mieszkanie-komentuje-waldemar-buda-7301307?source=rss](https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-program-pierwsze-mieszkanie-komentuje-waldemar-buda-7301307?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:07:59+00:00

<img alt="Kredyt z dopłatą do raty. Minister podaje najnowsze dane" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-paxk3q-mieszkania-blok-kredyt-6047705/alternates/LANDSCAPE_1280" />
    W programie "Pierwsze Mieszkanie" zostało złożonych 32 tysiące wniosków, podpisano ponad dwa tysiące umów na prawie miliard złotych - przekazał minister rozwoju i technologii Waldemar Buda. Średnia kwota Bezpiecznego kredytu 2 procent wyniosła 367 517 złotych. Założono ponad 1 tysiąc Kont Mieszkaniowych.

## PiS wciąż nie załagodził sporu z rolnikami. Magazyny ze zbożem nie zostały opróżnione
 - [https://fakty.tvn24.pl/zobacz-fakty/pis-wciaz-nie-zalagodzil-sporu-z-rolnikami-magazyny-ze-zbozem-nie-zostaly-oproznione-7301179?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pis-wciaz-nie-zalagodzil-sporu-z-rolnikami-magazyny-ze-zbozem-nie-zostaly-oproznione-7301179?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:02:40+00:00

<img alt="PiS wciąż nie załagodził sporu z rolnikami. Magazyny ze zbożem nie zostały opróżnione" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-6uanr3-pluska-papgrzegorz-michalowski-7301184/alternates/LANDSCAPE_1280" />
    Minister rolnictwa zapowiadał, że poda się do dymisji, jeśli nie poradzi sobie ze zbożem zalegającym w magazynach. Nie poradził sobie, choć na dożynkach zapewniał, że kryzys opanował. Ale nie tak to widzą rolnicy, którzy od miesięcy ostrzegali przed kłopotami. Zaskoczeni mogą być też emeryci, jeśli policzyli, kto właściwie ma szansę na pełną wypłatę tak zwanej czternastki.

## Pogoda na jutro - wtorek, 22.08. Nocą może się lokalnie błyskać, w dzień do 32 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2208-noca-moze-sie-lokalnie-blyskac-w-dzien-do-32-stopni-7301254?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-2208-noca-moze-sie-lokalnie-blyskac-w-dzien-do-32-stopni-7301254?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T18:00:44+00:00

<img alt="Pogoda na jutro - wtorek, 22.08. Nocą może się lokalnie błyskać, w dzień do 32 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-az4amx-noca-pojawia-sie-burze-5755354/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na wtorek 22.08. W nocy pojawią się miejscami zanikające burze, a także mgły ograniczające widzialność. Dzień zapowiada się na ogół słoneczny, termometry pokażą maksymalnie 32 stopnie Celsjusza.

## 17-latek dźgnięty nożem w brzuch
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-chcieli-pieniedzy-nastolatkowe-odmowili-17-latek-zostal-powaznie-ranny-w-brzuch-7301259?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-chcieli-pieniedzy-nastolatkowe-odmowili-17-latek-zostal-powaznie-ranny-w-brzuch-7301259?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T17:46:24+00:00

<img alt="17-latek dźgnięty nożem w brzuch" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jsm9dx-interweniowala-straz-miejska-zdjecie-ilustracyjne-7253315/alternates/LANDSCAPE_1280" />
    Do rozboju z użyciem noża doszło w weekend na Ochocie. Młody mężczyzna został ranny w brzuch. Strażnicy miejscy udzielili mu pierwszej pomocy i pomogli policji schwytać jednego z podejrzanych o napad.

## "Obywatele USA przebywający na Białorusi powinni natychmiast wyjechać". Ambasada apeluje
 - [https://tvn24.pl/swiat/bialorus-ambasada-usa-obywatele-stanow-zjednoczonych-przebywajacy-na-bialorusi-powinni-natychmiast-wyjechac-7301199?source=rss](https://tvn24.pl/swiat/bialorus-ambasada-usa-obywatele-stanow-zjednoczonych-przebywajacy-na-bialorusi-powinni-natychmiast-wyjechac-7301199?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T16:55:26+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wrh7gs-minsk-7265728/alternates/LANDSCAPE_1280" />
    Obywatele USA, którzy przebywają na Białorusi, "powinni natychmiast wyjechać" - oznajmiła ambasada Stanów Zjednoczonych w Mińsku na swojej stronie internetowej. Podkreśliła też, że "władze białoruskie stale ułatwiają nieuzasadniony rosyjski atak na Ukrainę" oraz że w państwie tym występują "arbitralne stosowanie miejscowego prawa, potencjalne niepokoje społeczne, ryzyko zatrzymania".

## Pożary w Grecji. "Mamy do czynienia z ekstremalnymi zjawiskami"
 - [https://tvn24.pl/tvnmeteo/swiat/grecja-pozary-wybuchlo-kilkadziesiat-pozarow-mamy-do-czynienia-z-ekstremalnymi-zjawiskami-7301094?source=rss](https://tvn24.pl/tvnmeteo/swiat/grecja-pozary-wybuchlo-kilkadziesiat-pozarow-mamy-do-czynienia-z-ekstremalnymi-zjawiskami-7301094?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T16:14:34+00:00

<img alt="Pożary w Grecji. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-14inoo-pozary-w-grecji-7301116/alternates/LANDSCAPE_1280" />
    W ciągu ostatniej doby w całej Grecji wybuchły łącznie 64 pożary. Z żywiołem walczą setki strażaków, a także samoloty gaśnicze. Szczególnie niebezpieczny pożar szaleje w pobliżu miasta portowego Aleksandropolis. Władze Cypru mają wysłać tam do pomocy swoje samoloty gaśnicze.

## Ponad 110 tysięcy firm zawiesiło działalność w pierwszym półroczu 2023 roku. "Polska gospodarka jest w sytuacji recesyjnej"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/ponad-110-tysiecy-firm-zawiesilo-dzialalnosc-w-pierwszym-polroczu-2023-roku-polska-gospodarka-jest-w-sytuacji-recesyjnej-7301131?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/ponad-110-tysiecy-firm-zawiesilo-dzialalnosc-w-pierwszym-polroczu-2023-roku-polska-gospodarka-jest-w-sytuacji-recesyjnej-7301131?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:49:24+00:00

<img alt="Ponad 110 tysięcy firm zawiesiło działalność w pierwszym półroczu 2023 roku. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-pemsts-2108n237x-f16-sidorowicz-przedsiebiorstwa-000577-7301126/alternates/LANDSCAPE_1280" />
    Przez pół roku w Polsce działalność zawiesiło już ponad 110 tysięcy firm. Najwięcej w branżach budowlanej i handlowej. Kolejne tysiące czekają na rozpatrzenie wniosku o zawieszenie działalności.

## Z Przasnysza, Makowa Mazowieckiego, Pułtuska i Serocka szybciej do stolicy. Jest przetarg
 - [https://tvn24.pl/tvnwarszawa/najnowsze/z-przasnysza-makowa-mazowieckiego-pultuska-i-serocka-szybciej-do-stolicy-jest-przetarg-7301085?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/z-przasnysza-makowa-mazowieckiego-pultuska-i-serocka-szybciej-do-stolicy-jest-przetarg-7301085?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:46:40+00:00

<img alt="Z Przasnysza, Makowa Mazowieckiego, Pułtuska i Serocka szybciej do stolicy. Jest przetarg" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hv3eq4-pociagi-pojada-z-przasnysza-do-stolicy-7301090/alternates/LANDSCAPE_1280" />

## Chłopiec jechał na rowerze poboczem ruchliwej drogi, za nim biegła dziewczynka. Dzieci wybrały się po "zupkę chińską"
 - [https://tvn24.pl/bialystok/swidnik-lublin-chlopiec-jechal-na-rowerze-poboczem-ruchliwej-drogi-za-nim-biegla-dziewczynka-dzieci-wybraly-sie-po-zupke-chinska-7301160?source=rss](https://tvn24.pl/bialystok/swidnik-lublin-chlopiec-jechal-na-rowerze-poboczem-ruchliwej-drogi-za-nim-biegla-dziewczynka-dzieci-wybraly-sie-po-zupke-chinska-7301160?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:44:12+00:00

<img alt="Chłopiec jechał na rowerze poboczem ruchliwej drogi, za nim biegła dziewczynka. Dzieci wybrały się po " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ju74in-rower-zdjecie-ilustracyjne-6900898/alternates/LANDSCAPE_1280" />
    Policjanci dostali zgłoszenie o dwojgu małych dzieci bez opieki na ruchliwej drodze. Szybko znaleźli ośmioletniego chłopca i sześcioletnią dziewczynkę. Dzieci tłumaczyły, że wybrały się ze Świdnika do marketu w Lublinie po "zupkę chińską".

## Karambol pod Olsztynem. Wśród poszkodowanych są dzieci
 - [https://tvn24.pl/polska/wojtowo-kolo-olsztyna-karambol-pieciu-samochodow-na-s16-wsrod-poszkodowanych-sa-dzieci-7301114?source=rss](https://tvn24.pl/polska/wojtowo-kolo-olsztyna-karambol-pieciu-samochodow-na-s16-wsrod-poszkodowanych-sa-dzieci-7301114?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:37:28+00:00

<img alt="Karambol pod Olsztynem. Wśród poszkodowanych są dzieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wu1bya-wojtowo-7301127/alternates/LANDSCAPE_1280" />
    Pięć pojazdów zderzyło się w okolicach miejscowości Wójtowo na drodze S16 pomiędzy Olsztynem i Barczewem. Cztery osoby, w tym dwoje dzieci, trafiły do szpitala. Są utrudnienia w ruchu.

## Bank centralny kupuje złoto. Nowe dane
 - [https://tvn24.pl/biznes/pieniadze/nbp-kupuje-zloto-dane-za-lipiec-2023-7301112?source=rss](https://tvn24.pl/biznes/pieniadze/nbp-kupuje-zloto-dane-za-lipiec-2023-7301112?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:35:31+00:00

<img alt="Bank centralny kupuje złoto. Nowe dane" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-op67fy-zloto-sztabki-zlota-w-banku-4648982/alternates/LANDSCAPE_1280" />
    Narodowy Bank Polski (NBP) w lipcu kupił złoto. Na koniec tego miesiąca posiadał blisko 9,3 miliona uncji złota, czyli o 0,72 miliona uncji więcej niż miesiąc wcześniej - wynika z danych opublikowanych przez bank centralny.

## Pakt senacki jest, paktu sejmowego nie będzie? "Nie ma potrzeby"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/pakt-senacki-jest-paktu-sejmowego-nie-bedzie-nie-ma-potrzeby-7301053?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/pakt-senacki-jest-paktu-sejmowego-nie-bedzie-nie-ma-potrzeby-7301053?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T15:34:38+00:00

<img alt="Pakt senacki jest, paktu sejmowego nie będzie? " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-jha6y7-2108n247x-f16-skalska-001950-7301040/alternates/LANDSCAPE_1280" />
    Opozycja ogłosiła pakt senacki. Teraz pojawia się pytanie - co z paktem sejmowym? Lewica chce porozumienia w sprawie i stosownych umów. Proponuje, żeby inne partie podpisały formalne zobowiązanie, że po wyborach będą współrządzić i ustalą listę priorytetów, którymi przyszły rząd miałby się zająć.

## Na Żoliborzu powstanie nowy skwer. 100 drzew, kilkadziesiąt tysięcy roślin i strefa zabaw
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-zoliborzu-powstanie-nowy-skwer-7300997?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-na-zoliborzu-powstanie-nowy-skwer-7300997?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:47:13+00:00

<img alt="Na Żoliborzu powstanie nowy skwer. 100 drzew, kilkadziesiąt tysięcy roślin i strefa zabaw " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5un51s-na-zoliborzu-powstaje-skwer-krasinskiego-7301002/alternates/LANDSCAPE_1280" />
    Rozpoczyna się budowa skweru na Żoliborzu. W pasie drogowym, wzdłuż Krasińskiego, pojawią się alejki, różnorodna zieleń i strefa zabaw dla dzieci. - Zadanie będzie realizowane etapami - informują urzędnicy.

## Do Polski dotarła pierwsza koreańska wyrzutnia rakietowa K239 Chunmoo
 - [https://tvn24.pl/polska/wojsko-polskie-wyrzutnie-k239-chunmo-do-polski-dotarl-pierwszy-egzemplarz-7301036?source=rss](https://tvn24.pl/polska/wojsko-polskie-wyrzutnie-k239-chunmo-do-polski-dotarl-pierwszy-egzemplarz-7301036?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:42:37+00:00

<img alt="Do Polski dotarła pierwsza koreańska wyrzutnia rakietowa K239 Chunmoo " src="https://tvn24.pl/najnowsze/cdn-zdjecie-gemwn1-k239-chunmoo-7301018/alternates/LANDSCAPE_1280" />
    Pierwszy egzemplarz wieloprowadnicowej wyrzutni rakietowej K239 Chunmoo przeznaczonego dla Wojska Polskiego dotarł do portu w Gdańsku. Jak zapowiadał minister obrony Mariusz Błaszczak, system miał pojawić się w Polsce "w pierwszej połowie sierpnia", co umożliwiłoby zaprezentowanie go na defiladzie z okazji Święta Wojska Polskiego. Ostatecznie pierwsza wyrzutnia trafiła do naszego kraju z kilkudniowym opóźnieniem, na które złożyła się między innymi akcja ratunkowa na Morzu Śródziemnym, w której brał udział statek transportujący K239 Chunmoo - poinformował Portal Morski.

## Na zamku znaleźli nieznane pomieszczenie. "Od około 200 lat nikt nie postawił tam nogi"
 - [https://tvn24.pl/wroclaw/odkrycie-na-zamku-swiny-remontuja-zamek-natkneli-sie-na-nieznane-pomieszczenie-prawdopodobnie-od-200-lat-nikt-nie-zagladal-do-srodka-7300650?source=rss](https://tvn24.pl/wroclaw/odkrycie-na-zamku-swiny-remontuja-zamek-natkneli-sie-na-nieznane-pomieszczenie-prawdopodobnie-od-200-lat-nikt-nie-zagladal-do-srodka-7300650?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:41:09+00:00

<img alt="Na zamku znaleźli nieznane pomieszczenie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ihby13-odkrycie-na-zamku-swiny-7300651/alternates/LANDSCAPE_1280" />
    Najpierw zbadali teren georadarem, ale to dopiero "weryfikacja wykopaliskowa" pozwoliła odkryć miejsce, w którym nikogo nie było prawdopodobnie od 200 lat. To "kompletnie zachowana" piwnica na Zamku Świny (woj. dolnośląskie). Warownia jest dostępna dla turystów, ale badania i prace rewitalizacyjne trwają. Zamek może kryć jeszcze niejedną tajemnicę.

## Tak rosną stawki najmu mieszkań w największych miastach
 - [https://tvn24.pl/biznes/nieruchomosci/polska-ceny-najmu-mieszkan-wzrosly-o-15-procent-miesiac-do-miesiaca-w-miastach-wojewodzkich-raport-z-rynku-najmu-7300959?source=rss](https://tvn24.pl/biznes/nieruchomosci/polska-ceny-najmu-mieszkan-wzrosly-o-15-procent-miesiac-do-miesiaca-w-miastach-wojewodzkich-raport-z-rynku-najmu-7300959?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:24:02+00:00

<img alt="Tak rosną stawki najmu mieszkań w największych miastach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-80zqzn-obok-zabudowy-jednorodzinnej-w-postaci-willi-miejskich-zbudowano-bloki-7143179/alternates/LANDSCAPE_1280" />
    W lipcu w miastach wojewódzkich stawki najmu mieszkań wzrosły średnio o 1,5 procent wobec czerwca i o 8,5 procent rok do roku. Największy wzrost odnotowano w Trójmieście oraz w Lublinie i Olsztynie.

## Noworodek porwany ze szpitala. Policja zatrzymała 30-letnią kobietę
 - [https://tvn24.pl/swiat/indie-noworodek-porwany-ze-szpitala-zostal-odnaleziony-po-osmiu-godzinach-policja-zatrzymala-30-letnia-kobiete-7300860?source=rss](https://tvn24.pl/swiat/indie-noworodek-porwany-ze-szpitala-zostal-odnaleziony-po-osmiu-godzinach-policja-zatrzymala-30-letnia-kobiete-7300860?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:21:08+00:00

<img alt="Noworodek porwany ze szpitala. Policja zatrzymała 30-letnią kobietę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jtt495-porod-domowy-jest-w-polsce-zgodny-z-prawem-6224086/alternates/LANDSCAPE_1280" />
    Indyjska policja prowadzi dochodzenie w sprawie porwania noworodka, który zniknął z oddziału położniczego zaledwie dwa dni po tym, jak się urodził. Odnalezienie porywaczki z dzieckiem zajęło służbom osiem godzin, informują media.

## Powietrze znad Sahary znów spływa do Włoch, na Węgrzech nawet 36 stopni
 - [https://tvn24.pl/tvnmeteo/swiat/upaly-w-europie-antycyklon-neron-powietrze-znad-sahary-znow-splywa-do-wloch-na-wegrzech-nawet-36-stopni-7300843?source=rss](https://tvn24.pl/tvnmeteo/swiat/upaly-w-europie-antycyklon-neron-powietrze-znad-sahary-znow-splywa-do-wloch-na-wegrzech-nawet-36-stopni-7300843?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T14:01:17+00:00

<img alt="Powietrze znad Sahary znów spływa do Włoch, na Węgrzech nawet 36 stopni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-nwjqd-wlochy-7300946/alternates/LANDSCAPE_1280" />
    Kolejna fala upałów nawiedziła Włochy. W tym tygodniu termometry mogą pokazać miejscami prawie 40 stopni Celsjusza. Taka aura związana jest z wyżem Neron, który zaciąga do Starego Kontynentu gorące powietrze znad Sahary. Spiekota daje się we znaki również na Węgrzech.

## Niecodzienna akcja policjantów. Musieli złapać konie
 - [https://tvn24.pl/bialystok/powiat-pulawski-policjanci-zlapali-konie-ktore-biegaly-po-drodze-wojewodzkiej-pomogl-jeden-z-mieszkancow-7300942?source=rss](https://tvn24.pl/bialystok/powiat-pulawski-policjanci-zlapali-konie-ktore-biegaly-po-drodze-wojewodzkiej-pomogl-jeden-z-mieszkancow-7300942?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:51:53+00:00

<img alt="Niecodzienna akcja policjantów. Musieli złapać konie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2nerqq-konie-udalo-sie-zlapac-7300949/alternates/LANDSCAPE_1280" />
    Na drodze wojewódzkiej z Nałęczowa do Lublina w powiecie puławskim biegały dwa konie. Złapali je policjanci, którym pomógł jeden z okolicznych mieszkańców. Okazało się, że zwierzęta uciekły z zagrody, bo spłoszyły się słysząc dźwięk kombajnów, które rano rozpoczęły pracę na pobliskim polu.

## 77-latek próbował gasić płonącą trawę i drewno na swojej posesji. Zmarł w szpitalu. Miał rozległe oparzenia
 - [https://tvn24.pl/bialystok/gmina-wisznice-77-latek-probowal-gasic-plonaca-trawe-i-pryzme-drewna-nie-zyje-7300889?source=rss](https://tvn24.pl/bialystok/gmina-wisznice-77-latek-probowal-gasic-plonaca-trawe-i-pryzme-drewna-nie-zyje-7300889?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:46:51+00:00

<img alt="77-latek próbował gasić płonącą trawę i drewno na swojej posesji. Zmarł w szpitalu. Miał rozległe oparzenia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-urjj1o-palila-sie-trawa-oraz-pryzma-drewna-7300891/alternates/LANDSCAPE_1280" />
    Nie żyje 77-latek, który w gminie Wisznice (woj. lubelskie) chciał zgasić pożar na swojej posesji. Paliła się trawa oraz pryzma drewna. W pewnym momencie upadł. Sąsiedzi próbowali go podnieść, ale z uwagi na wysoką temperaturę, im się nie udało. Mężczyźnie pomogli strażacy jednak doznał on rozległych poparzeń.

## "Co prawda upały nie odpuszczają, ale uspokajam, to nie fatamorgana"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-iluminacja-swiateczna-na-sezon-20232024-jak-bedzie-wygladala-7300912?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-iluminacja-swiateczna-na-sezon-20232024-jak-bedzie-wygladala-7300912?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:32:07+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c1znzx-w-sezonie-20232024-miejskie-ozdoby-swiateczne-nawiaza-do-lat-50-i-60-7300919/alternates/LANDSCAPE_1280" />
    Stołeczny ratusz poinformował właśnie o podpisaniu umowy na montaż świątecznej iluminacji. W sezonie 2023/2024 miejskie ozdoby świąteczne nawiążą do lat 50. i 60. XX wieku.

## Śmigłowiec na pikniku "dzięki wsparciu" wiceministra? Tak mówił wójt, teraz "nie ma wiedzy w tym temacie"
 - [https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-wojt-gminy-o-roli-wiceszefa-mswia-macieja-wasika-7300795?source=rss](https://tvn24.pl/polska/sarnowa-gora-policyjny-smiglowiec-black-hawk-zahaczyl-o-linie-energetyczna-wojt-gminy-o-roli-wiceszefa-mswia-macieja-wasika-7300795?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:27:34+00:00

<img alt="Śmigłowiec na pikniku " src="https://tvn24.pl/polska/cdn-zdjecie-gebqpj-wojt-gminy-sonsk-jaroslaw-muchowski-7300863/alternates/LANDSCAPE_1280" />
    Dzięki wsparciu MSWiA oraz wiceministra Macieja Wąsika główną atrakcją będzie policyjny śmigłowiec Black Hawk - zapowiadał jeszcze w niedzielę wójt gminy Sońsk Jarosław Muchowski. W poniedziałek w rozmowie z reporterem TVN24 powiedział jednak, że "nie ma wiedzy", czy Wąsik zorganizował ten śmigłowiec. Niebezpieczny przelot maszyny komentowali też w poniedziałek politycy.

## Porozrzucane wieńce i znicze na cmentarzu. Nie wiadomo, czy winni są wandale, czy trąba powietrzna
 - [https://tvn24.pl/bialystok/goldap-porozrzucane-kwiaty-wience-i-znicze-na-cmentarzu-to-przez-wandali-lub-trabe-powietrzna-7300555?source=rss](https://tvn24.pl/bialystok/goldap-porozrzucane-kwiaty-wience-i-znicze-na-cmentarzu-to-przez-wandali-lub-trabe-powietrzna-7300555?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:13:34+00:00

<img alt="Porozrzucane wieńce i znicze na cmentarzu. Nie wiadomo, czy winni są wandale, czy trąba powietrzna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ysrg54-na-cmentarzu-porozrzucane-zostaly-kwiaty-wience-i-znicze-7300553/alternates/LANDSCAPE_1280" />
    Wykrzywiony krzyż, wokół porozrzucane kwiaty, wieńce i znicze. To wszystko widzimy na filmie nagranym przez policjantów na cmentarzu komunalnym w miejscowości Banie Mazurskie (woj. warmińsko-mazurskie). Ustalają oni, czy wszystko jest dziełem człowieka czy może zjawiska atmosferycznego. Jeden ze świadków mówił o trąbie powietrznej.

## Skarb Państwa zaoferował prawie miliard złotych za Bogdankę. Akcje mocno w górę
 - [https://tvn24.pl/biznes/z-kraju/energetyka-enea-skarb-panstwa-zaoferowal-ponad-988-mln-zl-za-lw-bogdanka-7300897?source=rss](https://tvn24.pl/biznes/z-kraju/energetyka-enea-skarb-panstwa-zaoferowal-ponad-988-mln-zl-za-lw-bogdanka-7300897?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:13:15+00:00

<img alt="Skarb Państwa zaoferował prawie miliard złotych za Bogdankę. Akcje mocno w górę" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-da4jbb-kopalnia-bogdanki-6112382/alternates/LANDSCAPE_1280" />
    Skarb Państwa złożył ofertę za Lubelski Węgiel "Bogdanka" po 45 złotych za akcję, czyli za ponad 988 milionów złotych - przekazała spółka energetyczna Enea, która jest właścicielem Bogdanki. W komunikacie dodano, że zapłata miałaby zostać uregulowana w obligacjach skarbowych. Akcje Bogdanki zaczęły po południu rosnąć ponad 15 procent.

## Przekroczył prędkość i trafił do więzienia
 - [https://tvn24.pl/tvnwarszawa/ulice/lipsko-przekroczyl-predkosc-i-trafil-do-wiezienia-7300849?source=rss](https://tvn24.pl/tvnwarszawa/ulice/lipsko-przekroczyl-predkosc-i-trafil-do-wiezienia-7300849?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T13:06:25+00:00

<img alt="Przekroczył prędkość i trafił do więzienia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-x2rnyi-kontrola-drogowa-6895712/alternates/LANDSCAPE_1280" />
    Jechał za szybko i tym zwrócił na siebie policjantów z drogówki. Został zatrzymany. Wszystko skończyłoby się na mandacie, który - zgodnie z taryfikatorem - powinien wynieść 300 złotych. Ale nie w tym przypadku. 24-latek po drogowej kontroli trafił prosto do więzienia, czeka go też proces.

## Uciekł, zostawiając w rozbitym aucie rannych pasażerów. Jeden z nich, 16-latek, zmarł
 - [https://tvn24.pl/tvnwarszawa/ulice/mlawa-uciekl-zostawiajac-w-rozbitym-aucie-rannych-pasazerow-jeden-z-nich-16-latek-zmarl-7300847?source=rss](https://tvn24.pl/tvnwarszawa/ulice/mlawa-uciekl-zostawiajac-w-rozbitym-aucie-rannych-pasazerow-jeden-z-nich-16-latek-zmarl-7300847?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:51:37+00:00

<img alt="Uciekł, zostawiając w rozbitym aucie rannych pasażerów. Jeden z nich, 16-latek, zmarł" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ei82vh-w-wypadku-zginal-16-letni-pasazer-7300823/alternates/LANDSCAPE_1280" />
    Samochód uderzył w drzewo. Kierowca wydostał się z wraku i uciekł, zostawiając rannych pasażerów. Jeden z nich, 16-latek, nie przeżył. Podejrzany o kierowanie autem następnego dnia sam się zgłosił.

## Duże zainteresowanie piwnicami pałacu Saskiego. Wydłużono godziny zwiedzania, zwiększono limit osób
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duze-zainteresowanie-piwnicami-palacu-saskiego-wydluzono-godziny-powiekszono-limit-osob-7300606?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duze-zainteresowanie-piwnicami-palacu-saskiego-wydluzono-godziny-powiekszono-limit-osob-7300606?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:48:22+00:00

<img alt="Duże zainteresowanie piwnicami pałacu Saskiego. Wydłużono godziny zwiedzania, zwiększono limit osób" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hmsnr9-zwiedzanie-piwnic-palacu-saskiego-7300769/alternates/LANDSCAPE_1280" />
    Darmowe zwiedzanie piwnic pałacu Saskiego okazało się bardzo popularną rozrywką podczas tegorocznych wakacji. Sukces frekwencyjny zaskoczył nawet organizatora wycieczek. Przez nieco ponad miesiąc przewodnicy oprowadzili po piwnicach ponad trzy tysiące osób.

## Karetka utknęła w parku. Zapadły się pod nią granitowe płyty
 - [https://tvn24.pl/pomorze/torun-ratownicy-medyczni-interweniowali-w-parku-nagle-pod-karetka-zapadly-sie-plyty-7300584?source=rss](https://tvn24.pl/pomorze/torun-ratownicy-medyczni-interweniowali-w-parku-nagle-pod-karetka-zapadly-sie-plyty-7300584?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:47:06+00:00

<img alt="Karetka utknęła w parku. Zapadły się pod nią granitowe płyty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-teshla-torun-pod-karetka-zapadly-sie-granitowe-plyty-7300568/alternates/LANDSCAPE_1280" />
    W Toruniu (woj. kujawsko-pomorskie) pod ciężarem karetki zapadły się granitowe płyty. Interweniowały służby, które pomogły w wyciągnięciu pojazdu. Poszkodowanego, do którego zostali wezwani ratownicy, zabrano do szpitala zastępczym ambulansem.

## Uciekał przed policją na skuterze wodnym, był pijany
 - [https://tvn24.pl/pomorze/sopot-uciekal-przed-policja-na-skuterze-wodnym-byl-pijany-7300505?source=rss](https://tvn24.pl/pomorze/sopot-uciekal-przed-policja-na-skuterze-wodnym-byl-pijany-7300505?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:37:17+00:00

<img alt="Uciekał przed policją na skuterze wodnym, był pijany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jrd297-nietrzezwy-sternik-skutera-wodnego-bez-uprawnien-zostal-zatrzymany-7300498/alternates/LANDSCAPE_1280" />
    Policjanci z Gdańska (woj. pomorskie) zatrzymali po pościgu pijanego 40-latka, który uciekał na skuterze wodnym w okolicy plaży w Sopocie. Mężczyzna miał ponad promil alkoholu w organizmie, a do tego prowadził bez uprawnień i dowodu rejestracyjnego.

## Wieźli świeżo ścięte konopie, w ich domach policjanci znaleźli narkotyki warte 850 tys. zł
 - [https://tvn24.pl/bialystok/powiat-bialostocki-zatrzymali-35-i-40-latka-zabezpieczyli-narkotyki-warte-na-czarnym-rynku-okolo-850-tys-zl-7300324?source=rss](https://tvn24.pl/bialystok/powiat-bialostocki-zatrzymali-35-i-40-latka-zabezpieczyli-narkotyki-warte-na-czarnym-rynku-okolo-850-tys-zl-7300324?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:07:54+00:00

<img alt="Wieźli świeżo ścięte konopie, w ich domach policjanci znaleźli narkotyki warte 850 tys. zł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-izeom-lacznie-znaleziono-okolo-17-kilogramow-narkotykow-7300328/alternates/LANDSCAPE_1280" />
    Marihuana, haszysz i grzybki halucynogenne. Takie narkotyki zabezpieczyli policjanci, którzy zatrzymali w okolicach Białegostoku dwóch mieszkańców powiatu. Wieźli w aucie kwiatostany suszu konopi wycięte na leśnej plantacji. W ich domach mundurowi znaleźli słoiki, pudełka i opakowania próżniowe z narkotykami. Całość o czarnorynkowej wartości około 850 tys. zł.

## Chcą wznieść jedyny w mieście publiczny żłobek. Czekają na pieniądze z KPO
 - [https://tvn24.pl/bialystok/bielsk-podlaski-wladze-chca-wzniesc-jedyny-w-miescie-publiczny-zlobek-czekaja-na-pieniadze-z-kpo-7300638?source=rss](https://tvn24.pl/bialystok/bielsk-podlaski-wladze-chca-wzniesc-jedyny-w-miescie-publiczny-zlobek-czekaja-na-pieniadze-z-kpo-7300638?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:07:32+00:00

<img alt="Chcą wznieść jedyny w mieście publiczny żłobek. Czekają na pieniądze z KPO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d0mive-wladze-bielska-podlaskiego-chca-wybudowac-jedyny-w-miescie-publiczny-zlobek-7300715/alternates/LANDSCAPE_1280" />
    W Bielsku Podlaskim funkcjonują jedynie prywatne żłobki. Samorząd chce zbudować publiczny, co ma pochłonąć od 8 do 10 mln zł. Jest wyznaczone miejsce i kończy się proces przygotowywania dokumentacji projektowej. Niezbędne są jednak pieniądze - prawie 6,5 mln zł - przyznane miastu z Krajowego Planu Odbudowy, na które samorząd wciąż czeka.

## Pożar świdermajera. Konserwator zabytków zawiadamia prokuraturę, strażacy mówią o możliwym podpaleniu
 - [https://tvn24.pl/tvnwarszawa/okolice/sulejowek-pozar-swidermajera-konserwator-zabytkow-zawiadamia-prokurature-strazacy-mowia-o-mozliwym-podpaleniu-7300748?source=rss](https://tvn24.pl/tvnwarszawa/okolice/sulejowek-pozar-swidermajera-konserwator-zabytkow-zawiadamia-prokurature-strazacy-mowia-o-mozliwym-podpaleniu-7300748?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T12:04:46+00:00

<img alt="Pożar świdermajera. Konserwator zabytków zawiadamia prokuraturę, strażacy mówią o możliwym podpaleniu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-jx5p9m-pozar-w-sulejowku-7299284/alternates/LANDSCAPE_1280" />
    Złożyłem zawiadomienie do Prokuratury Rejonowej w Mińsku Mazowieckim o zniszczeniu zabytku oraz do Powiatowego Inspektora Nadzoru Budowlanego o zabezpieczenie i poprawę stanu technicznego obiektu - poinformował mazowiecki wojewódzki konserwator zabytków prof. Jakub Lewicki. Chodzi o sobotni pożar zabytkowego świdermajera w Sulejówku.

## Rząd szykuje się do wypłaty tak zwanej czternastej emerytury. Jest propozycja kwoty i terminu
 - [https://tvn24.pl/biznes/dla-seniora/czternasta-emerytura-kwota-brutto-i-termin-wyplaty-jest-propozycja-rzadu-7300719?source=rss](https://tvn24.pl/biznes/dla-seniora/czternasta-emerytura-kwota-brutto-i-termin-wyplaty-jest-propozycja-rzadu-7300719?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:56:57+00:00

<img alt="Rząd szykuje się do wypłaty tak zwanej czternastej emerytury. Jest propozycja kwoty i terminu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8gyges-shutterstock_1776949820-7300746/alternates/LANDSCAPE_1280" />
    Tak zwana 14. emerytura coraz bliżej. Na rządowych stronach pojawiły się informacje o proponowanej wysokości i terminie wypłaty świadczenia.

## Chiny chcą rzucić wyzwanie Zachodowi. Kilkadziesiąt krajów na liście
 - [https://tvn24.pl/biznes/ze-swiata/brics-g7-chiny-chca-rozszerzenia-bloku-brics-kilkadziesiat-krajow-na-liscie-7300637?source=rss](https://tvn24.pl/biznes/ze-swiata/brics-g7-chiny-chca-rozszerzenia-bloku-brics-kilkadziesiat-krajow-na-liscie-7300637?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:41:50+00:00

<img alt="Chiny chcą rzucić wyzwanie Zachodowi. Kilkadziesiąt krajów na liście" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-4t0xla-szanghaj-chiny-7300672/alternates/LANDSCAPE_1280" />
    Chiny naciskają na rozszerzenie bloku BRICS o kolejne państwa, aby stał się on pełnowymiarowym rywalem dla grupy G7 - napisał "Financial Times". Brytyjski dziennik zauważył, że temu pomysłowi sprzeciwiają się Indie. Według źródeł agencji Reuters zainteresowanie przystąpieniem do BRICS wyraziło ponad 40 krajów, część miało formalnie poprosić o akces. Obecnie do BRICS należą Brazylia, Rosja, Indie, Chiny, RPA.

## Są pieniądze na likwidację składowiska odpadów w Przylepie. "Miasto może przystąpić do działań"
 - [https://tvn24.pl/poznan/przylep-sa-srodki-na-likwidacje-skladowiska-odpadow-7300658?source=rss](https://tvn24.pl/poznan/przylep-sa-srodki-na-likwidacje-skladowiska-odpadow-7300658?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:40:50+00:00

<img alt="Są pieniądze na likwidację składowiska odpadów w Przylepie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m96tpm-zgliszcza-magazynu-na-terenie-skladowiska-odpadow-w-zielonogorskim-przylepie-7284924/alternates/LANDSCAPE_1280" />
    43 miliony złotych na likwidację składowiska odpadów w Przylepie (woj. lubuskie) trafiły do samorządu. Prezydent Zielonej Góry liczy, że w ciągu kilku dni podpisana zostanie odpowiednia umowa i rozpocznie się proces utylizacji.

## Potrącenie rowerzystki. Ranną kobietę zabrała karetka
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wesola-potracenie-rowerzystki-ranna-kobiete-zabrala-karetka-7300560?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wesola-potracenie-rowerzystki-ranna-kobiete-zabrala-karetka-7300560?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:31:17+00:00

<img alt="Potrącenie rowerzystki. Ranną kobietę zabrała karetka" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sfrdwq-wypadek-w-wesolej-7300572/alternates/LANDSCAPE_1280" />
    W Wesołej kierowca samochodu osobowego potrącił rowerzystkę. Na miejsce zadysponowano śmigłowiec Lotniczego Pogotowia Ratunkowego. Ostatecznie kobietę zabrała karetka kołowa. Przyczyny wypadku wyjaśnia policja.

## "Są kilka długości lepsze niż najlepsze postosowieckie". Błaszczak prezentuje nowe samoloty
 - [https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-minister-blaszczak-prezentuje-nowe-samoloty-7300624?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-minister-blaszczak-prezentuje-nowe-samoloty-7300624?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:14:53+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bcroe4-prezentacja-samolotu-fa-50-w-minsku-mazowieckim-7300647/alternates/LANDSCAPE_1280" />
    W poniedziałek w Mińsku Mazowieckim minister obrony narodowej zaprezentował południowokoreański samolot szkolno-bojowy FA-50. Polska zamówiła 48 egzemplarzy tej maszyny. Umowa na ich dostawę została zatwierdzona we wrześniu ubiegłego roku.

## Akcja ratunkowa Tatrach. Mężczyzna upadł i zatrzymał się tuż nad urwiskiem
 - [https://tvn24.pl/krakow/tatry-slowacja-turysta-spadl-z-baranich-rogow-zatrzymal-sie-nad-urwiskiem-akcja-ratunkowa-hzs-7300639?source=rss](https://tvn24.pl/krakow/tatry-slowacja-turysta-spadl-z-baranich-rogow-zatrzymal-sie-nad-urwiskiem-akcja-ratunkowa-hzs-7300639?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:12:31+00:00

<img alt="Akcja ratunkowa Tatrach. Mężczyzna upadł i zatrzymał się tuż nad urwiskiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ef24a-akcja-ratunkowa-hzs-7300630/alternates/LANDSCAPE_1280" />
    Ratownicy Horskiej Zachrannej Służby pomogli Polakowi, który w sobotę w okolicach szczytu Baranie Rogi niemal spadł z urwiska w przepaść. Turysta może mówić o podwójnym szczęściu, bo na miejscu był akurat lekarz, który udzielił mu pierwszej pomocy. Mężczyzna po upadku doznał obrażeń głowy i kończyn, został zabrany śmigłowcem.

## Firma energetyczna rusza z kontrolami fotowoltaiki
 - [https://tvn24.pl/biznes/z-kraju/energetyka-tauron-dystrybucja-prowadzi-kontrole-mikroinstalacji-fotowoltaicznych-7300544?source=rss](https://tvn24.pl/biznes/z-kraju/energetyka-tauron-dystrybucja-prowadzi-kontrole-mikroinstalacji-fotowoltaicznych-7300544?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:11:37+00:00

<img alt="Firma energetyczna rusza z kontrolami fotowoltaiki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qkyllo-panele-fotowoltaiczne-dom-shutterstock_1614190123-6961952/alternates/LANDSCAPE_1280" />
    Tauron Dystrybucja prowadzi kontrole mikroinstalacji fotowoltaicznych z powodu nadużyć klientów - poinformowała spółka w poniedziałek. Tauron wskazał, że tylko na obszarze gliwickim wykrył ponad 1,5 tysiąca niepoprawnych nastaw falowników i 1,6 tysiąca przypadków przekroczeń mocy zainstalowanej.

## Nurt w Wiśle porwał jednego z kąpiących się mężczyzn. Trwają poszukiwania
 - [https://tvn24.pl/pomorze/torun-kapali-sie-w-wisle-jednego-z-nich-nagle-porwal-rzeczny-nurt-trwaja-poszukiwania-39-latka-7300245?source=rss](https://tvn24.pl/pomorze/torun-kapali-sie-w-wisle-jednego-z-nich-nagle-porwal-rzeczny-nurt-trwaja-poszukiwania-39-latka-7300245?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T11:04:19+00:00

<img alt="Nurt w Wiśle porwał jednego z kąpiących się mężczyzn. Trwają poszukiwania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cpmr4e-sluzby-poszukuja-39-latka-ktory-kapal-sie-w-wisle-7300237/alternates/LANDSCAPE_1280" />
    W Toruniu (woj. kujawsko-pomorskie) służby od soboty poszukują 39-latka, który kąpał się w Wiśle i został porwany przez nurt rzeki. W poniedziałek rano poszukiwania zostały wznowione. Policja przestrzega przed kąpielami w rzekach i zaleca korzystanie ze strzeżonych kąpielisk.

## Nie żyje słynny "Cheems". Pies znany z memów "zasnął w piątek rano podczas operacji"
 - [https://tvn24.pl/ciekawostki/nie-zyje-slynny-cheems-pies-znany-z-memow-balltze-zasnal-w-piatek-rano-podczas-operacji-7300563?source=rss](https://tvn24.pl/ciekawostki/nie-zyje-slynny-cheems-pies-znany-z-memow-balltze-zasnal-w-piatek-rano-podczas-operacji-7300563?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T10:54:29+00:00

<img alt="Nie żyje słynny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vuh1pu-cheems-pies-znany-z-memow-nie-zyje-7300603/alternates/LANDSCAPE_1280" />
    Nie żyje "Cheems", pies znany z memów, który w rzeczywistości wabił się "Balltze". Słynny czworonóg zmarł podczas operacji 18 sierpnia. O odejściu shiby-inu w sobotę poinformowała za pomocą mediów społecznościowych jego opiekunka.

## Niebezpieczna pułapka na rowerzystów na Ursynowie. Ktoś powbijał gwoździe w ścieżkę
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pulapka-na-rowerzystow-na-ursynowie-ktos-powbijal-gwozdzie-w-sciezke-7300389?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-pulapka-na-rowerzystow-na-ursynowie-ktos-powbijal-gwozdzie-w-sciezke-7300389?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T10:38:20+00:00

<img alt="Niebezpieczna pułapka na rowerzystów na Ursynowie. Ktoś powbijał gwoździe w ścieżkę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8sw0z5-gwozdzie-wystaja-ze-sciezki-rowerowej-7300473/alternates/LANDSCAPE_1280" />
    Na jednej z ursynowskich grup sąsiedzkich w mediach społecznościowych pojawiły się zdjęcia ścieżki rowerowej, z której wystają kilkucentymetrowe, ostre gwoździe. Jak informuje Zarząd Dróg Miejskich, pracownicy pogotowia drogowego pojechali na miejsce, aby je usunąć.

## Kanada. Dziesiątki tysięcy ewakuowanych, tysiące spalonych hektarów
 - [https://tvn24.pl/tvnmeteo/swiat/pozary-w-kanadzie-dziesiatki-tysiecy-ewakuowanych-tysiace-spalonych-hektarow-7300406?source=rss](https://tvn24.pl/tvnmeteo/swiat/pozary-w-kanadzie-dziesiatki-tysiecy-ewakuowanych-tysiace-spalonych-hektarow-7300406?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T10:35:16+00:00

<img alt="Kanada. Dziesiątki tysięcy ewakuowanych, tysiące spalonych hektarów " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ta0c1l-pozary-w-kolumbii-brytyjskiej-7300503/alternates/LANDSCAPE_1280" />
    Kanada walczy z najgorszymi w historii kraju pożarami lasów. W prowincji Kolumbia Brytyjska nakazem ewakuacji objęto do tej pory ponad 35 tysięcy osób, a jakość powietrza w wielu miastach była niebezpieczna dla zdrowia. Próby opanowania ognia trwają także na północy kraju w pobliżu miasta Yellowknife.

## 10-latek utonął na strzeżonej plaży. Policja przesłuchuje świadków i ratowników
 - [https://tvn24.pl/pomorze/kajkowo-jezioro-sajmino-tragedia-na-strzezonej-plazy-nie-zyje-10-latek-policja-przesluchuje-ratownikow-7300445?source=rss](https://tvn24.pl/pomorze/kajkowo-jezioro-sajmino-tragedia-na-strzezonej-plazy-nie-zyje-10-latek-policja-przesluchuje-ratownikow-7300445?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T10:08:44+00:00

<img alt="10-latek utonął na strzeżonej plaży. Policja przesłuchuje świadków i ratowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oeno7d-do-tragedii-doszlo-na-strzezonym-kapielisku-7300456/alternates/LANDSCAPE_1280" />
    Po utonięciu 10-latka na strzeżonej plaży jeziora Sajmino w Kajkowie (woj. warmińsko-mazurskie) policja przesłuchuje świadków tragedii w tym ratowników, którzy pełnili służbę na kąpielisku. Jak przekazał prokurator rejonowy w Ostródzie Rafał Koziński, na wtorek zaplanowano sekcję zwłok dziecka.

## Skazany 19-latek chciał wyjechać za granicę i przyszedł na policję po swój telefon. Trafił do więzienia
 - [https://tvn24.pl/bialystok/gmina-sosnowica-chcial-wyjechac-za-granice-gdy-byl-na-komendzie-policjanci-zawiezli-go-do-zakladu-karnego-7300224?source=rss](https://tvn24.pl/bialystok/gmina-sosnowica-chcial-wyjechac-za-granice-gdy-byl-na-komendzie-policjanci-zawiezli-go-do-zakladu-karnego-7300224?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:46:38+00:00

<img alt="Skazany 19-latek chciał wyjechać za granicę i przyszedł na policję po swój telefon. Trafił do więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qjazok-przyszedl-na-komende-odebrac-telefon-komorkowy-zdjecie-ilustracyjne-7300247/alternates/LANDSCAPE_1280" />
    19-latek z gminy Sosnowica (woj. lubelskie) podkradał matce pieniądze. Łącznie ponad 27 tys. zł. Przyznał, że jest uzależniony od hazardu. Gdy przyszedł na komendę, żeby odebrać swój – zabezpieczonym w czasie czynności – telefon, policjanci dostali akurat korespondencję z sądu, z której wynikało, że mężczyzna został skazany na półtora roku więzienia. Zawieźli go do zakładu karnego. Następnego dnia planował wyjechać za granicę.

## Ratownicy medyczni bez dodatków za pracę w nocy i święta. "Powstała luka prawna"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ratownicy-medyczni-bez-dodatkow-za-prace-w-nocy-i-swieta-7300060?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ratownicy-medyczni-bez-dodatkow-za-prace-w-nocy-i-swieta-7300060?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:39:16+00:00

<img alt="Ratownicy medyczni bez dodatków za pracę w nocy i święta. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-80y6lz-karetka-w01-001-przed-izba-przyjec-szpitala-orlowskiego-7183536/alternates/LANDSCAPE_1280" />
    Stołeczni ratownicy medyczni stracili dodatki do wynagrodzenia za pracę w nocy i święta. Przysługiwały im w związku z epidemią Covid 19. Stan zagrożenia epidemicznego zniesiono 30 czerwca. Resort zdrowia podtrzymuje swoje wcześniejsze deklaracje i zapewnia, że dodatki powinny być nadal wypłacane jako stały element wynagrodzenia. Jednak projekt ustawy z zapisami gwarantującymi ich wypłatę jest dopiero procedowany w Sejmie, a termin wejścia w życie samej ustawy nie jest znany. Problem z dodatkowym wynagrodzeniem dotyczy ratowników także w innych miastach. – Pensje za lipiec są niższe nawet o 30 proc. – alarmują ratownicy.

## Młodzi rodzice z zarzutami po śmierci pięciomiesięcznego dziecka. Byli pijani
 - [https://tvn24.pl/krakow/brzezowa-smierc-niemowlecia-rodzice-z-zarzutami-prokuratura-ustala-przyczyne-rodzinnej-tragedii-7300193?source=rss](https://tvn24.pl/krakow/brzezowa-smierc-niemowlecia-rodzice-z-zarzutami-prokuratura-ustala-przyczyne-rodzinnej-tragedii-7300193?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:11:35+00:00

<img alt="Młodzi rodzice z zarzutami po śmierci pięciomiesięcznego dziecka. Byli pijani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dlatur-na-malarie-co-dwie-minuty-umiera-jedno-dziecko-6985787/alternates/LANDSCAPE_1280" />
    Rodzice niemowlęcia, które zmarło w sobotę we wsi Brzezowa na Podkarpaciu, usłyszeli zarzuty narażenia dziecka na niebezpieczeństwo. Jak poinformowała prokuratura, 22-letnia kobieta i 24-letni opiekowali się pięciomiesięczną córką w stanie upojenia alkoholowego. Gdy do ich domu przyjechały służby, matka miała 1,5 promila alkoholu w organizmie, a ojciec jeden promil. - Pili na pewno wieczorem lub nocą, ich stan wskazywał na wypicie niemałej ilości alkoholu - powiedziała nam prokurator Grażyna Krzyżanowska. Śledczy zawnioskowali o areszt.

## Młodzi rodzice zatrzymani po śmierci pięciomiesięcznego dziecka
 - [https://tvn24.pl/krakow/brzezowa-smierc-niemowlecia-rodzice-zatrzymani-prokuratura-ustala-przyczyne-rodzinnej-tragedii-7300193?source=rss](https://tvn24.pl/krakow/brzezowa-smierc-niemowlecia-rodzice-zatrzymani-prokuratura-ustala-przyczyne-rodzinnej-tragedii-7300193?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:11:35+00:00

<img alt="Młodzi rodzice zatrzymani po śmierci pięciomiesięcznego dziecka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dlatur-na-malarie-co-dwie-minuty-umiera-jedno-dziecko-6985787/alternates/LANDSCAPE_1280" />
    Prokuratura bada okoliczności śmierci pięciomiesięcznego dziecka we wsi Brzezowa na Podkarpaciu. Do tragedii doszło w sobotę, służby powiadomił jeden z członków rodziny. Mimo próby reanimacji dziewczynki nie udało się uratować. Policja zatrzymała rodziców, którzy w chwili interwencji byli pijani. Przyczyny śmierci niemowlęcia wykaże sekcja zwłok.

## Hollywood w deszczu, Dolina Śmierci pod wodą. Burza tropikalna Hilary w Kalifornii
 - [https://tvn24.pl/tvnmeteo/swiat/kalifornia-stany-zjednoczone-burza-tropikalna-hilary-hollywood-w-deszczu-dolina-smierci-pod-woda-trzesienie-ziemi-7300160?source=rss](https://tvn24.pl/tvnmeteo/swiat/kalifornia-stany-zjednoczone-burza-tropikalna-hilary-hollywood-w-deszczu-dolina-smierci-pod-woda-trzesienie-ziemi-7300160?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:07:05+00:00

<img alt="Hollywood w deszczu, Dolina Śmierci pod wodą. Burza tropikalna Hilary w Kalifornii" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tlq6jp-burza-hilary-dotarla-do-kalifornii-7300198/alternates/LANDSCAPE_1280" />
    Burza tropikalna Hilary uderzyła w Meksyk i Stany Zjednoczone. W wielu miastach doszło do niebezpiecznych podtopień, a strumienie wody opadowej spłynęły nawet Doliną Śmierci. Mieszkańców Los Angeles zaskoczyło także trzęsienie ziemi, do którego doszło w niedzielne popołudnie.

## Dwie dziewczynki pogryzione przez psa. "Wydostał się z posesji"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/pruszkow-dwie-dziewczynki-pogryzione-przez-psa-7300333?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/pruszkow-dwie-dziewczynki-pogryzione-przez-psa-7300333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T09:01:57+00:00

<img alt="Dwie dziewczynki pogryzione przez psa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-e4nok7-pies-pogryzl-dwie-dziewczynki-zdjecie-ilustracyjne-7300342/alternates/LANDSCAPE_1280" />
    W podwarszawskim Pruszkowie sześciolatka i ośmiolatka zostały pogryzione przez psa rasy amstaff. Obie trafiły do szpitala. Sprawą zajmuje się policja.

## Twierdził, że znalazł martwego kolegę i pobiegł po pomoc do sąsiada. Odpowie za zabójstwo
 - [https://tvn24.pl/katowice/kroczyce-zarzut-zabojstwa-dla-25-latka-po-smierci-jego-52-letniego-kolegi-wczesniej-twierdzil-ze-tylko-znalazl-cialo-7300259?source=rss](https://tvn24.pl/katowice/kroczyce-zarzut-zabojstwa-dla-25-latka-po-smierci-jego-52-letniego-kolegi-wczesniej-twierdzil-ze-tylko-znalazl-cialo-7300259?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T08:59:28+00:00

<img alt="Twierdził, że znalazł martwego kolegę i pobiegł po pomoc do sąsiada. Odpowie za zabójstwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-otleie-trwaja-poszukiwania-sprawcy-7198710/alternates/LANDSCAPE_1280" />
    Dożywotnie więzienie grozi 25-latkowi, który w gminie Kroczyce koło Zawiercia (woj. śląskie) miał zabić swojego 52-letniego kolegę. Według ustaleń policjantów mężczyzna wszedł do jego domu i kilkukrotnie dźgnął go nożem. 25-latek mówił wcześniej śledczym, że znalazł swojego starszego kolegę nieprzytomnego, po czym pobiegł do najbliższego sąsiada, by wezwać pomoc.

## Nie żyje Ron Cephas Jones. Aktor, znany m.in. z serialu "Tacy jesteśmy", zmarł w wieku 66 lat
 - [https://tvn24.pl/kultura-i-styl/ron-cephas-jones-nie-zyje-aktor-znany-z-serialu-tacy-jestesmy-zmarl-w-wieku-66-lat-7300167?source=rss](https://tvn24.pl/kultura-i-styl/ron-cephas-jones-nie-zyje-aktor-znany-z-serialu-tacy-jestesmy-zmarl-w-wieku-66-lat-7300167?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T07:58:17+00:00

<img alt="Nie żyje Ron Cephas Jones. Aktor, znany m.in. z serialu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dr8pbb-ron-cephas-jones-nie-zyje-7300091/alternates/LANDSCAPE_1280" />
    Nie żyje Ron Cephas Jones, amerykański aktor teatralny i telewizyjny. Międzynarodową sławę przyniosła mu rola Williama "Shakespeare'a" Hilla w serialu "Tacy jesteśmy", za którą otrzymał dwie statuetki Emmy. O śmierci 66-latka poinformował w niedzielę jego menadżer Dan Spilo.

## Duża wygrana w Lotto. Podano, gdzie padła
 - [https://tvn24.pl/biznes/pieniadze/gizycko-szostka-wlotto-w-gizycku-wyniki-losowania-lotto-190823-7300183?source=rss](https://tvn24.pl/biznes/pieniadze/gizycko-szostka-wlotto-w-gizycku-wyniki-losowania-lotto-190823-7300183?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T07:56:03+00:00

<img alt="Duża wygrana w Lotto. Podano, gdzie padła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fpmpdt-gizycko-mazury-kisajno-7300191/alternates/LANDSCAPE_1280" />
    W sobotnim losowaniu Lotto padła główna wygrana w wysokości blisko 6 milionów złotych. Szóstkę odnotowano w Giżycku - wynika z informacji dostępnych na stronie Totalizatora Sportowego.

## Pożar na Teneryfie. Ogień zniszczył ponad połowę drzewostanów
 - [https://tvn24.pl/tvnmeteo/swiat/teneryfa-walka-z-pozarem-ogien-zniszczyl-ponad-polowe-drzewostanow-7300085?source=rss](https://tvn24.pl/tvnmeteo/swiat/teneryfa-walka-z-pozarem-ogien-zniszczyl-ponad-polowe-drzewostanow-7300085?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T07:38:06+00:00

<img alt="Pożar na Teneryfie. Ogień zniszczył ponad połowę drzewostanów" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yhonp7-pozary-na-teneryfie-7300135/alternates/LANDSCAPE_1280" />
    Na Teneryfie trwają próby opanowania gigantycznego pożaru, który od prawie tygodnia trawi lasy. Strażacy mają nadzieję, że bardziej sprzyjające warunki meteorologiczne pomogą w walce z żywiołem. Do tej pory płomienie pochłonęły ponad połowę drzewostanów na wyspie.

## Światła pamięci ku czci ofiar akcji likwidacyjnej białostockiego getta
 - [https://tvn24.pl/bialystok/bialystok-swiatla-pamieci-ku-czci-ofiar-akcji-likwidacyjnej-getta-7299880?source=rss](https://tvn24.pl/bialystok/bialystok-swiatla-pamieci-ku-czci-ofiar-akcji-likwidacyjnej-getta-7299880?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T06:43:43+00:00

<img alt="Światła pamięci ku czci ofiar akcji likwidacyjnej białostockiego getta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7bo5j1-uczcili-ofiary-akcji-likwidacyjnej-bialostockiego-getta-7300080/alternates/LANDSCAPE_1280" />
    Światła pamięci ku czci ofiar akcji likwidacyjnej białostockiego getta zapłonęły w niedzielny wieczór na torach kolejowych w pobliżu dawnego Dworca Poleskiego, z którego do obozów koncentracyjnych odjeżdżały niemieckie transporty Żydów.

## Mołdawia nie wpuściła Gorana Bregovicia. "Byliśmy bardzo rozczarowani". Belgrad żąda wyjaśnień
 - [https://tvn24.pl/swiat/goran-bregovic-nie-wpuszczony-do-moldawii-szef-serbskiej-dyplomacji-zada-wyjasnien-7299889?source=rss](https://tvn24.pl/swiat/goran-bregovic-nie-wpuszczony-do-moldawii-szef-serbskiej-dyplomacji-zada-wyjasnien-7299889?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T04:42:17+00:00

<img alt="Mołdawia nie wpuściła Gorana Bregovicia. " src="https://tvn24.pl/najnowsze/cdn-zdjeciec78479f7ad030fa4186509489fb958f1-goran-bregovic-gra-od-lat-tam-gdzie-mu-zaplaca-3807790/alternates/LANDSCAPE_1280" />
    Kompozytorowi Goranowi Bregoviciowi, który w niedzielę wylądował na lotnisku w Kiszyniowie, odmówiono wjazdu do Mołdawii. Muzyk miał wziąć udział w organizowanym w stolicy kraju festiwalu. Wyjaśnienia sprawy zażądał minister spraw zagranicznych Serbii Ivica Daczić - podała agencja Tanjug.

## Utrudnienia dla kierowców w trzech dzielnicach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zmiany-w-ruchu-w-trzech-dzielnicach-7299491?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zmiany-w-ruchu-w-trzech-dzielnicach-7299491?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T04:40:22+00:00

<img alt="Utrudnienia dla kierowców w trzech dzielnicach  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a11ky1-prace-drogowe-zdjecie-ilustracyjne-7224541/alternates/LANDSCAPE_1280" />
    W związku z pracami kolejarzy, tramwajarzy i wodociągowców, a także remontem ulicy należy spodziewać się utrudnień na Pradze Południe, Mokotowie i Białołęce. W tej ostatniej dzielnicy niektóre linie autobusowe zostaną skierowane na objazd.

## Gdzie jest burza? Po południu znów kłębią się ciemne chmury
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-2108-sprawdz-gdzie-jest-burza-aktualna-mapa-i-radar-burz-7299978?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-2108-sprawdz-gdzie-jest-burza-aktualna-mapa-i-radar-burz-7299978?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T04:20:21+00:00

<img alt="Gdzie jest burza? Po południu znów kłębią się ciemne chmury" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-iupsgc-burze-burza-z-piorunami-5194282/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W poniedziałek 21.08 nad Polską pojawiają się wyładowania atmosferyczne. Wiatr w porywach osiąga prędkość do 70 kilometrów na godzinę, możliwy jest grad. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w Polsce na tvnmeteo.pl.

## Sinice w Bałtyku. Zamknięto większość kąpielisk w Trójmieście
 - [https://tvn24.pl/pomorze/sinice-w-baltyku-2023-mapa-ktore-plaze-sa-zamkniete-21082023-7201785?source=rss](https://tvn24.pl/pomorze/sinice-w-baltyku-2023-mapa-ktore-plaze-sa-zamkniete-21082023-7201785?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T04:10:00+00:00

<img alt="Sinice w Bałtyku. Zamknięto większość kąpielisk w Trójmieście" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kormc7-baltyk-sinice-6086528/alternates/LANDSCAPE_1280" />
    Z danych Głównego Inspektoratu Sanitarnego przekazanych w niedzielę, 20 sierpnia, wynika, że na nadmorskich kąpieliskach ponownie pojawiły się sinice - problem dotyczy większości plaż w Gdyni, Sopocie i Gdańsku. Obowiązuje tam zakaz kąpieli także rano w poniedziałek, 21 sierpnia, dopóki sanepid nie poda najnowszych informacji. Na plaży w Łebie pojawiła się także czerwona flaga, ale w związku z bakteriami E. coli w wodzie.

## Pięć rzeczy, które warto wiedzieć 21 sierpnia
 - [https://tvn24.pl/polska/piecrzeczy-ktore-warto-wiedziec-21-sierpnia-2023-roku-7299913?source=rss](https://tvn24.pl/polska/piecrzeczy-ktore-warto-wiedziec-21-sierpnia-2023-roku-7299913?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T03:40:02+00:00

<img alt="Pięć rzeczy, które warto wiedzieć 21 sierpnia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jn88wm-pozar-na-teneryfie-7298743/alternates/LANDSCAPE_1280" />
    Niebezpieczny incydent z udziałem policyjnego śmigłowca Black Hawk na pikniku wojskowym, tragiczny wypadek autobusu z kibicami klubu piłkarskiego Corinthians w Brazylii, potężne pożary lasów w Grecji i na Teneryfie, zapowiedź przekazania myśliwców F-16 Ukrainie przez Holandię i Danię, Jarosław Kaczyński o wysokości 14. emerytury. Oto pięć rzeczy, które warto dziś wiedzieć.

## Wszczęto śledztwo w sprawie incydentu z policyjnym Black Hawkiem
 - [https://tvn24.pl/polska/mazowieckie-incydent-podczas-pikniku-wojskowego-policyjny-smiglowiec-zahaczyl-o-linie-energetyczna-sledztwo-prokuratury-7299844?source=rss](https://tvn24.pl/polska/mazowieckie-incydent-podczas-pikniku-wojskowego-policyjny-smiglowiec-zahaczyl-o-linie-energetyczna-sledztwo-prokuratury-7299844?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T03:31:00+00:00

<img alt="Wszczęto śledztwo w sprawie incydentu z policyjnym Black Hawkiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-38kgv9-incydent-podczas-pikniku-policyjny-smiglowiec-zahaczyl-o-linie-energetyczna-7299834/alternates/LANDSCAPE_1280" />
    Prokuratura wszczęła śledztwo w sprawie incydentu z udziałem policyjnego Black Hawka. Śmigłowiec wczoraj przyczynił się do zerwania linii energetycznej podczas pikniku w Sarnowej Górze. Policja przekazała, że powiadomiła o wydarzeniu śledczych oraz Komisję Badania Wypadków Lotniczych Lotnictwa Państwowego. Czynności prowadzi też Biuro Kontroli KGP. Na pikniku obecny był wiceminister w resorcie spraw wewnętrznych i administracji Maciej Wąsik.

## Ukraińcy wciąż czekają na czołgi. "Nie mamy zasobów do przeprowadzenia ataków, o które Zachód błaga"
 - [https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-niedziela-20-sierpnia-2023-roku-7299929?source=rss](https://tvn24.pl/swiat/atak-rosji-na-ukraine-relacja-niedziela-20-sierpnia-2023-roku-7299929?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T03:18:17+00:00

<img alt="Ukraińcy wciąż czekają na czołgi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-54t34t-leopard-2-7218475/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 544 dni. Ukraina do tej pory dostała tylko 60 czołgów Leopard, zamiast obiecanych kilkuset - podał w niedzielę brytyjski tygodnik "The Economist", powołując się na źródło w Sztabie Generalnym Sił Zbrojnych Ukrainy. Jak twierdzi portal tygodnika, wobec rozczarowującego tempa ukraińskiej kontrofensywy, to że zachodnia broń nie jest dostarczana w takich ilościach, jak to było zapowiadane, jest szczególnie frustrujące dla władz w Kijowie. Przedstawiciel biura prezydenta Wołodymyra Zełenskiego Serhij Łeszczenko przyznał, że jest to "martwiące i demotywujące". W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Pogoda na dziś - poniedziałek 21.08. Front nad częścią Polski
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2108-front-nad-czescia-polski-7299864?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-poniedzialek-2108-front-nad-czescia-polski-7299864?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-08-21T00:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek 21.08. Front nad częścią Polski" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-gn9szk-burze-intensywne-opady-deszczu-5707113/alternates/LANDSCAPE_1280" />
    Poniedziałek w niektórych regionach przyniesie przelotne opady deszczu i burze. W większości kraju aura dopisze przez cały dzień. Będzie gorąco, a miejscami także upalnie.

