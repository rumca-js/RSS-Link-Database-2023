# Source:Washington Examiner - Tech, URL:https://feeds.feedburner.com/dcexaminer/tech, language:en-US

## White House science adviser says Biden is 'laser focused' on AI and its dangers
 - [https://www.washingtonexaminer.com/policy/technology/white-house-science-advisor-biden-laser-focused-ai-dangers](https://www.washingtonexaminer.com/policy/technology/white-house-science-advisor-biden-laser-focused-ai-dangers)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-08-21T14:12:43+00:00

One of President Joe Biden's leading science and technology advisers said he is "laser focused" on artificial intelligence and its possible dangers.

## White House science adviser says Biden is 'laser focused' on AI and its dangers
 - [https://www.washingtonexaminer.com/policy/technology/white-house-science-adviser-biden-laser-focused-ai-dangers](https://www.washingtonexaminer.com/policy/technology/white-house-science-adviser-biden-laser-focused-ai-dangers)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/tech
 - date published: 2023-08-21T14:12:43+00:00

One of President Joe Biden's leading science and technology advisers said he is "laser focused" on artificial intelligence and its possible dangers.

