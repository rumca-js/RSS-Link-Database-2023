# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Sąd wyznaczył Trumpowi kaucję. Były prezydent USA usłyszy zarzuty
 - [https://wydarzenia.interia.pl/zagranica/news-sad-wyznaczyl-trumpowi-kaucje-byly-prezydent-usa-uslyszy-zar,nId,6976958](https://wydarzenia.interia.pl/zagranica/news-sad-wyznaczyl-trumpowi-kaucje-byly-prezydent-usa-uslyszy-zar,nId,6976958)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T22:01:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sad-wyznaczyl-trumpowi-kaucje-byly-prezydent-usa-uslyszy-zar,nId,6976958"><img align="left" alt="Sąd wyznaczył Trumpowi kaucję. Były prezydent USA usłyszy zarzuty" src="https://i.iplsc.com/sad-wyznaczyl-trumpowi-kaucje-byly-prezydent-usa-uslyszy-zar/0007TTT6MTA05P5K-C321.jpg" /></a>Donald Trump żeby uniknąć aresztu będzie musiał zapłacić 200 tys. dolarów kaucji i zobowiązać się do niezastraszania potencjalnych świadków. Były prezydent USA i 18 innych oskarżonych mają stawić się w sądzie w piątek.</p><br clear="all" />

## Prigożyn miał zdradzić swoje położenie. "Walka o sprawiedliwość i szczęście"
 - [https://wydarzenia.interia.pl/zagranica/news-prigozyn-mial-zdradzic-swoje-polozenie-walka-o-sprawiedliwos,nId,6976946](https://wydarzenia.interia.pl/zagranica/news-prigozyn-mial-zdradzic-swoje-polozenie-walka-o-sprawiedliwos,nId,6976946)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T20:47:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prigozyn-mial-zdradzic-swoje-polozenie-walka-o-sprawiedliwos,nId,6976946"><img align="left" alt="Prigożyn miał zdradzić swoje położenie. &quot;Walka o sprawiedliwość i szczęście&quot;" src="https://i.iplsc.com/prigozyn-mial-zdradzic-swoje-polozenie-walka-o-sprawiedliwos/000H5IWHH45EJJ52-C321.jpg" /></a>Jewgienij Prigożyn, założyciel Grupy Wagnera opublikował nagranie, w którym powiedział, że znajduje się w Afryce. Jak podała &quot;Ukraińska Prawda&quot;, szef najemników miał przekazać, że walczy &quot;o sprawiedliwość i szczęście&quot; afrykańskich narodów&quot;.</p><br clear="all" />

## 96 śmigłowców AH-64E Apache dla Polski. USA zatwierdziły sprzedaż
 - [https://wydarzenia.interia.pl/kraj/news-96-smiglowcow-ah-64e-apache-dla-polski-usa-zatwierdzily-sprz,nId,6976927](https://wydarzenia.interia.pl/kraj/news-96-smiglowcow-ah-64e-apache-dla-polski-usa-zatwierdzily-sprz,nId,6976927)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:43:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-96-smiglowcow-ah-64e-apache-dla-polski-usa-zatwierdzily-sprz,nId,6976927"><img align="left" alt="96 śmigłowców AH-64E Apache dla Polski. USA zatwierdziły sprzedaż" src="https://i.iplsc.com/96-smiglowcow-ah-64e-apache-dla-polski-usa-zatwierdzily-sprz/000HKC0EMMDWGLL6-C321.jpg" /></a>Departament Stanu wyraził zgodę na potencjalną sprzedaż Polsce 96 śmigłowców szturmowych AH-64E Apache wraz z uzbrojeniem, wyceniając je na 12 miliardów dolarów - podała należąca do Pentagonu agencja Defense Security Cooperation Agency (DSCA).</p><br clear="all" />

## Kobieta próbowała schłodzić auto. Wpadła pod jego koła
 - [https://wydarzenia.interia.pl/kraj/news-kobieta-probowala-schlodzic-auto-wpadla-pod-jego-kola,nId,6976925](https://wydarzenia.interia.pl/kraj/news-kobieta-probowala-schlodzic-auto-wpadla-pod-jego-kola,nId,6976925)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:37:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kobieta-probowala-schlodzic-auto-wpadla-pod-jego-kola,nId,6976925"><img align="left" alt="Kobieta próbowała schłodzić auto. Wpadła pod jego koła" src="https://i.iplsc.com/kobieta-probowala-schlodzic-auto-wpadla-pod-jego-kola/000HKBYTJSFQEU2Q-C321.jpg" /></a>Policjanci ustalają dokładne okoliczności śmierci 71-letniej kobiety, która w miniony weekend zginęła pod kołami swojego samochodu w Rudnikach pod Częstochową. Została potrącona, gdy stojąc przy aucie przekręciła kluczyk w stacyjce. Wtedy pozostawiony na wstecznym biegu samochód ruszył.</p><br clear="all" />

## Nie żyje saudyjska księżniczka. Tajemnicze okoliczności śmierci 35-latki
 - [https://wydarzenia.interia.pl/zagranica/news-nie-zyje-saudyjska-ksiezniczka-tajemnicze-okolicznosci-smier,nId,6976886](https://wydarzenia.interia.pl/zagranica/news-nie-zyje-saudyjska-ksiezniczka-tajemnicze-okolicznosci-smier,nId,6976886)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:32:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-zyje-saudyjska-ksiezniczka-tajemnicze-okolicznosci-smier,nId,6976886"><img align="left" alt="Nie żyje saudyjska księżniczka. Tajemnicze okoliczności śmierci 35-latki" src="https://i.iplsc.com/nie-zyje-saudyjska-ksiezniczka-tajemnicze-okolicznosci-smier/000HKBVFOBKX1CL1-C321.jpg" /></a>Księżniczka Noura bint Mohammed bin Abdulaziz bin Saud bin Faisal Al Saud nie żyje. Arabia Saudyjska pogrążyła się w żałobie, tym bardziej, że businesswoman miała 35 lat. Okoliczności jej śmierci nie są znane.</p><br clear="all" />

## Ukraińskie media: F-16 z ubiegłego wieku, część z nich nie będzie latać
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-media-f-16-z-ubieglego-wieku-czesc-z-nich-nie-bed,nId,6976890](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-media-f-16-z-ubieglego-wieku-czesc-z-nich-nie-bed,nId,6976890)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:24:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-media-f-16-z-ubieglego-wieku-czesc-z-nich-nie-bed,nId,6976890"><img align="left" alt="Ukraińskie media: F-16 z ubiegłego wieku, część z nich nie będzie latać" src="https://i.iplsc.com/ukrainskie-media-f-16-z-ubieglego-wieku-czesc-z-nich-nie-bed/000HKBPZ24BAHJAT-C321.jpg" /></a>Ukraina otrzyma myśliwce F-16 wyprodukowane jeszcze w ubiegłym wieku i część z nich nie będzie nadawać się do latania - podał w poniedziałek ukraiński portal Defence Express. Mimo to maszyny, które będą zdolne do wykonywania zadań bojowych określono jako pełnowartościowe. Nie jest wykluczone też, że część z nich poddana zostanie modernizacji. </p><br clear="all" />

## "Łowcy potworów" przygotowują się na największe polowanie od 50 lat
 - [https://wydarzenia.interia.pl/zagranica/news-lowcy-potworow-przygotowuja-sie-na-najwieksze-polowanie-od-5,nId,6976876](https://wydarzenia.interia.pl/zagranica/news-lowcy-potworow-przygotowuja-sie-na-najwieksze-polowanie-od-5,nId,6976876)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:20:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lowcy-potworow-przygotowuja-sie-na-najwieksze-polowanie-od-5,nId,6976876"><img align="left" alt="&quot;Łowcy potworów&quot; przygotowują się na największe polowanie od 50 lat" src="https://i.iplsc.com/lowcy-potworow-przygotowuja-sie-na-najwieksze-polowanie-od-5/000HKBEUL62PIC98-C321.jpg" /></a>W najbliższy weekend detektywi-amatorzy z zamiłowaniem do zjawisk nadprzyrodzonych spróbują rozwikłać największą tajemnicę Szkocji. &quot;Łowcy potworów&quot; z tak odległych miejsc jak Japonia czy Nowa Zelandia będą śledzić transmisje na żywo ze szkockiego jeziora Loch Ness w nadziei na odkrycie, czy słynny potwór, pieszczotliwie nazwany Nessie, rzeczywiście istnieje.</p><br clear="all" />

## Zarzuty wobec Trumpa. Zaskakujący wynik sondażu
 - [https://wydarzenia.interia.pl/zagranica/news-zarzuty-wobec-trumpa-zaskakujacy-wynik-sondazu,nId,6976917](https://wydarzenia.interia.pl/zagranica/news-zarzuty-wobec-trumpa-zaskakujacy-wynik-sondazu,nId,6976917)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:13:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zarzuty-wobec-trumpa-zaskakujacy-wynik-sondazu,nId,6976917"><img align="left" alt="Zarzuty wobec Trumpa. Zaskakujący wynik sondażu" src="https://i.iplsc.com/zarzuty-wobec-trumpa-zaskakujacy-wynik-sondazu/000HKBZGPIC9AL78-C321.jpg" /></a>Donald Trump mimo serii zarzutów wysuniętych przez śledczych w Georgii  zalicza wzrost poparcia wśród republikanów - wynika z opublikowanego w poniedziałek sondażu telewizji NBC News i gazety Des Moines Register w Iowa. Dzień wcześniej były prezydent USA oświadczył, że z powodu znacznej przewagi nad resztą stawki zrezygnuje z udziału w debatach przed republikańskimi prawyborami.</p><br clear="all" />

## Warszawa: Nie żyje emerytka przytrzaśnięta przez drzwi autobusu
 - [https://wydarzenia.interia.pl/kraj/news-warszawa-nie-zyje-emerytka-przytrzasnieta-przez-drzwi-autobu,nId,6976854](https://wydarzenia.interia.pl/kraj/news-warszawa-nie-zyje-emerytka-przytrzasnieta-przez-drzwi-autobu,nId,6976854)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T19:08:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-warszawa-nie-zyje-emerytka-przytrzasnieta-przez-drzwi-autobu,nId,6976854"><img align="left" alt="Warszawa: Nie żyje emerytka przytrzaśnięta przez drzwi autobusu" src="https://i.iplsc.com/warszawa-nie-zyje-emerytka-przytrzasnieta-przez-drzwi-autobu/000HKBFC4GXE5I59-C321.jpg" /></a>Nie żyje 87-letnia kobieta która, podczas wysiadania z warszawskiego autobusu na Bielanach została przytrzaśnięta w drzwiach - dowiedziała się PAP. Prokuratura prowadzi śledztwo w sprawie wypadku.</p><br clear="all" />

## Niemiecki europoseł o Polsce i Węgrzech: UE finansuje swoich wrogów
 - [https://wydarzenia.interia.pl/news-niemiecki-europosel-o-polsce-i-wegrzech-ue-finansuje-swoich-,nId,6976869](https://wydarzenia.interia.pl/news-niemiecki-europosel-o-polsce-i-wegrzech-ue-finansuje-swoich-,nId,6976869)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T18:50:00+00:00

<p><a href="https://wydarzenia.interia.pl/news-niemiecki-europosel-o-polsce-i-wegrzech-ue-finansuje-swoich-,nId,6976869"><img align="left" alt="Niemiecki europoseł o Polsce i Węgrzech: UE finansuje swoich wrogów" src="https://i.iplsc.com/niemiecki-europosel-o-polsce-i-wegrzech-ue-finansuje-swoich/000HKBS79R35I57I-C321.jpg" /></a>- Wiele miliardów euro nadal płynie na Węgry i do Polski. Opowiadam się za wstrzymaniem wszystkich funduszy do czasu przeprowadzenia odpowiednich reform - mówił w wywiadzie dla dziennika &quot;Frankfurter Rundschau&quot; niemiecki europoseł Daniel Freund, polityk Zielonych. Polityk mówił o mechanizmach, jakie Bruksela stosuje wobec Warszawy i Budapesztu za tzw. łamanie praworządności.</p><br clear="all" />

## Tragedia w Moskwie. Turyści nie mogli wydostać się z zalanych kanałów
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-w-moskwie-turysci-nie-mogli-wydostac-sie-z-zalanych,nId,6976839](https://wydarzenia.interia.pl/zagranica/news-tragedia-w-moskwie-turysci-nie-mogli-wydostac-sie-z-zalanych,nId,6976839)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T18:21:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-w-moskwie-turysci-nie-mogli-wydostac-sie-z-zalanych,nId,6976839"><img align="left" alt="Tragedia w Moskwie. Turyści nie mogli wydostać się z zalanych kanałów" src="https://i.iplsc.com/tragedia-w-moskwie-turysci-nie-mogli-wydostac-sie-z-zalanych/000HKBEKYUAWR35I-C321.jpg" /></a>W Moskwie trwają poszukiwania kilku osób, które zostały uwięzione w kanałach ściekowych przez gwałtowne ulewy. Mer stolicy Siergiej Sobanin poinformował, że do tej pory odnaleziono zwłoki czterech osób. Poszukiwani oraz ofiary mieli brać udział w wycieczce z przewodnikiem.</p><br clear="all" />

## Nocleg w Tatrach za tysiąc złotych. Służby ostrzegają
 - [https://wydarzenia.interia.pl/malopolskie/news-nocleg-w-tatrach-za-tysiac-zlotych-sluzby-ostrzegaja,nId,6976848](https://wydarzenia.interia.pl/malopolskie/news-nocleg-w-tatrach-za-tysiac-zlotych-sluzby-ostrzegaja,nId,6976848)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T17:42:18+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-nocleg-w-tatrach-za-tysiac-zlotych-sluzby-ostrzegaja,nId,6976848"><img align="left" alt="Nocleg w Tatrach za tysiąc złotych. Służby ostrzegają" src="https://i.iplsc.com/nocleg-w-tatrach-za-tysiac-zlotych-sluzby-ostrzegaja/000HKBDDDYPODPJI-C321.jpg" /></a>Dwóch turystów spędziło noc nad brzegiem Morskiego Oka. Za to wykroczenie ukarano ich mandatem w wysokości tysiąca złotych. Biwakowanie pod gołym niebem w Tatrzańskim Parku Narodowym jest bezwzględnie zabronione - przypominają władze parku. </p><br clear="all" />

## "Tusk nie zasługuje na kolejną szansę". Jest nowy spot PiS
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-nie-zasluguje-na-kolejna-szanse-jest-nowy-spot-pis,nId,6976832](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-nie-zasluguje-na-kolejna-szanse-jest-nowy-spot-pis,nId,6976832)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T17:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tusk-nie-zasluguje-na-kolejna-szanse-jest-nowy-spot-pis,nId,6976832"><img align="left" alt="&quot;Tusk nie zasługuje na kolejną szansę&quot;. Jest nowy spot PiS" src="https://i.iplsc.com/tusk-nie-zasluguje-na-kolejna-szanse-jest-nowy-spot-pis/000HKBA70N74WBS1-C321.jpg" /></a>&quot;Tusk nie zasługuje na kolejną szansę&quot; - to slogan najnowszego spotu Prawa i Sprawiedliwości. Nagranie pojawiło się w poniedziałek w mediach społecznościowych. Kilka postaci w nim występujących zarzuca byłemu premierowi, a obecnemu liderowi Platformy Obywatelskiej m.in. &quot;niszczenie polskiej gospodarki, poniesienie wieku emerytalnego, rozbrojenie polskiej armii oraz ucieczkę do Brukseli&quot;.</p><br clear="all" />

## "Biała rodzina to nie prawdziwi londyńczycy". Afera wokół burmistrza miasta
 - [https://wydarzenia.interia.pl/zagranica/news-biala-rodzina-to-nie-prawdziwi-londynczycy-afera-wokol-burmi,nId,6976628](https://wydarzenia.interia.pl/zagranica/news-biala-rodzina-to-nie-prawdziwi-londynczycy-afera-wokol-burmi,nId,6976628)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T16:51:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-biala-rodzina-to-nie-prawdziwi-londynczycy-afera-wokol-burmi,nId,6976628"><img align="left" alt="&quot;Biała rodzina to nie prawdziwi londyńczycy&quot;. Afera wokół burmistrza miasta" src="https://i.iplsc.com/biala-rodzina-to-nie-prawdziwi-londynczycy-afera-wokol-burmi/000HKB4YKMGEN2BH-C321.jpg" /></a>Białe rodziny &quot;nie reprezentują prawdziwych londyńczyków&quot; - takie hasło pojawiło się na stronie londyńskiego ratusza pod zdjęciem czteroosobowej rodziny o tym kolorze skóry. Burmistrza miasta - Sadiqa Khana - skrytykowano i oskarżono o rasizm.
</p><br clear="all" />

## Alert ambasady USA w Mińsku. Wzywa obywateli do opuszczenia kraju
 - [https://wydarzenia.interia.pl/zagranica/news-alert-ambasady-usa-w-minsku-wzywa-obywateli-do-opuszczenia-k,nId,6976814](https://wydarzenia.interia.pl/zagranica/news-alert-ambasady-usa-w-minsku-wzywa-obywateli-do-opuszczenia-k,nId,6976814)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T16:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-alert-ambasady-usa-w-minsku-wzywa-obywateli-do-opuszczenia-k,nId,6976814"><img align="left" alt="Alert ambasady USA w Mińsku. Wzywa obywateli do opuszczenia kraju" src="https://i.iplsc.com/alert-ambasady-usa-w-minsku-wzywa-obywateli-do-opuszczenia-k/000HKB6STOYS2VBW-C321.jpg" /></a>&quot;Obywatele USA przebywający na Białorusi powinni natychmiast opuścić kraj&quot; - wzywa ambasada Stanów Zjednoczonych w Mińsku. Placówka wydała alert, w którym przestrzega przed podróżami także do Rosji i Ukrainy. &quot;Jeśli zdecydujesz się na podróż na Białoruś, przygotuj plan awaryjny, który nie będzie opierał się na pomocy rządu USA&quot; - zaznacza ambasada.</p><br clear="all" />

## Coś przykuło jej uwagę. Nieoczekiwany pasażer mógł przejechać nawet 800 km
 - [https://wydarzenia.interia.pl/zagranica/news-cos-przykulo-jej-uwage-nieoczekiwany-pasazer-mogl-przejechac,nId,6976830](https://wydarzenia.interia.pl/zagranica/news-cos-przykulo-jej-uwage-nieoczekiwany-pasazer-mogl-przejechac,nId,6976830)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T16:44:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-cos-przykulo-jej-uwage-nieoczekiwany-pasazer-mogl-przejechac,nId,6976830"><img align="left" alt="Coś przykuło jej uwagę. Nieoczekiwany pasażer mógł przejechać nawet 800 km " src="https://i.iplsc.com/cos-przykulo-jej-uwage-nieoczekiwany-pasazer-mogl-przejechac/000HKBERN6TOYRYL-C321.jpg" /></a>Tom Hutchings właściciel firmy taksówkarskiej specjalizującej się w długich trasach, nie krył zdziwienia, gdy na koniec pracy odkrył pod maską samochodu kociaka. Zwierzę mogło przejechać z nim nawet 800 km. </p><br clear="all" />

## Półtorametrowy pyton wypatrzony w Poznaniu. Pełzał po chodniku
 - [https://wydarzenia.interia.pl/wielkopolskie/news-poltorametrowy-pyton-wypatrzony-w-poznaniu-pelzal-po-chodnik,nId,6976727](https://wydarzenia.interia.pl/wielkopolskie/news-poltorametrowy-pyton-wypatrzony-w-poznaniu-pelzal-po-chodnik,nId,6976727)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T16:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-poltorametrowy-pyton-wypatrzony-w-poznaniu-pelzal-po-chodnik,nId,6976727"><img align="left" alt="Półtorametrowy pyton wypatrzony w Poznaniu. Pełzał po chodniku" src="https://i.iplsc.com/poltorametrowy-pyton-wypatrzony-w-poznaniu-pelzal-po-chodnik/000HKB50K7C3ESSL-C321.jpg" /></a>Około półtora metra miał pyton, który wił się na jednym z chodników poznańskiej Wildy. Gada zauważyli przechodnie. - Dzisiaj w nocy otrzymaliśmy zgłoszenie o wężu, który pełzał przy zabudowaniach ulicy Różanej - powiedział portalowi epoznan.pl Przemysław Piwecki ze straży miejskiej. </p><br clear="all" />

## Rosja wściekła po decyzji członka NATO. "Eskalacja konfliktu"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-wsciekla-po-decyzji-czlonka-nato-eskalacja-konfliktu,nId,6976619](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-wsciekla-po-decyzji-czlonka-nato-eskalacja-konfliktu,nId,6976619)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T15:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-wsciekla-po-decyzji-czlonka-nato-eskalacja-konfliktu,nId,6976619"><img align="left" alt="Rosja wściekła po decyzji członka NATO. &quot;Eskalacja konfliktu&quot;" src="https://i.iplsc.com/rosja-wsciekla-po-decyzji-czlonka-nato-eskalacja-konfliktu/000HKAQNW9K4TSKI-C321.jpg" /></a>Ambasador Rosji w Danii zareagował na decyzję o przekazaniu Ukrainie myśliwców F-16. Na taki krok zdecydowała się wcześniej zarówno Dania, jak i Holandia. W poniedziałek oba kraje odwiedził Wołodymyr Zełenski. - Fakt, że Dania zdecydowała się teraz przekazać Ukrainie samoloty F-16, prowadzi do eskalacji konfliktu - stwierdził rosyjski dyplomata.</p><br clear="all" />

## Karambol pod Olsztynem. Wśród poszkodowanych są dzieci
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-karambol-pod-olsztynem-wsrod-poszkodowanych-sa-dzieci,nId,6976635](https://wydarzenia.interia.pl/warminsko-mazurskie/news-karambol-pod-olsztynem-wsrod-poszkodowanych-sa-dzieci,nId,6976635)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T15:24:15+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-karambol-pod-olsztynem-wsrod-poszkodowanych-sa-dzieci,nId,6976635"><img align="left" alt="Karambol pod Olsztynem. Wśród poszkodowanych są dzieci" src="https://i.iplsc.com/karambol-pod-olsztynem-wsrod-poszkodowanych-sa-dzieci/000HKALM2JJ4YIOX-C321.jpg" /></a>Cztery osoby, w tym dwoje dzieci, trafiło do szpitala po karambolu w miejscowości Wójtowo na S16 pomiędzy Olsztynem a Barczewem (woj. warmińsko-mazurskie). Na pasie w kierunku Mazur zderzyło się w poniedziałek po południu w sumie pięć samochodów. </p><br clear="all" />

## Szwedzi zabiją rekordową liczbę niedźwiedzi. Wykorzystają psy
 - [https://wydarzenia.interia.pl/zagranica/news-szwedzi-zabija-rekordowa-liczbe-niedzwiedzi-wykorzystaja-psy,nId,6976534](https://wydarzenia.interia.pl/zagranica/news-szwedzi-zabija-rekordowa-liczbe-niedzwiedzi-wykorzystaja-psy,nId,6976534)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T15:14:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szwedzi-zabija-rekordowa-liczbe-niedzwiedzi-wykorzystaja-psy,nId,6976534"><img align="left" alt="Szwedzi zabiją rekordową liczbę niedźwiedzi. Wykorzystają psy" src="https://i.iplsc.com/szwedzi-zabija-rekordowa-liczbe-niedzwiedzi-wykorzystaja-psy/000HK9G9GDLUGPBC-C321.jpg" /></a>W Szwecji rozpoczął się sezon polowań na niedźwiedzie. W sezonie trwającym do 15 października w całym kraju może zginąć ich rekordowa liczba 649 osobników. Tylko w regionie Jamtland wydano pozwolenie na odstrzał 185 zwierząt. W tym roku, do polowania po raz pierwszy myśliwi będą mogli użyć psów. </p><br clear="all" />

## Szwecja nie odda gripenów Ukrainie. "Musimy bronić się sami"
 - [https://wydarzenia.interia.pl/zagranica/news-szwecja-nie-odda-gripenow-ukrainie-musimy-bronic-sie-sami,nId,6976605](https://wydarzenia.interia.pl/zagranica/news-szwecja-nie-odda-gripenow-ukrainie-musimy-bronic-sie-sami,nId,6976605)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T15:07:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szwecja-nie-odda-gripenow-ukrainie-musimy-bronic-sie-sami,nId,6976605"><img align="left" alt="Szwecja nie odda gripenów Ukrainie. &quot;Musimy bronić się sami&quot;" src="https://i.iplsc.com/szwecja-nie-odda-gripenow-ukrainie-musimy-bronic-sie-sami/0007HMGPU2TW3QIC-C321.jpg" /></a>Szwecja na razie nie przekaże Ukrainie samolotów Gripen, ale może to zrobić w przyszłości - powiedział premier tego kraju Ulf Kristersson. Wypowiedź premiera to reakcja na niedzielne deklaracje Danii oraz Holandii, które oddadzą Ukraińcom swoje maszyny F-16. Mimo międzynarodowego wsparcia potrzeby sprzętowe wschodniego sąsiada Polski pozostają ogromne.  </p><br clear="all" />

## Fiński prezydent: Przed wojną w Putinie coś się zmieniło
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-finski-prezydent-przed-wojna-w-putinie-cos-sie-zmienilo,nId,6976564](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-finski-prezydent-przed-wojna-w-putinie-cos-sie-zmienilo,nId,6976564)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T14:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-finski-prezydent-przed-wojna-w-putinie-cos-sie-zmienilo,nId,6976564"><img align="left" alt="Fiński prezydent: Przed wojną w Putinie coś się zmieniło" src="https://i.iplsc.com/finski-prezydent-przed-wojna-w-putinie-cos-sie-zmienilo/000HKAI7BEYRV3V4-C321.jpg" /></a>- Przed wybuchem wojny w Putinie nastąpiła zmiana. Był znacznie bardziej sfrustrowany, nie tylko Ukrainą, ale też sytuacją z Zachodem - stwierdził fiński prezydent Sauli Niinistö. Jego zdaniem obecnie &quot;z rosyjskiej strony jest coraz więcej propagandy przeciwko Finlandii&quot;. </p><br clear="all" />

## Michał Kołodziejczak: Kornel Morawiecki przestrzegał mnie przed synem
 - [https://wydarzenia.interia.pl/kraj/news-michal-kolodziejczak-kornel-morawiecki-przestrzegal-mnie-prz,nId,6976574](https://wydarzenia.interia.pl/kraj/news-michal-kolodziejczak-kornel-morawiecki-przestrzegal-mnie-prz,nId,6976574)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T14:40:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-michal-kolodziejczak-kornel-morawiecki-przestrzegal-mnie-prz,nId,6976574"><img align="left" alt="Michał Kołodziejczak: Kornel Morawiecki przestrzegał mnie przed synem" src="https://i.iplsc.com/michal-kolodziejczak-kornel-morawiecki-przestrzegal-mnie-prz/000HKADBJX62STRE-C321.jpg" /></a>- Kornel Morawiecki powiedział mi jasno: proszę uważać na mojego syna, ja nie rozumiem jego decyzji - mówił na poniedziałkowej konferencji prasowej Michał Kłodziejczak. Tak lider AgroUnii odpowiedział na pytanie, o zaufanie. - Nie współpracuj z Mateuszem Morawieckim. On zawsze cię oszuka - dodał. W niedzielę szef rządu komentował start lidera AgroUnii z list Koalicji Obywatelskiej nazywając go &quot;jawnie prorosyjskim i probiałoruskim politykiem&quot;.</p><br clear="all" />

## Nielegalny baner Mejzy? Konserwator zabytków zapowiada kontrolę
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nielegalny-baner-mejzy-konserwator-zabytkow-zapowiada-kontro,nId,6976588](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nielegalny-baner-mejzy-konserwator-zabytkow-zapowiada-kontro,nId,6976588)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T14:23:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nielegalny-baner-mejzy-konserwator-zabytkow-zapowiada-kontro,nId,6976588"><img align="left" alt="Nielegalny baner Mejzy? Konserwator zabytków zapowiada kontrolę" src="https://i.iplsc.com/nielegalny-baner-mejzy-konserwator-zabytkow-zapowiada-kontro/000HKAEKD4FRKLBT-C321.jpg" /></a>Poseł Łukasz Mejza na jednym z historycznych budynków w Żaganiu wywiesił wielki baner. Problem w tym, że wcześniej nie poprosił o zgodę Lubuskiego Konserwatora Zabytków. Urząd zapowiada kontrolę.</p><br clear="all" />

## Sławomir Mentzen rzucał banknotami w widownię. "U nas kpina, u was program"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-slawomir-mentzen-rzucal-banknotami-w-widownie-u-nas-kpina-u-,nId,6976545](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-slawomir-mentzen-rzucal-banknotami-w-widownie-u-nas-kpina-u-,nId,6976545)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T13:51:02+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-slawomir-mentzen-rzucal-banknotami-w-widownie-u-nas-kpina-u-,nId,6976545"><img align="left" alt="Sławomir Mentzen rzucał banknotami w widownię. &quot;U nas kpina, u was program&quot;" src="https://i.iplsc.com/slawomir-mentzen-rzucal-banknotami-w-widownie-u-nas-kpina-u/000HK9HA740PIGSK-C321.jpg" /></a>Liderzy Konfederacji ruszyli w trasę po Polsce. Pierwszymi przystankami na drodze Sławomira Mentzena i Krzysztofa Bosaka były Kielce, Rzeszów i Bielsko-Biała. Podczas swoich wystąpień lider Nowej Nadziei zjawiał się na scenie z plikiem banknotów i rzucał nimi w stronę publiczności. - To nie były prawdziwe banknoty - mówi Interii rzecznik Konfederacji Anna Bryłka.</p><br clear="all" />

## Lucy Lethby skazana. Bezwzględne dożywocie dla pielęgniarki
 - [https://wydarzenia.interia.pl/zagranica/news-lucy-lethby-skazana-bezwzgledne-dozywocie-dla-pielegniarki,nId,6976504](https://wydarzenia.interia.pl/zagranica/news-lucy-lethby-skazana-bezwzgledne-dozywocie-dla-pielegniarki,nId,6976504)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T13:48:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lucy-lethby-skazana-bezwzgledne-dozywocie-dla-pielegniarki,nId,6976504"><img align="left" alt="Lucy Lethby skazana. Bezwzględne dożywocie dla pielęgniarki" src="https://i.iplsc.com/lucy-lethby-skazana-bezwzgledne-dozywocie-dla-pielegniarki/000HK9F679PQMWQ0-C321.jpg" /></a>Pielęgniarka Lucy Letby z Wielkiej Brytanii resztę życia spędzi w więzieniu. Kobietę skazano na karę bezwzględnego dożywocia za zamordowanie siedmiu noworodków i próbę zabicia kolejnych sześciu. - Była w niej głęboka wrogość granicząca z sadyzmem - podkreślił sędzia James Goss.</p><br clear="all" />

## Z jej rąk ginęły noworodki. Finał sprawy pielęgniarki
 - [https://wydarzenia.interia.pl/zagranica/news-z-jej-rak-ginely-noworodki-final-sprawy-pielegniarki,nId,6976504](https://wydarzenia.interia.pl/zagranica/news-z-jej-rak-ginely-noworodki-final-sprawy-pielegniarki,nId,6976504)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T13:48:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-z-jej-rak-ginely-noworodki-final-sprawy-pielegniarki,nId,6976504"><img align="left" alt="Z jej rąk ginęły noworodki. Finał sprawy pielęgniarki" src="https://i.iplsc.com/z-jej-rak-ginely-noworodki-final-sprawy-pielegniarki/000HK9F679PQMWQ0-C321.jpg" /></a>Pielęgniarka Lucy Letby z Wielkiej Brytanii resztę życia spędzi w więzieniu. Kobietę skazano na karę bezwzględnego dożywocia za zamordowanie siedmiu noworodków i próbę zabicia kolejnych sześciu. - Była w niej głęboka wrogość granicząca z sadyzmem - podkreślił sędzia James Goss.</p><br clear="all" />

## Groźny narkotyk na lizaku. Za śmierć czterolatka odpowiedzą rodzice
 - [https://wydarzenia.interia.pl/zagranica/news-grozny-narkotyk-na-lizaku-za-smierc-czterolatka-odpowiedza-r,nId,6976495](https://wydarzenia.interia.pl/zagranica/news-grozny-narkotyk-na-lizaku-za-smierc-czterolatka-odpowiedza-r,nId,6976495)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T13:42:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grozny-narkotyk-na-lizaku-za-smierc-czterolatka-odpowiedza-r,nId,6976495"><img align="left" alt="Groźny narkotyk na lizaku. Za śmierć czterolatka odpowiedzą rodzice" src="https://i.iplsc.com/grozny-narkotyk-na-lizaku-za-smierc-czterolatka-odpowiedza-r/000HK9L1OU9ORQDO-C321.jpg" /></a>36-letni Jason Moore i 35-letnia Amanda Moore z Rodzice czterolatka z hrabstwa Chester w Pensylwanii zostali oskarżeni o nieumyślne spowodowanie śmierci syna.  Przeprowadzone w trakcie dochodzenia policyjnego badania wykazały, że w organizmie dziecka był fentanyl. Niezwykle silny lek opioidowy znalazł się m.in. na lizaku w mieszkaniu zmarłego dziecka. Małżeństwo Amerykanów stanie teraz przed sądem. </p><br clear="all" />

## Doprowadził do kolizji. Pogryzł poszkodowanego na A4
 - [https://wydarzenia.interia.pl/opolskie/news-doprowadzil-do-kolizji-pogryzl-poszkodowanego-na-a4,nId,6976510](https://wydarzenia.interia.pl/opolskie/news-doprowadzil-do-kolizji-pogryzl-poszkodowanego-na-a4,nId,6976510)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T12:59:00+00:00

<p><a href="https://wydarzenia.interia.pl/opolskie/news-doprowadzil-do-kolizji-pogryzl-poszkodowanego-na-a4,nId,6976510"><img align="left" alt="Doprowadził do kolizji. Pogryzł poszkodowanego na A4" src="https://i.iplsc.com/doprowadzil-do-kolizji-pogryzl-poszkodowanego-na-a4/000HK983RGXD26NU-C321.jpg" /></a>Niebezpieczne zdarzenia na autostradzie A4 na wysokości Krapkowic. Jak informują lokalne służby, obywatel Rumunii doprowadził tam do kolizji, po czym próbował zbiec z miejsca zdarzenia. Co więcej, powstrzymywany przed ucieczką zrobił się agresywny i... pogryzł poszkodowanego w kolizji kierowcę kii. Sprawą zajmuje się policja.</p><br clear="all" />

## "Proszę, zostańcie w domach": Hilary dotarła do Los Angeles
 - [https://wydarzenia.interia.pl/zagranica/news-prosze-zostancie-w-domach-hilary-dotarla-do-los-angeles,nId,6976535](https://wydarzenia.interia.pl/zagranica/news-prosze-zostancie-w-domach-hilary-dotarla-do-los-angeles,nId,6976535)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T12:55:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prosze-zostancie-w-domach-hilary-dotarla-do-los-angeles,nId,6976535"><img align="left" alt="&quot;Proszę, zostańcie w domach&quot;: Hilary dotarła do Los Angeles" src="https://i.iplsc.com/prosze-zostancie-w-domach-hilary-dotarla-do-los-angeles/000HK9D7GRJFI9QX-C321.jpg" /></a>Tropikalna burza Hilary spowodowała liczne powodzie i podtopienia na zachodnim wybrzeżu USA. W mediach społecznościowych pojawiło się wiele nagrań pokazujących siłę zjawiska, które uderzyło w Kalifornię. Wydano ostrzeżenia dla terenów zamieszkałych przez dziesiątki milionów osób. To najsilniejszy żywioł, który dotarł w ten rejon USA od 26 lat. Sprawdź, jaka obecnie sytuacja panuje na zachodzie Stanów Zjednoczonych.</p><br clear="all" />

## Została zastrzelona z powodu flagi. Była matką dziewięciorga dzieci
 - [https://wydarzenia.interia.pl/zagranica/news-zostala-zastrzelona-z-powodu-flagi-byla-matka-dziewieciorga-,nId,6976516](https://wydarzenia.interia.pl/zagranica/news-zostala-zastrzelona-z-powodu-flagi-byla-matka-dziewieciorga-,nId,6976516)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T12:39:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zostala-zastrzelona-z-powodu-flagi-byla-matka-dziewieciorga-,nId,6976516"><img align="left" alt="Została zastrzelona z powodu flagi. Była matką dziewięciorga dzieci" src="https://i.iplsc.com/zostala-zastrzelona-z-powodu-flagi-byla-matka-dziewieciorga/000HK99DVQ6J8K8C-C321.jpg" /></a>Dramatyczne sceny w Cedar Glen w Kalifornii. Laura Ann Carleton, 66-letnia właścicielka sklepu odzieżowego, została zastrzelona z powodu wywieszonej przed jej butikiem tęczowej flagi. Kobieta osierociła dziewięcioro dzieci.</p><br clear="all" />

## Donald Tusk odpowiada Jarosławowi Kaczyńskiemu. "Nie ma się co bać"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-odpowiada-jaroslawowi-kaczynskiemu-nie-ma-sie-co,nId,6976469](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-odpowiada-jaroslawowi-kaczynskiemu-nie-ma-sie-co,nId,6976469)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T12:33:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-odpowiada-jaroslawowi-kaczynskiemu-nie-ma-sie-co,nId,6976469"><img align="left" alt="Donald Tusk odpowiada Jarosławowi Kaczyńskiemu. &quot;Nie ma się co bać&quot;" src="https://i.iplsc.com/donald-tusk-odpowiada-jaroslawowi-kaczynskiemu-nie-ma-sie-co/000HK92PK52U42VB-C321.jpg" /></a>Donald Tusk zareagował na słowa Jarosława Kaczyńskiego, który, dopytywany o ewentualną debatę z liderem Koalicji Obywatelskiej, odparł, że &quot;z Weberem chętnie&quot;. - Drogi Jarosławie, nie ma się co bać, nie ma się co wstydzić - mówi w nagraniu były premier i szef Platformy Obywatelskiej.</p><br clear="all" />

## Dzieci same w rozgrzanym aucie w Płocku. Matka wyszła do solarium
 - [https://wydarzenia.interia.pl/mazowieckie/news-dzieci-same-w-rozgrzanym-aucie-w-plocku-matka-wyszla-do-sola,nId,6976422](https://wydarzenia.interia.pl/mazowieckie/news-dzieci-same-w-rozgrzanym-aucie-w-plocku-matka-wyszla-do-sola,nId,6976422)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T12:18:00+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-dzieci-same-w-rozgrzanym-aucie-w-plocku-matka-wyszla-do-sola,nId,6976422"><img align="left" alt="Dzieci same w rozgrzanym aucie w Płocku. Matka wyszła do solarium" src="https://i.iplsc.com/dzieci-same-w-rozgrzanym-aucie-w-plocku-matka-wyszla-do-sola/000HK94XBQQH7MIN-C321.jpg" /></a>Skrajnie nieodpowiedzialną postawą wykazała się 36-letnia mieszkanka Płocka. Kobieta zostawiła dwoje małych dzieci w rozgrzanym samochodzie, a sama w tym czasie udała się do solarium. Zaparkowane na zakazie auto z pozostawionymi w środku nie tylko dziećmi, ale i kluczykami, przyciągnęło uwagę strażniczek miejskich. Teraz 36-latka odpowie za swoje zachowanie przed sądem.</p><br clear="all" />

## Tragiczna śmierć 10-latka. Policja przesłuchuje świadków
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczna-smierc-10-latka-policja-przesluchuje-swiadkow,nId,6976418](https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczna-smierc-10-latka-policja-przesluchuje-swiadkow,nId,6976418)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T11:57:15+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczna-smierc-10-latka-policja-przesluchuje-swiadkow,nId,6976418"><img align="left" alt="Tragiczna śmierć 10-latka. Policja przesłuchuje świadków" src="https://i.iplsc.com/tragiczna-smierc-10-latka-policja-przesluchuje-swiadkow/000HK8ZV90BIPYRX-C321.jpg" /></a>Policja przesłuchuje świadków po tragicznej śmierci 10-latka na plaży strzeżonej jeziora Sajmino - przekazał prokurator rejonowy w Ostródzie Rafał Koziński. Śledczy nie wszczęli formalnego dochodzenia, ale kluczowe będą zeznania ratowników, którzy pełnili wówczas służbę. Na wtorek zaplanowano sekcję zwłok chłopca.</p><br clear="all" />

## Marek Szaruga nie żyje. Burmistrz Kcyni miał 59 lat
 - [https://wydarzenia.interia.pl/kujawsko-pomorskie/news-marek-szaruga-nie-zyje-burmistrz-kcyni-mial-59-lat,nId,6976438](https://wydarzenia.interia.pl/kujawsko-pomorskie/news-marek-szaruga-nie-zyje-burmistrz-kcyni-mial-59-lat,nId,6976438)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T11:43:04+00:00

<p><a href="https://wydarzenia.interia.pl/kujawsko-pomorskie/news-marek-szaruga-nie-zyje-burmistrz-kcyni-mial-59-lat,nId,6976438"><img align="left" alt="Marek Szaruga nie żyje. Burmistrz Kcyni miał 59 lat" src="https://i.iplsc.com/marek-szaruga-nie-zyje-burmistrz-kcyni-mial-59-lat/000HK8YFMTDADXPQ-C321.jpg" /></a>Smutna wiadomość z Kcyni (woj. kujawsko-pomorskie). Jak informują lokalne media, w wieku 59 lat zmarł burmistrz tej miejscowości - Marek Szaruga. &quot;To bardzo smutna wiadomość, w którą jest nam nadal bardzo ciężko i trudno uwierzyć&quot; - czytamy w oficjalnym komunikacie.</p><br clear="all" />

## Chcą nowego porządku świata. Coraz więcej państw na liście
 - [https://wydarzenia.interia.pl/zagranica/news-chca-nowego-porzadku-swiata-coraz-wiecej-panstw-na-liscie,nId,6976417](https://wydarzenia.interia.pl/zagranica/news-chca-nowego-porzadku-swiata-coraz-wiecej-panstw-na-liscie,nId,6976417)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T11:08:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chca-nowego-porzadku-swiata-coraz-wiecej-panstw-na-liscie,nId,6976417"><img align="left" alt="Chcą nowego porządku świata. Coraz więcej państw na liście" src="https://i.iplsc.com/chca-nowego-porzadku-swiata-coraz-wiecej-panstw-na-liscie/000HK8TV8K9L8BVI-C321.jpg" /></a>Stanowią blisko jednej czwartej światowej gospodarki, blisko ze sobą współpracują, są zawiedzeni Zachodem i nie potępiają Rosji za inwazję na Ukrainę. Mowa o grupie państw BRICS. Chiny naciskają na rozszerzenie bloku o kolejne państwa, tak aby stał się on pełnowymiarowym rywalem dla G7. Chętnych nie brakuje - zainteresowanie przyłączeniem się do sojuszu wyraziło w tym roku ponad 40 kolejnych stolic. Celem BRICS jest zbudowanie nowego porządku świata i całkowite zreformowanie ONZ.</p><br clear="all" />

## Incydent z policyjnym śmigłowcem. Prokuratura wszczyna śledztwo
 - [https://wydarzenia.interia.pl/mazowieckie/news-incydent-z-policyjnym-smiglowcem-prokuratura-wszczyna-sledzt,nId,6976421](https://wydarzenia.interia.pl/mazowieckie/news-incydent-z-policyjnym-smiglowcem-prokuratura-wszczyna-sledzt,nId,6976421)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T11:06:07+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-incydent-z-policyjnym-smiglowcem-prokuratura-wszczyna-sledzt,nId,6976421"><img align="left" alt="Incydent z policyjnym śmigłowcem. Prokuratura wszczyna śledztwo" src="https://i.iplsc.com/incydent-z-policyjnym-smiglowcem-prokuratura-wszczyna-sledzt/000G87D762U532YS-C321.jpg" /></a>Prokuratura wszczyna śledztwo w sprawie incydentu lotniczego z udziałem policyjnego Black Hawka w Sarnowej Górze - wynika z ustaleń &quot;Wydarzeń&quot; Polsatu.</p><br clear="all" />

## Zapłakane dziecko w rozgrzanym aucie. Policja zatrzymała ojca
 - [https://wydarzenia.interia.pl/mazowieckie/news-zaplakane-dziecko-w-rozgrzanym-aucie-policja-zatrzymala-ojca,nId,6976368](https://wydarzenia.interia.pl/mazowieckie/news-zaplakane-dziecko-w-rozgrzanym-aucie-policja-zatrzymala-ojca,nId,6976368)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T10:52:14+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-zaplakane-dziecko-w-rozgrzanym-aucie-policja-zatrzymala-ojca,nId,6976368"><img align="left" alt="Zapłakane dziecko w rozgrzanym aucie. Policja zatrzymała ojca " src="https://i.iplsc.com/zaplakane-dziecko-w-rozgrzanym-aucie-policja-zatrzymala-ojca/00061XUSEG0NDVC0-C321.jpg" /></a>Zapłakane dziecko zostało znalezione w rozgrzanym samochodzie na warszawskiej Białołęce. Na zewnątrz było parno i duszno, a temperatura sięgała 35 stopni. Na szczęście wszystko dostrzegli przechodnie, którzy pomogli uratować dziecko i zadzwonili po służby. Za lekkomyślne zachowanie ojcu dziecka grozi teraz nawet do pięciu lat więzienia. </p><br clear="all" />

## Kolejne obszary wokół Bachmutu dla Ukrainy. "Wróg jest tam w pułapce"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kolejne-obszary-wokol-bachmutu-dla-ukrainy-wrog-jest-tam-w-p,nId,6976319](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kolejne-obszary-wokol-bachmutu-dla-ukrainy-wrog-jest-tam-w-p,nId,6976319)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T10:46:13+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kolejne-obszary-wokol-bachmutu-dla-ukrainy-wrog-jest-tam-w-p,nId,6976319"><img align="left" alt="Kolejne obszary wokół Bachmutu dla Ukrainy. &quot;Wróg jest tam w pułapce&quot;" src="https://i.iplsc.com/kolejne-obszary-wokol-bachmutu-dla-ukrainy-wrog-jest-tam-w-p/000HK8RDYQRMS7K9-C321.jpg" /></a>Ukraińskie wojsko stopniowo odzyskuje obszary wokół okupowanego przez Rosjan Bachmutu na wschodzie Ukrainy. Jak poinformowała ukraińska wiceminister obrony Hanna Malar,w zeszłym tygodniu jej rodacy wyzwolili kolejne trzy kilometry kwadratowe wokół miasta. W sumie od początku kontofensywy Ukraińcom udało się przejąć 43 kilometry kwadratowe w pobliżu Bachmutu. Malar mówiła też o sytuacji na południu kraju. </p><br clear="all" />

## Policyjny Black Hawk zerwał linię energetyczną. "Minister nie reagował"
 - [https://wydarzenia.interia.pl/mazowieckie/news-policyjny-black-hawk-zerwal-linie-energetyczna-minister-nie-,nId,6976326](https://wydarzenia.interia.pl/mazowieckie/news-policyjny-black-hawk-zerwal-linie-energetyczna-minister-nie-,nId,6976326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T10:13:19+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-policyjny-black-hawk-zerwal-linie-energetyczna-minister-nie-,nId,6976326"><img align="left" alt="Policyjny Black Hawk zerwał linię energetyczną. &quot;Minister nie reagował&quot; " src="https://i.iplsc.com/policyjny-black-hawk-zerwal-linie-energetyczna-minister-nie/000HK8JZ4DHDCL1D-C321.jpg" /></a>- Śmigłowce, samoloty nie mogą przelatywać podczas pokazów niżej niż 150 metrów nad terenem lub 300 metrów nad zgromadzeniem ludzi - przekazał na konferencji prasowej Maciej Lasek z Platformy Obywatelskiej, odnosząc się do niedzielnego incydentu z udziałem policyjnego śmigłowca Black Hawk. Wtórował mu Marcin Kierwiński z KO, który zaznaczył, że na wydarzeniu obecny był minister spraw wewnętrznych Maciej Wąsik, który &quot;nie zareagował&quot;. Z kolei senator Krzysztof Brejza opublikował w sieci treść pisma do premiera, w którym domaga się odpowiedzi...</p><br clear="all" />

## Polak poszukiwany listem gończym. Wpadł przez szokujące sceny na dworcu w Niemczech
 - [https://wydarzenia.interia.pl/zagranica/news-polak-poszukiwany-listem-gonczym-wpadl-przez-szokujace-sceny,nId,6976317](https://wydarzenia.interia.pl/zagranica/news-polak-poszukiwany-listem-gonczym-wpadl-przez-szokujace-sceny,nId,6976317)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:45:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-polak-poszukiwany-listem-gonczym-wpadl-przez-szokujace-sceny,nId,6976317"><img align="left" alt="Polak poszukiwany listem gończym. Wpadł przez szokujące sceny na dworcu w Niemczech" src="https://i.iplsc.com/polak-poszukiwany-listem-gonczym-wpadl-przez-szokujace-sceny/000HK8E4C4LON88H-C321.jpg" /></a>Poszukiwany listem gończym Polak został znaleziony przez policję na dworcu w Hamburgu. Stróżów prawa wezwano w związku z nieobyczajnych zachowaniem mężczyzny. 61-latek był poszukiwany za nieopłacenie grzywny w wysokości 366 euro, która została na niego nałożona po napadach z użyciem broni. Mężczyzna nie miał przy sobie tylu środków, więc trafił do aresztu.</p><br clear="all" />

## Inwazja nietoperzy. Setki latających ssaków w szpitalu
 - [https://wydarzenia.interia.pl/zagranica/news-inwazja-nietoperzy-setki-latajacych-ssakow-w-szpitalu,nId,6976355](https://wydarzenia.interia.pl/zagranica/news-inwazja-nietoperzy-setki-latajacych-ssakow-w-szpitalu,nId,6976355)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:39:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-inwazja-nietoperzy-setki-latajacych-ssakow-w-szpitalu,nId,6976355"><img align="left" alt="Inwazja nietoperzy. Setki latających ssaków w szpitalu" src="https://i.iplsc.com/inwazja-nietoperzy-setki-latajacych-ssakow-w-szpitalu/000HK8JT8LCYVFIC-C321.jpg" /></a>Ratownicy ze stacji Archa złapali w sumie ponad 400 nietoperzy w jednym z korytarzy szpitala w Libercu. Nie wiedzieli jednak, że to dopiero początek. Już następnego dnia w opuszczonym mieszkaniu w Jabloncu nad Nysą złapali kolejnych 600 latających ssaków. W Czechach coraz częściej odnotowywane są przypadki wtargnięć nietoperzy do domów. Ekspert radzi, jak zachować się w takich sytuacjach.</p><br clear="all" />

## Michał Kołodziejczak starł się z Oskarem Szafarowiczem. "Zostanie pan pozwany"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-michal-kolodziejczak-starl-sie-z-oskarem-szafarowiczem-zosta,nId,6976343](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-michal-kolodziejczak-starl-sie-z-oskarem-szafarowiczem-zosta,nId,6976343)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:29:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-michal-kolodziejczak-starl-sie-z-oskarem-szafarowiczem-zosta,nId,6976343"><img align="left" alt="Michał Kołodziejczak starł się z Oskarem Szafarowiczem. &quot;Zostanie pan pozwany&quot;" src="https://i.iplsc.com/michal-kolodziejczak-starl-sie-z-oskarem-szafarowiczem-zosta/000HK8EJ41SXBPQI-C321.jpg" /></a>- Pan manipuluje i zostanie pan pozwany w trybie wyborczym. Zmanipulował pan wypowiedź i takich wypowiedzi będziemy unikać  - zapowiedział Michał Kołodziejczak. Lider AgroUnii zareagował tak na słowa Oskara Szafarowicza, który pojawił się na konferencji polityka. Członek Forum Młodych PiS zarzucił Kołodziejczakowi, że w 2018 roku AgroUnia miała &quot;wytarzać w kapuście&quot; flagę Unii Europejskiej. Zdaniem Szafarowicza na tym samym wydarzeniu, 9 maja 2018 roku, miały też paść słowa o tym, że &quot;Unia zdradziła rolników i należy rozważyć, czy z tej...</p><br clear="all" />

## Tragiczny wypadek pod Mrągowem. Z auta niewiele zostało
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczny-wypadek-pod-mragowem-z-auta-niewiele-zostalo,nId,6976330](https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczny-wypadek-pod-mragowem-z-auta-niewiele-zostalo,nId,6976330)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:28:38+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-tragiczny-wypadek-pod-mragowem-z-auta-niewiele-zostalo,nId,6976330"><img align="left" alt="Tragiczny wypadek pod Mrągowem. Z auta niewiele zostało" src="https://i.iplsc.com/tragiczny-wypadek-pod-mragowem-z-auta-niewiele-zostalo/000HK8CAEMWPT1OA-C321.jpg" /></a>Dramatyczny wypadek pod Mrągowem. Na drodze wojewódzkiej numer 600 samochód osobowy uderzył w drzewo. W wyniku zdarzenia zginęło dwóch młodych mężczyzn. Policja bada okoliczności feralnego zdarzenia.</p><br clear="all" />

## Chcieli napić się czegoś słodkiego, nie żyją. Tragedia w USA
 - [https://wydarzenia.interia.pl/zagranica/news-chcieli-napic-sie-czegos-slodkiego-nie-zyja-tragedia-w-usa,nId,6976255](https://wydarzenia.interia.pl/zagranica/news-chcieli-napic-sie-czegos-slodkiego-nie-zyja-tragedia-w-usa,nId,6976255)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:19:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chcieli-napic-sie-czegos-slodkiego-nie-zyja-tragedia-w-usa,nId,6976255"><img align="left" alt="Chcieli napić się czegoś słodkiego, nie żyją. Tragedia w USA" src="https://i.iplsc.com/chcieli-napic-sie-czegos-slodkiego-nie-zyja-tragedia-w-usa/000HK7YQJEFV530Q-C321.jpg" /></a>Do tragicznego w skutkach zaniedbania doszło w miejscowości Tacoma w USA. Pracownicy lokalu z burgerami niedokładnie wyczyścili maszynę do produkcji koktajlów mlecznych. W efekcie wytworzyła się tam niezwykle groźna bakteria Listeria, odpowiadająca za Listeriozę. Z powodu zatrucia zmarły trzy osoby, a kolejne trzy trafiły do szpitala.</p><br clear="all" />

## Zełenski ostrzega: Wszyscy sąsiedzi Rosji mogą stać się jej celem
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-ostrzega-wszyscy-sasiedzi-rosji-moga-stac-sie-jej-c,nId,6976282](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-ostrzega-wszyscy-sasiedzi-rosji-moga-stac-sie-jej-c,nId,6976282)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T09:03:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-ostrzega-wszyscy-sasiedzi-rosji-moga-stac-sie-jej-c,nId,6976282"><img align="left" alt="Zełenski ostrzega: Wszyscy sąsiedzi Rosji mogą stać się jej celem " src="https://i.iplsc.com/zelenski-ostrzega-wszyscy-sasiedzi-rosji-moga-stac-sie-jej-c/000HK83UXUHW3N2C-C321.jpg" /></a>- Wszyscy sąsiedzi Rosji są zagrożeni, jeśli Ukraina nie wygra wojny. Ale Ukraina wygra wojnę - oświadczył prezydent Ukrainy Wołodymyr Zełenski podczas drugiego dnia wizyty w Danii. Przemawiając w tamtejszym parlamencie zaznaczył, że kiedy Władimir Putin rozpoczynał inwazję na Ukrainę wierzył, że &quot;zło może zmienić historię&quot;. - Wierzył tylko we władzę, bez człowieka. Wierzył w przemoc i dlatego jest słaby - zaznaczył. </p><br clear="all" />

## Łotwa ostrzega ws. granicy z Białorusią. "Coraz bardziej agresywni"
 - [https://wydarzenia.interia.pl/zagranica/news-lotwa-ostrzega-ws-granicy-z-bialorusia-coraz-bardziej-agresy,nId,6976232](https://wydarzenia.interia.pl/zagranica/news-lotwa-ostrzega-ws-granicy-z-bialorusia-coraz-bardziej-agresy,nId,6976232)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T08:55:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lotwa-ostrzega-ws-granicy-z-bialorusia-coraz-bardziej-agresy,nId,6976232"><img align="left" alt="Łotwa ostrzega ws. granicy z Białorusią. &quot;Coraz bardziej agresywni&quot;" src="https://i.iplsc.com/lotwa-ostrzega-ws-granicy-z-bialorusia-coraz-bardziej-agresy/000HK827P13DMYYX-C321.jpg" /></a>Łotewska straż graniczna mówi o nasilonych próbach nielegalnego przekraczania granic Łotwy z terytorium Białorusi. Według pograniczników białoruskie władze mogą dążyć do prowokacji. Imigranci zgromadzeni przy łotewskiej granicy są coraz bardziej agresywni, a według szefa straży granicznej funkcjonariusze mogą być zmuszeni do użycia broni. </p><br clear="all" />

## Dron spadł tuż obok domu ulubienicy Putina. Simonian pokazała zdjęcie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-spadl-tuz-obok-domu-ulubienicy-putina-simonian-pokazala,nId,6976248](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-spadl-tuz-obok-domu-ulubienicy-putina-simonian-pokazala,nId,6976248)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T08:43:02+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-spadl-tuz-obok-domu-ulubienicy-putina-simonian-pokazala,nId,6976248"><img align="left" alt="Dron spadł tuż obok domu ulubienicy Putina. Simonian pokazała zdjęcie" src="https://i.iplsc.com/dron-spadl-tuz-obok-domu-ulubienicy-putina-simonian-pokazala/000HK84027WX1967-C321.jpg" /></a>Wrak drona spadł na ulicę tuż obok moskiewskiego domu ulubienicy Władimira Putina i carycy rosyjskiej propagandy Margarity Simonian. W zdarzeniu ranne zostały dwie osoby, ponieważ po rozbiciu się maszyny odrzut był na tyle silny, że wybił wszystkie okna w ich domu. Do sprawy odniósł się również doradca ukraińskiego ministra, który stwierdził, że wojna &quot;zbliża się do Simonian coraz bardziej&quot;.</p><br clear="all" />

## Wielka parada w Kijowie. Zaprezentują rosyjski sprzęt
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielka-parada-w-kijowie-zaprezentuja-rosyjski-sprzet,nId,6976294](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielka-parada-w-kijowie-zaprezentuja-rosyjski-sprzet,nId,6976294)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T08:41:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wielka-parada-w-kijowie-zaprezentuja-rosyjski-sprzet,nId,6976294"><img align="left" alt="Wielka parada w Kijowie. Zaprezentują rosyjski sprzęt" src="https://i.iplsc.com/wielka-parada-w-kijowie-zaprezentuja-rosyjski-sprzet/000HK86VUMJX0850-C321.jpg" /></a>Władze w Kijowie po raz kolejny z okazji Dnia Niepodległości Ukrainy zaprezentują zniszczony rosyjski sprzęt. Ukraińskie święto przypada na 24 sierpnia. Na czas parady zablokowana zostanie m.in. główna arteria miasta - Chreszczatyk. Wystawa będzie dostępna do zwiedzania do 28 sierpnia.</p><br clear="all" />

## "Fake godny Oscara". Rosjanie mówią o Polakach
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-fake-godny-oscara-rosjanie-mowia-o-polakach,nId,6976292](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-fake-godny-oscara-rosjanie-mowia-o-polakach,nId,6976292)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T08:39:33+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-fake-godny-oscara-rosjanie-mowia-o-polakach,nId,6976292"><img align="left" alt="&quot;Fake godny Oscara&quot;. Rosjanie mówią o Polakach" src="https://i.iplsc.com/fake-godny-oscara-rosjanie-mowia-o-polakach/000HK89QQU4YKY6Y-C321.jpg" /></a>Rosyjska propaganda nie ustaje w publikowaniu kłamstw na temat sytuacji w Ukrainie. Przedstawiciele władz i kolaboranci zaczęli pisać o kolejnych &quot;zbrodniach polskich najemników&quot;. Jako dowód opublikowano nagranie z żołnierzami mówiącymi w trudnym do zrozumienia języku. Zdaniem propagandystów, byli to Polacy.</p><br clear="all" />

## "Jastrzębie" Putina chcą zmian na Kremlu. Mają jasny komunikat
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-jastrzebie-putina-chca-zmian-na-kremlu-maja-jasny-komunikat,nId,6976194](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-jastrzebie-putina-chca-zmian-na-kremlu-maja-jasny-komunikat,nId,6976194)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T08:15:30+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-jastrzebie-putina-chca-zmian-na-kremlu-maja-jasny-komunikat,nId,6976194"><img align="left" alt="&quot;Jastrzębie&quot; Putina chcą zmian na Kremlu. Mają jasny komunikat " src="https://i.iplsc.com/jastrzebie-putina-chca-zmian-na-kremlu-maja-jasny-komunikat/0007RZNHHGSMQTYC-C321.jpg" /></a>Na Kremlu pojawiają się głosy, które świadczą o tym, że nie wszyscy z kręgu Władimira Putina bezwzględnie popierają jego decyzje. Elity domagają się kilku kluczowych rzeczy. Jak donosi Bloomberg, powołując się na źródła zaznajomione z zakulisową sytuacją, urzędnicy chcą, aby minister obrony Siergiej Szojgu i szef Sztabu Generalnego Sił Zbrojnych Federacji Rosyjskiej Walerij Gierasimow utracili swoje stanowiska. Co więcej, podają czego jeszcze oczekują od rosyjskiego dyktatora. </p><br clear="all" />

## Striptizerki okradały klientów. Kluczowa rola "centrum monitoringu"
 - [https://wydarzenia.interia.pl/kraj/news-striptizerki-okradaly-klientow-kluczowa-rola-centrum-monitor,nId,6976176](https://wydarzenia.interia.pl/kraj/news-striptizerki-okradaly-klientow-kluczowa-rola-centrum-monitor,nId,6976176)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T07:44:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-striptizerki-okradaly-klientow-kluczowa-rola-centrum-monitor,nId,6976176"><img align="left" alt="Striptizerki okradały klientów. Kluczowa rola &quot;centrum monitoringu&quot;" src="https://i.iplsc.com/striptizerki-okradaly-klientow-kluczowa-rola-centrum-monitor/000HK7JKLWSB3KMD-C321.jpg" /></a>Funkcjonariusz Centralnego Biura Śledczego Policji (CBŚP) prowadzą śledztwo w sprawie serii wyłudzeń w klubach go-go w największych polskich miastach. Teraz zatrzymali kolejnych 20 osób - chodzi o kelnerki, tancerki, ale i kierownictwo lokalów, w których nieświadomi niebezpieczeństwa klienci tracili w jedną noc nawet 190 tysięcy złotych. Na razie śledczy mówią o 129 podejrzanych, ale liczba ta może jeszcze wzrosnąć. </p><br clear="all" />

## F-16 dla Ukrainy to nie tylko kwestia wojskowa. Ameryka chce pokazać coś więcej
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-f-16-dla-ukrainy-to-nie-tylko-kwestia-wojskowa-ameryka-chce-,nId,6976206](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-f-16-dla-ukrainy-to-nie-tylko-kwestia-wojskowa-ameryka-chce-,nId,6976206)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T07:36:43+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-f-16-dla-ukrainy-to-nie-tylko-kwestia-wojskowa-ameryka-chce-,nId,6976206"><img align="left" alt="F-16 dla Ukrainy to nie tylko kwestia wojskowa. Ameryka chce pokazać coś więcej" src="https://i.iplsc.com/f-16-dla-ukrainy-to-nie-tylko-kwestia-wojskowa-ameryka-chce/000HK7O2UB3EU3TW-C321.jpg" /></a>Po wielu miesiącach próśb i negocjacji, Ukraina dopięła swego. Stany Zjednoczone wyraziły zgodę na przekazanie Kijowowi przez Danię i Holandię myśliwców F-16. Dla Ukrainy to niezwykle doniosły moment - zarówno militarnie, jak i symbolicznie. - To też jednak znak, że Amerykanie wierzą, że ta wojna jest do wygrania i świadectwo wiarygodności oraz kompetencji Ukrainy w ich dotychczasowym prowadzeniu działań zbrojnych na froncie - mówi w rozmowie z Interią dr Tomasz Pawłuszko z Instytutu Sobieskiego.</p><br clear="all" />

## Premier do Webera: Wystarczy, że przysłaliście nam Donalda Tuska
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-do-webera-wystarczy-ze-przyslaliscie-nam-donalda-tus,nId,6976231](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-do-webera-wystarczy-ze-przyslaliscie-nam-donalda-tus,nId,6976231)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T07:32:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-do-webera-wystarczy-ze-przyslaliscie-nam-donalda-tus,nId,6976231"><img align="left" alt="Premier do Webera: Wystarczy, że przysłaliście nam Donalda Tuska" src="https://i.iplsc.com/premier-do-webera-wystarczy-ze-przyslaliscie-nam-donalda-tus/000HBU9PA03H6EG6-C321.jpg" /></a>- Był bliskim współpracownikiem Angeli Merkel i przez lata pomagał jej popełniać kolejne polityczne błędy, takie jak zbliżenie się z Rosją Putina. Widzimy teraz, jak fatalne skutki przyniosło to dla całej Europy - mówił o Manfredzie Weberze premier Mateusz Morawiecki. Na nagraniu zamieszczonym w sieci stwierdził także, że niemiecki polityk jest postacią kontrowersyjną i &quot;chce uczyć Polaków demokracji. - Nie chcemy tego w Polsce panie Weber. Wystarczy, że przysłaliście nam tutaj Donalda Tuska - dodał szef polskiego rządu.</p><br clear="all" />

## Randki online mogą powodować frustrację. "Efekt przeciążenia"
 - [https://wydarzenia.interia.pl/zagranica/news-randki-online-moga-powodowac-frustracje-efekt-przeciazenia,nId,6976183](https://wydarzenia.interia.pl/zagranica/news-randki-online-moga-powodowac-frustracje-efekt-przeciazenia,nId,6976183)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T07:11:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-randki-online-moga-powodowac-frustracje-efekt-przeciazenia,nId,6976183"><img align="left" alt="Randki online mogą powodować frustrację. &quot;Efekt przeciążenia&quot;" src="https://i.iplsc.com/randki-online-moga-powodowac-frustracje-efekt-przeciazenia/000HK7HNEDLY1ACW-C321.jpg" /></a>Randkowanie online jest dziś jednym z najbardziej powszechnych sposobów na poznawanie par w najmłodszym pokoleniu. Aplikacje oferują wiele możliwości, dla niektórych są one wręcz nieskończone. Fakt ten jednak powoduje &quot;efekt przeciążenia&quot;, co rodzi w nas frustrację i rozgoryczenie. Naukowcy radzą, co zrobić, by uniknąć powierzchowności i mechaniczności w poznawaniu ludzi przez internet</p><br clear="all" />

## Nagłe ruchy na moskiewskich lotniskach. Zawieszono loty
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nagle-ruchy-na-moskiewskich-lotniskach-zawieszono-loty,nId,6976201](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nagle-ruchy-na-moskiewskich-lotniskach-zawieszono-loty,nId,6976201)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T06:56:01+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nagle-ruchy-na-moskiewskich-lotniskach-zawieszono-loty,nId,6976201"><img align="left" alt="Nagłe ruchy na moskiewskich lotniskach. Zawieszono loty" src="https://i.iplsc.com/nagle-ruchy-na-moskiewskich-lotniskach-zawieszono-loty/000HK7GPB2DM1BIL-C321.jpg" /></a>Jak informują media, w poniedziałek władze moskiewskich portów lotniczych Wnukowo oraz Domodiedowo zawiesiły operacje ze względu na &quot;zapewnienie dodatkowych środków bezpieczeństwa&quot;. Ostatecznie rejsy zostały wznowione. Wcześniej jednak pojawiła się informacja o ukraińskim dronie zauważonym nad Moskwą.</p><br clear="all" />

## Potężny pożar rosyjskiego samolotu. Opublikowano zdjęcia
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-pozar-rosyjskiego-samolotu-opublikowano-zdjecia,nId,6976161](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-pozar-rosyjskiego-samolotu-opublikowano-zdjecia,nId,6976161)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T06:42:58+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-pozar-rosyjskiego-samolotu-opublikowano-zdjecia,nId,6976161"><img align="left" alt="Potężny pożar rosyjskiego samolotu. Opublikowano zdjęcia " src="https://i.iplsc.com/potezny-pozar-rosyjskiego-samolotu-opublikowano-zdjecia/000HK73EQSTO25LJ-C321.jpg" /></a>W mediach społecznościowych pojawiło się zdjęcie płonącej maszyny, która zdaniem autorów ujęcia ma być rosyjskim samolotem naddźwiękowym Tu-22M3. Według oświadczeń Kremla odrzutowiec został zaledwie uszkodzony podczas ataku drona w sobotnim nalocie w obwodzie nowogrodzkim. Ukraiński urzędnik - powołując się na rosyjskie kanały - poddaje jednak tę tezę pod wątpliwość, co mają sugerować również nowe zdjęcia.</p><br clear="all" />

## Antoni Macierewicz o listach KO. Mówi o "rosyjskiej agenturze"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-antoni-macierewicz-o-listach-ko-mowi-o-rosyjskiej-agenturze,nId,6976173](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-antoni-macierewicz-o-listach-ko-mowi-o-rosyjskiej-agenturze,nId,6976173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T06:06:48+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-antoni-macierewicz-o-listach-ko-mowi-o-rosyjskiej-agenturze,nId,6976173"><img align="left" alt="Antoni Macierewicz o listach KO. Mówi o &quot;rosyjskiej agenturze&quot;" src="https://i.iplsc.com/antoni-macierewicz-o-listach-ko-mowi-o-rosyjskiej-agenturze/000HK7400E0T7GO3-C321.jpg" /></a>- Donald Tusk jasno mówi Putinowi: &quot;Chcę wprowadzić do Sejmu ludzi, których będziesz kontrolował&quot; - uważa Antoni Macierewicz. Polityk Prawa i Sprawiedliwości skomentował w ten sposób listę kandydatów Koalicji Obywatelskiej w nadchodzących wyborach parlamentarnych. Skrytykował m.in. Bogusława Wołoszańskiego i Michała Kołodziejczaka.</p><br clear="all" />

## Analitycy: Rosyjscy żołnierze wściekli na dowódców
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-analitycy-rosyjscy-zolnierze-wsciekli-na-dowodcow,nId,6976160](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-analitycy-rosyjscy-zolnierze-wsciekli-na-dowodcow,nId,6976160)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T05:58:18+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-analitycy-rosyjscy-zolnierze-wsciekli-na-dowodcow,nId,6976160"><img align="left" alt="Analitycy: Rosyjscy żołnierze wściekli na dowódców" src="https://i.iplsc.com/analitycy-rosyjscy-zolnierze-wsciekli-na-dowodcow/000HK739G1SXAK3R-C321.jpg" /></a>Jak wynika z najnowszych analiz Instytutu Studiów na Wojną (ISW) Rosjanie obawiają się o bezpieczeństwo swojego kraju. Ostatnie ukraińskie ataki na terytorium Rosji wywołały złość żołnierzy, którzy skarżą się na działania swoich dowódców. To prawdopodobnie część ukraińskiej taktyki. </p><br clear="all" />

## Dieta matki wpływa nawet na wnuki. Naukowcy wskazują na popularny owoc
 - [https://wydarzenia.interia.pl/ciekawostki/news-dieta-matki-wplywa-nawet-na-wnuki-naukowcy-wskazuja-na-popul,nId,6976158](https://wydarzenia.interia.pl/ciekawostki/news-dieta-matki-wplywa-nawet-na-wnuki-naukowcy-wskazuja-na-popul,nId,6976158)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T05:34:53+00:00

<p><a href="https://wydarzenia.interia.pl/ciekawostki/news-dieta-matki-wplywa-nawet-na-wnuki-naukowcy-wskazuja-na-popul,nId,6976158"><img align="left" alt="Dieta matki wpływa nawet na wnuki. Naukowcy wskazują na popularny owoc" src="https://i.iplsc.com/dieta-matki-wplywa-nawet-na-wnuki-naukowcy-wskazuja-na-popul/000HK70QVVULIP3B-C321.jpg" /></a>Najnowsze badanie naukowców wykazało, że zdrowa dieta matki podczas ciąży może chronić mózgi nie tylko dzieci, ale i wnuków. Badacze wskazują, że odpowiedzialne za to są odpowiednie produkty, jak np. jabłka i zioła. Wykryta w nich cząsteczka ma pomagać w zmniejszeniu uszkodzeń aksonów, które są niezbędne do tego, aby mózg prawidłowo funkcjonował. </p><br clear="all" />

## Skończył właśnie 111 lat. Zdradził sekret długowieczności
 - [https://wydarzenia.interia.pl/zagranica/news-skonczyl-wlasnie-111-lat-zdradzil-sekret-dlugowiecznosci,nId,6974816](https://wydarzenia.interia.pl/zagranica/news-skonczyl-wlasnie-111-lat-zdradzil-sekret-dlugowiecznosci,nId,6974816)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T05:19:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-skonczyl-wlasnie-111-lat-zdradzil-sekret-dlugowiecznosci,nId,6974816"><img align="left" alt="Skończył właśnie 111 lat. Zdradził sekret długowieczności" src="https://i.iplsc.com/skonczyl-wlasnie-111-lat-zdradzil-sekret-dlugowiecznosci/000HK5LGXXYYXR5D-C321.jpg" /></a>Tripolino Giannini, najdłużej żyjący mężczyzna we Włoszech, skończył w niedzielę 111 lat - podały władze miejscowości Cecina, niedaleko Livorno gdzie mieszka jubilat. W dniu urodzin odwiedzili go bliscy znajomi, ale i władze miasta. Padło pytanie o sekret długowieczności.</p><br clear="all" />

## Niepokojące warunki w oceanach. Naukowcy ostrzegają przed katastrofą
 - [https://wydarzenia.interia.pl/zagranica/news-niepokojace-warunki-w-oceanach-naukowcy-ostrzegaja-przed-kat,nId,6974811](https://wydarzenia.interia.pl/zagranica/news-niepokojace-warunki-w-oceanach-naukowcy-ostrzegaja-przed-kat,nId,6974811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T05:13:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niepokojace-warunki-w-oceanach-naukowcy-ostrzegaja-przed-kat,nId,6974811"><img align="left" alt="Niepokojące warunki w oceanach. Naukowcy ostrzegają przed katastrofą" src="https://i.iplsc.com/niepokojace-warunki-w-oceanach-naukowcy-ostrzegaja-przed-kat/000HK5JQ9R37OU7I-C321.jpg" /></a>Naukowcy alarmują, że w wodach u wybrzeży Anglii i Irlandii może dojść do masowego pomoru zwierząt i wymierania wielu gatunków roślin. Wszystko z uwagi na &quot;przegrzewanie się&quot; mórz i oceanów, które ma związek z globalnym ociepleniem. Jeśli proces nie zostanie zahamowany, będziemy mieli do czynienia z katastrofą ekologiczną, ale i poważnymi problemami natury gospodarczej. - Człowiek &quot;przeciąża system&quot; - przyznają eksperci.</p><br clear="all" />

## Pocisk Pjongjangu "nie popełnił najmniejszego błędu". Tuż obok ćwiczenia USA
 - [https://wydarzenia.interia.pl/zagranica/news-pocisk-pjongjangu-nie-popelnil-najmniejszego-bledu-tuz-obok-,nId,6976150](https://wydarzenia.interia.pl/zagranica/news-pocisk-pjongjangu-nie-popelnil-najmniejszego-bledu-tuz-obok-,nId,6976150)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T04:56:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pocisk-pjongjangu-nie-popelnil-najmniejszego-bledu-tuz-obok-,nId,6976150"><img align="left" alt="Pocisk Pjongjangu &quot;nie popełnił najmniejszego błędu&quot;. Tuż obok ćwiczenia USA" src="https://i.iplsc.com/pocisk-pjongjangu-nie-popelnil-najmniejszego-bledu-tuz-obok/000HK6ZU0WHSH433-C321.jpg" /></a>Korea Północna przeprowadziła test strategicznych pocisków manewrujących, co osobiście nadzorował przywódca państwa Kim Dzong Un - przekazała rządowa agencja KCNA. Dyktator nie szczędził pochwał pod adresem swojej armii, która zdecydowała się na przeprowadzenie próby podczas rozpoczynających się ćwiczeń Korei Południowej ze Stanami Zjednoczonymi.</p><br clear="all" />

## Pożar w firmie oponiarskiej w Dębicy. W akcji 140 strażaków
 - [https://wydarzenia.interia.pl/podkarpackie/news-pozar-w-firmie-oponiarskiej-w-debicy-w-akcji-140-strazakow,nId,6976153](https://wydarzenia.interia.pl/podkarpackie/news-pozar-w-firmie-oponiarskiej-w-debicy-w-akcji-140-strazakow,nId,6976153)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T04:40:33+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-pozar-w-firmie-oponiarskiej-w-debicy-w-akcji-140-strazakow,nId,6976153"><img align="left" alt="Pożar w firmie oponiarskiej w Dębicy. W akcji 140 strażaków" src="https://i.iplsc.com/pozar-w-firmie-oponiarskiej-w-debicy-w-akcji-140-strazakow/000HK6YSFN3EQKNI-C321.jpg" /></a>W hali produkcyjnej firmy oponiarskiej w Dębicy na Podkarpaciu doszło do pożaru. Jak przekazał bryg. Marcin Betleja, rzecznik prasowy Podkarpackiego Komendanta Wojewódzkiego PSP, ogień został opanowany. Na miejscu pracowało blisko 140 strażaków z kilku powiatów. </p><br clear="all" />

## Burza tropikalna oraz trzęsienie ziemi w Kalifornii. "Ludzie krzyczeli"
 - [https://wydarzenia.interia.pl/zagranica/news-burza-tropikalna-oraz-trzesienie-ziemi-w-kalifornii-ludzie-k,nId,6976148](https://wydarzenia.interia.pl/zagranica/news-burza-tropikalna-oraz-trzesienie-ziemi-w-kalifornii-ludzie-k,nId,6976148)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-08-21T04:18:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-burza-tropikalna-oraz-trzesienie-ziemi-w-kalifornii-ludzie-k,nId,6976148"><img align="left" alt="Burza tropikalna oraz trzęsienie ziemi w Kalifornii. &quot;Ludzie krzyczeli&quot;" src="https://i.iplsc.com/burza-tropikalna-oraz-trzesienie-ziemi-w-kalifornii-ludzie-k/000HK6YR7C5P4I8L-C321.jpg" /></a>Po raz pierwszy od 84 lat Kalifornię nawiedziła burza tropikalna. Innym żywiołem, z którym w południowej części musiał zmagać się stan było trzęsienie ziemi. Najmocniej dało się je odczuć w pobliżu miasta Ojai, w hrabstwie Ventura. Sejsmolog ostrzega, że w najbliższych dniach mogą wystąpić wstrząsy wtórne.</p><br clear="all" />

