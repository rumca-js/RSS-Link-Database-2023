# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Polskie mięso będzie podbijać rynek w Azji. Jest decyzja
 - [https://www.money.pl/gospodarka/polskie-mieso-bedzie-podbijac-rynek-w-azji-jest-decyzja-6933083614604192a.html](https://www.money.pl/gospodarka/polskie-mieso-bedzie-podbijac-rynek-w-azji-jest-decyzja-6933083614604192a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T19:49:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7d35927d-bfa8-44ea-a16d-3fc4b40bb136" width="308" /> Polskie mięso wołowe już wkrótce trafi na rynek Tajlandii. 11 polskich zakładów produkujących wołowinę uzyskało uprawnienia do eksportu – poinformowało Ministerstwo Rolnictwa i Rozwoju Wsi. Pozwolenie będzie obowiązywać przez kilka lat.

## Przy kasach w Biedronkach pojawiły się tajemnicze komunikaty. Oto powód
 - [https://www.money.pl/gospodarka/przy-kasach-w-biedronkach-pojawily-sie-tajemnicze-komunikaty-oto-powod-6933067115944896a.html](https://www.money.pl/gospodarka/przy-kasach-w-biedronkach-pojawily-sie-tajemnicze-komunikaty-oto-powod-6933067115944896a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T18:42:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fab81808-08f6-471f-af88-35557b4862d2" width="308" /> Przy kasach w Biedronce pojawiły się komunikaty informujące, że "w przypadku rozbieżności lub wątpliwości" co do ceny, klient "ma prawo do żądania sprzedaży towaru po cenie dla niego najkorzystniejszej". Komunikat ten pozostanie na wiele miesięcy. Oto powód tego kroku.

## Miliony kary dla giganta coraz bliżej. Sąd podtrzymał decyzję urzędu
 - [https://www.money.pl/gospodarka/miliony-kary-dla-giganta-coraz-blizej-sad-podtrzymal-decyzje-urzedu-6933054909967264a.html](https://www.money.pl/gospodarka/miliony-kary-dla-giganta-coraz-blizej-sad-podtrzymal-decyzje-urzedu-6933054909967264a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T17:52:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bb0b7686-6048-4439-b19a-dfba355be7e3" width="308" /> Prawie 27 mln zł kary ma zapłacić Benefit Systems. Sąd Ochrony Konkurencji i Konsumentów oddalił odwołanie od decyzji o karze wydanej przez prezesa UOKiK. Wyrok nie jest prawomocny, a spółka zapowiada, że złoży odwołanie.

## "Karygodny" aspekt 14. emerytury. "Kto rządzącym zabroni takiego ruchu?" [OPINIA]
 - [https://www.money.pl/emerytury/karygodny-aspekt-14-emerytury-kto-rzadzacym-zabroni-takiego-ruchu-opinia-6932998514400192a.html](https://www.money.pl/emerytury/karygodny-aspekt-14-emerytury-kto-rzadzacym-zabroni-takiego-ruchu-opinia-6932998514400192a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T17:20:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cfd4786c-ae6f-4d25-98f8-38e0d87a7e2b" width="308" /> To, co dzieje się w związku ze świadczeniem nazywanym "14. emerytura", to już nawet nie jest żart. To, według mnie, ordynarna kiełbasa wyborcza. A do wyborów jeszcze 55 dni… Wiele się jeszcze może wydarzyć i wiele naszych pieniędzy pójdzie zapewne do najbardziej "obiecujących" grup wyborców.

## Węgry znalazły już pierwszego sojusznika. Zabezpieczają dostawy gazu z Rosji
 - [https://www.money.pl/gospodarka/wegry-znalazly-juz-pierwszego-sojusznika-zabezpieczaja-dostawy-gazu-z-rosji-6933039676504992a.html](https://www.money.pl/gospodarka/wegry-znalazly-juz-pierwszego-sojusznika-zabezpieczaja-dostawy-gazu-z-rosji-6933039676504992a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T16:50:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5871ba87-8c87-490c-a742-a965e86495f4" width="308" /> BOTAS, turecki koncern energetyczny, porozumiał się ze swoim węgierskim odpowiednikiem MVM. Owocem obustronnej umowy będą dostawy gazu ziemnego z Turcji do Węgier. Budapeszt znalazł się w trudnej sytuacji po decyzji Ukrainy o niepodejmowaniu negocjacji nowej umowy z Rosją dotyczącej przesłyłu surowca.

## "Tanie wypełniacze" i wysoka cena. Byli pracownicy McDonald’s ujawniają prawdę o nuggetsach
 - [https://www.money.pl/gospodarka/tanie-wypelniacze-i-wysoka-cena-byli-pracownicy-mcdonalds-ujawniaja-prawde-o-nuggetsach-6933001220656064a.html](https://www.money.pl/gospodarka/tanie-wypelniacze-i-wysoka-cena-byli-pracownicy-mcdonalds-ujawniaja-prawde-o-nuggetsach-6933001220656064a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T16:32:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8be27667-db75-4465-a831-bad976ad14cb" width="308" /> Byli pracownicy McDonald's postanowili opowiedzieć o tajemnicach i sztuczkach, których używa sieć. Pod lupę wzięli popularną pozycję z restauracyjnego menu, czyli kurczaki McNuggets - podaje portal tz.de.

## Zawodzimy w segregacji śmieci. Nie działają ani edukacja, ani groźby
 - [https://www.money.pl/gospodarka/zawodzimy-w-segregacji-smieci-nie-dzialaja-ani-edukacja-ani-grozby-6933015143152576a.html](https://www.money.pl/gospodarka/zawodzimy-w-segregacji-smieci-nie-dzialaja-ani-edukacja-ani-grozby-6933015143152576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T15:10:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a8602e9a-6b8c-42ec-b9b8-362c784316f1" width="308" /> Już za kilka lat większość odpadów będzie musiała być posegregowana. Tymczasem dziś największym problemem jest skłonienie Polaków do segregacji. Nie pomagają ani edukacja, ani prośby, ani groźby. Samorządy, aby spełnić coraz surowsze regulacje prawne, będą musiały uciekać się do kar.

## Rząd się przeliczył. "Czternastki" droższe o 9 mld zł
 - [https://www.money.pl/emerytury/rzad-sie-przeliczyl-czternastki-drozsze-o-9-mld-zl-6933015085534112a.html](https://www.money.pl/emerytury/rzad-sie-przeliczyl-czternastki-drozsze-o-9-mld-zl-6933015085534112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T15:10:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/37182d9d-7c01-4f3f-a077-2330f2525dcc" width="308" /> Koszt wypłaty tzw. czternastej emerytury dla budżetu państwa w 2023 roku, przy świadczeniu w wysokości 2200 zł netto, będzie wyższy o 9 mld zł od planu - przekazała na antenie Radia Maryja minister rodziny i polityki społecznej.

## Dorabiający muszą się mieć na baczności. Decyzja ZUS-u może im odebrać emeryturę
 - [https://www.money.pl/emerytury/dorabiajacy-musza-sie-miec-na-bacznosci-decyzja-zus-u-moze-im-odebrac-emeryture-6932998113692576a.html](https://www.money.pl/emerytury/dorabiajacy-musza-sie-miec-na-bacznosci-decyzja-zus-u-moze-im-odebrac-emeryture-6932998113692576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T14:15:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/db9aeec4-fab9-490b-bd8b-452abfd6a5d3" width="308" /> Osoby dorabiające do wcześniejszej emerytury lub renty muszą uważać. Wkrótce wejdzie w życie decyzja ZUS-u zmniejszająca limit maksymalnej kwoty, która nie powoduje utraty prawa do świadczenia.

## Metaverse Marka Zuckerberga generuje ogromne straty. W 21,5 mld dol. w 1,5 roku
 - [https://www.money.pl/gielda/metawersum-juz-generuje-ogromne-straty-jednak-mark-zuckerberg-wciaz-wierzy-w-projekt-6932988138630080a.html](https://www.money.pl/gielda/metawersum-juz-generuje-ogromne-straty-jednak-mark-zuckerberg-wciaz-wierzy-w-projekt-6932988138630080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T13:20:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2880bed5-749b-4ef1-a0e1-262f2a5a50d4" width="308" /> Metaverse to miał być przełom, który przeniesie ludzkość do kolejnej epoki w rozwoju jej cywilizacji. Na razie jednak przynosi ogromne straty. Meta przedstawiła wyniki finansowe laboratorium odpowiadającego za cyfrowe uniwersum. Mark Zuckerberg pozostaje mimo to "w pełni zaangażowany" w projekt.

## Jest oferta za Bogdankę. Akcję spółki wystrzeliły
 - [https://www.money.pl/gielda/jest-oferta-za-bogdanke-akcje-spolki-wystrzelily-6932986599214016a.html](https://www.money.pl/gielda/jest-oferta-za-bogdanke-akcje-spolki-wystrzelily-6932986599214016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T13:14:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d66534aa-7a76-4ae7-bb64-699772ad2256" width="308" /> Po ujawnieniu oficjalnej rządowej oferty dotyczącej nabycia akcji LW Bogdanka, akcje spółki na Giełdzie Papierów Wartościowych momentalnie poszybowały. W pewnym momencie kurs wyniósł ponad 40 zł za akcję.

## Mapa polskich milionerów. Oto nowy ranking miast, w których jest ich najwięcej
 - [https://www.money.pl/gospodarka/mapa-polskich-milionerow-w-tych-miastach-jest-ich-najwiecej-6932945899010976a.html](https://www.money.pl/gospodarka/mapa-polskich-milionerow-w-tych-miastach-jest-ich-najwiecej-6932945899010976a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T11:27:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf1c5650-0faa-48c6-b92e-063c0abdd9eb" width="308" /> W ciągu ostatnich dziesięciu lat obserwujemy znaczący wzrost liczby Polaków, którzy zarabiają co najmniej milion złotych rocznie. Ta liczba wzrosła aż czterokrotnie. Obecnie w naszym kraju żyje ponad 43 tysiące osób, które można zaliczyć do grona milionerów - informuje "Wprost", który sprawdził, w jakich miastach jest ich najwięcej.

## Mobilizacja w Chinach. Stworzą rywala dla "wielkiej siódemki"?
 - [https://www.money.pl/gospodarka/konkurent-dla-g7-chiny-chca-rozszerzenia-bloku-brics-6932955795426240a.html](https://www.money.pl/gospodarka/konkurent-dla-g7-chiny-chca-rozszerzenia-bloku-brics-6932955795426240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T11:09:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/29e2f3b4-6d21-4c69-87d1-c9410b892a8f" width="308" /> Chiny chcą, aby rozszerzono blok BRICS (zrzeszający Brazylię, Rosję, Indie, Chiny i RPA) o kolejne państwa. Takie działania miałyby sprawić, że grupa stałaby się rywalem dla G7 - podaje "Financial Times".

## Deflacja w Niemczech. Najnowsze dane nie pozostawiają złudzeń
 - [https://www.money.pl/gospodarka/deflacja-w-niemczech-najnowsze-dane-nie-pozostawiaja-zludzen-6932927121513376a.html](https://www.money.pl/gospodarka/deflacja-w-niemczech-najnowsze-dane-nie-pozostawiaja-zludzen-6932927121513376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T09:12:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0eaa2329-329e-43af-a074-9387a9c08485" width="308" /> Ceny produkcji sprzedanej przemysłu w Niemczech w lipcu 2023 roku były niższe o 6 procent w porównaniu do lipca 2022 roku - wynika z najnowszych danych tamtejszego urzędu statystycznego Destatis, które cytuje portal TVN 24.

## Najpopularniejsze mity o kredytach – jak to wygląda naprawdę?
 - [https://www.money.pl/banki/najpopularniejsze-mity-o-kredytach-jak-to-wyglada-naprawde-6931840871164832a.html](https://www.money.pl/banki/najpopularniejsze-mity-o-kredytach-jak-to-wyglada-naprawde-6931840871164832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T08:26:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/684de999-e9a3-448e-bc25-c78e8c830bc1" width="308" /> W 2023 roku nastąpiło duże ożywienie na rynku kredytowym w Polsce. Raport AMRON-SARFiN pokazał, że w I kw. 2023 roku liczba nowo udzielonych zobowiązań mieszkaniowych wyniosła niemal 13 tys., czyli odnotowano wzrost o ponad 16 proc. w porównaniu do IV kw. 2022 roku. O 21,14 proc. wzrosła wartość tych kredytów i wyniosła 7,47 mld zł.&nbsp;BIK z kolei w cyklicznym raporcie podał, że w marcu 2023 roku banki i SKOK-i przyznały w Polsce o 55,8 proc. więcej kredytów ratalnych, o 53,4 proc. więcej kart kredytowych i o 8 proc. więcej kredytów gotówkowych niż rok wcześniej. Czy jednak wiemy wszystko o kredytach? Sprawdź 10 popularnych mitów na ich temat.

## Wysokość 14. emerytury. Kaczyński się pomylił? Jest odpowiedź resortu
 - [https://www.money.pl/emerytury/zamieszanie-z-wysokoscia-14-emerytury-mamy-stanowisko-ministerstwa-6932913132043200a.html](https://www.money.pl/emerytury/zamieszanie-z-wysokoscia-14-emerytury-mamy-stanowisko-ministerstwa-6932913132043200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T08:15:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8eb64133-84ea-44d4-a95d-e19317725b11" width="308" /> Wysokość "czternastki" w 2023 roku ogłosił w niedzielę Jarosław Kaczyński. – Będzie wynosiła 2200 tys. zł netto – stwierdził. Po tych słowach pojawiły się wątpliwości. – Pomylił sobie brutto z netto. Powiedział "netto", a ponieważ oni są przerażeni i się go boją, już tak musi być – komentowała posłanka Izabela Leszczyna w TVN24.

## Tyle wynosi średnia emerytura pomostowa. Wiceminister podał liczbę
 - [https://www.money.pl/emerytury/tyle-wynosi-srednia-emerytura-pomostowa-wiceminister-podal-liczbe-6932881455274944a.html](https://www.money.pl/emerytury/tyle-wynosi-srednia-emerytura-pomostowa-wiceminister-podal-liczbe-6932881455274944a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T06:06:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c6bce7bf-d0cf-4f30-bfdb-57e48434c5e1" width="308" /> Emerytura pomostowa wynosi 100 proc. potencjalnej emerytury obliczonej dla osoby w wieku 60 lat. Jak przekazał wiceminister rodziny i polityki społecznej Stanisław Szwed, wynosi ona około 3200 zł.

## Polski gigant z problemami. Marże Dino w dół
 - [https://www.money.pl/gielda/marze-dino-sie-kurcza-konkurencja-dociska-siec-handlowa-6932876259810208a.html](https://www.money.pl/gielda/marze-dino-sie-kurcza-konkurencja-dociska-siec-handlowa-6932876259810208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:45:39+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e90d9ac3-29ad-4483-b9ab-f3f8c892d1a3" width="308" /> Akcje Dino Polska w piątek od rana traciły. Jak podaje "Rzeczpospolita", presja innych sieci handlowych jest tak duża, że marże spółki się kurczą. Dodatkowo w kolejnych miesiącach zmaleje dynamika sprzedaży Dino.

## Bezpłatne leki dla dzieci i seniorów tylko ze specjalnym kodem
 - [https://www.money.pl/gospodarka/bezplatne-leki-dla-dzieci-i-seniorow-tylko-ze-specjalnym-kodem-6932869742099360a.html](https://www.money.pl/gospodarka/bezplatne-leki-dla-dzieci-i-seniorow-tylko-ze-specjalnym-kodem-6932869742099360a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:19:08+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/31028932-7252-40ec-a906-9d77421474ac" width="308" /> Ustawa ws. bezpłatnych leków dla dzieci i młodzieży do 18. roku życia i osób, które mają co najmniej 65 lat, czeka na podpis prezydenta. Dziennik "Fakt" przypomina, że nowe przepisy mają wejść w życie od 1 września, ale nie oznacza to jednak, że seniorzy i rodziny w aptece już nic nie zapłacą za leki.

## Kursy walut 21.08.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-21-08-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6932869106187200a.html](https://www.money.pl/pieniadze/kursy-walut-21-08-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6932869106187200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:16:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 21.08.2023. W poniedziałek za jednego dolara (USD) zapłacimy 4.10 zł. Cena jednego funta szterlinga (GBP) to 5.22 zł, a franka szwajcarskiego (CHF) 4.64 zł. Z kolei euro (EUR) możemy zakupić za 4.46 zł.

## Influencer to podatnik jak każdy inny. Ważny wyrok sądu
 - [https://www.money.pl/podatki/influencer-to-podatnik-jak-kazdy-inny-wazny-wyrok-sadu-6932866514017184a.html](https://www.money.pl/podatki/influencer-to-podatnik-jak-kazdy-inny-wazny-wyrok-sadu-6932866514017184a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:06:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/be188391-50e9-428f-b2f8-0ef1b9fba419" width="308" /> Jak podaje "Rzeczpospolita", urzędy skarbowe starają się nakładać daniny na działalność reklamową w social mediach, choć ta "wciąż wymyka się schematom". Chodzi w szczególności o otrzymywanie prezentów od firm, a następnie reklamowanie ich na swoich stronach.

## Prezes PiS ogłosił: "czternastki" będą wyższe. Jest jeden haczyk
 - [https://www.money.pl/emerytury/kaczynski-czternastka-bedzie-wyzsza-prezes-pis-nie-powiedzial-wszystkiego-6932859325676480a.html](https://www.money.pl/emerytury/kaczynski-czternastka-bedzie-wyzsza-prezes-pis-nie-powiedzial-wszystkiego-6932859325676480a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:01:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/97221c6d-b62a-4e42-a3d0-115f7bc09f61" width="308" /> 14. emerytura, wypłacana w 2023 r., wyniesie 2,2 tys. zł netto - ogłosił w niedzielę podczas wojewódzkich dożynek w Paradyżu (Łódzkie) prezes PiS, wicepremier Jarosław Kaczyński, ale nie powiedział wszystkiego. Jest jeden haczyk.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 21.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-21-08-2023-6932865115446208a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-21-08-2023-6932865115446208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:00:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 21.08.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.6445 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 21.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-21-08-2023-6932865115438016a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-21-08-2023-6932865115438016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:00:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 21.08.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2185 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 21.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-21-08-2023-6932865097190304a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-21-08-2023-6932865097190304a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 21.08.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.4576 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 21.08.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-21-08-2023-6932865090993088a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-21-08-2023-6932865090993088a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-08-21T05:00:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 21.08.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.0965 zł.

