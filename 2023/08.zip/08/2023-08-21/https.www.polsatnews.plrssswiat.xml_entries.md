# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Nowoczesne myśliwce nie trafią na Ukrainę. Szwecja odmawia przekazania Gripenów
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/nowoczesne-mysliwce-nie-trafia-na-ukraine-szwecja-odmawia-przekazania-gripenow/](https://www.polsatnews.pl/wiadomosc/2023-08-21/nowoczesne-mysliwce-nie-trafia-na-ukraine-szwecja-odmawia-przekazania-gripenow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T19:53:00+00:00

- Musimy się bronić, a nie jesteśmy jeszcze członkami NATO. Dlatego nie możemy przekazać naszych myśliwców Gripen Ukrainie - stwierdził Ulf Kristersson. Szwedzki premier odniósł się medialnych doniesień dotyczących wsparcia Kijowa nowoczesnymi maszynami.

## Rosjanie zniszczyli XVI-wieczną twierdzę. Należała do polskich arystokratów
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/rosjanie-zniszczyli-xvi-wieczna-twierdze-nalezala-do-polskich-arystokratow/](https://www.polsatnews.pl/wiadomosc/2023-08-21/rosjanie-zniszczyli-xvi-wieczna-twierdze-nalezala-do-polskich-arystokratow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T19:39:00+00:00

W trakcie rosyjskiego ataku dronowego na obwód chmielnicki uszkodzony został Zamek Sieniawskich w Międzyborzu. Obiekt przez setki lat należał do polskich rodzin Sieniawskich i Czartoryskich.

## Korea Północna otwiera się na świat. Rosja na początek
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/korea-polnocna-otwiera-sie-na-swiat-rosja-na-poczatek/](https://www.polsatnews.pl/wiadomosc/2023-08-21/korea-polnocna-otwiera-sie-na-swiat-rosja-na-poczatek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T19:20:00+00:00

Air Koryo, północnokoreańska linia lotnicza, od końca sierpnia wznawia połączenia do Rosji. Połączenie z Pjongjangu do Władywostoku to pierwszy tak odważny krok reżimu Kim Dzong Una po ścisłym lockdownie.

## USA do swoich obywateli: Natychmiast opuścić Białoruś
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-do-swoich-obywateli-natychmiast-opuscic-bialorus/](https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-do-swoich-obywateli-natychmiast-opuscic-bialorus/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T18:30:00+00:00

Amerykańska ambasada w Mińsku wezwała swoich obywateli do natychmiastowego opuszczenia Białorusi. Placówka dyplomatyczna odradza także podróży do tego kraju ze względu na gromadzenie się rosyjskich sił zbrojnych, możliwość niepokojów społecznych oraz ryzyko zatrzymania.

## Chiny: Sklep tylko dla odważnych. Wejście wymaga umiejętności
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/chiny-sklep-tylko-dla-odwaznych-wejscie-do-srodka-wymaga-umiejetnosci/](https://www.polsatnews.pl/wiadomosc/2023-08-21/chiny-sklep-tylko-dla-odwaznych-wejscie-do-srodka-wymaga-umiejetnosci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T16:07:00+00:00

To najbardziej niewygodny sklep ogólnospożywczy na ziemi - piszą chińskie media. Żeby zrobić tam zakupy trzeba wspiąć się 120 metrów po wyjątkowo stromej skale.

## Kotka Kit Kat nową rekordzistką świata. Jej wyczyn zarejestrowano na filmie
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/kotka-kit-kat-nowa-rekordzistka-swiata-jej-wyczyn-zarejestrowano-na-filmie/](https://www.polsatnews.pl/wiadomosc/2023-08-21/kotka-kit-kat-nowa-rekordzistka-swiata-jej-wyczyn-zarejestrowano-na-filmie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T15:03:00+00:00

Gra w reklamach telewizyjnych, bierze udział w kampaniach w mediach społecznościowych, a teraz została wpisana do Księgi Rekordów Guinnessa. Mowa o 13-letniej kotce Kit Kat, która niedawno pobiła rekord skoków przez skakankę.

## Spotkanie Erdogana i Putina. Prezydent Turcji wskazał możliwy termin
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/spotkanie-erdogana-i-putina-prezydent-turcji-wskazuje-kiedy-moze-do-niego-dojsc/](https://www.polsatnews.pl/wiadomosc/2023-08-21/spotkanie-erdogana-i-putina-prezydent-turcji-wskazuje-kiedy-moze-do-niego-dojsc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T14:55:00+00:00

Prezydent Turcji Recep Tayyip Erdogan zdradził, kiedy najprawdopodobniej dojdzie do spotkania twarzą w twarz z Władimirem Putinem - podała w poniedziałek agencja Unian. Wcześniej służby prasowe Erdogana zapowiadały, że w trakcie rozmów między prezydentami ma zostać poruszony temat umowy zbożowej.

## Wielka Brytania: Dożywocie dla pielęgniarki. 33-latka mordowała noworodki
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/wielka-brytania-dozywocie-dla-pielegniarki-33-latka-mordowala-noworodki/](https://www.polsatnews.pl/wiadomosc/2023-08-21/wielka-brytania-dozywocie-dla-pielegniarki-33-latka-mordowala-noworodki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T13:56:00+00:00

Bezwzględne dożywocie, bez możliwości ubiegania się o przedterminowe zwolnienie - taki wyrok w poniedziałek usłyszała 33-letnia Lucy Letby. Kobieta była oskarżona o zamordowanie siedmiu noworodków i próbę zabicia kolejnych sześciu dzieci.

## Statek przyszłości wypłynął w swój pierwszy rejs. Odpowiedź na zmieniający się klimat
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/statek-przyszlosci-wyplynal-w-swoj-pierwszy-rejs-odpowiedz-na-zmieniajacy-sie-klimat/](https://www.polsatnews.pl/wiadomosc/2023-08-21/statek-przyszlosci-wyplynal-w-swoj-pierwszy-rejs-odpowiedz-na-zmieniajacy-sie-klimat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T11:54:00+00:00

Ekostatek wyruszył w swój pierwszy rejs. Towarowiec z wielkimi żaglami zasilanymi wiatrem ma być odpowiedzią na pogarszającą się sytuację na świecie związaną z dwutlenkiem węgla. Nowoczesne żagle mają zredukować jego emisję. Statek zakończy swój rejs po sześciu tygodniach.

## USA: Trzy osoby nie żyją po wypiciu mlecznego koktajlu. W maszynie do lodów wykryto bakterie
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-trzy-osoby-nie-zyja-po-wypiciu-mlecznego-koktajlu-w-maszynie-do-lodow-wykryto-bakterie/](https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-trzy-osoby-nie-zyja-po-wypiciu-mlecznego-koktajlu-w-maszynie-do-lodow-wykryto-bakterie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T09:06:00+00:00

Trzy osoby zmarły po wypiciu mlecznego koktajlu w restauracji z burgerami w Tacoma w stanie Waszyngton. Kolejni trzy klienci trafili do szpitala. Okazało się, że w maszynie do robienie lodów wykryto groźną bakterię.

## Ukraina: Rosyjski sprzęt na ulicach Kijowa. Szykują się na "defiladę"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/ukraina-rosyjski-sprzet-na-ulicach-kijowa-szykuja-sie-na-defilade/](https://www.polsatnews.pl/wiadomosc/2023-08-21/ukraina-rosyjski-sprzet-na-ulicach-kijowa-szykuja-sie-na-defilade/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T08:49:00+00:00

Na głównej ulicy Kijowa właśnie ustawiany jest rosyjski sprzęt wojskowy - to część przygotowań do Dnia Niepodległości Ukrainy 24 sierpnia. Podobnie jak rok wcześniej, w centrum ukraińskiej stolicy zorganizowana zostanie rosyjska defilada. Tyle tylko, że cały rosyjski sprzęt to wraki z linii frontu.

## "Polacy zabijają ukraińskich żołnierzy". Rosyjska propaganda w natarciu
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/polacy-zabijaja-ukrainskich-zolnierzy-rosyjska-propaganda-w-natarciu/](https://www.polsatnews.pl/wiadomosc/2023-08-21/polacy-zabijaja-ukrainskich-zolnierzy-rosyjska-propaganda-w-natarciu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T08:31:00+00:00

Rosyjskie władze rozsiewają fake newsy, tym razem o Polakach mordujących Ukraińców na froncie. Na poparcie swoich twierdzeń publikują wideo, na którym rzekomy Polak ma biec z karabinem za ukraińskim żołnierzem.

## Najstarszy Włoch skończył 111 lat. Zdradził sekret swojej długowieczności
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/najstarszy-wloch-skonczyl-111-lat-zdradzil-sekret-swojej-dlugowiecznosci/](https://www.polsatnews.pl/wiadomosc/2023-08-21/najstarszy-wloch-skonczyl-111-lat-zdradzil-sekret-swojej-dlugowiecznosci/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T08:06:00+00:00

Tripolino Giannini, najdłużej żyjący człowiek we Włoszech, 20 sierpnia skończył 111 lat. Podczas imprezy urodzinowej poproszono go, aby zdradził, jaki jest sekret tak długiego życia. Mężczyzna wskazał na trzy czynniki.

## Rosja: Ataki dronów w rejonie Moskwy. Zamknięto stołeczne lotniska
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/rosja-ataki-dronow-w-rejonie-moskwy-zamknieto-stoleczne-lotniska/](https://www.polsatnews.pl/wiadomosc/2023-08-21/rosja-ataki-dronow-w-rejonie-moskwy-zamknieto-stoleczne-lotniska/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T07:41:00+00:00

W poniedziałek rano doszło do dwóch prób ataku dronami na Moskwę. Według rosyjskiego MON odpowiedzialna jest za nie Ukraina. Drony zostały unieszkodliwione. Zanim jednak udało się je zniszczyć, Rosjanie musieli zawiesić pracę trzech stołecznych lotnisk.

## "Stop Putlerowi". Incydent podczas finału piłkarskich MŚ kobiet
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/stop-putinowi-incydent-podczas-finalu-mistrzostw-swiata-kobiet-rozpoczal-jednoosobowy-protest/](https://www.polsatnews.pl/wiadomosc/2023-08-21/stop-putinowi-incydent-podczas-finalu-mistrzostw-swiata-kobiet-rozpoczal-jednoosobowy-protest/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T06:10:00+00:00

Finałowy mecz mistrzostw świata kobiet w piłce nożnej został przerwany przez jednoosobowy protest. Mężczyzna, który wbiegł na boisko, miał na sobie koszulkę z napisem Stop Putlerowi. Jego akcja miała być apelem wobec działań wojennych Rosji.

## USA: Burza tropikalna i trzęsienie ziemi w Kalifornii. "Podwójny cios"
 - [https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-burza-tropikalna-i-trzesienie-ziemi-w-kalifornii-podwojny-cios/](https://www.polsatnews.pl/wiadomosc/2023-08-21/usa-burza-tropikalna-i-trzesienie-ziemi-w-kalifornii-podwojny-cios/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-08-21T05:20:00+00:00

Po raz pierwszy od lat Kalifornię nawiedziła burza tropikalna. Gwałtowny żywioł spowodował wielkie powodzie. W tym samym czasie w regionie doszło również do trzęsienia ziemi. Wstrząsy były najmocniej odczuwalne w pobliżu Ojai, w hrabstwie Ventura.

