# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Essential Back to School Gear Guide for Pop Culture Fans
 - [https://gizmodo.com/back-to-school-pop-culture-guide-boxlunch-disney-dc-1850754138](https://gizmodo.com/back-to-school-pop-culture-guide-boxlunch-disney-dc-1850754138)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T23:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--i3pXcv6n--/c_fit,fl_progressive,q_80,w_636/1b458acbf58910d5a191d82c7aeef451.jpg" /><p>School is back in session and if there’s still fandom gear to check off your shopping list, io9 has you covered.</p><p><a href="https://gizmodo.com/back-to-school-pop-culture-guide-boxlunch-disney-dc-1850754138">Read more...</a></p>

## Barbie's Breakout Hit Song Gets Hilarious Behind-the-Scenes Video
 - [https://gizmodo.com/barbie-movie-music-video-im-just-ken-ryan-gosling-sings-1850759883](https://gizmodo.com/barbie-movie-music-video-im-just-ken-ryan-gosling-sings-1850759883)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T22:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7fjH6o3Q--/c_fit,fl_progressive,q_80,w_636/c21544de9439dc911ed33cb9d907ff7e.jpg" /><p>The <a href="https://gizmodo.com/barbie-review-margot-robbie-greta-gerwig-ryan-gosling-1850660597">goofy, deadpan performances</a> of <em>Barbie</em> <a href="https://gizmodo.com/barbie-greta-gerwig-billion-dollar-box-office-mattel-1850707921">obviously work on screen</a>, but what were they like to film? Well, a new video has surfaced thanks to Atlantic Records answering that question and more. It’s a full music video for the <a href="https://gizmodo.com/barbie-audiences-pandemic-theaters-survey-1850731570">film’s standout</a> chart-topping bop “I’m Just Ken” by Ryan Gosling, but it’s filled with behind-…</p><p><a href="https://gizmodo.com/barbie-movie-music-video-im-just-ken-ryan-gosling-sings-1850759883">Read more...</a></p>

## Baldur's Gate 3 Characters Sheets for D&D Let You Put Your D&D in Your D&D While You D&D
 - [https://gizmodo.com/dungeons-and-dragons-baldurs-gate-3-character-sheets-1850759898](https://gizmodo.com/dungeons-and-dragons-baldurs-gate-3-character-sheets-1850759898)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T22:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QDzApV1p--/c_fit,fl_progressive,q_80,w_636/e3231ce2603f345661a059094fedc87f.png" /><p>Been playing a lot of <a href="https://gizmodo.com/baldurs-gate-3-beginner-guide-d-n-d-explained-1850740900"><em>Baldur’s Gate 3</em></a> and found yourself thinking “god, I love all of these <em>Dungeons &amp; Dragons</em> characters in this <em>Dungeons &amp; Dragons</em> video game. What if I <a href="https://gizmodo.com/show-us-your-baldurs-gate-3-characters-d-and-d-1850708781">simply played them</a> in <em>Dungeons &amp; Dragons</em>?” Well, the good news is that Wizards of the Coast and Larian have made that even more absurdly easy than…</p><p><a href="https://gizmodo.com/dungeons-and-dragons-baldurs-gate-3-character-sheets-1850759898">Read more...</a></p>

## The Feds Asked TikTok for Lots of Domestic Spying Features
 - [https://gizmodo.com/tiktok-cfius-draft-agreement-shows-spying-requests-1850759715](https://gizmodo.com/tiktok-cfius-draft-agreement-shows-spying-requests-1850759715)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T21:55:46+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0CUEItfi--/c_fit,fl_progressive,q_80,w_636/803aafeec1ac24a7dbe07df0a3e3ab37.jpg" /><p>US government regulators reportedly tried to come to an agreement with TikTok to prevent banning the app that would have granted the federal government vast powers over the app.  That’s according to a draft of a deal between TikTok and the Committee on Foreign Investment in the United States (CFIUS) <a href="https://www.forbes.com/sites/emilybaker-white/2023/08/21/draft-tiktok-cfius-agreement/?sh=1af8a03c112a" rel="noopener noreferrer" target="_blank">obtained by Forbes</a>…</p><p><a href="https://gizmodo.com/tiktok-cfius-draft-agreement-shows-spying-requests-1850759715">Read more...</a></p>

## Google’s Pixel 8 Could Eliminate the SIM Slot, Just Like the iPhone
 - [https://gizmodo.com/google-s-pixel-8-sim-slot-esim-only-iphone-1850759671](https://gizmodo.com/google-s-pixel-8-sim-slot-esim-only-iphone-1850759671)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T21:42:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--o6xnSMeH--/c_fit,fl_progressive,q_80,w_636/5d37ca3374ed369d5f9488297ea73a76.jpg" /><p>The <a href="https://gizmodo.com/samsung-galaxy-z-fold-5-review-1850744972?rev=1692285985867">summer of foldables</a> has started fizzling out, and now we’re moving on to the next batch of flagship phones. Google’s Pixel 8/8 Pro is expected to be the next major Android smartphone release this fall. And it might be Google’s first eSIM-only smartphone.  Apple went eSIM-only with the <a href="https://gizmodo.com/apple-iphone-14-google-pixel-7-camera-comparison-night-1849755086">iPhone 14</a> and <a href="https://gizmodo.com/apple-iphone-14-pro-review-max-google-android-pixel-13-1849532287">iPhone 14 Pro</a>…</p><p><a href="https://gizmodo.com/google-s-pixel-8-sim-slot-esim-only-iphone-1850759671">Read more...</a></p>

## Godfather NFTs Weren’t Enough to Prevent Recur From Sleeping With the Fishes
 - [https://gizmodo.com/recur-nft-platform-1850759400](https://gizmodo.com/recur-nft-platform-1850759400)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T21:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WLNniITH--/c_fit,fl_progressive,q_80,w_636/2a2e11283032bca171e7be302b21a581.jpg" /><p>Even with the inclusion of collectibles from the Nickelodeon, Paramount, and Hello Kitty back catalogs, the NFT platform Recur is calling it quits after several years of pumping the internet full of monetized images of <em>The Godfather’s </em>similarly ineffective Fredo. </p><p><a href="https://gizmodo.com/recur-nft-platform-1850759400">Read more...</a></p>

## How Many People Does It Take to Start a Colony on Mars?
 - [https://gizmodo.com/how-many-astronauts-to-start-mars-colony-study-1850758977](https://gizmodo.com/how-many-astronauts-to-start-mars-colony-study-1850758977)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T21:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lyrb0ypa--/c_fit,fl_progressive,q_80,w_636/271c56abecc547eea1b1a9e9786725ff.jpg" /><p>It might only take 22 people to establish a colony on Mars, though that small group of cosmic inhabitants should have agreeable personality types to survive on the Red Planet, according to new research. </p><p><a href="https://gizmodo.com/how-many-astronauts-to-start-mars-colony-study-1850758977">Read more...</a></p>

## This New Ahsoka Clip Finally Brings the Chopper Chaos
 - [https://gizmodo.com/ahsoka-clip-chopper-star-wars-rebels-disney-plus-1850759465](https://gizmodo.com/ahsoka-clip-chopper-star-wars-rebels-disney-plus-1850759465)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T21:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--GRNfQ7DR--/c_fit,fl_progressive,q_80,w_636/f4c379123afddc6116309f3ef750ca0f.png" /><p>What we’ve seen so far of <em>Ahsoka</em> <a href="https://gizmodo.com/ahsoka-reviews-star-wars-dave-filoni-rosario-dawson-1850748961">seems promising</a>, especially for fans of <em>Star Wars Rebels</em> waiting to see just what is up <a href="https://gizmodo.com/ahsoka-character-guide-hera-sabine-thrawn-ezra-star-war-1850744096">with those characters</a> after the events of the show. But something has been missing: a spark, an energy, a little frisson of silliness and personality. That something is Chopper, and, at long last, a…</p><p><a href="https://gizmodo.com/ahsoka-clip-chopper-star-wars-rebels-disney-plus-1850759465">Read more...</a></p>

## Here’s What the WGA Has to Say About the Big 3 Streaming Monopolies
 - [https://gizmodo.com/here-s-what-the-wga-has-to-say-about-the-big-3-streamin-1850758992](https://gizmodo.com/here-s-what-the-wga-has-to-say-about-the-big-3-streamin-1850758992)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T20:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X43K5Z0q--/c_fit,fl_progressive,q_80,w_636/307e36b588f498dc6540e2e43ee9351c.jpg" /><p>The <a href="https://gizmodo.com/wga-strike-update-hollywood-amptp-meeting-writers-union-1850741136">Writers’ Guild of America West</a> has released a <a href="https://www.wga.org/the-guild/advocacy/politics-public-policy-pac/the-new-gatekeepers-how-disney-amazon-and-netflix-will-take-over-media" rel="noopener noreferrer" target="_blank">15-page report</a> on the big three streaming services, outlining exactly how far each one has gone to preserve and maintain their monopoly in the space. The three companies at the heart of the report are <a href="https://gizmodo.com/disney-ceo-bob-iger-strikes-end-quickly-sag-aftra-1850723163">Disney</a>, Amazon, and <a href="https://gizmodo.com/writers-strike-update-wga-amptp-negotiating-continues-1850726070">Netflix</a>. All three of these streaming services…</p><p><a href="https://gizmodo.com/here-s-what-the-wga-has-to-say-about-the-big-3-streamin-1850758992">Read more...</a></p>

## 850 People Remain Missing in Maui After Devastating Wildfires
 - [https://gizmodo.com/850-people-remain-missing-in-maui-after-wildfires-1850759018](https://gizmodo.com/850-people-remain-missing-in-maui-after-wildfires-1850759018)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T20:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FR2m8yrF--/c_fit,fl_progressive,q_80,w_636/ac5cce5fde47f6009ef119bdd965391f.jpg" /><p>850 people are currently still missing in Maui, more than two weeks after the fires first sparked, <a href="https://www.staradvertiser.com/2023/08/21/breaking-news/search-and-relief-efforts-continue-as-maui-prepares-for-biden-visit/" rel="noopener noreferrer" target="_blank">Maui County’s Mayor</a><a href="https://www.staradvertiser.com/2023/08/21/breaking-news/search-and-relief-efforts-continue-as-maui-prepares-for-biden-visit/" rel="noopener noreferrer" target="_blank"> Richard Bissen said</a>.</p><p><a href="https://gizmodo.com/850-people-remain-missing-in-maui-after-wildfires-1850759018">Read more...</a></p>

## Montana Compares TikTok to 'Cancer-Causing Radio' in Defense of State's Ban
 - [https://gizmodo.com/montana-tiktok-ban-compare-cancer-causing-radio-1850758733](https://gizmodo.com/montana-tiktok-ban-compare-cancer-causing-radio-1850758733)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T19:47:28+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LJ1-uqgI--/c_fit,fl_progressive,q_80,w_636/d4d7f278812f62c06720ae3c41af7cbf.jpg" /><p>Montana’s <a href="https://montanafreepress.org/2022/09/29/by-the-numbers-knudsen-lawsuits-challenging-biden-administration/" rel="noopener noreferrer" target="_blank">lawsuit-hungry attorney general</a> Austin Knudsen wants US courts to think of TikTok less like a light-hearted home for viral trends and more akin to the harbinger of a life-threatening disease. In recent <a href="https://ecf.mtd.uscourts.gov/cgi-bin/show_temp.pl?file=2982611-0--79353.pdf&amp;type=application/pdf" rel="noopener noreferrer" target="_blank">court filings</a> defending his state’s <a href="https://gizmodo.com/tiktok-banned-in-montana-1850447913">unprecedented ban on the short-form video app</a>, Knudsen compared TikTok …</p><p><a href="https://gizmodo.com/montana-tiktok-ban-compare-cancer-causing-radio-1850758733">Read more...</a></p>

## Webb Space Telescope Drops Two Spellbinding Shots of the Ring Nebula
 - [https://gizmodo.com/webb-space-telescope-ring-nebula-two-new-images-1850758937](https://gizmodo.com/webb-space-telescope-ring-nebula-two-new-images-1850758937)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T19:18:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hZZjB_1S--/c_fit,fl_progressive,q_80,w_636/c88f81b9e83d317d081beb8232333f0d.jpg" /><p>The Webb Space Telescope recently imaged the Ring Nebula with its two primary imagers, revealing the gaseous formation in never-before-seen detail.</p><p><a href="https://gizmodo.com/webb-space-telescope-ring-nebula-two-new-images-1850758937">Read more...</a></p>

## 'Benefits of Slavery:' Google's AI Search Gives Ridiculous and Wrong Answers
 - [https://gizmodo.com/google-search-ai-answers-slavery-benefits-1850758631](https://gizmodo.com/google-search-ai-answers-slavery-benefits-1850758631)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T18:55:28+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qMd8kl36--/c_fit,fl_progressive,q_80,w_636/50319b20222698cb2729fec3eff832f7.jpg" /><p>Google’s experiments with AI-generated search results produce some troubling answers, Gizmodo has learned, including justifications for slavery and genocide and the positive effects of banning books. In one instance, Google gave cooking tips for Amanita ocreata, a poisonous mushroom known as the “angel of death.” The…</p><p><a href="https://gizmodo.com/google-search-ai-answers-slavery-benefits-1850758631">Read more...</a></p>

## Elon Musk Tests Verification With a Government ID and a Selfie
 - [https://gizmodo.com/twitter-x-verification-government-id-selfie-1850756394](https://gizmodo.com/twitter-x-verification-government-id-selfie-1850756394)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T18:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yI8mLfjJ--/c_fit,fl_progressive,q_80,w_636/c6cdd260447f16f151c05964b9e1aa1d.jpg" /><p>X (the social media site <a href="https://gizmodo.com/linda-yaccarino-twitter-elon-musk-justify-x-rebrand-1850726989">formerly known</a> as Twitter) is in the process of launching a new identity verification feature that could prove  controversial. The feature, which is currently only offered to/forced on premium <a href="https://gizmodo.com/twitter-x-gives-blue-users-option-to-hide-checkmark-1850699191">“Blue” subscribers</a>, asks users to fork over a selfie and a picture of a government issued ID to…</p><p><a href="https://gizmodo.com/twitter-x-verification-government-id-selfie-1850756394">Read more...</a></p>

## Movie Theaters Are Charging Only $4 Per Ticket This Sunday
 - [https://gizmodo.com/national-cinema-day-cheap-ticket-movie-theaters-barbie-1850757983](https://gizmodo.com/national-cinema-day-cheap-ticket-movie-theaters-barbie-1850757983)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T18:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--DlXnWBOU--/c_fit,fl_progressive,q_80,w_636/6e1c27d52c19054797e73310e37901c3.jpg" /><p>The <a href="https://gizmodo.com/movie-theaters-are-screwed-1843160685">biggest complaint</a> about <a href="https://gizmodo.com/if-you-take-out-your-phone-in-a-movie-theater-im-going-1836977301">seeing a movie in theaters</a> these days is that it’s too damned expensive. And for 364 days in a year, <a href="https://gizmodo.com/amc-movie-theater-new-movies-movie-pass-1850078315">that’s true</a>. But for one day, one magical day, movie costs come down so low, you’d think it you’d traveled back in time 50 years, and that day is coming soon.</p><p><a href="https://gizmodo.com/national-cinema-day-cheap-ticket-movie-theaters-barbie-1850757983">Read more...</a></p>

## Creepshow Season 4 Promises Generous Portions of Ghosts, Ghouls, and Gore
 - [https://gizmodo.com/creepshow-season-4-shudder-amc-trailer-horror-anthology-1850758422](https://gizmodo.com/creepshow-season-4-shudder-amc-trailer-horror-anthology-1850758422)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T17:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--zpQMkB4j--/c_fit,fl_progressive,q_80,w_636/ab53a1a77b24c047ac3c661207d765b6.jpg" /><p>It’s a scarily good time to be a fan of horror TV, with <a href="https://gizmodo.com/chucky-season-3-syfy-usa-network-peacock-universal-hhn-1850747869"><em>Chucky</em> recently revealing its season three premiere date</a>, and now <a href="https://gizmodo.com/shudders-creepshow-horror-anthology-series-is-off-to-a-1838082270">Shudder’s <em>Creepshow </em>anthology series</a> announcing its own return. Season four of <a href="https://gizmodo.com/creepshow-is-back-to-make-you-ewww-with-delight-1847696720">Greg Nicotero’s George A. Romero-inspired series</a> drops Friday, October 13 on Shudder and AMC+.</p><p><a href="https://gizmodo.com/creepshow-season-4-shudder-amc-trailer-horror-anthology-1850758422">Read more...</a></p>

## The Best Phones You Can Buy in 2023
 - [https://gizmodo.com/the-best-phones-you-can-buy-1830552418](https://gizmodo.com/the-best-phones-you-can-buy-1830552418)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T17:33:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--a0ZIy2gH--/c_fit,fl_progressive,q_80,w_636/f552ffc90241efc88baab0cfe330b89a.jpg" /><p><small>Some of our posts include links to retailers. If you buy something from clicking on one, G/O Media may earn a commission. Because editorial staff is independent of commerce, affiliate linking does not influence our editorial content.</small></p><p>The smartphone audience is so wide that it’s difficult to settle on just one best phone of 2023. Some of us want huge screens, fast processors, and tons of memory. Other people want the very best camera so they can share photos on social media. And then there are the folks who want the best budget phone and/or best…</p><p><a href="https://gizmodo.com/the-best-phones-you-can-buy-1830552418">Read more...</a></p>

## YouTube Says Its Music AI Incubator Will 'Protect' Artists
 - [https://gizmodo.com/youtube-launches-music-ai-incubator-with-universal-1850758218](https://gizmodo.com/youtube-launches-music-ai-incubator-with-universal-1850758218)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T17:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--JHKG3sxX--/c_fit,fl_progressive,q_80,w_636/e17c7717df13141047faa6453d086ee9.jpg" /><p>YouTube is embracing the future of artificial intelligence in the music industry by creating a YouTube Music AI Incubator to “protect” artists and their work, the company said in a <a href="https://blog.youtube/inside-youtube/partnering-with-the-music-industry-on-ai/" rel="noopener noreferrer" target="_blank">press release</a> on Monday. The streaming platform partnered with Universal Music Group (UMG) to <a href="https://gizmodo.com/google-universal-music-ai-to-replicate-artists-voices-1850722515">launch the Music AI Incubator</a>, working…</p><p><a href="https://gizmodo.com/youtube-launches-music-ai-incubator-with-universal-1850758218">Read more...</a></p>

## Samsung Tries to Entice iPhone Users With Fake Foldable Experience
 - [https://gizmodo.com/samsung-tries-to-entice-iphone-users-with-fake-foldable-1850758059](https://gizmodo.com/samsung-tries-to-entice-iphone-users-with-fake-foldable-1850758059)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T17:03:48+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--uk1YQw2v--/c_fit,fl_progressive,q_80,w_636/6243344fc6bd67cae182aa03c3a29c70.jpg" /><p>With Samsung pouring its marketing money into its latest foldable phones, the company is trying to snatch up potential iPhone 15 customers by showing them all the fun and weirdness of using two screens, so long as they have an additional iPhone on hand and they’re easily distracted by playing a dull game of air hockey.</p><p><a href="https://gizmodo.com/samsung-tries-to-entice-iphone-users-with-fake-foldable-1850758059">Read more...</a></p>

## BeReal Is Launching a New Feature That Ignores the App's Entire Purpose
 - [https://gizmodo.com/bereal-adds-friends-of-friends-tab-1850757592](https://gizmodo.com/bereal-adds-friends-of-friends-tab-1850757592)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T17:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Ir73HPsQ--/c_fit,fl_progressive,q_80,w_636/72053c5ce1407e2df3f6f95101efea0e.jpg" /><p>The point of BeReal is simple: Keep your circle tight. The app where most accounts are private and users can only post once a day is unveiling a new Friends of Friends feature that allows users to explore what people they kinda know are up to.</p><p><a href="https://gizmodo.com/bereal-adds-friends-of-friends-tab-1850757592">Read more...</a></p>

## See How Tropical Storm Hilary Flooded Southern California
 - [https://gizmodo.com/photos-tropical-storm-hilary-floods-southern-california-1850757351](https://gizmodo.com/photos-tropical-storm-hilary-floods-southern-california-1850757351)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T16:43:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KVMoAI02--/c_fit,fl_progressive,q_80,w_636/872dc691655c0c62b2833b5e3098e002.jpg" /><p>Tropical storm Hilary swept over Baja California and up into Southern California this weekend, flooding roads and felling trees. This is the first tropical storm to hit the state in over 80 years, the Associated Press <a href="https://apnews.com/article/hilary-tropical-storm-flooding-california-mexico-f89aeddeb62d55c935699ac81ca85f1d" rel="noopener noreferrer" target="_blank">reports</a>.</p><p><a href="https://gizmodo.com/photos-tropical-storm-hilary-floods-southern-california-1850757351">Read more...</a></p>

## Hubble Space Telescope Snaps Galaxy Cluster That Could Hold Secrets of Dark Matter
 - [https://gizmodo.com/hubble-telescope-images-abell-3322-dark-matter-1850757510](https://gizmodo.com/hubble-telescope-images-abell-3322-dark-matter-1850757510)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T16:32:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hUsaERat--/c_fit,fl_progressive,q_80,w_636/b3666c254c64255407c0c765e94a30ca.jpg" /><p>The Hubble Space Telescope is no spring chicken, having operated in space for over 30 years. But the veteran observatory soldiers on. It recently imaged a massive galaxy cluster that could hold secrets about both dark and ordinary matter.</p><p><a href="https://gizmodo.com/hubble-telescope-images-abell-3322-dark-matter-1850757510">Read more...</a></p>

## Easter Eggs in Blue Beetle | io9 Interview
 - [https://gizmodo.com/easter-eggs-in-blue-beetle-1850734464](https://gizmodo.com/easter-eggs-in-blue-beetle-1850734464)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R7i4oC1H--/c_fit,fl_progressive,q_80,w_636/5c766e41dea81547e4d19846c7bdf620.jpg" /><p><a href="https://gizmodo.com/easter-eggs-in-blue-beetle-1850734464">Read more...</a></p>

## Wandavision, Loki, and The Mandalorian Will All Get Physical Home Releases
 - [https://gizmodo.com/wandavision-loki-mandalorian-physical-release-disney-1850757575](https://gizmodo.com/wandavision-loki-mandalorian-physical-release-disney-1850757575)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T15:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---mBNmMNa--/c_fit,fl_progressive,q_80,w_636/38f51cc997c4c03d74e49dce4c2f2af2.png" /><p>As the streaming era devolves into a wave of cutbacks, consolidation, and the <a href="https://gizmodo.com/disney-plus-hulu-removals-full-list-1850482457">removing of original content</a> for the sake of tax breaks, it’s become more important than ever that physical releases of streaming original media offers a legal path to people still being able to actually access that content. Thankfully,…</p><p><a href="https://gizmodo.com/wandavision-loki-mandalorian-physical-release-disney-1850757575">Read more...</a></p>

## Russia's Long-Awaited Return to the Moon Crashes and Burns
 - [https://gizmodo.com/russias-luna-25-moon-mission-crashes-1850757300](https://gizmodo.com/russias-luna-25-moon-mission-crashes-1850757300)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T15:06:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3jT-ogow--/c_fit,fl_progressive,q_80,w_636/e76d5bbef180bcbb32cddf6ed3f14966.jpg" /><p>The Luna-25 mission crashed on the surface of the Moon this weekend, ending Russia’s quest to prove it still has what it takes to land on the lunar surface.</p><p><a href="https://gizmodo.com/russias-luna-25-moon-mission-crashes-1850757300">Read more...</a></p>

## David Tennant Teases How Different His Return to Doctor Who Is
 - [https://gizmodo.com/david-tennant-doctor-who-60th-anniversary-14th-doctor-1850755648](https://gizmodo.com/david-tennant-doctor-who-60th-anniversary-14th-doctor-1850755648)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T14:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--R-qLxpBc--/c_fit,fl_progressive,q_80,w_636/950daca9023c15d4e2347cf91ca502b3.png" /><p>Could a fifth <em>Thor</em> movie really be on the way? <em>Star Wars: Young Jedi Adventures</em> is getting ready to celebrate Life Day. Al Gore strikes back in new <em>Futurama</em> pics. Plus, what’s coming on <em>Riverdale</em>’s final episode. To me, my spoilers!</p><p><a href="https://gizmodo.com/david-tennant-doctor-who-60th-anniversary-14th-doctor-1850755648">Read more...</a></p>

## Tesla Says Massive Data Breach Was an Inside Job
 - [https://gizmodo.com/tesla-says-massive-data-breach-was-an-inside-job-1850757217](https://gizmodo.com/tesla-says-massive-data-breach-was-an-inside-job-1850757217)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0InLDZp6--/c_fit,fl_progressive,q_80,w_636/0b459ab425091570714c1189f2ad6da9.jpg" /><p>Tesla’s data breach in May, which affected more than 75,000 people, was an inside job, the company said in a notice released to its customers on Friday. According to the <a href="https://apps.web.maine.gov/online/aeviewer/ME/40/014ae6db-4cb7-464b-b827-5d73f0bbc911.shtml" rel="noopener noreferrer" target="_blank">notice</a>, German news outlet Handelsblatt informed Tesla of the breach on May 10 after obtaining the confidential information.</p><p><a href="https://gizmodo.com/tesla-says-massive-data-breach-was-an-inside-job-1850757217">Read more...</a></p>

## Charles Martinet, Longtime Voice Actor for Mario and Luigi, Retires
 - [https://gizmodo.com/charles-martinet-super-mario-nintendo-voice-retire-1850757330](https://gizmodo.com/charles-martinet-super-mario-nintendo-voice-retire-1850757330)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T14:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7VhdcTMP--/c_fit,fl_progressive,q_80,w_636/5580d79fb4a16ad30ac9092f0e090cb4.png" /><p>Nintendo has announced on <a href="https://twitter.com/NintendoUK/status/1693624024000036898?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1693624024000036898%7Ctwgr%5E4093d9baecbba2f152d30a5ffaa15c19859f234f%7Ctwcon%5Es1_c10&amp;ref_url=https%3A%2F%2Fkinja.com%2Fembed%2Finset%2Fiframe%3Fautosize%3D1id%3Dtwitter-1693624024000036898" rel="noopener noreferrer" target="_blank">X,</a> formerly known as Twitter, that Charles Martinet, who has been the video game voice actor for Mario since 1991, is retiring. He will be stepping into a “new role” of Mario Ambassador. No announcement has been made about the future of Mario’s voice.</p><p><a href="https://gizmodo.com/charles-martinet-super-mario-nintendo-voice-retire-1850757330">Read more...</a></p>

## Threads Is Finally Getting a Web Browser
 - [https://gizmodo.com/threads-is-finally-getting-a-web-browser-1850757140](https://gizmodo.com/threads-is-finally-getting-a-web-browser-1850757140)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T13:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--bJIqzpkn--/c_fit,fl_progressive,q_80,w_636/0822dfb828f17a4fdcc2e6a93b02f7a7.jpg" /><p>As the cold war between Elon Musk’s Twitter (recently rebranded as X) and Mark Zuckerberg’s Threads rages on, the latter is preparing to launch a new offensive. Head of Instagram Adam Mosseri announced that Threads was finally getting a bona fide browser version.</p><p><a href="https://gizmodo.com/threads-is-finally-getting-a-web-browser-1850757140">Read more...</a></p>

## Apple Is Already Working on Chips for iPhone 15's Successors
 - [https://gizmodo.com/apple-working-on-chips-for-iphone-15-a17-successor-1850757130](https://gizmodo.com/apple-working-on-chips-for-iphone-15-a17-successor-1850757130)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T13:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--OE-O4-YN--/c_fit,fl_progressive,q_80,w_636/d46fb51c68899d8a02682a46853437c2.jpg" /><p>Are you already entirely up to date with all the iPhone 15 rumors ahead of its <a href="https://gizmodo.com/apple-iphone-15-how-to-watch-1850719532">expected debut next month</a>? Well, don’t let the impending release stop you from squinting at the product IDs for Apple’s processor series two years in advance.</p><p><a href="https://gizmodo.com/apple-working-on-chips-for-iphone-15-a17-successor-1850757130">Read more...</a></p>

## New One Piece Featurette Goes Behind the Seas With the Cast and Crew
 - [https://gizmodo.com/one-piece-cast-crew-bts-featurette-live-action-netflix-1850757071](https://gizmodo.com/one-piece-cast-crew-bts-featurette-live-action-netflix-1850757071)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T13:02:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ef5yn9B7--/c_fit,fl_progressive,q_80,w_636/8660fecb055de0ba414cf14352d84edd.jpg" /><p><em>One Piece</em>, a beloved, long-running manga <a href="https://gizmodo.com/one-piece-anime-english-dub-crunchyroll-stream-july-5-1850602855">and anime</a> that has been read and watched worldwide, is finally coming to <a href="https://gizmodo.com/one-piece-japanese-dub-netflix-series-1850599952">live-action</a>. <a href="https://gizmodo.com/one-piece-live-action-series-netflix-release-date-1850404038">Eiichiro Oda</a>, the original manga’s author/artist has been working alongside <a href="https://gizmodo.com/sdcc-2023-one-piece-trailer-netflix-1850664763">Netflix</a> throughout the production. A new featurette shows off some all new footage plus interviews with the cast and…</p><p><a href="https://gizmodo.com/one-piece-cast-crew-bts-featurette-live-action-netflix-1850757071">Read more...</a></p>

## ‘I Was Shadowbanned:’ How Hinge's Algorithm Decides Who You Date
 - [https://gizmodo.com/hinge-dating-app-algorithm-1850744140](https://gizmodo.com/hinge-dating-app-algorithm-1850744140)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-08-21T10:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yl-D1kcO--/c_fit,fl_progressive,q_80,w_636/8113bbba100151a290a46e7c2a126252.jpg" /><p>Last year, a friend came to me with a strange tech problem. “The algorithm is screwing me over,” he said, peering over a drink at a bar in Manhattan’s East Village. Anthony, a 31-year old engineer who asked to withhold his real name, had been on the dating app Hinge for five years. He said he always had a hard time…</p><p><a href="https://gizmodo.com/hinge-dating-app-algorithm-1850744140">Read more...</a></p>

