# Source:Tomasz Samołyk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg, language:pl-PL

## Tyle kasy wydałem na ubogich, a tyle modliłem się za Was (o obłudzie i ośrodku w Rusinowicach)
 - [https://www.youtube.com/watch?v=jN2puDq9qN8](https://www.youtube.com/watch?v=jN2puDq9qN8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCj5Ug7sV0Id9g-NEfFa1psg
 - date published: 2023-08-21T15:00:36+00:00

W dzisiejszym odcinku opowiadam o ośrodku rehabilitacyjnym w Rusinowicach i o czystych intencjach.

#obłuda #rusinowice #czystość

👉  Ośrodek Rehabilitacyjny pw. św. Rafała Archanioła w Rusinowicach: https://www.rusinowice.com/

👉 Kontynuowanie i rozwijanie mojej pracy możliwe jest dzięki Patronom. Tu można do nich dołączyć oraz dowiedzieć się o tym na co idą środki ze wsparcia oraz poczytać o planowanych kierunkach rozwoju kanału: https://patronite.pl/Samolyk

JAK MOŻNA WESPRZEĆ KANAŁ i DOŁĄCZYĆ DO GRUPY FACEBOOK DLA WSPIERAJĄCYCH:

Można mnie wesprzeć na https://patronite.pl/samolyk, przez przycisk "WESPRZYJ" lub wpłacając dobrowolną kwotę na nr konta: Bank Pekao SA 08 1240 2786 1111 0010 1984 8265 tytułem: "darowizna"
--------------------------------------------------------------------------------------
Jeżeli wpłaciłeś darowiznę, wsparłeś mnie przez przycisk "WESPRZYJ" i chcesz być w napisach końcowych I dołączyć do grupy Patronów na Facebooku to daj mi znać na tsamolyk@gmail.com. Kiedyś wpisywałem w napisach końcowych wszystkich Darczyńców, ale kilku z nich zwróciło mi uwagę, że chcą pozostać anonimowi. Mają do tego prawo więc wprowadzam taką praktykę. Dziękuję za zrozumienie.

