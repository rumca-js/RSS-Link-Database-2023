# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## The Creator Featurette - Gareth's Vision (2023)
 - [https://www.youtube.com/watch?v=FcSoc22KK7M](https://www.youtube.com/watch?v=FcSoc22KK7M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-08-21T18:36:20+00:00

Check out an Official Behind the Scenes Featurette for The Creator starring John David Washington! 

► Buy Tickets for The Creator: https://www.fandango.com/the-creator-2023-231997/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: September 29, 2023
Starring: Gemma Chan, John David Washington, Ken Watanabe
Director: Gareth Edwards
Synopsis: From writer/director Gareth Edwards ("Rogue One," "Godzilla") comes an epic sci-fi action thriller set amidst a future war between the human race and the forces of artificial intelligence. Joshua (John David Washington, "Tenet"), a hardened ex-special forces agent grieving the disappearance of his wife (Gemma Chan, "Eternals"), is recruited to hunt down and kill the Creator, the elusive architect of advanced AI who has developed a mysterious weapon with the power to end the war... and mankind itself. Joshua and his team of elite operatives journey across enemy lines, into the dark heart of AI-occupied territory... only to discover the world-ending weapon he's been instructed to destroy is an AI in the form of a young child (newcomer Madeleine Yuna Voyles).

► Learn more: https://www.rottentomatoes.com/m/the_creator_2023?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#TheCreator

## Freelance Trailer #1 (2023)
 - [https://www.youtube.com/watch?v=kiON2PCrESY](https://www.youtube.com/watch?v=kiON2PCrESY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-08-21T17:38:17+00:00

Check out the official trailer for Freelance starring John Cena! 
► Sign up for a Fandango FanAlert for Freelance: http://www.fandango.com/freelance-2023-/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: October 6, 2023
Starring: Alice Eve, Alison Brie, John Cena
Director: Pierre Morel
Synopsis: An ex-special forces operator takes a job providing security for a journalist as she interviews a cruel dictator, but a military coup breaks out and the three are forced to escape into the jungle.
► Learn more: https://www.rottentomatoes.com/m/freelance_2023?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#Freelance #JohnCena

## The Creator TV Spot - Fear (2023)
 - [https://www.youtube.com/watch?v=pgoAEa7k3Kc](https://www.youtube.com/watch?v=pgoAEa7k3Kc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-08-21T16:34:05+00:00

Check out the official trailer for The Creator starring Madeleine Yuna Voyles! 
► Buy Tickets on Fandango: https://www.fandango.com/the-creator-2023-231997/movie-overview?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: September 29, 2023
Starring: Madeleine Yuna Voyles, Gemma Chan, John David Washington, Ken Watanabe
Director: Gareth Edwards
Synopsis: Mankind goes to war against sentient robotic beings.
► Learn more: https://www.rottentomatoes.com/m/the_creator_2023?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#TheCreator #20thCenturyStudios

## Reptile Trailer #1 (2023)
 - [https://www.youtube.com/watch?v=6FwGvIZxdVg](https://www.youtube.com/watch?v=6FwGvIZxdVg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-08-21T15:02:13+00:00

Check out the official trailer for Reptile starring Benicio del Toro! 
► Visit Fandango: https://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: October 6, 2023
Starring: Alicia Silverstone, Benicio del Toro, Justin Timberlake
Director: Grant Singer
Synopsis: Following the brutal murder of a young real estate agent, a hardened detective attempts to uncover the truth in a case where nothing is as it seems, and, by doing so, dismantles the illusions in his own life.
► Learn more: https://www.rottentomatoes.com/m/reptile_2023?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#Reptile #Netflix

## Celebrate National Cinema Day!
 - [https://www.youtube.com/watch?v=aa2PzTxkppc](https://www.youtube.com/watch?v=aa2PzTxkppc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-08-21T13:00:03+00:00

Celebrate National Cinema Day 8/27 with Fandango!

► Buy Tickets on Fandango: http://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in one place!

#NationalCinemaDay

