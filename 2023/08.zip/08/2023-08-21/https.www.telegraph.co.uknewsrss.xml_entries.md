# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Lucy Letby will never be released, but this is not the end of the horror
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-victims-families-real-life-sentence/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-victims-families-real-life-sentence/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T21:19:06+00:00



## Crooked House campaigners stage sit-in to stop removal work
 - [https://www.telegraph.co.uk/news/2023/08/21/campaigners-sit-in-at-crooked-house-pub-try-stop-clear-up/](https://www.telegraph.co.uk/news/2023/08/21/campaigners-sit-in-at-crooked-house-pub-try-stop-clear-up/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T20:36:19+00:00



## Monday evening news briefing: Lucy Letby to die in jail after 'cynical campaign of child murder'
 - [https://www.telegraph.co.uk/news/2023/08/21/monday-evening-news-briefing-lucy-letby-to-die-in-jail-afte/](https://www.telegraph.co.uk/news/2023/08/21/monday-evening-news-briefing-lucy-letby-to-die-in-jail-afte/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T16:35:40+00:00



## Ukraine: The Latest - Former Nasa astronaut on working with Russia in space
 - [https://www.telegraph.co.uk/news/2023/08/21/russia-space-moon-mission-ukraine-cosmonauts-nasa/](https://www.telegraph.co.uk/news/2023/08/21/russia-space-moon-mission-ukraine-cosmonauts-nasa/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T15:58:09+00:00



## Watch: Moment Lucy Letby is told she will spend the rest of her life in prison
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-sentenced-whole-life-order-watch/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-sentenced-whole-life-order-watch/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T14:11:05+00:00



## Lucy Letby's parents fail to appear in court for daughter's sentencing
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-parents-absent-court-manchester-sentencing/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-parents-absent-court-manchester-sentencing/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T12:04:50+00:00



## ‘You are evil. You did this’, victims’ families tell Lucy Letby
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-victim-impact-statement-manchester-sentencing/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-victim-impact-statement-manchester-sentencing/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T11:35:25+00:00



## 'Cowardly' Lucy Letby refuses to enter dock for sentencing in 'final act of wickedness'
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-refuses-appear-dock-court-sentencing-coward/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-refuses-appear-dock-court-sentencing-coward/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T10:21:09+00:00



## Lucy Letby live: Serial baby killer refuses to appear at sentencing
 - [https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-nurse-murder-sentencing-live-hmp-bronzefield/](https://www.telegraph.co.uk/news/2023/08/21/lucy-letby-nurse-murder-sentencing-live-hmp-bronzefield/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T09:06:53+00:00



## Mass brawl erupts ‘between rival gangs’ at kabaddi tournament
 - [https://www.telegraph.co.uk/news/2023/08/21/alvaston-india-kabaddi-tournament-derby-gang-gun-violence/](https://www.telegraph.co.uk/news/2023/08/21/alvaston-india-kabaddi-tournament-derby-gang-gun-violence/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T08:47:24+00:00



## Virgin Radio DJ Chris Evans reveals skin cancer diagnosis live on air
 - [https://www.telegraph.co.uk/news/2023/08/21/chris-evans-dj-skin-cancer-diagnosis-live-air-virgin-radio/](https://www.telegraph.co.uk/news/2023/08/21/chris-evans-dj-skin-cancer-diagnosis-live-air-virgin-radio/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T07:46:12+00:00



## Ucas Clearing 2023: How to get a last-minute university place on A-level results day
 - [https://www.telegraph.co.uk/news/2023/08/21/how-ucas-clearing-2023-works-university-placements-grades-rejection/](https://www.telegraph.co.uk/news/2023/08/21/how-ucas-clearing-2023-works-university-placements-grades-rejection/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-08-21T06:50:57+00:00



