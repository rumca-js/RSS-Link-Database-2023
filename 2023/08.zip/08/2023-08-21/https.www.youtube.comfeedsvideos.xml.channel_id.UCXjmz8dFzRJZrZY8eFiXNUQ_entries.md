# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## The Most Glaring Problem With JJ Abrams' Movies
 - [https://www.youtube.com/watch?v=PbYbPRQlavs](https://www.youtube.com/watch?v=PbYbPRQlavs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-08-21T17:00:21+00:00

Without a doubt JJ Abrams is one of the most recognizable directors of the decade.  Resurrecting franchises like Mission Impossible, Star Trek and Star Wars put the director on the map, but one famously personal touch may have gone too far...Lens Flares.  JJ Abrams is now more known for his use of Lens Flares than his large body of work.  But in his more recent films, it seems JJ Abrams has stepped away from the use of Lens Flares, almost entirely.

#jjabrams #startrek #starwars #nerdstalgic 


Sources: 
What Causes Lens Flares and Why: 
https://www.youtube.com/watch?v=OaHVdA8KLtw
https://www.youtube.com/watch?v=miL6UxY5bnU&amp;t=144s
https://www.youtube.com/watch?v=HKY666zwcz0
https://ew.com/article/2015/11/22/star-wars-force-awakens-jj-abrams-lens-flares/

