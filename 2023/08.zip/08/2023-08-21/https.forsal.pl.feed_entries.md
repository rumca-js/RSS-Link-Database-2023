# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Polska w recesji. Tak słabego początku III kwartału dawno nie było
 - [https://forsal.pl/gospodarka/pkb/artykuly/9281409,polska-w-recesji-tak-slabego-poczatku-iii-kwartalu-dawno-nie-bylo.html](https://forsal.pl/gospodarka/pkb/artykuly/9281409,polska-w-recesji-tak-slabego-poczatku-iii-kwartalu-dawno-nie-bylo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-22T00:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S8PktkuTURBXy9lNjI4MGNmMC0zMGIzLTQzYTMtYmI5Ni1iOWIxZTQyNTNmODYuanBlZ5GTBc0BHcyg" />W lipcu szósty miesiąc z rzędu produkcja przemysłowa była niższa niż przed rokiem, a tempo wzrostu wynagrodzeń najsłabsze od lutego zeszłego roku. Ekonomiści oceniają, że odbicie w II półroczu będzie powolne

## Wyborcze obietnice tanich mieszkań nie zbudują
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281397,wyborcze-obietnice-tanich-mieszkan-nie-zbuduja.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281397,wyborcze-obietnice-tanich-mieszkan-nie-zbuduja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-22T00:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jUrktkuTURBXy8xNjVjYWNlZS0xYjUxLTQ2NjEtOWRlNy1mNzZjMDkyNDJiZDAuanBlZ5GTBc0BHcyg" />Wszystkie partie polityczne zgodnie zauważają, że rynek mieszkaniowy w Polsce nie wygląda tak, jak powinien. Proponowane rozwiązania tej sytuacji są jednak radykalnie inne

## 27 sierpnia 2023 - czy to niedziela handlowa?
 - [https://forsal.pl/artykuly/1398040,27-sierpnia-2023-czy-to-niedziela-handlowa.html](https://forsal.pl/artykuly/1398040,27-sierpnia-2023-czy-to-niedziela-handlowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T21:00:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8LUktkuTURBXy9mYTI0N2ExMS1mNTM1LTQyZWEtYjEyZC04Y2YzN2M5YzJjNmYuanBlZ5GTBc0BHcyg" />Czy w niedzielę 27 sierpnia sklepy będą otwarte? Kiedy przypada najbliższa niedziela handlowa? Oto nasz kalendarz niedziel handlowych.

## Media: Prigożyn twierdzi, że jest w Afryce i walczy z dżihadystami
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281570,media-prigozyn-twierdzi-ze-jest-w-afryce-i-walczy-z-dzihadystami.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281570,media-prigozyn-twierdzi-ze-jest-w-afryce-i-walczy-z-dzihadystami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T20:47:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iPbktkuTURBXy9iMzYyM2FjNi1lZDlhLTQ0YjAtYWY3OS1kZjg3ZGZjMzQ2MjUuanBlZ5GTBc0BHcyg" />Założyciel najemniczej Grupy Wagnera Jewgienij Prigożyn nagrał klip, w którym mówi, że znajduje się w Afryce i walczy „o sprawiedliwość i szczęście” afrykańskich narodów – poinformował w poniedziałek ukraiński portal „Ukraińska Prawda”.

## Dlaczego Goran Bregović dostał zakaz wjazdu do Mołdawii?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281567,dlaczego-goran-bregovic-dostal-zakaz-wjazdu-do-moldawii.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281567,dlaczego-goran-bregovic-dostal-zakaz-wjazdu-do-moldawii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T20:22:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hidktkuTURBXy82M2I2ZmMyYi0zN2YxLTQxZWEtOTdhMS03ZDNlMjRhMjQyMjMuanBlZ5GTBc0BHcyg" />Prorosyjskie poglądy i poparcie udzielone nielegalnej aneksji Krymu przez Rosję stoją za decyzją o zakazaniu wjazdu do Mołdawii Goranowi Bregoviciowi - powiedział w poniedziałek Adrian Efros, minister spraw wewnętrznych Mołdawii.

## Departament Stanu USA wyraził zgodę na sprzedaż Polsce śmigłowców AH-64E Apache
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281562,departament-stanu-usa-wyrazil-zgode-na-sprzedaz-polsce-smiglowcow-ah-6.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281562,departament-stanu-usa-wyrazil-zgode-na-sprzedaz-polsce-smiglowcow-ah-6.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T19:56:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HP-ktkuTURBXy9iM2MyYWMzYS0wZjIzLTRjNTctYWVhYy02ZGU0NmZiNjE1YjEuanBlZ5GTBc0BHcyg" />Departament Stanu wyraził zgodę na potencjalną sprzedaż Polsce 96 śmigłowców szturmowych AH-64E Apache wraz z uzbrojeniem, wyceniając je na 12 miliardów dolarów - podała należąca do Pentagonu agencja Defense Security Cooperation Agency (DSCA).

## Poparcie republikanów dla Trumpa wzrosło po najnowszej serii zarzutów [SONDAŻ]
 - [https://forsal.pl/swiat/usa/artykuly/9281539,poparcie-republikanow-dla-trumpa-wzroslo-po-najnowszej-serii-zarzutow.html](https://forsal.pl/swiat/usa/artykuly/9281539,poparcie-republikanow-dla-trumpa-wzroslo-po-najnowszej-serii-zarzutow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T19:26:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-K7ktkuTURBXy82YjY2YWVkOS0yYmVjLTRlMTctYTA4Mi00ZTZkNTQxODc0OGQuanBlZ5GTBc0BHcyg" />Poparcie dla Donalda Trumpa wśród wyborców republikanów wzrosło po ostatniej serii zarzutów wysuniętych przez śledczych w Georgii - wynika z opublikowanego w poniedziałek sondażu telewizji NBC News i gazety Des Moines Register w Iowa. W niedzielę Trump oświadczył, że z powodu znacznej przewagi nad resztą stawki zrezygnuje z udziału w debatach przed republikańskimi prawyborami.

## "New Yorker": Władze USA w wielu obszarach są zdane na łaskę Elona Muska
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281536,new-yorker-wladze-usa-w-wielu-obszarach-sa-zdane-na-elona-muska.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281536,new-yorker-wladze-usa-w-wielu-obszarach-sa-zdane-na-elona-muska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T19:14:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d0wktkuTURBXy8wZGU2MjZlMS1kZDM4LTQ4NWEtYmE4NS1kOWIyY2RhZTk4NTMuanBlZ5GTBc0BHcyg" />Rządowe agencje są zdane na łaskę i niełaskę miliardera Elona Muska, w obszarach od obronności po eksplorację kosmosu - zauważa w poniedziałek magazyn &quot;New Yorker&quot;. Pismo twierdzi, że poziom uzależnienia państwa od bogacza budzi obawy, m.in. w obliczu jego coraz bardziej impulsywnego zachowania, pogardy dla zasad i &quot;regularnych&quot; konsultacji z Kremlem.

## Zełenski: Grecja przyłączy się do szkolenia ukraińskich pilotów
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281532,zelenski-grecja-przylaczy-sie-do-szkolenia-ukrainskich-pilotow.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281532,zelenski-grecja-przylaczy-sie-do-szkolenia-ukrainskich-pilotow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T19:07:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w6EktkuTURBXy9mY2Y5ZmFhOS0zNzIzLTQzNGItOWFjYi0zZDI2N2JiODMyMjMuanBlZ5GTBc0BHcyg" />Grecja przyłączy się do szkolenia ukraińskich pilotów na myśliwcach F-16 – poinformował w poniedziałek prezydent Ukrainy Wołodymyr Zełenski na konferencji prasowej w Atenach po spotkaniu z premierem Grecji Kyriakosem Micotakisem.

## "Times": Pekin inwestuje obecnie w Serbii tyle, ile cała UE; to zła wiadomość dla zachodnich dyplomatów
 - [https://forsal.pl/swiat/chiny/artykuly/9281464,times-pekin-inwestuje-obecnie-w-serbii-tyle-ile-cala-ue-to-zla-wi.html](https://forsal.pl/swiat/chiny/artykuly/9281464,times-pekin-inwestuje-obecnie-w-serbii-tyle-ile-cala-ue-to-zla-wi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T18:43:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jzbktkuTURBXy8wZjNmNzZiZi00OTg0LTQ3OGItOTViZS1mMzE0M2VjNDVkZjguanBlZ5GTBc0BHcyg" />Chiny inwestują obecnie w Serbii tyle, ile cała Unia Europejska łącznie; to musi budzić niepokój zachodnich dyplomatów - pisze w poniedziałek brytyjski dziennik &quot;Times&quot;

## Benefit Systems: Sąd UOKiK oddalił odwołanie spółki od decyzji Prezesa Urzędu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281462,benefit-systems-sad-uokik-oddalil-odwolanie-spolki-od-decyzji-prezesa.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281462,benefit-systems-sad-uokik-oddalil-odwolanie-spolki-od-decyzji-prezesa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T18:21:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yj-ktkuTURBXy80MjFiNjdkNi1lZGE5LTQzYzQtYTY4MS03ZGNiYzQwOGEzNWYuanBlZ5GTBc0BHcyg" />Sąd Ochrony Konkurencji i Konsumentów oddalił odwołanie Benefit Systems od decyzji wydanej przez Prezesa UOKiK - poinformowała w poniedziałek spółka. Chodzi o nałożenie na Benefit Systems kary w wysokości 26,9 mln zł. Spółka zapowiedziała wniesienie apelacji od wyroku Sądu.

## Prezydent Portugalii zawetował ustawę ws. wynajmu pustych domów
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/9281455,prezydent-portugalii-zawetowal-ustawe-ws-wynajmu-pustych-domow.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/9281455,prezydent-portugalii-zawetowal-ustawe-ws-wynajmu-pustych-domow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T18:00:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bvwktkuTURBXy82M2M1ZDNhOC1lY2EyLTQzMTctOWU4ZS01OWQ4ZDg0YTQzNmEuanBlZ5GTBc0BHcyg" />Prezydent Portugalii Marcelo Rebelo de Sousa zawetował w poniedziałek zatwierdzoną w lipcu przez jednoizbowy parlament ustawę o mieszkalnictwie. Regulacja ta zobowiązywała m.in. posiadaczy pustych domów do ich wynajęcia.

## Ukraińskie media: Otrzymamy F-16 z ubiegłego wieku, część z nich nie będzie nadawała się do latania
 - [https://forsal.pl/swiat/ukraina/artykuly/9281454,ukrainskie-media-otrzymamy-f-16-z-ubieglego-wieku-czesc-z-nich-nie-b.html](https://forsal.pl/swiat/ukraina/artykuly/9281454,ukrainskie-media-otrzymamy-f-16-z-ubieglego-wieku-czesc-z-nich-nie-b.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T17:54:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mNJktkuTURBXy9iNGExODQ5OC1iN2M4LTRmMTgtOWY5MC1kMDliNzgyMDU0YmEuanBlZ5GTBc0BHcyg" />Ukraina otrzyma myśliwce F-16 wyprodukowane jeszcze w ubiegłym wieku i część z nich nie będzie nadawać się do latania – pisze w poniedziałek ukraiński portal Defence Express.

## MRiRW: Tajlandia dopuszcza na swój rynek polskie mięso wołowe
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281452,mrirw-tajlandia-dopuszcza-na-swoj-rynek-polskie-mieso-wolowe.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281452,mrirw-tajlandia-dopuszcza-na-swoj-rynek-polskie-mieso-wolowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T17:26:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ce3ktkuTURBXy9iNmYyYTU0ZS0zMjAwLTRlYWEtOWY0MC04ZmNmM2ZjMzk4MDUuanBlZ5GTBc0BHcyg" />11 polskich zakładów produkujących wołowinę uzyskało uprawnienia do eksportu tego mięsa na rynek Tajlandii - poinformowało w poniedziałek Ministerstwo Rolnictwa i Rozwoju Wsi. Zatwierdzenie obowiązuje przez 3 lat - dodano.

## Minister energii i zasobów naturalnych Turcji: Po raz pierwszy wyślemy gaz naturalny do kraju europejskiego, z którym nie graniczymy
 - [https://forsal.pl/biznes/energetyka/artykuly/9281450,minister-energii-i-zasobow-naturalnych-turcji-po-raz-pierwszy-wyslemy.html](https://forsal.pl/biznes/energetyka/artykuly/9281450,minister-energii-i-zasobow-naturalnych-turcji-po-raz-pierwszy-wyslemy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T17:17:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/T2YktkuTURBXy9kOTNiNTQ1MS05YmQxLTQ5ZjMtYjdhYS02NjQwNTgxODM1NGQuanBlZ5GTBc0BHcyg" />Po raz pierwszy w historii rozpoczniemy przesyłanie gazu naturalnego do kraju europejskiego, z którym nie dzielimy granicy. Eksport surowca na Węgry powinien ruszyć w przyszłym roku - poinformował w poniedziałek minister energii i zasobów naturalnych Turcji Alparslan Bayraktar.

## Sasin o ofercie zakupu akcji Bogdanki: Realizujemy obietnice
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281446,sasin-o-ofercie-zakupu-akcji-bogdanki-realizujemy-obietnice.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281446,sasin-o-ofercie-zakupu-akcji-bogdanki-realizujemy-obietnice.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T17:01:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KS8ktkuTURBXy9hMTdhYjFiZS1iNzBmLTRmMzQtOGRkZS1hM2E4ZjYwM2RiNDIuanBlZ5GTBc0BHcyg" />Realizujemy obietnice, zgodnie z wcześniejszymi zapowiedziami Skarb Państwa złożył Grupie Enea ofertę nabycia wszystkich akcji Bogdanki - napisał na twitterze minister aktywów państwowych Jacek Sasin. Skarb Państwa zaoferował Enei po 345 zł za akcję Bogdanki.

## Rekordowe powodzie i opady w Kalifornii; zalana Dolina Śmierci
 - [https://forsal.pl/swiat/usa/artykuly/9281444,rekordowe-powodzie-i-opady-w-kalifornii-zalana-dolina-smierci.html](https://forsal.pl/swiat/usa/artykuly/9281444,rekordowe-powodzie-i-opady-w-kalifornii-zalana-dolina-smierci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T16:58:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PoUktkuTURBXy9lZDZmNDdmYy02MWI3LTQ4ZTgtYmE4Yy02ZGEzZGRlYmE0M2QuanBlZ5GTBc0BHcyg" />Pierwsza od ponad 80 lat burza tropikalna Hilary spowodowała rekordowe opady deszczu i powodzie w Kalifornii i Nevadzie, choć jak dotąd nie sprawdziły się najczarniejsze scenariusze - donoszą w poniedziałek media. Z powodu powodzi zamknięto park narodowy w Dolinie Śmierci, zaś pustynny kurort Palm Springs został odcięty od świata.

## Aforti zamierza odwołać się od decyzji Prezesa UOKIK o nałożeniu kary
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281443,aforti-zamierza-odwolac-sie-od-decyzji-prezesa-uokik-o-nalozeniu-kary.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281443,aforti-zamierza-odwolac-sie-od-decyzji-prezesa-uokik-o-nalozeniu-kary.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T16:51:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QFBktkuTURBXy9jNjU2MjgzYS0xN2E3LTQxZTgtOTgzYy1mZjc4MzRmM2EzOTQuanBlZ5GTBc0BHcyg" />Aforti Holding nie zgadza się z decyzją Prezesa UOKiK o nałożeniu kary za wprowadzenie konsumentów w błąd i odwoła się do Sądu Ochrony Konkurencji i Konsumentów - przekazała w poniedziałek PAP spółka. Urząd antymonopolowy nałożył na Aforti 790 tys. zł kary.

## Ambasada USA: Obywatele Stanów Zjednoczonych powinni natychmiast wyjechać z Białorusi
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281441,ambasada-usa-obywatele-stanow-zjednoczonych-powinni-natychmiast-wyjec.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281441,ambasada-usa-obywatele-stanow-zjednoczonych-powinni-natychmiast-wyjec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T16:42:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dSDktkuTURBXy8yZmY1NzFhNC1hYjJjLTQyODQtYTM5Ni1lY2E0ODMxZjhiNmEuanBlZ5GTBc0BHcyg" />Przebywający na Białorusi obywatele Stanów Zjednoczonych &quot;powinni stąd natychmiast wyjechać&quot; - oznajmiła amerykańska ambasada w tym kraju na swojej stronie internetowej.

## Najwyższy alarm z powodu upałów we włoskich miastach
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281359,najwyzszy-alarm-z-powodu-upalow-we-wloskich-miastach.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281359,najwyzszy-alarm-z-powodu-upalow-we-wloskich-miastach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T16:17:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FxZktkuTURBXy83ZGQ2ZDgzZi00NzczLTQ0ZmQtYTkyZC00MjVjYTk4NThlZWMuanBlZ5GTBc0BHcyg" />W 12 miastach Włoch, w tym w Rzymie i Florencji, obowiązuje w poniedziałek najwyższy stopień alarmu z powodu upałów, sięgających 40 stopni Celsjusza. W środę liczba tych miast wzrośnie do 17 - zapowiedziało Ministerstwo Zdrowia.

## Złoty w poniedziałek po południu stracił wobec głównych walut
 - [https://forsal.pl/finanse/artykuly/9281356,zloty-w-poniedzialek-po-poludniu-stracil-wobec-glownych-walut.html](https://forsal.pl/finanse/artykuly/9281356,zloty-w-poniedzialek-po-poludniu-stracil-wobec-glownych-walut.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T16:01:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uw1ktkuTURBXy83YmM4MjBkMi04Y2E0LTQ0NjktOTNiOC1jY2RmZmY0MTE4ZTIuanBlZ5GTBc0BHcyg" />W poniedziałek po południu polska waluta straciła na wartości wobec euro, franka szwajcarskiego i dolara amerykańskiego. Euro kosztowało 4,47 zł, frank szwajcarski 4,67 zł, a dolar 4,11 zł.

## Gaz na europejskim rynku w poniedziałek drożeje w granicach 12 proc.
 - [https://forsal.pl/biznes/energetyka/artykuly/9281349,gaz-na-europejskim-rynku-w-poniedzialek-drozeje-w-granicach-12-proc.html](https://forsal.pl/biznes/energetyka/artykuly/9281349,gaz-na-europejskim-rynku-w-poniedzialek-drozeje-w-granicach-12-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T15:43:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/32yktkuTURBXy8zZTg1MDVkMi03Nzk5LTQ4NDAtYmMwOS1kMjIyNmMxMjQzZjQuanBlZ5GTBc0BHcyg" />Gaz w holenderskim hubie TTF w poniedziałek zdrożał w granicach 12 proc. Najbardziej, o 12 proc. podrożały kontrakty z dostawą we wrześniu, wyceniane na prawie 41 euro. Powodem wzrostów są obawy przed strajkiem w terminalach eksportowych LNG w Australii.

## Bild: Kryzys uchodźczy pogłębia się; liczba nielegalnych migrantów rośnie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281348,bild-kryzys-uchodzczy-poglebia-sie-liczba-nielegalnych-migrantow-ros.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281348,bild-kryzys-uchodzczy-poglebia-sie-liczba-nielegalnych-migrantow-ros.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T15:41:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LobktkuTURBXy9mNjkxM2Y5MS1kODEyLTRhNDAtYjU4Yi0wMWFjODRlMDA0MzQuanBlZ5GTBc0BHcyg" />Z najnowszych danych policji federalnej wynika, że w lipcu do Niemiec nielegalnie wjechało 10 714 osób – najwięcej od listopada 2022 roku. Dziennie ma miejsce ponad 300 nielegalnych przekroczeń granicy – poinformował w poniedziałek portal dziennika „Bild”.

## Policja zamknęła śledztwo ws. odznaczeń za dotacje dla fundacji Karola III
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281347,policja-zamknela-sledztwo-ws-odznaczen-za-dotacje-dla-fundacji-karola.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281347,policja-zamknela-sledztwo-ws-odznaczen-za-dotacje-dla-fundacji-karola.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T15:33:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FIpktkuTURBXy9iMTAyMWY2Ny1hMWFhLTRhNDYtODU0ZS01NzU3YmRlYTNkNTUuanBlZ5GTBc0BHcyg" />Londyńska policja metropolitalna oświadczyła w poniedziałek, że nie podejmie żadnych dalszych działań w następstwie dochodzenia w sprawie doniesień medialnych, jakoby fundacja założona przez króla Karola III, gdy był on jeszcze następcą tronu, oferowała odznaczenia w zamian za darowizny.

## Ekonomiści: Niepokojące sygnały z przemysłu i rynku pracy
 - [https://forsal.pl/praca/aktualnosci/artykuly/9281254,ekonomisci-niepokojace-sygnaly-z-przemyslu-i-rynku-pracy.html](https://forsal.pl/praca/aktualnosci/artykuly/9281254,ekonomisci-niepokojace-sygnaly-z-przemyslu-i-rynku-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T15:18:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/z3JktkuTURBXy83Y2IzOWUwMi02ZGU3LTQ3MmItYmUyOC03N2RkNTVlMzk4MGMuanBlZ5GTBc0BHcyg" />Drugie półrocze, które według nas ma przynieść odbicie gospodarcze, zaczęło się od niepokojących sygnałów z przemysłu i rynku pracy – stwierdzili ekonomiści Santander Bank Polska w komentarzu do poniedziałkowych danych GUS.

## "Temperatura na rynku najmu rośnie". O ile zwiększyły się stawki w lipcu?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281246,temperatura-na-rynku-najmu-rosnie-o-ile-zwiekszyly-sie-stawki-w-lip.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281246,temperatura-na-rynku-najmu-rosnie-o-ile-zwiekszyly-sie-stawki-w-lip.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T14:55:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WTYktkuTURBXy8zZjUzM2NmNS0wMWMzLTRiOTAtODM1YS0xNjhhNzU0MjFjYWIuanBlZ5GTBc0BHcyg" />undefined

## "Pierwsze Mieszkanie. Ile osób złożyło wnioski?
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281238,pierwsze-mieszkanie-ile-osob-zlozylo-wnioski.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9281238,pierwsze-mieszkanie-ile-osob-zlozylo-wnioski.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T14:30:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QL5ktkuTURBXy8zODMxOGY5YS02NDg5LTQ4ZmMtOGZhNC03NzZlODI2YmVlMWIuanBlZ5GTBc0BHcyg" />Ponad 32 tys. osób złożyło wnioski w programie „Pierwsze Mieszkanie”; podpisano 2 tys. 709 umów na prawie 1 mld złotych - poinformował w poniedziałek minister rozwoju i technologii Waldemar Buda. Dodał, że założono też 1 tys. 331 Kont Mieszkaniowych.

## Jak nie paść ofiarą "oszustwa romantycznego" w relacjach online? NASK udostępnia poradnik
 - [https://forsal.pl/lifestyle/technologie/artykuly/9281231,jak-nie-pasc-ofiara-oszustwa-romantycznego-w-relacjach-online-nask.html](https://forsal.pl/lifestyle/technologie/artykuly/9281231,jak-nie-pasc-ofiara-oszustwa-romantycznego-w-relacjach-online-nask.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T14:19:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-hdktkuTURBXy9lYzU2MDljYy03MWRhLTQwOGQtOTczZi1iODdhNDY0MDBiMmIuanBlZ5GTBc0BHcyg" />&quot;Internetowe love. Jak zadbać o swoje cyberbezpieczeństwo w relacjach online&quot; - to tytuł ogólnodostępnego poradnika wydanego przez Państwowy Instytut Badawczy NASK. Autorki publikacji tłumaczą, na czym polegają &quot;oszustwa romantyczne&quot; i jak się przed nimi ustrzec.

## Maląg: Koszt 14. emerytury będzie dla budżetu państwa wyższy o 9 mld zł
 - [https://forsal.pl/finanse/artykuly/9281222,malag-koszt-14-emerytury-bedzie-dla-budzetu-panstwa-wyzszy-o-9-mld-z.html](https://forsal.pl/finanse/artykuly/9281222,malag-koszt-14-emerytury-bedzie-dla-budzetu-panstwa-wyzszy-o-9-mld-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T14:05:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JLbktktTURBXy9hMDczYmRkYS01ZTM1LTRhNmYtYWM5Yy00OTdlNmIyYjVlYTkucG5nkZMFzQEdzKA" />undefined

## Bezwzględne dożywocie dla pielęgniarki, która zabiła 7 noworodków
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9281220,bezwzgledne-dozywocie-dla-pielegniarki-ktora-zabila-7-noworodkow.html](https://forsal.pl/swiat/aktualnosci/artykuly/9281220,bezwzgledne-dozywocie-dla-pielegniarki-ktora-zabila-7-noworodkow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T14:01:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LxaktkuTURBXy9mOWIyYzMxNC05MGYzLTQxZWYtOGQxMS05NTAwNDE0ODQ1ZDguanBlZ5GTBc0BHcyg" />Na karę bezwzględnego dożywocia, czyli bez możliwości ubiegania się kiedykolwiek o przedterminowe warunkowe zwolnienie, skazał w poniedziałek sąd w Manchesterze 33-letnią Lucy Letby, pielęgniarkę, która pracując na oddziale położniczym zabiła siedmioro noworodków i usiłowała zabić co najmniej sześcioro kolejnych.

## Zadłużenie Skarbu Państwa. Ile wyniosło na koniec lipca?
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9281203,zadluzenie-skarbu-panstwa-ile-wynioslo-na-koniec-lipca.html](https://forsal.pl/finanse/aktualnosci/artykuly/9281203,zadluzenie-skarbu-panstwa-ile-wynioslo-na-koniec-lipca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T13:45:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kJWktkuTURBXy85NmJlYTkxNy04M2NiLTQ5ZmMtOGE5NC1lNDIxYjZkMjYxYTAuanBlZ5GTBc0BHcyg" />undefined

## Szef MON: Do Polski dotarła pierwsza koreańska wyrzutnia rakietowa K239 Chunmoo
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281189,szef-mon-do-polski-dotarla-pierwsza-koreanska-wyrzutnia-rakietowa-k23.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281189,szef-mon-do-polski-dotarla-pierwsza-koreanska-wyrzutnia-rakietowa-k23.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T13:27:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DeVktkuTURBXy8wMWYzNmM1Yi02MzE5LTQ0ZjMtOWQwZS1kYTk2NmY5M2UxOWQuanBlZ5GTBc0BHcyg" />Do Polski właśnie dotarła pierwsza koreańska wyrzutnia rakietowa K239 Chunmoo; jeszcze w tym roku dotrą do nas kolejne wyrzutnie - poinformował w poniedziałek minister obrony narodowej Mariusz Błaszczak.

## Enea otrzymała od SP ofertę nabycia pakietu akcji LW Bogdanki
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9281164,enea-otrzymala-od-sp-oferte-nabycia-pakietu-akcji-lw-bogdanki.html](https://forsal.pl/biznes/aktualnosci/artykuly/9281164,enea-otrzymala-od-sp-oferte-nabycia-pakietu-akcji-lw-bogdanki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:45:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HnQktkuTURBXy9kZTcyMDUwMi00MzEwLTRjNDMtOTEyOC01YmI3MDg2ZDNlZjguanBlZ5GTBc0BHcyg" />Enea otrzymała od Skarbu Państwa, reprezentowanego przez Ministra Aktywów Państwowych, ofertę nabycia pakietu 21.962.189 akcji LW Bogdanki należących do Enei, po cenie 45 zł za akcję, czyli łącznie ok. 988,3 mln zł - podała Enea w komunikacie.

## Media: Australia rozpoczyna gruntowną modernizację sił zbrojnych
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281155,media-australia-rozpoczyna-gruntowna-modernizacje-sil-zbrojnych.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281155,media-australia-rozpoczyna-gruntowna-modernizacje-sil-zbrojnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:35:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KFmktkuTURBXy9kMTg0ZTNmYi02ZDNlLTQ2MDItYjA4MS1iYjdhM2QxZTE0MGYuanBlZ5GTBc0BHcyg" />undefined

## Setki Etiopczyków próbujących dostać się przez Jemen do Arabii Saudyjskiej zginęło na granicy [RAPORT HRW]
 - [https://forsal.pl/swiat/artykuly/9281148,setki-etiopczykow-probujacych-dostac-sie-przez-jemen-do-arabii-saudyjs.html](https://forsal.pl/swiat/artykuly/9281148,setki-etiopczykow-probujacych-dostac-sie-przez-jemen-do-arabii-saudyjs.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:27:16+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LobktkuTURBXy9mNjkxM2Y5MS1kODEyLTRhNDAtYjU4Yi0wMWFjODRlMDA0MzQuanBlZ5GTBc0BHcyg" />Saudyjscy strażnicy graniczni zostali oskarżeni o zabicie setek migrantów, głównie Etiopczyków, między innymi przy użyciu artylerii - poinformował w poniedziałek dziennik &quot;The Guardian&quot;, powołując się na raport organizacji ochrony praw człowieka Human Rights Watch z siedzibą w USA.

## NBP w lipcu zwiększył zasoby złota
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9281147,nbp-w-lipcu-zwiekszyl-zasoby-zlota.html](https://forsal.pl/finanse/aktualnosci/artykuly/9281147,nbp-w-lipcu-zwiekszyl-zasoby-zlota.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:23:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bVuktkuTURBXy8wZDhlZTU5Yy05M2NmLTRhM2QtYTBlNi0xZmFkODFhZjFiYWMuanBlZ5GTBc0BHcyg" />NBP w lipcu zwiększył zasoby złota. Na koniec tego miesiąca posiadał blisko 9,3 mln uncji złota, czyli o 0,72 mln uncji więcej niż miesiąc wcześniej – wynika z danych opublikowanych w poniedziałek przez bank centralny.

## Credit Agricole: Płace będą rosły coraz wolniej w nadchodzących kwartałach
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/9281138,credit-agricole-place-beda-rosly-coraz-wolniej-w-nadchodzacych-kwarta.html](https://forsal.pl/praca/wynagrodzenia/artykuly/9281138,credit-agricole-place-beda-rosly-coraz-wolniej-w-nadchodzacych-kwarta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:07:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AycktkuTURBXy81ODBhMTkzYi01OGZhLTQ4ZjEtOTIzYi02M2U2MmY0ODc4M2IuanBlZ5GTBc0BHcyg" />undefined

## Budimex Mobility uruchomił 31 stacji ładownia elektryków, ma ich łącznie ponad 140
 - [https://forsal.pl/finanse/gielda/artykuly/9281137,budimex-mobility-uruchomil-31-stacji-ladownia-elektrykow-ma-ich-laczn.html](https://forsal.pl/finanse/gielda/artykuly/9281137,budimex-mobility-uruchomil-31-stacji-ladownia-elektrykow-ma-ich-laczn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:07:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/enBktkuTURBXy8zZDRlNjFhZS1kNDk1LTRhMzYtYTVjNi00NDFhYWVhNTA0OTMuanBlZ5GTBc0BHcyg" />undefined

## Kernel: Wzrost plonów upraw ozimych w 2023 r., pszenicy do 6,6 t: ha, rzepaku do 3,3 t: ha
 - [https://forsal.pl/finanse/gielda/artykuly/9281136,kernel-wzrost-plonow-upraw-ozimych-w-2023-r-pszenicy-do-66-t-ha.html](https://forsal.pl/finanse/gielda/artykuly/9281136,kernel-wzrost-plonow-upraw-ozimych-w-2023-r-pszenicy-do-66-t-ha.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:04:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cQZktkuTURBXy9kNDdjOWMxNS00ZDI3LTQ4ZjYtYTg1Yy1jYTRlYmZhM2Q5MDUuanBlZ5GTBc0BHcyg" />undefined

## Kernel: Capex na zniszczenia w rosyjskich atakach ok. 20 mln USD, straty towaru 12 mln USD
 - [https://forsal.pl/finanse/gielda/artykuly/9281134,kernel-capex-na-zniszczenia-w-rosyjskich-atakach-ok-20-mln-usd-stra.html](https://forsal.pl/finanse/gielda/artykuly/9281134,kernel-capex-na-zniszczenia-w-rosyjskich-atakach-ok-20-mln-usd-stra.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T12:01:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HquktkuTURBXy9mZGYyYmI5ZC00YTU0LTQwOWMtYjYxNy1jZjNiOTM3OTEzYmIuanBlZ5GTBc0BHcyg" />undefined

## Sajnóg: Mimo oznak spowolnienia gospodarczego zatrudnienie pozostaje stabilne
 - [https://forsal.pl/praca/kariera/artykuly/9281104,sajnog-mimo-oznak-spowolnienia-gospodarczego-zatrudnienie-pozostaje-s.html](https://forsal.pl/praca/kariera/artykuly/9281104,sajnog-mimo-oznak-spowolnienia-gospodarczego-zatrudnienie-pozostaje-s.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T11:18:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wQ4ktkuTURBXy83NDkzMWUxYy1iMTlkLTQzNGMtODcyMS01Y2ZiYWMzYzI3NDkuanBlZ5GTBc0BHcyg" />Spowolnienie gospodarcze ogranicza rekrutacje nowych pracowników, jednak nie niesie ze sobą wzrostu bezrobocia - wskazał Sebastian Sajnóg z Polskiego Instytutu Ekonomicznego, komentując dane GUS. Zwrócił uwagę, że w lipcu wynagrodzenia rosły wolniej od inflacji, a zatrudnienie pozostaje stabilne.

## Niemcy nie zrealizują założeń NATO w kwestii wydatków na obronność. Eksperci wiedzą dlaczego
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281100,niemcy-nie-zrealizuja-zalozen-nato-w-kwestii-wydatkow-na-obronnosc-ek.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9281100,niemcy-nie-zrealizuja-zalozen-nato-w-kwestii-wydatkow-na-obronnosc-ek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T11:11:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wOJktkuTURBXy9jZDhmZTlmNS1mMzNkLTQ4NGUtOWMzOS1jMzQ2YTgwNGIyMmUuanBlZ5GTBc0BHcyg" />Współprzewodniczący SPD Lars Klingbeil uważa, że Niemcy są w stanie osiągnąć wyznaczony przez NATO cel wydatków rocznych na obronność wynoszący 2 proc. PKB. Jednak z obliczeń ekspertów wyłania się inny obraz i do spełnienia celu brakuje od kilku do kilkunastu miliardów euro – pisze w poniedziałek portal ZDF.

## Kolejna odsłona konfliktu Chiny - Tajwan. Tym razem ofiarą politycznych decyzji Pekinu jest import... mango
 - [https://forsal.pl/swiat/chiny/artykuly/9281095,kolejna-odslona-konfliktu-chiny-tajwan-tym-razem-ofiara-politycznyc.html](https://forsal.pl/swiat/chiny/artykuly/9281095,kolejna-odslona-konfliktu-chiny-tajwan-tym-razem-ofiara-politycznyc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T10:54:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rWfktkuTURBXy81Mzk5ZjViOC04MGQ3LTQ3ZmUtODM5Ny00Y2RjMzc5MGMzMDMuanBlZ5GTBc0BHcyg" />Pekin zawiesił w poniedziałek import mango z Tajwanu – poinformował oficjalny dziennik Komunistycznej Partii Chin &quot;Renmin Ribao&quot;. Powodem decyzji jest wykrycie pestycydów. Władze Tajwanu potępiły decyzję, twierdząc, że jest ona motywowana politycznie.

## "FT": BRICS ma być rywalem G7? Chiny chcą poszerzyć listę państw bloku
 - [https://forsal.pl/swiat/artykuly/9281094,ft-brics-ma-byc-rywalem-g7-chiny-chca-poszerzyc-liste-panstw-bloku.html](https://forsal.pl/swiat/artykuly/9281094,ft-brics-ma-byc-rywalem-g7-chiny-chca-poszerzyc-liste-panstw-bloku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T10:52:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SKkktkuTURBXy85NWNiMDkyMC03YmZiLTQxZmMtOTEzNy1iZjllMjdhZWM0YzIuanBlZ5GTBc0BHcyg" />Chiny naciskają na rozszerzenie bloku BRICS (Brazylia, Rosja, Indie, Chiny, RPA) o kolejne państwa, aby stał się on pełnowymiarowym rywalem dla grupy G7, choć pomysłowi temu sprzeciwiają się Indie - pisze w poniedziałek &quot;Financial Times&quot;.

## Kolejna odsłona konfliktu Chiny - Tajwan. Tym razem ofiarą politycznych decyzji Pekinu jest import... mango
 - [https://forsal.pl/swiat/chiny/artykuly/9281084,kolejna-odslona-konfliktu-chiny-tajwan-tym-razem-ofiara-politycznyc.html](https://forsal.pl/swiat/chiny/artykuly/9281084,kolejna-odslona-konfliktu-chiny-tajwan-tym-razem-ofiara-politycznyc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T10:40:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rWfktkuTURBXy81Mzk5ZjViOC04MGQ3LTQ3ZmUtODM5Ny00Y2RjMzc5MGMzMDMuanBlZ5GTBc0BHcyg" />Pekin zawiesił w poniedziałek import mango z Tajwanu – poinformował oficjalny dziennik Komunistycznej Partii Chin &quot;Renmin Ribao&quot;. Powodem decyzji jest wykrycie pestycydów. Władze Tajwanu potępiły decyzję, twierdząc, że jest ona motywowana politycznie.

## PIE: Nadchodzi trudny czas dla produkcji przemysłowej
 - [https://forsal.pl/biznes/przemysl/artykuly/9281070,pie-nadchodzi-trudny-czas-dla-produkcji-przemyslowej.html](https://forsal.pl/biznes/przemysl/artykuly/9281070,pie-nadchodzi-trudny-czas-dla-produkcji-przemyslowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T10:21:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HMDktkuTURBXy9kYTRkY2YyNi04MGQ1LTRlMWQtYTIxMC1hMjcwYzVhNWU5NzMuanBlZ5GTBc0BHcyg" />Kolejne miesiące przyniosą niewielką poprawę wyników w przemyśle; słabe wyniki to efekt pogarszającej się globalnie koniunktury - poinformowali analitycy Polskiego Instytutu Ekonomicznego komentując poniedziałkowe dane GUS. Zobaczymy dalsze hamownie inflacji bazowej w Polsce - dodali.

## Nie tylko Eris. Naukowcy znaleźli kolejny wariant koronawirusa atakującego ludzi
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9281030,nie-tylko-eris-naukowcy-znalezli-kolejny-wariant-koronawirusa-atakuja.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9281030,nie-tylko-eris-naukowcy-znalezli-kolejny-wariant-koronawirusa-atakuja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T09:44:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kGrktkuTURBXy8zOTU5YjFjOC0wY2MyLTRhZWEtYWIzNC0yM2MxMTY2NjA2MWQuanBlZ5GTBc0BHcyg" />Brytyjscy specjaliści opublikowali pierwsze wyniki badań dotyczących nowego wariantu koronawirusa o nazwie Pirola, wykrytego ostatnio na trzech kontynentach - w Europie, USA i Izraelu.

## Żniwa 2023: Rolnicy zabrali zboża z ponad 70 proc. areału upraw
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9281022,zniwa-2023-rolnicy-zabrali-zboza-z-ponad-70-proc-arealu-upraw.html](https://forsal.pl/biznes/rolnictwo/artykuly/9281022,zniwa-2023-rolnicy-zabrali-zboza-z-ponad-70-proc-arealu-upraw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T09:34:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1HektkuTURBXy85NWQ4NDVkYy0xY2UyLTRkNGQtOTJhZS01ZDIwOGYyN2ZlYWMuanBlZ5GTBc0BHcyg" />W skali kraju zboża zebrano z ponad 70 proc. areału upraw – przekazała Izba Zbożowo-Paszowa w newsletterze. Jak zaznaczono, obfite opady deszczu i upalna pogoda sprzyjały szybkiemu powstawaniu chorób grzybowych. Dodano, że rosną ceny pszenicy o parametrach konsumpcyjnych.

## Urlop dłuższy niż 2 tygodnie i inne sposoby Polaków na uniknięcie wypalenia zawodowego
 - [https://forsal.pl/praca/kariera/artykuly/9280992,urlop-dluzszy-niz-2-tygodnie-i-inne-sposoby-polakow-na-unikniecie-wypa.html](https://forsal.pl/praca/kariera/artykuly/9280992,urlop-dluzszy-niz-2-tygodnie-i-inne-sposoby-polakow-na-unikniecie-wypa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T09:02:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8-zktkuTURBXy9lMWE4MzZkMC01Y2QxLTQyZDItYTdkNy0wNmVmZjIyOThlZjUuanBlZ5GTBc0BHcyg" />Potrzebę zrobienia sobie przerwy w pracy dłuższej niż dwa tygodnie odczuwa 27 proc. pracowników - wynika z opublikowanego w poniedziałek badania Pracuj.pl.

## Fala bankructw przedsiębiorstw w UE. Tak źle nie było od 2015 roku
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9280962,fala-bankructw-przedsiebiorstw-w-ue-tak-zle-nie-bylo-od-2015-roku.html](https://forsal.pl/swiat/unia-europejska/artykuly/9280962,fala-bankructw-przedsiebiorstw-w-ue-tak-zle-nie-bylo-od-2015-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T08:36:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jfOktkuTURBXy9jMTgyYmNhYy1lZTI3LTQzNmQtOWY2My1hMzE0NjE1M2NiOTUuanBlZ5GTBc0BHcyg" />Szósty kwartał z rzędu w 2023 roku wzrosła liczba wniosków o upadłość unijnych przedsiębiorstw. W porównaniu z poprzednim kwartałem liczba upadłości wzrosła o 8,4 proc. i tym samym osiągnęła najwyższy poziom od rozpoczęcia zbierania danych w 2015 roku – podał Eurostat.

## Wyraźny wzrost płac w lipcu. Znamy powód
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/9280953,wyrazny-wzrost-plac-w-lipcu-znamy-powod.html](https://forsal.pl/praca/wynagrodzenia/artykuly/9280953,wyrazny-wzrost-plac-w-lipcu-znamy-powod.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T08:30:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ME9ktkuTURBXy8yYmIzOTU1MS1lODkzLTQ0NWUtYjYyMS1mYTg3NzVlMDUzYzcuanBlZ5GTBc0BHcyg" />undefined

## Zmiany w wartości produkcji sprzedanej w lipcu w ujęciu rdr. GUS podał najnowsze dane
 - [https://forsal.pl/biznes/przemysl/artykuly/9280949,zmiany-w-wartosci-produkcji-sprzedanej-w-lipcu-w-ujeciu-rdr-gus-podal.html](https://forsal.pl/biznes/przemysl/artykuly/9280949,zmiany-w-wartosci-produkcji-sprzedanej-w-lipcu-w-ujeciu-rdr-gus-podal.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T08:25:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h4dktkuTURBXy9lN2Q1ZTAwOC1kNjk4LTRlMjctYmZhZC1hMDBlMjQ2Yzc5OGUuanBlZ5GTBc0BHcyg" />Produkcja sprzedana przedsiębiorstw przemysłowych spadła o 2,7 proc. r/r w lipcu 2023 r., poinformował Główny Urząd Statystyczny (GUS). W ujęciu miesięcznym odnotowano spadek o 8,5 proc.

## Ceny produkcji sprzedanej przemysłu w lipcu spadły. Wiemy o ile
 - [https://forsal.pl/biznes/przemysl/artykuly/9280944,ceny-produkcji-sprzedanej-przemyslu-w-lipcu-spadly-wiemy-o-ile.html](https://forsal.pl/biznes/przemysl/artykuly/9280944,ceny-produkcji-sprzedanej-przemyslu-w-lipcu-spadly-wiemy-o-ile.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T08:18:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ze7ktkuTURBXy9mYTY4NzgxNC1hMDQ3LTRiNzgtYTZmZS1jMmQ0ZDQyMzczZDQuanBlZ5GTBc0BHcyg" />undefined

## W większości branż produkcja przemysłowa w lipcu spadła w ujęciu rdr
 - [https://forsal.pl/biznes/przemysl/artykuly/9280940,w-wiekszosci-branz-produkcja-przemyslowa-w-lipcu-spadla-w-ujeciu-rdr.html](https://forsal.pl/biznes/przemysl/artykuly/9280940,w-wiekszosci-branz-produkcja-przemyslowa-w-lipcu-spadla-w-ujeciu-rdr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T08:12:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gbCktkuTURBXy8zYjhkNTA4OS02YTVjLTQ5OTItYjcxNC1jMDdlODcyN2Q1YmUuanBlZ5GTBc0BHcyg" />undefined

## Blitzkrieg zawiódł. Przedłużająca się wojna w Ukrainie zmusza Rosję do stworzenia nowej armii
 - [https://forsal.pl/swiat/rosja/artykuly/9280929,blitzkrieg-zawiodl-przedluzajaca-sie-wojna-w-ukrainie-zmusza-rosje-do.html](https://forsal.pl/swiat/rosja/artykuly/9280929,blitzkrieg-zawiodl-przedluzajaca-sie-wojna-w-ukrainie-zmusza-rosje-do.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:59:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4HBktkuTURBXy83ZTVhZWVlYS0yZGJhLTQyMTEtOTYzZC03ODAxYjQ5MzA3ZDYuanBlZ5GTBc0BHcyg" />Wobec przedłużającej się wojny na Ukrainie Rosja rozbudowuje swoje struktury wojskowe i bardzo prawdopodobne jest utworzenie nowej formacji - 18. Armii Ogólnowojskowej - przekazało w poniedziałek brytyjskie ministerstwo obrony.

## Rosyjska marynarka wojenna zamieniła port w Mariupolu w swoją bazę
 - [https://forsal.pl/swiat/ukraina/artykuly/9280922,rosyjska-marynarka-wojenna-zamienila-port-w-mariupolu-w-swoja-baze.html](https://forsal.pl/swiat/ukraina/artykuly/9280922,rosyjska-marynarka-wojenna-zamienila-port-w-mariupolu-w-swoja-baze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:49:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/x-KktkuTURBXy9hYjQ5ZTk3NS1kM2MxLTRkMGYtOTkzMS1lMTc2NDEwOGFkMTMuanBlZ5GTBc0BHcyg" />W niedzielę do portu w zniszczonym i okupowanym przez Rosjan Mariupolu nad Morzem Azowskim po raz pierwszy wpłynął okręt wojenny wroga; można zatem oficjalnie przyznać, że w tym mieście utworzono bazę rosyjskiej floty - oznajmił w poniedziałek lojalny wobec Kijowa doradca mera Mariupola Petro Andriuszczenko.

## Przychody Asbisu wzrosły szacunkowo o ok. 10 proc. r/r do ok. 222 mln USD w lipcu
 - [https://forsal.pl/finanse/gielda/artykuly/9280910,przychody-asbisu-wzrosly-szacunkowo-o-ok-10-proc-rr-do-ok-222-mln.html](https://forsal.pl/finanse/gielda/artykuly/9280910,przychody-asbisu-wzrosly-szacunkowo-o-ok-10-proc-rr-do-ok-222-mln.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:25:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Cognor oczekuje wyniku EBITDA za III kw. zbliżonego do 54 mln zł odnotowanych w II kw.
 - [https://forsal.pl/finanse/gielda/artykuly/9280908,cognor-oczekuje-wyniku-ebitda-za-iii-kw-zblizonego-do-54-mln-zl-odnot.html](https://forsal.pl/finanse/gielda/artykuly/9280908,cognor-oczekuje-wyniku-ebitda-za-iii-kw-zblizonego-do-54-mln-zl-odnot.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:22:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fBMktkuTURBXy81ZTVlNDFlNy1hMzE1LTRlMGMtYmRjZS02NDlhZGZmZTk3NWIuanBlZ5GTBc0BHcyg" />undefined

## Cognor miał 23,72 mln zł zysku netto, 54,04 mln zł zysku EBITDA w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9280907,cognor-mial-2372-mln-zl-zysku-netto-5404-mln-zl-zysku-ebitda-w-ii-k.html](https://forsal.pl/finanse/gielda/artykuly/9280907,cognor-mial-2372-mln-zl-zysku-netto-5404-mln-zl-zysku-ebitda-w-ii-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:20:31+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hTdktkuTURBXy9mYWYxOTM2ZC0zMmI0LTRiYWEtYTFlYS1iN2ZiYTMxZmM3ODIuanBlZ5GTBc0BHcyg" />undefined

## Energa miała szac. 147 mln zł straty netto, 276 mln zł zysku EBITDA w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9280902,energa-miala-szac-147-mln-zl-straty-netto-276-mln-zl-zysku-ebitda-w.html](https://forsal.pl/finanse/gielda/artykuly/9280902,energa-miala-szac-147-mln-zl-straty-netto-276-mln-zl-zysku-ebitda-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:16:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y7BktkuTURBXy85ZmZhNmFiNC01NTMwLTQxOTAtOTk2ZC0yZDgyOWMzM2FlZWIuanBlZ5GTBc0BHcyg" />undefined

## Akcjonariusze Livechat zdecydowali o łącznie 5,95 zł dywidendy na akcję
 - [https://forsal.pl/finanse/gielda/artykuly/9280887,akcjonariusze-livechat-zdecydowali-o-lacznie-595-zl-dywidendy-na-akcj.html](https://forsal.pl/finanse/gielda/artykuly/9280887,akcjonariusze-livechat-zdecydowali-o-lacznie-595-zl-dywidendy-na-akcj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:11:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Kaczyński o 14. emeryturze: W tym roku wyniesie ona 2,2 tys. zł netto
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9280879,kaczynski-o-14-emeryturze-w-tym-roku-wyniesie-ona-22-tys-zl-netto.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9280879,kaczynski-o-14-emeryturze-w-tym-roku-wyniesie-ona-22-tys-zl-netto.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T07:04:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IttktkuTURBXy9lOGVlNjEzYS01NzE1LTQ0YWQtODI3Ny05YzBiN2Q5NmE1YmMuanBlZ5GTBc0BHcyg" />undefined

## Zmiany na rynku miedzi
 - [https://forsal.pl/finanse/notowania/artykuly/9280873,zmiany-na-rynku-miedzi.html](https://forsal.pl/finanse/notowania/artykuly/9280873,zmiany-na-rynku-miedzi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:57:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fFaktkuTURBXy9iM2U1MjFhMy0wNzk3LTRjMWMtODU3OS1hMGE2NzcyM2NhOWMuanBlZ5GTBc0BHcyg" />Ceny miedzi na giełdzie metali LME w Londynie idą w górę Metal na LME zyskuje 0,5 proc. wobec 8.240,00 USD za tonę, notowanych na zakończenie poprzedniej sesji - podają maklerzy.

## Jones: Niemcy są podatne na rosyjską infiltrację. Problemem jest biurokratyczny nadzór nad specsłużbami
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9280867,jones-niemcy-sa-podatne-na-rosyjska-infiltracje-problemem-jest-biuro.html](https://forsal.pl/swiat/unia-europejska/artykuly/9280867,jones-niemcy-sa-podatne-na-rosyjska-infiltracje-problemem-jest-biuro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:53:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/oPoktkuTURBXy9kMmNjMmZiNS1lZmI4LTQ2ZTQtYjc5NS1iZjY2MWJlZTM0NDEuanBlZ5GTBc0BHcyg" />Niemiecka nieufność wobec własnych agencji szpiegowskich, co jest spuścizną nazistowskiej dyktatury, powoduje, że Niemcy są wyjątkowo podatne na rosyjską infiltrację - pisze w najnowszym numerze brytyjskiego tygodnika &quot;The Spectator&quot; Nigel Jones, historyk i dziennikarz.

## ISW: Ukraińskie ataki na tyły Rosjan wywołują krytykę pod adresem rosyjskiego dowództwa
 - [https://forsal.pl/swiat/ukraina/artykuly/9280862,isw-ukrainskie-ataki-na-tyly-rosjan-wywoluja-krytyke-pod-adresem-rosy.html](https://forsal.pl/swiat/ukraina/artykuly/9280862,isw-ukrainskie-ataki-na-tyly-rosjan-wywoluja-krytyke-pod-adresem-rosy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:49:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vFektkuTURBXy83NDU4N2JmZC0zNmIyLTQ3MTEtOTU5Mi01OWQ2MTZmNzE5OWIuanBlZ5GTBc0BHcyg" />Ukraińskie ataki na tyły Rosjan wywołują niezadowolenie w rosyjskiej przestrzeni informacyjnej i krytykę pod adresem rosyjskiego dowództwa - pisze w najnowszej analizie amerykański Instytut Studiów nad Wojną (ISW). Jak dodaje, zapewne taki właśnie jest cel strony ukraińskiej.

## PFR: Tempo wzrostu cen spada w całej Unii Europejskiej dziewiąty miesiąc z rzędu
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9280861,pfr-tempo-wzrostu-cen-spada-w-calej-unii-europejskiej-dziewiaty-miesi.html](https://forsal.pl/gospodarka/inflacja/artykuly/9280861,pfr-tempo-wzrostu-cen-spada-w-calej-unii-europejskiej-dziewiaty-miesi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:47:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IwOktkuTURBXy9kNjlmMzQ0MS1iZDQyLTRkNjgtYjBhOS04MWZjYmFmOWU5YTkuanBlZ5GTBc0BHcyg" />Lipiec był dziewiątym z rzędu miesiącem, w którym odnotowano spowolnienie wzrostu cen w UE. W Polsce inflacja HICP wyhamowała do 10,3 proc. z 11,0 proc. miesiąc wcześniej – podał PFR w udostępnionym PAP raporcie.

## Mieszkańcy Kijowa już przygotowują się do kolejnej ciężkiej zimy w czasie wojny
 - [https://forsal.pl/swiat/ukraina/artykuly/9280811,mieszkancy-kijowa-juz-przygotowuja-sie-do-kolejnej-ciezkiej-zimy-w-cza.html](https://forsal.pl/swiat/ukraina/artykuly/9280811,mieszkancy-kijowa-juz-przygotowuja-sie-do-kolejnej-ciezkiej-zimy-w-cza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:44:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KF-ktkuTURBXy8wZTc5ZjUzMy1iZjBkLTQ1ZDYtYjMxNy01ZDkzMjFlMmE5ZGIuanBlZ5GTBc0BHcyg" />Od dwóch tygodni upały w Kijowie uniemożliwiają wielu mieszkańcom ukraińskiej stolicy normalny sen, który i tak dodatkowo jest przerywany częstymi alarmami przeciwlotniczymi. Jednak mimo wysokich temperatur kijowianie myślą już o tym, jak będą ogrzewać mieszkania za kilka miesięcy w warunkach rosyjskiej inwazji.

## Chińskie firmy pomagają Rosji obchodzić sankcje. Chodzi o dziesiątki tysięcy przesyłek
 - [https://forsal.pl/swiat/rosja/artykuly/9280777,chinskie-firmy-pomagaja-rosji-obchodzic-sankcje-chodzi-o-dziesiatki-t.html](https://forsal.pl/swiat/rosja/artykuly/9280777,chinskie-firmy-pomagaja-rosji-obchodzic-sankcje-chodzi-o-dziesiatki-t.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:36:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/X8_ktkuTURBXy9jOTY1NWY4MS0yMmZlLTQ4N2ItYmM4Ny1hOTk2OWY4NzhhMzkuanBlZ5GTBc0BHcyg" />Chiny pomagają zaopatrywać Rosję w helikoptery, drony, celowniki optyczne i kluczowe metale wykorzystywane przez przemysł obronny. Od początku wojny rosyjskie firmy otrzymały z Chin dziesiątki tysięcy przesyłek - wynika z ustaleń brytyjskiego &quot;Sunday Telegraph&quot;.

## Ruch na rynku ropy naftowej
 - [https://forsal.pl/finanse/notowania/artykuly/9280770,ruch-na-rynku-ropy-naftowej.html](https://forsal.pl/finanse/notowania/artykuly/9280770,ruch-na-rynku-ropy-naftowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:32:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h59ktkuTURBXy82MDM4NzRjNi0xMWM3LTQ5ZGUtODZkZC05MDI0OWVkOWJhNjIuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 8 notowania ropy Brent na giełdzie w Londynie rosły o 0,55 proc., do 85,27 dol. za baryłkę. Spadały natomiast notowania amerykańskiej ropy WTI na giełdzie w Nowym Jorku - o 0,17 proc., do 81,11 dol. za baryłkę.

## Kursy walut: Złoty umocnił się względem euro i franka. Stracił wobec dolara
 - [https://forsal.pl/finanse/waluty/artykuly/9280769,kursy-walut-zloty-umocnil-sie-wzgledem-euro-i-franka-stracil-wobec-d.html](https://forsal.pl/finanse/waluty/artykuly/9280769,kursy-walut-zloty-umocnil-sie-wzgledem-euro-i-franka-stracil-wobec-d.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:30:34+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/17sktkuTURBXy9hNmY4MGYzNC1kNDlhLTQwNmUtYTk4My1jZjJjYzUxYjA1NmEuanBlZ5GTBc0BHcyg" />W poniedziałek rano polska waluta zyskiwała na wartości wobec euro i franka szwajcarskiego, a traciła względem dolara amerykańskiego. Euro kosztowało ok. 4,47 zł, dolar blisko 4,10 zł, a frank szwajcarski - 4,67 zł.

## W drugiej turze wyborów prezydenckich w Ekwadorze faworytką jest lewicowa kandydatka Luisa Gonzalez
 - [https://forsal.pl/gospodarka/polityka/artykuly/9280760,w-drugiej-turze-wyborow-prezydenckich-w-ekwadorze-faworytka-jest-lewic.html](https://forsal.pl/gospodarka/polityka/artykuly/9280760,w-drugiej-turze-wyborow-prezydenckich-w-ekwadorze-faworytka-jest-lewic.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:26:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K3ektkuTURBXy80ZGMzODJiZi0yMWNjLTQ5ZTgtYmE2OC0wN2UwN2FjYjg2ZjYuanBlZ5GTBc0BHcyg" />Lewicowa kandydatka Luisa Gonzalez, która uzyskała 33 proc. głosów i przedstawiciel bogatej ekwadorskiej rodziny Daniel Noboa, na którego w niedzielę głos oddało 24 proc. uprawnionych obywateli zmierzą się w drugiej turze wyborów prezydenckich w Ekwadorze, zaplanowanej na 15 października.

## Paraliż moskiewskich lotnisk. Po kilku godzinach wznowiono rejsy
 - [https://forsal.pl/swiat/rosja/artykuly/9280749,paraliz-moskiewskich-lotnisk-po-kilku-godzinach-wznowiono-rejsy.html](https://forsal.pl/swiat/rosja/artykuly/9280749,paraliz-moskiewskich-lotnisk-po-kilku-godzinach-wznowiono-rejsy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T06:08:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/St1ktkuTURBXy9mY2VkNjRjZC1jZjA5LTQ4NTQtYmVkNi0yMTM2NTg2YjNmODQuanBlZ5GTBc0BHcyg" />W Moskwie w poniedziałek na lotnisku Domodiedowo czasowo ograniczono przyloty i odloty, a inny port lotniczy w rosyjskiej stolicy - Wnukowo całkiem zawiesił loty - podała agencja Reutera. Później rejsy wznowiono.

## Wojna o zboże z udziałem Polski. Kijów naciska na Warszawę
 - [https://forsal.pl/swiat/artykuly/9280740,wojna-o-zboze-z-udzialem-polski-kijow-naciska-na-warszawe.html](https://forsal.pl/swiat/artykuly/9280740,wojna-o-zboze-z-udzialem-polski-kijow-naciska-na-warszawe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T05:45:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1JPktkuTURBXy9mMTBmZTc1Ni0yZmZlLTRjMWYtYjFmNC0xNGRkNDY4NmE1MmUuanBlZ5GTBc0BHcyg" />Sojusznicy Kijowa pracują nad wzmocnieniem transportu towarów przez Dunaj. Władze kraju nie rezygnują jednak z Morza Czarnego i nacisków na Polskę w sprawie odblokowania rynków środkowoeuropejskich

## Za późno na szybkie wynurzenie polskiej Marynarki Wojennej
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9280737,za-pozno-na-szybkie-wynurzenie-polskiej-marynarki-wojennej.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9280737,za-pozno-na-szybkie-wynurzenie-polskiej-marynarki-wojennej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T05:35:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hqwktkuTURBXy9lYzQ5MDkyZC0yMTUxLTQ0NTMtODM1MS0xYWVlYzUwM2IzZjMuanBlZ5GTBc0BHcyg" />Jesteśmy w Gdyni i jesteśmy świadkami kolejnego etapu wzmacniania polskiej Marynarki Wojennej. Fregaty, 3 fregaty w programie Miecznik będą stanowiły nową jakość w polskiej Marynarce Wojennej. Będą silnie uzbrojone, zarówno jeżeli chodzi o broń ofensywną, jak i jeśli chodzi o broń przeciwlotniczą – mówił w środę, dzień po wielkiej defiladzie minister obrony Mariusz Błaszczak, podczas „palenia blach” dla pierwszego okrętu tego typu.

## Rynek nieruchomości pogrąża chińską gospodarkę
 - [https://forsal.pl/swiat/chiny/artykuly/9280734,rynek-nieruchomosci-pograza-chinska-gospodarke.html](https://forsal.pl/swiat/chiny/artykuly/9280734,rynek-nieruchomosci-pograza-chinska-gospodarke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T05:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/27uktkuTURBXy82ZGIzZjg3Ny1lMDU3LTQ3MTgtYmRkMy1hN2IxYzE4M2YzNGMuanBlZ5GTBc0BHcyg" />Zadłużenie deweloperów to kolejny problem dla władz Państwa Środka. Mierzą się już z deflacją i rekordowym bezrobociem wśród młodych

## Które kraje zużywają najwięcej ropy? Dwóch wielkich liderów [RANKING]
 - [https://forsal.pl/biznes/przemysl/artykuly/9277385,ktore-kraje-zuzywaja-najwiecej-ropy-dwoch-wielkich-liderow-ranking.html](https://forsal.pl/biznes/przemysl/artykuly/9277385,ktore-kraje-zuzywaja-najwiecej-ropy-dwoch-wielkich-liderow-ranking.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T04:00:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/14QktkuTURBXy81ZTgzNTc4Mi1kYzQ5LTQ1OWQtYjM2ZS03YTM3ZWY0NjY0ZmEuanBlZ5GTBc0BHcyg" />Nawet przy stałym wzroście udziału odnawialnych źródeł energii w produkcji energii elektrycznej w ostatnich latach, ropa naftowa nadal pozostaje najważniejszym źródłem energii na świecie. Oto kraje, które zużywają najwięcej tego surowca.

## Afryka Zachodnia nie ma co jeść. Liczba głodujących wzrosła w kilka lat ponad czterokrotnie
 - [https://forsal.pl/swiat/artykuly/9277335,afryka-zachodnia-nie-ma-co-jesc-liczba-glodujacych-wzrosla-w-kilka-la.html](https://forsal.pl/swiat/artykuly/9277335,afryka-zachodnia-nie-ma-co-jesc-liczba-glodujacych-wzrosla-w-kilka-la.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T04:00:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/F9NktkuTURBXy9lY2NiNWM1YS0yZWI2LTQ3OGItOWRmNi0zOTU2NGU2OTkzODYuanBlZ5GTBc0BHcyg" />Niestabilna sytuacja w regionie, w tym walki w Nigerii z dżihadystami oraz wojskowe zamachy stanu w Burkina Faso, a obecnie w Nigrze, sprawiły, że od 2019 r. liczba mieszkańców Afryki Zachodniej cierpiących z powodu ostrego głodu wzrosła czterokrotnie.

## Marzenie o pierwszej sieci kolei wodorowej umarło szybką śmiercią. Niemcy wycofują się z projektu
 - [https://forsal.pl/transport/artykuly/9276420,marzenie-o-pierwszej-sieci-kolei-wodorowej-umarlo-szybka-smiercia-nie.html](https://forsal.pl/transport/artykuly/9276420,marzenie-o-pierwszej-sieci-kolei-wodorowej-umarlo-szybka-smiercia-nie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T04:00:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YbgktkuTURBXy9mNjg3MTg1Ny1mYjAyLTQyYzEtOGU3ZS1jOWM3NWIzNzE1NjguanBlZ5GTBc0BHcyg" />Rząd niemieckiej Dolnej Saksonii, która jako pierwsza zaczęła komercyjnie użytkować 14 pociągów wodorowych, zmienia zdanie ws. technologii i stawia na całkowicie elektryczną przyszłość — podał portal Quartz.

## Problemy mięsnego giganta. Tyson Foods traci na wartości i zamyka kolejne fabryki
 - [https://forsal.pl/biznes/ekologia/artykuly/9277449,problemy-miesnego-giganta-tyson-foods-traci-na-wartosci-i-zamyka-kole.html](https://forsal.pl/biznes/ekologia/artykuly/9277449,problemy-miesnego-giganta-tyson-foods-traci-na-wartosci-i-zamyka-kole.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-08-21T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pxQktkuTURBXy80MDJiODZmOC0zZDVlLTQwMDUtODU2My01YWE3ODRjNmI3YzMuanBlZ5GTBc0BHcyg" />Jeszcze w 2015 roku Tyson Foods znalazł się na 311 miejscu w rankingu Global 500 magazynu „Fortune”. Niewątpliwie mięsny gigant to ogromne przedsiębiorstwo, generujące wielkie dochody swoim właścicielom. Ostatnio jednak zebrały się nad nim czarne chmury – funkcjonująca od 1935 roku amerykańska firma na początku tego roku odnotowała spadek swojej wartości o 16 proc.

