# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## "Get her!": Woman brings traffic to a halt starting a fight, then tries running away before eating pavement
 - [https://www.louderwithcrowder.com/traffic-women-fighting-pavement](https://www.louderwithcrowder.com/traffic-women-fighting-pavement)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T23:06:00+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=30816515&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C119" /><br /><br /><p>As someone who works from home, I miss out on the <a href="https://www.louderwithcrowder.com/blocking-traffic-italy" target="_blank">morning commute</a>. The most excitement from my commute to my office is a hungry cat screaming at me while I try to make coffee and prepare for another day of Facebook-throttling content. So, I miss out on <a href="https://www.louderwithcrowder.com/gun-man-traffic-light" target="_blank">things like this</a>: freeway traffic being brought to a standstill over two women getting into fisticuffs.</p><p>And that's before the footrace starts.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/FightHaven/status/1693759890131386628"></a>
</blockquote>

<p>You know the deal. It's a viral video, allow for missing context and whatnot. The context I'm most curious about is how this fight started. Because it takes place in the middle of a freeway, and shawty with the shorty-shorts doesn't look like someone who was driving. Unless her man was driving, only he's beta and, after cutting someone off, sat in the car while his girlfriend did all the work. </p><p>Either that, or the one in white is the "other woman" and picked an awkward time to confront her boyfriend's wife. And how did she know they would be driving down the freeway at that moment and manage to run into the middle of traffic? These are the questions we need answered.</p><p>I feel bad for the one in white because we've all been there. You pick a fight with someone more significant than you, and then the moment of clarity smacks you upside the head that... I just picked a fight with someone bigger than me. Fight or flight. She chose flight. Until she found herself eating pavement. Hey, it happens.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

## Oliver Anthony's success gets even more insane as he becomes the first artist EVER to do this on the Billboard charts
 - [https://www.louderwithcrowder.com/oliver-anthony-debuts-at-1-on-billboard-hot-100](https://www.louderwithcrowder.com/oliver-anthony-debuts-at-1-on-billboard-hot-100)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T20:34:29+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34990402&amp;width=2000&amp;height=1500&amp;coordinates=141%2C0%2C179%2C0" /><br /><br /><p>You love to see any artist disrupt the establishment. The disruption Oliver Anthony caused with "Rich Men South of Richmond" has been, in a good way, batsh*t insane. And it keeps going as Anthony's song debuted on the Billboard Hot 100 chart.</p><p>Scratch that. It debuted AT NUMBER ONE on the Billboard Hot 100 chart. He was <a href="https://www.whiskeyriff.com/2023/08/21/oliver-anthony-becomes-the-first-artist-to-debut-at-1-on-the-billboard-hot-100-with-rich-men-north-of-richmond/" target="_blank">only at a few thousand views on TikTok just a couple of weeks ago</a>. Now he has the number one song in America.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/PopBase/status/1693681047308038232"></a>
</blockquote>

<p>Shout out to Luke Combs and Morgan Wallen <a href="https://www.louderwithcrowder.com/country-music-billboard-100" target="_blank">still holding down in the top three too</a>.</p><p>This is ludicrous. Think about how much money goes into recording and promoting Taylor Swift and Oliva Rodrigo. I'm not even knocking the artists, I dig both songs. But labels pay m-m-m-MILLIONS to get a single to the #1 spot.</p><p>Not only did Anthony becomes the first artist EVER to debut at #1, he was the first to do it not signed to a record label. He's a dude with a YouTube channel. It goes back to what I said in an earlier post. Stop bitching about the "woke" music industry. The music industry is you, your guitar, and your hustle. I don't even think Oliver Anthony knows the word "woke." Prior to opening a Twitter account for the first time last week, he was too busy touching grass in the real world.</p><p>And as much as I don't want to be the "how does the relate to politics" guy, we have an election coming up and the #1 song in America is a passionate rebuttal to Washington DC elites. Here's hoping it inspires more art in that same genre.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

## Rainn Wilson attempts feeble dunk on "Rich Men North of Richmond," gets annihilated with one tweet from a veteran
 - [https://www.louderwithcrowder.com/rainn-wilson-blasts-viral-hit](https://www.louderwithcrowder.com/rainn-wilson-blasts-viral-hit)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T18:07:28+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34983412&amp;width=1200&amp;height=800&amp;coordinates=40%2C0%2C160%2C0" /><br /><br /><p> <strong><a href="https://www.louderwithcrowder.com/2024-gop-candidates" target="_self"><em>VOTE IN THE LWC 2024 GOP STRAW POLL! CLICK HERE!</em></a></strong></p><p>Oh, Dwight. </p><p>Actor Rainn Wilson had been <a href="https://www.louderwithcrowder.com/rainn-wilson-anti-christian" target="_blank">poking his head</a> out and <a href="https://www.louderwithcrowder.com/rainn-wilson-tucker-carlson" target="_blank">sharing the occasional common sense thought</a> as of late. But when it comes to "Rich Men North of Richmond," Wilson's inner smug leftist douche could not be contained. Had HE wrote the song, it would have gone a little something like this: </p><p>"I wouldn't talk about obese people on welfare, I’d sing about CEOs who make 400 times their average workers' salary (up from 50 times 30 years ago) & corps that pay zero taxes & offshore tax shelters for billionaires."</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/rainnwilson/status/1693306691184709939"></a>
</blockquote>
<p>Economic illiteracy aside, his tweet can be summed up thusly:</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="78ded" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34983437&amp;width=980" />
</p><p>It could be that Dwight is having a hard time finding songs that he agrees with culturally or politically. He isn't alone on the Left. Having one song (two if you include "<a href="https://www.louderwithcrowder.com/jason-aldean-small-town-acoustic" target="_blank">Try That in A Small Town</a>") that <a href="https://www.louderwithcrowder.com/oliver-anthony-rap-remix" target="_blank">appeals to the middle class</a> go popular is too much for progressives to handle. It needs to be delegitimized and destroyed. Since singer-songwriter, Oliver Anthony doesn't have a social media they can troll to find a bad meme he liked, smugly dismissing his lyrics is the next logical step.</p><p>Though, as veteran Joey Jones SAVAGELY points out, you would think Rainn would have learned a thing or two acting as Dwight Schrute from <em>The Office</em>.</p><p>"But you didn’t write it. You played a parody character of a Pennsylvania farmer turned office worker. You did a fantastic job exploiting a very real simple/humble upbringing as well as the rat race of middle class white collar workers. You did such a good job making fun of their existence it made you a multimillionaire."</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/Johnny_Joey/status/1693618667970273538"></a>
</blockquote>
<p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/WynnDuffyOG/status/1693627259431576023"></a>
</blockquote>
<p>Jones' clap back (as the kids call it) to Rainn can be summarized thusly:</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="d7b70" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34983754&amp;width=980" />
</p><p>I could explain that Anthony wasn't attacking people on welfare. He was singing of the frustration of people who work hard and barely scrape by, and looking at the government seemed more concerned about the people who don't. Also when he sings "I've been sellin' my soul, workin' all day / Overtime hours for bullshit pay", there is an above-average chance his employer is one of them millionaires and billionaires that Rainn wishes the song was about. We know the rich men north of Richmond are all millionaires and billionaires.<br /></p><p>Rub some beet juice on it, Dwight. </p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

## Watch: Chuck Todd whines the GOP isn't attacking Trump, when he's a key reason why none of us are going to
 - [https://www.louderwithcrowder.com/chuck-todd-wants-republicans-to-attack-trump](https://www.louderwithcrowder.com/chuck-todd-wants-republicans-to-attack-trump)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T16:18:13+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34982290&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C2" /><br /><br /><p> <strong><a href="https://www.louderwithcrowder.com/2024-gop-candidates" target="_self"><em>VOTE IN THE LWC 2024 GOP STRAW POLL! CLICK HERE!</em></a></strong></p><p>
	Chuck Todd has a sad. No matter how many times Donald Trump gets indicted, he is still popular in the polls conducted by NBC News and Todd's other colleagues in the journalisming industries. A CBS News poll claims Trump voters trust him more than their family and friends. Chuckles says something needs to be done, and he knows who.</p><p>No, not the journalismers who suck at both their jobs and at life. Joe Biden and the GOP candidates. They are the ones who aren't attacking Trump more better enough, and if they don't start attacking harder our fraying democracy is literally </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/KevinTober94/status/1693270864639197445"></a>
</blockquote>
<p>
	We know why Joe Biden's handlers aren't telling him to attack Trump. They want him to be the nominee and are going to wait until then. And hope Biden can remember to speak and read when the time comes.</p><p>As for the GOP, there's a reason why none of us are launching full-on attacks against Trump. Because eat a dick. That's why.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="dc3ad" src="https://www.louderwithcrowder.com/media-library/image.gif?id=34982929&amp;width=980" />
</p><p>Plenty of us are criticizing Trump on policy. <a href="https://www.louderwithcrowder.com/donald-trump-backs-out-of-gop-primary-debate" target="_blank">There is a lot to criticize</a>. Chuck Todd and the media <a href="https://newsbusters.org/blogs/nb/rich-noyes/2023/08/21/tvs-distorted-gop-primary-race-three-fourths-trump-90-negative" target="_blank">don't give any airtime to that</a>. They don't care that Trump is being hit on turning the government over to Fauci or that he didn't drain the swamp. They want nothing but attacks about the indictments so that they can create indictment content and do the Democrats' jobs for them. That brings us to the next part.</p><p>Even Trump's harshest critics not employed by cable news or the Lincoln Project view it all as a political witchhunt. He's been <a href="https://www.louderwithcrowder.com/watch-todays-show-biden-bribery" target="_blank">indicted over paperwork</a>, <a href="https://www.louderwithcrowder.com/watch-todays-show-trump-indicted" target="_blank">alleged classified documents</a> when Democrats don't get indicted for the same, <a href="https://www.louderwithcrowder.com/donald-trump-j6-indictment" target="_blank">exercising his First Amendment rights</a> in the same way Democrats have in the past, and <a href="https://www.louderwithcrowder.com/georgia-witch-hunt-trump-innocent" target="_blank">questioning election results</a>... again how Democrats have in the past.</p><p>All of us on the Right knows it doesn't matter if it's Trump, Chris Christie, or Asa Hutchinson. It's just the new rules. These are the rules of engagement put forth by the Left and the media (but I repeat myself). No one with an (R-State) after their name is going to attack Trump because he's the current target of these new rules. We're going to wait until it's our time to exploit them.</p><p>Chuck Todd should be more concerned when the next poll comes out that labels journalism as the least trusted institution in America. Hint: Clips like this are a key reason why.</p><p>
	><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p>
</p>

## Watch: Do Blacks & Whites REALLY Hate Each Other?  (Black & White on the Grey Issues)
 - [https://www.louderwithcrowder.com/steven-crowder-black-white-grey](https://www.louderwithcrowder.com/steven-crowder-black-white-grey)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T14:12:36+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34982362&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>I hit the streets of Texas in a new segment called "Black & White on the Gray Issues." In this initial episode, we discussed: DEI training, the possibility of a race war, the media's role in the racial divide, affirmative action, what black people think about LGBTQ+, hate speech, and much more. Let us know what you think in the comments below & if you'd like to see more episodes like this.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Do Blacks & Whites REALLY Hate Each Other? | Black & White On The Gray Issues</small>
<small class="image-media media-photo-credit">
<a href="https://youtu.be/m7j9wy0_gT4" target="_blank">youtu.be</a>
</small>
</p>

## Watch: More embarrassing than this shoplifter getting dropped, he was caught stealing Bud Light
 - [https://www.louderwithcrowder.com/old-man-caught-stealing-bud-light-from-walgreens](https://www.louderwithcrowder.com/old-man-caught-stealing-bud-light-from-walgreens)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T13:08:47+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34982112&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Bud Light has been your favorite beer for decades and old habits die hard. I get it. <a href="https://www.louderwithcrowder.com/kid-rock-caught-drinking-bud-light-in-nashville" target="_blank">Just ask Kid Rock</a>. No one wants to be caught buying a Bud Light and having their friends sh*t on them for drinking TRANSmission fluid. But that's no reason to resort to a life of crime. A lesson one poor sap learned outside of a Walgreens somewhere in America.</p><p>In this man's defense, he may have read on the internets that Bud Light has grown so unpopular, <a href="https://www.louderwithcrowder.com/bud-light-costco" target="_blank">stores are practically giving it all away</a>. And he misunderstood the expression. "Practically" doesn't mean "literally." We need to allow for missing context in all viral videos. This could just be one giant misunderstanding. He also could have seen all the crime videos from Walgreens and thought it looked like fun.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="a5ff0" src="https://www.louderwithcrowder.com/media-library/image.png?id=34982158&amp;width=980" />
</p>
<p>An employee, who is past examples are any indication we guess <a href="https://www.louderwithcrowder.com/supermarket-employee-fired-filming-shoplifters" target="_blank">is currently no longer employed</a> by Walgreens, follow the man outside and dropped him. No one is stealing on his watch!</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="fad8c" src="https://www.louderwithcrowder.com/media-library/image.png?id=34982161&amp;width=980" />
</p>
<p>It was at this point that the employee realized, "Well f*ck, now I need to be seen carrying Bud Light." And quickly collected the stole merchandise before some snapped a photo. Little did he know someone was sitting in their car remembering to do it for the content.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="63794" src="https://www.louderwithcrowder.com/media-library/image.png?id=34982167&amp;width=980" />
</p>
<p>Here's the full video.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/LWCnewswire/status/1693574565975253175"></a>
</blockquote>

<p>This video ranks second in our favorite <a href="https://twitter.com/LWCnewswire/status/1693574565975253175" target="_blank">Bud Light Related Crimes</a>. #3 is a dude from Louisiana who also stole a few cases. <a href="https://www.louderwithcrowder.com/bud-light-thief" target="_blank">But he was only caught on security camera</a> and wasn't manhandled by an employee.</p><p>#1 remains this legend who got <a href="https://www.louderwithcrowder.com/bud-light-kansas-arrest" target="_blank">pulled over for drunk driving while still wearing his Bud Light costume</a> for work.</p><div class="rm-embed embed-media"></div><p>Remember kids. PRACTICALLY giving something away means while it is being sold dirt cheap, you still need to exchange currency. Don't be the man walking out of Walgreens stealing Bud Light. That's an embarrassment few can ever live down.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

## Watch: Rapper drops passionate fire remix of Oliver Anthony's "Rich Men North of Richmond"
 - [https://www.louderwithcrowder.com/oliver-anthony-rap-remix](https://www.louderwithcrowder.com/oliver-anthony-rap-remix)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T12:11:24+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=34981971&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C2" /><br /><br /><p>
	Oliver Anthony's viral hit "Rich Men South of Richmond" continues to inspire. And now it's crossing genres. An MC who is known on X as @TheMarineRapper was so moved by Anthony's song and universal lyrics, he put his own spin on it.</p><p>The boss has a video of our own dropping later today that echoes similar, but this song is a reminder that contrary to what the media wants you to believe, it's not black vs white. It's elitists vs everyone else. Or, the rich men north of Richmond vs the middle-class men south of it.</p><p>Also, and I can't stress this enough, there need to be more acoustic guitar/singer-songwriter samples in hip-hop.</p><p>Lyrics:</p><p>
	This is for the women who birthed our,<br />
Daughters and sons and they nurse our,<br />
All of our family while we are traveling,<br />
And trying to get our paychecks and work hard.<br />
</p><p>
I don’t know how much longer I can take this,<br />
Only looks like I got half of my paycheck,<br />
How can I explain this all to a baby,<br />
I know, I’ll read her this statement you gave me:,<br />
Dear Mr. Lott, Know you’ve been working daily ’round the clock,<br />
Gotta provide for the family you got,<br />
But you laid off,<br />
Sincerely, your boss,<br />
PS I’m sorry.<br />
</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/TheMarineRapper/status/1690883423382949888"></a>
</blockquote>
<p>
	Seeing how a passionate song can inspire another passionate song brings me to something I was thinking about over the weekend. John Rich (legit the reason I'm into country music) also does things on his own, and he dropped X about it.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/johnrich/status/1693252105560092953"></a>
</blockquote>
<p>This is why I hate when people say the "woke" music industry. The music industry is you, your guitar, and your hustle. Or in The Marine Rapper's case, his beat composer. It's a matter of naming your price. If you want billions of dollars and major stadium tours, then you may have to decide if not being allowed an opinion is a fair trade off. If you want to just make a living providing for your family by sharing music, f*ck the industry.</p><p>One of the best pieces of advice I've ever heard comes from Dave Chappelle's dad.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/brodigan/status/1693300316282692065"></a>
</blockquote>
<p>As Anthony says: "People in the music industry give me blank stares when I brush off 8 million dollar offers. I don't want 6 tour buses, 15 tractor trailers and a jet. I don't want to play stadium shows, I don't want to be in the spotlight. I wrote the music I wrote because I was suffering with mental health and depression. These songs have connected with millions of people on such a deep level because they're being sung by someone feeling the words in the very moment they were being sung. No editing, no agent, no bulls--t. Just some idiot and his guitar. The style of music that we should have never gotten away from in the first place."</p><p>Now we need to see Oliver Anthony and the Marine Rapper on stage together.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

## Donald Trump makes it official, he's refusing to appear before the voters and defend his record in a GOP primary debate
 - [https://www.louderwithcrowder.com/donald-trump-backs-out-of-gop-primary-debate](https://www.louderwithcrowder.com/donald-trump-backs-out-of-gop-primary-debate)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-08-21T11:19:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34979223&amp;width=1200&amp;height=800&amp;coordinates=105%2C0%2C95%2C0" /><br /><br /><p><em>The view expressed by writers are their own and do not necessarily represent the views of Louder with Crowder.</em></p><p>After dragging his feet and hinting about it on TruthSocial, Donald Trump has made it official and said he's refusing to show up to Wednesday's GOP Primary Debate. Not just that debate, but any debate this cycle.</p><p>Many people are saying Trump is too chicken to have his record challenged (not draining the swamp, not locking her up, turning his presidency over to Fauci, school lockdowns, small business lockdowns, the Trump schmaccine, blindly signing spending bills like the CARES Act which led to 2020's mail-in voting, a string of electoral defeats since 2016, etc.). I'm not saying that, but many people are. </p><p>According to the former president, even though the first votes aren't for five months, because he is ahead in public opinion polls -- many of which have been conducted by the corporate media -- <a href="https://redstate.com/bobhoge/2023/08/20/trump-touts-strong-poll-numbers-i-will-therefore-not-be-doing-the-debates-n2162847" target="_blank">he does not need to debate his opponents</a>. </p><blockquote>New CBS poll has me out by "legendary" numbers... I WILL THEREFORE NOT BE DOING THE DEBATES.</blockquote><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="6cd8a" src="https://www.louderwithcrowder.com/media-library/image.jpg?id=34979306&amp;width=980" />
</p><p>Trump's focus on and faith in CBS News is interesting. Prior to him swearing by their polling numbers, I was to believe CBS News was fake news:</p><p><a href="https://www.louderwithcrowder.com/report-cbs-news-aired-faked-covid-19-testing-site" rel="noopener noreferrer" target="_self" title="view post: REPORT: CBS News Aired Faked COVID-19 Testing Site">REPORT: CBS News Aired Faked COVID-19 Testing Site</a></p><p><a href="https://www.louderwithcrowder.com/cbs-news-encourages-people-to-snitch-on-the-ice-cream-man-for-not-social-distancing" rel="noopener noreferrer" target="_self" title="view post: CBS News Encourages People to Snitch on the Ice Cream Man">CBS News Encourages People to Snitch on the Ice Cream Man</a></p><p><a href="https://www.louderwithcrowder.com/ymca-locker-room-speaks-out" rel="noopener noreferrer" target="_self" title="view post: 'She says she's a woman!' CBS News desperately tries to defend transwoman in YMCA locker room">'She says she's a woman!' CBS News desperately tries to defend transwoman in YMCA locker room</a></p><p><a href="https://www.louderwithcrowder.com/ted-cruz-60-minutes-australia" rel="noopener noreferrer" target="_self" title="view post: Ted Cruz Calls Out CBS News for Showing an Anti-Biden Story in Australia that They Didn't Show in America">Ted Cruz Calls Out CBS News for Showing an Anti-Biden Story in Australia that They Didn't Show in America</a></p><p><a href="https://www.louderwithcrowder.com/cbs-deletes-fact-check-on-donald-trump-because-it-proved-trump-was-right" rel="noopener noreferrer" target="_self" title="view post: CBS Deletes Fact-Check on Donald Trump. Because it Proved Trump was Right">CBS Deletes Fact-Check on Donald Trump. Because it Proved Trump was Right</a></p><p>As of right now, it appears Trump's handpicked establishment RNC Chair Ronna Romney-McDaniel isn't going to do anything about this, and is even letting Trump send surrogates to spin for him at a debate he refuses to go to. Fox News is also planning to use Trump clips instead of having the candidates who did show up talk about issues that matter to voters.</p><p>It will be interesting to see how the other GOP candidates respond.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/brodigan/status/1687056710890815489"></a>
</blockquote>
<p>My personal opinion is that this is a mistake on Trump's part. Primary polls are notoriously unreliable, and while Trump might be in the lead now, it's a soft lead. The first votes aren't until January, and while Trump may be the most popular now when a pollster asks a voter who they like, primary voters are known to take their time before deciding who they pull the lever for.</p><p>As today's Des Moines Register Iowa Caucus poll shows, while Trump is up overall, five months is an eternity in politics.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/MarcACaputo/status/1693567535298306367"></a>
</blockquote>
<p>There are also variables to consider if Trump gets the nomination. What about when Joe Biden says he's not going to debate? Or when CBS News airs something critical of the former president? Do they go back to being fake news? Will Biden be too scared to debate before the American people?</p><p>If I was Donald Trump, I'd show up and debate and dominate all my opponents. At least until people start voting. Once the voting starts and he still has such a dominant lead, then he can say the race is over and it's time to unite.</p><p>><p><p><p><p><p><
<p>
<em>Brodigan is Grand Poobah of this here website and when he isn't writing words about things enjoys day drinking, pro-wrestling, and country music. You can find him <a href="https://twitter.com/brodigan" target="_blank">on the Twitter</a> too.</em>
</p>
<p>
<em><strong>Facebook doesn't want you reading this post or any others lately. </strong>Their algorithm hides our stories and shenanigans as best it can. The best way to stick it to Zuckerface? <strong>Sign up for our </strong><a href="https://www.louderwithcrowder.com/newsletter" target="_blank"><strong>DAILY EMAIL BLASTS</strong></a>! They can't stop us from delivering our content straight to your inbox. Yet.</em>
</p></p>

