# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## 10 SHAMELESS Video Game Clones That SUCKED
 - [https://www.youtube.com/watch?v=hMjJmB4xooQ](https://www.youtube.com/watch?v=hMjJmB4xooQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-08-21T15:30:10+00:00

Some games attempt to ape other (much better) games in hilarious ways.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1  

Zeus of War source: https://youtu.be/dYwjMkEGhAY

0:00 Intro
0:25 Number 10
2:48 Number 9
4:17 Number 8
5:49 Number 7
7:36 Number 6
9:05 Number 5
10:36 Number 4
11:54 Number 3
13:08 Number 2
14:40 Number 1
16:14 Bonus

