# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## How a Christie’s website revealed where people kept their art
 - [https://www.washingtonpost.com/technology/2023/08/21/christies-security-breach-location/](https://www.washingtonpost.com/technology/2023/08/21/christies-security-breach-location/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-08-21T12:00:35+00:00

The incident shows that cybersecurity isn’t just an issue for big tech companies, but for almost everyone as more and more business is transacted over the internet.

## Improve your chances of getting noticed by AI on job sites with these tips
 - [https://www.washingtonpost.com/technology/2023/08/21/job-sites-tips-ai/](https://www.washingtonpost.com/technology/2023/08/21/job-sites-tips-ai/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-08-21T10:00:00+00:00

How to best work with AI matching systems on popular job sites such as LinkedIn, Indeed and ZipRecruiter.

