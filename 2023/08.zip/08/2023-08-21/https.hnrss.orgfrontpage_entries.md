# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Podman Desktop celebrates 500k downloads
 - [https://blog.podman.io/2023/08/celebrating-500k-downloads-the-podman-desktop-journey-%f0%9f%8e%89/](https://blog.podman.io/2023/08/celebrating-500k-downloads-the-podman-desktop-journey-%f0%9f%8e%89/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T23:44:54+00:00

<p>Article URL: <a href="https://blog.podman.io/2023/08/celebrating-500k-downloads-the-podman-desktop-journey-%f0%9f%8e%89/">https://blog.podman.io/2023/08/celebrating-500k-downloads-the-podman-desktop-journey-%f0%9f%8e%89/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37216800">https://news.ycombinator.com/item?id=37216800</a></p>
<p>Points: 64</p>
<p># Comments: 15</p>

## Why a highly mutated coronavirus variant has scientists on alert
 - [https://www.nature.com/articles/d41586-023-02656-9](https://www.nature.com/articles/d41586-023-02656-9)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T23:27:49+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-02656-9">https://www.nature.com/articles/d41586-023-02656-9</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37216700">https://news.ycombinator.com/item?id=37216700</a></p>
<p>Points: 5</p>
<p># Comments: 2</p>

## Growing share of Americans favor more nuclear power
 - [https://www.pewresearch.org/short-reads/2023/08/18/growing-share-of-americans-favor-more-nuclear-power/](https://www.pewresearch.org/short-reads/2023/08/18/growing-share-of-americans-favor-more-nuclear-power/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T23:21:26+00:00

<p>Article URL: <a href="https://www.pewresearch.org/short-reads/2023/08/18/growing-share-of-americans-favor-more-nuclear-power/">https://www.pewresearch.org/short-reads/2023/08/18/growing-share-of-americans-favor-more-nuclear-power/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37216647">https://news.ycombinator.com/item?id=37216647</a></p>
<p>Points: 59</p>
<p># Comments: 29</p>

## The Pleasure and Communion of Jane Austen’s Country Dance
 - [https://lithub.com/the-pleasure-and-communion-of-austens-country-dance/](https://lithub.com/the-pleasure-and-communion-of-austens-country-dance/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T22:50:39+00:00

<p>Article URL: <a href="https://lithub.com/the-pleasure-and-communion-of-austens-country-dance/">https://lithub.com/the-pleasure-and-communion-of-austens-country-dance/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37216401">https://news.ycombinator.com/item?id=37216401</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Ego Death
 - [https://krisnova.net/posts/ego-death/](https://krisnova.net/posts/ego-death/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T22:05:17+00:00

<p>Article URL: <a href="https://krisnova.net/posts/ego-death/">https://krisnova.net/posts/ego-death/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215974">https://news.ycombinator.com/item?id=37215974</a></p>
<p>Points: 20</p>
<p># Comments: 10</p>

## Baghdad closes LED advert screens after hacker shows porn film on a screen
 - [https://www.iraqinews.com/iraq/baghdad-closes-led-advert-screens-after-hacker-shows-porn-film-on-a-screen/](https://www.iraqinews.com/iraq/baghdad-closes-led-advert-screens-after-hacker-shows-porn-film-on-a-screen/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T21:56:29+00:00

<p>Article URL: <a href="https://www.iraqinews.com/iraq/baghdad-closes-led-advert-screens-after-hacker-shows-porn-film-on-a-screen/">https://www.iraqinews.com/iraq/baghdad-closes-led-advert-screens-after-hacker-shows-porn-film-on-a-screen/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215892">https://news.ycombinator.com/item?id=37215892</a></p>
<p>Points: 32</p>
<p># Comments: 5</p>

## Associated Press clarifies standards around generative AI
 - [https://www.niemanlab.org/2023/08/not-a-replacement-of-journalists-in-any-way-ap-clarifies-standards-around-generative-ai/](https://www.niemanlab.org/2023/08/not-a-replacement-of-journalists-in-any-way-ap-clarifies-standards-around-generative-ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T21:51:45+00:00

<p>Article URL: <a href="https://www.niemanlab.org/2023/08/not-a-replacement-of-journalists-in-any-way-ap-clarifies-standards-around-generative-ai/">https://www.niemanlab.org/2023/08/not-a-replacement-of-journalists-in-any-way-ap-clarifies-standards-around-generative-ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215829">https://news.ycombinator.com/item?id=37215829</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## uBlock Origin Lite now available on Firefox
 - [https://addons.mozilla.org/en-US/firefox/addon/ublock-origin-lite/](https://addons.mozilla.org/en-US/firefox/addon/ublock-origin-lite/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T21:23:51+00:00

<p>Article URL: <a href="https://addons.mozilla.org/en-US/firefox/addon/ublock-origin-lite/">https://addons.mozilla.org/en-US/firefox/addon/ublock-origin-lite/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215557">https://news.ycombinator.com/item?id=37215557</a></p>
<p>Points: 40</p>
<p># Comments: 2</p>

## Screen Time at Age 1 Year and Communication, Problem-Solving Developmental Delay
 - [https://jamanetwork.com/journals/jamapediatrics/fullarticle/2808593](https://jamanetwork.com/journals/jamapediatrics/fullarticle/2808593)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T21:20:55+00:00

<p>Article URL: <a href="https://jamanetwork.com/journals/jamapediatrics/fullarticle/2808593">https://jamanetwork.com/journals/jamapediatrics/fullarticle/2808593</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215526">https://news.ycombinator.com/item?id=37215526</a></p>
<p>Points: 23</p>
<p># Comments: 6</p>

## Educational Codebases
 - [https://buttondown.email/hillelwayne/archive/educational-codebases/](https://buttondown.email/hillelwayne/archive/educational-codebases/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T21:09:35+00:00

<p>Article URL: <a href="https://buttondown.email/hillelwayne/archive/educational-codebases/">https://buttondown.email/hillelwayne/archive/educational-codebases/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215400">https://news.ycombinator.com/item?id=37215400</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## SolarPi experiment 2: Finally something that works
 - [http://blog.rfox.eu/en/Hardware/SolarPi_experiment_2_Finally_something_that_works.html](http://blog.rfox.eu/en/Hardware/SolarPi_experiment_2_Finally_something_that_works.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T20:57:23+00:00

<p>Article URL: <a href="http://blog.rfox.eu/en/Hardware/SolarPi_experiment_2_Finally_something_that_works.html">http://blog.rfox.eu/en/Hardware/SolarPi_experiment_2_Finally_something_that_works.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37215246">https://news.ycombinator.com/item?id=37215246</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## Google Pixel Binary Transparency: verifiable security for Pixel devices
 - [https://security.googleblog.com/2023/08/pixel-binary-transparency-verifiable.html](https://security.googleblog.com/2023/08/pixel-binary-transparency-verifiable.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T20:12:40+00:00

<p>Article URL: <a href="https://security.googleblog.com/2023/08/pixel-binary-transparency-verifiable.html">https://security.googleblog.com/2023/08/pixel-binary-transparency-verifiable.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37214733">https://news.ycombinator.com/item?id=37214733</a></p>
<p>Points: 39</p>
<p># Comments: 18</p>

## Why Open Source?
 - [https://getconvoy.io/blog/why-open-source/](https://getconvoy.io/blog/why-open-source/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T19:41:39+00:00

<p>Article URL: <a href="https://getconvoy.io/blog/why-open-source/">https://getconvoy.io/blog/why-open-source/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37214342">https://news.ycombinator.com/item?id=37214342</a></p>
<p>Points: 37</p>
<p># Comments: 12</p>

## Top Ten Most Frequent DNS Test Failures
 - [https://dnsinstitute.com/research/2022/ten-common-failures-202204.html](https://dnsinstitute.com/research/2022/ten-common-failures-202204.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T19:40:15+00:00

<p>Article URL: <a href="https://dnsinstitute.com/research/2022/ten-common-failures-202204.html">https://dnsinstitute.com/research/2022/ten-common-failures-202204.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37214321">https://news.ycombinator.com/item?id=37214321</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Eighteen150 A residence program for solo immigrant founders
 - [https://www.unshackledvc.com/eighteen150](https://www.unshackledvc.com/eighteen150)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T19:30:06+00:00

<p>Article URL: <a href="https://www.unshackledvc.com/eighteen150">https://www.unshackledvc.com/eighteen150</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37214212">https://news.ycombinator.com/item?id=37214212</a></p>
<p>Points: 16</p>
<p># Comments: 4</p>

## How the rich get richer (2020)
 - [https://www.imf.org/en/Blogs/Articles/2020/11/30/how-the-rich-get-richer](https://www.imf.org/en/Blogs/Articles/2020/11/30/how-the-rich-get-richer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T19:15:27+00:00

<p>Article URL: <a href="https://www.imf.org/en/Blogs/Articles/2020/11/30/how-the-rich-get-richer">https://www.imf.org/en/Blogs/Articles/2020/11/30/how-the-rich-get-richer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37214043">https://news.ycombinator.com/item?id=37214043</a></p>
<p>Points: 37</p>
<p># Comments: 38</p>

## What does it mean for a monad to be strong?
 - [http://blog.sigfpe.com/2023/08/what-does-it-mean-for-monad-to-be-strong.html](http://blog.sigfpe.com/2023/08/what-does-it-mean-for-monad-to-be-strong.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:49:28+00:00

<p>Article URL: <a href="http://blog.sigfpe.com/2023/08/what-does-it-mean-for-monad-to-be-strong.html">http://blog.sigfpe.com/2023/08/what-does-it-mean-for-monad-to-be-strong.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213739">https://news.ycombinator.com/item?id=37213739</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Show HN: VisionScript, abstract programming language for computer vision
 - [https://github.com/capjamesg/visionscript](https://github.com/capjamesg/visionscript)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:48:25+00:00

<p>Hello! I'm James and I am working on VisionScript. With VisionScript, I want to empower people -- including everyone without any prior programming experience -- to build cool apps with vision.<p>This weekend, I recorded a demo for VisionScript, in which I made apps that count how many cats are in an image and hides people in a video. Each app was < 10 lines of code.<p><a href="https://vimeo.com/856043804" rel="nofollow noreferrer">https://vimeo.com/856043804</a><p>VisionScript is built for the 10 year old inside of me who would have loved more visual programming languages with which to play. I want to show people the potential of programming and how you can make what you want with computers, whether it be a game that counts cats or an app that monitors how many birds flew past a tree. Those "wow" moments should come as soon as possible in one's learning experience.<p>VisionScript is in active development. I started work on this project in July. There will likely be bugs; this is a passion project. Inspiration comes from Wolfram and Python. Behind the scenes, I am adopting what I am calling "lexical inference", which is to say there is a last state value on which functions infer; the language manages types and state.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213729">https://news.ycombinator.com/item?id=37213729</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## 5 years ago Valve released Proton forever changing Linux gaming
 - [https://www.gamingonlinux.com/2023/08/5-years-ago-valve-released-proton-forever-changing-linux-gaming/](https://www.gamingonlinux.com/2023/08/5-years-ago-valve-released-proton-forever-changing-linux-gaming/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:28:37+00:00

<p>Article URL: <a href="https://www.gamingonlinux.com/2023/08/5-years-ago-valve-released-proton-forever-changing-linux-gaming/">https://www.gamingonlinux.com/2023/08/5-years-ago-valve-released-proton-forever-changing-linux-gaming/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213479">https://news.ycombinator.com/item?id=37213479</a></p>
<p>Points: 59</p>
<p># Comments: 27</p>

## Latest Android Runtime (ART) update led to apps starting 30% faster
 - [https://9to5google.com/2023/08/21/android-runtime-13-14-updates/](https://9to5google.com/2023/08/21/android-runtime-13-14-updates/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:08:07+00:00

<p>Article URL: <a href="https://9to5google.com/2023/08/21/android-runtime-13-14-updates/">https://9to5google.com/2023/08/21/android-runtime-13-14-updates/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213190">https://news.ycombinator.com/item?id=37213190</a></p>
<p>Points: 34</p>
<p># Comments: 5</p>

## Critical hearing looms in battle over California’s last nuclear power plant
 - [https://www.thenewlede.org/2023/08/critical-hearing-looms-in-battle-over-californias-last-nuclear-power-plant/](https://www.thenewlede.org/2023/08/critical-hearing-looms-in-battle-over-californias-last-nuclear-power-plant/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:03:52+00:00

<p>Article URL: <a href="https://www.thenewlede.org/2023/08/critical-hearing-looms-in-battle-over-californias-last-nuclear-power-plant/">https://www.thenewlede.org/2023/08/critical-hearing-looms-in-battle-over-californias-last-nuclear-power-plant/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213134">https://news.ycombinator.com/item?id=37213134</a></p>
<p>Points: 8</p>
<p># Comments: 7</p>

## Early Days of AI
 - [https://blog.eladgil.com/p/early-days-of-ai](https://blog.eladgil.com/p/early-days-of-ai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T18:01:41+00:00

<p>Article URL: <a href="https://blog.eladgil.com/p/early-days-of-ai">https://blog.eladgil.com/p/early-days-of-ai</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213107">https://news.ycombinator.com/item?id=37213107</a></p>
<p>Points: 18</p>
<p># Comments: 3</p>

## Shrinking economies don't innovate
 - [https://www.overcomingbias.com/p/shrinking-economies-dont-innovate](https://www.overcomingbias.com/p/shrinking-economies-dont-innovate)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:55:46+00:00

<p>Article URL: <a href="https://www.overcomingbias.com/p/shrinking-economies-dont-innovate">https://www.overcomingbias.com/p/shrinking-economies-dont-innovate</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37213037">https://news.ycombinator.com/item?id=37213037</a></p>
<p>Points: 27</p>
<p># Comments: 36</p>

## Lyrebird the Linux voice changer now supports PipeWire
 - [https://github.com/lyrebird-voice-changer/lyrebird/releases/tag/v1.2.0](https://github.com/lyrebird-voice-changer/lyrebird/releases/tag/v1.2.0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:31:57+00:00

<p>Article URL: <a href="https://github.com/lyrebird-voice-changer/lyrebird/releases/tag/v1.2.0">https://github.com/lyrebird-voice-changer/lyrebird/releases/tag/v1.2.0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37212711">https://news.ycombinator.com/item?id=37212711</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## US Housing Affordability Hits Worst Point in Nearly Four Decades
 - [https://www.bloomberg.com/news/articles/2023-08-17/rising-mortgage-rates-squeeze-affordability-in-us-housing-market](https://www.bloomberg.com/news/articles/2023-08-17/rising-mortgage-rates-squeeze-affordability-in-us-housing-market)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:29:06+00:00

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-08-17/rising-mortgage-rates-squeeze-affordability-in-us-housing-market">https://www.bloomberg.com/news/articles/2023-08-17/rising-mortgage-rates-squeeze-affordability-in-us-housing-market</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37212672">https://news.ycombinator.com/item?id=37212672</a></p>
<p>Points: 39</p>
<p># Comments: 36</p>

## P2panda: P2P protocol for secure, energy-efficient local-first web applications
 - [https://p2panda.org/](https://p2panda.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:14:43+00:00

<p>Article URL: <a href="https://p2panda.org/">https://p2panda.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37212462">https://news.ycombinator.com/item?id=37212462</a></p>
<p>Points: 27</p>
<p># Comments: 2</p>

## New York and California Each Lost $1T When Financial Firms Moved South
 - [https://www.bloomberg.com/graphics/2023-asset-management-relocation-wall-street-south/](https://www.bloomberg.com/graphics/2023-asset-management-relocation-wall-street-south/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:02:51+00:00

<p>Article URL: <a href="https://www.bloomberg.com/graphics/2023-asset-management-relocation-wall-street-south/">https://www.bloomberg.com/graphics/2023-asset-management-relocation-wall-street-south/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37212301">https://news.ycombinator.com/item?id=37212301</a></p>
<p>Points: 17</p>
<p># Comments: 7</p>

## When I have a slower publishing cadence my blog grows faster
 - [https://www.henrikkarlsson.xyz/p/effort-pieces](https://www.henrikkarlsson.xyz/p/effort-pieces)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T17:00:09+00:00

<p>Article URL: <a href="https://www.henrikkarlsson.xyz/p/effort-pieces">https://www.henrikkarlsson.xyz/p/effort-pieces</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37212266">https://news.ycombinator.com/item?id=37212266</a></p>
<p>Points: 32</p>
<p># Comments: 2</p>

## Build a Business, Not an Audience
 - [https://jakobgreenfeld.com/build_an_audience](https://jakobgreenfeld.com/build_an_audience)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:34:54+00:00

<p>Article URL: <a href="https://jakobgreenfeld.com/build_an_audience">https://jakobgreenfeld.com/build_an_audience</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211933">https://news.ycombinator.com/item?id=37211933</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Namecheap to increase .COM and .XYZ prices
 - [https://www.namecheap.com/blog/upcoming-com-and-xyz-domain-price-increase/](https://www.namecheap.com/blog/upcoming-com-and-xyz-domain-price-increase/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:20:02+00:00

<p>Article URL: <a href="https://www.namecheap.com/blog/upcoming-com-and-xyz-domain-price-increase/">https://www.namecheap.com/blog/upcoming-com-and-xyz-domain-price-increase/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211675">https://news.ycombinator.com/item?id=37211675</a></p>
<p>Points: 50</p>
<p># Comments: 40</p>

## The broad set of computer science problems faced at cloud database companies
 - [https://davidgomes.com/the-broad-set-of-computer-science-problems-faced-at-cloud-database-companies/](https://davidgomes.com/the-broad-set-of-computer-science-problems-faced-at-cloud-database-companies/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:17:56+00:00

<p>Article URL: <a href="https://davidgomes.com/the-broad-set-of-computer-science-problems-faced-at-cloud-database-companies/">https://davidgomes.com/the-broad-set-of-computer-science-problems-faced-at-cloud-database-companies/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211642">https://news.ycombinator.com/item?id=37211642</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## MacLynx beta 5: UTF-8, pull-down menus and more dialogue boxes
 - [http://oldvcr.blogspot.com/2023/08/maclynx-beta-5-utf-8-pull-down-menus.html](http://oldvcr.blogspot.com/2023/08/maclynx-beta-5-utf-8-pull-down-menus.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:11:01+00:00

<p>Article URL: <a href="http://oldvcr.blogspot.com/2023/08/maclynx-beta-5-utf-8-pull-down-menus.html">http://oldvcr.blogspot.com/2023/08/maclynx-beta-5-utf-8-pull-down-menus.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211542">https://news.ycombinator.com/item?id=37211542</a></p>
<p>Points: 29</p>
<p># Comments: 0</p>

## I Made Stable Diffusion XL Smarter by Finetuning It on Bad AI-Generated Images
 - [https://minimaxir.com/2023/08/stable-diffusion-xl-wrong/](https://minimaxir.com/2023/08/stable-diffusion-xl-wrong/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:09:27+00:00

<p>Article URL: <a href="https://minimaxir.com/2023/08/stable-diffusion-xl-wrong/">https://minimaxir.com/2023/08/stable-diffusion-xl-wrong/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211519">https://news.ycombinator.com/item?id=37211519</a></p>
<p>Points: 78</p>
<p># Comments: 21</p>

## 9% price increase for .COM and .XYZ domains starting Sept 1, 2023
 - [https://i.imgur.com/5cGazrG.png](https://i.imgur.com/5cGazrG.png)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T16:05:39+00:00

<p>Article URL: <a href="https://i.imgur.com/5cGazrG.png">https://i.imgur.com/5cGazrG.png</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211462">https://news.ycombinator.com/item?id=37211462</a></p>
<p>Points: 12</p>
<p># Comments: 3</p>

## Clever coating turns lampshades into indoor air purifiers
 - [https://techxplore.com/news/2023-08-clever-coating-lampshades-indoor-air.html](https://techxplore.com/news/2023-08-clever-coating-lampshades-indoor-air.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:58:50+00:00

<p>Article URL: <a href="https://techxplore.com/news/2023-08-clever-coating-lampshades-indoor-air.html">https://techxplore.com/news/2023-08-clever-coating-lampshades-indoor-air.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211365">https://news.ycombinator.com/item?id=37211365</a></p>
<p>Points: 12</p>
<p># Comments: 5</p>

## Steve Jobs: Fast boot times saves lives
 - [https://www.folklore.org/StoryView.py?story=Saving_Lives.txt](https://www.folklore.org/StoryView.py?story=Saving_Lives.txt)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:51:18+00:00

<p>Article URL: <a href="https://www.folklore.org/StoryView.py?story=Saving_Lives.txt">https://www.folklore.org/StoryView.py?story=Saving_Lives.txt</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211230">https://news.ycombinator.com/item?id=37211230</a></p>
<p>Points: 51</p>
<p># Comments: 35</p>

## What Are FD&C Dyes and Lakes (and How Do They Differ)?
 - [https://www.madmicas.com/pages/what-are-fd-c-dyes-and-lakes-and-how-do-they-differ](https://www.madmicas.com/pages/what-are-fd-c-dyes-and-lakes-and-how-do-they-differ)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:51:18+00:00

<p>Article URL: <a href="https://www.madmicas.com/pages/what-are-fd-c-dyes-and-lakes-and-how-do-they-differ">https://www.madmicas.com/pages/what-are-fd-c-dyes-and-lakes-and-how-do-they-differ</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37211231">https://news.ycombinator.com/item?id=37211231</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## New study measures grammatical complexity of 1,314 languages
 - [https://phys.org/news/2023-08-evolution-complex-grammars-grammatical-complexity.html](https://phys.org/news/2023-08-evolution-complex-grammars-grammatical-complexity.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:33:45+00:00

<p>Article URL: <a href="https://phys.org/news/2023-08-evolution-complex-grammars-grammatical-complexity.html">https://phys.org/news/2023-08-evolution-complex-grammars-grammatical-complexity.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210961">https://news.ycombinator.com/item?id=37210961</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Don't Fire Your Illustrator
 - [https://sambleckley.com/writing/dont-fire-your-illustrator.html](https://sambleckley.com/writing/dont-fire-your-illustrator.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:33:11+00:00

<p>Article URL: <a href="https://sambleckley.com/writing/dont-fire-your-illustrator.html">https://sambleckley.com/writing/dont-fire-your-illustrator.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210953">https://news.ycombinator.com/item?id=37210953</a></p>
<p>Points: 49</p>
<p># Comments: 14</p>

## Kansas Bureau of Investigation takes lead following police raid of newspaper
 - [https://www.kansascity.com/news/politics-government/article278253028.html](https://www.kansascity.com/news/politics-government/article278253028.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:25:30+00:00

<p>Article URL: <a href="https://www.kansascity.com/news/politics-government/article278253028.html">https://www.kansascity.com/news/politics-government/article278253028.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210837">https://news.ycombinator.com/item?id=37210837</a></p>
<p>Points: 49</p>
<p># Comments: 4</p>

## ''Vinegar Syndrome'' Decaying Archives of Cellulose Acetate Microfilm Stock
 - [https://www.cbc.ca/news/canada/toronto/vinegar-syndrome-acetate-film-1.6939032](https://www.cbc.ca/news/canada/toronto/vinegar-syndrome-acetate-film-1.6939032)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:11:21+00:00

<p>Article URL: <a href="https://www.cbc.ca/news/canada/toronto/vinegar-syndrome-acetate-film-1.6939032">https://www.cbc.ca/news/canada/toronto/vinegar-syndrome-acetate-film-1.6939032</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210615">https://news.ycombinator.com/item?id=37210615</a></p>
<p>Points: 13</p>
<p># Comments: 5</p>

## I come here not to bury Delphi, but to praise it (2019)
 - [https://accu.org/journals/overload/27/153/martin_2703/](https://accu.org/journals/overload/27/153/martin_2703/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T15:09:20+00:00

<p>Article URL: <a href="https://accu.org/journals/overload/27/153/martin_2703/">https://accu.org/journals/overload/27/153/martin_2703/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210584">https://news.ycombinator.com/item?id=37210584</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## Flatpak is not the future (2021)
 - [https://ludocode.com/blog/flatpak-is-not-the-future](https://ludocode.com/blog/flatpak-is-not-the-future)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T14:56:36+00:00

<p>Article URL: <a href="https://ludocode.com/blog/flatpak-is-not-the-future">https://ludocode.com/blog/flatpak-is-not-the-future</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210397">https://news.ycombinator.com/item?id=37210397</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## YouTube Is Still Tracking Kids Through Its Ads, Study Says
 - [https://cordcuttersnews.com/youtube-is-still-tracking-kids-through-its-ads-study-says/](https://cordcuttersnews.com/youtube-is-still-tracking-kids-through-its-ads-study-says/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T14:40:38+00:00

<p>Article URL: <a href="https://cordcuttersnews.com/youtube-is-still-tracking-kids-through-its-ads-study-says/">https://cordcuttersnews.com/youtube-is-still-tracking-kids-through-its-ads-study-says/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37210159">https://news.ycombinator.com/item?id=37210159</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Garbage Collection in a Large Lisp System (1984) [pdf]
 - [https://dl.acm.org/doi/pdf/10.1145/800055.802040](https://dl.acm.org/doi/pdf/10.1145/800055.802040)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T14:21:57+00:00

<p>Article URL: <a href="https://dl.acm.org/doi/pdf/10.1145/800055.802040">https://dl.acm.org/doi/pdf/10.1145/800055.802040</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209932">https://news.ycombinator.com/item?id=37209932</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## All of the vehicle license plates available in America
 - [https://www.beautifulpublicdata.com/all-of-the-license-plates-in-the-united-states/](https://www.beautifulpublicdata.com/all-of-the-license-plates-in-the-united-states/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T14:19:18+00:00

<p>Article URL: <a href="https://www.beautifulpublicdata.com/all-of-the-license-plates-in-the-united-states/">https://www.beautifulpublicdata.com/all-of-the-license-plates-in-the-united-states/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209888">https://news.ycombinator.com/item?id=37209888</a></p>
<p>Points: 30</p>
<p># Comments: 23</p>

## Duo Outage
 - [https://status.duo.com](https://status.duo.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T14:02:57+00:00

<p>Article URL: <a href="https://status.duo.com">https://status.duo.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209684">https://news.ycombinator.com/item?id=37209684</a></p>
<p>Points: 47</p>
<p># Comments: 25</p>

## Study: Inflammation drives social media use
 - [https://www.buffalo.edu/news/releases/2023/08/lee-inflammation-drives-social-media-use.html](https://www.buffalo.edu/news/releases/2023/08/lee-inflammation-drives-social-media-use.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T13:39:37+00:00

<p>Article URL: <a href="https://www.buffalo.edu/news/releases/2023/08/lee-inflammation-drives-social-media-use.html">https://www.buffalo.edu/news/releases/2023/08/lee-inflammation-drives-social-media-use.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209460">https://news.ycombinator.com/item?id=37209460</a></p>
<p>Points: 15</p>
<p># Comments: 2</p>

## Suppose I Wanted to Kill a Lot of Pilots
 - [https://newsletter.butwhatfor.com/p/invert-always-invert-avoid-failure](https://newsletter.butwhatfor.com/p/invert-always-invert-avoid-failure)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T13:27:20+00:00

<p>Article URL: <a href="https://newsletter.butwhatfor.com/p/invert-always-invert-avoid-failure">https://newsletter.butwhatfor.com/p/invert-always-invert-avoid-failure</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209309">https://news.ycombinator.com/item?id=37209309</a></p>
<p>Points: 15</p>
<p># Comments: 7</p>

## Taos Operating System (1995)
 - [http://www.uruk.org/emu/Taos.html](http://www.uruk.org/emu/Taos.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T13:24:43+00:00

<p>Article URL: <a href="http://www.uruk.org/emu/Taos.html">http://www.uruk.org/emu/Taos.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37209279">https://news.ycombinator.com/item?id=37209279</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Wi-Fi sniffers strapped to drones–Mike Lindell’s odd plan to stop election fraud
 - [https://arstechnica.com/tech-policy/2023/08/wi-fi-sniffers-strapped-to-drones-mike-lindells-odd-plan-to-stop-election-fraud/](https://arstechnica.com/tech-policy/2023/08/wi-fi-sniffers-strapped-to-drones-mike-lindells-odd-plan-to-stop-election-fraud/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T12:44:21+00:00

<p>Article URL: <a href="https://arstechnica.com/tech-policy/2023/08/wi-fi-sniffers-strapped-to-drones-mike-lindells-odd-plan-to-stop-election-fraud/">https://arstechnica.com/tech-policy/2023/08/wi-fi-sniffers-strapped-to-drones-mike-lindells-odd-plan-to-stop-election-fraud/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208751">https://news.ycombinator.com/item?id=37208751</a></p>
<p>Points: 11</p>
<p># Comments: 4</p>

## Anyone incarcerated 2+ years is going to return to their Google account deleted
 - [https://twitter.com/GrahamStarr/status/1693119093526671859](https://twitter.com/GrahamStarr/status/1693119093526671859)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T12:08:56+00:00

<p>Article URL: <a href="https://twitter.com/GrahamStarr/status/1693119093526671859">https://twitter.com/GrahamStarr/status/1693119093526671859</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208378">https://news.ycombinator.com/item?id=37208378</a></p>
<p>Points: 33</p>
<p># Comments: 6</p>

## Show HN: The Uncolouring Book
 - [https://lines.potato.horse](https://lines.potato.horse)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T11:54:09+00:00

<p>Article URL: <a href="https://lines.potato.horse">https://lines.potato.horse</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208248">https://news.ycombinator.com/item?id=37208248</a></p>
<p>Points: 17</p>
<p># Comments: 9</p>

## Why Bumblebees Love Cats and Other Beautiful Relationships (2021)
 - [https://longreads.com/2021/03/23/nation-of-plants-excerpt-stefano-mancuso/](https://longreads.com/2021/03/23/nation-of-plants-excerpt-stefano-mancuso/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T11:51:32+00:00

<p>Article URL: <a href="https://longreads.com/2021/03/23/nation-of-plants-excerpt-stefano-mancuso/">https://longreads.com/2021/03/23/nation-of-plants-excerpt-stefano-mancuso/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208228">https://news.ycombinator.com/item?id=37208228</a></p>
<p>Points: 20</p>
<p># Comments: 2</p>

## The Ideal Viewport Doesn't Exist
 - [https://viewports.fyi/](https://viewports.fyi/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T11:49:30+00:00

<p>Article URL: <a href="https://viewports.fyi/">https://viewports.fyi/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208211">https://news.ycombinator.com/item?id=37208211</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## GNU Parallel, where have you been all my life?
 - [https://alexplescan.com/posts/2023/08/20/gnu-parallel/](https://alexplescan.com/posts/2023/08/20/gnu-parallel/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T11:31:15+00:00

<p>Article URL: <a href="https://alexplescan.com/posts/2023/08/20/gnu-parallel/">https://alexplescan.com/posts/2023/08/20/gnu-parallel/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37208083">https://news.ycombinator.com/item?id=37208083</a></p>
<p>Points: 67</p>
<p># Comments: 11</p>

## 80% of Companies do not need Snowflake or Databricks
 - [https://kjhealey.medium.com/cached-takes-80-of-companies-do-not-need-snowflake-or-databricks-5ebda64c0853](https://kjhealey.medium.com/cached-takes-80-of-companies-do-not-need-snowflake-or-databricks-5ebda64c0853)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T09:55:14+00:00

<p>Article URL: <a href="https://kjhealey.medium.com/cached-takes-80-of-companies-do-not-need-snowflake-or-databricks-5ebda64c0853">https://kjhealey.medium.com/cached-takes-80-of-companies-do-not-need-snowflake-or-databricks-5ebda64c0853</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37207329">https://news.ycombinator.com/item?id=37207329</a></p>
<p>Points: 20</p>
<p># Comments: 5</p>

## Tesla owners say they've been trapped inside their EVs after they lost power
 - [https://www.businessinsider.com/how-to-manually-open-tesla-door-if-battery-power-dies-2023-8](https://www.businessinsider.com/how-to-manually-open-tesla-door-if-battery-power-dies-2023-8)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T09:23:12+00:00

<p>Article URL: <a href="https://www.businessinsider.com/how-to-manually-open-tesla-door-if-battery-power-dies-2023-8">https://www.businessinsider.com/how-to-manually-open-tesla-door-if-battery-power-dies-2023-8</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37207107">https://news.ycombinator.com/item?id=37207107</a></p>
<p>Points: 23</p>
<p># Comments: 30</p>

## Last rites for the UK Online Safety Bill, an idea too stupid to notice it's dead
 - [https://www.theregister.com/2023/08/21/opinion_column_monday/](https://www.theregister.com/2023/08/21/opinion_column_monday/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T08:56:36+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/08/21/opinion_column_monday/">https://www.theregister.com/2023/08/21/opinion_column_monday/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206953">https://news.ycombinator.com/item?id=37206953</a></p>
<p>Points: 21</p>
<p># Comments: 3</p>

## English is a pictographic language with 26 radicals
 - [https://www.smbc-comics.com/comic/pronounce](https://www.smbc-comics.com/comic/pronounce)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T08:08:27+00:00

<p>Article URL: <a href="https://www.smbc-comics.com/comic/pronounce">https://www.smbc-comics.com/comic/pronounce</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206651">https://news.ycombinator.com/item?id=37206651</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## I'm sending a weekly PHP community newsletter
 - [https://weeklyphp.substack.com/](https://weeklyphp.substack.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T07:46:38+00:00

<p>Article URL: <a href="https://weeklyphp.substack.com/">https://weeklyphp.substack.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206520">https://news.ycombinator.com/item?id=37206520</a></p>
<p>Points: 20</p>
<p># Comments: 1</p>

## Be careful of the examples you use. They stick
 - [https://blog.thinkst.com/2023/08/default-behaviour-sticks-and-so-do-examples.html](https://blog.thinkst.com/2023/08/default-behaviour-sticks-and-so-do-examples.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T07:20:26+00:00

<p>Article URL: <a href="https://blog.thinkst.com/2023/08/default-behaviour-sticks-and-so-do-examples.html">https://blog.thinkst.com/2023/08/default-behaviour-sticks-and-so-do-examples.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206353">https://news.ycombinator.com/item?id=37206353</a></p>
<p>Points: 11</p>
<p># Comments: 7</p>

## A man who can talk backwards
 - [https://linguischtick.wordpress.com/2017/04/06/the-man-who-can-talk-backwards/](https://linguischtick.wordpress.com/2017/04/06/the-man-who-can-talk-backwards/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T06:26:41+00:00

<p>Article URL: <a href="https://linguischtick.wordpress.com/2017/04/06/the-man-who-can-talk-backwards/">https://linguischtick.wordpress.com/2017/04/06/the-man-who-can-talk-backwards/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206061">https://news.ycombinator.com/item?id=37206061</a></p>
<p>Points: 7</p>
<p># Comments: 4</p>

## To Conference Organisers Everywhere
 - [https://arunraghavan.net/2023/08/to-conference-organisers-everywhere/](https://arunraghavan.net/2023/08/to-conference-organisers-everywhere/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T06:24:50+00:00

<p>Article URL: <a href="https://arunraghavan.net/2023/08/to-conference-organisers-everywhere/">https://arunraghavan.net/2023/08/to-conference-organisers-everywhere/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37206052">https://news.ycombinator.com/item?id=37206052</a></p>
<p>Points: 9</p>
<p># Comments: 0</p>

## We’re All Just Temporarily Abled
 - [https://blog.jim-nielsen.com/2023/temporarily-abled/](https://blog.jim-nielsen.com/2023/temporarily-abled/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T05:16:03+00:00

<p>Article URL: <a href="https://blog.jim-nielsen.com/2023/temporarily-abled/">https://blog.jim-nielsen.com/2023/temporarily-abled/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205731">https://news.ycombinator.com/item?id=37205731</a></p>
<p>Points: 48</p>
<p># Comments: 12</p>

## Out-of-memory victim selection with BPF
 - [https://lwn.net/SubscriberLink/941614/f873a0ec485e01c5/](https://lwn.net/SubscriberLink/941614/f873a0ec485e01c5/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T05:13:16+00:00

<p>Article URL: <a href="https://lwn.net/SubscriberLink/941614/f873a0ec485e01c5/">https://lwn.net/SubscriberLink/941614/f873a0ec485e01c5/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205717">https://news.ycombinator.com/item?id=37205717</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Precompiled binaries removed from serde v1.0.184
 - [https://github.com/serde-rs/serde/releases/tag/v1.0.184](https://github.com/serde-rs/serde/releases/tag/v1.0.184)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T04:59:01+00:00

<p>Article URL: <a href="https://github.com/serde-rs/serde/releases/tag/v1.0.184">https://github.com/serde-rs/serde/releases/tag/v1.0.184</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205647">https://news.ycombinator.com/item?id=37205647</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Texas electricity prices soar 6k% as heat wave is expected to shatter records
 - [https://desdemonadespair.net/2023/08/texas-electricity-prices-soar-6000-percent-as-a-fresh-heat-wave-is-expected-to-shatter-records-spot-electricity-prices-jumped-to-4750-per-megawatt-hour-from-the-average-of-75.html](https://desdemonadespair.net/2023/08/texas-electricity-prices-soar-6000-percent-as-a-fresh-heat-wave-is-expected-to-shatter-records-spot-electricity-prices-jumped-to-4750-per-megawatt-hour-from-the-average-of-75.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T03:43:49+00:00

<p>Article URL: <a href="https://desdemonadespair.net/2023/08/texas-electricity-prices-soar-6000-percent-as-a-fresh-heat-wave-is-expected-to-shatter-records-spot-electricity-prices-jumped-to-4750-per-megawatt-hour-from-the-average-of-75.html">https://desdemonadespair.net/2023/08/texas-electricity-prices-soar-6000-percent-as-a-fresh-heat-wave-is-expected-to-shatter-records-spot-electricity-prices-jumped-to-4750-per-megawatt-hour-from-the-average-of-75.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205215">https://news.ycombinator.com/item?id=37205215</a></p>
<p>Points: 30</p>
<p># Comments: 39</p>

## FreeBSD replaces bubblesort with mergesort on SYSINTs, results in 100x speed
 - [https://twitter.com/cperciva/status/1693127769901969772](https://twitter.com/cperciva/status/1693127769901969772)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T03:09:20+00:00

<p>Article URL: <a href="https://twitter.com/cperciva/status/1693127769901969772">https://twitter.com/cperciva/status/1693127769901969772</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205053">https://news.ycombinator.com/item?id=37205053</a></p>
<p>Points: 25</p>
<p># Comments: 4</p>

## Anxious brains redirect emotion regulation
 - [https://www.nature.com/articles/s41467-023-40666-3](https://www.nature.com/articles/s41467-023-40666-3)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T03:04:51+00:00

<p>Article URL: <a href="https://www.nature.com/articles/s41467-023-40666-3">https://www.nature.com/articles/s41467-023-40666-3</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37205029">https://news.ycombinator.com/item?id=37205029</a></p>
<p>Points: 27</p>
<p># Comments: 5</p>

## CLAs create different issues than making (small) open source contributions
 - [https://utcc.utoronto.ca/~cks/space/blog/tech/CLAsImpedeContributionsII](https://utcc.utoronto.ca/~cks/space/blog/tech/CLAsImpedeContributionsII)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T02:58:28+00:00

<p>Article URL: <a href="https://utcc.utoronto.ca/~cks/space/blog/tech/CLAsImpedeContributionsII">https://utcc.utoronto.ca/~cks/space/blog/tech/CLAsImpedeContributionsII</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204996">https://news.ycombinator.com/item?id=37204996</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## StableVideo: Text-Driven Consistency-Aware Diffusion Video Editing
 - [https://rese1f.github.io/StableVideo/](https://rese1f.github.io/StableVideo/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T02:47:52+00:00

<p>Article URL: <a href="https://rese1f.github.io/StableVideo/">https://rese1f.github.io/StableVideo/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204950">https://news.ycombinator.com/item?id=37204950</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Probability Can Bite
 - [https://www.maa.org/external_archive/devlin/devlin_04_10.html](https://www.maa.org/external_archive/devlin/devlin_04_10.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T02:42:41+00:00

<p>Article URL: <a href="https://www.maa.org/external_archive/devlin/devlin_04_10.html">https://www.maa.org/external_archive/devlin/devlin_04_10.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204926">https://news.ycombinator.com/item?id=37204926</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## The Age of the Clever Fool
 - [https://www.ft.com/content/1dbc675b-944d-4fb3-8889-6be7526cf11e](https://www.ft.com/content/1dbc675b-944d-4fb3-8889-6be7526cf11e)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T02:26:39+00:00

<p>Article URL: <a href="https://www.ft.com/content/1dbc675b-944d-4fb3-8889-6be7526cf11e">https://www.ft.com/content/1dbc675b-944d-4fb3-8889-6be7526cf11e</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204837">https://news.ycombinator.com/item?id=37204837</a></p>
<p>Points: 13</p>
<p># Comments: 6</p>

## GNU Radio software-defined radio (SDR) implementation of a LoRa transceiver
 - [https://github.com/tapparelj/gr-lora_sdr](https://github.com/tapparelj/gr-lora_sdr)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T02:12:35+00:00

<p>Article URL: <a href="https://github.com/tapparelj/gr-lora_sdr">https://github.com/tapparelj/gr-lora_sdr</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204775">https://news.ycombinator.com/item?id=37204775</a></p>
<p>Points: 20</p>
<p># Comments: 1</p>

## My talk with Kris Nova about being homeless. See you on the other side, friend
 - [https://kubecuddle.transistor.fm/episodes/dave-fogle-and-kris-nova](https://kubecuddle.transistor.fm/episodes/dave-fogle-and-kris-nova)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T01:20:48+00:00

<p>Article URL: <a href="https://kubecuddle.transistor.fm/episodes/dave-fogle-and-kris-nova">https://kubecuddle.transistor.fm/episodes/dave-fogle-and-kris-nova</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204473">https://news.ycombinator.com/item?id=37204473</a></p>
<p>Points: 48</p>
<p># Comments: 1</p>

## Sfmemory.org: Useful San Francisco and Bay Area History Resources
 - [https://sfmemory.org/](https://sfmemory.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-08-21T00:18:06+00:00

<p>Article URL: <a href="https://sfmemory.org/">https://sfmemory.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37204193">https://news.ycombinator.com/item?id=37204193</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

