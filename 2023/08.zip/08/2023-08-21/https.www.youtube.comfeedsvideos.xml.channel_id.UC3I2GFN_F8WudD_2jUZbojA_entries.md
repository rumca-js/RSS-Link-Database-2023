# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Oblé Reed - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=ZpYy0PU81cI](https://www.youtube.com/watch?v=ZpYy0PU81cI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-08-21T15:00:36+00:00

http://KEXP.ORG presents Oblé Reed performing live in the KEXP studio. Recorded June 29, 2023

Songs:
MP3.
DANCEPARTY.
BLACKKIDS.
HOMETOWNHERO.

Oblé Reed - Vocals
Jason Abbot - Guitar
Ariel De Anda - Guitar
Hayden Lilak - Bass
Evan George - Drums
Tristan Stone - Keyboard, Synth

Host: Eva Walker
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.oblereed.com
http://kexp.org

## Oblé Reed - MP3. (Live on KEXP)
 - [https://www.youtube.com/watch?v=qPpK_3BUePw](https://www.youtube.com/watch?v=qPpK_3BUePw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-08-21T11:00:45+00:00

http://KEXP.ORG presents Oblé Reed performing “MP3." live in the KEXP studio. Recorded June 29, 2023

Oblé Reed - Vocals
Jason Abbot - Guitar
Ariel De Anda - Guitar
Hayden Lilak - Bass
Evan George - Drums
Tristan Stone - Keyboard, Synth

Host: Eva Walker
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.oblereed.com
http://kexp.org

## Oblé Reed - DANCEPARTY. (Live on KEXP)
 - [https://www.youtube.com/watch?v=hDDrNv9fCOg](https://www.youtube.com/watch?v=hDDrNv9fCOg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-08-21T11:00:37+00:00

http://KEXP.ORG presents Oblé Reed performing “DANCEPARTY.” live in the KEXP studio. Recorded June 29, 2023

Oblé Reed - Vocals
Jason Abbot - Guitar
Ariel De Anda - Guitar
Hayden Lilak - Bass
Evan George - Drums
Tristan Stone - Keyboard, Synth

Host: Eva Walker
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.oblereed.com
http://kexp.org

## Oblé Reed - BLACKKIDS. (Live on KEXP)
 - [https://www.youtube.com/watch?v=HxpuS3CDDPo](https://www.youtube.com/watch?v=HxpuS3CDDPo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-08-21T11:00:24+00:00

http://KEXP.ORG presents Oblé Reed performing “BLACKKIDS.” live in the KEXP studio. Recorded June 29, 2023

Oblé Reed - Vocals
Jason Abbot - Guitar
Ariel De Anda - Guitar
Hayden Lilak - Bass
Evan George - Drums
Tristan Stone - Keyboard, Synth

Host: Eva Walker
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.oblereed.com
http://kexp.org

## Oblé Reed - HOMETOWNHERO. (Live on KEXP)
 - [https://www.youtube.com/watch?v=Y_xDAh4k98E](https://www.youtube.com/watch?v=Y_xDAh4k98E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-08-21T11:00:23+00:00

http://KEXP.ORG presents Oblé Reed performing “HOMETOWNHERO.” live in the KEXP studio. Recorded June 29, 2023

Oblé Reed - Vocals
Jason Abbot - Guitar
Ariel De Anda - Guitar
Hayden Lilak - Bass
Evan George - Drums
Tristan Stone - Keyboard, Synth

Host: Eva Walker
Audio Engineers: Kevin Suggs
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Scott Holpainen

https://www.oblereed.com
http://kexp.org

