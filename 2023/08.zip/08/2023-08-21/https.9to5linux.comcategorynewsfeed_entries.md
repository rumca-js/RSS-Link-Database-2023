# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Bodhi Linux 7.0 Released with Linux Kernel 6.4, Based on Ubuntu 22.04 LTS
 - [https://9to5linux.com/bodhi-linux-7-0-released-with-linux-kernel-6-4-based-on-ubuntu-22-04-lts](https://9to5linux.com/bodhi-linux-7-0-released-with-linux-kernel-6-4-based-on-ubuntu-22-04-lts)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-08-21T13:18:50+00:00

<p>Bodhi Linux 7.0 distribution is now available for download with support for Linux kernel 6.4, based on Ubuntu 22.04 LTS.</p>
<p>The post <a href="https://9to5linux.com/bodhi-linux-7-0-released-with-linux-kernel-6-4-based-on-ubuntu-22-04-lts" rel="nofollow">Bodhi Linux 7.0 Released with Linux Kernel 6.4, Based on Ubuntu 22.04 LTS</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## LibreOffice 7.6 Open-Source Office Suite Officially Released, This Is What’s New
 - [https://9to5linux.com/libreoffice-7-6-open-source-office-suite-officially-released-this-is-whats-new](https://9to5linux.com/libreoffice-7-6-open-source-office-suite-officially-released-this-is-whats-new)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-08-21T10:00:42+00:00

<p>LibreOffice 7.6 open-source office suite is now available for download with several new features and improvements. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/libreoffice-7-6-open-source-office-suite-officially-released-this-is-whats-new" rel="nofollow">LibreOffice 7.6 Open-Source Office Suite Officially Released, This Is What&#8217;s New</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

