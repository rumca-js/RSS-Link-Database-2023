# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 📶 Android nie chce 2G
 - [https://www.youtube.com/watch?v=DCjo1p54sk8](https://www.youtube.com/watch?v=DCjo1p54sk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-08-21T04:00:07+00:00

Sieci komórkowe drugiej generacji nie mają wiele wspólnego z bezpieczeństwem. Niestety mimo tego, że mamy już 3, 4, a nawet 5G, to ktoś złośliwy jest w stanie w sprytny sposób zmusić nasz telefon do połączenia się do stacji bazowej korzystając z przestarzałych protokołów komunikacji. A wtedy już naprawdę łatwo nas zaatakować.
 
Źródła:
https://tinyurl.com/5n8zykp9

 
#Android #bezpieczeństwo #2G #szyfrowanie

