# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Kamala Harris seeks a second act as GOP attacks intensify
 - [https://www.politico.com/news/2023/08/21/kamala-harris-second-act-00111913](https://www.politico.com/news/2023/08/21/kamala-harris-second-act-00111913)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-08-21T03:30:00+00:00

In a POLITICO interview, the vice president addressed how she views the growing scrutiny she’s under as Republicans use her as a “bogeyman” in 2024.

