# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## Manatee county teachers close class libraries, fearing prosecution under FL law
 - [https://www.heraldtribune.com/story/news/education/2023/01/23/fearing-prosecution-manatee-county-teachers-cover-up-classroom-books/69832276007/](https://www.heraldtribune.com/story/news/education/2023/01/23/fearing-prosecution-manatee-county-teachers-cover-up-classroom-books/69832276007/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 23:28:34+00:00
 - user: None

<p>Article URL: <a href="https://www.heraldtribune.com/story/news/education/2023/01/23/fearing-prosecution-manatee-county-teachers-cover-up-classroom-books/69832276007/">https://www.heraldtribune.com/story/news/education/2023/01/23/fearing-prosecution-manatee-county-teachers-cover-up-classroom-books/69832276007/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34553234">https://news.ycombinator.com/item?id=34553234</a></p>
<p>Points: 44</p>
<p># Comments: 34</p>

## Broider: Pixel Art CSS Borders
 - [https://maxbittker.github.io/broider/](https://maxbittker.github.io/broider/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 23:24:06+00:00
 - user: None

<p>Article URL: <a href="https://maxbittker.github.io/broider/">https://maxbittker.github.io/broider/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34553190">https://news.ycombinator.com/item?id=34553190</a></p>
<p>Points: 47</p>
<p># Comments: 5</p>

## Why Go and Not Rust? (2019)
 - [https://kristoff.it/blog/why-go-and-not-rust/](https://kristoff.it/blog/why-go-and-not-rust/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 22:58:59+00:00
 - user: None

<p>Article URL: <a href="https://kristoff.it/blog/why-go-and-not-rust/">https://kristoff.it/blog/why-go-and-not-rust/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34552981">https://news.ycombinator.com/item?id=34552981</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Weather Machine – Rock solid weather APIs with zero hassle
 - [https://weathermachine.io/](https://weathermachine.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 22:47:52+00:00
 - user: None

<p>Article URL: <a href="https://weathermachine.io/">https://weathermachine.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34552890">https://news.ycombinator.com/item?id=34552890</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## First signs of spring have arrived in parts of south 3 weeks sooner than average
 - [https://www.usanpn.org/news/spring](https://www.usanpn.org/news/spring)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 22:35:59+00:00
 - user: None

<p>Article URL: <a href="https://www.usanpn.org/news/spring">https://www.usanpn.org/news/spring</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34552808">https://news.ycombinator.com/item?id=34552808</a></p>
<p>Points: 26</p>
<p># Comments: 5</p>

## Building a Sleeper Computer from an SGI Indy
 - [https://buu342.me/blog/projects/01-SGIIndySleeper.html](https://buu342.me/blog/projects/01-SGIIndySleeper.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 22:29:15+00:00
 - user: None

<p>Article URL: <a href="https://buu342.me/blog/projects/01-SGIIndySleeper.html">https://buu342.me/blog/projects/01-SGIIndySleeper.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34552750">https://news.ycombinator.com/item?id=34552750</a></p>
<p>Points: 12</p>
<p># Comments: 2</p>

## Carp: A Statically Typed Lisp
 - [https://github.com/carp-lang/Carp](https://github.com/carp-lang/Carp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 21:51:18+00:00
 - user: None

<p>Article URL: <a href="https://github.com/carp-lang/Carp">https://github.com/carp-lang/Carp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34552382">https://news.ycombinator.com/item?id=34552382</a></p>
<p>Points: 11</p>
<p># Comments: 1</p>

## Multiple engines are down: incident report for OpenAI
 - [https://status.openai.com/incidents/tljwlz08w539](https://status.openai.com/incidents/tljwlz08w539)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 21:15:43+00:00
 - user: None

<p>Article URL: <a href="https://status.openai.com/incidents/tljwlz08w539">https://status.openai.com/incidents/tljwlz08w539</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551967">https://news.ycombinator.com/item?id=34551967</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Kevin Mitnick Hacked California Law in 1983
 - [https://www.schneier.com/blog/archives/2023/01/kevin-mitnick-hacked-california-law-in-1983.html](https://www.schneier.com/blog/archives/2023/01/kevin-mitnick-hacked-california-law-in-1983.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:41:50+00:00
 - user: None

<p>Article URL: <a href="https://www.schneier.com/blog/archives/2023/01/kevin-mitnick-hacked-california-law-in-1983.html">https://www.schneier.com/blog/archives/2023/01/kevin-mitnick-hacked-california-law-in-1983.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551569">https://news.ycombinator.com/item?id=34551569</a></p>
<p>Points: 22</p>
<p># Comments: 11</p>

## Wizards of the Coast Releases SRD Under Creative Commons License
 - [https://www.dndbeyond.com/posts/1439-ogl-1-0a-creative-commons](https://www.dndbeyond.com/posts/1439-ogl-1-0a-creative-commons)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:40:35+00:00
 - user: None

<p>Article URL: <a href="https://www.dndbeyond.com/posts/1439-ogl-1-0a-creative-commons">https://www.dndbeyond.com/posts/1439-ogl-1-0a-creative-commons</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551552">https://news.ycombinator.com/item?id=34551552</a></p>
<p>Points: 74</p>
<p># Comments: 20</p>

## Saving millions on logging: Finding relevant savings
 - [https://product.hubspot.com/blog/savings-logging-part1](https://product.hubspot.com/blog/savings-logging-part1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:21:06+00:00
 - user: None

<p>Article URL: <a href="https://product.hubspot.com/blog/savings-logging-part1">https://product.hubspot.com/blog/savings-logging-part1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551290">https://news.ycombinator.com/item?id=34551290</a></p>
<p>Points: 14</p>
<p># Comments: 1</p>

## Bell Telephone launched a mobile phone during the 1940s
 - [https://www.openculture.com/2023/01/bell-telephone-launched-a-mobile-phone-during-the-1940s.html](https://www.openculture.com/2023/01/bell-telephone-launched-a-mobile-phone-during-the-1940s.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:17:20+00:00
 - user: None

<p>Article URL: <a href="https://www.openculture.com/2023/01/bell-telephone-launched-a-mobile-phone-during-the-1940s.html">https://www.openculture.com/2023/01/bell-telephone-launched-a-mobile-phone-during-the-1940s.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551246">https://news.ycombinator.com/item?id=34551246</a></p>
<p>Points: 9</p>
<p># Comments: 5</p>

## Code Lifespan
 - [https://xkcd.com/2730/](https://xkcd.com/2730/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:14:24+00:00
 - user: None

<p>Article URL: <a href="https://xkcd.com/2730/">https://xkcd.com/2730/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551207">https://news.ycombinator.com/item?id=34551207</a></p>
<p>Points: 13</p>
<p># Comments: 3</p>

## Show HN: Search – inside – 15,000 pitchdeck slides
 - [https://www.searchthedeck.com/](https://www.searchthedeck.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 20:00:12+00:00
 - user: None

<p>Article URL: <a href="https://www.searchthedeck.com/">https://www.searchthedeck.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34551000">https://news.ycombinator.com/item?id=34551000</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Pandas Illustrated: The Definitive Visual Guide to Pandas
 - [https://scribe.citizen4.eu/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43](https://scribe.citizen4.eu/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:41:40+00:00
 - user: None

<p>Article URL: <a href="https://scribe.citizen4.eu/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43">https://scribe.citizen4.eu/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550735">https://news.ycombinator.com/item?id=34550735</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Pandas Illustrated: Visual Guide to Pandas
 - [https://betterprogramming.pub/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43?sk=50184a8a8b46ffca16664f6529741abc](https://betterprogramming.pub/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43?sk=50184a8a8b46ffca16664f6529741abc)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:41:40+00:00
 - user: None

<p>Article URL: <a href="https://betterprogramming.pub/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43?sk=50184a8a8b46ffca16664f6529741abc">https://betterprogramming.pub/pandas-illustrated-the-definitive-visual-guide-to-pandas-c31fa921a43?sk=50184a8a8b46ffca16664f6529741abc</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550735">https://news.ycombinator.com/item?id=34550735</a></p>
<p>Points: 140</p>
<p># Comments: 31</p>

## $6.96B was raised by private longevity companies in 2022
 - [https://spannr.com/reports/2022-longevity-funding](https://spannr.com/reports/2022-longevity-funding)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:32:47+00:00
 - user: None

<p>Article URL: <a href="https://spannr.com/reports/2022-longevity-funding">https://spannr.com/reports/2022-longevity-funding</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550632">https://news.ycombinator.com/item?id=34550632</a></p>
<p>Points: 41</p>
<p># Comments: 14</p>

## Elite for Emacs
 - [https://www.salkosuo.net/2015/10/22/elite-for-emacs.html](https://www.salkosuo.net/2015/10/22/elite-for-emacs.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:28:11+00:00
 - user: None

<p>Article URL: <a href="https://www.salkosuo.net/2015/10/22/elite-for-emacs.html">https://www.salkosuo.net/2015/10/22/elite-for-emacs.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550574">https://news.ycombinator.com/item?id=34550574</a></p>
<p>Points: 47</p>
<p># Comments: 6</p>

## Tell HN: GitHub now blocks aliased email addresses
 - [https://news.ycombinator.com/item?id=34550418](https://news.ycombinator.com/item?id=34550418)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:17:11+00:00
 - user: None

<p>"Our spam detecting systems flagged your account because of the email address you used to register the account. Temporary/aliased email addresses are not permitted for use on GitHub accounts."<p>"Before we can remove the flag we need you to add a personal, non-disposable email address and then verify that address. You also need to remove the temporary/aliased email from the account."<p>Bad news for SimpleLogin and AnonAddy users.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550418">https://news.ycombinator.com/item?id=34550418</a></p>
<p>Points: 16</p>
<p># Comments: 13</p>

## Transcending Scaling Laws with 0.1% Extra Compute
 - [https://arxiv.org/abs/2210.11399](https://arxiv.org/abs/2210.11399)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 19:00:15+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2210.11399">https://arxiv.org/abs/2210.11399</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34550191">https://news.ycombinator.com/item?id=34550191</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The ER has become a sanctuary for society’s unmet needs
 - [https://www.seattletimes.com/opinion/the-er-has-become-a-sanctuary-for-societys-unmet-needs/](https://www.seattletimes.com/opinion/the-er-has-become-a-sanctuary-for-societys-unmet-needs/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 18:08:01+00:00
 - user: None

<p>Article URL: <a href="https://www.seattletimes.com/opinion/the-er-has-become-a-sanctuary-for-societys-unmet-needs/">https://www.seattletimes.com/opinion/the-er-has-become-a-sanctuary-for-societys-unmet-needs/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549507">https://news.ycombinator.com/item?id=34549507</a></p>
<p>Points: 50</p>
<p># Comments: 30</p>

## Show HN: ML paper podcast generator using GPT and Tortoise-TTS
 - [https://scribepod.substack.com/p/scribepod-1](https://scribepod.substack.com/p/scribepod-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:59:34+00:00
 - user: None

<p>I built a pipeline that turns tweets about ML papers into a podcast.<p>Code's up here. Happy hacking. <a href="https://github.com/yacineMTB/scribepod">https://github.com/yacineMTB/scribepod</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549402">https://news.ycombinator.com/item?id=34549402</a></p>
<p>Points: 31</p>
<p># Comments: 11</p>

## Natural language is the lazy user interface
 - [https://austinhenley.com/blog/naturallanguageui.html](https://austinhenley.com/blog/naturallanguageui.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:57:36+00:00
 - user: None

<p>Article URL: <a href="https://austinhenley.com/blog/naturallanguageui.html">https://austinhenley.com/blog/naturallanguageui.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549378">https://news.ycombinator.com/item?id=34549378</a></p>
<p>Points: 76</p>
<p># Comments: 78</p>

## Father, Son and Double Helix (2015)
 - [https://openthemagazine.com/features/living/father-son-and-the-double-helix/](https://openthemagazine.com/features/living/father-son-and-the-double-helix/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:53:26+00:00
 - user: None

<p>Article URL: <a href="https://openthemagazine.com/features/living/father-son-and-the-double-helix/">https://openthemagazine.com/features/living/father-son-and-the-double-helix/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549307">https://news.ycombinator.com/item?id=34549307</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Notes on Craft
 - [https://granta.com/notes-on-craft-lee-lai/](https://granta.com/notes-on-craft-lee-lai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:53:10+00:00
 - user: None

<p>Article URL: <a href="https://granta.com/notes-on-craft-lee-lai/">https://granta.com/notes-on-craft-lee-lai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549296">https://news.ycombinator.com/item?id=34549296</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## The Science of Sword-Swallowing
 - [https://twistedphysics.typepad.com/cocktail_party_physics/2007/10/by-the-sword.html](https://twistedphysics.typepad.com/cocktail_party_physics/2007/10/by-the-sword.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:52:51+00:00
 - user: None

<p>Article URL: <a href="https://twistedphysics.typepad.com/cocktail_party_physics/2007/10/by-the-sword.html">https://twistedphysics.typepad.com/cocktail_party_physics/2007/10/by-the-sword.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549288">https://news.ycombinator.com/item?id=34549288</a></p>
<p>Points: 49</p>
<p># Comments: 11</p>

## Nobody Has My Condition but Me
 - [https://www.newyorker.com/magazine/2023/01/30/nobody-has-my-condition-but-me](https://www.newyorker.com/magazine/2023/01/30/nobody-has-my-condition-but-me)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:44:06+00:00
 - user: None

<p>Article URL: <a href="https://www.newyorker.com/magazine/2023/01/30/nobody-has-my-condition-but-me">https://www.newyorker.com/magazine/2023/01/30/nobody-has-my-condition-but-me</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34549162">https://news.ycombinator.com/item?id=34549162</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Show HN: Sync’ing data to your customer’s Google Sheets
 - [https://news.ycombinator.com/item?id=34548663](https://news.ycombinator.com/item?id=34548663)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 17:15:36+00:00
 - user: None

<p>Hey HN! Charles here from Prequel (https://prequel.co). We just launched the ability to sync data from your own app/db/data warehouse to any of your customer’s Google Sheets, CSV, or Excel – and I wanted to share a bit more about how we built the Google Sheets integration. If you’re curious, see here for a quick GIF demo of our Google Sheets destination: https://storage.googleapis.com/hn_asset/Prequel_GoogleSheetsDemo.webp.<p>Quick background on us: we make it easy to integrate with and sync data to data warehouses. Problem is, there are plenty of folks who want access to their data, but don’t have or don’t know how to use a data warehouse. For example, FP&amp;A teams, customer success teams, etc.<p>To get around that, we added some non-db destinations to Prequel: Google Sheets, CSV, and Excel. We had to rework some core assumptions in order to get Google Sheets to work.<p>By default, Prequel does incremental syncs, meaning we only write net new or updated data to the destination. To avoid duplicate rows, we typically perform those writes as upserts – this is pretty trivial in most SQL dialects. But since Google Sheets is not actually a db, it doesn’t have a concept of upserts, and we had to get creative.<p>We had two options: either force all Google Sheets syncs to be “full refreshes” every time (eg grab all the data and brute-force write it to the sheet). The downside is, this can get expensive quickly for our customers, especially when data gets refreshed at higher frequencies (eg every 15 minutes).<p>The other, and better, option was to figure out how to perform upserts in Sheets. To do so, we read the data from the sheet we’re about to write to into memory. We store it in a large map by primary key. We reconcile it with the data we’re about to write. We then dump the contents of the map back to the sheet. In order to make the user experience smoother, we also sort the rows by timestamp before writing it back. This guarantees that we don’t accidentally shuffle rows with every transfer, which might leave users feeling confused.<p>“Wait, you keep all the data in memory… so how do you avoid blowing up your pods?”. Great question! Luckily, Google Sheets has pretty stringent cell / row size limits. This allows us to restrict the amount of data that can be written to these destinations (we throw a nice error if someone tries to sync too much data), and thereby also guarantees that we don’t OOM our poor pods.<p>Another interesting problem we had to solve was auth: how do we let users give us access to their sheets in a way that both feels intuitive and upholds strong security guarantees? It seemed like the cleanest user experience was to ask the spreadsheet owner to share access with a new user – much like they would with any real human user. To make this possible without creating a superuser that would have access to _all_ the sheets, we had to programmatically generate a different user for each of our customers. We do this via the GCP IAM API, creating a new service account every time. We then auth into the sheet through this service account.<p>One last fun UX challenge to think through was how to prevent users from editing the “golden” data we just sync’d. It might not be immediately clear to them that this data is meant as a source of truth record, rather than a playground. To get around this, we create protected ranges and prevent them from editing the sheets we write to. Sheets even adds a little padlock icon to the relevant sheets, which helps convey the “don’t mess with this”.<p>If you want to take it for a spin, you can sign up on our site or reach us at hello (at) prequel.co. Happy to answer any other questions about the design!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34548663">https://news.ycombinator.com/item?id=34548663</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Show HN: YouTube Summaries Using GPT
 - [https://www.eightify.app/](https://www.eightify.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 16:45:25+00:00
 - user: None

<p>Hi, I'm Alex. I created Eightify to take my mind off things during a weekend, but I was surprised that my friends were genuinely interested in it. I kept going, and now it's been nine weeks since I started.<p>I got the idea to summarize videos when my friend sent me a lengthy video again. This happens to me often; the video title is so enticing, and then it turns out to be nothing. I had been working with GPT for 6 months by the time, so everything looked like a nail to me.<p>It's a Chrome extension, and I'm offering 5 free tries for videos under an hour. After that, you have to buy a package. I'm not making money yet, but it pays for GPT, which can be pricey for long texts. And some of Lex Fridman's podcasts are incredibly long.<p>I'm one of those overly optimistic people when it comes to GPT. So many people tell me, "Oh, it doesn't solve this problem yet; let's wait for GPT-4". The real issue is that their prompts are usually inadequate, and it takes you anywhere from two days to two weeks to make it work. Testing and debugging, preferably with automated tests. I believe you can solve many problems with GPT-3 already.<p>I would love to answer any questions you have about the product and GPT in general. I've invested at least 500 hours into prompt engineering. And I enjoy watching other people's prompts too!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34548154">https://news.ycombinator.com/item?id=34548154</a></p>
<p>Points: 30</p>
<p># Comments: 19</p>

## AWS Purity Test
 - [https://www.awspuritytest.com/](https://www.awspuritytest.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 16:40:30+00:00
 - user: None

<p>Article URL: <a href="https://www.awspuritytest.com/">https://www.awspuritytest.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34548077">https://news.ycombinator.com/item?id=34548077</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## “They wanted my Instagram handle, and somehow they've now got it.”
 - [https://mastodon.social/@alexjsp/109760277713815857](https://mastodon.social/@alexjsp/109760277713815857)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 16:23:22+00:00
 - user: None

<p>Article URL: <a href="https://mastodon.social/@alexjsp/109760277713815857">https://mastodon.social/@alexjsp/109760277713815857</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547773">https://news.ycombinator.com/item?id=34547773</a></p>
<p>Points: 32</p>
<p># Comments: 3</p>

## Classified Death Star documents discovered in Darth Vader’s garage
 - [https://www.screen-idle.com/classified-death-star-documents-discovered-in-darth-vaders-garage/](https://www.screen-idle.com/classified-death-star-documents-discovered-in-darth-vaders-garage/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 16:17:19+00:00
 - user: None

<p>Article URL: <a href="https://www.screen-idle.com/classified-death-star-documents-discovered-in-darth-vaders-garage/">https://www.screen-idle.com/classified-death-star-documents-discovered-in-darth-vaders-garage/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547687">https://news.ycombinator.com/item?id=34547687</a></p>
<p>Points: 20</p>
<p># Comments: 3</p>

## Godot 4.0 beta 16: Initial .NET 7 support
 - [https://godotengine.org/article/dev-snapshot-godot-4-0-beta-16/](https://godotengine.org/article/dev-snapshot-godot-4-0-beta-16/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 16:13:48+00:00
 - user: None

<p>Article URL: <a href="https://godotengine.org/article/dev-snapshot-godot-4-0-beta-16/">https://godotengine.org/article/dev-snapshot-godot-4-0-beta-16/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547637">https://news.ycombinator.com/item?id=34547637</a></p>
<p>Points: 49</p>
<p># Comments: 18</p>

## Just know stuff. (Or, how to achieve success in a machine learning PhD)
 - [https://kidger.site/thoughts/just-know-stuff/](https://kidger.site/thoughts/just-know-stuff/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:50:07+00:00
 - user: None

<p>Article URL: <a href="https://kidger.site/thoughts/just-know-stuff/">https://kidger.site/thoughts/just-know-stuff/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547358">https://news.ycombinator.com/item?id=34547358</a></p>
<p>Points: 50</p>
<p># Comments: 5</p>

## The Hostile Forces of Beijing
 - [https://scholars-stage.org/candlelight-vigils-and-hostile-forces/](https://scholars-stage.org/candlelight-vigils-and-hostile-forces/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:44:33+00:00
 - user: None

<p>Article URL: <a href="https://scholars-stage.org/candlelight-vigils-and-hostile-forces/">https://scholars-stage.org/candlelight-vigils-and-hostile-forces/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547294">https://news.ycombinator.com/item?id=34547294</a></p>
<p>Points: 22</p>
<p># Comments: 4</p>

## Ask HN: Those making $0/month or less on side projects – Show and tell
 - [https://news.ycombinator.com/item?id=34547265](https://news.ycombinator.com/item?id=34547265)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:42:30+00:00
 - user: None

<p>Not sure about anyone else, but I enjoy seeing the posts on side projects making money. Often while reading all of the comments I find new products or services I want, so I buy them and contribute further to that hustle's success. But for every hacker making $100 or more per month with their idea, there are hundreds more working hard, making nothing, struggling to get started. Does that describe you? Maybe the community just needs to hear about what you're offering, what you've been working on. If you've got something cool that has not yet gained traction, maybe it just needs to be seen by a gaggle of like-minded hackers and geeks. So share!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547265">https://news.ycombinator.com/item?id=34547265</a></p>
<p>Points: 89</p>
<p># Comments: 76</p>

## Forking Chrome to render in a terminal
 - [https://fathy.fr/carbonyl](https://fathy.fr/carbonyl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:42:00+00:00
 - user: None

<p>Article URL: <a href="https://fathy.fr/carbonyl">https://fathy.fr/carbonyl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547259">https://news.ycombinator.com/item?id=34547259</a></p>
<p>Points: 78</p>
<p># Comments: 14</p>

## Passenger Uses AirTags, Discovers Airline Donated Their Bags to Charity
 - [https://www.blogto.com/travel/2023/01/ontario-couple-tracking-lost-baggage-shocked-air-canada-gave-it-charity/](https://www.blogto.com/travel/2023/01/ontario-couple-tracking-lost-baggage-shocked-air-canada-gave-it-charity/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:38:31+00:00
 - user: None

<p>Article URL: <a href="https://www.blogto.com/travel/2023/01/ontario-couple-tracking-lost-baggage-shocked-air-canada-gave-it-charity/">https://www.blogto.com/travel/2023/01/ontario-couple-tracking-lost-baggage-shocked-air-canada-gave-it-charity/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547209">https://news.ycombinator.com/item?id=34547209</a></p>
<p>Points: 79</p>
<p># Comments: 41</p>

## Show HN: Interact with the terminal in plain English using GPT-3
 - [https://github.com/dylanjcastillo/shell-genie](https://github.com/dylanjcastillo/shell-genie)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:23:34+00:00
 - user: None

<p>Article URL: <a href="https://github.com/dylanjcastillo/shell-genie">https://github.com/dylanjcastillo/shell-genie</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34547015">https://news.ycombinator.com/item?id=34547015</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Enough Empty Office Space for 160k People in San Francisco
 - [https://socketsite.com/archives/2023/01/enough-empty-office-space-for-160000-employees-in-san-francisco.html](https://socketsite.com/archives/2023/01/enough-empty-office-space-for-160000-employees-in-san-francisco.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:18:39+00:00
 - user: None

<p>Article URL: <a href="https://socketsite.com/archives/2023/01/enough-empty-office-space-for-160000-employees-in-san-francisco.html">https://socketsite.com/archives/2023/01/enough-empty-office-space-for-160000-employees-in-san-francisco.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34546966">https://news.ycombinator.com/item?id=34546966</a></p>
<p>Points: 7</p>
<p># Comments: 6</p>

## ChatGPT and the Enshittening of Knowledge
 - [https://castlebridge.ie/insights/chatgpt-and-the-enshittening-of-knowledge/](https://castlebridge.ie/insights/chatgpt-and-the-enshittening-of-knowledge/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 15:07:44+00:00
 - user: None

<p>Article URL: <a href="https://castlebridge.ie/insights/chatgpt-and-the-enshittening-of-knowledge/">https://castlebridge.ie/insights/chatgpt-and-the-enshittening-of-knowledge/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34546846">https://news.ycombinator.com/item?id=34546846</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## OsmAnd (OpenStreetMap) 4.3 for Android is fast with a new rendering engine
 - [https://osmand.net/blog/osmand-android-4-3-released/](https://osmand.net/blog/osmand-android-4-3-released/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 13:49:43+00:00
 - user: None

<p>Article URL: <a href="https://osmand.net/blog/osmand-android-4-3-released/">https://osmand.net/blog/osmand-android-4-3-released/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545961">https://news.ycombinator.com/item?id=34545961</a></p>
<p>Points: 37</p>
<p># Comments: 7</p>

## Accessible hamburger buttons without JavaScript
 - [https://www.pausly.app/blog/accessible-hamburger-buttons-without-javascript](https://www.pausly.app/blog/accessible-hamburger-buttons-without-javascript)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 13:48:14+00:00
 - user: None

<p>Article URL: <a href="https://www.pausly.app/blog/accessible-hamburger-buttons-without-javascript">https://www.pausly.app/blog/accessible-hamburger-buttons-without-javascript</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545943">https://news.ycombinator.com/item?id=34545943</a></p>
<p>Points: 17</p>
<p># Comments: 13</p>

## Experts warn of steep increase in Java costs
 - [https://www.theregister.com/2023/01/27/oracle_java_licensing_change/](https://www.theregister.com/2023/01/27/oracle_java_licensing_change/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 12:44:54+00:00
 - user: None

<p>Article URL: <a href="https://www.theregister.com/2023/01/27/oracle_java_licensing_change/">https://www.theregister.com/2023/01/27/oracle_java_licensing_change/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545369">https://news.ycombinator.com/item?id=34545369</a></p>
<p>Points: 16</p>
<p># Comments: 17</p>

## The Tilde Text Editor
 - [https://github.com/gphalkes/tilde](https://github.com/gphalkes/tilde)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 12:00:39+00:00
 - user: None

<p>Article URL: <a href="https://github.com/gphalkes/tilde">https://github.com/gphalkes/tilde</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545086">https://news.ycombinator.com/item?id=34545086</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## Erlang's not about lightweight processes and message passing
 - [https://github.com/stevana/armstrong-distributed-systems/blob/main/docs/erlang-is-not-about.md](https://github.com/stevana/armstrong-distributed-systems/blob/main/docs/erlang-is-not-about.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:56:12+00:00
 - user: None

<p>Article URL: <a href="https://github.com/stevana/armstrong-distributed-systems/blob/main/docs/erlang-is-not-about.md">https://github.com/stevana/armstrong-distributed-systems/blob/main/docs/erlang-is-not-about.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545061">https://news.ycombinator.com/item?id=34545061</a></p>
<p>Points: 82</p>
<p># Comments: 9</p>

## Apple’s Mac security is so good, it’s sending used M1 MacBooks to the scrap heap
 - [https://www.macworld.com/article/1485237/mac-security-t2-chip-macbook-activation-lock.html](https://www.macworld.com/article/1485237/mac-security-t2-chip-macbook-activation-lock.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:50:01+00:00
 - user: None

<p>Article URL: <a href="https://www.macworld.com/article/1485237/mac-security-t2-chip-macbook-activation-lock.html">https://www.macworld.com/article/1485237/mac-security-t2-chip-macbook-activation-lock.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545028">https://news.ycombinator.com/item?id=34545028</a></p>
<p>Points: 11</p>
<p># Comments: 3</p>

## Attacker with access to XML config can trigger keepass.exe to obtain passwords
 - [https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-24055](https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-24055)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:47:52+00:00
 - user: None

<p>Article URL: <a href="https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-24055">https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2023-24055</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34545010">https://news.ycombinator.com/item?id=34545010</a></p>
<p>Points: 32</p>
<p># Comments: 35</p>

## Reverse Engineering Programs with Unknown Instruction Sets [pdf]
 - [https://www.recon.cx/2012/schedule/attachments/40_Chernov-Troshina.pdf](https://www.recon.cx/2012/schedule/attachments/40_Chernov-Troshina.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:45:43+00:00
 - user: None

<p>Article URL: <a href="https://www.recon.cx/2012/schedule/attachments/40_Chernov-Troshina.pdf">https://www.recon.cx/2012/schedule/attachments/40_Chernov-Troshina.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544994">https://news.ycombinator.com/item?id=34544994</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## SirTunnel, a Personal Ngrok Alternative
 - [https://eighty-twenty.org/2023/01/27/sirtunnel-personal-ngrok](https://eighty-twenty.org/2023/01/27/sirtunnel-personal-ngrok)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:03:51+00:00
 - user: None

<p>Article URL: <a href="https://eighty-twenty.org/2023/01/27/sirtunnel-personal-ngrok">https://eighty-twenty.org/2023/01/27/sirtunnel-personal-ngrok</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544745">https://news.ycombinator.com/item?id=34544745</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## BuzzFeed says it will use AI to help create content, stock jumps 150% – CNN
 - [https://www.cnn.com/2023/01/26/media/buzzfeed-ai-content-creation/index.html](https://www.cnn.com/2023/01/26/media/buzzfeed-ai-content-creation/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 11:03:46+00:00
 - user: None

<p>Article URL: <a href="https://www.cnn.com/2023/01/26/media/buzzfeed-ai-content-creation/index.html">https://www.cnn.com/2023/01/26/media/buzzfeed-ai-content-creation/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544744">https://news.ycombinator.com/item?id=34544744</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Urgent public health warning issued over lost radioactive capsule
 - [https://www.abc.net.au/news/2023-01-27/radioactive-capsule-lost-in-wa-emergency-public-health-warning/101901472](https://www.abc.net.au/news/2023-01-27/radioactive-capsule-lost-in-wa-emergency-public-health-warning/101901472)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 10:58:49+00:00
 - user: None

<p>Article URL: <a href="https://www.abc.net.au/news/2023-01-27/radioactive-capsule-lost-in-wa-emergency-public-health-warning/101901472">https://www.abc.net.au/news/2023-01-27/radioactive-capsule-lost-in-wa-emergency-public-health-warning/101901472</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544709">https://news.ycombinator.com/item?id=34544709</a></p>
<p>Points: 38</p>
<p># Comments: 8</p>

## Text-to-4D Dynamic Scene Generation
 - [https://make-a-video3d.github.io/](https://make-a-video3d.github.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 10:41:19+00:00
 - user: None

<p>Article URL: <a href="https://make-a-video3d.github.io/">https://make-a-video3d.github.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544630">https://news.ycombinator.com/item?id=34544630</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## 97% of American adults own a cellphone or smartphone
 - [https://www.pewresearch.org/internet/fact-sheet/mobile/](https://www.pewresearch.org/internet/fact-sheet/mobile/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 10:39:42+00:00
 - user: None

<p>Article URL: <a href="https://www.pewresearch.org/internet/fact-sheet/mobile/">https://www.pewresearch.org/internet/fact-sheet/mobile/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544621">https://news.ycombinator.com/item?id=34544621</a></p>
<p>Points: 16</p>
<p># Comments: 15</p>

## How we’re approaching AI-generated writing on Medium
 - [https://blog.medium.com/how-were-approaching-ai-generated-writing-on-medium-16ee8cb3bc89](https://blog.medium.com/how-were-approaching-ai-generated-writing-on-medium-16ee8cb3bc89)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 10:17:03+00:00
 - user: None

<p>Article URL: <a href="https://blog.medium.com/how-were-approaching-ai-generated-writing-on-medium-16ee8cb3bc89">https://blog.medium.com/how-were-approaching-ai-generated-writing-on-medium-16ee8cb3bc89</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544487">https://news.ycombinator.com/item?id=34544487</a></p>
<p>Points: 8</p>
<p># Comments: 5</p>

## Omega-3s: Are “Brain-Boosting” Effects Scientifically Backed?
 - [https://abouttolearn.substack.com/p/omega-3s-are-brain-boosting-effects](https://abouttolearn.substack.com/p/omega-3s-are-brain-boosting-effects)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 09:56:03+00:00
 - user: None

<p>Article URL: <a href="https://abouttolearn.substack.com/p/omega-3s-are-brain-boosting-effects">https://abouttolearn.substack.com/p/omega-3s-are-brain-boosting-effects</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544367">https://news.ycombinator.com/item?id=34544367</a></p>
<p>Points: 20</p>
<p># Comments: 7</p>

## Intel discontinues pathfinder for RISC-V program
 - [https://pathfinder.intel.com](https://pathfinder.intel.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 09:43:02+00:00
 - user: None

<p>Article URL: <a href="https://pathfinder.intel.com">https://pathfinder.intel.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544295">https://news.ycombinator.com/item?id=34544295</a></p>
<p>Points: 15</p>
<p># Comments: 11</p>

## The Mystery of the Dune Font
 - [https://fontsinuse.com/uses/43515/the-mystery-of-the-dune-font](https://fontsinuse.com/uses/43515/the-mystery-of-the-dune-font)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 09:01:23+00:00
 - user: None

<p>Article URL: <a href="https://fontsinuse.com/uses/43515/the-mystery-of-the-dune-font">https://fontsinuse.com/uses/43515/the-mystery-of-the-dune-font</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544074">https://news.ycombinator.com/item?id=34544074</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Contracts you should never sign
 - [https://vadimkravcenko.com/shorts/contracts-you-should-never-sign/](https://vadimkravcenko.com/shorts/contracts-you-should-never-sign/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 08:48:52+00:00
 - user: None

<p>Article URL: <a href="https://vadimkravcenko.com/shorts/contracts-you-should-never-sign/">https://vadimkravcenko.com/shorts/contracts-you-should-never-sign/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34544008">https://news.ycombinator.com/item?id=34544008</a></p>
<p>Points: 28</p>
<p># Comments: 7</p>

## Foliate – A simple and modern eBook viewer for Linux desktops
 - [https://johnfactotum.github.io/foliate/](https://johnfactotum.github.io/foliate/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 08:29:50+00:00
 - user: None

<p>Article URL: <a href="https://johnfactotum.github.io/foliate/">https://johnfactotum.github.io/foliate/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543912">https://news.ycombinator.com/item?id=34543912</a></p>
<p>Points: 21</p>
<p># Comments: 8</p>

## Ask HN: EU Bank with Good API?
 - [https://news.ycombinator.com/item?id=34543832](https://news.ycombinator.com/item?id=34543832)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 08:17:11+00:00
 - user: None

<p>I am working on a service that connects buyers and sellers and will be doing plenty of pay-outs. The company is based in EU and EUR has been chosen as settling currency. I am therefore looking for an EU-base bank with good API to automate the necessary processes. So far, local banks are very bad in this regard. I looked at Wise and Revolut but they won't give me access to the sandbox environment to test and evaluate their APIs without signing up for paid business plan straight away, which is simply a no-go. Can you therefore recommend a bank with good API? By good I mean that it at least has a concept of idempotency and nonce and webhooks. I really don't need that much but the state of things is rotten.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543832">https://news.ycombinator.com/item?id=34543832</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Show HN: Pashword – Hashed Password Calculator
 - [https://pashword.app](https://pashword.app)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 07:55:55+00:00
 - user: None

<p>Article URL: <a href="https://pashword.app">https://pashword.app</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543700">https://news.ycombinator.com/item?id=34543700</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## Deepfaked Tom Cruise and Paris Hilton
 - [https://old.reddit.com/r/DeepFakesSFW/comments/10meypl/deepfaked_tom_cruise_and_paris_hilton_what_do_you/](https://old.reddit.com/r/DeepFakesSFW/comments/10meypl/deepfaked_tom_cruise_and_paris_hilton_what_do_you/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 07:21:02+00:00
 - user: None

<p>Article URL: <a href="https://old.reddit.com/r/DeepFakesSFW/comments/10meypl/deepfaked_tom_cruise_and_paris_hilton_what_do_you/">https://old.reddit.com/r/DeepFakesSFW/comments/10meypl/deepfaked_tom_cruise_and_paris_hilton_what_do_you/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543521">https://news.ycombinator.com/item?id=34543521</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## “Computers enable fantasies” – the continued relevance of Weizenbaum’s warnings
 - [https://librarianshipwreck.wordpress.com/2023/01/26/computers-enable-fantasies-on-the-continued-relevance-of-weizenbaums-warnings/](https://librarianshipwreck.wordpress.com/2023/01/26/computers-enable-fantasies-on-the-continued-relevance-of-weizenbaums-warnings/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 07:20:55+00:00
 - user: None

<p>Article URL: <a href="https://librarianshipwreck.wordpress.com/2023/01/26/computers-enable-fantasies-on-the-continued-relevance-of-weizenbaums-warnings/">https://librarianshipwreck.wordpress.com/2023/01/26/computers-enable-fantasies-on-the-continued-relevance-of-weizenbaums-warnings/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543518">https://news.ycombinator.com/item?id=34543518</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Enso (YC S21) Is Hiring TypeScript Developer
 - [https://www.ycombinator.com/companies/enso/jobs/yON8exA-senior-typescript-developer](https://www.ycombinator.com/companies/enso/jobs/yON8exA-senior-typescript-developer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 07:00:18+00:00
 - user: None

<p>Article URL: <a href="https://www.ycombinator.com/companies/enso/jobs/yON8exA-senior-typescript-developer">https://www.ycombinator.com/companies/enso/jobs/yON8exA-senior-typescript-developer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34543419">https://news.ycombinator.com/item?id=34543419</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Lytro Unlock – Making a bad camera slightly better
 - [https://github.com/ea/lytro_unlock](https://github.com/ea/lytro_unlock)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 05:48:52+00:00
 - user: None

<p>Article URL: <a href="https://github.com/ea/lytro_unlock">https://github.com/ea/lytro_unlock</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34542993">https://news.ycombinator.com/item?id=34542993</a></p>
<p>Points: 32</p>
<p># Comments: 3</p>

## Ask HN: Right to Repair for Software?
 - [https://news.ycombinator.com/item?id=34542824](https://news.ycombinator.com/item?id=34542824)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 05:26:33+00:00
 - user: None

<p>How would you implement a right to repair for software in 2023?<p>Perhaps you could change copyright law to require either public source code or source code escrow before software could be eligible for copyright protection. Plus some default rights, like right to modification, rebuild and reinstallation for individuals.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34542824">https://news.ycombinator.com/item?id=34542824</a></p>
<p>Points: 17</p>
<p># Comments: 12</p>

## Show HN: Chrome extension to close Zoom/Notion tabs after launching desktop app
 - [https://chrome.google.com/webstore/detail/goodnight-tabs/paichadkkbhdmkngdmkgmefiabjjcaai](https://chrome.google.com/webstore/detail/goodnight-tabs/paichadkkbhdmkngdmkgmefiabjjcaai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 03:43:54+00:00
 - user: None

<p>Hi HN! I use the desktop versions of Zoom, Notion, and Asana, so at the end of the day, I have a ton of Chrome tabs left over from these services launching their apps. I threw together a little extension to clean these tabs up.<p>Do folks tend to use the browser versions of these apps? Or are there other sites that this extension should support?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34542191">https://news.ycombinator.com/item?id=34542191</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The Galaga no-fire-cheat mystery (2012)
 - [https://jasoneckert.github.io/myblog/the-galaga-no-fire-cheat-mystery/](https://jasoneckert.github.io/myblog/the-galaga-no-fire-cheat-mystery/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 03:21:39+00:00
 - user: None

<p>Article URL: <a href="https://jasoneckert.github.io/myblog/the-galaga-no-fire-cheat-mystery/">https://jasoneckert.github.io/myblog/the-galaga-no-fire-cheat-mystery/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34542064">https://news.ycombinator.com/item?id=34542064</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Apple: The only big tech giant going against the job cuts tide
 - [https://blog.pragmaticengineer.com/apple-job-cuts-tide/](https://blog.pragmaticengineer.com/apple-job-cuts-tide/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 03:12:12+00:00
 - user: None

<p>Article URL: <a href="https://blog.pragmaticengineer.com/apple-job-cuts-tide/">https://blog.pragmaticengineer.com/apple-job-cuts-tide/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34542013">https://news.ycombinator.com/item?id=34542013</a></p>
<p>Points: 53</p>
<p># Comments: 29</p>

## The Python Paradox
 - [http://www.paulgraham.com/pypar.html](http://www.paulgraham.com/pypar.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 02:57:48+00:00
 - user: None

<p>Article URL: <a href="http://www.paulgraham.com/pypar.html">http://www.paulgraham.com/pypar.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541933">https://news.ycombinator.com/item?id=34541933</a></p>
<p>Points: 3</p>
<p># Comments: 2</p>

## A Fix-It-Yourself Trend for Appliances (1983)
 - [https://www.nytimes.com/1983/02/19/style/a-fix-it-yourself-trend-for-appliances.html](https://www.nytimes.com/1983/02/19/style/a-fix-it-yourself-trend-for-appliances.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 02:56:34+00:00
 - user: None

<p>Article URL: <a href="https://www.nytimes.com/1983/02/19/style/a-fix-it-yourself-trend-for-appliances.html">https://www.nytimes.com/1983/02/19/style/a-fix-it-yourself-trend-for-appliances.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541926">https://news.ycombinator.com/item?id=34541926</a></p>
<p>Points: 20</p>
<p># Comments: 17</p>

## MusicLM: Generating music from text
 - [https://arxiv.org/abs/2301.11325](https://arxiv.org/abs/2301.11325)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 02:44:37+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2301.11325">https://arxiv.org/abs/2301.11325</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541836">https://news.ycombinator.com/item?id=34541836</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Rust's Ugly Syntax
 - [https://matklad.github.io/2023/01/26/rusts-ugly-syntax.html](https://matklad.github.io/2023/01/26/rusts-ugly-syntax.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 02:20:34+00:00
 - user: None

<p>Article URL: <a href="https://matklad.github.io/2023/01/26/rusts-ugly-syntax.html">https://matklad.github.io/2023/01/26/rusts-ugly-syntax.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541695">https://news.ycombinator.com/item?id=34541695</a></p>
<p>Points: 51</p>
<p># Comments: 27</p>

## MusicLM: Generating Music from Text
 - [https://google-research.github.io/seanet/musiclm/examples/](https://google-research.github.io/seanet/musiclm/examples/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 02:20:26+00:00
 - user: None

<p>Article URL: <a href="https://google-research.github.io/seanet/musiclm/examples/">https://google-research.github.io/seanet/musiclm/examples/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541693">https://news.ycombinator.com/item?id=34541693</a></p>
<p>Points: 31</p>
<p># Comments: 2</p>

## Sci-Hub: knowledge as a human right
 - [https://sci-hub.ru/](https://sci-hub.ru/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 01:52:22+00:00
 - user: rumpel
 - tags: science

<p>Article URL: <a href="https://sci-hub.ru/">https://sci-hub.ru/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34541505">https://news.ycombinator.com/item?id=34541505</a></p>
<p>Points: 119</p>
<p># Comments: 41</p>

## Why VR/AR gets farther away as it comes into focus
 - [https://www.matthewball.vc/all/why-vrar-gets-farther-away-as-it-comes-into-focus](https://www.matthewball.vc/all/why-vrar-gets-farther-away-as-it-comes-into-focus)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-27 00:02:02+00:00
 - user: rumpel
 - tags: virtual reality,augmented reality

<p>Article URL: <a href="https://www.matthewball.vc/all/why-vrar-gets-farther-away-as-it-comes-into-focus">https://www.matthewball.vc/all/why-vrar-gets-farther-away-as-it-comes-into-focus</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34540649">https://news.ycombinator.com/item?id=34540649</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>
