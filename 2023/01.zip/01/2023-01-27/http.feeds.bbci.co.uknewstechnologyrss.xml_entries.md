# Source BBC tech, Source URL:http://feeds.bbci.co.uk/news/technology/rss.xml, Source language: en-US

## Car-sharing app offers private vehicles for hire
 - [https://www.bbc.co.uk/news/technology-64427489?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64427489?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-27 15:11:58+00:00
 - user: None

BBC Click's Nick Kwek test drives a car from a firm offering an alternative to traditional rentals.

## Lockdowns linked to tenfold rise in child sex imagery
 - [https://www.bbc.co.uk/news/technology-64415015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64415015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-27 00:51:46+00:00
 - user: None

A charity says its data highlights how predators took advantage of the worldwide Covid-19 situation.

## Hemp makes a comeback in the construction industry
 - [https://www.bbc.co.uk/news/business-63666195?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63666195?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-27 00:07:49+00:00
 - user: None

A revival of hemp cultivation in Portugal has spurred the use of hemp blocks in construction.

## Warning over risky electric blankets sold online
 - [https://www.bbc.co.uk/news/technology-64418949?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64418949?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-27 00:05:18+00:00
 - user: None

The consumer rights group Which? found products being sold online that could cause electric shocks.
