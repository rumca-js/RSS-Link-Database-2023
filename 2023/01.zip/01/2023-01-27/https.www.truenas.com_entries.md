# Source URL:https://www.truenas.com, Source language: en-US

## TrueNAS - Welcome to the Open Storage Era
 - [https://www.truenas.com/](https://www.truenas.com/)
 - RSS feed: https://www.truenas.com
 - date published: 2023-01-27 10:13:25+00:00
 - user: rumpel
 - tags: smarthome,selfhost,digital bunker

TrueNAS - Welcome to the Open Storage Era
