# Source The Washington Post - Tech, Source URL:https://feeds.washingtonpost.com/rss/business/technology, Source language: en-US

## I was hit with $1,300 in credit card fraud. Here’s how to cut your risk.
 - [https://www.washingtonpost.com/technology/2023/01/27/credit-card-fraud-prevention/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/27/credit-card-fraud-prevention/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-27 12:30:00+00:00
 - user: None

You can't completely prevent credit card fraud. But these six steps do reduce your risk.

## Musk says he met McCarthy and Jeffries to ensure Twitter is ‘fair’
 - [https://www.washingtonpost.com/politics/2023/01/27/elon-musk-twitter-mccarthy-capitol/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/politics/2023/01/27/elon-musk-twitter-mccarthy-capitol/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-27 08:36:42+00:00
 - user: None

Elon Musk said he met with House Speaker Kevin McCarthy and House Minority Leader Hakeem Jeffries to discuss ensuring Twitter “is fair to both parties.”

## Big Tech was moving cautiously on AI. Then came ChatGPT.
 - [https://www.washingtonpost.com/technology/2023/01/27/chatgpt-google-meta/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/27/chatgpt-google-meta/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-27 07:00:35+00:00
 - user: None

Google, Facebook and Microsoft have used AI in their products for years. But OpenAI's ChatGPT is stealing the limelight, forcing them to move faster.

## With Trump reinstatement, Meta finds new ways to punish world leaders
 - [https://www.washingtonpost.com/technology/2023/01/27/meta-trump-new-rules-instagram-facebook/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/27/meta-trump-new-rules-instagram-facebook/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-27 07:00:00+00:00
 - user: None

The social media giant is expanding the range of interventions that it can use to fight dangerous rhetoric from Trump and other public figures.
