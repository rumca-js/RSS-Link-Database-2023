# Source Techradar, Source URL:https://www.techradar.com/rss, Source language: en-US

## Galaxy Book 3 leak spills the beans on the latest Samsung laptops
 - [https://www.techradar.com/news/galaxy-book-3-leak-spills-the-beans-on-the-latest-samsung-laptops](https://www.techradar.com/news/galaxy-book-3-leak-spills-the-beans-on-the-latest-samsung-laptops)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 20:59:07+00:00
 - user: None

Leaks suggest the high-end Galaxy Book 3 Ultra will launch with a NVIDIA GeForce RTX 4070 GPU.

## NAD’s new wireless streamer is a cheap high-res audio upgrade
 - [https://www.techradar.com/news/nads-new-wireless-streamer-is-a-cheap-high-res-audio-upgrade](https://www.techradar.com/news/nads-new-wireless-streamer-is-a-cheap-high-res-audio-upgrade)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 20:55:22+00:00
 - user: None

The new NAD CS1 is one of the least expensive options available for adding high-res streaming to an existing music system.

## Yandex denies it was hacked, says rogue employee to blame for breach
 - [https://www.techradar.com/news/yandex-denies-it-was-hacked-says-rogue-employee-to-blame-for-breach](https://www.techradar.com/news/yandex-denies-it-was-hacked-says-rogue-employee-to-blame-for-breach)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 18:02:23+00:00
 - user: None

Leaker posts "Yandex git sources" on hacking forum, but Russian giant says it wasn't hacked.

## How your office printer can offer a secret sustainability improvement
 - [https://www.techradar.com/news/how-your-office-printer-can-offer-a-secret-sustainability-improvement](https://www.techradar.com/news/how-your-office-printer-can-offer-a-secret-sustainability-improvement)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 17:17:04+00:00
 - user: None

The Epson EcoTank could help your business do its part in addressing the climate crisis.

## It sounds like Ubisoft is trying to do a Call of Duty: Warzone with Far Cry
 - [https://www.techradar.com/news/it-sounds-like-ubisoft-is-trying-to-do-a-call-of-duty-warzone-with-far-cry](https://www.techradar.com/news/it-sounds-like-ubisoft-is-trying-to-do-a-call-of-duty-warzone-with-far-cry)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 17:01:08+00:00
 - user: None

Leaked information suggests that Ubisoft may have the next two Far Cry games in the works.

## Lexmark security bug leaves thousands of its printers open to attack
 - [https://www.techradar.com/news/lexmark-security-bug-leaves-thousands-of-its-printers-open-to-attack](https://www.techradar.com/news/lexmark-security-bug-leaves-thousands-of-its-printers-open-to-attack)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 16:42:10+00:00
 - user: None

Vendor warns of proof of concept exploits and urges customers to update as soon as possible.

## Samsung's 65-inch The Frame TV crashes to record-low price ahead Super Bowl
 - [https://www.techradar.com/news/samsungs-the-frame-tv-crashes-to-record-low-price-ahead-of-super-bowl](https://www.techradar.com/news/samsungs-the-frame-tv-crashes-to-record-low-price-ahead-of-super-bowl)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 16:41:11+00:00
 - user: None

Samsung's Super Bowl TV deals include the best-selling 65-inch The Frame TV on sale for a record-low price of $1,599.99.

## Seagate's top HDDs are all getting a storage boost
 - [https://www.techradar.com/news/seagates-top-hdds-are-all-getting-a-storage-boost](https://www.techradar.com/news/seagates-top-hdds-are-all-getting-a-storage-boost)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 16:29:00+00:00
 - user: None

Seagate is pushing ahead with plans to deliver huge (and even huge-r) HDDs.

## Toni Collette's new Prime Video thriller series looks electrifying
 - [https://www.techradar.com/news/toni-collettes-new-prime-video-thriller-series-looks-electrifying](https://www.techradar.com/news/toni-collettes-new-prime-video-thriller-series-looks-electrifying)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 16:24:41+00:00
 - user: None

The Power, a new superpower-based thriller series, is coming to Prime Video in March.

## The Dead Space remake has an amazing feature I won't be using
 - [https://www.techradar.com/news/the-dead-space-remake-has-an-amazing-feature-i-wont-be-using](https://www.techradar.com/news/the-dead-space-remake-has-an-amazing-feature-i-wont-be-using)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 16:17:13+00:00
 - user: None

Electronic Arts have added a brilliant accessibility feature that you probably shouldn’t use.

## Even the star of Fire Emblem Engage can't get a copy of the Nintendo RPG
 - [https://www.techradar.com/news/even-the-star-of-fire-emblem-engage-cant-get-a-copy-of-the-nintendo-rpg](https://www.techradar.com/news/even-the-star-of-fire-emblem-engage-cant-get-a-copy-of-the-nintendo-rpg)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 15:53:41+00:00
 - user: None

The voice of Fire Emblem Engage’s main character couldn’t get his own preorder fulfilled by GameStop.

## Monster Hunter has competition because this RPG has something it doesn't
 - [https://www.techradar.com/news/monster-hunter-has-competition-because-this-rpg-has-something-it-doesnt](https://www.techradar.com/news/monster-hunter-has-competition-because-this-rpg-has-something-it-doesnt)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 15:11:40+00:00
 - user: None

A new trailer shows off helicopters, buster swords, and claw blades in upcoming monster-slaying action game Wild Hearts.

## 7 new movies and TV shows on Netflix, Prime Video, Disney Plus and more this weekend (January 27)
 - [https://www.techradar.com/news/7-new-movies-and-tv-shows-on-netflix-prime-video-disney-plus-and-more-this-weekend-january-27-2023](https://www.techradar.com/news/7-new-movies-and-tv-shows-on-netflix-prime-video-disney-plus-and-more-this-weekend-january-27-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 15:00:43+00:00
 - user: None

From new supernatural dramas to subversive rom-coms, there’s plenty to watch this weekend.

## The FBI says it has infiltrated and shut down the notorious Hive ransomware group
 - [https://www.techradar.com/news/the-fbi-claims-it-infiltrated-and-shut-down-the-hive-ransomware-group](https://www.techradar.com/news/the-fbi-claims-it-infiltrated-and-shut-down-the-hive-ransomware-group)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 15:00:00+00:00
 - user: None

Joint operation between US and European law enforcement agencies may be cause for celebration, but those in the know are still worried.

## Ubuntu Pro is now available for everyone to use
 - [https://www.techradar.com/news/ubuntu-pro-is-now-available-for-everyone-to-use](https://www.techradar.com/news/ubuntu-pro-is-now-available-for-everyone-to-use)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 14:05:22+00:00
 - user: None

Following a successful beta testing period with companies like Nvidia and Google, Ubuntu Pro is now available to all.

## This devious ransomware hijacks the Windows Everything search tool
 - [https://www.techradar.com/news/this-devious-ransomware-hijacks-the-windows-everything-search-tool](https://www.techradar.com/news/this-devious-ransomware-hijacks-the-windows-everything-search-tool)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 13:04:20+00:00
 - user: None

This sneaky ransomware is using Windows Everything to deploy an even more efficient attack, so be on your guard.

## Playing GoldenEye on my iPad is real, and it's spectacular
 - [https://www.techradar.com/news/playing-goldeneye-on-my-ipad-is-real-and-its-spectacular](https://www.techradar.com/news/playing-goldeneye-on-my-ipad-is-real-and-its-spectacular)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 12:24:26+00:00
 - user: None

With the help of Xbox Cloud, Nintendo, an iPad, an 8BitDo controller, and a Game Pass subscription, I'm content.

## Intel sees huge drop in profits as PC and server markets fall
 - [https://www.techradar.com/news/intel-sees-huge-drop-in-profits-as-pc-and-server-markets-fall](https://www.techradar.com/news/intel-sees-huge-drop-in-profits-as-pc-and-server-markets-fall)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 12:15:51+00:00
 - user: None

Intel reports a huge dropoff in 2022 profits, but its report might contain some hidden light.

## Remastering three classics from Apogee Software for a new age
 - [https://www.techradar.com/news/remastering-three-classics-from-apogee-software-for-a-new-age](https://www.techradar.com/news/remastering-three-classics-from-apogee-software-for-a-new-age)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 12:15:45+00:00
 - user: None

While Apogee was bought by 3D Realms back in 1996, its legacy lives on in three games, recently remastered.

## Exclusive: Lots of us still really don't trust content written by AI
 - [https://www.techradar.com/news/exclusive-people-really-dont-trust-content-written-by-ai](https://www.techradar.com/news/exclusive-people-really-dont-trust-content-written-by-ai)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 12:00:12+00:00
 - user: None

Our survey finds continued suspicion around written content produced by artificial intelligence.

## You can now hide Google Chrome Incognito tabs behind a biometric lock on Android
 - [https://www.techradar.com/news/you-can-now-hide-google-chrome-incognito-tabs-behind-a-biometric-lock-on-android](https://www.techradar.com/news/you-can-now-hide-google-chrome-incognito-tabs-behind-a-biometric-lock-on-android)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 11:39:18+00:00
 - user: None

Android phone users can finally hide their Incognito tabs in Google Chrome behind a biometric lock.

## The Google Pixel Tablet could be the Pixel Tablet Pro in all but name
 - [https://www.techradar.com/news/no-google-pixel-tablet-pro-after-all](https://www.techradar.com/news/no-google-pixel-tablet-pro-after-all)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 11:26:44+00:00
 - user: None

A leak has revealed numerous Pixel Tablet specs and suggests that the rumored Pro model will be the only version.

## Bitwarden users at risk after potential phishing scam discovered
 - [https://www.techradar.com/news/bitwarden-users-at-risk-after-potential-phishing-scam-discovered](https://www.techradar.com/news/bitwarden-users-at-risk-after-potential-phishing-scam-discovered)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 11:19:04+00:00
 - user: None

A fake Bitwarden website may have tricked users into divulging their master passwords.

## Microsoft Teams is finally fixing this ear-splitting annoyance
 - [https://www.techradar.com/news/microsoft-teams-is-finally-fixing-this-ear-splitting-annoyance](https://www.techradar.com/news/microsoft-teams-is-finally-fixing-this-ear-splitting-annoyance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 10:55:48+00:00
 - user: None

No need for muting when you join a Microsoft Teams call.

## Shazam! Fury of the Gods trailer breakdown: 6 thing you might have missed
 - [https://www.techradar.com/news/shazam-fury-of-the-gods-trailer-breakdown-6-thing-you-might-have-missed](https://www.techradar.com/news/shazam-fury-of-the-gods-trailer-breakdown-6-thing-you-might-have-missed)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 10:54:34+00:00
 - user: None

Here are six thing you might have overlooked in the final trailer for Shazam! Fury of the Gods.

## Surfshark aces its first no-logs audit
 - [https://www.techradar.com/news/surfshark-aces-its-first-no-logs-audit](https://www.techradar.com/news/surfshark-aces-its-first-no-logs-audit)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 10:38:51+00:00
 - user: None

Surfshark's users now have the assurance their data is in the hands of a VPN provider operating with the highest privacy standards.

## Wordle today - hints, clues and answer for game #587, Friday, January 27
 - [https://www.techradar.com/news/wordle-today](https://www.techradar.com/news/wordle-today)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-27 08:30:20+00:00
 - user: None

Looking for hints for today's Wordle? We can help. Plus the solution to yesterday's Wordle and past answers.
