# Source Sky News, Source URL:http://feeds.skynews.com/feeds/rss/world.xml, Source language: en-US

## King and Queen Consort light candles on Holocaust Memorial Day in remembrance of millions of victims
 - [https://news.sky.com/story/holocaust-memorial-day-king-and-queen-consort-light-candles-in-remembrance-of-millions-of-victims-12797078](https://news.sky.com/story/holocaust-memorial-day-king-and-queen-consort-light-candles-in-remembrance-of-millions-of-victims-12797078)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 21:00:00+00:00
 - user: None

The King and Queen Consort have lit candles on Holocaust Memorial Day in remembrance of the six million Jewish people deliberately murdered by the Nazis in German-occupied Europe during World War Two.

## Five dead after shooting at synagogue in Jerusalem
 - [https://news.sky.com/story/five-dead-after-shooting-at-synagogue-in-jerusalem-israeli-ambulance-service-says-12796972](https://news.sky.com/story/five-dead-after-shooting-at-synagogue-in-jerusalem-israeli-ambulance-service-says-12796972)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 19:03:00+00:00
 - user: None

Five people have been killed and several injured in a shooting at a synagogue in Jerusalem, according to an ambulance service in Israel.

## 'You disgraced your families when you did this': Mother of US man who died after police 'beating' slams officers
 - [https://news.sky.com/story/tyre-nichols-death-mother-of-us-man-beaten-by-officers-says-they-disgraced-their-own-families-12796861](https://news.sky.com/story/tyre-nichols-death-mother-of-us-man-beaten-by-officers-says-they-disgraced-their-own-families-12796861)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 16:56:00+00:00
 - user: None

The mother of a US motorist who died after he was allegedly beaten by police has said the five charged officers "disgraced their own families".

## Palestinian militants 'ready to die' as prospect of all-out war increases
 - [https://news.sky.com/story/palestinian-militants-ready-to-die-as-prospect-of-all-out-war-increases-after-west-bank-clashes-12796849](https://news.sky.com/story/palestinian-militants-ready-to-die-as-prospect-of-all-out-war-increases-after-west-bank-clashes-12796849)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 16:37:00+00:00
 - user: None

The alleyways that run inside the Balata refugee camp are narrow, claustrophobic and full of uncollected rubbish.

## Poland to send 60 more tanks to Ukraine - on top of the 14 it previously announced
 - [https://news.sky.com/story/poland-to-send-60-more-tanks-to-ukraine-in-addition-to-the-14-it-previously-announced-12796770](https://news.sky.com/story/poland-to-send-60-more-tanks-to-ukraine-in-addition-to-the-14-it-previously-announced-12796770)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 16:00:00+00:00
 - user: None

Poland will send 60 more tanks to Ukraine, on top of the 14 it has already pledged to the war effort, the Polish prime minister has said.

## Godfather and Joker posters found in hideout of mafia boss before his arrest
 - [https://news.sky.com/story/mafia-boss-matteo-messina-denaro-godfather-and-joker-posters-found-in-apartment-used-by-him-before-his-arrest-12796828](https://news.sky.com/story/mafia-boss-matteo-messina-denaro-godfather-and-joker-posters-found-in-apartment-used-by-him-before-his-arrest-12796828)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 15:56:00+00:00
 - user: None

Police investigating a murderous mafia boss have found posters of Al Pacino as the Godfather and Joaquin Phoenix as the Joker in the apartment where he is thought to have lived before his arrest.

## 'Indifference kills': Zelenskyy leads global tributes on Holocaust Memorial Day
 - [https://news.sky.com/story/international-holocaust-memorial-day-marked-worldwide-as-zelenskyys-tribute-warns-indifference-kills-12796691](https://news.sky.com/story/international-holocaust-memorial-day-marked-worldwide-as-zelenskyys-tribute-warns-indifference-kills-12796691)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 13:45:00+00:00
 - user: None

Cities across the world have marked International Holocaust Memorial Day, with Ukraine's president warning that "indifference kills" in his tribute to victims.

## Norway discovers 'substantial' levels of metals and minerals on its seabed
 - [https://news.sky.com/story/norway-discovers-substantial-levels-of-metals-and-minerals-on-its-seabed-12796586](https://news.sky.com/story/norway-discovers-substantial-levels-of-metals-and-minerals-on-its-seabed-12796586)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 12:02:00+00:00
 - user: None

Norway has discovered what it calls "substantial" levels of metals and minerals on the floor of its extended continental shelf - including rare earth metals, officials have revealed.

## Deadly chemical attack was work of Syria's air force, watchdog finds
 - [https://news.sky.com/story/douma-chemical-attack-that-killed-43-in-syria-was-likely-work-of-regimes-air-force-international-watchdog-finds-12796578](https://news.sky.com/story/douma-chemical-attack-that-killed-43-in-syria-was-likely-work-of-regimes-air-force-international-watchdog-finds-12796578)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 11:50:00+00:00
 - user: None

A chemical strike that killed 43 people in the Syrian city of Douma in 2018 was almost certainly the work of Syria's air force, a watchdog has found.&#160;

## 'It's why we're on the brink of extinction': Crackdown urged on fossil fuel lobbyists at COP summits
 - [https://news.sky.com/story/crack-down-on-fossil-fuel-lobbyists-at-cop-climate-talks-global-groups-urge-the-united-nations-12796536](https://news.sky.com/story/crack-down-on-fossil-fuel-lobbyists-at-cop-climate-talks-global-groups-urge-the-united-nations-12796536)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 11:20:00+00:00
 - user: None

Fossil fuel lobbyists should be kicked out of the negotiating rooms at the international COP climate talks, global groups have urged the United Nations.

## British teenage extremist whose videos were linked to two mass murders in US jailed
 - [https://news.sky.com/story/daniel-harris-british-teenage-extremist-whose-videos-were-linked-to-two-mass-murders-in-us-jailed-12795052](https://news.sky.com/story/daniel-harris-british-teenage-extremist-whose-videos-were-linked-to-two-mass-murders-in-us-jailed-12795052)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 10:00:00+00:00
 - user: None

A British teenage extremist has been jailed after his far-right videos were linked to two mass murders in the US.

## Rioting police seize streets in protest after 10 officers killed by Haitian gangs
 - [https://news.sky.com/story/rioting-police-rebels-in-haiti-seize-port-au-prince-streets-in-protest-at-gang-killings-of-at-least-10-officers-12796435](https://news.sky.com/story/rioting-police-rebels-in-haiti-seize-port-au-prince-streets-in-protest-at-gang-killings-of-at-least-10-officers-12796435)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 09:27:00+00:00
 - user: None

Rebel police officers have rioted on the streets of Haiti's capital by blockading roads with burning tyres and firing guns into the air in protest at the killing of colleagues by criminal gangs.

## Auckland flooding brings major disruption - and Elton John gig axed minutes before start
 - [https://news.sky.com/story/auckland-flooding-brings-major-disruption-and-elton-john-gig-axed-minutes-before-start-12796430](https://news.sky.com/story/auckland-flooding-brings-major-disruption-and-elton-john-gig-axed-minutes-before-start-12796430)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 09:22:00+00:00
 - user: None

Torrential rain and wild weather in Auckland has caused major disruption throughout the city - and even led to an Elton John concert being cancelled just minutes before he was due on stage.

## Djokovic's father watches Australian Open semi-final remotely after appearing with Putin supporters
 - [https://news.sky.com/story/novak-djokovics-father-srdjan-watches-australian-open-semi-final-remotely-after-appearing-with-putin-supporters-12796424](https://news.sky.com/story/novak-djokovics-father-srdjan-watches-australian-open-semi-final-remotely-after-appearing-with-putin-supporters-12796424)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 09:20:00+00:00
 - user: None

Novak Djokovic's father is watching his son's Australian Open semi-final remotely after being captured on video alongside supporters of Russian President Vladimir Putin.

## Israel shoots down rockets after deadly commando raid on flashpoint West Bank town
 - [https://news.sky.com/story/israel-shoots-down-rockets-fired-from-gaza-after-deadly-commando-raid-on-flashpoint-west-bank-town-of-jenin-12796390](https://news.sky.com/story/israel-shoots-down-rockets-fired-from-gaza-after-deadly-commando-raid-on-flashpoint-west-bank-town-of-jenin-12796390)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 08:34:00+00:00
 - user: None

A number of rockets fired from the Gaza Strip have been intercepted by Israel's missile defences.

## Egypt's oldest mummy discovered 'covered in gold'
 - [https://news.sky.com/story/egypts-oldest-mummy-found-covered-in-layers-of-gold-following-year-long-excavation-12796367](https://news.sky.com/story/egypts-oldest-mummy-found-covered-in-layers-of-gold-following-year-long-excavation-12796367)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 07:28:00+00:00
 - user: None

A mummy "completely covered in layers of gold" may be the oldest and most complete ever found in Egypt.

## Islamic State terror banker killed by US special forces in mountain cave hideout
 - [https://news.sky.com/story/islamic-state-terror-banker-bilal-al-sudani-killed-by-us-special-forces-in-somalia-mountain-cave-hideout-12796361](https://news.sky.com/story/islamic-state-terror-banker-bilal-al-sudani-killed-by-us-special-forces-in-somalia-mountain-cave-hideout-12796361)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 07:19:00+00:00
 - user: None

US special forces have killed a senior Islamic State leader and 10 other militants in a raid on a mountain cave complex in a remote part of northern Somalia.

## 'I saw blood on the snow': Holocaust survivor shares horror of watching Nazi death squad kill her mum
 - [https://news.sky.com/story/holocaust-memorial-day-survivor-shares-horror-of-watching-nazi-death-squad-kill-her-mother-12793672](https://news.sky.com/story/holocaust-memorial-day-survivor-shares-horror-of-watching-nazi-death-squad-kill-her-mother-12793672)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-27 01:00:00+00:00
 - user: None

Hannah Lewis was just seven years old when she watched a Nazi death squad execute her mother.
