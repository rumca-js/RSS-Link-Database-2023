# Source NBC tech, Source URL:https://feeds.nbcnews.com/nbcnews/public/tech, Source language: en-US

## Two companies race to deploy robotaxis in San Francisco. The city wants them to hit the brakes.
 - [https://www.nbcnews.com/tech/tech-news/san-francisco-looks-hit-brakes-self-driving-cars-rcna66204](https://www.nbcnews.com/tech/tech-news/san-francisco-looks-hit-brakes-self-driving-cars-rcna66204)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-27 22:38:02+00:00
 - user: None

San Francisco is trying to slow the expansion of robotaxis after repeated incidents in which cars without drivers stopped and idled in the middle of the street.

## Damar Hamlin’s recovery fuels anti-vaccine conspiracy theories
 - [https://www.nbcnews.com/tech/internet/damar-hamlins-recovery-fuels-anti-vaccine-conspiracy-theories-rcna67722](https://www.nbcnews.com/tech/internet/damar-hamlins-recovery-fuels-anti-vaccine-conspiracy-theories-rcna67722)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-27 20:05:24+00:00
 - user: None

Hamlin’s cardiac arrest was seized on by people pushing unfounded claims about the dangers of Covid vaccines. His recovery pushed them to stranger theories.

## Former Fox News employee sues network, alleging Roger Ailes sexually abused her
 - [https://www.nbcnews.com/business/corporations/fox-employee-luhn-alleges-sex-abuse-roger-ailes-rcna67743](https://www.nbcnews.com/business/corporations/fox-employee-luhn-alleges-sex-abuse-roger-ailes-rcna67743)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-27 01:29:58+00:00
 - user: None

Former Fox News employee Laura Luhn sued the network on Wednesday, alleging that late Fox News chairman and CEO Roger Ailes sexually abused her for years.

## Elon Musk meets with House leaders on Capitol Hill
 - [https://www.nbcnews.com/politics/congress/elon-musk-meets-house-leaders-capitol-hill-rcna67780](https://www.nbcnews.com/politics/congress/elon-musk-meets-house-leaders-capitol-hill-rcna67780)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-27 00:07:53+00:00
 - user: None

Twitter CEO Elon Musk visited Capitol Hill on Thursday and met with House leaders from both parties, saying the discussions focused on his social media platform.
