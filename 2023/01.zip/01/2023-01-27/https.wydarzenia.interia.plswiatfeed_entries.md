# Source Wydarzenia Interia - Świat, Source URL:https://wydarzenia.interia.pl/swiat/feed, Source language: pl-PL

## Olaf Scholz przypomina o "historycznej odpowiedzialności Niemiec" za Holokaust
 - [https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-przypomina-o-historycznej-odpowiedzialnosci-niem,nId,6561047](https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-przypomina-o-historycznej-odpowiedzialnosci-niem,nId,6561047)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-27 13:37:53+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-olaf-scholz-przypomina-o-historycznej-odpowiedzialnosci-niem,nId,6561047"><img align="left" alt="Olaf Scholz przypomina o &quot;historycznej odpowiedzialności Niemiec&quot; za Holokaust " src="https://i.iplsc.com/olaf-scholz-przypomina-o-historycznej-odpowiedzialnosci-niem/000GOD6DLK5YGFQF-C321.jpg" /></a>&quot;W Dniu Pamięci o Ofiarach Holokaustu przypominamy o naszej historycznej odpowiedzialności&quot; - napisał na Twitterze kanclerz Niemiec Olaf Scholz. W centrum tegorocznych obchodów, jak poinformowała niemiecka minister kultury, są osoby prześladowane w czasach narodowego socjalizmu z powodu orientacji seksualnej lub tożsamości płciowej. </p><br clear="all" />
