# Source Le Monde - science, Source URL:https://www.lemonde.fr/en/science/rss_full.xml, Source language: en-US

## OpenAI: Inside the minds of ChatGPT's creators
 - [https://www.lemonde.fr/en/pixels/article/2023/01/27/openai-inside-the-minds-of-chatgpt-s-creators_6013287_13.html](https://www.lemonde.fr/en/pixels/article/2023/01/27/openai-inside-the-minds-of-chatgpt-s-creators_6013287_13.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-01-27 04:00:09+00:00
 - user: None

Behind the software is OpenAI, a startup with a messianic vision and global ambitions, founded by Silicon Valley heavyweights, including Elon Musk.
