# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## Judge: Colorado supermarket shooting suspect unfit to stand trial
 - [https://www.aljazeera.com/news/2023/1/27/judge-colorado-supermarket-shooting-suspect-unfit-to-stand-trial](https://www.aljazeera.com/news/2023/1/27/judge-colorado-supermarket-shooting-suspect-unfit-to-stand-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 22:38:09+00:00
 - user: None

The 23-year-old alleged attacker is charged with killing 10 people in a Colorado supermarket in March 2021.

## BBC Arabic radio goes off air after 85 years
 - [https://www.aljazeera.com/news/2023/1/27/bbc-world-services-ends-arabic-radio-after-85-years](https://www.aljazeera.com/news/2023/1/27/bbc-world-services-ends-arabic-radio-after-85-years)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 21:49:43+00:00
 - user: None

The Arabic language radio station is among 10 different language services that are ending, BBC says.

## Thapelo Amad elected first Muslim mayor of Johannesburg
 - [https://www.aljazeera.com/news/2023/1/27/johannesburg-gets-first-muslim-mayor-as-tiny-party-wins-top-job](https://www.aljazeera.com/news/2023/1/27/johannesburg-gets-first-muslim-mayor-as-tiny-party-wins-top-job)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 20:54:40+00:00
 - user: None

Amad says he is &#039;humbled&#039; to be elected mayor of the South Africa&#039;s biggest metropolis.

## What does Blinken’s Middle East visit hope to achieve?
 - [https://www.aljazeera.com/program/inside-story/2023/1/27/what-does-blinkens-middle-east-visit-hope-to-achieve](https://www.aljazeera.com/program/inside-story/2023/1/27/what-does-blinkens-middle-east-visit-hope-to-achieve)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 20:28:53+00:00
 - user: None

The trip comes at a time of increasing tension with dozens of Palestinians killed by Israeli forces so far this year.

## Quran burned in front of Denmark mosque, Turkish embassy
 - [https://www.aljazeera.com/news/2023/1/27/quran-burned-before-a-mosque-and-turkish-embassy-in-copenhagen](https://www.aljazeera.com/news/2023/1/27/quran-burned-before-a-mosque-and-turkish-embassy-in-copenhagen)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 20:13:25+00:00
 - user: None

Turkey summons Danish ambassador after a far-right politician burns the Muslim holy book near a Copenhagen mosque.

## M23 rebels take control of Kitshanga in eastern DR Congo
 - [https://www.aljazeera.com/news/2023/1/27/m23-rebels-take-control-of-kitshanga-in-eastern-dr-congo](https://www.aljazeera.com/news/2023/1/27/m23-rebels-take-control-of-kitshanga-in-eastern-dr-congo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 20:06:31+00:00
 - user: None

The rebels seize the strategic town after days of fierce fighting, drawing condemnation from the UN.

## US charges three in Iran-linked plot to assassinate journalist
 - [https://www.aljazeera.com/news/2023/1/27/us-charges-three-in-iran-linked-plot-to-assassinate-journalist](https://www.aljazeera.com/news/2023/1/27/us-charges-three-in-iran-linked-plot-to-assassinate-journalist)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 19:33:30+00:00
 - user: None

Attorney General Garland says charges stem from an investigation into Iranian efforts to target a journalist on US soil.

## Peru’s president says elections could be held later this year
 - [https://www.aljazeera.com/news/2023/1/27/perus-president-says-elections-could-be-held-later-this-year](https://www.aljazeera.com/news/2023/1/27/perus-president-says-elections-could-be-held-later-this-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 19:27:04+00:00
 - user: None

Dina Boluarte says she is open to bringing vote forward to December 2023 as protests demanding her resignation continue.

## Gunman kills at least 5 people in East Jerusalem attack
 - [https://www.aljazeera.com/news/2023/1/27/gunman-wounds-at-least-5-people-in-east-jerusalem-attack](https://www.aljazeera.com/news/2023/1/27/gunman-wounds-at-least-5-people-in-east-jerusalem-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 19:00:26+00:00
 - user: None

Shooting follows a deadly Israeli raid in the occupied West Bank&#039;s Jenin refugee camp that killed nine Palestinians.

## US inflation and consumer spending cooled in December
 - [https://www.aljazeera.com/economy/2023/1/27/us-inflation-and-consumer-spending-cooled-in-december](https://www.aljazeera.com/economy/2023/1/27/us-inflation-and-consumer-spending-cooled-in-december)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 18:56:01+00:00
 - user: None

The pullback in consumer spending will likely be welcomed by Fed officials, who are seeking to cool the economy.

## Majida Obaid, killed by Israeli forces in Jenin, was ‘very loved’
 - [https://www.aljazeera.com/news/2023/1/27/elderly-woman-killed-by-israeli-forces-in-jenin-was-very-loved](https://www.aljazeera.com/news/2023/1/27/elderly-woman-killed-by-israeli-forces-in-jenin-was-very-loved)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 18:38:46+00:00
 - user: None

The 61-year-old grandmother among nine who were shot dead by Israeli forces in the occupied West Bank city of Jenin.

## Footage released of hammer attack on Nancy Pelosi’s husband
 - [https://www.aljazeera.com/news/2023/1/27/footage-released-of-hammer-attack-on-nancy-pelosis-husband](https://www.aljazeera.com/news/2023/1/27/footage-released-of-hammer-attack-on-nancy-pelosis-husband)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 18:19:16+00:00
 - user: None

Police video shows Paul Pelosi, husband of former US House Speaker, attacked with a hammer in their San Francisco home.

## Zimbabwe court grants bail to 26 opposition party members
 - [https://www.aljazeera.com/news/2023/1/27/zimbabwe-court-grants-bail-to-26-opposition-party-members](https://www.aljazeera.com/news/2023/1/27/zimbabwe-court-grants-bail-to-26-opposition-party-members)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 17:31:57+00:00
 - user: None

The arrests of the CCC members were for what authorities said was an unlawful gathering.

## Nepal Supreme Court removes deputy PM over citizenship
 - [https://www.aljazeera.com/news/2023/1/27/nepals-deputy-pm-rabi-lamichhane-sacked-over-citizenship-law](https://www.aljazeera.com/news/2023/1/27/nepals-deputy-pm-rabi-lamichhane-sacked-over-citizenship-law)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 17:15:37+00:00
 - user: None

Rabi Lamichhane, who entered politics on an anti-corruption platform, is removed for violating citizenship laws.

## India’s Adani Group loses $48bn in stocks over fraud claims
 - [https://www.aljazeera.com/news/2023/1/27/indias-adani-group-loses-45-bn-in-stocks-over-fraud-claims](https://www.aljazeera.com/news/2023/1/27/indias-adani-group-loses-45-bn-in-stocks-over-fraud-claims)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 17:00:07+00:00
 - user: None

Hindenburg Research claimed Adani Group had committed &#039;brazen&#039; corporate fraud but Adani Group dismissed the report.

## Tyre Nichols: US braces for release of police arrest video
 - [https://www.aljazeera.com/news/2023/1/27/tyre-nichols-us-braces-for-release-of-fatal-police-assault-video](https://www.aljazeera.com/news/2023/1/27/tyre-nichols-us-braces-for-release-of-fatal-police-assault-video)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 16:44:44+00:00
 - user: None

Memphis police chief says the video, which shows police beating a Black motorist, depicts &#039;acts that defy humanity&#039;.

## Biden names Jeff Zients as new White House chief of staff
 - [https://www.aljazeera.com/news/2023/1/27/biden-names-jeff-zients-as-new-white-house-chief-of-staff](https://www.aljazeera.com/news/2023/1/27/biden-names-jeff-zients-as-new-white-house-chief-of-staff)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 16:33:16+00:00
 - user: None

Shake-up comes midway through US president&#039;s term, as outgoing Ron Klain resigns citing need for &#039;fresh leadership&#039;.

## UNICEF urges release of 13 kidnapped children in eastern DRC
 - [https://www.aljazeera.com/news/2023/1/27/unicef-urges-release-of-13-kidnapped-children-in-east-dr-congo](https://www.aljazeera.com/news/2023/1/27/unicef-urges-release-of-13-kidnapped-children-in-east-dr-congo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 15:37:20+00:00
 - user: None

The ADF, a central African affiliate of ISIL, is one of the deadliest armed groups in eastern DRC.

## OPCW blames Syria gov’t for 2018 chlorine gas attack in Douma
 - [https://www.aljazeera.com/news/2023/1/27/opcw-blames-syria-government-forces-for-2018-douma-chlorine-gas-attack](https://www.aljazeera.com/news/2023/1/27/opcw-blames-syria-government-forces-for-2018-douma-chlorine-gas-attack)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 15:15:43+00:00
 - user: None

OPCW says helicopter dropped two cylinders &#039;containing toxic chlorine gas on two apartment buildings&#039; in Douma.

## Finnish reporters found guilty of revealing classified intel
 - [https://www.aljazeera.com/news/2023/1/27/finnish-reporters-convicted-for-revealing-classified-intelligence](https://www.aljazeera.com/news/2023/1/27/finnish-reporters-convicted-for-revealing-classified-intelligence)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 14:53:10+00:00
 - user: None

Press freedom groups, Finnish media warn ruling could have a chilling effect on reporting in the Nordic nation.

## After Jenin, is a third Palestinian uprising inevitable?
 - [https://www.aljazeera.com/news/2023/1/27/after-jenin-is-a-third-palestinian-intifada-inevitable](https://www.aljazeera.com/news/2023/1/27/after-jenin-is-a-third-palestinian-intifada-inevitable)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 14:22:43+00:00
 - user: None

Israel&#039;s military raid in Jenin was the deadliest in years, and makes an uprising more likely.

## Rockets, air attacks in Gaza follow deadly Israeli raid in Jenin
 - [https://www.aljazeera.com/news/2023/1/27/rockets-air-attacks-gaza-but-likelihood-war-unclear](https://www.aljazeera.com/news/2023/1/27/rockets-air-attacks-gaza-but-likelihood-war-unclear)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 12:40:32+00:00
 - user: None

Operation in occupied West Bank generates defiance in Gaza, but could it lead to another war?

## State of emergency declared in Auckland after widespread flooding
 - [https://www.aljazeera.com/news/2023/1/27/heavy-rains-in-new-zealand-city-force-evacuations-closures](https://www.aljazeera.com/news/2023/1/27/heavy-rains-in-new-zealand-city-force-evacuations-closures)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 11:50:31+00:00
 - user: None

Main roads were also blocked by the floods, causing long traffic queues on highways.

## Ukraine warns it may boycott 2024 Olympics if Russians take part
 - [https://www.aljazeera.com/news/2023/1/27/ukraine-warns-it-may-boycott-2024-olympics-if-russians-take-part](https://www.aljazeera.com/news/2023/1/27/ukraine-warns-it-may-boycott-2024-olympics-if-russians-take-part)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 11:45:32+00:00
 - user: None

The IOC has said it will &#039;explore a pathway&#039; for Russian and Belarusian athletes to take part in the Paris Games.

## Nigeria launches domestic card scheme to boost cashless economy
 - [https://www.aljazeera.com/news/2023/1/27/nigeria-launches-domestic-card-scheme-in-cashless-bid](https://www.aljazeera.com/news/2023/1/27/nigeria-launches-domestic-card-scheme-in-cashless-bid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 11:13:07+00:00
 - user: None

The move is part of the central bank&#039;s moves to reduce cash flow within the borders of Africa&#039;s biggest economy.

## Staying warm this winter: How cold affects those most vulnerable
 - [https://www.aljazeera.com/features/longform/2023/1/27/staying-warm-this-winter-how-cold-affects-those-most-vulnerable](https://www.aljazeera.com/features/longform/2023/1/27/staying-warm-this-winter-how-cold-affects-those-most-vulnerable)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 10:53:52+00:00
 - user: None

Extreme cold, high inflation and spiralling energy costs are affecting every aspect of American life.

## Islamophobia makes democracies less safe for everyone
 - [https://www.aljazeera.com/opinions/2023/1/27/islamophobia-makes-democracies-less-safe-for-everyone](https://www.aljazeera.com/opinions/2023/1/27/islamophobia-makes-democracies-less-safe-for-everyone)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:57:53+00:00
 - user: None

Islamophobic acts have an effect not only on Muslims but the entire society in which they occur.

## What do we know about Tyre Nichols’s killing by Memphis police?
 - [https://www.aljazeera.com/news/2023/1/27/tyre-nichols-what-you-need-to-know-about-memphis-police-murder](https://www.aljazeera.com/news/2023/1/27/tyre-nichols-what-you-need-to-know-about-memphis-police-murder)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:53:05+00:00
 - user: None

Five police officers have been charged with the murder of 29-year-old Tyre Nichols.

## Malaysia condemns desecration of Quran in Netherlands, Sweden
 - [https://www.aljazeera.com/news/2023/1/27/malaysia-condemns-quran-desecration-in-netherlands-sweden](https://www.aljazeera.com/news/2023/1/27/malaysia-condemns-quran-desecration-in-netherlands-sweden)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:50:20+00:00
 - user: None

Kuala Lumpur says it is &#039;appalled&#039; that Islamophobic acts had been repeated within days in the two European countries.

## Toxic chemicals allegedly kill 18 people in Pakistan’s Karachi
 - [https://www.aljazeera.com/news/2023/1/27/toxic-chemicals-allegedly-kill-18-people-in-pakistans-karachi](https://www.aljazeera.com/news/2023/1/27/toxic-chemicals-allegedly-kill-18-people-in-pakistans-karachi)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:43:47+00:00
 - user: None

At least 18 people, most of them children, die within 16 days as residents report foul smell from two factories.

## Knowing when to quit is an important part of being a good leader
 - [https://www.aljazeera.com/opinions/2023/1/27/africas-leaders-do-not-know-when-to-call-it-quits](https://www.aljazeera.com/opinions/2023/1/27/africas-leaders-do-not-know-when-to-call-it-quits)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:37:35+00:00
 - user: None

Uganda&#039;s Yoweri Museveni and Cameroon&#039;s Paul Biya have a lot to learn from New Zealand’s Jacinda Ardern.

## UN condemns M23 rebel offensive on DRC town as hundreds flee
 - [https://www.aljazeera.com/news/2023/1/27/u-n-condemns-m23-rebel-offensive-on-congo-town-hundreds-flee](https://www.aljazeera.com/news/2023/1/27/u-n-condemns-m23-rebel-offensive-on-congo-town-hundreds-flee)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:08:19+00:00
 - user: None

The M23 rebels have seized areas of eastern DRC&#039;s North Kivu province in a rapid onslaught since May.

## US military operation kills top ISIL leader in Somalia
 - [https://www.aljazeera.com/news/2023/1/27/u-s-military-operation-kills-islamic-state-leader-in-somalia-officials](https://www.aljazeera.com/news/2023/1/27/u-s-military-operation-kills-islamic-state-leader-in-somalia-officials)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 09:08:02+00:00
 - user: None

The US said the operation was carried out on January 25 on al-Sudani, &#039;a key facilitator for ISIS’s global network&#039;.

## ‘Oldest and most complete’ mummy found in Egypt
 - [https://www.aljazeera.com/news/2023/1/27/oldest-complete-mummy-found-egypt](https://www.aljazeera.com/news/2023/1/27/oldest-complete-mummy-found-egypt)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 08:12:49+00:00
 - user: None

The 4,300-year-old mummy was found covered in layers of gold near the Step Pyramid at Saqqara.

## Are humans fundamentally decent?
 - [https://www.aljazeera.com/program/upfront/2023/1/27/are-humans-fundamentally-decent](https://www.aljazeera.com/program/upfront/2023/1/27/are-humans-fundamentally-decent)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 07:57:04+00:00
 - user: None

&#039;Most people deep down are pretty decent but power corrupts,&#039; argues historian and author Rutger Bregman.

## ‘Happy tears’ as Sania Mirza bows out of Australian Open
 - [https://www.aljazeera.com/news/2023/1/27/indias-tennis-star-sania-mirza-bows-out-of-grand-slam-tennis](https://www.aljazeera.com/news/2023/1/27/indias-tennis-star-sania-mirza-bows-out-of-grand-slam-tennis)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 07:38:28+00:00
 - user: None

Mirza played her last Grand Slam match where she and her partner Bopanna lost the Australian Open mixed doubles final.

## Russia’s FM Lavrov meets Eritrean president on Africa tour
 - [https://www.aljazeera.com/news/2023/1/27/russias-lavrov-meets-eritrean-president-in-surprise-visit](https://www.aljazeera.com/news/2023/1/27/russias-lavrov-meets-eritrean-president-in-surprise-visit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 06:54:08+00:00
 - user: None

Foreign minister&#039;s trip to Eritrea comes as part of his Africa tour which took him to South Africa, Angola and Eswatini.

## One person killed in armed attack on Azerbaijan embassy in Iran
 - [https://www.aljazeera.com/news/2023/1/27/armed-attack-azerbaijan-embassy-iran-kills](https://www.aljazeera.com/news/2023/1/27/armed-attack-azerbaijan-embassy-iran-kills)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 06:51:43+00:00
 - user: None

Azerbaijani foreign ministry say a guard has been killed in the attack.

## Russia-Ukraine war: List of key events, day 338
 - [https://www.aljazeera.com/news/2023/1/27/russia-ukraine-war-list-of-key-events-day-338](https://www.aljazeera.com/news/2023/1/27/russia-ukraine-war-list-of-key-events-day-338)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 06:42:13+00:00
 - user: None

As the Russia-Ukraine war enters its 338th day, we take a look at the main developments.

## Japan, Netherlands to join US in China chip controls: Bloomberg
 - [https://www.aljazeera.com/economy/2023/1/27/japan-netherlands-to-join-us-in-china-chip-controls-bloomberg](https://www.aljazeera.com/economy/2023/1/27/japan-netherlands-to-join-us-in-china-chip-controls-bloomberg)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 06:17:35+00:00
 - user: None

Agreement on tighter export controls on China would be seen as a big diplomatic win for US President Joe Biden.

## Gandhi’s killer Godse ‘real patriot’ for some Hindu nationalists
 - [https://www.aljazeera.com/news/2023/1/27/gandhis-killer-godse-real-patriot-for-some-hindu-nationalists-in-india](https://www.aljazeera.com/news/2023/1/27/gandhis-killer-godse-real-patriot-for-some-hindu-nationalists-in-india)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 05:41:36+00:00
 - user: None

Many visit temple near New Delhi dedicated to Nathuram Godse, who on January 30, 1948 gunned down the freedom fighter.

## IAEA reports blasts near Zaporizhzhia plant, Russia rejects claim
 - [https://www.aljazeera.com/news/2023/1/27/un-says-blasts-near-zaporizhzhia-plant-russia-dismisses-concerns](https://www.aljazeera.com/news/2023/1/27/un-says-blasts-near-zaporizhzhia-plant-russia-dismisses-concerns)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 05:25:48+00:00
 - user: None

The International Atomic Energy Agency reported explosions near the Ukrainian nuclear power plant occupied by Russia.

## Fiji suspends police commissioner, ends China policing agreement
 - [https://www.aljazeera.com/news/2023/1/27/fiji-suspends-police-commissioner-ends-china-policing-agreement](https://www.aljazeera.com/news/2023/1/27/fiji-suspends-police-commissioner-ends-china-policing-agreement)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 05:07:47+00:00
 - user: None

Commissioner of Police Sitiveni Qiliho is seen as close to former Prime Minister Frank Bainimarama.

## Israel air attacks hit Gaza after 10 Palestinians killed in Jenin
 - [https://www.aljazeera.com/news/2023/1/27/israel-airstrikes-hit-gaza-after-10-palestinians-killed-in-jenin](https://www.aljazeera.com/news/2023/1/27/israel-airstrikes-hit-gaza-after-10-palestinians-killed-in-jenin)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 04:25:48+00:00
 - user: None

Witnesses reported Israeli drones firing missiles at targets in Gaza followed by fighter jets attacking locations.

## Myanmar military announces strict new election law ahead of polls
 - [https://www.aljazeera.com/news/2023/1/27/myanmar-military-unveils-strict-new-election-law-ahead-of-polls](https://www.aljazeera.com/news/2023/1/27/myanmar-military-unveils-strict-new-election-law-ahead-of-polls)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 04:07:24+00:00
 - user: None

New rules, published in state media, appear designed to ensure there is no meaningful opposition to the military.

## Japan tightens Russia sanctions, expands export ban list
 - [https://www.aljazeera.com/economy/2023/1/27/japan-bans-exports-of-robots-semiconductor-parts-to-russia](https://www.aljazeera.com/economy/2023/1/27/japan-bans-exports-of-robots-semiconductor-parts-to-russia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 03:41:50+00:00
 - user: None

Tokyo&#039;s latest sanctions come after Russia launched missile attacks across Ukraine that killed at least 11 people.

## South Korea’s unions cry ‘red scare’ amid North Korea spy claims
 - [https://www.aljazeera.com/economy/2023/1/27/south-korea-unions-decry-red-scare-amid-north-korea-spy-claims](https://www.aljazeera.com/economy/2023/1/27/south-korea-unions-decry-red-scare-amid-north-korea-spy-claims)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 03:06:40+00:00
 - user: None

South Korea&#039;s spy agency has accused members of the country&#039;s largest union of illegally contacting North Korean agents.

## ICC to resume investigation into Philippines’s deadly drug war
 - [https://www.aljazeera.com/news/2023/1/27/icc-to-resume-investigation-into-philippiness-deadly-drug-war](https://www.aljazeera.com/news/2023/1/27/icc-to-resume-investigation-into-philippiness-deadly-drug-war)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-27 01:33:36+00:00
 - user: None

Manila had argued it was conducting its own investigation into deaths under the controversial policy.
