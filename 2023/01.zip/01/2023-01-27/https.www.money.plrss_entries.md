# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## Rząd podał warunek obniżenia podatków w Wielkiej Brytanii. Marzenie wielu się oddala
 - [https://www.money.pl/podatki/rzad-podal-warunek-obnizenia-podatkow-w-wielkiej-brytanii-marzenie-wielu-sie-oddala-6860155431824064a.html](https://www.money.pl/podatki/rzad-podal-warunek-obnizenia-podatkow-w-wielkiej-brytanii-marzenie-wielu-sie-oddala-6860155431824064a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 18:03:52+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d8c58b15-ff23-4d33-8b3e-db448249ae02" width="308" /> Jeremy Hunt, brytyjski minister finansów, wykluczył obniżenie podatków w najbliższym czasie. Podał warunki, które muszą być spełnione, by wprowadzić cięcia. Skomentował też doniesienia o upadku gospodarki Wielkiej Brytanii.

## Jak negocjować wynagrodzenie podczas rozmowy o pracę?
 - [https://www.money.pl/gospodarka/jak-negocjowac-wynagrodzenie-podczas-rozmowy-o-prace-6859752906644128a.html](https://www.money.pl/gospodarka/jak-negocjowac-wynagrodzenie-podczas-rozmowy-o-prace-6859752906644128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 15:30:43+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/037f49af-f509-4d84-8ee1-67361ffde3ab" width="308" /> Zmiana pracy wiąże się zazwyczaj także ze zmianą wynagrodzenia. Aby było ono satysfakcjonujące dla pracownika, musi potrafić wynegocjować pensję, która go zadowoli. Podczas rozmowy kwalifikacyjnej pada pytanie o oczekiwania finansowe. Warto wiedzieć, jak na nie odpowiedzieć i jak się przygotować, by osiągnąć swój cel.

## Rolnicy odbierają telefony, pada dziwne pytanie. Trwa narodowy spis
 - [https://www.money.pl/gospodarka/rolnicy-odbieraja-telefony-pada-dziwne-pytanie-trwa-narodowy-spis-6860080235809472a.html](https://www.money.pl/gospodarka/rolnicy-odbieraja-telefony-pada-dziwne-pytanie-trwa-narodowy-spis-6860080235809472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 13:13:50+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6387fbd8-ed83-4fa7-b1b5-f0c7ae5c34db" width="308" /> Rolnicy z całego kraju odbierają telefony z lokalnych biur Agencji Restrukturyzacji i Modernizacji Rolnictwa. Urzędnicy pytają gospodarzy o ilość magazynowanych zbóż - donosi serwis farmer.pl. Rolnicy są zdziwieni całą sytuacją.

## "Zakopiański smog wita" i żąda myta. Turyści płacą. Prawnicy: to nielegalne
 - [https://www.money.pl/podatki/zakopianski-smog-wita-i-zada-myta-turysci-placa-prawnicy-to-nielegalne-6859735350487744a.html](https://www.money.pl/podatki/zakopianski-smog-wita-i-zada-myta-turysci-placa-prawnicy-to-nielegalne-6859735350487744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 12:38:44+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1768bb9c-6e2d-4e08-96bb-c04c5b1edae9" width="308" /> Zakopane od lat nie radzi sobie z jakością powietrza. Turyści skarżą się na panujący tam zimą smog. Jeden z nich zaskarżył opłatę miejscową w sądzie. NSA przyznał mu rację i uchylił miejscowe prawo zezwalające na pobór taksy klimatycznej. Jednak urzędnicy dalej ją pobierają.

## Wysokość tych emerytur robi wrażenie. Rekordzista pracował ponad 57 lat
 - [https://www.money.pl/emerytury/wysokosc-tych-emerytur-robi-wrazenie-rekordzista-pracowal-ponad-57-lat-6860070077827744a.html](https://www.money.pl/emerytury/wysokosc-tych-emerytur-robi-wrazenie-rekordzista-pracowal-ponad-57-lat-6860070077827744a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 12:16:24+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9bb9e10f-9ef0-471e-bc8c-fbbf83f4bdf9" width="308" /> Najwyższa emerytura w kraju należy do informatyka z Poznania. Jego świadczenie to 27 635,90 zł brutto, czyli 22 776,86 zł netto.&nbsp;Rekordzista otrzymuje co miesiąc więcej pieniędzy niż premier, którego pensja to ponad 17 tys. zł brutto miesięcznie - wylicza Interia Biznes.

## W Birmie gwałtownie wzrosła produkcja opium. To efekt kryzysu
 - [https://www.money.pl/gospodarka/w-birmie-gwaltownie-wzrosla-produkcja-opium-to-efekt-kryzysu-6859974017145536a.html](https://www.money.pl/gospodarka/w-birmie-gwaltownie-wzrosla-produkcja-opium-to-efekt-kryzysu-6859974017145536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 05:45:41+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fbf22432-92fc-439f-91f4-efb90409c26c" width="308" /> W ubiegłym roku produkcja opium w Birmie wzrosła dwukrotnie, sięgając 795 ton - informuje BBC, powołując się na dane ONZ. Obszary upraw maku opiumowego w 2022 roku wzrosły o jedną trzecią do 40 tys. hektarów, a ceny surowego produkty skoczyły o 67 procent.

## Wcześniejsze emerytury dla nauczycieli. Resort edukacji właśnie dopina szczegóły z ZUS
 - [https://www.money.pl/emerytury/wczesniejsze-emerytury-dla-nauczycieli-resort-edukacji-wlasnie-dopina-szczegoly-z-zus-6859972711049920a.html](https://www.money.pl/emerytury/wczesniejsze-emerytury-dla-nauczycieli-resort-edukacji-wlasnie-dopina-szczegoly-z-zus-6859972711049920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-27 05:40:22+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ecc4396-97c0-4e25-87a4-c7a3390dbed6" width="308" /> Na 1 lutego zaplanowano rozmowy o wcześniejszych emeryturach resortu edukacji z nauczycielskimi związkami zawodowymi. Resort edukacji che przenieść cześć nauczycieli "w stan spoczynku" w związku z nadchodzącym niżem demograficznym. Jak ustaliła wyborcza.biz. wcześniejsze emerytury będą wprowadzone od września 2024 r.
