# Source MSN, Source URL:http://www.msn.com/rss/news.aspx, Source language: en-US

## How to teach kids the meaning of Martin Luther King Jr. Day
 - [http://www.msn.com/en-us/news/us/how-to-teach-kids-the-meaning-of-martin-luther-king-jr-day/ar-BB1cQiCy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-to-teach-kids-the-meaning-of-martin-luther-king-jr-day/ar-BB1cQiCy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.279624+00:00
 - user: None



## Robbie Knievel, American daredevil and son of Evel Knievel, dead at 60
 - [http://www.msn.com/en-us/news/crime/robbie-knievel-american-daredevil-and-son-of-evel-knievel-dead-at-60/ar-AA16k0z9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/robbie-knievel-american-daredevil-and-son-of-evel-knievel-dead-at-60/ar-AA16k0z9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.270695+00:00
 - user: None



## West Virginia Gov. Jim Justice 'seriously' contemplating a challenge against Manchin
 - [http://www.msn.com/en-us/news/politics/west-virginia-gov-jim-justice-seriously-contemplating-a-challenge-against-manchin/ar-AA16k58m?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/west-virginia-gov-jim-justice-seriously-contemplating-a-challenge-against-manchin/ar-AA16k58m?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.262603+00:00
 - user: None



## Hillicon Valley — Tesla slashes prices
 - [http://www.msn.com/en-us/news/politics/hillicon-valley-tesla-slashes-prices/ar-AA16k9sZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hillicon-valley-tesla-slashes-prices/ar-AA16k9sZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.255337+00:00
 - user: None



## Kari Lake Supporter Sues Judge to Get Election Overturned
 - [http://www.msn.com/en-us/news/politics/kari-lake-supporter-sues-judge-to-get-election-overturned/ar-AA16k5bw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kari-lake-supporter-sues-judge-to-get-election-overturned/ar-AA16k5bw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.248090+00:00
 - user: None



## Santos target of another watchdog complaint alleging misuse of campaign funds
 - [http://www.msn.com/en-us/news/politics/santos-target-of-another-watchdog-complaint-alleging-misuse-of-campaign-funds/ar-AA16kogW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/santos-target-of-another-watchdog-complaint-alleging-misuse-of-campaign-funds/ar-AA16kogW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.240845+00:00
 - user: None



## DHS policy protects migrant workers in labor investigations
 - [http://www.msn.com/en-us/news/us/dhs-policy-protects-migrant-workers-in-labor-investigations/ar-AA16jPXb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dhs-policy-protects-migrant-workers-in-labor-investigations/ar-AA16jPXb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.233133+00:00
 - user: None



## GOP House targets China, abortion, IRS funding in McCarthy's first week as speaker
 - [http://www.msn.com/en-us/news/politics/gop-house-targets-china-abortion-irs-funding-in-mccarthy-s-first-week-as-speaker/ar-AA16kcLf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-house-targets-china-abortion-irs-funding-in-mccarthy-s-first-week-as-speaker/ar-AA16kcLf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 23:15:30.225150+00:00
 - user: None



## Supreme Court appears set to expand workers' right to time off for religious observance
 - [http://www.msn.com/en-us/news/us/supreme-court-appears-set-to-expand-workers-right-to-time-off-for-religious-observance/ar-AA16keEW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/supreme-court-appears-set-to-expand-workers-right-to-time-off-for-religious-observance/ar-AA16keEW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.326271+00:00
 - user: None



## Avian flu is crushing farmers
 - [http://www.msn.com/en-us/news/us/avian-flu-is-crushing-farmers/ar-AA16k8cJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/avian-flu-is-crushing-farmers/ar-AA16k8cJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.319015+00:00
 - user: None



## At least 1 law clerk is among a small group of suspects in Supreme Court investigation of abortion leak: report
 - [http://www.msn.com/en-us/news/politics/at-least-1-law-clerk-is-among-a-small-group-of-suspects-in-supreme-court-investigation-of-abortion-leak-report/ar-AA16jPzA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/at-least-1-law-clerk-is-among-a-small-group-of-suspects-in-supreme-court-investigation-of-abortion-leak-report/ar-AA16jPzA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.310809+00:00
 - user: None



## 5 Dead in 2 Cars That 'Burst Into Flames' After Getting Crushed by Trucks on Arizona Highway
 - [http://www.msn.com/en-us/news/us/5-dead-in-2-cars-that-burst-into-flames-after-getting-crushed-by-trucks-on-arizona-highway/ar-AA16jXPC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/5-dead-in-2-cars-that-burst-into-flames-after-getting-crushed-by-trucks-on-arizona-highway/ar-AA16jXPC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.303110+00:00
 - user: None



## Are Gas Stoves Doomed?
 - [http://www.msn.com/en-us/news/us/are-gas-stoves-doomed/ar-AA16kckl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/are-gas-stoves-doomed/ar-AA16kckl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.295767+00:00
 - user: None



## 10 Horrible Tech Gadgets From the Last 25 Years That Just Suck
 - [http://www.msn.com/en-us/news/technology/10-horrible-tech-gadgets-from-the-last-25-years-that-just-suck/ar-AA16alMf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/10-horrible-tech-gadgets-from-the-last-25-years-that-just-suck/ar-AA16alMf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.287393+00:00
 - user: None



## Judge rules Catholic hospital ‘discriminated’ against transgender man for refusing ‘gender-affirming’ surgery
 - [http://www.msn.com/en-us/news/us/judge-rules-catholic-hospital-discriminated-against-transgender-man-for-refusing-gender-affirming-surgery/ar-AA16k9ic?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/judge-rules-catholic-hospital-discriminated-against-transgender-man-for-refusing-gender-affirming-surgery/ar-AA16k9ic?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 22:15:23.279397+00:00
 - user: None



## 2nd caretaker arrested amid search for missing 4-year-old girl
 - [http://www.msn.com/en-us/news/crime/2nd-caretaker-arrested-amid-search-for-missing-4-year-old-girl/ar-AA16hxMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2nd-caretaker-arrested-amid-search-for-missing-4-year-old-girl/ar-AA16hxMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.309211+00:00
 - user: None



## Webb Telescope Finds Massive Shock Wave Wreaking Havoc Among 5 Galaxies
 - [http://www.msn.com/en-us/news/technology/webb-telescope-finds-massive-shock-wave-wreaking-havoc-among-5-galaxies/ar-AA16hAgY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/webb-telescope-finds-massive-shock-wave-wreaking-havoc-among-5-galaxies/ar-AA16hAgY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.302014+00:00
 - user: None



## ‘I’m going to put you in an electric chair’: Video of a Maryland H.S. student bullying a special needs classmate sparks outrage
 - [http://www.msn.com/en-us/news/us/i-m-going-to-put-you-in-an-electric-chair-video-of-a-maryland-h-s-student-bullying-a-special-needs-classmate-sparks-outrage/ar-AA16jPeP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/i-m-going-to-put-you-in-an-electric-chair-video-of-a-maryland-h-s-student-bullying-a-special-needs-classmate-sparks-outrage/ar-AA16jPeP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.293924+00:00
 - user: None



## Fiscal train wreck ahead?
 - [http://www.msn.com/en-us/news/politics/fiscal-train-wreck-ahead/ar-AA16kbQy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fiscal-train-wreck-ahead/ar-AA16kbQy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.286643+00:00
 - user: None



## One more thing for Democrats to fix: the Republican Party
 - [http://www.msn.com/en-us/news/politics/one-more-thing-for-democrats-to-fix-the-republican-party/ar-AA16jXsN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/one-more-thing-for-democrats-to-fix-the-republican-party/ar-AA16jXsN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.279062+00:00
 - user: None



## Missing Mom Ana Walshe's Kids Are in State Custody. Her Friends Want Them to Stay with People They Know
 - [http://www.msn.com/en-us/news/crime/missing-mom-ana-walshe-s-kids-are-in-state-custody-her-friends-want-them-to-stay-with-people-they-know/ar-AA16jXrA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/missing-mom-ana-walshe-s-kids-are-in-state-custody-her-friends-want-them-to-stay-with-people-they-know/ar-AA16jXrA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.271709+00:00
 - user: None



## Photos of the Week: Surfing, Santos and Superman
 - [http://www.msn.com/en-us/news/politics/photos-of-the-week-surfing-santos-and-superman/ar-AA16k7vQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/photos-of-the-week-surfing-santos-and-superman/ar-AA16k7vQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.264371+00:00
 - user: None



## House Republicans launch inquiry into Biden files
 - [http://www.msn.com/en-us/news/world/house-republicans-launch-inquiry-into-biden-files/ar-AA16kgAZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/house-republicans-launch-inquiry-into-biden-files/ar-AA16kgAZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 21:15:20.256016+00:00
 - user: None



## Russia tried to claim months ago it destroyed American-made armored vehicles that the US didn't even offer Ukraine until last week
 - [http://www.msn.com/en-us/news/world/russia-tried-to-claim-months-ago-it-destroyed-american-made-armored-vehicles-that-the-us-didn-t-even-offer-ukraine-until-last-week/ar-AA16kbbM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-tried-to-claim-months-ago-it-destroyed-american-made-armored-vehicles-that-the-us-didn-t-even-offer-ukraine-until-last-week/ar-AA16kbbM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:19.311637+00:00
 - user: None



## Is it time for the West to give Ukraine heavy tanks?
 - [http://www.msn.com/en-us/news/world/is-it-time-for-the-west-to-give-ukraine-heavy-tanks/ar-AA16jZa8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/is-it-time-for-the-west-to-give-ukraine-heavy-tanks/ar-AA16jZa8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:19.246991+00:00
 - user: None



## Putin's Biggest Weak Spot Exposed as Ukraine's Ambition Grows
 - [http://www.msn.com/en-us/news/world/putin-s-biggest-weak-spot-exposed-as-ukraine-s-ambition-grows/ar-AA16jX0Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-biggest-weak-spot-exposed-as-ukraine-s-ambition-grows/ar-AA16jX0Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:19.179270+00:00
 - user: None



## Curriculum transparency is harder to achieve than lawmakers assume
 - [http://www.msn.com/en-us/news/us/curriculum-transparency-is-harder-to-achieve-than-lawmakers-assume/ar-AA16jZeo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/curriculum-transparency-is-harder-to-achieve-than-lawmakers-assume/ar-AA16jZeo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:19.111487+00:00
 - user: None



## Search for 4-year-old after postal worker finds sister alone; 2 caretakers arrested
 - [http://www.msn.com/en-us/news/crime/search-for-4-year-old-after-postal-worker-finds-sister-alone-2-caretakers-arrested/ar-AA16hxMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/search-for-4-year-old-after-postal-worker-finds-sister-alone-2-caretakers-arrested/ar-AA16hxMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:19.043449+00:00
 - user: None



## Houston police arrest suspect in slaying of man found wrapped in blankets in closet last year
 - [http://www.msn.com/en-us/news/crime/houston-police-arrest-suspect-in-slaying-of-man-found-wrapped-in-blankets-in-closet-last-year/ar-AA16k8Hg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/houston-police-arrest-suspect-in-slaying-of-man-found-wrapped-in-blankets-in-closet-last-year/ar-AA16k8Hg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:18.977706+00:00
 - user: None



## Bannon asks to change lawyers in wall building fraud case
 - [http://www.msn.com/en-us/news/politics/bannon-asks-to-change-lawyers-in-wall-building-fraud-case/ar-AA16jORN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bannon-asks-to-change-lawyers-in-wall-building-fraud-case/ar-AA16jORN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:18.914689+00:00
 - user: None



## At least 9 dead with toll expected to grow after tornadoes tore through the Southeast
 - [http://www.msn.com/en-us/news/us/at-least-9-dead-with-toll-expected-to-grow-after-tornadoes-tore-through-the-southeast/ar-AA16jWaK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/at-least-9-dead-with-toll-expected-to-grow-after-tornadoes-tore-through-the-southeast/ar-AA16jWaK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 20:15:18.846518+00:00
 - user: None



## Biden to Give State of the Union Feb. 7 as Debt Fight Looms
 - [http://www.msn.com/en-us/news/politics/biden-to-give-state-of-the-union-feb-7-as-debt-fight-looms/ar-AA16jWHa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-give-state-of-the-union-feb-7-as-debt-fight-looms/ar-AA16jWHa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.239245+00:00
 - user: None



## How defending gas stoves became a conservative culture war
 - [http://www.msn.com/en-us/news/us/how-defending-gas-stoves-became-a-conservative-culture-war/ar-AA16k3yR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/how-defending-gas-stoves-became-a-conservative-culture-war/ar-AA16k3yR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.230504+00:00
 - user: None



## Russia Sets Ultimatum to Formally Pull a Third Country Into Putin’s War
 - [http://www.msn.com/en-us/news/world/russia-sets-ultimatum-to-formally-pull-a-third-country-into-putin-s-war/ar-AA16jKTF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-sets-ultimatum-to-formally-pull-a-third-country-into-putin-s-war/ar-AA16jKTF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.220668+00:00
 - user: None



## Why Pakistan Is Facing a Growing Food Crisis
 - [http://www.msn.com/en-us/news/world/why-pakistan-is-facing-a-growing-food-crisis/ar-AA16k67a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/why-pakistan-is-facing-a-growing-food-crisis/ar-AA16k67a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.212418+00:00
 - user: None



## Twitter Files: Emails show Schiff's routine efforts to get posts taken down
 - [http://www.msn.com/en-us/news/politics/twitter-files-emails-show-schiff-s-routine-efforts-to-get-posts-taken-down/ar-AA16k6kd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/twitter-files-emails-show-schiff-s-routine-efforts-to-get-posts-taken-down/ar-AA16k6kd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.204626+00:00
 - user: None



## Iowa official’s wife arrested, charged with voter fraud in 2020 election
 - [http://www.msn.com/en-us/news/politics/iowa-official-s-wife-arrested-charged-with-voter-fraud-in-2020-election/ar-AA16jUB0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/iowa-official-s-wife-arrested-charged-with-voter-fraud-in-2020-election/ar-AA16jUB0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.188962+00:00
 - user: None



## Boston unveils new sculpture honoring Martin Luther King and Coretta Scott King
 - [http://www.msn.com/en-us/news/us/boston-unveils-new-sculpture-honoring-martin-luther-king-and-coretta-scott-king/ar-AA16jN91?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/boston-unveils-new-sculpture-honoring-martin-luther-king-and-coretta-scott-king/ar-AA16jN91?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.181661+00:00
 - user: None



## Belarusian investigators use photo of politician shaking hands with Hillary Clinton against him
 - [http://www.msn.com/en-us/news/world/belarusian-investigators-use-photo-of-politician-shaking-hands-with-hillary-clinton-against-him/ar-AA16k6m0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/belarusian-investigators-use-photo-of-politician-shaking-hands-with-hillary-clinton-against-him/ar-AA16k6m0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 19:23:23.172277+00:00
 - user: None



## Service members terminated over unvaxxed status could be reinstated in military with GOP-led bills
 - [http://www.msn.com/en-us/news/politics/service-members-terminated-over-unvaxxed-status-could-be-reinstated-in-military-with-gop-led-bills/ar-AA16jS6L?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/service-members-terminated-over-unvaxxed-status-could-be-reinstated-in-military-with-gop-led-bills/ar-AA16jS6L?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.339822+00:00
 - user: None



## Why DeSantis and Other 2024 Hopefuls Are Unlikely to Announce Before May
 - [http://www.msn.com/en-us/news/politics/why-desantis-and-other-2024-hopefuls-are-unlikely-to-announce-before-may/ar-AA16jKfU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-desantis-and-other-2024-hopefuls-are-unlikely-to-announce-before-may/ar-AA16jKfU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.332736+00:00
 - user: None



## Daily on Energy: The Biden administration’s solo permitting reform efforts
 - [http://www.msn.com/en-us/news/politics/daily-on-energy-the-biden-administration-s-solo-permitting-reform-efforts/ar-AA16jWcY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/daily-on-energy-the-biden-administration-s-solo-permitting-reform-efforts/ar-AA16jWcY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.325762+00:00
 - user: None



## Afghan rulers urged to reverse ban on women aid workers
 - [http://www.msn.com/en-us/news/world/afghan-rulers-urged-to-reverse-ban-on-women-aid-workers/ar-AA16jvnn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/afghan-rulers-urged-to-reverse-ban-on-women-aid-workers/ar-AA16jvnn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.318771+00:00
 - user: None



## New York Mayor: Cost of asylum seekers could hit $2B as shelters reach capacity
 - [http://www.msn.com/en-us/news/us/new-york-mayor-cost-of-asylum-seekers-could-hit-2b-as-shelters-reach-capacity/ar-AA16jvpg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-york-mayor-cost-of-asylum-seekers-could-hit-2b-as-shelters-reach-capacity/ar-AA16jvpg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.311443+00:00
 - user: None



## Hanged Erdogan effigy sparks new Sweden Nato row
 - [http://www.msn.com/en-us/news/world/hanged-erdogan-effigy-sparks-new-sweden-nato-row/ar-AA16jWdp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/hanged-erdogan-effigy-sparks-new-sweden-nato-row/ar-AA16jWdp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.303350+00:00
 - user: None



## Sweden discovers largest known rare earth mineral deposit in Europe
 - [http://www.msn.com/en-us/news/politics/sweden-discovers-largest-known-rare-earth-mineral-deposit-in-europe/ar-AA16jWaS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sweden-discovers-largest-known-rare-earth-mineral-deposit-in-europe/ar-AA16jWaS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:22.296315+00:00
 - user: None



## At least 9 dead with more deaths expected after tornadoes tore through the Southeast
 - [http://www.msn.com/en-us/news/us/at-least-9-dead-with-more-deaths-expected-after-tornadoes-tore-through-the-southeast/ar-AA16jWaK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/at-least-9-dead-with-more-deaths-expected-after-tornadoes-tore-through-the-southeast/ar-AA16jWaK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 18:23:21.956318+00:00
 - user: None



## Ezra Miller gets probation in Vermont booze theft after pleading guilty to trespassing
 - [http://www.msn.com/en-us/news/crime/ezra-miller-gets-probation-in-vermont-booze-theft-after-pleading-guilty-to-trespassing/ar-AA16jLza?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ezra-miller-gets-probation-in-vermont-booze-theft-after-pleading-guilty-to-trespassing/ar-AA16jLza?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.486894+00:00
 - user: None



## The Simple Programs That Beat ChatGPT, Midjourney, and DALL-E
 - [http://www.msn.com/en-us/news/technology/the-simple-programs-that-beat-chatgpt-midjourney-and-dall-e/ar-AA16jSWb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-simple-programs-that-beat-chatgpt-midjourney-and-dall-e/ar-AA16jSWb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.479111+00:00
 - user: None



## Arkansas Gov. Sarah Sanders bans use of 'Latinx' in government documents
 - [http://www.msn.com/en-us/news/politics/arkansas-gov-sarah-sanders-bans-use-of-latinx-in-government-documents/ar-AA16jsKP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/arkansas-gov-sarah-sanders-bans-use-of-latinx-in-government-documents/ar-AA16jsKP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.470890+00:00
 - user: None



## Why Tesla is dropping prices across the US
 - [http://www.msn.com/en-us/news/politics/why-tesla-is-dropping-prices-across-the-us/ar-AA16jqeN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-tesla-is-dropping-prices-across-the-us/ar-AA16jqeN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.463489+00:00
 - user: None



## Winklevoss firm charged in US over crypto sales
 - [http://www.msn.com/en-us/news/world/winklevoss-firm-charged-in-us-over-crypto-sales/ar-AA16jNS3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/winklevoss-firm-charged-in-us-over-crypto-sales/ar-AA16jNS3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.456020+00:00
 - user: None



## Delphi murder suspect appears in court as judge rules trial will remain in county, gag order continues
 - [http://www.msn.com/en-us/news/crime/delphi-murder-suspect-appears-in-court-as-judge-rules-trial-will-remain-in-county-gag-order-continues/ar-AA16jQV8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/delphi-murder-suspect-appears-in-court-as-judge-rules-trial-will-remain-in-county-gag-order-continues/ar-AA16jQV8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.447383+00:00
 - user: None



## Rep. George Santos Appears to Have Ripped Off His Former Boss's Resume in Crafting His Backstory
 - [http://www.msn.com/en-us/news/politics/rep-george-santos-appears-to-have-ripped-off-his-former-boss-s-resume-in-crafting-his-backstory/ar-AA16jY53?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-george-santos-appears-to-have-ripped-off-his-former-boss-s-resume-in-crafting-his-backstory/ar-AA16jY53?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 17:23:16.438475+00:00
 - user: None



## LastPass Breach: 5 Things to Do Right Now if You Use the Password Manager
 - [http://www.msn.com/en-us/news/technology/lastpass-breach-5-things-to-do-right-now-if-you-use-the-password-manager/ar-AA163yoK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/lastpass-breach-5-things-to-do-right-now-if-you-use-the-password-manager/ar-AA163yoK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.904913+00:00
 - user: None



## Russia claims to have captured Ukrainian town of Soledar
 - [http://www.msn.com/en-us/news/world/russia-claims-to-have-captured-ukrainian-town-of-soledar/ar-AA16jIzk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-claims-to-have-captured-ukrainian-town-of-soledar/ar-AA16jIzk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.897619+00:00
 - user: None



## Ezra Miller Appears in Court, Pleads Guilty to Misdemeanor and Begins 1-Year Probation
 - [http://www.msn.com/en-us/news/crime/ezra-miller-appears-in-court-pleads-guilty-to-misdemeanor-and-begins-1-year-probation/ar-AA16javX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ezra-miller-appears-in-court-pleads-guilty-to-misdemeanor-and-begins-1-year-probation/ar-AA16javX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.890148+00:00
 - user: None



## Photo with Clinton used against jailed Belarus politician
 - [http://www.msn.com/en-us/news/world/photo-with-clinton-used-against-jailed-belarus-politician/ar-AA16jGE7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/photo-with-clinton-used-against-jailed-belarus-politician/ar-AA16jGE7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.882879+00:00
 - user: None



## Aliens or spies? What to make of the government’s new UFO report
 - [http://www.msn.com/en-us/news/technology/aliens-or-spies-what-to-make-of-the-government-s-new-ufo-report/ar-AA16jFuT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/aliens-or-spies-what-to-make-of-the-government-s-new-ufo-report/ar-AA16jFuT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.874971+00:00
 - user: None



## GOP rep introduces bill to restart border wall construction, days after Mexican president lauds Biden
 - [http://www.msn.com/en-us/news/politics/gop-rep-introduces-bill-to-restart-border-wall-construction-days-after-mexican-president-lauds-biden/ar-AA16jxMo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/gop-rep-introduces-bill-to-restart-border-wall-construction-days-after-mexican-president-lauds-biden/ar-AA16jxMo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.848057+00:00
 - user: None



## Russia Accidentally Blows Up Its Own Tank During Repairs: Report
 - [http://www.msn.com/en-us/news/world/russia-accidentally-blows-up-its-own-tank-during-repairs-report/ar-AA16jFFM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-accidentally-blows-up-its-own-tank-during-repairs-report/ar-AA16jFFM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.838903+00:00
 - user: None



## Mega Millions jackpot surges to $1.35 billion
 - [http://www.msn.com/en-us/news/us/mega-millions-jackpot-surges-to-1-35-billion/ar-AA16jhiF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mega-millions-jackpot-surges-to-1-35-billion/ar-AA16jhiF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 16:23:10.500116+00:00
 - user: None



## Loudoun County attorney's office to no longer prosecute certain misdemeanors
 - [http://www.msn.com/en-us/news/crime/loudoun-county-attorney-s-office-to-no-longer-prosecute-certain-misdemeanors/ar-AA16jwRF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/loudoun-county-attorney-s-office-to-no-longer-prosecute-certain-misdemeanors/ar-AA16jwRF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.519210+00:00
 - user: None



## Seizing Moscow’s assets is a necessity, not just an option
 - [http://www.msn.com/en-us/news/world/seizing-moscow-s-assets-is-a-necessity-not-just-an-option/ar-AA16jrh5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/seizing-moscow-s-assets-is-a-necessity-not-just-an-option/ar-AA16jrh5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.511544+00:00
 - user: None



## Heavily Entangled Right Whale Covered in Wounds and Lice 'Likely to Die'
 - [http://www.msn.com/en-us/news/world/heavily-entangled-right-whale-covered-in-wounds-and-lice-likely-to-die/ar-AA16jEfk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/heavily-entangled-right-whale-covered-in-wounds-and-lice-likely-to-die/ar-AA16jEfk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.502710+00:00
 - user: None



## Russia says it has captured eastern town, its first victory in months
 - [http://www.msn.com/en-us/news/world/russia-says-it-has-captured-eastern-town-its-first-victory-in-months/ar-AA16j3tZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-says-it-has-captured-eastern-town-its-first-victory-in-months/ar-AA16j3tZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.493076+00:00
 - user: None



## Germany plans to drop mask mandate on long-distance trains, buses
 - [http://www.msn.com/en-us/news/world/germany-plans-to-drop-mask-mandate-on-long-distance-trains-buses/ar-AA16jFYA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-plans-to-drop-mask-mandate-on-long-distance-trains-buses/ar-AA16jFYA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.485240+00:00
 - user: None



## Ukraine says it's now a de facto member of NATO — further underlining a crucial error in Putin's invasion
 - [http://www.msn.com/en-us/news/world/ukraine-says-it-s-now-a-de-facto-member-of-nato-further-underlining-a-crucial-error-in-putin-s-invasion/ar-AA16jp5c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-says-it-s-now-a-de-facto-member-of-nato-further-underlining-a-crucial-error-in-putin-s-invasion/ar-AA16jp5c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.477748+00:00
 - user: None



## Trump Organization sentenced to maximum fine following tax fraud conviction
 - [http://www.msn.com/en-us/news/politics/trump-organization-sentenced-to-maximum-fine-following-tax-fraud-conviction/ar-AA16iNbr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-organization-sentenced-to-maximum-fine-following-tax-fraud-conviction/ar-AA16iNbr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 15:22:58.469704+00:00
 - user: None



## Starting Tuesday, all U.S. military veterans in suicidal crisis will be eligible for free care at any VA or private facility
 - [http://www.msn.com/en-us/news/us/starting-tuesday-all-u-s-military-veterans-in-suicidal-crisis-will-be-eligible-for-free-care-at-any-va-or-private-facility/ar-AA16jou4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/starting-tuesday-all-u-s-military-veterans-in-suicidal-crisis-will-be-eligible-for-free-care-at-any-va-or-private-facility/ar-AA16jou4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.950908+00:00
 - user: None



## Metal detectors will be installed at school where 6-year-old shot teacher, official says
 - [http://www.msn.com/en-us/news/us/metal-detectors-will-be-installed-at-school-where-6-year-old-shot-teacher-official-says/ar-AA16jqVv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/metal-detectors-will-be-installed-at-school-where-6-year-old-shot-teacher-official-says/ar-AA16jqVv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.937988+00:00
 - user: None



## Ukraine Latest: Russia Claims Control of Soledar in Bloody Fight
 - [http://www.msn.com/en-us/news/world/ukraine-latest-russia-claims-control-of-soledar-in-bloody-fight/ar-AA16iwOK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-russia-claims-control-of-soledar-in-bloody-fight/ar-AA16iwOK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.930965+00:00
 - user: None



## From University To MetaVersity
 - [http://www.msn.com/en-us/news/technology/from-university-to-metaversity/ar-AA16jByR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/from-university-to-metaversity/ar-AA16jByR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.922281+00:00
 - user: None



## $1.35B Mega Millions prize drawing set for Friday night
 - [http://www.msn.com/en-us/news/us/1-35b-mega-millions-prize-drawing-set-for-friday-night/ar-AA16jr4G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/1-35b-mega-millions-prize-drawing-set-for-friday-night/ar-AA16jr4G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.915265+00:00
 - user: None



## Ashli Babbitt’s shooter housed at Andrews for six months
 - [http://www.msn.com/en-us/news/us/ashli-babbitt-s-shooter-housed-at-andrews-for-six-months/ar-AA16jwqD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/ashli-babbitt-s-shooter-housed-at-andrews-for-six-months/ar-AA16jwqD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.908246+00:00
 - user: None



## GOP bill blocks Biden admin from banning gas stoves: ‘Regulation run amok’
 - [http://www.msn.com/en-us/news/us/gop-bill-blocks-biden-admin-from-banning-gas-stoves-regulation-run-amok/ar-AA16jBv7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/gop-bill-blocks-biden-admin-from-banning-gas-stoves-regulation-run-amok/ar-AA16jBv7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.900550+00:00
 - user: None



## Schumer backs special counsel in Biden documents case: ‘Let it play out’
 - [http://www.msn.com/en-us/news/politics/schumer-backs-special-counsel-in-biden-documents-case-let-it-play-out/ar-AA16jBDf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schumer-backs-special-counsel-in-biden-documents-case-let-it-play-out/ar-AA16jBDf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.892709+00:00
 - user: None



## Biden worries the secret service may be loyal to Trump, according to a new book
 - [http://www.msn.com/en-us/news/politics/biden-worries-the-secret-service-may-be-loyal-to-trump-according-to-a-new-book/ar-AA16jzaC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-worries-the-secret-service-may-be-loyal-to-trump-according-to-a-new-book/ar-AA16jzaC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 14:43:47.884171+00:00
 - user: None



## Russia Claims Soledar Is its First Territorial Gain in Months
 - [http://www.msn.com/en-us/news/world/russia-claims-soledar-is-its-first-territorial-gain-in-months/ar-AA16j56x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-claims-soledar-is-its-first-territorial-gain-in-months/ar-AA16j56x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:36.322428+00:00
 - user: None



## McCarthy says he will look at expunging Trump impeachment
 - [http://www.msn.com/en-us/news/politics/mccarthy-says-he-will-look-at-expunging-trump-impeachment/ar-AA16iV0t?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-says-he-will-look-at-expunging-trump-impeachment/ar-AA16iV0t?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:36.314874+00:00
 - user: None



## A perilous paradise: In Montecito, fires, floods and mudflows leave wealthy town in fear
 - [http://www.msn.com/en-us/news/world/a-perilous-paradise-in-montecito-fires-floods-and-mudflows-leave-wealthy-town-in-fear/ar-AA16j9p0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/a-perilous-paradise-in-montecito-fires-floods-and-mudflows-leave-wealthy-town-in-fear/ar-AA16j9p0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.874849+00:00
 - user: None



## Satellite images show staggering destruction from bitter fighting in Ukraine's east
 - [http://www.msn.com/en-us/news/world/satellite-images-show-staggering-destruction-from-bitter-fighting-in-ukraine-s-east/ar-AA16iT12?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/satellite-images-show-staggering-destruction-from-bitter-fighting-in-ukraine-s-east/ar-AA16iT12?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.837152+00:00
 - user: None



## Seven Novels About What Makes a House a Home
 - [http://www.msn.com/en-us/news/world/seven-novels-about-what-makes-a-house-a-home/ar-AA16jokT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/seven-novels-about-what-makes-a-house-a-home/ar-AA16jokT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.829333+00:00
 - user: None



## Tech Companies Need to Be Held Accountable for Security, Experts Say
 - [http://www.msn.com/en-us/news/technology/tech-companies-need-to-be-held-accountable-for-security-experts-say/ar-AA16j9ly?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/tech-companies-need-to-be-held-accountable-for-security-experts-say/ar-AA16j9ly?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.821702+00:00
 - user: None



## Editorial: We know soot pollution is deadly. The EPA needs tougher standards to protect public health
 - [http://www.msn.com/en-us/news/us/editorial-we-know-soot-pollution-is-deadly-the-epa-needs-tougher-standards-to-protect-public-health/ar-AA16jypa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/editorial-we-know-soot-pollution-is-deadly-the-epa-needs-tougher-standards-to-protect-public-health/ar-AA16jypa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.812699+00:00
 - user: None



## EU inaugurates first mainland satellite launch port
 - [http://www.msn.com/en-us/news/world/eu-inaugurates-first-mainland-satellite-launch-port/ar-AA16jo7B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/eu-inaugurates-first-mainland-satellite-launch-port/ar-AA16jo7B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.803817+00:00
 - user: None



## Republicans split on taking fast-tracked approach to Mayorkas impeachment
 - [http://www.msn.com/en-us/news/politics/republicans-split-on-taking-fast-tracked-approach-to-mayorkas-impeachment/ar-AA16jydp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-split-on-taking-fast-tracked-approach-to-mayorkas-impeachment/ar-AA16jydp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.796561+00:00
 - user: None



## Art collector says a Van Gogh painting that he owns went missing for nearly six years and resurfaced in a Detroit gallery
 - [http://www.msn.com/en-us/news/crime/art-collector-says-a-van-gogh-painting-that-he-owns-went-missing-for-nearly-six-years-and-resurfaced-in-a-detroit-gallery/ar-AA16jvwp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/art-collector-says-a-van-gogh-painting-that-he-owns-went-missing-for-nearly-six-years-and-resurfaced-in-a-detroit-gallery/ar-AA16jvwp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.789322+00:00
 - user: None



## Russia claims control of Soledar in eastern Ukraine, first major win in months
 - [http://www.msn.com/en-us/news/world/russia-claims-control-of-soledar-in-eastern-ukraine-first-major-win-in-months/ar-AA16jqKK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-claims-control-of-soledar-in-eastern-ukraine-first-major-win-in-months/ar-AA16jqKK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 13:43:35.781810+00:00
 - user: None



## U.S. and Japan's new defense strategy sends stark warning to China
 - [http://www.msn.com/en-us/news/world/u-s-and-japan-s-new-defense-strategy-sends-stark-warning-to-china/ar-AA16iUyE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-and-japan-s-new-defense-strategy-sends-stark-warning-to-china/ar-AA16iUyE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:36:48.019500+00:00
 - user: None



## Wounded Russians are being sent back to Ukraine with major injuries like punctured lungs and shrapnel still in their bodies, report says
 - [http://www.msn.com/en-us/news/world/wounded-russians-are-being-sent-back-to-ukraine-with-major-injuries-like-punctured-lungs-and-shrapnel-still-in-their-bodies-report-says/ar-AA16j1P4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/wounded-russians-are-being-sent-back-to-ukraine-with-major-injuries-like-punctured-lungs-and-shrapnel-still-in-their-bodies-report-says/ar-AA16j1P4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:36:48.011923+00:00
 - user: None



## Russia claims control of Soledar in eastern Ukraine, its first victory in months
 - [http://www.msn.com/en-us/news/world/russia-claims-control-of-soledar-in-eastern-ukraine-its-first-victory-in-months/ar-AA16j3tZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-claims-control-of-soledar-in-eastern-ukraine-its-first-victory-in-months/ar-AA16j3tZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:36:48.000674+00:00
 - user: None



## Is It Finally Time for a Touchscreen MacBook?
 - [http://www.msn.com/en-us/news/technology/is-it-finally-time-for-a-touchscreen-macbook/ar-AA16j1UY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/is-it-finally-time-for-a-touchscreen-macbook/ar-AA16j1UY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:36:47.912063+00:00
 - user: None



## Migrant attempts to enter Europe without authorization hit six-year high
 - [http://www.msn.com/en-us/news/world/migrant-attempts-to-enter-europe-without-authorization-hit-six-year-high/ar-AA16iXyN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/migrant-attempts-to-enter-europe-without-authorization-hit-six-year-high/ar-AA16iXyN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.383594+00:00
 - user: None



## Why Mayors Are So Unpopular
 - [http://www.msn.com/en-us/news/us/why-mayors-are-so-unpopular/ar-AA16iFjd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/why-mayors-are-so-unpopular/ar-AA16iFjd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.376070+00:00
 - user: None



## Reporter feuding with Karine Jean-Pierre says White House 'doesn't want tough questions'
 - [http://www.msn.com/en-us/news/us/reporter-feuding-with-karine-jean-pierre-says-white-house-doesn-t-want-tough-questions/ar-AA16iU5d?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/reporter-feuding-with-karine-jean-pierre-says-white-house-doesn-t-want-tough-questions/ar-AA16iU5d?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.368499+00:00
 - user: None



## Ukraine credits local beavers for unwittingly bolstering its defenses — their dams make the ground marshy and impassable
 - [http://www.msn.com/en-us/news/world/ukraine-credits-local-beavers-for-unwittingly-bolstering-its-defenses-their-dams-make-the-ground-marshy-and-impassable/ar-AA16iZK1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-credits-local-beavers-for-unwittingly-bolstering-its-defenses-their-dams-make-the-ground-marshy-and-impassable/ar-AA16iZK1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.360400+00:00
 - user: None



## What's at stake in the Left's war on women
 - [http://www.msn.com/en-us/news/politics/what-s-at-stake-in-the-left-s-war-on-women/ar-AA16j1E8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-s-at-stake-in-the-left-s-war-on-women/ar-AA16j1E8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.352168+00:00
 - user: None



## US flights grounded because engineer accidentally 'replaced one file with another'
 - [http://www.msn.com/en-us/news/us/us-flights-grounded-because-engineer-accidentally-replaced-one-file-with-another/ar-AA16glMc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-flights-grounded-because-engineer-accidentally-replaced-one-file-with-another/ar-AA16glMc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.343508+00:00
 - user: None



## Want to deter China? Hold a tanker competition
 - [http://www.msn.com/en-us/news/politics/want-to-deter-china-hold-a-tanker-competition/ar-AA16iS3D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/want-to-deter-china-hold-a-tanker-competition/ar-AA16iS3D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.335755+00:00
 - user: None



## Justice Dept. enters political fray with 2 special counsels
 - [http://www.msn.com/en-us/news/politics/justice-dept-enters-political-fray-with-2-special-counsels/ar-AA16iS3u?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/justice-dept-enters-political-fray-with-2-special-counsels/ar-AA16iS3u?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 12:17:51.327707+00:00
 - user: None



## Bed Bath & Beyond’s Potential Bankruptcy, Explained
 - [http://www.msn.com/en-us/money/news/bed-bath-beyond-s-potential-bankruptcy-explained/vi-AA16iWHz?srcref=rss](http://www.msn.com/en-us/money/news/bed-bath-beyond-s-potential-bankruptcy-explained/vi-AA16iWHz?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 11:10:29.689720+00:00
 - user: None



## Commentary: School choice would benefit rural students in Texas
 - [http://www.msn.com/en-us/news/us/commentary-school-choice-would-benefit-rural-students-in-texas/ar-AA16j83G?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/commentary-school-choice-would-benefit-rural-students-in-texas/ar-AA16j83G?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 11:10:29.681024+00:00
 - user: None



## Deadly Venomous Snake Found Hiding Inside Printer Paper Drawer
 - [http://www.msn.com/en-us/news/technology/deadly-venomous-snake-found-hiding-inside-printer-paper-drawer/ar-AA16izFL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/deadly-venomous-snake-found-hiding-inside-printer-paper-drawer/ar-AA16izFL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 11:10:29.671340+00:00
 - user: None



## 3 HBCUs receive funding in the aftermath of bomb threats
 - [http://www.msn.com/en-us/news/us/3-hbcus-receive-funding-in-the-aftermath-of-bomb-threats/ar-AA16iuTj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/3-hbcus-receive-funding-in-the-aftermath-of-bomb-threats/ar-AA16iuTj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.171354+00:00
 - user: None



## Sunak pledges to work constructively with Scotland's leader
 - [http://www.msn.com/en-us/news/world/sunak-pledges-to-work-constructively-with-scotland-s-leader/ar-AA16j2QB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sunak-pledges-to-work-constructively-with-scotland-s-leader/ar-AA16j2QB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.163554+00:00
 - user: None



## Legal woes grow for George Santos as another watchdog files FEC complaint
 - [http://www.msn.com/en-us/news/politics/legal-woes-grow-for-george-santos-as-another-watchdog-files-fec-complaint/ar-AA16iWKs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/legal-woes-grow-for-george-santos-as-another-watchdog-files-fec-complaint/ar-AA16iWKs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.155908+00:00
 - user: None



## Two huge black holes are on the verge of colliding. When they do, the explosion will be incalculable
 - [http://www.msn.com/en-us/news/technology/two-huge-black-holes-are-on-the-verge-of-colliding-when-they-do-the-explosion-will-be-incalculable/ar-AA16iYUW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/two-huge-black-holes-are-on-the-verge-of-colliding-when-they-do-the-explosion-will-be-incalculable/ar-AA16iYUW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.148678+00:00
 - user: None



## The strategist who didn't believe in the red wave
 - [http://www.msn.com/en-us/news/politics/the-strategist-who-didn-t-believe-in-the-red-wave/ar-AA16j2SR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-strategist-who-didn-t-believe-in-the-red-wave/ar-AA16j2SR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.141446+00:00
 - user: None



## Putin's reshuffle of military brass points to rifts at the top as war in Ukraine rages
 - [http://www.msn.com/en-us/news/world/putin-s-reshuffle-of-military-brass-points-to-rifts-at-the-top-as-war-in-ukraine-rages/ar-AA16j0Ho?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-reshuffle-of-military-brass-points-to-rifts-at-the-top-as-war-in-ukraine-rages/ar-AA16j0Ho?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:58:54.133457+00:00
 - user: None



## Donald Trump Calls Special Counsel Investigating Him a 'Terrorist'
 - [http://www.msn.com/en-us/news/politics/donald-trump-calls-special-counsel-investigating-him-a-terrorist/ar-AA16iMJb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-calls-special-counsel-investigating-him-a-terrorist/ar-AA16iMJb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:17:38.556297+00:00
 - user: None



## Israel kills 3 in West Bank raids, pushing Palestinian death toll to 9 already in 2023
 - [http://www.msn.com/en-us/news/world/israel-kills-3-in-west-bank-raids-pushing-palestinian-death-toll-to-9-already-in-2023/ar-AA16iW5h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/israel-kills-3-in-west-bank-raids-pushing-palestinian-death-toll-to-9-already-in-2023/ar-AA16iW5h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:17:38.545344+00:00
 - user: None



## Ukraine Latest: Kyiv Fights in Soledar as Russia Seen in Control
 - [http://www.msn.com/en-us/news/world/ukraine-latest-kyiv-fights-in-soledar-as-russia-seen-in-control/ar-AA16iwOK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-latest-kyiv-fights-in-soledar-as-russia-seen-in-control/ar-AA16iwOK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:17:38.536663+00:00
 - user: None



## George Santos Tries on a New Disguise: Conservative Renegade
 - [http://www.msn.com/en-us/news/politics/george-santos-tries-on-a-new-disguise-conservative-renegade/ar-AA16iCkD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/george-santos-tries-on-a-new-disguise-conservative-renegade/ar-AA16iCkD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 10:17:38.528507+00:00
 - user: None



## Heidi Stevens: 'As a child, if I died and my family died, no one would care.' Author sheds light on childhood poverty, homelessness
 - [http://www.msn.com/en-us/news/us/heidi-stevens-as-a-child-if-i-died-and-my-family-died-no-one-would-care-author-sheds-light-on-childhood-poverty-homelessness/ar-AA16iVwn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/heidi-stevens-as-a-child-if-i-died-and-my-family-died-no-one-would-care-author-sheds-light-on-childhood-poverty-homelessness/ar-AA16iVwn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.623181+00:00
 - user: None



## White House capitalizes on Republican divisions on abortion
 - [http://www.msn.com/en-us/news/politics/white-house-capitalizes-on-republican-divisions-on-abortion/ar-AA16iSOi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-capitalizes-on-republican-divisions-on-abortion/ar-AA16iSOi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.615943+00:00
 - user: None



## Police seek manslaughter charges over Seoul Halloween crowd crush that killed 158
 - [http://www.msn.com/en-us/news/world/police-seek-manslaughter-charges-over-seoul-halloween-crowd-crush-that-killed-158/ar-AA16iJ5c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/police-seek-manslaughter-charges-over-seoul-halloween-crowd-crush-that-killed-158/ar-AA16iJ5c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.608190+00:00
 - user: None



## Capture of Soledar Only 'Pyrrhic' Victory for Russia—ISW
 - [http://www.msn.com/en-us/news/world/capture-of-soledar-only-pyrrhic-victory-for-russia-isw/ar-AA16iVDJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/capture-of-soledar-only-pyrrhic-victory-for-russia-isw/ar-AA16iVDJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.601118+00:00
 - user: None



## Ukraine's smart air defense threatens one of Russia's most advanced jets, leaving it too scared to use them, experts say
 - [http://www.msn.com/en-us/news/world/ukraine-s-smart-air-defense-threatens-one-of-russia-s-most-advanced-jets-leaving-it-too-scared-to-use-them-experts-say/ar-AA16iXXe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-smart-air-defense-threatens-one-of-russia-s-most-advanced-jets-leaving-it-too-scared-to-use-them-experts-say/ar-AA16iXXe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.593852+00:00
 - user: None



## Brian Kemp and the Electric Car: A Love Story
 - [http://www.msn.com/en-us/news/politics/brian-kemp-and-the-electric-car-a-love-story/ar-AA16iurA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/brian-kemp-and-the-electric-car-a-love-story/ar-AA16iurA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:58:50.586239+00:00
 - user: None



## TRANSFER NEWS LIVE: Latest deals and rumours ahead of January window
 - [http://www.msn.com/en-us/sports/premier-league/transfer-news-live-latest-deals-and-rumours-ahead-of-january-window/ar-AA16iBDY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/sports/premier-league/transfer-news-live-latest-deals-and-rumours-ahead-of-january-window/ar-AA16iBDY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:17:34.952094+00:00
 - user: None



## Japan Seeks Biden Endorsement of Security Overhaul at Summit
 - [http://www.msn.com/en-us/news/world/japan-seeks-biden-endorsement-of-security-overhaul-at-summit/ar-AA16iOf0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/japan-seeks-biden-endorsement-of-security-overhaul-at-summit/ar-AA16iOf0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 09:17:34.942237+00:00
 - user: None



## Biden to Talk China Tech With Japan, Dutch Leaders in Washington
 - [http://www.msn.com/en-us/news/world/biden-to-talk-china-tech-with-japan-dutch-leaders-in-washington/ar-AA16hHpn?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-to-talk-china-tech-with-japan-dutch-leaders-in-washington/ar-AA16hHpn?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:42:20.482140+00:00
 - user: None



## Biden faces new pressure to bring federal workers back to the office
 - [http://www.msn.com/en-us/news/politics/biden-faces-new-pressure-to-bring-federal-workers-back-to-the-office/ar-AA16iLuE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-faces-new-pressure-to-bring-federal-workers-back-to-the-office/ar-AA16iLuE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:42:20.474319+00:00
 - user: None



## Hungary policeman dies as suspect tries to flee
 - [http://www.msn.com/en-us/news/world/hungary-policeman-dies-as-suspect-tries-to-flee/ar-AA16iIx7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/hungary-policeman-dies-as-suspect-tries-to-flee/ar-AA16iIx7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:42:20.467172+00:00
 - user: None



## Putin's military command reshuffle reveals a power struggle at the heart of the Ukraine war
 - [http://www.msn.com/en-us/news/world/putin-s-military-command-reshuffle-reveals-a-power-struggle-at-the-heart-of-the-ukraine-war/ar-AA16iLAy?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-military-command-reshuffle-reveals-a-power-struggle-at-the-heart-of-the-ukraine-war/ar-AA16iLAy?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:42:20.458847+00:00
 - user: None



## Secret rule change will see House lawmakers get a $34,000 PAY BUMP
 - [http://www.msn.com/en-us/news/politics/secret-rule-change-will-see-house-lawmakers-get-a-34-000-pay-bump/ar-AA16iDzd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/secret-rule-change-will-see-house-lawmakers-get-a-34-000-pay-bump/ar-AA16iDzd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:17:26.133673+00:00
 - user: None



## Suspect in assassination of Japan's Shinzo Abe is charged with murder
 - [http://www.msn.com/en-us/news/world/suspect-in-assassination-of-japan-s-shinzo-abe-is-charged-with-murder/ar-AA16if8k?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/suspect-in-assassination-of-japan-s-shinzo-abe-is-charged-with-murder/ar-AA16if8k?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:17:26.126300+00:00
 - user: None



## Researchers claim method to break encryption using existing quantum computer
 - [http://www.msn.com/en-us/news/technology/researchers-claim-method-to-break-encryption-using-existing-quantum-computer/ar-AA16iGqI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/researchers-claim-method-to-break-encryption-using-existing-quantum-computer/ar-AA16iGqI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:17:26.116185+00:00
 - user: None



## Shinzo Abe assassination: Suspect charged with murder in fatal shooting of Japan's former prime minister
 - [http://www.msn.com/en-us/news/world/shinzo-abe-assassination-suspect-charged-with-murder-in-fatal-shooting-of-japan-s-former-prime-minister/ar-AA16iyy8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/shinzo-abe-assassination-suspect-charged-with-murder-in-fatal-shooting-of-japan-s-former-prime-minister/ar-AA16iyy8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 08:17:26.108461+00:00
 - user: None



## Rifts in Russian military command seen amid Ukraine fighting
 - [http://www.msn.com/en-us/news/world/rifts-in-russian-military-command-seen-amid-ukraine-fighting/ar-AA16iDwB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/rifts-in-russian-military-command-seen-amid-ukraine-fighting/ar-AA16iDwB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 07:55:20.306628+00:00
 - user: None



## Hunter Biden among the storm clouds circling president’s reelection decision
 - [http://www.msn.com/en-us/news/politics/hunter-biden-among-the-storm-clouds-circling-president-s-reelection-decision/ar-AA16irjt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/hunter-biden-among-the-storm-clouds-circling-president-s-reelection-decision/ar-AA16irjt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 07:42:32.713949+00:00
 - user: None



## Democrats scramble to defend Biden's handling of classified materials, point fingers at Trump
 - [http://www.msn.com/en-us/news/politics/democrats-scramble-to-defend-biden-s-handling-of-classified-materials-point-fingers-at-trump/ar-AA16irme?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/democrats-scramble-to-defend-biden-s-handling-of-classified-materials-point-fingers-at-trump/ar-AA16irme?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 07:42:32.706329+00:00
 - user: None



## Alex Jones Accuses Piers Morgan of 'Mind Control' in Contentious Interview
 - [http://www.msn.com/en-us/news/us/alex-jones-accuses-piers-morgan-of-mind-control-in-contentious-interview/ar-AA16itlw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/alex-jones-accuses-piers-morgan-of-mind-control-in-contentious-interview/ar-AA16itlw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 07:17:22.032018+00:00
 - user: None



## Whither robust, Reagan-style defense budgets?
 - [http://www.msn.com/en-us/news/politics/whither-robust-reagan-style-defense-budgets/ar-AA16iwhg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/whither-robust-reagan-style-defense-budgets/ar-AA16iwhg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 07:17:22.019648+00:00
 - user: None



## Hunting for Nazi gold in a Dutch village
 - [http://www.msn.com/en-us/news/world/hunting-for-nazi-gold-in-a-dutch-village/ar-AA16it4O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/hunting-for-nazi-gold-in-a-dutch-village/ar-AA16it4O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:52:18.355505+00:00
 - user: None



## US stops hundreds of Cuban and Haitian immigrants from entering
 - [http://www.msn.com/en-us/news/us/us-stops-hundreds-of-cuban-and-haitian-immigrants-from-entering/ar-AA16iD7k?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-stops-hundreds-of-cuban-and-haitian-immigrants-from-entering/ar-AA16iD7k?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:52:18.348681+00:00
 - user: None



## Trump Organization to be sentenced for tax fraud, faces fine
 - [http://www.msn.com/en-us/news/politics/trump-organization-to-be-sentenced-for-tax-fraud-faces-fine/ar-AA16iD6B?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-organization-to-be-sentenced-for-tax-fraud-faces-fine/ar-AA16iD6B?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:52:18.339483+00:00
 - user: None



## Rep. Jim Banks eyes Indiana Senate seat
 - [http://www.msn.com/en-us/news/politics/rep-jim-banks-eyes-indiana-senate-seat/ar-AA16iqy8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-jim-banks-eyes-indiana-senate-seat/ar-AA16iqy8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:17:16.461647+00:00
 - user: None



## Squad member Ayanna Pressley opposes committee on China for fear of racism: 'Embolden anti-Asian rhetoric'
 - [http://www.msn.com/en-us/news/politics/squad-member-ayanna-pressley-opposes-committee-on-china-for-fear-of-racism-embolden-anti-asian-rhetoric/ar-AA16im5O?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/squad-member-ayanna-pressley-opposes-committee-on-china-for-fear-of-racism-embolden-anti-asian-rhetoric/ar-AA16im5O?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:17:16.454455+00:00
 - user: None



## Husband of missing Massachusetts mother threatened to kill her in 2014, police report says
 - [http://www.msn.com/en-us/news/crime/husband-of-missing-massachusetts-mother-threatened-to-kill-her-in-2014-police-report-says/ar-AA16ivN1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/husband-of-missing-massachusetts-mother-threatened-to-kill-her-in-2014-police-report-says/ar-AA16ivN1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:17:16.447192+00:00
 - user: None



## MLK holiday to feature tributes, commitments to race agenda
 - [http://www.msn.com/en-us/news/us/mlk-holiday-to-feature-tributes-commitments-to-race-agenda/ar-AA16ivR3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mlk-holiday-to-feature-tributes-commitments-to-race-agenda/ar-AA16ivR3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 06:17:16.439344+00:00
 - user: None



## Biden revealed to Jay Leno that Hunter refurbished his Corvette - that was in garage with documents
 - [http://www.msn.com/en-us/news/politics/biden-revealed-to-jay-leno-that-hunter-refurbished-his-corvette-that-was-in-garage-with-documents/ar-AA16ixTt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-revealed-to-jay-leno-that-hunter-refurbished-his-corvette-that-was-in-garage-with-documents/ar-AA16ixTt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:52:17.651329+00:00
 - user: None



## MSNBC Host Scolds Reporter for Using Term ‘Pro-Life’: ‘Not Accurate’
 - [http://www.msn.com/en-us/news/politics/msnbc-host-scolds-reporter-for-using-term-pro-life-not-accurate/ar-AA16hRTA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/msnbc-host-scolds-reporter-for-using-term-pro-life-not-accurate/ar-AA16hRTA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:52:17.644348+00:00
 - user: None



## Larry Hogan is betting on a Reaganite revival
 - [http://www.msn.com/en-us/news/politics/larry-hogan-is-betting-on-a-reaganite-revival/ar-AA16ixPl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/larry-hogan-is-betting-on-a-reaganite-revival/ar-AA16ixPl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:52:17.637337+00:00
 - user: None



## Even as NY nurses return to work, more strikes could follow
 - [http://www.msn.com/en-us/news/us/even-as-ny-nurses-return-to-work-more-strikes-could-follow/ar-AA16icHE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/even-as-ny-nurses-return-to-work-more-strikes-could-follow/ar-AA16icHE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:52:17.628668+00:00
 - user: None



## LAURA INGRAHAM: The American media ignored the longstanding corruption of Biden, Inc
 - [http://www.msn.com/en-us/news/politics/laura-ingraham-the-american-media-ignored-the-longstanding-corruption-of-biden-inc/ar-AA16ilDv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/laura-ingraham-the-american-media-ignored-the-longstanding-corruption-of-biden-inc/ar-AA16ilDv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:17:13.087764+00:00
 - user: None



## Black Lives Matter co-founder's cousin was tased 7 times in the back by LAPD officers before his death. The family's lawyer argues that the TASER was 'wrongly' activated.
 - [http://www.msn.com/en-us/news/crime/black-lives-matter-co-founder-s-cousin-was-tased-7-times-in-the-back-by-lapd-officers-before-his-death-the-family-s-lawyer-argues-that-the-taser-was-wrongly-activated/ar-AA16hRNf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/black-lives-matter-co-founder-s-cousin-was-tased-7-times-in-the-back-by-lapd-officers-before-his-death-the-family-s-lawyer-argues-that-the-taser-was-wrongly-activated/ar-AA16hRNf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:17:13.080610+00:00
 - user: None



## S. Korean police seek manslaughter charges over deadly crush
 - [http://www.msn.com/en-us/news/world/s-korean-police-seek-manslaughter-charges-over-deadly-crush/ar-AA16io7n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/s-korean-police-seek-manslaughter-charges-over-deadly-crush/ar-AA16io7n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 05:17:13.071771+00:00
 - user: None



## From Cold War to frozen conflicts
 - [http://www.msn.com/en-us/news/politics/from-cold-war-to-frozen-conflicts/ar-AA16i7sK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/from-cold-war-to-frozen-conflicts/ar-AA16i7sK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 04:52:11.165929+00:00
 - user: None



## TUCKER CARLSON: This is the beginning of the end for Biden
 - [http://www.msn.com/en-us/news/us/tucker-carlson-this-is-the-beginning-of-the-end-for-biden/ar-AA16hUiV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/tucker-carlson-this-is-the-beginning-of-the-end-for-biden/ar-AA16hUiV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 04:17:08.318772+00:00
 - user: None



## MTG explains support for McCarthy in Infowars appearance
 - [http://www.msn.com/en-us/news/politics/mtg-explains-support-for-mccarthy-in-infowars-appearance/ar-AA16hYX8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mtg-explains-support-for-mccarthy-in-infowars-appearance/ar-AA16hYX8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 04:17:08.311796+00:00
 - user: None



## Pakistan Seeks Change to U.S. World Finance Control as Cuba Leads U.N. Bloc
 - [http://www.msn.com/en-us/news/world/pakistan-seeks-change-to-u-s-world-finance-control-as-cuba-leads-u-n-bloc/ar-AA16inwq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/pakistan-seeks-change-to-u-s-world-finance-control-as-cuba-leads-u-n-bloc/ar-AA16inwq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 04:17:08.304077+00:00
 - user: None



## Oil giant CEO picked to lead UN climate conference
 - [http://www.msn.com/en-us/news/world/oil-giant-ceo-picked-to-lead-un-climate-conference/ar-AA16hVLu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/oil-giant-ceo-picked-to-lead-un-climate-conference/ar-AA16hVLu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 04:17:08.296501+00:00
 - user: None



## U.S. stops hundreds fleeing Cuba and Haiti by sea, returns most
 - [http://www.msn.com/en-us/news/world/u-s-stops-hundreds-fleeing-cuba-and-haiti-by-sea-returns-most/ar-AA16i9NX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-stops-hundreds-fleeing-cuba-and-haiti-by-sea-returns-most/ar-AA16i9NX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:06.029101+00:00
 - user: None



## Lightfoot says political outreach email to teachers was a 'mistake,' blames staffer: 'Shouldn't have happened'
 - [http://www.msn.com/en-us/news/politics/lightfoot-says-political-outreach-email-to-teachers-was-a-mistake-blames-staffer-shouldn-t-have-happened/ar-AA16iieR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lightfoot-says-political-outreach-email-to-teachers-was-a-mistake-blames-staffer-shouldn-t-have-happened/ar-AA16iieR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:06.021544+00:00
 - user: None



## My Favorite Hidden iPhone Shortcut To Turn On The Flashlight (And More)
 - [http://www.msn.com/en-us/news/technology/my-favorite-hidden-iphone-shortcut-to-turn-on-the-flashlight-and-more/ar-AA160olB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/my-favorite-hidden-iphone-shortcut-to-turn-on-the-flashlight-and-more/ar-AA160olB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:06.013718+00:00
 - user: None



## Special counsel named to investigate Biden classified records that included top secret document
 - [http://www.msn.com/en-us/news/politics/special-counsel-named-to-investigate-biden-classified-records-that-included-top-secret-document/ar-AA16gx7w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/special-counsel-named-to-investigate-biden-classified-records-that-included-top-secret-document/ar-AA16gx7w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:06.006090+00:00
 - user: None



## Another House Republican calls for George Santos to resign
 - [http://www.msn.com/en-us/news/politics/another-house-republican-calls-for-george-santos-to-resign/ar-AA16ikUv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/another-house-republican-calls-for-george-santos-to-resign/ar-AA16ikUv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:05.999041+00:00
 - user: None



## Putin's war in Ukraine has made Russia a 'liability' whose few friends are 'hardly at the top' of anyone's wishlist'
 - [http://www.msn.com/en-us/news/world/putin-s-war-in-ukraine-has-made-russia-a-liability-whose-few-friends-are-hardly-at-the-top-of-anyone-s-wishlist/ar-AA16hWPd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-war-in-ukraine-has-made-russia-a-liability-whose-few-friends-are-hardly-at-the-top-of-anyone-s-wishlist/ar-AA16hWPd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:05.991545+00:00
 - user: None



## Admitting ignorance is bliss
 - [http://www.msn.com/en-us/news/crime/admitting-ignorance-is-bliss/ar-AA16i9X8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/admitting-ignorance-is-bliss/ar-AA16i9X8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:05.984566+00:00
 - user: None



## City National Bank to pay $31M in redlining settlement with DOJ
 - [http://www.msn.com/en-us/news/us/city-national-bank-to-pay-31m-in-redlining-settlement-with-doj/ar-AA16idFh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/city-national-bank-to-pay-31m-in-redlining-settlement-with-doj/ar-AA16idFh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:52:05.976974+00:00
 - user: None



## What to expect from Super Nintendo World at Universal Studios, including the Mario Kart ride
 - [http://www.msn.com/en-us/news/technology/what-to-expect-from-super-nintendo-world-at-universal-studios-including-the-mario-kart-ride/ar-AA16i6Ky?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/what-to-expect-from-super-nintendo-world-at-universal-studios-including-the-mario-kart-ride/ar-AA16i6Ky?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:17:04.410855+00:00
 - user: None



## Lisa Marie Presley dies at 54
 - [http://www.msn.com/en-us/news/politics/lisa-marie-presley-dies-at-54/ar-AA16hQRK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lisa-marie-presley-dies-at-54/ar-AA16hQRK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:17:04.402248+00:00
 - user: None



## UN chief: Rule of law risks becoming `Rule of Lawlessness'
 - [http://www.msn.com/en-us/news/world/un-chief-rule-of-law-risks-becoming-rule-of-lawlessness/ar-AA16ii9c?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/un-chief-rule-of-law-risks-becoming-rule-of-lawlessness/ar-AA16ii9c?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:17:04.394523+00:00
 - user: None



## Santos again rejects calls to resign, says all '142,000 voters' would have to ask
 - [http://www.msn.com/en-us/news/politics/santos-again-rejects-calls-to-resign-says-all-142-000-voters-would-have-to-ask/ar-AA16gsWK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/santos-again-rejects-calls-to-resign-says-all-142-000-voters-would-have-to-ask/ar-AA16gsWK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 03:17:04.385901+00:00
 - user: None



## If Donald Trump Gets Reelected, What 'Will Soon Happen Again'?
 - [http://www.msn.com/en-us/news/politics/if-donald-trump-gets-reelected-what-will-soon-happen-again/ar-AA16ifI7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/if-donald-trump-gets-reelected-what-will-soon-happen-again/ar-AA16ifI7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:52:00.906079+00:00
 - user: None



## 6 dead after destructive tornadoes hit Alabama
 - [http://www.msn.com/en-us/news/us/6-dead-after-destructive-tornadoes-hit-alabama/ar-AA16hUH8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/6-dead-after-destructive-tornadoes-hit-alabama/ar-AA16hUH8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:52:00.897815+00:00
 - user: None



## 'Rick and Morty' Creator Justin Roiland Charged With Battery
 - [http://www.msn.com/en-us/news/technology/rick-and-morty-creator-justin-roiland-charged-with-battery/ar-AA16ifqd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/rick-and-morty-creator-justin-roiland-charged-with-battery/ar-AA16ifqd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:52:00.889261+00:00
 - user: None



## White House won't say how many people could have accessed classified Biden documents in garage
 - [http://www.msn.com/en-us/news/us/white-house-won-t-say-how-many-people-could-have-accessed-classified-biden-documents-in-garage/ar-AA16hP8N?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/white-house-won-t-say-how-many-people-could-have-accessed-classified-biden-documents-in-garage/ar-AA16hP8N?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:52:00.881677+00:00
 - user: None



## Brazil reckons with artistic treasures ruined in riot
 - [http://www.msn.com/en-us/news/world/brazil-reckons-with-artistic-treasures-ruined-in-riot/ar-AA16ibpu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/brazil-reckons-with-artistic-treasures-ruined-in-riot/ar-AA16ibpu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:52:00.872653+00:00
 - user: None



## See SpaceX Starship Gleaming on the Launchpad in Epic New Images
 - [http://www.msn.com/en-us/news/technology/see-spacex-starship-gleaming-on-the-launchpad-in-epic-new-images/ar-AA16hA47?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/see-spacex-starship-gleaming-on-the-launchpad-in-epic-new-images/ar-AA16hA47?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:17:07.315924+00:00
 - user: None



## JESSE WATTERS: Everywhere Biden's aides look, they find something new that surprises Joe
 - [http://www.msn.com/en-us/news/us/jesse-watters-everywhere-biden-s-aides-look-they-find-something-new-that-surprises-joe/ar-AA16i4EL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jesse-watters-everywhere-biden-s-aides-look-they-find-something-new-that-surprises-joe/ar-AA16i4EL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:17:07.308915+00:00
 - user: None



## More Republicans call for George Santos to resign over lies and fabrications
 - [http://www.msn.com/en-us/news/politics/more-republicans-call-for-george-santos-to-resign-over-lies-and-fabrications/ar-AA16gSjT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/more-republicans-call-for-george-santos-to-resign-over-lies-and-fabrications/ar-AA16gSjT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 02:17:07.301359+00:00
 - user: None



## WSJ Opinion: Special Counsels, Corvettes and Classified Documents
 - [http://www.msn.com/en-us/news/world/wsj-opinion-special-counsels-corvettes-and-classified-documents/vi-AA16iaLt?srcref=rss](http://www.msn.com/en-us/news/world/wsj-opinion-special-counsels-corvettes-and-classified-documents/vi-AA16iaLt?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.221128+00:00
 - user: None



## Biden's words on Trump raid come back to haunt him, just like Hillary's comments on Benghazi, critics say
 - [http://www.msn.com/en-us/news/politics/biden-s-words-on-trump-raid-come-back-to-haunt-him-just-like-hillary-s-comments-on-benghazi-critics-say/ar-AA16iaFz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-words-on-trump-raid-come-back-to-haunt-him-just-like-hillary-s-comments-on-benghazi-critics-say/ar-AA16iaFz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.214213+00:00
 - user: None



## Pentagon receives more than 350 new reports of UFO sightings
 - [http://www.msn.com/en-us/news/us/pentagon-receives-more-than-350-new-reports-of-ufo-sightings/ar-AA16i1q6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/pentagon-receives-more-than-350-new-reports-of-ufo-sightings/ar-AA16i1q6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.187919+00:00
 - user: None



## Key dates in discovery of classified records tied to Biden
 - [http://www.msn.com/en-us/news/politics/key-dates-in-discovery-of-classified-records-tied-to-biden/ar-AA16i8Eh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/key-dates-in-discovery-of-classified-records-tied-to-biden/ar-AA16i8Eh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.180921+00:00
 - user: None



## WATCH: Paul Ryan praises fiscal conservatism theme in speaker concessions
 - [http://www.msn.com/en-us/news/politics/watch-paul-ryan-praises-fiscal-conservatism-theme-in-speaker-concessions/ar-AA16i8UH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-paul-ryan-praises-fiscal-conservatism-theme-in-speaker-concessions/ar-AA16i8UH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.173952+00:00
 - user: None



## Mother of Idaho Victim Remembers 'Carefree' and 'Happy' Son as His Siblings Return to University
 - [http://www.msn.com/en-us/news/crime/mother-of-idaho-victim-remembers-carefree-and-happy-son-as-his-siblings-return-to-university/ar-AA16i1yj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/mother-of-idaho-victim-remembers-carefree-and-happy-son-as-his-siblings-return-to-university/ar-AA16i1yj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.158488+00:00
 - user: None



## Wisconsin, North Carolina become latest states to ban TikTok from government devices
 - [http://www.msn.com/en-us/news/politics/wisconsin-north-carolina-become-latest-states-to-ban-tiktok-from-government-devices/ar-AA16hOSu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/wisconsin-north-carolina-become-latest-states-to-ban-tiktok-from-government-devices/ar-AA16hOSu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:51:54.151148+00:00
 - user: None



## Kamala Harris mocked for repeating several word salads during climate crisis talk: 'WTF is her deal'
 - [http://www.msn.com/en-us/news/politics/kamala-harris-mocked-for-repeating-several-word-salads-during-climate-crisis-talk-wtf-is-her-deal/ar-AA16hQbg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kamala-harris-mocked-for-repeating-several-word-salads-during-climate-crisis-talk-wtf-is-her-deal/ar-AA16hQbg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.086789+00:00
 - user: None



## Bipartisan tech sector scrutiny grows
 - [http://www.msn.com/en-us/news/politics/bipartisan-tech-sector-scrutiny-grows/ar-AA16hTjO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/bipartisan-tech-sector-scrutiny-grows/ar-AA16hTjO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.078130+00:00
 - user: None



## A Special Counsel May End Up Protecting Biden Admin From GOP Witch Hunts
 - [http://www.msn.com/en-us/news/politics/a-special-counsel-may-end-up-protecting-biden-admin-from-gop-witch-hunts/ar-AA16iayp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/a-special-counsel-may-end-up-protecting-biden-admin-from-gop-witch-hunts/ar-AA16iayp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.069929+00:00
 - user: None



## Set Your Thermostat to This Exact Temperature to Save Money on Heating Now
 - [http://www.msn.com/en-us/news/technology/set-your-thermostat-to-this-exact-temperature-to-save-money-on-heating-now/ar-AASb5qP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/set-your-thermostat-to-this-exact-temperature-to-save-money-on-heating-now/ar-AASb5qP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.062964+00:00
 - user: None



## Caretaker arrested as search for missing Oklahoma 4-year-old continues
 - [http://www.msn.com/en-us/news/crime/caretaker-arrested-as-search-for-missing-oklahoma-4-year-old-continues/ar-AA16gbgO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/caretaker-arrested-as-search-for-missing-oklahoma-4-year-old-continues/ar-AA16gbgO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.027435+00:00
 - user: None



## US renames 5 places that used racist slur for a Native woman
 - [http://www.msn.com/en-us/news/us/us-renames-5-places-that-used-racist-slur-for-a-native-woman/ar-AA16i5Tb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/us-renames-5-places-that-used-racist-slur-for-a-native-woman/ar-AA16i5Tb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 01:16:54.019373+00:00
 - user: None



## Chinese police arrest man who plowed into crowd, killing 5 people, injuring others
 - [http://www.msn.com/en-us/news/world/chinese-police-arrest-man-who-plowed-into-crowd-killing-5-people-injuring-others/ar-AA16hJvL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/chinese-police-arrest-man-who-plowed-into-crowd-killing-5-people-injuring-others/ar-AA16hJvL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.684917+00:00
 - user: None



## Scroll-Wheel Click Will Help You Comparison Shop
 - [http://www.msn.com/en-us/news/technology/scroll-wheel-click-will-help-you-comparison-shop/ar-AA13oIna?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/scroll-wheel-click-will-help-you-comparison-shop/ar-AA13oIna?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.677756+00:00
 - user: None



## Calmes: Republicans have rediscovered fiscal conservatism. Don't believe it for a minute.
 - [http://www.msn.com/en-us/news/politics/calmes-republicans-have-rediscovered-fiscal-conservatism-don-t-believe-it-for-a-minute/ar-AA16hJG6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/calmes-republicans-have-rediscovered-fiscal-conservatism-don-t-believe-it-for-a-minute/ar-AA16hJG6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.669942+00:00
 - user: None



## In Case of an Emergency or Evacuation, These Essentials Keep Pets Safe
 - [http://www.msn.com/en-us/news/technology/in-case-of-an-emergency-or-evacuation-these-essentials-keep-pets-safe/ar-AA16i5zH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/in-case-of-an-emergency-or-evacuation-these-essentials-keep-pets-safe/ar-AA16i5zH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.662209+00:00
 - user: None



## 4-year-old missing after postal worker finds sister alone; caretaker arrested: Police
 - [http://www.msn.com/en-us/news/crime/4-year-old-missing-after-postal-worker-finds-sister-alone-caretaker-arrested-police/ar-AA16hxMM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/4-year-old-missing-after-postal-worker-finds-sister-alone-caretaker-arrested-police/ar-AA16hxMM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.654860+00:00
 - user: None



## Alaska governor pitches plan to capitalize on carbon markets
 - [http://www.msn.com/en-us/news/politics/alaska-governor-pitches-plan-to-capitalize-on-carbon-markets/ar-AA16i165?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/alaska-governor-pitches-plan-to-capitalize-on-carbon-markets/ar-AA16i165?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.646134+00:00
 - user: None



## Alabama governor declares state of emergency as tornadoes sweep through state
 - [http://www.msn.com/en-us/news/us/alabama-governor-declares-state-of-emergency-as-tornadoes-sweep-through-state/ar-AA16hzxQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/alabama-governor-declares-state-of-emergency-as-tornadoes-sweep-through-state/ar-AA16hzxQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.638475+00:00
 - user: None



## Man Allegedly Handcuffed, Stabbed Wife to Death After She Filed for Divorce
 - [http://www.msn.com/en-us/news/crime/man-allegedly-handcuffed-stabbed-wife-to-death-after-she-filed-for-divorce/ar-AA16hOrR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-allegedly-handcuffed-stabbed-wife-to-death-after-she-filed-for-divorce/ar-AA16hOrR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:51:48.630458+00:00
 - user: None



## White House says it's being 'transparent' about classified documents despite keeping under wraps for months
 - [http://www.msn.com/en-us/news/politics/white-house-says-it-s-being-transparent-about-classified-documents-despite-keeping-under-wraps-for-months/ar-AA16hVBp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-says-it-s-being-transparent-about-classified-documents-despite-keeping-under-wraps-for-months/ar-AA16hVBp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:56.751171+00:00
 - user: None



## Biden classified documents: What we know about the special counsel probe
 - [http://www.msn.com/en-us/news/politics/biden-classified-documents-what-we-know-about-the-special-counsel-probe/ar-AA16hOba?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-classified-documents-what-we-know-about-the-special-counsel-probe/ar-AA16hOba?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:56.214062+00:00
 - user: None



## A Black woman in Philadelphia spent almost a week in jail because Texas police thought she looked like a shoplifter. But she had never been to Texas.
 - [http://www.msn.com/en-us/news/crime/a-black-woman-in-philadelphia-spent-almost-a-week-in-jail-because-texas-police-thought-she-looked-like-a-shoplifter-but-she-had-never-been-to-texas/ar-AA16i0RR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-black-woman-in-philadelphia-spent-almost-a-week-in-jail-because-texas-police-thought-she-looked-like-a-shoplifter-but-she-had-never-been-to-texas/ar-AA16i0RR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:56.206836+00:00
 - user: None



## Republican candidate's wife arrested, charged with casting 23 fraudulent votes for her husband in the 2020 election
 - [http://www.msn.com/en-us/news/politics/republican-candidate-s-wife-arrested-charged-with-casting-23-fraudulent-votes-for-her-husband-in-the-2020-election/ar-AA16hJmX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republican-candidate-s-wife-arrested-charged-with-casting-23-fraudulent-votes-for-her-husband-in-the-2020-election/ar-AA16hJmX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:56.199617+00:00
 - user: None



## Why Merrick Garland appointed a special counsel to the Biden classified documents case
 - [http://www.msn.com/en-us/news/politics/why-merrick-garland-appointed-a-special-counsel-to-the-biden-classified-documents-case/ar-AA16i5kr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/why-merrick-garland-appointed-a-special-counsel-to-the-biden-classified-documents-case/ar-AA16i5kr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:55.661711+00:00
 - user: None



## On The Money — Inflation sees rapid cooldown
 - [http://www.msn.com/en-us/news/politics/on-the-money-inflation-sees-rapid-cooldown/ar-AA16i5jk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/on-the-money-inflation-sees-rapid-cooldown/ar-AA16i5jk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:55.653177+00:00
 - user: None



## FACT FOCUS: Biden administration isn't banning gas stoves
 - [http://www.msn.com/en-us/news/politics/fact-focus-biden-administration-isn-t-banning-gas-stoves/ar-AA16hVET?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fact-focus-biden-administration-isn-t-banning-gas-stoves/ar-AA16hVET?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:55.645399+00:00
 - user: None



## HBO Max Review: Expensive but Its Catalog Is Packed
 - [http://www.msn.com/en-us/news/technology/hbo-max-review-expensive-but-its-catalog-is-packed/ar-AAWM5gX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/hbo-max-review-expensive-but-its-catalog-is-packed/ar-AAWM5gX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-13 00:10:55.206999+00:00
 - user: None


