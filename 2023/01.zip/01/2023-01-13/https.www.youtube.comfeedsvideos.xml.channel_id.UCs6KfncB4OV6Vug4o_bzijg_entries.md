# Source Techlore, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg, Source language: en-US

## Is There an Oversaturation of FOSS Projects?! - Techlore Talks #6
 - [https://www.youtube.com/watch?v=at3nJpSrFNc](https://www.youtube.com/watch?v=at3nJpSrFNc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCs6KfncB4OV6Vug4o_bzijg
 - date published: 2023-01-13 17:30:01+00:00
 - user: None

Are there too many open source projects? Or too many of the wrong type? Or is everything a-okay? Today we chat about what feels like the oversaturation of FOSS.

🔐 Our Website: https://techlore.tech
✉️ Techlore Dispatch & Blog: https://dispatch.techlore.tech
🕵 Go Incognito Course: https://techlore.tech/goincognito
📹 Odysee: https://odysee.com/@techlore:3
📹 PeerTube: https://tilvids.com/c/techlore_channel/videos

Connect with others in the privacy community:
💻 Our Forum: https://discuss.techlore.tech
Ⓜ️ Mastodon: https://social.lol/@techlore
👾 Discord: https://discord.techlore.tech

Support our mission to spread privacy to the masses:
💖 All Support Methods: https://techlore.tech/support
🧡 Patreon: https://www.patreon.com/techlore
🪙 Monero: 49H4jTvUY5zaX8qLpVBstJFR7ayTMxxU3UyWpGqUoBM4UzM2zwUHA2sJ9i3AhQYdaqhFmS8PDfWKn1Tea4SKU6haMTXG8qD
#FOSS #opensource #techlore
