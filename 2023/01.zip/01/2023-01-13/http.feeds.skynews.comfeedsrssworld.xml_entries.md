# Source Sky News, Source URL:http://feeds.skynews.com/feeds/rss/world.xml, Source language: en-US

## Princess faces eviction from stunning villa with rare renaissance mural
 - [https://news.sky.com/story/princess-faces-eviction-from-stunning-roman-villa-with-caravaggio-mural-12786114](https://news.sky.com/story/princess-faces-eviction-from-stunning-roman-villa-with-caravaggio-mural-12786114)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 20:58:00+00:00
 - user: None

A Texas-born Italian princess faces eviction from a Roman villa which has the world's only known mural painted by the renaissance artist Caravaggio, as part of a bitter inheritance battle over the future of the unique property.

## Soledar may have fallen - but Ukraine says Russia has lost large number of troops for not much gain
 - [https://news.sky.com/story/ukraine-war-soledar-may-have-fallen-but-ukrainians-say-russia-has-lost-large-number-of-troops-for-not-much-gain-12786026](https://news.sky.com/story/ukraine-war-soledar-may-have-fallen-but-ukrainians-say-russia-has-lost-large-number-of-troops-for-not-much-gain-12786026)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 19:11:00+00:00
 - user: None

The air crackles with the sound of gunfire.

## Jailed Hong Kong media tycoon Jimmy Lai's son criticises UK govt for failing to denounce China
 - [https://news.sky.com/story/jailed-hong-kong-media-tycoon-jimmy-lais-son-criticises-uk-government-for-failing-to-denounce-china-12785966](https://news.sky.com/story/jailed-hong-kong-media-tycoon-jimmy-lais-son-criticises-uk-government-for-failing-to-denounce-china-12785966)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 17:56:00+00:00
 - user: None

The son of media mogul and British citizen Jimmy Lai, jailed in Hong Kong for allegedly breaking national security laws, has criticised the UK government for failing to speak out against China.

## Explosion hits gas pipeline connecting Lithuania and Latvia - nearby village evacuated
 - [https://news.sky.com/story/explosion-hits-gas-pipeline-connecting-lithuania-and-latvia-nearby-village-evacuated-12785961](https://news.sky.com/story/explosion-hits-gas-pipeline-connecting-lithuania-and-latvia-nearby-village-evacuated-12785961)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 17:49:00+00:00
 - user: None

An explosion has hit a gas pipeline connecting Lithuania and Latvia.

## Explosion hits gas pipeline connecting Lithuania and Latvia - nearby village set to be evacuated
 - [https://news.sky.com/story/explosion-hits-gas-pipeline-between-lithuania-and-latvia-nearby-village-set-to-be-evacuated-12785961](https://news.sky.com/story/explosion-hits-gas-pipeline-between-lithuania-and-latvia-nearby-village-set-to-be-evacuated-12785961)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 17:49:00+00:00
 - user: None

An explosion has hit a gas pipeline connecting Lithuania and Latvia.

## At least nine dead after US tornadoes hit southern states - as tens of thousands left without power
 - [https://news.sky.com/story/us-tornadoes-at-least-nine-dead-after-southern-states-hit-as-tens-of-thousands-of-people-left-without-power-12785920](https://news.sky.com/story/us-tornadoes-at-least-nine-dead-after-southern-states-hit-as-tens-of-thousands-of-people-left-without-power-12785920)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 16:48:00+00:00
 - user: None

At least nine people have been killed in the US after dozens of tornadoes struck the southern states of Alabama and Georgia.

## Thunberg joins protests at German village under threat of destruction over coal mine
 - [https://news.sky.com/story/greta-thunberg-joins-protests-at-german-village-under-threat-of-destruction-over-coal-mine-12785896](https://news.sky.com/story/greta-thunberg-joins-protests-at-german-village-under-threat-of-destruction-over-coal-mine-12785896)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 16:11:00+00:00
 - user: None

Greta Thunberg has condemned the forced removal of protesters from a small village in western Germany that is due to be demolished to accommodate the expansion of an open coal mine.

## Culture of silence as Russians warned of being pawns in propaganda battle
 - [https://news.sky.com/story/ukraine-war-culture-of-silence-as-ordinary-russians-warned-of-being-unwary-pawns-in-propaganda-battle-12785882](https://news.sky.com/story/ukraine-war-culture-of-silence-as-ordinary-russians-warned-of-being-unwary-pawns-in-propaganda-battle-12785882)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 15:22:00+00:00
 - user: None

The grave is fresh, surrounded by memorial wreaths from the Samara governor and from Russia's defence ministry.

## Woman ordered to pay damages to ex-employer after tracking software exposed 'time theft'
 - [https://news.sky.com/story/canada-time-theft-woman-ordered-to-pay-damages-to-her-former-employer-after-tracking-software-exposed-serious-misconduct-12785725](https://news.sky.com/story/canada-time-theft-woman-ordered-to-pay-damages-to-her-former-employer-after-tracking-software-exposed-serious-misconduct-12785725)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 12:27:00+00:00
 - user: None

A women in Canada has been ordered by a civil tribunal to pay damages to her former employer for "time theft" after she was caught claiming for unworked hours by tracking software.

## Exxon predicted global warming in 1970s despite publicly dismissing climate change, research finds
 - [https://news.sky.com/story/exxon-predicted-global-warming-in-1970s-despite-publicly-dismissing-climate-change-research-finds-12785585](https://news.sky.com/story/exxon-predicted-global-warming-in-1970s-despite-publicly-dismissing-climate-change-research-finds-12785585)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 09:56:00+00:00
 - user: None

Scientists working at oil giant Exxon Mobil in the 1970s predicted global warming with "astonishing" accuracy while the company publicly contradicted the research, a study has found.

## Ukraine War Diaries: Using comedy to cope with war
 - [https://news.sky.com/story/ukraine-war-diaries-using-comedy-to-cope-with-war-12785565](https://news.sky.com/story/ukraine-war-diaries-using-comedy-to-cope-with-war-12785565)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 09:24:00+00:00
 - user: None

The idea of a comedy night in a country twisted out of shape by war, jars somewhat against the backdrop of blitz-like living conditions and mounting casualties in eastern Ukraine.

## South Korean police seek manslaughter and negligence charges against officials over crowd crush
 - [https://news.sky.com/story/south-korea-crowd-crush-police-seek-manslaughter-and-negligence-charges-against-officials-12785560](https://news.sky.com/story/south-korea-crowd-crush-police-seek-manslaughter-and-negligence-charges-against-officials-12785560)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 09:13:00+00:00
 - user: None

An investigation into last year's Halloween crush in the South Korean capital, in which nearly 160 people died, says 23 officials should be charged for an alleged lack of safety measures.

## TikTok star known for eating bizarre foods dies 'from presumed heart attack'
 - [https://news.sky.com/story/tiktok-star-waffler69-who-was-known-for-eating-bizarre-foods-dies-from-presumed-heart-attack-12785543](https://news.sky.com/story/tiktok-star-waffler69-who-was-known-for-eating-bizarre-foods-dies-from-presumed-heart-attack-12785543)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 08:55:00+00:00
 - user: None

A TikTok star who went viral for posting videos of himself eating bizarre snacks and expired food has died aged 33.

## Adidas loses court battle against fashion designer over stripe design
 - [https://news.sky.com/story/adidas-loses-court-battle-against-fashion-designer-thom-browne-over-stripe-design-12785527](https://news.sky.com/story/adidas-loses-court-battle-against-fashion-designer-thom-browne-over-stripe-design-12785527)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-13 08:24:00+00:00
 - user: None

Adidas has lost a court case against New York fashion designer Thom Browne after suing over a stripe design.
