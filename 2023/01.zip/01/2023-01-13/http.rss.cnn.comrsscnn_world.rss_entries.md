# Source CNN World, Source URL:http://rss.cnn.com/rss/cnn_world.rss, Source language: en-US

## 'This is the last thing we need:' Millions of businesses hammered by the pandemic need to start paying back Covid loans
 - [https://www.cnn.com/2023/01/13/economy/small-business-eidl-pandemic-loan-repayment/index.html](https://www.cnn.com/2023/01/13/economy/small-business-eidl-pandemic-loan-repayment/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-13 12:58:04+00:00
 - user: None

At Teddy & The Bully Bar restaurant near downtown Washington, DC, business has never been the same since the pandemic hit.

## Egg prices exploded 60% higher last year. These food prices surged too
 - [https://www.cnn.com/2023/01/12/economy/food-prices-inflation-december/index.html](https://www.cnn.com/2023/01/12/economy/food-prices-inflation-december/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-13 11:47:57+00:00
 - user: None

Eggs, milk, butter, flour ... if you were making pancakes last year, it would have cost you. Food prices surged in 2022.
