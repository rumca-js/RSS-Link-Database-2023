# Source NY times technology, Source URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, Source language: en-US

## Bob Jordan, Southwest Airlines’ CEO, on What Went Wrong
 - [https://www.nytimes.com/2023/01/13/business/southwest-airlines-bob-jordan.html](https://www.nytimes.com/2023/01/13/business/southwest-airlines-bob-jordan.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-13 19:57:56+00:00
 - user: None

Southwest Airlines’ chief executive, Bob Jordan, said frigid temperatures and mistakes by the company caused its meltdown around Christmas.

## Bob Jordan, Southwest Airlines’ CEO, on What Went Wrong
 - [https://www.nytimes.com/2023/01/13/business/southwest-airlines-bob-jordan-corner-office.html](https://www.nytimes.com/2023/01/13/business/southwest-airlines-bob-jordan-corner-office.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-13 19:06:36+00:00
 - user: None

Southwest Airlines’ chief executive, Bob Jordan, said frigid temperatures and mistakes by the company caused its meltdown around Christmas.

## A Teacher Who Loves ChatGPT and Is ‘M3GAN’ Real?
 - [https://www.nytimes.com/2023/01/13/podcasts/hard-fork-chatgpt-teachers-gen-z-cameras-m3gan.html](https://www.nytimes.com/2023/01/13/podcasts/hard-fork-chatgpt-teachers-gen-z-cameras-m3gan.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-13 10:05:05+00:00
 - user: None

Also, why teenagers are buying old digital cameras.
