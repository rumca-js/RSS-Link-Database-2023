# Source Wydarzenia Interia, Source URL:https://wydarzenia.interia.pl/feed, Source language: pl-PL

## Wiceszef MSZ: Rosyjskie wojska na Białorusi powinny uruchomić dzwonki alarmowe
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wiceszef-msz-rosyjskie-wojska-na-bialorusi-powinny-uruchomic,nId,6532928](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wiceszef-msz-rosyjskie-wojska-na-bialorusi-powinny-uruchomic,nId,6532928)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 23:25:13+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wiceszef-msz-rosyjskie-wojska-na-bialorusi-powinny-uruchomic,nId,6532928"><img align="left" alt="Wiceszef MSZ: Rosyjskie wojska na Białorusi powinny uruchomić dzwonki alarmowe" src="https://i.iplsc.com/wiceszef-msz-rosyjskie-wojska-na-bialorusi-powinny-uruchomic/000ETZA5YWOPIEH8-C321.jpg" /></a>- Przyspieszająca koncentracja sił rosyjskich na Białorusi i planowane ćwiczenia wojsk obu państw powinny uruchomić dodatkowe dzwonki alarmowe - powiedział w piątek wiceminister spraw zagranicznych RP Wojciech Gerwel. Jak dodał, takie gromadzenie sił zwiastuje &quot;negatywne konsekwencje&quot;.</p><br clear="all" />

## Paryż: Trzylatka znaleziona w pralce. Mimo reanimacji zmarła
 - [https://wydarzenia.interia.pl/zagranica/news-paryz-trzylatka-znaleziona-w-pralce-mimo-reanimacji-zmarla,nId,6532919](https://wydarzenia.interia.pl/zagranica/news-paryz-trzylatka-znaleziona-w-pralce-mimo-reanimacji-zmarla,nId,6532919)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 22:58:02+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-paryz-trzylatka-znaleziona-w-pralce-mimo-reanimacji-zmarla,nId,6532919"><img align="left" alt="Paryż: Trzylatka znaleziona w pralce. Mimo reanimacji zmarła" src="https://i.iplsc.com/paryz-trzylatka-znaleziona-w-pralce-mimo-reanimacji-zmarla/000APX7P4ELTEJJ1-C321.jpg" /></a>Do tragedii doszło w Paryżu w czwartek wieczorem. To tam ojciec trzyletniej dziewczynki znalazł swoją córkę uwięzioną w pralce. Dziecko było w stanie krytycznym. Mimo około godzinnej reanimacji życia trzylatki nie udało się uratować.</p><br clear="all" />

## Watykan: Książka abpa Gaensweina ujawnia kontrowersyjne sekrety
 - [https://wydarzenia.interia.pl/zagranica/news-watykan-ksiazka-abpa-gaensweina-ujawnia-kontrowersyjne-sekre,nId,6532917](https://wydarzenia.interia.pl/zagranica/news-watykan-ksiazka-abpa-gaensweina-ujawnia-kontrowersyjne-sekre,nId,6532917)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 22:22:13+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-watykan-ksiazka-abpa-gaensweina-ujawnia-kontrowersyjne-sekre,nId,6532917"><img align="left" alt="Watykan: Książka abpa Gaensweina ujawnia kontrowersyjne sekrety" src="https://i.iplsc.com/watykan-ksiazka-abpa-gaensweina-ujawnia-kontrowersyjne-sekre/000GM98I6FO3DOCM-C321.jpg" /></a>Książka prywatnego sekretarza Benedykta XVI Georga Gaensweina opowiada o trudnych relacjach i koegzystencji dwóch papieży w Watykanie. Włoskie media informowały, że część kardynałów i arcybiskupów przestrzegało Gaensweina, by &quot;lepiej milczał&quot;, publikacja ujrzała jednak światło dzienne, wbrew woli Watykanu. Dzieło ujawnia wiele napięć i konfliktów wewnętrznych wśród władz Kościoła. Zdaniem niektórych może doprowadzić do polemik, a nawet podziałów.</p><br clear="all" />

## Niemieckie media: Christine Lambrecht postanowiła podać się do dymisji
 - [https://wydarzenia.interia.pl/zagranica/news-niemieckie-media-christine-lambrecht-postanowila-podac-sie-d,nId,6532906](https://wydarzenia.interia.pl/zagranica/news-niemieckie-media-christine-lambrecht-postanowila-podac-sie-d,nId,6532906)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 21:25:31+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemieckie-media-christine-lambrecht-postanowila-podac-sie-d,nId,6532906"><img align="left" alt="Niemieckie media: Christine Lambrecht postanowiła podać się do dymisji" src="https://i.iplsc.com/niemieckie-media-christine-lambrecht-postanowila-podac-sie-d/0009DRF1OOBKX05S-C321.jpg" /></a>Christine Lambrecht (SPD), niemiecka minister obrony narodowej, postanowiła podać się do dymisji - przekazuje portal dziennika &quot;Bild&quot;, powołując się na kilka źródeł. &quot;Bild&quot; podkreśla, że inicjatywa miała wyjść nie od kanclerza Olafa Scholza, a od samej minister. Kwestia następcy Lambrecht &quot;jest już przedmiotem wewnętrznych dyskusji&quot;, choć wciąż nie wiadomo, kiedy dokładnie nastąpić ma rezygnacja.</p><br clear="all" />

## Przetrzymywali go od miesięcy w Iranie. Polski biolog wrócił do kraju
 - [https://wydarzenia.interia.pl/kraj/news-przetrzymywali-go-od-miesiecy-w-iranie-polski-biolog-wrocil-,nId,6532905](https://wydarzenia.interia.pl/kraj/news-przetrzymywali-go-od-miesiecy-w-iranie-polski-biolog-wrocil-,nId,6532905)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 20:58:01+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-przetrzymywali-go-od-miesiecy-w-iranie-polski-biolog-wrocil-,nId,6532905"><img align="left" alt="Przetrzymywali go od miesięcy w Iranie. Polski biolog wrócił do kraju" src="https://i.iplsc.com/przetrzymywali-go-od-miesiecy-w-iranie-polski-biolog-wrocil/000GM94ZAY05NXOL-C321.jpg" /></a>Polski biolog przetrzymywany od miesięcy w irańskim więzieniu wrócił w grudniu do kraju - poinformował rzecznik ministerstwa spraw zagranicznych Łukasz Jasina. Profesor UMK wraz z grupą obcokrajowców został zatrzymany w Iranie we wrześniu 2021 roku.</p><br clear="all" />

## Marcin Przydacz o tekście Piotra Zaremby: Narracja rosyjskiej propagandy
 - [https://wydarzenia.interia.pl/kraj/news-marcin-przydacz-o-tekscie-piotra-zaremby-narracja-rosyjskiej,nId,6532896](https://wydarzenia.interia.pl/kraj/news-marcin-przydacz-o-tekscie-piotra-zaremby-narracja-rosyjskiej,nId,6532896)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 20:21:39+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-marcin-przydacz-o-tekscie-piotra-zaremby-narracja-rosyjskiej,nId,6532896"><img align="left" alt="Marcin Przydacz o tekście Piotra Zaremby: Narracja rosyjskiej propagandy" src="https://i.iplsc.com/marcin-przydacz-o-tekscie-piotra-zaremby-narracja-rosyjskiej/000GM93356EG6HUW-C321.jpg" /></a>- Uważam tego typu narrację za szkodliwą dla całości państwa polskiego. Próba imputowania, że są jakieś zewnętrzne naciski, pod wpływem których podejmowane są decyzje w Polsce, to sugestie kojarzone ze środowiskiem sprzyjającym Rosji - powiedział w Polsat News szef prezydenckiego Biura Polityki Międzynarodowej Marcin Przydacz. W ten sposób odniósł się do felietonu Piotra Zaremby, który sugerował, że &quot;prezydent Andrzej Duda zawetował 'lex Czarnek 2.0' po interwencji amerykańskiego sekretarza stanu Antonego Blinkena&quot;. Pałac Prezydencki...</p><br clear="all" />

## Import gazu do Niemiec. Scholz: Irak byłby mile widzianym partnerem do współpracy
 - [https://wydarzenia.interia.pl/zagranica/news-import-gazu-do-niemiec-scholz-irak-bylby-mile-widzianym-part,nId,6532892](https://wydarzenia.interia.pl/zagranica/news-import-gazu-do-niemiec-scholz-irak-bylby-mile-widzianym-part,nId,6532892)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 20:11:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-import-gazu-do-niemiec-scholz-irak-bylby-mile-widzianym-part,nId,6532892"><img align="left" alt="Import gazu do Niemiec. Scholz: Irak byłby mile widzianym partnerem do współpracy" src="https://i.iplsc.com/import-gazu-do-niemiec-scholz-irak-bylby-mile-widzianym-part/000GM8Y6Y70E1XPP-C321.jpg" /></a>Olaf Scholz opowiedział się za importem gazu z Iraku. Jak przekazał w piątek na konferencji prasowej w Berlinie: - Irak byłby dla nas bardzo mile widzianym partnerem do współpracy w zakresie importu gazu i ropy do Niemiec. Kanclerz Niemiec, cytowany przez agencję dpa, stwierdził też, że &quot;import gazu mógłby być również kierowany do innych krajów europejskich przez Niemcy&quot;.</p><br clear="all" />

## Polka ciężko ranna w Bachmucie: Leżałam na ziemi, obok śpiewała kobieta
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polka-ciezko-ranna-w-bachmucie-lezalam-na-ziemi-obok-spiewal,nId,6532847](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polka-ciezko-ranna-w-bachmucie-lezalam-na-ziemi-obok-spiewal,nId,6532847)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 20:10:35+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-polka-ciezko-ranna-w-bachmucie-lezalam-na-ziemi-obok-spiewal,nId,6532847"><img align="left" alt="Polka ciężko ranna w Bachmucie: Leżałam na ziemi, obok śpiewała kobieta " src="https://i.iplsc.com/polka-ciezko-ranna-w-bachmucie-lezalam-na-ziemi-obok-spiewal/000GM92XEVBVJ0DV-C321.jpg" /></a>Grażyna straciła w Bachmucie nogę. Kiedy leżała na ziemi była pewna, że umiera. Ludzie wokół niej uciekali do schronów, a ona nie była w stanie się ruszyć. Myślała wtedy o bliskich, o zbliżającym się weselu siostry. W rozmowie z Interią wspomina też najmocniejszy obraz z Ukrainy, który zapisał się w jej pamięci. Czy pojechałaby tam drugi raz? - Do Ukrainy tak, ale czy do Bachumtu? Nie wiem, z tym pytaniem nie umiem się jeszcze zmierzyć - przyznaje.</p><br clear="all" />

## Silny wiatr na wybrzeżu. Może wyrywać drzewa i uszkadzać linie energetyczne
 - [https://wydarzenia.interia.pl/kraj/news-silny-wiatr-na-wybrzezu-moze-wyrywac-drzewa-i-uszkadzac-lini,nId,6532872](https://wydarzenia.interia.pl/kraj/news-silny-wiatr-na-wybrzezu-moze-wyrywac-drzewa-i-uszkadzac-lini,nId,6532872)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 19:59:21+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-silny-wiatr-na-wybrzezu-moze-wyrywac-drzewa-i-uszkadzac-lini,nId,6532872"><img align="left" alt="Silny wiatr na wybrzeżu. Może wyrywać drzewa i uszkadzać linie energetyczne" src="https://i.iplsc.com/silny-wiatr-na-wybrzezu-moze-wyrywac-drzewa-i-uszkadzac-lini/000GM8W3Q0RTV09D-C321.jpg" /></a>Na wybrzeżu silny wiatr może wywracać drzewa i spowodować uszkodzenia linii elektrycznych - ostrzegła synoptyk kraju IMGW Grażyna Dąbrowska. Wszystko to związane jest z głębokim niżem zalegającym nad Wyspami Brytyjskimi.</p><br clear="all" />

## Warszawa: Pijany funkcjonariusz SOP spowodował kolizję i zaczął uciekać
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-pijany-funkcjonariusz-sop-spowodowal-kolizje-i-zacz,nId,6532828](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-pijany-funkcjonariusz-sop-spowodowal-kolizje-i-zacz,nId,6532828)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 19:25:55+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-pijany-funkcjonariusz-sop-spowodowal-kolizje-i-zacz,nId,6532828"><img align="left" alt="Warszawa: Pijany funkcjonariusz SOP spowodował kolizję i zaczął uciekać" src="https://i.iplsc.com/warszawa-pijany-funkcjonariusz-sop-spowodowal-kolizje-i-zacz/000GM8QGVKAOKUK9-C321.jpg" /></a>Pijany kierowca doprowadził w Warszawie do kolizji i próbował uciec z miejsca zdarzenia. Poszkodowany ruszył za nim, powiadamiając o wszystkim policję. Sprawcą okazał się funkcjonariusz Służby Ochrony Państwa. W wydychanym powietrzu miał 2,5 promila alkoholu. Wobec mężczyzny wszczęto postępowanie dyscyplinarne. </p><br clear="all" />

## Greta Thunberg w Luetzerath: Przemoc policji jest oburzająca
 - [https://wydarzenia.interia.pl/zagranica/news-greta-thunberg-w-luetzerath-przemoc-policji-jest-oburzajaca,nId,6532859](https://wydarzenia.interia.pl/zagranica/news-greta-thunberg-w-luetzerath-przemoc-policji-jest-oburzajaca,nId,6532859)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 19:10:37+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-greta-thunberg-w-luetzerath-przemoc-policji-jest-oburzajaca,nId,6532859"><img align="left" alt="Greta Thunberg w Luetzerath: Przemoc policji jest oburzająca" src="https://i.iplsc.com/greta-thunberg-w-luetzerath-przemoc-policji-jest-oburzajaca/000GM8Q75GSNVFKK-C321.jpg" /></a>Greta Thunberg odwiedziła w piątek niemiecką wieś Luetzerath na zachodzie RFN zajmowaną przez aktywistów klimatycznych. Skrytykowała działania policji podczas eksmisji aktywistów z wioski, która ma być wyburzona, by ustąpić miejsca kopalni. Poinformowała także o swoich planach wzięcia w sobotę udziału w planowanej manifestacji na rzecz zachowania Luetzerath.</p><br clear="all" />

## Kreml wydał instrukcje. Uderza w Grupę Wagnera
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kreml-wydal-instrukcje-uderza-w-grupe-wagnera,nId,6532808](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kreml-wydal-instrukcje-uderza-w-grupe-wagnera,nId,6532808)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 19:02:53+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-kreml-wydal-instrukcje-uderza-w-grupe-wagnera,nId,6532808"><img align="left" alt="Kreml wydał instrukcje. Uderza w Grupę Wagnera " src="https://i.iplsc.com/kreml-wydal-instrukcje-uderza-w-grupe-wagnera/000FB0ZGL3MUFKMD-C321.jpg" /></a>Sztab rosyjskiej armii wydał 11 zaleceń dla reżimowych mediów w sprawie informowania o wojnie przeciwko Ukrainie - przekazał ukraiński wywiad wojskowy w piątek. Wśród najistotniejszych zaleceń jest nakaz mówienia o inwazji, jako o konflikcie Rosji z NATO oraz dyskredytowanie roli Grupy Wagnera. 
</p><br clear="all" />

## Tusk w Gdańsku: Przyrzekliśmy Pawłowi, że zrobimy wszystko, żeby nienawiść zniknęła
 - [https://wydarzenia.interia.pl/pomorskie/news-tusk-w-gdansku-przyrzeklismy-pawlowi-ze-zrobimy-wszystko-zeb,nId,6532589](https://wydarzenia.interia.pl/pomorskie/news-tusk-w-gdansku-przyrzeklismy-pawlowi-ze-zrobimy-wszystko-zeb,nId,6532589)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 18:39:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-tusk-w-gdansku-przyrzeklismy-pawlowi-ze-zrobimy-wszystko-zeb,nId,6532589"><img align="left" alt="Tusk w Gdańsku: Przyrzekliśmy Pawłowi, że zrobimy wszystko, żeby nienawiść zniknęła" src="https://i.iplsc.com/tusk-w-gdansku-przyrzeklismy-pawlowi-ze-zrobimy-wszystko-zeb/000GM8IQB5RERNXP-C321.jpg" /></a>- Mam dokładnie w pamięci te chwile cztery lata temu - mówił w Gdańsku Donald Tusk, wspominając moment, gdy przekazano informację o śmierci prezydenta Gdańska Pawła Adamowicza. - Wtedy trudno nam było nawet mówić, bo przełykaliśmy łzy, wszyscy byliśmy bardzo poruszeni - powiedział szef PO. Jak dodał: - Przyrzekliśmy Pawłowi, że zrobimy wszystko, co potrafimy, co w naszej mocy, żeby nienawiść i pogarda zniknęły z polskiego życia publicznego i żeby już nigdy zło nie zatriumfowało, szczególnie w tak brutalny sposób, jak tutaj w tym miejscu...</p><br clear="all" />

## Eksplozja gazociągu łączącego Litwę z Łotwą
 - [https://wydarzenia.interia.pl/zagranica/news-eksplozja-gazociagu-laczacego-litwe-z-lotwa,nId,6532830](https://wydarzenia.interia.pl/zagranica/news-eksplozja-gazociagu-laczacego-litwe-z-lotwa,nId,6532830)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 18:05:01+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-eksplozja-gazociagu-laczacego-litwe-z-lotwa,nId,6532830"><img align="left" alt="Eksplozja gazociągu łączącego Litwę z Łotwą" src="https://i.iplsc.com/eksplozja-gazociagu-laczacego-litwe-z-lotwa/000G87D762U532YS-C321.jpg" /></a>Litewski operator przesyłu gazu Amber Grid poinformował w piątek, że doszło do eksplozji gazociągu łączącego Litwę i Łotwę na odcinku w okolicach litewskiego miasta Paswol na północy kraju. Na filmach z miejsca zdarzenia widać kulę ognia unoszącą się nad okolicą. Według świadków płonie sięgają około 50 metrów, a od ognia temperatura w okolicy wzrosła do ponad 20 stopni Celsjusza.  </p><br clear="all" />

## Firma Donalda Trumpa ma zapłacić 1,6 mln dolarów. Chodzi o oszustwa podatkowe
 - [https://wydarzenia.interia.pl/zagranica/news-firma-donalda-trumpa-ma-zaplacic-1-6-mln-dolarow-chodzi-o-os,nId,6532790](https://wydarzenia.interia.pl/zagranica/news-firma-donalda-trumpa-ma-zaplacic-1-6-mln-dolarow-chodzi-o-os,nId,6532790)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 17:52:52+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-firma-donalda-trumpa-ma-zaplacic-1-6-mln-dolarow-chodzi-o-os,nId,6532790"><img align="left" alt="Firma Donalda Trumpa ma zapłacić 1,6 mln dolarów. Chodzi o oszustwa podatkowe" src="https://i.iplsc.com/firma-donalda-trumpa-ma-zaplacic-1-6-mln-dolarow-chodzi-o-os/0007TTT6MTA05P5K-C321.jpg" /></a>Trump Organization - grupa spółek Donalda Trumpa, byłego prezydenta USA - ma zapłacić 1,61 mln dolarów za oszustwa podatkowe. O maksymalnej karze zdecydował w piątek sąd najwyższy stanu Nowy Jork. Oszustwa miały trwać przez 15 lat. Wcześniej na pięć miesięcy więzienia skazany został dyrektor finansowy konglomeratu Allan Weisselberg.</p><br clear="all" />

## Aleksandr Łukaszenka pozbywa się rywala. Andrej Dzmitryjeu zatrzymany
 - [https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-pozbywa-sie-rywala-andrej-dzmitryjeu-za,nId,6532631](https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-pozbywa-sie-rywala-andrej-dzmitryjeu-za,nId,6532631)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 17:24:36+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-aleksandr-lukaszenka-pozbywa-sie-rywala-andrej-dzmitryjeu-za,nId,6532631"><img align="left" alt="Aleksandr Łukaszenka pozbywa się rywala. Andrej Dzmitryjeu zatrzymany" src="https://i.iplsc.com/aleksandr-lukaszenka-pozbywa-sie-rywala-andrej-dzmitryjeu-za/000GM7WSJUOXK2LS-C321.jpg" /></a>Były kandydat w wyborach prezydenckich na Białorusi w 2020 r., opozycyjny polityk Andrej Dzmitryjeu został zatrzymany z powodu &quot;działalności ekstremistycznej&quot;. Brał udział w protestach, często jeździł za granicę, miał zdjęcie z Hillary Clinton. W przeszłości Dzmitryjeu był liderem ruchu politycznego &quot;Mów prawdę&quot; - ten został zdelegalizowany w 2021 roku. </p><br clear="all" />

## Tusk tłumaczy się z głosowania ws. nowelizacji ustawy o SN
 - [https://wydarzenia.interia.pl/kraj/news-tusk-tlumaczy-sie-z-glosowania-ws-nowelizacji-ustawy-o-sn,nId,6532641](https://wydarzenia.interia.pl/kraj/news-tusk-tlumaczy-sie-z-glosowania-ws-nowelizacji-ustawy-o-sn,nId,6532641)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 16:55:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-tlumaczy-sie-z-glosowania-ws-nowelizacji-ustawy-o-sn,nId,6532641"><img align="left" alt="Tusk tłumaczy się z głosowania ws. nowelizacji ustawy o SN" src="https://i.iplsc.com/tusk-tlumaczy-sie-z-glosowania-ws-nowelizacji-ustawy-o-sn/000GM833R0QQIDCK-C321.jpg" /></a> Podjęliśmy decyzję, by zagłosować za pieniędzmi europejskimi, bo mieliśmy świadomość, że ta propozycja może odblokować środki europejskie. (…) Otrzymaliśmy dokument - delikatnie mówiąc - niedoskonały, ale wiedziałem, że realnie może odblokować te pieniądze. Nazywając rzecz po imieniu, my dzisiaj zdecydowaliśmy zagłosować za ustawą, która jest zła i być może niekonstytucyjna, ale obiektywnie lepsza niż status quo, ziobrowe status quo, pogwałcenie systemu sprawiedliwości w Polsce - powiedział Donald Tusk w Gdańsku, podczas spotkania z młodzieżą.</p><br clear="all" />

## Grecja: Ceny wakacji rosną nawet dwukrotnie
 - [https://wydarzenia.interia.pl/zagranica/news-grecja-ceny-wakacji-rosna-nawet-dwukrotnie,nId,6532580](https://wydarzenia.interia.pl/zagranica/news-grecja-ceny-wakacji-rosna-nawet-dwukrotnie,nId,6532580)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 15:51:39+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grecja-ceny-wakacji-rosna-nawet-dwukrotnie,nId,6532580"><img align="left" alt="Grecja: Ceny wakacji rosną nawet dwukrotnie" src="https://i.iplsc.com/grecja-ceny-wakacji-rosna-nawet-dwukrotnie/0003CZ7Z9ITNQPG3-C321.jpg" /></a>Ceny w umowach, które podpisują greccy hotelarze z głównymi europejskimi organizatorami wycieczek wzrosły średnio o 12 procent w sezonie turystycznym 2023 w stosunku do zeszłego roku. W przypadku prywatnych rezerwacji wzrost cen może przekroczyć nawet 100 procent - poinformował w piątek grecki portal Ekathimerini. Mimo podwyżek operatorzy szacują, że będą w stanie sprzedać więcej pakietów turystycznych. &quot;Chęć do podróżowania czasem wydaje się nawet większa niż w 2022 roku&quot; - podał portal.</p><br clear="all" />

## Lech Wałęsa po głosowaniu w sprawie SN: Wycofuję swoje sympatyzowanie z PO
 - [https://wydarzenia.interia.pl/kraj/news-lech-walesa-po-glosowaniu-w-sprawie-sn-wycofuje-swoje-sympat,nId,6532565](https://wydarzenia.interia.pl/kraj/news-lech-walesa-po-glosowaniu-w-sprawie-sn-wycofuje-swoje-sympat,nId,6532565)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 15:26:09+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-lech-walesa-po-glosowaniu-w-sprawie-sn-wycofuje-swoje-sympat,nId,6532565"><img align="left" alt="Lech Wałęsa po głosowaniu w sprawie SN: Wycofuję swoje sympatyzowanie z PO" src="https://i.iplsc.com/lech-walesa-po-glosowaniu-w-sprawie-sn-wycofuje-swoje-sympat/000AF9HRJHQA8BWO-C321.jpg" /></a>W związku z dzisiejszym głosowaniem posłów Platformy Obywatelskiej otwierającym drogę PiS-owi do środków unijnych postanowiłem wycofać swoje sympatyzowanie z PO - zadeklarował były prezydent Lech Wałęsa odnosząc się do przyjętej przez Sejm nowelizacji ustawy o Sądzie Najwyższym. Wcześniej zaapelował do posłów opozycji, by &quot;podjęli zdecydowane działania przeciwko tym, którzy łamali i wciąż łamią Konstytucję&quot;.</p><br clear="all" />

## Zderzenie samochodu osobowego ze śmieciarką. Nie żyją trzy osoby
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-zderzenie-samochodu-osobowego-ze-smieciarka-nie-zyja-trzy-os,nId,6532563](https://wydarzenia.interia.pl/dolnoslaskie/news-zderzenie-samochodu-osobowego-ze-smieciarka-nie-zyja-trzy-os,nId,6532563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 15:24:58+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-zderzenie-samochodu-osobowego-ze-smieciarka-nie-zyja-trzy-os,nId,6532563"><img align="left" alt="Zderzenie samochodu osobowego ze śmieciarką. Nie żyją trzy osoby" src="https://i.iplsc.com/zderzenie-samochodu-osobowego-ze-smieciarka-nie-zyja-trzy-os/000GM7SYQQJGO3ES-C321.jpg" /></a>W miejscowości Uciechów koło Dzierżoniowa na Dolnym Śląsku doszło do śmiertelnego wypadku. Jak podała Państwowa Straż Pożarna, z ciężarówką służącą do odbioru śmieci zderzyło się tam auto osobowe. Według wstępnych ustaleń, kierujący osobówką miał z nieustalonych przyczyn zjechać na przeciwległy pas. Zginęły trzy osoby, a dwie zostały ranne. </p><br clear="all" />

## Niemcy: Bezsensowna biurokracja w wojsku. Żołnierze wskazują absurdy
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-bezsensowna-biurokracja-w-wojsku-zolnierze-wskazuja-a,nId,6532537](https://wydarzenia.interia.pl/zagranica/news-niemcy-bezsensowna-biurokracja-w-wojsku-zolnierze-wskazuja-a,nId,6532537)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:54:59+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-bezsensowna-biurokracja-w-wojsku-zolnierze-wskazuja-a,nId,6532537"><img align="left" alt="Niemcy: Bezsensowna biurokracja w wojsku. Żołnierze wskazują absurdy" src="https://i.iplsc.com/niemcy-bezsensowna-biurokracja-w-wojsku-zolnierze-wskazuja-a/00075L0VN6UUQ38X-C321.jpg" /></a>W Bundeswehrze panuje &quot;potworna biurokracja&quot;. Liczne przepisy opóźniają istotne dla armii działania i kluczowe cele, takie jak poprawianie możliwości bojowych – opisuje w piątek portal dziennika &quot;Bild&quot;. Marcel Bohnert, wiceprzewodniczący związku Bundeswehry tłumaczył, że &quot;wojskowi i siły zbrojnie nie mogą sobie pozwolić na takie przeszkody&quot;.  - Liczne regulacje cywilne przynoszą, zamiast naprawdę odstraszającego efektu, cel wprost przeciwny - zwrócił uwagę były komisarz wojskowy Hans-Peter Bartels.</p><br clear="all" />

## Świętokrzyskie: 19-latek wjechał w dom. Miał prawie dwa promile
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-swietokrzyskie-19-latek-wjechal-w-dom-mial-prawie-dwa-promil,nId,6532526](https://wydarzenia.interia.pl/swietokrzyskie/news-swietokrzyskie-19-latek-wjechal-w-dom-mial-prawie-dwa-promil,nId,6532526)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:49:26+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-swietokrzyskie-19-latek-wjechal-w-dom-mial-prawie-dwa-promil,nId,6532526"><img align="left" alt="Świętokrzyskie: 19-latek wjechał w dom. Miał prawie dwa promile" src="https://i.iplsc.com/swietokrzyskie-19-latek-wjechal-w-dom-mial-prawie-dwa-promil/000GM7I4SI7GP94S-C321.jpg" /></a>W Koperni w województwie świętokrzyskim nastolatek wjechał samochodem w dom. 19-letni kierowca audi miał prawie dwa promile alkoholu w organizmie. Jak przekazał rzecznik pińczowskiej policji, asp. szt. Damian Stefaniec, nastolatkowi grozi do trzech lat pozbawienia wolności.</p><br clear="all" />

## Niebywały pech do broni palnej. Najpierw ojciec, teraz córka
 - [https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-ojciec-teraz-corka,nId,6532525](https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-ojciec-teraz-corka,nId,6532525)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:49:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-ojciec-teraz-corka,nId,6532525"><img align="left" alt="Niebywały pech do broni palnej. Najpierw ojciec, teraz córka" src="https://i.iplsc.com/niebywaly-pech-do-broni-palnej-najpierw-ojciec-teraz-corka/000GM74CQ35JBXR0-C321.jpg" /></a>Córka radnego 18-tego okręgu Chicago Derricka Curtisa została przypadkowo postrzelona w nogę podczas zajęć z bronią, które Curtis prowadził w kościele w Ashburn. Sam radny kilka miesięcy temu sam się postrzelił - donosi ABC.</p><br clear="all" />

## Niebywały pech do broni palnej. Najpierw radny, teraz jego córka
 - [https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-radny-teraz-jego-cor,nId,6532525](https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-radny-teraz-jego-cor,nId,6532525)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:49:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niebywaly-pech-do-broni-palnej-najpierw-radny-teraz-jego-cor,nId,6532525"><img align="left" alt="Niebywały pech do broni palnej. Najpierw radny, teraz jego córka" src="https://i.iplsc.com/niebywaly-pech-do-broni-palnej-najpierw-radny-teraz-jego-cor/000GM7V94SO3BDXK-C321.jpg" /></a>Córka radnego 18-tego okręgu Chicago Derricka Curtisa została przypadkowo postrzelona w nogę podczas zajęć z bronią, które Curtis prowadził w kościele w Ashburn. Sam radny kilka miesięcy temu sam się postrzelił - donosi ABC.</p><br clear="all" />

## Nieoficjalnie: Andrzej Duda zawetował lex Czarnek po interwencji Amerykanów
 - [https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-andrzej-duda-zawetowal-lex-czarnek-po-interwen,nId,6532491](https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-andrzej-duda-zawetowal-lex-czarnek-po-interwen,nId,6532491)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:46:59+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nieoficjalnie-andrzej-duda-zawetowal-lex-czarnek-po-interwen,nId,6532491"><img align="left" alt="Nieoficjalnie: Andrzej Duda zawetował lex Czarnek po interwencji Amerykanów" src="https://i.iplsc.com/nieoficjalnie-andrzej-duda-zawetowal-lex-czarnek-po-interwen/000GM6YZ5UTLITKC-C321.jpg" /></a>Prezydent Andrzej Duda zawetował &quot;lex Czarnek 2.0&quot; po interwencji amerykańskiego sekretarza stanu - podaje w swoim najnowszym felietonie na łamach Interii Piotr Zaremba. - Nic nie wiem o takim fakcie - mówi naszemu portalowi szef gabinetu prezydenta Paweł Szrot.</p><br clear="all" />

## Ojciec chłopca zginął w Donbasie. Prezent od władz: Tani smartwatch
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ojciec-chlopca-zginal-w-donbasie-prezent-od-wladz-tani-smart,nId,6532499](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ojciec-chlopca-zginal-w-donbasie-prezent-od-wladz-tani-smart,nId,6532499)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:23:03+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ojciec-chlopca-zginal-w-donbasie-prezent-od-wladz-tani-smart,nId,6532499"><img align="left" alt="Ojciec chłopca zginął w Donbasie. Prezent od władz: Tani smartwatch" src="https://i.iplsc.com/ojciec-chlopca-zginal-w-donbasie-prezent-od-wladz-tani-smart/000GM6R5TRFRNXQV-C321.jpg" /></a>Kostromska policja spełniła noworoczne życzenie syna żołnierza, który zginął w Donbasie - brzmi zapowiedź propagandowego materiału w prokremlowskiej telewizji Rossija-1. Przedstawiciele MSW Rosji wręczyli chłopcu taniego smartwatcha i model samochodu z Komitetu Śledczego. - Marzenia zawsze się spełniają - powiedział mu minister spraw wewnętrznych obwodu kostromskiego Aleksander Arapow.</p><br clear="all" />

## Morawiecki dziękuje Solidarnej Polsce. "Osiągnęliśmy niełatwy kompromis"
 - [https://wydarzenia.interia.pl/kraj/news-morawiecki-dziekuje-solidarnej-polsce-osiagnelismy-nielatwy-,nId,6532496](https://wydarzenia.interia.pl/kraj/news-morawiecki-dziekuje-solidarnej-polsce-osiagnelismy-nielatwy-,nId,6532496)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 14:21:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-morawiecki-dziekuje-solidarnej-polsce-osiagnelismy-nielatwy-,nId,6532496"><img align="left" alt="Morawiecki dziękuje Solidarnej Polsce. &quot;Osiągnęliśmy niełatwy kompromis&quot;" src="https://i.iplsc.com/morawiecki-dziekuje-solidarnej-polsce-osiagnelismy-nielatwy/000GM6TDPA9GI8NL-C321.jpg" /></a>- Polityka to jest sztuka kompromisu i my ten kompromis, niełatwy kompromis osiągnęliśmy - mówił dziennikarzom w piątek Mateusz Morawiecki, po uchwaleniu nowelizacji ustawy o Sądzie Najwyższym, która według autorów ma wypełnić kluczowy &quot;kamień milowy&quot;. Podziękował też koalicjantom z Solidarnej Polski - którzy zagłosowali przeciw noweli - za &quot;dyskusje z ostatnich trzech tygodni&quot; oraz &quot;słuszne uwagi.&quot; </p><br clear="all" />

## Kryzys zaufania na opozycji po głosowaniu Polski 2050 Szymona Hołowni
 - [https://wydarzenia.interia.pl/kraj/news-kryzys-zaufania-na-opozycji-po-glosowaniu-polski-2050-szymon,nId,6532323](https://wydarzenia.interia.pl/kraj/news-kryzys-zaufania-na-opozycji-po-glosowaniu-polski-2050-szymon,nId,6532323)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 13:55:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-kryzys-zaufania-na-opozycji-po-glosowaniu-polski-2050-szymon,nId,6532323"><img align="left" alt="Kryzys zaufania na opozycji po głosowaniu Polski 2050 Szymona Hołowni" src="https://i.iplsc.com/kryzys-zaufania-na-opozycji-po-glosowaniu-polski-2050-szymon/000GM6789656I0HE-C321.jpg" /></a>W głosowaniu nad ustawą o Sądzie Najwyższym niemal cała opozycja wstrzymała się od głosu, dzięki czemu projekt posłów PiS trafi do Senatu. Przeciw było całe ugrupowanie Szymona Hołowni, przez co na opozycji powstał zgrzyt. - Władysław Kosiniak-Kamysz, Donald Tusk i ja jesteśmy za jednością opozycji. Szymon Hołownia też, ale chyba jednak nie za wszelką cenę - mówi Interii Włodzimierz Czarzasty. O braku zaufania do Hołowni mówił z kolei Borys Budka, a ten w odpowiedzi zarzucił mu kłamstwo.</p><br clear="all" />

## Nowelizacja ustawy o komisji ds. pedofilii.  Sejm odrzucił większość poprawek Senatu
 - [https://wydarzenia.interia.pl/kraj/news-nowelizacja-ustawy-o-komisji-ds-pedofilii-sejm-odrzucil-wiek,nId,6532312](https://wydarzenia.interia.pl/kraj/news-nowelizacja-ustawy-o-komisji-ds-pedofilii-sejm-odrzucil-wiek,nId,6532312)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 13:10:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowelizacja-ustawy-o-komisji-ds-pedofilii-sejm-odrzucil-wiek,nId,6532312"><img align="left" alt="Nowelizacja ustawy o komisji ds. pedofilii.  Sejm odrzucił większość poprawek Senatu" src="https://i.iplsc.com/nowelizacja-ustawy-o-komisji-ds-pedofilii-sejm-odrzucil-wiek/000FUXT2A1850M6X-C321.jpg" /></a>Sejm odrzucił w piątek większość poprawek senackich do nowelizacji ustawy o Państwowej Komisji ds. Pedofilii. Z tekstu noweli usunięto m.in. rozwiązania przewidujące możliwość kar za nieuzasadnione nieprzekazanie dokumentów, o które wnioskuje Komisja. Przepisy trafią teraz na biurko prezydenta.</p><br clear="all" />

## Kielce: 41-latka zmarła po cesarskim cięciu. Osierociła troje dzieci
 - [https://wydarzenia.interia.pl/swietokrzyskie/news-kielce-41-latka-zmarla-po-cesarskim-cieciu-osierocila-troje-,nId,6532309](https://wydarzenia.interia.pl/swietokrzyskie/news-kielce-41-latka-zmarla-po-cesarskim-cieciu-osierocila-troje-,nId,6532309)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 13:09:29+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/swietokrzyskie/news-kielce-41-latka-zmarla-po-cesarskim-cieciu-osierocila-troje-,nId,6532309"><img align="left" alt="Kielce: 41-latka zmarła po cesarskim cięciu. Osierociła troje dzieci" src="https://i.iplsc.com/kielce-41-latka-zmarla-po-cesarskim-cieciu-osierocila-troje/0007XPSV71JNQPBE-C321.jpg" /></a>Prokuratura wyjaśnia okoliczności śmierci 41-letniej kobiety, która zmarła w szpitalu w Kielcach po przeprowadzonym cesarskim cięciu. Dziecko kobiety przeżyło.</p><br clear="all" />

## Ciało mężczyzny znalezione przy granicy z Białorusią
 - [https://wydarzenia.interia.pl/kraj/news-cialo-mezczyzny-znalezione-przy-granicy-z-bialorusia,nId,6532279](https://wydarzenia.interia.pl/kraj/news-cialo-mezczyzny-znalezione-przy-granicy-z-bialorusia,nId,6532279)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 12:48:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-cialo-mezczyzny-znalezione-przy-granicy-z-bialorusia,nId,6532279"><img align="left" alt="Ciało mężczyzny znalezione przy granicy z Białorusią" src="https://i.iplsc.com/cialo-mezczyzny-znalezione-przy-granicy-z-bialorusia/000FKKQSW1DSV1IG-C321.jpg" /></a>Ciało mężczyzny znaleźli polscy pogranicznicy w pobliżu granicy z Białorusią - przekazała rzeczniczka Podlaskiego Oddziału Straży Granicznej Katarzyna Zdanowicz. Jak dodała, w tych samych okolicach odkryto w czwartek szczątki innej osoby.</p><br clear="all" />

## Antyrekordy rosyjskiej gospodarki. Tak upada kolos
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-antyrekordy-rosyjskiej-gospodarki-tak-upada-kolos,nId,6532248](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-antyrekordy-rosyjskiej-gospodarki-tak-upada-kolos,nId,6532248)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 12:47:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-antyrekordy-rosyjskiej-gospodarki-tak-upada-kolos,nId,6532248"><img align="left" alt="Antyrekordy rosyjskiej gospodarki. Tak upada kolos" src="https://i.iplsc.com/antyrekordy-rosyjskiej-gospodarki-tak-upada-kolos/000GM5RFSFSQ94TR-C321.jpg" /></a>W styczniu wielkość utraconych wpływów do budżetu federalnego z ropy i gazu wyniesie 54,5 mld rubli - prognozuje rosyjskie Ministerstwo Finansów. Bloomberg wyliczył, że pułap cen rosyjskiej ropy, wprowadzony na krótko przed końcem 2022 rokiem, kosztuje Rosję 160-172 mln dolarów utraconych dochodów dziennie. - To, co wydarzyło się w 2022 roku, jest kresem jakiegokolwiek rozwoju naszej gospodarki. Wpadliśmy w bagno - twierdzi doktor nauk ekonomicznych Władysław Inoziemcew. O tym, czego jeszcze można się spodziewać po rosyjskiej gospodarce i...</p><br clear="all" />

## Nowe przepisy o pracy zdalnej. Jest też zapis o kontroli trzeźwości pracownika
 - [https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-o-pracy-zdalnej-jest-tez-zapis-o-kontroli-trze,nId,6532271](https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-o-pracy-zdalnej-jest-tez-zapis-o-kontroli-trze,nId,6532271)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 12:41:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowe-przepisy-o-pracy-zdalnej-jest-tez-zapis-o-kontroli-trze,nId,6532271"><img align="left" alt="Nowe przepisy o pracy zdalnej. Jest też zapis o kontroli trzeźwości pracownika" src="https://i.iplsc.com/nowe-przepisy-o-pracy-zdalnej-jest-tez-zapis-o-kontroli-trze/0006IXQIXNHFQDPG-C321.jpg" /></a>Sejm przegłosował nowelizację kodeksu pracy oraz ustawę o przeciwdziałaniu przemocy w rodzinie. W związku ze zmianami w prawie unormowana została formuła pracy zdalnej i hybrydowej, a także przyjęto rozwiązania, mające za zadanie wzmocnienie walki z cyberprzemocą.</p><br clear="all" />

## Gest Ukraińców dla Andrzeja Dudy. Usunęli flagi Bandery
 - [https://wydarzenia.interia.pl/kraj/news-gest-ukraincow-dla-andrzeja-dudy-usuneli-flagi-bandery,nId,6532250](https://wydarzenia.interia.pl/kraj/news-gest-ukraincow-dla-andrzeja-dudy-usuneli-flagi-bandery,nId,6532250)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 12:31:38+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-gest-ukraincow-dla-andrzeja-dudy-usuneli-flagi-bandery,nId,6532250"><img align="left" alt="Gest Ukraińców dla Andrzeja Dudy. Usunęli flagi Bandery" src="https://i.iplsc.com/gest-ukraincow-dla-andrzeja-dudy-usuneli-flagi-bandery/000GM5NN80AIOUAW-C321.jpg" /></a>Kiedy Andrzej Duda odwiedzał Lwów w ramach spotkania Trójkąta Lubelskiego, mieszkańcy witali go na ulicach niczym gwiazdę. Jak ustaliła Interia, na istotny gest zdobyły się również ukraińskie władze. Podczas wizyty naszego prezydenta z Cmentarza Orląt Lwowskich zniknęły czerwono-czarne flagi UPA. - To duży, bardzo istotny krok, za którym powinny iść następne - usłyszeliśmy od Pawła Szrota, szefa gabinetu politycznego głowy państwa. Z kolei ks. Tadeusz Isakowicz-Zaleski podkreśla, że w relacjach polsko-ukraińskich na tle historycznym...</p><br clear="all" />

## Nieletni ministrant wjechał w dom. Auto należało do księdza
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-nieletni-ministrant-wjechal-w-dom-auto-nalezalo-do-ksiedza,nId,6532263](https://wydarzenia.interia.pl/dolnoslaskie/news-nieletni-ministrant-wjechal-w-dom-auto-nalezalo-do-ksiedza,nId,6532263)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 12:24:38+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-nieletni-ministrant-wjechal-w-dom-auto-nalezalo-do-ksiedza,nId,6532263"><img align="left" alt="Nieletni ministrant wjechał w dom. Auto należało do księdza" src="https://i.iplsc.com/nieletni-ministrant-wjechal-w-dom-auto-nalezalo-do-ksiedza/000GM5RD6FO6SH30-C321.jpg" /></a>Szesnastolatek wjechał samochodem w dom w gminie Wąsosz na Dolnym Śląsku. Chłopak jest ministrantem i jechał autem należącym do księdza. Został ranny. Sprawa trafi do sądu rodzinnego. </p><br clear="all" />

## Wagnerowcy szukają chętnych do wywozu ciał zabitych. "Opłata tylko gotówką"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wagnerowcy-szukaja-chetnych-do-wywozu-cial-zabitych-oplata-t,nId,6532191](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wagnerowcy-szukaja-chetnych-do-wywozu-cial-zabitych-oplata-t,nId,6532191)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:59:22+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wagnerowcy-szukaja-chetnych-do-wywozu-cial-zabitych-oplata-t,nId,6532191"><img align="left" alt="Wagnerowcy szukają chętnych do wywozu ciał zabitych. &quot;Opłata tylko gotówką&quot;" src="https://i.iplsc.com/wagnerowcy-szukaja-chetnych-do-wywozu-cial-zabitych-oplata-t/000GM5FW9XWQ0U7H-C321.jpg" /></a>Do transportu ciał zabitych rosyjskich żołnierzy przedstawiciele Grupy Wagnera używają zwykłych ciężarówek rosyjskich firm transportowych - donosi niezależny portal Ostrorożno Novosti. Opłata za taki transport z Rostowa nad Donem na południu Rosji do podmoskiewskiej Bałaszychy ma wynosić zwykle około 60 tys. rubli (niecałe cztery tysiące złotych) płatnych gotówką.</p><br clear="all" />

## Nowy dowódca Sił Powietrznych Rosji. Poprzedniego zdymisjonowano
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-dowodca-sil-powietrznych-rosji-poprzedniego-zdymisjonow,nId,6532175](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-dowodca-sil-powietrznych-rosji-poprzedniego-zdymisjonow,nId,6532175)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:53:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-dowodca-sil-powietrznych-rosji-poprzedniego-zdymisjonow,nId,6532175"><img align="left" alt="Nowy dowódca Sił Powietrznych Rosji. Poprzedniego zdymisjonowano" src="https://i.iplsc.com/nowy-dowodca-sil-powietrznych-rosji-poprzedniego-zdymisjonow/000GM5FG6JBVJ1HF-C321.jpg" /></a>Generał broni Oleg Makarewicz został mianowany nowym dowódcą Sił Powietrznych Rosji. Dotychczasowego dowódcę generała Michaiła Teplińskiego zdymisjonowano. To kolejna zmiana w rosyjskim dowództwie wojskowym w ostatnich dniach po objęciu przez Generała Wasilija Gierasimowa dowódcą frontu ukraińskiego. </p><br clear="all" />

## Nie tylko Polska. Kolejny kraj gotowy wysłać Ukrainie Leopardy
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-tylko-polska-kolejny-kraj-gotowy-wyslac-ukrainie-leopard,nId,6532214](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-tylko-polska-kolejny-kraj-gotowy-wyslac-ukrainie-leopard,nId,6532214)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:50:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nie-tylko-polska-kolejny-kraj-gotowy-wyslac-ukrainie-leopard,nId,6532214"><img align="left" alt="Nie tylko Polska. Kolejny kraj gotowy wysłać Ukrainie Leopardy" src="https://i.iplsc.com/nie-tylko-polska-kolejny-kraj-gotowy-wyslac-ukrainie-leopard/000GM5ESI8K8HP4E-C321.jpg" /></a>- Finlandia mogłaby zwiększyć swoją pomoc wojskową dla Ukrainy, wysyłając czołgi Leopard 2 - powiedział prezydent tego państwa Sauli Niinistö cytowany przez agencję informacyjną STT. Zaznaczył jednak, że ich liczba byłaby ograniczona. Dostawy miałyby być częścią międzynarodowej koalicji, w której przekazanie Leopardów jako pierwsza zadeklarowała Polska. Duże znaczenie w tej sprawie może mieć też stanowisko Berlina, bo zgodnie z tzw. klauzulą końcowego przeznaczenia Niemcy muszą dać pozwolenie na taki transfer. </p><br clear="all" />

## Zbigniew Ziobro: Zrobimy wszystko, by nowelizacja nie weszła w życie
 - [https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-zrobimy-wszystko-by-nowelizacja-nie-weszla-w,nId,6532216](https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-zrobimy-wszystko-by-nowelizacja-nie-weszla-w,nId,6532216)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:32:36+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zbigniew-ziobro-zrobimy-wszystko-by-nowelizacja-nie-weszla-w,nId,6532216"><img align="left" alt="Zbigniew Ziobro: Zrobimy wszystko, by nowelizacja nie weszła w życie" src="https://i.iplsc.com/zbigniew-ziobro-zrobimy-wszystko-by-nowelizacja-nie-weszla-w/000GM5H8XWONBJSD-C321.jpg" /></a>- Zawsze realizujemy program najlepszy dla Polski, dlatego nie zamierzamy oddawać władzy Donaldowi Tuskowi i tej zgrai kolaborantów niemieckich, którzy chcieliby wprowadzać tu porządek ustalony w Brukseli, a właściwie w Berlinie - powiedział minister sprawiedliwości Zbigniew Ziobro po przyjęciu przez Sejm nowelizacji ustawy o Sądzie Najwyższym. Zdaniem szefa Solidarnej Polski za KPO &quot;przyjdzie nam zapłacić od 300 do 500 mld złotych&quot;.</p><br clear="all" />

## Sejm przyjął ustawę o Sądzie Najwyższym. Jest reakcja Komisji Europejskiej
 - [https://wydarzenia.interia.pl/zagranica/news-sejm-przyjal-ustawe-o-sadzie-najwyzszym-jest-reakcja-komisji,nId,6532215](https://wydarzenia.interia.pl/zagranica/news-sejm-przyjal-ustawe-o-sadzie-najwyzszym-jest-reakcja-komisji,nId,6532215)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:30:26+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-sejm-przyjal-ustawe-o-sadzie-najwyzszym-jest-reakcja-komisji,nId,6532215"><img align="left" alt="Sejm przyjął ustawę o Sądzie Najwyższym. Jest reakcja Komisji Europejskiej" src="https://i.iplsc.com/sejm-przyjal-ustawe-o-sadzie-najwyzszym-jest-reakcja-komisji/0007KE6J2WFEN70G-C321.jpg" /></a>- Nowy projekt ustawy o sądownictwie złożony przez polski rząd w grudniu 2022 r., obecnie przyjęty przez Sejm, jest ważnym krokiem w kierunku wypełnienia zobowiązań wynikających z polskiego Krajowego Planu Odbudowy - przekazał Polskiej Agencji Prasowej rzecznik Komisji Europejskiej Christian Wigand.</p><br clear="all" />

## Niemiecki rząd: Nie wpłynął do nas żaden wniosek Polski w sprawie Leopardów
 - [https://wydarzenia.interia.pl/zagranica/news-niemiecki-rzad-nie-wplynal-do-nas-zaden-wniosek-polski-w-spr,nId,6532068](https://wydarzenia.interia.pl/zagranica/news-niemiecki-rzad-nie-wplynal-do-nas-zaden-wniosek-polski-w-spr,nId,6532068)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:29:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiecki-rzad-nie-wplynal-do-nas-zaden-wniosek-polski-w-spr,nId,6532068"><img align="left" alt="Niemiecki rząd: Nie wpłynął do nas żaden wniosek Polski w sprawie Leopardów" src="https://i.iplsc.com/niemiecki-rzad-nie-wplynal-do-nas-zaden-wniosek-polski-w-spr/000GM4TM03CIHYF9-C321.jpg" /></a>- Nie mówimy &quot;nie&quot; w sprawie przekazania Leopardów Ukrainie, bo nie wpłynęła do nas jeszcze oficjalna prośba w tej sprawie - powiedziała rzeczniczka niemieckiego rządu w odpowiedzi na pytanie korespondenta Polsat News i Interii Tomasza Lejmana.</p><br clear="all" />

## Wojna w Ukrainie. Rosja twierdzi, że zdobyła Sołedar
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar,nId,6532198](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar,nId,6532198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:18:59+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar,nId,6532198"><img align="left" alt="Wojna w Ukrainie. Rosja twierdzi, że zdobyła Sołedar" src="https://i.iplsc.com/wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar/000GM5EWK4V3RKK4-C321.jpg" /></a>Ministerstwo Obrony Rosji poinformowało o wyzwoleniu Sołedaru przez wojska rosyjskie w czwartek wieczorem. Strona ukraińska w piątkowy poranek nie potwierdzała tych informacji. - Noc w Sołedarze była gorąca, walki trwały - przekazała wiceminister obrony Hanna Malar.</p><br clear="all" />

## Wojna w Ukrainie. Rosja twierdzi, że zdobyła Sołedar. Ukraina zaprzecza
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar-ukraina-z,nId,6532198](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar-ukraina-z,nId,6532198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 11:18:59+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar-ukraina-z,nId,6532198"><img align="left" alt="Wojna w Ukrainie. Rosja twierdzi, że zdobyła Sołedar. Ukraina zaprzecza" src="https://i.iplsc.com/wojna-w-ukrainie-rosja-twierdzi-ze-zdobyla-soledar-ukraina-z/000GM5EWK4V3RKK4-C321.jpg" /></a>Ministerstwo Obrony Rosji poinformowało o wyzwoleniu Sołedaru przez wojska rosyjskie w czwartek wieczorem. Strona ukraińska w piątek zaprzeczyła tym informacjom. - To nieprawda. W mieście toczą się walki - powiedział rzecznik Wschodniego Zgrupowania Sił Zbrojnych Ukrainy Serhij Czerewaty.</p><br clear="all" />

## Rodzice walczą o życie swoich dzieci. W Sejmie powstał specjalny zespół
 - [https://wydarzenia.interia.pl/kraj/news-rodzice-walcza-o-zycie-swoich-dzieci-w-sejmie-powstal-specja,nId,6532119](https://wydarzenia.interia.pl/kraj/news-rodzice-walcza-o-zycie-swoich-dzieci-w-sejmie-powstal-specja,nId,6532119)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:46:37+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-rodzice-walcza-o-zycie-swoich-dzieci-w-sejmie-powstal-specja,nId,6532119"><img align="left" alt="Rodzice walczą o życie swoich dzieci. W Sejmie powstał specjalny zespół" src="https://i.iplsc.com/rodzice-walcza-o-zycie-swoich-dzieci-w-sejmie-powstal-specja/000GM5ANO9AL79NK-C321.jpg" /></a>Powstał parlamentarny zespół ds. SMA, którego celem jest zrefundowanie terapii genowej dla 17 dzieci chorych na rdzeniowy zanik mięśni. Dzieciom tym nie należy się refundacja najdroższym lekiem świata, co zmusza ich rodziców do zbiórek pieniędzy. &quot;Zwracamy się, by te pieniądze były zabudżetowane i będziemy działać na rzecz tego, by te pieniądze były zabudżetowane&quot; - powiedziała Monika Falej z Lewicy.</p><br clear="all" />

## Sejm przyjął ustawę o inwestycjach w zakresie budowy elektrowni jądrowej
 - [https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-ustawe-o-inwestycjach-w-zakresie-budowy-elektro,nId,6532168](https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-ustawe-o-inwestycjach-w-zakresie-budowy-elektro,nId,6532168)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:40:04+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-ustawe-o-inwestycjach-w-zakresie-budowy-elektro,nId,6532168"><img align="left" alt="Sejm przyjął ustawę o inwestycjach w zakresie budowy elektrowni jądrowej" src="https://i.iplsc.com/sejm-przyjal-ustawe-o-inwestycjach-w-zakresie-budowy-elektro/000F23TS4B753YPK-C321.jpg" /></a>Sejm przyjął ustawę o inwestycjach w zakresie obiektów energetyki jądrowej w Polsce z pięcioma poprawkami. Dzięki nowym regulacjom możliwe będzie przyspieszenie realizacji projektów związanych z budową elektrowni jądrowej w Polsce. Zmniejszeniu ulegnie także potencjalne ryzyko po stronie inwestorów, którzy zdecydują się na podjęcie takiej budowy na terenie naszego kraju.</p><br clear="all" />

## Groźny narkotyk dotarł do Polski. Niewielka ilość może doprowadzić do zgonu
 - [https://wydarzenia.interia.pl/slaskie/news-grozny-narkotyk-dotarl-do-polski-niewielka-ilosc-moze-doprow,nId,6532166](https://wydarzenia.interia.pl/slaskie/news-grozny-narkotyk-dotarl-do-polski-niewielka-ilosc-moze-doprow,nId,6532166)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:39:04+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/slaskie/news-grozny-narkotyk-dotarl-do-polski-niewielka-ilosc-moze-doprow,nId,6532166"><img align="left" alt="Groźny narkotyk dotarł do Polski. Niewielka ilość może doprowadzić do zgonu" src="https://i.iplsc.com/grozny-narkotyk-dotarl-do-polski-niewielka-ilosc-moze-doprow/000GM5ARX8AUEG2V-C321.jpg" /></a>A-pirolidynoizoheksanofenon zwany &quot;funky&quot; to niebezpieczna substancja psychotropowa, która pojawiła się na polskim rynku. Kilkadziesiąt gram tej niezwykle niebezpiecznej substancji znaleziono u jednego z mieszkańców Raciborza. 48-latek został zatrzymany przez policję i grozi mu do trzech lat pobytu w więzieniu.</p><br clear="all" />

## Staruszek pracował na kasie. Użytkownik TikToka zebrał dla niego 100 tys. dolarów
 - [https://wydarzenia.interia.pl/zagranica/news-staruszek-pracowal-na-kasie-uzytkownik-tiktoka-zebral-dla-ni,nId,6532040](https://wydarzenia.interia.pl/zagranica/news-staruszek-pracowal-na-kasie-uzytkownik-tiktoka-zebral-dla-ni,nId,6532040)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:34:37+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-staruszek-pracowal-na-kasie-uzytkownik-tiktoka-zebral-dla-ni,nId,6532040"><img align="left" alt="Staruszek pracował na kasie. Użytkownik TikToka zebrał dla niego 100 tys. dolarów" src="https://i.iplsc.com/staruszek-pracowal-na-kasie-uzytkownik-tiktoka-zebral-dla-ni/000GM4LS7SGUVX1B-C321.jpg" /></a>Ponad 100 tys. dolarów trafiło do Warrena &quot;Butcha&quot; Mariona, 82-etniego weterana amerykańskiej marynarki wojennej za sprawą zbiórki zorganizowanej przez influencera z TikToka Rory'a McCarty'ego. Mimo że Marion ma emeryturę, do tej pory musiał pracować w sklepie na kasie, żeby związać koniec z końcem. McCarty poznał jego historię podczas zakupów w supermarkecie sieci Walmart. To spotkanie odmieniło los staruszka. </p><br clear="all" />

## Szef rosyjskiej Dumy: Konfiskata majątków "łajdaków", którzy wyjechali
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-rosyjskiej-dumy-konfiskata-majatkow-lajdakow-ktorzy-wyj,nId,6532080](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-rosyjskiej-dumy-konfiskata-majatkow-lajdakow-ktorzy-wyj,nId,6532080)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:20:57+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-szef-rosyjskiej-dumy-konfiskata-majatkow-lajdakow-ktorzy-wyj,nId,6532080"><img align="left" alt="Szef rosyjskiej Dumy: Konfiskata majątków &quot;łajdaków&quot;, którzy wyjechali" src="https://i.iplsc.com/szef-rosyjskiej-dumy-konfiskata-majatkow-lajdakow-ktorzy-wyj/000GM52JC181JJ4X-C321.jpg" /></a>Rosjanom, którzy opuścili kraj i krytykują wojnę oraz rosyjskie władze, należy skonfiskować majątek - napisał na swoim kanale w Telegramie przewodniczący Dumy Państwowej Wiaczesław Wołodin. Nazywa tych ludzi &quot;łajdakami&quot; i domaga się zmian zapisów w kodeksie karnym. </p><br clear="all" />

## Sejm przyjął nowelizację ustawy o przeciwdziałaniu przemocy w rodzinie
 - [https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-przeciwdzialaniu-przemocy-,nId,6532151](https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-przeciwdzialaniu-przemocy-,nId,6532151)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 10:16:58+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-przeciwdzialaniu-przemocy-,nId,6532151"><img align="left" alt="Sejm przyjął nowelizację ustawy o przeciwdziałaniu przemocy w rodzinie " src="https://i.iplsc.com/sejm-przyjal-nowelizacje-ustawy-o-przeciwdzialaniu-przemocy/000GM59IF7P25KEA-C321.jpg" /></a>Sejm uchwalił w piątek nowelizację ustawy o przeciwdziałaniu przemocy w rodzinie. Nowe przepisy uwzględniają przemoc ekonomiczną i cyberprzemoc, rozszerzają krąg osób objętych ochroną na byłych partnerów oraz dzieci będące świadkami przemocy domowej. Zmiany dotyczą też niebieskiej karty i przepisów w zakresie kwalifikacji osób kierujących specjalistycznymi ośrodkami wsparcia.</p><br clear="all" />

## Fatalny błąd lekarza. 2 tys. osób będzie musiało powtórzyć kolonoskopię
 - [https://wydarzenia.interia.pl/zagranica/news-fatalny-blad-lekarza-2-tys-osob-bedzie-musialo-powtorzyc-kol,nId,6532129](https://wydarzenia.interia.pl/zagranica/news-fatalny-blad-lekarza-2-tys-osob-bedzie-musialo-powtorzyc-kol,nId,6532129)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:57:57+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-fatalny-blad-lekarza-2-tys-osob-bedzie-musialo-powtorzyc-kol,nId,6532129"><img align="left" alt="Fatalny błąd lekarza. 2 tys. osób będzie musiało powtórzyć kolonoskopię" src="https://i.iplsc.com/fatalny-blad-lekarza-2-tys-osob-bedzie-musialo-powtorzyc-kol/000GM55EXFDJMHNQ-C321.jpg" /></a>Chirurg odpowiedzialna za wykonanie około 2 tys. &quot;niekompletnych&quot; kolonoskopii w Australii otrzymała zakaz wykonywania zawodu lekarza. Pacjenci mieli bowiem otrzymać niedokładne diagnozy, w związku z czym zaleca się, aby powtórzyli badanie.</p><br clear="all" />

## Sejm przyjął uchwałę ws. stanu zdrowia byłego prezydenta Gruzji
 - [https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-uchwale-ws-stanu-zdrowia-bylego-prezydenta-gruz,nId,6532078](https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-uchwale-ws-stanu-zdrowia-bylego-prezydenta-gruz,nId,6532078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:40:03+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-uchwale-ws-stanu-zdrowia-bylego-prezydenta-gruz,nId,6532078"><img align="left" alt="Sejm przyjął uchwałę ws. stanu zdrowia byłego prezydenta Gruzji" src="https://i.iplsc.com/sejm-przyjal-uchwale-ws-stanu-zdrowia-bylego-prezydenta-gruz/000GM4TG7NNCSYF9-C321.jpg" /></a>Na piątkowym posiedzeniu Sejmu posłowie przyjęli specjalną uchwałę w sprawie stanu zdrowia byłego prezydenta Gruzji Micheila Saakaszwilego. - Sejm RP apeluje do władz Gruzji o niezwłoczne umożliwienie leczenia pana Micheila Saakaszwilego. &quot;Za&quot; było 438 posłów. Ośmioro było przeciwko, zaś jeden wstrzymał się od głosu. </p><br clear="all" />

## Zmiana pogody na początek ferii. Temperatura zacznie spadać
 - [https://wydarzenia.interia.pl/kraj/news-zmiana-pogody-na-poczatek-ferii-temperatura-zacznie-spadac,nId,6531886](https://wydarzenia.interia.pl/kraj/news-zmiana-pogody-na-poczatek-ferii-temperatura-zacznie-spadac,nId,6531886)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:30:47+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiana-pogody-na-poczatek-ferii-temperatura-zacznie-spadac,nId,6531886"><img align="left" alt="Zmiana pogody na początek ferii. Temperatura zacznie spadać" src="https://i.iplsc.com/zmiana-pogody-na-poczatek-ferii-temperatura-zacznie-spadac/000GM4U9W1DU8HUQ-C321.jpg" /></a>Ferie tuż, tuż. Już od soboty uczniowie z pięciu województw rozpoczną weekend, po którym czekają ich dwutygodniową przerwę zimowe. W sobotę i niedzielę utrzymywać się będą temperatury od pięciu do 10 st. C., a opady śniegu spodziewane są tylko w górach. W poniedziałek nastąpi jednak zmiana pogody, temperatury spadną i pojawi się szansa na opady w innych częściach kraju.</p><br clear="all" />

## Rozstrzyga się los Krajowego Planu Odbudowy. Trwa posiedzenie Sejmu
 - [https://wydarzenia.interia.pl/kraj/news-rozstrzyga-sie-los-krajowego-planu-odbudowy-trwa-posiedzenie,nId,6531869](https://wydarzenia.interia.pl/kraj/news-rozstrzyga-sie-los-krajowego-planu-odbudowy-trwa-posiedzenie,nId,6531869)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:09:20+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-rozstrzyga-sie-los-krajowego-planu-odbudowy-trwa-posiedzenie,nId,6531869"><img align="left" alt="Rozstrzyga się los Krajowego Planu Odbudowy. Trwa posiedzenie Sejmu" src="https://i.iplsc.com/rozstrzyga-sie-los-krajowego-planu-odbudowy-trwa-posiedzenie/000DMHI50QQIC6VW-C321.jpg" /></a>Trwa posiedzenie Sejmu, podczas którego rozstrzygnie się nowelizacja ustawy o Sądzie Najwyższym. To od przyjęcia zgłoszonego przez PiS 13 grudnia projektu zależy - zdaniem autorów - przyjęcie przez Polskę środków unijnych w ramach Krajowego Planu Odbudowy. W obozie władzy brak większości, dlatego o przyjęciu proponowanych zapisów zdecyduje poparcie opozycji.</p><br clear="all" />

## Sejm przyjął nowelizację ustawy o Sądzie Najwyższym
 - [https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-sadzie-najwyzszym,nId,6531869](https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-sadzie-najwyzszym,nId,6531869)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:09:20+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-sejm-przyjal-nowelizacje-ustawy-o-sadzie-najwyzszym,nId,6531869"><img align="left" alt="Sejm przyjął nowelizację ustawy o Sądzie Najwyższym" src="https://i.iplsc.com/sejm-przyjal-nowelizacje-ustawy-o-sadzie-najwyzszym/000GM53V8GO0YWMG-C321.jpg" /></a>Sejm przegłosował projekt nowelizacji ustawy o Sądzie Najwyższym z poprawkami Prawa i Sprawiedliwości. Zdaniem autorów reforma ma zapewnić Polsce przyjęcie środków unijnych w ramach Krajowego Planu Odbudowy. Podczas prac nad zapisami w sejmowej komisji poprawki opozycji do projektu nie uzyskały poparcia. Teraz ustawa trafi do Senatu, który ma 30 dni na wprowadzenie poprawek i odesłanie ich z powrotem do izby niższej.</p><br clear="all" />

## Pełno w nim erotycznych fresków. Po 20 latach ponownie zaprasza turystów
 - [https://wydarzenia.interia.pl/zagranica/news-pelno-w-nim-erotycznych-freskow-po-20-latach-ponownie-zapras,nId,6532049](https://wydarzenia.interia.pl/zagranica/news-pelno-w-nim-erotycznych-freskow-po-20-latach-ponownie-zapras,nId,6532049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:07:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pelno-w-nim-erotycznych-freskow-po-20-latach-ponownie-zapras,nId,6532049"><img align="left" alt="Pełno w nim erotycznych fresków. Po 20 latach ponownie zaprasza turystów" src="https://i.iplsc.com/pelno-w-nim-erotycznych-freskow-po-20-latach-ponownie-zapras/000GM4OVF8SDF1T6-C321.jpg" /></a>Bywa nazywany &quot;Kaplicą Sykstyńską Pompejów&quot; i jedną z pereł miasta zniszczonego przez erupcję Wezuwiusza. Na jego ścianach widać kalejdoskop barw i obrazów. Szczególną popularnością cieszą erotyczne freski, które w przeszłości ściągały turystów z całego świata. Dom Wettiuszów, bo o nim mowa, przeszedł gruntowną renowację i po 20 latach znów jest otwarty dla zwiedzających. </p><br clear="all" />

## Maciej Czajkowski o autobiografii księcia Harrego: Rebelia antyelżbietańska
 - [https://wydarzenia.interia.pl/zagranica/news-maciej-czajkowski-o-autobiografii-ksiecia-harrego-rebelia-an,nId,6530094](https://wydarzenia.interia.pl/zagranica/news-maciej-czajkowski-o-autobiografii-ksiecia-harrego-rebelia-an,nId,6530094)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 09:00:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-maciej-czajkowski-o-autobiografii-ksiecia-harrego-rebelia-an,nId,6530094"><img align="left" alt="Maciej Czajkowski o autobiografii księcia Harrego: Rebelia antyelżbietańska" src="https://i.iplsc.com/maciej-czajkowski-o-autobiografii-ksiecia-harrego-rebelia-an/000GM1VK7Q4DHEKL-C321.jpg" /></a>- Widzę tę książkę jako pewnego rodzaju domknięcie życia, jakie było do tej pory - mówi o autobiografii księcia Harry'ego Maciej Czajkowski, specjalista od monarchii brytyjskiej. W videocaście Piotra Witwickiego nazywa książkę &quot;rebelią antyelżbietańską&quot;. - Nie przeciw rodzinie, ale zasadom, według których funkcjonuje monarchia - uważa. W rozmowie ocenia też działania pałacu Buckingham.</p><br clear="all" />

## Czesi wybierają nowego prezydenta. Troje kandydatów z szansą na drugą turę
 - [https://wydarzenia.interia.pl/zagranica/news-czesi-wybieraja-nowego-prezydenta-troje-kandydatow-z-szansa-,nId,6532012](https://wydarzenia.interia.pl/zagranica/news-czesi-wybieraja-nowego-prezydenta-troje-kandydatow-z-szansa-,nId,6532012)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:54:23+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czesi-wybieraja-nowego-prezydenta-troje-kandydatow-z-szansa-,nId,6532012"><img align="left" alt="Czesi wybierają nowego prezydenta. Troje kandydatów z szansą na drugą turę" src="https://i.iplsc.com/czesi-wybieraja-nowego-prezydenta-troje-kandydatow-z-szansa/000GM4KHEO84V3UY-C321.jpg" /></a>W Czechach w piątek i sobotę odbywa się pierwsza tura wyborów prezydenckich. Zgodnie z sondażami niezbędna będzie dogrywka, a szansę na nią ma troje kandydatów, w tym jedna kobieta. Elekcję poprzedziła czwartkowa debata telewizyjna głównych pretendentów do objęcia urzędu po ustępującym Miloszu Zemanie.</p><br clear="all" />

## Pokazują wojnę online. Kontrowersje w środowisku ratowników
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pokazuja-wojne-online-kontrowersje-w-srodowisku-ratownikow,nId,6530137](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pokazuja-wojne-online-kontrowersje-w-srodowisku-ratownikow,nId,6530137)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:43:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-pokazuja-wojne-online-kontrowersje-w-srodowisku-ratownikow,nId,6530137"><img align="left" alt="Pokazują wojnę online. Kontrowersje w środowisku ratowników" src="https://i.iplsc.com/pokazuja-wojne-online-kontrowersje-w-srodowisku-ratownikow/000GM4K060HFQH5A-C321.jpg" /></a>Ostrzelane samochody, krwawe obrazki z pierwszej linii frontu. Wojnę w pełnej krasie, bo trudno nazwać to inaczej, można oglądać w mediach społecznościowych Damiana Dudy, szefa Wydziału Polityki Informacyjnej RCB. Publiczna aktywność lidera zespołu medyków pola walki &quot;W międzyczasie&quot; wzbudza jednak kontrowersje części środowiska ratowników wyjeżdżających do Ukrainy. Czy sława i doniesienia z frontu online dodatkowo narażają personel? - Jeśli publikujemy jakieś materiały, dbamy o wrażliwe informacje - odpowiada krótko autor, którego na...</p><br clear="all" />

## Nowy projekt prawa komunikacji elektronicznej. "PiS chce szpiegować Polaków"
 - [https://wydarzenia.interia.pl/kraj/news-nowy-projekt-prawa-komunikacji-elektronicznej-pis-chce-szpie,nId,6532019](https://wydarzenia.interia.pl/kraj/news-nowy-projekt-prawa-komunikacji-elektronicznej-pis-chce-szpie,nId,6532019)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:39:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-projekt-prawa-komunikacji-elektronicznej-pis-chce-szpie,nId,6532019"><img align="left" alt="Nowy projekt prawa komunikacji elektronicznej. &quot;PiS chce szpiegować Polaków&quot;" src="https://i.iplsc.com/nowy-projekt-prawa-komunikacji-elektronicznej-pis-chce-szpie/000GM4JW3TUVVR5I-C321.jpg" /></a>- Nasze państwo przekształca się w państwo policyjne - uważa Jacek Wilk z Konfederacji. Posłowie tego ugrupowania złożyli w piątek interwencję poselską w Komendzie Głównej Policji w Warszawie. Powodem jest wpłynięcie do Sejmu projektu prawa komunikacji elektronicznej, który liczy trzy i pół tysiąca stron. Z przepisów wynika, że służby dostaną szerszy dostęp do naszych połączeń, maili i czatów w komunikatorach. Kontrowersje wzbudza zakup kolejnego oprogramowania szpiegującego, tym razem przez policję. Według posłów Konfederacji sprawa jest...</p><br clear="all" />

## Amerykanom brakuje jaj. "Podstawowy artykuł stał się dobrem luksusowym"
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanom-brakuje-jaj-podstawowy-artykul-stal-sie-dobrem-lu,nId,6532025](https://wydarzenia.interia.pl/zagranica/news-amerykanom-brakuje-jaj-podstawowy-artykul-stal-sie-dobrem-lu,nId,6532025)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:19:26+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanom-brakuje-jaj-podstawowy-artykul-stal-sie-dobrem-lu,nId,6532025"><img align="left" alt="Amerykanom brakuje jaj. &quot;Podstawowy artykuł stał się dobrem luksusowym&quot;" src="https://i.iplsc.com/amerykanom-brakuje-jaj-podstawowy-artykul-stal-sie-dobrem-lu/00061EXLMYXUGQDN-C321.jpg" /></a>Niedobór jajek w Ameryce - alarmują tamtejsze media. W niektórych sklepach widać puste półki. Najtańsze jajka - tych brakuje najbardziej - są już reglamentowane. Jednocześnie gwałtownie rosną ceny. Powodem braków jest przede wszystkim ptasia grypa.</p><br clear="all" />

## Konduktor: Pilnujcie swoich bagaży. Pasażerowie oburzeni
 - [https://wydarzenia.interia.pl/zagranica/news-konduktor-pilnujcie-swoich-bagazy-pasazerowie-oburzeni,nId,6532013](https://wydarzenia.interia.pl/zagranica/news-konduktor-pilnujcie-swoich-bagazy-pasazerowie-oburzeni,nId,6532013)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:02:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-konduktor-pilnujcie-swoich-bagazy-pasazerowie-oburzeni,nId,6532013"><img align="left" alt="Konduktor: Pilnujcie swoich bagaży. Pasażerowie oburzeni" src="https://i.iplsc.com/konduktor-pilnujcie-swoich-bagazy-pasazerowie-oburzeni/000GM4GN393N2BE4-C321.jpg" /></a>Konduktor zaapelował do pasażerów pociągu, aby ci pilnowali swoich bagaży i uważali na &quot;śródziemnomorskie typy&quot;, które &quot;kłusują po Holandii&quot;. Składem jechało wówczas wiele osób o śródziemnomorskim wyglądzie lub pochodzeniu, w tym jeden z samorządowych polityków, który nagłośnił sprawę na Twitterze. Holenderska kolej odcięła się od rasistowskich komentarzy i przeprosiła za zaistniały incydent.</p><br clear="all" />

## Coraz mniej czasu na złożenie wniosku. Jeśli nie zdążysz, przepadnie ci 1000 zł
 - [https://wydarzenia.interia.pl/kraj/news-coraz-mniej-czasu-na-zlozenie-wniosku-jesli-nie-zdazysz-prze,nId,6529976](https://wydarzenia.interia.pl/kraj/news-coraz-mniej-czasu-na-zlozenie-wniosku-jesli-nie-zdazysz-prze,nId,6529976)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 08:01:28+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-coraz-mniej-czasu-na-zlozenie-wniosku-jesli-nie-zdazysz-prze,nId,6529976"><img align="left" alt="Coraz mniej czasu na złożenie wniosku. Jeśli nie zdążysz, przepadnie ci 1000 zł " src="https://i.iplsc.com/coraz-mniej-czasu-na-zlozenie-wniosku-jesli-nie-zdazysz-prze/000G60S0WR7NNCQO-C321.jpg" /></a>Dzięki dodatkowi elektrycznemu można zyskać nawet 1500 zł dofinansowania. Jednak nie zostało dużo czasu na złożenie wniosku. Można to zrobić jeszcze tylko przez kilkanaście dni. Sprawdź, komu przysługuje dodatek elektryczny i jak się o niego starać.</p><br clear="all" />

## Warszawski ratusz chce walczyć z dieslami. Szykują się ograniczenia
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawski-ratusz-chce-walczyc-z-dieslami-szykuja-sie-ograni,nId,6530494](https://wydarzenia.interia.pl/mazowieckie/news-warszawski-ratusz-chce-walczyc-z-dieslami-szykuja-sie-ograni,nId,6530494)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 07:57:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawski-ratusz-chce-walczyc-z-dieslami-szykuja-sie-ograni,nId,6530494"><img align="left" alt="Warszawski ratusz chce walczyć z dieslami. Szykują się ograniczenia" src="https://i.iplsc.com/warszawski-ratusz-chce-walczyc-z-dieslami-szykuja-sie-ograni/000GM3FZQ5I7EFWA-C321.jpg" /></a>Przed trującymi autami z silnikiem diesla przestrzegają grafiki, które pojawiają się w różnych miejscach Warszawy. Jak dowiedziała się Interia, ratusz chce w ten sposób przekonać mieszkańców do wprowadzenia Strefy Czystego Transportu. Na jej obszar nie mogłyby wjeżdżać samochody niespełniające ekologicznych norm, a wśród nich - być może - także te wyprodukowane mniej niż 10 lat temu. Kierowcom takich aut władze stolicy sugerują chociażby przesiadkę na komunikację miejską.</p><br clear="all" />

## Atak nożownika w Budapeszcie. Nie żyje policjant
 - [https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-budapeszcie-nie-zyje-policjant,nId,6531893](https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-budapeszcie-nie-zyje-policjant,nId,6531893)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 07:42:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-nozownika-w-budapeszcie-nie-zyje-policjant,nId,6531893"><img align="left" alt="Atak nożownika w Budapeszcie. Nie żyje policjant" src="https://i.iplsc.com/atak-nozownika-w-budapeszcie-nie-zyje-policjant/000GM4DAGV3SRFST-C321.jpg" /></a>W stolicy Węgier miał miejsce atak nożownika. Napastnik ranił trzech policjantów. Jeden z funkcjonariuszy zmarł w wyniku poniesionych obrażeń. Nożownik został obezwładniony - informuje agencja Reutera, powołując się na komunikat budapeszteńskiej policji. Napastnika postrzelono podczas ucieczki.</p><br clear="all" />

## ISW o doniesieniach Rosji ws. Sołedaru: Propaganda wyolbrzymia. "Pyrrusowe zwycięstwo"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-doniesieniach-rosji-ws-soledaru-propaganda-wyolbrzymia,nId,6531877](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-doniesieniach-rosji-ws-soledaru-propaganda-wyolbrzymia,nId,6531877)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 07:25:28+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-o-doniesieniach-rosji-ws-soledaru-propaganda-wyolbrzymia,nId,6531877"><img align="left" alt="ISW o doniesieniach Rosji ws. Sołedaru: Propaganda wyolbrzymia. &quot;Pyrrusowe zwycięstwo&quot;" src="https://i.iplsc.com/isw-o-doniesieniach-rosji-ws-soledaru-propaganda-wyolbrzymia/000GM479C4LMCUAW-C321.jpg" /></a>Ogłaszane przez Rosjan zajęcie Sołedaru nie ma znaczenia operacyjnego i prawdopodobnie nie zapowiada rychłego okrążenia Bachmutu przez Rosjan - ocenia amerykański think tank Instytut Studiów nad wojną (ISW). Doniesienia o zdobyciu miasta dementowane są przez stronę ukraińską. W czwartek sztab ukraiński nie informował jednak - w przeciwieństwie do poprzednich dni - że siły ukraińskie odpierają rosyjskie ataki na Sołedar.</p><br clear="all" />

## Polki nie chcą mieć dzieci albo nie wiedzą, czy chcą. Potomstwo staje się luksusem
 - [https://wydarzenia.interia.pl/kraj/news-polki-nie-chca-miec-dzieci-albo-nie-wiedza-czy-chca-potomstw,nId,6530152](https://wydarzenia.interia.pl/kraj/news-polki-nie-chca-miec-dzieci-albo-nie-wiedza-czy-chca-potomstw,nId,6530152)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 07:23:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-polki-nie-chca-miec-dzieci-albo-nie-wiedza-czy-chca-potomstw,nId,6530152"><img align="left" alt="Polki nie chcą mieć dzieci albo nie wiedzą, czy chcą. Potomstwo staje się luksusem" src="https://i.iplsc.com/polki-nie-chca-miec-dzieci-albo-nie-wiedza-czy-chca-potomstw/000GM1PPVSFRLNHG-C321.jpg" /></a>Wyniki najnowszego badania CBOS-u potwierdzają, że sytuacja demograficzna Polski pogarsza się z każdym miesiącem. Ze wspomnianego sondażu wynika, że przeszło dwie trzecie Polek nie planuje potomstwa albo nie wie, czy chce mieć dziecko. Wśród kobiet bezdzietnych wskaźnik ten coraz bardziej zbliża się natomiast do 50 proc.</p><br clear="all" />

## Celnicy zatrzymali przesyłkę z Chin. W środku... 180 tys. tabletek na potencję
 - [https://wydarzenia.interia.pl/kraj/news-celnicy-zatrzymali-przesylke-z-chin-w-srodku-180-tys-tablete,nId,6531867](https://wydarzenia.interia.pl/kraj/news-celnicy-zatrzymali-przesylke-z-chin-w-srodku-180-tys-tablete,nId,6531867)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 06:49:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-celnicy-zatrzymali-przesylke-z-chin-w-srodku-180-tys-tablete,nId,6531867"><img align="left" alt="Celnicy zatrzymali przesyłkę z Chin. W środku... 180 tys. tabletek na potencję" src="https://i.iplsc.com/celnicy-zatrzymali-przesylke-z-chin-w-srodku-180-tys-tablete/000GM45P8VR5I3YL-C321.jpg" /></a>Funkcjonariusze mazowieckiej Izby Administracji Skarbowej zatrzymali podczas rutynowej kontroli na warszawskim lotnisku Chopina przesyłkę z Chin. W kartonach zamiast suplementów dla zwierząt znaleźli prawie 180 tys. nielegalnych tabletek na potencję wartych ponad osiem milionów złotych. Były one przeznaczone na sprzedaż. </p><br clear="all" />

## Reznikow: Ukraina stała się de facto członkiem NATO
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-reznikow-ukraina-jest-juz-nieformalnym-czlonkiem-nato,nId,6531873](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-reznikow-ukraina-jest-juz-nieformalnym-czlonkiem-nato,nId,6531873)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 06:42:38+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-reznikow-ukraina-jest-juz-nieformalnym-czlonkiem-nato,nId,6531873"><img align="left" alt="Reznikow: Ukraina stała się de facto członkiem NATO" src="https://i.iplsc.com/reznikow-ukraina-stala-sie-de-facto-czlonkiem-nato/000GH2RELPSUVVQ5-C321.jpg" /></a>Ukraina stała się de facto członkiem sojuszu wojskowego NATO - stwierdził minister obrony Ukrainy Ołeksij Reznikow w wywiadzie dla BBC. W jego opinii kraje zachodnie - niegdyś zaniepokojone, że pomoc wojskowa państwu na wschodzie może być postrzegana przez Rosję jako eskalacja - zmieniają swoje &quot;podejście myślowe&quot;.</p><br clear="all" />

## Pogoda: W piątek duże zachmurzenie i opady deszczu. Gdzie śnieg?
 - [https://wydarzenia.interia.pl/kraj/news-pogoda-w-piatek-duze-zachmurzenie-i-opady-deszczu-gdzie-snie,nId,6531859](https://wydarzenia.interia.pl/kraj/news-pogoda-w-piatek-duze-zachmurzenie-i-opady-deszczu-gdzie-snie,nId,6531859)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 06:15:53+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-pogoda-w-piatek-duze-zachmurzenie-i-opady-deszczu-gdzie-snie,nId,6531859"><img align="left" alt="Pogoda: W piątek duże zachmurzenie i opady deszczu. Gdzie śnieg?" src="https://i.iplsc.com/pogoda-w-piatek-duze-zachmurzenie-i-opady-deszczu-gdzie-snie/000GM441RW66DESV-C321.jpg" /></a>Duże zachmurzenie z możliwymi większymi przejaśnieniami na wschodzie kraju -  prognozuje piątkową pogodę synoptyk IMGW Kamil Walczak. Na nizinach spodziewane są opady deszczu, w górach śniegu.</p><br clear="all" />

## Mijają cztery lata od zamachu na Pawła Adamowicza
 - [https://wydarzenia.interia.pl/raporty/raport-pawel-adamowicz-nie-zyje/aktualnosci/news-mijaja-cztery-lata-od-zamachu-na-pawla-adamowicza,nId,6531854](https://wydarzenia.interia.pl/raporty/raport-pawel-adamowicz-nie-zyje/aktualnosci/news-mijaja-cztery-lata-od-zamachu-na-pawla-adamowicza,nId,6531854)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 06:04:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-pawel-adamowicz-nie-zyje/aktualnosci/news-mijaja-cztery-lata-od-zamachu-na-pawla-adamowicza,nId,6531854"><img align="left" alt="Mijają cztery lata od zamachu na Pawła Adamowicza" src="https://i.iplsc.com/mijaja-cztery-lata-od-zamachu-na-pawla-adamowicza/000GM43C280DU8K4-C321.jpg" /></a>Cztery lata temu miał miejsce zamach na Pawła Adamowicza. Podczas finału Wielkiej Orkiestry Świątecznej Pomocy na scenę wbiegł nieznany mężczyzna i ranił kilkukrotnie nożem prezydenta Gdańska, po czym wyrwał mikrofon konferansjerowi i wykrzyczał swoje motywacje. Po niezwłocznych próbach reanimacji i kilku godzinach operacji Paweł Adamowicz zmarł następnego dnia.</p><br clear="all" />

## Matki poszukują ciał swoich dzieci. Odnalazły już ponad 1,5 tys. ofiar
 - [https://wydarzenia.interia.pl/zagranica/news-matki-poszukuja-cial-swoich-dzieci-odnalazly-juz-ponad-1-5-t,nId,6531849](https://wydarzenia.interia.pl/zagranica/news-matki-poszukuja-cial-swoich-dzieci-odnalazly-juz-ponad-1-5-t,nId,6531849)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 05:51:42+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-matki-poszukuja-cial-swoich-dzieci-odnalazly-juz-ponad-1-5-t,nId,6531849"><img align="left" alt="Matki poszukują ciał swoich dzieci. Odnalazły już ponad 1,5 tys. ofiar" src="https://i.iplsc.com/matki-poszukuja-cial-swoich-dzieci-odnalazly-juz-ponad-1-5-t/000GM42F1HDDQLQ1-C321.jpg" /></a>Stowarzyszenie Matek Poszukujących na Sonorze (Madres Buscadoras de Sonora) działające od 2019 roku znalazło na tej meksykańskiej pustyni ciała 1520 osób, zabitych przez kartele narkotykowe - podała organizacja, cytowana w czwartek przez dziennik &quot;La Nacion&quot;.</p><br clear="all" />

## Ferie 2023 startują. Odbędą się w czterech terminach
 - [https://wydarzenia.interia.pl/kraj/news-ferie-2023-startuja-odbeda-sie-w-czterech-terminach,nId,6531846](https://wydarzenia.interia.pl/kraj/news-ferie-2023-startuja-odbeda-sie-w-czterech-terminach,nId,6531846)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 05:36:41+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-ferie-2023-startuja-odbeda-sie-w-czterech-terminach,nId,6531846"><img align="left" alt="Ferie 2023 startują. Odbędą się w czterech terminach" src="https://i.iplsc.com/ferie-2023-startuja-odbeda-sie-w-czterech-terminach/000EDBZXNRSSMOJP-C321.jpg" /></a>Ferie zimowe w szkołach rozpoczynają się w tym roku 14 stycznia, zatem dla części dzieci piątek 13 stycznia jest ostatnim przed zimowymi wakacjami dniem w nauki. Dwutygodniowa przerwa w zajęciach odbędzie się w czterech terminach i w sumie potrwa do 26 lutego. Przedstawiamy harmonogram dla poszczególnych województw.</p><br clear="all" />

## Silne eksplozje w Kanadzie. Są zaginieni
 - [https://wydarzenia.interia.pl/zagranica/news-silne-eksplozje-w-kanadzie-sa-zaginieni,nId,6531844](https://wydarzenia.interia.pl/zagranica/news-silne-eksplozje-w-kanadzie-sa-zaginieni,nId,6531844)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 05:30:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-silne-eksplozje-w-kanadzie-sa-zaginieni,nId,6531844"><img align="left" alt="Silne eksplozje w Kanadzie. Są zaginieni" src="https://i.iplsc.com/silne-eksplozje-w-kanadzie-sa-zaginieni/000GM41MGGW9HO15-C321.jpg" /></a>Służby ratunkowe poszukują trzech osób po wybuchu na stacji dystrybucji propanu w Saint-Roch-de-l’Achigan w kanadyjskiej prowincji Quebec, do którego doszło w czwartek. Wcześniej seria silnych eksplozji zniszczyła zakład utylizacyjny w miejscowości St. Catharines w Ontario.</p><br clear="all" />

## Witamina D chroni przed czerniakiem skóry. Nowe badanie
 - [https://wydarzenia.interia.pl/zdrowie/news-witamina-d-chroni-przed-czerniakiem-skory-nowe-badanie,nId,6531841](https://wydarzenia.interia.pl/zdrowie/news-witamina-d-chroni-przed-czerniakiem-skory-nowe-badanie,nId,6531841)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 05:12:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zdrowie/news-witamina-d-chroni-przed-czerniakiem-skory-nowe-badanie,nId,6531841"><img align="left" alt="Witamina D chroni przed czerniakiem skóry. Nowe badanie" src="https://i.iplsc.com/witamina-d-chroni-przed-czerniakiem-skory-nowe-badanie/000363O0L1EVAT9R-C321.jpg" /></a>Osoby suplementujące witaminę D rzadziej chorują na czerniaka skóry niż ci, którzy tej witaminy nie przyjmują - wynika z fińskiego badania, które publikuje czasopismo &quot;Melanoma Research&quot;. Ponadto osoby, które regularnie stosują suplementy z witaminą D, mają też znacznie niższe ogólne ryzyko nowotworów skóry (łącznie czerniaka i raków skóry).</p><br clear="all" />

## Zmarła Lisa Marie Presley. Była córką Elvisa
 - [https://wydarzenia.interia.pl/zagranica/news-zmarla-lisa-marie-presley-byla-corka-elvisa,nId,6531839](https://wydarzenia.interia.pl/zagranica/news-zmarla-lisa-marie-presley-byla-corka-elvisa,nId,6531839)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 05:08:50+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zmarla-lisa-marie-presley-byla-corka-elvisa,nId,6531839"><img align="left" alt="Zmarła Lisa Marie Presley. Była córką Elvisa" src="https://i.iplsc.com/zmarla-lisa-marie-presley-byla-corka-elvisa/000GM40X88IWY5TR-C321.jpg" /></a>W wieku 54 lat zmarła w Kalifornii amerykańska piosenkarka Lisa Marie Presley, córka legendy rock'n'rolla Elvisa Presleya - poinformowały w czwartek wieczorem czasu lokalnego amerykańskie media, powołując się na jej rodzinę.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130541](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130541)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130541"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130610](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130610)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130610"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130646](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130646)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130646"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130712](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130712)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130712"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130733](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130733)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130733"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130808](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130808)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-13 04:29:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo,nzId,3621,akt,130808"><img align="left" alt="Wojna w Ukrainie. 324. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-324-dzien-inwazji-rosji-relacja-na-zywo/000GM3ZWEYOKSA1D-C321.jpg" /></a>Najnowsze informacje dotyczące rosyjskiej inwazji na Ukrainę. Śledź naszą relację na żywo.</p><br clear="all" />
