# Source Lifehacker, Source URL:https://lifehacker.com/rss, Source language: en-US

## Halo Top Will Give You Free Ice Cream for Sticking to a New Goal
 - [https://lifehacker.com/halo-top-will-give-you-free-ice-cream-for-sticking-to-a-1849985992](https://lifehacker.com/halo-top-will-give-you-free-ice-cream-for-sticking-to-a-1849985992)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 23:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KRYqyRt6--/c_fit,fl_progressive,q_80,w_636/37c5879d9e9fe9285b6c410088e9bf5e.jpg" /><p>Halo Top is kicking off the new year by offering up an <a href="https://www.halotopgoalgetter.com/" rel="noopener noreferrer" target="_blank">accountability goal tracker</a> that gives you rewards as you accomplish your goal—and the first prize is a free tub of Halo Top ice cream. Once you claim that reward, you’ll be entered to win additional sweepstakes as you continue making progress. <br /></p><p><a href="https://lifehacker.com/halo-top-will-give-you-free-ice-cream-for-sticking-to-a-1849985992">Read more...</a></p>

## Baking Soda Will Completely Wreck Your Carpet
 - [https://lifehacker.com/baking-soda-will-fuck-up-your-carpet-1849984622](https://lifehacker.com/baking-soda-will-fuck-up-your-carpet-1849984622)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 23:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--SZcMQ0HK--/c_fit,fl_progressive,q_80,w_636/90265a0e327fe63d63c4a3e85ea23464.jpg" /><p><a href="https://lifehacker.com/don-t-clean-your-air-fryer-with-this-viral-tiktok-trick-1849553685">Once again</a>, we regret to inform you that a cleaning hack you may have seen online is maybe not a great idea. This one involves sprinkling bicarb—or baking soda—on your carpet to remove stains or odors, which certainly <em>sounds</em> promising considering all <a href="https://lifehacker.com/15-smarter-ways-you-should-be-using-baking-soda-1848491125">the wonderful cleaning uses baking soda typically has</a>. But cleaning…</p><p><a href="https://lifehacker.com/baking-soda-will-fuck-up-your-carpet-1849984622">Read more...</a></p>

## You Need to Know Your Roof's 'Snow Load'
 - [https://lifehacker.com/you-need-to-know-your-roofs-snow-load-1849983752](https://lifehacker.com/you-need-to-know-your-roofs-snow-load-1849983752)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 22:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Rs_S2I9C--/c_fit,fl_progressive,q_80,w_636/0ecd79b40a7aedd366cf90b483b4f3dc.jpg" /><p>Most roofs constructed after modern regulations were passed in the U.S. in 1988 are built to withstand a certain amount of extra weight in the form of snow. Even older roofs usually have some extra capacity to allow for snow. But sometimes, larger amounts of snow, or wet or compacted snow can exceed the capacity of…</p><p><a href="https://lifehacker.com/you-need-to-know-your-roofs-snow-load-1849983752">Read more...</a></p>

## This App Uses AI to Generate Custom Playlists
 - [https://lifehacker.com/this-app-uses-ai-to-generate-custom-playlists-1849983912](https://lifehacker.com/this-app-uses-ai-to-generate-custom-playlists-1849983912)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 22:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--O9O2uecX--/c_fit,fl_progressive,q_80,w_636/c3809fcfbfa8f6fe52c55800d0c5589e.jpg" /><p>If you’re tired of music streaming apps deciding what you should listen to, you can take back the power. <a href="https://apps.apple.com/app/playlistai-playlist-maker/id1631703551" rel="noopener noreferrer" target="_blank">PlaylistAI</a> is an app that uses AI to help you create playlists easily, and it is compatible with Spotify and Apple Music. It lets you specify the kind of music you’re looking for and creates custom playlists for…</p><p><a href="https://lifehacker.com/this-app-uses-ai-to-generate-custom-playlists-1849983912">Read more...</a></p>

## 12 Killer Supersets to Add to Your Next Workout
 - [https://lifehacker.com/12-killer-supersets-to-add-to-your-next-workout-1849986590](https://lifehacker.com/12-killer-supersets-to-add-to-your-next-workout-1849986590)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 21:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Cns-sLiU--/c_fit,fl_progressive,q_80,w_636/ed970a5330bfd0913bfbcc42091c58f7.jpg" /><p>Who doesn’t love a superset? Pairing two exercises saves time in your main workout, provided the routine allows. And if you’d like to do a quick bit of extra work at the end of the day, a superset is an efficient way to fit it in. So let’s look at a few perfect pairings you can add to your next workout. </p><p><a href="https://lifehacker.com/12-killer-supersets-to-add-to-your-next-workout-1849986590">Read more...</a></p>

## When You Should (and Shouldn't) Date Someone Newly Single
 - [https://lifehacker.com/when-you-should-and-shouldnt-date-someone-newly-singl-1849982790](https://lifehacker.com/when-you-should-and-shouldnt-date-someone-newly-singl-1849982790)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 21:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PdXqmVYu--/c_fit,fl_progressive,q_80,w_636/9c285c3885868652994847b356d4862b.jpg" /><p>You met someone great. However, they are newly single. So how soon is too soon to date someone who just got out of a relationship? After all, isn’t it wise to let someone grieve and process their breakup? And if they haven’t fully done that, wouldn’t it spell trouble for your budding romance?</p><p><a href="https://lifehacker.com/when-you-should-and-shouldnt-date-someone-newly-singl-1849982790">Read more...</a></p>

## Don’t Buy Apple’s iPhone Cases
 - [https://lifehacker.com/don-t-buy-apple-s-iphone-cases-1849984015](https://lifehacker.com/don-t-buy-apple-s-iphone-cases-1849984015)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 20:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--YTF-lC1V--/c_fit,fl_progressive,q_80,w_636/be4762c5a6b4fcf12fe3884292ce6e29.jpg" /><p>When you get a new iPhone, it’s always a good idea to get a case to go with it: Accidents happen, and you don’t want a crack on the expensive new phone you just bought. And if you’re buying your phone from an Apple store or Apple.com, the company will promote its cases while you’re checking out. But you’re better off…</p><p><a href="https://lifehacker.com/don-t-buy-apple-s-iphone-cases-1849984015">Read more...</a></p>

## How to Get the Most Money Possible From a Canceled Flight
 - [https://lifehacker.com/how-to-get-the-most-money-possible-from-a-canceled-flig-1849981717](https://lifehacker.com/how-to-get-the-most-money-possible-from-a-canceled-flig-1849981717)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 20:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PC8fArYm--/c_fit,fl_progressive,q_80,w_636/ea5d9ef8a7c668d791eb4b27e819c5f0.jpg" /><p>With a <a href="https://www.cnet.com/culture/more-than-3000-flights-canceled-on-christmas-morning/" rel="noopener noreferrer" target="_blank">debacle at Southwest Airlines</a> leading to more than 3,000 flights canceled on Christmas day, and the <a href="https://www.nbcnews.com/news/us-news/live-blog/faa-computer-outage-live-updates-flights-us-affected-rcna65248#rcrd10016" rel="noopener noreferrer" target="_blank">Federal Aviation Administration’s computer outage</a> leading to more than 1,300 flights canceled (and 10,000 delayed in the U.S. on Wednesday), it feels like an on-time flight is an increasing rarity. Clearly, you…</p><p><a href="https://lifehacker.com/how-to-get-the-most-money-possible-from-a-canceled-flig-1849981717">Read more...</a></p>

## Why Antibiotics Don't Work on Colds
 - [https://lifehacker.com/why-antibiotics-dont-work-on-colds-1849981989](https://lifehacker.com/why-antibiotics-dont-work-on-colds-1849981989)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 19:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--7IlMUCA7--/c_fit,fl_progressive,q_80,w_636/0a568520063d62131b3550dc5c5a843b.jpg" /><p>If you’ve been sick with a cough and a sniffly nose for a few days, you might show up at the clinic desperate for something that will make you feel better. But if all signs point to your cold being an ordinary virus (or even a nasty virus like COVID or flu), antibiotics won’t help. Here’s why. </p><p><a href="https://lifehacker.com/why-antibiotics-dont-work-on-colds-1849981989">Read more...</a></p>

## Electric Stoves Are Good, Actually
 - [https://lifehacker.com/electric-stoves-are-good-actually-1849981561](https://lifehacker.com/electric-stoves-are-good-actually-1849981561)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 19:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IN6GnfAJ--/c_fit,fl_progressive,q_80,w_636/7009c07bb40d850493b2ef63caae4493.png" /><p>On Monday, <a href="https://www.bloomberg.com/news/articles/2023-01-09/us-safety-agency-to-consider-ban-on-gas-stoves-amid-health-fears?sref=qYiz2hd0" rel="noopener noreferrer" target="_blank">Bloomberg reported  the Consumer Product Safety Commission would consider a ban on gas stoves</a>, causing everyone from Republican politicians to cooks on Twitter to promptly<em> lose their minds </em>and begin insulting electric stoves.<em> </em>If you were among them, don’t panic: A gas stove ban is unlikely, especially in…</p><p><a href="https://lifehacker.com/electric-stoves-are-good-actually-1849981561">Read more...</a></p>

## 13 of Best TV Rewatch Podcasts
 - [https://lifehacker.com/13-of-best-tv-rewatch-podcasts-1849977332](https://lifehacker.com/13-of-best-tv-rewatch-podcasts-1849977332)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 18:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--C19g7SdO--/c_fit,fl_progressive,q_80,w_636/d7368c405ad2db042187f90d9fc13076.png" /><p>Television rewatch shows are  taking over the podcast zeitgeist. It’s kind of an easy sell—creating content around something that has already won the hearts of a dedicated audience, hitting us with nostalgia feels and offering a chance to reflect on the evolution of pop culture and TV—bonus points if anyone who made…</p><p><a href="https://lifehacker.com/13-of-best-tv-rewatch-podcasts-1849977332">Read more...</a></p>

## The Right Way to Remove Salty Streaks From Your Floor
 - [https://lifehacker.com/the-right-way-to-remove-salty-streaks-from-your-floor-1849980743](https://lifehacker.com/the-right-way-to-remove-salty-streaks-from-your-floor-1849980743)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 18:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--V9jN56OV--/c_fit,fl_progressive,q_80,w_636/5b3c86c95690d021c96cc5158e7049d6.jpg" /><p>Salt is great for dealing with ice outside—but salt is <em>terrible</em> for your floors for the same reason. Even if you’re very much on top of making people remove their shoes when they enter your home, salty dust can still find a way onto your hardwood and other floor surfaces and could lead to permanent damage if you don’t…</p><p><a href="https://lifehacker.com/the-right-way-to-remove-salty-streaks-from-your-floor-1849980743">Read more...</a></p>

## The Out-of-Touch Adult's Guide to Kid Culture: What's Going on With Dungeons & Dragons?
 - [https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-whats-goi-1849982988](https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-whats-goi-1849982988)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 17:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XmiFRgJX--/c_fit,fl_progressive,q_80,w_636/b6c181814bbb787910c00a95d8670af4.jpg" /><p>This week’s out-of-touch guide features three prominent young influencers: One may have abandoned a pig, one is accused of <em>being</em> a pig, and the third is MrBeast. Plus, TikTok’s death row meals trend is dissected, as is the anger of our nations’s nerds.<br /></p><p><a href="https://lifehacker.com/the-out-of-touch-adults-guide-to-kid-culture-whats-goi-1849982988">Read more...</a></p>

## Use a Muffin Tin As a Big Ol' Trivet
 - [https://lifehacker.com/use-a-muffin-tin-as-a-big-ol-trivet-1849980930](https://lifehacker.com/use-a-muffin-tin-as-a-big-ol-trivet-1849980930)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 17:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CCujBjCV--/c_fit,fl_progressive,q_80,w_636/4b667f9a273d90f2b1580be358962954.jpg" /><p>Open up whatever drawer you keep your trivets and hot pads in and count them up. Count your trivets. Count your hot pads. How many do you have? I have four. Usually that is enough. </p><p><a href="https://lifehacker.com/use-a-muffin-tin-as-a-big-ol-trivet-1849980930">Read more...</a></p>

## The Easiest Way to Twist Homemade Pretzels
 - [https://lifehacker.com/the-easiest-way-to-twist-homemade-pretzels-1849981457](https://lifehacker.com/the-easiest-way-to-twist-homemade-pretzels-1849981457)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 16:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--zMLg35Zr--/c_fit,fl_progressive,q_80,w_636/a109eb232156fc073134563f2c7bea3c.jpg" /><p>If you’ve ever walked by a pretzel stand and witnessed the absolute magic of a pro slinging a strand of dough into the perfect twist, you may have been slightly intimidated by the process. To the untrained eye, that string weaves a confusing path. You don’t need that level of dexterity to make pretzels at home; even…</p><p><a href="https://lifehacker.com/the-easiest-way-to-twist-homemade-pretzels-1849981457">Read more...</a></p>

## How to Tell If You Got a ‘Quiet Promotion’ (and Why That’s Not a Good Thing)
 - [https://lifehacker.com/how-to-tell-if-you-got-a-quiet-promotion-and-why-tha-1849980890](https://lifehacker.com/how-to-tell-if-you-got-a-quiet-promotion-and-why-tha-1849980890)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 16:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---Dpkl8wx--/c_fit,fl_progressive,q_80,w_636/9844aadbe70a2a009be55db7671a68bd.jpg" /><p>It’s often not too big a deal when  your boss occasionally asks you to take on a little more work than in your original job description. This request is typically wrapped up in notions of “a great opportunity for growth” and “being a team player.” However, there comes a tipping point where taking on additional…</p><p><a href="https://lifehacker.com/how-to-tell-if-you-got-a-quiet-promotion-and-why-tha-1849980890">Read more...</a></p>

## Maybe Your Divorce Deserves a Party
 - [https://lifehacker.com/maybe-your-divorce-deserves-a-party-1849977489](https://lifehacker.com/maybe-your-divorce-deserves-a-party-1849977489)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 15:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PKFrVwza--/c_fit,fl_progressive,q_80,w_636/b6ff4432e25947f000e04377c6de57f9.jpg" /><p>A divorce is typically an emotionally draining and difficult process that’s rife with negativity. But some people are using the dissolution of their marriage as an opportunity to <em>celebrate</em>—by throwing a divorce party.</p><p><a href="https://lifehacker.com/maybe-your-divorce-deserves-a-party-1849977489">Read more...</a></p>

## How to Choose a Statement Chandelier That Isn’t Tacky
 - [https://lifehacker.com/how-to-choose-a-statement-chandelier-that-isn-t-tacky-1849976287](https://lifehacker.com/how-to-choose-a-statement-chandelier-that-isn-t-tacky-1849976287)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 15:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--w51avVaM--/c_fit,fl_progressive,q_80,w_636/0612905e72b1c39ef675674da2093cfa.jpg" /><p>For some people—like my wife, who is fancy in her heart—a chandelier is the height of elegance. When we moved into our current home, she launched a scorched-earth campaign to have a chandelier installed <em>somewhere</em>, despite the fact that this quirky house has exactly zero appropriate places for one. I once joked that…</p><p><a href="https://lifehacker.com/how-to-choose-a-statement-chandelier-that-isn-t-tacky-1849976287">Read more...</a></p>

## Seven iPhone Automations You Deserve to Make Life Easier
 - [https://lifehacker.com/seven-iphone-automations-you-deserve-to-make-life-easie-1849969049](https://lifehacker.com/seven-iphone-automations-you-deserve-to-make-life-easie-1849969049)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 14:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--T3qQ6bZO--/c_fit,fl_progressive,q_80,w_636/e5221ca9226ceef171430968dd0bc503.png" /><p>We spend a lot of time on our iPhones doing simple, repetitive tasks we shouldn’t have to do. In fact, those simple, repetitive tasks can and should be handed over to your iPhone, so you can get back to tasks you <em>really</em> want to do, like scroll Instagram and TikTok. If you’re willing to spend a couple of minutes on…</p><p><a href="https://lifehacker.com/seven-iphone-automations-you-deserve-to-make-life-easie-1849969049">Read more...</a></p>

## What to Do When You’re Blinded by Another Car’s High Beams
 - [https://lifehacker.com/what-to-do-when-you-re-blinded-by-another-car-s-high-be-1849970220](https://lifehacker.com/what-to-do-when-you-re-blinded-by-another-car-s-high-be-1849970220)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--HtHGBJAW--/c_fit,fl_progressive,q_80,w_636/cf2f47b94393965ac9440614bd8da922.jpg" /><p>Like everything else in the modern age, car headlights have enjoyed a steady advance in terms of technology and function. Back in the earliest days of cars, <a href="https://jalopnik.com/how-to-restore-headlights-without-having-a-nervous-brea-1826231412">headlights</a> used to be called head<em>lamps</em> because that’s what they were—gas-fueled flames inside a glass enclosure. Eventually, car makers migrated to electric…</p><p><a href="https://lifehacker.com/what-to-do-when-you-re-blinded-by-another-car-s-high-be-1849970220">Read more...</a></p>
