# Source URL:https://github.com, Source language: en

## GitHub - LukeSmithxyz/emailwiz: Script that installs/configures a Dovecot, Postfix, Spam Assassin, OpenDKIM Debian web server
 - [https://github.com/LukeSmithxyz/emailwiz](https://github.com/LukeSmithxyz/emailwiz)
 - RSS feed: https://github.com
 - date published: 2023-01-13 13:01:24+00:00
 - user: rumpel
 - tags: digital bunker,selfhost,smarthome

GitHub - LukeSmithxyz/emailwiz: Script that installs/configures a Dovecot, Postfix, Spam Assassin, OpenDKIM Debian web server

## GitHub - awesome-selfhosted/awesome-selfhosted: A list of Free Software network services and web applications which can be hosted on your own servers
 - [https://github.com/awesome-selfhosted/awesome-selfhosted](https://github.com/awesome-selfhosted/awesome-selfhosted)
 - RSS feed: https://github.com
 - date published: 2023-01-13 12:59:05+00:00
 - user: rumpel
 - tags: digital bunker,selfhosted,smarthome

GitHub - awesome-selfhosted/awesome-selfhosted: A list of Free Software network services and web applications which can be hosted on your own servers
