# Source Bankier, Source URL:https://www.bankier.pl/rss/wiadomosci.xml, Source language: pl-PL

## Agencja Fitch zabrał głos. "Solidne perspektywy wzrostu polskiej gospodarki"
 - [https://www.bankier.pl/wiadomosc/Agencja-Fitch-potwierdzila-rating-Polski-na-poziomie-A-z-perspektywa-stabilna-8472160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Agencja-Fitch-potwierdzila-rating-Polski-na-poziomie-A-z-perspektywa-stabilna-8472160.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 22:18:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/500cf4c959fd8b-945-560-67-22-1406-843.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Agencja Fitch Ratings potwierdziła w piątek wieczorem długoterminowy rating Polski w walucie obcej na poziomie "A-" z perspektywą stabilną - podała agencja w komunikacie.</p>

## Polska pomogła Ukrainie w zakupie ośmiu tysięcy terminali Starlink
 - [https://www.bankier.pl/wiadomosc/Polska-pomogla-Ukrainie-w-zakupie-osmiu-tysiecy-terminali-Starlink-8472143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-pomogla-Ukrainie-w-zakupie-osmiu-tysiecy-terminali-Starlink-8472143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 20:37:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/d7b14143b400f4-948-568-0-270-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska pomogła Ukrainie w zakupie ośmiu tysięcy terminali Starlink; dziękuję premierowi Mateuszowi Morawieckiemu i pełnomocnikowi rządu ds. cyberbezpieczeństwa Januszowi Cieszyńskiemu - napisał w piątek na Telegramie minister ds. transformacji cyfrowej Ukrainy Mychajło Fedorow.</p>

## Kotecki: Inflacja mdm może zwiększyć się w styczniu o 6-8 proc.
 - [https://www.bankier.pl/wiadomosc/Kotecki-Inflacja-mdm-moze-zwiekszyc-sie-w-styczniu-o-6-8-proc-8472122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kotecki-Inflacja-mdm-moze-zwiekszyc-sie-w-styczniu-o-6-8-proc-8472122.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 19:42:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/edbff0d85a2bb8-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W styczniu 2023 roku inflacja w Polsce może wzrosnąć o około 6-8 proc. mdm - powiedział członek Rady Polityki Pieniężnej Ludwik Kotecki w Polsat News.</p>

## Rafako wzywa Tauron Wytwarzanie i Tauron PE łącznie o zapłatę 857,6 mln zł
 - [https://www.bankier.pl/wiadomosc/Rafako-wzywa-Tauron-Wytwarzanie-i-Tauron-PE-lacznie-o-zaplate-857-6-mln-zl-8472094.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rafako-wzywa-Tauron-Wytwarzanie-i-Tauron-PE-lacznie-o-zaplate-857-6-mln-zl-8472094.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 18:14:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/5c1bcc9df1580c-948-568-0-0-1500-900.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rafako wezwało Tauron Wytwarzanie o zapłatę  606,5 mln zł, a Tauron Polska Energia o zapłatę 251,1 mln zł - podało Rafako w komunikacie.</p>

## Wybuch gazociągu łączącego Litwę z Łotwą
 - [https://www.bankier.pl/wiadomosc/Wybuch-gazociagu-laczacego-Litwe-z-Lotwa-8472083.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wybuch-gazociagu-laczacego-Litwe-z-Lotwa-8472083.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 17:53:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/eb1d1e058055aa-948-568-0-0-1000-600.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Litewski operator przesyłu gazu Amber Grid poinformował w piątek, że doszło do eksplozji gazociągu łączącego Litwę i Łotwę na odcinku w okolicach litewskiego miasta Paswol na północy kraju..</p>

## Dlaczego Platforma zagłosowała za ustawą o SN? Tusk tłumaczy
 - [https://www.bankier.pl/wiadomosc/Dlaczego-Platforma-zaglosowala-za-ustawa-o-SN-Tusk-tlumaczy-8472079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dlaczego-Platforma-zaglosowala-za-ustawa-o-SN-Tusk-tlumaczy-8472079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 17:34:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/dc3ccade9160fb-948-568-0-65-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pieniądze KPO są własnością Polek i Polaków, a nie tej czy innej ekipy rządowej; podjęliśmy decyzję, żeby zagłosować za pieniędzmi europejskimi, bo mieliśmy świadomość - i najbliższe dni pokażą to - że mieliśmy rację, że ta propozycja może odblokować środki europejskie - podkreślił lider PO Donald Tusk.</p>

## Von der Leyen: KE oceni polską ustawę o SN, gdy nowe prawo zostanie wdrożone
 - [https://www.bankier.pl/wiadomosc/Von-der-Leyen-KE-oceni-polska-ustawe-o-SN-gdy-nowe-prawo-zostanie-wdrozone-8472070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Von-der-Leyen-KE-oceni-polska-ustawe-o-SN-gdy-nowe-prawo-zostanie-wdrozone-8472070.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 17:13:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/d019aca6f5700c-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska oceni, czy ostatnie zmiany w polskim sądownictwie mogą doprowadzić do wypłaty środków z Funduszu Odbudowy dopiero wtedy, gdy nowe prawo zostanie wdrożone - przekazała przewodnicząca KE Ursula von der Leyen w piątek w szwedzkiej Kirunie.</p>

## Kanclerz Scholz opowiada się za importem gazu z Iraku
 - [https://www.bankier.pl/wiadomosc/Niemcy-Kanclerz-Scholz-opowiada-sie-za-importem-gazu-z-Iraku-8472043.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niemcy-Kanclerz-Scholz-opowiada-sie-za-importem-gazu-z-Iraku-8472043.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 16:36:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/ff3e42d39ba0e6-948-569-190-35-1566-940.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kanclerz Niemiec Olaf Scholz opowiedział się za importem gazu z Iraku. "Irak byłby dla nas bardzo mile widzianym partnerem do współpracy w zakresie importu gazu i ropy do Niemiec" - powiedział Scholz w piątek na konferencji prasowej z nowym premierem Iraku Mohammedem Szia al-Sudanim w Berlinie.</p>

## Firma Donalda Trumpa ukarana za oszustwa podatkowe
 - [https://www.bankier.pl/wiadomosc/Firma-Donalda-Trumpa-ukarana-za-oszustwa-podatkowe-8472042.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firma-Donalda-Trumpa-ukarana-za-oszustwa-podatkowe-8472042.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 16:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/5e0635acb2afd4-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd najwyższy stanu Nowy Jork nakazał w piątek Trump Organization - grupie spółek byłego prezydenta USA Donalda Trumpa - zapłatę maksymalnej kary 1,61 mln dolarów za trwające przez 15 lat oszustwa podatkowe. Wcześniej dyrektor finansowy konglomeratu Allan Weisselberg został skazany na pięć miesięcy więzienia.</p>

## Spadkowy koniec wzrostowego tygodnia. Ostrożnie z bankami przed TSUE
 - [https://www.bankier.pl/wiadomosc/Spadkowy-koniec-wzrostowego-tygodnia-Ostroznie-z-bankami-przed-TSUE-8472008.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spadkowy-koniec-wzrostowego-tygodnia-Ostroznie-z-bankami-przed-TSUE-8472008.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 15:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/9e9105ed16dc3a-945-567-337-71-1710-1026.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek indeksy na GPW zaliczyły nieznaczne cofnięcie, które jednak nie przeszkodziło zaliczyć całego tygodnia na solidnych plusach. Spokojniejszy handel w portfelach dużych i średnich spółek został zrekompensowany większymi zmianami cen poszczególnych akcji na szerokim rynku.</p>

## Polki nie planują dzieci. Szefowa resortu rodziny komentuje wyniki badania CBOS
 - [https://www.bankier.pl/wiadomosc/Polki-nie-planuja-dzieci-Szefowa-resortu-rodziny-komentuje-wyniki-badania-CBOS-8471945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polki-nie-planuja-dzieci-Szefowa-resortu-rodziny-komentuje-wyniki-badania-CBOS-8471945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 14:34:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/f/7fa09fd20d5e0f-948-568-0-78-4500-2700.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polityka demograficzna wymaga działań długofalowych. Nie sprzyjają jednak zapowiedzi polityków opozycji o możliwym ograniczeniu programów społecznych - przekazała PAP minister rodziny i polityki społecznej Marlena Maląg, komentując najnowsze badanie CBOS.</p>

## Komputronik szacuje dodatkowy zysk większy niż własna kapitalizacja. Kurs wystrzelił
 - [https://www.bankier.pl/wiadomosc/Komputronik-szacuje-dodatkowy-zysk-wiekszy-niz-swoja-kapitalizacja-Kurs-wystrzelil-8471923.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komputronik-szacuje-dodatkowy-zysk-wiekszy-niz-swoja-kapitalizacja-Kurs-wystrzelil-8471923.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/7/bcda8db9549b8f-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs Komputronika zalicza kolejny dzień mocnych wzrostów. Po informacji z czwartku, o zakończeniu postępowania restrukturyzacyjnego, w piątek spółka podała jej szacunkowy wpływ na wynik w 2022 r. Nadzwyczajny zysk ma być kilka razy większy niż kapitalizacja spółki.</p>

## W pierwszym tygodniu ferii na stacje mogą wrócić podwyżki
 - [https://www.bankier.pl/wiadomosc/W-pierwszym-tygodniu-ferii-na-stacje-moga-wrocic-podwyzki-8471903.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-pierwszym-tygodniu-ferii-na-stacje-moga-wrocic-podwyzki-8471903.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 13:37:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/72a7704e66d2de-948-568-11-0-4596-2757.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszym tygodniu ferii na stacje mogą wrócić kilkugroszowe podwyżki - przewidują analitycy Refleksu. W przypadku benzyny i diesla to będzie efekt wzrostu cen hurtowych od 13 stycznia i ewentualnych dalszych podwyżek - wyjaśnili.</p>

## Przerwy weekendowe w dużych bankach. Możesz mieć problem z kartą
 - [https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-PKO-BP-Pekao-ING-BNP-8471894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przerwa-techniczna-w-PKO-BP-Pekao-ING-BNP-8471894.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 13:27:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/9/f4e4b8444cf2a4-948-568-30-119-2970-1781.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przerwy techniczne, technologiczne, modernizacyjne czy serwisowe – pod takim hasłem banki informują klientów o planowanych pracach nad systemami, które zwykle wiążą się z brakiem dostępu do niektórych usług.</p>

## Czesi wybierają prezydenta. Były premier wśród faworytów
 - [https://www.bankier.pl/wiadomosc/Czesi-wybieraja-prezydenta-Byly-premier-wsrod-faworytow-8471889.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czesi-wybieraja-prezydenta-Byly-premier-wsrod-faworytow-8471889.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 13:22:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/32f4433372bd09-945-560-18-168-3722-2233.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O godz. 14. w piątek w Czechach rozpoczęły się bezpośrednie wybory prezydenckie, w których uczestniczy ośmioro kandydatów. Prezydent Milosz Zeman kończy drugą kadencję i nie mógł już kandydować. Lokale wyborcze zostaną zamknięte o godz. 22 i ponownie będą czynne w sobotę od godz. 8 do 14.</p>

## Pora rozliczyć PIT. Jak połapać się w zmianach? Specjalne wydanie Bankier.pl już 17 stycznia
 - [https://www.bankier.pl/wiadomosc/PIT-2022-Specjalne-wydanie-Bankier-pl-17-stycznia-8471585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PIT-2022-Specjalne-wydanie-Bankier-pl-17-stycznia-8471585.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 12:17:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/d/55b237d87e9b1b-948-568-87-35-3266-1960.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już dawno żaden okres rozliczeń podatkowych nie wydawał się tak trudny, 
jak ten. Zmiany w zakresie PIT-ów nie ominą ani Kowalskiego, ani 
przedsiębiorcy. Do jakich wyborów zmusiły podatników rządowe decyzje i 
jak najlepiej przygotować się do złożenia PIT-ów - o tym będziemy 
informowali przez cały dzień we wtorek 17 stycznia, podczas specjalnego 
wydania Bankier.pl.</p>

## Praca zdalna już w Kodeksie pracy. Sejm zagłosował
 - [https://www.bankier.pl/wiadomosc/Praca-zdalna-juz-w-Kodeksie-pracy-Sejm-zaglosowal-8471815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-zdalna-juz-w-Kodeksie-pracy-Sejm-zaglosowal-8471815.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 12:03:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/5b329e752b5445-948-568-0-100-3983-2390.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm odrzucił w piątek cztery poprawki Senatu do nowelizacji Kodeksu pracy, która na stałe wprowadza do przepisów pracę zdalną. Nowelizacja trafi teraz do podpisu prezydenta.</p>

## Tym będą żyły rynki: kto trzyma się mocno?
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-kto-trzyma-sie-mocno-8471747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-kto-trzyma-sie-mocno-8471747.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/3/5a00e856d1d148-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W trzecim tygodniu stycznia przekonamy się, jak szybko spadają realne płace w Polsce, jak z wybuchem pandemii Covid-19 poradziła sobie chińska gospodarka oraz czy Japończycy ugną się pod naporem sił rynkowych.</p>

## Ustawa wiatrakowa wyjęta z zamrażarki? Sejm zajmie się nią na kolejnym posiedzeniu
 - [https://www.bankier.pl/wiadomosc/Ustawa-wiatrakowa-wyjeta-z-zamrazaki-Sejm-zajmie-sie-nia-na-kolejnym-posiedzeniu-8471805.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ustawa-wiatrakowa-wyjeta-z-zamrazaki-Sejm-zajmie-sie-nia-na-kolejnym-posiedzeniu-8471805.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 11:56:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/2282695a763155-948-568-0-0-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przyjęty przez rząd w lipcu projekt ustawy odległościowej otrzymał w piątek numer druku i został skierowany do I czytania w komisjach sejmowych - podano na stronie Sejmu.</p>

## Trwają prace przy budowie drogi wodnej przez Mierzeję Wiślaną
 - [https://www.bankier.pl/wiadomosc/Trwaja-prace-przy-budowie-drogi-wodnej-przez-Mierzeje-Wislana-8471801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trwaja-prace-przy-budowie-drogi-wodnej-przez-Mierzeje-Wislana-8471801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 11:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/82e1a335167eff-948-568-53-0-1172-703.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oddanie do użytku Kanału Żeglugowego, nie zakończyło budowy 23-kilometrowej drogi wodnej łączącej Zatokę Gdańską z Zalewem Wiślanym. Trwają prace na rzece Elbląg, gdzie zaawansowanie robót wynosi 80 proc. Z powodów atmosferycznych wstrzymane tymczasowo są prace na Zalewie Wiślanym, ale postęp prac w tej części jest taki sam - podał w piątek Urząd Morski w Gdyni.</p>

## "Lex pilot" idzie przez Sejm. Kanały TVP zaprogramowane na pilocie do TV
 - [https://www.bankier.pl/wiadomosc/Lex-pilot-idzie-przez-Sejm-Kanaly-TVP-zaprogramowane-na-pilocie-do-TV-8471757.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lex-pilot-idzie-przez-Sejm-Kanaly-TVP-zaprogramowane-na-pilocie-do-TV-8471757.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 11:16:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/36b93a44086e28-948-568-38-9-3789-2273.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm skierował w piątek rządowy projekt ustawy Prawo komunikacji elektronicznej oraz przepisy wprowadzające ustawę do Komisji Cyfryzacji, Innowacyjności i Nowoczesnych Technologii. Sejm nie zgodził się na odrzucenie projektu w pierwszym czytaniu oraz na skierowanie go dodatkowo do Komisji Kultury i Środków Przekazu.</p>

## Bogdanka ma nowego prezesa
 - [https://www.bankier.pl/wiadomosc/Kasjan-Wyligala-nowym-prezesem-zarzadu-LW-Bogdanka-8471748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kasjan-Wyligala-nowym-prezesem-zarzadu-LW-Bogdanka-8471748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 11:10:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/a1b863de20af70-948-568-39-0-1050-630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rada Nadzorcza LW Bogdanka powołała Kasjana Wyligałę na stanowisko prezesa zarządu LW Bogdanka - poinformowała spółka w komunikacie.</p>

## PKB Wielkiej Brytanii zaskoczył. "Gospodarka najprawdopodobniej nie jest jeszcze w recesji"
 - [https://www.bankier.pl/wiadomosc/PKB-Wielkiej-Brytanii-zaskoczyl-Gospodarka-najprawdopodobniej-nie-jest-jeszcze-w-recesji-8471719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-Wielkiej-Brytanii-zaskoczyl-Gospodarka-najprawdopodobniej-nie-jest-jeszcze-w-recesji-8471719.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 10:37:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/f9615f4959e7e1-948-568-0-97-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W listopadzie gospodarka Wielkiej Brytanii zanotowała wzrost, a nie spadek PKB, którego spodziewali się analitycy, co znaczy, że wbrew podnoszonym od kilku tygodni obawom kraj najprawdopodobniej nie jest jeszcze w recesji - podał w piątek urząd statystyczny ONS.</p>

## Są szanse na wzrosty na rynku obligacji i koniec bessy na akcjach
 - [https://www.bankier.pl/wiadomosc/Sa-szanse-na-wzrosty-na-rynku-obligacji-i-koniec-bessy-na-akcjach-8471700.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sa-szanse-na-wzrosty-na-rynku-obligacji-i-koniec-bessy-na-akcjach-8471700.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 10:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/0/79e40c4f1c744a-948-568-0-169-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />TFI PZU w 2023 roku w Polsce i na świecie oczekuje spadku inflacji, co wraz ze spowolnieniem gospodarczym oznacza zielone światło dla obligacji. Na horyzoncie widać także koniec bessy na rynku akcji, ale w najbliższych miesiącach negatywny wpływ na indeksy mogą mieć spadające zyski spółek.</p>

## Coraz bliżej KPO. Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym
 - [https://www.bankier.pl/wiadomosc/Coraz-blizej-KPO-Sejm-uchwalil-nowelizacje-ustawy-o-Sadzie-Najwyzszym-8471680.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-blizej-KPO-Sejm-uchwalil-nowelizacje-ustawy-o-Sadzie-Najwyzszym-8471680.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 10:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/8e4c8569866203-948-568-0-61-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym. </p>

## Przemoc ekonomiczna i cyberprzemoc uwzględnione w przepisach dot. przeciwdziałaniu przemocy w rodzinie
 - [https://www.bankier.pl/wiadomosc/Przemoc-ekonomiczna-i-cyberprzemoc-uwzglednione-w-przepisach-dot-przeciwdzialaniu-przemocy-w-rodzinie-8471675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przemoc-ekonomiczna-i-cyberprzemoc-uwzglednione-w-przepisach-dot-przeciwdzialaniu-przemocy-w-rodzinie-8471675.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:57:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/13641be0ba5a97-948-568-0-75-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił w piątek nowelizację ustawy o przeciwdziałaniu przemocy w rodzinie. Regulacja zakłada m.in. uwzględnienie w przepisach przemocy ekonomicznej i cyberprzemocy, rozszerza też krąg osób objętych ochroną na byłych partnerów i dzieci będące świadkami przemocy domowej.</p>

## Rolnicy dostaną większe emerytury. Sejm znowelizował ustawę o ubezpieczeniu społecznym rolników
 - [https://www.bankier.pl/wiadomosc/Rolnicy-dostana-wieksze-emerytury-Sejm-znowelizowal-ustawe-o-ubezpieczeniu-spolecznym-rolnikow-8471664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rolnicy-dostana-wieksze-emerytury-Sejm-znowelizowal-ustawe-o-ubezpieczeniu-spolecznym-rolnikow-8471664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/0/1eb45b3c4685ab-945-560-240-0-3600-2159.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm w piątek uchwalił nowelizację ustawy o ubezpieczeniu społecznym rolników. Zmiany mają spowodować podniesienie wysokości emerytur rolniczych, chodzi o zmianę sposobu waloryzacji emerytur z KRUS.</p>

## Niemiecka gospodarka rośnie w ciężkich czasach. PKB lepsze od oczekiwań
 - [https://www.bankier.pl/wiadomosc/PKB-Niemiec-w-2022-r-Dane-lepsze-od-oczekiwan-8471613.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-Niemiec-w-2022-r-Dane-lepsze-od-oczekiwan-8471613.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:45:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/3217e27a1eda96-905-542-12-15-905-542.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szok energetyczny zepchnął Niemcy na skraj recesji, 
ale
problemy gospodarcze wydają się być mniej dotkliwe, niż początkowo się 
obawiano. PKB naszych zachodnich sąsiadów rósł w 2022 r. szybciej, niż 
spodziewali się ekonomiści, chociaż zwolnił względem roku 2021. Najbliższa
przyszłość gospodarcza ma zależeć przede wszystkim od cen energii.</p>

## Dezinflacja w Polsce potwierdzona przez GUS. Ale wzrost cen jeszcze przyspieszy
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Polsce-w-grudniu-2022-dane-finalne-8471617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Polsce-w-grudniu-2022-dane-finalne-8471617.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/74ddb9afe5b0fb-948-568-0-102-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zaledwie o 0,1 proc. wzrosły w grudniu ceny towarów i
 usług konsumpcyjnych w stosunku do listopada - wynika z wyliczeń GUS-u.
 Niestety w ujęciu rocznym inflacja pozostaje bardzo wysoka, a w 
najbliższym czasie znów przyspieszy.</p>

## Kuczyński: W zgodzie z prognozami
 - [https://www.bankier.pl/wiadomosc/Kuczynski-W-zgodzie-z-prognozami-8471626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kuczynski-W-zgodzie-z-prognozami-8471626.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/9/f61dd188e29a72-945-560-0-40-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Co dalej po zgodnym z oczekiwaniami odczycie amerykańskiej inflacji? Kto jeszcze wierzy w umocnienie złotego i czy krytykując WIBOR wspieramy Putina?</p>

## E-sklep PGG sprzedał tyle ton węgla. 2022 rok był rekordowy
 - [https://www.bankier.pl/wiadomosc/E-sklep-PGG-sprzedal-tyle-ton-wegla-2022-rok-byl-rekordowy-8471642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/E-sklep-PGG-sprzedal-tyle-ton-wegla-2022-rok-byl-rekordowy-8471642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 09:14:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/9/e37c6b0245d6a2-948-568-0-44-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ubiegłym roku w sklepie internetowym Polskiej Grupy Górniczej złożono prawie pół miliona zamówień na ok. 1,5 miliona ton węgla i miałów węglowych - wynika z informacji spółki. 2022 rok był rekordowy dla e-sklepu największego krajowego producenta węgla.</p>

## Inflacja na Węgrzech przechodzi w galop
 - [https://www.bankier.pl/wiadomosc/Inflacja-na-Wegrzech-przechodzi-w-galop-8471588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-na-Wegrzech-przechodzi-w-galop-8471588.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 08:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/8716147c2c644f-948-568-4-137-1742-1045.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podczas gdy w zdecydowanej większości państw Unii Europejskiej inflacja 
zaczyna hamować, na Węgrzech nadal przyspiesza i jest zdecydowanie 
najwyższa w UE.</p>

## Minister Moskwa: Ograniczymy podwyżki cen ciepła dla obywateli i zapewnimy rekompensaty
 - [https://www.bankier.pl/wiadomosc/Minister-Moskwa-Ograniczymy-podwyzki-cen-ciepla-dla-obywateli-i-zapewnimy-rekompensaty-8471599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-Moskwa-Ograniczymy-podwyzki-cen-ciepla-dla-obywateli-i-zapewnimy-rekompensaty-8471599.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 08:18:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/8/565c5fc6e3e261-948-568-0-163-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wkrótce przedstawimy dodatkowe przepisy mające jeszcze mocniej chronić odbiorców ciepła; zapewnimy rekompensaty i ograniczymy podwyżki dla obywateli - przekazała w piątek minister klimatu i środowiska Anna Moskwa.</p>

## W USA brakuje jajek, gwałtownie rosną ich ceny. Sklepy racjonują te najtańsze
 - [https://www.bankier.pl/wiadomosc/W-USA-brakuje-jajek-gwaltownie-rosna-ich-ceny-Sklepy-racjonuja-te-najtansze-8471591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-USA-brakuje-jajek-gwaltownie-rosna-ich-ceny-Sklepy-racjonuja-te-najtansze-8471591.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 08:08:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/003230e934559b-948-568-0-415-4494-2696.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Ameryce występuje niedobór jajek. W niektórych sklepach widać puste półki. Brakuje zwłaszcza najtańszych jajek i są one przedmiotem racjonowania. Jednocześnie gwałtownie rosną ceny. Powodem braków jest przede wszystkim ptasia grypa.</p>

## Historyczna nadwyżka Chin
 - [https://www.bankier.pl/wiadomosc/Chiny-eksport-i-import-w-2022-r-Partnerzy-handlowi-i-najwazniejsze-towary-8471525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-eksport-i-import-w-2022-r-Partnerzy-handlowi-i-najwazniejsze-towary-8471525.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 07:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/8f79e42d423732-948-568-55-82-1519-911.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Słaby popyt wewnętrzny i silny popyt za granicą 
wywindowały w minionym roku nadwyżkę handlową Chin do rekordowego 
poziomu. W tym roku gospodarka Państwa Środka będzie za to musiała sobie
 radzić w zupełnie innych warunkach. Na razie zmaga się z konsekwencjami
 nagłego porzucenia polityki zero Covid.</p>

## Musk ma kolejny kontrowersyjny pomysł, jak zarobić na Twitterze
 - [https://www.bankier.pl/wiadomosc/Musk-wystawi-nazwy-uzytkownikow-Twittera-na-aukcje-8471544.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Musk-wystawi-nazwy-uzytkownikow-Twittera-na-aukcje-8471544.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 07:20:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/6/b3a2bfb6de56ac-948-569-30-87-966-580.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Elon Musk wpadł na kolejny kontrowersyjny pomysł zarobienia dodatkowych pieniędzy na Twitterze. Po fiasku opłaty za "niebieski znaczek" na celownik wziął nazwy użytkowników. Przyjdzie za nie zapłacić. </p>

## Przekręt giełdy kryptowalut FTX. Odzyskano miliardy zaginionych dolarów
 - [https://www.bankier.pl/wiadomosc/Przekret-gieldy-kryptowalut-FTX-Odzyskano-miliardy-zaginionych-dolarow-8471550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przekret-gieldy-kryptowalut-FTX-Odzyskano-miliardy-zaginionych-dolarow-8471550.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 07:20:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/6/70361c2ce7410f-948-568-0-0-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Upadek jednej z największych giełdy kryptowalut FTX wstrząsnął rynkami, a klienci zostali z pustymi kieszeniami. Okazuje się jednak, że udało się odnaleźć zaginione... 5 miliardów dolarów.</p>

## Rzecznik rządu: Wypłata z KPO to perspektywa maja-czerwca
 - [https://www.bankier.pl/wiadomosc/Rzecznik-rzadu-Wyplata-z-KPO-to-perspektywa-maja-czerwca-8471547.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzecznik-rzadu-Wyplata-z-KPO-to-perspektywa-maja-czerwca-8471547.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 06:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/3/3ba76eca8421b3-948-568-0-22-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeżeli proces legislacyjny ws. ustawy o SN zakończy się w ciągu pół miesiąca, półtora, to później składamy wniosek do KE; wypłata z KPO, to perspektywa maja, czerwca - mówił w piątek rzecznik rządu Piotr Müller.</p>

## Wnorowski (RPP): Możliwe niewielkie podwyżki stóp proc. w I kwartale
 - [https://www.bankier.pl/wiadomosc/Wnorowski-RPP-Mozliwe-niewielkie-podwyzki-stop-proc-w-I-kwartale-8471541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wnorowski-RPP-Mozliwe-niewielkie-podwyzki-stop-proc-w-I-kwartale-8471541.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 06:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/b/9e0e16bb90b8fa-948-568-0-86-3131-1878.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przy silnym impulsie inflacyjnym w I kwartale możliwa jest jedna lub dwie niewielkie podwyżki stóp  - powiedział w telewizji BIZNES 24 członek RPP Henryk Wnorowski.</p>

## Orlen poluje na start-upy za granicą. Dokonał największej z dotychczasowych inwestycji
 - [https://www.bankier.pl/wiadomosc/Orlen-poluje-na-start-upy-za-granica-Dokonal-najwiekszej-z-dotychczasowych-inwestycji-8471523.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Orlen-poluje-na-start-upy-za-granica-Dokonal-najwiekszej-z-dotychczasowych-inwestycji-8471523.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:55:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/7b2fb12ad7d3f8-948-568-20-10-3980-2387.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Płocki koncern zainwestował w innowacyjną francuską platformę logistyczną Shippeo - podaje w piątek "Rzeczpospolita". Gazeta zauważa jednocześnie, że rynek technologicznych transakcji w Polsce i Europie wyraźnie słabnie.</p>

## Jak Polacy robią zakupy? Patrzą już teraz tylko na rosnące ceny
 - [https://www.bankier.pl/wiadomosc/Jak-Polacy-robia-zakupy-Patrza-juz-teraz-tylko-na-rosnace-ceny-8471521.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Jak-Polacy-robia-zakupy-Patrza-juz-teraz-tylko-na-rosnace-ceny-8471521.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:52:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/1/0820e00b389082-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy patrzą już teraz tylko na rosnące ceny. Znaczenie innych kryteriów na zakupach spada. Do tego już ponad 80 proc. regularnie czyta gazetki reklamowe sieci, by wyszukiwać oferty i planować zakupy – czytamy w piątek w "Rzeczpospolitej".</p>

## Brytyjczycy coraz bardziej żałują brexitu. "Większość podwyżek podatków nie byłaby potrzebna"
 - [https://www.bankier.pl/wiadomosc/Brytyjczycy-coraz-bardziej-zaluja-brexitu-Wiekszosc-podwyzek-podatkow-nie-bylaby-potrzebna-8471517.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjczycy-coraz-bardziej-zaluja-brexitu-Wiekszosc-podwyzek-podatkow-nie-bylaby-potrzebna-8471517.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/d4a1e36106d5c4-948-568-0-190-1414-848.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Strajki pracowników kolei i brytyjskiej służby zdrowia czy znaczące podwyżki podatków na Wyspach mogłyby nigdy nie dojść do skutku, gdyby nie brexit - wyliczyli analitycy londyńskiego think tanku...</p>

## Koniec z nieuczciwymi praktykami podczas pokazów. UOKiK: Klienci nie będą z nich wychodzić z kredytami
 - [https://www.bankier.pl/wiadomosc/Koniec-z-nieuczciwymi-praktykami-podczas-pokazow-UOKiK-Klienci-nie-beda-z-nich-wychodzic-z-kredytami-8471511.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-z-nieuczciwymi-praktykami-podczas-pokazow-UOKiK-Klienci-nie-beda-z-nich-wychodzic-z-kredytami-8471511.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/cb731fb02e449a-948-568-0-175-1671-1002.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nadużycia związane ze sprzedażą na pokazach, wycieczkach lub podczas wizyt akwizytorów od lat stanowiły jeden z poważniejszych problemów rynku konsumenckiego. Tym bardziej że najczęściej ich ofiarą padały...</p>

## Zużycie gazu w Polsce w 2022 roku mocno spadło. "Nie ma ryzyka wprowadzenia ograniczeń"
 - [https://www.bankier.pl/wiadomosc/Zuzycie-gazu-w-Polsce-w-2022-roku-mocno-spadlo-Nie-ma-ryzyka-wprowadzenia-ograniczen-8471510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zuzycie-gazu-w-Polsce-w-2022-roku-mocno-spadlo-Nie-ma-ryzyka-wprowadzenia-ograniczen-8471510.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:32:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/e12ccca91e324b-948-568-0-168-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Według wstępnych szacunków zużycie gazu ziemnego w 2022 r. mogło spaść o ok. 16-17 proc. względem roku poprzedniego – przekazał PAP resort klimatu i środowiska. Podkreślono, że system jest przygotowany na najmroźniejszą zimę, a ryzyka wprowadzenia ograniczeń w poborze gazu na dziś nie ma.</p>

## Większość Polaków nie wierzy w spadek cen żywności w sklepach
 - [https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-nie-wierzy-w-spadek-cen-zywnosci-w-sklepach-8471507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiekszosc-Polakow-nie-wierzy-w-spadek-cen-zywnosci-w-sklepach-8471507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:17:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/c/afe54f07cf5262-948-568-0-230-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 63 proc. Polaków nie wierzy, że w tym roku dojdzie do spadku cen żywności w sklepach. Przeszło 36 proc. ankietowanych w ogóle nie uważa, aby możliwy był spadek cen kiedykolwiek - wynika z przekazanego PAP badania.</p>

## Nowojorskie pielęgniarki zakończyły strajk; dostaną podwyżki i lepsze warunki pracy
 - [https://www.bankier.pl/wiadomosc/Nowojorskie-pielegniarki-zakonczyly-strajk-dostana-podwyzki-i-lepsze-warunki-pracy-8471499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowojorskie-pielegniarki-zakonczyly-strajk-dostana-podwyzki-i-lepsze-warunki-pracy-8471499.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:05:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/55afd075dcc97d-948-568-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartek ponad siedem tysięcy pielęgniarek z dwóch dużych szpitali nowojorskich zakończyło strajk. Wstępne porozumienie z pracodawcami obejmuje m.in. podwyżkę płac i poprawę warunków pracy.</p>

## W Polsce też mamy Dolinę Krzemową
 - [https://www.bankier.pl/wiadomosc/Polska-Dolina-Krzemowa-Sprawdz-gdzie-sie-znajduje-8471312.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-Dolina-Krzemowa-Sprawdz-gdzie-sie-znajduje-8471312.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-13 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/7/815d8f84463b2f-948-568-2-0-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dolina
Krzemowa to zlokalizowane w Kalifornii, legendarne centrum amerykańskiego
sektora zaawansowanych technologii. Coraz częściej tym mianem nazywana
jest również stolica Dolnego Śląska. Potwierdzają to nie tylko międzynarodowe
rankingi, ale przede wszystkim przedsiębiorcy, którzy ulokowali tu swoje firmy.
</p>
