# Source Politico, Source URL:https://rss.politico.com/politics-news.xml, Source language: en-US

## The strategist who didn't believe in the red wave
 - [https://www.politico.com/news/2023/01/13/pbdd-01-13-2023-00077433](https://www.politico.com/news/2023/01/13/pbdd-01-13-2023-00077433)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-01-13 05:34:58+00:00
 - user: None

During the 2022 election cycle, when it was common to predict a red wave, there was one person who challenged that conventional wisdom.

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2023/01/13/the-nations-cartoonists-on-the-week-in-politics-00077813](https://www.politico.com/gallery/2023/01/13/the-nations-cartoonists-on-the-week-in-politics-00077813)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-01-13 04:30:00+00:00
 - user: None

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Matt Wuerker.
