# Source BBC tech, Source URL:http://feeds.bbci.co.uk/news/technology/rss.xml, Source language: en-US

## Winklevoss firm charged in US over crypto sales
 - [https://www.bbc.co.uk/news/technology-64265440?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64265440?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-13 16:52:31+00:00
 - user: None

Its partner company is also accused of illegal sales to hundreds of thousands of investors.

## Tesla cuts prices by up to a fifth to boost demand
 - [https://www.bbc.co.uk/news/business-64266471?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64266471?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-13 16:32:30+00:00
 - user: None

The electric car maker is reducing prices by thousands of pounds as global downturn threatens sales.

## Apple boss Tim Cook to have pay cut by over 40% this year
 - [https://www.bbc.co.uk/news/business-64258289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64258289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-13 04:23:04+00:00
 - user: None

The technology giant's chief executive Tim Cook has faced criticism from investors over his salary.

## India targets China's dominance in mobile phones
 - [https://www.bbc.co.uk/news/business-63806296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-63806296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-13 00:12:29+00:00
 - user: None

There's some way to go, but India hopes to build its own world-class mobile phone industry.
