# Source Forbs - innovation, Source URL:https://www.forbes.com/innovation/feed2, Source language: en-US

## The Worst Show On TV Is Finally Coming To An End
 - [https://www.forbes.com/sites/erikkain/2023/01/13/the-worst-show-on-tv-is-finally-coming-to-an-end/](https://www.forbes.com/sites/erikkain/2023/01/13/the-worst-show-on-tv-is-finally-coming-to-an-end/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 22:51:16+00:00
 - user: None

Fear The Walking Dead has been half-dead for years. AMC is finally putting it out of its misery.

## In The Aftermath Of Riots, Brazil Faces The Challenge Of Countering Online Radicalization
 - [https://www.forbes.com/sites/angelicamarideoliveira/2023/01/13/in-the-aftermath-of-riots-brazil-faces-the-challenge-of-countering-online-radicalization/](https://www.forbes.com/sites/angelicamarideoliveira/2023/01/13/in-the-aftermath-of-riots-brazil-faces-the-challenge-of-countering-online-radicalization/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 21:17:07+00:00
 - user: None

The events that included the trashing of key public buildings were a result of a long process - and shifting the current scenario requires a multifaceted approach, experts say

## The ‘Truth’ About Driving With Hazard Lights Flashing During Bad Weather
 - [https://www.forbes.com/sites/marshallshepherd/2023/01/13/the-truth-about-driving-with-hazard-lights-flashing-during-bad-weather/](https://www.forbes.com/sites/marshallshepherd/2023/01/13/the-truth-about-driving-with-hazard-lights-flashing-during-bad-weather/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 20:17:37+00:00
 - user: None

Most experts say you should not drive with your hazard lights flashing in bad weather (even if it is legal). Here's why.

## ‘Shot In The Arm’ Shows How Disinformation Can Be Deadly
 - [https://www.forbes.com/sites/lipiroy/2023/01/13/shot-in-the-arm-shows-how-disinformation-can-be-deadly/](https://www.forbes.com/sites/lipiroy/2023/01/13/shot-in-the-arm-shows-how-disinformation-can-be-deadly/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 20:12:34+00:00
 - user: None

Vaccine-preventable diseases like polio and measles are on the rise because more and more parents aren't vaccinating their kids. 'Shot in the Arm' clearly shows why disinformation itself is a disease.

## Tesla Owners Are Not Happy About Price Cuts: ‘Sobbing In The Fetal Position’
 - [https://www.forbes.com/sites/johnkoetsier/2023/01/13/tesla-owners-are-not-happy-about-price-cuts-sobbing-in-the-fetal-position/](https://www.forbes.com/sites/johnkoetsier/2023/01/13/tesla-owners-are-not-happy-about-price-cuts-sobbing-in-the-fetal-position/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:25:06+00:00
 - user: None

“$69k no-USS having MYP owner here,” says a recent Model Y Performance purchaser in a Reddit threat, who’s also bemoaning the fact that Tesla recently removed ultrasonic sensors (USS) in favor of vision-driven proximity alerts. “This is wack.”

## A Rocket Crashed In Alaska This Week And Images Are Starting To Come Out
 - [https://www.forbes.com/sites/ericmack/2023/01/13/a-rocket-crashed-in-alaska-this-week-and-images-are-starting-to-come-out/](https://www.forbes.com/sites/ericmack/2023/01/13/a-rocket-crashed-in-alaska-this-week-and-images-are-starting-to-come-out/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:19:16+00:00
 - user: None

Space startup ABL Space Systems and its RS1 rocket got off the ground for the first time on Monday, but quickly came back down to Earth.

## Out Of This World: The Crowdsourced Star Wars
 - [https://www.forbes.com/sites/petersuciu/2023/01/13/out-of-this-world-the-crowdsourced-star-wars/](https://www.forbes.com/sites/petersuciu/2023/01/13/out-of-this-world-the-crowdsourced-star-wars/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:17:56+00:00
 - user: None

More than a few of the entries proved to be worthy of a Jedi master (or at least Hollywood director), using various animation techniques, action figures, LEGO sets, and simple props to put a new twist on the beloved Hollywood classic.

## Successful Couples’ Counseling Starts With A Shift In These 4 Habits
 - [https://www.forbes.com/sites/traversmark/2023/01/13/successful-couples-counseling-starts-with-a-shift-in-these-4-habits/](https://www.forbes.com/sites/traversmark/2023/01/13/successful-couples-counseling-starts-with-a-shift-in-these-4-habits/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:15:51+00:00
 - user: None

Struggling to make your relationship work? Try developing these four habits.

## Emergence Of IgG4 In Long-Term Vaccines: Winning Or Losing The Race?
 - [https://www.forbes.com/sites/williamhaseltine/2023/01/13/emergence-of-igg4-in-long-term-vaccines-winning-or-losing-the-race/](https://www.forbes.com/sites/williamhaseltine/2023/01/13/emergence-of-igg4-in-long-term-vaccines-winning-or-losing-the-race/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:06:50+00:00
 - user: None

An uncommon type of antibody is on the rise after multiple vaccinations or infections. Here we discuss what this could mean.

## Apple Loop: iPhone 15 Pro Leaks, Mac Pro Disappointment, Apple’s Budget AirPods
 - [https://www.forbes.com/sites/ewanspence/2023/01/13/apple-news-iphone-15-pro-leak-mac-pro-design-airpods-lite/](https://www.forbes.com/sites/ewanspence/2023/01/13/apple-news-iphone-15-pro-leak-mac-pro-design-airpods-lite/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:04:46+00:00
 - user: None

This week’s Apple Loop includes the iPhone 15’s massive upgrade, the pricey iPhone 15 Pro, the cheaper AirPods Lite, Apple’s display ambitions, the mixed reality headset really is coming this year, Mac Pro disappointment, and more...

## Android Circuit: Honor Magic5 Lite Leaks, Nothing Phone (1) Reaches America, A Single Screen For Microsoft’s Duo
 - [https://www.forbes.com/sites/ewanspence/2023/01/13/android-news-samsung-galaxy-s23-honor-magic5-lite-nothing-phone1-microsoft-duo-asus-zenfone/](https://www.forbes.com/sites/ewanspence/2023/01/13/android-news-samsung-galaxy-s23-honor-magic5-lite-nothing-phone1-microsoft-duo-asus-zenfone/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 19:01:10+00:00
 - user: None

This week’s Android headlines; Galaxy S23 camera and color details, Pixel Fold delay, Honor Magic5 Lite leaks, Nothing Phone (1) reaches America, one screen for the next Duo, and more...

## Oil Pulling Has Gone Viral On TikTok—But Does It Make Your Teeth Brighter? We Asked The Experts
 - [https://www.forbes.com/sites/ariannajohnson/2023/01/13/oil-pulling-has-gone-viral-on-tiktok-but-does-it-make-your-teeth-brighter-we-asked-the-experts/](https://www.forbes.com/sites/ariannajohnson/2023/01/13/oil-pulling-has-gone-viral-on-tiktok-but-does-it-make-your-teeth-brighter-we-asked-the-experts/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 18:01:53+00:00
 - user: None

Oil pulling originated in Ancient India and has been practiced for thousands of years.

## Limited-Edition Mark Levinson Monoblock ML-50 Amplifiers Reach London
 - [https://www.forbes.com/sites/marksparrow/2023/01/13/limited-edition-mark-levinson-monoblock-ml-50-amplifiers-reach-london/](https://www.forbes.com/sites/marksparrow/2023/01/13/limited-edition-mark-levinson-monoblock-ml-50-amplifiers-reach-london/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 18:00:00+00:00
 - user: None

The new ML-50 Monoblock amplifiers have been made to celebrate Mark Levinson’s 50th anniversary. The run is limited to 100 units globally.

## Jamie Dimon Says Frank Acquisition ‘Was A Huge Mistake’ After JP Morgan Alleges Millions Of Fake Customers
 - [https://www.forbes.com/sites/iainmartin/2023/01/13/jamie-dimon-says-frank-acquisition-was-a-huge-mistake-after-jp-morgan-alleges-millions-of-fake-customers/](https://www.forbes.com/sites/iainmartin/2023/01/13/jamie-dimon-says-frank-acquisition-was-a-huge-mistake-after-jp-morgan-alleges-millions-of-fake-customers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 17:28:07+00:00
 - user: None

The Chase chief executive faced questions from analysts over the bank’s due diligence after it launched a fraud lawsuit against the founder of a student financial aid startup it acquired for $175 million.

## Three Sport And Entertainment Venues That Understand The Value Of Connectivity
 - [https://www.forbes.com/sites/moorinsights/2023/01/13/three-sport-and-entertainment-venues-that-understand-the-value-of-connectivity/](https://www.forbes.com/sites/moorinsights/2023/01/13/three-sport-and-entertainment-venues-that-understand-the-value-of-connectivity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 16:45:54+00:00
 - user: None

Vice President, Security, Carriers and Enterprise Networking, Will Townsend dives into the value of connectivity for enhancing the fan experience and improving operational efficiency at three sport and entertainment venues.

## Nvidia Continues Its Momentum With New Robotics, Gaming And Creator Announcements At CES 2023
 - [https://www.forbes.com/sites/patrickmoorhead/2023/01/13/nvidia-continues-its-momentum-with-new-robotics-gaming-and-creator-announcements-at-ces-2023/](https://www.forbes.com/sites/patrickmoorhead/2023/01/13/nvidia-continues-its-momentum-with-new-robotics-gaming-and-creator-announcements-at-ces-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 16:35:09+00:00
 - user: None

#1-Ranked Industry Analyst Patrick Moorhead gives his coverage of Nvidia's robotics, gaming and creator announcements at CES 2023.

## How To Follow Up Without Being Too Pushy
 - [https://www.forbes.com/sites/quora/2023/01/13/how-to-follow-up-without-being-too-pushy/](https://www.forbes.com/sites/quora/2023/01/13/how-to-follow-up-without-being-too-pushy/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 16:30:00+00:00
 - user: None

When networking, how can one follow up after making a contact without coming across as too pushy or intrusive? Answer by Mark Goulston, Co-Founder at Michelangelo Mindset.

## A Professor Deconstructs Our Attraction To Tyrannical Leaders
 - [https://www.forbes.com/sites/traversmark/2023/01/13/a-professor-deconstructs-our-attraction-to-tyrannical-leaders/](https://www.forbes.com/sites/traversmark/2023/01/13/a-professor-deconstructs-our-attraction-to-tyrannical-leaders/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:38:57+00:00
 - user: None

Research explains why this manipulative brand of leadership never seems to go away.

## What Is An Atmospheric River? Here’s Why California Is Getting Hammered With Them
 - [https://www.forbes.com/sites/brianbushard/2023/01/13/what-is-an-atmospheric-river-heres-why-california-is-getting-hammered-with-them/](https://www.forbes.com/sites/brianbushard/2023/01/13/what-is-an-atmospheric-river-heres-why-california-is-getting-hammered-with-them/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:24:18+00:00
 - user: None

California’s record rainfall in the past two weeks has been between 400% and 600% higher than average, according to the National Weather Service.

## Apple Watch Ultra 2: New Leak Hints At Dazzling Design Upgrade
 - [https://www.forbes.com/sites/davidphelan/2023/01/13/apple-watch-ultra-2-new-leak-hints-at-dazzling-design-upgrade/](https://www.forbes.com/sites/davidphelan/2023/01/13/apple-watch-ultra-2-new-leak-hints-at-dazzling-design-upgrade/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:21:05+00:00
 - user: None

The display on the Apple Watch is going to change radically, it seems. Here’s why I think a new report must point to Apple Watch Ultra 2.

## How To Evolve Into A 'Product-Led' Organization
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-to-evolve-into-a-product-led-organization/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-to-evolve-into-a-product-led-organization/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:15:00+00:00
 - user: None

The transformation to product-led growth requires a change not just in R&amp;D teams but across the full company—sales, customer experience, partnerships, marketing and more.

## At CES, A Tractor And A Patient Stethoscope Point To Digital Health Future
 - [https://www.forbes.com/sites/michaelmillenson/2023/01/13/at-ces-a-tractor-and-a-patient-stethoscope-point-to-digital-health-future/](https://www.forbes.com/sites/michaelmillenson/2023/01/13/at-ces-a-tractor-and-a-patient-stethoscope-point-to-digital-health-future/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:00:00+00:00
 - user: None

Deere’s “smart machines” incorporate computer vision, soil moisture sensing, GPS with precise signal correction, machine learning and cloud computing...In health care terms, that adds up to personalized, evidence-based farming.

## Should You Go Back To The Office?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/should-you-go-back-to-the-office/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/should-you-go-back-to-the-office/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 15:00:00+00:00
 - user: None

Before rushing into a decision, take some time to consider: Will a remote, in-office or hybrid work model make the most sense for your team? And once you decide, how will you prepare for it?

## Tennis Participation Surges For Third Year In A Row, Up 33% Since 2020
 - [https://www.forbes.com/sites/brucelee/2023/01/13/tennis-participation-surges-for-third-year-in-row-up-33-since-2020/](https://www.forbes.com/sites/brucelee/2023/01/13/tennis-participation-surges-for-third-year-in-row-up-33-since-2020/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:58:54+00:00
 - user: None

Last year, U.S. tennis participation bounced up further by one million players with more than 23.6 million people playing the sport.

## Google And NVIDIA Join Sony To Complain About Microsoft’s Activision Deal
 - [https://www.forbes.com/sites/paultassi/2023/01/13/google-and-nvidia-join-sony-to-complain-about-microsofts-activision-deal/](https://www.forbes.com/sites/paultassi/2023/01/13/google-and-nvidia-join-sony-to-complain-about-microsofts-activision-deal/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:55:14+00:00
 - user: None

The longer this goes, the less I’m sure this Microsoft Activision acquisition may actually happen.

## Book A Last Minute Flight? You’re More Likely To Be Searched By The Feds
 - [https://www.forbes.com/sites/thomasbrewster/2023/01/13/last-minute-quick-return-flights-make-you-a-person-of-interest-to-us-government-surveillance/](https://www.forbes.com/sites/thomasbrewster/2023/01/13/last-minute-quick-return-flights-make-you-a-person-of-interest-to-us-government-surveillance/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:52:22+00:00
 - user: None

Newly-unsealed documents obtained by Forbes reveal American law enforcement has deep access to people’s travel records and how it uses that data to conduct targeted surveillance.

## Empowering The Workplace Of The Future With AR
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/empowering-the-workplace-of-the-future-with-ar/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/empowering-the-workplace-of-the-future-with-ar/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:45:00+00:00
 - user: None

No matter where you are in your digital journey, whether it’s implementing AR or launching your first app, always remember to have your goal in mind.

## HBO Max, After A Slew Of Cancelations And Removals, Is Raising Prices
 - [https://www.forbes.com/sites/paultassi/2023/01/13/hbo-max-after-a-slew-of-cancelations-and-removals-is-raising-prices/](https://www.forbes.com/sites/paultassi/2023/01/13/hbo-max-after-a-slew-of-cancelations-and-removals-is-raising-prices/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:40:18+00:00
 - user: None

Here's how much HBO Max prices are going up, as of right now.

## Bolt Holds Firm On UK Driver Model But Rivals And Critics Voice Discontent
 - [https://www.forbes.com/sites/jonathankeane/2023/01/13/bolt-holds-firm-on-uk-driver-model-but-rivals-and-critics-voice-discontent/](https://www.forbes.com/sites/jonathankeane/2023/01/13/bolt-holds-firm-on-uk-driver-model-but-rivals-and-critics-voice-discontent/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:30:14+00:00
 - user: None

Uber and a drivers' union have called on the company to provide benefits to its drivers.

## Buttoning Up On The Basics: BEC Is A Simple Yet Precarious Attack Method
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/buttoning-up-on-the-basics-bec-is-a-simple-yet-precarious-attack-method/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/buttoning-up-on-the-basics-bec-is-a-simple-yet-precarious-attack-method/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:30:00+00:00
 - user: None

It’s important to understand what BEC is and what makes it such a dangerous threat to your organization’s security.

## A ‘Marvel Snap’ Sera Surfer Zabu Deck For The Climb To Infinite
 - [https://www.forbes.com/sites/paultassi/2023/01/13/a-marvel-snap-sera-surfer-zabu-deck-for-the-climb-to-infinite/](https://www.forbes.com/sites/paultassi/2023/01/13/a-marvel-snap-sera-surfer-zabu-deck-for-the-climb-to-infinite/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:23:15+00:00
 - user: None

A normal Marvel Snap deck will have Silver Surfer buffing a whole host of 3 drop cards on your last turn, and while that’s always a great play, the addition of Zabu, a 3 drop himself, and two four drops he can reduce, Wong and Enchantress, has made this deck an absolute monster for me.

## Advanced Microchip Production Relies On Taiwan
 - [https://www.forbes.com/sites/katharinabuchholz/2023/01/13/advanced-microchip-production-relies-on-taiwan/](https://www.forbes.com/sites/katharinabuchholz/2023/01/13/advanced-microchip-production-relies-on-taiwan/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:19:23+00:00
 - user: None

The production of semiconductor slices for the most advanced types of computing and processing microchips is highly concentrated in one place: Taiwan. With innovative tech dependent on the island, rising tensions with China are making some governments uneasy. Yet, change is a long way off.

## EV-Nomics: Why EVs Can Be A Retailer’s New Financial Lifeline
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/ev-nomics-why-evs-can-be-a-retailers-new-financial-lifeline/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/ev-nomics-why-evs-can-be-a-retailers-new-financial-lifeline/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:15:00+00:00
 - user: None

As automotive manufacturers look to massively ramp up EV production, EV charging presents a key business opportunity for retailers.

## Irrigating America's Driest Digital Desert
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/irrigating-americas-driest-digital-desert/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/irrigating-americas-driest-digital-desert/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

Ironically, the place in our society that for decades was the most overlooked, underserviced and vulnerable technology desert of all—correctional facilities—offers more than a clue about how we might leverage technology effectively in our country.

## UnitedHealth Group Reports $4.7 Billion Profit As Optum And Health Plans Maintain Momentum
 - [https://www.forbes.com/sites/brucejapsen/2023/01/13/unitedhealth-group-reports-47-billion-profit-as-optum-and-health-plans-maintain-momentum/](https://www.forbes.com/sites/brucejapsen/2023/01/13/unitedhealth-group-reports-47-billion-profit-as-optum-and-health-plans-maintain-momentum/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:58:25+00:00
 - user: None

UnitedHealth Group’s profits eclipsed $4.76 billion in the fourth quarter as the healthcare giant’s UnitedHealthcare insurance plans and Optum health services maintained growth.

## HBO Max’s ‘Velma’ Is Getting Absolutely Savaged In Reviews And Online
 - [https://www.forbes.com/sites/paultassi/2023/01/13/hbo-maxs-velma-is-getting-absolutely-savaged-in-reviews-and-online/](https://www.forbes.com/sites/paultassi/2023/01/13/hbo-maxs-velma-is-getting-absolutely-savaged-in-reviews-and-online/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:54:19+00:00
 - user: None

Velma always seemed like a bit of an odd experiment, a re-imagining of Scooby Doo in adult animation format where the danger is real and the jokes are more crass.

## Predictions For 2023: Innovation, Core Values And Security
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/predictions-for-2023-innovation-core-values-and-security/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/predictions-for-2023-innovation-core-values-and-security/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:45:00+00:00
 - user: None

When I consider my predictions for 2023, they fall into four main categories: increased innovation, increased responsiveness to economic stressors, increased attention to core corporate values and increased demand for better security.

## ‘Destiny 2’ Wants Feedback To Start 2023, So Here’s Mine
 - [https://www.forbes.com/sites/paultassi/2023/01/13/destiny-2-wants-feedback-to-start-2023-so-heres-mine/](https://www.forbes.com/sites/paultassi/2023/01/13/destiny-2-wants-feedback-to-start-2023-so-heres-mine/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:38:07+00:00
 - user: None

It’s a brand new year for Destiny 2, even though technically, the new “year” for the game will start with Lightfall, out at the end of February. But community manager Cozmo is asking players for feedback via this reddit thread, both short and long term asks, along with smaller, Quality of Life chan

## Data Science And Investigative Journalism: Two Fields, One Goal, Similar Mindset
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/data-science-and-investigative-journalism-two-fields-one-goal-similar-mindset/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/data-science-and-investigative-journalism-two-fields-one-goal-similar-mindset/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:30:00+00:00
 - user: None

Detective journalists work with data all the time, and good investigative pieces are renowned for their thoroughness and work hygiene—qualities that are equally desirable for top-notch data science.

## Security Tokens Provide New Efficiency To Previously Paper-Based Transactions
 - [https://www.forbes.com/sites/waynerash/2023/01/13/security-tokens-provide-new-efficiency-to-previously-paper-based-transactions/](https://www.forbes.com/sites/waynerash/2023/01/13/security-tokens-provide-new-efficiency-to-previously-paper-based-transactions/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:30:00+00:00
 - user: None

Smart contract technology is transforming the securities business.

## Scientists Describe The Largest Fossil Flower Discovered So Far In Amber
 - [https://www.forbes.com/sites/davidbressan/2023/01/13/scientists-describe-the-largest-fossil-flower-discovered-so-far-in-amber/](https://www.forbes.com/sites/davidbressan/2023/01/13/scientists-describe-the-largest-fossil-flower-discovered-so-far-in-amber/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:25:26+00:00
 - user: None

A new species of fossil flower is nearly three times the size of other fossil flowers preserved in amber.

## 15 Ways Retailers Leverage AI That Every Consumer Should Know About
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/15-ways-retailers-leverage-ai-that-every-consumer-should-know-about/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/15-ways-retailers-leverage-ai-that-every-consumer-should-know-about/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:15:00+00:00
 - user: None

Retailers are using AI for far more than sending out email promotions or displaying timely online ads.

## Four Ways To Spark Employee Creativity
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/four-ways-to-spark-employee-creativity/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/four-ways-to-spark-employee-creativity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:15:00+00:00
 - user: None

Like many things in business and in life, it’s a balance. Striking the right one changes everything and will make your company a creative force to be reckoned with.

## U.K. Government’s Net Zero Review Claims Car-Shaped Electric Cars Reduce Congestion
 - [https://www.forbes.com/sites/carltonreid/2023/01/13/uk-governments-net-zero-review-claims-electric-cars-reduce-congestion/](https://www.forbes.com/sites/carltonreid/2023/01/13/uk-governments-net-zero-review-claims-electric-cars-reduce-congestion/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:04:08+00:00
 - user: None

Electric cars are heavier than gasoline-fuelled cars but tend to be the same shape.

## Planes Fly On Modern IT, Not Green Dreams
 - [https://www.forbes.com/sites/dianafurchtgott-roth/2023/01/13/planes-fly-on-modern-it-not-green-dreams/](https://www.forbes.com/sites/dianafurchtgott-roth/2023/01/13/planes-fly-on-modern-it-not-green-dreams/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:00:25+00:00
 - user: None

Modern equipment requires modern backup systems, and that requires investment in new technology.

## Dear Netflix: Give Your Cancelled Shows The Final Seasons They Deserve And Everybody Wins
 - [https://www.forbes.com/sites/erikkain/2023/01/13/dear-netflix-give-your-cancelled-shows-the-final-seasons-they-deserve-and-everybody-wins/](https://www.forbes.com/sites/erikkain/2023/01/13/dear-netflix-give-your-cancelled-shows-the-final-seasons-they-deserve-and-everybody-wins/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:00:00+00:00
 - user: None

Killing shows off before they have a chance to wrap up is bad for Netflix subscribers, but it's also bad for Netflix shareholders and Netflix as a business. It's time for a better way.

## Explainable AI: The Importance Of Adding Interpretability Into Machine Learning
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/explainable-ai-the-importance-of-adding-interpretability-into-machine-learning/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/explainable-ai-the-importance-of-adding-interpretability-into-machine-learning/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:00:00+00:00
 - user: None

The growing trend of AI means that it’s business-critical to understand how AI-enabled systems arrive at specific outputs.

## What You Need To Know About The ‘Rocket League’ Championship Series Winter Split
 - [https://www.forbes.com/sites/maxthielmeyer/2023/01/13/what-you-need-to-know-about-the-rocket-league-championship-series-winter-split/](https://www.forbes.com/sites/maxthielmeyer/2023/01/13/what-you-need-to-know-about-the-rocket-league-championship-series-winter-split/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 13:00:00+00:00
 - user: None

With the Winter Split comes a new tournament format, three online regional competitions, and the Winter Major LAN tournament.

## If Technology Doesn’t Empower Research Sites, It Risks Slowing Down Clinical Trials
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/if-technology-doesnt-empower-research-sites-it-risks-slowing-down-clinical-trials/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/if-technology-doesnt-empower-research-sites-it-risks-slowing-down-clinical-trials/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:45:00+00:00
 - user: None

Here’s how the tech industry can build site enablement platforms that address researchers’ needs.

## AI Remix: Generative AI Is Incredible—And A Con
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/ai-remix-generative-ai-is-incredible-and-a-con/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/ai-remix-generative-ai-is-incredible-and-a-con/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:30:00+00:00
 - user: None

It’s not that these systems are "aware" or even close to independent conscious thought. It’s that humans are quite predictable, which, in turn, allows generative AI platforms to present an extremely credible imitation.

## Will The Government Set Price Controls For Covid-19 Vaccines?
 - [https://www.forbes.com/sites/johnlamattina/2023/01/13/will-the-government-set-price-controls-for-covid-19-vaccines/](https://www.forbes.com/sites/johnlamattina/2023/01/13/will-the-government-set-price-controls-for-covid-19-vaccines/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:22:15+00:00
 - user: None

With the government no longer in the Covid-19 business, payment for these vaccines has now been passed on to insurers as happens with all vaccines.

## How Outsourcing Helps Tech Businesses Thrive In Times Of Economic Uncertainty
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-outsourcing-helps-tech-businesses-thrive-in-times-of-economic-uncertainty/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-outsourcing-helps-tech-businesses-thrive-in-times-of-economic-uncertainty/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:15:00+00:00
 - user: None

While adding something new to the budget may seem counterintuitive in turbulent economic times, it’s imperative that leaders take a step back and consider the big picture.

## How Small Businesses Can Continue Being Resilient, Optimistic And Determined
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-small-businesses-can-continue-being-resilient-optimistic-and-determined/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-small-businesses-can-continue-being-resilient-optimistic-and-determined/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

The current global crises and economic conditions are real and will undoubtedly impact how SMBs operate.

## Review: Cleer Scene Is A Bluetooth Speaker To Challenge JBL’s Charge
 - [https://www.forbes.com/sites/marksparrow/2023/01/13/review-cleer-scene-is-a-bluetooth-speaker-to-challenge-jbls-charge/](https://www.forbes.com/sites/marksparrow/2023/01/13/review-cleer-scene-is-a-bluetooth-speaker-to-challenge-jbls-charge/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

Cleer makes great headphones and earbuds. Now the San Diego-based company has turned its attention to speakers with the launch of its Scene Bluetooth speaker which even includes a speakerphone function.

## Replacing Wood Stoves Could Save $66 Billion In Healthcare Costs Annually
 - [https://www.forbes.com/sites/anuradhavaranasi/2023/01/13/replacing-wood-stoves-could-save-66-billion-in-healthcare-costs-annually/](https://www.forbes.com/sites/anuradhavaranasi/2023/01/13/replacing-wood-stoves-could-save-66-billion-in-healthcare-costs-annually/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:51:38+00:00
 - user: None

Implementing adequate policies to replace wood and charcoal burning stoves could prevent at least 463,000 deaths and $66 billion in healthcare costs yearly in sub-Saharan Africa, according to a recent study published in the journal Nature Sustainability.

## Accelerate Speed Of Data And AI-Driven Business Value With Time Series Technology
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/accelerate-speed-of-data-and-ai-driven-business-value-with-time-series-technology/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/accelerate-speed-of-data-and-ai-driven-business-value-with-time-series-technology/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:45:00+00:00
 - user: None

Remember, you can’t store time nor get more of it.

## Identities: The New Enterprise Perimeter
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/identities-the-new-enterprise-perimeter/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/identities-the-new-enterprise-perimeter/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:30:00+00:00
 - user: None

This explosion of SaaS adoption led to unprecedented identity sprawl with some employees creating hundreds of SaaS accounts over the time.

## Universal Audio Reveals Microphones That Emulate Classic Models In Post Production
 - [https://www.forbes.com/sites/marksparrow/2023/01/13/universal-audio-reveals-microphones-that-emulate-classic-models-in-post-production/](https://www.forbes.com/sites/marksparrow/2023/01/13/universal-audio-reveals-microphones-that-emulate-classic-models-in-post-production/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:24:21+00:00
 - user: None

Imagine a single microphone that can be shaped and customised to sound like up to 38 classic microphones, even after you've recorded a song or a voiceover. The DLX and LX models from Universal Audio are incredibly versatile mics with multiple personalities.

## How Technology Is Working To Improve Food Safety And Combat Food Insecurity
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-technology-is-working-to-improve-food-safety-and-combat-food-insecurity/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/how-technology-is-working-to-improve-food-safety-and-combat-food-insecurity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:15:00+00:00
 - user: None

If we could extend the shelf life of fresh food, we could make progress toward an overall solution to food waste.

## U.K. Set To Switch Off Fax Machines
 - [https://www.forbes.com/sites/barrycollins/2023/01/13/uk-set-to-switch-off-fax-machines/](https://www.forbes.com/sites/barrycollins/2023/01/13/uk-set-to-switch-off-fax-machines/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:07:13+00:00
 - user: None

Fax machines will soon beep their last beep in the U.K., after parliament votes to cut off support for them

## Worried About GPT? You Should Be. Here’s Why:
 - [https://www.forbes.com/sites/charlesradclyffe/2023/01/13/worried-about-gpt-you-should-be-heres-why/](https://www.forbes.com/sites/charlesradclyffe/2023/01/13/worried-about-gpt-you-should-be-heres-why/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:03:24+00:00
 - user: None

Is GPT evil or does it mark a pivotal moment in human history? This story should settle the issue once and for all.

## The Economic Forecast Is Cloudy: Three Steps To Clear Things Up
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/13/the-economic-forecast-is-cloudy-three-steps-to-clear-things-up/](https://www.forbes.com/sites/forbestechcouncil/2023/01/13/the-economic-forecast-is-cloudy-three-steps-to-clear-things-up/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 11:00:00+00:00
 - user: None

Having a road map and the right tools is essential to a safe, confident journey into the unknowns of 2023.

## Introducing The Most Baffling ‘Resident Evil’ Merch, Yours For $215
 - [https://www.forbes.com/sites/mattgardner1/2023/01/13/introducing-the-most-baffling-resident-evil-merchandise-yours-for-215/](https://www.forbes.com/sites/mattgardner1/2023/01/13/introducing-the-most-baffling-resident-evil-merchandise-yours-for-215/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 10:45:00+00:00
 - user: None

You too can soon own a piece of ‘Resident Evil’ merchandise you didn’t know you didn’t need.

## Garmin Forerunner 265 May Get Feature Apple Watch Has Had For 4 Years
 - [https://www.forbes.com/sites/andrewwilliams/2023/01/13/garmin-forerunner-265-may-get-feature-apple-watch-has-had-for-4-years/](https://www.forbes.com/sites/andrewwilliams/2023/01/13/garmin-forerunner-265-may-get-feature-apple-watch-has-had-for-4-years/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 10:13:59+00:00
 - user: None

The next batch of Garmin watches may have an ECG heart health sensor including the Forerunner 265 and Forerunner 265s.

## Rishi Sunak Faces Rebellion Over Accountability Of Tech Executives
 - [https://www.forbes.com/sites/emmawoollacott/2023/01/13/rishi-sunak-faces-rebellion-over-accountability-of-tech-executives/](https://www.forbes.com/sites/emmawoollacott/2023/01/13/rishi-sunak-faces-rebellion-over-accountability-of-tech-executives/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 09:53:47+00:00
 - user: None

UK prime minister Rishi Sunak is facing a major rebellion over the Online Safety Bill, with 36 Conservative MPs calling for social media bosses to be jailed if their platforms publish harmful content.

## Web3 Gets Real: Trends & Strategies Shaping The Luxury Retail Roadmap For 2023
 - [https://www.forbes.com/sites/stephaniehirschmiller/2023/01/13/web3-gets-real-luxury-retail-trends-in-2023/](https://www.forbes.com/sites/stephaniehirschmiller/2023/01/13/web3-gets-real-luxury-retail-trends-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 09:38:58+00:00
 - user: None

It all starts with the product says Arianee CEO Pierre-Nicolas.

## Are The Proposed EPA Air Quality Standards Strong Enough To Tackle Pollution?
 - [https://www.forbes.com/sites/jamiehailstone/2023/01/13/are-the-proposed-epa-air-quality-standards-strong-enough-to-tackle-pollution/](https://www.forbes.com/sites/jamiehailstone/2023/01/13/are-the-proposed-epa-air-quality-standards-strong-enough-to-tackle-pollution/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 09:20:28+00:00
 - user: None

The American Lung Association’s national senior vice president, Paul Billings said it was “really disappointed” with the proposed new standards.

## Why Blockchain, NFTs, And Web3 Have A Sustainability Problem
 - [https://www.forbes.com/sites/bernardmarr/2023/01/13/why-blockchain-nfts-and-web3-have-a-sustainability-problem/](https://www.forbes.com/sites/bernardmarr/2023/01/13/why-blockchain-nfts-and-web3-have-a-sustainability-problem/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 07:06:19+00:00
 - user: None

Blockchain technology has a reputation for consuming an enormous amount of energy. What can be done to address sustainability issues around blockchain, NFTs, and Web3 technologies?

## ‘Political Choices’ Behind England’s Healthcare Crisis, Think Tanks Say
 - [https://www.forbes.com/sites/katherinehignett/2023/01/13/political-choices-behind-englands-healthcare-crisis-think-tanks-say/](https://www.forbes.com/sites/katherinehignett/2023/01/13/political-choices-behind-englands-healthcare-crisis-think-tanks-say/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 06:26:05+00:00
 - user: None

Experts from two think tanks blame “political choices” and “underinvestment” for the crisis currently engulfing England’s public health system.

## Lisa Marie Presley, 54, Dies After Sudden Cardiac Arrest
 - [https://www.forbes.com/sites/brucelee/2023/01/13/lisa-marie-presley-54-dies-after-sudden-cardiac-arrest/](https://www.forbes.com/sites/brucelee/2023/01/13/lisa-marie-presley-54-dies-after-sudden-cardiac-arrest/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 06:05:37+00:00
 - user: None

And surprise, surprise, anti-Covid-19 vaccination claims with no real evidence soon followed.

## Why Water-Cooled SMRs Will Win The New Nuclear Competition
 - [https://www.forbes.com/sites/jeffmcmahon/2023/01/13/why-water-cooled-smrs-will-win-the-new-nuclear-competition/](https://www.forbes.com/sites/jeffmcmahon/2023/01/13/why-water-cooled-smrs-will-win-the-new-nuclear-competition/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 05:00:00+00:00
 - user: None

Nuclear power’s future—if it has a future—will likely be both small and water cooled, according to an expert with global credentials in nuclear research.

## Today’s Wordle #573 Hints, Clues And Answer For Friday, January 13th
 - [https://www.forbes.com/sites/erikkain/2023/01/12/todays-wordle-573-hints-clues-and-answer-for-friday-january-13th/](https://www.forbes.com/sites/erikkain/2023/01/12/todays-wordle-573-hints-clues-and-answer-for-friday-january-13th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 03:30:31+00:00
 - user: None

How to solve today's Wordle.

## The Worst Show On TV Is Finally Coming To An End
 - [https://www.forbes.com/sites/erikkain/2023/01/12/the-worst-show-on-tv-is-finally-coming-to-an-end/](https://www.forbes.com/sites/erikkain/2023/01/12/the-worst-show-on-tv-is-finally-coming-to-an-end/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 02:44:21+00:00
 - user: None

Fear The Walking Dead has been half-dead for years. AMC is finally putting it out of its misery.

## This Week In XR: CES Redux, Nreal Air Surging, BCI To Treat Depression
 - [https://www.forbes.com/sites/charliefink/2023/01/12/this-week-in-xr-ces-redux-nreal-air-surging-bci-to-treat-depression/](https://www.forbes.com/sites/charliefink/2023/01/12/this-week-in-xr-ces-redux-nreal-air-surging-bci-to-treat-depression/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 01:51:11+00:00
 - user: None

Say hello to the second screen.

## Today’s ‘Heardle’ Answer And Clues For Friday, January 13
 - [https://www.forbes.com/sites/krisholt/2023/01/12/todays-heardle-answer-and-clues-for-friday-january-13/](https://www.forbes.com/sites/krisholt/2023/01/12/todays-heardle-answer-and-clues-for-friday-january-13/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 01:15:41+00:00
 - user: None

Here's today's 'Heardle' song, along with some hints.

## Today’s ‘Quordle’ Answers And Clues For Friday, January 13
 - [https://www.forbes.com/sites/krisholt/2023/01/12/todays-quordle-answers-and-clues-for-friday-january-13/](https://www.forbes.com/sites/krisholt/2023/01/12/todays-quordle-answers-and-clues-for-friday-january-13/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 01:00:57+00:00
 - user: None

Some hints and the solution for today's 'Quordle' are just ahead.

## What’s The Brightest Star In The Night Sky? How To Find The ‘Rainbow Star’ With Your Naked Eyes
 - [https://www.forbes.com/sites/jamiecartereurope/2023/01/12/whats-the-brightest-star-in-the-night-sky-how-to-find-the-dog-star-with-your-naked-eyes/](https://www.forbes.com/sites/jamiecartereurope/2023/01/12/whats-the-brightest-star-in-the-night-sky-how-to-find-the-dog-star-with-your-naked-eyes/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-13 01:00:00+00:00
 - user: None

The brightest star in the night sky is Sirius, also known as the "Dog Star." Here's when, where and how to see it—and glimpse its rainbow of colors.
