# Source URL:https://jellyfin.org, Source language: en

## The Free Software Media System | Jellyfin
 - [https://jellyfin.org](https://jellyfin.org)
 - RSS feed: https://jellyfin.org
 - date published: 2023-01-13 12:53:50+00:00
 - user: rumpel
 - tags: jellyfin,digital bunker,smarthome

The Free Software Media System | Jellyfin
