# Source TVN24 Z kraju, Source URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, Source language: pl-PL

## Budka: Opozycja musiała powiedzieć "sprawdzam". Wymiar sprawiedliwości naprawimy po wygranych wyborach
 - [https://tvn24.pl/polska/ustawa-o-sadownictwie-a-wyplata-pieniedzy-z-kpo-borys-budka-opozycja-musiala-powiedziec-sprawdzam-6628749?source=rss](https://tvn24.pl/polska/ustawa-o-sadownictwie-a-wyplata-pieniedzy-z-kpo-borys-budka-opozycja-musiala-powiedziec-sprawdzam-6628749?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 19:17:33+00:00
 - user: None

<img alt="Budka: Opozycja musiała powiedzieć " src="https://tvn24.pl/najnowsze/cdn-zdjecie-44480r-13-1930-fpf-cl-0026-6628732/alternates/LANDSCAPE_1280" />
    Gdyby ustawa o sądownictwie została zablokowana, to premier Mateusz Morawiecki mógłby dalej mówić, że miał wszystko gotowe do odblokowania środków z KPO, ale niestety opozycja totalna zablokowała pieniądze dla Polski. Mówimy sprawdzam. Wymiar sprawiedliwości naprawimy po wygranych wyborach - powiedział w "Faktach po Faktach" szef klubu Koalicji Obywatelskiej Borys Budka.

## W sobotę wyłączą ruch tramwajów na dwóch ulicach
 - [https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-w-sobote-tramwaje-nie-pojada-jagiellonska-i-ratuszowa-6627414?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/warszawa-w-sobote-tramwaje-nie-pojada-jagiellonska-i-ratuszowa-6627414?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 19:14:18+00:00
 - user: None

<img alt="W sobotę wyłączą ruch tramwajów na dwóch ulicach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vka573-w-sobote-tramwaje-nie-pojada-jagiellonska-i-ratuszowa-zdj-ilustracyjne-6627408/alternates/LANDSCAPE_1280" />
    W sobotę, 14 stycznia wyłączony zostanie ruch tramwajów na Jagiellońskiej i Ratuszowej, między rondem Starzyńskiego a 11 listopada. Linie numer 6, 20 i 28 pojadą objazdami. Zarząd Transportu Miejskiego poinformował, że tymczasowe zmiany są związane z prowadzeniem prac pielęgnacyjnych w Parku Praskim.

## Pogoda na jutro - sobota 14.01. W nocy deszcz, w dzień pogodniej, do 8 stopni na termometrach
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-1401-w-nocy-deszcz-w-dzien-pogodniej-do-8-stopni-na-termometrach-6628651?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-1401-w-nocy-deszcz-w-dzien-pogodniej-do-8-stopni-na-termometrach-6628651?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 18:40:22+00:00
 - user: None

<img alt="Pogoda na jutro - sobota 14.01. W nocy deszcz, w dzień pogodniej, do 8 stopni na termometrach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fiyn55-noc-deszcz-opady-deszczu-6628653/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli sobotę 14.01. W nocy towarzyszyć nam będzie pochmurna, w prawie całym kraju deszczowa aura. Sobota okaże się nieco łaskawsza - niebo ma się przejaśniać, a strefa opadów odsunie się prawie znad całego kraju. W ciągu dnia towarzyszyć nam będą neutralne warunki biometeorologiczne.

## Duży pożar drewnianego domu w Milanówku
 - [https://tvn24.pl/tvnwarszawa/okolice/milanowek-duzy-pozar-drewnianego-domu-6628690?source=rss](https://tvn24.pl/tvnwarszawa/okolice/milanowek-duzy-pozar-drewnianego-domu-6628690?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 18:34:12+00:00
 - user: None

<img alt="Duży pożar drewnianego domu w Milanówku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bhlnr0-pozar-domu-w-milanowku-6628686/alternates/LANDSCAPE_1280" />
    W Milanówku wybuchł pożar drewnianego domu. Ogień objął cały budynek. Jak podaje straż pożarna, dwoje mieszkańców zdążyło ewakuować się jeszcze przed przybyciem służb ratunkowych.

## Cejrowski o zapaleniu mięśnia sercowego po szczepieniach przeciw COVID-19. Sprawdzamy
 - [https://konkret24.tvn24.pl/zdrowie/covid-19-cejrowski-udostepnia-wprowadzajace-w-blad-statystyki-6626922?source=rss](https://konkret24.tvn24.pl/zdrowie/covid-19-cejrowski-udostepnia-wprowadzajace-w-blad-statystyki-6626922?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 17:15:00+00:00
 - user: None

<img alt="Cejrowski o zapaleniu mięśnia sercowego po szczepieniach przeciw COVID-19. Sprawdzamy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a5y16o-falsz-16-6627979/alternates/LANDSCAPE_1280" />
    Wojciech Cejrowski podaje dalej nagranie z lekarzem, który stwierdza, że liczba przypadków zapalenia mięśnia sercowego radykalnie wzrosła  u osób zaszczepionych na COVID-19, w stosunku do okresu sprzed pandemii. Lekarz wielokrotnie dezinformował już na temat pandemii i szczepionek. Pokazujemy też, dlaczego nie należy zestawiać przytoczonych przez niego badań.

## Miał ponad 2,5 promila i jechał autobusem "wężykiem". Policji tłumaczył, że "stało się"
 - [https://tvn24.pl/lodz/sieradz-wandalin-mial-ponad-25-promila-i-jechal-autobusem-wezykiem-policji-tlumaczyl-ze-stalo-sie-6628386?source=rss](https://tvn24.pl/lodz/sieradz-wandalin-mial-ponad-25-promila-i-jechal-autobusem-wezykiem-policji-tlumaczyl-ze-stalo-sie-6628386?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 17:10:29+00:00
 - user: None

<img alt="Miał ponad 2,5 promila i jechał autobusem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ghkya5-jechal-autobusem-mial-ponad-25-promila-alkoholu-w-organizmie-6628208/alternates/LANDSCAPE_1280" />
    Ponad 2,5 promila alkoholu w organizmie miał kierowca autobusu z okolic Sieradza (Łódzkie). O tym, że 50-latek może prowadzić pojazd na "podwójnym gazie", policjantów poinformował świadek, który zauważył, że autobus jechał "wężykiem". Kierowcy grozi kara do dwóch lat więzienia, utrata uprawień i wysoka grzywna.

## 16-latek ukradł auto z garażu dziadków. Później z kolegami uciekał przed policją
 - [https://tvn24.pl/poznan/sroda-wielkopolska-16-latek-ukradl-auto-z-garazu-dziadkow-pozniej-z-kolegami-uciekal-przed-policja-6628505?source=rss](https://tvn24.pl/poznan/sroda-wielkopolska-16-latek-ukradl-auto-z-garazu-dziadkow-pozniej-z-kolegami-uciekal-przed-policja-6628505?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 16:52:41+00:00
 - user: None

<img alt="16-latek ukradł auto z garażu dziadków. Później z kolegami uciekał przed policją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qikqv2-samochod-16-latek-ukradl-dziadkom-6628506/alternates/LANDSCAPE_1280" />
    Uciekali przed policją, auto porzucili, a sami próbowali ukryć się pod betonowym płotem. Jak się okazało, samochodem po Środzie Wielkopolskiej jechała grupa nastolatków. Pojazd - jak informuje policja - 16-latek ukradł z garażu swoich dziadków.

## Gmina Michałowo laureatem drugiej edycji Nagrody im. Prezydenta Pawła Adamowicza
 - [https://tvn24.pl/bialystok/gmina-michalowo-z-nagroda-im-prezydenta-pawla-adamowicza-wiceburmistrz-nagroda-dla-wszystkich-mieszkancow-6628476?source=rss](https://tvn24.pl/bialystok/gmina-michalowo-z-nagroda-im-prezydenta-pawla-adamowicza-wiceburmistrz-nagroda-dla-wszystkich-mieszkancow-6628476?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 16:51:11+00:00
 - user: None

<img alt="Gmina Michałowo laureatem drugiej edycji Nagrody im. Prezydenta Pawła Adamowicza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4bs32p-13-1249-lvu-gdansk120230113105250-0011-6628587/alternates/LANDSCAPE_1280" />
    Gmina Michałowo (Podlaskie) została laureatem II edycji Nagrody im. Prezydenta Pawła Adamowicza. - To jest nagroda dla wszystkich mieszkańców - mówił zastępca burmistrza Michałowa. Kandydaturę gminy zgłosiły Kraków i Wrocław

## Kosmiczne aukcje WOŚP. Można strzelić laserem w satelitę i zwiedzić centrum astronautów
 - [https://tvn24.pl/poznan/wosp-2023-kosmiczne-aukcje-na-31-final-mozna-strzelic-laserem-w-satelite-i-zwiedzic-centrum-astronautow-6626613?source=rss](https://tvn24.pl/poznan/wosp-2023-kosmiczne-aukcje-na-31-final-mozna-strzelic-laserem-w-satelite-i-zwiedzic-centrum-astronautow-6626613?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 16:46:59+00:00
 - user: None

<img alt="Kosmiczne aukcje WOŚP. Można strzelić laserem w satelitę i zwiedzić centrum astronautów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vwbh1t-aukcja-borowiec-6628459/alternates/LANDSCAPE_1280" />
    WOŚP 2023 już wkrótce. Z tej okazji obserwatorium astrogeodynamiczne w Borówcu pod Poznaniem wystawiło na licytację Wielkiej Orkiestry Świątecznej Pomocy wyjątkową atrakcję. Ten, kto wygra aukcję, będzie mógł strzelić laserem do satelitów i śmieci kosmicznych. Na innej licytacji można powalczyć o prywatną wycieczkę po Europejskim Centrum Astronautów w Kolonii (Niemcy).

## Pogoda na weekend: system frontów przyniesie pochmurną i deszczową aurę. Na horyzoncie powrót lekkiej zimy
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-pogoda-na-5-dni-pogoda-na-ferie-zimowe-2023-6628247?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-pogoda-na-5-dni-pogoda-na-ferie-zimowe-2023-6628247?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 16:33:30+00:00
 - user: None

<img alt="Pogoda na weekend: system frontów przyniesie pochmurną i deszczową aurę. Na horyzoncie powrót lekkiej zimy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fflzeg-miejscami-popada-snieg-6628413/alternates/LANDSCAPE_1280" />
    Weekend zapowiada się pochmurny z opadami deszczu, w górach spadnie do 10 centymetrów śnieg. Powieje też dość silny wiatr, w porywach nawet do 100 kilometrów na godzinę. Nowy tydzień również przyniesie deszcz, a także deszcz ze śniegiem i sam śnieg.

## Jest pozwolenie, w przyszłym tygodniu otwarcie estakady Marsa - Żołnierska
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-estakada-na-skrzyzowaniu-zolnierskiej-i-marsa-gotowa-ratusz-w-przyszlym-tygodniu-otwarcie-6628416?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-estakada-na-skrzyzowaniu-zolnierskiej-i-marsa-gotowa-ratusz-w-przyszlym-tygodniu-otwarcie-6628416?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 15:48:53+00:00
 - user: None

<img alt="Jest pozwolenie, w przyszłym tygodniu otwarcie estakady Marsa - Żołnierska" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dtbxfc-wiadukt-na-skrzyzowaniu-marsa-z-zolnierska-6628484/alternates/LANDSCAPE_1280" />
    Miasto uzyskało pozwolenie na użytkowanie nowej estakady na skrzyżowaniu Marsa i Żołnierskiej. Ratusz zapowiada, że pierwsze auta przejadą nią już w przyszłym tygodniu.

## Prognoza pogody na ferie zimowe 2023. Czy spadnie śnieg?
 - [https://tvn24.pl/tvnmeteo/prognoza/prognoza-pogody-na-ferie-zimowe-2023-czy-spadnie-snieg-6616232?source=rss](https://tvn24.pl/tvnmeteo/prognoza/prognoza-pogody-na-ferie-zimowe-2023-czy-spadnie-snieg-6616232?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 15:17:00+00:00
 - user: None

<img alt="Prognoza pogody na ferie zimowe 2023. Czy spadnie śnieg?" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-eaicrn-pogoda-na-ferie-zimowe-6616437/alternates/LANDSCAPE_1280" />
    Jaka pogoda w ferie zimowe? Czy jest szansa na śnieg? Formalnie od poniedziałku, a faktycznie już od weekendu rusza pierwsza tura ferii zimowych w szkołach. Obejmuje pięć województw. Początkowo uczniowie z tych regionów - jeśli pozostaną w miejscu zamieszkania - mogą się spodziewać dużego zachmurzenia, ale miejscami jest szansa na rozpogodzenia. Pojawią się opady deszczu, deszczu ze śniegiem i śniegu. Temperatura spadnie poniżej zera.

## Złe wieści dla podróżujących do Grecji
 - [https://tvn24.pl/biznes/turystyka/grecja-ceny-ile-kosztuja-wakacje-w-grecji-6628419?source=rss](https://tvn24.pl/biznes/turystyka/grecja-ceny-ile-kosztuja-wakacje-w-grecji-6628419?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 15:15:39+00:00
 - user: None

<img alt="Złe wieści dla podróżujących do Grecji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kz9km6-rodos-grecja-shutterstock1565612872-6064235/alternates/LANDSCAPE_1280" />
    Ceny zorganizowanych wakacji w Grecji wzrosły średnio o 12 procent w sezonie turystycznym 2023 w stosunku do zeszłego roku. Z kolei prywatne rezerwacje mogą być droższe nawet 100 procent - podał grecki portal Ekathimerini.

## Ukradł samochód do rozwożenia pizzy, wpadł po policyjnym pościgu
 - [https://tvn24.pl/bialystok/biala-podlaska-ukradl-samochod-do-rozwozenia-pizzy-wpadl-po-policyjnym-poscigu-6628030?source=rss](https://tvn24.pl/bialystok/biala-podlaska-ukradl-samochod-do-rozwozenia-pizzy-wpadl-po-policyjnym-poscigu-6628030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 14:54:47+00:00
 - user: None

<img alt="Ukradł samochód do rozwożenia pizzy, wpadł po policyjnym pościgu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c4w3w3-mezczyzna-wykorzystal-fakt-ze-w-samochodzie-byly-kluczyki-i-ukradl-auto-6628055/alternates/LANDSCAPE_1280" />
    Za kradzież samochodu do rozwożenia pizzy odpowie 43-latek z Białej Podlaskiej (woj. lubelskie). - Wykorzystał fakt pozostawienia kluczyków we wnętrzu auta - informuje policja. Podczas pościgu porzucił auto i próbował uciekać pieszo. W chwili zatrzymania miał ponad półtora promila alkoholu w organizmie.

## Lech Wałęsa: postanowiłem wycofać swoje sympatyzowanie z PO. W związku z głosowaniem w Sejmie
 - [https://tvn24.pl/polska/lech-walesa-po-glosowaniu-w-sprawie-nowelizacji-ustawy-o-sn-postanowilem-wycofac-swoje-sympatyzowanie-z-po-6628296?source=rss](https://tvn24.pl/polska/lech-walesa-po-glosowaniu-w-sprawie-nowelizacji-ustawy-o-sn-postanowilem-wycofac-swoje-sympatyzowanie-z-po-6628296?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 14:37:38+00:00
 - user: None

<img alt="Lech Wałęsa: postanowiłem wycofać swoje sympatyzowanie z PO. W związku z głosowaniem w Sejmie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k5kbof-pap202212020x6-6628299/alternates/LANDSCAPE_1280" />
    Lech Wałęsa poinformował, że kończy z "sympatyzowaniem" z Platformą Obywatelską. Jak wyjaśnił, ma to związek z głosowaniem klubu KO w sprawie zmian zapisów w ustawie o sądownictwie.

## Miał grozić kobietom napotkanym w parku bronią palną i nożem. Został zatrzymany
 - [https://tvn24.pl/krakow/krakow-nozownik-w-parku-tysiaclecia-tydzien-wczesniej-mial-grozic-kobiecie-bronia-palna-6628218?source=rss](https://tvn24.pl/krakow/krakow-nozownik-w-parku-tysiaclecia-tydzien-wczesniej-mial-grozic-kobiecie-bronia-palna-6628218?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 14:07:50+00:00
 - user: None

<img alt="Miał grozić kobietom napotkanym w parku bronią palną i nożem. Został zatrzymany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q8sqti-pan-1-6628203/alternates/LANDSCAPE_1280" />
    Mężczyzna miał przysiąść się do kobiety w Parku Tysiąclecia w Krakowie, złapać ją za udo i przyłożyć broń palną do głowy, a po tygodniu grozić dwóm innym kobietom nożem. Do 10 lat więzienia grozi zatrzymanemu w Krakowie 30-latkowi, który swoją listę zarzutów dopełnił rzuceniem nożem w interweniującego policjanta. Mężczyzna spędzi najbliższe miesiące w areszcie.

## Poznań jak Nowy Jork. Na dawnej linii kolejowej chcą stworzyć park linearny
 - [https://tvn24.pl/poznan/poznan-na-dawnej-linii-kolejowej-chca-stworzyc-park-linearny-podobny-jak-high-line-w-nowym-jorku-6628152?source=rss](https://tvn24.pl/poznan/poznan-na-dawnej-linii-kolejowej-chca-stworzyc-park-linearny-podobny-jak-high-line-w-nowym-jorku-6628152?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 14:03:29+00:00
 - user: None

<img alt="Poznań jak Nowy Jork. Na dawnej linii kolejowej chcą stworzyć park linearny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jjna8g-tak-w-zalozeniu-ma-wygladac-nowy-poznanski-park-6628285/alternates/LANDSCAPE_1280" />
    Park linearny może powstać na terenie po dawnych torach "kolei berlińskiej" na poznańskim Górczynie. Taka koncepcja znalazła się w projekcie miejscowego planu zagospodarowania przestrzennego. "Tego typu założenia tworzy się na terenach, które pełniły niegdyś funkcje komunikacyjne, np. High Line, czyli dawna estakada kolejowa w Nowym Jorku" - piszą urzędnicy.

## Najmądrzejszy pies świata. Testy smartDOG wskazały najinteligentniejszą rasę
 - [https://tvn24.pl/tvnmeteo/ciekawostki/najmadrzejszy-pies-swiata-testy-smartdog-wskazaly-najinteligentniejsza-rase-6628163?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/najmadrzejszy-pies-swiata-testy-smartdog-wskazaly-najinteligentniejsza-rase-6628163?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 14:02:39+00:00
 - user: None

<img alt="Najmądrzejszy pies świata. Testy smartDOG wskazały najinteligentniejszą rasę  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5nq6ay-rasy-psow-6628224/alternates/LANDSCAPE_1280" />
    Naukowcy ocenili, że najinteligentniejszą rasą psa jest owczarek belgijski malinois – poinformowało czasopismo "Scientific Reports". Zwycięzcę zidentyfikowano za pomocą zestawu testów smartDOG, w których oceniano zarówno inteligencję, jak i funkcje poznawcze.

## Ksiądz poszedł z kolędą, 16-letni ministrant "postanowił przejechać się" jego autem. Wjechał w dom
 - [https://tvn24.pl/wroclaw/pobiel-16-letni-ministrant-rozbil-sie-samochodem-ksiedza-wjechal-w-dom-6628154?source=rss](https://tvn24.pl/wroclaw/pobiel-16-letni-ministrant-rozbil-sie-samochodem-ksiedza-wjechal-w-dom-6628154?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 13:37:44+00:00
 - user: None

<img alt="Ksiądz poszedł z kolędą, 16-letni ministrant " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2r1hmv-16-letni-ministrant-rozbil-sie-samochodem-ksiedza-6628146/alternates/LANDSCAPE_1280" />
    Ksiądz ruszył z kolędą, a w jego aucie został 16-letni ministrant. Jak informuje policja, w pewnym momencie "postanowił przejechać się samochodem". Ruszył przed siebie, stracił panowanie nad pojazdem i uderzył w budynek mieszkalny. Nastolatek został ranny, a sprawą zajmie się sąd rodzinny.

## Uciekł właścicielom, wszedł do pustostanu i nie mógł z niego wyjść
 - [https://tvn24.pl/wroclaw/twardogora-uciekl-wlascicielom-wszedl-do-pustostanu-i-nie-mogl-z-niego-wyjsc-policjanci-i-strazacy-pomogli-psu-6628059?source=rss](https://tvn24.pl/wroclaw/twardogora-uciekl-wlascicielom-wszedl-do-pustostanu-i-nie-mogl-z-niego-wyjsc-policjanci-i-strazacy-pomogli-psu-6628059?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 13:26:36+00:00
 - user: None

<img alt="Uciekł właścicielom, wszedł do pustostanu i nie mógł z niego wyjść" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hrd2ir-pies-siedziala-w-pustostanie-uratowali-go-policjanci-i-strazacy-6628019/alternates/LANDSCAPE_1280" />
    Głośno szczekał i skomlał, w końcu jeden z mieszkańców poinformował służby. Okazało się, że niewielki pies wszedł do pustostanu w Twardogórze (Dolnośląskie) i nie mógł z niego wyjść. Wystraszonego i wycieńczonego czworonoga wydostali strażacy i policjanci. Zwierzę, jak przekazały służby, uciekło z jednej z posesji i było poszukiwane od kilku dni.

## Łódź. Rzucił się z ostrzem na ratownika, został obezwładniony
 - [https://tvn24.pl/lodz/lodz-pijany-59-latek-rzucil-sie-z-ostrzem-na-ratownika-zostal-obezwladniony-6628064?source=rss](https://tvn24.pl/lodz/lodz-pijany-59-latek-rzucil-sie-z-ostrzem-na-ratownika-zostal-obezwladniony-6628064?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 13:18:21+00:00
 - user: None

<img alt="Łódź. Rzucił się z ostrzem na ratownika, został obezwładniony" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9m6w85-atak-na-ratownika-medycznego-6628068/alternates/LANDSCAPE_1280" />
    Zarzut czynnej napaści i kierowania gróźb karalnych usłyszał 59-letni mężczyzna, który zaatakował scyzorykiem ratownika medycznego w karetce. - Napastnik był tak pijany, że nie nadawał się do transportu przez straż miejską. W czasie przejazdu z zespołem ratownictwa ocknął się, wyciągnął scyzoryk i zaatakował - mówi rzecznik łódzkiego pogotowia.

## Miał na koncie 48 kradzieży paliwa. Wpadł przez niewłaściwe światła w aucie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mezczyzna-mial-48-razy-ukrasc-paliwo-6627661?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mezczyzna-mial-48-razy-ukrasc-paliwo-6627661?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 13:01:32+00:00
 - user: None

<img alt="Miał na koncie 48 kradzieży paliwa. Wpadł przez niewłaściwe światła w aucie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-6yj1rh-policjant-przesluchuje-podejrzanego-mezczyzne-6627693/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali na Kijowskiej 33-latka, bo jego auto miało nieprzepisowe światła. Szybko okazało się, że na tym nie kończą się problemy z samochodem. Tablice rejestracyjne były podmienione, a w bagażniku kierowca przewoził kilka kanistrów z paliwem. Jego pochodzenie zainteresowało policjantów.

## Najlepsze licea i technika w Warszawie. Ranking Perspektywy 2023
 - [https://tvn24.pl/tvnwarszawa/najnowsze/perspektywy-2023-najlepsze-licea-i-technika-w-warszawie-ranking-6627838?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/perspektywy-2023-najlepsze-licea-i-technika-w-warszawie-ranking-6627838?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:42:20+00:00
 - user: None

<img alt="Najlepsze licea i technika w Warszawie. Ranking Perspektywy 2023" src="https://tvn24.pl/najnowsze/cdn-zdjecie-psn17y-zespol-szkol-licealnych-i-technicznych-nr-1-w-tym-technikum-mechatronicznego-nr-1-przy-ul-wisniowej-w-warszawie-6628073/alternates/LANDSCAPE_1280" />
    Zarówno w kategorii liceów, jak i techników w ogólnopolskim rankingu Perspektywy 2023 na pierwszych miejscach znalazły się warszawskie szkoły: XIV Liceum Ogólnokształcące im. Stanisława Staszica oraz Technikum Mechatroniczne nr 1 w Zespole Szkół Licealnych i Technicznych nr 1. Oto dwadzieścia najlepszych liceów i dziesięć najlepszych techników w stolicy.

## Media: ciała wagnerowców przewożone ciężarówkami. Opłata w gotówce, bez "dobijania targu"
 - [https://tvn24.pl/swiat/rosyjskie-media-grupa-wagnera-transportuje-ciala-najemnikow-przy-uzyciu-zwyklych-ciezarowek-6627549?source=rss](https://tvn24.pl/swiat/rosyjskie-media-grupa-wagnera-transportuje-ciala-najemnikow-przy-uzyciu-zwyklych-ciezarowek-6627549?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:26:37+00:00
 - user: None

<img alt="Media: ciała wagnerowców przewożone ciężarówkami. Opłata w gotówce, bez " src="https://tvn24.pl/najnowsze/cdn-zdjecie-38ettb-rosyjska-ciezarowka-6627564/alternates/LANDSCAPE_1280" />
    Prywatna firma wojskowa Grupa Wagnera, rekrutująca najemników do walk w Ukrainie, transportuje ciała żołnierzy z tego kraju do Rosji przy pomocy zwykłych ciężarówek. Za dostawę "ładunku 200" trzeba zapłacić 60 tysięcy rubli - przekazały rosyjskie niezależne media.

## Miał zażądać od nastolatków pieniędzy. "Zagroził, że przestrzeli jednemu z nich kolano"
 - [https://tvn24.pl/bialystok/pulawy-mial-zazadac-od-nastolatkow-pieniedzy-policjantowi-grozic-smiercia-36-latek-z-zarzutami-6627817?source=rss](https://tvn24.pl/bialystok/pulawy-mial-zazadac-od-nastolatkow-pieniedzy-policjantowi-grozic-smiercia-36-latek-z-zarzutami-6627817?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:17:39+00:00
 - user: None

<img alt="Miał zażądać od nastolatków pieniędzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-erhixn-zaklad-karny-4689671/alternates/LANDSCAPE_1280" />
    Do 12 lat więzienia grozi 36-letniemu mieszkańcowi Puław (woj. lubelskie), który zagroził przestrzeleniem kolana jednemu z nastolatków, od którego zażądał pieniędzy, a policjantowi miał grozić zabójstwem. Mężczyzna usłyszał zarzuty usiłowania dokonania rozboju, wymuszenia rozbójniczego oraz kierowania gróźb karalnych. Trzy najbliższe miesiące spędzi w areszcie.

## Ile biletów PKP za średnią krajową w 2015 i 2023 roku? "Coś tu się nie zgadza"
 - [https://konkret24.tvn24.pl/najnowsze/bilety-kolejowe-ile-biletow-pkp-za-srednia-krajowa-w-2015-i-2023-roku-cos-tu-sie-nie-zgadza-6626235?source=rss](https://konkret24.tvn24.pl/najnowsze/bilety-kolejowe-ile-biletow-pkp-za-srednia-krajowa-w-2015-i-2023-roku-cos-tu-sie-nie-zgadza-6626235?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:13:28+00:00
 - user: None

<img alt="Ile biletów PKP za średnią krajową w 2015 i 2023 roku? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5kl9a-ile-biletow-pkp-za-srednia-krajowa-w-2015-roku-6625906/alternates/LANDSCAPE_1280" />
    Polityk PSL opublikował zestawienie pokazujące, że w 2015 roku za średnią pensję można było kupić dwa razy więcej biletów kolejowych niż w tym roku. "Coś tu się nie zgadza" - komentowali internauci. Sprawdziliśmy.

## Delfiny "przekrzykują się", aby przebić się przez hałas wytwarzany przez człowieka
 - [https://tvn24.pl/tvnmeteo/nauka/delfiny-przekrzykuja-sie-aby-przebic-sie-przez-halas-wytwarzany-przez-czlowieka-6627623?source=rss](https://tvn24.pl/tvnmeteo/nauka/delfiny-przekrzykuja-sie-aby-przebic-sie-przez-halas-wytwarzany-przez-czlowieka-6627623?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:05:35+00:00
 - user: None

<img alt="Delfiny " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-z5e79h-delfiny-butlonose-6627656/alternates/LANDSCAPE_1280" />
    Hałas związany z działalnością człowieka pogarsza współpracę i komunikację u delfinów butlonosych - donosi międzynarodowy zespół badawczy pod kierownictwem ekspertów z Uniwersytetu w Bristolu.

## Akcja policji w kilku miejscach jednocześnie. Znaleziono materiały wybuchowe, broń i narkotyki
 - [https://tvn24.pl/katowice/katowice-policjanci-przejeli-narkotyki-bron-i-materialy-wybuchowe-6627644?source=rss](https://tvn24.pl/katowice/katowice-policjanci-przejeli-narkotyki-bron-i-materialy-wybuchowe-6627644?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 12:03:32+00:00
 - user: None

<img alt="Akcja policji w kilku miejscach jednocześnie. Znaleziono materiały wybuchowe, broń i narkotyki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qzku3d-policjanci-przejeli-narkotyki-bron-i-materialy-wybuchowe-6627583/alternates/LANDSCAPE_1280" />
    Śląscy policjanci zatrzymali 28-letniego mieszkańca Chorzowa, a w mieszkaniach i garażu w kilku miastach w regionie zabezpieczyli broń palną, amunicję, narkotyki warte pół miliona złotych i materiały wybuchowe. Jak podaje policja, to pierwsza tak duża akcja śląskich kryminalnych w tym roku.

## Bus uderzył w tył ciężarówki. Kierowca miał zasnąć za kierownicą, jest poważnie ranny
 - [https://tvn24.pl/lodz/s8-sieradz-zloczew-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-zablokowana-6627874?source=rss](https://tvn24.pl/lodz/s8-sieradz-zloczew-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-zablokowana-6627874?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:46:04+00:00
 - user: None

<img alt="Bus uderzył w tył ciężarówki. Kierowca miał zasnąć za kierownicą, jest poważnie ranny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xxh25y-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-s8-zablokowana-6627839/alternates/LANDSCAPE_1280" />
    Jedna osoba została ciężko ranna w wypadku samochodu dostawczego z ciężarówką na drodze ekspresowej S8 pomiędzy węzłami Złoczew i Sieradz Wschód (Łódzkie). Droga w kierunku Warszawy jest zablokowana. Policja wyznaczyła objazdy.

## Bus uderzył w tył ciężarówki. Kierowca miał zasnąć za kierownicą, jest poważnie ranny
 - [https://tvn24.pl/lodz/s8-sieradz-zloczew-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-byla-zablokowana-6627874?source=rss](https://tvn24.pl/lodz/s8-sieradz-zloczew-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-byla-zablokowana-6627874?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:46:04+00:00
 - user: None

<img alt="Bus uderzył w tył ciężarówki. Kierowca miał zasnąć za kierownicą, jest poważnie ranny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xxh25y-bus-uderzyl-w-tyl-ciezarowki-jedna-osoba-ciezko-ranna-droga-s8-zablokowana-6627839/alternates/LANDSCAPE_1280" />
    Jedna osoba została ciężko ranna w wypadku samochodu dostawczego z ciężarówką na drodze ekspresowej S8 pomiędzy węzłami Złoczew i Sieradz Wschód (Łódzkie). Droga w kierunku Warszawy była zablokowana blisko cztery godziny.

## Ksiądz chodził po kolędzie, został napadnięty i okradziony. Mają podejrzanego o atak
 - [https://tvn24.pl/krakow/jaslo-ksiadz-chodzil-po-koledzie-zostal-napadniety-i-okradziony-37-latek-z-zarzutami-za-rozboj-przyznal-sie-do-ataku-na-ksiedza-6627701?source=rss](https://tvn24.pl/krakow/jaslo-ksiadz-chodzil-po-koledzie-zostal-napadniety-i-okradziony-37-latek-z-zarzutami-za-rozboj-przyznal-sie-do-ataku-na-ksiedza-6627701?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:43:19+00:00
 - user: None

<img alt="Ksiądz chodził po kolędzie, został napadnięty i okradziony. Mają podejrzanego o atak" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e28cyf-37-latek-ktory-zaatakowal-ksiedza-trzy-najblizsze-miesiace-spedzi-w-areszcie-6627745/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali mężczyznę, który w Jaśle (woj. podkarpackie) zaatakował i okradł księdza chodzącego po kolędzie. 37-latek usłyszał już zarzuty, do których się przyznał. Decyzją sądu trzy najbliższe miesiące spędzi w areszcie.

## Regularne przyjmowanie witaminy D może zmniejszać ryzyko nowotworów skóry
 - [https://tvn24.pl/tvnmeteo/nauka/badanie-regularne-przyjmowanie-witaminy-d-moze-zmniejszac-ryzyko-nowotworow-skory-6627824?source=rss](https://tvn24.pl/tvnmeteo/nauka/badanie-regularne-przyjmowanie-witaminy-d-moze-zmniejszac-ryzyko-nowotworow-skory-6627824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:31:08+00:00
 - user: None

<img alt="Regularne przyjmowanie witaminy D może zmniejszać ryzyko nowotworów skóry" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-n58dbd-witamina-d-6627880/alternates/LANDSCAPE_1280" />
    Fińscy badacze przeprowadzili analizę, która wykazała, że dzięki regularnemu przyjmowaniu witaminy D, spada ryzyko zachorowania na nowotwór skóry. W badaniu wzięło udział prawie 500 osób, wszystkich uczestników podzielono na grupy w zależności od tego, jak często stosowali suplementację.

## Francja przekaże Ukrainie wozy bojowe AMX-10 RC
 - [https://tvn24.pl/swiat/francja-przekaze-ukrainie-wozy-bojowe-amx-10-rc-6627857?source=rss](https://tvn24.pl/swiat/francja-przekaze-ukrainie-wozy-bojowe-amx-10-rc-6627857?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:23:51+00:00
 - user: None

<img alt="Francja przekaże Ukrainie wozy bojowe AMX-10 RC " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ftki6j-bojowe-wozy-rozpoznawcze-amx-10-rc-6627879/alternates/LANDSCAPE_1280" />
    Francuskie ministerstwo obrony poinformowało w piątek, że siły zbrojne kraju planują przekazać Ukrainie bojowe wozy rozpoznawcze AMX-10 RC w ciągu najbliższych dwóch miesięcy. Biuro prasowe prezydenta Emmanuela Macrona przekazało wcześniej, że Paryż dostarczy Ukrainie wozy AMX-10 RC, "chcąc wzmocnić pomoc wojskową, która została już udzielona Kijowowi".

## Mijają cztery lata od ataku na Pawła Adamowicza. Gdańsk upamiętni zmarłego prezydenta
 - [https://tvn24.pl/pomorze/gdansk-mijaja-cztery-lata-od-ataku-na-prezydenta-pawla-adamowicza-6627779?source=rss](https://tvn24.pl/pomorze/gdansk-mijaja-cztery-lata-od-ataku-na-prezydenta-pawla-adamowicza-6627779?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:10:51+00:00
 - user: None

<img alt="Mijają cztery lata od ataku na Pawła Adamowicza. Gdańsk upamiętni zmarłego prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie03136fd91cf4ba869ebad2074d51264b-rocznica-smierci-pawla-adamowicza-5020370/alternates/LANDSCAPE_1280" />
    Mijają cztery lata od 27. Finału Wielkiej Orkiestry Świątecznej Pomocy, podczas którego zaatakowany został Paweł Adamowicz, prezydent Gdańska. Samorządowiec zmarł następnego dnia. W geście pamięci na ulicach miasta ponownie rozbrzmi utwór "The Sound of Silence". Miasto zaplanowało również szereg wydarzeń upamiętniających rocznicę śmierci swojego prezydenta. Proces zabójcy jest w toku, grozi mu dożywocie.

## "To jest tak, jakby człowiek miał 39,5 stopnia temperatury, a spadło mu do 39"
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-grudniu-komentarze-kazimierza-krupy-i-dr-malgorzaty-starczewskiej-krzysztoszek-6627655?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-grudniu-komentarze-kazimierza-krupy-i-dr-malgorzaty-starczewskiej-krzysztoszek-6627655?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:09:39+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vdmy51-ludzie-ulica-maski-covid-5591867/alternates/LANDSCAPE_1280" />
    Z pewnością powodów do zadowolenia nie ma żadnych - wyjaśnił w TVN24 Kazimierz Krupa, dziennikarz ekonomiczny, dyrektor zarządzający Drawbridge komentując najnowsze dane o inflacji. W jego ocenie "z każdym miesiącem będziemy biednieli". dr Małgorzata Starczewska-Krzysztoszek z Uniwersytetu Warszawskiego odniosła się do wzrostu wynagrodzeń. - Jeśli porównamy przeciętne wynagrodzenia w mikofirmach i w firmach nieco większych, to tam te wynagrodzenia są istotnie mniejsze i wolniej rosną, jeśli w ogóle rosną - zaznaczyła.

## Natalie Portman przepytuje Olgę Tokarczuk. "Wciąż jestem pod wielkim wrażeniem"
 - [https://tvn24.pl/kultura-i-styl/natalie-portman-pyta-olge-tokarczuk-w-wywiadzie-o-ksiazki-i-role-kobiet-6627802?source=rss](https://tvn24.pl/kultura-i-styl/natalie-portman-pyta-olge-tokarczuk-w-wywiadzie-o-ksiazki-i-role-kobiet-6627802?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:08:32+00:00
 - user: None

<img alt="Natalie Portman przepytuje Olgę Tokarczuk. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-zs7ks9-olga-tokarczuk-w-rozmowie-z-natalie-portman-6627757/alternates/LANDSCAPE_1280" />
    Natalie Portman i Olga Tokarczuk rozmawiały o książkach, roli kobiet, a także znaczeniu ich wieku. Hollywoodzka gwiazda, w ramach swojego klubu książki, pytała polską pisarkę o jej powieść "Prowadź swój pług przez kości umarłych". Ale nie tylko o nią.

## Miał dożywotni zakaz prowadzenia, pijany uderzył w zaparkowane auta. Zarzuty i areszt dla kierowcy
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-pijany-uderzyl-w-zaparkowane-auta-mial-dozywotni-zakaz-zarzuty-i-areszt-dla-kierowcy-6627443?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-pijany-uderzyl-w-zaparkowane-auta-mial-dozywotni-zakaz-zarzuty-i-areszt-dla-kierowcy-6627443?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 11:03:44+00:00
 - user: None

<img alt="Miał dożywotni zakaz prowadzenia, pijany uderzył w zaparkowane auta. Zarzuty i areszt dla kierowcy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-5faw48-kolizja-na-ulicy-gotarda-6623383/alternates/LANDSCAPE_1280" />
    We wtorek pijany kierowca uszkodził trzy zaparkowane na ulicy Gotarda samochody. W piątek policja poinformowała, że jazda w stanie nietrzeźwości, to nie jedyna obciążająca go okoliczność. - Na swoim koncie ma dożywotni sądowy zakaz prowadzenia pojazdów - przekazała mokotowska komenda.

## Zaręczyny polityka PiS w kopalni. "Przekraczają granicę śmieszności"
 - [https://tvn24.pl/polska/bogdanka-kopalnia-polityk-pis-michal-moskal-mial-oswiadczyc-sie-pod-ziemia-komentarze-politykow-6627707?source=rss](https://tvn24.pl/polska/bogdanka-kopalnia-polityk-pis-michal-moskal-mial-oswiadczyc-sie-pod-ziemia-komentarze-politykow-6627707?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 10:54:52+00:00
 - user: None

<img alt="Zaręczyny polityka PiS w kopalni. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ca0ci0-en015283790004-6625861/alternates/LANDSCAPE_1280" />
    Naprawdę odjechali na całej prostej i skończą źle. Przekraczają granicę śmieszności, a to w polityce jest granica zabójcza - powiedział wicemarszałek Sejmu Piotr Zgorzelski (PSL) o zaręczynach Michała Moskala, polityka PiS. Ten bliski współpracownik Jarosława Kaczyńskiego poprosił wybrankę serca o rękę w lubelskiej kopalni Bogdanka, 960 metrów pod ziemią. Według rzecznika rządu Piotra Muellera "nic się złego nie stało, jeśli zostały zachowane procedury".

## Kolizja na Muranowie. Jeden z kierowców miał prawie dwa promile
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-u-zbiegu-stawki-i-jana-pawla-ii-kierowca-pijany-6627528?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-u-zbiegu-stawki-i-jana-pawla-ii-kierowca-pijany-6627528?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 10:51:23+00:00
 - user: None

<img alt="Kolizja na Muranowie. Jeden z kierowców miał prawie dwa promile" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vj8pdb-kolizja-na-muranowie-6627538/alternates/LANDSCAPE_1280" />
    Do kolizji dwóch samochodów osobowych doszło w czwartek wieczorem u zbiegu ulicy i alei Jana Pawła II. Jeden z kierowców okazał się pijany. Jak podała policja, miał prawie dwa promile alkoholu w organizmie.

## Rogatki się podnosiły, światło wciąż było czerwone. Rowerzysta pojechał, radiowóz ruszył za nim. Nagranie
 - [https://tvn24.pl/pomorze/borkowo-wjechal-rowerem-na-przejazd-kolejowy-na-czerwonym-swietle-policjanci-ruszyli-za-nim-nagranie-6627638?source=rss](https://tvn24.pl/pomorze/borkowo-wjechal-rowerem-na-przejazd-kolejowy-na-czerwonym-swietle-policjanci-ruszyli-za-nim-nagranie-6627638?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 10:43:54+00:00
 - user: None

<img alt="Rogatki się podnosiły, światło wciąż było czerwone. Rowerzysta pojechał, radiowóz ruszył za nim. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-356a4t-rowerzysta-przejechal-na-czerwonym-swietle-przez-przejazd-kolejowy-6627630/alternates/LANDSCAPE_1280" />
    Rogatki się dopiero podnosiły, a sygnalizator przed przejazdem kolejowym w Borkowie (woj. kujawsko-pomorskie) wciąż nadawał czerwone światło. Nie przeszkadzało to rowerzyście, który ruszył przed siebie. Za nim stał radiowóz. Policjanci zatrzymali 64-latka i ukarali go mandatem. Mężczyzna musiał zapłacić dwa tysiące złotych.

## Warszawa przekaże pociągi metra, Praga tramwaje i autobusy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/jak-warszawa-praga-bratyslawa-budapeszt-pomagaja-ukrainskim-miastom-6627750?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/jak-warszawa-praga-bratyslawa-budapeszt-pomagaja-ukrainskim-miastom-6627750?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 10:26:04+00:00
 - user: None

<img alt="Warszawa przekaże pociągi metra, Praga tramwaje i autobusy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i85r8n-po-wizycie-w-ukrainie-6627793/alternates/LANDSCAPE_1280" />
    Prezydent Warszawy Rafał Trzaskowski i burmistrzowie Bratysławy, Budapesztu oraz Pragi zakończyli wizytę w Ukrainie. W piątek spotkali się z dziennikarzami, by podzielić się swoimi wnioskami.

## Znaleźli pozostałości strusich jaj. Mogą liczyć nawet 7,5 tysiąca lat
 - [https://tvn24.pl/tvnmeteo/nauka/izrael-znalezli-pozostalosci-strusich-jaj-moga-miec-nawet-75-tysiaca-lat-6627650?source=rss](https://tvn24.pl/tvnmeteo/nauka/izrael-znalezli-pozostalosci-strusich-jaj-moga-miec-nawet-75-tysiaca-lat-6627650?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 10:22:13+00:00
 - user: None

<img alt="Znaleźli pozostałości strusich jaj. Mogą liczyć nawet 7,5 tysiąca lat" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-g0j2ox-znaleziono-fragmenty-strusich-jaj-liczacych-4-tysiace-lat-6627554/alternates/LANDSCAPE_1280" />
    Grupie izraelskich archeologów udało się odnaleźć doskonale zachowane pozostałości strusich jaj, które mogą mieć od 4 do 7,5 tysiąca lat. Skorupy były potłuczone, ale dobrze zakonserwowane dzięki pustynnym warunkom. Jak przekazali naukowcy, w tamtych czasach częstą praktyką było wykorzystywanie jaj jako pożywienia, dekoracji czy do obrządków religijnych.

## Rząd w Portugalii wprowadza kwestionariusz dla urzędników w celu wyeliminowania konfliktów interesów
 - [https://tvn24.pl/swiat/portugalia-rzad-wprowadza-kwestionariusz-dla-urzednikow-w-celu-wyeliminowania-konfliktow-interesow-6627180?source=rss](https://tvn24.pl/swiat/portugalia-rzad-wprowadza-kwestionariusz-dla-urzednikow-w-celu-wyeliminowania-konfliktow-interesow-6627180?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 09:59:02+00:00
 - user: None

<img alt="Rząd w Portugalii wprowadza kwestionariusz dla urzędników w celu wyeliminowania konfliktów interesów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0t4yqp-parlament-portugalii-przyjal-ustawe-o-depenalizacji-eutanazji-6596203/alternates/LANDSCAPE_1280" />
    Portugalskie władze zdecydowały, że przyszli urzędnicy zanim zostaną mianowani na swoje funkcje, będą musieli odpowiedzieć na pytania zawarte w kwestionariuszu. Test ten, wprowadzony po serii skandali ma udowodnić, że nadają się na urząd.

## Prezydent Brazylii zarzucił członkom sił porządkowych współudział w szturmie na urzędy państwowe
 - [https://tvn24.pl/swiat/brazylia-lula-zarzucil-czlonkom-sil-porzadkowych-wspoludzial-w-szturmie-na-urzedy-panstwowe-6627283?source=rss](https://tvn24.pl/swiat/brazylia-lula-zarzucil-czlonkom-sil-porzadkowych-wspoludzial-w-szturmie-na-urzedy-panstwowe-6627283?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 09:41:58+00:00
 - user: None

<img alt="Prezydent Brazylii zarzucił członkom sił porządkowych współudział w szturmie na urzędy państwowe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1x0f8g-sad-najwyzszy-nakazal-aresztowanie-szefa-bezpieczenstwa-publicznego-andersona-torresa-6623579/alternates/LANDSCAPE_1280" />
    Brazylijski prezydent zarzuca siłom porządkowym wspieranie zwolenników Jaira Bolsonaro podczas niedzielnych zamieszek i ataku na urzędy państwowe w stolicy kraju.

## Grypa w Polsce. Ogromna liczba przypadków w pierwszym tygodniu roku. Prawie 3000 skierowań do szpitali
 - [https://tvn24.pl/polska/grypa-w-polsce-epidemia-ile-zachorowan-liczba-przypadkow-w-pierwszym-tygodniu-stycznia-6627301?source=rss](https://tvn24.pl/polska/grypa-w-polsce-epidemia-ile-zachorowan-liczba-przypadkow-w-pierwszym-tygodniu-stycznia-6627301?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 08:53:21+00:00
 - user: None

<img alt="Grypa w Polsce. Ogromna liczba przypadków w pierwszym tygodniu roku. Prawie 3000 skierowań do szpitali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7xj41p-szpital-6550348/alternates/LANDSCAPE_1280" />
    Z powodu grypy od 1 do 7 stycznia zmarło w Polsce siedem osób. Wszystkie z nich miały powyżej 65 lat - wynika z najnowszych danych epidemiologicznych. W pierwszym tygodniu 2023 roku zanotowano w Polsce 306 637 przypadków grypy i jej podejrzeń. Wystawiono z tego powodu 2891 skierowań do szpitala.

## Rekordowa wymiana handlowa między Chinami i Rosją
 - [https://tvn24.pl/biznes/ze-swiata/chiny-rosja-rekordowa-wymiana-handlowa-w-2022-roku-6627534?source=rss](https://tvn24.pl/biznes/ze-swiata/chiny-rosja-rekordowa-wymiana-handlowa-w-2022-roku-6627534?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 08:49:36+00:00
 - user: None

<img alt="Rekordowa wymiana handlowa między Chinami i Rosją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q5jy1w-wladimir-putin-i-xi-jinping-w-uzbekistanie-wrzesien-2022-6622197/alternates/LANDSCAPE_1280" />
    Wymiana handlowa między Chinami i Rosją w 2022 roku osiągnęła rekordowy poziom 1,28 biliona juanów, czyli równowartość 190 miliardów dolarów - poinformowały w piątek władze w Pekinie.

## Orlen inwestuje za granicą i stawia na start-upy
 - [https://tvn24.pl/biznes/najnowsze/orlen-inwestuje-zagranica-i-stawia-na-start-upy-orlen-zainwestowal-we-francuska-platforme-logistyczna-shippeo-6627475?source=rss](https://tvn24.pl/biznes/najnowsze/orlen-inwestuje-zagranica-i-stawia-na-start-upy-orlen-zainwestowal-we-francuska-platforme-logistyczna-shippeo-6627475?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 07:56:49+00:00
 - user: None

<img alt="Orlen inwestuje za granicą i stawia na start-upy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qntevx-daniel-obajtek-6226621/alternates/LANDSCAPE_1280" />
    Płocki koncern zainwestował we francuską platformę logistyczną Shippeo - podaje w piątek "Rzeczpospolita". PKN Orlen zapowiada usprawnienie procesów dostaw we wszystkich obszarach swojej działalności. I temu ma służyć nowa inwestycja. Jak podaje dziennik nowatorska platforma technologiczna ma służyć do zarządzania łańcuchami dostaw, monitoruje ponad 32 mln przesyłek rocznie w 110 krajach. Gazeta zauważa jednocześnie, że rynek technologicznych transakcji w Polsce i Europie wyraźnie słabnie.

## Elżbieta Bieńkowska: rząd, który opowiada o tym, że broni racji stanu, nagle mówi, że nie można zmienić przecinka
 - [https://tvn24.pl/polska/kpo-a-zmiany-w-sadownictwie-elzbieta-bienkowska-rzad-ktory-opowiada-ze-broni-racji-stanu-nagle-mowi-ze-nie-mozna-zmienic-przecinka-6627406?source=rss](https://tvn24.pl/polska/kpo-a-zmiany-w-sadownictwie-elzbieta-bienkowska-rzad-ktory-opowiada-ze-broni-racji-stanu-nagle-mowi-ze-nie-mozna-zmienic-przecinka-6627406?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 07:16:20+00:00
 - user: None

<img alt="Elżbieta Bieńkowska: rząd, który opowiada o tym, że broni racji stanu, nagle mówi, że nie można zmienić przecinka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fro9lo-elzbieta-bienkowska-6627371/alternates/LANDSCAPE_1280" />
    Komisja Europejska nie pisze krajom ustaw. Rząd, który opowiada o tym, że broni polskiej racji stanu, wstaje z kolan, walczy z Komisją Europejską, nagle mówi, że nie można zmienić przecinka - zwracała uwagę w "Jeden na Jeden" Elżbieta Bieńkowska, była wicepremier oraz była komisarz europejska. Odniosła się do kwestii ustawy o sądownictwie, której przyjęcie - w ocenie autorów - ma odblokować środki z Krajowego Planu Odbudowy. Premier Mateusz Morawiecki ocenił, że przyjęcie projektu w pierwotnej formie "daje nam względną gwarancję tego, że ten proces zostanie zakończony".

## Przechwycili 180 tysięcy tabletek na potencję. Przesyłka z Chin miała trafić do warszawskiej firmy
 - [https://tvn24.pl/tvnwarszawa/wlochy/warszawa-180-tysiecy-nielegalnych-tabletek-na-potencje-w-przesylce-z-chin-6627349?source=rss](https://tvn24.pl/tvnwarszawa/wlochy/warszawa-180-tysiecy-nielegalnych-tabletek-na-potencje-w-przesylce-z-chin-6627349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 06:37:40+00:00
 - user: None

<img alt="Przechwycili 180 tysięcy tabletek na potencję. Przesyłka z Chin miała trafić do warszawskiej firmy " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l2o5zj-w-przesylce-z-chin-bylo-180-tysiecy-tabletek-na-potencje-6627340/alternates/LANDSCAPE_1280" />
    Mazowiecka Krajowa Administracja Skarbowa zatrzymała na warszawskim Lotnisku Chopina przesyłkę z Chin. Kartony zawierały prawie 180 tysięcy tabletek na potencję. Nielegalne leki są warte nawet osiem milionów złotych.

## Startują ferie zimowe. Policja opublikowała listę miejsc prowadzenia kontroli autobusów
 - [https://tvn24.pl/biznes/moto/ferie-zimowe-2023-kontrole-policji-lista-miejsc-prowadzenia-kontroli-autobusow-6627302?source=rss](https://tvn24.pl/biznes/moto/ferie-zimowe-2023-kontrole-policji-lista-miejsc-prowadzenia-kontroli-autobusow-6627302?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 05:53:16+00:00
 - user: None

<img alt="Startują ferie zimowe. Policja opublikowała listę miejsc prowadzenia kontroli autobusów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lnox9z-autokar-kontrola-6627315/alternates/LANDSCAPE_1280" />
    Policja zapowiada więcej patroli na drogach w całym kraju. Powodem są rozpoczynające się ferie zimowe dla dzieci i młodzieży. Funkcjonariusze będą zwracać szczególną uwagę między innymi na sposób przewożenia pasażerów i bagażu. Będą też sprawdzać autobusy wiozące młodzież na zimowy wypoczynek - zapowiedział poinformował nadkomisarz Robert Opas z Biura Ruchu Drogowego Komendy Głównej Policji.

## Nielegalna fabryka papierosów w mieszkaniu
 - [https://tvn24.pl/tvnwarszawa/bemowo/bemowo-nielegalna-fabryka-papierosow-w-mieszkaniu-6626450?source=rss](https://tvn24.pl/tvnwarszawa/bemowo/bemowo-nielegalna-fabryka-papierosow-w-mieszkaniu-6626450?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 05:43:31+00:00
 - user: None

<img alt="Nielegalna fabryka papierosów w mieszkaniu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-d75iyb-fabryka-papierosow-dzialala-w-mieszkaniu-na-bemowie-6626448/alternates/LANDSCAPE_1280" />
    W mieszkaniu na Bemowie działała nielegalna fabryka papierosów. Policjanci zatrzymali trzy osoby, przejęli maszyny do produkcji oraz urządzenia do pakowania.

## Silny wiatr na północy Polski. Porywy mogą sięgać 75 kilometrów na godzinę
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-porywy-moga-siegac-75-kilometrow-na-godzine-6627300?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-porywy-moga-siegac-75-kilometrow-na-godzine-6627300?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 05:33:48+00:00
 - user: None

<img alt="Silny wiatr na północy Polski. Porywy mogą sięgać 75 kilometrów na godzinę" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9ri8gc-silny-wiatr-6559607/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW wydali alarmy pierwszego stopnia przed silnymi porywami wiatru. Z komunikatu wynika, że w porywach może wiać do 75 kilometrów na godzinę. Obowiązuje też prognoza zagrożeń.

## Zełenski zwraca się do świata. Ma propozycję dla Afryki
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-13-stycznia-6627289?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-13-stycznia-6627289?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 04:14:35+00:00
 - user: None

<img alt="Zełenski zwraca się do świata. Ma propozycję dla Afryki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7o9toj-zaladowane-zbozem-ukrainskie-statki-6189630/alternates/LANDSCAPE_1280" />
    Piątek jest 324. dniem inwazji zbrojnej Rosji na Ukrainę. Naszą bardzo ważną inicjatywą jest utworzenie hubów żywnościowych w Afryce. Mieszkańcy krajów tego kontynentu już zrozumieli, że bezpieczeństwo różnych państw bezpośrednio zależy od eksportu ukraińskiej żywności - oznajmił w czwartek w wieczornym wystąpieniu na Facebooku prezydent Ukrainy Wołodymyr Zełenski. W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Pogoda na dziś - piątek 13.01. Przez Polskę przejdzie strefa opadów deszczu
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-1301-przez-polske-przejdzie-strefa-opadow-deszczu-6626918?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-1301-przez-polske-przejdzie-strefa-opadow-deszczu-6626918?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-13 01:00:00+00:00
 - user: None

<img alt="Pogoda na dziś - piątek 13.01. Przez Polskę przejdzie strefa opadów deszczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-egsoiq-popada-deszcz-5558356/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W piątek 13.01 strefa opadów deszczu będzie przemieszczać się z zachodu na wschód kraju. W górach sypnie śniegiem. Termometry pokażą maksymalnie od 5 do 10 stopni Celsjusza. Aura niekorzystnie wpłynie na nasze samopoczucie.
