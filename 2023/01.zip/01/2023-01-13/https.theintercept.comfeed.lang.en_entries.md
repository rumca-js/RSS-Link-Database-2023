# Source The Intercept, Source URL:https://theintercept.com/feed/?lang=en, Source language: en-US

## Kevin McCarthy Wants to Hold China Accountable. His Top Aide Lobbied for Alibaba.
 - [https://theintercept.com/2023/01/13/kevin-mccarthy-china-alibaba-aide/](https://theintercept.com/2023/01/13/kevin-mccarthy-china-alibaba-aide/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-13 19:31:21+00:00
 - user: None

<p>Daniel Meyer still holds a six-figure stake in the government-linked “Amazon of China.”</p>
<p>The post <a href="https://theintercept.com/2023/01/13/kevin-mccarthy-china-alibaba-aide/" rel="nofollow">Kevin McCarthy Wants to Hold China Accountable. His Top Aide Lobbied for Alibaba.</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Biden Used Classified Documents Accusation Against Carter CIA Nominee
 - [https://theintercept.com/2023/01/13/biden-classified-documents-cia/](https://theintercept.com/2023/01/13/biden-classified-documents-cia/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-13 19:29:53+00:00
 - user: None

<p>As a senator, Joe Biden helped kill President Jimmy Carter's CIA director nominee because he allegedly mishandled classified materials.</p>
<p>The post <a href="https://theintercept.com/2023/01/13/biden-classified-documents-cia/" rel="nofollow">Biden Used Classified Documents Accusation Against Carter CIA Nominee</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## It’s Important to Talk Openly About Suicide
 - [https://theintercept.com/2023/01/13/deconstructed-suicide-prevention-aaron-swartz/](https://theintercept.com/2023/01/13/deconstructed-suicide-prevention-aaron-swartz/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-13 18:00:53+00:00
 - user: None

<p>Ryan Grim talks to Jason Cherkis about suicide prevention. </p>
<p>The post <a href="https://theintercept.com/2023/01/13/deconstructed-suicide-prevention-aaron-swartz/" rel="nofollow">It’s Important to Talk Openly About Suicide</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Listen to Barack Obama’s Chilling Description of U.S. Involvement in the Gigantic 1965 Indonesia Massacre
 - [https://theintercept.com/2023/01/13/barack-obama-1965-indonesia-coup/](https://theintercept.com/2023/01/13/barack-obama-1965-indonesia-coup/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-13 16:09:12+00:00
 - user: None

<p>This week, Indonesian President Joko Widodo acknowledged the “staggering mass slaughter” that took place 62 years ago.</p>
<p>The post <a href="https://theintercept.com/2023/01/13/barack-obama-1965-indonesia-coup/" rel="nofollow">Listen to Barack Obama’s Chilling Description of U.S. Involvement in the Gigantic 1965 Indonesia Massacre</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>
