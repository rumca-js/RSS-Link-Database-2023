# Source Polsat News, Source URL:https://www.polsatnews.pl/rss/swiat.xml, Source language: pl-PL

## Litwa: Potężna eksplozja gazociągu. Służby badają przyczyny zdarzenia
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/litwa-potezna-eksplozja-gazociagu-sluzby-badaja-przyczyny-zdarzenia/](https://www.polsatnews.pl/wiadomosc/2023-01-13/litwa-potezna-eksplozja-gazociagu-sluzby-badaja-przyczyny-zdarzenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 19:10:00+00:00
 - user: None

W piątek po południu doszło do eksplozji gazociągu łączącego Litwę z Łotwą. Trwa ewakuacja pobliskiej litewskiej wioski liczącej 250 mieszkańców. Jak dotąd nie ma poszlak wskazujących na to, że do wybuchu doszło na skutek celowego działania - poinformował Reuters.

## USA. Atak nożownika w Walmarcie. Weteran powstrzymał napastnika
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-atak-nozownika-w-walmarcie-weteran-powstrzymal-napastnika/](https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-atak-nozownika-w-walmarcie-weteran-powstrzymal-napastnika/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 18:08:00+00:00
 - user: None

Weteran amerykańskiej armii unieszkodliwił mężczyznę, który groził nożem pracownikom i klientom w jednym z supermarketów sieci Walmart w Karolinie Południowej. W internecie opublikowano nagranie ze zdarzenia.

## USA: Nie przyszła na rozprawę. Sąd nakazał jej napisać esej na 30 stron
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-nie-przyszla-na-rozprawe-sad-nakazal-jej-napisac-esej-na-30-stron/](https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-nie-przyszla-na-rozprawe-sad-nakazal-jej-napisac-esej-na-30-stron/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 17:29:00+00:00
 - user: None

Amerykanka ze stanu Georgia uchylała się od pełnienia funkcji ławnika. Zamiast na rozprawę, kobieta wybrała się na wakacje na Dominikanę. W ramach nagany sąd nakazał jej napisać esej na temat znaczenia funkcjonowania ławy przysięgłych. Wypracowanie ma liczyć co najmniej 30 stron.

## Francja. Tragedia w Paryżu. Trzylatka zatrzasnęła się w pralce. Nie przeżyła
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/francja-tragedia-w-paryzu-trzylatka-zatrzasnela-sie-w-pralce-nie-przezyla/](https://www.polsatnews.pl/wiadomosc/2023-01-13/francja-tragedia-w-paryzu-trzylatka-zatrzasnela-sie-w-pralce-nie-przezyla/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 17:20:00+00:00
 - user: None

Ojciec trzyletniej dziewczynki znalazł ją zatrzaśniętą w pralce. Stan dziecka był krytyczny. Na miejsce natychmiast wezwano pogotowie, jednak życia dziecka nie udało się uratować. W sprawie wszczęto śledztwo.

## Japonia: Spuszczą do morza radioaktywną wodę z Fukushimy jeszcze w tym roku
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/japonia-spuszcza-do-morza-radioaktywna-wode-z-fukushimy-jeszcze-w-tym-roku/](https://www.polsatnews.pl/wiadomosc/2023-01-13/japonia-spuszcza-do-morza-radioaktywna-wode-z-fukushimy-jeszcze-w-tym-roku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 15:40:00+00:00
 - user: None

Rząd Japonii zapowiedział, że jeszcze w tym roku spuści do morza ponad milion litrów wody zanieczyszczonej substancjami promieniotwórczymi ze zniszczonego bloku elektrowni jądrowej Fukushima. Zaniepokojenie decyzją wyraziły Korea Południowa oraz Chiny. O swój biznes obawiają się także miejscowi rybacy.

## USA: Nagie zdjęcia księdza w kościelnej drukarce. W jego komputerze dziecięca pornografia
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-nagie-zdjecia-ksiedza-w-koscielnej-drukarce-w-jego-komputerze-dziecieca-pornografia/](https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-nagie-zdjecia-ksiedza-w-koscielnej-drukarce-w-jego-komputerze-dziecieca-pornografia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 12:41:00+00:00
 - user: None

72-letni duchowny z USA przez kilkanaście lat przeglądał komputerowe prezentacje z dziecięcą pornografią i uzupełniał je o kolejne fotografie. O jego pedofilskich skłonnościach dowiedzieli się współpracownicy z parafii po tym, jak w drukarce pozostawił swoje nagie zdjęcia. Przed wydaniem wyroku sąd usłyszał apel, by nie osadzać księdza w więzieniu, lecz pozwolić mu na pobyt w specjalnym ośrodku.

## Rosja: Władimir Putin uderza w ministra handlu i przemysłu. Chodzi o samoloty bojowe
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/rosja-wladimir-putin-uderza-w-ministra-handlu-i-przemyslu-chodzi-o-samoloty-bojowe/](https://www.polsatnews.pl/wiadomosc/2023-01-13/rosja-wladimir-putin-uderza-w-ministra-handlu-i-przemyslu-chodzi-o-samoloty-bojowe/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 12:30:00+00:00
 - user: None

Prezydent Rosji podczas wideokonferencji skrytykował ministra Denisa Manturowa za zamówienie zbyt małej liczby samolotów wojskowych na wojnę w Ukrainie. - Dlaczego udajesz głupka? - spytał wyraźnie zirytowany Władimir Putin. Jak przekazują media, wybuch zdradza frustrację prezydenta z powodu sytuacji na ukraińskim froncie.

## Chiny. Lwica chciała pożreć dziecko. Na przeszkodzie stanęła szyba
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/chiny-lwica-chciala-pozrec-dziecko-na-przeszkodzie-stanela-szyba/](https://www.polsatnews.pl/wiadomosc/2023-01-13/chiny-lwica-chciala-pozrec-dziecko-na-przeszkodzie-stanela-szyba/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 11:34:00+00:00
 - user: None

Podczas wizyty w zoo lwica próbowała pożreć małe dziecko. Sytuacja wyglądała bardzo groźnie, na szczęście zwierzę i chłopca dzieliła gruba szyba. Całe zdarzenie nagrała matka, która zachowała zimną krew.

## Chiny. Spotykają się po trzech latach. Rozdzielił ich COVID-19
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/chiny-spotykaja-sie-po-trzech-latach-rozdzielil-ich-covid-19/](https://www.polsatnews.pl/wiadomosc/2023-01-13/chiny-spotykaja-sie-po-trzech-latach-rozdzielil-ich-covid-19/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 10:50:00+00:00
 - user: None

W Chinach łączą się ze sobą członkowie rodzin, którzy nie widzieli się nawet trzy lata. Z powodu pandemii władze wprowadziły w marcu 2020 roku restrykcje, które w praktyce uniemożliwiały podróżowanie. Zniesiono je dopiero w ostatnią niedzielę. - W końcu mogłam wrócić - powiedziała 54-letnia Chu Wenhong po powrocie z Singapuru do Szanghaju. Chciała ujrzeć 83-letniego ojca i 78-letnią matkę.

## Meksyk. Matki szukają synów. Odnalazły setki ciał ofiar karteli narkotykowych
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/meksyk-odnaleziono-1520-cial-ofiar-karteli-narkotykowych-nasz-kraj-jest-zbiorowa-mogila/](https://www.polsatnews.pl/wiadomosc/2023-01-13/meksyk-odnaleziono-1520-cial-ofiar-karteli-narkotykowych-nasz-kraj-jest-zbiorowa-mogila/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 10:13:00+00:00
 - user: None

Organizacja Matek Poszukujących na Sonorze odnalazła od 2019 roku 1520 ciał ofiar karteli narkotykowych. - Cały nasz kraj jest jedną zbiorową mogiłą - powiedziała szefowa stowarzyszenia Cecilia Flores, która od lat szuka swoich zaginionych synów. Władze Meksyku szacują, że od 2015 r. w tym kraju zaginęło ponad 150 tys. osób. Ciała udało się odnaleźć w 43 proc. przypadków.

## Ołeksij Reznikow: Ukraina jest de facto członkiem NATO
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/oleksij-reznikow-ukraina-jest-de-facto-czlonkiem-nato/](https://www.polsatnews.pl/wiadomosc/2023-01-13/oleksij-reznikow-ukraina-jest-de-facto-czlonkiem-nato/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 08:23:00+00:00
 - user: None

- Ukraina jako kraj i jej armia stały się członkiem NATO. De facto, a nie zgodnie z prawem - stwierdził ukraiński minister obrony Ołeksij Reznikow, nawiązując do dostaw broni dla Kijowa. Mówił również, że Rosja szykuje się do wiosennej ofensywy, na potrzeby której może szukać przymusowych żołnierzy i broni na okupowanych terenach.

## Węgry: Budapeszt. Atak nożownika. Nie żyje policjant
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/wegry-atak-nozownika-w-budapeszcie-nie-zyje-policjant/](https://www.polsatnews.pl/wiadomosc/2023-01-13/wegry-atak-nozownika-w-budapeszcie-nie-zyje-policjant/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 07:13:00+00:00
 - user: None

Mężczyzna zaatakował nożem policjantów próbujących powstrzymać go przed wejściem do jednego z mieszkań w Budapeszcie. Trzech funkcjonariuszy zostało rannych, jeden z nich zmarł po przewiezieniu do szpitala - przekazały węgierskie służby. Napastnika postrzelono podczas ucieczki.

## ISW: Rosja prawdopodobnie zdobyła Sołedar. Ukraińska armia zaprzecza
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/isw-rosja-prawdopodobnie-zdobyla-soledar-ukrainska-armia-zaprzecza/](https://www.polsatnews.pl/wiadomosc/2023-01-13/isw-rosja-prawdopodobnie-zdobyla-soledar-ukrainska-armia-zaprzecza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 07:07:00+00:00
 - user: None

Siły rosyjskie prawdopodobnie zdobyły Sołedar - informuje amerykański think tank Instytut Studiów nad Wojną (ISW). Doniesieniom tym zaprzecza ukraiński sztab. W czwartek wieczorem prezydent Wołodymyr Zełenski przekazał, że kremlowscy propagandyści próbują udawać zdobycie miasta, by wesprzeć mobilizację w Rosji.

## USA. Zmarła córka Elvisa. Lisa Marie Presley miała 54 lata
 - [https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-zmarla-corka-elvisa-lisa-marie-presley-miala-54-lata/](https://www.polsatnews.pl/wiadomosc/2023-01-13/usa-zmarla-corka-elvisa-lisa-marie-presley-miala-54-lata/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-13 05:04:00+00:00
 - user: None

Lisa Marie Presley została w czwartek przewieziona do szpitala z zatrzymaniem akcji serca i zmarła. Opuściła nas moja piękna córka Lisa Marie - napisała w oświadczeniu jej matka, Priscilla Presley. Córka legendy rocknrolla Elvisa Presleya, jego jedyne dziecko, miała 54 lata.
