# Source IT hardware PL, Source URL:https://ithardware.pl/feed, Source language: pl-PL

## Konsola PlayStation zawiesza się. Powód zaskakuje
 - [https://ithardware.pl/aktualnosci/konsola_playstation_zawiesza_sie_powod_zaskakuje-25297.html](https://ithardware.pl/aktualnosci/konsola_playstation_zawiesza_sie_powod_zaskakuje-25297.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 21:13:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25297_1.jpg" />            Po aktualizacji oprogramowania systemowego PlayStation 5 zawiesza się podczas grania, a pow&oacute;d może być zaskakujący, chodzi bowiem o nowe warunki korzystania z usługi PlayStation Network.

Sony udostępniło ostatnio nową aktualizację dla...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/konsola_playstation_zawiesza_sie_powod_zaskakuje-25297.html">https://ithardware.pl/aktualnosci/konsola_playstation_zawiesza_sie_powod_zaskakuje-25297.html</a></p>

## Gears of War Remastered Collection. Projekt żyje i może zostać zaprezentowany niebawem
 - [https://ithardware.pl/aktualnosci/gears_of_war_remastered_collection_projekt_zyje_i_moze_zostac_zaprezentowany_niebawem-25296.html](https://ithardware.pl/aktualnosci/gears_of_war_remastered_collection_projekt_zyje_i_moze_zostac_zaprezentowany_niebawem-25296.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 18:30:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25296_1.jpg" />            Gears of War może powr&oacute;cić, ale nie za sprawą pełnoprawej nowej odsłony tylko kolekcji remaster&oacute;w poprzednich części. Projekt podobno pozostaje żywy i zostanie zaprezentowany wkr&oacute;tce.

O Gears of War od pewnego czasu jest...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gears_of_war_remastered_collection_projekt_zyje_i_moze_zostac_zaprezentowany_niebawem-25296.html">https://ithardware.pl/aktualnosci/gears_of_war_remastered_collection_projekt_zyje_i_moze_zostac_zaprezentowany_niebawem-25296.html</a></p>

## NVIDIA i Google wyrażają obawy związane z przejęciem Activision Blizzard przez Microsoft
 - [https://ithardware.pl/aktualnosci/nvidia_i_google_wyrazaja_obawy_zwiazane_z_przejeciem_activision_blizzard_przez_microsoft-25295.html](https://ithardware.pl/aktualnosci/nvidia_i_google_wyrazaja_obawy_zwiazane_z_przejeciem_activision_blizzard_przez_microsoft-25295.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 16:30:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25295_1.jpg" />            Google i NVIDIA dołączyły do grona krytykujących przejęcie Activision Blizzard przez Microsoft. Firmy wyraziły zaniepokojenie przewagą, jaką producent z Redmond może mieć na rynku chmury, gier mobilnych oraz subskrypcji.

Jak informuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_i_google_wyrazaja_obawy_zwiazane_z_przejeciem_activision_blizzard_przez_microsoft-25295.html">https://ithardware.pl/aktualnosci/nvidia_i_google_wyrazaja_obawy_zwiazane_z_przejeciem_activision_blizzard_przez_microsoft-25295.html</a></p>

## Hikvision G4000E. Trwały dysk SSD z TBW 1800 TB dla wymagających
 - [https://ithardware.pl/artykuly/hikvision_g4000e_trwaly_dysk_ssd_z_tbw_1800_tb_dla_wymagajacych-25291.html](https://ithardware.pl/artykuly/hikvision_g4000e_trwaly_dysk_ssd_z_tbw_1800_tb_dla_wymagajacych-25291.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25291_1.jpg" />            Wprowadzenie na rynek pierwszych konsumenckich dysk&oacute;w SSD przez wielu uważane jest za największą innowację ostatniej dekady. Przez ten okres p&oacute;łprzewodnikowe nośniki danych wyparły uważane w&oacute;wczas za standardowe dyski HDD...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/hikvision_g4000e_trwaly_dysk_ssd_z_tbw_1800_tb_dla_wymagajacych-25291.html">https://ithardware.pl/artykuly/hikvision_g4000e_trwaly_dysk_ssd_z_tbw_1800_tb_dla_wymagajacych-25291.html</a></p>

## Bill Gates zdradził Microsoft. Stawia na składany smartfon Samsunga
 - [https://ithardware.pl/aktualnosci/bill_gates_zdradzil_microsoft_stawia_na_skladany_smartfon_samsunga-25293.html](https://ithardware.pl/aktualnosci/bill_gates_zdradzil_microsoft_stawia_na_skladany_smartfon_samsunga-25293.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 13:22:40+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25293_1.jpg" />            Skoro nawet przedstawiciele największych producent&oacute;w smartfon&oacute;w regularnie dają się złapać na korzystaniu z rozwiązań konkurencji, to Bill Gates chwalący składane smartfony Samsunga nie powinien być dla nikogo wybitnym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/bill_gates_zdradzil_microsoft_stawia_na_skladany_smartfon_samsunga-25293.html">https://ithardware.pl/aktualnosci/bill_gates_zdradzil_microsoft_stawia_na_skladany_smartfon_samsunga-25293.html</a></p>

## Ubisoft podobno „został wyśmiany”, gdy proponował fuzje / przejęcia
 - [https://ithardware.pl/aktualnosci/ubisoft_podobno_zostal_wysmiany_gdy_proponowal_fuzje_przejecia-25292.html](https://ithardware.pl/aktualnosci/ubisoft_podobno_zostal_wysmiany_gdy_proponowal_fuzje_przejecia-25292.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 12:27:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25292_1.jpg" />            W ostatnim czasie można zaobserwować pewien trend wchłaniania mniejszych deweloper&oacute;w i wydawc&oacute;w przez gigant&oacute;w branży. Wystarczy spojrzeń na ostatnie działania Microsoftu, kt&oacute;ry przejął kilku naprawdę poważnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ubisoft_podobno_zostal_wysmiany_gdy_proponowal_fuzje_przejecia-25292.html">https://ithardware.pl/aktualnosci/ubisoft_podobno_zostal_wysmiany_gdy_proponowal_fuzje_przejecia-25292.html</a></p>

## Byli dyrektorzy Twittera wezwani do złożenia zeznań w sprawie cenzury. Musk włożył kij w mrowisko
 - [https://ithardware.pl/aktualnosci/byli_dyrektorzy_twittera_wezwani_do_zlozenia_zeznan_w_sprawie_cenzury_musk_wlozyl_kij_w_mrowisko-25290.html](https://ithardware.pl/aktualnosci/byli_dyrektorzy_twittera_wezwani_do_zlozenia_zeznan_w_sprawie_cenzury_musk_wlozyl_kij_w_mrowisko-25290.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 11:24:40+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25290_1.jpg" />            Przewodniczący Komisji Nadzoru Izby Reprezentant James Comer wezwał byłe kierownictwo&nbsp;Twittera&nbsp;do złożenia oficjalnych zeznań w sprawie cenzury raport&oacute;w New York Post dotyczących laptopa Huntera Bidena.

Twitter ograniczył...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/byli_dyrektorzy_twittera_wezwani_do_zlozenia_zeznan_w_sprawie_cenzury_musk_wlozyl_kij_w_mrowisko-25290.html">https://ithardware.pl/aktualnosci/byli_dyrektorzy_twittera_wezwani_do_zlozenia_zeznan_w_sprawie_cenzury_musk_wlozyl_kij_w_mrowisko-25290.html</a></p>

## Nadchodzący EV Xiaomi to średniej wielkości sedan. Poznaliśmy więcej szczegółów oraz ceny
 - [https://ithardware.pl/aktualnosci/nadchodzacy_ev_xiaomi_to_sredniej_wielkosci_sedan_poznalismy_wiecej_szczegolow_oraz_ceny-25289.html](https://ithardware.pl/aktualnosci/nadchodzacy_ev_xiaomi_to_sredniej_wielkosci_sedan_poznalismy_wiecej_szczegolow_oraz_ceny-25289.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 10:44:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25289_1.jpg" />            Wiadomo już, że Xiaomi przygotowuje sw&oacute;j pierwszy samoch&oacute;d elektryczny.&nbsp;Teraz pojawiają się jednak bardziej szczeg&oacute;łowe informacje na temat systemu autonomicznej jazdy i innych funkcji auta, kt&oacute;re do sprzedaży ma...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nadchodzacy_ev_xiaomi_to_sredniej_wielkosci_sedan_poznalismy_wiecej_szczegolow_oraz_ceny-25289.html">https://ithardware.pl/aktualnosci/nadchodzacy_ev_xiaomi_to_sredniej_wielkosci_sedan_poznalismy_wiecej_szczegolow_oraz_ceny-25289.html</a></p>

## Corsair przygotowuje nową serię zasilaczy ze złączami umieszczonymi z boku
 - [https://ithardware.pl/aktualnosci/corsair_przygotowuje_nowa_serie_zasilaczy_ze_zlaczami_umieszczonymi_z_boku-25287.html](https://ithardware.pl/aktualnosci/corsair_przygotowuje_nowa_serie_zasilaczy_ze_zlaczami_umieszczonymi_z_boku-25287.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 10:37:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25287_1.jpg" />            Corsair tworzy nową linię zasilaczy, znaną jako seria RMx Shift, kt&oacute;ra ma na celu przeniesienie wewnętrznych złączy zasilania z tyłu zasilacza na bok. Ta zmiana konstrukcyjna ma na celu poprawę zarządzania kablami poprzez udostępnienie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_przygotowuje_nowa_serie_zasilaczy_ze_zlaczami_umieszczonymi_z_boku-25287.html">https://ithardware.pl/aktualnosci/corsair_przygotowuje_nowa_serie_zasilaczy_ze_zlaczami_umieszczonymi_z_boku-25287.html</a></p>

## Acer Predator GM7 SSD korzysta z innowacyjnych chińskich pamięci i ma przez to duży problem
 - [https://ithardware.pl/aktualnosci/acer_predator_gm7_ssd_korzysta_w_innowacyjnych_chinskich_pamieci_i_ma_przez_to_duzy_problem-25288.html](https://ithardware.pl/aktualnosci/acer_predator_gm7_ssd_korzysta_w_innowacyjnych_chinskich_pamieci_i_ma_przez_to_duzy_problem-25288.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 10:28:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25288_1.jpg" />            Acer, a właściwie licencjobiorca marki firma&nbsp;Biwin Technology, pokazała jeden z najciekawszych dysk&oacute;w SSD tegorocznych targ&oacute;w CES 2023.&nbsp;Acer Predator GM7 SSD zbudowany jest w oparciu o pamięć flash chińskiego producenta...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/acer_predator_gm7_ssd_korzysta_w_innowacyjnych_chinskich_pamieci_i_ma_przez_to_duzy_problem-25288.html">https://ithardware.pl/aktualnosci/acer_predator_gm7_ssd_korzysta_w_innowacyjnych_chinskich_pamieci_i_ma_przez_to_duzy_problem-25288.html</a></p>

## AMD naprawia firmware, który wyłączał rdzenie w Ryzenach
 - [https://ithardware.pl/aktualnosci/amd_naprawia_firmware_ktory_wylaczal_rdzenie_w_ryzenach-25286.html](https://ithardware.pl/aktualnosci/amd_naprawia_firmware_ktory_wylaczal_rdzenie_w_ryzenach-25286.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 09:11:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25286_1.jpg" />            Ryzen 5 7600X to jeden z najlepszych procesor&oacute;w dla os&oacute;b z ograniczonym budżetem, jednak firmware AMD AGESA ComboAM5PI 1.0.0.4 z SMU 84.79.204 przypadkowo wyłączył rdzenie w tych CPU z podw&oacute;jnymi CCD. Wygląda jednak na to, że...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_naprawia_firmware_ktory_wylaczal_rdzenie_w_ryzenach-25286.html">https://ithardware.pl/aktualnosci/amd_naprawia_firmware_ktory_wylaczal_rdzenie_w_ryzenach-25286.html</a></p>

## Microsoft DirectStorage - testy wykazują bardzo duży wzrost prędkości transferów
 - [https://ithardware.pl/aktualnosci/microsoft_directstorage_testy_wykazuja_bardzo_duzy_wzrost_predkosci_transferow-25285.html](https://ithardware.pl/aktualnosci/microsoft_directstorage_testy_wykazuja_bardzo_duzy_wzrost_predkosci_transferow-25285.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 08:28:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25285_1.jpg" />            API Microsoft DirectStorage obiecuje ultraszybkie czasy ładowania w grach na PC, podobne do tego, jakiego doświadczają użytkownicy konsol Xbox Series i PlayStation 5 od dw&oacute;ch lat. Ponieważ pierwsza gra obsługująca DirectStorage przygotowuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/microsoft_directstorage_testy_wykazuja_bardzo_duzy_wzrost_predkosci_transferow-25285.html">https://ithardware.pl/aktualnosci/microsoft_directstorage_testy_wykazuja_bardzo_duzy_wzrost_predkosci_transferow-25285.html</a></p>

## Błąd w systemie mailowej weryfikacji NVIDII nie pozwala się zalogować do GeForce Experience i Now
 - [https://ithardware.pl/aktualnosci/blad_w_systemie_mailowej_weryfikacji_nvidii_nie_pozwala_sie_zalogowac_do_geforce_experience_i_now-25284.html](https://ithardware.pl/aktualnosci/blad_w_systemie_mailowej_weryfikacji_nvidii_nie_pozwala_sie_zalogowac_do_geforce_experience_i_now-25284.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 07:19:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25284_1.jpg" />            Czasami mała usterka powoduje poważne problemy. Wczoraj błąd w systemie weryfikacji adresu e-mail w usługach NVIDII zablokował użytkownikom dostęp do usług GeForce Experience i GeForce Now. W rezultacie niekt&oacute;rzy użytkownicy nie mogą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/blad_w_systemie_mailowej_weryfikacji_nvidii_nie_pozwala_sie_zalogowac_do_geforce_experience_i_now-25284.html">https://ithardware.pl/aktualnosci/blad_w_systemie_mailowej_weryfikacji_nvidii_nie_pozwala_sie_zalogowac_do_geforce_experience_i_now-25284.html</a></p>

## Premiera flagowego procesora Intel Core i9-13900KS. Cena zaskakuje
 - [https://ithardware.pl/aktualnosci/premiera_flagowego_procesora_intel_core_i9_13900ks_cena_zaskakuje-25283.html](https://ithardware.pl/aktualnosci/premiera_flagowego_procesora_intel_core_i9_13900ks_cena_zaskakuje-25283.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-13 05:50:41+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25283_1.jpg" />            Intel zgodnie z planem wypuścił sw&oacute;j najnowszy flagowy procesor z rodziny Raptor Lake, czyli 24-rdzeniowy i 32-wątkowy Core i9-13900KS. Tym samym poznaliśmy sugerowaną cenę tego CPU i ta pozytywnie zaskakuje, bo jest niższa niż w przypadku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/premiera_flagowego_procesora_intel_core_i9_13900ks_cena_zaskakuje-25283.html">https://ithardware.pl/aktualnosci/premiera_flagowego_procesora_intel_core_i9_13900ks_cena_zaskakuje-25283.html</a></p>
