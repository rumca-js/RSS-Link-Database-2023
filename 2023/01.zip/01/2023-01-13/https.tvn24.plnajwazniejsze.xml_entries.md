# Source TNV24 Najważniejsze, Source URL:https://tvn24.pl/najwazniejsze.xml, Source language: pl-PL

## Polski biolog zwolniony z irańskiego więzienia, wrócił do kraju. "Jest cały i zdrowy"
 - [https://tvn24.pl/polska/iran-polska-msz-biolog-z-torunia-przetrzymywany-w-wiezieniu-w-iranie-wrocil-w-grudniu-do-kraju-6628878?source=rss](https://tvn24.pl/polska/iran-polska-msz-biolog-z-torunia-przetrzymywany-w-wiezieniu-w-iranie-wrocil-w-grudniu-do-kraju-6628878?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:44:30+00:00
 - user: None

<img alt="Polski biolog zwolniony z irańskiego więzienia, wrócił do kraju. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jre6n7-teheran-iran-6625119/alternates/LANDSCAPE_1280" />
    Poinformował w piątek rzecznik resortu dyplomacji Łukasz Jasina.

## ONZ: ponad 30 mln niedożywionych dzieci na świecie
 - [https://tvn24.pl/swiat/onz-ponad-30-mln-niedozywionych-dzieci-na-swiecie-6628896?source=rss](https://tvn24.pl/swiat/onz-ponad-30-mln-niedozywionych-dzieci-na-swiecie-6628896?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:41:27+00:00
 - user: None

<img alt="ONZ: ponad 30 mln niedożywionych dzieci na świecie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hd4vk0-onz-alarmuje-w-sprawie-niedozywionych-dzieci-6628897/alternates/LANDSCAPE_1280" />
    Agendy apelują o przyspieszenie wprowadzenia w życie globalnego planu przeciwdziałania tej sytuacji.

## Szczęsny pokonany pięć razy. Napoli upokorzyło Juventus
 - [https://eurosport.tvn24.pl/szcz-sny-pokonany-pi---razy--napoli-upokorzy-o-juventus,1132743.html?source=rss](https://eurosport.tvn24.pl/szcz-sny-pokonany-pi---razy--napoli-upokorzy-o-juventus,1132743.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:41:27+00:00
 - user: None

<img alt="Szczęsny pokonany pięć razy. Napoli upokorzyło Juventus" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4kr9le-napoli-nie-mialo-litosci-dla-juventusu/alternates/LANDSCAPE_1280" />
    Kolejka włoskiej ekstraklasy rozpoczęła się od meczu na szczycie.

## Ziobro przegrywa z "Czarno na białym". Chciał "sprostować" krytyczną opinię
 - [https://tvn24.pl/polska/ziobro-przegrywa-z-czarno-na-bialym-chcial-sprostowac-krytyczna-opinie-6628892?source=rss](https://tvn24.pl/polska/ziobro-przegrywa-z-czarno-na-bialym-chcial-sprostowac-krytyczna-opinie-6628892?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:37:59+00:00
 - user: None

<img alt="Ziobro przegrywa z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lbo40g-zbigniew-ziobro-6628893/alternates/LANDSCAPE_1280" />
    Redaktor naczelny "Czarno na białym" TVN24 nie musi publikować oświadczenia Zbigniewa Ziobry, które ten nazwał sprostowaniem.

## "Jeżeli nawet za cenę swojego życia możemy uratować kolejne 50 czy 100 osób, to dla nas rachunek był prosty"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-szef-polskiego-zespolu-medykow-czasami-sa-takie-obrazki-na-ktore-nawet-my-nie-jestesmy-przygotowani-6628837?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-szef-polskiego-zespolu-medykow-czasami-sa-takie-obrazki-na-ktore-nawet-my-nie-jestesmy-przygotowani-6628837?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:15:20+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uwmkig-13-1930-fpf-cl-0036-6628759/alternates/LANDSCAPE_1280" />
    Damian Duda, szef ochotniczego zespołu medyków pola walki "W międzyczasie", w "Faktach po Faktach" w TVN24.

## Sejm apeluje o "umożliwienia Micheilowi Saakszwilemu podjęcia niezbędnego, specjalistycznego leczenia"
 - [https://tvn24.pl/swiat/gruzja-sejm-rp-apeluje-w-uchwale-o-umozliwienie-micheilowi-saakszwilemu-podjecia-niezbednego-specjalistycznego-leczenia-6628833?source=rss](https://tvn24.pl/swiat/gruzja-sejm-rp-apeluje-w-uchwale-o-umozliwienie-micheilowi-saakszwilemu-podjecia-niezbednego-specjalistycznego-leczenia-6628833?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 21:01:09+00:00
 - user: None

<img alt="Sejm apeluje o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ctabx9-micheil-saakszwili-w-szpitalu-6628869/alternates/LANDSCAPE_1280" />
    Sejm RP zwrócił się w uchwale też do społeczności międzynarodowej o ratowanie życia i zdrowia byłego prezydenta Gruzji.

## Czarna dziura przerobiła gwiazdę na pączek z dziurką
 - [https://tvn24.pl/tvnmeteo/nauka/czarna-dziura-rozerwala-gwiazde-zarejestrowal-to-teleskop-hubblea-6628454?source=rss](https://tvn24.pl/tvnmeteo/nauka/czarna-dziura-rozerwala-gwiazde-zarejestrowal-to-teleskop-hubblea-6628454?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 20:34:22+00:00
 - user: None

<img alt="Czarna dziura przerobiła gwiazdę na pączek z dziurką" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-bgggc4-czarna-dziura-pozerajaca-gwiazde-wizja-artystyczna-6628480/alternates/LANDSCAPE_1280" />
    Świadkiem "kosmicznej zbrodni" był Teleskop Kosmiczny Hubble'a.

## Wygrał on, wygrała jego dziewczyna. "Piątek trzynastego wyjątkowym dniem"
 - [https://eurosport.tvn24.pl/wygra--on--wygra-a-jego-dziewczyna---pi-tek-trzynastego-wyj-tkowym-dniem-,1132714.html?source=rss](https://eurosport.tvn24.pl/wygra--on--wygra-a-jego-dziewczyna---pi-tek-trzynastego-wyj-tkowym-dniem-,1132714.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 20:31:00+00:00
 - user: None

<img alt="Wygrał on, wygrała jego dziewczyna. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f6l6af-daniel-tschofenig-wygral-kwalifikacje-w-zakopanem/alternates/LANDSCAPE_1280" />
    Wygrał w Zakopanem swoje pierwsze w karierze kwalifikacje do konkursu Pucharu Świata.

## Meksykanie ukarani za wydarzenia z meczu z Polską
 - [https://eurosport.tvn24.pl/meksykanie-ukarani-za-wydarzenia-z-meczu-z-polsk---raczej-nie-upiecze-si--te--mistrzom--wiata,1132729.html?source=rss](https://eurosport.tvn24.pl/meksykanie-ukarani-za-wydarzenia-z-meczu-z-polsk---raczej-nie-upiecze-si--te--mistrzom--wiata,1132729.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 20:06:00+00:00
 - user: None

<img alt="Meksykanie ukarani za wydarzenia z meczu z Polską" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r9jxcs-meksyk-zremisowal-z-polska-6233816/alternates/LANDSCAPE_1280" />
    Raczej nie upiecze się też mistrzom świata.

## Do wyborów razem czy osobno? Pytania o stopień zjednoczenia rządowej koalicji i opozycji
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-jak-pojdzie-opozycja-a-jak-zjednoczona-prawica-andrzej-rozenek-i-marcin-ociepa-w-programie-kampania-bezkitu-6628547?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-jak-pojdzie-opozycja-a-jak-zjednoczona-prawica-andrzej-rozenek-i-marcin-ociepa-w-programie-kampania-bezkitu-6628547?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 20:02:02+00:00
 - user: None

<img alt="Do wyborów razem czy osobno? Pytania o stopień zjednoczenia rządowej koalicji i opozycji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pcubdx-bez-kitu-6628767/alternates/LANDSCAPE_1280" />
    Program "Kampania #BezKitu".

## Spór o paski z projektantem. Adidas przegrał w sądzie
 - [https://tvn24.pl/biznes/ze-swiata/spor-o-paski-adidas-kontra-thom-browne-gigant-odziezowy-przegral-w-sadzie-6628629?source=rss](https://tvn24.pl/biznes/ze-swiata/spor-o-paski-adidas-kontra-thom-browne-gigant-odziezowy-przegral-w-sadzie-6628629?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 19:27:49+00:00
 - user: None

<img alt="Spór o paski z projektantem. Adidas przegrał w sądzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1r6g09-forum-0747480201-6628639/alternates/LANDSCAPE_1280" />
    Adidas kontra Thom Browne.

## Do celu państwowej spółki sporo zabrakło. Tyle gazu trafiło do Polski przez Baltic Pipe
 - [https://tvn24.pl/biznes/z-kraju/gaz-ziemny-ile-gazu-przeslano-przez-baltic-pipe-w-2022-roku-dane-gaz-system-stanowisko-pgnig-6628475?source=rss](https://tvn24.pl/biznes/z-kraju/gaz-ziemny-ile-gazu-przeslano-przez-baltic-pipe-w-2022-roku-dane-gaz-system-stanowisko-pgnig-6628475?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 19:09:52+00:00
 - user: None

<img alt="Do celu państwowej spółki sporo zabrakło. Tyle gazu trafiło do Polski przez Baltic Pipe" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-oo1h2u-baltic-pipe-5125424/alternates/LANDSCAPE_1280" />
    Na pytania TVN24 Biznes odpowiedziały PGNiG i Gaz-System.

## "Tama chroniąca miasto zaczęła powoli się zapadać". Ogłoszono ewakuację
 - [https://tvn24.pl/tvnmeteo/swiat/lotwa-powodz-ewakuowano-czesc-mieszkancow-jekabpils-6628513?source=rss](https://tvn24.pl/tvnmeteo/swiat/lotwa-powodz-ewakuowano-czesc-mieszkancow-jekabpils-6628513?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 19:08:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-jtzk0z-mieszkancy-miasta-jekabpils-ewakuowani-z-powodu-powodzi-6628542/alternates/LANDSCAPE_1280" />
    Powódź na Łotwie.

## "Kto z was zrobił krok wstecz w waszej zaciętej nienawiści? Kto z was zrozumiał, że słowo zabija?"
 - [https://tvn24.pl/polska/gdansk-mijaja-cztery-lata-od-ataku-na-pawla-adamowicza-uroczystosci-w-rocznice-glos-zabrala-rodzina-prezydenta-6628744?source=rss](https://tvn24.pl/polska/gdansk-mijaja-cztery-lata-od-ataku-na-pawla-adamowicza-uroczystosci-w-rocznice-glos-zabrala-rodzina-prezydenta-6628744?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 19:06:10+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pu2sce-gdansk-6628747/alternates/LANDSCAPE_1280" />
    W miejscu, gdzie cztery lata temu doszło do brutalnego ataku na prezydenta, przed tablicą pamiątkową wymurowaną w pierwszą rocznicę zamachu, hołd Adamowiczowi złożyła prezydent Gdańska oraz najbliżsi zmarłego.

## Oskarżony o liczne gwałty piłkarz Manchesteru City uniewinniony z części zarzutów
 - [https://eurosport.tvn24.pl/oskar-ony-o-liczne-gwa-ty-pi-karz-manchesteru-city-uniewinniony-z-cz--ci-zarzut-w,1132670.html?source=rss](https://eurosport.tvn24.pl/oskar-ony-o-liczne-gwa-ty-pi-karz-manchesteru-city-uniewinniony-z-cz--ci-zarzut-w,1132670.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:44:16+00:00
 - user: None

<img alt="Oskarżony o liczne gwałty piłkarz Manchesteru City uniewinniony z części zarzutów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fflzol-benjamin-mendy-caly-czas-ma-powazne-problemy/alternates/LANDSCAPE_1280" />
    Bardzo ważne werdykty dla piłkarza Benjamina Mendy'ego.

## Tylko on nie awansował do konkursu. Do zwycięzcy stracił 90,7 punktu
 - [https://eurosport.tvn24.pl/to-on-jako-jedyny-nie-awansowa--do-konkursu--do-zwyci-zcy-straci--90-7-punktu,1132677.html?source=rss](https://eurosport.tvn24.pl/to-on-jako-jedyny-nie-awansowa--do-konkursu--do-zwyci-zcy-straci--90-7-punktu,1132677.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:32:00+00:00
 - user: None

<img alt="Tylko on nie awansował do konkursu. Do zwycięzcy stracił 90,7 punktu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ajflof-frantisek-lejsek-w-zakopanem/alternates/LANDSCAPE_1280" />
    Największy pechowiec piątkowych zmagań w Zakopanem.

## Trener Polaków podał skład na drużynówkę. Jeden skoczek może być rozczarowany
 - [https://eurosport.tvn24.pl/trener-polak-w-poda--sk-ad-na-dru-yn-wk---jeden-z-zawodnik-w-mo-e-by--zawiedziony,1132697.html?source=rss](https://eurosport.tvn24.pl/trener-polak-w-poda--sk-ad-na-dru-yn-wk---jeden-z-zawodnik-w-mo-e-by--zawiedziony,1132697.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:17:00+00:00
 - user: None

<img alt="Trener Polaków podał skład na drużynówkę. Jeden skoczek może być rozczarowany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7i625k-kubacki-i-zyla-skacza-wspaniale-6570271/alternates/LANDSCAPE_1280" />
    Zakopane ugości w sobotę pierwszy tej zimy konkurs drużynowy w Pucharze Świata.

## "Szturmowe oddziały Wagnera atakują cały czas". Bitwy o Sołedar i Bachmut trwają
 - [https://fakty.tvn24.pl/-szturmowe-oddzia-y-wagnera-atakuj--ca-y-czas---bitwy-o-so-edar-i-bachmut-trwaj-,1132687.html?source=rss](https://fakty.tvn24.pl/-szturmowe-oddzia-y-wagnera-atakuj--ca-y-czas---bitwy-o-so-edar-i-bachmut-trwaj-,1132687.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:12:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jl7pya-szturmowe-oddzialy-wagnera-atakuja-caly-czas-bitwy-o-soledar-i-bachmut-trwaja/alternates/LANDSCAPE_1280" />
    Rosjanie kłamią, ponoszą ciężkie straty.

## Awanse dla członków neo-KRS bis kojarzonych z aferą hejterską. Partner szefowej Rady sędzią Sądu Najwyższego
 - [https://tvn24.pl/polska/prezydent-wreczyl-nominacje-sedziowskie-awanse-dla-czlonkow-neo-krs-bis-kojarzonych-z-afera-hejterska-partner-szefowej-rady-sedzia-sadu-najwyzszego-6628508?source=rss](https://tvn24.pl/polska/prezydent-wreczyl-nominacje-sedziowskie-awanse-dla-czlonkow-neo-krs-bis-kojarzonych-z-afera-hejterska-partner-szefowej-rady-sedzia-sadu-najwyzszego-6628508?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:11:03+00:00
 - user: None

<img alt="Awanse dla członków neo-KRS bis kojarzonych z aferą hejterską. Partner szefowej Rady sędzią Sądu Najwyższego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-01hfu9-nominacje-sedziowskie-w-palacu-prezydenckim-6628646/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda wręczył w piątek nominacje sędziowskie.

## Eksplozja gazociągu łączącego Litwę i Łotwę
 - [https://tvn24.pl/swiat/litwa-wybuch-gazociagu-laczacego-litwe-i-lotwe-6628648?source=rss](https://tvn24.pl/swiat/litwa-wybuch-gazociagu-laczacego-litwe-i-lotwe-6628648?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:06:22+00:00
 - user: None

<img alt="Eksplozja gazociągu łączącego Litwę i Łotwę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mjpovt-poswol-6628672/alternates/LANDSCAPE_1280" />
    Gazociąg dostarczał gaz do północnej części Litwy oraz na Łotwę.

## Kosmiczna prezentacja w Sejmie. "Ostatnią humanitarną bitwą była bitwa pod Koronowem"
 - [https://fakty.tvn24.pl/kosmiczna-prezentacja-w-sejmie---ostatni--humanitarn--bitw--by-a-bitwa-pod-koronowem-,1132695.html?source=rss](https://fakty.tvn24.pl/kosmiczna-prezentacja-w-sejmie---ostatni--humanitarn--bitw--by-a-bitwa-pod-koronowem-,1132695.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 18:06:00+00:00
 - user: None

<img alt="Kosmiczna prezentacja w Sejmie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wpvas7-kosmiczna-prezentacja-w-sejmie-ostatnia-humanitarna-bitwa-byla-bitwa-pod-koronowem/alternates/LANDSCAPE_1280" />
    Atak na Gwiazdę Śmierci, bitwa pod Koronowem, mem o rosyjskim imperializmie, a także roboty, celowniki i modele atomów. Kuriozalna prezentacja na posiedzeniu sejmowej Komisji Obrony Narodowej.

## "Z nieba spadły miliardy litrów wody". Nie żyje co najmniej 19 osób
 - [https://tvn24.pl/tvnmeteo/swiat/kalifornia-trwa-niszczycielska-seria-burz-do-tej-pory-zginelo-19-osob-6628274?source=rss](https://tvn24.pl/tvnmeteo/swiat/kalifornia-trwa-niszczycielska-seria-burz-do-tej-pory-zginelo-19-osob-6628274?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:55:49+00:00
 - user: None

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v7pb2x-powodzie-w-kalifornii-6628395/alternates/LANDSCAPE_1280" />
    Kalifornia w obliczu dylematu. Ulewy mają tragiczne skutki, ale susza też jest groźna.

## Zaskakujący zwycięzca kwalifikacji w Zakopanem
 - [https://eurosport.tvn24.pl/zaskakuj-cy-zwyci-zca-kwalifikacji-w-zakopanem--drugie-miejsca-dla-dawida-kubackiego,1132681.html?source=rss](https://eurosport.tvn24.pl/zaskakuj-cy-zwyci-zca-kwalifikacji-w-zakopanem--drugie-miejsca-dla-dawida-kubackiego,1132681.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:54:05+00:00
 - user: None

<img alt="Zaskakujący zwycięzca kwalifikacji w Zakopanem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-njsrxs-dawid-kubacki-jest-w-wysokiej-formie-6628654/alternates/LANDSCAPE_1280" />
    W zawodach indywidualnych weźmie udział sześciu Polaków. Konkurs w niedzielę.

## Firma Trumpa z karą za oszustwa podatkowe. "Jest dla niego drobnostką"
 - [https://tvn24.pl/swiat/usa-nowy-jork-sad-zasadzil-najwyzsza-kare-dla-firmy-donalda-trumpa-za-oszustwa-podatkowe-6628613?source=rss](https://tvn24.pl/swiat/usa-nowy-jork-sad-zasadzil-najwyzsza-kare-dla-firmy-donalda-trumpa-za-oszustwa-podatkowe-6628613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:46:24+00:00
 - user: None

<img alt="Firma Trumpa z karą za oszustwa podatkowe. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0truqi-trump-shutterstock2207727635-6215333/alternates/LANDSCAPE_1280" />
    Decyzja kończy trwającą od kilku lat sprawę przeciwko Trump Organization.

## Opłata cukrowa do poprawki. Ministerstwo wyjaśnia
 - [https://tvn24.pl/biznes/z-kraju/oplata-cukrowa-nowelizacja-przepisow-o-oplacie-od-srodkow-spozywczych-komunikat-ministerstwa-finansow-6628575?source=rss](https://tvn24.pl/biznes/z-kraju/oplata-cukrowa-nowelizacja-przepisow-o-oplacie-od-srodkow-spozywczych-komunikat-ministerstwa-finansow-6628575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:44:37+00:00
 - user: None

<img alt="Opłata cukrowa do poprawki. Ministerstwo wyjaśnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sc0rud-napoje-gazowane-podatek-oplata-cukrowa-5017575/alternates/LANDSCAPE_1280" />
    Komunikat resortu finansów.

## Donald Tusk: mowa nienawiści dzisiaj jest na absolutnym topie, jeśli chodzi o zagrożenia cywilizacyjne
 - [https://tvn24.pl/polska/donald-tusk-w-gdansku-o-mowie-nienawisci-jest-dzisiaj-na-topie-jesli-chodzi-o-zagrozenia-cywilizacyjne-6628591?source=rss](https://tvn24.pl/polska/donald-tusk-w-gdansku-o-mowie-nienawisci-jest-dzisiaj-na-topie-jesli-chodzi-o-zagrozenia-cywilizacyjne-6628591?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:40:31+00:00
 - user: None

<img alt="Donald Tusk: mowa nienawiści dzisiaj jest na absolutnym topie, jeśli chodzi o zagrożenia cywilizacyjne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ttayjp-donald-tusk-w-gdansku-6628635/alternates/LANDSCAPE_1280" />
    Lider Platformy Obywatelskiej w Gdańsku.

## WADA "zaniepokojona ustaleniami" Rosjan w sprawie Walijewej
 - [https://eurosport.tvn24.pl/wada---zaniepokojona-ustaleniami--rosjan-w-sprawie-walijewej,1132691.html?source=rss](https://eurosport.tvn24.pl/wada---zaniepokojona-ustaleniami--rosjan-w-sprawie-walijewej,1132691.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:21:00+00:00
 - user: None

<img alt="WADA " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a6izy2-kamila-walijewa/alternates/LANDSCAPE_1280" />
    Światowa Agencja Antydopingowa poinformowała o wynikach śledztwa.

## "Możemy zobaczyć jeszcze wielki comeback zimy w prawdziwie amerykańskim stylu"
 - [https://tvn24.pl/tvnmeteo/prognoza/czy-wroci-zima-prognoza-pogody-na-styczen-i-luty-jezor-zimna-moze-na-przelomie-stycznia-i-lutego-dosiegnac-polski-6628510?source=rss](https://tvn24.pl/tvnmeteo/prognoza/czy-wroci-zima-prognoza-pogody-na-styczen-i-luty-jezor-zimna-moze-na-przelomie-stycznia-i-lutego-dosiegnac-polski-6628510?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:15:22+00:00
 - user: None

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-xirpzt-mapki-drv-6628569/alternates/LANDSCAPE_1280" />
    Pogoda na resztę zimy 2022/2023 w blogu synoptyka tvnmeteo.pl Arlety Unton-Pyziołek.

## Wykład Hanny Machińskiej na UW planowano od października. O odwołaniu dowiedziała się od znajomej
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-wladzie-uniwersytetu-warszawskiego-odwolaly-wyklad-doktor-hanny-machinskiej-6628523?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-wladzie-uniwersytetu-warszawskiego-odwolaly-wyklad-doktor-hanny-machinskiej-6628523?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:13:01+00:00
 - user: None

<img alt="Wykład Hanny Machińskiej na UW planowano od października. O odwołaniu dowiedziała się od znajomej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wb3nxc-hanna-machinska-byla-zastepczyni-rpo-6584041/alternates/LANDSCAPE_1280" />
    Oficjalnym powodem są "przyczyny techniczne".

## Kto odziedziczy Graceland?
 - [https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-kto-odziedziczy-graceland-dom-elvisa-to-wazna-atrakcja-turystyczna-w-usa-6628315?source=rss](https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-kto-odziedziczy-graceland-dom-elvisa-to-wazna-atrakcja-turystyczna-w-usa-6628315?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 17:12:34+00:00
 - user: None

<img alt="Kto odziedziczy Graceland? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-q0yv43-memhis-presley-dom-shutterstock1608213076-6628344/alternates/LANDSCAPE_1280" />
    Dom Elvisa to jedna z największych atrakcji turystycznych na południu USA.

## "Ukraina potrzebuje myśliwców, Putin odnosi na niebie większe sukcesy niż na ziemi"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-byly-dowodca-nato-james-stavridis-ukraina-potrzebuje-mysliwcow-6628516?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-byly-dowodca-nato-james-stavridis-ukraina-potrzebuje-mysliwcow-6628516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:53:33+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9mh1ox-amerykanski-mysliwiec-f-16-6628550/alternates/LANDSCAPE_1280" />
    Były dowódca wojsk NATO w Europie James Stavridis wystąpił w programie niemieckiej stacji ZDF.

## Chcą przywrócenia aresztowanego prezydenta. 360 policjantów rannych po starciach
 - [https://tvn24.pl/swiat/protesty-w-peru-w-starciach-ze-zwolennikami-bylego-prezydenta-pedro-castillo-rannych-zostalo-360-policjantow-6628540?source=rss](https://tvn24.pl/swiat/protesty-w-peru-w-starciach-ze-zwolennikami-bylego-prezydenta-pedro-castillo-rannych-zostalo-360-policjantow-6628540?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:53:27+00:00
 - user: None

<img alt="Chcą przywrócenia aresztowanego prezydenta. 360 policjantów rannych po starciach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ayf5pf-policjanci-na-miejscu-protestu-przy-autostradzie-laczacej-peru-z-chile-w-poblizu-miasta-tacna-w-andach-6628549/alternates/LANDSCAPE_1280" />
    W Peru obowiązuje stan wyjątkowy.

## Ustawa wiatrakowa coraz bliżej. Rzecznik rządu o terminie
 - [https://tvn24.pl/biznes/z-kraju/projekt-ustawy-wiatrakowej-termin-przyjecia-przez-sejm-komentarz-piotr-mueller-6628507?source=rss](https://tvn24.pl/biznes/z-kraju/projekt-ustawy-wiatrakowej-termin-przyjecia-przez-sejm-komentarz-piotr-mueller-6628507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:43:23+00:00
 - user: None

<img alt="Ustawa wiatrakowa coraz bliżej. Rzecznik rządu o terminie" src="https://tvn24.pl/najnowsze/article3228001.ece/alternates/LANDSCAPE_1280" />
    Nowelizacja ustawy wiatrakowej jest jednym z kamieni milowych, których spełnienie jest konieczne do wypłaty środków z KPO.

## Kosmiczna aukcja. Poczuj się jak prawdziwy kosmonauta
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-55,S00E55,962836?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-55,S00E55,962836?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:32:48+00:00
 - user: None

<img alt="Kosmiczna aukcja. Poczuj się jak prawdziwy kosmonauta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ytv9yj-wosp-zwiedzanie-europejskiego-centrum-astronautow-6628539/alternates/LANDSCAPE_1280" />
    Po Europejskim Centrum Astronautów oprowadzi dr Anna Fogtman.

## Polak znokautował na treningach w Zakopanem
 - [https://eurosport.tvn24.pl/polak-znokautowa--na-treningach-w-zakopanem,1132654.html?source=rss](https://eurosport.tvn24.pl/polak-znokautowa--na-treningach-w-zakopanem,1132654.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:29:00+00:00
 - user: None

<img alt="Polak znokautował na treningach w Zakopanem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0vkxk5-dawid-kubacki-jest-liderem-pucharu-swiata/alternates/LANDSCAPE_1280" />
    Popis jednego aktora. Transmisja z kwalifikacji w Eurosporcie i w Eurosporcie Extra w Playerze.

## Czesi wybierają prezydenta. Głosowanie trwa dwa dni
 - [https://tvn24.pl/swiat/czechy-bezposrednie-wybory-prezydenckie-2023-andrej-babisz-petr-pavel-i-danusze-nerudova-wsrod-faworytow-6628402?source=rss](https://tvn24.pl/swiat/czechy-bezposrednie-wybory-prezydenckie-2023-andrej-babisz-petr-pavel-i-danusze-nerudova-wsrod-faworytow-6628402?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:27:36+00:00
 - user: None

<img alt="Czesi wybierają prezydenta. Głosowanie trwa dwa dni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dixbb9-andrej-babisz-glosowal-w-piatek-w-towarzystwie-mediow-6628432/alternates/LANDSCAPE_1280" />
    W bezpośrednich wyborach prezydenckich startuje ośmiu kandydatów.

## Śmigłowiec runął na ziemię, zginął pilot. Prokuratura bada, jak doszło do wypadku
 - [https://tvn24.pl/pomorze/lesna-jania-smiglowiec-runal-na-ziemie-zginal-pilot-prokuratura-bada-jak-doszlo-do-wypadku-6628425?source=rss](https://tvn24.pl/pomorze/lesna-jania-smiglowiec-runal-na-ziemie-zginal-pilot-prokuratura-bada-jak-doszlo-do-wypadku-6628425?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 16:00:46+00:00
 - user: None

<img alt="Śmigłowiec runął na ziemię, zginął pilot. Prokuratura bada, jak doszło do wypadku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0j7n8o-wypadek-smiglowca-w-pow-starogardzkim-6623597/alternates/LANDSCAPE_1280" />
    "Śledczy biorą pod uwagę czynnik ludzki, awarię maszyny bądź usterkę".

## Lex Czarnek 3.0? Minister Czarnek ucina spekulacje
 - [https://tvn24.pl/polska/nie-bedzie-lex-czarnek-30-oswiadczenie-ministra-przemyslawa-czarnka-6628470?source=rss](https://tvn24.pl/polska/nie-bedzie-lex-czarnek-30-oswiadczenie-ministra-przemyslawa-czarnka-6628470?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:54:15+00:00
 - user: None

<img alt="Lex Czarnek 3.0? Minister Czarnek ucina spekulacje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-sv0z5o-przemyslaw-czarnek-w-warszawie-6628448/alternates/LANDSCAPE_1280" />
    Ustawę dwukrotnie wetował prezydent.

## Prokuratura prowadzi śledztwo w sprawie lipcowych wypowiedzi Tuska
 - [https://tvn24.pl/polska/donald-tusk-o-adamie-glapinskim-sledztwo-w-sprawie-slow-lidera-po-o-prezesie-nbp-6628435?source=rss](https://tvn24.pl/polska/donald-tusk-o-adamie-glapinskim-sledztwo-w-sprawie-slow-lidera-po-o-prezesie-nbp-6628435?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:49:23+00:00
 - user: None

<img alt="Prokuratura prowadzi śledztwo w sprawie lipcowych wypowiedzi Tuska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lvuuae-pap202212021bi-6557293/alternates/LANDSCAPE_1280" />
    Czy Donald Tusk zamierzał przemocą usunąć prezesa Narodowego Banku Polskiego? Śledztwo w tej sprawie od września prowadzi Prokuratura Okręgowa w Radomiu.

## Sejm nie zgodził się na uchylenie immunitetów sześciorgu posłom
 - [https://tvn24.pl/polska/sejm-nie-zgodzil-sie-na-uchylenie-immunitetow-szesciorgu-poslom-w-tym-arkadiuszowi-mularczykowi-i-przemyslawowi-czarnkowi-6628362?source=rss](https://tvn24.pl/polska/sejm-nie-zgodzil-sie-na-uchylenie-immunitetow-szesciorgu-poslom-w-tym-arkadiuszowi-mularczykowi-i-przemyslawowi-czarnkowi-6628362?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:47:33+00:00
 - user: None

<img alt="Sejm nie zgodził się na uchylenie immunitetów sześciorgu posłom" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e3oztk-wiceminister-spraw-zagranicznych-arkadiusz-mularczyk-6628424/alternates/LANDSCAPE_1280" />
    Piątkowe głosowania w Sejmie.

## Polak znokautował na treningu w Zakopanem
 - [https://eurosport.tvn24.pl/skoki-narciarskie-zakopane-2023--relacja-na--ywo-z-pi-tkowych-trening-w-i-kwalifikacji,1132643.html?source=rss](https://eurosport.tvn24.pl/skoki-narciarskie-zakopane-2023--relacja-na--ywo-z-pi-tkowych-trening-w-i-kwalifikacji,1132643.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:36:00+00:00
 - user: None

<img alt="Polak znokautował na treningu w Zakopanem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kweaj4-relacja-zakopane/alternates/LANDSCAPE_1280" />
    Wyniki na żywo i relacja live z treningów i kwalifikacji w Zakopanem w eurosport.pl.

## Urodziła się w 26. tygodniu ciąży, ważyła 390 gramów. Lekarze uratowali maleńką Martę
 - [https://tvn24.pl/katowice/ruda-slaska-urodzila-sie-w-26-tygodniu-ciazy-wazyla-390-gramow-lekarze-uratowali-marte-dziewczynka-zostala-wypisana-do-domu-6628375?source=rss](https://tvn24.pl/katowice/ruda-slaska-urodzila-sie-w-26-tygodniu-ciazy-wazyla-390-gramow-lekarze-uratowali-marte-dziewczynka-zostala-wypisana-do-domu-6628375?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:34:43+00:00
 - user: None

<img alt="Urodziła się w 26. tygodniu ciąży, ważyła 390 gramów. Lekarze uratowali maleńką Martę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a4ba1r-13-stycznia-2023-roku-mala-marta-opuscila-szpital-bedac-25-kilogramowym-niemowlakiem-6628379/alternates/LANDSCAPE_1280" />
    Po niemal czteromiesięcznej hospitalizacji dziewczynka opuściła Szpital Miejski w Rudzie Śląskiej.

## Tak wygląda drukowanie piętrowego domu. Pierwsza taka budowa w USA
 - [https://tvn24.pl/biznes/ze-swiata/teksas-drukowanie-pietrowego-domu-tak-wyglada-pierwsza-budowa-tego-typu-w-usa-6628138?source=rss](https://tvn24.pl/biznes/ze-swiata/teksas-drukowanie-pietrowego-domu-tak-wyglada-pierwsza-budowa-tego-typu-w-usa-6628138?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:26:59+00:00
 - user: None

<img alt="Tak wygląda drukowanie piętrowego domu. Pierwsza taka budowa w USA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kbxyos-dom-druk-6628219/alternates/LANDSCAPE_1280" />
    Olbrzymia "drukarka" waży ponad 12 ton.

## Tragiczny wypadek w sortowni śmieci: zacięła się maszyna, "brygadzista próbował ją ręcznie odblokować"
 - [https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-tragiczny-wypadek-w-sortowni-smieci-zaciela-sie-maszyna-brygadzista-probowal-ja-recznie-odblokowac-6628359?source=rss](https://tvn24.pl/tvnwarszawa/bialoleka/warszawa-tragiczny-wypadek-w-sortowni-smieci-zaciela-sie-maszyna-brygadzista-probowal-ja-recznie-odblokowac-6628359?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:24:30+00:00
 - user: None

<img alt="Tragiczny wypadek w sortowni śmieci: zacięła się maszyna, " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9zr7fi-tragiczny-wypadek-w-sortowni-odpadow-6625158/alternates/LANDSCAPE_1280" />
    Zginął 27-letni pracownik hali.

## Legendarna polska fabryka kończy działalność po 200 latach. Z jej produktów korzystał Barack Obama
 - [https://tvn24.pl/biznes/najnowsze/porcelana-krzysztof-w-walbrzychu-konczy-dzialalnosc-beda-zwolnienia-grupowe-komentarz-agnieszka-palus-dyrektorki-zarzadzajacej-6627982?source=rss](https://tvn24.pl/biznes/najnowsze/porcelana-krzysztof-w-walbrzychu-konczy-dzialalnosc-beda-zwolnienia-grupowe-komentarz-agnieszka-palus-dyrektorki-zarzadzajacej-6627982?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:06:45+00:00
 - user: None

<img alt="Legendarna polska fabryka kończy działalność po 200 latach. Z jej produktów korzystał Barack Obama" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-30h3mw-legendarna-polska-fabryka-konczy-dzialalnosc-po-prawie-200-latach-6628411/alternates/LANDSCAPE_1280" />
    - Dziękujemy wszystkim pokoleniom, które tworzyły piękną historię - mówi w rozmowie z TVN24 Biznes Agnieszka Palus.

## "Ukoronowanie przemian" czy "gmeranie pod swój elektorat". Pytania o zmiany w Kodeksie wyborczym
 - [https://tvn24.pl/polska/zmiany-w-kodeksie-wyborczym-komentarze-politykow-opozycja-nie-chce-zmian-w-tym-roku-6628286?source=rss](https://tvn24.pl/polska/zmiany-w-kodeksie-wyborczym-komentarze-politykow-opozycja-nie-chce-zmian-w-tym-roku-6628286?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 15:04:59+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hxg9w4-sejm-6628370/alternates/LANDSCAPE_1280" />
    I komentarze.

## Najprawdopodobniej zasłabł, uderzył w ogrodzenie. Zmarł na miejscu
 - [https://tvn24.pl/bialystok/stoczek-lukowski-54-letni-kierowca-zaslabl-i-uderzyl-w-ogrodzenie-zmarl-na-miejscu-6628235?source=rss](https://tvn24.pl/bialystok/stoczek-lukowski-54-letni-kierowca-zaslabl-i-uderzyl-w-ogrodzenie-zmarl-na-miejscu-6628235?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 14:50:13+00:00
 - user: None

<img alt="Najprawdopodobniej zasłabł, uderzył w ogrodzenie. Zmarł na miejscu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-verm36-kierowca-ciezarowki-zaslabl-i-uderzyl-w-ogrodzenie-nie-przezyl-zderzenia-6628308/alternates/LANDSCAPE_1280" />
    Okoliczności wypadku wyjaśnia policja.

## Funkcjonariusz SOP spowodował kolizję i uciekł. Miał 2,5 promila alkoholu
 - [https://tvn24.pl/polska/funkcjonariusz-sop-spowodowal-kolizje-i-uciekl-mial-25-promila-alkoholu-6628194?source=rss](https://tvn24.pl/polska/funkcjonariusz-sop-spowodowal-kolizje-i-uciekl-mial-25-promila-alkoholu-6628194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 14:35:07+00:00
 - user: None

<img alt="Funkcjonariusz SOP spowodował kolizję i uciekł. Miał 2,5 promila alkoholu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ya4bqq-pap202206130gp-1-6628351/alternates/LANDSCAPE_1280" />
    Wszczęto postępowanie dyscyplinarne.

## Zjechał na przeciwległy pas ruchu i zderzył się z ciężarówką. Nie żyją trzy osoby
 - [https://tvn24.pl/wroclaw/uciechow-zjechal-na-przeciwlegly-pas-ruchu-i-uderzyl-w-samochod-ciezarowy-nie-zyja-trzy-osoby-dwie-sa-ranne-6628316?source=rss](https://tvn24.pl/wroclaw/uciechow-zjechal-na-przeciwlegly-pas-ruchu-i-uderzyl-w-samochod-ciezarowy-nie-zyja-trzy-osoby-dwie-sa-ranne-6628316?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 14:26:04+00:00
 - user: None

<img alt="Zjechał na przeciwległy pas ruchu i zderzył się z ciężarówką. Nie żyją trzy osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g8cxbx-trzy-osoby-nie-zyja-a-dwie-zostaly-ranne-w-wypadku-pod-dzierzoniowem-6628297/alternates/LANDSCAPE_1280" />
    Dwie zostały ranne.

## "Apelujemy, żeby nie traktować Unii Europejskiej jako bankomatu"
 - [https://tvn24.pl/pomorze/pieniadze-na-kpo-samorzadowcy-o-zmianach-w-ustawie-dot-sadownictwa-6628281?source=rss](https://tvn24.pl/pomorze/pieniadze-na-kpo-samorzadowcy-o-zmianach-w-ustawie-dot-sadownictwa-6628281?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 14:20:01+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-450uhd-samorzadowcy-reaguja-na-ustawe-dotyczaca-sadownictwa-6628317/alternates/LANDSCAPE_1280" />
    Samorządowcy reagują na ustawę dotyczącą sądownictwa.

## Minister Moskwa zapewnia: ograniczymy podwyżki dla obywateli
 - [https://tvn24.pl/biznes/z-kraju/ogrzewanie-ceny-minister-klimatu-anna-moskwa-o-ograniczeniu-podwyzek-cen-ciepla-dla-obywateli-6628171?source=rss](https://tvn24.pl/biznes/z-kraju/ogrzewanie-ceny-minister-klimatu-anna-moskwa-o-ograniczeniu-podwyzek-cen-ciepla-dla-obywateli-6628171?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 14:14:28+00:00
 - user: None

<img alt="Minister Moskwa zapewnia: ograniczymy podwyżki dla obywateli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l8jt58-awarie-cieplownicze-w-stolicy-4998341/alternates/LANDSCAPE_1280" />
    Wkrótce mają zostać przedstawione nowe przepisy.

## Meksyk rozmieszcza w metrze tysiące gwardzistów po serii "nietypowych działań"
 - [https://tvn24.pl/swiat/meksyk-gwardia-narodowa-rozmieszczona-w-metrze-po-serii-nietypowych-wydarzen-6627927?source=rss](https://tvn24.pl/swiat/meksyk-gwardia-narodowa-rozmieszczona-w-metrze-po-serii-nietypowych-wydarzen-6627927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 13:31:35+00:00
 - user: None

<img alt="Meksyk rozmieszcza w metrze tysiące gwardzistów po serii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bhnls1-tysiace-gwardzistow-w-metrze-w-meksyku-6627922/alternates/LANDSCAPE_1280" />
    O rozmieszczeniu Gwardii Narodowej poinformowała burmistrz stolicy Meksyku.

## Po rosyjskim ataku zorganizowali zbiórkę "na zemstę". Zebrali miliony, pokazali, co kupili
 - [https://tvn24.pl/swiat/ukraina-po-zmasowanym-rosyjskim-ataku-zorganizowali-zbiorke-na-zemste-kupili-drony-6627898?source=rss](https://tvn24.pl/swiat/ukraina-po-zmasowanym-rosyjskim-ataku-zorganizowali-zbiorke-na-zemste-kupili-drony-6627898?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 13:30:42+00:00
 - user: None

<img alt="Po rosyjskim ataku zorganizowali zbiórkę " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9kyj5-ukraincy-drony-6627891/alternates/LANDSCAPE_1280" />
    Kwota to 352 miliony hrywien, czyli ponad 40 milionów złotych.

## Nieoczekiwane kłopoty snookerzysty. "Nic nie widziałem"
 - [https://eurosport.tvn24.pl/nieoczekiwane-k-opoty-snookerzysty---nic-nie-widzia-em-,1132628.html?source=rss](https://eurosport.tvn24.pl/nieoczekiwane-k-opoty-snookerzysty---nic-nie-widzia-em-,1132628.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 13:23:00+00:00
 - user: None

<img alt="Nieoczekiwane kłopoty snookerzysty. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ixpar4-jack-lisowski-zagra-w-polfinale/alternates/LANDSCAPE_1280" />
    I tak awansował do półfinału turnieju Masters.

## "USA i ich sojusznicy podejmują większe ryzyko w obronie Ukrainy"
 - [https://tvn24.pl/swiat/new-york-times-zachod-przelamuje-kolejne-bariery-wysylajac-na-ukraine-zaawansowana-bron-6627939?source=rss](https://tvn24.pl/swiat/new-york-times-zachod-przelamuje-kolejne-bariery-wysylajac-na-ukraine-zaawansowana-bron-6627939?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 13:13:45+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qi0lry-wojsko-ukraina-6628021/alternates/LANDSCAPE_1280" />
    Zachód przełamuje kolejne bariery, wysyłając na Ukrainę broń, której dostarczanie uważano dotąd za zbyt prowokacyjne - ocenia "New York Times".

## Milion ton wody z elektrowni jądrowej jeszcze w tym roku ma trafić do morza
 - [https://tvn24.pl/swiat/japonia-milion-ton-wody-z-fukushimy-jeszcze-w-tym-roku-ma-trafic-do-morza-6628086?source=rss](https://tvn24.pl/swiat/japonia-milion-ton-wody-z-fukushimy-jeszcze-w-tym-roku-ma-trafic-do-morza-6628086?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 13:10:57+00:00
 - user: None

<img alt="Milion ton wody z elektrowni jądrowej jeszcze w tym roku ma trafić do morza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v0whga-fukushima-5331088/alternates/LANDSCAPE_1280" />
    Sąsiednie kraje zaniepokojone.

## Wszczepili elektrody w mózg Igora, by mógł cieszyć się życiem bez padaczki. Pomógł robot od WOŚP
 - [https://tvn24.pl/pomorze/szczecin-wszczepili-elektrody-w-mozg-igora-by-mogl-cieszyc-sie-zyciem-bez-padaczki-pomogl-robot-od-wosp-6627883?source=rss](https://tvn24.pl/pomorze/szczecin-wszczepili-elektrody-w-mozg-igora-by-mogl-cieszyc-sie-zyciem-bez-padaczki-pomogl-robot-od-wosp-6627883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:55:22+00:00
 - user: None

<img alt="Wszczepili elektrody w mózg Igora, by mógł cieszyć się życiem bez padaczki. Pomógł robot od WOŚP" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e19ri4-16-letni-igor-czuje-sie-juz-zdecydowanie-lepiej-6627878/alternates/LANDSCAPE_1280" />
    Była to pierwsza w Polsce operacja robotycznego wszczepienia elektrod stereo-EEG (SEEG) do mózgu.

## Była modelka Playboya skazana za morderstwo psychiatry. Łączyła ich "transakcyjna relacja"
 - [https://tvn24.pl/swiat/usa-modelka-playboya-kelsey-turner-skazana-za-zabojstwo-psychiatry-laczyla-ich-transakcyjna-relacja-6626582?source=rss](https://tvn24.pl/swiat/usa-modelka-playboya-kelsey-turner-skazana-za-zabojstwo-psychiatry-laczyla-ich-transakcyjna-relacja-6626582?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:39:45+00:00
 - user: None

<img alt="Była modelka Playboya skazana za morderstwo psychiatry. Łączyła ich " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9rjnji-kelsey-turner-6627643/alternates/LANDSCAPE_1280" />
    "Z pewnością jest miejsce na wiele pikantnych spekulacji dotyczących charakteru związku tej pary".

## Waloryzacja emerytur "będzie wyższa niż zaplanował rząd". Wyliczenia
 - [https://tvn24.pl/biznes/dla-seniora/waloryzacja-emerytur-2023-podwyzki-brutto-netto-po-danych-gus-o-inflacji-tabela-6627987?source=rss](https://tvn24.pl/biznes/dla-seniora/waloryzacja-emerytur-2023-podwyzki-brutto-netto-po-danych-gus-o-inflacji-tabela-6627987?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:39:32+00:00
 - user: None

<img alt="Waloryzacja emerytur " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i4t551-bis-6628087/alternates/LANDSCAPE_1280" />
    Po danych GUS o inflacji.

## Budka o braku zaufania do Hołowni. Lider Polska 2050: zapraszam do osobistej rozmowy
 - [https://tvn24.pl/polska/sejm-borys-budka-o-braku-zaufania-do-szymona-holowni-lider-polski-2050-odpowiada-6628037?source=rss](https://tvn24.pl/polska/sejm-borys-budka-o-braku-zaufania-do-szymona-holowni-lider-polski-2050-odpowiada-6628037?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:37:19+00:00
 - user: None

<img alt="Budka o braku zaufania do Hołowni. Lider Polska 2050: zapraszam do osobistej rozmowy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8n73pb-borys-budka-6628057/alternates/LANDSCAPE_1280" />
    Po piątkowym głosowaniu opozycji w Sejmie.

## Milik znowu w Neapolu. "Wraca w koszulce najbardziej znienawidzonego rywala
 - [https://eurosport.tvn24.pl/milik-znowu-w-neapolu---wraca-w-koszulce-najbardziej-znienawidzonego-rywala,1132631.html?source=rss](https://eurosport.tvn24.pl/milik-znowu-w-neapolu---wraca-w-koszulce-najbardziej-znienawidzonego-rywala,1132631.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:30:00+00:00
 - user: None

<img alt="Milik znowu w Neapolu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-waloxt-jak-milik-zaprezentuje-sie-przeciwko-swojemu-bylemu-klubowi/alternates/LANDSCAPE_1280" />
    To będzie wieczór pełen emocji dla Arkadiusza Milika.

## Ziobro: KPO to bardzo drogi kredyt, za który przyjdzie nam płacić
 - [https://tvn24.pl/polska/sadownictwo-kpo-nowelizacja-ustawy-przyjeta-zbigniew-ziobro-komentuje-6627977?source=rss](https://tvn24.pl/polska/sadownictwo-kpo-nowelizacja-ustawy-przyjeta-zbigniew-ziobro-komentuje-6627977?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 12:03:15+00:00
 - user: None

<img alt="Ziobro: KPO to bardzo drogi kredyt, za który przyjdzie nam płacić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m7u4r1-zbigniew-ziobro-i-parlamentarzysci-solidarnej-polski-podczas-konferencji-prasowej-6628033/alternates/LANDSCAPE_1280" />
    Lider Solidarnej Polski odniósł się do przyjęcia przez Sejm projektu PiS zakładającego zmiany w sądownictwie.

## Morawiecki: Ta ustawa to trudny kompromis. Chcemy zakończyć spór, bo prawdziwy wróg jest na Wschodzie
 - [https://tvn24.pl/polska/krajowy-plan-odbudowy-unia-europejska-mateusz-morawiecki-chcemy-zakonczyc-spor-na-zachodzie-bo-prawdziwy-wrog-jest-na-wschodzie-6628012?source=rss](https://tvn24.pl/polska/krajowy-plan-odbudowy-unia-europejska-mateusz-morawiecki-chcemy-zakonczyc-spor-na-zachodzie-bo-prawdziwy-wrog-jest-na-wschodzie-6628012?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 11:53:45+00:00
 - user: None

<img alt="Morawiecki: Ta ustawa to trudny kompromis. Chcemy zakończyć spór, bo prawdziwy wróg jest na Wschodzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xod3lq-mateusz-morawiecki-6627973/alternates/LANDSCAPE_1280" />
    Komentarz premiera po przegłosowaniu w Sejmie ustawy o sądownictwie mogącej otworzyć Polsce drogę do pieniędzy z Krajowego Planu Odbudowy.

## Ustawa o sądownictwie przyjęta. Reakcja z Komisji Europejskiej
 - [https://tvn24.pl/polska/krajowy-plan-odbudowy-ustawa-o-sadownictwie-przyjeta-reakcja-z-komisji-europejskiej-6627966?source=rss](https://tvn24.pl/polska/krajowy-plan-odbudowy-ustawa-o-sadownictwie-przyjeta-reakcja-z-komisji-europejskiej-6627966?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 11:38:47+00:00
 - user: None

<img alt="Ustawa o sądownictwie przyjęta. Reakcja z Komisji Europejskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uddp1b-christian-wigand-4565334/alternates/LANDSCAPE_1280" />
    Komentarz rzecznika KE Christiana Wiganda.

## Został nowym prezesem kopalni Bogdanka. Brał udział w zaręczynach polityka PiS pod ziemią
 - [https://tvn24.pl/polska/kasjan-wyligala-nowy-prezes-kopalni-bogdanka-darczynca-pis-michal-moskal-wspolpracownik-jaroslawa-kaczynskiego-w-asyscie-wyligaly-zareczyl-sie-w-kopalni-6627615?source=rss](https://tvn24.pl/polska/kasjan-wyligala-nowy-prezes-kopalni-bogdanka-darczynca-pis-michal-moskal-wspolpracownik-jaroslawa-kaczynskiego-w-asyscie-wyligaly-zareczyl-sie-w-kopalni-6627615?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 11:34:53+00:00
 - user: None

<img alt="Został nowym prezesem kopalni Bogdanka. Brał udział w zaręczynach polityka PiS pod ziemią " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vqiz6z-kasjan-wyligala-6627831/alternates/LANDSCAPE_1280" />
    Wcześniej pisaliśmy o tym, że Michał Moskal, młody polityk PiS, miał oświadczyć się na dole kopalni. Umożliwić miał mu to nowy prezes firmy.

## Rewolucja na pilotach. Jest decyzja Sejmu
 - [https://tvn24.pl/biznes/z-kraju/lex-pilot-przepisy-wprowadzajace-ustawe-prawo-komunikacji-elektronicznej-sejm-podjal-decyzje-wyniki-glosowania-6627350?source=rss](https://tvn24.pl/biznes/z-kraju/lex-pilot-przepisy-wprowadzajace-ustawe-prawo-komunikacji-elektronicznej-sejm-podjal-decyzje-wyniki-glosowania-6627350?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 11:07:30+00:00
 - user: None

<img alt="Rewolucja na pilotach. Jest decyzja Sejmu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b88aa3-lex-pilot-media-telewizja-6627431/alternates/LANDSCAPE_1280" />
    Wyniki głosowania.

## "Zamieniłeś ferrari na twingo". Kim jest 22-latka, z którą Gerard Piqué miał zdradzać Shakirę?
 - [https://tvn24.pl/kultura-i-styl/shakira-spiewa-o-pique-zamieniles-ferrari-na-twingo-kim-jest-22-latka-z-ktora-pilkarz-mial-ja-zdradzac-6627588?source=rss](https://tvn24.pl/kultura-i-styl/shakira-spiewa-o-pique-zamieniles-ferrari-na-twingo-kim-jest-22-latka-z-ktora-pilkarz-mial-ja-zdradzac-6627588?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 10:23:19+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ibsha2-gerard-pique-clara-chia-6627732/alternates/LANDSCAPE_1280" />
    "Jestem warta tyle, co dwie 22-latki" - śpiewa kolumbijska gwiazda.

## Projekt zmian w sądownictwie przyjęty
 - [https://tvn24.pl/polska/sadownictwo-kpo-nowelizacja-ustawy-przyjeta-ma-umozliwic-odblokowanie-srodkow-z-unii-europejskiej-6627665?source=rss](https://tvn24.pl/polska/sadownictwo-kpo-nowelizacja-ustawy-przyjeta-ma-umozliwic-odblokowanie-srodkow-z-unii-europejskiej-6627665?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 10:01:17+00:00
 - user: None

<img alt="Projekt zmian w sądownictwie przyjęty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-09nwiq-obrady-sejmu-6627727/alternates/LANDSCAPE_1280" />
    Ma umożliwić odblokowanie środków z KPO.

## FIFA wybiera gola roku. Polski ampfutbolista w elitarnym gronie nominowanych
 - [https://eurosport.tvn24.pl/fifa-wybiera-gola-roku--polski-ampfutbolista-w-elitarnym-gronie-nominowanych,1132622.html?source=rss](https://eurosport.tvn24.pl/fifa-wybiera-gola-roku--polski-ampfutbolista-w-elitarnym-gronie-nominowanych,1132622.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:49:00+00:00
 - user: None

<img alt="FIFA wybiera gola roku. Polski ampfutbolista w elitarnym gronie nominowanych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dumz18-rywalami-oleksego-sa-min-richarlison-i-mbappe/alternates/LANDSCAPE_1280" />
    W gronie autorów jedenastu wyróżnionych bramek jest Marcin Oleksy z drużyny amp futbolu Warty Poznań.

## Pytanie o projekt dotyczący sądownictwa. Jarosław Kaczyński odpowiada
 - [https://tvn24.pl/polska/sejm-kpo-pieniadze-z-unii-prezes-pis-jaroslaw-kaczynski-odpowiada-na-pytanie-dziennikarzy-w-sprawie-projektu-o-sadownictwie-6627625?source=rss](https://tvn24.pl/polska/sejm-kpo-pieniadze-z-unii-prezes-pis-jaroslaw-kaczynski-odpowiada-na-pytanie-dziennikarzy-w-sprawie-projektu-o-sadownictwie-6627625?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:47:28+00:00
 - user: None

<img alt="Pytanie o projekt dotyczący sądownictwa. Jarosław Kaczyński odpowiada" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4tzx5u-jaroslaw-kaczynski-w-piatek-w-sejmie-6627617/alternates/LANDSCAPE_1280" />
    Prezes PiS zatrzymał się na chwilę przy zadających pytania sejmowych reporterach.

## Fałszywka o polskich najemnikach w Ukrainie. Bohater zdjęcia: "coś wyraźnie im nie wyszło"
 - [https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-falszywka-o-polskich-najemnikach-bohater-zdjecia-cos-wyraznie-im-nie-wyszlo-6626500?source=rss](https://konkret24.tvn24.pl/swiat/wojna-w-ukrainie-falszywka-o-polskich-najemnikach-bohater-zdjecia-cos-wyraznie-im-nie-wyszlo-6626500?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:36:55+00:00
 - user: None

<img alt="Fałszywka o polskich najemnikach w Ukrainie. Bohater zdjęcia: " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2jkrnv-rosyjska-propaganda-wykorzystala-zdjecie-polskiego-oficera-do-fejka-6627432/alternates/LANDSCAPE_1280" />
    Informacja, jakoby Ukraińcy porzucili w Sołedarze polskich najemników, to kolejny fake news prokremlowskiej propagandy.

## Skoczkowie wypoczęci, Wielka Krokiew im niestraszna
 - [https://eurosport.tvn24.pl/skoczkowie-wypocz-ci--wielka-krokiew-im-niestraszna---znaj--j--najlepiej-,1132569.html?source=rss](https://eurosport.tvn24.pl/skoczkowie-wypocz-ci--wielka-krokiew-im-niestraszna---znaj--j--najlepiej-,1132569.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:33:18+00:00
 - user: None

<img alt="Skoczkowie wypoczęci, Wielka Krokiew im niestraszna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4tucob-kamil-stoch-piotr-zyla-dawid-kubacki/alternates/LANDSCAPE_1280" />
    Trener Polaków Thomas Thurnbichler w rozmowie z Eurosportem o konkursach Pucharu Świata w Zakopanem.

## Eksperci: zdobycie Sołedaru nie ma znaczenia. Podolak: Rosjanie stracili w regionie 20 tysięcy żołnierzy
 - [https://tvn24.pl/swiat/ukraina-bachmut-i-soledar-doradca-zelenskiego-rosjanie-stracili-tam-20-tysiecy-zolnierzy-6627441?source=rss](https://tvn24.pl/swiat/ukraina-bachmut-i-soledar-doradca-zelenskiego-rosjanie-stracili-tam-20-tysiecy-zolnierzy-6627441?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:23:49+00:00
 - user: None

<img alt="Eksperci: zdobycie Sołedaru nie ma znaczenia. Podolak: Rosjanie stracili w regionie 20 tysięcy żołnierzy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kxrl7d-walki-o-soledar-w-obwodzie-donieckim-6627536/alternates/LANDSCAPE_1280" />
    Wiele źródeł wskazuje, że Rosjanie prawdopodobnie zajęli większość obszaru miasta, jednak strona ukraińska wciąż tego nie potwierdza.

## Znamy poziom inflacji w 2022 roku. To ważna informacja dla emerytów i rencistów
 - [https://tvn24.pl/biznes/dla-seniora/waloryzacja-emerytur-2023-gus-podal-ile-wyniosla-inflacja-w-2022-roku-6627419?source=rss](https://tvn24.pl/biznes/dla-seniora/waloryzacja-emerytur-2023-gus-podal-ile-wyniosla-inflacja-w-2022-roku-6627419?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:07:09+00:00
 - user: None

<img alt="Znamy poziom inflacji w 2022 roku. To ważna informacja dla emerytów i rencistów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z9lgaj-emerytury-i-renty-maja-wzrosnac-4772158/alternates/LANDSCAPE_1280" />
    Oznacza to, że wskaźnik waloryzacji może być wyższy niż prognozował rząd.

## Są nowe dane o inflacji w Polsce
 - [https://tvn24.pl/biznes/z-kraju/inflacja-grudzien-gus-podal-nowe-dane-6627343?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-grudzien-gus-podal-nowe-dane-6627343?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 09:01:41+00:00
 - user: None

<img alt="Są nowe dane o inflacji w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bnbvho-plansza-pilne-szeroki-drv-4712015/alternates/LANDSCAPE_1280" />
    Dane Głównego Urzędu Statystycznego.

## Wjechał w kobietę na pasach. "Nie miała żadnej możliwości ucieczki"
 - [https://tvn24.pl/tvnwarszawa/ulice/garwolin-wjechal-w-kobiete-na-pasach-nagranie-6627526?source=rss](https://tvn24.pl/tvnwarszawa/ulice/garwolin-wjechal-w-kobiete-na-pasach-nagranie-6627526?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:48:46+00:00
 - user: None

<img alt="Wjechał w kobietę na pasach. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cipcnj-do-potracenia-doszlo-w-centrum-garwolina-6627506/alternates/LANDSCAPE_1280" />
    Nagranie.

## Wielkie wymieranie permskie. Ziarenko pyłku pomogło wyjaśnić, dlaczego było tak katastrofalne
 - [https://tvn24.pl/tvnmeteo/nauka/wielkie-wymieranie-permskie-ziarenko-pylku-pomoglo-wyjasnic-dlaczego-bylo-tak-katastrofalne-6623976?source=rss](https://tvn24.pl/tvnmeteo/nauka/wielkie-wymieranie-permskie-ziarenko-pylku-pomoglo-wyjasnic-dlaczego-bylo-tak-katastrofalne-6623976?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:39:18+00:00
 - user: None

<img alt="Wielkie wymieranie permskie. Ziarenko pyłku pomogło wyjaśnić, dlaczego było tak katastrofalne" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9tzsrg-przyczyna-wymierania-permskiego-mogla-byc-wzmozona-aktywnosc-wulkaniczna-wizualizacja-6624119/alternates/LANDSCAPE_1280" />
    Badania opublikowano na łamach czasopisma "Science Advances".

## Kliczko: przygotowujemy się na ewentualny atak na Kijów z Białorusi
 - [https://tvn24.pl/swiat/ukraina-mer-kijowa-witalij-kliczko-przygotowujemy-sie-na-ewentualny-atak-z-bialorusi-jestesmy-silniejsi-6627282?source=rss](https://tvn24.pl/swiat/ukraina-mer-kijowa-witalij-kliczko-przygotowujemy-sie-na-ewentualny-atak-z-bialorusi-jestesmy-silniejsi-6627282?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:37:57+00:00
 - user: None

<img alt="Kliczko: przygotowujemy się na ewentualny atak na Kijów z Białorusi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjc9e8-witalij-kliczko-6627512/alternates/LANDSCAPE_1280" />
    Mer Kijowa w rozmowie z Arturem Molędą.

## Policjanci zaglądali z wysięgnika do mieszkania. Rzecznik Praw Obywatelskich oczekuje wyjaśnień
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-zagladali-z-wysiegnika-do-mieszkania-rzecznik-praw-obywatelskich-oczekuje-wyjasnien-6627507?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-zagladali-z-wysiegnika-do-mieszkania-rzecznik-praw-obywatelskich-oczekuje-wyjasnien-6627507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:36:06+00:00
 - user: None

<img alt="Policjanci zaglądali z wysięgnika do mieszkania. Rzecznik Praw Obywatelskich oczekuje wyjaśnień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i40cd3-policjanci-odwiedzili-lokal-lotnej-brygady-opozycji-6623105/alternates/LANDSCAPE_1280" />
    Lokal wynajęła Lotna Brygada Opozycji.

## Inflacja na Węgrzech przyspieszyła
 - [https://tvn24.pl/biznes/ze-swiata/wegry-inflacja-grudzien-2022-inflacja-na-wegrzech-przyspieszyla-6627487?source=rss](https://tvn24.pl/biznes/ze-swiata/wegry-inflacja-grudzien-2022-inflacja-na-wegrzech-przyspieszyla-6627487?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:19:45+00:00
 - user: None

<img alt="Inflacja na Węgrzech przyspieszyła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0t0jgc-budapeszt-wegry-mistervlad-shutterstock2151056345-6090149/alternates/LANDSCAPE_1280" />
    Nowe dane z Budapesztu.

## Wychodziła za mąż cztery razy, wszystkie małżeństwa były nieudane. Trudne życie Lisy Marie Presley
 - [https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-corka-elvisa-byla-zona-cagea-i-jacksona-cztery-razy-wychodzila-za-maz-6627435?source=rss](https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-corka-elvisa-byla-zona-cagea-i-jacksona-cztery-razy-wychodzila-za-maz-6627435?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 08:01:41+00:00
 - user: None

<img alt="Wychodziła za mąż cztery razy, wszystkie małżeństwa były nieudane. Trudne życie Lisy Marie Presley" src="https://tvn24.pl/najnowsze/cdn-zdjecie-57vd6d-gettyimages-88921973-6627378/alternates/LANDSCAPE_1280" />
    Córka Elvisa zmarła w wieku 54 lat.

## Na horyzoncie widać ochłodzenie. "To będzie duży spadek temperatury"
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-w-polsce-kiedy-wroci-zima-na-horyzoncie-widac-ochlodzenie-to-bedzie-duzy-spadek-temperatury-tomasz-wasilewski-o-pogodzie-6627469?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-w-polsce-kiedy-wroci-zima-na-horyzoncie-widac-ochlodzenie-to-bedzie-duzy-spadek-temperatury-tomasz-wasilewski-o-pogodzie-6627469?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:54:30+00:00
 - user: None

<img alt="Na horyzoncie widać ochłodzenie. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5xzjcg-widac-ochlodzenie-6627476/alternates/LANDSCAPE_1280" />
    Opowiadał prezenter tvnmeteo.pl Tomasz Wasilewski.

## Kto z członków rodziny królewskiej wypadł najlepiej w autobiografii Harry'ego
 - [https://tvn24.pl/swiat/ksiaze-harry-spare-kto-z-czlonkow-rodziny-krolewskiej-wypada-najlepiej-w-autobiografii-ksiecia-harryego-6625610?source=rss](https://tvn24.pl/swiat/ksiaze-harry-spare-kto-z-czlonkow-rodziny-krolewskiej-wypada-najlepiej-w-autobiografii-ksiecia-harryego-6625610?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:32:22+00:00
 - user: None

<img alt="Kto z członków rodziny królewskiej wypadł najlepiej w autobiografii Harry'ego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1tfk0i-brytyjska-rodzina-krolewska-5039258/alternates/LANDSCAPE_1280" />
    Analiza BBC.

## Chelsea nadal bez wygranej w nowym roku
 - [https://eurosport.tvn24.pl/chelsea-nadal-bez-wygranej-w-nowym-roku--nieudany-debiut-felixa,1132613.html?source=rss](https://eurosport.tvn24.pl/chelsea-nadal-bez-wygranej-w-nowym-roku--nieudany-debiut-felixa,1132613.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:26:02+00:00
 - user: None

<img alt="Chelsea nadal bez wygranej w nowym roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-flp1hx-nie-tak-joao-felix-wyobrazal-sobie-debiut-w-chelsea/alternates/LANDSCAPE_1280" />
    Nieudany debiut Felixa.

## Dwie osoby zginęły w nocnym pożarze kamienicy. Mieszkańców ewakuowano
 - [https://tvn24.pl/lodz/zdunska-wola-dwie-osoby-zginely-w-pozarze-kamienicy-6627404?source=rss](https://tvn24.pl/lodz/zdunska-wola-dwie-osoby-zginely-w-pozarze-kamienicy-6627404?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:25:28+00:00
 - user: None

<img alt="Dwie osoby zginęły w nocnym pożarze kamienicy. Mieszkańców ewakuowano" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yefzbn-poczatkowo-na-miejscu-dzialaly-cztery-zastepy-strazy-pozarnej-6627412/alternates/LANDSCAPE_1280" />
    Pierwszą informację i zdjęcia dostaliśmy na Kontakt 24.

## Ostatni wpis Lisy Marie Presley
 - [https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-ostatni-przed-smiercia-wpis-w-mediach-spolecznosciowych-6627397?source=rss](https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-ostatni-przed-smiercia-wpis-w-mediach-spolecznosciowych-6627397?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:07:08+00:00
 - user: None

<img alt="Ostatni wpis Lisy Marie Presley" src="https://tvn24.pl/najnowsze/cdn-zdjecie-304iqv-lisa-marie-presley-6627426/alternates/LANDSCAPE_1280" />
    "Śmierć jest częścią życia, czy nam się to podoba, czy nie".

## Przydacz o "pierwszym punkcie wśród priorytetów prezydenta"
 - [https://tvn24.pl/polska/marcin-przydacz-szef-biura-polityki-miedzynarodowej-o-polityce-bezpieczenstwa-wizerunku-polski-i-wsparciu-ukrainy-6627355?source=rss](https://tvn24.pl/polska/marcin-przydacz-szef-biura-polityki-miedzynarodowej-o-polityce-bezpieczenstwa-wizerunku-polski-i-wsparciu-ukrainy-6627355?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:01:18+00:00
 - user: None

<img alt="Przydacz o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6pmxp0-marcin-przydacz-zostal-szefem-biura-polityki-miedzynarodowej-w-kancelarii-prezydenta-6627357/alternates/LANDSCAPE_1280" />
    Nowo powołany szef Biura Polityki Międzynarodowej, Marcin Przydacz, w wywiadzie.

## Czołowe zderzenie samochodów. Jedno z aut zostało zmiażdżone i wypadło z jezdni
 - [https://tvn24.pl/pomorze/redzikowo-slupsk-wypadek-dwoch-samochodow-kierowcy-w-szpitalu-po-zderzeniu-czolowym-6627384?source=rss](https://tvn24.pl/pomorze/redzikowo-slupsk-wypadek-dwoch-samochodow-kierowcy-w-szpitalu-po-zderzeniu-czolowym-6627384?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 07:00:53+00:00
 - user: None

<img alt="Czołowe zderzenie samochodów. Jedno z aut zostało zmiażdżone i wypadło z jezdni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ubf6nw-do-wypadku-doszlo-w-redzikowie-woj-pomorskie-6627368/alternates/LANDSCAPE_1280" />
    Po wypadku dwie osoby trafiły do szpitala.

## Tomasz Kot o kulisach propozycji jego roli w Bondzie. "To plotki, że Daniel Craig zablokował mój udział w filmie"
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-33,S00E33,964742?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-33,S00E33,964742?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 06:50:48+00:00
 - user: None

<img alt="Tomasz Kot o kulisach propozycji jego roli w Bondzie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kd0137-monika-olejnik-i-tomasz-kot-6627395/alternates/LANDSCAPE_1280" />
    Aktor mówi Monice Olejnik również o wielkiej popularności, jaka na niego spadła po sukcesie "Zimnej wojny".

## Matki szukające dzieci znalazły na pustyni już 1520 ciał
 - [https://tvn24.pl/swiat/meksyk-kartele-narkotykowe-pustynia-sonora-1520-cial-zaginionych-odnalezionych-przez-matki-szukajace-dzieci-6627348?source=rss](https://tvn24.pl/swiat/meksyk-kartele-narkotykowe-pustynia-sonora-1520-cial-zaginionych-odnalezionych-przez-matki-szukajace-dzieci-6627348?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 06:49:56+00:00
 - user: None

<img alt="Matki szukające dzieci znalazły na pustyni już 1520 ciał" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rb2yhw-pustynia-sonora-w-meksyku-6627335/alternates/LANDSCAPE_1280" />
    "Cały nasz kraj jest jedną zbiorową mogiłą".

## "Słyszeliśmy ryk. Szkło było wszędzie. To było straszne"
 - [https://tvn24.pl/tvnmeteo/swiat/seria-tornad-w-usa-alabama-georgia-kentucky-zaatakowane-przez-zywiol-sa-zabici-i-ranni-6627314?source=rss](https://tvn24.pl/tvnmeteo/swiat/seria-tornad-w-usa-alabama-georgia-kentucky-zaatakowane-przez-zywiol-sa-zabici-i-ranni-6627314?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 06:46:36+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6op0fp-tornado-w-alabamie-6628303/alternates/LANDSCAPE_1280" />
    Seria tornad na wschodzie USA. Najnowsze dane o liczbie ofiar.

## Polacy przykręcili kurki z gazem. Zużycie spadło o kilkanaście procent
 - [https://tvn24.pl/biznes/z-kraju/gaz-ziemny-zuzycie-gazu-w-polsce-w-2022-roku-spadlo-wstepne-dane-ministerstwa-klimatu-i-srodowiska-6627312?source=rss](https://tvn24.pl/biznes/z-kraju/gaz-ziemny-zuzycie-gazu-w-polsce-w-2022-roku-spadlo-wstepne-dane-ministerstwa-klimatu-i-srodowiska-6627312?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 06:26:54+00:00
 - user: None

<img alt="Polacy przykręcili kurki z gazem. Zużycie spadło o kilkanaście procent" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kud5vv-gaz-shutterstock169694132-5788586/alternates/LANDSCAPE_1280" />
    Wstępne dane Ministerstwa Klimatu i Środowiska za 2022 rok.

## Lewandowski wśród gwiazd nominowanych do nagrody dla piłkarza roku FIFA The Best
 - [https://eurosport.tvn24.pl/lewandowski-w-r-d-gwiazd-nominowanych-do-nagrody-dla-pi-karza-roku-fifa-the-best,1132573.html?source=rss](https://eurosport.tvn24.pl/lewandowski-w-r-d-gwiazd-nominowanych-do-nagrody-dla-pi-karza-roku-fifa-the-best,1132573.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 06:02:00+00:00
 - user: None

<img alt="Lewandowski wśród gwiazd nominowanych do nagrody dla piłkarza roku FIFA The Best" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3l8s3g-robert-lewandowski-liczy-na-udany-mundial/alternates/LANDSCAPE_1280" />
    Kapitan reprezentacji Polski triumfował w dwóch poprzednich edycjach tego plebiscytu.

## Eksplozje w stacji propanu i zakładzie utylizacji śmieci. Zaginione osoby, ewakuacja mieszkańców
 - [https://tvn24.pl/swiat/kanada-silne-eksplozje-w-ontario-i-quebecu-ofiary-wybuchow-i-pozarow-6627293?source=rss](https://tvn24.pl/swiat/kanada-silne-eksplozje-w-ontario-i-quebecu-ofiary-wybuchow-i-pozarow-6627293?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:59:02+00:00
 - user: None

<img alt="Eksplozje w stacji propanu i zakładzie utylizacji śmieci. Zaginione osoby, ewakuacja mieszkańców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r57z5b-akcja-strazakow-w-saint-roch-de-lachigan-w-prowincji-quebec-w-kanadzie-6627313/alternates/LANDSCAPE_1280" />
    W Ontario i Quebecu w Kanadzie.

## Coraz więcej raka. Powstała "wyrwa, za którą będziemy płacić jeszcze kilka lat"
 - [https://tvn24.pl/polska/rak-piersi-coraz-wiecej-wykrywanych-nowotworow-po-spadku-liczby-badan-profilaktycznych-w-czasie-pandemii-6627021?source=rss](https://tvn24.pl/polska/rak-piersi-coraz-wiecej-wykrywanych-nowotworow-po-spadku-liczby-badan-profilaktycznych-w-czasie-pandemii-6627021?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:46:56+00:00
 - user: None

<img alt="Coraz więcej raka. Powstała " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pxnjy4-shutterstock1951533499-6185163/alternates/LANDSCAPE_1280" />
    Niemal dwie trzecie Polek i Polaków nie robi badań profilaktycznych.

## Wiatr może uszkadzać linie energetyczne i wywracać drzewa. Alerty IMGW
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-alerty-i-prognoza-zagrozen-meteo-6627300?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-alerty-i-prognoza-zagrozen-meteo-6627300?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:33:48+00:00
 - user: None

<img alt="Wiatr może uszkadzać linie energetyczne i wywracać drzewa. Alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ejl8d8-zdjecie-pogladowe-5604700/alternates/LANDSCAPE_1280" />
    Ogłoszono też prognozę zagrożeń.

## Wiatr w porywach do 75 km/h. W kolejnych dniach też groźnie
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-porywy-moga-siegac-75-kilometrow-na-godzine-prognoza-zagrozen-intensywne-opady-sniegu-6627300?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-porywy-moga-siegac-75-kilometrow-na-godzine-prognoza-zagrozen-intensywne-opady-sniegu-6627300?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:33:48+00:00
 - user: None

<img alt="Wiatr w porywach do 75 km/h. W kolejnych dniach też groźnie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-rgs1w1-silny-wiatr-5604621/alternates/LANDSCAPE_1280" />
    Obowiązują alarmy i prognoza zagrożeń.

## Przestroga dla Świątek przed Australian Open
 - [https://eurosport.tvn24.pl/przestroga-dla--wi-tek-przed-australian-open--jej-przewaga-w-rankingu-mo-e-wyra-nie-zmale-,1132542.html?source=rss](https://eurosport.tvn24.pl/przestroga-dla--wi-tek-przed-australian-open--jej-przewaga-w-rankingu-mo-e-wyra-nie-zmale-,1132542.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:29:22+00:00
 - user: None

<img alt="Przestroga dla Świątek przed Australian Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mxw8dz-iga-swiatek-jest-liderka-rankingu-wta/alternates/LANDSCAPE_1280" />
    Jej przewaga w rankingu może wyraźnie zmaleć.

## Kumulacja w górę. Wyniki losowania Lotto
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia-120123-liczby-z-ostatniego-losowania-6627295?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia-120123-liczby-z-ostatniego-losowania-6627295?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:16:40+00:00
 - user: None

<img alt="Kumulacja w górę. Wyniki losowania Lotto" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecieaf61038543ef029e7968c060d218d030-lotto-16-jpg-3815826/alternates/LANDSCAPE_1280" />
    Szczegóły.

## "Czy chodzi o to, żeby pilnowała Obajtka?"
 - [https://tvn24.pl/polska/janina-goss-w-pkn-orlen-politycy-o-przyjaciolce-jaroslawa-kaczynskiego-6627024?source=rss](https://tvn24.pl/polska/janina-goss-w-pkn-orlen-politycy-o-przyjaciolce-jaroslawa-kaczynskiego-6627024?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 05:10:57+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-azn1r9-janina-goss-6625076/alternates/LANDSCAPE_1280" />
    Przyjaciółka Kaczyńskiego w Orlenie i na ustach polityków.

## Media: arcybiskup Gaenswein ma opuścić dom, w którym mieszkał z Benedyktem XVI
 - [https://tvn24.pl/swiat/niemcy-watykan-media-arcybiskup-georg-gaenswein-osobisty-sekretarz-benedykta-xvi-musi-opuscic-dom-w-ktorym-z-nim-mieszkal-6627054?source=rss](https://tvn24.pl/swiat/niemcy-watykan-media-arcybiskup-georg-gaenswein-osobisty-sekretarz-benedykta-xvi-musi-opuscic-dom-w-ktorym-z-nim-mieszkal-6627054?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 04:55:23+00:00
 - user: None

<img alt="Media: arcybiskup Gaenswein ma opuścić dom, w którym mieszkał z Benedyktem XVI" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kcwi56-abp-gaenswein-ma-opuscic-dom-w-ktorym-mieszkal-z-benedyktem-xvi-6627052/alternates/LANDSCAPE_1280" />
    Osobisty sekretarz emerytowanego papieża wydał książkę, w której nie szczędzi słów krytyki pod adresem Franciszka.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6627288?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6627288?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 04:46:56+00:00
 - user: None

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j78l8k-zniszczenia-w-mikolajowie-po-rosyjskim-ataku-rakietowym-6627181/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 324 dni.

## Nie żyje Lisa Marie Presley, córka Elvisa. Jeszcze we wtorek była na gali Złotych Globów
 - [https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-corka-elvisa-presleya-piosenkarka-miala-54-lata-6627287?source=rss](https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-corka-elvisa-presleya-piosenkarka-miala-54-lata-6627287?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 04:32:18+00:00
 - user: None

<img alt="Nie żyje Lisa Marie Presley, córka Elvisa. Jeszcze we wtorek była na gali Złotych Globów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-73b5gw-lisa-marie-presley-zmarla-w-wieku-54-lat-6627286/alternates/LANDSCAPE_1280" />
    Zmarła w wieku 54 lat.

## Kukła z wizerunkiem Erdogana powieszona za nogi w Sztokholmie
 - [https://tvn24.pl/swiat/szwecja-kukla-z-wizerunkiem-prezydenta-turcji-erdogana-powieszona-za-nogi-w-sztokholmie-6627267?source=rss](https://tvn24.pl/swiat/szwecja-kukla-z-wizerunkiem-prezydenta-turcji-erdogana-powieszona-za-nogi-w-sztokholmie-6627267?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 04:24:49+00:00
 - user: None

<img alt="Kukła z wizerunkiem Erdogana powieszona za nogi w Sztokholmie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e1hqdz-powieszono-kukle-z-wizerunkiem-erdogana-w-sztokholmie-6627253/alternates/LANDSCAPE_1280" />
    Incydent - w momencie, gdy Szwecja zabiega o zgodę Turcji na przystąpienie do NATO - wywołał napięcie.

## "Posłowie oszczędzają. Mówią, że taniej opłaca się zjeść obiad poza restauracją" w Sejmie
 - [https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-102,S00E102,963770?source=rss](https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-102,S00E102,963770?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-13 04:20:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6kducu-sejm-wita-jedzenie-w-restauracji-w-sejmie-6627098/alternates/LANDSCAPE_1280" />
    Radomir Wit w Sejmie.
