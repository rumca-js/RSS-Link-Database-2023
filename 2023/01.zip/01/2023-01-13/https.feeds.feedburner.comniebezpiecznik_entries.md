# Source Niebezpiecznik, Source URL:https://feeds.feedburner.com/niebezpiecznik/, Source language: pl-PL

## Rząd chce jednoznacznie identyfikować użytkowników komunikatorów i usług pocztowych. O co chodzi?
 - [https://niebezpiecznik.pl/post/rzad-chce-jednoznacznie-identyfikowac-uzytkownikow-komunikatorow-i-uslug-pocztowych-o-co-chodzi/](https://niebezpiecznik.pl/post/rzad-chce-jednoznacznie-identyfikowac-uzytkownikow-komunikatorow-i-uslug-pocztowych-o-co-chodzi/)
 - RSS feed: https://feeds.feedburner.com/niebezpiecznik/
 - date published: 2023-01-13 12:17:11+00:00
 - user: None

<a href="https://niebezpiecznik.pl/post/rzad-chce-jednoznacznie-identyfikowac-uzytkownikow-komunikatorow-i-uslug-pocztowych-o-co-chodzi/"><img align="left" alt="" class="alignleft tfe wp-post-image" height="100" hspace="5" src="https://niebezpiecznik.pl/wp-content/uploads/2023/01/yctg-150x150.jpg" width="100" /></a>Rząd chce aby nowe podmioty musiały zbierać więcej informacji na temat swoich użytkowników. Nowe prawo ma dotyczyć przede wszystkim dostawców usług poczty elektronicznej i komunikatorów. Uspokajamy: nie chodzi o przekazywanie skanu dowodu. A raczej, chyba &#8212; bo projekt ustawy nie jest zbyt przejrzysty i jest za to słusznie i mocno krytykowany. Nie do końca wiadomo, [&#8230;]
