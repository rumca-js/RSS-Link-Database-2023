# Source Reclaim The Net, Source URL:https://reclaimthenet.org/feed/, Source language: en-US

## The White House’s most brazen, entitled, social media censorship demands
 - [https://reclaimthenet.org/the-white-houses-social-media-censorship-demands/](https://reclaimthenet.org/the-white-houses-social-media-censorship-demands/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 22:19:12+00:00
 - user: None

<a href="https://reclaimthenet.org/the-white-houses-social-media-censorship-demands/" rel="nofollow" title="The White House&#8217;s most brazen, entitled, social media censorship demands"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/biden-white-house-censorship.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A summary of the latest, sometimes expletive-riddled, revelations.</p>
<p>The post <a href="https://reclaimthenet.org/the-white-houses-social-media-censorship-demands/" rel="nofollow">The White House&#8217;s most brazen, entitled, social media censorship demands</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## First Look: An open-source Slack and Discord competitor
 - [https://reclaimthenet.org/first-look-an-open-source-slack-and-discord-competitor/](https://reclaimthenet.org/first-look-an-open-source-slack-and-discord-competitor/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 22:15:01+00:00
 - user: None

<a href="https://reclaimthenet.org/first-look-an-open-source-slack-and-discord-competitor/" rel="nofollow" title="First Look: An open-source Slack and Discord competitor"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/oslck.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/first-look-an-open-source-slack-and-discord-competitor/" rel="nofollow">First Look: An open-source Slack and Discord competitor</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Former Twitter officials are called to testify on their censorship
 - [https://reclaimthenet.org/former-twitter-officials-are-called-to-testify-on-their-censorship/](https://reclaimthenet.org/former-twitter-officials-are-called-to-testify-on-their-censorship/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 03:15:18+00:00
 - user: None

<a href="https://reclaimthenet.org/former-twitter-officials-are-called-to-testify-on-their-censorship/" rel="nofollow" title="Former Twitter officials are called to testify on their censorship"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/twitter-execs.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The House Oversight Committee has questions about Twitter's censorship revelations.</p>
<p>The post <a href="https://reclaimthenet.org/former-twitter-officials-are-called-to-testify-on-their-censorship/" rel="nofollow">Former Twitter officials are called to testify on their censorship</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## President Biden calls for bipartisan regulation of Big Tech
 - [https://reclaimthenet.org/president-biden-calls-for-bipartisan-regulation-of-big-tech/](https://reclaimthenet.org/president-biden-calls-for-bipartisan-regulation-of-big-tech/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 02:32:18+00:00
 - user: None

<a href="https://reclaimthenet.org/president-biden-calls-for-bipartisan-regulation-of-big-tech/" rel="nofollow" title="President Biden calls for bipartisan regulation of Big Tech"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/biden-letter.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>In a new op-ed.</p>
<p>The post <a href="https://reclaimthenet.org/president-biden-calls-for-bipartisan-regulation-of-big-tech/" rel="nofollow">President Biden calls for bipartisan regulation of Big Tech</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Google tries to get antitrust lawsuit dismissed
 - [https://reclaimthenet.org/google-tries-to-get-antitrust-lawsuit-dismissed/](https://reclaimthenet.org/google-tries-to-get-antitrust-lawsuit-dismissed/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 02:01:41+00:00
 - user: None

<a href="https://reclaimthenet.org/google-tries-to-get-antitrust-lawsuit-dismissed/" rel="nofollow" title="Google tries to get antitrust lawsuit dismissed"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/big-t2.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The Big Tech giant argues it didn't break antitrust law.</p>
<p>The post <a href="https://reclaimthenet.org/google-tries-to-get-antitrust-lawsuit-dismissed/" rel="nofollow">Google tries to get antitrust lawsuit dismissed</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Twitter disclosures show no sign of Russian influence, despite media and Democrat insistence
 - [https://reclaimthenet.org/twitter-disclosures-show-no-sign-of-russian-influence/](https://reclaimthenet.org/twitter-disclosures-show-no-sign-of-russian-influence/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-13 00:54:31+00:00
 - user: None

<a href="https://reclaimthenet.org/twitter-disclosures-show-no-sign-of-russian-influence/" rel="nofollow" title="Twitter disclosures show no sign of Russian influence, despite media and Democrat insistence"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/democrats-russia-influence-twitter-no-evidence-1.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Twitter staff expressed exasperation at "feeding congressional trolls."</p>
<p>The post <a href="https://reclaimthenet.org/twitter-disclosures-show-no-sign-of-russian-influence/" rel="nofollow">Twitter disclosures show no sign of Russian influence, despite media and Democrat insistence</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>
