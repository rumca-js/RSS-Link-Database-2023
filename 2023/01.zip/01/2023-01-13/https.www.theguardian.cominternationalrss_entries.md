# Source The Guardian - International, Source URL:https://www.theguardian.com/international/rss, Source language: en-US

## Prince Harry: I left out details as I feared family would not forgive me
 - [https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-i-left-out-details-as-i-feared-family-would-not-forgive-me](https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-i-left-out-details-as-i-feared-family-would-not-forgive-me)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 23:56:18+00:00
 - user: None

<p>Duke of Sussex tells Telegraph that he has enough material for another memoir and his original draft was twice as long</p><p>Prince Harry says he has enough material to write another memoir and chose not to publish some details as he was concerned his father and brother would never forgive him if they were made public.</p><p>In an interview with the Daily Telegraph, the Duke of Sussex also said the initial transcript for Spare was twice the length of the final draft and he had found it difficult to work out what to remove.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-i-left-out-details-as-i-feared-family-would-not-forgive-me">Continue reading...</a>

## A lack of Styles: Gucci showcases new direction for its menswear
 - [https://www.theguardian.com/fashion/2023/jan/13/a-lack-of-styles-gucci-showcases-new-direction-for-its-menswear](https://www.theguardian.com/fashion/2023/jan/13/a-lack-of-styles-gucci-showcases-new-direction-for-its-menswear)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 23:30:35+00:00
 - user: None

<p>There were still nods to the flamboyant looks favoured by the singer but also more sober pieces inspired by the brand’s history</p><p>The real giveaway at a fashion show is not the clothes you see on the catwalk but the celebrities in the audience, hoping to get a sneak preview of what they can wear to the Oscars. So what was Idris Elba, known for his slick suits and brogues, doing at a Gucci menswear show in Milan, best known for its babydoll dresses and pearls?</p><p>As the lights went up, this became clear. Out walked a model in wide-legged suit trousers, a tight white T-shirt and a tiny beanie. There was no costume jewellery, no pussy-bow blouses, and no Harry Styles in the front row. Instead: bomber jackets, oversized blazers and gilets, and the return of the deep V white T-shirt. </p> <a href="https://www.theguardian.com/fashion/2023/jan/13/a-lack-of-styles-gucci-showcases-new-direction-for-its-menswear">Continue reading...</a>

## Five-try Leicester beat Clermont and storm into last 16 of Champions Cup
 - [https://www.theguardian.com/sport/2023/jan/13/five-try-leicester-storm-to-last-16-of-heineken-champions-cup](https://www.theguardian.com/sport/2023/jan/13/five-try-leicester-storm-to-last-16-of-heineken-champions-cup)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 22:32:54+00:00
 - user: None

<p>Tigers beat Clermont 44-29 in France to put poor domestic form behind them and qualify with a game to spare</p><p>Leicester qualified for the last 16 of the Heineken Cup with a game to spare after a stirring bonus-point victory at Clermont. Richard Wigglesworth’s side had suffered heavy losses in their last two league outings but looked to have adapted to life without Steve Borthwick in France. Matt Scott, Harry Simmons and Dan Kelly all scored in the first half and two more tries after the break put Leicester at the top of Pool B before the other 10 teams play this weekend.</p><p>Following Borthwick’s appointment as England head coach, Wigglesworth was taking charge of his first European game having served as a replacement scrum-half in Leicester’s previous two wins in the competition. After a couple of rocky weeks in the Premiership, Tigers made themselves comfortable early in France with Scott’s interception score, but Clermont hit back through Bautista Delguy after Handré Pollard’s penalty.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/five-try-leicester-storm-to-last-16-of-heineken-champions-cup">Continue reading...</a>

## Rampant Napoli thrash Juventus to open up 10-point advantage in Serie A
 - [https://www.theguardian.com/football/2023/jan/13/napoli-thrash-juventus-serie-a-victor-osimhen](https://www.theguardian.com/football/2023/jan/13/napoli-thrash-juventus-serie-a-victor-osimhen)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 22:26:31+00:00
 - user: None

<ul><li>Victor Osimhen scores twice in crushing 5-1 win over title rivals</li><li>Juventus had won eight matches in a row without conceding</li></ul><p>Two of Napoli’s most influential players combined for what could be their most crucial win in this campaign and brought Juventus’s recent revival to a juddering halt.</p><p>Victor Osimhen scored twice and Khvicha Kvaratskhelia once, also setting up each other’s goals, to help the Serie A leaders Napoli crush second-placed Juventus 5-1 and open up a 10-point lead.</p> <a href="https://www.theguardian.com/football/2023/jan/13/napoli-thrash-juventus-serie-a-victor-osimhen">Continue reading...</a>

## Japan’s PM vows to modernise military for new era of threats
 - [https://www.theguardian.com/world/2023/jan/13/japans-pm-vows-to-modernise-military-for-new-era-of-threats](https://www.theguardian.com/world/2023/jan/13/japans-pm-vows-to-modernise-military-for-new-era-of-threats)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 22:15:47+00:00
 - user: None

<p>Fumio Kishida outlines step change in US-Japan security alliance after White House meeting with Joe Biden</p><p>Japan’s prime minister, Fumio Kishida, has pledged to modernise his country’s military alongside US president Joe Biden, warning that Russia’s invasion of Ukraine had opened a dangerous new era and could embolden China.</p><p>Welcoming Kishida at the White House, Biden hailed the Japanese government’s announcement last month that <a href="https://www.theguardian.com/world/2022/dec/16/japan-approves-biggest-military-buildup-since-second-world-war-amid-china-fears">it will double defence spending</a> over the next five years and develop new capabilities.</p> <a href="https://www.theguardian.com/world/2023/jan/13/japans-pm-vows-to-modernise-military-for-new-era-of-threats">Continue reading...</a>

## Aston Villa’s Leon Bailey and Emi Buendía extend Leeds’ worrying run
 - [https://www.theguardian.com/football/2023/jan/13/aston-villas-leon-bailey-and-emi-buendia-extend-leeds-worrying-run](https://www.theguardian.com/football/2023/jan/13/aston-villas-leon-bailey-and-emi-buendia-extend-leeds-worrying-run)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 22:12:46+00:00
 - user: None

<ul><li>Aston Villa 2-1 Leeds</li><li>Bailey and Buendía on target for Villa, Bamford replies for Leeds</li></ul><p>For Emiliano Martínez, this chilly evening in Aston must have felt strangely reminiscent of the World Cup on the Persian Gulf last month. There was the magnificent point-blank save to deny Jack Harrison and Leeds a certain equaliser on the brink of half-time; a replica of the free-kick from which Wout Weghorst, the Netherlands striker who has just joined Manchester United, scored to force extra-time in the quarter-final; there were the dark arts that infuriated Jesse Marsch on the touchline. And, ultimately, there was a sweet victory at the end of it all.</p><p>The Leeds substitute Patrick Bamford, who underwent groin surgery in Munich last month, stepped off the bench to strike but it proved nothing more than a consolation after goals by Leon Bailey and Emi Buendía earned Villa victory. For Unai Emery, it is now 13 points from six Premier League games, eclipsing Steven Gerrard’s total in the first 13 matches of the season. For Leeds, the worrying run continues; they have won two of their past 17 matches in all competitions.</p> <a href="https://www.theguardian.com/football/2023/jan/13/aston-villas-leon-bailey-and-emi-buendia-extend-leeds-worrying-run">Continue reading...</a>

## I heard the siren song of the professional mermaid, but I still haven’t found my voice | Megan Dunn
 - [https://www.theguardian.com/commentisfree/2023/jan/13/i-heard-the-siren-song-of-the-professional-mermaid-but-i-still-havent-found-my-voice](https://www.theguardian.com/commentisfree/2023/jan/13/i-heard-the-siren-song-of-the-professional-mermaid-but-i-still-havent-found-my-voice)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 22:00:26+00:00
 - user: None

<p>Hundreds of mermaids work in aquariums across the world – from Texas to Denmark – and I need you to listen to what they have to say</p><ul><li><a href="https://www.theguardian.com/newsletters/2019/oct/18/saved-for-later-sign-up-for-guardian-australias-culture-and-lifestyle-email?CMP=cvau_sfl">Get our weekend culture and lifestyle email</a></li></ul><p>“I can’t have a baby at 40, I’m not Nicole Kidman.” That was my mantra when I was 39. I kept saying it to close friends and cackling with laughter. Then the unthinkable happened. I had a baby at 40, didn’t sleep through the night for two years, woke up aged 42 and heard the mermaids.</p><p>I heard them because I called them. What motivated me? Poetry. TS Eliot’s The Love Song of J. Alfred Prufrock reads: “I have heard the mermaids singing, each to each. I do not think that they will sing to me.” That’s because he’s a man, I thought. I will Skype the mermaids, and because I’m a woman it will be easy. We’ll relate, each to each.</p><p><strong><a href="https://www.theguardian.com/newsletters/2019/oct/18/saved-for-later-sign-up-for-guardian-australias-culture-and-lifestyle-email?CMP=copyembed">Sign up for the fun stuff with our rundown of must-reads, pop culture and tips for the weekend, every Saturday morning</a></strong></p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/i-heard-the-siren-song-of-the-professional-mermaid-but-i-still-havent-found-my-voice">Continue reading...</a>

## Judge calls Trump’s attempt to dismiss E Jean Carroll rape lawsuit ‘absurd’
 - [https://www.theguardian.com/us-news/2023/jan/13/trumps-e-jean-carroll-lawsuit-absurd-ruling](https://www.theguardian.com/us-news/2023/jan/13/trumps-e-jean-carroll-lawsuit-absurd-ruling)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 21:57:24+00:00
 - user: None

<p>Ruling made in second case brought against former president by writer who alleges he sexually assaulted her in Bergdorf Goodman</p><p>A judge on Friday rejected as “absurd” Donald Trump’s attempt to dismiss a lawsuit from the writer E Jean Carroll, who alleges he raped her in a department store changing room in New York in the mid-1990s.</p><p>Carroll has sued Trump for defamation, for remarks while denying her allegation including that she was not his “type”.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/trumps-e-jean-carroll-lawsuit-absurd-ruling">Continue reading...</a>

## Judd Trump storms back to beat Barry Hawkins and make Masters semi-final
 - [https://www.theguardian.com/sport/2023/jan/13/judd-trump-storms-back-to-beat-barry-hawkins-and-make-masters-semi-final](https://www.theguardian.com/sport/2023/jan/13/judd-trump-storms-back-to-beat-barry-hawkins-and-make-masters-semi-final)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 20:17:29+00:00
 - user: None

<p>• Former champion hits a 143 break at Alexandra Palace</p><p>• Hawkins had led 5-4 but Trump levelled with a break of 107</p><p>Judd Trump escaped from the jaws of defeat to beat Barry Hawkins and book his place in the semi-final of the Masters.</p><p>The 2019 champion trailed Hawkins 5-4 in their best-of-11 last-eight encounter at Alexandra Palace. But Trump, who earlier matched the highest break of the week with a 143, delivered a clearance of 107 in the 10th frame to set up a decider.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/judd-trump-storms-back-to-beat-barry-hawkins-and-make-masters-semi-final">Continue reading...</a>

## How Lisa Marie Presley found triumph amid tragedy
 - [https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-music-legacy](https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-music-legacy)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 20:07:17+00:00
 - user: None

<p>The daughter of Elvis Presley had difficulties in and out of the spotlight but found a way to strike out and succeed on her own</p><ul><li><a href="https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-singer-and-daughter-of-elvis-dies-aged-54">Lisa Marie Presley, singer and daughter of Elvis, dies aged 54</a></li><li><a href="https://www.theguardian.com/music/gallery/2023/jan/13/lisa-marie-presley-a-life-in-pictures">Lisa Marie Presley – a life in pictures</a></li></ul><p>Children of celebrities are often unfairly placed under a public microscope, especially when the celebrity is the subject of salacious tabloid stories. Lisa Marie Presley, who <a href="https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-singer-and-daughter-of-elvis-dies-aged-54">died on Thursday at the age of 54</a> after reportedly going into cardiac arrest at her home, was acutely aware of this fact from a young age.</p><p>The only daughter of Elvis Presley, she was just a child when she recalled fans hiding in the trees and trespassing at her family’s estate, Graceland. Her response was clever and defiant. “People would give me cameras to go and take pictures, and I’d take money and I’d say I was going to take a picture of my dad, and then I’d throw the camera somewhere,” <a href="https://www.elvis.com.au/presley/interview-lisamarie-rollingstone.shtml">she told Rolling Stone in 2003</a>.</p> <a href="https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-music-legacy">Continue reading...</a>

## Aston Villa v Leeds United: Premier League – live
 - [https://www.theguardian.com/football/live/2023/jan/13/aston-villa-leeds-united-premier-league-live](https://www.theguardian.com/football/live/2023/jan/13/aston-villa-leeds-united-premier-league-live)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 19:55:09+00:00
 - user: None

<ul><li>Premier League game at Villa Park kicks off at 8pm (GMT)</li><li><a href="https://www.theguardian.com/football/2023/jan/13/premier-league-10-things-to-look-out-for-this-weekend">10 things to look out for this weekend in the top flight</a></li><li>Share your thoughts with John <a href="mailto:john.brewin.casual@theguardian.com">via email</a> or <a href="https://twitter.com/JohnBrewin_">on Twitter</a></li></ul><p><strong>Hi Ho Silver Lining is pumping out at Villa Park</strong>, with extra poignancy added by this week’s loss of Jeff Beck, the singer who hated his own most famous song as he sang on it. Rod Stewart on backing vocals, John Paul Jones on bass, and a huge hit. </p><p><strong>The Premier League table suggests Leeds are within reach of both comfort and worry.</strong> </p> <a href="https://www.theguardian.com/football/live/2023/jan/13/aston-villa-leeds-united-premier-league-live">Continue reading...</a>

## The week around the world in 20 pictures
 - [https://www.theguardian.com/artanddesign/gallery/2023/jan/13/the-week-around-the-world-in-20-pictures](https://www.theguardian.com/artanddesign/gallery/2023/jan/13/the-week-around-the-world-in-20-pictures)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 19:01:22+00:00
 - user: None

<p>The failed coup attempt in Brazil, the relentless assault on Bakhmut by Russian forces, floods in California and Prince Harry’s memoir Spare is released – the most striking images this week</p> <a href="https://www.theguardian.com/artanddesign/gallery/2023/jan/13/the-week-around-the-world-in-20-pictures">Continue reading...</a>

## Manchester United head into season’s second derby transformed by Ten Hag
 - [https://www.theguardian.com/football/2023/jan/13/manchester-united-head-into-derby-transformed-erik-ten-hag](https://www.theguardian.com/football/2023/jan/13/manchester-united-head-into-derby-transformed-erik-ten-hag)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 19:00:23+00:00
 - user: None

<p>United were blitzed 6-3 at the Etihad in October but their revival since has been remarkable and they should test City </p><p>Manchester United’s turnaround between October’s derby with Manchester City and the return fixture on Saturday suggests Erik ten Hag can be the man who finally casts Sir Alex Ferguson’s gilded era in sepia.</p><p>At the Etihad Stadium United were <a href="https://www.theguardian.com/football/2022/oct/02/manchester-city-manchester-united-premier-league-match-report">blitzed 6-3 by the champions</a>, going 4-0 down before half-time and 6-1 down after 64 minutes, on a dark afternoon for the club that featured hat-tricks from Erling Haaland and Phil Foden. Ten Hag’s men were fortunate not to suffer a double-digit defeat, and the Dutchman’s verdict was pithy: “We were not on the front foot and we were not brave in possession. [There] was a lack of belief.”</p> <a href="https://www.theguardian.com/football/2023/jan/13/manchester-united-head-into-derby-transformed-erik-ten-hag">Continue reading...</a>

## Novak Djokovic’s Melbourne return feels oddly normal after 2022 frenzy | Tumaini Carayol
 - [https://www.theguardian.com/sport/blog/2023/jan/13/novak-djokovic-melbourne-return-australian-open-tennis](https://www.theguardian.com/sport/blog/2023/jan/13/novak-djokovic-melbourne-return-australian-open-tennis)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 19:00:23+00:00
 - user: None

<p>The nine-times Australian Open champion shows no sign of a hangover from last year’s controversy and is the player to beat</p><p>In the hours after Novak Djokovic was briefly freed from government custody in Melbourne last year, his visa cancellation overturned on procedural grounds, he headed straight for the tennis court to resume his suspended preparation for the Australian Open. His first hitting session was played out behind closed doors at night, but by the time he returned in the day, chaos reigned over Melbourne Park. Fans and journalists alike tried to slip inside Rod Laver Arena, <a href="https://twitter.com/SkySportsNews/status/1480817769360859136">drones whirled overhead</a> just to get an unauthorised glimpse of him in action.</p><p>Outside of Park Hotel,where he was being detained, Djokovic’s fans congregated to dance and cheer, activists marked their presence in support of the dozens of asylum seekers also being held there and anti-vaxxers could not stay away. When Djokovic visited his lawyers upon his return to government custody, his supporters crowded the office and any car that left before being teargassed in the middle of Melbourne’s central business district.</p> <a href="https://www.theguardian.com/sport/blog/2023/jan/13/novak-djokovic-melbourne-return-australian-open-tennis">Continue reading...</a>

## Wild, soaked and exhilarated: my 12 years as the keeper of Quarantine Island
 - [https://www.theguardian.com/news/2023/jan/14/wild-soaked-and-exhilarated-my-12-years-as-the-keeper-of-quarantine-island](https://www.theguardian.com/news/2023/jan/14/wild-soaked-and-exhilarated-my-12-years-as-the-keeper-of-quarantine-island)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 19:00:23+00:00
 - user: None

<p>In an extract from her book Seaswept, Kathy Morrison tells of managing an isolated community in southern New Zealand</p><p>Dave Wilson [the former keeper] welcomed me to the island for the first time in 1992. Walking up the track to the remaining chimney of the old quarantine hospital on top of the hill, Dave confided that he was often lonely and thought that, although he loved the island, it was probably better suited to a family. He smiled cheekily at me and suggested that I would be a good person for the job and the transitions that would be needed in the near future.</p><p>Nothing was further from my mind.</p> <a href="https://www.theguardian.com/news/2023/jan/14/wild-soaked-and-exhilarated-my-12-years-as-the-keeper-of-quarantine-island">Continue reading...</a>

## Cross-party MPs launch fightback against bill to tear up 4,000 EU laws
 - [https://www.theguardian.com/politics/2023/jan/13/cross-party-mps-stella-creasy-fightback-bill-tear-up-eu-laws](https://www.theguardian.com/politics/2023/jan/13/cross-party-mps-stella-creasy-fightback-bill-tear-up-eu-laws)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 18:41:13+00:00
 - user: None

<p>Amendment seeks to give MPs not ministers the power to decide which Brussels-derived laws are abolished</p><p>A cross-party group of MPs including Labour’s Stella Creasy and the Conservative former Brexit secretary David Davis are launching an attempt to rein in the EU retained law bill that threatens to let ministers abolish 4,000 laws derived from Brussels at the end of this year.</p><p>Creasy and Davis have put their names to an amendment that would give MPs, rather than ministers, the power to decide which laws are retained.</p> <a href="https://www.theguardian.com/politics/2023/jan/13/cross-party-mps-stella-creasy-fightback-bill-tear-up-eu-laws">Continue reading...</a>

## RFU confirms departure of attack coach Martin Gleeson after Nick Evans’ arrival
 - [https://www.theguardian.com/sport/2023/jan/13/england-rugby-union-martin-gleeson-leaves-nick-evans-attack-coach](https://www.theguardian.com/sport/2023/jan/13/england-rugby-union-martin-gleeson-leaves-nick-evans-attack-coach)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 18:30:23+00:00
 - user: None

<ul><li>Fourth member of Eddie Jones’s team to depart England setup</li><li>Gleeson: ‘It’s been a pleasure to represent my country again’</li></ul><p>Steve Borthwick’s cull of Eddie Jones’s assistants has continued with Martin Gleeson leaving his job as England attack coach. Gleeson’s departure appeared inevitable after <a href="https://www.theguardian.com/sport/2023/jan/06/nick-evans-named-englands-attack-coach-for-six-nations-campaign">Nick Evans was handed the reins of the attack</a> last week, and the Rugby Football Union confirmed his exit with immediate effect on Friday.</p><p><a href="https://www.theguardian.com/sport/2021/sep/28/martin-gleeson-vows-to-add-creativity-to-england-attack-before-rugby-world-cup">Gleeson was appointed in August 2021</a> – the latest in a long line of Jones’s attack coaches – but while he came with a burgeoning reputation from his time at Wasps, following a switch from rugby league, he was largely unable to ignite England’s backline. That was no more evident than the limited success brought by the 10-12 axis of Marcus Smith and Owen Farrell, with Evans suggesting this week that there is room for improvement in that partnership.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/england-rugby-union-martin-gleeson-leaves-nick-evans-attack-coach">Continue reading...</a>

## BBC criticised for letting cardiologist ‘hijack’ interview with false Covid jab claim
 - [https://www.theguardian.com/world/2023/jan/13/bbc-cardiologist-aseem-malhotra-links-covid-jabs-to-heart-disease-deaths](https://www.theguardian.com/world/2023/jan/13/bbc-cardiologist-aseem-malhotra-links-covid-jabs-to-heart-disease-deaths)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:50:53+00:00
 - user: None

<p>Aseem Malhotra’s ‘misguided’ views linking some Covid vaccines to excess heart disease deaths should not have aired, say experts</p><p>The BBC has come under fire from scientists for interviewing a cardiologist who claimed certain Covid vaccines could be behind excess deaths from coronary artery disease.</p><p>Experts have criticised Dr Aseem Malhotra’s appearance on the corporation’s news channel on Friday, accusing him of pushing “extreme fringe” views, which are “misguided”, “dangerous” and could mislead the public.</p> <a href="https://www.theguardian.com/world/2023/jan/13/bbc-cardiologist-aseem-malhotra-links-covid-jabs-to-heart-disease-deaths">Continue reading...</a>

## Wada ‘concern’ as Rusada clears Valieva of wrongdoing over doping scandal
 - [https://www.theguardian.com/sport/2023/jan/13/wada-concern-after-valieva-cleared-wrongdoing-over-doping-scandal](https://www.theguardian.com/sport/2023/jan/13/wada-concern-after-valieva-cleared-wrongdoing-over-doping-scandal)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:47:15+00:00
 - user: None

<ul><li>Figure skater cleared by a Russian Anti-Doping Agency tribunal</li><li>Wada hints it could take case to Court of Arbitration for Sport</li></ul><p>The brilliant 16-year-old Russian figure skater Kamila Valieva, whose positive doping test <a href="https://www.theguardian.com/sport/blog/2022/feb/14/valieva-caught-in-a-complicated-mess-that-has-been-coming-for-years">dominated headlines</a> at the 2022 Winter Olympics, has been cleared of any wrongdoing by a Russian Anti-Doping Agency tribunal.</p><p>That is unlikely to be the end of the matter, however, with the World Anti-Doping Agency expressing its “concern” at the decision – before hinting that it could challenge the ruling at the Court of Arbitration for Sport.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/wada-concern-after-valieva-cleared-wrongdoing-over-doping-scandal">Continue reading...</a>

## UK may shelve controversial Brexit protocol bill in show of goodwill to EU
 - [https://www.theguardian.com/politics/2023/jan/13/uk-may-shelve-controversial-brexit-protocol-bill-sign-goodwill](https://www.theguardian.com/politics/2023/jan/13/uk-may-shelve-controversial-brexit-protocol-bill-sign-goodwill)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:44:35+00:00
 - user: None

<p>Negotiators on both sides hopeful they may be able to enter intense ‘tunnel’ phase of talks next week</p><p>Ministers could shelve proposed legislation to allow the UK to unilaterally rip up some Brexit arrangements for Northern Ireland as a sign of goodwill in negotiations with the EU, the Guardian has been told.</p><p>EU and UK negotiators are hopeful they may be able to enter the “tunnel” phase of negotiations next week. That phase, which involves intense negotiations with no public comment, is likely to be scheduled after a meeting between the UK foreign secretary, James Cleverly, and the European Commission vice-president Maroš Šefčovič on Monday.</p> <a href="https://www.theguardian.com/politics/2023/jan/13/uk-may-shelve-controversial-brexit-protocol-bill-sign-goodwill">Continue reading...</a>

## Ezra Miller pleads guilty to unlawful trespassing in Vermont
 - [https://www.theguardian.com/film/2023/jan/13/ezra-miller-pleads-guilty-unlawful-trespassing-vermont](https://www.theguardian.com/film/2023/jan/13/ezra-miller-pleads-guilty-unlawful-trespassing-vermont)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:36:14+00:00
 - user: None

<p>Actor will be subject to a $500 fine and a year of probation for breaking into a neighbor’s home and stealing liquor</p><p>The actor Ezra Miller has pleaded guilty to unlawful trespassing in Vermont after being charged with stealing liquor from a neighbor’s home in May.</p><p>Miller, who appeared in several Justice League films and stars in the upcoming feature The Flash, agreed that by entering the plea and abiding by the conditions, they would avoid a three-month jail sentence and be subject instead to a $500 fine and a court fee, a year of probation and conditions including continued mental health treatment.</p> <a href="https://www.theguardian.com/film/2023/jan/13/ezra-miller-pleads-guilty-unlawful-trespassing-vermont">Continue reading...</a>

## Amy Winehouse biopic: first photo released of Marisa Abela as late singer
 - [https://www.theguardian.com/music/2023/jan/13/amy-winehouse-biopic-first-photo-released-of-marisa-abela-as-late-singer](https://www.theguardian.com/music/2023/jan/13/amy-winehouse-biopic-first-photo-released-of-marisa-abela-as-late-singer)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:23:53+00:00
 - user: None

<p>Industry actor pictured with singer’s trademark beehive, as Sam Taylor-Johnson’s Back to Black set to start shooting this month</p><p>Last year it was announced that Sam Taylor-Johnson would direct an Amy Winehouse biopic titled Back to Black. Now the first image has been released of Marisa Abela in the title role, wearing the late singer’s trademark black beehive and gold hoop earrings. </p><p>Back to Black will chronicle Winehouse’s time living in London in the early 00s and her rise to fame. The film was written by the Manchester-born screenwriter Matt Greenhalgh, who wrote the script for Taylor-Johnson’s 2009 John Lennon biopic <a href="https://www.theguardian.com/film/2009/dec/17/nowhere-boy-review">Nowhere Boy</a>, and unlike the Oscar-winning 2015 documentary Amy, Back to Black has been authorised by the Amy Winehouse estate.</p> <a href="https://www.theguardian.com/music/2023/jan/13/amy-winehouse-biopic-first-photo-released-of-marisa-abela-as-late-singer">Continue reading...</a>

## Rishi Sunak ‘concerned’ about impact of Scotland’s gender recognition bill
 - [https://www.theguardian.com/society/2023/jan/13/rishi-sunak-concerned-impact-scotland-gender-recognition-bill](https://www.theguardian.com/society/2023/jan/13/rishi-sunak-concerned-impact-scotland-gender-recognition-bill)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:06:45+00:00
 - user: None

<p>PM dodges questions about whether he would stop controversial bill receiving royal assent</p><p>Rishi Sunak has voiced renewed concerns about gender recognition legislation passed by the Scottish parliament last month, in a sign the UK government could still step in to block it.</p><p>Ahead of the deadline for Downing Street to intervene if it wants to curtail the move, the prime minister dodged questions about whether he would stop the bill receiving royal assent and said that seeking advice on the issue was “standard practice”.</p> <a href="https://www.theguardian.com/society/2023/jan/13/rishi-sunak-concerned-impact-scotland-gender-recognition-bill">Continue reading...</a>

## Tatjana Patitz obituary
 - [https://www.theguardian.com/fashion/2023/jan/13/tatjana-patitz-obituary](https://www.theguardian.com/fashion/2023/jan/13/tatjana-patitz-obituary)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:05:48+00:00
 - user: None

<p>One of the first supermodels, in demand by photographers for her intriguing features, glamour and sophistication</p><p>Of the many Vogue covers featuring the model Tatjana Patitz, shot by three generations of star photographers, the best are the least fashiony, those where you do not want to subtract the clothes, makeup and frequent drastic changes of hairstyle inflicted on her, especially in youth. The greatest is from 1988, a tight close-up by <a href="https://www.theguardian.com/news/2002/dec/28/guardianobituaries.artsobituaries">Herb Ritts</a> of her face shadowed in chiffon but still so powerful it shakes off the lettering and barcode that clutter the page. <br /><br />Ritts said Patitz’s features were “a bit off”, which only made her more intriguing to capture. She was barely 23 when she modelled for the sequence from which that cover was cropped, arranging her almost 6ft tall, emphatically curved frame sinuously in body stocking and tights.</p><p>That was the year that she was transformed from a model in top-end work into one of the about-to-be-a-phenomenon “supermodels”, when the photographer <a href="https://www.theguardian.com/artanddesign/2019/sep/09/peter-lindbergh-obituary">Peter Lindbergh</a> included her among the unconventional newcomers he took to a California beach to lark before his camera. Even among his cast of wind-mussed, sun-smudged, tanned tall beauties in white shirts, Patitz stood out; she was having as good a time as the others, but seemed to be inhabiting happiness rather than performing it, and radiated it without the toothy rictus standard in fashion images. (Lindbergh loved Patitz, especially when she didn’t<em> </em>smile; they worked together on and off for 30 years.) <a href="https://www.theguardian.com/music/2016/dec/26/george-michael-obituary-wham-pop-star">George Michael</a> made her status clear when he asked Patitz to join her fellow supers, Christy Turlington, Naomi Campbell, Linda Evangelista and Cindy Crawford, in lip-syncing in his video for Freedom! 90.</p> <a href="https://www.theguardian.com/fashion/2023/jan/13/tatjana-patitz-obituary">Continue reading...</a>

## Mercedes’ James Vowles to leave and become F1 team principal at Williams
 - [https://www.theguardian.com/sport/2023/jan/13/mercedes-james-vowles-to-leave-and-become-f1-team-principal-at-williams](https://www.theguardian.com/sport/2023/jan/13/mercedes-james-vowles-to-leave-and-become-f1-team-principal-at-williams)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 17:03:27+00:00
 - user: None

<ul><li>Director of strategy has been seen as key to Mercedes’ success</li><li>Lewis Hamilton congratulates Vowles on ‘amazing’ opportunity</li></ul><p>The Mercedes director of strategy James Vowles is to leave the team to take over as team principal at Williams. The move is a blow to Mercedes with Vowles occupying a crucial role in the team and being a key contributor to their success over the past decade.</p><p>The team principal Toto Wolff, however, was optimistic Mercedes were in a strong position to cope with his departure.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/mercedes-james-vowles-to-leave-and-become-f1-team-principal-at-williams">Continue reading...</a>

## Sports quiz of the week: winners and losers, lovers and leavers
 - [https://www.theguardian.com/sport/2023/jan/13/sports-quiz-of-the-week-winners-losers-lovers-leavers-football](https://www.theguardian.com/sport/2023/jan/13/sports-quiz-of-the-week-winners-losers-lovers-leavers-football)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 16:54:11+00:00
 - user: None

<p>Who screamed? Who was scared? Who saw red?</p> <a href="https://www.theguardian.com/sport/2023/jan/13/sports-quiz-of-the-week-winners-losers-lovers-leavers-football">Continue reading...</a>

## Adidas loses four stripes court battle with designer Thom Browne
 - [https://www.theguardian.com/fashion/2023/jan/13/adidas-loses-four-stripes-court-battle-designer-thom-browne](https://www.theguardian.com/fashion/2023/jan/13/adidas-loses-four-stripes-court-battle-designer-thom-browne)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 16:15:51+00:00
 - user: None

<p>Sportswear company claimed fashion label’s motif was too similar to its trademark three-stripe logo</p><p>Adidas has lost a court case against the designer Thom Browne, after the sportswear company said the use of four stripes in his designs was too close to its trademark three-stripe logo.</p><p>A jury in New York on Thursday rejected the accusation. If successful, Adidas had been asking for $867,225 (£711,244) in potential licensing fees and more than $7m to represent the profit Adidas believes Browne made by using the stripes.</p> <a href="https://www.theguardian.com/fashion/2023/jan/13/adidas-loses-four-stripes-court-battle-designer-thom-browne">Continue reading...</a>

## Plane review – Gerard Butler’s rickety thriller never takes off
 - [https://www.theguardian.com/film/2023/jan/13/plane-review-gerard-butler](https://www.theguardian.com/film/2023/jan/13/plane-review-gerard-butler)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 16:02:26+00:00
 - user: None

<p>The actor plays a pilot tasked with an emergency landing and then an island full of criminals in a B-movie that needs some more thrills</p><p>One of the many reasons schlock horror <a href="https://www.theguardian.com/film/2023/jan/04/m3gan-review-girlbot-horror-offers-entertaining-spin-on-teenage-growing-pains">M3gan</a> become such a surprise critical darling last week was down to Universal’s crafty release strategy, sashaying into the otherwise dead zone of January, easily leaping over an extremely low bar. This week reminds us of what the month usually offers US cinemagoers – <a href="https://www.theguardian.com/film/2023/jan/13/house-party-review-lebron-james">an unwanted comedy remake</a>, <a href="https://variety.com/2023/film/reviews/the-devil-conspiracy-review-1235486365/">a horror film for Christians</a> and a Gerard Butler action thriller – junk that’s easy for the studios to dump and even easier for audiences to forget.</p><p>Already the subject of <a href="https://twitter.com/JonBershad/status/1606076080560910336">social media jabs</a> because of its ridiculous title, the Butler of it all, a film about a plane called Plane, is a January movie through and through, filling empty screens just because they need filling, doing the least but at an aggressively loud volume. There have certainly been worse B-movies released in this most cursed of months (last year’s kidnapped mermaid saga <a href="https://www.theguardian.com/film/2022/jan/21/the-kings-daughter-pierce-brosnan-mermaid">The King’s Daughter</a> and 2020’s staggeringly, almost satirically, incompetent Blake Lively thriller <a href="https://www.theguardian.com/film/2020/jan/29/the-rhythm-section-review-blake-lively-jude-law">The Rhythm Section</a> spring to mind) but there have also recently been far better (slay M3gan slay etc) and as such, Plane doesn’t exactly rise above that low bar but sort of meets it head-on.</p> <a href="https://www.theguardian.com/film/2023/jan/13/plane-review-gerard-butler">Continue reading...</a>

## Cocktail of the week: Jacuzzi’s black gold negroni - recipe | The good mixer
 - [https://www.theguardian.com/food/2023/jan/13/cocktail-of-the-week-jacuzzi-black-gold-negroni-recipe](https://www.theguardian.com/food/2023/jan/13/cocktail-of-the-week-jacuzzi-black-gold-negroni-recipe)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 16:00:19+00:00
 - user: None

<p>It’s the classic aperitif rounded out with a judicious poke of balsamic and delicate, orange-blossom overtones</p><p>This drink uses the acidity and sweetness of balsamic vinegar to add depth to the classic negroni, and uses orange blossom-infused gin to add a layer of floral notes. It’s on the menu at our newest trattoria, Jacuzzi, on High Street Kensington, London, which opens later this month.</p><p>Alessandro Tobaldi, bar manager, <a href="https://www.bigmammagroup.com/en/accueil">Big Mamma Group UK</a>, whose latest restaurant, Jacuzzi, opens later this month in London W8.</p> <a href="https://www.theguardian.com/food/2023/jan/13/cocktail-of-the-week-jacuzzi-black-gold-negroni-recipe">Continue reading...</a>

## Our European neighbours now look at post-Brexit Britain and say simply: nein, danke | Jonathan Freedland
 - [https://www.theguardian.com/commentisfree/2023/jan/13/european-brexit-britain-european-eu](https://www.theguardian.com/commentisfree/2023/jan/13/european-brexit-britain-european-eu)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:44:49+00:00
 - user: None

<p>From political dysfunction to economic turmoil, the evidence of Brexit as a great problem-creator is all around. No wonder European support for leaving the EU has tanked since 2016</p><p></p><p>We’re good Europeans at last. Nearly seven years after we voted to leave, Britons are finally doing their bit for the European Union. Diligently and with dogged devotion to duty, we are strengthening the ties that bind the 27 remaining nations of the EU – though not quite in the way anyone would have wanted.</p><p>Take a look at <a href="https://www.theguardian.com/world/2023/jan/12/support-for-leaving-eu-has-fallen-significantly-across-bloc-since-brexit">the Europe-wide survey</a>, published yesterday , which showed that support for leaving the EU has tanked everywhere since 2016. In every EU member state where data was available, from Finland to the Netherlands, Portugal to Hungary, pro-leave sentiment has fallen through the floor. Even Europe’s most hardcore anti-EU parties have abandoned the goal of actually leaving the EU – no more talk of <a href="https://www.theguardian.com/world/2022/apr/15/frexit-what-marine-le-pen-win-mean-eu">Frexit</a> or Italexit – aiming instead merely to reform the union from within.</p><p>Jonathan Freedland is a Guardian columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/european-brexit-britain-european-eu">Continue reading...</a>

## Congresswoman shares story of stillborn son with US House
 - [https://www.theguardian.com/us-news/2023/jan/13/frederica-wilson-house-abortion-republicans](https://www.theguardian.com/us-news/2023/jan/13/frederica-wilson-house-abortion-republicans)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:25:56+00:00
 - user: None

<p>Florida’s Frederica Wilson relives experience being forced to carry a dead baby as Republicans push for anti-abortion measures</p><p>It was a moment of raw humanity in Washington amid federal policy discussions that were largely devoid of it.</p><p>During a week when Republicans, <a href="https://www.theguardian.com/us-news/2023/jan/07/kevin-mccarthy-republican-house-speaker-congress">newly in control</a> of the House of Representatives, discussed whether pharmacy workers <a href="https://www.theguardian.com/us-news/2023/jan/11/new-abortion-restrictions-bills-republicans-house-congress">should be allowed</a> to refuse to fill abortion medication prescriptions due to religious objections, Florida congresswoman Frederica Wilson rose to break a silence she had held.<strong> </strong></p> <a href="https://www.theguardian.com/us-news/2023/jan/13/frederica-wilson-house-abortion-republicans">Continue reading...</a>

## Prince Harry’s revelations won’t help heal childhood traumas, say experts
 - [https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-book-spare-revelations-wont-help-heal-traumas-say-experts](https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-book-spare-revelations-wont-help-heal-traumas-say-experts)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:14:32+00:00
 - user: None

<p>Psychologists and psychotherapists warn tell-all approach could hinder duke from coming to terms with past</p><p>Prince Harry’s revelations of his grievances against the royal family are counterproductive to their reconciliation and to healing his own childhood traumas, relationship experts have said.</p><p>In TV interviews, Harry has defended publishing <a href="https://www.theguardian.com/books/2023/jan/10/spare-prince-harry-review-attempt-reclaim-narrative">his autobiography, Spare</a>, as a measure of last resort, driven by the royal family’s failure to address his “incredibly hurtful” experiences, and that none of his revelations were intended to harm them.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-book-spare-revelations-wont-help-heal-traumas-say-experts">Continue reading...</a>

## What is LockBit ransomware and how does it operate?
 - [https://www.theguardian.com/business/2023/jan/13/what-is-lockbit-ransomware-and-how-does-it-operate-malware-royal-mail](https://www.theguardian.com/business/2023/jan/13/what-is-lockbit-ransomware-and-how-does-it-operate-malware-royal-mail)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:13:26+00:00
 - user: None

<p>Name of malware and criminal group behind it, LockBit has been blamed for attack on Royal Mail</p><p>LockBit has emerged as the most prolific name in ransomware attacks and has now been blamed for an incident that has hit Royal Mail’s <a href="https://www.theguardian.com/business/2023/jan/12/royal-mail-ransomware-attackers-threaten-to-publish-stolen-data">international operations</a>. Here is what we know about LockBit and how it operates.</p> <a href="https://www.theguardian.com/business/2023/jan/13/what-is-lockbit-ransomware-and-how-does-it-operate-malware-royal-mail">Continue reading...</a>

## I watched as LauncherOne aborted its mission – it reminded me of an important truth about failure | Maggie Aderin-Pocock
 - [https://www.theguardian.com/commentisfree/2023/jan/13/launcherone-aborted-mission-space-scientist-failure](https://www.theguardian.com/commentisfree/2023/jan/13/launcherone-aborted-mission-space-scientist-failure)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:06:06+00:00
 - user: None

<p>As a space scientist, I was disappointed on Monday night. But advances in science come from learning, not giving up </p><p>Just like any expectant parent, I had a bag packed and was waiting by the front door. In these situations you never know when things will kick off, so it’s best to be prepared. The birth that I was waiting for was not a child, but the UK’s new launch capability to get baby satellites (known as microsatellites) into space from right here in Britain.</p><p>As a space scientist, and builder of satellites myself, I know of the frustration of a launch. Here in the UK we have developed an industry in small dynamic satellites. Microsatellites, unlike their larger brethren, can be turned around quickly. I spent part of my career working on the <a href="https://www.theguardian.com/science/james-webb-space-telescope">James Webb space telescope</a>, a wonderful piece of hi-tech engineering designed to give us amazing new insight into the early universe and how it evolved. But it took about 40 years to develop, from concept to launch.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/launcherone-aborted-mission-space-scientist-failure">Continue reading...</a>

## Lisa Marie Presley obituary
 - [https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-obituary](https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-obituary)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:05:58+00:00
 - user: None

<p>Daughter of Elvis Presley who spent her life in the spotlight and forged her own career as a singer</p><p>As the only child of Elvis Presley, Lisa Marie Presley, who has died aged 54, spent her life in the spotlight, much of it reflected from her father. She spent years as fodder for the tabloids, a frenzy fed by four marriages, including one to <a href="https://www.theguardian.com/music/2009/jun/26/michael-jackson-obituary">Michael Jackson</a> at the apex of his notoriety and, later in life, delineated in three albums that first dissected her history, and later drew on her father’s musical roots. Her inheritance was not only musical; as his sole heir she became hugely rich, and in nominal control of his lucrative estate. </p><p>Her life in the tabloids began, literally, at birth, with the first photos of her proud parents, Elvis and Priscilla (nee Beaulieu), whom the singer had courted since meeting her when she was 14 and a colonel’s daughter at the US army base in Germany where the world’s most famous private was serving. Lisa Marie was born in Memphis, Tennessee, nine months to the day after her parents married. She spent her early years at Graceland but, when she turned five, she moved with her mother to Los Angeles; the Presleys divorced in 1973. Lisa Marie visited Memphis regularly, where her father doted on her, once flying her in a private jet to Idaho so she could see snow for the first time and play in it for an hour. She was at Graceland when Elvis died in August 1977.</p> <a href="https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-obituary">Continue reading...</a>

## Trump Organization hit with maximum fine over years-long tax fraud
 - [https://www.theguardian.com/us-news/2023/jan/13/trump-organization-sentenced-tax-fraud-scheme](https://www.theguardian.com/us-news/2023/jan/13/trump-organization-sentenced-tax-fraud-scheme)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 15:04:58+00:00
 - user: None

<p>Former president’s business empire fined $1.6m after being convicted last month on 17 charges including falsifying records</p><p>Donald Trump’s business empire, the Trump Organization, was sentenced in a New York court on Friday to the maximum allowable fine of $1.6m for a tax fraud scheme going back at least 10 years.</p><p>Despite the fine itself being relatively small for a huge business, the symbolism of a criminal conviction for an entity so close to the former president is significant.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/trump-organization-sentenced-tax-fraud-scheme">Continue reading...</a>

## ‘Hellish’ battle for Soledar symbolises state of Russia’s war in Ukraine
 - [https://www.theguardian.com/world/2023/jan/13/hellish-battle-soledar-symbolises-russia-war-ukraine](https://www.theguardian.com/world/2023/jan/13/hellish-battle-soledar-symbolises-russia-war-ukraine)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:43:37+00:00
 - user: None

<p>Fall of saltmining town would be propaganda coup for Kremlin but analysts say scale of casualties make it a pyrrhic victory</p><ul><li><strong><a href="https://www.theguardian.com/world/live/2023/jan/13/russia-ukraine-war-live-small-pockets-of-resistance-from-ukraine-in-soledar-says-moscow-installed-official">Russia-Ukraine war – latest news updates</a></strong></li></ul><p>An infantry carrier moves quickly across a devastated landscape, traversing a flat expanse dotted with lines of shattered buildings, some reduced to rubble by artillery fire. At one point a plume of smoke is visible, drifting against the backdrop of a huge open mine works.</p><p>The drone footage shows the carrier, marked with a red cross, halt beside a building missing part of its roof and many of its windows. A Ukrainian medic darts out and peers briefly around the corner of the building as a casualty is brought out on a stretcher. Loaded quickly, the carrier heads away at high speed, coming under Russian artillery fire as it tries to leave the town.</p> <a href="https://www.theguardian.com/world/2023/jan/13/hellish-battle-soledar-symbolises-russia-war-ukraine">Continue reading...</a>

## Trump Organization to be sentenced for tax fraud – live
 - [https://www.theguardian.com/us-news/live/2023/jan/13/trump-organization-sentencing-joe-biden-house-senate-us-politics-latest](https://www.theguardian.com/us-news/live/2023/jan/13/trump-organization-sentencing-joe-biden-house-senate-us-politics-latest)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:25:17+00:00
 - user: None

<p>Business will probably be hit with fines totaling $1.6m, reports say, and ex-president still faces New York attorney general’s lawsuit</p><ul><li><a href="https://www.theguardian.com/info/2018/sep/17/guardian-us-morning-briefing-sign-up-to-stay-informed">Sign up to receive First Thing – our daily briefing by email</a></li></ul><p><em>You may have heard Donald Trump is running for president again – but not much more than that. The former president’s new bid for the White House hasn’t quite had the vigor of his first, successful campaign in 2016, but as the Guardian’s <a href="https://www.theguardian.com/profile/hugo-lowell">Hugo Lowell</a> reports, he’s looking to change that:</em></p><p>Donald Trump is scheduled to venture out of his Mar-a-Lago resort and conduct a swing of presidential campaign events later this month, ramping up efforts to secure the Republican nomination after facing hefty criticism around the slow start to his 2024 White House bid, according to sources familiar with the matter.</p> <a href="https://www.theguardian.com/us-news/live/2023/jan/13/trump-organization-sentencing-joe-biden-house-senate-us-politics-latest">Continue reading...</a>

## Ukraine confident UK will send Challenger 2 tanks to help war effort
 - [https://www.theguardian.com/world/2023/jan/13/ukraine-confident-uk-will-send-challenger-2-tanks-to-help-war-effort](https://www.theguardian.com/world/2023/jan/13/ukraine-confident-uk-will-send-challenger-2-tanks-to-help-war-effort)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:15:09+00:00
 - user: None

<p>Kyiv hopes decision on heavy armour will pave way for Germany to allow re-export of Leopard 2s</p><ul><li><a href="https://www.theguardian.com/world/live/2023/jan/13/russia-ukraine-war-live-small-pockets-of-resistance-from-ukraine-in-soledar-says-moscow-installed-official">Russia-Ukraine war – latest news updates</a></li></ul><p>Ukraine is confident Britain will announce it plans to send about 10 Challenger 2 tanks to Kyiv shortly, a move it hopes will help Germany finally allow its Leopard 2s to be re-exported to the embattled country.</p><p>A formal announcement is anticipated on Monday but Ukrainian sources indicated they understood that Britain had already decided in favour, as pressure mounts on Berlin ahead of a meeting of western defence ministers next Friday.</p> <a href="https://www.theguardian.com/world/2023/jan/13/ukraine-confident-uk-will-send-challenger-2-tanks-to-help-war-effort">Continue reading...</a>

## Greek court drops spying charges against refugee rescue activists
 - [https://www.theguardian.com/world/2023/jan/13/greek-court-drops-spying-charges-against-activist-migrant-rescue-team](https://www.theguardian.com/world/2023/jan/13/greek-court-drops-spying-charges-against-activist-migrant-rescue-team)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:04:19+00:00
 - user: None

<p>Ruling comes hours after UN called for charges to be dropped in ‘largest case of criminalisation of solidarity in Europe’</p><p>A Greek court has dropped espionage charges against 24 activists involved in rescuing refugees, after a lengthy <a href="https://www.theguardian.com/global-development/2023/jan/13/long-awaited-trial-of-24-aid-workers-accused-of-espionage-starts-in-lesbos">trial denounced by rights groups</a> as a sham.</p><p>In the ruling read to the chamber, the court admitted procedural faults, including insufficient translation of prosecution documents, and a lack of access to interpreters for the defendants.</p> <a href="https://www.theguardian.com/world/2023/jan/13/greek-court-drops-spying-charges-against-activist-migrant-rescue-team">Continue reading...</a>

## JP Morgan investment bankers suffer 30% bonus cut as takeover deals slump
 - [https://www.theguardian.com/business/2023/jan/13/jp-morgan-investment-bankers-bonus-cut-takeover-deals-slump](https://www.theguardian.com/business/2023/jan/13/jp-morgan-investment-bankers-bonus-cut-takeover-deals-slump)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:01:24+00:00
 - user: None

<p>Wall Street’s largest lender reports 22% fall in full-year profits including 58% drop in fees from dealmaking</p><p>JP Morgan has slashed bonuses for investment bankers by 30% after a slump in takeover deals as corporate clients braced for a <a href="https://www.theguardian.com/business/2022/sep/26/leading-economies-sliding-into-recession-as-ukraine-war-cuts-growth-finds-oecd">widely predicted recession.</a></p><p>Wall Street’s largest lender reported a 22% drop in full-year profits to $38bn (£31bn) on Friday, having suffered the ripple effects of the economic slowdown linked to the war in Ukraine.</p> <a href="https://www.theguardian.com/business/2023/jan/13/jp-morgan-investment-bankers-bonus-cut-takeover-deals-slump">Continue reading...</a>

## It’s 2023, where are the sex robots? ‘They will probably never be as huge as everyone thinks’
 - [https://www.theguardian.com/lifeandstyle/2023/jan/14/its-2023-where-are-the-sex-robots-they-will-probably-never-be-as-huge-as-everyone-thinks](https://www.theguardian.com/lifeandstyle/2023/jan/14/its-2023-where-are-the-sex-robots-they-will-probably-never-be-as-huge-as-everyone-thinks)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:20+00:00
 - user: None

<p>For at least a decade, researchers have speculated that sex with robots is just around the corner and yet that is yet to materialise</p><p>The man leans towards the woman on his couch. “What is your favourite meal?” he asks, his accent French. “Electricity,” she says, with a strong Scottish inflection. “It provides me energy and has a kick to it.”</p><p>The slight, bespectacled, increasingly bemused man peppers her with questions as they sit. Her blond hair gleams, her dark-rimmed eyes are placid, her lips a full and glossy pout. “Can I call you Charlotte?” he asks.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/14/its-2023-where-are-the-sex-robots-they-will-probably-never-be-as-huge-as-everyone-thinks">Continue reading...</a>

## Jessica Pegula: ‘Mine might not be an underdog story, but it’s a cool story’
 - [https://www.theguardian.com/sport/2023/jan/13/jessica-pegula-mine-might-not-be-an-underdog-story-but-its-a-cool-story](https://www.theguardian.com/sport/2023/jan/13/jessica-pegula-mine-might-not-be-an-underdog-story-but-its-a-cool-story)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:19+00:00
 - user: None

<p>The in-form American on her privileged upbringing, reaching No 3 in the world and her grand slam ambitions</p><p>The first major statement of the new tennis season came swiftly and with devastating force. At the United Cup in Sydney, the new mixed-gender team competition, Poland’s undisputed world No 1, Iga Swiatek, stepped on to the court against the US’s Jessica Pegula with the intention of extending her dominance for another year.</p><p>Instead she received a sharp dose of her own medicine. For just over an hour, Pegula picked Swiatek apart, suffocating her with early, crisp ball-striking, outmuscling her from inside the baseline and laying total waste to her serve. Pegula dusted Swiatek aside with the loss of only four games and briskly moved on.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/jessica-pegula-mine-might-not-be-an-underdog-story-but-its-a-cool-story">Continue reading...</a>

## My parents failed to guide me through my education. Do I confront them?  | Ask Annalisa Barbieri
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/my-parents-failed-to-guide-me-through-my-education-do-i-confront-them](https://www.theguardian.com/lifeandstyle/2023/jan/13/my-parents-failed-to-guide-me-through-my-education-do-i-confront-them)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:19+00:00
 - user: None

<p>Pointing fingers will lead to conflict. Give them an opportunity to share their experience – it may lead to mutual understanding</p><p><strong>Our eldest just started university. We have provided every conceivable support up to now, and also committed to shouldering accommodation costs for the next three years. I didn’t go into higher education when young (I gained </strong><strong>BSc</strong><strong> and </strong><strong>MSc</strong><strong> a couple of years ago) but I’m now realising how much support many children get throughout their education and I can’t help but reflect on the lack of parental support and guidance I received </strong><strong>from my family.</strong></p><p><strong>I’m in my late 40</strong><strong>s and my parents divorced when I was very young. My parents did not go to university themselves but in the post</strong><strong>war years had opportunities to train and gained professional careers.</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/my-parents-failed-to-guide-me-through-my-education-do-i-confront-them">Continue reading...</a>

## Writing wrongs: how true crime authors can fall victim to tragedy
 - [https://www.theguardian.com/books/2023/jan/13/writing-wrongs-true-crime-authors-janice-hallett](https://www.theguardian.com/books/2023/jan/13/writing-wrongs-true-crime-authors-janice-hallett)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:18+00:00
 - user: None

<p>Ever since Truman Capote, writers have struggled to both honour the victims and protect themselves. Novelist Janice Hallett investigates</p><p>“Countdown to DEATH”, “MURDERED by my boyfriend”, “Falling for a KILLER” … the language of true crime lost its potential to shock long ago, yet we continue to be drawn in. High-profile cases, solved or unsolved, seem to provide a bottomless well of fresh evidence and further mystery. What drives so many of us to consume true crime is a need to understand the extremes of humanity from the safe distance of the page or headphone. But for those who write in this genre, a “safe distance” can be hard to find.</p><p>Michelle McNamara is the most recent, and most tragic example. In 2013 McNamara, a journalist and writer, took up the case of the Golden State Killer, a term she coined to bring together a series of murders committed over a wide area of California during the 1970s and 80s. She opened up a trail of cold cases, made links police had missed at the time and often felt herself close to uncovering who the prolific serial killer might have been.</p> <a href="https://www.theguardian.com/books/2023/jan/13/writing-wrongs-true-crime-authors-janice-hallett">Continue reading...</a>

## Ditching cricket series only punishes Afghanistan even more | Shadi Khan Saif
 - [https://www.theguardian.com/commentisfree/2023/jan/13/australia-ditching-uae-cricket-series-only-punishes-afghanistan-even-more](https://www.theguardian.com/commentisfree/2023/jan/13/australia-ditching-uae-cricket-series-only-punishes-afghanistan-even-more)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:17+00:00
 - user: None

<p>Cricket Australia’s decision to cancel series against Afghanistan only serves to further isolate a country already abandoned by the west</p><p>My experience playing in the Australian club cricket scene has shown that players have a resilient fighting spirit and will not surrender without a fight.</p><p>But when I heard Australia was ditching a highly anticipated cricket series against Afghanistan in the United Arab Emirates later this year, it tarnished the image I had built of Australian players. Not a good decision, mate!</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/australia-ditching-uae-cricket-series-only-punishes-afghanistan-even-more">Continue reading...</a>

## It’s hibernation time – so dressing is about how you feel, not how you look | Jess Cartner-Morley
 - [https://www.theguardian.com/fashion/2023/jan/13/it-time-to-hibernate-what-to-wear-at-home-be-warm-stylish](https://www.theguardian.com/fashion/2023/jan/13/it-time-to-hibernate-what-to-wear-at-home-be-warm-stylish)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 14:00:17+00:00
 - user: None

<p>What you wear at home on these long, dark nights is a form of self-care – so embrace soft fabrics and fine layers</p><p>What should you wear when nobody is going to see you? Spoiler alert: the answer is not “who cares”. This is the hibernation month, but we can still make it fashion. Eveningwear is, until further notice, redefined as what to wear when bingeing a box set on the sofa, not how to shine at parties. The long dark nights, the cold, your bank balance and your new year resolutions make staying home feel like the path of least resistance, and besides, everyone else is in the same boat so it’s not like you are missing out on much. </p><p>This kind of eveningwear can be every bit as glorious, in its own way, as a frock and jewels. Hibernation chic is about optimising the way you feel, not the way you look, but that doesn’t mean it has to be schlumpy. I see no logic in making this time of year any more depressing than it is already by dressing in your most ancient tracksuit bottoms and a jumper that has gone bobbly. There is no need to abandon all dignity just because you are at home with the curtains closed. Solo time can be a treat, but only if you treat it as one.</p> <a href="https://www.theguardian.com/fashion/2023/jan/13/it-time-to-hibernate-what-to-wear-at-home-be-warm-stylish">Continue reading...</a>

## Tesla cuts prices by up to a fifth in US and Europe as EV price war starts
 - [https://www.theguardian.com/technology/2023/jan/13/tesla-prices-us-europe-slowing-demand-elon-musk](https://www.theguardian.com/technology/2023/jan/13/tesla-prices-us-europe-slowing-demand-elon-musk)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 13:57:19+00:00
 - user: None

<p>Price of cheapest Model 3 saloon car dropped by £5,500 to £42,990 to combat slowing demand as carmaker shares drop </p><p>Tesla has cut the prices of its cars in the US and Europe by up to a fifth as it contends with slowing demand and increased competition.</p><p>The US carmaker expanded its sales by 40% during 2022 to 1.3m, making it the world’s largest manufacturer of pure battery electric cars, ahead of China’s BYD. However, investors have started to worry that sales growth will be limited by economic slowdowns in some of its key markets.</p> <a href="https://www.theguardian.com/technology/2023/jan/13/tesla-prices-us-europe-slowing-demand-elon-musk">Continue reading...</a>

## When a plan comes together: Martin Ødegaard’s bumpy path to destiny
 - [https://www.theguardian.com/football/2023/jan/13/martin-degaard-bumpy-path-destiny-arsenal-norway](https://www.theguardian.com/football/2023/jan/13/martin-degaard-bumpy-path-destiny-arsenal-norway)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 13:37:06+00:00
 - user: None

<p>Childhood advantages gave him a head start, but obstacles still littered the road to captaining Arsenal and Norway</p><p>There was a football pitch in Drammen. But like most other outdoor pitches in that part of Norway, it was made of hard gravel: built for durability rather than control or technique. So in 2005, Hans Erik Ødegaard and about a dozen other parents simply forked out £50,000 to build a state-of-the-art all-weather surface, just a few hundred yards from the lavish villa he shared with his family.</p><p>Money was not a problem. The Ødegaards ran a chain of high-street clothing stores and Hans had been a professional footballer in his younger days. But he had even grander ambitions for his son, Martin, who even at the age of six could shoot a football at 40mph and possessed an unusual and extravagant range of skills. He couldn’t have known it at the time, but the artificial grass that Hans was paying for might as well have been a red carpet, spiriting his son to the most exclusive enclosure of the professional game.</p> <a href="https://www.theguardian.com/football/2023/jan/13/martin-degaard-bumpy-path-destiny-arsenal-norway">Continue reading...</a>

## Parisian sculpture and a giant insect: Friday’s best photos
 - [https://www.theguardian.com/news/gallery/2023/jan/13/parisian-sculpture-and-a-giant-insect-fridays-best-photos](https://www.theguardian.com/news/gallery/2023/jan/13/parisian-sculpture-and-a-giant-insect-fridays-best-photos)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 13:08:43+00:00
 - user: None

<p>The Guardian’s picture editors select photo highlights from around the world</p> <a href="https://www.theguardian.com/news/gallery/2023/jan/13/parisian-sculpture-and-a-giant-insect-fridays-best-photos">Continue reading...</a>

## At least seven people dead as tornadoes slam US south
 - [https://www.theguardian.com/us-news/2023/jan/13/tornadoes-georgia-alabama-south-death-toll](https://www.theguardian.com/us-news/2023/jan/13/tornadoes-georgia-alabama-south-death-toll)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:52:29+00:00
 - user: None

<p>First responders search for possibly trapped survivors or further victims in Georgia and Alabama after storm eased Thursday night</p><p>First responders are searching for any trapped survivors and any additional victims in on Friday after a massive storm system whipping up severe winds and spawning tornadoes cut a deadly path across the US South the day before, killing at least seven people in Georgia and Alabama.</p><p>A twister damaged buildings and tossed cars in the streets of historic downtown Selma, Alabama. Houses were torn off their foundations and property was smashed up and flattened by flying debris and ripped up trees.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/tornadoes-georgia-alabama-south-death-toll">Continue reading...</a>

## ‘Out of your league’: Shakira song mocking ex Gerard Piqué breaks YouTube record
 - [https://www.theguardian.com/music/2023/jan/13/shakira-gerard-pique-song-breaks-youtube-record](https://www.theguardian.com/music/2023/jan/13/shakira-gerard-pique-song-breaks-youtube-record)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:43:43+00:00
 - user: None

<p>Video with DJ Bizarrap ridiculing footballer’s new relationship racks up 63m views in 24 hours</p><p>A <a href="https://www.youtube.com/watch?v=CocEMWdc7Ck">savage new song by Shakira</a> in which the Colombian star, philanthropist and <a href="https://en.wikipedia.org/wiki/Hips_Don%27t_Lie">committed believer in the veracity of hips</a> ridicules her former partner Gerard Piqué has logged more than 63m YouTube views in 24 hours, making it the most watched new Latin song in the platform’s history.</p><p>Shakira and Piqué, who played football for Barcelona, Manchester United and the Spanish national team, separated last year after more than a decade and have two children. The former centre-back, 35, has since begun a relationship with a 23-year-old woman, Clara Chía.</p> <a href="https://www.theguardian.com/music/2023/jan/13/shakira-gerard-pique-song-breaks-youtube-record">Continue reading...</a>

## Digested week: Harry’s book reminds me of my first years in therapy | John Crace
 - [https://www.theguardian.com/uk-news/2023/jan/13/digested-week-harrys-book-reminds-me-of-my-therapy](https://www.theguardian.com/uk-news/2023/jan/13/digested-week-harrys-book-reminds-me-of-my-therapy)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:31:15+00:00
 - user: None

<p>2023 starts with trusty life hacks: hope in Spurs must fade and Wagnerian fever dreams featuring Dominic Raab will pass</p><p>The first full week back at work. My least favourite time of year. Everything just feels that bit more difficult and my anxiety is intensified. More bad news. Another old friend has killed himself, while another is seriously ill. My dreams are increasingly disturbed. Here’s just two from the last few days. In one, I was in the middle of an apocalypse where everyone had been infected with a virus which gave them less than 24 hours to live. People were turning to skeletons in front of my eyes. And the skeletons were turning to dust. In another, I was off to see a performance of a Wagner opera directed by Dominic Raab. I’m not sure which was more of a nightmare. My traditional life hack of counting the days past the winter solstice provides some relief. The reassurance that the days are getting longer even if barely noticeably so. There’s also comfort to be found in the return of familiar TV dramas. Much has been written about Happy Valley, but I’d like to give a shout out to Silent Witness. It’s now into its 26th series and I’ve watched every one. It’s also got more and more reliably absurd. So much so that it’s almost a comedy. Even when it’s over I’ve got little idea of what’s going on. Last week’s made no sense at all. It started with the Italian mafia, moved on to a children’s home and ended with Jack being captured and miraculously released by the head of the police who was also in the mafia. <a href="https://www.theguardian.com/lifeandstyle/2023/jan/01/sunday-with-emilia-fox-rowing-on-the-thames-with-my-daughter-and-the-dogs">Emilia Fox</a> skates through the two hours with just one expression. Total bewilderment. She’s bewildered when she does an autopsy. She’s bewildered when she is being attacked. And she’s bewildered when she falls in love. I’m not sure if that’s Emilia acting or whether she can’t follow the scripts either. It’s rumoured this is the last ever series. I’ll miss it when it’s gone.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/digested-week-harrys-book-reminds-me-of-my-therapy">Continue reading...</a>

## Manchester City footballer Benjamin Mendy cleared of rape charges
 - [https://www.theguardian.com/uk-news/2023/jan/13/manchester-city-footballer-benjamin-mendy-cleared-of-rape-charges](https://www.theguardian.com/uk-news/2023/jan/13/manchester-city-footballer-benjamin-mendy-cleared-of-rape-charges)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:30:16+00:00
 - user: None

<p>Ex-French international was accused of assaulting women at his Cheshire mansion between 2018 and 2021</p><p>The Manchester City footballer Benjamin Mendy has been found not guilty of raping four women and sexually assaulting another during lockdown parties at his Cheshire mansion.</p><p>The former French international slumped with his head in his hands as he was unanimously cleared of six counts of rape and one sexual assault following a five-month trial at Chester crown court.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/manchester-city-footballer-benjamin-mendy-cleared-of-rape-charges">Continue reading...</a>

## Abbas allies fear new Israeli government intends to destroy Palestinian Authority
 - [https://www.theguardian.com/world/2023/jan/13/mahmoud-abbas-allies-fear-israel-government-destroy-palestinian-authority](https://www.theguardian.com/world/2023/jan/13/mahmoud-abbas-allies-fear-israel-government-destroy-palestinian-authority)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:18:29+00:00
 - user: None

<p>Minister says ultranationalists in coalition want to dismantle body and create ‘new reality in the West Bank’</p><p>Senior allies of the Palestinian president, Mahmoud Abbas, have expressed fears that Benjamin Netanyahu’s new ultranationalist coalition in Israel will seek to dismantle the Palestinian Authority (PA), established after the 1993 Oslo peace accords.</p><p>The Palestinian social Development minister, Ahmad Majdalani, said members of the government intend to destroy the authority, which administers a degree of self rule in parts of the West Bank and is considered by Abbas as the institutional building block for a future Palestinian state.</p> <a href="https://www.theguardian.com/world/2023/jan/13/mahmoud-abbas-allies-fear-israel-government-destroy-palestinian-authority">Continue reading...</a>

## ‘The monarchy’s a laughing stock’: readers react to Prince Harry’s Spare
 - [https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-readers-react](https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-readers-react)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:09:22+00:00
 - user: None

<p>Views range from sympathy for the Sussexes in light of treatment by royals and tabloids, to regarding them as being ‘as entitled as the others’</p><p>Prince Harry’s tell-all autobiography has become the UK’s <a href="https://www.theguardian.com/uk-news/2023/jan/10/prince-harrys-autobiography-spare-is-fastest-selling-non-fiction-book">fastest-selling nonfiction</a> book ever.</p><p>The memoir has been controversial, including claims <a href="https://www.theguardian.com/uk-news/2023/jan/06/prince-harry-saw-red-mist-in-william-during-alleged-attack">that Prince William physically attacked him</a> and accusing his father of putting his own interests first.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-readers-react">Continue reading...</a>

## Bachman–Turner Overdrive drummer Robbie Bachman dies aged 69
 - [https://www.theguardian.com/music/2023/jan/13/bachman-turner-overdrive-drummer-robbie-bachman-dies-aged-69](https://www.theguardian.com/music/2023/jan/13/bachman-turner-overdrive-drummer-robbie-bachman-dies-aged-69)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:08:44+00:00
 - user: None

<p>Musician played with brother Randy in a band that reached peak in the 70s, with several albums and hit single Roll on Down the Highway</p><p>Robbie Bachman, the drummer for Bachman–Turner Overdrive and Brave Belt, has died age 69. His brother and bandmate Randy Bachman <a href="https://twitter.com/RandysVinylTap/status/1613693347125923842?s=20&amp;t=c3lljD7TEzqW6q15LXgwgQ">confirmed the news on Twitter</a>, describing Robbie as “an integral cog in our rock’n’roll machine” and writing that “the pounding beat behind BTO … has joined mum, dad and brother Gary on the other side”. No cause of death was given.</p><p>Robin Bachman was born in Winnipeg, Canada, in 1953. He and his brother began playing music in their youth, and Robbie played in a handful of bands in Winnipeg before Randy invited him to drum for Brave Belt, his new band with Chad Allan, with whom he had played in the celebrated Winnipeg rock band the Guess Who. Brave Belt recorded two albums, released in 1971 and 1972, before changing their name to Bachman–Turner Overdrive in 1973 after Allan’s departure.</p> <a href="https://www.theguardian.com/music/2023/jan/13/bachman-turner-overdrive-drummer-robbie-bachman-dies-aged-69">Continue reading...</a>

## Christ Tshiunza: ‘Sport doesn’t have a language. It helped me connect with people’
 - [https://www.theguardian.com/sport/2023/jan/13/christ-tshiunza-rugby-union-exeter-wales-interview](https://www.theguardian.com/sport/2023/jan/13/christ-tshiunza-rugby-union-exeter-wales-interview)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:04:08+00:00
 - user: None

<p>The Exeter and Wales lock played rugby to make friends after his family fled DR Congo – now he is targeting a World Cup place</p><p>Up on Christ Tshiunza’s bedroom wall, discreetly hidden away from prying eyes, is a list. One of the best prospects in world rugby has always written down his long-term goals but what separates him from his peers is how many he has already ticked off. “It brings me great joy that I’ve achieved everything I’ve wanted to achieve so far,” he murmurs. “Not a lot of people my age can say that.”</p><p>A full cap for Wales while still in his teens, a professional contract with one of England’s premier clubs and – his final exams at Exeter University permitting – a degree in sports science would be an impressive haul on its own. None of it, though, is remotely as uplifting as his remarkable journey to this point, an odyssey to give soaring hope to anyone growing up beyond rugby’s traditional margins.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/christ-tshiunza-rugby-union-exeter-wales-interview">Continue reading...</a>

## Scary monsters: how virtual reality could help people cope with anxiety
 - [https://www.theguardian.com/technology/2023/jan/13/monsters-virtual-reality-anxiety-treatment-video-game-breathing-techniques](https://www.theguardian.com/technology/2023/jan/13/monsters-virtual-reality-anxiety-treatment-video-game-breathing-techniques)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:00:15+00:00
 - user: None

<p>Guardian science correspondent is put to the test in the panic-inducing VR world of a game that teaches breathing technique</p><p>Tethered to a chair, in a gloomy basement, I’m doing my best not to panic – by breathing in for four seconds, holding for seven, and slowly releasing for eight. But when a bloodthirsty monster appears at my feet and starts crawling towards me, I don’t need a dial to tell me that my heart is pounding, and I’m in imminent mortal danger.</p><p>Welcome to the future of anxiety treatment: a virtual reality (VR) game that teaches you a breathing technique to help calm your nerves, and then pits you against a monstrous humanoid that wants to eat you, to practise deploying it in genuinely panic-inducing situations.</p> <a href="https://www.theguardian.com/technology/2023/jan/13/monsters-virtual-reality-anxiety-treatment-video-game-breathing-techniques">Continue reading...</a>

## Beuys’ dreams, bejewelled paintings and Avatar for art lovers – the week in art
 - [https://www.theguardian.com/artanddesign/2023/jan/13/beuys-dreams-bejewelled-paintings-and-avatar-for-art-lovers-the-week-in-art](https://www.theguardian.com/artanddesign/2023/jan/13/beuys-dreams-bejewelled-paintings-and-avatar-for-art-lovers-the-week-in-art)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:00:14+00:00
 - user: None

<p>The watercolours behind Beuys’ sculptures are revealed, Soheila Sokhanvari commemorates Iran’s feminist icons and Sahej Rahal creates a digital world – <a href="https://www.theguardian.com/artanddesign/2015/oct/19/sign-up-to-the-art-weekly-email">all in your weekly dispatch</a></p><p><strong>Joseph Beuys</strong><strong>: 40 Years of Drawing<br /></strong>Drawings and watercolours that reveal the myths and dreams behind this great artist’s sculptures.<br />• <a href="https://ropac.net/exhibitions/652-joseph-beuys-40-years-of-drawing/">Thaddaeus Ropac, London</a>, from 19 January to 22 March.</p> <a href="https://www.theguardian.com/artanddesign/2023/jan/13/beuys-dreams-bejewelled-paintings-and-avatar-for-art-lovers-the-week-in-art">Continue reading...</a>

## When Arsenal beat Tottenham at White Hart Lane ‘with six reserves’
 - [https://www.theguardian.com/football/that-1980s-sports-blog/2023/jan/13/arsenal-tottenham-white-hart-lane-six-reserves-spurs-derby-](https://www.theguardian.com/football/that-1980s-sports-blog/2023/jan/13/arsenal-tottenham-white-hart-lane-six-reserves-spurs-derby-)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 12:00:14+00:00
 - user: None

<p>Faced with five games in 11 days, Arsenal asked Spurs to move the derby. Spurs refused – and Arsenal beat them anyway</p><p>By <a href="https://twitter.com/1980ssportsblog">Steven Pye</a> for <a href="https://www.theguardian.com/sport/that-1980s-sports-blog">That 1980s Sports Blog</a></p><p>Squad rotation is now a common feature of top-flight football but it wasn’t always this way. There are various tales from the distant past of marathon seasons, where tiny squads racked up game after game, many of them cup replays, as players were worn down and exhausted by the quantity of matches. Arsenal’s season in 1979-80 is a prime example. Their small squad played 70 matches, taking in the Charity Shield, First Division, League Cup, FA Cup and Cup Winners’ Cup. The schedule was relentless.</p><p>Terry Neill and his players contested 10 matches in April alone as their quest for domestic and European glory took on a slightly masochistic flavour. Beating Liverpool and Juventus in cup semi-finals was hard enough but, to add an extra challenge, Arsenal were also trying to finish in the top three to qualify for the Uefa Cup.</p> <a href="https://www.theguardian.com/football/that-1980s-sports-blog/2023/jan/13/arsenal-tottenham-white-hart-lane-six-reserves-spurs-derby-">Continue reading...</a>

## The Guide #69: Why the abrupt end of Netflix’s 1899 could be a bad omen
 - [https://www.theguardian.com/culture/2023/jan/13/the-guide-1899-netflix](https://www.theguardian.com/culture/2023/jan/13/the-guide-1899-netflix)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:56:48+00:00
 - user: None

<p>In this week’s newsletter: The maritime mystery seemed to have everything it takes to be a hit – so what does it say that the show was thrown overboard so soon?</p><ul><li><strong><a href="https://ablink.email.theguardian.com/ss/c/TBl-lE0k4WbTlFRn6v-lQXxTpTslqnvUsR2ofAkC00vqkHXqakTSxrykj9mrdACFM7X02zB_4eaUcPGwGF8aSd8qfug3UI-6On7SZ6NCb1bc8x_o5dndnbkzvJa5hUkQ9nhvD7IJSuyXeKbacJDYEqlFbAZ0vOIKsv3NFHydfPIzaUpYyjP0KfOAhLRYMW2yTAs6TBIgM3bi7aVl__6M8OuHfLZfd7xmigDS_KOnKuU_bc0LD-KQTnN7wlkHVqzvlJ18crhTOgngZzAlM4_3_SCUmWonlgL50tNfCaUIQQk/3hx/2l-ct5r6Q8CNEhlq1hSBIw/h15/kSGp0pNCsCxOwXsdDM-fI8ISkKBb6hYjBXPF16gxdC8">Don’t get the Guide delivered to your inbox? Sign up to get the full article here</a></strong></li></ul><p>When the news broke at the start of month that Netflix had cancelled <a href="https://www.netflix.com/title/80214497">1899</a>, their genre-juggling supernatural horror series, after one seemingly well-received series, it sent a shudder through the streaming industry. Shows get axed all the time in Hollywood, but 1899 seemed pretty cancel-proof. After all, its creators, Jantje Friese and Baran bo Odar, were also behind Dark, the German sci-fi show that helped birth the idea of Netflix as an international hit factory. Produced by Friese and Odar’s Netflix-backed Dark Ways studio, 1899, it was hoped, would be a model for how planet-conquering series would get made: amassing a global cast on a <a href="https://www.youtube.com/watch?v=ZMynJCgJIQk">revolutionary virtual production stage</a>, and slotting it into a moreish puzzle-box mystery series.</p><p>Initial signs were good: a number two placing among Netflix’s English language titles in its first three weeks, and talk of a further two series mapped out by its creators. Then, suddenly, the chop came – both a bizarrely rash decision and a fitting coda. In 2022, it felt like years of rampant speculation, growth and churned-outcontent had come back to bite the industry. Here are a few of the worrying signs of a streaming universe dangerously in flux.</p> <a href="https://www.theguardian.com/culture/2023/jan/13/the-guide-1899-netflix">Continue reading...</a>

## Man pleads guilty to throwing egg at King Charles in Luton
 - [https://www.theguardian.com/uk-news/2023/jan/13/man-pleads-guilty-to-throwing-egg-at-king-charles-luton-visit-bad-taste](https://www.theguardian.com/uk-news/2023/jan/13/man-pleads-guilty-to-throwing-egg-at-king-charles-luton-visit-bad-taste)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:53:15+00:00
 - user: None

<p>Harry May, 21, threw object because he believed monarch’s visit to ‘poor area’ was in ‘bad taste’, court hears</p><p>A 21-year-old man has admitted throwing an egg towards King Charles during a walkabout in Luton because he thought the monarch’s visit to a “poor area” was in “bad taste”.</p><p>Harry May pleaded guilty at Westminster magistrates court in London on Friday to a public order offence relating to the incident on 6 December.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/man-pleads-guilty-to-throwing-egg-at-king-charles-luton-visit-bad-taste">Continue reading...</a>

## UK to further delay calling Northern Ireland election as Brexit talks continue
 - [https://www.theguardian.com/uk-news/2023/jan/13/uk-to-further-delay-calling-northern-ireland-election-as-brexit-talks-continue](https://www.theguardian.com/uk-news/2023/jan/13/uk-to-further-delay-calling-northern-ireland-election-as-brexit-talks-continue)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:29:28+00:00
 - user: None

<p>EU sources say progress in protocol dispute is slow despite growing momentum</p><p>The UK government is to further delay calling an election in Northern Ireland to give Brexit talks a chance.</p><p>Senior EU sources said “slow progress” was being made in talks between the UK and Brussels, dampening hopes of a breakthrough by the end of January on the protracted dispute over the Northern Ireland protocol.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/uk-to-further-delay-calling-northern-ireland-election-as-brexit-talks-continue">Continue reading...</a>

## Ant-Man and the Wasp: can Marvel’s tiniest heroes carry the whole franchise?
 - [https://www.theguardian.com/film/2023/jan/13/ant-man-and-the-wasp-quantumania-marvel-mcu-tiniest-heroes](https://www.theguardian.com/film/2023/jan/13/ant-man-and-the-wasp-quantumania-marvel-mcu-tiniest-heroes)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:24:25+00:00
 - user: None

<p>The trailer for the new Ant-Man film, Quantumania, puts Paul Rudd at the heart of the new-look MCU. But does this vision have legs?</p><p>It was pretty obvious to every superhero fan that Robert Downey Jr’s Iron Man, until his sad demise, sat at the centre of the Marvel Cinematic Universe. Who brought Ultron into existence? Yes, the billionaire philanthropist with the zippy one-liners. Who invented time travel in order to defeat Thanos? That guy who loved shawarma, weapons of mass destruction and casual sexism (at least <a href="https://www.theguardian.com/film/2021/jun/17/stark-contrast-a-decade-of-gender-politics-in-the-marvel-universe">in his early outings</a>).</p><p>Since Tony Stark’s death in <a href="https://www.theguardian.com/film/2019/apr/23/avengers-endgame-review-unconquerable-brilliance-takes-marvel-to-new-heights">Avengers: Endgame</a>, the MCU has been crying out for a focal point. Doctor Strange looked like he might step up, but soon lost his position as sorcerer supreme to Wong and almost destroyed the entire universe while <a href="https://www.theguardian.com/film/2021/dec/14/spider-man-no-way-home-review-scattered-fun-in-ambitious-sequel">trying to help out Peter Parker</a>. Thor still isn’t quite his old self after gaining a beer gut and attempting a journey of self-discovery, while Brie Larson’s Captain Marvel has been largely awol since Endgame.</p> <a href="https://www.theguardian.com/film/2023/jan/13/ant-man-and-the-wasp-quantumania-marvel-mcu-tiniest-heroes">Continue reading...</a>

## The anti-abortion movement just had a mask-off moment in Alabama | Moira Donegan
 - [https://www.theguardian.com/commentisfree/2023/jan/13/alabama-attorney-general-anti-abortion-movement](https://www.theguardian.com/commentisfree/2023/jan/13/alabama-attorney-general-anti-abortion-movement)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:23:13+00:00
 - user: None

<p>In Alabama, pregnant women are subjected to a work around law in the name of protecting the fetus: chemical endangerment of a child</p><p>This week, Steve Marshall, Alabama’s Republican attorney general said he sees a path to prosecuting women for having abortions in his state. This was a bit of a faux pas: a moment of letting slip the mask that the anti-abortion movement always tries to keep on.</p><p>Alabama’s total abortion ban, which has only limited exemptions for women’s lives, makes providing an abortion a felony, punishable by up to <a href="https://www.fiercehealthcare.com/practices/doctors-could-face-life-prison-under-new-alabama-abortion-law#:~:text=Republican%20Gov.,a%2010%2Dyear%20prison%20term.">99 years in prison</a>. But like nearly all of the abortion bans that have sprung into effect since the US supreme court’s ruling in Dobbs v Jackson Women’s Health overturned Roe v Wade last June, the law has no mechanism to prosecute women who receive abortions. But that doesn’t mean that patients are safe from criminal charges, according to the state’s top prosecutor.</p><p>Moira Donegan is a Guardian US columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/alabama-attorney-general-anti-abortion-movement">Continue reading...</a>

## ‘World’s longest river cruise’ could threaten endangered Ganges dolphin, experts warn
 - [https://www.theguardian.com/environment/2023/jan/13/india-worlds-longest-river-cruise-endangered-ganges-dolphin-aoe](https://www.theguardian.com/environment/2023/jan/13/india-worlds-longest-river-cruise-endangered-ganges-dolphin-aoe)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:20:03+00:00
 - user: None

<p>A luxury cruise has been hailed as the start of a new age of Indian tourism. But conservationists fear the impact of increased river traffic and pollution </p><p>The Indian prime minister, Narendra Modi, has officially launched the “world’s longest river cruise” from the city of Varanasi in Uttar Pradesh. The luxury voyage will last 51 days, travelling 3,200km via Dhaka in Bangladesh to Dibrugarh in Assam, crossing 27 river systems.</p><p>The three-deck MV Ganga Vilas, with 18 suites, is the latest venture in a trend for cruise tourism in India being promoted by the government. Modi hailed the cruise industry on the Ganges as a “landmark moment”, which will herald a new age of tourism in India.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/india-worlds-longest-river-cruise-endangered-ganges-dolphin-aoe">Continue reading...</a>

## Why hasn’t Harry given up his ridiculous title yet? | Arwa Mahdawi
 - [https://www.theguardian.com/uk-news/commentisfree/2023/jan/13/prince-harry-title-duke-duchess-sussex-spare](https://www.theguardian.com/uk-news/commentisfree/2023/jan/13/prince-harry-title-duke-duchess-sussex-spare)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:15:13+00:00
 - user: None

<p>I don’t think anyone should be going around calling themselves Duke or Duchess in 2023. Unless they are a stripper or a dog</p><p>I’m afraid it’s the law now, OK? I’ve valiantly resisted for as long as I could, but the time has come: I simply have to write about Harry and Meghan. It is basically illegal not to have at least one opinion about the royals who apparently hate being royals but are still milking their royal connections for all they’re worth. And don’t roll your eyes, you’re a glutton for this stuff too. Everyone loves to see obscenely privileged people airing their dirty laundry. There is a reason that Harry’s memoir has become the <a href="https://www.thedailybeast.com/prince-harrys-memoir-spare-becomes-uks-fastest-selling-nonfiction-book">UK’s fastest-selling nonfiction book</a> and that reason is not the quality of the writing.</p><p>Don’t worry I’m not going to pull a Piers Morgan or Jeremy Clarkson here and start seething with unhinged rage about Harry and Meghan. I’m not the Sussexes biggest fan but the only royal I can muster up enough energy to get really outraged about is Prince Andrew. You remember him? He hasn’t been in the news very much lately since Harry’s been hogging all the headlines but he’s the guy that got stripped of royal duties over his <a href="https://www.theguardian.com/us-news/2022/sep/15/jeffrey-epstein-prince-andrew-queen-death">relationship with the convicted sex offender Jeffrey Epstein</a>. He’s the guy that Ghislaine Maxwell recently called her “<a href="https://www.theguardian.com/us-news/2022/oct/16/ghislaine-maxwell-says-she-feels-bad-for-dear-friend-prince-andrew">dear friend</a>.” He’s a nasty piece of work and yet Britain is now so caught up in Harry hatred that a recent YouGov poll has found that Brits over the age of 65 dislike the Sussexes <a href="https://news.yahoo.com/harry-and-meghan-less-popular-than-prince-andrew-among-older-britons-new-poll-reveals-111438277.html">more than disgraced Prince Andrew</a>.</p><p>Arwa Mahdawi is a Guardian columnist and the author of Strong Female Lead</p> <a href="https://www.theguardian.com/uk-news/commentisfree/2023/jan/13/prince-harry-title-duke-duchess-sussex-spare">Continue reading...</a>

## China to take ‘golden shares’ in tech firms Alibaba and Tencent
 - [https://www.theguardian.com/world/2023/jan/13/china-to-take-golden-shares-in-tech-firms-alibaba-and-tencent](https://www.theguardian.com/world/2023/jan/13/china-to-take-golden-shares-in-tech-firms-alibaba-and-tencent)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:09:07+00:00
 - user: None

<p>Move marks shift in focus by Beijing as it tries to extend influence and keep sector in check</p><p>China is to take “golden shares” in two of its biggest tech companies, Alibaba and Tencent, as Beijing extends its influence on the country’s star tech firms and its <a href="https://www.theguardian.com/business/2020/nov/04/jack-ma-ant-group-is-tamed-social-media-reacts-after-china-blocks-ipo">most powerful and wealthy business people</a>.</p><p> Beijing’s move marks a shift away from imposing hefty fines and sanctions in its two-year tech crackdown, which was launched after Alibaba founder, Jack Ma, <a href="https://www.theguardian.com/business/2020/nov/04/jack-ma-ant-group-is-tamed-social-media-reacts-after-china-blocks-ipo">criticised regulators</a>,</p> <a href="https://www.theguardian.com/world/2023/jan/13/china-to-take-golden-shares-in-tech-firms-alibaba-and-tencent">Continue reading...</a>

## ‘Sometimes it warms up to -5C’: tips on keeping the cold out from an Antarctic scientist, Scandi oyster diver and more
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-dress-for-the-cold-by-the-people-who-really-know](https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-dress-for-the-cold-by-the-people-who-really-know)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:00:14+00:00
 - user: None

<p>Merino wool socks, lip balm and hand warmers … Four pros on how to dress for the cold – and how to warm up afterwards</p><p><strong>Lotta Klemming, diver at Klemmings Ostron, Grebbestad, Sweden</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-dress-for-the-cold-by-the-people-who-really-know">Continue reading...</a>

## Coastal residents fear ‘hideous’ seawalls will block waterfront views
 - [https://www.theguardian.com/us-news/2023/jan/13/us-cities-ugly-seawalls-climate-crisis-miami](https://www.theguardian.com/us-news/2023/jan/13/us-cities-ugly-seawalls-climate-crisis-miami)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:00:13+00:00
 - user: None

<p>Aesthetics and social inequity are cause for concern as locals grapple with proposals to protect cities from climate change</p><p>There were more than a few issues with a recent federal plan to wall Miami off from the dangers of climate change.</p><p>The $5bn proposal involved building a massive concrete seawall in <a href="https://news.miami.edu/as/stories/2022/06/fragile-ecosystems.html">the fragile marine ecosystem</a> of Biscayne Bay. It included using taxpayer money <a href="https://www.nytimes.com/2021/06/02/us/miami-fl-seawall-hurricanes.html">to elevate</a> private waterfront mansions, while <a href="https://www.biscaynetimes.com/news/residents-fight-floodwalls-proposed-by-army-corps-of-enginee/">constructing a wall through</a> the middle of downtown and sometimes low-income neighborhoods.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/us-cities-ugly-seawalls-climate-crisis-miami">Continue reading...</a>

## ‘It’s just so intense and awkward’: the death of the dinner date
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/its-just-so-intense-and-awkward-the-death-of-the-dinner-date](https://www.theguardian.com/lifeandstyle/2023/jan/13/its-just-so-intense-and-awkward-the-death-of-the-dinner-date)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 11:00:13+00:00
 - user: None

<p>Whether for reasons of cost, changed gender roles or the desire for privacy, eating out is no longer such a big part of finding love</p><p>It is an unusual option for a January date, but after meeting twice, 42-year-old Sasha thinks she is ready to take things to the next level with the man she has just started seeing. She is planning to take him for a sea swim near her home in East Sussex, followed by a beachside sauna. “I’m just putting it out there: here’s my body. It’s not the body I had when I was 20 but it is what it is.”</p><p>They have chatted a lot, first online and then in person, but have never been out to dinner together. “Oh no, I would never go out for dinner with anyone. It’s just so intense and awkward. If someone asked me out for dinner or the cinema, I know they’re not for me.” Asking someone to dinner is “unimaginative and boring”, says Sasha (not her real name). “I just think: snore alert.”</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/its-just-so-intense-and-awkward-the-death-of-the-dinner-date">Continue reading...</a>

## ‘We have to rethink the industry’: Danish restaurant Noma makes way for food lab
 - [https://www.theguardian.com/food/2023/jan/13/danish-restaurant-noma-makes-way-for-food-lab](https://www.theguardian.com/food/2023/jan/13/danish-restaurant-noma-makes-way-for-food-lab)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:57:03+00:00
 - user: None

<p>Michelin-starred eatery will be replaced by a ‘pioneering test kitchen and lab dedicated to groundbreaking work in food’</p><p>If what tickles your tastebuds for supper is duck brain served in the skull, edible pine cones, sweetbreads in reindeer moss and dried plum and pheasant heart followed by a berry-leather and black-garlic beetle, you’d better get a move on.</p><p>Noma, the fine-dining restaurant in Copenhagen on whose winter “game and forest” menu (it also does vegetable and seafood seasons) those delicacies feature, is <a href="https://www.theguardian.com/food/2023/jan/09/noma-restaurant-to-close-temporarily-at-the-end-of-2024">closing at the end of next year</a>, and the waiting list is very long.</p> <a href="https://www.theguardian.com/food/2023/jan/13/danish-restaurant-noma-makes-way-for-food-lab">Continue reading...</a>

## Famous fans say farewell to the B-52’s: ‘They got me to question my own prejudices’
 - [https://www.theguardian.com/music/2023/jan/13/famous-fans-say-farewell-to-the-b-52s-they-got-me-to-question-my-own-prejudices](https://www.theguardian.com/music/2023/jan/13/famous-fans-say-farewell-to-the-b-52s-they-got-me-to-question-my-own-prejudices)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:56:27+00:00
 - user: None

<p>After 46 years, the Athens originals are taking off for good later this year. David Byrne, Boy George and more pay tribute to one of the most unusual pop bands ever</p><p>What other band has three great lead singers? Nobody can do what Fred Schneider does. And Cindy [Wilson] and Kate [Pierson] – I remember listening to Give Me Back My Man, and the quality of their voices was so strong and so powerful. And also to be able to be so funny – their music is so joyous and interesting, and such a celebration of independent thinking.</p> <a href="https://www.theguardian.com/music/2023/jan/13/famous-fans-say-farewell-to-the-b-52s-they-got-me-to-question-my-own-prejudices">Continue reading...</a>

## Premier League: Chelsea fallout, team news and buildup to derby weekend – live
 - [https://www.theguardian.com/football/live/2023/jan/13/premier-league-chelsea-fallout-team-news-and-buildup-to-derby-weekend-live](https://www.theguardian.com/football/live/2023/jan/13/premier-league-chelsea-fallout-team-news-and-buildup-to-derby-weekend-live)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:51:53+00:00
 - user: None

<ul><li>Manchester and North London derbies this weekend</li><li><a href="https://www.theguardian.com/football/2023/jan/13/premier-league-10-things-to-look-out-for-this-weekend">Premier League: ten things to look out for</a></li><li>Any comments? You can <a href="mailto:david.tindall.casual@theguardian.com">email Dave</a> or <a href="https://twitter.com/DaveTindallgolf">tweet him</a></li></ul><p><strong>Debuts that went bad</strong>. If the BBC don’t do it, Sky will. Adding to Jonathan Woodgate’s calamitous first start for Real Madrid and Joe Cole’s red card on his Premier League debut for Liverpool is João Félix’s sending off on his Chelsea bow last night. Jonathan. Joe. João. It’s ‘The Curse Of The J’. Or something. One for <a href="https://www.theguardian.com/football/series/theknowledge">The Knowledge</a> probably. Can anyone think of others who saw red on debut? Extra marks if they were called Juan, Jim or Jeffrey.</p><p><strong>If you were out last night</strong> or perhaps watching the snooker, I’ll rustle my newspaper, take a slurp of tea and inform you that “Chelsea lost again”. Jacob Steinburg was at Craven Cottage to see Graham Potter pulling all sorts of strange faces.</p> <a href="https://www.theguardian.com/football/live/2023/jan/13/premier-league-chelsea-fallout-team-news-and-buildup-to-derby-weekend-live">Continue reading...</a>

## Chinese flock to Hong Kong to get private Covid booster shots
 - [https://www.theguardian.com/world/2023/jan/13/chinese-flock-to-hong-kong-to-get-private-covid-booster-shots-mrna-vaccine](https://www.theguardian.com/world/2023/jan/13/chinese-flock-to-hong-kong-to-get-private-covid-booster-shots-mrna-vaccine)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:36:39+00:00
 - user: None

<p>Travel packages advertised as interest surges  in mRNA vaccines unavailable on mainland</p><p>Private services offering Chinese travellers access to mRNA vaccines are attracting droves of mainlanders to Hong Kong and Macau seeking a booster shot that their government has refused to approve.</p><p>As part of its <a href="https://www.theguardian.com/world/2022/dec/09/excitement-and-apprehension-as-china-loosens-zero-covid-measures">dismantling of the country’s zero-Covid policy last month</a>, China’s government also lifted quarantine and other border restrictions. It prompted a wave of interest in overseas travel, particularly for the upcoming <a href="https://www.theguardian.com/world/2023/jan/06/anxious-lunar-new-year-in-china-as-millions-travel-while-covid-spreads">lunar new year holiday</a> later this month. However, there also appears to be a large contingent chasing the mRNA bivalent vaccines.</p> <a href="https://www.theguardian.com/world/2023/jan/13/chinese-flock-to-hong-kong-to-get-private-covid-booster-shots-mrna-vaccine">Continue reading...</a>

## ‘It was a massacre’: fury and grief amid Peru’s worst political violence in years
 - [https://www.theguardian.com/world/2023/jan/13/peru-protests-political-unrest-deaths](https://www.theguardian.com/world/2023/jan/13/peru-protests-political-unrest-deaths)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:30:12+00:00
 - user: None

<p>Country reeling as police unleash deadly violence on Pedro Castillo’s supporters, ramping up anger and inciting more protests and blockades</p><p>Lisbeth Candia wept uncontrollably as she waited in Cusco’s central morgue to recover the body of her brother Remo, the latest protester to be killed by Peruvian security forces as the country experiences its worst political violence in decades.</p><p>“Let there be no more deaths, let his be the last,” she said between sobs. “We don’t want his death to have been in vain,” she told the Guardian by phone.</p> <a href="https://www.theguardian.com/world/2023/jan/13/peru-protests-political-unrest-deaths">Continue reading...</a>

## Weather tracker: record rain for California, -62C in Siberia
 - [https://www.theguardian.com/environment/2023/jan/13/weather-tracker-record-rain-for-california-siberia](https://www.theguardian.com/environment/2023/jan/13/weather-tracker-record-rain-for-california-siberia)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:10:15+00:00
 - user: None

<p>It’s been very wet in San Francisco and parts of New Zealand, while extreme cold has swept across Russia</p><p>Over the past couple of weeks, California has seen the effects of a persistent atmospheric river bringing in constant spells of rain from the Pacific across the state. The National Oceanic and Atmospheric Administration (NOAA) and National Weather Service (NWS) have released rainfall totals for some areas of California over the course of 16 days from 26 December 2022 through to 11 January 2023. Over the 16-day period downtown San Francisco received 345mm and in nearby Oakland totals reached 327.7mm, breaking their 16-day rainfall record. The significance of the flooding is only increased by having had extremely dry soils through the summer and autumn with severe droughts, therefore preventing soils from easily soaking up the intense rainfall that has occurred over recent weeks.</p><p>Tropical Cyclone Hale affected the North Island of New Zealand on 9-12 January. Severe thunderstorms brought 156.5mm to Hikuwai in Gisborne in the space of 12 hours, and more than 100mm to other places around Gisborne in the same period. Over the course of 18 hours, 219mm was recorded at Pinnacles in the Coromandel ranges and in Whitianga aerodrome on 10 January, making it the fifth wettest January day on record.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/weather-tracker-record-rain-for-california-siberia">Continue reading...</a>

## Experience: I am the tallest woman in the world
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/tallest-woman-in-the-world-rumeysa-gelgi](https://www.theguardian.com/lifeandstyle/2023/jan/13/tallest-woman-in-the-world-rumeysa-gelgi)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:00:12+00:00
 - user: None

<p>My rare genetic condition makes travel tough, but last year I took a plane for the first time – lying horizontally</p><p>Since I was a little girl growing up in Safranbolu, Turkey, I’ve dreamed of exploring the world – from the sandy beaches of California to the northern lights in Iceland. Until a couple of years ago, I couldn’t have even imagined this happening, but a few months ago my dreams finally became a reality.</p><p>I’m more than 7ft (2.15 metres) tall, so travelling is difficult for me. I am the tallest woman in the world, due to a rare genetic condition called Weaver syndrome, which affects only 50 people.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/tallest-woman-in-the-world-rumeysa-gelgi">Continue reading...</a>

## Rightwing group pours millions in ‘dark money’ into US voter suppression bid
 - [https://www.theguardian.com/us-news/2023/jan/13/heritage-foundation-voter-suppression-lobbying-election-action-plan](https://www.theguardian.com/us-news/2023/jan/13/heritage-foundation-voter-suppression-lobbying-election-action-plan)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:00:12+00:00
 - user: None

<p>Tax filings reveal advocacy arm of Heritage Foundation spent $5m on lobbying in 2021 to block voting rights in battleground states</p><p>The advocacy arm of the Heritage Foundation, the powerful conservative thinktank based in Washington, spent more than $5m on lobbying in 2021 as it worked to block federal voting rights legislation and advance an ambitious plan to spread its far-right agenda calling for aggressive voter suppression measures in battleground states.</p><p>Previously unreported 2021 tax filings from Heritage Action for America, which operates as the foundation’s activist wing, shows that it spent $5.1m on contracting outside lobbying services. The outlay comes on top of $560,000 the group invested in its own <a href="https://www.documentcloud.org/documents/23562750-ha-2021-lobbying-records">in-house federal lobbying efforts</a> that year, as well as registered lobbying by Heritage Action staffers in at least 24 states.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/heritage-foundation-voter-suppression-lobbying-election-action-plan">Continue reading...</a>

## Voters know that Brexit was a mistake, so when will our politicians admit it? | Simon Jenkins
 - [https://www.theguardian.com/commentisfree/2023/jan/13/brexit-mistake-northern-ireland-protocol](https://www.theguardian.com/commentisfree/2023/jan/13/brexit-mistake-northern-ireland-protocol)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:00:12+00:00
 - user: None

<p>A glimmer of hope over the Northern Ireland protocol shows what can happen if we stop being embarrassed by the B-word</p><p>Brexit has become the banned word of British politics. Rishi Sunak never breathes it. Say it to Keir Starmer and he affects not to hear. Brexit is axed, cancelled, forbidden, dismissed as boring. Not just that, but YouGov reports that <a href="https://yougov.co.uk/topics/politics/articles-reports/2022/11/17/one-five-who-voted-brexit-now-think-it-was-wrong-d">56%</a> of the public regrets the country ever having voted for it, with just <a href="https://yougov.co.uk/topics/politics/articles-reports/2022/11/17/one-five-who-voted-brexit-now-think-it-was-wrong-d#:~:text=with%20only%2032%25%20of%20the%20British%20public%20saying%20it%20was%20right%20to%20vote%20to%20leave">32%</a> still in favour. Brexit, the great self-harm, has become the Great Mistake.</p><p>Britain is the only major world economy that has failed to return to its pre-Covid growth performance. <a href="https://www.ft.com/content/d6b84faf-f556-4fdd-ac27-65c2d514aa2f">Economists</a> regard Brexit as a prime cause. The Office for Budget Responsibility reports that the negative impact of Brexit has been double that of Covid, <a href="https://www.theguardian.com/politics/2021/oct/28/brexit-worse-for-the-uk-economy-than-covid-pandemic-obr-says#:~:text=reduce%20our%20long%20run%20GDP%20by%20around%204%25">reducing GDP in the long-term</a> by a full 4%. Not a day passes without farmers, fishers, manufacturers, care providers, academics or artists complaining of impeded trade and crippled labour supply. Brexit has added <a href="https://www.economist.com/britain/2022/06/23/the-case-for-a-softer-brexit-is-clear-how-to-get-one-is-not#:~:text=added%206%25%20to%20food%20prices%20in%20two%20years">6% to food prices</a>, according to some estimates. <a href="https://www.thetimes.co.uk/article/28e77a0a-8f97-11ed-8b99-f233af7a7956">Make UK claims 43%</a> of companies regard the UK as a declining place for investment.</p><p>Simon Jenkins is a Guardian columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/brexit-mistake-northern-ireland-protocol">Continue reading...</a>

## ‘He’s a coward’: Lucas Kunce on his Senate run – and Hawley running away
 - [https://www.theguardian.com/us-news/2023/jan/13/lucas-kunce-josh-hawley-us-senate-missouri](https://www.theguardian.com/us-news/2023/jan/13/lucas-kunce-josh-hawley-us-senate-missouri)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 10:00:12+00:00
 - user: None

<p>Missouri Democrat mounting a second bid for US Senate hammers the Republican incumbent over his actions on January 6</p><p>Announcing his second bid for US Senate in Missouri, Lucas Kunce needed to hit the ground running. He did so by <a href="https://www.youtube.com/watch?v=McuIscYMRmw">running an ad</a> targeting the Republican he hopes to defeat, Josh Hawley, for running away from the January 6 rioters he encouraged.</p><p>The ad appeared on the second anniversary of the deadly attack on the US Capitol by Donald Trump’s supporters. On 6 January 2021, before the mob broke in, Hawley was photographed raising his fist in its direction. The House January 6 committee showed what happened after rioters breached the walls: the senator <a href="https://www.theguardian.com/us-news/2022/jul/21/josh-hawley-running-away-rioters-january-6">ran for cover</a>.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/lucas-kunce-josh-hawley-us-senate-missouri">Continue reading...</a>

## Break Point review – is tennis boring? This documentary suggests as much
 - [https://www.theguardian.com/tv-and-radio/2023/jan/13/break-point-review-netflix-tennis-documentary](https://www.theguardian.com/tv-and-radio/2023/jan/13/break-point-review-netflix-tennis-documentary)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 09:59:10+00:00
 - user: None

<p>This series from the makers of F1: Drive to Survive fails to make the racket sport seem interesting – despite exclusive access to bad boy Nik Kyrgios</p><p>Break Point, Netflix’s new behind-the-scenes documentary series about the 2022 tennis season, is by the team behind the excellent F1: Drive to Survive – but although it emulates that show’s slick presentational sheen, making tennis as exciting a subject as motor racing is difficult. Blokes who race cars are gossipy playboys enjoying a sport full of controversy, political manoeuvres, garish eccentricity and the real risk of fiery death. Tennis cannot compete with that: the big dramas happen inside the players’ heads, and Break Point is an only intermittently successful attempt to capture them on screen.</p><p>This style of documentary, where kinetic game footage is mixed with revealing interviews and a lot of blustery cliche about how epic and exciting everything is, just doesn’t suit tennis very well. Whereas team field sports – rugby, soccer, American football – have big moments that energise other popular series such as All or Nothing, tennis matches are attritional, technical battles, decided gradually in matches that can last for several hours. There are no big-money transfers or arguments over team selection. How about the in-game pep talks from coaches that are often the best bit of a sports doc? Nope. Not really a thing in tennis. Like us, the coaches observe helplessly from the stands.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/13/break-point-review-netflix-tennis-documentary">Continue reading...</a>

## A Streetcar Named Desire review – Paul Mescal brings a fierce and dangerous energy
 - [https://www.theguardian.com/stage/2023/jan/13/a-streetcar-named-desire-review-almeida-london-paul-mescal](https://www.theguardian.com/stage/2023/jan/13/a-streetcar-named-desire-review-almeida-london-paul-mescal)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 09:53:31+00:00
 - user: None

<p><strong>Almeida, London<br /></strong>One of the year’s most hyped shows delivers with powerful performances from the Normal People star, Patsy Ferran and Anjana Vasan</p><p>Two weeks into 2023 and we have already arrived at one of the year’s hottest, most hyped shows. The excitement around this production of Tennessee Williams’s 1947 drama of desire, delusion and mental illness has been both over its casting of screen star Paul Mescal and its director, <a href="https://www.theguardian.com/stage/2021/nov/20/we-were-a-little-naive-staging-cabaret-in-the-60s-and-now">Rebecca Frecknall</a>, whose revival of Cabaret won copious honours last year.</p><p>A Streetcar Named Desire warrants the hype, although at first it looks as if Frecknall’s directorial vision is driven by a rampant theatricality which might eclipse Mescal’s performance (and every other) and drain the play of its emotional power.</p> <a href="https://www.theguardian.com/stage/2023/jan/13/a-streetcar-named-desire-review-almeida-london-paul-mescal">Continue reading...</a>

## Mette Henriette: Drifting review | John Lewis's contemporary album of the month
 - [https://www.theguardian.com/music/2023/jan/13/mette-henriette-drifting-review-chamber-trios-delicate-steps](https://www.theguardian.com/music/2023/jan/13/mette-henriette-drifting-review-chamber-trios-delicate-steps)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 09:00:11+00:00
 - user: None

<p><strong>(ECM)<br /></strong>The<strong> </strong>Norwegian saxophonist is joined by cellist, Judith Hamann, and pianist, Johan Lindvall, for her long-awaited second album</p><p>The Norwegian saxophonist Mette Henriette seems to have become the quintessential ECM Records artist. Her second album features all the hallmarks of Manfred Eicher’s label: beautifully recorded low-volume acoustic music located somewhere equidistant from jazz, folk and contemporary composition, with nothing as vulgar as a drum kit to sully the delicate sonic properties of each instrument.</p><p>Henriette’s 2015 debut flirted with a mini orchestra on some tracks but this long-awaited follow-up concentrates on a small chamber trio, which seems to suit her style. Over 15 short tracks, she is joined by Swedish pianist Johan Lindvall and the extraordinary Australian cellist Judith Hamann.</p> <a href="https://www.theguardian.com/music/2023/jan/13/mette-henriette-drifting-review-chamber-trios-delicate-steps">Continue reading...</a>

## White Riot by Joe Thomas review – racial tensions in Thatcher’s Britain
 - [https://www.theguardian.com/books/2023/jan/13/white-riot-by-joe-thomas-review-racial-tensions-in-thatchers-britain](https://www.theguardian.com/books/2023/jan/13/white-riot-by-joe-thomas-review-racial-tensions-in-thatchers-britain)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 09:00:11+00:00
 - user: None

<p>Drawing on archive material, this propulsive crime novel explores police violence and unsolved killings in a fracturing nation</p><p>With its Indian restaurants, market stalls, bagel shops and louche charm, London’s <a href="https://www.theguardian.com/cities/2017/mar/06/brick-lane-in-the-80s-before-it-became-banglatown">Brick Lane</a> had many attractions in the late 1970s and early 80s, but was disfigured each Sunday by the menacing presence of National Front supporters selling their odious newspaper. As the son of West Indians, I despised and feared the NF, but suspected their vitriolic anti-immigrant stance was harboured quietly by many Britons, including politicians and police officers.</p><p>This ugly period of recent British history, the focus of Joe Thomas’s novel White Riot, was characterised by opposing sentiments: growing nativism coupled with free-market Thatcherism, versus race and working‑class allyship. The title is taken from <a href="https://www.theguardian.com/music/clash">the Clash</a>’s first single, which Joe Strummer described as a call to arms for white youth to resist state-sanctioned poverty and over-policing, in the same way as their Black compatriots.</p> <a href="https://www.theguardian.com/books/2023/jan/13/white-riot-by-joe-thomas-review-racial-tensions-in-thatchers-britain">Continue reading...</a>

## UAE’s Cop28 president will keep role as head of national oil company
 - [https://www.theguardian.com/environment/2023/jan/13/uae-cop28-president-sultan-al-jaber-to-keep-role-as-head-of-national-oil-company](https://www.theguardian.com/environment/2023/jan/13/uae-cop28-president-sultan-al-jaber-to-keep-role-as-head-of-national-oil-company)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:47:40+00:00
 - user: None

<p>Campaigners warn ‘breathtaking conflict of interest’ could jeopardise climate negotiating process</p><p>Sultan Al Jaber, the government minister for United Arab Emirates who will preside over this year’s crucial UN climate talks, will retain his roles as head of the country’s oil company and sustainable energy businesses, UAE has confirmed.</p><p>Campaigners have been angered by the decision, <a href="https://www.theguardian.com/world/2023/jan/11/uae-to-launch-cop28-presidency-with-oil-boss-tipped-for-leading-role">revealed by the Guardian on Wednesday</a> and confirmed on Thursday by the UAE government, which they see as a clear conflict of interest, with some likening it to putting a tobacco company head in charge of an anti-smoking treaty, and warning it could jeopardise the negotiating process and hasten climate breakdown.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/uae-cop28-president-sultan-al-jaber-to-keep-role-as-head-of-national-oil-company">Continue reading...</a>

## Margo Price: Strays review – a magic mushroom-fuelled trip that packs a lyrical gut-punch
 - [https://www.theguardian.com/music/2023/jan/13/margo-price-strays-review-a-magic-mushroom-fuelled-trip-that-packs-a-lyrical-gut-punch](https://www.theguardian.com/music/2023/jan/13/margo-price-strays-review-a-magic-mushroom-fuelled-trip-that-packs-a-lyrical-gut-punch)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:30:10+00:00
 - user: None

<p><strong>(Loma Vista)<br /></strong>The Nashville star brilliantly rattles through country, psych and Patti Smith-style poetic rock’n’roll on a fourth album that creates a feeling of wild landscapes</p><p>Nashville star Margo Price went from poverty and alcoholism to pawning her wedding ring in order to fund her 2016 debut Midwest Farmer’s Daughter, which topped the UK country charts. But she refuses to let her backstory define her on her fourth album, Strays. Driving organ-rich opener Been to the Mountain finds her declaring “I’ve rolled in dirty dollars, stood in the welfare line” but announcing, defiantly: “I know there’s more here than this.”</p><p>Hot on the heels of her autobiography, Maybe We’ll Make It, Strays brilliantly rattles through country, psych and Patti Smith-style poetic rock’n’roll. Written after a six-day magic mushroom session with husband/collaborator Jeremy Ivey, the 10 songs were recorded at Angel Olsen producer Jonathan Wilson’s Topanga Canyon studio in California and have a feeling of wild landscapes as they veer between the autobiographical and the observational.</p> <a href="https://www.theguardian.com/music/2023/jan/13/margo-price-strays-review-a-magic-mushroom-fuelled-trip-that-packs-a-lyrical-gut-punch">Continue reading...</a>

## NFL wildcard weekend predictions: which No 3 seed is heading out?
 - [https://www.theguardian.com/sport/2023/jan/13/nfl-wildcard-weekend-predictions-playoffs-football](https://www.theguardian.com/sport/2023/jan/13/nfl-wildcard-weekend-predictions-playoffs-football)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:12:09+00:00
 - user: None

<p>There are plenty of intriguing match-ups as the playoffs kick-off. Who will survive and book a spot in the NFL’s last eight?</p><p>It will not be business as usual in the NFL playoffs this weekend. Buffalo Bills safety Damar Hamlin’s <a href="https://www.theguardian.com/sport/2023/jan/04/damar-hamlin-injury-nfl-postpone-game">on-field cardiac arrest</a> earlier this month will haunt proceedings, despite his <a href="https://www.theguardian.com/sport/2023/jan/11/damar-hamlin-released-hospital-buffalo-bills">near-miraculous recovery</a>. How could it not? If there’s one thing we should take away from the last few weeks, it’s that the league is populated by human beings, not abstract figures on stats sheets. The playoffs will continue as scheduled but expect the atmosphere to be more subdued than in years past. And let’s hope that the drama remains entirely football-related.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/nfl-wildcard-weekend-predictions-playoffs-football">Continue reading...</a>

## Sunak must stand up to ‘Brexit purity cult’ in Tory party, says Starmer
 - [https://www.theguardian.com/politics/2023/jan/13/keir-starmer-labour-sunak-tory-brexit-purity-cult-northern-ireland-protocol](https://www.theguardian.com/politics/2023/jan/13/keir-starmer-labour-sunak-tory-brexit-purity-cult-northern-ireland-protocol)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:11:58+00:00
 - user: None

<p>Labour leader to urge PM to take on Eurosceptics in attempt to resolve Northern Ireland protocol issues</p><p>Keir Starmer is to challenge Rishi Sunak to stand up to the “Brexit purity cult” of Eurosceptics within the Conservative party to resolve the Northern Ireland protocol impasse.</p><p>The Labour leader will use a speech in Belfast on Friday to encourage the prime minister to take on the once highly influential European Research Group (ERG) of backbench Tory MPs to find a fix for issues arising from Northern Ireland’s post-Brexit trading arrangements.</p> <a href="https://www.theguardian.com/politics/2023/jan/13/keir-starmer-labour-sunak-tory-brexit-purity-cult-northern-ireland-protocol">Continue reading...</a>

## Trump to ramp up efforts to secure 2024 Republican nomination after slow start
 - [https://www.theguardian.com/us-news/2023/jan/13/trump-events-secure-2024-republican-nomination](https://www.theguardian.com/us-news/2023/jan/13/trump-events-secure-2024-republican-nomination)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:00:11+00:00
 - user: None

<p>Events aim at giving ex-president a narrative reset after being criticized for his ‘low energy’ and inactivity, sources say</p><p>Donald Trump is scheduled to venture out of his Mar-a-Lago resort and conduct a swing of presidential campaign events later this month, ramping up efforts to secure the Republican nomination after facing hefty criticism around the slow start to his 2024 White House bid, according to sources familiar with the matter.</p><p>The <a href="https://www.theguardian.com/us-news/donaldtrump">former US president</a> is expected to travel to a number of early voting states for the Republican nomination – the specific states have not been finalized – around the final weekend of January, the sources said, where he is slated to announce his state level teams.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/trump-events-secure-2024-republican-nomination">Continue reading...</a>

## Babylon breakout star Diego Calva: ‘I owe this role to Margot Robbie. Something happened between us’
 - [https://www.theguardian.com/film/2023/jan/13/babylon-breakout-star-diego-calva-i-owe-this-role-to-margot-robbie-something-happened-between-us](https://www.theguardian.com/film/2023/jan/13/babylon-breakout-star-diego-calva-i-owe-this-role-to-margot-robbie-something-happened-between-us)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:00:10+00:00
 - user: None

<p>His smouldering looks enliven Damien Chazelle’s new Hollywood hedonism film, but life hasn’t always been easy. He talks about being catapulted into the big leagues – and leaving behind his struggles with depression</p><p>Damien Chazelle’s Babylon, a three-hour extravaganza about Hollywood hedonism in the silent era and beyond, could never be accused of subtlety. There is, though, a flash of understatement near the beginning of the film, when Nellie, a dizzy ingenue played by Margot Robbie, turns to Manny, the indefatigable studio dogsbody, and tells him: “You know, you’re not bad-looking.” Manny is played by the smouldering newcomer Diego Calva. How handsome is he? Put it this way: one smile from him, even on a fuzzy and faltering video call, and it is as if <a href="http://t0.gstatic.com/licensed-image?q=tbn:ANd9GcQgi00ueRJ-HVa32tBqvFk79ZSkvCpS2bRRYfUhFVXDHk_pCvuixMAiZ8NiQI2idnefo2oFjUerNOrhbgM">Ramon Novarro</a> never existed.</p><p>The 30-year-old actor is under the weather today, but his whopping hazel eyes still gleam beneath their sleepy lids, and his voice sounds darting and musical, sandpaper-scratchy though it is. “I feel a little sick but we’re good to go,” he says through his sniffles. Calva was meant to be in Los Angeles but illness has kept him in his New York hotel room, where he squints into his webcam as we talk, and pads around restlessly in nothing but a pistachio-coloured sweater and his underwear. The impulse to hop on a flight to JFK bearing soup and a blanket is not an easy one to suppress.</p> <a href="https://www.theguardian.com/film/2023/jan/13/babylon-breakout-star-diego-calva-i-owe-this-role-to-margot-robbie-something-happened-between-us">Continue reading...</a>

## The week in wildlife – in pictures
 - [https://www.theguardian.com/environment/gallery/2023/jan/13/the-week-in-wildlife-in-pictures](https://www.theguardian.com/environment/gallery/2023/jan/13/the-week-in-wildlife-in-pictures)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:00:10+00:00
 - user: None

<p>The best of this week’s wildlife pictures, including grazing goats, a recovering griffon and relaxing monkeys</p> <a href="https://www.theguardian.com/environment/gallery/2023/jan/13/the-week-in-wildlife-in-pictures">Continue reading...</a>

## You can’t stop the likes of Bridgen and Tate saying dangerous things – but you can take away their soapboxes | Gaby Hinsliff
 - [https://www.theguardian.com/commentisfree/2023/jan/13/andrew-brigden-andrew-tate-online-safety-bill](https://www.theguardian.com/commentisfree/2023/jan/13/andrew-brigden-andrew-tate-online-safety-bill)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:00:10+00:00
 - user: None

<p>It’s time to look again at the UK’s watered-down online safety bill: this problem is too big for democracies to ignore any more</p><p>The Conservative backbencher Andrew Bridgen was never the most glittering star in the political firmament. You might recall him from such hits as <a href="https://www.independent.co.uk/news/uk/home-news/irish-passport-england-uk-andrew-bridgen-tory-mp-brexit-border-eu-a8587286.html">wrongly suggesting</a> that any English person could ask for an Irish passport post-Brexit, or posting a <a href="https://www.dailymail.co.uk/news/article-5852679/Sexism-storm-Tory-MP-sends-raunchy-film-clip-Cabinet-WhatsApp-group.html">raunchy video</a> in a ministerial WhatsApp group.</p><p>More recently you might recall him being <a href="https://www.theguardian.com/politics/2023/jan/09/andrew-bridgen-suspended-from-house-of-commons-over-lobbying">suspended from parliament</a> for five days for breaching lobbying rules. But what ultimately cost him the Conservative whip was something of a different order entirely. Bridgen has recently taken to spouting anti-vaxxer messages on Twitter, and making <a href="https://www.thetimes.co.uk/article/tory-mp-andrew-bridgen-says-covid-19-was-kept-secret-and-then-exploited-kvchksz2h">bizarre claims</a> about a global conspiracy to cover up the truth about Covid.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/andrew-brigden-andrew-tate-online-safety-bill">Continue reading...</a>

## You be the judge: should my daughter stop using the dishwasher all the time?
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/you-be-the-judge-should-my-daughter-stop-using-the-dishwasher-all-the-time](https://www.theguardian.com/lifeandstyle/2023/jan/13/you-be-the-judge-should-my-daughter-stop-using-the-dishwasher-all-the-time)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 08:00:09+00:00
 - user: None

<p>Ama says the dishwasher saves time and energy. Her dad thinks she should wash up by hand. Is he right to land her in hot water? <br /><br /><a href="https://www.theguardian.com/lifeandstyle/2021/sep/25/you-be-the-judge-send-us-your-domestic-disputes">Find out how to get a disagreement settled or become a You be the judge juror</a></p><p><em>Ama always tries to put the dishwasher on – even for three plates and a few forks and breakfast bowls</em></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/you-be-the-judge-should-my-daughter-stop-using-the-dishwasher-all-the-time">Continue reading...</a>

## The Year of the Cat by Rhiannon Lucy Cosslett review – reflections on the feline
 - [https://www.theguardian.com/books/2023/jan/13/the-year-of-the-cat-by-rhiannon-lucy-cosslett-review-reflections-on-the-feline](https://www.theguardian.com/books/2023/jan/13/the-year-of-the-cat-by-rhiannon-lucy-cosslett-review-reflections-on-the-feline)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:30:09+00:00
 - user: None

<p>An affecting memoir that uses cats and our attitudes towards them to explore PTSD, separation, love and family</p><p>I found myself reading part of Rhiannon Lucy Cosslett’s account of the first year of her cat Mackerel’s life while I was sitting with Hector, my Norwegian Forest cat (I’ve always been delighted by the fact that <a href="https://www.theguardian.com/books/2020/nov/20/jan-morris-historian-travel-writer-and-trans-pioneer-dies-aged-94">Jan Morris</a> also had one of these noble specimens). Hector, a stray who came in from the cold and who turned out to be female, is now blind, and we supervise her meals lest her two housemates, Zsa Zsa, a black and white made cantankerous by juvenile arthritis, and Kiki the kitten, a boisterous and daftly loving tabby, try to edge her out of her dinner. As she finished, I lifted my head from the book and apologised to her for not being more chatty while she ate. Then I kissed her gently on the head. It is this kind of behaviour that The Year of the Cat seeks to analyse and understand: not only the emotional care cat owners often find themselves lavishing on these supremely unknowable little animals, but the reactions to our reactions, especially when they are pejorative.</p><p>“Cat lady” is one such charge, sometimes with the intensifier “crazy”, although it was my husband who wept for days when Hector lost her sight, for fear that she would be frightened and confused (she has proved wonderfully adaptable). Women who love their cats inordinately are said to be compensating – most usually for lack of sex or children – and projecting on to them an intimacy they are unable to experience elsewhere.</p> <a href="https://www.theguardian.com/books/2023/jan/13/the-year-of-the-cat-by-rhiannon-lucy-cosslett-review-reflections-on-the-feline">Continue reading...</a>

## UK economic growth slows to 0.1% in November – business live
 - [https://www.theguardian.com/business/live/2023/jan/13/uk-gdp-economy-november-recession-inflation-energy-business-live](https://www.theguardian.com/business/live/2023/jan/13/uk-gdp-economy-november-recession-inflation-energy-business-live)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:15:21+00:00
 - user: None

<p>Rolling coverage of the latest economic and financial news, with the latest healthcheck on the UK economy due at 7am</p><p><strong>Jeremy Hunt, Chancellor of the Exchequer, says:</strong></p><p>“We have a clear plan to halve inflation this year - an insidious hidden tax which has led to hikes in interest rates and mortgage costs, holding back growth here and around the world.</p><p>“To support families through this tough patch, we will provide an average of £3,500 support for every household over this year and next - but the most important help we can give is to stick to the plan to halve inflation this year so we get the economy growing again.”</p> <a href="https://www.theguardian.com/business/live/2023/jan/13/uk-gdp-economy-november-recession-inflation-energy-business-live">Continue reading...</a>

## I have seen how top-down solutions condemn the world’s poorest to eternal poverty | Anthony Kalulu
 - [https://www.theguardian.com/global-development/2023/jan/13/top-down-solutions-poor-poverty-solutions-covid](https://www.theguardian.com/global-development/2023/jan/13/top-down-solutions-poor-poverty-solutions-covid)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:15:08+00:00
 - user: None

<p>A western-led approach has failed to remedy the problem. Maybe, post-pandemic, a new focus on the poor is needed </p><p>In 2020, many people said the world must not “go back to normal”, to the same old ways that defined it before the Covid pandemic. The Overseas Development Institute, a UK-based thinktank, even said “<a href="https://odi.org/en/insights/covid-19-we-wont-get-back-to-normal-because-normal-was-the-problem/">normal was the problem</a>”.</p><p>I really wish the world would remember this.</p> <a href="https://www.theguardian.com/global-development/2023/jan/13/top-down-solutions-poor-poverty-solutions-covid">Continue reading...</a>

## Allison Williams: ‘If I was cast on Girls now, the experience would be much more stressful’
 - [https://www.theguardian.com/film/2023/jan/13/allison-williams-interview-m3gan](https://www.theguardian.com/film/2023/jan/13/allison-williams-interview-m3gan)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:02:08+00:00
 - user: None

<p>The actor reflects on her role in the zeitgeisty HBO series, subverting expectations in Get Out, her hit horror M3gan and the nepo baby discourse</p><p>For those with even a tentative toe online, it was hard to avoid the impact of yassified evil doll turned <a href="https://screenrant.com/megan-movie-doll-queer-icon/">newly branded “queer icon”</a> M3gan this past week. Ever since she danced her way to virality in <a href="https://www.youtube.com/watch?v=BRb4U99OU80">the internet-shifting trailer</a> for <a href="https://www.theguardian.com/film/2023/jan/04/m3gan-review-girlbot-horror-offers-entertaining-spin-on-teenage-growing-pains">her self-titled film</a> late last year, she’s never been far from the spotlight, but with the film finally unfurling in US cinemas, she was front and centre, terrorising Twitter and TikTok and sleekly dethroning both Chucky and Annabelle within a weekend.</p><p>“I was getting sent a lot of memes,” Allison Williams, the film’s star, tells me over Zoom. “I have a few friends who just sent me everything they see that’s funny and their Twitter algorithms are just like: ‘Oh, I guess you just want non-stop M3gan content.’”</p> <a href="https://www.theguardian.com/film/2023/jan/13/allison-williams-interview-m3gan">Continue reading...</a>

## Chocolate coats tongue to give melt-in-mouth sensation, study finds
 - [https://www.theguardian.com/science/2023/jan/13/chocolate-coats-tongue-melt-imouth-sensation-study](https://www.theguardian.com/science/2023/jan/13/chocolate-coats-tongue-melt-imouth-sensation-study)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:00:09+00:00
 - user: None

<p>Scientists say sensual discovery could be used to design low-fat product that mimics feel of high fat</p><p>The irresistible melt-in-the-mouth sensation of chocolate comes down to the way it lubricates the tongue, according to scientists.</p><p>A study investigated the physical process by which a solid square of chocolate morphs into a smooth emulsion. It found that chocolate released a fatty film that coats the tongue, giving a smooth sensation for the entire time it is in the mouth.</p> <a href="https://www.theguardian.com/science/2023/jan/13/chocolate-coats-tongue-melt-imouth-sensation-study">Continue reading...</a>

## Cycling ancient trails: off-road on an e-bike in Pembrokeshire’s Preseli Hills
 - [https://www.theguardian.com/travel/2023/jan/13/cycling-off-road-e-bike-wales-preseli-hills-pembrokeshire](https://www.theguardian.com/travel/2023/jan/13/cycling-off-road-e-bike-wales-preseli-hills-pembrokeshire)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:00:09+00:00
 - user: None

<p>Guided e-mountain bike rides in south-west Wales reveal a wild landscape of woods and rocky summits, plus a valley so secluded it still follows the Julian calendar</p><p>The path on which I’m riding my e-mountain bike across the hills of north Pembrokeshire is known as a bridleway, but to Ed Sykes, who grew up in these hills, it’s an “e-trail”. Ed is the founder of Hidden Routes in Newport (between Cardigan and Fishguard), an e-mountain biking outfit that takes clients on guided rides through what is probably the least-known corner of Pembrokeshire.</p><p>He came up with the term “e-trail” because, he says, he “wanted a name that differentiated what we do from regular mountain biking. Our routes are rideable on a normal mountain bike, of course, but we just reckon they’re more fun – and easier – on an e-mountain bike.”</p> <a href="https://www.theguardian.com/travel/2023/jan/13/cycling-off-road-e-bike-wales-preseli-hills-pembrokeshire">Continue reading...</a>

## Already ‘failed’ Dry January? There’s another way, and I’ve been doing it for years | Barbara Speed
 - [https://www.theguardian.com/commentisfree/2023/jan/13/dry-january-sober-drink-app](https://www.theguardian.com/commentisfree/2023/jan/13/dry-january-sober-drink-app)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:00:08+00:00
 - user: None

<p>Like other sober-curious people, I wanted <em>slightly</em> more of a handle on what I drank. So I started logging every drink in an app. And, reader: it helped</p><p>I am not doing Dry January this year. I didn’t do it last year, or the year before that. But I do know, down to the glass, what I drank on every single one of those January days. Two post-new year amarettos on 2 January 2021; two glasses of prosecco on 9 January 2020 (if I’d known what was coming in March, I might have stretched to three); a lone bottle of beer on a Sunday in 2019.</p><p>This isn’t some incredible feat of memory. The data is at my fingertips thanks to something I started doing just over five years ago, in late 2017. Every day – or, let’s be realistic, often a few days later – I plug the amount I’ve had to drink into an app.</p><p>Barbara Speed is a Guardian Opinion deputy editor</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/dry-january-sober-drink-app">Continue reading...</a>

## Walrus detectives and the Year of the Tiger: WWF’s key moments of 2022
 - [https://www.theguardian.com/artanddesign/2023/jan/13/walrus-detectives-and-the-year-of-the-tiger-wwfs-key-moments-of-2022](https://www.theguardian.com/artanddesign/2023/jan/13/walrus-detectives-and-the-year-of-the-tiger-wwfs-key-moments-of-2022)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 07:00:08+00:00
 - user: None

<p>This reflection on key moments reveals 2022 as a year of environmental highs and lows, many of which will continue to resonate in the year ahead</p><p>As we enter 2023, <a href="https://www.wwf.org.uk/">WWF</a> reflects on key moments from the last 12 months. From celebrating the Year of the Tiger and recruiting ‘Walrus Detectives’, to continued deforestation in the Amazon and the effects of extreme weather events around the world, 2022 was a year of environmental highs and lows, many of which will continue to resonate in the year ahead.</p><p>Photograph: Hushed Hills Ltd/WWF-Kenya</p> <a href="https://www.theguardian.com/artanddesign/2023/jan/13/walrus-detectives-and-the-year-of-the-tiger-wwfs-key-moments-of-2022">Continue reading...</a>

## ‘A lifeline’: mental health camps bring peace of mind to thousands in rural Assam
 - [https://www.theguardian.com/global-development/2023/jan/13/mental-health-camps-assam-india-acc](https://www.theguardian.com/global-development/2023/jan/13/mental-health-camps-assam-india-acc)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:30:08+00:00
 - user: None

<p>India’s severe shortage of mental health professionals and treatment funding leaves many patients without options. But a pioneering programme is working to get lives back on track</p><p>It is Saturday morning, and some 40 people on foot, bikes and rickshaws begin trickling into Kuklung village. They take a seat outside a single-storey building and wait to see the psychiatrist at a monthly treatment camp for people with mental health conditions.</p><p>The camp is providing a lifeline to this remote, impoverished community in Assam, in northeastern India.</p> <a href="https://www.theguardian.com/global-development/2023/jan/13/mental-health-camps-assam-india-acc">Continue reading...</a>

## House Party review – comedy remake is not worth the invite
 - [https://www.theguardian.com/film/2023/jan/13/house-party-review-lebron-james](https://www.theguardian.com/film/2023/jan/13/house-party-review-lebron-james)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:07:07+00:00
 - user: None

<p>The much-loved 1990 hit gets a flat, unnecessary upgrade with help from LeBron James and a host of other misfiring guests</p><p>“Party at LeBron’s” is a dynamite premise for a movie, especially if the King in question is the cheapskate egotist who stole the 2015 romcom Trainwreck as effortlessly as he would a lazy crosscourt pass. But it’s one thing for Judd Apatow and Amy Schumer to caricature the NBA great, quite another for James to take himself down a few pegs and bring one of the more beloved franchises in Black film cinema history with him.</p><p>House Party – like the forthcoming White Men Can’t Jump remake, also directed by Charles Kidd II (AKA Calmatic) – makes no titular attempt to distinguish itself from the 1990 classic. This latest edition, which premieres this weekend, doesn’t so much build on the story of the previous three films, or the two straight-to-DVD postscripts, as retread the idea of two best buds throwing a big do that promises to forever change their lives. In the original, Kid and Play (Christopher Reid and Christopher Martin) were a hungry pair of preppy rappers who were legitimately talented and clawing for a breakthrough. In the new edition Damon (Tosin Cole) is a clout-chasing social media influencer, and Kevin (Jacob Latimore) a reluctant bedroom beat maker with a baby daughter named Destiny (groan) who needs money for private school.</p> <a href="https://www.theguardian.com/film/2023/jan/13/house-party-review-lebron-james">Continue reading...</a>

## A lesson for Sunak: when the Tories take on striking workers, they don’t always win | Andy Beckett
 - [https://www.theguardian.com/commentisfree/2023/jan/13/rishi-sunak-tories-striking-workers-trade-unions](https://www.theguardian.com/commentisfree/2023/jan/13/rishi-sunak-tories-striking-workers-trade-unions)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:10+00:00
 - user: None

<p>The prime minister is pitting the public against trade unionists — forgetting that, in millions of cases, they are the same people</p><p>In Britain, the feelings that strikes arouse in Tory politicians can be more complicated than you might think. At first, there is often outrage that the usual supremacy of bosses over workers has been suspended. Preserving such hierarchies is one of Conservatism’s main aims.</p><p>But then there is sometimes a sense of opportunity: a belief that the strikers and their supporters may fall into a familiar trap, set by decades of anti-union legislation and press propaganda. Ever since Margaret Thatcher defeated the miners and other unions in the 1980s, Conservatives have believed that strikes can be used to make Tory governments look tough, and to discredit Labour and the wider left. The succession of aggressive, deliberately provocative <a href="https://www.theguardian.com/uk-news/2023/jan/10/anti-strike-bill-unveiled-in-commons-but-no-detail-on-minimum-service-levels">anti-strike measures</a> announced over the last six months by the governments of Boris Johnson, Liz Truss and now Rishi Sunak all reflect an assumption that taking on the unions is one of the few remaining strategies that might get the Conservatives re-elected.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/13/rishi-sunak-tories-striking-workers-trade-unions">Continue reading...</a>

## Long-awaited trial of 24 aid workers accused of espionage starts in Lesbos
 - [https://www.theguardian.com/global-development/2023/jan/13/long-awaited-trial-of-24-aid-workers-accused-of-espionage-starts-in-lesbos](https://www.theguardian.com/global-development/2023/jan/13/long-awaited-trial-of-24-aid-workers-accused-of-espionage-starts-in-lesbos)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:09+00:00
 - user: None

<p>Trial of Sarah Mardini and fellow defendants  lifts lid on ‘farcical’ treatment of humanitarians, say campaigners</p><p>Sarah Mardini, the refugee immortalised in the recent Netflix movie, <a href="https://www.theguardian.com/film/2022/nov/12/the-swimmers-review-powerful-refugee-drama-goes-for-the-happy-ending">The Swimmers</a>, was the talk of Lesbos this week as the long-awaited trial of 24 aid workers accused of espionage, got underway on the island. </p><p>Eight years after the Syrian and her younger sister, Yusra, saved 18 fellow passengers from a sinking dinghy off the isle, it was Mardini’s name that stood out as appeals court judge, Styliani Spyridonidou, conducted a roll call of defendants at the start of a hearing that has fuelled widespread human rights concerns. But,although Mardini’s story hogged the Greek headlines, the 27-year-old student, accused of spying after returning to the island to assist refugees, was not present.</p> <a href="https://www.theguardian.com/global-development/2023/jan/13/long-awaited-trial-of-24-aid-workers-accused-of-espionage-starts-in-lesbos">Continue reading...</a>

## Private jet emissions quadrupled during Davos 2022
 - [https://www.theguardian.com/environment/2023/jan/13/private-jet-emissions-quadrupled-davos-2022](https://www.theguardian.com/environment/2023/jan/13/private-jet-emissions-quadrupled-davos-2022)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:09+00:00
 - user: None

<p>Climate campaigners accuse leaders of hypocrisy as flights emit as much CO<sub>2</sub> in a week as 350,000 cars</p><p>Private jet emissions quadrupled as 1,040 planes flew in and out of airports serving Davos during the 2022 World Economic Forum (WEF) meeting.</p><p>Climate campaigners accused the rich and powerful of hypocrisy in flying in on private jets to a conference discussing climate breakdown.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/private-jet-emissions-quadrupled-davos-2022">Continue reading...</a>

## Frantic search continues for boy, 5, swept away in California floods
 - [https://www.theguardian.com/us-news/2023/jan/12/california-floods-missing-boy-search-continues](https://www.theguardian.com/us-news/2023/jan/12/california-floods-missing-boy-search-continues)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:08+00:00
 - user: None

<p>Kyle Doan, 5, was pulled into the raging waters as he and his mom, Lindsy Doan, were trying to escape the sudden flooding</p><p>The danger lurking along a country road in central California’s wine country was not clear to Lindsy Doan as she drove her five-year-old son to school on Monday morning.</p><p>The region, like much of the state, had been hit by a deadly series of storms that were , but the family had traveled through the area the previous day, her husband told the Guardian, and countless times before on their commutes. Nothing initially appeared wrong and unlike past occasions, there were no signs indicating the road was closed.</p> <a href="https://www.theguardian.com/us-news/2023/jan/12/california-floods-missing-boy-search-continues">Continue reading...</a>

## How to start a sustainable, affordable garden – right now
 - [https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-start-a-sustainable-affordable-garden-right-now](https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-start-a-sustainable-affordable-garden-right-now)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:08+00:00
 - user: None

<p>It might be winter, but there’s plenty to do: our expert on how to start a small, climate-friendly garden from scratch</p><p>The moment I knew our home purchase was final, last April, I ransacked my mother’s garden for cuttings. It was still a little early in the season, but I couldn’t hold back: budding twigs of viburnum, potentilla, <a href="https://www.rhsplants.co.uk/plants/_/sambucus-nigra-f-porphyrophylla-eva-pbr/classid.2000004449/">black elder</a> and <a href="https://www.rhs.org.uk/plants/buddleja">buddleja</a> were thrust into compost. Despite having gardened professionally for well over a decade, managing and maintaining gardens from green city pockets up to modest rural estates, this would be my first ever garden.</p><p>It is a small, slim rectangle: 80 square metres of chalky, free-draining Hampshire soil – two-thirds of which is lawn – in a village fringing the <a href="https://www.northwessexdowns.org.uk/">North Wessex Downs</a>. It is north-facing yet exposed, and therefore surprisingly sun baked between the equinoxes, and, to our delight, relatively free of pre-existing structures: a tiny shed, a thin strip of border, a miscellany of pots and a beer-branded barbecue – my potting bench, until it is forcibly rehomed – but otherwise a horticultural blank canvas. </p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/13/how-to-start-a-sustainable-affordable-garden-right-now">Continue reading...</a>

## New photography techniques reveal the Baltic’s eerie wrecks – in pictures
 - [https://www.theguardian.com/environment/gallery/2023/jan/13/new-photography-techniques-reveal-the-baltics-eerie-wrecks-in-pictures](https://www.theguardian.com/environment/gallery/2023/jan/13/new-photography-techniques-reveal-the-baltics-eerie-wrecks-in-pictures)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:08+00:00
 - user: None

<p>Tens of thousands of ships from every era lie undisturbed at the bottom of the Baltic Sea. Some of the world’s most advanced underwater photography now reveals how miraculously the cold, brackish water has preserved them</p><p>• Extracted from the book <a href="https://www.amazon.co.uk/Ghost-Ships-Baltic-Carl-Douglas/dp/9171265376">Ghost Ships of the Baltic Sea</a> by Jonas Dahm and Carl Douglas, published by Max Ström</p> <a href="https://www.theguardian.com/environment/gallery/2023/jan/13/new-photography-techniques-reveal-the-baltics-eerie-wrecks-in-pictures">Continue reading...</a>

## Van Gogh painting on display at Detroit Institute of Art is stolen, lawsuit claims
 - [https://www.theguardian.com/artanddesign/2023/jan/12/van-gogh-painting-lawsuit-detroit-institute-of-art-stolen](https://www.theguardian.com/artanddesign/2023/jan/12/van-gogh-painting-lawsuit-detroit-institute-of-art-stolen)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:08+00:00
 - user: None

<p>Brazilian art collector says he paid $3.7m for the 1888 oil called The Novel Reader, when a third party took possession of it</p><p>A painting by Vincent van Gogh on display at the Detroit Institute of Art was stolen, a new <a href="https://news.artnet.com/app/news-upload/2023/01/temporary-restraining-order.pdf">lawsuit</a> claims.</p><p>The lawsuit was filed on Tuesday by Brokerarte Capital Partners and its sole proprietor, Gustavo Soter, a Brazilian art collector. It claims the DIA borrowed the painting from an unnamed party that is not its legal owner.</p> <a href="https://www.theguardian.com/artanddesign/2023/jan/12/van-gogh-painting-lawsuit-detroit-institute-of-art-stolen">Continue reading...</a>

## ‘People are leaving the game’: Dungeons & Dragons fans revolt against new restrictions
 - [https://www.theguardian.com/games/2023/jan/12/dungeons-and-dragons-wizards-of-the-coast-ogl](https://www.theguardian.com/games/2023/jan/12/dungeons-and-dragons-wizards-of-the-coast-ogl)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:08+00:00
 - user: None

<p>Wizards of the Coast, which owns the game, is preparing to change longstanding licensing rules</p><p>It’s been a tough week for Dungeons &amp; Dragons fans.</p><p>The reins were pulled in on users who come up with their own storylines and new characters, creating legions of imaginary worlds that spin off of the original fantasy roleplaying game.<strong> </strong>They have also been able to make and sell products required to play or based on the game under an open game license (OGL) agreement.</p> <a href="https://www.theguardian.com/games/2023/jan/12/dungeons-and-dragons-wizards-of-the-coast-ogl">Continue reading...</a>

## Caroline Polachek on pop, privacy and imperfection: ‘I wanted undeniable, anthemic diva moments’
 - [https://www.theguardian.com/music/2023/jan/13/caroline-polachek-on-pop-privacy-and-imperfection-i-wanted-undeniable-anthemic-diva-moments](https://www.theguardian.com/music/2023/jan/13/caroline-polachek-on-pop-privacy-and-imperfection-i-wanted-undeniable-anthemic-diva-moments)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:07+00:00
 - user: None

<p>The American avant-pop star started out as an indie darling producing songs for Beyoncé. Now, she’s back with an album that could make her Gen Z’s Kate Bush</p><p>A few months ago, Caroline Polachek was filming the music video for her 80s pop fantasia <a href="https://www.youtube.com/watch?reload=9&amp;v=hxgcz_6GKX0">Welcome to My Island</a>, trying to explain that her makeup needed to capture “the mania that comes with desire and striving”. “I was like: ‘I need to look desperate and pathetic,’” she says. Her reference point was someone “crawling out of a house party”, mascara bleeding on to their cheeks. Her glam team were bemused. “<em>Excuse me?</em>” she recalls them saying.</p><p>Her directive was firm. A musician for nearly 20 years – from indie darling in Chairlift to songwriter for Beyoncé, ambient experimentalist and now alternative pop star – Polachek, 37, has perfected the art of writing songs about the kind of emotion that, as she describes it, “doesn’t fit in the world”. With its crisp guitar solo and howling vocals, Welcome to My Island takes that idea to the next level, evoking the “side of vulnerability and openness that’s not always pretty”. It’s not darkness, she says, but “an essential part of being alive”.</p> <a href="https://www.theguardian.com/music/2023/jan/13/caroline-polachek-on-pop-privacy-and-imperfection-i-wanted-undeniable-anthemic-diva-moments">Continue reading...</a>

## Harry wanted men to talk about their problems. Now therapy has been weaponized against him | Sam Wolfson
 - [https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-therapy-mental-health](https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-therapy-mental-health)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 06:00:07+00:00
 - user: None

<p>The duke and his brother have spent years as mental health advocates – and therapy has fueled Harry’s public outpouring </p><p>While the revelations in Prince Harry’s book have shock value, the format they come in does not. The tell-all memoir, ghostwritten with the most salacious stories parcelled into pre-publication interviews, is a media set piece. Subject, publisher and publicists all know their roles and – bar a few early leaks – things have been staged-managed effectively.</p><p>But what’s so unusual about Harry’s revelations is how they have been compared to, and intertwined with, a far less premeditated form of disclosure: therapy.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/prince-harry-spare-book-therapy-mental-health">Continue reading...</a>

## Fukushima water to be released into ocean in next few months, says Japan
 - [https://www.theguardian.com/environment/2023/jan/13/fukushima-water-to-be-released-into-ocean-in-next-few-months-says-japan](https://www.theguardian.com/environment/2023/jan/13/fukushima-water-to-be-released-into-ocean-in-next-few-months-says-japan)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 05:50:20+00:00
 - user: None

<p>Authorities to begin release of a million tonnes of water from stricken nuclear plant after treatment to remove most radioactive material</p><p>The controversial release of more than a million tonnes of water from the wrecked <a href="https://www.theguardian.com/environment/fukushima">Fukushima</a> Daiichi nuclear plant will begin in the northern spring or summer, Japan’s government has said – a move that has sparked anger among local fishing communities and countries in the region.</p><p>The decision comes more than two years after the government approved the release of the water, which will be treated to remove most radioactive materials but will still contain tritium, a naturally occurring radioactive form of hydrogen that is technically difficult to separate from water.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/fukushima-water-to-be-released-into-ocean-in-next-few-months-says-japan">Continue reading...</a>

## Russia-Ukraine war live: ‘small pockets of resistance’ from Ukraine in Soledar, says Moscow-installed official
 - [https://www.theguardian.com/world/live/2023/jan/13/russia-ukraine-war-live-small-pockets-of-resistance-from-ukraine-in-soledar-says-moscow-installed-official](https://www.theguardian.com/world/live/2023/jan/13/russia-ukraine-war-live-small-pockets-of-resistance-from-ukraine-in-soledar-says-moscow-installed-official)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 05:39:23+00:00
 - user: None

<p>Russian Lieutenant Colonel says Russian-backed troops have almost full control; US envoy calls for Serbia to sign on to sanctions against Russia</p><ul><li><strong><a href="https://www.theguardian.com/world/series/russia-ukraine-war-at-a-glance">Russia-Ukraine war at a glance</a></strong></li></ul> <a href="https://www.theguardian.com/world/live/2023/jan/13/russia-ukraine-war-live-small-pockets-of-resistance-from-ukraine-in-soledar-says-moscow-installed-official">Continue reading...</a>

## Rick and Morty co-creator Justin Roiland awaiting trial on domestic violence charges
 - [https://www.theguardian.com/us-news/2023/jan/13/justin-roiland-rick-and-morty-high-on-life-facing-trial-domestic-violence-charges](https://www.theguardian.com/us-news/2023/jan/13/justin-roiland-rick-and-morty-high-on-life-facing-trial-domestic-violence-charges)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 05:32:11+00:00
 - user: None

<p>Roiland, who voices two of the animated TV show’s characters and created video game High on Life, has pleaded not guilty to the charges</p><p>Justin Roiland, who co-created the animated series Rick and Morty and provides the voices of the two title characters, is awaiting trial on charges of felony domestic violence against a former girlfriend.</p><p>A criminal complaint obtained from prosecutors in Orange County, California charged Roiland, 42, with corporal injury and false imprisonment by menace, fraud, violence or deceit against the woman, who he was living with at the time.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/justin-roiland-rick-and-morty-high-on-life-facing-trial-domestic-violence-charges">Continue reading...</a>

## ‘Truth is one of our rights’: victims of Indonesia’s bloody past want more than regret from their president
 - [https://www.theguardian.com/world/2023/jan/13/truth-is-one-of-our-rights-victims-of-indonesias-bloody-past-want-more-than-regret-from-their-president](https://www.theguardian.com/world/2023/jan/13/truth-is-one-of-our-rights-victims-of-indonesias-bloody-past-want-more-than-regret-from-their-president)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 04:25:42+00:00
 - user: None

<p>After Joko Widodo acknowledged the mass killings of 1965-66, victims say compensation is the next step</p><p>Ita Nadia is an Indonesian activist who lost her uncle, aunt and a nephew in the mass killings of 1965-66. Her husband, Hersri Setiawan, an 86-year-old writer, was imprisoned without trial for more than a decade. Hearing loss and damaged lungs are the consequences of the hard labour and torture he was forced to endure.</p><p>On Wednesday, Indonesia’s President Joko Widodo, often referred to as Jokowi, acknowledged the communist purge alongside 11 other “gross human rights violations” that took place in the country between 1965 and 2003. Activists and those affected say they need more than an acknowledgment.</p> <a href="https://www.theguardian.com/world/2023/jan/13/truth-is-one-of-our-rights-victims-of-indonesias-bloody-past-want-more-than-regret-from-their-president">Continue reading...</a>

## Putin scolds defence industry minister in televised meeting for ‘fooling around’
 - [https://www.theguardian.com/world/2023/jan/13/vladimir-putin-scolds-defence-industry-minister-manturov-tv-fooling-around](https://www.theguardian.com/world/2023/jan/13/vladimir-putin-scolds-defence-industry-minister-manturov-tv-fooling-around)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 04:07:06+00:00
 - user: None

<p>Russian leader publicly berated Denis Manturov, eye-rolling and shuffling papers during the live call, as his war in Ukraine caused fresh problems</p><p>Vladimir Putin has publicly scolded a senior minister and ally during a meeting broadcast on state television as sanctions from the stalling war in Ukraine caused fresh economic headaches for the Russian president.</p><p>Speaking during a live video call with officials on Wednesday, the Russian leader appeared agitated and berated deputy prime minister Denis Manturov, who is also his trade and industry minister and responsible for overseeing Russia’s weapons and defence industry and supplies of equipment for troops. Putin criticised him for working too slowly on the country’s aircraft contracts, according to a <a href="http://kremlin.ru/events/president/news/70338">transcript</a> of the call later published by the Kremlin.</p> <a href="https://www.theguardian.com/world/2023/jan/13/vladimir-putin-scolds-defence-industry-minister-manturov-tv-fooling-around">Continue reading...</a>

## NWSL draft: Alyssa Thompson becomes first high schooler taken with No 1 pick
 - [https://www.theguardian.com/football/2023/jan/12/alyssa-thompson-nwsl-draft-picks-angel-city-fc](https://www.theguardian.com/football/2023/jan/12/alyssa-thompson-nwsl-draft-picks-angel-city-fc)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 03:55:03+00:00
 - user: None

<ul><li>Alyssa Thompson, 18, chosen by Angel City FC in NWSL draft</li><li>Thompson becomes first ever high school player taken at No 1</li></ul><p>Alyssa Thompson was the top pick in the National Women’s Soccer League draft on Thursday by Angel City, becoming the first high school player to be selected in the history of the league.</p><p>Thompson, an 18-year-old forward out of Harvard-Westlake High School in Los Angeles, declared her eligibility for the draft late last week. She initially committed to Stanford.</p> <a href="https://www.theguardian.com/football/2023/jan/12/alyssa-thompson-nwsl-draft-picks-angel-city-fc">Continue reading...</a>

## Jailed for life for stealing $14 - podcast
 - [https://www.theguardian.com/news/audio/2023/jan/13/jailed-for-life-for-stealing-14-dollars-podcast](https://www.theguardian.com/news/audio/2023/jan/13/jailed-for-life-for-stealing-14-dollars-podcast)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 03:00:03+00:00
 - user: None

<p>David Coulson was imprisoned in California under draconian ‘tough on crime’ laws stemming from the 1990s. Now campaigners are calling for reform, reports Sam Levin</p><p>In California, if a person commits two felonies that are classed as ‘serious’ or ‘violent’, and then go on to commit any other crime, no matter how small, they will be given a life sentence. It’s a law stemming from a tough crackdown on crime in the 1990s when a wave of crime in the state caused public outcry and was used by politicians determined to respond in kind.</p><p>In theory, it would keep the most dangerous offenders away from society, but in practice it has served to swell California’s prison system, with tens of thousands of people locked up for life for committing petty crimes. Just like <strong>David Coulson</strong> who tells the Guardian’s <strong>Sam Levin </strong>how he ended up in jail after stealing just $14.</p> <a href="https://www.theguardian.com/news/audio/2023/jan/13/jailed-for-life-for-stealing-14-dollars-podcast">Continue reading...</a>

## Colleen Hoover apologises for ‘tone-deaf’ colouring book based on domestic violence novel
 - [https://www.theguardian.com/books/2023/jan/13/colleen-hoover-apologises-for-tone-deaf-colouring-book-based-on-domestic-violence-novel](https://www.theguardian.com/books/2023/jan/13/colleen-hoover-apologises-for-tone-deaf-colouring-book-based-on-domestic-violence-novel)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 02:14:27+00:00
 - user: None

<p>Bestselling author cancels plans for a colouring book based on her novel It Ends With Us, saying she ‘absolutely sees’ why fans were critical</p><p>Bestselling author Colleen Hoover has apologised after she announced plans to publish a colouring book based on one of her bestselling novels about domestic violence.</p><p>The US author of It Ends With Us announced The Official It Ends With Us Coloring Book on social media on Thursday. But after a furious backlash from readers, she apologised that same day, writing that she could “absolutely see” how the idea was “tone-deaf”. She said her publishers would not be proceeding with the book.</p> <a href="https://www.theguardian.com/books/2023/jan/13/colleen-hoover-apologises-for-tone-deaf-colouring-book-based-on-domestic-violence-novel">Continue reading...</a>

## Elle Edwards: man charged with Christmas Eve murder of 26-year-old
 - [https://www.theguardian.com/uk-news/2023/jan/13/elle-edwards-man-charged-with-christmas-eve-of-26-year-old](https://www.theguardian.com/uk-news/2023/jan/13/elle-edwards-man-charged-with-christmas-eve-of-26-year-old)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 01:57:15+00:00
 - user: None

<p>Connor Chapman has been remanded in custody and will appear in court on Friday</p><p>Police investigating the shooting of Elle Edwards in Wallasey on Christmas Eve have charged Connor Chapman, 22, with her murder.</p><p>Chapman, of Houghton Road, Woodchurch, has also been charged with two counts of attempted murder and three counts of unlawful and malicious wounding with intent to do grievous bodily harm, possession of a firearm with intent to endanger life, possession of ammunition with intent to endanger life, and handling stolen goods, namely a Mercedes A-Class.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/elle-edwards-man-charged-with-christmas-eve-of-26-year-old">Continue reading...</a>

## Australian government praises national cricket team boycott of Afghanistan matches
 - [https://www.theguardian.com/sport/2023/jan/13/australian-government-praises-national-cricket-team-boycott-of-afghanistan-matches](https://www.theguardian.com/sport/2023/jan/13/australian-government-praises-national-cricket-team-boycott-of-afghanistan-matches)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 01:49:34+00:00
 - user: None

<p>The decision by Cricket Australia, based on ‘unacceptable’ treatment of women and girls by the Taliban, has been labelled ‘pathetic’ by the Afghan Cricket Board</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Follow our Australia news live blog for the latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The Australian sports minister, Anika Wells, has praised Cricket Australia for boycotting international matches against Afghanistan in response to the Taliban’s “unacceptable” treatment of women and girls.</p><p>Australia were scheduled to play three one-day internationals against Afghanistan on neutral ground in the United Arab Emirates (UAE) in March, but after talks with the Australian government <a href="https://www.theguardian.com/sport/2023/jan/12/cricket-australia-cancels-mens-one-day-internationals-against-afghanistan-due-to-concern-over-womens-rights">the series has been cancelled</a>.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/sport/2023/jan/13/australian-government-praises-national-cricket-team-boycott-of-afghanistan-matches">Continue reading...</a>

## Lisa Marie Presley, singer and daughter of Elvis, dies aged 54
 - [https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-singer-and-daughter-of-elvis-dies-aged-54](https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-singer-and-daughter-of-elvis-dies-aged-54)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 01:48:37+00:00
 - user: None

<p>Presley was rushed to hospital on Thursday night after suffering a suspected cardiac arrest</p><p>Lisa Marie Presley, singer and the only child of Elvis and Priscilla Presley, has died at the age of 54, after <a href="https://www.theguardian.com/music/2023/jan/12/elvis-daughter-lisa-marie-presley-hospital-cardiac-arrest">suddenly being hospitalised on Thursday</a>.</p><p>Her 77-year-old mother confirmed Presley’s death later on Thursday night.</p> <a href="https://www.theguardian.com/music/2023/jan/13/lisa-marie-presley-singer-and-daughter-of-elvis-dies-aged-54">Continue reading...</a>

## Russia-Ukraine war at a glance: what we know on day 324 of the invasion
 - [https://www.theguardian.com/world/2023/jan/13/russia-ukraine-war-at-a-glance-what-we-know-on-day-324-of-the-invasion](https://www.theguardian.com/world/2023/jan/13/russia-ukraine-war-at-a-glance-what-we-know-on-day-324-of-the-invasion)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 01:39:14+00:00
 - user: None

<p>Hundreds of civilians trapped in Soledar, says Ukriane; senior EU officials to meet Ukrainian counterparts next month</p><ul><li><strong><a href="https://www.theguardian.com/world/ukraine">See all our Russia-Ukraine war coverage</a></strong></li></ul> <a href="https://www.theguardian.com/world/2023/jan/13/russia-ukraine-war-at-a-glance-what-we-know-on-day-324-of-the-invasion">Continue reading...</a>

## Democratic lawmakers demand Biden revoke Bolsonaro’s visa after Brazil riot
 - [https://www.theguardian.com/world/2023/jan/12/bolsonaro-biden-democratic-lawmakers-revoke-visa-brazil-attack](https://www.theguardian.com/world/2023/jan/12/bolsonaro-biden-democratic-lawmakers-revoke-visa-brazil-attack)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 01:38:56+00:00
 - user: None

<p>Former president entered the US after his election loss and is staying in Florida</p><p>Dozens of Democratic lawmakers, including some of the top members of the House foreign affairs committee, <a href="https://mcusercontent.com/e711646c72c197262ff8d3d32/files/b95e998f-0dbd-be48-e682-9cb27375cebb/2023.1.11_BolsonaroJan8Attack_Final.pdf">sent a letter</a> to Joe Biden on Thursday demanding former Brazilian president Jair Bolsonaro’s diplomatic visa be canceled in the wake of the rampage in Brazil’s capital by his supporters.</p><p>“We request that you reassess his status in the country to ascertain whether there is a legal basis for his stay and revoke any such diplomatic visa he may hold,” said the letter. It continued: “The United States must not provide shelter for him, or any authoritarian who has inspired such violence against democratic institutions.”</p> <a href="https://www.theguardian.com/world/2023/jan/12/bolsonaro-biden-democratic-lawmakers-revoke-visa-brazil-attack">Continue reading...</a>

## Premier League: 10 things to look out for this weekend
 - [https://www.theguardian.com/football/2023/jan/13/premier-league-10-things-to-look-out-for-this-weekend](https://www.theguardian.com/football/2023/jan/13/premier-league-10-things-to-look-out-for-this-weekend)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 00:21:17+00:00
 - user: None

<p>Mitrovic returns for firing Fulham, Manchester United are flying into the derby and Coutinho looks finished at Villa</p><p>Manchester United’s resurgence since being <a href="https://www.theguardian.com/football/2022/oct/02/manchester-city-manchester-united-premier-league-match-report">trounced 6-3 by Manchester City</a> in October’s reverse fixture helps to set up the 189th derby as the most fascinating in recent years. Pep Guardiola’s champions have dropped four points from the last 12 while Erik ten Hag’s ever-improving side have claimed 27 from the last 30 available. Guardiola has recent form for questionable calls: he didn’t start Erling Haaland and Kevin De Bruyne in the <a href="https://www.theguardian.com/football/2023/jan/11/southampton-manchester-city-carabao-cup-quarter-final-match-report">Carabao Cup defeat at Southampton</a> on Wednesday and left it until too late to make changes when <a href="https://www.theguardian.com/football/2022/dec/31/manchester-city-everton-premier-league-match-report">drawing with Everton</a> lasat month. In Marcus Rashford – 15 goals in all competitions – United have the type of pacy forward that can expose City’s high line but City have a fine record of responding to mid-campaign dips. In true sat-on-the-fence fashion, the view here is that this local joust is incredibly difficult to call. <strong>Jamie Jackson</strong></p><p><em>Manchester United v Manchester City, Saturday 12.30pm (all times GMT)</em></p><p><em>Tottenham v Arsenal, Sunday 4.30pm</em></p> <a href="https://www.theguardian.com/football/2023/jan/13/premier-league-10-things-to-look-out-for-this-weekend">Continue reading...</a>

## Demonstrators protest NCAA’s transgender athlete inclusion
 - [https://www.theguardian.com/sport/2023/jan/12/demonstrators-protest-ncaa-estransgender-athlete-inclusion](https://www.theguardian.com/sport/2023/jan/12/demonstrators-protest-ncaa-estransgender-athlete-inclusion)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 00:17:49+00:00
 - user: None

<ul><li>Protesters convene outside NCAA convention in San Antonio</li><li>About two dozen demonstrators protest trans athlete inclusion</li></ul><p>Former Kentucky swimmer Riley Gaines and about two dozen demonstrators outside the NCAA convention Thursday protested the inclusion of transgender athletes in women’s sports and threatened the association with legal action if it doesn’t change its policies.</p><p>Gaines competed in last year’s NCAA swimming and diving championships against Penn’s Lia Thomas, who became first transgender woman to win a national title (<a href="https://www.theguardian.com/sport/2022/mar/17/lia-thomas-first-trans-woman-ncaa-swimming-championship">the women’s 500-yard freestyle</a>). She also placed fifth in the 200 freestyle, tying with Gaines.</p> <a href="https://www.theguardian.com/sport/2023/jan/12/demonstrators-protest-ncaa-estransgender-athlete-inclusion">Continue reading...</a>

## Time to branch out? Trees put lawns in the shade when it comes to tackling climate crisis
 - [https://www.theguardian.com/world/2023/jan/13/time-to-branch-out-trees-put-lawns-in-the-shade-when-it-comes-to-tackling-climate-crisis](https://www.theguardian.com/world/2023/jan/13/time-to-branch-out-trees-put-lawns-in-the-shade-when-it-comes-to-tackling-climate-crisis)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 00:15:42+00:00
 - user: None

<p>Traditional lawn has been under fire for years because of its lack of biodiversity and voracious appetite for fertiliser, herbicides and mowing</p><p>Dig up your “imperial” lawn and replant it with trees to combat the climate crisis, researchers have urged, after the latest study to lay bare the emissions cost of maintaining that pleasant, green patch.</p><p>If a third of the world’s city lawns were planted with trees, more than a gigatonne of carbon could be removed from the atmosphere over two decades, researchers from Auckland University of Technology found. The problem is not the grass itself, but the mowing, fertilisation and irrigation required.</p> <a href="https://www.theguardian.com/world/2023/jan/13/time-to-branch-out-trees-put-lawns-in-the-shade-when-it-comes-to-tackling-climate-crisis">Continue reading...</a>

## George Pell saw climate science as a dangerous religious dogma – in the end his hardline stance held the church back
 - [https://www.theguardian.com/australia-news/2023/jan/13/george-pell-saw-climate-science-as-a-dangerous-religious-dogma-in-the-end-his-hardline-stance-held-the-church-back](https://www.theguardian.com/australia-news/2023/jan/13/george-pell-saw-climate-science-as-a-dangerous-religious-dogma-in-the-end-his-hardline-stance-held-the-church-back)
 - RSS feed: https://www.theguardian.com/international/rss
 - date published: 2023-01-13 00:00:06+00:00
 - user: None

<p>Cardinal’s scepticism provided cover for the likes of Tony Abbott, who were able to justify denialism by invoking religious beliefs</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Follow our Australia news live blog for the latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The late Cardinal George Pell left a legacy of climate science denial which – in his later years – became ever more distanced from reality and the position of the Catholic church.</p><p>For decades in newspaper columns and speeches, Pell popularised climate denial talking points to dismiss the science of global heating and to brand environmentalists as hysterical and in the grip of a pseudo-religion.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/13/george-pell-saw-climate-science-as-a-dangerous-religious-dogma-in-the-end-his-hardline-stance-held-the-church-back">Continue reading...</a>
