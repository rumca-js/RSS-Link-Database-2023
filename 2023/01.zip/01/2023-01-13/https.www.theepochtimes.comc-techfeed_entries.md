# Source Epoch Times Tech, Source URL:https://www.theepochtimes.com/c-tech/feed/, Source language: en-US

## Mississippi Governor Bans TikTok From State Devices and Networks
 - [https://www.theepochtimes.com/mississippi-governor-bans-tiktok-from-state-devices-and-networks_4983170.html](https://www.theepochtimes.com/mississippi-governor-bans-tiktok-from-state-devices-and-networks_4983170.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-13 17:38:16+00:00
 - user: None

A symbol of TikTok (Douyin) is pictured at The Place shopping mall at dusk in Beijing, on Aug. 22, 2020. (VCG/VCG via Getty Images)

## Prominent Exchange and Token Issuer Crypto.com Slashing 20 Percent of Workforce
 - [https://www.theepochtimes.com/prominent-exchange-and-token-issuer-crypto-com-slashing-20-percent-of-workforce_4983661.html](https://www.theepochtimes.com/prominent-exchange-and-token-issuer-crypto-com-slashing-20-percent-of-workforce_4983661.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-13 17:31:54+00:00
 - user: None

Representations of virtual cryptocurrencies are placed on U.S. dollar banknotes in this illustration taken on Nov. 28, 2021. (Dado Ruvic/Reuters)

## Supreme Court’s Section 230 Case Could ‘Upend the Internet’: Google
 - [https://www.theepochtimes.com/supreme-courts-section-230-case-could-upend-the-internet-google-claims_4982129.html](https://www.theepochtimes.com/supreme-courts-section-230-case-could-upend-the-internet-google-claims_4982129.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-13 16:11:35+00:00
 - user: None

The Google logo at the entrance to the Google offices in London on Jan.18, 2019. (Hannah McKay/Reuters)
