# Source URL:https://www.tagesanzeiger.ch, Source language: en-US

## One in ten WEF attendees used private jet
 - [https://www.tagesanzeiger.ch/wef-2023-klimaschutz-privatjet-greenpeace-heuchelei-davos-259413788377](https://www.tagesanzeiger.ch/wef-2023-klimaschutz-privatjet-greenpeace-heuchelei-davos-259413788377)
 - RSS feed: https://www.tagesanzeiger.ch
 - date published: 2023-01-13 18:23:54+00:00
 - user: rumpel
 - tags: climate change,wef,davos

One in ten WEF attendees used private jet
