# Source URL:https://nextcloud.com, Source language: en-US

## Nextcloud
 - [https://nextcloud.com/install/](https://nextcloud.com/install/)
 - RSS feed: https://nextcloud.com
 - date published: 2023-01-13 10:08:29+00:00
 - user: rumpel
 - tags: digital bunker,nas,smarthome,local cloud,programming

Nextcloud
