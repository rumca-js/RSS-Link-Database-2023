# Source Daily Mail, Source URL:https://www.dailymail.co.uk/news/index.rss, Source language: en-US

## Texas high school football player DEFENDS coach who made team do 400 push-ups as punishment
 - [https://www.dailymail.co.uk/news/article-11633795/Texas-high-school-football-player-DEFENDS-coach-team-400-push-ups-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633795/Texas-high-school-football-player-DEFENDS-coach-team-400-push-ups-punishment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:42:03+00:00
 - user: None

A high school football player from Texas is backing his coach currently under investigation for allegedly making players perform up to 400 push-ups. The pushups were supposedly punishment.

## Boris Johnson plans a fresh trip to Kyiv to meet Ukrainian President Zelensky
 - [https://www.dailymail.co.uk/news/article-11634011/Boris-Johnson-plans-fresh-trip-Kyiv-meet-Ukrainian-President-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11634011/Boris-Johnson-plans-fresh-trip-Kyiv-meet-Ukrainian-President-Zelensky.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:33:41+00:00
 - user: None

The former prime minister is a hugely popular figure in the war-torn country, having travelled to Ukraine three times since the conflict began.

## Slick trio of thieves snatch $40,000 ring from right underneath Santa Clarita store owner's nose
 - [https://www.dailymail.co.uk/news/article-11633495/Slick-trio-thieves-snatch-40-000-ring-right-underneath-Santa-Clarita-store-owners-nose.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633495/Slick-trio-thieves-snatch-40-000-ring-right-underneath-Santa-Clarita-store-owners-nose.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:24:06+00:00
 - user: None

A trio of thieves snatched a $40,000 6-karat diamond ring right underneath the store owner's nose at a Southern California jewelry store - but not without being caught on the store's security cameras.

## Married Red Arrows commander abruptly leaves squadron after probe into affair with junior colleague
 - [https://www.dailymail.co.uk/news/article-11633969/Married-Red-Arrows-commander-abruptly-leaves-squadron-probe-affair-junior-colleague.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633969/Married-Red-Arrows-commander-abruptly-leaves-squadron-probe-affair-junior-colleague.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:20:05+00:00
 - user: None

David Montenegro (left), a married father of two, was recalled from a promotional tour of Gulf states in November after the Mail revealed the affair.

## Donald Trump called rape accuser E. Jean Carroll 'mentally sick' and a 'nut job'
 - [https://www.dailymail.co.uk/news/article-11633883/Donald-Trump-called-rape-accuser-E-Jean-Carroll-mentally-sick-nut-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633883/Donald-Trump-called-rape-accuser-E-Jean-Carroll-mentally-sick-nut-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:11:44+00:00
 - user: None

Ex-President Donald Trump called his rape accuser E. Jean Carroll 'mentally sick' and a 'nut job,' according to a newly unsealed deposition.

## Salim Mehajer could be freed from jail as soon as Wednesday as former Auburn deputy makes bail
 - [https://www.dailymail.co.uk/news/article-11633557/Salim-Mehajer-freed-jail-soon-Wednesday-former-Auburn-deputy-makes-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633557/Salim-Mehajer-freed-jail-soon-Wednesday-former-Auburn-deputy-makes-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:08:25+00:00
 - user: None

Mehajer has been held in custody for the last two years after he was found guilty of perverting the course of justice and making a false statement under oath in 2021.

## HALF of rail staff 'are crossing picket lines on strike days'
 - [https://www.dailymail.co.uk/news/article-11633695/HALF-rail-staff-crossing-picket-lines-strike-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633695/HALF-rail-staff-crossing-picket-lines-strike-days.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 23:05:08+00:00
 - user: None

Industry insiders claimed half of Network Rail staff turned up to work at 'dozens' of depots and signal boxes on the RMT's latest two strike days, on Friday and Saturday last week.

## Trevor Noah slams Britain again after claiming there was a racist backlash as Rishi Sunak became PM
 - [https://www.dailymail.co.uk/news/article-11633039/Trevor-Noah-slams-Britain-claiming-racist-backlash-Rishi-Sunak-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633039/Trevor-Noah-slams-Britain-claiming-racist-backlash-Rishi-Sunak-PM.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:52:48+00:00
 - user: None

After Rishi Sunak became prime minister in October 2022, Trevor Noah alleged that there were British people saying 'now the Indians are going to take over Great Britain'.

## Could a national sales tax supercharge the economy and raise your income by 10%?
 - [https://www.dailymail.co.uk/news/article-11633455/Could-national-sales-tax-supercharge-economy-raise-income-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633455/Could-national-sales-tax-supercharge-economy-raise-income-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:52:29+00:00
 - user: None

Critics say the GOP's Fair Tax Act would require phalanxes of new collectors in state capitals, hurt the middle classes, raise the deficit, and would never make it past a Democrat-led Senate.

## Volunteer NYC firefighter accuses department chief and co-worker of 'brutally raping' her
 - [https://www.dailymail.co.uk/news/article-11633533/Volunteer-NYC-firefighter-accuses-department-chief-worker-brutally-raping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633533/Volunteer-NYC-firefighter-accuses-department-chief-worker-brutally-raping-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:26:00+00:00
 - user: None

A New York volunteer firefighter has claimed that she was 'plied with alcohol' and 'violently raped' by a former Wantagh Fire Department chief and her colleague in their firehouse.

## Scott Mills drops Radio 2 classics from 60s and 70s in favour of dance hits from the noughties
 - [https://www.dailymail.co.uk/news/article-11633783/Scott-Mills-drops-Radio-2-classics-60s-70s-favour-dance-hits-noughties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633783/Scott-Mills-drops-Radio-2-classics-60s-70s-favour-dance-hits-noughties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:19:05+00:00
 - user: None

Fans feared a change of tune when Steve Wright's afternoon show was axed from Radio 2. And it seems their concerns were well founded after Scott Mills replaced him.

## Todd and Julie Chrisley round up the family for a farewell meal before they report to prison
 - [https://www.dailymail.co.uk/news/article-11633033/Todd-Julie-Chrisley-round-family-farewell-meal-report-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633033/Todd-Julie-Chrisley-round-family-farewell-meal-report-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:18:45+00:00
 - user: None

Todd, 53, and Julie Chrisley, 49, will report to prison on January 17 to serve their combined 19-year sentence for tax evasion and fraud.

## Delphi murder suspect is seen hobbling down stairs as judge rules he WILL be tried in same county
 - [https://www.dailymail.co.uk/news/article-11633443/Delphi-murder-suspect-seen-hobbling-stairs-judge-rules-tried-county.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633443/Delphi-murder-suspect-seen-hobbling-stairs-judge-rules-tried-county.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:18:38+00:00
 - user: None

Jurors at the trial of an Indiana man accused of killing two teenage girls nearly six years ago will be selected from outside the county where the crime took place, a judge said Friday.

## Lisa Marie Presley's ex-husband Michael Lockwood is seen for the first time since her death
 - [https://www.dailymail.co.uk/news/article-11633597/Lisa-Marie-Presleys-ex-husband-Michael-Lockwood-seen-time-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633597/Lisa-Marie-Presleys-ex-husband-Michael-Lockwood-seen-time-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:09:53+00:00
 - user: None

Lisa Marie Presley 's fourth husband Michael Lockwood was seen Friday for the first time since his ex-wife's death, after it was revealed he is taking care of the couple's twin daughters.

## Are MPs freebie trips courtesy of Westminster groups -  many funded by lobbyists - the next scandal?
 - [https://www.dailymail.co.uk/news/article-11633289/Are-MPs-freebie-trips-courtesy-Westminster-groups-funded-lobbyists-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633289/Are-MPs-freebie-trips-courtesy-Westminster-groups-funded-lobbyists-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:09:48+00:00
 - user: None

In the past month there have been disquieting reports of allegations relating to MPs belonging to an All-Party Parliamentary Group (APPG) seeking directions to brothels overseas.

## RICHARD PENDLEBURY returns to Kyiv where life has utterly changed but spirits remain unbroken
 - [https://www.dailymail.co.uk/news/article-11633601/RICHARD-PENDLEBURY-returns-Kyiv-life-utterly-changed-spirits-remain-unbroken.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633601/RICHARD-PENDLEBURY-returns-Kyiv-life-utterly-changed-spirits-remain-unbroken.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:09:30+00:00
 - user: None

The lives of Ukrainians in Kyiv have drastically changed following Russia's launch of cruise missiles and 'suicide' drones from October. Yet festive spirits remained unbroken in the city.

## Talk about recollections may vary! Harry and Meghan's 'truth' doesn't always match everyone else's
 - [https://www.dailymail.co.uk/news/article-11633705/Talk-recollections-vary-Harry-Meghans-truth-doesnt-match-elses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633705/Talk-recollections-vary-Harry-Meghans-truth-doesnt-match-elses.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:06:30+00:00
 - user: None

Prince Harry's memoir Spare has become the most talked about and controversial book in publishing history. But how reliable are its sometimes shocking claims?

## Popular National Trust cafe just five yards away from falling into the sea
 - [https://www.dailymail.co.uk/news/article-11633731/Popular-National-Trust-cafe-just-five-yards-away-falling-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633731/Popular-National-Trust-cafe-just-five-yards-away-falling-sea.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:04:35+00:00
 - user: None

For years, this charming clifftop cafe has refreshed the walkers and daytrippers at Birling Gap. Now the National Trust is planning to move and rebuild the much-loved eatery.

## Rep. Jim Jordan opens investigation into Merrick Garland's process to choose a Special Counsel
 - [https://www.dailymail.co.uk/news/article-11633403/Rep-Jim-Jordan-opens-investigation-Merrick-Garlands-process-choose-Special-Counsel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633403/Rep-Jim-Jordan-opens-investigation-Merrick-Garlands-process-choose-Special-Counsel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:04:06+00:00
 - user: None

House Judiciary Committee Chairman Jim Jordan is demanding AG Merrick Garland turn over information about the decision to appoint Robert Hur as special counsel.

## Former Labour MP Simon Danczuk frolics in hotel swimming pool with his 28-year-old Rwandan fiancee
 - [https://www.dailymail.co.uk/news/article-11633669/Former-Labour-MP-Simon-Danczuk-frolics-hotel-swimming-pool-28-year-old-Rwandan-fiancee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633669/Former-Labour-MP-Simon-Danczuk-frolics-hotel-swimming-pool-28-year-old-Rwandan-fiancee.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 22:02:05+00:00
 - user: None

He may be almost 30 years her senior but former Labour MP Simon Danczuk was caught looking like a love-struck teenager frolicking in a hotel swimming pool with his new bride-to-be.

## Supreme Court investigators are zeroed in on 'small number' of possible leakers of Roe v. Wade draft
 - [https://www.dailymail.co.uk/news/article-11633501/Supreme-Court-investigators-zeroed-small-number-possible-leakers-Roe-v-Wade-draft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633501/Supreme-Court-investigators-zeroed-small-number-possible-leakers-Roe-v-Wade-draft.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:59:42+00:00
 - user: None

Supreme Court investigators probing the May leak of the draft opinion to overturn Roe v. Wade are reportedly narrowing in on a short list of possible suspects.

## What Australians can expect to pay for airline tickets after the expensive Christmas peak
 - [https://www.dailymail.co.uk/news/article-11631575/What-Australians-expect-pay-airline-tickets-expensive-Christmas-peak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631575/What-Australians-expect-pay-airline-tickets-expensive-Christmas-peak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:52:06+00:00
 - user: None

Australia's Bureau of Infrastructure and Transport Research Economics (BITRE) shows an increase in discounted flights offered to Australians in January.

## Pictured: Mother, 24, charged over the death of her two-year-old daughter appears in court
 - [https://www.dailymail.co.uk/news/article-11633189/Pictured-Mother-24-charged-death-two-year-old-daughter-appears-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633189/Pictured-Mother-24-charged-death-two-year-old-daughter-appears-court.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:49:27+00:00
 - user: None

Dana Carr, 24, appeared at Teesside Crown Court charged with allowing death of a child and a charge of child cruelty. Michael Draymond, 26, is accused of murdering Maya Chappell.

## Missing Athena Brownfield's caregiver enjoyed romantic weekend with boyfriend AFTER she vanished
 - [https://www.dailymail.co.uk/news/article-11633089/Missing-Athena-Brownfields-caregiver-enjoyed-romantic-weekend-boyfriend-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633089/Missing-Athena-Brownfields-caregiver-enjoyed-romantic-weekend-boyfriend-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:42:05+00:00
 - user: None

Athena was reported missing on Tuesday January 10 when a postal worker found her older sister wandering the streets near their home in Cyril, Oklahoma.

## Boy who disappeared after watching Chales and Diana's wedding 'may have been murdered by paedophile'
 - [https://www.dailymail.co.uk/news/article-11633007/Boy-disappeared-watching-Chales-Dianas-wedding-murdered-paedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633007/Boy-disappeared-watching-Chales-Dianas-wedding-murdered-paedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:38:12+00:00
 - user: None

A new documentary, In the Footsteps of Killers, has revealed new information surrounding the 1981 disappearance of schoolboy Vishal Mehrotra, with connections to a gang leader.

## Boyfriend of missing Alice Springs woman Angie Fuller clashes with cop searching his car
 - [https://www.dailymail.co.uk/news/article-11631921/Boyfriend-missing-Alice-Springs-woman-Angie-Fuller-clashes-cop-searching-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631921/Boyfriend-missing-Alice-Springs-woman-Angie-Fuller-clashes-cop-searching-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:35:39+00:00
 - user: None

Angie Fuller, 30, from Alice Springs, was last seen on Tanami Road, 15 kilometres west of the intersection at Stuart Highway in the Northern Territory on Monday.

## Biden's press secretary says 'we're not avoiding anything here' about classified files scandal
 - [https://www.dailymail.co.uk/news/article-11633367/Bidens-press-secretary-says-not-avoiding-classified-files-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633367/Bidens-press-secretary-says-not-avoiding-classified-files-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:31:43+00:00
 - user: None

'I've been in here almost every day since we got back from Mexico City ... standing here taking your questions at length, so that we're not avoiding anything here,' said Karine Jean-Pierre on Friday.

## Family who kept mummified daughter in home for six weeks were 'convinced she was still alive'
 - [https://www.dailymail.co.uk/news/article-11632751/Family-kept-mummified-daughter-home-six-weeks-convinced-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632751/Family-kept-mummified-daughter-home-six-weeks-convinced-alive.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:30:34+00:00
 - user: None

A mysterious diary was found in the home of talented artist Rina Yasutake which revealed 'she became unresponsive on August 18', 2018.

## Teen who killed woman, 64, walking to Manhattan supermarket fled the US to Dominican Republic
 - [https://www.dailymail.co.uk/news/article-11633343/Teen-killed-woman-64-walking-Manhattan-supermarket-fled-Dominican-Republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633343/Teen-killed-woman-64-walking-Manhattan-supermarket-fled-Dominican-Republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:22:42+00:00
 - user: None

New York authorities have launched an international manhunt for a 17-year-old Manuel Ramos who shot and killed Valeria Ortega, a mother-of-three, in Manhattan last month.

## Lisa Marie Presley was planning to host podcast on grief with author David Kessler
 - [https://www.dailymail.co.uk/news/article-11633319/Lisa-Marie-Presley-planning-host-podcast-grief-author-David-Kessler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633319/Lisa-Marie-Presley-planning-host-podcast-grief-author-David-Kessler.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:22:09+00:00
 - user: None

Lisa Marie Presley hoped to start a grief podcast with expert David Kessler, who had helped her after her son, Benjamin Keough, 27, shot himself in 2020. Kessler said Lisa Marie wanted to help others.

## 'Prince William has made it very clear that his children are not Harry's responsibility'
 - [https://www.dailymail.co.uk/news/article-11633493/Prince-William-clear-children-not-Harrys-responsibility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633493/Prince-William-clear-children-not-Harrys-responsibility.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:10:55+00:00
 - user: None

Prince Harry has expressed his worry for other 'spares' in the family, despite his brother making it clear that his children are not Harry's responsibility.

## Amy Robach and Andrew Shue seen together to hand over Maltipoo Brody
 - [https://www.dailymail.co.uk/news/article-11632957/Amy-Robach-Andrew-Shue-seen-hand-Maltipoo-Brody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632957/Amy-Robach-Andrew-Shue-seen-hand-Maltipoo-Brody.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:10:15+00:00
 - user: None

The soon-to-be exes reunited at a park in Greenwich Village Friday morning to hand over custody of their family Maltipoo Brody, whom they  shared during happier times as a married couple.

## Prince Harry wishes William 'would be able to feel the same benefits of therapy'
 - [https://www.dailymail.co.uk/news/article-11633431/Prince-Harry-wishes-William-able-feel-benefits-therapy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633431/Prince-Harry-wishes-William-able-feel-benefits-therapy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:02:28+00:00
 - user: None

Harry has spoken openly in his memoir and the subsequent media rounds that he used ayahuasca, a psychedelic, with a professional during his treatment.

## Female athletes DEMAND NCAA stop letting biological men compete in women's college sports
 - [https://www.dailymail.co.uk/news/article-11633255/Female-athletes-DEMAND-NCAA-stop-letting-biological-men-compete-womens-college-sports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633255/Female-athletes-DEMAND-NCAA-stop-letting-biological-men-compete-womens-college-sports.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 21:02:05+00:00
 - user: None

The group protested outside the NCAA's San Antonio convention on Thursday and hand-delivered a letter threatening legal action.

## Mega Millions $1.35 BILLION jackpot: Friday the 13th could be someone's luckiest day
 - [https://www.dailymail.co.uk/news/article-11632579/Mega-Millions-1-35-BILLION-jackpot-Friday-13th-someones-luckiest-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632579/Mega-Millions-1-35-BILLION-jackpot-Friday-13th-someones-luckiest-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:16:15+00:00
 - user: None

After 25 drawings without a winner, the Mega Millions jackpot is now the fourth-largest in U.S. history - but the amount you take home could vary by as much as $147million.

## Dallas zoo shuts down after LOSING clouded leopard
 - [https://www.dailymail.co.uk/news/article-11633271/Dallas-zoo-shuts-LOSING-clouded-leopard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633271/Dallas-zoo-shuts-LOSING-clouded-leopard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:08:11+00:00
 - user: None

A missing clouded leopard shut down the Dallas Zoo on Friday as police helped search for the animal that officials described as not dangerous and likely hiding somewhere on the zoo grounds.

## Andy Dick arrested for public intoxication and failing to register as a sex offender
 - [https://www.dailymail.co.uk/news/article-11633327/Andy-Dick-arrested-public-intoxication-failing-register-sex-offender.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633327/Andy-Dick-arrested-public-intoxication-failing-register-sex-offender.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:06:13+00:00
 - user: None

Disgraced comedian Andy Dick was arrested Friday for public intoxication and failing to register as a sex offender stemming from his 2018 arrest for grabbing an Uber driver's crotch.

## Husband of Tennessee cop-gone-wild Maegan Hall sticks by his wife
 - [https://www.dailymail.co.uk/news/article-11632291/Husband-Tennessee-cop-gone-wild-Maegan-Hall-sticks-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632291/Husband-Tennessee-cop-gone-wild-Maegan-Hall-sticks-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:04:54+00:00
 - user: None

DailyMail.com can reveal Jedidiah Hall, 28, is standing by wife Maegan, 26, after the La Vergne police officer was fired for engaging in sexual relationships with multiple cops.

## Three Salvadoran sisters are found stranded alone on an islet on Rio Grande at U.S. Mexico border
 - [https://www.dailymail.co.uk/news/article-11632637/Three-Salvadoran-sisters-stranded-islet-Rio-Grande-U-S-Mexico-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632637/Three-Salvadoran-sisters-stranded-islet-Rio-Grande-U-S-Mexico-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:00:45+00:00
 - user: None

Three sisters from El Salvador were found alone  on Rio Grande islet at U.S. Mexico border Wednesday. The children were left there by smugglers.

## Idaho murder suspect Bryan Kohberger's ex-attorney shrugs off evidence used to arrest him
 - [https://www.dailymail.co.uk/news/article-11633149/Idaho-murder-suspect-Bryan-Kohbergers-ex-attorney-shrugs-evidence-used-arrest-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633149/Idaho-murder-suspect-Bryan-Kohbergers-ex-attorney-shrugs-evidence-used-arrest-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 20:00:41+00:00
 - user: None

University of Idaho murder suspect Bryan Kohberger's ex-attorney said while there is 'strong circumstantial evidence,' viewed individually, it could be easily attacked.

## Hero veteran takes down a knife-wielding man in a South Carolina Walmart by smacking him with a pole
 - [https://www.dailymail.co.uk/news/article-11632949/Hero-veteran-takes-knife-wielding-man-South-Carolina-Walmart-smacking-pole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632949/Hero-veteran-takes-knife-wielding-man-South-Carolina-Walmart-smacking-pole.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:30:51+00:00
 - user: None

Shocking video shows the unidentified man in red hoodie waving a knife and shouting at Walmart in Columbia, South Carolina, demanding $20 before Demario Davis struck him with a pole.

## Philadelphia's 'Boy in the Box' FINALLY gets a headstone engraved with his name
 - [https://www.dailymail.co.uk/news/article-11633067/Philadelphias-Boy-Box-FINALLY-gets-headstone-engraved-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633067/Philadelphias-Boy-Box-FINALLY-gets-headstone-engraved-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:20:29+00:00
 - user: None

Joseph Augustus Zarelli, previously only known as Philadelphia's 'Boy in the Box,' got a proper headstone on Friday, on what would have been his 70th birthday.

## Biden accepts GOP Speaker Kevin McCarthy's State of the Union invitation on February 7
 - [https://www.dailymail.co.uk/news/article-11633165/Biden-accepts-GOP-Speaker-Kevin-McCarthys-State-Union-invitation-February-7.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633165/Biden-accepts-GOP-Speaker-Kevin-McCarthys-State-Union-invitation-February-7.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:16:45+00:00
 - user: None

President Biden will deliver a State of the Union address before Congress on February 7th after accepting an invite from Speaker Kevin McCarthy.

## Teenager, 17, accidentally pocket dials 911 while playing tactical shooter video game
 - [https://www.dailymail.co.uk/news/article-11632919/Teenager-17-accidentally-pocket-dials-911-playing-tactical-shooter-video-game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632919/Teenager-17-accidentally-pocket-dials-911-playing-tactical-shooter-video-game.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:14:15+00:00
 - user: None

Armed officers in Kentucky responded to a 911 call of a 17-year-old - who admitted to killing two people - only to find the call was an 'accidental butt dial' while he'd been playing a video game.

## How billionaire Nelson Peltz favors profits over politics in business as he vies for Disney seat
 - [https://www.dailymail.co.uk/news/article-11632393/How-billionaire-Nelson-Peltz-favors-profits-politics-business-vies-Disney-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632393/How-billionaire-Nelson-Peltz-favors-profits-politics-business-vies-Disney-seat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:08:28+00:00
 - user: None

Peltz, 80, previously went after Unilever, the consumer goods company that owns Ben & Jerry's for making too political a statement by refusing to sell ice cream in Palestine. Unilever's shares rose.

## Amy Robach and TJ Holmes 'have other alternatives' if they do not return to GMA
 - [https://www.dailymail.co.uk/news/article-11632895/Amy-Robach-TJ-Holmes-alternatives-not-return-GMA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632895/Amy-Robach-TJ-Holmes-alternatives-not-return-GMA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 19:07:18+00:00
 - user: None

The pair were taken off the air temporarily after executives at the network became aware of their relationship - which was exclusively revealed by DailyMail.com.

## Nearly 6,000 complaints about damp and mould were made to ombudsman following death of Awaab Ishak
 - [https://www.dailymail.co.uk/news/article-11633017/Nearly-6-000-complaints-damp-mould-ombudsman-following-death-Awaab-Ishak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633017/Nearly-6-000-complaints-damp-mould-ombudsman-following-death-Awaab-Ishak.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:41:04+00:00
 - user: None

Thousands of complaints about leaks, damp and mould experienced at England's social housing have flooded in following the death of Awaab Ishak, new figures reveal.

## Woman whose body was found at her flat may have been lying dead for months
 - [https://www.dailymail.co.uk/news/article-11633139/Woman-body-flat-lying-dead-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633139/Woman-body-flat-lying-dead-months.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:32:18+00:00
 - user: None

The victim - who was named locally as Caroline McCrossan and was in her 60's - had complained of 'torrents of water' flooding into her home from the flat upstairs dating back to March last year.

## Prince Harry says he has 'enough for another book' and had to cut his tell-all memoir 'in HALF'
 - [https://www.dailymail.co.uk/news/article-11633087/Prince-Harry-says-book-cut-tell-memoir-HALF.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11633087/Prince-Harry-says-book-cut-tell-memoir-HALF.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:17:15+00:00
 - user: None

Prince Harry has revealed he has enough material to publish a second memoir and cut almost half of the material he'd written in a first draft.

## Vile moment animal rights activist launches foul-mouthed tirade at woman she saw fishing by a lake
 - [https://www.dailymail.co.uk/news/article-11632733/Vile-moment-animal-rights-activist-launches-foul-mouthed-tirade-woman-saw-fishing-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632733/Vile-moment-animal-rights-activist-launches-foul-mouthed-tirade-woman-saw-fishing-lake.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:09:16+00:00
 - user: None

Elsa Joan (pictured), 24 had spent a day fishing on January 8 at Brooklands Lake in her hometown of Dartford, Kent, and was shocked when an enraged woman verbally attacked her for two minutes.

## Biden ignores questions again on classified documents
 - [https://www.dailymail.co.uk/news/article-11632993/Biden-ignores-questions-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632993/Biden-ignores-questions-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:08:48+00:00
 - user: None

Biden ignored a question on why he didn't disclose sooner that he had classified documents in his personal possession as he welcomed Japanese Prime Minister Kishida Fumio to the White House.

## U.S. will reach the debt limit on January 19, Treasury Secretary Janet Yellen warns Congress
 - [https://www.dailymail.co.uk/news/article-11632977/U-S-reach-debt-limit-January-19-Treasury-Secretary-Janet-Yellen-warns-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632977/U-S-reach-debt-limit-January-19-Treasury-Secretary-Janet-Yellen-warns-Congress.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:07:04+00:00
 - user: None

Congress and the White House are on track for a major clash this summer, with the nation set to hit the debt limit January 19th, and 'extraordinary measures' that will last just months.

## Winklevoss twins-owned Gemini and Genesis charged with selling unregistered securities
 - [https://www.dailymail.co.uk/news/article-11632467/Winklevoss-twins-owned-Gemini-Genesis-charged-selling-unregistered-securities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632467/Winklevoss-twins-owned-Gemini-Genesis-charged-selling-unregistered-securities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:02:42+00:00
 - user: None

The Securities and Exchanged Commission accused Gemini and Genesis of offering unregistered securities to hundreds of thousands of investors through the Earn program.

## Biden tells Japanese prime minister that the US is completely committed to the defence of Japan
 - [https://www.dailymail.co.uk/news/article-11632791/Biden-tells-Japanese-prime-minister-completely-committed-defence-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632791/Biden-tells-Japanese-prime-minister-completely-committed-defence-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 18:02:16+00:00
 - user: None

U.S. President Joe Biden told Japanese Prime Minister Fumio Kishida that the United States strongly supports the defense of Japan as he welcomed him to the White House on Friday.

## Apple CEO Tim Cook slashes his OWN salary by 40% - down to $49 million
 - [https://www.dailymail.co.uk/news/article-11632995/Apple-CEO-Tim-Cook-slashes-salary-40-49-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632995/Apple-CEO-Tim-Cook-slashes-salary-40-49-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:58:32+00:00
 - user: None

Apple CEO Tim Cook will take a 40% pay cut this year from a year earlier as the company adjusts how it calculates his compensation partly based on a recommendation from Cook himself.

## F1 presenter Jennie Gow reveals she suffered 'serious stroke' which has affected her speech
 - [https://www.dailymail.co.uk/news/article-11632811/F1-presenter-Jennie-Gow-reveals-suffered-stroke-affected-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632811/F1-presenter-Jennie-Gow-reveals-suffered-stroke-affected-speech.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:57:08+00:00
 - user: None

Jennie Gow, 45, said she suffered the stroke two weeks ago which has affected her speech. The broadcaster thanked medical staff at hospitals in Surrey and London for taking care of her.

## Tory councillor gave details on Britain and Nato Communist Czech spies during Cold War
 - [https://www.dailymail.co.uk/news/article-11632853/Tory-councillor-gave-details-Britain-Nato-Communist-Czech-spies-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632853/Tory-councillor-gave-details-Britain-Nato-Communist-Czech-spies-Cold-War.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:53:50+00:00
 - user: None

EXCLUSIVE: Dexter Smith, the Conservative leader for Slough Council, supplemented his salary in the Eighties by providing details about Nato, chemical weapons and 
missile defence.

## Bizarre moment cyclist is confronted by motorist who overtook him in heated row
 - [https://www.dailymail.co.uk/news/article-11632589/Bizarre-moment-cyclist-confronted-motorist-overtook-heated-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632589/Bizarre-moment-cyclist-confronted-motorist-overtook-heated-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:53:33+00:00
 - user: None

The video posted to Twitter by a user called Northfield cyclist shows him travelling North on Spring Lane near the M24 in Solihull, south of Birmingham.

## Anti-Jewish sentiment has DOUBLED since 2019, as politicos, celebs and athletes under fire
 - [https://www.dailymail.co.uk/news/article-11632463/Anti-Jewish-sentiment-DOUBLED-2019-politicos-celebs-athletes-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632463/Anti-Jewish-sentiment-DOUBLED-2019-politicos-celebs-athletes-fire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:52:51+00:00
 - user: None

Kanye 'Ye' West, Whoopi Goldberg, Meyers Leonard, Ilhan Omar, and Donald Trump have all come under fire for allegedly making anti-Semitic remarks.

## Virginia school worker KNEW six-year-old who shot his teacher may have had a gun on him
 - [https://www.dailymail.co.uk/news/article-11632651/Virginia-school-worker-KNEW-six-year-old-shot-teacher-gun-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632651/Virginia-school-worker-KNEW-six-year-old-shot-teacher-gun-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:46:08+00:00
 - user: None

Newport News Public Schools Superintendent Dr. George Parker said at a town hall with parents Thursday that there had been a report the boy had the handgun with him.

## Army 'did not teach Harry to dehumanise the enemy'
 - [https://www.dailymail.co.uk/news/article-11632917/Army-did-NOT-teach-Harry-dehumanise-enemy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632917/Army-did-NOT-teach-Harry-dehumanise-enemy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:41:44+00:00
 - user: None

Prince Harry's claim the Army taught him to dehumanise the 25 Taliban he killed has been challenged by his Sandhurst classmates.

## Elvis Presley's Graceland saw its bonds DEFAULT after pandemic
 - [https://www.dailymail.co.uk/news/article-11632297/Elvis-Presleys-Graceland-saw-bonds-DEFAULT-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632297/Elvis-Presleys-Graceland-saw-bonds-DEFAULT-pandemic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:16:59+00:00
 - user: None

Elvis' home had $104millon issued for the expansion of the estate in Memphis, but the bonds issued by Memphis and Shelby Counties defaulted.

## New York City is on track to break 50-year record of most consecutive days with NO snow
 - [https://www.dailymail.co.uk/news/article-11632235/New-York-City-track-break-50-year-record-consecutive-days-NO-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632235/New-York-City-track-break-50-year-record-consecutive-days-NO-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:16:57+00:00
 - user: None

New York typically sees its first measurable snowfall by December 11, but according to forecasters the total number of days the Big Apple has been snowless is a staggering 307 days.

## Republicans demand to know if Hunter Biden was living at home where classified documents were found
 - [https://www.dailymail.co.uk/news/article-11632647/Republicans-demand-know-Hunter-Biden-living-home-classified-documents-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632647/Republicans-demand-know-Hunter-Biden-living-home-classified-documents-found.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:11:09+00:00
 - user: None

Republicans are demanding to know whether Hunter Biden was living at Biden's home and conducting 'international business deals' while there were classified files in the garage.

## Father tells how 15-year-old schoolgirl's lips turned blue as she lay dying after speedboat crash
 - [https://www.dailymail.co.uk/news/article-11632425/Schoolgirl-15-killed-horror-speedboat-crash-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632425/Schoolgirl-15-killed-horror-speedboat-crash-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 17:00:31+00:00
 - user: None

Highly experienced and qualified Michael Lawrence is accused of recklessly taking risks by performing daring stunts before he ploughed into the huge metal buoy at 36.6kts (42.2mph).

## R.I.P. Lisa Marie: MAUREEN CALLAHAN's searing portrait of a loner haunted by Graceland graveyard
 - [https://www.dailymail.co.uk/news/article-11632657/R-P-Lisa-Marie-MAUREEN-CALLAHANs-searing-portrait-loner-haunted-Graceland-graveyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632657/R-P-Lisa-Marie-MAUREEN-CALLAHANs-searing-portrait-loner-haunted-Graceland-graveyard.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:56:10+00:00
 - user: None

CALLAHAN: There was, by her own admission, a dark cloud that followed her. The Presley bloodline is a rough one, shot through with depression, mental illness, heart problems, addiction.

## Democrats peddled debunked 'Russian bot' conspiracy despite Twitter warnings
 - [https://www.dailymail.co.uk/news/article-11632547/Democrats-peddled-debunked-Russian-bot-conspiracy-despite-Twitter-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632547/Democrats-peddled-debunked-Russian-bot-conspiracy-despite-Twitter-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:55:03+00:00
 - user: None

The 14th installment of the Twitter Files released by journalist Matt Taibbi showed executives tried to warn senior Democrats about a debunked 'Russian bot' theory in 2018.

## Aristocrat, 53, brandished a 'family heirloom' machete 'to prove a point' at business meeting
 - [https://www.dailymail.co.uk/news/article-11632593/Aristocrat-53-brandished-family-heirloom-machete-prove-point-business-meeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632593/Aristocrat-53-brandished-family-heirloom-machete-prove-point-business-meeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:48:53+00:00
 - user: None

Romaine Colthurst, 53, took the blade to the meeting to 'prove a point' after losing a substantial amount of money, a court heard this week.

## British rape survivor who was abused by paedophile running coach takes her own life in Australia
 - [https://www.dailymail.co.uk/news/article-11632699/British-rape-survivor-abused-paedophile-running-coach-takes-life-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632699/British-rape-survivor-abused-paedophile-running-coach-takes-life-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:47:51+00:00
 - user: None

Katie was abused by coach Paul North, who was convicted of multiple counts of sexual assault and one count of rape in 2002 and jailed for ten years.

## George Ezra praises BRITs - despite females shut out of top gong following gender-neutral change
 - [https://www.dailymail.co.uk/tvshowbiz/article-11631767/George-Ezra-praises-BRITS-despite-females-shut-gong-following-gender-neutral-change.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11631767/George-Ezra-praises-BRITS-despite-females-shut-gong-following-gender-neutral-change.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:43:23+00:00
 - user: None

The singer, 29, who is nominated himself for the top gong, said  he believed that that  judges had done a 'great job of recognising' talent - despite no female being nominated for the prize.

## Spare: How the early days of Meghan and Prince Harry's romance unfolded
 - [https://www.dailymail.co.uk/femail/article-11631953/Spare-early-days-Meghan-Markle-Prince-Harrys-romance-unfolded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11631953/Spare-early-days-Meghan-Markle-Prince-Harrys-romance-unfolded.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:27:31+00:00
 - user: None

Prince Harry, who is now based in America, has opened up about the early days of his relationship with Meghan Markle in his bombshell memoir Spare.

## The three loyal Van Straubenzee brothers featured in Spare
 - [https://www.dailymail.co.uk/femail/article-11631149/The-three-loyal-Van-Straubenzee-brothers-featured-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11631149/The-three-loyal-Van-Straubenzee-brothers-featured-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:23:44+00:00
 - user: None

The three Van Straubenzee siblings were classmates of Prince William, 40, and the Duke of Sussex, 38, when at Ludgrove School together.

## Asylum seeker on trial for murdering aspiring Royal Marine is filmed punching man nine times in head
 - [https://www.dailymail.co.uk/news/article-11632335/Asylum-seeker-trial-murdering-aspiring-Royal-Marine-filmed-punching-man-nine-times-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632335/Asylum-seeker-trial-murdering-aspiring-Royal-Marine-filmed-punching-man-nine-times-head.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:21:09+00:00
 - user: None

Afghan Lawangeen Abdulrahimzai is accused of murdering aspiring Royal Marine Thomas Roberts, 21, outside a Subway sandwich shop in Bournemouth, Dorset on March 12, 2022.

## The TRUTH on statins: Are the cholesterol-busting pills safe?
 - [https://www.dailymail.co.uk/health/article-11631191/The-TRUTH-statins-cholesterol-busting-pills-safe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11631191/The-TRUTH-statins-cholesterol-busting-pills-safe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:20:54+00:00
 - user: None

Statins cost as little as 2p per pill and have been credited with saving millions of lives by preventing heart attacks and strokes but thousands have shunned the drugs over the side effects.

## More than half of Brits say Harry and Meghan should lose their royal titles
 - [https://www.dailymail.co.uk/news/article-11632205/More-half-Brits-say-Harry-Meghan-lose-royal-titles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632205/More-half-Brits-say-Harry-Meghan-lose-royal-titles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:19:22+00:00
 - user: None

EXCLUSIVE: As more errors in the memoirs emerge each day, one in four people who watched Harry's ITV interview with Tom Bradby last Sunday said they 'believed nothing' that he said.

## Biden staffers packing up files in his office were worried about TRUMP'S arrival
 - [https://www.dailymail.co.uk/news/article-11632261/Biden-staffers-packing-files-office-worried-TRUMPS-arrival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632261/Biden-staffers-packing-files-office-worried-TRUMPS-arrival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:16:19+00:00
 - user: None

Aides were packing up boxes of material from Joe Biden's vice presidential office during a 'weird time' in 2017, when many Democrats were stunned by Donald Trump's victory in the presidential election.

## Shocking moment Bandidos biker gang members killed motorcyclist for wearing rival 'colours'
 - [https://www.dailymail.co.uk/news/article-11632497/Shocking-moment-Bandidos-biker-gang-members-killed-motorcyclist-wearing-rival-colours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632497/Shocking-moment-Bandidos-biker-gang-members-killed-motorcyclist-wearing-rival-colours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:16:05+00:00
 - user: None

In dashcam footage, David Crawford, 59, is seen being knocked off his bike before being dragged hundreds of metres under a van and left for dead by the side of the A38 near Plymouth, Devon.

## The 'Flash' actor Ezra Miller avoids jail on trespassing charge
 - [https://www.dailymail.co.uk/news/article-11632591/The-Flash-actor-Ezra-Miller-Avoids-jail-trespassing-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632591/The-Flash-actor-Ezra-Miller-Avoids-jail-trespassing-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:15:50+00:00
 - user: None

American actor Ezra Miller, 30, has narrowly avoided jail time after accepting a plea deal in connection with a break in at a southern Vermont home in May last year.

## Queensland nurse Tori Dent opens up about learning to walk and talk again after brain lesion
 - [https://www.dailymail.co.uk/news/article-11631527/Queensland-nurse-Tori-Dent-opens-learning-walk-talk-brain-lesion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631527/Queensland-nurse-Tori-Dent-opens-learning-walk-talk-brain-lesion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:14:30+00:00
 - user: None

A Queensland woman, Tori Dent, was just 25 when she first experienced dizzy spells while holidaying on a cruise with friends in March 2020, signaling the start of a painful yet heroic fight for her life.

## What next for Benjamin Mendy's reputation and career after lurid sex trial?
 - [https://www.dailymail.co.uk/news/article-11626781/Mendy-backgrounder-assumes-not-guilty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11626781/Mendy-backgrounder-assumes-not-guilty.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:12:08+00:00
 - user: None

Benjamin Mendy had, over time, become more at ease around Chester Crown Court during a lengthy trial punctuated by delays that started during an August heatwave.

## AOC defends using a gas stove and mocks Republicans for their 'meltdown'
 - [https://www.dailymail.co.uk/news/article-11632475/AOC-defends-using-gas-stove-mocks-Republicans-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632475/AOC-defends-using-gas-stove-mocks-Republicans-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:09:58+00:00
 - user: None

Alexandria Ocasio-Cortez mocked Republicans on Thursday evening for their 'meltdown' over a report that President Joe Biden was considering banning gas stoves.

## Lineker say more 'brilliant minds' would run for office if MPs were paid more
 - [https://www.dailymail.co.uk/news/article-11631885/Lineker-say-brilliant-minds-run-office-MPs-paid-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631885/Lineker-say-brilliant-minds-run-office-MPs-paid-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:09:55+00:00
 - user: None

Lineker, the BBC's highest paid presenter who earned £1.35million last year, said a higher paycheck for politicians would entice people but added that the chances of that happening are slim.

## 60% of voters in George Santos' district want him to resign over his lies
 - [https://www.dailymail.co.uk/news/article-11632273/60-voters-George-Santos-district-want-resign-lies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632273/60-voters-George-Santos-district-want-resign-lies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 16:02:43+00:00
 - user: None

About a third of those who voted for Rep. George Santos in his Long Island district now want him to resign amid the piling lies, according to new polling.

## College student dies after falling from a balcony after she got locked out of her Cancún Airbnb
 - [https://www.dailymail.co.uk/news/article-11632239/College-student-dies-falling-balcony-got-locked-Canc-n-Airbnb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632239/College-student-dies-falling-balcony-got-locked-Canc-n-Airbnb.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:59:26+00:00
 - user: None

Nursing student Leah Pearse, of Massachusetts, suffered a deadly fall while attempting to scale up the balcony of her Cancún Airbnb rental on January 6.

## Top House Republican steps up his demand for answers on botched Afghanistan withdrawal
 - [https://www.dailymail.co.uk/news/article-11632195/Top-House-Republican-steps-demand-answers-botched-Afghanistan-withdrawal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632195/Top-House-Republican-steps-demand-answers-botched-Afghanistan-withdrawal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:47:51+00:00
 - user: None

The chairman of the House Foreign Affairs Committee on Thursday demanded answers from the Biden administration on the chaotic withdrawal from Afghanistan

## How Jeff Beck helped a woman land a job with Led Zeppelin after a chat at the pub
 - [https://www.dailymail.co.uk/news/article-11632107/How-Jeff-Beck-helped-woman-land-job-Led-Zeppelin-chat-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632107/How-Jeff-Beck-helped-woman-land-job-Led-Zeppelin-chat-pub.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:45:02+00:00
 - user: None

Unity MacLean, 75, recalls the moment guitar legend Jeff Beck helped her land a job with famed English rock band Led Zeppelin in 1975- thrusting her into a illustrious career for five years with the band.

## 'Possessive' woman, 27, who was 'obsessed' with her lover killed him after he messaged another girl
 - [https://www.dailymail.co.uk/news/article-11632303/Possessive-woman-27-obsessed-lover-killed-messaged-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632303/Possessive-woman-27-obsessed-lover-killed-messaged-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:29:43+00:00
 - user: None

Shaye Groves was 'obsessed' with lover Frankie Fitzgerald because of his 'performance in the bedroom', with the couple's sex life involving bondage and dominance.

## Artist who painted birthday portraits for King and Queen slammed for wrongly taking out £50k loans
 - [https://www.dailymail.co.uk/news/article-11632023/Artist-painted-birthday-portraits-King-Queen-slammed-wrongly-taking-50k-loans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632023/Artist-painted-birthday-portraits-King-Queen-slammed-wrongly-taking-50k-loans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:24:28+00:00
 - user: None

Darren Baker, of Meltham, West Yorkshire, wrongly received £45,000 from the Government's coronavirus Bounce Back Loan Scheme (BBLS) on behalf of The Leanne Baker Trust in October 2020.

## The Quantum Apocalypse is 'just YEARS away', experts say
 - [https://www.dailymail.co.uk/sciencetech/article-11628963/The-Quantum-Apocalypse-just-YEARS-away-experts-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11628963/The-Quantum-Apocalypse-just-YEARS-away-experts-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:19:46+00:00
 - user: None

Chinese experts are warning that quantum computing will reach a point where it is so powerful that it will make the encryptions that protect sensitive medical and bank details futile.

## Cardinal George Pell rumoured to have secret love child from years in Ballarat
 - [https://www.dailymail.co.uk/news/melbourne/article-11625573/Cardinal-George-Pell-rumoured-secret-love-child-years-Ballarat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/melbourne/article-11625573/Cardinal-George-Pell-rumoured-secret-love-child-years-Ballarat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:18:01+00:00
 - user: None

Cardinal George Pell was accused of bearing a child to a secret lover while living in his hometown in Country Victoria during the 1970s.

## Security guard who sent details of British officials to Russia claims he shouldn't be treated as spy
 - [https://www.dailymail.co.uk/news/article-11632253/Security-guard-sent-details-British-officials-Russia-claims-shouldnt-treated-spy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632253/Security-guard-sent-details-British-officials-Russia-claims-shouldnt-treated-spy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:17:45+00:00
 - user: None

David Smith (pictured), 58, sent details about British officials to a Russian military attaché and collected information 'useful to the Russian state' when he was working in Berlin.

## Pianist Jeremy So told 14-year-old schoolgirl 'I'm killing your childhood' after sex
 - [https://www.dailymail.co.uk/news/article-11629815/Pianist-Jeremy-told-14-year-old-schoolgirl-Im-killing-childhood-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629815/Pianist-Jeremy-told-14-year-old-schoolgirl-Im-killing-childhood-sex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:17:36+00:00
 - user: None

Jeremy So was 18 and studying at Sydney's prestigious Conservatorium of Music when he began a sexual relationship with a 14-year-old student at the high school next door.

## Outback Wrangler Matt Wright's extraordinary weekly pay packet
 - [https://www.dailymail.co.uk/news/article-11560185/Outback-Wrangler-Matt-Wrights-extraordinary-weekly-pay-packet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11560185/Outback-Wrangler-Matt-Wrights-extraordinary-weekly-pay-packet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:17:08+00:00
 - user: None

Matt Wright was hit with a string of charges in November over a chopper smash in the Northern Territory in February that resulted in the death of his co-star Chris Wilson. He runs a property empire.

## Does no one want to earn a crust? Greggs have to close recruitment centre due to lack of staff
 - [https://www.dailymail.co.uk/news/article-11632125/Does-no-one-want-earn-crust-Greggs-close-recruitment-centre-lack-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632125/Does-no-one-want-earn-crust-Greggs-close-recruitment-centre-lack-staff.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:11:16+00:00
 - user: None

The building in the City, on Cannon Street, was seen closed on Friday with a notice sellotaped to the window. It read: 'Closing early all this week due to staffing issues.'

## US Government is examining more than 500 reports of UFOs
 - [https://www.dailymail.co.uk/news/article-11631727/US-Government-examining-500-reports-UFOs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631727/US-Government-examining-500-reports-UFOs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:08:36+00:00
 - user: None

Last year the Pentagon opened the All-domain Anomaly Resolution Office, a department whose sole focus is to analyze reports of 'unidentified aerial phenomena' (UAPs)

## Homeowner is ordered to rip out £4,000 'high quality' gates he installed on luxury barn conversion
 - [https://www.dailymail.co.uk/property/article-11632059/Homeowner-ordered-rip-4-000-high-quality-gates-installed-luxury-barn-conversion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/property/article-11632059/Homeowner-ordered-rip-4-000-high-quality-gates-installed-luxury-barn-conversion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:01:57+00:00
 - user: None

Businessman David Holman, 53, installed the aluminium gates to replace the normal five-bar gate at his home  in Croesyceiliog, Monmouthshire.

## Billionaire investor Bill Ackman says Sam Bankman-Fried could be telling the TRUTH about FTX crash
 - [https://www.dailymail.co.uk/news/article-11632045/Billionaire-investor-Bill-Ackman-says-Sam-Bankman-Fried-telling-TRUTH-FTX-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632045/Billionaire-investor-Bill-Ackman-says-Sam-Bankman-Fried-telling-TRUTH-FTX-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:00:40+00:00
 - user: None

Hedge fund billionaire Bill Ackman, 56, suggested FTX founder Sam Bankman-Fried might be telling the truth as he pleads innocent to eight criminal fraud charges over his crypto exchange.

## Nigerian senator's daughter denies trafficking homeless man into the UK to harvest his kidney
 - [https://www.dailymail.co.uk/news/article-11632281/Nigerian-senators-daughter-denies-trafficking-homeless-man-UK-harvest-kidney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632281/Nigerian-senators-daughter-denies-trafficking-homeless-man-UK-harvest-kidney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 15:00:33+00:00
 - user: None

Sonia Ekweremadu, 25, is charged alongside her father Ike Ekweremadu, of trafficking a homeless man to the UK to harvest his kidney and treating him 'as a slave'. They deny the charges.

## Aussie driver is ran off the road after not letting another car merge, Dashcam video
 - [https://www.dailymail.co.uk/news/article-11631855/Aussie-driver-ran-road-not-letting-car-merge-Dashcam-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631855/Aussie-driver-ran-road-not-letting-car-merge-Dashcam-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:57:31+00:00
 - user: None

In Dashcam footage shared online, a silver Toyota RAV4 is seen speeding up while a white Ford Territory tries to merge into its lane on an Australian road on Wednesday afternoon.

## Prince Harry takes MORE swipes at Camilla in bombshell book
 - [https://www.dailymail.co.uk/femail/article-11631569/Prince-Harry-takes-swipes-Camilla-bombshell-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11631569/Prince-Harry-takes-swipes-Camilla-bombshell-book.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:54:58+00:00
 - user: None

Here FEMAIL reveals the multiple swipes Prince Harry takes at his stepmother in Spare - from dismissing Meghan's concern over her public image to suggesting a Bermuda move.

## How rife is Covid in YOUR area? Interactive map reveals up to one in 14 people were infected
 - [https://www.dailymail.co.uk/health/article-11631815/How-rife-Covid-area-Interactive-map-reveals-one-14-people-infected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11631815/How-rife-Covid-area-Interactive-map-reveals-one-14-people-infected.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:53:21+00:00
 - user: None

Around 2.2million people, or one in 25 people, were infected with the virus in England in the week to January 3, according to figures from the Office for National Statistics (ONS).

## How holes in Biden's story pushed Merrick Garland to appoint a Special Counsel
 - [https://www.dailymail.co.uk/news/article-11631935/How-holes-Bidens-story-pushed-Merrick-Garland-appoint-Special-Counsel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631935/How-holes-Bidens-story-pushed-Merrick-Garland-appoint-Special-Counsel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:38:42+00:00
 - user: None

Gaps in Joe Biden's story about classified documents contributed to special counsel - a decision Merrick Garland made before he went to Mexico and sat beside Biden during questioning.

## Vigilante who killed robber in Houston restaurant breaks silence
 - [https://www.dailymail.co.uk/news/article-11632047/Vigilante-killed-robber-Houston-restaurant-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632047/Vigilante-killed-robber-Houston-restaurant-breaks-silence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:34:41+00:00
 - user: None

A lawyer for a customer who shot and killed a robber in a Houston taqueria last week said his actions were justified because he was 'in fear of his life.'

## The seedy underbelly of the Premier League sex parties
 - [https://www.dailymail.co.uk/news/article-11622957/The-seedy-underbelly-Premier-League-sex-parties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11622957/The-seedy-underbelly-Premier-League-sex-parties.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:30:11+00:00
 - user: None

Six months of court hearings in Chester revealed a sleazy jungle where women are 'procured' by nightclub promoters.

## Sydney chef Fatimah Omran defends calling Cheer cheese by former name of Coon in TikTok
 - [https://www.dailymail.co.uk/news/article-11631103/Sydney-chef-Fatimah-Omran-defends-calling-Cheer-cheese-former-Coon-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631103/Sydney-chef-Fatimah-Omran-defends-calling-Cheer-cheese-former-Coon-TikTok.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:25:03+00:00
 - user: None

Sydney chef Fatimah Omran, 42, received backlash online after using the controversial former name for Cheer cheese - Coon, in a TikTok shared this week.

## MCCAIN: Wokery, poverty, blackouts… it's time to take horror of 'President Newsom' deadly serious
 - [https://www.dailymail.co.uk/news/article-11628211/MCCAIN-Wokery-poverty-blackouts-time-horror-President-Newsom-deadly-serious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11628211/MCCAIN-Wokery-poverty-blackouts-time-horror-President-Newsom-deadly-serious.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 14:03:54+00:00
 - user: None

MCCAIN: It's time to take slick-haired, 90s action hero, Gavin Newsom dead serious, evaluate his record and ask ourselves: Do we want to 'California' America?

## British Airways plane's emergency slide opens on the runway as it prepares to take off at Heathrow
 - [https://www.dailymail.co.uk/news/article-11632085/British-Airways-planes-emergency-slide-opens-runway-prepares-Heathrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632085/British-Airways-planes-emergency-slide-opens-runway-prepares-Heathrow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:40:42+00:00
 - user: None

The inflatable slide extended from the plane as it was pushing back from the terminal to prepare for takeoff. Passengers were evacuated from the Boeing 777.

## Lioness hero and SPOTY winner Beth Mead reveals heartbreak after her mother dies of ovarian cancer
 - [https://www.dailymail.co.uk/news/article-11631991/Lioness-hero-SPOTY-winner-Beth-Mead-reveals-heartbreak-mother-dies-ovarian-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631991/Lioness-hero-SPOTY-winner-Beth-Mead-reveals-heartbreak-mother-dies-ovarian-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:40:36+00:00
 - user: None

June Mead was diagnosed with the illness in 2021 and endured a long battle with the disease.

## Mark Brown jailed for killing Alexandra Morgan and Leah Brown
 - [https://www.dailymail.co.uk/news/article-11631905/Psychopath-killer-Mark-Brown-jailed-49-years-killing-two-prostitutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631905/Psychopath-killer-Mark-Brown-jailed-49-years-killing-two-prostitutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:40:34+00:00
 - user: None

The builder was sentenced at Hove Crown Court for the murders of Leah Ware, 33, and Alexandra Morgan, 34, in Sussex in 2021.

## Girl, three, dies after getting shut inside a washing machine in Paris
 - [https://www.dailymail.co.uk/news/article-11632003/Girl-three-dies-getting-shut-inside-washing-machine-Paris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632003/Girl-three-dies-getting-shut-inside-washing-machine-Paris.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:39:18+00:00
 - user: None

An investigation into the cause of death began on Friday after the child was discovered in northeast Paris on Thursday night, Pictured; Washing machine (file photo)

## Top conservative group tells Kevin McCarthy to install MORE cameras in Congress
 - [https://www.dailymail.co.uk/news/article-11631933/Kevin-McCarthy-cameras-Congress-tea-party-letter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631933/Kevin-McCarthy-cameras-Congress-tea-party-letter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:39:08+00:00
 - user: None

'The result was transparency of a kind rarely witnessed in the Congress. It was a huge hit with the American public,' Tea Party Patriots' letter to Speaker McCarthy read.

## Lisa Marie Presley's ex-husband Michael Lockwood says he's 'very sad' at her death
 - [https://www.dailymail.co.uk/news/article-11632009/Lisa-Marie-Presleys-ex-husband-Michael-Lockwood-says-hes-sad-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11632009/Lisa-Marie-Presleys-ex-husband-Michael-Lockwood-says-hes-sad-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:38:35+00:00
 - user: None

Michael Lockwood, who split from the star in 2016, said that his world had been 'turned on its ear' and that he was with twins Finley and Harper Vivienne.

## The alarming figures that show how a generation of Brits will be locked out the housing market
 - [https://www.dailymail.co.uk/news/article-11631687/The-alarming-figures-generation-Brits-locked-housing-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631687/The-alarming-figures-generation-Brits-locked-housing-market.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:37:49+00:00
 - user: None

A stark report by Nationwide warns that the typical first-time buyer now spends almost two fifths of their income on their mortgage, close to levels last seen at the start of the financial crisis.

## Missing four-year-old Athena Brownfield's caretaker is arrested
 - [https://www.dailymail.co.uk/news/article-11631857/Missing-four-year-old-Athena-Brownfields-caretaker-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631857/Missing-four-year-old-Athena-Brownfields-caretaker-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:28:59+00:00
 - user: None

Alysia Adams, 30, and her husband are responsible for looking after the child. Athena was reported missing on Tuesday after her older sister was found wandering the streets of Cyril, Oklahoma.

## Homing show which attracts 15,000 pigeon fanciers a year will go ahead without any birds
 - [https://www.dailymail.co.uk/news/article-11631869/Homing-attracts-15-000-pigeon-fanciers-year-ahead-without-birds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631869/Homing-attracts-15-000-pigeon-fanciers-year-ahead-without-birds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:19:40+00:00
 - user: None

The annual show in Blackpool, Lancashire, will go ahead for its 51st year on January 21 and 22. In previous years, the event would display around 1,000 show pigeons and 2,000 racing pigeons.

## Jaycob Yarran sentenced to five years jail for putting toddler's hands in boiling water in Perth
 - [https://www.dailymail.co.uk/news/article-11631479/Jaycob-Yarran-sentenced-five-years-jail-putting-toddlers-hands-boiling-water-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631479/Jaycob-Yarran-sentenced-five-years-jail-putting-toddlers-hands-boiling-water-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 13:13:06+00:00
 - user: None

Perth man Jaycob Anfernee John Yarran, 25, plunged a two-year-old girl's hands into a pot of boiling water when he was supposed to be looking after her at a home in Maddington in 2019.

## Two dogs rescued from oven-like car outside Wet'n'Wild on Gold Coast
 - [https://www.dailymail.co.uk/news/article-11631167/Two-dogs-rescued-oven-like-car-outside-WetnWild-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631167/Two-dogs-rescued-oven-like-car-outside-WetnWild-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:53:58+00:00
 - user: None

Police were called to the carpark of the Gold Coast's amusement park at around 2pm on Wednesday - later learning the dogs had been stuck in the scorching hot car since that morning.

## Labour hands staff 10.5% cost-of-living pay hike as donations surge
 - [https://www.dailymail.co.uk/news/article-11631879/Labour-hands-staff-10-5-cost-living-pay-hike-donations-surge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631879/Labour-hands-staff-10-5-cost-living-pay-hike-donations-surge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:51:24+00:00
 - user: None

Labour is handing workers the huge bump after seeing a dramatic rise in donations - while taxpayer funding is due to soar by £700,000.

## Lisa Marie Presley's kids: Who are her children?
 - [https://www.dailymail.co.uk/news/article-11631425/Lisa-Marie-Presleys-kids-four-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631425/Lisa-Marie-Presleys-kids-four-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:51:22+00:00
 - user: None

The singer-songwriter daughter of Elvis Presley shared two children with her first husband Danny Keough, whom she married in 1988 and divorced in 1994.

## The New York Times 'whitewashed' story on Hunter Biden investigation
 - [https://www.dailymail.co.uk/news/article-11628385/The-New-York-Times-whitewashed-story-Hunter-Biden-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11628385/The-New-York-Times-whitewashed-story-Hunter-Biden-investigation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:47:55+00:00
 - user: None

The New York Times published a report Wednesday examining the investigation into Hunter Biden's foreign business dealings.

## Oxford professor apologises for 1996 email saying 'blacks are more stupid than whites'
 - [https://www.dailymail.co.uk/news/article-11631457/Oxford-professor-apologises-1996-email-saying-blacks-stupid-whites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631457/Oxford-professor-apologises-1996-email-saying-blacks-stupid-whites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:44:14+00:00
 - user: None

Nick Bostrom a Swedish-born philosopher wrote an email where he says: 'Blacks are more stupid than whites' following with 'I like that sentence and think it is true.'

## Manchester City star Benjamin Mendy, 28, is CLEARED of six counts of rape and sex assault
 - [https://www.dailymail.co.uk/news/article-11631665/Manchester-City-star-Benjamin-Mendy-28-CLEARED-six-counts-rape-sex-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631665/Manchester-City-star-Benjamin-Mendy-28-CLEARED-six-counts-rape-sex-assault.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:32:16+00:00
 - user: None

The footballer, 28, and his friend and 'fixer' Louis Saha Matturie, have been on trial at Chester Crown Court for five months.

## Kanye West marries Australian Bianca Censori
 - [https://www.dailymail.co.uk/news/article-11629217/Kanye-West-marries-Australian-Bianca-Censori.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629217/Kanye-West-marries-Australian-Bianca-Censori.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:22:52+00:00
 - user: None

Kanye West is a married man again just a few weeks after finally settling his bitter divorce from ex-wife Kim Kardashian.

## Keir Starmer tells Rishi Sunak to ignore Tory 'Brexit purity cult' blocking NI deal with the EU
 - [https://www.dailymail.co.uk/news/article-11631831/Keir-Starmer-tells-Rishi-Sunak-ignore-Tory-Brexit-purity-cult-blocking-NI-deal-EU.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631831/Keir-Starmer-tells-Rishi-Sunak-ignore-Tory-Brexit-purity-cult-blocking-NI-deal-EU.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:22:01+00:00
 - user: None

Speaking at Queen's University in Belfast, Sir Keir said it was time for Rishi Sunak to face down hardliners in the Tory European Research Group (ERG) if they try to block a deal.

## What a mug! On-the-run stalking suspect has cheek to moan about the hair-do on his police mugshot
 - [https://www.dailymail.co.uk/news/article-11631429/What-mug-run-stalking-suspect-cheek-moan-hair-police-mugshot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631429/What-mug-run-stalking-suspect-cheek-moan-hair-police-mugshot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:17:06+00:00
 - user: None

Bailey Gover is being hunted by Greater Manchester Police but has now begged officers to change his mugshot online after his messy hair was ruthlessly ridiculed by people on Facebook,

## NHS strikes: Steve Barclay 'admits medics deserve one-off cash boost'
 - [https://www.dailymail.co.uk/health/article-11631187/NHS-strikes-Steve-Barclay-admits-medics-deserve-one-cash-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11631187/NHS-strikes-Steve-Barclay-admits-medics-deserve-one-cash-boost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:13:37+00:00
 - user: None

Steve Barclay admitted the Government's 2022/23 deal - which amounted to roughly £1,400 for most medics - needs to be upped to avoid more walk-outs, according to Whitehall sources.

## Couple who hoped for a 'last holiday together' say Thai trip turned into 'holiday from hell'
 - [https://www.dailymail.co.uk/news/article-11631663/Couple-hoped-holiday-say-Thai-trip-turned-holiday-hell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631663/Couple-hoped-holiday-say-Thai-trip-turned-holiday-hell.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:11:23+00:00
 - user: None

Adam Debeers had booked the £3,200 two week holiday to Thailand alongside fiancée Grace Cwalinska. It quickly turned into a nightmare, first with the flight and then when they arrived.

## Brits say people with colds SHOULD be able to go to offices if they cannot WFH
 - [https://www.dailymail.co.uk/news/article-11631689/Brits-say-people-colds-able-offices-WFH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631689/Brits-say-people-colds-able-offices-WFH.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 12:04:40+00:00
 - user: None

Research for MailOnline found 52 per cent thought coughs and sniffles should not be a block on carrying out duties.

## Kanye West is 'MARRIED' to Bianca Censori months after Kim Kardashian divorce
 - [https://www.dailymail.co.uk/tvshowbiz/article-11631267/Kanye-West-marries-Yeezy-designer-two-months-Kim-Kardashian-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11631267/Kanye-West-marries-Yeezy-designer-two-months-Kim-Kardashian-divorce.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:59:07+00:00
 - user: None

The rapper, 45, is said to have held a private ceremony with Bianca and the pair have been spotted wearing wedding rings. Kanye was first pictured with a ring last week.

## Tesla slashes price of its electric cars by up to £9,100 with immediate effect
 - [https://www.dailymail.co.uk/money/electriccars/article-11631335/Tesla-slashes-price-electric-cars-9-100-immediate-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/electriccars/article-11631335/Tesla-slashes-price-electric-cars-9-100-immediate-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:57:12+00:00
 - user: None

The US firm announced it has cut the price of both the Model Y (main) and Model S (inset) as of today, citing 'normalisation of some of the cost of inflation'.

## Woman RAMS car in front, then gets out and screams at other female driver at Irish petrol station
 - [https://www.dailymail.co.uk/news/article-11631407/Woman-RAMS-car-gets-screams-female-driver-Irish-petrol-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631407/Woman-RAMS-car-gets-screams-female-driver-Irish-petrol-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:52:44+00:00
 - user: None

Video shows the woman driving her silver Toyota, at speed, into the back of the parked black Ford at the Applegreen petrol station in Duleek, Co. Meath.

## PICTURED: Connor Chapman charged with murdering Elle Edwards
 - [https://www.dailymail.co.uk/news/article-11631361/PICTURED-Connor-Chapman-charged-murdering-Elle-Edwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631361/PICTURED-Connor-Chapman-charged-murdering-Elle-Edwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:52:36+00:00
 - user: None

Connor Chapman, 22, arrived at Wirral Magistrates Court this morning in a prison van accompanied by unmarked police cars.

## Nick Adams boycotts M&M's after chocolate brand released female-only packet
 - [https://www.dailymail.co.uk/news/article-11630963/Nick-Adams-boycotts-M-Ms-chocolate-brand-released-female-packet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630963/Nick-Adams-boycotts-M-Ms-chocolate-brand-released-female-packet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:50:09+00:00
 - user: None

The Australian-born right-wing commentator, Nick Adams, declared his stance against parent company Mars  outside of M&amp;M's World in Times Square in New York  on Thursday.

## UK passport renewal changes: How much will prices increase by? When do changes come into effect?
 - [https://www.dailymail.co.uk/news/article-11631405/UK-passport-renewal-changes-prices-increase-changes-come-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631405/UK-passport-renewal-changes-prices-increase-changes-come-effect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:47:31+00:00
 - user: None

Announcing the proposals this week, the Home Office said there will be higher fees on all passport (pictured) applications and renewals. The changes will be introduced from next month.

## Children's magician is fined £400 after putting rubbish in council bin
 - [https://www.dailymail.co.uk/news/article-11630949/Childrens-magician-fined-400-putting-rubbish-council-bin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630949/Childrens-magician-fined-400-putting-rubbish-council-bin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:42:52+00:00
 - user: None

Olivia Post, from Battle, East Sussex, said she picked up the waste from bin bags that had been ripped open by foxes near her home.

## Tearful Bolsonaro fans queue outside ex-Brazilian president's Florida hideout to pray for his health
 - [https://www.dailymail.co.uk/news/article-11631329/Tearful-Bolsonaro-fans-queue-outside-ex-Brazilian-presidents-Florida-hideout-pray-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631329/Tearful-Bolsonaro-fans-queue-outside-ex-Brazilian-presidents-Florida-hideout-pray-health.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:42:28+00:00
 - user: None

Brazilians living across the US have since travelled to the sleepy Florida suburb of Kissimmee, lining up on the grass outside their idol's rental home and chanting prayers as well as slogans of support

## Bizarre moment man rips a windscreen wiper off a Mercedes in a 'road rage row over laundry'
 - [https://www.dailymail.co.uk/news/article-11631403/Bizarre-moment-man-rips-windscreen-wiper-Mercedes-road-rage-row-laundry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631403/Bizarre-moment-man-rips-windscreen-wiper-Mercedes-road-rage-row-laundry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:33:56+00:00
 - user: None

The fight escalated between two men in a Mercedes Estate and a pedestrian in Acton, West London, on January 11.

## Prince William and Kate Middleton pose for selfies with delighted fans during visit to Liverpool
 - [https://www.dailymail.co.uk/femail/article-11631331/Prince-William-Kate-Middleton-pose-selfies-delighted-fans-visit-Liverpool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11631331/Prince-William-Kate-Middleton-pose-selfies-delighted-fans-visit-Liverpool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:25:24+00:00
 - user: None

William and Kate, both 40, toured the new Royal Liverpool University Hospital and smiled, joked and posed for a large number of photos with NHS staff.

## A majority of Brits oppose unions' demands for double-digit pay hikes
 - [https://www.dailymail.co.uk/news/article-11627761/A-majority-Brits-oppose-unions-demands-double-digit-pay-hikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11627761/A-majority-Brits-oppose-unions-demands-double-digit-pay-hikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:07:27+00:00
 - user: None

A poll for Mailonline today reveals that while a majority (53 per cent) support unions' right to take strike action over pay in broad terms, that support falls away if their pay demand is too high.

## Haunting book reveals what became of Anne Frank after her family were dragged off by the Nazis
 - [https://www.dailymail.co.uk/news/article-11627817/Haunting-book-reveals-Anne-Frank-family-dragged-Nazis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11627817/Haunting-book-reveals-Anne-Frank-family-dragged-Nazis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:06:35+00:00
 - user: None

A brilliant new book, After The Annex: Anne Frank, Auschwitz and Beyond, pieces together the chilling final months of the Jewish teenager and her family.

## The best Love Island moments ever
 - [https://www.dailymail.co.uk/news/article-11631273/The-best-Love-Island-moments-ever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631273/The-best-Love-Island-moments-ever.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:05:21+00:00
 - user: None

Ahead of Monday night's launch on ITV2, we take a look back at Love Island's most explosive moments from the past eight seasons.

## Mother says mould in her home has left each of her three children needing inhalers
 - [https://www.dailymail.co.uk/news/article-11631339/Mother-says-mould-home-left-three-children-needing-inhalers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631339/Mother-says-mould-home-left-three-children-needing-inhalers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 11:00:35+00:00
 - user: None

Marzena Piatkowska has lived on Merlin Road, Scunthorpe, for three years, however, she noticed patches of black mould appearing on her walls in October last year.

## PICTURED: Man, 22, charged with murdering beautician Elle Edwards, 26
 - [https://www.dailymail.co.uk/news/article-11631361/PICTURED-Man-22-charged-murdering-beautician-Elle-Edwards-26.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631361/PICTURED-Man-22-charged-murdering-beautician-Elle-Edwards-26.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:54:45+00:00
 - user: None

Connor Chapman, 22, arrived at Wirral Magistrates Court this morning in a prison van accompanied by unmarked police cars.

## Lisa Marie death: Latest news after Elvis Presley's daughter dies from heart attack
 - [https://www.dailymail.co.uk/news/article-11631399/Lisa-Marie-death-Latest-news-Elvis-Presleys-daughter-dies-heart-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631399/Lisa-Marie-death-Latest-news-Elvis-Presleys-daughter-dies-heart-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:53:49+00:00
 - user: None

MAILONLINE LIVE BLOG: Follow all the latest tributes, stories and news after Lisa Marie Presley died aged 54.

## Man, 21, pleads guilty to throwing egg at King Charles during royal walkabout
 - [https://www.dailymail.co.uk/news/article-11631531/Man-21-pleads-guilty-throwing-egg-King-Charles-royal-walkabout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631531/Man-21-pleads-guilty-throwing-egg-King-Charles-royal-walkabout.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:52:06+00:00
 - user: None

Harry May, 21, has pleaded guilty at Westminster Magistrates' Court to throwing an egg towards the King during a walkabout in Luton in December.

## Third man, 18, is charged with murder over nightclub dancefloor stabbing of footballer Cody Fisher
 - [https://www.dailymail.co.uk/news/article-11631499/Third-man-18-charged-murder-nightclub-dancefloor-stabbing-footballer-Cody-Fisher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631499/Third-man-18-charged-murder-nightclub-dancefloor-stabbing-footballer-Cody-Fisher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:51:13+00:00
 - user: None

Reegan Anderson, 18, has become is the latest suspect to be charged by detectives over the murder of Mr Fisher, West Midlands Police said.

## The Elvis Presley 'curse' continues: Lisa Marie dead at 54
 - [https://www.dailymail.co.uk/news/article-11630995/The-Elvis-Presley-curse-continues-Lisa-Marie-dead-54.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630995/The-Elvis-Presley-curse-continues-Lisa-Marie-dead-54.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:39:36+00:00
 - user: None

Ms Presley, The King's only child and sole heir to his $100million estate, went into cardiac arrest at her LA home yesterday afternoon.

## Arsonist, 26, who torched 20 vehicles in shocking one-night fire spree is jailed for three years
 - [https://www.dailymail.co.uk/news/article-11631365/Arsonist-26-torched-20-vehicles-shocking-one-night-fire-spree-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631365/Arsonist-26-torched-20-vehicles-shocking-one-night-fire-spree-jailed-three-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:39:21+00:00
 - user: None

Daniel Cron, 26, was sentenced to three years in prison having pleaded guilty to 21 counts of arson - comprising 20 vehicles and a fence - at a previous hearing.

## Wife 'cuts off her trumpet-player husband's penis' and leaves knife in his eyeball in Argentina
 - [https://www.dailymail.co.uk/news/article-11631363/Wife-cuts-trumpet-player-husbands-penis-leaves-knife-eyeball-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631363/Wife-cuts-trumpet-player-husbands-penis-leaves-knife-eyeball-Argentina.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:38:55+00:00
 - user: None

Florencia Amado Cattaneo, 41, has now been seized by Argentinian police for the horrific alleged murder of Pedro Federico Zarate, and sent for psychiatric assessment.

## New gas boilers could be banned within a decade as report say UK must do more to his net-zero target
 - [https://www.dailymail.co.uk/news/article-11631131/New-gas-boilers-banned-decade-report-say-UK-net-zero-target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631131/New-gas-boilers-banned-decade-report-say-UK-net-zero-target.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:30:52+00:00
 - user: None

The review, carried out by Tory MP Chris Skidmore and published on Friday, urges the Government  to phase out gas boilers across the UK by 2033, rather than 2035.

## Watch the moment influencer perches on top of the world's second highest building in Malaysia
 - [https://www.dailymail.co.uk/news/article-11631033/Watch-moment-influencer-perches-worlds-second-highest-building-Malaysia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631033/Watch-moment-influencer-perches-worlds-second-highest-building-Malaysia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:27:48+00:00
 - user: None

Angela Nikolau, 29, scaled the tower in Kuala Lumpur with her boyfriend Ivan Beerkus. She noted that it is 'the most beautiful skyscraper' she has ever visited.

## Couple's Bali trip goes wrong after they claim villa in Seminyak was 'disgusting'
 - [https://www.dailymail.co.uk/news/article-11630915/Couples-Bali-trip-goes-wrong-claim-villa-Seminyak-disgusting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630915/Couples-Bali-trip-goes-wrong-claim-villa-Seminyak-disgusting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:21:08+00:00
 - user: None

Sydney woman Dee Daber and her partner booked a villa in the popular tourist hangout of Seminyak but claim the accommodation was 'disgusting'.

## Putin 'will nominate his chosen heir this year rather than risk being toppled', former ally says
 - [https://www.dailymail.co.uk/news/article-11631171/Putin-nominate-chosen-heir-year-risk-toppled-former-ally-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631171/Putin-nominate-chosen-heir-year-risk-toppled-former-ally-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 10:02:30+00:00
 - user: None

Vladimir Putin will seek to hand over power to a chosen heir and retire to his £1billion Black Sea 'palace' rather than risk being toppled, said Abbas Gallyamov, the leader's former speechwriter.

## More flood hell as residents are forced out of their homes amid 258 flood alerts
 - [https://www.dailymail.co.uk/news/article-11631145/More-flood-hell-residents-forced-homes-amid-258-flood-alerts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631145/More-flood-hell-residents-forced-homes-amid-258-flood-alerts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:56:08+00:00
 - user: None

There are currently 258 flood alerts and warnings across the country, from Carlisle to Brighton, although Wales and the south west continue to be the most at risk

## Ukraine forces hold out after a 'hot' night of 'high intensity' battles in Soledar
 - [https://www.dailymail.co.uk/news/article-11631099/Ukraine-forces-hold-hot-night-high-intensity-battles-Soledar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631099/Ukraine-forces-hold-hot-night-high-intensity-battles-Soledar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:54:44+00:00
 - user: None

President Volodymyr Zelensky has vowed to defenders in the region would be armed with everything they need to keep Russian troops at  bay in the fierce and bloody fighting.

## Lisa Marie Presley told fans at Graceland she hardly leaves her home days before death
 - [https://www.dailymail.co.uk/news/article-11631039/Lisa-Marie-Presley-told-fans-Graceland-hardly-leaves-home-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631039/Lisa-Marie-Presley-told-fans-Graceland-hardly-leaves-home-days-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:49:57+00:00
 - user: None

The singer-songwriter told the devoted crowd at her father's Memphis estate that they were the 'only people who can bring me out of the house' in the touching words to mark his 88th birthday on Sunday.

## Lisa Marie Presley slurred her words in Golden Globes interview days before her death at 54
 - [https://www.dailymail.co.uk/tvshowbiz/article-11629651/Lisa-Marie-Presley-appears-unsteady-Golden-Globes-days-suffering-cardiac-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11629651/Lisa-Marie-Presley-appears-unsteady-Golden-Globes-days-suffering-cardiac-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:47:28+00:00
 - user: None

In the clip, Lisa Marie, 54 - who suffered a fatal cardiac arrest Thursday - turned to her friend Jerry Schilling, 80, and said, 'I'm gonna grab your arm.'

## Savage tornado rips through Alabama and Georgia, killing at least seven
 - [https://www.dailymail.co.uk/news/article-11631051/Savage-tornado-rips-Alabama-Georgia-killing-seven.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631051/Savage-tornado-rips-Alabama-Georgia-killing-seven.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:39:33+00:00
 - user: None

At least six fatalities were confirmed and an estimated 40 homes were destroyed by a sweeping tornado that cut a 20-mile  path through several rural communities in Autauga County, Alabama

## Police hunt for man after woman dropped to Bankstown Hospital with gunshot wound in Sydney's west
 - [https://www.dailymail.co.uk/news/article-11630797/Police-hunt-man-woman-dropped-Bankstown-Hospital-gunshot-wound-Sydneys-west.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630797/Police-hunt-man-woman-dropped-Bankstown-Hospital-gunshot-wound-Sydneys-west.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:35:44+00:00
 - user: None

The woman, 37, was driven to Bankstown Hospital, in Sydney's west, in a white  sedan after being shot in the torso, at about 12.50pm on Thursday.

## Cannabis-smoking father 'violently shook his newborn baby to death'
 - [https://www.dailymail.co.uk/news/article-11631025/Cannabis-smoking-father-violently-shook-newborn-baby-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631025/Cannabis-smoking-father-violently-shook-newborn-baby-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:34:52+00:00
 - user: None

Oliver Mailey originally claimed he found seven-week-old Abel-Jax Mailey limp and lifeless in his cot at home in Burnley, Lancashire, before admitting he had shaken the infant to death.

## Now Tesco locks up bacon and sausages in fridges
 - [https://www.dailymail.co.uk/news/article-11630961/Now-Tesco-locks-bacon-sausages-fridges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630961/Now-Tesco-locks-bacon-sausages-fridges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:27:28+00:00
 - user: None

The sign had been stuck on the chilled meat section of a Tesco Express on Tower Bridge Road in central London.

## Over half of Brits want 'immediate' end to cigarette sales
 - [https://www.dailymail.co.uk/news/article-11631197/Over-half-Brits-want-immediate-end-cigarette-sales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631197/Over-half-Brits-want-immediate-end-cigarette-sales.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 09:09:35+00:00
 - user: None

Research for MailOnline found that 52 per cent would support an 'outright' block on buying cigarettes - with 31 per cent backing it 'strongly'.

## How old is YOUR heart? As GPs are told to prescribe more statins, take the test to assess your risk
 - [https://www.dailymail.co.uk/health/article-11627661/How-old-heart-GPs-told-prescribe-statins-test-assess-risk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11627661/How-old-heart-GPs-told-prescribe-statins-test-assess-risk.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:57:21+00:00
 - user: None

NHS drug watchdogs have effectively axed the eligibility criteria for the life-saving pills. But, do you know whether you're at risk of being struck down by either killer?

## Widower, 58, wins keys to a five-bed £2.5m Lake District home and £100,000 after entering prize draw
 - [https://www.dailymail.co.uk/news/article-11631043/Widower-58-wins-keys-five-bed-2-5m-Lake-District-home-100-000-entering-prize-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631043/Widower-58-wins-keys-five-bed-2-5m-Lake-District-home-100-000-entering-prize-draw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:42:42+00:00
 - user: None

Grant Carson, 58, has won a stunning Lake District home worth £2.5 million and £100,000 after entering a £100 prize draw which raised £850,000 for the Dogs Trust.

## First-time buyer mortgage payments now 39% of salary
 - [https://www.dailymail.co.uk/money/mortgageshome/article-11627605/First-time-buyer-mortgage-payments-39-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/mortgageshome/article-11627605/First-time-buyer-mortgage-payments-39-salary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:38:40+00:00
 - user: None

House price rises also mean a 20% deposit on a typical first-time buyer home is now equivalent to 112% of the pre-tax income of a typical full-time employee.

## Rishi Sunak tells Nicola Sturgeon the UK should 'work together' on Scotland trip
 - [https://www.dailymail.co.uk/news/article-11631045/Rishi-Sunak-tells-Nicola-Sturgeon-UK-work-Scotland-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631045/Rishi-Sunak-tells-Nicola-Sturgeon-UK-work-Scotland-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:34:19+00:00
 - user: None

Rishi Sunak and Nicola Sturgeon had 'robust' exchanges during around an hour of talks over dinner last night.

## Royal fans spot inconsistency over Meghan Markle's first date outfit
 - [https://www.dailymail.co.uk/femail/article-11628881/Royal-fans-spot-inconsistency-Meghan-Markles-date-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11628881/Royal-fans-spot-inconsistency-Meghan-Markles-date-outfit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:34:14+00:00
 - user: None

Royal fans on TikTok pointed out that Prince Harry's account of the couple's first date in London conflicts with a comment Meghan made in September 2018.

## Man dies after collapsing at PureGym despite medics' efforts to revive him
 - [https://www.dailymail.co.uk/news/article-11631063/Man-dies-collapsing-PureGym-despite-medics-efforts-revive-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11631063/Man-dies-collapsing-PureGym-despite-medics-efforts-revive-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:30:11+00:00
 - user: None

Paramedics were called to the scene in Ilford shortly before 9am on Thursday. The Metropolitan Police said medics did their best to revive the man but he died 46 minutes later.

## Jermaine Pennant reveals he lost career earnings of over £10MILLION
 - [https://www.dailymail.co.uk/tvshowbiz/article-11629909/Jermaine-Pennant-reveals-lost-career-earnings-10MILLION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11629909/Jermaine-Pennant-reveals-lost-career-earnings-10MILLION.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:07:05+00:00
 - user: None

The former footballer, 39, who described himself as 'financially illiterate', said he blew his fortune on dodgy investments and bad actors who targeted him.

## Dr Liu-Ming Schmidt from Albury Wodonga Hospital temporary ban after potentially dodgy colonoscopies
 - [https://www.dailymail.co.uk/news/article-11630751/Dr-Liu-Ming-Schmidt-Albury-Wodonga-Hospital-temporary-ban-potentially-dodgy-colonoscopies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630751/Dr-Liu-Ming-Schmidt-Albury-Wodonga-Hospital-temporary-ban-potentially-dodgy-colonoscopies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:06:21+00:00
 - user: None

Dr Liu-Ming Schmidt who performed hundreds of potentially dodgy colonoscopies in the NSW-Victorian border region of Albury-Wodonga has been temporarily banned from practising medicine.

## Inside Lisa Marie Presley's 'unrelenting grief' over son Benjamin's suicide
 - [https://www.dailymail.co.uk/tvshowbiz/article-11629425/Inside-Lisa-Marie-Presleys-unrelenting-grief-son-Benjamins-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11629425/Inside-Lisa-Marie-Presleys-unrelenting-grief-son-Benjamins-suicide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:04:57+00:00
 - user: None

Lisa Marie Presley penned an essay sharing her 'unrelenting grief' over her son Benjamin's untimely death just five months before her own death at age 54.

## Martina Navratilova's wife of eight years Julia was exploring adoption… before cancer diagnosis
 - [https://www.dailymail.co.uk/tvshowbiz/article-11630945/Martina-Navratilovas-wife-eight-years-Julia-exploring-adoption-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11630945/Martina-Navratilovas-wife-eight-years-Julia-exploring-adoption-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 08:04:52+00:00
 - user: None

Just days after it was revealed that tennis legend Martina Navratilova is battling both throat and breast cancer , her wife Julia Lemigova teased the couple was exploring adoption.

## Drunk naked son, 54, 'battered his elderly father to death with a bottle of Bollinger'
 - [https://www.dailymail.co.uk/news/article-11630957/Drunk-naked-son-54-battered-elderly-father-death-bottle-Bollinger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630957/Drunk-naked-son-54-battered-elderly-father-death-bottle-Bollinger.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:43:18+00:00
 - user: None

Police found Deekan Vig, 54, lying naked on a pile of 100 bottles of champagne next to his dead father, Arjan Singh Vig, 86, at their home in Southgate, north London, the Old Bailey heard.

## Economy defied expectations by GROWING 0.1% in November
 - [https://www.dailymail.co.uk/news/article-11630929/Economy-defied-expectations-GROWING-0-1-November.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630929/Economy-defied-expectations-GROWING-0-1-November.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:35:53+00:00
 - user: None

Figures showed UK plc expanded by 0.1 per cent with the services sector performing well and pubs and bars boosted by the World Cup.

## Who's going to get Graceland? Lisa Marie's 14-year-old twins and Hollywood star daughter may inherit
 - [https://www.dailymail.co.uk/news/article-11630587/Whos-going-Graceland-Lisa-Maries-14-year-old-twins-Hollywood-star-daughter-inherit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630587/Whos-going-Graceland-Lisa-Maries-14-year-old-twins-Hollywood-star-daughter-inherit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:35:53+00:00
 - user: None

Lisa Marie Presley leaves behind three daughters - 33-year-old actress Riley Keough, and 14-year-old twins Harper Vivienne and Finley. Her son Benjamin killed himself age 27 in July 2020.

## JAN MOIR: Prince Harry knows very well how much this will wound and infuriate his older brother
 - [https://www.dailymail.co.uk/debate/article-11629553/JAN-MOIR-Prince-Harry-knows-wound-infuriate-older-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/debate/article-11629553/JAN-MOIR-Prince-Harry-knows-wound-infuriate-older-brother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:32:54+00:00
 - user: None

JAN MOIR: Going Spare? Me, too. Yet while there has been so much about Prince Harry this week - everything from his frozen penis to losing his virginity alfresco,  - let us spare a thought for Prince William.

## Eye-watering salaries of first year law, finance, consultancy graduates in Australia revealed
 - [https://www.dailymail.co.uk/news/article-11630389/Eye-watering-salaries-year-law-finance-consultancy-graduates-Australia-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630389/Eye-watering-salaries-year-law-finance-consultancy-graduates-Australia-revealed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:30:46+00:00
 - user: None

The Aussie Corporate ran the survey and collected responses from more than 2,500 people across the corporate sphere.

## Prosecutors in Danny Masterson rape case dealt a blow after Lisa Marie Presley's death
 - [https://www.dailymail.co.uk/news/article-11630777/Prosecutors-Danny-Masterson-rape-case-dealt-blow-Lisa-Marie-Presleys-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630777/Prosecutors-Danny-Masterson-rape-case-dealt-blow-Lisa-Marie-Presleys-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:17:20+00:00
 - user: None

Prosecutors eager to revive the rape case against That 70s Show star and Scientologist Danny Masterson were dealt a blow following the death of Lisa Marie Presley.

## Met Police take over hunt to find mother from wealthy aristocratic family, partner and newborn baby
 - [https://www.dailymail.co.uk/news/article-11630919/Met-Police-hunt-mother-wealthy-aristocratic-family-partner-newborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630919/Met-Police-hunt-mother-wealthy-aristocratic-family-partner-newborn-baby.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:09:36+00:00
 - user: None

Constance Marten, 35, is from an aristocratic landowning family in Dorset, with 'ties to the Royal Family'. She has been spotted in East London with her newborn baby.

## Is inbreeding responsible for heart attacks in Elvis's family? His grandparents were cousins
 - [https://www.dailymail.co.uk/news/article-11630557/Is-inbreeding-responsible-heart-attacks-Elviss-family-grandparents-cousins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630557/Is-inbreeding-responsible-heart-attacks-Elviss-family-grandparents-cousins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:05:57+00:00
 - user: None

The deaths of Elvis, his mother, and his daughter Lisa Marie may have been caused by a Alpha-1 antitrypsin deficiency. The genetic defect causes lung and liver damage and other problems.

## Sea World patrons left stuck on Leviathan rollercoaster on Gold Coast after new ride malfunctions
 - [https://www.dailymail.co.uk/news/article-11630709/Sea-World-patrons-left-stuck-Leviathan-rollercoaster-Gold-Coast-new-ride-malfunctions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630709/Sea-World-patrons-left-stuck-Leviathan-rollercoaster-Gold-Coast-new-ride-malfunctions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 07:01:28+00:00
 - user: None

Thrill-seekers have been left stuck on the new Leviathan rollercoaster at Sea World on the Gold Coast on Friday. A computer found a potential malfunction on the ride and triggered a stoppage.

## Secret rule change will see House lawmakers get a $34,000 PAY BUMP
 - [https://www.dailymail.co.uk/news/article-11630687/Secret-rule-change-House-lawmakers-34-000-PAY-BUMP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630687/Secret-rule-change-House-lawmakers-34-000-PAY-BUMP.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 06:49:52+00:00
 - user: None

House Democrats secretly passed a new rule that will see lawmakers get reimbursed for the cost of lodging, food and travel while on official business in DC.

## Diablo Co marketing manager wins court case against boss after she was fired for 'racism'
 - [https://www.dailymail.co.uk/news/article-11630365/Diablo-marketing-manager-wins-court-case-against-boss-fired-racism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630365/Diablo-marketing-manager-wins-court-case-against-boss-fired-racism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 06:43:40+00:00
 - user: None

A female marketing manager sacked for a 'racist' remark has won her unfair dismissal court battle against her boutique alcohol employer.

## Jet skiers caught on video 'chasing down' dolphins in Port Phillip Bay, Melbourne
 - [https://www.dailymail.co.uk/news/article-11630253/Jet-skiers-caught-video-chasing-dolphins-Port-Phillip-Bay-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630253/Jet-skiers-caught-video-chasing-dolphins-Port-Phillip-Bay-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 06:02:56+00:00
 - user: None

Vision of two men riding within two metres towards dolphins in Port Phillip Bay on the Mornington Peninsula in Melbourne was posted to social media this week.

## Wollongong man Paul Iera allegedly fakes kidnapping to be with lover on New Year's Eve
 - [https://www.dailymail.co.uk/news/article-11630443/Wollongong-man-Paul-Iera-allegedly-fakes-kidnapping-lover-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630443/Wollongong-man-Paul-Iera-allegedly-fakes-kidnapping-lover-New-Years-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:46:44+00:00
 - user: None

Paul Iera, 35, was arrested on Thursday before being charged with providing false information after he was accused of lying about being kidnapped to spend New Year's Eve with his mistress.

## Willem Powerfish responds to angry fans after filming a rescue as surfer almost drowns
 - [https://www.dailymail.co.uk/news/article-11630281/Willem-Powerfish-responds-angry-fans-filming-rescue-surfer-drowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630281/Willem-Powerfish-responds-angry-fans-filming-rescue-surfer-drowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:39:30+00:00
 - user: None

A man who filmed the moment a surfer struggling to stay above the water has had to defend himself from vicious commenters calling him a 'moron' for not helping.

## Lisa Marie Presley's falsely accused ex-husband Michael Lockwood of being a pedophile
 - [https://www.dailymail.co.uk/news/article-11630535/Lisa-Marie-Presleys-accused-ex-husband-pedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630535/Lisa-Marie-Presleys-accused-ex-husband-pedophile.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:35:20+00:00
 - user: None

Lisa Marie Presley was embroiled in a custody battle with her ex-husband Michael Lockwood for years after she falsely accused him of having images and videos of child pornography.

## Lisa Marie's unusual husbands - Nic Cage, Michael Jackson, and the divorce from Michael Lockwood
 - [https://www.dailymail.co.uk/news/article-11630177/Lisa-Maries-unusual-husbands-Nic-Cage-Michael-Jackson-divorce-Michael-Lockwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630177/Lisa-Maries-unusual-husbands-Nic-Cage-Michael-Jackson-divorce-Michael-Lockwood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:32:48+00:00
 - user: None

Lisa Marie Presley was engaged five times and married four men in her life. She married Michael Jackson in 1994, only to divorce less than two years later.

## Dominic Perrottet addresses comments about Labor MPs part in anti-Israel rally after Nazi scandal
 - [https://www.dailymail.co.uk/news/article-11630425/Dominic-Perrottet-addresses-comments-Labor-MPs-anti-Israel-rally-Nazi-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630425/Dominic-Perrottet-addresses-comments-Labor-MPs-anti-Israel-rally-Nazi-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:28:38+00:00
 - user: None

Dominic Perrottet was grilled over 2017 Labor sledge after admitting he wore Nazi uniform to his 21st birthday.

## Fierce trade war set to thaw as China imports Australian coal for the first time in years
 - [https://www.dailymail.co.uk/news/article-11630419/Fierce-trade-war-set-thaw-China-imports-Australian-coal-time-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630419/Fierce-trade-war-set-thaw-China-imports-Australian-coal-time-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 05:08:35+00:00
 - user: None

Icy trade relations between Australia and China are appearing to thaw amid reports Beijing will allow Australian coal imports for the first time since 2020 - with the first shipment due to arrive this month.

## Biden revealed to Jay Leno that Hunter refurbished his Corvette - that was  in garage with documents
 - [https://www.dailymail.co.uk/news/article-11630145/Biden-revealed-Jay-Leno-Hunter-refurbished-Corvette-garage-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630145/Biden-revealed-Jay-Leno-Hunter-refurbished-Corvette-garage-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 04:59:24+00:00
 - user: None

The Department of Justice said Thursday that a second trove of classified documents belonging to Joe Biden were found in a garage that his troubled son had access to in the president's home.

## NAB customer loses whole month's pay in scam
 - [https://www.dailymail.co.uk/news/article-11630217/NAB-customer-loses-months-pay-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630217/NAB-customer-loses-months-pay-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 04:39:11+00:00
 - user: None

Gold Coast woman Chelsea Paton, 36, lost almost $5,000 after her bank details were stolen and used for 25 transactions at the Pink Lady Private Hotel in Drummoyne, Sydney.

## Sea World helicopter crash: pilot Ashley Jenkinson farewelled in funeral on the Gold Coast
 - [https://www.dailymail.co.uk/news/article-11630379/Sea-World-helicopter-crash-pilot-Ashley-Jenkinson-farewelled-funeral-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630379/Sea-World-helicopter-crash-pilot-Ashley-Jenkinson-farewelled-funeral-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 04:09:46+00:00
 - user: None

Hundreds of mourners piled into Southport Church of Christ, on the Gold Coast, on Friday to say their goodbyes to Ashley Jenkinson, 40 - the pilot killed in the Sea World helicopter tragedy.

## Quaden Bayles targeted by cruel trolls as child gets ready for role in Mad Max franchise Furiosa
 - [https://www.dailymail.co.uk/news/article-11630003/Quaden-Bayles-targeted-cruel-trolls-child-gets-ready-role-Mad-Max-franchise-Furiosa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630003/Quaden-Bayles-targeted-cruel-trolls-child-gets-ready-role-Mad-Max-franchise-Furiosa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 03:30:22+00:00
 - user: None

The 12-year-old will appear next to the  Hollywood A-lister and actress Anya Taylor-Joy in the film 'Furiosa', the fifth instalment in the 'Mad Max' franchise, in May 2024.

## Heatwave forecast for NSW, WA, SA, Victoria but Sydney to be spared as rain hits Queensland
 - [https://www.dailymail.co.uk/news/article-11629807/Heatwave-forecast-NSW-WA-SA-Victoria-Sydney-spared-rain-hits-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629807/Heatwave-forecast-NSW-WA-SA-Victoria-Sydney-spared-rain-hits-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 03:27:03+00:00
 - user: None

Summer is finally here as authorities issue heatwave warnings for six states and territories with parts of Australia already sweltering through days above 45 degrees.

## Tesla's fully electric Model 3 beats the Toyota Camry
 - [https://www.dailymail.co.uk/news/article-11629611/Teslas-fully-electric-Model-3-beats-Toyota-Camry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629611/Teslas-fully-electric-Model-3-beats-Toyota-Camry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:44:16+00:00
 - user: None

Tesla's Model 3 electric car has toppled the Toyota Camry to become Australia's highest-selling sedan, but one owner of the vehicle is not impressed.

## Lisa Marie Presley dead: How Elvis's only child went from $100m inheritance to being $16m debt
 - [https://www.dailymail.co.uk/news/article-11630219/Lisa-Marie-Presley-dead-Elviss-child-went-100m-inheritance-16m-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630219/Lisa-Marie-Presley-dead-Elviss-child-went-100m-inheritance-16m-debt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:37:07+00:00
 - user: None

Lisa Marie Presley, who died on Thursday at the age of 54, inherited her father Elvis's estate at the age of 25. At the time it was worth $100 million, but mismanagement saw her become in debt.

## Injured British soldier tells Prince Harry he should 'crack on with his life'
 - [https://www.dailymail.co.uk/news/article-11630159/Injured-British-soldier-tells-Prince-Harry-crack-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630159/Injured-British-soldier-tells-Prince-Harry-crack-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:22:36+00:00
 - user: None

Former Royal Marine Ben McBean said that he 'does not have to support everything he [Prince Harry] does' and that he should now 'crack on with his life'.

## Pete Buttigieg avoided requests from GOP and Dems during paternity leave
 - [https://www.dailymail.co.uk/news/article-11630035/Pete-Buttigieg-avoided-requests-GOP-Dems-paternity-leave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630035/Pete-Buttigieg-avoided-requests-GOP-Dems-paternity-leave.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:20:48+00:00
 - user: None

Pete Buttigieg turned down requests to talk to a Republican senator, invites direct to him by the White House and a public appearance request from a Democrat during his time on paternity leave.

## Dickie Arbiter demands apology from Prince Harry after quote was apparently misattributed to him
 - [https://www.dailymail.co.uk/news/article-11630209/Dickie-Arbiter-demands-apology-Prince-Harry-quote-apparently-misattributed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630209/Dickie-Arbiter-demands-apology-Prince-Harry-quote-apparently-misattributed-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:10:06+00:00
 - user: None

Dickie Arbiter (pictured), 82, was press secretary to the late Queen Elizabeth but he is not named in the Duke of Sussex's Spare.

## VA woman reads cop's own 'racially motivated' ticketing record after he pulls her over
 - [https://www.dailymail.co.uk/news/article-11629911/VA-woman-reads-cops-racially-motivated-ticketing-record-pulls-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629911/VA-woman-reads-cops-racially-motivated-ticketing-record-pulls-over.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:03:31+00:00
 - user: None

One woman on TikTok stunned a Virginia police officer  after she read him data she had compiled on his ticketing record against people of color over six months.

## Drug abuse and rehab: Lisa Marie admitted abusing cocaine and five stints in rehab
 - [https://www.dailymail.co.uk/news/article-11629799/Drug-abuse-rehab-Lisa-Marie-admitted-abusing-cocaine-five-stints-rehab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629799/Drug-abuse-rehab-Lisa-Marie-admitted-abusing-cocaine-five-stints-rehab.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 02:03:09+00:00
 - user: None

Lisa Marie Presley, who died on Thursday at the age of 54, said she began using drugs at the age of 13, and at 17 was sent to a Scientology rehab. She became addicted again in 2008.

## Lisa Marie's marriage to Michael Jackson and THAT awkward kiss at the MTV Awards
 - [https://www.dailymail.co.uk/news/article-11629745/Lisa-Maries-marriage-Michael-Jackson-awkward-kiss-MTV-Awards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629745/Lisa-Maries-marriage-Michael-Jackson-awkward-kiss-MTV-Awards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:56:35+00:00
 - user: None

Lisa Marie Presley married Michael Jackson in 1994, and divorced months later. Their relationship began while Jackson was mired in child molestation charges.

## Bonogin triple death crash: Mother Susan Zimmer daughter Stephanie funeral at Mudgeeraba Showgrounds
 - [https://www.dailymail.co.uk/news/article-11629983/Bonogin-triple-death-crash-Mother-Susan-Zimmer-daughter-Stephanie-funeral-Mudgeeraba-Showgrounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629983/Bonogin-triple-death-crash-Mother-Susan-Zimmer-daughter-Stephanie-funeral-Mudgeeraba-Showgrounds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:47:15+00:00
 - user: None

Susan Zimmer, 70 and her daughter Stephanie, 35, died after their silver Mercedes was smashed off the road in Bonogin in Queensland's Gold Coast hinterland on December 30.

## Energy price cap could fall below £2,500 after unexpectedly warm winter, analysis shows
 - [https://www.dailymail.co.uk/news/article-11630053/Energy-price-cap-fall-2-500-unexpectedly-warm-winter-analysis-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630053/Energy-price-cap-fall-2-500-unexpectedly-warm-winter-analysis-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:45:50+00:00
 - user: None

An unexpectedly warm winter and substantial levels of gas storage have caused gas prices to drop in recent weeks.

## Kate raises eyebrows as she says 'talking therapies don't work for everyone' during hospital visit
 - [https://www.dailymail.co.uk/news/article-11630023/Kate-raises-eyebrows-says-talking-therapies-dont-work-hospital-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630023/Kate-raises-eyebrows-says-talking-therapies-dont-work-hospital-visit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:44:34+00:00
 - user: None

The Prince and Princess of Wales were in Merseyside yesterday visiting mental health charity Open Door, when Kate said: 'Talking therapies don't work for some.'

## Man jailed for rape and murder sues prison service in test case that could cost taxpayers millions
 - [https://www.dailymail.co.uk/news/article-11630069/Man-jailed-rape-murder-sues-prison-service-test-case-cost-taxpayers-millions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630069/Man-jailed-rape-murder-sues-prison-service-test-case-cost-taxpayers-millions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:42:52+00:00
 - user: None

Barry Hillman, 42, says that a lack of central heating and hot water at HMP Littlehey infringed on European human rights legislation.

## Brian Walshe once threatened to KILL wife Ana years before she went missing
 - [https://www.dailymail.co.uk/news/article-11630043/Brian-Walshe-threatened-KILL-wife-Ana-years-went-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630043/Brian-Walshe-threatened-KILL-wife-Ana-years-went-missing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:41:46+00:00
 - user: None

Ana Walshe called the Washington DC Metropolitan Police on Brain Walshe in 2015 saying he 'made a statement on the telephone that he was going to kill her.'

## ALISON BOSHOFF pays tribute to Jeff Beck
 - [https://www.dailymail.co.uk/tvshowbiz/article-11629691/ALISON-BOSHOFF-pays-tribute-Jeff-Beck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11629691/ALISON-BOSHOFF-pays-tribute-Jeff-Beck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:40:37+00:00
 - user: None

To many of the biggest names in music - Rod Stewart, Ronnie Wood and Eric Clapton - Jeff Beck was the ultimate loner.

## Up to a dozen Grenfell Tower firefighters are now ill with cancer caused by inhaling pollutants
 - [https://www.dailymail.co.uk/news/article-11629989/Up-dozen-Grenfell-Tower-firefighters-ill-cancer-caused-inhaling-pollutants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629989/Up-dozen-Grenfell-Tower-firefighters-ill-cancer-caused-inhaling-pollutants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:34:22+00:00
 - user: None

About a dozen firefighters who worked the west London fire in June 2017 have since been diagnosed with cancer. But experts fear there could end up being more than 20 cases linked the blaze.

## McDonald's potato scallop promo slammed by Victorian fish and chip shop owner amid potato shortage
 - [https://www.dailymail.co.uk/news/article-11629797/McDonalds-potato-scallop-promo-slammed-Victorian-fish-chip-shop-owner-amid-potato-shortage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629797/McDonalds-potato-scallop-promo-slammed-Victorian-fish-chip-shop-owner-amid-potato-shortage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:33:51+00:00
 - user: None

A frustrated fish and chip shop owner has blasted McDonald's for its potato scallop promo accusing the fast food giant of pushing local shops to the brink amid a nationwide spud shortage.

## Lotto winner passes out at work after discovering she had won $1million prize
 - [https://www.dailymail.co.uk/news/article-11630049/I-went-white-ghost-Wodonga-woman-loses-consciousness-1-million-Lotto-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630049/I-went-white-ghost-Wodonga-woman-loses-consciousness-1-million-Lotto-win.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:33:16+00:00
 - user: None

The lucky winner of the $1million Lotto prize said she turned 'white as a ghost' before promptly fainting at her desk at work - alarming her colleagues who had thought something was wrong.

## Mick Lynch forced to take an alternate Tube route during his commute as walkouts hit his usual
 - [https://www.dailymail.co.uk/news/article-11630065/Mick-Lynch-forced-alternate-Tube-route-commute-walkouts-hit-usual.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630065/Mick-Lynch-forced-alternate-Tube-route-commute-walkouts-hit-usual.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:23:01+00:00
 - user: None

He has overseen months of strikes and travel chaos. And yesterday, union boss Mick Lynch was forced to walk a mile in the shoes of frustrated travellers after a walkout derailed his own commute.

## Half of modern slavery claims from Channel boat migrants were made by Albanians, data shows
 - [https://www.dailymail.co.uk/news/article-11630143/Half-modern-slavery-claims-Channel-boat-migrants-Albanians-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630143/Half-modern-slavery-claims-Channel-boat-migrants-Albanians-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:20:11+00:00
 - user: None

Government data showed just over 51 per cent of Channel migrants who claimed they had been exploited were from the Balkan country. The figure was just over 11 per cent in 2021.

## Britain needs to cover buildings in solar panels to meet net-zero emissions target, expert says
 - [https://www.dailymail.co.uk/news/article-11630025/Britain-needs-cover-buildings-solar-panels-meet-net-zero-emissions-target-expert-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630025/Britain-needs-cover-buildings-solar-panels-meet-net-zero-emissions-target-expert-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 01:08:23+00:00
 - user: None

Chris Skidmore, the former science minister, set out his conclusions in his 'Net Zero Review', which looks at how the UK can reach its target to stop production of greenhouse gases by 2050.

## Karine Jean-Pierre grilled about transparency with classified documents
 - [https://www.dailymail.co.uk/news/article-11629703/Karine-Jean-Pierre-grilled-transparency-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629703/Karine-Jean-Pierre-grilled-transparency-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:47:18+00:00
 - user: None

Karine Jean-Pierre defended Joe Biden against charges of hypocrisy as she was grilled in on why the White House waited nearly a month to reveal there were more classified files.

## Man, 22, is charged with murdering beautician Elle Edwards, 26, who was shot dead on Christmas Eve
 - [https://www.dailymail.co.uk/news/article-11630027/Man-22-charged-murdering-beautician-Elle-Edwards-26-shot-dead-Christmas-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11630027/Man-22-charged-murdering-beautician-Elle-Edwards-26-shot-dead-Christmas-Eve.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:41:18+00:00
 - user: None

Detectives have charged a man with the murder of Elle Edwards in Wallasey on Christmas Eve.

## Police force head says he can't sack 'toxic' staff as  450 sex claims were made against officers
 - [https://www.dailymail.co.uk/news/article-11629945/Police-force-head-says-sack-toxic-staff-450-sex-claims-against-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629945/Police-force-head-says-sack-toxic-staff-450-sex-claims-against-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:38:59+00:00
 - user: None

Nearly 450 sexual misconduct allegations were made against police in one year, shocking figures revealed yesterday.

## Strike vote by teachers fails to reach 50% meaning walkout plans fail
 - [https://www.dailymail.co.uk/news/article-11629947/Strike-vote-teachers-fails-reach-50-meaning-walkout-plans-fail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629947/Strike-vote-teachers-fails-reach-50-meaning-walkout-plans-fail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:31:37+00:00
 - user: None

Just 42 per cent of the primary and secondary staff balloted by NASUWT turned out to vote in what has been described by MPs as a 'win for parents and pupils'.

## Foreign Office deny Afghans have been granted clearance to come to UK after minister said they had
 - [https://www.dailymail.co.uk/news/article-11629627/Minister-makes-inaccurate-statement-Afghans-granted-sanctuary-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629627/Minister-makes-inaccurate-statement-Afghans-granted-sanctuary-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:30:38+00:00
 - user: None

Leo Docherty told MPs that half of the 190 Afghan contractors had been given clearance to come to the UK. The Foreign Office were forced to correct the record as this was not the case.

## Idaho senator has mic switched off as he argues against transgender students using the girl's room
 - [https://www.dailymail.co.uk/news/article-11629751/Idaho-senator-mic-switched-argues-against-transgender-students-using-girls-room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629751/Idaho-senator-mic-switched-argues-against-transgender-students-using-girls-room.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:30:36+00:00
 - user: None

A volunteer school board president shut the mic off of Idaho State Sen, Chris Trakel who spoke out against the district's proposed transgender bathroom policy.

## Air New Zealand take swipe against Prince Harry over first-class claim in memoir Spare
 - [https://www.dailymail.co.uk/news/article-11629697/Air-New-Zealand-swipe-against-Prince-Harry-class-claim-memoir-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629697/Air-New-Zealand-swipe-against-Prince-Harry-class-claim-memoir-Spare.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:29:20+00:00
 - user: None

The Duke of Sussex had claimed Meghan purchased a first-class ticket from Mexico to Britain so her father Thomas Markle over concerns of media harassment.

## Health workers threaten MORE strikes with a further SIX walkouts planned
 - [https://www.dailymail.co.uk/news/article-11629951/Health-workers-threaten-strikes-SIX-walkouts-planned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629951/Health-workers-threaten-strikes-SIX-walkouts-planned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:27:42+00:00
 - user: None

Union sources said the GMB could, on Monday, announce a further six strikes by ambulance workers in a bid to ramp up pressure on ministers to give ground.

## George Pell blasted Daniel Andrews in speech before death as Victorian premier confirms no funeral
 - [https://www.dailymail.co.uk/news/article-11629597/George-Pell-blasted-Daniel-Andrews-speech-death-Victorian-premier-confirms-no-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629597/George-Pell-blasted-Daniel-Andrews-speech-death-Victorian-premier-confirms-no-funeral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:25:30+00:00
 - user: None

Victorian Premier Dan Andrews was quick to rule out a state memorial service for George Pell, saying he couldn't think of anything 'more distressing for victim survivors than that'.

## Squad of lethal Russian fighter bombers roar past HMS Queen Elizabeth in 'threatening' display
 - [https://www.dailymail.co.uk/news/article-11627307/Squad-lethal-Russian-fighter-bombers-roar-past-HMS-Queen-Elizabeth-threatening-display.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11627307/Squad-lethal-Russian-fighter-bombers-roar-past-HMS-Queen-Elizabeth-threatening-display.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:04:40+00:00
 - user: None

The trio of deadly SU-24 fighter-bombers were filmed charging towards the £3.2bn aircraft carrier and her battle group as they sailed towards the Suez Canal in June 2021.

## Adelaide father allegedly stabbed to death by daughter in Andrews Farm on Boxing Day hit by trolls
 - [https://www.dailymail.co.uk/news/article-11625893/Adelaide-father-allegedly-stabbed-death-daughter-Andrews-Farm-Boxing-Day-hit-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11625893/Adelaide-father-allegedly-stabbed-death-daughter-Andrews-Farm-Boxing-Day-hit-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:03:53+00:00
 - user: None

Trolls leapt on reports of the alleged stabbing of the father by his teenage daughter to make wild unfounded abuse allegations against the dead dad who relatives insist was a 'good man'.

## Brands 'abandon' smart TV owners after just two years by withdrawing tech support
 - [https://www.dailymail.co.uk/news/article-11629883/Brands-abandon-smart-TV-owners-just-two-years-withdrawing-tech-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629883/Brands-abandon-smart-TV-owners-just-two-years-withdrawing-tech-support.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:03:23+00:00
 - user: None

A survey by Which? found firms - such as LG and Sony - stopped offering technical support after this period despite designing the products to last much longer.

## Parking tickets are given out every TWO SECONDS in UK
 - [https://www.dailymail.co.uk/news/article-11629879/Parking-tickets-given-TWO-SECONDS-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11629879/Parking-tickets-given-TWO-SECONDS-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-13 00:00:54+00:00
 - user: None

Shock new figures reveal the 'ruthless' army of parking wardens employed by councils are issuing nearly 20,000 fines a day on average. Private companies are dishing out 30,000 daily tickets.
