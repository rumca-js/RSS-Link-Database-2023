# Source Laowhy86, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw, Source language: en-US

## China is About to LOSE Badly
 - [https://www.youtube.com/watch?v=h3UPG8CuPAY](https://www.youtube.com/watch?v=h3UPG8CuPAY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UChvithwOECK5g_19TjldMKw
 - date published: 2023-01-13 15:00:32+00:00
 - user: None

Protect yourself online with Guardio - https://guard.io/laowhy86 

The USA just ran some war game scenarios, and it looks really bad for China, but the Chinese government has plans of its own. 

General Spalding with Jordan Harbinger - Episode 751
https://jordanharbinger.com/751 

Weekly Live show The China Show - https://www.youtube.com/@UCcukTqc1cJJ4K3c4uzxTzjA 

◘ Support me on Patreon to talk to me directly and support my work - http://www.patreon.com/laowhy86
◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

Crypto support 
◘ Bitcoin - bc1qrvvga0c4kn69rlte47q0tzrhugn9pf426tqhvm
◘ ETH -  0x456E5A9B875d4eF8DCb70eB1F7Fa376C520b206C

My documentaries - 
◘ Conquering Northern China:
https://vimeo.com/ondemand/conqueringnorthernchina
◘ Conquering Southern China
https://vimeo.com/ondemand/conqueringsouthernchina

Weekly Live show The China Show - https://www.youtube.com/advpodcasts
ADVChina - https://www.youtube.com/advchina
SerpentZA - https://www.youtube.com/serpentza
China Fact Chasers - https://www.youtube.com/c/ChinaFactChasers

◘ Donate and support this channel through Paypal http://paypal.me/cmilkrun

◘ OR Become a Sponsor on YouTube:
https://www.youtube.com/channel/UChvithwOECK5g_19TjldMKw/sponsor

◘ Join me every week for videos about China! Don't forget to subscribe!
http://www.youtube.com/laowhy86

Be a Laowinner!
Like comment subscribe!

◘ Facebook:
http://www.facebook.com/laowhy86

◘ Instagram: 
http://instagram.com/laowhy86

Sources - 
https://asia.nikkei.com/Politics/International-relations/Indo-Pacific/China-adopts-mild-tone-to-smooth-way-for-Xi-visit-to-U.S

https://www.theguardian.com/world/2016/oct/06/un-peacekeepers-refused-to-help-south-sudan-rebels-raped-aid-workers-report

https://mwi.usma.edu/beijings-blue-helmets-what-to-make-of-chinas-role-in-un-peacekeeping-in-africa/

https://qz.com/africa/728566/china-reacts-to-the-death-of-two-peacekeepers-in-south-sudan-with-grief-and-rage

https://www.cnn.com/2023/01/09/politics/taiwan-invasion-war-game-intl-hnk-ml/index.html

https://www.cnn.com/2023/01/09/asia/china-taiwan-combat-drills-intl-hnk-ml/index.html

https://www.reuters.com/world/china/taiwan-says-43-chinese-air-force-planes-crossed-taiwan-strait-median-line-2022-12-26/

https://theintercept.com/2022/12/30/russia-china-news-media-agreement/

https://www.nationalreview.com/2019/07/wolf-warrior-ii-tells-us-a-lot-about-china/

https://www.csis.org/events/report-launch%E2%80%95-first-battle-next-war-wargaming-chinese-invasion-taiwan

https://jordanharbinger.com/751
