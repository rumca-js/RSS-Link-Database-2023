# Source Newsweek, Source URL:https://www.newsweek.com/rss, Source language: en-US

## Kari Lake Rips Republican Proposing Changes to Arizona Election Law
 - [https://www.newsweek.com/kari-lake-rips-republican-stephen-richer-proposing-changes-arizona-election-law-1773775](https://www.newsweek.com/kari-lake-rips-republican-stephen-richer-proposing-changes-arizona-election-law-1773775)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 23:43:45+00:00
 - user: None

Maricopa County Recorder Stephen Richer proposed a list of changes to the state's election laws on Thursday.

## Kari Lake Supporter Sues Judge to Get Election Overturned
 - [https://www.newsweek.com/kari-lake-supporter-sues-judge-get-election-overturned-katie-hobbs-arizona-governor-election-1773769](https://www.newsweek.com/kari-lake-supporter-sues-judge-get-election-overturned-katie-hobbs-arizona-governor-election-1773769)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 22:44:52+00:00
 - user: None

Lake came up short in her race with Katie Hobbs in the November 8, 2022, election, but she refuses to accept the outcome.

## Russian Prisoners Turned Soldiers Could Become 'Politicians,' Official Says
 - [https://www.newsweek.com/russian-prisoners-turned-soldiers-could-become-politicians-official-says-1773764](https://www.newsweek.com/russian-prisoners-turned-soldiers-could-become-politicians-official-says-1773764)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 22:28:51+00:00
 - user: None

"They were prisoners but today they are heroes," a former Russian general and current Duma deputy said.

## Evidence Against Ana Walshe's Husband Keeps 'Piling Up', Ex-FBI Agent Says
 - [https://www.newsweek.com/evidence-ana-walshe-husband-brian-keeps-piling-fbi-1773766](https://www.newsweek.com/evidence-ana-walshe-husband-brian-keeps-piling-fbi-1773766)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 22:21:04+00:00
 - user: None

Ana Walshe, a 39-year-old woman from Cohasset, Massachusetts, has been missing since January 1.

## Donald Trump Jr. Says 'Pay Your Taxes' Hours After Trump Org Tax Fraud Fine
 - [https://www.newsweek.com/donald-trump-jr-says-pay-your-taxes-hours-after-trump-org-tax-fraud-fine-1773762](https://www.newsweek.com/donald-trump-jr-says-pay-your-taxes-hours-after-trump-org-tax-fraud-fine-1773762)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 22:13:28+00:00
 - user: None

The Trump Organization was fined $1.6 million on Friday for its conviction on 17 counts of tax fraud and other charges.

## Putin's New-Year Losses Pass 8,000 as Russia Claims Capture of Soledar
 - [https://www.newsweek.com/putins-new-year-losses-pass-8000-russia-claims-capture-soledar-1773758](https://www.newsweek.com/putins-new-year-losses-pass-8000-russia-claims-capture-soledar-1773758)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 22:01:38+00:00
 - user: None

Ukraine's military quickly rejected the claim and President Volodymyr Zelensky said that his troops "are protecting the state."

## Kari Lake Attacks RINOs Trying to 'Claw Back Control' of GOP
 - [https://www.newsweek.com/kari-lake-attacks-rino-trying-claw-back-control-gop-1773746](https://www.newsweek.com/kari-lake-attacks-rino-trying-claw-back-control-gop-1773746)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 21:30:19+00:00
 - user: None

In an interview on Friday, the former candidate for Arizona governor also praised November's MAGA candidates as "exceptional."

## 'Alpha Male' Mocked for Demanding All-Male M&M's: 'Weird Hill to Die On'
 - [https://www.newsweek.com/nick-adams-mocked-demanding-all-male-mms-social-media-twitter-response-1773760](https://www.newsweek.com/nick-adams-mocked-demanding-all-male-mms-social-media-twitter-response-1773760)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 21:29:11+00:00
 - user: None

Mars will honor women by selling "all-female" M&amp;M's for a limited time.

## Republicans Want to 'Phase Out' Electric Cars to Protect Fossil Fuels
 - [https://www.newsweek.com/republicans-want-phase-out-electric-cars-protect-fossil-fuels-1773757](https://www.newsweek.com/republicans-want-phase-out-electric-cars-protect-fossil-fuels-1773757)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 21:06:58+00:00
 - user: None

The proliferation of electric vehicles, they said, would be detrimental to Wyoming and the "ability for the country to efficiently engage in commerce."

## Biden Official Defends Transparency While Stonewalling Reporters
 - [https://www.newsweek.com/joe-biden-white-house-official-defends-transparency-while-stonewalling-reporters-1773737](https://www.newsweek.com/joe-biden-white-house-official-defends-transparency-while-stonewalling-reporters-1773737)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:59:10+00:00
 - user: None

Nearly every question about the classified documents found in President Joe Biden's possession was deferred to the White House counsel.

## Biden at Greater 'Criminal Risk' Than Trump for Documents Scandal: Lawyer
 - [https://www.newsweek.com/biden-greater-criminal-risk-trump-documents-scandal-lawyer-1773755](https://www.newsweek.com/biden-greater-criminal-risk-trump-documents-scandal-lawyer-1773755)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:47:12+00:00
 - user: None

"It's a crime to remove and stored classified documents and put them in an unauthorized location," attorney and conservative commentator Gregg Jarrett said.

## Fact Check: Can House Democrats Bring Motion to Vacate House Speaker?
 - [https://www.newsweek.com/fact-check-can-house-democrats-bring-motion-vacate-house-speaker-1773698](https://www.newsweek.com/fact-check-can-house-democrats-bring-motion-vacate-house-speaker-1773698)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:44:32+00:00
 - user: None

Claims suggest House Speaker Kevin McCarthy's (R-CA) hard-fought seat could yet be pulled from under him by Democrats.

## Ukraine Testing Weapons With Range Longer Than Biden Willing to Provide
 - [https://www.newsweek.com/ukraine-testing-longer-range-drones-biden-willing-provide-1773753](https://www.newsweek.com/ukraine-testing-longer-range-drones-biden-willing-provide-1773753)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:27:26+00:00
 - user: None

"If Washington decides to supply longer-range missiles to Kyiv, then it will be crossing a red line," Russian Foreign Ministry spokesperson Maria Zakharova said in September.

## What Happens When U.S. Reaches Debt Limit as Ceiling Inches Closer
 - [https://www.newsweek.com/what-happens-when-us-reaches-debt-limit-ceiling-inches-closer-janet-yellen-kevin-mccarthy-letter-1773749](https://www.newsweek.com/what-happens-when-us-reaches-debt-limit-ceiling-inches-closer-janet-yellen-kevin-mccarthy-letter-1773749)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:19:52+00:00
 - user: None

Treasury Secretary Janet Yellen warned House Speaker Kevin McCarthy that the U.S. government is projected to reach its debt limit on January 19.

## Trump's Impeachments May Be Irreversible as McCarthy Mulls Expunging
 - [https://www.newsweek.com/trumps-impeachments-may-irreversible-mccarthy-mulls-expunging-1773739](https://www.newsweek.com/trumps-impeachments-may-irreversible-mccarthy-mulls-expunging-1773739)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 20:01:40+00:00
 - user: None

No Congress has ever tried to expunge a presidential impeachment before. It's not exactly clear if it can.

## Fact Check: Is Switzerland Deploying 5,000 Troops to WEF in Davos?
 - [https://www.newsweek.com/fact-check-switzerland-deploying-5000-troops-wef-davos-1773715](https://www.newsweek.com/fact-check-switzerland-deploying-5000-troops-wef-davos-1773715)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:44:41+00:00
 - user: None

Rumors on social media suggest a brigade of troops will be flown in to guard Davos for the WEF.

## Putin's Military Strategy Ignores Key Principles of War: Ukraine Adviser
 - [https://www.newsweek.com/vladimir-putin-russia-military-strategy-ignores-principles-war-ukraine-adviser-comments-1773726](https://www.newsweek.com/vladimir-putin-russia-military-strategy-ignores-principles-war-ukraine-adviser-comments-1773726)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:38:12+00:00
 - user: None

"Ukraine understood how Russia would approach a conflict and prepared accordingly," one expert told Newsweek regarding the countries' military strategies.

## Putin's Biggest Weak Spot Exposed as Ukraine's Ambition Grows
 - [https://www.newsweek.com/putin-biggest-weak-spot-exposed-ukraine-ambition-grows-1773741](https://www.newsweek.com/putin-biggest-weak-spot-exposed-ukraine-ambition-grows-1773741)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:32:49+00:00
 - user: None

With his military struggling on the battlefield in Ukraine, Russian President Vladimir Putin may now have a larger issue to be concerned about.

## Serena vs. Venus Williams and More Iconic Moments as Australian Open Starts
 - [https://www.newsweek.com/australian-open-most-iconic-moments-serena-williams-1773703](https://www.newsweek.com/australian-open-most-iconic-moments-serena-williams-1773703)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:19:01+00:00
 - user: None

The Australian Open has brought a number of iconic moments from the "Serena Slam" to the youngest-ever Grand Slam winner, at the age of 16.

## How Virginia Driving Bill Could Tacitly Endorse Anti-Abortion Agenda
 - [https://www.newsweek.com/abortion-virginia-general-assembly-driving-bill-1773261](https://www.newsweek.com/abortion-virginia-general-assembly-driving-bill-1773261)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:10:31+00:00
 - user: None

The bill says that "any pregnant woman shall be considered two people for determining occupancy in high-occupancy vehicle lanes."

## Fact Check: Are Jailed Brazil Rioters Forcibly Injected With 'COVID Shots'?
 - [https://www.newsweek.com/fact-check-are-jailed-brazil-rioters-forcibly-injected-covid-shots-1773681](https://www.newsweek.com/fact-check-are-jailed-brazil-rioters-forcibly-injected-covid-shots-1773681)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:06:18+00:00
 - user: None

Viral post claims those jailed for storming the Brazilian government buildings have been vaccinated against their will, enraging anti-vaccine accounts.

## Putin Faces Internal Division Among Military Leaders: Ex-NATO Commander
 - [https://www.newsweek.com/putin-faces-internal-division-among-military-leaders-ex-nato-commander-1773733](https://www.newsweek.com/putin-faces-internal-division-among-military-leaders-ex-nato-commander-1773733)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:03:34+00:00
 - user: None

The Russian Defense Ministry announced that General Valery Gerasimov will lead Russian forces in Ukraine in place of General Sergei Surovikin.

## Mega Millions Drawing for 01/13/23, Friday Jackpot Is $1.35 Billion
 - [https://www.newsweek.com/mega-millions-drawing-01-13-23-friday-jackpot-135-billion-1773472](https://www.newsweek.com/mega-millions-drawing-01-13-23-friday-jackpot-135-billion-1773472)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 19:00:01+00:00
 - user: None

Feel lucky? It's the second-largest jackpot in the game's history and by far the biggest for any Friday the 13th.

## Brazil's Bolsonaro Perfected Trump's Jan. 6 | Opinion
 - [https://www.newsweek.com/brazils-bolsonaro-perfected-trumps-jan-6-opinion-1773731](https://www.newsweek.com/brazils-bolsonaro-perfected-trumps-jan-6-opinion-1773731)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:51:58+00:00
 - user: None

The extreme Right, in Brazil and abroad, remains a serious threat to democracy worldwide.

## Tesla Drops Model Prices: Here's How Much They've Gone Down
 - [https://www.newsweek.com/tesla-drops-model-prices-heres-how-much-theyve-gone-down-1773729](https://www.newsweek.com/tesla-drops-model-prices-heres-how-much-theyve-gone-down-1773729)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:48:03+00:00
 - user: None

Tesla's drop across the board, gaining access to EV tax credit

## Police May Have Missed Crucial Detail in Idaho Murder Case: Attorney
 - [https://www.newsweek.com/moscow-idaho-police-may-have-missed-detail-murder-case-attorney-says-1773724](https://www.newsweek.com/moscow-idaho-police-may-have-missed-detail-murder-case-attorney-says-1773724)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:34:34+00:00
 - user: None

Earlier this week, a judge in Washington ordered the search warrant for Bryan Kohberger's Washington State University apartment to remain sealed.

## Matt Gaetz Says Biden is in 'Best Scandal' He Could Ask For
 - [https://www.newsweek.com/matt-gaetz-says-biden-best-scandal-1773720](https://www.newsweek.com/matt-gaetz-says-biden-best-scandal-1773720)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:30:06+00:00
 - user: None

Gaetz claimed the discovery of documents in Biden's position will help Democrats on two fronts.

## Alexandria Ocasio-Cortez Defends Using Gas Stove After Backlash
 - [https://www.newsweek.com/alexandria-ocasio-cortez-defends-using-gas-stove-after-backlash-1773718](https://www.newsweek.com/alexandria-ocasio-cortez-defends-using-gas-stove-after-backlash-1773718)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:24:58+00:00
 - user: None

"Science evolves and gives us new knowledge with time," the New York congresswoman said in a video posted to social media.

## Starved to Death in an American Jail, the Man who Couldn't Pay $100 Bail
 - [https://www.newsweek.com/2023/01/20/starved-death-american-jail-man-who-couldnt-pay-100-bail-1773459.html](https://www.newsweek.com/2023/01/20/starved-death-american-jail-man-who-couldnt-pay-100-bail-1773459.html)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:19:20+00:00
 - user: None

Price, a developmentally disabled and severely mentally ill man, died of malnutrition and dehydration inside an Arkansas jail.

## Pakistan Warns Cash-Strapped Taliban Fighters May Join ISIS Amid Unrest
 - [https://www.newsweek.com/pakiston-warns-cash-strapped-taliban-fighters-may-join-isis-1773719](https://www.newsweek.com/pakiston-warns-cash-strapped-taliban-fighters-may-join-isis-1773719)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 18:15:33+00:00
 - user: None

"If the Taliban do not have enough money, they may lose some of their factions to ISIL-K," Pakistani ambassador to the U.N. Munir Akram told Newsweek.

## How Crocodiles Became Such Ruthless, Efficient Apex Predators
 - [https://www.newsweek.com/newsweek-com-how-crocodile-ruthless-efficient-apex-predator-1773709](https://www.newsweek.com/newsweek-com-how-crocodile-ruthless-efficient-apex-predator-1773709)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:59:50+00:00
 - user: None

Nile crocodiles are estimated to be responsible for 200 human deaths every year. Now, researchers have discovered the secret to their unbeatable hunting tactics.

## Kellyanne Conway Gives Trump the Harsh Reality About 2024 Race
 - [https://www.newsweek.com/kellyanne-conway-comments-essay-donald-trump-2024-presidential-election-1773710](https://www.newsweek.com/kellyanne-conway-comments-essay-donald-trump-2024-presidential-election-1773710)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:50:35+00:00
 - user: None

Conway wrote that Donald Trump's 2024 campaign should not be shrugged off, but his path to the presidency still may not be "smooth and secure."

## Russia Just Gave Another Hint That Second Draft Is Coming
 - [https://www.newsweek.com/russia-just-gave-another-hint-that-second-draft-coming-1773706](https://www.newsweek.com/russia-just-gave-another-hint-that-second-draft-coming-1773706)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:38:51+00:00
 - user: None

Though Russian attempts at a new wave of mobilization have not been confirmed, Ukraine claims that Moscow's mobilization attempts are not over.

## When Can We Expect Nuclear Fusion?
 - [https://www.newsweek.com/nuclear-fusion-when-ready-electricity-technology-1773349](https://www.newsweek.com/nuclear-fusion-when-ready-electricity-technology-1773349)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:35:22+00:00
 - user: None

Developments in nuclear fusion are bringing us closer to using the technology to generate electricity, but we are still a long way away from it being ready.

## Forest Whitaker Talks 'Godfather of Harlem' Season 3 'Challenges' for Bumpy
 - [https://www.newsweek.com/godfather-harlem-forest-whitaker-giancarlo-esposito-season-three-bumpy-johnson-1773643](https://www.newsweek.com/godfather-harlem-forest-whitaker-giancarlo-esposito-season-three-bumpy-johnson-1773643)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:34:55+00:00
 - user: None

"Godfather of Harlem" stars Forest Whitaker and Giancarlo Esposito told Newsweek about what's in store for Bumpy Johnson and Adam Clayton Powell Jr. in Season 3

## '1923': Brandon Sklenar's Inspiration Behind 'Masculine Archetype' Spencer
 - [https://www.newsweek.com/1923-brandon-sklenar-masculine-archetype-spencer-dutton-1773672](https://www.newsweek.com/1923-brandon-sklenar-masculine-archetype-spencer-dutton-1773672)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:34:33+00:00
 - user: None

Breakout star of "Yellowstone" prequel show "1923," Brandon Sklenar spoke to Newsweek about playing Spencer Dutton.

## Cringe as Man's Photo of Overweight Doppelganger Turns Out to Be Friend
 - [https://www.newsweek.com/man-takes-photo-friend-overweight-doppelganger-cringe-1773599](https://www.newsweek.com/man-takes-photo-friend-overweight-doppelganger-cringe-1773599)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:29:54+00:00
 - user: None

"I died on the inside," said one Reddit user, while another advised the poster to "move to the sewers to escape the shame."

## Democrats Need Joe Manchin Whether They Like it or Not
 - [https://www.newsweek.com/democrats-need-joe-manchin-1773701](https://www.newsweek.com/democrats-need-joe-manchin-1773701)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:28:15+00:00
 - user: None

West Virginia Senator Joe Manchin is one of the only statewide elected Democrats in the state. He's also probably the only one who can win.

## Man Films Epic Sledding Fail With His Golden Retriever: 'Immediately No'
 - [https://www.newsweek.com/golden-retriever-snow-sledding-viral-tiktok-dogs-1773684](https://www.newsweek.com/golden-retriever-snow-sledding-viral-tiktok-dogs-1773684)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:28:10+00:00
 - user: None

Several users on TikTok were amused by the dog's reaction in the video.

## What Size Is a Clouded Leopard? Animal Missing From Dallas Zoo
 - [https://www.newsweek.com/clouded-leopard-missing-dallas-zoo-size-how-big-1773713](https://www.newsweek.com/clouded-leopard-missing-dallas-zoo-size-how-big-1773713)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:27:27+00:00
 - user: None

The zoo said the wild cat, which remains missing, is "non-dangerous."

## Trump Org's Fine for Tax Fraud is Less Than 1 Percent of Trump's Fortune
 - [https://www.newsweek.com/trump-orgs-fine-tax-fraud-less-1-percent-trumps-fortune-1773696](https://www.newsweek.com/trump-orgs-fine-tax-fraud-less-1-percent-trumps-fortune-1773696)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:23:23+00:00
 - user: None

A prosecutor in the case admitted that the fine will have a "minimal impact" on the Trump Organization.

## Golden Retriever Owner Warned Not to Get a 2nd Dog Shares Duo's Special Bond
 - [https://www.newsweek.com/golden-retriever-gets-friend-puppy-2nd-dog-think-twice-1773662](https://www.newsweek.com/golden-retriever-gets-friend-puppy-2nd-dog-think-twice-1773662)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:22:59+00:00
 - user: None

A video of a golden retriever loving their new puppy has received more than 1.3 million views on TikTok, but their owner was told, "Two dogs is a lot of work."

## Putin's Planning for Retirement, Has Eyes on 3 Successors: Ex-Speechwriter
 - [https://www.newsweek.com/putins-planning-retirement-has-eyes-3-successors-ex-speechwriter-1773697](https://www.newsweek.com/putins-planning-retirement-has-eyes-3-successors-ex-speechwriter-1773697)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:18:47+00:00
 - user: None

A former associate of the Russian president believes he will sit out the next election.

## Russian Diplomat Sets Out Key Condition for Talks with Ukraine
 - [https://www.newsweek.com/russian-diplomat-sets-out-key-condition-talks-ukraine-1773664](https://www.newsweek.com/russian-diplomat-sets-out-key-condition-talks-ukraine-1773664)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:14:12+00:00
 - user: None

Alexey Polishchuk said there are around 20 proposals from different countries to mediate the conflict, but not all could be trusted.

## Kanye West Dropped Hint About New Romance Last Month Amid Missing Rumors
 - [https://www.newsweek.com/kanye-west-dropped-hint-new-romance-bianca-censori-missing-rumors-1773691](https://www.newsweek.com/kanye-west-dropped-hint-new-romance-bianca-censori-missing-rumors-1773691)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:07:52+00:00
 - user: None

Amid reports that he has wed Bianca Censori, it has emerged that West hinted about his relationship when he released a track in December 2022.

## Prince Harry, and Why Recollections Really Do Vary
 - [https://www.newsweek.com/newsweek-com-prince-harry-why-recollections-vary-grief-memory-spare-1773673](https://www.newsweek.com/newsweek-com-prince-harry-why-recollections-vary-grief-memory-spare-1773673)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:07:44+00:00
 - user: None

When Prince Harry's long-awaited memoir, Spare, hit bookshops on January 10, readers were quick to point out discrepancies in his recollections.

## Hilarious Moment Pet Owners Accidentally Lock Themselves in Dog Crates
 - [https://www.newsweek.com/viral-tiktok-shows-people-stuck-dog-crate-1773679](https://www.newsweek.com/viral-tiktok-shows-people-stuck-dog-crate-1773679)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 17:04:41+00:00
 - user: None

Dog owners unintentionally lock themselves in their dogs' crates during viral TikTok

## Trump's Impeachment Lawyer Has Had Enough of Steve Bannon
 - [https://www.newsweek.com/trumps-impeachment-lawyer-has-had-enough-steve-bannon-1773650](https://www.newsweek.com/trumps-impeachment-lawyer-has-had-enough-steve-bannon-1773650)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:58:04+00:00
 - user: None

David Schoen, who represented Trump in his second impeachment trial, asked a New York judge to take him off Bannon's fraud case.

## Marjorie Taylor Greene Addresses Feud With Lauren Boebert
 - [https://www.newsweek.com/marjorie-taylor-greene-addresses-feud-lauren-boebert-1773651](https://www.newsweek.com/marjorie-taylor-greene-addresses-feud-lauren-boebert-1773651)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:55:04+00:00
 - user: None

The Georgia Republican made the comments during a recent episode of the podcast "From the Kitchen Table: The Duffys."

## Joe Manchin's Worst Nightmare Could Be About to Come True
 - [https://www.newsweek.com/joe-manchin-worst-nightmare-jim-justice-senate-1773677](https://www.newsweek.com/joe-manchin-worst-nightmare-jim-justice-senate-1773677)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:48:21+00:00
 - user: None

Jim Justice, Republican governor of West Virginia, said, "I'm sure I would seriously consider running for Senate" against Democrat holder Manchin.

## Sinkholes Set to Swallow Chunks of California After Rain and Flooding
 - [https://www.newsweek.com/sinkholes-could-swallow-chunks-california-after-rain-flooding-1773660](https://www.newsweek.com/sinkholes-could-swallow-chunks-california-after-rain-flooding-1773660)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:45:01+00:00
 - user: None

There is a "very strong and well-established" link between heavy rain or flooding and the formation of sinkholes, geoscientist Timothy Bechtel told Newsweek.

## Prince Harry's 'Scathing' Attack of Palace Aides Won't Help Bullying Claim
 - [https://www.newsweek.com/prince-harry-attack-palace-aides-undermine-bullying-denial-book-podcast-1773605](https://www.newsweek.com/prince-harry-attack-palace-aides-undermine-bullying-denial-book-podcast-1773605)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:44:19+00:00
 - user: None

A new episode of Newsweek's "Royal Report" podcast discusses Harry's unflattering name calling, directed at palace staff as part of his new book.

## Mom Neglecting Newborn Triplets by Leaving Them Crying Alone Inside Backed
 - [https://www.newsweek.com/mom-leaving-newborn-triplets-crying-alone-overwhelmed-1773523](https://www.newsweek.com/mom-leaving-newborn-triplets-crying-alone-overwhelmed-1773523)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:40:52+00:00
 - user: None

"In order for you to step away so you can regroup, even momentarily, your baby's safety is paramount," a New York pediatrician told Newsweek.

## Alex Jones Celebrates Women 'Throwing Themselves' at Him After Lawsuits
 - [https://www.newsweek.com/alex-jones-celebrates-women-throwing-themselves-after-lawsuit-1773688](https://www.newsweek.com/alex-jones-celebrates-women-throwing-themselves-after-lawsuit-1773688)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:39:56+00:00
 - user: None

Jones was recently ordered to pay $1 billion in damages to the families of Sandy Hook victims following a defamation lawsuit.

## Joe Biden's Classified Documents Batches—What We Do Know, What We Don't
 - [https://www.newsweek.com/joe-biden-classified-documents-trump-mar-lago-1773284](https://www.newsweek.com/joe-biden-classified-documents-trump-mar-lago-1773284)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:39:02+00:00
 - user: None

Newsweek's Fact Check team sifts through the allegations that the president mishandled classified documents.

## Cat With Two Baby Mamas Has Internet in Hysterics: 'Co-Parenting'
 - [https://www.newsweek.com/cat-dad-two-baby-mamas-internet-hysterics-co-parenting-1773647](https://www.newsweek.com/cat-dad-two-baby-mamas-internet-hysterics-co-parenting-1773647)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:34:29+00:00
 - user: None

"'Sister Wives' cats edition?" asked one TikTok user, while another dubbed the felines a "throuple."

## Five Major Things Netflix's 'The Hatchet Wielding Hitchhiker' Misses Out On
 - [https://www.newsweek.com/hatchet-wielding-hitchhiker-kai-lawrence-trial-leave-out-joseph-galfy-death-1773631](https://www.newsweek.com/hatchet-wielding-hitchhiker-kai-lawrence-trial-leave-out-joseph-galfy-death-1773631)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:29:48+00:00
 - user: None

Kai Lawrence and his arrest are the subject of new Netflix true-crime documentary "The Hatchet Wielding Hitchhiker" but the film does not show his 2019 trial.

## McDonald's Stokes Burger King Rivalry With Hilarious Sign: 'The Beef'
 - [https://www.newsweek.com/mcdonalds-stokes-burger-king-rivalry-hilarious-sign-beef-1773652](https://www.newsweek.com/mcdonalds-stokes-burger-king-rivalry-hilarious-sign-beef-1773652)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:19:34+00:00
 - user: None

A branch of the Golden Arches in Jacksonville, Florida, has been accused of putting up an "inflammatory" sign aimed at their nearby fast-food rivals.

## Kari Lake Shares Election Update From Court of Appeals
 - [https://www.newsweek.com/kari-lake-shares-election-update-court-appeals-1773625](https://www.newsweek.com/kari-lake-shares-election-update-court-appeals-1773625)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:14:54+00:00
 - user: None

The Arizona court agreed to treat Lake's case as a "special action petition" and to anticipate the date of the hearing.

## Russia Running Out of Military Reserves as Sanctions Take Toll—Ukraine
 - [https://www.newsweek.com/russia-running-out-military-reserves-sanctions-take-toll-ukraine-olha-stefanishyna-1773635](https://www.newsweek.com/russia-running-out-military-reserves-sanctions-take-toll-ukraine-olha-stefanishyna-1773635)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:11:42+00:00
 - user: None

The ongoing war in Ukraine is "exhausting" Moscow's forces and economy, Ukraine's deputy prime minister, Olha Stefanishyna, said.

## Russia Turning to Prison Labor as It Struggles to Make Enough Weapons: U.K.
 - [https://www.newsweek.com/russia-using-prison-labor-make-weapons-u-k-1773637](https://www.newsweek.com/russia-using-prison-labor-make-weapons-u-k-1773637)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:09:51+00:00
 - user: None

The Kremlin admitted in October that it did not have enough equipment and that it was taking "vigorous measures" to address the problem.

## 'I'm an American Living in Britain. It's Not What You'd Expect'
 - [https://www.newsweek.com/american-living-britain-london-cultural-differences-1773542](https://www.newsweek.com/american-living-britain-london-cultural-differences-1773542)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:08:50+00:00
 - user: None

The first difference I noticed I can't get used to even after so many years of living here in Britain.

## Owners Share How Sleeping With Their Two Huskies Goes Every Night
 - [https://www.newsweek.com/owners-sleeping-two-huskies-dogs-every-night-video-1773659](https://www.newsweek.com/owners-sleeping-two-huskies-dogs-every-night-video-1773659)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:08:35+00:00
 - user: None

"The real question is where does the husky go every couple hours," one user said.

## Russia Accidentally Blows Up Its Own Tank During Repairs: Report
 - [https://www.newsweek.com/russia-accidentally-blows-tank-belgorod-1773639](https://www.newsweek.com/russia-accidentally-blows-tank-belgorod-1773639)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:05:23+00:00
 - user: None

A fire reportedly caused ammunition to detonate, destroying one tank and damaging two others nearby.

## Man Finds 9ft Python in His House, Scared for Children
 - [https://www.newsweek.com/man-python-house-scared-children-1773656](https://www.newsweek.com/man-python-house-scared-children-1773656)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:01:39+00:00
 - user: None

The python had recently feasted on a very large meal, as it was found with a bulging stomach.

## 'RHOP' Exclusive: Robyn Slams 'Crafty' Karen Amid Heated Charrisse Feud
 - [https://www.newsweek.com/rhop-spoilers-karen-huger-charisse-jackson-feud-fight-robyn-dixon-1773352](https://www.newsweek.com/rhop-spoilers-karen-huger-charisse-jackson-feud-fight-robyn-dixon-1773352)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 16:00:01+00:00
 - user: None

"The behavior last night is extremely contradictory of the person and the woman Karen tries to present herself to be," says Robyn Dixon of her "RHOP" co-star.

## Great Pyrenees Dad Takes Things 'Too Far' When Playing With Puppies
 - [https://www.newsweek.com/great-pyrenees-dad-takes-too-far-playing-puppies-kentucky-1773634](https://www.newsweek.com/great-pyrenees-dad-takes-too-far-playing-puppies-kentucky-1773634)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:57:41+00:00
 - user: None

"Just like a dad to get them all riled up before bedtime," joked one commenter on the TikTok video that has more than 1.4 million views.

## Cory Monteith's Friend Thinks His Lea Michele Stories Will 'Shock People'
 - [https://www.newsweek.com/cory-monteith-friend-justin-neill-thinks-lea-michele-stories-shock-people-interview-1773601](https://www.newsweek.com/cory-monteith-friend-justin-neill-thinks-lea-michele-stories-shock-people-interview-1773601)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:50:54+00:00
 - user: None

Justin Neill, who features on the Discovery+ series 'The Price of Glee,' spoke to Newsweek about rumors surrounding Lea Michele.

## Why We Shouldn't Put Politicians in Charge of Key Infrastructure | Opinion
 - [https://www.newsweek.com/why-we-shouldnt-put-politicians-charge-key-infrastructure-opinion-1773422](https://www.newsweek.com/why-we-shouldnt-put-politicians-charge-key-infrastructure-opinion-1773422)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:50:38+00:00
 - user: None

The episode left the Federal Aviation Administration—the largest U.S. transportation agency in terms of staff—with egg on its face.

## Bride and Groom Share Their Unusual Way of Sealing Their Marriage: 'Iconic'
 - [https://www.newsweek.com/bride-groom-share-unusual-way-sealing-marriage-tequila-wedding-vowels-1773628](https://www.newsweek.com/bride-groom-share-unusual-way-sealing-marriage-tequila-wedding-vowels-1773628)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:43:43+00:00
 - user: None

The wedding videographer told Newsweek the guests "cheered and clapped" after the couple downed their shots.

## Trump Organization Fined $1.6 Million for Tax Fraud
 - [https://www.newsweek.com/trump-organization-fine-tax-fraud-1773608](https://www.newsweek.com/trump-organization-fine-tax-fraud-1773608)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:41:43+00:00
 - user: None

The former president's family business was previously found guilty of 17 financial crimes following a trial in New York.

## Deadly Tornadoes Hit South Live Updates: Dozens of Staff, Children Escape Selma Daycare
 - [https://www.newsweek.com/deadly-tornadoes-hit-south-live-updates-seven-dead-alabama-georgia-1773654](https://www.newsweek.com/deadly-tornadoes-hit-south-live-updates-seven-dead-alabama-georgia-1773654)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:25:36+00:00
 - user: None

At least eight people are dead and a dozen injured after tornadoes ripped through the Southern U.S. Follow for the latest.

## Democrat Reaches for Trump Playbook as He Questions Biden Documents Timing
 - [https://www.newsweek.com/democrat-trump-playbook-joe-biden-documents-1773622](https://www.newsweek.com/democrat-trump-playbook-joe-biden-documents-1773622)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:22:19+00:00
 - user: None

"Things can be planted in places and then discovered conveniently—that may be what has occurred here," congressman Hank Johnson said.

## Who Is Bianca Censori? Meet Kanye West's Yeezy Head of Architecture
 - [https://www.newsweek.com/who-bianca-censori-kanye-west-yeezy-architect-married-1773573](https://www.newsweek.com/who-bianca-censori-kanye-west-yeezy-architect-married-1773573)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:05:31+00:00
 - user: None

Kanye West has been spotted dining with Bianca Censori and the rapper was reportedly wearing a ring on his wedding finger.

## Video of Keenan Anderson's Arrest and Tasering Viewed 350,000 Times
 - [https://www.newsweek.com/keenan-anderson-arrest-tasering-video-viral-1773619](https://www.newsweek.com/keenan-anderson-arrest-tasering-video-viral-1773619)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 15:03:59+00:00
 - user: None

Anderson died after suffering a cardiac arrest after being repeatedly tasered by police in Los Angeles.

## Hilarious Clip Shows Rottweiler vs. Shaving Cream Aftermath: 'It's Snowing'
 - [https://www.newsweek.com/hilarious-clip-rottweiler-shaving-cream-aftermath-snowing-1773611](https://www.newsweek.com/hilarious-clip-rottweiler-shaving-cream-aftermath-snowing-1773611)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:54:02+00:00
 - user: None

"Wanted to say it wasn't me, but the evidence is all over his face, you are on your own," joked one TikTok user.

## How 'Single's Inferno' Cast Are Handling Fame and What They Said About Show
 - [https://www.newsweek.com/what-happened-singles-inferno-cast-season-two-netflix-fame-instagram-1773624](https://www.newsweek.com/what-happened-singles-inferno-cast-season-two-netflix-fame-instagram-1773624)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:52:59+00:00
 - user: None

The cast of "Single's Inferno" Season 2, the hit Korean dating series on Netflix, reflect on their experiences of being in the show, lessons learned and more.

## Heavily Entangled Right Whale Covered in Wounds and Lice 'Likely to Die'
 - [https://www.newsweek.com/heavily-entangled-right-whale-covered-wounds-lice-likely-die-1773616](https://www.newsweek.com/heavily-entangled-right-whale-covered-wounds-lice-likely-die-1773616)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:42:25+00:00
 - user: None

The whale is only 4 years old, and its species is endangered, with only 350 remaining in the world.

## Demanding Cat Caught on Camera Waking Dad Up at 4am for Breakfast: 'Claws'
 - [https://www.newsweek.com/cat-caught-camera-waking-dad-breakfast-tiktok-1773560](https://www.newsweek.com/cat-caught-camera-waking-dad-breakfast-tiktok-1773560)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:35:04+00:00
 - user: None

"My cat tries to wake the baby so I will get up. He's truly an evil genius," sympathized one TikTok user.

## Internet Impressed as Rottweiler Destroys 6ft Cardboard Box: 'Recycling'
 - [https://www.newsweek.com/viral-tiktok-destrutive-rottweiler-goes-mad-cardboard-box-1773594](https://www.newsweek.com/viral-tiktok-destrutive-rottweiler-goes-mad-cardboard-box-1773594)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:34:49+00:00
 - user: None

A mischievous rottweiler has been captured gnawing at a six-foot cardboard box in a viral video.

## Drunk Bear on the Run After Guzzling Rum Cocktail and Raiding Store
 - [https://www.newsweek.com/drunk-black-bear-rum-stealing-food-1773613](https://www.newsweek.com/drunk-black-bear-rum-stealing-food-1773613)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:25:25+00:00
 - user: None

The Himalayan black bear returned to the village in Bhutan to drink alcohol and steal food multiple times.

## 'RHOSLC' Reunion Trailer: Heather Gay Grilled Over Black Eye and Jen Shah
 - [https://www.newsweek.com/rhoslc-reunion-trailer-heather-gay-jen-shah-black-eye-what-happened-1773487](https://www.newsweek.com/rhoslc-reunion-trailer-heather-gay-jen-shah-black-eye-what-happened-1773487)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:20:18+00:00
 - user: None

Jen Shah, who was sentenced to six-and-a-half years in prison on January 6, did not take part in "The Real Housewives of Salt Lake City" Season 3 reunion.

## Lisa Marie Presley Subtly Supported Will Smith Before Death
 - [https://www.newsweek.com/lisa-marie-presley-subtly-supported-will-smith-before-death-1773591](https://www.newsweek.com/lisa-marie-presley-subtly-supported-will-smith-before-death-1773591)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:13:33+00:00
 - user: None

Hours before her sudden death, Presley spent some time on Twitter, where a post regarding Smith caught her eye.

## From University To MetaVersity
 - [https://www.newsweek.com/university-metaversity-1773405](https://www.newsweek.com/university-metaversity-1773405)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:00:08+00:00
 - user: None

Imagine the authenticity of learning when plagiarism is combated with NFTs and knowledge is experienced, not just accessed.

## Russian Wives Say Soldiers Given 'Punishment for the Truth' After Video
 - [https://www.newsweek.com/russian-wives-soldiers-ukraine-punishment-video-1773604](https://www.newsweek.com/russian-wives-soldiers-ukraine-punishment-video-1773604)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 14:00:08+00:00
 - user: None

Russian mobilized soldiers were reportedly punished after complaining that they were being forced to live in icy trenches in freezing temperatures.

## Cute Kid's Interview With Raiders' Davante Adams Goes Viral—'A Natural'
 - [https://www.newsweek.com/cute-kid-interview-raiders-davante-adams-goes-viral-1773586](https://www.newsweek.com/cute-kid-interview-raiders-davante-adams-goes-viral-1773586)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:58:35+00:00
 - user: None

Determined 10-year-old pitchside reporter Jeremiah has stolen the hearts of many with his interview with Las Vegas Raiders star Davante Adams

## Mayor Pete's Major Problem
 - [https://www.newsweek.com/mayor-pete-major-problem-travel-chaos-blame-1773551](https://www.newsweek.com/mayor-pete-major-problem-travel-chaos-blame-1773551)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:41:08+00:00
 - user: None

Several Republicans pointed their fingers at Pete Buttigieg following the travel chaos that swept across the U.S. this week. But is he really to blame?

## Kevin McCarthy's Promise Could Backfire Spectacularly for Republicans
 - [https://www.newsweek.com/kevin-mccarthy-security-footage-jan6-gaetz-1773569](https://www.newsweek.com/kevin-mccarthy-security-footage-jan6-gaetz-1773569)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:40:15+00:00
 - user: None

The House Speaker wants the public to see exactly "what happened" during the Capitol attack on January 6, 2021, by releasing all the security footage.

## Man Backed for Refusing to Take in Dead Dad's Step-Daughter: 'Blocked'
 - [https://www.newsweek.com/man-backed-refusing-take-dead-dad-step-daughter-blocked-1773526](https://www.newsweek.com/man-backed-refusing-take-dead-dad-step-daughter-blocked-1773526)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:39:48+00:00
 - user: None

The man rejected the girl's grandparents' pleas for a change of heart, telling them he "didn't care what my dad wanted."

## Harry and Meghan's Body Language Secrets Using Green Line Relationship Test
 - [https://www.newsweek.com/prince-harry-meghan-markle-relationship-body-language-green-line-test-1773308](https://www.newsweek.com/prince-harry-meghan-markle-relationship-body-language-green-line-test-1773308)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:33:36+00:00
 - user: None

"To use body language to judge a relationship, you need to look at where all the parts of their body are," a forensic psychiatrist told Newsweek.

## Is Lake Shasta's Water Level Rising?
 - [https://www.newsweek.com/newsweek-com-lake-shasta-water-level-rising-1773582](https://www.newsweek.com/newsweek-com-lake-shasta-water-level-rising-1773582)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:31:40+00:00
 - user: None

Over 13 inches of rain fell on Lake Shasta in the first 11 days of January as California was pummeled by six storms.

## Young Voters Showed Up to Vote for Congress—Will Congress Show Up for Them?
 - [https://www.newsweek.com/young-voters-showed-vote-congresswill-congress-show-them-1773398](https://www.newsweek.com/young-voters-showed-vote-congresswill-congress-show-them-1773398)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:30:29+00:00
 - user: None

Young Americans have shown up at the polls; now it's time for Congress to show up for them.

## Prince Harry Now Embroiled in TK Maxx Beef as Retailer Denies His Claims
 - [https://www.newsweek.com/prince-harry-tk-maxx-denies-claims-book-1773553](https://www.newsweek.com/prince-harry-tk-maxx-denies-claims-book-1773553)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:22:18+00:00
 - user: None

Harry claims to have loved shopping in the discount retailer's annual sale in his new memoir. However, the brand insists: "We don't actually do sales."

## Laughter at Staffordshire Bull Terrier's Tantrum Over 4-minute Late Dinner
 - [https://www.newsweek.com/laughter-staffordshire-bull-terrier-tantrum-over-4-minute-late-dinner-1773554](https://www.newsweek.com/laughter-staffordshire-bull-terrier-tantrum-over-4-minute-late-dinner-1773554)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:21:07+00:00
 - user: None

"He's gonna waste away," wrote one TikTok user, while another posted about the viral video, "The lip smack, love a dramatic munchieeee."

## 'Hunters' S2 Cast: Why Hunting Nazis Is More 'Relevant' Than Ever
 - [https://www.newsweek.com/hunters-season2-cast-interview-hunting-nazis-more-relevant-ever-prime-video-1773549](https://www.newsweek.com/hunters-season2-cast-interview-hunting-nazis-more-relevant-ever-prime-video-1773549)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:13:51+00:00
 - user: None

Logan Lerman and Josh Radnor spoke to Newsweek ahead of the launch of Season 2 of "Hunters," out now on Prime Video.

## Young Men Like Me Deserve Better Role Models Than Prince Harry | Opinion
 - [https://www.newsweek.com/young-men-like-me-deserve-better-role-models-prince-harry-opinion-1773417](https://www.newsweek.com/young-men-like-me-deserve-better-role-models-prince-harry-opinion-1773417)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 13:00:01+00:00
 - user: None

The Duke of Sussex renounced it all, and in doing so, he also denounced his country, scoffed at tradition, and estranged his family.

## Odell Beckham Jr.'s Airplane Cheese-Board Drama: A Timeline
 - [https://www.newsweek.com/odell-beckham-airplane-cheese-board-drama-timeline-1773563](https://www.newsweek.com/odell-beckham-airplane-cheese-board-drama-timeline-1773563)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:44:25+00:00
 - user: None

Newly released bodycam footage has shown exactly what happened when the NFL wide receiver was escorted off a plane by police at Miami airport in November.

## California Drought Monitor Status Before and After Rain
 - [https://www.newsweek.com/california-drought-impact-rain-1773559](https://www.newsweek.com/california-drought-impact-rain-1773559)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:43:17+00:00
 - user: None

Much of California has received between 400 and 600 percent above average rainfall for January, pulling parts of the state out of extreme drought.

## Brian Walshe Had History of Art Fraud, Meddling With Inheritance
 - [https://www.newsweek.com/brian-walshe-art-fraud-meddling-inheritance-1773550](https://www.newsweek.com/brian-walshe-art-fraud-meddling-inheritance-1773550)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:42:47+00:00
 - user: None

Ron Rivlin, who mistakenly bought two fake Andy Warhol paintings from Walshe, called the sale "an Oscar-winning performance."

## California Videos Show Salinas River Overflowing After Extreme Rain
 - [https://www.newsweek.com/california-storm-flooding-salinas-river-overflowing-videos-1773571](https://www.newsweek.com/california-storm-flooding-salinas-river-overflowing-videos-1773571)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:38:23+00:00
 - user: None

Dramatic images show the river bursting its banks, with local officials warning the Monterey Peninsula could become an island due to floodwater.

## Leah Remini, John Travolta Lead Lisa Marie Presley Tributes After Death
 - [https://www.newsweek.com/lisa-marie-presley-dead-celebrities-react-1773519](https://www.newsweek.com/lisa-marie-presley-dead-celebrities-react-1773519)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:31:37+00:00
 - user: None

The daughter of Elvis and Priscilla Presley died from suspected cardiac arrest.

## Lisa Marie Presley's Sudden Death Sparks COVID Vaccine Conspiracy Theories
 - [https://www.newsweek.com/lisa-marie-presley-sudden-death-covid-vaccine-conspiracy-theories-travis-tritt-1773567](https://www.newsweek.com/lisa-marie-presley-sudden-death-covid-vaccine-conspiracy-theories-travis-tritt-1773567)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:30:47+00:00
 - user: None

Several Twitter users pushed back amid questions over whether the singer-songwriter had recently taken the vaccine.

## Congress Military Vets Worried For National Defense Amid Turmoil in House
 - [https://www.newsweek.com/congress-military-vets-worried-national-defense-amid-turmoil-house-1773457](https://www.newsweek.com/congress-military-vets-worried-national-defense-amid-turmoil-house-1773457)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:27:39+00:00
 - user: None

"I don't want to see the 118th Congress fall down into chaos,"  Republican Representative Tony Gonzales told Newsweek.

## Recent Rain at Lake Mead Gives Respite to Dwindling Water Levels
 - [https://www.newsweek.com/recent-rain-lake-mead-respite-dwindling-water-levels-1773576](https://www.newsweek.com/recent-rain-lake-mead-respite-dwindling-water-levels-1773576)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:22:46+00:00
 - user: None

Although the rain has brought a modicum relief to Lake Mead, it will be short lived as the region is still in the grips of a decades-long drought.

## Virtual Telescope Project Green Comet Live Stream: When To Watch
 - [https://www.newsweek.com/virtual-telescope-project-green-comet-live-stream-when-watch-1773556](https://www.newsweek.com/virtual-telescope-project-green-comet-live-stream-when-watch-1773556)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:13:19+00:00
 - user: None

Comet C/2022 E3 (ZTF) could soon be faintly visible to the naked eye.

## Divisive Taylor Swift Remarks Matt Healy Made Clearly Buried After 1975 Gig
 - [https://www.newsweek.com/matt-healy-taylor-swift-dating-misogyny-interview-1975-1773495](https://www.newsweek.com/matt-healy-taylor-swift-dating-misogyny-interview-1975-1773495)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:10:53+00:00
 - user: None

Taylor Swift made a surprise appearance at a 1975 show in London alongside the group's singer, whose past comments about the pop star had been criticized.

## Former Soviet Union Countries Are 'Our Territory,' Russian Academic Says
 - [https://www.newsweek.com/former-soviet-union-countries-russian-territory-state-tv-1773578](https://www.newsweek.com/former-soviet-union-countries-russian-territory-state-tv-1773578)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:09:43+00:00
 - user: None

"This is our land, our territory of strategic interests," Henry Sardaryan, dean at the Moscow State Institute of International Relations, said on state TV.

## 'I Almost Died. It Was the Best Thing That Ever Happened to Me'
 - [https://www.newsweek.com/pneumonia-almost-died-covid-doctor-blessing-1773533](https://www.newsweek.com/pneumonia-almost-died-covid-doctor-blessing-1773533)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:02:52+00:00
 - user: None

When Dr. Chris Chen contracted COVID-related pneumonia in 2020, he was left fighting for his life in ICU.

## It's Time To Bring Justice and Equity to Climate and Health | Opinion
 - [https://www.newsweek.com/its-time-bring-justice-equity-climate-health-opinion-1773129](https://www.newsweek.com/its-time-bring-justice-equity-climate-health-opinion-1773129)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 12:00:01+00:00
 - user: None

The global dependence on fossil fuels deepens health inequity, with countries producing the least emissions suffering the most. Business could lead the way by strengthening climate-resilient health systems to reduce the gap.

## How NBC's Big Schedule Change Affects 'Blacklist', 'Magnum P.I' and More
 - [https://www.newsweek.com/nbc-midseason-schedule-change-impact-blacklist-magnum-pi-found-delayed-1773539](https://www.newsweek.com/nbc-midseason-schedule-change-impact-blacklist-magnum-pi-found-delayed-1773539)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:56:42+00:00
 - user: None

NBC has announced the network will be making changes to its drama schedule, with some shows being delayed and others changing dates.

## Adult Kid Pretending Not to Recognize Parents After Sister's Death Praised
 - [https://www.newsweek.com/family-conflict-estranged-child-parent-reddit-viral-1773503](https://www.newsweek.com/family-conflict-estranged-child-parent-reddit-viral-1773503)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:55:11+00:00
 - user: None

A licensed clinical social worker told Newsweek that the child "has every right to make clear boundaries" with their parents.

## Is the Deep State Coming After Joe Biden? | Opinion
 - [https://www.newsweek.com/deep-state-coming-after-joe-biden-opinion-1773468](https://www.newsweek.com/deep-state-coming-after-joe-biden-opinion-1773468)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:30:01+00:00
 - user: None

There are many, many open questions here.

## Prince Harry Thanks Gwyneth Paltrow Chiropractor, String of Therapists—Book
 - [https://www.newsweek.com/prince-harry-thanks-gwyneth-paltrow-chiropractor-therapists-book-spare-1773510](https://www.newsweek.com/prince-harry-thanks-gwyneth-paltrow-chiropractor-therapists-book-spare-1773510)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:16:27+00:00
 - user: None

In the acknowledgements for his book "Spare," Harry thanks experts and coaches for keeping him "physically and mentally strong," but not royal family members.

## California Mountain Lion Slaughters 27 Lambs but Did Not Eat a Single One
 - [https://www.newsweek.com/california-mountain-lion-slaughters-27-lambs-did-not-eat-single-one-1773517](https://www.newsweek.com/california-mountain-lion-slaughters-27-lambs-did-not-eat-single-one-1773517)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:12:44+00:00
 - user: None

Mountain lions are a protected species in California.

## Sean Hannity Demands Immediate Raid on All of Joe Biden's Properties
 - [https://www.newsweek.com/sean-hannity-joe-biden-search-classified-documents-1773522](https://www.newsweek.com/sean-hannity-joe-biden-search-classified-documents-1773522)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:07:47+00:00
 - user: None

The Fox News host said that the FBI had "no problem" searching Donald Trump's home during its attempts to retrieve classified materials.

## Why Biden Is Wrong About North Korea
 - [https://www.newsweek.com/why-biden-wrong-about-north-korea-1773499](https://www.newsweek.com/why-biden-wrong-about-north-korea-1773499)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:02:04+00:00
 - user: None

Secretary of State Antony Blinken criticized North Korea's "unlawful and reckless missile launches" on Wednesday.

## Take Dangerous Abortion Drugs Off The Market | Opinion
 - [https://www.newsweek.com/take-dangerous-abortion-drugs-off-market-opinion-1773043](https://www.newsweek.com/take-dangerous-abortion-drugs-off-market-opinion-1773043)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 11:00:01+00:00
 - user: None

The Biden administration's lethal innovation allows abortion pills to be sent by mail without any in-person exam.

## Marjorie Taylor Greene Insists She's 'Still The Same Person' After Backlash
 - [https://www.newsweek.com/marjorie-taylor-greene-insists-shes-still-same-person-after-backlash-1773511](https://www.newsweek.com/marjorie-taylor-greene-insists-shes-still-same-person-after-backlash-1773511)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:59:24+00:00
 - user: None

Infowars viewers called Greene "a fraud" for supporting Kevin McCarthy's House speakership bid.

## 'I Left': Woman Chooses Rescue Dogs and Dumps Man Who Hated Her Pets
 - [https://www.newsweek.com/woman-chooses-rescue-dogs-dumps-man-hated-pets-1773485](https://www.newsweek.com/woman-chooses-rescue-dogs-dumps-man-hated-pets-1773485)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:59:11+00:00
 - user: None

"Dogs are part of the family, and that's not something I am willing to compromise," Rachel Humphreys told Newsweek.

## 'I Rescue Babies Two Minutes After They're Abandoned'
 - [https://www.newsweek.com/i-rescue-babies-two-minutes-after-theyre-abandoned-1773280](https://www.newsweek.com/i-rescue-babies-two-minutes-after-theyre-abandoned-1773280)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:43:39+00:00
 - user: None

My own birth mom explained why she had abandoned me, and it was not the story that I had been told while growing up.

## Athena Brownfield Search Continues as Woman Arrested for Child Neglect
 - [https://www.newsweek.com/athena-brownfield-search-continues-woman-arrested-child-neglect-1773536](https://www.newsweek.com/athena-brownfield-search-continues-woman-arrested-child-neglect-1773536)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:42:42+00:00
 - user: None

Police are searching for the 4-year-old in Oklahoma, after she was reported missing on Tuesday, when Alysia Adams was meant to be caring for her and her sister.

## What Is the Largest Snake That Ever Existed?
 - [https://www.newsweek.com/largest-snake-ever-existed-titanoboa-1773531](https://www.newsweek.com/largest-snake-ever-existed-titanoboa-1773531)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:36:09+00:00
 - user: None

The Titanoboa—the largest known snake to ever exist—was as long as a school bus, growing to an estimated 50 feet long and 3 feet wide.

## Deadly Venomous Snake Found Hiding Inside Printer Paper Drawer
 - [https://www.newsweek.com/eastern-brown-snake-rescued-printer-australia-1773514](https://www.newsweek.com/eastern-brown-snake-rescued-printer-australia-1773514)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:31:39+00:00
 - user: None

Eastern brown snakes were responsible for more than 75 percent of all fatal snakebites in Australia between 2005 and 2015.

## What Kai 'The Hitchhiker' Lawrence Has Said Since Viral Clip: 'Still Scars'
 - [https://www.newsweek.com/kai-lawrence-interview-netflix-hatchet-wielding-hitchhiker-now-1773478](https://www.newsweek.com/kai-lawrence-interview-netflix-hatchet-wielding-hitchhiker-now-1773478)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:19:36+00:00
 - user: None

Kai Lawrence is the subject of a new Netflix documentary titled "The Hatchet Wielding Hitchhiker" and he has spoken publicly on several occasions.

## Debate as Spouse Demands Husband Gets a 2nd Job To Fund Their Lifestyle
 - [https://www.newsweek.com/spouse-demands-husband-job-fund-lifestyle-delivery-driver-1773494](https://www.newsweek.com/spouse-demands-husband-job-fund-lifestyle-delivery-driver-1773494)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:11:05+00:00
 - user: None

A wife and mother feeling the pinch of the cost of living crisis is thinking of asking her husband to become a delivery driver.

## Russia Explains Military Activity in Belarus as Ukraine Guards Border
 - [https://www.newsweek.com/russia-explains-military-activity-belarus-ukraine-guards-border-1773496](https://www.newsweek.com/russia-explains-military-activity-belarus-ukraine-guards-border-1773496)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 10:05:12+00:00
 - user: None

Kyiv sought to play down fears that Moscow or Minsk could be preparing a fresh attack from the northwest.

## Idaho Republican Apologizes for Comparing Women to Farm Animals
 - [https://www.newsweek.com/idaho-republican-representative-apologizes-womens-health-farm-animals-1773507](https://www.newsweek.com/idaho-republican-representative-apologizes-womens-health-farm-animals-1773507)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:50:18+00:00
 - user: None

"I'm embarrassed, and I offended others in the process," Rep. Jack Nelsen said after comparing women's reproductive health to milking cows.

## Was Lisa Marie Presley's Cause of Death Cardiac Arrest? What We Know
 - [https://www.newsweek.com/lisa-marie-presley-cause-death-cardiac-arrest-1773504](https://www.newsweek.com/lisa-marie-presley-cause-death-cardiac-arrest-1773504)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:44:07+00:00
 - user: None

The singer-songwriter—the only child of rock 'n' roll legend Elvis Presley—died aged 54 on Thursday after being hospitalized earlier in the day.

## Missouri Republicans' Dress Code for Women Blasted: 'So Many Questions'
 - [https://www.newsweek.com/missouri-republicans-dress-code-women-blasted-so-many-questions-1773481](https://www.newsweek.com/missouri-republicans-dress-code-women-blasted-so-many-questions-1773481)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:37:16+00:00
 - user: None

The Republican-controlled Missouri House of Representatives approved changes to the chamber's dress code preventing women legislators from showing bare arms.

## Joe Biden Faces a Very Different Special Counsel From Donald Trump's
 - [https://www.newsweek.com/joe-biden-faces-very-different-special-counsel-donald-trump-1773476](https://www.newsweek.com/joe-biden-faces-very-different-special-counsel-donald-trump-1773476)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:36:16+00:00
 - user: None

Robert Hur spent a year overseeing the work of Special Counsel Robert Mueller when he was investigating Trump and has associations with the Republican Party.

## Prince William Says Princess Diana's Death Wouldn't 'Break' Him In Old Clip
 - [https://www.newsweek.com/prince-william-princess-diana-death-break-clip-viral-tiktok-1773473](https://www.newsweek.com/prince-william-princess-diana-death-break-clip-viral-tiktok-1773473)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:23:01+00:00
 - user: None

A clip of the prince talking about his reaction to Diana's death from 2017 has resurfaced following the release of Prince Harry's memoir, "Spare."

## Donald Trump Calls Special Counsel Investigating Him a 'Terrorist'
 - [https://www.newsweek.com/donald-trump-special-counsel-jack-smith-terrorist-1773489](https://www.newsweek.com/donald-trump-special-counsel-jack-smith-terrorist-1773489)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:21:44+00:00
 - user: None

The former president has repeatedly attacked Jack Smith, who is overseeing classified materials and Jan. 6 probes into Trump.

## Capture of Soledar Only 'Pyrrhic' Victory for Russia—ISW
 - [https://www.newsweek.com/soledar-bakhmut-updated-ukraine-russia-isw-1773501](https://www.newsweek.com/soledar-bakhmut-updated-ukraine-russia-isw-1773501)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 09:17:42+00:00
 - user: None

Soledar is "not an operationally significant development and is unlikely to presage an imminent Russian encirclement of Bakhmut," the think tank said.

## Today's Wordle #573 Hints, Tips and Answer for January 13 Puzzle
 - [https://www.newsweek.com/todays-wordle-573-hints-tips-answer-january-13-puzzle-1773484](https://www.newsweek.com/todays-wordle-573-hints-tips-answer-january-13-puzzle-1773484)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 08:42:20+00:00
 - user: None

Newsweek has some hints and tips to help you crack today's "Wordle" puzzle.

## 'Rick and Morty' Future in Doubt as Justin Roiland Faces Years in Prison
 - [https://www.newsweek.com/rick-morty-future-doubt-justin-roiland-faces-years-prison-1773491](https://www.newsweek.com/rick-morty-future-doubt-justin-roiland-faces-years-prison-1773491)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 08:37:57+00:00
 - user: None

Co-creator and voice actor on "Rick and Morty" Justin Roiland is facing a number of domestic violence charges from an incident in 2020.

## Alex Jones Accuses Piers Morgan of 'Mind Control' in Contentious Interview
 - [https://www.newsweek.com/alex-jones-accuses-piers-morgan-mind-control-contentious-interview-1773466](https://www.newsweek.com/alex-jones-accuses-piers-morgan-mind-control-contentious-interview-1773466)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 05:06:10+00:00
 - user: None

"Don't let Piers mind-control you," Jones told viewers shortly before Morgan called him "utterly contemptible" and ended their interview.

## Lisa Marie Presley's Memorable Golden Globes Moments Days Before Her Death
 - [https://www.newsweek.com/lisa-marie-presleys-memorable-golden-globes-moments-days-before-her-death-1773471](https://www.newsweek.com/lisa-marie-presleys-memorable-golden-globes-moments-days-before-her-death-1773471)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 04:37:24+00:00
 - user: None

Presley, the only child of rock 'n' roll legend Elvis Presley, died Thursday after being hospitalized earlier in the day. She was 54 years old.

## Pakistan Seeks Change to U.S. World Finance Control as Cuba Leads U.N. Bloc
 - [https://www.newsweek.com/pakistan-seeks-change-us-world-finance-control-cuba-leads-un-bloc-1773464](https://www.newsweek.com/pakistan-seeks-change-us-world-finance-control-cuba-leads-un-bloc-1773464)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 03:47:49+00:00
 - user: None

"As far as global governance ... the greatest structural issue is the control of the international financial system by the United States," Munir Akram said.

## Marjorie Taylor Greene Trades Barbs With Swalwell on Death Threats
 - [https://www.newsweek.com/marjorie-taylor-greene-trades-barbs-swalwell-death-threats-1773465](https://www.newsweek.com/marjorie-taylor-greene-trades-barbs-swalwell-death-threats-1773465)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 02:57:34+00:00
 - user: None

Representative Eric Swalwell, a California Democrat, has faced scrutiny from the GOP since a 2020 report linked him to a Chinese intelligence operation.

## If Donald Trump Gets Reelected, What 'Will Soon Happen Again'?
 - [https://www.newsweek.com/if-donald-trump-gets-reelected-what-will-soon-happen-again-1773461](https://www.newsweek.com/if-donald-trump-gets-reelected-what-will-soon-happen-again-1773461)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 02:00:38+00:00
 - user: None

Trump has previously pledged to crush the "left-wing censorship regime" and "destroy" drug cartels if elected in 2024.

## Russia's Military Shakeup Highlights Its 'Systemic Challenges': Pentagon
 - [https://www.newsweek.com/russias-military-shakeup-highlights-its-systemic-challenges-pentagon-1773463](https://www.newsweek.com/russias-military-shakeup-highlights-its-systemic-challenges-pentagon-1773463)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 01:14:04+00:00
 - user: None

Pentagon press secretary Pat Ryder addressed the shift among Russia's military officials, including the appointment of Valery Gerasimov as leader.

## The 2024 Nissan GT-R Sharpens With Heritage Colors, Extreme Aerodynamics
 - [https://www.newsweek.com/2024-nissan-gt-r-sharpens-heritage-colors-extreme-aerodynamics-1773429](https://www.newsweek.com/2024-nissan-gt-r-sharpens-heritage-colors-extreme-aerodynamics-1773429)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 01:00:01+00:00
 - user: None

Nissan's updated supercar debuts this spring in three different trims and with two classic colors

## Hunter Biden's Access to Classified Documents in Delaware Questioned
 - [https://www.newsweek.com/hunter-biden-access-delaware-classified-documents-joe-biden-home-1773456](https://www.newsweek.com/hunter-biden-access-delaware-classified-documents-joe-biden-home-1773456)
 - RSS feed: https://www.newsweek.com/rss
 - date published: 2023-01-13 00:41:15+00:00
 - user: None

Republicans are demanding to see the "visitor logs" from President Biden's private home in Delaware, although it is unclear whether such logs exist.
