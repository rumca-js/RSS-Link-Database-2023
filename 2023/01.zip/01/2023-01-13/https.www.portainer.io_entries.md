# Source URL:https://www.portainer.io, Source language: en

## Powerful container management software for Platform Teams, DevOps, Dev
 - [https://www.portainer.io/](https://www.portainer.io/)
 - RSS feed: https://www.portainer.io
 - date published: 2023-01-13 13:03:10+00:00
 - user: rumpel
 - tags: digital bunker,selfhost,smarthome

Powerful container management software for Platform Teams, DevOps, Dev
