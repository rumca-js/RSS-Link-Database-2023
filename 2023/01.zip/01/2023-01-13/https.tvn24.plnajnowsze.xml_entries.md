# Source TVN24 Najnowsze, Source URL:https://tvn24.pl/najnowsze.xml, Source language: pl-PL

## Wjechał w kobietę na pasach. "Nie miała żadnej możliwości ucieczki"
 - [https://tvn24.pl/tvnwarszawa/ulice/garwolin-wjechal-w-kobiete-na-pasach-nagranie-6627526?source=rss](https://tvn24.pl/tvnwarszawa/ulice/garwolin-wjechal-w-kobiete-na-pasach-nagranie-6627526?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 08:48:46+00:00
 - user: None

<img alt="Wjechał w kobietę na pasach. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cipcnj-do-potracenia-doszlo-w-centrum-garwolina-6627506/alternates/LANDSCAPE_1280" />
    W centrum Garwolina (Mazowieckie) kierowca auta osobowego potrącił prawidłowo przechodzącą przez przejście dla pieszych kobietę. Wypadek zarejestrowały kamery miejskiego monitoringu. Policja opublikowała nagranie, by przypomnieć kierowcom, że ich nieuwaga może skończyć się tragedią.

## Wielkie wymieranie permskie. Ziarenko pyłku pomogło wyjaśnić, dlaczego było tak katastrofalne
 - [https://tvn24.pl/tvnmeteo/nauka/wielkie-wymieranie-permskie-ziarenko-pylku-pomoglo-wyjasnic-dlaczego-bylo-tak-katastrofalne-6623976?source=rss](https://tvn24.pl/tvnmeteo/nauka/wielkie-wymieranie-permskie-ziarenko-pylku-pomoglo-wyjasnic-dlaczego-bylo-tak-katastrofalne-6623976?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 08:39:18+00:00
 - user: None

<img alt="Wielkie wymieranie permskie. Ziarenko pyłku pomogło wyjaśnić, dlaczego było tak katastrofalne" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-9tzsrg-przyczyna-wymierania-permskiego-mogla-byc-wzmozona-aktywnosc-wulkaniczna-wizualizacja-6624119/alternates/LANDSCAPE_1280" />
    Jak sugerują najnowsze badania międzynarodowego zespołu naukowców, w wymieraniu permskim - jednej z największych katastrof w historii świata - ogromną rolę mogło odegrać promieniowanie ultrafioletowe (UV-B). Takimi wnioskami podzielili się badacze po przeanalizowaniu ziarenka pyłku, liczącego prawie 250 milionów lat.

## Witalij Kliczko: przygotowujemy się na ewentualny atak z terytorium Białorusi, jesteśmy silniejsi niż przed inwazją
 - [https://tvn24.pl/swiat/mer-kijowa-przygotowujemy-sie-na-ewentualny-atak-na-kijow-z-terytorium-bialorusi-jestesmy-silniejsi-niz-przed-inwazja-6627282?source=rss](https://tvn24.pl/swiat/mer-kijowa-przygotowujemy-sie-na-ewentualny-atak-na-kijow-z-terytorium-bialorusi-jestesmy-silniejsi-niz-przed-inwazja-6627282?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 08:37:57+00:00
 - user: None

<img alt="Witalij Kliczko: przygotowujemy się na ewentualny atak z terytorium Białorusi, jesteśmy silniejsi niż przed inwazją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjc9e8-witalij-kliczko-6627512/alternates/LANDSCAPE_1280" />
    Mer Kijowa Witalij Kliczko w rozmowie z Arturem Molędą z TVN24 powiedział, że jego kraj obawia się ponownego ataku Rosji na Kijów od strony Białorusi. Zastrzegł jednak, że ukraińskie wojska się do tego ataku przygotowują i są silniejsze niż przed otwartą wojną trwającą od lutego.

## Witalij Kliczko: przygotowujemy się na ewentualny atak z terytorium Białorusi, jesteśmy silniejsi niż przed inwazją
 - [https://tvn24.pl/swiat/ukraina-mer-kijowa-witalij-kliczko-przygotowujemy-sie-na-ewentualny-atak-z-bialorusi-jestesmy-silniejsi-6627282?source=rss](https://tvn24.pl/swiat/ukraina-mer-kijowa-witalij-kliczko-przygotowujemy-sie-na-ewentualny-atak-z-bialorusi-jestesmy-silniejsi-6627282?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 08:37:57+00:00
 - user: None

<img alt="Witalij Kliczko: przygotowujemy się na ewentualny atak z terytorium Białorusi, jesteśmy silniejsi niż przed inwazją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bjc9e8-witalij-kliczko-6627512/alternates/LANDSCAPE_1280" />
    Mer Kijowa Witalij Kliczko w rozmowie z Arturem Molędą z TVN24 powiedział, że jego kraj obawia się ponownego ataku Rosji na Kijów od strony Białorusi. Zastrzegł jednak, że ukraińskie wojska się do tego ataku przygotowują i są silniejsze niż przed otwartą wojną trwającą od lutego.

## Policjanci zaglądali z wysięgnika do mieszkania. Rzecznik Praw Obywatelskich oczekuje wyjaśnień
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-zagladali-z-wysiegnika-do-mieszkania-rzecznik-praw-obywatelskich-oczekuje-wyjasnien-6627507?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policjanci-zagladali-z-wysiegnika-do-mieszkania-rzecznik-praw-obywatelskich-oczekuje-wyjasnien-6627507?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 08:36:06+00:00
 - user: None

<img alt="Policjanci zaglądali z wysięgnika do mieszkania. Rzecznik Praw Obywatelskich oczekuje wyjaśnień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i40cd3-policjanci-odwiedzili-lokal-lotnej-brygady-opozycji-6623105/alternates/LANDSCAPE_1280" />
    Rzecznik Praw Obywatelskich zainteresował się policyjną interwencją wobec Lotnej Brygady Opozycji. We wtorek policja zaangażowała straż pożarną, by przez około godzinę zaglądać z wysięgnika do mieszkania, które wynajęli aktywiści. Obok odbywały się obchody tzw. miesięcznicy smoleńskiej. "Takie działanie ingeruje m.in. w konstytucyjne prawo do ochrony życia prywatnego" - czytamy w komunikacie RPO.

## Orlen inwestuje za granicą i stawia na start-upy
 - [https://tvn24.pl/biznes/najnowsze/orlen-inwestuje-zagranica-i-stawia-na-start-upy-orlen-zainwestowal-we-francuska-platforme-logistyczna-shippeo-6627475?source=rss](https://tvn24.pl/biznes/najnowsze/orlen-inwestuje-zagranica-i-stawia-na-start-upy-orlen-zainwestowal-we-francuska-platforme-logistyczna-shippeo-6627475?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 07:56:49+00:00
 - user: None

<img alt="Orlen inwestuje za granicą i stawia na start-upy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qntevx-daniel-obajtek-6226621/alternates/LANDSCAPE_1280" />
    Płocki koncern zainwestował we francuską platformę logistyczną Shippeo - podaje w piątek "Rzeczpospolita". PKN Orlen zapowiada usprawnienie procesów dostaw we wszystkich obszarach swojej działalności. I temu ma służyć nowa inwestycja. Jak podaje dziennik nowatorska platforma technologiczna ma służyć do zarządzania łańcuchami dostaw, monitoruje ponad 32 mln przesyłek rocznie w 110 krajach. Gazeta zauważa jednocześnie, że rynek technologicznych transakcji w Polsce i Europie wyraźnie słabnie.

## Ostatni przed śmiercią wpis Lisy Marie Presley. "Śmierć jest częścią życia, czy nam się to podoba, czy nie"
 - [https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-ostatni-przed-smiercia-wpis-w-mediach-spolecznosciowych-6627397?source=rss](https://tvn24.pl/kultura-i-styl/lisa-marie-presley-nie-zyje-ostatni-przed-smiercia-wpis-w-mediach-spolecznosciowych-6627397?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 07:07:08+00:00
 - user: None

<img alt="Ostatni przed śmiercią wpis Lisy Marie Presley. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8aeg3t-lisa-marie-presley-6627359/alternates/LANDSCAPE_1280" />
    W wieku 54 lat zmarła piosenkarka Lisa Marie Presley. Informację o śmierci jedynego dziecka Elvisa Presleya potwierdziła jej matka, Priscilla. W swoim ostatnim wpisie w mediach społecznościowych Lisa Marie pisała o śmierci i żałobie. "Od 9. roku życia zmagam się ze śmiercią, żalem i stratą" - pisała.

## Matki szukające dzieci znalazły na pustyni już 1520 ciał
 - [https://tvn24.pl/swiat/meksyk-kartele-narkotykowe-pustynia-sonora-1520-cial-zaginionych-odnalezionych-przez-matki-szukajace-dzieci-6627348?source=rss](https://tvn24.pl/swiat/meksyk-kartele-narkotykowe-pustynia-sonora-1520-cial-zaginionych-odnalezionych-przez-matki-szukajace-dzieci-6627348?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 06:49:56+00:00
 - user: None

<img alt="Matki szukające dzieci znalazły na pustyni już 1520 ciał" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rb2yhw-pustynia-sonora-w-meksyku-6627335/alternates/LANDSCAPE_1280" />
    Meksykańskie stowarzyszenie Matek Poszukujących na Sonorze odnalazło dotąd na tej pustyni ciała 1520 osób, które zostały zabite przez kartele narkotykowe. - Cały nasz kraj jest jedną zbiorową mogiłą - powiedziała kierująca organizacją Cecilia Flores.

## Sześć ofiar śmiertelnych i rozległe zniszczenia. Przez Alabamę przeszła potężna seria tornad
 - [https://tvn24.pl/tvnmeteo/swiat/alabama-usa-szesc-ofiar-smiertelnych-i-rozlegle-zniszczenia-przez-stan-przeszla-potezna-seria-tornad-6627314?source=rss](https://tvn24.pl/tvnmeteo/swiat/alabama-usa-szesc-ofiar-smiertelnych-i-rozlegle-zniszczenia-przez-stan-przeszla-potezna-seria-tornad-6627314?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 06:46:36+00:00
 - user: None

<img alt="Sześć ofiar śmiertelnych i rozległe zniszczenia. Przez Alabamę przeszła potężna seria tornad" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tyg6i5-zniszczenia-po-serii-tornad-w-alabamie-6627320/alternates/LANDSCAPE_1280" />
    Co najmniej 25 tornad przetoczyło się w czwartek przez środkowe regiony stanu Alabama w USA. Władze regionu potwierdziły, że w wyniku katastrofy życie straciło co najmniej sześć osób. Zniszczenia są ogromne, wielu mieszkańców zostało pozbawionych dachu nad głową i energii elektrycznej.

## Przechwycili 180 tysięcy tabletek na potencję. Przesyłka z Chin miała trafić do warszawskiej firmy
 - [https://tvn24.pl/tvnwarszawa/wlochy/warszawa-180-tysiecy-nielegalnych-tabletek-na-potencje-w-przesylce-z-chin-6627349?source=rss](https://tvn24.pl/tvnwarszawa/wlochy/warszawa-180-tysiecy-nielegalnych-tabletek-na-potencje-w-przesylce-z-chin-6627349?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 06:37:40+00:00
 - user: None

<img alt="Przechwycili 180 tysięcy tabletek na potencję. Przesyłka z Chin miała trafić do warszawskiej firmy " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-l2o5zj-w-przesylce-z-chin-bylo-180-tysiecy-tabletek-na-potencje-6627340/alternates/LANDSCAPE_1280" />
    Mazowiecka Krajowa Administracja Skarbowa zatrzymała na warszawskim Lotnisku Chopina przesyłkę z Chin. Kartony zawierały prawie 180 tysięcy tabletek na potencję. Nielegalne leki są warte nawet osiem milionów złotych.

## Startują ferie zimowe. Policja opublikowała listę miejsc prowadzenia kontroli autobusów
 - [https://tvn24.pl/biznes/moto/ferie-zimowe-2023-kontrole-policji-lista-miejsc-prowadzenia-kontroli-autobusow-6627302?source=rss](https://tvn24.pl/biznes/moto/ferie-zimowe-2023-kontrole-policji-lista-miejsc-prowadzenia-kontroli-autobusow-6627302?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 05:53:16+00:00
 - user: None

<img alt="Startują ferie zimowe. Policja opublikowała listę miejsc prowadzenia kontroli autobusów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lnox9z-autokar-kontrola-6627315/alternates/LANDSCAPE_1280" />
    Policja zapowiada więcej patroli na drogach w całym kraju. Powodem są rozpoczynające się ferie zimowe dla dzieci i młodzieży. Funkcjonariusze będą zwracać szczególną uwagę między innymi na sposób przewożenia pasażerów i bagażu. Będą też sprawdzać autobusy wiozące młodzież na zimowy wypoczynek - zapowiedział poinformował nadkomisarz Robert Opas z Biura Ruchu Drogowego Komendy Głównej Policji.

## Coraz więcej raka. Powstała "wyrwa, za którą będziemy płacić jeszcze kilka lat"
 - [https://tvn24.pl/polska/rak-piersi-coraz-wiecej-wykrywanych-nowotworow-po-spadku-liczby-badan-profilaktycznych-w-czasie-pandemii-6627021?source=rss](https://tvn24.pl/polska/rak-piersi-coraz-wiecej-wykrywanych-nowotworow-po-spadku-liczby-badan-profilaktycznych-w-czasie-pandemii-6627021?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 05:46:56+00:00
 - user: None

<img alt="Coraz więcej raka. Powstała " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pxnjy4-shutterstock1951533499-6185163/alternates/LANDSCAPE_1280" />
    Rak piersi to problem większy niż wcześniej. Jest źle - mówią lekarze, bo Polki przez pandemię miały przerwę w badaniach. A profilaktyka szczególnie w tym nowotworze ma kluczowe znaczenie. Pacjentek z rakiem piersi jest więcej, a ten wcześnie wykryty pozwala całkowicie wyzdrowieć. W sumie niemal dwie trzecie obywateli i obywatelek w ogóle nie bada się w kierunku nowotworów. Materiał magazynu "Polska i Świat".

## Nielegalna fabryka papierosów w mieszkaniu
 - [https://tvn24.pl/tvnwarszawa/bemowo/bemowo-nielegalna-fabryka-papierosow-w-mieszkaniu-6626450?source=rss](https://tvn24.pl/tvnwarszawa/bemowo/bemowo-nielegalna-fabryka-papierosow-w-mieszkaniu-6626450?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 05:43:31+00:00
 - user: None

<img alt="Nielegalna fabryka papierosów w mieszkaniu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-d75iyb-fabryka-papierosow-dzialala-w-mieszkaniu-na-bemowie-6626448/alternates/LANDSCAPE_1280" />
    W mieszkaniu na Bemowie działała nielegalna fabryka papierosów. Policjanci zatrzymali trzy osoby, przejęli maszyny do produkcji oraz urządzenia do pakowania.

## Końcówka tygodnia pod znakiem silniejszych porywów wiatru. Gdzie IMGW może wydać alarmy
 - [https://tvn24.pl/tvnmeteo/pogoda/koncowka-tygodnia-pod-znakiem-silniejszych-porywow-wiatru-pogoda-na-weekend-prognoza-zagrozen-imgw-6627300?source=rss](https://tvn24.pl/tvnmeteo/pogoda/koncowka-tygodnia-pod-znakiem-silniejszych-porywow-wiatru-pogoda-na-weekend-prognoza-zagrozen-imgw-6627300?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 05:33:48+00:00
 - user: None

<img alt="Końcówka tygodnia pod znakiem silniejszych porywów wiatru. Gdzie IMGW może wydać alarmy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-qw9x2b-powieje-silny-wiatr-5510566/alternates/LANDSCAPE_1280" />
    IMGW wydał prognozę zagrożeń. Z komunikatów synoptyków wynika, że do końca tygodnia doskwierać nam mogą silniejsze porywy wiatru. Sprawdź, gdzie mogą obowiązywać ostrzeżenia.

## Janina Goss w PKN Orlen. Komentarze polityków
 - [https://tvn24.pl/polska/janina-goss-w-pkn-orlen-politycy-o-przyjaciolce-jaroslawa-kaczynskiego-6627024?source=rss](https://tvn24.pl/polska/janina-goss-w-pkn-orlen-politycy-o-przyjaciolce-jaroslawa-kaczynskiego-6627024?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 05:10:57+00:00
 - user: None

<img alt="Janina Goss w PKN Orlen. Komentarze polityków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-azn1r9-janina-goss-6625076/alternates/LANDSCAPE_1280" />
    Jedna z najbliższych współpracowniczek prezesa Prawa i Sprawiedliwości - osoba, od której nawet pożyczał pieniądze - Janina Goss powołana do rady nadzorczej PKN Orlen. Wieloletnia przyjaciółka Jarosława Kaczyńskiego jest też prezeską spółki Srebrna, która zarządza nieruchomościami w Warszawie i miała budować dwie wieże. Mówi się o niej "szara eminencja" struktur PiS. Materiał magazynu "Polska i Świat".

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6627288?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6627288?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 04:46:56+00:00
 - user: None

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j78l8k-zniszczenia-w-mikolajowie-po-rosyjskim-ataku-rakietowym-6627181/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 324 dni. Absolutnie popieramy wysyłanie jakichkolwiek zdolności wojskowych Ukrainie, w tym czołgów - oświadczył rzecznik Pentagonu gen. Pat Ryder. Jednocześnie dodał, że są to suwerenne decyzje państw i należy brać w tym pod uwagę kwestie m.in. logistyki. Oto najważniejsze wydarzenia ostatnich godzin.

## Pogoda na dziś - piątek 13.01. Przez Polskę przejdzie strefa opadów deszczu
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-1301-przez-polske-przejdzie-strefa-opadow-deszczu-6626918?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-1301-przez-polske-przejdzie-strefa-opadow-deszczu-6626918?source=rss)
 - RSS feed: https://tvn24.pl/najnowsze.xml
 - date published: 2023-01-13 01:00:00+00:00
 - user: None

<img alt="Pogoda na dziś - piątek 13.01. Przez Polskę przejdzie strefa opadów deszczu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-egsoiq-popada-deszcz-5558356/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. W piątek 13.01 strefa opadów deszczu będzie przemieszczać się z zachodu na wschód kraju. W górach sypnie śniegiem. Termometry pokażą maksymalnie od 5 do 10 stopni Celsjusza. Aura niekorzystnie wpłynie na nasze samopoczucie.
