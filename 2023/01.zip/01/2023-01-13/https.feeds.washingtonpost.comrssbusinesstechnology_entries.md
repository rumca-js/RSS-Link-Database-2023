# Source The Washington Post - Tech, Source URL:https://feeds.washingtonpost.com/rss/business/technology, Source language: en-US

## Video game studio called Proletariat declines to recognize union (lol)
 - [https://www.washingtonpost.com/video-games/2023/01/13/elizabeth-warren-proletariat-union-activision/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2023/01/13/elizabeth-warren-proletariat-union-activision/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 18:05:04+00:00
 - user: None

Leadership at the video game company Proletariat —a term referring to the working class — declined to voluntarily recognize a nascent union at the studio.

## Sarah Natochenny voiced Pokémon’s Ash Ketchum for 17 years. What now?
 - [https://www.washingtonpost.com/video-games/2023/01/13/pokemon-ash-ketchum-sarah-natochenny/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/video-games/2023/01/13/pokemon-ash-ketchum-sarah-natochenny/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 15:20:35+00:00
 - user: None

The voice actress is optimistic about her future, and encouraged fans to "Be the very best like no one ever was."

## Even electric self-driving cars may have a climate change problem
 - [https://www.washingtonpost.com/technology/2023/01/13/self-driving-cars-greenhouse-gas-emissions/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/13/self-driving-cars-greenhouse-gas-emissions/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 13:43:09+00:00
 - user: None

MIT researchers found that the computers powering self-driving cars could have a large carbon footprint.

## Tesla cuts prices, allowing certain models to qualify for tax rebates
 - [https://www.washingtonpost.com/technology/2023/01/13/tesla-price-cut-tax-rebate/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/13/tesla-price-cut-tax-rebate/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 12:52:17+00:00
 - user: None

Buyers of certain American-made EVs are eligible for $7,500 tax incentives under the Inflation Reduction Act.

## The one simple trick to make sure your email gets noticed
 - [https://www.washingtonpost.com/technology/2023/01/13/schedule-send-features-email/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/13/schedule-send-features-email/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 12:30:22+00:00
 - user: None

Don't send that 2 a.m. email! Use features in many communications apps to write messages when it's convenient for you, but only arrive on the other end later.

## Space Dodgers
 - [https://www.washingtonpost.com/technology/interactive/2023/space-debris-game/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/interactive/2023/space-debris-game/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-13 06:00:26+00:00
 - user: None

Space junk is a serious problem and is getting worse. In this game, you’ll maneuver a spacecraft through an increasingly crowded debris field.
