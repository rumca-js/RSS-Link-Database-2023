# Source NBC tech, Source URL:https://feeds.nbcnews.com/nbcnews/public/tech, Source language: en-US

## Sweden locates rare earth deposits as Europe races against China
 - [https://www.nbcnews.com/news/world/sweden-locates-rare-earth-deposits-china-europe-rcna65651](https://www.nbcnews.com/news/world/sweden-locates-rare-earth-deposits-china-europe-rcna65651)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-13 10:22:26+00:00
 - user: None

Sweden’s iron-ore miner LKAB said Thursday it has identified “significant deposits” in Lapland of rare earth elements that are essential for manufacturing.
