# Source Android Authority, Source URL:https://www.androidauthority.com/feed/, Source language: en-US

## Motorola Moto G Play (2023) review: Limited reach
 - [https://www.androidauthority.com/motorola-moto-g-play-2023-review-3265042/](https://www.androidauthority.com/motorola-moto-g-play-2023-review-3265042/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 22:37:57+00:00
 - user: None

It's a bargain, but how affordable is too affordable?

## Stadia’s final act will be to unlock Bluetooth support on its controllers
 - [https://www.androidauthority.com/stadia-controller-bluetooth-3266613/](https://www.androidauthority.com/stadia-controller-bluetooth-3266613/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 22:16:20+00:00
 - user: None

The details on how to enable Bluetooth will be revealed next week.

## Galaxy S23 Plus and Ultra official press renders leak ahead of Unpacked event
 - [https://www.androidauthority.com/galaxy-s23-plus-ultra-3266548/](https://www.androidauthority.com/galaxy-s23-plus-ultra-3266548/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 20:21:11+00:00
 - user: None

The renders show off the devices in four different colors.

## Check your LG TV, as it may have just been recalled for a safety risk
 - [https://www.androidauthority.com/lg-tv-recall-3266506/](https://www.androidauthority.com/lg-tv-recall-3266506/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 18:50:25+00:00
 - user: None

The TV could create a tip-over and entrapment hazard.

## Samsung Galaxy S22 Ultra vs S23 Ultra: Will the new handset be worth the wait?
 - [https://www.androidauthority.com/galaxy-s22-ultra-vs-s23-ultra-3266173/](https://www.androidauthority.com/galaxy-s22-ultra-vs-s23-ultra-3266173/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 17:25:34+00:00
 - user: None

According to current rumors, the Samsung Galaxy S23 Ultra is quite similar to its predecessor.

## Daily Authority: 📺 New Chromecast with Google TV incoming
 - [https://www.androidauthority.com/daily-authority-january-13-2023-3266324/](https://www.androidauthority.com/daily-authority-january-13-2023-3266324/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 10:46:52+00:00
 - user: None

Plus more Galaxy S23 renders, a new Pentagon UFO report, and Chuck E. Cheese floppy disks.

## You told us: Many of you have multiple power banks
 - [https://www.androidauthority.com/power-bank-for-phone-poll-results-3266284/](https://www.androidauthority.com/power-bank-for-phone-poll-results-3266284/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 08:52:34+00:00
 - user: None

It turns out that more surveyed readers have multiple power banks than none at all.

## A new Chromecast with Google TV is in the pipeline
 - [https://www.androidauthority.com/new-chromecast-with-google-tv-2023-3266266/](https://www.androidauthority.com/new-chromecast-with-google-tv-2023-3266266/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 06:36:29+00:00
 - user: None

A third Chromecast with Google TV model could be on the way, but will it replace the 4K variant?

## How to get honeycomb in Minecraft
 - [https://www.androidauthority.com/how-to-get-honeycomb-in-minecraft-3261677/](https://www.androidauthority.com/how-to-get-honeycomb-in-minecraft-3261677/)
 - RSS feed: https://www.androidauthority.com/feed/
 - date published: 2023-01-13 01:16:38+00:00
 - user: None

Those bees sure are adorable, aren't they?
