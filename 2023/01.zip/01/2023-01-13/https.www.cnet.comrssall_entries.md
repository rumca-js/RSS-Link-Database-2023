# Source CNET, Source URL:https://www.cnet.com/rss/all/, Source language: en-US

## New Apple Music, TV and Devices Apps Now Available on Windows     - CNET
 - [https://www.cnet.com/tech/services-and-software/new-apple-music-tv-and-devices-apps-now-available-on-windows/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/new-apple-music-tv-and-devices-apps-now-available-on-windows/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 23:51:39+00:00
 - user: None

You can forget about iTunes.

## LG Recalls Over 52,000 4K TVs Over Tipping Hazards     - CNET
 - [https://www.cnet.com/tech/home-entertainment/lg-recalls-over-52000-4k-tvs-over-tipping-hazards/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/lg-recalls-over-52000-4k-tvs-over-tipping-hazards/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 23:24:00+00:00
 - user: None

The included leg stands don't keep the TV stable enough, resulting in tip-overs.

## 10 Effective Ways to Deter Burglars and Prevent Home Break-Ins     - CNET
 - [https://www.cnet.com/how-to/10-effective-ways-to-deter-burglars-and-prevent-home-break-ins/#ftag=CADf328eec](https://www.cnet.com/how-to/10-effective-ways-to-deter-burglars-and-prevent-home-break-ins/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 23:00:13+00:00
 - user: None

Follow these steps to keep your home secure from would-be porch pirates and intruders.

## 'The Mandalorian' Season 3: New Trailer Hints, March Release Date and Baby Yoda's Future     - CNET
 - [https://www.cnet.com/culture/entertainment/the-mandalorian-season-3-new-trailer-hints-march-release-date-and-baby-yoda-future/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-mandalorian-season-3-new-trailer-hints-march-release-date-and-baby-yoda-future/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 22:37:38+00:00
 - user: None

The third season of the Star Wars show returns to Disney Plus in a few weeks, and a fresh trailer is coming Monday.

## PNC Bank: 2023 Banking Review     - CNET
 - [https://www.cnet.com/personal-finance/banking/pnc-bank-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/pnc-bank-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 22:18:00+00:00
 - user: None

Despite a notable high-yield savings account, PNC has relatively low savings rates and isn't available in all states.

## New US Government UFO Report Adds Hundreds of Sightings     - CNET
 - [https://www.cnet.com/science/new-us-government-ufo-report-adds-hundreds-of-sightings/#ftag=CADf328eec](https://www.cnet.com/science/new-us-government-ufo-report-adds-hundreds-of-sightings/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 22:10:00+00:00
 - user: None

The US government now uses the term UAP, for "unidentified aerial phenomena."

## 7 Habits You'll Need to Better Your Mental Health     - CNET
 - [https://www.cnet.com/health/mental/7-habits-youll-need-to-better-your-mental-health/#ftag=CADf328eec](https://www.cnet.com/health/mental/7-habits-youll-need-to-better-your-mental-health/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 22:00:00+00:00
 - user: None

Make your mental health a priority by using these seven daily habits.

## 10 Horrible Tech Gadgets From the Last 25 Years That Just Suck     - CNET
 - [https://www.cnet.com/tech/computing/10-horrible-tech-gadgets-from-the-last-25-years-that-just-suck/#ftag=CADf328eec](https://www.cnet.com/tech/computing/10-horrible-tech-gadgets-from-the-last-25-years-that-just-suck/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 21:51:03+00:00
 - user: None

The annual CES show has given us thousands of gadgets this quarter-century. These are the worst.

## Frontpoint Home Security Review: Ace DIY System Grounded by Pricey Subscription Fees     - CNET
 - [https://www.cnet.com/news/frontpoint-home-security-review/#ftag=CADf328eec](https://www.cnet.com/news/frontpoint-home-security-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 21:39:21+00:00
 - user: None

This DIY security system competes with offerings from industry leaders like SimpliSafe and Abode, but demands too much for its monthly monitoring fees.

## How to Stop Drinking: 8 Tips That Actually Work     - CNET
 - [https://www.cnet.com/health/medical/how-to-stop-drinking-8-tips-that-actually-work/#ftag=CADf328eec](https://www.cnet.com/health/medical/how-to-stop-drinking-8-tips-that-actually-work/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 21:12:44+00:00
 - user: None

Use these tried-and-true tips to quit alcohol this year -- or just cut back.

## Making Distilled Water at Home Is Easy and Free. Here's How to Do It in 5 Steps     - CNET
 - [https://www.cnet.com/how-to/making-distilled-water-at-home-is-easy-and-free-heres-how-to-do-it-in-5-steps/#ftag=CADf328eec](https://www.cnet.com/how-to/making-distilled-water-at-home-is-easy-and-free-heres-how-to-do-it-in-5-steps/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 21:00:08+00:00
 - user: None

Why spend money on distilled water when you can easily make it yourself for free?

## Can You Buy a Gift Card With a Credit Card?     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/can-you-buy-a-gift-card-with-a-credit-card/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/can-you-buy-a-gift-card-with-a-credit-card/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:57:00+00:00
 - user: None

Yes -- and it can be quite rewarding. But there are risks, too.

## Social Security Cheat Sheet 2023: Understand Your Benefits     - CNET
 - [https://www.cnet.com/personal-finance/social-security-cheat-sheet-2023-understand-your-benefits/#ftag=CADf328eec](https://www.cnet.com/personal-finance/social-security-cheat-sheet-2023-understand-your-benefits/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:30:09+00:00
 - user: None

Curious about the cost-of-living adjustment or other Social Security benefits questions? We have answers.

## Webb Telescope Finds Massive Shock Wave Wreaking Havoc Among 5 Galaxies     - CNET
 - [https://www.cnet.com/science/space/webb-telescope-finds-massive-shock-wave-wreaking-havoc-among-5-galaxies/#ftag=CADf328eec](https://www.cnet.com/science/space/webb-telescope-finds-massive-shock-wave-wreaking-havoc-among-5-galaxies/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:26:00+00:00
 - user: None

Larger than the Milky Way, this wave managed to form a mysterious hydrogen "recycling plant" in one of space's scariest regions.

## Simmons Bank: 2023 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/simmons-bank-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/simmons-bank-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:15:00+00:00
 - user: None

This lender offers limited information on its website about the terms of its HELOC.

## You'll Need Keen Eyes to Spot NASA's Mars Helicopter in This Rover Image     - CNET
 - [https://www.cnet.com/science/space/youll-need-keen-eyes-to-spot-nasas-mars-helicopter-in-this-rover-image/#ftag=CADf328eec](https://www.cnet.com/science/space/youll-need-keen-eyes-to-spot-nasas-mars-helicopter-in-this-rover-image/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:06:00+00:00
 - user: None

Ingenuity is hiding out in the sandy Martian distance.

## The Absolute Best Sci-Fi TV Shows on HBO Max     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-on-hbo-max-tonight/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-sci-fi-tv-shows-on-hbo-max-tonight/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:05:04+00:00
 - user: None

Don't worry, Station Eleven is in here.

## Biggest Flower Ever Found Preserved in Amber Is at Least 33 Million Years Old     - CNET
 - [https://www.cnet.com/science/biology/biggest-flower-ever-found-preserved-in-amber-is-at-least-33-million-years-old/#ftag=CADf328eec](https://www.cnet.com/science/biology/biggest-flower-ever-found-preserved-in-amber-is-at-least-33-million-years-old/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:04:00+00:00
 - user: None

The absolute unit of a fossil flower has been given a new name.

## How Health Tech Wants to Change the Way We Age     - CNET
 - [https://www.cnet.com/health/medical/how-health-tech-wants-to-change-the-way-we-age/#ftag=CADf328eec](https://www.cnet.com/health/medical/how-health-tech-wants-to-change-the-way-we-age/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:03:00+00:00
 - user: None

We're all getting older. New technology, some of which was unveiled at CES this year, is bridging care gaps and keeping up with the times.

## Keep This COLA Letter in a Safe Place. Here's Why     - CNET
 - [https://www.cnet.com/personal-finance/keep-this-cola-letter-in-a-safe-place-heres-why/#ftag=CADf328eec](https://www.cnet.com/personal-finance/keep-this-cola-letter-in-a-safe-place-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:00:10+00:00
 - user: None

Letters containing Social Security recipients' new 2023 COLA benefit amount arrived in December. Here's why you should probably keep it around.

## HBO Max: The Absolute Best Sci-Fi Movies to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/hbo-max-the-absolute-best-sci-fi-movies-to-watch-this-evening/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/hbo-max-the-absolute-best-sci-fi-movies-to-watch-this-evening/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 20:00:04+00:00
 - user: None

Looking for a sci-fi flick this evening? HBO Max is sci-fi movie central.

## What Is an Annual Percentage Yield?     - CNET
 - [https://www.cnet.com/personal-finance/banking/what-is-annual-percentage-yield/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/what-is-annual-percentage-yield/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:51:00+00:00
 - user: None

It tells you how much you'll earn by depositing money into a savings account.

## What Is Overdraft Protection and Do You Need It?     - CNET
 - [https://www.cnet.com/personal-finance/banking/what-is-overdraft-protection-and-do-you-need-it/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/what-is-overdraft-protection-and-do-you-need-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:42:00+00:00
 - user: None

Protect yourself from onerous overdraft fees.

## T-Mobile Layoffs Hit Retail Staff     - CNET
 - [https://www.cnet.com/tech/mobile/t-mobile-layoffs-hit-retail-staff-as-carrier-shifts-store-strategy/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/t-mobile-layoffs-hit-retail-staff-as-carrier-shifts-store-strategy/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:20:00+00:00
 - user: None

The company is refocusing on more retail store formats.

## Funky Mars Rock Spotted by NASA Rover Might Be a Meteorite     - CNET
 - [https://www.cnet.com/science/space/funky-mars-rock-spotted-by-nasa-rover-might-be-a-meteorite/#ftag=CADf328eec](https://www.cnet.com/science/space/funky-mars-rock-spotted-by-nasa-rover-might-be-a-meteorite/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:16:00+00:00
 - user: None

The lumpy rock may have an off-world origin story.

## The New Search Button May Be the Most Annoying iOS 16 Feature, but There Is a Fix     - CNET
 - [https://www.cnet.com/tech/services-and-software/the-new-search-button-may-be-the-most-annoying-ios-16-feature-but-luckily-theres-a-fix/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/the-new-search-button-may-be-the-most-annoying-ios-16-feature-but-luckily-theres-a-fix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:15:03+00:00
 - user: None

If you keep accidentally hitting the new Search button on your iPhone, there's a way to completely remove it.

## Best Washing Machine of 2023     - CNET
 - [https://www.cnet.com/news/best-washing-machine/#ftag=CADf328eec](https://www.cnet.com/news/best-washing-machine/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:09:49+00:00
 - user: None

Whether you're looking for a washing machine that won't break the bank, a machine that does it all or one that will easily fit in any small space, these are the best washing machines to buy right now.

## NASA's James Webb Telescope Finds Its First Exoplanet, a Major Milestone     - CNET
 - [https://www.cnet.com/science/space/nasas-james-webb-telescope-finds-its-first-exoplanet-a-major-milestone/#ftag=CADf328eec](https://www.cnet.com/science/space/nasas-james-webb-telescope-finds-its-first-exoplanet-a-major-milestone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:09:00+00:00
 - user: None

The world isn't too far off and nearly the exact same size as Earth.

## Bank of America Business Advantage Unlimited Cash Rewards Mastercard Credit Card Review     - CNET
 - [https://www.cnet.com/personal-finance/credit-cards/bank-of-america-business-advantage-unlimited-cash-rewards-mastercard-credit-card-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/credit-cards/bank-of-america-business-advantage-unlimited-cash-rewards-mastercard-credit-card-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 19:04:00+00:00
 - user: None

This business credit card won't earn you the highest rewards rate, but it makes earning cash back easy.

## Yes, You Can Cut Your Heat and Electric Bills: 5 Easy Tips     - CNET
 - [https://www.cnet.com/how-to/yes-you-can-cut-your-heat-and-electric-bills-5-easy-tips/#ftag=CADf328eec](https://www.cnet.com/how-to/yes-you-can-cut-your-heat-and-electric-bills-5-easy-tips/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:56:00+00:00
 - user: None

Stop letting your utility bills ruin your budget. Here's how to save this winter.

## You Might Want to Throw Away Your Leftover Rice     - CNET
 - [https://www.cnet.com/how-to/you-might-want-to-throw-away-your-leftover-rice/#ftag=CADf328eec](https://www.cnet.com/how-to/you-might-want-to-throw-away-your-leftover-rice/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:55:00+00:00
 - user: None

Throw away that five-day-old rice and save your stomach from possible food poisoning.

## Scientists May Have Discovered the Long Lost Ancient Temple of Poseidon     - CNET
 - [https://www.cnet.com/science/scientists-may-have-discovered-the-long-lost-ancient-temple-of-poseidon/#ftag=CADf328eec](https://www.cnet.com/science/scientists-may-have-discovered-the-long-lost-ancient-temple-of-poseidon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:49:00+00:00
 - user: None

A buried shrine matches an ancient description of a place dedicated to the mythological god of the sea.

## Homebridge: 2023 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/homebridge-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/homebridge-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:47:51+00:00
 - user: None

You can receive a decision on the spot and receive your funds in as little as five days.

## Biggest Flower Yet Found Preserved in Amber Is at Least 33 Million Years Old     - CNET
 - [https://www.cnet.com/science/biology/biggest-flower-ever-found-preserved-in-amber-dates-back-33-million-years/#ftag=CADf328eec](https://www.cnet.com/science/biology/biggest-flower-ever-found-preserved-in-amber-dates-back-33-million-years/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:35:00+00:00
 - user: None

The absolute unit of a fossil flower has been given a new name.

## Journey Is Offering 20% Off Its Tech Sitewide For a Limited Time     - CNET
 - [https://www.cnet.com/deals/journey-is-offering-20-off-its-tech-sitewide-for-a-limited-time/#ftag=CADf328eec](https://www.cnet.com/deals/journey-is-offering-20-off-its-tech-sitewide-for-a-limited-time/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:33:57+00:00
 - user: None

Explore new tech for your favorite smart devices with savings on Journey chargers, mounts, mats and more.

## Groggy After Taking Melatonin? Try These 7 Natural Sleep Aids     - CNET
 - [https://www.cnet.com/health/sleep/groggy-after-taking-melatonin-try-these-7-natural-sleep-aids/#ftag=CADf328eec](https://www.cnet.com/health/sleep/groggy-after-taking-melatonin-try-these-7-natural-sleep-aids/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:10:00+00:00
 - user: None

Herbal tea, lavender oil and other natural aids have certain properties to promote sleepiness.

## SpaceX Set to Launch Falcon Heavy for US Space Force Mission This Weekend     - CNET
 - [https://www.cnet.com/science/space/spacex-set-to-launch-falcon-heavy-for-us-space-force-mission-this-weekend/#ftag=CADf328eec](https://www.cnet.com/science/space/spacex-set-to-launch-falcon-heavy-for-us-space-force-mission-this-weekend/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:02:36+00:00
 - user: None

After months and even years of delays in some cases, SpaceX is beginning to work through a backlog of launches involving its biggest rocket.

## 'The Last of Us' HBO Adaptation Pushes Its Universe Way Beyond the PlayStation Games     - CNET
 - [https://www.cnet.com/culture/entertainment/the-last-of-us-hbo-adaptation-pushes-its-universe-way-beyond-the-playstation-games/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-last-of-us-hbo-adaptation-pushes-its-universe-way-beyond-the-playstation-games/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:00:22+00:00
 - user: None

Writer Craig Mazin, Pedro Pascal and the rest of the cast reveal how the TV series goes beyond its source material while maintaining its powerful emotional core (and bringing back familiar faces).

## NFL Wild Card: How to Watch, Stream Ravens vs. Bengals on Sunday Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-wild-card-how-to-watch-stream-ravens-vs-bengals-on-sunday-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-wild-card-how-to-watch-stream-ravens-vs-bengals-on-sunday-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 18:00:03+00:00
 - user: None

The AFC North foes meet in Cincinnati for a Wild Card showdown on NBC.

## Play Storytelling Puzzle Game Illustrated Now on Apple Arcade     - CNET
 - [https://www.cnet.com/tech/gaming/play-storytelling-puzzle-game-illustrated-now-on-apple-arcade/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/play-storytelling-puzzle-game-illustrated-now-on-apple-arcade/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:54:15+00:00
 - user: None

Puzzle out Van Gogh paintings in this Apple Arcade game, out today.

## Tech Security Rests on the Wrong Shoulders     - CNET
 - [https://www.cnet.com/tech/services-and-software/tech-security-rests-on-the-wrong-shoulders/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/tech-security-rests-on-the-wrong-shoulders/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:48:49+00:00
 - user: None

Right now, it's all about you. But experts say companies must be held accountable for security.

## You Can Easily Fix These 4 Annoying iOS 16 Features     - CNET
 - [https://www.cnet.com/tech/services-and-software/you-can-easily-fix-these-4-annoying-ios-16-features/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/you-can-easily-fix-these-4-annoying-ios-16-features/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:15:00+00:00
 - user: None

Here's how to disable the most irritating features on your iPhone.

## HBO's 'The Last of Us' Is a Stunning Triumph of Video Game Adaptation     - CNET
 - [https://www.cnet.com/culture/entertainment/hbo-the-last-of-us-is-a-stunning-triumph-of-video-game-adaptation/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/hbo-the-last-of-us-is-a-stunning-triumph-of-video-game-adaptation/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:00:16+00:00
 - user: None

Joel and Ellie's dark odyssey, starting this Sunday, is a journey you need to take.

## NFL Wild Card Game: How to Watch, Stream Giants vs. Vikings on Sunday Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-wild-card-game-how-to-watch-stream-giants-vs-vikings-on-sunday-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-wild-card-game-how-to-watch-stream-giants-vs-vikings-on-sunday-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:00:12+00:00
 - user: None

The Giants are heading back to Minnesota to battle the Vikings in the NFC's second Wild Card game.

## Ditch Your Hanes T-Shirt and Shop Sustainable Basics at Terra Thread     - CNET
 - [https://www.cnet.com/culture/fashion/ditch-your-hanes-t-shirt-and-shop-sustainable-basics-at-terra-thread/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/ditch-your-hanes-t-shirt-and-shop-sustainable-basics-at-terra-thread/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:00:03+00:00
 - user: None

This new year it's out with the old and in with the new. Leave your old t-shirts in 2022 and add Terra Thread's sustainable cotton apparel to your wardrobe.

## Shop Sustainable Basics at Terra Thread     - CNET
 - [https://www.cnet.com/culture/fashion/shop-sustainable-basics-at-terra-thread/#ftag=CADf328eec](https://www.cnet.com/culture/fashion/shop-sustainable-basics-at-terra-thread/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 17:00:00+00:00
 - user: None

Leave your old T-shirts in 2022 and add Terra Thread's sustainable cotton apparel to your wardrobe.

## Epic Photos Show SpaceX Starship Beaming on the Launchpad     - CNET
 - [https://www.cnet.com/science/space/epic-photos-show-spacex-starship-beaming-on-the-launchpad/#ftag=CADf328eec](https://www.cnet.com/science/space/epic-photos-show-spacex-starship-beaming-on-the-launchpad/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:35:00+00:00
 - user: None

The next-gen spacecraft poses for glamour shots as SpaceX aims for orbit.

## The Absolute Best Fantasy Movies on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-to-watch-this-evening/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-fantasy-movies-to-watch-this-evening/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:33:43+00:00
 - user: None

Netflix's fantasy options range from pure magic to touching allegories of the human condition.

## Prime Video: The 35 Absolute Best TV Shows to Watch     - CNET
 - [https://www.cnet.com/culture/entertainment/amazon-prime-video-the-35-absolute-best-tv-shows-january/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/amazon-prime-video-the-35-absolute-best-tv-shows-january/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:30:09+00:00
 - user: None

Check out The English, starring Emily Blunt.

## KeyBank: 2023 Banking Review     - CNET
 - [https://www.cnet.com/personal-finance/banking/keybank-banking-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/keybank-banking-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:29:00+00:00
 - user: None

KeyBank offers a wide array of deposit accounts, but fees apply.

## Apple TV Plus: Every New TV Show Arriving in January     - CNET
 - [https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-january-this-evening/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/apple-tv-plus-tv-shows-to-watch-in-january-this-evening/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:25:58+00:00
 - user: None

Here's a complete list of shows coming in January.

## Monday Night Football: How to Watch, Stream Cowboys vs. Bucs Wild Card Game Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-cowboys-vs-bucs-wild-card-game-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/monday-night-football-how-to-watch-stream-cowboys-vs-bucs-wild-card-game-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:21:40+00:00
 - user: None

Dallas and Tampa Bay wrap up Wild Card weekend on Monday night on ESPN with the Peyton and Eli and the ManningCast on ESPN2.

## Exclusive Marvel Night Show With 500 Drones Coming to a Disney Park     - CNET
 - [https://www.cnet.com/culture/entertainment/exclusive-marvel-show-coming-to-a-disney-park-uses-500-drones/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/exclusive-marvel-show-coming-to-a-disney-park-uses-500-drones/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:16:00+00:00
 - user: None

Avengers: Power the Night celebrates superheroes such as Captain America, Captain Marvel, Iron Man, Hulk, Scarlet Witch and Shang-Chi.

## The Absolute Best Sci-Fi TV Shows on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-watch-over-the-weekend/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-absolute-best-netflix-sci-fi-tv-shows-to-watch-over-the-weekend/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:14:00+00:00
 - user: None

These are the best of the sci-fi series on Netflix.

## The Best Movies on Apple TV Plus     - CNET
 - [https://www.cnet.com/culture/entertainment/the-best-movies-you-can-catch-on-apple-tv-plus-over-the-weekend/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-best-movies-you-can-catch-on-apple-tv-plus-over-the-weekend/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:03:10+00:00
 - user: None

Apple TV Plus has an assortment of options, from dramas to music documentaries and animated movies.

## NFL Wild Card Weekend: How to Watch, Stream Dolphins vs. Bills on Sunday Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-wild-card-weekend-how-to-watch-stream-dolphins-vs-bills-on-sunday-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-wild-card-weekend-how-to-watch-stream-dolphins-vs-bills-on-sunday-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 16:00:30+00:00
 - user: None

The AFC East rivals meet in Buffalo for a Wild Card matchup.

## Extra Tax Refunds From IRS: How to See If You Overpaid Taxes in 2020     - CNET
 - [https://www.cnet.com/personal-finance/taxes/extra-tax-refunds-from-irs-how-to-see-if-you-overpaid-taxes-in-2020/#ftag=CADf328eec](https://www.cnet.com/personal-finance/taxes/extra-tax-refunds-from-irs-how-to-see-if-you-overpaid-taxes-in-2020/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:55:00+00:00
 - user: None

Americans who paid too much taxes on unemployment benefits are receiving nearly $15 billion back.

## LastPass Breach: 5 Things to Do Right Now if You Use the Password Manager     - CNET
 - [https://www.cnet.com/tech/services-and-software/lastpass-breach-5-things-to-do-right-now-if-you-use-the-password-manager/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/lastpass-breach-5-things-to-do-right-now-if-you-use-the-password-manager/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:41:55+00:00
 - user: None

The first thing LastPass subscribers need to do is find a new password manager.

## If Gas Stoves Are Banned, These 2 Studies May Be the Reason     - CNET
 - [https://www.cnet.com/news/2-studies-show-gas-stoves-are-dangerous/#ftag=CADf328eec](https://www.cnet.com/news/2-studies-show-gas-stoves-are-dangerous/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:31:00+00:00
 - user: None

Two major studies released in the last seven months may lead to strict regulation or even a federal ban on natural gas stoves.

## 'The Last of Us' Release Schedule: When Does Episode 1 Land on HBO Max?     - CNET
 - [https://www.cnet.com/culture/entertainment/the-last-of-us-release-schedule-when-does-episode-1-land-on-hbo-max/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/the-last-of-us-release-schedule-when-does-episode-1-land-on-hbo-max/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:30:07+00:00
 - user: None

HBO's adaptation of the beloved PlayStation game begins this Sunday.

## 5 Ways to Save Money and Earn Interest     - CNET
 - [https://www.cnet.com/personal-finance/banking/ways-to-save-money-and-earn-interest/#ftag=CADf328eec](https://www.cnet.com/personal-finance/banking/ways-to-save-money-and-earn-interest/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:23:50+00:00
 - user: None

Consider these alternatives to a traditional savings account to protect the value of your money and earn the most interest.

## Score Up to 60% Off Apparel During Adidas' End of Season Sale     - CNET
 - [https://www.cnet.com/deals/score-up-to-60-off-apparel-during-adidas-end-of-season-sale/#ftag=CADf328eec](https://www.cnet.com/deals/score-up-to-60-off-apparel-during-adidas-end-of-season-sale/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:23:00+00:00
 - user: None

With this sale, you have thousands of options to upgrade your athletic style.

## Are You a MacBook Owner? Apple Might Owe You Up to $395     - CNET
 - [https://www.cnet.com/personal-finance/apple-macbook-keyboard-settlement-how-to-file-claim/#ftag=CADf328eec](https://www.cnet.com/personal-finance/apple-macbook-keyboard-settlement-how-to-file-claim/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 15:00:15+00:00
 - user: None

Apple has agreed to a $50 million settlement over claims its butterfly keyboards were defective.

## Will There Be a Gas Stove Ban? Here's What to Know     - CNET
 - [https://www.cnet.com/health/will-there-be-a-gas-stove-ban-heres-what-to-know/#ftag=CADf328eec](https://www.cnet.com/health/will-there-be-a-gas-stove-ban-heres-what-to-know/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:50:34+00:00
 - user: None

Research shows that natural gas stoves produce dangerous levels of air pollutants.

## Lisa Marie Presley, Singer and Elvis Presley's Daughter, Dies at 54     - CNET
 - [https://www.cnet.com/culture/entertainment/lisa-marie-presley-singer-and-elvis-presley-daughter-dies-at-54/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/lisa-marie-presley-singer-and-elvis-presley-daughter-dies-at-54/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:38:00+00:00
 - user: None

The singer-songwriter was rushed to hospital suffering a suspected cardiac arrest. She was Elvis' only child.

## Get 25% Off Sitewide and Two Free Dream Pillows With a Mattress Purchase at Helix     - CNET
 - [https://www.cnet.com/deals/get-25-off-sitewide-and-two-free-dream-pillows-with-a-mattress-purchase-at-helix/#ftag=CADf328eec](https://www.cnet.com/deals/get-25-off-sitewide-and-two-free-dream-pillows-with-a-mattress-purchase-at-helix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:33:00+00:00
 - user: None

If you've want a new mattress for better sleep, here's a deal to help you out.

## The Best Budget for You Might Be No Budget at All. Here's Why     - CNET
 - [https://www.cnet.com/personal-finance/the-best-budget-for-you-might-be-no-budget-at-all-heres-why/#ftag=CADf328eec](https://www.cnet.com/personal-finance/the-best-budget-for-you-might-be-no-budget-at-all-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:13:02+00:00
 - user: None

If you're struggling to start a budget, you can start with a low-key approach that stresses fundamentals over details.

## Current Mortgage Rates for Jan. 13, 2023: Rates in a Nosedive     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/current-mortgage-rates-for-jan-13-2023-rates-tick-down/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/current-mortgage-rates-for-jan-13-2023-rates-tick-down/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

Both 15- and 30-year mortgage rates sharply fell this week, though rates remain high compared to a year ago. The Fed's interest rate hikes have increased costs for prospective homebuyers.

## Here Are Today's Refinance Rates, Jan. 13, 2023: Rates Drop Off a Cliff     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-jan-13-2023-rates-drop-off/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-jan-13-2023-rates-drop-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

Several benchmark refinance rates plummeted this week. The Fed's interest rate hikes over the last year have affected the refinance market.

## Snag the Apple Studio Display at a Discount -- Save Up to $150     - CNET
 - [https://www.cnet.com/deals/snag-the-apple-studio-display-at-a-discount-save-up-to-150/#ftag=CADf328eec](https://www.cnet.com/deals/snag-the-apple-studio-display-at-a-discount-save-up-to-150/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:53:00+00:00
 - user: None

This 27-inch monitor delivers excellent color accuracy, solid speakers and more that make it a worthy splurge for Mac owners.

## Tech Companies Need to Be Held Accountable for Security, Experts Say     - CNET
 - [https://www.cnet.com/tech/services-and-software/tech-companies-need-to-be-held-accountable-for-security-experts-say/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/tech-companies-need-to-be-held-accountable-for-security-experts-say/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:00:17+00:00
 - user: None

All that tech may look cool, but it also needs to be secure.

## Nothing Phone 1 Comes to the US for $299 but This Is No Bargain     - CNET
 - [https://www.cnet.com/tech/mobile/nothing-phone-1-comes-to-the-us-for-299-but-this-is-no-bargain/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/nothing-phone-1-comes-to-the-us-for-299-but-this-is-no-bargain/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:00:11+00:00
 - user: None

Commentary: Nothing's US launch is called a beta for a reason.

## Marvel Snap: Beginner's Guide and Top Tips to Get Cards and Win Games     - CNET
 - [https://www.cnet.com/tech/gaming/marvel-snap-beginners-guide-and-top-tips-to-get-cards-and-win-games/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/marvel-snap-beginners-guide-and-top-tips-to-get-cards-and-win-games/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:00:07+00:00
 - user: None

Just starting out with Marvel's new mobile card game? Here's what you need to begin.

## A Sommelier Reveals How to Find Cheap Wines That Taste Expensive     - CNET
 - [https://www.cnet.com/how-to/a-sommelier-reveals-how-to-find-cheap-wines-that-taste-expensive/#ftag=CADf328eec](https://www.cnet.com/how-to/a-sommelier-reveals-how-to-find-cheap-wines-that-taste-expensive/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:00:03+00:00
 - user: None

Good wine doesn't always have to be expensive. Here's how to tell which bottles are the best value.

## Apple Please Steal This Tech for Apple Watch video     - CNET
 - [https://www.cnet.com/videos/apple-please-steal-this-tech-for-apple-watch/#ftag=CADf328eec](https://www.cnet.com/videos/apple-please-steal-this-tech-for-apple-watch/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 13:00:01+00:00
 - user: None

CNET's Bridget Carey saw some cool tech at CES that she would really like Apple to adopt now. Like the BHeart health-tracking wristband that never needs a charging cord.

## 6 Practical Storage Hacks to Organize Your Tiny Apartment or Home     - CNET
 - [https://www.cnet.com/how-to/6-practical-storage-hacks-to-organize-your-tiny-apartment-or-home/#ftag=CADf328eec](https://www.cnet.com/how-to/6-practical-storage-hacks-to-organize-your-tiny-apartment-or-home/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 12:30:03+00:00
 - user: None

Make any small space feel bigger with these hacks.

## Think Twice Before Buying a New Samsung Galaxy S22 Right Now     - CNET
 - [https://www.cnet.com/tech/mobile/think-twice-before-buying-a-new-samsung-galaxy-s22-right-now/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/think-twice-before-buying-a-new-samsung-galaxy-s22-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 12:00:38+00:00
 - user: None

The Galaxy S23 is likely right around the corner, so it's a good idea to wait.

## Is It Finally Time for a Touchscreen MacBook?     - CNET
 - [https://www.cnet.com/tech/computing/is-it-finally-time-for-a-touchscreen-macbook/#ftag=CADf328eec](https://www.cnet.com/tech/computing/is-it-finally-time-for-a-touchscreen-macbook/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

Apple may be ready to flip-flop on this controversial laptop feature request.

## Stop Putting Your Security Cameras in These 3 Spots     - CNET
 - [https://www.cnet.com/how-to/stop-putting-your-security-cameras-in-these-3-spots/#ftag=CADf328eec](https://www.cnet.com/how-to/stop-putting-your-security-cameras-in-these-3-spots/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 11:00:15+00:00
 - user: None

Improve your home security by understanding where you should actually put your cameras.

## The Best Buy Membership and Support Option You Need to Know About     - CNET
 - [https://www.cnet.com/deals/the-best-buy-membership-and-support-option-you-need-to-know-about/#ftag=CADf328eec](https://www.cnet.com/deals/the-best-buy-membership-and-support-option-you-need-to-know-about/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 11:00:07+00:00
 - user: None

If you shop at Best Buy frequently, this is a membership to consider.

## Easy Meal Prep Ideas for Simple, Hearty Meals     - CNET
 - [https://www.cnet.com/health/nutrition/simple-meal-prep-ideas-for-simple-hearty-meals/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/simple-meal-prep-ideas-for-simple-hearty-meals/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 11:00:03+00:00
 - user: None

Here are four tips on effective meal prepping and a few easy recipes for breakfast, lunch and dinner.

## 5 Super-Simple Ways to Improve Your Next Target Trip and Save Some Cash     - CNET
 - [https://www.cnet.com/deals/5-super-simple-ways-to-improve-your-target-shopping-trip/#ftag=CADf328eec](https://www.cnet.com/deals/5-super-simple-ways-to-improve-your-target-shopping-trip/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 09:00:02+00:00
 - user: None

Use these tips and tricks on your next trip to Target.

## Top Signs You Might Have Depression, and How to Get Help     - CNET
 - [https://www.cnet.com/health/mental/top-signs-you-might-have-depression-and-how-to-get-help/#ftag=CADf328eec](https://www.cnet.com/health/mental/top-signs-you-might-have-depression-and-how-to-get-help/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 06:00:00+00:00
 - user: None

Depression rates have spiked in both teens and adults. Here's what you should know.

## My Favorite Hidden iPhone Shortcut To Turn On The Flashlight (And More)     - CNET
 - [https://www.cnet.com/tech/mobile/my-favorite-hidden-iphone-shortcut-to-turn-on-the-flashlight-and-more/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/my-favorite-hidden-iphone-shortcut-to-turn-on-the-flashlight-and-more/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 03:03:00+00:00
 - user: None

This simple pro iPhone tip will save you time and fumbling.

## Lisa Marie Presley, Rock Legend's Daughter, Dies at 54     - CNET
 - [https://www.cnet.com/culture/entertainment/lisa-marie-presley-rock-legends-daughter-dies-at-54/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/lisa-marie-presley-rock-legends-daughter-dies-at-54/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 02:06:00+00:00
 - user: None

The singer and actor's only child was rushed to hospital suffering a suspected cardiac arrest.

## Lisa Marie Presley, Singer's Daughter, Dies at 54     - CNET
 - [https://www.cnet.com/culture/entertainment/lisa-marie-presley-singers-daughter-dies-at-54/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/lisa-marie-presley-singers-daughter-dies-at-54/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 02:06:00+00:00
 - user: None

The singer and actor's only child was rushed to hospital suffering a suspected cardiac arrest.

## More People Need to Watch This Captivating Mystery on Prime Video     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-captivating-mystery-on-prime-video/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-this-captivating-mystery-on-prime-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 02:02:00+00:00
 - user: None

Don your detective hat for a whodunit done right.

## Behold the Biggest Ancient Flower Ever Found Preserved in Amber     - CNET
 - [https://www.cnet.com/science/biology/behold-the-biggest-ancient-flower-ever-found-preserved-in-amber/#ftag=CADf328eec](https://www.cnet.com/science/biology/behold-the-biggest-ancient-flower-ever-found-preserved-in-amber/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 01:52:00+00:00
 - user: None

The absolute unit of a fossil flower is over 33 million years old and has been given a new name.

## Good Luck Spotting NASA's Mars Helicopter in This Puzzling Rover Image     - CNET
 - [https://www.cnet.com/science/space/good-luck-spotting-nasas-mars-helicopter-in-this-puzzling-rover-image/#ftag=CADf328eec](https://www.cnet.com/science/space/good-luck-spotting-nasas-mars-helicopter-in-this-puzzling-rover-image/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 01:48:00+00:00
 - user: None

Ingenuity is hiding out in the sandy Martian distance, but you'll need keen eyes to find it.

## See SpaceX Starship Gleaming on the Launchpad in Epic New Images     - CNET
 - [https://www.cnet.com/science/space/see-spacex-starship-gleaming-on-the-launchpad-in-epic-new-images/#ftag=CADf328eec](https://www.cnet.com/science/space/see-spacex-starship-gleaming-on-the-launchpad-in-epic-new-images/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 01:46:00+00:00
 - user: None

Shine on, you crazy diamond.

## 'Rick and Morty' Creator Justin Roiland Charged With Battery     - CNET
 - [https://www.cnet.com/culture/rick-and-morty-creator-justin-roiland-charged-with-battery/#ftag=CADf328eec](https://www.cnet.com/culture/rick-and-morty-creator-justin-roiland-charged-with-battery/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 01:28:39+00:00
 - user: None

Roiland has been charged with felony domestic violence in relation to a 2020 incident, according to documents seen by NBC.

## Apple CEO Tim Cook Could Take 40% Pay Cut in 2023     - CNET
 - [https://www.cnet.com/tech/apple-ceo-tim-cook-could-take-40-pay-cut-in-2023/#ftag=CADf328eec](https://www.cnet.com/tech/apple-ceo-tim-cook-could-take-40-pay-cut-in-2023/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 00:42:01+00:00
 - user: None

If the shareholders agree, Cook will have a lower stock compensation.

## Scroll-Wheel Click Will Help You Comparison Shop     - CNET
 - [https://www.cnet.com/tech/computing/scroll-wheel-click-will-help-you-comparison-shop/#ftag=CADf328eec](https://www.cnet.com/tech/computing/scroll-wheel-click-will-help-you-comparison-shop/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-13 00:18:00+00:00
 - user: None

Your mouse's scroll wheel has a hidden trick that helps when you need to open multiple tabs.
