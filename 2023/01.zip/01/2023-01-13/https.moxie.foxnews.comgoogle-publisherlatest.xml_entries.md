# Source Fox News, Source URL:https://moxie.foxnews.com/google-publisher/latest.xml, Source language: en-US

## Kate Middleton says 'talking therapies don't work for some people' following Prince Harry's 'Spare' release
 - [https://www.foxnews.com/entertainment/kate-middleton-talking-therapies-dont-work-some-people-following-prince-harrys-spare](https://www.foxnews.com/entertainment/kate-middleton-talking-therapies-dont-work-some-people-following-prince-harrys-spare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:34:35+00:00
 - user: None

Prince William and Kate Middleton, the Prince and Princess of Wales, kept calm and carried on with royal engagements following the publication of Prince Harry's explosive tell-all this week as they visited the Open Door Charity in Birkenhead, England.

## Dr. Anthony Fauci claps back at Elon Musk, GOP critics: I can defend everything I've said and done
 - [https://www.foxnews.com/media/dr-anthony-fauci-claps-back-elon-musk-other-critics-i-can-defend-everything-ive-said-done](https://www.foxnews.com/media/dr-anthony-fauci-claps-back-elon-musk-other-critics-i-can-defend-everything-ive-said-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:34:19+00:00
 - user: None

Retired NIAID director Dr. Anthony Fauci responds to critics, including Elon Musk, who are shredding his response to the COVID-19 pandemic on "Your World."

## Dallas police open criminal investigation after clouded leopard escapes from zoo exhibit
 - [https://www.foxnews.com/us/dallas-police-open-criminal-investigation-clouded-leopard-escapes-zoo-exhibit](https://www.foxnews.com/us/dallas-police-open-criminal-investigation-clouded-leopard-escapes-zoo-exhibit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:30:35+00:00
 - user: None

Dallas Zoo President & CEO Gregg Hudson explained that the leopard is likely still on the property but that finding it will prove to be a challenge.

## Russian officials rule 'no fault' for figure skater Kamila Valieva in doping probe
 - [https://www.foxnews.com/sports/russian-tribunal-rules-no-fault-for-skater-kamila-valieva-doping-probe](https://www.foxnews.com/sports/russian-tribunal-rules-no-fault-for-skater-kamila-valieva-doping-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:25:43+00:00
 - user: None

The Russian Anti-Doping Agency found figure skater Kamila Valieva did violate anti-doping rules but bore "no fault or negligence” for the act, the World Anti-Doping Agency said.

## Lisa Marie Presley honored by 'Elvis' director Baz Luhrmann: 'We will miss your warmth, your smile, your love'
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-honored-by-elvis-director-baz-luhrmann](https://www.foxnews.com/entertainment/lisa-marie-presley-honored-by-elvis-director-baz-luhrmann)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:16:26+00:00
 - user: None

"Elvis" director Baz Luhrmann honored Lisa Marie Presley on Instagram following her death. The only daughter of Elvis died suddenly at 54 on Thursday.

## New York Democrats introduce Santos Act aimed at preventing candidates from lying about background
 - [https://www.foxnews.com/politics/new-york-democrats-introduce-santos-act-aimed-preventing-candidates-lying-background](https://www.foxnews.com/politics/new-york-democrats-introduce-santos-act-aimed-preventing-candidates-lying-background)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:15:37+00:00
 - user: None

A new bill aimed at Rep. George Santos' lies about his resume and family history would require congressional candidates to file more background information with the FEC.

## Tom Brady is 'the most unathletic quarterback in the game,' Hall of Famer says
 - [https://www.foxnews.com/sports/tom-brady-most-unathletic-quarterback-game-hall-famer-says](https://www.foxnews.com/sports/tom-brady-most-unathletic-quarterback-game-hall-famer-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:08:31+00:00
 - user: None

Tom Brady is "the most unathletic quarterback in the game," Pro Football Hall of Famer Troy Aikman said on the "Sports Illustrated Media Podcast" this week.

## Trump's deposition unsealed in E. Jean Carroll defamation lawsuit
 - [https://www.foxnews.com/politics/trumps-deposition-unsealed-e-jean-carroll-defamation-lawsuit](https://www.foxnews.com/politics/trumps-deposition-unsealed-e-jean-carroll-defamation-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:02:42+00:00
 - user: None

Former President Trump's deposition in the E. Jean Carroll defamation case will be unsealed, U.S. District Judge Lewis Kaplin ordered on Friday.

## Hot car: Toyota built a hydrogen-powered classic
 - [https://www.foxnews.com/auto/hot-car-toyota-built-hydrogen-powered-classic](https://www.foxnews.com/auto/hot-car-toyota-built-hydrogen-powered-classic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 23:00:05+00:00
 - user: None

Toyota has converted its classic AE86 sports car to burn hydrogen instead of gasoline. It also has an electric motor that's connected to a manual transmission.

## Congress blocks funding request for Microsoft headsets after testing concerns: report
 - [https://www.foxnews.com/tech/congress-blocks-funding-request-microsoft-heads-testing-concerns-report](https://www.foxnews.com/tech/congress-blocks-funding-request-microsoft-heads-testing-concerns-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:48:13+00:00
 - user: None

Congress reportedly declined an Army request for $400 million to buy Microsoft headsets after concerns over testing, but a new generation of the devices is still being funded.

## Meghan Markle, Kate Middleton's royal tailor speaks out on fallout amid Prince Harry's 'Spare' release
 - [https://www.foxnews.com/entertainment/meghan-markle-kate-middletons-royal-tailor-speaks-fallout-amid-prince-harrys-spare](https://www.foxnews.com/entertainment/meghan-markle-kate-middletons-royal-tailor-speaks-fallout-amid-prince-harrys-spare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:45:45+00:00
 - user: None

Royal tailor Ajay Mirpuri broke his silence about the fallout between Meghan Markle and Kate Middleton that occurred days before the Duke and Duchess of Sussex married in May 2018.

## LAPD bans Thin Blue Line flag over complaint it represents 'racist, bigoted views'
 - [https://www.foxnews.com/media/lapd-bans-thin-blue-line-complaint-represents-violent-extremist-views](https://www.foxnews.com/media/lapd-bans-thin-blue-line-complaint-represents-violent-extremist-views)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:43:18+00:00
 - user: None

The Los Angeles Police Department and a township in Pennsylvania voted to ban the Thin Blue Line flag from public areas saying the symbol was offensive.

## Robbie Knievel, American daredevil and son of Evel Knievel, dead at 60
 - [https://www.foxnews.com/sports/robbie-knievel-american-daredevil-son-evel-knievel-dead-60](https://www.foxnews.com/sports/robbie-knievel-american-daredevil-son-evel-knievel-dead-60)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:32:55+00:00
 - user: None

Robbie Knievel, daredevil and son of Evel Knievel, died Friday morning after battling pancreatic cancer, his family confirmed to The Associated Press.

## Ana Walshe update: Warrants executed in case of missing Cohasset mom
 - [https://www.foxnews.com/us/ana-walshe-update-warrants-executed-case-missing-cohasset-mom](https://www.foxnews.com/us/ana-walshe-update-warrants-executed-case-missing-cohasset-mom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:31:25+00:00
 - user: None

Search warrants were executed Thursday in Massachusetts as investigators continue to look into the disappearance of Cohasset mother and real estate executive Ana Walshe.

## Karine Jean-Pierre grilled for claiming DeSantis ‘made a mockery’ of immigration system: ‘Talk is cheap'
 - [https://www.foxnews.com/media/karine-jean-pierre-grilled-claiming-desantis-made-mockery-immigration-system-talk-cheap](https://www.foxnews.com/media/karine-jean-pierre-grilled-claiming-desantis-made-mockery-immigration-system-talk-cheap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:30:29+00:00
 - user: None

Critics blasted White House Press Secretary Karine Jean-Pierre after she accused Gov. Ron DeSantis, R-Fla., of making a "mockery" of the immigration system.

## Louisiana woman raped during drug sting while working as informant sues police handlers
 - [https://www.foxnews.com/us/louisiana-woman-raped-drug-sting-working-informant-sues-police-handlers](https://www.foxnews.com/us/louisiana-woman-raped-drug-sting-working-informant-sues-police-handlers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:30:20+00:00
 - user: None

A woman working as a Louisiana police informant was raped twice during a drug buy, she claims in a lawsuit against her handlers.

## Matt Taibbi rips 'reprehensible' Ted Lieu after Dem accuses Twitter Files writer of 'Kremlin talking points'
 - [https://www.foxnews.com/media/matt-taibbi-rips-reprehensible-ted-lieu-after-dem-accuses-twitter-files-writer-kremlin-talking-points](https://www.foxnews.com/media/matt-taibbi-rips-reprehensible-ted-lieu-after-dem-accuses-twitter-files-writer-kremlin-talking-points)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 22:29:10+00:00
 - user: None

Substack writer Matt Taibbi clashed with Rep. Ted Lieu, D-Calif., who rejected the latest installment of Elon Musk's "Twitter Files" that implicated top Democrats.

## Lisa Marie Presley remembered by Nicolas Cage and the Michael Jackson Estate: 'She lit up every room'
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-remembered-nicolas-cage-michael-jackson-estate](https://www.foxnews.com/entertainment/lisa-marie-presley-remembered-nicolas-cage-michael-jackson-estate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:56:26+00:00
 - user: None

Nicolas Cage and the Michael Jackson Estate are speaking out about the death of Lisa Marie Presley at the age of 54 on Thursday. She was married to Michael Jackson in 1994 and Nicolas Cage in 2002.

## Pentagon considers back pay for troops discharged over now-repealed COVID vaccine mandate
 - [https://www.foxnews.com/politics/pentagon-considers-back-pay-troops-discharged-now-repealed-covid-vaccine-mandate](https://www.foxnews.com/politics/pentagon-considers-back-pay-troops-discharged-now-repealed-covid-vaccine-mandate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:50:05+00:00
 - user: None

The Pentagon says it is considering back pay for service members discharged for refusing the coronavirus vaccine following the mandate's repeal.

## Bills to pay Damar Hamlin’s full salary despite landing on injured reserve: report
 - [https://www.foxnews.com/sports/bills-pay-damar-hamlins-full-salary-despite-landing-injured-reserve-report](https://www.foxnews.com/sports/bills-pay-damar-hamlins-full-salary-despite-landing-injured-reserve-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:46:44+00:00
 - user: None

The Buffalo Bills will pay Damar Hamlin his full salary despite his landing on the injured reserve. A clause in his contract allows Buffalo to pay him less if he lands on the IR.

## Sean McVay will remain head coach of Rams: reports
 - [https://www.foxnews.com/sports/sean-mcvay-will-remain-head-coach-of-rams-reports](https://www.foxnews.com/sports/sean-mcvay-will-remain-head-coach-of-rams-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:37:30+00:00
 - user: None

Sean McVay will remain the head coach of the Los Angeles Rams. The 36-year-old had been contemplating his future with the team following its 5-12 season.

## Meghan Markle bullying claims: Palace is 'protecting' the duchess by keeping review private, experts claim
 - [https://www.foxnews.com/entertainment/meghan-markle-bullying-claims-palace-protecting-duchess-keeping-review-private-experts-claim](https://www.foxnews.com/entertainment/meghan-markle-bullying-claims-palace-protecting-duchess-keeping-review-private-experts-claim)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:36:41+00:00
 - user: None

Despite Buckingham Palace keeping its finding private, Valentine Low alleged that former palace staff are standing by their allegations of bullying by the Duchess of Sussex.

## Idaho murders suspect Bryan Kohberger’s grad program had access to ‘crime lab’ with camera streams: insider
 - [https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohbergers-grad-program-had-access-crime-lab-camera-streams-insider](https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohbergers-grad-program-had-access-crime-lab-camera-streams-insider)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:34:09+00:00
 - user: None

Bryan Kohberger's Ph.D. program at WSU maintains access to a "crime lab" database of bodycam videos and live streams from security cameras, a source says.

## Biden spends weekend at Wilmington house where lawyers discovered classified docs
 - [https://www.foxnews.com/politics/biden-spends-weekend-wilmington-house-lawyers-discovered-classified-docs](https://www.foxnews.com/politics/biden-spends-weekend-wilmington-house-lawyers-discovered-classified-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:33:18+00:00
 - user: None

President Biden is spending his weekend at his residence in Wilmington, Delaware, where Obama-era classified documents were found this week.

## Texas man accused of decapitating newlywed wife allegedly steals beer from store where victim worked
 - [https://www.foxnews.com/us/texas-man-accused-decapitating-newlywed-wife-allegedly-steals-beer-store-victim-worked](https://www.foxnews.com/us/texas-man-accused-decapitating-newlywed-wife-allegedly-steals-beer-store-victim-worked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:25:08+00:00
 - user: None

A Texas man accused of killing his wife allegedly stole a beer from a convenience store moments after the slaying.

## Maine AG says deputy was legally justified in fatal shooting of armed 16-year-old
 - [https://www.foxnews.com/us/maine-ag-deputy-legally-justified-fatal-shooting-armed-16-year-old](https://www.foxnews.com/us/maine-ag-deputy-legally-justified-fatal-shooting-armed-16-year-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:11:38+00:00
 - user: None

Maine's attorney general's office announced that the deputy who killed an armed 16-year-old girl was justified in doing so. The teen was holding a store employee hostage.

## US nuclear agency’s multibillion-dollar project falls short in scheduling, cost estimates
 - [https://www.foxnews.com/us/us-nuclear-agencys-multibillion-dollar-project-falls-short-scheduling-cost-estimates](https://www.foxnews.com/us/us-nuclear-agencys-multibillion-dollar-project-falls-short-scheduling-cost-estimates)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:11:04+00:00
 - user: None

After 30 years of not regularly producing plutonium cores, a nuclear project is struggling to meet its congressional mandated deadline of producing 80 by 2030.

## Stephen Curry 'excited' to visit President Biden after skipping White House trips during Trump's presidency
 - [https://www.foxnews.com/sports/stephen-curry-excited-visit-president-biden-skipping-white-house-trips-trumps-presidency](https://www.foxnews.com/sports/stephen-curry-excited-visit-president-biden-skipping-white-house-trips-trumps-presidency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:09:02+00:00
 - user: None

The Golden State Warriors will visit the White House for the first time since Barack Obama's presidency, despite winning twice while former President Trump was in office.

## Bills honor local hero who saved 24 people during Buffalo blizzard with Super Bowl tickets
 - [https://www.foxnews.com/sports/bills-honor-local-hero-who-saved-24-people-during-buffalo-blizzard-with-super-bowl-tickets](https://www.foxnews.com/sports/bills-honor-local-hero-who-saved-24-people-during-buffalo-blizzard-with-super-bowl-tickets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:07:55+00:00
 - user: None

Buffalo Bills legend Thurman Thomas hand-delivered two Super Bowl tickets to Jay Withey on Friday after he saved 24 people during last month’s deadly winter blizzard.

## Pennsylvania court decides special elections to fill state House vacancies will be held on Feb. 7
 - [https://www.foxnews.com/politics/pennsylvania-court-decides-special-elections-fill-house-vacancies-held-feb-7](https://www.foxnews.com/politics/pennsylvania-court-decides-special-elections-fill-house-vacancies-held-feb-7)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 21:04:24+00:00
 - user: None

The election to fill the three vacancies in the Pennsylvania House are set to be held on Feb. 7. Partisan control of the state's chamber is at stake.

## Debate in Spain over regional abortion rights restrictions
 - [https://www.foxnews.com/world/debate-spain-regional-abortion-rights-restrictions](https://www.foxnews.com/world/debate-spain-regional-abortion-rights-restrictions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:57:16+00:00
 - user: None

Spain debated regional abortion rights and restrictions, as new measures in Castile and Leon angered abortion activists.

## NV lithium mine used in EV production receives $700M conditional loan from US Energy Department
 - [https://www.foxnews.com/us/nv-lithium-mine-used-ev-production-receives-700m-conditional-loan-us-energy-department](https://www.foxnews.com/us/nv-lithium-mine-used-ev-production-receives-700m-conditional-loan-us-energy-department)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:56:22+00:00
 - user: None

A Nevada lithium mine may receive a $700 million loan contingent on an environmental impact statement, as the project could damage an endangered flower species.

## Rapper Meek Mill's probation ends after pardon from Pennsylvania Gov. Tom Wolf
 - [https://www.foxnews.com/us/rapper-meek-mills-probation-ends-pardon-pennsylvania-gov-tom-wolf](https://www.foxnews.com/us/rapper-meek-mills-probation-ends-pardon-pennsylvania-gov-tom-wolf)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:54:23+00:00
 - user: None

Pennsylvania's governor pardoned rapper Meek Mill after years of probation. Meek Mill has been active in criminal justice reform for years in Pennsylvania.

## 40th Key West literary seminar focuses on Black literature
 - [https://www.foxnews.com/us/40th-key-west-literary-seminar-focuses-black-literature](https://www.foxnews.com/us/40th-key-west-literary-seminar-focuses-black-literature)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:52:59+00:00
 - user: None

The 40th annual Key West literary seminar will explore Black literature and African American literary history. Nearly 500 people are attending the seminar, which began Thursday.

## NY Dem calls on George Santos constituents to confront him in person, make his life a 'living nightmare'
 - [https://www.foxnews.com/politics/ny-dem-calls-george-santos-constituents-confront-him-person-make-his-life-living-nightmare](https://www.foxnews.com/politics/ny-dem-calls-george-santos-constituents-confront-him-person-make-his-life-living-nightmare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:52:49+00:00
 - user: None

A Nassau County Democratic lawmaker called on New York voters to confront Republican Rep. George Santos and "make his life a living nightmare" at a protest outside Santos' Queens office Friday.

## Florida hires more than 1,000 officers in six-month period, with bonuses totaling $5M
 - [https://www.foxnews.com/politics/florida-hires-1000-officers-six-month-period-bonuses-totaling-5m](https://www.foxnews.com/politics/florida-hires-1000-officers-six-month-period-bonuses-totaling-5m)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:11:34+00:00
 - user: None

Florida has hired more than 1,000 officers since last summer, awarding those who joined the state's law enforcement ranks with bonuses that totaled more than $5 million.

## Indian army general says situation on border with China is ‘unpredictable’
 - [https://www.foxnews.com/world/indian-army-general-says-situation-border-china-unpredictable](https://www.foxnews.com/world/indian-army-general-says-situation-border-china-unpredictable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:07:13+00:00
 - user: None

The saber-rattling between communist China and India is rising due to a bitter territorial conflict that has remained unresolved for over 50 years.

## Byron Donalds: Biden's response to Peter Doocy was the 'most idiotic thing I ever heard'
 - [https://www.foxnews.com/media/byron-donalds-biden-response-peter-doocy-idiotic-thing-ever-heard](https://www.foxnews.com/media/byron-donalds-biden-response-peter-doocy-idiotic-thing-ever-heard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:00:47+00:00
 - user: None

Rep. Byron Donalds, R-Fla., ridicules President Biden over his response to Fox News' Peter Doocy's question surrounding the second batch of classified documents.

## Dozens of illegal immigrants land on Florida beach, run from police as migrant crisis surges away from border
 - [https://www.foxnews.com/us/dozens-illegal-immigrants-land-florida-beach-run-from-police-migrant-crisis-surges-away-from-border](https://www.foxnews.com/us/dozens-illegal-immigrants-land-florida-beach-run-from-police-migrant-crisis-surges-away-from-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:00:37+00:00
 - user: None

More than two dozen illegal immigrants ran from police officers in Florida after their boat landed at a nearby beach as the influx of migrants into the state continues to surge.

## Kevin McCarthy's speakership of the people, by the people, for the people
 - [https://www.foxnews.com/opinion/kevin-mccarthy-speakership-of-people-by-people-for-people](https://www.foxnews.com/opinion/kevin-mccarthy-speakership-of-people-by-people-for-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 20:00:26+00:00
 - user: None

Kevin McCarthy delivered an historic address after winning on the 15th ballot for the U.S. House speakership.

## CDC identifies possible 'safety concern' for certain people receiving COVID vaccines
 - [https://www.foxnews.com/health/cdc-identifies-possible-safety-concern-certain-people-receiving-covid-vaccines](https://www.foxnews.com/health/cdc-identifies-possible-safety-concern-certain-people-receiving-covid-vaccines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:58:44+00:00
 - user: None

The CDC has identified a "safety signal" in the Bivalent Pfizer-BioNTech and is investigating whether the shot creates an increased stroke risk for people 65 and older.

## NASA’s Webb uncovers star formation in cluster's 'dusty ribbons'
 - [https://www.foxnews.com/science/nasas-webb-uncovers-star-formation-clusters-dusty-ribbons](https://www.foxnews.com/science/nasas-webb-uncovers-star-formation-clusters-dusty-ribbons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:55:30+00:00
 - user: None

New findings from the James Webb Space Telescope are shedding light on star formation in a dynamic cluster located in a dwarf galaxy that lies close to the Milky Way.

## Al Michaels says calling 'dreadful' 'Thursday Night Football' games was like trying to sell 'used car'
 - [https://www.foxnews.com/sports/al-michaels-says-calling-dreadful-thursday-night-football-games-was-trying-sell-used-car](https://www.foxnews.com/sports/al-michaels-says-calling-dreadful-thursday-night-football-games-was-trying-sell-used-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:53:00+00:00
 - user: None

In an interview with The Athletic, legendary sports broadcaster Al Michaels recalled some of the lackluster games he had to call during "Thursday Night Football."

## Houston police arrest suspect in slaying of man found wrapped in blankets in closet last year
 - [https://www.foxnews.com/us/houston-police-arrest-suspect-slaying-man-found-wrapped-blankets-closet-last-year](https://www.foxnews.com/us/houston-police-arrest-suspect-slaying-man-found-wrapped-blankets-closet-last-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:48:59+00:00
 - user: None

A man has been charged in the death of another man found dead wrapped in blankets inside a closet last year, Houston authorities said

## Dallas Zoo clouded leopard escapes, massive search underway
 - [https://www.foxnews.com/us/dallas-zoo-clouded-leopard-escapes-massive-search-underway](https://www.foxnews.com/us/dallas-zoo-clouded-leopard-escapes-massive-search-underway)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:26:58+00:00
 - user: None

The Dallas Zoo was closed to the public Friday after officials discovered a clouded leopard has escaped from its habitat. Officials believe it is on the grounds.

## In Nevada, $1,000 reward offered in search for suspect in deer poaching case
 - [https://www.foxnews.com/us/nevada-1000-reward-offered-search-suspect-deer-poaching-case](https://www.foxnews.com/us/nevada-1000-reward-offered-search-suspect-deer-poaching-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:17:44+00:00
 - user: None

A reward of $1,000 is being offered in exchange for information leading to an arrest in a deer poaching case in Nevada. Authorities believe a mule deer was killed illegally.

## Lisa Marie Presley to be buried at Graceland next to her beloved son, Benjamin Keough
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-buried-graceland-beloved-son-benjamin-keough](https://www.foxnews.com/entertainment/lisa-marie-presley-buried-graceland-beloved-son-benjamin-keough)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:13:10+00:00
 - user: None

Lisa Marie Presley will be buried at Graceland, her father Elvis’ mansion, next to her beloved son.

## Niagara Bottling plans to build $160M beverage facility in Louisiana
 - [https://www.foxnews.com/us/niagara-bottling-plans-build-160m-beverage-facility-louisiana](https://www.foxnews.com/us/niagara-bottling-plans-build-160m-beverage-facility-louisiana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:10:18+00:00
 - user: None

State officials announced Wednesday that Niagara Bottling is planning to build a $160 million beverage plant in Louisiana. The new facility is anticipated to create 70 new jobs.

## AZ pedestrian fatally struck by oncoming train
 - [https://www.foxnews.com/us/az-pedestrian-fatally-struck-oncoming-train](https://www.foxnews.com/us/az-pedestrian-fatally-struck-oncoming-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:10:03+00:00
 - user: None

An oncoming train has struck and killed a 37-year-old pedestrian in Flagstaff, Arizona. The man, identified as Cecil Begay, was pronounced dead at the scene.

## Mega Millions jackpot reaches $1.35 billion ahead of Friday night's drawing
 - [https://www.foxnews.com/us/mega-millions-jackpot-reaches-1-35-billion-ahead-friday-nights-drawing](https://www.foxnews.com/us/mega-millions-jackpot-reaches-1-35-billion-ahead-friday-nights-drawing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:09:23+00:00
 - user: None

The Jackpot for Friday nights Mega Millions drawing has reached $1.35 billion. The Mega Millions Jackpot is played in 45 states as well as the U.S. Virgin Islands and Washington, D.C.

## Supreme Court in Sri Lanka orders former president to pay victims of 2019 Easter Sunday bomb attacks
 - [https://www.foxnews.com/world/supreme-court-sri-lanka-says-communication-breakdown-between-countrys-officials-2019-bombing](https://www.foxnews.com/world/supreme-court-sri-lanka-says-communication-breakdown-between-countrys-officials-2019-bombing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:08:51+00:00
 - user: None

A bombing in Sri Lanka during a 2019 Easter ceremony killed 270 people. The country's Supreme Court ruled that inaction by the former president and other officials led to the attack.

## Belarusian investigators use photo of politician shaking hands with Hillary Clinton against him
 - [https://www.foxnews.com/world/belarusian-investigators-photo-politician-shaking-hands-hillary-clinton-against-him](https://www.foxnews.com/world/belarusian-investigators-photo-politician-shaking-hands-hillary-clinton-against-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:07:39+00:00
 - user: None

Andrey Dzmitryeu, a Belarusian politician who is facing four years in prison, was pictured shaking hands with Hillary Clinton. Investigators in the case are using the photo against him

## COVID XBB.1.5 variant now accounts for 43% of all US cases, CDC says
 - [https://www.foxnews.com/health/covid-xbb-1-5-variant-accounts-43-all-us-cases-cdc-says](https://www.foxnews.com/health/covid-xbb-1-5-variant-accounts-43-all-us-cases-cdc-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:04:38+00:00
 - user: None

Omicron subvariant XBB.1.5 now makes up 43% of all COVID-19 cases in the United States, up from the 30% reported in the first week of January.

## Michigan school trustee demands answers after students pole danced on class trip: 'How did we get here?'
 - [https://www.foxnews.com/media/michigan-school-trustee-demands-answers-students-pole-danced-class-trip-get](https://www.foxnews.com/media/michigan-school-trustee-demands-answers-students-pole-danced-class-trip-get)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 19:00:49+00:00
 - user: None

Rochester Community Schools board members could face legal action after trustee Andrew Weaver called for transparency after photos emerged of students dancing on poles.

## Inside the marriage of Brian Walshe and his missing wife Ana: 'love at first sight'
 - [https://www.foxnews.com/us/inside-marriage-brian-walshe-missing-wife-ana-love-first-sight](https://www.foxnews.com/us/inside-marriage-brian-walshe-missing-wife-ana-love-first-sight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:14:53+00:00
 - user: None

Missing real estate executive Ana Walshe described her marriage to her husband, Brian, as 'love at first sight' – but cracks emerged early in the Cohasset couple's relationship.

## Numerous people visited Joe Biden's house while classified documents were stored in his Wilmington garage
 - [https://www.foxnews.com/politics/numerous-people-visited-joe-bidens-house-classified-documents-stored-wilmington-garage](https://www.foxnews.com/politics/numerous-people-visited-joe-bidens-house-classified-documents-stored-wilmington-garage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:12:17+00:00
 - user: None

White House press secretary Karine Jean-Pierre dodged questions Thursday on whether the Biden administration would release a visitor log of the president's Wilmington residence.

## Bookstore owner goes viral after revealing customer returned $800 in books allegedly meant to stage a home
 - [https://www.foxnews.com/lifestyle/bookstore-owner-goes-viral-revealing-customer-returned-800-books-allegedly-meant-stage-home](https://www.foxnews.com/lifestyle/bookstore-owner-goes-viral-revealing-customer-returned-800-books-allegedly-meant-stage-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:10:45+00:00
 - user: None

The Fox News Lifestyle Newsletter brings you trending stories on family, travel, food, neighbors helping neighbors, pets, autos, military veterans, heroes, faith and American values.

## Port of South Louisiana agrees to buy former Avondale Shipyards
 - [https://www.foxnews.com/us/port-south-louisiana-agrees-buy-former-avondale-shipyards](https://www.foxnews.com/us/port-south-louisiana-agrees-buy-former-avondale-shipyards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:10:26+00:00
 - user: None

The Port of South Louisiana has agreed to buy the former Avondale Shipyards for $445 million. This purchase will help the port's international trade become more completive

## Minnesota Gov. Walz gives tax relief bill 1st signature of legislative session
 - [https://www.foxnews.com/politics/minnesota-gov-walz-gives-tax-relief-bill-1st-signature-legislative-session](https://www.foxnews.com/politics/minnesota-gov-walz-gives-tax-relief-bill-1st-signature-legislative-session)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:09:19+00:00
 - user: None

Democratic Minnesota Gov. Tim Walz signed his first bill of the 2023 legislative session Thursday, which focused on simplifying tax filing and more broadly providing tax relief.

## Nevada’s Highway 208 to close for months after heavy rain triggers huge landslide
 - [https://www.foxnews.com/us/nevadas-highway-208-close-months-heavy-rain-triggers-huge-landslide](https://www.foxnews.com/us/nevadas-highway-208-close-months-heavy-rain-triggers-huge-landslide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:06:26+00:00
 - user: None

Nevada’s Highway 208, which stretches 10 miles long, is expected to be closed for months after Wilson Canyon area saw the heaviest precipitation there in over a century.

## Sweden looking to abolish permits needed for dancing
 - [https://www.foxnews.com/world/sweden-looking-abolish-permits-needed-dancing](https://www.foxnews.com/world/sweden-looking-abolish-permits-needed-dancing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:05:41+00:00
 - user: None

The Swedish government is seeking to eliminate a decade-old rule that requires establishments to obtain permits to allow customers to dance.

## Black instructor at Black college deemed ‘anti-Black’ for asking that students not wear ‘durag', 'hoodies'
 - [https://www.foxnews.com/media/black-instructor-black-college-deemed-anti-black-asking-that-students-wear-durag-hoodies](https://www.foxnews.com/media/black-instructor-black-college-deemed-anti-black-asking-that-students-wear-durag-hoodies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 18:00:57+00:00
 - user: None

One Black college instructor at a historically Black college was accused of being "anti-Black" for his dress code policies that forbade "hoodies," "durags" and "twerk shorts."

## 'Not taking our gas stoves': Gov. DeSantis flames Biden agency considering gas stove ban chaos in unique way
 - [https://www.foxnews.com/politics/not-taking-gas-stoves-governor-desantis-flames-biden-agency-considering-gas-stove-ban-unique-way](https://www.foxnews.com/politics/not-taking-gas-stoves-governor-desantis-flames-biden-agency-considering-gas-stove-ban-unique-way)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:57:31+00:00
 - user: None

Governor Ron DeSantis of Florida vowed that nobody would be "taking our gas stoves away," after a CPSC commissioner suggested a ban was "on the table."

## Lakers’ LeBron James sounds off on no-call at end of regulation against Mavs: ‘That s--- is blatant’
 - [https://www.foxnews.com/sports/lakers-lebron-james-sounds-off-no-call-end-regulation-against-mavs-that-s-is-blatant](https://www.foxnews.com/sports/lakers-lebron-james-sounds-off-no-call-end-regulation-against-mavs-that-s-is-blatant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:55:57+00:00
 - user: None

Los Angeles Lakers star LeBron James was not pleased with a no-call on Tim Hardaway Jr. at the end of regulation that sent the game into overtime.

## Kids under 14 are dying of fentanyl poisoning faster than any other age group: analysis
 - [https://www.foxnews.com/us/kids-under-14-are-dying-fentanyl-poisoning-faster-any-other-age-group-analysis](https://www.foxnews.com/us/kids-under-14-are-dying-fentanyl-poisoning-faster-any-other-age-group-analysis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:41:01+00:00
 - user: None

Children under 14 are dying of fentanyl poisoning at a faster rate than any other age group, according to a new analysis of CDC data by Families Against Fentanyl.

## Biden admin gives top energy post to climate activist who failed Senate confirmation over ethics concerns
 - [https://www.foxnews.com/politics/biden-admin-gives-top-energy-post-climate-activist-failed-senate-confirmation-ethics-concerns](https://www.foxnews.com/politics/biden-admin-gives-top-energy-post-climate-activist-failed-senate-confirmation-ethics-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:12:11+00:00
 - user: None

The Biden administration appointed Elizabeth Klein, who has previously been questioned for potential conflicts of interest, to lead the Bureau of Ocean Energy Management.

## NV Gov. Joe Lombardo orders indefinite freeze on new state regulations
 - [https://www.foxnews.com/politics/nv-gov-joe-lombardo-orders-indefinite-freeze-new-state-regulations](https://www.foxnews.com/politics/nv-gov-joe-lombardo-orders-indefinite-freeze-new-state-regulations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:10:19+00:00
 - user: None

Nevada Gov. Joe Lombardo signed an order freezing new state regulations. Agencies will be required to recommend 10 eliminations to streamline regulation processes.

## Rep. Anna Paulina Luna says media sees conservative minorities as a 'threat': They thought I would 'roll over'
 - [https://www.foxnews.com/media/rep-anna-paulina-luna-media-conservative-minorities-threat](https://www.foxnews.com/media/rep-anna-paulina-luna-media-conservative-minorities-threat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:05:58+00:00
 - user: None

In an interview with Fox News Digital, Rep. Anna Paulina Luna, R-Fla., spoke about the media's hostility towards conservative minorities and what her top priorities are in Congress.

## Squad Dem launches wild rant defending 'wokeness', says Chip Roy wants 'old America' that 'enslaved Africans'
 - [https://www.foxnews.com/politics/squad-democrat-wild-rant-wokeness-chip-roy-old-america-enslaves-africans](https://www.foxnews.com/politics/squad-democrat-wild-rant-wokeness-chip-roy-old-america-enslaves-africans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:05:37+00:00
 - user: None

Far-left Squad member Rep. Jamaal Bowman, D-N.Y., launched on a wild rant against Rep. Chip Roy, R-Texas, claiming he wanted to go back to the "old America" that "enslaved Africans."

## Columbia, Missouri police fatally shoot man who rushed at officers with knife
 - [https://www.foxnews.com/us/columbia-missouri-police-fatally-shot-man-rushed-officers-knife](https://www.foxnews.com/us/columbia-missouri-police-fatally-shot-man-rushed-officers-knife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:03:56+00:00
 - user: None

Police in Columbia, Missouri fatally shot a man who rushed at officers with a knife Wednesday night. The suspect was accused of assaulting several people at a RV park home.

## Wisconsin, North Carolina latest states to ban TikTok on government-issued devices
 - [https://www.foxnews.com/politics/wisconsin-north-carolina-latest-states-ban-tiktok-government-issued-devices](https://www.foxnews.com/politics/wisconsin-north-carolina-latest-states-ban-tiktok-government-issued-devices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:02:03+00:00
 - user: None

Govs. Tony Evers of Wisconsin and Roy Cooper of North Carolina, both Democrats, are among the most recent in the nation to have signed off on TikTok bans for government devices.

## Remembering Lisa Marie Presley: Elvis and Priscilla’s only child, survived by mother, 3 daughters
 - [https://www.foxnews.com/entertainment/remembering-lisa-marie-presley-elvis-priscillas-only-child-survived-mother-3-daughters](https://www.foxnews.com/entertainment/remembering-lisa-marie-presley-elvis-priscillas-only-child-survived-mother-3-daughters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:00:56+00:00
 - user: None

Lisa Marie Presley died suddenly on January 12, after being rushed to the hospital. She is survived by her mother Priscilla, 33-year-old daughter Riley Keough, and her 14-year-old twins Harper and Finley Lockwood. In 2020, Lisa Marie lost her son Benjamin to suicide.

## Four McCarthy holdouts get seats on top House committees
 - [https://www.foxnews.com/politics/four-mccarthy-holdouts-seats-top-house-committees](https://www.foxnews.com/politics/four-mccarthy-holdouts-seats-top-house-committees)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:00:14+00:00
 - user: None

Four GOP lawmakers who stalled Kevin McCarthy’s speakership until he met their demands earned seats for the first time on some of the chambers powerful committee.

## House Republicans will keep you safe from Biden's disastrous border policies
 - [https://www.foxnews.com/opinion/house-republicans-will-keep-you-safe-bidens-disastrous-border-policies](https://www.foxnews.com/opinion/house-republicans-will-keep-you-safe-bidens-disastrous-border-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 17:00:00+00:00
 - user: None

House Republicans will keep Americans safe from Biden's repeated failures on national security, disastrous border policies and threats from cybercrime.

## Elvis' daughter Lisa Marie Presley was music royalty but fame brought sadness and pain
 - [https://www.foxnews.com/opinion/elvis-daughter-lisa-marie-presley-music-royalty-fame-brought-sadness-pain](https://www.foxnews.com/opinion/elvis-daughter-lisa-marie-presley-music-royalty-fame-brought-sadness-pain)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:52:29+00:00
 - user: None

Lisa Marie Presley died on Thursday night. The daughter of Elvis and Priscilla Presley she was only 54 years old. She was also married to Michael Jackson and later Nicholas Cage.

## The Empire State Building: New York’s most famous building
 - [https://www.foxnews.com/lifestyle/the-empire-state-building-new-yorks-most-famous-building](https://www.foxnews.com/lifestyle/the-empire-state-building-new-yorks-most-famous-building)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:13:52+00:00
 - user: None

This 1,454-foot-tall Art Deco skyscraper is one of the most famous buildings in the world. The Empire State building was constructed in 1930 and built in one year and 45 days.

## Best printers for 2023
 - [https://www.foxnews.com/tech/best-printers-2023](https://www.foxnews.com/tech/best-printers-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:12:21+00:00
 - user: None

Kurt "CyberGuy" Knutsson shares his preferred list of printers in 2023 that will fit into a work office, a home workspace, or any other situation that needs printing.

## US Treasury Secretary Janet Yellen traveling to Senegal, Zambia, South Africa
 - [https://www.foxnews.com/us/us-treasury-secretary-janet-yellen-traveling-senegal-zambia-south-africa](https://www.foxnews.com/us/us-treasury-secretary-janet-yellen-traveling-senegal-zambia-south-africa)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:08:00+00:00
 - user: None

Janet Yellen is traveling to South Africa, Zambia, and Senegal to strengthen the relationship between the United States and Africa. President Biden will also travel to Africa this year.

## Czechs begin to vote for new president to succeed Zeman, Andrej Babis leads field
 - [https://www.foxnews.com/world/czechs-begin-vote-new-president-succeed-zeman-andrej-babis-leads-field](https://www.foxnews.com/world/czechs-begin-vote-new-president-succeed-zeman-andrej-babis-leads-field)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:07:10+00:00
 - user: None

Voting has began in the election to replace Milos Zeman in the Czech Republic. The eight candidate field is led by billionaire Andrej Babis.

## GOP rep introduces bill to restart border wall construction, days after Mexican president lauds Biden
 - [https://www.foxnews.com/politics/gop-rep-introduces-bill-restart-border-wall-construction-days-mexican-president-lauds-biden](https://www.foxnews.com/politics/gop-rep-introduces-bill-restart-border-wall-construction-days-mexican-president-lauds-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:04:59+00:00
 - user: None

Rep. Clay Higgins, R-La., is introducing legislation to re-fire construction of the wall at the southern border, warning that the U.S. has lost its sovereignty.

## Women's advocacy group hand-delivers demand letter to NCAA 'to keep women’s collegiate sports female'
 - [https://www.foxnews.com/sports/womens-advocacy-group-hand-delivers-demand-letter-ncaa-keep-womens-collegiate-sports-female](https://www.foxnews.com/sports/womens-advocacy-group-hand-delivers-demand-letter-ncaa-keep-womens-collegiate-sports-female)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 16:00:43+00:00
 - user: None

A demand letter was delivered to the NCAA on Thursday calling for an end to the practice of allowing male-born athletes to compete on women's teams.

## Michigan high school's reopening postponed as storm damage, asbestos repairs continue
 - [https://www.foxnews.com/us/michigan-high-school-reopening-postponed-storm-damage-asbestos-repairs-continue](https://www.foxnews.com/us/michigan-high-school-reopening-postponed-storm-damage-asbestos-repairs-continue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 15:59:58+00:00
 - user: None

Menominee High School, located on Michigan's Upper Peninsula, has been closed for repairs since August, with reopening plans being postponed.

## North Carolina Gov. Cooper returning to public stage after knee surgery
 - [https://www.foxnews.com/us/north-carolina-gov-cooper-returning-public-stage-knee-surgery](https://www.foxnews.com/us/north-carolina-gov-cooper-returning-public-stage-knee-surgery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 15:58:05+00:00
 - user: None

North Carolina Gov. Roy Cooper is returning to the public stage after partial knee replacement surgery during the holidays. Gov. Cooper will make his first appearance on Friday.

## West Virginia education board lifts emergency for county system
 - [https://www.foxnews.com/us/west-virginia-education-board-lifts-emergency-county-system](https://www.foxnews.com/us/west-virginia-education-board-lifts-emergency-county-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 15:51:28+00:00
 - user: None

The West Virginia education board has lifted an emergency declaration for Lincoln County's school system. The declaration was implemented two years ago to help with issues in the system.

## West Virginia police officer fatally shot man who attacked him with pipe
 - [https://www.foxnews.com/us/west-virginia-police-officer-fatally-shot-man-attacked-pipe](https://www.foxnews.com/us/west-virginia-police-officer-fatally-shot-man-attacked-pipe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 15:47:10+00:00
 - user: None

A West Virginia police officer fatally shot a man who attacked him with a pipe on Wednesday. The suspect was suspected of trespassing and became violent.

## Turn this Gmail security feature on ASAP
 - [https://www.foxnews.com/tech/turn-gmail-security-feature-asap](https://www.foxnews.com/tech/turn-gmail-security-feature-asap)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:58:46+00:00
 - user: None

Kurt "CyberGuy" Knutsson explains how to use your Gmail to send private encrypted emails to others so you keep your personal information secure and safe from harm.

## Don Lemon, Chuck Schumer clash over Biden classified documents story: 'For God's sake'
 - [https://www.foxnews.com/media/don-lemon-chuck-schumer-clash-bidens-mishandling-documents-story-gods-sake](https://www.foxnews.com/media/don-lemon-chuck-schumer-clash-bidens-mishandling-documents-story-gods-sake)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:58:37+00:00
 - user: None

CNN's Don Lemon pressed Chuck Schumer Friday after the Senate Majority Leader claimed that Biden had handled the situation surrounding the documents "correctly."

## Russia again claims victory over Ukrainian city Soledar, in possible rare victory
 - [https://www.foxnews.com/world/russia-again-claims-victory-ukrainian-city-soledar-possible-rare-victory](https://www.foxnews.com/world/russia-again-claims-victory-ukrainian-city-soledar-possible-rare-victory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:57:48+00:00
 - user: None

Russia on Friday once again claimed victory over Soledar in Ukraine's Donetsk region, where heavy fighting has raged, though Ukraine has not conceded the battleground.

## Idaho murders suspect Bryan Kohberger trades intensity for fear in 2nd court appearance: body language expert
 - [https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohberger-trades-intensity-2nd-court-appearance-body-language-expert](https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohberger-trades-intensity-2nd-court-appearance-body-language-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:56:57+00:00
 - user: None

University of Idaho quadruple stabbing suspect Bryan Kohberger's body language in court analyzed by expert on mannerisms and deception Susan Constantine.

## Germany plans to drop mask mandate on long-distance trains, buses
 - [https://www.foxnews.com/world/germany-plans-drop-mask-mandate-long-distance-trains-buses](https://www.foxnews.com/world/germany-plans-drop-mask-mandate-long-distance-trains-buses)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:51:44+00:00
 - user: None

Germany's Health Minister Karl Lauterbach announced that the mask mandate on long-distance planes and buses will soon be dropped on Feb. 2.

## Virginia city where student shot his teacher to install metal detectors
 - [https://www.foxnews.com/us/virginia-city-where-student-shot-teacher-install-metal-detectors](https://www.foxnews.com/us/virginia-city-where-student-shot-teacher-install-metal-detectors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:37:47+00:00
 - user: None

A city in Virginia where a 6-year-old student shot his teacher will be installing metal detectors. There was no struggle before the gun was fired at the first-grade teacher.

## Nebraska high schooler arrested, charged for gun possession
 - [https://www.foxnews.com/us/nebraska-high-schooler-arrested-charged-gun-possession](https://www.foxnews.com/us/nebraska-high-schooler-arrested-charged-gun-possession)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:35:51+00:00
 - user: None

An Omaha, Nebraska, high schooler was arrested and charged for illegally carrying a firearm. School staff were led to believe the boy was carrying after they broke up a fight.

## 3 Hungary police officers stabbed in Budapest, 1 killed
 - [https://www.foxnews.com/world/3-hungary-police-officers-stabbed-budapest-1-killed](https://www.foxnews.com/world/3-hungary-police-officers-stabbed-budapest-1-killed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:31:46+00:00
 - user: None

A stabbing in Budapest, Hungary, killed a police officer and injured two others. The man who stabbed the officers was shot in the leg by police.

## Missing Massachusetts mother Ana Walshe’s husband is a ‘sociopath,’ ‘has no insanity defense’, experts say
 - [https://www.foxnews.com/us/missing-massachusetts-mother-ana-walshes-husband-sociopath-has-no-insanity-defense-experts-say](https://www.foxnews.com/us/missing-massachusetts-mother-ana-walshes-husband-sociopath-has-no-insanity-defense-experts-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:27:23+00:00
 - user: None

Brian Walshe, the husband of missing Massachusetts real estate executive Ana Walshe, has been called a "sociopath," but likely has no insanity defense, experts say.

## ‘Rick and Morty’ creator awaits trial on domestic violence charges against ex-girlfriend
 - [https://www.foxnews.com/entertainment/rick-morty-creator-awaits-trial-domestic-violence-charges-against-ex-girlfriend](https://www.foxnews.com/entertainment/rick-morty-creator-awaits-trial-domestic-violence-charges-against-ex-girlfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:20:43+00:00
 - user: None

"Rick and Morty" creator Justin Roiland who also provides voices for both title characters is awaiting trial on domestic violence charges against his former girlfriend.

## Shaquille O’Neal honors bet, eats frog legs after TCU's blowout loss: 'I'm a man of my word'
 - [https://www.foxnews.com/sports/shaquille-oneal-honors-bet-eats-frog-legs-tcu-blowout-loss-im-man-my-word](https://www.foxnews.com/sports/shaquille-oneal-honors-bet-eats-frog-legs-tcu-blowout-loss-im-man-my-word)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:12:49+00:00
 - user: None

Shaquille O'Neal made good on his bet to eat a frog if Georgia defeated TCU in the national championship game on Monday night.

## United Nations extends Lebanon tribunal until Dec. 31 to cease operation
 - [https://www.foxnews.com/world/united-nations-extends-lebanon-tribunal-until-dec-31-cease-operation](https://www.foxnews.com/world/united-nations-extends-lebanon-tribunal-until-dec-31-cease-operation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:12:45+00:00
 - user: None

The United Nations has extended Lebanon's mandate of the tribunal until the end of the year. This protection plan will ensure the safety and support of victims.

## 2 Kentucky organizations funded $2.3M in support of school safety, mental health
 - [https://www.foxnews.com/politics/2-kentucky-organizations-funded-2-3m-support-school-safety-mental-health](https://www.foxnews.com/politics/2-kentucky-organizations-funded-2-3m-support-school-safety-mental-health)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:10:27+00:00
 - user: None

The Department of Health and Human Services has awarded two Kentucky organizations $2.3 million to help fund school safety and support mental health.

## GOP bill blocks Biden admin from banning gas stoves: ‘Regulation run amok’
 - [https://www.foxnews.com/politics/gop-bill-blocks-biden-admin-from-banning-gas-stoves-regulation-run-amok](https://www.foxnews.com/politics/gop-bill-blocks-biden-admin-from-banning-gas-stoves-regulation-run-amok)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:10:22+00:00
 - user: None

Dozens of House Republicans introduced legislation this week to block the Biden administration from banning gas stoves, after a consumer protection agency hinted one might be coming.

## Indiana man pleads guilty to car dealer's stabbing, but maintains mental illness defense
 - [https://www.foxnews.com/us/indiana-man-pleads-guilty-car-dealers-stabbing-maintains-mental-illness-defense](https://www.foxnews.com/us/indiana-man-pleads-guilty-car-dealers-stabbing-maintains-mental-illness-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 14:08:10+00:00
 - user: None

Samuel Byfield, 33, of Northern Indiana, has pleaded guilty to the February murder of used car dealer Wayne Bontrager, 73. Byfield, however, maintains mental illness as a defense.

## Migrant entry numbers into Europe hit six-year high
 - [https://www.foxnews.com/world/migrant-entry-numbers-into-europe-hit-six-year-high](https://www.foxnews.com/world/migrant-entry-numbers-into-europe-hit-six-year-high)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:32:41+00:00
 - user: None

The EU agency Frontex recently released their 2022 immigration figures - the number of attempts by migrants into the EU without authorization reached around 330,000 last year.

## Biden's classified documents timeline a 'cover-up' that 'stinks to high heaven': Mark Levin
 - [https://www.foxnews.com/media/biden-classified-documents-timeline-cover-up-stinks-high-heaven-mark-levin](https://www.foxnews.com/media/biden-classified-documents-timeline-cover-up-stinks-high-heaven-mark-levin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:30:38+00:00
 - user: None

Radio host Mark Levin sounded off Thursday on 'Hannity' regarding the timeline of events from President Biden's ongoing classified documents situation.

## Former first-round pick to work out for Lakers two years after anti-Semitic slur suspension: report
 - [https://www.foxnews.com/sports/former-first-round-pick-work-out-lakers-two-years-anti-semitic-slur-suspension-report](https://www.foxnews.com/sports/former-first-round-pick-work-out-lakers-two-years-anti-semitic-slur-suspension-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:29:07+00:00
 - user: None

Meyers Leonard has not played an NBA game in over two years, and was suspended after using an antisemitic slur, but he will reportedly work out for the Lakers on Friday.

## After a deadly severe weather outbreak in South, calmer skies move in
 - [https://www.foxnews.com/us/after-deadly-severe-weather-outbreak-south-calmer-skies](https://www.foxnews.com/us/after-deadly-severe-weather-outbreak-south-calmer-skies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:28:08+00:00
 - user: None

Snow and freezing rain are lingering Friday across sections of the Midwest and Northeast, as the West braces for more severe weather and flooding hazards.

## Florida homeowners forced to clean up ‘boat from Cuba’ that migrants abandoned on their property
 - [https://www.foxnews.com/media/florida-homeowners-forced-clean-boat-from-cuba-migrants-abandoned-their-property](https://www.foxnews.com/media/florida-homeowners-forced-clean-boat-from-cuba-migrants-abandoned-their-property)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:09:00+00:00
 - user: None

A local Florida news station interviewed a husband and wife who said they were forced to pay to have a migrant boat removed from their property, or risk a felony.

## Harry Potter 'book artist' who removes J.K. Rowling's name is within his rights: legal experts
 - [https://www.foxnews.com/lifestyle/harry-potter-book-artist-removes-j-k-rowlings-name-within-rights-legal-experts](https://www.foxnews.com/lifestyle/harry-potter-book-artist-removes-j-k-rowlings-name-within-rights-legal-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:06:02+00:00
 - user: None

An individual in Toronto, Canada, says he will remove J.K. Rowling's name from "Harry Potter" books and "re-bind" them for a fee — legal experts weighed in on the "artistic" activity.

## Progressive climate activists finally realize protests and stunts don’t work. We told you so
 - [https://www.foxnews.com/opinion/progressive-climate-activists-are-rethinking-divisive-protests-we-always-knew-was-wrong-approach](https://www.foxnews.com/opinion/progressive-climate-activists-are-rethinking-divisive-protests-we-always-knew-was-wrong-approach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:00:48+00:00
 - user: None

Progressive climate activists Extinction Rebellion realize protests and stunts don’t work. They should follow our bipartisan approach to climate solutions.

## Animal sacrifice 'should be a thing of the past': PETA spokesperson criticizes Michigan city's ruling
 - [https://www.foxnews.com/media/animal-sacrifice-should-be-thing-past-peta-spokesperson-criticizes-michigan-citys-ruling](https://www.foxnews.com/media/animal-sacrifice-should-be-thing-past-peta-spokesperson-criticizes-michigan-citys-ruling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 13:00:04+00:00
 - user: None

PETA spokesperson Ashley Byrne discusses the Hamtramck, Michigan, ruling allowing at-home animal sacrifice and how it, despite it's legality, is morally wrong on "Jesse Watters Primetime."

## Revolutionary: Mazda brings back the rotary engine ... in an electric car?
 - [https://www.foxnews.com/auto/revolutionary-mazda-rotary-engine-electric-car](https://www.foxnews.com/auto/revolutionary-mazda-rotary-engine-electric-car)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 12:41:28+00:00
 - user: None

The Mazda MX-30 R-EV is the first plug-in hybrid to use a rotary engine as a range-extender that can provide electricity after the battery is drained.

## Biden dragged for insisting classified docs were stored securely next to Corvette: 'Most Biden thing ever'
 - [https://www.foxnews.com/media/biden-dragged-insisting-classified-docs-stored-securely-corvette-biden](https://www.foxnews.com/media/biden-dragged-insisting-classified-docs-stored-securely-corvette-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 12:00:26+00:00
 - user: None

Twitter users went after President Joe Biden for insisting the classified documents discovered in his garage were safely stored alongside his Corvette.

## Reporter feuding with Karine Jean-Pierre says White House 'doesn't want tough questions'
 - [https://www.foxnews.com/media/reporter-feuding-karine-jean-pierre-white-house-doesnt-want-tough-questions](https://www.foxnews.com/media/reporter-feuding-karine-jean-pierre-white-house-doesnt-want-tough-questions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 11:30:08+00:00
 - user: None

Simon Ateba, a reporter for Today News Africa, explains why White House press secretary Karine Jean-Pierre won't meet with him until 2024 on 'Tucker Carlson Tonight.'

## Lisa Marie Presley dead at 54, Dems scramble to defend Biden in classified docs scandal and more top headlines
 - [https://www.foxnews.com/us/lisa-marie-presley-dead-at-54](https://www.foxnews.com/us/lisa-marie-presley-dead-at-54)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 11:17:49+00:00
 - user: None

Fox News First brings you Fox News' top headlines every morning.

## Lisa Marie Presley made final public outing at 80th Golden Globes, applauding Austin Butler for 'Elvis' award
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-final-public-outing-80th-golden-globe-applauding-austin-butler-elvis-award](https://www.foxnews.com/entertainment/lisa-marie-presley-final-public-outing-80th-golden-globe-applauding-austin-butler-elvis-award)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 11:17:22+00:00
 - user: None

Lisa Marie Presley, who died Thursday, made her final public outing at the 80th Golden Globes Tuesday night at The Beverly Hilton, where she was seen clapping and smiling.

## New Jersey wants to be the state of disinformation and indoctrinate its students
 - [https://www.foxnews.com/opinion/new-jersey-wants-state-disinformation-indoctrinate-its-students](https://www.foxnews.com/opinion/new-jersey-wants-state-disinformation-indoctrinate-its-students)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 11:00:50+00:00
 - user: None

In New Jersey students in grades K-12 are doing to be taught about 'media literacy' and how to identify misinformation. Here's an imaginary look at how this might actually work...

## Lori Lightfoot torpedoed over re-election campaign: 'Worst mayor in America, worst mayor Chicago has ever had'
 - [https://www.foxnews.com/media/lori-lightfoot-torpedoed-re-election-campaign-worst-mayor-america-worst-mayor-chicago-has-ever-had](https://www.foxnews.com/media/lori-lightfoot-torpedoed-re-election-campaign-worst-mayor-america-worst-mayor-chicago-has-ever-had)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 11:00:04+00:00
 - user: None

'The Five' co-hosts break down Chicago Mayor Lori Lightfoot's decision to seek re-election and reports her campaign reportedly asked schools to offer extra credit to students who help volunteer for her campaign.

## AOC fires back at ‘Republican meltdown’ over gas stoves: ‘There is very concerning science’
 - [https://www.foxnews.com/media/aoc-fires-back-republican-meltdown-gas-stoves-there-very-concerning-science](https://www.foxnews.com/media/aoc-fires-back-republican-meltdown-gas-stoves-there-very-concerning-science)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 10:39:29+00:00
 - user: None

New York Congresswoman and green activist Alexandria Ocasio-Cortez issued another salvo in the heated gas stove debate in a video posted to Instagram Thursday.

## CBS anchors call out Karine Jean-Pierre’s transparency on Biden docs: 'She has not answered a single question'
 - [https://www.foxnews.com/media/cbs-anchors-call-karine-jean-pierres-transparency-biden-docs-answered-single-question](https://www.foxnews.com/media/cbs-anchors-call-karine-jean-pierres-transparency-biden-docs-answered-single-question)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 10:00:11+00:00
 - user: None

Two anchors on the CBS News Streaming Network criticized White House spokeswoman Karine Jean-Pierre, hitting her lack of transparency about the classified documents.

## Lisa Marie Presley's life growing up with Elvis and Priscilla in her own words
 - [https://www.foxnews.com/entertainment/lisa-marie-presleys-life-growing-up-elvis-priscilla-her-own-words](https://www.foxnews.com/entertainment/lisa-marie-presleys-life-growing-up-elvis-priscilla-her-own-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 09:58:01+00:00
 - user: None

Lisa Marie Presley, the only child of Elvis Presley and Priscilla Presley, shared what it was like to grow up with the King of Rock 'n Roll as her father.

## Former Major League Baseball outfielder and coach Lee Tinsley dead at 53
 - [https://www.foxnews.com/sports/former-major-league-baseball-outfielder-coach-lee-tinsley-dead-53](https://www.foxnews.com/sports/former-major-league-baseball-outfielder-coach-lee-tinsley-dead-53)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 09:47:21+00:00
 - user: None

Lee Tinsley, 53, a former Major League Baseball outfielder and coach, passed away in Scottsdale, Arizona, on Thursday at the age of 53. He is survived by his three children.

## Debt ceiling vote could save America if House Republicans are willing to stand up to Democrats
 - [https://www.foxnews.com/opinion/house-republicans-right-no-debt-limit-increase-until-balanced-budget-plan-is-in-place](https://www.foxnews.com/opinion/house-republicans-right-no-debt-limit-increase-until-balanced-budget-plan-is-in-place)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 09:00:01+00:00
 - user: None

Debt ceiling vote could save America if House Republicans will stand up to Democrats, especially after US government took in nearly $5 trillion in 2022.

## Tornado damage: 5-year-old confirmed dead in Georgia as severe weather threatens the Southeast
 - [https://www.foxnews.com/us/tornado-damage-5-year-old-confirmed-dead-georgia-severe-weather-threatens-southeast](https://www.foxnews.com/us/tornado-damage-5-year-old-confirmed-dead-georgia-severe-weather-threatens-southeast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:43:05+00:00
 - user: None

A five-year-old child is confirmed dead in Georgia, following a severe tornado that ripped through the state and left hundreds of thousands of people without power.

## Shinzo Abe assassination: Suspect charged with murder in fatal shooting of Japan's former prime minister
 - [https://www.foxnews.com/world/shinzo-abe-assassination-suspect-charged-murder-fatal-shooting-japans-former-prime-minister](https://www.foxnews.com/world/shinzo-abe-assassination-suspect-charged-murder-fatal-shooting-japans-former-prime-minister)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:32:23+00:00
 - user: None

The man accused of shooting and killing Japan's former Prime Minister Shinzo Abe was charged with murder. Tetsuya Yamagami allegedly admitted to police that he killed Abe.

## Supermodel Tatjana Patitz dead at 56: Cindy Crawford, Naomi Campbell and other '90s supermodels then and now
 - [https://www.foxnews.com/entertainment/supermodel-tatjana-patitz-dead-56-where-iconic-90s-supermodels-now](https://www.foxnews.com/entertainment/supermodel-tatjana-patitz-dead-56-where-iconic-90s-supermodels-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:56+00:00
 - user: None

In the wake of Tatjana Patitz's death, Fox News Digital looks back at other iconic supermodels from the '90s and where they are now.

## Democrats scramble to defend Biden's handling of classified materials, point fingers at Trump
 - [https://www.foxnews.com/politics/democrats-scramble-defend-bidens-handling-classified-materials-point-fingers-trump](https://www.foxnews.com/politics/democrats-scramble-defend-bidens-handling-classified-materials-point-fingers-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:45+00:00
 - user: None

Democrats hare rushing to defend President Biden over his handling of classified documents, highlighting “differences” between how he and Trump handled classified materials.

## Meet the American who invented Band-Aids: cotton buyer and devoted husband Earle Dickson
 - [https://www.foxnews.com/lifestyle/meet-american-who-invented-band-aids-cotton-buyer-devoted-husband-earle-dickson](https://www.foxnews.com/lifestyle/meet-american-who-invented-band-aids-cotton-buyer-devoted-husband-earle-dickson)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:43+00:00
 - user: None

Earle Dickson invented the Band-Aid in 1921. A cotton buyer for Johnson & Johnson, he was inspired to create the new product to treat's wife household wounds.

## Abortion survivors call out opposition to Born-Alive bill on Capitol Hill: ‘This is infanticide’
 - [https://www.foxnews.com/media/abortion-survivors-call-out-opposition-born-alive-bill-capitol-hill-infanticide](https://www.foxnews.com/media/abortion-survivors-call-out-opposition-born-alive-bill-capitol-hill-infanticide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:18+00:00
 - user: None

Abortion survivors celebrated the House passage of the Born-Alive Abortion Survivors Protection Act on Capitol Hill, while Democrats called the bill "extreme."

## I helped sue to protect women's sports in West Virginia, and we won
 - [https://www.foxnews.com/opinion/i-helped-sue-protect-womens-sports-west-virginia-we-won](https://www.foxnews.com/opinion/i-helped-sue-protect-womens-sports-west-virginia-we-won)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:16+00:00
 - user: None

I helped sue to protect women's sports in West Virginia, and we won because federal court upheld the Save Women’s Sports Act and using Title IX as intended.

## Democrats push to amend Constitution so 16-year-olds can vote
 - [https://www.foxnews.com/politics/democrats-push-amend-constitution-16-year-olds-vote](https://www.foxnews.com/politics/democrats-push-amend-constitution-16-year-olds-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 07:00:05+00:00
 - user: None

House Democrats will try once more to amend the Constitution in order to lower the voting age to 16, an idea that has been popular with Democrats but unpopular with Republicans.

## WATCH: Lisa Marie Presley shared remarks at Elvis Presley's 88th birthday at Graceland days before her death
 - [https://www.foxnews.com/entertainment/watch-lisa-marie-presley-shared-remarks-elvis-pressleys-88th-birthday-graceland-her-death](https://www.foxnews.com/entertainment/watch-lisa-marie-presley-shared-remarks-elvis-pressleys-88th-birthday-graceland-her-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 06:03:58+00:00
 - user: None

Lisa Marie Presley, the only child of icon Elvis Presley and Priscilla Presley, shared remarks at Elvis's 88th birthday at Graceland days before her own death.

## WATCH: Lisa Marie Presley shared remarks at Elvis Presley's 88th birthday at Graceland days before her death
 - [https://www.foxnews.com/entertainment/watch-lisa-marie-presley-shared-remarks-elvis-presleys-88th-birthday-graceland-her-death](https://www.foxnews.com/entertainment/watch-lisa-marie-presley-shared-remarks-elvis-presleys-88th-birthday-graceland-her-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 06:03:58+00:00
 - user: None

Lisa Marie Presley, the only child of icon Elvis Presley and Priscilla Presley, shared remarks at Elvis's 88th birthday at Graceland days before her own death.

## Squad member Ayanna Pressley opposes committee on China for fear of racism: 'Embolden anti-Asian rhetoric'
 - [https://www.foxnews.com/media/squad-member-ayanna-pressley-opposes-committee-china-fear-racism-embolden-anti-asian-rhetoric](https://www.foxnews.com/media/squad-member-ayanna-pressley-opposes-committee-china-fear-racism-embolden-anti-asian-rhetoric)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 05:30:01+00:00
 - user: None

Rep. Ayanna Pressley told CNN she voted against the formation of a House committee on China because she is worried it could contribute to a rise in anti-Asian rhetoric.

## Giants players recall infamous 'boat picture' ahead of long-awaited return to NFL playoffs
 - [https://www.foxnews.com/sports/giants-players-recall-infamous-boat-trip-photo-ahead-long-awaited-return-nfl-playoffs](https://www.foxnews.com/sports/giants-players-recall-infamous-boat-trip-photo-ahead-long-awaited-return-nfl-playoffs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 05:11:57+00:00
 - user: None

Victor Cruz, Odell Beckham Jr. and other Giants players flew to Florida ahead of a January 2017 playoff game and posted a shirtless photo aboard a yacht with celebrities.

## Lisa Marie Presley remembered: Tom Hanks, Rita Wilson and John Travolta mourn death of Elvis' daughter
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-remembered-tom-hanks-rita-wilson-john-travolta-mourn-death-elvis-daughter](https://www.foxnews.com/entertainment/lisa-marie-presley-remembered-tom-hanks-rita-wilson-john-travolta-mourn-death-elvis-daughter)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 05:11:23+00:00
 - user: None

Lisa Marie Presley remembered by John Travolta, Leah Remini and Tom Hanks. The daughter of rock royalty Elvis and Priscilla Presley is survived by three children.

## GREG GUTFELD: We're talking large breasts here
 - [https://www.foxnews.com/opinion/greg-gutfeld-were-talking-large-breasts-here](https://www.foxnews.com/opinion/greg-gutfeld-were-talking-large-breasts-here)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 05:10:43+00:00
 - user: None

Fox News host Greg Gutfeld provides updates on the Candian teacher who wears oversized prosthetic breasts on 'Gutfeld!'

## On this day in history, Jan. 13, 1968, Johnny Cash performs live at Folsom Prison with all-star band
 - [https://www.foxnews.com/lifestyle/this-day-history-jan-13-1968-johnny-cash-performs-live-folsom-prison-band](https://www.foxnews.com/lifestyle/this-day-history-jan-13-1968-johnny-cash-performs-live-folsom-prison-band)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 05:02:26+00:00
 - user: None

Johnny Cash performed live at California State Prison at Folsom on this day in history, Jan. 13, 1968. The performance featured an all-star band including June Carter Cash and Carl Perkins.

## LAURA INGRAHAM: The American media ignored the longstanding corruption of Biden, Inc
 - [https://www.foxnews.com/media/laura-ingraham-american-media-ignored-longstanding-corruption-biden-inc](https://www.foxnews.com/media/laura-ingraham-american-media-ignored-longstanding-corruption-biden-inc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 04:32:24+00:00
 - user: None

Laura Ingraham slams the media for trying to cover for the Biden administration by pivoting from the classified documents scandal on "The Ingraham Angle."

## Lisa Marie Presley's life in pictures
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-life-in-pictures](https://www.foxnews.com/entertainment/lisa-marie-presley-life-in-pictures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 04:00:40+00:00
 - user: None

Lisa Marie Presley has died at 54. Here is a look at the only child of Elvis and Priscilla Presley's life in pictures.

## NFL Hall of Famer Brian Urlacher sues hair transplant company for using likeness without permission
 - [https://www.foxnews.com/sports/nfl-hall-of-famer-brian-urlacher-sues-hair-transplant-company-using-likeness-without-permission](https://www.foxnews.com/sports/nfl-hall-of-famer-brian-urlacher-sues-hair-transplant-company-using-likeness-without-permission)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:36:54+00:00
 - user: None

NFL Hall of Famer Brian Urlacher filed a lawsuit against a Houston-based hair transplant company that allegedly used his likeness without his permission.

## TUCKER CARLSON: This is the beginning of the end for Biden
 - [https://www.foxnews.com/opinion/tucker-carlson-beginning-end-biden](https://www.foxnews.com/opinion/tucker-carlson-beginning-end-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:33:53+00:00
 - user: None

Fox News host Tucker Carlson calls out President Biden's alleged mishandling of documents and weighs in on how Democrats are reacting on "Tucker Carlson Tonight."

## Biden can't keep classified docs in that garage, ex-White House ethics lawyer says: 'This is a dumpster fire'
 - [https://www.foxnews.com/media/biden-cant-keep-classified-docs-garage-ex-white-house-ethics-lawyer-dumpster-fire](https://www.foxnews.com/media/biden-cant-keep-classified-docs-garage-ex-white-house-ethics-lawyer-dumpster-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:26:47+00:00
 - user: None

Former Senate candidate Richard Painter criticizes President Biden for storing classified materials in multiple locations on 'Tucker Carlson Tonight.'

## SEAN HANNITY: If you take classified material seriously, don't stash secret documents in a garage
 - [https://www.foxnews.com/opinion/sean-hannity-take-classified-material-seriously-dont-stash-secret-documents-garage](https://www.foxnews.com/opinion/sean-hannity-take-classified-material-seriously-dont-stash-secret-documents-garage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:24:47+00:00
 - user: None

Fox News host Sean Hannity gives his take on more classified documents allegedly being found in President Biden's garage on 'Hannity.'

## Oklahoma death row inmate's last words before execution: 'My conscience is clear'
 - [https://www.foxnews.com/us/oklahoma-death-row-inmates-last-words-execution-conscience-clear](https://www.foxnews.com/us/oklahoma-death-row-inmates-last-words-execution-conscience-clear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:10:16+00:00
 - user: None

As lethal injection drugs began to flow into Scott James Eizember on Thursday morning, the double murderer said, "My conscience is clear, completely."

## Anna Kendrick says she once found year-long text exchange that proved her boyfriend had cheated
 - [https://www.foxnews.com/entertainment/anna-kendrick-once-found-year-long-text-exchange-proved-boyfriend-cheated](https://www.foxnews.com/entertainment/anna-kendrick-once-found-year-long-text-exchange-proved-boyfriend-cheated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:07:31+00:00
 - user: None

Anna Kendrick recently reflected on a past boyfriend who cheated on her, and, according to the actress, continued to deny it even after she confronted him with texts he sent to the woman.

## Lightfoot says political outreach email to teachers was a 'mistake,' blames staffer: 'Shouldn't have happened'
 - [https://www.foxnews.com/media/lightfoot-political-outreach-email-teachers-mistake-blames-staffer-shouldnt-happened](https://www.foxnews.com/media/lightfoot-political-outreach-email-teachers-mistake-blames-staffer-shouldnt-happened)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 03:00:40+00:00
 - user: None

Chicago Mayor Lori Lightfoot said the email sent to city school teachers was sent by a staffer working on her reelection campaign and was a "mistake."

## BLM founder’s cousin dies after Los Angeles police arrest
 - [https://www.foxnews.com/us/blm-founders-cousin-dies-los-angeles-police-arrest](https://www.foxnews.com/us/blm-founders-cousin-dies-los-angeles-police-arrest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:46:32+00:00
 - user: None

The cousin of Black Lives Matter co-founder Patrisse Cullors died on Jan. 3 after he was arrested by Los Angeles police officers, according to the department.

## NHL coach bans iPads from bench: 'It is a major problem'
 - [https://www.foxnews.com/sports/nhl-coach-john-tortorella-philadelphia-flyers-bans-ipad-bench-major-problem](https://www.foxnews.com/sports/nhl-coach-john-tortorella-philadelphia-flyers-bans-ipad-bench-major-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:45:23+00:00
 - user: None

John Tortorella has banned iPads from the Philadelphia Flyers' bench. He says they are a "major problem" and his players can simply "watch the game."

## Former Alabama running back Ahmaad Galloway found dead at 42: report
 - [https://www.foxnews.com/sports/former-alabama-running-back-ahmaad-galloway-found-dead-at-42-report](https://www.foxnews.com/sports/former-alabama-running-back-ahmaad-galloway-found-dead-at-42-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:44:41+00:00
 - user: None

Former Alabama Crimson Tide running back Ahmaad Galloway, who played with NFL great Shaun Alexander in college, was found dead in his apartment Monday. He was 42.

## Ana Walshe said husband was 'taught to lie' and 'told he was a loser' as a child: Court docs
 - [https://www.foxnews.com/us/ana-walshe-said-husband-was-taught-lie-told-was-loser-child-court-docs](https://www.foxnews.com/us/ana-walshe-said-husband-was-taught-lie-told-was-loser-child-court-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:43:01+00:00
 - user: None

Ana Walshe wrote in a letter to a federal judge that her husband Brian Walshe had a rough upbringing as a child and was "taught to lie."

## Florida man sentenced to life in prison after setting woman on fire in 2017
 - [https://www.foxnews.com/us/florida-man-sentenced-life-prison-setting-woman-fire](https://www.foxnews.com/us/florida-man-sentenced-life-prison-setting-woman-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:42:20+00:00
 - user: None

A jury in Volusia County, Florida convicted a man of first-degree murder and two counts of first-degree arson after he set a woman on fire in 2017.

## NBA Hall of Famer says getting stabbed 11 times was a reality check: 'Shouldn't be in the streets'
 - [https://www.foxnews.com/sports/nba-hall-of-famer-says-getting-stabbed-11-times-reality-check-shouldnt-be-in-streets](https://www.foxnews.com/sports/nba-hall-of-famer-says-getting-stabbed-11-times-reality-check-shouldnt-be-in-streets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:33:15+00:00
 - user: None

Former Boston Celtic Paul Pierce reflected on the night he was stabbed 11 times in Boston, saying the near-fatal attack "motivated me to be on the court."

## Joe Rogan puts leftist mega-donor George Soros on blast: 'He wants cities to fall apart, crime to flourish'
 - [https://www.foxnews.com/media/joe-rogan-leftist-mega-donor-george-soros-blast-wants-cities-fall-apart-crime-flourish](https://www.foxnews.com/media/joe-rogan-leftist-mega-donor-george-soros-blast-wants-cities-fall-apart-crime-flourish)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:30:23+00:00
 - user: None

Joe Rogan and a former CIA agent on Wednesday hammered George Soros with host Rogan calling out the liberal mega-donor for "funding corrosion" in politics.

## Arkansas dumping of hundreds of deer carcasses prompts investigation: reports
 - [https://www.foxnews.com/us/arkansas-dumping-of-hundreds-of-deer-carcasses-prompts-investigation-reports](https://www.foxnews.com/us/arkansas-dumping-of-hundreds-of-deer-carcasses-prompts-investigation-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:22:54+00:00
 - user: None

A landowner in Arkansas reported to the Johnson County Sheriff's Office that someone illegally dumped hundreds of deer carcasses on his property.

## Patriots announce Jerod Mayo will remain with team long term in surprise statement
 - [https://www.foxnews.com/sports/patriots-announce-jerod-mayo-remain-team-long-term-surprise-statement](https://www.foxnews.com/sports/patriots-announce-jerod-mayo-remain-team-long-term-surprise-statement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:16:08+00:00
 - user: None

It is unlike the New England Patriots to reveal their plans about anything. On Thursday, they released a statement saying Jerod Mayo will be staying with the team long term.

## White House won't say how many people could have accessed classified Biden documents in garage
 - [https://www.foxnews.com/politics/white-house-wont-say-how-many-people-could-have-accessed-classified-biden-documents-garage](https://www.foxnews.com/politics/white-house-wont-say-how-many-people-could-have-accessed-classified-biden-documents-garage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:04:42+00:00
 - user: None

The White House declined to give an estimate of the number of people who could have had access to the classified found in President Biden's Wilmington garage.

## Former Biden assistant questioned by law enforcement over classified docs repeatedly appeared in Hunter emails
 - [https://www.foxnews.com/politics/former-biden-assistant-questioned-law-enforcement-classified-docs-repeatedly-appeared-hunter-emails](https://www.foxnews.com/politics/former-biden-assistant-questioned-law-enforcement-classified-docs-repeatedly-appeared-hunter-emails)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 02:03:20+00:00
 - user: None

Kathy Chung, a former aide to President Biden who was interviewed by investigators this week, frequently emailed the president's son Hunter Biden about a range of issues.

## Divorcing your spouse: How to safely remove them from shared accounts
 - [https://www.foxnews.com/tech/divorcing-your-spouse-safely-remove-shared-accounts](https://www.foxnews.com/tech/divorcing-your-spouse-safely-remove-shared-accounts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:57:53+00:00
 - user: None

If you are currently in the midst of divorce, your tech and social media may still be intertwined. Here's how to reclaim your own digital footprint.

## Lisa Marie Presley, Elvis and Priscilla’s only child, dead at 54
 - [https://www.foxnews.com/entertainment/lisa-marie-presley-elvis-priscilla-only-child-dead-54](https://www.foxnews.com/entertainment/lisa-marie-presley-elvis-priscilla-only-child-dead-54)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:50:27+00:00
 - user: None

Lisa Marie Presley, the only child of Elvis and Priscilla Presley, was rushed to the hospital on Thursday afternoon.

## JESSE WATTERS: Everywhere Biden's aides look, they find something new that surprises Joe
 - [https://www.foxnews.com/media/jesse-watters-everywhere-bidens-aides-look-find-something-new-surprises-joe](https://www.foxnews.com/media/jesse-watters-everywhere-bidens-aides-look-find-something-new-surprises-joe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:49:20+00:00
 - user: None

Jesse Watters criticizes President Biden for keeping classified documents in his garage along with more hidden documents in other locations on "Jesse Watters Primetime."

## Biden admin dealt blow by Sixth Circuit ruling against vaccine mandate in Kentucky, Ohio, Tennessee
 - [https://www.foxnews.com/politics/biden-admin-dealt-blow-sixth-circuit-ruling-against-admins-vaccine-mandate-kentucky-ohio-tennessee](https://www.foxnews.com/politics/biden-admin-dealt-blow-sixth-circuit-ruling-against-admins-vaccine-mandate-kentucky-ohio-tennessee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:48:42+00:00
 - user: None

A federal appeals court ruled on Thursday that the Biden administration cannot enforce a mandate requiring workers who contract with the federal government to vaccinate.

## Karine Jean-Pierre dodges questions about visitor logs to Biden's Delaware home where he kept classified docs
 - [https://www.foxnews.com/politics/karine-jean-pierre-dodges-questions-visitor-logs-bidens-delaware-home-kept-classified-docs](https://www.foxnews.com/politics/karine-jean-pierre-dodges-questions-visitor-logs-bidens-delaware-home-kept-classified-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:42:03+00:00
 - user: None

Karine Jean-Pierre refused to answer a question asking if the White House will release visitor logs to President Biden's Wilmington, Delaware, residence after classified documents were found there.

## California man narrowly escapes death by falling boulder
 - [https://www.foxnews.com/us/california-man-narrowly-escapes-death-falling-boulder](https://www.foxnews.com/us/california-man-narrowly-escapes-death-falling-boulder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:37:45+00:00
 - user: None

A California is lucky to be alive after a boulder from a landslide smashed the roof of his sedan in, right where he would have been sitting had his girlfriend not called.

## Utah DPS arrests two gang members for fatal shooting in 2009 on I-15: law enforcement officials
 - [https://www.foxnews.com/us/utah-dps-arrests-gang-members-fatal-shooting-2009-law-enforcement-officials](https://www.foxnews.com/us/utah-dps-arrests-gang-members-fatal-shooting-2009-law-enforcement-officials)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:35:51+00:00
 - user: None

The Utah Department of Public Safety investigators arrested two men for allegedly shooting and killing a man on Interstate 15, 14 years ago.

## Bittersweet goodbyes: international soccer's high-profile retirements since the Qatar World Cup
 - [https://www.foxnews.com/sports/bittersweet-goodbyes-international-soccer-high-profile-retirements-since-qatar-world-cup](https://www.foxnews.com/sports/bittersweet-goodbyes-international-soccer-high-profile-retirements-since-qatar-world-cup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:32:36+00:00
 - user: None

The conclusion of a World Cup is a natural ending point for many a player's international career. Fox News takes you through some of those retirements here.

## All 30 Triple-A teams to implement electronic strike zone this season: report
 - [https://www.foxnews.com/sports/all-30-triple-a-teams-to-implement-electronic-strike-zone-this-season-report](https://www.foxnews.com/sports/all-30-triple-a-teams-to-implement-electronic-strike-zone-this-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:30:31+00:00
 - user: None

All 30 Triple-A ballparks will use an automatic balls and strikes system in some capacity in the upcoming season, according to a report from ESPN.

## UFO sightings surged over last two years, US intel report says
 - [https://www.foxnews.com/politics/ufo-sightings-surged-last-two-years-us-intel-report-says](https://www.foxnews.com/politics/ufo-sightings-surged-last-two-years-us-intel-report-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:23:37+00:00
 - user: None

The Pentagon's All-Domain Anomaly Resolution Office has gathered 366 UFO sightings over the past two years, intelligence officials wrote in a report to Congress.

## Tesla driver attacks another vehicle on California highway, video shows
 - [https://www.foxnews.com/us/tesla-driver-attacks-another-vehicle-california-highway-video-shows](https://www.foxnews.com/us/tesla-driver-attacks-another-vehicle-california-highway-video-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:17:25+00:00
 - user: None

A Los Angeles-area Tesla driver was recently caught on dashcam footage exiting his vehicle and assaulting another vehicle on California Highway 2.

## Florida Coast Guard asks for help with migrant surge moments after WH accuses DeSantis of 'political stunts’
 - [https://www.foxnews.com/politics/florida-coast-guard-asks-help-migrant-surge-moments-wh-accuses-desantis-political-stunts](https://www.foxnews.com/politics/florida-coast-guard-asks-help-migrant-surge-moments-wh-accuses-desantis-political-stunts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:11:46+00:00
 - user: None

Moments after the Biden Administration blasted Ron DeSantis' move to activate the national guard, the Republican governor shares that the U.S. Coast Guard asked for the state's assistance in dealing with the migrant surge.

## NYC man pleads guilty to beating Chinese immigrant to death
 - [https://www.foxnews.com/us/nyc-man-pleads-guilty-beating-chinese-immigrant-death](https://www.foxnews.com/us/nyc-man-pleads-guilty-beating-chinese-immigrant-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:02:33+00:00
 - user: None

A man who beat an Asian man to death in New York City pleaded guilty and will be sentenced to 22 years in prison.

## Biden's words on Trump raid come back to haunt him, just like Hillary's comments on Benghazi, critics say
 - [https://www.foxnews.com/media/bidens-words-trump-raid-come-back-haunt-him-hillarys-comments-benghazi](https://www.foxnews.com/media/bidens-words-trump-raid-come-back-haunt-him-hillarys-comments-benghazi)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 01:00:18+00:00
 - user: None

President Biden was widely derided for his 2022 comment to Scott Pelley condemning Donald Trump after the FBI raided his Mar-a-Lago estate over classified docs.

## Most 'long COVID' symptoms after mild case of virus resolve in about a year: new study
 - [https://www.foxnews.com/lifestyle/most-long-covid-symptoms-mild-case-virus-resolve-year-study](https://www.foxnews.com/lifestyle/most-long-covid-symptoms-mild-case-virus-resolve-year-study)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:46:54+00:00
 - user: None

A study out of Israel suggests most people with "long COVID" following a mild case of COVID-19 have their symptoms resolve after a year. Fox News medical contributor Dr. Marc Siegel weighed in.

## Oklahoma authorities make arrest in missing toddler Athena Brownfield's mysterious disappearance
 - [https://www.foxnews.com/us/oklahoma-authorities-make-arrest-missing-toddler-athena-brownfields-mysterious-disappearance](https://www.foxnews.com/us/oklahoma-authorities-make-arrest-missing-toddler-athena-brownfields-mysterious-disappearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:35:27+00:00
 - user: None

Oklahoma officials on Thursday arrested Alysia Adams on two counts of child neglect in connection to the Tuesday disappearance of Athena Brownfield, 4, from Cyril.

## Buccaneers QB Tom Brady looks to keep unbeaten streak against the Cowboys alive in playoff matchup
 - [https://www.foxnews.com/sports/buccaneers-qb-tom-brady-looks-to-keep-unbeaten-streak-against-the-cowboys-alive-playoff-matchup](https://www.foxnews.com/sports/buccaneers-qb-tom-brady-looks-to-keep-unbeaten-streak-against-the-cowboys-alive-playoff-matchup)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:32:17+00:00
 - user: None

Tampa Bay Buccaneers QB Tom Brady has played the Dallas Cowboys seven times during his storied 23-year NFL career and defeated them in all seven games.

## Kamala Harris mocked for repeating several word salads during climate crisis talk: 'WTF is her deal'
 - [https://www.foxnews.com/media/kamala-harris-mocked-repeating-several-word-salads-during-climate-crisis-talk-wtf-deal](https://www.foxnews.com/media/kamala-harris-mocked-repeating-several-word-salads-during-climate-crisis-talk-wtf-deal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:30:39+00:00
 - user: None

Vice President Kamala Harris was mocked for making a series of familiar nonsensical comments during her latest public appearance in Michigan on Thursday.

## Chicago bookstore owner's tweet about customer's $800 return goes viral: 'Don’t do this to a small business'
 - [https://www.foxnews.com/lifestyle/chicago-bookstore-owners-tweet-customers-800-return-goes-viral-dont-do-this-to-a-small-business](https://www.foxnews.com/lifestyle/chicago-bookstore-owners-tweet-customers-800-return-goes-viral-dont-do-this-to-a-small-business)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:30:28+00:00
 - user: None

A Chicago bookstore owner's Twitter post about an "expensive" return has gone viral after she vents about a customer returning $800 worth of books that was used as temporary decor.

## Mother of Houston taqueria robbery suspect killed by customer says son promised to do better
 - [https://www.foxnews.com/us/mother-houston-taqueria-robbery-suspect-killed-customer-son-promised-better](https://www.foxnews.com/us/mother-houston-taqueria-robbery-suspect-killed-customer-son-promised-better)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:27:51+00:00
 - user: None

The mother of an armed robbery suspect who was shot and killed by an armed customer at a Houston, Texas taqueria said her son promised he would do better, on morning of incident.

## Texas border officials arrest 14 illegal immigrants, including suspected smuggler, after high-speed chase
 - [https://www.foxnews.com/us/texas-border-officials-arrest-14-illegal-immigrants-including-suspected-smuggler-high-speed-chase](https://www.foxnews.com/us/texas-border-officials-arrest-14-illegal-immigrants-including-suspected-smuggler-high-speed-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:22:31+00:00
 - user: None

Texas and border authorities arrested 14 illegal immigrants Wednesday after a high-speed chase, officials said.

## 'General Hospital' will honor Sonya Eddy with special tribute episode three months after her death
 - [https://www.foxnews.com/entertainment/general-hospital-honor-sonya-eddy-special-tribute-episode-three-months-after-death](https://www.foxnews.com/entertainment/general-hospital-honor-sonya-eddy-special-tribute-episode-three-months-after-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:15:28+00:00
 - user: None

Following Sonya Eddy's death in December and amid episodes marking its 60 years on the air, "General Hospital" will film a tribute episode to the late star this spring.

## Tori Spelling says ‘hits just keep coming’ as she reveals 14-year-old daughter Stella is in hospital
 - [https://www.foxnews.com/entertainment/tori-spelling-14-year-old-daughter-stella-hospital](https://www.foxnews.com/entertainment/tori-spelling-14-year-old-daughter-stella-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:15:12+00:00
 - user: None

Tori Spelling said her daughter, Stella, was in the hospital on Wednesday night. The "90210" star posted a photo on her Instagram Stories showing her 14-year-old in a hospital bed.

## Biden's classified documents scandal was swept under the rug: GOP rep
 - [https://www.foxnews.com/media/rep-michael-mccaul-bidens-classified-documents-scandal-swept-under-rug](https://www.foxnews.com/media/rep-michael-mccaul-bidens-classified-documents-scandal-swept-under-rug)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:09:59+00:00
 - user: None

Texas Republican Rep. Michael McCaul calls out President Biden's alleged mishandling of classified documents on “Special Report.”

## Enes Kanter Freedom reveals Turkish government put $500K bounty on his head, may sue NBA
 - [https://www.foxnews.com/sports/enes-kanter-freedom-reveals-turkish-government-500k-bounty-on-his-head](https://www.foxnews.com/sports/enes-kanter-freedom-reveals-turkish-government-500k-bounty-on-his-head)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-13 00:02:52+00:00
 - user: None

Enes Kanter Freedom, the ex-NBA center, revealed that the Turkish government, of which he has been outspoken about during his time in the league, put a bounty on his head.
