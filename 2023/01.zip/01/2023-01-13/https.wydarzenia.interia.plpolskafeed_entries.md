# Source Wydarzenia Interia - Polska, Source URL:https://wydarzenia.interia.pl/polska/feed, Source language: pl-PL

## Tusk w Gdańsku: Nie będę tego pokornie znosił, nie nastawię drugiego policzka
 - [https://wydarzenia.interia.pl/kraj/news-tusk-w-gdansku-nie-bede-tego-pokornie-znosil-nie-nastawie-dr,nId,6532641](https://wydarzenia.interia.pl/kraj/news-tusk-w-gdansku-nie-bede-tego-pokornie-znosil-nie-nastawie-dr,nId,6532641)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-01-13 16:55:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-tusk-w-gdansku-nie-bede-tego-pokornie-znosil-nie-nastawie-dr,nId,6532641"><img align="left" alt="Tusk w Gdańsku: Nie będę tego pokornie znosił, nie nastawię drugiego policzka" src="https://i.iplsc.com/tusk-w-gdansku-nie-bede-tego-pokornie-znosil-nie-nastawie-dr/000GM833R0QQIDCK-C321.jpg" /></a>Podjęliśmy decyzję, by zagłosować za ustawą o SN, bo mieliśmy świadomość, że ta propozycja może odblokować środki europejskie. Nazywając rzecz po imieniu, głosowaliśmy za ustawą, która jest zła i być może niekonstytucyjna, ale obiektywnie lepsza niż status quo, ziobrowe status quo, pogwałcenie systemu sprawiedliwości w Polsce - stwierdził Donald Tusk w Gdańsku, podczas spotkania z młodzieżą. Mówiąc o poziomie debaty publicznej, podkreślił, że &quot;opozycja już nie może pozwalać, ale musi oddawać&quot;. - Nie odpuszczę nogi, nie będę tego pokornie...</p><br clear="all" />

## Trafiła do PKN Orlen. Kim jest Janina Goss?
 - [https://wydarzenia.interia.pl/kraj/news-trafila-do-pkn-orlen-kim-jest-janina-goss,nId,6532120](https://wydarzenia.interia.pl/kraj/news-trafila-do-pkn-orlen-kim-jest-janina-goss,nId,6532120)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-01-13 14:56:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-trafila-do-pkn-orlen-kim-jest-janina-goss,nId,6532120"><img align="left" alt="Trafiła do PKN Orlen. Kim jest Janina Goss? " src="https://i.iplsc.com/trafila-do-pkn-orlen-kim-jest-janina-goss/000GM55FXMBRTX8D-C321.jpg" /></a>Janina Goss to polska radczyni prawna, o której głośno zrobiło się za sprawą nominacji do rady nadzorczej PKN Orlen. Związana z Prawem i Sprawiedliwością jest jednocześnie jedną z najbardziej zaufanych współpracownic Jarosława Kaczyńskiego. Kim jest Janina Goss?</p><br clear="all" />
