# Source Epoch times world, Source URL:https://www.theepochtimes.com/c-world/feed/, Source language: en-US

## Japan, Canada Leaders Discuss Bilateral Trade, Economy, and China
 - [https://www.theepochtimes.com/japan-canada-leaders-discuss-bilateral-trade-economy-and-china_4982171.html](https://www.theepochtimes.com/japan-canada-leaders-discuss-bilateral-trade-economy-and-china_4982171.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 23:50:09+00:00
 - user: None

Canada's Prime Minister Justin Trudeau speaks during his meeting with Japan's Prime Minister Fumio Kishida in Ottawa, Ontario, Canada, on Jan. 12, 2023. (Blair Gable/Reuters)

## Bettong Baby Joy in Australian State Wilderness
 - [https://www.theepochtimes.com/bettong-baby-joy-in-australian-state-wilderness_4984357.html](https://www.theepochtimes.com/bettong-baby-joy-in-australian-state-wilderness_4984357.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 23:39:37+00:00
 - user: None

A supplied image obtained Jan. 13, 2023 shows a bettong in the Pilliga State Conservation Area, Pilliga, NSW. (AAP Image/Supplied by NSW Department of Planning and Environment)

## Weather Alerts of Heavy Snowfall, Freezing Rain Issued for Regions From Coast to Coast
 - [https://www.theepochtimes.com/weather-alerts-of-heavy-snowfall-freezing-rain-issued-for-regions-from-coast-to-coast_4984238.html](https://www.theepochtimes.com/weather-alerts-of-heavy-snowfall-freezing-rain-issued-for-regions-from-coast-to-coast_4984238.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 23:34:24+00:00
 - user: None

A person makes their way through the Glebe neighbourhood of Ottawa, on Dec. 24, 2022. (Spencer Colby/The Canadian Press)

## Russia Says It Took Soledar, Ukraine Denies Its Capture
 - [https://www.theepochtimes.com/russia-says-it-took-soledar-ukraine-denies-its-capture_4983136.html](https://www.theepochtimes.com/russia-says-it-took-soledar-ukraine-denies-its-capture_4983136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 23:22:24+00:00
 - user: None

Ukrainian army Grad multiple rocket launcher fires rockets at Russian positions in the frontline near Soledar, Donetsk region, Ukraine, on Jan. 11, 2023. (Libkos/AP Photo)

## Suspect in Japan’s Former PM Shinzo Abe’s Assassination Charged With Murder
 - [https://www.theepochtimes.com/suspect-in-japans-former-pm-shinzo-abes-assassination-charged-with-murder_4982898.html](https://www.theepochtimes.com/suspect-in-japans-former-pm-shinzo-abes-assassination-charged-with-murder_4982898.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 23:15:25+00:00
 - user: None

Japan's Prime Minister Shinzo Abe speaks to media after the summit between the United States and North Korea in Singapore, at Abe's official residence in Tokyo, Japan, on June 12, 2018. (Issei Kato/Reuters)

## US and Japan Sign Historic Defense Agreements, Extend Mutual Aid to Space
 - [https://www.theepochtimes.com/us-and-japan-sign-historic-defense-agreements-extend-mutual-aid-to-space_4984528.html](https://www.theepochtimes.com/us-and-japan-sign-historic-defense-agreements-extend-mutual-aid-to-space_4984528.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 22:46:39+00:00
 - user: None

U.S. President Joe Biden shakes hands with Japan's Prime Minister Fumio Kishida during a meeting in the Oval Office of the White House in Washington on Jan. 13, 2023. (Mandel Ngan/AFP via Getty Images)

## Tory MP Requested Feds Identify All ‘Misinformation’ Released Since 2016
 - [https://www.theepochtimes.com/tory-mp-requested-feds-identify-all-misinformation-released-since-2016_4984307.html](https://www.theepochtimes.com/tory-mp-requested-feds-identify-all-misinformation-released-since-2016_4984307.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 21:36:57+00:00
 - user: None

Chris Warkentin waits to begin a session of the House of Commons Access to Information, Privacy and Ethics committee on Parliament hill in Ottawa, July 12, 2021. (Adrian Wyld/The Canadian Press)

## Robbie Bachman of Bachman-Turner Overdrive Dies at 69
 - [https://www.theepochtimes.com/robbie-bachman-of-bachman-turner-overdrive-dies-at-69_4984136.html](https://www.theepochtimes.com/robbie-bachman-of-bachman-turner-overdrive-dies-at-69_4984136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 21:20:43+00:00
 - user: None

Randy Bachman (R) holds the Juno as Robbie Bachman videotapes a closeup of the trophy after being inducted into the Canadian Music Hall of Fame at the Juno Awards in Winnipeg on March 30, 2014. (John Woods/The Canadian Press via AP)

## Gun Fired Inside Washroom During Altercation at Toronto High School, Police Say
 - [https://www.theepochtimes.com/gun-fired-inside-washroom-during-altercation-at-toronto-high-school-police-say_4984043.html](https://www.theepochtimes.com/gun-fired-inside-washroom-during-altercation-at-toronto-high-school-police-say_4984043.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 20:48:40+00:00
 - user: None

A Toronto Police Services logo is shown at headquarters, in Toronto on Aug. 9, 2019. (The Canadian Press/Christopher Katsarov)

## Northern Queensland Braces for Flood as Rain Sets In
 - [https://www.theepochtimes.com/northern-queensland-braces-for-flood-as-rain-sets-in_4982620.html](https://www.theepochtimes.com/northern-queensland-braces-for-flood-as-rain-sets-in_4982620.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 20:41:55+00:00
 - user: None

North Queensland experienced extreme rainfall and floods earlier this year. (Torsten Blackwood/AFP/Getty Images)

## LIVE 4:30 PM ET: Japanese Prime Minister Fumio Kishida Visits NASA HQ
 - [https://www.theepochtimes.com/japanese-prime-minister-fumio-kishida-visits-nasa-hq_4983958.html](https://www.theepochtimes.com/japanese-prime-minister-fumio-kishida-visits-nasa-hq_4983958.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 20:37:02+00:00
 - user: None

Japan's Prime Minister Fumio Kishida addresses a press conference next to German Chancellor Olaf Scholz and U.S. President Joe Biden during the G-7 Summit at Elmau Castle, southern Germany, on June 26, 2022. (Jonathan Ernst/ AFP via Getty Images)

## LME’s Plan to Restart Asian Trading Halted Amid Nickel Chaos
 - [https://www.theepochtimes.com/lmes-plan-to-restart-asian-trading-halted-amid-nickel-chaos_4983698.html](https://www.theepochtimes.com/lmes-plan-to-restart-asian-trading-halted-amid-nickel-chaos_4983698.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 20:15:32+00:00
 - user: None

A sign for the London Metal Exchange (LME) on a wall by the new Ring, the open trading floor of the LME following its relocation in central London on Feb. 18, 2016. (Leon Neal/AFP via Getty Images)

## Police Offer $100,000 Reward for Whereabouts of Abducted Ontario Woman Elnaz Hajtamiri
 - [https://www.theepochtimes.com/police-offer-100000-reward-for-whereabouts-of-abducted-ontario-woman-elnaz-hajtamiri_4983550.html](https://www.theepochtimes.com/police-offer-100000-reward-for-whereabouts-of-abducted-ontario-woman-elnaz-hajtamiri_4983550.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 20:02:20+00:00
 - user: None

An Ontario Provincial Police logo is shown during a press conference in Barrie, Ont., on April 3, 2019. (The Canadian Press/Nathan Denette)

## Canada Sanctions More of Haiti’s Political Elites, Bringing Total to 15
 - [https://www.theepochtimes.com/canada-sanctions-more-of-haitis-political-elites-bringing-total-to-15_4984082.html](https://www.theepochtimes.com/canada-sanctions-more-of-haitis-political-elites-bringing-total-to-15_4984082.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 19:26:18+00:00
 - user: None

Former lawmaker Arnel Belizaire is escorted by national police to be presented to the press in Port-au-Prince, Haiti, Dec. 4, 2019. (The Canadian Press/AP-Dieu Nalio Chery)

## UK Could Ban New Gas Boilers Within a Decade Under Net Zero Proposals
 - [https://www.theepochtimes.com/uk-could-ban-new-gas-boilers-within-a-decade-under-net-zero-proposals_4983823.html](https://www.theepochtimes.com/uk-could-ban-new-gas-boilers-within-a-decade-under-net-zero-proposals_4983823.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 19:11:01+00:00
 - user: None

A giant sand artwork adorns New Brighton Beach to highlight the forthcoming COP26 global climate conference on in Wirral, Merseyside, on May 31, 2021. (Christopher Furlong/Getty Images)

## Air Canada Customer Says AirTag Shows Missing Bag 8,000 Km Away, Airline Won’t Retrieve It
 - [https://www.theepochtimes.com/air-canada-customer-says-airtag-shows-missing-bag-8000-km-away-airline-wont-retrieve-it_4983522.html](https://www.theepochtimes.com/air-canada-customer-says-airtag-shows-missing-bag-8000-km-away-airline-wont-retrieve-it_4983522.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 19:09:48+00:00
 - user: None

An Air Canada Boeing 737 MAX 8 approaches for landing at Toronto Pearson International Airport in Toronto, Ontario, Canada, March 13, 2019.  (Reuters/Chris Helgren)

## LIVE NOW: State Department Briefing Amid Japanese Prime Minister’s Visit
 - [https://www.theepochtimes.com/state-department-briefing-amid-japanese-prime-ministers-visit_4983632.html](https://www.theepochtimes.com/state-department-briefing-amid-japanese-prime-ministers-visit_4983632.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 18:56:47+00:00
 - user: None



## Officials Say 88 Million People in China’s Henan Province Infected With COVID
 - [https://www.theepochtimes.com/officials-say-88-million-people-in-chinas-henan-province-infected-with-covid_4979780.html](https://www.theepochtimes.com/officials-say-88-million-people-in-chinas-henan-province-infected-with-covid_4979780.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 18:46:41+00:00
 - user: None

A child receives a nucleic acid test for COVID-19 in Zhengzhou, in central China's Henan Province on July 31, 2021. (-/AFP via Getty Images)

## LIVE 3 PM ET: Japanese Prime Minister Gives Speech in Washington
 - [https://www.theepochtimes.com/japanese-prime-minister-gives-speech-in-washington_4983532.html](https://www.theepochtimes.com/japanese-prime-minister-gives-speech-in-washington_4983532.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 18:20:51+00:00
 - user: None

FILE PHOTO: Japanese Prime Minister Fumio Kishida speaks during a news conference at the prime minister's official residence in Tokyo, Japan, August 10, 2022. Rodrigo Reyes Marin/Pool via REUTERS/File Photo

## Fossil Fuels Once Again the Preferred Source of Reliable, Affordable Energy
 - [https://www.theepochtimes.com/fossil-fuels-once-again-the-preferred-source-of-reliable-affordable-energy_4980740.html](https://www.theepochtimes.com/fossil-fuels-once-again-the-preferred-source-of-reliable-affordable-energy_4980740.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 18:00:10+00:00
 - user: None

A natural gas flare on an oil well pad burns as the sun sets outside Watford City, North Dakota Jan. 21, 2016. (Reuters/Andrew Cullen)

## Gun Buyback Pilot on Prince Edward Island Not Going Ahead: Report
 - [https://www.theepochtimes.com/gun-buyback-pilot-on-prince-edward-island-not-going-ahead-report_4983593.html](https://www.theepochtimes.com/gun-buyback-pilot-on-prince-edward-island-not-going-ahead-report_4983593.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 17:19:50+00:00
 - user: None

Public Safety Minister Marco Mendicino arrives at the Public Order Emergency Commission, Nov. 22, 2022 in Ottawa. (The Canadian Press/Adrian Wyld)

## UK Economy Grew Slightly in November, Defying Expectations of Slump
 - [https://www.theepochtimes.com/uk-economy-grew-slightly-in-november-defying-expectations-of-slump_4983417.html](https://www.theepochtimes.com/uk-economy-grew-slightly-in-november-defying-expectations-of-slump_4983417.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 17:14:43+00:00
 - user: None

The City of London financial district can be seen as people walk along the south side of the River Thames, in London, on March 19, 2021. (Henry Nicholls/Reuters)

## Penalties for Public Servants Who Won’t Go Back to Office to Be Handled Individually
 - [https://www.theepochtimes.com/penalties-for-public-servants-who-wont-go-back-to-office-to-be-handled-individually_4983656.html](https://www.theepochtimes.com/penalties-for-public-servants-who-wont-go-back-to-office-to-be-handled-individually_4983656.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 17:10:51+00:00
 - user: None

President of the Treasury Board Mona Fortier speaks in the foyer of the House of Commons on Parliament Hill in Ottawa, Dec. 15, 2022. (The Canadian Press/Sean Kilpatrick)

## One in Five Canadians Say Home Heating Costs Are a ‘Financial Burden’: Federal Research
 - [https://www.theepochtimes.com/one-in-five-canadians-say-home-heating-costs-are-a-financial-burden-federal-research_4983217.html](https://www.theepochtimes.com/one-in-five-canadians-say-home-heating-costs-are-a-financial-burden-federal-research_4983217.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 16:34:32+00:00
 - user: None

Twenty-one percent of Canadians say rising home heating costs are a "financial burden," according to a study contracted by a federal department. (Steve Parsons/PA Media)

## Ontario Student Protesting Transgender Use of Girls’ Washroom Files ‘Religious Discrimination’ Appeal
 - [https://www.theepochtimes.com/ontario-student-protesting-transgender-use-of-girls-washroom-files-religious-discrimination-appeal_4981538.html](https://www.theepochtimes.com/ontario-student-protesting-transgender-use-of-girls-washroom-files-religious-discrimination-appeal_4981538.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 16:18:52+00:00
 - user: None

Josh Alexander, a grade-11 student at St. Joseph's High School in Renfew, Ont. (Yan Parisien)

## India Should Declare End to Pandemic, Recognize Natural Immunity: COVID Task Force
 - [https://www.theepochtimes.com/india-should-declare-end-to-pandemic-recognize-natural-immunity-covid-task-force_4981355.html](https://www.theepochtimes.com/india-should-declare-end-to-pandemic-recognize-natural-immunity-covid-task-force_4981355.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 15:50:00+00:00
 - user: None

A health official receives a dose of AstraZeneca's COVID-19 vaccine manufactured by the Serum Institute of India, at Infectious Diseases Hospital in Colombo, Sri Lanka, on Jan. 29, 2021. (Dinuka Liyanawatte/Reuters)

## Premier League Footballer Benjamin Mendy ‘Delighted’ After Partial Acquittal in Rape Trial
 - [https://www.theepochtimes.com/premier-league-footballer-benjamin-mendy-delighted-after-partial-acquittal-in-rape-trial_4904677.html](https://www.theepochtimes.com/premier-league-footballer-benjamin-mendy-delighted-after-partial-acquittal-in-rape-trial_4904677.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 15:48:47+00:00
 - user: None

Manchester City and France footballer Benjamin Mendy arrives at Chester Crown Court in Chester, northwest England, on Dec. 22, 2022. (Lindsey Parnaby/AFP via Getty Images)

## New UK Legislation Could See Journalists Prosecuted for Receiving a Press Release, Peer Claims
 - [https://www.theepochtimes.com/new-uk-legislation-could-see-journalists-prosecuted-for-receiving-a-press-release-peer-claims_4982945.html](https://www.theepochtimes.com/new-uk-legislation-could-see-journalists-prosecuted-for-receiving-a-press-release-peer-claims_4982945.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 15:47:29+00:00
 - user: None

Green Party member Jenny Jones,  Baroness Jones of Moulsecoomb, poses for a portrait at the "Stop HS2" camp at Euston Station in London on Jan. 31, 2021. (Hollie Adams/Getty Images)

## Why Are There so Many Cyberattacks Lately? an Explainer on the Rising Trend
 - [https://www.theepochtimes.com/why-are-there-so-many-cyberattacks-lately-an-explainer-on-the-rising-trend_4983382.html](https://www.theepochtimes.com/why-are-there-so-many-cyberattacks-lately-an-explainer-on-the-rising-trend_4983382.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 15:33:31+00:00
 - user: None

A woman uses her computer keyboard in North Vancouver, British Columbia, on Dec. 19, 2012. (Jonathan Hayward/The Canadian Press)

## ‘Australia Will Avoid a Recession’ as World Faces Economic Slump: Treasurer
 - [https://www.theepochtimes.com/australia-will-avoid-a-recession-as-world-faces-economic-slump-treasurer_4982490.html](https://www.theepochtimes.com/australia-will-avoid-a-recession-as-world-faces-economic-slump-treasurer_4982490.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 15:16:17+00:00
 - user: None

Treasurer Jim Chalmers delivers his Budget Address at Parliament House in Canberra, Australia on Oct. 25, 2022. (Martin Ollman/Getty Images)

## ‘Comprehensive Assessment’ Was Conducted Before Contracting Antisemitic Consultant: Heritage Department
 - [https://www.theepochtimes.com/comprehensive-assessment-was-conducted-before-contracting-antisemitic-consultant-heritage-department_4982964.html](https://www.theepochtimes.com/comprehensive-assessment-was-conducted-before-contracting-antisemitic-consultant-heritage-department_4982964.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 14:46:09+00:00
 - user: None

Minister of Canadian Heritage Pablo Rodriguez prepares to appear at a Senate hearing on Bill C-11, in Ottawa on Nov. 22, 2022. (The Canadian Press/Justin Tang)

## Japan Signs Agreements With US to Secure Defense Supply Chains
 - [https://www.theepochtimes.com/japan-signs-agreements-with-us-to-secure-defense-supply-chains_4982638.html](https://www.theepochtimes.com/japan-signs-agreements-with-us-to-secure-defense-supply-chains_4982638.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 14:45:43+00:00
 - user: None

U.S. Defense Secretary Lloyd Austin welcomes Japanese Defense Minister Yasukazu Hamada to the Pentagon in Washington on Jan. 12, 2023. (Mandel Ngan/AFP via Getty Images)

## Most ‘Modern Slavery’ Claimants Arriving in UK Illegally by Small Boats Are Albanian
 - [https://www.theepochtimes.com/most-modern-slavery-claimants-arriving-in-uk-illegally-by-small-boats-are-albanian_4982921.html](https://www.theepochtimes.com/most-modern-slavery-claimants-arriving-in-uk-illegally-by-small-boats-are-albanian_4982921.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 12:46:24+00:00
 - user: None

An inflatable craft carrying illegal immigrants crosses the shipping lane in the English Channel off the coast of Dover, England, on Aug. 4, 2022. (Dan Kitwood/Getty Images)

## NSW Premier’s Apologizes for 21st Birthday Nazi Costume Before State Election
 - [https://www.theepochtimes.com/nsw-premiers-apologizes-for-21st-birthday-nazi-costume-before-state-election_4982649.html](https://www.theepochtimes.com/nsw-premiers-apologizes-for-21st-birthday-nazi-costume-before-state-election_4982649.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 09:50:38+00:00
 - user: None

NSW Premier Dominic Perrottet faces the media during a press conference at Ryde Hospital, in Sydney on Jan. 13, 2023. Premier Dominic Perrottet is under mounting pressure after yesterdays relevations that he wore a Nazi uniform to his 21st birthday party. (AAP Image/Dean Lewins)

## Australia and PNG Bilateral Security Treaty to Underpin Regional Security
 - [https://www.theepochtimes.com/australia-and-png-bilateral-security-treaty-to-underpin-regional-security_4982190.html](https://www.theepochtimes.com/australia-and-png-bilateral-security-treaty-to-underpin-regional-security_4982190.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 05:53:36+00:00
 - user: None

A supplied image obtained on Friday, January 13, 2023, shows Australian Prime Minister Anthony Albanese wearing a traditional headdress during a welcome ceremony in Wewak, Papua New Guinea. Mr Albanese is the first Australian leader to visit the country since 2018. (AAP Image/Supplied by the Prime Minister's Office)

## Australian Economy Suffers $5 Billion Loss from Extreme Floods in 2022
 - [https://www.theepochtimes.com/australian-economy-suffers-5-billion-loss-from-extreme-floods-in-2022_4982545.html](https://www.theepochtimes.com/australian-economy-suffers-5-billion-loss-from-extreme-floods-in-2022_4982545.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 05:37:38+00:00
 - user: None

An aerial drone view of houses inundated by floodwater in Woodburn, Australia, on March 07, 2022. (Dan Peled/Getty Images)

## Community Group Calls on Aussie Govt to Address ‘Imperfections’ of Murray Darling Basin Plan
 - [https://www.theepochtimes.com/community-group-calls-on-aussie-govt-to-address-imperfections-of-murray-darling-basin-plan_4982503.html](https://www.theepochtimes.com/community-group-calls-on-aussie-govt-to-address-imperfections-of-murray-darling-basin-plan_4982503.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 05:29:46+00:00
 - user: None

Mayor Phil O'Connor overlooks the Murray-Darling Basin in Brewarrina,  NSW, Australia on Feb. 17, 2020. (Jenny Evans/Getty Images)

## BC Creates $500M Fund for Non-Profits to Buy Rental Buildings, Protect Tenants
 - [https://www.theepochtimes.com/bc-creates-500m-fund-for-non-profits-to-buy-rental-buildings-protect-tenants_4982569.html](https://www.theepochtimes.com/bc-creates-500m-fund-for-non-profits-to-buy-rental-buildings-protect-tenants_4982569.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 05:07:54+00:00
 - user: None

B.C. Premier David Eby speaks after being sworn in as the province's 37th premier during a ceremony at the Musqueam Nation, in Vancouver, B.C., Nov. 18, 2022. (The Canadian Press/Darryl Dyck)

## BC Tribunal Orders Woman to Repay Employer for ‘Time Theft’ While Working at Home
 - [https://www.theepochtimes.com/bc-tribunal-orders-woman-to-repay-employer-for-time-theft-while-working-at-home_4982556.html](https://www.theepochtimes.com/bc-tribunal-orders-woman-to-repay-employer-for-time-theft-while-working-at-home_4982556.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 05:03:53+00:00
 - user: None

A woman is typing on a laptop on a train in New Jersey, on May 18, 2021. (Jenny Kane/AP Photo)

## China Note! EU-Member Sweden Locates Rare Earth Deposits
 - [https://www.theepochtimes.com/china-note-eu-member-sweden-locates-rare-earth-deposits_4980581.html](https://www.theepochtimes.com/china-note-eu-member-sweden-locates-rare-earth-deposits_4980581.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 04:59:38+00:00
 - user: None

Reindeer herder Niila Inga from the Laevas Sami community walks across the snow as the sun sets on Longastunturi mountain near Kiruna, Sweden, on Nov. 27, 2019. (Malin Moberg/AP Photo)

## Mexico City Mayor Deploys National Guard to Metro After Accidents
 - [https://www.theepochtimes.com/mexico-city-mayor-deploys-national-guard-to-metro-after-accidents_4981461.html](https://www.theepochtimes.com/mexico-city-mayor-deploys-national-guard-to-metro-after-accidents_4981461.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 04:16:45+00:00
 - user: None

A member of the National Guard walks at a metro platform as part of a deployment to stations and other facilities of the metro system after a series of incidents, in Mexico City on Jan. 12, 2023. (Raquel Cunha/Reuters)

## Malaysia Says It Could Stop Palm Oil Exports to EU After New Curbs
 - [https://www.theepochtimes.com/malaysia-says-it-could-stop-palm-oil-exports-to-eu-after-new-curbs_4980093.html](https://www.theepochtimes.com/malaysia-says-it-could-stop-palm-oil-exports-to-eu-after-new-curbs_4980093.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 03:47:31+00:00
 - user: None

A worker pushes a wheelbarrow of fresh fruit bunches of oil palm tree during harvest at a palm oil plantation in Kuala Selangor, Selangor, Malaysia, on April 26, 2022. (Hasnoor Hussain/Reuters)

## Reaching for ‘Peace in Our Time’ Once Again
 - [https://www.theepochtimes.com/reaching-for-peace-in-our-time-once-again_4982310.html](https://www.theepochtimes.com/reaching-for-peace-in-our-time-once-again_4982310.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 03:33:41+00:00
 - user: None

British statesman and prime minister Neville Chamberlain (1869 - 1940) at Heston Airport on his return from Munich after meeting with Hitler, making his 'peace in our time' address. (Central Press/Getty Images)

## Albanese Govt Urged to List Iran’s Revolutionary Guard as Terrorist Organisation
 - [https://www.theepochtimes.com/albanese-govt-urged-to-list-irans-revolutionary-guard-as-terrorist-organisation_4982272.html](https://www.theepochtimes.com/albanese-govt-urged-to-list-irans-revolutionary-guard-as-terrorist-organisation_4982272.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 02:41:47+00:00
 - user: None

Australian Prime Minister Anthony Albanese speaks during a press conference in Sydney, Australia, on July 8, 2022. (Lisa Maree Williams/Getty Images)

## Marketing Over Policy: Former Special Forces Steps Down From Politics Citing Poor State of Discourse
 - [https://www.theepochtimes.com/marketing-over-policy-former-special-forces-steps-down-from-politics-citing-poor-state-of-discourse_4981998.html](https://www.theepochtimes.com/marketing-over-policy-former-special-forces-steps-down-from-politics-citing-poor-state-of-discourse_4981998.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 01:11:38+00:00
 - user: None

A polling officer hands over a ballot paper to a resident at the Australian general elections in Cook electorate of Sydney on May 21, 2022. (Saeed Khan/AFP via Getty Images)

## No ‘Serious Negligence’ or ‘Bad Faith’ From Unions Whose Unvaccinated Members Alleged Breach of Fair Representation, Alberta Labour Board Rules
 - [https://www.theepochtimes.com/no-serious-negligence-or-bad-faith-from-unions-whose-unvaccinated-members-alleged-breach-of-fair-representation-alberta-labour-board-rules_4982074.html](https://www.theepochtimes.com/no-serious-negligence-or-bad-faith-from-unions-whose-unvaccinated-members-alleged-breach-of-fair-representation-alberta-labour-board-rules_4982074.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 00:48:56+00:00
 - user: None

Albertans enter a COVID-19 mass immunization clinic in downtown Calgary, Alta., on May 17, 2021. (Jeff McIntosh/The Canadian Press)

## Newly Restored House in Pompeii Offers Glimpse of Elite Life
 - [https://www.theepochtimes.com/newly-restored-house-in-pompeii-offers-glimpse-of-elite-life_4977707.html](https://www.theepochtimes.com/newly-restored-house-in-pompeii-offers-glimpse-of-elite-life_4977707.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 00:47:22+00:00
 - user: None

Colums frame the 'peristylium', or courtyard, in the center of the Ancient Roman Domus Vettiorum, House of Vettii, in the Pompeii Archeological Park, near Naples, southern Italy, on Dec. 14, 2022. (Andrew Medichini/AP Photo)

## Another Woman Dies After Extended ER Wait Time, Family Calls for Health System Reform
 - [https://www.theepochtimes.com/another-woman-dies-after-extended-er-wait-time-family-calls-for-health-system-reform_4981419.html](https://www.theepochtimes.com/another-woman-dies-after-extended-er-wait-time-family-calls-for-health-system-reform_4981419.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-13 00:33:48+00:00
 - user: None

Paramedics are seen at the Dartmouth General Hospital in Dartmouth, N.S., on July 4, 2013. (Andrew Vaughan/The Canadian Press)
