# Source Forsal.pl, Source URL:https://forsal.pl/.feed, Source language: pl-PL

## Bolsonaro przygotowywał zamach stanu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8635381,brazylia-jair-bolsonaro-zamach-stanu.html](https://forsal.pl/swiat/aktualnosci/artykuly/8635381,brazylia-jair-bolsonaro-zamach-stanu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 21:35:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EYQktkuTURBXy83MWQ0NjZiOC1lMGZjLTQxNzctOWY2Ni1lODcyZDliYzU4YjMuanBlZ5GTBc0BHcyg" />W dokumentach byłego brazylijskiego ministra sprawiedliwości Andersona Torresa znaleziono projekt dekretu, przewidujący wprowadzenie w kraju nadzwyczajnych środków, które mogły pozwolić na anulowanie wyniku wyborów prezydenckich, przegranych przez Jaira Bolsonaro - napisał w piątek dziennik &quot;Folha de S.Paulo&quot;.

## Prorosyjscy crackerzy próbowali zhakować wybory w Czechach
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8635380,wybory-czechy-prorosyjscy-crackerzy.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8635380,wybory-czechy-prorosyjscy-crackerzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 21:28:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PDSktkuTURBXy8xZTJjMmRiMC1mOGE5LTRhMmUtOTBjZi1kOTg1ZmU1NTc0NWMuanBlZ5GTBc0BHcyg" />Pierwszy dzień wyborów prezydenckich w Czechach przebiegał prawie bez incydentów, ale dwa sztaby kandydatów zgłosiły w piątek ataki hakerskie na ich serwery. Ataki potwierdził Krajowy Urząd do spraw bezpieczeństwa cybernetycznego i informatycznego (NUKiB). Zdaniem ekspertów ataki są powiązane z działalnością prorosyjskich hakerów.

## Polski ambasador wręczył Zgromadzeniu Ogólnemu ONZ pismo nt. odszkodowań wojennych
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8635379,odszkodowania-wojenne-dla-polski-pismo-do-onz.html](https://forsal.pl/swiat/aktualnosci/artykuly/8635379,odszkodowania-wojenne-dla-polski-pismo-do-onz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 21:18:57+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PQhktkuTURBXy81NmQ0N2MxZC05YWZkLTQ5ODItOTJkYy1lNjFmMGNlYjZlN2YuanBlZ5GTBc0BHcyg" />Ambasador RP przy ONZ Krzysztof Szczerski spotkał się w piątek z przewodniczącym Zgromadzenia Ogólnego ONZ Csabą Korosim i przekazał mu pismo z prośbą o przyjrzenie się sprawie odszkodowań wojennych od Niemiec, o które stara się Polska. Jak powiedział PAP Szczerski, kopię listu otrzymał też sekretarz generalny ONZ Antonio Guterres.

## Najbardziej kłopotliwa minister niemieckiego rządu poda się do dymisji?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8635367,christine-malmbrech-dymisja.html](https://forsal.pl/swiat/aktualnosci/artykuly/8635367,christine-malmbrech-dymisja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 20:39:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1P-ktkuTURBXy8zZDA5YWY2ZS1iODNjLTRkMzktOWMxMS1jYjgwMGE4ZmFjYWYuanBlZ5GTBc0BHcyg" />Niemiecka minister obrony narodowej Christine Lambrecht (SPD), najbardziej kłopotliwy minister obecnego rządu, postanowiła podać się do dymisji – informuje w piątek portal dziennika „Bild”, powołując się na kilka źródeł.

## Szynkowski vel Sęk: Wprowadzanie poprawek do ustawy o SN to igranie z pozyskaniem środków europejskich
 - [https://forsal.pl/gospodarka/polityka/artykuly/8635365,szymon-szynkowski-vel-sek-ustawa-o-sn-senat-poprawki.html](https://forsal.pl/gospodarka/polityka/artykuly/8635365,szymon-szynkowski-vel-sek-ustawa-o-sn-senat-poprawki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 20:13:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7MAktkuTURBXy9iMjkzMzQ1NC02ZDE4LTRlZmMtOTQwNy04NzlhZjA5OTExYTcuanBlZ5GTBc0BHcyg" />Zwlekanie przez Senat lub wprowadzanie daleko idących poprawek do nowelizacji ustawy o Sądzie Najwyższym jest bardzo ryzykowne, jest de facto igraniem z pozyskaniem środków europejskich - mówił w piątek minister ds. UE Szymon Szynkowski vel Sęk.

## Rafako vs. Tauron. Kolejny zwrot w sporze spółek
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8635342,rafako-tauron-spor-o-jaworzno.html](https://forsal.pl/biznes/aktualnosci/artykuly/8635342,rafako-tauron-spor-o-jaworzno.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 19:51:25+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0axktkuTURBXy83ODBiZDdhYi05YTc5LTQ2MjgtOTU2Yy01ZDFhZWUxYTU5OGYuanBlZ5GTBc0BHcyg" />Rafako wezwało Tauron Wytwarzanie do zapłaty 606,5 mln zł oraz spółkę Tauron Polska Energia do zapłaty 251,1 mln zł - podała w piątek w komunikacie spółka

## Joe Biden ma kłopoty? Co znajdowało się w tajnych dokumentach, które "zawieruszyły się" w jego willi?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8635338,joe-biden-tajne-dokumenty-biuro-willa-przeszukanie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8635338,joe-biden-tajne-dokumenty-biuro-willa-przeszukanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 19:33:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/scPktkuTURBXy8xMzFkNWIwZS1jMjExLTRlMWYtYmM5YS02NWM5N2U5MDcyOGEuanBlZ5GTBc0BHcyg" />Wśród niejawnych dokumentów, znalezionych w domu i biurze Joe Bidena, były materiały przygotowujące go do rozmowy z przewodniczącym Rady Europejskiej i premierem Wielkiej Brytanii - przekazała w piątek CNN. Pochodziły one z czasu, kiedy Biden - obecny prezydent USA - był wiceprezydentem.

## Rząd Ugandy anuluje kontrakt na budowę linii kolejowej z Chinami. Może go przejąć Turcja
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634785,uganda-chiny-turcja-kontrakt-linie-kolejowe.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634785,uganda-chiny-turcja-kontrakt-linie-kolejowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 18:20:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QVKktkuTURBXy84YjJlMDYzYi02ZDQ1LTRmZjEtYjNjYy05MTljYzI1ODdhNWEuanBlZ5GTBc0BHcyg" />Po ośmiu latach oczekiwania na wdrożenie projektu rząd Ugandy rozwiązał kontrakt o wartości 2,2 mld USD z China Harbor Engineering Company (CHEC) na budowę pierwszej w kraju dalekobieżnej linii kolejowej. W perspektywie porozumienie z inwestorem tureckim - podał w piątek serwis The EastAfrican.

## Wybuch gazociągu łączącego Litwę z Łotwą
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634736,wybuch-gazociagu-litwa-lotwa.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634736,wybuch-gazociagu-litwa-lotwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 18:09:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ejxktkuTURBXy9hNzg3NzA0ZS0wMjhiLTRkMzctOGZiNS1iODdhZGEyMWMyNjIuanBlZ5GTBc0BHcyg" />Litewski operator przesyłu gazu Amber Grid poinformował w piątek, że doszło do eksplozji gazociągu łączącego Litwę i Łotwę na odcinku w okolicach litewskiego miasta Paswol na północy kraju. Nikt nie został ranny.

## Wdrożycie, to ocenimy. Von der Leyen o polskiej ustawie o SN
 - [https://forsal.pl/gospodarka/polityka/artykuly/8634728,von-der-leyen-ustawa-o-sn.html](https://forsal.pl/gospodarka/polityka/artykuly/8634728,von-der-leyen-ustawa-o-sn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 17:25:58+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yx7ktkuTURBXy8wNzg3NjUzMC05NjI2LTQyYTAtODJhZS01YTQ0ZWMzZjAxODkuanBlZ5GTBc0BHcyg" />Komisja Europejska oceni, czy ostatnie zmiany w polskim sądownictwie mogą doprowadzić do wypłaty środków z Funduszu Odbudowy dopiero wtedy, gdy nowe prawo zostanie wdrożone - przekazała przewodnicząca KE Ursula von der Leyen w piątek w szwedzkiej Kirunie.

## Ropa na rynku w piątek drożeje o ponad 1 proc.
 - [https://forsal.pl/finanse/notowania/artykuly/8634724,cena-ropy-13-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8634724,cena-ropy-13-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 17:08:23+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cuyktkuTURBXy9lYzViNDkzMS0wMGZlLTQ2MTctODQ4Mi1iODUwM2YxZGI4YzkuanBlZ5GTBc0BHcyg" />Notowania ropy na rynku w piątek wzrosły o ponad 1 proc. Cena baryłki Brent zdrożała o nieco ponad 1 proc., do niecałych 85 dol. Amerykańska ropa WTI podrożała o 1,4 proc., do 79,5 dol. za baryłkę.

## Gaz na europejskim rynku w piątek tanieje o ponad 5 proc.
 - [https://forsal.pl/finanse/notowania/artykuly/8634723,gaz-tanieje-13-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8634723,gaz-tanieje-13-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 17:06:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4HmktkuTURBXy8yOGZiNGNhNS01N2FhLTQ0MzItYmY1Yy0xMDkwY2UwOTM4YTcuanBlZ5GTBc0BHcyg" />Gaz w holenderskim hubie TTF w piątek tanieje o ponad 5 proc. Wycena kontraktów z dostawą w najbliższych miesiącach jest już poniżej 65 euro za MWh.

## Import gazu z Iraku? Scholz jest na "tak"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634721,olaf-scholz-import-gazu-z-iraku.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634721,olaf-scholz-import-gazu-z-iraku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 17:01:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Aq1ktkuTURBXy9mNWY4ZTY5MC1mNmU4LTQ4ZDEtOWI3Mi1jNGRmYjdjYmRlOGUuanBlZ5GTBc0BHcyg" />Kanclerz Niemiec Olaf Scholz opowiedział się za importem gazu z Iraku. &quot;Irak byłby dla nas bardzo mile widzianym partnerem do współpracy w zakresie importu gazu i ropy do Niemiec&quot; - powiedział Scholz w piątek na konferencji prasowej z nowym premierem Iraku Mohammedem Szia al-Sudanim w Berlinie.

## Trump oszukiwał na podatkach. Jego firma zapłaci karę
 - [https://forsal.pl/swiat/usa/artykuly/8634719,trump-organization-oszustwa-podatkowe-kara.html](https://forsal.pl/swiat/usa/artykuly/8634719,trump-organization-oszustwa-podatkowe-kara.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:57:30+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PunktkuTURBXy8zY2M3OTM0NC00MzU0LTRjYzAtOTAxYS04YzZhZjgwMThjNTguanBlZ5GTBc0BHcyg" />Sąd najwyższy stanu Nowy Jork nakazał w piątek Trump Organization - grupie spółek byłego prezydenta USA Donalda Trumpa - zapłatę maksymalnej kary 1,61 mln dolarów za trwające przez 15 lat oszustwa podatkowe. Wcześniej dyrektor finansowy konglomeratu Allan Weisselberg został skazany na pięć miesięcy więzienia.

## Brazylia: Radykalni zwolennicy Bolsonaro z zablokowanymi kontami
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634714,brazylia-jair-bolsonaro-zwolennicy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634714,brazylia-jair-bolsonaro-zwolennicy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:45:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_x8ktkuTURBXy84MjRhZWQ4Ni04MThmLTQzOTEtODUzNy03ZjE5YjM1Y2EzZWQuanBlZ5GTBc0BHcyg" />Sąd federalny w Brasilii nakazał w piątek zablokować majątek 52 osób i siedmiu firm, które miały sponsorować radykalnych zwolenników byłego prezydenta Brazylii Jaira Bolsonaro. Orzeczenie jest konsekwencją niedzielnego szturmu prawicowych manifestantów na budynki instytucji państwowych.

## Mieszkańcy Niemiec przyjeżdżają do Polski, by farbować włosy
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8634700,niemcy-fryzjer-przyjazd-do-polski-ceny-inflacja.html](https://forsal.pl/biznes/aktualnosci/artykuly/8634700,niemcy-fryzjer-przyjazd-do-polski-ceny-inflacja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:43:16+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gxQktkuTURBXy82Yjc0MDBhYS0wNmRiLTQ5MzEtOGUzOS04N2ExNjNmZGM5NGQuanBlZ5GTBc0BHcyg" />Fryzjerzy w stolicy Niemiec i Brandenburgii podwyższają ceny z powodu inflacji. Więcej mieszkańców RFN „przyjeżdża do Polski, by farbować włosy” – pisze „Berliner Zeitung”.

## Lex Pilot. Mniejsza oferta, większe opłaty za telewizję
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8634711,lex-pilot-telewizja-oplaty.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8634711,lex-pilot-telewizja-oplaty.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:41:19+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0P7ktkuTURBXy80MGNmYmFhMy0wZTBhLTQ5M2EtOGEyMy0zNTQ1NWVlNmFlNWQuanBlZ5GTBc0BHcyg" />Regulacje, zawarte w projekcie prawa komunikacji elektronicznej, który dzisiaj trafił do prac w sejmowej Komisji Cyfryzacji, Innowacyjności i Nowoczesnych Technologii w zakresie tzw. Lex Pilot doprowadzi do wyższych opłat za telewizję, przyczyni się do pogorszenia jakości kanałów i ograniczy wybór, uważa Polska Izba Komunikacji Elektronicznej (PKIE).

## Sytuacja złotego na tle dolara, franka i euro
 - [https://forsal.pl/finanse/waluty/artykuly/8634710,zloty-euro-frank-dolar-13-stycznia.html](https://forsal.pl/finanse/waluty/artykuly/8634710,zloty-euro-frank-dolar-13-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:33:24+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xnyktkuTURBXy9lMmFkNzVlYy02ODJjLTRmOTAtOWE1Yy03MTdkMjI1YjllNzYuanBlZ5GTBc0BHcyg" />W piątek po południu złoty traci na wartości do dolara i franka szwajcarskiego, które kosztują odpowiednio 4,34 zł i 4,68 zł. Euro jest po 4,70 zł, stabilnie względem czwartku.

## Media powinny mówić, że jest to konflikt Rosji z NATO. Nowe zalecenia rosyjskiej armii ws. informacji o wojnie
 - [https://forsal.pl/swiat/rosja/artykuly/8634706,rosja-media-zalecenia-informacje-o-wojnie-w-ukrainie.html](https://forsal.pl/swiat/rosja/artykuly/8634706,rosja-media-zalecenia-informacje-o-wojnie-w-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:30:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CmEktkuTURBXy81YTM5ZjI1MS00ZjBkLTQ3ZWYtOThjZi01YjNiYzU2NzI0MGMuanBlZ5GTBc0BHcyg" />Sztab rosyjskiej armii wydał zalecenia w sprawie informowania o wojnie przeciwko Ukrainie, zgodnie z którymi media powinny mówić, że jest to konflikt Rosji z NATO, usprawiedliwiać ataki na ukraińską infrastrukturę cywilną i podnosić zasługi formalnych dowódców - przekazał ukraiński wywiad wojskowy w piątek.

## Długi publiczne wielu państw strefy euro przekraczają ich PKB
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634703,dlug-publiczny-pkb-strefa-euro.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634703,dlug-publiczny-pkb-strefa-euro.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:21:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g9JktkuTURBXy8yZTYyYWRlYy1hMWNmLTQyYTEtYmMzNS01YzAyMzRkYTgyOTIuanBlZ5GTBc0BHcyg" />Największy dług publiczny w UE mają: Grecja - 182 proc. w stosunku do PKB, Włochy - 150 proc., Portugalia - 123 proc., Hiszpania - 116,1 proc. - podały w piątek hiszpańskie media, przypominając, że Komisja Europejska zaleca „konsolidację fiskalną”, co oznacza podwyższenie podatków lub zredukowanie wydatków budżetowych.

## Lalki i samochodziki-bomby. Perfidne działania rosyjskiego agresora
 - [https://forsal.pl/swiat/rosja/artykuly/8634702,rosja-bomby-w-zabawkach.html](https://forsal.pl/swiat/rosja/artykuly/8634702,rosja-bomby-w-zabawkach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:17:12+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AnlktkuTURBXy8xZGUyMWZmMC0xMmJhLTQ4NmYtYWE0OS04NWE2ZDNiZTkxZWEuanBlZ5GTBc0BHcyg" />Zastępca ministra koordynatora służb specjalnych publikuje w mediach społecznościowych zdjęcia min-pułapek, które rosyjscy agresorzy montują na Ukrainie. Śmiercionośne ładunki, które sfotografowano, zostały ukryte m.in. w lalce przypominającej niemowlę, w grającej zabawce, w samochodziku z klocków. Zdaniem Stanisława Żaryna to kolejna rosyjska zbrodnia wojenna.

## Ustawa przegłosowana, kiedy kasa z KPO? [KOMENTARZ]
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8634693,kpo-kiedy-pieniadze.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8634693,kpo-kiedy-pieniadze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 16:01:23+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H-tktkuTURBXy8zYjlmMTBmNC02ZWRkLTRkYzEtODM0Mi1jMGYzZmQ3NTI2NWEuanBlZ5GTBc0BHcyg" />Wygrana PiS w Sejmie przy głosowaniu nad ustawą o SN rzeczywiście zbliża nas do odblokowania 36 mld euro z KPO. Ale to jeszcze nie znaczy, że droga do tych pieniędzy nie jest długa i kręta.

## Koniec budowy tunelu w Świnoujściu coraz bliżej. Zobacz ZDJĘCIA
 - [https://forsal.pl/gospodarka/galeria/8634678,tunel-swinoujscie-budowa-zdjecia.html](https://forsal.pl/gospodarka/galeria/8634678,tunel-swinoujscie-budowa-zdjecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 15:52:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8efktkuTURBXy8yZjA5YTEwOC1jOWE5LTQzN2QtYTY3Ni1hNTkwMmU5YzE4NzcuanBlZ5GTBc0BHcyg" />W tunelu pomiędzy wyspami Uznam i Wolin trwają prace porządkowe przed rozpoczęciem wylewania asfaltu na nawierzchnię drogową. Pierwsze pojazdy przejadą nim jeszcze przed tegorocznymi wakacjami. Zobacz, jak teraz wygląda najdłuższa podwodna przeprawa w Polsce.

## Zniesienie zasady 10H. Nowelizacja ustawy o elektrowniach wiatrowych w komisji sejmowej
 - [https://forsal.pl/biznes/energetyka/artykuly/8634675,ustawa-elektrownie-wiatrowe-zasada-10h.html](https://forsal.pl/biznes/energetyka/artykuly/8634675,ustawa-elektrownie-wiatrowe-zasada-10h.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:59:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BTfktkuTURBXy83ZGNmYTJlYi02NDE1LTQyNTctYmE4Zi01Nzk0N2IzNzZjNjguanBlZ5GTBc0BHcyg" />Rządowy projekt nowelizacji ustawy o inwestycjach w zakresie elektrowni wiatrowych, zakładający zniesienie zasady 10H, czyli zakazu lokowania elektrowni w promieniu wyznaczonym przez odległość równą dziesięciokrotności całkowitej wysokości projektowanej elektrowni wiatrowej do zabudowy mieszkaniowej został skierowany do prac w sejmowej Komisji do Spraw Energii, Klimatu i Aktywów Państwowych oraz Komisji Samorządu Terytorialnego i Polityki Regionalnej.

## Represje wobec mediów w Rosji i w Białorusi. Łotwa daje możliwość uczciwej pracy rosyjskojęzycznym dziennikarzom
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634672,lotwa-praca-dla-rosyjskojezycznych-dziennikarzy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634672,lotwa-praca-dla-rosyjskojezycznych-dziennikarzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:51:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xN7ktkuTURBXy9lZDNiZmU5NC04Mzk2LTQyYjgtOWFhNi03NDRiYTI2YWNhMWQuanBlZ5GTBc0BHcyg" />Radio Wolna Europa/Radio Swoboda (RFE/RL) otworzyło nową redakcję w Rydze, gdzie będą pracować m.in. dziennikarze z kilku rosyjskojęzycznych oddziałów RFE, a w Wilnie niedawno otwarto redakcję, która zajmuje się publikowaniem wiadomości z Białorusi.

## Finansowy cios w CEO Apple’a. Jego wynagrodzenie spadnie o 40 proc.
 - [https://forsal.pl/biznes/artykuly/8634670,ceo-apple-obnizka-pensji.html](https://forsal.pl/biznes/artykuly/8634670,ceo-apple-obnizka-pensji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:50:28+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Uw6ktkuTURBXy9iZmY4ZGNkOC1mNDcyLTQ4YzUtODk1Ny0yYWQxMGIyN2MwOTUuanBlZ5GTBc0BHcyg" />Apple poinformowało, że całkowite wynagrodzenie dyrektora generalnego firmy spadnie w 2023 roku do 49 mln dol. - pisze CNBC.

## Ogromne podwyżki biletów na PKP Intercity nie mają uzasadnienia. Według klubu KO
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8634667,podwyzki-cen-biletow-pkp-intercity-ko.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8634667,podwyzki-cen-biletow-pkp-intercity-ko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:43:41+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0ZVktkuTURBXy8wMTc2MDcwZC1iNWI5LTQxMTQtOGIyNC1mMzYyNTQ5N2Q5NzMuanBlZ5GTBc0BHcyg" />Ogromne podwyżki biletów na PKP Intercity nie mają uzasadnienia; ceny biletów można by nawet obniżyć, gdyby wprowadzono np. zerowy VAT na przejazdy kolejowe - mówili na piątkowej konferencji Urszula Zielińska, Maciej Lasek i Franciszek Sterczewski z klubu KO.

## "Pozostajemy w kontakcie z polskimi władzami". Rzecznik KE o ustawie o SN
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8634662,christian-wigand-komisja-europejska-ustawa-o-sn.html](https://forsal.pl/swiat/unia-europejska/artykuly/8634662,christian-wigand-komisja-europejska-ustawa-o-sn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:38:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7l6ktkuTURBXy8zM2QzNDMyMy04ZDZjLTRlYzUtODdmMC04YTJlY2E2ZDY0YzUuanBlZ5GTBc0BHcyg" />Nowy projekt ustawy o sądownictwie złożony przez polski rząd w grudniu 2022 r., a obecnie przyjęty przez Sejm, jest ważnym krokiem w kierunku wypełnienia zobowiązań wynikających z polskiego Krajowego Planu Odbudowy - powiedział PAP rzecznik Komisji Europejskiej Christian Wigand.

## Mój drogi, grecki urlop. Jak wzrosły ceny w hotelach?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8634659,grecja-wzrost-cen-hotele.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8634659,grecja-wzrost-cen-hotele.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:31:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c5uktkuTURBXy9mMTUxZTBjOC03YzUwLTQ5ZWQtYmRkNS1jYTAzNjZkMGM5Y2QuanBlZ5GTBc0BHcyg" />Ceny w umowach, które podpisują greccy hotelarze z głównymi europejskimi organizatorami wycieczek, wzrosły średnio o 12 procent w sezonie turystycznym 2023 w stosunku do zeszłego roku. W przypadku prywatnych rezerwacji wzrost cen może przekroczyć nawet 100 procent - poinformował w piątek grecki portal Ekathimerini.

## W pierwszym tygodniu ferii benzyna może podrożeć
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8634653,cena-paliw-pierwszy-tydzien-ferii.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8634653,cena-paliw-pierwszy-tydzien-ferii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:23:41+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fl8ktkuTURBXy9mMzcwYjc4MS03NmI4LTQ1Y2UtYmFlYy0zYmUyY2MwOTI4ZGYuanBlZ5GTBc0BHcyg" />W pierwszym tygodniu ferii na stacje mogą wrócić kilkugroszowe podwyżki - przewidują analitycy Refleksu. W przypadku benzyny i diesla to będzie efekt wzrostu cen hurtowych od 13 stycznia i ewentualnych dalszych podwyżek - wyjaśnili.

## Niemcy unikną załamania gospodarczego. O ile wzrosło PKB sąsiada z zachodu?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634644,niemcy-wzrost-pkb-2022.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634644,niemcy-wzrost-pkb-2022.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:08:18+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h7LktkuTURBXy8xZWQ0ZWM1ZC1hMjYzLTRhNWEtYWM4ZS0yMzUwOTFjMGYzYWMuanBlZ5GTBc0BHcyg" />Mimo inflacji, wojny w Ukrainie i problemów z dostawami niemiecka gospodarka odnotowała wzrost w ubiegłym roku. Produkt krajowy brutto (PKB) wzrósł o 1,9 procent - ogłosił w piątek Federalny Urząd Statystyczny na podstawie wstępnych szacunków. Gospodarka nie dorównała jednak wynikowi z roku 2021, kiedy to PKB poszedł w górę o 2,6 proc.

## Oto najważniejsze cechy polskich liderów w 2023 roku
 - [https://forsal.pl/biznes/firma/artykuly/8634661,najwazniejsze-cechy-polskich-liderow-2023.html](https://forsal.pl/biznes/firma/artykuly/8634661,najwazniejsze-cechy-polskich-liderow-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5-tktkuTURBXy9jZTU3NmI2OC03NzE0LTQ5MjItOWJiMC02OTA2MTNkNDIyNzMuanBlZ5GTBc0BHcyg" />Uczucie niepewności zdominowało Europę i nie powinno nas dziwić, że przeciętny Polak czuje niepokój myśląc o 2023 roku – uważa Piotr Arak z Polskiego Instytutu Ekonomicznego. Przed jakimi wyzwaniami stają więc polscy liderzy w perspektywie kolejnych 12 miesięcy? Jakie cechy i umiejętności powinni przede wszystkim rozwijać, by móc im sprostać?

## Wybory prezydenckie w Czechach. Faworyci mają za sobą członkostwo w partii komunistycznej
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634639,wybory-prezydenckie-czechy-2023.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634639,wybory-prezydenckie-czechy-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 13:59:09+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y2gktkuTURBXy8xNmJiMTM2MS1mOGRiLTRhN2MtYjBiZS02YWNhNmFiZjRmYTAuanBlZ5GTBc0BHcyg" />O godz. 14.00 w piątek w Czechach rozpoczęły się bezpośrednie wybory prezydenckie, w których uczestniczy ośmioro kandydatów. Prezydent Milosz Zeman kończy drugą kadencję i nie mógł już kandydować. Lokale wyborcze zostaną zamknięte o godz. 22.00 i ponownie będą czynne w sobotę od godz. 8.00 do 14.00.

## Spotkanie przedstawicieli Paktu Wolnych Miast. Powstanie Dom Rekonstrukcji Ukrainy?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634637,pakt-wolnych-miast-spotkanie-rekonstrukcja-ukrainy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634637,pakt-wolnych-miast-spotkanie-rekonstrukcja-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 13:48:04+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1SEktkuTURBXy8zNDUwNGZmNy0zNzExLTRlYjUtYmY5OC03MGUwNDlkOTVjNjAuanBlZ5GTBc0BHcyg" />W piątek przed południem czterej włodarze miast europejskich: Warszawy, Pragi, Bratysławy i Budapesztu zrzeszeni w Pakcie Wolnych Miast, dojechali do Warszawy. Przez dwa dni gościli na Ukrainie.

## Od marca uchodźcy będą partycypować w kosztach utrzymania w ośrodkach zbiorowego zakwaterowania
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8634618,ustawa-o-pomocy-obywatelom-ukrainy-nowelizacja.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8634618,ustawa-o-pomocy-obywatelom-ukrainy-nowelizacja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 13:29:36+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/APxktkuTURBXy85MTg5MTRhOC1kYmI2LTRkMmUtOTUyOS0xMDAyMzM4OTllZWYuanBlZ5GTBc0BHcyg" />Sejm odrzucił poprawki Senatu do nowelizacji ustawy o pomocy obywatelom Ukrainy w związku z konfliktem zbrojnym na terytorium tego państwa, przesuwające termin wejścia w życie przepisów dot. partycypacji uchodźców w części kosztów, związanej z zakwaterowaniem i wyżywieniem.

## Po raz pierwszy od kwietnia 2021 r. wartość polskiego eksportu rosła szybciej niż wartość importu
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8634610,eksport-import-listopad-2022-polska.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8634610,eksport-import-listopad-2022-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 13:14:35+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/bAsktkuTURBXy81MDkyYTM1Ny1jMjc0LTRmZTgtODJlMy0xMTMxNzliODRkMGEuanBlZ5GTBc0BHcyg" />Eksport towarów z Polski wzrósł o 20,3 proc. w porównaniu do zeszłego roku, do 30 018 mln euro w listopadzie 2022 r., zaś import wzrósł o 17,7 proc. do 31 514 mln euro, wynika z danych przedstawionych przez Narodowy Bank Polski (NBP). Po raz pierwszy od kwietnia 2021 r. wartość eksportu rosła szybciej niż wartość importu.

## Eksperci: Odczyty inflacji CPI sugerują, że tempo podwyżek stóp w USA może zwolnić
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8634604,inflacja-fed-usa-stopy-procentowe.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8634604,inflacja-fed-usa-stopy-procentowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 13:04:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eywktkuTURBXy9iYTBkOTEwYy1jMzE1LTQxNDYtYTlhZi02Nzg4YWVlNDZjYjYuanBlZ5GTBc0BHcyg" />Pomimo napięcia związanego z rozbieżnością prognoz Rezerwy Federalnej (Fed) na ten rok z konsensusem rynkowym, odczyty inflacji CPI sugerują, że tempo podwyżek stóp procentowych w USA może zwolnić do 25 pkt bazowych na posiedzeniu Fed 1 lutego – przekazali w piątek analitycy UBS.

## Niemiecki polityk ws. Leopardów dla Ukrainy: Polska przeszła do ofensywy, a uparty kanclerz stoi na drodze
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634599,niemiecki-polityk-ws-leopardow-dla-ukrainy-polska-przeszla-do-ofensywy-a-uparty-kanclerz-stoi-na-drodze.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634599,niemiecki-polityk-ws-leopardow-dla-ukrainy-polska-przeszla-do-ofensywy-a-uparty-kanclerz-stoi-na-drodze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 12:56:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cXlktkuTURBXy9iMDc2MjVkMi1hNGUyLTQ4NzItYmU5NS1iNDJkYjc3YzViYjAuanBlZ5GTBc0BHcyg" />Johann Wadephul (CDU), wiceszef frakcji Unii, zarzucił kanclerzowi Scholzowi upór w kwestii dostawy czołgów na Ukrainę. Wiele krajów od dawna chce coś zrobić w tej sprawie, „Polska przeszła do ofensywy, a uparty kanclerz stoi na drodze” – stwierdził Wadephul w piątek w programie „Fruehstart” RTL/ntv.

## Oto grupa w Rosji, u której rosną dochody podczas wojny. "Wzrost świadczeń socjalnych"
 - [https://forsal.pl/swiat/rosja/artykuly/8634592,rosja-dochody-najbiedniejsi-rosjanie-dochody.html](https://forsal.pl/swiat/rosja/artykuly/8634592,rosja-dochody-najbiedniejsi-rosjanie-dochody.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 12:45:13+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CCNktkuTURBXy8xMWM5ODc1ZC02NzkxLTRkOTgtODhhZS1hMjIyYjcyMGY0Y2EuanBlZ5GTBc0BHcyg" />Wzrost świadczeń socjalnych, związany z rosyjską inwazją na Ukrainę, podniósł dochody najbiedniejszych w Rosji ponad dwukrotnie w stosunku do stopy inflacji; to jedyna grupa w Rosji, która radzi sobie tak dobrze - oceniła w piątek agencja Bloomberga. Rosja przeznacza obecnie około dwóch trzecich swojego budżetu na programy socjalne, obronne oraz bezpieczeństwa.

## Maląg: Praca zdalna zostaje wprowadzona do Kodeksu pracy
 - [https://forsal.pl/praca/aktualnosci/artykuly/8634578,praca-zdalna-zostaje-wprowadzona-do-kodeksu-pracy.html](https://forsal.pl/praca/aktualnosci/artykuly/8634578,praca-zdalna-zostaje-wprowadzona-do-kodeksu-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 12:28:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/huektkuTURBXy9mMmVjYTg4My0wZmNkLTQ2MzItYWZlMC0wMWFiMzk2MDhmYWUuanBlZ5GTBc0BHcyg" />Dzisiaj jest bardzo dobry dzień – przegłosowano dwie bardzo ważne zmiany: nowelizację Kodeksu pracy i ustawy o przeciwdziałaniu przemocy w rodzinie. Praca zdalna funkcjonowała do tej pory na mocy przepisów covidowych, teraz zostaje wprowadzona do Kodeksu pracy – poinformowała szefowa MRiPS Marlena Maląg.

## PKO BP: W styczniu i lutym inflacja wzrośnie do 19-20 proc. r:r
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8634577,inflacja-styczen-luty-prognozy.html](https://forsal.pl/gospodarka/inflacja/artykuly/8634577,inflacja-styczen-luty-prognozy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 12:26:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/83cktkuTURBXy9kMmJmOTk5MC1hMTI1LTQxMmItYmE0YS0zMzMxMDIwYjllN2UuanBlZ5GTBc0BHcyg" />W styczniu i lutym br. inflacja CPI wzrośnie do 19-20 proc. r/r, by wejść w trend spadkowy, który na koniec roku sprowadzi ją nieco poniżej 10 proc. r/r. - prognozują ekonomiści PKO BP komentując dane GUS. Kluczowe znaczenie dla najbliższych dwóch odczytów będą miały ceny energii i paliw - dodano.

## Ziobro: Będziemy podejmować wszystkie działania, by rozwiązania ustawy o SN nie weszły w życie
 - [https://forsal.pl/gospodarka/polityka/artykuly/8634568,ziobro-ustawa-sn-polska-kpo.html](https://forsal.pl/gospodarka/polityka/artykuly/8634568,ziobro-ustawa-sn-polska-kpo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 12:16:55+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Xa3ktkuTURBXy8zNzUzN2ViNy1hNWE5LTQ1N2ItOGExYy0wYjFmZThmOTY0ODYuanBlZ5GTBc0BHcyg" />Będziemy podejmować wszystkie możliwe działania, by rozwiązania ustawy o SN nie weszły w życie, bo uważamy, że polityka prowadzona pod &quot;szantażem ze strony Brukseli czy Berlina&quot; musi się dla Polski i dla Polaków źle skończyć - powiedział w piątek szef MS Zbigniew Ziobro.

## Premier ws. ustawy o SN: Trudny kompromis, ale przede wszystkim trzeba zakończyć spór z KE
 - [https://forsal.pl/gospodarka/polityka/artykuly/8634548,ustawa-o-sn-premier-kpo-ke.html](https://forsal.pl/gospodarka/polityka/artykuly/8634548,ustawa-o-sn-premier-kpo-ke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 11:58:47+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LM8ktkuTURBXy9lNjEzMjYxOC03Yzc2LTRhMzgtODFmYy1kZjk2NzcwOTc5MjkuanBlZ5GTBc0BHcyg" />Nowelizacja ustawy o Sądzie Najwyższym to trudnym kompromis, ale przede wszystkim chodzi w niej o to, by zakończyć jeden spór i skupić się na prawdziwym przeciwniku, który jest na Wschodzie, nie na Zachodzie - powiedział premier Mateusz Morawiecki w Sejmie po uchwaleniu noweli.

## Co dalej z polskim KPO? Jest komentarz rzecznika KE
 - [https://forsal.pl/gospodarka/polityka/artykuly/8634525,kpo-polska-ke-ustawa-rzad.html](https://forsal.pl/gospodarka/polityka/artykuly/8634525,kpo-polska-ke-ustawa-rzad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 11:41:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QRhktkuTURBXy8yZDM5NjM2MS1mMWZmLTRlOWMtODJkYy0wNjcxMzAwOTQ1NDUuanBlZ5GTBc0BHcyg" />Nowy projekt ustawy o sądownictwie złożony przez polski rząd w grudniu 2022 r., a obecnie przyjęty przez Sejm, jest ważnym krokiem w kierunku wypełnienia zobowiązań wynikających z polskiego Krajowego Planu Odbudowy - powiedział PAP rzecznik Komisji Europejskiej Christian Wigand.

## ING: Szczyt inflacji przypadnie w lutym
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8634503,szczyt-inflacji-w-polsce-kiedy.html](https://forsal.pl/gospodarka/inflacja/artykuly/8634503,szczyt-inflacji-w-polsce-kiedy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 11:24:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4lbktkuTURBXy84NDZmN2I4Zi01NzI3LTQxOWUtYmIzOC01ZTNhZDRiNzA1YjYuanBlZ5GTBc0BHcyg" />Szczyt inflacji nadal pozostaje przed nami, przypadnie w lutym 2023 i wyniesie ok. 20 proc. rdr - przewidują ekonomiści ING. Ich zdaniem bieżący rok będzie upływał pod znakiem dezinflacji, jednak inflacja bazowa pozostanie wysoka.

## Gospodarka Wielkiej Brytanii nie jest jeszcze w recesji?
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8634485,wielka-brytania-recesja-gospodarka.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8634485,wielka-brytania-recesja-gospodarka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:59:10+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-hNktkuTURBXy8yNTZmMjVlYi02NDRkLTQ4N2UtODNlYi0yMzMzOTE0Y2U2ZmUuanBlZ5GTBc0BHcyg" />W listopadzie gospodarka Wielkiej Brytanii zanotowała wzrost, a nie spadek PKB, którego spodziewali się analitycy, co znaczy, że wbrew podnoszonym od kilku tygodni obawom, kraj najprawdopodobniej nie jest jeszcze w recesji - podał w piątek urząd statystyczny ONS.

## Orlen VC dokonał piątej, największej dotąd inwestycji, w platformę Shippeo
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8634470,orlen-vc-dokonal-piatej-najwiekszej-dotad-inwestycji-w-platforme-shippeo.html](https://forsal.pl/biznes/aktualnosci/artykuly/8634470,orlen-vc-dokonal-piatej-najwiekszej-dotad-inwestycji-w-platforme-shippeo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:48:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4DSktkuTURBXy83OGZhZDFmMS01OThlLTQ0MTMtOTczYi0xZDFlMDlmNmI3NzAuanBlZ5GTBc0BHcyg" />Należący do PKN Orlen fundusz korporacyjny Orlen VC zrealizował piątą i największą jak do tej pory inwestycję bezpośrednią - w platformę francuskiej firmy Shippeo, która pozwala wydajniej zarządzać procesami logistycznymi w firmach operujących niemal w każdej gałęzi przemysłu, podał koncern. Pierwszy rok działalności Orlen VC zamknął z siedmioma inwestycjami kapitałowymi w łącznej kwocie ponad 150 mln zł.

## Sejm przyjął ustawę o inwestycjach w obiekty energetyki jądrowej
 - [https://forsal.pl/biznes/energetyka/artykuly/8634464,inwestycje-w-obiekty-energetyki-jadrowej.html](https://forsal.pl/biznes/energetyka/artykuly/8634464,inwestycje-w-obiekty-energetyki-jadrowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:43:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AMMktkuTURBXy8yYzE3NjYxYi04YzU2LTRjMzQtYWY4Yy1jOTYwMzg2YWRkYmYuanBlZ5GTBc0BHcyg" />Sejm przyjął ustawę o inwestycjach w zakresie obiektów energetyki jądrowej w Polsce z pięcioma poprawkami. Umożliwi to przyspieszenie realizacji strategicznych dla bezpieczeństwa energetycznego projektów, zmniejszy ryzyko po stronie inwestorów.

## Eurostat: Produkcja przemysłowa w Polsce wzrosła w listopadzie
 - [https://forsal.pl/biznes/przemysl/artykuly/8634456,produkcja-przemyslowa-w-polsce-dane.html](https://forsal.pl/biznes/przemysl/artykuly/8634456,produkcja-przemyslowa-w-polsce-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:36:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NiQktkuTURBXy83ZjYzNjIxYS04MmZmLTRiY2QtYmQ1NS00NzMwZTMzZDExMzMuanBlZ5GTBc0BHcyg" />Produkcja przemysłowa w Polsce wzrosła o 4,6% r/r w listopadzie 2022 r., podał unijny urząd statystyczny Eurostat. W ujęciu miesięcznym, w Polsce produkcja wzrosła o 1,3%.

## Wywiad wojskowy: Rosja dąży do sformowania dwumilionowej armii
 - [https://forsal.pl/swiat/rosja/artykuly/8634448,rosja-armia-wywiad-wojskowy.html](https://forsal.pl/swiat/rosja/artykuly/8634448,rosja-armia-wywiad-wojskowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:31:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VakktkuTURBXy80NTQ4Nzc4Yi04MTVhLTQ1ZGEtYmYwOS01MmE3ODk0YmE1Y2MuanBlZ5GTBc0BHcyg" />Działania mobilizacyjne Rosji świadczą, że dąży ona do sformowania dwumilionowej armii – ocenił w piątek Główny Zarząd Wywiadu Ministerstwa Obrony Ukrainy (HUR). W ramach nowej fali mobilizacji do wojska może trafić 500 tysięcy osób – ostrzegł wywiad.

## Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym
 - [https://forsal.pl/gospodarka/prawo/artykuly/8634427,sad-najwyzszy-nowelizacja-ustawy.html](https://forsal.pl/gospodarka/prawo/artykuly/8634427,sad-najwyzszy-nowelizacja-ustawy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 10:11:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LG0ktkuTURBXy85ZmMxZmIwNi0yM2NiLTRjNTUtYWQyYS1lOGZiNWMwNmJmNmYuanBlZ5GTBc0BHcyg" />Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym w dniu 13 stycznia 2022 roku.

## Bon turystyczny. Do kiedy jest ważny?
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8634403,bon-turystyczny-do-kiedy-jest-wazny-ferie-zimowe.html](https://forsal.pl/lifestyle/turystyka/artykuly/8634403,bon-turystyczny-do-kiedy-jest-wazny-ferie-zimowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:44:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/I2iktkuTURBXy85MTE1YmI4NS01ZGVlLTQ2OGUtYWI1YS02MjUzOWRmNWI4MDEuanBlZ5GTBc0BHcyg" />Dotychczas nie aktywowano, nie użyto, bądź użyto jedynie częściowo ok. 1,7 mln bonów turystycznych. Zgodnie z obowiązującymi przepisami można z nich skorzystać jedynie do 31 marca br., przypomina Zakład Ubezpieczeń Społecznych (ZUS).

## Inflacja na Węgrzech. Jest kolejny rekord
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8634398,inflacja-na-wegrzech-rekord.html](https://forsal.pl/gospodarka/inflacja/artykuly/8634398,inflacja-na-wegrzech-rekord.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:32:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HG4ktkuTURBXy81YmJmMzBkYy1jODMwLTRjNTMtODNlZS1jMjMxM2IzZjhhMzcuanBlZ5GTBc0BHcyg" />Podczas gdy w wielu krajach europejskich obserwuje się spadek inflacji w ostatnim czasie, na Węgrzech odnotowano kolejny rekord. Według danych węgierskiego Głównego Urzędu Statystycznego (KSH) średnioroczna inflacja w 2022 r. była najwyższa od 25 lat.

## Kowalczyk: Będą regulacje ograniczające ceny nawozów
 - [https://forsal.pl/biznes/rolnictwo/artykuly/8634397,ceny-nawozow-regulacje-ograniczajace.html](https://forsal.pl/biznes/rolnictwo/artykuly/8634397,ceny-nawozow-regulacje-ograniczajace.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:28:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/b8kktkuTURBXy9jNzJiNmNmZC03NzE3LTRlY2YtOTc3ZS01NDA3NDlkM2U0MjguanBlZ5GTBc0BHcyg" />Będą regulacje ograniczające ceny nawozów, tak by utrzymać je na akceptowalnym poziomie - poinformował w piątek wicepremier, minister rolnictwa i rozwoju wsi Henryk Kowalczyk. Dodał, że dwa tygodnie powinny pojawić się rozwiązania w tej sprawie.

## Synektik miał szacunkowo 130 mln zł przychodów w I kw. r.fin. 2022/2023, wzrost o 267 proc. r/r
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8634389,synektik-mial-szacunkowo-130-mln-zl-przychodow-w-i-kw-rfin-20222023-wzrost-o-267-proc-rr.html](https://forsal.pl/biznes/aktualnosci/artykuly/8634389,synektik-mial-szacunkowo-130-mln-zl-przychodow-w-i-kw-rfin-20222023-wzrost-o-267-proc-rr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:18:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />Synektik odnotował szacunkowo 130 mln zł przychodów w I kw. roku finansowego 2022/2023 (październik-grudzień 2022), co oznacza wzrost o 267% r/r, podała spółka. Spektakularny wzrost przychodów to zasługa dynamicznego rozwoju segmentu dostaw sprzętu oraz usług, napędzanego przez sprzedaż innowacyjnych systemów do terapii.

## Inflacja w grudniu. GUS podał ostateczne dane
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8634385,inflacja-w-grudniu-2022-roku-dane-ostateczne.html](https://forsal.pl/gospodarka/inflacja/artykuly/8634385,inflacja-w-grudniu-2022-roku-dane-ostateczne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:00:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/08-ktkuTURBXy8yZjI2YTc0Mi04ZDA3LTQ1ZjktYWRhMS1kMGE5ODBkMDIzYjUuanBlZ5GTBc0BHcyg" />Główny Urząd Statystyczny podał ostateczne dane ws. inflacji w grudniu 2022 r. O ile wzrosły ceny towarów i usług konsumpcyjnych?

## Ferie 2023. Ile zapłacimy w tym roku? [CENY NOCLEGÓW I SKIPASSÓW]
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8634376,ferie-2023-ceny-skipassow-ceny-noclegow.html](https://forsal.pl/lifestyle/turystyka/artykuly/8634376,ferie-2023-ceny-skipassow-ceny-noclegow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:00:28+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cN7ktkuTURBXy85N2UwYWI5Ni1iZTFlLTQ1MzItYTdjMS0zZGU0OTJkMzY4NTcuanBlZ5GTBc0BHcyg" />Ruszają ferie 2023. Jak w tym roku kształtują się ceny noclegów w turystycznych miejscowościach, ile kosztują karnety narciarskie i jak można ciekawie spędzić na tzw. city breakach w dużych miastach? Podpowiadamy!

## Ferie 2023: Polska jedzie w góry
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8634376,ferie-2023-polska-jedzie-w-gory.html](https://forsal.pl/lifestyle/turystyka/artykuly/8634376,ferie-2023-polska-jedzie-w-gory.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 09:00:28+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cN7ktkuTURBXy85N2UwYWI5Ni1iZTFlLTQ1MzItYTdjMS0zZGU0OTJkMzY4NTcuanBlZ5GTBc0BHcyg" />Zima w tym roku spłatała branży turystycznej brzydkiego psikusa. W całej Polsce jest ciepło, a śnieg można znaleźć tylko w górach. Oto kilka propozycji jak spędzić tegoroczną zimową przerwę.

## Moskwa: Rząd zamierza przedstawić dodatkowe przepisy, chroniące odbiorców ciepła
 - [https://forsal.pl/biznes/energetyka/artykuly/8634370,odbiorcy-ciepla-dodatkowe-przepisy-anna-moskwa.html](https://forsal.pl/biznes/energetyka/artykuly/8634370,odbiorcy-ciepla-dodatkowe-przepisy-anna-moskwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 08:52:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MJFktkuTURBXy85YmM5YzE2Zi0wY2RmLTQ3OGItODQ5MS1lMjZmZTEzM2VlNzQuanBlZ5GTBc0BHcyg" />Rząd planuje w najbliższym czasie przedstawić dodatkowe przepisy, chroniące odbiorców ciepła, poinformowała minister klimatu i środowiska Anna Moskwa.

## LGBT kontra TVP. Przełomowe orzeczenie TSUE
 - [https://forsal.pl/gospodarka/prawo/artykuly/8634362,lgbt-kontra-tvp-przelomowe-orzeczenie-tsue.html](https://forsal.pl/gospodarka/prawo/artykuly/8634362,lgbt-kontra-tvp-przelomowe-orzeczenie-tsue.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 08:38:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7Q2ktkuTURBXy9jM2FmZjU4Ni00YjI1LTQxNTQtOWQyZS1iZTAzNTIzMmNjMWMuanBlZ5GTBc0BHcyg" />Zerwanie współpracy z samozatrudnionym kontrahentem tylko z powodu jego orientacji seksualnej jest sprzeczne z prawem wspólnotowym i prawo polskie także powinno traktować takie zachowanie jako nierówne traktowanie w zatrudnieniu – orzekł TSUE odpowiadając na pytanie prejudycjalne w sprawie jaką wytoczył telewizji publicznej jej były współpracownik.

## Służby będą mogły korzystać z danych z komunikatorów? Jest komentarz rzecznika rządu
 - [https://forsal.pl/gospodarka/polityka/artykuly/8634357,sluzby-beda-mogly-korzystac-z-danych-z-komunikatorow.html](https://forsal.pl/gospodarka/polityka/artykuly/8634357,sluzby-beda-mogly-korzystac-z-danych-z-komunikatorow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 08:33:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2ydktkuTURBXy81NTA0MGEyZS0zODVhLTRjNDQtYmUzNi0xM2JhMDZmODc4YTkuanBlZ5GTBc0BHcyg" />To aktualizacja uprawnień, jeżeli chodzi o funkcjonowanie służb państwowych w XXI w.; służby będą mogły korzystać z danych z komunikatorów tylko w sytuacjach, gdy wynika to z przepisów prawa i z kontrolą sądów - mówił rzecznik rządu Piotr Müller pytany o zmiany w Prawie komunikacji elektronicznej.

## Konfiskata majątków osób krytykujących wojnę? W Rosji pojawiła się propozycja ws. kary
 - [https://forsal.pl/swiat/rosja/artykuly/8634348,konfiskata-majatkow-osob-krytykujacych-wojne.html](https://forsal.pl/swiat/rosja/artykuly/8634348,konfiskata-majatkow-osob-krytykujacych-wojne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 08:14:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LjHktkuTURBXy9hZjNmZTViNS0yYzYyLTQ3MWUtODNiMS1iNWIzMDUyZjE2YTYuanBlZ5GTBc0BHcyg" />Przewodniczący Dumy Państwowej (niższej izby rosyjskiego parlamentu) Wiaczesław Wołodin proponuje konfiskatę majątków osób krytykujących wojnę oraz tych, którzy wyjechali za granicę; uważa, że dotychczasowe ustawodawstwo przewiduje niedostateczne kary za &quot;dyskredytację&quot; Rosji i działań jej wojska - poinformowała w piątek agencja Reutera.

## Rafako: Propozycja Taurona o "zamrożeniu" kar nie znosi przesłanek dla wniosku o upadłość
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8634338,rafako-propozycja-taurona-o-zamrozeniu-kar.html](https://forsal.pl/biznes/aktualnosci/artykuly/8634338,rafako-propozycja-taurona-o-zamrozeniu-kar.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:56:06+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u2UktkuTURBXy85MWU5MTliZi0wMDgzLTQ3NjEtYTEyNS1kM2IzY2I5ZmE0YzIuanBlZ5GTBc0BHcyg" />Rafako zwraca uwagę, że proponowane przez Tauron &quot;zamrożenie&quot; noty ws. płatności 1,31 mld zł kar i odszkodowań związanych z realizacją bloku energetycznego 910 MW w Jaworznie nie jest zdefiniowane prawnie, a ponadto nie niweluje skutków wystawionej noty, podała spółka. Rafako jest natomiast gotowe do dalszych mediacji.

## Ekspert: Korumpowanie ważnych europosłów opłaca się, bo mają oni wpływ na unijne prawo
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8634331,ekspert-korumpowanie-waznych-europoslow-oplaca-sie-bo-maja-oni-wplyw-na-unijne-prawo.html](https://forsal.pl/swiat/unia-europejska/artykuly/8634331,ekspert-korumpowanie-waznych-europoslow-oplaca-sie-bo-maja-oni-wplyw-na-unijne-prawo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:42:11+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cKYktkuTURBXy9kNmM0MjM1Mi0wOTU0LTQxYzQtYWE0NS01NTI0ZDY5YTFlZTkuanBlZ5GTBc0BHcyg" />Firmom i państwom opłaca się korumpowanie wpływowych eurodeputowanych; mają oni wpływ na unijne prawo, a za jego pośrednictwem na rynek o wielkości prawie 500 mln osób - mówi w rozmowie z PAP dyrektor brytyjskiego think tanku analizującego politykę europejską - The Bruges Group - Robert Oulds, komentując skandal korupcyjny w Parlamencie Europejskim.

## O ile spadło zużycie gazu w Polsce w 2022 r. ? [DANE]
 - [https://forsal.pl/biznes/energetyka/artykuly/8634327,zuzycie-gazu-w-polsce-w-2022-rok.html](https://forsal.pl/biznes/energetyka/artykuly/8634327,zuzycie-gazu-w-polsce-w-2022-rok.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:39:06+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/O3fktkuTURBXy84YTllZDM2YS1kYTE4LTRkYmMtOGYyNC1jOWE4ODM2N2FhMDkuanBlZ5GTBc0BHcyg" />Według wstępnych szacunków zużycie gazu ziemnego w 2022 r. mogło spaść o ok. 16-17 proc. względem roku poprzedniego – przekazał PAP resort klimatu i środowiska. Podkreślono, że system jest przygotowany na najmroźniejszą zimę, a ryzyka wprowadzenia ograniczeń w poborze gazu na dziś nie ma.

## Włochy oddadzą do dyspozycji Ukrainy porty w Trieście i Weronie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634325,wlochy-oddadza-do-dyspozycji-ukrainy-porty-w-triescie-i-weronie.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634325,wlochy-oddadza-do-dyspozycji-ukrainy-porty-w-triescie-i-weronie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:35:17+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gE6ktkuTURBXy8xNjdiMjU4Zi1iN2E5LTQ0OTEtODk3Yy05NDEwYzNlNGM5MzIuanBlZ5GTBc0BHcyg" />Włochy oddadzą do dyspozycji Ukrainy swoje porty w Trieście i Wenecji; w Rzymie w marcu odbędzie się konferencja na temat odbudowy tego kraju - o takich ustaleniach poinformował włoski minister przedsiębiorczości Adolfo Urso po wizycie w Kijowie.

## Spadek cen żywności w 2023 r.? 63 proc. Polaków nie wierzy w to [BADANIE]
 - [https://forsal.pl/gospodarka/inflacja/artykuly/8634323,spadek-cen-zywnosci-w-2023-r-63-proc-polakow-nie-wierzy-w-to-badanie.html](https://forsal.pl/gospodarka/inflacja/artykuly/8634323,spadek-cen-zywnosci-w-2023-r-63-proc-polakow-nie-wierzy-w-to-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:32:33+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Wi0ktkuTURBXy8xOWY1ODhiZS00NDM5LTRhMTEtODkzMi1kNWRmYmY3YTcxZTkuanBlZ5GTBc0BHcyg" />Ponad 63 proc. Polaków nie wierzy, że w tym roku dojdzie do spadku cen żywności w sklepach. Przeszło 36 proc. ankietowanych w ogóle nie uważa, aby możliwy był spadek cen kiedykolwiek - wynika z przekazanego PAP badania.

## Mitchell: Ameryka powinna pomóc Ukrainie szybko pokonać Rosję i skupić się na Chinach
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8634319,mitchell-ameryka-powinna-pomoc-ukrainie-szybko-pokonac-rosje-i-skupic-sie-na-chinach.html](https://forsal.pl/swiat/aktualnosci/artykuly/8634319,mitchell-ameryka-powinna-pomoc-ukrainie-szybko-pokonac-rosje-i-skupic-sie-na-chinach.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:31:39+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AxqktkuTURBXy8zYzIwYzJhMi1iNjQxLTRmYzItYjNmOC1jMWZjOGZiYTNmYjQuanBlZ5GTBc0BHcyg" />USA powinny skupić się na zagrożeniu płynącym z Chin, ale właśnie dlatego w naszym interesie leży jak najszybsze pokonanie Rosji - mówi PAP były asystent zastępcy sekretarza stanu USA ds. europejskich Wess Mitchell. Jak dodaje, Chiny jednak w długim terminie mogą skorzystać na efektach wojny.

## W 30 lat polski eksport wzrósł ponad 25-krotnie. Jesteśmy blisko wejścia do światowego TOP-20
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8634318,paih-polski-eksport-wzrosl-ponad-25-krotnie-top-20.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8634318,paih-polski-eksport-wzrosl-ponad-25-krotnie-top-20.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:27:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-PUktkuTURBXy9hMzczMTIxMy01NTY2LTQzZWUtYjI3MS01YTQ2NjkxMjk4MmYuanBlZ5GTBc0BHcyg" />W ciągu ostatnich trzech dekad polski eksport wzrósł ponad dwudziestopięciokrotnie - poinformował Łukasz Grabowski z Polskiej Agencji Inwestycji i Handlu. Wartość eksportu styczeń-październik 2022 r. wyniosła prawie 285 mld euro, zbliżając się do psychologicznej granicy 300 mld euro - dodał.

## Osoby suplementujące witaminę D rzadziej chorują na czerniaka skóry [BADANIA]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8634315,osoby-suplementujace-witamine-d-rzadziej-choruja-na-czerniaka-skory-badania.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8634315,osoby-suplementujace-witamine-d-rzadziej-choruja-na-czerniaka-skory-badania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:22:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5TGktkuTURBXy8xOWFhODBiMS02ZjllLTQ0ZjYtOTQ0NS03NmJmYThkNWE1NWIuanBlZ5GTBc0BHcyg" />Wśród osób zażywających regularnie suplementy z witaminą D obserwuje się mniej przypadków czerniaka skóry niż wśród tych, którzy nie przyjmują tej witaminy – wynika z fińskiego badania, które publikuje czasopismo &quot;Melanoma Research”.

## Wcześniejsza emerytura i samotność mogą przyspieszać rozwój demencji [BADANIA]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8634311,wczesniejsza-emerytura-i-samotnosc-moga-przyspieszac-rozwoj-demencji-badania.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8634311,wczesniejsza-emerytura-i-samotnosc-moga-przyspieszac-rozwoj-demencji-badania.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:21:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/9NektkuTURBXy8xZDdlYTA4Yy1lMjI2LTQ1NGItYmM2OC05ZWJhNzNkZjYzZGMuanBlZ5GTBc0BHcyg" />Wcześniejsze przechodzenie na emeryturę, jak również izolacja społeczna mogą przyspieszać zaburzenia poznawcze i rozwój demencji w starszym wieku – wynika z dwóch amerykańskich badań.

## Duże osiągnięcie w USA. Wskaźnik zgonów z powodu raka spadł o jedną trzecią
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8634310,duze-osiagniecie-w-usa-wskaznik-zgonow-z-powodu-raka-spadl-o-jedna-trzecia.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8634310,duze-osiagniecie-w-usa-wskaznik-zgonow-z-powodu-raka-spadl-o-jedna-trzecia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:17:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c4mktkuTURBXy84YmEzODAwOC04MzU1LTQ4M2EtOGY0Mi1hYjc0MjI2ZjQwNDAuanBlZ5GTBc0BHcyg" />W ciągu ostatnich trzech dekad w USA spadł wskaźnik śmiertelności z powodu raka o jedną trzecią. Eksperci wyrażają jednak niepokój z powodu wzrostu liczby rozpoznań zaawansowanego raka prostaty.

## Złoty traci do euro i dolara, umacnia się względem franka szwajcarskiego
 - [https://forsal.pl/finanse/waluty/artykuly/8634305,zloty-kurs-walut-euro-dolar-frank.html](https://forsal.pl/finanse/waluty/artykuly/8634305,zloty-kurs-walut-euro-dolar-frank.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:15:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4cyktkuTURBXy83NTNhZjczNy00YzNmLTRhMzctYmM1My02MGQyMzgwYTM3NTcuanBlZ5GTBc0BHcyg" />W piątek rano złoty osłabia się względem euro o ok. 0,14 proc. - wspólna waluta wyceniana jest na blisko 4,70 zł. Względem dolara złoty słabnie o 0,18 proc., umacnia się natomiast w stosunku do franka szwajcarskiego o 0,03 proc.

## Dlaczego nie powiodła się misja kosmiczna Virgin Orbit? Firma zapowiada kolejną próbę
 - [https://forsal.pl/lifestyle/technologie/artykuly/8634296,dlaczego-nie-powiodla-sie-misja-kosmiczna-virgin-orbit-firma-zapowiada-kolejna-probe.html](https://forsal.pl/lifestyle/technologie/artykuly/8634296,dlaczego-nie-powiodla-sie-misja-kosmiczna-virgin-orbit-firma-zapowiada-kolejna-probe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:08:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/36dktkuTURBXy9hMzE1YjgzZS0zYTUwLTQ0ZGUtYTkwOS1hOGU0Y2Y2NWY4YWIuanBlZ5GTBc0BHcyg" />Firma Virgin Orbit zapewniła w czwartek, że podejmie kolejną próbę wysłania rakiety w przestrzeń kosmiczną z portu kosmicznego w Kornwalii i przekazała wstępne ustalenia na temat przyczyn niepowodzenia pierwszej misji, która miała miejsce w poniedziałek.

## Wall Street w górę. Pomogły dane o inflacji
 - [https://forsal.pl/finanse/gielda/artykuly/8634295,wall-street-w-gore-pomogly-dane-o-inflacji.html](https://forsal.pl/finanse/gielda/artykuly/8634295,wall-street-w-gore-pomogly-dane-o-inflacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:06:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6sfktkuTURBXy9hMzMzMGYyNy1kNWI5LTQ4MTYtYmZiYi1lOWUzMjFlOGQzMWMuanBlZ5GTBc0BHcyg" />Czwartkowa sesja na Wall Street zakończyła się wzrostami głównych indeksów, a Nasdaq zanotował piąty zwyżkowy dzień z rzędu. W centrum uwagi jest rozpoczynający się w piątek sezon publikacji wyników przez amerykańskie spółki za czwarty kwartał 2022 roku. Na pierwszy ogień pójdą największe banki.

## Zełenski chce utworzenia hubów żywnościowych w Afryce
 - [https://forsal.pl/swiat/ukraina/artykuly/8634293,zelenski-chce-utworzenia-hubow-zywnosciowych-w-afryce.html](https://forsal.pl/swiat/ukraina/artykuly/8634293,zelenski-chce-utworzenia-hubow-zywnosciowych-w-afryce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:04:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yrYktkuTURBXy83NmNjOTU3MS0wYTFkLTQzODItOWYxNi0zZmRiNTY4ODA3MmYuanBlZ5GTBc0BHcyg" />Naszą bardzo ważną inicjatywą jest utworzenie hubów żywnościowych w Afryce; mieszkańcy krajów tego kontynentu już zrozumieli, że bezpieczeństwo różnych państw bezpośrednio zależy od eksportu ukraińskiej żywności - oznajmił w czwartek w wieczornym wystąpieniu na Facebooku prezydent Ukrainy Wołodymyr Zełenski.

## Irlandia wprowadza ostrzeżenia na winie jak na papierosach. Włoscy ministrowie: To absurdalne
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8634292,irlandia-wprowadza-ostrzezenia-na-winie-jak-na-papierosach-wloscy-ministrowie-to-absurdalne.html](https://forsal.pl/swiat/unia-europejska/artykuly/8634292,irlandia-wprowadza-ostrzezenia-na-winie-jak-na-papierosach-wloscy-ministrowie-to-absurdalne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 07:01:46+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w0ektkuTURBXy8xYzJlZjk1Zi1mNzliLTRjM2EtODAzMC1kMmRhN2QyMzJhNzEuanBlZ5GTBc0BHcyg" />Włoscy ministrowie: spraw zagranicznych - Antonio Tajani i rolnictwa - Francesco Lollobrigida, w liście do komisarza UE ds. rynku wewnętrznego Thierry Bretona poprosili o interwencję w związku z decyzją władz Irlandii, które postanowiły, że na butelkach z winem, piwem i likierem widnieć będzie napis: &quot;Spożycie alkoholu powoduje choroby wątroby&quot;. Będzie też ostrzeżenie o związku między piciem alkoholu i nowotworami.

## Wielki strajk na brytyjskich uniwersytetach i w służbie cywilnej
 - [https://forsal.pl/praca/aktualnosci/artykuly/8634286,wielki-strajk-na-brytyjskich-uniwersytetach-i-w-sluzbie-cywilnej.html](https://forsal.pl/praca/aktualnosci/artykuly/8634286,wielki-strajk-na-brytyjskich-uniwersytetach-i-w-sluzbie-cywilnej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 06:56:50+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m6KktkuTURBXy8wOThiNDJhNy1hZDZiLTQ2MTctOWU4OS1iOTg1NzFhMzEyYmMuanBlZ5GTBc0BHcyg" />Dwa kolejne duże strajki zapowiedziały w czwartek brytyjskie związki zawodowe - aż przez 18 dni strajkować będzie ponad 70 tys. pracowników na 150 uniwersytetach, zaś jednodniowy protest przeprowadzi ok. 100 tys. pracowników służby cywilnej.

## Wysyłanie czołgów na Ukrainę. Pentagon: Popieramy
 - [https://forsal.pl/swiat/usa/artykuly/8634284,wysylanie-czolgow-na-ukraine-pentagon-popieramy.html](https://forsal.pl/swiat/usa/artykuly/8634284,wysylanie-czolgow-na-ukraine-pentagon-popieramy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 06:52:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zL-ktkuTURBXy9iYjU3NmIwYy0xZTc1LTQzNDAtOTJjOS0zYmFhMzBkZDVlNzAuanBlZ5GTBc0BHcyg" />Absolutnie popieramy wysyłanie jakichkolwiek zdolności wojskowych Ukrainie, w tym czołgów - oświadczył w czwartek rzecznik Pentagonu gen. Pat Ryder. Jednocześnie dodał, że są to suwerenne decyzje państw i należy brać w tym pod uwagę kwestie m.in. logistyki.

## "Najbardziej słoneczne" miasta. Jeden kraj w Europie ma ich najwięcej
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8633367,gdzie-jest-najwiecej-slonca-europa-miasta-sloneczne-miejsca.html](https://forsal.pl/lifestyle/turystyka/artykuly/8633367,gdzie-jest-najwiecej-slonca-europa-miasta-sloneczne-miejsca.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:50:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UXmktkuTURBXy9hNzMyOGRiMS04NTQwLTQyNWYtYmU2My0xOWI4Njk2ZDVhZGMuanBlZ5GTBc0BHcyg" />W Hiszpanii jest najwięcej „najbardziej słonecznych” miast w Europie według raportu na podstawie danych z World Weather Online, opublikowanego przez Holidu.

## Bileciki do kontroli. Państwowy prąd kopie państwową kolej, a kolej nas [FELIETON]
 - [https://forsal.pl/transport/kolej/artykuly/8633980,pkp-intercity-podwyzki-biletow-felieton-zbigniew-bartus.html](https://forsal.pl/transport/kolej/artykuly/8633980,pkp-intercity-podwyzki-biletow-felieton-zbigniew-bartus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/W3SktkuTURBXy9iODNmNTZlOS1mMDM1LTRmYTItOWJiOC05YjgyNzg3OGRkNTEuanBlZ5GTBc0BHcyg" />Chcę wierzyć, że nasza państwowa kolej jako jedyna w Europie wywindowała właśnie ceny biletów po to, by mieć za co równać do niemieckiej. Chcę, ale nie wierzę - pisze w felietonie Zbigniew Bartuś, publicysta Forsal.pl.

## Niebezpieczne uzależnienie od Chin? Smok może potraktować to jako "broń"
 - [https://forsal.pl/swiat/chiny/artykuly/8633986,chiny-handel-europa-polska-niemcy-zagrozenie-przyszlosc.html](https://forsal.pl/swiat/chiny/artykuly/8633986,chiny-handel-europa-polska-niemcy-zagrozenie-przyszlosc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jzbktkuTURBXy8wZjNmNzZiZi00OTg0LTQ3OGItOTViZS1mMzE0M2VjNDVkZjguanBlZ5GTBc0BHcyg" />Lekarstwa, urządzenia, surowce… Kraje w Europie sprowadzają wiele rzeczy z Państwa Środka. Jakie ryzyko dla Starego Kontynentu stwarza to uzależnienie od władz w Pekinie?

## Nowy świat wykuwa się w Ukrainie. Losy wojny przesądzą o przyszłym porządku międzynarodowym
 - [https://forsal.pl/swiat/ukraina/artykuly/8632696,wojna-w-ukrainie-nowy-porzadek-wykuwa-sie-w-ukrainie.html](https://forsal.pl/swiat/ukraina/artykuly/8632696,wojna-w-ukrainie-nowy-porzadek-wykuwa-sie-w-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KF-ktkuTURBXy8wZTc5ZjUzMy1iZjBkLTQ1ZDYtYjMxNy01ZDkzMjFlMmE5ZGIuanBlZ5GTBc0BHcyg" />Ukraina, dzięki swojemu położeniu i zasobom, ma kluczowe znaczenie strategiczne. Losy wojny w Ukrainie wpłyną na kształt nowego światowego porządku – pisze w opinii dla agencji Bloomberg prof. Hal Brands.

## Energetyczny twist w Europie. Polska stała się eksporterem energii netto, Francja musiała importować [MAPA]
 - [https://forsal.pl/biznes/energetyka/artykuly/8633792,energetyczny-twist-szwecja-stala-sie-najwiekszym-eksporterem-pradu-w-europie.html](https://forsal.pl/biznes/energetyka/artykuly/8633792,energetyczny-twist-szwecja-stala-sie-najwiekszym-eksporterem-pradu-w-europie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xmOktktTURBXy8yN2ZkYzVmYS02OTdkLTRiZjctOWU1Zi0wZjM3Y2YwOTNhYjgucG5nkZMFzQEdzKA" />Kryzys energetyczny w 2022 roku namieszał w obrocie energią elektryczną na Starym Kontynencie. Efekt? Szwecja stała się największym eksporterem prądu w Europie, a posiadająca najwięcej reaktorów jądrowych Francja musiała importować prąd.

## Konsumenci spodziewają się już niższego wzrostu inflacji. Są nowe dane EBC
 - [https://forsal.pl/gospodarka/artykuly/8633841,ebc-oczekiwania-inflacyjne-konsumentow-spadly.html](https://forsal.pl/gospodarka/artykuly/8633841,ebc-oczekiwania-inflacyjne-konsumentow-spadly.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y5VktkuTURBXy9lZjhhNjk5MC1mMGFmLTQxZGUtOGE0ZS0yZjRhMjNiYTQxNTEuanBlZ5GTBc0BHcyg" />Oczekiwania konsumentów dotyczące poziomu inflacji w ciągu najbliższych 12 miesięcy spadły po raz pierwszy od maja 2022 r., wynika z comiesięcznego badania Europejskiego Banku Centralnego.

## Jak wychowywać dziecko, by osiągnęło sukces? Oto najskuteczniejszy styl
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8633739,jak-wychowywac-dzieci-osiagajace-sukcesy.html](https://forsal.pl/lifestyle/psychologia/artykuly/8633739,jak-wychowywac-dzieci-osiagajace-sukcesy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-13 05:30:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CbLktkuTURBXy9hMTUwN2ZmNS00YzZjLTQ1MDAtOTQ4OS0xNzQ1MWFmNDlkOTAuanBlZ5GTBc0BHcyg" />Jaki jest najbardziej skuteczny styl wychowywania dzieci pod kątem osiągania przez nie sukcesów? Odpowiedzią jest tzw. rodzicielstwo szacunku – pisze CNBC.
