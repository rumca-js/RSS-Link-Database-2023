# Source wiadomości.gazeta.pl, Source URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, Source language: pl-PL

## Kielce. Zmarła pacjentka, u której przeprowadzono wcześniej cesarskie cięcie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29357240,kielce-zmarla-pacjentka-u-ktorej-przeprowadzono-cesarskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29357240,kielce-zmarla-pacjentka-u-ktorej-przeprowadzono-cesarskie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 21:44:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dc/ff/1b/z29357276M,Kielce--Zmarla-pacjentka--u-ktorej-przeprowadzono-.jpg" vspace="2" />W Wigilię w szpitalu w Kielcach zmarła kobieta, u której wcześniej przeprowadzono cesarskie cięcie. 41-latka urodziła trzecie dziecko. Prokuratura Regionalna w Krakowie prowadzi śledztwo w sprawie zgonu.

## Zakopane. Awantura o ogromny mur tuż przy domach mieszkańców. "Nie możemy się nic dowiedzieć" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356861,mur-w-zakopanem-tuz-przy-domach-mieszkancow-zabrali-nam-swiatlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356861,mur-w-zakopanem-tuz-przy-domach-mieszkancow-zabrali-nam-swiatlo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 20:35:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/aa/ff/1b/z29356970M,Mur-w-Zakopanem-tuz-przy-domach-mieszkancow---Zabr.jpg" vspace="2" />- Mur powstał z dnia na dzień. Zabrali nam widok z okna i światło dzienne - mówi Monika Saj, mieszkanka Zakopanego w rozmowie z Gazeta.pl. Między innymi przed jej domem powstaje ogromny betonowy mur.

## Wypadek radiowozu z nastolatkami. Są nowe ustalenia. "Policjant nie chce złożyć wyjaśnień"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356735,wypadek-radiowozu-z-nastolatkami-sa-nowe-ustalenia-policjant.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356735,wypadek-radiowozu-z-nastolatkami-sa-nowe-ustalenia-policjant.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 19:26:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4e/fb/1b/z29343566M,Wypadek-radiowozu-pod-Dawidami-Bankowymi.jpg" vspace="2" />Policjant, który spowodował wypadek z nastolatkami w Pruszkowie, nie chce złożyć wyjaśnień - przekazała posłanka Kinga Gajewska. Jak dodała, funkcjonariusz wciąż przebywa na zwolnieniu lekarskim.

## Wypadek radiowozu w Dawidach Bankowych. Giertych reprezentuje drugą nastolatkę. Zapytaliśmy o jej relację
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355307,wypadek-radiowozu-w-dawidach-bankowych-giertych-reprezentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355307,wypadek-radiowozu-w-dawidach-bankowych-giertych-reprezentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 18:49:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/f1/1a/z28250890M.jpg" vspace="2" />Roman Giertych reprezentuje także drugą nastolatkę, która znajdowała się w radiowozie w chwili wypadku niedaleko Piaseczna - dowiedział się portal Gazeta.pl. Prawnik potwierdził, że w zakresie zeznań nastolatek "nie ma konfliktu".

## Po Sądzie Najwyższym - wiatraki. Sejm sięga po kolejnym "kamień milowy". Bez niego nie będzie KPO
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356279,po-sadzie-najwyzszym-wiatraki-sejm-siega-po-kolejnym-kamien.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356279,po-sadzie-najwyzszym-wiatraki-sejm-siega-po-kolejnym-kamien.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 17:14:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3b/f8/1b/z29328699M,Wiatraki.jpg" vspace="2" />Sejm przyjął nowelizację ustawy o Sądzie Najwyższym i już zabrał się do pracy nad kolejnym projektem, który ma wypełnić warunki do wypłaty pieniędzy z Krajowego Planu Odbudowy (KPO) postawione przez Komisję Europejską. To tzw. ustawa wiatrakowa. Bez zapisów z projektu, który do tej pory był w sejmowej "zamrażalce", Polska nie dostanie pieniędzy z Brukseli.

## Zawracał w tunelu na Zakopiance, został zatrzymany. "O czymś sobie przypomniał i musiał zawrócić"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356290,zawracal-na-zakopiance-zostal-zatrzymany-o-czyms-sobie-przypomnial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356290,zawracal-na-zakopiance-zostal-zatrzymany-o-czyms-sobie-przypomnial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 16:30:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/ff/1b/z29356375M,Zawracal-na-Zakopiance--zostal-zatrzymany.jpg" vspace="2" />Kierowca, który zawrócił w tunelu na Zakopiance i zaczął jechać pod prąd, został zatrzymany. Jak tłumaczył, zrobił to, bo "o czymś sobie przypomniał i musiał zawrócić do domu". Mężczyzna popełnił kilka naruszeń - straci prawo jazdy, zapłaci też spory mandat.

## Spowodował kolizję i uciekł, miał 2,5 promila alkoholu. Okazało się, że to funkcjonariusz SOP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356223,spowodowal-kolizje-i-uciekl-mial-2-5-promila-alkoholu-okazalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356223,spowodowal-kolizje-i-uciekl-mial-2-5-promila-alkoholu-okazalo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 15:37:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/85/16/z23616213M,SOP---Zdjecie-ilustracyjne.jpg" vspace="2" />Po krótkim pościgu stołeczni policjanci zatrzymali funkcjonariusza Służby Ochrony Państwa - podaje tvn24.pl. Komendant SOP nakazał wszcząć postępowanie dyscyplinarne wobec funkcjonariusza.

## Dolny Śląsk. Czołowe zderzenie osobówki ze śmieciarką. Nie żyją trzy osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356033,dolny-slask-czolowe-zderzenie-osobowki-ze-smieciarka-nie-zyja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29356033,dolny-slask-czolowe-zderzenie-osobowki-ze-smieciarka-nie-zyja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 15:10:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/ca/1b/z29142517M,karetka-pogotowia---zdjecie-ilustracyjne.jpg" vspace="2" />W województwie dolnośląskim doszło do czołowego zderzenia samochodu osobowego z ciężarówką służącą do wywozu śmieci. Zginęły trzy osoby.

## Ksiądz skrytykował Dudę i PiS. "Mieli 8 lat, aby to zmienić. Sojusz ołtarza z tronem stał się ważniejszy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355359,ksiadz-skrytykowal-dude-i-pis-mieli-8-lat-aby-to-zmienic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355359,ksiadz-skrytykowal-dude-i-pis-mieli-8-lat-aby-to-zmienic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 13:43:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/48/19/z26511318M,Ksiadz-Tadeusz-Isakowicz-Zaleski-.jpg" vspace="2" />Ksiądz Tadeusz Isakowicz-Zaleski odniósł się do sprawy ks. Stanisława P., który zgodnie z ustaleniami prokuratury, miał skrzywdzić co najmniej 95 dzieci i nieletnich. Zgodnie z polskim prawem osoby, które tuszowały te sprawę pozostają bezkarne - napisał dalej duchowny i dodał, że "Andrzej Duda i PiS mieli osiem lat, żeby to zmienić".

## Para współżyła przy 2-letnim dziecku. Psycholog: To trauma dla dziecka przez duże "T"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355031,para-wspolzyla-przy-2-letnim-dziecku-psycholog-to-trauma-przez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355031,para-wspolzyla-przy-2-letnim-dziecku-psycholog-to-trauma-przez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 13:42:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/db/54/1b/z28657627M,Dziecko---zdjecie-ilustracyjne.jpg" vspace="2" />Para współżyła w obecności swojego 2-letnego dziecka. Wszystko nagrywali i fotografowali. O konsekwencje takie zachowania dla dziecka zapytaliśmy psychologa dziecięcego Igora Wiśniewskiego. - Ze strony formalno-prawnej, jak i psychologicznej jest to narażenie dziecka na traumatyzację i wykorzystanie seksualne. Narażenie na ekspozycje treści o charakterze pornograficznym - stwierdził specjalista w rozmowie z Gazeta.pl.

## Pobiel. Ministrant wjechał w dom, w którym trwała kolęda. Sprawą zajmie się sąd rodzinny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355309,pobiel-ministrant-wjechal-w-dom-w-ktorym-trwala-koleda-sprawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355309,pobiel-ministrant-wjechal-w-dom-w-ktorym-trwala-koleda-sprawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 13:29:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/33/fe/1b/z29355571M,Ministrant-uderzyl-autem-w-dom.jpg" vspace="2" />Trwa wyjaśnianie okoliczności zdarzenia, do którego doszło w czwartek we wsi Pobiel w woj. dolnośląskim. 16-letni ministrant wjechał autem księdza w jeden z domów. Nastolatek został ranny, trafił do szpitala.

## Łomża. Policjant zgubił notatki służbowe z danymi wylegitymowanych osób. "Mogą na nas brać kredyty"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354593,policjant-zgubil-notatki-sluzbowe-z-danymi-osobowymi-legitymowanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354593,policjant-zgubil-notatki-sluzbowe-z-danymi-osobowymi-legitymowanych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 13:22:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/fe/1b/z29355316M,Emblemat-policji-z-Lomzy-.jpg" vspace="2" />Policjant z Łomży zgubił notatki służbowe, które zawierały szczegółowe dane legitymowanych osób. "Dostaliśmy od KMP Łomża pisma, że nasze dane z policji wyciekły i że mogą na nas brać kredyty" - pisze jeden z poszkodowanych mieszkańców. Co w zaistniałej sytuacji powinni zrobić poszkodowani?

## Samolot z reprezentacją leciał na Mistrzostwa Świata z eskortą F-16. Jest odpowiedź MON
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355063,samolot-polakow-lecial-na-mistrzostwa-swiata-z-eskorta-f-16.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29355063,samolot-polakow-lecial-na-mistrzostwa-swiata-z-eskorta-f-16.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 12:56:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/53/fe/1b/z29355347M,F-16---zdjecie-ilustracyjne.jpg" vspace="2" />Samolot z piłkarzami reprezentacji Polski lecący na mundial do Kataru był eskortowany do południowych granic naszego kraju przez wojskowe F-16. Sekretarz stanu w Ministerstwie Obrony Narodowej, Wojciech Skurkiewicz tłumaczył, że lot dwóch samolotów F-16 eskortujących samolot został zrealizowany z limitu nalotu szkoleniowego przydzielonego dla 2. Skrzydła Lotnictwa Taktycznego.

## Policjanci na strażackim wysięgniku. Rzecznik Praw Obywatelskich prosi o wyjaśnienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354743,policjanci-na-strazackim-wysiegniku-rzecznik-praw-obywatelskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354743,policjanci-na-strazackim-wysiegniku-rzecznik-praw-obywatelskich.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 11:56:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/fc/1b/z29344224M,Policjanci-za-oknem-na-wysiegniku.jpg" vspace="2" />Policjanci na strażackim wysięgniku zaglądali przez okno do wynajętego mieszkania. O wyjaśnienia w sprawie niecodziennej obserwacji prosi Rzecznik Praw Obywatelskich. "Takie działanie ingerowało w sferę praw i wolności obywatelskich, w tym w konstytucyjne prawo do ochrony życia prywatnego" - czytamy w komunikacie RPO.

## Andrzej Duda witany przez tłum we Lwowie. Ekspert komentuje: Było inaczej, niż się wydaje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354444,andrzej-duda-witany-przez-tlum-we-lwowie-ekspert-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354444,andrzej-duda-witany-przez-tlum-we-lwowie-ekspert-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 11:02:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bd/fe/1b/z29354685M,Andrzej-Duda-we-Lwowie.jpg" vspace="2" />W środę Andrzej Duda udał się do Lwowa, gdzie spotkał się z prezydentami Ukrainy i Litwy. Prezydent Polski spędził też czas w katedrze lwowskiej, przed którą pojawił się tłum Ukraińców. - Umiejscowienie ludzi, a także dziennikarzy, którym pozwolono filmować przebieg zdarzenia świadczy o tym, że raczej nie było to spontaniczne spotkanie - skomentował ekspert ds. bezpieczeństwa Marcin Samsel.

## Czwarta rocznica śmierci Pawła Adamowicza. "Wspomnienia pozostaną. Nikt z nas nie jest z kamienia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354133,4-rocznica-smierci-pawla-adamowicza-wspomnienia-pozostana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354133,4-rocznica-smierci-pawla-adamowicza-wspomnienia-pozostana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 10:58:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/93/a8/1a/z27954323M,Zamordowany-prezydent-Gdanska-Pawel-Adamowicz.jpg" vspace="2" />14 stycznia przypada czwarta rocznica śmierci prezydenta Gdańska Pawła Adamowicza. - Przez ponad rok starałem się nie chodzić do Bazyliki Mariackiej, w której jest urna z prochami. Jeszcze dwa lata temu reagowałem alergicznie na sygnał karetek - wspomina brat zmarłego Piotr Adamowicz w rozmowie z dziennikarzem Wirtualnej Polski.

## Grodzisk Mazowiecki: zakonnica z prokuratorskimi zarzutami. Miała znęcać się nad przedszkolakami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354138,grodzisk-mazowiecki-zakonnica-z-prokuratorskimi-zarzutami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29354138,grodzisk-mazowiecki-zakonnica-z-prokuratorskimi-zarzutami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 10:45:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/fe/1b/z29354506M,Zakonnica--Zdjecie-ilustracyjne.jpg" vspace="2" />Zakonnica pracująca w jednym z przedszkoli w Grodzisku Mazowieckim usłyszała prokuratorskie zarzuty dotyczące znęcania się nad dziećmi - informuje Onet.pl. Jak relacjonuje portal, siostra K. miała nie tylko obrażać dzieci, ale również bić je, drapać i popychać. Według ustaleń portalu Onet.pl mimo zarzutów zakonnica wciąż pracuje w przedszkolu.

## Ksiądz Woźnicki grzmi, bo prawie nikt nie zaprosił go na kolędę. "To ksiądz dla koperty chodzi?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353953,ksiadz-woznicki-grzmi-bo-prawie-nikt-nie-zaprosil-go-na-kolede.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353953,ksiadz-woznicki-grzmi-bo-prawie-nikt-nie-zaprosil-go-na-kolede.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 09:21:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/af/fe/1b/z29354159M,Ks--Michal-Woznicki.jpg" vspace="2" />W internecie pojawiło się kolejne nagranie z udziałem ks. Michała Woźnickiego. Kapłan podczas kazania poruszył kwestię wizyt duszpasterskich - duchowny grzmiał, że tylko dwie rodziny zaprosiły go na kolędę. Jak dodał, wierni nie powinni zakładać, że ksiądz "chodzi po domach dla koperty".

## Pogoda na ferie zimowe 2023. Zima zaskoczy uczniów? Gdzie pojawi się śnieg i ochłodzenie?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353572,pogoda-na-ferie-zimowe-2023-zima-zaskoczy-uczniow-gdzie-pojawi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353572,pogoda-na-ferie-zimowe-2023-zima-zaskoczy-uczniow-gdzie-pojawi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 08:40:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/c7/1b/z29129429M,Snieg--zdjecie-ilustracyjne-.jpg" vspace="2" />Według zapowiedzi synoptyków w trakcie najbliższych ferii zimowych pogoda będzie bardziej zbliżona do wiosennej niż zimowej. Nie będzie obfitych opadów śniegu ani mrozu, jednak pojawi się ochłodzenie.

## Kiedy wypadają ferie zimowe 2023 dla poszczególnych województw? [HARMONOGRAM]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353474,wiemy-kiedy-wypadaja-ferie-zimowe-2023-dla-poszczegolnych-wojewodztw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353474,wiemy-kiedy-wypadaja-ferie-zimowe-2023-dla-poszczegolnych-wojewodztw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 08:34:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4e/7b/1a/z27769422M,Ferie-zimowe--zdjecie-ilustracyjne-.jpg" vspace="2" />Styczeń jest nie tylko czasem powrotu do obowiązków po przerwie świątecznej, ale też okresem wyczekiwania ferii zimowych. Terminy tej dwutygodniowej przerwy są różne dla poszczególnych województw, dlatego należy sprawdzić, w jakim okresie wypada czas wolny w konkretnych rejonach. Niektórzy bowiem będą cieszyli się wolnym już w połowie stycznia, inni zaś będą musieli czekać niespełna miesiąc dłużej.

## Ksiądz Dymer winny molestowania. Kościół ujawnił wyrok po 2 latach. Abp Polak: Smutne i zawstydzające
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353677,ksiadz-dymer-winny-molestowania-kosciol-ujawnil-wyrok-po-2.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353677,ksiadz-dymer-winny-molestowania-kosciol-ujawnil-wyrok-po-2.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 08:24:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/19/fd/1b/z29347865M.jpg" vspace="2" />Franciszkanin Tarsycjusz Krasucki otrzymał, za zgodą Watykanu, częściową informację o wyroku, jaki zapadł dwa lata temu w sprawie kanonicznej przeciwko księdzu Andrzeju Dymerowi, który został uznany winnym molestowania seksualnego wychowanków. W czwartek oświadczenie w sprawie wydał Prymas Polski. Abp Wojciech Polak stwierdził, że to "smutne i zawstydzające", że "pokrzywdzeni tak długo musieli czekać na prawdę".

## Pijacka awantura podczas wigilii TVP3 Opole. Pobity dziennikarz stracił pracę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353632,pijacka-awantura-podczas-wigilii-tvp3-opole-pobity-dziennikarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353632,pijacka-awantura-podczas-wigilii-tvp3-opole-pobity-dziennikarz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 08:14:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/fe/1b/z29353737M,TVP-3-Opole---zdjecie-ilustracyjne.jpg" vspace="2" />Kolejne konsekwencje wigilii pracowników TVP3 Opole. Jak wynika z informacji "Gazety Wyborczej", jeden z dziennikarzy stracił pracę, a trzech innych zostało zawieszonych. Wcześniej zarząd spółki zakazał picia alkoholu podczas spotkań świątecznych oraz organizacji tychże poza siedzibą firmy.

## Zawrócił w tunelu na S7 i zaczął jechać pod prąd. GDDKiA publikuje nagranie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353662,zawrocil-w-tunelu-na-s7-i-zaczal-jechac-pod-prad-gddkia-publikuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353662,zawrocil-w-tunelu-na-s7-i-zaczal-jechac-pod-prad-gddkia-publikuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 08:07:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/fe/1b/z29353719M,Auto-jadace-pod-prad.jpg" vspace="2" />Generalna Dyrekcja Dróg Krajowych i Autostrad opublikowała - ku przestrodze - nagranie z jednej z kamer w tunelu na drodze ekspresowej S7. Jeden z kierowców w środę wieczorem nagle zawrócił i zaczął jechać pod prąd, stwarzając poważne zagrożenie.

## Wojna w Ukrainie. ISW o sytuacji w Sołedarze: W najlepszym przypadku pyrrusowe zwycięstwo Rosji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353486,wojna-w-ukrainie-isw-o-sytuacji-w-soledarze-w-najlepszym-przypadku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353486,wojna-w-ukrainie-isw-o-sytuacji-w-soledarze-w-najlepszym-przypadku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 07:10:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3c/fe/1b/z29353532M,Soledar--11-stycznia.jpg" vspace="2" />"Siły rosyjskie prawdopodobnie kontrolują większość, jeśli nie całość Sołedaru" - przekazał w czwartek wieczorem amerykański think tank ISW, analizujący sytuację w Ukrainie. Instytucja oceniła jednocześnie, że można mówić jedynie o "rosyjskim taktycznym pyrrusowym zwycięstwie".

## Brat zabił Agnieszkę, bo "psuła" wizerunek katolickiej rodziny. "Myśleliśmy, że to normalne bicie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29348860,brat-zabil-agnieszke-bo-psula-wizerunek-katolickiej-rodziny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29348860,brat-zabil-agnieszke-bo-psula-wizerunek-katolickiej-rodziny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 07:00:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/fd/1b/z29348979M,Szydlowiec---zdjecie-ilustracyjne.jpg" vspace="2" />Agnieszka poszła w ślady rodziców i została nauczycielką. Rodzice chwalili się wszystkim zarówno córką, jak i młodszym synem Marcinem. Wizerunek idealnej, katolickiej rodziny zaczął się jednak walić. Brat uznał, że winną tej sytuacji jest właśnie Agnieszka. Kobieta została przez niego zabita, a ojciec i matka pomogli synowi zmylić tropy śledczych. Po latach Antoni P. twierdził, że był dobrym ojcem, a w dniu zabójstwa myślał, że Marcin "normalnie, jak zawsze tylko bije" Agnieszkę.

## Zabójstwo 10-letniej Kristiny z Mrowin. Prokuratura zaskarżyła wyrok ws. Jakuba A.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353448,zabojstwo-10-letniej-kristiny-z-mrowin-prokuratura-zaskarzyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353448,zabojstwo-10-letniej-kristiny-z-mrowin-prokuratura-zaskarzyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 06:16:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/00/fe/1b/z29353472M,Jakub-A---2021-r-.jpg" vspace="2" />Prokuratura zaskarżyła październikowy wyrok Sądu Okręgowego w Świdnicy ws. zabójstwa 10-letniej Kristiny z Mrowin - dowiedział się portal Gazeta.pl. Jakub A. został skazany na dożywocie, a o przedterminowe zwolnienie warunkowe będzie mógł ubiegać się najwcześniej po 30 latach. Zdaniem prokuratury ów okres należałoby jednak wydłużyć.

## Zbrodnia miłoszycka. Rodzice zamordowanej w 1997 r. Małgosi chcą zadośćuczynienia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29352932,zbrodnia-miloszycka-rodzice-zamordowanej-w-1997-r-malgosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29352932,zbrodnia-miloszycka-rodzice-zamordowanej-w-1997-r-malgosi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 05:35:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/93/1a/z27865948M,Zbrodnia-miloszycka--Norbert-Basiura-i-Ireneusz-M-.jpg" vspace="2" />Rodzice Małgosi, która w 1997 roku została brutalnie zgwałcona i zamordowana, chcą zadośćuczynienia. Mowa o milionie złotych. - Na bestialskiej śmierci mojej córki robiono kariery, a my przez ten system zostaliśmy zmiażdżeni - mówił "Gazecie Wyborczej" ojciec ofiary. - Będziemy kwestionować żądaną kwotę, a przede wszystkim zasadność samego pozwu - przekazała Onetowi pełnomocniczka oskarżonego Norberta Basiury.

## Para uprawiała stosunek przy 2-letnim dziecku. Nagranie trafiło w ręce policji. W tle handel narkotykami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353018,para-uprawiala-stosunek-przy-2-letnim-dziecku-nagranie-trafilo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29353018,para-uprawiala-stosunek-przy-2-letnim-dziecku-nagranie-trafilo.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-13 05:00:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/fe/1b/z29353036M,Policjant--zdjecie-ilustrujace-.jpg" vspace="2" />W powiecie sławieńskim (woj. zachodniopomorskie) doszło do skandalu obyczajowego. Para współżyła w obecności swojego 2-letniego dziecka, a wszystkie wyczyny nagrywała i fotografowała. Wideo przypadkiem trafiło w ręce policji, kiedy mężczyznę zatrzymano do rutynowej kontroli drogowej. Nieobyczajne zachowanie nie jest jednak jego jedynym problemem. Okazało się, że mężczyzna posiadał także znaczną ilości narkotyków.
