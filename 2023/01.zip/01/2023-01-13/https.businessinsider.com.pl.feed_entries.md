# Source Business insider, Source URL:https://businessinsider.com.pl/.feed, Source language: en-US

## Orlen kupi kilkanaście stacji benzynowych w Niemczech
 - [https://businessinsider.com.pl/wiadomosci/orlen-kupi-kilkanascie-stacji-benzynowych-w-niemczech/09kd025](https://businessinsider.com.pl/wiadomosci/orlen-kupi-kilkanascie-stacji-benzynowych-w-niemczech/09kd025)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 21:06:21+00:00
 - user: None

Koncern OMV planuje sprzedać Orlenowi 17 stacji benzynowych w Niemczech — podają niemieckie media.

## Teraz Rafako wzywa Tauron do zapłaty. Chce odszkodowania
 - [https://businessinsider.com.pl/gielda/teraz-rafako-wzywa-tauron-do-zaplaty-chce-odszkodowania/6zycskx](https://businessinsider.com.pl/gielda/teraz-rafako-wzywa-tauron-do-zaplaty-chce-odszkodowania/6zycskx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 20:44:06+00:00
 - user: None

Rafako stoi nad przepaścią po tym, jak Tauron zażądał od spółki kar i odszkodowań w wysokości 1,3 mld zł. Rafako poinformowało w piątek, że wzywa Tauron do zapłaty łącznie ponad 857 mln zł. Spółka oczekuje również przeprosin za bezprawne naruszenie dóbr osobistych.

## Teraz Rafako wzywał Tauron do zapłaty. Chce odszkodowania
 - [https://businessinsider.com.pl/gielda/teraz-rafako-wzywal-tauron-do-zaplaty-chce-odszkodowania/6zycskx](https://businessinsider.com.pl/gielda/teraz-rafako-wzywal-tauron-do-zaplaty-chce-odszkodowania/6zycskx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 20:44:06+00:00
 - user: None

Rafako stoi nad przepaścią po tym, jak Tauron zażądał od spółki kar i odszkodowań w wysokości 1,3 mld zł. Rafako poinformowało w piątek, że wzywa Tauron do zapłaty łącznie ponad 857 mln zł. Spółka oczekuje również przeprosin za bezprawne naruszenie dóbr osobistych.

## Członek RPP o inflacji. Może wzrosnąc o 6-8 proc. w miesiąc
 - [https://businessinsider.com.pl/gospodarka/czlonek-rpp-o-inflacji-moze-wzrosnac-o-6-8-proc-w-miesiac/jc4yv2s](https://businessinsider.com.pl/gospodarka/czlonek-rpp-o-inflacji-moze-wzrosnac-o-6-8-proc-w-miesiac/jc4yv2s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 20:11:04+00:00
 - user: None

Inflacja może wzrosnąć w styczniu o około 6-8 proc. w porównaniu z grudniem — powiedział członek Rady Polityki Pieniężnej Ludwik Kotecki w Polsat News. — Wydaje się, że problem inflacji zostanie z nami na dłużej, niż to niektórzy przewidują — dodał.

## Zamknięcie Shopee. Co z bazą klientów i zyskami sprzedawców
 - [https://businessinsider.com.pl/prawo/upadek-shopee-co-z-baza-klientow-i-zyskami-sprzedawcow/4blfrbg](https://businessinsider.com.pl/prawo/upadek-shopee-co-z-baza-klientow-i-zyskami-sprzedawcow/4blfrbg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 19:47:29+00:00
 - user: None

W czwartek platforma Shopee zaskoczyła wszystkich. Poinformowała, że 13 stycznia wycofuje się z Polski. To problem nie tylko dla pracowników i klientów, ale także dla sprzedawców. Z dnia na dzień stracili źródło sprzedaży. Czy mogą zaskarżyć spółkę? Pojawia się też pytanie, czy Shopee może odsprzedać swoją bazę użytkowników. Zdaniem prawników, tak.

## Zamknięcie Shopee. Co z bazą klientów i zyskami sprzedawców
 - [https://businessinsider.com.pl/prawo/shopee-znika-z-polski-co-z-baza-klientow-i-zyskami-sprzedawcow/4blfrbg](https://businessinsider.com.pl/prawo/shopee-znika-z-polski-co-z-baza-klientow-i-zyskami-sprzedawcow/4blfrbg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 19:47:29+00:00
 - user: None

W czwartek platforma Shopee zaskoczyła wszystkich. Poinformowała, że 13 stycznia wycofuje się z Polski. To problem nie tylko dla pracowników i klientów, ale także dla sprzedawców. Z dnia na dzień stracili źródło sprzedaży. Czy mogą zaskarżyć spółkę? Pojawia się też pytanie, czy Shopee może odsprzedać swoją bazę użytkowników. Zdaniem prawników, tak.

## Tusk zdradził, jaki ma plan na TVP. Jest zaskoczenie. "Niczego innego nie wymyślimy"
 - [https://businessinsider.com.pl/gospodarka/tusk-zdradzil-jaki-ma-plan-na-tvp-niczego-innego-nie-wymyslimy/mj6jvnr](https://businessinsider.com.pl/gospodarka/tusk-zdradzil-jaki-ma-plan-na-tvp-niczego-innego-nie-wymyslimy/mj6jvnr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 18:35:32+00:00
 - user: None

Wolałbym, żeby telewizja publiczna istniała, zachowywała się możliwie neutralnie, żeby KRRiT istniała i żeby znowu wróciły jako tako zdrowe zasady — powiedział w piątek przewodniczący PO Donald Tusk. Wcześniej jego polityczne otoczenie mówiło raczej o "likwidacji TVP".

## Wybuch gazociągu łączącego Litwę z Łotwą. Trwa ewakuacja
 - [https://businessinsider.com.pl/gospodarka/wybuch-gazociagu-laczacego-litwe-z-lotwa/4kj3b33](https://businessinsider.com.pl/gospodarka/wybuch-gazociagu-laczacego-litwe-z-lotwa/4kj3b33)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 18:28:12+00:00
 - user: None

Litewski operator przesyłu gazu Amber Grid poinformował w piątek, że doszło do eksplozji gazociągu łączącego Litwę i Łotwę na odcinku w okolicach litewskiego miasta Paswol na północy kraju. Służby prowadzą ewakuację sąsiedniej miejscowości.

## Koniec papierowych faktur dla klientów? Ministerstwo nie wyklucza zmian
 - [https://businessinsider.com.pl/prawo/podatki/obowiazkowe-e-faktury-dla-klientow-sklepow-mf-nie-wyklucza-zmian-w-noweli-ustawy-o/t6h8gtc](https://businessinsider.com.pl/prawo/podatki/obowiazkowe-e-faktury-dla-klientow-sklepow-mf-nie-wyklucza-zmian-w-noweli-ustawy-o/t6h8gtc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 17:30:09+00:00
 - user: None

Faktury za materiały budowlane, prąd, gaz itp. dostają również konsumenci. Zwykle na papierze. Od 2024 r. mają je dostawać wyłącznie w formie elektronicznej za pomocą Krajowego Systemu e-Faktur. Tak wynika z projektu nowelizacji VAT. Eksperci krytykują ten pomysł i wskazują na przeszkody techniczne oraz fakt, że władza będzie wiedziała wszystko o zakupach Polaków. Ministerstwo Finansów w odpowiedzi na pytania Business Insidera przyznaje, że sprawa nie jest przesądzona.

## Oszustwa podatkowe firmy Donalda Trumpa. Jest wyrok
 - [https://businessinsider.com.pl/wiadomosci/oszustwa-podatkowe-firmy-donalda-trumpa-jest-wyrok/1ewxnjy](https://businessinsider.com.pl/wiadomosci/oszustwa-podatkowe-firmy-donalda-trumpa-jest-wyrok/1ewxnjy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 17:24:33+00:00
 - user: None

Sąd najwyższy stanu Nowy Jork nakazał w piątek Trump Organization — grupie spółek byłego prezydenta USA Donalda Trumpa — zapłatę maksymalnej kary 1,61 mln dol. za trwające przez 15 lat oszustwa podatkowe. Kara jest drobnostką dla Trumpa, którego roczne przychody sięgają setek milionów dolarów.

## Ustawa o SN. Przewodnicząca KE zabrała głos
 - [https://businessinsider.com.pl/wiadomosci/von-der-leyen-ocenimy-polska-ustawe-o-sn-gdy-zostanie-wdrozona/b51egph](https://businessinsider.com.pl/wiadomosci/von-der-leyen-ocenimy-polska-ustawe-o-sn-gdy-zostanie-wdrozona/b51egph)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 17:18:42+00:00
 - user: None

Komisja Europejska oceni, czy ostatnie zmiany w polskim sądownictwie mogą doprowadzić do wypłaty środków z Funduszu Odbudowy dopiero wtedy, gdy nowe prawo zostanie wdrożone — przekazała przewodnicząca KE Ursula von der Leyen w piątek w szwedzkiej Kirunie.

## Niemcy znaleźli nowego dostawcę  gazu. Polska też może zyskać
 - [https://businessinsider.com.pl/gospodarka/niemcy-maja-nowego-dostawce-ropy-i-gazu-polska-tez-moze-zyskac/bgv7mdq](https://businessinsider.com.pl/gospodarka/niemcy-maja-nowego-dostawce-ropy-i-gazu-polska-tez-moze-zyskac/bgv7mdq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 17:02:54+00:00
 - user: None

Kanclerz Niemiec Olaf Scholz opowiedział się za importem ropy gazu z Iraku. Jak zapowiedział, surowiec z tego kraju mógłby również być transportowany do innych europejskich państw.

## Zamieszki w Brazylii. Sąd nakazał blokadę kont bankowych
 - [https://businessinsider.com.pl/wiadomosci/zamieszki-w-brazylii-sad-nakazal-blokade-kont-bankowych/zed8q6g](https://businessinsider.com.pl/wiadomosci/zamieszki-w-brazylii-sad-nakazal-blokade-kont-bankowych/zed8q6g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 16:54:29+00:00
 - user: None

Sąd nakazał zablokowanie kont osób i firm wspierających radykalnych zwolenników byłego prezydenta Brazylii Jaira Bolsonaro. To konsekwencja niedzielnego szturmu prawicowych manifestantów na budynki instytucji państwowych. Wartość zablokowanych środków szacowana jest na równowartość blisko 1,2 mln euro.

## Rewolucja w kredytach coraz bliżej. Pierwsze banki już podpisały umowy
 - [https://businessinsider.com.pl/twoje-pieniadze/rewolucja-w-kredytach-coraz-blizej-pierwsze-banki-juz-podpisaly-umowy-na-wiron/1qckfgh](https://businessinsider.com.pl/twoje-pieniadze/rewolucja-w-kredytach-coraz-blizej-pierwsze-banki-juz-podpisaly-umowy-na-wiron/1qckfgh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 16:20:26+00:00
 - user: None

Rewolucyjne zmiany w kredytach zapowiadane przez premiera miały być odczuwalne już od 1 stycznia 2023 r. Banki jednak ciągle wstrzymują się z oferowaniem umów z nową stawką WIRON. Co więcej, nie wszystkie podpisały dokumenty, które im to umożliwią. Prawdopodobnie jest ich tylko kilka. Największy polski bank przyznaje, że umowę na WIRON już ma. Jego konkurent deklaruje, że "trwają ostatnie ustalenia". Co więc stoi na przeszkodzie?

## Chcieli kupić chleb za 2,99 zł. Jak prezes NBP
 - [https://businessinsider.com.pl/twoje-pieniadze/chcieli-kupic-chleb-za-299-zl-jak-prezes-nbp/98zj3j0](https://businessinsider.com.pl/twoje-pieniadze/chcieli-kupic-chleb-za-299-zl-jak-prezes-nbp/98zj3j0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 16:09:17+00:00
 - user: None

Prezes NBP Adam Glapiński ocenił w trakcie ostatniej konferencji prasowej, że w mediach pojawiają się nieprawdziwe informacje dotyczące cen, w tym m.in. cen pieczywa. On zaś kupuje chleb za 2,99 zł. Dziennikarze rmf24.pl ruszyli śladami prezesa NBP na poszukiwanie bochenka w takiej cenie.

## Bill Gates woli telefon z systemem Android od iPhone’a
 - [https://businessinsider.com.pl/wiadomosci/bill-gates-w-druzynie-androida-a-nie-iphonea/pm2kljj](https://businessinsider.com.pl/wiadomosci/bill-gates-w-druzynie-androida-a-nie-iphonea/pm2kljj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 15:43:12+00:00
 - user: None

Podczas jedenastej akcji Ask Me Anything na Reddicie, Bill Gates potwierdził, że nadal jest w drużynie Androida, a nie iPhone'a.

## To może być początek pozytywnego zwrotu w polskiej gospodarce
 - [https://businessinsider.com.pl/finanse/makroekonomia/to-moze-byc-poczatek-pozytywnego-zwrotu-w-polskiej-gospodarce/0nc0qt3](https://businessinsider.com.pl/finanse/makroekonomia/to-moze-byc-poczatek-pozytywnego-zwrotu-w-polskiej-gospodarce/0nc0qt3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 15:37:25+00:00
 - user: None

Dane dotyczące bilansu płatniczego za listopad okazały się zaskakująco dobre. Zdaniem ekonomistów PKO BP są duże szanse na to, że wchodzimy w okres trwałej poprawy bilansu płatniczego. Jednak na wyjście na plus i nadwyżek w tym zakresie, które wspierałyby złotego, prawdopodobnie na razie nie ma co liczyć.

## Dziewięć najnowszych zmian w prawie. Co uchwalił Sejm?
 - [https://businessinsider.com.pl/prawo/praca/sejm-uchwalil-kodeks-pracy-ustawe-o-sn-i-wiele-innych-waznych-ustaw/y34e82e](https://businessinsider.com.pl/prawo/praca/sejm-uchwalil-kodeks-pracy-ustawe-o-sn-i-wiele-innych-waznych-ustaw/y34e82e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 15:07:23+00:00
 - user: None

W nowym roku posłowie nie próżnują. Poza kontrowersyjną ustawą o Sądzie Najwyższym przyjęli wiele innych ważnych przepisów. Dotyczą one pracy zdalnej, badania trzeźwości, pomocy obywatelom Ukrainy, emerytur dla rolników, uprawnień fiskusa, badań klinicznych, grypy, a nawet państwowej komisji do spraw pedofilii. Opisujemy najważniejsze zmiany, jakie w piątek 13 grudnia przyjął Sejm.

## Ustawa o SN nie odblokuje KPO. Te przepisy będą równie ważne
 - [https://businessinsider.com.pl/gospodarka/ustawa-o-sn-nie-odblokuje-kpo-te-przepisy-beda-rownie-wazne/0wdeqgh](https://businessinsider.com.pl/gospodarka/ustawa-o-sn-nie-odblokuje-kpo-te-przepisy-beda-rownie-wazne/0wdeqgh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 14:52:44+00:00
 - user: None

Zmiany w sądownictwie były najpoważniejszą, ale nie jedyną przeszkodą dla wypłat z polskiego KPO. Jak informuje RMF FM, nawet przyjęcie nowelizacji ustawy o Sądzie Najwyższym nie wystarczy, by dostać pieniądze. Komisja Europejska domaga się jeszcze tzw. ustawy wiatrakowej.

## Sprzedawcy bez dostępu do swoich pieniędzy. Shopee się tłumaczy
 - [https://businessinsider.com.pl/finanse/handel/sprzedawcy-bez-dostepu-do-pieniedzy-shopee-sie-tlumaczy/gx5f1xj](https://businessinsider.com.pl/finanse/handel/sprzedawcy-bez-dostepu-do-pieniedzy-shopee-sie-tlumaczy/gx5f1xj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 14:43:55+00:00
 - user: None

Sprzedawcy, którzy od wczoraj mają problem z wypłatą pieniędzy ze swojego konta w Shopee, muszą uzbroić się w cierpliwość. Platforma przyznaje, że miała pewne problemy techniczne, ale w większości przypadków zostały już zażegnane. "Wciąż pracujemy nad rozwiązaniem problemu w niewielkiej liczbie pozostałych przypadków i przepraszamy za niedogodności" — czytamy w oświadczeniu Shopee.

## Grupa Wagnera szuka ciężarówek do wywożenia ciał. Opłata w gotówce
 - [https://businessinsider.com.pl/wiadomosci/grupa-wagnera-szuka-ciezarowek-do-wywozenia-cial-oplata-w-gotowce/2fgc4fq](https://businessinsider.com.pl/wiadomosci/grupa-wagnera-szuka-ciezarowek-do-wywozenia-cial-oplata-w-gotowce/2fgc4fq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 14:29:23+00:00
 - user: None

Grupy Wagnera, rosyjska formacja najemników, transportuje ciała zabitych żołnierzy za pomocą ciężarówek rosyjskich firm transportowych — piszą rosyjskie niezależne media. Chętnych do przewozu szuka przez ogłoszenia. Opłata za transport to 60 tys. rubli gotówką.

## Polska krytykowała Niemcy, a sama popełnia ten sam błąd
 - [https://businessinsider.com.pl/gospodarka/polska-krytykowala-niemcy-a-sama-popelnia-ten-sam-blad/cyzm6cz](https://businessinsider.com.pl/gospodarka/polska-krytykowala-niemcy-a-sama-popelnia-ten-sam-blad/cyzm6cz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 14:25:46+00:00
 - user: None

Żaden kraj w Europie nie krytykował tak ostro Niemiec za uzależnienie od rosyjskiej ropy i gazu jak Polska. Warszawa dużo mówi o swojej samowystarczalności energetycznej dzięki zielonej energii i energii jądrowej. Ale teraz sama jest zależna od dyktatur - pisze w komentarzu dla "Die Welt" Phillip Fritz.

## Niezłe dane z niemieckiej gospodarki. To dobra informacja także dla Polski
 - [https://businessinsider.com.pl/finanse/makroekonomia/niezle-dane-z-niemieckiej-gospodarki-to-dobra-informacja-takze-dla-polski/x07hptb](https://businessinsider.com.pl/finanse/makroekonomia/niezle-dane-z-niemieckiej-gospodarki-to-dobra-informacja-takze-dla-polski/x07hptb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 14:24:23+00:00
 - user: None

Produkt Krajowy Brutto Niemiec w 2022 r. wzrósł o 1,9 proc. — poinformował w komunikacie Federalny Urząd Statystyczny na podstawie wstępnych szacunków. To odczyt nawet nieco lepszy od prognoz. Analitycy spodziewali się bowiem wzrostu 1,8 proc. W 2021 r. niemiecka gospodarka urosła o 2,6 proc.

## Oto fotowoltaiczny "kwiatek". Produkuje nawet o połowę więcej energii niż zwykłe panele
 - [https://businessinsider.com.pl/wideo/oto-fotowoltaiczny-kwiatek-produkuje-nawet-o-polowe-wiecej-energii-niz-zwykle-panele/9twq12d](https://businessinsider.com.pl/wideo/oto-fotowoltaiczny-kwiatek-produkuje-nawet-o-polowe-wiecej-energii-niz-zwykle-panele/9twq12d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:58:00+00:00
 - user: None

Smartflower zachowuje się jak prawdziwy kwiat i korzysta ze zjawiska zwanego heliotropizmem. W ciągu dnia "podąża" za słońcem, by "wycisnąć" z niego jak najwięcej.

## Ranking pięciu najpopularniejszych lornetek w styczniu 2023 roku
 - [https://businessinsider.com.pl/technologie/ranking-pieciu-najpopularniejszych-lornetek-w-styczniu-2023-roku/6f3bp4e](https://businessinsider.com.pl/technologie/ranking-pieciu-najpopularniejszych-lornetek-w-styczniu-2023-roku/6f3bp4e)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:49:00+00:00
 - user: None

Szukasz lornetki, ale nie wiesz, którym modelem warto się zainteresować? Przygotowaliśmy dla ciebie ranking pięciu najpopularniejszych modeli w styczniu 2023 roku według danych z internetowej porównywarki cen Skąpiec.pl.

## Zaskakujące dane o polskim eksporcie. To pierwszy taki przypadek od ponad półtora roku
 - [https://businessinsider.com.pl/finanse/makroekonomia/zaskakujace-dane-o-polskim-eksporcie-to-pierwszy-taki-przypadek-od-ponad-poltora-roku/wwd6mpf](https://businessinsider.com.pl/finanse/makroekonomia/zaskakujace-dane-o-polskim-eksporcie-to-pierwszy-taki-przypadek-od-ponad-poltora-roku/wwd6mpf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:37:07+00:00
 - user: None

Saldo rachunku bieżącego w listopadzie okazało się lepsze od oczekiwań, choć wciąż jest ujemne – poinformował w piątek Narodowy Bank Polski. Eksport wreszcie urósł szybciej niż import. Sprzedaż za granicę urosła o 20,3 proc. rok do roku, a import o 17,7 proc.

## Dobre informacje dla polskich cen paliw. Te dane wpłyną na obniżkę
 - [https://businessinsider.com.pl/gospodarka/dobre-informacje-dla-polskich-cen-paliw-te-dane-wplyna-na-obnizke/43xe5fc](https://businessinsider.com.pl/gospodarka/dobre-informacje-dla-polskich-cen-paliw-te-dane-wplyna-na-obnizke/43xe5fc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:33:41+00:00
 - user: None

Złoty kontynuuje umacnianie się względem dolara, rentowności polskich obligacji rządowych zeszły poniżej 6 proc. Skąd ta wiara międzynarodowego kapitału w polską gospodarkę, choć prognozy są tak niepokojące? To głównie skutek spadającej inflacji w USA. Drogą gospodarczych naczyń połączonych powinno się to przełożyć też na ceny paliw w Polsce, a więc i spadek naszej inflacji.

## "Die Welt": Polska powtarza błąd Niemców. Chodzi o kontakty z Saudami
 - [https://businessinsider.com.pl/gospodarka/die-welt-polska-uzaleznia-sie-od-saudyjskiej-ropy-robi-ten-sam-blad-co-niemcy/lglkzwk](https://businessinsider.com.pl/gospodarka/die-welt-polska-uzaleznia-sie-od-saudyjskiej-ropy-robi-ten-sam-blad-co-niemcy/lglkzwk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:31:46+00:00
 - user: None

Zdaniem niemieckiego "Die Welt" Polska uzależniając się coraz mocniej od saudyjskiej ropy naftowej popełnia dokładnie ten sam błąd co Niemcy, które przez lata stawiały na gaz z Rosji i wspólnie z Moskwą forsowały Nord Stream.

## Nie narzekaj na router —  kup wzmacniacz wi-fi
 - [https://businessinsider.com.pl/technologie/nie-narzekaj-na-router-kup-wzmacniacz-wi-fi/98m04bq](https://businessinsider.com.pl/technologie/nie-narzekaj-na-router-kup-wzmacniacz-wi-fi/98m04bq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 13:02:00+00:00
 - user: None

Jeśli masz w domu problemy z internetem, prawdopodobnie wina nie leży po stronie dostawcy ani routera. Problemem może być po prostu słaby zasięg wi-fi, z czym poradzi sobie wzmacniacz sygnału. Przedstawiamy ranking takich urządzeń według danych z porównywarki cen Skąpiec.pl.

## Już nawet nie ukrywają. Spór jest coraz ostrzejszy, a droga do miliardów – wyboista
 - [https://businessinsider.com.pl/wiadomosci/juz-nawet-nie-ukrywaja-spor-jest-coraz-ostrzejszy/n0zxxnv](https://businessinsider.com.pl/wiadomosci/juz-nawet-nie-ukrywaja-spor-jest-coraz-ostrzejszy/n0zxxnv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 12:45:18+00:00
 - user: None

Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym, ale jeszcze bardziej naświetliło to konflikt PiS i Solidarnej Polski – a zwłaszcza otoczenia Morawieckiego i Ziobry.

## Adidas przegrał sądową batalię z projektantem. Poszło o paski
 - [https://businessinsider.com.pl/wiadomosci/adidas-przegral-sadowa-batalie-z-projektantem-poszlo-o-paski/259e5jg](https://businessinsider.com.pl/wiadomosci/adidas-przegral-sadowa-batalie-z-projektantem-poszlo-o-paski/259e5jg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 12:37:32+00:00
 - user: None

Adidas przegrał sądową batalię z projektantem Thomem Browne'em. Po szło o to, czy można sprzedawać produkty z paskami. Ława przysięgłych na podjęcie decyzji potrzebowała mniej niż trzech godzin.

## PiS chce jeszcze większych przywilejów dla TVP. Wiadomo, co dalej z "lex pilot"
 - [https://businessinsider.com.pl/gospodarka/pis-chce-jeszcze-wiekszych-przywilejow-dla-tvp-lex-pilot-do-komisji/vb2tvl7](https://businessinsider.com.pl/gospodarka/pis-chce-jeszcze-wiekszych-przywilejow-dla-tvp-lex-pilot-do-komisji/vb2tvl7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 12:08:33+00:00
 - user: None

PiS wraz z koalicjantami nie pozwolił na odrzucenie w pierwszym czytaniu nowelizacji Prawa komunikacji elektronicznej. To oznacza, że "lex pilot" trafi teraz do komisji. Skąd nazwa? W projekcie jest bowiem zapis, który narzuca obowiązek ustawiania kanałów TVP na pierwszych pięciu miejscach na pilocie.

## Wyligała nowym prezesem LW Bogdanka. Niedawno towarzyszył w zaręczynach ważnego polityka PiS
 - [https://businessinsider.com.pl/gospodarka/wyligala-nowym-prezesem-lw-bogdanka/b7gpbdm](https://businessinsider.com.pl/gospodarka/wyligala-nowym-prezesem-lw-bogdanka/b7gpbdm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 12:08:18+00:00
 - user: None

Rada nadzorcza powołała w piątek Kasjana Wyligałę na stanowisko prezesa – poinformował w komunikacie Lubelski Węgiel Bogdanka S.A. Menedżer miał towarzyszyć niedawno w zaręczynach wpływowego działacza PiS Michała Moskala, które odbyły się właśnie w tej kopalni.

## "Albo pieniądze, albo prawo". Przedsiębiorcy krytykują ustawę o SN
 - [https://businessinsider.com.pl/gospodarka/albo-pieniadze-albo-prawo-przedsiebiorcy-krytykuja-ustawe-o-sn/z6x4t03](https://businessinsider.com.pl/gospodarka/albo-pieniadze-albo-prawo-przedsiebiorcy-krytykuja-ustawe-o-sn/z6x4t03)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 11:55:33+00:00
 - user: None

Pracodawcy i przedsiębiorcy niezbyt dobrze oceniają uchwalenie nowelizacji ustawy o Sądzie Najwyższym. Mimo że — zgodnie z zapowiedziami rządzących — ma ona przyczynić się do odblokowania pieniędzy z KPO. "Nie możemy się zgodzić na kolejną pseudo naprawę polskiego systemu sądownictwa" — komentuje Konfederacja Lewiatan.

## CBA weszło do Urzędu Miasta Katowice
 - [https://businessinsider.com.pl/wiadomosci/cba-weszlo-do-urzedu-miasta-katowice/fbn72h7](https://businessinsider.com.pl/wiadomosci/cba-weszlo-do-urzedu-miasta-katowice/fbn72h7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 11:29:48+00:00
 - user: None

Pod koniec 2022 r. w Urzędzie Miasta Katowice pojawili się funkcjonariusze CBA. Przeprowadzają kontrolę dot. działań promocyjnych stolicy woj. śląskiego — informuje portalsamorzadowy.pl.

## Dlaczego w samolotach jest tak zimno?
 - [https://businessinsider.com.pl/lifestyle/podroze/dlaczego-w-samolotach-jest-tak-zimno-jak-sie-ubrac-do-samolotu/s9eh8w1](https://businessinsider.com.pl/lifestyle/podroze/dlaczego-w-samolotach-jest-tak-zimno-jak-sie-ubrac-do-samolotu/s9eh8w1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 11:21:00+00:00
 - user: None

Zapytaj bardziej doświadczonych podróżników o to, jak ubierają się na podróż samolotem, a usłyszysz jedną odpowiedź: na cebulkę. To dlatego, że istnieje wysokie ryzyko, że gdy znajdziesz się na pokładzie, będzie tam bardzo zimno.

## Inflacja zacznie spadać, ale wciąż będzie wysoka. To nie pozwoli na prędkie cięcie stóp
 - [https://businessinsider.com.pl/finanse/makroekonomia/inflacja-zacznie-spadac-ale-wciaz-bedzie-wysoka-to-nie-pozwoli-na-predkie-ciecie-stop/jc8cr0f](https://businessinsider.com.pl/finanse/makroekonomia/inflacja-zacznie-spadac-ale-wciaz-bedzie-wysoka-to-nie-pozwoli-na-predkie-ciecie-stop/jc8cr0f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 11:10:07+00:00
 - user: None

Według ekonomistów inflacja od marca będzie się od marca obniżać, ale w głównej mierze wynikać to będzie ze spadku tzw. elementów niebazowych, czyli na przykład cen energii i paliw, które są mocno zmienne i przewidzieć ich kierunek oraz zależą głównie od sytuacji na świecie. Z kolei inflacja bazowa pozostanie uporczywie wysoka, co będzie blokować Radzie Polityki Pieniężnej drogę do obniżek stóp procentowych. "Jeśli RPP obniży w tym roku stopy, to za moment będzie je podwyższać. Być może będzie musiała nawet bez obniżki" — ocenili ekonomiści mBanku.

## Biedronka znów rozzłościła UOKiK. Chodzi o "potrójne ceny"
 - [https://businessinsider.com.pl/gospodarka/biedronka-znow-rozzloscila-uokik-chodzi-o-potrojne-ceny/tvsm34d](https://businessinsider.com.pl/gospodarka/biedronka-znow-rozzloscila-uokik-chodzi-o-potrojne-ceny/tvsm34d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 10:57:53+00:00
 - user: None

Regulator wielokrotnie nakładał na Biedronkę bardzo wysokie kary. Czy może dojść kolejna? UOKiK nie ukrywa, że nie jest zadowolony z tego, jak sieć wdrożyła unijną dyrektywę Omnibus.

## Apple obniża pensję swojego prezesa o 40 proc.
 - [https://businessinsider.com.pl/wiadomosci/apple-obniza-pensje-swojego-prezesa-o-40-proc/evpldg1](https://businessinsider.com.pl/wiadomosci/apple-obniza-pensje-swojego-prezesa-o-40-proc/evpldg1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 10:36:59+00:00
 - user: None

Tim Cook, dyrektor generalny Apple, otrzyma w tym roku wynagrodzenie mniejsze o 40 proc. Technologiczny gigant przekazał, że obniżki zażądał sam Cook po krytyce ze strony akcjonariuszy - donosi BBC.

## Bez tego mieszkania nie sprzedasz. Będzie nowy przepis
 - [https://businessinsider.com.pl/twoje-pieniadze/bez-tego-mieszkania-nie-sprzedasz-bedzie-nowy-przepis/pt9sss6](https://businessinsider.com.pl/twoje-pieniadze/bez-tego-mieszkania-nie-sprzedasz-bedzie-nowy-przepis/pt9sss6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 10:14:32+00:00
 - user: None

Świadectwa energetyczne będą obowiązkowe przy sprzedaży lub najmie nieruchomości. Resort rozwoju i technologii podaje datę, kiedy przepis wejdzie w życie.

## Sejm uchwalił nowelizację ustawy o Sądzie Najwyższym
 - [https://businessinsider.com.pl/wiadomosci/sejm-uchwalil-nowelizacje-ustawy-o-sadzie-najwyzszym/2820nz3](https://businessinsider.com.pl/wiadomosci/sejm-uchwalil-nowelizacje-ustawy-o-sadzie-najwyzszym/2820nz3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 10:00:45+00:00
 - user: None

Sejm poparł ustawę o Sądzie Najwyższym. Rządzący przekonują, że te przepisy pozwolą odblokować środki z KPO.

## Najnowsze dane o inflacji. Te produkty konsumpcyjne podrożały najmocniej
 - [https://businessinsider.com.pl/finanse/makroekonomia/najnowsze-dane-o-inflacji-te-produkty-konsumpcyjne-podrozaly-najmocniej/mlzpn0x](https://businessinsider.com.pl/finanse/makroekonomia/najnowsze-dane-o-inflacji-te-produkty-konsumpcyjne-podrozaly-najmocniej/mlzpn0x)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 09:40:57+00:00
 - user: None

Rok 2022 był trudny dla konsumentów ze względu na szybki wzrost kosztów utrzymania. Żywność oraz użytkowanie mieszkania i nośniki energii podrożały w tempie niewidzianym od dekad. Oto szczegółowe statystyki dotyczące wzrostów cen towarów i usług konsumpcyjnych w Polsce.

## Te auta z gamy JCW warto poznać bliżej
 - [https://businessinsider.com.pl/technologie/motoryzacja/te-auta-z-gamy-jcw-warto-poznac-blizej/p0fpnyt](https://businessinsider.com.pl/technologie/motoryzacja/te-auta-z-gamy-jcw-warto-poznac-blizej/p0fpnyt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 09:35:00+00:00
 - user: None

Każde MINI John Cooper Works stanowi zapowiedź czegoś więcej niż auto przeznaczone do pokonywania odcinków na trasie dom - praca - dom. Modele JCW nie lubią nudy: widać to zarówno po designie, jak i po tym, co znajduje się pod maską. Oto trzy samochody, którym warto przyjrzeć się z zewnątrz i od środka.

## "Ograniczymy podwyżki dla obywateli". Minister Moskwa obiecuje
 - [https://businessinsider.com.pl/twoje-pieniadze/ograniczymy-podwyzki-dla-obywateli-minister-moskwa-obiecuje/csnltm5](https://businessinsider.com.pl/twoje-pieniadze/ograniczymy-podwyzki-dla-obywateli-minister-moskwa-obiecuje/csnltm5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 09:21:13+00:00
 - user: None

Już wkrótce przedstawimy dodatkowe przepisy jeszcze mocniej chroniące odbiorców ciepła. Zapewnimy rekompensaty i ograniczymy podwyżki do obywateli – zapowiada minister klimatu i środowiska Anna Moskwa.

## Inflacja w Polsce znowu spadła. GUS potwierdza oficjalne dane
 - [https://businessinsider.com.pl/finanse/makroekonomia/inflacja-w-polsce-znowu-spadla-gus-potwierdza-oficjalne-dane/8y9szzr](https://businessinsider.com.pl/finanse/makroekonomia/inflacja-w-polsce-znowu-spadla-gus-potwierdza-oficjalne-dane/8y9szzr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 09:00:18+00:00
 - user: None

Grudzień był drugim miesiącem z rzędu, w którym spadł w Polsce wskaźnik inflacji konsumenckiej liczony rok do roku. Potwierdzają to piątkowe finalne dane Głównego Urzędu Statystycznego. Jednak szczyt tempa wzrostu cen dopiero przed nami. Inflacja średnioroczna w całym 2022 r. wyniosła 14,4 proc. wobec 4,9 proc. w 2021 r. — wynika z danych GUS.

## Leszek Balcerowicz prezesem FOR. Odchodzi znany ekspert
 - [https://businessinsider.com.pl/gospodarka/balcerowicz-prezesem-for-odchodzi-znany-ekspert/qvct01f](https://businessinsider.com.pl/gospodarka/balcerowicz-prezesem-for-odchodzi-znany-ekspert/qvct01f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:48:38+00:00
 - user: None

Pracami Forum Obywatelskiego Rozwoju pokieruje założyciel tej fundacji, czyli Leszek Balcerowicz. Z FOR żegna się natomiast dotychczasowy szef Sławomir Dudek, jeden z najbardziej rozpoznawalnych ekspertów tej organizacji.

## Leszek Balcerowicz z nowym stanowiskiem. Będzie prezesem
 - [https://businessinsider.com.pl/gospodarka/leszek-balcerowicz-z-nowym-stanowiskiem-bedzie-prezesem/qvct01f](https://businessinsider.com.pl/gospodarka/leszek-balcerowicz-z-nowym-stanowiskiem-bedzie-prezesem/qvct01f)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:48:38+00:00
 - user: None

Nowym pezesem Forum Obywatelskiego Rozwoju został założyciel tej fundacji, czyli Leszek Balcerowicz. Z FOR żegna się natomiast dotychczasowy szef Sławomir Dudek, jeden z najbardziej rozpoznawalnych ekspertów tej organizacji.

## Budżet nie zyska na e-papierosach. Będą nowe problemy. Mamy stanowisko Ministerstwa Finansów
 - [https://businessinsider.com.pl/prawo/podatki/plyn-do-e-papierosow-czy-akcyze-zaplaca-tez-firmy-z-innych-branz-wyjasnia/zsn5t6r](https://businessinsider.com.pl/prawo/podatki/plyn-do-e-papierosow-czy-akcyze-zaplaca-tez-firmy-z-innych-branz-wyjasnia/zsn5t6r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:39:53+00:00
 - user: None

Zmiana definicji liquidów do e-papierosów ma zwiększyć wpływy z akcyzy. Trudniej będzie oszukać, że sprzedaje się aromat do kominków. Zdaniem ekspertów osiągnięcie tego celu może się jednak nie udać. Za to pojawiają się nowe problemy dla firm z innych branż, m.in. spożywczej, kosmetycznej, farmaceutycznej, a nawet budowlanej, które korzystają z substancji wykorzystywanych w e-papierosach. Ministerstwo Finansów w odpowiedzi na pytania Business Insidera wyjaśnia, jak należy interpretować nowe regulacje.

## Kurs franka 13 stycznia poniżej 4,7 zł
 - [https://businessinsider.com.pl/gospodarka/kurs-franka-13-stycznia-ponizej-47-zl/e045739](https://businessinsider.com.pl/gospodarka/kurs-franka-13-stycznia-ponizej-47-zl/e045739)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:30:31+00:00
 - user: None

Frank szwajcarski poniżej 4,7 zł. W piątek rano 13 stycznia 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,6587.

## Kurs euro 13 stycznia w okolicach 4,7 zł
 - [https://businessinsider.com.pl/gospodarka/kurs-euro-13-stycznia-w-okolicach-47-zl/vs1rk45](https://businessinsider.com.pl/gospodarka/kurs-euro-13-stycznia-w-okolicach-47-zl/vs1rk45)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:22:00+00:00
 - user: None

Kurs euro w okolicach 4,7. W piątek rano 13 stycznia 2022 r. kurs EUR/PLN wynosił 4,6942 zł.

## Jeep Renegade także z oszczędnymi napędami hybrydowymi
 - [https://businessinsider.com.pl/technologie/motoryzacja/jeep-renegade-z-ciekawymi-oszczednymi-napedami-hybrydowymi/rdym5gm](https://businessinsider.com.pl/technologie/motoryzacja/jeep-renegade-z-ciekawymi-oszczednymi-napedami-hybrydowymi/rdym5gm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:16:00+00:00
 - user: None

Za sprawą zelektryfikowanych napędów znany terenowy SUV amerykańskiej marki zyskał nowocześniejsze oblicze. Poznajcie dwie odsłony Jeepa Renegade - 4xe oraz e-Hybrid.

## Nowy rekord inflacji na Węgrzech
 - [https://businessinsider.com.pl/finanse/makroekonomia/kolejne-klopoty-gospodarcze-viktora-orbana-inflacja-wciaz-rosnie/9mq3rt4](https://businessinsider.com.pl/finanse/makroekonomia/kolejne-klopoty-gospodarcze-viktora-orbana-inflacja-wciaz-rosnie/9mq3rt4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:15:09+00:00
 - user: None

Węgierskich problemów gospodarczych ciąg dalszy. Inflacja konsumencka w kraju rządzonym przez Viktora Orbana wkroczyła w grudniu na poziomy nienotowane od ponad ćwierćwiecza. Najmocniej drożeją ceny energii i żywności, tu wskaźniki sięgają odpowiednio 55 proc. i 45 proc.

## Coraz więcej Polaków na tym zarabia. Kupują "tajemnicze palety"
 - [https://businessinsider.com.pl/wiadomosci/nowy-sposob-polakow-na-zarobek-o-co-chodzi-z-tajemniczymi-paletami/by5qwlz](https://businessinsider.com.pl/wiadomosci/nowy-sposob-polakow-na-zarobek-o-co-chodzi-z-tajemniczymi-paletami/by5qwlz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:14:31+00:00
 - user: None

Prawie 250 ogłoszeń pojawia się w serwisie Allegro po zaznaczeniu filtra "paleta ze zwrotami", ponad 60 wyskakuje na Olx. Na Facebooku zarejestrowanych jest co najmniej kilkanaście grup, dzięki którym można sprzedać lub kupić pakiet towarów zwróconych przez klientów sklepów internetowych. Niektórzy robią na tym biznes, ale trzeba uważać, żeby nie kupić "kota w worku".

## Kurs dolara 13 stycznia powyżej 4,3
 - [https://businessinsider.com.pl/gospodarka/kurs-dolara-13-stycznia-powyzej-43/wb8jtm8](https://businessinsider.com.pl/gospodarka/kurs-dolara-13-stycznia-powyzej-43/wb8jtm8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 08:14:13+00:00
 - user: None

Kurs dolara powyżej 4,3 zł. W piątek rano 13 stycznia 2022 r. kurs USD/PLN wynosi 4,3256.

## Członek RPP: możliwa jedna lub dwie podwyżki stóp
 - [https://businessinsider.com.pl/finanse/czlonek-rpp-mozliwa-jedna-lub-dwie-podwyzki-stop/r261zf3](https://businessinsider.com.pl/finanse/czlonek-rpp-mozliwa-jedna-lub-dwie-podwyzki-stop/r261zf3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 07:21:01+00:00
 - user: None

Przy silnym impulsie inflacyjnym w I kwartale możliwa jest jedna lub dwie niewielkie podwyżki stóp — powiedział w telewizji BIZNES 24 członek RPP Henryk Wnorowski.

## Kiedy wypłaty z KPO? Rzecznik rządu podaje konkretny termin
 - [https://businessinsider.com.pl/wiadomosci/kiedy-wyplaty-z-kpo-rzecznik-rzadu-podaje-konkretny-termin/9qsemgb](https://businessinsider.com.pl/wiadomosci/kiedy-wyplaty-z-kpo-rzecznik-rzadu-podaje-konkretny-termin/9qsemgb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 07:02:22+00:00
 - user: None

Choć losy ustawy, która ma odblokować środki z KPO wcale przesądzone nie są, rzecznik rządu Piotr Müller wskazuje, kiedy moglibyśmy otrzymać z Brukseli pieniądze. "Jeżeli proces legislacyjny się zakończy w ciągu pół miesiąca, półtora, to później składamy wniosek do KE" – mówi rzecznik w RMF.

## Polska armia coraz silniejsza. Raport Global Firepower potwierdza
 - [https://businessinsider.com.pl/wiadomosci/polska-armia-coraz-silniejsza-raport-global-firepower-potwierdza/7d6n62r](https://businessinsider.com.pl/wiadomosci/polska-armia-coraz-silniejsza-raport-global-firepower-potwierdza/7d6n62r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:46:05+00:00
 - user: None

W ciągu ostatniego roku Polska awansowała o cztery pozycje i zajmuje 20. miejsce wśród potęg militarnych świata w najnowszej edycji rankingu Global Firepower. Zestawienie mierzy potencjał militarny 145 państw świata.

## Polska staje się wojskową potęgą. Raport Global Firepower potwierdza
 - [https://businessinsider.com.pl/wiadomosci/polska-staje-sie-wojskowa-potega-raport-potwierdza/7d6n62r](https://businessinsider.com.pl/wiadomosci/polska-staje-sie-wojskowa-potega-raport-potwierdza/7d6n62r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:46:05+00:00
 - user: None

W ciągu ostatniego roku Polska awansowała o cztery pozycje i zajmuje 20. miejsce wśród potęg militarnych świata w najnowszej edycji rankingu Global Firepower. Zestawienie mierzy potencjał militarny 145 państw świata.

## Orlen zainwestował we francuską platformę
 - [https://businessinsider.com.pl/gospodarka/orlen-zainwestowal-we-francuska-platforme/swhdrdt](https://businessinsider.com.pl/gospodarka/orlen-zainwestowal-we-francuska-platforme/swhdrdt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:38:00+00:00
 - user: None

PKN Orlen zainwestował w innowacyjną francuską platformę logistyczną Shippeo — podaje w piątek "Rzeczpospolita". Gazeta zauważa jednocześnie, że rynek technologicznych transakcji w Polsce i Europie wyraźnie słabnie.

## Kałasznikow zyskuje na wojnie. "Największe kontrakty w historii"
 - [https://businessinsider.com.pl/gospodarka/kalasznikow-zyskuje-na-wojnie-najwieksze-kontrakty-w-historii/rsjsg82](https://businessinsider.com.pl/gospodarka/kalasznikow-zyskuje-na-wojnie-najwieksze-kontrakty-w-historii/rsjsg82)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:31:40+00:00
 - user: None

"Mamy największe kontrakty w historii przedsiębiorstwa" – przekazuje rosyjskim mediom biuro prasowe Kałasznikowa. Wojna w Ukrainie spowodowała, że zapotrzebowanie na tę broń jest najwyższe od dekad.

## Ten kraj zamroził ceny, a i tak ma prawie 100-proc. inflację
 - [https://businessinsider.com.pl/gospodarka/ten-kraj-zamrozil-ceny-a-i-tak-ma-prawie-100-proc-inflacje/jy54jyd](https://businessinsider.com.pl/gospodarka/ten-kraj-zamrozil-ceny-a-i-tak-ma-prawie-100-proc-inflacje/jy54jyd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:15:01+00:00
 - user: None

Inflacja w 2022 r. w Argentynie wyniosła niemal 95 proc., najwięcej od 1991 r. – podały władze w Buenos Aires. Rząd ostatnio mocno walczy z tym zjawiskiem np. poprzez zamrażanie cen kluczowych produktów.

## W 2022 r. Polacy zużyli o wiele mniej gazu
 - [https://businessinsider.com.pl/gospodarka/w-2022-r-polacy-zuzyli-o-wiele-mniej-gazu/cn150hs](https://businessinsider.com.pl/gospodarka/w-2022-r-polacy-zuzyli-o-wiele-mniej-gazu/cn150hs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 06:00:05+00:00
 - user: None

16-17 proc. — o tyle spadło zużycie gazu ziemnego w 2022 r. według wstępnych szacunków resort klimatu i środowiska. Ministerstwo zapewnia, że system jest przygotowany na najmroźniejszą zimę, a ryzyka wprowadzenia ograniczeń w poborze gazu na dziś nie ma.

## Idą zmiany dla klientów telekomów. Niektóre budzą kontrowersje
 - [https://businessinsider.com.pl/prawo/ida-zmiany-dla-klientow-telekomow-niektore-budza-kontrowersje/m4jz3ce](https://businessinsider.com.pl/prawo/ida-zmiany-dla-klientow-telekomow-niektore-budza-kontrowersje/m4jz3ce)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:48:00+00:00
 - user: None

Operatorzy zwrócą niewykorzystane pieniądze za prepaid, ograniczą stawki za usługi doliczane do rachunku, a rozwiązanie umowy będzie tańsze — pisze w piątek "Rzeczpospolita".

## To teraz najważniejsze na świecie dane ekonomiczne i na szczęście wyglądają dobrze. Inflacja w USA znowu spadła
 - [https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-13012023/lvwrsnq](https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-13012023/lvwrsnq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:46:16+00:00
 - user: None

Inflacja w USA nadal spada, a rynek coraz bardziej wierzy w szybkie zakończenie podwyżek stóp procentowych w Stanach, co powinno być korzystne dla nas wszystkich. U nas członkowie RPP coraz chętnie wypowiadają się na temat obniżania stóp procentowych jeszcze w tym roku. Obniża nam się także dług publiczny w relacji do PKB. Podniosła się za to rynkowa wycena Allegro po tym, jak z Polski postanowiła zniknąć platforma zakupowa Shopee. Rząd z kolei chce skorygować wysokie podwyżki cen za ogrzewanie, bo przepisy uchwalone w tej sprawie pół roku temu okazały się nieszczelne. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Włochy chcą "przekazać" Ukrainie dwa swoje porty
 - [https://businessinsider.com.pl/wiadomosci/wlochy-chca-przekazac-ukrainie-dwa-swoje-porty/drn80s5](https://businessinsider.com.pl/wiadomosci/wlochy-chca-przekazac-ukrainie-dwa-swoje-porty/drn80s5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:43:26+00:00
 - user: None

Szefowa włoskiego rządu Giorgia Meloni zapowiedziała, że niebawem chce pojechać do Kijowa. Rzym ogłasza też, że chce pomagać Ukrainie gospodarczo i militarnie, a nawet zamierza "przekazać" temu krajowi porty w Trieście i Weronie.

## Shopee znika z Polski, sprzedawcy mają problem z odzyskaniem pieniędzy
 - [https://businessinsider.com.pl/finanse/handel/shopee-znika-z-polski-sprzedawcy-maja-problem-z-odzyskaniem-pieniedzy/r5hc88p](https://businessinsider.com.pl/finanse/handel/shopee-znika-z-polski-sprzedawcy-maja-problem-z-odzyskaniem-pieniedzy/r5hc88p)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:31:03+00:00
 - user: None

W czwartek platforma Shopee zaskoczyła wszystkich — również swoich pracowników w Polsce — i przekazała, że 13 stycznia wycofuje się z kraju. Teraz znamy więcej szczegółów wyjścia. Część sprzedawców skarży się, że nie może wypłacić środków.

## Rzecznik PiS broni przyjaciółki Kaczyńskiego w Orlenie. "Wiele spółek o nią zabiegało"
 - [https://businessinsider.com.pl/gospodarka/rzecznik-pis-broni-przyjaciolki-kaczynskiego-w-orlenie/c5198q5](https://businessinsider.com.pl/gospodarka/rzecznik-pis-broni-przyjaciolki-kaczynskiego-w-orlenie/c5198q5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:21:34+00:00
 - user: None

Wieloletnia przyjaciółka Jarosława Kaczyńskiego trafiła do rady nadzorczej Orlenu, jednak rzecznik PiS Rafał Bochenek nie widzi w tym nic dziwnego. "Wiele spółek o nią zabiegało" – zapewnia.

## Dojazd do pracy dwa razy droższy niż bilet miesięczny w Warszawie. To oni na nowych cenach stracą najwięcej
 - [https://businessinsider.com.pl/gospodarka/dwa-razy-drozej-niz-w-warszawie-kto-na-drogich-biletach-traci-najbardziej/w3kv093](https://businessinsider.com.pl/gospodarka/dwa-razy-drozej-niz-w-warszawie-kto-na-drogich-biletach-traci-najbardziej/w3kv093)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:10:35+00:00
 - user: None

W internecie wrze z powodu podwyżek cen biletów PKP Intercity, a w metropoliach trwają burzliwe dyskusje o droższych biletach autobusowych. Okazuje się jednak, że najboleśniejszy efekt kryzysu, w którym znalazł się polski transport publiczny, może tkwić zupełnie gdzie indziej. I to nie mieszkańcy największych miast są na najbardziej straconej pozycji.

## Czas na pierwszą poważną ocenę rządu w 2023 r. Data niefortunna, a problemy się kumulują
 - [https://businessinsider.com.pl/gospodarka/rating-polski-wedlug-fitch-czas-na-pierwsza-powazna-ocene-rzadu-w-2023-r/s2704hy](https://businessinsider.com.pl/gospodarka/rating-polski-wedlug-fitch-czas-na-pierwsza-powazna-ocene-rzadu-w-2023-r/s2704hy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:01:00+00:00
 - user: None

Sytuacji w Polsce przygląda się jedna z trzech największych agencji ratingowych. W centrum uwagi powinien znaleźć się spór o KPO i perspektywy spowalniającej gospodarki. Ekonomiści są dobrej myśli w sprawie samej oceny punktowej, choć zwracają uwagę na skumulowanie wielu negatywnych czynników, które mogłyby przechylić szalę na naszą niekorzyść. Wskazują, co mogłoby być takim pretekstem.

## Jarosław Kaczyński chce wiedzieć, co się dzieje w Orlenie. Wysłał Obajtkowi rewizora
 - [https://businessinsider.com.pl/wiadomosci/jaroslaw-kaczynski-bedzie-patrzyl-prezesowi-orlenu-na-rece/rg0c9cx](https://businessinsider.com.pl/wiadomosci/jaroslaw-kaczynski-bedzie-patrzyl-prezesowi-orlenu-na-rece/rg0c9cx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 05:00:00+00:00
 - user: None

Powołanie Janiny Goss do rady nadzorczej PKN Orlen budzi duże emocje w PiS. To bliska przyjaciółka Jarosława Kaczyńskiego, a jej wejście do władz paliwowego giganta kierowanego przez Daniela Obajtka odbierane jest jako sygnał, że prezes chce wiedzieć, co naprawdę dzieje się w Orlenie. Nasi rozmówcy z kręgów rządowych twierdzą, że to dowód na spadek zaufania do prezesa Orlenu po ostatnim zamieszaniu m.in. wokół fuzji z Lotosem czy cen paliw.

## Pora przywyknąć do drożyzny. Ten sondaż mówi wszystko [TYLKO U NAS]
 - [https://businessinsider.com.pl/gospodarka/polacy-nie-wierza-ze-ceny-w-sklepach-kiedykolwiek-sie-zatrzymaja-tylko-u-nas/mjl4fgw](https://businessinsider.com.pl/gospodarka/polacy-nie-wierza-ze-ceny-w-sklepach-kiedykolwiek-sie-zatrzymaja-tylko-u-nas/mjl4fgw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-13 04:54:00+00:00
 - user: None

Do drożyzny trzeba się powoli przyzwyczaić, bo ceny jeszcze bardzo długo nie spadną. A już na pewno nie w tym roku. Tak twierdzi ponad 60 proc. Polaków — wynika z badania przeprowadzonego przez UCE Research dla Business Insider Polska. Ale są też tacy, którzy już dziś w sklepach widzą pierwsze obniżki. To statystycznie co czterdziesty z nas. — Być może to są konsumenci, którzy nie do końca precyzyjnie potrafią ocenić sytuację — komentuje dr Krzysztof Łuczak, ekspert rynku handlowego i główny ekonomista grupy BLIX.
