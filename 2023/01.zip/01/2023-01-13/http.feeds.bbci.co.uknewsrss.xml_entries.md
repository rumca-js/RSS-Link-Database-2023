# Source BBC, Source URL:http://feeds.bbci.co.uk/news/rss.xml, Source language: en-US

## Lisa Marie to be buried next to son at Graceland
 - [https://www.bbc.co.uk/news/world-us-canada-64271642?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64271642?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 23:53:26+00:00
 - user: None

The singer was the only child of the "King of Rock 'n' Roll", Elvis Presley.

## Manchester United v Manchester City preview: Team news, match facts and prediction
 - [https://www.bbc.co.uk/sport/football/64195236?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64195236?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 23:07:43+00:00
 - user: None

Manchester United host Manchester City on Saturday in what could be one of their most evenly matched Premier League encounters in years.

## Lithuanian gas pipeline hit by large explosion
 - [https://www.bbc.co.uk/news/world-europe-64267736?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64267736?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 22:48:00+00:00
 - user: None

Latvia's defence minster says sabotage could not be ruled out as a cause of the blast near its border.

## Holidaymakers spending more as bookings rise
 - [https://www.bbc.co.uk/news/business-64234234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64234234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 22:25:29+00:00
 - user: None

People planning a trip abroad for the summer are splashing out despite incomes being hit by inflation.

## Aston Villa 2-1 Leeds United: Leon Bailey has hand in two goals as Villa win
 - [https://www.bbc.co.uk/sport/football/64182802?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64182802?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 22:08:11+00:00
 - user: None

Leon Bailey has a hand in both goals as Aston Villa start the Premier League weekend with victory over Leeds.

## Hearts 1-0 St Mirren: Barrie McKay goal hands Hearts victory over St Mirren
 - [https://www.bbc.co.uk/sport/football/62784247?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/62784247?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 22:04:34+00:00
 - user: None

Hearts move six points clear of Aberdeen in fourth place in the Scottish Premiership with a narrow win over St Mirren at a packed Tynecastle Stadium.

## Heineken Champions Cup: Clermont Auvergne 29-44 Leicester Tigers
 - [https://www.bbc.co.uk/sport/rugby-union/64250796?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64250796?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 21:59:19+00:00
 - user: None

Leicester qualify for the Heineken Champions Cup last 16 with a game to spare as they return to winning ways at Clermont.

## Prince Harry: Family would never forgive me if I told all
 - [https://www.bbc.co.uk/news/uk-64269194?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64269194?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 21:58:54+00:00
 - user: None

In a new interview with the Daily Telegraph, the prince says he wants an apology for his wife, Meghan.

## Manchester United sign striker Wout Weghorst on loan for the rest of season
 - [https://www.bbc.co.uk/sport/football/64231986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64231986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 21:00:52+00:00
 - user: None

Manchester United sign Netherlands striker Wout Weghorst on loan for the rest of the season.

## Covid: Nurses who died probably caught virus at work
 - [https://www.bbc.co.uk/news/uk-wales-64269639?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64269639?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 20:21:44+00:00
 - user: None

Coroner Graeme Hughes concludes Gareth Roberts and Dominga David died of industrial disease.

## Usain Bolt: Investigation opened after ex-Olympic champion spots 'discrepancies' in investments
 - [https://www.bbc.co.uk/sport/athletics/64268534?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/64268534?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 20:12:27+00:00
 - user: None

An investigation is looking into allegations of fraud at a company that looks after Usain Bolt's investments.

## Four unanswered questions about the Biden classified documents
 - [https://www.bbc.co.uk/news/world-us-canada-64267983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64267983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 20:02:23+00:00
 - user: None

Pressure is mounting on the president to give further details about material found at his home and former office.

## Lützerath: Greta Thunberg joins 'Pinky' and 'Brain' tunnel protest
 - [https://www.bbc.co.uk/news/world-europe-64261197?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64261197?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 19:22:48+00:00
 - user: None

The activist condemns police as German protesters try to stop a coal mine from swallowing up a village.

## Scottish NHS strikes on hold while pay offer negotiated
 - [https://www.bbc.co.uk/news/uk-scotland-64266800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64266800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 18:57:48+00:00
 - user: None

The GMB and Royal College of Nursing will not call strikes while negotiations take place on the 2023 pay offer.

## UFO reports by US troops skyrocket to over 500
 - [https://www.bbc.co.uk/news/world-us-canada-64252340?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64252340?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 18:36:32+00:00
 - user: None

The number of encounters has climbed from the 144 compiled by a top US spy agency in its 2021 report.

## Newport News: Staff were alerted six-year-old may have had a weapon
 - [https://www.bbc.co.uk/news/world-us-canada-64252261?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64252261?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 18:29:53+00:00
 - user: None

School chief says at least one staff member was alerted the child had a gun before the shooting.

## UK weather: More flood warnings ahead of colder spell
 - [https://www.bbc.co.uk/news/uk-64269187?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64269187?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 18:27:20+00:00
 - user: None

More than 80 flood warnings are in place across the UK, as a cold weather alert is also issued.

## Ezra Miller: The Flash star pleads guilty to trespass but avoids jail
 - [https://www.bbc.co.uk/news/entertainment-arts-64269515?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64269515?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 17:45:15+00:00
 - user: None

The Flash star avoids being sent to prison after agreeing a plea deal over an alleged burglary.

## Masters 2023: Judd Trump beats Barry Hawkins to reach semi-final
 - [https://www.bbc.co.uk/sport/snooker/64266390?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/64266390?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 17:44:12+00:00
 - user: None

Former champion Judd Trump comes from behind to beat Barry Hawkins 6-5 and reach the semi-finals of the Masters.

## Natalie McNally: Man arrested on suspicion of murder of Lurgan woman
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64251556?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64251556?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 17:43:39+00:00
 - user: None

Ms McNally, 32, was 15 weeks pregnant when she was stabbed on 18 December at her home in Lurgan.

## Kamila Valieva: Russia clears figure skater over doping case
 - [https://www.bbc.co.uk/sport/winter-sports/64268527?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-sports/64268527?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 16:46:22+00:00
 - user: None

Figure skater Kamila Valieva bore "no fault or negligence" for a positive doping test, Russia's anti-doping agency finds.

## Hero Cup: Continental Europe lead Great Britain and Ireland 3-2 after opening day
 - [https://www.bbc.co.uk/sport/golf/64267165?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/64267165?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 16:15:00+00:00
 - user: None

Continental Europe lead Great Britain and Ireland 3-2 after the opening day of the inaugural Hero Cup in Abu Dhabi.

## Byron Burger chain owner shuts sites and axes jobs
 - [https://www.bbc.co.uk/news/business-64260312?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64260312?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 16:13:25+00:00
 - user: None

The company will close nearly half of its restaurants and cut 218 staff in a further restructure.

## Shakira diss track breaks Latin YouTube viewing records
 - [https://www.bbc.co.uk/news/entertainment-arts-64267366?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64267366?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 15:57:23+00:00
 - user: None

The song about ex-partner Gerard Pique gained over 63m views in the first day of it being online.

## Freeports: What are they and will they help the economy?
 - [https://www.bbc.co.uk/news/uk-politics-55819489?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-55819489?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 15:36:39+00:00
 - user: None

Two freeports have been named in Scotland, adding to the eight already in place in England.

## BBC broadcaster Gow suffers 'serious stroke'
 - [https://www.bbc.co.uk/news/uk-england-hampshire-64261533?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-hampshire-64261533?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 15:31:27+00:00
 - user: None

Jennie Gow, 45, says it will take some time for her to return to work after the stroke two weeks ago.

## US renames five places that used racist slur for Native Americans
 - [https://www.bbc.co.uk/news/world-us-canada-64252259?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64252259?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 15:23:10+00:00
 - user: None

The move is part of wider efforts to remove the derogatory term from hundreds of geographic sites.

## Brighton: Leandro Trossard dropped for Liverpool game because of poor attitude, says Roberto De Zerbi
 - [https://www.bbc.co.uk/sport/football/64267013?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64267013?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 15:15:19+00:00
 - user: None

Leandro Trossard has been dropped from the Brighton squad for Saturday's game against Liverpool because of his poor attitude, says boss Roberto De Zerbi.

## Is fan violence on the up? Supporter views on attending football matches
 - [https://www.bbc.co.uk/sport/football/64259799?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64259799?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 14:50:03+00:00
 - user: None

As a report shows more arrests were made at football matches last year than the year before, BBC Sport hears from football fans about their experiences of attending matches.

## Nicola Sturgeon and Rishi Sunak's smiles mask a deep political divide
 - [https://www.bbc.co.uk/news/uk-scotland-64266046?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64266046?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 14:34:51+00:00
 - user: None

There were cordial talks on the PM's visit to Scotland, but battles could be looming on a number of issues.

## Lisa Marie Presley: How she turned personal tragedy into hope
 - [https://www.bbc.co.uk/news/entertainment-arts-64260769?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64260769?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 14:05:25+00:00
 - user: None

The late singer and daughter of Elvis Presley wrote and sang about her grief and struggles.

## California’s devastating storm in maps and charts
 - [https://www.bbc.co.uk/news/64265510?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/64265510?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:36:59+00:00
 - user: None

The state is being battered by storms with more destruction expected in the coming days.

## Mark Brown: 'Pure evil' killer gets life sentence for women's murders
 - [https://www.bbc.co.uk/news/uk-england-sussex-64213744?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-sussex-64213744?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:29:46+00:00
 - user: None

Mark Brown still claims he did not kill Leah Ware and that she is still alive.

## Corbyn-era legal costs could blunt Labour general election campaign
 - [https://www.bbc.co.uk/news/uk-politics-64248136?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64248136?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:28:28+00:00
 - user: None

A long-running internal feud may prove costly in the run to the next election, writes Iain Watson.

## Benjamin Mendy found not guilty of six counts of rape
 - [https://www.bbc.co.uk/news/uk-england-manchester-63677581?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63677581?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:25:58+00:00
 - user: None

The prosecution is seeking a retrial on two counts the jury could not reach verdicts on.

## Benjamin Mendy acquitted but 'will never escape the accusations'
 - [https://www.bbc.co.uk/news/uk-england-manchester-63857493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-63857493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:22:17+00:00
 - user: None

Despite his acquittal on most charges, the footballer's lawyer says he cannot return to his former life.

## Kevin Spacey pleads not guilty to sexual assault charges
 - [https://www.bbc.co.uk/news/uk-64259879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64259879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:21:10+00:00
 - user: None

The US actor was accused of seven sexual offences against a man in the early 2000s.

## Beth Mead's mum June dies after 'long and brave battle with ovarian cancer'
 - [https://www.bbc.co.uk/sport/football/64261789?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64261789?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 13:02:27+00:00
 - user: None

England star Beth Mead has announced her mother June died on 7 January after "a long and brave battle with ovarian cancer".

## Williams appoint James Vowles as new team principal
 - [https://www.bbc.co.uk/sport/formula1/64260044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/64260044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:37:32+00:00
 - user: None

Williams appoint former Mercedes head of strategy James Vowles as their new team principal.

## Historic wild camping tradition outlawed on part of Dartmoor
 - [https://www.bbc.co.uk/news/science-environment-64238116?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64238116?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:37:05+00:00
 - user: None

Wild camping on part of a Devon moor has been ruled illegal by the High Court unless permission given.

## Lewis Capaldi to share stage with students at Glasgow Hydro show
 - [https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64263283?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-glasgow-west-64263283?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:30:14+00:00
 - user: None

The Scottish singer has invited students from his old college to share the stage in Glasgow.

## Novak Djokovic and Nick Kyrgios entertain Melbourne in charity match
 - [https://www.bbc.co.uk/sport/av/tennis/64264653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/tennis/64264653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:07:11+00:00
 - user: None

Nick Kyrgios beats Novak Djokovic in charity warm-up match ahead of the Australian Open.

## Man fined for throwing egg towards King Charles III in Luton
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-64263384?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-64263384?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:04:35+00:00
 - user: None

A court hears Harry May thought the monarch's visit to the "poor area" of Luton was in "bad taste".

## Man jailed for life for murder in oldest double jeopardy case
 - [https://www.bbc.co.uk/news/uk-england-london-64263303?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64263303?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 12:03:18+00:00
 - user: None

Dennis McGrory was initially cleared of the murder of a teenager he raped and strangled in 1975.

## Ros Atkins on… social care’s impact on the NHS crisis
 - [https://www.bbc.co.uk/news/health-64258235?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64258235?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 11:52:04+00:00
 - user: None

Ros Atkins explains how the crisis in the NHS connects to long-term issues within social care.

## Adidas loses stripes trademark battle with designer
 - [https://www.bbc.co.uk/news/world-us-canada-64261616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64261616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 11:34:29+00:00
 - user: None

The sportswear giant argued the use of four parallel stripes was too similar to its logo.

## Joelinton: Newcastle United boss Eddie Howe unsure of picking striker after drink-driving charge
 - [https://www.bbc.co.uk/sport/football/64261234?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64261234?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 11:09:16+00:00
 - user: None

Newcastle United boss Eddie Howe says Joelinton's drink-driving charge came as a "shock" and he is unsure about picking the striker against Fulham on Sunday.

## Russia claims control of salt mine town Soledar
 - [https://www.bbc.co.uk/news/world-europe-64263119?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64263119?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 10:48:00+00:00
 - user: None

Russia says it has taken control of Ukrainian salt mine town Soledar after a months-long battle, calling it a "crucial step"

## Man charged with Elle Edwards murder appears in court
 - [https://www.bbc.co.uk/news/uk-england-merseyside-64260842?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-64260842?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 10:43:22+00:00
 - user: None

The 26-year-old beautician died in a shooting at a Merseyside pub on Christmas Eve.

## Australian Open: Novak Djokovic receives warm welcome on Melbourne return
 - [https://www.bbc.co.uk/sport/tennis/64258638?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64258638?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 10:11:54+00:00
 - user: None

Novak Djokovic receives an adoring welcome on his first public return to the Australian Open for a practice match with home favourite Nick Kyrgios.

## Arthur Labinjo-Hughes: Children facing 'significant harm' by Solihull Council
 - [https://www.bbc.co.uk/news/uk-england-birmingham-64261393?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-birmingham-64261393?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 10:00:46+00:00
 - user: None

An Ofsted probe after Arthur Labinjo-Hughes's death finds Solihull children's services inadequate.

## Wolves close to signing Nice midfielder Mario Lemina
 - [https://www.bbc.co.uk/sport/football/64259469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64259469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 09:39:11+00:00
 - user: None

Wolves are set to sign Nice midfielder Mario Lemina for fee believed to be about €11m (£9.7m).

## British drone user raises shark alarm in Australia
 - [https://www.bbc.co.uk/news/uk-england-northamptonshire-64256341?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-northamptonshire-64256341?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 09:28:22+00:00
 - user: None

The expat spotted a great white swimming close to a packed beach and called to have it evacuated.

## Caterham dog attack: Police investigate after woman killed and another injured
 - [https://www.bbc.co.uk/news/uk-england-surrey-64260916?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-surrey-64260916?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 09:20:21+00:00
 - user: None

Officers ask people "not to speculate" on the circumstances of the fatal attack in Caterham.

## Rishi Sunak concerned about impact of gender reforms
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64260502?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64260502?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 08:53:05+00:00
 - user: None

The PM says he is awaiting final advice before deciding whether to block Scotland's gender reforms.

## Premier League: Assessing a key weekend in the battle against relegation
 - [https://www.bbc.co.uk/sport/football/64227876?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64227876?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 08:07:29+00:00
 - user: None

As six of the bottom eight sides face each other this weekend, could this be a big weekend in the fight for Premier League survival?

## Australian Open 2023: Iga Swiatek looking forward after successful 2022 season
 - [https://www.bbc.co.uk/sport/tennis/64245614?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64245614?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 08:00:04+00:00
 - user: None

Iga Swiatek says she is not thinking about matching her stunning 2022 season as she aims to add the Australian Open title to her achievements.

## UK economy beats expectations with November growth
 - [https://www.bbc.co.uk/news/business-64238309?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64238309?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 07:25:44+00:00
 - user: None

The UK economy grew by 0.1% in November, according to the Office for National Statistics.

## Fukushima nuclear disaster: Japan to release radioactive water into sea this year
 - [https://www.bbc.co.uk/news/world-asia-64259043?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64259043?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 07:12:04+00:00
 - user: None

Tokyo plans to release a million tonnes of water contaminated by the destroyed Fukushima plant.

## Chocolate's texture has been examined by the University of Leeds
 - [https://www.bbc.co.uk/news/uk-england-leeds-64255991?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-64255991?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 06:38:58+00:00
 - user: None

Healthier chocolate that feels just as good to eat could be developed, researchers say.

## Rape survivor secretly recorded her abuser's confession
 - [https://www.bbc.co.uk/news/uk-scotland-64248542?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64248542?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 06:30:36+00:00
 - user: None

Ellie Wilson said she released the confession to show how "manipulative" abusers can be.

## Ukraine defence minister: We are a de facto member of Nato alliance
 - [https://www.bbc.co.uk/news/world-europe-64255249?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64255249?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 06:23:27+00:00
 - user: None

Oleksii Reznikov's comments will provoke Russia, which has framed the war as a battle with the West.

## Claire Rafferty: Former Lioness says players should not be weighed routinely
 - [https://www.bbc.co.uk/sport/football/64250020?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64250020?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 06:17:09+00:00
 - user: None

Former England defender Claire Rafferty says players should not be routinely weighed as it is not healthy.

## Hunting for Nazi gold in a Dutch village
 - [https://www.bbc.co.uk/news/world-europe-64254209?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64254209?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 06:05:04+00:00
 - user: None

A 76-year-old sketch map drawn by a German soldier shows where he said treasure had been buried.

## Joshimath: 'From two-storey house to sharing a room with five'
 - [https://www.bbc.co.uk/news/world-asia-india-64258918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-64258918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 05:58:17+00:00
 - user: None

Families in the Himalayan town of Joshimath, which is sinking, say they yearn to go back to their homes.

## Online Safety Bill changes 'not ruled out' - culture secretary
 - [https://www.bbc.co.uk/news/uk-politics-64258424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64258424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 05:32:46+00:00
 - user: None

Tory rebels want to make social media bosses criminally liable if they fail to protect children.

## KSI says Andrew Tate's Top G style is cringey
 - [https://www.bbc.co.uk/news/newsbeat-64249874?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64249874?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 05:20:57+00:00
 - user: None

The YouTuber tells BBC Newsbeat he wants to use his own influential platform in a positive way.

## Itaewon crowd crush: Senior officials spared blame in report
 - [https://www.bbc.co.uk/news/world-asia-64258669?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64258669?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 03:55:40+00:00
 - user: None

One relative said blaming local officials was "cutting off the off the lizard's tail to spare the head".

## Two-month gap in telling public may haunt Biden
 - [https://www.bbc.co.uk/news/world-us-canada-64257109?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64257109?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 02:57:31+00:00
 - user: None

The distinctions between the inquiry into Mr Biden and a parallel one into Donald Trump may pass most Americans by.

## Biden visitor logs sought after documents find
 - [https://www.bbc.co.uk/news/world-us-canada-64257918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64257918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 02:41:22+00:00
 - user: None

The president's opponents say they need to know who has access to him as "a clear matter of national security".

## TommyInnit: Life as one of the world's top content creators
 - [https://www.bbc.co.uk/news/entertainment-arts-64053610?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64053610?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 01:30:38+00:00
 - user: None

YouTube star Tom Simons talks about the challenges facing content creators and about his future.

## 'Forever chemicals' still in use in UK make-up
 - [https://www.bbc.co.uk/news/science-environment-64192516?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64192516?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 01:08:52+00:00
 - user: None

PFAS substances linked with cancer discovered in UK cosmetics on day EU sets out to ban them.

## Christmas Eve pub shooting: Man charged with Elle Edwards murder
 - [https://www.bbc.co.uk/news/uk-england-64258499?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-64258499?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 01:02:17+00:00
 - user: None

The 26-year-old was shot outside outside The Lighthouse in Wallasey.

## Smart appliances could stop working after two years, says Which?
 - [https://www.bbc.co.uk/news/technology-64249388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64249388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:52:00+00:00
 - user: None

The consumer champion found "hardly any" brands came close to matching a device's expected lifespan.

## Africa's week in pictures: 6-12 January 2023
 - [https://www.bbc.co.uk/news/world-africa-64248968?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-africa-64248968?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:19:11+00:00
 - user: None

A selection of the best photos from across Africa this week.

## Consider statins for millions more people in England, NHS told
 - [https://www.bbc.co.uk/news/health-64251636?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64251636?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:12:39+00:00
 - user: None

Cholesterol-lowering pills could help more people cut their risk of heart attacks and stroke, guidelines say.

## The Papers: 'Life-saving statin handout' and 'Grenfell agony'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64257766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64257766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:09:15+00:00
 - user: None

Friday's papers cover calls for more people to be put on statins and Grenfell firefighters with cancer.

## Does easing US inflation point the way for the world?
 - [https://www.bbc.co.uk/news/business-64030276?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64030276?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:06:59+00:00
 - user: None

It may be good news for the rest of the world if price increases in the US continue to slow.

## Starmer to urge Sunak to put NI above 'Brexit purity cult'
 - [https://www.bbc.co.uk/news/uk-northern-ireland-64256883?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-northern-ireland-64256883?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-13 00:01:30+00:00
 - user: None

Labour's leader will urge Rishi Sunak to fix minds on a resolution to the Northern Ireland Protocol.
