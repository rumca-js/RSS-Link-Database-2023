# Source The Guardian - World, Source URL:https://www.theguardian.com/world/rss, Source language: en-US

## Soaked California prepares for more flooding as thousands remain without power
 - [https://www.theguardian.com/us-news/2023/jan/13/california-storms-flooding-rain-weather](https://www.theguardian.com/us-news/2023/jan/13/california-storms-flooding-rain-weather)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 23:09:22+00:00
 - user: None

<p>Officials urge residents to remain on guard for further damage, with 6,000 under evacuation orders</p><p>With rain-soaked California expected to see several more rounds of stormy weather over the weekend and into next week, state and federal officials pleaded with residents on Friday to stay alert to the possibility of more flooding and damage.</p><p>A series of storms has walloped the state since late December, leaving at least 19 people dead. On Friday, 6,000 people were under evacuation orders and another 20,000 households were without power, said Nancy Ward, the director of the California governor’s office of emergency services.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/california-storms-flooding-rain-weather">Continue reading...</a>

## Australia live news: Vatican mass for George Pell; parts of Queensland on flood alert
 - [https://www.theguardian.com/australia-news/live/2023/jan/14/australia-live-news-vatican-mass-george-pell-nsw-premier-dominic-perrottet-battles-internal-enemies](https://www.theguardian.com/australia-news/live/2023/jan/14/australia-live-news-vatican-mass-george-pell-nsw-premier-dominic-perrottet-battles-internal-enemies)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 22:07:38+00:00
 - user: None

<p>The late Australian cardinal will be honoured with a funeral mass at St Peter’s in Rome later today</p><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Morning. <strong>Graham Readfearn</strong> with you now. Thanks to <strong>Martin Farrer</strong> for covering the first hour of the day.</p><p>The Vatican mass for <strong>George Pell</strong> will be held at 11.30am local time in Rome today, which is 9.30pm AEDT today.</p> <a href="https://www.theguardian.com/australia-news/live/2023/jan/14/australia-live-news-vatican-mass-george-pell-nsw-premier-dominic-perrottet-battles-internal-enemies">Continue reading...</a>

## Dallas zoo closes after clouded leopard escapes its enclosure
 - [https://www.theguardian.com/us-news/2023/jan/13/dallas-zoo-closes-leopard-escapes](https://www.theguardian.com/us-news/2023/jan/13/dallas-zoo-closes-leopard-escapes)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 21:51:58+00:00
 - user: None

<p>The big cat, Nova, weighs around 25lb and zoo officials speculate is likely still on the grounds and hiding in the trees</p><p>The Dallas zoo was closed on Friday as staff searched for a clouded leopard that escaped its enclosure.</p><p>The zoo issued a “code blue”, signaling a non-dangerous animal was not in its habitat.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/dallas-zoo-closes-leopard-escapes">Continue reading...</a>

## Republicans launch investigations into Biden’s handling of classified papers
 - [https://www.theguardian.com/us-news/2023/jan/13/republicans-investigations-biden-classified-documents](https://www.theguardian.com/us-news/2023/jan/13/republicans-investigations-biden-classified-documents)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 21:03:53+00:00
 - user: None

<p>House judiciary committee makes announcement after special counsel appointed to look into the case</p><p>Republicans on the House judiciary committee on Friday announced an investigation into the discovery of classified documents at Joe Biden’s Delaware home and former office in Washington DC.</p><p>The GOP representatives, newly in control of committees after their party took the House last November, made their move a day after the attorney general, Merrick Garland, announced the appointment of a special counsel to investigate the matter.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/republicans-investigations-biden-classified-documents">Continue reading...</a>

## Six-year-old Virginia boy’s backpack was searched before he shot his teacher
 - [https://www.theguardian.com/us-news/2023/jan/13/virginia-teacher-shooting-abigail-zwerner-child-backpack-searched](https://www.theguardian.com/us-news/2023/jan/13/virginia-teacher-shooting-abigail-zwerner-child-backpack-searched)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 20:56:18+00:00
 - user: None

<p>Police say a school employee was notified of a possible gun and searched the student’s backpack but did not find it</p><p>Administrators at the Virginia school where a six-year-old boy <a href="https://www.theguardian.com/us-news/2023/jan/09/virginia-teacher-shot-newport-news-richneck-elementary-abby-zwerner">shot his teacher</a> learned the child may have had a weapon before the shooting but did not find the 9mm handgun despite searching his bag, the school system’s superintendent said.</p><p>The teacher, Abigail Zwerner, 25, was shot in the chest, suffering injuries that were initially considered to be life-threatening. Her condition has improved and she has been reported in stable condition.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/virginia-teacher-shooting-abigail-zwerner-child-backpack-searched">Continue reading...</a>

## Release of Bolsonaro spending records shows love of high living and … ice-cream
 - [https://www.theguardian.com/world/2023/jan/13/release-of-bolsonaro-spending-records-shows-love-of-high-living-and-ice-cream](https://www.theguardian.com/world/2023/jan/13/release-of-bolsonaro-spending-records-shows-love-of-high-living-and-ice-cream)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 20:07:42+00:00
 - user: None

<p>Brazilian government overturns former president’s 100-year ban to publish credit card records</p><p>Brazil’s new government has released the personal spending accounts of the former president <a href="https://www.theguardian.com/world/jair-bolsonaro">Jair Bolsonaro</a>, revealing the far-right leader’s apparent penchant for expensive hotels, big meals out – and ice-cream.</p><p>Bolsonaro, who <a href="https://www.theguardian.com/world/2022/nov/01/jair-bolsonaro-brazil-election-silence-lula">lost his re-election bid in October</a>, once boasted he did not withdraw “a single penny” from the corporate credit cards given to him and his closest advisers.</p> <a href="https://www.theguardian.com/world/2023/jan/13/release-of-bolsonaro-spending-records-shows-love-of-high-living-and-ice-cream">Continue reading...</a>

## Wales coroner rules nurses’ Covid deaths as industrial disease
 - [https://www.theguardian.com/world/2023/jan/13/wales-coroner-rules-nurses-covid-deaths-as-industrial-disease](https://www.theguardian.com/world/2023/jan/13/wales-coroner-rules-nurses-covid-deaths-as-industrial-disease)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 19:20:41+00:00
 - user: None

<p>Gareth Roberts, 65, and Domingo David, 63, most likely to have caught virus from colleagues or patients</p><p>The deaths of two nurses from Covid-19 in the early days of the pandemic have been ruled as industrial disease.</p><p>Gareth Roberts, 65, of Aberdare, and Domingo David, 63, of Penarth, were found to have been most likely to have contracted the virus from colleagues or patients while working for hospitals under the Cardiff and Vale University Health Board.</p> <a href="https://www.theguardian.com/world/2023/jan/13/wales-coroner-rules-nurses-covid-deaths-as-industrial-disease">Continue reading...</a>

## What happened in the Russia-Ukraine war this week? Catch up with the must-read news and analysis
 - [https://www.theguardian.com/world/2023/jan/14/what-happened-in-the-russia-ukraine-war-this-week-catch-up-with-the-must-read-news-and-analysis](https://www.theguardian.com/world/2023/jan/14/what-happened-in-the-russia-ukraine-war-this-week-catch-up-with-the-must-read-news-and-analysis)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 19:00:23+00:00
 - user: None

<p>The battle for Soledar; Putin reshuffles his military top brass again;  west considers giving tanks to Ukraine</p><ul><li><strong><a href="https://www.theguardian.com/world/ukraine">See all our Ukraine war coverage</a></strong></li></ul><p>Every week we wrap up the must-reads from our coverage of the <a href="https://www.theguardian.com/world/ukraine">Ukraine</a> war, from news and features to analysis, visual guides and opinion.</p> <a href="https://www.theguardian.com/world/2023/jan/14/what-happened-in-the-russia-ukraine-war-this-week-catch-up-with-the-must-read-news-and-analysis">Continue reading...</a>

## Landlord guidance about health risks of mould to be reviewed, ministers say
 - [https://www.theguardian.com/society/2023/jan/13/landlord-guidance-health-risks-mould-review-awaab-ishak](https://www.theguardian.com/society/2023/jan/13/landlord-guidance-health-risks-mould-review-awaab-ishak)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 18:39:27+00:00
 - user: None

<p>Move comes after coroner instructed government to take action after death of two-year-old Awaab Ishak</p><ul><li><a href="https://www.theguardian.com/society/2023/jan/13/the-council-inspectors-tackling-harrows-deathtrap-homes">The council inspectors tackling Harrow’s illegal, deathtrap homes</a></li></ul><p>Ministers have announced a rapid review of guidance to landlords about health risks from damp and mould after the death of two-year-old Awaab Ishak.</p><p>The housing and health secretaries, Michael Gove and Steve Barclay, said new guidance would be published by the summer with the UK Health Security Agency involved in the review.</p> <a href="https://www.theguardian.com/society/2023/jan/13/landlord-guidance-health-risks-mould-review-awaab-ishak">Continue reading...</a>

## Inquest hears isolated Japanese family kept sister’s body at home
 - [https://www.theguardian.com/uk-news/2023/jan/13/inquest-hears-isolated-japanese-family-kept-sisters-body-at-yorkshire-home](https://www.theguardian.com/uk-news/2023/jan/13/inquest-hears-isolated-japanese-family-kept-sisters-body-at-yorkshire-home)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 18:05:05+00:00
 - user: None

<p>Coroner gives open verdict after cause of 49-year-old’s death undetermined following discovery of partially-mummified body</p><p>A Japanese woman living an isolated, insular life with her brother, sister and mother in North Yorkshire lay dead for weeks while her family bought surgical spirit, convinced she was still alive.</p><p>An inquest on Friday heard that the partially-mummified body of 49-year-old Rina Yasutake was found on a mattress in her home in Helmsley on 25 September 2018.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/inquest-hears-isolated-japanese-family-kept-sisters-body-at-yorkshire-home">Continue reading...</a>

## ‘Depraved’ builder who murdered two women is sentenced to at least 49 years in prison
 - [https://www.theguardian.com/uk-news/2023/jan/13/depraved-builder-who-murdered-two-women-is-sentenced-to-at-least-49-years-in-prison](https://www.theguardian.com/uk-news/2023/jan/13/depraved-builder-who-murdered-two-women-is-sentenced-to-at-least-49-years-in-prison)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 17:56:37+00:00
 - user: None

<p>East Sussex man killed Alexandra Morgan and Leah Ware, who he kept semi-captive in a shipping container</p><p>A builder who murdered two women, having kept one of them semi-captive in a shipping container, has been sentenced to at least 49 years in prison.</p><p>Mark Brown, 41, who described himself as a “psychopath with a conscience”, killed Leah Ware, 33, and Alexandra Morgan, 34, in May and November 2021 at a remote farm near St Leonards in East Sussex.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/depraved-builder-who-murdered-two-women-is-sentenced-to-at-least-49-years-in-prison">Continue reading...</a>

## ‘Cultural shift’ since pandemic causing attendance crisis in English schools
 - [https://www.theguardian.com/education/2023/jan/13/cultural-shift-since-pandemic-causing-attendance-crisis-in-english-schools](https://www.theguardian.com/education/2023/jan/13/cultural-shift-since-pandemic-causing-attendance-crisis-in-english-schools)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 17:30:45+00:00
 - user: None

<p>Teachers say parents are now more reluctant to send children to school or willing to let them stay home</p><p>Headteachers and school leaders are becoming increasingly worried that a “cultural shift” in attitudes is causing a crisis in attendance, with more pupils absent than before the Covid pandemic.</p><p>Teachers say parents are now more reluctant to send children to school and more resistant to efforts to encourage attendance, with school leaders in England warning it may take years to repair national attendance figures.</p> <a href="https://www.theguardian.com/education/2023/jan/13/cultural-shift-since-pandemic-causing-attendance-crisis-in-english-schools">Continue reading...</a>

## Man sentenced to life for ‘brutal’ murder of 15-year-old girl in 1975
 - [https://www.theguardian.com/uk-news/2023/jan/13/dennis-mcgrory-sentenced-to-life-for-brutal-murder-of-15-year-old-girl-in-1975](https://www.theguardian.com/uk-news/2023/jan/13/dennis-mcgrory-sentenced-to-life-for-brutal-murder-of-15-year-old-girl-in-1975)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 17:24:13+00:00
 - user: None

<p>Dennis McGrory, 75, likely to spend rest of life in jail for rape and murder of Jacqui Montgomery in London</p><p>A man who murdered a teenager nearly 50 years ago has been told by a judge he will probably spend the rest of his life in prison in the oldest double jeopardy case in England and Wales.</p><p>Dennis McGrory was 28 when he sexually assaulted, stabbed and strangled Jacqui Montgomery, 15, during a “horrific, violent and sustained ordeal” at her home in Islington, north London, in 1975.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/dennis-mcgrory-sentenced-to-life-for-brutal-murder-of-15-year-old-girl-in-1975">Continue reading...</a>

## Environmental group sues New York for approving crypto mining facility
 - [https://www.theguardian.com/us-news/2023/jan/13/environmental-group-sues-new-york-crypto-mining](https://www.theguardian.com/us-news/2023/jan/13/environmental-group-sues-new-york-crypto-mining)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 17:10:38+00:00
 - user: None

<p>Lawsuit argues move to allow energy-intensive cryptocurrency miner to take over power plant violates state’s 2019 climate law</p><p>Environmental activists filed a lawsuit against a New York state agency on Friday for approving a cryptocurrency mining company’s takeover of an upstate power plant.</p><p>The group said the move violates the state’s landmark climate law that was passed in 2019 and the lawsuit is the first to test how energy-intensive crypto mining legally holds up against the state’s climate goals.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/environmental-group-sues-new-york-crypto-mining">Continue reading...</a>

## Labour calls for halt to ‘shameful’ forced installation of prepayment meters
 - [https://www.theguardian.com/money/2023/jan/13/labour-forced-installation-prepayment-meters-ed-miliband](https://www.theguardian.com/money/2023/jan/13/labour-forced-installation-prepayment-meters-ed-miliband)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 17:00:20+00:00
 - user: None

<p>Ed Miliband accuses government of ‘dereliction of duty’ and demands extra support for households</p><p>Labour has called for an immediate halt to the “shameful” forced installation of prepay gas and electricity meters, with the shadow climate change secretary, Ed Miliband, accusing the government of a “dereliction of duty” and demanding extra financial support for struggling households.</p><p>The opposition wants a three-month moratorium on the installations – which are typically made when customers rack up debts with their energy supplier – and it has asked for an “urgent review of how energy vulnerability can be reduced”.</p> <a href="https://www.theguardian.com/money/2023/jan/13/labour-forced-installation-prepayment-meters-ed-miliband">Continue reading...</a>

## Benjamin Mendy trial lifts lid on footballer’s partying lifestyle
 - [https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-trial-lifts-lid-footballer-partying-lifestyle](https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-trial-lifts-lid-footballer-partying-lifestyle)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 16:59:28+00:00
 - user: None

<p>Court case revealed private life of Manchester City star, from his chat-up lines to profligate spending</p><p>Benjamin Mendy’s <a href="https://www.theguardian.com/uk-news/2023/jan/13/manchester-city-footballer-benjamin-mendy-cleared-of-rape-charges">five-month trial</a> lifted the lid on his private life off the pitch, offering unique “through the keyhole” access to his home and inner circle.</p><p>The jury heard the defender’s chat-up lines: “I said to her, ‘Show me your bum.’ She showed me her bum and I said: ‘Do you want to have sex?’” They discovered he never used contraception, despite regularly sleeping with multiple women in the course of a night. They heard that Mendy and his friends sometimes had sex with the same women, albeit separately, on some nights. </p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-trial-lifts-lid-footballer-partying-lifestyle">Continue reading...</a>

## FTSE 100 nears record high as inflation fears ease
 - [https://www.theguardian.com/business/2023/jan/13/ftse-100-nears-record-high-as-inflation-fears-ease](https://www.theguardian.com/business/2023/jan/13/ftse-100-nears-record-high-as-inflation-fears-ease)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 16:50:33+00:00
 - user: None

<p>Blue-chip stock index ends week 1% off all-time best as markets across Europe rise amid falling energy prices</p><p>The UK’s FTSE 100 share index approached a record high on Friday, as European markets were lifted by hopes that the inflation shock from energy prices is easing.</p><p>The blue-chip stock index, which includes the 100 largest companies listed in London, hit its highest level in more than four years. It touched 7,864.95 points, less than 1% away from the record intraday high of 7,903 points set in May 2018, before closing at 7844.07.</p> <a href="https://www.theguardian.com/business/2023/jan/13/ftse-100-nears-record-high-as-inflation-fears-ease">Continue reading...</a>

## BBC Formula One presenter Jennie Gow says she has had a serious stroke
 - [https://www.theguardian.com/sport/2023/jan/13/bbc-formula-one-presenter-jennie-gow-drive-to-survive-serious-stroke](https://www.theguardian.com/sport/2023/jan/13/bbc-formula-one-presenter-jennie-gow-drive-to-survive-serious-stroke)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 16:48:03+00:00
 - user: None

<p>Broadcaster, 45, who also appears on Netflix series Drive to Survive, says her speech has been affected</p><p>BBC Formula One presenter Jennie Gow, who regularly appears on Netflix’s series Drive to Survive, has said she has had a “serious stroke”.</p><p>The broadcaster and journalist, 45, said her speech has been affected and thanked the medical teams at Frimley Park hospital in Surrey and St George’s hospital in London for taking care of her.</p> <a href="https://www.theguardian.com/sport/2023/jan/13/bbc-formula-one-presenter-jennie-gow-drive-to-survive-serious-stroke">Continue reading...</a>

## Byron burger chain closes nine sites, losing more than 200 jobs
 - [https://www.theguardian.com/business/2023/jan/13/byron-burger-closes-sites-jobs](https://www.theguardian.com/business/2023/jan/13/byron-burger-closes-sites-jobs)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 16:44:54+00:00
 - user: None

<p>Brand calls in administrators for second time in less than three years but 12 branches are saved</p><p>The owner of the upmarket burger chain Byron has called in administrators for the second time in less than three years with almost half the 21-site chain closing immediately with the loss of more than 200 jobs.</p><p>The administrators to Famously Proper, which also owns the Mother Clucker takeaway brand, said 12 branches were being saved and 365 jobs saved under a pre-agreed rescue deal with Tristar Foods. Both companies have the same owner, the private equity firm Calveton.</p> <a href="https://www.theguardian.com/business/2023/jan/13/byron-burger-closes-sites-jobs">Continue reading...</a>

## Lecturers urged to review assessments in UK amid concerns over new AI tool
 - [https://www.theguardian.com/technology/2023/jan/13/end-of-the-essay-uk-lecturers-assessments-chatgpt-concerns-ai](https://www.theguardian.com/technology/2023/jan/13/end-of-the-essay-uk-lecturers-assessments-chatgpt-concerns-ai)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 16:23:36+00:00
 - user: None

<p>ChatGPT is capable of producing high-quality essays with minimal human input</p><ul><li><a href="https://www.theguardian.com/technology/2023/jan/13/chatgpt-explainer-what-can-artificial-intelligence-chatbot-do-ai">ChatGPT: what can the extraordinary artificial intelligence chatbot do?</a></li></ul><p>Lecturers at UK universities have been urged to review the way in which their courses are assessed amid concerns that students are already using a potent new AI tool capable of producing high-quality essays with minimal human input.</p><p>ChatGPT, the latest chatbot from OpenAI, founded in 2015 by Elon Musk, Sam Altman and others, has only been publicly available for a matter of weeks, but has already triggered concerns about the potential for hard-to-detect plagiarism and questions about the validity of the essay as a future form of assessment.</p> <a href="https://www.theguardian.com/technology/2023/jan/13/end-of-the-essay-uk-lecturers-assessments-chatgpt-concerns-ai">Continue reading...</a>

## Sunak under fire over second jet flight for UK trip in a week
 - [https://www.theguardian.com/politics/2023/jan/13/sunak-under-fire-over-second-jet-flight-for-uk-trip-in-a-week](https://www.theguardian.com/politics/2023/jan/13/sunak-under-fire-over-second-jet-flight-for-uk-trip-in-a-week)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 15:54:52+00:00
 - user: None

<p>Prime minister flew to Scotland with RAF plane days after he flew by jet from London to Leeds</p><ul><li><a href="https://www.theguardian.com/politics/live/2023/jan/13/rishi-sunak-nhs-strikes-tories-keir-starmer-labour-uk-politics-latest-news">UK politics live – latest news updates</a></li></ul><p>Rishi Sunak has been accused of wasting taxpayers’ money and making a mockery of the government’s strategy for tackling the climate crisis, after chartering a second private jet for a UK trip within a week.</p><p>The prime minister took a roughly 90-minute ride in an RAF plane to Scotland for a two-day visit, where he held a meeting with the first minister, Nicola Sturgeon, and announced the opening of two new freeports.</p> <a href="https://www.theguardian.com/politics/2023/jan/13/sunak-under-fire-over-second-jet-flight-for-uk-trip-in-a-week">Continue reading...</a>

## Rail and ambulance strikes: when is industrial action planned?
 - [https://www.theguardian.com/society/2023/jan/11/rail-ambulance-strikes-when-is-industrial-action-planned-in-january](https://www.theguardian.com/society/2023/jan/11/rail-ambulance-strikes-when-is-industrial-action-planned-in-january)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 15:54:31+00:00
 - user: None

<p>Unions representing staff in NHS, transport and beyond warn of disputes escalating unless ministers give ground on pay</p><p>The end of 2022 was <a href="https://www.theguardian.com/uk-news/2022/dec/12/uk-strike-days-calendar-the-public-service-stoppages-planned-for-december">marked by mass industrial unrest</a> as employees across the transport network, NHS, Royal Mail, schools and the civil service took strike action. The start of 2023 has brought further stoppages by rail workers, bus drivers, teachers in Scotland, nurses, ambulance workers and civil servants.</p><p>Paul Nowak, the new general secretary of the Trades Union Congress, has warned of a <a href="https://news.sky.com/story/unions-will-coordinate-strike-action-if-government-doesnt-discuss-pay-head-of-tuc-suggests-12776014">“rolling wave”</a> of strikes this year unless ministers give ground on pay, with unions taking coordinated action so that stoppages happen either on the same day or in quick succession.</p> <a href="https://www.theguardian.com/society/2023/jan/11/rail-ambulance-strikes-when-is-industrial-action-planned-in-january">Continue reading...</a>

## Police find Bengal tiger cub in mobile home while investigating shooting
 - [https://www.theguardian.com/us-news/2023/jan/13/police-find-bengal-tiger-cub-in-mobile-home-while-investigating-shooting](https://www.theguardian.com/us-news/2023/jan/13/police-find-bengal-tiger-cub-in-mobile-home-while-investigating-shooting)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 15:39:46+00:00
 - user: None

<p>New Mexico officers followed a trail of blood and found the uninjured cub in a crate, and took him to the local zoo</p><p>Police in New Mexico investigating reports of a shooting followed a trail of blood to a mobile home, and discovered a young tiger cub inside a crate.</p><p>The uninjured cub was not, officials said, the same illegally kept tiger that investigators were searching for last summer when they <a href="https://www.cabq.gov/police/news/while-assisting-nm-game-and-fish-to-locate-tiger-apd-seizes-large-quantities-of-drugs-money-and-guns">raided a nearby house in Albuquerque</a> and found instead a stash of guns, cash, drugs and a 3ft alligator.</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/police-find-bengal-tiger-cub-in-mobile-home-while-investigating-shooting">Continue reading...</a>

## Unite employee under investigation over alleged bribery and fraud
 - [https://www.theguardian.com/uk-news/2023/jan/13/unite-employee-under-investigation-over-alleged-bribery-and-fraud](https://www.theguardian.com/uk-news/2023/jan/13/unite-employee-under-investigation-over-alleged-bribery-and-fraud)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 15:12:46+00:00
 - user: None

<p>Police say it is suspected contracts were awarded ‘in return for personal financial and other rewards’</p><p>A Unite employee is the subject of a criminal investigation into allegations of bribery, fraud, money-laundering and tax evasion, South Wales police have confirmed.</p><p>The police said they were working with HM Revenue and Customs, the tax department, on an investigation into the union employee, as well as several companies.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/unite-employee-under-investigation-over-alleged-bribery-and-fraud">Continue reading...</a>

## UK plans GPS tracking of potential deportees by fingerprint scanners
 - [https://www.theguardian.com/uk-news/2023/jan/13/potential-deportees-fingerprint-scanners-gps-tracking-home-office-plans](https://www.theguardian.com/uk-news/2023/jan/13/potential-deportees-fingerprint-scanners-gps-tracking-home-office-plans)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 15:00:18+00:00
 - user: None

<p>Charities say 24/7 monitoring for people on bail from immigration detention risk ‘total surveillance’</p><p>People facing deportation have been told they must scan their fingerprints several times a day using devices installed with GPS technology under plans from the Home Office and the Ministry of Justice.</p><p>Those required to carry one of the handheld devices will be subject to 24/7 location tracking, with information including an individual’s name, date of birth and nationality stored on the device and shared with the government, police and other authorities. Users will receive alerts throughout the day to submit their biometrics and are obliged to carry the device with them at all times.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/potential-deportees-fingerprint-scanners-gps-tracking-home-office-plans">Continue reading...</a>

## Benjamin Mendy rape case: not-guilty verdicts came down to question of consent
 - [https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-case-not-guilty-verdicts-came-down-to-question-of-consent](https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-case-not-guilty-verdicts-came-down-to-question-of-consent)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:53:52+00:00
 - user: None

<p>It was largely agreed sexual activity took place, so footballer’s defence focused on women’s actions after the fact</p><p>In some ways, the trial of Benjamin Mendy was not complex. Even the prosecution barrister, Timothy Cray KC, said it was “the opposite of a whodunnit”. For all of the rape charges he faced, both sides agreed that sexual activity had taken place. The question was: did the women consent?</p><p>On charges relating to four of his accusers, <a href="https://www.theguardian.com/uk-news/2023/jan/13/manchester-city-footballer-benjamin-mendy-cleared-of-rape-charges">the jury decided</a> unanimously that he was not guilty of rape and sexual assault. They could not reach verdicts on two outstanding counts, of attempting to rape one woman and of raping another.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/benjamin-mendy-case-not-guilty-verdicts-came-down-to-question-of-consent">Continue reading...</a>

## ‘Negligent’ skipper caused girl’s death in speedboat crash, court told
 - [https://www.theguardian.com/uk-news/2023/jan/13/negligent-skipper-caused-girls-death-in-speedboat-crash-court-told-southampton-water](https://www.theguardian.com/uk-news/2023/jan/13/negligent-skipper-caused-girls-death-in-speedboat-crash-court-told-southampton-water)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:50:06+00:00
 - user: None

<p>Michael Lawrence accused of ignoring safety rules before crash that killed Emily Lewis, 15, on Southampton Water</p><p>A schoolgirl was killed in a speedboat crash after a “grossly negligent” skipper ignored safety rules and smashed into a large buoy at more than 40mph, a court heard today.</p><p>Michael Lawrence, who was highly experienced and qualified, is accused of taking risks by performing stunts before he ploughed into the metal buoy on Southampton Water, Hants, during what was meant to be a “high thrills” ride.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/negligent-skipper-caused-girls-death-in-speedboat-crash-court-told-southampton-water">Continue reading...</a>

## Meanwhile, Brexit: second thoughts take voters where parties won’t follow
 - [https://www.theguardian.com/politics/2023/jan/13/meanwhile-brexit-second-thoughts-take-voters-where-parties-wont-follow](https://www.theguardian.com/politics/2023/jan/13/meanwhile-brexit-second-thoughts-take-voters-where-parties-wont-follow)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:25:44+00:00
 - user: None

<p>Even leavers might be changing their minds, but there’s little incentive for the opposition to revisit the issue, say analysts</p><p>While Brexit may have been chased out of the headlines in recent months by the cost of living crisis and the chaos in Westminster, the tectonic plates of public opinion on this deeply divisive issue have been quietly shifting.</p><p>The opposition parties have shied away from blaming Brexit for the UK’s woes, but voters’ scepticism about the project has increased through the past 18 months, as the economic outlook has darkened.</p> <a href="https://www.theguardian.com/politics/2023/jan/13/meanwhile-brexit-second-thoughts-take-voters-where-parties-wont-follow">Continue reading...</a>

## Knives out: questions remain after Dominic Perrottet’s Nazi uniform admission
 - [https://www.theguardian.com/australia-news/2023/jan/14/knives-out-questions-remain-after-dominic-perrottets-nazi-uniform-admission](https://www.theguardian.com/australia-news/2023/jan/14/knives-out-questions-remain-after-dominic-perrottets-nazi-uniform-admission)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:00:20+00:00
 - user: None

<p>There is mystery about who was behind the rumours of the damaging photo but the internal anger at the premier is real and multifaceted</p><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>It’s the biggest mystery in New South Wales politics: who was behind the rumours of a damaging photograph of Dominic Perrottet that began circulating in the weeks before he revealed that he wore a Nazi uniform at his 21st birthday party?</p><p>When it comes to uncovering the culprit, one Liberal party source said: “It’s a bit like that movie Knives Out – there are about 20 people who it could’ve been and they all had a motive.”</p> <a href="https://www.theguardian.com/australia-news/2023/jan/14/knives-out-questions-remain-after-dominic-perrottets-nazi-uniform-admission">Continue reading...</a>

## In Australia’s severe rental crisis, asylum seekers are increasingly desperate for a place to live
 - [https://www.theguardian.com/australia-news/2023/jan/14/in-australias-severe-rental-crisis-asylum-seekers-are-increasingly-desperate-for-a-place-to-live](https://www.theguardian.com/australia-news/2023/jan/14/in-australias-severe-rental-crisis-asylum-seekers-are-increasingly-desperate-for-a-place-to-live)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:00:18+00:00
 - user: None

<p>Each week about 150 people are coming to the Asylum Seeker Resource Centre in housing distress, but only 40 can be accommodated</p><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Asylum seekers in Australia are increasingly at risk of homelessness as the<strong> </strong>rental crisis continues to bite, with more than 70% of people who turn up to a leading asylum seeker support charity<strong> </strong>in housing distress unable to be placed in accommodation.</p><p>The Asylum Seeker Resource Centre (ASRC) has shifted resources since the pandemic to provide emergency accommodation for asylum seekers who are sleeping rough or at immediate risk of homelessness.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/14/in-australias-severe-rental-crisis-asylum-seekers-are-increasingly-desperate-for-a-place-to-live">Continue reading...</a>

## Queensland urged to end its ‘failing’ shark nets and drum lines program
 - [https://www.theguardian.com/australia-news/2023/jan/14/queensland-urged-to-end-its-failing-shark-nets-and-drum-lines-program](https://www.theguardian.com/australia-news/2023/jan/14/queensland-urged-to-end-its-failing-shark-nets-and-drum-lines-program)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 14:00:16+00:00
 - user: None

<p>Scientists call on government to replace lethal control measures amid criticism of its use of federal money at the Great Barrier Reef</p><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Scientists are urging the Queensland government to remove shark nets and traditional drum lines from coastlines, saying “ineffective” lethal methods are inhumane, amid criticism of the state’s use of federal money for measures at the Great Barrier Reef.</p><p>Lawrence Chlebeck, a marine biologist at Humane Society International, said Queensland’s lethal shark control program is “failing” on both environmental and public safety fronts and should be “discontinued”.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/14/queensland-urged-to-end-its-failing-shark-nets-and-drum-lines-program">Continue reading...</a>

## Hopes of sharp fall in household energy bills as HSBC cuts gas price forecast
 - [https://www.theguardian.com/business/2023/jan/13/hopes-of-sharp-fall-in-household-energy-bills-as-hsbc-cuts-gas-price-forecast](https://www.theguardian.com/business/2023/jan/13/hopes-of-sharp-fall-in-household-energy-bills-as-hsbc-cuts-gas-price-forecast)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 13:24:11+00:00
 - user: None

<p>Bank slashes predicted 2023 European wholesale price by 30% as mild weather reduces demand</p><p>HSBC has slashed its forecasts for future wholesale gas prices in response to mild weather in Europe – raising hopes of a sharp decline in household energy bills.</p><p>The bank cut its 2023 forecasts for the price of gas traded in Europe by about 30% and its forecast for 2024 by 20%.</p> <a href="https://www.theguardian.com/business/2023/jan/13/hopes-of-sharp-fall-in-household-energy-bills-as-hsbc-cuts-gas-price-forecast">Continue reading...</a>

## ADHD services ‘swamped’, say experts as more UK women seek diagnosis
 - [https://www.theguardian.com/society/2023/jan/13/adhd-services-swamped-say-experts-as-more-uk-women-seek-diagnosis](https://www.theguardian.com/society/2023/jan/13/adhd-services-swamped-say-experts-as-more-uk-women-seek-diagnosis)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 11:00:13+00:00
 - user: None

<p>Warnings of ‘great cost’ to individuals, workplaces and the economy as people struggle to access diagnosis and treatment</p><p>ADHD awareness hassoared among women in the UK in the past year, but waiting times and the dearth of clinical awareness are leaving people awaiting diagnosis in a perilous position, leading experts have warned.</p><p>Dr Max Davie, a consultant paediatrician and co-founder of ADHD UK, said that people talking openly about their diagnoses – such as the <a href="https://www.theguardian.com/society/2022/nov/24/nadia-sawalha-reveals-she-has-been-diagnosed-with-adhd">Loose Women presenter Nadia Sawalha</a> – had led to more people seeking referrals for the condition.</p> <a href="https://www.theguardian.com/society/2023/jan/13/adhd-services-swamped-say-experts-as-more-uk-women-seek-diagnosis">Continue reading...</a>

## Apple’s Tim Cook to take 50% pay hit after shareholder feedback
 - [https://www.theguardian.com/technology/2023/jan/13/apple-tim-cook-to-take-pay-hit-after-shareholder-feedback](https://www.theguardian.com/technology/2023/jan/13/apple-tim-cook-to-take-pay-hit-after-shareholder-feedback)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 10:49:45+00:00
 - user: None

<p>‘Target compensation’ for CEO down from $99.4m in 2022 to an expected $49m for the current year</p><p>Apple chief executive, Tim Cook, is expected to have his pay cut by almost 50% this year to about $49m (£40m) after the billionaire boss asked the company to “adjust his compensation” in the light of feedback from shareholders disappointed at the fall in the company’s share price.</p><p>Cook, 62, who became CEO after the death of co-founder Steve Jobs in 2011, was<a href="https://www.theguardian.com/technology/2022/jan/07/apple-boss-tim-cook-was-paid-nearly-100m-last-year-filings-show"> paid $99.4m in 2022</a> and $98.8m in 2021. But the <a href="https://www.sec.gov/Archives/edgar/data/320193/000130817923000019/laap2023_def14a.htm">company said in a regulatory filing late on Thursday night</a> that it had set a “target compensation” of $49m for 2023.</p> <a href="https://www.theguardian.com/technology/2023/jan/13/apple-tim-cook-to-take-pay-hit-after-shareholder-feedback">Continue reading...</a>

## Dartmoor landowner wins fight to eject wild campers from his estate
 - [https://www.theguardian.com/environment/2023/jan/13/dartmoor-estate-landowner-alexander-darwall-court-case-right-to-camp](https://www.theguardian.com/environment/2023/jan/13/dartmoor-estate-landowner-alexander-darwall-court-case-right-to-camp)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 10:47:24+00:00
 - user: None

<p>Hedge fund manager Alexander Darwall brought case against national park arguing right to camp never existed</p><p>The right to wild camp on Dartmoor has been overturned after a court case brought to the high court by a wealthy landowner.</p><p>Dartmoor was the only place in England and Wales where there is a right to camp under the stars without seeking permission from the landowner.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/dartmoor-estate-landowner-alexander-darwall-court-case-right-to-camp">Continue reading...</a>

## Bills to regulate toxic ‘forever chemicals’ died in Congress – with Republican help
 - [https://www.theguardian.com/environment/2023/jan/13/pfas-toxic-forever-chemicals-republican-house](https://www.theguardian.com/environment/2023/jan/13/pfas-toxic-forever-chemicals-republican-house)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 10:00:12+00:00
 - user: None

<p>Lobbying industry flexed muscle to ensure bills that aimed to set stricter standards on PFAS compounds went nowhere </p><p>All legislation aimed at regulating toxic PFAS “forever chemicals” died in the Democratic-controlled US Congress last session as companies flexed their lobbying muscle and bills did not gain enough Republican support to overcome a Senate filibuster.</p><p>The failure comes after public health advocates and Democratic lawmakers expressed optimism at the legislative session’s outset that bills that would protect the public from dangerous exposure to the chemicals could gain sufficient bipartisan support.</p> <a href="https://www.theguardian.com/environment/2023/jan/13/pfas-toxic-forever-chemicals-republican-house">Continue reading...</a>

## First Thing: Trump plans tour of presidential campaign events
 - [https://www.theguardian.com/us-news/2023/jan/13/first-thing-trump-plans-tour-of-presidential-campaign-events](https://www.theguardian.com/us-news/2023/jan/13/first-thing-trump-plans-tour-of-presidential-campaign-events)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 09:57:41+00:00
 - user: None

<p>Events aim at giving ex-president a narrative reset after being criticized for his ‘low energy’ and inactivity, sources say. Plus, how menopause can destroy mental health</p><p>Good morning.</p><p>Donald Trump is scheduled to venture out of his Mar-a-Lago resort and conduct a swing of presidential campaign events later this month, ramping up efforts to secure the Republican nomination after facing criticism around the slow start to his 2024 White House bid, <a href="https://www.theguardian.com/us-news/2023/jan/13/trump-events-secure-2024-republican-nomination">according to sources familiar with the matter</a>.</p><p><strong>What else is happening?</strong> The US attorney general, Merrick Garland, appointed a special counsel on Thursday to investigate Joe Biden’s retention of classified documents from his time as vice-president. The move to name Robert Hur, a former Trump-appointed federal prosecutor and former top justice department official, was a rapid decision from Garland to insulate the department from <a href="https://www.theguardian.com/us-news/2023/jan/12/biden-more-classified-documents-found-garage-delaware">possible accusations of political conflicts or interference</a>.</p><p><strong>How do the Trump and Biden cases regarding classified documents differ? </strong>While Trump appears to have wilfully obstructed efforts to recover them, leading to the FBI raid, Biden’s team said they cooperated fully and immediately returned the documents to the National Archives as soon as they were discovered. Read more <a href="https://www.theguardian.com/us-news/2023/jan/12/trump-biden-classified-docs-differences">here</a>.</p><p><strong>What tributes have been paid to Presley?</strong> John Travolta said on Instagram: “Lisa baby girl, I’m so sorry. I’ll miss you but I know I’ll see you again.” Meanwhile, Bette Midler said: “I’m in shock. So beautiful and only 54 years old; I can’t actually comprehend it.”</p> <a href="https://www.theguardian.com/us-news/2023/jan/13/first-thing-trump-plans-tour-of-presidential-campaign-events">Continue reading...</a>

## No sign from Sunak of additional funding to avert NHS strikes, says Sturgeon – UK politics live
 - [https://www.theguardian.com/politics/live/2023/jan/13/rishi-sunak-nhs-strikes-tories-keir-starmer-labour-uk-politics-latest-news](https://www.theguardian.com/politics/live/2023/jan/13/rishi-sunak-nhs-strikes-tories-keir-starmer-labour-uk-politics-latest-news)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 09:54:00+00:00
 - user: None

<p>Scotland’s first minister discussed NHS funding with the PM on Thursday night in Holyrood</p><p><strong>Keir Starmer</strong> is to challenge <strong>Rishi Sunak</strong> to stand up to the “Brexit purity cult” of Eurosceptics within the Conservative party to resolve the <strong>Northern Ireland</strong> protocol impasse.</p><p>The Labour leader will use a speech in <strong>Belfast</strong> on Friday to encourage the prime minister to take on the once highly influential European Research Group (ERG) of backbench Tory MPs to find a fix for issues arising from Northern Ireland’s post-Brexit trading arrangements.</p><p>The time to put Northern Ireland above a Brexit purity cult, which can never be satisfied, is now.</p><p>The Scottish government took this case to the Supreme Court, which was completely clear about the ability of the Scottish government to do that (hold a referendum) unilaterally. What I want to do is have a constructive dialogue with the Scottish government to make sure we can continue to deliver for the people of Scotland.</p> <a href="https://www.theguardian.com/politics/live/2023/jan/13/rishi-sunak-nhs-strikes-tories-keir-starmer-labour-uk-politics-latest-news">Continue reading...</a>

## The UK may avoid a recession for now but it won’t feel like it for many
 - [https://www.theguardian.com/business/2023/jan/13/uk-avoid-recession-november-gdp-growth](https://www.theguardian.com/business/2023/jan/13/uk-avoid-recession-november-gdp-growth)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 09:43:20+00:00
 - user: None

<p>Jeremy Hunt is not getting carried away by November growth, and monthly GDP moves can be erratic</p><ul><li><a href="https://www.theguardian.com/business/2023/jan/13/uk-economy-grew-in-november">UK economy grew by only 0.1% in November</a></li><li><a href="https://www.theguardian.com/business/live/2023/jan/13/uk-gdp-economy-november-recession-inflation-energy-business-live">Business live updates: UK may avoid 2022 recession</a></li></ul><p>In normal circumstances the fact that the UK economy eked out a bit of growth in November would be of little relevance, especially since the 0.1% monthly expansion was partly the result of extra spending on food and drink during the World Cup.</p><p>Yet for a government sorely in need of some good – or even some less bad – news, the latest bulletin from the <a href="https://www.ons.gov.uk/economy/grossdomesticproductgdp/bulletins/gdpmonthlyestimateuk/november2022">Office for National Statistics (ONS)</a> provides some hope that the economy may have avoided falling into recession in late 2022.</p> <a href="https://www.theguardian.com/business/2023/jan/13/uk-avoid-recession-november-gdp-growth">Continue reading...</a>

## Rishi Sunak refuses to back calls for NHS funding boost
 - [https://www.theguardian.com/society/2023/jan/13/rishi-sunak-strikes-nhs-funding-boost](https://www.theguardian.com/society/2023/jan/13/rishi-sunak-strikes-nhs-funding-boost)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 09:31:41+00:00
 - user: None

<p>PM says NHS already has ‘record funding’ as health secretary privately admits more money needed to end strikes</p><p>Rishi Sunak has refused to back calls to boost the health service budget in an attempt to alleviate staffing pressures that have already led to strikes by nurses and ambulance workers, and could soon prompt junior doctors to strike as well. </p><p>Asked on BBC’s Good Morning Scotland whether there was scope for a one-off increase in health spending, the prime minister added: “There is record funding already going into the NHS … in spite of the difficult decisions we have had to make to get a grip of borrowing and tackle inflation.”</p> <a href="https://www.theguardian.com/society/2023/jan/13/rishi-sunak-strikes-nhs-funding-boost">Continue reading...</a>

## New federal court rules over access to documents branded ‘utterly disgraceful’ – as it happened
 - [https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals](https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 08:13:51+00:00
 - user: None

<p>Court moves to protect respondents from early reporting of allegations but media union criticises decision. This blog is now closed</p><ul><li><a href="https://www.theguardian.com/media/2023/jan/13/utterly-disgraceful-new-federal-court-rules-limiting-access-to-documents-criticised-by-media-union">New federal court rules limiting access to documents criticised by media union</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p><strong>Chalmers finds it ‘hard to believe’ someone at 21 wouldn’t know Nazi fancy dress was unacceptable</strong></p><p><strong>Hamish McDonald</strong> asks <strong>Chalmers</strong> about the news on Perrottet’s decision to wear a Nazi uniform at his 21st birthday party.</p><p>My view about this is that we want the state of New South Wales and we want Australia to be more inclusive and more tolerant. And when something like this comes out, that’s obviously a challenge for that. People in New South Wales will have an opportunity to express their view in March on a more inclusive and more tolerant state of New South Wales in the same way that people had that opportunity nationally in May.</p><p>Do you think that it’s possible that someone didn’t know [it was offensive] was even at the age of 21?</p><p>I find that hard to believe. I think it’s a particularly hurtful thing to have done, particularly for people who remember the war; obviously the Jewish community and others will be deeply hurt by, deeply offended by that, and for good reason, and I think the ultimate judge of this will be the people of New South Wales. </p><p>The lost economic activity doesn’t really begin to capture the full human cost [to the] community and the full cost to infrastructure and assets and communities more broadly.</p><p>We’ve put that number out there, really just as a reminder that even though we are largely focused on the human cost of these natural disasters, there is a cost to the economy as well and the cost to the budget.</p> <a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Continue reading...</a>

## Minister refuses to rule out changes to UK online safety bill
 - [https://www.theguardian.com/media/2023/jan/12/uk-jail-social-media-bosses-children-online-safety-bill](https://www.theguardian.com/media/2023/jan/12/uk-jail-social-media-bosses-children-online-safety-bill)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 08:05:12+00:00
 - user: None

<p>Social media bosses who breach child safety rules may face jail if Ofcom given powers to prosecute</p><p>The UK culture secretary has said she is “not ruling out” changing the online safety bill to allow regulators to prosecute social media bosses who are found not to have protected children’s safety.</p><p>Michele Donelan told the BBC on Friday she was open to making changes that have been demanded by dozens of Conservative MPs, saying she would take a “sensible approach” to their ideas.</p> <a href="https://www.theguardian.com/media/2023/jan/12/uk-jail-social-media-bosses-children-online-safety-bill">Continue reading...</a>

## ‘Cheap and delicious’: it’s lentils to go on Belfast’s cost of living frontline
 - [https://www.theguardian.com/uk-news/2023/jan/13/belfast-cost-of-living-frontline-lentils](https://www.theguardian.com/uk-news/2023/jan/13/belfast-cost-of-living-frontline-lentils)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 08:00:11+00:00
 - user: None

<p>Cooking tips and takeaways are among the community offerings at a centre that will benefit from the Guardian and Observer charity appeal</p><p>Marianne Daly has turned to an ancient staple to help the women of west Belfast weather the cost of living crisis: lentils.</p><p>At the <a href="https://www.footprintswomenscentre.org/socialsupermarket">Footprints Women’s Centre</a> she teaches her students that the legume, one of humanity’s oldest sources of food, can bulk up curries, sauces and other dishes for a fraction of the price of meat.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/13/belfast-cost-of-living-frontline-lentils">Continue reading...</a>

## UK economy grew by only 0.1% in November
 - [https://www.theguardian.com/business/2023/jan/13/uk-economy-grew-in-november](https://www.theguardian.com/business/2023/jan/13/uk-economy-grew-in-november)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 07:34:07+00:00
 - user: None

<p>Figure comes as people began Christmas shopping, while World Cup gave pubs and bars a boost</p><p>The UK economy grew by 0.1% in November as consumers headed to the shops in the run-up to Christmas and pubs and bars enjoyed a boost from the World Cup.</p><p>It was a slowdown compared with 0.5% growth in October, when the economy rebounded from a weak September, when many businesses closed for the Queen’s funeral. It was, however, better than forecasts, with City economists predicting the economy would shrink by 0.2 % in November.</p> <a href="https://www.theguardian.com/business/2023/jan/13/uk-economy-grew-in-november">Continue reading...</a>

## ‘Utterly disgraceful’: new federal court rules limiting access to documents criticised by media union
 - [https://www.theguardian.com/media/2023/jan/13/utterly-disgraceful-new-federal-court-rules-limiting-access-to-documents-criticised-by-media-union](https://www.theguardian.com/media/2023/jan/13/utterly-disgraceful-new-federal-court-rules-limiting-access-to-documents-criticised-by-media-union)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 07:25:16+00:00
 - user: None

<p>While the court says rules are designed to protect respondents from early reporting of allegations, MEAA president says decision ‘goes against the concept of open court’</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Follow our Australia news live blog for the latest updates</a></li></ul><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>New federal court rules barring media from accessing documents until the first directions hearing have been labelled “utterly disgraceful” and a breach of the concept of “open” justice.</p><p>Enacted in mid-December by federal court judges without consulting the media and published on the gazette Thursday, the <a href="https://www.legislation.gov.au/Details/F2023L00033">rules</a> appear designed to protect respondents against reporting of allegations at the earliest stages of a case.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/media/2023/jan/13/utterly-disgraceful-new-federal-court-rules-limiting-access-to-documents-criticised-by-media-union">Continue reading...</a>

## Banksia Hill: autistic teenage girl ‘treated like a dog’ at detention centre, class action alleges
 - [https://www.theguardian.com/australia-news/2023/jan/13/banksia-hill-teenage-girl-with-autism-treated-like-a-dog-at-detention-centre-class-action-alleges](https://www.theguardian.com/australia-news/2023/jan/13/banksia-hill-teenage-girl-with-autism-treated-like-a-dog-at-detention-centre-class-action-alleges)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 06:07:00+00:00
 - user: None

<p>Girl, first detained at 13, suffered ‘extremely traumatic’ restraining with handcuffs, leg shackles and spit hoods, court document claims</p><ul><li><strong>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></strong></li></ul><p>An autistic teenage girl detained at Banksia Hill Detention Centre was forced to use underwear stained with menstrual blood and sleep on a mattress covered with “excrement and saliva”, according to a legal document filed in support of a class action against the West Australian government.</p><p>The affidavit by lawyer Stewart Levitt alleges the girl was fed meals through a grille and was forced to “earn” her bedding. She felt like she was being “treated like a dog” and responded by sleeping on the concrete floor of her cell and pretending she was a dog, the document states.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/13/banksia-hill-teenage-girl-with-autism-treated-like-a-dog-at-detention-centre-class-action-alleges">Continue reading...</a>

## National Science and Media museum in Bradford to close for £6m refurb
 - [https://www.theguardian.com/culture/2023/jan/13/national-science-and-media-museum-in-bradford-to-close-for-6m-refurb](https://www.theguardian.com/culture/2023/jan/13/national-science-and-media-museum-in-bradford-to-close-for-6m-refurb)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 06:00:09+00:00
 - user: None

<p>Year-long revamp intended to inspire next generation of ‘creatives, inventors and scientists’ and tie in with city’s 2025 stint as capital of culture</p><p>The <a href="https://www.scienceandmediamuseum.org.uk/">National Science and Media museum</a> is to close for a year for a “radical, once-in-a-generation” revamp that will allow more visitors to attend and provide the ability to tell stories in a more dynamic way, bosses say.</p><p>The museum in Bradford has a vast, dizzyingly diverse collection of more than 3.2m objects, from the first photographic negative to the original puppet of Zippy from Rainbow.</p> <a href="https://www.theguardian.com/culture/2023/jan/13/national-science-and-media-museum-in-bradford-to-close-for-6m-refurb">Continue reading...</a>

## Doctor temporarily banned over thousands of potentially ‘incomplete’ colonoscopies in Albury-Wodonga
 - [https://www.theguardian.com/australia-news/2023/jan/13/doctor-temporarily-banned-over-thousands-of-potentially-incomplete-colonoscopies-in-albury-wodonga](https://www.theguardian.com/australia-news/2023/jan/13/doctor-temporarily-banned-over-thousands-of-potentially-incomplete-colonoscopies-in-albury-wodonga)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 04:32:41+00:00
 - user: None

<p>Almost 2,000 patients of<strong> </strong>surgeon told<strong> </strong>by health authorities they may need to have procedures repeated to ensure they do not have cancer<strong> </strong>after an investigation by regulators</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Follow our Australia news live blog for the latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>A surgeon who performed hundreds of potentially “incomplete” colonoscopies in the Albury-Wodonga region has been temporarily banned from practising medicine. </p><p>Dr Liu-Ming Schmidt will remain registered as a GP and specialist surgeon in Australia, but cannot perform any medical procedures or treat patients according to conditions imposed on Friday.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/13/doctor-temporarily-banned-over-thousands-of-potentially-incomplete-colonoscopies-in-albury-wodonga">Continue reading...</a>

## Australia on track for 2023 migration boom as arrivals dwarf Treasury forecasts, ex-official says
 - [https://www.theguardian.com/australia-news/2023/jan/13/australia-on-track-for-2023-migration-boom-as-arrivals-dwarf-treasury-forecasts-ex-official-says](https://www.theguardian.com/australia-news/2023/jan/13/australia-on-track-for-2023-migration-boom-as-arrivals-dwarf-treasury-forecasts-ex-official-says)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 03:10:33+00:00
 - user: None

<p>Former immigration department deputy believes government has ‘significantly underestimated’ net migration </p><ul><li><strong>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></strong></li></ul><p>Australia is on track for net migration of more than 300,000 people this year, more than 25% higher than Treasury forecasts, due to a surge in arrivals, according to a former top immigration official.</p><p>Abul Rizvi, the former deputy secretary of the immigration department, said that Treasury forecasts of a 235,000-person annual boost to population from migration – the long term pre-pandemic average – have “significantly underestimated” net figures.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/13/australia-on-track-for-2023-migration-boom-as-arrivals-dwarf-treasury-forecasts-ex-official-says">Continue reading...</a>

## Why now? Inside Dominic Perrottet’s plea for voters’ forgiveness over his Nazi outfit
 - [https://www.theguardian.com/australia-news/2023/jan/13/why-now-inside-dominic-perrottets-plea-for-voters-forgiveness-over-his-nazi-outfit](https://www.theguardian.com/australia-news/2023/jan/13/why-now-inside-dominic-perrottets-plea-for-voters-forgiveness-over-his-nazi-outfit)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-01-13 02:33:15+00:00
 - user: None

<p><strong>Analysis:</strong> Someone in the NSW premier’s own corner seems determined that he should pay for his 21st birthday mistake</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/13/australia-news-live-dominic-perrottet-leadership-crisis-anthony-albanese-peter-dutton-labor-liberals">Follow our Australia news live blog for the latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>In his maiden speech to parliament 11 years ago, the New South Wales premier, Dominic Perrottet, shared an anecdote from his childhood, in which he explained his “love of politics” began from a young age.</p><p>In the speech, Perrottet said that from the age of 10 he and his siblings were “required to present an article on current affairs to the family” at the dinner table.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/13/why-now-inside-dominic-perrottets-plea-for-voters-forgiveness-over-his-nazi-outfit">Continue reading...</a>
