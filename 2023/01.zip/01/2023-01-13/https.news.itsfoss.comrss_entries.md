# Source It's FOSS News, Source URL:https://news.itsfoss.com/rss/, Source language: en-US

## Mastodon's Growth Continues, Medium Joins in With its New Community Platform
 - [https://news.itsfoss.com/medium-mastodon/](https://news.itsfoss.com/medium-mastodon/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-01-13 10:16:54+00:00
 - user: None

Another win for Mastodon's adoption! Medium launches an instance for its users.

## FOSS Weekly #23.02: Free Linux Book, Cooler Master Goes Open Source and More
 - [https://news.itsfoss.com/foss-weekly-23-02/](https://news.itsfoss.com/foss-weekly-23-02/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-01-13 08:14:37+00:00
 - user: None

I've got a gift for you in this edition of FOSS Weekly. A new Linux book you can download for free.
