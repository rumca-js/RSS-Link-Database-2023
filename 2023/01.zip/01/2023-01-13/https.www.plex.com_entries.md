# Source URL:https://www.plex.com, Source language: en

## Plex Smart Manufacturing Platform | Plex, by Rockwell Automation
 - [https://www.plex.com/](https://www.plex.com/)
 - RSS feed: https://www.plex.com
 - date published: 2023-01-13 12:56:31+00:00
 - user: rumpel
 - tags: digital bunker,plex,smarthome

Plex Smart Manufacturing Platform | Plex, by Rockwell Automation
