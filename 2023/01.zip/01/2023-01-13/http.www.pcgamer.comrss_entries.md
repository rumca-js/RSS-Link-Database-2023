# Source pcgamer, Source URL:http://www.pcgamer.com/rss, Source language: en-US

## The biggest esports scandals of the past 10 years
 - [https://www.pcgamer.com/the-biggest-esports-scandals-of-the-past-10-years](https://www.pcgamer.com/the-biggest-esports-scandals-of-the-past-10-years)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 23:02:20+00:00
 - user: None

Corporate catastrophes, cheating incidents, and heated gamer moments.

## An Enclave-themed group in Fallout 76 roleplayed the villains so hard it turned everyone against them
 - [https://www.pcgamer.com/an-enclave-themed-group-in-fallout-76-roleplayed-the-villains-so-hard-it-turned-everyone-against-them](https://www.pcgamer.com/an-enclave-themed-group-in-fallout-76-roleplayed-the-villains-so-hard-it-turned-everyone-against-them)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 22:50:49+00:00
 - user: None

Seemingly-benign roleplay gave way to enforcing its own rules on other players, with something more sinister potentially lurking beneath.

## Here's why a bunch of games, including Starfield, just changed release dates on Steam
 - [https://www.pcgamer.com/heres-why-a-bunch-of-games-including-starfield-just-changed-release-dates-on-steam](https://www.pcgamer.com/heres-why-a-bunch-of-games-including-starfield-just-changed-release-dates-on-steam)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 22:04:33+00:00
 - user: None

Starfield, Redfall, Ark 2, and a bunch of other games slated for launch in 2023 are now listed as simply “coming soon.”

## Nvidia and Google come out against Microsoft’s Activision Blizzard buyout
 - [https://www.pcgamer.com/nvidia-and-google-come-out-against-microsofts-activision-blizzard-buyout](https://www.pcgamer.com/nvidia-and-google-come-out-against-microsofts-activision-blizzard-buyout)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 18:20:25+00:00
 - user: None

The two tech giants recently shared their concerns about the deal with the FTC.

## Biggest leak in Valve's history includes pretty much everything from Portal, TF2, and Half-Life 2
 - [https://www.pcgamer.com/biggest-leak-in-valves-history-includes-pretty-much-everything-from-portal-tf2-and-half-life-2](https://www.pcgamer.com/biggest-leak-in-valves-history-includes-pretty-much-everything-from-portal-tf2-and-half-life-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 18:10:19+00:00
 - user: None

Sounds like a spy got in somewhere.

## This Animal Crossing creepypasta game is perfect for Friday the 13th
 - [https://www.pcgamer.com/this-animal-crossing-creepypasta-game-is-perfect-for-friday-the-13th](https://www.pcgamer.com/this-animal-crossing-creepypasta-game-is-perfect-for-friday-the-13th)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 17:11:01+00:00
 - user: None

What's better for a cursed day than a cursed game?

## Google serves up fake AMD driver downloads in search results
 - [https://www.pcgamer.com/google-serves-up-fake-amd-driver-downloads-in-search-results](https://www.pcgamer.com/google-serves-up-fake-amd-driver-downloads-in-search-results)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 16:45:26+00:00
 - user: None

Beware malware served up in Google ads. Again...

## Want to write for PC Gamer?
 - [https://www.pcgamer.com/want-to-write-for-pc-gamer](https://www.pcgamer.com/want-to-write-for-pc-gamer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 16:44:23+00:00
 - user: None

We're looking for a new staff writer to join the team.

## Nvidia's latest AI lets you maintain uncanny valley levels of eye contact on camera
 - [https://www.pcgamer.com/nvidia-broadcast-eye-contact-out-now](https://www.pcgamer.com/nvidia-broadcast-eye-contact-out-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 15:14:57+00:00
 - user: None

Try not to creep out your co-workers too much with this gaze-augmenting AI tool, out now.

## Fortnite disables hurdling after it keeps launching players into the stratosphere
 - [https://www.pcgamer.com/fortnite-disables-hurdling-after-it-keeps-launching-players-into-the-stratosphere](https://www.pcgamer.com/fortnite-disables-hurdling-after-it-keeps-launching-players-into-the-stratosphere)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 13:49:14+00:00
 - user: None

Chapter 4 Season 1's launch has been full of hurdles of its own.

## Ubisoft CEO tells staff the ball is in their court to turn the company around
 - [https://www.pcgamer.com/ubisoft-ceo-tells-staff-the-ball-is-in-their-court-to-turn-the-company-around](https://www.pcgamer.com/ubisoft-ceo-tells-staff-the-ball-is-in-their-court-to-turn-the-company-around)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 12:30:17+00:00
 - user: None

Yves Guillemot also asked employees to tighten their belts when it comes to future spending.

## Assassin's Creed Mirage will be smaller because Ubisoft knows big games are getting tiresome
 - [https://www.pcgamer.com/assassins-creed-mirage-will-be-smaller-because-ubisoft-knows-big-games-are-getting-tiresome](https://www.pcgamer.com/assassins-creed-mirage-will-be-smaller-because-ubisoft-knows-big-games-are-getting-tiresome)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 12:08:35+00:00
 - user: None

Editing its world down might do Ubisoft some good.

## Today's Wordle 573 answer and hint for Friday, January 13
 - [https://www.pcgamer.com/wordle-573-answer-january-13](https://www.pcgamer.com/wordle-573-answer-january-13)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 08:05:25+00:00
 - user: None

Wordle today: The solution and a hint for the #573 puzzle.

## So far, HBO's The Last of Us is a surprisingly simple adaptation
 - [https://www.pcgamer.com/so-far-hbos-the-last-of-us-is-a-surprisingly-simple-adaptation](https://www.pcgamer.com/so-far-hbos-the-last-of-us-is-a-surprisingly-simple-adaptation)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-13 02:20:59+00:00
 - user: None

An incredibly faithful retelling that feels like a relic of a different time.
