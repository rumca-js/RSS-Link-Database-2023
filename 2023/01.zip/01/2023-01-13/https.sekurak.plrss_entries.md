# Source Sekurak, Source URL:https://sekurak.pl/rss, Source language: pl-PL

## Piątek 13-stego. Najnowsze reguły Windows Defender mogą pomyłkowo „usuwać Programy z Menu Start”
 - [https://sekurak.pl/piatek-13-stego-najnowsze-reguly-windows-defender-moga-pomylkowo-usuwac-programy-z-menu-start/](https://sekurak.pl/piatek-13-stego-najnowsze-reguly-windows-defender-moga-pomylkowo-usuwac-programy-z-menu-start/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-13 14:02:13+00:00
 - user: None

<p>Najnowsze doniesienia są jeszcze bardziej alarmujące bo mówią o &#8222;usuwaniu całych aplikacji&#8221;: Have you had anyone report applications going missing from there laptops today? I&#8217;ve seemed to have lost all Microsoft apps, outlook/excel/word. An error message comes up saying it&#8217;s not supported and then the app seems to have uninstalled....</p>
<p>Artykuł <a href="https://sekurak.pl/piatek-13-stego-najnowsze-reguly-windows-defender-moga-pomylkowo-usuwac-programy-z-menu-start/" rel="nofollow">Piątek 13-stego. Najnowsze reguły Windows Defender mogą pomyłkowo &#8222;usuwać Programy z Menu Start&#8221;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Część pralek Samsunga stanowi zagrożenie pożarowe. Producent daje automatyczną aktualizację po WiFi. Jeśli pralka nie ma WiFi – wysyłają dongla :-]
 - [https://sekurak.pl/czesc-pralek-samsunga-stanowi-zagrozenie-pozarowe-producent-daje-automatyczna-aktualizacje-po-wifi-jesli-pralka-nie-ma-wifi-wysylaja-dongla/](https://sekurak.pl/czesc-pralek-samsunga-stanowi-zagrozenie-pozarowe-producent-daje-automatyczna-aktualizacje-po-wifi-jesli-pralka-nie-ma-wifi-wysylaja-dongla/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-13 12:29:54+00:00
 - user: None

<p>Samsung wspomina o następujących problemach, które mogą wystąpić w pewnych modelach pralek (rynek USA): This announcement addresses potential overheating within the control panel of certain models. Such events present a smoking, melting, overheating, or fire hazard to the product and consumer. Nie wygląda to dobrze, przy czym warto zwrócić uwagę...</p>
<p>Artykuł <a href="https://sekurak.pl/czesc-pralek-samsunga-stanowi-zagrozenie-pozarowe-producent-daje-automatyczna-aktualizacje-po-wifi-jesli-pralka-nie-ma-wifi-wysylaja-dongla/" rel="nofollow">Część pralek Samsunga stanowi zagrożenie pożarowe. Producent daje automatyczną aktualizację po WiFi. Jeśli pralka nie ma WiFi &#8211; wysyłają dongla :-]</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Koleżka kupił androidowy TV box (T95 AllWinner T616). A tam domyślnie działa sobie malwarek. Analiza.
 - [https://sekurak.pl/kolezka-kupil-androidowy-tv-box-t95-allwinner-t616-a-tam-domyslnie-dziala-sobie-malwarek-analiza/](https://sekurak.pl/kolezka-kupil-androidowy-tv-box-t95-allwinner-t616-a-tam-domyslnie-dziala-sobie-malwarek-analiza/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-13 09:35:11+00:00
 - user: None

<p>Bohaterem są tanie urządzenia dostępne np. na Amazonie: Badacz zakupił je najpewniej na standardowe potrzeby (tj. oglądanie TV ;) ale postanowił nieco przeanalizować zdobyty okaz: This device&#8217;s ROM turned out to be very very sketchy &#8212; Android 10 is signed with test keys, and named &#8222;Walleye&#8221; after the Google Pixel...</p>
<p>Artykuł <a href="https://sekurak.pl/kolezka-kupil-androidowy-tv-box-t95-allwinner-t616-a-tam-domyslnie-dziala-sobie-malwarek-analiza/" rel="nofollow">Koleżka kupił androidowy TV box (T95 AllWinner T616). A tam domyślnie działa sobie malwarek. Analiza.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Kolejna fala złośliwych reklam w Google. Niezainfekowany wynik może pojawiać się dopiero na 4 (!) miejscu.
 - [https://sekurak.pl/kolejna-fala-zlosliwych-reklam-w-google-niezainfekowany-wynik-moze-pojawiac-sie-dopiero-na-4-miejscu/](https://sekurak.pl/kolejna-fala-zlosliwych-reklam-w-google-niezainfekowany-wynik-moze-pojawiac-sie-dopiero-na-4-miejscu/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-13 08:44:54+00:00
 - user: None

<p>Ostatnio pisaliśmy choćby o fałszywych reklamach Gimpa: Nasz czytelnik wygooglał pakiet instalacyjny Gimpa. Trafił na fejkową reklamę, zainfekował komputer i stracił dostęp do konta Google Blender to darmowe oprogramowanie do tworzenia grafiki 3D, a ktoś na reddicie &#8222;pochwalił się&#8221; takim widokiem: Jak widzicie, mamy tu aż trzy reklamy, a prawdziwy...</p>
<p>Artykuł <a href="https://sekurak.pl/kolejna-fala-zlosliwych-reklam-w-google-niezainfekowany-wynik-moze-pojawiac-sie-dopiero-na-4-miejscu/" rel="nofollow">Kolejna fala złośliwych reklam w Google. Niezainfekowany wynik może pojawiać się dopiero na 4 (!) miejscu.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Można było hurtem pobierać CV z Linkedin (również CV uploadowane przez rekruterów). Najbardziej banalna podatność z możliwych…
 - [https://sekurak.pl/mozna-bylo-hurtem-pobierac-cv-z-linkedin-rowniez-cv-uploadowane-przez-rekruterow-najbardziej-banalna-podatnosc-z-mozliwych/](https://sekurak.pl/mozna-bylo-hurtem-pobierac-cv-z-linkedin-rowniez-cv-uploadowane-przez-rekruterow-najbardziej-banalna-podatnosc-z-mozliwych/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-13 08:25:39+00:00
 - user: None

<p>W tym miejscu możecie poczytać o szczegółach podatności znalezionej w ramach programu bug bounty LinkedIna: Unauthorized access to resumes stored on Linkedin [resumes &#8211; czyli CV &#8211; przyp. sekurak] Podatność jest klasy IDOR (insecure direct object references), czyli po ludzku można było wykonać mniej więcej coś takiego:linkedin.com/api/v4/download_resume?id=827387 oraz iterować po...</p>
<p>Artykuł <a href="https://sekurak.pl/mozna-bylo-hurtem-pobierac-cv-z-linkedin-rowniez-cv-uploadowane-przez-rekruterow-najbardziej-banalna-podatnosc-z-mozliwych/" rel="nofollow">Można było hurtem pobierać CV z Linkedin (również CV uploadowane przez rekruterów). Najbardziej banalna podatność z możliwych&#8230;</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>
