# Source Wired business, Source URL:https://www.wired.com/feed/category/business/latest/rss, Source language: en-US

## Lina Khan’s Plan to Liberate US Workers
 - [https://www.wired.com/story/plaintext-lina-khans-plan-to-liberate-us-workers/](https://www.wired.com/story/plaintext-lina-khans-plan-to-liberate-us-workers/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

The chair of the Federal Trade Commission explains why she wants to ban companies from locking up employees with noncompete clauses.

## ChatGPT Has Investors Drooling—but Can It Bring Home the Bacon?
 - [https://www.wired.com/story/chatgpt-has-investors-drooling-but-can-it-bring-home-the-bacon/](https://www.wired.com/story/chatgpt-has-investors-drooling-but-can-it-bring-home-the-bacon/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

The loquacious bot has Microsoft ready to sink a reported $10 billion into OpenAI. It’s unclear what products can be built on the technology.

## How Airports Catch Illicit Radioactive Cargo
 - [https://www.wired.com/story/heathrow-radioactive-cargo-screening/](https://www.wired.com/story/heathrow-radioactive-cargo-screening/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

Hidden screening devices are used to track the movement of dangerous materials—and recently caught a shipment of uranium at London’s Heathrow Airport.
