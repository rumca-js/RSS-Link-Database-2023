# Source Washington Examiner - world, Source URL:https://feeds.feedburner.com/dcexaminer/WorldNews, Source language: en-US

## European Union sees highest unauthorized migrant crossings since 2015 crisis
 - [https://www.washingtonexaminer.com/policy/immigration/european-union-highest-unauthorized-migrant-crossings-since-2015-crisis](https://www.washingtonexaminer.com/policy/immigration/european-union-highest-unauthorized-migrant-crossings-since-2015-crisis)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/WorldNews
 - date published: 2023-01-13 19:10:41+00:00
 - user: None

The European Union has seen the highest number of unauthorized migrant entries since 2016, during the end of the 2015 European migrant crisis.
