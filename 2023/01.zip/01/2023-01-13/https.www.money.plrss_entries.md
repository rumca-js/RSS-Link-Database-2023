# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## Inflacyjne uderzenie jeszcze przed nami. Ekonomiści wskazują, kiedy możemy spodziewać się szczytu
 - [https://www.money.pl/gospodarka/inflacyjne-uderzenie-jeszcze-przed-nami-ekonomisci-wskazuja-kiedy-mozemy-spodziewac-sie-szczytu-6855133465283488a.html](https://www.money.pl/gospodarka/inflacyjne-uderzenie-jeszcze-przed-nami-ekonomisci-wskazuja-kiedy-mozemy-spodziewac-sie-szczytu-6855133465283488a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 13:29:25+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/279aa1d7-d224-4db4-9268-717c3705ddcb" width="308" /> Inflacja jeszcze nie powiedziała ostatniego słowa. W styczniu i w lutym wskaźnik wzrostu cen wzrośnie do 19-20 proc. W tych miesiącach możemy spodziewać się szczytu. W następnych rozpocznie się powolny trend spadkowy – prognozują ekonomiści PKO BP. Najważniejszymi składowymi dla najbliższych odczytów będą ceny energii i paliw.

## Afrykańskie państwo podnosi pensje o 30 proc. w środku największego kryzysu od dekad
 - [https://www.money.pl/gospodarka/afrykanskie-panstwo-podnosi-pensje-o-30-proc-w-srodku-najwiekszego-kryzysu-od-dekad-6855116853832608a.html](https://www.money.pl/gospodarka/afrykanskie-panstwo-podnosi-pensje-o-30-proc-w-srodku-najwiekszego-kryzysu-od-dekad-6855116853832608a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 12:21:51+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4474b1af-5f13-4c08-8324-853c2fb90ba9" width="308" /> Rząd Ghany uzgodnił w ramach negocjacji ze związkami zawodowymi, że w 2023 roku pensje wszystkich urzędników państwowych wzrosną o 30 proc. - poinformowano we wspólnym oświadczeniu obu stron, na które powołuje się portal aljazeera.com. Kraj zmaga się z największym od pokoleń kryzysem gospodarczym. Inflacja w Ghanie sięga 50,3 proc.

## Kilkadziesiąt mieszkań sprzedawanych w pakiecie. Nowy typ ofert pojawia się w sieci
 - [https://www.money.pl/gospodarka/kilkadziesiat-mieszkan-sprzedawanych-w-pakiecie-nowy-typ-ofert-pojawia-sie-w-sieci-6855082003966880a.html](https://www.money.pl/gospodarka/kilkadziesiat-mieszkan-sprzedawanych-w-pakiecie-nowy-typ-ofert-pojawia-sie-w-sieci-6855082003966880a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 11:53:34+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5f49622a-39b7-43d2-a7b6-0e06cf593577" width="308" /> Na portalach internetowych pojawiła się oferta kilkudziesięciu mieszkań w pakiecie. Chętni mogą kupić 30 lub 70 mieszkań w Warszawie albo 75 w Żyrardowie. Choć nie jest to nowość na rynku, to jednak zazwyczaj sprzedaż pakietu mieszkań zawierano w deweloperskich biurach sprzedaży

## Rekordowe wzrosty kurs Allegro. Oto co się stało
 - [https://www.money.pl/gielda/gpw-notowania-allegro-rekordowe-wzrosty-kursu-oto-co-sie-stalo-6855088565459520a.html](https://www.money.pl/gielda/gpw-notowania-allegro-rekordowe-wzrosty-kursu-oto-co-sie-stalo-6855088565459520a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 11:50:14+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f612de0b-f14a-4ee9-b474-f5c3e66867db" width="308" /> Akcje Allegro zyskały wczoraj 6,5 proc., a porównaniu z październikowym dołkiem kurs jest wyższy o ponad 50 proc. Z jednej strony Allegro zyskuje na fali wzrostów całej polskiej giełdy. Z drugiej – jak podkreśla Maciej Kietliński z domu maklerskiego XTB – dużą rolę odgrywa pozytywna dla spółki informacja, że z Polski wycofuje się Shopee.

## Sejm przyjął ustawę o Sądzie Najwyższym. To ona ma odblokować pieniądze z KPO
 - [https://www.money.pl/gospodarka/sejm-przyjal-ustawe-o-sadzie-najwyzszym-to-ona-ma-odblokowac-pieniadze-z-kpo-6855083285899840a.html](https://www.money.pl/gospodarka/sejm-przyjal-ustawe-o-sadzie-najwyzszym-to-ona-ma-odblokowac-pieniadze-z-kpo-6855083285899840a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 10:05:16+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3f2d2361-3e9e-4ca3-90c8-7bcc6c50dbf9" width="308" /> Opozycja nie chciała poprzeć nowelizacji ustawy o Sądzie Najwyższym w obecnym brzmieniu. Jednak Prawo i Sprawiedliwość ani myślało przyjąć jej poprawki. Wobec tego większość posłów partii opozycyjnych wstrzymała się od głosu. Tym samym PiS, mimo braku większości w związku ze sprzeciwem Solidarnej Polski, ostatecznie przeprowadziło ustawę przez Sejm.

## To wpłynie na emerytury Polaków. GUS podał kluczowy wskaźnik
 - [https://www.money.pl/emerytury/to-wplynie-na-emerytury-polakow-gus-podal-kluczowy-wskaznik-6855065939278400a.html](https://www.money.pl/emerytury/to-wplynie-na-emerytury-polakow-gus-podal-kluczowy-wskaznik-6855065939278400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 09:01:09+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3b2f6cc4-d761-4eef-ac65-14ee278537df" width="308" /> Średnioroczny wskaźnik cen towarów i usług konsumpcyjnych ogółem w 2022 r. wyniósł 14,4 proc. - podał w piątek Główny Urząd Statystyczny. To kluczowe dane dla kilku milionów emerytów i rencistów w Polsce. Służą one m.in. do ustawowego wyliczenia wskaźnika waloryzacji świadczeń. W 2021 r. średnioroczna inflacja wynosiła 5,1 proc.

## Apple obniża wynagrodzenie swojego szefa. Dyrektor generalny będzie zarabiać o 40 proc. mniej
 - [https://www.money.pl/gielda/apple-obniza-wynagrodzenie-swojego-szefa-dyrektor-generalny-bedzie-zarabiac-o-40-proc-mniej-6855056321002048a.html](https://www.money.pl/gielda/apple-obniza-wynagrodzenie-swojego-szefa-dyrektor-generalny-bedzie-zarabiac-o-40-proc-mniej-6855056321002048a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 08:15:31+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f3619a2a-c4d4-487c-89f5-4f0047d03fb4" width="308" /> Apple obniży wynagrodzenie dyrektora generalnego. Tim Cook ma od teraz zarabiać o ponad 40 proc. mniej. W ten sposób koncern reaguje na oczekiwania własnych inwestorów, a także na prośbę samego Cooka, by dostosować jego pensję. W zamian będzie mógł liczyć na większy pakiet akcji – pisze Bloomberg.

## Czym jest podatek Belki?
 - [https://www.money.pl/gospodarka/czym-jest-podatek-belki-6854406118185536a.html](https://www.money.pl/gospodarka/czym-jest-podatek-belki-6854406118185536a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 07:59:44+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f026d2f5-4746-47d3-b0d0-39becf063f4f" width="308" /> Lokując środki na lokatach bankowych, uzyskujesz odsetki, które naliczane są według określonej z góry stawki. Podawana jest ona w ofertach bankowych w skali roku. Pamiętaj jednak, że wyliczone odsetki są pomniejszane o tak zwany podatek Belki. Co to jest i czy zawsze trzeba go płacić?

## Czym zajmuje się Rada Polityki Pieniężnej?
 - [https://www.money.pl/gospodarka/czym-zajmuje-sie-rada-polityki-pienieznej-6854407536356256a.html](https://www.money.pl/gospodarka/czym-zajmuje-sie-rada-polityki-pienieznej-6854407536356256a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 07:57:45+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8a0f2fc2-8803-4477-8be5-b0e242b6ed8b" width="308" /> Posiedzenia Rady Polityki Pieniężnej w kolejnych miesiącach 2022 roku budziły ogromne zainteresowanie Polaków. Przeciętny Kowalski śledził je z zapartym tchem, zwłaszcza wtedy, gdy spłacał kredyt w złotówkach. Od decyzji RPP zależało bowiem to, czy koszt zobowiązania wzrośnie, czy też nie. Zobacz zatem, czym zajmuje się Rada Polityki Pieniężnej. Jakie podejmuje decyzje?

## Domy na raty z pominięciem banku. Miliarder ma nowy pomysł
 - [https://www.money.pl/banki/domy-na-raty-z-pominieciem-banku-miliarder-ma-nowy-pomysl-6855033682852416a.html](https://www.money.pl/banki/domy-na-raty-z-pominieciem-banku-miliarder-ma-nowy-pomysl-6855033682852416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 07:15:44+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ad5bf852-2000-4e28-b8ce-215069413011" width="308" /> - Uruchamiamy sprzedaż domów jednorodzinnych na raty — poinformował Józef Wojciechowski, szef rady nadzorczej J.W. Construction Holding SA. W rozmowie z portalem wnp.pl deweloper zapowiedział, że jego firma chce zastąpić banki do czasu, aż na rynku pojawią się tańsze kredyty. - Będziemy tu pionierami na rynku - uważa.

## Biedronka przekroczyła kolejną granicę. Zwiększyła sprzedaż o ponad jedną piątą
 - [https://www.money.pl/gospodarka/biedronka-przekroczyla-kolejna-granice-zwiekszyla-sprzedaz-o-ponad-jedna-piata-6855036611848768a.html](https://www.money.pl/gospodarka/biedronka-przekroczyla-kolejna-granice-zwiekszyla-sprzedaz-o-ponad-jedna-piata-6855036611848768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:55:00+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/03059d47-dbdf-49cc-b940-af2915f5286b" width="308" /> Rekordowy rok za Biedronką. Sieć handlowa zanotowała sprzedaż na poziomie 17,58 mld euro. To oznacza wzrost o niemal 21 proc. w porównaniu z wynikiem za 2021 r. Tym samym firma na naszym rynku przekroczyła barierę ponad 80 mld zł przychodów – podaje portal wiadomoscihandlowe.pl.

## Tak PiS zebrało 1,3 mln zł na kampanię wyborczą. "Zrzutka" od zarządów państwowych spółek
 - [https://www.money.pl/pieniadze/tak-pis-zebralo-1-3-mln-zl-na-kampanie-wyborcza-zrzutka-od-zarzadow-panstwowych-spolek-6855024559069760a.html](https://www.money.pl/pieniadze/tak-pis-zebralo-1-3-mln-zl-na-kampanie-wyborcza-zrzutka-od-zarzadow-panstwowych-spolek-6855024559069760a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:29:31+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bd6d1311-efd6-4081-8e22-c884083492ca" width="308" /> Wyborcza kampania wymaga od partii sporych wydatków. Pieniądze trzeba przeznaczyć m.in. na jej organizację i promocję swoich kandydatów. Dlatego też ugrupowania liczą na wpłaty od darczyńców i sympatyków. Szczególnie Prawo i Sprawiedliwość, które swoich zwolenników upycha w spółkach Skarbu Państwa. W zamian partia uzyskała od nich prawie 1,3 mln zł.

## Kursy walut 13.01.2023. Piątkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-13-01-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6855025568066112a.html](https://www.money.pl/pieniadze/kursy-walut-13-01-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6855025568066112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:10:24+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 13.01.2023. W piątek za jednego dolara (USD) zapłacimy 4.3348 zł. Cena jednego funta szterlinga (GBP) to 5.2828 zł, a franka szwajcarskiego (CHF) 4.6570 zł. Z kolei euro (EUR) możemy zakupić za 4.6980 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 13.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-13-01-2023-6855024314510240a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-13-01-2023-6855024314510240a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:05:22+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 13.01.2023. W piątek za jednego dolara (USD) trzeba zapłacić 4.3317 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 13.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-13-01-2023-6855024311073696a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-13-01-2023-6855024311073696a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:05:21+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 13.01.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2793 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 13.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-13-01-2023-6855024309214112a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-13-01-2023-6855024309214112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:05:20+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 13.01.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.6957 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 13.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-13-01-2023-6855024306215488a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-13-01-2023-6855024306215488a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 06:05:20+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 13.01.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.6553 zł.

## Rząd chce chronić Polaków. A przy okazji dowiedzieć się o nich więcej
 - [https://www.money.pl/gospodarka/rzad-chce-chronic-polakow-a-przy-okazji-dowiedziec-sie-o-nich-wiecej-6855021223820192a.html](https://www.money.pl/gospodarka/rzad-chce-chronic-polakow-a-przy-okazji-dowiedziec-sie-o-nich-wiecej-6855021223820192a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-13 05:52:41+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/45a9ca44-0b34-4d74-828a-fac8b76b5009" width="308" /> Rząd chce zmienić przepisy dotyczące prawa komunikacji elektronicznej. Nowelizacja ma wprowadzić korzystne rozwiązania dla klientów telekomów. Przy okazji jednak chce jednak wydłużyć obowiązek przetrzymywania danych z komunikatorów, z których korzystają Polacy.
