# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## US Supreme Court to consider religious discrimination case
 - [https://www.aljazeera.com/news/2023/1/13/us-supreme-court-to-consider-religious-discrimination-case](https://www.aljazeera.com/news/2023/1/13/us-supreme-court-to-consider-religious-discrimination-case)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 23:46:55+00:00
 - user: None

The case involves a postal carrier who says he cannot work on Sunday due to his religious beliefs.

## Brazil prepares to seek extradition of Bolsonaro ally from US
 - [https://www.aljazeera.com/news/2023/1/13/brazil-prepares-to-seek-extradition-of-bolsonaro-ally-from-us](https://www.aljazeera.com/news/2023/1/13/brazil-prepares-to-seek-extradition-of-bolsonaro-ally-from-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 23:31:12+00:00
 - user: None

Brazilian authorities are seeking return of former justice minister Anderson Torres as part of probe into Brasilia riot.

## US treasury secretary Yellen warns of hitting debt cap by June
 - [https://www.aljazeera.com/economy/2023/1/13/us-treasury-secretary-yellen-warns-of-hitting-debt-cap-by-june](https://www.aljazeera.com/economy/2023/1/13/us-treasury-secretary-yellen-warns-of-hitting-debt-cap-by-june)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 23:28:04+00:00
 - user: None

In a letter, Janet Yellen urged congressional leaders to quickly act to raise the debt ceiling.

## US President Biden to give State of the Union speech in February
 - [https://www.aljazeera.com/news/2023/1/13/us-president-biden-to-give-state-of-the-union-speech-in-february](https://www.aljazeera.com/news/2023/1/13/us-president-biden-to-give-state-of-the-union-speech-in-february)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 22:38:04+00:00
 - user: None

Biden will likely push for bipartisanship as he faces an empowered Republican majority in House of Representatives.

## Frene Ginwala: First democratic S African parliament speaker dies
 - [https://www.aljazeera.com/news/2023/1/13/frene-ginwala-first-democratic-s-african-parliament-speaker-dies](https://www.aljazeera.com/news/2023/1/13/frene-ginwala-first-democratic-s-african-parliament-speaker-dies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 21:23:17+00:00
 - user: None

Frene Noshir Ginwala, called the &#039;torchbearer&#039; of the post-apartheid parliament, dies aged 90 after suffering a stroke.

## Gas pipeline between Lithuania and Latvia blows up
 - [https://www.aljazeera.com/news/2023/1/13/gas-pipeline-between-lithuania-latvia-blows-up](https://www.aljazeera.com/news/2023/1/13/gas-pipeline-between-lithuania-latvia-blows-up)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 20:57:22+00:00
 - user: None

Fire put out at site of a gas pipeline explosion in northern Lithuania with no signs of attack or casualties.

## Peru attorney general launches investigations into protest deaths
 - [https://www.aljazeera.com/news/2023/1/13/peru-attorney-general-launches-investigations-into-protest-deaths](https://www.aljazeera.com/news/2023/1/13/peru-attorney-general-launches-investigations-into-protest-deaths)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 20:27:41+00:00
 - user: None

Probes will focus on deadly clashes at ongoing anti-government protests spurred by removal of ex-President Castillo.

## Sinking Himalayan town puts spotlight on India’s hydropower push
 - [https://www.aljazeera.com/news/2023/1/13/sinking-himalayan-town-puts-spotlight-on-indias-hydropower-push](https://www.aljazeera.com/news/2023/1/13/sinking-himalayan-town-puts-spotlight-on-indias-hydropower-push)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 20:03:03+00:00
 - user: None

Locals blame the damage on a hotel construction boom and tunneling for a nearby hydroelectric project.

## What’s behind finding of classified files in Biden home, office?
 - [https://www.aljazeera.com/program/inside-story/2023/1/13/whats-behind-finding-of-classified-files-in-biden-home-office](https://www.aljazeera.com/program/inside-story/2023/1/13/whats-behind-finding-of-classified-files-in-biden-home-office)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 19:43:09+00:00
 - user: None

It comes as an inquiry continues into former President Donald Trump&#039;s retention of classified papers.

## Canada imposes new sanctions on two ‘Haitian elites’
 - [https://www.aljazeera.com/news/2023/1/13/canada-imposes-fresh-sanctions-on-two-haitian-elites](https://www.aljazeera.com/news/2023/1/13/canada-imposes-fresh-sanctions-on-two-haitian-elites)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 19:32:15+00:00
 - user: None

Canadian government has accused two Haitian nationals, including associate of ex-President Martelly, of enabling gangs.

## Photos: Death toll expected to rise after tornadoes strike US
 - [https://www.aljazeera.com/gallery/2023/1/13/photos-death-toll-expected-to-rise-after-tornadoes-strike-us](https://www.aljazeera.com/gallery/2023/1/13/photos-death-toll-expected-to-rise-after-tornadoes-strike-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 19:00:24+00:00
 - user: None

The US National Weather Service received 45 tornado reports on Thursday, as violent storms whipped across the southeast.

## Tesla slashes prices globally by as much as 20 percent
 - [https://www.aljazeera.com/economy/2023/1/13/tesla-slashes-prices-globally-by-as-much-as-20](https://www.aljazeera.com/economy/2023/1/13/tesla-slashes-prices-globally-by-as-much-as-20)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 18:50:18+00:00
 - user: None

Price cuts challenge electric carmaker&#039;s rivals and reverse its strategy of past two years when orders exceeded supply.

## Apple CEO Tim Cook to take a more than 40 percent pay cut
 - [https://www.aljazeera.com/economy/2023/1/13/apple-ceo-tim-cook-to-take-a-more-than-40-pay-cut](https://www.aljazeera.com/economy/2023/1/13/apple-ceo-tim-cook-to-take-a-more-than-40-pay-cut)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 18:48:31+00:00
 - user: None

The compensation committee took into account shareholder feedback, company performance and a recommendation by Cook.

## Afghans condemn Australia’s boycott of men’s cricket team
 - [https://www.aljazeera.com/news/2023/1/13/afghans-condemn-australias-boycott-of-men-cricket-team](https://www.aljazeera.com/news/2023/1/13/afghans-condemn-australias-boycott-of-men-cricket-team)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 17:49:37+00:00
 - user: None

Afghan cricketers lead the chorus of criticism against Australia&#039;s decision to cancel a cricket series due in March.

## Iran’s top diplomat says talks with Saudis could restore ties
 - [https://www.aljazeera.com/news/2023/1/13/irans-fm-says-hopes-to-rekindle-ties-with-saudi-arabia](https://www.aljazeera.com/news/2023/1/13/irans-fm-says-hopes-to-rekindle-ties-with-saudi-arabia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 17:34:50+00:00
 - user: None

Iranian foreign minister says he hopes diplomatic ties with Saudi Arabia can be restored after years of tensions.

## Biden hosting Kishida as US, Japan bolster ties in face of China
 - [https://www.aljazeera.com/news/2023/1/13/biden-hosting-kishida-as-us-japan-bolster-ties-in-face-of-china](https://www.aljazeera.com/news/2023/1/13/biden-hosting-kishida-as-us-japan-bolster-ties-in-face-of-china)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 16:37:50+00:00
 - user: None

Talks in Washington are part of Japanese prime minister&#039;s diplomatic blitz to boost partnerships amid China pressure.

## Trump Organization fined $1.6m for ‘brazen’ tax fraud
 - [https://www.aljazeera.com/news/2023/1/13/trump-organization-fined-1-6-million-for-tax-fraud](https://www.aljazeera.com/news/2023/1/13/trump-organization-fined-1-6-million-for-tax-fraud)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 16:37:37+00:00
 - user: None

The penalty is the maximum the judge could impose on the company, found guilty of 17 criminal charges.

## What does Russia’s military shake-up mean for the war in Ukraine?
 - [https://www.aljazeera.com/news/2023/1/13/what-does-russias-military-shakeup-mean-for-the-war-in-ukraine](https://www.aljazeera.com/news/2023/1/13/what-does-russias-military-shakeup-mean-for-the-war-in-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 16:21:39+00:00
 - user: None

The appointment of Valery Gerasimov signals Moscow&#039;s failing war effort and fraught domestic politics, analysts say.

## Greek court rejects charges against aid workers
 - [https://www.aljazeera.com/news/2023/1/13/greek-court-rejects-charges-against-aid-workers](https://www.aljazeera.com/news/2023/1/13/greek-court-rejects-charges-against-aid-workers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 16:04:31+00:00
 - user: None

Lesbos court says cases brought against two dozen people have procedural flaws.

## For Biden, probe of classified documents is a political snag
 - [https://www.aljazeera.com/news/2023/1/13/for-biden-probe-of-classified-documents-is-a-political-snag](https://www.aljazeera.com/news/2023/1/13/for-biden-probe-of-classified-documents-is-a-political-snag)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 15:26:41+00:00
 - user: None

Special counsels are investigating both Donald Trump and Joe Biden over their handling of classified documents.

## Sri Lanka to slash military by a third to cut costs
 - [https://www.aljazeera.com/news/2023/1/13/bankrupt-sri-lanka-to-slash-military-by-third-to-cut-costs](https://www.aljazeera.com/news/2023/1/13/bankrupt-sri-lanka-to-slash-military-by-third-to-cut-costs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 14:47:11+00:00
 - user: None

The bankrupt country says it will reduce army personnel to 135,000 by next year and 100,000 by 2030.

## Belarus could join war if Ukraine ‘invades’, says Russia
 - [https://www.aljazeera.com/news/2023/1/13/russia-warns-belarus-may-enter-ukraine-war-if-invaded](https://www.aljazeera.com/news/2023/1/13/russia-warns-belarus-may-enter-ukraine-war-if-invaded)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 14:38:35+00:00
 - user: None

Moscow warns of &#039;collective response&#039; to any attack on Russia or Belarus, as allies prepare to stage joint drills.

## Tunisia increasingly isolated under Saied as US loses interest
 - [https://www.aljazeera.com/news/2023/1/13/president-saied-isolating-tunisia-as-us-loses-interest](https://www.aljazeera.com/news/2023/1/13/president-saied-isolating-tunisia-as-us-loses-interest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 12:45:47+00:00
 - user: None

The president has tried to look abroad to get the country out of its economic crisis, without much success.

## Iran praises possible rapprochement between Syria and Turkey
 - [https://www.aljazeera.com/news/2023/1/13/iran-praises-rapprochement-between-its-ally-syria-and-turkey](https://www.aljazeera.com/news/2023/1/13/iran-praises-rapprochement-between-its-ally-syria-and-turkey)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 12:29:14+00:00
 - user: None

Moscow supports Damascus-Ankara talks, which al-Assad says must lead to an end of Turkey&#039;s &quot;occupation&quot; of Syrian land.

## Drop all charges against refugee aid workers, UN tells Greece
 - [https://www.aljazeera.com/news/2023/1/13/un-asks-greece-drop-charges-in-syrian-migrant-rescuer-trial](https://www.aljazeera.com/news/2023/1/13/un-asks-greece-drop-charges-in-syrian-migrant-rescuer-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 12:17:48+00:00
 - user: None

Syrian swimmer Sara Mardini and several other foreign and Greek refugee rescue workers are on trial in Lesbos.

## Amhara forces withdraw from northern Ethiopia’s Tigray region
 - [https://www.aljazeera.com/news/2023/1/13/amhara-forces-leave-northern-ethiopias-tigray-region](https://www.aljazeera.com/news/2023/1/13/amhara-forces-leave-northern-ethiopias-tigray-region)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 12:07:05+00:00
 - user: None

The Ethiopian army says Amhara forces have left war-torn Tigray in compliance with a truce agreed on November 2.

## Russia says its forces have taken control of Ukraine’s Soledar
 - [https://www.aljazeera.com/news/2023/1/13/russia-says-its-forces-have-taken-control-of-ukraines-soledar](https://www.aljazeera.com/news/2023/1/13/russia-says-its-forces-have-taken-control-of-ukraines-soledar)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 11:42:07+00:00
 - user: None

Moscow says its capture of the eastern town will enable Russian troops to envelop the nearby city of Bakhmut.

## Astronomers find Milky Way galaxy’s most-distant stars
 - [https://www.aljazeera.com/news/2023/1/13/astronomers-discover-milky-way-galaxys-most-distant-stars](https://www.aljazeera.com/news/2023/1/13/astronomers-discover-milky-way-galaxys-most-distant-stars)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 11:35:33+00:00
 - user: None

Astronomers found 208 stars of which the furthest is 1.08 million light years from Earth.

## Pro-government parties win parliament majority in Benin polls
 - [https://www.aljazeera.com/news/2023/1/13/benin-pro-govt-parties-win-parliament-majority](https://www.aljazeera.com/news/2023/1/13/benin-pro-govt-parties-win-parliament-majority)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 11:00:12+00:00
 - user: None

The two parties supporting President Talon together won 81 out of 109 seats.

## India urged to close airspace to Myanmar warplanes after attacks
 - [https://www.aljazeera.com/news/2023/1/13/india-urged-to-close-airspace-to-myanmar-warplanes-after-attacks](https://www.aljazeera.com/news/2023/1/13/india-urged-to-close-airspace-to-myanmar-warplanes-after-attacks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 10:45:31+00:00
 - user: None

Fortify Rights said Myanmar&#039;s air force &#039;dropped bombs on both sides of the Myanmar-India border&#039; in raids this week.

## Koblenz trial one year on: ‘It should have been in Damascus’
 - [https://www.aljazeera.com/opinions/2023/1/13/koblenz-trial-one-year-on-it-should-have-been-in-damascus](https://www.aljazeera.com/opinions/2023/1/13/koblenz-trial-one-year-on-it-should-have-been-in-damascus)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 10:04:55+00:00
 - user: None

The proceedings against Syrian regime officials in Germany were in no way perfect - but still a momentous achievement.

## Pakistan foreign exchange reserves drop to lowest since 2014
 - [https://www.aljazeera.com/news/2023/1/13/pakistan-foreign-exchange-rates-drop-to-lowest-since-2014](https://www.aljazeera.com/news/2023/1/13/pakistan-foreign-exchange-rates-drop-to-lowest-since-2014)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 09:38:18+00:00
 - user: None

Experts paint a gloomy picture, saying the government must reconsider its priorities.

## What’s behind the computer glitch that grounded US flights?
 - [https://www.aljazeera.com/program/inside-story/2023/1/13/whats-behind-the-computer-glitch-that-grounded-us-flights](https://www.aljazeera.com/program/inside-story/2023/1/13/whats-behind-the-computer-glitch-that-grounded-us-flights)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 09:34:53+00:00
 - user: None

Thousands of domestic and international flights were disrupted on Wednesday.

## S Korea police seek to charge officials over 159 killed in crush
 - [https://www.aljazeera.com/news/2023/1/13/s-korea-police-seek-to-charge-officials-over-159-killed-in-crush](https://www.aljazeera.com/news/2023/1/13/s-korea-police-seek-to-charge-officials-over-159-killed-in-crush)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 09:11:43+00:00
 - user: None

Inquiry finds officials in Seoul had failed to employ adequate crowd control for an expected Halloween crowd of 100,000.

## Hundreds rally against al-Shabab in Somali capital Mogadishu
 - [https://www.aljazeera.com/news/2023/1/13/hundreds-rally-against-al-shabab-in-somali-capital-mogadishu](https://www.aljazeera.com/news/2023/1/13/hundreds-rally-against-al-shabab-in-somali-capital-mogadishu)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 09:05:43+00:00
 - user: None

Somalia President Mohamud urges citizens to help flush out members of the group he describes as &#039;bedbugs&#039;.

## Ghana increases salaries by 30 percent amid economic woes
 - [https://www.aljazeera.com/news/2023/1/13/crisis-hit-ghana-increases-public-servant-salaries-by-30](https://www.aljazeera.com/news/2023/1/13/crisis-hit-ghana-increases-public-servant-salaries-by-30)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 08:37:22+00:00
 - user: None

Inflation is hovering at a record 50.3 percent in Ghana, once described as Africa’s shining star by the World Bank.

## Japan prosecutors indict man for ex-PM Shinzo Abe murder: Media
 - [https://www.aljazeera.com/news/2023/1/13/japan-prosecutors-indict-man-for-ex-pm-shinzo-abe-murder-media](https://www.aljazeera.com/news/2023/1/13/japan-prosecutors-indict-man-for-ex-pm-shinzo-abe-murder-media)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 08:07:46+00:00
 - user: None

Suspect Tetsuya Yamagami, 42, was indicted on murder charges and violating gun laws for the shooting of Shinzo Abe.

## Turkey summons Swedish ambassador over Erdogan effigy protest
 - [https://www.aljazeera.com/news/2023/1/13/turkey-summons-swedish-ambassador-over-erdogan-puppet-protest](https://www.aljazeera.com/news/2023/1/13/turkey-summons-swedish-ambassador-over-erdogan-puppet-protest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 07:52:08+00:00
 - user: None

Footage showed what Turkish media said was a protest by the PKK, in which they hung up an effigy of Erdogan.

## Seven dead in US South after severe rain, tornadoes
 - [https://www.aljazeera.com/news/2023/1/13/seven-dead-in-us-south-amid-severe-winds-tornadoes](https://www.aljazeera.com/news/2023/1/13/seven-dead-in-us-south-amid-severe-winds-tornadoes)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 07:46:49+00:00
 - user: None

Strong winds and heavy rain damage homes, tens of thousands without power in parts of Georgia, Mississippi and Alabama.

## CIA chief visits Libya after Lockerbie suspect handover
 - [https://www.aljazeera.com/news/2023/1/13/cia-chief-visits-libya-after-lockerbie-suspect-handover](https://www.aljazeera.com/news/2023/1/13/cia-chief-visits-libya-after-lockerbie-suspect-handover)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 07:32:54+00:00
 - user: None

William Burns makes a rare trip to Libya, meeting the country&#039;s interim prime minister and his rival, Khalifa Haftar.

## China’s imports, exports plunge in warning sign for economy
 - [https://www.aljazeera.com/economy/2023/1/13/chinas-imports-exports-plunge-in-warning-sign-for-economy](https://www.aljazeera.com/economy/2023/1/13/chinas-imports-exports-plunge-in-warning-sign-for-economy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 07:08:42+00:00
 - user: None

Exports shrink 9.9 percent year-on-year in December, while imports decline 8.7 percent.

## Thai army kills 5 suspected drug smugglers near ‘Golden Triangle’
 - [https://www.aljazeera.com/news/2023/1/13/thai-army-kills-5-suspected-drug-smugglers-near-golden-triangle](https://www.aljazeera.com/news/2023/1/13/thai-army-kills-5-suspected-drug-smugglers-near-golden-triangle)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 07:01:15+00:00
 - user: None

Almost 500,000 methamphetamine pills found after clash between Thai forces and suspected smugglers in Thailand&#039;s north.

## Russia-Ukraine war: List of key events, day 324
 - [https://www.aljazeera.com/news/2023/1/13/russia-ukraine-war-list-of-key-events-day-324](https://www.aljazeera.com/news/2023/1/13/russia-ukraine-war-list-of-key-events-day-324)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 06:35:03+00:00
 - user: None

As the Russia-Ukraine war enters its 324th day, we take a look at the main developments.

## US states Wisconsin, North Carolina unveil TikTok bans
 - [https://www.aljazeera.com/economy/2023/1/13/us-states-of-wisconsin-north-carolina-unveil-tiktok-bans](https://www.aljazeera.com/economy/2023/1/13/us-states-of-wisconsin-north-carolina-unveil-tiktok-bans)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 05:27:07+00:00
 - user: None

Moves come after US President Joe Biden signed law banning federal employees from using the app on government devices.

## Peru’s gateway airport to Machu Picchu closes as protests grow
 - [https://www.aljazeera.com/news/2023/1/13/gateway-airport-to-perus-machu-picchu-closed-as-protests-grow](https://www.aljazeera.com/news/2023/1/13/gateway-airport-to-perus-machu-picchu-closed-as-protests-grow)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 04:50:14+00:00
 - user: None

Safety considerations led to the closure of airport in Cusco, a gateway to Peru&#039;s tourism crown jewel of Machu Picchu.

## UK says Hong Kong freedoms continue to erode, drawing China anger
 - [https://www.aljazeera.com/news/2023/1/13/uk-says-hong-kong-freedoms-continue-to-erode-drawing-china-anger](https://www.aljazeera.com/news/2023/1/13/uk-says-hong-kong-freedoms-continue-to-erode-drawing-china-anger)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 04:39:40+00:00
 - user: None

Former colonial power in the territory says it is in China’s interests that Hong Kong maintain its distinctiveness.

## Lisa Marie Presley dies at 54 after suspected cardiac arrest
 - [https://www.aljazeera.com/news/2023/1/13/lisa-marie-presley-dies-at-54-after-suspected-cardiac-arrest](https://www.aljazeera.com/news/2023/1/13/lisa-marie-presley-dies-at-54-after-suspected-cardiac-arrest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 03:18:18+00:00
 - user: None

Mother confirms death of musician and only daughter of rock &#039;n&#039; roll legend Elvis Presley.

## ExxonMobil predicted climate change while downplaying risk: Study
 - [https://www.aljazeera.com/economy/2023/1/13/exxonmobil-predicted-climate-change-while-downplaying-risk-study](https://www.aljazeera.com/economy/2023/1/13/exxonmobil-predicted-climate-change-while-downplaying-risk-study)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 02:57:36+00:00
 - user: None

Texas, US-based company’s own scientists accurately predicted global warming as far back as the 1970s, study says.

## Japan says Fukushima water release to start in ‘spring or summer’
 - [https://www.aljazeera.com/news/2023/1/13/japan-says-fukushima-water-release-to-start-in-spring-or-summer](https://www.aljazeera.com/news/2023/1/13/japan-says-fukushima-water-release-to-start-in-spring-or-summer)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 01:50:22+00:00
 - user: None

Plan will see some 1 million tonnes of water used to cool the ruined plant&#039;s reactors released into the Pacific.

## IMF chief sees 2023 global growth forecast holding steady
 - [https://www.aljazeera.com/economy/2023/1/13/imf-chief-sees-2023-global-growth-forecast-holding-steady](https://www.aljazeera.com/economy/2023/1/13/imf-chief-sees-2023-global-growth-forecast-holding-steady)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 01:06:23+00:00
 - user: None

IMF Managing Director Kristalina Georgieva says 2023 to be another &quot;tough year&quot; for the global economy.

## ‘Extremely dangerous’ tornado tears across US South as storms hit
 - [https://www.aljazeera.com/news/2023/1/13/extremely-dangerous-tornado-tears-across-us-south-as-storms-hit](https://www.aljazeera.com/news/2023/1/13/extremely-dangerous-tornado-tears-across-us-south-as-storms-hit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-13 00:24:06+00:00
 - user: None

The National Weather Service received 33 tornado reports across southern states like Alabama, Georgia and Kentucky.
