# Source Gizmodo, Source URL:https://gizmodo.com/rss, Source language: en-US

## Where Will You Be When the Robot Apocalypse Begins?
 - [https://gizmodo.com/scifi-comedy-short-uprising-robot-apocalypse-john-gembe-1849987933](https://gizmodo.com/scifi-comedy-short-uprising-robot-apocalypse-john-gembe-1849987933)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 23:03:30+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2NMBCLxw--/c_fit,fl_progressive,q_80,w_636/1378167850bd42973e74908c762411d2.jpg" /><p>It’s a day like any other for Bernie (John Gemberling, whose voice credits include <a href="https://gizmodo.com/bobs-burgers-movie-cast-and-crew-interview-loren-boucha-1848938225"><em>Bob’s Burgers</em></a>, <a href="https://gizmodo.com/big-mouths-new-season-looks-buggy-as-hell-1847871624"><em>Big Mouth</em></a>, and <em>Central Park</em>): toiling at his office job, visiting his stoner besties, mooning over his mega-crush. But as it turns out, this is <em>not</em> any other day: this is the day <a href="https://gizmodo.com/netflixs-anime-eden-shows-the-robot-apocalypse-can-be-b-1846887223">the robots rebel</a>.</p><p><a href="https://gizmodo.com/scifi-comedy-short-uprising-robot-apocalypse-john-gembe-1849987933">Read more...</a></p>

## Republicans Create Culture War Over… Stoves
 - [https://gizmodo.com/republicans-create-culture-war-over-stoves-1849987910](https://gizmodo.com/republicans-create-culture-war-over-stoves-1849987910)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Si8ZN2Qq--/c_fit,fl_progressive,q_80,w_636/91893f69c25e18e633ffa049e5d2ee16.jpg" /><p><a href="https://gizmodo.com/republicans-create-culture-war-over-stoves-1849987910">Read more...</a></p>

## Voice AI Company SoundHound Lays Off Nearly Half Its Staff and Offers ‘Pitiful’ Severance
 - [https://gizmodo.com/soundhound-lays-off-half-employees-pitiful-severance-1849987534](https://gizmodo.com/soundhound-lays-off-half-employees-pitiful-severance-1849987534)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vB0TF3X7--/c_fit,fl_progressive,q_80,w_636/4825861cb9e4a432c4fa35e0b32a7b7b.jpg" /><p>SoundHound, a voice AI company, laid off nearly half of its remaining staff last week—roughly 200 people—in a major company-wide downsizing, according to three employees who lost their jobs and an email from the CEO viewed by Gizmodo. What’s more, the former SoundHound employees are in for a rough landing. Their…</p><p><a href="https://gizmodo.com/soundhound-lays-off-half-employees-pitiful-severance-1849987534">Read more...</a></p>

## This Week's Best Toys Take Us Across the Spider-Verse, the Great Outdoors, and the Forgotten Realms
 - [https://gizmodo.com/toy-aisle-across-the-spider-verse-indiana-jones-lego-1849972349](https://gizmodo.com/toy-aisle-across-the-spider-verse-indiana-jones-lego-1849972349)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--u4cFTICj--/c_fit,fl_progressive,q_80,w_636/a622ce7c4360d0e37d9e292fe117f65a.jpg" /><p>Welcome back to Toy Aisle. This week we return to the <a href="https://gizmodo.com/spiderman-across-spider-verse-trailer-into-spiderverse-1849885335">Spider-Verse</a> with Miles and Gwen figures from S.H.Figuarts, start the <a href="https://gizmodo.com/transformers-rise-of-the-beasts-trailer-teaser-beast-wa-1849839119"><em>Transformers Rise of the Beasts</em></a> merchandising onslaught with Arcee, and begin our <a href="https://gizmodo.com/nerdy-valentines-cards-2022-spider-man-dune-batman-b-1848534862">Valentine’s Day</a> planning with a Pokémon Love Ball Poké Ball replica from the Wand Company. Check it out!</p><p><a href="https://gizmodo.com/toy-aisle-across-the-spider-verse-indiana-jones-lego-1849972349">Read more...</a></p>

## Judge Says Elon Musk's Trial Must Take Place on Twitter's Home Turf
 - [https://gizmodo.com/tesla-elon-musk-twitter-texas-trial-1849987555](https://gizmodo.com/tesla-elon-musk-twitter-texas-trial-1849987555)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--m2avd5Zy--/c_fit,fl_progressive,q_80,w_636/c78eb2b65b2a1764c592621b11ece70f.jpg" /><p>A judge told Tesla CEO Elon Musk and his attorneys that, no, the court won’t move his upcoming securities fraud trial out of San Francisco even if there’s a dwindling number of people in the Bay Area with a positive opinion of the Twitter owner.</p><p><a href="https://gizmodo.com/tesla-elon-musk-twitter-texas-trial-1849987555">Read more...</a></p>

## An Oil Exec Will Lead the UN's 2023 Climate Summit
 - [https://gizmodo.com/cop28-uae-sultan-ahmed-al-jaber-oil-executive-climate-1849985666](https://gizmodo.com/cop28-uae-sultan-ahmed-al-jaber-oil-executive-climate-1849985666)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--btaaMIIU--/c_fit,fl_progressive,q_80,w_636/61e3bcc3515afc2d4721c176120ce1dc.jpg" /><p>For nearly 30 years, nations, nonprofits, researchers, industry representatives, and other stakeholders have gathered annually at the United Nations’ Conference of Parties—commonly <a href="https://gizmodo.com/what-is-cop27-egypt-1849742336">known as COP</a>—to talk through implementation of the U.N.’s climate change treaty. Though deeply imperfect, these summits are <a href="https://gizmodo.com/i-need-you-to-care-about-the-un-climate-talks-1847962084">a critical…</a></p><p><a href="https://gizmodo.com/cop28-uae-sultan-ahmed-al-jaber-oil-executive-climate-1849985666">Read more...</a></p>

## Exclusive "Violent Night" Deleted Scene Featuring David Harbour's Badass Santa
 - [https://gizmodo.com/violent-night-deleted-scene-david-harbours-badass-sant-1849981022](https://gizmodo.com/violent-night-deleted-scene-david-harbours-badass-sant-1849981022)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 22:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9z1eAOda--/c_fit,fl_progressive,q_80,w_636/5f53aedd460bbd775cd21bbfe1b778cd.jpg" /><p><a href="https://gizmodo.com/violent-night-deleted-scene-david-harbours-badass-sant-1849981022">Read more...</a></p>

## YouTube Is Testing a Free, Ad-supported Streaming Service
 - [https://gizmodo.com/youtube-streaming-service-netflix-1849987382](https://gizmodo.com/youtube-streaming-service-netflix-1849987382)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 21:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--w7bpXpid--/c_fit,fl_progressive,q_80,w_636/2b3f255de868e9852989a2f2b75d0d16.jpg" /><p>YouTube announced it is introducing free, ad-supported streaming channels in a product test as the company grows its video platform. The new hub, known as FAST, would create competition for other industry players including <a href="https://gizmodo.com/roku-is-branching-out-with-its-own-brand-of-tvs-1849946014">Roku</a>, <a href="https://gizmodo.com/streaming-services-acorn-tv-tubi-tv-hoopla-crackle-1849449825">Pluto TV, and Tubi</a>.</p><p><a href="https://gizmodo.com/youtube-streaming-service-netflix-1849987382">Read more...</a></p>

## Blacula Rises Again in a Gorgeous New Graphic Novel
 - [https://gizmodo.com/blacula-return-of-the-king-graphic-novel-blaxploitation-1849986293](https://gizmodo.com/blacula-return-of-the-king-graphic-novel-blaxploitation-1849986293)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 21:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lPjrbxBJ--/c_fit,fl_progressive,q_80,w_636/78bf1cd67b8ba86eb7c1a779ec61bde1.jpg" /><p><a href="https://gizmodo.com/blacula-was-about-the-respectable-monster-haunting-us-a-1847238529"><em>Blacula</em></a> isn’t as famous as <a href="https://gizmodo.com/best-worst-dracula-depictions-actors-movies-vampire-lee-1848758521"><em>Dracula</em></a>, but he has a great deal more to be angry about. The star of the 1972 <a href="https://gizmodo.com/blacula-will-rise-again-to-seek-revenge-in-new-reboot-1847124930">blaxploitation horror hit</a> was an 18th-century African prince who asked Dracula’s help to end the slave trade. Instead, Dracula turned him into a vampire, killed his wife, and imprisoned him under his castle.…</p><p><a href="https://gizmodo.com/blacula-return-of-the-king-graphic-novel-blaxploitation-1849986293">Read more...</a></p>

## Scientists Are Testing an Old Cough Medicine as a Parkinson's Disease Treatment
 - [https://gizmodo.com/cough-medicine-ambroxol-parkinsons-disease-trial-1849986729](https://gizmodo.com/cough-medicine-ambroxol-parkinsons-disease-trial-1849986729)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 21:12:49+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--S5TCL0xu--/c_fit,fl_progressive,q_80,w_636/6fc8342367ac2281714025589fde7c0f.jpg" /><p>An important clinical trial for Parkinson’s disease has just gotten underway in the UK. The  placebo-controlled Phase III trial will test whether a long-existing cough medication can slow down the progression of the neurodegenerative condition and improve people’s quality of life. Earlier studies have suggested that…</p><p><a href="https://gizmodo.com/cough-medicine-ambroxol-parkinsons-disease-trial-1849986729">Read more...</a></p>

## Tesla Tries to Salvage Shrinking Stock and Fend-Off Competition by Slashing Prices Up to 20%
 - [https://gizmodo.com/tesla-elon-musk-ev-tesla-sale-discount-cars-1849986794](https://gizmodo.com/tesla-elon-musk-ev-tesla-sale-discount-cars-1849986794)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 20:50:48+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--pfjUTtI8--/c_fit,fl_progressive,q_80,w_636/42239bf5560cb094559deb3ef8a36bcc.jpg" /><p>Increased competition from global carmakers and management missteps have led Tesla, once one of the world’s more expensive electric vehicle makers, to introduce new price cuts across its lineup of products.</p><p><a href="https://gizmodo.com/tesla-elon-musk-ev-tesla-sale-discount-cars-1849986794">Read more...</a></p>

## Harry Styles Serves Suit Over Stolen Styles
 - [https://gizmodo.com/harry-styles-merchandise-counterfeit-1849986633](https://gizmodo.com/harry-styles-merchandise-counterfeit-1849986633)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 20:30:46+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--al8dIM_o--/c_fit,fl_progressive,q_80,w_636/74dc130bd76eb15e5c1b0b44cbf97a49.jpg" /><p>Famed pop star Harry Styles is taking a page directly from major clothing brands in his attempt to shut down counterfeit online retailers selling Styles-styled merchandise.</p><p><a href="https://gizmodo.com/harry-styles-merchandise-counterfeit-1849986633">Read more...</a></p>

## Paizo President Jim Butler Reveals Plans for a Universal RPG License
 - [https://gizmodo.com/paizo-universal-rpg-license-interview-jim-butler-1849986745](https://gizmodo.com/paizo-universal-rpg-license-interview-jim-butler-1849986745)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 20:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9dJ3FWHg--/c_fit,fl_progressive,q_80,w_636/639c118d956afb53eaf281544e19ae75.png" /><p>While <a href="https://gizmodo.com/dnd-wizards-of-the-coast-ogl-1-1-open-gaming-license-1849950634">Wizards of the Coast</a> was <a href="https://gizmodo.com/dungeons-dragons-ogl-license-wizards-of-the-coast-wotc-1849985196">still assembling its party</a>, other leaders in the tabletop roleplaying games industry were studying the blade. As fans <a href="https://gizmodo.com/dungeons-dragons-ogl-announcement-wizards-of-the-coast-1849981365">waited for the Hasbro-owned company to respond</a> to the ongoing controversy over the <em>Dungeons &amp; Dragons</em> Open Game License, <a href="https://gizmodo.com/paizo-wizards-of-the-coast-dnd-open-rpg-ogl-1-1-1849982443">Paizo announced</a> it would be financially…</p><p><a href="https://gizmodo.com/paizo-universal-rpg-license-interview-jim-butler-1849986745">Read more...</a></p>

## Russia Wants to Trade 36 Hijacked Satellites for Soyuz Rocket
 - [https://gizmodo.com/russia-trade-oneweb-satellites-soyuz-rocket-1849985034](https://gizmodo.com/russia-trade-oneweb-satellites-soyuz-rocket-1849985034)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 20:05:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--t_6iGQ6A--/c_fit,fl_progressive,q_80,w_636/93b1ba96a3b5370379e049cb78fadce7.jpg" /><p>The Russian space agency may be willing to return 36 satellites it’s been keeping hostage in Kazakhstan in exchange for parts of its Soyuz rockets that are being held in French Guinea. </p><p><a href="https://gizmodo.com/russia-trade-oneweb-satellites-soyuz-rocket-1849985034">Read more...</a></p>

## These Pearl Earrings Are Secretly Wireless Earbuds
 - [https://gizmodo.com/nova-h1-pearl-earrings-are-secretly-wireless-earbuds-1849986662](https://gizmodo.com/nova-h1-pearl-earrings-are-secretly-wireless-earbuds-1849986662)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:55:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--r3tKNbkq--/c_fit,fl_progressive,q_80,w_636/2db4d2834d82272b3a3fd3181ebb9ae8.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--UeRaftYX--/c_fit,fl_progressive,q_80,w_636/2db4d2834d82272b3a3fd3181ebb9ae8.mp4" type="video/mp4" /></video><p>Wireless earbuds are no longer just a convenient way to listen to music and podcasts. As work continues to shift away from offices and we’re more dependent on virtual meetings and phone calls, many of us leave earbuds in all day long, but for those wanting something more fashionable and invisible than a white stick,…</p><p><a href="https://gizmodo.com/nova-h1-pearl-earrings-are-secretly-wireless-earbuds-1849986662">Read more...</a></p>

## Marvel's Moon Girl and Devil Dinosaur Trailer Unleashes the Dino-Mite Duo
 - [https://gizmodo.com/marvel-moon-girl-devil-dinosaur-trailer-disney-animated-1849986626](https://gizmodo.com/marvel-moon-girl-devil-dinosaur-trailer-disney-animated-1849986626)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--mEXdYvwy--/c_fit,fl_progressive,q_80,w_636/d0bfb1562c767237c58ad82d2b992898.png" /><p>Get ready to meet girl genius Lunella Lafayette and her partner in fighting crime—who just so happens to be a T-rex—in <a href="https://gizmodo.com/marvel-moon-girl-and-devil-dinosaur-cartoon-preview-1849943147"><em>Marvel’s Moon Girl and Devil Dinosaur</em></a>. </p><p><a href="https://gizmodo.com/marvel-moon-girl-devil-dinosaur-trailer-disney-animated-1849986626">Read more...</a></p>

## Linguistics Have Officially Dubbed '-Ussy' as Word of the Year
 - [https://gizmodo.com/linguistics-have-officially-dubbed-ussy-as-word-of-the-1849986295](https://gizmodo.com/linguistics-have-officially-dubbed-ussy-as-word-of-the-1849986295)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yg6XifcV--/c_fit,fl_progressive,q_80,w_636/5ceb764677b6c4dca81492411ff673ad.jpg" /><p>The evolution of language on the Internet is truly a fascinating one, and future linguists will be shaking their head at the American Dialect Society’s choice for <a href="https://gizmodo.com/goblin-mode-2022-word-of-the-year-oxford-1849853358">2022 word of the year</a>: “-ussy.”<br /></p><p><a href="https://gizmodo.com/linguistics-have-officially-dubbed-ussy-as-word-of-the-1849986295">Read more...</a></p>

## Clouded Leopard Escapes From Dallas Zoo Enclosure
 - [https://gizmodo.com/clouded-leopard-dallas-zoo-1849986355](https://gizmodo.com/clouded-leopard-dallas-zoo-1849986355)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--499d0Q27--/c_fit,fl_progressive,q_80,w_636/7f1d2dff0f48a3cf91ffa274323b36e5.jpg" /><p>A <a href="https://gizmodo.com/how-evolution-could-bring-back-the-sabercat-1441270558">clouded leopard</a> was reported missing from the Dallas Zoo on Friday as staff say they showed up to work to find the cage empty. The zoo put out an urgent message on <a href="https://gizmodo.com/twitter-hack-elon-musk-social-media-dark-web-1849979139">Twitter</a> saying the clouded leopard is “non-threatening” but the zoo has shut down while they search for the missing animal.</p><p><a href="https://gizmodo.com/clouded-leopard-dallas-zoo-1849986355">Read more...</a></p>

## SEC Charges Crypto Firms Genesis and Gemini With Selling Unregistered Securities
 - [https://gizmodo.com/crypto-genesis-gemini-sec-winklevoss-twins-1849985760](https://gizmodo.com/crypto-genesis-gemini-sec-winklevoss-twins-1849985760)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--MRuAySB9--/c_fit,fl_progressive,q_80,w_636/ec62cbc465edbfcaeb68ee94b312f5b2.png" /><p>The U.S. Securities and Exchange Commission charged Genesis Global Capital LLC and Gemini Trust Company LLC on Thursday for allegedly providing unregistered securities to investors through a program that touted a high interest on deposits.</p><p><a href="https://gizmodo.com/crypto-genesis-gemini-sec-winklevoss-twins-1849985760">Read more...</a></p>

## How to Watch SpaceX's Falcon Heavy Launch a Classified Military Satellite
 - [https://gizmodo.com/how-to-watch-spacex-falcon-heavy-space-force-launch-1849985465](https://gizmodo.com/how-to-watch-spacex-falcon-heavy-space-force-launch-1849985465)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 19:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5uygKpL2--/c_fit,fl_progressive,q_80,w_636/bd14c7bef4888777f94d8ce5cb3312e9.jpg" /><p>The U.S. military is hitching a ride aboard a SpaceX Falcon Heavy—the most powerful commercial rocket currently in operation. Here’s how you can watch the classified USSF-67 mission take to Florida’s twilight skies.<br /></p><p><a href="https://gizmodo.com/how-to-watch-spacex-falcon-heavy-space-force-launch-1849985465">Read more...</a></p>

## 13 Gruesomely Excellent Friday the 13th Kills
 - [https://gizmodo.com/13-gruesomely-excellent-friday-the-13th-kills-1847461581](https://gizmodo.com/13-gruesomely-excellent-friday-the-13th-kills-1847461581)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 18:50:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ypmCcNwb--/c_fit,fl_progressive,q_80,w_636/2a07ae867e7e4911164cb18c8d6e4104.jpg" /><p>Today is Friday the 13th, and horror fans know the best way to mark the occasion is by spending some quality time with <a href="https://gizmodo.com/jason-x-is-everything-that-makes-the-friday-the-13th-mo-1776319127">a certain machete-loving</a>, teenager-hating <a href="https://gizmodo.com/friday-the-13th-part-4-is-the-best-friday-the-13th-movi-1738386095">masked maniac</a> (and <a href="https://gizmodo.com/10-totally-monstrous-horror-movie-parents-1833378655">his dear mother</a>, of course). This list isn’t a movie ranking—<a href="https://gizmodo.com/all-the-friday-the-13th-movies-ranked-1838011683">we’ve already done that</a>—but rather a round-up of what we consider to be the…</p><p><a href="https://gizmodo.com/13-gruesomely-excellent-friday-the-13th-kills-1847461581">Read more...</a></p>

## Amazon Removes Some Nazi Paraphernalia From Site After Jewish Group Claims It Monetizes Hate
 - [https://gizmodo.com/amazon-amazon-prime-nazi-paraphernalia-1849984744](https://gizmodo.com/amazon-amazon-prime-nazi-paraphernalia-1849984744)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 18:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--4PHiRyOr--/c_fit,fl_progressive,q_80,w_636/cce8da278848a16f3d7c1c01acffebba.png" /><p>Once again, Amazon is being put on blast for racist and anti-Semitic products that third-party sellers are funneling through the retail giant’s platform.<br /></p><p><a href="https://gizmodo.com/amazon-amazon-prime-nazi-paraphernalia-1849984744">Read more...</a></p>

## Ghosts Will Return to Scare Up a Third Season
 - [https://gizmodo.com/cbs-ghosts-comedy-renewed-season-3-rose-mciver-1849985526](https://gizmodo.com/cbs-ghosts-comedy-renewed-season-3-rose-mciver-1849985526)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 18:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5tiTOEPM--/c_fit,fl_progressive,q_80,w_636/ca972b71cbd98a8c446ebbd11d7316f9.jpg" /><p>The current TV landscape is packed full of high-profile <a href="https://gizmodo.com/mayfair-witches-amc-review-interview-with-the-vampire-1849935459">witches</a>, <a href="https://gizmodo.com/what-we-do-in-the-shadows-fx-colin-robinson-interview-1849479948">vampires</a>, <a href="https://gizmodo.com/wolf-pack-sarah-michelle-gellar-paramount-werewolves-1849979875">werewolves</a>, and <a href="https://gizmodo.com/walking-dead-rick-michonne-spinoff-release-dates-daryl-1849970344">zombies</a>—and now there’s word that another supernatural series will continue to haunt the airwaves for another season. CBS’ hit comedy <em>Ghosts</em> has just been renewed for a third installment.</p><p><a href="https://gizmodo.com/cbs-ghosts-comedy-renewed-season-3-rose-mciver-1849985526">Read more...</a></p>

## The Best Friday the 13th Movies, Ranked
 - [https://gizmodo.com/all-the-friday-the-13th-movies-ranked-1838011683](https://gizmodo.com/all-the-friday-the-13th-movies-ranked-1838011683)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 17:46:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--oX-IeLQQ--/c_fit,fl_progressive,q_80,w_636/zgasaf0tpuxsmqfd92mj.png" /><p>Happy Friday the 13th! The Jason Voorhees faithful may end up waiting forever for that <a href="https://io9.gizmodo.com/the-friday-the-13th-reboot-has-been-delayed-yet-again-1792063602">long-promised 13th <em>Friday the 13th </em>movie</a>, and the new <a href="https://gizmodo.com/friday-the-13-prequel-crystal-lake-peacock-bryan-fuller-1849724455" target="_blank"><em>Friday the 13th </em>prequel series</a> coming to Peacock won’t hit until later this year. But the good news is that there are 12 other <em>Fridays</em> to watch in the meantime.</p><p><a href="https://gizmodo.com/all-the-friday-the-13th-movies-ranked-1838011683">Read more...</a></p>

## Willow Showrunner Jon Kasdan Talks Season 1 Spoilers and Reception—and His Season 2 Aspirations
 - [https://gizmodo.com/willow-season-2-questions-season-1-finale-spoilers-kasd-1849982846](https://gizmodo.com/willow-season-2-questions-season-1-finale-spoilers-kasd-1849982846)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 17:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--DreWDWz---/c_fit,fl_progressive,q_80,w_636/3fa2bf1d2fabb27ab73d97a75a1ac0e7.jpg" /><p>The <a href="https://gizmodo.com/willow-ep-8-recap-children-of-the-wyrm-season-finale-1849975195">first season of Disney+ series <em>Willow</em> is over</a>. If you watched, you no doubt have questions about some of the season’s final moments, and are wondering if it’s been renewed for season two yet (it has not). If you didn’t watch, maybe you’re now thinking, “They <a href="https://gizmodo.com/willow-show-warwick-davis-lucasfilm-elora-danon-disney-1849828699">made a <em>Willow</em> TV show</a>?” Both of these are completely…</p><p><a href="https://gizmodo.com/willow-season-2-questions-season-1-finale-spoilers-kasd-1849982846">Read more...</a></p>

## This Violent Night Deleted Scene Is an Early Reminder to Stay Off the Naughty List
 - [https://gizmodo.com/violent-night-deleted-scene-david-harbour-santa-claus-1849980495](https://gizmodo.com/violent-night-deleted-scene-david-harbour-santa-claus-1849980495)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 17:10:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--NmVJAn7l--/c_fit,fl_progressive,q_80,w_636/a3d0a861438a6084bcb74ed442f684a1.jpg" /><p>You may have just finished packing away all your holiday decorations, but here’s a good reason to inject a little bonus <a href="https://gizmodo.com/christmas-bloody-christmas-shudder-horror-movie-review-1849864955">Christmas spirit</a> into your January: <em>Violent Night—</em><a href="https://gizmodo.com/david-harbour-violent-night-interview-santa-claus-xmas-1849813819">David Harbour’s excellent</a> <a href="https://gizmodo.com/violent-night-trailer-david-harbour-santa-claus-die-har-1849619165">Santa-goes-<em>Die Hard</em> tale</a>—is arriving soon on digital, Blu-ray, and DVD. io9 has an exclusive deleted scene from the…</p><p><a href="https://gizmodo.com/violent-night-deleted-scene-david-harbour-santa-claus-1849980495">Read more...</a></p>

## Climate Gentrification Is Coming to Hurricane-Wrecked Florida
 - [https://gizmodo.com/climate-gentrification-is-coming-to-hurricane-wrecked-f-1849981170](https://gizmodo.com/climate-gentrification-is-coming-to-hurricane-wrecked-f-1849981170)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 16:57:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--kkfj5OLn--/c_fit,fl_progressive,q_80,w_636/d09672efe24c2460d522edaf37345f3a.jpg" /><p>You might assume that home prices would decline in an area recently wrecked by a hurricane, but a new study finds the opposite is true, and post-storm price hikes could be a major driver of what’s known as climate gentrification. </p><p><a href="https://gizmodo.com/climate-gentrification-is-coming-to-hurricane-wrecked-f-1849981170">Read more...</a></p>

## NASA's Moon-Bound Lunar Flashlight Is Experiencing Thruster Issues
 - [https://gizmodo.com/nasa-lunar-flashlight-thruster-issues-1849984875](https://gizmodo.com/nasa-lunar-flashlight-thruster-issues-1849984875)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 16:50:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QB4SvvmE--/c_fit,fl_progressive,q_80,w_636/26680e826e852998d969a64844bbd6f0.jpg" /><p>NASA’s Lunar Flashlight is on a mission to hunt for water ice on the Moon’s surface, but the mission appears to be in trouble as three of the craft’s four thrusters are “underperforming,” according to NASA.</p><p><a href="https://gizmodo.com/nasa-lunar-flashlight-thruster-issues-1849984875">Read more...</a></p>

## Wizards of the Coast Breaks Its Silence on Dungeons and Dragons' Open Game License
 - [https://gizmodo.com/dungeons-dragons-ogl-license-wizards-of-the-coast-wotc-1849985196](https://gizmodo.com/dungeons-dragons-ogl-license-wizards-of-the-coast-wotc-1849985196)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 16:23:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--B2ECs2ZH--/c_fit,fl_progressive,q_80,w_636/1b72f096cd32812fc7e10bf659ea970c.png" /><p>Wizards of the Coast, the Hasbro subsidiary that publishes <a href="https://gizmodo.com/dungeons-and-dragons-tv-show-paramount-plus-hasbro-1849969764"><em>Dungeons &amp; Dragons</em></a>, <a href="https://www.dndbeyond.com/posts/1423-an-update-on-the-open-game-license-ogl" rel="noopener noreferrer" target="_blank">revealed details of its new Open Game License</a> on Friday and attempted to answer questions about the future of the D&amp;D  community that were raised after io9 <a href="https://gizmodo.com/dnd-wizards-of-the-coast-ogl-1-1-open-gaming-license-1849950634">broke the news</a> about the contents of a draft of the document last week.<br /></p><p><a href="https://gizmodo.com/dungeons-dragons-ogl-license-wizards-of-the-coast-wotc-1849985196">Read more...</a></p>

## Meta Sues 'Predictive Policing' Firm for Using Fake Accounts to Scrape More Than 600,000 Facebook Profiles
 - [https://gizmodo.com/facebook-voyager-labs-predictive-policing-meta-1849985035](https://gizmodo.com/facebook-voyager-labs-predictive-policing-meta-1849985035)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 16:16:08+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wrMaYHq5--/c_fit,fl_progressive,q_80,w_636/c6877aa823c61976c53524a731ea9e10.jpg" /><p>Meta, the company previously known as Facebook, may not have the <em>best </em><a href="https://gizmodo.com/ftc-approves-5-billion-settlement-against-facebook-ove-1836321977">track record</a> when it comes to preserving its users’ privacy, but it nonetheless wants to make damn sure other companies aren’t spying on its community without its approval. </p><p><a href="https://gizmodo.com/facebook-voyager-labs-predictive-policing-meta-1849985035">Read more...</a></p>

## Tim Cook Takes a 40% Pay Cut After Apple Shareholders Grumbled
 - [https://gizmodo.com/apples-tim-cook-iphone-ipad-pay-cut-shareholders-1849984551](https://gizmodo.com/apples-tim-cook-iphone-ipad-pay-cut-shareholders-1849984551)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_l3N9PQw--/c_fit,fl_progressive,q_80,w_636/e9c017bd66cbaf03193c145bbb0a497c.png" /><p>Even CEOs aren’t immune to tough economic times and discontented grumbling. Just ask Apple’s Tim Cook, who just agreed to give himself a 40% pay cut, given the fruit stand’s lackluster performance in 2022 and shareholder pushback. </p><p><a href="https://gizmodo.com/apples-tim-cook-iphone-ipad-pay-cut-shareholders-1849984551">Read more...</a></p>

## The Offering Reminds You to Not to Feed Any Hungry Demons
 - [https://gizmodo.com/the-offering-jewish-horror-demons-brooklyn-funeral-home-1849982419](https://gizmodo.com/the-offering-jewish-horror-demons-brooklyn-funeral-home-1849982419)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--0aeEMofr--/c_fit,fl_progressive,q_80,w_636/d396627f9b46c01b719d8f9c75c13e35.png" /><p><a href="https://gizmodo.com/prime-video-horror-review-my-best-friends-exorcism-1849531135">Exorcisms</a> are a favorite topic in horror movies for obvious reasons; succinctly, demons are <em>scary</em>. But while we’ve seen a lot of films tackle possession and evil spirits through <a href="https://gizmodo.com/the-exorcist-documentary-leap-of-faith-takes-you-inside-1845336739">a Catholic lens</a>, it’s rarer to see <a href="https://gizmodo.com/indonesian-horror-on-shudder-review-satans-slaves-2-1849716117">other religions brought into the story</a>. That’s a big way that <em>The Offering</em>, about a Hasidic family facing…</p><p><a href="https://gizmodo.com/the-offering-jewish-horror-demons-brooklyn-funeral-home-1849982419">Read more...</a></p>

## Tweetbot, Twitterrific, and Other Third-Party Twitter Apps Are Busted
 - [https://gizmodo.com/tweetbot-twitterrific-twitter-down-apps-elon-musk-1849984610](https://gizmodo.com/tweetbot-twitterrific-twitter-down-apps-elon-musk-1849984610)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--y9IFVI0z--/c_fit,fl_progressive,q_80,w_636/8fd140d246fa48814a32c1dc56375f27.jpg" /><p>A long list of third-party Twitter clients, including Tweetbot, Twitterific, Echofon, and Fenix aren’t working. The apps, which all rely on access to Twitter’s application program interface (API) to get data, have been facing issues since Thursday night, according to multiple online posts from app developers, and as <a href="https://www.theverge.com/2023/1/13/23553161/third-party-twitter-clients-apps-outage-twitterific-tweetbot" rel="noopener noreferrer" target="_blank">…</a></p><p><a href="https://gizmodo.com/tweetbot-twitterrific-twitter-down-apps-elon-musk-1849984610">Read more...</a></p>

## The Dumbest Reactions to the Non-Existent Gas Stove Ban
 - [https://gizmodo.com/gas-stove-ban-reactions-twitter-desantis-1849981258](https://gizmodo.com/gas-stove-ban-reactions-twitter-desantis-1849981258)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:43:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--FhrzBCJa--/c_fit,fl_progressive,q_80,w_636/07734dd0f5c44c3a28e63de39e7d65d4.png" /><p>A swift turnaround from the U.S. Consumer Product Safety Commission gave the media whiplash earlier this week. On Monday, a commissioner from the watchdog agency, Richard Trumka Jr., indicated CPSC was <a href="https://gizmodo.com/us-considers-ban-gas-stoves-health-risks-1849966453">considering new restrictions</a> on gas stoves over mounting health concerns.<br /></p><p><a href="https://gizmodo.com/gas-stove-ban-reactions-twitter-desantis-1849981258">Read more...</a></p>

## U.S. Has Seen an Increase in UFO Sightings, New Government Report Says
 - [https://gizmodo.com/ufo-unidentified-aerial-phenomenon-uap-1849984430](https://gizmodo.com/ufo-unidentified-aerial-phenomenon-uap-1849984430)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VNTFdJyh--/c_fit,fl_progressive,q_80,w_636/8f60243fef803a82562d8a4dc614af24.jpg" /><p>It’s a bird! It’s a plane! No, it’s an unidentified aerial phenomenon. <a href="https://www.dni.gov/index.php/newsroom/reports-publications/reports-publications-2023/item/2354-2022-annual-report-on-unidentified-aerial-phenomena" rel="noopener noreferrer" target="_blank">A newly published report</a> from the Office of the Director of National Intelligence says that it’s received a total of 510 <a href="https://gizmodo.com/ufo-uap-unidentified-objects-aliens-hearing-1848936948">UFO reports</a> over the last 17 years, and the majority of those reports, more than 350, have been filed since March 2021.<br /></p><p><a href="https://gizmodo.com/ufo-unidentified-aerial-phenomenon-uap-1849984430">Read more...</a></p>

## A Crouching Tiger, Hidden Dragon TV Series Leaps Into Existence
 - [https://gizmodo.com/crouching-tiger-hidden-dragon-tv-flash-walking-dead-1849979806](https://gizmodo.com/crouching-tiger-hidden-dragon-tv-flash-walking-dead-1849979806)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 15:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--E9CJlNEv--/c_fit,fl_progressive,q_80,w_636/909f554b8eb547ff1045d7d34bff6670.png" /><p>Get a glimpse of the timeline shenanigans coming to <em>The Flas</em>h’s final season. There’s a bevy of new production photos from <em>The Walking Dead: Dead City. </em>The composer of the <em>Joker</em> sequel has begun, uh, composing, John Carpenter denies a rumor, and much more await in today’s Morning Spoilers.<br /></p><p><a href="https://gizmodo.com/crouching-tiger-hidden-dragon-tv-flash-walking-dead-1849979806">Read more...</a></p>

## CES 2023 Round Up Part 2
 - [https://gizmodo.com/ces-2023-round-up-part-2-1849981379](https://gizmodo.com/ces-2023-round-up-part-2-1849981379)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 14:50:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KSflXisL--/c_fit,fl_progressive,q_80,w_636/734cc08a351efc3bfc9b99b6ef6e5266.jpg" /><p><a href="https://gizmodo.com/ces-2023-round-up-part-2-1849981379">Read more...</a></p>

## Automakers Have Ground Massachusetts Right-to-Repair Law to a Halt
 - [https://gizmodo.com/automakers-have-ground-massachusetts-right-to-repair-la-1849984499](https://gizmodo.com/automakers-have-ground-massachusetts-right-to-repair-la-1849984499)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 14:43:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--xrSoGRi7--/c_fit,fl_progressive,q_80,w_636/038a2e5e36d10efd340cec2c974bbaee.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/automakers-have-ground-massachusetts-right-to-repair-la-1849984499">Read more...</a></p>

## Sennheiser’s TV Clear Set Will Take Your TV Watching Experience to a Whole New, Expensive Level
 - [https://gizmodo.com/sennheiser-tv-clear-set-wireless-earbuds-speech-clarity-1849981539](https://gizmodo.com/sennheiser-tv-clear-set-wireless-earbuds-speech-clarity-1849981539)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 14:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--tvcP9UbF--/c_fit,fl_progressive,q_80,w_636/7976e67a2dbd12cbf643f89d02f4a5c9.jpg" /><p>Sennheiser recently released the <a href="https://gizmodo.com/sennheiser-earbud-bluetooth-wireless-speech-enhancement-1849001255">TV Clear Set</a>, which is essentially a pair of earbuds that wirelessly connect to your TV for a custom, private listening experience. While the concept is fairly simple, not too dissimilar from using <a href="https://gizmodo.com/apple-airpods-pro-2-review-best-iphone-wireless-earbuds-1849541242">AirPods</a> with an Apple TV, their $400 price tag might leave you a little confused.…</p><p><a href="https://gizmodo.com/sennheiser-tv-clear-set-wireless-earbuds-speech-clarity-1849981539">Read more...</a></p>

## The Asus ZenBook 17 Fold OLED is Promising, But Not Ready
 - [https://gizmodo.com/asus-zenbook-17-fold-oled-laptop-review-foldable-tablet-1849981924](https://gizmodo.com/asus-zenbook-17-fold-oled-laptop-review-foldable-tablet-1849981924)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 13:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--o_uw3Y6Z--/c_fit,fl_progressive,q_80,w_636/1d3bfb2b1275bef4013fe6f59fa9fead.jpg" /><p>I would describe the Asus Zenbook 17 Fold as the ideal ambassador for the folding laptop. It’s far from perfect, nor does its Taiwanese PC maker expect to sell it in droves, given its astronomical $3500 price tag. But after a month with it, the Zenbook 17 has convinced me on what many only a couple of years ago…</p><p><a href="https://gizmodo.com/asus-zenbook-17-fold-oled-laptop-review-foldable-tablet-1849981924">Read more...</a></p>

## Your First 2023 Resolution Should Be to Fix Your Work From Home Setup
 - [https://gizmodo.com/best-work-from-home-accessories-desk-monitor-keyboard-1849980633](https://gizmodo.com/best-work-from-home-accessories-desk-monitor-keyboard-1849980633)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 13:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--b9t8wrqJ--/c_fit,fl_progressive,q_80,w_636/436be4cea9b63627ba2bc784602c9a87.jpg" /><p>With 2023 upon us, you have to ask yourself, should you spend another year hunched over your dining room table while working from home? The correct answer is no, no you shouldn’t. Instead of committing to sudden life-changing resolutions, taking smaller steps to make your everyday spaces just a bit more comfortable…</p><p><a href="https://gizmodo.com/best-work-from-home-accessories-desk-monitor-keyboard-1849980633">Read more...</a></p>

## An Interview With the Guy Who Has All Your Data
 - [https://gizmodo.com/acxiom-ceo-chad-engelgau-data-broker-interview-privacy-1849977330](https://gizmodo.com/acxiom-ceo-chad-engelgau-data-broker-interview-privacy-1849977330)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 12:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--mDwDH4uA--/c_fit,fl_progressive,q_80,w_636/467d700a56ac7dfad7e6c137c0019a54.png" /><p>Chad Engelgau is the CEO of Acxiom, a data broker that operates one of the world’s biggest repositories of consumer information. The company claims to have granular details on more than 2.5 billion people across 62 different countries. The chances that Acxiom knows a whole lot about you, reader, are good.</p><p><a href="https://gizmodo.com/acxiom-ceo-chad-engelgau-data-broker-interview-privacy-1849977330">Read more...</a></p>

## Everything Everywhere All at Once Is Letterboxd's Highest-Rated Film of 2022
 - [https://gizmodo.com/everything-everywhere-all-at-once-wins-2022-letterboxd-1849982781](https://gizmodo.com/everything-everywhere-all-at-once-wins-2022-letterboxd-1849982781)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 01:10:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Dnd5-7kl--/c_fit,fl_progressive,q_80,w_636/f43873401050f7fad1d74bda9ac7846f.png" /><p>Letterboxd, the review social media aggregator site used by film enthusiasts, celebrated <a href="https://gizmodo.com/on-being-trans-and-watching-everything-everywhere-all-a-1848714824"><em>Everything Everywhere All at Once</em></a> becoming the platform’s <a href="https://gizmodo.com/best-movies-2022-horror-sci-fi-fantasy-superhero-genre-1849935315">highest rated film</a>, and the film’s writer-directors joined the party.</p><p><a href="https://gizmodo.com/everything-everywhere-all-at-once-wins-2022-letterboxd-1849982781">Read more...</a></p>

## My Dad the Bounty Hunter Boasts the Coolest 'Bring Your Kids to Work Day' Ever
 - [https://gizmodo.com/netflix-animation-sci-fi-kids-my-dad-the-bounty-hunter-1849982784](https://gizmodo.com/netflix-animation-sci-fi-kids-my-dad-the-bounty-hunter-1849982784)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-13 00:30:20+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ARo0_Mad--/c_fit,fl_progressive,q_80,w_636/8ac2d0b13aaafe953818f3d1ea697e08.jpg" /><p>Two kids—one voiced by <a href="https://gizmodo.com/report-priah-ferguson-is-getting-bumped-up-to-series-r-1841855190"><em>Stranger Things</em> breakout</a> <a href="https://gizmodo.com/a-stranger-things-fan-favorite-stars-in-this-dreamy-sho-1821260656">Priah Ferguson</a>—have always believed their dad was just an average dude. So it comes as a huge shock when they learn he’s actually, well... <em>My Dad the Bounty Hunter</em>. In other words, he’s an intergalactic badass, and <a href="https://gizmodo.com/killjoys-really-is-a-most-excellent-space-adventure-sho-1712643138">space adventures</a> galore await the lucky siblings in this…</p><p><a href="https://gizmodo.com/netflix-animation-sci-fi-kids-my-dad-the-bounty-hunter-1849982784">Read more...</a></p>
