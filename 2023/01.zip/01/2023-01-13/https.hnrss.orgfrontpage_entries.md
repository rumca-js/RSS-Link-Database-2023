# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## EPA Proposes to Strengthen Air Quality Standards
 - [https://www.epa.gov/newsreleases/epa-proposes-strengthen-air-quality-standards-protect-public-harmful-effects-soot](https://www.epa.gov/newsreleases/epa-proposes-strengthen-air-quality-standards-protect-public-harmful-effects-soot)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 23:31:02+00:00
 - user: None

<p>Article URL: <a href="https://www.epa.gov/newsreleases/epa-proposes-strengthen-air-quality-standards-protect-public-harmful-effects-soot">https://www.epa.gov/newsreleases/epa-proposes-strengthen-air-quality-standards-protect-public-harmful-effects-soot</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34375368">https://news.ycombinator.com/item?id=34375368</a></p>
<p>Points: 33</p>
<p># Comments: 5</p>

## How will the remaining uplift affect the Scandinavian landscape?
 - [https://geoforskning.no/hvordan-vil-gjenstaende-landheving-pavirke-landskapet-eng/](https://geoforskning.no/hvordan-vil-gjenstaende-landheving-pavirke-landskapet-eng/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 23:26:32+00:00
 - user: None

<p>Article URL: <a href="https://geoforskning.no/hvordan-vil-gjenstaende-landheving-pavirke-landskapet-eng/">https://geoforskning.no/hvordan-vil-gjenstaende-landheving-pavirke-landskapet-eng/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34375325">https://news.ycombinator.com/item?id=34375325</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Emacs Is Not Enough
 - [https://project-mage.org/emacs-is-not-enough](https://project-mage.org/emacs-is-not-enough)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 23:02:49+00:00
 - user: None

<p>Article URL: <a href="https://project-mage.org/emacs-is-not-enough">https://project-mage.org/emacs-is-not-enough</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34375137">https://news.ycombinator.com/item?id=34375137</a></p>
<p>Points: 42</p>
<p># Comments: 8</p>

## Programming Interviews Turn Normal People into A-Holes
 - [https://new.pythonforengineers.com/blog/programming-interviews-turn-normal-people-into-a-holes/](https://new.pythonforengineers.com/blog/programming-interviews-turn-normal-people-into-a-holes/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 22:33:43+00:00
 - user: None

<p>Article URL: <a href="https://new.pythonforengineers.com/blog/programming-interviews-turn-normal-people-into-a-holes/">https://new.pythonforengineers.com/blog/programming-interviews-turn-normal-people-into-a-holes/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34374847">https://news.ycombinator.com/item?id=34374847</a></p>
<p>Points: 26</p>
<p># Comments: 27</p>

## GitHub – pi-hole/pi-hole: A black hole for Internet advertisements
 - [https://github.com/pi-hole/pi-hole](https://github.com/pi-hole/pi-hole)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 22:22:31+00:00
 - user: rumpel
 - tags: raspberry,digital bunker,smarthome

<p>Article URL: <a href="https://github.com/pi-hole/pi-hole">https://github.com/pi-hole/pi-hole</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34374725">https://news.ycombinator.com/item?id=34374725</a></p>
<p>Points: 38</p>
<p># Comments: 12</p>

## Sickcodes/Docker-OS X: Run macOS VM in a Docker
 - [https://github.com/sickcodes/Docker-OSX](https://github.com/sickcodes/Docker-OSX)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 22:20:27+00:00
 - user: None

<p>Article URL: <a href="https://github.com/sickcodes/Docker-OSX">https://github.com/sickcodes/Docker-OSX</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34374710">https://news.ycombinator.com/item?id=34374710</a></p>
<p>Points: 31</p>
<p># Comments: 7</p>

## Cuba and the Geopolitics of Submarine Cables
 - [https://www.kentik.com/blog/cuba-and-the-geopolitics-of-submarine-cables/](https://www.kentik.com/blog/cuba-and-the-geopolitics-of-submarine-cables/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 21:24:49+00:00
 - user: None

<p>Article URL: <a href="https://www.kentik.com/blog/cuba-and-the-geopolitics-of-submarine-cables/">https://www.kentik.com/blog/cuba-and-the-geopolitics-of-submarine-cables/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34374090">https://news.ycombinator.com/item?id=34374090</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Shapecatcher: Draw the Unicode character you want
 - [https://shapecatcher.com/](https://shapecatcher.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 21:24:11+00:00
 - user: None

<p>Article URL: <a href="https://shapecatcher.com/">https://shapecatcher.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34374083">https://news.ycombinator.com/item?id=34374083</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## ExifTool – Read, Write and Edit Meta Information
 - [https://exiftool.org/](https://exiftool.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 21:11:42+00:00
 - user: None

<p>Article URL: <a href="https://exiftool.org/">https://exiftool.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373928">https://news.ycombinator.com/item?id=34373928</a></p>
<p>Points: 31</p>
<p># Comments: 9</p>

## ChatGPT doesn't ackowledge being wrong?
 - [https://news.ycombinator.com/item?id=34373911](https://news.ycombinator.com/item?id=34373911)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 21:10:16+00:00
 - user: None

<p>So far in all the cases I have seen of ChatGPT providing a wrong answer, I have never seen it actually acknowledge that the answer it provides might be innacurate. Am I the only one worried by this?<p>For all the talk about "AI ethics" there is it seems strinking to me that the current state of the art model will opt for providing a convincing argument for why it's wrong answer is correct, rather than say that the answer it provides might be innacurate. (Funnily enough this is what humans tend to do aswell.)
Being that these models often tend to be trained on data found on the internet, could this be a sign of the bias we tend to have when writing on social platforms and the internet in general? (As in justifying our answers instead of trying to get to the correct one)<p>So the questions are:
1. What are the consequences of this in the development of LLMs and in their application to various fields?<p>2. How would one implement this capability of recognizing where the model might be innacurate?<p>3. Is 2. really that much more complicated than what is currently being done? If not, then why hasn't it been done yet?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373911">https://news.ycombinator.com/item?id=34373911</a></p>
<p>Points: 8</p>
<p># Comments: 7</p>

## Woman ordered to repay $2k after her employer used software to track her time
 - [https://www.npr.org/2023/01/13/1148985075/time-tracking-software-canadian-woman-reach-cpa-court](https://www.npr.org/2023/01/13/1148985075/time-tracking-software-canadian-woman-reach-cpa-court)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 20:52:35+00:00
 - user: None

<p>Article URL: <a href="https://www.npr.org/2023/01/13/1148985075/time-tracking-software-canadian-woman-reach-cpa-court">https://www.npr.org/2023/01/13/1148985075/time-tracking-software-canadian-woman-reach-cpa-court</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373725">https://news.ycombinator.com/item?id=34373725</a></p>
<p>Points: 37</p>
<p># Comments: 21</p>

## What the hell is Forth? (2019)
 - [https://blog.information-superhighway.net/what-the-hell-is-forth](https://blog.information-superhighway.net/what-the-hell-is-forth)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 20:15:59+00:00
 - user: None

<p>Article URL: <a href="https://blog.information-superhighway.net/what-the-hell-is-forth">https://blog.information-superhighway.net/what-the-hell-is-forth</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373279">https://news.ycombinator.com/item?id=34373279</a></p>
<p>Points: 18</p>
<p># Comments: 2</p>

## Strava Raises Prices but Can’t Tell You How Much It Costs Anymore
 - [https://www.dcrainmaker.com/2023/01/strava-raises-prices-doubling.html](https://www.dcrainmaker.com/2023/01/strava-raises-prices-doubling.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 20:09:37+00:00
 - user: None

<p>Article URL: <a href="https://www.dcrainmaker.com/2023/01/strava-raises-prices-doubling.html">https://www.dcrainmaker.com/2023/01/strava-raises-prices-doubling.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373206">https://news.ycombinator.com/item?id=34373206</a></p>
<p>Points: 69</p>
<p># Comments: 35</p>

## CoinDesk, Inc. Files Motion to Unseal Names of SBF's Additional Bail Sureties [pdf]
 - [https://ia801508.us.archive.org/25/items/gov.uscourts.nysd.590940/gov.uscourts.nysd.590940.43.0.pdf](https://ia801508.us.archive.org/25/items/gov.uscourts.nysd.590940/gov.uscourts.nysd.590940.43.0.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 19:58:17+00:00
 - user: None

<p>Article URL: <a href="https://ia801508.us.archive.org/25/items/gov.uscourts.nysd.590940/gov.uscourts.nysd.590940.43.0.pdf">https://ia801508.us.archive.org/25/items/gov.uscourts.nysd.590940/gov.uscourts.nysd.590940.43.0.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34373068">https://news.ycombinator.com/item?id=34373068</a></p>
<p>Points: 89</p>
<p># Comments: 25</p>

## Why older fathers pass on more genetic mutations to their offspring
 - [https://www.rockefeller.edu/news/33436-why-older-fathers-pass-on-more-genetic-mutations-to-their-offspring/](https://www.rockefeller.edu/news/33436-why-older-fathers-pass-on-more-genetic-mutations-to-their-offspring/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 19:23:00+00:00
 - user: None

<p>Article URL: <a href="https://www.rockefeller.edu/news/33436-why-older-fathers-pass-on-more-genetic-mutations-to-their-offspring/">https://www.rockefeller.edu/news/33436-why-older-fathers-pass-on-more-genetic-mutations-to-their-offspring/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34372587">https://news.ycombinator.com/item?id=34372587</a></p>
<p>Points: 23</p>
<p># Comments: 18</p>

## Sam Bankman-Fried's secret 'backdoor' discovered, FTX lawyer says
 - [https://www.businessinsider.com/sam-bankman-fried-secret-backdoor-worth-65-billion-court-hears-2023-1](https://www.businessinsider.com/sam-bankman-fried-secret-backdoor-worth-65-billion-court-hears-2023-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 19:16:36+00:00
 - user: None

<p>Article URL: <a href="https://www.businessinsider.com/sam-bankman-fried-secret-backdoor-worth-65-billion-court-hears-2023-1">https://www.businessinsider.com/sam-bankman-fried-secret-backdoor-worth-65-billion-court-hears-2023-1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34372508">https://news.ycombinator.com/item?id=34372508</a></p>
<p>Points: 36</p>
<p># Comments: 20</p>

## Docker 2.0 went from $11M to $135M in 2 years
 - [https://sacra.com/p/docker-plg-pivot/](https://sacra.com/p/docker-plg-pivot/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 18:49:42+00:00
 - user: None

<p>Article URL: <a href="https://sacra.com/p/docker-plg-pivot/">https://sacra.com/p/docker-plg-pivot/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34372140">https://news.ycombinator.com/item?id=34372140</a></p>
<p>Points: 34</p>
<p># Comments: 13</p>

## Setting the Bozo Bit on Apple
 - [https://blog.metaobject.com/2023/01/setting-bozo-bit-on-apple.html](https://blog.metaobject.com/2023/01/setting-bozo-bit-on-apple.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 18:02:44+00:00
 - user: None

<p>Article URL: <a href="https://blog.metaobject.com/2023/01/setting-bozo-bit-on-apple.html">https://blog.metaobject.com/2023/01/setting-bozo-bit-on-apple.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34371438">https://news.ycombinator.com/item?id=34371438</a></p>
<p>Points: 10</p>
<p># Comments: 7</p>

## You Don’t Know How Bad the Pizza Box Is
 - [https://www.theatlantic.com/technology/archive/2023/01/pizza-delivery-box-design-soggy/672712/](https://www.theatlantic.com/technology/archive/2023/01/pizza-delivery-box-design-soggy/672712/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 17:46:04+00:00
 - user: None

<p>Article URL: <a href="https://www.theatlantic.com/technology/archive/2023/01/pizza-delivery-box-design-soggy/672712/">https://www.theatlantic.com/technology/archive/2023/01/pizza-delivery-box-design-soggy/672712/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34371156">https://news.ycombinator.com/item?id=34371156</a></p>
<p>Points: 32</p>
<p># Comments: 31</p>

## Learning eBPF Exploitation
 - [https://stdnoerr.github.io/writeup/2022/08/21/eBPF-exploitation-(ft.-D-3CTF-d3bpf).html](https://stdnoerr.github.io/writeup/2022/08/21/eBPF-exploitation-(ft.-D-3CTF-d3bpf).html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 17:44:12+00:00
 - user: None

<p>Article URL: <a href="https://stdnoerr.github.io/writeup/2022/08/21/eBPF-exploitation-(ft.-D-3CTF-d3bpf).html">https://stdnoerr.github.io/writeup/2022/08/21/eBPF-exploitation-(ft.-D-3CTF-d3bpf).html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34371123">https://news.ycombinator.com/item?id=34371123</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## Alpine Linux in the Browser
 - [https://bellard.org/jslinux/vm.html?url=alpine-x86.cfg&mem=192](https://bellard.org/jslinux/vm.html?url=alpine-x86.cfg&mem=192)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 17:41:28+00:00
 - user: None

<p>Article URL: <a href="https://bellard.org/jslinux/vm.html?url=alpine-x86.cfg&amp;mem=192">https://bellard.org/jslinux/vm.html?url=alpine-x86.cfg&amp;mem=192</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34371073">https://news.ycombinator.com/item?id=34371073</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## Precedent – Building Blocks for Next.js
 - [https://precedent.vercel.app/](https://precedent.vercel.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 17:11:19+00:00
 - user: None

<p>Article URL: <a href="https://precedent.vercel.app/">https://precedent.vercel.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34370660">https://news.ycombinator.com/item?id=34370660</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## Analog Chess
 - [https://github.com/ehulinsky/AnalogChess/blob/main/README.md](https://github.com/ehulinsky/AnalogChess/blob/main/README.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 16:55:21+00:00
 - user: None

<p>Article URL: <a href="https://github.com/ehulinsky/AnalogChess/blob/main/README.md">https://github.com/ehulinsky/AnalogChess/blob/main/README.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34370440">https://news.ycombinator.com/item?id=34370440</a></p>
<p>Points: 123</p>
<p># Comments: 25</p>

## An Update on the Open Game License (OGL)
 - [https://www.dndbeyond.com/posts/1423-an-update-on-the-open-game-license-ogl](https://www.dndbeyond.com/posts/1423-an-update-on-the-open-game-license-ogl)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 16:48:03+00:00
 - user: None

<p>Article URL: <a href="https://www.dndbeyond.com/posts/1423-an-update-on-the-open-game-license-ogl">https://www.dndbeyond.com/posts/1423-an-update-on-the-open-game-license-ogl</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34370340">https://news.ycombinator.com/item?id=34370340</a></p>
<p>Points: 26</p>
<p># Comments: 19</p>

## We could stumble into AI catastrophe
 - [https://www.cold-takes.com/how-we-could-stumble-into-ai-catastrophe/](https://www.cold-takes.com/how-we-could-stumble-into-ai-catastrophe/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 16:45:56+00:00
 - user: None

<p>Article URL: <a href="https://www.cold-takes.com/how-we-could-stumble-into-ai-catastrophe/">https://www.cold-takes.com/how-we-could-stumble-into-ai-catastrophe/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34370310">https://news.ycombinator.com/item?id=34370310</a></p>
<p>Points: 22</p>
<p># Comments: 18</p>

## Strava hikes monthly subscription price by more than 25 per cent
 - [https://www.bikeradar.com/news/strava-hikes-monthly-subscription-cost-by-more-than-25-per-cent/](https://www.bikeradar.com/news/strava-hikes-monthly-subscription-cost-by-more-than-25-per-cent/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 16:38:36+00:00
 - user: None

<p>Article URL: <a href="https://www.bikeradar.com/news/strava-hikes-monthly-subscription-cost-by-more-than-25-per-cent/">https://www.bikeradar.com/news/strava-hikes-monthly-subscription-cost-by-more-than-25-per-cent/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34370192">https://news.ycombinator.com/item?id=34370192</a></p>
<p>Points: 26</p>
<p># Comments: 34</p>

## Launch HN: MagnaPlay (YC W23) – Indie gaming subscription service for PC
 - [https://news.ycombinator.com/item?id=34369562](https://news.ycombinator.com/item?id=34369562)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 15:58:52+00:00
 - user: None

<p>Hey everyone, I’m Pedro, and together with my friend Paulo I co-founded MagnaPlay (<a href="https://magnaplay.tech">https://magnaplay.tech</a>). Basically, we’re a “Spotify”, but for games made by independent creators on PC.<p>Paulo and I have been indie gamers for the past decade. Both of us have insanely long back catalogs of games we’ve always wanted to try, but couldn’t. When we were stuck at home during covid, we were frustrated and decided to set out to solve this problem. Naturally, this decision was made during a game of Call of Duty: Warzone.<p>For consumers, MagnaPlay eliminates the paywall when it comes to buying a new game. Today, the indie market is incredibly saturated and prices are increasing. A subscription service, like Spotify, can make indie gaming more affordable and allow players to try out more content.<p>For developers, we solve the problem of lower consumer lifetime values for indie games.  Most indie games sell for around $10 and lose 50% of that to tax and store commissions, so the average player only nets them around $5 LTV. By introducing a revenue model which focuses on the distribution of player subscriptions, we’re able to pay developers a recurring revenue stream, as long as people are playing their game. This way, indie games can achieve profitability with a smaller player base, which is crucial as these developers tend to have incredibly small marketing budgets.<p>MagnaPlay subscriptions cost $8/month. We divide that up and distribute it to developers based on a series of data such as time played, play sessions and number of downloads. We designed this with the idea of helping indies achieve profitability with a smaller player base, crucial when competition is ever-increasing.<p>This isn’t a new idea, but we offer a few twists. Namely: a) we only work with indie games, which makes the unit economics work; b) we don’t do streaming—the business model doesn’t really work and it’s not as cool as it sounds; and c) we’re trying out all our funky gamer ideas: letting players vote for titles, let players review games on a review feed and even letting players choose who gets part of their subscription!<p>By far our biggest difficulty is overcoming the chicken-and-egg problem of platform businesses: we need games to get users, and we need users to get games. We have a few high quality games already, but not enough yet to draw major interest. Things have been especially hard on the supply side, because most of the time we’re competing with massive companies such as Microsoft, which really bankroll their service “Game Pass”. We’re going to have to be clever and determined to overcome this problem and it may need some real hacking…accepting any suggestions!<p>In the meantime, if you think MagnaPlay is a good idea and would like it to exist in your world, like we do, we’d love you to consider taking a leap of faith with us and getting in early. We promise to listen closely to your opinions about what games to add and how to build this out going forward!<p>The other perennial question, of course, is piracy. Since we don’t do streaming, all games are installed on your computer, but since we’re a subscription service, we have to validate your subscription—and however we do that, it has to be effortless for the indie developers to integrate with.<p>For this, we ended up building our own DRM program. It consists of a C++ wrapper that encrypts and compresses games’ raw binary, as well as a program which injects assembly code into the game’s .EXE files which validates the parent process of the program upon running. The beauty of it is: developers don’t need to change any of their source code! (An interesting tradeoff is that although this reduces game file size by around 26%, it unfortunately increases memory usage by around 9%.) Most players understandably dislike DRMs, and of course there’s no perfect solution against piracy, but we’re hopeful that this approach will be non-intrusive enough for both players and devs to solve this core business problem.<p>We are super happy to see customers trying out games they normally wouldn’t! One example was Jared, who runs an indie podcast (Indie Game International on Spotify!): he got word of MagnaPlay and later told us how he gave this little indie game called Existensis a try and he absolutely loved it, played it to completion, and then ended up interviewing the developer on his podcast! So far, this was definitely the coolest thing we’ve seen happen on/due to MagnaPlay.<p>We’re happy to launch MagnaPlay on Hacker News and are eager to hear your feedback on our value prop, suggestions on dealing with chicken and egg, and on our product, which is available now for a free trial and then $8/month on <a href="https://magnaplay.tech">https://magnaplay.tech</a>. We look forward to your comments!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34369562">https://news.ycombinator.com/item?id=34369562</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## History of Web Browser Engines from 1990 until today
 - [https://eylenburg.github.io/browser_engines.htm](https://eylenburg.github.io/browser_engines.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 15:58:49+00:00
 - user: None

<p>Article URL: <a href="https://eylenburg.github.io/browser_engines.htm">https://eylenburg.github.io/browser_engines.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34369560">https://news.ycombinator.com/item?id=34369560</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## ChatGPT Can't Kill Anything Worth Preserving
 - [https://biblioracle.substack.com/p/chatgpt-cant-kill-anything-worth](https://biblioracle.substack.com/p/chatgpt-cant-kill-anything-worth)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 15:32:11+00:00
 - user: None

<p>Article URL: <a href="https://biblioracle.substack.com/p/chatgpt-cant-kill-anything-worth">https://biblioracle.substack.com/p/chatgpt-cant-kill-anything-worth</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34369110">https://news.ycombinator.com/item?id=34369110</a></p>
<p>Points: 34</p>
<p># Comments: 14</p>

## Working for a Dating Website (2015)
 - [https://caseysoftware.com/blog/working-for-a-dating-website](https://caseysoftware.com/blog/working-for-a-dating-website)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:59:42+00:00
 - user: None

<p>Article URL: <a href="https://caseysoftware.com/blog/working-for-a-dating-website">https://caseysoftware.com/blog/working-for-a-dating-website</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34368601">https://news.ycombinator.com/item?id=34368601</a></p>
<p>Points: 42</p>
<p># Comments: 35</p>

## Examples of Floating Point Problems
 - [https://jvns.ca/blog/2023/01/13/examples-of-floating-point-problems/](https://jvns.ca/blog/2023/01/13/examples-of-floating-point-problems/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:59:21+00:00
 - user: None

<p>Article URL: <a href="https://jvns.ca/blog/2023/01/13/examples-of-floating-point-problems/">https://jvns.ca/blog/2023/01/13/examples-of-floating-point-problems/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34368597">https://news.ycombinator.com/item?id=34368597</a></p>
<p>Points: 12</p>
<p># Comments: 4</p>

## Ask HN: We found a cracked version of our software on the web, now what?
 - [https://news.ycombinator.com/item?id=34368237](https://news.ycombinator.com/item?id=34368237)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:35:07+00:00
 - user: None

<p>Hi HN, I work for a small company and we've recently come across a version of our software that's been cracked.<p>Specifically, the crack modifies some of our binaries to circumvent the activation process and allows bogus registration keys. Pretty standard stuff AFAIK. Thankfully, our digital signatures are lost in the process, so that's reassuring.<p>We haven't done the most thorough search of how widespread the issue is, but we've estimated that it's about 1 user per day since the early half of 2022. A license costs a few thousand dollars, but we do regional pricing and bulk licenses for larger firms. We also provide free licenses to academics (with proof).<p>For context, we are a <15 person company where we all wear multiple hats and would like to continue providing great service, training and introducing features. It's clear to us why someone would crack our software, especially in lower income countries.<p>I'm not entirely sure what other information would be helpful to provide, but I was wondering if anyone has run into this into the past, and how it was mitigated. While we'll always have some piracy, we'd like to keep it to a minimum.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34368237">https://news.ycombinator.com/item?id=34368237</a></p>
<p>Points: 16</p>
<p># Comments: 17</p>

## How CUE Wins (2021)
 - [https://blog.cedriccharly.com/post/20210523-how-cue-wins/](https://blog.cedriccharly.com/post/20210523-how-cue-wins/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:09:14+00:00
 - user: None

<p>Article URL: <a href="https://blog.cedriccharly.com/post/20210523-how-cue-wins/">https://blog.cedriccharly.com/post/20210523-how-cue-wins/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367943">https://news.ycombinator.com/item?id=34367943</a></p>
<p>Points: 12</p>
<p># Comments: 12</p>

## Despite Everything You Think You Know, America Is on the Right Track
 - [https://www.theatlantic.com/ideas/archive/2023/01/american-optimism-productivity-innovation-rise/672714/](https://www.theatlantic.com/ideas/archive/2023/01/american-optimism-productivity-innovation-rise/672714/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:07:54+00:00
 - user: None

<p>Article URL: <a href="https://www.theatlantic.com/ideas/archive/2023/01/american-optimism-productivity-innovation-rise/672714/">https://www.theatlantic.com/ideas/archive/2023/01/american-optimism-productivity-innovation-rise/672714/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367920">https://news.ycombinator.com/item?id=34367920</a></p>
<p>Points: 38</p>
<p># Comments: 33</p>

## Endemic pathogens are causing psychiatric illnesses and shortening lifespans
 - [https://return.life/2022/05/endemic-pathogens/](https://return.life/2022/05/endemic-pathogens/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:06:59+00:00
 - user: None

<p>Article URL: <a href="https://return.life/2022/05/endemic-pathogens/">https://return.life/2022/05/endemic-pathogens/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367905">https://news.ycombinator.com/item?id=34367905</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## OpenAI starts testing ChatGPT premium
 - [https://www.businesstoday.in/technology/story/openai-tests-the-premium-version-of-chatgpt-heres-how-you-can-get-it-359958-2023-01-12](https://www.businesstoday.in/technology/story/openai-tests-the-premium-version-of-chatgpt-heres-how-you-can-get-it-359958-2023-01-12)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:02:05+00:00
 - user: None

<p>Article URL: <a href="https://www.businesstoday.in/technology/story/openai-tests-the-premium-version-of-chatgpt-heres-how-you-can-get-it-359958-2023-01-12">https://www.businesstoday.in/technology/story/openai-tests-the-premium-version-of-chatgpt-heres-how-you-can-get-it-359958-2023-01-12</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367824">https://news.ycombinator.com/item?id=34367824</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Big meat can’t quit antibiotics
 - [https://www.vox.com/future-perfect/2023/1/8/23542789/big-meat-antibiotics-resistance-fda](https://www.vox.com/future-perfect/2023/1/8/23542789/big-meat-antibiotics-resistance-fda)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 14:01:58+00:00
 - user: None

<p>Article URL: <a href="https://www.vox.com/future-perfect/2023/1/8/23542789/big-meat-antibiotics-resistance-fda">https://www.vox.com/future-perfect/2023/1/8/23542789/big-meat-antibiotics-resistance-fda</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367820">https://news.ycombinator.com/item?id=34367820</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## ABC: A C compiler for printable x86
 - [http://tom7.org/abc/](http://tom7.org/abc/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:59:41+00:00
 - user: None

<p>Article URL: <a href="http://tom7.org/abc/">http://tom7.org/abc/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367780">https://news.ycombinator.com/item?id=34367780</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## A 116kb WASM of Blink that lets you run x86_64 Linux binaries in the browser
 - [https://twitter.com/justinetunney/status/1613895681038770182](https://twitter.com/justinetunney/status/1613895681038770182)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:58:45+00:00
 - user: None

<p>Article URL: <a href="https://twitter.com/justinetunney/status/1613895681038770182">https://twitter.com/justinetunney/status/1613895681038770182</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367767">https://news.ycombinator.com/item?id=34367767</a></p>
<p>Points: 7</p>
<p># Comments: 2</p>

## Conversion of HP 54520C / 54540C oscilloscopes to VGA display(s)
 - [https://github.com/blackbit42/HP54542_LCD2VGA](https://github.com/blackbit42/HP54542_LCD2VGA)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:57:34+00:00
 - user: None

<p>Article URL: <a href="https://github.com/blackbit42/HP54542_LCD2VGA">https://github.com/blackbit42/HP54542_LCD2VGA</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367747">https://news.ycombinator.com/item?id=34367747</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Yet another keyboard post, or, introducing ErgoNICE
 - [https://val.packett.cool/blog/ergonice/](https://val.packett.cool/blog/ergonice/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:32:40+00:00
 - user: None

<p>Article URL: <a href="https://val.packett.cool/blog/ergonice/">https://val.packett.cool/blog/ergonice/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367390">https://news.ycombinator.com/item?id=34367390</a></p>
<p>Points: 21</p>
<p># Comments: 0</p>

## The Halo Drive: Fuel-Free Relativistic Propulsion (2019)
 - [https://arxiv.org/abs/1903.03423](https://arxiv.org/abs/1903.03423)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:30:35+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/1903.03423">https://arxiv.org/abs/1903.03423</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367367">https://news.ycombinator.com/item?id=34367367</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## The Gas Industry Is Paying Instagram Influencers to Gush over Gas Stoves
 - [https://www.motherjones.com/environment/2020/06/gas-industry-influencers-stoves/](https://www.motherjones.com/environment/2020/06/gas-industry-influencers-stoves/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 13:15:25+00:00
 - user: None

<p>Article URL: <a href="https://www.motherjones.com/environment/2020/06/gas-industry-influencers-stoves/">https://www.motherjones.com/environment/2020/06/gas-industry-influencers-stoves/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367230">https://news.ycombinator.com/item?id=34367230</a></p>
<p>Points: 7</p>
<p># Comments: 6</p>

## I deleted all my social media 3 yrs ago and I hardcore regret it everyday
 - [https://old.reddit.com/r/nosurf/comments/107osuu/i_deleted_all_my_social_media_about_3_years_ago/](https://old.reddit.com/r/nosurf/comments/107osuu/i_deleted_all_my_social_media_about_3_years_ago/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 12:53:26+00:00
 - user: None

<p>Article URL: <a href="https://old.reddit.com/r/nosurf/comments/107osuu/i_deleted_all_my_social_media_about_3_years_ago/">https://old.reddit.com/r/nosurf/comments/107osuu/i_deleted_all_my_social_media_about_3_years_ago/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34367036">https://news.ycombinator.com/item?id=34367036</a></p>
<p>Points: 40</p>
<p># Comments: 13</p>

## Study: Exxon Mobil Accurately Predicted Warming Since 1970s
 - [https://www.voanews.com/a/study-exxon-mobil-accurately-predicted-warming-since-1970s-/6916612.html](https://www.voanews.com/a/study-exxon-mobil-accurately-predicted-warming-since-1970s-/6916612.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 12:08:36+00:00
 - user: None

<p>Article URL: <a href="https://www.voanews.com/a/study-exxon-mobil-accurately-predicted-warming-since-1970s-/6916612.html">https://www.voanews.com/a/study-exxon-mobil-accurately-predicted-warming-since-1970s-/6916612.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34366696">https://news.ycombinator.com/item?id=34366696</a></p>
<p>Points: 8</p>
<p># Comments: 4</p>

## New study puts a number on what 'Exxon knew' decades ago about climate science
 - [https://phys.org/news/2023-01-exxon-knew-decades-climate-science.html](https://phys.org/news/2023-01-exxon-knew-decades-climate-science.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 12:05:12+00:00
 - user: None

<p>Article URL: <a href="https://phys.org/news/2023-01-exxon-knew-decades-climate-science.html">https://phys.org/news/2023-01-exxon-knew-decades-climate-science.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34366666">https://news.ycombinator.com/item?id=34366666</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Ask HN: Do you hate software engineering but love programming?
 - [https://news.ycombinator.com/item?id=34366610](https://news.ycombinator.com/item?id=34366610)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 11:57:46+00:00
 - user: None

<p>I have come to a realization that I don't really enjoy Software Engineering(& the processes that it comes with) but I do love programming & solving problems.<p>Finding and fixing bugs is a lot of fun. Incidence response is a lot of fun. Hacking on new projects is a lot of fun. Writing unit tests is fun too.<p>Refactoring, rewriting, sprint, agile, rearchitecting things etc aren't that fun. I like a few languages and I am not too keen on learning new paradigms or languages unless I have to. I'd rather get to value now by making something that just works(and is adequately tested) than engineer something thats future proof but takes longer to get out.<p>What are some good jobs for a person like this?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34366610">https://news.ycombinator.com/item?id=34366610</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## Liu Cixin's Technologies of the Future
 - [https://vincelwt.com/darkforest](https://vincelwt.com/darkforest)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 11:10:16+00:00
 - user: None

<p>Article URL: <a href="https://vincelwt.com/darkforest">https://vincelwt.com/darkforest</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34366286">https://news.ycombinator.com/item?id=34366286</a></p>
<p>Points: 17</p>
<p># Comments: 3</p>

## The 'Buy Now, Pay Later' Bubble Is About to Burst
 - [https://www.theatlantic.com/culture/archive/2023/01/buy-now-pay-later-affirm-afterpay-credit-card-debt/672686/](https://www.theatlantic.com/culture/archive/2023/01/buy-now-pay-later-affirm-afterpay-credit-card-debt/672686/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 09:24:28+00:00
 - user: None

<p>Article URL: <a href="https://www.theatlantic.com/culture/archive/2023/01/buy-now-pay-later-affirm-afterpay-credit-card-debt/672686/">https://www.theatlantic.com/culture/archive/2023/01/buy-now-pay-later-affirm-afterpay-credit-card-debt/672686/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34365609">https://news.ycombinator.com/item?id=34365609</a></p>
<p>Points: 27</p>
<p># Comments: 65</p>

## Alpine.js
 - [https://alpinejs.dev/](https://alpinejs.dev/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 09:09:47+00:00
 - user: None

<p>Article URL: <a href="https://alpinejs.dev/">https://alpinejs.dev/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34365515">https://news.ycombinator.com/item?id=34365515</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Care is needed to use C++ std:optional with non-trivial objects
 - [https://lemire.me/blog/2023/01/12/care-is-needed-to-use-c-stdoptional-with-non-trivial-objects/](https://lemire.me/blog/2023/01/12/care-is-needed-to-use-c-stdoptional-with-non-trivial-objects/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 09:06:22+00:00
 - user: None

<p>Article URL: <a href="https://lemire.me/blog/2023/01/12/care-is-needed-to-use-c-stdoptional-with-non-trivial-objects/">https://lemire.me/blog/2023/01/12/care-is-needed-to-use-c-stdoptional-with-non-trivial-objects/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34365494">https://news.ycombinator.com/item?id=34365494</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Perform What-If Analysis of Your Network Without Compromising Data Integrity
 - [https://memgraph.com/blog/perform-what-if-analysis-of-your-network-directly-in-storage-without-compromising-data-integrity](https://memgraph.com/blog/perform-what-if-analysis-of-your-network-directly-in-storage-without-compromising-data-integrity)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 08:38:26+00:00
 - user: None

<p>Article URL: <a href="https://memgraph.com/blog/perform-what-if-analysis-of-your-network-directly-in-storage-without-compromising-data-integrity">https://memgraph.com/blog/perform-what-if-analysis-of-your-network-directly-in-storage-without-compromising-data-integrity</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34365312">https://news.ycombinator.com/item?id=34365312</a></p>
<p>Points: 4</p>
<p># Comments: 1</p>

## Map of the Week: What Does the Land Under Antarctica’s Ice Sheet Look Like?
 - [https://ubique.americangeo.org/map-of-the-week/map-of-the-week-what-does-the-land-under-antarcticas-ice-sheet-look-like/](https://ubique.americangeo.org/map-of-the-week/map-of-the-week-what-does-the-land-under-antarcticas-ice-sheet-look-like/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 08:03:36+00:00
 - user: None

<p>Article URL: <a href="https://ubique.americangeo.org/map-of-the-week/map-of-the-week-what-does-the-land-under-antarcticas-ice-sheet-look-like/">https://ubique.americangeo.org/map-of-the-week/map-of-the-week-what-does-the-land-under-antarcticas-ice-sheet-look-like/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34365110">https://news.ycombinator.com/item?id=34365110</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## A command line tool that draw plots on the terminal
 - [https://github.com/red-data-tools/YouPlot](https://github.com/red-data-tools/YouPlot)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 07:09:03+00:00
 - user: None

<p>Article URL: <a href="https://github.com/red-data-tools/YouPlot">https://github.com/red-data-tools/YouPlot</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34364807">https://news.ycombinator.com/item?id=34364807</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Paizo Announces System-Neutral Open RPG License
 - [https://paizo.com/community/blog/v5748dyo6si7v?Paizo-Announces-SystemNeutral-Open-RPG-License](https://paizo.com/community/blog/v5748dyo6si7v?Paizo-Announces-SystemNeutral-Open-RPG-License)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 04:35:28+00:00
 - user: None

<p>Article URL: <a href="https://paizo.com/community/blog/v5748dyo6si7v?Paizo-Announces-SystemNeutral-Open-RPG-License">https://paizo.com/community/blog/v5748dyo6si7v?Paizo-Announces-SystemNeutral-Open-RPG-License</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363991">https://news.ycombinator.com/item?id=34363991</a></p>
<p>Points: 30</p>
<p># Comments: 4</p>

## How to Write English Prose
 - [https://thelampmagazine.com/2023/01/09/how-to-write-english-prose/](https://thelampmagazine.com/2023/01/09/how-to-write-english-prose/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 04:31:43+00:00
 - user: None

<p>Article URL: <a href="https://thelampmagazine.com/2023/01/09/how-to-write-english-prose/">https://thelampmagazine.com/2023/01/09/how-to-write-english-prose/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363974">https://news.ycombinator.com/item?id=34363974</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## What Were We Thinking?
 - [https://www.commonwealmagazine.org/what-were-we-thinking](https://www.commonwealmagazine.org/what-were-we-thinking)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 04:25:25+00:00
 - user: None

<p>Article URL: <a href="https://www.commonwealmagazine.org/what-were-we-thinking">https://www.commonwealmagazine.org/what-were-we-thinking</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363936">https://news.ycombinator.com/item?id=34363936</a></p>
<p>Points: 10</p>
<p># Comments: 2</p>

## My PhD qualifying exam was a nightmare but I'm not letting it define me
 - [https://www.science.org/content/article/my-ph-d-qualifying-exam-was-nightmare-i-m-not-letting-it-define-me](https://www.science.org/content/article/my-ph-d-qualifying-exam-was-nightmare-i-m-not-letting-it-define-me)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 03:52:07+00:00
 - user: None

<p>Article URL: <a href="https://www.science.org/content/article/my-ph-d-qualifying-exam-was-nightmare-i-m-not-letting-it-define-me">https://www.science.org/content/article/my-ph-d-qualifying-exam-was-nightmare-i-m-not-letting-it-define-me</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363746">https://news.ycombinator.com/item?id=34363746</a></p>
<p>Points: 15</p>
<p># Comments: 19</p>

## Twitter's API is down?
 - [https://news.ycombinator.com/item?id=34363743](https://news.ycombinator.com/item?id=34363743)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 03:51:48+00:00
 - user: None

<p>Getting an error loop on Tweetbot on all accounts:<p>Re-authorization Failed
Failed to request token from Twitter.com:: service unavailable</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363743">https://news.ycombinator.com/item?id=34363743</a></p>
<p>Points: 62</p>
<p># Comments: 17</p>

## Write admin tools from day one (2022)
 - [http://milwaukeemaven.blogspot.com/2022/08/write-admin-tools-from-day-one.html](http://milwaukeemaven.blogspot.com/2022/08/write-admin-tools-from-day-one.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 03:32:52+00:00
 - user: None

<p>Article URL: <a href="http://milwaukeemaven.blogspot.com/2022/08/write-admin-tools-from-day-one.html">http://milwaukeemaven.blogspot.com/2022/08/write-admin-tools-from-day-one.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34363642">https://news.ycombinator.com/item?id=34363642</a></p>
<p>Points: 6</p>
<p># Comments: 5</p>

## Tesla's solar factory in Buffalo fizzles
 - [https://www.investigativepost.org/2023/01/11/teslas-solar-factory-in-buffalo-fizzles/](https://www.investigativepost.org/2023/01/11/teslas-solar-factory-in-buffalo-fizzles/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 01:28:17+00:00
 - user: None

<p>Article URL: <a href="https://www.investigativepost.org/2023/01/11/teslas-solar-factory-in-buffalo-fizzles/">https://www.investigativepost.org/2023/01/11/teslas-solar-factory-in-buffalo-fizzles/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34362826">https://news.ycombinator.com/item?id=34362826</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## Loss of Epigenetic Information Can Drive Aging, Restoration Can Reverse It
 - [https://hms.harvard.edu/news/loss-epigenetic-information-can-drive-aging-restoration-can-reverse](https://hms.harvard.edu/news/loss-epigenetic-information-can-drive-aging-restoration-can-reverse)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-13 00:12:28+00:00
 - user: None

<p>Article URL: <a href="https://hms.harvard.edu/news/loss-epigenetic-information-can-drive-aging-restoration-can-reverse">https://hms.harvard.edu/news/loss-epigenetic-information-can-drive-aging-restoration-can-reverse</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34362210">https://news.ycombinator.com/item?id=34362210</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>
