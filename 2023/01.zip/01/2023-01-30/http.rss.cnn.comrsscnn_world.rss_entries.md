# Source CNN World, Source URL:http://rss.cnn.com/rss/cnn_world.rss, Source language: en-US

## Pope Francis to visit two fragile African nations
 - [https://www.cnn.com/2023/01/30/africa/pope-francis-africa-visit-intl/index.html](https://www.cnn.com/2023/01/30/africa/pope-francis-africa-visit-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-30 18:27:10+00:00
 - user: None

Pope Francis starts a trip on Tuesday to two fragile African nations often forgotten by the world, where protracted conflicts have left millions of refugees and displaced people grappling with hunger.

## Eight people dead as gunman opens fire on birthday party in South Africa
 - [https://www.cnn.com/2023/01/30/africa/birthday-party-shooting-south-africa-intl/index.html](https://www.cnn.com/2023/01/30/africa/birthday-party-shooting-south-africa-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-30 10:02:31+00:00
 - user: None

Eight people were killed and three wounded after two gunmen entered a home and opened fire on a group of people celebrating a birthday in the southern port city of Gqeberha, formerly Port Elizabeth, in South Africa on Sunday evening, according to the South African police service (SAPS).
