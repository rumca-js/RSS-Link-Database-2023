# Source Wydarzenia Interia, Source URL:https://wydarzenia.interia.pl/feed, Source language: pl-PL

## Skandynawowie wyślą Leopardy Ukrainie. "Najszybciej, jak to możliwe"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-skandynawowie-wysla-leopardy-ukrainie-najszybciej-jak-to-moz,nId,6566895](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-skandynawowie-wysla-leopardy-ukrainie-najszybciej-jak-to-moz,nId,6566895)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 22:28:09+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-skandynawowie-wysla-leopardy-ukrainie-najszybciej-jak-to-moz,nId,6566895"><img align="left" alt="Skandynawowie wyślą Leopardy Ukrainie. &quot;Najszybciej, jak to możliwe&quot;" src="https://i.iplsc.com/skandynawowie-wysla-leopardy-ukrainie-najszybciej-jak-to-moz/000GOU2OWY3JGNWO-C321.jpg" /></a>Norwegia przekaże Ukrainie czołgi Leopard 2 najszybciej, jak to tylko możliwe - zapowiedział w poniedziałek minister obrony Norwegii Bjørn Arild Gram, cytowany przez AFP. Darowiznę w postaci pojazdów pancernych rozważa także Kopenhaga. - Jesteśmy otwarci na wysłanie czołgów Leopard 2 – powiedziała duńska premier Mette Frederiksen.</p><br clear="all" />

## USA: Joe Biden przyleci do Polski, ale jeszcze nie wie, kiedy
 - [https://wydarzenia.interia.pl/zagranica/news-usa-joe-biden-przyleci-do-polski-ale-jeszcze-nie-wie-kiedy,nId,6566896](https://wydarzenia.interia.pl/zagranica/news-usa-joe-biden-przyleci-do-polski-ale-jeszcze-nie-wie-kiedy,nId,6566896)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 21:31:27+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-joe-biden-przyleci-do-polski-ale-jeszcze-nie-wie-kiedy,nId,6566896"><img align="left" alt="USA: Joe Biden przyleci do Polski, ale jeszcze nie wie, kiedy" src="https://i.iplsc.com/usa-joe-biden-przyleci-do-polski-ale-jeszcze-nie-wie-kiedy/000AWFNWLXWQYNDV-C321.jpg" /></a>Prezydent USA Joe Biden potwierdził, że odwiedzi Polskę. Zastrzegł jednak, że nie wie, w jakim dokładnie terminie. Amerykański przywódca poinformował także, że jego kraj nie przekaże Ukrainie samolotów F-16.</p><br clear="all" />

## Fala strajków w Wielkiej Brytanii. Dołączają i nauczyciele
 - [https://wydarzenia.interia.pl/zagranica/news-fala-strajkow-w-wielkiej-brytanii-dolaczaja-i-nauczyciele,nId,6566882](https://wydarzenia.interia.pl/zagranica/news-fala-strajkow-w-wielkiej-brytanii-dolaczaja-i-nauczyciele,nId,6566882)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 20:37:29+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-fala-strajkow-w-wielkiej-brytanii-dolaczaja-i-nauczyciele,nId,6566882"><img align="left" alt="Fala strajków w Wielkiej Brytanii. Dołączają i nauczyciele" src="https://i.iplsc.com/fala-strajkow-w-wielkiej-brytanii-dolaczaja-i-nauczyciele/000GOTWWM9EA9GJC-C321.jpg" /></a>Związek zawodowy FBU zapowiedział pierwszy od 20 lat, ogólnokrajowy strajk brytyjskich strażaków. Jednocześnie NEU - związek zawodowy nauczycieli poinformował o fiasku rozmów ze stroną rządową i za kilka dni rozpocznie swój strajk. Najbliższa środa będzie dniem kumulacji protestów kilku branż.</p><br clear="all" />

## Zmiany w Kodeksie postępowania cywilnego. Rzecznik PiS zabrał głos
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-postepowania-cywilnego-rzecznik-pis-zabral,nId,6566880](https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-postepowania-cywilnego-rzecznik-pis-zabral,nId,6566880)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 20:30:46+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-postepowania-cywilnego-rzecznik-pis-zabral,nId,6566880"><img align="left" alt="Zmiany w Kodeksie postępowania cywilnego. Rzecznik PiS zabrał głos" src="https://i.iplsc.com/zmiany-w-kodeksie-postepowania-cywilnego-rzecznik-pis-zabral/000GOTW19LBRU3TV-C321.jpg" /></a>- Łączenie prywatnej sprawy prezesa PiS ze zmianą przepisów w Kodeksie postępowania cywilnego jest nieuzasadnione - ocenił w poniedziałek rzecznik PiS. Wcześniej pojawiły się doniesienia, że nowelizacja ma związek z przegranym procesem Jarosława Kaczyńskiego. - Aby uciąć spekulacje zgłosimy poprawkę, że te przepisy będą stosowane do postępowań dopiero w przyszłości - podkreślił w rozmowie z PAP Rafał Bochenek.</p><br clear="all" />

## Wargacze zamarzły na belgijskim lotnisku. Spędziły dobę w lodowatym samolocie
 - [https://wydarzenia.interia.pl/zagranica/news-wargacze-zamarzly-na-belgijskim-lotnisku-spedzily-dobe-w-lod,nId,6566856](https://wydarzenia.interia.pl/zagranica/news-wargacze-zamarzly-na-belgijskim-lotnisku-spedzily-dobe-w-lod,nId,6566856)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 19:53:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wargacze-zamarzly-na-belgijskim-lotnisku-spedzily-dobe-w-lod,nId,6566856"><img align="left" alt="Wargacze zamarzły na belgijskim lotnisku. Spędziły dobę w lodowatym samolocie" src="https://i.iplsc.com/wargacze-zamarzly-na-belgijskim-lotnisku-spedzily-dobe-w-lod/000GOTS3K4TSI9PV-C321.jpg" /></a>Na lotnisku w belgijskim Liege zamarzły trzy wargacze, które spędziły 24 godziny w samolocie. Maszyna była zablokowana przez obfite opady śniegu. Jak informują media, w sprawie interweniuje walońska minister ds. dobrostanu zwierząt Celine Tellier.</p><br clear="all" />

## Zdjęcia z Nowego Jorku obiegły sieć. Wiemy, kto stoi za kampanią
 - [https://wydarzenia.interia.pl/zagranica/news-zdjecia-z-nowego-jorku-obiegly-siec-wiemy-kto-stoi-za-kampan,nId,6566811](https://wydarzenia.interia.pl/zagranica/news-zdjecia-z-nowego-jorku-obiegly-siec-wiemy-kto-stoi-za-kampan,nId,6566811)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 19:19:09+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zdjecia-z-nowego-jorku-obiegly-siec-wiemy-kto-stoi-za-kampan,nId,6566811"><img align="left" alt="Zdjęcia z Nowego Jorku obiegły sieć. Wiemy, kto stoi za kampanią" src="https://i.iplsc.com/zdjecia-z-nowego-jorku-obiegly-siec-wiemy-kto-stoi-za-kampan/000GOTMOML60JOS1-C321.jpg" /></a>300 słoneczników ma przypominać Amerykanom o wojnie w Ukrainie i sprawić, że temat rosyjskiej napaści nie zniknie całkiem z mediów - również tych społecznościowych. Polską akcję wspierają m.in. spoty oraz filmy publikowane przez influencerów. Za kampanię odpowiada Bank Gospodarstwa Krajowego, a wydano na nią ponad trzy miliony dolarów.</p><br clear="all" />

## Kobieta zabiła swojego "sobowtóra", by uciec od rodziny
 - [https://wydarzenia.interia.pl/zagranica/news-kobieta-zabila-swojego-sobowtora-by-uciec-od-rodziny,nId,6566833](https://wydarzenia.interia.pl/zagranica/news-kobieta-zabila-swojego-sobowtora-by-uciec-od-rodziny,nId,6566833)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 19:14:51+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kobieta-zabila-swojego-sobowtora-by-uciec-od-rodziny,nId,6566833"><img align="left" alt="Kobieta zabiła swojego &quot;sobowtóra&quot;, by uciec od rodziny" src="https://i.iplsc.com/kobieta-zabila-swojego-sobowtora-by-uciec-od-rodziny/000GOTOV44A1CM5S-C321.jpg" /></a>Sprawa sobowtóra z Ingolstadt była jedną z bardziej skomplikowanych spraw kryminalnych w Niemczech, w 2022 roku. 24-letni Shahraban K. i Sheqir K. zamordowali z premedytacją kobietę, zadając jej 50 ciosów nożem. Ofiarę wytypowali na Instagramie.</p><br clear="all" />

## Łukaszenka w Zimbabwe. Ukraińscy internauci nie mają litości
 - [https://wydarzenia.interia.pl/zagranica/news-lukaszenka-w-zimbabwe-ukrainscy-internauci-nie-maja-litosci,nId,6566821](https://wydarzenia.interia.pl/zagranica/news-lukaszenka-w-zimbabwe-ukrainscy-internauci-nie-maja-litosci,nId,6566821)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 19:14:10+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lukaszenka-w-zimbabwe-ukrainscy-internauci-nie-maja-litosci,nId,6566821"><img align="left" alt="Łukaszenka w Zimbabwe. Ukraińscy internauci nie mają litości" src="https://i.iplsc.com/lukaszenka-w-zimbabwe-ukrainscy-internauci-nie-maja-litosci/000GOTLSBGA1EXGG-C321.jpg" /></a>Białoruski dyktator kilka dni temu ruszył w podróż na Bliski Wschód oraz do Afryki. Dziś dotarł do Zimbabwe, gdzie przywitano go tańcami i śpiewem. Wizyta nie uszła uwadze internautów w Telegramie. - Mamy nadzieję, że uzurpator zostanie tam przywódcą i już nigdy nie wróci - pisze jeden z nich.</p><br clear="all" />

## Poszkodowana o wybuchu w Katowicach: Tam było mnóstwo aniołów
 - [https://wydarzenia.interia.pl/kraj/news-poszkodowana-o-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790](https://wydarzenia.interia.pl/kraj/news-poszkodowana-o-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:56:07+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-poszkodowana-o-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790"><img align="left" alt="Poszkodowana o wybuchu w Katowicach: Tam było mnóstwo aniołów" src="https://i.iplsc.com/poszkodowana-o-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow/000GOTGSJ68MGDKR-C321.jpg" /></a>- Moja mama powiedziała, że tego dnia było tam po prostu mnóstwo aniołów - powiedziała dziennikarzom Joanna Ucińska, która po eksplozji w Katowicach trafiła do szpitala z dwiema rannymi córeczkami.</p><br clear="all" />

## Poszkodowana wybuchu w Katowicach: Tam było mnóstwo aniołów
 - [https://wydarzenia.interia.pl/kraj/news-poszkodowana-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790](https://wydarzenia.interia.pl/kraj/news-poszkodowana-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:56:07+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-poszkodowana-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow,nId,6566790"><img align="left" alt="Poszkodowana wybuchu w Katowicach: Tam było mnóstwo aniołów" src="https://i.iplsc.com/poszkodowana-wybuchu-w-katowicach-tam-bylo-mnostwo-aniolow/000GOTGSJ68MGDKR-C321.jpg" /></a>- Moja mama powiedziała, że tego dnia było tam po prostu mnóstwo aniołów - powiedziała dziennikarzom Joanna Ucińska, która po eksplozji w Katowicach trafiła do szpitala z dwiema rannymi córeczkami.</p><br clear="all" />

## NIK nie mógł skontrolować Orlenu. Banaś idzie do prokuratury
 - [https://wydarzenia.interia.pl/kraj/news-nik-nie-mogl-skontrolowac-orlenu-banas-idzie-do-prokuratury,nId,6566763](https://wydarzenia.interia.pl/kraj/news-nik-nie-mogl-skontrolowac-orlenu-banas-idzie-do-prokuratury,nId,6566763)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:47:36+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nik-nie-mogl-skontrolowac-orlenu-banas-idzie-do-prokuratury,nId,6566763"><img align="left" alt="NIK nie mógł skontrolować Orlenu. Banaś idzie do prokuratury" src="https://i.iplsc.com/nik-nie-mogl-skontrolowac-orlenu-banas-idzie-do-prokuratury/000GOTA54EOAD25K-C321.jpg" /></a>Marian Banaś chciał skontrolować Orlen, ale jak wynika z oświadczenia prezesa NIK, Orlen skontrolować się nie dał. Banaś składa w tej sprawie zawiadomienie do prokuratury i podkreśla, że osoby odpowiedzialne za wydawanie trzech miliardów publicznych złotych rocznie &quot;twierdzą, że nie należy kontrolować ich wydatków&quot;.</p><br clear="all" />

## Nie żyje Piotr Waśko. Był posłem PO i burmistrzem Wielenia
 - [https://wydarzenia.interia.pl/kraj/news-nie-zyje-piotr-wasko-byl-poslem-po-i-burmistrzem-wielenia,nId,6566776](https://wydarzenia.interia.pl/kraj/news-nie-zyje-piotr-wasko-byl-poslem-po-i-burmistrzem-wielenia,nId,6566776)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:46:52+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nie-zyje-piotr-wasko-byl-poslem-po-i-burmistrzem-wielenia,nId,6566776"><img align="left" alt="Nie żyje Piotr Waśko. Był posłem PO i burmistrzem Wielenia" src="https://i.iplsc.com/nie-zyje-piotr-wasko-byl-poslem-po-i-burmistrzem-wielenia/000GOTDSEG7NL4QF-C321.jpg" /></a>W wieku 61 lat zmarł Piotr Waśko, były poseł Platformy Obywatelskiej, a na przełomie lat 90. i 00. burmistrz Wielenia w Wielkopolsce. &quot;Był człowiekiem piekielnie inteligentnym, wrażliwym na drugiego człowieka i piękno otaczającego świata. Duszą towarzystwa i oparciem w wielu sprawach&quot; - napisał Waldy Dzikowski, jego kolega z partii.</p><br clear="all" />

## Zabrze: Miał zgwałcić i okraść 17-latkę. Policja opublikowała wizerunek
 - [https://wydarzenia.interia.pl/slaskie/news-zabrze-mial-zgwalcic-i-okrasc-17-latke-policja-opublikowala-,nId,6566782](https://wydarzenia.interia.pl/slaskie/news-zabrze-mial-zgwalcic-i-okrasc-17-latke-policja-opublikowala-,nId,6566782)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:40:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/slaskie/news-zabrze-mial-zgwalcic-i-okrasc-17-latke-policja-opublikowala-,nId,6566782"><img align="left" alt="Zabrze: Miał zgwałcić i okraść 17-latkę. Policja opublikowała wizerunek" src="https://i.iplsc.com/zabrze-mial-zgwalcic-i-okrasc-17-latke-policja-opublikowala/000GOTDP4W8FERNX-C321.jpg" /></a>Policja z Zabrza opublikowała wizerunek poszukiwanego mężczyzny. Jest on podejrzewany o to, że kilka dni temu zgwałcił 17-latkę, a następnie ukradł jej telefon i zegarek. </p><br clear="all" />

## Czechy: 21-latka jechała po torach tramwajowych. Tak poleciła jej nawigacja
 - [https://wydarzenia.interia.pl/zagranica/news-czechy-21-latka-jechala-po-torach-tramwajowych-tak-polecila-,nId,6566678](https://wydarzenia.interia.pl/zagranica/news-czechy-21-latka-jechala-po-torach-tramwajowych-tak-polecila-,nId,6566678)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 17:12:21+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czechy-21-latka-jechala-po-torach-tramwajowych-tak-polecila-,nId,6566678"><img align="left" alt="Czechy: 21-latka jechała po torach tramwajowych. Tak poleciła jej nawigacja" src="https://i.iplsc.com/czechy-21-latka-jechala-po-torach-tramwajowych-tak-polecila/000GOT9QHEKPSV0F-C321.jpg" /></a>Młoda kobieta zaufała nawigacji, która wyprowadziła ją na tory tramwajowe w czeskiej Ostrawie. Przejechała po nich 30 metrów, po czym utknęła. Na pomoc pospieszyli policjanci i strażacy, a ruch szynowej komunikacji miejskiej trzeba było tymczasowo wstrzymać.</p><br clear="all" />

## Szwecja: Gangsterzy odwołali burmistrz. "Niektórzy ledwo znali język"
 - [https://wydarzenia.interia.pl/zagranica/news-szwecja-gangsterzy-odwolali-burmistrz-niektorzy-ledwo-znali-,nId,6566587](https://wydarzenia.interia.pl/zagranica/news-szwecja-gangsterzy-odwolali-burmistrz-niektorzy-ledwo-znali-,nId,6566587)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 16:27:14+00:00
 - user: rumpel
 - tags: immigration,sweden

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szwecja-gangsterzy-odwolali-burmistrz-niektorzy-ledwo-znali-,nId,6566587"><img align="left" alt="Szwecja: Gangsterzy odwołali burmistrz. &quot;Niektórzy ledwo znali język&quot;" src="https://i.iplsc.com/szwecja-gangsterzy-odwolali-burmistrz-niektorzy-ledwo-znali/000GOSVPESP962SS-C321.jpg" /></a>Walczyła z przestępczością, a teraz lokalni gangsterzy pozbawili ją stanowiska burmistrza. Ebby Oestlin, rządząca w gminie Botkyrka pod Sztokholmem, straciła poparcie Partii Robotniczej - Socjaldemokraci, bo do ugrupowania przyjęto nowe osoby. Gdy zorientowano się, że wśród dodatkowych członków są przestępcy, było za późno.</p><br clear="all" />

## Nowa faza sporu w TK. Muszyński w postanowieniu o "byłej prezes"
 - [https://wydarzenia.interia.pl/kraj/news-nowa-faza-sporu-w-tk-muszynski-w-postanowieniu-o-bylej-preze,nId,6566594](https://wydarzenia.interia.pl/kraj/news-nowa-faza-sporu-w-tk-muszynski-w-postanowieniu-o-bylej-preze,nId,6566594)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 16:25:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowa-faza-sporu-w-tk-muszynski-w-postanowieniu-o-bylej-preze,nId,6566594"><img align="left" alt="Nowa faza sporu w TK. Muszyński w postanowieniu o &quot;byłej prezes&quot;" src="https://i.iplsc.com/nowa-faza-sporu-w-tk-muszynski-w-postanowieniu-o-bylej-preze/000GOSVIWLCUC5Q8-C321.jpg" /></a>Spór sędziów TK wkracza w nową fazę. W zdaniu odrębnym do postanowienia Trybunału, sędzia Mariusz Muszyński nazwał Julią Przyłębską &quot;byłą prezes&quot;. Główna zainteresowana postanowiła odpowiedzieć i wskazała, na co Muszyński powinien przeznaczyć swój &quot;wysiłek intelektualny&quot;.</p><br clear="all" />

## "Umarł jak bohater". Ukraina żegna "jednego z najlepszych oficerów"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umarl-jak-bohater-ukraina-zegna-jednego-z-najlepszych-oficer,nId,6566568](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umarl-jak-bohater-ukraina-zegna-jednego-z-najlepszych-oficer,nId,6566568)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 16:08:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-umarl-jak-bohater-ukraina-zegna-jednego-z-najlepszych-oficer,nId,6566568"><img align="left" alt="&quot;Umarł jak bohater&quot;. Ukraina żegna &quot;jednego z najlepszych oficerów&quot;" src="https://i.iplsc.com/umarl-jak-bohater-ukraina-zegna-jednego-z-najlepszych-oficer/000GOSRYIJ42WD7U-C321.jpg" /></a>24-letni Danyło Muraszko tuż przed śmiercią sprawił, że na wschodzie Ukrainy nie doszło do większej tragedii. W jego samolot uderzyła rosyjska rakieta. Pilot, opłakiwany teraz przez swoich kolegów z wojska, wykonał manewr, dzięki któremu maszyna nie spadła na zamieszkane budynki. Samemu nie był jednak w stanie bezpiecznie ewakuować się z samolotu.</p><br clear="all" />

## Włoski pułkownik: Rosyjski kontyngent pomocowy podczas pandemii miał tajną misję
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-wloski-pulkownik-rosyjski-kontyngent-pomocowy-podczas-pandem,nId,6566569](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-wloski-pulkownik-rosyjski-kontyngent-pomocowy-podczas-pandem,nId,6566569)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 16:01:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/aktualnosci/news-wloski-pulkownik-rosyjski-kontyngent-pomocowy-podczas-pandem,nId,6566569"><img align="left" alt="Włoski pułkownik: Rosyjski kontyngent pomocowy podczas pandemii miał tajną misję" src="https://i.iplsc.com/wloski-pulkownik-rosyjski-kontyngent-pomocowy-podczas-pandem/000GOSQC2G1U7EDR-C321.jpg" /></a>Mieli nieść pomoc w miastach w Lombardii, zmagającej się z ostrą falą zachorowań i zgonów na COVID- 19. Pojawia się jednak coraz więcej wątpliwości, co do prawdziwego celu obecności Rosjan we Włoszech w marcu 2020 r. w ramach operacji &quot;Z Rosji z miłością&quot;. - W 104-osobowym rosyjskim kontyngencie przybyłym na północ Włoch na początku pandemii, by pomóc w Bergamo i Brescii, było tylko dwóch lekarzy i pięciu pielęgniarzy; pozostali to żołnierze - ujawnia włoski pułkownik rezerwy Orio Giorgio Stirpe podczas sympozjum zorganizowanego w Rzymie.</p><br clear="all" />

## Warszawa: Zabójstwo na Nowym Świecie. Pierwszy podejrzany w rękach policji
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-zabojstwo-na-nowym-swiecie-pierwszy-podejrzany-w-re,nId,6566556](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-zabojstwo-na-nowym-swiecie-pierwszy-podejrzany-w-re,nId,6566556)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 15:37:30+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-zabojstwo-na-nowym-swiecie-pierwszy-podejrzany-w-re,nId,6566556"><img align="left" alt="Warszawa: Zabójstwo na Nowym Świecie. Pierwszy podejrzany w rękach policji" src="https://i.iplsc.com/warszawa-zabojstwo-na-nowym-swiecie-pierwszy-podejrzany-w-re/000GOSOHMDYS1T2S-C321.jpg" /></a>Policjanci zatrzymali Łukasza G., pierwszego z podejrzanych o zabójstwo z maja 2022 r. na Nowym Świecie w Warszawie - podała stołeczna policja. </p><br clear="all" />

## Rosja: Będą nagrody za zdobycie Leopardów i Abramsów
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-beda-nagrody-za-zdobycie-leopardow-i-abramsow,nId,6566532](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-beda-nagrody-za-zdobycie-leopardow-i-abramsow,nId,6566532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 15:27:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosja-beda-nagrody-za-zdobycie-leopardow-i-abramsow,nId,6566532"><img align="left" alt="Rosja: Będą nagrody za zdobycie Leopardów i Abramsów" src="https://i.iplsc.com/rosja-beda-nagrody-za-zdobycie-leopardow-i-abramsow/000GOSLEGYFA740M-C321.jpg" /></a>Decyzja państw zachodnich o przekazaniu Ukrainie czołgów odbiła się szerokim echem w Rosji. To wydarzenie na tyle istotne, że władze Kraju Zabajkalskiego zdecydowały się nagradzać finansowo żołnierzy za przejęcie lub zniszczenie nowoczesnych, europejskich i amerykańskich maszyn. Za zdobycie Leoparda żołnierz może liczyć na trzy miliony rubli.</p><br clear="all" />

## Michałek zmarł przez trutkę na szczury. Zapadł wyrok w głośnej sprawie
 - [https://wydarzenia.interia.pl/zachodniopomorskie/news-michalek-zmarl-przez-trutke-na-szczury-zapadl-wyrok-w-glosne,nId,6566531](https://wydarzenia.interia.pl/zachodniopomorskie/news-michalek-zmarl-przez-trutke-na-szczury-zapadl-wyrok-w-glosne,nId,6566531)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 15:08:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zachodniopomorskie/news-michalek-zmarl-przez-trutke-na-szczury-zapadl-wyrok-w-glosne,nId,6566531"><img align="left" alt="Michałek zmarł przez trutkę na szczury. Zapadł wyrok w głośnej sprawie" src="https://i.iplsc.com/michalek-zmarl-przez-trutke-na-szczury-zapadl-wyrok-w-glosne/000GOSN94I8K8ECK-C321.jpg" /></a>Dwa lata więzienia - na tyle skazał Henryka C. szczeciński Sąd Okręgowy. Chodzi o spowodowanie śmiertelnego zatrucia dziecka przez rozłożenie w budynku trutki na szczury. W wyniku zatrucia fosforowodorem zmarł 14-miesięczny Michał. Wyrok nie jest prawomocny.</p><br clear="all" />

## Poszukiwaniami żyły całe Chiny. Zwłoki, trzy miesiące nerwów i pytania
 - [https://wydarzenia.interia.pl/zagranica/news-poszukiwaniami-zyly-cale-chiny-zwloki-trzy-miesiace-nerwow-i,nId,6566476](https://wydarzenia.interia.pl/zagranica/news-poszukiwaniami-zyly-cale-chiny-zwloki-trzy-miesiace-nerwow-i,nId,6566476)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 14:40:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-poszukiwaniami-zyly-cale-chiny-zwloki-trzy-miesiace-nerwow-i,nId,6566476"><img align="left" alt="Poszukiwaniami żyły całe Chiny. Zwłoki, trzy miesiące nerwów i pytania" src="https://i.iplsc.com/poszukiwaniami-zyly-cale-chiny-zwloki-trzy-miesiace-nerwow-i/000GORQY4MS7MK0A-C321.jpg" /></a>15-letni Hu Xinyu wyszedł z akademika i słuch po nim zaginął. Przez trzy miesiące Chiny żyły poszukiwaniami nastolatka. Przełom nastąpił po 100 dniach. Ciało Xu leżało w lesie - niedaleko jego szkoły. Jak informują zagraniczne media, odnalezienie zwłok nastolatka budzi jednak więcej pytań, niż daje odpowiedzi.</p><br clear="all" />

## Chiny: Władze zmieniają politykę rodzinną. Chodzi o zwiększenie dzietności
 - [https://wydarzenia.interia.pl/zagranica/news-chiny-wladze-zmieniaja-polityke-rodzinna-chodzi-o-zwiekszeni,nId,6566441](https://wydarzenia.interia.pl/zagranica/news-chiny-wladze-zmieniaja-polityke-rodzinna-chodzi-o-zwiekszeni,nId,6566441)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 14:34:55+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chiny-wladze-zmieniaja-polityke-rodzinna-chodzi-o-zwiekszeni,nId,6566441"><img align="left" alt="Chiny: Władze zmieniają politykę rodzinną. Chodzi o zwiększenie dzietności" src="https://i.iplsc.com/chiny-wladze-zmieniaja-polityke-rodzinna-chodzi-o-zwiekszeni/000GORI3CT6CACT7-C321.jpg" /></a>Władze prowincji Syczuan na południowym zachodzie Chin zezwolą osobom stanu wolnego na rejestrację dzieci i korzystanie ze świadczeń zarezerwowanych dotąd dla małżeństw. Ma to zachęcić mieszkańców do posiadania dzieci, również w związkach pozamałżeńskich.</p><br clear="all" />

## 31. Finał WOŚP. Jerzy Owsiak podał, ile udało się zebrać
 - [https://wydarzenia.interia.pl/kraj/news-31-final-wosp-jerzy-owsiak-podal-ile-udalo-sie-zebrac,nId,6566488](https://wydarzenia.interia.pl/kraj/news-31-final-wosp-jerzy-owsiak-podal-ile-udalo-sie-zebrac,nId,6566488)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 14:17:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-31-final-wosp-jerzy-owsiak-podal-ile-udalo-sie-zebrac,nId,6566488"><img align="left" alt="31. Finał WOŚP. Jerzy Owsiak podał, ile udało się zebrać" src="https://i.iplsc.com/31-final-wosp-jerzy-owsiak-podal-ile-udalo-sie-zebrac/000GORNNUHW3N2CJ-C321.jpg" /></a>Jerzy Owsiak wstępnie podsumował 31. Finał Wielkiej Orkiestry Świątecznej Pomocy. Udało się zebrać ponad 154 miliony złotych. W tegorocznej edycji 120 tysięcy wolontariuszy zbierało pieniądze, dzięki którym będzie można skuteczniej walczyć z sepsą.</p><br clear="all" />

## CBOS: Andrzej Duda, Rafał Trzaskowski i Mateusz Morawiecki liderami rankingu zaufania w styczniu
 - [https://wydarzenia.interia.pl/kraj/news-cbos-andrzej-duda-rafal-trzaskowski-i-mateusz-morawiecki-lid,nId,6566440](https://wydarzenia.interia.pl/kraj/news-cbos-andrzej-duda-rafal-trzaskowski-i-mateusz-morawiecki-lid,nId,6566440)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 14:11:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-cbos-andrzej-duda-rafal-trzaskowski-i-mateusz-morawiecki-lid,nId,6566440"><img align="left" alt="CBOS: Andrzej Duda, Rafał Trzaskowski i Mateusz Morawiecki liderami rankingu zaufania w styczniu " src="https://i.iplsc.com/cbos-andrzej-duda-rafal-trzaskowski-i-mateusz-morawiecki-lid/000GORF16GRH335J-C321.jpg" /></a>CBOS opublikował nowy ranking, z którego wynika, że w styczniu największym zaufaniem spośród polityków cieszyli się prezydent Andrzej Duda, prezydent Warszawy Rafał Trzaskowski i premier Mateusz Morawiecki. Z kolei z największą nieufnością spotykali się prezes PiS Jarosław Kaczyński, minister sprawiedliwości Zbigniew Ziobro oraz szef PO Donald Tusk. </p><br clear="all" />

## Ukraińcy bronią "kluczowego bastionu". W Wuhłedarze inaczej niż pod Bachmutem
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-bronia-kluczowego-bastionu-w-wuhledarze-inaczej-niz,nId,6566417](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-bronia-kluczowego-bastionu-w-wuhledarze-inaczej-niz,nId,6566417)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 13:40:29+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraincy-bronia-kluczowego-bastionu-w-wuhledarze-inaczej-niz,nId,6566417"><img align="left" alt="Ukraińcy bronią &quot;kluczowego bastionu&quot;. W Wuhłedarze inaczej niż pod Bachmutem" src="https://i.iplsc.com/ukraincy-bronia-kluczowego-bastionu-w-wuhledarze-inaczej-niz/000GORE147NOG8SB-C321.jpg" /></a>Położone na południu obwodu donieckiego miasteczko Wuhłedar to obecnie kluczowy bastion naszej obrony w Donbasie. Utrata kontroli nad tą miejscowością zmusiłaby nas do przeorganizowania całej linii frontu - powiadomił rzecznik ukraińskiej 68. samodzielnej brygady strzelców Jewhen Nazarenko.</p><br clear="all" />

## Ukradł radiowóz. Policjanci wyciągnęli go z auta w ostatniej chwili
 - [https://wydarzenia.interia.pl/zagranica/news-ukradl-radiowoz-policjanci-wyciagneli-go-z-auta-w-ostatniej-,nId,6566269](https://wydarzenia.interia.pl/zagranica/news-ukradl-radiowoz-policjanci-wyciagneli-go-z-auta-w-ostatniej-,nId,6566269)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 13:36:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukradl-radiowoz-policjanci-wyciagneli-go-z-auta-w-ostatniej-,nId,6566269"><img align="left" alt="Ukradł radiowóz. Policjanci wyciągnęli go z auta w ostatniej chwili" src="https://i.iplsc.com/ukradl-radiowoz-policjanci-wyciagneli-go-z-auta-w-ostatniej/000GOQSR1G9Y07W0-C321.jpg" /></a>Na ulicach Atlanty w USA miał miejsce pościg policji za mężczyzną. Podejrzany skorzystał z niefrasobliwości jednego z funkcjonariuszy i... ukradł jego radiowóz. Mężczyzna rozbił auto, po czym utknął we wraku na torach kolejowych. Funkcjonariusze wyciągnęli go z samochodu w ostatniej chwili. Zaraz po tym nadjechał pociąg towarowy. </p><br clear="all" />

## 14-latce odmówiono aborcji. Interweniuje RPO, Niedzielski komentuje
 - [https://wydarzenia.interia.pl/kraj/news-14-latce-odmowiono-aborcji-interweniuje-rpo-niedzielski-kome,nId,6566428](https://wydarzenia.interia.pl/kraj/news-14-latce-odmowiono-aborcji-interweniuje-rpo-niedzielski-kome,nId,6566428)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 13:24:26+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-14-latce-odmowiono-aborcji-interweniuje-rpo-niedzielski-kome,nId,6566428"><img align="left" alt="14-latce odmówiono aborcji. Interweniuje RPO, Niedzielski komentuje" src="https://i.iplsc.com/14-latce-odmowiono-aborcji-interweniuje-rpo-niedzielski-kome/000GORDLEG49WSB8-C321.jpg" /></a>- Takie zachowanie jest nieakceptowalne - ocenił Adam Niedzielski, pytany o sprawę zgwałconej 14-latki, której lekarze odmówili aborcji, powołując się na klauzulę sumienia. Jednocześnie interweniuje Rzecznik Praw Obywatelskich. Marcin Wiącek skierował do Ministerstwa Zdrowia i Narodowego Funduszu Zdrowia pismo, w którym wskazuje na problemy związane z wykorzystaniem klauzuli sumienia.</p><br clear="all" />

## Sołowiej: Putin chce zaatakować Ukrainę na kilku frontach jednocześnie. Rosyjscy dowódcy przerażeni
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-solowiej-putin-chce-zaatakowac-ukraine-na-kilku-frontach-jed,nId,6566386](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-solowiej-putin-chce-zaatakowac-ukraine-na-kilku-frontach-jed,nId,6566386)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 13:04:33+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-solowiej-putin-chce-zaatakowac-ukraine-na-kilku-frontach-jed,nId,6566386"><img align="left" alt="Sołowiej: Putin chce zaatakować Ukrainę na kilku frontach jednocześnie. Rosyjscy dowódcy przerażeni" src="https://i.iplsc.com/solowiej-putin-chce-zaatakowac-ukraine-na-kilku-frontach-jed/000GOR6MANE4B8AP-C321.jpg" /></a>Znany z krytyki Kremla politolog twierdzi, że Władimir Putin chce, aby rosyjskie wojsko uderzyło na Ukrainę w kilku kierunkach naraz. Plany ofensywy przywódca Rosji miał ujawnić na spotkaniu z najwyższymi dowódcami armii. - Oni są przerażeni. Boją się stracić pozostałe siły zbrojne w rzezi, w którą wciąga ich rozkaz - skomentował Sołowiej. </p><br clear="all" />

## Unia chce zakazać pieców gazowych. "To nieunikniony kierunek"
 - [https://wydarzenia.interia.pl/kraj/news-unia-chce-zakazac-piecow-gazowych-to-nieunikniony-kierunek,nId,6566303](https://wydarzenia.interia.pl/kraj/news-unia-chce-zakazac-piecow-gazowych-to-nieunikniony-kierunek,nId,6566303)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 13:02:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-unia-chce-zakazac-piecow-gazowych-to-nieunikniony-kierunek,nId,6566303"><img align="left" alt="Unia chce zakazać pieców gazowych. &quot;To nieunikniony kierunek&quot;" src="https://i.iplsc.com/unia-chce-zakazac-piecow-gazowych-to-nieunikniony-kierunek/000GOQWTKQ4CCOHB-C321.jpg" /></a>Komisja Europejska chce zakazać instalowania pieców gazowych. Padają dwa kluczowe terminy: 2027 r. i 2030 r. Tymczasem w polskich domach trwa wymiana pieców węglowych na kotły gazowe. - Sprawa jest dość oczywista. Gaz jest paliwem kopalnym i też jest emisyjny, choć nieco mniej niż węgiel. Celem polityki klimatycznej UE jest odejście od wszystkich paliw kopalnych. Nie uciekniemy od kolejnych decyzji służących ograniczaniu zużycia także gazu - mówi Interii Urszula Stefanowicz z Koalicji Klimatycznej. </p><br clear="all" />

## Rosjanie zdekonspirowani pod Biełgorodem. Trzymają tam niebezpieczną broń
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-zdekonspirowani-pod-bielgorodem-trzymaja-tam-niebez,nId,6566390](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-zdekonspirowani-pod-bielgorodem-trzymaja-tam-niebez,nId,6566390)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:50:48+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-rosjanie-zdekonspirowani-pod-bielgorodem-trzymaja-tam-niebez,nId,6566390"><img align="left" alt="Rosjanie zdekonspirowani pod Biełgorodem. Trzymają tam niebezpieczną broń" src="https://i.iplsc.com/rosjanie-zdekonspirowani-pod-bielgorodem-trzymaja-tam-niebez/000GOR5WG5DF1VD5-C321.jpg" /></a>Do sieci trafiły kolejne zdjęcia tzw. białego wywiadu. Jak się okazuje, pod Biełgorodem Rosjanie mają kilka pozycji, po których przemieszczają się baterie rakiet S-300. To broń wykorzystywana zarówno przez Rosję, jak i przez Ukrainę. </p><br clear="all" />

## Opolskie: Produkowali narkotyki. Wpadli na gorącym uczynku
 - [https://wydarzenia.interia.pl/opolskie/news-opolskie-produkowali-narkotyki-wpadli-na-goracym-uczynku,nId,6566385](https://wydarzenia.interia.pl/opolskie/news-opolskie-produkowali-narkotyki-wpadli-na-goracym-uczynku,nId,6566385)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:50:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/opolskie/news-opolskie-produkowali-narkotyki-wpadli-na-goracym-uczynku,nId,6566385"><img align="left" alt="Opolskie: Produkowali narkotyki. Wpadli na gorącym uczynku" src="https://i.iplsc.com/opolskie-produkowali-narkotyki-wpadli-na-goracym-uczynku/000GOR632SSLL9HP-C321.jpg" /></a>Dziupla do wytwarzania narkotyków, przypominająca tę z serialu &quot;Breaking Bad&quot;, a w niej trzech mężczyzn - taki widok zastali policjanci z Centralnego Biura Śledczego Policji, którzy wcześniej wytypowali jedno z gospodarstw w woj. opolskim, jako miejsce, gdzie mogą powstawać syntetyczne substancje odurzające. Wśród zatrzymanych jest &quot;chemik&quot;, który zajmował się produkcją nielegalnego &quot;klefedronu&quot;. Zatrzymanym grozi do 15 lat więzienia.</p><br clear="all" />

## Alarmujące dane o próbach samobójczych dzieci i młodzieży. Padł kolejny rekord
 - [https://wydarzenia.interia.pl/kraj/news-alarmujace-dane-o-probach-samobojczych-dzieci-i-mlodziezy-pa,nId,6566246](https://wydarzenia.interia.pl/kraj/news-alarmujace-dane-o-probach-samobojczych-dzieci-i-mlodziezy-pa,nId,6566246)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:47:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-alarmujace-dane-o-probach-samobojczych-dzieci-i-mlodziezy-pa,nId,6566246"><img align="left" alt="Alarmujące dane o próbach samobójczych dzieci i młodzieży. Padł kolejny rekord" src="https://i.iplsc.com/alarmujace-dane-o-probach-samobojczych-dzieci-i-mlodziezy-pa/000GOQEXORQIAUI1-C321.jpg" /></a>Gwałtownie rośnie liczba prób samobójczych dzieci i młodzieży. W ubiegłym roku było ich 2031 - ponad dwa razy więcej niż w 2020 roku. To dane zebrane przez Fundację GrowSpace w komendach wojewódzkich policji. - Statystyki są zatrważające. Zbieramy żniwo wielu lat zaniedbań w psychoedukacji - komentuje Interii psycholożka Paulina Filipowicz. - Jako obywatele i obywatelki mamy prawo domagać się natychmiastowych działań resortów edukacji i zdrowia - dodaje aktywista Dominik Kuc. </p><br clear="all" />

## Tarnowo Podgórne: Znaleziono osiem martwych węży. Policja szuka sprawców
 - [https://wydarzenia.interia.pl/wielkopolskie/news-tarnowo-podgorne-znaleziono-osiem-martwych-wezy-policja-szuk,nId,6566349](https://wydarzenia.interia.pl/wielkopolskie/news-tarnowo-podgorne-znaleziono-osiem-martwych-wezy-policja-szuk,nId,6566349)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:27:30+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-tarnowo-podgorne-znaleziono-osiem-martwych-wezy-policja-szuk,nId,6566349"><img align="left" alt="Tarnowo Podgórne: Znaleziono osiem martwych węży. Policja szuka sprawców" src="https://i.iplsc.com/tarnowo-podgorne-znaleziono-osiem-martwych-wezy-policja-szuk/000GOR2SUP23A9D4-C321.jpg" /></a>Osiem martwych węży znalazł jeden ze spacerowiczów na leśnej drodze w Tarnowie Podgórnym. Z opinii eksperta wynika, że gady musiały zostać uduszone, dlatego sprawą zajęła się policja, która poszukuje właściciela zwierząt, ich hodowcy lub jakichkolwiek osób, które mają informacje w sprawie.</p><br clear="all" />

## Simionian o wojnie: Kiedyś mieliśmy dylemat, dziś już nie mamy wątpliwości
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-simionian-o-wojnie-kiedys-mielismy-dylemat-dzis-juz-nie-mamy,nId,6566287](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-simionian-o-wojnie-kiedys-mielismy-dylemat-dzis-juz-nie-mamy,nId,6566287)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:10:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-simionian-o-wojnie-kiedys-mielismy-dylemat-dzis-juz-nie-mamy,nId,6566287"><img align="left" alt="Simionian o wojnie: Kiedyś mieliśmy dylemat, dziś już nie mamy wątpliwości" src="https://i.iplsc.com/simionian-o-wojnie-kiedys-mielismy-dylemat-dzis-juz-nie-mamy/000FMVE6MTCACXLA-C321.jpg" /></a>Na początku &quot;specjalnej operacji&quot; mieliśmy kompleks, że walczymy z bratnimi Ukraińcami, ale dziś Zachód rozwiał nasze wątpliwości - stwierdziła Margarita Simonian - jedna z głównych proputinowskich propagandystek medialnych. Jak stwierdziła, kiedyś największym dylematem moralnym Rosjan była &quot;wojna z bratnim narodem&quot;, lecz teraz, po wielu miesiącach inwazji, ta &quot;gorycz&quot; już więcej nie ma miejsca.</p><br clear="all" />

## USA: Pożar tesli na autostradzie. Strażacy użyli ponad 22 tys. litrów wody
 - [https://wydarzenia.interia.pl/zagranica/news-usa-pozar-tesli-na-autostradzie-strazacy-uzyli-ponad-22-tys-,nId,6566288](https://wydarzenia.interia.pl/zagranica/news-usa-pozar-tesli-na-autostradzie-strazacy-uzyli-ponad-22-tys-,nId,6566288)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 12:01:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-pozar-tesli-na-autostradzie-strazacy-uzyli-ponad-22-tys-,nId,6566288"><img align="left" alt="USA: Pożar tesli na autostradzie. Strażacy użyli ponad 22 tys. litrów wody" src="https://i.iplsc.com/usa-pozar-tesli-na-autostradzie-strazacy-uzyli-ponad-22-tys/000GOQQWEYOIKAON-C321.jpg" /></a>Ponad 22 tys. litrów wody wykorzystali strażacy z Sacramento w amerykańskim stanie Kalifornia, którzy walczyli z pożarem tesli model S. Auto zapaliło się podczas jazdy autostradą. Na szczęście nikt nie został ranny. </p><br clear="all" />

## Lecieli samolotem 13 godzin. Wylądowali... w tym samym miejscu
 - [https://wydarzenia.interia.pl/zagranica/news-lecieli-samolotem-13-godzin-wyladowali-w-tym-samym-miejscu,nId,6566313](https://wydarzenia.interia.pl/zagranica/news-lecieli-samolotem-13-godzin-wyladowali-w-tym-samym-miejscu,nId,6566313)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 11:44:16+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lecieli-samolotem-13-godzin-wyladowali-w-tym-samym-miejscu,nId,6566313"><img align="left" alt="Lecieli samolotem 13 godzin. Wylądowali... w tym samym miejscu" src="https://i.iplsc.com/lecieli-samolotem-13-godzin-wyladowali-w-tym-samym-miejscu/000GOQXKXBS3YNCT-C321.jpg" /></a>Pasażerowie lotu z Dubaju do Auckland w Nowej Zelandii przeżyli spore rozczarowanie, lądując z powrotem w stolicy Zjednoczonych Emiratów Arabskich. Lot został zawrócony w połowie drogi z powodu trudnych warunków atmosferycznych w Auckland. </p><br clear="all" />

## Katowice: List pożegnalny od ofiar wybuchu. "Tabletki nasenne pozwolą nam odejść"
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-tabletki-nasenne-p,nId,6566300](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-tabletki-nasenne-p,nId,6566300)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 11:29:23+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-tabletki-nasenne-p,nId,6566300"><img align="left" alt="Katowice: List pożegnalny od ofiar wybuchu. &quot;Tabletki nasenne pozwolą nam odejść&quot;" src="https://i.iplsc.com/katowice-list-pozegnalny-od-ofiar-wybuchu-tabletki-nasenne-p/000GOQXXUP25LISG-C321.jpg" /></a>Trzy dni po eksplozji na plebanii w Katowicach do redakcji &quot;Interwencji&quot; telewizji Polsat wpłynął list, w którym wyjaśniono okoliczności zdarzenia. &quot;Nie pozostało nam nic innego jak rozszerzone samobójstwo, a tabletki nasenne pozwolą nam odejść skutecznie i po cichu&quot; - napisano w liście. Pismo podpisały trzy ofiary wybuchu, które zajmowały mieszkanie na terenie plebanii kościoła ewangelicko-augsburskiego: dwie kobiety, które zginęły i mężczyzna, który trafił do szpitala.</p><br clear="all" />

## Katowice: List pożegnalny od ofiar wybuchu. Otrzymała go "Interwencja"
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-otrzymala-go-inter,nId,6566300](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-otrzymala-go-inter,nId,6566300)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 11:29:23+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-katowice-list-pozegnalny-od-ofiar-wybuchu-otrzymala-go-inter,nId,6566300"><img align="left" alt="Katowice: List pożegnalny od ofiar wybuchu. Otrzymała go &quot;Interwencja&quot;" src="https://i.iplsc.com/katowice-list-pozegnalny-od-ofiar-wybuchu-otrzymala-go-inter/000GOQXXUP25LISG-C321.jpg" /></a>Trzy dni po eksplozji na plebanii w Katowicach do redakcji &quot;Interwencji&quot; telewizji Polsat wpłynął list, w którym wyjaśniono okoliczności zdarzenia. Jak przekazano, było to rozszerzone samobójstwo. &quot;Nie pozostało nam nic innego jak rozszerzone samobójstwo, a tabletki nasenne pozwolą nam odejść skutecznie i po cichu&quot; - napisano w liście. Pismo podpisały trzy ofiary wybuchu, które zajmowały mieszkanie na terenie plebanii: dwie kobiety, które zginęły i mężczyzna, który trafił do szpitala.</p><br clear="all" />

## Ksiądz z Bydgoszczy porównuje WOŚP do hitlerowskich Niemiec. Wymowne zdjęcie
 - [https://wydarzenia.interia.pl/kraj/news-ksiadz-z-bydgoszczy-porownuje-wosp-do-hitlerowskich-niemiec-,nId,6566283](https://wydarzenia.interia.pl/kraj/news-ksiadz-z-bydgoszczy-porownuje-wosp-do-hitlerowskich-niemiec-,nId,6566283)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 11:08:56+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-ksiadz-z-bydgoszczy-porownuje-wosp-do-hitlerowskich-niemiec-,nId,6566283"><img align="left" alt="Ksiądz z Bydgoszczy porównuje WOŚP do hitlerowskich Niemiec. Wymowne zdjęcie" src="https://i.iplsc.com/ksiadz-z-bydgoszczy-porownuje-wosp-do-hitlerowskich-niemiec/000GOQYHJTH2TX8C-C321.jpg" /></a>W niedzielę 29 stycznia odbył się 31. finał Wielkiej Orkiestry Świątecznej Pomocy. Akcja od trzech dekad cieszy się dużym poparciem ze strony społeczeństwa, ale mierzy się też z falą krytyki. Zbiórkę na WOŚP w mediach społecznościowych skrytykował m.in. znany duchowny z Bydgoszczy - Roman Kneblewski. W sprawie zamieszczonych przez duchownego treści zareagował Ośrodek Monitorowania Zachowań Rasistowskich i Ksenofobicznych.</p><br clear="all" />

## WOŚP 2023: Ile zebrano w tym roku i jakimi kwotami kończyły się wcześniejsze finały?
 - [https://wydarzenia.interia.pl/kraj/news-wosp-2023-ile-zebrano-w-tym-roku-i-jakimi-kwotami-konczyly-s,nId,6566093](https://wydarzenia.interia.pl/kraj/news-wosp-2023-ile-zebrano-w-tym-roku-i-jakimi-kwotami-konczyly-s,nId,6566093)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 11:05:24+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-wosp-2023-ile-zebrano-w-tym-roku-i-jakimi-kwotami-konczyly-s,nId,6566093"><img align="left" alt="WOŚP 2023: Ile zebrano w tym roku i jakimi kwotami kończyły się wcześniejsze finały?" src="https://i.iplsc.com/wosp-2023-ile-zebrano-w-tym-roku-i-jakimi-kwotami-konczyly-s/000GOPG2QLPU431W-C321.jpg" /></a>31. Finał Wielkiej Orkiestry Świątecznej Pomocy odbył się w niedzielę, jednak zbiórka pieniędzy wciąż trwa. Tegorocznym celem akcji jest walka z sepsą i Polacy najwyraźniej doceniają powagę sytuacji, ponieważ licznik wpłat pędzi jak szalony. Ile zebrała WOŚP podczas Finału 2023 i przez 30 lat swojego istnienia? Podajemy szczegółowe dane.</p><br clear="all" />

## Były prezydent Ukrainy: Nie doceniliście Kaczyńskiego. Zabili go Rosjanie
 - [https://wydarzenia.interia.pl/kraj/news-byly-prezydent-ukrainy-nie-doceniliscie-kaczynskiego-zabili-,nId,6566262](https://wydarzenia.interia.pl/kraj/news-byly-prezydent-ukrainy-nie-doceniliscie-kaczynskiego-zabili-,nId,6566262)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:55:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-byly-prezydent-ukrainy-nie-doceniliscie-kaczynskiego-zabili-,nId,6566262"><img align="left" alt="Były prezydent Ukrainy: Nie doceniliście Kaczyńskiego. Zabili go Rosjanie" src="https://i.iplsc.com/byly-prezydent-ukrainy-nie-doceniliscie-kaczynskiego-zabili/000GOQIC1VAT9VMH-C321.jpg" /></a>Były prezydent Ukrainy Wiktor Juszczenko wyraził przekonanie, że byłego prezydenta prof. Lecha Kaczyńskiego zabili Rosjanie. Powiedział o tym w wywiadzie dla ukraińskiego portalu Gordonua.com, w którym ocenił, że Polacy nie docenili byłego szefa swojego państwa.</p><br clear="all" />

## Dolnośląskie: Tragiczny wypadek na lokalnej drodze. Zginęła 18-latka
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-dolnoslaskie-tragiczny-wypadek-na-lokalnej-drodze-zginela-18,nId,6566235](https://wydarzenia.interia.pl/dolnoslaskie/news-dolnoslaskie-tragiczny-wypadek-na-lokalnej-drodze-zginela-18,nId,6566235)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:50:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-dolnoslaskie-tragiczny-wypadek-na-lokalnej-drodze-zginela-18,nId,6566235"><img align="left" alt="Dolnośląskie: Tragiczny wypadek na lokalnej drodze. Zginęła 18-latka" src="https://i.iplsc.com/dolnoslaskie-tragiczny-wypadek-na-lokalnej-drodze-zginela-18/000GOQJ3MXVKAOLX-C321.jpg" /></a>18-letnia pasażerka zginęła w tragicznym wypadku na lokalnej drodze w gminie Kostomłoty (woj. dolnośląskie), a 28-letni kierowca w ciężkim stanie został przetransportowany śmigłowcem do szpitala - potwierdziła w rozmowie z Interią asp. szt. Marta Stefanowska z KPP w Środzie Śląskiej. Samochód, którym podróżowali, z wciąż nieustalonych powodów zjechał z drogi i uderzył w drzewo, po czym stanął w płomieniach.</p><br clear="all" />

## Żarłacz biały odgryzł głowę nurka. Tragedia w Meksyku
 - [https://wydarzenia.interia.pl/zagranica/news-zarlacz-bialy-odgryzl-glowe-nurka-tragedia-w-meksyku,nId,6566249](https://wydarzenia.interia.pl/zagranica/news-zarlacz-bialy-odgryzl-glowe-nurka-tragedia-w-meksyku,nId,6566249)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:40:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zarlacz-bialy-odgryzl-glowe-nurka-tragedia-w-meksyku,nId,6566249"><img align="left" alt="Żarłacz biały odgryzł głowę nurka. Tragedia w Meksyku" src="https://i.iplsc.com/zarlacz-bialy-odgryzl-glowe-nurka-tragedia-w-meksyku/000GOQGLKTHW655D-C321.jpg" /></a>Mężczyzna nurkował w zatoce Tobari (zachodnie wybrzeże Meksyku) w poszukiwaniu owoców morza, gdy zaatakował go rekin. Drapieżnik odgryzł mu głowę. </p><br clear="all" />

## Czeskie media o podróży Pavla do Polski: Nadchodzi nowa era w polityce zagranicznej
 - [https://wydarzenia.interia.pl/zagranica/news-czeskie-media-o-podrozy-pavla-do-polski-nadchodzi-nowa-era-w,nId,6566243](https://wydarzenia.interia.pl/zagranica/news-czeskie-media-o-podrozy-pavla-do-polski-nadchodzi-nowa-era-w,nId,6566243)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:38:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czeskie-media-o-podrozy-pavla-do-polski-nadchodzi-nowa-era-w,nId,6566243"><img align="left" alt="Czeskie media o podróży Pavla do Polski: Nadchodzi nowa era w polityce zagranicznej " src="https://i.iplsc.com/czeskie-media-o-podrozy-pavla-do-polski-nadchodzi-nowa-era-w/000GOQGATCCODSW9-C321.jpg" /></a>Nowy prezydent Czech, zgodnie z tradycją, w pierwszą podróż zagraniczną pojedzie na Słowację. W drugiej kolejności Petr Pavel chce udać się do Polski. &quot;W polityce zagranicznej Czech nadchodzi nowa era, porównywalna do tej z czasów prezydentury Vaclava Havla&quot; - napisał komentator dziennika &quot;Hospodarzskie Noviny&quot; Martin Ehl. Jego zdaniem podróż do Polski będzie w czeskiej polityce zagranicznej absolutnym novum. </p><br clear="all" />

## Atak na zakład wojskowy w Iranie. Rosyjskie MSZ wydało oświadczenie
 - [https://wydarzenia.interia.pl/zagranica/news-atak-na-zaklad-wojskowy-w-iranie-rosyjskie-msz-wydalo-oswiad,nId,6566219](https://wydarzenia.interia.pl/zagranica/news-atak-na-zaklad-wojskowy-w-iranie-rosyjskie-msz-wydalo-oswiad,nId,6566219)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:21:48+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-atak-na-zaklad-wojskowy-w-iranie-rosyjskie-msz-wydalo-oswiad,nId,6566219"><img align="left" alt="Atak na zakład wojskowy w Iranie. Rosyjskie MSZ wydało oświadczenie" src="https://i.iplsc.com/atak-na-zaklad-wojskowy-w-iranie-rosyjskie-msz-wydalo-oswiad/000GOQDBX183SSJD-C321.jpg" /></a>&quot;Takie destrukcyjne działania mogą mieć nieprzewidywalne konsekwencja dla stabilności i pokoju na Bliskim Wschodzie&quot; - przekazało rosyjskie MSZ, odnosząc się do niedzielnego ataku dronów na zakład wojskowy w Isfahanie w Iranie. Moskwa jednocześnie potępiła atak.</p><br clear="all" />

## Spektakularne odkrycie polskich naukowców. "Zbawienna słodycz" albicydyny
 - [https://wydarzenia.interia.pl/zagranica/news-spektakularne-odkrycie-polskich-naukowcow-zbawienna-slodycz-,nId,6566216](https://wydarzenia.interia.pl/zagranica/news-spektakularne-odkrycie-polskich-naukowcow-zbawienna-slodycz-,nId,6566216)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 10:07:10+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-spektakularne-odkrycie-polskich-naukowcow-zbawienna-slodycz-,nId,6566216"><img align="left" alt="Spektakularne odkrycie polskich naukowców. &quot;Zbawienna słodycz&quot; albicydyny" src="https://i.iplsc.com/spektakularne-odkrycie-polskich-naukowcow-zbawienna-slodycz/000GOQDH8X5UVTGW-C321.jpg" /></a>Polscy naukowcy mówią o przełomie. Chodzi o badania nad albicydyną - silną toksyną roślinną - która może pomóc w walce z bakteriami. I to nie byle jakimi. Albicydyna to antybiotyk, który obecnie jest uważany za najskuteczniejszy w walce z bakteriami antybiotykoopornymi. </p><br clear="all" />

## Włamał się do kościelnej skarbony. To nie pierwsza próba 31-latka
 - [https://wydarzenia.interia.pl/news-wlamal-sie-do-koscielnej-skarbony-to-nie-pierwsza-proba-31-l,nId,6566175](https://wydarzenia.interia.pl/news-wlamal-sie-do-koscielnej-skarbony-to-nie-pierwsza-proba-31-l,nId,6566175)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 09:58:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/news-wlamal-sie-do-koscielnej-skarbony-to-nie-pierwsza-proba-31-l,nId,6566175"><img align="left" alt="Włamał się do kościelnej skarbony. To nie pierwsza próba 31-latka" src="https://i.iplsc.com/wlamal-sie-do-koscielnej-skarbony-to-nie-pierwsza-proba-31-l/000GOQ27E24FSQBB-C321.jpg" /></a>Mężczyzna użył śrubokrętu, aby włamać się do kościelnej skarbony. Jak się okazało, nie była to jego pierwsza próba. Za kradzież z włamaniem grozi mu do 10 lat pozbawienia wolności.</p><br clear="all" />

## Efekt halo w Polsce. Zjawisko uchwycono na Śnieżce
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-efekt-halo-w-polsce-zjawisko-uchwycono-na-sniezce,nId,6566209](https://wydarzenia.interia.pl/dolnoslaskie/news-efekt-halo-w-polsce-zjawisko-uchwycono-na-sniezce,nId,6566209)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 09:50:27+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-efekt-halo-w-polsce-zjawisko-uchwycono-na-sniezce,nId,6566209"><img align="left" alt="Efekt halo w Polsce. Zjawisko uchwycono na Śnieżce " src="https://i.iplsc.com/efekt-halo-w-polsce-zjawisko-uchwycono-na-sniezce/000GOQ9WUYCU8NJT-C321.jpg" /></a>W miniony weekend na niebie można było zaobserwować zjawisko nazywane efektem halo. Udało się je uchwycić ze Śnieżki - najwyższego szczytu w Karkonoszach, a spektakularne zdjęcia opublikowali w mediach społecznościowych Lubuscy Łowcy Burz.  </p><br clear="all" />

## Zamachowiec samobójca wysadził się w meczecie. 20 osób nie żyje
 - [https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-20-osob-nie-zy,nId,6566197](https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-20-osob-nie-zy,nId,6566197)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 09:36:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-20-osob-nie-zy,nId,6566197"><img align="left" alt="Zamachowiec samobójca wysadził się w meczecie. 20 osób nie żyje" src="https://i.iplsc.com/zamachowiec-samobojca-wysadzil-sie-w-meczecie-20-osob-nie-zy/000GOQ7RCM3KMHH2-C321.jpg" /></a>W meczecie w Peszawarze na północy Pakistanu zamachowiec samobójca zdetonował w poniedziałek kamizelkę z materiałami wybuchowymi, w wyniku czego co najmniej 20 osób zginęło, a 96 zostało rannych - przekazała pakistańska policja</p><br clear="all" />

## Serbowie i Chorwaci walczą w Ukrainie, lecz po różnych stronach konfliktu
 - [https://wydarzenia.interia.pl/zagranica/news-serbowie-i-chorwaci-walcza-w-ukrainie-lecz-po-roznych-strona,nId,6566143](https://wydarzenia.interia.pl/zagranica/news-serbowie-i-chorwaci-walcza-w-ukrainie-lecz-po-roznych-strona,nId,6566143)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 09:28:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-serbowie-i-chorwaci-walcza-w-ukrainie-lecz-po-roznych-strona,nId,6566143"><img align="left" alt="Serbowie i Chorwaci walczą w Ukrainie, lecz po różnych stronach konfliktu" src="https://i.iplsc.com/serbowie-i-chorwaci-walcza-w-ukrainie-lecz-po-roznych-strona/000GOQ4POHEJHTNT-C321.jpg" /></a>Serbscy i Chorwaccy ekstremiści walczą na wojnie w Ukrainie, lecz po innych stronach konfliktu. Podczas gdy Serbowie częściej zasilają szeregi grupy Wagnera, tak Chorwaci dołączają przeważnie do armii ukraińskiej. Również odmienne są motywacje bałkańskich sąsiadów, które wahają się między tradycyjnymi nastrojami prorosyjskimi a &quot;walką o białą europejską rasę&quot;. I choć władze próbują zatrzymać swoich obywateli przed werbunkiem, to ich udział jest zauważalny już od 2014 roku.</p><br clear="all" />

## GUS: Spada liczba ludności w Polsce
 - [https://wydarzenia.interia.pl/kraj/news-gus-spada-liczba-ludnosci-w-polsce,nId,6566163](https://wydarzenia.interia.pl/kraj/news-gus-spada-liczba-ludnosci-w-polsce,nId,6566163)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 09:03:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-gus-spada-liczba-ludnosci-w-polsce,nId,6566163"><img align="left" alt="GUS: Spada liczba ludności w Polsce" src="https://i.iplsc.com/gus-spada-liczba-ludnosci-w-polsce/000GOQ0CW50KWWR4-C321.jpg" /></a>Liczba ludności na koniec 2022 r. wyniosła w Polsce 37 mln 767 tys. To mniej o 141 tys. niż w 2021 r.  - wynika z najnowszych danych GUS. W 2022 r. w naszym kraju odnotowano najmniej urodzeń w całym okresie powojennym. </p><br clear="all" />

## Ambasada USA w Turcji ostrzega przed atakami terrorystycznymi. "Odwet za palenie Koranu"
 - [https://wydarzenia.interia.pl/zagranica/news-ambasada-usa-w-turcji-ostrzega-przed-atakami-terrorystycznym,nId,6566149](https://wydarzenia.interia.pl/zagranica/news-ambasada-usa-w-turcji-ostrzega-przed-atakami-terrorystycznym,nId,6566149)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:59:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ambasada-usa-w-turcji-ostrzega-przed-atakami-terrorystycznym,nId,6566149"><img align="left" alt="Ambasada USA w Turcji ostrzega przed atakami terrorystycznymi. &quot;Odwet za palenie Koranu&quot;" src="https://i.iplsc.com/ambasada-usa-w-turcji-ostrzega-przed-atakami-terrorystycznym/000GOPU43ESP7WX1-C321.jpg" /></a>Amerykańska ambasada w Turcji ostrzegła przed możliwymi atakami na kościoły, synagogi i misje dyplomatyczne w Stambule, które mogą być odwetem za demonstracje w krajach zachodnich, na których palono Koran. Podobne ostrzeżenia wystosowały ambasady Niemiec, Francji, Włoch i krajów skandynawskich.</p><br clear="all" />

## Były ambasador Niemiec ostrzega: Polskie pięć minut może się szybko skończyć
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-ambasador-niemiec-ostrzega-polskie-piec-minut-moze-sie-,nId,6566131](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-ambasador-niemiec-ostrzega-polskie-piec-minut-moze-sie-,nId,6566131)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:46:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-byly-ambasador-niemiec-ostrzega-polskie-piec-minut-moze-sie-,nId,6566131"><img align="left" alt="Były ambasador Niemiec ostrzega: Polskie pięć minut może się szybko skończyć" src="https://i.iplsc.com/byly-ambasador-niemiec-ostrzega-polskie-piec-minut-moze-sie/000GOPTIBGDHC9AM-C321.jpg" /></a>Rolf Nikel, były ambasador Niemiec w Polsce, zarzuca Warszawie, że nie wykorzystuje ona &quot;swoich pięciu minut&quot;. Dyplomata wskazuje, że polski rząd &quot;woli próbować zbić kapitał polityczny na zaistniałej sytuacji&quot;. - Zachodzi przy tym niebezpieczeństwo, że &quot;te polskie pięć minut&quot;, gdy Polska korzysta z nowego nastawienia Niemiec, miną szybciej, niż niektórzy myślą - dodaje Nikel.</p><br clear="all" />

## Zima nie powiedziała ostatniego słowa. Niż Nicolas uderzy śnieżycami
 - [https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-niz-nicolas-uderzy-sni,nId,6566152](https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-niz-nicolas-uderzy-sni,nId,6566152)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:45:33+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-niz-nicolas-uderzy-sni,nId,6566152"><img align="left" alt="Zima nie powiedziała ostatniego słowa. Niż Nicolas uderzy śnieżycami" src="https://i.iplsc.com/zima-nie-powiedziala-ostatniego-slowa-niz-nicolas-uderzy-sni/000GOPUP7UQ6NPN7-C321.jpg" /></a>Pogoda potrafi zaskoczyć w najmniej spodziewanym momencie. Jeżeli ktoś myślał, że zima to przeszłość - jest w błędzie. Wszystko to za sprawą niżu Nicolas, który do Polski sprowadzi śnieżyce, zamiecie i spadek temperatury. Według najnowszej prognozy pogody taki stan rzeczy utrzyma się w najbliższych dniach. To jednak nie koniec. Prawdziwa zima ma nadejść dopiero w lutym.</p><br clear="all" />

## Kraków: Urzędnicy kupili rower za niemal 30 tys. złotych. Zaskakujące tłumaczenie
 - [https://wydarzenia.interia.pl/malopolskie/news-krakow-urzednicy-kupili-rower-za-niemal-30-tys-zlotych-zaska,nId,6558432](https://wydarzenia.interia.pl/malopolskie/news-krakow-urzednicy-kupili-rower-za-niemal-30-tys-zlotych-zaska,nId,6558432)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:40:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-krakow-urzednicy-kupili-rower-za-niemal-30-tys-zlotych-zaska,nId,6558432"><img align="left" alt="Kraków: Urzędnicy kupili rower za niemal 30 tys. złotych. Zaskakujące tłumaczenie" src="https://i.iplsc.com/krakow-urzednicy-kupili-rower-za-niemal-30-tys-zlotych-zaska/000GOPTZHXBPM3G3-C321.jpg" /></a>Krakowscy urzędnicy z wydziału komunikacji społecznej kupili rower za 29,9 tys. zł - wynika z dokumentu, z którym zapoznała się Interia. Sprzęt ma służyć przede wszystkim do rozwożenia urzędowego czasopisma - wynika ze słów rzecznik prasowej prezydenta Jacka Majchrowskiego. Szkopuł w tym, że tylko w ciągu ostatnich kilkunastu miesięcy urzędnicy podpisali umowy na kolportaż tego samego magazynu z kilkoma innymi podmiotami i osobami. Dystrybucyjny rozmach magistratu kosztował jak dotąd blisko ćwierć miliona złotych.</p><br clear="all" />

## ISW: Opóźnienia w dostawach broni mogą uniemożliwić Ukrainie ofensywę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-opoznienia-w-dostawach-broni-moga-uniemozliwic-ukrainie-,nId,6566130](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-opoznienia-w-dostawach-broni-moga-uniemozliwic-ukrainie-,nId,6566130)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:14:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-isw-opoznienia-w-dostawach-broni-moga-uniemozliwic-ukrainie-,nId,6566130"><img align="left" alt="ISW: Opóźnienia w dostawach broni mogą uniemożliwić Ukrainie ofensywę" src="https://i.iplsc.com/isw-opoznienia-w-dostawach-broni-moga-uniemozliwic-ukrainie/000GN2U6AAOLY181-C321.jpg" /></a>Opóźnienia w dostawach zachodniego uzbrojenia i sprzętu wojskowego zdecydowały o tym, że po wyzwoleniu zachodniej części obwodu chersońskiego w listopadzie ubiegłego roku ukraińska armia nie była już w stanie przeprowadzić kolejnych operacji ofensywnych - ocenił w najnowszym raporcie amerykański Instytut Studiów nad Wojną. Think tank pisze również, że &quot;przywódcy Zachodu muszą w większym stopniu brać pod uwagę nieunikniony okres przejściowy pomiędzy decyzją o dostawach broni i jej użyciem na froncie&quot;.</p><br clear="all" />

## Ukraiński generał: Wejście NATO do Ukrainy oznacza nuklearną zagładę
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-general-wejscie-nato-do-ukrainy-oznacza-nuklearna-,nId,6566099](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-general-wejscie-nato-do-ukrainy-oznacza-nuklearna-,nId,6566099)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:11:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukrainski-general-wejscie-nato-do-ukrainy-oznacza-nuklearna-,nId,6566099"><img align="left" alt="Ukraiński generał: Wejście NATO do Ukrainy oznacza nuklearną zagładę" src="https://i.iplsc.com/ukrainski-general-wejscie-nato-do-ukrainy-oznacza-nuklearna/000GOPO714H2XHLL-C321.jpg" /></a>NATO mogłoby bardzo szybko zakończyć wojnę w Ukrainie, jednak oznaczałoby to poważne ryzyko nuklearnej zagłady ludzkości - powiedział ukraiński genernał Mykoła Małomuż. Dodał, że zachodni przywódcy są świadomi tego ryzyka, dlatego bezpośrednia konfrontacja między Sojuszem a Rosją w Ukrainie jest bardzo mało prawdopodobna.</p><br clear="all" />

## Śmierć na boisku. Dariusz Szczepaniak zmarł podczas finału WOŚP
 - [https://wydarzenia.interia.pl/wielkopolskie/news-smierc-na-boisku-dariusz-szczepaniak-zmarl-podczas-finalu-wo,nId,6566118](https://wydarzenia.interia.pl/wielkopolskie/news-smierc-na-boisku-dariusz-szczepaniak-zmarl-podczas-finalu-wo,nId,6566118)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:03:34+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-smierc-na-boisku-dariusz-szczepaniak-zmarl-podczas-finalu-wo,nId,6566118"><img align="left" alt="Śmierć na boisku. Dariusz Szczepaniak zmarł podczas finału WOŚP" src="https://i.iplsc.com/smierc-na-boisku-dariusz-szczepaniak-zmarl-podczas-finalu-wo/000GOPLO93N4JFJD-C321.jpg" /></a>W czasie 31. finału Wielkiej Orkiestry Świątecznej Pomocy doszło do tragedii. Zmarł 46-letni Dariusz Szczepaniak, trener z Ostrzeszowa. Mężczyzna zasłabł podczas meczu charytatywnego. </p><br clear="all" />

## Kontrowersyjne prawybory Konfederacji w Legnicy. "Doszło do wielu nieprawidłowości"
 - [https://wydarzenia.interia.pl/kraj/news-kontrowersyjne-prawybory-konfederacji-w-legnicy-doszlo-do-wi,nId,6566092](https://wydarzenia.interia.pl/kraj/news-kontrowersyjne-prawybory-konfederacji-w-legnicy-doszlo-do-wi,nId,6566092)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 08:01:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-kontrowersyjne-prawybory-konfederacji-w-legnicy-doszlo-do-wi,nId,6566092"><img align="left" alt="Kontrowersyjne prawybory Konfederacji w Legnicy. &quot;Doszło do wielu nieprawidłowości&quot;" src="https://i.iplsc.com/kontrowersyjne-prawybory-konfederacji-w-legnicy-doszlo-do-wi/000GOPM28Y6YBPOB-C321.jpg" /></a>Prawybory partii Nowa Nadzieja Sławomira Mentzena w Legnicy zakończyły się wzajemnymi oskarżeniami kandydatów i ich sympatyków o oszustwa. W efekcie nie wyłoniono jedynki Konfederacji w pierwszym okręgu wyborczym - na liście legnickiej. </p><br clear="all" />

## Kierowca bmw wjechał do rzeki. Samochód dachował. 31-latek był pijany
 - [https://wydarzenia.interia.pl/pomorskie/news-kierowca-bmw-wjechal-do-rzeki-samochod-dachowal-31-latek-byl,nId,6566084](https://wydarzenia.interia.pl/pomorskie/news-kierowca-bmw-wjechal-do-rzeki-samochod-dachowal-31-latek-byl,nId,6566084)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:59:13+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-kierowca-bmw-wjechal-do-rzeki-samochod-dachowal-31-latek-byl,nId,6566084"><img align="left" alt="Kierowca bmw wjechał do rzeki. Samochód dachował. 31-latek był pijany " src="https://i.iplsc.com/kierowca-bmw-wjechal-do-rzeki-samochod-dachowal-31-latek-byl/000GOPCY2N5RFSQA-C321.jpg" /></a>W miejscowości Mareza (powiat kwidzyński, województwo pomorskie) kierowca bmw wpadł do rzeki Liwa. 31-letni kierowca i 26-letni pasażer wyszli z pojazdu o własnych siłach. Jak podaje straż pożarna, byli to obcokrajowcy. Obaj byli nietrzeźwi. Kierowca miał w organizmie 1,2 promila alkoholu. </p><br clear="all" />

## Śnieżyce, zawieje i wichury do 120 km/h. Pogoda na początek tygodnia
 - [https://wydarzenia.interia.pl/kraj/news-sniezyce-zawieje-i-wichury-do-120-km-h-pogoda-na-poczatek-ty,nId,6566097](https://wydarzenia.interia.pl/kraj/news-sniezyce-zawieje-i-wichury-do-120-km-h-pogoda-na-poczatek-ty,nId,6566097)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:58:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-sniezyce-zawieje-i-wichury-do-120-km-h-pogoda-na-poczatek-ty,nId,6566097"><img align="left" alt="Śnieżyce, zawieje i wichury do 120 km/h. Pogoda na początek tygodnia" src="https://i.iplsc.com/sniezyce-zawieje-i-wichury-do-120-km-h-pogoda-na-poczatek-ty/00069COT5P94U0CP-C321.jpg" /></a>Początek tygodnia zapowiada się wietrzny, ze słabymi opadami śniegu, deszczu ze śniegiem i mżawki. Michał Folwarski, synoptyk IMGW-PIB powiedział, że temperatura maksymalna będzie utrzymywać się w okolicach zera stopni, więc na drogach może być ślisko. Jak przekazał, w poniedziałek wpływ na pogodę w kraju będzie miał niż znad Skandynawii.</p><br clear="all" />

## Rodzinny dramat w Meksyku. Pływała z córkami, nie dało się jej uratować
 - [https://wydarzenia.interia.pl/zagranica/news-rodzinny-dramat-w-meksyku-plywala-z-corkami-nie-dalo-sie-jej,nId,6566110](https://wydarzenia.interia.pl/zagranica/news-rodzinny-dramat-w-meksyku-plywala-z-corkami-nie-dalo-sie-jej,nId,6566110)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:54:40+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rodzinny-dramat-w-meksyku-plywala-z-corkami-nie-dalo-sie-jej,nId,6566110"><img align="left" alt="Rodzinny dramat w Meksyku. Pływała z córkami, nie dało się jej uratować" src="https://i.iplsc.com/rodzinny-dramat-w-meksyku-plywala-z-corkami-nie-dalo-sie-jej/000GOPMGX77FI9S8-C321.jpg" /></a>To miały być wymarzone wczasy dla rodziny z Wielkiej Brytanii. Ciepła woda, hotel i piękne plaże w rejonie Cancun w Meksyku. Niestety, rodzinną sielankę przerwała tragedia. W czasie kąpieli z córkami 38-letnia Lina Dilipkumar została porwana w głąb oceanu. Dziewczynki przeżyły, jednak dla matki nie było ratunku. </p><br clear="all" />

## Lawina w słowackich Tatrach. Nie żyje dwóch polskich wspinaczy
 - [https://wydarzenia.interia.pl/zagranica/news-lawina-w-slowackich-tatrach-nie-zyje-dwoch-polskich-wspinacz,nId,6566108](https://wydarzenia.interia.pl/zagranica/news-lawina-w-slowackich-tatrach-nie-zyje-dwoch-polskich-wspinacz,nId,6566108)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:44:08+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-lawina-w-slowackich-tatrach-nie-zyje-dwoch-polskich-wspinacz,nId,6566108"><img align="left" alt="Lawina w słowackich Tatrach. Nie żyje dwóch polskich wspinaczy" src="https://i.iplsc.com/lawina-w-slowackich-tatrach-nie-zyje-dwoch-polskich-wspinacz/000GOPKEI8ME4FU1-C321.jpg" /></a>Lawina w słowackich Tatrach porwała trzech polskich wspinaczy. Mimo szybkiej akcji ratowniczej dwóch z nich nie udało się uratować. </p><br clear="all" />

## Minister spraw zagranicznych Chin ma odwiedzić Rosję. Spotka się z Putinem
 - [https://wydarzenia.interia.pl/zagranica/news-minister-spraw-zagranicznych-chin-ma-odwiedzic-rosje-spotka-,nId,6566089](https://wydarzenia.interia.pl/zagranica/news-minister-spraw-zagranicznych-chin-ma-odwiedzic-rosje-spotka-,nId,6566089)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:19:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-minister-spraw-zagranicznych-chin-ma-odwiedzic-rosje-spotka-,nId,6566089"><img align="left" alt="Minister spraw zagranicznych Chin ma odwiedzić Rosję. Spotka się z Putinem" src="https://i.iplsc.com/minister-spraw-zagranicznych-chin-ma-odwiedzic-rosje-spotka/000GOPDMPXK1IEJI-C321.jpg" /></a>Członek Rady Państwa Chińskiej Republiki Ludowej oraz minister spraw zagranicznych Wang Yi ma odwiedzić Rosję. Polityk może spotkać się z Władimirem Putinem. Wizyta stanowi ciąg dalszy bliskich relacji pomiędzy dwoma państwami.</p><br clear="all" />

## Samoloty bojowe dla Ukrainy. Stanowcza deklaracja Olafa Scholza
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-samoloty-bojowe-dla-ukrainy-stanowcza-deklaracja-olafa-schol,nId,6566071](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-samoloty-bojowe-dla-ukrainy-stanowcza-deklaracja-olafa-schol,nId,6566071)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 07:16:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-samoloty-bojowe-dla-ukrainy-stanowcza-deklaracja-olafa-schol,nId,6566071"><img align="left" alt="Samoloty bojowe dla Ukrainy. Stanowcza deklaracja Olafa Scholza" src="https://i.iplsc.com/samoloty-bojowe-dla-ukrainy-stanowcza-deklaracja-olafa-schol/000GOPAVWS9WSA08-C321.jpg" /></a>Olaf Scholz oświadczył, że jego kraj nie przekaże Ukrainie samolotów bojowych. Przebywający z wizytą w Chile kanclerz podkreślił, że Niemcy &quot;udzieliły Ukrainie wsparcia, podobnie jak inne kraje, w postaci pomocy finansowej, humanitarnej i wojskowej&quot;. Szef niemieckiego rządu zaznaczył, że nie pozwoli, by wojna w Ukrainie przerodziła się w konflikt między Rosją a NATO. </p><br clear="all" />

## Wiceszef MSZ Rosji: Mam nadzieję na porozumienie z USA
 - [https://wydarzenia.interia.pl/zagranica/news-wiceszef-msz-rosji-mam-nadzieje-na-porozumienie-z-usa,nId,6566069](https://wydarzenia.interia.pl/zagranica/news-wiceszef-msz-rosji-mam-nadzieje-na-porozumienie-z-usa,nId,6566069)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 06:58:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wiceszef-msz-rosji-mam-nadzieje-na-porozumienie-z-usa,nId,6566069"><img align="left" alt="Wiceszef MSZ Rosji: Mam nadzieję na porozumienie z USA" src="https://i.iplsc.com/wiceszef-msz-rosji-mam-nadzieje-na-porozumienie-z-usa/000GOP6YWGKFGYIO-C321.jpg" /></a>- Potrzebujemy taktyki małych kroków, aby dojść do konsensusu w relacjach z USA - powiedział wiceminister spraw zagranicznych Rosji Siergiej Riabkow. Ponadto wskazał, że prawdopodobnie w 2026 roku porozumienie między Moskwą a Waszyngtonem w sprawie ograniczenia proliferacji broni jądrowej zakończy się. - To całkiem możliwy scenariusz - oznajmił.</p><br clear="all" />

## Chińscy naukowcy ostrzegają: Wewnętrzne jądro Ziemi zatrzymało się
 - [https://wydarzenia.interia.pl/zagranica/news-chinscy-naukowcy-ostrzegaja-wewnetrzne-jadro-ziemi-zatrzymal,nId,6566067](https://wydarzenia.interia.pl/zagranica/news-chinscy-naukowcy-ostrzegaja-wewnetrzne-jadro-ziemi-zatrzymal,nId,6566067)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 06:31:03+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chinscy-naukowcy-ostrzegaja-wewnetrzne-jadro-ziemi-zatrzymal,nId,6566067"><img align="left" alt="Chińscy naukowcy ostrzegają: Wewnętrzne jądro Ziemi zatrzymało się " src="https://i.iplsc.com/chinscy-naukowcy-ostrzegaja-wewnetrzne-jadro-ziemi-zatrzymal/000GOP79321127UN-C321.jpg" /></a>Zespół naukowców z Pekinu na podstawie badań sejsmicznych twierdzi, że wewnętrzne ziemskie jądro się zatrzymało, a być może nawet zaczyna obracać się w przeciwną stronę. Zachodzące w czasie kilku dekad spowolnienie nakłada się na zmiany w innych zachowaniach planety.</p><br clear="all" />

## Ten dodatek od państwa znany jest nielicznym. Ty też możesz dostawać 620 zł miesięcznie?
 - [https://wydarzenia.interia.pl/kraj/news-ten-dodatek-od-panstwa-znany-jest-nielicznym-ty-tez-mozesz-d,nId,6558696](https://wydarzenia.interia.pl/kraj/news-ten-dodatek-od-panstwa-znany-jest-nielicznym-ty-tez-mozesz-d,nId,6558696)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 06:20:55+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-ten-dodatek-od-panstwa-znany-jest-nielicznym-ty-tez-mozesz-d,nId,6558696"><img align="left" alt="Ten dodatek od państwa znany jest nielicznym. Ty też możesz dostawać 620 zł miesięcznie?" src="https://i.iplsc.com/ten-dodatek-od-panstwa-znany-jest-nielicznym-ty-tez-mozesz-d/000GO7PI977EG5CB-C321.jpg" /></a>Specjalny zasiłek opiekuńczy przysługuje osobom, które zrezygnowały z pracy zarobkowej, aby sprawować całodobową opiekę nad osobą z niepełnosprawnością. Wyjaśniamy, kto i w jakiej sytuacji może ubiegać się o jego przyznanie. Ile wynosi świadczenie opiekuńcze w 2023 roku? </p><br clear="all" />

## Włochy: Ksiądz udzielił ślubu cywilnego muzułmańskiej parze z Iranu
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-ksiadz-udzielil-slubu-cywilnego-muzulmanskiej-parze-z,nId,6566062](https://wydarzenia.interia.pl/zagranica/news-wlochy-ksiadz-udzielil-slubu-cywilnego-muzulmanskiej-parze-z,nId,6566062)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 06:20:48+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-ksiadz-udzielil-slubu-cywilnego-muzulmanskiej-parze-z,nId,6566062"><img align="left" alt="Włochy: Ksiądz udzielił ślubu cywilnego muzułmańskiej parze z Iranu" src="https://i.iplsc.com/wlochy-ksiadz-udzielil-slubu-cywilnego-muzulmanskiej-parze-z/000GOP6CQMYWQYL6-C321.jpg" /></a>W Genui na północy Włoch ksiądz katolicki jako reprezentant burmistrza udzielił ślubu cywilnego parze młodych Irańczyków, którzy są muzułmanami. Z panną i panem młodym połączyli się zdalnie ich rodzice i krewni, którzy nie mogą opuścić swojego kraju, gdzie trwają gwałtowne protesty i represje. - Ten ślub jest znakiem cywilizowanego postępowania, które jest konieczne za każdym razem, gdy spotykają się różne kultury, bo nie powinny nas dzielić ani kultura, ani religia, ani pochodzenie czy kraj - powiedział duchowny.</p><br clear="all" />

## Ekspert ds. klimatu przed ostrzega: Narty będą sportem dla bogaczy
 - [https://wydarzenia.interia.pl/zagranica/news-ekspert-ds-klimatu-przed-ostrzega-narty-beda-sportem-dla-bog,nId,6566056](https://wydarzenia.interia.pl/zagranica/news-ekspert-ds-klimatu-przed-ostrzega-narty-beda-sportem-dla-bog,nId,6566056)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 05:58:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ekspert-ds-klimatu-przed-ostrzega-narty-beda-sportem-dla-bog,nId,6566056"><img align="left" alt="Ekspert ds. klimatu przed ostrzega: Narty będą sportem dla bogaczy" src="https://i.iplsc.com/ekspert-ds-klimatu-przed-ostrzega-narty-beda-sportem-dla-bog/000GOP5VMJWWSB99-C321.jpg" /></a>Narciarstwo staje się sportem, na który stać tylko zamożne rodziny - mówi w rozmowie z &quot;ZDFheute&quot; badacz klimatu prof. Harald Kunstman. W jego opinii Alpy są szczególnie mocno dotknięte zmianami klimatycznymi. Najbardziej cierpią na tym tereny narciarskie położone poniżej 1500 merów nad poziomem morza, które wymagają coraz częściej sztucznego dośnieżania.</p><br clear="all" />

## Syria: Atak na konwój z irańską bronią. Są ofiary
 - [https://wydarzenia.interia.pl/zagranica/news-syria-atak-na-konwoj-z-iranska-bronia-sa-ofiary,nId,6566055](https://wydarzenia.interia.pl/zagranica/news-syria-atak-na-konwoj-z-iranska-bronia-sa-ofiary,nId,6566055)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 05:41:17+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-syria-atak-na-konwoj-z-iranska-bronia-sa-ofiary,nId,6566055"><img align="left" alt="Syria: Atak na konwój z irańską bronią. Są ofiary" src="https://i.iplsc.com/syria-atak-na-konwoj-z-iranska-bronia-sa-ofiary/000GOP4DDWJX60HH-C321.jpg" /></a>Niezidentyfikowane samoloty lub drony zaatakowały i zniszczyły we wschodniej Syrii, przy granicy z Irakiem, konwój z irańską bronią; są zabici i ranni - poinformowało w niedzielę wieczorem Syryjskie Obserwatorium Praw Człowieka. Władze w Teheranie z kolei określiły atak jako nieudany. &quot;Nie spowodował ofiar śmiertelnych, jest tylko niewielkie uszkodzenie dachu&quot; - podało tamtejsze MON.</p><br clear="all" />

## Boris Johnson: Putin groził mi uderzeniem rakietowym
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boris-johnson-putin-grozil-mi-uderzeniem-rakietowym,nId,6566051](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boris-johnson-putin-grozil-mi-uderzeniem-rakietowym,nId,6566051)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 05:16:04+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-boris-johnson-putin-grozil-mi-uderzeniem-rakietowym,nId,6566051"><img align="left" alt="Boris Johnson: Putin groził mi uderzeniem rakietowym" src="https://i.iplsc.com/boris-johnson-putin-grozil-mi-uderzeniem-rakietowym/000EFB9WBKUOT45B-C321.jpg" /></a>Władimir Putin groził Borisowi Johnsonowi uderzeniem rakietowym - stwierdził były premier Wielkiej Brytanii w filmie dokumentalnym BBC. Podczas wypowiadania swoich słów w trakcie rozmowy telefonicznej w lutym ubiegłego roku prezydent Rosji miał być bardzo zrelaksowany i pewny siebie - mówił Johnson.</p><br clear="all" />

## Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300612](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300612)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 04:38:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300612"><img align="left" alt="Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo/000GOP3D8K52SV3S-C321.jpg" /></a>Najnowsze informacje z frontu. Zapraszamy do śledzenia relacji na żywo</p><br clear="all" />

## Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300706](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300706)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 04:38:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300706"><img align="left" alt="Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo/000GOP3D8K52SV3S-C321.jpg" /></a>Najnowsze informacje z frontu. Zapraszamy do śledzenia relacji na żywo</p><br clear="all" />

## Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300803](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300803)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-30 04:38:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo,nzId,3707,akt,300803"><img align="left" alt="Wojna w Ukrainie. 341. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-341-dzien-inwazji-rosji-relacja-na-zywo/000GOP3D8K52SV3S-C321.jpg" /></a>Najnowsze informacje z frontu. Zapraszamy do śledzenia relacji na żywo</p><br clear="all" />
