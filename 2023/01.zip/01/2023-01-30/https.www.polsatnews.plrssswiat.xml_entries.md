# Source Polsat News, Source URL:https://www.polsatnews.pl/rss/swiat.xml, Source language: pl-PL

## Iran. Blogerzy tańczyli w czasie protestów. Sąd skazał ich na 10 lat więzienia
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/iran-blogerzy-tanczyli-w-czasie-protestow-sad-skazal-ich-na-10-lat-wiezienia/](https://www.polsatnews.pl/wiadomosc/2023-01-30/iran-blogerzy-tanczyli-w-czasie-protestow-sad-skazal-ich-na-10-lat-wiezienia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 20:09:00+00:00
 - user: None

10 i pół roku więzienia, zakaz prowadzenia działalności w Internecie oraz zakaz opuszczenia kraju przez dwa lata po odbyciu kary - taki wyrok usłyszała dwójka blogerów z Iranu po tym, jak opublikowali w sieci nagranie, na którym tańczą w czasie tłumienia antyrządowych protestów.

## USA. Ukradł policyjny radiowóz. Rozbił się na torach kolejowych
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ukradl-policyjny-radiowoz-rozbil-sie-na-torach-kolejowych/](https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ukradl-policyjny-radiowoz-rozbil-sie-na-torach-kolejowych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 20:04:00+00:00
 - user: None

Policja w amerykańskim stanie Georgia uratowała mężczyznę z przewróconego radiowozu na kilka sekund przed nadjechaniem pociągu. Skradziony chwilę wcześniej samochód został unieruchomiony na torach kolejowych, których nie zauważył uciekający przed pościgiem kierowca. Funkcjonariusze opublikowali wideo z dramatycznej interwencji.

## USA. Ma 130 mln fanów. Dzięki niemu tysiąc osób odzyskało wzrok
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ma-130-mln-fanow-dzieki-niemu-tysiac-osob-odzyskalo-wzrok/](https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ma-130-mln-fanow-dzieki-niemu-tysiac-osob-odzyskalo-wzrok/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 18:44:00+00:00
 - user: None

Gwiazda serwisu Youtube, MrBeast, którego kanał obserwuje 130 mln fanów, w swoim najnowszym materiale wideo pochwalił się szczytną inicjatywą - opłacił zabieg usunięcia zaćmy tysiąca niewidomych lub prawie niewidomych pacjentów, których nie stać było na operację.

## Niemcy. 23-latka chciała upozorować swoją śmierć. Zabiła sobowtórkę
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/niemcy-23-latka-chciala-upozorowac-swoja-smierc-zabila-sobowtorke/](https://www.polsatnews.pl/wiadomosc/2023-01-30/niemcy-23-latka-chciala-upozorowac-swoja-smierc-zabila-sobowtorke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 18:29:00+00:00
 - user: None

Kiedy w aucie znaleziono ciało kobiety, wyglądającej dokładnie jak Shahraban, rodzice byli przekonani, że ich 23-letnia córka nie żyje. Prawda była jednak zupełnie inna. Shahraban okazała się nie ofiarą, a sprawcą zabójstwa.

## Malediwy. Nie żyje 52-letni turysta z Polski. Podczas nurkowania potrącił go ponton
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/malediwy-nie-zyje-52-letni-turysta-z-polski-podczas-nurkowania-potracil-go-ponton/](https://www.polsatnews.pl/wiadomosc/2023-01-30/malediwy-nie-zyje-52-letni-turysta-z-polski-podczas-nurkowania-potracil-go-ponton/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 16:18:00+00:00
 - user: None

Nie żyje 52-letni turysta z Polski, który został potrącony przez ponton podczas nurkowania - podały lokalne media, powołując się na policję. Mężczyznę po wypadku przewieziono do szpitala, ale na miejscu stwierdzono zgon.

## Zoo w San Antonio pozwoli ci nazwać karalucha imieniem byłego z okazji walentynek
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/zoo-w-san-antonio-pozwoli-ci-nazwac-karalucha-imieniem-bylego-z-okazji-walentynek/](https://www.polsatnews.pl/wiadomosc/2023-01-30/zoo-w-san-antonio-pozwoli-ci-nazwac-karalucha-imieniem-bylego-z-okazji-walentynek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 14:54:00+00:00
 - user: None

Dla wszystkich nieszczęśliwie zakochanych, którzy wciąż leczą rany po nieudanym związku lub prześladuje ich imię byłego partnera, zoo w San Antonio ma rozwiązanie. Oferuje specjalne walentynkowe życzenia dla wyjątkowo uciążliwych eks, których chcemy wyrzucić z pamięci. Taki jest cel corocznej zbiórki pieniędzy wspierającej przyszłość dzikiej przyrody w Teksasie.

## Ukraińcy chcieli uciec przed mobilizacją. Jeden przebrał się za kobietę
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/ukraincy-chcieli-uciec-przed-mobilizacja-jeden-przebral-sie-za-kobiete/](https://www.polsatnews.pl/wiadomosc/2023-01-30/ukraincy-chcieli-uciec-przed-mobilizacja-jeden-przebral-sie-za-kobiete/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 14:19:00+00:00
 - user: None

Ukraińska Straż Graniczna zatrzymała trzech poborowych, którzy próbowali uciec z kraju w obawie przed pójściem do wojska. Jeden z mężczyzna wykazał się nie lada kreatywnością i aby zmylić służby przebrał się za... kobietę.

## Były prezydent Ukrainy: Jestem przekonany, że Rosjanie zabili Lecha Kaczyńskiego
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/byly-prezydent-ukrainy-jestem-przekonany-ze-rosjanie-zabili-lecha-kaczynskiego/](https://www.polsatnews.pl/wiadomosc/2023-01-30/byly-prezydent-ukrainy-jestem-przekonany-ze-rosjanie-zabili-lecha-kaczynskiego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 12:56:00+00:00
 - user: None

Były prezydent Ukrainy Wiktor Juszczenko stwierdził, że Rosjanie odpowiadają za śmierć Lecha Kaczyńskiego. - Jestem o tym przekonany - powiedział polityk w rozmowie z ukraińskimi mediami.

## USA. Ukradł radiowóz i zaczął uciekać. Nietypowe zakończenie policyjnej kontroli
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ukradl-radiowoz-i-zaczal-uciekac-nietypowe-zakonczenie-policyjnej-kontroli/](https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-ukradl-radiowoz-i-zaczal-uciekac-nietypowe-zakonczenie-policyjnej-kontroli/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 11:04:00+00:00
 - user: None

Widowiskowy pościg na ulicach Atlanty. Policjanci ścigali mężczyznę, który wykorzystał nieuwagę jednego z funkcjonariuszy i ukradł jego radiowóz. Ucieczka zakończyła się rozbiciem policyjnego auta na torach kolejowych. Pościg zamienił się w dramatyczną akcję ratunkową, gdy okazało się, że do miejsca wypadku zbliża się... pociąg.

## Iran: Atak na zakład wojskowy i konwój z bronią. MSZ Rosji reaguje
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/iran-atak-na-zaklad-wojskowy-i-konwoj-z-bronia-msz-rosji-reaguje/](https://www.polsatnews.pl/wiadomosc/2023-01-30/iran-atak-na-zaklad-wojskowy-i-konwoj-z-bronia-msz-rosji-reaguje/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 10:46:00+00:00
 - user: None

Rosja potępiła ataki na fabrykę wojskową w Iranie - przekazała agencja Reuters. Według MSZ Rosji, takie prowokacyjne działania mogą prowadzić do eskalacji napiętej już sytuacji. W niedzielę w Iranie doszło do ataku na zakład wojskowy, a w Syrii zaatakowano konwój, w którym przewożona była irańska broń.

## USA. Nie żyje Lisa Loring. Aktorka znana z "Rodziny Addamsów" zmarła w wieku 64 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-nie-zyje-lisa-loring-aktorka-znana-z-rodziny-addamsow-zmarla-w-wieku-64-lat/](https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-nie-zyje-lisa-loring-aktorka-znana-z-rodziny-addamsow-zmarla-w-wieku-64-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 09:42:00+00:00
 - user: None

Lisa Loring zagrała Wednesday Addams w klasycznej, telewizyjnej adaptacji Rodziny Addamsów z lat 60. XX wieku. Aktorka zmarła w sobotę wieczorem w Providence w szpitalu St. Joseph Medical Center z powodu komplikacji po udarze. Odeszła w spokoju, w towarzystwie obu córek - przekazały media.

## Wielka Brytania. Władimir Putin miał grozić Johnsonowi. "Zajęłoby to tylko minutę"
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/wielka-brytania-wladimir-putin-mial-grozic-johnsonowi-zajeloby-to-tylko-minute/](https://www.polsatnews.pl/wiadomosc/2023-01-30/wielka-brytania-wladimir-putin-mial-grozic-johnsonowi-zajeloby-to-tylko-minute/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 09:28:00+00:00
 - user: None

Władimir Putin groził atakiem rakietowym byłemu premierowi Wielkiej Brytanii Borisowi Johnsonowi przed rozpoczęciem inwazji na Ukrainę w lutym ubiegłego roku - wynika z wypowiedzi Johnsona dla BBC. - Myślę, że Putin bawił się moimi próbami skłonienia go do negocjacji - powiedział Johnson.

## Pakistan. Potężny wybuch w meczecie. Jest co najmniej kilkadziesiąt ofiar
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/pakistan-potezny-wybuch-w-meczecie-jest-co-najmniej-kilkudziesieciu-rannych/](https://www.polsatnews.pl/wiadomosc/2023-01-30/pakistan-potezny-wybuch-w-meczecie-jest-co-najmniej-kilkudziesieciu-rannych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 09:23:00+00:00
 - user: None

W poniedziałek w meczecie w północno-zachodnim mieście Peszawar w Pakistanie doszło do eksplozji. W wybuchu zginęło co najmniej 20 osób. A 96 osób zostało rannych - przekazała agencja AP. Stan niektórych z nich jest krytyczny. Jak przekazały służby, kilka osób może być uwięzionych pod zawaloną ścianą budynku.

## USA. Tragiczny finał policyjnego pościgu. Nie żyje trzech młodych mężczyzn
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-tragiczny-final-policyjnego-poscigu-nie-zyje-trzech-mlodych-mezczyzn/](https://www.polsatnews.pl/wiadomosc/2023-01-30/usa-tragiczny-final-policyjnego-poscigu-nie-zyje-trzech-mlodych-mezczyzn/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 08:46:00+00:00
 - user: None

Trzej młodzi mężczyźni zginęli w wypadku samochodowym, do którego doszło podczas policyjnego pościgu. Samochód którym uciekali wypadł z drogi i zapalił się.

## Annie Wersching nie żyje. Aktorka miała 45 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/nie-zyje-annie-wersching-aktorka-miala-45-lat/](https://www.polsatnews.pl/wiadomosc/2023-01-30/nie-zyje-annie-wersching-aktorka-miala-45-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 08:32:00+00:00
 - user: None

Annie Wersching znana z ról w filmie Bruce Wszechmogący, serialach Pamiętniki z wampirów i 24 godziny oraz roli Tess w grze The Last of Us zmarła w niedzielę rano w Kalifornii. Aktorka chorowała na nowotwór. Miała 45 lat.

## Australia. Mężczyzna zmarł w wyniku ukąszenia węża. Ratownicy nie zdążyli mu pomóc
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/australia-mezczyzna-zmarl-w-wyniku-ukaszenia-weza-ratownicy-nie-zdazyli-mu-pomoc/](https://www.polsatnews.pl/wiadomosc/2023-01-30/australia-mezczyzna-zmarl-w-wyniku-ukaszenia-weza-ratownicy-nie-zdazyli-mu-pomoc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 07:59:00+00:00
 - user: None

60-letni ojciec dwójki dzieci został ukąszony przez jadowitego węża. Mężczyzna zmarł przed przyjazdem karetki pogotowia. Jak uważają służby, ofiara została ugryziona przez jeden z najbardziej jadowitych gatunków węża na świecie.

## RPA: Strzelanina na przyjęciu urodzinowym. Nie żyje osiem osób
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/rpa-strzelanina-na-przyjeciu-urodzinowym-nie-zyje-osiem-osob/](https://www.polsatnews.pl/wiadomosc/2023-01-30/rpa-strzelanina-na-przyjeciu-urodzinowym-nie-zyje-osiem-osob/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 07:48:00+00:00
 - user: None

Nieznani napastnicy otworzyli ogień do ludzi bawiących się na przyjęciu urodzinowym w mieście Gqeberha w Republice Południowej Afryki. Zabili osiem osób, a ranili trzy.

## Słowacja. Lawina w Tatrach. Nie żyje dwóch polskich wspinaczy
 - [https://www.polsatnews.pl/wiadomosc/2023-01-30/lawina-w-tatrach-nie-zyje-dwoch-polskich-wspinaczy/](https://www.polsatnews.pl/wiadomosc/2023-01-30/lawina-w-tatrach-nie-zyje-dwoch-polskich-wspinaczy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-30 07:28:00+00:00
 - user: None

Lawina, która zeszła w słowackich Tatrach porwała trzech polskich wspinaczy. Dwóch z nich nie udało się uratować - poinformowali ratownicy z Horskiej Zachrannej Służby (HZS).
