# Source CodeProject, Source URL:https://www.codeproject.com/WebServices/NewsRSS.aspx, Source language: en-US

## Google created an AI that can generate music from text descriptions, but won’t release it
 - [https://techcrunch.com/2023/01/27/google-created-an-ai-that-can-generate-music-from-text-descriptions-but-wont-release-it/](https://techcrunch.com/2023/01/27/google-created-an-ai-that-can-generate-music-from-text-descriptions-but-wont-release-it/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

Kraftwerk welcomes the competition

## Massive Microsoft 365 outage caused by WAN router IP change
 - [https://www.bleepingcomputer.com/news/microsoft/massive-microsoft-365-outage-caused-by-wan-router-ip-change/](https://www.bleepingcomputer.com/news/microsoft/massive-microsoft-365-outage-caused-by-wan-router-ip-change/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

Which explains why it took five hours to change the setting back?

## Report: OpenAI hired 1,000 contractors to improve its AI models’ coding capabilities
 - [https://siliconangle.com/2023/01/27/report-openai-hired-1000-contractors-improve-ai-models-coding-capabilities/](https://siliconangle.com/2023/01/27/report-openai-hired-1000-contractors-improve-ai-models-coding-capabilities/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

How many programmers does it take to fix the code it generates?

## The biggest blocker to DevSecOps? Security teams and devs not getting on: Report
 - [https://devclass.com/2023/01/26/devsecops-report/](https://devclass.com/2023/01/26/devsecops-report/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

They started it!

## The developer ecosystem in 2022: Key trends for C#
 - [https://blog.jetbrains.com/dotnet/2023/01/26/the-developer-ecosystem-in-2022-key-trends-for-c/](https://blog.jetbrains.com/dotnet/2023/01/26/the-developer-ecosystem-in-2022-key-trends-for-c/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

You are here: 2022 edition

## What programmers say
 - [https://www.codeproject.com/Messages/5923213/What-programmers-say](https://www.codeproject.com/Messages/5923213/What-programmers-say)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

You know you might be a programmer if...

## What tips can you give to increase the effectiveness of remote meetings?
 - [https://www.codeproject.com/Messages/5923232/What-tips-can-you-give-to-increase-the-effectivene](https://www.codeproject.com/Messages/5923232/What-tips-can-you-give-to-increase-the-effectivene)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

What's on the agenda?

## Windows 11 will auto-update version 21H2 users to 22H2, here's everything new coming to your PC
 - [https://www.windowscentral.com/software-apps/windows-11/microsoft-begins-automatically-updating-windows-11-version-21h2-users-to-version-22h2](https://www.windowscentral.com/software-apps/windows-11/microsoft-begins-automatically-updating-windows-11-version-21h2-users-to-version-22h2)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

We heard you like rebooting your computer

## Workers want more AI to get rid of their office busywork, says Microsoft survey
 - [https://www.zdnet.com/home-and-office/work-life/workers-want-more-ai-to-get-rid-of-their-office-busywork-says-microsoft-survey/](https://www.zdnet.com/home-and-office/work-life/workers-want-more-ai-to-get-rid-of-their-office-busywork-says-microsoft-survey/)
 - RSS feed: https://www.codeproject.com/WebServices/NewsRSS.aspx
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

Everyone wants a big red button to do their job (until it does their job)
