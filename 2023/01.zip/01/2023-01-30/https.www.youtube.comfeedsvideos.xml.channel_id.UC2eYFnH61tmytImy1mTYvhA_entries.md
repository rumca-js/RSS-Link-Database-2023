# Source Luke Smith - YouTube, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA, Source language: en-US

## Globalism, Dystopia & Crypto ｜ Luke Smith on Monero Magazine
 - [https://www.youtube.com/watch?v=WNhvPLKIWsQ](https://www.youtube.com/watch?v=WNhvPLKIWsQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2eYFnH61tmytImy1mTYvhA
 - date published: 2023-01-30 17:00:21+00:00
 - user: None

https://www.youtube.com/@moneromagazine/videos

00:00 – 00:04 Welcome, Luke
00:04 – 01:02 Funniest WiFi Name
01:02 – 09:40 History of Globalism & Elitism 
09:40 – 14:00 When Was The Idea Of Freedom Lost?
14:00 – 23:02 Future Tools of Globalism
23:02 – 26:08 Crypto’s Role In Dystopia?
26:08 - 28:42 Bitcoin or Monero?

I went on Monero Magazine. For some reason my audio was terrible though lol! I had my microphone, but it must not've been the default input!

My website: https://lukesmith.xyz
Classical books reprinted by me: https://lindypress.net
Get all my videos off YouTube: https://videos.lukesmith.xyz
or Odysee: https://odysee.com/$/invite/@Luke:7

Please donate: https://donate.lukesmith.xyz
BTC: bc1qd20r7phdct3t0e0z6jqs55ulectg25pngt7hyl
XMR: 89yML3AtqnTNdo3wNuoaW44D94Zx1kBZNSBc9SyNxGdaKEZwZNdVzvy9zpbzJMzysiWZEU3b5LwjQ3XwWuQsknCF8JK73yv

OR affiliate links to things l use:
https://www.vultr.com/?ref=8384069-6G Get a VPS and host a website or server for anything else.
https://www.epik.com/?affid=we2ro7sa6 Get a cheap and reliable domain name with Epik.
