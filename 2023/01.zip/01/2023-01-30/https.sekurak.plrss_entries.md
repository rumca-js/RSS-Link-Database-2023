# Source Sekurak, Source URL:https://sekurak.pl/rss, Source language: pl-PL

## Podsumowanie cyber-wydarzeń stycznia
 - [https://sekurak.pl/podsumowanie-cyber-wydarzen-stycznia/](https://sekurak.pl/podsumowanie-cyber-wydarzen-stycznia/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-30 17:42:02+00:00
 - user: None

<p>Poniżej subiektywny wybór newsów / ciekawostek / ostrzeżeń, które publikowaliśmy w styczniu 2023r. na sekuraku. Jeśli podoba się Wam zestawienie &#8211; podeślijcie linka znajomym oraz koniecznie dajcie znać w komentarzu. Jeśli Wasz odzew będzie pozytywny &#8211; będziemy kontynuować tego typu zestawienia (częściej niż raz na miesiąc :-) SEKURAK (scamy, ciekawostki,...</p>
<p>Artykuł <a href="https://sekurak.pl/podsumowanie-cyber-wydarzen-stycznia/" rel="nofollow">Podsumowanie cyber-wydarzeń stycznia</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Przeoczyłeś malutką kropkę w adresie? Możesz wylądować na stronie-scamie, a Chrome tym razem Cię nie ochroni
 - [https://sekurak.pl/przeoczyles-malutka-kropke-w-adresie-mozesz-wyladowac-na-stronie-scamie-a-chrome-tym-razem-cie-nie-ochroni/](https://sekurak.pl/przeoczyles-malutka-kropke-w-adresie-mozesz-wyladowac-na-stronie-scamie-a-chrome-tym-razem-cie-nie-ochroni/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-30 16:08:35+00:00
 - user: None

<p>Być może pamiętacie scamy które opisywaliśmy w kontekście prób ataków na klientów mBanku: Uważne oko dostrzeże w adresie kropkę lub przecinek (więcej o temacie: punycode). Tymczasem zobaczcie na ten (cały czas aktywny) scam, próbujący nabrać użytkowników Ledgera: Wprawne oko wykrywacza scamów wyłapie dziwną literę i w adresie powyżej. Nieco dokładniej...</p>
<p>Artykuł <a href="https://sekurak.pl/przeoczyles-malutka-kropke-w-adresie-mozesz-wyladowac-na-stronie-scamie-a-chrome-tym-razem-cie-nie-ochroni/" rel="nofollow">Przeoczyłeś malutką kropkę w adresie? Możesz wylądować na stronie-scamie, a Chrome tym razem Cię nie ochroni</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>
