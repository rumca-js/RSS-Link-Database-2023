# Source Financial Times World, Source URL:https://www.ft.com/world?format=rss, Source language: en-US

## FirstFT: US halts licences in latest broadside against Huawei
 - [https://www.ft.com/content/70877867-ed97-40bc-ae7f-7356ee6cfc6a](https://www.ft.com/content/70877867-ed97-40bc-ae7f-7356ee6cfc6a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 21:39:40+00:00
 - user: None

Also in today’s newsletter, interest rates set for 15-year highs and Twitter pays first $300mn interest bill

## Washington halts licences for US companies to export to Huawei
 - [https://www.ft.com/content/23433f43-8d81-4a24-9373-fc0ac18f948a](https://www.ft.com/content/23433f43-8d81-4a24-9373-fc0ac18f948a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 20:30:15+00:00
 - user: None

White House moving closer to imposing total ban on sale of American tech to Chinese company

## Sunak insists he can restore integrity to politics after Zahawi affair
 - [https://www.ft.com/content/3f6dcb69-8614-4823-9d0f-3b841f2f150a](https://www.ft.com/content/3f6dcb69-8614-4823-9d0f-3b841f2f150a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 19:55:19+00:00
 - user: None

Labour accuses UK PM of procrastination as new polling suggests his popularity is waning

## Tribunal finds ‘serious failings’ by UK security agency over privacy safeguards
 - [https://www.ft.com/content/e3533128-90f4-4746-a419-a025ee2728be](https://www.ft.com/content/e3533128-90f4-4746-a419-a025ee2728be)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 19:07:27+00:00
 - user: None

Judges rule shortcomings ‘ought to have been addressed urgently’ by MI5’s board and Home Office

## UK firefighters union votes for industrial action over pay
 - [https://www.ft.com/content/29f9ca86-006f-4c28-b0ae-512b072882e5](https://www.ft.com/content/29f9ca86-006f-4c28-b0ae-512b072882e5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:54:02+00:00
 - user: None

Strike dates will be set if government and employers do not make ‘credible offer’ in next 10 days

## Adani affair is a test for India Inc
 - [https://www.ft.com/content/8157b75d-67a9-4307-ba21-6b6409dbab1d](https://www.ft.com/content/8157b75d-67a9-4307-ba21-6b6409dbab1d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:22:55+00:00
 - user: None

Allegations from a New York financial firm have knocked $70bn off companies’ values

## Push into illiquid assets exposes UK pension savers to higher fees
 - [https://www.ft.com/content/6cb12c6c-0c5a-485a-b185-b91341875c47](https://www.ft.com/content/6cb12c6c-0c5a-485a-b185-b91341875c47)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:15:37+00:00
 - user: None

Government presses ahead with plans to funnel scheme funds into infrastructure and start ups

## China’s return to work raises hopes for global growth
 - [https://www.ft.com/content/2dc5c693-d348-48db-9705-484a98868590](https://www.ft.com/content/2dc5c693-d348-48db-9705-484a98868590)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:15:35+00:00
 - user: None

Also in this newsletter: German economy shrinks unexpectedly, big week for central banks and the EU’s ‘Qatargate’ scandal

## Countries urged to help children catch up on education lost during pandemic
 - [https://www.ft.com/content/e4420427-d3ad-45f9-9d4e-14db1eaba233](https://www.ft.com/content/e4420427-d3ad-45f9-9d4e-14db1eaba233)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:12:28+00:00
 - user: None

Report says focus must be maintained on tackling ‘learning deficits’ caused by shutdown of classes

## Goldman transferred privately held Russian assets to former employees
 - [https://www.ft.com/content/69b7afc8-f212-40f0-8dda-05d70b71e899](https://www.ft.com/content/69b7afc8-f212-40f0-8dda-05d70b71e899)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:10:28+00:00
 - user: None

Western banks are exiting the country following the invasion of Ukraine

## Jair Bolsonaro seeks six-month US tourist visa to extend Florida stay
 - [https://www.ft.com/content/914b9d07-49a6-4133-84ac-f22e2eff803d](https://www.ft.com/content/914b9d07-49a6-4133-84ac-f22e2eff803d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 18:09:50+00:00
 - user: None

Former Brazilian president is facing multiple investigations at home

## Only an IMF bailout can save Pakistan now
 - [https://www.ft.com/content/53397013-7a94-470e-ab46-ffe0ed73c1d9](https://www.ft.com/content/53397013-7a94-470e-ab46-ffe0ed73c1d9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 17:39:09+00:00
 - user: None

Without immediate help, the debt-ridden country will follow in Sri Lanka’s footsteps

## Sturgeon criticised for ‘botched’ policy on transgender prisoners
 - [https://www.ft.com/content/9ca38e1b-c9b0-46da-9d3c-59709fa5ef5f](https://www.ft.com/content/9ca38e1b-c9b0-46da-9d3c-59709fa5ef5f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 16:54:35+00:00
 - user: None

Controversy over Edinburgh’s gender reforms deepens after fresh concerns about protection of female-only spaces

## Spanish PM Pedro Sánchez under fire over release of sex offenders
 - [https://www.ft.com/content/dd84903c-3565-4239-8d16-a22f0bc57412](https://www.ft.com/content/dd84903c-3565-4239-8d16-a22f0bc57412)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 16:12:37+00:00
 - user: None

Sexual consent law backfires on government but supporters blame judges for applying it incorrectly

## Up to £2bn of England’s apprenticeship levy used on management training
 - [https://www.ft.com/content/691face9-9758-4487-ba04-a5ba40f531dc](https://www.ft.com/content/691face9-9758-4487-ba04-a5ba40f531dc)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 14:30:27+00:00
 - user: None

Executives are benefiting from funds at the expense of younger recruits, finds CIPD research

## How quantitative tightening *really* works
 - [https://www.ft.com/content/c9ccd19c-14dc-4b15-8a21-126a36fdc1d6](https://www.ft.com/content/c9ccd19c-14dc-4b15-8a21-126a36fdc1d6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 13:44:04+00:00
 - user: None

The world according to BEAPFF

## Three ways to read the ‘deglobalisation’ debate
 - [https://www.ft.com/content/b3f41263-88d9-4012-aafc-145f0327678f](https://www.ft.com/content/b3f41263-88d9-4012-aafc-145f0327678f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 13:27:36+00:00
 - user: None

Proponents of business as usual and the new cold warriors are too confident of their ability to predict the future

## Teachers’ strike exposes the deficiencies in Britain’s education system
 - [https://www.ft.com/content/7d42647e-48f4-46db-a261-13182c99cfc9](https://www.ft.com/content/7d42647e-48f4-46db-a261-13182c99cfc9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:56:38+00:00
 - user: None

Achievement, attendance and recruitment levels have failed to recover from Covid’s battering

## European stocks and US futures dip ahead of interest rate decisions
 - [https://www.ft.com/content/8b5a864b-8d12-4803-8ad7-640fc62c6058](https://www.ft.com/content/8b5a864b-8d12-4803-8ad7-640fc62c6058)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:46:00+00:00
 - user: None

Fed expected to raise rates by 0.25 percentage points and the BoE and ECB by half a percentage point this week

## Sunak defends plan to tackle NHS crisis
 - [https://www.ft.com/content/7ad5472d-6f2e-4d95-a244-a44b2d51c669](https://www.ft.com/content/7ad5472d-6f2e-4d95-a244-a44b2d51c669)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:41:15+00:00
 - user: None

Prime minister promises ‘largest and fastest-ever improvement’ in emergency waiting times in NHS history

## EU to relax curbs on tax credits in response to US green subsidies
 - [https://www.ft.com/content/53eb769b-6ce1-4f50-9703-f2463c465001](https://www.ft.com/content/53eb769b-6ce1-4f50-9703-f2463c465001)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:33:43+00:00
 - user: None

Covid recovery funds could also be redirected under proposed loosening of state aid rules, according to draft plan

## Sovereign default problems that haven’t found a fix
 - [https://www.ft.com/content/9d9b0754-2e54-42c4-b370-2de7d153bd77](https://www.ft.com/content/9d9b0754-2e54-42c4-b370-2de7d153bd77)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:31:35+00:00
 - user: None

Zambia’s landmark debt restructuring delayed by fundamental discord between China and other creditors

## How the war in Ukraine met the war on woke
 - [https://www.ft.com/content/8e8d0f8e-dd29-41c4-80a6-90bd3676208b](https://www.ft.com/content/8e8d0f8e-dd29-41c4-80a6-90bd3676208b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:29:35+00:00
 - user: None

Vladimir Putin has found friends in the west by posing as a defender of traditional values

## Iran’s dissidents offer a new template for martyrdom
 - [https://www.ft.com/content/d2a81b79-5839-4e22-8719-5e6c0ed2ecbb](https://www.ft.com/content/d2a81b79-5839-4e22-8719-5e6c0ed2ecbb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:17:01+00:00
 - user: None

Protesters have shown the regime they are also willing to die for a cause — but this time it’s not religion

## Alice Diop on her film Saint Omer: ‘It questions the complexity of the maternal bond’
 - [https://www.ft.com/content/9b50bb07-24c2-4b86-8685-ff9ba787a2d5](https://www.ft.com/content/9b50bb07-24c2-4b86-8685-ff9ba787a2d5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 12:00:35+00:00
 - user: None

The director discusses dramatising the trial of a woman who left her child to die — and why it reflects ‘a very French form of racism’

## Passive owners, active lobbyists?
 - [https://www.ft.com/content/25505201-ec56-4756-92b1-b5027b066d6d](https://www.ft.com/content/25505201-ec56-4756-92b1-b5027b066d6d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 11:39:13+00:00
 - user: None

It’s not what you pay, it’s what you own

## Fed set to signal plans to keep raising rates even as inflation eases
 - [https://www.ft.com/content/7fffc75f-3130-49a1-8067-91d362d85eb2](https://www.ft.com/content/7fffc75f-3130-49a1-8067-91d362d85eb2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 11:00:35+00:00
 - user: None

US central bank officials expected to shift down to quarter-point rise at first gathering of the year

## Swedish and Finnish Nato bids may be treated ‘separately’, Turkey warns
 - [https://www.ft.com/content/5b0286ad-5139-4fb7-9bf1-64858e40519d](https://www.ft.com/content/5b0286ad-5139-4fb7-9bf1-64858e40519d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 10:39:24+00:00
 - user: None

Relations between Ankara and Stockholm have worsened since a rightwing activist set fire to a Koran in the Swedish capital

## Property developers told to commit to £2bn UK repair scheme
 - [https://www.ft.com/content/cf286c56-c49b-403e-ba76-27f7fe262063](https://www.ft.com/content/cf286c56-c49b-403e-ba76-27f7fe262063)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 10:28:40+00:00
 - user: None

Companies have six weeks to sign up or face ‘serious consequences’

## Zahawi saga exposes weak links in UK legal and tax systems
 - [https://www.ft.com/content/72b54714-db8c-4e57-8df0-18c9bea28bc8](https://www.ft.com/content/72b54714-db8c-4e57-8df0-18c9bea28bc8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 09:30:35+00:00
 - user: None

Sacking puts Sunak’s political judgment under scrutiny, amid consistently bleak opinion polls for him and Tories

## German economy shrinks as energy and borrowing costs pinch demand
 - [https://www.ft.com/content/dc978c84-64c4-42cd-bfe5-7d59e1441475](https://www.ft.com/content/dc978c84-64c4-42cd-bfe5-7d59e1441475)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 09:28:47+00:00
 - user: None

Unexpected fourth-quarter contraction shows how hard manufacturing has been hit

## 888 chief leaves as online betting group launches VIP accounts probe
 - [https://www.ft.com/content/a460b288-c5c3-41b4-bd5f-6e8bdc2a2b4a](https://www.ft.com/content/a460b288-c5c3-41b4-bd5f-6e8bdc2a2b4a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 08:52:02+00:00
 - user: None

Several customer accounts in the Middle East suspended following investigation into suspected money laundering

## Renault and Nissan shake up alliance with equal shares and EV deal
 - [https://www.ft.com/content/4c87905b-d9a0-4aae-b276-3f1358c75dce](https://www.ft.com/content/4c87905b-d9a0-4aae-b276-3f1358c75dce)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 08:36:02+00:00
 - user: None

Carmakers will hold 15% in each other and work on new joint projects

## Ryanair on track for ‘strong’ summer as airline swings to profit
 - [https://www.ft.com/content/169d857b-708f-4f71-9a16-75793c492828](https://www.ft.com/content/169d857b-708f-4f71-9a16-75793c492828)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 07:36:35+00:00
 - user: None

Low-cost carrier predicts rush of US and Asian tourists will boost demand for travel in Europe

## Nato chief calls on South Korea to provide military aid to Ukraine
 - [https://www.ft.com/content/68417c45-3f3c-4162-8cd4-5111de03884a](https://www.ft.com/content/68417c45-3f3c-4162-8cd4-5111de03884a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 06:47:16+00:00
 - user: None

Jens Stoltenberg cites Kyiv’s ‘urgent’ need for ammunition during trip to deepen ties with Seoul and Tokyo

## Industrial policy is so hot right now
 - [https://www.ft.com/content/98ee1141-46e9-4212-83b8-24c8bc4151e2](https://www.ft.com/content/98ee1141-46e9-4212-83b8-24c8bc4151e2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 06:30:35+00:00
 - user: None

Lord make me a free-marketer, but not yet

## How the EU fought back against Moscow in the food crisis blame game
 - [https://www.ft.com/content/50e62622-4df6-49a1-ba38-d0154b368b69](https://www.ft.com/content/50e62622-4df6-49a1-ba38-d0154b368b69)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 06:00:35+00:00
 - user: None

Also in this newsletter: yet another election in seemingly ungovernable Bulgaria

## Shares of Adani Group’s flagship company rise after sell-off
 - [https://www.ft.com/content/ccf85bcd-7cdd-4255-b51c-eb798c156f45](https://www.ft.com/content/ccf85bcd-7cdd-4255-b51c-eb798c156f45)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:20:09+00:00
 - user: None

Indian conglomerate pushes ahead with $2.4bn follow-on sale set to close on Tuesday

## Blackstone steps up tenant evictions in US with eye on boosting returns
 - [https://www.ft.com/content/5ac750a5-c454-485d-8974-17627c47ea20](https://www.ft.com/content/5ac750a5-c454-485d-8974-17627c47ea20)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Hundreds affected as one of biggest US landlords calls time on long period of pandemic forbearance

## Central banks prepare to lift rates to 15-year highs as investors’ jitters grow
 - [https://www.ft.com/content/ef8452ca-f7bb-499f-a67f-51b13a5ad76c](https://www.ft.com/content/ef8452ca-f7bb-499f-a67f-51b13a5ad76c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Concern that bond market rally underestimates growing evidence of persistent inflation

## Crypto ETFs roar into life with eye-popping 2023 returns
 - [https://www.ft.com/content/93b77a70-42cf-4c6c-943e-842b70984720](https://www.ft.com/content/93b77a70-42cf-4c6c-943e-842b70984720)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Rebound has extended to tech funds such as ARKK, which has risen 25% this year

## Meloni is making it harder for NGOs to rescue migrants lost at sea
 - [https://www.ft.com/content/3fef71fc-01ef-4925-be85-bc8ea52cd31d](https://www.ft.com/content/3fef71fc-01ef-4925-be85-bc8ea52cd31d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

New Italian protocols aim to stem flow of people while avoiding another Ocean Viking-type row

## Putin vs the West — world leaders face up to failures to stop Russian aggression
 - [https://www.ft.com/content/1403c53e-18a1-4745-bc4f-444e1070c27a](https://www.ft.com/content/1403c53e-18a1-4745-bc4f-444e1070c27a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Norma Percy’s documentary takes a high-level look at European diplomacy with Russia’s president

## Running in London with the world’s oldest cross-country club
 - [https://www.ft.com/content/52400e96-4608-4b78-bfa0-a42c9abdfe0e](https://www.ft.com/content/52400e96-4608-4b78-bfa0-a42c9abdfe0e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Dating back to 1868, Thames Hare and Hounds is one of several running clubs in the capital with a long and colourful heritage. Our correspondent set off with them across Wimbledon Common

## Spain’s biggest banks prepare to challenge windfall tax
 - [https://www.ft.com/content/64c3fccb-ff6d-4501-a4cf-a8c4147ea52d](https://www.ft.com/content/64c3fccb-ff6d-4501-a4cf-a8c4147ea52d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Lenders say they will make the first payment due next month but are ready for legal action

## The growing tensions around spinouts at British universities
 - [https://www.ft.com/content/a2cb4877-c50e-4353-a697-cd5343eaae2d](https://www.ft.com/content/a2cb4877-c50e-4353-a697-cd5343eaae2d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Millions of pounds are being invested to turn scientific research into global companies. But some founders say they have to give up too much equity

## The real cost of shadow work
 - [https://www.ft.com/content/c2913c55-b9f5-44fa-b6dc-7cd7a2659925](https://www.ft.com/content/c2913c55-b9f5-44fa-b6dc-7cd7a2659925)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Calculating its full economic impact could help us understand productivity and employment issues

## UK braces for biggest day of strikes this winter
 - [https://www.ft.com/content/5308851a-fff5-436f-8f0a-8c84d74fcc7b](https://www.ft.com/content/5308851a-fff5-436f-8f0a-8c84d74fcc7b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Workers from rail, teaching and university sectors to walk out on February 1 in co-ordinated action over pay

## UK dividends forecast to shrink in 2023
 - [https://www.ft.com/content/f983434c-dbec-425b-8f20-e20ec5fa74b6](https://www.ft.com/content/f983434c-dbec-425b-8f20-e20ec5fa74b6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

Payouts likely to fall as company margins come under pressure

## What’s behind the strange phenomenon of Havana syndrome? — podcast review
 - [https://www.ft.com/content/080e93b4-013b-47f2-95c9-9ac3473a271b](https://www.ft.com/content/080e93b4-013b-47f2-95c9-9ac3473a271b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 05:00:47+00:00
 - user: None

The neurological disturbance which afflicted US diplomats is the subject of two new series

## Mongolia reels from impact of Russian sanctions
 - [https://www.ft.com/content/21a51801-6bc6-4fda-a38d-0653605c0d88](https://www.ft.com/content/21a51801-6bc6-4fda-a38d-0653605c0d88)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:30:46+00:00
 - user: None

Prime minister of landlocked democracy complains of blow to his country’s economy

## ‘High expectations’: What China’s reopening means for markets
 - [https://www.ft.com/content/89e8e569-7f5f-40a4-bf2a-4fd651663895](https://www.ft.com/content/89e8e569-7f5f-40a4-bf2a-4fd651663895)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:30:46+00:00
 - user: None

As the country exits its first Covid-19 wave, traders are betting on a surge in demand

## Live news: Oil prices rise as China returns to work after lunar new year break
 - [https://www.ft.com/content/237864f5-f0ba-4e59-a2fa-83a312e4522e](https://www.ft.com/content/237864f5-f0ba-4e59-a2fa-83a312e4522e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:21:05+00:00
 - user: None



## UK sets out plans to raise disclosure standards for pensions industry
 - [https://www.ft.com/content/e5bcfc87-6874-430e-8456-3225c8be8853](https://www.ft.com/content/e5bcfc87-6874-430e-8456-3225c8be8853)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:05:00+00:00
 - user: None

Value-for-money test proposals will affect millions of retirement savers

## Lobby group calls for slimming down of UK’s ‘door-stopper’ annual reports
 - [https://www.ft.com/content/39b61879-341f-48b0-97d9-ed7fe9bbf0d2](https://www.ft.com/content/39b61879-341f-48b0-97d9-ed7fe9bbf0d2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:01:46+00:00
 - user: None

Quoted Companies Alliance says disclosure requirements are drain on resources of smaller companies

## Sunak’s NHS crisis plan to provide more ambulances, hospital beds and care at home
 - [https://www.ft.com/content/6fa06598-95e8-4770-b8d4-39e1e8aea0e3](https://www.ft.com/content/6fa06598-95e8-4770-b8d4-39e1e8aea0e3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:01:46+00:00
 - user: None

Blueprint relies on ‘virtual’ wards and improved community care to alleviate bottlenecks

## UK company profit warnings up 50% last year
 - [https://www.ft.com/content/f4a28bd1-ead2-4b68-9270-0586a9925059](https://www.ft.com/content/f4a28bd1-ead2-4b68-9270-0586a9925059)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-01-30 00:01:46+00:00
 - user: None

Combination of rising costs and falling consumer confidence hit British business
