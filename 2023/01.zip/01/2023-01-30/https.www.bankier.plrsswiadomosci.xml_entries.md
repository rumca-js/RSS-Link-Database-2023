# Source Bankier, Source URL:https://www.bankier.pl/rss/wiadomosci.xml, Source language: pl-PL

## Spadki na Wall Street. Nasdaq oddał niemal 2%
 - [https://www.bankier.pl/wiadomosc/Spadki-na-Wall-Street-Nadaq-oddal-niemal-2-8481015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spadki-na-Wall-Street-Nadaq-oddal-niemal-2-8481015.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 21:14:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/8/25bcb36c6eb825-948-568-25-105-1975-1184.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najmocniej
ucierpiały wielkie spółki technologiczne i to one pociągnęły dół w giełdowe
indeksy.</p>

## Prezes PGE: Ceny energii w przyszłości będą wyższe, nie możemy sobie mydlić oczu
 - [https://www.bankier.pl/wiadomosc/Prezes-PGE-Ceny-energii-w-przyszlosci-beda-wyzsze-nie-mozemy-sobie-mydlic-oczu-8480934.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezes-PGE-Ceny-energii-w-przyszlosci-beda-wyzsze-nie-mozemy-sobie-mydlic-oczu-8480934.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 17:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/a720186a89dec5-948-568-0-40-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Energetyka ma się opierać na źródłach nisko- i zeroemisyjnych i ma dawać bezpieczeństwo energetyczne, czyli m.in. prąd w akceptowalnych cenach - powiedział wiceminister aktywów Karol Rabenda w czasie dyskusji o roli polskich firm w budowaniu suwerenności energetycznej kraju.</p>

## Rośnie liczba Polaków o opiniach zbieżnych z rosyjską propagandą
 - [https://www.bankier.pl/wiadomosc/Rosnie-liczba-Polakow-o-opiniach-zbieznych-z-rosyjska-propaganda-8480907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-liczba-Polakow-o-opiniach-zbieznych-z-rosyjska-propaganda-8480907.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 17:04:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/a/f0679b1b91608b-948-568-21-258-4293-2576.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rośnie liczba Polaków o opiniach zbieżnych z rosyjską propagandą, szczególnie w kwestii postaw dotyczących Rosji i wojny w Ukrainie - wynika z raportu opublikowanego przez Warsaw Enterprise Institute. "Wojna nie toczy się tylko na polu bitwy, ale także w ludzkich umysłach" - wskazują eksperci.</p>

## Banki ciężarem dla indeksów. Wydatki na wojsko wspierają branżowe spółki
 - [https://www.bankier.pl/wiadomosc/Banki-ciezarem-dla-indeksow-Wydatki-na-wojsko-wspieraja-branzowe-spolki-8480882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Banki-ciezarem-dla-indeksow-Wydatki-na-wojsko-wspieraja-branzowe-spolki-8480882.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 16:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/4/37460523159504-945-560-0-0-1387-832.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek tygodnia na GPW był pod największym wpływem 
podaży,
która skoncentrowała się głównie na przecenie sektora bankowego i 
paliwowego,
ale spadki dotknęły także pozostałe indeksy branżowe. Zbiegło się 
to z
publikacją wstępnych danych GUS-u nt. kondycji polskiej gospodarki w 
2022 r. Obronne wydatki podbiły kursy potencjalnych beneficjentów 
zamówień z wojska. </p>

## Młodzi Brytyjczycy boją się, że nie zarobią na utrzymanie rodziny
 - [https://www.bankier.pl/wiadomosc/Mlodzi-Brytyjczycy-boja-sie-ze-nie-zarobia-na-utrzymanie-rodziny-8480836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mlodzi-Brytyjczycy-boja-sie-ze-nie-zarobia-na-utrzymanie-rodziny-8480836.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 15:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/1/f9615f4959e7e1-948-568-0-97-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie połowa wszystkich młodych ludzi w Wielkiej Brytanii - z grupy wiekowej 16-25 lat - obawia się, że nigdy nie będzie zarabiać wystarczająco dużo, aby utrzymać rodzinę - wynika z opublikowanego w poniedziałek raportu organizacji charytatywnej Prince's Trust.</p>

## Na świecie przybyło fałszywych banknotów euro, ale EBC uspokaja
 - [https://www.bankier.pl/wiadomosc/Na-swiecie-przybylo-falszywych-banknotow-euro-ale-EBC-uspokaja-8480804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Na-swiecie-przybylo-falszywych-banknotow-euro-ale-EBC-uspokaja-8480804.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 14:56:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/7/f9ca8da770c5fb-948-568-0-4-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nie wszyscy oszuści przenieśli się do internetu. Podrabianie banknotów nadal cieszy się popularnością. Jak poinformował Europejski Bank Centralny,
 na całym świecie w 2022 roku wycofano z obiegu 376 tys. fałszywych 
banknotów euro, co stanowi wzrost o 8,4 proc. w porównaniu z 2021 
rokiem.</p>

## Powstała druga na świecie szczepionka donosowa przeciwko koronawirusowi
 - [https://www.bankier.pl/wiadomosc/Powstala-druga-na-swiecie-szczepionka-donosowa-przeciwko-koronawirusowi-8480785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Powstala-druga-na-swiecie-szczepionka-donosowa-przeciwko-koronawirusowi-8480785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 14:38:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/f/f748208bad64b3-948-568-120-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Indiach zatwierdzono do użycia pierwszą w tym kraju i drugą na świecie szczepionkę donosową przeciwko Covid-19. Pierwszą kilka miesięcy temu wprowadzono w Chinach. W USA i Europie wciąż trwają prace nad takim preparatem.</p>

## Należąca do Orlenu morska farma wiatrowa ma pierwsze z wymaganych pozwoleń na budowę
 - [https://www.bankier.pl/wiadomosc/Nalezaca-do-Orlenu-morska-farma-wiatrowa-ma-pierwsze-z-wymaganych-pozwolen-na-budowe-8480774.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nalezaca-do-Orlenu-morska-farma-wiatrowa-ma-pierwsze-z-wymaganych-pozwolen-na-budowe-8480774.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 14:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/2/322a7bcab9e725-948-568-48-0-1809-1085.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Należąca do Grupy Orlen morska farma wiatrowa BalticPower uzyskała w poniedziałek pierwsze z wymaganych pozwoleń na budowę dla lądowej części inwestycji - poinformował na Twitterze prezes Orlenu Daniel Obajtek.</p>

## Coraz mniej płatników podatku cukrowego. Co z wpływami do budżetu?
 - [https://www.bankier.pl/wiadomosc/Podatek-cukrowy-Resort-finansow-poinformowal-o-wplywach-za-2022-r-8480360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Podatek-cukrowy-Resort-finansow-poinformowal-o-wplywach-za-2022-r-8480360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 14:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/0aea7fec5c282d-948-568-0-166-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W całym 2021 roku podatek cukrowy zasilił państwową kasę kwotą 1,625 mld złotych. Wiemy już, że wyniku z debiutanckich 12 miesięcy nie udało się powtórzyć. Spadły nie tylko wpływy, ale i liczba płatników - wynika z ustaleń portalu wirtualnemedia.pl. 








</p>

## Liczba lekarzy i dentystów w Polsce znacząco się zwiększyła od 2015 roku
 - [https://www.bankier.pl/wiadomosc/Liczba-lekarzy-i-dentystow-w-Polsce-znaczaco-sie-zwiekszyla-od-2015-roku-8480739.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-lekarzy-i-dentystow-w-Polsce-znaczaco-sie-zwiekszyla-od-2015-roku-8480739.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 13:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/bf606a024a565d-945-560-7-45-992-595.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba lekarzy i lekarzy dentystów wykonujących zawód zwiększyła się od 2015 r. o 24 659 – przekazało w poniedziałek Ministerstwo Zdrowia.</p>

## Prezydent Chorwacji: Jestem przeciwny wysyłaniu Ukrainie jakiejkolwiek broni
 - [https://www.bankier.pl/wiadomosc/Prezydent-Chorwacji-Jestem-przeciwny-wysylaniu-Ukrainie-jakiejkolwiek-broni-8480689.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prezydent-Chorwacji-Jestem-przeciwny-wysylaniu-Ukrainie-jakiejkolwiek-broni-8480689.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 13:15:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/6/286fe0d052730e-945-560-7-14-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent Chorwacji Zoran Milanović powiedział, że jest przeciwny wysyłaniu Ukrainie jakiejkolwiek broni, ponieważ - jego zdaniem - to jedynie przedłuża wojnę z Rosją.</p>

## Inflacja w Belgii przestała być dwucyfrowa, ale żywność nadal drożeje
 - [https://www.bankier.pl/wiadomosc/Inflacja-w-Belgii-przestala-byc-dwucyfrowa-ale-zywnosc-nadal-drozeje-8480688.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-w-Belgii-przestala-byc-dwucyfrowa-ale-zywnosc-nadal-drozeje-8480688.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 13:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/300212d1782b58-948-568-0-105-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wzrost cen towarów i usług wyniósł w Belgii w styczniu br. 8,05 procent - informuje w poniedziałek Belgijski Urząd Statystyczny (Statbel). W grudniu 2022 r. wyniósł on 10,35 proc. Inflacja spada trzeci miesiąc z rzędu.</p>

## Praca zdalna w przepisach i kontrola trzeźwości pracownika. Prezydent podpisał nowelizację Kodeksu pracy
 - [https://www.bankier.pl/wiadomosc/Praca-zdalna-w-przepisach-i-kontrola-trzezwosci-pracownika-Prezydent-podpisal-nowelizacje-Kodeksu-pracy-8480671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-zdalna-w-przepisach-i-kontrola-trzezwosci-pracownika-Prezydent-podpisal-nowelizacje-Kodeksu-pracy-8480671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:52:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/07c0e375811f26-948-568-0-75-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Praca zdalna - szczególnie w czasie trwania pandemii -
 stała się bardzo popularna, przez co ruszyły prace, by została 
usankcjonowana prawnie. Teraz nowelizacja Kodeksu pracy została 
podpisana przez prezydent Andrzej Duda. Na mocy wprowadzonych zmian 
pracodawcy będą mogli ponadto kontrolować trzeźwość pracowników.</p>

## UE walczy z ubóstwem i przyjmuje zalecenie ws. odpowiedniego dochodu minimalnego
 - [https://www.bankier.pl/wiadomosc/UE-walczy-z-ubostwem-i-przyjmuje-zalecenie-ws-odpowiedniego-dochodu-minimalnego-8480649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/UE-walczy-z-ubostwem-i-przyjmuje-zalecenie-ws-odpowiedniego-dochodu-minimalnego-8480649.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:34:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/f1f9744ce8011d-948-567-0-0-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ubóstwo i wykluczenie społeczne nadal jest obecne i 
dotyka dziesiątki milionów ludzi w całej w UE. By walczyć z biedą, Rada 
przyjęła zalecenie w sprawie odpowiedniego dochodu minimalnego, co ma 
pomóc w dążeniu do wysokiego poziomu zatrudnienia poprzez propagowanie 
dochodu minimalnego.</p>

## Którym politykom Polacy ufają nabardziej, a którym najmniej? Karuzela nazwisk
 - [https://www.bankier.pl/wiadomosc/Ktorym-politykom-Polacy-ufaja-nabardziej-a-ktorym-najmniej-Karuzela-nazwisk-8480645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ktorym-politykom-Polacy-ufaja-nabardziej-a-ktorym-najmniej-Karuzela-nazwisk-8480645.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:32:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/d0afb666299d27-948-568-8-0-1722-1033.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Którzy politycy cieszą się zaufaniem Polaków, a 
którzy są po drugiej stronie? Najnowszy sondaż CBOS pokazuje, że 
liderami zestawienia są pezydent Andrzej Duda, prezydent Warszawy Rafał 
Trzaskowski i premier Mateusz Morawiecki. Z największą nieufnością 
spotyka się prezes PiS Jarosław Kaczyński, minister sprawiedliwości 
Zbigniew Ziobro oraz szef PO Donald Tusk.</p>

## Domy jak igloo - ekologiczne i ekonomiczne
 - [https://www.bankier.pl/wiadomosc/Domy-jak-igloo-ekologiczne-i-ekonomiczne-8480472.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Domy-jak-igloo-ekologiczne-i-ekonomiczne-8480472.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:15:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/ddd5bc84e66f6f-948-568-0-67-999-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Są takie domy, obok których nie da się przejść obojętnie. Wyglądem przypominają igloo, a ich budulcem jest beton z… konopi. Dzięki niezwykłemu kształtowi i naturalnym materiałom budowlanym są nie tylko zdrowe, ale też wyjątkowo przyjazne mieszkańcom i planecie. O modułowych domach kopułowych rozmawiamy z Pawłem Fornalskim, założycielem firmy DOMIR, który od lat zajmuje się popularyzacją budownictwa naturalnego.</p>

## Polska Wschodnia stawia na start-upy. Dotacje sięgną nawet 3 mln zł
 - [https://www.bankier.pl/wiadomosc/Polska-Wschodnia-stawia-na-start-upy-Dotacje-siegna-nawet-3-mln-zl-8480619.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-Wschodnia-stawia-na-start-upy-Dotacje-siegna-nawet-3-mln-zl-8480619.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:13:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/c/acbf5e9783e087-948-568-285-105-2715-1628.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W nowej ofercie Funduszy Europejskich dla makroregionu Polski Wschodniej aktualna
pozostanie oferta wsparcia dla tych, którzy będą chcieli uruchomić swój start-up. O
dofinansowanie będzie można się starać dwukrotnie, a maksymalna kwota dotacji
sięgnie 3 mln złotych.</p>

## "Konflikt USA z Chinami o Tajwan jest bardzo prawdopodobny"
 - [https://www.bankier.pl/wiadomosc/Konflikt-USA-z-Chinami-o-Tajwan-jest-bardzo-prawdopodobny-8480614.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konflikt-USA-z-Chinami-o-Tajwan-jest-bardzo-prawdopodobny-8480614.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 12:08:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/bd536eeceb2cb7-948-568-0-0-2718-1630.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawdopodobieństwo konfliktu USA z Chinami o Tajwan jest "bardzo wysokie" - oświadczył przewodniczący komisji spraw zagranicznych Izby Reprezentantów Michael McCaul. Polityk skomentował w ten sposób słowa Mike'a Minihana, generała amerykańskich sił powietrznych, który ostrzegł, że do wojny z Chinami może dojść już w 2025 r.</p>

## A2 między Łodzią a Warszawą będzie szersza. GDDKiA ogłosiła przetarg
 - [https://www.bankier.pl/wiadomosc/A2-miedzy-Lodzia-a-Warszawa-bedzie-szersza-GDDKiA-oglosila-przetarg-8480574.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/A2-miedzy-Lodzia-a-Warszawa-bedzie-szersza-GDDKiA-oglosila-przetarg-8480574.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 11:34:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/0fb0bc8e87cc92-948-568-0-64-1167-700.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Generalna Dyrekcja Dróg Krajowych i Autostrad (GDDKiA) ogłosiła przetarg na wykonanie projektu budowalnego rozbudowy autostrady A2 do trzech i czterech pasów ruchu na odcinku między Łodzią a Warszawą. Prace przy poszerzeniu autostrady mają rozpocząć się w 2025 r.</p>

## XTB rozpoczyna współpracę z Kanałem Sportowym
 - [https://www.bankier.pl/wiadomosc/XTB-rozpoczyna-wspolprace-z-Kanalem-Sportowym-8480475.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/XTB-rozpoczyna-wspolprace-z-Kanalem-Sportowym-8480475.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 10:45:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/1/7885ccbd77ef17-948-568-11-35-1584-950.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spółka XTB ogłosiła, że rozpoczyna współpracę z Kanałem Sportowym mającą na celu popularyzację oferty inwestycyjnej domu maklerskiego. Według przedstawicieli kanału na YouTube, a także polskiego brokera CFD, świat sportu i inwestycji ma wiele punktów stycznych, a część z nich będzie można poznać w programach Kanału.</p>

## Ostatni moment na zgłoszenie się do "Mały ZUS Plus"
 - [https://www.bankier.pl/wiadomosc/Ostatni-moment-na-zgloszenie-sie-do-malego-ZUS-plus-8480508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ostatni-moment-na-zgloszenie-sie-do-malego-ZUS-plus-8480508.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 10:24:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/3/7d6fd98b8f1439-948-568-0-0-2255-1353.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />We wtorek 31 stycznia mija termin dla przedsiębiorców na zgłoszenie się do małego ZUS plus. Ci, którzy korzystali z ulgi w 2022 roku i nadal spełniają warunki, nie muszą zgłaszać się ponownie – przypomina rzecznik Zakładu Ubezpieczeń Społecznych Paweł Żebrowski.</p>

## Włochy kupią libijski gaz za 8 mld dolarów
 - [https://www.bankier.pl/wiadomosc/Wlochy-kupia-libijski-gaz-za-8-mld-dolarow-8480492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wlochy-kupia-libijski-gaz-za-8-mld-dolarow-8480492.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 10:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/2f58edf6d6a66d-945-567-63-15-1393-836.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Włochy podpisały z Libią kontrakt w sprawie produkcji gazu na sumę 8 miliardów euro. Umowę z libijską państwową firmą Noc zawarł włoski koncern energetyczny Eni podczas wizyty premier Giorgii Meloni w Trypolisie w ostatni weekend. Ekonomiczny dziennik „Il Sole-24 Ore” nazywa porozumienie „historycznym”.</p>

## Myśliwi jednak bez badań psychologicznych. Wrzutka do projektu ustawy w Sejmie
 - [https://www.bankier.pl/wiadomosc/Mysliwi-jednak-bez-badan-psychologicznych-Wrzutka-do-projektu-ustawy-w-Sejmie-8480411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mysliwi-jednak-bez-badan-psychologicznych-Wrzutka-do-projektu-ustawy-w-Sejmie-8480411.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 10:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/79ec3e0b9fa0be-948-568-0-221-2908-1745.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm głosami PiS i PSL zdecydował o zniesieniu 
obowiązkowych badań lekarskich dla myśliwych. Stało się to w czwartek. 
Zapisy na ten temat znalazły się w projekcie ustawy o zmianie ustaw w celu likwidowania zbędnych barier 
administracyjnych i prawnych.</p>

## Dłuższe wakacje kredytowe? Premier: Będą zależeć od inflacji w Polsce
 - [https://www.bankier.pl/wiadomosc/Dluzsze-wakacje-kredytowe-Premier-Beda-zalezec-od-inflacji-w-Polsce-8480473.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dluzsze-wakacje-kredytowe-Premier-Beda-zalezec-od-inflacji-w-Polsce-8480473.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/b1ce9cee9dda8b-948-568-0-138-2510-1505.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Decyzje w sprawie wakacji kredytowych nie zostały jeszcze podjęte, zależą one od ukształtowania się sytuacji inflacyjnej w Polsce w dalszej części tego roku - powiedział w poniedziałek premier Mateusz Morawiecki.</p>

## Polska przeznaczy 4 proc. PKB na wojsko. Premier: to może być najwięcej w całym NATO
 - [https://www.bankier.pl/wiadomosc/Polska-przeznaczy-4-proc-PKB-na-wojsko-Premier-to-moze-byc-najwiecej-w-calym-NATO-8480450.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-przeznaczy-4-proc-PKB-na-wojsko-Premier-to-moze-byc-najwiecej-w-calym-NATO-8480450.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:37:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/2159f70b43994d-948-568-0-17-1024-614.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojna na Ukrainie powoduje, że musimy zbroić się jeszcze szybciej, dlatego w tym roku przeznaczymy 4 proc. PKB na wojsko, być może będzie to najwyższy procent wśród wszystkich państw NATO - powiedział w poniedziałek premier Mateusz Morawiecki.</p>

## Ostrzeżenia zdrowotne na butelkach alkoholu? Producenci przeciwni
 - [https://www.bankier.pl/wiadomosc/Ostrzezenia-zdrowotne-na-butelkach-alkoholu-Producenci-przeciwni-8480435.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ostrzezenia-zdrowotne-na-butelkach-alkoholu-Producenci-przeciwni-8480435.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/c3380350bd641c-948-568-0-48-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja
Europejska zgodziła się na wprowadzenie w Irlandii obowiązku umieszczania na
etykietach napojów alkoholowych informacji o ich szkodliwości dla zdrowia. Mają
być podobne do tych, jakie znajdują się na paczkach papierosów. To spowodowało
duże protesty producentów alkoholi, którzy obawiają się, że wpłynie to
negatywnie na ich sprzedaż.</p>

## "Niewiarygodnie słaba" konsumpcja prywatna odbija się na PKB Polski. "Polityka pieniężna działa"
 - [https://www.bankier.pl/wiadomosc/PKB-Polski-w-2022-r-8480347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-Polski-w-2022-r-8480347.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/c926b99a57a434-948-568-0-176-1722-1033.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W całym minionym roku polska gospodarka nadal szybko 
rosła. Ale z kwartału na kwartał dynamika wzrostu PKB wyraźnie 
zwalniała. W ostatnim kwartale wynik konsumpcji prywatnej był 
"niewiarygodnie słaby" - oceniają ekonomiści Banku Pekao. </p>

## Kaczyński nie zapłaci 700 tys. zł Sikorskiemu. PiS zmienił prawo
 - [https://www.bankier.pl/wiadomosc/Kaczynski-nie-zaplaci-700-tys-zl-Sikorskiemu-PiS-zmienil-prawo-8480378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-nie-zaplaci-700-tys-zl-Sikorskiemu-PiS-zmienil-prawo-8480378.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:23:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/c/c1f59099b4a0f8-948-568-0-146-3264-1958.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd wydał wyrok, że Jarosław Kaczyński musi przeprosić Radosława Sikorskiego, a ponieważ się od tego uchylał, ma wydać 700 tys. zł. PiS zmienił więc kodeks cywilny, by znacząco zmniejszyć wymiar kary prezesa, bo prawo będzie się tyczyło trwających postępowań. Wyrok Kaczyński kontra Sikorski jest nieprawomocny. </p>

## Nowy operator komórkowy wszedł do Polski. Będzie wynajmował iPhone’y
 - [https://www.bankier.pl/wiadomosc/Nowy-operator-komorkowy-wszedl-do-Polski-Bedzie-wynajmowal-iPhone-y-8480426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nowy-operator-komorkowy-wszedl-do-Polski-Bedzie-wynajmowal-iPhone-y-8480426.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:19:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/6/185b10bfb20758-945-560-8-166-3491-2094.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PHOX – tak nazywa się nowy wirtualny operator komórkowy, który rozpoczął działalność na polskim rynku – informuje serwis telepolis.pl. PHOX będzie korzystał z infrastruktury należącej do Plusa, a w ofercie będzie miał smartfony na wynajem.</p>

## NBP: optymizm inwestycyjny przedsiębiorstw słabnie, również w dłuższym okresie
 - [https://www.bankier.pl/wiadomosc/NBP-optymizm-inwestycyjny-przedsiebiorstw-slabnie-rowniez-w-dluzszym-okresie-8480422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-optymizm-inwestycyjny-przedsiebiorstw-slabnie-rowniez-w-dluzszym-okresie-8480422.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:18:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/4/14101a83ef9dc3-948-568-10-10-2037-1222.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Optymizm inwestycyjny przedsiębiorstw jest obecnie bardzo niski, obniża się od kilku kwartałów i słabnie również w wieloletnich planach rozwojowych - napisano w najnowszej wersji raportu NBP "Szybki Monitoring".</p>

## Liczba urodzeń w Polsce najmniejsza od II wojny światowej
 - [https://www.bankier.pl/wiadomosc/Liczba-urodzen-w-Polsce-najmniejsza-od-II-wojny-swiatowej-8480352.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Liczba-urodzen-w-Polsce-najmniejsza-od-II-wojny-swiatowej-8480352.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:15:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/58a04f5914f436-948-568-2-0-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W minionym roku w Polsce przyszło na świat najmniej dzieci od II wojny 
światowej. Zmarło mniej osób niż w poprzednich dwóch latach, ale 
wyraźnie więcej niż przed pandemią.</p>

## PKB: Niemcy pod kreską. Największa gospodarka Europy mogła się znaleźć w technicznej recesji
 - [https://www.bankier.pl/wiadomosc/PKB-Niemiec-IV-kwartal-2022-8480413.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-Niemiec-IV-kwartal-2022-8480413.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:08:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/3217e27a1eda96-905-542-12-15-905-542.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ostatnie trzy miesiące 2022 roku przyniosły realny spadek
produktu krajowego brutto Niemiec. Największa gospodarka Europy mogła się znaleźć
w tzw. technicznej recesji.</p>

## Philips zwolni więcej pracowników, niż planował
 - [https://www.bankier.pl/wiadomosc/Philips-zwolni-wiecej-pracownikow-niz-planowal-8480412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Philips-zwolni-wiecej-pracownikow-niz-planowal-8480412.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 09:08:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/429612af0104a0-945-567-17-92-953-572.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Philips planuje zwolnić 6 tys. pracowników na całym świecie, w tym 1,1 tys. w Niderlandach. Jest to wynik straty osiągniętej w 2022 roku w wysokości 1,6 mld euro. Jeszcze trzy miesiące temu firma zapowiadała redukcję etatów o 4 tys. pracowników.</p>

## Kurs euro bez większych zmian. Złoty czeka na nowe dane
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8480390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bez-wiekszych-zmian-8480390.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 08:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/54f02e0f933ada-948-568-175-0-1300-780.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przełom stycznia i lutego na polskim rynku
walutowym rozpoczynamy z kursem euro w pobliżu 4,70 zł.</p>

## mBank zawarł z klientami ponad 2800 ugód dotyczących kredytów CHF
 - [https://www.bankier.pl/wiadomosc/mBank-zawarl-z-klientami-ponad-2800-ugod-dotyczacych-kredytow-CHF-8480371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/mBank-zawarl-z-klientami-ponad-2800-ugod-dotyczacych-kredytow-CHF-8480371.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 08:24:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/fd5e96308c0431-948-568-0-147-2192-1315.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu trzech miesięcy mBank zawarł z klientami ponad 2800 ugód dotyczących kredytów we frankach szwajcarskich - poinformował bank w komunikacie prasowym.</p>

## Mamy coraz więcej kart i chętnie nimi płacimy
 - [https://www.bankier.pl/wiadomosc/Mamy-coraz-wiecej-kart-i-chetnie-nimi-placimy-8480342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mamy-coraz-wiecej-kart-i-chetnie-nimi-placimy-8480342.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 07:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/55c8fd3d807205-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy mają coraz więcej kart i coraz chętniej dokonują za ich pomocą transakcji bezgotówkowych – wynika z najnowszych danych NBP. Regularnie przybywa terminali POS, w których można zapłacić kartą. Na koniec III kwartału 2022 r. było ich już ponad 1,2 mln. Kurczy się natomiast sieć bankomatów.</p>

## "Nie masz serca?" Członkini RPP odpowiada krytykom podwyżek stóp procentowych
 - [https://www.bankier.pl/wiadomosc/Nie-masz-serca-Czlonkini-RPP-odpowiada-krytykom-podwyzek-stop-procentowych-8480327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nie-masz-serca-Czlonkini-RPP-odpowiada-krytykom-podwyzek-stop-procentowych-8480327.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 07:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/e/b2cf70e8c2e26f-948-568-0-672-2478-1486.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Członkini RPP Joanna Tyrowicz tłumaczy, dlaczego opowiada się za 
dalszymi podwyżkami stóp procentowych, mimo że zacieśnienie polityki 
pieniężnej prowadzi do wzrostu rat kredytów mieszkaniowych.</p>

## Rząd weźmie się za lombardy. Soboń: Rynek będzie ucywilizowany
 - [https://www.bankier.pl/wiadomosc/Rzad-wezmie-sie-za-lombardy-Sobon-Rynek-bedzie-ucywilizowany-8480332.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-wezmie-sie-za-lombardy-Sobon-Rynek-bedzie-ucywilizowany-8480332.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 07:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/1/439e641d8eb8b1-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd bierze na celownik lombardy i przygotowuje rozwiązania, które ucywilizują ten rynek. Wśród nich mają się znaleźć m.in. limity dotyczące kosztów, analogicznie jak w ustawie antylichwiarskiej - zapowiedział wiceminister finansów Artur Soboń. Dodał, że w połowie roku zapadnie decyzja ws. przedłużenia wakacji kredytowych na 2024 r.</p>

## Wartość inwestycji venture capital w Polsce w '22 wyniosła 3,6 mld zł
 - [https://www.bankier.pl/wiadomosc/Wartosc-inwestycji-venture-capital-w-Polsce-w-22-wyniosla-3-6-mld-zl-8480326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wartosc-inwestycji-venture-capital-w-Polsce-w-22-wyniosla-3-6-mld-zl-8480326.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 07:14:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/eeb6795dd4fa40-948-568-0-293-4350-2609.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wartość inwestycji venture capital w Polsce w 2022 roku wyniosła 3,6 mld zł - poinformował w komunikacie PFR Ventures i Inovo VC.</p>

## Problemy mieszkaniowe jedną z największych bolączek Polaków
 - [https://www.bankier.pl/wiadomosc/Problemy-mieszkaniowe-jedna-z-najwiekszych-bolaczek-Polakow-8480301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Problemy-mieszkaniowe-jedna-z-najwiekszych-bolaczek-Polakow-8480301.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 06:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/f/0cc61650f18cbe-948-568-2-32-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kwestię braku mieszkań miały rozwiązać mieszkania komunalne i należące do towarzystw budownictwa społecznego (TBS-ów), ale ich udział w ogólnej liczbie nowo oddawanych lokali jest wręcz marginalny....</p>

## Uniwersytety Europejskie konkurencją dla uczelni amerykańskich i chińskich?
 - [https://www.bankier.pl/wiadomosc/Uniwersytety-Europejskie-konkurencja-dla-uczelni-amerykanskich-i-chinskich-8480303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Uniwersytety-Europejskie-konkurencja-dla-uczelni-amerykanskich-i-chinskich-8480303.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 06:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/8/52ab7a26ff6410-948-568-0-143-3027-1816.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do końca stycznia uczelnie wyższe, które chcą się stać częścią sojuszy Uniwersytetów Europejskich - integralnej części programu Erasmus+ - mogą zgłaszać swoje aplikacje. Nabór ogłoszony...</p>

## Nawet 3 tys. zł "na dom". Prezes PGE o środkach, które zatrzymają wzrost cen energii
 - [https://www.bankier.pl/wiadomosc/Nawet-3-tys-zl-na-dom-Prezes-PGE-o-srodkach-ktore-zatrzymaja-wzrost-cen-energii-8480292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nawet-3-tys-zl-na-dom-Prezes-PGE-o-srodkach-ktore-zatrzymaja-wzrost-cen-energii-8480292.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:54:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/9e55709ec1f4f9-948-568-22-59-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Farmy wiatrowe na Bałtyku mogą wyprodukować prąd już w 2026 roku - zapowiada DGP prezes PGE Polskiej Grupy Energetycznej Wojciech Dąbrowski. Jednocześnie chwaląc się, że grupa jest liderem zielonej zmiany. </p>

## Analityk z ING BSK o prognozach PKB za IV kwartał 2022 r.
 - [https://www.bankier.pl/wiadomosc/Prognozy-PKB-IV-kwartal-2022-roku-z-ING-BSK-8480290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Prognozy-PKB-IV-kwartal-2022-roku-z-ING-BSK-8480290.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:51:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/cbd49580b9f131-948-568-0-0-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ekonomista banku ING BSK Adam Antoniak poinformował o prognozach PKB zarówno na IV kwartał 2022 roku, jak i na cały zeszły rok. Niestety odzwierciedlają one dalszy i szeroko zakrojony spadek koniunktury.</p>

## Czeka nas albo dłuższa praca albo bieda. Ekonomiści nie mają złudzeń
 - [https://www.bankier.pl/wiadomosc/Czeka-nas-albo-dluzsza-praca-albo-bieda-Ekonomisci-nie-maja-zludzen-8480289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czeka-nas-albo-dluzsza-praca-albo-bieda-Ekonomisci-nie-maja-zludzen-8480289.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/bdaa73e607bdb9-945-560-20-90-962-577.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wyższy wiek emerytalny budzi sporo emocji nie tylko w Polsce. O tym, że musi być zrównany dla kobiet i mężczyzn i wyższy niż dziś przekonana jest większość ekonomistów -  pisze w poniedziałkowym wydaniu "Rzeczpospolita".</p>

## Polskie promy coraz bliżej. Gróbarczyk chwali się terminem ich wodowania
 - [https://www.bankier.pl/wiadomosc/Polskie-promy-coraz-blizej-Grobarczyk-chwali-sie-terminem-ich-wodowania-8480282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-promy-coraz-blizej-Grobarczyk-chwali-sie-terminem-ich-wodowania-8480282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:16:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/54e6dc477358b4-948-568-419-92-1628-976.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Już w tym roku nastąpi wodowanie pierwszego promu dla Polskiej Żeglugi Morskiej - zapowiedział hucznie minister infrastruktury Marek Gróbarczyk. "Możliwe jest, że nastąpi to w trzecim kwartale" zaznaczył. Nie będzie to jednak koniec prac. </p>

## ChatGPT opowiedział, po co Microsoft inwestuje miliardy w sztuczną inteligencję
 - [https://www.bankier.pl/wiadomosc/ChatGPT-opowiedzial-po-co-Microsoft-inwestuje-miliardy-w-sztuczna-inteligencje-8478195.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ChatGPT-opowiedzial-po-co-Microsoft-inwestuje-miliardy-w-sztuczna-inteligencje-8478195.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/4dc47b4daf7f4d-948-568-123-270-4376-2625.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Publikacja wyników Microsoftu była okazją do zaprezentowania prognoz finansowych na kolejne kwartały. Nie są one najlepsze, nie zmienia to jednak faktu, że technologiczny gigant z Redmond coraz więcej chce wydawać na rozwój sztucznej inteligencji (AI). Jednym z flagowych produktów ma być ChatGPT, który bije rekordy popularności.</p>

## Ginący gatunek hipotek. Wybór kredytów ze zmienną stopą coraz mniejszy
 - [https://www.bankier.pl/wiadomosc/Najlepsze-kredyty-hipoteczne-ze-zmiennym-oprocentowaniem-styczen-2022-8479598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-kredyty-hipoteczne-ze-zmiennym-oprocentowaniem-styczen-2022-8479598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/8/cf8ade26506f48-948-568-35-165-1625-975.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kiedyś nie miały konkurencji, dziś kredyty hipoteczne ze zmiennym oprocentowaniem schodzą na drugi plan. Powoli skraca się lista banków oferujących ten produkt. Bankier.pl sprawdza w styczniowym zestawieniu, jakie stawki proponują kredytodawcy.</p>

## Jak żyje się Polakom? Indeks Nędzy zawrócił z wieloletniego szczytu
 - [https://www.bankier.pl/wiadomosc/Indeks-Nedzy-dla-Polski-styczen-2023-8478153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Indeks-Nedzy-dla-Polski-styczen-2023-8478153.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/dcaa2cfbe2f0fc-948-568-0-168-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Potwornie wysoka inflacja cenowa sprawiła, że Indeks Nędzy
dla Polski osiągnął najwyższą wartość od 17 lat.</p>

## Połowa firm boi się niewypłacalności, ale sporo liczy też na rozwój
 - [https://www.bankier.pl/wiadomosc/Polowa-firm-boi-sie-niewyplacalnosci-ale-sporo-liczy-tez-na-rozwoj-8480278.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polowa-firm-boi-sie-niewyplacalnosci-ale-sporo-liczy-tez-na-rozwoj-8480278.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/c/d93962accadf91-948-568-0-0-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Blisko połowa firm, ale i klientów indywidualnych jest zdania, że z powodu trudnych warunków ekonomicznych wzrośnie liczba podmiotów zagrożonych niewypłacalnością i upadłością - tanie wnioski płyną z badania firmy Kaczmarski Inkasso. Jest jednak pozytyw. 24 proc. firm liczy na rozwój gospodarczy - dodano.</p>

## Wycena mieszkań znów drgnęła w górę. Nowy raport Bankier.pl i Otodom
 - [https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-styczen-2023-Raport-Bankier-pl-8479501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-ofertowe-wynajmu-mieszkan-styczen-2023-Raport-Bankier-pl-8479501.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/28302f36c920f3-948-569-34-182-1891-1135.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarówno w przypadku nowych mieszkań, jak i lokali z drugiej ręki grudzień 2022 r. przyniósł wzrost średnich cen ofertowych – wynika z udostępnionych Bankier.pl danych Otodom. W ujęciu rocznym, z uwagi na efekt bazy, stawki, zwłaszcza na rynku wtórnym, rosły w jednocyfrowym tempie.</p>
