# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## Interesting
 - [https://mctoon.net/interesting/](https://mctoon.net/interesting/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 22:39:24+00:00
 - user: None

<p>Article URL: <a href="https://mctoon.net/interesting/">https://mctoon.net/interesting/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34587575">https://news.ycombinator.com/item?id=34587575</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## It Should Be Okay to Just Read Headlines
 - [https://mukdde.substack.com/p/why-it-should-be-okay-to-just-read](https://mukdde.substack.com/p/why-it-should-be-okay-to-just-read)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 22:28:28+00:00
 - user: None

<p>Article URL: <a href="https://mukdde.substack.com/p/why-it-should-be-okay-to-just-read">https://mukdde.substack.com/p/why-it-should-be-okay-to-just-read</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34587421">https://news.ycombinator.com/item?id=34587421</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## Ask HN: Do you use JSON Schema? Help us shape its future stability guarantees
 - [https://news.ycombinator.com/item?id=34587360](https://news.ycombinator.com/item?id=34587360)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 22:24:05+00:00
 - user: None

<p>The JSON Schema organization is requesting feedback from users out there about the stability guarantees it should be enforcing on the next release of the specification.<p>If you feel you can contribute, please read https://github.com/orgs/json-schema-org/discussions/295 and share your thoughts.<p>The current options are:<p>- The specifications that have been published to date provide no stability guarantees, but we will be adding explicit guarantees with the next publication.<p>- Apply the stability guarantees starting with the most recent publication (draft 2020-12) so that the next publication contains no breaking changes.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34587360">https://news.ycombinator.com/item?id=34587360</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## All 10TB portable SSDs on Amazon (UK) are scams
 - [https://www.amazon.co.uk/s?k=portable+ssd+10tb&crid=3B5JCJDW98CMX&sprefix=portable+ssd+10tb%2Caps%2C149&ref=nb_sb_noss_1](https://www.amazon.co.uk/s?k=portable+ssd+10tb&crid=3B5JCJDW98CMX&sprefix=portable+ssd+10tb%2Caps%2C149&ref=nb_sb_noss_1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 22:19:17+00:00
 - user: None

<p>Article URL: <a href="https://www.amazon.co.uk/s?k=portable+ssd+10tb&amp;crid=3B5JCJDW98CMX&amp;sprefix=portable+ssd+10tb%2Caps%2C149&amp;ref=nb_sb_noss_1">https://www.amazon.co.uk/s?k=portable+ssd+10tb&amp;crid=3B5JCJDW98CMX&amp;sprefix=portable+ssd+10tb%2Caps%2C149&amp;ref=nb_sb_noss_1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34587293">https://news.ycombinator.com/item?id=34587293</a></p>
<p>Points: 57</p>
<p># Comments: 25</p>

## Git archive checksums may change
 - [https://github.blog/changelog/2023-01-30-git-archive-checksums-may-change/](https://github.blog/changelog/2023-01-30-git-archive-checksums-may-change/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 21:48:15+00:00
 - user: None

<p>Article URL: <a href="https://github.blog/changelog/2023-01-30-git-archive-checksums-may-change/">https://github.blog/changelog/2023-01-30-git-archive-checksums-may-change/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34586917">https://news.ycombinator.com/item?id=34586917</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Amazon Is Selling Its 29-Acre Bay Area Property as Return to Office Stalls
 - [https://www.msn.com/en-us/money/companies/amazon-to-sell-bay-area-office-complex-as-sales-growth-cools/ar-AA16M4Pp](https://www.msn.com/en-us/money/companies/amazon-to-sell-bay-area-office-complex-as-sales-growth-cools/ar-AA16M4Pp)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 21:22:01+00:00
 - user: None

<p>Article URL: <a href="https://www.msn.com/en-us/money/companies/amazon-to-sell-bay-area-office-complex-as-sales-growth-cools/ar-AA16M4Pp">https://www.msn.com/en-us/money/companies/amazon-to-sell-bay-area-office-complex-as-sales-growth-cools/ar-AA16M4Pp</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34586553">https://news.ycombinator.com/item?id=34586553</a></p>
<p>Points: 24</p>
<p># Comments: 2</p>

## Automerge 2.0
 - [https://automerge.org//blog/automerge-2/](https://automerge.org//blog/automerge-2/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 21:10:13+00:00
 - user: None

<p>Article URL: <a href="https://automerge.org//blog/automerge-2/">https://automerge.org//blog/automerge-2/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34586433">https://news.ycombinator.com/item?id=34586433</a></p>
<p>Points: 12</p>
<p># Comments: 8</p>

## Firefighters forced to smash window of driverless Cruise taxi to stop it
 - [https://www.businessinsider.com/san-francisco-firefighters-smashed-window-driverless-cruise-taxi-stop-it-2023-1](https://www.businessinsider.com/san-francisco-firefighters-smashed-window-driverless-cruise-taxi-stop-it-2023-1)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 20:53:06+00:00
 - user: None

<p>Article URL: <a href="https://www.businessinsider.com/san-francisco-firefighters-smashed-window-driverless-cruise-taxi-stop-it-2023-1">https://www.businessinsider.com/san-francisco-firefighters-smashed-window-driverless-cruise-taxi-stop-it-2023-1</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34586213">https://news.ycombinator.com/item?id=34586213</a></p>
<p>Points: 57</p>
<p># Comments: 49</p>

## Burning a NeXTCube (1993)
 - [http://web.archive.org/web/20000817013818/http://simson.net/photos/hacks/cubefire.html](http://web.archive.org/web/20000817013818/http://simson.net/photos/hacks/cubefire.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 20:17:08+00:00
 - user: None

<p>Article URL: <a href="http://web.archive.org/web/20000817013818/http://simson.net/photos/hacks/cubefire.html">http://web.archive.org/web/20000817013818/http://simson.net/photos/hacks/cubefire.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34585754">https://news.ycombinator.com/item?id=34585754</a></p>
<p>Points: 32</p>
<p># Comments: 1</p>

## Burning a NeXTCube (1993)
 - [https://simson.net/ref/1993/cubefire.html](https://simson.net/ref/1993/cubefire.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 20:17:08+00:00
 - user: None

<p>Article URL: <a href="https://simson.net/ref/1993/cubefire.html">https://simson.net/ref/1993/cubefire.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34585754">https://news.ycombinator.com/item?id=34585754</a></p>
<p>Points: 94</p>
<p># Comments: 18</p>

## SimulaVR FPGA Image Processing Pipeline
 - [https://simulavr.com/blog/fpga-image-processing-pipeline/](https://simulavr.com/blog/fpga-image-processing-pipeline/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:45:29+00:00
 - user: None

<p>Article URL: <a href="https://simulavr.com/blog/fpga-image-processing-pipeline/">https://simulavr.com/blog/fpga-image-processing-pipeline/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34584473">https://news.ycombinator.com/item?id=34584473</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## Show HN: Deploy Button for GPT-3 API Back Ends
 - [https://www.steamship.com/build/prompt-apis](https://www.steamship.com/build/prompt-apis)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:42:02+00:00
 - user: None

<p>Article URL: <a href="https://www.steamship.com/build/prompt-apis">https://www.steamship.com/build/prompt-apis</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34584416">https://news.ycombinator.com/item?id=34584416</a></p>
<p>Points: 35</p>
<p># Comments: 13</p>

## Show HN: ELI5 Powered by GPT-3
 - [https://eli5.gg](https://eli5.gg)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:40:37+00:00
 - user: None

<p>Article URL: <a href="https://eli5.gg">https://eli5.gg</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34584393">https://news.ycombinator.com/item?id=34584393</a></p>
<p>Points: 10</p>
<p># Comments: 15</p>

## Metal Without Mining
 - [https://magratheametals.com](https://magratheametals.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:34:08+00:00
 - user: None

<p>Article URL: <a href="https://magratheametals.com">https://magratheametals.com</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34584279">https://news.ycombinator.com/item?id=34584279</a></p>
<p>Points: 25</p>
<p># Comments: 18</p>

## Ask HN: LinkedIn sent me a cease and desist for my Chrome extension. Help?
 - [https://news.ycombinator.com/item?id=34583932](https://news.ycombinator.com/item?id=34583932)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:11:54+00:00
 - user: None

<p>Hi HN,<p>I'm the creator and solo developer behind Browserflow, a Chrome extension that lets you automate any website. (Show HN from around a year ago: https://news.ycombinator.com/item?id=29254147). Basically, it's a general-purpose browser automation tool like Selenium/Puppeteer/Playwright that anyone can use without writing code.<p>The Browserflow website includes examples of automations people often request, including scraping popular websites like LinkedIn. A few days ago, I received a cease and desist letter from LinkedIn: https://browserflow.app/linkedin.pdf<p>As a one-man operation with modest resources, I'm hoping I can get some help from the HN community in understanding what this means to avoid getting sued into oblivion. :)<p>At first I thought that I'd be fine if I removed all references to LinkedIn from the Browserflow website, but I'm not so sure about that. One of LinkedIn's demands is to “Cease and desist developing, offering, or using software or programs with features developed, marketed, or intended for automating activity on LinkedIn’s website or app, scraping LinkedIn member data, or otherwise violating the LinkedIn User Agreement”.<p>Even if I removed all the LinkedIn examples, Browserflow could still be used to automate or scrape LinkedIn because, well, it's a browser automation tool. Is LinkedIn demanding that I stop developing Browserflow altogether?<p>The letter cites hiQ Labs, Inc. v. LinkedIn Corp as the legal precedent for why Browserflow is in violation, but there are some differences between hiQ and Browserflow that I thought might be meaningful:<p>1. Browserflow is not designed specifically for scraping LinkedIn: It's a tool for general-purpose browser automation, not a service that scrapes LinkedIn and resells the data.<p>2. Browserflow does not scrape LinkedIn on its own: Any automation of LinkedIn is initiated by the user using their own LinkedIn account.<p>2. Browserflow does not create or use fake LinkedIn accounts.<p>I'd be fine with removing all the LinkedIn examples from the website, but I'd like to continue building Browserflow because I love working on it and it's my livelihood. I'd appreciate any advice or help. Thanks!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583932">https://news.ycombinator.com/item?id=34583932</a></p>
<p>Points: 56</p>
<p># Comments: 39</p>

## Hypertext Emacs: You may not need org-mode
 - [http://bjornwestergard.com/log/2022-04-19-hypertext-emacs.gmi](http://bjornwestergard.com/log/2022-04-19-hypertext-emacs.gmi)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 18:00:16+00:00
 - user: None

<p>Article URL: <a href="http://bjornwestergard.com/log/2022-04-19-hypertext-emacs.gmi">http://bjornwestergard.com/log/2022-04-19-hypertext-emacs.gmi</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583734">https://news.ycombinator.com/item?id=34583734</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## J&J Can’t Use Bankruptcy to Resolve Talc-Injury Lawsuits, Appeals Court Rules
 - [https://www.wsj.com/articles/j-js-talc-bankruptcy-case-thrown-out-by-appeals-court-11675096308](https://www.wsj.com/articles/j-js-talc-bankruptcy-case-thrown-out-by-appeals-court-11675096308)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 17:56:43+00:00
 - user: None

<p>Article URL: <a href="https://www.wsj.com/articles/j-js-talc-bankruptcy-case-thrown-out-by-appeals-court-11675096308">https://www.wsj.com/articles/j-js-talc-bankruptcy-case-thrown-out-by-appeals-court-11675096308</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583670">https://news.ycombinator.com/item?id=34583670</a></p>
<p>Points: 60</p>
<p># Comments: 25</p>

## Berkeley Mono Ligatures Release
 - [https://berkeleygraphics.com/public-affairs/bulletins/BT-002/](https://berkeleygraphics.com/public-affairs/bulletins/BT-002/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 17:46:37+00:00
 - user: None

<p>Article URL: <a href="https://berkeleygraphics.com/public-affairs/bulletins/BT-002/">https://berkeleygraphics.com/public-affairs/bulletins/BT-002/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583520">https://news.ycombinator.com/item?id=34583520</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Ask HN: Have students started questioning their curriculums due to ChatGPT?
 - [https://news.ycombinator.com/item?id=34583343](https://news.ycombinator.com/item?id=34583343)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 17:35:50+00:00
 - user: None

<p>In particular, what is the point of learning something that is answerable by an AI such as ChatGPT?<p>How do teachers reply to such questions?<p>Are teachers starting to change what they teach?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583343">https://news.ycombinator.com/item?id=34583343</a></p>
<p>Points: 12</p>
<p># Comments: 18</p>

## Show HN: Asdf Clone Written in Rust
 - [https://news.ycombinator.com/item?id=34583080](https://news.ycombinator.com/item?id=34583080)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 17:22:46+00:00
 - user: None

<p>I think that asdf (https://asdf-vm.com) was a great idea for a project. It helps consolidate installing and running different programming languages into a similar UX. It also is built with a plugin interface that makes it easy to build support for new languages.<p>However it is so slow. I was just testing `node -v` and it was taking ~900ms. That kind of overhead is completely unusable. My shell prompt uses runtimes inside of it for various things so this effectively makes every command take multiple seconds to complete.<p>So I rebuilt it in Rust but using the same plugin ecosystem so it should be a drop-in replacement. I also added a couple of features that I wanted from asdf (aliases and fuzzy-matching).<p>Let me know what you think! Just know that people have only been using this for a few days so if you see any bugs, they're likely not big hairy issues, just overlooked edge-cases and will be fixed soon.<p>https://github.com/jdxcode/rtx</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34583080">https://news.ycombinator.com/item?id=34583080</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## The Muse (YC W12) Is Hiring a BD Manager for Strategic Partnerships
 - [https://www.themuse.com/jobs/themuse/manager-business-development-strategic-partnerships](https://www.themuse.com/jobs/themuse/manager-business-development-strategic-partnerships)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 17:00:28+00:00
 - user: None

<p>Article URL: <a href="https://www.themuse.com/jobs/themuse/manager-business-development-strategic-partnerships">https://www.themuse.com/jobs/themuse/manager-business-development-strategic-partnerships</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34582681">https://news.ycombinator.com/item?id=34582681</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## It's not you, it's SQL
 - [https://stack.convex.dev/not-sql](https://stack.convex.dev/not-sql)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 16:54:04+00:00
 - user: rumpel
 - tags: sql,programming

<p>Article URL: <a href="https://stack.convex.dev/not-sql">https://stack.convex.dev/not-sql</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34582549">https://news.ycombinator.com/item?id=34582549</a></p>
<p>Points: 31</p>
<p># Comments: 13</p>

## The Parallel Port
 - [https://computer.rip/2023-01-29-the-parallel-port.html](https://computer.rip/2023-01-29-the-parallel-port.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 16:45:52+00:00
 - user: None

<p>Article URL: <a href="https://computer.rip/2023-01-29-the-parallel-port.html">https://computer.rip/2023-01-29-the-parallel-port.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34582385">https://news.ycombinator.com/item?id=34582385</a></p>
<p>Points: 18</p>
<p># Comments: 4</p>

## TigerBeetle raises $6.4M to power the future of financial accounting infra
 - [https://tigerbeetle.com/blog/2023-01-30-series-seed-announcement/](https://tigerbeetle.com/blog/2023-01-30-series-seed-announcement/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 16:34:57+00:00
 - user: None

<p>Article URL: <a href="https://tigerbeetle.com/blog/2023-01-30-series-seed-announcement/">https://tigerbeetle.com/blog/2023-01-30-series-seed-announcement/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34582181">https://news.ycombinator.com/item?id=34582181</a></p>
<p>Points: 28</p>
<p># Comments: 0</p>

## When Will Fusion Energy Light Our Homes?
 - [https://nautil.us/when-will-fusion-energy-light-our-homes-259169/](https://nautil.us/when-will-fusion-energy-light-our-homes-259169/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:32:30+00:00
 - user: None

<p>Article URL: <a href="https://nautil.us/when-will-fusion-energy-light-our-homes-259169/">https://nautil.us/when-will-fusion-energy-light-our-homes-259169/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580959">https://news.ycombinator.com/item?id=34580959</a></p>
<p>Points: 3</p>
<p># Comments: 3</p>

## Astronomers Say They Have Spotted the Universe’s First Stars
 - [https://www.quantamagazine.org/astronomers-say-they-have-spotted-the-universes-first-stars-20230130/](https://www.quantamagazine.org/astronomers-say-they-have-spotted-the-universes-first-stars-20230130/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:31:54+00:00
 - user: None

<p>Article URL: <a href="https://www.quantamagazine.org/astronomers-say-they-have-spotted-the-universes-first-stars-20230130/">https://www.quantamagazine.org/astronomers-say-they-have-spotted-the-universes-first-stars-20230130/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580947">https://news.ycombinator.com/item?id=34580947</a></p>
<p>Points: 26</p>
<p># Comments: 4</p>

## The benefits of everything (in Emacs) being a buffer
 - [https://mbork.pl/2023-01-30_The_benefits_of_everything_being_a_buffer](https://mbork.pl/2023-01-30_The_benefits_of_everything_being_a_buffer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:31:47+00:00
 - user: None

<p>Article URL: <a href="https://mbork.pl/2023-01-30_The_benefits_of_everything_being_a_buffer">https://mbork.pl/2023-01-30_The_benefits_of_everything_being_a_buffer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580943">https://news.ycombinator.com/item?id=34580943</a></p>
<p>Points: 29</p>
<p># Comments: 7</p>

## FYI: LLVM-project repo has exceeded GitHub upload size limit (2022)
 - [https://discourse.llvm.org/t/fyi-llvm-project-repo-has-exceeded-github-upload-size-limit/63293](https://discourse.llvm.org/t/fyi-llvm-project-repo-has-exceeded-github-upload-size-limit/63293)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:28:53+00:00
 - user: None

<p>Article URL: <a href="https://discourse.llvm.org/t/fyi-llvm-project-repo-has-exceeded-github-upload-size-limit/63293">https://discourse.llvm.org/t/fyi-llvm-project-repo-has-exceeded-github-upload-size-limit/63293</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580907">https://news.ycombinator.com/item?id=34580907</a></p>
<p>Points: 31</p>
<p># Comments: 5</p>

## U.S. No Fly list publicly shared on a hacking forum, government investigating
 - [https://www.bleepingcomputer.com/news/security/us-no-fly-list-shared-on-a-hacking-forum-government-investigating/](https://www.bleepingcomputer.com/news/security/us-no-fly-list-shared-on-a-hacking-forum-government-investigating/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:17:40+00:00
 - user: rumpel
 - tags: hack,noprivacy,leak

<p>Article URL: <a href="https://www.bleepingcomputer.com/news/security/us-no-fly-list-shared-on-a-hacking-forum-government-investigating/">https://www.bleepingcomputer.com/news/security/us-no-fly-list-shared-on-a-hacking-forum-government-investigating/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580705">https://news.ycombinator.com/item?id=34580705</a></p>
<p>Points: 46</p>
<p># Comments: 34</p>

## Electrify America “fries” EVs at charging stations
 - [https://www.teslarati.com/rivian-ford-chevy-fried-electrify-america-video/](https://www.teslarati.com/rivian-ford-chevy-fried-electrify-america-video/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:13:37+00:00
 - user: None

<p>Article URL: <a href="https://www.teslarati.com/rivian-ford-chevy-fried-electrify-america-video/">https://www.teslarati.com/rivian-ford-chevy-fried-electrify-america-video/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580631">https://news.ycombinator.com/item?id=34580631</a></p>
<p>Points: 29</p>
<p># Comments: 11</p>

## Big Tech is using layoffs to crush worker power
 - [https://www.latimes.com/business/technology/story/2023-01-30/column-how-big-tech-is-using-mass-layoffs-to-bring-workers-to-heel](https://www.latimes.com/business/technology/story/2023-01-30/column-how-big-tech-is-using-mass-layoffs-to-bring-workers-to-heel)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 15:09:50+00:00
 - user: None

<p>Article URL: <a href="https://www.latimes.com/business/technology/story/2023-01-30/column-how-big-tech-is-using-mass-layoffs-to-bring-workers-to-heel">https://www.latimes.com/business/technology/story/2023-01-30/column-how-big-tech-is-using-mass-layoffs-to-bring-workers-to-heel</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580560">https://news.ycombinator.com/item?id=34580560</a></p>
<p>Points: 75</p>
<p># Comments: 31</p>

## Philips Plans 6000 Job Cuts; Sees Growth in FY25, Beyond
 - [https://www.nasdaq.com/articles/philips-plans-6000-job-cuts-sees-growth-in-fy25-beyond](https://www.nasdaq.com/articles/philips-plans-6000-job-cuts-sees-growth-in-fy25-beyond)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 14:52:59+00:00
 - user: None

<p>Article URL: <a href="https://www.nasdaq.com/articles/philips-plans-6000-job-cuts-sees-growth-in-fy25-beyond">https://www.nasdaq.com/articles/philips-plans-6000-job-cuts-sees-growth-in-fy25-beyond</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34580281">https://news.ycombinator.com/item?id=34580281</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Cargo airships could be big
 - [https://www.elidourado.com/p/cargo-airships](https://www.elidourado.com/p/cargo-airships)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 14:24:10+00:00
 - user: None

<p>Article URL: <a href="https://www.elidourado.com/p/cargo-airships">https://www.elidourado.com/p/cargo-airships</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579915">https://news.ycombinator.com/item?id=34579915</a></p>
<p>Points: 23</p>
<p># Comments: 21</p>

## Why I’m Still on Strike: Portraits from the HarperCollins Picket Line
 - [https://lithub.com/why-im-still-on-strike-portraits-from-the-harpercollins-picket-line/](https://lithub.com/why-im-still-on-strike-portraits-from-the-harpercollins-picket-line/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 14:17:26+00:00
 - user: None

<p>Article URL: <a href="https://lithub.com/why-im-still-on-strike-portraits-from-the-harpercollins-picket-line/">https://lithub.com/why-im-still-on-strike-portraits-from-the-harpercollins-picket-line/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579842">https://news.ycombinator.com/item?id=34579842</a></p>
<p>Points: 41</p>
<p># Comments: 9</p>

## Show HN: DeepReview (ChatGPT powered CV/cover letter/perf review writer)
 - [https://deepreview.eu/](https://deepreview.eu/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 14:14:15+00:00
 - user: None

<p>Article URL: <a href="https://deepreview.eu/">https://deepreview.eu/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579810">https://news.ycombinator.com/item?id=34579810</a></p>
<p>Points: 11</p>
<p># Comments: 8</p>

## WAN router IP address change blamed for global Microsoft 365 outage
 - [https://www.theregister.com/2023/01/30/wan_router_ip_address_change/](https://www.theregister.com/2023/01/30/wan_router_ip_address_change/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 13:53:58+00:00
 - user: None

<p>Article URL: <a href="https://www.theregister.com/2023/01/30/wan_router_ip_address_change/">https://www.theregister.com/2023/01/30/wan_router_ip_address_change/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579562">https://news.ycombinator.com/item?id=34579562</a></p>
<p>Points: 14</p>
<p># Comments: 0</p>

## A Modern Compiler for the French Tax Code
 - [https://arxiv.org/abs/2011.07966](https://arxiv.org/abs/2011.07966)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 13:22:51+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2011.07966">https://arxiv.org/abs/2011.07966</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579236">https://news.ycombinator.com/item?id=34579236</a></p>
<p>Points: 15</p>
<p># Comments: 3</p>

## Ask HN: Something you’ve done your whole life that you realized is wrong?
 - [https://news.ycombinator.com/item?id=34579175](https://news.ycombinator.com/item?id=34579175)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 13:16:53+00:00
 - user: None

<p>I was helping my son learn to write and realized I’ve been holding the pencil wrong when I write. When I changed my grip to match how my son was learning, it was more comfortable. What have you learned that is different and better than something you’ve always done?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34579175">https://news.ycombinator.com/item?id=34579175</a></p>
<p>Points: 21</p>
<p># Comments: 35</p>

## A bunch of bored kids found a way to unenroll their school Chromebooks
 - [https://sh1mmer.me](https://sh1mmer.me)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 12:40:08+00:00
 - user: None

<p>Article URL: <a href="https://sh1mmer.me">https://sh1mmer.me</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578900">https://news.ycombinator.com/item?id=34578900</a></p>
<p>Points: 83</p>
<p># Comments: 76</p>

## How to find your blind spots
 - [https://www.zeptonaut.com/posts/find-your-blind-spots/](https://www.zeptonaut.com/posts/find-your-blind-spots/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 12:01:54+00:00
 - user: None

<p>Article URL: <a href="https://www.zeptonaut.com/posts/find-your-blind-spots/">https://www.zeptonaut.com/posts/find-your-blind-spots/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578597">https://news.ycombinator.com/item?id=34578597</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Antarctica’s Brunt Ice Shelf Finally Breaks
 - [https://earthobservatory.nasa.gov/images/150880/antarcticas-brunt-ice-shelf-finally-breaks](https://earthobservatory.nasa.gov/images/150880/antarcticas-brunt-ice-shelf-finally-breaks)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:38:18+00:00
 - user: None

<p>Article URL: <a href="https://earthobservatory.nasa.gov/images/150880/antarcticas-brunt-ice-shelf-finally-breaks">https://earthobservatory.nasa.gov/images/150880/antarcticas-brunt-ice-shelf-finally-breaks</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578468">https://news.ycombinator.com/item?id=34578468</a></p>
<p>Points: 27</p>
<p># Comments: 1</p>

## Lone Wolves: Why do some people hate teamwork? (2017)
 - [https://queendomblog.wordpress.com/2017/10/13/lone-wolves-why-do-some-people-hate-teamwork/](https://queendomblog.wordpress.com/2017/10/13/lone-wolves-why-do-some-people-hate-teamwork/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:37:50+00:00
 - user: None

<p>Article URL: <a href="https://queendomblog.wordpress.com/2017/10/13/lone-wolves-why-do-some-people-hate-teamwork/">https://queendomblog.wordpress.com/2017/10/13/lone-wolves-why-do-some-people-hate-teamwork/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578461">https://news.ycombinator.com/item?id=34578461</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>

## Löb and möb: strange loops in Haskell
 - [https://github.com/quchen/articles/blob/master/loeb-moeb.md](https://github.com/quchen/articles/blob/master/loeb-moeb.md)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:29:24+00:00
 - user: None

<p>Article URL: <a href="https://github.com/quchen/articles/blob/master/loeb-moeb.md">https://github.com/quchen/articles/blob/master/loeb-moeb.md</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578411">https://news.ycombinator.com/item?id=34578411</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Disabled and out of work for years, but need some side income, what can I do?
 - [https://news.ycombinator.com/item?id=34578347](https://news.ycombinator.com/item?id=34578347)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:20:08+00:00
 - user: None

<p>I've been disabled since 2018, and my skills in software as such have largely become outdated. I have high problem solving competence in general, but most modern technology stacks people are regularly using seem to be past my time. I'm willing to put some work into correcting the difference, however due to the circumstances I'm in, it would really have to quickly and effectively pay off. It can't be a "maybe useful" kind of scenario.<p>I've come into a situation, largely due to how awful the rent situation is in the United States, where I pretty desperately need to maximize the amount I can earn under disability (which is around $1200 a month) without losing it.<p>I have 8-10 years of overall experience, and regularly program as a hobby, but I have not been employed for years.<p>The last job I worked I primarily wrote python scripts for automating things like data entry into a CMS and other basic front-end web development features using older technology.<p>What can I do to actually be able to get some side income in the software space here in 2023? I've talked with a couple companies in my situation and the answers usually are along the lines of "well we can just hire a new graduate with up-to-date experience and they can work 40 hours a week for us no problem."<p>I'm in my early-to-mid 30s for reference. I'm not really able to get off disability as the condition is severe.<p>---<p>edit:
I've already reduced expenses pretty much as much as I reasonably can do of course.<p>I've explored other options already as well. For things like Fiverr or being hired contract-wise on websites they seem to be races to the bottom so if I'm trying to earn $1200 a month I'm really having to work quite a lot harder and more hours than I'm really currently able to do.<p>I have some applications I've written that generated some interest, however if I want to make any decent money off them I would have to put an extraordinarily large amount of effort into marketing and post-release diligence which may well be past what I'm currently capable of doing.<p>I do tutor students as well intermittenly but it doesn't get me very much.<p>I've written some scripts and other little projects for people I know here and there for small amounts, but it is extremely inconsistent availability even though they trust what I deliver.<p>It seems like finding other leads in that regard is really my only option.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578347">https://news.ycombinator.com/item?id=34578347</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## The Art of Eating Well in Antarctica
 - [https://www.atlasobscura.com/articles/cooking-in-antarctica](https://www.atlasobscura.com/articles/cooking-in-antarctica)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:17:14+00:00
 - user: None

<p>Article URL: <a href="https://www.atlasobscura.com/articles/cooking-in-antarctica">https://www.atlasobscura.com/articles/cooking-in-antarctica</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578331">https://news.ycombinator.com/item?id=34578331</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## SQL should be your default choice for data engineering pipelines
 - [https://www.robinlinacre.com/recommend_sql/](https://www.robinlinacre.com/recommend_sql/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:15:20+00:00
 - user: None

<p>Article URL: <a href="https://www.robinlinacre.com/recommend_sql/">https://www.robinlinacre.com/recommend_sql/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578324">https://news.ycombinator.com/item?id=34578324</a></p>
<p>Points: 36</p>
<p># Comments: 21</p>

## New Distro 'BlendOS' Combines Arch Linux, Fedora Linux and Ubuntu
 - [https://blendos.co/](https://blendos.co/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 11:00:09+00:00
 - user: None

<p>Article URL: <a href="https://blendos.co/">https://blendos.co/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578197">https://news.ycombinator.com/item?id=34578197</a></p>
<p>Points: 19</p>
<p># Comments: 5</p>

## Relational Floating-Point Arithmetic [pdf]
 - [https://www.cs.toronto.edu/~lczhang/sandre_float2021.pdf](https://www.cs.toronto.edu/~lczhang/sandre_float2021.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:44:31+00:00
 - user: None

<p>Article URL: <a href="https://www.cs.toronto.edu/~lczhang/sandre_float2021.pdf">https://www.cs.toronto.edu/~lczhang/sandre_float2021.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578094">https://news.ycombinator.com/item?id=34578094</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## An Update on Leap Seconds
 - [https://dotat.at/@/2022-12-04-leap-seconds.html](https://dotat.at/@/2022-12-04-leap-seconds.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:42:42+00:00
 - user: None

<p>Article URL: <a href="https://dotat.at/@/2022-12-04-leap-seconds.html">https://dotat.at/@/2022-12-04-leap-seconds.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34578077">https://news.ycombinator.com/item?id=34578077</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## Float Compression 0: Intro
 - [https://aras-p.info/blog/2023/01/29/Float-Compression-0-Intro/](https://aras-p.info/blog/2023/01/29/Float-Compression-0-Intro/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:28:17+00:00
 - user: None

<p>Article URL: <a href="https://aras-p.info/blog/2023/01/29/Float-Compression-0-Intro/">https://aras-p.info/blog/2023/01/29/Float-Compression-0-Intro/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577987">https://news.ycombinator.com/item?id=34577987</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## UK Online Safety Bill threatens encryption, secure communication, and reporting
 - [https://cpj.org/2023/01/how-uk-online-safety-bill-threatens-encryption-secure-communication-and-reporting-on-migration/](https://cpj.org/2023/01/how-uk-online-safety-bill-threatens-encryption-secure-communication-and-reporting-on-migration/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:15:36+00:00
 - user: None

<p>Article URL: <a href="https://cpj.org/2023/01/how-uk-online-safety-bill-threatens-encryption-secure-communication-and-reporting-on-migration/">https://cpj.org/2023/01/how-uk-online-safety-bill-threatens-encryption-secure-communication-and-reporting-on-migration/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577914">https://news.ycombinator.com/item?id=34577914</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## Ask HN: Why does every package+module system become a Rube Goldberg machine?
 - [https://news.ycombinator.com/item?id=34577844](https://news.ycombinator.com/item?id=34577844)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:04:40+00:00
 - user: None

<p>A programming language has a "core language" plus a package/module system.
In each successful language, the core language is neat-and-tidy,
but the package/module system is a Rube Goldberg machine.
See JavaScript/TypeScript, Python, or C/C++.<p>Lots of brain cycles are spent on "programming language theory".
We've roughly figured out the primitives required to express real-world computation.<p>In contrast, we apparently have no "package management theory".
We have not figured out the primitives required to express dependencies.
As a result, we keep building new variants and features,
until we end up with <p></p><hr /><p><a href="https://news.ycombinator.com/item?id=34577844"></a></p><p></p><p></p>

## PageRank Algorithm for Graph Databases
 - [https://memgraph.com/blog/pagerank-algorithm-for-graph-databases](https://memgraph.com/blog/pagerank-algorithm-for-graph-databases)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 10:02:49+00:00
 - user: None

<p>Article URL: <a href="https://memgraph.com/blog/pagerank-algorithm-for-graph-databases">https://memgraph.com/blog/pagerank-algorithm-for-graph-databases</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577832">https://news.ycombinator.com/item?id=34577832</a></p>
<p>Points: 31</p>
<p># Comments: 4</p>

## Aicracy – Governed by Algorithms
 - [https://www.aicracy.net](https://www.aicracy.net)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 09:32:31+00:00
 - user: None

<p>Article URL: <a href="https://www.aicracy.net">https://www.aicracy.net</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577617">https://news.ycombinator.com/item?id=34577617</a></p>
<p>Points: 19</p>
<p># Comments: 6</p>

## Ask HN: What's your approach to raising kids?
 - [https://news.ycombinator.com/item?id=34577487](https://news.ycombinator.com/item?id=34577487)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 09:11:33+00:00
 - user: None

<p>Worth saying up front: This isn't for a startup idea or anything like that, just keen to learn from the more-stable-than-Reddit minds of HN so I can get ideas for myself.<p>We have twin girls who are ~6mo old, and we're finally getting out of the "survival" stage and getting to the "parenting" stage. I'm finding that there are so many different schools of thought about absolutely everything, from pregnancy/birth to sleep training to Montessori to gentle parenting.<p>Specific things I'm curious about:<p>- Did you think about what sort of parent you'd like to be and work backwards?
- Did you think about what makes a good kid and work backwards?
- Did you align with a "style" of parenting?
- How did you use technology to help you?
- Did you keep your kids away from technology (like watching TV) for the first couple of years or just go for it?
- What would you do differently if you had your time again?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577487">https://news.ycombinator.com/item?id=34577487</a></p>
<p>Points: 30</p>
<p># Comments: 33</p>

## Yandex ‘leak’ reveals 1,922 search ranking factors
 - [https://searchengineland.com/yandex-search-ranking-factors-leak-392323](https://searchengineland.com/yandex-search-ranking-factors-leak-392323)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 09:10:36+00:00
 - user: None

<p>Article URL: <a href="https://searchengineland.com/yandex-search-ranking-factors-leak-392323">https://searchengineland.com/yandex-search-ranking-factors-leak-392323</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577480">https://news.ycombinator.com/item?id=34577480</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Choosing the Correct High-Bandwidth Memory
 - [https://semiengineering.com/choosing-the-correct-high-bandwidth-memory/](https://semiengineering.com/choosing-the-correct-high-bandwidth-memory/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 08:01:46+00:00
 - user: None

<p>Article URL: <a href="https://semiengineering.com/choosing-the-correct-high-bandwidth-memory/">https://semiengineering.com/choosing-the-correct-high-bandwidth-memory/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34577056">https://news.ycombinator.com/item?id=34577056</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Ask HN: Did improving conversation and listening skills win you anything big?
 - [https://news.ycombinator.com/item?id=34576976](https://news.ycombinator.com/item?id=34576976)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 07:49:01+00:00
 - user: None

<p>We hear that improving how we converse or listen one to one with people says a lot about how we treat or empathize with them in real life situations. Is that actually true?<p>What other aspects of life improvements have you seen with improving your skills in this domain?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34576976">https://news.ycombinator.com/item?id=34576976</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Deep dive into diagram layout engines: Minimizing hierarchical edge crossings
 - [https://www.terrastruct.com/blog/post/diagram-layout-engines-crossing-minimization/](https://www.terrastruct.com/blog/post/diagram-layout-engines-crossing-minimization/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 07:43:01+00:00
 - user: None

<p>Article URL: <a href="https://www.terrastruct.com/blog/post/diagram-layout-engines-crossing-minimization/">https://www.terrastruct.com/blog/post/diagram-layout-engines-crossing-minimization/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34576941">https://news.ycombinator.com/item?id=34576941</a></p>
<p>Points: 7</p>
<p># Comments: 1</p>

## Covid-19 and other pandemics require a coherent response strategy
 - [https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)02489-8/fulltext](https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)02489-8/fulltext)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 07:24:00+00:00
 - user: None

<p>Article URL: <a href="https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)02489-8/fulltext">https://www.thelancet.com/journals/lancet/article/PIIS0140-6736(22)02489-8/fulltext</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34576812">https://news.ycombinator.com/item?id=34576812</a></p>
<p>Points: 16</p>
<p># Comments: 0</p>

## Story Structure 101: Super Basic Shit (By Dan Harmon)
 - [https://channel101.fandom.com/wiki/Story_Structure_101:_Super_Basic_Shit](https://channel101.fandom.com/wiki/Story_Structure_101:_Super_Basic_Shit)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 05:23:25+00:00
 - user: None

<p>Article URL: <a href="https://channel101.fandom.com/wiki/Story_Structure_101:_Super_Basic_Shit">https://channel101.fandom.com/wiki/Story_Structure_101:_Super_Basic_Shit</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34576085">https://news.ycombinator.com/item?id=34576085</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Google executive fired after female boss groped him
 - [https://www.news.com.au/technology/online/internet/google-executive-fired-after-female-boss-groped-him/news-story/1901a730cb7075916e90a9f072732757](https://www.news.com.au/technology/online/internet/google-executive-fired-after-female-boss-groped-him/news-story/1901a730cb7075916e90a9f072732757)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 04:26:44+00:00
 - user: None

<p>Article URL: <a href="https://www.news.com.au/technology/online/internet/google-executive-fired-after-female-boss-groped-him/news-story/1901a730cb7075916e90a9f072732757">https://www.news.com.au/technology/online/internet/google-executive-fired-after-female-boss-groped-him/news-story/1901a730cb7075916e90a9f072732757</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575768">https://news.ycombinator.com/item?id=34575768</a></p>
<p>Points: 43</p>
<p># Comments: 6</p>

## The High Cost of Expensive Housing (and How Auckland Fixed It)
 - [https://brettongoods.substack.com/p/the-high-cost-of-expensive-housing](https://brettongoods.substack.com/p/the-high-cost-of-expensive-housing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 04:05:10+00:00
 - user: None

<p>Article URL: <a href="https://brettongoods.substack.com/p/the-high-cost-of-expensive-housing">https://brettongoods.substack.com/p/the-high-cost-of-expensive-housing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575658">https://news.ycombinator.com/item?id=34575658</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## “Foundations of Data Science”, Free Book by Hopcroft and Kannan [pdf]
 - [https://www.cs.cornell.edu/jeh/book.pdf?file=book.pdf](https://www.cs.cornell.edu/jeh/book.pdf?file=book.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 04:01:44+00:00
 - user: None

<p>Article URL: <a href="https://www.cs.cornell.edu/jeh/book.pdf?file=book.pdf">https://www.cs.cornell.edu/jeh/book.pdf?file=book.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575637">https://news.ycombinator.com/item?id=34575637</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Where Our Gasoline Comes From
 - [https://www.eia.gov/energyexplained/gasoline/where-our-gasoline-comes-from.php](https://www.eia.gov/energyexplained/gasoline/where-our-gasoline-comes-from.php)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 03:55:47+00:00
 - user: None

<p>Article URL: <a href="https://www.eia.gov/energyexplained/gasoline/where-our-gasoline-comes-from.php">https://www.eia.gov/energyexplained/gasoline/where-our-gasoline-comes-from.php</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575601">https://news.ycombinator.com/item?id=34575601</a></p>
<p>Points: 10</p>
<p># Comments: 0</p>

## What Does It Mean to Trademark a Color?
 - [https://www.atlasobscura.com/articles/jardin-marjorelle-trademark-color](https://www.atlasobscura.com/articles/jardin-marjorelle-trademark-color)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 03:28:13+00:00
 - user: None

<p>Article URL: <a href="https://www.atlasobscura.com/articles/jardin-marjorelle-trademark-color">https://www.atlasobscura.com/articles/jardin-marjorelle-trademark-color</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575469">https://news.ycombinator.com/item?id=34575469</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## SBF's Lawyer Scrambles to Explain Signal Messages to Potential Witnesses [pdf]
 - [https://ia601406.us.archive.org/2/items/gov.uscourts.deb.188450/gov.uscourts.deb.188450.587.0.pdf](https://ia601406.us.archive.org/2/items/gov.uscourts.deb.188450/gov.uscourts.deb.188450.587.0.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 03:16:37+00:00
 - user: None

<p>Article URL: <a href="https://ia601406.us.archive.org/2/items/gov.uscourts.deb.188450/gov.uscourts.deb.188450.587.0.pdf">https://ia601406.us.archive.org/2/items/gov.uscourts.deb.188450/gov.uscourts.deb.188450.587.0.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575420">https://news.ycombinator.com/item?id=34575420</a></p>
<p>Points: 20</p>
<p># Comments: 8</p>

## A Genius at Suffering
 - [https://newcriterion.com/issues/2023/2/a-genius-at-suffering](https://newcriterion.com/issues/2023/2/a-genius-at-suffering)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 02:35:28+00:00
 - user: None

<p>Article URL: <a href="https://newcriterion.com/issues/2023/2/a-genius-at-suffering">https://newcriterion.com/issues/2023/2/a-genius-at-suffering</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575213">https://news.ycombinator.com/item?id=34575213</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The free money machine that went into reverse: Grayscale Bitcoin Trust
 - [https://newsletter.mollywhite.net/p/grayscale-bitcoin-trust-the-free](https://newsletter.mollywhite.net/p/grayscale-bitcoin-trust-the-free)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 02:19:20+00:00
 - user: None

<p>Article URL: <a href="https://newsletter.mollywhite.net/p/grayscale-bitcoin-trust-the-free">https://newsletter.mollywhite.net/p/grayscale-bitcoin-trust-the-free</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34575112">https://news.ycombinator.com/item?id=34575112</a></p>
<p>Points: 46</p>
<p># Comments: 3</p>

## Show HN: Train CIFAR10 to 94% in under 10 seconds on a single A100, world record
 - [https://github.com/tysam-code/hlb-CIFAR10](https://github.com/tysam-code/hlb-CIFAR10)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 01:58:57+00:00
 - user: None

<p>Hi,<p>My career is currently in this field, and I created this project as (effectively, among other things) a living resume, and to also be a really great workbench for hacking/experimenting on different methods. Testing and getting a feel for how different methods work within this framework is truly a delight, and quite simple/fast. Additionally, generally speaking, many of the mathematical concepts should transfer, so this (for me) has been a really great proving grounds in testing out how something might work in a different place in the real world. We hope to get under 2 seconds of training time (for 94%) within about two years or so, so stay tuned for updates as we continue to push more changes that take us faster and faster than our starting point of ~18.1 seconds or so.<p>By the way, this architecture and training hyperparameters do indeed scale well, just increase epochs from 10->80 and base_depth from 64->128 and you'll have about 95.77% accuracy in about 188 seconds or so (just over 3 minutes :D). That alone is a huge boon! Great to see scaling laws working well within this very, very tight hyperparameter resolution.<p>Feel free to let me know if you have any questions, Hacker News always seems to get me the most traffic. I really love talking about this project, and can't really seem to find anyone to nerd out about it with. This is very, very cool stuff! So feel free to leave a comment, and I'd love to jump in and chat about it! :D :) <3 <3 :))))</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34574993">https://news.ycombinator.com/item?id=34574993</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Cyclic Combinational Circuits [pdf]
 - [http://www.mriedel.ece.umn.edu/wiki/images/7/7a/Riedel_Cyclic_Combinational_Circuits.pdf](http://www.mriedel.ece.umn.edu/wiki/images/7/7a/Riedel_Cyclic_Combinational_Circuits.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 01:23:53+00:00
 - user: None

<p>Article URL: <a href="http://www.mriedel.ece.umn.edu/wiki/images/7/7a/Riedel_Cyclic_Combinational_Circuits.pdf">http://www.mriedel.ece.umn.edu/wiki/images/7/7a/Riedel_Cyclic_Combinational_Circuits.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34574771">https://news.ycombinator.com/item?id=34574771</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Scale transform -50 x*x + 240 x – 7
 - [https://statmodeling.stat.columbia.edu/2023/01/29/you-wish-youre-first-to-invent-this-scale-transform-50-xx-240-x-7/](https://statmodeling.stat.columbia.edu/2023/01/29/you-wish-youre-first-to-invent-this-scale-transform-50-xx-240-x-7/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-30 00:58:11+00:00
 - user: None

<p>Article URL: <a href="https://statmodeling.stat.columbia.edu/2023/01/29/you-wish-youre-first-to-invent-this-scale-transform-50-xx-240-x-7/">https://statmodeling.stat.columbia.edu/2023/01/29/you-wish-youre-first-to-invent-this-scale-transform-50-xx-240-x-7/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34574570">https://news.ycombinator.com/item?id=34574570</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>
