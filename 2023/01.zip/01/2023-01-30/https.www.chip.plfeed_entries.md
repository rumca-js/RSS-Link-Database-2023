# Source Chip.pl, Source URL:https://www.chip.pl/feed, Source language: pl-PL

## „Kochaj wyjątkowe momenty”, czyli promocje walentynkowe Huawei
 - [https://www.chip.pl/2023/01/huawei-promocja-na-walentynki](https://www.chip.pl/2023/01/huawei-promocja-na-walentynki)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 20:01:16+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/01/huawei-freebuds-5i-07.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/huawei-freebuds-5i-07.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Święto zakochanych to świetny moment by obdarować bliską osobę. Z tej okazji Huawei ma do zaproponowania kosz interesujących promocji dla niego i dla niej. A może zrobisz przy okazji prezent sobie? Oferty są dostępne zarówno online w sklepie huawei.pl, jak i w dużych sieciach handlowych. Na co warto zwrócić uwagę? Promocją „Kochaj wyjątkowe momenty” objęte [&#8230;]</p>

## Przeoczyliśmy wiadomość od obcych? Tak sugeruje sztuczna inteligencja
 - [https://www.chip.pl/2023/01/wiadomosc-od-obcych-sztuczna-inteligencja](https://www.chip.pl/2023/01/wiadomosc-od-obcych-sztuczna-inteligencja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 20:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="707" src="https://konto.chip.pl/wp-content/uploads/2023/01/kosmici.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/kosmici.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ludzkość od dawna szuka dowodów na to, że gdzieś we wszechświecie istnieją inne cywilizacje, których przedstawiciele próbowali się z nami skontaktować. A co, jeśli faktycznie tak było, lecz to przegapiliśmy? Jeśli chodzi o Układ Słoneczny, to nawet w nim istnieje kilka obiektów, które mogłyby stanowić potencjalne miejsca istnienia życia, choć raczej trudno oczekiwać, by były [&#8230;]</p>

## Rynek smartfonów zalicza rekordowe spadki. Tak źle nie było od dekady
 - [https://www.chip.pl/2023/01/rynek-smartfonow-2022-rok-raport](https://www.chip.pl/2023/01/rynek-smartfonow-2022-rok-raport)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 19:30:47+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="788" src="https://konto.chip.pl/wp-content/uploads/2022/06/smartfon.jpg" style="margin-bottom: 10px;" width="1400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/06/smartfon.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czas, w którym analitycy radzili producentom smartfonów przeczekanie kryzysu, chyba dobiegł końca. Teraz, w obliczu kolejnych spadków dostaw, raczej trzeba zacząć wymyślać nowe strategie, bo na poprawę się zanosi. W Chinach tak źle nie było od dekady, ale reszta świata nie ma co się cieszyć, bo i tutaj nie ma mowy o praktycznie żadnych wzrostach. [&#8230;]</p>

## Jeden z 5000 laptopów Lenovo ThinkPad X1 Carbon G10 30th Anniversary Edition trafił na moje biurko
 - [https://www.chip.pl/2023/01/jeden-z-5000-laptopow-lenovo-thinkpad-x1-carbon-g10-30th-anniversary-edition-trafil-na-moje-biurko](https://www.chip.pl/2023/01/jeden-z-5000-laptopow-lenovo-thinkpad-x1-carbon-g10-30th-anniversary-edition-trafil-na-moje-biurko)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 19:10:34+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/lenovo-thinkpad-x1-carbon-30th-anniversary-25.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/lenovo-thinkpad-x1-carbon-30th-anniversary-25.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ma numer 2100 i jest jednym z 5000 egzemplarzy laptopów Lenovo ThinkPad X1 Carbon G10 przygotowanych z okazji 30. urodzin marki ThinkPad. Taki sprzęt wylądował na moim biurku i&#8230; czaruje. Nie tylko swoim wyglądem. To nie jest recenzja Lenovo ThinkPad X1 Carbon G10 30th Anniversary Edition Czym jest Lenovo ThinkPad X1 Carbon wie każdy, kto [&#8230;]</p>

## Sztuczna inteligencja może sobie generować muzykę z tekstu, ale ja nie zamierzam jej słuchać
 - [https://www.chip.pl/2023/01/sztuczna-inteligencja-generowanie-muzyki-z-tekstu](https://www.chip.pl/2023/01/sztuczna-inteligencja-generowanie-muzyki-z-tekstu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 18:30:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/mikrofon.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/mikrofon.jpg" style="display: block; margin: 1em auto;" /></p>
<p>W ostatnich dniach coraz głośniej w sieci o eksperymentach Google z MusicLM, modelem językowym sztucznej inteligencji skupionym na generowaniu muzyki na podstawie wpisanego przez użytkownika tekstu. Nie mam nawet ułamka niezbędnych kompetencji, żeby oceniać to rozwiązanie pod względem technicznym. Mogę za to podzielić się swoimi odczuciami ze słuchania próbek MusicLM i mojego do takich narzędzi [&#8230;]</p>

## Wszechświat cieplejszy niż powinien. Znamy winowajcę
 - [https://www.chip.pl/2023/01/wszechswiat-i-ciemne-fotony](https://www.chip.pl/2023/01/wszechswiat-i-ciemne-fotony)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 18:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="612" src="https://konto.chip.pl/wp-content/uploads/2021/06/wszechswiat.jpg" style="margin-bottom: 10px;" width="1300" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/06/wszechswiat.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Nowe badania wskazują, że Wszechświat jest nieco gorętszy niż powinien. Winne tego stanu rzeczy są tajemnicze cząstki elementarne, zwane ciemnymi fotonami. Obserwacje astronomiczne zdają sie sugerować, że gaz międzygalaktyczny we Wszechświecie jest nieco gorętszy niż powinien. Naukowcy wykorzystali symulacje komputerowe, aby zaproponować rozwiązanie tego stanu rzeczy &#8211; egzotyczną formę ciemnej materii, znaną jako ciemne fotony. [&#8230;]</p>

## Apple skopiuje najlepszą cechę swojego rywala. Ta funkcja powinna trafić do każdego tabletu
 - [https://www.chip.pl/2023/01/apple-zamontuje-podporke-w-skladanym-ipadzie](https://www.chip.pl/2023/01/apple-zamontuje-podporke-w-skladanym-ipadzie)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 17:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1306" src="https://konto.chip.pl/wp-content/uploads/2022/10/ipados-16-ipad.jpg" style="margin-bottom: 10px;" width="1960" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/10/ipados-16-ipad.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Samsung już od lat śmieje się z Apple’a, że ten nadal nie ma składanego smartfona. Wiele jednak mówi się o tym, że kiedy gigant z Cupertino pójdzie w składaki, to pierwszym urządzenie wcale nie będzie składany iPhone a iPad. Teraz doniesienia wspominają, że na jego premierę trzeba będzie trochę poczekać. Cóż, czekamy już od dawna. [&#8230;]</p>

## Ekran smartfona przyprawia mnie mdłości. Koncepcja urządzenia do wszystkiego wydaje mi się coraz bardziej chybiona
 - [https://www.chip.pl/2023/01/uzaleznienie-od-smartfona-2023](https://www.chip.pl/2023/01/uzaleznienie-od-smartfona-2023)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 16:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1281" src="https://konto.chip.pl/wp-content/uploads/2022/11/motorola-razr-2022-czy-galaxy-z-flip-4-opinie-7-1.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/motorola-razr-2022-czy-galaxy-z-flip-4-opinie-7-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Kojarzycie ten kultowy GIF, na którym widać, jak wiele rzeczy &#8211; niegdyś powszechnych w naszym życiu &#8211; zastąpił nam smartfon? Nie wiem, czy to kwestia wieku, zmęczenia, zdziadzienia czy rzeczywiście coś w tym jest, ale ostatnimi czasy coraz częściej mam wrażenie, że koncepcja urządzenia “wszystko w jednym” jest nieco chybiona. Był czas, gdy bez reszty [&#8230;]</p>

## Darmowy laptop nie tylko dla uczniów – nauczyciele też dostaną kiełbasę wyborczą
 - [https://www.chip.pl/2023/01/darmowe-laptopy-dla-nauczycieli-co-wiemy](https://www.chip.pl/2023/01/darmowe-laptopy-dla-nauczycieli-co-wiemy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 15:30:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1707" src="https://konto.chip.pl/wp-content/uploads/2023/01/Huawei-Matebook-D16-zdalna-nauka-1.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Huawei-Matebook-D16-zdalna-nauka-1.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ledwo nieco uspokoił się szum związany z planem rozdania przez rząd 370 tys. laptopów dla uczniów klas IV w roku 2023, a okazuje się, że na tym nie koniec. Dalsze plany obejmują bowiem także podobny program dla nauczycieli O ile w przypadku uczniów program ma być cykliczny i każdy kolejny rocznik czwartoklasistów miałby być nim [&#8230;]</p>

## Autonomiczne taksówki narobiły bałaganu. Władze miasta chcą wstrzymania testów
 - [https://www.chip.pl/2023/01/autonomiczne-taksowki-waymo-cruise-testy](https://www.chip.pl/2023/01/autonomiczne-taksowki-waymo-cruise-testy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 15:00:00+00:00
 - user: None

<img alt="Autonomiczne taksówki w San Francisco" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/01/Autonomiczne-taksowki-San-Francisco.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Autonomiczne-taksowki-San-Francisco.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Odkąd tylko autonomiczne samochody stały się bywalcami dróg publicznych w ramach całej masy testów lub programów rozwojowych o różnym stopniu zaawansowania, jedni są nimi zachwyceni, a drudzy dostrzegają w nich problem. Ostatnie obserwacje na ulicach San Franisco zapewniły pożywkę tym drugim. Urzędnicy zaczęli zgłaszać oficjalne wnioski co do ukrócenia testów autonomicznych samochodów firm Cruise i [&#8230;]</p>

## Test Tronsmart Halo 100. Oto najlepszy głośnik bezprzewodowy Tronsmarta
 - [https://www.chip.pl/2023/01/tronsmart-halo-100-test-recenzja-opinia](https://www.chip.pl/2023/01/tronsmart-halo-100-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 14:30:00+00:00
 - user: None

<img alt="Tronsmart Halo 100" class="attachment-full size-full wp-post-image" height="1440" src="https://konto.chip.pl/wp-content/uploads/2023/01/Test-Tronsmart-Halo-100-1-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Test-Tronsmart-Halo-100-1-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Głośniki Tronsmarta mają wzięcie. Tak przynajmniej wynika z częstotliwości premier nowych modeli od tego producenta, który teraz postanowił odświeżyć serię bardziej tradycyjnych &#8220;mini-kolumn&#8221; dźwiękowych swoim najbardziej imponującym w całej ofercie głośnikiem Halo 100. Czego możecie od niego oczekiwać? O tym właśnie opowiem poniżej.  Tronsmart to istny król w segmencie głośników mobilnych. Halo 100 z całą [&#8230;]</p>

## Te panele słoneczne są całkowicie czarne. Produkują je w malutkim kraju, który wyrasta na potęgę
 - [https://www.chip.pl/2023/01/panele-sloneczne-calkowicie-czarne](https://www.chip.pl/2023/01/panele-sloneczne-calkowicie-czarne)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 14:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/solar-panels-6940440_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/solar-panels-6940440_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Marzeniem wielu korzystających z paneli słonecznych jest to, aby mogły się one spójnie komponować z otoczeniem. Zunifikowany kształt i przede wszystkim kolor obecnie dostępnych paneli słonecznych na rynku nie zawsze pasuje do miejsca, w którym chcemy je zamontować. Słoweńska firma ma jednak rozwiązanie na ten problem. Przynajmniej częściowe. Słoweński producent ogniw fotowoltaicznych Bisol przedstawił w [&#8230;]</p>

## Zainwestują miliardy, byleby tylko wyprzedzić Chińczyków. To tam powstaną pierwsze 2-nm procesory
 - [https://www.chip.pl/2023/01/pierwsze-2-nm-procesory-rapidus](https://www.chip.pl/2023/01/pierwsze-2-nm-procesory-rapidus)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 12:30:00+00:00
 - user: None

<img alt="Pierwsze 2-nm procesory" class="attachment-full size-full wp-post-image" height="1002" src="https://konto.chip.pl/wp-content/uploads/2021/12/Chinskie-procesory-graficzne-JM9-coraz-blizej.-Jaki-poziom-wydajnosci-zaoferuja-1-2.jpg" style="margin-bottom: 10px;" width="1600" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/12/Chinskie-procesory-graficzne-JM9-coraz-blizej.-Jaki-poziom-wydajnosci-zaoferuja-1-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Wygląda na to, że TSMC doczeka się godnej konkurencji. Z najnowszych informacji wynika, że podczas gdy rozwijające się w wysokim tempie Chiny mogą zostać utemperowane nowymi sankcjami, Japonia poczyni ogromne inwestycje w rodzimego producenta układów scalonych Rapidus, który ma wielkie ambicje. Japoński przemysł półprzewodnikowy na sterydach. Ogromne inwestycje w Rapidus przekują pierwsze 2-nm procesory na [&#8230;]</p>

## Game Boy na miarę 2023 roku. Ta retrokonsolka przywróciła mi radość z grania
 - [https://www.chip.pl/2023/01/miyoo-mini-v2-opinie-gdzie-kupic](https://www.chip.pl/2023/01/miyoo-mini-v2-opinie-gdzie-kupic)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

<img alt="Miyoo Mini v2" class="attachment-full size-full wp-post-image" height="1333" src="https://konto.chip.pl/wp-content/uploads/2023/01/miyoo-mini-v2-2-of-10.jpg" style="margin-bottom: 10px;" width="2000" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/miyoo-mini-v2-2-of-10.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeżeli &#8211; podobnie jak ja &#8211; wychowałeś się w latach 90., istnieje duża szansa, że Game Boy jest dla ciebie ikoną całej epoki. Moje niespełnione marzenie z dzieciństwa zrealizowałem dopiero teraz, ale za to w arcyciekawej odsłonie na miarę 2023 r. Poznajcie retrokonsolkę Miyoo Mini v2. W latach 90. na moim podwórku tylko jeden szczęśliwiec [&#8230;]</p>

## Był antyplagiat, będzie antychatbot. Prestiżowa uczelnia pracuje nad narzędziem do walki z ChatGPT
 - [https://www.chip.pl/2023/01/antychatbot-detectgpt-oszustwa-chatgpt](https://www.chip.pl/2023/01/antychatbot-detectgpt-oszustwa-chatgpt)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 10:30:00+00:00
 - user: None

<img alt="Antychatbot DetectGPT to bat na ChatGPT" class="attachment-full size-full wp-post-image" height="710" src="https://konto.chip.pl/wp-content/uploads/2023/01/Antychatbot-DetectGPT-Narzedzie-do-walki-z-ChatGPT-2.jpg" style="margin-bottom: 10px;" width="1624" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Antychatbot-DetectGPT-Narzedzie-do-walki-z-ChatGPT-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zespół ze Stanford University rozwija obecnie narzędzie o nazwie DetectGPT, aby uzbroić nauczycieli i wykładowców w odpowiednie narzędzie do walki z rosnącą tendencją uczniów do generowania swoich prac domowych z wykorzystaniem systemów sztucznej inteligencji pokroju m.in. ChatGPT. Korzystacie z ChatGPT do odrabiania prac domowych? Strzeżcie się, bo z DetectGPT nauczyciele przejrzą was na wylot Jeszcze [&#8230;]</p>

## W sklepach IKEA pojawi się wkrótce nowy sprzęt. Będziesz chciał go mieć w swoim domu
 - [https://www.chip.pl/2023/01/w-sklepach-ikea-pojawi-sie-wkrotce-nowy-sprzet](https://www.chip.pl/2023/01/w-sklepach-ikea-pojawi-sie-wkrotce-nowy-sprzet)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 10:27:30+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="941" src="https://konto.chip.pl/wp-content/uploads/2023/01/ikea-eneby-glosnik-bt.jpg" style="margin-bottom: 10px;" width="1400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/ikea-eneby-glosnik-bt.jpg" style="display: block; margin: 1em auto;" /></p>
<p>O designie produktów nie mam zielonego pojęcia, więc mogę bazować wyłącznie na odczuciach, a te w większości przypadków w stosunku do produktów sklepu IKEA są jak dotąd pozytywne. Być może dlatego żywię przekonanie, że szykowana przez Szwedów nowa wersja głośnika Bluetooth ENEBY okaże się strzałem w dziesiątkę. To nic, że teraz ma się nazywać VAPPEBY, [&#8230;]</p>

## Chiny opracowały nowatorski system przechwytywania. Jeśli to prawda, inne kraje mają problem
 - [https://www.chip.pl/2023/01/chiny-hipersoniczny-wyscig-obrona-przeciwlotnicza](https://www.chip.pl/2023/01/chiny-hipersoniczny-wyscig-obrona-przeciwlotnicza)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 09:30:00+00:00
 - user: None

<img alt="Pociski przechwytujące nowej generacji" class="attachment-full size-full wp-post-image" height="1063" src="https://konto.chip.pl/wp-content/uploads/2022/11/Beda-chronic-USA-przed-pociskami-balistycznymi.-Pociski-przechwytujace-nowej-generacji-nadchodza-scaled.jpg" style="margin-bottom: 10px;" width="2560" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/11/Beda-chronic-USA-przed-pociskami-balistycznymi.-Pociski-przechwytujace-nowej-generacji-nadchodza-scaled.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeśli uwierzymy we wszystko, czym Chiny chwalą się na lewo i prawo w opracowaniach naukowych, odniesiemy wrażenie, że to właśnie państwo prowadzi w hipersonicznym wyścigu. Zwłaszcza jeśli weźmiemy pod uwagę niechęć Chin do udostępniania informacji na temat swoich systemów wojskowych, które najwyraźniej mogą wkrótce wzbogacić się o systemy obronne przed pociskami hipersonicznymi. Zestrzelenie pocisków hipersonicznych [&#8230;]</p>

## Rolls-Royce nie tylko samochodami żyje. Niedługo wyśle na Księżyc pierwszych mieszkańców
 - [https://www.chip.pl/2023/01/rolls-royce-reaktor-baza-na-ksiezycu](https://www.chip.pl/2023/01/rolls-royce-reaktor-baza-na-ksiezycu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 08:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="843" src="https://konto.chip.pl/wp-content/uploads/2023/01/reaktor.jpeg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/reaktor.jpeg" style="display: block; margin: 1em auto;" /></p>
<p>NASA, DARPA i Rolls-Royce podejmą współpracę mającą na celu zaprojektowanie reaktora jądrowego, który posłuży do zasilania bazy na Księżycu. Ta miałaby powstać w ramach programu Artemis, który zakłada powrót człowieka na Srebrny Glob i utworzenie na miejscu długoterminowych placówek. Rolls Royce słynie ze swojego zaangażowania w projektowanie części i silników, które można znaleźć zarówno w [&#8230;]</p>

## Z takimi okrętami podwodnymi można trzymać w garści cały świat. Turcja właśnie chce je stworzyć
 - [https://www.chip.pl/2023/01/bezzalogowe-okrety-podwodne-turcja](https://www.chip.pl/2023/01/bezzalogowe-okrety-podwodne-turcja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-30 05:05:46+00:00
 - user: None

<img alt="Tureckie bezzałogowe okręty podwodne" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/01/Tureckie-bezzalogowe-okrety-podwodne.jpg" style="margin-bottom: 10px;" width="1904" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Tureckie-bezzalogowe-okrety-podwodne.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Turecki przemysł obronny dąży obecnie do opracowania typu okrętów podwodnych, który mógłby wnieść koncept triady nuklearnej na zupełnie nowy poziom. Mowa bowiem o całkowicie bezzałogowych okrętach podwodnych, które z odpowiednim wyposażeniem byłyby bronią wręcz idealną w dzisiejszych niepewnych czasach. Bezzałogowe okręty podwodne z pociskami nuklearnymi to prosty przepis na zrewolucjonizowanie jednej części triady nuklearnej Jest [&#8230;]</p>
