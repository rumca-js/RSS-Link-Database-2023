# Source Washington Examiner - politics, Source URL:https://feeds.feedburner.com/dcexaminer/Politics, Source language: en-US

## Utah county commissioner threatens officer over son's arrest
 - [https://www.washingtonexaminer.com/news/utah-county-commissioner-threatens-cop-son-arrest](https://www.washingtonexaminer.com/news/utah-county-commissioner-threatens-cop-son-arrest)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-01-30 21:01:54+00:00
 - user: None

A Utah county commissioner was caught on camera threatening a sheriff's deputy over his son's arrest and demanding to see the warrant.
