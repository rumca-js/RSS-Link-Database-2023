# Source Epoch times world, Source URL:https://www.theepochtimes.com/c-world/feed/, Source language: en-US

## Trump Reiterates Call for Peaceful Resolution to Ukraine War
 - [https://www.theepochtimes.com/trump-reiterates-call-for-peaceful-resolution-to-ukraine-war_5020815.html](https://www.theepochtimes.com/trump-reiterates-call-for-peaceful-resolution-to-ukraine-war_5020815.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 22:51:02+00:00
 - user: None

Former President Donald Trump addresses the crowd during a 2024 election campaign event in Columbia, South Carolina, on Jan. 28, 2023. (Logan Cyrus/AFP via Getty Images)

## Jordan Peterson Sets Up ‘Pro-Human’ Alternative to Globalist-Corporatist World Economic Forum
 - [https://www.theepochtimes.com/jordan-peterson-sets-up-pro-human-alternative-to-globalist-corporatist-world-economic-forum_5019757.html](https://www.theepochtimes.com/jordan-peterson-sets-up-pro-human-alternative-to-globalist-corporatist-world-economic-forum_5019757.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 22:27:00+00:00
 - user: None

Jordan Peterson speaks at the 2018 Student Action Summit at the Palm Beach County Convention Center in West Palm Beach, Fla., on Dec. 20, 2018. (Gage Skidmore/CC BY-SA 2.0)

## ‘We Need a Record’: National Citizens’ Inquiry on COVID-19 Response Set to Begin in March
 - [https://www.theepochtimes.com/we-need-a-record-national-citizens-inquiry-on-covid-19-response-set-to-begin-in-march_5017543.html](https://www.theepochtimes.com/we-need-a-record-national-citizens-inquiry-on-covid-19-response-set-to-begin-in-march_5017543.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 22:26:58+00:00
 - user: None

Traffic on Highway 401 passes under a COVID-19 sign in Toronto on April 6, 2020. (Frank Gunn/The Canadian Press)

## Trudeau Says He Will Facilitate Meeting Between Anti-Islamophobia Rep and Blanchet
 - [https://www.theepochtimes.com/trudeau-says-he-will-facilitate-meeting-between-anti-islamophobia-rep-and-blanchet_5020678.html](https://www.theepochtimes.com/trudeau-says-he-will-facilitate-meeting-between-anti-islamophobia-rep-and-blanchet_5020678.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 21:25:54+00:00
 - user: None

Bloc Québécois Leader Yves-Francois Blanchet speaks with reporters in Ottawa on Oct. 26, 2022. (The Canadian Press/Adrian Wyld)

## ‘Unprecedented Swing in Housing Demand’: Report Says 995,000 Arrivals to Canada Straining Housing Supply
 - [https://www.theepochtimes.com/unprecedented-swing-in-housing-demand-report-says-995000-arrivals-to-canada-straining-housing-supply_5020991.html](https://www.theepochtimes.com/unprecedented-swing-in-housing-demand-report-says-995000-arrivals-to-canada-straining-housing-supply_5020991.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 21:16:11+00:00
 - user: None

A person walks by a row of houses in Toronto on July 12, 2022. (Cole Burston/The Canadian Press)

## Bolsonaro, Brazil’s Former President, Has Applied for US Tourist Visa
 - [https://www.theepochtimes.com/bolsonaro-brazils-former-president-has-applied-for-us-tourist-visa_5020989.html](https://www.theepochtimes.com/bolsonaro-brazils-former-president-has-applied-for-us-tourist-visa_5020989.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 21:15:47+00:00
 - user: None

Brazil's President Jair Bolsonaro looks on after a ceremony about the National Policy for Education at the Planalto Palace in Brasilia, Brazil, on June 20, 2022. (Ueslei Marcelino/Reuters)

## Dozens of Canadian Universities Collaborated With Chinese Military Institute in Academic Research: Report
 - [https://www.theepochtimes.com/dozens-of-canadian-universities-collaborated-with-chinese-military-institute-in-academic-research-report_5019902.html](https://www.theepochtimes.com/dozens-of-canadian-universities-collaborated-with-chinese-military-institute-in-academic-research-report_5019902.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 21:08:07+00:00
 - user: None

Military vehicles carrying HHQ-9B surface-to-air missiles participate in a military parade at Tiananmen Square in Beijing on October 1, 2019, to mark the 70th anniversary of the founding of the Peoples Republic of China. (GREG BAKER/AFP via Getty Images)

## Tempering Steel: Activist Reflects on Meaning of Suffering After Reading Article by Founder of Falun Gong
 - [https://www.theepochtimes.com/tempering-steel-activist-reflects-on-meaning-of-suffering-after-reading-article-by-founder-of-falun-gong_5019929.html](https://www.theepochtimes.com/tempering-steel-activist-reflects-on-meaning-of-suffering-after-reading-article-by-founder-of-falun-gong_5019929.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 20:29:59+00:00
 - user: None

Duan Jinggang in Jokhang Temple, Tibet, in 2011. (Courtesy of Duan Jinggang)

## Federal Bank Awarded Senior Staff $104M in Bonuses, Raises During Pandemic: Taxpayers’ Federation: Taxpayers’ Federation
 - [https://www.theepochtimes.com/federal-bank-awarded-senior-staff-104m-in-bonuses-and-raises-during-pandemic-taxpayers-federation_5020505.html](https://www.theepochtimes.com/federal-bank-awarded-senior-staff-104m-in-bonuses-and-raises-during-pandemic-taxpayers-federation_5020505.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 20:23:26+00:00
 - user: None

King Street West, a major commercial and entertainment district in  in Toronto, on April 23, 2020. (Emma McIntyre/Getty Images)

## Singh Meeting With Trudeau About Private Health Care Ahead of Sit-Down With Premiers
 - [https://www.theepochtimes.com/singh-meeting-with-trudeau-about-private-health-care-ahead-of-sit-down-with-premiers_5020846.html](https://www.theepochtimes.com/singh-meeting-with-trudeau-about-private-health-care-ahead-of-sit-down-with-premiers_5020846.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 20:21:27+00:00
 - user: None

New Democratic Party leader Jagmeet Singh listens to a question during an availability on Parliament Hill, Jan. 19, 2023 in Ottawa. (The Canadian Press/Adrian Wyld)

## UK Government Admits to Monitoring COVID Lockdown Critics on Social Media Platforms
 - [https://www.theepochtimes.com/uk-government-admits-to-monitoring-covid-lockdown-critics-on-social-media-platforms_5019567.html](https://www.theepochtimes.com/uk-government-admits-to-monitoring-covid-lockdown-critics-on-social-media-platforms_5019567.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 20:15:32+00:00
 - user: None

A person using a computer in an undated file photo. (Dominic Lipinski/PA Media)

## UK Defence Ministry to Probe Old Wi-fi Contract Following Report of Chinese Involvement
 - [https://www.theepochtimes.com/uk-defence-ministry-to-probe-old-wi-fi-contract-following-report-of-chinese-involvement_5019847.html](https://www.theepochtimes.com/uk-defence-ministry-to-probe-old-wi-fi-contract-following-report-of-chinese-involvement_5019847.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 20:05:42+00:00
 - user: None

Undated file photo of the sign for the Ministry of Defence in London. (Tim Ireland/PA Media)

## Professor Gives ‘Final Assessment’ on COVID Lockdowns
 - [https://www.theepochtimes.com/professor-gives-final-assessment-on-covid-lockdowns_5004732.html](https://www.theepochtimes.com/professor-gives-final-assessment-on-covid-lockdowns_5004732.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 19:46:18+00:00
 - user: None

A man walks down a quiet Saint-Catherine Street under Quebec's COVID-19 lockdown in Montreal, on Jan. 11, 2021. (The Canadian Press/Paul Chiasson)

## Alberta Premier Danielle Smith Opposes Assisted-Dying Expansion as Ottawa Eyes Delay
 - [https://www.theepochtimes.com/alberta-premier-danielle-smith-opposes-assisted-dying-expansion-as-ottawa-eyes-delay_5020502.html](https://www.theepochtimes.com/alberta-premier-danielle-smith-opposes-assisted-dying-expansion-as-ottawa-eyes-delay_5020502.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 18:37:14+00:00
 - user: None

Alberta Premier Danielle Smith's office says the province objects to Ottawa's plan to extend eligibility for medically assisted death to people whose sole underlying condition is a mental illness. Smith gives an update in Calgary, Jan. 10, 2023. (The Canadian Press/Jeff McIntosh)

## UK Adopts New Rules to Tackle Abuse of Modern Slavery Laws by Illegal Immigrants
 - [https://www.theepochtimes.com/uk-adopts-new-rules-to-tackle-abuse-of-modern-slavery-laws-by-illegal-immigrants_5020303.html](https://www.theepochtimes.com/uk-adopts-new-rules-to-tackle-abuse-of-modern-slavery-laws-by-illegal-immigrants_5020303.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 18:36:19+00:00
 - user: None

Home Secretary Suella Braverman arrives in Downing Street, London, on Jan. 10, 2023. (Stefan Rousseau/PA Media)

## Quebec Calls for Resignation of Federal Government’s Anti-Islamophobia Representative
 - [https://www.theepochtimes.com/quebec-calls-for-resignation-of-federal-governments-anti-islamophobia-representative_5020354.html](https://www.theepochtimes.com/quebec-calls-for-resignation-of-federal-governments-anti-islamophobia-representative_5020354.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 18:34:35+00:00
 - user: None

Quebec Secularism Minister Jean-François Roberge tables legislation at the legislature in Quebec City, Dec. 6, 2022. (The Canadian Press/Jacques Boissinot)

## Dutch Gov’t Plans New Digital ID Project With Canada, Says WEF Initiative Is Done
 - [https://www.theepochtimes.com/dutch-govt-plans-new-digital-id-project-with-canada-says-wef-initiative-is-done_5020401.html](https://www.theepochtimes.com/dutch-govt-plans-new-digital-id-project-with-canada-says-wef-initiative-is-done_5020401.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 18:20:12+00:00
 - user: None

A KLM airplane landed from Johannesburg, South Africa, is parked at the gate E19 at the Schiphol Airport, The Netherlands, on Nov. 27, 2021. (Sem Van Der Wal/ANP/AFP via Getty Images)

## WHO Says COVID-19 Is Still a Global Health Emergency, at ‘Transition Point’
 - [https://www.theepochtimes.com/who-says-covid-19-is-a-global-health-emergency-at-transition-point_5020240.html](https://www.theepochtimes.com/who-says-covid-19-is-a-global-health-emergency-at-transition-point_5020240.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 18:18:36+00:00
 - user: None

A sign of the World Health Organization in Geneva, Switzerland, on April 24, 2020. (Fabrice Coffrini/AFP via Getty Images)

## US Professional Skier Named as 1 Victim of Japan Avalanche
 - [https://www.theepochtimes.com/us-professional-skier-named-as-1-victim-of-japan-avalanche_5019621.html](https://www.theepochtimes.com/us-professional-skier-named-as-1-victim-of-japan-avalanche_5019621.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 17:33:14+00:00
 - user: None

Rescue workers ride a gondola at a ski resort as they take part in a search for missing skiers following an avalanche the previous day, in the village of Otari in Nagano Prefecture, central Japan, on Jan. 30, 2023. (Kyodo via Reuters)

## South Korea’s Rapid Progress in Hypersonic Missiles Could Become a Major Deterrent to North Korea, Experts Say
 - [https://www.theepochtimes.com/south-koreas-rapid-progress-in-hypersonic-missiles-could-become-a-major-deterrent-to-north-korea-experts-say_5019859.html](https://www.theepochtimes.com/south-koreas-rapid-progress-in-hypersonic-missiles-could-become-a-major-deterrent-to-north-korea-experts-say_5019859.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 17:32:41+00:00
 - user: None

A missile is launched during what state media report is a hypersonic missile test at an undisclosed location in North Korea, on Jan. 11, 2022, in this photo released by North Korea's Korean Central News Agency (KCNA) on Jan. 12, 2022.  (KCNA via Reuters)

## Fire Still Burning, Djokovic and GOAT Debate Move on to Paris
 - [https://www.theepochtimes.com/fire-still-burning-djokovic-and-goat-debate-move-on-to-paris_5019643.html](https://www.theepochtimes.com/fire-still-burning-djokovic-and-goat-debate-move-on-to-paris_5019643.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 17:20:27+00:00
 - user: None

Serbia's Novak Djokovic poses with the trophy during Australian Open champion in Government House, Melbourne, Australia, on Jan. 30, 2023. (Carl Recine/Reuters)

## BC Events Mark One-Year Anniversary of Convoy Protests
 - [https://www.theepochtimes.com/bc-events-mark-one-year-anniversary-of-convoy-protests_5019983.html](https://www.theepochtimes.com/bc-events-mark-one-year-anniversary-of-convoy-protests_5019983.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 16:53:02+00:00
 - user: None

A convoy of vehicles outside Merritt, B.C., marks the one-year anniversary of trucker convoy protests against COVID-19 mandates, on Jan. 28, 2023. (Courtesy Bruce Orydzuk)

## House Committee Set to Begin Federal Electoral Redistricting Review
 - [https://www.theepochtimes.com/house-committee-set-to-begin-federal-electoral-redistricting-review_5019951.html](https://www.theepochtimes.com/house-committee-set-to-begin-federal-electoral-redistricting-review_5019951.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 16:31:44+00:00
 - user: None

A voter heads to cast their vote in Canada's federal election at the Fairbanks Interpretation Centre in Dartmouth, N.S., Monday, Oct. 21, 2019. (The Canadian Press/Andrew Vaughan)

## EU Official’s Remarks About Hate Speech Laws Coming to America ‘Very Chilling,’ Free Speech Advocate Says
 - [https://www.theepochtimes.com/eu-officials-remarks-about-hate-speech-laws-coming-to-america-very-chilling-free-speech-advocate-says_5015937.html](https://www.theepochtimes.com/eu-officials-remarks-about-hate-speech-laws-coming-to-america-very-chilling-free-speech-advocate-says_5015937.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 16:23:55+00:00
 - user: None

European Union flags flutter outside the EU Commission headquarters in Brussels on June 17, 2022. (Yves Herman/Reuters)

## Azov Special Operations Regiment Becomes ‘Separate Assault Brigade’ With Ukrainian Army’s Ground Forces
 - [https://www.theepochtimes.com/azov-special-operations-regiment-becomes-separate-assault-brigade-with-ukrainian-armys-ground-forces_5019474.html](https://www.theepochtimes.com/azov-special-operations-regiment-becomes-separate-assault-brigade-with-ukrainian-armys-ground-forces_5019474.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 16:20:04+00:00
 - user: None

Recruits of the Azov Ukrainian volunteer battalion take their oaths during a ceremony in Kyiv, on Aug. 14, 2015. (Sergei Supinsky/AFP via Getty Images)

## Trucks Crash Into Commuters in Nigeria’s South; 20 Dead
 - [https://www.theepochtimes.com/trucks-crash-into-commuters-in-nigerias-south-20-dead_5019781.html](https://www.theepochtimes.com/trucks-crash-into-commuters-in-nigerias-south-20-dead_5019781.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 16:15:07+00:00
 - user: None

An ambulance drives in Lagos, Nigeria, on Jan. 16, 2012. (Pius Utomi Ekpei/AFP via Getty Images)

## Parliamentarians Return to House of Commons Facing Rocky Economic Year
 - [https://www.theepochtimes.com/parliamentarians-return-to-house-of-commons-facing-rocky-economic-year_5020013.html](https://www.theepochtimes.com/parliamentarians-return-to-house-of-commons-facing-rocky-economic-year_5020013.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:43:29+00:00
 - user: None

Prime Minister Justin Trudeau stands during question period in the House of Commons on Parliament Hill in Ottawa, on Nov. 30, 2022. (The Canadian Press/Sean Kilpatrick)

## German Economy Shrank 0.2 Percent in 4th Quarter, Worse Than Expected
 - [https://www.theepochtimes.com/german-economy-shrank-0-2-percent-in-4th-quarter-worse-than-expected_5019596.html](https://www.theepochtimes.com/german-economy-shrank-0-2-percent-in-4th-quarter-worse-than-expected_5019596.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:38:50+00:00
 - user: None

A person walks past a store at the famous shopping road Kurfuerstendamm, better known as 'Kudamm', in Berlin, Germany, on Oct. 11, 2022. (Michael Sohn/AP Photo)

## NDP to Call for Emergency Debate in House of Commons Over Private Health Care
 - [https://www.theepochtimes.com/ndp-to-call-for-emergency-debate-in-house-of-commons-over-private-health-care_5020002.html](https://www.theepochtimes.com/ndp-to-call-for-emergency-debate-in-house-of-commons-over-private-health-care_5020002.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:37:35+00:00
 - user: None

NDP leader Jagmeet Singh speaks to reporters on Parliament Hill in Ottawa on Dec. 7, 2022. (The Canadian Press/Sean Kilpatrick)

## Norway Finds Rare Earth Metals That Could Make Europe Less Dependent on China
 - [https://www.theepochtimes.com/norway-finds-rare-earth-metals-that-could-make-europe-less-dependent-on-china_5019784.html](https://www.theepochtimes.com/norway-finds-rare-earth-metals-that-could-make-europe-less-dependent-on-china_5019784.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:29:10+00:00
 - user: None

Kjersti Dahle, NPD director technology, analysis and coexistence  (The Norwegian Petroleum Directorate photo)

## House of Lords Urged to Back ‘Proper Penalties’ for Disruptive Protesters
 - [https://www.theepochtimes.com/house-of-lords-urged-to-back-proper-penalties-for-disruptive-protesters_5019795.html](https://www.theepochtimes.com/house-of-lords-urged-to-back-proper-penalties-for-disruptive-protesters_5019795.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:20:05+00:00
 - user: None

Just Stop Oil protesters block traffic in Parliament Square in London, on Oct. 4, 2022. (Dan Kitwood/Getty Images)

## NATO Seeks ‘Stronger’ Ties With South Korea as North Korea Accused of Arming Russia
 - [https://www.theepochtimes.com/nato-seeks-stronger-ties-with-south-korea-as-north-korea-accused-of-arming-russia_5019449.html](https://www.theepochtimes.com/nato-seeks-stronger-ties-with-south-korea-as-north-korea-accused-of-arming-russia_5019449.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:18:20+00:00
 - user: None

NATO Secretary-General Jens Stoltenberg gives a press conference after a bilateral meeting at the NATO headquarters in Brussels, Belgium, on Dec. 10, 2021. (John Thys/AFP via Getty Images)

## Britishvolt Was ‘Highly Risky Project’ and Government Should Walk Away From It: Energy Expert
 - [https://www.theepochtimes.com/britishvolt-was-highly-risky-project-and-government-should-walk-away-from-it-energy-expert_5015166.html](https://www.theepochtimes.com/britishvolt-was-highly-risky-project-and-government-should-walk-away-from-it-energy-expert_5015166.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 15:13:55+00:00
 - user: None

Peter Rolton, executive chairman of Britishvolt, at the site of the company's planned electric battery factory in Blyth, England, on Jan. 27, 2022. (Reuters/Nick Carey)

## CCP Policies Create ‘Artificial’ Energy Crisis as Chinese Citizens Lack Winter Heating
 - [https://www.theepochtimes.com/ccp-policies-create-artificial-energy-crisis-as-chinese-citizens-lack-winter-heating_5019515.html](https://www.theepochtimes.com/ccp-policies-create-artificial-energy-crisis-as-chinese-citizens-lack-winter-heating_5019515.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 14:39:03+00:00
 - user: None

A man stands outside during heavy snowfall in Harbin in northeast China’s Heilongjiang province on Nov. 18, 2013. (STR/AFP/Getty Images)

## Canadian Theater Sparks Backlash After Announcing Performances for ‘Black-Identifying Audiences’
 - [https://www.theepochtimes.com/canadian-theater-sparks-backlash-after-announcing-performances-for-black-identifying-audiences_5019573.html](https://www.theepochtimes.com/canadian-theater-sparks-backlash-after-announcing-performances-for-black-identifying-audiences_5019573.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 14:26:12+00:00
 - user: None

The National Arts Centre in Ottawa, Canada, in May 2021. (Google Maps/Screenshot via The Epoch Times)

## Michael Taube: Airlines Need an Open Skies Policy, Not a New Bill of Passenger Rights
 - [https://www.theepochtimes.com/michael-taube-airlines-need-an-open-skies-policy-not-a-new-bill-of-passenger-rights_5018789.html](https://www.theepochtimes.com/michael-taube-airlines-need-an-open-skies-policy-not-a-new-bill-of-passenger-rights_5018789.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 14:25:58+00:00
 - user: None

An Air Canada aircraft is parked at a gate at Vancouver International Airport in Richmond, B.C., on Dec. 26, 2022. (The Canadian Press/Darryl Dyck)

## Cabinet Having ‘Delicate Conversations’ on Proposed Gun Restriction Bill, Says Gov’t House Leader
 - [https://www.theepochtimes.com/cabinet-having-delicate-conversations-on-proposed-gun-restriction-bill-says-govt-house-leader_5019701.html](https://www.theepochtimes.com/cabinet-having-delicate-conversations-on-proposed-gun-restriction-bill-says-govt-house-leader_5019701.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 14:16:19+00:00
 - user: None

Leader of the Government in the House of Commons Mark Holland speaks during a news conference on Parliament Hill on Sept. 20, 2022. (Adrian Wyld/The Canadian Press)

## Toyota Defends Title as World’s Top-Selling Automaker in 2022
 - [https://www.theepochtimes.com/toyota-defends-title-as-worlds-top-selling-automaker-in-2022_5019554.html](https://www.theepochtimes.com/toyota-defends-title-as-worlds-top-selling-automaker-in-2022_5019554.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 14:11:24+00:00
 - user: None

The Toyota logo on the bonnet of a newly launched Camry Hybrid electric vehicle at a hotel in New Delhi, India, on Jan. 18, 2019. (Anushree Fadnavis/Reuters)

## Russia Denies Putin Threatened Boris Johnson With Missile Attack in Pre-War Phone Call
 - [https://www.theepochtimes.com/russia-denies-putin-threatened-boris-johnson-with-missile-attack-in-pre-war-phone-call_5019713.html](https://www.theepochtimes.com/russia-denies-putin-threatened-boris-johnson-with-missile-attack-in-pre-war-phone-call_5019713.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 13:07:08+00:00
 - user: None

Ukrainian President Volodymyr Zelenskyy (R) meeting British Prime Minister Boris Johnson, who has made a surprise visit to Kyiv, on June 17, 2022. (Ukrainian Presidential Press Office/PA Media)

## Suicide Bombing at Mosque in Pakistan Kills 34, Targeted Police
 - [https://www.theepochtimes.com/suicide-bombing-at-mosque-in-pakistan-kills-32-targeted-police_5019678.html](https://www.theepochtimes.com/suicide-bombing-at-mosque-in-pakistan-kills-32-targeted-police_5019678.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 13:03:59+00:00
 - user: None

A police officer guides an ambulance after a suicide blast in a mosque, at police line area in Peshawar, Pakistan, on Jan. 30, 2023. (Fayaz Aziz/Reuters)

## Unprecedented Auckland Flash Flooding Caused by Climate Change: New Zealand PM
 - [https://www.theepochtimes.com/unprecedented-auckland-flash-flooding-caused-by-climate-change-new-zealand-pm_5019454.html](https://www.theepochtimes.com/unprecedented-auckland-flash-flooding-caused-by-climate-change-new-zealand-pm_5019454.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 12:00:05+00:00
 - user: None

A vehicle is submerged in flooding at Kumeu as heavy rain causes extensive flooding and destruction in Auckland, New Zealand, on Aug. 31, 2021. (Fiona Goodall/Getty Images)

## UN General Assembly Head Says Security Council Is ‘Paralyzed’, Cannot Maintain Peace Amid Russia–Ukraine War
 - [https://www.theepochtimes.com/un-general-assembly-head-says-security-council-is-paralyzed-cannot-maintain-peace-amid-russia-ukraine-war_5019473.html](https://www.theepochtimes.com/un-general-assembly-head-says-security-council-is-paralyzed-cannot-maintain-peace-amid-russia-ukraine-war_5019473.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 11:40:55+00:00
 - user: None

The results of a General Assembly vote on a resolution is shown on a screen during a special session of the General Assembly at the United Nations headquarters in New York, on March 2, 2022. (Michael M. Santiago/Getty Images)

## France Must Raise Pension Age to 64, Prime Minister Says
 - [https://www.theepochtimes.com/france-must-raise-pension-age-to-64-prime-minister-says_5018400.html](https://www.theepochtimes.com/france-must-raise-pension-age-to-64-prime-minister-says_5018400.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 08:02:03+00:00
 - user: None

People gather on Place de la Republique during a demonstration against proposed pension changes in Paris on Jan. 19, 2023. (Lewis Joly/AP Photo)

## Peru Bus Plunges Off Cliff, Killing at Least 24
 - [https://www.theepochtimes.com/peru-bus-plunges-off-cliff-killing-at-least-24_5018370.html](https://www.theepochtimes.com/peru-bus-plunges-off-cliff-killing-at-least-24_5018370.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 07:55:25+00:00
 - user: None

Bodies of victims are transported on the back of a pick-up truck after a bus carrying 60 passengers plunged off a cliff in the district of El Alto, Peru, on Jan. 28, 2023. (Piura Government/Handout via Reuters)

## Samsung Employees to Get Low-Carbon Meals as Part of Net-Zero Climate Push
 - [https://www.theepochtimes.com/samsung-employees-to-get-low-carbon-meals-as-part-of-net-zero-climate-push_5019143.html](https://www.theepochtimes.com/samsung-employees-to-get-low-carbon-meals-as-part-of-net-zero-climate-push_5019143.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 06:59:24+00:00
 - user: None

The logo of Samsung Electronics in Seoul, South Korea, on March 23, 2018. (Kim Hong-Ji/Reuters)

## Chinese Students Forced to Scramble Back to Australia as Beijing Shuts the Door on Online Study
 - [https://www.theepochtimes.com/chinese-students-forced-to-scramble-back-to-australia-as-beijing-shuts-the-door-on-online-study_5019184.html](https://www.theepochtimes.com/chinese-students-forced-to-scramble-back-to-australia-as-beijing-shuts-the-door-on-online-study_5019184.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 05:55:33+00:00
 - user: None

Students walk around the University of New South Wales campus in Sydney, Australia, on Dec. 1, 2020. (AP Photo/Mark Baker)

## ‘No’ Campaign Launches Against Voice Referendum
 - [https://www.theepochtimes.com/no-campaign-launches-against-voice-referendum_5019196.html](https://www.theepochtimes.com/no-campaign-launches-against-voice-referendum_5019196.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 05:42:23+00:00
 - user: None

The Aboriginal Tent Embassy holds a family BBQ and entertainment in Canberra, Australia on Jan. 26, 2023. (Martin Ollman/Getty Images)

## Guangzhou Retirees Stage Mass Protests Over Cuts to Medical Insurance Payments
 - [https://www.theepochtimes.com/guangzhou-retirees-stage-mass-protests-over-cuts-to-medical-insurance-payments_5018617.html](https://www.theepochtimes.com/guangzhou-retirees-stage-mass-protests-over-cuts-to-medical-insurance-payments_5018617.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 03:41:06+00:00
 - user: None

Riot police in personal protection suits walk down a street during protests over COVID-19 restrictions in Guangzhou, a city in Guangdong province, China,  in this screen grab taken from a social media video released on Nov. 29, 2022. (Video Obtained by Reuters/via Reuters)

## International Fugitive Doctor Convicted of Fentanyl Drug Trafficking Loses Medical Licence
 - [https://www.theepochtimes.com/international-fugitive-doctor-convicted-of-fentanyl-drug-trafficking-loses-medical-licence_5019089.html](https://www.theepochtimes.com/international-fugitive-doctor-convicted-of-fentanyl-drug-trafficking-loses-medical-licence_5019089.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 03:23:06+00:00
 - user: None

A U.S. Drug Enforcement Administration (DEA) chemist checks confiscated powder containing fentanyl at the DEA Northeast Regional Laboratory in New York on Oct. 8, 2019. (Don Emmert/AFP via Getty Images)

## Bus Crash in Southern Pakistan Kills at Least 41
 - [https://www.theepochtimes.com/bus-crash-in-southern-pakistan-kills-at-least-41_5018348.html](https://www.theepochtimes.com/bus-crash-in-southern-pakistan-kills-at-least-41_5018348.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 02:30:19+00:00
 - user: None

People work at the site of a bus crash in Lasbela District, Balochistan province, Pakistan, on Jan. 29, 2023. (Edhi Foundation/Handout/Reuters TV via Reuters)

## Undoing Zero-COVID Reveals the CCP’s Greatest Fear
 - [https://www.theepochtimes.com/undoing-zero-covid-reveals-the-ccps-greatest-fear_5019121.html](https://www.theepochtimes.com/undoing-zero-covid-reveals-the-ccps-greatest-fear_5019121.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 01:56:01+00:00
 - user: None

Chinese leader Xi Jinping arrives to attend the APEC Economic Leaders Meeting during the Asia-Pacific Economic Cooperation, APEC summit in Bangkok on Nov. 19, 2022. (Jack Taylor/Pool Photo via AP)

## Liberal ‘Green Energy’ Plan Adding to Inflation: Bank of Canada Paper
 - [https://www.theepochtimes.com/liberal-green-energy-plan-adding-to-inflation-bank-of-canada-paper_5018968.html](https://www.theepochtimes.com/liberal-green-energy-plan-adding-to-inflation-bank-of-canada-paper_5018968.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 00:52:21+00:00
 - user: None

Prime Minister Justin Trudeau (back L) celebrates with California Gov. Gavin Newsom (C) and California Senior Climate Adviser Lauren Sanchez (back R), as Canada's Environment Minister Steven Guilbeault (front L) and California Senior Environmental Protection Agency Chief Jerod Blumenthal sign a memorandum of cooperation on climate change at the California Science Center outside the ninth Summit of the Americas, in Los Angeles on June 9, 2022. (Richard Vogel/AP Photo)

## China U-Turns on Visa Freeze for Japanese
 - [https://www.theepochtimes.com/china-announces-resumption-of-visas-for-japanese_5018393.html](https://www.theepochtimes.com/china-announces-resumption-of-visas-for-japanese_5018393.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 00:40:07+00:00
 - user: None

The Chinese Embassy in Tokyo on Jan. 11, 2023. (Kazushi Kurihara/Kyodo News via AP)

## NSW Election Tackles Screen Addiction
 - [https://www.theepochtimes.com/nsw-election-tackles-screen-addiction_5016885.html](https://www.theepochtimes.com/nsw-election-tackles-screen-addiction_5016885.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-30 00:07:17+00:00
 - user: None

Two children play video games on their phones. The world is seeing an explosion of smart phone usage that will have a long-term impact on human relationships. (Sean Gallup/Getty Images)
