# Source IT hardware PL, Source URL:https://ithardware.pl/feed, Source language: pl-PL

## Składany iPad - nowe doniesienia wskazują, kiedy może zadebiutować i z czego będzie zbudowany
 - [https://ithardware.pl/aktualnosci/skladany_ipad_nowe_doniesienia_wskazuja_kiedy_moze_zadebiutowac_i_z_czego_bedzie_zbudowany-25581.html](https://ithardware.pl/aktualnosci/skladany_ipad_nowe_doniesienia_wskazuja_kiedy_moze_zadebiutowac_i_z_czego_bedzie_zbudowany-25581.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 19:20:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25581_1.jpg" />            Jeden z bardziej rozpoznawalnych analityk&oacute;w, Ming-Chi Kuo, udostępnił tweeta, w kt&oacute;ry zdradził kilka szczeg&oacute;ł&oacute;w na temat składanego tabletu od Apple. Urządzenie ma być wyposażone w podp&oacute;rkę wykonaną z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/skladany_ipad_nowe_doniesienia_wskazuja_kiedy_moze_zadebiutowac_i_z_czego_bedzie_zbudowany-25581.html">https://ithardware.pl/aktualnosci/skladany_ipad_nowe_doniesienia_wskazuja_kiedy_moze_zadebiutowac_i_z_czego_bedzie_zbudowany-25581.html</a></p>

## Rosyjski procesor Elbrus-8SV przetestowany w grach. Nawet Gothic 2 działa na nim tragicznie
 - [https://ithardware.pl/aktualnosci/rosyjski_procesor_elbrus_8sv_przetestowany_w_grach_nawet_gothic_2_dziala_na_nim_tragicznie-25580.html](https://ithardware.pl/aktualnosci/rosyjski_procesor_elbrus_8sv_przetestowany_w_grach_nawet_gothic_2_dziala_na_nim_tragicznie-25580.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 17:19:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25580_1.jpg" />            Rosyjskie procesory są daleko w tyle za układami Intela czy AMD. Do sieci trafiło nagranie z prezentacją wydajności CPU o nazwie Elbrus-8SV w wielu grach. To 8-rdzeniowa jednostka rosyjskiej produkcji, kt&oacute;ra korzysta z grubo przestarzałego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rosyjski_procesor_elbrus_8sv_przetestowany_w_grach_nawet_gothic_2_dziala_na_nim_tragicznie-25580.html">https://ithardware.pl/aktualnosci/rosyjski_procesor_elbrus_8sv_przetestowany_w_grach_nawet_gothic_2_dziala_na_nim_tragicznie-25580.html</a></p>

## TP-Link Archer AX72 Pro oraz Archer AX55 Pro – nowe routery Wi-Fi 6 z portami 2,5 Gb/s
 - [https://ithardware.pl/aktualnosci/tp_link_archer_ax72_pro_oraz_archer_ax55_pro_nowe_routery_wi_fi_6_z_portami_2_5_gb_s-25579.html](https://ithardware.pl/aktualnosci/tp_link_archer_ax72_pro_oraz_archer_ax55_pro_nowe_routery_wi_fi_6_z_portami_2_5_gb_s-25579.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 15:21:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25579_1.jpg" />            Archer AX72 Pro i Archer AX55 Pro to routery od TP-Link pracujące w najnowszym standardzie Wi-Fi 6. Urządzenia szczeg&oacute;lnie polecane są użytkownikom, kt&oacute;rzy korzystają z ofert światłowodowych, osiągających prędkości powyżej 1...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tp_link_archer_ax72_pro_oraz_archer_ax55_pro_nowe_routery_wi_fi_6_z_portami_2_5_gb_s-25579.html">https://ithardware.pl/aktualnosci/tp_link_archer_ax72_pro_oraz_archer_ax55_pro_nowe_routery_wi_fi_6_z_portami_2_5_gb_s-25579.html</a></p>

## iiyama zaprasza na festiwal Meet at Rift Winter 2023
 - [https://ithardware.pl/aktualnosci/iiyama_zaprasza_na_festiwal_meet_at_rift_winter_2023-25578.html](https://ithardware.pl/aktualnosci/iiyama_zaprasza_na_festiwal_meet_at_rift_winter_2023-25578.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 14:11:40+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25578_1.jpg" />            Rozgrywki e-sportowe zawsze dostarczają niezapomnianych emocji, szczeg&oacute;lnie jeśli gracze mogą cieszyć się najwyższą jakością rozgrywki. To właśnie dlatego iiyama jest jednym z gł&oacute;wnych partner&oacute;w drugiej edycji wydarzenia...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iiyama_zaprasza_na_festiwal_meet_at_rift_winter_2023-25578.html">https://ithardware.pl/aktualnosci/iiyama_zaprasza_na_festiwal_meet_at_rift_winter_2023-25578.html</a></p>

## BMW zbuduje w Niemczech fabrykę akumulatorów półprzewodnikowych ze stałym elektrolitem
 - [https://ithardware.pl/aktualnosci/bmw_zbuduje_w_niemczech_fabryke_akumulatorow_polprzewodnikowych_ze_stalym_elektrolitem-25577.html](https://ithardware.pl/aktualnosci/bmw_zbuduje_w_niemczech_fabryke_akumulatorow_polprzewodnikowych_ze_stalym_elektrolitem-25577.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 13:26:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25577_1.jpg" />            BMW Group i Solid Power pogłębiają wsp&oacute;łpracę, kt&oacute;rej efektem jest obecnie przyznanie licencji, kt&oacute;ra pozwoli BMW na budowę w Niemczech linii produkcyjnej nowych akumulator&oacute;w Solid Power ze stałym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/bmw_zbuduje_w_niemczech_fabryke_akumulatorow_polprzewodnikowych_ze_stalym_elektrolitem-25577.html">https://ithardware.pl/aktualnosci/bmw_zbuduje_w_niemczech_fabryke_akumulatorow_polprzewodnikowych_ze_stalym_elektrolitem-25577.html</a></p>

## Test Kingston FURY Renegade 2x16 GB 7200 MHz CL 38. Zawrotnie szybka pamięć DDR5
 - [https://ithardware.pl/testyirecenzje/kingston_fury_renegade_7200_mhz_test_recenzja_opinia-25492.html](https://ithardware.pl/testyirecenzje/kingston_fury_renegade_7200_mhz_test_recenzja_opinia-25492.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 13:20:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25492_1.jpg" />            Test szybkiej pamięci DDR5 Kingston FURY&trade; Renegade

Kontynuujemy przegląd pamięci DDR5 o wysokim taktowaniu i kolejny zestaw, jakie trafił na testy, to Kingston FURY&trade; Renegade w wariancie 2x16 GB 7200 MHz CL 38. Są to zatem pierwsze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/kingston_fury_renegade_7200_mhz_test_recenzja_opinia-25492.html">https://ithardware.pl/testyirecenzje/kingston_fury_renegade_7200_mhz_test_recenzja_opinia-25492.html</a></p>

## Ryzeny 7000 coraz tańsze. AMD chce wyczyścić magazyny przed premierą modeli X3D?
 - [https://ithardware.pl/aktualnosci/ryzeny_7000_coraz_tansze_amd_chce_wyczyscic_magazyny_przed_premiera_modeli_x3d-25573.html](https://ithardware.pl/aktualnosci/ryzeny_7000_coraz_tansze_amd_chce_wyczyscic_magazyny_przed_premiera_modeli_x3d-25573.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 12:31:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25573_1.jpg" />            Ceny procesor&oacute;w AMD Ryzen 7000 do komputer&oacute;w stacjonarnych nieustannie spadają, a w USA odnotowano właśnie kolejne obniżki. Co ciekawe, niekt&oacute;re modele &bdquo;X&rdquo; są tam teraz tańsze od odpowiednik&oacute;w bez...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ryzeny_7000_coraz_tansze_amd_chce_wyczyscic_magazyny_przed_premiera_modeli_x3d-25573.html">https://ithardware.pl/aktualnosci/ryzeny_7000_coraz_tansze_amd_chce_wyczyscic_magazyny_przed_premiera_modeli_x3d-25573.html</a></p>

## Pierwsze egzemplarze pickupa Tesla Cybertruck już wkrótce pojawią się na drogach
 - [https://ithardware.pl/aktualnosci/pierwsze_egzemplarze_pickupa_tesla_cybertruck_juz_wkrotce_pojawia_sie_na_drogach-25576.html](https://ithardware.pl/aktualnosci/pierwsze_egzemplarze_pickupa_tesla_cybertruck_juz_wkrotce_pojawia_sie_na_drogach-25576.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 11:20:50+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25576_1.jpg" />            Na elektrycznego pickupa od Tesli czekamy już bardzo długo, jednak&nbsp;wszystko wskazuje na to, że Elon Musk w końcu wprowadzi Cybertrucka na rynek.

Kryzys p&oacute;łprzewodnikowy&nbsp;i pandemia koronawirusa op&oacute;źniły wiele...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwsze_egzemplarze_pickupa_tesla_cybertruck_juz_wkrotce_pojawia_sie_na_drogach-25576.html">https://ithardware.pl/aktualnosci/pierwsze_egzemplarze_pickupa_tesla_cybertruck_juz_wkrotce_pojawia_sie_na_drogach-25576.html</a></p>

## Japonia i Holandia także banują eksport maszyn litograficznych do Chin. Gigant ma duży problem
 - [https://ithardware.pl/aktualnosci/japonia_i_holandia_takze_banuja_eksport_maszyn_litograficznych_do_chin_gigant_ma_duzy_problem-25572.html](https://ithardware.pl/aktualnosci/japonia_i_holandia_takze_banuja_eksport_maszyn_litograficznych_do_chin_gigant_ma_duzy_problem-25572.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 11:07:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25572_1.jpg" />            Jak podała agencja Bloomberg, Japonia i Holandia wsparły USA w ograniczaniu Chinom dostępu do zaawansowanego sprzętu do produkcji p&oacute;łprzewodnik&oacute;w.&nbsp;

Trzy kraje osiągnęły porozumienie w piątek i Japonia oraz Holandia mają...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/japonia_i_holandia_takze_banuja_eksport_maszyn_litograficznych_do_chin_gigant_ma_duzy_problem-25572.html">https://ithardware.pl/aktualnosci/japonia_i_holandia_takze_banuja_eksport_maszyn_litograficznych_do_chin_gigant_ma_duzy_problem-25572.html</a></p>

## Nawet GeForce RTX 4090 nie radzi sobie z Dead Space Remake w 4K
 - [https://ithardware.pl/aktualnosci/nawet_geforce_rtx_4090_nie_radzi_sobie_z_dead_space_remake_w_4k-25571.html](https://ithardware.pl/aktualnosci/nawet_geforce_rtx_4090_nie_radzi_sobie_z_dead_space_remake_w_4k-25571.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 10:15:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25571_1.jpg" />            NVIDIA GeForce RTX 4090 to najmocniejsza karta graficzna dostępna na rynku, kt&oacute;ra według NVIDII nie powinna mieć problem&oacute;w z zapewnieniem płynnej rozgrywki w 4K. Jednak Dead Space Remake jest jedną z pierwszych gier, w kt&oacute;rych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nawet_geforce_rtx_4090_nie_radzi_sobie_z_dead_space_remake_w_4k-25571.html">https://ithardware.pl/aktualnosci/nawet_geforce_rtx_4090_nie_radzi_sobie_z_dead_space_remake_w_4k-25571.html</a></p>

## Corsair przedwcześnie opublikował zwiastun nowego dysku PCIe 5.0 (MP700)
 - [https://ithardware.pl/aktualnosci/corsair_przedwczesnie_opublikowal_zwiastun_nowego_dysku_pcie_5_0_mp700-25570.html](https://ithardware.pl/aktualnosci/corsair_przedwczesnie_opublikowal_zwiastun_nowego_dysku_pcie_5_0_mp700-25570.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 09:29:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25570_1.jpg" />            Zdaje się, że dużymi krokami zbliżamy się do szerokiej premiery dysk&oacute;w SSD wykorzystujących interfejs PCIe 5.0. W miniony weekend pisaliśmy, że pierwszy taki dysk trafił do sprzedaży w Japonii, a zdaje się, że nie będziemy musieli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/corsair_przedwczesnie_opublikowal_zwiastun_nowego_dysku_pcie_5_0_mp700-25570.html">https://ithardware.pl/aktualnosci/corsair_przedwczesnie_opublikowal_zwiastun_nowego_dysku_pcie_5_0_mp700-25570.html</a></p>

## Wydajny smartfon Motorola Edge 40 Pro dostrzeżony na renderach. Oto, co już wiemy o urządzeniu
 - [https://ithardware.pl/aktualnosci/wydajny_smartfon_motorola_edge_40_pro_dostrzezony_na_renderach_oto_co_juz_wiemy_o_urzadzeniu-25575.html](https://ithardware.pl/aktualnosci/wydajny_smartfon_motorola_edge_40_pro_dostrzezony_na_renderach_oto_co_juz_wiemy_o_urzadzeniu-25575.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 09:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25575_1.jpg" />            W zeszłym miesiącu Motorola wprowadziła w Chinach smartfon&nbsp;Moto X40, ale na rynku globalnym urządzenie ma zadebiutować pod nazwą&nbsp;Motorola Edge 40 Pro. Sprzęt pojawił się już w bazach&nbsp;FCC, TDRA i Geekbench, co sugeruje jego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wydajny_smartfon_motorola_edge_40_pro_dostrzezony_na_renderach_oto_co_juz_wiemy_o_urzadzeniu-25575.html">https://ithardware.pl/aktualnosci/wydajny_smartfon_motorola_edge_40_pro_dostrzezony_na_renderach_oto_co_juz_wiemy_o_urzadzeniu-25575.html</a></p>

## Google opracowało sztuczną inteligencję, która tworzy muzykę
 - [https://ithardware.pl/aktualnosci/google_opracowalo_sztuczna_inteligencje_ktora_tworzy_muzyke-25574.html](https://ithardware.pl/aktualnosci/google_opracowalo_sztuczna_inteligencje_ktora_tworzy_muzyke-25574.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 08:30:48+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25574_1.jpg" />            Ostatnio widzieliśmy, jak sztuczna inteligencja (AI) jest wykorzystywana do generowania obraz&oacute;w i pomagania ludziom w pisaniu treści. Google jednak właśnie stworzyło nowe AI, kt&oacute;re może generować muzykę na bazie opisu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/google_opracowalo_sztuczna_inteligencje_ktora_tworzy_muzyke-25574.html">https://ithardware.pl/aktualnosci/google_opracowalo_sztuczna_inteligencje_ktora_tworzy_muzyke-25574.html</a></p>

## Macie starsze grafiki od AMD? To w ogóle nie zagracie w Forspoken
 - [https://ithardware.pl/aktualnosci/macie_starsze_grafiki_od_amd_to_w_ogole_nie_zagracie_w_forspoken-25569.html](https://ithardware.pl/aktualnosci/macie_starsze_grafiki_od_amd_to_w_ogole_nie_zagracie_w_forspoken-25569.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 08:05:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25569_1.jpg" />            Użytkownicy kart graficznych AMD Polaris, kt&oacute;rzy stanowią większość graczy z Radeonami, nie mogą uruchomić Forspoken na swoich komputerach z powodu braku obsługi DirectX 12_1.

AMD wypuściło swoje pierwsze karty graficzne Polaris w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/macie_starsze_grafiki_od_amd_to_w_ogole_nie_zagracie_w_forspoken-25569.html">https://ithardware.pl/aktualnosci/macie_starsze_grafiki_od_amd_to_w_ogole_nie_zagracie_w_forspoken-25569.html</a></p>

## Pierwsze elektryczne auto Xiaomi zaprezentowane w pełnej krasie
 - [https://ithardware.pl/aktualnosci/pierwsze_elektryczne_auto_xiaomi_zaprezentowane_w_pelnej_krasie-25568.html](https://ithardware.pl/aktualnosci/pierwsze_elektryczne_auto_xiaomi_zaprezentowane_w_pelnej_krasie-25568.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 07:13:17+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25568_1.jpg" />            Chińskie portale społecznościowe potrafią być prawdziwą kopalnią informacji, o ile wie się jak i gdzie szukać. Potwierdzeniem tej tezy jest najnowszy przeciek, kt&oacute;ry oferuje możliwość obejrzenia w pełnej krasie pierwszego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwsze_elektryczne_auto_xiaomi_zaprezentowane_w_pelnej_krasie-25568.html">https://ithardware.pl/aktualnosci/pierwsze_elektryczne_auto_xiaomi_zaprezentowane_w_pelnej_krasie-25568.html</a></p>

## Produkty Silver Monkey nawet do 68% taniej. Specjalna oferta na ferie w x-komie
 - [https://ithardware.pl/aktualnosci/produkty_silver_monkey_nawet_do_68_taniej_specjalna_oferta_na_ferie_w_x_komie-25544.html](https://ithardware.pl/aktualnosci/produkty_silver_monkey_nawet_do_68_taniej_specjalna_oferta_na_ferie_w_x_komie-25544.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-30 07:00:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25544_1.jpg" />            Jeśli jeszcze nie masz żadnego sprzętu od marki Silver Monkey, to teraz jest doskonała okazja, aby to zmienić. Z okazji ferii zimowych w x-komie wiele produkt&oacute;w Silver Monkey możesz teraz kupić z rabatem wynoszącym nawet 68%. Sprawdź...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/produkty_silver_monkey_nawet_do_68_taniej_specjalna_oferta_na_ferie_w_x_komie-25544.html">https://ithardware.pl/aktualnosci/produkty_silver_monkey_nawet_do_68_taniej_specjalna_oferta_na_ferie_w_x_komie-25544.html</a></p>
