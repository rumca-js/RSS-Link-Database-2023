# Source TVN24 Ze świata, Source URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, Source language: pl-PL

## Pojechali razem autobusem do Zabrza. Szukają go, jest podejrzewany o zgwałcenie 17-latki
 - [https://tvn24.pl/najnowsze/zabrze-pojechali-razem-autobusem-mezczyzna-mial-zgwalcic-17-latke-w-pustostanie-policja-publikuje-film-z-monitoringu-6709616?source=rss](https://tvn24.pl/najnowsze/zabrze-pojechali-razem-autobusem-mezczyzna-mial-zgwalcic-17-latke-w-pustostanie-policja-publikuje-film-z-monitoringu-6709616?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-01-30 14:16:30+00:00
 - user: None

<img alt="Pojechali razem autobusem do Zabrza. Szukają go, jest podejrzewany o zgwałcenie 17-latki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i51523-poszukiwany-mezczyzna-podejrzewany-jest-o-zgwalcenie-17-latki-6709701/alternates/LANDSCAPE_1280" />
    Policja w Zabrzu publikuje wizerunek mężczyzny, podejrzewanego o zgwałcenie 17-latki. Kamera zarejestrowała go w autobusie miejskim, którym miał jechać z dziewczyną z Katowic do Zabrza.
