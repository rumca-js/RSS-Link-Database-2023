# Source It's FOSS News, Source URL:https://news.itsfoss.com/rss/, Source language: en-US

## Budgie 10.7 Release Brings in UX Improvements and New Tools
 - [https://news.itsfoss.com/budgie-10-7-release/](https://news.itsfoss.com/budgie-10-7-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-01-30 10:17:16+00:00
 - user: None

Budgie desktop experience gets better with the updgrade.
