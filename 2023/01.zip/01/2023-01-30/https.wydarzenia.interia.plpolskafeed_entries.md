# Source Wydarzenia Interia - Polska, Source URL:https://wydarzenia.interia.pl/polska/feed, Source language: pl-PL

## Zima nie powiedziała ostatniego słowa. W lutym przyjdą potężne mrozy
 - [https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-w-lutym-przyjda-potezn,nId,6566152](https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-w-lutym-przyjda-potezn,nId,6566152)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-01-30 08:45:33+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zima-nie-powiedziala-ostatniego-slowa-w-lutym-przyjda-potezn,nId,6566152"><img align="left" alt="Zima nie powiedziała ostatniego słowa. W lutym przyjdą potężne mrozy" src="https://i.iplsc.com/zima-nie-powiedziala-ostatniego-slowa-w-lutym-przyjda-potezn/000GOPUP7UQ6NPN7-C321.jpg" /></a>Pogoda potrafi zaskoczyć w najmniej spodziewanym momencie. Jeżeli ktoś myślał, że zima to przeszłość - jest w błędzie. Wszystko to za sprawą niżu Nicolas, który do Polski sprowadzi śnieżyce, zamiecie i spadek temperatury. Według najnowszej prognozy pogody taki stan rzeczy utrzyma się w najbliższych dniach. To jednak nie koniec. Prawdziwa zima ma nadejść dopiero w lutym.</p><br clear="all" />
