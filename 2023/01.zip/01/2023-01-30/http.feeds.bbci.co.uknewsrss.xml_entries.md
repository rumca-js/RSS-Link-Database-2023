# Source BBC, Source URL:http://feeds.bbci.co.uk/news/rss.xml, Source language: en-US

## New powers to curb strike disruption approved by MPs
 - [https://www.bbc.co.uk/news/uk-politics-64456279?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64456279?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 23:21:28+00:00
 - user: None

Under the bill some employees would have to work during strikes - and could be sacked if they refuse.

## How Egyptian police hunt LGBT people on dating apps
 - [https://www.bbc.co.uk/news/world-middle-east-64390817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64390817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 22:08:30+00:00
 - user: None

The BBC has seen evidence of how officers pose as dates online to seek out and arrest their targets.

## FA Cup: Derby County 0-2 West Ham United - highlights
 - [https://www.bbc.co.uk/sport/av/football/64349465?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64349465?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 22:07:11+00:00
 - user: None

Watch highlights as goals from Jarrod Bowen and Michail Antonio give West Ham a 2-0 victory over Derby to set up an FA Cup fifth round tie away at Manchester United.

## Retired vicar banned over 'virulently antisemitic' posts
 - [https://www.bbc.co.uk/news/uk-64460767?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64460767?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 21:18:38+00:00
 - user: None

The Church of England ruled that Dr Stephen Sizer had "provoked and offended the Jewish community".

## Alessia Russo: Arsenal make world-record bid for Manchester United and England striker
 - [https://www.bbc.co.uk/sport/football/64460662?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64460662?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 20:03:55+00:00
 - user: None

Arsenal make a late world-record bid for England international Alessia Russo on the eve of transfer window deadline day.

## FA Cup fifth round draw: Man City go to Bristol City, Wrexham could host Spurs
 - [https://www.bbc.co.uk/sport/football/64456927?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64456927?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 19:31:42+00:00
 - user: None

Manchester City will go to Championship side Bristol City in the FA Cup fifth round, while Wrexham could host Tottenham.

## Eva Green: Actress gives evidence in High Court over bitter film dispute
 - [https://www.bbc.co.uk/news/entertainment-arts-64454163?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64454163?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 19:14:44+00:00
 - user: None

The French star is suing a film company in the High Court after their plans fell apart.

## Sixth police officer suspended after Tyre Nichols' death
 - [https://www.bbc.co.uk/news/world-us-canada-64408456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64408456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 18:54:13+00:00
 - user: None

Preston Hemphill was one of the officers who initially stopped Mr Nichols prior to his fatal beating.

## Premier League transfers: Record spending set to be extended on deadline day
 - [https://www.bbc.co.uk/sport/football/64455271?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64455271?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 18:37:23+00:00
 - user: None

The Premier League transfer window closes on Tuesday night and there are some potential deals which could further extend the record amount already spent.

## Wrexham McDonald's plays classical music to deter bad behaviour
 - [https://www.bbc.co.uk/news/uk-wales-64458332?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64458332?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 18:35:08+00:00
 - user: None

A branch of the fast-food chain in Wrexham is also rationing wi-fi after youngsters cause "upset".

## Police appeal to woman after foetus left outside Barnet hospital
 - [https://www.bbc.co.uk/news/uk-england-london-64456771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64456771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 18:08:30+00:00
 - user: None

A box containing a 16-week-old foetus was discovered outside Barnet Hospital on Monday.

## Mysterious 'whirlpool' appears in the night sky above Hawaii
 - [https://www.bbc.co.uk/news/world-us-canada-64458511?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64458511?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 18:04:08+00:00
 - user: None

An observatory captured video of the spiral formation flying through the night sky in January.

## Plymouth shooting: Firearms licence officer says he had no training
 - [https://www.bbc.co.uk/news/uk-england-devon-64451185?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-devon-64451185?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 17:58:49+00:00
 - user: None

An inquest into five people's deaths in Plymouth is told firearms licence training was "on the job".

## Richard Sharp: Watchdog head steps back from BBC chair probe
 - [https://www.bbc.co.uk/news/uk-64458289?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64458289?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 17:53:57+00:00
 - user: None

William Shawcross will no longer lead a review of Richard Sharp's appointment owing to past contacts.

## Six Nations 2023: How each team is shaping up for the tournament
 - [https://www.bbc.co.uk/sport/rugby-union/64458895?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64458895?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 17:29:12+00:00
 - user: None

The top two sides in the world and two late coaching changes - a look at each team in the 2023 Six Nations.

## Kyle Smaine: US freestyle skier dies aged 31 in avalanche in Japan
 - [https://www.bbc.co.uk/sport/winter-sports/64455248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-sports/64455248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 17:28:25+00:00
 - user: None

Former US world champion freestyle skier Kyle Smaine dies in an avalanche in Japan.

## Sichuan: Couples in Chinese province allowed to have unlimited children
 - [https://www.bbc.co.uk/news/world-asia-china-64457367?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-64457367?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 17:04:15+00:00
 - user: None

As part of the policy in Sichuan, unmarried individuals will also be able to raise children.

## UK firefighters back strike action in row over pay
 - [https://www.bbc.co.uk/news/uk-64457843?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64457843?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 16:46:26+00:00
 - user: None

The Fire Brigades Union says it will delay announcing dates for action until after it meets employers.

## Buyer backs out of £62,000 Mr Blobby suit purchase
 - [https://www.bbc.co.uk/news/uk-64454173?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64454173?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 16:26:54+00:00
 - user: None

After a whirlwind bidding war over an original costume of the TV character, the seller is let down.

## Chelsea transfer news: Blues bid £105.6m for Enzo Fernandez
 - [https://www.bbc.co.uk/sport/football/64456682?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64456682?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 16:03:17+00:00
 - user: None

Chelsea bid 120m euros (£105.6m) for Benfica's Argentina midfielder Enzo Fernandez in a move that would make him the British transfer record signing.

## Lisa Loring, the original Wednesday Addams actress, dies at 64
 - [https://www.bbc.co.uk/news/world-us-canada-64455503?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64455503?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:54:31+00:00
 - user: None

She was five when she starred in the first TV adaptation of The Addams Family in the 1960s.

## January transfer window: Premier League hits and misses after £3bn spent in 20 years
 - [https://www.bbc.co.uk/sport/football/64109185?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64109185?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:44:50+00:00
 - user: None

Which players have been the biggest hits and misses after making a move in the January transfer window?

## Siobhan Cattigan: Family criticise Scottish Rugby Union for failing to meet
 - [https://www.bbc.co.uk/sport/rugby-union/64448460?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64448460?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:24:19+00:00
 - user: None

The parents of Siobhan Cattigan criticise the Scottish Rugby Union for not meeting the MSP investigating the death of the Scotland forward after two serious concussions.

## Sean Dyche: The key tasks for new Everton manager
 - [https://www.bbc.co.uk/sport/football/64430098?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64430098?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:22:55+00:00
 - user: None

A 'broken' club that doesn't know 'how to win' - BBC Sport looks at the key challenges facing new Everton manager Sean Dyche.

## Sean Dyche: Everton name former Burnley boss as new manager
 - [https://www.bbc.co.uk/sport/football/64431854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64431854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:09:32+00:00
 - user: None

Everton name former Burnley boss Sean Dyche as their new manager following the sacking of Frank Lampard.

## Thomas settles HIV legal case with ex-partner
 - [https://www.bbc.co.uk/news/uk-wales-64453783?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-64453783?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 14:06:45+00:00
 - user: None

Former British and Irish Lions captain Gareth Thomas says he has agreed to pay £75,000.

## 'I was sold to men for sex but police did nothing'
 - [https://www.bbc.co.uk/news/uk-england-manchester-64452655?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64452655?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 13:52:55+00:00
 - user: None

A woman forced to have sex with hundreds of men receives an apology after police failed to investigate.

## Andrea Riseborough: Oscar nomination to be reviewed by Academy
 - [https://www.bbc.co.uk/news/entertainment-arts-64450851?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64450851?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 13:42:37+00:00
 - user: None

The Academy will review Andrea Riseborough's nomination amid discussions about her campaign.

## Laura Winham: Investigators seek whereabouts of gas engineer
 - [https://www.bbc.co.uk/news/uk-england-surrey-64454909?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-surrey-64454909?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 13:21:56+00:00
 - user: None

Laura Winham, 38, who had schizophrenia, was found in a "mummified, almost skeletal state".

## Review of BBC economic coverage finds concerns but no systematic bias
 - [https://www.bbc.co.uk/news/entertainment-arts-64453200?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64453200?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 13:04:33+00:00
 - user: None

A report into BBC reporting of government financial policies finds "weaknesses" but no systemic bias.

## Bayern in talks to sign Man City defender Cancelo
 - [https://www.bbc.co.uk/sport/football/64452933?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64452933?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 13:03:06+00:00
 - user: None

Manchester City defender Joao Cancelo is in talks to join German champions Bayern Munich on loan before Tuesday's transfer window deadline.

## Cost of living: One in five eating food beyond use-by date
 - [https://www.bbc.co.uk/news/business-64452348?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64452348?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 12:59:05+00:00
 - user: None

A similar number have eaten smaller portions owing to rising prices, with more struggling to stay warm.

## Nadhim Zahawi: Sunak says he handled case decisively
 - [https://www.bbc.co.uk/news/uk-politics-64453740?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64453740?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 12:52:51+00:00
 - user: None

The PM says he followed "the right process" after learning about claims against Nadhim Zahawi.

## JD Sports says 10 million customers hit by cyber attack.
 - [https://www.bbc.co.uk/news/business-64452986?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64452986?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:57:32+00:00
 - user: None

The sportswear chain says stored data relating to its customers might be at risk following the attack.

## Campbell Johnstone: Former All Black hopes coming out will 'take away the stigma' of being gay
 - [https://www.bbc.co.uk/sport/rugby-union/64452098?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64452098?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:40:44+00:00
 - user: None

Former New Zealand prop Campbell Johnstone hopes to "take away the pressure and stigma" as the first All Black to come out as gay.

## No trans prisoners have attacked women, says justice minister
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64431383?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-64431383?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:32:53+00:00
 - user: None

The justice secretary says none of five trans prisoners in women's units had convictions for violence against women.

## Grenfell fire: Housing developers given ultimatum to fix unsafe buildings
 - [https://www.bbc.co.uk/news/uk-england-london-64450711?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64450711?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:15:51+00:00
 - user: None

Companies will face 'significant consequences' over unsafe buildings, the housing secretary says.

## Pakistan mosque blast: At least 28 killed after explosion in Peshawar
 - [https://www.bbc.co.uk/news/world-asia-64451936?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64451936?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:10:04+00:00
 - user: None

More than 150 were injured in an explosion at a mosque in the Pakistani city of Peshawar.

## Hexham stabbing: Family pays tribute to Holly Newton
 - [https://www.bbc.co.uk/news/uk-england-tyne-64450907?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-64450907?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:08:34+00:00
 - user: None

Holly Newton, 15, was fatally wounded in Hexham on Friday evening and later died in hospital.

## Rory McIlroy beats Patrick Reed to win Dubai Desert Classic
 - [https://www.bbc.co.uk/sport/golf/64450326?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/golf/64450326?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 11:00:27+00:00
 - user: None

Rory McIlroy emerges victorious from a tense tussle with rival Patrick Reed to win his third Dubai Desert Classic title.

## NFL: Kansas City Chiefs beat Cincinnati Bengals 23-20 to reach Super Bowl - highlights
 - [https://www.bbc.co.uk/sport/av/american-football/64452631?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/64452631?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 10:58:11+00:00
 - user: None

Watch highlights as the Kansas City Chiefs beat the Cincinnati Bengals 23-20 in the AFC Championship game to reach their third Super Bowl in four years.

## Firm fined £120k after builders lifted in digger's bucket
 - [https://www.bbc.co.uk/news/uk-england-manchester-64440273?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64440273?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 10:56:36+00:00
 - user: None

Two men fitted a stone from an airborne bucket at a housing site in Littleborough.

## Annie Wersching: The Last of Us video game and 24 actress, dies at 45
 - [https://www.bbc.co.uk/news/entertainment-arts-64450133?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64450133?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 10:46:42+00:00
 - user: None

Wersching, who also featured in TV shows 24 and Star Trek: Picard, dies from cancer at the age of 45.

## Video streaming subscriptions fall by two million in 2022
 - [https://www.bbc.co.uk/news/business-64450202?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64450202?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 10:06:38+00:00
 - user: None

Households cut back on streaming services in their droves as the cost of living rose sharply.

## Barrett Strong: Motown trailblazer and hitmaker, dies at 81
 - [https://www.bbc.co.uk/news/entertainment-arts-64450921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64450921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 10:03:46+00:00
 - user: None

Barrett Strong scored Motown's first major hit and went on to write I Heard It Through The Grapevine.

## Village hall ban for councillor after warm space Facebook post
 - [https://www.bbc.co.uk/news/uk-england-gloucestershire-64450965?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-gloucestershire-64450965?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 09:46:25+00:00
 - user: None

She had written a Facebook post asking about using the hall as a warm space for vulnerable people.

## Teacher accused of abuse at Edinburgh schools arrested
 - [https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-64449983?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-edinburgh-east-fife-64449983?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 09:21:22+00:00
 - user: None

Man accused of abuse by BBC broadcaster Nicky Campbell set to appear in court in South Africa.

## Covid in China: Officials say current wave is 'coming to an end'
 - [https://www.bbc.co.uk/news/world-asia-china-64449226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-china-64449226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 08:50:05+00:00
 - user: None

Authorities say the death toll has peaked, and there's been no case spike during Lunar New Year.

## 'Gut-wrenching' referee error costs Lakers
 - [https://www.bbc.co.uk/sport/basketball/64450359?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/basketball/64450359?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 08:27:53+00:00
 - user: None

Match referees admit making a "gut-wrenching" error after being accused of cheating by the Los Angeles Lakers in their defeat by the Boston Celtics.

## Rare 'mother-of-pearl' cloud spotted in Scotland
 - [https://www.bbc.co.uk/news/uk-scotland-64450253?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64450253?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 08:24:28+00:00
 - user: None

Stunning Nacreous cloud captured by BBC Weather Watchers in Scotland.

## Nicola Bulley: Missing Inskip dog walker prompts police search
 - [https://www.bbc.co.uk/news/uk-england-lancashire-64450243?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-lancashire-64450243?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 07:25:19+00:00
 - user: None

Nicola Bulley has been missing since she took her dog for a walk on Friday morning, police say.

## ULEZ expansion: Pressure mounts on London mayor to reconsider plans
 - [https://www.bbc.co.uk/news/uk-england-london-64373344?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-64373344?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 06:46:57+00:00
 - user: None

Over half of outer London boroughs have voiced concerns with some councils considering legal action.

## Novak Djokovic: Why can't the next generation stop the Australian Open champion?
 - [https://www.bbc.co.uk/sport/tennis/64443257?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64443257?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 06:46:09+00:00
 - user: None

After 35-year-old Novak Djokovic beats another young pretender to win a record-equalling 22nd Grand Slam title, BBC Sport analyses how he is staying ahead of the rest.

## Chris Mason: What does Zahawi sacking mean for Sunak?
 - [https://www.bbc.co.uk/news/uk-politics-64449027?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64449027?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 06:35:18+00:00
 - user: None

Rishi Sunak resisted those urging him to sack Nadhim Zahawi sooner, writes Political Editor Chris Mason.

## FA Cup: Watch the best moments from Wrexham's thrilling draw against Sheffield United
 - [https://www.bbc.co.uk/sport/av/football/64440920?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64440920?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 06:04:26+00:00
 - user: None

Wrexham co-owner Ryan Reynolds experiences all the emotions of a Hollywood drama during a thrilling FA Cup fourth-round tie against Sheffield United.

## Thousands of NHS staff with long Covid risk losing their pay
 - [https://www.bbc.co.uk/news/health-64405899?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64405899?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 05:50:59+00:00
 - user: None

Analysis by BBC Panorama suggests between 5,000 and 10,000 NHS staff risk losing their pay.

## Mining giant 'sorry' over lost radioactive capsule in Australia
 - [https://www.bbc.co.uk/news/business-64448879?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64448879?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 04:34:26+00:00
 - user: None

Rio Tinto says the object went missing while it was being transported 1,400km in Western Australia.

## Auckland floods: More heavy rain ahead for New Zealand's largest city
 - [https://www.bbc.co.uk/news/world-asia-64449248?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-64449248?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 04:32:10+00:00
 - user: None

Authorities have issued severe weather warnings for Auckland and other northern towns.

## Adani Group says Hindenburg fraud claim 'calculated attack on India'
 - [https://www.bbc.co.uk/news/business-64448880?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64448880?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 04:17:01+00:00
 - user: None

Last week the Indian firm owned by Asia's richest man had more than $50bn wiped off its market value.

## Man rescued after crashing stolen police car on train tracks in Georgia
 - [https://www.bbc.co.uk/news/64448930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/64448930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 02:12:17+00:00
 - user: None

The suspect jumped into a police vehicle during a traffic stop in the US city of Atlanta.

## £1bn boost in hospital beds and ambulance fleet
 - [https://www.bbc.co.uk/news/health-64448354?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64448354?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 01:21:24+00:00
 - user: None

Extra capacity will help the NHS in England tackle emergency care delays, the prime minister says.

## Why I'm seizing the chance to scrutinise the family courts
 - [https://www.bbc.co.uk/news/uk-64411229?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64411229?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 01:01:04+00:00
 - user: None

After decades of calls for greater scrutiny, journalists are to be allowed to report on proceedings.

## Over-50s at work: 'You feel your usefulness has passed'
 - [https://www.bbc.co.uk/news/business-64441775?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64441775?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:46:00+00:00
 - user: None

New research suggests applicants are right when they say employers are less open to hiring older workers.

## The Papers: Zahawi sacked and Putin's threat to kill Johnson
 - [https://www.bbc.co.uk/news/blogs-the-papers-64448688?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64448688?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:34:36+00:00
 - user: None

The dismissal of Nadhim Zahawi and a threat by Vladimir Putin to kill Boris Johnson lead the papers.

## Ukraine war: Funeral held for battleground body collector
 - [https://www.bbc.co.uk/news/world-europe-64446436?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64446436?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:30:22+00:00
 - user: None

Denys Sosnenko was was killed by an anti-tank mine while helping to recover the remains of soldiers.

## NEU teacher strikes: Government and union to meet for last-ditch talks
 - [https://www.bbc.co.uk/news/uk-64446759?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64446759?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:16:46+00:00
 - user: None

Education Secretary Gillian Keegan will meet union chiefs in an effort to avert Wednesday's walkout.

## The family that bought the King's bed for £100
 - [https://www.bbc.co.uk/news/uk-politics-64347139?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64347139?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:13:30+00:00
 - user: None

How a Victorian bed built for monarchs to sleep in before coronations ended up in a Welsh wool mill.

## The new tech offering relief from the misery of period pain
 - [https://www.bbc.co.uk/news/business-64397795?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64397795?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:08:15+00:00
 - user: None

Two start-up firms are making wearable technology that targets menstrual discomfort.

## Childcare costs rise as providers feel the pinch
 - [https://www.bbc.co.uk/news/education-64448598?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-64448598?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:02:20+00:00
 - user: None

Prices increased across Britain over the last year due to funding pressures, a survey suggests.

## Greater Manchester Police didn't care I was abused, woman says
 - [https://www.bbc.co.uk/news/uk-england-manchester-64410912?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64410912?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:00:42+00:00
 - user: None

A woman who was forced into prostitution by her husband says police ignored her repeated pleas.

## Ukraine war: Russian athletes cannot be allowed at Olympics, Zelensky says
 - [https://www.bbc.co.uk/news/world-europe-64448808?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64448808?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-30 00:00:42+00:00
 - user: None

Olympics chiefs say Russian and Belarusian athletes could compete as neutrals, but Ukraine opposes the move.
