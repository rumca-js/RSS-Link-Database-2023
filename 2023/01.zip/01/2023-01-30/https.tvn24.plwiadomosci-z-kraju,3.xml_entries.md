# Source TVN24 Z kraju, Source URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, Source language: pl-PL

## Zwłoki humbaka wyrzucone na plażę w stanie Nowy Jork
 - [https://tvn24.pl/tvnmeteo/swiat/nowy-jork-stany-zjednoczone-morze-wyrzucilo-na-brzeg-humbaka-6710126?source=rss](https://tvn24.pl/tvnmeteo/swiat/nowy-jork-stany-zjednoczone-morze-wyrzucilo-na-brzeg-humbaka-6710126?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 20:46:52+00:00
 - user: None

<img alt="Zwłoki humbaka wyrzucone na plażę w stanie Nowy Jork" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-his1a8-humbak-na-plazy-w-nowym-jorku-6711108/alternates/LANDSCAPE_1280" />
    Humbak został wyrzucony na brzeg w stanie Nowy Jork. To kolejny w ciągu kilku tygodni martwy waleń, który został znaleziony na tym odcinku wschodniego wybrzeża Stanów Zjednoczonych.

## Atak nożownika w brukselskim metrze. Jedna z ofiar jest w stanie krytycznym
 - [https://tvn24.pl/swiat/belgia-bruksela-atak-nozownika-w-metrze-sa-ranni-6710682?source=rss](https://tvn24.pl/swiat/belgia-bruksela-atak-nozownika-w-metrze-sa-ranni-6710682?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 20:40:34+00:00
 - user: None

<img alt="Atak nożownika w brukselskim metrze. Jedna z ofiar jest w stanie krytycznym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-izs04e-policja-na-miejscu-ataku-nozownika-w-metrze-w-brukseli-6710185/alternates/LANDSCAPE_1280" />
    Nożownik zaatakował w metrze w brukselskiej dzielnicy, gdzie zlokalizowana jest większość instytucji Unii Europejskiej. Ranił trzy osoby. 30-letni podejrzany został szybko zatrzymany. Jak dotąd nie są znane motywy jego działania.

## Giganci tną wynagrodzenia prezesów. "Wciąż są przepłacani"
 - [https://tvn24.pl/biznes/ze-swiata/apple-morgan-stanley-goldman-sachs-najwieksze-firmy-tna-wynagrodzenia-prezesow-6710104?source=rss](https://tvn24.pl/biznes/ze-swiata/apple-morgan-stanley-goldman-sachs-najwieksze-firmy-tna-wynagrodzenia-prezesow-6710104?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 19:56:49+00:00
 - user: None

<img alt="Giganci tną wynagrodzenia prezesów. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-61e6wl-shutterstock1697543284-6511033/alternates/LANDSCAPE_1280" />
    Zarządy korporacji obcinają wynagrodzenia niektórym prezesom. To nowy trend, który może się dopiero rozpoczynać - napisał portal stacji CNN.

## Czeski prezydent elekt Petr Pavel rozmawiał z przywódczynią Tajwanu Tsai Ing-wen
 - [https://tvn24.pl/swiat/prezydent-elekt-czech-petr-pavel-rozmawial-z-prezydent-tajwanu-tsai-ing-wen-6709998?source=rss](https://tvn24.pl/swiat/prezydent-elekt-czech-petr-pavel-rozmawial-z-prezydent-tajwanu-tsai-ing-wen-6709998?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 18:46:08+00:00
 - user: None

<img alt="Czeski prezydent elekt Petr Pavel rozmawiał z przywódczynią Tajwanu Tsai Ing-wen" src="https://tvn24.pl/najnowsze/cdn-zdjecie-is3weq-petr-pavel-6710006/alternates/LANDSCAPE_1280" />
    Prezydent elekt Czech Petr Pavel rozmawiał telefonicznie z prezydent Taiwanu Tsai Ing-wen. Politycy mieli potwierdzić wspólne wartości i zgodę na wzmacnianie partnerstwa. Przy rozmowie był obecny również tajwański minister spraw zagranicznych Joseph Wu.

## Samochód dostawczy na barierkach po zderzeniu z autem osobowym
 - [https://tvn24.pl/tvnwarszawa/ulice/grzedy-dk7-samochod-dostawczy-na-barierkach-po-zderzeniu-z-autem-osobowym-6710030?source=rss](https://tvn24.pl/tvnwarszawa/ulice/grzedy-dk7-samochod-dostawczy-na-barierkach-po-zderzeniu-z-autem-osobowym-6710030?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 18:43:55+00:00
 - user: None

<img alt="Samochód dostawczy na barierkach po zderzeniu z autem osobowym " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1wtaa9-wypadek-na-krajowej-siodemce-w-miejscowosci-grzedy-6710022/alternates/LANDSCAPE_1280" />
    Do zdarzenia doszło na drodze krajowej numer siedem w miejscowości Grzędy. Zderzyły się: dostawcze iveco i osobowy citroen. Samochód dostawczy po zderzeniu zawisł na barierkach. Policja poinformowała o utrudnieniach w kierunku Krakowa.

## Pogoda na jutro - wtorek 31.01. Noc przyniesie zawieje śnieżne, dzień - opady mokrego śniegu
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-3101-noc-przyniesie-zawieje-sniezne-dzien-opady-mokrego-sniegu-6709997?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-3101-noc-przyniesie-zawieje-sniezne-dzien-opady-mokrego-sniegu-6709997?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 18:24:42+00:00
 - user: None

<img alt="Pogoda na jutro - wtorek 31.01. Noc przyniesie zawieje śnieżne, dzień - opady mokrego śniegu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-qog5db-noc-intensywne-opady-sniegu-6508740/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli wtorek 31.01. Kolejne godziny przyniosą w części Polski zawieje śnieżne i oblodzone, śliskie nawierzchnie. Widzialność może być mocno ograniczona. Opady śniegu wystąpią miejscami także w ciągu dnia.

## To rozwiązanie zrobiło w Niemczech furorę. Wraca od maja z nową ceną
 - [https://tvn24.pl/biznes/ze-swiata/niemcy-bilet-miesieczny-na-transport-za-49-euro-od-1-maja-6709944?source=rss](https://tvn24.pl/biznes/ze-swiata/niemcy-bilet-miesieczny-na-transport-za-49-euro-od-1-maja-6709944?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 18:00:17+00:00
 - user: None

<img alt="To rozwiązanie zrobiło w Niemczech furorę. Wraca od maja z nową ceną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7qrm59-shutterstock2035098575-6709954/alternates/LANDSCAPE_1280" />
    Bilet miesięczny w transporcie lokalnym na terenie całych Niemiec ma wrócić od maja. Jego cena będzie wynosić 49 euro - poinformował portal Deutsche Welle.

## Sąd uniewinnił byłego szefa ABW generała Krzysztofa Bondaryka
 - [https://tvn24.pl/polska/general-krzysztof-bondaryk-byly-szef-abw-uniewinniony-6709843?source=rss](https://tvn24.pl/polska/general-krzysztof-bondaryk-byly-szef-abw-uniewinniony-6709843?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 17:08:19+00:00
 - user: None

<img alt="Sąd uniewinnił byłego szefa ABW generała Krzysztofa Bondaryka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fn2tdh-general-krzysztof-bondaryk-6709931/alternates/LANDSCAPE_1280" />
    Sąd uniewinnił od prokuratorskich zarzutów generała Krzysztofa Bondaryka, który kierował Agencją Bezpieczeństwa Wewnętrznego w czasach rządu Donalda Tuska - dowiedział się tvn24.pl. Nieoficjalnie wiadomo, że prokuratura będzie się odwoływać od kolejnej już niekorzystnej dla siebie decyzji.

## Na osiedlu znaleziono niewybuch. Ewakuowali mieszkańców, czekają na saperów
 - [https://tvn24.pl/katowice/czestochowa-na-osiedlu-znaleziono-niewybuch-trzeba-bylo-ewakuowac-mieszkancow-6709860?source=rss](https://tvn24.pl/katowice/czestochowa-na-osiedlu-znaleziono-niewybuch-trzeba-bylo-ewakuowac-mieszkancow-6709860?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 17:03:35+00:00
 - user: None

<img alt="Na osiedlu znaleziono niewybuch. Ewakuowali mieszkańców, czekają na saperów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4vixsn-podczas-budowy-nitki-gazociagu-na-ulicy-kossaka-w-czestochowie-znaleziono-niewybuch-6709880/alternates/LANDSCAPE_1280" />
    Podczas budowy nitki gazociągu na ulicy Kossaka w Częstochowie (woj. śląskie) znaleziono niewybuch. Teren zabezpiecza policja, zarządzono ewakuację mieszkańców. Informację i zdjęcia z miejsca zdarzenia otrzymaliśmy na Kontakt 24.

## Iran. Tańczyli na placu w Teheranie. Sąd: Są winni zachęcania do demoralizacji. Trafią do więzienia
 - [https://tvn24.pl/swiat/iran-blogerzy-skazani-na-wiezienie-za-taniec-na-placu-w-teheranie-6709839?source=rss](https://tvn24.pl/swiat/iran-blogerzy-skazani-na-wiezienie-za-taniec-na-placu-w-teheranie-6709839?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:40:28+00:00
 - user: None

<img alt="Iran. Tańczyli na placu w Teheranie. Sąd: Są winni zachęcania do demoralizacji. Trafią do więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bivr0f-shutterstock386662756-6709849/alternates/LANDSCAPE_1280" />
    Sąd w Teheranie skazał w niedzielę na karę ponad 10 lat więzienia dwoje młodych blogerów. Opublikowali oni w sieci nagranie, na którym widać, jak tańczą na jednym z głównych placów stolicy - poinformował portal Iran Wire. Według sądu Amir Ahmadżi i Astiadż Hadżidżi są winni "zachęcania do demoralizacji".

## Czeka nas czas z dynamiczną pogodą. Możliwe zawieje śnieżne
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-piec-dni-czy-spadnie-snieg-pogoda-na-luty-poczatek-lutego-przyniesie-mieszane-opady-miejscami-wystapi-lekki-mroz-6709787?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-piec-dni-czy-spadnie-snieg-pogoda-na-luty-poczatek-lutego-przyniesie-mieszane-opady-miejscami-wystapi-lekki-mroz-6709787?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:35:40+00:00
 - user: None

<img alt="Czeka nas czas z dynamiczną pogodą. Możliwe zawieje śnieżne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eekm4a-popada-snieg-6709838/alternates/LANDSCAPE_1280" />
    Najbliższe dni przyniosą w części Polski opady śniegu, które będą przechodzić w opady deszczu. Powieje wiatr, który w porywach osiągnie prędkość do 80 kilometrów na godzinę.

## Prawie 600 pielęgniarek ma rozważać pozwanie szpitala. Spór o kwalifikacje i podwyżki
 - [https://tvn24.pl/polska/krakow-prawie-600-pielegniarek-ma-rozwazac-pozwanie-szpitala-uniwersyteckiego-chodzi-o-podwyzki-i-uznanie-kwalifikacji-6709801?source=rss](https://tvn24.pl/polska/krakow-prawie-600-pielegniarek-ma-rozwazac-pozwanie-szpitala-uniwersyteckiego-chodzi-o-podwyzki-i-uznanie-kwalifikacji-6709801?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:09:50+00:00
 - user: None

<img alt="Prawie 600 pielęgniarek ma rozważać pozwanie szpitala. Spór o kwalifikacje i podwyżki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yrv212-szpital-uniwersytecki-w-krakowie-5040919/alternates/LANDSCAPE_1280" />
    Prawie 600 pielęgniarek ma rozważać pozwanie Szpitala Uniwersyteckiego w Krakowie - wynika ze słów Patrycji Błaszczyk, jednej z pielęgniarek tej placówki. Jak podkreśliła w poniedziałek na konferencji prasowej małopolskich polityków Koalicji Obywatelskiej, pracodawca nie uznaje ich kwalifikacji i nie wypłaca przewidzianych ustawą podwyżek. "Nie mamy sobie nic do zarzucenia" - odpowiada dyrekcja szpitala.

## Prawo zmieniane pod Kaczyńskiego? W TK jest wniosek Manowskiej w sprawie Kodeksu postępowania cywilnego
 - [https://tvn24.pl/polska/lex-kaczynski-trybunal-konstytucyjny-wniosek-i-prezes-sadu-najwyzszego-w-sprawie-kodeksu-postepowania-cywilnego-w-tk-6709554?source=rss](https://tvn24.pl/polska/lex-kaczynski-trybunal-konstytucyjny-wniosek-i-prezes-sadu-najwyzszego-w-sprawie-kodeksu-postepowania-cywilnego-w-tk-6709554?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:04:40+00:00
 - user: None

<img alt="Prawo zmieniane pod Kaczyńskiego? W TK jest wniosek Manowskiej w sprawie Kodeksu postępowania cywilnego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vf4yqa-u2ntitled-1-6709690/alternates/LANDSCAPE_1280" />
    Sejm przyjął w zeszłym tygodniu zmiany w Kodeksie postępowania cywilnego, które, zdaniem opozycji, są skrojone pod Jarosława Kaczyńskiego. Określają maksymalną grzywnę za nieopublikowanie nakazanych przez sąd przeprosin. Tymczasem, jak się okazuje, w grudniu zeszłego roku pierwsza prezes Sądu Najwyższego Małgorzata Manowska złożyła do Trybunału Konstytucyjnego wniosek w sprawie stwierdzenia niekonstytucyjności dwóch przepisów ustawy, które dotyczą zapłaty przez dłużnika na rzecz wierzyciela przymusowej sumy pieniężnej.

## Leniwce zamarzły w samolocie
 - [https://tvn24.pl/tvnmeteo/swiat/belgia-leniwce-zamarzly-na-smierc-w-samolocie-6709805?source=rss](https://tvn24.pl/tvnmeteo/swiat/belgia-leniwce-zamarzly-na-smierc-w-samolocie-6709805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:03:39+00:00
 - user: None

<img alt="Leniwce zamarzły w samolocie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-618j2i-leniuchowiec-dwupalczasty-choloepus-didactylus-jeden-z-gatunkow-leniwcow-wystepujacych-w-peru-zdj-ilustracyjne-6709841/alternates/LANDSCAPE_1280" />
    Leniwce zamarzły w samolocie znajdującym się na belgijskim lotnisku Liège. Z uwagi na paraliż komunikacyjny, jaki zapanował w zeszłym tygodniu w wyniku obfitych opadów śniegu, zwierzęta utknęły w nieogrzewanym samolocie na ponad 24 godziny. Władze regionu zapowiadają śledztwo w sprawie tego tragicznego zaniedbania.

## RPA. Strzelanina podczas przyjęcia urodzinowego, są zabici i ranni. Trwa obława na sprawców
 - [https://tvn24.pl/swiat/rpa-strzelanina-podczas-przyjecia-urodzinowego-zabici-i-ranni-6709824?source=rss](https://tvn24.pl/swiat/rpa-strzelanina-podczas-przyjecia-urodzinowego-zabici-i-ranni-6709824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 16:03:15+00:00
 - user: None

<img alt="RPA. Strzelanina podczas przyjęcia urodzinowego, są zabici i ranni. Trwa obława na sprawców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6elbsr-en015528050353-1-6709828/alternates/LANDSCAPE_1280" />
    Osiem osób zginęło, a trzy zostały ranne w strzelaninie w mieście Gqeberha w Republice Południowej Afryki. Do ataku doszło w trakcie przyjęcia urodzinowego. Zginął między innymi gospodarz. Miejscowa szefowa policji określiła napaść jako "bezduszną i dokonaną z zimną krwią".

## Ruszył proces księdza oskarżonego o molestowanie nieletniego chłopca
 - [https://tvn24.pl/bialystok/zambrow-wyszkow-ruszyl-proces-ksiedza-oskarzonego-o-molestowanie-nieletniego-chlopca-6709578?source=rss](https://tvn24.pl/bialystok/zambrow-wyszkow-ruszyl-proces-ksiedza-oskarzonego-o-molestowanie-nieletniego-chlopca-6709578?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 15:07:22+00:00
 - user: None

<img alt="Ruszył proces księdza oskarżonego o molestowanie nieletniego chłopca  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-33g6zu-ruszyl-proces-ksiedza-oskarzonego-o-molestowanie-nieletniego-chlopca-6709797/alternates/LANDSCAPE_1280" />
    Przed Sądem Rejonowym w Wyszkowie ruszył proces księdza Łukasza R. Duchowny został oskarżony m.in. o molestowanie seksualne chłopca poniżej 15. roku życia. Pełnił posługę kapłańską na terenie Mazowsza i Podlasia, był też opiekunem harcerzy. Na rozprawę został doprowadzony z aresztu.

## Po kłótni z matką miał strzelić z broni do jej psa, później dobić go siekierą. Jest akt oskarżenia
 - [https://tvn24.pl/krakow/maslow-po-klotni-z-matka-mial-strzelic-z-broni-do-jej-psa-pozniej-dobic-go-siekiera-jest-akt-oskarzenia-6709625?source=rss](https://tvn24.pl/krakow/maslow-po-klotni-z-matka-mial-strzelic-z-broni-do-jej-psa-pozniej-dobic-go-siekiera-jest-akt-oskarzenia-6709625?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:59:30+00:00
 - user: None

<img alt="Po kłótni z matką miał strzelić z broni do jej psa, później dobić go siekierą. Jest akt oskarżenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie8278d5e7bb8457357b4fe8fd81551350-za-10-zlotych-zabil-psa-4350562/alternates/LANDSCAPE_1280" />
    Kielecka prokuratura skierowała do sądu akt oskarżenia przeciwko Łukaszowi D., który ze szczególnym okrucieństwem miał zabić psa swojej matki. Jak ustalili śledczy, po kłótni z kobietą 41-latek miał strzelić do zwierzęcia z broni palnej, a następnie dobić go siekierą. Mężczyzna nie przyznaje się do popełnienia zarzucanych mu czynów.

## Zasłabł i stracił przytomność w trakcie meczu, pomogli mu strażacy. "Umiejętności udzielania pierwszej pomocy są bezcenne"
 - [https://tvn24.pl/pomorze/gdansk-zaslabl-i-stracil-przytomnosc-w-trakcie-meczu-pomogli-mu-strazacy-6709715?source=rss](https://tvn24.pl/pomorze/gdansk-zaslabl-i-stracil-przytomnosc-w-trakcie-meczu-pomogli-mu-strazacy-6709715?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:45:42+00:00
 - user: None

<img alt="Zasłabł i stracił przytomność w trakcie meczu, pomogli mu strażacy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-b6hxfy-strazacy-przeprowadzili-resuscytacje-podczas-meczu-6709724/alternates/LANDSCAPE_1280" />
    Dwóch strażaków podczas towarzyskiego meczu KS Korona Cedry Małe z Bałtykiem Sztutowo przeprowadziło resuscytację zawodnika, który nagle stracił przytomność. Akcję ratunkową prowadzili aż do przyjazdu pogotowia. Mężczyznę udało się uratować. - Umiejętności udzielania pierwszej pomocy są bezcenne - podkreślają strażacy.

## Sekretarz stanu USA Antony Blinken na Bliskim Wchodzie. Zaczął od wizyty w Egipcie
 - [https://tvn24.pl/swiat/usa-sekretarz-stanu-antony-blinken-na-bliskim-wchodzie-zaczal-od-wizyty-w-egipcie-6709665?source=rss](https://tvn24.pl/swiat/usa-sekretarz-stanu-antony-blinken-na-bliskim-wchodzie-zaczal-od-wizyty-w-egipcie-6709665?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:25:40+00:00
 - user: None

<img alt="Sekretarz stanu USA Antony Blinken na Bliskim Wchodzie. Zaczął od wizyty w Egipcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lal22l-sekretarz-stanu-usa-i-prezydent-egiptu-6709666/alternates/LANDSCAPE_1280" />
    Działania zmierzające do deeskalacji napięć izraelsko-palestyńskich oraz kluczowe kwestie regionalne były tematami rozmów między sekretarzem stanu USA Antonym Blinkenem a egipskim prezydentem Abdem el-Fatahem es-Sisim. Szef amerykańskiej dyplomacji wizytą w Egipcie rozpoczął podróż po Bliskim Wschodzie.

## Zabrze. Podejrzewany o zgwałcenie 17-latki zatrzymany przez policję po publikacji jego wizerunku
 - [https://tvn24.pl/katowice/zabrze-pojechali-razem-autobusem-mezczyzna-mial-zgwalcic-17-latke-w-pustostanie-policja-go-zatrzymala-6709616?source=rss](https://tvn24.pl/katowice/zabrze-pojechali-razem-autobusem-mezczyzna-mial-zgwalcic-17-latke-w-pustostanie-policja-go-zatrzymala-6709616?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:16:30+00:00
 - user: None

<img alt="Zabrze. Podejrzewany o zgwałcenie 17-latki zatrzymany przez policję po publikacji jego wizerunku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ct637i-policja-zdjecie-ilustracyjne-6149875/alternates/LANDSCAPE_1280" />
    Funkcjonariusze z Zabrza zatrzymali mężczyznę, który jest podejrzewany o zgwałcenie 17-latki - przekazała wieczorem w poniedziałek śląska policja. Wcześniej opublikowano w mediach społecznościowych wizerunek poszukiwanego. Bliższe informacje w tej sprawie zapowiadane są na wtorek.

## Strajk kontrolerów w Hiszpanii. Utrudnienia na popularnych kierunkach
 - [https://tvn24.pl/biznes/ze-swiata/hiszpania-strajk-kontrolerow-utrudnienia-na-popularnych-kierunkach-min-ibiza-fuerteventura-lanzarote-sewilla-alicante-i-walencja-6709681?source=rss](https://tvn24.pl/biznes/ze-swiata/hiszpania-strajk-kontrolerow-utrudnienia-na-popularnych-kierunkach-min-ibiza-fuerteventura-lanzarote-sewilla-alicante-i-walencja-6709681?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:09:23+00:00
 - user: None

<img alt="Strajk kontrolerów w Hiszpanii. Utrudnienia na popularnych kierunkach" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-ocx602-lotnisko-w-madrycie-6709679/alternates/LANDSCAPE_1280" />
    W Hiszpanii kontrolerzy lotów rozpoczęli strajk na 16 lotniskach. 24-godzinny protest na tle płacowym będzie kontynuowany w lutym - poinformowali organizatorzy akcji strajkowej.

## Śnieg powoduje utrudnienia. Przejazd na trasie Harachov - Szklarska Poręba częściowo zamknięty
 - [https://tvn24.pl/tvnmeteo/polska/zima-w-polsce-opady-sniegu-powoduja-utrudnienia-na-drogach-6709647?source=rss](https://tvn24.pl/tvnmeteo/polska/zima-w-polsce-opady-sniegu-powoduja-utrudnienia-na-drogach-6709647?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:06:51+00:00
 - user: None

<img alt="Śnieg powoduje utrudnienia. Przejazd na trasie Harachov - Szklarska Poręba częściowo zamknięty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7yktbv-poniedzialkowe-opady-sniegu-w-lodzi-6709675/alternates/LANDSCAPE_1280" />
    Obfite opady śniegu w poniedziałek utrudniają ruch drogowy w wielu częściach kraju. Śliskie drogi są zmorą kierowców i pasażerów, a na ulice miast raz po raz wyjeżdżają pługopiaskarki. W województwie dolnośląskim występują utrudnienia w ruchu pojazdów ciężarowych.

## Awaria urządzeń sterowania ruchem, były opóźnienia pociągów na linii średnicowej
 - [https://tvn24.pl/tvnwarszawa/komunikacja/awaria-urzadzen-sterowania-ruchem-byly-opoznienia-pociagow-na-linii-srednicowej-6709671?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/awaria-urzadzen-sterowania-ruchem-byly-opoznienia-pociagow-na-linii-srednicowej-6709671?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:02:32+00:00
 - user: None

<img alt="Awaria urządzeń sterowania ruchem, były opóźnienia pociągów na linii średnicowej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-i6pla4-na-stacji-warszawa-zachodnia-doszlo-do-awarii-6642434/alternates/LANDSCAPE_1280" />
    Z powodu usterki urządzeń sterowania ruchem na podmiejskiej linii średnicowej w rejonie stacji Warszawa Zachodnia występowały utrudnienia w ruchu wszystkich przewoźników - informował rzecznik PKP PLK Karol Jakubowski. Awaria została naprawiona. Pociągi jeżdżą zgodnie z rozkładem.

## Awaria urządzeń sterowania ruchem, opóźnienia pociągów na linii średnicowej
 - [https://tvn24.pl/tvnwarszawa/komunikacja/awaria-urzadzen-sterowania-ruchem-opoznienia-pociagow-na-linii-srednicowej-6709671?source=rss](https://tvn24.pl/tvnwarszawa/komunikacja/awaria-urzadzen-sterowania-ruchem-opoznienia-pociagow-na-linii-srednicowej-6709671?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 14:02:32+00:00
 - user: None

<img alt="Awaria urządzeń sterowania ruchem, opóźnienia pociągów na linii średnicowej" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-i6pla4-na-stacji-warszawa-zachodnia-doszlo-do-awarii-6642434/alternates/LANDSCAPE_1280" />
    Z powodu usterki urządzeń sterowania ruchem na podmiejskiej linii średnicowej w rejonie stacji Warszawa Zachodnia, występują utrudnienia w ruchu wszystkich przewoźników - poinformował rzecznik PKP PLK Karol Jakubowski. To już druga awaria w rejonie stacji Warszawa Zachodnia w ostatnim czasie.

## Policzyli żubry w Puszczy Białowieskiej, teraz weryfikują dane. Było trudno, bo brakowało śniegu
 - [https://tvn24.pl/bialystok/bialowieza-policzyli-zubry-w-puszczy-teraz-weryfikuja-dane-w-tym-roku-bylo-trudno-bo-brakowalo-sniegu-6709139?source=rss](https://tvn24.pl/bialystok/bialowieza-policzyli-zubry-w-puszczy-teraz-weryfikuja-dane-w-tym-roku-bylo-trudno-bo-brakowalo-sniegu-6709139?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:42:44+00:00
 - user: None

<img alt="Policzyli żubry w Puszczy Białowieskiej, teraz weryfikują dane. Było trudno, bo brakowało śniegu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9q7d57-liczenie-w-terenie-juz-sie-zakonczylo-teraz-trwa-weryfikacja-danych-6709609/alternates/LANDSCAPE_1280" />
    Pracownicy Białowieskiego Parku Narodowego, leśnicy, naukowcy i wolontariusze wybrali się, jak co roku, w teren, by policzyć żubry bytujące po polskiej stronie puszczy. Wyniki mają być znane w połowie lutego. Liczenie staje się coraz trudniejszym zadaniem z uwagi na bezśnieżne zimy. Żubry zbierają się w większe stada, gdy leży śnieg. Łatwo można je też wtedy wytropić po śladach.

## Premier o cenach biletów kolejowych. "To jest ta zmora"
 - [https://tvn24.pl/biznes/z-kraju/ceny-biletow-kolejowych-pkp-premier-mateusz-morawiecki-zapowiada-obnizke-w-ciagu-2-tygodni-6709593?source=rss](https://tvn24.pl/biznes/z-kraju/ceny-biletow-kolejowych-pkp-premier-mateusz-morawiecki-zapowiada-obnizke-w-ciagu-2-tygodni-6709593?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:22:11+00:00
 - user: None

<img alt="Premier o cenach biletów kolejowych. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-725r20-shutterstock1589152165-6635667/alternates/LANDSCAPE_1280" />
    W ciągu najbliższych dwóch tygodni chcemy sprawić, by nastąpił powrót do niskich cen biletów kolejowych - zapowiedział na konferencji prasowej szef rządu Mateusz Morawiecki.

## Laptopy od rządu. Czy będzie można je sprzedać?
 - [https://tvn24.pl/biznes/z-kraju/laptopy-od-rzadu-czteroklasisci-dostana-komputery-czy-mozna-je-sprzedac-6709519?source=rss](https://tvn24.pl/biznes/z-kraju/laptopy-od-rzadu-czteroklasisci-dostana-komputery-czy-mozna-je-sprzedac-6709519?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:18:40+00:00
 - user: None

<img alt="Laptopy od rządu. Czy będzie można je sprzedać?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmc4vg-laptop-laptopy-sklep-shutterstock1445581070-5192627/alternates/LANDSCAPE_1280" />
    Zostaną wprowadzone rozwiązania uniemożliwiające odsprzedaż laptopów, które w przyszłym roku otrzymają czwartoklasiści – zapowiedział pełnomocnik rządu do spraw cyberbezpieczeństwa Janusz Cieszyński.

## Wuhłedar, "kluczowy bastion" ukraińskiej obrony w Donbasie
 - [https://tvn24.pl/najnowsze/ukraina-wuhledar-kluczowy-bastion-ukrainskiej-obrony-w-donbasie-6709528?source=rss](https://tvn24.pl/najnowsze/ukraina-wuhledar-kluczowy-bastion-ukrainskiej-obrony-w-donbasie-6709528?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:11:36+00:00
 - user: None

<img alt="Wuhłedar, " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1pz3t5-ukraina-wojsko-6709585/alternates/LANDSCAPE_1280" />
    Wuhłedar to obecnie kluczowy bastion naszej obrony w Donbasie - powiedział w rozmowie z niezależnymi rosyjskimi mediami rzecznik ukraińskiej 68. samodzielnej brygady strzelców Jewhen Nazarenko. Utrata kontroli nad 15-tysięcznym miasteczkiem, położonym na południu obwodu donieckiego zmusiłaby siły ukraińskie do przeorganizowania całej linii frontu.

## Praca zdalna i kontrola trzeźwości pracowników. Jest podpis prezydenta
 - [https://tvn24.pl/biznes/dlafirm/kodeks-pracy-2023-praca-zdalna-i-kontrola-trzezwosci-pracownikow-prezydent-andrzej-duda-podpisal-ustawe-6709561?source=rss](https://tvn24.pl/biznes/dlafirm/kodeks-pracy-2023-praca-zdalna-i-kontrola-trzezwosci-pracownikow-prezydent-andrzej-duda-podpisal-ustawe-6709561?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:10:38+00:00
 - user: None

<img alt="Praca zdalna i kontrola trzeźwości pracowników. Jest podpis prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ckabmi-praca-zdalna-laptop-komputer-w-domu-4654679/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda podpisał nowelizację Kodeksu pracy - poinformowała w poniedziałek Kancelaria Prezydenta RP. Przepisy wpisują pracę zdalną wpisują do Kodeksu pracy. Umożliwiają też kontrolę pracowników na obecność alkoholu w ich organizmach.

## Podczas czyszczenia studzienki kanalizacyjnej znalazł ludzkie szczątki
 - [https://tvn24.pl/krakow/charsznica-czyscil-studzienke-kanalizacyjna-znalazl-ludzkie-szczatki-policja-to-moze-byc-zaginiony-od-2018-roku-mezczyzna-6709499?source=rss](https://tvn24.pl/krakow/charsznica-czyscil-studzienke-kanalizacyjna-znalazl-ludzkie-szczatki-policja-to-moze-byc-zaginiony-od-2018-roku-mezczyzna-6709499?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:08:29+00:00
 - user: None

<img alt="Podczas czyszczenia studzienki kanalizacyjnej znalazł ludzkie szczątki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u52rbb-w-domu-znaleziono-ciala-dwoch-osob-zdjecie-ilustracyjne-6583707/alternates/LANDSCAPE_1280" />
    Szczątki człowieka znalazł w studzience kanalizacyjnej w Charsznicy pod Miechowem (woj. małopolskie) pracownik zakładu usług komunalnych. Na ukryte pod liśćmi kości natknął się po tym, jak miejscowy dom opieki powiadomił o problemie z odpływem ścieków. Jak informuje policja, szczątki mogą należeć do zaginionego od 2018 roku mężczyzny.

## Śliskie drogi na Mazowszu. Kierowca wjechał w ogrodzenie szkoły, inny dachował
 - [https://tvn24.pl/tvnwarszawa/ulice/sliskie-drogi-na-mazowszu-kierowca-wjechal-w-ogrodzenie-szkoly-inny-dachowal-6709428?source=rss](https://tvn24.pl/tvnwarszawa/ulice/sliskie-drogi-na-mazowszu-kierowca-wjechal-w-ogrodzenie-szkoly-inny-dachowal-6709428?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:07:11+00:00
 - user: None

<img alt="Śliskie drogi na Mazowszu. Kierowca wjechał w ogrodzenie szkoły, inny dachował" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-pgahho-samochod-dachowal-w-strzykulach-6709476/alternates/LANDSCAPE_1280" />
    Opady śniegu powodują utrudnienia zarówno dla kierowców, jak i pieszych na Mazowszu. W stolicy na ulicach pracuje 170 posypywarek, a służby nie odnotowały większej liczby kolizji. Do poważnych zdarzeń doszło natomiast w podwarszawskich powiatach. Dwie osoby trafiły do szpitali.

## Policjanci uratowali mężczyznę z auta tuż przed tym, jak uderzył w nie pociąg. Nagranie
 - [https://tvn24.pl/swiat/usa-atlanta-policjanci-uratowali-mezczyzne-z-auta-tuz-przed-tym-jak-uderzyl-w-nie-pociag-nagranie-6709372?source=rss](https://tvn24.pl/swiat/usa-atlanta-policjanci-uratowali-mezczyzne-z-auta-tuz-przed-tym-jak-uderzyl-w-nie-pociag-nagranie-6709372?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:06:56+00:00
 - user: None

<img alt="Policjanci uratowali mężczyznę z auta tuż przed tym, jak uderzył w nie pociąg. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d5opuc-fragment-nagrania-z-policyjnego-helikoptera-6709373/alternates/LANDSCAPE_1280" />
    Mężczyzna, zidentyfikowany później jako 28-letni Mickal Parker, ukradł radiowóz policjantom, którzy byli akurat zajęci rutynową kontrolą drogową. Złodziej został namierzony, funkcjonariusze ruszyli za nim w pościg. W trakcie ucieczki auto wjechało na tory, tam rozbiło się i wylądowało na boku. Na udostępnionym w sieci nagraniu widać, że policjanci wyciągnęli złodzieja z pojazdu chwilę przed tym, jak uderzył w niego pociąg.

## Na spacerze znalazł zakopany worek, a w nim osiem martwych węży. Policja: zostały uduszone
 - [https://tvn24.pl/poznan/tarnowo-podgorne-na-spacerze-znalazl-zakopany-worek-a-w-nim-osiem-martwych-wezy-policja-zostaly-uduszone-6709419?source=rss](https://tvn24.pl/poznan/tarnowo-podgorne-na-spacerze-znalazl-zakopany-worek-a-w-nim-osiem-martwych-wezy-policja-zostaly-uduszone-6709419?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 13:02:07+00:00
 - user: None

<img alt="Na spacerze znalazł zakopany worek, a w nim osiem martwych węży. Policja: zostały uduszone" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8ilswq-pyton-6236361/alternates/LANDSCAPE_1280" />
    Osiem martwych węży - o długości od trzech do sześciu metrów - zostało znalezionych na jednej z leśnych dróg w Tarnowie Podgórnym (Wielkopolska). Jak informuje policja, pytony i boa zostały uduszone. Funkcjonariusze szukają sprawcy uśmiercenia zwierząt i apelują do wszystkich, którzy mogą mieć informacje na temat właściciela gadów.

## Japońska straż przybrzeżna: chińskie jednostki wpłynęły na nasze wody terytorialne
 - [https://tvn24.pl/swiat/japonia-chinskie-jednostki-na-wodach-wokol-spornych-wysp-senkaku-6709444?source=rss](https://tvn24.pl/swiat/japonia-chinskie-jednostki-na-wodach-wokol-spornych-wysp-senkaku-6709444?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:37:49+00:00
 - user: None

<img alt="Japońska straż przybrzeżna: chińskie jednostki wpłynęły na nasze wody terytorialne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mfed0l-jednostki-japonskiej-strazy-przybrzeznej-na-wodach-wokol-senkaku-wrzesien-2012-6709483/alternates/LANDSCAPE_1280" />
    Na japońskie wody terytorialne wokół spornych wysp Senkaku wpłynęły w poniedziałek cztery chińskie jednostki - poinformowała straż przybrzeżna Japonii. Chiny nazywają kontrolowane przez Tokio wyspy Diaoyu i uznają je za własne terytorium.

## Wjechała w rowerzystkę z dzieckiem, była pijana. Jest opinia biegłych
 - [https://tvn24.pl/bialystok/krasnystaw-potracila-rowerzystke-z-dzieckiem-byla-pijana-jest-opinia-bieglych-6709243?source=rss](https://tvn24.pl/bialystok/krasnystaw-potracila-rowerzystke-z-dzieckiem-byla-pijana-jest-opinia-bieglych-6709243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:37:44+00:00
 - user: None

<img alt="Wjechała w rowerzystkę z dzieckiem, była pijana. Jest opinia biegłych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rjnt5a-rowerzystka-potracona-osobowka-przez-59-latke-zmarla-w-szpitalu-w-wyniku-odniesionych-obrazen-6209270/alternates/LANDSCAPE_1280" />
    59-letnia Anna K., która - mając 3,5 promila alkoholu we krwi - wjechała autem w rowerzystkę i jej dziecko jest poczytalna i może odpowiadać za swój czyn - tak orzekli biegli psychiatrzy, którzy badali kobietę. W wyniku wypadku rowerzystka zmarła, a jej trzyletni syn został ranny. 59-latka usłyszała zarzut zabójstwa i usiłowania zabójstwa z zamiarem ewentualnym. Grozi jej za to dożywocie.

## Po kolizji kierowca i pasażer uciekli. Nieoficjalnie: auto było kradzione
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-a-alejach-jerozolimskich-kierowca-i-pasazer-seata-uciekli-nieoficjalnie-auto-bylo-kradzione-6709334?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kolizja-a-alejach-jerozolimskich-kierowca-i-pasazer-seata-uciekli-nieoficjalnie-auto-bylo-kradzione-6709334?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:30:34+00:00
 - user: None

<img alt="Po kolizji kierowca i pasażer uciekli. Nieoficjalnie: auto było kradzione" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ulvbum-zderzenie-dwoch-aut-w-alejach-jerozolimskich-6709379/alternates/LANDSCAPE_1280" />
    W poniedziałek około południa w Alejach Jerozolimskich zderzyły się dwa samochody osobowe. Kierowca oraz pasażer jednego z nich "oddalili się" z miejsca zdarzenia. Nieoficjalnie ustaliliśmy, że podróżowali kradzionym autem.

## Uciekając przed prześladowaniem z nazistowskich Niemiec sprzedali obraz Picassa. Ich potomkowie chcą go odzyskać
 - [https://tvn24.pl/kultura-i-styl/usa-sprzedali-obraz-picassa-uciekajac-z-nazistowskich-niemiec-ich-potomkowie-chca-odzyskac-kobiete-prasujaca-6684940?source=rss](https://tvn24.pl/kultura-i-styl/usa-sprzedali-obraz-picassa-uciekajac-z-nazistowskich-niemiec-ich-potomkowie-chca-odzyskac-kobiete-prasujaca-6684940?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:11:18+00:00
 - user: None

<img alt="Uciekając przed prześladowaniem z nazistowskich Niemiec sprzedali obraz Picassa. Ich potomkowie chcą go odzyskać" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m62ocn-muzeum-guggenheima-w-nowym-jorku-6709383/alternates/LANDSCAPE_1280" />
    Karl i Rosi Adler w 1938 roku uciekli z nazistowskich Niemiec, a pieniądze na podróż pozyskali ze sprzedaży obrazu Pabla Picassa. Jak informuje CNN, dziś spadkobiercy niemieckich Żydów chcą odzyskać dzieło sztuki. Uważają, że niska cena, za jaką sprzedano wówczas obraz, była podyktowana sytuacją, w jakiej znaleźli się Adlerowie.

## Wiosną po wybuchach metanu na dole kopalni zostało siedmiu górników. Wrócą po nich, jest plan akcji
 - [https://tvn24.pl/katowice/pawlowice-wroca-po-siedmiu-zaginionych-gornikow-ktory-zostali-na-dole-kopalni-pniowek-po-wybuchach-metanu-w-kwietniu-2022-roku-6705688?source=rss](https://tvn24.pl/katowice/pawlowice-wroca-po-siedmiu-zaginionych-gornikow-ktory-zostali-na-dole-kopalni-pniowek-po-wybuchach-metanu-w-kwietniu-2022-roku-6705688?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:10:20+00:00
 - user: None

<img alt="Wiosną po wybuchach metanu na dole kopalni zostało siedmiu górników. Wrócą po nich, jest plan akcji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ff6mwa-kopalnia-pniowek04-5722890/alternates/LANDSCAPE_1280" />
    Do serii wybuchów metanu w kopalni Pniówek doszło w kwietniu 2022 roku. Zginęło 16 górników i ratowników górniczych. Siedmiu z nich z powodu pożaru nie udało się wydostać. Zostali tysiąc metrów pod ziemią, w miejscu które zostało odgrodzone tamą. Jastrzębska Spółka węglowa przedstawiła w poniedziałek, 30 stycznia, plan wydobycia ich na powierzchnię.

## "Morskie pająki" potrafią zregenerować swój odwłok. "Nikt się tego nie spodziewał"
 - [https://tvn24.pl/tvnmeteo/nauka/kikutnice-czyli-morskie-pajaki-potrafia-zregenerowac-swoj-odwlok-nikt-sie-tego-nie-spodziewal-6708924?source=rss](https://tvn24.pl/tvnmeteo/nauka/kikutnice-czyli-morskie-pajaki-potrafia-zregenerowac-swoj-odwlok-nikt-sie-tego-nie-spodziewal-6708924?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 12:06:55+00:00
 - user: None

<img alt="" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-3fs3fm-kikutnice-naleza-do-gromady-pycnogonida-6709188/alternates/LANDSCAPE_1280" />
    Kikutnice, zwane też "morskimi pająkami", posiadają niezwykłą, nieznaną wcześniej zdolność - potrafią zregenerować swój odwłok. Naukowcy uważają, że to odkrycie może doprowadzić w przyszłości do przełomu w odtwarzaniu utraconych części ludzkiego ciała. Badania przeprowadzono na gatunku Pycnogonum litorale, a wyniki opublikowano na łamach pisma "Evolution".

## Mieli kanarka, teraz kupili papugę, której nikt nie chciał. Pracownicy oczyszczalni ścieków mają nowego pupila
 - [https://tvn24.pl/lodz/lodz-mieli-kanarka-teraz-kupili-papuge-ktorej-nikt-nie-chcial-pracownicy-oczyszczalni-sciekow-maja-nowego-pupila-6709227?source=rss](https://tvn24.pl/lodz/lodz-mieli-kanarka-teraz-kupili-papuge-ktorej-nikt-nie-chcial-pracownicy-oczyszczalni-sciekow-maja-nowego-pupila-6709227?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:49:06+00:00
 - user: None

<img alt="Mieli kanarka, teraz kupili papugę, której nikt nie chciał. Pracownicy oczyszczalni ścieków mają nowego pupila" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jyz1c1-pracownicy-grupowej-oczyszczalni-sciekow-wykupili-ze-sklepu-papuge-6709037/alternates/LANDSCAPE_1280" />
    Pracownicy Grupowej Oczyszczalni Ścieków w Łodzi zebrali pieniądze i kupili papugę, której od kilku lat nikt nie chciał kupić. Sonia - bo tak nazywa się ptak - ma otwartą klatkę, swobodnie lata, rozmawia z pracownikami i jest wyprowadzana na spacery. Zastąpiła kanarka, który wcześniej był pupilem pracowników.

## "1000 zł na zakupy w sklepach". Oszuści podszywają się pod duży bank
 - [https://tvn24.pl/biznes/z-kraju/bnp-paribas-oszusci-podszywaja-sie-pod-bank-bnp-paribas-falszywe-reklamy-w-mediach-spolecznosciowych-6709061?source=rss](https://tvn24.pl/biznes/z-kraju/bnp-paribas-oszusci-podszywaja-sie-pod-bank-bnp-paribas-falszywe-reklamy-w-mediach-spolecznosciowych-6709061?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:27:42+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fpj1qa-telefon-4352885/alternates/LANDSCAPE_1280" />
    Zespół cyberbezpieczeństwa w Komisji Nadzoru Finansowego (CSIRT KNF) ostrzega przed oszustami podszywającymi się Bank BNP Paribas. Cyberprzestępcy stworzyli fałszywe reklamy w mediach społecznościowych.

## Jeden gen może zaważyć na istnieniu łabędzi czarnych w Australii. "Zagrożenie jest bardzo realne"
 - [https://tvn24.pl/tvnmeteo/nauka/australia-jeden-gen-moze-zawazyc-na-istnieniu-labedzi-czarnych-6709184?source=rss](https://tvn24.pl/tvnmeteo/nauka/australia-jeden-gen-moze-zawazyc-na-istnieniu-labedzi-czarnych-6709184?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:26:54+00:00
 - user: None

<img alt="Jeden gen może zaważyć na istnieniu łabędzi czarnych w Australii. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-mnptpg-labedz-czarny-cygnus-atratus-6709200/alternates/LANDSCAPE_1280" />
    Australijscy naukowcy odkryli, że tamtejsza populacja łabędzi czarnych może być tak bardzo wrażliwa na patogeny, że gdyby do kraju dotarł wirus ptasiej grypy, ptaki mogłyby wyginąć w ciągu kilku dni. Okazuje się, że jest to warunkowane przez niewłaściwie działający gen.

## Kierowcy utworzyli "wzorowy" korytarz życia na S3. Policja: należą się wielkie słowa uznania
 - [https://tvn24.pl/poznan/zielona-gora-droga-s3-kierowcy-utworzyli-wzorowy-korytarz-zycia-po-kolizji-policja-wielkie-slowa-uznania-6709171?source=rss](https://tvn24.pl/poznan/zielona-gora-droga-s3-kierowcy-utworzyli-wzorowy-korytarz-zycia-po-kolizji-policja-wielkie-slowa-uznania-6709171?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:21:23+00:00
 - user: None

<img alt="Kierowcy utworzyli " src="https://tvn24.pl/najnowsze/cdn-zdjecie-3b9f8p-korytarz-zycia-na-lubuskim-odcinku-trasy-s3-6709118/alternates/LANDSCAPE_1280" />
    Reakcja kierowców na drodze ekspresowej S3 w okolicy Zielonej Góry (woj. lubuskie) umożliwiła służbom sprawne dotarcie na miejsce kolizji. Stojące w kilkukilometrowym korku pojazdy utworzyły korytarz życia, dzięki któremu środkiem jezdni mogli szybko przejechać ratownicy. - Kierowcom należą się wielkie słowa uznania - podkreślają policjanci i publikują nagranie z radiowozu.

## Tysiąc niewidomych osób odzyskało wzrok dzięki znanemu youtuberowi
 - [https://tvn24.pl/ciekawostki/usa-tysiac-niewidomych-osob-odzyskalo-wzrok-dzieki-youtuberowi-mrbeast-oplacil-operacje-zacmy-6708333?source=rss](https://tvn24.pl/ciekawostki/usa-tysiac-niewidomych-osob-odzyskalo-wzrok-dzieki-youtuberowi-mrbeast-oplacil-operacje-zacmy-6708333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:12:29+00:00
 - user: None

<img alt="Tysiąc niewidomych osób odzyskało wzrok dzięki znanemu youtuberowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wd3phf-youtuber-oplacil-operacje-usuniecia-zacmy-tysiaca-osob-6709236/alternates/LANDSCAPE_1280" />
    Jimmy Donaldson, znany na platformie YouTube jako MrBeast, postanowił pomóc tysiącu niewidomych lub niedowidzących osób. Celebryta sfinansował operacje zaćmy ludziom, których nie było stać na taki zabieg, a jego internetowe relacje z tej akcji zbierają miliony wyświetleń. - Połowa wszystkich niewidzących osób na świecie to osoby, które potrzebują tylko 10-minutowej operacji - przyznaje uczestniczący w akcji chirurg.

## Tysiąc osób odzyskało wzrok dzięki znanemu youtuberowi
 - [https://tvn24.pl/ciekawostki/usa-tysiac-osob-odzyskalo-wzrok-dzieki-youtuberowi-mrbeast-oplacil-operacje-zacmy-6708333?source=rss](https://tvn24.pl/ciekawostki/usa-tysiac-osob-odzyskalo-wzrok-dzieki-youtuberowi-mrbeast-oplacil-operacje-zacmy-6708333?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 11:12:29+00:00
 - user: None

<img alt="Tysiąc osób odzyskało wzrok dzięki znanemu youtuberowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wd3phf-youtuber-oplacil-operacje-usuniecia-zacmy-tysiaca-osob-6709236/alternates/LANDSCAPE_1280" />
    Jimmy Donaldson, znany na platformie YouTube jako MrBeast, postanowił pomóc tysiącu niewidomych lub niedowidzących osób. Celebryta sfinansował operacje zaćmy ludziom, których nie było stać na taki zabieg, a jego internetowe relacje z tej akcji zbierają miliony wyświetleń. - Połowa wszystkich niewidzących osób na świecie to osoby, które potrzebują tylko 10-minutowej operacji - przyznaje uczestniczący w akcji chirurg.

## Liczba ludności Polski spadła. "Zanotowaliśmy najmniej urodzeń w okresie powojennym"
 - [https://tvn24.pl/biznes/z-kraju/liczba-ludnosci-w-polsce-2022-najmniej-urodzen-w-okresie-powojennym-dane-gus-6709176?source=rss](https://tvn24.pl/biznes/z-kraju/liczba-ludnosci-w-polsce-2022-najmniej-urodzen-w-okresie-powojennym-dane-gus-6709176?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:55:05+00:00
 - user: None

<img alt="Liczba ludności Polski spadła. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8e2juj-ludzie-tlum-grand-warszawski-shutterstock2231580655-6638375/alternates/LANDSCAPE_1280" />
    Liczba ludności w 2022 roku zmniejszyła się o 141 tysięcy w stosunku do poprzedniego roku - poinformował prezes Głównego Urzędu Statystycznego Dominik Rozkrut. Jak podkreślił, w ubiegłym roku zanotowano "najmniej urodzeń w okresie powojennym".

## Ktoś ukradł ze sklepu puszkę z datkami na WOŚP. Szukali dwóch mężczyzn, jednego już przesłuchali
 - [https://tvn24.pl/pomorze/gdansk-ktos-ukradl-ze-sklepu-puszke-z-datkami-na-wosp-szukali-dwoch-mezczyzn-jednego-juz-przesluchali-6709141?source=rss](https://tvn24.pl/pomorze/gdansk-ktos-ukradl-ze-sklepu-puszke-z-datkami-na-wosp-szukali-dwoch-mezczyzn-jednego-juz-przesluchali-6709141?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:52:43+00:00
 - user: None

<img alt="Ktoś ukradł ze sklepu puszkę z datkami na WOŚP. Szukali dwóch mężczyzn, jednego już przesłuchali" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9e8ykl-ustalono-personalia-zlodziei-puszki-wosp-6709587/alternates/LANDSCAPE_1280" />
    Mężczyzna miał ukraść puszkę z datkami na Wielką Orkiestrę Świątecznej Pomocy, która ustawiona była w jednym ze sklepów w Gdańsku. Kamera zarejestrowała wizerunek zarówno sprawcy, jak i drugiego mężczyzny, który prawdopodobnie mu towarzyszył. Policja ustaliła ich personalia.

## "Potrącili autem trzy osoby, jedną zaatakowali maczetą". Podejrzani zostali zatrzymani
 - [https://tvn24.pl/wroclaw/radkow-potracenie-samochodem-i-atak-maczeta-zatrzymano-dwoch-mezczyzn-6709109?source=rss](https://tvn24.pl/wroclaw/radkow-potracenie-samochodem-i-atak-maczeta-zatrzymano-dwoch-mezczyzn-6709109?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:43:40+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ezi2st-zatrzymano-dwoch-mlodych-mezczyzn-zdjecie-ilustracyjne-6709131/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali dwóch młodych mężczyzn, którzy mogą mieć związek z piątkowym napadem przed jednym z marketów w przygranicznym Radkowie na Dolnym Śląsku. Podejrzani - jak wynika z dotychczasowych ustaleń śledczych - najpierw potrącili autem trzy osoby, a później zaatakowali jedną z nich maczetą.

## IMGW alarmuje. Silny sztorm na Bałtyku
 - [https://tvn24.pl/tvnmeteo/pogoda/silny-sztorm-na-baltyku-imgw-alarmuje-wiatr-w-porywach-moze-przekraczac-100-kilometrow-na-godzine-6709005?source=rss](https://tvn24.pl/tvnmeteo/pogoda/silny-sztorm-na-baltyku-imgw-alarmuje-wiatr-w-porywach-moze-przekraczac-100-kilometrow-na-godzine-6709005?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:27:40+00:00
 - user: None

<img alt="IMGW alarmuje. Silny sztorm na Bałtyku" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-b4t9s3-prognozuje-sie-sztorm-na-baltyku-5455415/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej (IMGW) ostrzega przed sztormem. Synoptycy wydali alarmy drugiego stopnia we wschodniej części strefy brzegowej. Wiatr ma wiać tam w porywach do 9-10 stopni w skali Beauforta, czyli przekraczać nawet 100 kilometrów na godzinę.

## Prokuratura: wybuch gazu to wiodąca hipoteza. Trwa rozbiórka plebanii
 - [https://tvn24.pl/katowice/katowice-wybuch-i-zawalenie-sie-kamienicy-prokuratura-wybuch-gazu-to-wiodaca-hipoteza-trwa-rozbiorka-plebanii-6708849?source=rss](https://tvn24.pl/katowice/katowice-wybuch-i-zawalenie-sie-kamienicy-prokuratura-wybuch-gazu-to-wiodaca-hipoteza-trwa-rozbiorka-plebanii-6708849?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:27:21+00:00
 - user: None

<img alt="Prokuratura: wybuch gazu to wiodąca hipoteza. Trwa rozbiórka plebanii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-d6ayf5-kamienica-zawalila-sie-po-wybuchu-w-katowicach-szopienicach-6709154/alternates/LANDSCAPE_1280" />
    Śledczy zakończyli oględziny na gruzowisku w Katowicach Szopienicach. W piątek zawalił się tam budynek plebanii. Zginęły dwie osoby. Na wtorek zaplanowano sekcję zwłok. Wciąż nie wiadomo, co było przyczyną tragedii. Wiodącą hipotezą jest wybuch gazu.

## Auto wpadło w poślizg i uderzyło w ciężarówkę. Zginęły dwie osoby
 - [https://tvn24.pl/bialystok/czarny-piec-auto-wpadlo-w-poslizg-i-uderzylo-w-ciezarowke-nie-zyje-38-latka-i-43-latek-6709036?source=rss](https://tvn24.pl/bialystok/czarny-piec-auto-wpadlo-w-poslizg-i-uderzylo-w-ciezarowke-nie-zyje-38-latka-i-43-latek-6709036?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:15:17+00:00
 - user: None

<img alt="Auto wpadło w poślizg i uderzyło w ciężarówkę. Zginęły dwie osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-293lgr-kierujaca-wpadla-w-poslizg-6709046/alternates/LANDSCAPE_1280" />
    W miejscowości Czarny Piec (woj. warmińsko-mazurskie) doszło do tragicznego wypadku. Nie żyją 38-letnia kierująca i 43-letni pasażer auta, które na łuku drogi wpadło w poślizg i uderzyło w ciężarówkę.

## Premier Morawiecki: wszelkie dozbrajanie Ukrainy odbywa się po uzgodnieniach z sojusznikami z NATO
 - [https://tvn24.pl/polska/ukraina-premier-mateusz-morawiecki-wszelkie-dozbrajanie-odbywa-sie-po-uzgodnieniach-z-sojusznikami-z-nato-6709026?source=rss](https://tvn24.pl/polska/ukraina-premier-mateusz-morawiecki-wszelkie-dozbrajanie-odbywa-sie-po-uzgodnieniach-z-sojusznikami-z-nato-6709026?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:11:00+00:00
 - user: None

<img alt="Premier Morawiecki: wszelkie dozbrajanie Ukrainy odbywa się po uzgodnieniach z sojusznikami z NATO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hhr0xy-mariusz-blaszczak-mateusz-morawiecki-oraz-krzysztof-tchorzewski-w-w-siedzibie-18-dywizji-zmechanizowanej-6709033/alternates/LANDSCAPE_1280" />
    Wszelkie działania o charakterze wzmocnienia siły obronnej Ukrainy uzgadniamy z naszymi partnerami z NATO - powiedział w poniedziałek premier Matusz Morawiecki. Jak dodał, podobnie jak w przypadku myśliwców MiG, także "jakakolwiek inna siła powietrzna będzie w uzgodnieniu z państwami NATO realizowana".

## Rozprawy w procesie Poczobuta w ciągu najbliższych dni. "Dalsze plany będą znane później"
 - [https://tvn24.pl/swiat/bialorus-andrzej-poczobut-przed-sadem-rozprawy-w-procesie-w-ciagu-najblizszych-dni-dalsze-plany-beda-znane-pozniej-6708971?source=rss](https://tvn24.pl/swiat/bialorus-andrzej-poczobut-przed-sadem-rozprawy-w-procesie-w-ciagu-najblizszych-dni-dalsze-plany-beda-znane-pozniej-6708971?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:07:55+00:00
 - user: None

<img alt="Rozprawy w procesie Poczobuta w ciągu najbliższych dni. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t84hat-uwolnic-andrzeja-poczobuta-6634426/alternates/LANDSCAPE_1280" />
    Sąd obwodowy w Grodnie poinformował, że w tym tygodniu rozprawy w procesie działacza polskiej mniejszości na Białorusi i dziennikarza Andrzeja Poczobuta zaplanowane są na poniedziałek, wtorek i środę. Proces toczy się za zamkniętymi drzwiami, a adwokaci nie mogą udzielać informacji na temat przebiegu postępowania.

## Zgwałconej nastolatce odmówiono aborcji. Interwencja RPO w Ministerstwie Zdrowia i NFZ
 - [https://tvn24.pl/swiat/aborcja-klauzula-sumienia-zgwalconej-nastolatce-odmowiono-aborcji-interwencja-rpo-6708918?source=rss](https://tvn24.pl/swiat/aborcja-klauzula-sumienia-zgwalconej-nastolatce-odmowiono-aborcji-interwencja-rpo-6708918?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:04:41+00:00
 - user: None

<img alt="Zgwałconej nastolatce odmówiono aborcji. Interwencja RPO w Ministerstwie Zdrowia i NFZ" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmquv6-rpo-6708972/alternates/LANDSCAPE_1280" />
    Rzecznik Praw Obywatelskich podjął interwencję w Narodowym Funduszu Zdrowia oraz Ministerstwie Zdrowia w związku z odmową udzielenia aborcji zgwałconej czternastolatce z niepełnosprawnością intelektualną. Lekarze z podlaskich szpitali, do których zgłosiła się dziewczynka, powołali się na klauzulę sumienia. "Ta sytuacja doprowadziła do naruszenia prawa pacjentki do uzyskania świadczenia zdrowotnego" - ocenił RPO w komunikacie.

## Reaktywacja Spice Girls? Według prasy, słynny girlsband może wystąpić na koronacji Karola III
 - [https://tvn24.pl/kultura-i-styl/wielka-brytania-spice-girls-z-victoria-beckham-wystapia-na-koronacji-karola-iii-6708899?source=rss](https://tvn24.pl/kultura-i-styl/wielka-brytania-spice-girls-z-victoria-beckham-wystapia-na-koronacji-karola-iii-6708899?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:01:58+00:00
 - user: None

<img alt="Reaktywacja Spice Girls? Według prasy, słynny girlsband może wystąpić na koronacji Karola III" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8yng4b-spice-girls-i-ksiaze-karol-6708710/alternates/LANDSCAPE_1280" />
    Spice Girls mogą wystąpić na koncercie koronacyjnym Karola III - twierdzi "The Sun". Jak wynika z nieoficjalnych informacji gazety, na scenie miałyby pojawić się wszystkie członkinie zespołu. Ostatni raz artystki wspólnie zagrały ponad 10 lat temu.

## "No i wstaliśmy z kolan". Te dane o zarobkach są nieaktualne - a jak jest teraz?
 - [https://konkret24.tvn24.pl/polska/wynagrodzenia-no-i-wstalismy-z-kolan-to-nie-jest-aktualny-wykres-6683383?source=rss](https://konkret24.tvn24.pl/polska/wynagrodzenia-no-i-wstalismy-z-kolan-to-nie-jest-aktualny-wykres-6683383?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 10:01:22+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ou0ejk-internauci-wierzyli-ze-to-aktualne-dane-6684129/alternates/LANDSCAPE_1280" />
    "Brak przyjęcia euro drogo nas kosztuje", "ale za to inflację mamy prawie najwyższą" - komentują internauci wykres, który rzekomo pokazuje, że średnie miesięczne zarobki w Polsce są najniższe w Europie. Te dane nie są ani aktualne, ani wiarygodne. Ale najnowsze statystyki też nie są optymistyczne: w Polce nadal zarabia się dużo mniej niż w innych krajach Europy.

## Ugody z frankowiczami w dużym banku. Są nowe dane
 - [https://tvn24.pl/biznes/pieniadze/mbank-kredyty-frankowe-ugody-z-frankowiczami-mbank-podal-nowe-dane-6708964?source=rss](https://tvn24.pl/biznes/pieniadze/mbank-kredyty-frankowe-ugody-z-frankowiczami-mbank-podal-nowe-dane-6708964?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:58:26+00:00
 - user: None

<img alt="Ugody z frankowiczami w dużym banku. Są nowe dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-24d8me-mbank-5515151/alternates/LANDSCAPE_1280" />
    mBank poinformował w poniedziałek, że klienci spłacający kredyty we franku szwajcarskim podpisali do tej pory ponad 2800 ugód. mBank rozpoczął oferowanie ugód frankowych na początku listopada ubiegłego roku. Niedawno informacje w tej sprawie przekazywał też PKO Bank Polski.

## Gdzie jest śnieg? Tak długo na opady nie czekano tam od 50 lat
 - [https://tvn24.pl/tvnmeteo/swiat/nowy-jork-gdzie-jest-snieg-tak-dlugo-na-opady-nie-czekano-tam-od-50-lat-6708896?source=rss](https://tvn24.pl/tvnmeteo/swiat/nowy-jork-gdzie-jest-snieg-tak-dlugo-na-opady-nie-czekano-tam-od-50-lat-6708896?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:54:43+00:00
 - user: None

<img alt="Gdzie jest śnieg? Tak długo na opady nie czekano tam od 50 lat" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-wfwwx8-bezsniezna-zima-w-nowym-jorku-6708939/alternates/LANDSCAPE_1280" />
    W Nowym Jorku od dekad nie było równie bezśnieżnej zimy. Nieznaczne opady zostały co prawda zarejestrowane, ale nie było ich wystarczająco dużo, by można było je zmierzyć. - To po prostu dziwne. Czuję się nieswojo - komentują mieszkańcy metropolii.

## Eksplozja i pożar w kotłowni. Pracownika wyrzuciło na zewnątrz, nie przeżył
 - [https://tvn24.pl/pomorze/osie-w-kotlowni-wybuchl-pozar-nie-zyje-61-letni-pracownik-6708805?source=rss](https://tvn24.pl/pomorze/osie-w-kotlowni-wybuchl-pozar-nie-zyje-61-letni-pracownik-6708805?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:17:29+00:00
 - user: None

<img alt="Eksplozja i pożar w kotłowni. Pracownika wyrzuciło na zewnątrz, nie przeżył" src="https://tvn24.pl/najnowsze/cdn-zdjecie-944l38-w-pozarze-stolarni-zginela-jedna-osoba-6708775/alternates/LANDSCAPE_1280" />
    W pożarze kotłowni przy stolarni w Osiu (woj. kujawsko-pomorskie) zginął 61-letni mężczyzna, który pracował jako palacz w kotłowni. Z ogniem walczyło kilkanaście zastępów straży pożarnej. Dokładne przyczyny i okoliczności tego zdarzenia wyjaśnia policja pod nadzorem prokuratury w Świeciu.

## Amerykański generał przewiduje wojnę z Chinami. "Mam nadzieję, że się myli. Myślę jednak, że ma rację"
 - [https://tvn24.pl/swiat/tajwan-a-chiny-amerykanski-general-przewiduje-wojne-z-chinami-republikanin-komentuje-6708157?source=rss](https://tvn24.pl/swiat/tajwan-a-chiny-amerykanski-general-przewiduje-wojne-z-chinami-republikanin-komentuje-6708157?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:12:36+00:00
 - user: None

<img alt="Amerykański generał przewiduje wojnę z Chinami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6wc4js-chiny-sa-drugim-najwiekszym-producentem-broni-na-swiecie-3393275/alternates/LANDSCAPE_1280" />
    Do wojny między Chinami a Stanami Zjednoczonymi może dojść już w 2025 roku - ocenił generał Sił Powietrznych armii USA Mike Minihan. - Mam nadzieję, że się myli. Myślę jednak, że ma rację - skomentował tę wypowiedź nowy przewodniczący Komisji Spraw Zagranicznych w Izbie Reprezentantów Mike McCaul.

## Auto uderzyło w drzewo i stanęło w płomieniach. Zginęła 19-letnia pasażerka
 - [https://tvn24.pl/wroclaw/pazdziorno-19-letnia-pasazerka-zginela-w-wypadku-auto-rozbilo-sie-na-drzewie-i-stanelo-w-plomieniach-6708878?source=rss](https://tvn24.pl/wroclaw/pazdziorno-19-letnia-pasazerka-zginela-w-wypadku-auto-rozbilo-sie-na-drzewie-i-stanelo-w-plomieniach-6708878?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:06:39+00:00
 - user: None

<img alt="Auto uderzyło w drzewo i stanęło w płomieniach. Zginęła 19-letnia pasażerka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x1qsot-auto-rozbilo-sie-na-drzewie-i-stanelo-w-plomieniach-6708832/alternates/LANDSCAPE_1280" />
    W okolicach miejscowości Paździorno (Dolnośląskie) osobowe suzuki uderzyło w przydrożne drzewo, po czym stanęło w płomieniach. Jedna osoba wypadła z pojazdu, drugą musieli wyciągać świadkowie. Nie żyje 19-letnia pasażerka.

## Budowa piersi wpływa na ryzyko nowotworu. Kobiety nie są tego świadome - wynika z badań
 - [https://tvn24.pl/swiat/rak-piersi-gestosc-piersi-zwieksza-ryzyko-nowotworu-kobiety-nie-sa-tego-swiadome-wyniki-badan-6685441?source=rss](https://tvn24.pl/swiat/rak-piersi-gestosc-piersi-zwieksza-ryzyko-nowotworu-kobiety-nie-sa-tego-swiadome-wyniki-badan-6685441?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:03:06+00:00
 - user: None

<img alt="Budowa piersi wpływa na ryzyko nowotworu. Kobiety nie są tego świadome - wynika z badań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iqqnun-rak-piersi-2983141/alternates/LANDSCAPE_1280" />
    Niewiele kobiet jest świadomych, że wysoka gęstość piersi jest jednym z najważniejszych czynników zwiększających ryzyko zachorowania na raka piersi - wynika z badań przeprowadzonych w USA. Choć naukowcy nie do końca potrafią wyjaśnić to zjawisko, wysoka gęstość piersi wiąże się z nawet czterokrotnie wyższym ryzykiem zachorowania na nowotwór.

## Szef NATO w Korei Południowej. Wezwał władze w Seulu do zwiększania pomocy militarnej dla Ukrainy
 - [https://tvn24.pl/swiat/szef-nato-w-korei-poludniowej-wezwal-wladze-w-seulu-do-zwiekszania-pomocy-militarnej-dla-ukrainy-6708860?source=rss](https://tvn24.pl/swiat/szef-nato-w-korei-poludniowej-wezwal-wladze-w-seulu-do-zwiekszania-pomocy-militarnej-dla-ukrainy-6708860?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:02:01+00:00
 - user: None

<img alt="Szef NATO w Korei Południowej. Wezwał władze w Seulu do zwiększania pomocy militarnej dla Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cq4ss0-sekretarz-generalny-nato-jens-stoltenberg-oraz-minister-spraw-zagranicznych-korei-poludniowej-park-jin-6708861/alternates/LANDSCAPE_1280" />
    Jeśli nie chcemy, by zwyciężyła autokracja i tyrania, Ukrainie potrzebna jest broń - powiedział sekretarz generalny NATO Jens Stoltenberg, który przebywa z wizytą w Korei Południowej. Zaapelował do władz w Seulu, by zwiększyły wsparcie wojskowe dla Kijowa, wskazując przy tym na państwa, które po rozpoczęciu rosyjskiej inwazji zmieniły swoje stanowisko i zaczęły przekazywać uzbrojenie.

## Zakrwawione ciało mężczyzny przy drodze, zginął od ciosu nożem
 - [https://tvn24.pl/lodz/tuszyn-woj-lodzkie-zakrwawione-cialo-mezczyzny-przy-drodze-zginal-od-ciosu-nozem-podejrzany-o-zabojstwo-trafil-do-aresztu-6708882?source=rss](https://tvn24.pl/lodz/tuszyn-woj-lodzkie-zakrwawione-cialo-mezczyzny-przy-drodze-zginal-od-ciosu-nozem-podejrzany-o-zabojstwo-trafil-do-aresztu-6708882?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 09:00:18+00:00
 - user: None

<img alt="Zakrwawione ciało mężczyzny przy drodze, zginął od ciosu nożem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1sjeoe-cialo-32-latka-znaleziono-w-czwartek-rano-6708888/alternates/LANDSCAPE_1280" />
    Dożywocie grozi 53-letniemu mężczyźnie, który jest podejrzany o zabójstwo 32-letniego znajomego. Ze wstępnych ustaleń śledczych wynika, że pokłócili się podczas libacji alkoholowej i starszy śmiertelnie ranił nożem młodszego.

## Zamknęli wiadukt po zderzeniu dwóch aut
 - [https://tvn24.pl/tvnwarszawa/ulice/jozefow-zderzenie-dwoch-aut-na-wiadukcie-6708756?source=rss](https://tvn24.pl/tvnwarszawa/ulice/jozefow-zderzenie-dwoch-aut-na-wiadukcie-6708756?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 08:54:22+00:00
 - user: None

<img alt="Zamknęli wiadukt po zderzeniu dwóch aut" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ko99q8-zderzenie-w-jozefowie-6708887/alternates/LANDSCAPE_1280" />
    W poniedziałek rano na wiadukcie w podwarszawskim Józefowie zderzyły się dwa auta. Przeprawa była czasowo nieczynna.

## Ambasada USA ostrzega obywateli swojego kraju przed możliwymi atakami terrorystycznymi
 - [https://tvn24.pl/swiat/turcja-ambasada-usa-ostrzega-amerykanow-przed-mozliwymi-atakami-terrorystycznymi-w-stambule-6708792?source=rss](https://tvn24.pl/swiat/turcja-ambasada-usa-ostrzega-amerykanow-przed-mozliwymi-atakami-terrorystycznymi-w-stambule-6708792?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 08:40:38+00:00
 - user: None

<img alt="Ambasada USA ostrzega obywateli swojego kraju przed możliwymi atakami terrorystycznymi " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f10i9k-pakistan-protesty-6708857/alternates/LANDSCAPE_1280" />
    Ambasada USA w Turcji ostrzegła w poniedziałek Amerykanów przed możliwymi atakami na kościoły, synagogi i misje dyplomatyczne w Stambule. Zaznaczono, że niebezpieczeństwo wynika z potencjalnych ataków odwetowych za demonstracje w krajach zachodnich, na których palono Koran.

## "Wszedł do domu sąsiadki, pobił ją kijem bejsbolowym, ukradł pieniądze i uciekł"
 - [https://tvn24.pl/polska/bartoszyce-wszedl-do-domu-sasiadki-pobil-ja-kijem-bejsbolowym-ukradl-pieniadze-i-uciekl-6707824?source=rss](https://tvn24.pl/polska/bartoszyce-wszedl-do-domu-sasiadki-pobil-ja-kijem-bejsbolowym-ukradl-pieniadze-i-uciekl-6707824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 08:16:19+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ngze6o-32-latek-uderzal-sasiadke-kijem-bejsbolowym-6707746/alternates/LANDSCAPE_1280" />
    32-latek wszedł do domu swojej sąsiadki, pobił ją kijem bejsbolowym, ranił, ukradł 359 złotych i uciekł - informuje policja. Został zatrzymany, usłyszał zarzut rozboju i trafił do aresztu. Grozi mu do 18 lat pozbawienia wolności.

## Dwie stacje drugiej linii metra zamknięte
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zamkniete-stacje-drugiej-linii-metra-bemowo-i-ulrychow-6708766?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-zamkniete-stacje-drugiej-linii-metra-bemowo-i-ulrychow-6708766?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 08:14:39+00:00
 - user: None

<img alt="Dwie stacje drugiej linii metra zamknięte" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-xdv6sw-bagaz-porzucono-na-stacji-bemowo-zdj-ilustracyjne-6708797/alternates/LANDSCAPE_1280" />
    Utrudnienia na drugiej linii metra w Warszawie. M2 kursuje na trasie skróconej: Bródno-Księcia Janusza. Zamknięto stacje Bemowo i Ulrychów.

## Podejrzani o kradzież pompy głębinowej zatrzymani na granicy
 - [https://tvn24.pl/polska/biala-podlaska-robiac-zakupy-ogladali-pompe-glebinowa-pozniej-jeden-z-nich-mial-ja-ukrasc-6708411?source=rss](https://tvn24.pl/polska/biala-podlaska-robiac-zakupy-ogladali-pompe-glebinowa-pozniej-jeden-z-nich-mial-ja-ukrasc-6708411?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 08:12:27+00:00
 - user: None

<img alt="Podejrzani o kradzież pompy głębinowej zatrzymani na granicy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i3q362-policja-odzyskala-skradziona-pompe-6708718/alternates/LANDSCAPE_1280" />
    Policjanci, we współpracy ze Strażą Graniczną zatrzymali trzech obywateli Białorusi, którzy odpowiedzą za kradzież pompy głębinowej z jednego ze sklepów w Białej Podlaskiej (woj. lubelskie). Z ustaleń wynika, że jeden z mężczyzn wyniósł ją, wykorzystując moment nieuwagi sprzedawcy.

## Alpy cierpią z powodu zmian klimatu. "Narciarstwo to już sport, na który stać tylko zamożne rodziny"
 - [https://tvn24.pl/tvnmeteo/swiat/niemcy-alpy-cierpia-z-powodu-zmian-klimatu-narciarstwo-to-juz-sport-na-ktory-stac-tylko-zamozne-rodziny-6707425?source=rss](https://tvn24.pl/tvnmeteo/swiat/niemcy-alpy-cierpia-z-powodu-zmian-klimatu-narciarstwo-to-juz-sport-na-ktory-stac-tylko-zamozne-rodziny-6707425?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 07:37:43+00:00
 - user: None

<img alt="Alpy cierpią z powodu zmian klimatu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-l90hh9-niemieckie-alpy-6707638/alternates/LANDSCAPE_1280" />
    Najwyższe góry w Europie są szczególnie mocno narażone na konsekwencje zmian klimatu. Coraz bardziej ubywa tam śniegu, przez co stoki wymagają częstszego i większego naśnieżania. To oznacza, że wszelka turystyka i sporty zimowe stają się tam coraz droższe.

## Płonął silnik cysterny. Ciężarówka przewoziła olej napędowy
 - [https://tvn24.pl/tvnwarszawa/ulice/dawidy-pozar-komory-silnika-cysterny-przewozila-olej-napedowy-6707415?source=rss](https://tvn24.pl/tvnwarszawa/ulice/dawidy-pozar-komory-silnika-cysterny-przewozila-olej-napedowy-6707415?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 07:30:05+00:00
 - user: None

<img alt="Płonął silnik cysterny. Ciężarówka przewoziła olej napędowy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vzn0vg-pozar-cysterny-w-dawidach-6707633/alternates/LANDSCAPE_1280" />
    W miejscowości Dawidy w okolicy Piaseczna doszło do pożaru ciężarówki - cysterny, przewożącej olej napędowy. Ogień nie rozprzestrzenił się na przestrzeń ładunkową.

## Wakacje kredytowe na dłużej? Wiceminister o warunkach
 - [https://tvn24.pl/biznes/nieruchomosci/wakacje-kredytowe-rowniez-w-2024-roku-wiceminister-finansow-artur-sobon-wyjasnia-6705597?source=rss](https://tvn24.pl/biznes/nieruchomosci/wakacje-kredytowe-rowniez-w-2024-roku-wiceminister-finansow-artur-sobon-wyjasnia-6705597?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 07:12:41+00:00
 - user: None

<img alt="Wakacje kredytowe na dłużej? Wiceminister o warunkach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fdzr1m-ministerstwo-finansow-shutterstock1074556148s-5557353/alternates/LANDSCAPE_1280" />
    Ustawowe wakacje kredytowe mogą zostać przedłużone na 2024 rok. - Będziemy się nad tym zastanawiać w połowie roku - powiedział w poniedziałek w RMF FM wiceminister finansów Artur Soboń. Jak wskazywał, resort będzie patrzył na sytuację związaną z inflacją i decyzje dotyczące stóp procentowych.

## Wiceminister obrony: wojna w Ukrainie to jedna wielka zmiana mentalna
 - [https://tvn24.pl/polska/ukraina-wiceminister-obrony-marcin-ociepa-cala-ta-wojna-to-jedna-wielka-zmiana-mentalna-6705826?source=rss](https://tvn24.pl/polska/ukraina-wiceminister-obrony-marcin-ociepa-cala-ta-wojna-to-jedna-wielka-zmiana-mentalna-6705826?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 07:12:31+00:00
 - user: None

<img alt="Wiceminister obrony: wojna w Ukrainie to jedna wielka zmiana mentalna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b9cvwe-marcin-ociepa-6706569/alternates/LANDSCAPE_1280" />
    Przy okazji wojny w Ukrainie dokonuje się bezprecedensowy przełom, jeśli chodzi o modernizację polskich Sił Zbrojnych - mówił w "Rozmowie Piaseckiego" wiceminister obrony narodowej Marcin Ociepa. Zaznaczył, że "czerwoną linią" dostaw polskiego uzbrojenia na Ukrainę są "wyłącznie nasze możliwości". - Bezpieczeństwo Ukrainy to jest także bezpieczeństwo Polek i Polaków - powiedział.

## Na stację paliw podjeżdżał w ubraniu z firmy, w której wcześniej pracował. Nie płacił, ale brał faktury
 - [https://tvn24.pl/bialystok/augustow-policja-zatrzymala-34-latka-podejrzanego-o-kradzieze-paliwa-6706539?source=rss](https://tvn24.pl/bialystok/augustow-policja-zatrzymala-34-latka-podejrzanego-o-kradzieze-paliwa-6706539?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 07:06:55+00:00
 - user: None

<img alt="Na stację paliw podjeżdżał w ubraniu z firmy, w której wcześniej pracował. Nie płacił, ale brał faktury" src="https://tvn24.pl/najnowsze/cdn-zdjecie-naul10-34-latek-uslyszal-dziewiec-zarzutow-kradziezy-paliwa-6707127/alternates/LANDSCAPE_1280" />
    Do pięciu lat więzienia grozi 34-latkowi, którego zatrzymali policjanci z Augustowa (woj. podlaskie). Z ustaleń wynika, że mężczyzna zakładał ubranie robocze firmy, w której wcześniej pracował i jechał na stację paliw, gdzie tankował. Brał faktury, podpisując je nazwiskiem osoby uprawnionej do tankowania firmowych pojazdów.

## Duży zwrot z ZUS do budżetu. "Oddaliśmy pieniądze do dyspozycji ministrowi finansów"
 - [https://tvn24.pl/biznes/z-kraju/emerytury-prezes-zus-gertruda-uscinska-o-kondycji-funduszu-ubezpieczen-spolecznych-zus-zwrocil-miliardy-do-budzetu-6703642?source=rss](https://tvn24.pl/biznes/z-kraju/emerytury-prezes-zus-gertruda-uscinska-o-kondycji-funduszu-ubezpieczen-spolecznych-zus-zwrocil-miliardy-do-budzetu-6703642?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 06:14:55+00:00
 - user: None

<img alt="Duży zwrot z ZUS do budżetu. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie2723631e49f17af4ccb987f33fbcf906-zus-rozpoczal-wysylke-listow-5071331/alternates/LANDSCAPE_1280" />
    Ubiegły rok był jednym z najlepszych w historii Funduszu Ubezpieczeń Społecznych - oceniła prezes Zakładu Ubezpieczeń Społecznych profesor Gertruda Uścińska. Jak przekazała, pozwoliło to na oddanie prawie 5,5 miliarda złotych dotacji z budżetu państwa.

## 126 720 żarówek wyświetlało reklamy, jakich Polska jeszcze nie widziała
 - [https://tvn24.pl/poznan/poznan-collegium-altum-30-lat-temu-zamontowano-na-nim-gigantyczny-ekran-reklamowy-6685157?source=rss](https://tvn24.pl/poznan/poznan-collegium-altum-30-lat-temu-zamontowano-na-nim-gigantyczny-ekran-reklamowy-6685157?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 06:05:08+00:00
 - user: None

<img alt="126 720 żarówek wyświetlało reklamy, jakich Polska jeszcze nie widziała" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zkwkr8-w-1993-roku-na-gmachu-uniwersytety-ekonomicznego-zawisl-najwiekszy-wowczas-na-swiecie-ekran-1777507/alternates/LANDSCAPE_1280" />
    Gigantyczny ekran zamontowano tak, by to, co na nim się wyświetla mogli zobaczyć goście Międzynarodowych Targów Poznańskich. Pierwszą reklamę wyświetlono na nim 30 stycznia 1993 roku.

## "WSJ": Izrael stoi za atakiem na irańskie instalacje wojskowe
 - [https://tvn24.pl/swiat/iran-atak-dronow-wall-street-journal-izrael-stoi-za-atakiem-na-iranskie-instalacje-wojskowe-6703609?source=rss](https://tvn24.pl/swiat/iran-atak-dronow-wall-street-journal-izrael-stoi-za-atakiem-na-iranskie-instalacje-wojskowe-6703609?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 06:00:25+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-431x6r-atak-dronow-na-instalacje-wojskowe-w-isfahanie-6703612/alternates/LANDSCAPE_1280" />
    Za atak dronów na instalacje wojskowe w Isfahanie, trzecim co do wielkości mieście Iranu, jest odpowiedzialny Izrael - poinformował w niedzielę amerykański dziennik "The Wall Street Journal". Powołał się przy tym na źródła zastrzegające sobie anonimowość. Izraelskie wojsko odmawia komentarzy w sprawie incydentu.

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-inwazja-rosji-najwazniejsze-wydarzenia-ostatnich-godzin-30-stycznia-2023-roku-6699571?source=rss](https://tvn24.pl/swiat/ukraina-inwazja-rosji-najwazniejsze-wydarzenia-ostatnich-godzin-30-stycznia-2023-roku-6699571?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 04:06:13+00:00
 - user: None

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fxn3g6-ostrzelany-budynek-w-chersoniu-6686422/alternates/LANDSCAPE_1280" />
    Inwazja Rosji na Ukrainę trwa od 341 dni. Rosyjska rakieta uderzyła w budynek mieszkalny w Charkowie, zginęła jedna osoba. W obwodzie ługańskim rosyjska armia zmusza mieszkańców do opuszczenia domów. Oto najważniejsze wydarzenia ostatnich godzin.

## Pogoda na dziś - poniedziałek, 30.01. Opady śniegu przemierzą Polskę
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-3001-opady-sniegu-przemierza-polske-6686929?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-3001-opady-sniegu-przemierza-polske-6686929?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-30 01:00:00+00:00
 - user: None

<img alt="Pogoda na dziś - poniedziałek, 30.01. Opady śniegu przemierzą Polskę" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-zm9lbk-snieg-popada-snieg-6686957/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Poniedziałek 30.01 przyniesie przemieszczające się z północnego zachodu na południowy wschód opady mokrego śniegu. Termometry pokażą od 1 do 5 stopni Celsjusza. Biomet będzie niekorzystny.
