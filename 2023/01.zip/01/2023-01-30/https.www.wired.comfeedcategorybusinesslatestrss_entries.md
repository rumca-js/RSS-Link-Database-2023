# Source Wired business, Source URL:https://www.wired.com/feed/category/business/latest/rss, Source language: en-US

## Ex-Twitter Workers Puzzle Over Elon Musk’s Abandoned Laptops
 - [https://www.wired.com/story/ex-twitter-workers-puzzle-over-elon-musks-abandoned-laptops/](https://www.wired.com/story/ex-twitter-workers-puzzle-over-elon-musks-abandoned-laptops/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-01-30 12:00:00+00:00
 - user: None

The cash-strapped company recently auctioned off USB dongles but has left some corporate computers in the custody of laid-off staff.
