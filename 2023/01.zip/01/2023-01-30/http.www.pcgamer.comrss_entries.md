# Source pcgamer, Source URL:http://www.pcgamer.com/rss, Source language: en-US

## Activision Blizzard exec says The Last of Us' success on HBO proves the Microsoft buyout should go through
 - [https://www.pcgamer.com/activision-blizzard-exec-says-the-last-of-us-success-on-hbo-proves-the-microsoft-buyout-should-go-through](https://www.pcgamer.com/activision-blizzard-exec-says-the-last-of-us-success-on-hbo-proves-the-microsoft-buyout-should-go-through)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 22:34:40+00:00
 - user: None

Lulu Cheng Meservey sent a message to the FTC after the most recent episode of The Last of Us on HBO.

## The Crew 3 is real and an announcement is coming tomorrow
 - [https://www.pcgamer.com/the-crew-3-is-real-and-an-announcement-is-coming-tomorrow](https://www.pcgamer.com/the-crew-3-is-real-and-an-announcement-is-coming-tomorrow)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 22:17:25+00:00
 - user: None

Ubisoft's tepidly received racing series averts the axe.

## CEO of OpenAI says misuse of artificial intelligence could be 'lights out for all'
 - [https://www.pcgamer.com/ceo-of-openai-says-misuse-of-artificial-intelligence-could-be-lights-out-for-all](https://www.pcgamer.com/ceo-of-openai-says-misuse-of-artificial-intelligence-could-be-lights-out-for-all)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 21:59:28+00:00
 - user: None

Even the maker of ChapGPT acknowledges the potential worst-case scenario for AI.

## State bar associations shout 'objection your honor!' to scare AI lawyer away from court
 - [https://www.pcgamer.com/state-bar-associations-shout-objection-your-honor-to-scare-ai-lawyer-away-from-court](https://www.pcgamer.com/state-bar-associations-shout-objection-your-honor-to-scare-ai-lawyer-away-from-court)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 21:59:00+00:00
 - user: None

Finally, a little victory for humanity (if you count lawyers).

## The Last of Us actor Annie Wersching has died
 - [https://www.pcgamer.com/the-last-of-us-actor-annie-wersching-has-died](https://www.pcgamer.com/the-last-of-us-actor-annie-wersching-has-died)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 21:21:28+00:00
 - user: None

Wersching, who also had prominent roles in Star Trek: Picard, The Rookie, and 24, voiced Tess in the original videogame.

## MMO player grinds god-awful minigame tokens for 8 years, breaks in-game XP tracker by blowing it all in 49 seconds
 - [https://www.pcgamer.com/mmo-player-grinds-god-awful-minigame-tokens-for-8-years-breaks-in-game-xp-tracker-by-blowing-it-all-in-49-seconds](https://www.pcgamer.com/mmo-player-grinds-god-awful-minigame-tokens-for-8-years-breaks-in-game-xp-tracker-by-blowing-it-all-in-49-seconds)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 20:02:32+00:00
 - user: None

The bit? Committed to.

## Call of Duty: Warzone 2 seems to be headed to Japan
 - [https://www.pcgamer.com/call-of-duty-warzone-2-seems-to-be-headed-to-japan](https://www.pcgamer.com/call-of-duty-warzone-2-seems-to-be-headed-to-japan)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 19:18:06+00:00
 - user: None

Activision is teasing Warzone's next map with a satisfying sand render.

## Life is Strange studio packs gaming nostalgia into a 'little glimpse' of its next game
 - [https://www.pcgamer.com/life-is-strange-studio-packs-gaming-nostalgia-into-a-little-glimpse-of-its-next-game](https://www.pcgamer.com/life-is-strange-studio-packs-gaming-nostalgia-into-a-little-glimpse-of-its-next-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 19:17:17+00:00
 - user: None

An image shared today by Don't Nod Montreal has a very distinct 1990s vibe.

## Belarusian KGB adds World of Tanks studio boss to terrorist list
 - [https://www.pcgamer.com/belarusian-kgb-adds-world-of-tanks-studio-boss-to-terrorist-list](https://www.pcgamer.com/belarusian-kgb-adds-world-of-tanks-studio-boss-to-terrorist-list)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 16:48:12+00:00
 - user: None

Likely in retaliation for Wargaming leaving the country after Belarus supported Russia's invasion of Ukraine.

## Forspoken review
 - [https://www.pcgamer.com/forspoken-review](https://www.pcgamer.com/forspoken-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 16:47:41+00:00
 - user: None

Forspoken could have been excellent if it tried a little harder.

## Loupedeck Live S
 - [https://www.pcgamer.com/loupedeck-live-s-review](https://www.pcgamer.com/loupedeck-live-s-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 16:25:33+00:00
 - user: None

A multifaceted desktop whatchamacallit.

## A major Street Fighter tournament is ditching PlayStations in favour of PC
 - [https://www.pcgamer.com/a-major-street-fighter-tournament-is-ditching-playstations-in-favour-of-pc](https://www.pcgamer.com/a-major-street-fighter-tournament-is-ditching-playstations-in-favour-of-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 16:04:18+00:00
 - user: None

Consoles have traditionally been the platform of choice for offline events, but Capcom Cup is changing that.

## How to get inside the Kloros Guild in Forspoken
 - [https://www.pcgamer.com/forspoken-kloros-guild-tower](https://www.pcgamer.com/forspoken-kloros-guild-tower)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 15:59:53+00:00
 - user: None

Defeat the Nightmare to claim your reward.

## Krafton belatedly realises making every game PUBG-related may not be a great strategy
 - [https://www.pcgamer.com/krafton-belatedly-realises-making-every-game-pubg-related-may-not-be-a-great-strategy](https://www.pcgamer.com/krafton-belatedly-realises-making-every-game-pubg-related-may-not-be-a-great-strategy)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 15:20:15+00:00
 - user: None

The game's fun, but the extended universe never felt like a goer.

## Microsoft says Sony isn't telling the truth to EU regulators about Call of Duty
 - [https://www.pcgamer.com/microsoft-says-sony-isnt-telling-the-truth-to-eu-regulators-about-call-of-duty](https://www.pcgamer.com/microsoft-says-sony-isnt-telling-the-truth-to-eu-regulators-about-call-of-duty)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 15:00:04+00:00
 - user: None

Go off, (Activision-Blizzard) King.

## Where to find the Dead Space Peng statue
 - [https://www.pcgamer.com/dead-space-peng-location](https://www.pcgamer.com/dead-space-peng-location)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 14:34:49+00:00
 - user: None

Locate and loot this prize collectible.

## Tiny spots on AMD's RDNA 3 GPU hint at massive cache potential
 - [https://www.pcgamer.com/tiny-spots-on-amds-rdna-3-gpu-hint-at-massive-cache-potential](https://www.pcgamer.com/tiny-spots-on-amds-rdna-3-gpu-hint-at-massive-cache-potential)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 14:16:09+00:00
 - user: None

A sign of things to come or a feature left on the cutting room floor in production?

## How to complete the Innovating the Engine quest in WoW: Dragonflight
 - [https://www.pcgamer.com/world-of-warcraft-wow-innovating-the-engine](https://www.pcgamer.com/world-of-warcraft-wow-innovating-the-engine)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 13:20:23+00:00
 - user: None

How to finish the final step of the In Tyr's Footsteps quest chain.

## Warzone 2's wiping DMZ progress and players don't quite know how to feel about it
 - [https://www.pcgamer.com/warzone-2s-wiping-dmz-progress-and-players-dont-quite-know-how-to-feel-about-it](https://www.pcgamer.com/warzone-2s-wiping-dmz-progress-and-players-dont-quite-know-how-to-feel-about-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 13:05:12+00:00
 - user: None

Call of Duty: Modern Savefile

## This Lego Intel Arc A750 GPU has a working fan made of meat cleavers
 - [https://www.pcgamer.com/this-lego-intel-arc-a750-gpu-has-a-working-fan-made-out-of-meat-cleavers](https://www.pcgamer.com/this-lego-intel-arc-a750-gpu-has-a-working-fan-made-out-of-meat-cleavers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 12:34:10+00:00
 - user: None

It's not likely to end up an official Lego Intel Arc set, but a parts list is coming for anyone interested.

## Assassin's Creed artist smuggles complaint into comic asking if 'someone can explain how to write this shit'
 - [https://www.pcgamer.com/assassins-creed-artist-smuggles-complaint-into-comic-asking-if-someone-can-explain-how-to-write-this-shit](https://www.pcgamer.com/assassins-creed-artist-smuggles-complaint-into-comic-asking-if-someone-can-explain-how-to-write-this-shit)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 12:24:57+00:00
 - user: None

First Civ, second language, last nerve.

## F1 champ Max Verstappen's private jet has a sim racing rig in it
 - [https://www.pcgamer.com/f1-champ-max-verstappens-private-jet-has-a-sim-racing-rig-in-it](https://www.pcgamer.com/f1-champ-max-verstappens-private-jet-has-a-sim-racing-rig-in-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 11:55:36+00:00
 - user: None

Practice makes perfect, even at 30,000ft.

## Asus TUF Gaming B650 Plus WiFi
 - [https://www.pcgamer.com/asus-tuf-gaming-b650-plus-wifi](https://www.pcgamer.com/asus-tuf-gaming-b650-plus-wifi)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 11:19:29+00:00
 - user: None

AM5 at a more worldly price point.

## Top tech tips to fool your boss into thinking you're working hard
 - [https://www.pcgamer.com/top-tech-tips-to-fool-your-boss-into-thinking-youre-working-hard](https://www.pcgamer.com/top-tech-tips-to-fool-your-boss-into-thinking-youre-working-hard)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 10:46:33+00:00
 - user: None

Whether you're working from home or the office, here's the totally official PC Gamer guide to slacking off without getting noticed.

## Wordle hint and answer today: Let's solve #590, January 30
 - [https://www.pcgamer.com/wordle-hint-answer-today-590-january-30](https://www.pcgamer.com/wordle-hint-answer-today-590-january-30)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 08:05:44+00:00
 - user: None

Today's Wordle: Help to solve Monday's puzzle.

## The cyberpunk future looks upsettingly meaty
 - [https://www.pcgamer.com/the-cyberpunk-future-looks-upsettingly-meaty](https://www.pcgamer.com/the-cyberpunk-future-looks-upsettingly-meaty)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 05:54:25+00:00
 - user: None

I saw it so now you have to, too.

## Looks like Amazon's making a Tomb Raider movie and series to go with its game
 - [https://www.pcgamer.com/looks-like-amazons-making-a-tomb-raider-movie-and-series-to-go-with-its-game](https://www.pcgamer.com/looks-like-amazons-making-a-tomb-raider-movie-and-series-to-go-with-its-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 04:57:09+00:00
 - user: None

Who'll be Lara this time?

## HyperX's January keycap was a cute winter kitty and I missed it
 - [https://www.pcgamer.com/hyperxs-january-keycap-was-a-cute-winter-kitty-and-i-missed-it](https://www.pcgamer.com/hyperxs-january-keycap-was-a-cute-winter-kitty-and-i-missed-it)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 04:37:59+00:00
 - user: None

But he's got that cute little hat and scarf.

## Fight through the Greek afterlife with blade and shot in this grimy, gilded FPS
 - [https://www.pcgamer.com/fight-through-the-greek-afterlife-with-blade-and-shot-in-this-grimy-gilded-fps](https://www.pcgamer.com/fight-through-the-greek-afterlife-with-blade-and-shot-in-this-grimy-gilded-fps)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 01:53:24+00:00
 - user: None

<article>
                                <div class="youtube-video"><div class="video-aspect-box"></div></div>
<p>"Slay hordes of creatures on the black sands of Purgatory and sell their gold-stained corpses to craven priests," <a href="https://store.steampowered.com/app/1016360/PERISH/" target="_blank">Perish</a>&apos;s description on Steam begins. "Kill magnificent bosses and use the proceeds to gain access to Elysium, a place of cosmic revelations." Say no more, I&apos;m in.</p><p>Every frame of this co-op FPS looks like it could be metal album art⁠—it&apos;s inspired by Greek mythology, but feels extremely fresh. Instead of white marble columns and clean Corinthian helms, everything&apos;s <em>greasier</em> in Perish, its gold color palette conferring a real sickly quality. It&apos;s raining blood in the second area of Perish&apos;s free demo, and my favorite shot of its Steam trailer shows an alien sky with multiple moons beyond a series of floating ruins. <em>This stuff&apos;s rad</em>.</p><p>I unlocked a gun pretty quick in the demo, but I just couldn&apos;t put down the starting hatchet weapon. Similar to Fatshark&apos;s offerings, developer Item42&apos;s really nailed the feeling of crunchy, effective melee weapons, and I&apos;m especially jazzed about the infinitely respawning grappling hook javelins and beam-launching <a href="https://en.wikipedia.org/wiki/Khopesh" target="_blank">khopesh</a> sword shown off in the trailers.</p><p>Perish has set maps with variable objectives, a setup similar to other co-op shooters. You can accumulate gold to unlock permanently available weapons and modifiers for your character, as well as earn randomized temporary bonuses as you complete the stages of a mission. One stage had me chasing down a slippery target before holding down an objective for time, while another required me to trade in my hatchet for a slow-swinging torch and burn down a temple.</p><p>The objectives are fun and distinct enough from one another, and I was having plenty of fun tackling Perish&apos;s demo solo. If you&apos;re luckier than me and have friends who <em>aren&apos;t</em> adults with jobs and no time for co-op indie shooters, all the better⁠—Perish seems like a real winner for two to four player co-op. Perish will release in full this Thursday, February 2, and until then you can check out its demo and wishlist the game on <a href="https://store.steampowered.com/app/1016360/PERISH/" target="_blank">Steam</a>.</p>
<div class="inlinegallery  inline-layout"><div class="inlinegallery-wrap" style="display: flex;"><div class="inlinegallery-item"><span class="slidecount">Image 1 of 5</span><figure class="van-image-figure "><div class="image-full-width-wrapper"><div class="image-widthsetter"><p class="vanilla-image-block" style="padding-top: 56.25%;"><img align="" alt="drawing a bow against a large horned demon in a sickly red and green hallway" class="" height="1080" id="2eF87Vbatu87xKFLPBrikQ" name="ss_4478ed4d5443ae82d018aae64648e540a6cf5dfd.1920x1080.jpg" src="https://cdn.mos.cms.futurecdn.net/2eF87Vbatu87xKFLPBrikQ.jpg" width="1920" /></p></div></div><figcaption class=""><span class="credit">(Image credit: Item42)</span></figcaption></figure></div><div class="inlinegallery-item"><span class="slidecount">Image 2 of 5</span><figure class="van-image-figure "><div class="image-full-width-wrapper"><div class="image-widthsetter"><p class="vanilla-image-block" style="padding-top: 55.05%;"><img align="" alt="aiming shotgun up at large armored monster in a well lit chamber" class="" height="1057" id="unCBogbHvihzUkoW3JDuNQ" name="ss_99ec4dccea73239049ef334ace1ec75d4329d209.1920x1080.jpg" src="https://cdn.mos.cms.futurecdn.net/unCBogbHvihzUkoW3JDuNQ.jpg" width="1920" /></p></div></div><figcaption class=""><span class="credit">(Image credit: Item42)</span></figcaption></figure></div><div class="inlinegallery-item"><span class="slidecount">Image 3 of 5</span><figure class="van-image-figure "><div class="image-full-width-wrapper"><div class="image-widthsetter"><p class="vanilla-image-block" style="padding-top: 56.25%;"><img align="" alt="aiming a javelin at a skeleton monster in darkened hallway" class="" height="1080" id="tqr8JFFwwcG67o8GTKEADQ" name="ss_3a6b5349ba54c33cd2d74cc4056fc0b7c1df700b.1920x1080.jpg" src="https://cdn.mos.cms.futurecdn.net/tqr8JFFwwcG67o8GTKEADQ.jpg" width="1920" /></p></div></div><figcaption class=""><span class="credit">(Image credit: Item42)</span></figcaption></figure></div><div class="inlinegallery-item"><span class="slidecount">Image 4 of 5</span><figure class="van-image-figure "><div class="image-full-width-wrapper"><div class="image-widthsetter"><p class="vanilla-image-block" style="padding-top: 56.25%;"><img align="" alt="aiming revolver at masked cultist amid rain of blood" class="" height="1080" id="jJL6Yk2C3KHJJVzQPPdevQ" name="ss_07273b8f202aebeb322028043f27434d80d187cd.1920x1080.jpg" src="https://cdn.mos.cms.futurecdn.net/jJL6Yk2C3KHJJVzQPPdevQ.jpg" width="1920" /></p></div></div><figcaption class=""><span class="credit">(Image credit: Item42)</span></figcaption></figure></div><div class="inlinegallery-item"><span class="slidecount">Image 5 of 5</span><figure class="van-image-figure "><div class="image-full-width-wrapper"><div class="image-widthsetter"><p class="vanilla-image-block" style="padding-top: 56.25%;"><img align="" alt="aiming a cannon at some manner of lava monster" class="" height="1080" id="pTgvWCU8qATbnEzSazuP7R" name="ss_b93aae9624091e17ac4bb77a82c0e760cfa40e3d.1920x1080.jpg" src="https://cdn.mos.cms.futurecdn.net/pTgvWCU8qATbnEzSazuP7R.jpg" width="1920" /></p></div></div><figcaption class=""><span class="credit">(Image credit: Item42)</span></figcaption></figure></div></div></div>
                                                            </article>

## Dead Island 2 will have cards instead of a skill tree
 - [https://www.pcgamer.com/dead-island-2-will-have-cards-instead-of-a-skill-tree](https://www.pcgamer.com/dead-island-2-will-have-cards-instead-of-a-skill-tree)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 00:38:53+00:00
 - user: None

Cards against humanity.

## A surreal first person adventure based on a cult animated series just dropped its first gameplay trailer
 - [https://www.pcgamer.com/a-surreal-first-person-adventure-based-on-a-cult-animated-series-just-dropped-its-first-gameplay-trailer](https://www.pcgamer.com/a-surreal-first-person-adventure-based-on-a-cult-animated-series-just-dropped-its-first-gameplay-trailer)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-30 00:02:34+00:00
 - user: None

ENA: Dream BBQ is an intriguing adaptation of the popular YouTube series.
