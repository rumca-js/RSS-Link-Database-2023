# Source Business insider, Source URL:https://businessinsider.com.pl/.feed, Source language: en-US

## Bundeswehra poszukuje rezerwistów do szkolenia ukraińskich żołnierzy
 - [https://businessinsider.com.pl/wiadomosci/szkolenia-ukrainskich-zolnierzy-bundeswehra-poszukuje-rezerwistow/c9wzmfk](https://businessinsider.com.pl/wiadomosci/szkolenia-ukrainskich-zolnierzy-bundeswehra-poszukuje-rezerwistow/c9wzmfk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 20:50:20+00:00
 - user: None

Bundeswehra poszukuje około 50 rezerwistów do pomocy w szkoleniu ukraińskich żołnierzy. Pierwsi żołnierze przyjechali do Niemiec w ubiegły czwartek, aby szkolić się na marderach.

## "Oni zwalniają, my zatrudniamy". Niemcy chcą skorzystać na zwolnieniach w Dolinie Krzemowej
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/zwolnienia-w-google-i-facebooku-niemcy-kusza-inzynierow-z-doliny-krzemowej/pdccn88](https://businessinsider.com.pl/twoje-pieniadze/praca/zwolnienia-w-google-i-facebooku-niemcy-kusza-inzynierow-z-doliny-krzemowej/pdccn88)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 20:08:19+00:00
 - user: None

W obliczu napiętego rynku pracy i niedoboru pracowników o kluczowych umiejętnościach w zakresie inżynierii oprogramowania niektóre niemieckie firmy postrzegają tysiące zwolnień w Dolinie Krzemowej jako okazję do rekrutacji najlepszych talentów — pisze Reuters.

## Czołgi dla Ukrainy. Brytyjski minister mówi, kiedy trafią na front
 - [https://businessinsider.com.pl/wiadomosci/czolgi-dla-ukrainy-brytyjski-minister-mowi-kiedy-trafia-na-front/6bvwt4g](https://businessinsider.com.pl/wiadomosci/czolgi-dla-ukrainy-brytyjski-minister-mowi-kiedy-trafia-na-front/6bvwt4g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 19:37:45+00:00
 - user: None

Przekazane Ukrainie czołgi Challenger 2 trafią na linię frontu przed latem — zapowiedział w poniedziałek Ben Wallace, minister obrony Wielkiej Brytanii.

## Średniowieczne zamki wystawione na sprzedaż. Niektóre tańsze niż mieszkanie
 - [https://businessinsider.com.pl/lifestyle/sredniowieczne-zamki-na-sprzedaz-niektore-tansze-niz-mieszkanie/qpgz9bt](https://businessinsider.com.pl/lifestyle/sredniowieczne-zamki-na-sprzedaz-niektore-tansze-niz-mieszkanie/qpgz9bt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 18:40:50+00:00
 - user: None

W Hiszpanii na sprzedaż zostały wystawione średniowieczne zamki. Niektóre z nich można kupić za cenę niższą od mieszkania w dużym mieście. Najczęściej do sprzedaży zmuszają prywatnych właścicieli koszty utrzymania posiadłości.

## Węgry mają pomysł na źródło gazu. Duża umowa z partnerem ze Wschodu
 - [https://businessinsider.com.pl/gospodarka/orban-ma-pomysl-na-nowe-zrodlo-gazu-wegry-z-duza-umowa-z-krajem-ze-wschodu/cq3lp04](https://businessinsider.com.pl/gospodarka/orban-ma-pomysl-na-nowe-zrodlo-gazu-wegry-z-duza-umowa-z-krajem-ze-wschodu/cq3lp04)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 18:30:04+00:00
 - user: None

— W chwili obecnej najbardziej realnym scenariuszem dywersyfikacji dla Europy jest transport energii z Azerbejdżanu — powiedział w poniedziałek w Budapeszcie premier Węgier Viktor Orban na wspólnej konferencji z prezydentem Azerbejdżanu Ilhamem Alijewem.

## Prezes PGE na debacie z wiceministrem: nie możemy sobie mydlić oczu, ceny energii w przyszłości będą wyższe
 - [https://businessinsider.com.pl/gospodarka/ile-zaplacimy-za-prad-prezes-pge-ceny-energii-w-przyszlosci-beda-wyzsze/81n94fy](https://businessinsider.com.pl/gospodarka/ile-zaplacimy-za-prad-prezes-pge-ceny-energii-w-przyszlosci-beda-wyzsze/81n94fy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 18:07:52+00:00
 - user: None

— Energetyka ma się opierać na źródłach nisko— i zeroemisyjnych i ma dawać bezpieczeństwo energetyczne, czyli m.in. prąd w akceptowalnych cenach — zapewniał podczas dyskusji z prezesami spółek energetycznych, wiceminister aktywów Karol Rabenda. Prezes PGE Wojciech Dąbrowski nie miał jednak wątpliwości. — Nie możemy sobie mydlić oczu, ceny energii w przyszłości będą wyższe — mówił. I argumentował dlaczego.

## Tak Gazprom ominął sankcje. Sam uruchomił zakład
 - [https://businessinsider.com.pl/gospodarka/kaliningrad-gazprom-ominal-sankcje-sam-uruchomil-zaklad/gmycz81](https://businessinsider.com.pl/gospodarka/kaliningrad-gazprom-ominal-sankcje-sam-uruchomil-zaklad/gmycz81)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 18:01:32+00:00
 - user: None

Po tym, jak niemiecki koncern wycofał się z projektu w wyniku sankcji, Gazprom sam uruchomił zakład produkcji LNG w tłoczni Portowaja. Jak zdołał to uczynić, skoro nie ma potrzebnej technologii? Gigant uważa, że ten ruch wzmocni bezpieczeństwo Obwodu Kaliningradzkiego.

## Orlen i Azoty zawyżają ceny nawozów? "Cena powinna być uczciwa, a dziś nie jest"
 - [https://businessinsider.com.pl/biznes/orlen-i-azoty-zawyzaja-ceny-nawozow-agrounia-cena-nie-jest-uczciwa/8t7n58r](https://businessinsider.com.pl/biznes/orlen-i-azoty-zawyzaja-ceny-nawozow-agrounia-cena-nie-jest-uczciwa/8t7n58r)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 17:41:08+00:00
 - user: None

Ostatnie tygodnie przyniosły spadki cen nawozów w Europie, sięgające nawet kilkudziesięciu procent. To efekt taniejącego gazu. — Kiedy gaz drożał w Europie, cena nawozów wzrastała z dnia na dzień. Kiedy gaz jest najtańszy od długiego czasu, cena nawozów pozostaje nadal wysoka. To jakiś absurd — tłumaczy Business Insiderowi prezes Agrounii Michał Kołodziejczak. Według ekspertów ceny w Polsce już w najbliższym czasie mogą spaść o 20-30 proc. Istotna będzie tu nie tylko presja rolników, ale też polityków. — Mamy rok wyborczy, a rolnicy to duża część elektoratu — przekonuje Jakub Szkopek z Erste Securities.

## Przepis pod Kaczyńskiego. Prezes skorzysta, inni niekoniecznie
 - [https://businessinsider.com.pl/prawo/firma/przepis-ktory-ratuje-kaczynskiego-uderzy-w-firmy/2xcfe3j](https://businessinsider.com.pl/prawo/firma/przepis-ktory-ratuje-kaczynskiego-uderzy-w-firmy/2xcfe3j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 17:31:48+00:00
 - user: None

Senat zajmie się nowelizację kodeksu postępowania cywilnego, która co do zasady naprawia reformę z 2019 r. Znalazł się w niej przepis, który umożliwi Jarosławowi Kaczyńskiemu uniknięcia zapłaty ponad 700 tys. zł. I o ile prezes Kaczyński skorzysta z nowego przepisu, to inni niekoniecznie. Pokrzywdzone mogą być m.in. firmy, bo szkalowanie dobrego imienia będzie opłacalne.

## Ta branża nie jest już nietykalna. Rynek gier z pierwszym spadkiem w historii
 - [https://businessinsider.com.pl/firmy/gaming-nie-jest-juz-nietykalny-rynek-gier-dopadl-pierwszy-kryzys-w-historii/lyy0w11](https://businessinsider.com.pl/firmy/gaming-nie-jest-juz-nietykalny-rynek-gier-dopadl-pierwszy-kryzys-w-historii/lyy0w11)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 17:31:13+00:00
 - user: None

Rynek gier przyzwyczaił analityków, inwestorów, a także samych graczy do tego, że nieustannie, z roku na rok robił się coraz większy. Okazuje się jednak, że spowolnienie gospodarcze dopadło również tę branżę. Jak szacują eksperci NewZoo, wiele wskazuje na to, że przychody w ubiegłym roku zauważalnie się skurczyły.

## Przełom w robotyce. Naukowcy stworzyli robota, który zmienia swój stan skupienia [WIDEO]
 - [https://businessinsider.com.pl/technologie/stworzyli-robota-ktory-zmienil-sie-w-ciecz-aby-uciec-z-klatki-wideo/qtk1ts4](https://businessinsider.com.pl/technologie/stworzyli-robota-ktory-zmienil-sie-w-ciecz-aby-uciec-z-klatki-wideo/qtk1ts4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 17:07:38+00:00
 - user: None

Według ustaleń opublikowanych w czasopiśmie naukowym Matter naukowcy twierdzą, że stworzyli robota zmieniającego kształt. Robot może "przełączać" swój stan skupienia między cieczą i ciałem stałym, przewodzi prąd i ma zdolności magnetyczne,

## Jajka z konopi i grochu. Kiedy ceny jaj szaleją, wykluwa się nowy biznes
 - [https://businessinsider.com.pl/biznes/ceny-jaj-szaleja-czym-mozna-je-zastapic-sprawdzamy/m1msejf](https://businessinsider.com.pl/biznes/ceny-jaj-szaleja-czym-mozna-je-zastapic-sprawdzamy/m1msejf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 16:44:01+00:00
 - user: None

Sproszkowane nasiona lnu, nasiona chia, mąka ziemniaczana albo z tapioki. Dojrzały banan, mus z jabłek lub dyni, woda z ciecierzycy— roślinnych zamienników jaj na rynku jest mnóstwo i wbrew pozorom nie są to egzotyczne produkty. O ile pieczenie i gotowanie bez wykorzystania kurzych jaj jest proste, o tyle smak i konsystencję prawdziwych jaj uzyskać jest trudniej. Na rynku powstają jednak pierwsze syntetyczne zamienniki jajek, a jeden z nich opracował start-up z Polski.

## Etykiety butelek na alkohol z ostrzeżeniem zdrowotnym? Producenci kwestionują
 - [https://businessinsider.com.pl/biznes/ostrzezenia-na-butelkach-alkoholu-na-producentow-padl-blady-strach/m472bcv](https://businessinsider.com.pl/biznes/ostrzezenia-na-butelkach-alkoholu-na-producentow-padl-blady-strach/m472bcv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 16:38:35+00:00
 - user: None

W Europie toczy się walka o plan Irlandii dotyczący umieszczania ostrzeżeń zdrowotnych na butelkach wina, piwa i napojów spirytusowych.

## Manipulacje w sklepach internetowych to norma. Oto najczęstsze triki sprzedawców
 - [https://businessinsider.com.pl/finanse/handel/oto-manipulacje-sklepow-w-internecie-ue-te-triki-w-e-commerce-sa-norma/r0wkgsc](https://businessinsider.com.pl/finanse/handel/oto-manipulacje-sklepow-w-internecie-ue-te-triki-w-e-commerce-sa-norma/r0wkgsc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 16:25:03+00:00
 - user: None

Komisja Europejska i krajowe organy ds. ochrony konsumentów z 23 państw członkowskich, Norwegii i Islandii opublikowały wyniki akcji kontrolnej stron internetowych związanych z handlem detalicznym. Wyniki nie napawają optymizmem. Kontrola objęła 399 sklepów internetowych. Manipulacyjne praktyki internetowe były masowe, a Komisja Europejska przedstawiła najpopularniejsze z nich.

## Mięso wieloryba z automatu. Japońska firma znalazła niszę
 - [https://businessinsider.com.pl/biznes/mieso-wieloryba-z-automatu-japonska-firma-znalazla-nisze/54n9vsz](https://businessinsider.com.pl/biznes/mieso-wieloryba-z-automatu-japonska-firma-znalazla-nisze/54n9vsz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 16:07:22+00:00
 - user: None

Japońska firma będzie sprzedawać w automatach mięso wieloryba za 8 dol. Firma zamierza ustawiać automaty w pobliżu supermarketów, w których mięso wieloryba nie jest już sprzedawane, często z powodu nacisków aktywistów sprzeciwiających się połowom.

## W Czechach generał zostaje prezydentem. Czemu więc w Polsce generałowie są komentatorami?
 - [https://businessinsider.com.pl/wiadomosci/w-czechach-general-zostaje-prezydentem-czemu-wiec-w-polsce-generalowie-sa/5weddc5](https://businessinsider.com.pl/wiadomosci/w-czechach-general-zostaje-prezydentem-czemu-wiec-w-polsce-generalowie-sa/5weddc5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:39:17+00:00
 - user: None

W Czechach gen. Petr Pavel właśnie wygrał wybory prezydenckie. Nie wszystkich to dziwi – w końcu w wielu krajach generałowie po zakończeniu służby robią fantastyczne kariery biznesowe czy polityczne. Tylko Polski ta zasada wydaje się nie dotyczyć. Może to się odbić nam sporą czkawką.

## Reuters: grupa aktywistów z Niemiec robi zbiórki dla Rosji
 - [https://businessinsider.com.pl/wiadomosci/reuters-grupa-aktywistow-z-niemiec-robi-zbiorki-dla-rosji/mvcmj79](https://businessinsider.com.pl/wiadomosci/reuters-grupa-aktywistow-z-niemiec-robi-zbiorki-dla-rosji/mvcmj79)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:22:30+00:00
 - user: None

Jak informuje Reuters, grupa prorosyjskich aktywistów z Niemiec przekazała 500 euro na zakup sprzętu łączności dla jednej z dywizji rosyjskiego wojska walczącej w Ukrainie. Liderzy tego środowiska to osoby, które wcześniej prowadziły kampanię domagającą się od niemieckiego rządu zaprzestania dostarczania broni Ukrainie.

## Badacze snu chcą płacić za podjadanie sera w nocy
 - [https://businessinsider.com.pl/wiadomosci/badanie-snu-1000-dolarow-za-podjadanie-sera-w-nocy/3nfzwf2](https://businessinsider.com.pl/wiadomosci/badanie-snu-1000-dolarow-za-podjadanie-sera-w-nocy/3nfzwf2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:22:13+00:00
 - user: None

Jeśli zarabianie na jedzeniu sera każdej nocy, niczym postać z "30 Rock" Liz Lemon, brzmi jak spełnienie marzeń, możesz być idealnym kandydatem do udziału w badaniach nad wpływem sera na sen.

## Philips zwolni na raty tysiące pracowników. Ma rozpisany harmonogram
 - [https://businessinsider.com.pl/gielda/wiadomosci/zwolnienia-w-it-philips-tnie-tysiace-etatow-na-swiecie/g6bdwrp](https://businessinsider.com.pl/gielda/wiadomosci/zwolnienia-w-it-philips-tnie-tysiace-etatow-na-swiecie/g6bdwrp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:15:28+00:00
 - user: None

Kolejny technologiczny gigant tnie etaty. Philips w sumie zmniejszy zatrudnienie o 13 proc. Ogłosił cięcie kolejnych 6 tys. miejsc pracy. Cały proces ma się zakończyć do 2025 r.

## Alert w elektrowni atomowej w Japonii. Wstrzymano pracę reaktora
 - [https://businessinsider.com.pl/wiadomosci/elektrownia-atomowa-w-japonii-po-alercie-wstrzymano-prace-reaktora/6xkckfh](https://businessinsider.com.pl/wiadomosci/elektrownia-atomowa-w-japonii-po-alercie-wstrzymano-prace-reaktora/6xkckfh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:06:42+00:00
 - user: None

Praca jednego z reaktorów elektrowni atomowej w Japonii została w poniedziałek automatycznie wstrzymana. Elektrownia znajduje się na wybrzeżu Morza Japońskiego, w mieście Takahama.

## Jeszcze więcej pieniędzy na armię. Wiemy, jaką sumą będzie dysponował specjalny fundusz [TYLKO U NAS]
 - [https://businessinsider.com.pl/wiadomosci/jeszcze-wiecej-pieniedzy-na-armie-znamy-dokladna-kwote-specjalnego-funduszu/7rrjyee](https://businessinsider.com.pl/wiadomosci/jeszcze-wiecej-pieniedzy-na-armie-znamy-dokladna-kwote-specjalnego-funduszu/7rrjyee)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 15:02:00+00:00
 - user: None

Fundusz Wsparcia Sił Zbrojny będzie w tym roku dysponował kwotą o prawie 10 mld zł wyższa, niż rząd zakładał jeszcze kilka tygodni temu. Z informacji, jakie Business Insider Polska uzyskał w resorcie obrony narodowej, wynika, że wielkość wpływów Funduszu w tym roku wyniesie nieco ponad 49 mld zł. To zaś oznacza, że cały budżet na armię, razem z pieniędzmi zarezerwowanymi w kasie państwa, sięgnie blisko 150 mld zł.

## Ceny węgla spadają, koniec eldorado dla kopalń. Mogą nie udźwignąć "wyborczych" podwyżek płac
 - [https://businessinsider.com.pl/gospodarka/ceny-wegla-spadaja-koniec-eldorado-dla-kopaln-moga-nie-udzwignac-wyborczych-podwyzek/m40e2s7](https://businessinsider.com.pl/gospodarka/ceny-wegla-spadaja-koniec-eldorado-dla-kopaln-moga-nie-udzwignac-wyborczych-podwyzek/m40e2s7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:46:33+00:00
 - user: None

Sytuacja powtarza się regularnie. Najpierw przychodzą wysokie ceny węgla na rynku, za nimi idą zyski kopalń, górnicy je zauważają i żądają podwyżek, grożą strajkiem, zarządy kopalń ulegają pod presją strajków, a potem nadchodzą niskie ceny i groźba upadłości. Wtedy rząd wyciąga pieniądze z podatków i dokłada, żeby ratować miejsca pracy. Właśnie nadchodzi przedostatni etap tego cyklu. Ekstremalnie wysokie ceny węgla z ubiegłego roku krok po kroku odchodzą w przeszłość, a górnicy ruszają do strajków, bo chcą więcej zarabiać. Tyle że ich pensje to już ponad połowa kosztów kopalń.

## Ceny węgla spadają, koniec eldorado dla kopalń. Mogą nie udźwignąć "wyborczych" podwyżek płac
 - [https://businessinsider.com.pl/gospodarka/ceny-wegla-spadaja-koniec-eldorado-dla-kopaln-nie-udzwigna-podwyzek/m40e2s7](https://businessinsider.com.pl/gospodarka/ceny-wegla-spadaja-koniec-eldorado-dla-kopaln-nie-udzwigna-podwyzek/m40e2s7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:46:33+00:00
 - user: None

Sytuacja powtarza się regularnie. Najpierw przychodzą wysokie ceny węgla na rynku, za nimi idą zyski kopalń, górnicy je zauważają i żądają podwyżek, grożą strajkiem, zarządy kopalń ulegają pod presją strajków, a potem nadchodzą niskie ceny i groźba upadłości. Wtedy rząd wyciąga pieniądze z podatków i dokłada, żeby ratować miejsca pracy. Właśnie nadchodzi przedostatni etap tego cyklu. Ekstremalnie wysokie ceny węgla z ubiegłego roku krok po kroku odchodzą w przeszłość, a górnicy ruszają do strajków, bo chcą więcej zarabiać. Tyle że ich pensje to już ponad połowa kosztów kopalń.

## Użytkownicy Netflixa też muszą opłacić abonament RTV, choć nie oglądają telewizji? Wyjaśniamy
 - [https://businessinsider.com.pl/wiadomosci/uzytkownicy-netflixa-musza-oplacic-abonament-rtv-prawnicy-maja-watpliwosci/nzwe2b3](https://businessinsider.com.pl/wiadomosci/uzytkownicy-netflixa-musza-oplacic-abonament-rtv-prawnicy-maja-watpliwosci/nzwe2b3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:45:57+00:00
 - user: None

Mogłoby się wydawać, że zgodnie z obowiązującą ustawą osoby, które mają telewizory, ale nie oglądają na nich TVP, lecz korzystają z platform typu Netflix, również powinny opłacać abonament RTV. Prawnicy mają jednak wątpliwości co do takiej interpretacji.

## Koniec małego ZUS plus? Nic podobnego, ale trzeba się spieszyć
 - [https://businessinsider.com.pl/prawo/podatki/maly-zus-plus-31-stycznia-mija-termin-trzeba-sie-pospieszyc/245hqys](https://businessinsider.com.pl/prawo/podatki/maly-zus-plus-31-stycznia-mija-termin-trzeba-sie-pospieszyc/245hqys)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:25:43+00:00
 - user: None

Kto nie korzystał z małego ZUS plus, nadal może to zrobić. Pogłoski o końcu preferencji są więc przesadzone. Na wybór tej preferencji jest czas do 31 stycznia. Kto przez ostatnie lata korzystał z małego ZUS plus, musi jednak zacząć płacić składki w pełnej wysokości. Jest to szczególnie bolesne, bo ich wysokość w 2023 r. znacznie wzrosła. Te osoby będą mogły jednak powrócić do niższych składek.

## Koniec małego ZUS plus? Nic podobnego, ale trzeba się spieszyć
 - [https://businessinsider.com.pl/prawo/podatki/koniec-malego-zus-plus-nic-podobnego-ale-trzeba-sie-spieszyc/245hqys](https://businessinsider.com.pl/prawo/podatki/koniec-malego-zus-plus-nic-podobnego-ale-trzeba-sie-spieszyc/245hqys)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:25:43+00:00
 - user: None

Kto nie korzystał z małego ZUS plus, nadal może to zrobić. Pogłoski o końcu preferencji są więc przesadzone. Na wybór tej preferencji jest czas do 31 stycznia. Kto przez ostatnie lata korzystał z małego ZUS plus, musi jednak zacząć płacić składki w pełnej wysokości. Jest to szczególnie bolesne, bo ich wysokość w 2023 r. znacznie wzrosła. Te osoby będą mogły jednak powrócić do niższych składek.

## Inflacja uderzyła Niemców po kieszeniach. Gospodarka niespodziewanie się cofnęła
 - [https://businessinsider.com.pl/gospodarka/pkb-niemiec-zaskakuje-najwieksza-gospodarka-ue-na-minusie/mlfzldl](https://businessinsider.com.pl/gospodarka/pkb-niemiec-zaskakuje-najwieksza-gospodarka-ue-na-minusie/mlfzldl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:16:01+00:00
 - user: None

Ryzyko recesji w Niemczech wzrasta po niespodziewanym spadku PKB kwartał do kwartału. Ekonomiści liczyli, że uda się tego uniknąć. Plany pokrzyżowała m.in. inflacja i jej większy wpływ na wydatki naszych zachodnich sąsiadów.

## Inflacja uderzyła Niemców po kieszeniach. Gospodarka niespodziewanie się cofnęła
 - [https://businessinsider.com.pl/gospodarka/inflacja-uderzyla-niemcow-po-kieszeniach-gospodarka-sie-cofnela/mlfzldl](https://businessinsider.com.pl/gospodarka/inflacja-uderzyla-niemcow-po-kieszeniach-gospodarka-sie-cofnela/mlfzldl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:16:01+00:00
 - user: None

Ryzyko recesji w Niemczech wzrasta po niespodziewanym spadku PKB kwartał do kwartału. Ekonomiści liczyli, że uda się tego uniknąć. Plany pokrzyżowała m.in. inflacja i jej większy wpływ na wydatki naszych zachodnich sąsiadów.

## Ile zebrał WOŚP? Jurek Owsiak podsumowuje tegoroczny finał
 - [https://businessinsider.com.pl/wiadomosci/ile-zebrala-wielka-orkiestra-swiatecznej-pomocy-jurek-owsiak-podsumowuje/50p5esl](https://businessinsider.com.pl/wiadomosci/ile-zebrala-wielka-orkiestra-swiatecznej-pomocy-jurek-owsiak-podsumowuje/50p5esl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 14:09:10+00:00
 - user: None

Wielka Orkiestra Świątecznej Pomocy zebrała już 154 mln 606 tys. zł. A kwota ta ciągle wzrasta i jest coraz bliżej ubiegłorocznego rekordu. Tegoroczny finał WOŚP przebiega pod hasłem "Chcemy wygrać z sepsą! Gramy dla wszystkich – małych i dużych!". Jurek Owsiak podsumował tegoroczny finał.

## To one nakręcają inflację. Nowe dane dają nadzieję na wyhamowanie podwyżek cen
 - [https://businessinsider.com.pl/gospodarka/oczekiwania-inflacyjne-w-dol-daja-nadzieje-na-wyhamowanie-podwyzek-cen/zspvtfp](https://businessinsider.com.pl/gospodarka/oczekiwania-inflacyjne-w-dol-daja-nadzieje-na-wyhamowanie-podwyzek-cen/zspvtfp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 13:32:04+00:00
 - user: None

Przez długi czas inflacja była napędzana m.in. rosnącymi oczekiwaniami podwyżek cen. Badanie Komisji Europejskiej wskazuje, że pod koniec 2022 r. wskaźnik oczekiwań inflacyjnych konsumentów się cofnął. Niestety nie widać poprawy nastrojów w polskiej gospodarce.

## Duże zmiany w kodeksie pracy. Prezydent podpisał ustawę
 - [https://businessinsider.com.pl/gospodarka/kodeks-pracy-zmienia-prace-zdalna-prezydent-podpisal-ustawe/5rtr8rz](https://businessinsider.com.pl/gospodarka/kodeks-pracy-zmienia-prace-zdalna-prezydent-podpisal-ustawe/5rtr8rz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 13:16:08+00:00
 - user: None

Prezydent Andrzej Duda podpisał nowelizację Kodeksu pracy. Zmiany są spore. Zmiana prawa reguluje m.in. pracę zdalną. Ponadto pracodawcy będą mogli kontrolować trzeźwość pracowników.

## Unia wydała rekomendacje w sprawie dochodu minimalnego. "Ma służyć wspieraniu równości"
 - [https://businessinsider.com.pl/wiadomosci/dochod-minimalny-dla-mieszkancow-ue-tak-unia-europejska-walczy-z-ubostwem/4f7sqnp](https://businessinsider.com.pl/wiadomosci/dochod-minimalny-dla-mieszkancow-ue-tak-unia-europejska-walczy-z-ubostwem/4f7sqnp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:58:46+00:00
 - user: None

Unia Europejska przyjęła zalecenie w sprawie odpowiedniego dochodu minimalnego w państwach członkowskich. Zakłada zwalczaniu ubóstwa i wykluczenia społecznego oraz dążenie do wysokiego poziomu zatrudnienia poprzez propagowanie dochodu minimalnego.

## Ranking hulajnóg elektrycznych dwa miesiące przed rozpoczęciem sezonu
 - [https://businessinsider.com.pl/technologie/ranking-hulajnog-elektrycznych-dwa-miesiace-przed-rozpoczeciem-sezonu/9l1q3hm](https://businessinsider.com.pl/technologie/ranking-hulajnog-elektrycznych-dwa-miesiace-przed-rozpoczeciem-sezonu/9l1q3hm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:34:00+00:00
 - user: None

Do wiosny pozostały jeszcze dwa miesiące, ale jeśli na zewnątrz jest sucho i nie pada, nic nie stoi na przeszkodzie, aby poruszać się hulajnogą już teraz. Wystarczy się tylko ciepło ubrać. Przedstawiam najnowszy ranking hulajnóg elektrycznych według danych ze Skąpiec.pl.

## Lokaty już nie takie korzystne. Banki pogarszają oferty
 - [https://businessinsider.com.pl/twoje-pieniadze/koniec-wyscigu-na-lokaty-banki-wycofuja-najlepsze-oferty/qchg0wv](https://businessinsider.com.pl/twoje-pieniadze/koniec-wyscigu-na-lokaty-banki-wycofuja-najlepsze-oferty/qchg0wv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:29:55+00:00
 - user: None

Końcówka ubiegłego roku w bankach stała pod znakiem wyścigu na promocyjne oferty depozytów. Ten czas już się jednak kończy. Początek roku nie rozpieszcza oszczędzających. Najczęściej w dół poszło oprocentowanie lub co najmniej maksymalna kwota, którą można zainwestować na preferencyjnych warunkach — zauważa HRE Investments.

## Wojna o Tajwan między USA a Chinami? Ważny amerykański polityk nie ma dobrych wiadomości
 - [https://businessinsider.com.pl/wiadomosci/usa-i-chiny-stocza-boj-o-tajwan-amerykanski-polityk-nie-ma-zludzen/ky540xy](https://businessinsider.com.pl/wiadomosci/usa-i-chiny-stocza-boj-o-tajwan-amerykanski-polityk-nie-ma-zludzen/ky540xy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:28:26+00:00
 - user: None

Prawdopodobieństwo konfliktu USA z Chinami o Tajwan jest "bardzo wysokie" — oświadczył przewodniczący komisji spraw zagranicznych Izby Reprezentantów Michael McCaul. Polityk skomentował w ten sposób słowa Mike'a Minihana, generała amerykańskich sił powietrznych, który wskazał nawet potencjalną datę rozpoczęcia konfliktu.

## Szykują magazynową ofensywę. Nie tylko w Polsce
 - [https://businessinsider.com.pl/gielda/wiadomosci/mlp-group-zbuduje-magazyny-nie-tylko-w-polsce-celuje-w-niemcy/qmq6t3m](https://businessinsider.com.pl/gielda/wiadomosci/mlp-group-zbuduje-magazyny-nie-tylko-w-polsce-celuje-w-niemcy/qmq6t3m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:27:42+00:00
 - user: None

MLP Group chce w tym roku rozpocząć realizację inwestycji w Austrii, Rumunii, Polsce i Niemczech na łącznie nawet 350 tys. m kw. powierzchni magazynowej, poinformował prezes Radosław T. Krochta. Największe przyspieszenie spółka zanotuje u naszych zachodnich sąsiadów.

## Żegnamy pracę zdalną. Liczba wynajętych biur jak przed pandemią
 - [https://businessinsider.com.pl/prawo/praca/koniec-pracy-zdalnej-liczba-wynajetych-biur-w-warszawie-w-2022-r/x6w91z1](https://businessinsider.com.pl/prawo/praca/koniec-pracy-zdalnej-liczba-wynajetych-biur-w-warszawie-w-2022-r/x6w91z1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:27:09+00:00
 - user: None

Polscy pracownicy powoli żegnają się z pracą zdalną. W W 2022 r. zapotrzebowanie na powierzchnię biurową w Warszawie wróciło do poziomu notowanego przed pandemią.

## Agencja Fitch: NABE? Ogólnie na plus, ale są też wady
 - [https://businessinsider.com.pl/gospodarka/agencja-fitch-nabe-ogolnie-na-tak-ale-sa-minusy/08lj660](https://businessinsider.com.pl/gospodarka/agencja-fitch-nabe-ogolnie-na-tak-ale-sa-minusy/08lj660)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 12:07:50+00:00
 - user: None

Przedstawiciele renomowanej agencji Fitch oceniają, że powstanie NABE pozytywnie wpłynie na polskie spółki energetyczne. Podkreślają jednak, że wcale nie oznacza to, że taka operacja nie ma minusów. Oceniają, że spółki "stracą część EBITDA, będą mniejszymi podmiotami", co może utrudnić zadłużanie się.

## Rośnie zainteresowanie ugodami dotyczącymi kredytów. Duży bank odkrył karty
 - [https://businessinsider.com.pl/twoje-pieniadze/ugody-kredytobiorcow-frankowych-mbank-pokazal-statystyki/geznjhd](https://businessinsider.com.pl/twoje-pieniadze/ugody-kredytobiorcow-frankowych-mbank-pokazal-statystyki/geznjhd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 11:57:54+00:00
 - user: None

Średnio tysiąc ugód miesięcznie zawiera mBank ze swoimi klientami, którzy mają kredyty we frankach szwajcarskich. W efekcie porozumienia kredytobiorca pozbywa się ryzyka kursowego i może mieć pewność stałego oprocentowania przez pięć lat.

## Duże debiuty na polskim rynku. Te sieci mają otworzyć się w 2023 r.
 - [https://businessinsider.com.pl/wiadomosci/nowe-knajpy-i-niemiecki-dyskont-to-beda-najwieksze-debiuty-2023-r-w-polsce/cv4q0kc](https://businessinsider.com.pl/wiadomosci/nowe-knajpy-i-niemiecki-dyskont-to-beda-najwieksze-debiuty-2023-r-w-polsce/cv4q0kc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 11:48:08+00:00
 - user: None

Duże międzynarodowe marki, ciekawy debiutant znany z Czech i Ukrainy czy nowy format znanej już marki — to czeka nas w handlu i gastronomii w 2023 r.

## Niemcy nie chcą atomu? Społeczeństwo twierdzi inaczej
 - [https://businessinsider.com.pl/gospodarka/niemcy-nie-chca-atomu-spoleczenstwo-twierdzi-inaczej/vxrxsm0](https://businessinsider.com.pl/gospodarka/niemcy-nie-chca-atomu-spoleczenstwo-twierdzi-inaczej/vxrxsm0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 11:24:33+00:00
 - user: None

Niemcy wciąż utrzymują kurs stopniowego wygaszania swoich elektrowni atomowych, nawet jeśli przedłużają działanie części reaktorów. Tymczasem jak wynika z ankiety przeprowadzonej przez Fundację Konrada Adenauera, większość obywateli tego kraju nie chce, by ich kraj zrezygnował z energetyki jądrowej.

## Ich samolot jest wart ponad 100 mln dol., a sam hełm pilota 400 tys. dol. Byliśmy w odpowiedniku "Top gun" dla pilotów F-35B
 - [https://businessinsider.com.pl/wideo/tak-szkoleni-sa-piloci-do-latania-wielozadaniowym-mysliwcem-f35b/5w2yl5y](https://businessinsider.com.pl/wideo/tak-szkoleni-sa-piloci-do-latania-wielozadaniowym-mysliwcem-f35b/5w2yl5y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:59:00+00:00
 - user: None

Maszyna F-35B potrafi wystartować na kilkudziesięciu metrach i lądować pionowo, ma też najbardziej zaawansowany zestaw czujników spośród wszystkich myśliwców w historii. Tak wygląda szkolenie żołnierzy, którzy mają nią latać.

## Smartfony z niezwykle szybkim ładowaniem baterii
 - [https://businessinsider.com.pl/technologie/smartfony-z-niezwykle-szybkim-ladowaniem-baterii/kfkk8h9](https://businessinsider.com.pl/technologie/smartfony-z-niezwykle-szybkim-ladowaniem-baterii/kfkk8h9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:57:00+00:00
 - user: None

Nie ma nic bardziej irytującego niż smartfon, który rozładowuje się w najmniej odpowiednim momencie. Rozwiązaniem tego problemu jest po pierwsze wydajna bateria, a po drugie technologia szybkiego ładowania. Przedstawiam kilka smartfonów, które mogą pochwalić się ekstremalnie szybkim uzupełnianiem energii, a przy tym mają sporą baterię.

## Kupiła Teslę, czuje się oszukana. Przegapiła szansę na zniżkę
 - [https://businessinsider.com.pl/technologie/motoryzacja/kupila-tesle-czuje-sie-oszukana-przegapila-szanse-na-znizke/jpp8fvp](https://businessinsider.com.pl/technologie/motoryzacja/kupila-tesle-czuje-sie-oszukana-przegapila-szanse-na-znizke/jpp8fvp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:44:13+00:00
 - user: None

Niektórych nabywcy Tesli ominęły duże obniżki cen, dzięki którym mogliby zaoszczędzić tysiące dolarów. W efekcie ostro uderzyli w producenta samochodów elektrycznych, należącego do Elona Muska.

## Trzy, a częściowo nawet cztery pasy. Bliżej do rozbudowy A2
 - [https://businessinsider.com.pl/technologie/motoryzacja/polska-autostrada-spuchnie-miejscami-az-cztery-pasy-w-jedna-strone/0dgj2zk](https://businessinsider.com.pl/technologie/motoryzacja/polska-autostrada-spuchnie-miejscami-az-cztery-pasy-w-jedna-strone/0dgj2zk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:42:59+00:00
 - user: None

Generalna Dyrekcja Dróg Krajowych i Autostrad (GDDKiA) ogłosiła przetarg na wykonanie projektu budowalnego rozbudowy autostrady A2 do trzech i czterech pasów ruchu na odcinku między Łodzią a Warszawą.

## Mocny spadek w ludności Polski. Przyrost naturalny ciągle ujemny
 - [https://businessinsider.com.pl/gospodarka/jest-nas-coraz-mniej-mocny-spadek-w-ludnosci-i-ujemny-przyrost-naturalny/r37624j](https://businessinsider.com.pl/gospodarka/jest-nas-coraz-mniej-mocny-spadek-w-ludnosci-i-ujemny-przyrost-naturalny/r37624j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:37:01+00:00
 - user: None

Na koniec 2022 r. liczba ludności Polski była niższa niż rok wcześniej. W ciągu roku odnotowano mniej niż w 2021 r. zarówno urodzeń, jak i zgonów. Przyrost naturalny, podobnie jak w poprzednich latach, był ujemny, a na świat przyszło najmniej dzieci od drugiej wojny światowej.

## Taniej, bo z Polski. Tak czeskie knajpy radzą sobie w kryzysie
 - [https://businessinsider.com.pl/wiadomosci/polski-trik-czechow-tak-czeskie-knajpy-radza-sobie-z-drozyzna/4840569](https://businessinsider.com.pl/wiadomosci/polski-trik-czechow-tak-czeskie-knajpy-radza-sobie-z-drozyzna/4840569)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:15:01+00:00
 - user: None

Drożyzna męczy nie tylko Polaków, ale i Czechów. Są jednak w tym kraju lokale, które radzą sobie lepiej z rosnącymi kosztami. Portal seznamspravy.cz postanowił sprawdzić, w czym tkwi sekret. Okazuje się, że jest tu polski wątek.

## Mniej dociskamy firmy na wzrost wynagrodzeń. Zobacz, ilu pracodawców szykuje podwyżki
 - [https://businessinsider.com.pl/gospodarka/liczysz-na-podwyzke-tyle-firm-planuje-do-marca-podniesc-place/cvnvmqs](https://businessinsider.com.pl/gospodarka/liczysz-na-podwyzke-tyle-firm-planuje-do-marca-podniesc-place/cvnvmqs)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 10:04:37+00:00
 - user: None

Firmy prognozują spowolnienie wzrostu cen oferowanych produktów. Jednocześnie wskazują na spadek presji płacowej. Mimo to udział firm prognozujących podniesienie wynagrodzeń w kolejnym kwartale lekko wzrósł. Podwyżki do marca planuje prawie połowa ankietowanych przedsiębiorstw.

## Zastrzyk z budżetu dla PKP ma pomóc obniżyć ceny biletów. Jest data
 - [https://businessinsider.com.pl/wiadomosci/zazadalem-powrotu-poprzednich-cen-morawiecki-zdradzil-termin-nowych-stawek-w-pkp/s09w21k](https://businessinsider.com.pl/wiadomosci/zazadalem-powrotu-poprzednich-cen-morawiecki-zdradzil-termin-nowych-stawek-w-pkp/s09w21k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 09:41:43+00:00
 - user: None

Premier Mateusz Morawiecki zdradził, że to m.in. dodatkowe środki z budżetu państwa dla PKP mają pomóc obniżyć ceny biletów. Podkreślił, że można na to liczyć w ciągu dwóch tygodni.

## "Rz": rekordowe odejścia z wojska. Szybka reakcja MON na artykuł
 - [https://businessinsider.com.pl/wiadomosci/tylu-odejsc-z-wojska-za-pis-u-nie-bylo-szybka-reakcja-mon-na-artykul/bcjx3h1](https://businessinsider.com.pl/wiadomosci/tylu-odejsc-z-wojska-za-pis-u-nie-bylo-szybka-reakcja-mon-na-artykul/bcjx3h1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 09:08:37+00:00
 - user: None

Kilkanaście tysięcy żołnierzy zawodowych i ochotników WOT zrezygnowała w ub. roku z noszenia mundurów. Kolejne ponad 4 tys. żołnierzy miało zrezygnować także w tym roku — donosi "Rzeczpospolita". Ministerstwo Obrony Narodowej w reakcji na te doniesienia informuje o rekordach powołań.

## Polska gospodarka jedzie na hamulcu, ale uniknęliśmy najgorszego
 - [https://businessinsider.com.pl/gospodarka/pkb-polski-w-2022-r-najnowsze-dane-gus/d2jzpcm](https://businessinsider.com.pl/gospodarka/pkb-polski-w-2022-r-najnowsze-dane-gus/d2jzpcm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 09:02:09+00:00
 - user: None

W całym 2022 r. gospodarka urosła o blisko 5 proc. — wynika z najnowszych danych GUS. Według szacunków ekonomistów w samym czwartym kwartale wzrost PKB Polski był na poziomie około 2 proc. Wbrew nie tak dawnym obawom, udało się naszej gospodarce uniknąć recesji, ale spowolnienie jest wyraźne.

## W połowie roku decyzja ws. przedłużenia wakacji kredytowych
 - [https://businessinsider.com.pl/finanse/w-polowie-roku-decyzja-ws-przedluzenia-wakacji-kredytowych/9ym4dh2](https://businessinsider.com.pl/finanse/w-polowie-roku-decyzja-ws-przedluzenia-wakacji-kredytowych/9ym4dh2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:52:15+00:00
 - user: None

Ministerstwo Finansów będzie zastanawiać się w połowie roku nad potrzebą przedłużenia wakacji kredytowych na 2024 r. Wszystko zależy od poziomu inflacji — poinformował wiceminister finansów Artur Soboń. Stwierdził, że gdyby inflacja w lipcu-sierpniu wynosiła 12-13 proc. r/r, "z całą pewnością jakieś decyzje wówczas trzeba będzie podjąć".

## Korea ma samolot, którego już obawiają się Chiny. Niestety, to nie ten, który kupiła Polska
 - [https://businessinsider.com.pl/biznes/korea-poludniowa-stworzyla-niewidzialny-mysliwiec-kf-21-polska-kupila-inny-fa-50/y3f1e3t](https://businessinsider.com.pl/biznes/korea-poludniowa-stworzyla-niewidzialny-mysliwiec-kf-21-polska-kupila-inny-fa-50/y3f1e3t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:45:00+00:00
 - user: None

KF-21 Boramae, co w języku koreańskim oznacza jastrząb, może konkurować z najnowszymi maszynami z Chin i Rosji. Polska, która podpisuje z Koreą miliardowe umowy na uzbrojenie zdecydowała się na kupno prostszego i tańszego FA-50, ale jak twierdzi MON jest zainteresowana także i tym projektem.

## Kurs franka 30 stycznia poniżej 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-30-stycznia-2023/fwjtrqp](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-30-stycznia-2023/fwjtrqp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:15:18+00:00
 - user: None

Frank szwajcarski poniżej 4,7. W poniedziałek rano 30 stycznia 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,6919.

## Kurs dolara 30 stycznia powyżej 4,3
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-30-stycznia-2023/hctzbmz](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-30-stycznia-2023/hctzbmz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:13:16+00:00
 - user: None

Kurs dolara powyżej 4,3. W poniedziałek rano 30 stycznia 2022 r. kurs USD/PLN wynosi 4,3259.

## Kurs euro 30 stycznia w okolicach 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-30-stycznia-2023/wz7zdws](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-30-stycznia-2023/wz7zdws)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:11:36+00:00
 - user: None

Kurs euro w okolicach 4,7. W poniedziałek rano 30 stycznia 2022 r. kurs EUR/PLN wynosił 4,7060 zł.

## Perspektywy gospodarki się nie poprawiają
 - [https://businessinsider.com.pl/gospodarka/wskaznik-wyprzedzajacy-koniunktury-biec-perspektywy-gospodarki-sie-nie-poprawiaja/0mhj8yq](https://businessinsider.com.pl/gospodarka/wskaznik-wyprzedzajacy-koniunktury-biec-perspektywy-gospodarki-sie-nie-poprawiaja/0mhj8yq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:03:43+00:00
 - user: None

Wskaźnik Wyprzedzający Koniunktury (WWK), informujący z wyprzedzeniem o przyszłych tendencjach w gospodarce w styczniu 2023 r. nie zmienił się w stosunku do wartości sprzed miesiąca.

## Wskaźnik wyprzedzający koniunkturę nie wróży dobrze na pierwsze miesiące 2023 r.
 - [https://businessinsider.com.pl/gospodarka/wskaznik-wyprzedzajacy-koniunktury-biec-co-z-perspektywami-gospodarki/0mhj8yq](https://businessinsider.com.pl/gospodarka/wskaznik-wyprzedzajacy-koniunktury-biec-co-z-perspektywami-gospodarki/0mhj8yq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:03:43+00:00
 - user: None

Zamówień w firmach sektora przetwórstwa przemysłowego nie przybywa. Ich napływ od krajowych i zagranicznych odbiorców jest na rekordowo niskim poziomie. Eksperci BIEC zauważają, że konsekwencją tego oraz wzrostu kosztów prowadzenia działalności gospodarczej jest pogorszenie ocen menadżerów na temat stanu finansów.

## Wpłaty na WOŚP można odliczyć od podatku
 - [https://businessinsider.com.pl/prawo/podatki/wosp-2023-jak-odliczyc-wplate-na-wosp-od-podatku/62n2m02](https://businessinsider.com.pl/prawo/podatki/wosp-2023-jak-odliczyc-wplate-na-wosp-od-podatku/62n2m02)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 08:02:11+00:00
 - user: None

Osoby, które przekazują pieniądze fundacjom pożytku publicznego, w tym Wielkiej Orkiestrze Świątecznej Pomocy, mogą je odliczyć od dochodu lub przychodu, o ile zostaną właściwie udokumentowane. Można też odliczyć wpłaty dla indywidualnych osób, ale pod warunkiem, że taka osoba ma specjalne konto w organizacji (darowizna jest wpłacana na konto fundacji lub stowarzyszenia). Wyjaśniamy, jak to zrobić.

## Lotte Wedel zmniejszył Ptasie Mleczko. Teraz się tłumaczy
 - [https://businessinsider.com.pl/twoje-pieniadze/zwrociliscie-uwage-co-sie-stalo-z-ptasim-mleczkiem-producent-sie-tlumaczy/eephmy0](https://businessinsider.com.pl/twoje-pieniadze/zwrociliscie-uwage-co-sie-stalo-z-ptasim-mleczkiem-producent-sie-tlumaczy/eephmy0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 07:26:15+00:00
 - user: None

Było 360 g, a jest 340 g — tak na początku 2023 r. zmniejszyła się gramatura popularnego Ptasiego Mleczka od Wedla. Wszystko przez droższe: cukier, mleko, masło czy opakowania.

## Prawda o wakacjach kredytowych. "Bogaci" skorzystali i nadpłacili
 - [https://businessinsider.com.pl/twoje-pieniadze/gigantyczne-nadplaty-bogaci-wykorzystali-wakacje-kredytowe/nh7c6kv](https://businessinsider.com.pl/twoje-pieniadze/gigantyczne-nadplaty-bogaci-wykorzystali-wakacje-kredytowe/nh7c6kv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 06:46:53+00:00
 - user: None

Choć wakacje kredytowe miały z założenia pomóc w czasie kryzysu osobom w najtrudniejszej sytuacji materialnej, to w praktyce stały się okazją dla wielu osób z oszczędnościami. Ochoczo nadpłacały one bowiem swoje bankowe zobowiązania.

## Wewnętrzne jądro Ziemi mogło się zatrzymać
 - [https://businessinsider.com.pl/wiadomosci/wewnetrzne-jadro-ziemi-moglo-sie-zatrzymac/k23d825](https://businessinsider.com.pl/wiadomosci/wewnetrzne-jadro-ziemi-moglo-sie-zatrzymac/k23d825)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 06:38:29+00:00
 - user: None

Wewnętrzne ziemskie jądro się zatrzymało, a być może nawet zaczyna obracać się w przeciwną stronę — twierdzi zespół naukowców z Pekinu na podstawie badań sejsmicznych.

## Rheinmetall chce produkować zestawy HIMARS w Niemczech
 - [https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-30012023/19e6646](https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-30012023/19e6646)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 06:01:41+00:00
 - user: None

Wykorzystywane przez armię Ukrainy zestawy HIMARS mogą być produkowane w Niemczech, Rheinmetall i Lockheed Martin mają finalizować rozmowy na ten temat za parę tygodni. Poprawiają się nasze oceny dotyczące sytuacji gospodarczej, chociaż martwimy się o to, co będzie na emeryturze. W Stanach inflacja ciągle spada, a na giełdzie do łask inwestorów wrócili producenci samochodów elektrycznych. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Trzeba podnieść wiek emerytalny. Inaczej bieda
 - [https://businessinsider.com.pl/twoje-pieniadze/emerytury/wiek-emerytalny-trzeba-podniesc-inaczej-czeka-nas-bieda/bkf0k7t](https://businessinsider.com.pl/twoje-pieniadze/emerytury/wiek-emerytalny-trzeba-podniesc-inaczej-czeka-nas-bieda/bkf0k7t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 06:00:14+00:00
 - user: None

Wiek emerytalny musi być równy dla obu płci i wyższy niż dziś – uważa większość ekonomistów. W przeciwnym wypadku czeka nas marny los — bieda — pisze w poniedziałek "Rzeczpospolita".

## Rudery, działki i okazje, czyli kolej sprzedaje nieruchomości. Czy da się na nich zarobić?
 - [https://businessinsider.com.pl/twoje-pieniadze/rudery-dzialki-i-okazje-oto-jakie-nieruchomosci-mozna-kupic-od-kolei/fmm2rqb](https://businessinsider.com.pl/twoje-pieniadze/rudery-dzialki-i-okazje-oto-jakie-nieruchomosci-mozna-kupic-od-kolei/fmm2rqb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:50:44+00:00
 - user: None

Niemal tysiąc ofert sprzedaży i prawie 3 tys. ofert wynajmu. Tak dziś wygląda oferta posiadacza jednego z największych zasobów nieruchomości w Polsce – spółki PKP S.A. Sprawdziliśmy, co i za ile można kupić od kolei. Zapytaliśmy też eksperta, czy na takim zakupie można zarobić.

## Darmowe laptopy dostaną też nauczyciele. Zapowiedź ministra
 - [https://businessinsider.com.pl/wiadomosci/darmowe-laptopy-dla-nauczyciele-przemyslaw-czarnek/l6yw4zq](https://businessinsider.com.pl/wiadomosci/darmowe-laptopy-dla-nauczyciele-przemyslaw-czarnek/l6yw4zq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:46:56+00:00
 - user: None

Po zakończeniu przetargu na laptopy dla uczniów będą też laptopy dla nauczycieli — poinformował w niedzielę minister edukacji i nauki Przemysław Czarnek. Dodał, że do nauczycieli trafi ponad 400 tys. sztuk sprzętu.

## Czkawka po Polskim Ładzie? Uważaj, żeby zamiast 5 tys. zł nie zapłacić nawet 20 tys. zł
 - [https://businessinsider.com.pl/prawo/podatki/polski-lad-daje-po-kieszeni-uwazaj-zeby-zamiast-5-tys-zl-nie-zaplacic-nawet-20-tys-zl/0kf2h0k](https://businessinsider.com.pl/prawo/podatki/polski-lad-daje-po-kieszeni-uwazaj-zeby-zamiast-5-tys-zl-nie-zaplacic-nawet-20-tys-zl/0kf2h0k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:39:41+00:00
 - user: None

Polski Ład najpierw przyniósł ogromne zamieszanie, potem jego korekta uspokoiła sytuację. Teraz reforma znów odbija się czkawką przedsiębiorcom. Wszystko przez przepisy o składce zdrowotnej, którą eksperci nazywają wręcz podatkiem zdrowotnym. To właśnie przez składkę zdrowotną dziś wielu podatników cierpi i musi dopłacić nawet tysiące złotych.

## Tyle TK wydaje na prezenty. To rekord
 - [https://businessinsider.com.pl/wiadomosci/tyle-tk-wydaje-na-prezenty-to-rekord/tw432lm](https://businessinsider.com.pl/wiadomosci/tyle-tk-wydaje-na-prezenty-to-rekord/tw432lm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:37:01+00:00
 - user: None

35,3 tys. zł – tyle w 2021 r. Trybunał Konstytucyjny wydał na prezenty. Kwota jest rekordowa, bo w poprzednich latach TK wydał mniej – 18,7 tys. zł w 2020 r. i 21,7 tys. w 2022 r. O sprawie informuje "Rzeczpospolita".

## Opel Grandland 1.6 300 KM Plug-in – dobry SUV, ale nie dla każdego
 - [https://businessinsider.com.pl/technologie/motoryzacja/opel-grandland-16-300-km-plug-in-dobry-suv-ale-nie-dla-kazdego-test/9m3jnyt](https://businessinsider.com.pl/technologie/motoryzacja/opel-grandland-16-300-km-plug-in-dobry-suv-ale-nie-dla-kazdego-test/9m3jnyt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:30:00+00:00
 - user: None

Opel Grandland to ładny SUV, występujący też w postaci hybrydy, której baterie można ładować z gniazdka. Właśnie taki wariant sprawdzamy i to w niebagatelnej wersji, bo z napędem spalinowo-elektrycznym, na cztery koła, którego łączna moc wynosi aż 300 KM! Czy to nie przesada, zważywszy, że mowa o rodzinnym SUV-ie?

## "Zimna wojna" między USA a Unią Europejską? Konflikt handlowy od dawna nie był tak blisko
 - [https://businessinsider.com.pl/finanse/handel/wielki-spor-miedzy-usa-a-unia-europejska-wojna-handlowa-najblizej-od-lat/q6h2t1y](https://businessinsider.com.pl/finanse/handel/wielki-spor-miedzy-usa-a-unia-europejska-wojna-handlowa-najblizej-od-lat/q6h2t1y)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:24:35+00:00
 - user: None

Wydawać by się mogło, że agresywna Rosja sprawi, iż więzy między Stanami Zjednoczonymi a Unią Europejską będą najsilniejsze od czasów zimnej wojny. W rzeczywistości jednak Zachód znalazł się u progu wewnętrznej wojny handlowej. Komisja Europejska wprost zarzuca Amerykanom podążanie drogą Chin i nadmierne faworyzowanie krajowej produkcji kosztem towarów z zewnątrz. Odpowiedź Waszyngtonu jest zdecydowana. — Jestem krytykowany na arenie międzynarodowej za zbytnie skupianie się na Ameryce. Do diabła z tym – mówił Joe Biden, dając do zrozumienia, że pola na ustępstwa już nie ma.

## WOŚP 2023. Tyle zebrano w czasie 31. Finału
 - [https://businessinsider.com.pl/wiadomosci/wosp-2023-ile-zebrano-w-czasie-31-finalu/4fvlrs6](https://businessinsider.com.pl/wiadomosci/wosp-2023-ile-zebrano-w-czasie-31-finalu/4fvlrs6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:12:56+00:00
 - user: None

Do tej pory wolontariusze Wielkiej Orkiestry Świątecznej Pomocy zebrali 154 mln 606 tys. 764 zł — poinformował sztab WOŚP w niedzielę po północy, podsumowując dotychczasowy przebieg akcji. Tegoroczny finał WOŚP przebiega pod hasłem "Chcemy wygrać z sepsą! Gramy dla wszystkich – małych i dużych!".

## Jeszcze więcej pieniędzy na armię. Wiemy, jaką sumą będzie dysponował specjalny fundusz [TYLKO U NAS]
 - [https://businessinsider.com.pl/wiadomosci/fundusz-wsparcia-sil-zbrojny-rosnie-w-sile-mon-ujawnia-jaka-kwota-bedzie-dysponowal/7rrjyee](https://businessinsider.com.pl/wiadomosci/fundusz-wsparcia-sil-zbrojny-rosnie-w-sile-mon-ujawnia-jaka-kwota-bedzie-dysponowal/7rrjyee)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-30 05:02:56+00:00
 - user: None

Fundusz Wsparcia Sił Zbrojny będzie w tym roku dysponował kwotą o prawie 10 mld zł wyższa, niż rząd zakładał jeszcze kilka tygodni temu. Z informacji, jakie Business Insider Polska uzyskał w resorcie obrony narodowej, wynika, że wielkość wpływów Funduszu w tym roku wyniesie nieco ponad 49 mld zł. To zaś oznacza, że cały budżet na armię, razem z pieniędzmi zarezerwowanymi w kasie państwa, sięgnie blisko 150 mld zł.
