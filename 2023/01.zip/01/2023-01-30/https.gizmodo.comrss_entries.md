# Source Gizmodo, Source URL:https://gizmodo.com/rss, Source language: en-US

## Showtime De-Fangs Let the Right One In After a Single Season
 - [https://gizmodo.com/showtime-let-the-right-one-in-cancellation-vampire-show-1850050761](https://gizmodo.com/showtime-let-the-right-one-in-cancellation-vampire-show-1850050761)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 22:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--2y8kzVLi--/c_fit,fl_progressive,q_80,w_636/449eafe3c5c9789cd1837acd8da4a595.jpg" /><p><em>Let the Right One In</em>—the <a href="https://gizmodo.com/side-by-side-comparison-let-the-right-one-in-vs-the-5577842">gorgeously bleak 2008 Swedish movie</a> based on the 2004 Swedish horror novel—is remembered fondly for its unique vampire story, exploring the grim but  loving relationship between a girl who thirsts for blood and the man who acts as her protector and prey-snatcher. The <a href="https://gizmodo.com/let-the-right-one-in-showtime-vampire-series-first-look-1849200899">Showtime series based on…</a></p><p><a href="https://gizmodo.com/showtime-let-the-right-one-in-cancellation-vampire-show-1850050761">Read more...</a></p>

## Food Blogger Fined Nearly $20,000 for Eating Great White Shark
 - [https://gizmodo.com/great-white-shark-food-blogger-tizi-china-1850050448](https://gizmodo.com/great-white-shark-food-blogger-tizi-china-1850050448)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 22:10:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--sHGZNows--/c_fit,fl_progressive,q_80,w_636/1efc3795cb4119f2bc873aa62e9868bb.jpg" /><p>A Chinese food blogger has been fined $18,500 for cooking and eating a great white shark in a video posted online. The blogger, who goes by the name Tizi was identified by officials as Jin, who said she had bought the shark on an Alibaba-owned shopping site Taobao for 7,700 yuan ($1,141). </p><p><a href="https://gizmodo.com/great-white-shark-food-blogger-tizi-china-1850050448">Read more...</a></p>

## AI Voice Simulator Easily Abused to Deepfake Celebrities Spouting Racism and Homophobia
 - [https://gizmodo.com/ai-joe-rogan-4chan-deepfake-elevenlabs-1850050482](https://gizmodo.com/ai-joe-rogan-4chan-deepfake-elevenlabs-1850050482)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 21:50:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--q8sFeKPH--/c_fit,fl_progressive,q_80,w_636/e88777151d35abe1fd1746ccfe15f13a.jpg" /><p>Who could have possibly seen this coming? AI image generators have been used to create <a href="https://techcrunch.com/2022/11/17/meet-unstable-diffusion-the-group-trying-to-monetize-ai-porn-generators/?guccounter=1&amp;guce_referrer=aHR0cHM6Ly93d3cudGhldmVyZ2UuY29tLw&amp;guce_referrer_sig=AQAAAIrdQpEcKPWc2grsfRBz1jur1vkE0heUsO0hRy_AU_d0rk0s5QDNrJJaaToTyUE0oHNGkFfsw-j_tcSCihtJgH5zrPkBeaCiWg5TYR0Pk2asK0EBw5iHZqd1kP97xMlRVOKqk9qKjOCUpuGz7dWPLop7Rtv40ADzg6lL5tAoLgyV" rel="noopener noreferrer" target="_blank">non-consensual pornography</a> of celebrities, but why would that same user base dare abuse a free AI text-to-speech deepfake voice generator?<br /></p><p><a href="https://gizmodo.com/ai-joe-rogan-4chan-deepfake-elevenlabs-1850050482">Read more...</a></p>

## OnePlus Could Be the Next Android Brand with Folding Smartphones
 - [https://gizmodo.com/oneplus-v-fold-flip-folding-foldable-android-smartphone-1850050368](https://gizmodo.com/oneplus-v-fold-flip-folding-foldable-android-smartphone-1850050368)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 21:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--CeBvSWFy--/c_fit,fl_progressive,q_80,w_636/5d7a9dd728daf5500d8378cc79b89704.jpg" /><p>OnePlus could be the next major Android brand with a foldable smartphone. A circulating leak from the Chinese patent offices indicates the company may already be laying the groundwork to offer an alternative for U.S. users. <br /></p><p><a href="https://gizmodo.com/oneplus-v-fold-flip-folding-foldable-android-smartphone-1850050368">Read more...</a></p>

## Texas Is Staring Down a Major Winter Storm
 - [https://gizmodo.com/central-texas-winter-storm-freezing-rain-1850049046](https://gizmodo.com/central-texas-winter-storm-freezing-rain-1850049046)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 21:32:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--1bvW_xwF--/c_fit,fl_progressive,q_80,w_636/16efd33e488ce6267bfa35ec23f64e98.jpg" /><p>An Arctic cold front is bearing down on the Great Plains and points south, all the way into Central Texas this week. Already, cold temperatures and <a href="https://twitter.com/NWSFortWorth/status/1620142633795330050" rel="noopener noreferrer" target="_blank">freezing rain have begun</a> across the state, and the dangerous winter weather is likely to persist through Wednesday, according to Monday morning’s short-range forecast from…</p><p><a href="https://gizmodo.com/central-texas-winter-storm-freezing-rain-1850049046">Read more...</a></p>

## Norways Finds a Treasure Trove of Minerals in Its Seabed
 - [https://gizmodo.com/norway-seabed-rare-earth-metals-copper-minerals-1850049338](https://gizmodo.com/norway-seabed-rare-earth-metals-copper-minerals-1850049338)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 21:03:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--U79DBI7c--/c_fit,fl_progressive,q_80,w_636/bf73ec27ac066684c1b990d1c2417b78.jpg" /><p>A recent  study from the Norwegian Petroleum Directorate found large amounts of valuable metals and minerals on the seabed of the country’s continental shelf, <a href="https://www.reuters.com/markets/commodities/norway-finds-substantial-mineral-resources-its-seabed-2023-01-27/" rel="noopener noreferrer" target="_blank">Reuters reported</a>. The rare earth metals, copper, and other materials would be a boon to Europe’s ability to produce energy transition technologies, but…</p><p><a href="https://gizmodo.com/norway-seabed-rare-earth-metals-copper-minerals-1850049338">Read more...</a></p>

## Elon Apologizes for Spreading Conspiracy Theory About the Hammer Attack on Paul Pelosi
 - [https://gizmodo.com/elon-musk-nancy-pelosi-paul-attack-apology-conspiracy-1850049972](https://gizmodo.com/elon-musk-nancy-pelosi-paul-attack-apology-conspiracy-1850049972)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 20:56:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ePuYSSUT--/c_fit,fl_progressive,q_80,w_636/27abdb54588dd371df8e22a4a37353fc.jpg" /><p>Twitter CEO Elon Musk gave a brief public apology for his role in helping spread and <a href="https://gizmodo.com/conspiracy-theories-paul-nancy-pelosi-hammers-underwear-1849720475">amplify a baseless conspiracy</a> related to the brutal October attack on Paul Pelosi, the husband of Rep. Nancy Pelosi. Musk’s backtracking comes just days after the release of graphic police body camera footage capturing the attempt on…</p><p><a href="https://gizmodo.com/elon-musk-nancy-pelosi-paul-attack-apology-conspiracy-1850049972">Read more...</a></p>

## Crunchyroll Has Quietly Launched Gundam: The Witch From Mercury's English Dub
 - [https://gizmodo.com/gundam-witch-from-mercury-english-dub-streaming-1850049783](https://gizmodo.com/gundam-witch-from-mercury-english-dub-streaming-1850049783)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 20:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--DkOmjqMu--/c_fit,fl_progressive,q_80,w_636/bb3fe15c6585188e52f88b5d0a7ebcf7.png" /><p><a href="https://gizmodo.com/gundam-witch-from-mercury-suletta-miorine-wives-lgbtq-1849610157"><em>Mobile Suit Gundam: The Witch From Mercury</em></a>’s first season was one of io9's <a href="https://gizmodo.com/best-animation-2022-gundam-pinocchio-chainsaw-man-1849927257">favorites last year</a>, but if you were waiting for the series to get dubbed into English before you hopped on the <a href="https://gizmodo.com/gundam-witch-from-mercury-slap-aerial-suletta-miorine-1849971348">high-fivin’ hype train</a>, then good news: it looks like your time is <em>right now</em>.<br /></p><p><a href="https://gizmodo.com/gundam-witch-from-mercury-english-dub-streaming-1850049783">Read more...</a></p>

## FAA Says Computer System Update Should Prevent Another Glitch That Grounded 11,000 Planes
 - [https://gizmodo.com/faa-notam-airlines-ground-stop-1850049706](https://gizmodo.com/faa-notam-airlines-ground-stop-1850049706)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 20:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--lGbR1erN--/c_fit,fl_progressive,q_80,w_636/8cf3f0aa601121bf82a687e9bb6dfb51.jpg" /><p>The Federal Aviation Administration (FAA) has implemented computer system changes to combat outages like the one that occurred on January 11, resulting in more than <a href="https://gizmodo.com/flights-faa-grounds-all-domestic-us-notice-air-missions-1849973999">11,000 flight disruptions</a>.<br /></p><p><a href="https://gizmodo.com/faa-notam-airlines-ground-stop-1850049706">Read more...</a></p>

## The Most Dazzling Ocean Photos of the Year
 - [https://gizmodo.com/ocean-art-contest-photos-2022-nature-1850049833](https://gizmodo.com/ocean-art-contest-photos-2022-nature-1850049833)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 20:30:47+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ehGfxWRq--/c_fit,fl_progressive,q_80,w_636/166accef387bca242d310231bd74ffbb.jpg" /><p>The oceans remain one of the most unexplored places on the planet. But every once in a while, we get a glimpse of the beauty and terror they contain. This month, the Underwater Photography Guide announced the latest winners of its <a href="https://www.uwphotographyguide.com/ocean-art-contest-winners-2022" rel="noopener noreferrer" target="_blank">Ocean Art Contest</a>, filled with plenty of these fascinating peeks under the water’s…</p><p><a href="https://gizmodo.com/ocean-art-contest-photos-2022-nature-1850049833">Read more...</a></p>

## Coal in the U.S. Is Pointlessly Expensive
 - [https://gizmodo.com/coal-more-expensive-than-renewables-usa-1850049391](https://gizmodo.com/coal-more-expensive-than-renewables-usa-1850049391)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 20:08:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UY_Ix1KR--/c_fit,fl_progressive,q_80,w_636/619e14028ac45cbc9625049b122e02cc.jpg" /><p>Nearly all of the coal plants operating in the U.S. are now more expensive to keep online than it would be to build entirely new renewable energy facilities in their stead, according to a new analysis by Energy Innovation, an energy and policy firm. The <a href="https://energyinnovation.org/publication/the-coal-cost-crossover-3-0/" rel="noopener noreferrer" target="_blank">analysis</a> found that 99% of U.S. coal plants supply energy that…</p><p><a href="https://gizmodo.com/coal-more-expensive-than-renewables-usa-1850049391">Read more...</a></p>

## The Latest Last Of Us Has Linda Ronstadt Running Up Those Charts
 - [https://gizmodo.com/last-of-us-linda-ronstadt-streaming-long-long-time-song-1850049711](https://gizmodo.com/last-of-us-linda-ronstadt-streaming-long-long-time-song-1850049711)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 19:50:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--m01aHc1Q--/c_fit,fl_progressive,q_80,w_636/71dba4d9c0cbe5072d855dcdf63eac7a.jpg" /><p>Last night’s episode of <a href="https://gizmodo.com/last-of-us-episode-3-recap-pedro-pascal-nick-offerman-1850021207"><em>The Last Of Us</em></a> has genre TV fans everywhere buzzing, thanks in part to a certain vintage pop hit. And now, like <a href="https://gizmodo.com/kate-bush-stranger-things-season-4-running-up-that-hill-1849092944">another specific piece of music before it</a>, the song is seeing a huge surge in popularity.</p><p><a href="https://gizmodo.com/last-of-us-linda-ronstadt-streaming-long-long-time-song-1850049711">Read more...</a></p>

## Vrbo Works to Squash Super Bowl Party Rentals
 - [https://gizmodo.com/vrbo-super-bowl-short-term-rental-airbnb-1850048946](https://gizmodo.com/vrbo-super-bowl-short-term-rental-airbnb-1850048946)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 19:05:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--nDfSUcHm--/c_fit,fl_progressive,q_80,w_636/523286dc218ba9d70e4fdf9cb1d2edf7.jpg" /><p>Vrbo is asking users to host any planned 2023 Super Bowl blowouts in their own damned home, and not mess up somebody else’s abode or rental property.</p><p><a href="https://gizmodo.com/vrbo-super-bowl-short-term-rental-airbnb-1850048946">Read more...</a></p>

## Avatar 2 Just Passed the Highest-Grossing Star Wars Movie
 - [https://gizmodo.com/avatar-2-box-office-ranking-star-wars-the-force-awakens-1850049173](https://gizmodo.com/avatar-2-box-office-ranking-star-wars-the-force-awakens-1850049173)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 18:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--TmBf6PFP--/c_fit,fl_progressive,q_80,w_636/f32746977f75be8c86e3257e97f00a38.jpg" /><p>Too bad no one has seen <a href="https://gizmodo.com/avatar-2-movie-review-the-way-of-water-james-cameron-1849876980"><em>Avatar: The Way of Water</em></a>. If they had, maybe it would already be the highest-grossing movie of all time. As it stands though, <a href="https://gizmodo.com/avatar-2-release-date-delay-james-cameron-pandora-water-1849854621">the little movie that could</a> just became merely the <em>fourth</em> highest-grossing movie of all-time, topping <a href="https://gizmodo.com/the-force-awakens-has-obliterated-box-office-records-in-1748983309">the highest-grossing film</a> in one of the world’s most popular…</p><p><a href="https://gizmodo.com/avatar-2-box-office-ranking-star-wars-the-force-awakens-1850049173">Read more...</a></p>

## Google Cuts Its Director of Mental Health and Wellbeing
 - [https://gizmodo.com/google-alphabet-mental-health-well-being-layoffs-1850048313](https://gizmodo.com/google-alphabet-mental-health-well-being-layoffs-1850048313)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 18:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--wVlsdjUh--/c_fit,fl_progressive,q_80,w_636/671dc6bff2ba77cbfc00fda39e7419be.jpg" /><p>As layoffs continue to <a href="https://gizmodo.com/the-12-biggest-tech-layoffs-of-the-year-so-far-1849372352">plague the tech sector</a>, even the titans of the industry aren’t safe. Amidst ongoing <a href="https://gizmodo.com/google-layoffs-tiktok-ex-employees-vlogs-videos-1850042760">layoffs at Google</a>, we’ve learned the company has let go of its mental health executive, according to <a href="https://www.businessinsider.com/google-layoffs-mental-health-and-wellbeing-director-jobs-workers-tech-2023-1" rel="noopener noreferrer" target="_blank">Insider</a>.<br /></p><p><a href="https://gizmodo.com/google-alphabet-mental-health-well-being-layoffs-1850048313">Read more...</a></p>

## Jordan Peele's Akira Adaption Exists Only in References
 - [https://gizmodo.com/jordan-peele-nope-akira-adaption-references-film-1850048374](https://gizmodo.com/jordan-peele-nope-akira-adaption-references-film-1850048374)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 17:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--V7t8Zv52--/c_fit,fl_progressive,q_80,w_636/2a61cfd3b0f20bb89dccbf9e3a79e105.png" /><p>Jordan Peele appeared on the <a href="https://youtu.be/zltKTg7lWqk" rel="noopener noreferrer" target="_blank"><em>Happy Sad Confused</em></a> podcast recently to talk about his career, <a href="https://gizmodo.com/jordan-peele-answers-nope-questions-shoe-angels-sequel-1850003321"><em>Nope</em> theories</a>, and even give some insight on how he feels about his short-lived association to an <a href="https://gizmodo.com/taika-waititi-still-plans-on-directing-akira-eventuall-1839207999"><em>Akira </em>live-action movie</a>. Rumors about Peele’s association with <a href="https://gizmodo.com/akira-is-getting-a-4k-remaster-and-a-new-anime-1836127694"><em>Akira</em></a> came after his hit directorial debut, <em>Get Out, </em>but nothing…</p><p><a href="https://gizmodo.com/jordan-peele-nope-akira-adaption-references-film-1850048374">Read more...</a></p>

## Nothing Phone (2) is Coming to the U.S. Sometime This Year
 - [https://gizmodo.com/nothing-phone-2-us-2023-release-date-premium-usa-americ-1850048861](https://gizmodo.com/nothing-phone-2-us-2023-release-date-premium-usa-americ-1850048861)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 17:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dkxn6_3W--/c_fit,fl_progressive,q_80,w_636/2f54c915b6a816bca6766170d8cd749d.jpg" /><p>Nothing, the company behind the light-up <a href="https://gizmodo.com/nothing-phone-1-review-glyph-camera-launcher-price-us-1849179261">Nothing Phone (1)</a>, is still nothing in the U.S., and its CEO wants that to change. Speaking to <a href="https://www.inverse.com/gear/nothing-phone-2-us-2023-release-carl-pei-interview" rel="noopener noreferrer" target="_blank">Inverse</a>, Nothing CEO Carl Pei expressed a renewed focus on competing in the U.S. market with its upcoming second-generation Phone (2).<br /></p><p><a href="https://gizmodo.com/nothing-phone-2-us-2023-release-date-premium-usa-americ-1850048861">Read more...</a></p>

## Oops, I Did It Again: Apple Faces Fourth iPhone Privacy Lawsuit After Gizmodo Story
 - [https://gizmodo.com/apple-iphone-analytics-privacy-4th-lawsuit-1850048418](https://gizmodo.com/apple-iphone-analytics-privacy-4th-lawsuit-1850048418)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 17:30:00+00:00
 - user: rumpel
 - tags: tracking,privacy,apple

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Cx9DENeH--/c_fit,fl_progressive,q_80,w_636/346b18049a9ba8ea1a15be6fc36bcc4d.png" /><p>Apple is famous for breaking records, and apparently it’s just as competitive when it comes to getting sued. The company was just hit with a fourth class-action lawsuit over accusations <a href="https://gizmodo.com/apple-iphone-ipad-privacy-problems-data-gathering-1849855092">surreptitious iPhone data collection</a>. Three of those lawsuits were filed in January alone. Impressive.<br /></p><p><a href="https://gizmodo.com/apple-iphone-analytics-privacy-4th-lawsuit-1850048418">Read more...</a></p>

## Defunct Satellite and Rocket Stage Nearly Collide in Potential ‘Worst-Case Scenario’
 - [https://gizmodo.com/near-miss-orbit-collision-satellite-rocket-soviet-1850048253](https://gizmodo.com/near-miss-orbit-collision-satellite-rocket-soviet-1850048253)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 17:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--VGpW37E0--/c_fit,fl_progressive,q_80,w_636/3b9e625a1be9d571cd45c3d45b24df7f.jpg" /><p>An old rocket body and military satellite—large pieces of space junk dating back to the Soviet Union—nearly smashed into each other on Friday morning, in an uncomfortable near-miss that would’ve resulted in thousands of pieces of debris had they collided.<br /></p><p><a href="https://gizmodo.com/near-miss-orbit-collision-satellite-rocket-soviet-1850048253">Read more...</a></p>

## The First Glimpse of Netflix's Live-Action One Piece Has Docked
 - [https://gizmodo.com/one-piece-live-action-netflix-poster-luffy-zoro-sanji-1850048408](https://gizmodo.com/one-piece-live-action-netflix-poster-luffy-zoro-sanji-1850048408)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 17:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Gl4bh26A--/c_fit,fl_progressive,q_80,w_636/fb7c35901541c91571ffefdbc7f06987.jpg" /><p>We’ve finally gotten our official look at Netflix’s <a href="https://gizmodo.com/one-pieces-awesomely-international-live-action-cast-has-1848027437">much-anticipated</a>, maybe <a href="https://gizmodo.com/one-piece-live-action-netflix-manga-anime-eiichiro-oda-1849022984">slightly dreaded</a> live-action of adaptation of Eiichiro Oda’s beyond-best-selling manga <a href="https://gizmodo.com/one-piece-chapter-1044-spoilers-luffy-joyboy-powers-exp-1848728057"><em>One Piece</em></a>, and, well, it’s a lot of people’s backs. But man, those backs look incredibly accurate to the manga and anime.<br /></p><p><a href="https://gizmodo.com/one-piece-live-action-netflix-poster-luffy-zoro-sanji-1850048408">Read more...</a></p>

## NASA Team to Investigate Recurring Problem With Juno Orbiter Camera
 - [https://gizmodo.com/nasa-juno-orbiter-camera-malfunction-1850048457](https://gizmodo.com/nasa-juno-orbiter-camera-malfunction-1850048457)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 16:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Zq2sND8V--/c_fit,fl_progressive,q_80,w_636/e799a59fd28d5108f92a28cc59a8a2be.jpg" /><p>The Juno spacecraft did not take all the images it was supposed to during a flyby of Jupiter on January 22. NASA says it will look into the problem.</p><p><a href="https://gizmodo.com/nasa-juno-orbiter-camera-malfunction-1850048457">Read more...</a></p>

## The Last Of Us Showrunners Dive Into the Reasons and Meaning Behind Episode 3
 - [https://gizmodo.com/last-of-us-3-explained-craig-mazin-neil-druckmann-hbo-1850026210](https://gizmodo.com/last-of-us-3-explained-craig-mazin-neil-druckmann-hbo-1850026210)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 16:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZOGcBQfO--/c_fit,fl_progressive,q_80,w_636/0597e95cff83b112be20d951d3be2e99.jpg" /><p>A few weeks ago, as I was watching screeners for <a href="https://gizmodo.com/last-of-us-hbo-review-playstation-pedro-pascal-joel-ell-1849950042">HBO’s new show, <em>The Last Of Us</em></a>, I immediately thought <a href="https://gizmodo.com/last-of-us-hbo-length-left-behind-dlc-neil-druckmann-1849945355">about this moment</a>. Today. Right now. You reading this. The day after everyone else could see what I just witnessed. </p><p><a href="https://gizmodo.com/last-of-us-3-explained-craig-mazin-neil-druckmann-hbo-1850026210">Read more...</a></p>

## TikTok CEO to Face Congressional Hearing in March
 - [https://gizmodo.com/tiktok-bytedance-china-tiktok-ban-congress-1850047848](https://gizmodo.com/tiktok-bytedance-china-tiktok-ban-congress-1850047848)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 16:05:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--AkNBQFKO--/c_fit,fl_progressive,q_80,w_636/420ce2fe58ce29d2327de3078d445947.jpg" /><p>TikTok CEO Shou Zi Chew is set to testify before a congressional committee in in less than two months, according to <a href="https://www.wsj.com/articles/tiktoks-chief-to-testify-before-congress-in-march-11675050606" rel="noopener noreferrer" target="_blank">a report</a> from the Wall Street Journal. On March 23, Chew will appear in front of the House Energy and Commerce Committee, a congressional spokesperson told the outlet. The TikTok head will be the sole…</p><p><a href="https://gizmodo.com/tiktok-bytedance-china-tiktok-ban-congress-1850047848">Read more...</a></p>

## This Mario 64 Mod Almost Looks Like a Gamecube Game and Runs on Actual Hardware
 - [https://gizmodo.com/mario-64-mod-gamecube-nintendo-64-graphics-fps-framerat-1850048235](https://gizmodo.com/mario-64-mod-gamecube-nintendo-64-graphics-fps-framerat-1850048235)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 16:00:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--ARroMbdG--/c_fit,fl_progressive,q_80,w_636/2196a7296aa62a5d69847a578927f15d.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--_2mY5UrF--/c_fit,fl_progressive,q_80,w_636/2196a7296aa62a5d69847a578927f15d.mp4" type="video/mp4" /></video><p>We all have a favorite video game that we’ve played through time and time again (for me, it’s <a href="https://gizmodo.com/nintendos-new-game-watch-is-a-zelda-fans-must-have-1848069927"><em>Link’s Awakening</em></a>) but for Kaze Emanuar, simply playing through the N64's <em>Super Mario 64</em> isn’t enough. Through modding, they’re trying to <a href="https://gonintendo.com/contents/15499-modder-pushes-the-limits-of-the-n64-with-a-new-mario-project" rel="noopener noreferrer" target="_blank">push the game to its absolute limits</a>, and so far <a href="https://www.youtube.com/watch?v=DUbR8C6svHs" rel="noopener noreferrer" target="_blank">the results are unbelievable</a> for a…</p><p><a href="https://gizmodo.com/mario-64-mod-gamecube-nintendo-64-graphics-fps-framerat-1850048235">Read more...</a></p>

## New Chatbot Is Coming to Chinese Internet Company Baidu
 - [https://gizmodo.com/baidu-chatgpt-ai-search-engine-google-1850048152](https://gizmodo.com/baidu-chatgpt-ai-search-engine-google-1850048152)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 15:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--EJRtmesq--/c_fit,fl_progressive,q_80,w_636/5e5c74a89f4eca3a929005e68f7860c1.jpg" /><p>Chinese-owned internet company Baidu Inc. is reportedly launching a <a href="https://gizmodo.com/chatgpt-free-ai-10-fails-nyc-schools-college-essay-porn-1849956907">ChatGPT</a>-style bot in March to merge with the company’s search engine eventually, an unnamed source familiar with the matter told the <a href="https://www.wsj.com/articles/baidu-is-developing-its-own-chatgpt-aiming-to-integrate-it-into-search-11675065601?mod=Searchresults_pos1&amp;page=1" rel="noopener noreferrer" target="_blank">Wall Street Journal</a>. </p><p><a href="https://gizmodo.com/baidu-chatgpt-ai-search-engine-google-1850048152">Read more...</a></p>

## Rare Polar Bear Attack in Canada | Extreme Earth
 - [https://gizmodo.com/rare-polar-bear-attack-in-canada-extreme-earth-1850041161](https://gizmodo.com/rare-polar-bear-attack-in-canada-extreme-earth-1850041161)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 15:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--WYeSv0KZ--/c_fit,fl_progressive,q_80,w_636/652669cc8dd7c1c10e930eeb094a3843.jpg" /><p><a href="https://gizmodo.com/rare-polar-bear-attack-in-canada-extreme-earth-1850041161">Read more...</a></p>

## How 19 ‘Cop City’ Activists Got Charged With Terrorism
 - [https://gizmodo.com/how-19-cop-city-activists-got-charged-with-terrorism-1850048136](https://gizmodo.com/how-19-cop-city-activists-got-charged-with-terrorism-1850048136)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 15:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--X9418DiS--/c_fit,fl_progressive,q_80,w_636/3c3372c29c56ddaf90edc96ced25f7cb.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/how-19-cop-city-activists-got-charged-with-terrorism-1850048136">Read more...</a></p>

## Neko Mario Pounces in the New Super Mario Teaser
 - [https://gizmodo.com/cat-mario-nintendo-the-last-of-us-morning-spoilers-1850046033](https://gizmodo.com/cat-mario-nintendo-the-last-of-us-morning-spoilers-1850046033)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 15:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--8Os8M3eI--/c_fit,fl_progressive,q_80,w_636/ec383e2ffd75717f1d8d1da829a1fa70.png" /><p>Ah, <a href="https://gizmodo.com/mario-movie-clip-mushroom-kingdom-chris-pratt-nintendo-1849873019">Kitty Mario</a>. Never has anything ever been more cursed than Chris Pratt saying “meow” while his character is in a yellow catsuit. Scarring stuff. Besides furry animated plumbers, we’ve got some info on Disney’s <a href="https://gizmodo.com/tony-hale-first-fandoms-1849751624"><em>The Mysterious Benedict Society</em></a> and a couple of episode trailers from <a href="https://gizmodo.com/mindy-kaling-velma-trailer-hbo-max-adult-animated-1849975740"><em>Velma</em></a> and <a href="https://gizmodo.com/last-of-us-hbo-review-playstation-pedro-pascal-joel-ell-1849950042"><em>The Last of Us</em></a>. Let’s…</p><p><a href="https://gizmodo.com/cat-mario-nintendo-the-last-of-us-morning-spoilers-1850046033">Read more...</a></p>

## Apple Analyst Says Company Will Finally Offer Up a Foldable iPad in 2024
 - [https://gizmodo.com/apple-foldable-ipad-2024-kuo-leak-rumor-kickstand-mini-1850047968](https://gizmodo.com/apple-foldable-ipad-2024-kuo-leak-rumor-kickstand-mini-1850047968)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 15:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--yeW5UnmR--/c_fit,fl_progressive,q_80,w_636/932adfa79ee6bf38f3c159d1a2a9c8ee.jpg" /><p>Apple has yet to fold on the lingering image of itself as a maverick. But now that Samsung, Oppo, and Huawei are <a href="https://gizmodo.com/smartphone-apple-android-samsung-google-2023-prediction-1849920715">releasing plenty of foldable devices</a>, one oft-cited analyst says that Apple will need a full year and change before it can release its first foldable device.</p><p><a href="https://gizmodo.com/apple-foldable-ipad-2024-kuo-leak-rumor-kickstand-mini-1850047968">Read more...</a></p>

## Clever Hacker Finds the Perfect Way to Creatively Vandalize London's Knightrider Court
 - [https://gizmodo.com/london-knightrider-court-knight-rider-tv-show-hacker-1850047884](https://gizmodo.com/london-knightrider-court-knight-rider-tv-show-hacker-1850047884)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 14:50:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--9zwJ6N_l--/c_fit,fl_progressive,q_80,w_636/f8d99d837c45686a4e8388caad6ad7cf.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--1TG8SFt---/c_fit,fl_progressive,q_80,w_636/f8d99d837c45686a4e8388caad6ad7cf.mp4" type="video/mp4" /></video><p>We here at Gizmodo do not normally endorse vandalism of any kind, but we’re making an exception this time for two reasons. First, Matt Gray isn’t actually causing any permanent damage—the upgrades are easily removable. And second, how could a talented hardware hacker be expected to resist having a little fun with this…</p><p><a href="https://gizmodo.com/london-knightrider-court-knight-rider-tv-show-hacker-1850047884">Read more...</a></p>

## Mercedes-Benz Says It's Doing Autonomous Driving Better Than Tesla
 - [https://gizmodo.com/mercedes-benz-tesla-autonomous-driving-driver-pilot-1850047723](https://gizmodo.com/mercedes-benz-tesla-autonomous-driving-driver-pilot-1850047723)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 14:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--oFJ81CBt--/c_fit,fl_progressive,q_80,w_636/f79144523846587e9f0ad0e3c538f2c9.jpg" /><p><a href="https://gizmodo.com/mercedes-electric-vehicle-bmw-acceleration-increase-1849817295">Mercedes-Benz</a> is apparently beating Tesla at its own game as the luxury car manufacturer <a href="https://media.mbusa.com/releases/mercedes-benz-worlds-first-automotive-company-to-certify-sae-level-3-system-for-us-market" rel="noopener noreferrer" target="_blank">announced last week</a> that its new car system has a level of autonomous capabilities that is higher than Tesla’s current level of <a href="https://gizmodo.com/tesla-elon-musk-full-self-driving-autopilot-1849930860">self-driving</a>.<br /></p><p><a href="https://gizmodo.com/mercedes-benz-tesla-autonomous-driving-driver-pilot-1850047723">Read more...</a></p>

## Grab Your Helmets and Let's-a Go Into This Week's Toy News
 - [https://gizmodo.com/super-mario-movie-figures-lego-star-wars-helmets-krang-1850021792](https://gizmodo.com/super-mario-movie-figures-lego-star-wars-helmets-krang-1850021792)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 14:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--BxoTrOZa--/c_fit,fl_progressive,q_80,w_636/1d170ed7cfcf9c73fc2353be250477fe.jpg" /><p>Welcome back to Toy Aisle, io9's regular weekly round up of the latest toy news on the internet. Kick off the week with a trio of <a href="https://gizmodo.com/legos-finally-doing-something-it-shouldve-done-with-sta-1848697588"><em>Star Wars</em></a> <a href="https://gizmodo.com/dark-helmet-would-love-this-exclusive-lego-darth-helmet-1833474726">Lego helmets</a>, another <em>Beast Wars</em> classic making its way to <a href="https://gizmodo.com/transformers-rise-of-the-beasts-trailer-teaser-beast-wa-1849839119"><em>Rise of the Beasts</em></a>, and a supersized <em>TMNT</em> Krang. Check it out!<br /></p><p><a href="https://gizmodo.com/super-mario-movie-figures-lego-star-wars-helmets-krang-1850021792">Read more...</a></p>

## This Week in Spaceflight: SpaceX Starship Static Fire Test, ISS Spacewalk, and More
 - [https://gizmodo.com/spacex-starship-static-fire-test-iss-spacewalk-columbia-1850042358](https://gizmodo.com/spacex-starship-static-fire-test-iss-spacewalk-columbia-1850042358)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 14:14:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PMb0xQUB--/c_fit,fl_progressive,q_80,w_636/fb5bc21c772620136b23e27fa27a3a77.jpg" /><p> SpaceX continues to launch its Falcon 9 rocket at a frenetic pace, as the calendar flips over to February this week. Excitingly, the company could perform its first full static fire test of the enormous Starship, in which all 33 Raptor engines will simultaneously roar to life.<br /></p><p><a href="https://gizmodo.com/spacex-starship-static-fire-test-iss-spacewalk-columbia-1850042358">Read more...</a></p>

## Watch an Exclusive Deleted Scene From Black Panther: Wakanda Forever
 - [https://gizmodo.com/black-panther-2-deleted-scene-martin-freeman-marvel-mcu-1850030025](https://gizmodo.com/black-panther-2-deleted-scene-martin-freeman-marvel-mcu-1850030025)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 14:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--9UrSa383--/c_fit,fl_progressive,q_80,w_636/196546620ac171b5287a30c958d6bbcc.jpg" /><p><a href="https://gizmodo.com/black-panther-wakanda-forever-movie-review-marvel-studi-1849725648"><em>Black Panther: Wakanda Forever</em></a> comes home this week and with it, you’ll find even more of the <a href="https://gizmodo.com/black-panther-2-spoilers-discussion-wakanda-forever-mcu-1849774928">movie you already loved</a>. The digital release, out February 1, as well as the Blu-ray, out February 7, includes four scenes deleted from the Ryan Coogler <a href="https://gizmodo.com/black-panther-wakanda-forever-mid-credits-scene-impact-1849777747">Marvel Studios sequel</a>—but you don’t have to wait to watch all four. io9…</p><p><a href="https://gizmodo.com/black-panther-2-deleted-scene-martin-freeman-marvel-mcu-1850030025">Read more...</a></p>

## Tesla Model S Bursts Into Flames in California While Driver Was on Highway
 - [https://gizmodo.com/tesla-model-s-fire-highway-california-sacramento-1850047599](https://gizmodo.com/tesla-model-s-fire-highway-california-sacramento-1850047599)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 13:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--F3S0vuXM--/c_fit,fl_progressive,q_80,w_636/28349280de8ae8e85aaa8cd9e322cdb5.png" /><p>A Tesla Model S burst into flames on Saturday while the driver was on a highway outside Sacramento, forcing authorities to bring in significant manpower and thousands of gallons of water to get the fire under control.</p><p><a href="https://gizmodo.com/tesla-model-s-fire-highway-california-sacramento-1850047599">Read more...</a></p>

## Everything We Know About the Facial Recognition Scandal at Madison Square Garden
 - [https://gizmodo.com/madison-square-garden-facial-recognition-what-we-know-1850041475](https://gizmodo.com/madison-square-garden-facial-recognition-what-we-know-1850041475)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ntYni2ER--/c_fit,fl_progressive,q_80,w_636/ed028161bdc1cb14a682db8a035ae743.jpg" /><p>The future of facial recognition use by private companies in the United States could boil down to who emerges victorious in an ongoing dispute between a collection of lawyers and a petty, authoritarian New York billionaire. The place: one of America’s most famous venues, Madison Square Garden. The owner: James Dolan. </p><p><a href="https://gizmodo.com/madison-square-garden-facial-recognition-what-we-know-1850041475">Read more...</a></p>

## Ex-Google Employees Are Vlogging Their Layoffs on TikTok
 - [https://gizmodo.com/google-layoffs-tiktok-ex-employees-vlogs-videos-1850042760](https://gizmodo.com/google-layoffs-tiktok-ex-employees-vlogs-videos-1850042760)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--3XhKzrQf--/c_fit,fl_progressive,q_80,w_636/8747a788cf1c745df68e00395d27ca49.jpg" /><p>When Google <a href="https://gizmodo.com/google-layoffs-12000-workers-largest-cuts-history-1850010658">told 12,000 employees they were out of a job</a> last week, there were <a href="https://finance.yahoo.com/news/engineer-laid-off-over-16-104711925.html" rel="noopener noreferrer" target="_blank">a lot of feels</a>, understandably. Some workers were confused about why they had been laid off. Others were frustrated. Some ex-Googlers were grateful to have even had the opportunity at all.</p><p><a href="https://gizmodo.com/google-layoffs-tiktok-ex-employees-vlogs-videos-1850042760">Read more...</a></p>

## The Last Of Us Took a Major Detour for an Unforgettable Episode
 - [https://gizmodo.com/last-of-us-episode-3-recap-pedro-pascal-nick-offerman-1850021207](https://gizmodo.com/last-of-us-episode-3-recap-pedro-pascal-nick-offerman-1850021207)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 03:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Eg00ex6e--/c_fit,fl_progressive,q_80,w_636/1d99d0504fd1d039976881a30ed2c818.jpg" /><p>We realize it’s only January, but if <a href="https://gizmodo.com/last-of-us-hbo-review-playstation-pedro-pascal-joel-ell-1849950042">2023 gives us a better episode</a> of television than episode three of <em>The Last of Us</em>, we’ll be very lucky. “Long, Long Time”—which was less an episode and <a href="https://gizmodo.com/last-of-us-hbo-craig-mazin-games-violence-naughty-dog-1849932304">more a short movie</a>, clocking in around 76 minutes—told a story <a href="https://gizmodo.com/last-of-us-hbo-craig-mazin-games-violence-naughty-dog-1849932304">inspired by the game</a>, but mostly original to the show. Yes, Joel…</p><p><a href="https://gizmodo.com/last-of-us-episode-3-recap-pedro-pascal-nick-offerman-1850021207">Read more...</a></p>

## Star Trek: Picard's Final Trailer Pushes Back the Darkness
 - [https://gizmodo.com/star-trek-picard-season-3-final-trailer-tng-data-worf-1850046985](https://gizmodo.com/star-trek-picard-season-3-final-trailer-tng-data-worf-1850046985)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-30 01:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--XRv32AtJ--/c_fit,fl_progressive,q_80,w_636/24a271bff97c8f4681721c250037b44b.png" /><p>Jean-Luc Picard has <a href="https://gizmodo.com/patrick-stewart-star-trek-picard-season-3-finale-or-not-1849967542">one more fight</a> left in him—and he needs some help from his friends to make sure <a href="https://gizmodo.com/star-trek-picard-season-3-tng-cast-potential-deaths-1850030245">he can win it</a>.<br /></p><p><a href="https://gizmodo.com/star-trek-picard-season-3-final-trailer-tng-data-worf-1850046985">Read more...</a></p>
