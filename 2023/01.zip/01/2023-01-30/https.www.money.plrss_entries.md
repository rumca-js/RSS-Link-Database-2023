# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## Można dostać nawet 1,5 tys. zł. 1 lutego mija termin składania wniosków
 - [https://www.money.pl/pieniadze/mozna-dostac-nawet-1-5-tys-zl-1-lutego-mija-termin-skladania-wnioskow-6861208981924544a.html](https://www.money.pl/pieniadze/mozna-dostac-nawet-1-5-tys-zl-1-lutego-mija-termin-skladania-wnioskow-6861208981924544a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 17:30:15+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b977fb7d-1a1c-43a5-a63a-25fc6efa80e1" width="308" /> W odpowiedzi na rosnące ceny energii rząd wprowadził dodatek energetyczny. Jest to wsparcie finansowe dla gospodarstw domowych, które ogrzewają swoje mieszkania i domy z pomocą energii elektrycznej. Zostały już tylko dwa dni, by skorzystać - czas kończy się 1 lutego. Kto może dostać pieniądze i jak złożyć wniosek?

## Europa szuka nowych dostawców paliw. Chiński smok energetyczny pręży muskuły
 - [https://www.money.pl/gielda/europa-szuka-nowych-dostawcow-paliw-chinski-smok-energetyczny-prezy-muskuly-6861155888409280a.html](https://www.money.pl/gielda/europa-szuka-nowych-dostawcow-paliw-chinski-smok-energetyczny-prezy-muskuly-6861155888409280a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 16:25:07+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/297b9d41-249a-48e7-93b2-77569c250ca4" width="308" /> Od 5 lutego zacznie obowiązywać europejskie embargo na rosyjskie paliwa sprowadzane drogą morską. Dodatkowo nałożony zostanie pułap cenowy na poziomie 100-110 dol. Unia Europejska musi znaleźć nowych dostawców i coraz częściej spogląda w stronę Chin.

## Reforma emerytalna uziemi samoloty Air France. Linie wydały ważny komunikat
 - [https://www.money.pl/emerytury/reforma-emerytalna-uziemi-samoloty-air-france-linie-wydaly-wazny-komunikat-6861151884434112a.html](https://www.money.pl/emerytury/reforma-emerytalna-uziemi-samoloty-air-france-linie-wydaly-wazny-komunikat-6861151884434112a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 13:38:26+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b31cfd2b-3a6d-4fc1-9c88-7de5fff3feca" width="308" /> We wtorek (31 stycznia) we Francji odbędą się ogólnokrajowe strajki i protesty przeciwko planom podwyższenia wieku emerytalnego. To oznacza problemy m.in. dla pasażerów linii lotniczych Air France.

## Gorzka prawda o emeryturach. Członkini RPP: Osoby, które dziś są przed 40-tką będą otrzymywać świadczenie minimalne
 - [https://www.money.pl/emerytury/gorzka-prawda-o-emeryturach-czlonkini-rpp-osoby-ktore-dzis-sa-przed-40-tka-beda-otrzymywac-swiadczenie-minimalne-6861127025941152a.html](https://www.money.pl/emerytury/gorzka-prawda-o-emeryturach-czlonkini-rpp-osoby-ktore-dzis-sa-przed-40-tka-beda-otrzymywac-swiadczenie-minimalne-6861127025941152a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 11:57:17+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a7e28e6f-7fc1-4255-96a6-2fb4c23a6b69" width="308" /> Przy bieżącym wieku emerytalnym, 78 proc. społeczeństwa urodzonego po 1980 r. będzie otrzymywać emeryturę minimalną i będzie nas to kosztować 4,5 proc. PKB - mówiła w "Rozmowie w południe" w RMF FM prof. Joanna Tyrowicz, członkini z Rady Polityki Pieniężnej.

## Poprawka Suskiego. "To nie tylko zgniły kompromis, ale też niebezpieczna gra"
 - [https://www.money.pl/gospodarka/poprawka-suskiego-to-nie-tylko-zgnily-kompromis-ale-tez-niebezpieczna-gra-6861094288743072a.html](https://www.money.pl/gospodarka/poprawka-suskiego-to-nie-tylko-zgnily-kompromis-ale-tez-niebezpieczna-gra-6861094288743072a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:44:05+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/9ac58c17-1feb-42df-b02b-d3b2926665ca" width="308" /> Nie 500 metrów od zabudowań a 700 - taką poprawkę do tzw. ustawy wiatrakowej na ostatniej prostej zgłosił Marek Suski. Eksperci nie mają jednak wątpliwości, że proponowane rozwiązanie nie jest dobre. - Ograniczenie branży wiatrowej, cios w energetykę i strata dla gospodarki - tak poprawkę ocenia Michał Kaczerowski, ekspert, który od lat zajmuje się rozwijaniem projektów wiatrowych w Polsce.

## Dłuższe spowolnienie gospodarcze. Niepokojące prognozy NBP
 - [https://www.money.pl/firma/wiadomosci/dluzsze-spowolnienie-gospodarcze-niepokojace-prognozy-nbp-6861085054184096a.html](https://www.money.pl/firma/wiadomosci/dluzsze-spowolnienie-gospodarcze-niepokojace-prognozy-nbp-6861085054184096a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:37:21+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c54be0f8-0220-4cfa-bb56-30e82cc4573f" width="308" /> Wskaźnik przyszłej sytuacji oraz prognozy sugerują, że aktualne spowolnienie gospodarcze może być dłuższe od wywołanego pandemią koronawirusa, a także dłuższe niż wskazywały wskaźniki i prognozy formułowane na podstawie danych z końca 2021 r. - czytamy w najnowszym raporcie NBP. Bank Centralny dostrzega także coraz większe utrudnienia w dostępie do finansowania bankowego, z którym zmagają się firmy szczególnie z branży budowalnej.

## Rząd przedłuży wakacje kredytowe o kolejny rok? Jest odpowiedź premiera
 - [https://www.money.pl/banki/rzad-przedluzy-wakacje-kredytowe-o-kolejny-rok-jest-odpowiedz-premiera-6861091343383200a.html](https://www.money.pl/banki/rzad-przedluzy-wakacje-kredytowe-o-kolejny-rok-jest-odpowiedz-premiera-6861091343383200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:32:07+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b0c7f2a5-1e64-41fa-bd33-6c807f3f03c8" width="308" /> Te decyzje jeszcze nie zostały podjęte - odpowiedział premier Mateusz Morawiecki zapytany o to, czy w przyszłym roku również będą obowiązywać wakacje kredytowe. Jak ustalił money.pl, projekt w tej sprawie miał się już znaleźć na biurku szefa rządu.

## Praca zdalna - dodatkowe koszty czy oszczędność dla pracownika?
 - [https://www.money.pl/gospodarka/praca-zdalna-dodatkowe-koszty-czy-oszczednosc-dla-pracownika-6861087954733728a.html](https://www.money.pl/gospodarka/praca-zdalna-dodatkowe-koszty-czy-oszczednosc-dla-pracownika-6861087954733728a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:19:52+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/22a7f299-72b1-4eff-aa2d-0ee1a97d362f" width="308" /> Pandemia spowodowała, że praca zdalna stała się niemal codziennością. Obecnie wielu pracowników woli pracować z domu niż każdego dnia udawać się do biura. Korzyści tzw. home office zauważają jednak nie tylko pracownicy, ale i pracodawcy, którzy nie muszą dłużej wynajmować przestrzeni biurowej. Czy jednak praca zdalna rzeczywiście opłaca się pracownikowi?

## "Efekt napływu migrantów z Ukrainy". Ekonomiści o najnowszych danych na temat PKB Polski w 2022 r.
 - [https://www.money.pl/gospodarka/efekt-naplywu-migrantow-z-ukrainy-ekonomisci-o-najnowszych-danych-na-temat-pkb-polski-w-2022-r-6861082719316672a.html](https://www.money.pl/gospodarka/efekt-naplywu-migrantow-z-ukrainy-ekonomisci-o-najnowszych-danych-na-temat-pkb-polski-w-2022-r-6861082719316672a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:15:49+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/68e725a5-bb5d-4784-8884-eb6036525a8c" width="308" /> Wzrost PKB w 2022 r. wyniósł 4,9 proc. w ujęciu rocznym. Ekonomiści zwracają uwagę, że ubiegłoroczny wynik polskiej gospodarki to w dużej mierze efekt napływu migrantów z ogarniętej wojną Ukrainy. To przyczyniło się do wzrostu konsumpcji, zwłaszcza dóbr pierwszej potrzeby.

## Są najnowsze dane dotyczące PKB w Polsce w 2022 r.
 - [https://www.money.pl/gospodarka/sa-najnowsze-dane-dotyczace-pkb-w-polsce-w-2022-r-6861059600968384a.html](https://www.money.pl/gospodarka/sa-najnowsze-dane-dotyczace-pkb-w-polsce-w-2022-r-6861059600968384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 09:01:33+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/20d3d445-015f-462b-8426-4135e78846a4" width="308" /> Produkt krajowy brutto (PKB) Polski w 2022 r. wzrósł o 4,9 proc. - wynika z szybkiego szacunku Głównego Urzędu Statystycznego. W 2021 roku wzrost wynosił 6,8 proc.

## Ważna zapowiedź rządu. Weźmie się za lombardy
 - [https://www.money.pl/gospodarka/wazna-zapowiedz-rzadu-wezmie-sie-za-lombardy-6861070460111552a.html](https://www.money.pl/gospodarka/wazna-zapowiedz-rzadu-wezmie-sie-za-lombardy-6861070460111552a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 08:07:07+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c30eee8c-b8f5-4110-b50c-1e3b8bafcfdd" width="308" /> - Przygotowujemy rozwiązania, które ucywilizują rynek lombardów, będą wprowadzały limity dotyczące kosztów, analogicznie jak w ustawie antylichwiarskiej - zapowiedział w poniedziałek wiceminister finansów Artur Soboń.

## ABW i agentka z wyrokiem. O Danielu Obajtku znów głośno
 - [https://www.money.pl/gospodarka/abw-i-agentka-z-wyrokiem-o-danielu-obajtku-znow-glosno-6861045233482400a.html](https://www.money.pl/gospodarka/abw-i-agentka-z-wyrokiem-o-danielu-obajtku-znow-glosno-6861045233482400a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:24:28+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/208e6d9a-c235-4b38-a617-46752665f6fb" width="308" /> Prezes Orlenu Daniel Obajtek został przed laty zarejestrowany jako współpracownik Agencji Bezpieczeństwa Wewnętrznego - twierdzą  informatorzy "Gazety Wyborczej". Jego oficerem prowadzącym była Beata Z., która dziś pracuje na kierowniczym stanowisku w Orlenie i która została skazana za defraudację funduszu operacyjnego ABW - przekonuje dziennik.

## Kursy walut 30.01.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-30-01-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6861043742059200a.html](https://www.money.pl/pieniadze/kursy-walut-30-01-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6861043742059200a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:18:25+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 30.01.2023. W poniedziałek za jednego dolara (USD) zapłacimy 4.33 zł. Cena jednego funta szterlinga (GBP) to 5.36 zł, a franka szwajcarskiego (CHF) 4.70 zł. Z kolei euro (EUR) możemy zakupić za 4.70 zł.

## Dłuższa praca albo bieda. Ekonomiści szczerze o wieku emerytalnym
 - [https://www.money.pl/emerytury/dluzsza-praca-albo-bieda-ekonomisci-szczerze-o-wieku-emerytalnym-6861040112614080a.html](https://www.money.pl/emerytury/dluzsza-praca-albo-bieda-ekonomisci-szczerze-o-wieku-emerytalnym-6861040112614080a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:03:38+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3118b88c-6328-4be7-a968-dcfdda7d464a" width="308" /> Wiek emerytalny musi być równy dla obu płci i wyższy niż dziś - uważa większość ekonomistów - pisze w poniedziałkowym wydaniu "Rzeczpospolita". Przekonują, że jeśli minimalny wiek emerytalny zostanie utrzymany na obecnym  poziomie, to za kilka dekad większość emerytów będzie mogła liczyć co najwyżej na świadczenie minimalne.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 30.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-30-01-2023-6861039536900800a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-30-01-2023-6861039536900800a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:01:24+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 30.01.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.7074 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 30.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-30-01-2023-6861039530511040a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-30-01-2023-6861039530511040a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:01:22+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 30.01.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.331 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 30.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-30-01-2023-6861039523818176a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-30-01-2023-6861039523818176a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:01:20+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 30.01.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3692 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 30.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-30-01-2023-6861039519517344a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-30-01-2023-6861039519517344a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 06:01:19+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 30.01.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.7029 zł.

## "Czternastki dla emerytów". Projekt jest już gotowy
 - [https://www.money.pl/emerytury/czternastki-dla-emerytow-projekt-jest-juz-gotowy-6861033727322784a.html](https://www.money.pl/emerytury/czternastki-dla-emerytow-projekt-jest-juz-gotowy-6861033727322784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 05:37:36+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f2c1d626-42d0-4001-a50a-a1da4682c8ae" width="308" /> "Czternasta emerytura" ma być zagwarantowana na stałe za sprawą ustawy - obiecali politycy Prawa i Sprawiedliwości. Wiceminister rodziny Stanisław Szwed zapowiedział, że projekt ustawy już jest gotowy. Dziennik "Fakt" poznał szczegóły i przekonuje, że "zapisy, idą wbrew temu, co Polakom wcześniej obiecywano".

## Gdzie szukać godnych pieniędzy na starość? Eksperci emerytalni zdradzają swoje sposoby
 - [https://www.money.pl/emerytury/gdzie-szukac-godnych-pieniedzy-na-starosc-eksperci-emerytalni-zdradzaja-swoje-sposoby-6860146251352768a.html](https://www.money.pl/emerytury/gdzie-szukac-godnych-pieniedzy-na-starosc-eksperci-emerytalni-zdradzaja-swoje-sposoby-6860146251352768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-30 04:53:17+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b0bc8df6-a0a2-4854-99e2-141c5a11587f" width="308" /> W 2060 r. emerytury z ZUS dla tych, którzy dziś zaczynają pracę, mogą wynieść około 1300 zł na rękę. Oszczędzanie we własnym zakresie też może okazać się niewystarczające. Ekspertów zajmujących się systemem emerytalnym zapytaliśmy, co robić, aby nie stracić szansy na godną jesień życia.
