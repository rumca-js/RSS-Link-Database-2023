# Source Sky News, Source URL:http://feeds.skynews.com/feeds/rss/world.xml, Source language: en-US

## Three emergency workers fired over response to Tyre Nichols after he was beaten by police
 - [https://news.sky.com/story/tyre-nichols-three-emergency-workers-fired-over-response-to-father-of-one-after-he-was-beaten-by-police-12799551](https://news.sky.com/story/tyre-nichols-three-emergency-workers-fired-over-response-to-father-of-one-after-he-was-beaten-by-police-12799551)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 22:48:00+00:00
 - user: None

Three emergency workers have been fired over their response to Tyre Nichols after he was beaten by police.

## Surprise attack on secret military factory in Iran was Israeli raid, US officials say
 - [https://news.sky.com/story/surprise-drone-attack-on-iran-was-work-of-israeli-intelligence-us-officials-say-12799304](https://news.sky.com/story/surprise-drone-attack-on-iran-was-work-of-israeli-intelligence-us-officials-say-12799304)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 14:32:00+00:00
 - user: None

A drone attack that caused a large explosion in the Iranian city of Isfahan was the work of Israel's intelligence agency, Mossad, according to US officials.

## Blinken calls for calm as he arrives in Tel Aviv amid rise in Israeli-Palestinian tensions
 - [https://news.sky.com/story/antony-blinken-calls-for-calm-as-he-arrives-in-tel-aviv-amid-rise-in-israeli-palestinian-tensions-12799291](https://news.sky.com/story/antony-blinken-calls-for-calm-as-he-arrives-in-tel-aviv-amid-rise-in-israeli-palestinian-tensions-12799291)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 14:07:00+00:00
 - user: None

US secretary of state Antony Blinken has called for Israel and the Palestinians to ease tensions as he arrived in Tel Aviv amid escalating violence in the region.

## US pro skier 'killed after being thrown 50 metres and buried by avalanche'
 - [https://news.sky.com/story/kyle-smaine-us-professional-skier-killed-in-japan-after-being-thrown-50-metres-and-buried-by-avalanche-12799259](https://news.sky.com/story/kyle-smaine-us-professional-skier-killed-in-japan-after-being-thrown-50-metres-and-buried-by-avalanche-12799259)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 13:16:00+00:00
 - user: None

A US professional skier has been named as one of two people killed in an avalanche in Japan.

## 'Another barrier has been broken': First New Zealand rugby player comes out as gay
 - [https://news.sky.com/story/new-zealand-rugby-legend-campbell-johnstone-comes-out-as-first-openly-gay-all-black-after-living-a-lie-12799263](https://news.sky.com/story/new-zealand-rugby-legend-campbell-johnstone-comes-out-as-first-openly-gay-all-black-after-living-a-lie-12799263)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 13:10:00+00:00
 - user: None

Former New Zealand prop Campbell Johnstone has become the first All Black to come out as gay, saying he had been "living a lie" and leading "a double life" before acknowledging his sexuality.

## Girl, 5, miraculously walks away after she is hit by car and sent crashing through window
 - [https://news.sky.com/story/girl-5-miraculously-walks-away-after-she-is-hit-by-car-and-sent-crashing-through-front-window-of-driving-school-in-brazil-12799235](https://news.sky.com/story/girl-5-miraculously-walks-away-after-she-is-hit-by-car-and-sent-crashing-through-front-window-of-driving-school-in-brazil-12799235)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 12:50:00+00:00
 - user: None

CCTV has captured the moment a drunk driver hit a motorcyclist before ploughing into a five-year-old girl - who miraculously walked away from the crash.

## Sunak believes British Army is 'top-level fighting force' despite US general's warning
 - [https://news.sky.com/story/rishi-sunak-believes-british-army-is-top-level-fighting-force-despite-us-generals-warning-12799230](https://news.sky.com/story/rishi-sunak-believes-british-army-is-top-level-fighting-force-despite-us-generals-warning-12799230)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 12:49:00+00:00
 - user: None

Rishi Sunak still believes the British Army is a "top-level fighting force" despite a US general's warning that the UK's Armed Forces are no longer regarded as elite, Downing Street has said.

## Allowing Russian athletes to compete in Olympics tells world 'terror is acceptable', says Zelenskyy
 - [https://news.sky.com/story/volodymyr-zelenskyy-says-olympic-efforts-over-russian-athletes-participating-in-paris-tells-world-terror-is-acceptable-12799208](https://news.sky.com/story/volodymyr-zelenskyy-says-olympic-efforts-over-russian-athletes-participating-in-paris-tells-world-terror-is-acceptable-12799208)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 12:18:00+00:00
 - user: None

Ukrainian President Volodymyr Zelenskyy has said efforts to allow Russian athletes to perform at next year's Olympics in France is an attempt to tell the world that "terror is somehow acceptable".

## 'Callous and cold-blooded': Eight people shot dead at birthday party in South Africa
 - [https://news.sky.com/story/south-africa-eight-people-shot-dead-in-callous-and-cold-blooded-attack-on-birthday-party-12799112](https://news.sky.com/story/south-africa-eight-people-shot-dead-in-callous-and-cold-blooded-attack-on-birthday-party-12799112)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 10:23:00+00:00
 - user: None

Eight people have been shot and killed in an attack by two people on a birthday party in South Africa.

## Flight to nowhere: New Zealand-bound plane flies 13 hours only to land where it took off
 - [https://news.sky.com/story/new-zealand-bound-plane-flies-13-hours-only-to-land-back-in-dubai-after-auckland-floods-close-airport-12799064](https://news.sky.com/story/new-zealand-bound-plane-flies-13-hours-only-to-land-back-in-dubai-after-auckland-floods-close-airport-12799064)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 09:29:00+00:00
 - user: None

New Zealand-bound passengers endured a 13-hour flight to nowhere after the plane they were on was forced to return to Dubai when Auckland Airport closed due to flooding.&#160;

## Suicide bomber kills at least 25 after targeting mosque in Pakistan
 - [https://news.sky.com/story/suicide-bomber-kills-at-least-17-after-targeting-mosque-in-pakistan-12799052](https://news.sky.com/story/suicide-bomber-kills-at-least-17-after-targeting-mosque-in-pakistan-12799052)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 09:12:00+00:00
 - user: None

At least 25 people have been killed and 96 injured after a suicide bomber struck a mosque in Pakistan.

## Mining giant apologises for losing radioactive capsule as authorities scramble to find it
 - [https://news.sky.com/story/rio-tinto-apologises-for-losing-radioactive-capsule-as-authorities-scramble-to-find-it-12798979](https://news.sky.com/story/rio-tinto-apologises-for-losing-radioactive-capsule-as-authorities-scramble-to-find-it-12798979)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-30 07:41:00+00:00
 - user: None

Rio Tinto has apologised for losing a highly radioactive capsule in the Australian outback as authorities scramble to find it.
