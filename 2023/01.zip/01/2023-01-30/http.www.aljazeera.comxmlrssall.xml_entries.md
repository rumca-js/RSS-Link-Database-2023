# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## Bangladesh to get $4.7bn IMF package
 - [https://www.aljazeera.com/economy/2023/1/30/bangladesh-to-get-4-7bn-imf-package](https://www.aljazeera.com/economy/2023/1/30/bangladesh-to-get-4-7bn-imf-package)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 23:18:57+00:00
 - user: None

The funding comes under a new programme which aims to help vulnerable middle-income countries and island states.

## US not interested in pressing Israel amid violence: Experts
 - [https://www.aljazeera.com/news/2023/1/30/us-not-interested-in-pressing-israel-amid-violence-experts](https://www.aljazeera.com/news/2023/1/30/us-not-interested-in-pressing-israel-amid-violence-experts)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 23:02:03+00:00
 - user: None

US will continue to prop up &#039;status quo&#039;, analysts say, as Blinken visits region following spate of deadly attacks.

## Brazil’s ex-President Bolsonaro seeks US tourist visa: Lawyer
 - [https://www.aljazeera.com/news/2023/1/30/brazils-ex-president-bolsonaro-seeks-us-tourist-visa-lawyer](https://www.aljazeera.com/news/2023/1/30/brazils-ex-president-bolsonaro-seeks-us-tourist-visa-lawyer)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 22:05:35+00:00
 - user: None

Application for six-month US visa comes as Jair Bolsonaro faces accusations he helped incite riot in Brazil&#039;s capital.

## Ukraine’s Zelenskyy says Russia’s ‘big revenge’ has begun
 - [https://www.aljazeera.com/news/2023/1/30/ukraines-zelenskyy-says-russias-big-revenge-has-begun](https://www.aljazeera.com/news/2023/1/30/ukraines-zelenskyy-says-russias-big-revenge-has-begun)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 21:34:44+00:00
 - user: None

President Zelenskyy had warned for weeks that Moscow sought to step up assaults after months of virtual stalemate.

## Was India’s Hockey World Cup failure a missed opportunity?
 - [https://www.aljazeera.com/sports/2023/1/30/hockey-world-cup-indias-lost-moment-to-revive-a-beloved-sport](https://www.aljazeera.com/sports/2023/1/30/hockey-world-cup-indias-lost-moment-to-revive-a-beloved-sport)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 21:06:36+00:00
 - user: None

The national field hockey team finished tied for ninth place at a home World Cup. What went wrong?

## Will the Ukraine war become a wider European conflict?
 - [https://www.aljazeera.com/program/inside-story/2023/1/30/will-ukraine-war-become-a-wider-european](https://www.aljazeera.com/program/inside-story/2023/1/30/will-ukraine-war-become-a-wider-european)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 20:52:06+00:00
 - user: None

Kyiv calls for fighter jets after Germany agrees to allow the deployment of Leopard 2 tanks.

## Germany pledges millions to help Brazil protect Amazon rainforest
 - [https://www.aljazeera.com/news/2023/1/30/germany-pledges-millions-to-help-brazil-protect-amazon-rainforest](https://www.aljazeera.com/news/2023/1/30/germany-pledges-millions-to-help-brazil-protect-amazon-rainforest)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 20:02:53+00:00
 - user: None

German minister says Brazil&#039;s new government offers &#039;great chance&#039; to protect rainforest after widespread destruction.

## Turkey opposition vows to cut presidential powers if it wins vote
 - [https://www.aljazeera.com/news/2023/1/30/turkey-opposition-vows-to-strengthen-democracy-ahead-of-may-vote](https://www.aljazeera.com/news/2023/1/30/turkey-opposition-vows-to-strengthen-democracy-ahead-of-may-vote)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 19:57:52+00:00
 - user: None

Alliance of opposition parties presents 240-page programme ahead of presidential and parliamentary elections.

## Tyre Nichols case renews calls for changes to US policing
 - [https://www.aljazeera.com/news/2023/1/30/tyre-nichols-case-renews-calls-for-changes-to-us-policing](https://www.aljazeera.com/news/2023/1/30/tyre-nichols-case-renews-calls-for-changes-to-us-policing)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 18:25:11+00:00
 - user: None

Structural changes are desperately needed, advocates say, as the US deals with another case of fatal police violence.

## India’s Adani firms lose $65bn in value
 - [https://www.aljazeera.com/economy/2023/1/30/indias-adani-firms-lose-65bn-in-value](https://www.aljazeera.com/economy/2023/1/30/indias-adani-firms-lose-65bn-in-value)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 18:23:37+00:00
 - user: None

Led by Asia&#039;s richest man Gautam Adani, the group has locked horns with short seller Hindenburg Research.

## Blinken urges calm, reaffirms ‘ironclad’ US support for Israel
 - [https://www.aljazeera.com/news/2023/1/30/blinken-urges-calm-reaffirms-us-ironclad-support-for-israel](https://www.aljazeera.com/news/2023/1/30/blinken-urges-calm-reaffirms-us-ironclad-support-for-israel)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 17:44:11+00:00
 - user: None

Top US diplomat pays tribute to Israeli victims of attack in Jerusalem without mentioning Palestinians killed by Israel.

## How Putin made himself Maidan-proof by waging war on Ukraine
 - [https://www.aljazeera.com/opinions/2023/1/30/how-putin-made-himself-maidan-proof-by-waging-war-on-ukraine](https://www.aljazeera.com/opinions/2023/1/30/how-putin-made-himself-maidan-proof-by-waging-war-on-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 17:15:19+00:00
 - user: None

Since 2014, the conflict in Ukraine has been tightly linked to Putin&#039;s fear of an opposition-led challenge to his rule.

## World ‘dangerously unprepared’ for next pandemic, Red Cross warns
 - [https://www.aljazeera.com/news/2023/1/30/world-dangerously-unprepared-for-next-pandemic-ifrc](https://www.aljazeera.com/news/2023/1/30/world-dangerously-unprepared-for-next-pandemic-ifrc)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 16:55:08+00:00
 - user: None

World&#039;s largest humanitarian network says strong preparedness systems &#039;severely lacking&#039; despite three years of COVID.

## Gandhi’s 150-day march is over. But will it revive Congress?
 - [https://www.aljazeera.com/news/2023/1/30/rahul-gandhi-150-day-march-is-over-but-will-it-revive-congress](https://www.aljazeera.com/news/2023/1/30/rahul-gandhi-150-day-march-is-over-but-will-it-revive-congress)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 15:44:17+00:00
 - user: None

Leader of India&#039;s main opposition party concludes cross-country &#039;unity&#039; march in Kashmir.

## Croatian president slams Western arms to Ukraine
 - [https://www.aljazeera.com/news/2023/1/30/croatian-president-slams-western-arms-to-ukraine](https://www.aljazeera.com/news/2023/1/30/croatian-president-slams-western-arms-to-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 15:40:54+00:00
 - user: None

President Zoran Milanovic has repeatedly criticised Western policies towards Russia and the Balkans.

## UK cost-of-living crisis pushes mothers to the brink
 - [https://www.aljazeera.com/gallery/2023/1/30/uk-cost-of-living-crisis-pushes-mothers-to-the-brink](https://www.aljazeera.com/gallery/2023/1/30/uk-cost-of-living-crisis-pushes-mothers-to-the-brink)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 14:18:22+00:00
 - user: None

In the midst of the biggest surge in prices in decades, food banks have become a feature of modern British life.

## Russian troops have left this Ukrainian village, but fear remains
 - [https://www.aljazeera.com/gallery/2023/1/30/russians-gone-from-ukraine-village-fear-and-hardship-remain](https://www.aljazeera.com/gallery/2023/1/30/russians-gone-from-ukraine-village-fear-and-hardship-remain)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 13:45:37+00:00
 - user: None

Liberation has not diminished the hardship for Kalynivske residents, both those returning and the ones who never left.

## Dozens killed in bombing at mosque in Pakistan’s Peshawar
 - [https://www.aljazeera.com/gallery/2023/1/30/photos-dozens-killed-in-bombing-at-mosque-in-pakistans-peshawar](https://www.aljazeera.com/gallery/2023/1/30/photos-dozens-killed-in-bombing-at-mosque-in-pakistans-peshawar)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 13:00:28+00:00
 - user: None

A blast at a mosque inside the police headquarters in Peshawar killed at least 32 worshippers and wounded 150 more.

## Conflict survivors to meet Pope Francis on his DR Congo trip
 - [https://www.aljazeera.com/news/2023/1/30/survivors-of-conflict-to-meet-pope-francis-in-congo](https://www.aljazeera.com/news/2023/1/30/survivors-of-conflict-to-meet-pope-francis-in-congo)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 12:17:53+00:00
 - user: None

Pope’s long-awaited visit to DRC and South Sudan where two of the world’s most neglected crises are ongoing.

## Jenin refugee camp residents defiant after deadly Israeli assault
 - [https://www.aljazeera.com/news/2023/1/30/jenin-refugee-camp-defiant-despite-deadly-israeli-assault](https://www.aljazeera.com/news/2023/1/30/jenin-refugee-camp-defiant-despite-deadly-israeli-assault)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 11:52:17+00:00
 - user: None

Palestinians pledge to &#039;keep fighting&#039; illegal Israeli occupation following largest military raid in Jenin since 2002.

## Iran summons Ukraine’s envoy over drone attack comments
 - [https://www.aljazeera.com/news/2023/1/30/iran-summons-ukraine-envoy-over-drone-attack-comments](https://www.aljazeera.com/news/2023/1/30/iran-summons-ukraine-envoy-over-drone-attack-comments)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 11:50:06+00:00
 - user: None

Move comes after Zelenskyy adviser appeared to directly link Ukraine with attack on military facility in central Iran.

## Israeli forces kill Palestinian man in Hebron as tensions spiral
 - [https://www.aljazeera.com/news/2023/1/30/israeli-forces-kill-palestinian-in-hebron-as-tensions-spiral](https://www.aljazeera.com/news/2023/1/30/israeli-forces-kill-palestinian-in-hebron-as-tensions-spiral)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 10:54:48+00:00
 - user: None

Naseem Abu Fouda, 26, is the 35th Palestinian to be killed by Israel so far in January 2023.

## Can Bola Tinubu, Nigeria’s ailing kingmaker, win the presidency?
 - [https://www.aljazeera.com/features/2023/1/30/tinubu-nigerias-ailing-kingmaker-aims-for-presidency-in-2023](https://www.aljazeera.com/features/2023/1/30/tinubu-nigerias-ailing-kingmaker-aims-for-presidency-in-2023)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 10:23:45+00:00
 - user: None

Tinubu has a formidable political machinery &amp; is credited with Lagos&#039;s successes, but can he become Nigerian president?

## UK’s Boris Johnson says Putin threatened him with missile attack
 - [https://www.aljazeera.com/news/2023/1/30/uks-johnson-says-putin-threatened-him-with-missile-strike](https://www.aljazeera.com/news/2023/1/30/uks-johnson-says-putin-threatened-him-with-missile-strike)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 10:18:34+00:00
 - user: None

Former British PM says Russian president threatened him during a phone call in the run up to Ukraine invasion.

## Another uprising is in the making in Tunisia
 - [https://www.aljazeera.com/opinions/2023/1/30/tunisias-democratic-backsliding-its-the-economy-stupid](https://www.aljazeera.com/opinions/2023/1/30/tunisias-democratic-backsliding-its-the-economy-stupid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 10:04:20+00:00
 - user: None

President Saeid&#039;s decision to turn to the IMF to save Tunisia&#039;s economy will sound the death knell for his regime.

## In Ivory Coast, people with leprosy fight social exclusion
 - [https://www.aljazeera.com/gallery/2023/1/30/ivory-coast-leprosy-sufferers-fight-social-exclusion](https://www.aljazeera.com/gallery/2023/1/30/ivory-coast-leprosy-sufferers-fight-social-exclusion)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 09:27:58+00:00
 - user: None

In Ivory Coast, people living with leprosy say they often face social exclusion. Some now live together in a commune.

## Apocalypse in Palestine: The rise of Israeli fanaticism
 - [https://www.aljazeera.com/opinions/2023/1/30/apocalypse-in-palestine-the-rise-of-israeli-fanaticism](https://www.aljazeera.com/opinions/2023/1/30/apocalypse-in-palestine-the-rise-of-israeli-fanaticism)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 09:24:15+00:00
 - user: None

Israel’s fanatics do not want a democratic state, they want a religious kingdom.

## Dozens injured in blast at busy mosque in Pakistan’s Peshawar
 - [https://www.aljazeera.com/news/2023/1/30/peshawar-pakistan-mosque-explosion-casualties](https://www.aljazeera.com/news/2023/1/30/peshawar-pakistan-mosque-explosion-casualties)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 09:12:37+00:00
 - user: None

Officials say an explosion at a mosque in Peshawar, northwestern Pakistan, has caused multiple casualties.

## Cyclone in Madagascar kills dozens, displaces tens of thousands
 - [https://www.aljazeera.com/news/2023/1/30/cyclone-in-madagascar-kills-dozens-displaces-tens-of-thousands](https://www.aljazeera.com/news/2023/1/30/cyclone-in-madagascar-kills-dozens-displaces-tens-of-thousands)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 08:19:50+00:00
 - user: None

At least 25 confirmed dead and more than 37,000 displaced by Cyclone Cheneso, authorities say.

## Gunmen kill eight people at birthday party in South Africa
 - [https://www.aljazeera.com/news/2023/1/30/gunmen-kill-several-people-at-birthday-party-in-south-africa](https://www.aljazeera.com/news/2023/1/30/gunmen-kill-several-people-at-birthday-party-in-south-africa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 07:36:41+00:00
 - user: None

Police say three others were wounded in southern port city of Gqeberha and a manhunt for the perpetrators is under way.

## Russia-Ukraine war: List of key events, day 341
 - [https://www.aljazeera.com/news/2023/1/30/russia-ukraine-war-list-of-key-events-day-341](https://www.aljazeera.com/news/2023/1/30/russia-ukraine-war-list-of-key-events-day-341)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 07:12:28+00:00
 - user: None

As the Russia-Ukraine war enters its 341st day, we take a look at the main developments.

## NATO chief asks S Korea to ‘step up’ military support for Ukraine
 - [https://www.aljazeera.com/news/2023/1/30/nato-chief-asks-s-korea-to-step-up-military-support-for-ukraine](https://www.aljazeera.com/news/2023/1/30/nato-chief-asks-s-korea-to-step-up-military-support-for-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 05:03:27+00:00
 - user: None

Jens Stoltenberg suggests Seoul reconsider its policy of barring weapons exports to countries in conflict.

## Rio Tinto apologises as search for radioactive capsule continues
 - [https://www.aljazeera.com/news/2023/1/30/rio-tinto-apologises-as-search-for-radioactive-capsule-continues](https://www.aljazeera.com/news/2023/1/30/rio-tinto-apologises-as-search-for-radioactive-capsule-continues)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 03:26:02+00:00
 - user: None

A radiation alert is in force for parts of Western Australia after a tiny capsule containing Caesium-137 was lost.

## Missile hits Kharkiv apartment block, killing at least one
 - [https://www.aljazeera.com/news/2023/1/30/missile-hits-kharkiv-apartment-block-killing-at-least-one](https://www.aljazeera.com/news/2023/1/30/missile-hits-kharkiv-apartment-block-killing-at-least-one)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 00:47:18+00:00
 - user: None

Three people were injured in the raid, and rescue teams are searching for an elderly woman thought to be trapped.

## Erdogan says Turkey may accept Finland in NATO, but not Sweden
 - [https://www.aljazeera.com/news/2023/1/30/erdogan-says-turkey-may-accept-finland-in-nato-but-not-sweden](https://www.aljazeera.com/news/2023/1/30/erdogan-says-turkey-may-accept-finland-in-nato-but-not-sweden)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-30 00:33:03+00:00
 - user: None

Turkey and Hungary are the only members of the 30-nation alliance yet to approve the Nordic nations&#039; application.
