# Source The Hill, Source URL:https://thehill.com/news/feed/, Source language: en-US

## Biden administration plans to end COVID public health emergency in May
 - [https://thehill.com/policy/healthcare/3836604-biden-administration-plans-to-end-covid-public-health-emergency-in-may/](https://thehill.com/policy/healthcare/3836604-biden-administration-plans-to-end-covid-public-health-emergency-in-may/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 23:04:32+00:00
 - user: None

The Biden administration on Monday announced that the COVID-19 public health emergency, which has been in place since January 2020, is set to end on May 11. "The COVID-19 national emergency and public health emergency (PHE) were declared by the Trump Administration in 2020.  They are currently set to expire on March 1 and April...

## Nearly 53,000 pounds of charcuterie meat recalled over listeria concerns
 - [https://thehill.com/policy/healthcare/3836529-nearly-53000-pounds-of-charcuterie-meat-recalled-over-listeria-concerns/](https://thehill.com/policy/healthcare/3836529-nearly-53000-pounds-of-charcuterie-meat-recalled-over-listeria-concerns/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:50:16+00:00
 - user: None

Check your meat!

## CEO apologizes after quoting MLK in layoff announcement
 - [https://thehill.com/business-a-lobbying/business-lobbying/3836602-ceo-apologizes-after-quoting-mlk-in-layoff-announcement/](https://thehill.com/business-a-lobbying/business-lobbying/3836602-ceo-apologizes-after-quoting-mlk-in-layoff-announcement/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:50:14+00:00
 - user: None

Roughly 7% of the company's workforce is impacted by the layoffs.

## Haley Stevens passes on bid for Michigan Senate seat
 - [https://thehill.com/homenews/campaign/3836565-haley-stevens-passes-on-bid-for-michigan-senate-seat/](https://thehill.com/homenews/campaign/3836565-haley-stevens-passes-on-bid-for-michigan-senate-seat/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:44:36+00:00
 - user: None

Rep. Haley Stevens (D-Mich.) announced Monday that she will not be seeking election to the Senate in 2024, saying that she can "best serve" her constituents as a House lawmaker. "After deep consideration, I have decided that I can best serve Michigan’s working families, manufacturers, students, and small businesses in my current role. I will...

## The Biden team is digging in its feet with spending and border
 - [https://thehill.com/opinion/congress-blog/3836518-the-biden-team-is-digging-in-its-feet-with-spending-and-border/](https://thehill.com/opinion/congress-blog/3836518-the-biden-team-is-digging-in-its-feet-with-spending-and-border/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:30:00+00:00
 - user: None

Gazing into the vacant eyes of President Biden and the penetrating malevolence in those of Homeland Security Secretary Alejandro Mayorkas, you sense that the debt ceiling issue and border crisis will bring further attacks on Americans. You might say that President Biden and Mayorkas are a potent duo of destruction. I hope that in the...

## Texas congressman looks to honor American slaves in new legislation
 - [https://thehill.com/blogs/blog-briefing-room/news/legislation/3836572-texas-congressman-looks-to-honor-american-slaves-in-new-legislation/](https://thehill.com/blogs/blog-briefing-room/news/legislation/3836572-texas-congressman-looks-to-honor-american-slaves-in-new-legislation/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:26:15+00:00
 - user: None

Rep. Al Green (D-Texas) has introduced a slate of legislation that seeks to honor American slaves and their descendants.   “At some point, they ought to have their descendants benefit from the injustice with justice, in the form of first making sure that their ancestors are respected for what they've done,” Green told The Hill. “I...

## Bed Bath & Beyond announces 87 more store closures
 - [https://thehill.com/homenews/nexstar_media_wire/3836476-bed-bath-beyond-announces-87-more-store-closures/](https://thehill.com/homenews/nexstar_media_wire/3836476-bed-bath-beyond-announces-87-more-store-closures/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:20:20+00:00
 - user: None

Bed Bath &#038; Beyond told Nexstar Monday that it will be closing 87 additional stores, an announcement that comes days after the beleaguered home goods chain said it had defaulted on its loans.

## RNC calls on candidates to 'go on offense' on anti-abortion laws in 2024
 - [https://thehill.com/policy/healthcare/3836567-rnc-calls-on-candidates-to-double-down-on-anti-abortion-laws-in-2024/](https://thehill.com/policy/healthcare/3836567-rnc-calls-on-candidates-to-double-down-on-anti-abortion-laws-in-2024/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:19:54+00:00
 - user: None

The Republican National Committee is doubling down on its anti-abortion stance by urging all GOP candidates and lawmakers to "go on offense" in the 2024 election cycle and pass the strictest anti-abortion legislation possible. In a resolution passed Friday during its winter meeting, the committee called on Republicans to pass laws "that acknowledge the beating...

## Ukraine says Poland sending 'positive signals' about providing F-16 fighter jets
 - [https://thehill.com/homenews/3836456-ukraine-says-poland-sending-positive-signals-about-providing-f-16-fighter-jets/](https://thehill.com/homenews/3836456-ukraine-says-poland-sending-positive-signals-about-providing-f-16-fighter-jets/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:15:17+00:00
 - user: None

A top Ukrainian official on Monday said Poland is sending "positive signals" about sending F-16 fighter jets to Kyiv as the next big debate over Western security assistance for Ukraine heats up. Andriy Yermak, the head of Ukraine's presidential office, wrote on Telegram that Poland is ready to "pass them on to us in coordination...

## Trump sues journalist Bob Woodward
 - [https://thehill.com/regulation/court-battles/3836526-trump-sues-journalist-bob-woodward/](https://thehill.com/regulation/court-battles/3836526-trump-sues-journalist-bob-woodward/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:15:06+00:00
 - user: None

Former President Trump is suing journalist Bob Woodward over interview recordings that Trump alleges he didn’t agree could be included in an audiobook.  Trump concedes that he consented to Woodward recording their conversations for the purpose of a book, and gave 19 interviews to the veteran journalist in 2019 and 2020, which Woodward included in...

## Are EPA programs creating more barriers for polluted communities?
 - [https://thehill.com/opinion/energy-environment/3836466-are-epa-programs-creating-more-barriers-for-polluted-communities/](https://thehill.com/opinion/energy-environment/3836466-are-epa-programs-creating-more-barriers-for-polluted-communities/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 22:00:00+00:00
 - user: None

Accountability and equitable funding practices are not mutually exclusive.

## Biden says US won't provide Ukraine with F-16s
 - [https://thehill.com/homenews/administration/3836519-biden-says-us-wont-provide-ukraine-with-f-16s/](https://thehill.com/homenews/administration/3836519-biden-says-us-wont-provide-ukraine-with-f-16s/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:56:02+00:00
 - user: None

President Biden responded "no" when asked on Monday if the United States will provide F-16 fighter jets to Ukraine. Biden last week announced a decision to send 31 Abrams battle tanks to the country. Shortly after that announcement, Yuriy Sak, an adviser to Ukraine’s Defense secretary, told The Hill that he was optimistic about receiving Western...

## Judge expands pause of New Jersey gun law that bans firearms in casinos, parks and bars
 - [https://thehill.com/regulation/court-battles/3836486-judge-expands-pause-of-new-jersey-gun-law-that-bans-firearms-in-casinos-parks-and-bars/](https://thehill.com/regulation/court-battles/3836486-judge-expands-pause-of-new-jersey-gun-law-that-bans-firearms-in-casinos-parks-and-bars/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:53:06+00:00
 - user: None

A federal judge on Monday temporarily blocked New Jersey’s firearm bans at casinos, parks and beaches, the latest setback for the state’s new gun law. The ruling by U.S. District Judge Renée Marie Bumb, a George W. Bush appointee, augments her opinion earlier this month temporarily blocking enforcement at other so-called “sensitive places” where state...

## 100,000 chickens die in fire at Connecticut egg farm
 - [https://thehill.com/homenews/state-watch/3836445-100000-chickens-die-in-fire-at-connecticut-egg-farm/](https://thehill.com/homenews/state-watch/3836445-100000-chickens-die-in-fire-at-connecticut-egg-farm/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:48:42+00:00
 - user: None

About 100,000 chickens died in a fire over the weekend at a Connecticut farm that is one of the top five egg producers in the country. Officials from the state Department of Agriculture confirmed Monday that an estimated 100,000 hens were killed in a fire at the Hillandale Farms property in Bozrah, Conn., on Saturday,...

## Missouri rep trolls Bengals players, Cincinnati mayor after Chiefs win
 - [https://thehill.com/homenews/house/3836457-missouri-rep-trolls-bengals-players-cincinnati-mayor-after-chiefs-win/](https://thehill.com/homenews/house/3836457-missouri-rep-trolls-bengals-players-cincinnati-mayor-after-chiefs-win/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:43:11+00:00
 - user: None

Rep. Mark Alford (R-Mo.) took time on Monday to troll a couple of Cincinnati Bengals players and the city’s mayor after the Kansas City Chiefs’s victory Sunday in the AFC Championship game.  “Today I rise to honor my Kansas City Chiefs for their AFC championship and their berth in Super Bowl LVII,” the first-term lawmaker...

## Watchdog group says White House science integrity measure amounts to a 'gag rule'
 - [https://thehill.com/policy/energy-environment/3836495-watchdog-group-says-white-house-science-integrity-measure-amounts-to-a-gag-rule/](https://thehill.com/policy/energy-environment/3836495-watchdog-group-says-white-house-science-integrity-measure-amounts-to-a-gag-rule/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:40:26+00:00
 - user: None

A whistleblower and advocacy group is raising concerns over what they call a “gag rule” against federal scientists that was included in White House scientific integrity guidelines.  Earlier this month, the White House Office of Science and Technology Policy (OSTP) issued a model scientific integrity policy as part of a larger framework on the issue...

## The horrifying shift to lone gunman terrorism in Israel
 - [https://thehill.com/opinion/international/3835960-the-horrifying-shift-to-lone-gunman-terrorism-in-israel/](https://thehill.com/opinion/international/3835960-the-horrifying-shift-to-lone-gunman-terrorism-in-israel/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 21:00:00+00:00
 - user: None

The killers do not fit the usual profiles.

## Lawsuit accuses Marilyn Manson of sexually assaulting underage girl multiple times
 - [https://thehill.com/blogs/in-the-know/3836309-lawsuit-accuses-marilyn-manson-of-sexually-assaulting-underage-girl-multiple-times/](https://thehill.com/blogs/in-the-know/3836309-lawsuit-accuses-marilyn-manson-of-sexually-assaulting-underage-girl-multiple-times/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:59:41+00:00
 - user: None

Musician Marilyn Manson is facing more allegations of sexual misconduct, accused in a lawsuit filed on Monday of sexually assaulting an underage girl multiple times in the 1990s. The woman in the lawsuit, who is filing under the name Jane Doe, says in her complaint that Manson started to "target" her in 1995 when she...

## Biden touts fix to Baltimore rail tunnel that he's traveled through 'a thousand times'
 - [https://thehill.com/homenews/administration/3836418-biden-touts-fix-to-baltimore-rail-tunnel-that-hes-traveled-through-a-thousand-times/](https://thehill.com/homenews/administration/3836418-biden-touts-fix-to-baltimore-rail-tunnel-that-hes-traveled-through-a-thousand-times/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:56:54+00:00
 - user: None

Longtime Amtrak rider President Biden returned Monday to a spot he’s been in hundreds of times: the Baltimore and Potomac Tunnel. This time, he arrived at the East Coast’s worst rail congestion point as a messenger of good news rather than a passenger. “I’ve been through this tunnel a thousand times. When folks talk about...

## McCarthy to meet with King Abdullah II of Jordan on Tuesday
 - [https://thehill.com/homenews/house/3836409-mccarthy-to-meet-with-king-abdullah-ii-of-jordan-on-tuesday/](https://thehill.com/homenews/house/3836409-mccarthy-to-meet-with-king-abdullah-ii-of-jordan-on-tuesday/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:50:10+00:00
 - user: None

Speaker Kevin McCarthy (R-Calif.) is scheduled to meet with King Abdullah II of Jordan at the Capitol on Tuesday, marking the first visit from a foreign leader during the California Republican's Speakership. Abdullah’s trip to Capitol Hill comes as tensions ratchet up in the Middle East between Israel and Palestine. An Israeli raid on a...

## New Marist poll: 62 percent say state of union is not strong
 - [https://thehill.com/blogs/blog-briefing-room/3836410-new-marist-poll-62-percent-say-state-of-union-is-not-strong/](https://thehill.com/blogs/blog-briefing-room/3836410-new-marist-poll-62-percent-say-state-of-union-is-not-strong/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:39:09+00:00
 - user: None

Ahead of President Biden's State of the Union address next week, a new poll finds that a majority of Americans do not think the state of the country is strong. More than 60 percent of people think the state of the union is not strong, according to a new Marist poll. The negative rating comes...

## Former Twitter execs to testify about Hunter Biden laptop story before House panel
 - [https://thehill.com/homenews/house/3836361-former-twitter-execs-to-testify-about-hunter-biden-laptop-story-before-house-panel/](https://thehill.com/homenews/house/3836361-former-twitter-execs-to-testify-about-hunter-biden-laptop-story-before-house-panel/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:15:17+00:00
 - user: None

Former Twitter executives are set to testify next month before the House Oversight and Accountability Committee about the social media platform’s decisions surrounding a 2020 news story on President Biden’s son Hunter Biden. Republicans have argued that Twitter suppressed circulation of a 2020 New York Post article about Hunter Biden in the weeks before the...

## China urges McCarthy not to visit Taiwan
 - [https://thehill.com/homenews/house/3836382-china-urges-mccarthy-not-to-visit-taiwan/](https://thehill.com/homenews/house/3836382-china-urges-mccarthy-not-to-visit-taiwan/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 20:09:22+00:00
 - user: None

China is warning House Speaker Kevin McCarthy (R-Calif.) against visiting Taiwan after reports that the GOP leader is planning a trip later this year to the island, which is a flashpoint in the rising tensions between Beijing and Washington. “We urge certain individuals in the U.S. to earnestly abide by the one-China principle,” Foreign Ministry...

## Davis: Time to correct the record again — Hillary Clinton did not have a single email marked ‘classified’
 - [https://thehill.com/opinion/3836347-davis-time-to-correct-the-record-again-hillary-clinton-did-not-have-a-single-email-marked-classified/](https://thehill.com/opinion/3836347-davis-time-to-correct-the-record-again-hillary-clinton-did-not-have-a-single-email-marked-classified/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:45:00+00:00
 - user: None

There has been substantial media coverage of President Biden and former Vice President Pence both removing marked classified documents outside the White House after they left the vice presidency (and, in the case of Biden, also including after he was a U.S. senator). Both insist they did so inadvertently.   Of course, the word “inadvertent” does not apply to former President Trump’s behavior. As we now know from Mr. Trump’s own admission, he knew documents he took to Mar-a-Lago were classified...

## COVID among top 10 causes of death in children in US: study
 - [https://thehill.com/policy/healthcare/3836326-covid-among-top-10-causes-of-death-in-children-in-us-study/](https://thehill.com/policy/healthcare/3836326-covid-among-top-10-causes-of-death-in-children-in-us-study/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:40:40+00:00
 - user: None

COVID-19 was the eighth leading cause of death among U.S. children and young people between August 2021 and July 2022, new research shows.  Throughout the same period, COVID-19 was the top cause of death from an infectious or respiratory disease among children, while deaths were the highest in this age group during the Delta and...

## Biden administration unveils new green card design with eye on enhanced security
 - [https://thehill.com/homenews/administration/3836324-biden-administration-unveils-new-green-card-design-with-eye-on-enhanced-security/](https://thehill.com/homenews/administration/3836324-biden-administration-unveils-new-green-card-design-with-eye-on-enhanced-security/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:39:53+00:00
 - user: None

The Biden administration released a new design for Permanent Resident Cards, also known as green cards, and Employment Authorization Documents (EADs), adding a series of new security measures for the immigration documents. The new cards will be issued by U.S. Citizenship and Immigration Services (USCIS) as of Monday; older cards will remain valid until their...

## 18 million people to be hit by ice storms, 'hazardous winter weather' this week, forecasters predict
 - [https://thehill.com/homenews/nexstar_media_wire/3836256-18-million-people-to-be-hit-by-ice-storms-hazardous-winter-weather-this-week-forecasters-predict/](https://thehill.com/homenews/nexstar_media_wire/3836256-18-million-people-to-be-hit-by-ice-storms-hazardous-winter-weather-this-week-forecasters-predict/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:32:10+00:00
 - user: None

A wide swath of America is bracing for ice, snow and other winter weather dangers to blast through this week.

## Firefighters' union mounts legal push against 'forever chemicals': 'It stops now'
 - [https://thehill.com/policy/equilibrium-sustainability/3836215-firefighters-union-mounts-legal-push-against-forever-chemicals-it-stops-now/](https://thehill.com/policy/equilibrium-sustainability/3836215-firefighters-union-mounts-legal-push-against-forever-chemicals-it-stops-now/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:30:00+00:00
 - user: None

The International Association of Fire Fighters called on Monday for the elimination of protective gear that contains “forever chemicals,” saying swift regulatory action is needed to address the toxic substances.  The union — which has more than 333,000 members — announced that it has retained the services of three nationally recognized law firms to pursue these goals,...

## Quantum computing is coming — and there’s more the Biden administration can do to prepare
 - [https://thehill.com/opinion/cybersecurity/3836271-quantum-computing-is-coming-and-theres-more-the-biden-administration-can-do-to-prepare/](https://thehill.com/opinion/cybersecurity/3836271-quantum-computing-is-coming-and-theres-more-the-biden-administration-can-do-to-prepare/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:30:00+00:00
 - user: None

There are countless lessons to be learned if the federal government embraces a quantum-security guinea pig role.

## 99 percent of US coal plants are more expensive than new renewables would be: report
 - [https://thehill.com/policy/energy-environment/3836301-99-percent-of-u-s-coal-plants-are-more-expensive-than-new-renewables-would-be-report/](https://thehill.com/policy/energy-environment/3836301-99-percent-of-u-s-coal-plants-are-more-expensive-than-new-renewables-would-be-report/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:21:10+00:00
 - user: None

All of the nation's coal-fired power plants but one are less cost-effective to operate than constructing new solar or wind facilities in the United States, according to a study published Monday by the firm Energy Innovation. Analysts compared operating costs at the 210 coal plants in the continental U.S. in 2021 to the estimated costs...

## Southwest hires former congressman as lobbyist amid scrutiny
 - [https://thehill.com/policy/transportation/3836292-southwest-hires-former-congressman-as-lobbyist-amid-scrutiny/](https://thehill.com/policy/transportation/3836292-southwest-hires-former-congressman-as-lobbyist-amid-scrutiny/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:12:57+00:00
 - user: None

Southwest Airlines hired a lawmaker-turned-lobbyist amid investigations into the carrier’s catastrophic system meltdown over the holidays.  Southwest contracted with former Rep. Jerry Costello (D-Ill.), a for-hire lobbyist who chaired the House Transportation and Infrastructure Aviation Subcommittee during his time in Congress, according to a congressional filing.  The airline is dispatching Costello to lobby on the...

## Manhattan prosecutor presenting evidence in Trump Stormy Daniels hush money case to grand jury: report
 - [https://thehill.com/regulation/court-battles/3836264-manhattan-prosecutor-presenting-evidence-in-trump-stormy-daniels-hush-money-case-to-grand-jury-report/](https://thehill.com/regulation/court-battles/3836264-manhattan-prosecutor-presenting-evidence-in-trump-stormy-daniels-hush-money-case-to-grand-jury-report/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:12:31+00:00
 - user: None

The Manhattan district attorney is escalating his criminal investigation into former President Trump by showing a grand jury evidence about hush money paid to an adult-film star just before the 2016 presidential election, The New York Times reported. The Times reported that Manhattan District Attorney Alvin Bragg (D) will begin presenting the evidence on Monday...

## Two Black quarterbacks to face off in Super Bowl for first time
 - [https://thehill.com/changing-america/respect/equality/3836259-two-black-quarterbacks-to-face-off-in-super-bowl-for-first-time/](https://thehill.com/changing-america/respect/equality/3836259-two-black-quarterbacks-to-face-off-in-super-bowl-for-first-time/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:04:36+00:00
 - user: None

Story at a glance For the first time in Super Bowl history, two Black starting quarterbacks will compete against each other. Patrick Mahomes of the Kansas City Chiefs and Jalen Hurts of the Philadelphia Eagles will face off on Sunday, February 12 at the State Farm Stadium in Glendale, Ariz.   Mahomes led the Chiefs...

## Getting vaccinated at pharmacies works: It could soon disappear
 - [https://thehill.com/opinion/healthcare/3835860-getting-vaccinated-at-pharmacies-works-it-could-soon-disappear/](https://thehill.com/opinion/healthcare/3835860-getting-vaccinated-at-pharmacies-works-it-could-soon-disappear/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 19:00:00+00:00
 - user: None

Fortunately, the fix is simple: Make it easier, not harder, for people to continue getting vaccinated at pharmacies.

## DOJ declines to release communication on Biden docs to House Judiciary
 - [https://thehill.com/homenews/administration/3836251-doj-declines-to-release-communication-on-biden-docs-to-house-judiciary/](https://thehill.com/homenews/administration/3836251-doj-declines-to-release-communication-on-biden-docs-to-house-judiciary/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:49:16+00:00
 - user: None

The Justice Department on Monday rebuffed a broad request from the House Judiciary Committee to provide further details about the special counsel investigation into the mishandling of documents during President Biden’s time as vice president, saying that doing so would risk releasing information central to the case. The response follows a request from the panel,...

## Nearly 6 million households had power shut off during pandemic: report
 - [https://thehill.com/homenews/3836099-nearly-6-million-households-had-power-shut-off-during-pandemic-report/](https://thehill.com/homenews/3836099-nearly-6-million-households-had-power-shut-off-during-pandemic-report/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:33:53+00:00
 - user: None

Utility companies in the U.S. have disconnected customers an estimated 5.7 million times since 2020, according to a new report. The disconnections have come even as those companies have paid billions to shareholders and executives, according to a report published on Monday by the Center for Biological Diversity, BailoutWatch and the Energy and Policy Institute. ...

## AWOL: The anti-war Democratic presidential contender
 - [https://thehill.com/opinion/campaign/3836022-awol-the-anti-war-democratic-presidential-contender/](https://thehill.com/opinion/campaign/3836022-awol-the-anti-war-democratic-presidential-contender/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:30:00+00:00
 - user: None

We have a $31.5 trillion national debt, in good measure due to our military spending and forgiving trillions in debt as an incentive for other countries to forgo military solutions to problems.

## House Oversight chair eyes bipartisan classified documents reform
 - [https://thehill.com/homenews/house/3836213-house-oversight-chair-eyes-bipartisan-classified-documents-reform/](https://thehill.com/homenews/house/3836213-house-oversight-chair-eyes-bipartisan-classified-documents-reform/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:29:26+00:00
 - user: None

House Oversight and Accountability Committee Chairman James Comer (R-Ky.) said he is hoping to pursue bipartisan legislation with ranking member Jamie Raskin (D-Md.) to address how presidential and vice presidential offices ensure they do not improperly retain classified documents after they leave office. Comer said at a National Press Club event on Monday that he...

## Crew-6: Here's a look at the four astronauts flying on NASA's next mission to the ISS
 - [https://thehill.com/homenews/space/3836098-crew-6-heres-a-look-at-the-four-astronauts-flying-on-nasas-next-mission-to-the-iss/](https://thehill.com/homenews/space/3836098-crew-6-heres-a-look-at-the-four-astronauts-flying-on-nasas-next-mission-to-the-iss/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:27:56+00:00
 - user: None

The countdown for NASA's next astronaut mission to the International Space Station (ISS) is on. Working together with SpaceX, the U.S. space agency is planning to launch its sixth long-duration crew mission as soon as Feb. 26.  Strapping inside the Dragon will be one of NASA's most diverse crews yet: NASA astronauts Stephen Bowen and...

## Fly, Eagles, fly in NY? Governor weighs in on Empire State Building sporting Philly colors
 - [https://thehill.com/blogs/in-the-know/3836175-fly-eagles-fly-in-ny-governor-weighs-in-on-empire-state-building-sporting-philly-colors/](https://thehill.com/blogs/in-the-know/3836175-fly-eagles-fly-in-ny-governor-weighs-in-on-empire-state-building-sporting-philly-colors/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:11:29+00:00
 - user: None

New York Gov. Kathy Hochul (D) doesn't seem happy about the Empire State Building lighting itself up in green and white to celebrate the Philadelphia Eagles' big victory Sunday in the NFC championship game. "To be clear, New York State has no control over how @EmpireStateBldg lights its colors," Hochul wrote in a tweet on...

## Man who disarmed Monterey Park shooting suspect invited to State of the Union
 - [https://thehill.com/homenews/administration/3836137-man-who-disarmed-monterey-park-shooting-suspect-invited-to-state-of-the-union/](https://thehill.com/homenews/administration/3836137-man-who-disarmed-monterey-park-shooting-suspect-invited-to-state-of-the-union/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:05:14+00:00
 - user: None

Rep. Judy Chu (D-Calif.) invited Brandon Tsay to be her guest at the upcoming State of the Union, an offer of honor after he disarmed the man suspected of killing at least 11 in Monterey Park, Calif.  Chu invited Tsay to the annual Washington, D.C., event in remarks as he received several California honors and recognition at a...

## WHO maintains highest alert status for COVID but sees 'transition point'
 - [https://thehill.com/policy/healthcare/3835858-who-maintains-highest-alert-status-for-covid-but-sees-transition-point/](https://thehill.com/policy/healthcare/3835858-who-maintains-highest-alert-status-for-covid-but-sees-transition-point/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:04:55+00:00
 - user: None

The World Health Organization (WHO) has determined that the COVID-19 pandemic remains a "public health emergency of international concern" while acknowledging the outbreak has reached a "transition point." WHO Director-General Tedros Adhanom Ghebreyesus on Monday relayed the findings from a recent report made by the International Health Regulations (IHR) Emergency Committee. "The WHO Director-General concurs...

## Senate Judiciary mulls action amid fallout from Durham probe
 - [https://thehill.com/policy/national-security/3836162-senate-judiciary-mulls-action-amid-fallout-from-durham-probe/](https://thehill.com/policy/national-security/3836162-senate-judiciary-mulls-action-amid-fallout-from-durham-probe/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:00:08+00:00
 - user: None

The Senate Judiciary Committee is pledging to review the actions of former special counsel John Durham following reports of inappropriate handling of his probe into the investigation of former President Trump. Recent reporting from The New York Times detailed ethical concerns during the probe prompted numerous staff departures, including concerns over former Attorney General Bill Barr’s involvement...

## Hardheaded support for a Ukrainian victory
 - [https://thehill.com/opinion/national-security/3832629-hardheaded-support-for-a-ukrainian-victory/](https://thehill.com/opinion/national-security/3832629-hardheaded-support-for-a-ukrainian-victory/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 18:00:00+00:00
 - user: None

During his address to a joint session of Congress in December, Ukrainian President Volodymyr Zelensky summed up U.S. support the best: “Your money is not charity.” Arming Ukraine to defeat Russia is in America’s interest. Regrettably, President Biden fails to explain why this is the case in a way that resonates with many Americans. Instead...

## White House moves to strengthen ObamaCare contraception requirement
 - [https://thehill.com/policy/healthcare/3836146-white-house-moves-to-strengthen-obamacare-contraception-requirement/](https://thehill.com/policy/healthcare/3836146-white-house-moves-to-strengthen-obamacare-contraception-requirement/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:59:29+00:00
 - user: None

The Biden administration is proposing an expansion of contraceptive coverage, including removing moral exemptions finalized under the Trump administration that made it easier for private health plans and insurers to exclude coverage of birth control. The proposal, released Monday by the Departments of Health and Human Services, Treasury, and Labor would remove the moral exemption but...

## Trump courses hosting three tournaments for Saudi-underwritten LIV Golf
 - [https://thehill.com/blogs/blog-briefing-room/3836024-trump-courses-hosting-three-tournaments-for-saudi-underwritten-liv-golf/](https://thehill.com/blogs/blog-briefing-room/3836024-trump-courses-hosting-three-tournaments-for-saudi-underwritten-liv-golf/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:58:26+00:00
 - user: None

Three golf courses belonging to former President Trump will be featured among other sites as hosts of tournaments for a new Saudi-backed golf league this year. Trump’s golf courses in Florida, New Jersey and Virginia will host tournaments for LIV Golf, the offshoot league that has caused rifts in the golf world by luring high-profile...

## Meadows ally to plead guilty to illegal campaign contribution
 - [https://thehill.com/regulation/court-battles/3836140-meadows-ally-to-plead-guilty-to-illegal-campaign-contribution/](https://thehill.com/regulation/court-battles/3836140-meadows-ally-to-plead-guilty-to-illegal-campaign-contribution/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:56:40+00:00
 - user: None

An unsuccessful Republican congressional candidate who ran to replace former Rep. Mark Meadows (R-N.C.) after he joined the Trump White House will plead guilty to accepting an illegal campaign contribution, according to court filings. Federal prosecutors on Friday charged Lynda Bennett for knowingly accepting a $25,000 campaign contribution from a relative that was made in...

## Five ways January transformed the political landscape
 - [https://thehill.com/homenews/3836142-five-ways-january-transformed-the-political-landscape/](https://thehill.com/homenews/3836142-five-ways-january-transformed-the-political-landscape/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:54:15+00:00
 - user: None

A new year and a new power structure at the Capitol with a House GOP majority eager to exert its influence is quickly transforming the political landscape. The year — barely a month old — has already been marked by at least one political happening not seen in more than a century: an electrifying House election that...

## Do classified document revelations highlight problems at the National Archives?
 - [https://thehill.com/opinion/white-house/3836014-do-classified-document-revelations-highlight-problems-at-the-national-archives/](https://thehill.com/opinion/white-house/3836014-do-classified-document-revelations-highlight-problems-at-the-national-archives/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:30:00+00:00
 - user: None

What is needed is a revamping of how  Top Secret and Secret classified information is archived.

## The Hill's 12:30 Report — First major step in partisan debt ceiling talks
 - [https://thehill.com/homenews/1230-report/3836046-the-hills-1230-report-first-major-step-in-partisan-debt-ceiling-talks-kelce-first-mom-to-have-sons-compete-in-superbowl-jill-biden-wears-eagles-gear/](https://thehill.com/homenews/1230-report/3836046-the-hills-1230-report-first-major-step-in-partisan-debt-ceiling-talks-kelce-first-mom-to-have-sons-compete-in-superbowl-jill-biden-wears-eagles-gear/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:30:00+00:00
 - user: None

To view past editions of The Hill's 12:30 Report, click here: https://bit.ly/30ARS1U  To receive The Hill's 12:30 Report in your inbox, please sign up here: https://bit.ly/3qmIoS9  --&#62; A midday take on what's happening in politics and how to have a sense of humor about it.*  *Ha. Haha. Hahah. Sniff. Haha. Sniff. Ha--breaks down crying hysterically. The Hill’s 12:30 Report:...

## Why California, other western states face growing pressure to reduce water consumption
 - [https://thehill.com/changing-america/sustainability/climate-change/3836075-why-california-other-western-states-face-growing-pressure-to-reduce-water-consumption/](https://thehill.com/changing-america/sustainability/climate-change/3836075-why-california-other-western-states-face-growing-pressure-to-reduce-water-consumption/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:26:33+00:00
 - user: None

Story at a glance The major storms that hit California earlier this winter dumped more than 32 trillion gallons of water on the state, helped boost some of the region's reservoirs and increased snowpack in key mountains throughout the west.   But despite this temporary reprieve, the region will need to work on water conservation and reducing demand given climate change.  ...

## Sixth Memphis officer relieved of duty in connection to Tyre Nichols death
 - [https://thehill.com/homenews/state-watch/3836074-sixth-memphis-officer-relieved-of-duty-in-connection-to-tyre-nichols-death/](https://thehill.com/homenews/state-watch/3836074-sixth-memphis-officer-relieved-of-duty-in-connection-to-tyre-nichols-death/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 17:07:58+00:00
 - user: None

A sixth officer has been relieved of duty in connection to the beating of Tyre Nichols, a 29-year-old Black man who died after being beaten by five police officers after a traffic stop on Jan. 7.  Preston Hemphill, who was hired in 2018, has been relieved of his duties as an ongoing investigation continues, The Associated...

## Twenty-four GOP senators warn they will oppose debt limit increase without fiscal reforms
 - [https://thehill.com/policy/finance/3836021-twenty-four-gop-senators-warn-they-will-oppose-debt-limit-increase-without-fiscal-reforms/](https://thehill.com/policy/finance/3836021-twenty-four-gop-senators-warn-they-will-oppose-debt-limit-increase-without-fiscal-reforms/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:58:35+00:00
 - user: None

Nearly half of the Senate Republican conference has signed onto a letter to President Biden warning they will not vote for any bill to raise the nation’s debt limit unless it’s connected to spending cuts to address the nation’s $31 trillion debt.   The letter, led by conservative Sens. Mike Lee (R-Utah) and Ted Budd...

## Graham floats potential compromise on qualified immunity
 - [https://thehill.com/homenews/senate/3835986-graham-floats-potential-compromise-on-qualified-immunity/](https://thehill.com/homenews/senate/3835986-graham-floats-potential-compromise-on-qualified-immunity/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:34:07+00:00
 - user: None

Sen. Lindsey Graham (R-S.C.) is floating a possible compromise on what was one of the key holdups in the negotiations surrounding policing reform legislation after the death of George Floyd in 2020, The death of Tyre Nichols, 29, at the hands of police in Memphis earlier this month has sparked a renewed push for policing...

## Are open amendment rules too unruly?
 - [https://thehill.com/opinion/congress-blog/3835635-are-open-amendment-rules-too-unruly/](https://thehill.com/opinion/congress-blog/3835635-are-open-amendment-rules-too-unruly/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:30:00+00:00
 - user: None

Two of the concessions the Freedom Caucus wrung-out of Republican Speaker-designate Kevin McCarthy (Calif.), in return for his election to the post on the 15th ballot Jan. 7, were commitments to bring more major bills to the floor under open amendment rules, and to appoint more hardline conservatives to the Rules Committee with its nine-to-four majority/minority...

## TikTok chief to appear before congressional panel
 - [https://thehill.com/policy/technology/3835926-tiktok-chief-to-appear-before-congressional-panel/](https://thehill.com/policy/technology/3835926-tiktok-chief-to-appear-before-congressional-panel/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:22:11+00:00
 - user: None

TikTok CEO Shou Zi Chew will appear in March before the House Energy and Commerce Committee as lawmakers push to examine the video-sharing app’s ties to China and its consumer data privacy and security practices.   Committee Chair Cathy McMorris Rodgers (R-Wash.) said calling the TikTok chief to testify is part of the panel's goal...

## Surgeon general: 13-year-olds too young to join social media
 - [https://thehill.com/policy/healthcare/3835954-surgeon-general-13-year-olds-too-young-to-join-social-media/](https://thehill.com/policy/healthcare/3835954-surgeon-general-13-year-olds-too-young-to-join-social-media/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:19:17+00:00
 - user: None

Surgeon General Vivek Murthy on Sunday cautioned that, despite many app guidelines, 13-year-olds are too young to join social media. "What is the right age for a child to start using social media? I worry that right now, if you look at the guidelines from the platforms, that age 13 is when kids are technically allowed...

## The cracks in the GOP are growing into gaping holes
 - [https://thehill.com/opinion/campaign/3835803-the-cracks-in-the-gop-are-growing-into-gaping-holes/](https://thehill.com/opinion/campaign/3835803-the-cracks-in-the-gop-are-growing-into-gaping-holes/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 16:00:00+00:00
 - user: None

The GOP of 2023 is embroiled in chaos and beset by internal strife.

## 11 US destinations land on Forbes list of top travel spots in 2023
 - [https://thehill.com/changing-america/enrichment/arts-culture/3835220-11-us-destinations-land-on-forbes-list-of-top-travel-spots-in-2023/](https://thehill.com/changing-america/enrichment/arts-culture/3835220-11-us-destinations-land-on-forbes-list-of-top-travel-spots-in-2023/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:45:04+00:00
 - user: None

A riverside city in West Virginia, a wildlife refuge in Georgia, and a Utah national park hotspot have made it onto Forbes' list of "Best Places to Travel In 2023."

## Why $4 per gallon gas this spring isn't out of the question
 - [https://thehill.com/homenews/3835897-why-4-per-gallon-gas-this-spring-isnt-out-of-the-question/](https://thehill.com/homenews/3835897-why-4-per-gallon-gas-this-spring-isnt-out-of-the-question/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:40:57+00:00
 - user: None

GasBuddy predicts the national average could hit $4 again in a couple of months. The price  is up more than 13% nationally over the past month.

## Tyre Nichols's parents accept invitation to attend State of the Union
 - [https://thehill.com/homenews/house/3835889-tyre-nicholss-parents-accept-invitation-to-attend-state-of-the-union/](https://thehill.com/homenews/house/3835889-tyre-nicholss-parents-accept-invitation-to-attend-state-of-the-union/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:40:49+00:00
 - user: None

The parents of Tyre Nichols, the 29-year-old who died after being beaten by Memphis police during a traffic stop, have accepted an invitation to President Biden's State of the Union address next month. Police footage released Friday showed a group of officers pepper spraying, using a stun gun on, punching and kicking Nichols, while others...

## Four principles for crypto regulation
 - [https://thehill.com/opinion/cybersecurity/3835466-four-principles-for-crypto-regulation/](https://thehill.com/opinion/cybersecurity/3835466-four-principles-for-crypto-regulation/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:30:00+00:00
 - user: None

We encourage regulators not to take a one-size-fits-all approach to web3 regulation, but to understand the context and allow for experimentation and dialogue.

## Molotov cocktail thrown at New Jersey synagogue, police say
 - [https://thehill.com/homenews/state-watch/3835846-molotov-cocktail-thrown-at-new-jersey-synagogue-police-say/](https://thehill.com/homenews/state-watch/3835846-molotov-cocktail-thrown-at-new-jersey-synagogue-police-say/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:20:07+00:00
 - user: None

A Molotov cocktail was thrown at the front door of a New Jersey synagogue on Sunday, according to authorities, who said the suspect remains at large.   Video surveillance shared by the Bloomfield, N.J., Division of Public Safety shows the suspect — believed to be a Caucasian male — approach the Temple Ner Tamid synagogue in a...

## Jim Jordan says he's uncertain reform can stop 'evil' seen in Tyre Nichols video
 - [https://thehill.com/homenews/house/3835841-jim-jordan-says-hes-uncertain-reform-can-stop-evil-seen-in-tyre-nichols-video/](https://thehill.com/homenews/house/3835841-jim-jordan-says-hes-uncertain-reform-can-stop-evil-seen-in-tyre-nichols-video/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:04:28+00:00
 - user: None

Rep. Jim Jordan (R-Ohio) on Sunday said he’s not sure any police reform could have stopped what happened to Tyre Nichols, a 29-year-old Black man who was beaten by Memphis police officers after a traffic stop in early January.  “I don't know that there's any law that can stop that evil that we saw that is just,...

## The 'Putin Principle' could bring peace to Eurasia
 - [https://thehill.com/opinion/international/3832552-the-putin-principle-could-bring-peace-to-eurasia/](https://thehill.com/opinion/international/3832552-the-putin-principle-could-bring-peace-to-eurasia/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 15:00:00+00:00
 - user: None

Sometimes even Russian strongman Vladimir Putin has a good idea. For years, he has insisted that Russia has a right to territories that were historically Russia’s and whose inhabitants are “our own.” Hence, Putin’s claims on Ukraine’s Donbas and Crimea, which have large Russian and Russian-speaking populations. This is also his justification for the genocidal...

## COVID still an emergency but nearing key immunity level, WHO says
 - [https://thehill.com/changing-america/well-being/prevention-cures/3835693-covid-still-an-emergency-but-nearing-key-immunity-level-who-says/](https://thehill.com/changing-america/well-being/prevention-cures/3835693-covid-still-an-emergency-but-nearing-key-immunity-level-who-says/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:59:18+00:00
 - user: None

The coronavirus remains a global health emergency, the World Health Organization chief said Monday after a key advisory panel found the pandemic may be nearing an “inflexion point” where higher levels of immunity can lower virus-related deaths.

## EV price war underway as Ford slashes electric Mustang prices
 - [https://thehill.com/policy/transportation/automobiles/3835808-ev-price-war-underway-as-ford-slashes-electric-mustang-prices/](https://thehill.com/policy/transportation/automobiles/3835808-ev-price-war-underway-as-ford-slashes-electric-mustang-prices/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:52:29+00:00
 - user: None

Ford Motor Co. will slash the price of its top electric vehicle, the Mustang Mach-E, after Tesla announced a series of major price cuts earlier this month. Ford on Monday announced price cuts ranging from $600 to $5,900 on certain Mach-E models. The American automaker added that it will “significantly” increase production of the electric...

## Boris Johnson says Putin threatened to kill him
 - [https://thehill.com/policy/international/3835776-boris-johnson-says-putin-threatened-to-kill-him/](https://thehill.com/policy/international/3835776-boris-johnson-says-putin-threatened-to-kill-him/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:30:55+00:00
 - user: None

Former British Prime Minister Boris Johnson claims that Russian President Vladimir Putin threatened to kill him with a missile strike in the days leading up to the Russian invasion of Ukraine. Johnson made the claim in a documentary for the BBC, saying Putin “threatened me at one point, and he said, 'Boris, I don't want...

## Juan Williams: Republicans’ troubles start with failing to catch a ‘red wave’
 - [https://thehill.com/opinion/campaign/3835429-juan-williams-republicans-troubles-start-with-failing-to-catch-a-red-wave/](https://thehill.com/opinion/campaign/3835429-juan-williams-republicans-troubles-start-with-failing-to-catch-a-red-wave/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:30:00+00:00
 - user: None

McCarthy embodies today’s GOP as a captive of kooks, grifters and aspiring authoritarians.

## Schumer on debt ceiling battle: 'I think we'll win'
 - [https://thehill.com/homenews/senate/3835760-schumer-on-debt-ceiling-battle-i-think-well-win/](https://thehill.com/homenews/senate/3835760-schumer-on-debt-ceiling-battle-i-think-well-win/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:06:30+00:00
 - user: None

Lawmakers are on a crash course over how to deal with the debt limit in the coming weeks, and it’s a collision that Senate Majority Leader Charles Schumer (D-N.Y.) thinks Democrats will win. Schumer has hammered House Republican for demanding spending cuts from Democrats and the White House in exchange for raising the debt limit,...

## Western business is still sustaining Russia’s war
 - [https://thehill.com/opinion/international/3835419-western-business-is-still-sustaining-russias-war/](https://thehill.com/opinion/international/3835419-western-business-is-still-sustaining-russias-war/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 14:00:00+00:00
 - user: None

The details are damning.

## Vice President Harris to tout Latino small businesses in Raleigh
 - [https://thehill.com/latino/3835755-vice-president-harris-to-tout-latino-small-businesses-in-raleigh/](https://thehill.com/latino/3835755-vice-president-harris-to-tout-latino-small-businesses-in-raleigh/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 13:42:31+00:00
 - user: None

Vice President Harris will travel to Raleigh, N.C., Monday, making a stop to discuss Latino small businesses at a public forum, The Hill has learned. In Raleigh, Harris will join a panel discussion with Small Business Administrator Isabella Casillas Guzmán and Vicky García, senior vice president of the Latino Community Credit Union, a financial institution...

## More Americans list government as top problem in US: Gallup
 - [https://thehill.com/blogs/blog-briefing-room/3835739-more-americans-list-government-as-top-problem-in-us-gallup/](https://thehill.com/blogs/blog-briefing-room/3835739-more-americans-list-government-as-top-problem-in-us-gallup/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 13:36:55+00:00
 - user: None

More Americans see the government as the worst problem in the U.S., according to a new survey, topping issues including inflation and immigration. A 21 percent plurality of respondents cited the government as the top issue in the U.S. in the Gallup poll released Monday after the fight over Speaker in the House and as...

## Chiefs star Kelce to Cincinnati mayor: 'Know your role and shut your mouth'
 - [https://thehill.com/blogs/blog-briefing-room/3835706-chiefs-star-kelce-to-cincinnati-mayor-know-your-role-and-shut-your-mouth/](https://thehill.com/blogs/blog-briefing-room/3835706-chiefs-star-kelce-to-cincinnati-mayor-know-your-role-and-shut-your-mouth/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 13:27:28+00:00
 - user: None

Kansas City Chiefs tight end Travis Kelce had some words for Cincinnati Mayor Aftab Pureval after the mayor threw jabs at the Chiefs before Sunday's AFC Championship game against the Bengals. Prior to the game, Pureval posted a video to Twitter, proclaiming Sunday "They Gotta Play Us Day" to celebrate the matchup, while throwing shade at...

## To reverse our discontent, America needs a national infrastructure bank
 - [https://thehill.com/opinion/finance/3835430-to-reverse-our-discontent-america-needs-a-national-infrastructure-bank/](https://thehill.com/opinion/finance/3835430-to-reverse-our-discontent-america-needs-a-national-infrastructure-bank/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 13:00:00+00:00
 - user: None

Infrastructure, writ large, offers the same potential for explosive growth as automobiles did a century ago.

## Ohio, Missouri senators wager ribs on Bengals-Chiefs game
 - [https://thehill.com/blogs/blog-briefing-room/3835699-ohio-missouri-senators-wager-ribs-on-bengals-chiefs-game/](https://thehill.com/blogs/blog-briefing-room/3835699-ohio-missouri-senators-wager-ribs-on-bengals-chiefs-game/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 12:42:28+00:00
 - user: None

Sens. Josh Hawley (R-Mo.) and J.D. Vance (R-Ohio) wagered ribs on the outcome of the AFC Championship game between the Kansas City Chiefs and the Cincinnati Bengals, Hawley said in a tweet on Sunday. “We settled on ribs from @JDVance1 if (and when) he loses, KC Joe’s from me in the highly unlikely event the...

## State 'right-to-repair' laws can't take away the rights of digital creators
 - [https://thehill.com/opinion/technology/3828346-state-right-to-repair-laws-cant-take-away-the-rights-of-digital-creators/](https://thehill.com/opinion/technology/3828346-state-right-to-repair-laws-cant-take-away-the-rights-of-digital-creators/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 12:30:00+00:00
 - user: None

Reports abound about farmers who can’t repair their tractors or iPhone owners who can’t replace their cracked screens have fueled a push in recent years for state “right-to-repair” legislation that would create more opportunities for consumers to repair their electronic devices. But what these narratives leave out is the important role that copyright law plays...

## In Beijing, Blinken should appeal for the freedom of 'blank page' protesters
 - [https://thehill.com/opinion/international/3833509-in-beijing-blinken-should-appeal-for-the-freedom-of-blank-page-protesters/](https://thehill.com/opinion/international/3833509-in-beijing-blinken-should-appeal-for-the-freedom-of-blank-page-protesters/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 12:00:00+00:00
 - user: None

As Antony Blinken prepares to embark on his first trip to China as Secretary of State, activists around the world are urging him to place human rights at the top of his agenda. For Blinken to do so would certainly be in keeping with America’s tradition of championing freedom and democracy — a tradition that...

## Tesla 'spontaneously' caught fire on California highway: officials
 - [https://thehill.com/homenews/3835368-tesla-spontaneously-caught-fire-on-california-highway-officials/](https://thehill.com/homenews/3835368-tesla-spontaneously-caught-fire-on-california-highway-officials/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:40:20+00:00
 - user: None

It's just the latest Tesla fire authorities in Sacramento have had to deal with.

## The Hill's Morning Report — Biden, McCarthy to meet amid 2024 backdrop
 - [https://thehill.com/homenews/morning-report/3835674-the-hills-morning-report-biden-mccarthy-to-meet-amid-2024-backdrop/](https://thehill.com/homenews/morning-report/3835674-the-hills-morning-report-biden-mccarthy-to-meet-amid-2024-backdrop/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:30:00+00:00
 - user: None

Editor’s note: The Hill’s Morning Report is our daily newsletter that dives deep into Washington’s agenda. To subscribe, click here or fill out the box below. Both political parties this week will put actions behind narratives they believe could mold the future of American politics. President Biden starts the week by reminding Americans specifically how...

## Biden gets to know new partner in House in Hakeem Jeffries
 - [https://thehill.com/homenews/administration/3832225-biden-jeffries-kick-start-working-relationship/](https://thehill.com/homenews/administration/3832225-biden-jeffries-kick-start-working-relationship/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

President Biden this week marked the beginning of his working relationship with House Democratic Leader Hakeem Jeffries, who he’ll have to rely on when it comes to Republican threats of spending cuts and a showdown over the country’s debt ceiling.  The new Democratic leader’s role is also a generational shift after 20 years of former...

## Manchin sees himself as shuttle diplomat from Democrats to McCarthy
 - [https://thehill.com/homenews/senate/3833832-manchin-sees-himself-as-shuttle-diplomat-from-democrats-to-mccarthy/](https://thehill.com/homenews/senate/3833832-manchin-sees-himself-as-shuttle-diplomat-from-democrats-to-mccarthy/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

Sen. Joe Manchin (D-W.Va.) is seeking to carve out a new role for himself now that he's no longer the power broker that he was in last year's 50-50 Senate.   Manchin now envisions himself as a shuttle diplomat working to bridge the partisan divide between Senate Majority Leader Charles Schumer (D-N.Y.) and Speaker Kevin...

## This week: Biden, McCarthy to meet amid debt ceiling standoff
 - [https://thehill.com/homenews/house/3835514-this-week-biden-mccarthy-to-meet-amid-debt-ceiling-standoff/](https://thehill.com/homenews/house/3835514-this-week-biden-mccarthy-to-meet-amid-debt-ceiling-standoff/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

President Biden and Speaker Kevin McCarthy (R-Calif.) are scheduled to meet this week amid a standoff over the debt ceiling. The highly anticipated meeting — scheduled for Wednesday at the White House — comes nearly two weeks after the U.S. hit its debt ceiling, starting the clock for Congress to take action or allow the country to...

## What three hard-line conservatives plan to do with their seats on the Rules Committee
 - [https://thehill.com/homenews/house/3833833-what-three-hard-line-conservatives-plan-to-do-with-their-seats-on-the-rules-committee/](https://thehill.com/homenews/house/3833833-what-three-hard-line-conservatives-plan-to-do-with-their-seats-on-the-rules-committee/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

The addition of Republican Reps. Chip Roy (Texas), Ralph Norman (S.C.), and Thomas Massie (Ky.) to the House Rules Committee — one of the concessions from Speaker Kevin McCarthy (R-Calif.) that helped him secure the gavel — means that the frequent antagonists of leadership have the opportunity to create significant barriers to getting legislation to...

## Biden to visit Baltimore for rail tunnel project kickoff
 - [https://thehill.com/homenews/administration/3835538-biden-to-visit-baltimore-for-rail-tunnel-project-kickoff/](https://thehill.com/homenews/administration/3835538-biden-to-visit-baltimore-for-rail-tunnel-project-kickoff/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 10:00:00+00:00
 - user: None

President Biden on Monday will visit Baltimore, Md., for the launch of a project to replace a 150-year-old tunnel causing rail bottlenecks between the nation’s capital and New Jersey. The replacement rail tunnel — funded by the bipartisan Infrastructure Law — is set to improve the travel woes of millions of commuters who face delays down the...

## Germany warns against arms race as Ukraine pushes for missiles, jets
 - [https://thehill.com/policy/international/3835512-germany-warns-against-arms-race-as-ukraine-pushes-for-missiles-jets/](https://thehill.com/policy/international/3835512-germany-warns-against-arms-race-as-ukraine-pushes-for-missiles-jets/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 03:40:08+00:00
 - user: None

German Chancellor Olaf Scholz is warning against a race to arm Ukraine with high-powered weapons as Ukraine ramps up its calls for fighter jets and long-range missiles. Scholz engineered a breakthrough with President Biden to send modern tanks to Ukraine earlier this month, but has said fighter jets is a non-starter. “I can only advise against...

## Lake attacks Gallego as 'AOC of Arizona' after Senate announcement
 - [https://thehill.com/homenews/campaign/3835487-lake-attacks-gallego-as-aoc-of-arizona-after-senate-announcement/](https://thehill.com/homenews/campaign/3835487-lake-attacks-gallego-as-aoc-of-arizona-after-senate-announcement/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 03:19:40+00:00
 - user: None

Former Arizona gubernatorial candidate Kari Lake (R) attacked Rep. Ruben Gallego (D-Ariz.) as the "AOC of Arizona" on Sunday night, a week after the progressive Democrat announced he's running for Senate in 2024. Since losing to now-Gov. Katie Hobbs (D) in November's election, Lake has pushed false claims about election fraud and taken her grievances to court....

## Philadelphia Eagles, Kansas City Chiefs heading to Super Bowl
 - [https://thehill.com/homenews/nexstar_media_wire/3835509-philadelphia-eagles-kansas-city-chiefs-heading-to-super-bowl/](https://thehill.com/homenews/nexstar_media_wire/3835509-philadelphia-eagles-kansas-city-chiefs-heading-to-super-bowl/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 03:07:40+00:00
 - user: None

We now know who will play in the Super Bowl next month.

## Omar says McCarthy following playbook 'used by demagogues throughout history'
 - [https://thehill.com/homenews/house/3835484-omar-says-mccarthy-following-playbook-used-by-demagogues-throughout-history/](https://thehill.com/homenews/house/3835484-omar-says-mccarthy-following-playbook-used-by-demagogues-throughout-history/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 02:41:08+00:00
 - user: None

Rep. Ilhan Omar (D-Minn.) on Sunday said Speaker Kevin McCarthy (R-Calif.) is following a political playbook “used by demagogues throughout history” by trying to “pit my minority groups against each other” in his bid to remove her from the House Foreign Affairs Committee. McCarthy has accused Omar, one of the first two Muslim women elected to Congress,...

## DOJ 'working' to share info on classified Trump, Biden docs with senators: reports
 - [https://thehill.com/homenews/senate/3835452-doj-working-to-share-info-on-classified-trump-biden-docs-with-senators-reports/](https://thehill.com/homenews/senate/3835452-doj-working-to-share-info-on-classified-trump-biden-docs-with-senators-reports/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 01:28:36+00:00
 - user: None

The Department of Justice has told Senate Intelligence Committee members that it is working to provide more information on the classified documents found at the homes of President Biden and former President Trump. “We are working with the Office of the Director of National Intelligence to support the provision of information that will satisfy the...

## Maxine Waters says Manchin and Sinema 'don't give a darn' about policing reform
 - [https://thehill.com/homenews/house/3835405-maxine-waters-says-manchin-and-sinema-dont-give-a-darn-about-policing-reform/](https://thehill.com/homenews/house/3835405-maxine-waters-says-manchin-and-sinema-dont-give-a-darn-about-policing-reform/)
 - RSS feed: https://thehill.com/news/feed/
 - date published: 2023-01-30 01:01:55+00:00
 - user: None

Rep. Maxine Waters (D-Calif.) on Sunday said Sens. Joe Manchin (D-W.Va.) and Kyrsten Sinema (I-Ariz.) both “don’t give a darn” about police reform amid renewed calls for legislative action on the issue following the fatal beating of Tyre Nichols at the hands of Memphis police officers. Sinema and Manchin has been fierce defenders of the...
