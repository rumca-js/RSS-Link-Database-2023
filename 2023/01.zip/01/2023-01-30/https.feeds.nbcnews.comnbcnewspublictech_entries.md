# Source NBC tech, Source URL:https://feeds.nbcnews.com/nbcnews/public/tech, Source language: en-US

## TikTok CEO to testify before Congress in March amid app security questions
 - [https://www.nbcnews.com/politics/congress/tiktok-ceo-testify-congress-march-app-security-questions-rcna68147](https://www.nbcnews.com/politics/congress/tiktok-ceo-testify-congress-march-app-security-questions-rcna68147)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-30 14:57:57+00:00
 - user: None

TikTok CEO Shou Zi Chew will appear before Congress in March to field questions about the viral video app's security measures amid mounting efforts to ban it because of privacy concerns.

## Europe’s crackdown on Big Tech omitted TikTok — but now that’s set to change
 - [https://www.nbcnews.com/tech/tech-news/europe-eyes-crack-tiktok-rcna68149](https://www.nbcnews.com/tech/tech-news/europe-eyes-crack-tiktok-rcna68149)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-30 14:18:15+00:00
 - user: None

TikTok is beginning to feel the sting of political and regulatory pressure in Europe, where the Chinese-owned app has largely evaded scrutiny.
