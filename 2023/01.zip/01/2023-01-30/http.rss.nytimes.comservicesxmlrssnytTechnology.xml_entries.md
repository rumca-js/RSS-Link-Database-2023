# Source NY times technology, Source URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, Source language: en-US

## Ford Follows Tesla in Cutting Electric Vehicle Prices
 - [https://www.nytimes.com/2023/01/30/business/ford-mustang-electric-prices.html](https://www.nytimes.com/2023/01/30/business/ford-mustang-electric-prices.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-30 16:50:57+00:00
 - user: None

The automaker reduced the price of the Mustang Mach-E by up to $5,900 after Tesla slashed prices of its cars by as much as 20 percent.

## ‘Recession Resilient’ Climate Start-Ups Shine in Tech Downturn
 - [https://www.nytimes.com/2023/01/30/technology/recession-resilient-climate-start-ups-shine-in-tech-downturn.html](https://www.nytimes.com/2023/01/30/technology/recession-resilient-climate-start-ups-shine-in-tech-downturn.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-30 10:00:18+00:00
 - user: None

Tech workers and investors are flocking to start-ups that aim to combat climate change.
