# Source ABC News, Source URL:http://feeds.abcnews.com/abcnews/topstories, Source language: en-US

## Court upholds Minnesota 'Clean Car Rule' tied to California
 - [https://abcnews.go.com/Business/wireStory/court-upholds-minnesota-clean-car-rule-tied-california-96775227](https://abcnews.go.com/Business/wireStory/court-upholds-minnesota-clean-car-rule-tied-california-96775227)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 23:38:53+00:00
 - user: None

The rule ties the state&rsquo;s vehicle emission standards to California regulations.

## 'Father of Peeps' marshmallow candies Bob Born dies at 98
 - [https://abcnews.go.com/Business/wireStory/father-peeps-bob-born-dies-98-96774956](https://abcnews.go.com/Business/wireStory/father-peeps-bob-born-dies-98-96774956)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 23:23:33+00:00
 - user: None

He mechanized the process to make the marshmallow chicks.

## WATCH:  Police save suspect from path of oncoming train
 - [https://abcnews.go.com/US/video/police-save-suspect-path-oncoming-train-96775548](https://abcnews.go.com/US/video/police-save-suspect-path-oncoming-train-96775548)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 23:13:52+00:00
 - user: None

Footage released by Atlanta police shows officers pulling a suspect out of the path of an oncoming train after authorities say he stole a patrol car, fled and then lost control.

## Biden administration will end COVID-19 emergencies on May 11
 - [https://abcnews.go.com/Health/biden-administration-end-covid-19-emergencies-11/story?id=96335640](https://abcnews.go.com/Health/biden-administration-end-covid-19-emergencies-11/story?id=96335640)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 23:10:02+00:00
 - user: None

The Biden administration plans to end both the COVID-19 national emergency and public health emergency on May 11, the White House has informed Congress

## Biden touts $6 billion rail tunnel replacement, highlighting infrastructure law
 - [https://abcnews.go.com/Politics/biden-touts-6-billion-rail-tunnel-replacement-highlighting/story?id=96769576](https://abcnews.go.com/Politics/biden-touts-6-billion-rail-tunnel-replacement-highlighting/story?id=96769576)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 22:49:40+00:00
 - user: None

President Joe Biden on Monday kicked off a $6 billion rail tunnel replacement, highlighting the benefits of the infrastructure law.

## WATCH:  Soap bubbles crystallize in freezing weather
 - [https://abcnews.go.com/US/video/soap-bubbles-crystallize-freezing-weather-96775437](https://abcnews.go.com/US/video/soap-bubbles-crystallize-freezing-weather-96775437)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 22:25:23+00:00
 - user: None

Freezing weather in Minnesota caused soap bubbles to crystalize, creating beautiful designs.

## Russian millionaire on trial in hack, insider trade scheme
 - [https://abcnews.go.com/Business/wireStory/russian-millionaire-trial-hack-insider-trade-scheme-96774963](https://abcnews.go.com/Business/wireStory/russian-millionaire-trial-hack-insider-trade-scheme-96774963)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 22:24:46+00:00
 - user: None

Russian millionaire and associates allegedly made tens of millions of dollars .

## Chicago prosecutor dropping R. Kelly sex-abuse charges
 - [https://abcnews.go.com/Entertainment/wireStory/chicago-prosecutor-dropping-kelly-sex-abuse-charges-96774628](https://abcnews.go.com/Entertainment/wireStory/chicago-prosecutor-dropping-kelly-sex-abuse-charges-96774628)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 22:09:10+00:00
 - user: None

His federal convictions ensure the disgraced star will be locked up for decades.

## Florida GOP leaders want to get rid of gun permits
 - [https://abcnews.go.com/Politics/wireStory/florida-gop-leaders-rid-gun-permits-96773328](https://abcnews.go.com/Politics/wireStory/florida-gop-leaders-rid-gun-permits-96773328)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 21:42:15+00:00
 - user: None

The House speaker proposed legislation to eliminate concealed weapons permits.

## Over 50,000 pounds of charcuterie-style sausage recalled over Listeria contamination
 - [https://abcnews.go.com/GMA/Food/50000-pounds-charcuterie-style-sausage-recalled-listeria-contamination/story?id=96762289](https://abcnews.go.com/GMA/Food/50000-pounds-charcuterie-style-sausage-recalled-listeria-contamination/story?id=96762289)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 20:44:29+00:00
 - user: None

The USDA Food Safety and Inspection Service announced a recall from Daniele International LLC of 52,914 pounds of products due to Listeria contamination concerns.

## Johnson & Johnson can't invoke bankruptcy to stop cancer lawsuits, court says
 - [https://abcnews.go.com/Business/johnson-johnson-invoke-bankruptcy-stop-cancer-lawsuits-court/story?id=96768459](https://abcnews.go.com/Business/johnson-johnson-invoke-bankruptcy-stop-cancer-lawsuits-court/story?id=96768459)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 20:44:19+00:00
 - user: None

Johnson & Johnson faces 38,000 lawsuits that allege its baby powder causes cancer.

## What's behind the Pakistani Taliban's insurgency?
 - [https://abcnews.go.com/International/wireStory/pakistani-talibans-deadly-insurgency-96767917](https://abcnews.go.com/International/wireStory/pakistani-talibans-deadly-insurgency-96767917)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 20:38:47+00:00
 - user: None

The TTP claimed responsibility for a deadly suicide bombing at a mosque.

## Congressional candidate accused of campaign violation
 - [https://abcnews.go.com/Politics/wireStory/congressional-candidate-accused-campaign-violation-96770253](https://abcnews.go.com/Politics/wireStory/congressional-candidate-accused-campaign-violation-96770253)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 20:08:40+00:00
 - user: None

She's accused of a campaign finance violation and has signed a plea agreement.

## US skier Kyle Smaine killed in avalanche in Japan
 - [https://abcnews.go.com/Sports/us-skier-kyle-smaine-killed-avalanche-japan/story?id=96768097](https://abcnews.go.com/Sports/us-skier-kyle-smaine-killed-avalanche-japan/story?id=96768097)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 20:07:24+00:00
 - user: None

Kyle Smaine, a U.S. professional skier who was the halfpipe gold medalist in the 2015 world championships, died Sunday in an avalanche in Japan, his family said.

## Man charged with killing mom at sea seeks grand jury minutes
 - [https://abcnews.go.com/US/wireStory/man-charged-killing-mom-sea-seeks-grand-jury-96769903](https://abcnews.go.com/US/wireStory/man-charged-killing-mom-sea-seeks-grand-jury-96769903)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 19:53:05+00:00
 - user: None

He is charged with killing his mother at sea during a 2016 fishing trip.

## Michael Jackson's nephew to star in King of Pop biopic
 - [https://abcnews.go.com/Entertainment/wireStory/michael-jacksons-nephew-star-king-pop-biopic-96768282](https://abcnews.go.com/Entertainment/wireStory/michael-jacksons-nephew-star-king-pop-biopic-96768282)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 19:08:50+00:00
 - user: None

Michael Jackson&rsquo;s 26-year-old nephew, Jaafar Jackson, will play the King of Pop in the planned biopic &ldquo;Michael&rdquo; to be directed by Antoine Fuqua

## Florida sheriff sued for 'Wheel of Fugitive' defamation
 - [https://abcnews.go.com/US/wireStory/florida-sheriff-sued-wheel-fugitive-defamation-96767089](https://abcnews.go.com/US/wireStory/florida-sheriff-sued-wheel-fugitive-defamation-96767089)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 17:53:35+00:00
 - user: None

The sheriff posts weekly &quot;Wheel of Fugitive&quot; videos on social media.

## WHO says COVID still a threat but pandemic is 'probably at a transition point'
 - [https://abcnews.go.com/Health/covid-19-pandemic-transition-point/story?id=96765627](https://abcnews.go.com/Health/covid-19-pandemic-transition-point/story?id=96765627)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 17:26:44+00:00
 - user: None

The WHO said in a statement Monday COVID-19 is still a public health emergency but that the pandemic "is probably at a transition point."

## Volvo Group North America faces $130M civil penalty
 - [https://abcnews.go.com/Business/wireStory/volvo-group-north-america-faces-130m-civil-penalty-96766366](https://abcnews.go.com/Business/wireStory/volvo-group-north-america-faces-130m-civil-penalty-96766366)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 17:23:33+00:00
 - user: None

Volvo failed to recall vehicles quickly enough in a consent order.

## Hall of Famer Bobby Hull, the Golden Jet, dies at 84
 - [https://abcnews.go.com/Sports/wireStory/hall-famer-bobby-hull-golden-jet-dies-age-96765801](https://abcnews.go.com/Sports/wireStory/hall-famer-bobby-hull-golden-jet-dies-age-96765801)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 17:09:06+00:00
 - user: None

Hull helped the Chicago Blackhawks win the 1961 Stanley Cup Final.

## 6th officer involved in Tyre Nichols' death relieved of duty
 - [https://abcnews.go.com/US/6th-officer-involved-tyre-nichols-death-relieved-duty/story?id=96764687](https://abcnews.go.com/US/6th-officer-involved-tyre-nichols-death-relieved-duty/story?id=96764687)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 16:50:58+00:00
 - user: None

A sixth Memphis police officer involved in the arrest of Tyre Nichols has been relieved of duty.

## Fed, set to impose smaller hike, may hint of fewer increases
 - [https://abcnews.go.com/Politics/wireStory/fed-set-impose-smaller-hike-hint-fewer-increases-96764507](https://abcnews.go.com/Politics/wireStory/fed-set-impose-smaller-hike-hint-fewer-increases-96764507)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 16:27:51+00:00
 - user: None

The Federal Reserve is poised this week to raise its benchmark interest rate for an eighth time since March

## Ford cuts price on Mustang Mach-E after Tesla trims prices
 - [https://abcnews.go.com/Business/wireStory/ford-cuts-price-mustang-mach-after-tesla-price-96762926](https://abcnews.go.com/Business/wireStory/ford-cuts-price-mustang-mach-after-tesla-price-96762926)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 16:08:51+00:00
 - user: None

Ford is cutting prices on its Mustang Mach-E electric SUV by as much as $6,000 just weeks after market leader Tesla made similar moves

## New US ambassador to Moscow meets with Russian deputy FM
 - [https://abcnews.go.com/Politics/wireStory/new-us-ambassador-moscow-meets-russian-deputy-fm-96761427](https://abcnews.go.com/Politics/wireStory/new-us-ambassador-moscow-meets-russian-deputy-fm-96761427)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 14:08:40+00:00
 - user: None

New U.S. ambassador to Moscow Lynne Tracy arrived last week amid high tensions.

## 'I'm still shocked': Tech workers offer insider account of mass layoffs
 - [https://abcnews.go.com/Business/im-shocked-tech-workers-offer-insider-account-mass/story?id=96535559](https://abcnews.go.com/Business/im-shocked-tech-workers-offer-insider-account-mass/story?id=96535559)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 14:00:26+00:00
 - user: None

Three laid-off tech workers describe losing their jobs and how they're coping.

## Lisa Loring, actress who played original Wednesday Addams, dies at 64
 - [https://abcnews.go.com/GMA/Culture/lisa-loring-actress-played-original-wednesday-addams-dies/story?id=96756065](https://abcnews.go.com/GMA/Culture/lisa-loring-actress-played-original-wednesday-addams-dies/story?id=96756065)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 13:55:12+00:00
 - user: None

Lisa Loring, the actress who portrayed the original Wednesday Addams in the '60s series "The Addams Family," has died.

## 2 foreign skiers hit by Japan avalanche found, presumed dead
 - [https://abcnews.go.com/International/wireStory/2-foreign-skiers-hit-japan-avalanche-found-presumed-96757779](https://abcnews.go.com/International/wireStory/2-foreign-skiers-hit-japan-avalanche-found-presumed-96757779)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 13:54:49+00:00
 - user: None

Japanese rescuers have found two foreign men who were hit by an avalanche while backcountry skiing

## Turkey's opposition vows more democracy if it wins election
 - [https://abcnews.go.com/International/wireStory/turkeys-opposition-vows-democracy-wins-election-96760226](https://abcnews.go.com/International/wireStory/turkeys-opposition-vows-democracy-wins-election-96760226)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 13:46:15+00:00
 - user: None

A coalition of six Turkish opposition parties striving to end two decades of rule by President Recep Tayyip Erdogan are reaffirming a commitment for a return to parliamentary democracy should their alliance win elections that are likely to be held on M...

## NATO chief urges Seoul to send military support to Ukraine
 - [https://abcnews.go.com/International/wireStory/nato-chief-urges-seoul-send-military-support-ukraine-96760345](https://abcnews.go.com/International/wireStory/nato-chief-urges-seoul-send-military-support-ukraine-96760345)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 13:42:01+00:00
 - user: None

NATO Secretary-General Jens Stoltenberg is calling for South Korea to provide direct military support to Ukraine, saying Kyiv is in urgent need of weapons to fight off the prolonged Russian invasion

## School where 6-year-old shot his teacher set to reopen
 - [https://abcnews.go.com/US/wireStory/school-6-year-shot-teacher-set-reopen-96758963](https://abcnews.go.com/US/wireStory/school-6-year-shot-teacher-set-reopen-96758963)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 12:38:48+00:00
 - user: None

Students and teachers returning to the Virginia elementary school where a 6-year-old boy shot his teacher will see visible signs of stepped-up security

## Austrian police find family illegally living in wine cellar
 - [https://abcnews.go.com/International/wireStory/austrian-police-find-family-illegally-living-wine-cellar-96758839](https://abcnews.go.com/International/wireStory/austrian-police-find-family-illegally-living-wine-cellar-96758839)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 12:23:35+00:00
 - user: None

Austrian police say they arrested a 54-year-old man after he attacked two social workers with pepper spray when they found him living illegally in a private wine cellar in northeastern Austria with a woman and six young children

## Biden visit to Baltimore highlights rail tunnel project
 - [https://abcnews.go.com/Business/wireStory/biden-visit-baltimore-highlights-rail-tunnel-project-96758743](https://abcnews.go.com/Business/wireStory/biden-visit-baltimore-highlights-rail-tunnel-project-96758743)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 12:18:58+00:00
 - user: None

President Joe Biden is heading to Baltimore to visit an aging rail tunnel that's slated to be replaced with help from bipartisan infrastructure legislation that he signed in 2021

## Boris Johnson says Putin said he could hit him with missile
 - [https://abcnews.go.com/International/wireStory/boris-johnson-putin-hit-missile-96757942](https://abcnews.go.com/International/wireStory/boris-johnson-putin-hit-missile-96757942)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 12:17:06+00:00
 - user: None

Former U.K. Prime Minister Boris Johnson has said that President Vladimir Putin didn&rsquo;t seem serious about avoiding war in the days before Russia invaded Ukraine

## WHO: COVID still an emergency but nearing 'inflection' point
 - [https://abcnews.go.com/International/wireStory/covid-emergency-nearing-inflection-point-96758022](https://abcnews.go.com/International/wireStory/covid-emergency-nearing-inflection-point-96758022)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 12:15:13+00:00
 - user: None

The World Health Organization chief says the coronavirus remains a global health emergency

## Suicide bomber kills at least 17 at mosque in Pakistan
 - [https://abcnews.go.com/International/suicide-bomber-detonates-inside-mosque-pakistan-killing-wounding/story?id=96757596](https://abcnews.go.com/International/suicide-bomber-detonates-inside-mosque-pakistan-killing-wounding/story?id=96757596)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 10:46:34+00:00
 - user: None

A suicide bomber detonated explosives inside a mosque in northwestern Pakistan on Monday, killing and wounding dozens of people, officials said.

## Senators renew call for probe of smaller AR-15 rifle they claim is targeted at kids
 - [https://abcnews.go.com/US/senators-renew-call-investigation-smaller-ar-15-rifle/story?id=96712785](https://abcnews.go.com/US/senators-renew-call-investigation-smaller-ar-15-rifle/story?id=96712785)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 09:23:06+00:00
 - user: None

Senators renew call for investigation of smaller AR-15 rifle targeted toward children

## Chiefs top Bengals on last-second kick, will face Eagles in Super Bowl
 - [https://abcnews.go.com/Sports/wireStory/chiefs-top-bengals-23-20-kick-afc-title-96755326](https://abcnews.go.com/Sports/wireStory/chiefs-top-bengals-23-20-kick-afc-title-96755326)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 04:08:57+00:00
 - user: None

A 45-yard field goal with 3 seconds left gave Kansas City a 23-20 win.

## Chiefs top Bengals 23-20 to win AFC title, will face Eagles in Super Bowl
 - [https://abcnews.go.com/Sports/wireStory/chiefs-top-bengals-23-20-win-afc-title-96755223](https://abcnews.go.com/Sports/wireStory/chiefs-top-bengals-23-20-win-afc-title-96755223)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 03:11:42+00:00
 - user: None

Chiefs top Bengals 23-20 to win AFC title, will face Eagles in Super Bowl

## Barrett Strong, Motown artist known for ‘Money,’ dies at 81
 - [https://abcnews.go.com/Entertainment/wireStory/barrett-strong-motown-artist-money-dies-81-96755093](https://abcnews.go.com/Entertainment/wireStory/barrett-strong-motown-artist-money-dies-81-96755093)
 - RSS feed: http://feeds.abcnews.com/abcnews/topstories
 - date published: 2023-01-30 03:08:50+00:00
 - user: None

Barrett Strong was one of Motown&rsquo;s founding artists and most gifted songwriters.
