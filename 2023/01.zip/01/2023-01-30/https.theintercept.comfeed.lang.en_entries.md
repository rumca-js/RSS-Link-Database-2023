# Source The Intercept, Source URL:https://theintercept.com/feed/?lang=en, Source language: en-US

## New FTX Filing Pulls Back the Curtain on Sam Bankman-Fried’s Massive Influence Peddling Operation
 - [https://theintercept.com/2023/01/30/ftx-sam-bankman-fried-lobbying-pr/](https://theintercept.com/2023/01/30/ftx-sam-bankman-fried-lobbying-pr/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-30 22:19:54+00:00
 - user: None

<p>A bankruptcy filing revealed new information about how the crypto exchange spent money on consultants, think tanks, and business relationships.</p>
<p>The post <a href="https://theintercept.com/2023/01/30/ftx-sam-bankman-fried-lobbying-pr/" rel="nofollow">New FTX Filing Pulls Back the Curtain on Sam Bankman-Fried’s Massive Influence Peddling Operation</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## George Santos Benefactor Bankrolled Group Opposing LA's Progressive Prosecutor
 - [https://theintercept.com/2023/01/30/geoge-santos-donor-andrew-intrater-john-mckinney/](https://theintercept.com/2023/01/30/geoge-santos-donor-andrew-intrater-john-mckinney/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-30 17:15:20+00:00
 - user: None

<p>A big spender on right-wing causes, investor Andrew Intrater gave seed money to a group formed to oust a reform-minded district attorney.</p>
<p>The post <a href="https://theintercept.com/2023/01/30/geoge-santos-donor-andrew-intrater-john-mckinney/" rel="nofollow">George Santos Benefactor Bankrolled Group Opposing LA&#8217;s Progressive Prosecutor</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>
