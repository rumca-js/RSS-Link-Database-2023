# Source Fox News, Source URL:https://moxie.foxnews.com/google-publisher/latest.xml, Source language: en-US

## Vermont man accused of shooting WWII hero grandfather, murdering mom at sea demands grand jury minutes
 - [https://www.foxnews.com/us/vermont-man-accused-shooting-wwii-hero-grandfather-murdering-mom-at-sea-demands-grand-jury-minutes](https://www.foxnews.com/us/vermont-man-accused-shooting-wwii-hero-grandfather-murdering-mom-at-sea-demands-grand-jury-minutes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 23:03:09+00:00
 - user: None

Nathan Carman is requesting grand jury minutes in a federal murder trial involving the deaths of his mother and WWII hero grandfather in an inheritance plot.

## Russell Brand unleashes on new Biden chief of staff Jeff Zients: ‘Cronyism, corporatism, profiteering’
 - [https://www.foxnews.com/media/russell-brand-unleashes-new-biden-chief-of-staff-jeff-zients-cronyism-corporatism-profiteering](https://www.foxnews.com/media/russell-brand-unleashes-new-biden-chief-of-staff-jeff-zients-cronyism-corporatism-profiteering)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 23:00:54+00:00
 - user: None

Political commentator and comedian Russell Brand comments on President Biden's new chief of staff's apparent close ties to the pharmaceutical industry Saturday.

## South African tiger on the loose successfully captured
 - [https://www.foxnews.com/world/south-african-tiger-loose-successfully-captured](https://www.foxnews.com/world/south-african-tiger-loose-successfully-captured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 23:00:16+00:00
 - user: None

A South African tiger that was on the loose was successfully captured while roaming in a residential area. The tiger was shot Monday using darts containing sedatives.

## ‘Harry Potter’ star Rupert Grint says cast is ‘still trying to figure out what life looks like’
 - [https://www.foxnews.com/entertainment/harry-potter-star-rupert-grint-cast-still-trying-figure-what-life-looks-like](https://www.foxnews.com/entertainment/harry-potter-star-rupert-grint-cast-still-trying-figure-what-life-looks-like)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:53:56+00:00
 - user: None

Rupert Grint shared in a new interview that he and his castmates Daniel Radcliffe and Emma Watson are "still trying to figure out what life looks like" after starring in one of the biggest film series in history.

## Dead humpback whale found washed ashore in New York amid uptick in endangered whale deaths along East Coast
 - [https://www.foxnews.com/us/dead-humpback-whale-washed-ashore-new-york-endangered-deaths-east-coast](https://www.foxnews.com/us/dead-humpback-whale-washed-ashore-new-york-endangered-deaths-east-coast)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:48:01+00:00
 - user: None

A dead whale washed ashore in Long Island, New York, the latest whale to wash up along the East Coast in recent months

## Biden administration proposes expanding access to no-cost birth control under Obamacare
 - [https://www.foxnews.com/politics/biden-administration-proposes-expanding-access-no-cost-birth-control-obamacare](https://www.foxnews.com/politics/biden-administration-proposes-expanding-access-no-cost-birth-control-obamacare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:42:23+00:00
 - user: None

The Department of Health and Human Services proposed a new rule expanding birth control access on Monday by removing moral exemptions for providing contraceptive coverage.

## Brazil's former President Bolsonaro applies for U.S. tourist visa: reports
 - [https://www.foxnews.com/world/brazils-former-president-bolsonaro-applies-u-s-tourist-visa-reports](https://www.foxnews.com/world/brazils-former-president-bolsonaro-applies-u-s-tourist-visa-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:40:11+00:00
 - user: None

Former Brazilian President Jair Bolsonaro has applied for a six-month tourist visa in the United States to clear his head and take time off before deciding his next steps.

## Biden touts electric vehicle tax credits with picture of him in luxury Hummer that doesn't even qualify
 - [https://www.foxnews.com/politics/biden-touts-electric-vehicle-tax-credits-picture-him-luxury-hummer-doesnt-qualify](https://www.foxnews.com/politics/biden-touts-electric-vehicle-tax-credits-picture-him-luxury-hummer-doesnt-qualify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:39:53+00:00
 - user: None

President Biden touted his electric vehicle tax credit on Monday with him in an expensive GMC Hummer EV that doesn't even qualify for it as Americans continue to struggle with inflation.

## Suspect in Wisconsin double homicide arrested in Arkansas
 - [https://www.foxnews.com/us/suspect-wisconsin-double-homicide-arrested-arkansas](https://www.foxnews.com/us/suspect-wisconsin-double-homicide-arrested-arkansas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:35:18+00:00
 - user: None

A suspect in a Green Bay, Wisconsin, double homicide that occurred this weekend was arrested Monday in Arkansas, according to authorities.

## CNN labels Adam Schiff a Republican during rare clash on Russia collusion: 'That turned out not to be true'
 - [https://www.foxnews.com/media/cnn-labels-adam-schiff-republican-rare-clash-russia-collusion-turned-true](https://www.foxnews.com/media/cnn-labels-adam-schiff-republican-rare-clash-russia-collusion-turned-true)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:30:48+00:00
 - user: None

Rep. Adam Schiff, D-Calif., was mistakenly labeled a Republican while facing questions regarding his removal from the House Intelligence Committee on CNN Sunday.

## 49ers legend, Giants’ rookie Kayvon Thibodeaux trade barbs during NFC title game: ‘I don't know you'
 - [https://www.foxnews.com/sports/49ers-legend-giants-rookie-kayvon-thibodeaux-trade-barbs-during-nfc-title-game-i-dont-know-you](https://www.foxnews.com/sports/49ers-legend-giants-rookie-kayvon-thibodeaux-trade-barbs-during-nfc-title-game-i-dont-know-you)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:28:00+00:00
 - user: None

New York Giants rookie linebacker Kayvon Thibodeaux and Niners legend Joe Staley traded insults on Twitter Sunday after Thibodeaux took aim at San Francisco during the NFC title game.

## West Virginia advances public school mandate on 'In God We Trust'
 - [https://www.foxnews.com/us/west-virginia-advances-public-school-mandate-god-we-trust](https://www.foxnews.com/us/west-virginia-advances-public-school-mandate-god-we-trust)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:27:47+00:00
 - user: None

The West Virginia Senate advanced a bill requring public schools to display the phrase "In God We Trust" on every building. GOP Sen. Mike Azinger wants school pupils to put their hope in God.

## California sees more rain, snow, frost, wind post weekend weather system
 - [https://www.foxnews.com/us/california-sees-more-rain-snow-frost-wind-post-weekend-weather-system](https://www.foxnews.com/us/california-sees-more-rain-snow-frost-wind-post-weekend-weather-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:26:05+00:00
 - user: None

California sees more rain, snow, frost, and wind in the aftermath of the weekend weather system. The California Highway Patrol issued frost and freeze warnings.

## Indiana man arrested for 2018 shootings that killed 3
 - [https://www.foxnews.com/us/indiana-man-arrested-2018-shootings-killed-3](https://www.foxnews.com/us/indiana-man-arrested-2018-shootings-killed-3)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:21:34+00:00
 - user: None

Police in Fort Wayne, Indiana, arrested Jacquail Belcher, 29, on three counts of murder for the 2018 shootings of three men, according to the department.

## NYC still reports no measurable snowfall as January ends
 - [https://www.foxnews.com/us/nyc-reports-no-measurable-snowfall-january-ends](https://www.foxnews.com/us/nyc-reports-no-measurable-snowfall-january-ends)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:20:41+00:00
 - user: None

Despite hazardous blizzards reported upstate, New York City has gone without measurable snowfall for the longest period of time since 1973.

## Stars we've lost in 2023
 - [https://www.foxnews.com/entertainment/stars-weve-lost-2023](https://www.foxnews.com/entertainment/stars-weve-lost-2023)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:16:52+00:00
 - user: None

A photo gallery of the beloved stars lost in 2023.

## These 4 senators are the most likely to lose their seats in 2024
 - [https://www.foxnews.com/politics/these-4-democrat-senators-most-likely-lose-their-seats-2024](https://www.foxnews.com/politics/these-4-democrat-senators-most-likely-lose-their-seats-2024)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:14:11+00:00
 - user: None

A top non-partisan political handicapper predicts Democrats face a serious challenge holding on to four crucial Senate seats as they attempt to protect their razor-thin majority in 2024

## Scooby-Doo spinoff 'Velma' doesn't give cartoon character's sexuality 'depth' it 'needs,' magazine complains
 - [https://www.foxnews.com/media/scooby-doo-spinoff-velma-doesnt-give-cartoon-characters-sexuality-depth-needs-wired-complains](https://www.foxnews.com/media/scooby-doo-spinoff-velma-doesnt-give-cartoon-characters-sexuality-depth-needs-wired-complains)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:00:33+00:00
 - user: None

The low-rated Scooby-Doo spinoff series earned criticism from a left-wing critic for not adequately exploring the cartoon character's sexuality.

## Lori Lightfoot ripped for dancing in street as crime soars: 'Marie Antoinette of America's mayors'
 - [https://www.foxnews.com/media/lori-lightfoot-ripped-dancing-street-crime-soars-marie-antoinette-america-mayors](https://www.foxnews.com/media/lori-lightfoot-ripped-dancing-street-crime-soars-marie-antoinette-america-mayors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 22:00:04+00:00
 - user: None

Chicago Mayor Lori Lightfoot garnered intense criticism for dancing at a Lunar New Year parade as crime skyrockets throughout The Windy City.

## Ukraine to invest $550 million in drones, defense minister says
 - [https://www.foxnews.com/world/ukraine-invest-550-million-drones-defense-minister-says](https://www.foxnews.com/world/ukraine-invest-550-million-drones-defense-minister-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:54:31+00:00
 - user: None

Ukrainian Defense Minister Oleksii Reznikov said Monday the country is planning to invest nearly $550 million in drone manufacturing from domestic companies.

## Kentucky Gov. Beshear makes another appeal for education spending
 - [https://www.foxnews.com/politics/kentucky-gov-beshear-makes-another-appeal-education-spending](https://www.foxnews.com/politics/kentucky-gov-beshear-makes-another-appeal-education-spending)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:48:53+00:00
 - user: None

Democratic Kentucky Gov. Andy Beshear spoke on the state's teacher shortage Monday, and is expected to push the state legislature to increase education funding.

## Dozens of northern Texas-based flights cancelled over wintry weather
 - [https://www.foxnews.com/us/dozens-northern-texas-based-flights-cancelled-wintry-weather](https://www.foxnews.com/us/dozens-northern-texas-based-flights-cancelled-wintry-weather)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:47:50+00:00
 - user: None

Southwest and American Airlines canceled dozens of flights in northern Texas by early Monday afternoon as reports of inclement weather in the coming week began surfacing.

## Chiefs fan mocks Bengals’ loss on the House floor: ‘The Bungles’
 - [https://www.foxnews.com/politics/chiefs-fan-mocks-bengals-loss-house-floor-bungles](https://www.foxnews.com/politics/chiefs-fan-mocks-bengals-loss-house-floor-bungles)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:45:12+00:00
 - user: None

Rep. Mark Alford ripped the Cincinnati Bengals for penalties that cost them the AFC Championship Game on Sunday and mocked Cincinnati Mayor "Jabroni."

## Marshawn lynch puts camera crew through brutal beach workout: 'Get introduced to my world'
 - [https://www.foxnews.com/sports/marshawn-lynch-puts-camera-crew-through-brutal-beach-workout-get-introduced-my-world](https://www.foxnews.com/sports/marshawn-lynch-puts-camera-crew-through-brutal-beach-workout-get-introduced-my-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:39:39+00:00
 - user: None

Marshawn Lynch is different from most physically, and he's got the workouts and highlight reels to prove it. He put his camera crew through a workout to show them why.

## George Kittle has blunt take on 49ers' quarterback woes in NFC Championship Game
 - [https://www.foxnews.com/sports/george-kittle-has-blunt-take-49ers-quarterback-woes-nfc-championship-game](https://www.foxnews.com/sports/george-kittle-has-blunt-take-49ers-quarterback-woes-nfc-championship-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:31:58+00:00
 - user: None

San Francisco 49ers tight end George Kittle said it felt "pretty s-----" to have both quarterbacks go down with injuries in Sunday's NFC Championship Game.

## Ana Navarro claims Florida parents should be ‘more concerned’ with book bans than mom with an OnlyFans account
 - [https://www.foxnews.com/media/ana-navarro-claims-florida-parents-concerned-book-bans-mom-withan-onlyfans-account](https://www.foxnews.com/media/ana-navarro-claims-florida-parents-concerned-book-bans-mom-withan-onlyfans-account)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:30:34+00:00
 - user: None

Ana Navarro, co-host of "The View," said during Monday's episode that parents in Florida should be "more concerned" with the banning of books in the state.

## Arizona man charged with domestic violence murder of girlfriend: police
 - [https://www.foxnews.com/us/arizona-man-charged-murder-girlfriend-police](https://www.foxnews.com/us/arizona-man-charged-murder-girlfriend-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:28:26+00:00
 - user: None

A Chandler, Arizona 23-year-old man was arrested and charged with murdering his girlfriend back in December, according to police officials.

## Missouri mother convicted of killing her infant twins
 - [https://www.foxnews.com/us/missouri-mother-convicted-killing-infant-twins](https://www.foxnews.com/us/missouri-mother-convicted-killing-infant-twins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:27:05+00:00
 - user: None

A Missouri mother was convicted Friday of child endangerment and involuntary manslaughter of her infant twins. She planned to give the twins up for adoption until they died of hunger.

## Slain LSU student Madison Brooks remembered in obituary as living 'every day to the fullest'
 - [https://www.foxnews.com/us/slain-lsu-student-madison-brooks-remembered-obituary-living-every-day-fullest](https://www.foxnews.com/us/slain-lsu-student-madison-brooks-remembered-obituary-living-every-day-fullest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:22:46+00:00
 - user: None

Madison Brooks, 19, died early on Jan. 15, 2023, after she was struck by a car near her Baton Rouge, Louisiana, campus, shortly after she was allegedly raped.

## Pennsylvania jury acquits pro-life activist Mark Houck on charges of obstructing abortion clinic access
 - [https://www.foxnews.com/us/pennsylvania-jury-acquits-pro-life-activist-mark-houck-charges-obstructing-abortion-clinic-access](https://www.foxnews.com/us/pennsylvania-jury-acquits-pro-life-activist-mark-houck-charges-obstructing-abortion-clinic-access)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:09:48+00:00
 - user: None

A Pennsylvania jury acquitted a pro-life activist accused of assaulting a Planned Parenthood escort in 2021

## Sen. Tim Scott headed to Iowa in February, fueling more GOP presidential speculation
 - [https://www.foxnews.com/politics/2024-watch-sen-tim-scott-headed-iowa-february-fueling-more-gop-presidential-speculation](https://www.foxnews.com/politics/2024-watch-sen-tim-scott-headed-iowa-february-fueling-more-gop-presidential-speculation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:07:46+00:00
 - user: None

Sen. Tim Scott of South Carolina is heading to the state that for half a century's kicked off the presidential nominating calendar, sparking more 2024 presidential speculation

## CNN accused of publishing antisemitic cartoon: 'Flirts with ancient blood libel'
 - [https://www.foxnews.com/media/cnn-accused-publishing-antisemitic-cartoon-flirts-ancient-blood-libel](https://www.foxnews.com/media/cnn-accused-publishing-antisemitic-cartoon-flirts-ancient-blood-libel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:00:57+00:00
 - user: None

CAMERA, a media watchdog group, accused CNN of purposefully publishing a cartoon featuring antisemitic tropes in a piece about an Israeli artist.

## First GMC Hummer EV SUV auctioned for $500,000 as production begins
 - [https://www.foxnews.com/auto/first-gmc-hummer-ev-suv-500000-production-begins](https://www.foxnews.com/auto/first-gmc-hummer-ev-suv-500000-production-begins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 21:00:44+00:00
 - user: None

The first GMC Hummer EV SUV was auctioned for $500,000 to raise money for charity on Saturday night and production kicked off on Monday at GM's Factory Zero.

## Stephanie Seymour models her late son Harry Brant’s suit in new photoshoot: ‘It does help me with my grief’
 - [https://www.foxnews.com/entertainment/stephanie-seymour-models-late-son-harry-brants-suit-new-photoshoot](https://www.foxnews.com/entertainment/stephanie-seymour-models-late-son-harry-brants-suit-new-photoshoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:56:34+00:00
 - user: None

Harry Brant, a rising model and son of supermodel Stephanie Seymour and publisher Peter M. Brant, died in 2021. The cause of death for the 24-year-old was an accidental overdose.

## Massachusetts launches abortion hotline offering free legal advice
 - [https://www.foxnews.com/us/massachusetts-launches-abortion-hotline-offering-free-legal-advice](https://www.foxnews.com/us/massachusetts-launches-abortion-hotline-offering-free-legal-advice)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:51:09+00:00
 - user: None

Massachusetts launched a free legal advice hotline Monday, providing counsel to women seeking abortions. The hotline mirrors similar ones implemented in other blue states.

## Law enforcement groups skeptical police reform talks can succeed after Tyre Nichols death
 - [https://www.foxnews.com/politics/law-enforcement-groups-skeptical-police-reform-talks-succeed-tyre-nichols-death](https://www.foxnews.com/politics/law-enforcement-groups-skeptical-police-reform-talks-succeed-tyre-nichols-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:48:19+00:00
 - user: None

The nation's largest police organizations are willing to work with Congress to revive police reform negotiations following the death of Tyre Nichols, but are not optimistic anything will bear fruit.

## China urges Kevin McCarthy to avoid repeating Nancy Pelosi's trip to Taiwan
 - [https://www.foxnews.com/politics/china-urges-kevin-mccarthy-avoid-repeating-nancy-pelosis-trip-taiwan](https://www.foxnews.com/politics/china-urges-kevin-mccarthy-avoid-repeating-nancy-pelosis-trip-taiwan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:48:12+00:00
 - user: None

China's Foreign Ministry spokeswoman, Mao Ning, urged House Speaker Kevin McCarthy to avoid visiting Taiwan as his predecessor, Nancy Pelosi, did last year.

## Kansas City police find body in man's car after towing it
 - [https://www.foxnews.com/us/kansas-city-police-find-body-mans-car-towing-it](https://www.foxnews.com/us/kansas-city-police-find-body-mans-car-towing-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:46:43+00:00
 - user: None

The Kansas City police have found a body in the back of a man's car after towing it earlier this month. Officials are working to identify a suspect, but have yet to make an arrest.

## Florida baby girl found abandoned an hour after birth
 - [https://www.foxnews.com/us/florida-baby-girl-found-abandoned-hour-birth](https://www.foxnews.com/us/florida-baby-girl-found-abandoned-hour-birth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:44:59+00:00
 - user: None

A Florida baby girl still attached to a placenta was found wrappped in a blanket on a hill outside a trailer park Saturday. The child was brought to the hospital where is she stable.

## I just got back from Ukraine. Don't underestimate its people's determination to defeat Russia
 - [https://www.foxnews.com/opinion/ukraine-underestimate-peoples-determination-defeat-russia](https://www.foxnews.com/opinion/ukraine-underestimate-peoples-determination-defeat-russia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:43:46+00:00
 - user: None

I recently visited the city of Uzhhrod in western Ukraine. I was struck by the remarkable tenacity and resilience of the Ukrainian people. They are determined to resist this brutal war.

## South Carolina man convicted in fatal home attack
 - [https://www.foxnews.com/us/south-carolina-man-convicted-fatal-home-attack](https://www.foxnews.com/us/south-carolina-man-convicted-fatal-home-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:42:52+00:00
 - user: None

A South Carolina man has been convicted of a fatal home attack, riddling the residence with bullets. Maurice Wigfall was sentenced to 45 years for the killing and another five on a weapons offense.

## DOJ is 'working to brief' Senate Intel on Biden, Trump classified docs
 - [https://www.foxnews.com/politics/doj-working-brief-senate-intel-biden-trump-classified-docs](https://www.foxnews.com/politics/doj-working-brief-senate-intel-biden-trump-classified-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:41:42+00:00
 - user: None

DOJ says it is working with the intelligence community before briefing the Senate Intelligence Committee on the improper retention of classified records by Biden and Trump.

## Mexican rural confrontation leaves 2 officers, 3 civilians dead
 - [https://www.foxnews.com/world/mexican-rural-confrontation-leaves-2-officers-3-civilians-dead](https://www.foxnews.com/world/mexican-rural-confrontation-leaves-2-officers-3-civilians-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:39:20+00:00
 - user: None

A Mexican rural confrontation over the weekend resulted in the deaths of two officers and three civilians. Residents of southern Mexico took action regarding complaints of police brutality.

## North Carolina reporter, spokesperson Dick Ellis dies at 78
 - [https://www.foxnews.com/us/north-carolina-reporter-spokesperson-dick-ellis-dies-78](https://www.foxnews.com/us/north-carolina-reporter-spokesperson-dick-ellis-dies-78)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:36:13+00:00
 - user: None

A North Carolina reporter and spokesperson Dick Ellis died at age 78 from cancer on Saturday at the VA Medical Center in Durham. Ellis worked as a press secretary for state governors.

## California man who drove Tesla off cliff with wife, 2 kids inside transported to jail from hospital
 - [https://www.foxnews.com/us/california-man-who-drove-tesla-off-cliff-wife-2-kids-inside-transported-jail-hospital](https://www.foxnews.com/us/california-man-who-drove-tesla-off-cliff-wife-2-kids-inside-transported-jail-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:33:22+00:00
 - user: None

Dharmesh Patel, the California man accused of driving his wife and two children off a cliff on Jan. 2, has been transported from the hospital to a San Mateo County jail.

## Michigan teen Adriana Davidson found dead 4 days after mysterious disappearance
 - [https://www.foxnews.com/us/michigan-teen-adrianna-davidson-found-dead-4-days-mysterious-disappearance-search-family-says](https://www.foxnews.com/us/michigan-teen-adrianna-davidson-found-dead-4-days-mysterious-disappearance-search-family-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:31:48+00:00
 - user: None

Michigan authorities have located deceased 15-year-old Adriana Davidson, who was last seen near Pioneer High School in Ann Arbor on the morning of Jan. 27.

## House Oversight chair calls for reform on handling of classified docs: 'There's a problem'
 - [https://www.foxnews.com/politics/house-oversight-chair-calls-reform-handling-classified-docs-problem](https://www.foxnews.com/politics/house-oversight-chair-calls-reform-handling-classified-docs-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:31:37+00:00
 - user: None

House Oversight Chairman James Comer, R-Ky., outlined what he plans to discuss with the National Archives Tuesday during a closed deposition.

## Christmas, Easter removed from London School of Economics academic calendar: 'Church of woke' has taken over
 - [https://www.foxnews.com/world/christmas-easter-removed-london-school-economics-academic-calendar-church-woke-has-taken-over](https://www.foxnews.com/world/christmas-easter-removed-london-school-economics-academic-calendar-church-woke-has-taken-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:28:47+00:00
 - user: None

The London School of Economics in the U.K. is stripping historical Christian terms from its academic calendar in an effort to promote an "international" atmosphere at the school.

## Texas budget surplus may hand homeowners a tax break
 - [https://www.foxnews.com/politics/texas-budget-surplus-may-hand-homeowners-tax-break](https://www.foxnews.com/politics/texas-budget-surplus-may-hand-homeowners-tax-break)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:26:51+00:00
 - user: None

A planned increase in Texas' homestead exemption could potentially save homeowners thousands of dollars over the lifetime of their homes.

## Missing Pennsylvania man identified 37 years after his skull was found along riverbank
 - [https://www.foxnews.com/us/missing-pennsylvania-man-identified-37-years-after-his-skull-was-found-along-riverbank](https://www.foxnews.com/us/missing-pennsylvania-man-identified-37-years-after-his-skull-was-found-along-riverbank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:24:38+00:00
 - user: None

Detectives in Bucks County, Pennsylvania, worked with a private forensic DNA lab to identify a skull found nearly four decades ago as belonging to Richard Thomas Alt.

## Travis Kelce takes final shot at Cincinnati mayor, says city was better when Jerry Springer was in office
 - [https://www.foxnews.com/sports/travis-kelce-takes-final-shot-cincinnati-mayor-city-better-jerry-springer-in-office](https://www.foxnews.com/sports/travis-kelce-takes-final-shot-cincinnati-mayor-city-better-jerry-springer-in-office)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:24:06+00:00
 - user: None

Kansas City Chiefs tight end Travis Kelce barked back at Cincinnati Mayor Aftab Pureval after winning the AFC Championship over the Bengals, and left with one final comment post-game.

## Idaho murders suspect Bryan Kohberger's lawyer also represented Maddie Mogen's parents
 - [https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohbergers-lawyer-also-represented-maddie-mogens-parents](https://www.foxnews.com/us/idaho-murders-suspect-bryan-kohbergers-lawyer-also-represented-maddie-mogens-parents)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:20:03+00:00
 - user: None

Kootenai County Public Defender Anne Taylor is representing Idaho student stabbings suspect Bryan Kohberger -- but she has ties to two victims' families.

## Chris Pratt's ex-wife, Anna Faris, goes nude for upcoming Super Bowl 2023 commercial
 - [https://www.foxnews.com/entertainment/chris-pratts-ex-wife-anna-faris-nude-upcoming-super-bowl-2023-commercial](https://www.foxnews.com/entertainment/chris-pratts-ex-wife-anna-faris-nude-upcoming-super-bowl-2023-commercial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:15:35+00:00
 - user: None

Anna Faris, 46, revealed why she thinks she could join "a nudist colony" after stripping down for her first Super Bowl ad.

## White House silent on police policy after Tyre Nichols death, one year after Biden’s ‘significant’ reforms
 - [https://www.foxnews.com/politics/white-house-silent-police-policy-tyre-nichols-death-one-year-bidens-significant-reforms](https://www.foxnews.com/politics/white-house-silent-police-policy-tyre-nichols-death-one-year-bidens-significant-reforms)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:13:43+00:00
 - user: None

The White House is silent on whether it will pursue additional accountability measures for law enforcement after President Biden signed an executive order last year.

## Schiff, Whitehouse slam Meta for decision to allow Trump back on Facebook, Instagram: ‘Inexplicable’
 - [https://www.foxnews.com/politics/schiff-whitehouse-slam-meta-decision-allow-trump-back-facebook-instagram-inexplicable](https://www.foxnews.com/politics/schiff-whitehouse-slam-meta-decision-allow-trump-back-facebook-instagram-inexplicable)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:06:59+00:00
 - user: None

Top Democrats are demanding Meta provide answers on why it reinstated former President Trump to Facebook and Instagram, calling it “inexplicable.”

## Mark Meadows-backed failed GOP House candidate to plead guilty to DOJ campaign finance allegations: reports
 - [https://www.foxnews.com/politics/mark-meadows-backed-failed-gop-house-candidate-plead-guilty-doj-campaign-finance-allegations-reports](https://www.foxnews.com/politics/mark-meadows-backed-failed-gop-house-candidate-plead-guilty-doj-campaign-finance-allegations-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:06:43+00:00
 - user: None

Lynda Bennett, backed by Mark Meadows to succeed him in North Carolina’s 11th Congressional District, allegedly illegally accepted a $25,000 campaign contribution from a family member.

## California Tesla driver arrested after video captures road rage attack, authorities say
 - [https://www.foxnews.com/us/california-tesla-driver-arrested-video-captures-road-rage-attack](https://www.foxnews.com/us/california-tesla-driver-arrested-video-captures-road-rage-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:03:22+00:00
 - user: None

A Tesla driver captured on camera assaulting a vehicle during a Los Angeles-area road rage incident has been arrested, authorities said.

## House Judiciary Committee hearing on border crisis to feature law enforcement, fentanyl victims group
 - [https://www.foxnews.com/politics/house-judiciary-committee-hearing-border-crisis-feature-law-enforcement-fentanyl-victims-group](https://www.foxnews.com/politics/house-judiciary-committee-hearing-border-crisis-feature-law-enforcement-fentanyl-victims-group)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:02:32+00:00
 - user: None

The House Judiciary Committee will hold its first hearing on President Biden’s “border crisis,” Fox News Digital has learned.

## Eagles’ Jalen Hurts says he relied on faith to overcome doubt: ‘They probably didn’t even want to draft me”
 - [https://www.foxnews.com/sports/eagles-jalen-hurts-relied-faith-overcome-doubt-they-probably-didnt-even-want-draft-me](https://www.foxnews.com/sports/eagles-jalen-hurts-relied-faith-overcome-doubt-they-probably-didnt-even-want-draft-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:02:29+00:00
 - user: None

Philadelphia Eagles quarterback Jalen Hurts revealed during his presser Sunday that in his rookie season, he felt “they probably didn’t even want to draft me here.”

## Man recieves pre-trial imprisonment for killing church officer, injuring 4 during Algeciras attack
 - [https://www.foxnews.com/world/man-recieves-pre-trial-imprisonment-killing-church-officer-injuring-4-during-algeciras-attack](https://www.foxnews.com/world/man-recieves-pre-trial-imprisonment-killing-church-officer-injuring-4-during-algeciras-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:01:42+00:00
 - user: None

A man suspected of killing a church officer and injuring four others during a machete attack will be jailed until his trial for terrorism. The judge approved a request for no bail.

## 'Barbaric' Minnesota abortion bill lambasted by state senator: 'Future generations will look back in horror'
 - [https://www.foxnews.com/media/barbaric-minnesota-abortion-bill-lambasted-state-senator-future-generations-look-back-ihorror](https://www.foxnews.com/media/barbaric-minnesota-abortion-bill-lambasted-state-senator-future-generations-look-back-ihorror)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:00:33+00:00
 - user: None

Republican State Sen. Julia Coleman called the new abortion legislation "dangerous" and criticized Democrats for denying Republicans' efforts to make the bill more moderate.

## Victims of Iowa van crash identified as 3 children, 1 adult
 - [https://www.foxnews.com/us/victims-iowa-van-crash-identified-3-children-1-adult](https://www.foxnews.com/us/victims-iowa-van-crash-identified-3-children-1-adult)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 20:00:14+00:00
 - user: None

The victims of a deadly northern Iowa van crash that occurred Friday were identified as Ervin J. Borntreger, 22, and Marlin, Rebecca and Emma Borntreger, aged one to four.

## Three sloth bears die in freezing temperatures after plane grounded at Belgium airport: report
 - [https://www.foxnews.com/world/three-sloth-bears-die-freezing-temperatures-plane-grounded-belgium-airport-report](https://www.foxnews.com/world/three-sloth-bears-die-freezing-temperatures-plane-grounded-belgium-airport-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:58:41+00:00
 - user: None

Three sloth bears reportedly have died in Belgium after the cargo plane they were being transported in was grounded during a winter storm.

## Maine mails out heat subsidies as sub-zero temps persist
 - [https://www.foxnews.com/us/maine-mails-heat-subsidies-sub-zero-temps-persist](https://www.foxnews.com/us/maine-mails-heat-subsidies-sub-zero-temps-persist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:58:40+00:00
 - user: None

Maine has begun mailing residents their first energy cost relief payments as temperatures this week are anticipated to drop past ten degrees below zero.

## A handful of Republicans may save Ilhan Omar's committee seat
 - [https://www.foxnews.com/politics/handful-republicans-save-ilhan-omars-committee-seat](https://www.foxnews.com/politics/handful-republicans-save-ilhan-omars-committee-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:56:04+00:00
 - user: None

A handful of Republicans may wind up saving Rep. Ilhan Omar’s, D-Minn., House Foreign Affairs Committee seat amid Speaker Kevin McCarthy attempt to remove her.

## Illegal migrants refuse to leave NYC hotel for Brooklyn migrant relief center, sleep in the street
 - [https://www.foxnews.com/politics/illegal-migrants-refuse-leave-nyc-hotel-brooklyn-migrant-relief-center-sleep-street](https://www.foxnews.com/politics/illegal-migrants-refuse-leave-nyc-hotel-brooklyn-migrant-relief-center-sleep-street)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:53:34+00:00
 - user: None

Several illegal migrants are refusing to leave their temporary placement at the Watson Hotel in New York City for a migrant relief center.

## Alec Baldwin to be formally charged in fatal 'Rust' shooting
 - [https://www.foxnews.com/entertainment/alec-baldwin-formally-charged-fatal-rust-shooting](https://www.foxnews.com/entertainment/alec-baldwin-formally-charged-fatal-rust-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:44:49+00:00
 - user: None

The New Mexico First Judicial District Attorney's Office will formally file charges against Alec Baldwin on Tuesday in connection to the death of "Rust" cinematographer Halyna Hutchins.

## House pushing to end COVID emergency status, endangering Biden legal case for student loan plan
 - [https://www.foxnews.com/politics/house-pushing-end-covid-emergency-status-endangering-biden-student-loan-plan](https://www.foxnews.com/politics/house-pushing-end-covid-emergency-status-endangering-biden-student-loan-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:38:17+00:00
 - user: None

The House is expected to vote to end the COVID public health emergency, undermining the Biden administration's legal argument for its student loan forgiveness program.

## South Korea drops indoor mask mandate, but many continue to wear them as concerns linger
 - [https://www.foxnews.com/health/south-korea-drops-indoor-mask-mandate-many-continue-wear-them-concerns-linger](https://www.foxnews.com/health/south-korea-drops-indoor-mask-mandate-many-continue-wear-them-concerns-linger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:28:56+00:00
 - user: None

South Korea has scrapped its mask requirement for most indoor public places. However, residents are still wearing coverings voluntarily as fears of infections linger.

## Bystander wounded in Arizona RV park police shootout
 - [https://www.foxnews.com/us/bystander-wounded-arizona-rv-park-police-shootout](https://www.foxnews.com/us/bystander-wounded-arizona-rv-park-police-shootout)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:26:14+00:00
 - user: None

A bystander was wounded in an Arizona RV park police shootout on Friday. Officials were investigating reports of a man in a bulletproof vest pointing a gun at people.

## Roadside bomb targeting Syrian police wounds 15 officers
 - [https://www.foxnews.com/world/roadside-bomb-targeting-syrian-police-wounds-15-officers](https://www.foxnews.com/world/roadside-bomb-targeting-syrian-police-wounds-15-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:22:23+00:00
 - user: None

In Syria, 15 officers were injured after a bomb targeting Syrian police exploded. The officers were returning to the country's capital, Damascus.

## All countries are dangerously unprepared for future outbreaks, IFRC reports
 - [https://www.foxnews.com/world/all-countries-dangerously-unprepared-future-outbreaks-ifrc-reports](https://www.foxnews.com/world/all-countries-dangerously-unprepared-future-outbreaks-ifrc-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:19:13+00:00
 - user: None

The International Federation of the Red Cross reported that every country is dangerously vulnerable to future outbreaks and pandemics.

## WHO seeks to expand role in tackling next global health emergency, but faces funding issues
 - [https://www.foxnews.com/health/who-seeks-expand-role-tackling-next-global-health-emergency-faces-funding-issues](https://www.foxnews.com/health/who-seeks-expand-role-tackling-next-global-health-emergency-faces-funding-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:18:43+00:00
 - user: None

The World Health Organization is seeking to expand its role as the world’s leading health body. However, under-funded WHO must also tackle its budgeting issues.

## Manhattan DA begins presenting evidence in Trump-Stormy Daniels case before grand jury
 - [https://www.foxnews.com/politics/manhattan-da-begins-presenting-evidence-trump-stormy-daniels-case-grand-jury](https://www.foxnews.com/politics/manhattan-da-begins-presenting-evidence-trump-stormy-daniels-case-grand-jury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:13:10+00:00
 - user: None

A grand jury in New York is hearing testimony on Donald Trump's hand in hush payments to Stormy Daniels, indicating the DA is nearing a decision on whether to charge Trump.

## Missing Michigan teen Adriana Davidson last seen 4 days ago after phone found at school
 - [https://www.foxnews.com/us/missing-michigan-teen-adriana-davidson-last-seen-4-days-ago-phone-found-school](https://www.foxnews.com/us/missing-michigan-teen-adriana-davidson-last-seen-4-days-ago-phone-found-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:09:11+00:00
 - user: None

Adriana Davidson, a missing teenager, was last seen near Pioneer High School in Ann Arbor, Michigan, on Friday, Jan. 27. Her phone was found near the school's tennis courts.

## China says its COVID situation is now at a 'low level' following Lunar New Year
 - [https://www.foxnews.com/health/china-says-covid-situation-now-low-level-following-lunar-new-year](https://www.foxnews.com/health/china-says-covid-situation-now-low-level-following-lunar-new-year)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:05:57+00:00
 - user: None

China said its coronavirus situation is now at a low level with a decrease of 40% in clinic visits post Lunar New Year. No mutant strains have been identified either, according to CDC.

## San Francisco reparations proposal would destroy city's budget, supervisors caution
 - [https://www.foxnews.com/politics/san-francisco-reparations-proposal-would-destroy-citys-budget-supervisors-caution](https://www.foxnews.com/politics/san-francisco-reparations-proposal-would-destroy-citys-budget-supervisors-caution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:04:59+00:00
 - user: None

A San Francisco reparations proposal that would give $5 million to each qualifying Black resident, would not be possible with current budgetary constraints, officials said.

## Indonesia local trader forged ingredient label that may have led to cough syrup deaths of 200 kids
 - [https://www.foxnews.com/health/indonesia-local-trader-forged-ingredient-label-led-cough-syrup-deaths-200-kids](https://www.foxnews.com/health/indonesia-local-trader-forged-ingredient-label-led-cough-syrup-deaths-200-kids)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:04:43+00:00
 - user: None

Industrial-grade chemicals were sold as pharmaceutical-grade by a local trader in Indonesia. The ingredients found in cough syrups may have led to the deaths of 200 kids.

## Whoopi Goldberg asks if 'we need to see White people get beat up' to see change, then quickly clarifies
 - [https://www.foxnews.com/media/whoopi-goldberg-asks-if-we-need-see-white-people-get-beat-up-see-change-then-quickly-clarifies](https://www.foxnews.com/media/whoopi-goldberg-asks-if-we-need-see-white-people-get-beat-up-see-change-then-quickly-clarifies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:02:11+00:00
 - user: None

Whoopi Goldberg asked during "The View" on Monday if "we need to see white people get beat up" to see police reform following the death of Tyre Nichols.

## DOJ tells Jordan disclosing info on Biden documents probe to Congress would jeopardize investigation
 - [https://www.foxnews.com/politics/doj-tells-jordan-disclosing-info-biden-documents-probe-congress-jeopardize-investigation](https://www.foxnews.com/politics/doj-tells-jordan-disclosing-info-biden-documents-probe-congress-jeopardize-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:01:59+00:00
 - user: None

The Justice Department on Monday told House Judiciary Committee Chairman Jim Jordan that it could not disclose information related to the special counsel investigation into President Biden’s improper retention of classified documents, warning it could jeopardize the probe.

## ‘Remember the Titans’ writer Gregory Allen Howard dies at age 70
 - [https://www.foxnews.com/us/remember-titans-writer-gregory-allen-howard-dies-age-70](https://www.foxnews.com/us/remember-titans-writer-gregory-allen-howard-dies-age-70)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:01:53+00:00
 - user: None

Gregory Allen Howard, who wrote “Remember the Titans,” died of heart failure on Friday in Miami. He was the first Black screenwriter to write a drama that passed $100 million.

## Sam Smith’s music video with nipple pasties and corsets breaks Twitter: 'Degenerate Hollywood culture'
 - [https://www.foxnews.com/media/sam-smiths-music-video-nipple-pasties-corsets-twitter-degenerate-hollywood-culture](https://www.foxnews.com/media/sam-smiths-music-video-nipple-pasties-corsets-twitter-degenerate-hollywood-culture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 19:00:16+00:00
 - user: None

The British singer-songwriter divided Twitter after posting a music video in which Smith dances suggestively in a corset with nipple pasties covered in liquid.

## Belarus' president arrives in Zimbabwe to cement economic, political ties between the Russian allies
 - [https://www.foxnews.com/world/belarus-president-arrives-zimbabwe-cement-economic-political-ties-between-russian-allies](https://www.foxnews.com/world/belarus-president-arrives-zimbabwe-cement-economic-political-ties-between-russian-allies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:59:35+00:00
 - user: None

Alexander Lukashenko arrived in Zimbabwe on Monday to cement the economic and political ties between Belarus and its fellow Russian ally. He was met with pomp and fanfare.

## HI firefighter injured after getting swept through storm drain, carried through length of 8 football fields
 - [https://www.foxnews.com/us/hi-firefighter-injured-getting-swept-storm-drain-carried-length-8-football-fields](https://www.foxnews.com/us/hi-firefighter-injured-getting-swept-storm-drain-carried-length-8-football-fields)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:59:07+00:00
 - user: None

A Hawaii firefighter became critically injured after he was swept into a 4-foot storm drain for 800 yards. He landed on the shoreline where the storm drain empties.

## Tony Romo faces scrutiny over Michael Jordan, Clyde Drexler comparison in AFC title game
 - [https://www.foxnews.com/sports/tony-romo-faces-scrutiny-michael-jordan-clyde-drexler-comparison-afc-title-game](https://www.foxnews.com/sports/tony-romo-faces-scrutiny-michael-jordan-clyde-drexler-comparison-afc-title-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:55:58+00:00
 - user: None

NFL broadcaster Tony Romo had people scratching their heads with a comparison he made during the AFC Championship on Sunday night.

## Cowboys' Micah Parsons calls out Bengals' Germaine Pratt over postgame outburst
 - [https://www.foxnews.com/sports/cowboys-micah-parsons-calls-out-bengals-germaine-pratt-over-postgame-outburst](https://www.foxnews.com/sports/cowboys-micah-parsons-calls-out-bengals-germaine-pratt-over-postgame-outburst)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:55:03+00:00
 - user: None

Dallas Cowboys pass rusher Micah Parsons called out Bengals linebacker Germaine Pratt after his postgame outburst towards Joseph Ossai went viral following Ossai's late hit on Mahomes.

## Missing Maryland woman’s body found in park a month after disappearing, police investigating as murder
 - [https://www.foxnews.com/us/missing-maryland-womans-body-found-park-month-disappearing-police-investigating-murder](https://www.foxnews.com/us/missing-maryland-womans-body-found-park-month-disappearing-police-investigating-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:53:20+00:00
 - user: None

The body of 20-year-old Keylin Yolibeth Chavez-Dominguez was found Saturday in a park in Montgomery County, Maryland, nearly a month after she disappeared.

## Cincinnati mayor reacts to Travis Kelce's 'jabroni' jab: 'Deserved that'
 - [https://www.foxnews.com/sports/cincinnati-mayor-reacts-travis-kelces-jabroni-jab-deserved-that](https://www.foxnews.com/sports/cincinnati-mayor-reacts-travis-kelces-jabroni-jab-deserved-that)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:51:07+00:00
 - user: None

Cincinnati Mayor Aftab Pureval admitted he deserved the jawing from Travis Kelce after the Kansas City Chiefs defeated the Bengals in the AFC Championship.

## New Jersey synagogues increase security following attempted arson attack
 - [https://www.foxnews.com/us/new-jersey-synagogues-increase-security-following-attempted-arson-attack](https://www.foxnews.com/us/new-jersey-synagogues-increase-security-following-attempted-arson-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:44:57+00:00
 - user: None

New Jersey synagogues are receiving added security resources from local police departments following an attempted arson attack on a temple early Sunday morning.

## 'Defund the police' advocates playing 'bait-and-switch game' to push narrative, civil rights activist says
 - [https://www.foxnews.com/media/defund-police-advocates-playing-bait-switch-game-push-narrative-civil-rights-activist-says](https://www.foxnews.com/media/defund-police-advocates-playing-bait-switch-game-push-narrative-civil-rights-activist-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:43:58+00:00
 - user: None

Dr. Bob Woodson addresses demands for police reform following the death Tyre Nichols, arguing 'you can't do anything positive by attacking the police.'

## Utah lawmaker accused of 'intimidating' police officers who arrested his son
 - [https://www.foxnews.com/politics/utah-lawmaker-accused-intimidating-police-officers-arrested-son](https://www.foxnews.com/politics/utah-lawmaker-accused-intimidating-police-officers-arrested-son)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:41:02+00:00
 - user: None

Footage shows Utah lawmaker Bruce Adams berating officers who arrested his son on a burglary warrant last year, with one officer saying Adams was attempting to "intimidate."

## Catholic civil rights group asks for House GOP probe into pro-abortion extremist group Jane's Revenge
 - [https://www.foxnews.com/politics/catholic-civil-rights-group-asks-house-gop-probe-pro-abortion-extremist-group-janes-revenge](https://www.foxnews.com/politics/catholic-civil-rights-group-asks-house-gop-probe-pro-abortion-extremist-group-janes-revenge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:36:48+00:00
 - user: None

Catholic League president Bill Donohue asked Rep. Jim Jordan, R-Ohio, to launch a House Judiciary Committee probe into the DOJ's "reluctance" to pursue those targeting pro-life centers.

## No plans for Hunter Biden to appear before House Oversight Committee 'right now,' says Chairman James Comer
 - [https://www.foxnews.com/politics/no-plans-for-hunter-biden-appear-before-house-oversight-committee-right-now-says-chairman-james-comer](https://www.foxnews.com/politics/no-plans-for-hunter-biden-appear-before-house-oversight-committee-right-now-says-chairman-james-comer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:34:21+00:00
 - user: None

Investigating the questionable business dealings of the Biden family is one of the top priorities of the House Oversight Committee, according Chairman James Comer, R-Ky.

## France buys new masterpiece 'Boating Party' for Orsay museum at $47 million
 - [https://www.foxnews.com/world/france-buys-new-masterpiece-boating-party-orsay-museum-47-million](https://www.foxnews.com/world/france-buys-new-masterpiece-boating-party-orsay-museum-47-million)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:25:03+00:00
 - user: None

France has acquired a 19th-century Impressionist masterpiece for the Orsay museum. “Boating Party” by Gustave Caillebotte was bought with $47 million.

## Tyre Nichols' parents, Monterey Park shooting hero Brandon Tsay invited to State of the Union
 - [https://www.foxnews.com/politics/tyre-nichols-parents-monterey-park-shooting-hero-brandon-tsay-invited-state-union](https://www.foxnews.com/politics/tyre-nichols-parents-monterey-park-shooting-hero-brandon-tsay-invited-state-union)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:24:41+00:00
 - user: None

Tyre Nichols' parents and Brandon Tsay, who has emerged as a hero in the wake of the Monterey Park, California mass shooting, are expected to attend the State of the Union speech.

## Americans cite government as top problem facing the nation, inflation second in new poll
 - [https://www.foxnews.com/politics/americans-government-top-problem-facing-nation-inflation-second-new-poll](https://www.foxnews.com/politics/americans-government-top-problem-facing-nation-inflation-second-new-poll)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:24:15+00:00
 - user: None

A new Gallup poll shows U.S. adults view the government and poor leadership as the top problem facing the country, followed closely by inflation.

## Australia, France announce plans to jointly send several thousand artillery shells to Ukraine
 - [https://www.foxnews.com/world/australia-france-announce-plans-jointly-send-several-thousand-artillery-shells-ukraine](https://www.foxnews.com/world/australia-france-announce-plans-jointly-send-several-thousand-artillery-shells-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:24:11+00:00
 - user: None

A multimillion-dollar plan to send artillery shells to Ukraine has been announced by Australia and France. The announcement comes nearly a year into Russia's war with Ukraine.

## Indiana officers shoot, critically wound man following police chase
 - [https://www.foxnews.com/us/indiana-officers-shoot-critically-wound-police-chase](https://www.foxnews.com/us/indiana-officers-shoot-critically-wound-police-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:17:36+00:00
 - user: None

Indianapolis officers shot a man during a police chase that ended in a crash. The man was critically wounded in the shooting. The man allegedly shot a woman before the chase.

## Top Republican slams Kamala Harris for hollow 'PR stunt' touting admin's small business wins
 - [https://www.foxnews.com/politics/top-republican-slams-kamala-harris-hollow-pr-stunt-touting-admins-small-business-wins](https://www.foxnews.com/politics/top-republican-slams-kamala-harris-hollow-pr-stunt-touting-admins-small-business-wins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:12:23+00:00
 - user: None

The chair of the House Small Business committee slammed Vice President Kamala Harris’ speech Monday on the administration's investments in small business in North Carolina as a "PR stunt."

## Florida bill could hand gun owners huge win, make the US a constitutional carry majority country
 - [https://www.foxnews.com/us/florida-bill-could-gun-owners-huge-win-us-constitutional-carry-majority-country](https://www.foxnews.com/us/florida-bill-could-gun-owners-huge-win-us-constitutional-carry-majority-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:05:37+00:00
 - user: None

Florida Republicans introduced a constitutional carry bill on Monday, which could tip the U.S. to having a majority of states with permitless carry if the bill is signed into law.

## French Prime Minister Borne announces plan to defeat racism, anti-Semitism, and discrimination of all kinds
 - [https://www.foxnews.com/world/french-prime-minister-borne-announces-plan-defeat-racism-anti-semitism-discrimination-kind](https://www.foxnews.com/world/french-prime-minister-borne-announces-plan-defeat-racism-anti-semitism-discrimination-kind)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:04:35+00:00
 - user: None

A plan to defeat anti-Semitism, racism, and discrimination of all kinds has been announced by French Prime Minister Elisabeth Borne. Borne claimed, "Hate has reinvented itself."

## Wilmington Police Department in NC adds jiu-jitsu to officers’ training
 - [https://www.foxnews.com/us/wilmington-police-department-nc-adds-jiu-jitsu-officers-training](https://www.foxnews.com/us/wilmington-police-department-nc-adds-jiu-jitsu-officers-training)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:00:49+00:00
 - user: None

Each officer in Wilmington, North Carolina, is now receiving at least four hours of jiu-jitsu training as part of a method to instill control and composure among law enforcement.

## A 24-year-old millionaire responds after internet erupts at Lamborghini claims: 'Not some ignorant little kid'
 - [https://www.foxnews.com/media/24-year-millionaire-responds-internet-erupts-lamborghini-claims-ignorant-little-kid](https://www.foxnews.com/media/24-year-millionaire-responds-internet-erupts-lamborghini-claims-ignorant-little-kid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 18:00:23+00:00
 - user: None

24-year-old finance YouTuber and self-made millionaire Sebastian Ghiorghiu sparked debate after claiming men in their 20s should be able to afford a Lamborghini.

## NM loses 3rd public education secretary in 4 years
 - [https://www.foxnews.com/politics/nm-loses-3rd-public-education-secretary-4-years](https://www.foxnews.com/politics/nm-loses-3rd-public-education-secretary-4-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:59:40+00:00
 - user: None

New Mexico has lost its third public education secretary in the last four years. Kurt Steinhaus said he wanted to retire to focus on family and his health.

## WV State Wildlife Center to host annual Groundhog Day event
 - [https://www.foxnews.com/us/wv-state-wildlife-center-host-annual-groundhog-day-event](https://www.foxnews.com/us/wv-state-wildlife-center-host-annual-groundhog-day-event)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:58:54+00:00
 - user: None

Groundhog French Creek Freddie will emerge from his den to predict whether winter will continue for another six weeks at West Virginia’s annual Groundhog Day.

## NC shooting leaves 1 dead, 2 injured
 - [https://www.foxnews.com/us/nc-shooting-leaves-1-dead-2-injured](https://www.foxnews.com/us/nc-shooting-leaves-1-dead-2-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:58:19+00:00
 - user: None

A shooting outside a building in North Carolina has left one person dead and two others critically injured. Preliminary investigation suggests an argument led to the shooting.

## John Newbery Medal for the year's best children's book awarded to Amina Luqman-Dawson's 'Freewater'
 - [https://www.foxnews.com/us/john-newbery-medal-years-best-childrens-book-awarded-amina-luqman-dawsons-freewater](https://www.foxnews.com/us/john-newbery-medal-years-best-childrens-book-awarded-amina-luqman-dawsons-freewater)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:57:56+00:00
 - user: None

The John Newbery Medal for the year's best children's book has been awarded to "Freewater". The novel by Amina Luqman-Dawson is about a secret community of formerly enslaved people.

## Man accused of killing New Hampshire couple during walk scheduled to face trial in July
 - [https://www.foxnews.com/us/man-accused-killing-new-hampshire-couple-during-walk-scheduled-face-trial-july](https://www.foxnews.com/us/man-accused-killing-new-hampshire-couple-during-walk-scheduled-face-trial-july)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:57:29+00:00
 - user: None

Logan Clegg is set to face trial in July for allegedly killing two people in New Hampshire. The couple who was murdered was on a walk on a hiking trail.

## Shania Twain says ‘forget the sag’ after posing nude for first time, reveals plastic surgery plans
 - [https://www.foxnews.com/entertainment/shania-twain-forget-sag-posing-nude-first-time-reveals-plastic-surgery-plans](https://www.foxnews.com/entertainment/shania-twain-forget-sag-posing-nude-first-time-reveals-plastic-surgery-plans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:43:40+00:00
 - user: None

Shania Twain reveals if she'd ever consider plastic surgery after posing nude for the first time. The singer is releasing her latest album Feb. 3.

## 'Black alien' who mutilated his body says restaurants refuse to serve him
 - [https://www.foxnews.com/media/black-alien-who-mutilated-his-body-says-restaurants-refuse-serve-him](https://www.foxnews.com/media/black-alien-who-mutilated-his-body-says-restaurants-refuse-serve-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:42:30+00:00
 - user: None

The 'black alien,' who mutilated his body with voluntary surgeries to become less Earthly, says restaurants refuse to serve him over his extreme physique.

## Brooklyn DA investigating alleged forgeries, favoritism tied to Democratic Party
 - [https://www.foxnews.com/politics/brooklyn-da-investigating-alleged-forgeries-favoritism-tied-democratic-party](https://www.foxnews.com/politics/brooklyn-da-investigating-alleged-forgeries-favoritism-tied-democratic-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:33:35+00:00
 - user: None

The Brooklyn DA's office is reportedly looking into allegations that include the forging of election-related documents linked to the local Democratic Party.

## Alabama family learns veteran dad secretly paid neighbors' pharmacy bills for a decade: 'Wanted no credit'
 - [https://www.foxnews.com/lifestyle/alabama-family-learns-veteran-dad-secretly-paid-neighbors-pharmacy-bills-decade-no-credit](https://www.foxnews.com/lifestyle/alabama-family-learns-veteran-dad-secretly-paid-neighbors-pharmacy-bills-decade-no-credit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:28:50+00:00
 - user: None

An Alabama man, an Air Force veteran, secretly donated $100 each month to cover the cost of his neighbors' medications at a pharmacy, Geraldine Drugs. Now, after his death, others are taking it up.

## Pandemic left many Americans 'more open to God,' Barna survey finds: 'Spiritual hunger'
 - [https://www.foxnews.com/us/pandemic-left-many-americans-more-open-god-barna-survey-finds-spiritual-hunger](https://www.foxnews.com/us/pandemic-left-many-americans-more-open-god-barna-survey-finds-spiritual-hunger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:24:37+00:00
 - user: None

A large majority of Americans said they believe in a supernatural dimension to the world, according a recent Barna Group study that also found many are more open to the divine.

## Virginia school where 6-year-old shot teacher reopens with metal detectors, upgraded security
 - [https://www.foxnews.com/us/virginia-school-6-year-old-shot-teacher-reopens-metal-detectors-upgraded-security](https://www.foxnews.com/us/virginia-school-6-year-old-shot-teacher-reopens-metal-detectors-upgraded-security)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:22:23+00:00
 - user: None

The school in Newport News, Virginia where first-grade teacher Abby Zwerner was shot by a 6-year-old boy on Jan. 6 has reopened Monday.

## Democrats to 'take a hard look' at  Durham's probe into Russia investigation
 - [https://www.foxnews.com/politics/democrats-take-hard-look-durhams-probe-into-russia-investigation](https://www.foxnews.com/politics/democrats-take-hard-look-durhams-probe-into-russia-investigation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:19:43+00:00
 - user: None

Senate Judiciary Committee Chairman Dick Durbin announced that the committee will “take a hard look” into a “alleged misconduct” by the Special Counsel John Durham's investigation.

## Tennessee man charged with murder after ex-girlfriend's body found in his closet, police say
 - [https://www.foxnews.com/us/tennessee-man-charged-murder-ex-girlfriends-body-found-closet-police-say](https://www.foxnews.com/us/tennessee-man-charged-murder-ex-girlfriends-body-found-closet-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:19:37+00:00
 - user: None

Dwayne Herelle Jr., 28, was charged with murder after the body of his ex-girlfriend was discovered stuffed inside a plastic container in the closet of his Nashville apartment.

## North Carolina boy, 14, dies in bull-riding rodeo competition tragedy: 'My lil cowboy'
 - [https://www.foxnews.com/us/north-carolina-boy-14-dies-bull-riding-rodeo-competition-tragedy-my-lil-cowboy](https://www.foxnews.com/us/north-carolina-boy-14-dies-bull-riding-rodeo-competition-tragedy-my-lil-cowboy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:16:36+00:00
 - user: None

14-year-old Denim Bradshaw died after he was bucked off a bull, stomped on and went into cardiac arrest at the Rafter K. Rodeo Winter Series event in Stokes County, North Carolina.

## Bengals' BJ Hill staunchly defends Joseph Ossai after pivotal penalty: 'Dumb question'
 - [https://www.foxnews.com/sports/bengals-bj-hill-staunchly-defends-joseph-ossai-pivotal-penalty-dumb-question](https://www.foxnews.com/sports/bengals-bj-hill-staunchly-defends-joseph-ossai-pivotal-penalty-dumb-question)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:15:07+00:00
 - user: None

Cincinnati Bengals defensive lineman BJ Hill stood up for Joseph Ossai after a costly penalty set up the Kansas City Chiefs' go-ahead score late in the AFC Championship.

## Madison Brooks' family 'blown away' by claims LSU student 'would not have complained' about alleged rape
 - [https://www.foxnews.com/us/madison-brooks-family-blown-away-claims-lsu-student-would-not-complained-alleged-rape](https://www.foxnews.com/us/madison-brooks-family-blown-away-claims-lsu-student-would-not-complained-alleged-rape)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:07:46+00:00
 - user: None

The attorney for grieving mother of LSU student Madison Brooks has said he is "blown away" by claims made by one of the suspect’s lawyers that she "would not have complained at all."

## Obama's secretary of defense blames 'carelessness' for classified docs scandal afflicting Biden, Trump
 - [https://www.foxnews.com/politics/obamas-secretary-defense-blames-carelessness-classified-docs-scandal-afflicting-biden-trump](https://www.foxnews.com/politics/obamas-secretary-defense-blames-carelessness-classified-docs-scandal-afflicting-biden-trump)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:02:15+00:00
 - user: None

The former secretary of defense for President Barack Obama torched the mishandling of classified documents, amid investigations into both Biden and Trump.

## Tyre Nichols bodycam shows ‘systemic racism’ in non-White people, Black activists say
 - [https://www.foxnews.com/media/tyre-nichols-bodycam-systemic-racism-non-white-people-black-activists](https://www.foxnews.com/media/tyre-nichols-bodycam-systemic-racism-non-white-people-black-activists)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:00:36+00:00
 - user: None

Following Tyre Nichols' death, Black activists have said that systemic racism in non-White people can lead police to violent action against people of color.

## European 'Christian state' faces criticism for banning woke lessons, immigration laws: 'Will of the people'
 - [https://www.foxnews.com/world/european-christian-state-faces-criticism-banning-woke-lessons-immigration-laws-will-people](https://www.foxnews.com/world/european-christian-state-faces-criticism-banning-woke-lessons-immigration-laws-will-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 17:00:20+00:00
 - user: None

The European Commission decided to approve further budget cuts to Hungary, this time impacting universities over concerns of academic freedom from political interference.

## In VA, 4 juveniles charged in the death of a 16-year-old
 - [https://www.foxnews.com/us/va-4-juveniles-charged-death-16-year-old](https://www.foxnews.com/us/va-4-juveniles-charged-death-16-year-old)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:53:54+00:00
 - user: None

A group of juveniles have been charged with second-degree murder after a 16-year-old boy was shot to death in Virginia. They were also charged with robbery and use of a firearm.

## Bill Gates addresses Jeffrey Epstein relationship in awkward interview: 'I had dinner with him and that's all'
 - [https://www.foxnews.com/media/bill-gates-addresses-jeffrey-epstein-relationship-awkward-interview-i-had-dinner-with-him-thats-all](https://www.foxnews.com/media/bill-gates-addresses-jeffrey-epstein-relationship-awkward-interview-i-had-dinner-with-him-thats-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:53:44+00:00
 - user: None

Bill Gates continued to downplay his relationship with convicted pedophile Jeffrey Epstein, claiming they were merely dinner pals during an interview with ABC 7.30.

## Guam capsizing, 'planted docs,' and 'termite' Jewish settlers: Hank Johnson's wildest statements
 - [https://www.foxnews.com/politics/guam-capsizing-planted-docs-termite-jewish-settlers-hank-johnsons-wildest-statements](https://www.foxnews.com/politics/guam-capsizing-planted-docs-termite-jewish-settlers-hank-johnsons-wildest-statements)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:53:43+00:00
 - user: None

Rep. Hank Johnson, a Democrat from Georgia, has a history of making wild statements ranging from comparing Jewish Israeli settlers to "termites" to claiming Guam will "capsize."

## Courting DeSantis: These groups are trying to convince Florida’s governor to run for president
 - [https://www.foxnews.com/politics/courting-desantis-these-groups-trying-convince-floridas-governor-run-president](https://www.foxnews.com/politics/courting-desantis-these-groups-trying-convince-floridas-governor-run-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:45:25+00:00
 - user: None

Outside political groups trying to convince Ron DeSantis to campaign for president in 2024 are a sign of the Florida GOP governor's sizable grassroots support should he run.

## Missing Las Vegas airman found dead near Red Rock Canyon after reportedly falling 250 feet during hike
 - [https://www.foxnews.com/us/missing-las-vegas-airman-found-dead-red-rock-canyon-reportedly-falling-250-feet-hike](https://www.foxnews.com/us/missing-las-vegas-airman-found-dead-red-rock-canyon-reportedly-falling-250-feet-hike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:43:59+00:00
 - user: None

The body of U.S. Senior Airman Luke Saunders, 22, was recovered last week after he went missing while on a hike near Red Rock Canyon in Las Vegas, officials said.

## Andrew Carnegie Medal for Excellence awarded to Julie Otsuka, Ed Yong
 - [https://www.foxnews.com/us/andrew-carnegie-medal-excellence-awarded-julie-otsuka-ed-yong](https://www.foxnews.com/us/andrew-carnegie-medal-excellence-awarded-julie-otsuka-ed-yong)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:39:33+00:00
 - user: None

Julie Otsuka was announced as the winner of the Andrew Carnegie Medal for Excellence in Fiction. Ed Yong won the same award in the nonfiction category.

## NC nightclub shooting leaves 1 dead, several injured
 - [https://www.foxnews.com/us/nc-nightclub-shooting-leaves-1-dead-several-injured](https://www.foxnews.com/us/nc-nightclub-shooting-leaves-1-dead-several-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:04:00+00:00
 - user: None

A shooting at an adult entertainment club in North Carolina left one person dead and several others wounded. The victims were taken to hospital with life-threatening conditions.

## KY voter registration grows among those not affiliated with Republican, Democratic parties
 - [https://www.foxnews.com/politics/ky-voter-registration-grows-those-not-affiliated-republican-democratic-parties](https://www.foxnews.com/politics/ky-voter-registration-grows-those-not-affiliated-republican-democratic-parties)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:03:11+00:00
 - user: None

Registration among voters not affiliated with major parties is growing in Kentucky. Registration under political category of “other” reached 10% last December.

## Star Mississippi chef warns Jackson restaurants may not survive water crisis: 'Something has to be done'
 - [https://www.foxnews.com/media/star-mississippi-chef-warns-jackson-restaurants-survive-water-crisis-something-done](https://www.foxnews.com/media/star-mississippi-chef-warns-jackson-restaurants-survive-water-crisis-something-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 16:00:28+00:00
 - user: None

CEO of Nick Wallace Culinary Nick Wallace joined "Fox & Friends" to discuss how the ongoing water crisis is hurting local restaurants and the community.

## Hockey legend Bobby Hull, who starred for Blackhawks, dead at 84
 - [https://www.foxnews.com/sports/hockey-legend-bobby-hull-starred-blackhawks-dead](https://www.foxnews.com/sports/hockey-legend-bobby-hull-starred-blackhawks-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:53:46+00:00
 - user: None

Bobby Hull, a hockey legend whose career spanned the NHL and the World Hockey Association, has died. He was 84. The cause of his death wasn't immediately known.

## ME Republican Party elects former Assistant House Minority Leader Joel Stetkis to serve as chair
 - [https://www.foxnews.com/politics/me-republican-party-elects-former-assistant-house-minority-joel-stetkis-serve-chair](https://www.foxnews.com/politics/me-republican-party-elects-former-assistant-house-minority-joel-stetkis-serve-chair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:52:51+00:00
 - user: None

Maine's Republican Party elected Joel Stetkis to serve as the party's chair. Stetkis previously served as the assistant minority leader of the state's Republican Party.

## Where do the Squad, Democrats stand on socialism? GOP will put them to the test this week
 - [https://www.foxnews.com/politics/where-do-squad-democrats-stand-socialism-gop-test-this-week](https://www.foxnews.com/politics/where-do-squad-democrats-stand-socialism-gop-test-this-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:34:02+00:00
 - user: None

House Republicans will call up a resolution this week that denounces socialism, which will test Democrats and may divide them when it comes time for the final vote.

## Drew Barrymore 'almost felt nervous and bad' about 'Charlie's Angels' casting, lack of diversity
 - [https://www.foxnews.com/media/drew-barrymore-almost-felt-nervous-bad-charlies-angels-casting-lack-diversity](https://www.foxnews.com/media/drew-barrymore-almost-felt-nervous-bad-charlies-angels-casting-lack-diversity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:30:13+00:00
 - user: None

Drew Barrymore sat down with actress Nia Long to discuss "Charlie's Angels" casting and how she felt "nervous and bad" about the lack of diversity in the film.

## Do not fall for this medical equipment scam
 - [https://www.foxnews.com/tech/do-not-fall-this-medical-equipment-scam](https://www.foxnews.com/tech/do-not-fall-this-medical-equipment-scam)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:23:06+00:00
 - user: None

Scammers are always out looking for their next victims. Kurt "CyberGuy" Knutsson helps you to watch out for Medicare scammers looking to steal your money from you.

## American skier Kyle Smaine believed among 2 killed in avalanche in Japan backcountry: reports
 - [https://www.foxnews.com/world/american-skier-kyle-smaine-believed-among-2-killed-avalanche-japan-backcountry-reports](https://www.foxnews.com/world/american-skier-kyle-smaine-believed-among-2-killed-avalanche-japan-backcountry-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:22:43+00:00
 - user: None

Kyle Smaine, a 31-year-old American pro skier, was believed to be among two foreign skiers killed when an avalanche triggered on Mount Hakuba Norikura in central Japan.

## Martha Stewart shows off skin in close-up selfies with 'absolutely no re-imaging,' gets ripped by fans online
 - [https://www.foxnews.com/entertainment/martha-stewart-shows-off-skin-close-up-selfies-absolutely-no-re-imaging-gets-ripped-fans-online](https://www.foxnews.com/entertainment/martha-stewart-shows-off-skin-close-up-selfies-absolutely-no-re-imaging-gets-ripped-fans-online)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:14:38+00:00
 - user: None

Martha Stewart shared "un filtered" pictures from the salon-chair to her Instagram, showing off her youthful appearance. Some fans were quick to question her all natural claims about her face and complexion.

## Calls for transparency from NBC News grow louder in wake of Paul Pelosi attack bodycam video
 - [https://www.foxnews.com/media/calls-for-transparency-nbc-news-grow-louder-wake-paul-pelosi-attack-bodycam-video](https://www.foxnews.com/media/calls-for-transparency-nbc-news-grow-louder-wake-paul-pelosi-attack-bodycam-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:00:54+00:00
 - user: None

Critics are calling for transparency from NBC News after video of the attack on Paul Pelosi shed light on what appeared to be accurate and inaccurate with the network's coverage.

## Texas salon owners consider closing shop after crime crisis leaves them waiting up 'to an hour' for police
 - [https://www.foxnews.com/media/texas-salon-owners-consider-closing-shop-crime-crisis-leaves-waiting-hour-police](https://www.foxnews.com/media/texas-salon-owners-consider-closing-shop-crime-crisis-leaves-waiting-hour-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:00:54+00:00
 - user: None

Laura North and Erin Mutschler of Austin, Texas' Headspace Salon explained how escalating homeless crime is making them consider packing up their business.

## Time to get America's fiscal house in order: Here are the first steps
 - [https://www.foxnews.com/opinion/time-get-americas-fiscal-house-order-here-first-steps](https://www.foxnews.com/opinion/time-get-americas-fiscal-house-order-here-first-steps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:00:36+00:00
 - user: None

It’s startling to see how much debt the United States has taken on – $31.5 trillion and counting – and even more jarring to realize there’s no plan to address it.

## Terror watchlist, sex offender arrests have surged at the southern border. These Americans are worried
 - [https://www.foxnews.com/us/terror-watchlist-sex-offender-arrests-surged-southern-border-americans-worried](https://www.foxnews.com/us/terror-watchlist-sex-offender-arrests-surged-southern-border-americans-worried)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 15:00:07+00:00
 - user: None

People in Texas told Fox News they were worried by recent spikes in the number of sex offenders and potential terrorists caught crossing the southern border.

## Iowa Democrats choose failed congressional candidate to lead state party
 - [https://www.foxnews.com/politics/iowa-democrats-choose-failed-congressional-candidate-state-party](https://www.foxnews.com/politics/iowa-democrats-choose-failed-congressional-candidate-state-party)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:54:25+00:00
 - user: None

Rita Hart has been chosen to lead the Iowa Democratic Party. Hart was previously a state senator who lost a 2020 US House race by a small number of votes.

## North Korea has eased strict epidemic restrictions, according to Russian embassy
 - [https://www.foxnews.com/world/north-korea-eased-strict-epidemic-restrictions-russian-embassy](https://www.foxnews.com/world/north-korea-eased-strict-epidemic-restrictions-russian-embassy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:53:56+00:00
 - user: None

North Korea has eased its strict epidemic restrictions, according to the Russian embassy in the country. North Korea never officially acknowledged a lockdown.

## Video shows Wisconsin police officer getting snow dumped on him after closing door
 - [https://www.foxnews.com/us/video-shows-wisconsin-police-officer-getting-snow-dumped-him-closing-door](https://www.foxnews.com/us/video-shows-wisconsin-police-officer-getting-snow-dumped-him-closing-door)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:47:46+00:00
 - user: None

The Viroqua Police Department outside of Madison, Wisconsin, has released a video of one of its officers getting slammed with snow after closing a door.

## In NV, Lake Mead’s water decline rate may slow down due to recent snowfall at CO river
 - [https://www.foxnews.com/us/nv-lake-meads-water-decline-rate-slow-down-due-recent-snowfall-co-river](https://www.foxnews.com/us/nv-lake-meads-water-decline-rate-slow-down-due-recent-snowfall-co-river)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:46:55+00:00
 - user: None

Recent snowfall that fed into the Colorado River may slow down Lake Mead’s water decline rate. Nevada's lake is now expected to finish seven feet higher that original thought.

## Tyre Nichols memorial fundraiser blows past $1 million in 2 days
 - [https://www.foxnews.com/us/tyre-nichols-memorial-fundraiser-blows-past-1-million-2-days](https://www.foxnews.com/us/tyre-nichols-memorial-fundraiser-blows-past-1-million-2-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:42:03+00:00
 - user: None

Tyre Nichols' mother, RowVaughn Wells, started a memorial fundraiser for her son that has now received nearly $1.2 million in donations after just two days.

## Virginia Giuffre won't 'remain silent' on Prince Andrew sexual abuse allegations once gag order lifts: lawyer
 - [https://www.foxnews.com/world/virginia-giuffre-wont-remain-silent-prince-andrew-sexual-abuse-allegations-once-gag-order-lifts-lawyer](https://www.foxnews.com/world/virginia-giuffre-wont-remain-silent-prince-andrew-sexual-abuse-allegations-once-gag-order-lifts-lawyer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:39:27+00:00
 - user: None

American lawyer Lisa Bloom, who's represented Jeffrey Epstein and Ghislaine Maxwell's accusers, says she doubts Virginia Giuffre will keep quiet on Prince Andrew's alleged sexual abuse.

## 10 coffee makers to make your mornings better
 - [https://www.foxnews.com/tech/10-coffee-makers-make-mornings-better](https://www.foxnews.com/tech/10-coffee-makers-make-mornings-better)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:00:36+00:00
 - user: None

Different people need different types of coffee makers. Kurt "CyberGuy" Knutsson lists the top 10 coffee makers with various features to fit your coffee needs.

## Law enforcement officials send message after Tyre Nichols' death: This was 'thug culture' not 'police culture'
 - [https://www.foxnews.com/media/law-enforcement-officials-send-message-tyre-nichols-death-thug-culture-police-culture](https://www.foxnews.com/media/law-enforcement-officials-send-message-tyre-nichols-death-thug-culture-police-culture)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:00:13+00:00
 - user: None

Police officials urge Americans not to "attack the entire profession" for the "horrible crimes" of the Memphis PD after the tragic beating death of Tyre Nichols.

## Los Angeles shooting that left 3 dead took place at 'rental party house,' neighbor says, as manhunt ongoing
 - [https://www.foxnews.com/us/los-angeles-shooting-left-3-dead-took-place-rental-party-house-neighbor-says-manhunt-ongoing](https://www.foxnews.com/us/los-angeles-shooting-left-3-dead-took-place-rental-party-house-neighbor-says-manhunt-ongoing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 14:00:01+00:00
 - user: None

A manhunt is ongoing Monday for suspects behind a shooting in the Beverly Crest neighborhood of Los Angeles, California, that left 3 dead and 4 wounded.

## Illinois Gov. Pritzker receives bill that would make it easier for residents to change their names
 - [https://www.foxnews.com/politics/illinois-gov-pritzker-receives-bill-easier-residents-change-names](https://www.foxnews.com/politics/illinois-gov-pritzker-receives-bill-easier-residents-change-names)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:58:55+00:00
 - user: None

Currently, there is a lifetime ban on name changes for people who have been convicted of certain crimes in Illinois. Gov. Pritzker received a bill that would lift this restriction.

## Michigan grave of Civil War soldier finally receives headstone
 - [https://www.foxnews.com/us/grave-civil-war-soldier-michigan-cemetery-finally-receives-headstone](https://www.foxnews.com/us/grave-civil-war-soldier-michigan-cemetery-finally-receives-headstone)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:46:07+00:00
 - user: None

The grave of a Civil War soldier who died in 1910 was given a headstone in a northern Michigan cemetery. Ruel Boynton was a veteran who had eight children.

## Former California Democratic mayor pleads no contest to child sex crimes: reports
 - [https://www.foxnews.com/politics/former-california-democratic-mayor-pleads-no-contest-child-sex-crimes-reports](https://www.foxnews.com/politics/former-california-democratic-mayor-pleads-no-contest-child-sex-crimes-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:46:06+00:00
 - user: None

Robert Jacob, the former Democratic mayor of Sebastopol, California, pleaded no contest to six counts of child sex crimes earlier this month, according to local reports.

## Chiefs' Chris Jones sends stern message to NFL: 'Don’t ever disrespect Arrowhead Stadium'
 - [https://www.foxnews.com/sports/chiefs-chris-jones-sends-stern-message-nfl-disrespect-arrowhead-stadium](https://www.foxnews.com/sports/chiefs-chris-jones-sends-stern-message-nfl-disrespect-arrowhead-stadium)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:37:44+00:00
 - user: None

Kansas City Chiefs defensive tackle Chris Jones had two sacks in the AFC Championship victory and had a message for the rest of the NFL.

## Kansas firefighters find man on fire inside Walmart restroom
 - [https://www.foxnews.com/us/kansas-firefighters-man-fire-inside-walmart-restroom](https://www.foxnews.com/us/kansas-firefighters-man-fire-inside-walmart-restroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:21:18+00:00
 - user: None

A man was found on fire in the bathroom of a Walmart Neighborhood Market over the weekend. The man was taken to the hospital with serious injuries.

## Ice storm in South could cause power outages, travel issues for millions of Americans
 - [https://www.foxnews.com/us/ice-storm-south-cause-power-outages-travel-issues-millions-americans](https://www.foxnews.com/us/ice-storm-south-cause-power-outages-travel-issues-millions-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:15:32+00:00
 - user: None

The South is facing the risk of a significant ice storm as a powerful arctic cold front is bringing freezing wind chills to most of the U.S.

## Boris Johnson says Putin threatened to ‘hurt’ him with missile strike after visiting Ukraine
 - [https://www.foxnews.com/world/boris-johnson-putin-threatened-hurt-him-missile-strike-visiting-ukraine](https://www.foxnews.com/world/boris-johnson-putin-threatened-hurt-him-missile-strike-visiting-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:12:34+00:00
 - user: None

Former British Prime Minister Boris Johnson says Russian President Vladimir Putin, in the days leading up to the start of the Ukraine war, threatened a missile strike in a phone call.

## I'm a Seattle native and 'equity' is destroying my once beautiful, thriving city
 - [https://www.foxnews.com/opinion/seattle-native-equity-destroying-once-beautiful-thriving-city](https://www.foxnews.com/opinion/seattle-native-equity-destroying-once-beautiful-thriving-city)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:00:41+00:00
 - user: None

Seattle is obsessed with "equity," the centerpiece of diversity, equity, and inclusion. As a result, the once lovely and livable Emerald City has lost its shine.

## Jinger Duggar says she’s 'free' from ‘cult-like’ religious upbringing: ‘It just consumed my life’
 - [https://www.foxnews.com/entertainment/jinger-duggar-free-from-cult-like-religious-upbringing-just-consumed-life](https://www.foxnews.com/entertainment/jinger-duggar-free-from-cult-like-religious-upbringing-just-consumed-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 13:00:32+00:00
 - user: None

For nearly 18 years, Jinger Duggar Vuolo appeared on TLC’s hit reality shows "19 Kids and Counting" and "Counting On." She wrote a new book titled "Becoming Free Indeed."

## Cougar studied by CA biologists found dead likely due to vehicle collision
 - [https://www.foxnews.com/us/cougar-studied-ca-biologists-found-dead-due-vehicle-collision](https://www.foxnews.com/us/cougar-studied-ca-biologists-found-dead-due-vehicle-collision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:47:42+00:00
 - user: None

A radio-collared cougar known as P-81 was found dead near Point Mugu, California. The cougar is one of the dozens of mountain lions that died likely due to a car collision.

## Nebraska police find 3 children who were taken during a carjacking with suspected hypothermia, frostbite
 - [https://www.foxnews.com/us/nebraska-police-find-3-children-taken-during-carjacking-suspected-hypothermia-frostbite](https://www.foxnews.com/us/nebraska-police-find-3-children-taken-during-carjacking-suspected-hypothermia-frostbite)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:46:47+00:00
 - user: None

An SUV was stolen in Nebraska with three young children in the vehicle. Police found the three children, and they all had suspected frostbite and hypothermia.

## Flying high: 1979 Pontiac Firebird Trans Am with 37 miles on it just sold for $220,000
 - [https://www.foxnews.com/auto/1979-pontiac-firebird-trans-am-sold](https://www.foxnews.com/auto/1979-pontiac-firebird-trans-am-sold)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:44:04+00:00
 - user: None

A 1979 Pontiac Firebird Trans Am with just 37 miles on its odometer was auctioned at the Barrett-Jackson event in Scottsdale, Arizona, for $220,000.

## Ohio man convicted in shootout that wounded police officer, sentenced to 56 years in prison
 - [https://www.foxnews.com/us/ohio-man-convicted-shootout-wounded-police-officer-sentenced-56-years-prison](https://www.foxnews.com/us/ohio-man-convicted-shootout-wounded-police-officer-sentenced-56-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:42:59+00:00
 - user: None

Christopher Hubbard was sentenced to 56 years in prison for shooting at police officers. Hubbard wounded an officer in the shooting and was also wounded when officers returned fire.

## Phoenix park closes for homicide investigation after hiker finds human skull
 - [https://www.foxnews.com/us/phoenix-park-closes-homicide-investigation-hiker-finds-human-skull](https://www.foxnews.com/us/phoenix-park-closes-homicide-investigation-hiker-finds-human-skull)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:37:23+00:00
 - user: None

A human skull showing signs of trauma has been found at a park in Phoenix, Arizona. Officials have closed portions of the park to investigate for homicide evidence.

## Super Bowl 2023: What to know about the game
 - [https://www.foxnews.com/sports/super-bowl-2023-what-to-know-about-game](https://www.foxnews.com/sports/super-bowl-2023-what-to-know-about-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:36:34+00:00
 - user: None

The Kansas City Chiefs and the Philadelphia Eagles will meet in Super Bowl LVII on Feb. 12. Here's what to know about the game and the two best teams in the NFL.

## President Biden to visit Maryland, will talk about replacing Baltimore and Potomac Tunnel
 - [https://www.foxnews.com/politics/president-biden-visit-maryland-will-talk-about-replacing-baltimore-potomac-tunnel](https://www.foxnews.com/politics/president-biden-visit-maryland-will-talk-about-replacing-baltimore-potomac-tunnel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:28:33+00:00
 - user: None

President Biden is visiting Baltimore on Monday. Biden plans to talk about replacing the Baltimore and Potomac Tunnel. The project is expected to take a decade to be completed.

## Comer sounds alarm on Biden's mishandling of classified documents: 'Nothing' he's done is 'normal'
 - [https://www.foxnews.com/media/comer-sounds-alarm-bidens-mishandling-classified-documents-nothing-done-normal](https://www.foxnews.com/media/comer-sounds-alarm-bidens-mishandling-classified-documents-nothing-done-normal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:06:47+00:00
 - user: None

Rep. James Comer says investigating Biden's mishandling of classified documents is of the "utmost importance" after the FBI retrieves notebooks from his Delaware home.

## Ilhan Omar labeled a 'liar' after claiming she was unaware of 'tropes about Jews and money:' 'Give me a break'
 - [https://www.foxnews.com/media/ilhan-omar-labeled-liar-claiming-unaware-tropes-jews-and-money-give-me-break](https://www.foxnews.com/media/ilhan-omar-labeled-liar-claiming-unaware-tropes-jews-and-money-give-me-break)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:00:53+00:00
 - user: None

Rep. Ilhan Omar is accused of 'lying' after she said that she was unaware there were 'tropes about Jews and money' when asked about past antisemitic comments.

## Canadian theater sparks backlash with plan to host play with Black-only audiences: 'Cultural apartheid'
 - [https://www.foxnews.com/world/canadian-theater-sparks-backlash-plan-host-play-black-only-audiences-cultural-apartheid](https://www.foxnews.com/world/canadian-theater-sparks-backlash-plan-host-play-black-only-audiences-cultural-apartheid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 12:00:04+00:00
 - user: None

The National Arts Centre in Ottawa stoked backlash after one of its theaters announced a performance of a play starring Black women that is open only to Black audiences.

## Chickens killed in fire at Hillandale Farms property in Connecticut, cause remains unknown
 - [https://www.foxnews.com/us/chickens-killed-fire-hillandale-farms-property-connecticut-cause-remains-unknown](https://www.foxnews.com/us/chickens-killed-fire-hillandale-farms-property-connecticut-cause-remains-unknown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:51:07+00:00
 - user: None

A fire at the Hillandale Farms property in Bozrah, Connecticut, killed several chickens and burned for hours. The cause of the fire remains unknown.

## Major US city forces CRT-inspired training on employees, Chiefs' do-over sparks outrage and more top headlines
 - [https://www.foxnews.com/us/nyc-employees-forced-into-critical-race-theory-training](https://www.foxnews.com/us/nyc-employees-forced-into-critical-race-theory-training)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:36:34+00:00
 - user: None

'EQUITY LENS' - All employees of major US city forced into radical critical race theory-inspired training

## New Jersey man sentenced to 55 years in prison for fatally stabbing co-worker on lunch break
 - [https://www.foxnews.com/us/new-jersey-man-sentenced-55-years-fatally-stabbing-worker-lunch-break](https://www.foxnews.com/us/new-jersey-man-sentenced-55-years-fatally-stabbing-worker-lunch-break)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:24:37+00:00
 - user: None

Kenneth Saal pleaded guilty to first-degree murder and burglary charges after he killed his co-worker over three years ago. He was sentenced to 55 years in prison for the crimes.

## ‘Socialist’ teacher admits she wants to ‘abolish the police’ amid school curriculum battle with DeSantis
 - [https://www.foxnews.com/media/socialist-teacher-admits-she-wants-abolish-police-amid-school-curriculum-battle-with-desantis](https://www.foxnews.com/media/socialist-teacher-admits-she-wants-abolish-police-amid-school-curriculum-battle-with-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:19:51+00:00
 - user: None

One of the teacher's behind the proposed AP African-American studies course in Florida is accused of being a "socialist" in a recent National Review op-ed.

## Eagles' Jalen Hurts, Chiefs' Patrick Mahomes set to make Super Bowl history
 - [https://www.foxnews.com/sports/eagles-jalen-hurts-chiefs-patrick-mahomes-super-bowl-history](https://www.foxnews.com/sports/eagles-jalen-hurts-chiefs-patrick-mahomes-super-bowl-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:15:32+00:00
 - user: None

When Patrick Mahomes and Jalen Hurts take the field in Super Bowl LVII at State Farm Stadium in Arizona on Feb. 12, they will be making history in the big game.

## Donna Kelce to make history at Super Bowl LVII
 - [https://www.foxnews.com/sports/donna-kelce-make-history-super-bowl-lvii](https://www.foxnews.com/sports/donna-kelce-make-history-super-bowl-lvii)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:11:35+00:00
 - user: None

Donna Kelce is set to make history at Super Bowl LVII next month once both of her sons hit the field. The Kansas City Chiefs meet the Philadelphia Eagles.

## Patrick Mahomes offers parting shot to Cincinnati mayor after Chiefs win AFC Championship
 - [https://www.foxnews.com/sports/patrick-mahomes-offers-parting-shot-cincinnati-mayor-chiefs-win-afc-championship](https://www.foxnews.com/sports/patrick-mahomes-offers-parting-shot-cincinnati-mayor-chiefs-win-afc-championship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:08:21+00:00
 - user: None

Patrick Mahomes shared his thoughts about Cincinnati Mayor Aftab Pureval after the Kansas City Chiefs defeated the Bengals in the AFC Championship.

## Bengals player upset after teammate's penalty costs AFC Championship: 'Why the f--- you touch the quarterback'
 - [https://www.foxnews.com/sports/bengals-player-upset-teammates-penalty-costs-afc-championship](https://www.foxnews.com/sports/bengals-player-upset-teammates-penalty-costs-afc-championship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:05:37+00:00
 - user: None

Bengals linebacker Germaine Pratt didn't hold back his thoughts on his teammates' horrible mistake that led to the Chiefs' game-winning field goal in the AFC Championship.

## Patrick Mahomes praises God after AFC Championship win: 'He healed my body this week'
 - [https://www.foxnews.com/sports/patrick-mahomes-praises-god-afc-championship-win-body-week](https://www.foxnews.com/sports/patrick-mahomes-praises-god-afc-championship-win-body-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:01:59+00:00
 - user: None

Kansas City Chiefs star Patrick Mahomes took a moment to thank God for healing his body during the week as he managed to play with a high-ankle sprain.

## JK Rowling 'deeply amused' by 'lost admiration' critics: I'll file it 'where I keep my missing f---s'
 - [https://www.foxnews.com/media/jk-rowling-deeply-amused-critics-file-keep-missing-f-s](https://www.foxnews.com/media/jk-rowling-deeply-amused-critics-file-keep-missing-f-s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:00:57+00:00
 - user: None

Author J.K. Rowling defended her Twitter comments on transgender policies and women's rights by mocking those who claimed “lost their admiration” for her on Saturday.

## Biden’s abortion mandates threaten pro-life VA nurse's job, but she isn’t giving up
 - [https://www.foxnews.com/opinion/bidens-abortion-mandates-threaten-pro-life-va-nurses-job-she-isnt-giving-up](https://www.foxnews.com/opinion/bidens-abortion-mandates-threaten-pro-life-va-nurses-job-she-isnt-giving-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 11:00:29+00:00
 - user: None

Since the Biden administration took office, the executive branch has established quite the track record for repeatedly usurping congressional authority and improperly wielding its own powers to appease its political base to the grave detriment of religious Americans

## Suicide bomber kills at least 28, leaves nearly 150 wounded at mosque in Pakistan
 - [https://www.foxnews.com/world/suicide-bomber-kills-20-leaves-nearly-100-wounded-mosque-pakistan](https://www.foxnews.com/world/suicide-bomber-kills-20-leaves-nearly-100-wounded-mosque-pakistan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 10:22:08+00:00
 - user: None

At least 28 were people killed Monday and nearly 150 injured when a suicide bomber targeted a mosque in Pakistan. There were roughly 150 people inside the mosque when the bomb went off.

## Zachary Levi sparks Twitter controversy over claim that Pfizer is a 'danger' to the world: 'Hardcore agree'
 - [https://www.foxnews.com/media/zachary-levi-sparks-twitter-controversy-claim-pfizer-danger-world-hardcore-agree](https://www.foxnews.com/media/zachary-levi-sparks-twitter-controversy-claim-pfizer-danger-world-hardcore-agree)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 10:00:46+00:00
 - user: None

Actor Zachary Levi caused controversy on Twitter Sunday after retweeting a comment agreeing that the pharmaceutical company Pfizer poses a threat to the world.

## Florida dog found cemented to sidewalk, diagnosed with more than 20 medical conditions: 'He was left to die'
 - [https://www.foxnews.com/us/florida-dog-found-cemented-sidewalk-diagnosed-more-than-20-medical-conditions](https://www.foxnews.com/us/florida-dog-found-cemented-sidewalk-diagnosed-more-than-20-medical-conditions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 09:58:13+00:00
 - user: None

A dog is recovering after being found cemented to a sidewalk in Florida with 22 medical conditions. The shelter that found him believes he was there for days.

## Novak Djokovic wins Australian Open a year after being deported: 'He stood on principle'
 - [https://www.foxnews.com/media/novak-djokovic-wins-australian-open-year-after-being-deported-he-stood-principle](https://www.foxnews.com/media/novak-djokovic-wins-australian-open-year-after-being-deported-he-stood-principle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 09:00:56+00:00
 - user: None

'The Big Sunday Show' co-hosts discuss Novak Djokovic's Australian Open victory and his stance on the COVID-19 vaccine.

## Teenager playing hide-and-seek found days later inside shipping container in another country
 - [https://www.foxnews.com/world/teenager-playing-hide-seek-found-days-later-inside-shipping-container-another-country](https://www.foxnews.com/world/teenager-playing-hide-seek-found-days-later-inside-shipping-container-another-country)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 08:18:19+00:00
 - user: None

A 15-year-old Bangladesh boy accidentally locked himself inside a shipping container while playing hide-and-seek. He was found six days later in another country.

## NYC forces all city employees to undergo radical critical race theory training: 'Really unfair'
 - [https://www.foxnews.com/media/new-york-forces-all-city-employees-into-radical-racial-equity-training](https://www.foxnews.com/media/new-york-forces-all-city-employees-into-radical-racial-equity-training)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 08:00:34+00:00
 - user: None

New York City launched a mandatory critical race theory-inspired 'equity' training for all employees which accused America of being systemically racist.

## Biden is coming for your job
 - [https://www.foxnews.com/opinion/biden-is-coming-your-job](https://www.foxnews.com/opinion/biden-is-coming-your-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:28:43+00:00
 - user: None

Biden is coming for your job with new regulations and crazy leftist policies that are an essential part of his anti-business agenda. Tech is his new target.

## Holly Madison talks Playboy murders, leaving Hugh Hefner: 'I felt emotionally shell-shocked'
 - [https://www.foxnews.com/entertainment/holly-madison-talks-playboy-murders-leaving-hugh-hefner-felt-emotionally](https://www.foxnews.com/entertainment/holly-madison-talks-playboy-murders-leaving-hugh-hefner-felt-emotionally)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:00:55+00:00
 - user: None

Holly Madison is a former Playboy Bunny, ex-girlfriend of Hugh Hefner and star of "The Girls Next Door." She is hosting a true-crime docuseries on ID titled "The Playboy Murders."

## Girl, 9 years old, discovers rare prehistoric megalodon tooth in Maryland waters: 'I couldn't believe it'
 - [https://www.foxnews.com/lifestyle/girl-9-years-old-discovers-rare-prehistoric-megalodon-tooth-maryland-waters-couldnt-believe-it](https://www.foxnews.com/lifestyle/girl-9-years-old-discovers-rare-prehistoric-megalodon-tooth-maryland-waters-couldnt-believe-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:00:40+00:00
 - user: None

Molly Sampson, a fourth grader from Prince Frederick, Maryland, found a 15 million-year-old megalodon tooth on Christmas in a bay near Calvert Cliffs. Her family had it checked by a paleontologist.

## Alex Murdaugh: Timeline of the once powerful South Carolina lawyer's spectacular downfall
 - [https://www.foxnews.com/us/alex-murdaugh-timeline-once-powerful-south-carolina-lawyers-spectacular-downfall](https://www.foxnews.com/us/alex-murdaugh-timeline-once-powerful-south-carolina-lawyers-spectacular-downfall)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:00:28+00:00
 - user: None

Timeline of Alex Murdaugh's dramatic downward spiral from a life of privilege and wealth to a disbarred attorney on trial for the murder of his wife and son.

## I'm a successful female minority truck driver. California's AB5 forced me to leave the state I love
 - [https://www.foxnews.com/opinion/female-minority-truck-driver-california-ab5-forced-me-leave-state](https://www.foxnews.com/opinion/female-minority-truck-driver-california-ab5-forced-me-leave-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:00:20+00:00
 - user: None

When the California legislature began debating Assembly Bill 5 – a law effectively banning independent contractors in trucking – my dream was put in jeopardy.

## Freedom Caucus stand against McCarthy inspires conservatives to fight ’50 swamps in the 50 states’
 - [https://www.foxnews.com/politics/freedom-caucus-stand-against-mccarthy-inspires-conservatives-fight-50-swamps-50-states](https://www.foxnews.com/politics/freedom-caucus-stand-against-mccarthy-inspires-conservatives-fight-50-swamps-50-states)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 07:00:16+00:00
 - user: None

State Freedom Caucus lawmakers are riding the wave of the 20 Republicans who held up the House speaker race to combat what they call the "swamp" in their states.

## Texas police chief on leave after SWAT raids wrong house in search of suspect falsely accused of murder
 - [https://www.foxnews.com/us/texas-police-chief-leave-after-swat-raids-wrong-house-search-suspect-falsely-accused-murder](https://www.foxnews.com/us/texas-police-chief-leave-after-swat-raids-wrong-house-search-suspect-falsely-accused-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 06:56:57+00:00
 - user: None

A SWAT team in Galveston, Texas, raided the wrong home, terrifying the family members inside. Now, the city's police chief is on leave over the miscommunication.

## On this day in history, Jan. 30, 1933, 'The Lone Ranger' debuts, trotting into American cultural lore
 - [https://www.foxnews.com/lifestyle/this-day-history-jan-30-1933-lone-ranger-debuts-american-culture-lore](https://www.foxnews.com/lifestyle/this-day-history-jan-30-1933-lone-ranger-debuts-american-culture-lore)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 05:02:04+00:00
 - user: None

"The Lone Ranger" debuted on WXYZ radio in Detroit on this day in history, Jan. 30, 1933. The masked vigilante lawman and his Native sidekick, Tonto, became a dynamic duo of multimedia fame.

## Chiefs' Travis Kelce to the Cincinnati mayor: 'Know your role and shut your mouth'
 - [https://www.foxnews.com/sports/chiefs-travis-kelce-cincinnati-mayor-know-your-role-and-shut-your-mouth](https://www.foxnews.com/sports/chiefs-travis-kelce-cincinnati-mayor-know-your-role-and-shut-your-mouth)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 03:56:30+00:00
 - user: None

After winning the AFC Championship over the Bengals, Chiefs tight end Travis Kelce took a shot at the Cincinnati mayor who threw some shade leading up to the game.

## Chiefs finally take down Joe Burrow, Bengals to advance to Super Bowl LVII
 - [https://www.foxnews.com/sports/chiefs-finally-take-down-joe-burrow-bengals-advance-super-bowl-lvii](https://www.foxnews.com/sports/chiefs-finally-take-down-joe-burrow-bengals-advance-super-bowl-lvii)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 03:12:13+00:00
 - user: None

The Kansas City Chiefs finally defeated Joe Burrow and the Cincinnati Bengals to advance to Super Bowl LVII thanks to Patrick Mahomes' late-game magic.

## Chiefs' do-over play in 4th quarter of AFC Championship enrages NFL fans
 - [https://www.foxnews.com/sports/chiefs-do-over-play-4th-quarter-afc-championship-enrages-nfl-fans](https://www.foxnews.com/sports/chiefs-do-over-play-4th-quarter-afc-championship-enrages-nfl-fans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 03:02:38+00:00
 - user: None

The Kansas City Chiefs received a do-over in a pivotal moment of the AFC Championship against the Cincinnati Bengals on Sunday night.

## Mark Levin calls on GOP governors to protect children's education: 'Teach history, not Marxist propaganda'
 - [https://www.foxnews.com/media/mark-levin-calls-gop-governors-protect-childrens-education-teach-history-not-marxist-propaganda](https://www.foxnews.com/media/mark-levin-calls-gop-governors-protect-childrens-education-teach-history-not-marxist-propaganda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 03:00:23+00:00
 - user: None

Fox News host Mark Levin praises Florida Gov. Ron DeSantis for standing up to 'woke' educators in the state in his opening monologue on 'Life Liberty & Levin.'

## Houston police say ‘sharp dressed man' in hat and dark suit wanted in 2 bank robberies
 - [https://www.foxnews.com/us/houston-police-say-sharp-dressed-man-hat-suit-wanted-bank-robberies](https://www.foxnews.com/us/houston-police-say-sharp-dressed-man-hat-suit-wanted-bank-robberies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:53:57+00:00
 - user: None

Houston police say they are looking for a "sharp dressed" man caught on camera robbing two separate banks in Houston, Texas this month.

## Russia to require basic military training in schools in 'evocation of the Soviet Union,' UK says
 - [https://www.foxnews.com/world/russia-require-basic-military-training-schools-evocation-soviet-union-uk-says](https://www.foxnews.com/world/russia-require-basic-military-training-schools-evocation-soviet-union-uk-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:38:26+00:00
 - user: None

Students throughout Russia will undergo basic military training starting next September, signaling a militarized atmosphere in wartime Russia, the UK Ministry of Defense said.

## New York pregnant woman dies after car driven by beau slams into electrical pole: police
 - [https://www.foxnews.com/us/new-york-pregnant-woman-dies-car-driven-beau-slams-electrical-pole-police](https://www.foxnews.com/us/new-york-pregnant-woman-dies-car-driven-beau-slams-electrical-pole-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:36:51+00:00
 - user: None

A Staten Island, New York pregnant woman died on Saturday morning after her beau, who was allegedly drunk, drove into an electrical pole, causing the vehicle to split in three.

## Eagles fans party in the streets, climb up greased poles after team's NFC Championship win
 - [https://www.foxnews.com/sports/eagles-fans-party-streets-climb-up-greased-poles-teams-nfc-championship-win](https://www.foxnews.com/sports/eagles-fans-party-streets-climb-up-greased-poles-teams-nfc-championship-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:36:27+00:00
 - user: None

Philadelphia Eagles fans partied hard following the team's NFC Championship win over the San Francisco 49ers. The team is back in the Super Bowl.

## Adam Schiff and Eric Swalwell poisoned the minds of American people: Devin Nunes
 - [https://www.foxnews.com/media/adam-schiff-eric-swalwell-poisoned-minds-american-people-devin-nunes](https://www.foxnews.com/media/adam-schiff-eric-swalwell-poisoned-minds-american-people-devin-nunes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:36:06+00:00
 - user: None

Trump Media & Technology Group CEO Devin Nunes reacted to Speaker Kevin McCarthy blocking California Democrats Adam Schiff and Eric Swalwell from the House Intel Committee.

## Chinese vessels and aircraft appear in Taiwanese waters and airspace
 - [https://www.foxnews.com/world/chinese-vessels-aircraft-appear-taiwanese-waters-airspace](https://www.foxnews.com/world/chinese-vessels-aircraft-appear-taiwanese-waters-airspace)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:32:14+00:00
 - user: None

China military planes and naval vessels encroached into Taiwanese airspace and waters on Monday morning, in an effort to flex its potential power against the island nation.

## Brock Purdy's injury revealed; 49ers to get more clarity Monday: report
 - [https://www.foxnews.com/sports/brock-purdys-injury-revealed-49ers-more-clarity-monday-report](https://www.foxnews.com/sports/brock-purdys-injury-revealed-49ers-more-clarity-monday-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:30:37+00:00
 - user: None

The San Francisco 49ers believe quarterback Brock Purdy suffered a UCL injury during the NFC Championship loss to the Philadelphia Eagles.

## Scotland changes policy on sending transgender inmates to all-female prison: report
 - [https://www.foxnews.com/world/scotland-changes-policy-sending-transgender-inmates-female-prison-report](https://www.foxnews.com/world/scotland-changes-policy-sending-transgender-inmates-female-prison-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:02:58+00:00
 - user: None

Scotland will no longer send transgender inmates to all-female prisons, if they have violent backgrounds against women, according to reports.

## US general warns British Army no longer among world’s top tier fighting forces: report
 - [https://www.foxnews.com/world/us-general-warns-british-army-no-longer-among-worlds-top-tier-fighting-forces-report](https://www.foxnews.com/world/us-general-warns-british-army-no-longer-among-worlds-top-tier-fighting-forces-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 02:00:32+00:00
 - user: None

A U.S. general reportedly warned UK Defense Secretary Ben Wallace that the British Army must revamp its military as it is no longer considered among the world's top-tier forces.

## Cowboys, Kellen Moore part ways after another disappointing end to season: reports
 - [https://www.foxnews.com/sports/cowboys-kellen-moore-part-ways-another-disappointing-end-season-report](https://www.foxnews.com/sports/cowboys-kellen-moore-part-ways-another-disappointing-end-season-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:49:27+00:00
 - user: None

The Dallas Cowboys and offensive coordinator Kellen Moore have agreed to mutually part ways after another disappointing end to a season.

## New Jersey police searching for man who threw molotov cocktail at synagogue
 - [https://www.foxnews.com/us/new-jersey-police-searching-man-threw-molotov-cocktail-synagogue](https://www.foxnews.com/us/new-jersey-police-searching-man-threw-molotov-cocktail-synagogue)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:46:40+00:00
 - user: None

A man lit a molotov cocktail and threw it at Temple Ner Tamid in Bloomfield, New Jersey, around 3:19 a.m. on Sunday morning, according to police.

## NFC Championship shows it's time to bring back 3rd quarterback rule
 - [https://www.foxnews.com/sports/nfc-championship-shows-time-bring-back-3rd-quarterback-rule](https://www.foxnews.com/sports/nfc-championship-shows-time-bring-back-3rd-quarterback-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:45:03+00:00
 - user: None

The San Francisco 49ers lost to the Philadelphia Eagles in an uneventful NFC Championship. It showed the NFL has to fix the roster situation when it pertains to QBs

## Empire State Building lights up green to support Eagles and creates firestorm: 'You are dead to me'
 - [https://www.foxnews.com/sports/empire-state-building-lights-up-green-support-eagles-creates-firestorm-dead-me](https://www.foxnews.com/sports/empire-state-building-lights-up-green-support-eagles-creates-firestorm-dead-me)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:43:10+00:00
 - user: None

The Empire State Building ruffled a bunch of feathers on Sunday night as it lit up green to support the Philadelphia Eagles making the Super Bowl.

## Alan Cumming says he 'broke the internet' after returning OBE honor caused international response
 - [https://www.foxnews.com/entertainment/alan-cumming-broke-internet-returning-obe-honor](https://www.foxnews.com/entertainment/alan-cumming-broke-internet-returning-obe-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:40:40+00:00
 - user: None

Alan Cumming is speaking out on his decision to return his OBE award several months ago. The actor sparked an international response to his decision.

## NBA referees on blown LeBron James foul: Missed call will 'cause sleepless nights'
 - [https://www.foxnews.com/sports/nba-referees-blown-lebron-james-foul-missed-call-will-cause-sleepless-nights](https://www.foxnews.com/sports/nba-referees-blown-lebron-james-foul-missed-call-will-cause-sleepless-nights)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:39:25+00:00
 - user: None

The National Basketball Referees Association put out a statement Sunday night on the blown LeBron James foul call from Saturday night's debacle.

## Syrian government forces behind 2018 Douma chemical attack, watchdog group says
 - [https://www.foxnews.com/world/syrian-government-forces-behind-2018-douma-chemical-attack-watchdog-group-says](https://www.foxnews.com/world/syrian-government-forces-behind-2018-douma-chemical-attack-watchdog-group-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 01:23:46+00:00
 - user: None

The Organization for the Prohibition of Chemical Weapons released the results of a nearly two-year-long investigation into the chemical weapons attack in Ghouta, Syria, in 2018.

## WHO updates list of medicines governments should stockpile in case of a nuclear emergency
 - [https://www.foxnews.com/health/who-updates-list-medicines-governments-should-stockpile-case-nuclear-emergency](https://www.foxnews.com/health/who-updates-list-medicines-governments-should-stockpile-case-nuclear-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 00:52:31+00:00
 - user: None

WHO released an updated report on Friday detailing medications that governments should have on hand in the event of a radiological or nuclear emergency.

## Rep. Carlos Giménez urges DHS to reconsider allowing Border Patrols chiefs to testify before Congress
 - [https://www.foxnews.com/politics/rep-carlos-gimenez-urges-dhs-reconsider-allowing-border-patrols-chiefs-testify-congress](https://www.foxnews.com/politics/rep-carlos-gimenez-urges-dhs-reconsider-allowing-border-patrols-chiefs-testify-congress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 00:49:13+00:00
 - user: None

Congressman Carlos Giménez is urging Department of Homeland Security Secretary Alejandro Mayorkas to allow four Border Patrol chiefs to testify about the southern border crisis.

## Taylor Swift casts transgender man as her love interest in latest music video
 - [https://www.foxnews.com/media/taylor-swift-casts-transgender-man-love-interest-music-video](https://www.foxnews.com/media/taylor-swift-casts-transgender-man-love-interest-music-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 00:30:44+00:00
 - user: None

Singer-songwriter Taylor Swift cast a transgender man as her love interest in the 'Lavender Haze' music video, which premiered over the weekend.

## NFL star Joey Bosa goes on explicit tirade toward heckling Eagles fan: 'You f---ing loser!'
 - [https://www.foxnews.com/sports/nfl-star-joey-bosa-explicit-tirade-toward-heckling-eagles-fan-f-ing-loser](https://www.foxnews.com/sports/nfl-star-joey-bosa-explicit-tirade-toward-heckling-eagles-fan-f-ing-loser)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 00:18:10+00:00
 - user: None

Los Angeles Chargers defensive end Joey Bosa was seen in a screaming match with a Philadelphia Eagles fan before the NFC Championship Game.

## Oregon suspect accused of torturing women is using dating apps to lure victims, evade capture: police
 - [https://www.foxnews.com/us/oregon-suspect-accused-of-torturing-women-is-using-dating-apps-victims-evade-capture-police](https://www.foxnews.com/us/oregon-suspect-accused-of-torturing-women-is-using-dating-apps-victims-evade-capture-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-30 00:04:53+00:00
 - user: None

Oregon police warned that a man accused of torturing and beating women is using dating apps to lure new victims or find assistance to evade law enforcement officers.
