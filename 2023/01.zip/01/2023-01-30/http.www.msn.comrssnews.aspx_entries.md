# Source MSN, Source URL:http://www.msn.com/rss/news.aspx, Source language: en-US

## Rep. Haley Stevens passes on 2024 Michigan Senate bid
 - [http://www.msn.com/en-us/news/politics/rep-haley-stevens-passes-on-2024-michigan-senate-bid/ar-AA16V2tH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rep-haley-stevens-passes-on-2024-michigan-senate-bid/ar-AA16V2tH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.226792+00:00
 - user: None



## Biden seemingly rejects request to send U.S. F-16s to Ukraine
 - [http://www.msn.com/en-us/news/world/biden-seemingly-rejects-request-to-send-u-s-f-16s-to-ukraine/ar-AA16V2ok?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/biden-seemingly-rejects-request-to-send-u-s-f-16s-to-ukraine/ar-AA16V2ok?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.219606+00:00
 - user: None



## UN: Taliban ban on women aid workers is potential death blow
 - [http://www.msn.com/en-us/news/us/un-taliban-ban-on-women-aid-workers-is-potential-death-blow/ar-AA16UKzW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/un-taliban-ban-on-women-aid-workers-is-potential-death-blow/ar-AA16UKzW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.212391+00:00
 - user: None



## Nearly 53,000 pounds of charcuterie meat recalled over listeria concerns
 - [http://www.msn.com/en-us/news/us/nearly-53-000-pounds-of-charcuterie-meat-recalled-over-listeria-concerns/ar-AA16UKzD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nearly-53-000-pounds-of-charcuterie-meat-recalled-over-listeria-concerns/ar-AA16UKzD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.205118+00:00
 - user: None



## Tyre Nichols’ family attorneys question white officer’s discipline after Nichols’ death
 - [http://www.msn.com/en-us/news/crime/tyre-nichols-family-attorneys-question-white-officer-s-discipline-after-nichols-death/ar-AA16VaMq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tyre-nichols-family-attorneys-question-white-officer-s-discipline-after-nichols-death/ar-AA16VaMq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.197844+00:00
 - user: None



## Russell Brand unleashes on new Biden chief of staff Jeff Zients: ‘Cronyism, corporatism, profiteering’
 - [http://www.msn.com/en-us/news/us/russell-brand-unleashes-on-new-biden-chief-of-staff-jeff-zients-cronyism-corporatism-profiteering/ar-AA16USVs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/russell-brand-unleashes-on-new-biden-chief-of-staff-jeff-zients-cronyism-corporatism-profiteering/ar-AA16USVs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.189519+00:00
 - user: None



## Biden administration will end COVID-19 emergencies on May 11
 - [http://www.msn.com/en-us/news/politics/biden-administration-will-end-covid-19-emergencies-on-may-11/ar-AA16USZ8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-administration-will-end-covid-19-emergencies-on-may-11/ar-AA16USZ8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.181852+00:00
 - user: None



## Justice Department denies GOP request for non-public information on Biden docs probe
 - [http://www.msn.com/en-us/news/politics/justice-department-denies-gop-request-for-non-public-information-on-biden-docs-probe/ar-AA16USQ1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/justice-department-denies-gop-request-for-non-public-information-on-biden-docs-probe/ar-AA16USQ1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 23:19:52.173054+00:00
 - user: None



## Steve Bannon Teases 'Plan' That Will Make RNC Critics Happy
 - [http://www.msn.com/en-us/news/politics/steve-bannon-teases-plan-that-will-make-rnc-critics-happy/ar-AA16USlQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/steve-bannon-teases-plan-that-will-make-rnc-critics-happy/ar-AA16USlQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.046399+00:00
 - user: None



## Doctor Charged with Attempted Murder After Driving Tesla off Cliff with Wife and 2 Kids Inside
 - [http://www.msn.com/en-us/news/crime/doctor-charged-with-attempted-murder-after-driving-tesla-off-cliff-with-wife-and-2-kids-inside/ar-AA16UZQf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/doctor-charged-with-attempted-murder-after-driving-tesla-off-cliff-with-wife-and-2-kids-inside/ar-AA16UZQf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.036980+00:00
 - user: None



## Where do Hollywood screenplays come from? Sometimes Washington
 - [http://www.msn.com/en-us/news/politics/where-do-hollywood-screenplays-come-from-sometimes-washington/ar-AA16UO1e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/where-do-hollywood-screenplays-come-from-sometimes-washington/ar-AA16UO1e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.029270+00:00
 - user: None



## Juvenile dies after riding bull at North Carolina rodeo
 - [http://www.msn.com/en-us/news/crime/juvenile-dies-after-riding-bull-at-north-carolina-rodeo/ar-AA16V7Vh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/juvenile-dies-after-riding-bull-at-north-carolina-rodeo/ar-AA16V7Vh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.021377+00:00
 - user: None



## Ukraine to invest $550 million in drones, defense minister says
 - [http://www.msn.com/en-us/news/world/ukraine-to-invest-550-million-in-drones-defense-minister-says/ar-AA16VaiK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-to-invest-550-million-in-drones-defense-minister-says/ar-AA16VaiK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.011870+00:00
 - user: None



## Are EPA programs creating more barriers for polluted communities?
 - [http://www.msn.com/en-us/news/us/are-epa-programs-creating-more-barriers-for-polluted-communities/ar-AA16Vbzc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/are-epa-programs-creating-more-barriers-for-polluted-communities/ar-AA16Vbzc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 22:19:49.004246+00:00
 - user: None



## Amtrak Bottleneck Turns Biden’s Focus to His Favorite Rail Route
 - [http://www.msn.com/en-us/news/us/amtrak-bottleneck-turns-biden-s-focus-to-his-favorite-rail-route/ar-AA16TktZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/amtrak-bottleneck-turns-biden-s-focus-to-his-favorite-rail-route/ar-AA16TktZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.952671+00:00
 - user: None



## Biden cites unions and infrastructure law as locomotive of economic growth
 - [http://www.msn.com/en-us/news/politics/biden-cites-unions-and-infrastructure-law-as-locomotive-of-economic-growth/ar-AA16URWk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-cites-unions-and-infrastructure-law-as-locomotive-of-economic-growth/ar-AA16URWk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.945369+00:00
 - user: None



## Lawmakers won’t compromise on police reform. Will Tyre Nichols’s killing change that?
 - [http://www.msn.com/en-us/news/politics/lawmakers-won-t-compromise-on-police-reform-will-tyre-nichols-s-killing-change-that/ar-AA16UZsC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/lawmakers-won-t-compromise-on-police-reform-will-tyre-nichols-s-killing-change-that/ar-AA16UZsC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.938030+00:00
 - user: None



## What is a Negative Balance on a Credit Card?
 - [http://www.msn.com/en-us/news/technology/what-is-a-negative-balance-on-a-credit-card/ar-AA16V7fN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/what-is-a-negative-balance-on-a-credit-card/ar-AA16V7fN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.929797+00:00
 - user: None



## Biden touts fix to Baltimore rail tunnel that he’s traveled through ‘a thousand times’
 - [http://www.msn.com/en-us/news/politics/biden-touts-fix-to-baltimore-rail-tunnel-that-he-s-traveled-through-a-thousand-times/ar-AA16UPgg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-touts-fix-to-baltimore-rail-tunnel-that-he-s-traveled-through-a-thousand-times/ar-AA16UPgg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.922110+00:00
 - user: None



## Zachary Levi’s Controversial Pfizer Tweet Is Just the Tip of the Iceberg
 - [http://www.msn.com/en-us/news/politics/zachary-levi-s-controversial-pfizer-tweet-is-just-the-tip-of-the-iceberg/ar-AA16UWOm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/zachary-levi-s-controversial-pfizer-tweet-is-just-the-tip-of-the-iceberg/ar-AA16UWOm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.913718+00:00
 - user: None



## Tesla driver is charged with attempted murder after allegedly plunging his family off a California cliff on purpose
 - [http://www.msn.com/en-us/news/crime/tesla-driver-is-charged-with-attempted-murder-after-allegedly-plunging-his-family-off-a-california-cliff-on-purpose/ar-AA16UNqC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tesla-driver-is-charged-with-attempted-murder-after-allegedly-plunging-his-family-off-a-california-cliff-on-purpose/ar-AA16UNqC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 21:19:49.906217+00:00
 - user: None



## Davis: Time to correct the record again — Hillary Clinton did not have a single email marked ‘classified’
 - [http://www.msn.com/en-us/news/politics/davis-time-to-correct-the-record-again-hillary-clinton-did-not-have-a-single-email-marked-classified/ar-AA16URbF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/davis-time-to-correct-the-record-again-hillary-clinton-did-not-have-a-single-email-marked-classified/ar-AA16URbF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.536541+00:00
 - user: None



## Biden's semiconductor push has states jockeying for billions in federal cash
 - [http://www.msn.com/en-us/news/politics/biden-s-semiconductor-push-has-states-jockeying-for-billions-in-federal-cash/ar-AA16RQtv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-s-semiconductor-push-has-states-jockeying-for-billions-in-federal-cash/ar-AA16RQtv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.529216+00:00
 - user: None



## ATF downplays impact of new gun ruling, expects 60% to register AR ‘pistols’
 - [http://www.msn.com/en-us/news/politics/atf-downplays-impact-of-new-gun-ruling-expects-60-to-register-ar-pistols/ar-AA16V9gI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/atf-downplays-impact-of-new-gun-ruling-expects-60-to-register-ar-pistols/ar-AA16V9gI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.521911+00:00
 - user: None



## Former UCLA lecturer accused of making violent threats ruled mentally unfit to stand trial
 - [http://www.msn.com/en-us/news/crime/former-ucla-lecturer-accused-of-making-violent-threats-ruled-mentally-unfit-to-stand-trial/ar-AA16V9lH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/former-ucla-lecturer-accused-of-making-violent-threats-ruled-mentally-unfit-to-stand-trial/ar-AA16V9lH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.514030+00:00
 - user: None



## Republicans Declare War on Sex Education
 - [http://www.msn.com/en-us/news/politics/republicans-declare-war-on-sex-education/ar-AA16URoh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-declare-war-on-sex-education/ar-AA16URoh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.504009+00:00
 - user: None



## Three sloth bears die in freezing temperatures after plane grounded at Belgium airport: report
 - [http://www.msn.com/en-us/news/world/three-sloth-bears-die-in-freezing-temperatures-after-plane-grounded-at-belgium-airport-report/ar-AA16UYZd?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/three-sloth-bears-die-in-freezing-temperatures-after-plane-grounded-at-belgium-airport-report/ar-AA16UYZd?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.496249+00:00
 - user: None



## 6th officer involved in Tyre Nichols' death relieved of duty
 - [http://www.msn.com/en-us/news/crime/6th-officer-involved-in-tyre-nichols-death-relieved-of-duty/ar-AA16Ucwx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/6th-officer-involved-in-tyre-nichols-death-relieved-of-duty/ar-AA16Ucwx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.488328+00:00
 - user: None



## Dolphins, humans both benefit from fishing collaboration
 - [http://www.msn.com/en-us/news/us/dolphins-humans-both-benefit-from-fishing-collaboration/ar-AA16UWsq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/dolphins-humans-both-benefit-from-fishing-collaboration/ar-AA16UWsq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 20:19:42.480044+00:00
 - user: None



## Florida to consider allowing gunowners to carry concealed guns without a permit
 - [http://www.msn.com/en-us/news/politics/florida-to-consider-allowing-gunowners-to-carry-concealed-guns-without-a-permit/ar-AA16UDTL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/florida-to-consider-allowing-gunowners-to-carry-concealed-guns-without-a-permit/ar-AA16UDTL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.925058+00:00
 - user: None



## Memphis Police Department Disbands Special Unit That Fatally Beat Tyre Nichols
 - [http://www.msn.com/en-us/news/crime/memphis-police-department-disbands-special-unit-that-fatally-beat-tyre-nichols/ar-AA16UpDM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/memphis-police-department-disbands-special-unit-that-fatally-beat-tyre-nichols/ar-AA16UpDM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.915990+00:00
 - user: None



## WATCH LIVE: Biden joins Buttigieg at 150-year-old tunnel to tout infrastructure investments
 - [http://www.msn.com/en-us/news/us/watch-live-biden-joins-buttigieg-at-150-year-old-tunnel-to-tout-infrastructure-investments/ar-AA16UpNe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/watch-live-biden-joins-buttigieg-at-150-year-old-tunnel-to-tout-infrastructure-investments/ar-AA16UpNe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.906346+00:00
 - user: None



## Paul Murdaugh’s Final Tragic Texts Revealed
 - [http://www.msn.com/en-us/news/crime/paul-murdaugh-s-final-tragic-texts-revealed/ar-AA16ULDp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/paul-murdaugh-s-final-tragic-texts-revealed/ar-AA16ULDp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.899133+00:00
 - user: None



## DOJ declines to release communication on Biden docs to House Judiciary
 - [http://www.msn.com/en-us/news/politics/doj-declines-to-release-communication-on-biden-docs-to-house-judiciary/ar-AA16UieY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-declines-to-release-communication-on-biden-docs-to-house-judiciary/ar-AA16UieY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.891861+00:00
 - user: None



## MrBeast Says He’s Raising Awareness Over Preventable Blindness. Others Smell Yet Another Stunt
 - [http://www.msn.com/en-us/news/us/mrbeast-says-he-s-raising-awareness-over-preventable-blindness-others-smell-yet-another-stunt/ar-AA16UJ1Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mrbeast-says-he-s-raising-awareness-over-preventable-blindness-others-smell-yet-another-stunt/ar-AA16UJ1Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.884239+00:00
 - user: None



## Whoopi Goldberg asks if 'we need to see White people get beat up' to see change, then quickly clarifies
 - [http://www.msn.com/en-us/news/us/whoopi-goldberg-asks-if-we-need-to-see-white-people-get-beat-up-to-see-change-then-quickly-clarifies/ar-AA16UJ2V?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/whoopi-goldberg-asks-if-we-need-to-see-white-people-get-beat-up-to-see-change-then-quickly-clarifies/ar-AA16UJ2V?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 19:19:36.874935+00:00
 - user: None



## Do classified document revelations highlight problems at the National Archives?
 - [http://www.msn.com/en-us/news/politics/do-classified-document-revelations-highlight-problems-at-the-national-archives/ar-AA16UoRj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/do-classified-document-revelations-highlight-problems-at-the-national-archives/ar-AA16UoRj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.316858+00:00
 - user: None



## “I certainly didn’t report that”: Journalist busts GOPer inventing story about Biden live on air
 - [http://www.msn.com/en-us/news/politics/i-certainly-didn-t-report-that-journalist-busts-goper-inventing-story-about-biden-live-on-air/ar-AA16U8bK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/i-certainly-didn-t-report-that-journalist-busts-goper-inventing-story-about-biden-live-on-air/ar-AA16U8bK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.309195+00:00
 - user: None



## Russia 'Didn't Take It Far Enough' in WWII, Lawmaker Says
 - [http://www.msn.com/en-us/news/world/russia-didn-t-take-it-far-enough-in-wwii-lawmaker-says/ar-AA16Uw0x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-didn-t-take-it-far-enough-in-wwii-lawmaker-says/ar-AA16Uw0x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.301778+00:00
 - user: None



## Attack on Iran Raises Tension as Blinken Visits Israel PM
 - [http://www.msn.com/en-us/news/world/attack-on-iran-raises-tension-as-blinken-visits-israel-pm/ar-AA16QCS3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/attack-on-iran-raises-tension-as-blinken-visits-israel-pm/ar-AA16QCS3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.294467+00:00
 - user: None



## Federal proposal of 'Middle East or North African' category is long overdue, advocates say
 - [http://www.msn.com/en-us/news/us/federal-proposal-of-middle-east-or-north-african-category-is-long-overdue-advocates-say/ar-AA16SKJo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/federal-proposal-of-middle-east-or-north-african-category-is-long-overdue-advocates-say/ar-AA16SKJo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.286482+00:00
 - user: None



## DOJ rejects Jordan info requests on Biden classified docs by citing special counsel appointment
 - [http://www.msn.com/en-us/news/politics/doj-rejects-jordan-info-requests-on-biden-classified-docs-by-citing-special-counsel-appointment/ar-AA16Ug8e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-rejects-jordan-info-requests-on-biden-classified-docs-by-citing-special-counsel-appointment/ar-AA16Ug8e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.277216+00:00
 - user: None



## The Good Morning America anchors who made us love cheating scandals exit ABC
 - [http://www.msn.com/en-us/news/us/the-good-morning-america-anchors-who-made-us-love-cheating-scandals-exit-abc/ar-AA150w2M?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-good-morning-america-anchors-who-made-us-love-cheating-scandals-exit-abc/ar-AA150w2M?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 18:19:30.269178+00:00
 - user: None



## The state of our union is worse off because of Joe Biden
 - [http://www.msn.com/en-us/news/politics/the-state-of-our-union-is-worse-off-because-of-joe-biden/ar-AA16U4St?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-state-of-our-union-is-worse-off-because-of-joe-biden/ar-AA16U4St?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.839801+00:00
 - user: None



## Russian Army Headed by 'Totally Incompetent People,' Ex-Russian VP Warns
 - [http://www.msn.com/en-us/news/world/russian-army-headed-by-totally-incompetent-people-ex-russian-vp-warns/ar-AA16Ufj4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-army-headed-by-totally-incompetent-people-ex-russian-vp-warns/ar-AA16Ufj4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.832778+00:00
 - user: None



## Courting DeSantis: These groups are trying to convince Florida’s governor to run for president
 - [http://www.msn.com/en-us/news/politics/courting-desantis-these-groups-are-trying-to-convince-florida-s-governor-to-run-for-president/ar-AA16TY7o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/courting-desantis-these-groups-are-trying-to-convince-florida-s-governor-to-run-for-president/ar-AA16TY7o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.825317+00:00
 - user: None



## Sixth officer is 'relieved of duty' after Tyre Nichols' death, Memphis police say
 - [http://www.msn.com/en-us/news/us/sixth-officer-is-relieved-of-duty-after-tyre-nichols-death-memphis-police-say/ar-AA16TY1Z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/sixth-officer-is-relieved-of-duty-after-tyre-nichols-death-memphis-police-say/ar-AA16TY1Z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.818246+00:00
 - user: None



## Search for tiger on the loose near South Africa's largest city
 - [http://www.msn.com/en-us/news/world/search-for-tiger-on-the-loose-near-south-africa-s-largest-city/ar-AA16U0bI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/search-for-tiger-on-the-loose-near-south-africa-s-largest-city/ar-AA16U0bI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.811025+00:00
 - user: None



## Memphis PD Disciplines Sixth Cop Involved in Tyre Nichols’ Beating
 - [http://www.msn.com/en-us/news/crime/memphis-pd-disciplines-sixth-cop-involved-in-tyre-nichols-beating/ar-AA16Ujqx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/memphis-pd-disciplines-sixth-cop-involved-in-tyre-nichols-beating/ar-AA16Ujqx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.802968+00:00
 - user: None



## Twenty-four GOP senators warn they will oppose debt limit increase without fiscal reforms
 - [http://www.msn.com/en-us/news/politics/twenty-four-gop-senators-warn-they-will-oppose-debt-limit-increase-without-fiscal-reforms/ar-AA16U4RN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/twenty-four-gop-senators-warn-they-will-oppose-debt-limit-increase-without-fiscal-reforms/ar-AA16U4RN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.795884+00:00
 - user: None



## A 6th Memphis police officer was taken off the force over Tyre Nichols' death. But he'll still be paid while his role is investigated.
 - [http://www.msn.com/en-us/news/crime/a-6th-memphis-police-officer-was-taken-off-the-force-over-tyre-nichols-death-but-he-ll-still-be-paid-while-his-role-is-investigated/ar-AA16UqTI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-6th-memphis-police-officer-was-taken-off-the-force-over-tyre-nichols-death-but-he-ll-still-be-paid-while-his-role-is-investigated/ar-AA16UqTI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 17:19:46.788276+00:00
 - user: None



## Victims identified in 6th mass shooting in 13 days to rock California
 - [http://www.msn.com/en-us/news/crime/victims-identified-in-6th-mass-shooting-in-13-days-to-rock-california/ar-AA16Seng?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/victims-identified-in-6th-mass-shooting-in-13-days-to-rock-california/ar-AA16Seng?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.687612+00:00
 - user: None



## Southwest hires its first new lobbyist in years amid multi-prong controversies
 - [http://www.msn.com/en-us/news/politics/southwest-hires-its-first-new-lobbyist-in-years-amid-multi-prong-controversies/ar-AA16TX9n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/southwest-hires-its-first-new-lobbyist-in-years-amid-multi-prong-controversies/ar-AA16TX9n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.679044+00:00
 - user: None



## Ukrainian troops are calling the US military in the middle of shootouts with Russia for help fixing their artillery
 - [http://www.msn.com/en-us/news/world/ukrainian-troops-are-calling-the-us-military-in-the-middle-of-shootouts-with-russia-for-help-fixing-their-artillery/ar-AA16UbR8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukrainian-troops-are-calling-the-us-military-in-the-middle-of-shootouts-with-russia-for-help-fixing-their-artillery/ar-AA16UbR8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.670547+00:00
 - user: None



## An Honor Foldable Phone Is Set to Go Global Soon
 - [http://www.msn.com/en-us/news/technology/an-honor-foldable-phone-is-set-to-go-global-soon/ar-AA16UbGa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/an-honor-foldable-phone-is-set-to-go-global-soon/ar-AA16UbGa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.663291+00:00
 - user: None



## Black Cat Caught Spying on Owner in Hilarious Clip: 'Danger'
 - [http://www.msn.com/en-us/news/technology/black-cat-caught-spying-on-owner-in-hilarious-clip-danger/ar-AA16UeCi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/black-cat-caught-spying-on-owner-in-hilarious-clip-danger/ar-AA16UeCi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.655163+00:00
 - user: None



## Ukraine's Zelensky wants the West to deliver him weapons faster
 - [http://www.msn.com/en-us/news/world/ukraine-s-zelensky-wants-the-west-to-deliver-him-weapons-faster/ar-AA16TSRF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-s-zelensky-wants-the-west-to-deliver-him-weapons-faster/ar-AA16TSRF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.647091+00:00
 - user: None



## The cracks in the GOP are growing into gaping holes
 - [http://www.msn.com/en-us/news/politics/the-cracks-in-the-gop-are-growing-into-gaping-holes/ar-AA16Uc7T?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-cracks-in-the-gop-are-growing-into-gaping-holes/ar-AA16Uc7T?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.638800+00:00
 - user: None



## The Pandemic Set Students Back Worse Than We Imagined
 - [http://www.msn.com/en-us/news/us/the-pandemic-set-students-back-worse-than-we-imagined/ar-AA16UgLU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/the-pandemic-set-students-back-worse-than-we-imagined/ar-AA16UgLU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 16:19:21.629267+00:00
 - user: None



## All agree: Government is biggest problem in America
 - [http://www.msn.com/en-us/news/politics/all-agree-government-is-biggest-problem-in-america/ar-AA16TPtf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/all-agree-government-is-biggest-problem-in-america/ar-AA16TPtf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.094422+00:00
 - user: None



## Meadows ally faces charge, possible plea over illegal campaign finance contribution
 - [http://www.msn.com/en-us/news/politics/meadows-ally-faces-charge-possible-plea-over-illegal-campaign-finance-contribution/ar-AA16UbjG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/meadows-ally-faces-charge-possible-plea-over-illegal-campaign-finance-contribution/ar-AA16UbjG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.087154+00:00
 - user: None



## TikTok CEO to testify before Congress in March amid app security questions
 - [http://www.msn.com/en-us/news/politics/tiktok-ceo-to-testify-before-congress-in-march-amid-app-security-questions/ar-AA16TFTD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tiktok-ceo-to-testify-before-congress-in-march-amid-app-security-questions/ar-AA16TFTD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.078312+00:00
 - user: None



## Russian Company Offers Reward for Destroying U.S. Abrams Tanks
 - [http://www.msn.com/en-us/news/world/russian-company-offers-reward-for-destroying-u-s-abrams-tanks/ar-AA16U3RN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russian-company-offers-reward-for-destroying-u-s-abrams-tanks/ar-AA16U3RN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.071127+00:00
 - user: None



## Texas salon owners consider closing shop after crime crisis leaves them waiting up 'to an hour' for police
 - [http://www.msn.com/en-us/news/crime/texas-salon-owners-consider-closing-shop-after-crime-crisis-leaves-them-waiting-up-to-an-hour-for-police/ar-AA16U91e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texas-salon-owners-consider-closing-shop-after-crime-crisis-leaves-them-waiting-up-to-an-hour-for-police/ar-AA16U91e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.062111+00:00
 - user: None



## In the West, pressure to count water lost to evaporation
 - [http://www.msn.com/en-us/news/us/in-the-west-pressure-to-count-water-lost-to-evaporation/ar-AA16U16L?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/in-the-west-pressure-to-count-water-lost-to-evaporation/ar-AA16U16L?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.054265+00:00
 - user: None



## Jim Jordan says he’s uncertain reform can stop ‘evil’ seen in Tyre Nichols video
 - [http://www.msn.com/en-us/news/politics/jim-jordan-says-he-s-uncertain-reform-can-stop-evil-seen-in-tyre-nichols-video/ar-AA16Ubug?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/jim-jordan-says-he-s-uncertain-reform-can-stop-evil-seen-in-tyre-nichols-video/ar-AA16Ubug?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 15:19:22.046196+00:00
 - user: None



## King Charles Talks Suitable Brides in Viral Clip After Harry Netflix Claims
 - [http://www.msn.com/en-us/news/world/king-charles-talks-suitable-brides-in-viral-clip-after-harry-netflix-claims/ar-AA16TTnj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/king-charles-talks-suitable-brides-in-viral-clip-after-harry-netflix-claims/ar-AA16TTnj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.155484+00:00
 - user: None



## Ukraine official gloats after drone strike on weapons facility in Russian-allied Iran: 'Ukraine did warn you'
 - [http://www.msn.com/en-us/news/world/ukraine-official-gloats-after-drone-strike-on-weapons-facility-in-russian-allied-iran-ukraine-did-warn-you/ar-AA16Tij8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-official-gloats-after-drone-strike-on-weapons-facility-in-russian-allied-iran-ukraine-did-warn-you/ar-AA16Tij8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.147280+00:00
 - user: None



## Vice President Harris to tout Latino small businesses in Raleigh
 - [http://www.msn.com/en-us/news/politics/vice-president-harris-to-tout-latino-small-businesses-in-raleigh/ar-AA16TMU7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/vice-president-harris-to-tout-latino-small-businesses-in-raleigh/ar-AA16TMU7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.138896+00:00
 - user: None



## Investigations and complaints facing George Santos could bring serious penalties
 - [http://www.msn.com/en-us/news/politics/investigations-and-complaints-facing-george-santos-could-bring-serious-penalties/ar-AA16QHoW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/investigations-and-complaints-facing-george-santos-could-bring-serious-penalties/ar-AA16QHoW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.131519+00:00
 - user: None



## Report: Michigan public school system ranks 33rd nationwide
 - [http://www.msn.com/en-us/news/us/report-michigan-public-school-system-ranks-33rd-nationwide/ar-AA16TI6F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/report-michigan-public-school-system-ranks-33rd-nationwide/ar-AA16TI6F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.124154+00:00
 - user: None



## Mortgage Refinance Rates for Jan. 30, 2023: Rates Drop
 - [http://www.msn.com/en-us/money/realestate/mortgage-refinance-rates-for-jan-30-2023-rates-drop/ar-AA16TTw5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/money/realestate/mortgage-refinance-rates-for-jan-30-2023-rates-drop/ar-AA16TTw5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.116759+00:00
 - user: None



## Trevor Noah returns as Grammy host with comfort, nervousness
 - [http://www.msn.com/en-us/news/us/trevor-noah-returns-as-grammy-host-with-comfort-nervousness/ar-AA16TN4D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/trevor-noah-returns-as-grammy-host-with-comfort-nervousness/ar-AA16TN4D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.108960+00:00
 - user: None



## Trump attacks “globalist” Ron DeSantis over COVID response in late-night Truth Social meltdown
 - [http://www.msn.com/en-us/news/politics/trump-attacks-globalist-ron-desantis-over-covid-response-in-late-night-truth-social-meltdown/ar-AA16TKOC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-attacks-globalist-ron-desantis-over-covid-response-in-late-night-truth-social-meltdown/ar-AA16TKOC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 14:19:21.099608+00:00
 - user: None



## Ohio infant dies a month after returning home from abduction
 - [http://www.msn.com/en-us/news/crime/ohio-infant-dies-a-month-after-returning-home-from-abduction/ar-AA16TQIB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ohio-infant-dies-a-month-after-returning-home-from-abduction/ar-AA16TQIB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.783829+00:00
 - user: None



## Virginia school where 6-year-old boy shot his teacher set to reopen
 - [http://www.msn.com/en-us/news/us/virginia-school-where-6-year-old-boy-shot-his-teacher-set-to-reopen/ar-AA16Ti0x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/virginia-school-where-6-year-old-boy-shot-his-teacher-set-to-reopen/ar-AA16Ti0x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.775430+00:00
 - user: None



## Ilhan Omar on previous anti-Semitic comments: 'Wasn't aware there are tropes about Jews and money'
 - [http://www.msn.com/en-us/news/politics/ilhan-omar-on-previous-anti-semitic-comments-wasn-t-aware-there-are-tropes-about-jews-and-money/ar-AA16TD7V?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ilhan-omar-on-previous-anti-semitic-comments-wasn-t-aware-there-are-tropes-about-jews-and-money/ar-AA16TD7V?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.767418+00:00
 - user: None



## Bear Pounces on Man From Behind, Mauling His Back and Legs
 - [http://www.msn.com/en-us/news/world/bear-pounces-on-man-from-behind-mauling-his-back-and-legs/ar-AA16TESM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bear-pounces-on-man-from-behind-mauling-his-back-and-legs/ar-AA16TESM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.759477+00:00
 - user: None



## NATO chief urges Seoul to send military support to Ukraine
 - [http://www.msn.com/en-us/news/world/nato-chief-urges-seoul-to-send-military-support-to-ukraine/ar-AA16TJZj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nato-chief-urges-seoul-to-send-military-support-to-ukraine/ar-AA16TJZj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.751365+00:00
 - user: None



## To reverse our discontent, America needs a national infrastructure bank
 - [http://www.msn.com/en-us/news/politics/to-reverse-our-discontent-america-needs-a-national-infrastructure-bank/ar-AA16TMhq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/to-reverse-our-discontent-america-needs-a-national-infrastructure-bank/ar-AA16TMhq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.744022+00:00
 - user: None



## I'm a Seattle native and 'equity' is destroying my once beautiful, thriving city
 - [http://www.msn.com/en-us/news/us/i-m-a-seattle-native-and-equity-is-destroying-my-once-beautiful-thriving-city/ar-AA16Tvbb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/i-m-a-seattle-native-and-equity-is-destroying-my-once-beautiful-thriving-city/ar-AA16Tvbb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.736714+00:00
 - user: None



## Here are the schools and colleges that have banned the use of ChatGPT over plagiarism and misinformation fears
 - [http://www.msn.com/en-us/news/us/here-are-the-schools-and-colleges-that-have-banned-the-use-of-chatgpt-over-plagiarism-and-misinformation-fears/ar-AA16TAxr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/here-are-the-schools-and-colleges-that-have-banned-the-use-of-chatgpt-over-plagiarism-and-misinformation-fears/ar-AA16TAxr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 13:19:18.728668+00:00
 - user: None



## Bill Gates Grilled Over Jeffrey Epstein Ties in Live TV Interview
 - [http://www.msn.com/en-us/news/world/bill-gates-grilled-over-jeffrey-epstein-ties-in-live-tv-interview/ar-AA16TJ9D?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/bill-gates-grilled-over-jeffrey-epstein-ties-in-live-tv-interview/ar-AA16TJ9D?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.751409+00:00
 - user: None



## Spanberger takes swing district views to Democratic leaders
 - [http://www.msn.com/en-us/news/politics/spanberger-takes-swing-district-views-to-democratic-leaders/ar-AA16TLiv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/spanberger-takes-swing-district-views-to-democratic-leaders/ar-AA16TLiv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.743742+00:00
 - user: None



## The Debrief: Conn Carroll on Biden’s lack of Title 42 enforcement
 - [http://www.msn.com/en-us/news/technology/the-debrief-conn-carroll-on-biden-s-lack-of-title-42-enforcement/ar-AA16TzCO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/the-debrief-conn-carroll-on-biden-s-lack-of-title-42-enforcement/ar-AA16TzCO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.735976+00:00
 - user: None



## China accuses Washington of abusing export controls
 - [http://www.msn.com/en-us/news/world/china-accuses-washington-of-abusing-export-controls/ar-AA16TLlx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/china-accuses-washington-of-abusing-export-controls/ar-AA16TLlx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.728272+00:00
 - user: None



## How effective altruists ignored risk
 - [http://www.msn.com/en-us/news/technology/how-effective-altruists-ignored-risk/ar-AA16TGBu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-effective-altruists-ignored-risk/ar-AA16TGBu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.718778+00:00
 - user: None



## In Beijing, Blinken should appeal for the freedom of ‘blank page’ protesters
 - [http://www.msn.com/en-us/news/politics/in-beijing-blinken-should-appeal-for-the-freedom-of-blank-page-protesters/ar-AA16TJeZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/in-beijing-blinken-should-appeal-for-the-freedom-of-blank-page-protesters/ar-AA16TJeZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.711175+00:00
 - user: None



## Ilhan Omar labeled a 'liar' after claiming she was unaware of 'tropes about Jews and money:' 'Give me a break'
 - [http://www.msn.com/en-us/news/politics/ilhan-omar-labeled-a-liar-after-claiming-she-was-unaware-of-tropes-about-jews-and-money-give-me-a-break/ar-AA16TzBX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ilhan-omar-labeled-a-liar-after-claiming-she-was-unaware-of-tropes-about-jews-and-money-give-me-a-break/ar-AA16TzBX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.703436+00:00
 - user: None



## Russia is preventing migrant workers from leaving the country as authorities consider more military call-ups, UK intel says
 - [http://www.msn.com/en-us/news/world/russia-is-preventing-migrant-workers-from-leaving-the-country-as-authorities-consider-more-military-call-ups-uk-intel-says/ar-AA16TCn9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-is-preventing-migrant-workers-from-leaving-the-country-as-authorities-consider-more-military-call-ups-uk-intel-says/ar-AA16TCn9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 12:19:23.695389+00:00
 - user: None



## French bakers under pressure as food, energy costs rise
 - [http://www.msn.com/en-us/news/world/french-bakers-under-pressure-as-food-energy-costs-rise/ar-AA16TouP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/french-bakers-under-pressure-as-food-energy-costs-rise/ar-AA16TouP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.356528+00:00
 - user: None



## The Computer Chip Wars: How AMD Ended Intel's Market Dominance
 - [http://www.msn.com/en-us/news/technology/the-computer-chip-wars-how-amd-ended-intel-s-market-dominance/vi-AA16Tfu0?srcref=rss](http://www.msn.com/en-us/news/technology/the-computer-chip-wars-how-amd-ended-intel-s-market-dominance/vi-AA16Tfu0?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.348748+00:00
 - user: None



## John M. Crisp: Don’t feel guilty about taxing the wealthy
 - [http://www.msn.com/en-us/news/politics/john-m-crisp-don-t-feel-guilty-about-taxing-the-wealthy/ar-AA16TBcZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/john-m-crisp-don-t-feel-guilty-about-taxing-the-wealthy/ar-AA16TBcZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.340984+00:00
 - user: None



## NASA's Artemis program works to avoid repeating past launch disasters
 - [http://www.msn.com/en-us/news/technology/nasa-s-artemis-program-works-to-avoid-repeating-past-launch-disasters/ar-AA16Tw2Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-s-artemis-program-works-to-avoid-repeating-past-launch-disasters/ar-AA16Tw2Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.333222+00:00
 - user: None



## Blinken urges Israel-Palestinian calm as violence soars
 - [http://www.msn.com/en-us/news/world/blinken-urges-israel-palestinian-calm-as-violence-soars/ar-AA16TkQ3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/blinken-urges-israel-palestinian-calm-as-violence-soars/ar-AA16TkQ3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.323243+00:00
 - user: None



## Your favorite tech giant wants you to know it’s a startup again
 - [http://www.msn.com/en-us/news/technology/your-favorite-tech-giant-wants-you-to-know-it-s-a-startup-again/ar-AA16TfN5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/your-favorite-tech-giant-wants-you-to-know-it-s-a-startup-again/ar-AA16TfN5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.315959+00:00
 - user: None



## What three hard-line conservatives plan to do with their seats on the Rules Committee
 - [http://www.msn.com/en-us/news/politics/what-three-hard-line-conservatives-plan-to-do-with-their-seats-on-the-rules-committee/ar-AA16TfN8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-three-hard-line-conservatives-plan-to-do-with-their-seats-on-the-rules-committee/ar-AA16TfN8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.308695+00:00
 - user: None



## Biden’s abortion mandates threaten pro-life VA nurse's job, but she isn’t giving up
 - [http://www.msn.com/en-us/news/us/biden-s-abortion-mandates-threaten-pro-life-va-nurse-s-job-but-she-isn-t-giving-up/ar-AA16TtBj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/biden-s-abortion-mandates-threaten-pro-life-va-nurse-s-job-but-she-isn-t-giving-up/ar-AA16TtBj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 11:19:16.301175+00:00
 - user: None



## Russians may be gone, but fear and hardship remain in a recaptured Ukrainian village
 - [http://www.msn.com/en-us/news/world/russians-may-be-gone-but-fear-and-hardship-remain-in-a-recaptured-ukrainian-village/ar-AA16T2k5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russians-may-be-gone-but-fear-and-hardship-remain-in-a-recaptured-ukrainian-village/ar-AA16T2k5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.170686+00:00
 - user: None



## U.S. arms left in Afghanistan are turning up in a different conflict
 - [http://www.msn.com/en-us/news/world/u-s-arms-left-in-afghanistan-are-turning-up-in-a-different-conflict/ar-AA16SZVm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-arms-left-in-afghanistan-are-turning-up-in-a-different-conflict/ar-AA16SZVm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.163274+00:00
 - user: None



## Senators renew call for probe of smaller AR-15 rifle they claim is targeted at kids
 - [http://www.msn.com/en-us/news/crime/senators-renew-call-for-probe-of-smaller-ar-15-rifle-they-claim-is-targeted-at-kids/ar-AA16TreC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/senators-renew-call-for-probe-of-smaller-ar-15-rifle-they-claim-is-targeted-at-kids/ar-AA16TreC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.155482+00:00
 - user: None



## Why Bryan Kohberger's DNA Presents Problem for Prosecution
 - [http://www.msn.com/en-us/news/crime/why-bryan-kohberger-s-dna-presents-problem-for-prosecution/ar-AA16T5aG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/why-bryan-kohberger-s-dna-presents-problem-for-prosecution/ar-AA16T5aG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.147539+00:00
 - user: None



## Republicans Are Desperate to Cut Spending. They Can't Agree on What.
 - [http://www.msn.com/en-us/news/politics/republicans-are-desperate-to-cut-spending-they-can-t-agree-on-what/ar-AA16TeNS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-are-desperate-to-cut-spending-they-can-t-agree-on-what/ar-AA16TeNS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.139910+00:00
 - user: None



## Texas police chief on leave after SWAT team raids the wrong house
 - [http://www.msn.com/en-us/news/crime/texas-police-chief-on-leave-after-swat-team-raids-the-wrong-house/ar-AA16TmlQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/texas-police-chief-on-leave-after-swat-team-raids-the-wrong-house/ar-AA16TmlQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.132372+00:00
 - user: None



## Indian opposition's 'unity march' ends in disputed Kashmir
 - [http://www.msn.com/en-us/news/world/indian-opposition-s-unity-march-ends-in-disputed-kashmir/ar-AA16T5aS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/indian-opposition-s-unity-march-ends-in-disputed-kashmir/ar-AA16T5aS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.123366+00:00
 - user: None



## Trudeau knows there’s trouble on the horizon
 - [http://www.msn.com/en-us/news/world/trudeau-knows-there-s-trouble-on-the-horizon/ar-AA16Td1l?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/trudeau-knows-there-s-trouble-on-the-horizon/ar-AA16Td1l?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 10:19:16.115381+00:00
 - user: None



## Gandhi Walks 2,000 Miles to Challenge Modi in 2024 Election
 - [http://www.msn.com/en-us/news/world/gandhi-walks-2-000-miles-to-challenge-modi-in-2024-election/ar-AA16SgiA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/gandhi-walks-2-000-miles-to-challenge-modi-in-2024-election/ar-AA16SgiA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 09:19:17.930162+00:00
 - user: None



## Wordle Today #590 Hints and Answer for Monday, January 30 Challenge
 - [http://www.msn.com/en-us/news/technology/wordle-today-590-hints-and-answer-for-monday-january-30-challenge/ar-AA16TlON?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/wordle-today-590-hints-and-answer-for-monday-january-30-challenge/ar-AA16TlON?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 09:19:17.922549+00:00
 - user: None



## As Blinken visits, Palestinians say Israeli troops kill a man in the West Bank
 - [http://www.msn.com/en-us/news/world/as-blinken-visits-palestinians-say-israeli-troops-kill-a-man-in-the-west-bank/ar-AA16Tc8X?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/as-blinken-visits-palestinians-say-israeli-troops-kill-a-man-in-the-west-bank/ar-AA16Tc8X?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 09:19:17.914686+00:00
 - user: None



## More mothers work part-time in NI, says report
 - [http://www.msn.com/en-us/news/world/more-mothers-work-part-time-in-ni-says-report/ar-AA16TjmW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/more-mothers-work-part-time-in-ni-says-report/ar-AA16TjmW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 09:19:17.906216+00:00
 - user: None



## North Carolina boy, 14, died from cardiac arrest after being bucked off a bull and stepped on
 - [http://www.msn.com/en-us/news/us/north-carolina-boy-14-died-from-cardiac-arrest-after-being-bucked-off-a-bull-and-stepped-on/ar-AA16T3ND?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/north-carolina-boy-14-died-from-cardiac-arrest-after-being-bucked-off-a-bull-and-stepped-on/ar-AA16T3ND?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 08:19:16.493150+00:00
 - user: None



## I'm a successful female minority truck driver. California's AB5 forced me to leave the state I love
 - [http://www.msn.com/en-us/news/us/i-m-a-successful-female-minority-truck-driver-california-s-ab5-forced-me-to-leave-the-state-i-love/ar-AA16SPDU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/i-m-a-successful-female-minority-truck-driver-california-s-ab5-forced-me-to-leave-the-state-i-love/ar-AA16SPDU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 08:19:16.485442+00:00
 - user: None



## Survivors of conflict to meet Pope Francis in Congo
 - [http://www.msn.com/en-us/news/world/survivors-of-conflict-to-meet-pope-francis-in-congo/ar-AA16Tb2n?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/survivors-of-conflict-to-meet-pope-francis-in-congo/ar-AA16Tb2n?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 08:19:16.477362+00:00
 - user: None



## NASA needs to ditch its ‘diversity’ training
 - [http://www.msn.com/en-us/news/us/nasa-needs-to-ditch-its-diversity-training/ar-AA16TiIe?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nasa-needs-to-ditch-its-diversity-training/ar-AA16TiIe?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 08:19:16.469279+00:00
 - user: None



## Top Democratic, GOP lawmakers split on Air Force general's forecast of a coming war with China
 - [http://www.msn.com/en-us/news/politics/top-democratic-gop-lawmakers-split-on-air-force-general-s-forecast-of-a-coming-war-with-china/ar-AA16SKBY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/top-democratic-gop-lawmakers-split-on-air-force-general-s-forecast-of-a-coming-war-with-china/ar-AA16SKBY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 07:19:13.111520+00:00
 - user: None



## New Zealand city to get more dangerous rainfall after flood
 - [http://www.msn.com/en-us/news/us/new-zealand-city-to-get-more-dangerous-rainfall-after-flood/ar-AA16SYDS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/new-zealand-city-to-get-more-dangerous-rainfall-after-flood/ar-AA16SYDS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 07:19:13.103634+00:00
 - user: None



## Russian embassy says North Korea lifted lockdown in capital
 - [http://www.msn.com/en-us/health/health-news/russian-embassy-says-north-korea-lifted-lockdown-in-capital/ar-AA16Sxri?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/health-news/russian-embassy-says-north-korea-lifted-lockdown-in-capital/ar-AA16Sxri?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 06:19:15.601972+00:00
 - user: None



## Tyre Nichols's parents, Monterey Park hero invited to attend State of the Union
 - [http://www.msn.com/en-us/news/crime/tyre-nichols-s-parents-monterey-park-hero-invited-to-attend-state-of-the-union/ar-AA16SYo6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/tyre-nichols-s-parents-monterey-park-hero-invited-to-attend-state-of-the-union/ar-AA16SYo6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 06:19:15.590532+00:00
 - user: None



## In the city where Tyre Nichols was killed, some refuse to watch beating video that 'exploits' Black grief
 - [http://www.msn.com/en-us/news/us/in-the-city-where-tyre-nichols-was-killed-some-refuse-to-watch-beating-video-that-exploits-black-grief/ar-AA16SCmm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/in-the-city-where-tyre-nichols-was-killed-some-refuse-to-watch-beating-video-that-exploits-black-grief/ar-AA16SCmm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 05:19:12.981488+00:00
 - user: None



## Adani says fraud claim 'calculated attack on India'
 - [http://www.msn.com/en-us/news/world/adani-says-fraud-claim-calculated-attack-on-india/ar-AA16STqZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/adani-says-fraud-claim-calculated-attack-on-india/ar-AA16STqZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 05:19:12.973533+00:00
 - user: None



## Biden visit to Baltimore highlights rail tunnel project
 - [http://www.msn.com/en-us/news/politics/biden-visit-to-baltimore-highlights-rail-tunnel-project/ar-AA16SY5S?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-visit-to-baltimore-highlights-rail-tunnel-project/ar-AA16SY5S?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 05:19:12.964967+00:00
 - user: None



## Top eight contenders for NASA's 2024 Artemis II mission that will see rocket orbit the moon
 - [http://www.msn.com/en-us/news/technology/top-eight-contenders-for-nasa-s-2024-artemis-ii-mission-that-will-see-rocket-orbit-the-moon/ar-AA16Sn9J?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/top-eight-contenders-for-nasa-s-2024-artemis-ii-mission-that-will-see-rocket-orbit-the-moon/ar-AA16Sn9J?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.162167+00:00
 - user: None



## Mark Levin calls on GOP governors to protect children's education: 'Teach history, not Marxist propaganda'
 - [http://www.msn.com/en-us/news/us/mark-levin-calls-on-gop-governors-to-protect-children-s-education-teach-history-not-marxist-propaganda/ar-AA16SE5Y?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/mark-levin-calls-on-gop-governors-to-protect-children-s-education-teach-history-not-marxist-propaganda/ar-AA16SE5Y?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.154867+00:00
 - user: None



## Tyre Nichols’ Family Accepts Invite to State of the Union Address
 - [http://www.msn.com/en-us/news/politics/tyre-nichols-family-accepts-invite-to-state-of-the-union-address/ar-AA16SJdI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tyre-nichols-family-accepts-invite-to-state-of-the-union-address/ar-AA16SJdI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.147556+00:00
 - user: None



## Germany warns against arms race as Ukraine pushes for missiles, jets
 - [http://www.msn.com/en-us/news/world/germany-warns-against-arms-race-as-ukraine-pushes-for-missiles-jets/ar-AA16SwPm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-warns-against-arms-race-as-ukraine-pushes-for-missiles-jets/ar-AA16SwPm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.139681+00:00
 - user: None



## Trump says it's 'very disloyal' of Ron DeSantis to even consider running against him in 2024
 - [http://www.msn.com/en-us/news/politics/trump-says-it-s-very-disloyal-of-ron-desantis-to-even-consider-running-against-him-in-2024/ar-AA16SzLz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-says-it-s-very-disloyal-of-ron-desantis-to-even-consider-running-against-him-in-2024/ar-AA16SzLz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.131002+00:00
 - user: None



## Taxes slow India's solar power rollout but boost manufacture
 - [http://www.msn.com/en-us/news/us/taxes-slow-india-s-solar-power-rollout-but-boost-manufacture/ar-AA16STfq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/taxes-slow-india-s-solar-power-rollout-but-boost-manufacture/ar-AA16STfq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 04:19:12.122214+00:00
 - user: None



## Texas grandma shares incredible dashcam footage from inside the eye of a TORNADO that struck her SUV
 - [http://www.msn.com/en-us/news/us/texas-grandma-shares-incredible-dashcam-footage-from-inside-the-eye-of-a-tornado-that-struck-her-suv/ar-AA16SSFH?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/texas-grandma-shares-incredible-dashcam-footage-from-inside-the-eye-of-a-tornado-that-struck-her-suv/ar-AA16SSFH?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.597568+00:00
 - user: None



## WATCH: Durbin urges Booker, Scott to revisit police reform after Tyre Nichols murder
 - [http://www.msn.com/en-us/news/politics/watch-durbin-urges-booker-scott-to-revisit-police-reform-after-tyre-nichols-murder/ar-AA16SGlR?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/watch-durbin-urges-booker-scott-to-revisit-police-reform-after-tyre-nichols-murder/ar-AA16SGlR?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.589881+00:00
 - user: None



## 5 questions and takeaways from the Trump, Biden and Pence classified documents cases
 - [http://www.msn.com/en-us/news/politics/5-questions-and-takeaways-from-the-trump-biden-and-pence-classified-documents-cases/ar-AA16PjiJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/5-questions-and-takeaways-from-the-trump-biden-and-pence-classified-documents-cases/ar-AA16PjiJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.582063+00:00
 - user: None



## Russia to require basic military training in schools in 'evocation of the Soviet Union,' UK says
 - [http://www.msn.com/en-us/news/world/russia-to-require-basic-military-training-in-schools-in-evocation-of-the-soviet-union-uk-says/ar-AA16SLiQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-to-require-basic-military-training-in-schools-in-evocation-of-the-soviet-union-uk-says/ar-AA16SLiQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.574261+00:00
 - user: None



## Omar says McCarthy following playbook ‘used by demagogues throughout history’
 - [http://www.msn.com/en-us/news/politics/omar-says-mccarthy-following-playbook-used-by-demagogues-throughout-history/ar-AA16Splo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/omar-says-mccarthy-following-playbook-used-by-demagogues-throughout-history/ar-AA16Splo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.566527+00:00
 - user: None



## The Biden administration could exclude North Africans and Middle Easterners as 'white' in the 2030 Census. New categories will prevent undercounting of MENA people, advocates say.
 - [http://www.msn.com/en-us/news/politics/the-biden-administration-could-exclude-north-africans-and-middle-easterners-as-white-in-the-2030-census-new-categories-will-prevent-undercounting-of-mena-people-advocates-say/ar-AA16SJ3z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-biden-administration-could-exclude-north-africans-and-middle-easterners-as-white-in-the-2030-census-new-categories-will-prevent-undercounting-of-mena-people-advocates-say/ar-AA16SJ3z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 03:19:11.557591+00:00
 - user: None



## Is Israel's new government destroying democracy? Blinken surveys situation on Middle East trip
 - [http://www.msn.com/en-us/news/world/is-israel-s-new-government-destroying-democracy-blinken-surveys-situation-on-middle-east-trip/ar-AA16SDCD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/is-israel-s-new-government-destroying-democracy-blinken-surveys-situation-on-middle-east-trip/ar-AA16SDCD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 02:19:10.157350+00:00
 - user: None



## Parents of Tyre Nichols invited to State of the Union address after public outcry following his death: 'Law enforcement has an obligation to do its job'
 - [http://www.msn.com/en-us/news/politics/parents-of-tyre-nichols-invited-to-state-of-the-union-address-after-public-outcry-following-his-death-law-enforcement-has-an-obligation-to-do-its-job/ar-AA16SDBM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/parents-of-tyre-nichols-invited-to-state-of-the-union-address-after-public-outcry-following-his-death-law-enforcement-has-an-obligation-to-do-its-job/ar-AA16SDBM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 02:19:10.147035+00:00
 - user: None



## DOJ ‘working’ to share info on classified Trump, Biden docs with senators: reports
 - [http://www.msn.com/en-us/news/politics/doj-working-to-share-info-on-classified-trump-biden-docs-with-senators-reports/ar-AA16SItY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-working-to-share-info-on-classified-trump-biden-docs-with-senators-reports/ar-AA16SItY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 02:19:10.139663+00:00
 - user: None



## Scotland changes policy on sending transgender inmates to all-female prison: report
 - [http://www.msn.com/en-us/news/world/scotland-changes-policy-on-sending-transgender-inmates-to-all-female-prison-report/ar-AA16Smut?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/scotland-changes-policy-on-sending-transgender-inmates-to-all-female-prison-report/ar-AA16Smut?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 02:19:10.131656+00:00
 - user: None



## Clip shows restaurant worker clasping Trump's hand while praying as he begins re-election effort
 - [http://www.msn.com/en-us/news/politics/clip-shows-restaurant-worker-clasping-trump-s-hand-while-praying-as-he-begins-re-election-effort/ar-AA16SDs2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/clip-shows-restaurant-worker-clasping-trump-s-hand-while-praying-as-he-begins-re-election-effort/ar-AA16SDs2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.608339+00:00
 - user: None



## WATCH: Attorney Ben Crump insists racial bias to blame in Tyre Nichols death
 - [http://www.msn.com/en-us/news/us/watch-attorney-ben-crump-insists-racial-bias-to-blame-in-tyre-nichols-death/ar-AA16StWE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/watch-attorney-ben-crump-insists-racial-bias-to-blame-in-tyre-nichols-death/ar-AA16StWE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.600627+00:00
 - user: None



## Funeral held for battleground body collector in Ukraine
 - [http://www.msn.com/en-us/news/world/funeral-held-for-battleground-body-collector-in-ukraine/ar-AA16Sufc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/funeral-held-for-battleground-body-collector-in-ukraine/ar-AA16Sufc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.593199+00:00
 - user: None



## How America Would Be Screwed If China Invades Taiwan
 - [http://www.msn.com/en-us/news/world/how-america-would-be-screwed-if-china-invades-taiwan/ar-AA16Sueh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-america-would-be-screwed-if-china-invades-taiwan/ar-AA16Sueh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.585990+00:00
 - user: None



## Federal proposal of 'MENA' category long overdue, advocates say
 - [http://www.msn.com/en-us/news/us/federal-proposal-of-mena-category-long-overdue-advocates-say/ar-AA16SKJo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/federal-proposal-of-mena-category-long-overdue-advocates-say/ar-AA16SKJo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.577952+00:00
 - user: None



## Russia-Ukraine live updates: Reports of 3 dead, 6 wounded in Kherson, Zelenskyy says
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-reports-of-3-dead-6-wounded-in-kherson-zelenskyy-says/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-reports-of-3-dead-6-wounded-in-kherson-zelenskyy-says/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.568637+00:00
 - user: None



## Maxine Waters says Manchin and Sinema ‘don’t give a darn’ about policing reform
 - [http://www.msn.com/en-us/news/politics/maxine-waters-says-manchin-and-sinema-don-t-give-a-darn-about-policing-reform/ar-AA16Sutr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/maxine-waters-says-manchin-and-sinema-don-t-give-a-darn-about-policing-reform/ar-AA16Sutr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 01:19:13.560577+00:00
 - user: None



## Police searching for man who threw Molotov cocktail at New Jersey temple
 - [http://www.msn.com/en-us/news/us/police-searching-for-man-who-threw-molotov-cocktail-at-new-jersey-temple/ar-AA16SkAq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/police-searching-for-man-who-threw-molotov-cocktail-at-new-jersey-temple/ar-AA16SkAq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:23.548281+00:00
 - user: None



## Rep. Jim Jordan clashes with NBC's Chuck Todd over FBI 'abusing power': 'Did the FBI not do its job?'
 - [http://www.msn.com/en-us/news/us/rep-jim-jordan-clashes-with-nbc-s-chuck-todd-over-fbi-abusing-power-did-the-fbi-not-do-its-job/ar-AA16StuI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/rep-jim-jordan-clashes-with-nbc-s-chuck-todd-over-fbi-abusing-power-did-the-fbi-not-do-its-job/ar-AA16StuI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:23.535796+00:00
 - user: None



## McConnell, Senate GOP happy to sit out debt limit talks — for now
 - [http://www.msn.com/en-us/news/politics/mcconnell-senate-gop-happy-to-sit-out-debt-limit-talks-for-now/ar-AA16SrAM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mcconnell-senate-gop-happy-to-sit-out-debt-limit-talks-for-now/ar-AA16SrAM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:23.526758+00:00
 - user: None



## 6 Dead, 3 Seriously Injured After Bus and Box Truck Collide in Upstate New York
 - [http://www.msn.com/en-us/news/crime/6-dead-3-seriously-injured-after-bus-and-box-truck-collide-in-upstate-new-york/ar-AA16SotT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/6-dead-3-seriously-injured-after-bus-and-box-truck-collide-in-upstate-new-york/ar-AA16SotT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:23.517856+00:00
 - user: None



## Drones reportedly attack convoy in east Syria coming from Iraq
 - [http://www.msn.com/en-us/news/world/drones-reportedly-attack-convoy-in-east-syria-coming-from-iraq/ar-AA16Sy7b?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/drones-reportedly-attack-convoy-in-east-syria-coming-from-iraq/ar-AA16Sy7b?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:23.506735+00:00
 - user: None



## McCarthy, Biden to meet on spending and debt; McCarthy says there will be no default
 - [http://www.msn.com/en-us/news/politics/mccarthy-biden-to-meet-on-spending-and-debt-mccarthy-says-there-will-be-no-default/ar-AA16SbVa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/mccarthy-biden-to-meet-on-spending-and-debt-mccarthy-says-there-will-be-no-default/ar-AA16SbVa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-30 00:11:22.361228+00:00
 - user: None


