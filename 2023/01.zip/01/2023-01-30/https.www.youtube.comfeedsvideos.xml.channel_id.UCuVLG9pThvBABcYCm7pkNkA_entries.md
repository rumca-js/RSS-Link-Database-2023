# Source Climate Town, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA, Source language: en-US

## The Troll Army of Big Oil | Climate Town
 - [https://www.youtube.com/watch?v=FOi05zDO4yw](https://www.youtube.com/watch?v=FOi05zDO4yw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCuVLG9pThvBABcYCm7pkNkA
 - date published: 2023-01-30 16:30:48+00:00
 - user: None

Fake it 'til you make it! Patreon: https://www.patreon.com/ClimateTown sUbScRiBe FoR mOrE ViDeOs: https://www.youtube.com/c/climatetown?sub_confirmation=1 
Sign Evergreen’s demand letter: https://www.evergreenaction.com/RealActualPeople 

Join us this Thu (2/2) at 1:45pm Eastern on Discord for a conversation with our buds at Evergreen Action. We'll be talking about the EPA, updating clean energy regulation to cut emissions, and what YOU can do to help make that happen. https://discord.gg/3ntSHWaZ?event=1069660251592343643

EPISODE SOURCES & CITATIONS: https://www.climatetownproductions.com/astroturfing 

Special thanks to Hiroko Tabuchi (https://twitter.com/HirokoTabuchi) & Rebecca Leber (https://twitter.com/rebleber) for their tireless and exhaustive reporting. Links above, but follow them on Twitter pls.

Oh what's that? We’re also on the larger Internet? 
Discord server: https://discord.gg/HFHgfMgchp 
Instagram: https://www.instagram.com/climatetown/ 
TikTok: https://www.tiktok.com/@climatetown 
Website: https://www.climatetownproductions.com/ 
LinkTree: https://linktr.ee/ClimateTown 

Make a tax-deductible donation to Climate Town: https://www.climatetownproductions.com/support 

Join and support some movements!
350.org (https://350.org/) 
Sunrise Movement (https://www.sunrisemovement.org/) 
NRDC (https://www.nrdc.org/) 
Climate Changemakers (https://www.climatechangemakers.org/) 

John Oliver Astroturfing segment: https://youtu.be/Fmh4RdIwswE 

Executive Producers: Rollie Williams, Benjamin Boult, Matt Nelsen
Writers: Rollie Williams, Matt Nelsen, Benjamin Boult
Editor: Rollie Williams
Cinematographer: Benjamin Boult (https://www.benjaminboult.com/)
Assistant Editor: Matt Nelsen (https://thelovelyuniverse.com/)
Animator: Cliffton Real (https://www.cliffreal.com/) 
Theme music by Gratis (https://www.gratistheband.com/) 
Special Thanks to Sage Welch for help with background/research
