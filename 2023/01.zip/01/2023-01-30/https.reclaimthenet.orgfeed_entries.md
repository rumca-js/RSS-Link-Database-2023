# Source Reclaim The Net, Source URL:https://reclaimthenet.org/feed/, Source language: en-US

## UK government asked Facebook to remove a post that was restricted to be seen by “Friends Only”
 - [https://reclaimthenet.org/uk-government-asked-facebook-to-remove-friends-only-post/](https://reclaimthenet.org/uk-government-asked-facebook-to-remove-friends-only-post/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 22:42:43+00:00
 - user: None

<a href="https://reclaimthenet.org/uk-government-asked-facebook-to-remove-friends-only-post/" rel="nofollow" title="UK government asked Facebook to remove a post that was restricted to be seen by “Friends Only”"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/uk-gov-fb.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Over a post regarding Covid test kits.</p>
<p>The post <a href="https://reclaimthenet.org/uk-government-asked-facebook-to-remove-friends-only-post/" rel="nofollow">UK government asked Facebook to remove a post that was restricted to be seen by “Friends Only”</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## UK government monitored tweets from high profile journalists and politicians that criticized Covid policy
 - [https://reclaimthenet.org/uk-government-monitored-politician-journalists-covid-dissent/](https://reclaimthenet.org/uk-government-monitored-politician-journalists-covid-dissent/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 20:46:43+00:00
 - user: None

<a href="https://reclaimthenet.org/uk-government-monitored-politician-journalists-covid-dissent/" rel="nofollow" title="UK government monitored tweets from high profile journalists and politicians that criticized Covid policy"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/uk-gov-monitor-journalists.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A new report reveals alarming levels of dissent surveillance.</p>
<p>The post <a href="https://reclaimthenet.org/uk-government-monitored-politician-journalists-covid-dissent/" rel="nofollow">UK government monitored tweets from high profile journalists and politicians that criticized Covid policy</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Eventbrite is threatened with lawsuit for canceling show with cardiologist Peter McCullough
 - [https://reclaimthenet.org/eventbrite-canceled-show-cardiologist-peter-mccullough/](https://reclaimthenet.org/eventbrite-canceled-show-cardiologist-peter-mccullough/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 19:40:42+00:00
 - user: None

<a href="https://reclaimthenet.org/eventbrite-canceled-show-cardiologist-peter-mccullough/" rel="nofollow" title="Eventbrite is threatened with lawsuit for canceling show with cardiologist Peter McCullough"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/McCullough.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>"Trust and safety."</p>
<p>The post <a href="https://reclaimthenet.org/eventbrite-canceled-show-cardiologist-peter-mccullough/" rel="nofollow">Eventbrite is threatened with lawsuit for canceling show with cardiologist Peter McCullough</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Anti-war Russian teen faces jail for social media posts criticizing Ukraine war
 - [https://reclaimthenet.org/anti-war-russian-teen-faces-jail-for-social-media-posts-criticizing-ukraine-war/](https://reclaimthenet.org/anti-war-russian-teen-faces-jail-for-social-media-posts-criticizing-ukraine-war/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 19:33:55+00:00
 - user: None

<a href="https://reclaimthenet.org/anti-war-russian-teen-faces-jail-for-social-media-posts-criticizing-ukraine-war/" rel="nofollow" title="Anti-war Russian teen faces jail for social media posts criticizing Ukraine war"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/Krivtsova.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Facing up to 10 years.</p>
<p>The post <a href="https://reclaimthenet.org/anti-war-russian-teen-faces-jail-for-social-media-posts-criticizing-ukraine-war/" rel="nofollow">Anti-war Russian teen faces jail for social media posts criticizing Ukraine war</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Russian commander imposes restrictions on military bloggers
 - [https://reclaimthenet.org/russian-commander-imposes-restrictions-on-military-bloggers/](https://reclaimthenet.org/russian-commander-imposes-restrictions-on-military-bloggers/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 19:28:59+00:00
 - user: None

<a href="https://reclaimthenet.org/russian-commander-imposes-restrictions-on-military-bloggers/" rel="nofollow" title="Russian commander imposes restrictions on military bloggers"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/Valery-Gerasimov.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>New rules for those reporting on the war.</p>
<p>The post <a href="https://reclaimthenet.org/russian-commander-imposes-restrictions-on-military-bloggers/" rel="nofollow">Russian commander imposes restrictions on military bloggers</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Apple’s censorship for China is starting to leak into Hong Kong
 - [https://reclaimthenet.org/apples-censorship-for-china-is-starting-to-leak-into-hong-kong/](https://reclaimthenet.org/apples-censorship-for-china-is-starting-to-leak-into-hong-kong/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 16:14:52+00:00
 - user: None

<a href="https://reclaimthenet.org/apples-censorship-for-china-is-starting-to-leak-into-hong-kong/" rel="nofollow" title="Apple&#8217;s censorship for China is starting to leak into Hong Kong"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/apple-hk87.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Evidence suggests the Big Tech giant is expanding its blacklist to Hong Kong.</p>
<p>The post <a href="https://reclaimthenet.org/apples-censorship-for-china-is-starting-to-leak-into-hong-kong/" rel="nofollow">Apple&#8217;s censorship for China is starting to leak into Hong Kong</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The censors are already beginning to target AI technology
 - [https://reclaimthenet.org/the-censors-are-already-beginning-to-target-ai-technology/](https://reclaimthenet.org/the-censors-are-already-beginning-to-target-ai-technology/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-30 16:08:29+00:00
 - user: None

<a href="https://reclaimthenet.org/the-censors-are-already-beginning-to-target-ai-technology/" rel="nofollow" title="The censors are already beginning to target AI technology"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/ai-manip.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/the-censors-are-already-beginning-to-target-ai-technology/" rel="nofollow">The censors are already beginning to target AI technology</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>
