# Source wiadomości.gazeta.pl, Source URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, Source language: pl-PL

## Zabrze. Policja zatrzymała podejrzewanego o gwałt na 17-latce. Pomogła publikacja wizerunku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416671,zabrze-policja-zatrzymala-podejrzewanego-o-gwalt-na-17-latce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416671,zabrze-policja-zatrzymala-podejrzewanego-o-gwalt-na-17-latce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 22:07:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/0c/1c/z29413277M,Policja-swiatla-policyjne.jpg" vspace="2" />Policja zatrzymała mężczyznę podejrzewanego o zgwałcenie 17-latki w Zabrzu. W namierzeniu domniemanego sprawcy przestępstwa pomogła publikacja wizerunku w internecie.

## Dolnośląskie. Były funkcjonariusz zdemolował hotel i ukradł radiowóz policjantom
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416466,dolnoslaskie-byly-funkcjonariusz-zdemolowal-hotel-i-ukradl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416466,dolnoslaskie-byly-funkcjonariusz-zdemolowal-hotel-i-ukradl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 20:04:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/0d/1c/z29416569M,Byly-funkcjonariusz-zdemolowal-hotel-i-ukradl-radi.jpg" vspace="2" />32-letni były policjant wywołał awanturę w jednym hoteli w Oleśnicy (woj. dolnośląskie), a kiedy na miejsce przyjechali policjanci, ukradł ich radiowóz i uciekł. Mężczyznę udało się zatrzymać po policyjnym pościgu i blokadzie drogi. Grozi mu za to do pięciu lat więzienia.

## Wróci zima i siarczysty mróz? Minimalna temperatura w lutym może wynieść -24 stopnie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416018,wroci-zima-i-siarczysty-mroz-minimalna-temperatura-w-lutym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416018,wroci-zima-i-siarczysty-mroz-minimalna-temperatura-w-lutym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 16:39:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/0d/1c/z29416123M,Zima---zdjecie-ilustracyjne.jpg" vspace="2" />Długoterminowe prognozy pogody wskazują, że w najbliższych tygodniach możemy mieć do czynienia z siarczystym mrozem. W południowo-wschodniej części Polski minimalna temperatura może wynieść -24 stopnie Celsjusza.

## Tragedia w Katowicach może być kolejnym zabójstwem suiscydalnym. Ekspertka: Zjawisko może się nasilać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415043,tragedia-w-katowicach-moze-byc-kolejnym-zabojstwem-suiscydalnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415043,tragedia-w-katowicach-moze-byc-kolejnym-zabojstwem-suiscydalnym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 16:24:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c7/0d/1c/z29415623M,Zabojstwo-suicydalne--zdj--ilustracyjne-.jpg" vspace="2" />Od początku roku już kilkakrotnie dochodziło w Polsce do zabójstw zakończonych samobójstwami, takim zdarzeniem najprawdopodobniej był też wybuch gazu w Katowicach. W rozmowie z Gazeta.pl eksperci wyjaśniają przyczyny zabójstw suicydalnych i zastanawiają się, czy obecnie dochodzi do nich częściej, niż zwykle. Problem stanowi jednak brak statystyk. - Intuicja zbudowana na wielu latach pracy w obszarze przemocy domowej mówi mi, że zjawisko może się nasilać - mówi kierowniczka Niebieskiej Linii.

## Zabójstwo na Nowym Świecie. Policja zatrzymała podejrzanego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416037,zabojstwo-na-nowym-swiecie-policja-zatrzymala-podejrzanego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29416037,zabojstwo-na-nowym-swiecie-policja-zatrzymala-podejrzanego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 15:36:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />Policjanci zatrzymali pierwszego z podejrzanych o zabójstwo z maja 2022 r. na Nowym Świecie w Warszawie - podaje PAP.

## Pożar miejskiego archiwum w Krakowie. Są pierwsze zarzuty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415679,pozar-miejskiego-archiwum-w-krakowie-sa-pierwsze-zarzuty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415679,pozar-miejskiego-archiwum-w-krakowie-sa-pierwsze-zarzuty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 15:02:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d7/b2/1a/z27996119M,Budynek-Archiwum-Urzedu-Miasta-po-pozarze.jpg" vspace="2" />Cztery osoby usłyszały zarzuty w śledztwie dotyczącym pożaru w Archiwum Urzędu Miasta Krakowa - podaje RMF24. Wszyskim zarzuca się poświadczenie nieprawdy w dokumentacji budowy archiwum. Grozi im do 5 lat więzienia.

## Jerzy Owsiak podsumował 31. finał WOŚP. "Przeszedł wspaniale, cudownie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415786,jerzy-owsiak-podsumowal-31-final-wosp-przeszedl-wspaniale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415786,jerzy-owsiak-podsumowal-31-final-wosp-przeszedl-wspaniale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 14:46:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/0d/1c/z29415809M,Jerzy-Owsiak.jpg" vspace="2" />- Zakończyliśmy Finał WOŚP deklarowaną kwotą 154 606 764 złote - przekazał na konferencji prasowej Jerzy Owsiak.

## Rozłam w Ordo Iuris. Co z Karoliną Pawłowską i Tymoteuszem Zychem rok po skandalu?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414767,rozlam-w-ordo-iuris-co-z-karolina-pawlowska-i-tymoteuszem-zychem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414767,rozlam-w-ordo-iuris-co-z-karolina-pawlowska-i-tymoteuszem-zychem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 14:03:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/da/19/z27109467M,Tymoteusz-Zych.jpg" vspace="2" />Karolina Pawłowska i Tomasz Zych odeszli z ultrakonserwatywnej fundacji Ordo Iuris w styczniu 2022 roku w atmosferze skandalu. Czym zajmują się teraz? Jak wygląda sytuacja samej Ordo Iuris?

## "Interwencja" dostała list pożegnalny ofiar wybuchu w Katowicach. "Prokurator podjął działania"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415241,interwencja-dostala-list-pozegnalny-ofiar-wybuchu-w-katowicach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415241,interwencja-dostala-list-pozegnalny-ofiar-wybuchu-w-katowicach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 13:49:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/0d/1c/z29415220M,Po-wybuchu-gazu-kamienica-w-Katowicach-nadaje-sie-.jpg" vspace="2" />Trzy dni po wybuchu gazu w Katowicach redakcja "Interwencji" otrzymała list, który przed śmiercią miały napisać ofiary. - Prokurator podjął działania zmierzające do zabezpieczenia tego listu - mówi w rozmowie z Gazeta.pl rzeczniczka Prokuratury Okręgowej w Katowicach Marta Zawada-Dybek.

## Małopolska. Jechali do kościoła. Porsche wpadło w poślizg i przebiło ogrodzenie plebanii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415093,malopolska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29415093,malopolska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 13:47:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/0d/1c/z29415152M,Malopolska--Porsche-przebilo-ogrodzenie-plebanii-w.jpg" vspace="2" />Zamiast do kościoła, wjechali do ogrodu plebanii w miejscowości Luszowice, w województwie małopolskim. Czteroosobowa rodzina, która jechała w niedzielę rano do kościoła, miała wypadek. Porsche, którym podróżowali, wpadło w poślizg i przebiło betonowe ogrodzenie.

## Wybuch gazu w Katowicach. Redakcja "Interwencji" dostała list, który przed śmiercią miały napisać ofiary
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414779,wybuch-gazu-w-katowicach-redakcja-interwencji-dostala-list.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414779,wybuch-gazu-w-katowicach-redakcja-interwencji-dostala-list.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 12:56:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7e/0b/1c/z29405566M,Katowice--Wybuch-gazu-w-kamienicy.jpg" vspace="2" />Trzy dni po wybuchu gazu w Katowicach redakcja "Interwencji" otrzymała list, który przed śmiercią miały napisać ofiary. Osoby, które miały napisać list, miały podkreślić, że znalazły się w trudnej sytuacji, z której nie widziały wyjścia. Zdecydowały się na zabójstwo suicydalne (potocznie zwane "samobójstwem rozszerzonym").

## Księża też wspierali WOŚP. Niektórzy oddali niedzielną tacę. "Pomagamy, bo lubimy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414424,ksieza-tez-wspierali-wosp-niektorzy-oddali-niedzielna-tace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414424,ksieza-tez-wspierali-wosp-niektorzy-oddali-niedzielna-tace.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 12:32:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/26/0d/1c/z29414694M,Ks--Wojciech-Drozdowicz.jpg" vspace="2" />- Każdy grosz się liczy, aby wspomóc tę wielką akcję, która pomaga, ale też wszystkich dzisiaj jednoczy - powiedział ks. Kamil Wołyński, proboszcz parafii polskokatolickiej w Zamościu, który niedzielną tacę przeznaczył na Wielką Orkiestrę Świątecznej Pomocy. Ale to niejedyny duchowny, który wsparł akcję.

## Make Life Harder z gigantyczną zbiórką na WOŚP. Osiągnęli 266732 proc. celu. "Pędzi jak poj***na!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413626,make-life-harder-z-gigantyczna-zbiorka-na-wosp-zebrali-266732.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413626,make-life-harder-z-gigantyczna-zbiorka-na-wosp-zebrali-266732.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 12:30:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/0d/1c/z29414748M,Zbiorka-Make-Life-Harder.jpg" vspace="2" />Skromny cel zakładał zebranie tylko tysiąca złotych, ale sympatycy Make Life Harder wpłacili za pośrednictwem memiarzy ponad 2,6 mln zł na Wielką Orkiestrę Świątecznej Pomocy. MLH pomogli też wielu mniejszym zbiórkom.

## Wojna w Ukrainie. "WSJ": W polskim zakładzie trwa naprawa ukraińskiego sprzętu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414007,wojna-w-ukrainie-wsj-w-polskim-zakladzie-trwa-naprawa-ukrainskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29414007,wojna-w-ukrainie-wsj-w-polskim-zakladzie-trwa-naprawa-ukrainskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 12:11:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/0d/1c/z29414536M,AHS-Krab-w-Ukrainie.jpg" vspace="2" />W polskiej fabryce naprawiany jest ukraiński sprzęt wykorzystywany na froncie - podaje amerykański dziennik "Wall Street Journal". Obecnie zakład zajmuje się renowacją polskich armatohaubic AHS Krab, jednak w przyszłości - zdaniem gazety - dołączyć do nich ma także sprzęt zagranicznej produkcji.

## Nowelizacja Kodeksu wyborczego będzie problemem dla gmin. "Nie ma budynków, świetlic, kościołów"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413778,nowelizacja-kodeksu-wyborczego-bedzie-problemem-dla-gmin-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413778,nowelizacja-kodeksu-wyborczego-bedzie-problemem-dla-gmin-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 10:26:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/98/1b/z28934515M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Jeśli nowelizacja Kodeksu wyborczego wejdzie w życie, część gmin może mieć poważny problem ze zorganizowaniem nowych lokali wyborczych i skompletowaniem dodatkowych komisji. - To jest dla mnie niezrozumiałe. Po co wydawać na to tyle środków finansowych, publicznych? - powiedział w rozmowie z natemat.pl wójt gminy Książki, który otwarcie mówi, że nie ma gdzie utworzyć nowych lokali. - Obiło mi się o uszy, że może zrobić lokal wyborczy na plebanii, w kościele? Ale to bez sensu - podkreślił.

## Policja kupiła kolejną licencję na sprzęt szpiegowski. Cellebrite był wykorzystywany w Rosji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413329,policja-kupila-kolejna-licencje-na-sprzet-szpiegowski-cellebrite.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413329,policja-kupila-kolejna-licencje-na-sprzet-szpiegowski-cellebrite.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 09:59:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/88/e1/1b/z29234824M,Komputer.jpg" vspace="2" />Sejm odroczył prace nad zmianami w prawie komunikacji elektronicznej, po których wprowadzeniu operatorzy byliby zobligowani dać służbom informacje na temat użytkowników bez wcześniejszej zgody sądu. Mimo to polska policja kupiła kolejną licencję umożliwiającą korzystanie z narzędzia szpiegowskiego Cellebrite.

## Ile pieniędzy zebrało WOŚP w 2023 roku, a ile przez 30 lat? [KWOTY, AKTUALIZACJA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413583,ile-pieniedzy-zebralo-wosp-w-2023-roku-a-ile-przez-30-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413583,ile-pieniedzy-zebralo-wosp-w-2023-roku-a-ile-przez-30-lat.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 09:13:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/28/0d/1c/z29413672M,31--final-WOSP-w-2023-roku.jpg" vspace="2" />W niedzielę miał miejsce 31. finał WOŚP. Po północy fundacja podała kwotę, którą udało się zebrać wolontariuszom. Czy uda się pobić rekord z 2022 roku?

## Magdalena Ogórek trafiła na SOR. Napisała o "nagłym wydarzeniu". Wzięła wolne od pracy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413539,magdalena-ogorek-trafila-na-sor-napisala-o-naglym-wydarzeniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413539,magdalena-ogorek-trafila-na-sor-napisala-o-naglym-wydarzeniu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 08:56:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f1/0d/1c/z29413617M,Magdalena-Ogorek.jpg" vspace="2" />Magdalena Ogórek poinformowała swoich fanów w weekend, że trafiła na SOR. Nie wiadomo, dlaczego prezenterka TVP Info pojechała do szpitala, zapowiedziała jedynie, że w najbliższym tygodniu nie będzie jej w pracy.

## Współpracownik Kaczyńskiego, fikcyjny ślub z górnikiem przebranym za kobietę i 20-kilogramowy pierścień
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413156,wspolpracownik-kaczynskiego-fikcyjny-slub-z-gornikiem-przebranym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413156,wspolpracownik-kaczynskiego-fikcyjny-slub-z-gornikiem-przebranym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 08:43:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/fd/1b/z29350613M,Michal-Moskal.jpg" vspace="2" />Michał Moskal, jeden z bliskich współpracowników Jarosława Kaczyńskiego, zaręczył się pod koniec grudnia, jak donosiły media, w kopalni Bogdanka. W drugiej połowie stycznia zażartowali z tego sami górnicy, którzy zaaranżowali dla Moskala fikcyjny ślub i wręczyli mu 20-kilogramowy pierścień z bryłą węgla. - Karczma porusza najgorętsze tematy, którymi żyje nasza społeczność. Nie mogło więc zabraknąć zaręczyn - podkreślił w rozmowie z "Tubą Łęcznej" przewodniczący NSZZ "Solidarność.

## Wichura nad Polską i alerty IMGW. "Ciśnienie runie", pojawią się śnieżyce i ulewy [MAPA]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413233,wichura-nad-polska-i-alerty-imgw-cisnienie-runie-pojawia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413233,wichura-nad-polska-i-alerty-imgw-cisnienie-runie-pojawia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 08:28:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/0d/1c/z29413498M,Mapa-porywow-wiatru-i-opadow---poniedzialek-30-sty.jpg" vspace="2" />W poniedziałek czeka nas bardzo dynamiczna pogoda. Synoptycy IMGW wydali już ostrzeżenia pierwszego stopnia dotyczące wichur i intensywnych opadów śniegu. W Polsce zapowiadane są także ulewy i spory spadek ciśnienia.

## Myśliwi będą zwolnieni z obowiązkowych badań lekarskich i psychologicznych? "Wstyd i hańba"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413138,mysliwi-beda-zwolnieni-z-obowiazkowych-badan-lekarskich-i-psychologicznych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413138,mysliwi-beda-zwolnieni-z-obowiazkowych-badan-lekarskich-i-psychologicznych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 08:17:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c4/57/19/z26571460M,Mysliwi-i-blokada-polowania--Lasy-w-okolicach-Wlad.jpg" vspace="2" />Myśliwi nie będą musieli stawiać się co pięć lat na badania lekarskie i psychologiczne - zadecydował Sejm. Projekt ustawy, która ma likwidować zbędne bariery administracyjne i prawne trafi teraz do Senatu. "Myśliwi nie chcą się badać, bo wiedzą, że badań by nie przeszli" - alarmuje Pracownia na rzecz Wszystkich Istot. W tym roku myśliwi po raz pierwszy musieliby przejść takie badania.

## "Wiadomości" TVP poświęciły WOŚP całe 14 sekund. Więcej mówiono o akcji braci Karnowskich
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413128,wiadomosci-tvp.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413128,wiadomosci-tvp.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 06:41:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/19/0c/1c/z29413145M,TVP-promuje-akcje-braci-Karnowskich.jpg" vspace="2" />Zaledwie 14 sekund - tyle w głównym wydaniu "Wiadomości" TVP poświęcono Wielkiej Orkiestrze Świątecznej Pomocy. Poinformowano tylko o tym, że trwa finał, a celem zbiórki jest zakup sprzętu do diagnostyki sepsy. Więcej czasu przeznaczono na wypromowanie akcji braci Karnowskich, którzy stworzyli listę zaufanych organizacji pomagających Ukrainie.

## Horała robi intelektualny szpagat. Zgwałcona 14-latka i wieprzowina w islamie. "Nazywacie się katolikami?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413130,horala-z-pis-o-zgwalconej-14-latce-i-zjedzeniu-wieprzowiny-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413130,horala-z-pis-o-zgwalconej-14-latce-i-zjedzeniu-wieprzowiny-w.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 06:37:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/53/e7/1a/z28209491M,Marcin-Horala.jpg" vspace="2" />Marcin Horała z PiS wziął udział w dyskusji na temat zgwałconej 14-latki z niepełnosprawnością, której dwaj podlascy lekarze odmówili przeprowadzenia aborcji, powołując się na klauzulę sumienia. Wiceminister komentując tę sprawę porównał ją ze "zmuszaniem muzułmanina do jedzenia wieprzowiny".

## Już ponad 154 mln na liczniku WOŚP! Ale to nie koniec, gramy dalej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413103,juz-ponad-154-mln-na-liczniku-wosp-ale-to-nie-koniec-gramy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29413103,juz-ponad-154-mln-na-liczniku-wosp-ale-to-nie-koniec-gramy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-30 05:34:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/76/0c/1c/z29411702M.jpg" vspace="2" />154 606 764 zł - tyle udało się już zebrać Wielkiej Orkiestrze Świątecznej Pomocy. W tym roku zebrane pieniądze zostaną przeznaczone na zakup sprzętu, który przyspieszy diagnostykę sepsy.
