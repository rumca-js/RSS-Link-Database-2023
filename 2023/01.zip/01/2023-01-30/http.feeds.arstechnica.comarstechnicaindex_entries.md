# Source ArsTechnica, Source URL:http://feeds.arstechnica.com/arstechnica/index/, Source language: en-US

## Google’s new AI model creates songs from text descriptions of moods, sounds
 - [https://arstechnica.com/?p=1913289](https://arstechnica.com/?p=1913289)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 22:43:54+00:00
 - user: None

Your musical wish is MusicLM's command, making hi-fi audio from "rich captions."

## Man wanted for attempted murder is using dating apps while on the run, cops say
 - [https://arstechnica.com/?p=1913479](https://arstechnica.com/?p=1913479)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 20:46:49+00:00
 - user: None

Anyone with information can call the Grants Pass Police tip line.

## Charter settles with family of murder victim, says insurance will cover it
 - [https://arstechnica.com/?p=1913433](https://arstechnica.com/?p=1913433)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 19:04:41+00:00
 - user: None

Settlement under $262 million "shouldn't cost Charter anything" due to insurance.

## COVID is still a global health emergency, but end may be near, WHO says
 - [https://arstechnica.com/?p=1913458](https://arstechnica.com/?p=1913458)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 18:55:40+00:00
 - user: None

WHO lays out path to end the emergency as pandemic reaches an "inflection point."

## Decades-old law forms biggest obstacle to nationwide TikTok ban, lawmaker says
 - [https://arstechnica.com/?p=1913428](https://arstechnica.com/?p=1913428)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 18:44:30+00:00
 - user: None

TikTok's CEO agrees to testify before Congress for the first time in March.

## Count on old-school fun with these new calculator emulations
 - [https://arstechnica.com/?p=1913351](https://arstechnica.com/?p=1913351)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 18:24:26+00:00
 - user: None

14 number crunchers from Texas Instruments, HP, and more that you can click.

## Massive Yandex code leak reveals Russian search engine’s ranking factors
 - [https://arstechnica.com/?p=1913325](https://arstechnica.com/?p=1913325)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 17:37:11+00:00
 - user: None

Details show how the world's fourth-largest search engine ranks webpages.

## Report: Apple is planning both a foldable screen and a kickstand for the iPad
 - [https://arstechnica.com/?p=1913324](https://arstechnica.com/?p=1913324)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 17:12:55+00:00
 - user: None

Rumors of an even-larger iPad have persisted for a couple of years now.

## Renault and Nissan hammer out historic deal to salvage alliance
 - [https://arstechnica.com/?p=1913381](https://arstechnica.com/?p=1913381)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 17:04:01+00:00
 - user: None

Pact aims to close bitter chapter following arrest of former boss Carlos Ghosn in 2018.

## Best deals on accessories for your new MacBook Pro M2
 - [https://arstechnica.com/?p=1911947](https://arstechnica.com/?p=1911947)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 17:00:24+00:00
 - user: None

USB-C hubs, extra storage, stands, and cases for your MacBook Pro at a discount

## The stakes couldn’t be higher in final trailer for Star Trek: Picard S3
 - [https://arstechnica.com/?p=1913308](https://arstechnica.com/?p=1913308)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 16:24:01+00:00
 - user: None

"We fight or we die."

## Ford follows Tesla’s lead, cuts prices on Mustang Mach-E
 - [https://arstechnica.com/?p=1913322](https://arstechnica.com/?p=1913322)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 15:11:24+00:00
 - user: None

Ford is increasing production in North America and Europe by 67% to meet demand.

## After a failure 4 months ago, the New Shepard spacecraft remains in limbo
 - [https://arstechnica.com/?p=1912980](https://arstechnica.com/?p=1912980)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 13:55:23+00:00
 - user: None

Blue Origin has said nothing publicly about the September failure of New Shepard.

## The generative AI revolution has begun—how did we get here?
 - [https://arstechnica.com/?p=1912999](https://arstechnica.com/?p=1912999)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 12:00:20+00:00
 - user: None

A new class of incredibly powerful AI models has made recent breakthroughs possible.

## HBO’s The Last of Us tries a little tenderness in a surprising episode 3
 - [https://arstechnica.com/?p=1912957](https://arstechnica.com/?p=1912957)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-30 12:00:07+00:00
 - user: None

Kyle and Andrew fall in love with Nick Offerman's Bill and his dystopian love story.
