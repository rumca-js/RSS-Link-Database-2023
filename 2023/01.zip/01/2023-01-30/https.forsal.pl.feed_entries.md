# Source Forsal.pl, Source URL:https://forsal.pl/.feed, Source language: pl-PL

## Blinken: Odchodzenie od rozwiązania dwupaństwowego jest zagrożeniem dla bezpieczeństwa Izraela
 - [https://forsal.pl/swiat/usa/artykuly/8649593,blinken-odchodzenie-od-rozwiazania-dwupanstwowego-jest-zagrozeniem-dla-bezpieczenstwa-izraela.html](https://forsal.pl/swiat/usa/artykuly/8649593,blinken-odchodzenie-od-rozwiazania-dwupanstwowego-jest-zagrozeniem-dla-bezpieczenstwa-izraela.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 21:01:39+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1NBktkuTURBXy9kOGQ0NTVmZC1kMjllLTRjYjEtOTk5Mi03MWUzNjE2YjE4ODIuanBlZ5GTBc0BHcyg" />Jakiekolwiek ruchy oddalające rozwiązanie konfliktu oparte na dwóch państwach będzie wiązać się ze szkodą dla długoterminowego bezpieczeństwa Izraela - ostrzegł po spotkaniu z izraelskim premierem Benjaminem Netanjahu szef amerykańskiej dyplomacji Antony Blinken. Obaj politycy rozmawiali też o pogłębieniu współpracy w powstrzymywaniu Iranu, w tym na Ukrainie.

## Scholz: Chile pożądanym partnerem w czasie uniezależniania się od rosyjskich paliw
 - [https://forsal.pl/biznes/energetyka/artykuly/8649590,scholz-chile-pozadanym-partnerem-w-czasie-uniezalezniania-sie-od-rosyjskich-paliw.html](https://forsal.pl/biznes/energetyka/artykuly/8649590,scholz-chile-pozadanym-partnerem-w-czasie-uniezalezniania-sie-od-rosyjskich-paliw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:57:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IPXktkuTURBXy82ZWE5ODI1Zi1jZWE2LTRjMjEtODUzYi1jMmE1NjQwMGRmMGQuanBlZ5GTBc0BHcyg" />Kanclerz Niemiec Olaf Scholz oświadczył w poniedziałek podczas wizyty w stolicy Chile, że kraj ten jest „pożądanym partnerem” dla jego kraju w dążeniu do konsolidacji niezależności od rosyjskiego gazu i ropy naftowej.

## Trzy osoby zostały ranne w ataku nożownika w metrze w Brukseli
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649588,trzy-osoby-zostaly-ranne-w-ataku-nozownika-w-metrze-w-brukseli.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649588,trzy-osoby-zostaly-ranne-w-ataku-nozownika-w-metrze-w-brukseli.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:50:11+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TJ8ktkuTURBXy8xNTM4MWFiZi03NDBhLTQ0YjEtOWY2NS1hNjVjM2ZkOTE4ZDAuanBlZ5GTBc0BHcyg" />Trzy osoby zostały ranne w poniedziałkowym ataku nożownika w metrze w Brukseli. Napastnik został zatrzymany. Stan jednego z poszkodowanych jest krytyczny - poinformowała belgijska policja.

## Bundeswehra poszukuje rezerwistów do pomocy w szkoleniu ukraińskich żołnierzy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649574,bundeswehra-poszukuje-rezerwistow-pomoc-szkolenie-ukrainskich-zolnierzy.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649574,bundeswehra-poszukuje-rezerwistow-pomoc-szkolenie-ukrainskich-zolnierzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:46:39+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Kf_ktkuTURBXy85YzU3YjBmMi00NmU0LTQ1ZTUtOWZlOS0yMjhjNWUzNDY4NjMuanBlZ5GTBc0BHcyg" />Bundeswehra poszukuje około 50 rezerwistów do pomocy w szkoleniu ukraińskich żołnierzy, wynika z prośby Dowództwa Operacyjnego skierowanej do Związku Rezerwistów - pisze w poniedziałek portal tygodnika &quot;Spiegel&quot;.

## Szalay-Bobrovniczky: Węgry podobnie jak Austria nie wyśle broni na Ukrainę
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649559,szalay-bobrovniczky-wegry-jak-austria-nie-wysle-broni-na-ukraine.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649559,szalay-bobrovniczky-wegry-jak-austria-nie-wysle-broni-na-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:34:45+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gLMktkuTURBXy85MTM1OWYyYy1lM2QzLTRiYTAtYTViYi0xNzdmYjNlMGQ2N2MuanBlZ5GTBc0BHcyg" />Nie wysyłamy broni na Ukrainę, ponieważ chcemy uniknąć eskalacji konfliktu. Pod tym względem zgadzamy się Austrią, która jest państwem neutralnym - powiedział w poniedziałek minister obrony Węgier Kristof Szalay-Bobrovniczky po spotkaniu ze swoją austriacką odpowiedniczką Klaudią Tanner w Budapeszcie.

## Stoltenberg o wojnie w Ukrainie: Putin szykuje nowe ataki. Jego cel pozostaje niezmienny
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649543,stoltenberg-wojna-w-ukrainie-putin-nowe-ataki-cel-pozostaje-niezmienny.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649543,stoltenberg-wojna-w-ukrainie-putin-nowe-ataki-cel-pozostaje-niezmienny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:28:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/k7tktkuTURBXy81N2YzYTQ2Yy1iNjk5LTRhZjMtYjIyMC01MGNjYjVkOTQ3YmUuanBlZ5GTBc0BHcyg" />Putin szykuje nowe ataki, mobilizuje więcej żołnierzy i pozyskuje więcej broni i amunicji, a cel, jakim jest opanowanie Ukrainy, pozostaje niezmienny - powiedział w poniedziałek w stolicy Korei Południowej Seulu sekretarz generalny NATO Jens Stoltenberg.

## Finlandia chce wejść do NATO wspólnie ze Szwecją. Nawet wbrew Turcji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649525,finlandia-chce-wejsc-do-nato-wspolnie-ze-szwecja-nawet-wbrew-turcji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649525,finlandia-chce-wejsc-do-nato-wspolnie-ze-szwecja-nawet-wbrew-turcji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:23:24+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TO8ktkuTURBXy9kZjM0MDYyYi1iNmI5LTRhYjEtYTU0YS1lNzU2NWM0NDVjMjMuanBlZ5GTBc0BHcyg" />Szef fińskiej dyplomacji Pekka Haavisto oświadczył w poniedziałek, że Finlandia podtrzymuje swoje stanowisko z wiosny 2022 roku o wspólnej akcesji do NATO ze Szwecją. Podobne zdanie wyraził w mediach prezydent Finlandii Sauli Niinisto.

## Dania będzie przyznawać Afgankom azyl. Reżim talibów pozbawia je praw
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649519,dania-bedzie-przyznawac-afgankom-azyl-rezim-talibow-pozbawia-je-praw.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649519,dania-bedzie-przyznawac-afgankom-azyl-rezim-talibow-pozbawia-je-praw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 20:19:23+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1UlktkuTURBXy9mZmJlMGM2NS0xODAzLTQxYmEtODM3My1kMTc4YTZjMDU3NWEuanBlZ5GTBc0BHcyg" />Dania będzie przyznawać Afgankom azyl i status uchodźczyń, ponieważ od powrotu talibów do władzy są one w swoim kraju coraz bardziej pozbawiane praw - ogłosiła w poniedziałek duńska komisja do spraw uchodźców.

## Wallace: Brytyjskie Challengery trafią na Ukrainę jeszcze przed latem
 - [https://forsal.pl/swiat/ukraina/artykuly/8649274,wallace-brytyjskie-challengery-trafia-na-ukraine-jeszcze-przed-latem.html](https://forsal.pl/swiat/ukraina/artykuly/8649274,wallace-brytyjskie-challengery-trafia-na-ukraine-jeszcze-przed-latem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 19:31:29+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uUwktkuTURBXy85M2UzM2I0YS04ZjIxLTQ4MzktYjIwNC1hMzI3NTg0MTI2NGIuanBlZ5GTBc0BHcyg" />Brytyjski minister obrony Ben Wallace potwierdził w poniedziałek, że przekazane Ukrainie czołgi Challenger 2 trafią na linię frontu przed latem, ale nie sprecyzował, kiedy dokładnie to nastąpi. Przyznał natomiast, że siły zbrojne wymagają pilnego dofinansowania.

## Wasylenko: Blisko jedna trzecia Ukrainy pokryta jest minami i materiałami wybuchowymi
 - [https://forsal.pl/swiat/ukraina/artykuly/8649272,wasylenko-jedna-trzecia-ukrainy-pokryta-minami-materialami-wybuchowymi.html](https://forsal.pl/swiat/ukraina/artykuly/8649272,wasylenko-jedna-trzecia-ukrainy-pokryta-minami-materialami-wybuchowymi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 19:18:16+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cYpktkuTURBXy84ZDJhNGIzYy0zODk1LTQxYjEtYjk2YS1iM2ExYjE4ZTIwMjguanBlZ5GTBc0BHcyg" />Około 30 proc. terytorium Ukrainy jest pokryte minami i materiałami wybuchowymi, a nieusunięcie ich może wywołać &quot;efekt domina&quot; w Europie i Afryce, powiedziała deputowana do Rady Najwyższej Ukrainy Łesia Wasylenko w wystąpieniu skierowanym do Rady Europy, zrelacjonowanym w poniedziałek przez ukraiński parlament na Twitterze.

## Orban: Europa powinna postawić na dostawy surowców energetycznych z Azerbejdżanu
 - [https://forsal.pl/biznes/energetyka/artykuly/8649164,orban-europa-dostawy-surowcow-energetycznych-z-azerbejdzanu.html](https://forsal.pl/biznes/energetyka/artykuly/8649164,orban-europa-dostawy-surowcow-energetycznych-z-azerbejdzanu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 19:09:13+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QxtktkuTURBXy9lYzY1NDgwNy00YjU5LTRiNzMtYTcwNi0yMzhjOWNmNjU0ZGQuanBlZ5GTBc0BHcyg" />W chwili obecnej najbardziej realnym scenariuszem dywersyfikacji dla Europy jest transport energii z Azerbejdżanu - powiedział w poniedziałek w Budapeszcie premier Węgier Viktor Orban na wspólnej konferencji z prezydentem Azerbejdżanu Ilhamem Alijewem.

## Koalicja sześciu tureckich opozycyjnych partii zapowiedziała walkę z prezydentemi Erdoganem
 - [https://forsal.pl/gospodarka/polityka/artykuly/8649148,koalicja-6-tureckich-opozycyjnych-partii-walka-prezydent-erdogan.html](https://forsal.pl/gospodarka/polityka/artykuly/8649148,koalicja-6-tureckich-opozycyjnych-partii-walka-prezydent-erdogan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 18:17:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pb6ktkuTURBXy8yYjk5ZDk0Yy0yMGE0LTRiZWItYmEyZC1iOGE0YWUyNDFlNWUuanBlZ5GTBc0BHcyg" />Opozycyjny sojusz w Turcji ogłosił w poniedziałek swój program, mający na celu ograniczenie władzy prezydenta i rozszerzenie praw demokratycznych; sześć partii zjednoczonych przeciwko prezydentowi Recepowi Tayyipowi Erdoganowi zobowiązało się również do uzgodnienia w przyszłym miesiącu wspólnego kandydata na prezydenta - poinformował portal thenationalnews.com.

## Francja i Australia wspólnie będą produkować pociski artyleryjskie dla Ukrainy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649146,francja-i-australia-wspolnie-produkowac-pociski-artyleryjskie-ukraina.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649146,francja-i-australia-wspolnie-produkowac-pociski-artyleryjskie-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 17:59:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WsnktkuTURBXy83ZWZlZjVmNC1kYzI1LTQ1MWUtODQ1Ni1mYjU4MDRmNDk0OGMuanBlZ5GTBc0BHcyg" />Francja i Australia zgodziły się na współpracę przy produkcji 155-milimetrowych pocisków dla Ukrainy - poinformowała w poniedziałek agencja Reutera.

## Polacy coraz chętniej akceptują rosyjską propagandą [RAPORT]
 - [https://forsal.pl/swiat/rosja/artykuly/8649142,polacy-coraz-chetniej-akceptuja-rosyjska-propaganda.html](https://forsal.pl/swiat/rosja/artykuly/8649142,polacy-coraz-chetniej-akceptuja-rosyjska-propaganda.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 17:24:50+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/C87ktkuTURBXy83ZDllYzM0Yi1hZWJhLTQ0ODktODliNi04YmJjYjkzY2FmZDEuanBlZ5GTBc0BHcyg" />Rośnie liczba Polaków o opiniach zbieżnych z rosyjską propagandą, szczególnie w kwestii postaw dotyczących Rosji i wojny w Ukrainie - wynika z raportu opublikowanego przez Warsaw Enterprise Institute. &quot;Wojna nie toczy się tylko na polu bitwy, ale także w ludzkich umysłach&quot; - wskazują eksperci.

## EBC: W 2022 r. z obiegu wycofano 367 tys. fałszywych banknotów euro. To więcej o prawie 9 proc. rdr
 - [https://forsal.pl/finanse/waluty/artykuly/8649137,ebc-2022-z-obiegu-wycofano-367-tys-falszywek-euro-wiecej-o-9-proc-rdr.html](https://forsal.pl/finanse/waluty/artykuly/8649137,ebc-2022-z-obiegu-wycofano-367-tys-falszywek-euro-wiecej-o-9-proc-rdr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 17:12:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zVwktkuTURBXy8wMzU2MDIyZC1hMmI3LTRjNTEtOTE3ZC01MTQ0OGI2ODRjNDMuanBlZ5GTBc0BHcyg" />Na całym świecie wycofano w ubiegłym roku z obiegu 376 tys. fałszywych banknotów euro, co oznacza wzrost o 8,4 proc. w porównaniu z 2021 r. - informuje w poniedziałek Europejski Bank Centralny (EBC).

## Dziś złoty traci do euro i dolara, zyskuje wobec franka szwajcarskiego
 - [https://forsal.pl/finanse/waluty/artykuly/8649094,dzis-zloty-traci-do-euro-i-dolara-zyskuje-wobec-franka-szwajcarskiego.html](https://forsal.pl/finanse/waluty/artykuly/8649094,dzis-zloty-traci-do-euro-i-dolara-zyskuje-wobec-franka-szwajcarskiego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 17:00:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6tCktkuTURBXy9iY2YwNzJlZi0zNjdjLTQ0OTQtYjU3OC1jMjAxNThkYTVmZjcuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 17 polska waluta traciła 0,18 proc., wobec euro, które kosztowało 4,71zł. Dolar amerykański drożał o 0,08 proc. do 4,33 zł, a kurs franka szwajcarskiego spadł o 0,10 proc. do 4,69 zł.

## Pistorius: Wszystko o dostawie samolotów myśliwskich dla Ukrainy zostało już powiedziane
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649056,pistorius-dostawa-samolotow-mysliwskich-ukrainy-zostalo-juz-powiedziane.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649056,pistorius-dostawa-samolotow-mysliwskich-ukrainy-zostalo-juz-powiedziane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 16:58:06+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/V8iktkuTURBXy9hMTYwNDVjNC1jMDYyLTQ3ZGQtYWVlMS05ZjhhMDAzNWVkYTQuanBlZ5GTBc0BHcyg" />Minister obrony RFN Boris Pistorius nie chce się angażować w debatę na temat przekazania myśliwców Ukrainie po decyzji o dostarczeniu czołgów - pisze w poniedziałek agencja dpa. &quot;O ile wiem, kanclerz powiedział wszystko, co trzeba powiedzieć&quot; - stwierdził minister. Scholz przestrzegł niedawno przed &quot;licytowaniem się&quot; na systemy uzbrojenia.

## Podolak zasugerował udział Ukrainy w aktaku w Isfahanie? Irańskie MSZ żąda wyjaśnień
 - [https://forsal.pl/swiat/ukraina/artykuly/8649049,podolak-sugestia-udzial-ukrainy-atak-isfahan-iran-msz-zada-wyjasnien.html](https://forsal.pl/swiat/ukraina/artykuly/8649049,podolak-sugestia-udzial-ukrainy-atak-isfahan-iran-msz-zada-wyjasnien.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 16:50:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hntktkuTURBXy8yMDg4YjhlMy1iY2FmLTRiY2ItYTk1ZC0xYTY4ZGIyYjE1ZmQuanBlZ5GTBc0BHcyg" />Ministerstwo Spraw Zagranicznych Iranu wezwało charge d'affaires Ukrainy w związku z komentarzami doradcy ukraińskiego prezydenta, które Teheran postrzega jako udział Kijowa w sobotnim ataku dronów na instalacje wojskowe w Isfahanie - poinformował w poniedziałek niezależny kanał Iran International.

## Węgierscy hotelarze w 2022 roku zarobili 668 mld forintów. To 52 proc. więcej niż rok wcześniej
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649036,wegry-hotelarze-2022-zarobili-668-mld-forintow-52-proc-wiecej-rdr.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649036,wegry-hotelarze-2022-zarobili-668-mld-forintow-52-proc-wiecej-rdr.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 16:15:10+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XQmktkuTURBXy80YzEyNThhZC1hNWZmLTQ0ZTUtYmM0Ni0yN2E5Y2JmNDExZjQuanBlZ5GTBc0BHcyg" />Przychody hoteli na Węgrzech w 2022 roku wyniosły 668 mld forintów (około 8 mld zł) i były o 52 proc. wyższe niż w roku poprzednim - poinformował w poniedziałek na konferencji prasowej Zoltan Guller, prezes zarządu Węgierskiej Agencji Turystyki (MTU).

## Młodzi Brytyjczycy boją się rosnących kosztów życia. Prawie połowa z nich uważa, że nie utrzyma rodziny
 - [https://forsal.pl/praca/kariera/artykuly/8649029,mlodzi-brytyjczycy-rosnace-koszty-zycia-polowa-nie-utrzyma-rodziny.html](https://forsal.pl/praca/kariera/artykuly/8649029,mlodzi-brytyjczycy-rosnace-koszty-zycia-polowa-nie-utrzyma-rodziny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:59:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m6KktkuTURBXy8wOThiNDJhNy1hZDZiLTQ2MTctOWU4OS1iOTg1NzFhMzEyYmMuanBlZ5GTBc0BHcyg" />Prawie połowa wszystkich młodych ludzi w Wielkiej Brytanii - z grupy wiekowej 16-25 lat - obawia się, że nigdy nie będzie zarabiać wystarczająco dużo, aby utrzymać rodzinę - wynika z opublikowanego w poniedziałek raportu organizacji charytatywnej Prince's Trust.

## Buda: Polskie PKB w 2022 r. wzrosło o 4,9 proc. To więcej niż w roku przed pandemią
 - [https://forsal.pl/gospodarka/pkb/artykuly/8649025,buda-polskie-pkb-2022-r-wzroslo-o-49-proc-wiecej-niz-przed-pandemia.html](https://forsal.pl/gospodarka/pkb/artykuly/8649025,buda-polskie-pkb-2022-r-wzroslo-o-49-proc-wiecej-niz-przed-pandemia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:45:28+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sYbktkuTURBXy9hYTJmNWQ5NC0yZGEyLTRlMWEtOWI4Yy0wNGUyMTIwMWNlMDAuanBlZ5GTBc0BHcyg" />To był trudny rok dla polskiej i światowej gospodarki. Mimo to dane GUS pokazują, że w 2022 r. polskie PKB wzrosło o 4,9 proc., co jest dobrym wynikiem, wyższym niż w 2019 r. – ocenił minister rozwoju i technologii Waldemar Buda w poniedziałek w wypowiedzi dla PAP.

## „Bild”: Scholz chce osobiście przejąć stery polityki zagranicznej. W tle konflikt z szefową MSZ
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8649018,bild-scholz-stery-polityki-zagranicznej-konflikt-z-szefowa-msz.html](https://forsal.pl/swiat/unia-europejska/artykuly/8649018,bild-scholz-stery-polityki-zagranicznej-konflikt-z-szefowa-msz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:38:13+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yfPktkuTURBXy8wOTkwMDkwYy02Y2ZhLTQyYjQtYTk5NS01ODkwZDRmYjQ2ZDguanBlZ5GTBc0BHcyg" />Kanclerz Olaf Scholz (SPD) jest ostatnio „poirytowany” działaniami i wypowiedziami minister spraw zagranicznych Annaleny Baerbock (Zieloni). Jej błędy są „skrzętnie odnotowywane” przez Kancelarię – informuje w poniedziałek portal dziennika Bild”. Zwolennicy minister Baerbock podkreślają, że stanowi ona przeciwwagę dla „wahającego” się kanclerza.

## PKO BP: W 2023 r. inflacja nie wpłynie na PKB, a RPP zakończyła podwyżki stóp proc.
 - [https://forsal.pl/gospodarka/pkb/artykuly/8649014,pko-bp-2023-r-inflacja-nie-wplynie-pkb-rpp-koniec-podwyzki-stop-proc.html](https://forsal.pl/gospodarka/pkb/artykuly/8649014,pko-bp-2023-r-inflacja-nie-wplynie-pkb-rpp-koniec-podwyzki-stop-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:23:55+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pCJktkuTURBXy9hZTZkNWYyMi00ZTBjLTQ4MDctOGNlZi00YzU0ZTJjZGNiOGEuanBlZ5GTBc0BHcyg" />Struktura PKB w 2023 r. będzie dezinflacyjna, co oznacza, że Rada Polityki Pieniężnej (RPP) zakończyła podwyżki stóp procentowych, oceniają analitycy PKO Banku Polskiego. Według nich, wynik PKB w IV kw. ub. wykazał silnie słabnącą konsumpcję prywatną oraz zyskujący popyt zewnętrzny inwestycyjny, wpisując się w ścieżkę dezinflacji w kolejnych miesiącach

## Szpitalowi Uniwersyteckiemu w Krakowie grozi paraliż. Prawie 600 pielęgniarek rozważa pozew sądowy
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8649009,szpital-uniwersytecki-krakow-paraliz-600-pielegniarek-pozew-sadowy.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8649009,szpital-uniwersytecki-krakow-paraliz-600-pielegniarek-pozew-sadowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:11:30+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1XiktkuTURBXy82M2JiOGY4MS0xMmM1LTRhZDEtODkxMy1lODQ4OGRhMzRkMzIuanBlZ5GTBc0BHcyg" />Prawie 600 pielęgniarek ze Szpitala Uniwersyteckiego w Krakowie rozważa pozew sądowy w związku z tym, że – jak poinformowały – pracodawca nie uznaje ich magisterskich kwalifikacji, co wpływa na obniżenie wynagrodzenia. Placówka jest po kontroli inspekcji pracy, która nie stwierdziła nieprawidłowości.

## Trakcja miała wstępnie 15,49 mln zł jednostkowej straty netto w IV kw. 2022 r.
 - [https://forsal.pl/finanse/gielda/artykuly/8649006,trakcja-miala-wstepnie-1549-mln-zl-jednostkowej-straty-netto-w-iv-kw-2022-r.html](https://forsal.pl/finanse/gielda/artykuly/8649006,trakcja-miala-wstepnie-1549-mln-zl-jednostkowej-straty-netto-w-iv-kw-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 15:02:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fBMktkuTURBXy81ZTVlNDFlNy1hMzE1LTRlMGMtYmRjZS02NDlhZGZmZTk3NWIuanBlZ5GTBc0BHcyg" />Trakcja miała 297,55 mln zł jednostkowych przychodów ze sprzedaży, 6,69 mln zł zysku EBITDA oraz 15,49 mln zł straty netto w IV kw. 2022 r., podała spółka, prezentując wstępne dane.

## Baltic Power otrzymał pierwsze pozwolenie na budowę lądowej części inwestycji
 - [https://forsal.pl/biznes/energetyka/artykuly/8649001,baltic-power-otrzymal-pierwsze-pozwolenie-na-budowe-ladowej-czesci-inwestycji.html](https://forsal.pl/biznes/energetyka/artykuly/8649001,baltic-power-otrzymal-pierwsze-pozwolenie-na-budowe-ladowej-czesci-inwestycji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 14:59:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y0mktkuTURBXy9mNGEyN2NlOS05NDJiLTQ1MWYtOWYzNC02NTQ1YWVlZWI0ZGIuanBlZ5GTBc0BHcyg" />Baltic Power - spółka z Grupy PKN Orlen - uzyskał pierwsze z kilku niezbędnych pozwoleń na budowę dla projektu morskiej farmy wiatrowej o mocy 1,2 GW, jednocześnie pierwsze w ogóle tego typu pozwolenie wydane dla proejktu offshore wind realizowanego w Polsce, poinformował prezes PKN Orlen Daniel Obajtek.

## Blisko 7,6 proc. Polaków mieszkających w Anglii i Walii posiada brytyjskie obywatelstwo
 - [https://forsal.pl/swiat/brexit/artykuly/8649000,76-proc-polakow-w-anglii-i-walii-posiada-brytyjskie-obywatelstwo.html](https://forsal.pl/swiat/brexit/artykuly/8649000,76-proc-polakow-w-anglii-i-walii-posiada-brytyjskie-obywatelstwo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 14:57:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5B6ktkuTURBXy8xODAzYTc3MC0wZjFiLTQ4NzQtYjc2Ni03MWRmMDRlY2JkOWEuanBlZ5GTBc0BHcyg" />Niecałe 7,6 proc. mieszkańców Anglii i Wali, którzy urodzili się w Polsce, posługuje się brytyjskim paszportem; to jeden z najniższych wskaźników wśród osób urodzonych poza granicami Zjednoczonego Królestwa - wynika z danych ze spisu powszechnego.

## Blinken z wizytą na Bliskim Wschodzie. Z prezydentem Egiptu omówił kwestie bezpieczeństwa w regionie
 - [https://forsal.pl/swiat/usa/artykuly/8648983,blinken-bliski-wschod-prezydent-egiptu-bezpieczenstwa-w-regionie.html](https://forsal.pl/swiat/usa/artykuly/8648983,blinken-bliski-wschod-prezydent-egiptu-bezpieczenstwa-w-regionie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 14:36:35+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1NBktkuTURBXy9kOGQ0NTVmZC1kMjllLTRjYjEtOTk5Mi03MWUzNjE2YjE4ODIuanBlZ5GTBc0BHcyg" />Antony Blinken, sekretarz stanu USA, rozpoczął podróż po Bliskim Wschodzie spotkaniem z prezydentem Egiptu, Abdelfattahem Al Sisi. Tematem rozmów były działania zmierzające do deeskalacji napięć izraelsko-palestyńskich oraz kluczowe kwestie regionalne - pisze w poniedziałek agencja Reutera.

## Hiszpania będzie dostarczać paliwo jądrowe do poradzieckich elektrowni atomowych
 - [https://forsal.pl/biznes/energetyka/artykuly/8648965,hiszpania-dostarczy-paliwo-jadrowe-poradzieckie-elektrownie-atomowe.html](https://forsal.pl/biznes/energetyka/artykuly/8648965,hiszpania-dostarczy-paliwo-jadrowe-poradzieckie-elektrownie-atomowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 14:15:50+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4z5ktkuTURBXy8xMDA4Yzg4MS1mMjlkLTRkNmItYjI5OC0yMDY2OTZhNDJjZmYuanBlZ5GTBc0BHcyg" />Państwowa spółka handlowa Industrias Avanzadas S.A. (ENUSA) podejmie produkcję paliwa jądrowego dla reaktorów technologii radzieckiej VVER - 440 we współpracy z koncernem Westinghouse Electric Sweden AB - poinformowała ENUSA w oświadczeniu na stronie internetowej.

## Chiny walczą z zapaścią demograficzną. Single z prowincji Syczuan będą mogli mieć legalnie dzieci
 - [https://forsal.pl/gospodarka/demografia/artykuly/8648958,chiny-zapasc-demograficzna-single-prowincja-syczuan-legalnie-dzieci.html](https://forsal.pl/gospodarka/demografia/artykuly/8648958,chiny-zapasc-demograficzna-single-prowincja-syczuan-legalnie-dzieci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 14:05:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wzUktkuTURBXy8zZGIxODY1NC00YmRlLTQ5Y2MtOGJhNi04MTJhODBjODQ2ZWYuanBlZ5GTBc0BHcyg" />Władze prowincji Syczuan na południowym zachodzie Chin zezwolą osobom stanu wolnego na rejestrację dzieci i korzystanie ze świadczeń zarezerwowanych dotąd dla małżeństw. To element starań o zwiększenie dzietności.

## "NYT": Niebezpieczni przestępcy z Grupy Wagnera wracają do domów. Rosję czeka fala przemocy
 - [https://forsal.pl/swiat/ukraina/artykuly/8648949,nyt-przestepcy-z-grupy-wagnera-wracaja-do-domow-rosja-fala-przemocy.html](https://forsal.pl/swiat/ukraina/artykuly/8648949,nyt-przestepcy-z-grupy-wagnera-wracaja-do-domow-rosja-fala-przemocy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:51:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wV4ktkuTURBXy8wZmY0NmZkNC0xMTg4LTRmZDItYTNlZS04OGNlNWQ4YTZhNjMuanBlZ5GTBc0BHcyg" />Ponad pół roku temu prywatna firma wojskowa Grupa Wagnera zaczęła rekrutować więźniów na skalę niewidzianą od II wojny światowej, aby wesprzeć rosyjski atak na ukraińskie miasto Bachmut, a w tym miesiącu ci, którzy przeżyli, zaczęli powracać do Rosji, stawiając społeczeństwo przed wyzwaniem reintegracji tysięcy mężczyzn z kryminalną przeszłością - pisze w poniedziałek dziennik &quot;New York Times&quot;.

## "NYT": Przestępcy zwerbowani przez Grupę Wagnera wracają do Rosji.  mogą stanowić zagrożenie
 - [https://forsal.pl/swiat/ukraina/artykuly/8648949,nyt-najemnicy-przestepcy-z-grupy-wagnera-wracaja-do-rosji-moga-stanowic-zagrozenie.html](https://forsal.pl/swiat/ukraina/artykuly/8648949,nyt-najemnicy-przestepcy-z-grupy-wagnera-wracaja-do-rosji-moga-stanowic-zagrozenie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:51:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wV4ktkuTURBXy8wZmY0NmZkNC0xMTg4LTRmZDItYTNlZS04OGNlNWQ4YTZhNjMuanBlZ5GTBc0BHcyg" />Ponad pół roku temu prywatna firma wojskowa Grupa Wagnera zaczęła rekrutować więźniów na skalę niewidzianą od II wojny światowej, aby wesprzeć rosyjski atak na ukraińskie miasto Bachmut, a w tym miesiącu ci, którzy przeżyli, zaczęli powracać do Rosji, stawiając społeczeństwo przed wyzwaniem reintegracji tysięcy mężczyzn z kryminalną przeszłością - pisze w poniedziałek dziennik &quot;New York Times&quot;.

## Strajk w Air France. Co dziesiąty lot we wtorek zostanie odwołany
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8648933,strajk-w-air-france-co-dziesiaty-lot-we-wtorek-zostanie-odwolany.html](https://forsal.pl/swiat/unia-europejska/artykuly/8648933,strajk-w-air-france-co-dziesiaty-lot-we-wtorek-zostanie-odwolany.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:36:11+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5T6ktkuTURBXy9hY2RkMmM4ZC1lMTJjLTQxYjEtYTI2ZS1lMThhMjA1ZGQyYzEuanBlZ5GTBc0BHcyg" />Z powodu zapowiadanych na wtorek we Francji strajków i protestów przeciwko rządowej reformie emerytalnej linie lotnicze Air France odwołują tego dnia 10 proc. połączeń krótko- i średniodystansowych - ogłoszono w poniedziałek. Loty długodystansowe mają odbywać się normalnie.

## Ekologiczne paliwa? Jesteśmy gotowi płacić więcej
 - [https://forsal.pl/biznes/ekologia/artykuly/8648918,ekologia-paliwa-stacje-benzynowe.html](https://forsal.pl/biznes/ekologia/artykuly/8648918,ekologia-paliwa-stacje-benzynowe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:18:39+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kqCktkuTURBXy9jMzFmYzBmZi00NGIxLTRiM2EtYjQ5Ny00NGEzN2U2MjdlZjguanBlZ5GTBc0BHcyg" />Trzy piąte ankietowanych klientów (60 proc.) stacji paliw jest gotowych zapłacić więcej za produkty ekologiczne, a 95 proc. respondentów deklaruje, że na co dzień dba o środowisko, wynika z badania &quot;Przyszłość stacji paliw&quot; zrealizowanego przez instytut ARC Rynek i Opinia na zlecenie Anwimu.

## Praca zdalna na stałe w Kodeksie pracy. Prezydent podpisał ustawę
 - [https://forsal.pl/praca/aktualnosci/artykuly/8648907,ustawa-praca-zdalna-kodeks-pracy.html](https://forsal.pl/praca/aktualnosci/artykuly/8648907,ustawa-praca-zdalna-kodeks-pracy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:13:42+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tl9ktkuTURBXy8xOTVmYjljOC0wODZlLTRhYTktYWY5NC0wZjJhZDU2YjkxOGUuanBlZ5GTBc0BHcyg" />Prezydent Andrzej Duda podpisał nowelizację Kodeksu pracy. Wprowadza ona na stałe do przepisów pracę zdalną – poinformowano w poniedziałek na stronie Kancelarii Prezydenta. Ponadto pracodawcy będą mogli kontrolować trzeźwość pracowników.

## Alert w elektrowni atomowej w Japonii. Wstrzymano pracę reaktora
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8648900,japonia-alert-w-elektrowni-atomowej.html](https://forsal.pl/swiat/aktualnosci/artykuly/8648900,japonia-alert-w-elektrowni-atomowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 13:07:52+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/es9ktkuTURBXy85ZTMwZjljZC01ZTc1LTQwNDEtODk3ZC1jYWE5MWE2N2I5MGIuanBlZ5GTBc0BHcyg" />Praca jednego z reaktorów elektrowni atomowej w prefekturze Fukui w Japonii została w poniedziałek automatycznie wstrzymana w związku z alertem o gwałtownie spadającej liczbie neutronów – podała agencja Kyodo, powołując się na operatora siłowni i władze.

## Dochód minimalny. Unia Europejska chce zwalczać ubóstwo i wykluczenie
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8648891,unia-europejska-dochod-minimalny.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8648891,unia-europejska-dochod-minimalny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:59:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jfOktkuTURBXy9jMTgyYmNhYy1lZTI3LTQzNmQtOWY2My1hMzE0NjE1M2NiOTUuanBlZ5GTBc0BHcyg" />UE przyjęła zalecenie w sprawie odpowiedniego dochodu minimalnego. Zakłada zwalczaniu ubóstwa i wykluczenia społecznego oraz dążenie do wysokiego poziomu zatrudnienia poprzez propagowanie dochodu minimalnego.

## Którym politykom ufamy najbardziej? Duda otwiera ranking
 - [https://forsal.pl/gospodarka/polityka/artykuly/8648885,cbos-zaufanie-do-politykow.html](https://forsal.pl/gospodarka/polityka/artykuly/8648885,cbos-zaufanie-do-politykow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:50:18+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BHRktkuTURBXy81Njg3OTI2NS01MmZmLTQyMDgtOTM3MS03MWQ1OTBmNjM2ZjcuanBlZ5GTBc0BHcyg" />Prezydent Andrzej Duda, prezydent Warszawy Rafał Trzaskowski i premier Mateusz Morawiecki to liderzy rankingu zaufania w styczniu - wynika z sondażu CBOS. Z największą nieufnością spotyka się prezes PiS Jarosław Kaczyński, minister sprawiedliwości Zbigniew Ziobro oraz szef PO Donald Tusk.

## Jak budować konkurencyjność firmy? Na pewno nie tanią siłą roboczą
 - [https://forsal.pl/praca/aktualnosci/artykuly/8648878,barbara-socha-koniec-czasow-taniej-sily-roboczej.html](https://forsal.pl/praca/aktualnosci/artykuly/8648878,barbara-socha-koniec-czasow-taniej-sily-roboczej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:39:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EWUktkuTURBXy9lMTc2Y2NiMS04MmQ5LTQxZGYtYTk2NS03Zjk4ZmVkMjYzNjMuanBlZ5GTBc0BHcyg" />Budowanie konkurencyjności na taniej i licznej sile roboczej skończyło się – stwierdziła w poniedziałek wiceminister w MRiPS Barbara Socha. Jej zdaniem oczekiwania pracowników, by więcej zarabiać świadczą o tym, że się bogacimy, co jest bardzo pozytywnym zjawiskiem.

## Jesteś w Belgii i masz przy sobie kokainę? Zapłacisz 1000 euro
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8648814,belgia-wzrost-kar-za-posiadanie-narkotykow.html](https://forsal.pl/swiat/aktualnosci/artykuly/8648814,belgia-wzrost-kar-za-posiadanie-narkotykow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:21:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cf7ktkuTURBXy85MzM2ZGY0Yi1mZTk2LTRmMmQtYmEzNS03YjI5YzlkMTNjNDQuanBlZ5GTBc0BHcyg" />W Belgii kary za zażywanie lub posiadanie na własny użytek takich narkotyków jak kokaina, ketamina czy LSD wzrosną ze 150 do 1000 euro - zdecydował minister sprawiedliwości Vincent Van Quickenborne. Chce on także, by grzywny z tego powodu były egzekwowane podobnie jak mandaty drogowe tj. ściągane z pensji w przypadku braku zapłaty.

## Spółka PKP Cargo ma umowę zakupu aktywów oddziału Alstom za 13,5 mln zł netto
 - [https://forsal.pl/biznes/przemysl/artykuly/8648811,spolka-pkp-cargo-ma-umowe-zakupu-aktywow-oddzialu-alstom-za-135-mln-zl-netto.html](https://forsal.pl/biznes/przemysl/artykuly/8648811,spolka-pkp-cargo-ma-umowe-zakupu-aktywow-oddzialu-alstom-za-135-mln-zl-netto.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:16:16+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DynktkuTURBXy8xZmQ3Mjk0YS0yNGQ1LTQzZTUtYTkxNy1mOGQ1OWM2YzZlZmIuanBlZ5GTBc0BHcyg" />PKP Cargotabor - spółka zależna PKP Cargo - zawarł umowę z Alstom Pojazdy Szynowe na zakup aktywów likwidowanego oddziału Alstom, podało PKP Cargo. Wartość umowy to 13,5 mln zł netto.

## Strajk kontrolerów lotów. Tym razem w Hiszpanii
 - [https://forsal.pl/praca/aktualnosci/artykuly/8648796,hiszpania-strajk-kontrolerow-lotow.html](https://forsal.pl/praca/aktualnosci/artykuly/8648796,hiszpania-strajk-kontrolerow-lotow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 12:03:19+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ADuktkuTURBXy8zNTY3NmJlYy02Yzk1LTRmZjYtOGZiOS05YWE0NDI1NGEzNDguanBlZ5GTBc0BHcyg" />Kontrolerzy lotów rozpoczęli w poniedziałek strajk na 16 lotniskach w Hiszpanii. 24-godzinny protest na tle płacowym będzie kontynuowany w lutym - zapowiedzieli przed południem organizatorzy akcji strajkowej.

## Chińskie jednostki wpłynęły na japońskie wody terytorialne
 - [https://forsal.pl/swiat/chiny/artykuly/8648787,chinskie-jednostki-japonskie-wody-terytorialne.html](https://forsal.pl/swiat/chiny/artykuly/8648787,chinskie-jednostki-japonskie-wody-terytorialne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:59:16+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YXSktkuTURBXy9lNWI0MTMyMy04YmNlLTRmNTYtODc3Ny0yMjE0NmVlZDcxZWYuanBlZ5GTBc0BHcyg" />Cztery chińskie jednostki wpłynęły w poniedziałek, po raz drugi w tym roku, na japońskie wody terytorialne wokół wysp Senkaku – poinformowała japońska straż przybrzeżna. Pekin nazywa kontrolowane przez Tokio wyspy Diaoyu i uznaje je za własne terytorium.

## Rekord prób samobójczych dzieci i młodzieży. Petycja do Ministerstwa Edukacji
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8648769,samobojstwa-dzieci-mlodziez-petycja.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8648769,samobojstwa-dzieci-mlodziez-petycja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:48:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JTlktkuTURBXy8xMDAzNzg5OS1iZDhkLTQ0ZTctYjRiYy03ODhmMjdlOThhNDkuanBlZ5GTBc0BHcyg" />Zgodnie z danymi pozyskanymi na podstawie wniosków o dostęp do informacji publicznej, w 2022 roku padł rekord prób samobójczych dzieci i młodzieży. Odnotowano ich ponad 2 tysiące. To wzrost o 150 proc. w stosunku do danych z 2020 roku. Dane pozyskali aktywiści z Fundacji GrowSpace – Dominik Kuc oraz Paulina Filipowicz, którzy kierują petycję do Ministerstwa Edukacji i Nauki oraz Ministerstwa Zdrowia. Padł także niechlubny rekord prób samobójczych zakończonych zgonem – 150 przypadków. Te dane mogą się jeszcze zwiększać.

## Przetarg na projekt budowalny rozbudowy autostrady A2
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8648737,gddkia-przetarg-rozbudowa-autostrady-a2.html](https://forsal.pl/biznes/aktualnosci/artykuly/8648737,gddkia-przetarg-rozbudowa-autostrady-a2.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:41:11+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZVhktkuTURBXy84ZDA5OTFkOS00ZDg5LTQ0YmItOTkxMC0zYmJkNGRiNDM5ZTEuanBlZ5GTBc0BHcyg" />Generalna Dyrekcja Dróg Krajowych i Autostrad (GDDKiA) ogłosiła przetarg na wykonanie projektu budowalnego rozbudowy autostrady A2 do trzech i czterech pasów ruchu na odcinku między Łodzią a Warszawą. Prace przy poszerzeniu autostrady mają rozpocząć się w 2025 r.

## Niemcy nie chcą odejścia od energetyki jądrowej
 - [https://forsal.pl/biznes/energetyka/artykuly/8648727,niemcy-energetyka-jadrowa.html](https://forsal.pl/biznes/energetyka/artykuly/8648727,niemcy-energetyka-jadrowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:33:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h7LktkuTURBXy8xZWQ0ZWM1ZC1hMjYzLTRhNWEtYWM4ZS0yMzUwOTFjMGYzYWMuanBlZ5GTBc0BHcyg" />Większość obywateli Niemiec nie chce, by ich kraj zrezygnował z energetyki jądrowej - wynika z ankiety przeprowadzonej przez Fundację Konrada Adenauera, której rezultaty relacjonuje w poniedziałek portal dziennika &quot;Bild&quot;.

## W 2022 r. głównym motorem gospodarki był przemysł
 - [https://forsal.pl/biznes/przemysl/artykuly/8648718,lewiatan-przemysl-polska-gospodarka.html](https://forsal.pl/biznes/przemysl/artykuly/8648718,lewiatan-przemysl-polska-gospodarka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:26:13+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/plTktkuTURBXy9kYWQxZGM2My1lZjAyLTQxODctODYxMi03ZTYzZGMzY2JjMmYuanBlZ5GTBc0BHcyg" />Głównym motorem napędowym gospodarki w 2022 r. okazał się przemysł, największy wpływ na wzrost PKB miał popyt krajowy - ocenia Konfederacja Lewiatan. Jak podał w poniedziałek GUS, wzrost PKB wzrósł w ubiegłym roku o 4,9 proc.

## Wraca widmo recesji w Niemczech. Analitycy zaskoczeni spadkiem PKB w IV kw.
 - [https://forsal.pl/gospodarka/pkb/artykuly/8648716,niemcy-spadek-pkb-iv-kw-ryzyko-recesji-w-niemczech.html](https://forsal.pl/gospodarka/pkb/artykuly/8648716,niemcy-spadek-pkb-iv-kw-ryzyko-recesji-w-niemczech.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:21:56+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h_RktkuTURBXy81YmZhYmZlYy1jYWIwLTRiYmItODEwMy0xYTU0NmM0MmQ3OTkuanBlZ5GTBc0BHcyg" />Niemiecka gospodarka zmniejszyła się w IV. kw. 2022 roku o 0,2 proc. To wynik gorszy, niż spodziewali się analitycy. Tym samym ryzyko recesji w największej gospodarce Europy znów staje się realne.

## Obywatele Korei Południowej chcą mieć własną broń atomową
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8648707,korea-poludniowa-bron-jadrowa-ankieta.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8648707,korea-poludniowa-bron-jadrowa-ankieta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 11:15:10+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VMKktkuTURBXy9lZDZiMTk1YS1kN2EwLTQ3NTAtOWJjNy1iZTVmMjliN2MzOTEuanBlZ5GTBc0BHcyg" />76,6 proc. mieszkańców Korei Płd. uważa, że ich kraj powinien rozpocząć prace nad własnym arsenałem jądrowym w obliczu nasilających się gróźb i prowokacji ze strony Korei Płn. - wynika z ankiety opisywanej w poniedziałek przez lokalne media.

## Polacy wyjeżdżający na ferie będzie oszczędzać na noclegach i wyżywieniu
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8648690,polacy-ferie-zimowe-oszczedzanie.html](https://forsal.pl/lifestyle/turystyka/artykuly/8648690,polacy-ferie-zimowe-oszczedzanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:46:19+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/By8ktkuTURBXy8zN2M4ZTBlOC1mOTQxLTQ0MzQtOWRmMi02N2E4NmI0N2YyOGMuanBlZ5GTBc0BHcyg" />Na ferie w tym roku wybiera się co czwarty Polak, jednak 73 proc. z nich będzie oszczędzać na standardzie hotelu i jego lokalizacji czy wyżywieniu, wynika z badania przeprowadzonego na zlecenie firmy ubezpieczeniowej Wiener. Połowa przeznaczy na zimowy wyjazd do 1,5 tys. zł na osobę. Jednocześnie rośnie świadomość ubezpieczeniowa Polaków, bo ponad 60 proc. z nich wykupi na wyjazd przynajmniej jeden rodzaj ubezpieczenia.

## Fundusz Wsparcia Sił Zbrojnych ma dysponować kwotą ponad 49 mld zł
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8648681,fundusz-sil-zbrojnych-49-mld-zl.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8648681,fundusz-sil-zbrojnych-49-mld-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:35:36+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/eAgktkuTURBXy85ZmU5YTAxZi0zYTdkLTRkYTItOTVjYS1mMmZiODU3M2FkM2QuanBlZ5GTBc0BHcyg" />Pozabudżetowy Fundusz Wsparcia Sił Zbrojnych ma dysponować w tym roku kwotą nieco ponad 49 mld zł, wynika z informacji, jakie Business Insider Polska uzyskał w resorcie obrony narodowej. Portal podkreśla, że oznacza to, iż będzie to kwota o prawie 10 mld zł wyższa, niż rząd zakładał jeszcze kilka tygodni temu.

## GUS: Mniej ludzi w Polsce. Ile wyniósł ubytek ludności?
 - [https://forsal.pl/gospodarka/demografia/artykuly/8648677,gus-polska-ubytek-ludnosci.html](https://forsal.pl/gospodarka/demografia/artykuly/8648677,gus-polska-ubytek-ludnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:26:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GPyktkuTURBXy82ZTllN2I3ZC01NzVjLTQwNTMtOTQwYy04MWQxYWRiNGVmZjEuanBlZ5GTBc0BHcyg" />W 2022 r. liczba ludności zmniejszyła się o 141 tys. w stosunku do poprzedniego roku. Ubytek ludności był mniejszy niż w 2021 r., ale nadal większy niż przed wybuchem pandemii – poinformował w poniedziałek na konferencji prezes GUS Dominik Rozkrut.

## Włoski gigant energetyczny ma kontrakt gazowy z Libią. Wartość? 8 mld dol.
 - [https://forsal.pl/biznes/energetyka/artykuly/8648676,koncern-eni-kontrakt-gazowy-z-libia-8-mld-dol.html](https://forsal.pl/biznes/energetyka/artykuly/8648676,koncern-eni-kontrakt-gazowy-z-libia-8-mld-dol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:22:55+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VO3ktkuTURBXy9lYmU1OWZhNC0yMGE4LTRjZGMtOTIzZC02ZTBmNGYzNDY3NzQuanBlZ5GTBc0BHcyg" />Włochy podpisały z Libią kontrakt w sprawie produkcji gazu na sumę 8 miliardów euro. Umowę z libijską państwową firmą Noc zawarł włoski koncern energetyczny Eni podczas wizyty premier Giorgii Meloni w Trypolisie w ostatni weekend. Ekonomiczny dziennik „Il Sole-24 Ore” nazywa porozumienie „historycznym”.

## Obniżki cen biletów. Morawiecki: Dodatkowe środki dla PKP w ciągu 2 tygodni
 - [https://forsal.pl/transport/kolej/artykuly/8648667,obnizki-cen-biletow-morawiecki-dodatkowe-srodki-dla-pkp-w-ciagu-2-tygodni.html](https://forsal.pl/transport/kolej/artykuly/8648667,obnizki-cen-biletow-morawiecki-dodatkowe-srodki-dla-pkp-w-ciagu-2-tygodni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:12:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zRhktkuTURBXy9hOGE5OGNlZi02OTAyLTRmZWMtYTY4ZC03ZTNkZjc4MWQzMTMuanBlZ5GTBc0BHcyg" />Rząd planuje przekazanie PKP dodatkowych środków z budżetu państwa na pokrycie kosztów wzrostu cen energii, co w konsekwencji ma doprowadzić do obniżki cen biletów w ciągu najbliższych dwóch tygodni, wynika z wypowiedzi premiera Mateusza Morawieckiego.

## Daniel Obajtek współpracownikiem ABW? PKN Orlen zaprzecza doniesieniom "GW"
 - [https://forsal.pl/biznes/energetyka/artykuly/8648665,daniel-obajtek-wspolpracownikiem-abw-pkn-orlen-zaprzecza-doniesieniom-gw.html](https://forsal.pl/biznes/energetyka/artykuly/8648665,daniel-obajtek-wspolpracownikiem-abw-pkn-orlen-zaprzecza-doniesieniom-gw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:06:17+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0QIktkuTURBXy81ZDA4MTExNS1lYWNkLTRkNWQtYTk4Ny1lZGJiYmRlYWVmZGQuanBlZ5GTBc0BHcyg" />Daniel Obajtek, prezes PKN Orlen, nie był nigdy zarejestrowany jako współpracownik ABW - przekazał koncern w oświadczeniu zamieszczonym w poniedziałek na Twitterze w odpowiedzi na doniesienia &quot;Gazety Wyborczej&quot;. Według spółki publikacja dziennika zawiera nieprawdziwe informacje.

## Wydłużenie wakacji kredytowych? Premier zabrał głos
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8648663,wydluzenie-wakacji-kredytowych-premier-zabral-glos.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8648663,wydluzenie-wakacji-kredytowych-premier-zabral-glos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 10:03:06+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZiHktkuTURBXy84YTYwNGY3Ny02YmVmLTRjZDctOGM2Yi0yOGRlYmJiN2U0ZWQuanBlZ5GTBc0BHcyg" />Decyzje w sprawie wakacji kredytowych nie zostały jeszcze podjęte, zależą one od ukształtowania się sytuacji inflacyjnej w Polsce w dalszej części tego roku - powiedział w poniedziałek premier Mateusz Morawiecki.

## Firmy planują podwyżki, choć presja płacowa spada
 - [https://forsal.pl/praca/aktualnosci/artykuly/8648653,firmy-podwyzki-presja-placowa.html](https://forsal.pl/praca/aktualnosci/artykuly/8648653,firmy-podwyzki-presja-placowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 09:54:58+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n9YktkuTURBXy9kOWRkYzI1ZS0wYThjLTQxODgtYmZmZC1iYzhkYzliNWNhY2QuanBlZ5GTBc0BHcyg" />Przedsiębiorstwa ankietowane w grudniu ub.r. wskazują na spadek presji płacowej, choć udział firm odczuwających naciski na wzrost płac jest nadal relatywnie wysoki, podał Narodowy Bank Polski (NBP). Co więcej, mimo spadku presji płacowej udział podmiotów prognozujących podniesienie wynagrodzeń w kolejnym kwartale nieznacznie wrósł i zwiększyła się przeciętna skala planowanych podwyżek, co może być związane z wprowadzoną od początku 2023 r. podwyżką płacy minimalnej, podano także.

## 4 proc. polskiego PKB na wojsko. Deklaracja Morawieckiego
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8648647,polska-pkb-wojsko-morawiecki.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8648647,polska-pkb-wojsko-morawiecki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 09:47:19+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wOKktkuTURBXy9mMjdkZmM2Yi1lMTdmLTRlYTItOTMzYS01NzBlNWIxMjMzYWEuanBlZ5GTBc0BHcyg" />Wojna w Ukrainie powoduje, że musimy zbroić się jeszcze szybciej, dlatego w tym roku przeznaczymy 4 proc. PKB na wojsko, być może będzie to najwyższy procent wśród wszystkich państw NATO - powiedział w poniedziałek premier Mateusz Morawiecki.

## 49 euro za transport w całym kraju. Niemcy wprowadzą nowy bilet miesięczny
 - [https://forsal.pl/transport/aktualnosci/artykuly/8648640,niemcy-bilet-miesieczny-za-49-euro-transport.html](https://forsal.pl/transport/aktualnosci/artykuly/8648640,niemcy-bilet-miesieczny-za-49-euro-transport.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 09:41:36+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rPvktkuTURBXy84NDI1YWU0ZC1iZjAyLTQzYTktYWU1OS0yNzIxMmVhZmY5NWQuanBlZ5GTBc0BHcyg" />Niemcy wprowadzą miesięczny bilet za 49 euro na transport w całym kraju od 1 maja 2023 roku. Tani bilet ma zachęcić obywateli do korzystania z transportu publicznego, obniżyć koszty życia i emisje CO2.

## Wielkie zwolnienia w Philipsie. W samej Holandii pracę straci 1,1 tys. osób
 - [https://forsal.pl/praca/aktualnosci/artykuly/8648619,holandia-philips-zwolnienia.html](https://forsal.pl/praca/aktualnosci/artykuly/8648619,holandia-philips-zwolnienia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 09:17:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WwlktkuTURBXy9jNGJiYzM3ZS1iMGQ0LTQ0ZjUtYjk2OS00YmQ3NTBiOGYyODguanBlZ5GTBc0BHcyg" />Po tym jak Philips stracił w 2022 r. 1,6 mld euro, koncern poinformował w poniedziałek rano, że zamierza zwolnić 6 tys. pracowników na całym świecie, w tym 1,1 tys. w Niderlandach. Trzy miesiące temu firma poinformowała, że zwalnia 4 tys. pracowników.

## PKB wzrósł mocniej od oczekiwań. GUS podał dane za 2022 rok
 - [https://forsal.pl/artykuly/8648609,pkp-polski-2022-dane-gus.html](https://forsal.pl/artykuly/8648609,pkp-polski-2022-dane-gus.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 09:10:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RfEktkuTURBXy82NmM4ZjJmNy0yMWM5LTRjN2EtOGZkMS05YTdlNzlmMTNmYWYuanBlZ5GTBc0BHcyg" />Według wstępnego szacunku produkt krajowy brutto w 2022 r. wzrósł realnie o 4,9 proc., wobec wzrostu o 6,8 proc. w 2021 r. - podał GUS. Szacunki analityków zakładały wzrost na poziomie 4,8 proc.

## Cognor zarekomendował wypłatę 1,23 zł dywidendy na akcję za 2022 r.
 - [https://forsal.pl/biznes/przemysl/artykuly/8648593,cognor-zarekomendowal-wyplate-123-zl-dywidendy-na-akcje-za-2022-r.html](https://forsal.pl/biznes/przemysl/artykuly/8648593,cognor-zarekomendowal-wyplate-123-zl-dywidendy-na-akcje-za-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:55:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3SIktkuTURBXy8zMjY1OTQ5My1mMWUxLTQ0MDItOTJmNC0yZGEzMTlmZTM1ZDEuanBlZ5GTBc0BHcyg" />Cognor Holding zarekomendował akcjonariuszom wypłatę 1,23 zł dywidendy na akcję z zysku za 2022 rok, podała spółka.

## Gaz w poniedziałek rano tanieje
 - [https://forsal.pl/finanse/notowania/artykuly/8648590,cena-gazu-30-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8648590,cena-gazu-30-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:53:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4HmktkuTURBXy8yOGZiNGNhNS01N2FhLTQ0MzItYmY1Yy0xMDkwY2UwOTM4YTcuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 9.30 gaz ziemny w holenderskim hubie TTF w kontraktach na luty tanieje o 1,21 proc., do 54,75 euro za MWh. Spada również jego cena w kontraktach na marzec o 0,46 proc. do 55,19 euro za MWh.

## Cognor Holding miał wstępnie 602,4 mln skonsolidowanego zysku netto w 2022 r.
 - [https://forsal.pl/biznes/przemysl/artykuly/8648588,cognor-holding-mial-wstepnie-6024-mln-skonsolidowanego-zysku-netto-w-2022-r.html](https://forsal.pl/biznes/przemysl/artykuly/8648588,cognor-holding-mial-wstepnie-6024-mln-skonsolidowanego-zysku-netto-w-2022-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:53:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FJcktkuTURBXy9jYmNkZDNjZi0xMzI3LTRmNWEtODk2NC00OTNmYjY3NWZkODYuanBlZ5GTBc0BHcyg" />Cognor Holding miał 602,4 mln zł skonsolidowanego zysku netto w 2022 roku, przy przychodach na poziomie 3,41 mld zł, podała spółka, powołując się na dane szacunkowe.

## Jesteś przedsiębiorcą z Polski Wschodniej? Możesz sięgnąć po wsparcie ze środków unijnych
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8648584,parp-wsparcie-srodki-unijne-wschodnia-polska.html](https://forsal.pl/biznes/aktualnosci/artykuly/8648584,parp-wsparcie-srodki-unijne-wschodnia-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:49:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CwAktkuTURBXy8yZjJiOWMwNC1hNDIxLTQwN2UtODU5ZS0wMzYwZjQ5Nzc3ZmMuanBlZ5GTBc0BHcyg" />Przedsiębiorcy, samorządy, twórcy startupów z Polski Wschodniej mogą otrzymać 1,39 mld euro wsparcia ze środków unijnych w ramach konkursu „Platformy startowe dla nowych pomysłów&quot; - poinformowała w poniedziałek Polska Agencja Rozwoju Przedsiębiorczości.

## Grupa Żywiec złożyła do KNF wniosek ws. wycofania akcji z GPW
 - [https://forsal.pl/finanse/gielda/artykuly/8648573,grupa-zywiec-zlozyla-do-knf-wniosek-ws-wycofania-akcji-z-gpw.html](https://forsal.pl/finanse/gielda/artykuly/8648573,grupa-zywiec-zlozyla-do-knf-wniosek-ws-wycofania-akcji-z-gpw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:43:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wwPktkuTURBXy80NTVjNDE5ZS0zZDZjLTQzNWItODBmNi05ZmY0YTYyNGVmNjIuanBlZ5GTBc0BHcyg" />Grupa Żywiec złożyła do Komisji Nadzoru Finansowego (KNF) wniosek o zezwolenie na wycofanie wszystkich akcji z obrotu na rynku regulowanym prowadzonym przez Giełdę Papierów Wartościowych w Warszawie, podała spółka. Wniosek został złożony w wykonaniu uchwały podjętej przez nadzwyczajne walne zgromadzenie w dniu 26 stycznia.

## W obwodzie ługańskim trwają masowe wywózki. Zwolnione domy zajmują rosyjscy żołnierze
 - [https://forsal.pl/swiat/ukraina/artykuly/8648570,obwod-luganski-masowe-wywozki.html](https://forsal.pl/swiat/ukraina/artykuly/8648570,obwod-luganski-masowe-wywozki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:40:18+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ggVktkuTURBXy83NTNhODc0MS1mNTIzLTQ4ZjItYjA5YS05MWZhMTg4ZTEzMzkuanBlZ5GTBc0BHcyg" />Mieszkańcy okupowanych miejscowości w obwodzie ługańskim, na wschodzie Ukrainy, są masowo deportowani do Rosji, a ich domy zajmują żołnierze agresora, przybywający na front - zaalarmował w poniedziałek lojalny wobec Kijowa szef władz Ługańszczyzny Serhij Hajdaj.

## Szynkowski vel Sęk: Część zapowiadanych poprawek do noweli o SN jest absurdalna
 - [https://forsal.pl/gospodarka/prawo/artykuly/8648566,szynkowki-vel-sek-poprawki-do-noweli-o-sn.html](https://forsal.pl/gospodarka/prawo/artykuly/8648566,szynkowki-vel-sek-poprawki-do-noweli-o-sn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:35:09+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0FUktkuTURBXy8yMDNhNDgzNS0zY2E0LTRjZWUtYWNhZi00ZGI2ZjU1ZDBmMjYuanBlZ5GTBc0BHcyg" />Zapowiadane przez Senat poprawki do noweli o SN to nic nowego - część z nich jest absurdalna, część wykracza poza oczekiwania Komisji Europejskiej, a część mogłaby zburzyć kompromis z Komisją - powiedział w poniedziałek minister ds. Unii Europejskiej Szymon Szynkowski vel Sęk.

## Miedź na LME zaczyna tydzień od spadków. Dlaczego zmniejszył się popyt?
 - [https://forsal.pl/finanse/notowania/artykuly/8648558,cena-miedzi-30-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8648558,cena-miedzi-30-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:11:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y3GktkuTURBXy82NGU1NzNmYi04ZTgxLTQwODUtYWU1OS1iMzg3Zjc2ZjNhNWUuanBlZ5GTBc0BHcyg" />Miedź na giełdzie metali LME w Londynie spada, a maklerzy starają się oszacować, jaka będzie sytuacja gospodarcza w Chinach po powrocie Chińczyków do pracy po świątecznej przerwie.

## Ropa tanieje na rynku o niespełna 1 proc.
 - [https://forsal.pl/finanse/notowania/artykuly/8648554,cena-ropy-30-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8648554,cena-ropy-30-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 08:07:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/cuyktkuTURBXy9lYzViNDkzMS0wMGZlLTQ2MTctODQ4Mi1iODUwM2YxZGI4YzkuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 8.30 ropa Brent na giełdzie w Londynie staniała o 0,80 proc., do 85,71 dolarów za baryłkę, a cena amerykańskiej ropy WTI spadła o 0,84 proc. do 79,01 dolarów za baryłkę.

## Ważny tydzień w świecie finansów. Szacunki PKB, posiedzenie Fed i Europejskiego Banku Centralnego
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8648551,szacunki-pkb-posiedzenie-fed-i-europejskiego-banku-centralnego.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/8648551,szacunki-pkb-posiedzenie-fed-i-europejskiego-banku-centralnego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:58:34+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/t77ktkuTURBXy9jNGRlZTdiMi04NzRjLTQzNjEtOWIxNi1jZmY2OGQ3YTFlNzEuanBlZ5GTBc0BHcyg" />W bieżącym tygodniu w centrum uwagi znajdą się posiedzenia Fed i Europejskiego Banku Centralnego (EBC), a na rynku krajowym - dzisiejsza publikacja szacunku PKB w 2022 r., uważają ekonomiści Banku Ochrony Środowiska (BOŚ). Oczekują oni, że w całym roku wzrost PKB wyniesie 4,8 proc. r/r.

## O ile wzrósł PKB w 2022 r.? „Mamy do czynienia z dużą dozą niepewności"
 - [https://forsal.pl/gospodarka/pkb/artykuly/8648546,o-ile-wzrosl-pkb-w-2022-r-mamy-do-czynienia-z-duza-doza-niepewnosci.html](https://forsal.pl/gospodarka/pkb/artykuly/8648546,o-ile-wzrosl-pkb-w-2022-r-mamy-do-czynienia-z-duza-doza-niepewnosci.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:49:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BoSktkuTURBXy81ODJiNzRkNC1hOGViLTRjMGYtYWE0Mi00MmU3OTM2ZjhiNmEuanBlZ5GTBc0BHcyg" />Spodziewamy się, że wzrost PKB wyniósł w 2022 r. wyniósł ok. 4,8 proc. W IV kw. wzrost PKB wyniósł ok. 1,8 proc., co jest efektem dalszego, szeroko zakrojonego spadku koniunktury – powiedział PAP ekonomista banku ING BSK Adam Antoniak.

## Ograniczenia w zakupie mieszkań. Kiedy rząd zajmie się ustawą?
 - [https://forsal.pl/nieruchomosci/artykuly/8648545,ograniczenia-w-zakupie-mieszkan-buda-w-lutym-rzad-moze-zajac-sie-ustawa.html](https://forsal.pl/nieruchomosci/artykuly/8648545,ograniczenia-w-zakupie-mieszkan-buda-w-lutym-rzad-moze-zajac-sie-ustawa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:44:46+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vtBktkuTURBXy8zMmJjZDRlNy1iZjFkLTRiZTQtODUyZi0xMjM5YWQ0OWVmYTAuanBlZ5GTBc0BHcyg" />Rada ministrów może w lutym zająć się projektem ustawy o ograniczeniach w nabywaniu mieszkań - wynika z wypowiedzi dla PAP ministra rozwoju i technologii Waldemara Budy.

## Po leki bez recepty idziemy do e-apteki. Handel internetowy produktów OTC w Polsce rośnie
 - [https://forsal.pl/biznes/handel/artykuly/8648543,e-handel-produkty-otc-wzrost.html](https://forsal.pl/biznes/handel/artykuly/8648543,e-handel-produkty-otc-wzrost.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:44:25+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rKYktkuTURBXy9jNDE3M2IyMC0yOTI5LTRhZTItOGYxNS1jYmJhM2YyYjM5YjIuanBlZ5GTBc0BHcyg" />Rynek handlu internetowego produktami OTC (lekami bez recepty, suplementami diety i dermokosmetykami) w latach 2017-2022 rósł w tempie 23 proc. rocznie, biorąc pod uwagę dynamikę nominalną. Według prognoz PMR, w 2023 r. jego wartość wyniesie 2,8 mld zł w cenach netto, wynika z raportu &quot;Handel internetowy produktami OTC w Polsce. Analiza rynku i prognozy rozwoju na lata 2023-2028&quot;. Kwota ta obejmuje sprzedaż wyżej wymienionych produktów w aptekach i sklepach internetowych oraz na platformach handlowych (leki mogą być sprzedawane tylko w aptekach internetowych).

## Wyniki leczenia ECMO u pacjentów z COVID 2-3 razy gorsze, niż przy grypie
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8648541,wyniki-leczenia-ecmo-u-pacjentow-z-covid-2-3-razy-gorsze-niz-przy-grypie.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8648541,wyniki-leczenia-ecmo-u-pacjentow-z-covid-2-3-razy-gorsze-niz-przy-grypie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:42:24+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/c4mktkuTURBXy84YmEzODAwOC04MzU1LTQ4M2EtOGY0Mi1hYjc0MjI2ZjQwNDAuanBlZ5GTBc0BHcyg" />Wyniki leczenia ECMO u pacjentów z COVID-19 były dwa-trzy razy gorsze, niż przy grypie. Okazało się, że śmiertelność wynosiła 70-80 proc. – powiedział PAP prof. Mirosław Czuczwar z SPSK1 Lublinie. Dodał, że użycie ECMO powinno być ograniczone do najbardziej doświadczonych ośrodków w Polsce.

## 53 proc. firm boi się niewypłacalności [BADANIE]
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8648536,53-proc-firm-boi-sie-niewyplacalnosci-badanie.html](https://forsal.pl/biznes/aktualnosci/artykuly/8648536,53-proc-firm-boi-sie-niewyplacalnosci-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:38:13+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VK7ktkuTURBXy9lMWQ1ZDM0Yi1jOWI3LTQ2MDEtODM0OS00ZWViMmFkOTEzZGYuanBlZ5GTBc0BHcyg" />53 proc. firm i 46 proc. klientów indywidualnych uważa, że z powodu niepewnych warunków ekonomicznych wzrośnie liczba podmiotów zagrożonych niewypłacalnością i upadłością - wynika z badania firmy Kaczmarski Inkasso. 24 proc. firm uważa, że po kryzysie nastąpi rozwój gospodarczy - dodano.

## Według prezesa PGE S.A. energetyka jądrowa w Polsce to konieczność
 - [https://forsal.pl/biznes/energetyka/artykuly/8648530,polska-energetyka-jadrowa-prezes-pge.html](https://forsal.pl/biznes/energetyka/artykuly/8648530,polska-energetyka-jadrowa-prezes-pge.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:35:30+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OlKktkuTURBXy9iZDliMmJkOS1hNGJmLTRmZTktYTZhZC1hZWRhNDE5OTg4ZTkuanBlZ5GTBc0BHcyg" />Jako lider zielonej zmiany prowadzimy najbardziej zaawansowany projekt rozwoju morskich farm wiatrowych w polskiej strefie na Bałtyku. Uruchomienie produkcji energii wytwarzanej przez nasze wiatraki na morzu planujemy już w 2026 r. - mówi DGP prezes PGE Polskiej Grupy Energetycznej Wojciech Dąbrowski.

## Sok z ziemniaka może działać na nowotwory. "Potencjał jest ogromny"
 - [https://forsal.pl/lifestyle/nauka/artykuly/8648533,sok-z-ziemniaka-moze-dzialac-na-nowotwory.html](https://forsal.pl/lifestyle/nauka/artykuly/8648533,sok-z-ziemniaka-moze-dzialac-na-nowotwory.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:28:41+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/frlktkuTURBXy9lMDBhODA2Zi0xYzc5LTQ5MDItOTgwNC1hOTNhNTk0M2YxNTEuanBlZ5GTBc0BHcyg" />Sok z ziemniaka może się stać lekiem selektywnie działającym na różnego typu nowotwory - i posłużyć pacjentom, którzy z powodów zdrowotnych muszą stosować rygorystyczne diety - wynika z badań naukowców z Uniwersytetu Przyrodniczego w Poznaniu (UPP).

## Część Alp bez śniegu. Ekspert: Narty stają się sportem dla bogatych
 - [https://forsal.pl/lifestyle/turystyka/artykuly/8648525,czesc-alp-bez-sniegu-ekspert-narty-staja-sie-sportem-dla-bogatych.html](https://forsal.pl/lifestyle/turystyka/artykuly/8648525,czesc-alp-bez-sniegu-ekspert-narty-staja-sie-sportem-dla-bogatych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:24:54+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pScktkuTURBXy9iNDMxZGE2MS1lMDA5LTQzMGYtOTYxOC1lZGZmZDNiNjI4OTcuanBlZ5GTBc0BHcyg" />Alpy są szczególnie mocno dotknięte zmianami klimatycznymi. Najbardziej dotknięte brakiem śniegu są tereny narciarskie, położone poniżej 1500 metrów nad poziomem morza, wymagające sztucznego dośnieżania. Narciarstwo staje się sportem, na który stać tylko zamożne rodziny – mówi prof. Harald Kunstmann, badacz klimatu, w wywiadzie dla portalu „ZDF heute”.

## W poniedziałek rano złoty osłabia się wobec euro, dolara i franka szwajcarskiego
 - [https://forsal.pl/finanse/waluty/artykuly/8648520,kurs-zlotego-30-stycznia.html](https://forsal.pl/finanse/waluty/artykuly/8648520,kurs-zlotego-30-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:21:29+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xnyktkuTURBXy9lMmFkNzVlYy02ODJjLTRmOTAtOWE1Yy03MTdkMjI1YjllNzYuanBlZ5GTBc0BHcyg" />W poniedziałek przed godz. 7 polska waluta traciła wobec euro 0,15 proc., które kosztowało 4,70 zł. Dolar amerykański drożał o 0,05 proc. do 4,33 zł, a kurs franka szwajcarskiego wzrósł o 0,14 proc. do 4,70 zł.

## Scholz: Żaden kraj nie wspiera Ukrainy bardziej niż Niemcy
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8648522,scholz-zaden-kraj-nie-wspiera-ukrainy-bardziej-niz-niemcy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8648522,scholz-zaden-kraj-nie-wspiera-ukrainy-bardziej-niz-niemcy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:21:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FHQktkuTURBXy8yMWRlZDYyNy1iMzhlLTRhM2ItYWM3Yy1hNDhhYjZhMWU5MmYuanBlZ5GTBc0BHcyg" />Przebywający z wizytą w Chile kanclerz Niemiec Olaf Scholz zapewnił w niedzielę, że jego kraj nie pozwoli, by wojna na Ukrainie przerodziła się w konflikt między Rosją a NATO.

## Nowela ustawy o Sądzie Najwyższym. Senacka większość zapowiedziała poprawki
 - [https://forsal.pl/gospodarka/prawo/artykuly/8648516,nowela-ustawy-o-sadzie-najwyzszym-senackie-poprawki.html](https://forsal.pl/gospodarka/prawo/artykuly/8648516,nowela-ustawy-o-sadzie-najwyzszym-senackie-poprawki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:17:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FNAktkuTURBXy8wZGYzMTU4Ni1hMDRhLTRmODktYTc3Mi1lOWIxMzFhYjlmOWQuanBlZ5GTBc0BHcyg" />Połączone komisje senackie zajmą się w poniedziałek nowelą ustawy o Sądzie Najwyższym, której przyjęcie ma umożliwić odblokowanie środków z KPO. Senacka większość zapowiedziała poprawki; chodzi o ulokowanie spraw dyscyplinarnych wewnątrz SN, a nie, jak przewiduje ustawa, w NSA.

## Boris Johnson: Jeszcze przed inwazją na Ukrainę Putin groził mi uderzeniem rakietowym
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8648519,boris-johnson-putin-grozil-mi-uderzeniem-rakietowym.html](https://forsal.pl/swiat/aktualnosci/artykuly/8648519,boris-johnson-putin-grozil-mi-uderzeniem-rakietowym.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:17:35+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NjsktkuTURBXy84MWI4MDAwZC1iZTk4LTRlNDItYjY0ZS05Nzc4ODZmMjJiZjMuanBlZ5GTBc0BHcyg" />Były premier Wielkiej Brytanii Boris Johnson powiedział w filmie dokumentalnym BBC, że w rozmowie telefonicznej w lutym ubiegłego roku, jeszcze przed rosyjską inwazją na Ukrainę, Władimir Putin groził mu &quot;uderzeniem rakietowym&quot;.

## Konflikt w Trybunale Konstytucyjnym wchodzi w nową fazę
 - [https://forsal.pl/gospodarka/prawo/artykuly/8648184,trybunal-konstytucyjny-konflikt-wchodzi-w-nowa-faze.html](https://forsal.pl/gospodarka/prawo/artykuly/8648184,trybunal-konstytucyjny-konflikt-wchodzi-w-nowa-faze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 07:05:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MxDktkuTURBXy9jYzVhNGZhMi0wMjU2LTQ1MmMtODAzNi00NjRkNjE0YjE4NzMuanBlZ5GTBc0BHcyg" />Już nie tylko w korespondencji i oświadczeniach sędziowie podważają prawo Julii Przyłębskiej do kierowania sądem konstytucyjnym. Ma to też odbicie w orzecznictwie.

## Polska żywność bije rekordy. To był kolejny historyczny rok dla eksportu
 - [https://forsal.pl/biznes/handel/artykuly/8648249,eksport-polska-zywnosc-bije-rekordy-2022.html](https://forsal.pl/biznes/handel/artykuly/8648249,eksport-polska-zywnosc-bije-rekordy-2022.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 06:59:07+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1XDktkuTURBXy8wOTk2ZDFmNy1hMjY0LTRjNDQtODEzZS1lNmMwNjU2N2ZhNzQuanBlZ5GTBc0BHcyg" />Ostatni rok przyniósł odwrócenie trendu: import rośnie szybciej niż eksport. Na razie nie cierpi na tym dodatnie saldo wymiany handlowej.

## Trudno stracić na oszczędzaniu w PPK. Jakie wyniki osiągały fundusze?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8648244,ppk-stopa-zwrotu-czy-warto-oszczedzac.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8648244,ppk-stopa-zwrotu-czy-warto-oszczedzac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 06:46:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gKfktkuTURBXy84MzU3ZjAzYi03MTkwLTQ4MTktYTcxZC05MTRmNDg5ZTJiY2MuanBlZ5GTBc0BHcyg" />Od 0,4 proc. do 36 proc. zarobiły w ciągu trzech lat fundusze PPK dla swoich klientów. Zasady funkcjonowania programu sprawiają, że na rachunkach oszczędzających na emeryturę jest przynajmniej 80 proc. więcej środków, niż te osoby wpłaciły same.

## Niemal co czwarty nastolatek przyznaje się do próby samookaleczania [WYWIAD]
 - [https://forsal.pl/lifestyle/psychologia/artykuly/8648325,niemal-co-czwarty-nastolatek-przyznaje-sie-do-proby-samookaleczania-wywiad.html](https://forsal.pl/lifestyle/psychologia/artykuly/8648325,niemal-co-czwarty-nastolatek-przyznaje-sie-do-proby-samookaleczania-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 06:42:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/R4WktkuTURBXy84YTg4YmY4NS03YzZlLTQ4ODktODg5NS0zODcwY2I0ZDRkZWMuanBlZ5GTBc0BHcyg" />Niemal co czwarty nastolatek przyznaje się do próby samookaleczania ciała. Jeden na dziesięciu wypisuje o sobie złe rzeczy w internecie - mów w wywiadzie Prof. Jakub Andrzejczak, kierownik Zakładu Socjologii Wychowania Wielkopolskiej Akademii Społeczno-Ekonomicznej.

## Ponad połowa Polaków nie chce się szczepić. Boją się skutków ubocznych [SONDAŻ DGP i RMF]
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8648294,szczepienia-sondaz-ponad-polowa-polakow-nie-chce.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8648294,szczepienia-sondaz-ponad-polowa-polakow-nie-chce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 06:37:22+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D-sktkuTURBXy85ODczZWExNS02OTg1LTRhYzYtOGM3Yi02NWJmODk1YmUyNWYuanBlZ5GTBc0BHcyg" />Ponad połowa Polaków nie chce się szczepić. Wśród powodów obawy o skutki uboczne. Poglądy zależą od sympatii politycznych i od wieku.

## Laptopy dla IV klas. Jakie komputery dostaną uczniowie i kto będzie nimi administrował?
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8648315,laptopy-dla-iv-klas-co-wiadomo-o-rzadowym-programie.html](https://forsal.pl/lifestyle/edukacja/artykuly/8648315,laptopy-dla-iv-klas-co-wiadomo-o-rzadowym-programie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 06:29:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mwDktkuTURBXy81MmE1ZTNmMy0wNDViLTRiZjctOTk3Mi03OWQ2YjhhOTYxNTQuanBlZ5GTBc0BHcyg" />363 tys. czwartoklasistów ma na jesieni dostać własne laptopy. – Bez platformy edukacyjnej i szkoleń to nietrafiony wydatek – oceniają nauczyciele i samorządowcy.

## Technologia fuzji jądrowej. Biznes już teraz próbuje wykorzystać energię gwiazd
 - [https://forsal.pl/biznes/energetyka/artykuly/8645550,fuzja-jadrowa-wykorzystanie-w-biznesie-medycyna-przemysl.html](https://forsal.pl/biznes/energetyka/artykuly/8645550,fuzja-jadrowa-wykorzystanie-w-biznesie-medycyna-przemysl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 05:45:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FMektkuTURBXy8xMmY3NTNjNC1jYzNkLTQ1YzEtOTlhYy00ZjIyNDJiZDY2YTYuanBlZ5GTBc0BHcyg" />Fuzja jądrowa ma być zbawieniem dla energetyki. Jednak budowa elektrowni termojądrowej będzie długim, skomplikowanym i kosztownym procesem. Dlatego niektóre firmy już teraz znajdują sposoby na komercjalizację zaawansowanych technologii, które opracowują, aby ostatecznie wykorzystać energię gwiazd.

## Eksport z Chin bez konkurencji. Kraj ten przejął niemalże całą Afrykę w 20 lat
 - [https://forsal.pl/gospodarka/artykuly/8646497,eksport-chin-do-afryki.html](https://forsal.pl/gospodarka/artykuly/8646497,eksport-chin-do-afryki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 05:25:17+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/R2SktkuTURBXy9jMDc5YjZmMS0zZWU5LTRiOTYtOTM3Zi01OGJjNzBmODg0OWQuanBlZ5GTBc0BHcyg" />Chiny są głównym źródłem importu dla ponad 30 afrykańskich państw. Dwie dekady temu było ich tylko kilka – pisze Statista.

## Oto najlepsze i najgorsze spółki z WIG 20 w 2022 roku [RANKING]
 - [https://forsal.pl/finanse/gielda/galeria/8647309,najlepsze-i-najgorsze-spolki-wig-20-ranking.html](https://forsal.pl/finanse/gielda/galeria/8647309,najlepsze-i-najgorsze-spolki-wig-20-ranking.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 05:20:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/at5ktkuTURBXy8zOTJkMmYzYS0xYTZiLTQwZjAtODNhOC1hZGRjOTM1Nzc5MjIuanBlZ5GTBc0BHcyg" />W 2022 roku szalejąca inflacja nie dała zarobić na lokatach. Czy dało się za to zyskać na inwestycjach w największe giełdowe spółki? Odpowiedź, brzmi: raczej nie. Wśród spółek wchodzących w skład indeksu WIG20 tylko dwie były na plusie, a biorąc pod uwagę, że w ubiegłym roku inflacja wynosiła 16,6 proc., tylko jedna spółka zapewniła zysk na dobrym poziomie.

## Polacy coraz bardziej podatni na rosyjską propagandę? [BADANIE]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8648477,rosyjska-propaganda-polacy-badanie.html](https://forsal.pl/gospodarka/polityka/artykuly/8648477,rosyjska-propaganda-polacy-badanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 05:00:59+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WCsktkuTURBXy9jMWU3ZGZmMy1iMmI0LTRiYzQtODkzMi0yNDg4MTVkOTQyNDkuanBlZ5GTBc0BHcyg" />Rośnie liczba osób podzielających tezy rosyjskiej propagandy – wynika z badania Warsaw Enterprise Institute. Coraz więcej Polaków uważa, że uchodźcy z Ukrainy to w rzeczywistości imigranci ekonomiczni, że ze względu na Wołyń i Banderę nie powinniśmy wspierać Kijowa, że powinniśmy wstrzymać dostawy broni na Ukrainę, bo to tylko podsyca konflikt. Pułkownik Adam Jawor, oficer rezerwy polskich służb specjalnych, wyjaśnia, że propaganda zewnętrzna najlepiej działa w społeczeństwach podzielonych, jak polskie, wykorzystując głównie media społecznościowe.

## Kraje z najniższym i najwyższym wiekiem emerytalnym w Europie. Zobacz RANKING
 - [https://forsal.pl/praca/artykuly/8646428,wiek-emerytalny-najnizszy-najwyzszy-w-ue-panstwa.html](https://forsal.pl/praca/artykuly/8646428,wiek-emerytalny-najnizszy-najwyzszy-w-ue-panstwa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/x_pktkuTURBXy80MjMxMDcwOS1jZTc5LTQ1ODctOTFhNi1hNDZlNWRmMDBkNGQuanBlZ5GTBc0BHcyg" />Podwyższenie wieku emerytalnego to ostatnio gorący temat. PiS straszy, że opozycja po wygranych wyborach zdecyduje się na taki krok, PO zaprzecza. Jednak światowy trend jest taki, że obowiązkowy wiek emerytalny ma wzrosnąć w większości krajów OECD. Francuski rząd właśnie przedstawił reformę podnosząca wiek przejścia na emeryturę. Sprawdź i porównaj, jaki wiek emerytalny obowiązuje obecnie w różnych krajach.

## Rosja: ludzi mamy pod dostatkiem
 - [https://forsal.pl/gospodarka/demografia/artykuly/8647332,rosja-ludzi-mamy-pod-dostatkiem.html](https://forsal.pl/gospodarka/demografia/artykuly/8647332,rosja-ludzi-mamy-pod-dostatkiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 04:40:58+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xybktkuTURBXy9hYTg0MWM0Yi0wZWRiLTQ5N2QtYjYwNS0yMmMzZGRjZDc5ZjYuanBlZ5GTBc0BHcyg" />Jednym ze skutków rosyjskiej inwazji na Ukrainę będzie degradacja rosyjskiej gospodarki, nie tylko w wyniku zastosowania sankcji przez kraje zachodnie, ale z przyczyn wewnętrznych – prowadzenia wyniszczającej polityki demograficznej. Obecne władze Federacji Rosyjskiej w sposób ekstensywny, podobnie jak w okresie ZSRR, zarządzają nie tylko surowcami, ale również własnym społeczeństwem.

## Żyli ponad 110 lat. Kim byli superstulatkowie?
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8646766,najstarsi-ludzie-na-swiecie-superstulatkowie.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8646766,najstarsi-ludzie-na-swiecie-superstulatkowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 04:40:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5CyktkuTURBXy80MmU2ZGM3Yy1kMjc2LTQ4NTItYTk5NS1mOWNjNTk5MTQ5YzEuanBlZ5GTBc0BHcyg" />Większość z nich urodziła się we Francji lub Japonii. Najstarsza osoba miała 122 lata. Oto ludzie, którzy żyli najdłużej na świecie.

## Będą też laptopy dla nauczycieli. Szef MEiN: Ponad 400 tys. sztuk
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/8648475,laptopy-dla-nauczycieli-uczniow-przemyslaw-czarnek.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/8648475,laptopy-dla-nauczycieli-uczniow-przemyslaw-czarnek.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-30 00:30:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sgYktkuTURBXy84OGIxOTk5NS1lZjkwLTQyZTAtYTAyNy05Y2FlODRlYjBiMDEuanBlZ5GTBc0BHcyg" />Po zakończeniu przetargu na laptopy dla uczniów, będą też laptopy dla nauczycieli - poinformował w niedzielę minister edukacji i nauki Przemysław Czarnek. Dodał, że do nauczycieli trafi ponad 400 tys. sztuk sprzętu.
