# Source Daily Mail, Source URL:https://www.dailymail.co.uk/news/index.rss, Source language: en-US

## Police search for two thieves dressed like tradies after robbery of Dandenong jewellery store
 - [https://www.dailymail.co.uk/news/article-11693675/Police-search-two-thieves-dressed-like-tradies-robbery-Dandenong-jewellery-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693675/Police-search-two-thieves-dressed-like-tradies-robbery-Dandenong-jewellery-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:13:42+00:00
 - user: None

Two men dressed like tradies allegedly stole more than $2milllion of jewellery from a Melbourne store in an armed robbery on December 29.

## Bolsonaro applies to EXTEND his US visa by six months as Biden faces calls to return him to Brazil
 - [https://www.dailymail.co.uk/news/article-11693867/Bolsonaro-applies-EXTEND-visa-six-months-Biden-faces-calls-return-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693867/Bolsonaro-applies-EXTEND-visa-six-months-Biden-faces-calls-return-Brazil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:10:21+00:00
 - user: None

Former Brazilian President Jair Bolsonaro has applied for a tourist visa so that he can remain in the US even as investigators probe any role he may have played in violent protests in his country's capital.

## Rowan Sutton fights off croc with machete after it mauled Lachlan McDougall Monk on Daly River, NT
 - [https://www.dailymail.co.uk/news/article-11693715/Rowan-Sutton-fights-croc-machete-mauled-Lachlan-McDougall-Monk-Daly-River-NT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693715/Rowan-Sutton-fights-croc-machete-mauled-Lachlan-McDougall-Monk-Daly-River-NT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:09:57+00:00
 - user: None

The man wouldn't be alive today if it wasn't for the heroic actions of his colleague after an crocodile egg collecting mission in the Northern Territory almost ended in tragedy on the Daly River.

## Two EMTs and fire department lieutenant fired after Tyre Nichols killing
 - [https://www.dailymail.co.uk/news/article-11694231/Two-EMTs-fire-department-lieutenant-fired-Tyre-Nichols-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694231/Two-EMTs-fire-department-lieutenant-fired-Tyre-Nichols-killing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:08:51+00:00
 - user: None

Two EMTs and a fire department lieutenant have been fired in Memphis following the January 7 killing of Tyre Nichols, 29. Nine have now lost their jobs.

## Michigan teenage girl, 15, is found dead near high school athletic fields
 - [https://www.dailymail.co.uk/news/article-11693975/Michigan-teenage-girl-15-dead-near-high-school-athletic-fields.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693975/Michigan-teenage-girl-15-dead-near-high-school-athletic-fields.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:02:26+00:00
 - user: None

Ann Arbor authorities found the remains of Adriana Davidson, 15, near the Pioneer High School athletic fields on Monday afternoon, four days after she was reported missing.

## Documentary searches for answers in Canadian man's 2018 mysterious disappearance in Mexico
 - [https://www.dailymail.co.uk/news/article-11693141/Documentary-searches-answers-Canadian-mans-2018-mysterious-disappearance-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693141/Documentary-searches-answers-Canadian-mans-2018-mysterious-disappearance-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 23:01:55+00:00
 - user: None

The documentary, Malcom is Missing, is based on the disappearance of Canadian Malcom Madsen, who has not been seen since a visit to a Puerto Vallarta, Mexico bar with his girlfriend.

## Police arrest two men on suspicion of murder of council worker Ashley Dale in Liverpool
 - [https://www.dailymail.co.uk/news/article-11694185/Police-arrest-two-men-suspicion-murder-council-worker-Ashley-Dale-Liverpool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694185/Police-arrest-two-men-suspicion-murder-council-worker-Ashley-Dale-Liverpool.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:54:41+00:00
 - user: None

Detectives have today arrested two men in connection with the murder of 28-year-old council worker Ashley Dale, who was shot dead in Liverpool last August.

## Labour is urged to stop risking lives by trying to cripple legislation for minimising strike damage
 - [https://www.dailymail.co.uk/news/article-11694113/Labour-urged-stop-risking-lives-trying-cripple-legislation-minimising-strike-damage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694113/Labour-urged-stop-risking-lives-trying-cripple-legislation-minimising-strike-damage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:53:35+00:00
 - user: None

Labour was accused of 'playing politics' with people's lives after it tried to cripple moves to minimise strike disruption.

## Biden says the U.S. will NOT send F-16 jets to Ukraine
 - [https://www.dailymail.co.uk/news/article-11694041/Biden-says-U-S-NOT-send-F-16-jets-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694041/Biden-says-U-S-NOT-send-F-16-jets-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:52:39+00:00
 - user: None

President Joe Biden answered in the negative Monday when asked if he'd send F-16 fighter jets to Ukraine. 'No,' he told reporters on the South Lawn.

## Second home owners could see their council tax bill DOUBLE in some of Britain's tourist hotspots
 - [https://www.dailymail.co.uk/news/article-11694173/Second-home-owners-council-tax-bill-DOUBLE-Britains-tourist-hotspots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694173/Second-home-owners-council-tax-bill-DOUBLE-Britains-tourist-hotspots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:51:43+00:00
 - user: None

Government figures released last year showed 257,331 homes in England were unoccupied for at least six months. But there is little fear the tax changes would hurt tourism.

## Minister faces backlash over claim that patients are 'comfortable' attending GP appointments online
 - [https://www.dailymail.co.uk/news/article-11694183/Minister-faces-backlash-claim-patients-comfortable-attending-GP-appointments-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694183/Minister-faces-backlash-claim-patients-comfortable-attending-GP-appointments-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:50:01+00:00
 - user: None

Helen Whately, pictured, said the NHS will monitor up to 50,000 patients a month in their own homes rather than in hospital under plans to free-up beds.

## Biden shrugs off question on whether he'll testify in classified docs case
 - [https://www.dailymail.co.uk/news/article-11694029/Biden-shrugs-question-hell-testify-classified-docs-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694029/Biden-shrugs-question-hell-testify-classified-docs-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:49:59+00:00
 - user: None

President Joe Biden on Monday shrugged off a question about whether he would testify in his classified documents investigation if the special counsel asked him to with a dismissive wave.

## Woke Disney slammed for 1619 Project on Hulu by viewers who boycott the service
 - [https://www.dailymail.co.uk/news/article-11693831/Woke-Disney-slammed-1619-Project-Hulu-viewers-boycott-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693831/Woke-Disney-slammed-1619-Project-Hulu-viewers-boycott-service.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:45:09+00:00
 - user: None

Critics slammed Disney-owned streaming service Hulu for their 'woke' screen adaptation of Nikole Hannah-Jones' The 1619 Project some saying the complexities of the topics not translating to screen.

## 'Do we need to see white people also get beat?': asks Whoopi Goldberg after Tyre Nichols' death
 - [https://www.dailymail.co.uk/news/article-11693825/Do-need-white-people-beat-asks-Whoopi-Goldberg-Tyre-Nichols-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693825/Do-need-white-people-beat-asks-Whoopi-Goldberg-Tyre-Nichols-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:42:14+00:00
 - user: None

Whoopi Goldberg (left) asked The View panel if we need to see 'white people get beat' for total police reform in the wake of Tyre Nichols' death. Goldberg, 67, insisted she was not inciting violence.

## Patients face battle to see GPs as one in four cannot even get an appointment, new data shows
 - [https://www.dailymail.co.uk/news/article-11694117/Patients-face-battle-GPs-one-four-appointment-new-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694117/Patients-face-battle-GPs-one-four-appointment-new-data-shows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:38:44+00:00
 - user: None

The delays are leaving many in crippling pain, destroying relationships and forcing some to quit work, warns the Office for National Statistics.

## Retired doctors could work from home to deal with non-emergency 111 calls in move to ease NHS burden
 - [https://www.dailymail.co.uk/news/article-11694163/Retired-doctors-work-home-deal-non-emergency-111-calls-ease-NHS-burden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694163/Retired-doctors-work-home-deal-non-emergency-111-calls-ease-NHS-burden.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:37:05+00:00
 - user: None

The non-emergency NHS 111 service will allow more staff to work from home and recruit more retired doctors, after concerns too many people are referred to overcrowded A&amp;Es or to 999.

## Retired Air Force intel officer had hundreds of classified documents in his Florida home
 - [https://www.dailymail.co.uk/news/article-11693931/Retired-Air-Force-intel-officer-hundreds-classified-documents-Florida-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693931/Retired-Air-Force-intel-officer-hundreds-classified-documents-Florida-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:31:16+00:00
 - user: None

A former Air Force intelligence officer has agreed to plea guilty  after prosecutors said he illegally kept hundreds of highly classified documents at his Florida home.

## Trump: I need more lawyers than Al Capone and trust Putin over intelligence 'lowlifes'
 - [https://www.dailymail.co.uk/news/article-11693677/Trump-need-lawyers-Al-Capone-trust-Putin-intelligence-lowlifes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693677/Trump-need-lawyers-Al-Capone-trust-Putin-intelligence-lowlifes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:15:13+00:00
 - user: None

Trump suggested that he trusts Russian President Vladimir Putin more than U.S. intelligence officials as he complained he needs more lawyers than infamous gangster boss Al Capone.

## Auckland family's home ripped apart in New Zealand landslide as they search for children
 - [https://www.dailymail.co.uk/news/article-11693811/Auckland-familys-home-ripped-apart-New-Zealand-landslide-search-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693811/Auckland-familys-home-ripped-apart-New-Zealand-landslide-search-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:13:54+00:00
 - user: None

Teressa Hodgson, her partner Luke Hanan and their five kids were inside their Tauranga home, southeast of Auckland, on Saturday night when it was suddenly flooded with mud.

## Curry house at centre of internet storm after widow claimed promo video featured her late husband
 - [https://www.dailymail.co.uk/news/article-11693837/Curry-house-centre-internet-storm-widow-claimed-promo-video-featured-late-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693837/Curry-house-centre-internet-storm-widow-claimed-promo-video-featured-late-husband.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:12:49+00:00
 - user: None

The mystery over a 'ghost diner' at an Indian restaurant that cooked up a storm on the internet has finally been solved, Mail Online can reveal.

## Colorado woman, 40, who survived 200-foot fall in California hiked 150-feet with a broken neck
 - [https://www.dailymail.co.uk/news/article-11693711/Colorado-woman-40-survived-200-foot-fall-California-hiked-150-feet-broken-neck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693711/Colorado-woman-40-survived-200-foot-fall-California-hiked-150-feet-broken-neck.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:12:12+00:00
 - user: None

Ruth Woroniecki, 40, revealed that she had to hike to safety with a broken neck after she survived a 200-foot fall in the San Gabriel Mountains while out hiking on Christmas Eve.

## Bond girl Eva Green refers to shooting on Alec Baldwin film Rust in High Court battle with producer
 - [https://www.dailymail.co.uk/news/article-11693939/Bond-girl-Eva-Green-refers-shooting-Alec-Baldwin-film-Rust-High-Court-battle-producer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693939/Bond-girl-Eva-Green-refers-shooting-Alec-Baldwin-film-Rust-High-Court-battle-producer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:11:10+00:00
 - user: None

French movie actress Eva Green referred to the fatal shooting of a cinematographer on the set of Alec Baldwin's film Rust while giving evidence to the High Court today in a multi-million legal battle.

## MI5 illegally kept data on millions of Britons and ministers unwittingly signed off warrants
 - [https://www.dailymail.co.uk/news/article-11694019/MI5-illegally-kept-data-millions-Britons-ministers-unwittingly-signed-warrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694019/MI5-illegally-kept-data-millions-Britons-ministers-unwittingly-signed-warrants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:10:18+00:00
 - user: None

In a landmark judgment, the Investigatory Powers Tribunal (IPT) ruled there were 'very serious failings' at the highest levels of MI5 to comply with privacy safeguards.

## Is it naff to colour-code your books? A home library is the new middle-class boast.
 - [https://www.dailymail.co.uk/news/article-11694005/Is-naff-colour-code-books-home-library-new-middle-class-boast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11694005/Is-naff-colour-code-books-home-library-new-middle-class-boast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:09:45+00:00
 - user: None

Whether you prefer to organise your books in cheerful rainbow order, or in piles of decreasing size there's no doubt the 'shelfie' is having a moment.

## Maegan Hall details her police sex scandal with SEVEN fellow officers
 - [https://www.dailymail.co.uk/news/article-11693351/Maegan-Hall-details-police-sex-scandal-SEVEN-fellow-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693351/Maegan-Hall-details-police-sex-scandal-SEVEN-fellow-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:08:13+00:00
 - user: None

DailyMail.com obtained interview transcripts of fired Tennessee cop Maegan Hall, 26, detailing her affairs with several fellow officers.

## Professor and co-author of reparations book demand government pay $14 TRILLION to black Americans
 - [https://www.dailymail.co.uk/news/article-11693589/Professor-author-reparations-book-demand-government-pay-14-TRILLION-reparations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693589/Professor-author-reparations-book-demand-government-pay-14-TRILLION-reparations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:07:15+00:00
 - user: None

Duke University professor William A. Darity, pictured right, and writer A. Kirsten Mullen, left, argued that the federal government should foot the bill for $14 trillion reparations as it is 'culpable for slavery'.

## Sen Joni Ernst demands federal employees who stole COVID funds be fired
 - [https://www.dailymail.co.uk/news/article-11693833/Sen-Joni-Ernst-demands-federal-employees-stole-COVID-funds-fired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693833/Sen-Joni-Ernst-demands-federal-employees-stole-COVID-funds-fired.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:06:18+00:00
 - user: None

Thousands of federal employees received Covid-era unemployment checks and pandemic-related loans they were ineligible for and Sen. Joni Ernst is calling for each of them to be fired.

## Democrats say Kamala is not 'adept as a communicator,' is underwhelming and has been invisible
 - [https://www.dailymail.co.uk/news/article-11693537/Democrats-say-Kamala-not-adept-communicator-underwhelming-invisible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693537/Democrats-say-Kamala-not-adept-communicator-underwhelming-invisible.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:06:11+00:00
 - user: None

Democrats say Kamala Harris isn't 'adept as a communicator,' is underwhelming and has been almost invisible in a brutal assessment of her political future.

## Memphis top cop who set up aggressive Scorpion task force was in charge of corrupt unit in Atlanta
 - [https://www.dailymail.co.uk/news/article-11693613/Memphis-cop-set-aggressive-Scorpion-task-force-charge-corrupt-unit-Atlanta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693613/Memphis-cop-set-aggressive-Scorpion-task-force-charge-corrupt-unit-Atlanta.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:05:20+00:00
 - user: None

DailyMail.com can reveal Davis was previously in charge of the infamous REDDOG Unit while working at Atlanta Police, which has striking similarities to SCORPION.

## Texas police chief is placed on leave after ordering SWAT raid on the wrong house
 - [https://www.dailymail.co.uk/news/article-11693627/Texas-police-chief-placed-leave-ordering-SWAT-raid-wrong-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693627/Texas-police-chief-placed-leave-ordering-SWAT-raid-wrong-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 22:01:37+00:00
 - user: None

The police chief of a city in Texas was put on leave after ordering a SWAT raid on the home of an innocent family and failing to mention it to officials.

## Lawyer for family of LSU student Madi says 'rape is rape' after defense alleges sex was consensual
 - [https://www.dailymail.co.uk/news/article-11693579/Lawyer-family-LSU-student-Madi-says-rape-rape-defense-alleges-sex-consensual.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693579/Lawyer-family-LSU-student-Madi-says-rape-rape-defense-alleges-sex-consensual.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:52:18+00:00
 - user: None

The lawyer representing the family of Madi Brooks (left) has insisted 'rape is rape' after the defense alleged she consented to sex. Kerry Miller told Fox News he was 'blown away' by suspects' defense.

## Biden vows to fix 150-year-old Baltimore train tunnel
 - [https://www.dailymail.co.uk/news/article-11693759/Biden-vows-fix-150-year-old-Baltimore-train-tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693759/Biden-vows-fix-150-year-old-Baltimore-train-tunnel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:50:58+00:00
 - user: None

President Joe Biden was in Baltimore on Monday to kick off a project that will replace a train tunnel built back when Ulysses S. Grant was president.

## Law enforcement face criticism for response to break-in at Nancy Pelosi's San Francisco home
 - [https://www.dailymail.co.uk/news/article-11693651/Law-enforcement-face-criticism-response-break-Nancy-Pelosis-San-Francisco-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693651/Law-enforcement-face-criticism-response-break-Nancy-Pelosis-San-Francisco-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:39:15+00:00
 - user: None

Law enforcement officials who handled the break-in at former House Speaker Nancy Pelosi's home have been criticized over claims the brutal hammer attack against Paul Pelosi could have been prevented.

## Anti-aging biotech tycoon is accused of dumping fiancée after breast cancer diagnosis
 - [https://www.dailymail.co.uk/news/article-11692609/Anti-aging-biotech-tycoon-accused-dumping-fianc-e-breast-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692609/Anti-aging-biotech-tycoon-accused-dumping-fianc-e-breast-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:26:54+00:00
 - user: None

Taryn Southern, 37, is suing Bryan Johnson, who she claims kicked her out of their LA home and went back on his $149,000 separation agreement after she was diagnosed with breast cancer in 2019.

## China warns Kevin McCarthy NOT to visit Taiwan
 - [https://www.dailymail.co.uk/news/article-11693477/China-warns-Kevin-McCarthy-NOT-visit-Taiwan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693477/China-warns-Kevin-McCarthy-NOT-visit-Taiwan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:13:50+00:00
 - user: None

Beijing on Monday warned House Speaker Kevin McCarthy and officials to honor the 'one-China' policy and not do anything that 'violates' international norms.

## Johnson & Johnson's bankruptcy plan to resolve  claims its talc products causing cancer is REJECTED
 - [https://www.dailymail.co.uk/news/article-11693807/Johnson-Johnsons-bankruptcy-plan-resolve-claims-talc-products-causing-cancer-REJECTED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693807/Johnson-Johnsons-bankruptcy-plan-resolve-claims-talc-products-causing-cancer-REJECTED.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:13:19+00:00
 - user: None

The decision by the U.S. 3rd Circuit Court of Appeals in Philadelphia on Monday dismissed a Chapter 11 petition filed by a recently created J&amp;J subsidiary in October.

## JACI STEPHEN's infectious love-it-and-hate-it review of The Last Of Us
 - [https://www.dailymail.co.uk/news/article-11693615/JACI-STEPHENs-infectious-love-hate-review-Us.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693615/JACI-STEPHENs-infectious-love-hate-review-Us.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:11:53+00:00
 - user: None

STEPHEN: With what seemed like worms on acid slithering out if its mouth, Rain Dough Man - or Woman? Who knows - the gingery feelers locked lips with Tess.

## Anthony Albanese at the Australian Open: Jacinta Price slams PM for leaving Alice Springs for tennis
 - [https://www.dailymail.co.uk/news/article-11693765/Anthony-Albanese-Australian-Open-Jacinta-Price-slams-PM-leaving-Alice-Springs-tennis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693765/Anthony-Albanese-Australian-Open-Jacinta-Price-slams-PM-leaving-Alice-Springs-tennis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:11:38+00:00
 - user: None

Anthony Albanese has been slammed for being more interested in 'chugging beers' at the Australian Open than wanting to help Alice Springs.

## Interest rates forecast to rise four more times as Reserve Bank of Australia brings more pain
 - [https://www.dailymail.co.uk/news/article-11693683/Interest-rates-forecast-rise-four-times-Reserve-Bank-Australia-brings-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693683/Interest-rates-forecast-rise-four-times-Reserve-Bank-Australia-brings-pain.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:08:59+00:00
 - user: None

Deutsche Bank has made the dire forecast with the rate set to rise by a quarter of a per cent in February, March, May and August.

## China slams 'provocative and reckless hype' from four-star general that US will be at WAR  by 2025
 - [https://www.dailymail.co.uk/news/article-11693289/China-slams-provocative-reckless-hype-four-star-general-WAR-2025.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693289/China-slams-provocative-reckless-hype-four-star-general-WAR-2025.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:03:05+00:00
 - user: None

The ominous warning was delivered Friday in a memo from General Mike Minihan (pictured), who oversees the military branch's fleet of transport and refueling aircraft.

## Relatives of Jerry Garcia pull cannabis brand out of California as regulations let black market boom
 - [https://www.dailymail.co.uk/news/article-11693323/Relatives-Jerry-Garcia-pull-cannabis-brand-California-regulations-let-black-market-boom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693323/Relatives-Jerry-Garcia-pull-cannabis-brand-California-regulations-let-black-market-boom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:02:42+00:00
 - user: None

California has collected more than $4billion in taxes from legal cannabis sales. Regulations have made it difficult for legitimate weed business to be profitable.

## Gautam Adani loses $70BN after American investor accuses him of fraud
 - [https://www.dailymail.co.uk/news/article-11693573/Gautam-Adani-loses-70BN-American-investor-accuses-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693573/Gautam-Adani-loses-70BN-American-investor-accuses-fraud.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 21:00:21+00:00
 - user: None

Gautam Adani, 60, is now just the seventh-richest man in the world after his personal net worth dipped to $92.7billion following a damning report filed by a New York City-investment firm last week.

## Meteoric rise in food prices slowed slightly in December - but prices are still up 10%
 - [https://www.dailymail.co.uk/news/article-11693565/Meteoric-rise-food-prices-slowed-slightly-December-prices-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693565/Meteoric-rise-food-prices-slowed-slightly-December-prices-10.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:43:22+00:00
 - user: None

Dallas, the Twin Cities, and Baltimore are suffering some of the country's highest rates of inflation for food prices, which rose 14.1%, 13.7%, and 13.5% in those cities respectively.

## Decades-old Tylenol murders case is revived as Chicago cops launch 'intense effort' to find killer
 - [https://www.dailymail.co.uk/news/article-11693069/Decades-old-Tylenol-murders-case-revived-Chicago-cops-launch-intense-effort-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693069/Decades-old-Tylenol-murders-case-revived-Chicago-cops-launch-intense-effort-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:34:33+00:00
 - user: None

Police are using advanced DNA technology to find the killer of seven people murdered in Chicago in 1982 after they unknowingly took Tylenol pills laced with a lethal dose of cyanide.

## High Street stationer Paperchase 'could collapse as soon as tomorrow' as plans to sell up fade
 - [https://www.dailymail.co.uk/news/article-11693725/High-Street-stationer-Paperchase-collapse-soon-tomorrow-plans-sell-fade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693725/High-Street-stationer-Paperchase-collapse-soon-tomorrow-plans-sell-fade.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:33:35+00:00
 - user: None

The retailer could be sold to a new buyer  which could see a loss of stores and jobs as a result. The business has 106 branches and over 800 employees across the UK and Ireland.

## Where was Love Actually filmed? From a Notting Hill mews to a restaurant in Marseille
 - [https://www.dailymail.co.uk/news/article-11692341/Where-Love-Actually-filmed-Notting-Hill-mews-restaurant-Marseille.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692341/Where-Love-Actually-filmed-Notting-Hill-mews-restaurant-Marseille.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:09:28+00:00
 - user: None

Heathrow Airport and St Luke's Mews in Notting Hill, London, are among the most memorable scenes in the 2003 romantic comedy Love Actually.

## Elwood brawl: Melbourne driver fighting with pedestrian along Brighton Road caught on video
 - [https://www.dailymail.co.uk/news/article-11693541/Elwood-brawl-Melbourne-driver-fighting-pedestrian-Brighton-Road-caught-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693541/Elwood-brawl-Melbourne-driver-fighting-pedestrian-Brighton-Road-caught-video.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:06:09+00:00
 - user: None

A driver stopped their car before getting out to confront a pedestrian along Brighton Road in Elwood, south-east Melbourne, at 6pm on Monday.

## Americans think the GOVERNMENT is the nation's top problem
 - [https://www.dailymail.co.uk/news/article-11693413/Americans-think-GOVERNMENT-nations-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693413/Americans-think-GOVERNMENT-nations-problem.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 20:03:51+00:00
 - user: None

In a Gallup poll taken in January 2023, 21 percent of respondents named 'the government/poor leadership' as their top concern, up from 15 percent in December

## DOJ stonewalls GOP request for more information on classified Biden documents
 - [https://www.dailymail.co.uk/news/article-11693505/DOJ-stonewalls-GOP-request-information-classified-Biden-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693505/DOJ-stonewalls-GOP-request-information-classified-Biden-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:53:52+00:00
 - user: None

Justice Department denied Rep. Jim Jordan's request for more details on their handling of President Joe Biden's classified files, saying it would not provide him with the information.

## Hunt for 'Elon Musk lookalike' after man was racially abused in shopping centre
 - [https://www.dailymail.co.uk/news/article-11693397/Hunt-Elon-Musk-lookalike-man-racially-abused-shopping-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693397/Hunt-Elon-Musk-lookalike-man-racially-abused-shopping-centre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:42:49+00:00
 - user: None

Northumbria Police has taken to social media to launch an appeal for anyone with information regarding the man, who looks extremely like Elon Musk, to come forward.

## Nicho Hynes: Cronulla Sharks Dally M winner's  mum charged with heroin supply Central Coast NSW home
 - [https://www.dailymail.co.uk/news/article-11668511/Nicho-Hynes-Cronulla-Sharks-Dally-M-winners-mum-charged-heroin-supply-Central-Coast-NSW-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11668511/Nicho-Hynes-Cronulla-Sharks-Dally-M-winners-mum-charged-heroin-supply-Central-Coast-NSW-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:35:54+00:00
 - user: None

Julie Hynes has pleaded not guilty to supplying heroin after a 29-year-old man died of an overdose after allegedly inhaling the drug while packaging narcotics in her home on the NSW Central Coast.

## DAVID MARCUS: Joe, we told you so! Biden's migrant policies are destroying lives
 - [https://www.dailymail.co.uk/news/article-11693341/DAVID-MARCUS-Joe-told-Bidens-migrant-policies-destroying-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693341/DAVID-MARCUS-Joe-told-Bidens-migrant-policies-destroying-lives.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:29:16+00:00
 - user: None

MARCUS: Bidenvilles are popping up in New York City, as dozens of migrants slept on the streets Sunday night. How embarrassing for Biden as he is set to visit the Big Apple on Tuesday?

## 'Sixteen-week-old' human foetus is found inside a box outside a London hospital
 - [https://www.dailymail.co.uk/news/article-11693463/Sixteen-week-old-human-foetus-inside-box-outside-London-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693463/Sixteen-week-old-human-foetus-inside-box-outside-London-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:16:05+00:00
 - user: None

The discovery was made at Barnet Hospital in north London at around 9am but police said their priority is to ensure the mother is okay and receiving medical attention.

## Austin hair salon owners fear they'll have to close after attacks on their business by the homeless
 - [https://www.dailymail.co.uk/news/article-11693089/Austin-hair-salon-owners-fear-theyll-close-attacks-business-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693089/Austin-hair-salon-owners-fear-theyll-close-attacks-business-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:14:18+00:00
 - user: None

The owners of a hair salon in Austin recorded the moment a crazed man from a nearby homeless camp approached their glass storefront swinging a piece of timber.

## Watch as Extinction Rebellion eco-zealots storm House of Lords as peers debated new protest laws
 - [https://www.dailymail.co.uk/news/article-11693395/Watch-Extinction-Rebellion-eco-zealots-storm-House-Lords-peers-debated-new-protest-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693395/Watch-Extinction-Rebellion-eco-zealots-storm-House-Lords-peers-debated-new-protest-laws.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:14:04+00:00
 - user: None

The 12 demonstrates from the Extinction Rebellion were escorted out of the public gallery by doorkeepers and security staff, all wearing t-shirts which bore the slogan 'Defend Human Rights'.

## New Jersey surgeon father sues daughter's wedding photographer who left him $76,0000 out of pocket
 - [https://www.dailymail.co.uk/news/article-11692265/New-Jersey-surgeon-father-sues-daughters-wedding-photographer-left-76-0000-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692265/New-Jersey-surgeon-father-sues-daughters-wedding-photographer-left-76-0000-pocket.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:12:02+00:00
 - user: None

Dr Amit Patel, 59, paid Clane Gessel and his studio up front for him to photograph his daughter's wedding in Turkey in May 2022.

## 'He Gets Us' organizers to spend $20 million on Super Bowl ad aiming to rebrand Jesus
 - [https://www.dailymail.co.uk/news/article-11692959/He-Gets-organizers-spend-20-million-Super-Bowl-ad-aiming-rebrand-Jesus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692959/He-Gets-organizers-spend-20-million-Super-Bowl-ad-aiming-rebrand-Jesus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:10:39+00:00
 - user: None

A Christian non-profit has spent $20 million on a Super Bowl ad aiming to rebrand Jesus. The 'He Gets Us' campaign has been tied to a host of controversial, right-wing organizations.

## Speeding driver, 32, who caused deaths of two boys is warned he faces 'very significant sentence'
 - [https://www.dailymail.co.uk/news/article-11693389/Speeding-driver-32-caused-deaths-two-boys-warned-faces-significant-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693389/Speeding-driver-32-caused-deaths-two-boys-warned-faces-significant-sentence.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:08:35+00:00
 - user: None

Jack Hart, 32, (pictured) of Anlaby Road, west Hull, had previously denied causing the death of Steven Duffield, 10, and Mason Deakin 11, by dangerous driving on Anlaby Road.

## CNN will air Bill Maher's segment 'Overtime' - as boss Chris Licht works on 'casting a wide net'
 - [https://www.dailymail.co.uk/news/article-11693255/CNN-air-Bill-Mahers-segment-Overtime-boss-Chris-Licht-works-casting-wide-net.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693255/CNN-air-Bill-Mahers-segment-Overtime-boss-Chris-Licht-works-casting-wide-net.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:08:17+00:00
 - user: None

CNN will soon begin airing the post show of HBO's 'Real Time with Bill Maher' as part of CEO Chris Licht's measures to widen the network's appeal.

## More than 40 million people face crippling icy temperatures today as Arctic blast grips 15 states
 - [https://www.dailymail.co.uk/news/article-11692765/More-40-million-people-face-crippling-icy-temperatures-today-Arctic-blast-grips-15-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692765/More-40-million-people-face-crippling-icy-temperatures-today-Arctic-blast-grips-15-states.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:05:44+00:00
 - user: None

A severe snowstorm killed one person as arctic conditions caused a 40-car-pileup in Wyoming, pictured left. Millions are bracing for further sub-zero temperatures and icy winds in the coming days.

## Mandatory CRT-style training for NYC staff branded 'immoral and illegal' waste of money
 - [https://www.dailymail.co.uk/news/article-11693295/Mandatory-CRT-style-training-NYC-staff-branded-immoral-illegal-waste-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693295/Mandatory-CRT-style-training-NYC-staff-branded-immoral-illegal-waste-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 19:05:09+00:00
 - user: None

A mandatory critical race theory-inspired course forced on New York City's public workers is an 'immoral and illegal' waste of money that will sew grievance, an expert has said.

## Grieving father 'tried to kill man he blamed for drowning death of his son, 18, in machete attack
 - [https://www.dailymail.co.uk/news/article-11693219/Grieving-father-tried-kill-man-blamed-drowning-death-son-18-machete-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693219/Grieving-father-tried-kill-man-blamed-drowning-death-son-18-machete-attack.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:59:39+00:00
 - user: None

Samson Price, 48, was said to be consumed with grief after his son Samson Jnr (pictured), 18, drowned in Wigan in October 2020 and held one of his son's friends Patrick Brown, 21, responsible.

## Migrants kicked out of Midtown hotel have set up tents on sidewalk after refusing to move to shelter
 - [https://www.dailymail.co.uk/news/article-11692829/Migrants-kicked-Midtown-hotel-set-tents-sidewalk-refusing-shelter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692829/Migrants-kicked-Midtown-hotel-set-tents-sidewalk-refusing-shelter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:57:51+00:00
 - user: None

The encampment sprouted out outside the Watson Hotel seemingly overnight, and serves as the latest development in the city's ongoing saga on where to house the abnormal amount of asylum seekers.

## Sadiq Khan suggests it would be 'weak' for him to hold referendum on ULEZ expansion
 - [https://www.dailymail.co.uk/news/article-11693267/Sadiq-Khan-suggests-weak-hold-referendum-ULEZ-expansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693267/Sadiq-Khan-suggests-weak-hold-referendum-ULEZ-expansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:45:27+00:00
 - user: None

The capital's mayor dismissed anger at his decision to expand ULEZ to the whole of the London from late August as he hit out at 'vested interests'.

## Grindr users warned after two Spanish-speaking thieves drugged and robbed four men they met on app
 - [https://www.dailymail.co.uk/news/article-11693363/Grindr-users-warned-two-Spanish-speaking-thieves-drugged-robbed-four-men-met-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693363/Grindr-users-warned-two-Spanish-speaking-thieves-drugged-robbed-four-men-met-app.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:44:08+00:00
 - user: None

Grindr users have been warned amid reports two Spanish-speaking thieves drugged and robbed four men they met on the gay hook-up app, between New Year's Eve and January 9, in London.

## NYC will set record after going 327 days without snow
 - [https://www.dailymail.co.uk/news/article-11692593/NYC-set-record-going-327-days-without-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692593/NYC-set-record-going-327-days-without-snow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:41:06+00:00
 - user: None

New York City snowless streak will set a record for the latest-ever 'first measurable snow' record  of 327 days without snow - with no forecast of the fluffy powdery flakes anytime soon.

## Top Republican dismisses claims he's ignoring Trump family business deals
 - [https://www.dailymail.co.uk/news/article-11692771/Top-Republican-dismisses-claims-hes-ignoring-Trump-family-business-deals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692771/Top-Republican-dismisses-claims-hes-ignoring-Trump-family-business-deals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:15:35+00:00
 - user: None

House Oversight Committee Chairman James Comer dismissed that he's ignoring Donald Trump's family's foreign business dealings while zeroing in on Hunter Biden's.

## Donald Trump's role in Stormy Daniels 'hush money' payments examined by Manhattan grand jury
 - [https://www.dailymail.co.uk/news/article-11693337/Donald-Trump-Stormy-Daniels-hush-money-Manhattan-grand-jury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693337/Donald-Trump-Stormy-Daniels-hush-money-Manhattan-grand-jury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:15:21+00:00
 - user: None

Prosecutors in Manhattan District Attorney Alvin Bragg's office are laying out their case, which could potentially lead to criminal charges, according to the New York Times.

## Chair of California reparations panel pushes for a wealth tax to pay descendants of slaves
 - [https://www.dailymail.co.uk/news/article-11693095/Chair-California-reparations-panel-pushes-wealth-tax-pay-descendants-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693095/Chair-California-reparations-panel-pushes-wealth-tax-pay-descendants-slaves.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:14:35+00:00
 - user: None

California reparations task force chair Kamilah Moore tweeted that the panel is considering new taxes to fund payments to descendants of slaves.

## Netflix documentary Gunther's Millions exposes truth behind world's richest dog
 - [https://www.dailymail.co.uk/news/article-11692671/Netflix-documentary-Gunthers-Millions-exposes-truth-worlds-richest-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692671/Netflix-documentary-Gunthers-Millions-exposes-truth-worlds-richest-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 18:03:32+00:00
 - user: None

For decades, Italian pharmaceutical heir Maurizio Mian perpetrated an elaborate ruse, claiming to be the caretaker of a wealthy line of German Shepherds named Gunther.

## Michael Gove gives developers six weeks to sign contract to fix fire safety issues in towers
 - [https://www.dailymail.co.uk/news/article-11693233/Michael-Gove-gives-developers-six-weeks-sign-contract-fix-fire-safety-issues-towers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693233/Michael-Gove-gives-developers-six-weeks-sign-contract-fix-fire-safety-issues-towers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:54:21+00:00
 - user: None

Michael Gove insisted companies that fail to meet the cut-off for addressing post-Grenfell concerns will have to 'find another line of work'.

## Triple murderer who stabbed wife and strangled his children seeks permission to move to open prison
 - [https://www.dailymail.co.uk/news/article-11693179/Triple-murderer-stabbed-wife-strangled-children-seeks-permission-open-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693179/Triple-murderer-stabbed-wife-strangled-children-seeks-permission-open-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:53:17+00:00
 - user: None

Evil triple murderer Phillip Austin (left) murdered his wife Claire (right), their children Keiran, eight and seven-year-old Jade and their two dogs at their family home in Northampton in 2000.

## BBC journalists 'don't grasp basic economics' and are guilty of 'uniformed group-think'
 - [https://www.dailymail.co.uk/news/article-11693253/BBC-journalists-dont-grasp-basic-economics-guilty-uniformed-group-think.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693253/BBC-journalists-dont-grasp-basic-economics-guilty-uniformed-group-think.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:49:43+00:00
 - user: None

A report commissioned by the broadcaster said the corporation's economics reporting is guilty of 'uninformed groupthink' and dominated too much by the Westminster version of events.

## Republicans demand Biden crack down on Turkey over $500,000 bounty on NBA star Enes Kanter Freedom
 - [https://www.dailymail.co.uk/news/article-11692363/Republicans-demand-Biden-crack-Turkey-500-000-bounty-NBA-star-Enes-Kanter-Freedom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692363/Republicans-demand-Biden-crack-Turkey-500-000-bounty-NBA-star-Enes-Kanter-Freedom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:48:32+00:00
 - user: None

More than 40 House Republicans are demanding that Biden examine whether sanctions are in order against Turkish officials responsible for the bounty on Enes Kanter Freedom

## Black PE teacher who was sacked on 'first day of Black History Month' sues school
 - [https://www.dailymail.co.uk/news/article-11693127/Black-PE-teacher-sacked-day-Black-History-Month-sues-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693127/Black-PE-teacher-sacked-day-Black-History-Month-sues-school.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:40:17+00:00
 - user: None

Louise Lewis, 40, was suspended as a PE teacher at North Huddersfield Trust School and is suing the school for racial discrimination and unfair dismissal after being forced out of her job.

## Serving Dorset Police officer, 46, charged with two counts of rape and six other sexual offences
 - [https://www.dailymail.co.uk/news/article-11693155/Serving-Dorset-Police-officer-46-charged-two-counts-rape-six-sexual-offences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693155/Serving-Dorset-Police-officer-46-charged-two-counts-rape-six-sexual-offences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:33:51+00:00
 - user: None

Dorset Police Constable Ravi Canhye is alleged to have committed eight sexual offences against two women, including two charges of rape, while off duty in early 2022.

## Firefighters and control room staff have voted for a nationwide strike over pay
 - [https://www.dailymail.co.uk/news/article-11692975/Firefighters-control-room-staff-voted-nationwide-strike-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692975/Firefighters-control-room-staff-voted-nationwide-strike-pay.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:12:36+00:00
 - user: None

Members of the Fire Brigades Union backed walkouts by 88 per cent on a 73 per cent turnout today after rejecting a below-inflation five per cent pay offer in November last year.

## Florida lawmakers unveil new legislation for gun holders to carry weapons WITHOUT a permit in public
 - [https://www.dailymail.co.uk/news/article-11693001/Florida-lawmakers-unveil-new-legislation-gun-holders-carry-weapons-WITHOUT-permit-public.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11693001/Florida-lawmakers-unveil-new-legislation-gun-holders-carry-weapons-WITHOUT-permit-public.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:11:37+00:00
 - user: None

Floridan's currently don't need permits to buy guns, but do for public carrying. The bill could as early as this coming March in Florida's Republican led house.

## Tim Allen hits back at Pamela Anderson's claim he flashed her
 - [https://www.dailymail.co.uk/news/article-11692459/Tim-Allen-hits-Pamela-Andersons-claim-flashed-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692459/Tim-Allen-hits-Pamela-Andersons-claim-flashed-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:08:45+00:00
 - user: None

Pamela Anderson claims in her upcoming memoir Love, Pamela that Tim Allen flashed her on the set of ABC sitcom Home Improvement in 1991.

## Heart-stopping moment cops pull suspect from car overturned on railway tracks
 - [https://www.dailymail.co.uk/news/article-11692803/Heart-stopping-moment-cops-pull-suspect-car-overturned-railway-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692803/Heart-stopping-moment-cops-pull-suspect-car-overturned-railway-tracks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:07:32+00:00
 - user: None

A 29-year-old man has been saved from getting hit by an oncoming train after he stole a cop car and crashed it onto a railway track in southwest Atlanta.

## St Pancras flat goes on sale for hits the market for £10million
 - [https://www.dailymail.co.uk/news/article-11692997/St-Pancras-flat-goes-sale-hits-market-10million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692997/St-Pancras-flat-goes-sale-hits-market-10million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:03:02+00:00
 - user: None

A gothic flat that sits above St Pancras International Station, London, is on sale with a reduced price tag of £1.5million after it failed to sell two years ago.

## Polish tourist sparking fury by climbing the steps of a Mayan temple in Mexico
 - [https://www.dailymail.co.uk/news/article-11692647/Polish-tourist-sparking-fury-climbing-steps-Mayan-temple-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692647/Polish-tourist-sparking-fury-climbing-steps-Mayan-temple-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 17:02:18+00:00
 - user: None

This is the moment a Polish tourist is whacked over the head with a large wooden stick after sparking fury by climbing the steps of an ancient N temple in Mexico.

## Uber driver who stole £3,000 pet macaw from Richmond Park then released it into the wild avoids jail
 - [https://www.dailymail.co.uk/news/article-11692787/Uber-driver-stole-3-000-pet-macaw-Richmond-Park-released-wild-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692787/Uber-driver-stole-3-000-pet-macaw-Richmond-Park-released-wild-avoids-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:59:54+00:00
 - user: None

Sattar Abdul, 44, attracted Sura the macaw into his car and made an unsuccessful bid to also grab another bird before making off from the south west London park.

## Aspiring female performers must AUDITION to get a room in subsidized Manhattan complex
 - [https://www.dailymail.co.uk/news/article-11692491/Aspiring-female-performers-AUDITION-room-subsidized-Manhattan-complex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692491/Aspiring-female-performers-AUDITION-room-subsidized-Manhattan-complex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:57:40+00:00
 - user: None

The Rehearsal Club has re-opened in an apartment complex in Manhattan. Residents audition for spots in the apartments and pay $1,000 per month.

## Doctor accused of trying to kill his wife and children by driving Tesla off a cliff booked into jail
 - [https://www.dailymail.co.uk/news/article-11692751/Doctor-accused-trying-kill-wife-children-driving-Tesla-cliff-booked-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692751/Doctor-accused-trying-kill-wife-children-driving-Tesla-cliff-booked-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:57:03+00:00
 - user: None

The Pasadena doctor charged with the attempted murder of his wife and their two young children by intentionally driving their Tesla off a 250ft cliff is behind bars.

## Woman, 31, dies in hospital after 'spending 12 hours in A&E corridor' as her family slam hospital
 - [https://www.dailymail.co.uk/news/article-11692983/Woman-31-dies-hospital-spending-12-hours-E-corridor-family-slam-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692983/Woman-31-dies-hospital-spending-12-hours-E-corridor-family-slam-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:55:52+00:00
 - user: None

Tamara Davis, 31, was admitted to the Royal Sussex County Hospital in Brighton on January 10 with a severe chest infection after coughing up blood at home.

## Moment Polish tourist is beaten after he scaled ancient Mayan temple in Mexico
 - [https://www.dailymail.co.uk/news/article-11692697/Moment-Polish-tourist-beaten-scaled-ancient-Mayan-temple-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692697/Moment-Polish-tourist-beaten-scaled-ancient-Mayan-temple-Mexico.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:53:59+00:00
 - user: None

Pawel Tomasz, of Poland, was arrested for trekking up the Temple of Kukulcán in Yucatán, Mexico, on Saturday. He was fined about $263 and forced to deleted photos he took to post on social media.

## Father who 'shook his nine-week-old son to death after becoming angry with crying' guilty of murder
 - [https://www.dailymail.co.uk/news/article-11692905/Father-shook-nine-week-old-son-death-angry-crying-guilty-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692905/Father-shook-nine-week-old-son-death-angry-crying-guilty-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:33:38+00:00
 - user: None

WARNING DISTRESSING CONTENT A Sheffield father has been found guilty of murdering his nine-week-old baby via a severe brain injury because he was 'angry with his crying'

## Eco warrior King Charles took two 112-mile helicopter trips in 24 hours
 - [https://www.dailymail.co.uk/news/article-11692483/Eco-warrior-King-Charles-took-two-112-mile-helicopter-trips-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692483/Eco-warrior-King-Charles-took-two-112-mile-helicopter-trips-24-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:29:21+00:00
 - user: None

King Charles took two helicopter trips in 24 hours to open the new Africa Centre in London where he discussed the effects of climate change.

## UK judge says dropping F-bomb at work has lost its 'shock value'
 - [https://www.dailymail.co.uk/news/article-11692695/UK-judge-says-dropping-F-bomb-work-lost-shock-value.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692695/UK-judge-says-dropping-F-bomb-work-lost-shock-value.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:17:03+00:00
 - user: None

Phrases like 'I don't give a f***' are now 'fairly commonplace' at work and have 'lost all their significance', employment Judge Andrew Gumbiti-Zimuto has ruled during a tribunal in Reading.

## Tyre Nichols' family accepts invitation to attend Biden's State of the Union
 - [https://www.dailymail.co.uk/news/article-11692627/Tyre-Nichols-family-accepts-invitation-attend-Bidens-State-Union.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692627/Tyre-Nichols-family-accepts-invitation-attend-Bidens-State-Union.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:14:22+00:00
 - user: None

The parents of Tyre Nichols have accepted an invitation to attend President Biden's State of the Union address next Tuesday.

## Marilyn Manson sued for sexual assault of underage girl
 - [https://www.dailymail.co.uk/news/article-11692777/New-lawsuit-claims-Marilyn-Manson-groomed-underage-girl-multiple-times-early-1990s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692777/New-lawsuit-claims-Marilyn-Manson-groomed-underage-girl-multiple-times-early-1990s.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:13:23+00:00
 - user: None

Marilyn Manson is being sued for allegedly grooming and assaulting an underage girl multiple times in the 1990s, according to a new lawsuit.

## Girl, five, cheats death when drink-driver crashes into her and knocks her through a window
 - [https://www.dailymail.co.uk/news/article-11692667/Girl-five-cheats-death-drink-driver-crashes-knocks-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692667/Girl-five-cheats-death-drink-driver-crashes-knocks-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:13:08+00:00
 - user: None

The car bulldozed through a motorcycle stood outside the office - knocking down its 60-year-old owner - and rammed head-on into the potted plant, blasting it and the young girl through the glass window

## Missing Maryland woman, 20, is found dead in park after cops are called to 'suspicious situation'
 - [https://www.dailymail.co.uk/news/article-11692391/Missing-Maryland-woman-20-dead-park-cops-called-suspicious-situation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692391/Missing-Maryland-woman-20-dead-park-cops-called-suspicious-situation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:12:52+00:00
 - user: None

Police have launched a murder probe into the death of a Maryland woman, 20, who went missing close to a month ago after finding her lifeless body in a park at the weekend.

## AIDS researcher is forced to pay back $375k of grant money
 - [https://www.dailymail.co.uk/news/article-11692471/AIDS-researcher-forced-pay-375k-grant-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692471/AIDS-researcher-forced-pay-375k-grant-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:11:00+00:00
 - user: None

Jeffrey Parsons-Hietikko, left, is required to pay the federal government back $375,000 after he used grant money to fund luxury scuba diving trips and other expenses.

## Woman whose 'mummified' body lay undiscovered for four years could have starved
 - [https://www.dailymail.co.uk/news/article-11692883/Woman-mummified-body-lay-undiscovered-four-years-starved.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692883/Woman-mummified-body-lay-undiscovered-four-years-starved.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:08:18+00:00
 - user: None

Laura Winham was found in a 'mummified' state at her home in Woking, Surrey, along with her 2017 calendar on which she had scrawled 'I need help'.

## Ted Cruz calls it 'critical for the FBI to search Hunter Biden's homes'
 - [https://www.dailymail.co.uk/news/article-11692631/Ted-Cruz-calls-critical-FBI-search-Hunter-Bidens-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692631/Ted-Cruz-calls-critical-FBI-search-Hunter-Bidens-homes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:05:36+00:00
 - user: None

Texas Sen. Ted Cruz says Hunter Biden's properties should be searched for classified material, citing his potential home office at his father's Wilmington home and an email about Ukraine.

## Huge crack emerges in cliff on the Jurassic Coast as experts warn it could collapse 'at any moment'
 - [https://www.dailymail.co.uk/news/article-11692811/Huge-crack-emerges-cliff-Jurassic-Coast-experts-warn-collapse-moment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692811/Huge-crack-emerges-cliff-Jurassic-Coast-experts-warn-collapse-moment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:05:06+00:00
 - user: None

The 60ft-wide section of the 600ft-cliff at Seatown, Dorset, has sunk by 3ft and is in the process of splitting away from the mainland.

## Nicola Sturgeon flounders in TV grilling on trans policy for prisons
 - [https://www.dailymail.co.uk/news/article-11692575/Nicola-Sturgeon-flounders-TV-grilling-trans-policy-prisons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692575/Nicola-Sturgeon-flounders-TV-grilling-trans-policy-prisons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 16:03:41+00:00
 - user: None

Nicola Sturgeon struggled as she tried to explain her policy during an ITV interview - admitting that trans women will be treated differently to born women.

## Biden and Schumer take debt limit fight to Kevin McCarthy
 - [https://www.dailymail.co.uk/news/article-11692517/Biden-Schumer-debt-limit-fight-Kevin-McCarthy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692517/Biden-Schumer-debt-limit-fight-Kevin-McCarthy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:57:01+00:00
 - user: None

The White House and Senate Democratic Leader Chuck Schumer attacked Speaker Kevin McCarthy ahead of this week's negotiations to raise the debt ceiling as talks remain at an impasse.

## Prince Andrew accuser Virginia Giuffre seen for first time in a year while out shopping in Australia
 - [https://www.dailymail.co.uk/news/article-11692701/Prince-Andrew-accuser-Virginia-Giuffre-seen-time-year-shopping-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692701/Prince-Andrew-accuser-Virginia-Giuffre-seen-time-year-shopping-Australia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:48:40+00:00
 - user: None

The 39-year-old, who received an out-of-court settlement of £12million from the Duke of York last year, visited a mall in the suburbs of Perth with her service dog.

## Entrepreneur who helped turn Airfix into global hit dies aged 97
 - [https://www.dailymail.co.uk/news/article-11692211/Entrepreneur-helped-turn-Airfix-global-hit-dies-aged-97.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692211/Entrepreneur-helped-turn-Airfix-global-hit-dies-aged-97.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:46:47+00:00
 - user: None

Ralph Ehrmann, who died earlier this month, was the firm's boss from the late 1950s until the 1970s, after training as a navigator in the Royal Air Force during the Second World War.

## Senator Lidia Thorpe slaps down Indigenous Voice to Parliament vote on ABC Q&A
 - [https://www.dailymail.co.uk/news/article-11692321/Senator-Lidia-Thorpe-slaps-Indigenous-Voice-Parliament-vote-ABC-Q-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692321/Senator-Lidia-Thorpe-slaps-Indigenous-Voice-Parliament-vote-ABC-Q-A.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:43:04+00:00
 - user: None

The outspoken Indigenous Senator told ABC's Q&amp;A on Monday 'black fellas' have no interest in being enshrined in the the constitution or playing a toothless advisory role to government.

## Brother of pregnant woman, 23, killed in Staten Island crash pays tribute to the 'perfect' mom-to-be
 - [https://www.dailymail.co.uk/news/article-11692393/Brother-pregnant-woman-23-killed-Staten-Island-crash-pays-tribute-perfect-mom-be.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692393/Brother-pregnant-woman-23-killed-Staten-Island-crash-pays-tribute-perfect-mom-be.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:42:36+00:00
 - user: None

The brother of a pregnant 23-year-old who died in a high sped car crash in Staten Island has spoken of his sister's excitement over her expected baby.

## 'I'm not rude - I'm just French': Bond girl Eva Green insists
 - [https://www.dailymail.co.uk/news/article-11692689/Im-not-rude-Im-just-French-Bond-girl-Eva-Green-insists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692689/Im-not-rude-Im-just-French-Bond-girl-Eva-Green-insists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:41:13+00:00
 - user: None

The former Bond girl is giving evidence in a £4million legal battle over A Patriot - a film she was set to star in before production was shut down in October 2019.

## Qantas leaves Aussie mum with two kids stranded in Paris for two weeks after ticket error
 - [https://www.dailymail.co.uk/news/article-11691239/Qantas-leaves-Aussie-mum-two-kids-stranded-Paris-two-weeks-ticket-error.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691239/Qantas-leaves-Aussie-mum-two-kids-stranded-Paris-two-weeks-ticket-error.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:40:05+00:00
 - user: None

Brisbane mum Tarnya Allen and her two kids checked in at Paris to fly home on January 8 only to find Qantas had not issued a ticket for her youngest. She's fuming at their treatment.

## Newborn baby girl with umbilical cord still attached is abandoned outside Florida trailer park
 - [https://www.dailymail.co.uk/news/article-11692415/Newborn-baby-girl-umbilical-cord-attached-abandoned-outside-Florida-trailer-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692415/Newborn-baby-girl-umbilical-cord-attached-abandoned-outside-Florida-trailer-park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:26:44+00:00
 - user: None

Magdalena Gregorio Ordonez (top right) found the newborn baby with her 12-year-old daughter (bottom right) after she was left for dead near their trailer park home just an hour after being born.

## 'How Tyre Nichols should be remembered': Skateboarding video posted by friends
 - [https://www.dailymail.co.uk/news/article-11692445/This-remembered-Two-minute-video-Tyre-Nichols-skateboarding-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692445/This-remembered-Two-minute-video-Tyre-Nichols-skateboarding-goes-viral.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:11:44+00:00
 - user: None

Friends of Tyre Nichols (inset) have released a moving video clip of him skateboarding as they insisted he should be remembered 'living his best life' not for bodycam footage showing his death.

## Mother, 62, was discovered 'secreted' in a hole on a coastal path where she took her own life
 - [https://www.dailymail.co.uk/news/article-11692539/Mother-62-discovered-secreted-hole-coastal-path-took-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692539/Mother-62-discovered-secreted-hole-coastal-path-took-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:10:26+00:00
 - user: None

An anxious mother worried about the rising cost of living and energy prices took her own life on a beach in Cornwall after suffering feelings of 'hopelessness'.

## Memphis DA 'can't rule out' MORE charges against officers at the scene of Tyre Nichols beating
 - [https://www.dailymail.co.uk/news/article-11692549/Memphis-DA-rule-charges-against-officers-scene-Tyre-Nichols-beating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692549/Memphis-DA-rule-charges-against-officers-scene-Tyre-Nichols-beating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:09:52+00:00
 - user: None

The District Attorney for Memphis has said they cannot rule out filing more charges against officers at the scene of Tyre Nichols' brutal beating.

## 'It is bullsh**!' Mickey Rourke doubles down against Alec Baldwin's manslaughter charges
 - [https://www.dailymail.co.uk/news/article-11684075/It-bullsh-Mickey-Rourke-doubles-against-Alec-Baldwins-manslaughter-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11684075/It-bullsh-Mickey-Rourke-doubles-against-Alec-Baldwins-manslaughter-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:08:12+00:00
 - user: None

The 70-year-old actor defended Alec Baldwin after manslaughter charges were filed in the death of cinematographer Halyna Hutchins, 42.

## Trump ramps up war on 'Ron DeSanctimonious': Ex-President calls Florida governor a 'globalist'
 - [https://www.dailymail.co.uk/news/article-11692451/donald-trump-ron-desantis-globalist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692451/donald-trump-ron-desantis-globalist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 15:06:43+00:00
 - user: None

Trump first wheeled out his 'Ron DeSanctimonious' line during a rally in Pennsylvania just three days before the midterm elections - and was promptly criticized by top Republicans.

## Ex-Countdown host Carole Vorderman hailed for surprise campaign against 'Tory sleaze'
 - [https://www.dailymail.co.uk/news/article-11692375/Ex-Countdown-host-Carole-Vorderman-hailed-surprise-campaign-against-Tory-sleaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692375/Ex-Countdown-host-Carole-Vorderman-hailed-surprise-campaign-against-Tory-sleaze.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:57:53+00:00
 - user: None

Many social media users have expressed their joy - and some bemusement - at how the 62-year-old has turned into a 'fearless' political campaigner.

## Fans leap to Sam Smith's defence after I'm Not Here to Make Friends sparks outrage
 - [https://www.dailymail.co.uk/news/article-11692373/Fans-leap-Sam-Smiths-defence-Im-Not-Make-Friends-sparks-outrage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692373/Fans-leap-Sam-Smiths-defence-Im-Not-Make-Friends-sparks-outrage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:53:59+00:00
 - user: None

Fans have pointed to how similarly risqué videos have been released by global artists in the past including Frankie Goes to Hollywood, Madonna, Rihanna, Queen and Miley Cyrus

## Labour bids to wreck 'minimum service' law for strikes
 - [https://www.dailymail.co.uk/news/article-11692497/Labour-bids-wreck-minimum-service-law-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692497/Labour-bids-wreck-minimum-service-law-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:52:49+00:00
 - user: None

With more industrial action set to cripple the country this week, Downing Street insisted talks were the right way for rail, NHS and teaching unions to resolve disputes.

## Website mum-of-five, 43, used to 'order a £20,000 hitman to murder an ex-colleague' had price list
 - [https://www.dailymail.co.uk/news/article-11692447/Website-mum-five-43-used-order-20-000-hitman-murder-ex-colleague-price-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692447/Website-mum-five-43-used-order-20-000-hitman-murder-ex-colleague-price-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:45:24+00:00
 - user: None

Helen Hewlett, 43, from King's Lynn, Norfolk, is on trial this week charged with soliciting murder and stalking Paul Belton, 50, between January 2021 and August 2022.

## Which schools will close due to teachers strikes?
 - [https://www.dailymail.co.uk/news/article-11691949/Which-schools-close-teachers-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691949/Which-schools-close-teachers-strikes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:40:59+00:00
 - user: None

Members of the National Education Union (NEU) are set to go on strike on Wednesday, February 1, as part of their ongoing dispute with the Government over pay.

## Thousands of drug-driving prosecutions could be thrown out over 'incorrect' laboratory results
 - [https://www.dailymail.co.uk/news/article-11692323/Thousands-drug-driving-prosecutions-thrown-incorrect-laboratory-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692323/Thousands-drug-driving-prosecutions-thrown-incorrect-laboratory-results.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:40:51+00:00
 - user: None

Issues were uncovered with thousands of drug-driving tests carried out by Synlab Laboratory Services Limited between April 2019 and December 2020.

## Murdaugh trial Day Six: Alex hides handcuffs under his blazer
 - [https://www.dailymail.co.uk/news/article-11692383/Murdaugh-trial-Day-Six-Alex-hides-handcuffs-blazer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692383/Murdaugh-trial-Day-Six-Alex-hides-handcuffs-blazer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:13:18+00:00
 - user: None

Defense attorney Dick Harpootlian will launch his cross-examination of a forensic scientist who found Murdaugh's wife and son lying in pools of blood at the family's estate in Islandton, South Carolina.

## Major insurers refuse to cover some Kia and Hyundai cars over major security flaw
 - [https://www.dailymail.co.uk/news/article-11692273/Major-insurers-refuse-cover-Kia-Hyundai-cars-major-security-flaw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692273/Major-insurers-refuse-cover-Kia-Hyundai-cars-major-security-flaw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:12:57+00:00
 - user: None

Insurance companies are refusing to cover some Kia and Hyundai models after an 'explosive increase' in thefts linked to a TikTok challenge that exploits a major security flaw.

## Welsh rugby legend Gareth Thomas agrees £75,000 settlement in HIV legal battle with ex
 - [https://www.dailymail.co.uk/news/article-11692507/Welsh-rugby-legend-Gareth-Thomas-agrees-75-000-settlement-HIV-legal-battle-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692507/Welsh-rugby-legend-Gareth-Thomas-agrees-75-000-settlement-HIV-legal-battle-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:12:27+00:00
 - user: None

The former Wales captain said he had made the decision 'for my own mental health and that of my family' - insisting that the move was 'not an admission of guilt'.

## Moment bridge collapses sending two demolition vehicles crashing to the ground
 - [https://www.dailymail.co.uk/news/article-11692417/Moment-bridge-collapses-sending-two-demolition-vehicles-crashing-ground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692417/Moment-bridge-collapses-sending-two-demolition-vehicles-crashing-ground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:11:19+00:00
 - user: None

The bridge collapsed while four yellow CAT machines were drilling into the foundations to break away the middle section during a demolition in Israel.

## Family whose £100,000 Bentley was stolen slam the Met police
 - [https://www.dailymail.co.uk/news/article-11692337/Family-100-000-Bentley-stolen-slam-Met-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692337/Family-100-000-Bentley-stolen-slam-Met-police.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:10:26+00:00
 - user: None

Shocked Anwar Patel, 40, told how he and his family collected a raft of video clips from multiple sources after their beloved car was stolen from a street in East Ham, east London.

## Goldman Sachs restructures asset in Russia - after vowing to pull out of the country 10 months ago
 - [https://www.dailymail.co.uk/news/article-11692421/Goldman-Sachs-restructures-asset-Russia-vowing-pull-country-10-months-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692421/Goldman-Sachs-restructures-asset-Russia-vowing-pull-country-10-months-ago.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:07:55+00:00
 - user: None

The RBC daily reported the news on Monday, citing two investment market sources, in a move is the most pronounced yet from the bank in distancing itself from the Putin-led nation.

## Alex Murdaugh murder trial live: Jury to hear first full week of testimony
 - [https://www.dailymail.co.uk/news/live/article-11692411/Alex-Murdaugh-murder-trial-live-Jury-hear-week-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11692411/Alex-Murdaugh-murder-trial-live-Jury-hear-week-testimony.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:07:51+00:00
 - user: None

DAILYMAIL.COM LIVE BLOG: Follow along as witnesses take the stand in South Carolina for Alex Murdaugh's double murder trial.

## Devastating photos of cobalt mines in Democratic Republic of Congo that power Apple, Tesla and more
 - [https://www.dailymail.co.uk/news/article-11668015/Devastating-photos-cobalt-mines-Democratic-Republic-Congo-power-Apple-Tesla-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11668015/Devastating-photos-cobalt-mines-Democratic-Republic-Congo-power-Apple-Tesla-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:07:49+00:00
 - user: None

A new series of images taken from inside cobalt mines in the Democratic Republic of Congo raise uncomfortable questions for American tech companies claiming to be 'clean'.

## Shamed reality star Stephen Bear's sentencing is delayed by a month for psychiatric report
 - [https://www.dailymail.co.uk/news/article-11692379/Shamed-reality-star-Stephen-Bears-sentencing-delayed-month-psychiatric-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692379/Shamed-reality-star-Stephen-Bears-sentencing-delayed-month-psychiatric-report.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:04:01+00:00
 - user: None

The former Ex on the Beach and Celebrity Big Brother star, 33, was found to have captured CCTV footage of the act in his back garden on August 2, 2020, and uploaded it online.

## Essex thug calls judge a 'mug' while streaming sentencing on Facebook live
 - [https://www.dailymail.co.uk/news/article-11692253/Essex-thug-calls-judge-mug-streaming-sentencing-Facebook-live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692253/Essex-thug-calls-judge-mug-streaming-sentencing-Facebook-live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 14:01:09+00:00
 - user: None

Mathers live-streamed his entire sentencing to Facebook from the moment he walked into the courtroom at Southend Magistrates' Court, Essex, on January 24 this year.

## Outraged property developer hit by £2,800 'empty home' tax bill
 - [https://www.dailymail.co.uk/news/article-11692307/Outraged-property-developer-hit-2-800-home-tax-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692307/Outraged-property-developer-hit-2-800-home-tax-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:59:35+00:00
 - user: None

Ray Plant snapped up the two-bed semi in Bradeley, near Stoke-on-Trent, for £100,000.was left dumbfounded after being hit by the shock council tax bill from Stoke-on-Trent City Council.

## Rishi Sunak's popularity nosedives among Tory members amid Zahawi tax row and economic problems
 - [https://www.dailymail.co.uk/news/article-11692499/Rishi-Sunaks-popularity-nosedives-Tory-members-amid-Zahawi-tax-row-economic-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692499/Rishi-Sunaks-popularity-nosedives-Tory-members-amid-Zahawi-tax-row-economic-problems.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:58:55+00:00
 - user: None

Backing for the Prime Minister among Conservative grassroots has fallen by three quarters in the wake of Nadhim Zahawi's tax revelations.

## Woman, 28, who was mauled to death by pack of eight dogs she was hired to walk is named
 - [https://www.dailymail.co.uk/news/article-11692443/Woman-28-mauled-death-pack-eight-dogs-hired-walk-named.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692443/Woman-28-mauled-death-pack-eight-dogs-hired-walk-named.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:55:27+00:00
 - user: None

Natasha Johnston died after a frenzied attack by the canines at the Gravelly Hill beauty spot in Caterham, Surrey, on January 12.

## Lisa Marie Presley was 'back on opioids and taking weight loss meds before Golden Globes'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11691767/Lisa-Marie-Presley-opioids-taking-weight-loss-meds-Golden-Globes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11691767/Lisa-Marie-Presley-opioids-taking-weight-loss-meds-Golden-Globes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:51:13+00:00
 - user: None

The star underwent plastic surgery two months before the Golden Globes and lost up to 50 pounds as part of a strict regimen, insiders told TMZ.

## Donna Nelson from Australia charged with importing 1.9kg of meth into Japan in 'love scam'
 - [https://www.dailymail.co.uk/news/article-11692215/Donna-Nelson-Australia-charged-importing-1-9kg-meth-Japan-love-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692215/Donna-Nelson-Australia-charged-importing-1-9kg-meth-Japan-love-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:47:53+00:00
 - user: None

A prominent Indigenous woman from WA allegedly carried a suitcase containing 1.9kg of illegal stimulants through airports in three countries before being arrested in Japan, court documents allege.

## Military wife ordered her senior Army husband to punch a colleague in the face
 - [https://www.dailymail.co.uk/news/article-11692053/Military-wife-ordered-senior-Army-husband-punch-colleague-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692053/Military-wife-ordered-senior-Army-husband-punch-colleague-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:44:04+00:00
 - user: None

Staff Sergeant Gareth Porch (pictured), 42, punched Warrant Officer Michael Gilroy in the face during a 'disgraceful' episode of 'unwanted violence' at an RAF base in Limassol, Cyprus.

## Backlash over NHS's 5-step recovery blueprint to avert another devastating winter crisis
 - [https://www.dailymail.co.uk/health/article-11691831/Backlash-NHSs-5-step-recovery-blueprint-avert-devastating-winter-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11691831/Backlash-NHSs-5-step-recovery-blueprint-avert-devastating-winter-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:38:47+00:00
 - user: None

The blueprint, backed by the Prime Minister, is expected to ease pressure on the NHS in England and avert another winter crisis by boosting capacity, hiring more medics and speeding up discharges.

## Harry and Meghan face questions over remaining Archewell Foundation's remaining $10m charity money
 - [https://www.dailymail.co.uk/news/article-11691901/Harry-Meghan-face-questions-remaining-Archewell-Foundations-remaining-10m-charity-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691901/Harry-Meghan-face-questions-remaining-Archewell-Foundations-remaining-10m-charity-money.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:33:44+00:00
 - user: None

The Archewell Foundation has raised $13million since its formation after Megxit in 2020, giving away $3million in grants, it has emerged.

## Nelson the seal who chomped through £4k worth of fish stocks in Essex dies after rescue attempt
 - [https://www.dailymail.co.uk/news/article-11692291/Nelson-seal-chomped-4k-worth-fish-stocks-Essex-dies-rescue-attempt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692291/Nelson-seal-chomped-4k-worth-fish-stocks-Essex-dies-rescue-attempt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:30:09+00:00
 - user: None

A plucky seal who set up camp in an Essex angling lake and munched through £4k worth of stock has sadly died after being tranquilised in a rescue attempt.

## Officers gave terrified Tyre Nichols 71 swift and contradictory commands in just 13 minutes
 - [https://www.dailymail.co.uk/news/article-11692205/Officers-gave-terrified-Tyre-Nichols-71-swift-contradictory-commands-just-13-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692205/Officers-gave-terrified-Tyre-Nichols-71-swift-contradictory-commands-just-13-minutes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:27:14+00:00
 - user: None

The 29-year-old was savagely beaten earlier this month by the Memphis, Tennessee, cops and died days later from his horrific injuries.

## Multi-millionaire successfully appeals road ban as judge cites 'important security and safety' fears
 - [https://www.dailymail.co.uk/news/article-11692217/Multi-millionaire-successfully-appeals-road-ban-judge-cites-important-security-safety-fears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692217/Multi-millionaire-successfully-appeals-road-ban-judge-cites-important-security-safety-fears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:24:25+00:00
 - user: None

Shelim Hussain, said to be worth £80m, was ordered to stay off the road for six months by magistrates for speeding in South Wales, but paid for a top barrister to take his case to a crown court judge.

## Emily Atack details vile campaign of online sexual harassment and impact on her on BBC Breakfast
 - [https://www.dailymail.co.uk/tvshowbiz/article-11691837/Emily-Atack-shows-sense-style-patterned-dress-details-online-sexual-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11691837/Emily-Atack-shows-sense-style-patterned-dress-details-online-sexual-harassment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:22:36+00:00
 - user: None

The actress, 33, appeared on the show to talk about her upcoming BBC documentary Emily Atack: Asking For It?

## NYC mayor to require all city staff to go through CRT-style training to address unconscious bias
 - [https://www.dailymail.co.uk/news/article-11692203/NYC-mayor-require-city-staff-CRT-style-training-address-unconscious-bias.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692203/NYC-mayor-require-city-staff-CRT-style-training-address-unconscious-bias.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:11:28+00:00
 - user: None

New York City employees will reportedly be required to undergo mandatory Critical Race Training-type training to address racial equality and unconscious bias in the workplace

## Melanotan beauty product dubbed the 'Barbie drug' sparks urgent health warnings
 - [https://www.dailymail.co.uk/news/article-11691931/Melanotan-beauty-product-dubbed-Barbie-drug-sparks-urgent-health-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691931/Melanotan-beauty-product-dubbed-Barbie-drug-sparks-urgent-health-warnings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:10:52+00:00
 - user: None

The drug is a synthetic version of a Melanocyte-stimulating-hormone (-MSH), and works by 'hacking' the body's regulation of pigment cells.

## Pro US skier Kyle Smaine reportedly killed in an avalanche in Japan
 - [https://www.dailymail.co.uk/news/article-11691557/Pro-skier-Kyle-Smaine-reportedly-killed-avalanche-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691557/Pro-skier-Kyle-Smaine-reportedly-killed-avalanche-Japan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:10:38+00:00
 - user: None

Two men were found dead among five swept up in an avalanche on the eastern slopes of Mount Habuka Norikura in central Japan.

## South African police arrest teacher accused of preying on boys at schools in Scotland
 - [https://www.dailymail.co.uk/news/article-11692275/South-African-police-arrest-teacher-accused-preying-boys-schools-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692275/South-African-police-arrest-teacher-accused-preying-boys-schools-Scotland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:04:25+00:00
 - user: None

The 83-year-old, dubbed 'Jimmy Savile Mark II', is accused of crimes against boys at Edinburgh Academy and Fettes College (pictured)- the alma mater of ex-PM Tony Blair - in the 1970s

## Paul Burrell, 64, confirms 'lifechanging' cancer diagnosis
 - [https://www.dailymail.co.uk/tvshowbiz/article-11691697/Paul-Burrell-64-confirms-lifechanging-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11691697/Paul-Burrell-64-confirms-lifechanging-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:04:13+00:00
 - user: None

The late Diana, Princess of Wales' former butler confirmed the news during an appearance on Monday's edition of Lorraine.

## Richard Madeley apologises for misgendering non-binary Sam Smith
 - [https://www.dailymail.co.uk/tvshowbiz/article-11691695/Richard-Madeley-apologises-misgendering-non-binary-Sam-Smith.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11691695/Richard-Madeley-apologises-misgendering-non-binary-Sam-Smith.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:03:51+00:00
 - user: None

Good Morning Britain presenter Richard Madeley apologised for misgendering Sam Smith on Monday morning's show.

## Q&A and full list of school closures in England and Wales due to teachers strike
 - [https://www.dailymail.co.uk/news/article-11691949/Q-list-school-closures-England-Wales-teachers-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691949/Q-list-school-closures-England-Wales-teachers-strike.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 13:01:01+00:00
 - user: None

Members of the National Education Union (NEU) are set to go on strike on Wednesday, February 1, as part of their ongoing dispute with the Government over pay.

## Economics graduate moves to Thailand after making £3.6million playing poker
 - [https://www.dailymail.co.uk/news/article-11691771/Economics-graduate-moves-Thailand-making-3-6million-playing-poker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691771/Economics-graduate-moves-Thailand-making-3-6million-playing-poker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:58:50+00:00
 - user: None

Richard Sheils moved to the sun-kissed country from Birmingham after building a $4.5million (£3.6m) fortune competing in online tournaments.

## Top psychotherapist reveals 9 tips for parenting the Danish way
 - [https://www.dailymail.co.uk/femail/parenting/article-11683621/Top-psychotherapist-reveals-9-tips-parenting-Danish-way.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/parenting/article-11683621/Top-psychotherapist-reveals-9-tips-parenting-Danish-way.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:55:50+00:00
 - user: None

Writing in her new book, The Danish Way of Raising Teens, psychotherapist and author Iben Sandahl, of Copenhagen, reveals her top tips for making happy teens with character.

## Fury as London School of Economics cancels Christian term names
 - [https://www.dailymail.co.uk/news/article-11692031/Fury-London-School-Economics-cancels-Christian-term-names.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692031/Fury-London-School-Economics-cancels-Christian-term-names.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:44:21+00:00
 - user: None

The institution, which is popular with overseas students, says it has changing the names to 'better reflect the international nature of our community'.

## Watch as jealous pensioner, 75, takes revenge on neighbour by keying their £60,000 Lexus
 - [https://www.dailymail.co.uk/news/article-11691937/Watch-jealous-pensioner-75-takes-revenge-neighbour-keying-60-000-Lexus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691937/Watch-jealous-pensioner-75-takes-revenge-neighbour-keying-60-000-Lexus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:43:08+00:00
 - user: None

Keith Ardley, 75, was said to have been jealous of Marius Crisan's brand new Lexus car and damaged it out of spite. Magistrates found Ardley guilty after seeing the video footage.

## Rehab facility uses groundbreaking treatment to help patients
 - [https://www.dailymail.co.uk/news/article-11678885/Rehab-facility-uses-groundbreaking-treatment-help-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678885/Rehab-facility-uses-groundbreaking-treatment-help-patients.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:36:58+00:00
 - user: None

A treatment centre in San Diego, California is working to change the scenario for patients suffering from mental health conditions and substance abuse.

## Emily Atack's mother breaks down in tears as she reads 'vile' messages men have sent her daughter
 - [https://www.dailymail.co.uk/femail/article-11671051/Emily-Atacks-mother-breaks-tears-reads-vile-messages-men-sent-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11671051/Emily-Atacks-mother-breaks-tears-reads-vile-messages-men-sent-daughter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:31:41+00:00
 - user: None

In her new BBC documentary Emily Atack: Asking for It? , the comedian, 32, visited her mother's home in Bedfordshire to discuss her campaign against social media abuse.

## Airport chef who sued his employer for £2.2 million after a work accident has his claim thrown out
 - [https://www.dailymail.co.uk/news/article-11692015/Airport-chef-sued-employer-2-2-million-work-accident-claim-thrown-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692015/Airport-chef-sued-employer-2-2-million-work-accident-claim-thrown-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:13:01+00:00
 - user: None

Ferenc Sumegi, 49, strained his back lifting a fish tray at Heathrow and said the 'unbearable' ongoing pain meant he had to use a stick or crutches to walk.

## Love Actually fans plague London street made famous by movie
 - [https://www.dailymail.co.uk/news/article-11691785/Love-Actually-fans-plague-London-street-famous-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691785/Love-Actually-fans-plague-London-street-famous-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:12:39+00:00
 - user: None

St Luke's Mews, in Notting Hill, London, is plagued by hundreds of fans of the 2003 romantic comedy every week, who flock from across the globe to pose for photos outside a pink house featured in film.

## Bond girl Eva Green, 42, arrives at court for London legal battle
 - [https://www.dailymail.co.uk/news/article-11692009/Bond-girl-Eva-Green-42-arrives-court-London-legal-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692009/Bond-girl-Eva-Green-42-arrives-court-London-legal-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:12:25+00:00
 - user: None

The Casino Royale star, 42, had been set to star in A Patriot before production was shut down in October 2019.

## Teaching union barons holding schools to ransom over pay rake in near £260,000 salary and benefits
 - [https://www.dailymail.co.uk/news/article-11691887/Teaching-union-barons-holding-schools-ransom-pay-rake-near-260-000-salary-benefits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691887/Teaching-union-barons-holding-schools-ransom-pay-rake-near-260-000-salary-benefits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:10:56+00:00
 - user: None

Two union barons holding Britain's schools to ransom over teachers' pay  rake in nearly £260,000 themselves in pay and benefits.

## Tim Burton applies to chop down and prune two trees at his London mansion
 - [https://www.dailymail.co.uk/news/article-11691999/Tim-Burton-applies-chop-prune-two-trees-London-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691999/Tim-Burton-applies-chop-prune-two-trees-London-mansion.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:08:13+00:00
 - user: None

The Edward Scissorhands director, 64, of Hampstead, London, is looking to chop down a weeping ash in his front garden and trim back an oak in his backyard.

## Tyre Nichols' GoFundMe page passes $1M two days after his mom set it up with moving tribute
 - [https://www.dailymail.co.uk/news/article-11691751/Tyre-Nichols-GoFundMe-page-passes-1M-two-days-mom-set-moving-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691751/Tyre-Nichols-GoFundMe-page-passes-1M-two-days-mom-set-moving-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:08:13+00:00
 - user: None

Tyre's mother RowVaughn Wells posted the GoFundMe with a moving tribute on Friday, and by Sunday, the figure had passed $1million.

## Selfridges Oxford Street employee mocks customers who flock to buy reduced jeans for £1
 - [https://www.dailymail.co.uk/news/article-11691643/Selfridges-Oxford-Street-employee-mocks-customers-flock-buy-reduced-jeans-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691643/Selfridges-Oxford-Street-employee-mocks-customers-flock-buy-reduced-jeans-1.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:07:59+00:00
 - user: None

Columba Ferguson, who works in the Women's section on the third floor of the exclusive Central London outlet, posted a video on her TikTok profile on Saturday.

## Millionaire, 70, who illegally built 'Britain's best man cave' faces jail AGAIN
 - [https://www.dailymail.co.uk/news/article-11691857/Millionaire-70-illegally-built-Britains-best-man-cave-faces-jail-AGAIN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691857/Millionaire-70-illegally-built-Britains-best-man-cave-faces-jail-AGAIN.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:06:55+00:00
 - user: None

Accountant Graham Wildin, 70, built the huge 10,000sqft extension to the rear of his home in Cirencester, Gloucestershire, in 2014 - without applying for planning permission.

## Andrew Tate gives Channel 4 'full access' to never-seen-before footage for new documentary
 - [https://www.dailymail.co.uk/news/article-11691835/Andrew-Tate-gives-Channel-4-access-never-seen-footage-new-documentary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691835/Andrew-Tate-gives-Channel-4-access-never-seen-footage-new-documentary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 12:00:25+00:00
 - user: None

The former kickboxing champion is in custody in Romania facing allegations of human trafficking and being part of a crime gang along with his brother Tristan.

## Average age of Christians has risen to 51, census figures show
 - [https://www.dailymail.co.uk/news/article-11691891/Average-age-Christians-risen-51-census-figures-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691891/Average-age-Christians-risen-51-census-figures-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:59:55+00:00
 - user: None

The average age of Christians has risen from 45 at the time of the last huge survey in England and Wales in 2011.

## Engineers still using dowsing rods to hunt for leaks despite being discredited by scientific studies
 - [https://www.dailymail.co.uk/news/article-11691399/Engineers-using-dowsing-rods-hunt-leaks-despite-discredited-scientific-studies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691399/Engineers-using-dowsing-rods-hunt-leaks-despite-discredited-scientific-studies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:58:07+00:00
 - user: None

The method, which dates back to the 16th century, involves someone holding two L-shaped or one Y-shaped rod in front of them, which is then said to twitch or cross if there is water underground.

## Ukraine accuses International Olympic Committee of being a 'promoter of war, murder and destruction'
 - [https://www.dailymail.co.uk/news/article-11692095/Ukraine-accuses-International-Olympic-Committee-promoter-war-murder-destruction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11692095/Ukraine-accuses-International-Olympic-Committee-promoter-war-murder-destruction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:54:54+00:00
 - user: None

Ukraine accused the IOC of offering Russia a 'platform to promote genocide' after the sports body said it was considering ways for Russians to compete in the 2024 Paris Games.

## Lung cancer symptoms: What are the warning signs?
 - [https://www.dailymail.co.uk/health/article-11691513/Lung-cancer-symptoms-warning-signs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11691513/Lung-cancer-symptoms-warning-signs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:52:40+00:00
 - user: None

It's one of the deadliest forms of cancer, killing tens of thousands in Britain and the US every year. And there are usually no noticeable symptoms of lung cancer until it is advanced.

## Police probing rapes in Reading launch public appeal for information after 'linking the attacks'
 - [https://www.dailymail.co.uk/news/article-11691939/Police-probing-rapes-Reading-launch-public-appeal-information-linking-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691939/Police-probing-rapes-Reading-launch-public-appeal-information-linking-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:31:33+00:00
 - user: None

Thames Valley Police confirmed that two separate rapes just three miles apart  in Reading, one on January 15, 2023 and the other on June 11, 2022, were linked to the same attacker.

## The world is 'dangerously unprepared' for the next pandemic, Red Cross warns
 - [https://www.dailymail.co.uk/news/article-11691985/The-world-dangerously-unprepared-pandemic-Red-Cross-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691985/The-world-dangerously-unprepared-pandemic-Red-Cross-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:25:27+00:00
 - user: None

Despite three years of  Covid, strong preparedness systems for future health crises are 'severely lacking', the Red Cross has warned today

## Russia accuse Boris Johnson of lying about Putin threatening to kill him
 - [https://www.dailymail.co.uk/news/article-11691863/Kremlin-accuse-Boris-Johnson-LYING-Putin-threatening-kill-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691863/Kremlin-accuse-Boris-Johnson-LYING-Putin-threatening-kill-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:12:31+00:00
 - user: None

Johnson, speaking to the BBC for a documentary (pictured), said the Russian leader had threatened him with a missile strike that would 'only take a minute' to kill him

## Bill Gates grilled over having dinner with Jeffrey Epstein in interview
 - [https://www.dailymail.co.uk/news/article-11691679/Bill-Gates-grilled-having-dinner-Jeffrey-Epstein-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691679/Bill-Gates-grilled-having-dinner-Jeffrey-Epstein-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:12:25+00:00
 - user: None

Gates, a philanthropist, who has given billions to charity, was grilled about his links to Epstein while in Australia to talk about global issues such climate change and artificial intelligence.

## Jeremy Clarkson says divide over Diddly Squat farm is between people with house number and name
 - [https://www.dailymail.co.uk/news/article-11691707/Jeremy-Clarkson-says-divide-Diddly-Squat-farm-people-house-number-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691707/Jeremy-Clarkson-says-divide-Diddly-Squat-farm-people-house-number-name.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:12:14+00:00
 - user: None

Broadcaster Jeremy Clarkson, 62, revealed a number of locals are still less than impressed with his foray into farming - but others support him bringing business to the area.

## At least 25 people are killed and 120 injured in suicide bomb attack on a mosque in Pakistan
 - [https://www.dailymail.co.uk/news/article-11691885/At-25-people-killed-120-injured-suicide-bomb-attack-mosque-Pakistan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691885/At-25-people-killed-120-injured-suicide-bomb-attack-mosque-Pakistan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:11:02+00:00
 - user: None

The bomber detonated his suicide vest as some 150 worshippers - including many policemen from nearby police offices - were praying inside.

## Prince Andrew is urged to challenge £12m settlement with sex abuse accuser
 - [https://www.dailymail.co.uk/news/article-11691349/Prince-Andrew-urged-challenge-12m-settlement-sex-abuse-accuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691349/Prince-Andrew-urged-challenge-12m-settlement-sex-abuse-accuser.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:09:08+00:00
 - user: None

Mr Dershowitz was sued by Ms Giuffre for calling her a liar over her claims that she had been forced to have sex with him, before she later admitted she 'may have made a mistake'.

## Sir Ian McKellen's pub sees hygiene rating drop by two stars after inspectors find out of date food
 - [https://www.dailymail.co.uk/news/article-11691813/Sir-Ian-McKellens-pub-sees-hygiene-rating-drop-two-stars-inspectors-date-food.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691813/Sir-Ian-McKellens-pub-sees-hygiene-rating-drop-two-stars-inspectors-date-food.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:03:58+00:00
 - user: None

The actor, 83, part-owns The Grapes in Limehouse, east London, which dates back nearly 500 years. But the pub has recently been rapped over a series of errors in the kitchen.

## Drunk Maserati Levante driver crashes his £70k supercar in Birmingham
 - [https://www.dailymail.co.uk/news/article-11691765/Drunk-Maserati-Levante-driver-crashes-70k-supercar-Birmingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691765/Drunk-Maserati-Levante-driver-crashes-70k-supercar-Birmingham.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:00:59+00:00
 - user: None

The sozzled motorist had been waiting at the junction of Bristol Street and Bristol Road in Birmingham when the crash happened in October last year.

## Business expert says bosses should give staff going through a marriage breakup more work
 - [https://www.dailymail.co.uk/news/article-11691705/Business-expert-says-bosses-staff-going-marriage-breakup-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691705/Business-expert-says-bosses-staff-going-marriage-breakup-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 11:00:16+00:00
 - user: None

The scheme, created by the Positive Parenting Alliance and backed by Tesco, Asda and Natwest, would change HR policies to state that separation akin to a family death.

## Hunt for the BBC food thief as staff reveal their lunch is being pinched
 - [https://www.dailymail.co.uk/news/article-11691601/Hunt-BBC-food-thief-staff-reveal-lunch-pinched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691601/Hunt-BBC-food-thief-staff-reveal-lunch-pinched.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:59:04+00:00
 - user: None

A mystery food thief is stalking the corridors of the BBC - with broadcasters and journalists repeatedly falling victim to the culinary crook.

## BA stewardess arrested after pilot calls police suspecting she's drunk and under influence of drugs
 - [https://www.dailymail.co.uk/news/article-11691757/BA-stewardess-arrested-pilot-calls-police-suspecting-shes-drunk-influence-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691757/BA-stewardess-arrested-pilot-calls-police-suspecting-shes-drunk-influence-drugs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:58:40+00:00
 - user: None

Officers from Sussex Police boarded the British Airways flight from Gran Canaria in the Canary Islands when it landed at Gatwick Airport on Thursday afternoon.

## Millions of families in leasehold homes set to get greater powers to buy them outright
 - [https://www.dailymail.co.uk/news/article-11691855/Millions-families-leasehold-homes-set-greater-powers-buy-outright.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691855/Millions-families-leasehold-homes-set-greater-powers-buy-outright.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:57:25+00:00
 - user: None

Michael Gove is today expected to outline plans to end the 'feudal' leasehold/freehold ownership system used on more than 4.5 million properties after branding it 'outdated'.

## What's next for Nadhim Zahawi following his political downfall?
 - [https://www.dailymail.co.uk/news/article-11691869/Whats-Nadhim-Zahawi-following-political-downfall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691869/Whats-Nadhim-Zahawi-following-political-downfall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:56:57+00:00
 - user: None

Nadhim Zahawi has previously described how, aged 11, he sat at the back of a classroom in the UK 'unable to speak a word of English'.

## 'Russia is on the verge of direct collision with US and NATO', Moscow warns
 - [https://www.dailymail.co.uk/news/article-11691713/Russia-verge-direct-collision-NATO-Moscow-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691713/Russia-verge-direct-collision-NATO-Moscow-warns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:48:45+00:00
 - user: None

Deputy Foreign Minister Sergei Ryabkov said Washington's decision to supply Kyiv with 31 of its M1 Abrams tanks was an 'extremely destructive step' which 'escalated' the war in Ukraine.

## Apprentice star's ice cream business is going under after struggling during Covid lockdowns
 - [https://www.dailymail.co.uk/news/article-11691521/Apprentice-stars-ice-cream-business-going-struggling-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691521/Apprentice-stars-ice-cream-business-going-struggling-Covid-lockdowns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:44:40+00:00
 - user: None

Mr Stevenson, who was a contestant on the show in 2015, set up Alaskan Ice five years ago, but there is now a proposal to strike the firm off, with no accounts formally filed since 2020.

## Police force faces backlash after officers seize a mother's e-scooter as she rode with her child
 - [https://www.dailymail.co.uk/news/article-11691783/Police-force-faces-backlash-officers-seize-mothers-e-scooter-rode-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691783/Police-force-faces-backlash-officers-seize-mothers-e-scooter-rode-child.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:40:04+00:00
 - user: None

Gloucestershire police has been branded 'pathetic' after posting a video showing officers seizing an E-scooter from a mother and 4-year-old child on their way to school

## Chester mother blames her 'period pain' after flying into a rage
 - [https://www.dailymail.co.uk/news/article-11691541/Chester-mother-blames-period-pain-flying-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691541/Chester-mother-blames-period-pain-flying-rage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:14:18+00:00
 - user: None

Sabrina Abdelkader, 33, of Chester, had a 'meltdown' over the accident, waking up Marisa Salvi with a Facetime call and raging: '"What the f*** have you done with my chair? - it's covered in paint".'

## Teachers' concern that OpenAi's ChatGPT is 'so powerful' it could end homework
 - [https://www.dailymail.co.uk/news/article-11691571/Teachers-concern-OpenAis-ChatGPT-powerful-end-homework.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691571/Teachers-concern-OpenAis-ChatGPT-powerful-end-homework.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:13:32+00:00
 - user: None

Staff at Alleyn's School in southeast London say they  are being forced to rethink their practises after a test English essay produced by AI bot ChatGPT was awarded an A* grade

## Sam Smith's 'raunchy' music video sparks controversy: Critics slam 'hyper-sexualised' dancing
 - [https://www.dailymail.co.uk/news/article-11691593/Sam-Smiths-raunchy-music-video-sparks-controversy-Critics-slam-hyper-sexualised-dancing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691593/Sam-Smiths-raunchy-music-video-sparks-controversy-Critics-slam-hyper-sexualised-dancing.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:13:06+00:00
 - user: None

The singer, 30, released the video for their track I'm Not Here To Make Friends, part of their new album Gloria, last week.

## Rescue centre's 'oldest ever' dogs with a combined age of 34 find their forever home
 - [https://www.dailymail.co.uk/news/article-11691487/Rescue-centres-oldest-dogs-combined-age-34-forever-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691487/Rescue-centres-oldest-dogs-combined-age-34-forever-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:12:39+00:00
 - user: None

Sheba and Teddy, both 17-year-old Collie crosses, were taken into the care of the Dogs Trust in Evesham, Worcestershire, after their owner passed away in November last year.

## James May brands Jeremy Clarkson's controversial Meghan Markle column as 'creepy'
 - [https://www.dailymail.co.uk/news/article-11691519/James-brands-Jeremy-Clarksons-controversial-Meghan-Markle-column-creepy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691519/James-brands-Jeremy-Clarksons-controversial-Meghan-Markle-column-creepy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:12:12+00:00
 - user: None

James May, who was invited to discuss his views on potential 20mph speed limits coming into force, was quizzed on his Grand Tour colleague's controversial column about Meghan Markle.

## Shocking moment breeder screams at airport staff after airline prevents him from seeing his dogs
 - [https://www.dailymail.co.uk/news/article-11691467/Shocking-moment-breeder-screams-airport-staff-airline-prevents-seeing-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691467/Shocking-moment-breeder-screams-airport-staff-airline-prevents-seeing-dogs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:06:28+00:00
 - user: None

Joao Paulo de Costa, a dog breeder from Criciuma, Brazil (pictured during meltdown), had travelled to the Philippines with five of his Papillon spaniels to participate in a canine beauty contest

## When Arnima Hayat's lover picked up the phone, he spat five menacing words
 - [https://www.dailymail.co.uk/news/article-11689029/When-Arnima-Hayats-lover-picked-phone-spat-five-menacing-words.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11689029/When-Arnima-Hayats-lover-picked-phone-spat-five-menacing-words.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 10:05:31+00:00
 - user: None

The man accused of the  'acid bath' murder had a fiery blow-up with the father of his girlfriend four months before his alleged victim, Arnima Hayat, 19, was found in acid in a flat they shared.

## Cressida Dick wanted £500,000 to quit as Met chief
 - [https://www.dailymail.co.uk/news/article-11691609/Cressida-Dick-wanted-500-000-quit-Met-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691609/Cressida-Dick-wanted-500-000-quit-Met-chief.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:57:24+00:00
 - user: None

Dame Cressida's four-year tenure as London's top cop was mired in controversy even before the crimes of David Carrick were revealed.

## Alameddine crime clan boss Masood Zakaria arrested in Turkey
 - [https://www.dailymail.co.uk/news/article-11691317/Alameddine-crime-clan-boss-Masood-Zakaria-arrested-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691317/Alameddine-crime-clan-boss-Masood-Zakaria-arrested-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:50:28+00:00
 - user: None

Masood Zakaria, 27, was reportedly captured by Turkish Special Forces in raids in the port city of Bodrum. He is expected to be extradited to Sydney on charges linked to the city's gang war.

## Tyre Nichols' lawyer calls on US Congress to urgently pass police reform laws that ban chokeholds
 - [https://www.dailymail.co.uk/news/article-11691537/Tyre-Nichols-lawyer-calls-Congress-urgently-pass-police-reform-laws-ban-chokeholds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691537/Tyre-Nichols-lawyer-calls-Congress-urgently-pass-police-reform-laws-ban-chokeholds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:49:31+00:00
 - user: None

The 29-year-old FedEx worker was savagely beaten to death by five cops in Memphis, Tennessee, earlier this month, shocking footage released Friday showed.

## Five-year-old Delaney Krings from Wisconsin dies after battle with incurable brain cancer
 - [https://www.dailymail.co.uk/news/article-11691597/Five-year-old-Delaney-Krings-Wisconsin-dies-battle-incurable-brain-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691597/Five-year-old-Delaney-Krings-Wisconsin-dies-battle-incurable-brain-cancer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:48:45+00:00
 - user: None

Five-year-old Delaney Krings, who moved thousands in December to send birthday cards, died following a battle with terminal brain cancer, her parents confirmed Saturday

## Elephant tries in vain to break free as it is stabbed with spears in Thailand
 - [https://www.dailymail.co.uk/news/article-11691563/Elephant-tries-vain-break-free-stabbed-spears-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691563/Elephant-tries-vain-break-free-stabbed-spears-Thailand.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:42:16+00:00
 - user: None

At least six men, armed with weapons, tied the gentle giant by its' legs and tusks to a tree in Surin, North East Thailand.

## Russian company offers cash reward to first troops who destroy or capture Western tanks in Ukraine
 - [https://www.dailymail.co.uk/news/article-11691539/Russian-company-offers-cash-reward-troops-destroy-capture-Western-tanks-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691539/Russian-company-offers-cash-reward-troops-destroy-capture-Western-tanks-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:29:59+00:00
 - user: None

Russian company Fores is offering cash payments to Russian servicemen who 'capture or destroy' German-made Leopard 2 or U.S.-made Abrams tanks.

## Australian Open tennis VIP stands packed with celebrities
 - [https://www.dailymail.co.uk/news/article-11691017/Australian-Open-tennis-VIP-stands-packed-celebrities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691017/Australian-Open-tennis-VIP-stands-packed-celebrities.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:24:44+00:00
 - user: None

The final days of the Australian Open proved to be a magnet for leading figures in politics, sport, business and entertainment as the VIP viewing areas bulged with big name spectators.

## Shamed ex-minister Nadhim Zahawi refuses to go quietly after being fired over tax affairs
 - [https://www.dailymail.co.uk/news/article-11691585/Shamed-ex-minister-Nadhim-Zahawi-refuses-quietly-fired-tax-affairs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691585/Shamed-ex-minister-Nadhim-Zahawi-refuses-quietly-fired-tax-affairs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:15:20+00:00
 - user: None

The Prime Minister dismissed the former vaccines minister for a 'serious breach of the ministerial code' less than two hours after receiving a report by ethics chief Sir Laurie Magnus.

## Bondage-loving mum who ran Facebook fetish page faces jail after hosting child abuse images on site
 - [https://www.dailymail.co.uk/news/article-11691533/Bondage-loving-mum-ran-Facebook-fetish-page-faces-jail-hosting-child-abuse-images-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691533/Bondage-loving-mum-ran-Facebook-fetish-page-faces-jail-hosting-child-abuse-images-site.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 09:11:13+00:00
 - user: None

Julie Barnes (pictured) had her home in Widnes, Cheshire, raided by police after she was linked to the X-rated social media account which contained explicit pictures of children as young as five.

## Tesco pulls own-brand grated cheddar cheese over fears it could contain 'small pieces of plastic'
 - [https://www.dailymail.co.uk/news/article-11691461/Tesco-pulls-brand-grated-cheddar-cheese-fears-contain-small-pieces-plastic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691461/Tesco-pulls-brand-grated-cheddar-cheese-fears-contain-small-pieces-plastic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 08:52:40+00:00
 - user: None

The multinational retailer issued a warning to customers and recalled its 500g Creamfields grated cheddar product with a best before date of March 23, 2023.

## Inside Austrian cellars where father is accused of keeping his six children
 - [https://www.dailymail.co.uk/news/article-11691459/Inside-Austrian-cellars-father-accused-keeping-six-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691459/Inside-Austrian-cellars-father-accused-keeping-six-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 08:52:13+00:00
 - user: None

Tom Landon, 54, was held by police after he used pepper spray on social workers, who had been called to investigate after neighbours reported crying kids.

## Putin has made himself a 'laughing stock', says Russia's former vice-president
 - [https://www.dailymail.co.uk/news/article-11691403/Putin-laughing-stock-says-Russias-former-vice-president.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691403/Putin-laughing-stock-says-Russias-former-vice-president.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 08:27:46+00:00
 - user: None

Alexander Rutskoy, a former Soviet general, accused Putin of 'senselessly' killing tens of thousands of Russian soliders who have been used as cannon fodder in the war.

## Woke George Washington University psychology professor faces anti-Semitism probe
 - [https://www.dailymail.co.uk/news/article-11691273/Woke-George-Washington-University-psychology-professor-faces-anti-Semitism-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691273/Woke-George-Washington-University-psychology-professor-faces-anti-Semitism-probe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:12:05+00:00
 - user: None

Officials at George Washington University launched an investigation into the behavior of Professor Lara Sheehi following accusations of anti-Semitism.

## Sydney airport in chaos as flights halted during severe storm
 - [https://www.dailymail.co.uk/news/article-11691315/Sydney-airport-chaos-flights-halted-severe-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691315/Sydney-airport-chaos-flights-halted-severe-storm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:10:56+00:00
 - user: None

Thunderstorms and heavy rain began to lash Sydney just after 5pm, making it too dangerous for flights to take off and land from Sydney airport.

## Foul-mouthed Utah lawmaker is filmed trying to bully cops into freeing his convicted burglar son
 - [https://www.dailymail.co.uk/news/article-11691207/Foul-mouthed-Utah-lawmaker-filmed-trying-bully-cops-freeing-convicted-burglar-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691207/Foul-mouthed-Utah-lawmaker-filmed-trying-bully-cops-freeing-convicted-burglar-son.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:09:26+00:00
 - user: None

A southeastern Utah county commissioner was caught on tape threatening and berating a sheriff's deputy about his son's post-Thanksgiving arrest.

## North Carolina boy, 14, died from cardiac arrest after being bucked off a bull and stepped on
 - [https://www.dailymail.co.uk/news/article-11691211/North-Carolina-cowboy-14-suffers-fatal-cardiac-arrest-flung-bull-stomped-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691211/North-Carolina-cowboy-14-suffers-fatal-cardiac-arrest-flung-bull-stomped-on.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:07:49+00:00
 - user: None

Denim Bradshaw, 14, died after falling off a bull while at a North Carolina rodeo event on Saturday evening. The bull stomped on Bradshaw's chest and he suffered from cardiac arrest.

## Brittany Higgins' fiancé David Sharaz threatens to sue LinkedIn user for questioning her rape claims
 - [https://www.dailymail.co.uk/news/article-11690843/Brittany-Higgins-fianc-David-Sharaz-threatens-sue-LinkedIn-user-questioning-rape-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690843/Brittany-Higgins-fianc-David-Sharaz-threatens-sue-LinkedIn-user-questioning-rape-claims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:06:10+00:00
 - user: None

David Sharaz, 29, supported Brittany Higgins in court during the trial against her accused rapist Bruce Lehrmann. Last month, he threatened to sue a LinkedIn user for defamation.

## Chicago Mayor Lori Lightfoot is filmed DANCING in streets of Windy City as murders soar
 - [https://www.dailymail.co.uk/news/article-11691129/Chicago-Mayor-Lori-Lightfoot-filmed-DANCING-streets-Windy-City-murders-soar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691129/Chicago-Mayor-Lori-Lightfoot-filmed-DANCING-streets-Windy-City-murders-soar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:04:44+00:00
 - user: None

Chicago Mayor Lori Lightfood made a scene Sunday as video of her dancing went viral, as several criticized it amid continued violent crime and the loss of more flagship stores.

## Stuart MacGill former Test cricketer allegedly screamed 'you're going down' at his best mate's ex
 - [https://www.dailymail.co.uk/news/article-11691051/Stuart-MacGill-former-Test-cricketer-allegedly-screamed-youre-going-best-mates-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691051/Stuart-MacGill-former-Test-cricketer-allegedly-screamed-youre-going-best-mates-ex.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 07:00:41+00:00
 - user: None

Former Australian cricket star Stuart MacGill is charged with intimidation and using offensive language in a public place over an alleged pub incident.

## WSU frat boy, 19, is found dead in his dorm just 10 miles from scene of Idaho quadruple murders
 - [https://www.dailymail.co.uk/news/article-11691043/WSU-frat-boy-19-dead-dorm-just-10-miles-scene-Idaho-quadruple-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691043/WSU-frat-boy-19-dead-dorm-just-10-miles-scene-Idaho-quadruple-murders.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 06:18:09+00:00
 - user: None

Luke Morgan Tyler, 19, was found dead in his Washington State University dorm room on January 22. Officials haven't released Tyler's cause of death and don't suspect foul play.

## Enraging moment brazen teen vandals destroy local Cairns business' $2.4millon crane and boast online
 - [https://www.dailymail.co.uk/news/article-11691045/Enraging-moment-brazen-teen-vandals-destroy-local-Cairns-business-2-4millon-crane-boast-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691045/Enraging-moment-brazen-teen-vandals-destroy-local-Cairns-business-2-4millon-crane-boast-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 06:05:18+00:00
 - user: None

Two teenagers have been caught damaging millions of dollars worth of heavy machinery belonging to Cairns local businesses on the weekend after they posted videos of the brazen acts online.

## Dem. Maxine Waters calls Kyrsten Sinema 'that woman from Arizona' in wake of Tyre Nichols' murder
 - [https://www.dailymail.co.uk/news/article-11690985/Dem-Maxine-Waters-calls-Kyrsten-Sinema-woman-Arizona-wake-Tyre-Nichols-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690985/Dem-Maxine-Waters-calls-Kyrsten-Sinema-woman-Arizona-wake-Tyre-Nichols-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:57:26+00:00
 - user: None

Representative Maxine Waters dismissed Senator Kyrsten Sinema as 'that woman from Arizona' while slamming some congressional Democrats for not caring about police reform.

## TikTok trend of tourists risking Bali Belly by drinking tap water sparks warning by Aussie expat
 - [https://www.dailymail.co.uk/news/article-11690923/TikTok-trend-tourists-risking-Bali-Belly-drinking-tap-water-sparks-warning-Aussie-expat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690923/TikTok-trend-tourists-risking-Bali-Belly-drinking-tap-water-sparks-warning-Aussie-expat.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:56:14+00:00
 - user: None

An Australian expat has exposed the dangers of trying to build an immunity to the island's 'undrinkable' tap water while attempting to avoid the dreaded Bali Belly.

## Sydney socialite Hollie Nasser buys ex-husband Chris Nasser's share in luxury Paddington home
 - [https://www.dailymail.co.uk/news/article-11691019/Sydney-socialite-Hollie-Nasser-buys-ex-husband-Chris-Nassers-share-luxury-Paddington-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691019/Sydney-socialite-Hollie-Nasser-buys-ex-husband-Chris-Nassers-share-luxury-Paddington-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:15:29+00:00
 - user: None

Sydney socialite Hollie Nasser has bought her husband's share of their luxury home and is the sole name on the properties mortgage following the bitter fallout from their messy divorce.

## Wyong couple Daniel Hasapis and Bonnie Cullen charged over alleged kidnapping friends with victims
 - [https://www.dailymail.co.uk/news/article-11690875/Wyong-couple-Daniel-Hasapis-Bonnie-Cullen-charged-alleged-kidnapping-friends-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690875/Wyong-couple-Daniel-Hasapis-Bonnie-Cullen-charged-alleged-kidnapping-friends-victims.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:14:07+00:00
 - user: None

Sean Froggatt, 52, and Mariana Cheri Taitoko, 44, were allegedly held against their will inside a housing commission block on Levett Street in Wyong, NSW, from Thursday until Saturday.

## Teal independent Kooyong MP Dr Monique Ryan sued by chief-of-staff ex-GetUp campaigner Sally Rugg
 - [https://www.dailymail.co.uk/news/article-11691033/Teal-independent-Kooyong-MP-Dr-Monique-Ryan-sued-chief-staff-ex-GetUp-campaigner-Sally-Rugg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11691033/Teal-independent-Kooyong-MP-Dr-Monique-Ryan-sued-chief-staff-ex-GetUp-campaigner-Sally-Rugg.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:12:42+00:00
 - user: None

Marriage equality campaigner Sally Rugg - partner of ABC TV comedian Kate McCartney - claims Dr Ryan breached general protections under the Fair Work Act.

## Somerton Park abduction: Suspect pictured by police after teen allegedly grabbed in Adelaide
 - [https://www.dailymail.co.uk/news/article-11690859/Somerton-Park-abduction-Suspect-pictured-police-teen-allegedly-grabbed-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690859/Somerton-Park-abduction-Suspect-pictured-police-teen-allegedly-grabbed-Adelaide.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:11:30+00:00
 - user: None

South Australian Police have released an image of a suspect linked to the alleged abduction of a 17-year-old boy off the street in Somerton Park, South Australia, on Thursday.

## Migrants are LOCKED OUT of NYC hotel and ordered to head to Brooklyn
 - [https://www.dailymail.co.uk/news/article-11690961/Migrants-LOCKED-NYC-hotel-ordered-head-Brooklyn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690961/Migrants-LOCKED-NYC-hotel-ordered-head-Brooklyn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:02:31+00:00
 - user: None

Mayor Eric Adams announced that the Brooklyn Cruise Terminal will open Monday and house about 1,000 single adult male migrants from a Midtown Manhattan hotel.

## British tourist slams Australia as 'just too nice to live in' and blasts 'trivial inconveniences'
 - [https://www.dailymail.co.uk/news/article-11690881/British-tourist-slams-Australia-just-nice-live-blasts-trivial-inconveniences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690881/British-tourist-slams-Australia-just-nice-live-blasts-trivial-inconveniences.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 05:00:11+00:00
 - user: None

A British tourist has slammed Australia - where he spent three weeks over Christmas - as being 'just too nice to live in' and for its 'trivial inconveniences' around coffee.

## Pickles Schoolwear, Lowes, Moorebank Uniforms charge more for overweight school students
 - [https://www.dailymail.co.uk/news/article-11690903/Pickles-Schoolwear-Lowes-Moorebank-Uniforms-charge-overweight-school-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690903/Pickles-Schoolwear-Lowes-Moorebank-Uniforms-charge-overweight-school-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 04:28:39+00:00
 - user: None

Pickles Schoolwear, Lowes and Moorebank Uniforms & Embroidery are among the school uniform providers charging more for larger sizes.

## Harry and Meghan Archewell Foundation raised $13m and donated $3m helped buy 12.6m COVID vaccines
 - [https://www.dailymail.co.uk/news/article-11690867/Harry-Meghan-Archewell-Foundation-raised-13m-donated-3m-helped-buy-12-6m-COVID-vaccines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690867/Harry-Meghan-Archewell-Foundation-raised-13m-donated-3m-helped-buy-12-6m-COVID-vaccines.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 04:13:58+00:00
 - user: None

Harry and Meghan's Archewell Foundation has released its 2020-22 'Impact Report' which reveals how in their first year of operation the charity raised $13m and distributed $3m in grants.

## Jim Chalmers attacks Josh Frydenberg for mocking him about yoga
 - [https://www.dailymail.co.uk/news/article-11690473/Jim-Chalmers-attacks-Josh-Frydenberg-mocking-yoga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690473/Jim-Chalmers-attacks-Josh-Frydenberg-mocking-yoga.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 04:13:34+00:00
 - user: None

The Treasurer used a 6,000-word essay in The Monthly magazine to recall his former opponent's parliamentary sledge against him in February 2020 just before the start of the pandemic.

## Alice Springs Aboriginal youths spit on and attack white pub patrons
 - [https://www.dailymail.co.uk/news/article-11690449/Alice-Springs-Aboriginal-youths-spit-attack-white-pub-patrons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690449/Alice-Springs-Aboriginal-youths-spit-attack-white-pub-patrons.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 04:01:11+00:00
 - user: None

Alice Springs is gripped by a crime crisis over the past few months where gangs of mostly indigenous youths roam the streets looking for trouble, breaking into homes and attacking residents.

## Pentagon top brass want to send F-16 FIGHTER JETS to Ukraine in bid to crush Putin
 - [https://www.dailymail.co.uk/news/article-11690793/Pentagon-brass-want-send-F-16-FIGHTER-JETS-Ukraine-bid-crush-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690793/Pentagon-brass-want-send-F-16-FIGHTER-JETS-Ukraine-bid-crush-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 03:24:38+00:00
 - user: None

Volodymyr Zelensky seeks US fighter jets, adding to the $30 billion in assistance in military and security assistance since Russia's invasion on February 24.

## Louise Milligan claims Redfield College alumni 'threatened' her over ABC Four Corners Opus Dei story
 - [https://www.dailymail.co.uk/news/article-11690513/Louise-Milligan-claims-Redfield-College-alumni-threatened-ABC-Four-Corners-Opus-Dei-story.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690513/Louise-Milligan-claims-Redfield-College-alumni-threatened-ABC-Four-Corners-Opus-Dei-story.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 03:05:00+00:00
 - user: None

The ABC journalist has allegedly been threatened by a graduate from a 'prominent family' of Redfield College in Dural, north-west Sydney.

## Wieambilla Ambush: Cop killers Gareth and Nathaniel Train's paedophile claims exposed by Maddy Train
 - [https://www.dailymail.co.uk/news/article-11690395/Wieambilla-Ambush-Cop-killers-Gareth-Nathaniel-Trains-paedophile-claims-exposed-Maddy-Train.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690395/Wieambilla-Ambush-Cop-killers-Gareth-Nathaniel-Trains-paedophile-claims-exposed-Maddy-Train.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:59:54+00:00
 - user: None

Madelyn Train, 26, has revealed how how her family of doomsday prepper cop killers had been cut off from their  family after they made child abuse claims.

## Top eight contenders for NASA's 2024 Artemis II mission that will see rocket orbit the moon
 - [https://www.dailymail.co.uk/news/article-11690565/Top-eight-contenders-NASAs-2024-Artemis-II-mission-rocket-orbit-moon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690565/Top-eight-contenders-NASAs-2024-Artemis-II-mission-rocket-orbit-moon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:58:49+00:00
 - user: None

Top US astronauts are in contention for a prized spot aboard the Artemis II mission, which will launch in 2024. Three Americans and one Canadian will be aboard the mission.

## Cassius Turvey death: Perth teen's family pleads for return of bike stolen from mum's Stratton home
 - [https://www.dailymail.co.uk/news/article-11690367/Cassius-Turvey-death-Perth-teens-family-pleads-return-bike-stolen-mums-Stratton-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690367/Cassius-Turvey-death-Perth-teens-family-pleads-return-bike-stolen-mums-Stratton-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:46:44+00:00
 - user: None

Cassius' beloved bike was recently stolen from his mum Mechelle's home in Perth's east as they issued a desperate plea for its return.

## Megyn Kelly mocks Jill Biden after first lady was referred to as 'doctor' by football game announcer
 - [https://www.dailymail.co.uk/news/article-11690713/Megyn-Kelly-mocks-Jill-Biden-lady-referred-doctor-football-game-announcer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690713/Megyn-Kelly-mocks-Jill-Biden-lady-referred-doctor-football-game-announcer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:43:29+00:00
 - user: None

Megyn Kelly expressed strong opinions on the use of academic titles during a 49ers game, after a presenter referred to First Lady Jill Biden as 'Dr. Jill Biden'.

## South Molle Island, Whitsundays resort now abandoned, destroyed after cyclone destroyed it
 - [https://www.dailymail.co.uk/news/article-11690505/South-Molle-Island-Whitsundays-resort-abandoned-destroyed-cyclone-destroyed-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690505/South-Molle-Island-Whitsundays-resort-abandoned-destroyed-cyclone-destroyed-it.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:42:59+00:00
 - user: None

South Molle Island was one of Queensland's most popular holiday spots, but after a cyclone smashed its shore the resort has come a tropical wasteland -  and there's no telling when it will be resorted.

## New Harry Potter game Hogwarts Legacy faces boycott due to JK Rowling's stance on trans issues
 - [https://www.dailymail.co.uk/news/article-11690811/New-Harry-Potter-game-Hogwarts-Legacy-faces-boycott-JK-Rowlings-stance-trans-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690811/New-Harry-Potter-game-Hogwarts-Legacy-faces-boycott-JK-Rowlings-stance-trans-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:33:40+00:00
 - user: None

Trans rights activists have demanded a boycott of Hogwarts Legacy, soon to be available on the PS5 and XBox One consoles, as they rail against author JK Rowling's stance on trans issues.

## Yorkshire PC suspended over 'fling with senior officer' now 'probed over affair with drugs kingpin'
 - [https://www.dailymail.co.uk/news/article-11690693/Yorkshire-PC-suspended-fling-senior-officer-probed-affair-drugs-kingpin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690693/Yorkshire-PC-suspended-fling-senior-officer-probed-affair-drugs-kingpin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:29:39+00:00
 - user: None

PC Caitlin Howarth (pictured), then-aged 21, was suspended from West Yorkshire Police in November 2021 after being accused of having an affair with commanding officer Daniel Greenwood.

## Dynamite' audio recordings 'reveal the identity of man who hid M25 road rage killer Kenneth Noye'
 - [https://www.dailymail.co.uk/news/article-11690537/Dynamite-audio-recordings-reveal-identity-man-hid-M25-road-rage-killer-Kenneth-Noye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690537/Dynamite-audio-recordings-reveal-identity-man-hid-M25-road-rage-killer-Kenneth-Noye.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:28:58+00:00
 - user: None

The identity of a person who harboured M25 road rage killer Kenneth Noye while he hid from police has apparently been unearthed in new evidence.

## Church in row over plan to show Pride flag on altar over claims it politicises place of worship
 - [https://www.dailymail.co.uk/news/article-11690809/Church-row-plan-Pride-flag-altar-claims-politicises-place-worship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690809/Church-row-plan-Pride-flag-altar-claims-politicises-place-worship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:15:45+00:00
 - user: None

A historic church's controversial plan to display a gay Pride flag on its altar is to be ruled on in a landmark legal case after protesters complained it was 'politicising'.

## DAILY MAIL COMMENT: A brutal sacking but Nadhim Zahawi had to go
 - [https://www.dailymail.co.uk/news/article-11690773/DAILY-MAIL-COMMENT-brutal-sacking-Nadhim-Zahawi-go.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690773/DAILY-MAIL-COMMENT-brutal-sacking-Nadhim-Zahawi-go.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:13:31+00:00
 - user: None

DAILY MAIL COMMENT: For several days Nadhim Zahawi has been clinging on to his job as Tory party chairman by a thread. Yesterday the thread finally snapped.

## Texas grandma shares incredible dashcam footage from inside the eye of a TORNADO that struck her SUV
 - [https://www.dailymail.co.uk/news/article-11690687/Texas-grandma-shares-incredible-dashcam-footage-inside-eye-TORNADO-struck-SUV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690687/Texas-grandma-shares-incredible-dashcam-footage-inside-eye-TORNADO-struck-SUV.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:03:44+00:00
 - user: None

Irma Cantu's dashcam caught the twister as it passed through while she and her daughter were on their way home after picking up Cantu's grandson from school.

## The other helicopter trip that changed Outback Wrangler's life
 - [https://www.dailymail.co.uk/news/article-11681933/The-helicopter-trip-changed-Outback-Wranglers-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681933/The-helicopter-trip-changed-Outback-Wranglers-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:03:09+00:00
 - user: None

Matt Wright, 43, met his future bride Kaia while she was sipping on champagne on a boat off Rottnest Island in Western Australia. Nine years later, she has supported him though criminal charges.

## Anthony Albanese at Chinese New Year celebrations shows off rabbit tie in Melbourne
 - [https://www.dailymail.co.uk/news/article-11690527/Anthony-Albanese-Chinese-New-Year-celebrations-shows-rabbit-tie-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690527/Anthony-Albanese-Chinese-New-Year-celebrations-shows-rabbit-tie-Melbourne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:01:36+00:00
 - user: None

Anthony Albanese was caught yesterday at a Melbourne Chinese New Year celebration showing off a tie covered in rabbits, as an onlooker linked the clothing choice to his Rabbitohs obsession.

## Star Wars fans dressed in character take to the streets of New Orleans to honor sci-fi movie
 - [https://www.dailymail.co.uk/news/article-11690587/Star-Wars-fans-dressed-character-streets-New-Orleans-honor-sci-fi-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690587/Star-Wars-fans-dressed-character-streets-New-Orleans-honor-sci-fi-movie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 02:01:27+00:00
 - user: None

The force was strong with thousands of 'Star Wars' fans who gathered in New Orleans Saturday night to pay tribute to the iconic sci-fi film.

## Iran claims drones attack was launched by Israel
 - [https://www.dailymail.co.uk/news/article-11690739/Iran-claims-drones-attack-launched-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690739/Iran-claims-drones-attack-launched-Israel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 01:12:04+00:00
 - user: None

Israel appears to have been behind a drone attack on a military factory in Iran, it was claimed yesterday. Iran said it intercepted three drones at the targeted building near the city of Isfahan.

## Surgeon General Vivek Murthy warns 13 is far too young for children to sign up to social media sites
 - [https://www.dailymail.co.uk/news/article-11690563/Surgeon-General-Vivek-Murthy-warns-13-far-young-children-sign-social-media-sites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690563/Surgeon-General-Vivek-Murthy-warns-13-far-young-children-sign-social-media-sites.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 01:11:14+00:00
 - user: None

Surgeon General Vivek Murthy warned parents should keep kids off social media until they are 18. Murthy claimed that the online apps can hinder a teenager's development.

## Sky News host Chris Smith celebrates 50 days sober after getting sacked amid Christmas party scandal
 - [https://www.dailymail.co.uk/news/article-11690053/Sky-News-host-Chris-Smith-celebrates-50-days-sober-getting-sacked-amid-Christmas-party-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690053/Sky-News-host-Chris-Smith-celebrates-50-days-sober-getting-sacked-amid-Christmas-party-scandal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 01:01:42+00:00
 - user: None

Chris Smith, 60, marked the special milestone with a candid selfie showing him sporting a green cap and sunglasses while out on a walk.

## Anthony Albanese 'cosying up' to Peter Costello at the Australian Open upsets Twitter
 - [https://www.dailymail.co.uk/news/article-11690377/Anthony-Albanese-cosying-Peter-Costello-Australian-Open-upsets-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690377/Anthony-Albanese-cosying-Peter-Costello-Australian-Open-upsets-Twitter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 01:00:58+00:00
 - user: None

Prime Minister and dedicated tennis fan Anthony Albanese has caused a stir on Twitter by sitting next to former Liberal treasurer Peter Costello at the Australian Open on Saturday night.

## Jacinta Nampijinpa Price, Warren Mundine lead Indigenous Voice to Parliament 'No' campaign
 - [https://www.dailymail.co.uk/news/article-11690167/Jacinta-Nampijinpa-Price-Warren-Mundine-lead-Indigenous-Voice-Parliament-No-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690167/Jacinta-Nampijinpa-Price-Warren-Mundine-lead-Indigenous-Voice-Parliament-No-campaign.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:59:45+00:00
 - user: None

The official 'No' campaign opposing the government's proposed Indigenous Voice to Parliament begins today, with organisers warning the legislation would significantly change Australia's parliament.

## Virgin Australia sale: Flights to Sydney, Byron Bay, Fiji, Queenstown cheap as airline launches sale
 - [https://www.dailymail.co.uk/news/article-11690421/Virgin-Australia-sale-Flights-Sydney-Byron-Bay-Fiji-Queenstown-cheap-airline-launches-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690421/Virgin-Australia-sale-Flights-Sydney-Byron-Bay-Fiji-Queenstown-cheap-airline-launches-sale.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:56:20+00:00
 - user: None

Bargain jetsetters searching for a discounted overseas escape are also in luck with discounted return fares to Bali, Vanuatu, Fiji, Samoa and Tokyo.

## Michael Gove set to end misery of leaseholds for millions of homeowners
 - [https://www.dailymail.co.uk/news/article-11690689/Michael-Gove-set-end-misery-leaseholds-millions-homeowners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690689/Michael-Gove-set-end-misery-leaseholds-millions-homeowners.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:44:51+00:00
 - user: None

Michael Gove has committed to abolishing the 'outdated, feudal' leasehold system of ownership for almost five million homes by the next general election.

## Strictly's Helen Skelton caught up in 'brutal' 3am street fight while 'bottles are thrown' in Leeds
 - [https://www.dailymail.co.uk/tvshowbiz/article-11689799/Strictlys-Helen-Skelton-caught-brutal-3am-street-fight-bottles-thrown-Leeds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11689799/Strictlys-Helen-Skelton-caught-brutal-3am-street-fight-bottles-thrown-Leeds.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:36:19+00:00
 - user: None

Strictly's Helen Skelton and her co-stars reportedly had to take cover when they stumbled across a 'shocking' late night  brawl in Leeds city centre on Friday.

## Crooks will not be able to use slavery or trafficking as reason to remain in UK under new proposal
 - [https://www.dailymail.co.uk/news/article-11690629/Crooks-not-able-use-slavery-trafficking-reason-remain-UK-new-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690629/Crooks-not-able-use-slavery-trafficking-reason-remain-UK-new-proposal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:26:48+00:00
 - user: None

Suella Braverman said that the changes will help prevent false claims of modern slavery and allow officials to focus on genuine victims.

## Six unanswered questions Tyre Nichols why did police pull him over did they know him cause of death
 - [https://www.dailymail.co.uk/news/article-11690341/Six-unanswered-questions-Tyre-Nichols-did-police-pull-did-know-cause-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690341/Six-unanswered-questions-Tyre-Nichols-did-police-pull-did-know-cause-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:25:18+00:00
 - user: None

Following the release of disturbing footage showing the violent attack on Tyre Nichols, 28, in Memphis, Tennessee, there are still many questions left unanswered.

## Cop says he was pressured to resign after writing 'there's no such thing as homosexual marriage'
 - [https://www.dailymail.co.uk/news/article-11690381/Cop-says-pressured-resign-writing-theres-no-thing-homosexual-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690381/Cop-says-pressured-resign-writing-theres-no-thing-homosexual-marriage.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:14:19+00:00
 - user: None

Jacob Kersey, 19, resigned from the department in Port Wentworth, a few miles outside Savannah, after refusing to remove a post on Facebook regarding gay marriage and his faith.

## Stunning seven-bedroom California home designed by architect Frank Lloyd Wright on sale for $4.25M
 - [https://www.dailymail.co.uk/news/article-11690347/Stunning-seven-bedroom-California-home-designed-architect-Frank-Lloyd-Wright-sale-4-25M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690347/Stunning-seven-bedroom-California-home-designed-architect-Frank-Lloyd-Wright-sale-4-25M.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:07:23+00:00
 - user: None

A home designed by Frank Lloyd Wright is now on the market in California for $4.25 million. The seven bedroom, six bathroom home is located about 120 miles southeast of San Francisco.

## Sydney writer Natalie Fornasier dies after battle with melanoma
 - [https://www.dailymail.co.uk/news/article-11690577/Sydney-writer-Natalie-Fornasier-dies-battle-melanoma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690577/Sydney-writer-Natalie-Fornasier-dies-battle-melanoma.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:07:19+00:00
 - user: None

Popular Australian writer Natalie Fornasier has died at the age of 28 after battling melanoma.

## Radical NHS blueprint promises more beds, 800 new ambulances and video 'treatment'
 - [https://www.dailymail.co.uk/news/article-11690583/Radical-NHS-blueprint-promises-beds-800-new-ambulances-video-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690583/Radical-NHS-blueprint-promises-beds-800-new-ambulances-video-treatment.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:06:58+00:00
 - user: None

The Urgent and Emergency Care plan will help take pressure off the NHS - in time to present to voters ahead of the next general election, due by January 2025.

## Happy Valley star Sarah Lancashire is slapped with parking ticket in London street
 - [https://www.dailymail.co.uk/news/article-11690551/Happy-Valley-star-Sarah-Lancashire-slapped-parking-ticket-London-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690551/Happy-Valley-star-Sarah-Lancashire-slapped-parking-ticket-London-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:05:47+00:00
 - user: None

The actress, 58, who plays Police Sergeant Catherine Cawood, looked far from pleased as she peeled the ticket off her car in west London, where she had parked on a street during prohibited hours.

## Clip shows restaurant worker clasping Trump's hand while praying as he begins re-election effort
 - [https://www.dailymail.co.uk/news/article-11690349/Clip-shows-restaurant-worker-clasping-Trumps-hand-praying-begins-election-effort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690349/Clip-shows-restaurant-worker-clasping-Trumps-hand-praying-begins-election-effort.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:04:05+00:00
 - user: None

Donald Trump was stopped over the weekend by a restaurant worker who became emotional as she gripped the politician's hand and prayed for the success of his presidential campaign.

## Vladimir Putin's 'threat to kill Boris Johnson' in run-up to Ukraine war
 - [https://www.dailymail.co.uk/news/article-11690521/Vladimir-Putins-threat-kill-Boris-Johnson-run-Ukraine-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690521/Vladimir-Putins-threat-kill-Boris-Johnson-run-Ukraine-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:03:29+00:00
 - user: None

Boris Johnson said the Russian leader had bragged it would 'take only a minute' to kill him with a missile after he warned him to abandon his plans to attack Ukraine.

## Jeremy Clarkson blames newcomers from London for village standoff over Cotswolds Diddly Squat farm
 - [https://www.dailymail.co.uk/news/article-11690569/Jeremy-Clarkson-blames-newcomers-London-village-standoff-Cotswolds-Diddly-Squat-farm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11690569/Jeremy-Clarkson-blames-newcomers-London-village-standoff-Cotswolds-Diddly-Squat-farm.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-30 00:01:33+00:00
 - user: None

Jeremy Clarkson (pictured) said he is yet to win over some of his Cotswolds neighbours - particularly those who have moved from London - who remain unhappy with Diddly Squat Farm.
