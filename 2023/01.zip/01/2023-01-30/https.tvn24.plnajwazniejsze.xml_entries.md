# Source TNV24 Najważniejsze, Source URL:https://tvn24.pl/najwazniejsze.xml, Source language: pl-PL

## Prezydent Joe Biden o swojej podróży do Polski
 - [https://tvn24.pl/swiat/usa-prezydent-joe-biden-o-wizycie-w-polsce-6712604?source=rss](https://tvn24.pl/swiat/usa-prezydent-joe-biden-o-wizycie-w-polsce-6712604?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 21:55:14+00:00
 - user: None

<img alt="Prezydent Joe Biden o swojej podróży do Polski" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1r9pq5-joe-biden-6712169/alternates/LANDSCAPE_1280" />
    Amerykańskie media donosiły, że prezydent USA planuje przybyć do Europy w rocznicę zbrojnej rosyjskiej napaści na Ukrainę.

## Norweski skoczek załamany. Nie wyklucza szybkiego zakończenia kariery
 - [https://eurosport.tvn24.pl/norweski-skoczek-za-amany--nie-wyklucza-szybkiego-zako-czenia-kariery,1134785.html?source=rss](https://eurosport.tvn24.pl/norweski-skoczek-za-amany--nie-wyklucza-szybkiego-zako-czenia-kariery,1134785.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 21:04:00+00:00
 - user: None

<img alt="Norweski skoczek załamany. Nie wyklucza szybkiego zakończenia kariery" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q1fxl4-johansson-w-tym-sezonie-nie-ma-zbyt-wielu-powodow-do-zadowolenia/alternates/LANDSCAPE_1280" />
    Wszystko z powodu poważnych problemów zdrowotnych.

## "Aryna, twoje zdrowie!". Prowokacja Łukaszenki spotkała się z ostrą reakcją Ukraińców
 - [https://eurosport.tvn24.pl/-aryna--twoje-zdrowie----prowokacja--ukaszenki-spotka-a-si--z-ostr--reakcj--ukrai-c-w,1134853.html?source=rss](https://eurosport.tvn24.pl/-aryna--twoje-zdrowie----prowokacja--ukaszenki-spotka-a-si--z-ostr--reakcj--ukrai-c-w,1134853.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 20:23:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vw3lfg-alaksandr-lukaszenka/alternates/LANDSCAPE_1280" />
    Australian Open się skończył, zaczęła się dogrywka.

## Był demonem szybkości i mistrzem NHL. Śmierć legendy hokeja
 - [https://eurosport.tvn24.pl/by--demonem-szybko-ci-i-mistrzem-nhl---mier--legendy-hokeja,1134825.html?source=rss](https://eurosport.tvn24.pl/by--demonem-szybko-ci-i-mistrzem-nhl---mier--legendy-hokeja,1134825.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 20:00:00+00:00
 - user: None

<img alt="Był demonem szybkości i mistrzem NHL. Śmierć legendy hokeja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7yvtls-bobby-hull-byl-legenda-nhl/alternates/LANDSCAPE_1280" />
    Środowisko NHL pożegnało jedną ze swoich największych postaci.

## Matczak: W państwie praworządnym ludzie są równi. A tu okazuje się, że ktoś może być ponad prawem
 - [https://tvn24.pl/polska/lex-kaczynski-marcin-matczak-komentuje-przepisy-6710111?source=rss](https://tvn24.pl/polska/lex-kaczynski-marcin-matczak-komentuje-przepisy-6710111?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 19:55:42+00:00
 - user: None

<img alt="Matczak: W państwie praworządnym ludzie są równi. A tu okazuje się, że ktoś może być ponad prawem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bxioml-profesor-marcin-matczak-6710069/alternates/LANDSCAPE_1280" />
    Profesor Marcin Matczak komentował w "Faktach po Faktach" zmiany prawne, na których może skorzystać prezes PiS.

## Borowski ma pomysł dla opozycji. "Żeby się nie roztopić" na jednej liście
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-start-opozycji-z-jednej-listy-marek-borowski-o-swoim-pomysle-dla-wszystkich-partii-6710028?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-start-opozycji-z-jednej-listy-marek-borowski-o-swoim-pomysle-dla-wszystkich-partii-6710028?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 19:38:32+00:00
 - user: None

<img alt="Borowski ma pomysł dla opozycji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qubc35-marek-borowski-6710041/alternates/LANDSCAPE_1280" />
    Mówił o nim w "Faktach po Faktach" w TVN24.

## Linette: w tenisie jest bardzo mało bliskich przyjaźni
 - [https://eurosport.tvn24.pl/linette--w-tenisie-jest-bardzo-ma-o-bliskich-przyja-ni,1134834.html?source=rss](https://eurosport.tvn24.pl/linette--w-tenisie-jest-bardzo-ma-o-bliskich-przyja-ni,1134834.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 19:17:00+00:00
 - user: None

<img alt="Linette: w tenisie jest bardzo mało bliskich przyjaźni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fzknhz-magda-linette-w-programie-kropka-nad-i-6710105/alternates/LANDSCAPE_1280" />
    Polska bohaterka tegorocznego Australian Open w "Kropce nad i".

## Polska policja w ogniu krytyki. "Polityka wdarła się w jej struktury i strasznie je niszczy"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2365,S00E2365,979887?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2365,S00E2365,979887?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 19:05:29+00:00
 - user: None

<img alt="Polska policja w ogniu krytyki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjvr7t-cnb-6710089/alternates/LANDSCAPE_1280" />
    Reportaż Artura Warcholińskiego i Marcina Jakubika.

## Zamordowała swojego sobowtóra, aby upozorować własną śmierć. "Ponad 50 ran kłutych"
 - [https://tvn24.pl/swiat/niemcy-bawaria-ingolstadt-kobieta-miala-zamordowac-swojego-sobowtora-aby-upozorowac-wlasna-smierc-grozi-jej-dozywocie-6709985?source=rss](https://tvn24.pl/swiat/niemcy-bawaria-ingolstadt-kobieta-miala-zamordowac-swojego-sobowtora-aby-upozorowac-wlasna-smierc-grozi-jej-dozywocie-6709985?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 19:04:22+00:00
 - user: None

<img alt="Zamordowała swojego sobowtóra, aby upozorować własną śmierć. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xoimbz-ingolstadt-bawaria-policjanci-przeszukuja-las-w-poblizu-miejsca-gdzie-znaleziono-cialo-kobiety-w-samochodzie-zdjecie-z-17-sierpnia-2022-roku-6709993/alternates/LANDSCAPE_1280" />
    Oskarżonej kobiecie i jej znajomemu grozi dożywocie.

## "Lex Kaczyński". Prawnik: ochrona dóbr osobistych przestaje funkcjonować w normalny sposób
 - [https://tvn24.pl/polska/lex-kaczynski-nowelizacja-kodeksu-postepowania-cywilnego-maciej-gutowski-i-tomasz-nalecz-komentuja-6709975?source=rss](https://tvn24.pl/polska/lex-kaczynski-nowelizacja-kodeksu-postepowania-cywilnego-maciej-gutowski-i-tomasz-nalecz-komentuja-6709975?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 18:46:16+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-txu7vj-maciej-gutowski-i-tomasz-nalecz-w-tak-jest-6709935/alternates/LANDSCAPE_1280" />
    Profesor Maciej Gutowski i profesor Tomasz Nałęcz w "Tak jest" w TVN24.

## Kiedy elektroniczne rozliczenie z fiskusem? Jest termin i nowość dla rodzin 4 plus
 - [https://tvn24.pl/biznes/pieniadze/podatki-2023-kiedy-zlozyc-pit-za-2022-rok-mf-wyjasnia-6709883?source=rss](https://tvn24.pl/biznes/pieniadze/podatki-2023-kiedy-zlozyc-pit-za-2022-rok-mf-wyjasnia-6709883?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 18:40:36+00:00
 - user: None

<img alt="Kiedy elektroniczne rozliczenie z fiskusem? Jest termin i nowość dla rodzin 4 plus" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ld0mxa-podatki-4560315/alternates/LANDSCAPE_1280" />
    Odpowiedzi na pytania TVN24 Biznes.

## Na krajowej "60" wywróciła się ciężarówka przewożąca świnie
 - [https://tvn24.pl/tvnwarszawa/ulice/dk-60-bielsk-ciezarowka-z-trzoda-chlewna-wywrocila-sie-o-zjechala-do-rowu-6710007?source=rss](https://tvn24.pl/tvnwarszawa/ulice/dk-60-bielsk-ciezarowka-z-trzoda-chlewna-wywrocila-sie-o-zjechala-do-rowu-6710007?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 18:27:12+00:00
 - user: None

<img alt="Na krajowej " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-i74nn6-do-zdarzenia-doszlo-w-miejscowosci-bielsk-6710003/alternates/LANDSCAPE_1280" />
    W miejscowości Bielsk.

## Przerażające dane. "2031 trudnych pytań"
 - [https://fakty.tvn24.pl/przera-aj-ce-dane-dotycz-ce-pr-b-samob-jczych-w-r-d-dzieci-i-m-odzie-y---2031-trudnych-pyta---trudnych-sytuacji-,1134827.html?source=rss](https://fakty.tvn24.pl/przera-aj-ce-dane-dotycz-ce-pr-b-samob-jczych-w-r-d-dzieci-i-m-odzie-y---2031-trudnych-pyta---trudnych-sytuacji-,1134827.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 18:08:00+00:00
 - user: None

<img alt="Przerażające dane. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uc25zv-3001--przerazajace-dane-dotyczace-prob-samobojczych-wsrod-dzieci-i-mlodziezy-2031-trudnych-pytan-trudnych-sytuacji/alternates/LANDSCAPE_1280" />
    Te liczby są przerażające, a każda z nich to młody człowiek, który nie chciał dłużej żyć i próbował to życie zakończyć. W 2022 roku zdarzyło się tak aż ponad 2000 razy. To o wiele więcej niż w poprzednich latach.

## Autokar spadł z mostu. Tragiczny wypadek z młodymi piłkarzami
 - [https://eurosport.tvn24.pl/autokar-spad--z-mostu--tragiczny-wypadek-z-m-odymi-pi-karzami,1134824.html?source=rss](https://eurosport.tvn24.pl/autokar-spad--z-mostu--tragiczny-wypadek-z-m-odymi-pi-karzami,1134824.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 17:41:00+00:00
 - user: None

<img alt="Autokar spadł z mostu. Tragiczny wypadek z młodymi piłkarzami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-agga18-wypadek-autokaru-z-mlodymi-pilkarzami-w-brazylii/alternates/LANDSCAPE_1280" />
    Cztery osoby zginęły, a 29 zostało rannych.

## Samochody ślizgały się na tafli lodu. Nawet 30 pojazdów zderzyło się ze sobą
 - [https://tvn24.pl/tvnmeteo/swiat/missouri-stany-zjednoczone-karambol-na-oblodzonej-autostradzie-6709927?source=rss](https://tvn24.pl/tvnmeteo/swiat/missouri-stany-zjednoczone-karambol-na-oblodzonej-autostradzie-6709927?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 17:28:27+00:00
 - user: None

<img alt="Samochody ślizgały się na tafli lodu. Nawet 30 pojazdów zderzyło się ze sobą" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-x0sfby-karambol-w-missouri-6709941/alternates/LANDSCAPE_1280" />
    Marznący deszcz sparaliżował ruch w części Missouri.

## Kolejne transze potrącone. Straciliśmy już 1,7 miliarda złotych
 - [https://tvn24.pl/biznes/z-kraju/ke-potracila-kolejne-transze-z-funduszy-ue-dla-polski-kara-za-izbe-dyscyplinarna-6709946?source=rss](https://tvn24.pl/biznes/z-kraju/ke-potracila-kolejne-transze-z-funduszy-ue-dla-polski-kara-za-izbe-dyscyplinarna-6709946?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 17:26:49+00:00
 - user: None

<img alt="Kolejne transze potrącone. Straciliśmy już 1,7 miliarda złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0jl13x-komisja-europejska-5452065/alternates/LANDSCAPE_1280" />
    Wynika z ustaleń korespondenta TVN24 w Brukseli Macieja Sokołowskiego.

## Myśliwiec rozbił się na morzu. Jeden pilot nie żyje, drugi zaginął
 - [https://tvn24.pl/swiat/grecja-peloponez-pilot-zginal-po-rozbiciu-sie-mysliwca-f-4-phantom-na-morzu-jonskim-drugi-jest-poszukiwany-6709879?source=rss](https://tvn24.pl/swiat/grecja-peloponez-pilot-zginal-po-rozbiciu-sie-mysliwca-f-4-phantom-na-morzu-jonskim-drugi-jest-poszukiwany-6709879?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 17:16:06+00:00
 - user: None

<img alt="Myśliwiec rozbił się na morzu. Jeden pilot nie żyje, drugi zaginął" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b5jg9c-shutterstock1983177110-6709859/alternates/LANDSCAPE_1280" />
    Trzydniowa żałoba w szeregach greckiego wojska.

## Na osiedlu znaleziono niewybuch. Ewakuowali mieszkańców, czekają na saperów
 - [https://tvn24.pl/katowice/czestochowa-przy-ul-kossaka-znaleziono-niewybuch-ewakuacja-mieszkancow-6709860?source=rss](https://tvn24.pl/katowice/czestochowa-przy-ul-kossaka-znaleziono-niewybuch-ewakuacja-mieszkancow-6709860?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 17:03:35+00:00
 - user: None

<img alt="Na osiedlu znaleziono niewybuch. Ewakuowali mieszkańców, czekają na saperów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4vixsn-podczas-budowy-nitki-gazociagu-na-ulicy-kossaka-w-czestochowie-znaleziono-niewybuch-6709880/alternates/LANDSCAPE_1280" />
    Informację i zdjęcia z miejsca zdarzenia otrzymaliśmy na Kontakt 24.

## Alec Baldwin zostanie oskarżony o nieumyślne zabójstwo, jego żona przerywa milczenie
 - [https://tvn24.pl/kultura-i-styl/alec-baldwin-zostanie-oskarzony-o-nieumyslne-zabojstwo-jego-zona-przerywa-milczenie-6709872?source=rss](https://tvn24.pl/kultura-i-styl/alec-baldwin-zostanie-oskarzony-o-nieumyslne-zabojstwo-jego-zona-przerywa-milczenie-6709872?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:58:18+00:00
 - user: None

<img alt="Alec Baldwin zostanie oskarżony o nieumyślne zabójstwo, jego żona przerywa milczenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kliikq-hilaria-i-alec-baldwin-5033467/alternates/LANDSCAPE_1280" />
    Para ma razem siedmioro dzieci.

## Nowa drabina strażacka złamała się i runęła na ziemię. "Uległa awarii"
 - [https://tvn24.pl/pomorze/inowroclaw-nowa-drabina-strazacka-zlamala-sie-i-runela-na-ziemie-straz-pozarna-to-byly-testy-nikt-nie-ucierpial-6709853?source=rss](https://tvn24.pl/pomorze/inowroclaw-nowa-drabina-strazacka-zlamala-sie-i-runela-na-ziemie-straz-pozarna-to-byly-testy-nikt-nie-ucierpial-6709853?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:42:33+00:00
 - user: None

<img alt="Nowa drabina strażacka złamała się i runęła na ziemię. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ijf2r-drabina-strazacka-zlamala-sie-podczas-cwiczen-6709844/alternates/LANDSCAPE_1280" />
    Na to, co się stało w Inowrocławiu, zareagował już komendant główny Państwowej Straży Pożarnej.

## Świątek z niespodzianką dla amerykańskiej gwiazdy. Niedługo ma dojść do rewanżu
 - [https://eurosport.tvn24.pl/-wi-tek-z-niespodziank--dla-ameryka-skiej-gwiazdy--nied-ugo-ma-doj---do-rewan-u,1134804.html?source=rss](https://eurosport.tvn24.pl/-wi-tek-z-niespodziank--dla-ameryka-skiej-gwiazdy--nied-ugo-ma-doj---do-rewan-u,1134804.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:30:00+00:00
 - user: None

<img alt="Świątek z niespodzianką dla amerykańskiej gwiazdy. Niedługo ma dojść do rewanżu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zsvl6z-swiatek-przekazala-rakiete-z-wta-finals-6709905/alternates/LANDSCAPE_1280" />
    W weekend Amerykanka otrzymała go osobiście podczas zawodów, od osoby reprezentującej polską tenisistkę.

## Bayern walczy z czasem. Wielki transfer wisi w powietrzu
 - [https://eurosport.tvn24.pl/bayern-walczy-z-czasem--wielki-transfer-wisi-w-powietrzu,1134777.html?source=rss](https://eurosport.tvn24.pl/bayern-walczy-z-czasem--wielki-transfer-wisi-w-powietrzu,1134777.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:23:00+00:00
 - user: None

<img alt="Bayern walczy z czasem. Wielki transfer wisi w powietrzu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9u9ewr-bayern-broni-tytulu/alternates/LANDSCAPE_1280" />
    Reprezentant Portugalii blisko Allianz Arena.

## Hiszpański przysmak zagrożony. "To będzie najgorszy rok od 40 lat"
 - [https://tvn24.pl/biznes/ze-swiata/hiszpania-szynka-jamon-iberico-bellota-zagrozone-z-powodu-ocieplania-klimatu-6709790?source=rss](https://tvn24.pl/biznes/ze-swiata/hiszpania-szynka-jamon-iberico-bellota-zagrozone-z-powodu-ocieplania-klimatu-6709790?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:17:18+00:00
 - user: None

<img alt="Hiszpański przysmak zagrożony. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-deps50-szynka-hiszpania-jamon-iberico-6709827/alternates/LANDSCAPE_1280" />
    Przez ocieplenie klimatu.

## Stypendium bez wymogów naukowych, "musisz tylko być Ukraińcem"? To nieprawda
 - [https://konkret24.tvn24.pl/polska/wojna-w-ukrainie-zeby-otrzymac-stypendium-nie-ma-zadnych-wymogow-musisz-tylko-byc-ukraincem-to-nieprawda-6684298?source=rss](https://konkret24.tvn24.pl/polska/wojna-w-ukrainie-zeby-otrzymac-stypendium-nie-ma-zadnych-wymogow-musisz-tylko-byc-ukraincem-to-nieprawda-6684298?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 16:16:00+00:00
 - user: None

<img alt="Stypendium bez wymogów naukowych, " src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-6f22oh-warunki-przyznawania-stypendiow-sa-inne-niz-tu-napisano-6685443/alternates/LANDSCAPE_1280" />
    Ukraińcy mogą uzyskać wysokie stypendium naukowe bez żadnych warunków i nawet nie będą musieli żyć w Polsce - głosi popularny przekaz. Te tezy wprowadzają w błąd.

## "Potężne tąpnięcie" na rynku nieruchomości
 - [https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-sprzedaz-mieszkan-ostro-w-dol-co-z-cenami-raport-za-2022-6709722?source=rss](https://tvn24.pl/biznes/nieruchomosci/nieruchomosci-sprzedaz-mieszkan-ostro-w-dol-co-z-cenami-raport-za-2022-6709722?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:46:58+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tut0mb-shutterstock2176166657-6709830/alternates/LANDSCAPE_1280" />
    Analiza.

## Wsiadła do taksówki, kierowca miał "usiłować doprowadzić ją do obcowania płciowego". Zarzuty dla 46-latka
 - [https://tvn24.pl/wroclaw/wroclaw-taksowkarz-mial-napastowac-seksualnie-pasazerke-uslyszal-zarzuty-trafil-do-aresztu-6709760?source=rss](https://tvn24.pl/wroclaw/wroclaw-taksowkarz-mial-napastowac-seksualnie-pasazerke-uslyszal-zarzuty-trafil-do-aresztu-6709760?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:45:56+00:00
 - user: None

<img alt="Wsiadła do taksówki, kierowca miał " src="https://tvn24.pl/najnowsze/cdn-zdjecie-0bgj7t-46-letni-mezczyzna-uslyszal-zarzut-zarzutow-doprowadzenia-wbrew-woli-kobiety-do-innej-czynnosci-seksualnej-6709761/alternates/LANDSCAPE_1280" />
    Grozi mu do ośmiu lat więzienia.

## Jeden z podejrzanych o zabójstwo na Nowym Świecie zatrzymany
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/jeden-z-podejrzanych-o-zabojstwo-na-nowym-swiecie-zatrzymany-6709832?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/jeden-z-podejrzanych-o-zabojstwo-na-nowym-swiecie-zatrzymany-6709832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:40:43+00:00
 - user: None

<img alt="Jeden z podejrzanych o zabójstwo na Nowym Świecie zatrzymany" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qnbl1y-policja-zatrzymala-lukasza-g-poszukiwanego-w-zwiazku-z-zabojstwem-na-nowym-swiecie-6709863/alternates/LANDSCAPE_1280" />
    Do tragedii doszło w maju 2022.

## Jeden z podejrzanych o zabójstwo na Nowym Świecie zatrzymany
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/zabojstwo-na-nowym-swiecie-policja-zatrzymala-jednego-z-podejrzanych-6709832?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/zabojstwo-na-nowym-swiecie-policja-zatrzymala-jednego-z-podejrzanych-6709832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:40:43+00:00
 - user: None

<img alt="Jeden z podejrzanych o zabójstwo na Nowym Świecie zatrzymany" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qnbl1y-policja-zatrzymala-lukasza-g-poszukiwanego-w-zwiazku-z-zabojstwem-na-nowym-swiecie-6709863/alternates/LANDSCAPE_1280" />
    Do tragedii doszło w maju 2022.

## Niepokojący komunikat w sprawie Milika
 - [https://eurosport.tvn24.pl/niepokoj-cy-komunikat-juventusu-w-sprawie-milika,1134787.html?source=rss](https://eurosport.tvn24.pl/niepokoj-cy-komunikat-juventusu-w-sprawie-milika,1134787.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:37:00+00:00
 - user: None

<img alt="Niepokojący komunikat w sprawie Milika" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hliwgx-arkadiusz-milik-bedzie-musial-pauzowac/alternates/LANDSCAPE_1280" />
    Nowe informacje dotyczące kontuzji polskiego napastnika.

## "Ludzie, którzy mogą być bardzo niebezpieczni". Wracają do kraju
 - [https://tvn24.pl/swiat/new-york-times-najemnicy-z-grupy-wagnera-wracaja-do-rosji-moga-stanowic-zagrozenie-6709635?source=rss](https://tvn24.pl/swiat/new-york-times-najemnicy-z-grupy-wagnera-wracaja-do-rosji-moga-stanowic-zagrozenie-6709635?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 15:27:19+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-72p9uj-najemnicy-grupy-wagnera-6709650/alternates/LANDSCAPE_1280" />
    Powrót do Rosji więźniów, którzy zaciągnęli się do Grupy Wagnera i walczyli w Ukrainie, oznacza wiele problemów - ocenia "New York Times"

## "Umawiałam się z nim, ale nie wiedziałam, kim jest". Policja na tropie kochanek bossa
 - [https://tvn24.pl/ciekawostki/wlochy-matteo-messina-denaro-nawet-zyjac-w-ukryciu-pozostal-kobieciarzem-policja-na-tropie-kochanek-sycylijskiego-bossa-6709685?source=rss](https://tvn24.pl/ciekawostki/wlochy-matteo-messina-denaro-nawet-zyjac-w-ukryciu-pozostal-kobieciarzem-policja-na-tropie-kochanek-sycylijskiego-bossa-6709685?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:53:58+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mhpz29-mlody-matteo-messina-denaro-6641403/alternates/LANDSCAPE_1280" />
    "Usłyszysz, jak ludzie o mnie mówią, będą mnie przedstawiać jako diabła, ale to wszystko nieprawda" - pisał w liście do kobiety Matteo Messina Denaro.

## Mistrzowska sesja Djokovicia
 - [https://eurosport.tvn24.pl/mistrzowska-sesja-djokovicia-i-wiadomo---do-kibic-w,1134764.html?source=rss](https://eurosport.tvn24.pl/mistrzowska-sesja-djokovicia-i-wiadomo---do-kibic-w,1134764.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:50:00+00:00
 - user: None

<img alt="Mistrzowska sesja Djokovicia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5n53o-djokovic-dziesiaty-raz-najlepszy-w-australian-open/alternates/LANDSCAPE_1280" />
    Wiadomość do kibiców.

## Trzej mężczyźni pracowali sześć metrów nad ziemią. Spadli z podestu, jeden nie żyje
 - [https://tvn24.pl/tvnwarszawa/okolice/piaseczno-trzech-mezczyzn-spadlo-z-wysokosci-podczas-prac-jeden-nie-przezyl-6709656?source=rss](https://tvn24.pl/tvnwarszawa/okolice/piaseczno-trzech-mezczyzn-spadlo-z-wysokosci-podczas-prac-jeden-nie-przezyl-6709656?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:34:59+00:00
 - user: None

<img alt="Trzej mężczyźni pracowali sześć metrów nad ziemią. Spadli z podestu, jeden nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wro62u-do-zdarzenia-doszlo-w-piasecznie-zdj-ilustracyjne-6709639/alternates/LANDSCAPE_1280" />
    Do tragicznego wypadku doszło w Piasecznie.

## Prezes NIK o planowych kontrolach w Orlenie. "Zostały udaremnione"
 - [https://tvn24.pl/biznes/z-kraju/prezes-nik-marian-banas-na-komisji-do-spraw-kontroli-panstwowej-o-pkn-orlen-6709741?source=rss](https://tvn24.pl/biznes/z-kraju/prezes-nik-marian-banas-na-komisji-do-spraw-kontroli-panstwowej-o-pkn-orlen-6709741?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:34:55+00:00
 - user: None

<img alt="Prezes NIK o planowych kontrolach w Orlenie. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-k429bo-marian-banas-podczas-posiedzenia-komisji-6680409/alternates/LANDSCAPE_1280" />
    Oświadczenie.

## "Wspaniały, cudowny i bardzo spokojny dzień". Owsiak podsumował 31. Finał WOŚP
 - [https://tvn24.pl/wosp-2023/wosp-2023-ile-zebrano-pieniedzy-konferencja-jurka-owsiaka-6709687?source=rss](https://tvn24.pl/wosp-2023/wosp-2023-ile-zebrano-pieniedzy-konferencja-jurka-owsiaka-6709687?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:32:30+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vh88yd-jurek-owsiak-6709717/alternates/LANDSCAPE_1280" />
    Na konferencji.

## Pracę mają stracić tysiące osób. "Trudne i bolesne"
 - [https://tvn24.pl/biznes/ze-swiata/philips-zapowiada-zwolnienie-6-tys-pracownikow-na-calym-swiecie-6709640?source=rss](https://tvn24.pl/biznes/ze-swiata/philips-zapowiada-zwolnienie-6-tys-pracownikow-na-calym-swiecie-6709640?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 14:20:29+00:00
 - user: None

<img alt="Pracę mają stracić tysiące osób. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-dd83ni-shutterstock2234723475-6709663/alternates/LANDSCAPE_1280" />
    Zapowiedź giganta.

## Nieszczęście przed metą. Kolarz uderzony telefonem
 - [https://eurosport.tvn24.pl/dramat-przed-met---kolarz-uderzony-telefonem,1134763.html?source=rss](https://eurosport.tvn24.pl/dramat-przed-met---kolarz-uderzony-telefonem,1134763.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:59:00+00:00
 - user: None

<img alt="Nieszczęście przed metą. Kolarz uderzony telefonem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r3o6rd-jakobsen-6709672/alternates/LANDSCAPE_1280" />
    Niewiele brakowało, by Fabio Jakobsen zaliczył kolejny, bardzo groźny upadek w karierze.

## Nastolatek bawił się w chowanego, po 6 dniach znaleziono go w innym państwie
 - [https://tvn24.pl/ciekawostki/malezja-nastolatek-fahim-bawil-sie-w-chowanego-po-6-dniach-znaleziono-go-w-kontenerze-w-malezji-6709331?source=rss](https://tvn24.pl/ciekawostki/malezja-nastolatek-fahim-bawil-sie-w-chowanego-po-6-dniach-znaleziono-go-w-kontenerze-w-malezji-6709331?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:50:53+00:00
 - user: None

<img alt="Nastolatek bawił się w chowanego, po 6 dniach znaleziono go w innym państwie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o9zn9v-port-klang-w-malezji-6709420/alternates/LANDSCAPE_1280" />
    W zamknięciu pokonał prawie 3 tysiące kilometrów.

## Miał więzić kobiety i znęcać się nad nimi. Policja: podejrzany aktywnie korzysta z aplikacji randkowych
 - [https://tvn24.pl/swiat/usa-poszukiwany-w-oregonie-za-znecanie-sie-nad-kobieta-wykorzystuje-aplikacje-randkowe-6709544?source=rss](https://tvn24.pl/swiat/usa-poszukiwany-w-oregonie-za-znecanie-sie-nad-kobieta-wykorzystuje-aplikacje-randkowe-6709544?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:50:40+00:00
 - user: None

<img alt="Miał więzić kobiety i znęcać się nad nimi. Policja: podejrzany aktywnie korzysta z aplikacji randkowych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h8fwuh-benjamin-obadiah-foster-jest-poszukiwany-w-zwiazku-z-zarzutami-usilowania-morderstwa-porwania-i-napasci-6709385/alternates/LANDSCAPE_1280" />
    Na liście zarzutów usiłowanie morderstwa, porwanie i napaść.

## Koniec niebywałej serii
 - [https://eurosport.tvn24.pl/koniec-niebywa-ej-serii--przez-prawie-siedem-lat-nie-opu-ci---adnego-meczu,1134753.html?source=rss](https://eurosport.tvn24.pl/koniec-niebywa-ej-serii--przez-prawie-siedem-lat-nie-opu-ci---adnego-meczu,1134753.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:49:00+00:00
 - user: None

<img alt="Koniec niebywałej serii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3m89vx-inaki-williams-jest-jedna-z-najwiekszych-gwiazd-athletiku-bilbao/alternates/LANDSCAPE_1280" />
    Przez prawie siedem lat nie opuścił żadnego meczu.

## To miał być planowy zabieg, pacjentka zmarła. Po dziewięciu latach jest wyrok sądu
 - [https://tvn24.pl/polska/lublin-tomial-byc-planowy-zabieg-pacjentka-zmarla-sad-uniewinnil-czworo-lekarzy-6709588?source=rss](https://tvn24.pl/polska/lublin-tomial-byc-planowy-zabieg-pacjentka-zmarla-sad-uniewinnil-czworo-lekarzy-6709588?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:36:49+00:00
 - user: None

<img alt="To miał być planowy zabieg, pacjentka zmarła. Po dziewięciu latach jest wyrok sądu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ssf5g6-sad-uniewinnil-lekarzy-wyrok-nie-jest-prawomocny-6709582/alternates/LANDSCAPE_1280" />
    Mąż zmarłej, który jest lekarzem, powiedział po wyjściu z sali rozpraw, że rozważy apelację.

## Sześcioro dzieci odnaleziono w piwnicy w Austrii. Najmłodsze miało siedem miesięcy
 - [https://tvn24.pl/swiat/austria-szescioro-dzieci-odnaleziono-w-piwnicy-w-austrii-najmlodsze-mialo-siedem-miesiecy-6709021?source=rss](https://tvn24.pl/swiat/austria-szescioro-dzieci-odnaleziono-w-piwnicy-w-austrii-najmlodsze-mialo-siedem-miesiecy-6709021?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:34:45+00:00
 - user: None

<img alt="Sześcioro dzieci odnaleziono w piwnicy w Austrii. Najmłodsze miało siedem miesięcy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dn5m53-policjantka-policja-austria-funkcjonariusz-shutterstock1940520043-6709546/alternates/LANDSCAPE_1280" />
    W piwnicy była też broń.

## Alert w elektrowni atomowej. Wstrzymano pracę reaktora
 - [https://tvn24.pl/swiat/japonia-alert-w-elektrowni-atomowej-wstrzymano-prace-reaktora-6709538?source=rss](https://tvn24.pl/swiat/japonia-alert-w-elektrowni-atomowej-wstrzymano-prace-reaktora-6709538?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 13:02:11+00:00
 - user: None

<img alt="Alert w elektrowni atomowej. Wstrzymano pracę reaktora" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dk7s7t-elektrownia-atomowa-w-takahamie-6709545/alternates/LANDSCAPE_1280" />
    W Japonii.

## Wyłożył trutkę na szczury, zmarło dziecko. Jest wyrok sądu
 - [https://tvn24.pl/pomorze/kamien-pomorski-wylozyl-trutke-na-szczury-zmarlo-dziecko-mezczyzna-skazany-6709271?source=rss](https://tvn24.pl/pomorze/kamien-pomorski-wylozyl-trutke-na-szczury-zmarlo-dziecko-mezczyzna-skazany-6709271?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:46:39+00:00
 - user: None

<img alt="Wyłożył trutkę na szczury, zmarło dziecko. Jest wyrok sądu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vyra42-do-tragedii-doszlo-w-kamieniu-pomorskim-4789053/alternates/LANDSCAPE_1280" />
    Decyzja Sądu Okręgowego w Szczecinie.

## W gruzach znaleźli kota. "Schował się w szafie, przeżył"
 - [https://tvn24.pl/katowice/katowice-w-gruzach-znaleziono-kota-milus-byl-w-szafie-przezyl-plebania-zawalila-sie-po-wybuchu-w-piatek-6708954?source=rss](https://tvn24.pl/katowice/katowice-w-gruzach-znaleziono-kota-milus-byl-w-szafie-przezyl-plebania-zawalila-sie-po-wybuchu-w-piatek-6708954?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:41:32+00:00
 - user: None

<img alt="W gruzach znaleźli kota. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-28dags-milus-zostal-znaleziony-zywy-w-gruzowisku-6709387/alternates/LANDSCAPE_1280" />
    W Katowicach Szopienicach.

## PiS wytyka Nitrasowi "piłowanie katolików". I manipuluje cytatem
 - [https://konkret24.tvn24.pl/polityka/pis-wytyka-nitrasowi-pilowanie-katolikow-i-manipuluje-cytatem-6686470?source=rss](https://konkret24.tvn24.pl/polityka/pis-wytyka-nitrasowi-pilowanie-katolikow-i-manipuluje-cytatem-6686470?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:40:08+00:00
 - user: None

<img alt="PiS wytyka Nitrasowi " src="https://tvn24.pl/najnowsze/cdn-zdjecie-17xncf-beata-mazurek-i-anna-zalewska-pokazaly-ilustracje-ze-zmanipulowanym-cytatem-slawomira-nitrasa-6704595/alternates/LANDSCAPE_1280" />
    PiS wykorzystuje głośną wypowiedź posła PO o Kościele katolickim, tworząc fałszywy przekaz.

## Nie tylko "lex Kaczyński". Jak PiS tworzył prawo korzystne dla rządzących i związanych z władzą
 - [https://tvn24.pl/polska/jaroslaw-kaczynski-zbigniew-ziobro-daniel-obajtek-jak-pis-tworzyl-prawo-korzystne-dla-rzadzacych-i-zwiazanych-z-wladza-6709134?source=rss](https://tvn24.pl/polska/jaroslaw-kaczynski-zbigniew-ziobro-daniel-obajtek-jak-pis-tworzyl-prawo-korzystne-dla-rzadzacych-i-zwiazanych-z-wladza-6709134?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:39:19+00:00
 - user: None

<img alt="Nie tylko " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1lna2y-pap2022052628d-6709380/alternates/LANDSCAPE_1280" />
    Przypominamy kilka przykładów.

## Darowizna na WOŚP i niższy podatek
 - [https://tvn24.pl/biznes/z-kraju/wosp-2023-a-podatek-czy-darowizne-mozna-odliczyc-od-podstawy-opodatkowania-6709194?source=rss](https://tvn24.pl/biznes/z-kraju/wosp-2023-a-podatek-czy-darowizne-mozna-odliczyc-od-podstawy-opodatkowania-6709194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:38:53+00:00
 - user: None

<img alt="Darowizna na WOŚP i niższy podatek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g7v6xa-mid-23129237-6709526/alternates/LANDSCAPE_1280" />
    Wyjaśnia Małgorzata Samborska, doradczyni podatkowa w Grant Thornton.

## Darowizna na WOŚP i niższy podatek
 - [https://tvn24.pl/biznes/z-kraju/czy-darowizne-na-wosp-mozna-odliczyc-od-podstawy-opodatkowania-6709194?source=rss](https://tvn24.pl/biznes/z-kraju/czy-darowizne-na-wosp-mozna-odliczyc-od-podstawy-opodatkowania-6709194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:38:53+00:00
 - user: None

<img alt="Darowizna na WOŚP i niższy podatek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g7v6xa-mid-23129237-6709526/alternates/LANDSCAPE_1280" />
    Wyjaśnia Małgorzata Samborska, doradczyni podatkowa w Grant Thornton.

## Nagrody dla pracowników kolejnych ministerstw. Podano kwoty
 - [https://tvn24.pl/biznes/pieniadze/rzad-pis-nagrody-dla-pracownikow-kolejnych-ministerstw-podano-kwoty-6709277?source=rss](https://tvn24.pl/biznes/pieniadze/rzad-pis-nagrody-dla-pracownikow-kolejnych-ministerstw-podano-kwoty-6709277?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:34:03+00:00
 - user: None

<img alt="Nagrody dla pracowników kolejnych ministerstw. Podano kwoty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5lg8v-pieniadze-pln-shutterstock2176660861-6709493/alternates/LANDSCAPE_1280" />
    Szczegóły.

## Nie żyje jeden z półrocznych bliźniaków. Miesiąc temu szczęśliwie odnaleziono ich po porwaniu
 - [https://tvn24.pl/swiat/usa-nie-zyje-jeden-z-blizniakow-porwanych-w-grudniu-w-columbus-kyair-thomas-zakrztusil-sie-6708923?source=rss](https://tvn24.pl/swiat/usa-nie-zyje-jeden-z-blizniakow-porwanych-w-grudniu-w-columbus-kyair-thomas-zakrztusil-sie-6708923?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:30:49+00:00
 - user: None

<img alt="Nie żyje jeden z półrocznych bliźniaków. Miesiąc temu szczęśliwie odnaleziono ich po porwaniu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eivs4g-nie-zyje-jeden-z-chlopcow-ktorzy-w-grudniu-zostali-porwani-6709342/alternates/LANDSCAPE_1280" />
    Chłopców w grudniu porwano sprzed restauracji w Columbus w stanie Ohio.

## Magda Linette będzie gościem "Kropki nad i"
 - [https://eurosport.tvn24.pl/magda-linette-b-dzie-go-ciem--kropki-nad-i-,1134768.html?source=rss](https://eurosport.tvn24.pl/magda-linette-b-dzie-go-ciem--kropki-nad-i-,1134768.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 12:22:00+00:00
 - user: None

<img alt="Magda Linette będzie gościem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5abuqn-magda-linette/alternates/LANDSCAPE_1280" />
    W poniedziałek o godz. 20.

## "Jedna z najważniejszych decyzji w tej kadencji"
 - [https://tvn24.pl/polska/nowelizacja-ustawy-o-sadzie-najwyzszym-a-kpo-prace-senatu-jakie-poprawki-6709197?source=rss](https://tvn24.pl/polska/nowelizacja-ustawy-o-sadzie-najwyzszym-a-kpo-prace-senatu-jakie-poprawki-6709197?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:58:46+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t6n5mm-komisje-senackie-rozpoczely-prace-nad-nowela-ustawy-o-sadzie-najwyzszym-6709412/alternates/LANDSCAPE_1280" />
    Zapowiedź z Senatu, ruszyły prace.

## Liczba ludności Polski spadła. "Najmniej urodzeń w okresie powojennym"
 - [https://tvn24.pl/biznes/z-kraju/polakow-jest-coraz-mniej-w-2022-najmniej-urodzen-od-ii-wojny-swiatowej-6709176?source=rss](https://tvn24.pl/biznes/z-kraju/polakow-jest-coraz-mniej-w-2022-najmniej-urodzen-od-ii-wojny-swiatowej-6709176?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:55:00+00:00
 - user: None

<img alt="Liczba ludności Polski spadła. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jm2yld-ludzie-tlum-grand-warszawski-shutterstock2231580655-6638375/alternates/LANDSCAPE_1280" />
    Prezes GUS podczas konferencji prasowej.

## Zatrzymali kobietę z nagrania w kościele
 - [https://tvn24.pl/bialystok/suwalki-policja-zatrzymala-24-latke-z-nagrania-przyznala-sie-do-kradziezy-torebki-w-kosciele-6709205?source=rss](https://tvn24.pl/bialystok/suwalki-policja-zatrzymala-24-latke-z-nagrania-przyznala-sie-do-kradziezy-torebki-w-kosciele-6709205?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:47:35+00:00
 - user: None

<img alt="Zatrzymali kobietę z nagrania w kościele" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ww4fzu-zabrala-zostawiona-na-lawce-torebke-6644158/alternates/LANDSCAPE_1280" />
    Przyznała się do kradzieży.

## Lisa Loring nie żyje. Pierwsza odtwórczyni roli Wednesday Addams zmarła w wieku 64 lat
 - [https://tvn24.pl/kultura-i-styl/lisa-loring-nie-zyje-pierwsza-odtworczyni-roli-wednesday-addams-zmarla-w-wieku-64-lat-6709167?source=rss](https://tvn24.pl/kultura-i-styl/lisa-loring-nie-zyje-pierwsza-odtworczyni-roli-wednesday-addams-zmarla-w-wieku-64-lat-6709167?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:43:39+00:00
 - user: None

<img alt="Lisa Loring nie żyje. Pierwsza odtwórczyni roli Wednesday Addams zmarła w wieku 64 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8629ps-lisa-loring-nie-zyje-odtworczyni-roli-wednesday-addams-zmarla-w-wieku-64-lat-6709164/alternates/LANDSCAPE_1280" />
    "Odeszła spokojnie, z córkami  przy boku trzymającymi ją za ręce".

## Trzy, a miejscami nawet cztery pasy. Poszerzą A2 pomiędzy Warszawą a Łodzią
 - [https://tvn24.pl/lodz/autostrada-a2-przetarg-na-poszerzenie-odcinka-pomiedzy-lodzia-a-warszawa-6709343?source=rss](https://tvn24.pl/lodz/autostrada-a2-przetarg-na-poszerzenie-odcinka-pomiedzy-lodzia-a-warszawa-6709343?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:40:21+00:00
 - user: None

<img alt="Trzy, a miejscami nawet cztery pasy. Poszerzą A2 pomiędzy Warszawą a Łodzią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mp9fyf-autostrada-a2-5765897/alternates/LANDSCAPE_1280" />
    GDDKiA ogłasza przetarg, prace mają ruszyć w 2025 roku.

## Naga 16-latka w worku porzuconym na złomowisku. Prokuratura podważa wersję rodziny
 - [https://tvn24.pl/swiat/meksyk-16-letnia-maria-angela-olguin-znaleziona-naga-w-worku-nowe-informacje-6709160?source=rss](https://tvn24.pl/swiat/meksyk-16-letnia-maria-angela-olguin-znaleziona-naga-w-worku-nowe-informacje-6709160?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:35:50+00:00
 - user: None

<img alt="Naga 16-latka w worku porzuconym na złomowisku. Prokuratura podważa wersję rodziny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-acn07a-policja-w-meksyku-6668750/alternates/LANDSCAPE_1280" />
    Jest też nowe nagranie z publicznej kamery.

## Z tej ulgi korzysta około 240 tysięcy osób. To ostatnia chwila na złożenie wniosku
 - [https://tvn24.pl/biznes/dlafirm/maly-zus-plus-termin-do-31012023-komentarz-pawla-zebrowskiego-6709325?source=rss](https://tvn24.pl/biznes/dlafirm/maly-zus-plus-termin-do-31012023-komentarz-pawla-zebrowskiego-6709325?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:35:35+00:00
 - user: None

<img alt="Z tej ulgi korzysta około 240 tysięcy osób. To ostatnia chwila na złożenie wniosku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-sapq8i-porady-w-wyjatkowych-sytuacjach-sa-udzielane-telefonicznie-4545251/alternates/LANDSCAPE_1280" />
    Wyjaśnia rzecznik ZUS Paweł Żebrowski.

## "Zrobili taką poprawkę, żeby ratować Kaczyńskiego"
 - [https://tvn24.pl/polska/lex-kaczynski-poslowie-komentuja-zmiany-w-kodeksie-postepowania-cywilnego-robione-pod-kaczynskiego-6709163?source=rss](https://tvn24.pl/polska/lex-kaczynski-poslowie-komentuja-zmiany-w-kodeksie-postepowania-cywilnego-robione-pod-kaczynskiego-6709163?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 11:00:15+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gk2md4-pap202211041h0-6633833/alternates/LANDSCAPE_1280" />
    Posłowie komentują zmiany w Kodeksie postępowania cywilnego.

## Tajemnicze zaginięcie radioaktywnej kapsuły. Gigant przeprasza
 - [https://tvn24.pl/biznes/ze-swiata/australia-radioaktywna-kapsula-zginela-w-czasie-transportu-rio-tinto-przeprasza-6708952?source=rss](https://tvn24.pl/biznes/ze-swiata/australia-radioaktywna-kapsula-zginela-w-czasie-transportu-rio-tinto-przeprasza-6708952?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:55:22+00:00
 - user: None

<img alt="Tajemnicze zaginięcie radioaktywnej kapsuły. Gigant przeprasza" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-rggw8j-kopalnia-rio-tinto-w-australii-6709055/alternates/LANDSCAPE_1280" />
    Trwają poszukiwania.

## Klienci wrzucali datki do puszki na WOŚP, puszka zniknęła. Policja szuka dwóch mężczyzn
 - [https://tvn24.pl/pomorze/gdansk-ktos-ukradl-ze-sklepu-puszke-z-datkami-na-wosp-policja-szuka-dwoch-mezczyzn-6709141?source=rss](https://tvn24.pl/pomorze/gdansk-ktos-ukradl-ze-sklepu-puszke-z-datkami-na-wosp-policja-szuka-dwoch-mezczyzn-6709141?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:52:43+00:00
 - user: None

<img alt="Klienci wrzucali datki do puszki na WOŚP, puszka zniknęła. Policja szuka dwóch mężczyzn" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v7m9tm-policja-szuka-dwoch-mezczyzn-6709142/alternates/LANDSCAPE_1280" />
    W Gdańsku.

## Szóstka w Lotto warta ponad 2,8 miliona złotych. Podano, gdzie wysłano szczęśliwy kupon
 - [https://tvn24.pl/biznes/z-kraju/prostki-szostka-w-lotto-padla-w-prostkach-6709166?source=rss](https://tvn24.pl/biznes/z-kraju/prostki-szostka-w-lotto-padla-w-prostkach-6709166?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:49:54+00:00
 - user: None

<img alt="Szóstka w Lotto warta ponad 2,8 miliona złotych. Podano, gdzie wysłano szczęśliwy kupon" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e8daeg-emerytka-emeryt-kupon-lotto-senior-shutterstock1464157709-6189722/alternates/LANDSCAPE_1280" />
    To pierwsza szóstka trafiona w tej miejscowości.

## Pytania o "lex Kaczyński". Morawiecki odpowiada
 - [https://tvn24.pl/polska/lex-kaczynski-nowelizacja-kodeksu-postepowania-cywilnego-kaczynski-skorzysta-morawiecki-komentuje-6709035?source=rss](https://tvn24.pl/polska/lex-kaczynski-nowelizacja-kodeksu-postepowania-cywilnego-kaczynski-skorzysta-morawiecki-komentuje-6709035?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:49:03+00:00
 - user: None

<img alt="Pytania o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qox1ww-mateusz-morawiecki-6709041/alternates/LANDSCAPE_1280" />
    Premier o nowelizacji Kodeksu postępowania cywilnego, na której może skorzystać Jarosław Kaczyński.

## Tom Verlaine nie żyje. Jego muzyka inspirowała m.in. Davida Bowiego
 - [https://tvn24.pl/kultura-i-styl/tom-verlaine-nie-zyje-muzyk-mial-73-lata-6709065?source=rss](https://tvn24.pl/kultura-i-styl/tom-verlaine-nie-zyje-muzyk-mial-73-lata-6709065?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:41:16+00:00
 - user: None

<img alt="Tom Verlaine nie żyje. Jego muzyka inspirowała m.in. Davida Bowiego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6ccrk4-tom-verlaine-6709076/alternates/LANDSCAPE_1280" />
    Miał 73 lata.

## "Zmarł nagle, na boisku, wspierając szczytną ideę"
 - [https://tvn24.pl/polska/dariusz-szczepaniak-nie-zyje-zmarly-podczas-finalu-wosp-trener-mial-46-lat-6709070?source=rss](https://tvn24.pl/polska/dariusz-szczepaniak-nie-zyje-zmarly-podczas-finalu-wosp-trener-mial-46-lat-6709070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:33:17+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-smu5zy-dariusz-szczepaniak-6709028/alternates/LANDSCAPE_1280" />
    Tragedia podczas finału WOŚP.

## Niemiecka gospodarka zaskoczyła analityków. "Słaba informacja dla polskiego eksportu"
 - [https://tvn24.pl/biznes/ze-swiata/pkb-niemiec-czwarty-kwartal-2022-niemiecka-gospodarka-ponizej-oczekiwan-komentarze-6709003?source=rss](https://tvn24.pl/biznes/ze-swiata/pkb-niemiec-czwarty-kwartal-2022-niemiecka-gospodarka-ponizej-oczekiwan-komentarze-6709003?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:29:20+00:00
 - user: None

<img alt="Niemiecka gospodarka zaskoczyła analityków. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-444oog-berlin-niemcy-6087831/alternates/LANDSCAPE_1280" />
    Dane Federalnego Urzędu Statystycznego.

## Nowy poziom konfliktu w Trybunale. "Była już prezes" i "bałamutny sposób" procedowania
 - [https://tvn24.pl/polska/trybunal-konstytucyjny-konflikt-w-sprawie-kadencji-julii-przylebskiej-sedzia-muszynski-byla-juz-prezes-tk-6708926?source=rss](https://tvn24.pl/polska/trybunal-konstytucyjny-konflikt-w-sprawie-kadencji-julii-przylebskiej-sedzia-muszynski-byla-juz-prezes-tk-6708926?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:24:12+00:00
 - user: None

<img alt="Nowy poziom konfliktu w Trybunale. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4uf6ia-julia-przylebska-mariusz-muszynski-6709031/alternates/LANDSCAPE_1280" />
    Sędzia Mariusz Muszyński o Julii Przyłębskiej.

## Ostra sprzeczka reprezentantów Polski. Wszystko zarejestrowały kamery
 - [https://eurosport.tvn24.pl/ostra-sprzeczka-reprezentant-w-polski--wszystko-zarejestrowa-y-kamery,1134766.html?source=rss](https://eurosport.tvn24.pl/ostra-sprzeczka-reprezentant-w-polski--wszystko-zarejestrowa-y-kamery,1134766.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:23:10+00:00
 - user: None

<img alt="Ostra sprzeczka reprezentantów Polski. Wszystko zarejestrowały kamery" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6gckpp-piotr-zielinski-i-nicola-zalewski-graja-wspolnie-w-reprezentacji-polski/alternates/LANDSCAPE_1280" />
    Choć obaj zaliczyli po asyście, to na ustach kibiców znaleźli się również z innego powodu.

## Zgwałconej nastolatce odmówiono aborcji. RPO interweniuje
 - [https://tvn24.pl/polska/aborcja-klauzula-sumienia-zgwalconej-nastolatce-odmowiono-aborcji-interwencja-rpo-6708918?source=rss](https://tvn24.pl/polska/aborcja-klauzula-sumienia-zgwalconej-nastolatce-odmowiono-aborcji-interwencja-rpo-6708918?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 10:04:41+00:00
 - user: None

<img alt="Zgwałconej nastolatce odmówiono aborcji. RPO interweniuje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lmquv6-rpo-6708972/alternates/LANDSCAPE_1280" />
    "Ta sytuacja doprowadziła do naruszenia prawa pacjentki do uzyskania świadczenia zdrowotnego".

## "Gazeta Wyborcza": Obajtek zatrudnił znajomą skazaną za defraudację. Oświadczenie Orlenu
 - [https://tvn24.pl/polska/daniel-obajtek-prezes-orlenu-zatrudnil-znajoma-skazana-za-defraudacje-pisze-gazeta-wyborcza-6705593?source=rss](https://tvn24.pl/polska/daniel-obajtek-prezes-orlenu-zatrudnil-znajoma-skazana-za-defraudacje-pisze-gazeta-wyborcza-6705593?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:45:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ieskk4-daniel-obajtek-6634522/alternates/LANDSCAPE_1280" />
    Beata Z. była funkcjonariuszką Agencji Bezpieczeństwa Wewnętrznego, według gazety "została skazana za defraudację funduszu operacyjnego ABW".

## Włoskie media bez wątpliwości. Polacy nie zawiedli w hicie Serie A
 - [https://eurosport.tvn24.pl/w-oskie-media-bez-w-tpliwo-ci--polacy-nie-zawiedli-w-hicie-serie-a,1134759.html?source=rss](https://eurosport.tvn24.pl/w-oskie-media-bez-w-tpliwo-ci--polacy-nie-zawiedli-w-hicie-serie-a,1134759.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:35:37+00:00
 - user: None

<img alt="Włoskie media bez wątpliwości. Polacy nie zawiedli w hicie Serie A" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k0vccj-zielinski-i-zalewski-byli-jednymi-z-bohaterow-hitu-serie-a/alternates/LANDSCAPE_1280" />
    Piotr Zieliński i Nicola Zalewski byli jednymi z kluczowych postaci starcia 20. kolejki pomiędzy Napoli a Romą.

## Tak zagranica robi biznes w Polsce. Jest rekord
 - [https://tvn24.pl/biznes/z-kraju/gospodarka-zagraniczny-biznes-w-polsce-jest-rekord-6708812?source=rss](https://tvn24.pl/biznes/z-kraju/gospodarka-zagraniczny-biznes-w-polsce-jest-rekord-6708812?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:23:16+00:00
 - user: None

<img alt="Tak zagranica robi biznes w Polsce. Jest rekord" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7cuit1-warszawa-ulica-tlum-ludzie-nataly-reinch-shutterstock523956709-6708831/alternates/LANDSCAPE_1280" />
    Największym zaskoczeniem okazali się Rosjanie.

## Eksplozja w meczecie. Rośnie liczba zabitych, dziesiątki rannych
 - [https://tvn24.pl/swiat/pakistan-eksplozja-w-meczecie-w-peszwarze-zabici-i-ranni-6708922?source=rss](https://tvn24.pl/swiat/pakistan-eksplozja-w-meczecie-w-peszwarze-zabici-i-ranni-6708922?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:22:50+00:00
 - user: None

<img alt="Eksplozja w meczecie. Rośnie liczba zabitych, dziesiątki rannych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v2pah5-zamach-w-peszawarze-6709203/alternates/LANDSCAPE_1280" />
    W Peszawarze.

## Eksplozja w meczecie. Wielu zabitych, dziesiątki rannych
 - [https://tvn24.pl/swiat/pakistan-eksplozja-w-meczecie-w-peszwarze-wielu-rannych-6708922?source=rss](https://tvn24.pl/swiat/pakistan-eksplozja-w-meczecie-w-peszwarze-wielu-rannych-6708922?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:22:50+00:00
 - user: None

<img alt="Eksplozja w meczecie. Wielu zabitych, dziesiątki rannych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nnkgzy-pakistan-meczet-6709019/alternates/LANDSCAPE_1280" />
    W Peszawarze.

## Duży skok Linette, Świątek dużo straciła. Przetasowania w rankingu tenisistek
 - [https://eurosport.tvn24.pl/du-y-skok-linette---wi-tek-du-o-straci-a--przetasowania-w-rankingu-tenisistek,1134762.html?source=rss](https://eurosport.tvn24.pl/du-y-skok-linette---wi-tek-du-o-straci-a--przetasowania-w-rankingu-tenisistek,1134762.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:11:00+00:00
 - user: None

<img alt="Duży skok Linette, Świątek dużo straciła. Przetasowania w rankingu tenisistek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-enbglp-linette-zaliczyla-spory-awans-w-rankingu-wta/alternates/LANDSCAPE_1280" />
    Sporo zmian po wielkoszlemowym Australian Open.

## Polska gospodarka wyhamowała. Nowe dane GUS
 - [https://tvn24.pl/biznes/z-kraju/pkb-polski-2022-polska-gospodarka-wyhamowala-gus-podal-dane-6704694?source=rss](https://tvn24.pl/biznes/z-kraju/pkb-polski-2022-polska-gospodarka-wyhamowala-gus-podal-dane-6704694?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 09:05:41+00:00
 - user: None

<img alt="Polska gospodarka wyhamowała. Nowe dane GUS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bnbvho-plansza-pilne-szeroki-drv-4712015/alternates/LANDSCAPE_1280" />
    Dane za 2022 rok.

## Posłowie latali za ponad 5 milionów złotych. "Mamy duży problem"
 - [https://tvn24.pl/biznes/z-kraju/loty-poslow-2022-lukasz-mejza-na-czele-krzysztof-izdebski-komentuje-6708296?source=rss](https://tvn24.pl/biznes/z-kraju/loty-poslow-2022-lukasz-mejza-na-czele-krzysztof-izdebski-komentuje-6708296?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 08:48:34+00:00
 - user: None

<img alt="Posłowie latali za ponad 5 milionów złotych. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-t9vmyk-kolejne-panstwa-zamykaja-przestrzen-powietrzna-dla-rosyjskich-samolotow-5614301/alternates/LANDSCAPE_1280" />
    Gościem "Wstajesz i wiesz" w TVN24 był Krzysztof Izdebski.

## Komitet nadzorujący realizację KPO może się zbierać raz na rok. "To będzie fasadowa instytucja"
 - [https://tvn24.pl/premium/komitet-nadzorujacy-realizacje-kpo-moze-sie-zbierac-raz-na-rok-to-bedzie-fasadowa-instytucja-6707826?source=rss](https://tvn24.pl/premium/komitet-nadzorujacy-realizacje-kpo-moze-sie-zbierac-raz-na-rok-to-bedzie-fasadowa-instytucja-6707826?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 08:38:28+00:00
 - user: None

<img alt="Komitet nadzorujący realizację KPO może się zbierać raz na rok. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ss1chu-siedziba-ministerstwa-funduszy-i-polityki-regionalnej-6708806/alternates/LANDSCAPE_1280" />
    Komitet, który ma monitorować realizację Krajowego Planu Odbudowy, ma obowiązek zbierać się zaledwie raz w roku - wynika z projektu regulaminu tego gremium, do którego dotarli dziennikarze TVN24 i tvn24.pl. Według naszych informacji część samorządowców, którzy są członkami komitetu, nie zgadza się na przyjęcie regulaminu. Ich zdaniem akceptacja dokumentu w tym kształcie sprawi, że to będzie fasadowa instytucja.

## Dłuższa praca albo bieda. Ekonomiści nie mają złudzeń
 - [https://tvn24.pl/biznes/pieniadze/dluzsza-praca-albo-bieda-ekonomisci-nie-maja-zludzen-6708180?source=rss](https://tvn24.pl/biznes/pieniadze/dluzsza-praca-albo-bieda-ekonomisci-nie-maja-zludzen-6708180?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 08:15:53+00:00
 - user: None

<img alt="Dłuższa praca albo bieda. Ekonomiści nie mają złudzeń" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecieb1e9ee3f53303b0ec6e065ac0de965f2-emeryci-przejda-szkolenia-4313844/alternates/LANDSCAPE_1280" />
    Pytania o wiek emerytalny.

## Magda Linette i Iga Świątek grają z WOŚP. Imponujące kwoty za kolację oraz rakietę
 - [https://eurosport.tvn24.pl/iga--wi-tek-i-magda-linette-graj--z-wo-p--imponuj-ce-kwoty-za-kolacj--oraz-rakiet-,1134758.html?source=rss](https://eurosport.tvn24.pl/iga--wi-tek-i-magda-linette-graj--z-wo-p--imponuj-ce-kwoty-za-kolacj--oraz-rakiet-,1134758.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:47:56+00:00
 - user: None

<img alt="Magda Linette i Iga Świątek grają z WOŚP. Imponujące kwoty za kolację oraz rakietę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qol1hz-linette-i-swiatek/alternates/LANDSCAPE_1280" />
    Najlepsze polskie tenisistki ponownie włączyły się w szczytną akcję.

## Lawina śnieżna w Tatrach porwała dwóch wspinaczy. Nie żyją
 - [https://tvn24.pl/polska/lawina-sniezna-w-tatrach-porwala-dwoch-wspinaczy-nie-zyja-6708143?source=rss](https://tvn24.pl/polska/lawina-sniezna-w-tatrach-porwala-dwoch-wspinaczy-nie-zyja-6708143?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:28:41+00:00
 - user: None

<img alt="Lawina śnieżna w Tatrach porwała dwóch wspinaczy. Nie żyją" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kaf2v5-lawina-zeszla-w-slowackich-tatrach-nie-zyja-dwie-osoby-6707909/alternates/LANDSCAPE_1280" />
    W słowackiej Dolinie Staroleśnej.

## Nie żyje Annie Wersching. Aktorka zmarła w wieku zaledwie 45 lat
 - [https://tvn24.pl/kultura-i-styl/annie-wersching-nie-zyje-aktorka-zmarla-w-wieku-45-lat-6707062?source=rss](https://tvn24.pl/kultura-i-styl/annie-wersching-nie-zyje-aktorka-zmarla-w-wieku-45-lat-6707062?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:26:23+00:00
 - user: None

<img alt="Nie żyje Annie Wersching. Aktorka zmarła w wieku zaledwie 45 lat " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2pqjzf-annie-wersching-6705594/alternates/LANDSCAPE_1280" />
    Była gwiazdą serialu "24 godziny". Jej głos znają fani "The Last of Us".

## "16 miejsc w jednym momencie", "dopalanie" mikrofonów. Tak relacjonowaliśmy 31. Finał WOŚP
 - [https://tvn24.pl/wosp-2023/wosp-2023-31-final-relacja-w-tvn24-6706618?source=rss](https://tvn24.pl/wosp-2023/wosp-2023-31-final-relacja-w-tvn24-6706618?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:20:20+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kba2bu-praca-0009-6707037/alternates/LANDSCAPE_1280" />
    Podobnie jak w poprzednich latach, TVN Warner Bros. Discovery był partnerem i telewizyjnym gospodarzem Orkiestry.

## Kubacki na podium listy płac. Zdecydowany lider
 - [https://eurosport.tvn24.pl/kubacki-na-podium-listy-p-ac--zdecydowany-lider,1134755.html?source=rss](https://eurosport.tvn24.pl/kubacki-na-podium-listy-p-ac--zdecydowany-lider,1134755.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:15:57+00:00
 - user: None

<img alt="Kubacki na podium listy płac. Zdecydowany lider" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g33i5p-dawid-kubacki/alternates/LANDSCAPE_1280" />
    Norweg Halvor Egner Granerud dominuje.

## Mężczyzna zginął. 17 osób, w tym sześcioro dzieci, ewakuowano
 - [https://tvn24.pl/lodz/zgierz-pozar-kamienicy-przy-ulicy-szerokiej-nie-zyje-jedna-osoba-6707125?source=rss](https://tvn24.pl/lodz/zgierz-pozar-kamienicy-przy-ulicy-szerokiej-nie-zyje-jedna-osoba-6707125?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 07:01:49+00:00
 - user: None

<img alt="Mężczyzna zginął. 17 osób, w tym sześcioro dzieci, ewakuowano" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fv4ovu-w-pozarze-zginal-60-letni-mezczyzna-6706804/alternates/LANDSCAPE_1280" />
    Tragiczny pożar w Zgierzu

## Celem ataków było sześć ciężarówek. "Przewoziły irańską broń"
 - [https://tvn24.pl/swiat/syryjskie-obserwatorium-praw-czlowieka-atak-na-konwoj-z-iranska-bronia-sa-zabici-i-ranni-6706096?source=rss](https://tvn24.pl/swiat/syryjskie-obserwatorium-praw-czlowieka-atak-na-konwoj-z-iranska-bronia-sa-zabici-i-ranni-6706096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:58:09+00:00
 - user: None

<img alt="Celem ataków było sześć ciężarówek. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-20j0g8-syria-irak-mapa-6704951/alternates/LANDSCAPE_1280" />
    Poinformowało Syryjskie Obserwatorium Praw Człowieka.

## Byli w aucie, gdy uderzyło tornado. "Nie było dokąd uciekać. Przerażające doświadczenie"
 - [https://tvn24.pl/tvnmeteo/swiat/teksas-usa-nie-zdazyli-uciec-przed-tornadem-musieli-przetrwac-je-chroniac-sie-w-aucie-wideo-6705596?source=rss](https://tvn24.pl/tvnmeteo/swiat/teksas-usa-nie-zdazyli-uciec-przed-tornadem-musieli-przetrwac-je-chroniac-sie-w-aucie-wideo-6705596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:51:32+00:00
 - user: None

<img alt="Byli w aucie, gdy uderzyło tornado. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ljwmpi-tornado-z-wnetrza-auta-6706099/alternates/LANDSCAPE_1280" />
    Nagranie.

## "Doszło do poważnego naruszenia kodeksu ministerialnego". Zwolniony
 - [https://tvn24.pl/swiat/wielka-brytania-nadhim-zahawi-przewodniczacy-rzadzacej-partii-konserwatywnej-zwolniony-za-unikanie-podatkow-6695343?source=rss](https://tvn24.pl/swiat/wielka-brytania-nadhim-zahawi-przewodniczacy-rzadzacej-partii-konserwatywnej-zwolniony-za-unikanie-podatkow-6695343?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:51:16+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2h25m1-nadhim-zahawi-6699566/alternates/LANDSCAPE_1280" />
    Rishi Sunak zwolnił Nadhima Zahawiego.

## Ostatnia akcja pozbawiła PSG wygranej
 - [https://eurosport.tvn24.pl/ostatnia-akcja-pozbawi-a-psg-wygranej---frustruj-cy-wiecz-r-,1134752.html?source=rss](https://eurosport.tvn24.pl/ostatnia-akcja-pozbawi-a-psg-wygranej---frustruj-cy-wiecz-r-,1134752.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:46:47+00:00
 - user: None

<img alt="Ostatnia akcja pozbawiła PSG wygranej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7n8zwx-psg-tylko-zremisowalo-z-reims-11/alternates/LANDSCAPE_1280" />
    Niespodzianka na Parc des Princes.

## Polska "cichym bohaterem stojącym za tą przełomową decyzją"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-atlantic-council-o-wyslaniu-na-ukraine-czolgow-przez-niemcy-i-usa-polska-cichym-bohaterem-przelomowej-decyzji-6700230?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-atlantic-council-o-wyslaniu-na-ukraine-czolgow-przez-niemcy-i-usa-polska-cichym-bohaterem-przelomowej-decyzji-6700230?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:32:16+00:00
 - user: None

<img alt="Polska " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u6326a-leopard-2a7v-nalezacy-do-bundeswehry-6677324/alternates/LANDSCAPE_1280" />
    O roli Polski w europejskiej odpowiedzi na inwazję Putina.

## Aż trzech graczy mistrzów Polski w drużynie gwiazd mundialu
 - [https://eurosport.tvn24.pl/a--trzech-graczy-mistrz-w-polski-w-dru-ynie-gwiazd-mundialu,1134751.html?source=rss](https://eurosport.tvn24.pl/a--trzech-graczy-mistrz-w-polski-w-dru-ynie-gwiazd-mundialu,1134751.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:29:00+00:00
 - user: None

<img alt="Aż trzech graczy mistrzów Polski w drużynie gwiazd mundialu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-v6mk1e-kilku-zawodnikow-wroci-do-kielc-z-medalami/alternates/LANDSCAPE_1280" />
    W najlepszej siódemce mundialu piłkarzy ręcznych. O kogo chodzi?

## "W ciągu tygodnia rozstrzygniemy kierunek"
 - [https://tvn24.pl/biznes/nieruchomosci/podatek-od-mieszkan-zmiany-minister-rozwoju-i-technologii-waldemar-buda-o-projekcie-6704778?source=rss](https://tvn24.pl/biznes/nieruchomosci/podatek-od-mieszkan-zmiany-minister-rozwoju-i-technologii-waldemar-buda-o-projekcie-6704778?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:27:22+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vnfric-mieszkanie-blok-warszawa-nieruchomosc-5668227/alternates/LANDSCAPE_1280" />
    Wyższy podatek i ograniczenia przy zakupie mieszkań.

## Johnson: Putin "jakby mi zagroził"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-borisjohnson-o-rozmowie-telefonicznej-z-wladimirem-putinem-grozil-mi-uderzeniem-rakietowym-6703635?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-borisjohnson-o-rozmowie-telefonicznej-z-wladimirem-putinem-grozil-mi-uderzeniem-rakietowym-6703635?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:25:56+00:00
 - user: None

<img alt="Johnson: Putin " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qqoa7o-boris-johnson-w-miejscowosci-borodzianka-6643839/alternates/LANDSCAPE_1280" />
    Były premier Wielkiej Brytanii opowiedział o rozmowie telefonicznej, jaką odbył jeszcze przed rosyjską inwazją na Ukrainę.

## Trzy auta zderzyły się na S8. "Korek ma pięć kilometrów"
 - [https://tvn24.pl/tvnwarszawa/ulice/konotopa-zderzenie-trzech-aut-na-s8-duze-utrudnienia-6705476?source=rss](https://tvn24.pl/tvnwarszawa/ulice/konotopa-zderzenie-trzech-aut-na-s8-duze-utrudnienia-6705476?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 06:25:50+00:00
 - user: None

<img alt="Trzy auta zderzyły się na S8. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-69femp-zderzenie-na-s8-6705640/alternates/LANDSCAPE_1280" />
    Utrudnienia w porannym szczycie.

## Erdogan: Finlandia nie powinna popełnić tego samego błędu
 - [https://tvn24.pl/swiat/prezydent-turcji-recep-tayyip-erdogan-zasugerowal-zatwierdzenie-kandydatury-finlandii-do-nato-6703607?source=rss](https://tvn24.pl/swiat/prezydent-turcji-recep-tayyip-erdogan-zasugerowal-zatwierdzenie-kandydatury-finlandii-do-nato-6703607?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:48:00+00:00
 - user: None

<img alt="Erdogan: Finlandia nie powinna popełnić tego samego błędu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ukv8nb-erdogan-6596183/alternates/LANDSCAPE_1280" />
    Co z rozszerzeniem NATO? Zapowiedź tureckiego prezydenta.

## Intensywne opady śniegu i porywisty wiatr. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-wiatr-sniezyce-wichury-gdzie-spadnie-snieg-pogoda-w-poniedzialek-3001-6703632?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-wiatr-sniezyce-wichury-gdzie-spadnie-snieg-pogoda-w-poniedzialek-3001-6703632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:32:00+00:00
 - user: None

<img alt="Intensywne opady śniegu i porywisty wiatr. IMGW ostrzega" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-a3plke-silny-wiatr-6559607/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie aura będzie niebezpieczna.

## Miejscami dosypie nawet 20 centymetrów śniegu. IMGW ostrzega przed śnieżycami i silnym wiatrem
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-silny-wiatr-wiatr-sniezyce-wichury-gdzie-spadnie-snieg-pogoda-w-poniedzialek-3001-6703632?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-intensywne-opady-sniegu-silny-wiatr-wiatr-sniezyce-wichury-gdzie-spadnie-snieg-pogoda-w-poniedzialek-3001-6703632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:32:00+00:00
 - user: None

<img alt="Miejscami dosypie nawet 20 centymetrów śniegu. IMGW ostrzega przed śnieżycami i silnym wiatrem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-v0sdzi-intensywne-opady-sniegu-6590567/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie wydano ostrzeżenia.

## Śnieżyce, gołoledź, wichury. Alerty IMGW przed szeregiem pogodowych niebezpieczeństw
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-sniezyce-gololedz-wichury-ostrzezenia-dla-wiekszosci-kraju-pogoda-w-poniedzialek-3001-6703632?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-sniezyce-gololedz-wichury-ostrzezenia-dla-wiekszosci-kraju-pogoda-w-poniedzialek-3001-6703632?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:32:00+00:00
 - user: None

<img alt="Śnieżyce, gołoledź, wichury. Alerty IMGW przed szeregiem pogodowych niebezpieczeństw " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t54kfv-opady-beda-zamarzac-4766915/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie pogoda da nam się we znaki.

## Ukraiński wywiad: Prigożyn nie kieruje już Grupą Wagnera, ma nowe "kluczowe zadania"
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-ukrainski-wywiad-jewgienij-prigozyn-nie-kieruje-juz-sztabem-grupy-wagnera-6690671?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-ukrainski-wywiad-jewgienij-prigozyn-nie-kieruje-juz-sztabem-grupy-wagnera-6690671?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:28:00+00:00
 - user: None

<img alt="Ukraiński wywiad: Prigożyn nie kieruje już Grupą Wagnera, ma nowe " src="https://tvn24.pl/najnowsze/cdn-zdjecie-w0m2ge-prigozyn-6596998/alternates/LANDSCAPE_1280" />
    Ustalenia przekazał przedstawiciel ukraińskiego wywiadu wojskowego.

## "Polski arcyrywal ponownie rozczarował"
 - [https://eurosport.tvn24.pl/norwegowie--wi-tuj--po-wygranej-graneruda---polski-arcyrywal-ponownie-rozczarowa--,1134708.html?source=rss](https://eurosport.tvn24.pl/norwegowie--wi-tuj--po-wygranej-graneruda---polski-arcyrywal-ponownie-rozczarowa--,1134708.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:21:21+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w7ocqb-granerud-imponuje-forma/alternates/LANDSCAPE_1280" />
    Norwegowie świętują po wygranej Graneruda.

## Minister obrony Ukrainy: uzgadniamy przekazanie samolotów
 - [https://tvn24.pl/swiat/ukraina-rosja-dostawy-samolotow-bojowych-z-zachodu-minister-obrony-ukrainy-reznikow-odpowiada-6703627?source=rss](https://tvn24.pl/swiat/ukraina-rosja-dostawy-samolotow-bojowych-z-zachodu-minister-obrony-ukrainy-reznikow-odpowiada-6703627?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:20:32+00:00
 - user: None

<img alt="Minister obrony Ukrainy: uzgadniamy przekazanie samolotów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-voth64-samolot-ukraina-6149381/alternates/LANDSCAPE_1280" />
    "Zapisałem swoje życzenia w liście do Świętego Mikołaja. Ta lista pozostaje w mocy".

## Deklaracja Scholza w sprawie samolotów bojowych dla Ukrainy
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-30-stycznia-2023-6701116?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-30-stycznia-2023-6701116?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:05:41+00:00
 - user: None

<img alt="Deklaracja Scholza w sprawie samolotów bojowych dla Ukrainy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n8vxec-olaf-scholz-z-wizyta-w-chile-6703616/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## "Nie mają w sobie odwagi". Skrzywanek wskazuje ministra, arcybiskupa i prezydenta
 - [https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-117,S00E117,977416?source=rss](https://tvn24.pl/go/programy,7/bez-polityki-odcinki,413879/odcinek-117,S00E117,977416?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 05:00:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hw5uct-jakub-skrzywanek-i-piotr-jacon-6684795/alternates/LANDSCAPE_1280" />
    Jakub Skrzywanek - utalentowany reżyser, laureat Paszportu "Polityki" - w rozmowie z Piotrem Jaconiem.

## Gratulacje i zaproszenie do Kijowa. Pierwsza taka rozmowa
 - [https://tvn24.pl/swiat/czechy-prezydent-elekt-petr-pavel-rozmawial-z-prezydentem-ukrainy-zelenski-zaprosil-pavla-do-kijowa-6686979?source=rss](https://tvn24.pl/swiat/czechy-prezydent-elekt-petr-pavel-rozmawial-z-prezydentem-ukrainy-zelenski-zaprosil-pavla-do-kijowa-6686979?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 04:50:00+00:00
 - user: None

<img alt="Gratulacje i zaproszenie do Kijowa. Pierwsza taka rozmowa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m6folt-petr-pavel-6688993/alternates/LANDSCAPE_1280" />
    Po wyborze na prezydenta.

## Ile zebrano w 31. Finale WOŚP. Kwota ogłoszona na koniec dnia
 - [https://tvn24.pl/wosp-2023/wosp-2023-ile-pieniedzy-zebrano-w-niedziele-podczas-31-finalu-wielkiej-orkiestry-swiatecznej-pomocy-6686972?source=rss](https://tvn24.pl/wosp-2023/wosp-2023-ile-pieniedzy-zebrano-w-niedziele-podczas-31-finalu-wielkiej-orkiestry-swiatecznej-pomocy-6686972?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 04:35:00+00:00
 - user: None

<img alt="Ile zebrano w 31. Finale WOŚP. Kwota ogłoszona na koniec dnia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cddjpg-jerzy-owsiak-6703624/alternates/LANDSCAPE_1280" />
    Zbiórka pieniędzy na walkę z sepsą.

## Przejść do "gospodarki wojennej". Apeluje szef komitetu wojskowego NATO
 - [https://tvn24.pl/swiat/ukraina-rosja-admiral-rob-bauer-szef-komitetu-wojskowego-nato-przejsc-do-gospodarki-wojennej-6699575?source=rss](https://tvn24.pl/swiat/ukraina-rosja-admiral-rob-bauer-szef-komitetu-wojskowego-nato-przejsc-do-gospodarki-wojennej-6699575?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-30 04:22:45+00:00
 - user: None

<img alt="Przejść do " src="https://tvn24.pl/najnowsze/cdn-zdjecie-im1al3-admiral-rob-bauer-6639723/alternates/LANDSCAPE_1280" />
    Admirał Rob Bauer w rozmowie z portugalską telewizją.
