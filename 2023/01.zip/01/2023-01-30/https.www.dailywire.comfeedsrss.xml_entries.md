# Source Daily Wire, Source URL:https://www.dailywire.com/feeds/rss.xml, Source language: en-US

## Reforming Social Security And Medicare ‘Off The Table’ In Debt Negotiations, McCarthy Says
 - [https://www.dailywire.com/news/reforming-social-security-and-medicare-off-the-table-in-debt-negotiations-mccarthy-says](https://www.dailywire.com/news/reforming-social-security-and-medicare-off-the-table-in-debt-negotiations-mccarthy-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 18:02:03+00:00
 - user: None

House Speaker Kevin McCarthy (R-CA) said that spending cuts to Social Security and Medicare are “off the table” as lawmakers seek to fund the government while reducing deficits. McCarthy plans to meet with President Joe Biden on Wednesday to discuss possible budget cuts after the debt ceiling, an arbitrary cap on the national debt established ...

## It’s Time To Say Goodbye To Sam Smith — His Latest Music Video Belongs In The Trash
 - [https://www.dailywire.com/news/its-time-to-say-goodbye-to-sam-smith-his-latest-music-video-belongs-in-the-trash](https://www.dailywire.com/news/its-time-to-say-goodbye-to-sam-smith-his-latest-music-video-belongs-in-the-trash)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 17:56:19+00:00
 - user: None

Singer Sam Smith has released a new music video. First, let me say this about this incredible performer: I loved his music.  But with his latest release “I&#8217;m Not Here to Make Friends,” I can no longer love it. Even though Sam is tremendously talented, I am now going to have to dump his incredible ...

## Gary Sinise Talks About Being A Conservative In Hollywood And How It Affected His Career
 - [https://www.dailywire.com/news/gary-sinise-talks-about-being-a-conservative-in-hollywood-and-how-it-affected-his-career](https://www.dailywire.com/news/gary-sinise-talks-about-being-a-conservative-in-hollywood-and-how-it-affected-his-career)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 17:50:10+00:00
 - user: None

Hollywood star Gary Sinise knows being a conservative in Tinseltown isn&#8217;t easy, but acknowledged that he&#8217;s had a great career despite being outspoken about his political beliefs. During Friday&#8217;s episode of CNN&#8217;s &#8220;Who&#8217;s Talking to Chris Wallace?,&#8221; the host asked the 67-year-old actor about his decision to start the conservative group, Friends of Abe, for ...

## Monday Afternoon Update: Pro-Life Father Acquitted After Biden Raid, Utah Bans Sex-Change Surgeries For Minors, Ice Storm Threatens South
 - [https://www.dailywire.com/news/monday-afternoon-update-pro-life-father-acquitted-after-biden-raid-utah-bans-sex-change-surgeries-for-minors-ice-storm-threatens-south](https://www.dailywire.com/news/monday-afternoon-update-pro-life-father-acquitted-after-biden-raid-utah-bans-sex-change-surgeries-for-minors-ice-storm-threatens-south)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 17:39:37+00:00
 - user: None

This article is a companion piece to today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. Sixth Police Officer Disciplined In Tyre Nichols Beating Memphis Police say a 6th officer has been disciplined for his involvement in the brutal beating and arrest of Tyre Nichols. The department revealed that officer Preston Hemphill ...

## Marilyn Manson Accused Of Sexually Assaulting 16-Year-Old On Tour Bus, Threatened To Kill Family: Lawsuit
 - [https://www.dailywire.com/news/marilyn-manson-accused-of-sexually-assaulting-16-year-old-minor-on-tour-bus-threatened-to-kill-family-lawsuit](https://www.dailywire.com/news/marilyn-manson-accused-of-sexually-assaulting-16-year-old-minor-on-tour-bus-threatened-to-kill-family-lawsuit)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 17:20:03+00:00
 - user: None

An anonymous woman filed a lawsuit against singer Marilyn Manson for allegedly grooming and sexually assaulting her multiple times when she was underage in the 1990s. Plaintiff &#8220;Jane Doe&#8221; filed the lawsuit in Nassau County Supreme Court in Long Island, New York, on Monday against Manson, whose real name is Brain Warner, and his former ...

## NFL Great Michael Irvin Decries Death Of Tyre Nichols, Draws Bizarre Comparison
 - [https://www.dailywire.com/news/nfl-great-michael-irvin-decries-death-of-tyre-nichols-draws-bizarre-comparison](https://www.dailywire.com/news/nfl-great-michael-irvin-decries-death-of-tyre-nichols-draws-bizarre-comparison)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 16:59:01+00:00
 - user: None

NFL Hall of Famer Michael Irvin said he&#8217;s &#8220;tired of seeing black men fight black men&#8221; after five Memphis police officers were charged in the death of Tyre Nichols, and drew an ill-advised comparison to Will Smith slapping Chris Rock last year. During ESPN&#8217;s &#8220;First Take&#8221; on Monday, sports host Ryan Clark talked about the ...

## Ted Cruz Pushes For DHS Secretary Alejandro Mayorkas To Be Impeached Quickly
 - [https://www.dailywire.com/news/ted-cruz-pushes-for-dhs-secretary-alejandro-mayorkas-to-be-impeached-quickly](https://www.dailywire.com/news/ted-cruz-pushes-for-dhs-secretary-alejandro-mayorkas-to-be-impeached-quickly)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 16:43:35+00:00
 - user: None

Sen. Ted Cruz (R-TX) is advocating for the quick removal of Department of Homeland Security Secretary Alejandro Mayorkas as the illegal immigration crisis on the southern border shows no signs of slowing down. Cruz&#8217;s remarks come after U.S. Customs and Border Protection (CBP) had 251,487 encounters with illegal aliens last month, the highest number ever ...

## The U.S. Is Barreling Toward World War III: Where Have All The Peacemakers Gone?
 - [https://www.dailywire.com/news/the-u-s-is-barreling-toward-world-war-iii-where-have-all-the-peacemakers-gone](https://www.dailywire.com/news/the-u-s-is-barreling-toward-world-war-iii-where-have-all-the-peacemakers-gone)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 16:33:12+00:00
 - user: None

If any three men have been most outspoken in their desire for peace between Ukraine and Russia, it has been former President Donald J. Trump, the Vicar of Christ Pope Francis, and former Secretary of State Henry Kissinger. The oddball trio standing athwart America&#8217;s military-industrial complex raises two questions: Where have all the peacemakers gone? ...

## Super Bowl-Bound Chiefs QB Patrick Mahomes Praises God For Getting Him There
 - [https://www.dailywire.com/news/super-bowl-bound-chiefs-qb-patrick-mahomes-praises-god-for-getting-him-there](https://www.dailywire.com/news/super-bowl-bound-chiefs-qb-patrick-mahomes-praises-god-for-getting-him-there)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 16:24:14+00:00
 - user: None

Chiefs QB Patrick Mahomes praised God for getting him well enough to play in the AFC Championship against the Bengals. His team ultimately beat them, giving the Chiefs another return to the Super Bowl. Mahomes, who had suffered a high-ankle sprain going into the game, spoke to CBS reporter Tracy Wolfson following Kansas City&#8217;s 23-20 ...

## Lowe’s Successfully Tests Way To Stop Retail Theft Without Locking Down Products
 - [https://www.dailywire.com/news/lowes-successfully-tests-way-to-stop-retail-theft-without-locking-down-products](https://www.dailywire.com/news/lowes-successfully-tests-way-to-stop-retail-theft-without-locking-down-products)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:57:49+00:00
 - user: None

Lowe’s successfully tested a mechanism to track and lock items with low-cost radio frequency identification chips such that power tools and other equipment will not function if they are stolen. Thefts executed by packs of robbers have garnered public attention during the crime wave of the past three years, with some retailers and convenience chains ...

## Minnesota Compared To North Korea, China For Extreme Abortion Bill About To Pass
 - [https://www.dailywire.com/news/minnesota-compared-to-north-korea-china-for-extreme-abortion-bill-about-to-pass](https://www.dailywire.com/news/minnesota-compared-to-north-korea-china-for-extreme-abortion-bill-about-to-pass)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:57:19+00:00
 - user: None

If, as expected, Minnesota Democratic governor signs a bill just passed by the Minnesota Senate, the state will permit a right to abortion at any time of a woman’s pregnancy. “Every individual who becomes pregnant has a fundamental right to continue the pregnancy and give birth, or obtain an abortion, and to make autonomous decisions about how ...

## YouTuber MrBeast Puts Billionaires Like Bezos, Musk To Shame With His Love Of Humanity
 - [https://www.dailywire.com/news/youtuber-mrbeast-puts-billionaires-like-bezos-musk-to-shame-with-his-love-of-humanity](https://www.dailywire.com/news/youtuber-mrbeast-puts-billionaires-like-bezos-musk-to-shame-with-his-love-of-humanity)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:48:13+00:00
 - user: None

The top 10 most wealthy people in the world, according to Forbes, are worth a combined $1,187,000,000,000. Yup, that&#8217;s more than a trillion dollars. Some of them you&#8217;ve heard of (Elon Musk, Jeff Bezos, Warren Buffett, Bill Gates), but others you haven&#8217;t (including No. 1, Bernard Arnault and family, who are worth more than $211 ...

## Comer On Biden’s Doc Scandal: ‘He’s Also Being Investigated For Influence Peddling With Our Adversaries’
 - [https://www.dailywire.com/news/comer-on-bidens-doc-scandal-hes-also-being-investigated-for-influence-peddling-with-our-adversaries](https://www.dailywire.com/news/comer-on-bidens-doc-scandal-hes-also-being-investigated-for-influence-peddling-with-our-adversaries)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:47:43+00:00
 - user: None

House Oversight Committee Chairman James Comer (R-KY) said during an interview Monday that President Joe Biden was under investigation for allegedly &#8220;influence peddling with our adversaries.&#8221; Comer made the remarks during an interview on Fox News&#8217;s &#8220;Fox &amp; Friends First&#8221; while discussing Biden&#8217;s classified document scandal. Comer said that the National Archives was coming before ...

## Pro-Life Father Acquitted Of Federal Charges, Attorney Rips Biden Admin ‘Intimidation’
 - [https://www.dailywire.com/news/mark-houck-catholic-pro-life-activist-facing-11-years-in-prison-acquitted-at-trial](https://www.dailywire.com/news/mark-houck-catholic-pro-life-activist-facing-11-years-in-prison-acquitted-at-trial)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:40:48+00:00
 - user: None

A Catholic pro-life activist facing 11 years in prison for allegedly violating a federal law prohibiting people from blocking others from entering an abortion clinic was acquitted on Monday following a week-long trial. Mark Houck leads a nonprofit group that counsels women outside of abortion clinics in Philadelphia, Pennsylvania. He was providing sidewalk counseling when, ...

## CEO Backtracks After Quoting Martin Luther King Jr. In Layoff Announcement: ‘Inappropriate And Insensitive’
 - [https://www.dailywire.com/news/ceo-backtracks-after-quoting-martin-luther-king-jr-in-layoff-announcement-inappropriate-and-insensitive](https://www.dailywire.com/news/ceo-backtracks-after-quoting-martin-luther-king-jr-in-layoff-announcement-inappropriate-and-insensitive)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:26:45+00:00
 - user: None

PagerDuty CEO Jennifer Tejada apologized after quoting Martin Luther King Jr. while announcing that her company would implement mass layoffs. Tejada revealed in a company memo last week that roughly 7% of positions at the cloud computing firm would be eliminated to reduce costs and improve return on investment. “Like most technology companies, our most ...

## The Solution To Human Trafficking Is Hiding In Plain Sight
 - [https://www.dailywire.com/news/the-solution-to-human-trafficking-is-hiding-in-plain-sight](https://www.dailywire.com/news/the-solution-to-human-trafficking-is-hiding-in-plain-sight)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:24:28+00:00
 - user: None

An estimated 4.5 million people worldwide are victims of forced sexual exploitation. One in six teenage runaways become sex trafficking victims. Children, in fact, make up 20% of all trafficking victims. The statistics are staggering and tragic. They are motivating factors, though, in January being recognized as “Human Trafficking Awareness Month.” And while awareness is appreciated, ...

## ‘Dancing On The Graves Of The 2,278 Homicide Victims’: Lightfoot Blasted For Dancing While Chicago Fails
 - [https://www.dailywire.com/news/dancing-on-the-graves-of-the-2278-homicide-victims-lightfoot-blasted-for-dancing-while-chicago-fails](https://www.dailywire.com/news/dancing-on-the-graves-of-the-2278-homicide-victims-lightfoot-blasted-for-dancing-while-chicago-fails)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:16:05+00:00
 - user: None

Chicago Mayor Lori Lightfoot was slammed after video showed her dancing in the street in Chicago’s Lunar New Year parade Sunday. Crime has soared in Chicago in 2023; overall crime in January is 61% higher than it was in January 2022. “Since @chicagosmayor &#8216;s term began, Chicago has suffered 2,278 homicides and over 9,000 shot,” ...

## Priscilla Presley Contests Amendment To Late Daughter’s Will — Lisa Marie Reportedly Cut Her Out
 - [https://www.dailywire.com/news/priscilla-presley-contests-amendment-to-late-daughters-will-lisa-marie-reportedly-cut-her-out](https://www.dailywire.com/news/priscilla-presley-contests-amendment-to-late-daughters-will-lisa-marie-reportedly-cut-her-out)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 15:04:36+00:00
 - user: None

Priscilla Presley has reportedly contested her late daughter&#8217;s will, filing court documents on Thursday in Los Angeles that challenge the validity of a 2016 amendment removing her and a former business manager as trustees. Lisa Marie Presley, Priscilla&#8217;s daughter with her late husband and singer Elvis Presley, had died two weeks earlier after going into ...

## Sam Bankman-Fried Attempted To Tamper With Witness, Prosecutors Allege
 - [https://www.dailywire.com/news/sam-bankman-fried-attempted-to-tamper-with-witness-prosecutors-allege](https://www.dailywire.com/news/sam-bankman-fried-attempted-to-tamper-with-witness-prosecutors-allege)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 14:31:30+00:00
 - user: None

Federal prosecutors requested that former FTX CEO Sam Bankman-Fried become subject to more restrictions during his pretrial release after he allegedly tried to tamper with a witness through the encrypted messaging platform Signal. The former cryptocurrency executive is awaiting trial for various fraud charges after he commingled funds between FTX and sister trading company Alameda ...

## Fans Delighted That Tidying Up Expert Marie Kondo Admits She’s ‘Kind Of Given Up’ After Birth Of Third Child
 - [https://www.dailywire.com/news/fans-delighted-that-tidying-up-expert-marie-kondo-admits-shes-kind-of-given-up-after-birth-of-third-child](https://www.dailywire.com/news/fans-delighted-that-tidying-up-expert-marie-kondo-admits-shes-kind-of-given-up-after-birth-of-third-child)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 14:19:11+00:00
 - user: None

Best-selling author and well-known organizational expert Marie Kondo has admitted she’s &#8220;kind of given up&#8221; on tidying up. The 38-year-old became a household name following the massive success of her book, “The Life-Changing Magic of Tidying Up,” which became a New York Times bestseller with more than four million copies sold. She also had a ...

## Is It Time We All Stop Tipping? It’s Absolutely Out Of Control!
 - [https://www.dailywire.com/news/is-it-time-we-all-stop-tipping-its-absolutely-out-of-control](https://www.dailywire.com/news/is-it-time-we-all-stop-tipping-its-absolutely-out-of-control)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 14:12:17+00:00
 - user: None

&#8220;Why tip someone for a job I&#8217;m capable of doing myself? I can deliver food, I can drive a taxi, I can and do cut my own hair. I did, however, tip my urologist because I am unable to pulverize my own kidney stones.&#8221; &#8212; Dwight Shrute, &#8220;The Office&#8221; *** Let&#8217;s start at the beginning: ...

## Ilhan Omar Insinuates GOP Racist For Attempting To Remove Her From Committee
 - [https://www.dailywire.com/news/ilhan-omar-insinuates-gop-racist-for-attempting-to-remove-her-from-committee](https://www.dailywire.com/news/ilhan-omar-insinuates-gop-racist-for-attempting-to-remove-her-from-committee)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 14:00:31+00:00
 - user: None

Democrat firebrand Rep. Ilhan Omar suggested Sunday that racism is behind House Speaker Kevin McCarthy&#8217;s effort to remove her from the House Foreign Affairs Committee. The Minnesota lawmaker, who appeared on CNN’s “State of the Union,” has been accused in the past of pushing anti-Semitic tropes and recently drew fire for equating the U.S. and Israel ...

## TikTok CEO Will Testify Before Congress As National Security, Privacy Concerns Grow
 - [https://www.dailywire.com/news/tiktok-ceo-will-testify-before-congress-as-national-security-privacy-concerns-grow](https://www.dailywire.com/news/tiktok-ceo-will-testify-before-congress-as-national-security-privacy-concerns-grow)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 13:46:06+00:00
 - user: None

TikTok CEO Shou Zi Chew is set to appear before lawmakers in March to discuss the social media platform’s data security practices and links to the Chinese government. ByteDance, the company which owns TikTok, is based in Beijing and incorporated in the Cayman Islands. The company has garnered scrutiny from officials in response to alleged ...

## 8-Month-Old Allegedly Strangled By Mother Dies In Hospital
 - [https://www.dailywire.com/news/8-month-old-allegedly-strangled-by-mother-dies-in-hospital](https://www.dailywire.com/news/8-month-old-allegedly-strangled-by-mother-dies-in-hospital)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 13:38:54+00:00
 - user: None

An 8-month-old boy who was allegedly strangled by his mother and airlifted to a Boston, Massachusetts, hospital has died, authorities say. On January 24, a man called 911 saying a woman had attempted suicide by jumping out of a window. The woman was identified as Lindsay Clancy, 32, of Duxbury, Massachusetts, and the caller was ...

## Trans Activist Dylan Mulvaney Stages Dramatic Reveal After Face Feminization Surgery, Gets Slammed
 - [https://www.dailywire.com/news/trans-activist-dylan-mulvaney-stages-dramatic-reveal-after-face-feminization-surgery-gets-slammed](https://www.dailywire.com/news/trans-activist-dylan-mulvaney-stages-dramatic-reveal-after-face-feminization-surgery-gets-slammed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 13:30:14+00:00
 - user: None

Trans activist Dylan Mulvaney dramatically debuted a new face after telling his fans he was undergoing “facial feminization” surgery. The TikTok influencer is known for creating the “Days of Girlhood” series. These viral videos have attracted so much attention that Mulvaney was invited to the White House to meet with President Joe Biden to “ask ...

## Exclusive Interview: Marjorie Taylor Greene Says She Hasn’t Changed, The Party Has
 - [https://www.dailywire.com/news/exclusive-interview-marjorie-taylor-greene-says-she-hasnt-changed-the-party-has](https://www.dailywire.com/news/exclusive-interview-marjorie-taylor-greene-says-she-hasnt-changed-the-party-has)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 13:22:09+00:00
 - user: None

As Marjorie Taylor Greene traded whispers on the House floor with the most powerful man in the chamber earlier this month, the headlines turned apoplectic. The Georgia congresswoman’s close alliance with Kevin McCarthy was on full display during his chaotic fight to become House speaker, a fight he ultimately won, in part thanks to Greene ...

## NHL Hall Of Famer Bobby Hull, The Golden Jet, Dead At 84
 - [https://www.dailywire.com/news/nhl-hall-of-famer-bobby-hull-the-golden-jet-dead-at-84](https://www.dailywire.com/news/nhl-hall-of-famer-bobby-hull-the-golden-jet-dead-at-84)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 13:02:44+00:00
 - user: None

Hockey legend Bobby Hull, known as the Golden Jet because of his blonde hair and fast skating, has died, according to a statement from the NHL Alumni Association issued on Monday morning. He was 84 years old. Hull is the all-time leading scorer for the Chicago Blackhawks, amassing more than 600 goals in his 15-year ...

## ‘Climate Quitting’: Young Workers Are Jumping Ship When Companies Don’t Care Enough About The Environment
 - [https://www.dailywire.com/news/climate-quitting-young-workers-are-jumping-ship-when-companies-dont-care-enough-about-the-environment](https://www.dailywire.com/news/climate-quitting-young-workers-are-jumping-ship-when-companies-dont-care-enough-about-the-environment)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 12:14:44+00:00
 - user: None

Young workers in Western nations are leaving their jobs at increasing levels over a desire to work for companies they believe are committed to fighting climate change. The phenomenon of “climate quitting” occurs as multiple surveys indicate that professionals in younger cohorts prefer their employers to take active stands on social and political issues. Some ...

## ’24’ Actress Annie Wersching Dead At 45 After Private Cancer Battle
 - [https://www.dailywire.com/news/24-actress-annie-wersching-dead-at-45-after-private-cancer-battle](https://www.dailywire.com/news/24-actress-annie-wersching-dead-at-45-after-private-cancer-battle)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 12:14:24+00:00
 - user: None

Actress Annie Wersching, a native of St. Louis, Missouri, who starred in the television series &#8220;24,&#8221; died on Sunday morning after a private battle with cancer. She was 45 years old. Wersching&#8217;s publicist confirmed the news to Deadline on Sunday; her husband, actor and comedian Stephen Full (&#8220;Cold Case&#8221;), released a statement that was published ...

## Suicide Bomber Targeting Police Kills 47, Injures More Than 150 During Prayer Service
 - [https://www.dailywire.com/news/suicide-bomber-targeting-police-kills-47-injures-more-than-150-during-prayer-service](https://www.dailywire.com/news/suicide-bomber-targeting-police-kills-47-injures-more-than-150-during-prayer-service)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 12:09:00+00:00
 - user: None

A suicide bomber targeted police at a crowded mosque in Peshawar, Pakistan, Monday, killing at least 47 people and injuring more than 150 others. Most of the people who died were police officers, The Associated Press reported, in what is the latest attack against law enforcement in the city by Islamist militants. Hospital officials told ...

## Thousands Of Pandemic Unemployment Claims Listed The Names Of Still-Employed Government Workers, Senator Says
 - [https://www.dailywire.com/news/thousands-of-pandemic-unemployment-claims-listed-the-names-of-still-employed-government-workers-senator-says](https://www.dailywire.com/news/thousands-of-pandemic-unemployment-claims-listed-the-names-of-still-employed-government-workers-senator-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 12:06:51+00:00
 - user: None

Thousands of federal employees may have wrongfully obtained coronavirus bailouts by claiming to be unemployed&#8211;with some even doing so from their desks at government offices, government investigators found.

## DeSantis Would Win Today ‘Without A Doubt’: N.H. Gov On 2024’s First Primary
 - [https://www.dailywire.com/news/desantis-would-win-today-without-a-doubt-n-h-gov-on-2024s-first-primary](https://www.dailywire.com/news/desantis-would-win-today-without-a-doubt-n-h-gov-on-2024s-first-primary)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 12:04:46+00:00
 - user: None

New Hampshire Governor Chris Sununu, whose state will be the first in the nation to hold a GOP primary after the Iowa caucuses begin the 2024 run for the presidency, said that Florida Governor Ron DeSantis would win the primary if it were held now. Sununu, a member of a veteran political family, is the ...

## ‘Frankly Grotesque’: Internet Reacts To Non-Binary Singer Sam Smith’s New Sexually Charged Music Video
 - [https://www.dailywire.com/news/frankly-grotesque-internet-reacts-to-non-binary-singer-sam-smiths-new-sexually-charged-music-video](https://www.dailywire.com/news/frankly-grotesque-internet-reacts-to-non-binary-singer-sam-smiths-new-sexually-charged-music-video)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 11:55:52+00:00
 - user: None

Singer Sam Smith is facing criticism for his over-the-top, sexually charged music video, which critics point out is visible to young fans on YouTube. The 30-year-old U.K.-based performer, who identifies as non-binary, just dropped a new video for the single &#8220;I&#8217;m Not Here To Make Friends,&#8221; which is featured on their recently-released album, &#8220;Gloria.&#8221; The ...

## Democrat Wants Artificial Intelligence Regulations As First Easy-To-Use Tools Hit The Marketplace
 - [https://www.dailywire.com/news/democrat-wants-artificial-intelligence-regulations-as-first-easy-to-use-tools-hit-the-marketplace](https://www.dailywire.com/news/democrat-wants-artificial-intelligence-regulations-as-first-easy-to-use-tools-hit-the-marketplace)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 10:48:31+00:00
 - user: None

Policymakers in the United States and beyond are proposing regulations for novel mass-market artificial intelligence systems. The calls for government oversight come after ChatGPT, a language processing tool that knowledge workers are leveraging to complete tasks such as writing emails and debugging code in a matter of moments, garners worldwide popularity. Rep. Ted Lieu (D-CA) ...

## VIDEO: ‘Gender-Neutral Woman’ Ice Skater Falls, Can’t Get Up During Show’s Opening Ceremonies
 - [https://www.dailywire.com/news/video-gender-neutral-woman-ice-skater-falls-cant-get-up-during-shows-opening-ceremonies](https://www.dailywire.com/news/video-gender-neutral-woman-ice-skater-falls-cant-get-up-during-shows-opening-ceremonies)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 10:11:58+00:00
 - user: None

Viewers had some strong reactions to a now-viral clip of Finland showcasing a &#8220;gender-neutral&#8221; figure skater&#8217;s disastrous results. The theme for the ISU European Figure Skating Championships was &#8220;just be you.&#8221; “With the diverse group of performers, we want to show that the ice has space for everyone,” synchronized skating coach Helena Tienhaara said in ...

## Trump Warns DeSantis Against ‘Disloyal’ ’24 Bid As New Poll Has Gov Surging In Key State
 - [https://www.dailywire.com/news/trump-warns-desantis-against-disloyal-24-bid-as-new-poll-has-gov-surging-in-key-state](https://www.dailywire.com/news/trump-warns-desantis-against-disloyal-24-bid-as-new-poll-has-gov-surging-in-key-state)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 09:45:40+00:00
 - user: None

Former President Trump warned Ron DeSantis over the weekend against launching a presidential primary challenge against him, saying such a move by the popular Florida governor would be &#8220;very disloyal.&#8221; It was not the first time Trump, the only major Republican who has declared a 2024 candidacy, has attacked DeSantis, who won re-election by nearly ...

## New Yorkers Mad After Empire State Building Honors Philadelphia Eagles
 - [https://www.dailywire.com/news/new-yorkers-mad-after-empire-state-building-honors-philadelphia-eagles](https://www.dailywire.com/news/new-yorkers-mad-after-empire-state-building-honors-philadelphia-eagles)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-30 00:04:06+00:00
 - user: None

The Philadelphia Eagles locked up the National Football Conference (NFC) championship on Sunday, clinching a spot in the upcoming Super Bowl LVII — and someone at the Empire State Building thought that was cause for celebration. The iconic tower was lit in green and white in honor of the Eagles, and an announcement via Twitter ...
