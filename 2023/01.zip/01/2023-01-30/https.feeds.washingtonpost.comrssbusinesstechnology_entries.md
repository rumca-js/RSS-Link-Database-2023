# Source The Washington Post - Tech, Source URL:https://feeds.washingtonpost.com/rss/business/technology, Source language: en-US

## Astronauts who first flew SpaceX capsule to be honored at White House
 - [https://www.washingtonpost.com/technology/2023/01/30/behnken-hurley-awarded-space-medal-white-house/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/30/behnken-hurley-awarded-space-medal-white-house/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-30 17:18:01+00:00
 - user: None

The last time the medal was awarded was in 2006 to Robert Crippen, the pilot of the first Space Shuttle flight.

## These robots might build your house
 - [https://www.washingtonpost.com/technology/2023/01/30/construction-companies-robotic-technology/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/30/construction-companies-robotic-technology/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-30 06:00:10+00:00
 - user: None

The construction industry is in a crisis, and more companies are turning to robots to automate tasks on the job site.

## Your iPhone has powerful new security features. Do you need them?
 - [https://www.washingtonpost.com/technology/2023/01/30/iphone-security-keys/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/30/iphone-security-keys/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-30 06:00:00+00:00
 - user: None

Apple has added support for physical security keys and expanded encryption to the new iPhone iOS 16.3 update, but they’re not for everyone.
