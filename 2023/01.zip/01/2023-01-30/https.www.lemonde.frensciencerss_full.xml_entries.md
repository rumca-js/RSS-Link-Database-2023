# Source Le Monde - science, Source URL:https://www.lemonde.fr/en/science/rss_full.xml, Source language: en-US

## Walking five minutes every half hour is the best remedy against the effects of a sedentary lifestyle
 - [https://www.lemonde.fr/en/science/article/2023/01/30/walking-five-minutes-every-half-hour-is-the-best-remedy-against-the-effects-of-a-sedentary-lifestyle_6013614_10.html](https://www.lemonde.fr/en/science/article/2023/01/30/walking-five-minutes-every-half-hour-is-the-best-remedy-against-the-effects-of-a-sedentary-lifestyle_6013614_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-01-30 06:00:12+00:00
 - user: None

A study by researchers at Columbia University Medical Center has highlighted a method that most reduces the adverse effects of sitting for far too long, like diabetes and heart conditions.
