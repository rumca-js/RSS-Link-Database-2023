# Source Epoch Times Tech, Source URL:https://www.theepochtimes.com/c-tech/feed/, Source language: en-US

## Nuclear Lab in China Procured US Chips Despite Ban
 - [https://www.theepochtimes.com/nuclear-lab-in-china-procured-us-chips-despite-ban_5020208.html](https://www.theepochtimes.com/nuclear-lab-in-china-procured-us-chips-despite-ban_5020208.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-30 17:49:34+00:00
 - user: None

China's DF-41 nuclear-capable intercontinental ballistic missiles are seen during a military parade at Tiananmen Square in Beijing, on Oct. 1, 2019. (Greg Baker/AFP via Getty Images)

## Apple Tells Certain iPhone Owners to Update Software or Face the Consequences
 - [https://www.theepochtimes.com/apple-tells-certain-iphone-owners-to-update-software-or-face-the-consequences_5020059.html](https://www.theepochtimes.com/apple-tells-certain-iphone-owners-to-update-software-or-face-the-consequences_5020059.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-30 16:30:02+00:00
 - user: None

An Israeli woman uses her iPhone in front of the building housing the Israeli NSO group, in Herzliya, near Tel Aviv, Israel, on Aug. 28, 2016. (Jack Guez/AFP via Getty Images)

## Google Removes Over 50,000 Contents Promoting Pro-China Disinformation
 - [https://www.theepochtimes.com/google-removes-over-50000-contents-promoting-pro-china-disinformation_5019625.html](https://www.theepochtimes.com/google-removes-over-50000-contents-promoting-pro-china-disinformation_5019625.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-30 14:51:06+00:00
 - user: None

An unnamed Chinese hacker using his computer at their office in Dongguan, in China's southern Guangdong Province, on Aug. 4, 2020. (Nicolas Asfouri/AFP via Getty Images)

## 100 Social Media Influencers Face Australian Probe Over Hidden Endorsements
 - [https://www.theepochtimes.com/100-social-media-influencers-face-australian-probe-over-hidden-endorsements_5019065.html](https://www.theepochtimes.com/100-social-media-influencers-face-australian-probe-over-hidden-endorsements_5019065.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-30 01:35:36+00:00
 - user: None

The logos of Facebook, YouTube, TikTok, and Snapchat on mobile devices in a combination of 2017–2022 photos. (AP Photo)
