# Source ComputerWorld, Source URL:https://www.computerworld.com/index.rss, Source language: en-US

## Desktop tweaks in Windows can be fun, but watch out for risks
 - [https://www.computerworld.com/article/3686614/desktop-tweaks-in-windows-can-be-fun-but-watch-out-for-risks.html#tk.rss_all](https://www.computerworld.com/article/3686614/desktop-tweaks-in-windows-can-be-fun-but-watch-out-for-risks.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-01-30 19:39:00+00:00
 - user: None

<article>
	<section class="page">
<p>Like many things, computer desktops are unique. Though large businesses tend to deploy a single image for all their workstations to lock things down (and limit customization), many small firms and home users want to make their desktop, well, <em>theirs</em>. Case in point: one of the first things I do after installing Windows 11 is move the bottom menu over to the left. After so many years of turning off my computer with the Start button on the left, I found myself always clicking on widgets to turn off my computer. Not only did that small change look better, it served as a small productivity boost.</p><p>The desire for customization is not new. As far back as I can remember with Windows, users have been installing <a href="https://support.microsoft.com/en-us/windows/change-your-desktop-background-image-175618be-4cf1-c159-2785-ec2238b433a8" rel="noopener nofollow" target="_blank">custom backgrounds</a>, editing icons, <a href="https://support.microsoft.com/en-us/windows/change-colors-in-windows-d26ef4d6-819a-581c-1581-493cfcc005fe" rel="noopener nofollow" target="_blank">trying out different colors</a>, and so on. But all that customization can come with side effects. Too often with Windows 11, a third-party customization tool will behave badly after a Windows update, prompting the user to blame Microsoft. But it’s the tool that’s acting up because it relies on registry entries that have changed.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3686614/desktop-tweaks-in-windows-can-be-fun-but-watch-out-for-risks.html#jump">To read this article in full, please click here</a></p></section></article>

## Apple wants to build a new computing platform with AR
 - [https://www.computerworld.com/article/3686512/apple-wants-to-build-a-new-computing-platform-with-ar.html#tk.rss_all](https://www.computerworld.com/article/3686512/apple-wants-to-build-a-new-computing-platform-with-ar.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-01-30 16:29:00+00:00
 - user: None

<article>
	<section class="page">
<p>Apple’s plan to create an App Store and an easy way to create <a href="https://www.computerworld.com/article/3681892/apple-gives-up-on-reality-but-still-wants-to-extend-it.html">mixed-reality apps</a> offers an<a href="https://www.theinformation.com/articles/apple-devising-software-to-help-anyone-build-ar-apps-to-drive-headset-sales" rel="noopener nofollow" target="_blank"> important insight</a> into its strategy and confirms that the company <a href="https://www.computerworld.com/article/3684793/apple-wont-announce-vr-for-the-rest-of-us-at-wwdc.html">sees these devices as platforms</a>, not peripherals. And when considering the business case for them, we need to see whether they hit that mark.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3686512/apple-wants-to-build-a-new-computing-platform-with-ar.html#jump">To read this article in full, please click here</a></p></section></article>

## US wins support from Japan and Netherlands to clip China’s chip industry
 - [https://www.computerworld.com/article/3686571/us-wins-support-from-japan-and-netherlands-to-clip-chinas-chip-industry.html#tk.rss_all](https://www.computerworld.com/article/3686571/us-wins-support-from-japan-and-netherlands-to-clip-chinas-chip-industry.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-01-30 11:08:00+00:00
 - user: None

<article>
	<section class="page">
<p>The US has convinced two other countries to join it in expanding a ban on exports of chip-making technology to China, according to a report by Bloomberg. The move could cramp China’s home-grown chip industry as there are few, if any, other sources for the sophisticated technologies required for modern semiconductor manufacturing.</p><p>As part of a broader trade war with China, the US sought for its chip technology embargo from Japan and the Netherlands, where some of the world’s largest manufacturers of semiconductor manufacturing equipment are headquartered. It first imposed restrictions on exports of chips to China in 2015, extending them in 2021 and twice in 2022. The most recent restrictions were introduced in December.</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3686571/us-wins-support-from-japan-and-netherlands-to-clip-chinas-chip-industry.html#jump">To read this article in full, please click here</a></p></section></article>

## Study: When employees don’t have to commute, they work
 - [https://www.computerworld.com/article/3686653/study-when-employees-dont-have-to-commute-they-work.html#tk.rss_all](https://www.computerworld.com/article/3686653/study-when-employees-dont-have-to-commute-they-work.html#tk.rss_all)
 - RSS feed: https://www.computerworld.com/index.rss
 - date published: 2023-01-30 11:00:00+00:00
 - user: None

<article>
	<section class="page">
<p>When employees are allowed to work remotely, they most often use the time they would have spent commuting to the office working.</p><p>On average, employees save 72 minutes in commute time every day when they’re allowed to work from home rather than in the office, according to the <a href="https://www.nber.org/system/files/working_papers/w30866/w30866.pdf" rel="nofollow noopener" target="_blank">Global Survey of Working Arrangements</a> (G-SWA) study performed by the National Bureau of Economic Research (NBER).</p><p>“That’s a large time savings, especially when multiplied by hundreds of millions of workers around the world,” the study said. “These results suggest that much of the time savings flow back to employers, and that children and other caregiving recipients also benefit.”</p><p class="jumpTag"><a href="https://www.computerworld.com/article/3686653/study-when-employees-dont-have-to-commute-they-work.html#jump">To read this article in full, please click here</a></p></section></article>
