# Source Linus Tech Tips, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, Source language: en-US

## The open source alternative to my sponsor
 - [https://www.youtube.com/watch?v=jKF5GtBIxpM](https://www.youtube.com/watch?v=jKF5GtBIxpM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-01-30 18:25:27+00:00
 - user: None

Check out Secret Lab at https://lmg.gg/SecretLabLTT

Sign up with Zoho Desk at: https://lmg.gg/zohodeskltt

When we shout about home AV servers, it's like we're shouting into a canyon. We scream "PLEX!" and an echo rings out "JELLYFIN! JeLlYfIn! JellYFiN! jellyfin! ʲᵉˡˡʸᶠᶦⁿ...." So we listened to the void we screamed into, and decided to give Jellyfin a shot. Does it succeed where Plex fails? What are its shortcomings? Is Jellyfin the chosen one where Plex was unsuccessful?

Discuss on the forum: https://linustechtips.com/topic/1484999-the-open-source-alternative-to-my-sponsor/

► GET MERCH: https://lttstore.com
► COME TO LTX 2023: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/masponsors
► OUR WAN PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
1:39 Device Compatibility
3:31 Server Setup
4:30 Library Setup
5:30 Filtering
6:35 Parental Tools and Account Management
7:50 Video Players, Skip Intro, and Plugins
9:08 Google TV
9:57 Android Mobile and the Download Problem
12:16 iOS, the Apple Problem, and Disappearing Features
13:05 Plex as a Sponsor and Switching to Jellyfin Longterm
15:05 "bUt WhAt AbOuT eMbY?!"
15:39 Closing Statements
