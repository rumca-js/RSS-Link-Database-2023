# Source ZDNET, Source URL:http://www.zdnet.com/news/rss.xml, Source language: en-US

## OpenAI is hiring developers to make ChatGPT better at coding
 - [https://www.zdnet.com/article/openai-is-hiring-developers-to-make-chatgpt-better-at-coding/#ftag=RSSbaffb68](https://www.zdnet.com/article/openai-is-hiring-developers-to-make-chatgpt-better-at-coding/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 22:15:53+00:00
 - user: None

Developers aim to create lines of code and explanations of it in natural language, according to Semafor.

## Glowforge Pro review: Laser cutting and engraving for serious makers and small businesses
 - [https://www.zdnet.com/article/glowforge-pro-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/glowforge-pro-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 22:14:00+00:00
 - user: None

If you have the money and space, and can put up with some noise and odor, the Glowforge Pro will allow you to undertake an impressive range of creative projects.

## The 10 best tech-themed gift cards to give in 2023
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-gift-card/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-gift-card/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 22:12:00+00:00
 - user: None

Check out these gift cards to secure some of the hottest tech and gadgets, and best of all, they can all be purchased and used online.

## Samsung Unpacked 2023: How to watch and what you need to know
 - [https://www.zdnet.com/article/samsung-unpacked-2023-how-to-watch/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsung-unpacked-2023-how-to-watch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 21:53:00+00:00
 - user: None

On Wednesday, Samsung will hold its Unpacked 2023 event where it will drop its latest tech. Here is how you can tune in.

## Lectric XP Lite e-bike review: A sheer ($800) joy to ride
 - [https://www.zdnet.com/article/lectric-xp-lite-e-bike-review/#ftag=RSSbaffb68](https://www.zdnet.com/article/lectric-xp-lite-e-bike-review/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 21:07:00+00:00
 - user: None

Electric bikes priced below $1,000 usually mean lots of compromises. The Lectric XP Lite shatters those expectations.

## How to set up an Apple Watch
 - [https://www.zdnet.com/article/how-to-set-up-an-apple-watch/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-set-up-an-apple-watch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 20:50:00+00:00
 - user: None

Despite how incredibly versatile the Apple Watch is, its setup process is absurdly simple. Still, there are a few things you should know to make it even easier.

## How to run a Windows app on Linux with Wine
 - [https://www.zdnet.com/article/how-to-run-a-windows-app-on-linux-with-wine/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-run-a-windows-app-on-linux-with-wine/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 20:34:39+00:00
 - user: None

If you want to make the Linux operating system your go-to but still need to run Windows apps, Wine has you covered.

## 5 iOS 16 features I can't live without now (and how to use them)
 - [https://www.zdnet.com/article/5-ios-16-features-i-cant-live-without-now-and-how-to-use-them/#ftag=RSSbaffb68](https://www.zdnet.com/article/5-ios-16-features-i-cant-live-without-now-and-how-to-use-them/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 20:05:00+00:00
 - user: None

These iOS 16 features will change how you use your iPhone on a daily basis.

## LG revamps UltraGear line with stunning 45-inch OLED curved gaming monitor
 - [https://www.zdnet.com/home-and-office/home-entertainment/lg-ultragear-oled-gaming-monitors-release-date-price-features-specs/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/lg-ultragear-oled-gaming-monitors-release-date-price-features-specs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:31:00+00:00
 - user: None

LG has launched its first UltraGear OLED gaming monitors, starting with two models: a 45-inch curved monitor and a 27-inch 1440p monitor. Both offer high-quality displays with a 'world-first' 240Hz refresh rate and 0.03ms response time. You can pre-order them now.

## Flash sale: The MSI Summit E13 Flip just dropped to $600
 - [https://www.zdnet.com/article/msi-summit-e13-flip-evo-laptop-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/article/msi-summit-e13-flip-evo-laptop-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:25:00+00:00
 - user: None

Save over $900 on this touchscreen laptop.

## The simple way to add more complications to your Apple Watch
 - [https://www.zdnet.com/article/the-simple-way-to-add-more-complications-to-your-apple-watch/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-simple-way-to-add-more-complications-to-your-apple-watch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:14:38+00:00
 - user: None

I love my Apple Watch complications, and even the Apple Watch Ultra doesn't let me have enough. So, here's what I do.

## The 5 best cheap 3D printers of 2023
 - [https://www.zdnet.com/article/best-cheap-3d-printer/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-cheap-3d-printer/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:10:00+00:00
 - user: None

3D printing can bring your art to life, but you need the right 3D printer. ZDNET analyzed the best cheap 3D printers under $300 for your personal or professional use.

## PikaOS is a next-gen Linux distribution aimed specifically toward gamers
 - [https://www.zdnet.com/article/pikaos-is-a-next-gen-linux-distribution-aimed-specifically-toward-gamers/#ftag=RSSbaffb68](https://www.zdnet.com/article/pikaos-is-a-next-gen-linux-distribution-aimed-specifically-toward-gamers/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:09:08+00:00
 - user: None

With its Ubuntu base, PikaOS makes gaming and standard desktop usage on Linux fairly straightforward.

## This Acer 516 GE Chromebook is $200 off at Best Buy
 - [https://www.zdnet.com/article/acer-516-ge-200-off-deal-best-buy/#ftag=RSSbaffb68](https://www.zdnet.com/article/acer-516-ge-200-off-deal-best-buy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 19:08:44+00:00
 - user: None

At 31% off, the Acer 516 GE Cloud Gaming Chromebook showcases impressive specs along with its impressive discount at Best Buy.

## ChatGPT can't make music, but Google's new AI model can
 - [https://www.zdnet.com/article/chatgpt-cant-make-music-but-googles-ai-model-can/#ftag=RSSbaffb68](https://www.zdnet.com/article/chatgpt-cant-make-music-but-googles-ai-model-can/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 18:53:20+00:00
 - user: None

Google is sharing information about a new, experimental AI model, MusicLM, which can create a song from a simple text input.

## OLED vs. QLED: Which is better?
 - [https://www.zdnet.com/home-and-office/home-entertainment/oled-vs-qled/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/oled-vs-qled/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 18:23:20+00:00
 - user: None

What's the difference between OLED and QLED? Here are reasons you should buy one over the other.

## The 5 best VPN trials of 2023
 - [https://www.zdnet.com/article/best-vpn-trial/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-vpn-trial/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 16:44:00+00:00
 - user: None

VPN trials are a great way to test a VPN's speed and reliability before you commit. Here are ZDNET's picks for the best VPN trials you should take advantage of in 2023.

## Building software these days: Design thinking, hybrid teams, and, of course, DevOps
 - [https://www.zdnet.com/article/building-software-these-days-design-thinking-hybrid-team-and-of-course-devops/#ftag=RSSbaffb68](https://www.zdnet.com/article/building-software-these-days-design-thinking-hybrid-team-and-of-course-devops/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 16:22:13+00:00
 - user: None

There's an urgency for 'thinking about development from the lens of the user experience first, and solution second,' says Cisco CIO Fletcher Previn.

## This Asus gaming laptop is less than $500 at Best Buy
 - [https://www.zdnet.com/article/asus-gaming-chromebook-deal-200-off-best-buy/#ftag=RSSbaffb68](https://www.zdnet.com/article/asus-gaming-chromebook-deal-200-off-best-buy/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 15:41:11+00:00
 - user: None

Chromebooks typically aren't made for gaming purposes. This ASUS Cloud Gaming Chromebook proves that statement false, all while seeing a $200 discount.

## This must-have screwdriver has two cool hidden tricks
 - [https://www.zdnet.com/home-and-office/this-must-have-screwdriver-has-two-cool-hidden-tricks/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/this-must-have-screwdriver-has-two-cool-hidden-tricks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 14:38:35+00:00
 - user: None

The screwdriver to rule them all!

## Samsung's Galaxy S23 release date and what to know
 - [https://www.zdnet.com/article/samsungs-galaxy-s23-release-date-and-what-to-know/#ftag=RSSbaffb68](https://www.zdnet.com/article/samsungs-galaxy-s23-release-date-and-what-to-know/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 14:31:06+00:00
 - user: None

Click back here for updates as we learn more about Samsung's upcoming family of flagship smartphones.

## AI has caused a renaissance of tech industry R&D, says Meta's chief AI scientist
 - [https://www.zdnet.com/article/ai-has-caused-a-renaissance-of-tech-industry-r-d-says-metas-chief-ai-scientist/#ftag=RSSbaffb68](https://www.zdnet.com/article/ai-has-caused-a-renaissance-of-tech-industry-r-d-says-metas-chief-ai-scientist/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 14:21:52+00:00
 - user: None

There are many promising commercial applications already that may lead to productivity increases, but, ultimately, AI must develop an ability to plan if it is to truly advance, says Yann LeCun.

## Foldable iPad is coming and could arrive in 2024, says analyst
 - [https://www.zdnet.com/article/foldable-ipad-is-coming-and-could-arrive-in-2024-says-analyst/#ftag=RSSbaffb68](https://www.zdnet.com/article/foldable-ipad-is-coming-and-could-arrive-in-2024-says-analyst/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 13:05:38+00:00
 - user: None

Move over foldable phones, a foldable iPad could be in the works from Apple.

## Microsoft warning: Protect this critical piece of your tech infrastructure
 - [https://www.zdnet.com/article/microsoft-warning-protect-this-critical-piece-of-your-tech-infrastructure/#ftag=RSSbaffb68](https://www.zdnet.com/article/microsoft-warning-protect-this-critical-piece-of-your-tech-infrastructure/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 12:38:24+00:00
 - user: None

Microsoft warns admins to keep Exchange Server updated as the platform is constantly being targeted by attackers.

## That big Microsoft 365, Teams, and Outlook outage? Here's what went wrong
 - [https://www.zdnet.com/home-and-office/work-life/that-big-microsoft-365-teams-and-outlook-outage-heres-what-went-wrong/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/that-big-microsoft-365-teams-and-outlook-outage-heres-what-went-wrong/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 11:24:27+00:00
 - user: None

Microsoft has given some detail on the causes of the recent cloud outage that affected customers using its services.

## You can now buy the Ring video doorbell for only $35 on Amazon
 - [https://www.zdnet.com/home-and-office/ring-video-doorbell-for-deal-sale-coupon-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/ring-video-doorbell-for-deal-sale-coupon-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-30 08:53:21+00:00
 - user: None

If you're willing to make a few compromises, the Ring video doorbell will only set you back $35 in Amazon's sale.
