# Source Wydarzenia Interia - Świat, Source URL:https://wydarzenia.interia.pl/swiat/feed, Source language: pl-PL

## Zabójstwo Tyre'a Nicholsa. Zawieszono szóstego policjanta
 - [https://wydarzenia.interia.pl/zagranica/news-zabojstwo-tyre-a-nicholsa-zawieszono-szostego-policjanta,nId,6566889](https://wydarzenia.interia.pl/zagranica/news-zabojstwo-tyre-a-nicholsa-zawieszono-szostego-policjanta,nId,6566889)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-30 21:04:58+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zabojstwo-tyre-a-nicholsa-zawieszono-szostego-policjanta,nId,6566889"><img align="left" alt="Zabójstwo Tyre'a Nicholsa. Zawieszono szóstego policjanta" src="https://i.iplsc.com/zabojstwo-tyre-a-nicholsa-zawieszono-szostego-policjanta/000GOU0BLPQMXVJ4-C321.jpg" /></a>Policja w Memphis zawiesiła w obowiązkach Prestona Hemphilla. Funkcjonariusz miał być zamieszany w głośną śmierć 29-letniego Tyre'a Nicholsa. Wcześniej o zabójstwo czarnoskórego mężczyzny oskarżono pięciu innych policjantów.</p><br clear="all" />

## Zamachowiec samobójca wysadził się w meczecie. 34 osoby zginęły
 - [https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-34-osoby-zgine,nId,6566197](https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-34-osoby-zgine,nId,6566197)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-30 09:36:43+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zamachowiec-samobojca-wysadzil-sie-w-meczecie-34-osoby-zgine,nId,6566197"><img align="left" alt="Zamachowiec samobójca wysadził się w meczecie. 34 osoby zginęły" src="https://i.iplsc.com/zamachowiec-samobojca-wysadzil-sie-w-meczecie-34-osoby-zgine/000GOQ7RCM3KMHH2-C321.jpg" /></a>W meczecie w Peszawarze na północy Pakistanu zamachowiec samobójca zdetonował kamizelkę z materiałami wybuchowymi, w wyniku czego co najmniej 34 osoby zginęły, a 150 zostało rannych.</p><br clear="all" />
