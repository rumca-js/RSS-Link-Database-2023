# Source CNN, Source URL:http://rss.cnn.com/rss/edition.rss, Source language: en-US

## John Mayer is hitting the road for his first acoustic tour
 - [https://www.cnn.com/2023/01/26/entertainment/john-mayer-solo-acoustic-tour/index.html](https://www.cnn.com/2023/01/26/entertainment/john-mayer-solo-acoustic-tour/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 23:55:36+00:00
 - user: None

John Mayer has announced a first-ever solo acoustic tour.

## CNN obtains audio of traffic stop involving Tyre Nichols
 - [https://www.cnn.com/videos/us/2023/01/26/new-audio-tyre-nichols-sidner-ath-vpx.cnn](https://www.cnn.com/videos/us/2023/01/26/new-audio-tyre-nichols-sidner-ath-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 23:54:52+00:00
 - user: None

CNN has obtained portions of the police scanner audio leading up to the arrest of Tyre Nichols who died three days after was pulled over for alleged reckless driving in Memphis, Tennessee. Police say confrontations ensued between Nichols and officers during the stop. CNN's Sara Sidner reports.

## What we know -- and still don't know -- about what led to Tyre Nichols' death
 - [https://www.cnn.com/2023/01/26/us/what-we-know-tyre-nichols-death/index.html](https://www.cnn.com/2023/01/26/us/what-we-know-tyre-nichols-death/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 22:13:30+00:00
 - user: None

It's been almost three weeks since a traffic stop in Memphis led to a violent arrest and, three days later, the death of the 29-year-old Black driver.

## Swimming in cash, Chevron plans a $75 billion slap in the face to drivers
 - [https://www.cnn.com/2023/01/26/business/nightcap-chevron-stock-buyback/index.html](https://www.cnn.com/2023/01/26/business/nightcap-chevron-stock-buyback/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 22:08:58+00:00
 - user: None

While most blue-chip companies were reporting losses last year, Big Oil was having a moment. Crude prices surged, thanks in part to high demand and reduced supply. All of that helped make Chevron the top-performing Dow stock of last year, with shares surging more than 50%.

## US will send more modern and lethal version of Abrams tank to Ukraine
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-1-26-23/h_7a27b5c4481ce756a64e956e5e164e81](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-1-26-23/h_7a27b5c4481ce756a64e956e5e164e81)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 21:55:34.775158+00:00
 - user: None



## NYC bike path terror suspect found guilty in 2017 killing of eight people with truck
 - [https://www.cnn.com/2023/01/26/us/sayfullo-saipov-nyc-terror-attack-verdict/index.html](https://www.cnn.com/2023/01/26/us/sayfullo-saipov-nyc-terror-attack-verdict/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 21:01:06+00:00
 - user: None



## Analysis: Could fighter jets be next for Ukraine?
 - [https://www.cnn.com/2023/01/26/europe/ukraine-tanks-fighter-jets-intl/index.html](https://www.cnn.com/2023/01/26/europe/ukraine-tanks-fighter-jets-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 19:46:02+00:00
 - user: None

The decision by Germany, the United States, and others to send main battle tanks to Ukraine has gone further than many thought realistic just months ago.

## ChatGPT passes exam at Ivy League business school
 - [https://www.cnn.com/2023/01/26/tech/chatgpt-passes-exams/index.html](https://www.cnn.com/2023/01/26/tech/chatgpt-passes-exams/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 18:35:49+00:00
 - user: None

ChatGPT is smart enough to pass prestigious graduate-level exams -- though not with particularly high marks.

## Neighbors claim terrorizing turkey is 'literally taking over our life'
 - [https://www.cnn.com/videos/us/2023/01/26/turkey-terrorizes-minnesota-neighborhood-affil-pkg-cprog-vpx.wcco](https://www.cnn.com/videos/us/2023/01/26/turkey-terrorizes-minnesota-neighborhood-affil-pkg-cprog-vpx.wcco)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 18:02:34+00:00
 - user: None

A turkey named 'Gladis' is terrorizing a neighborhood in Coon Rapids, Minnesota, and has residents living in fear of getting chased, pecked and followed by the wild bird. CNN affiliate WCCO reports.

## Charges to be announced in investigation of Tyre Nichols' death after police encounter
 - [https://edition.cnn.com/webview/us/live-news/tyre-nichols-memphis-news-1-26-23/index.html](https://edition.cnn.com/webview/us/live-news/tyre-nichols-memphis-news-1-26-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:55:30.950901+00:00
 - user: None



## Humans can understand apes' sign language, new study finds
 - [https://www.cnn.com/2023/01/26/world/humans-understand-ape-sign-language-intl-scli-scn/index.html](https://www.cnn.com/2023/01/26/world/humans-understand-ape-sign-language-intl-scli-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:52:30+00:00
 - user: None

From pointing to animated arm movements and nodding, people regularly employ gestures to accompany and create language.

## Hate crime investigation as effigy of Real Madrid star hanged from bridge ahead of derby
 - [https://www.cnn.com/2023/01/26/football/vinicius-jr-effigy-real-madrid-atletico-spt-intl/index.html](https://www.cnn.com/2023/01/26/football/vinicius-jr-effigy-real-madrid-atletico-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:34:58+00:00
 - user: None

Spanish national police have opened an investigation "for a possible hate crime," after an effigy of Real Madrid star Vinícius Junior was hanged from a bridge in Madrid, the national police's press office for the Madrid region told CNN on Thursday.

## We finally know whom FTX owes money to
 - [https://www.cnn.com/2023/01/26/investing/ftx-creditors-wall-street/index.html](https://www.cnn.com/2023/01/26/investing/ftx-creditors-wall-street/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:27:32+00:00
 - user: None

Newly unsealed bankruptcy documents revealed thousands of creditors to whom FTX owes money after the once-mighty crypto exchange collapsed in November.

## Box truck-size asteroid to make one of the closest approaches of Earth ever recorded
 - [https://www.cnn.com/2023/01/26/world/asteroid-close-pass-of-earth-scn/index.html](https://www.cnn.com/2023/01/26/world/asteroid-close-pass-of-earth-scn/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:14:38+00:00
 - user: None

An asteroid the size of a box truck is about to make one of the closest passes of planet Earth ever recorded.

## Turkey says Sweden was complicit in burning of Quran amid tension over NATO membership bid
 - [https://www.cnn.com/2023/01/26/europe/turkey-blames-swedish-government-quran-burning-intl/index.html](https://www.cnn.com/2023/01/26/europe/turkey-blames-swedish-government-quran-burning-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 17:11:16+00:00
 - user: None

The Swedish government was complicit in the burning of the Quran at a protest in Stockholm last weekend, Turkish Foreign Minister Mevlüt Çavuşoğlu reportedly said Thursday.

## John Legend shares picture of new baby girl
 - [https://www.cnn.com/2023/01/26/entertainment/john-legend-baby-chrissy-teigen/index.html](https://www.cnn.com/2023/01/26/entertainment/john-legend-baby-chrissy-teigen/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 16:30:04+00:00
 - user: None

John Legend shared his first photo with newborn daughter, Esti, on social media.

## Three people treated during filming of real-life 'Squid Game,' but Netflix denies any 'serious injury'
 - [https://www.cnn.com/2023/01/26/entertainment/squid-game-real-show-netflix-scli-intl/index.html](https://www.cnn.com/2023/01/26/entertainment/squid-game-real-show-netflix-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:40:52+00:00
 - user: None

Three people received medical treatment during filming for a real-life "Squid Game" show, Netflix has confirmed, but the streaming giant denied that anyone suffered "serious injury."

## Former Trump DHS official Ken Cuccinelli testifying in grand jury investigation around 2020 election interference
 - [https://www.cnn.com/2023/01/26/politics/ken-cuccinelli-grand-jury/index.html](https://www.cnn.com/2023/01/26/politics/ken-cuccinelli-grand-jury/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:26:43+00:00
 - user: None

Former Trump-era Department of Homeland Security official Ken Cuccinelli is testifying before a federal grand jury in Washington, DC, on Thursday.

## Man engages in gunfight with police helicopter
 - [https://www.cnn.com/videos/us/2023/01/26/man-fires-at-police-helicopter-video-cnntm-vpx.cnn](https://www.cnn.com/videos/us/2023/01/26/man-fires-at-police-helicopter-video-cnntm-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:23:52+00:00
 - user: None

A man in Detroit fired at a police helicopter and was later killed by police.

## Austin Butler gives ex Vanessa Hudgens credit for inspiring him to pursue 'Elvis'
 - [https://www.cnn.com/2023/01/26/entertainment/austin-butler-vanessa-hudgens-elvis/index.html](https://www.cnn.com/2023/01/26/entertainment/austin-butler-vanessa-hudgens-elvis/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:23:01+00:00
 - user: None

People on the internet can calm down now as Austin Butler has acknowledged that his ex-girlfriend, Vanessa Hudgens, is the "friend" he credits for encouraging him to play Elvis.

## Tyre Nichols' family speaks out after seeing police footage of police beating
 - [https://www.cnn.com/videos/us/2023/01/26/tyre-nichols-family-speaks-out-memphis-police-sidner-pkg-cnntm-ldn-vpx.cnn](https://www.cnn.com/videos/us/2023/01/26/tyre-nichols-family-speaks-out-memphis-police-sidner-pkg-cnntm-ldn-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:05:50+00:00
 - user: None

After a traffic stop in Memphis resulted in a violent arrest and subsequent death of 29-year-old Tyre Nichols, police are expected to release police body camera footage of the incident to the public. The family of Nichols and attorneys have viewed the traffic stop's video recordings, which have been described as a vicious, prolonged beating that lasted for minutes after officers chased down a fleeing Nichols. CNN's Sara Sidner reports.

## FBI has seized website used by notorious ransomware gang
 - [https://www.cnn.com/2023/01/26/politics/fbi-ransomware-gang-website/index.html](https://www.cnn.com/2023/01/26/politics/fbi-ransomware-gang-website/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 15:00:46+00:00
 - user: None

The FBI has seized a website that a notorious ransomware gang, which has extorted more than $100 million from victim organizations, has used to shame its victims, according to a posting on the website.

## Iranian chess player Sara Khadem 'inspires' Spanish Prime Minister Pedro Sánchez
 - [https://www.cnn.com/2023/01/26/sport/iranian-chess-sara-khadem-spanish-prime-minister-spt-intl/index.html](https://www.cnn.com/2023/01/26/sport/iranian-chess-sara-khadem-spanish-prime-minister-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 14:41:36+00:00
 - user: None

Spain's Prime Minister Pedro Sánchez says he's been inspired by Iranian chess player Sara Khadem, who recently took part in an international tournament without a hijab.

## Azerbaijan calls for sanctions over tennis player's pro-Armenia messages at the Australian Open
 - [https://www.cnn.com/2023/01/26/tennis/karen-khachanov-australian-open-armenia-azerbaijan-spt-intl/index.html](https://www.cnn.com/2023/01/26/tennis/karen-khachanov-australian-open-armenia-azerbaijan-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 14:37:20+00:00
 - user: None

Azerbaijan's tennis federation has called for Karen Khachanov to be sanctioned after the Russian player expressed support for the Armenian-majority population living in the disputed Nagorno-Karabakh region at the Australian Open.

## More than 1,000 dead in Malawi's worst cholera outbreak
 - [https://www.cnn.com/2023/01/26/africa/malawi-worst-cholera-outbreak-intl/index.html](https://www.cnn.com/2023/01/26/africa/malawi-worst-cholera-outbreak-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 14:19:50+00:00
 - user: None

Malawi has reported more than 1,000 deaths from a cholera outbreak that started in March 2022, the country's health ministry said in a statement Wednesday.

## Chelsea Handler says she 'didn't know' she was on Ozempic
 - [https://www.cnn.com/2023/01/26/entertainment/chelsea-handler-ozempic/index.html](https://www.cnn.com/2023/01/26/entertainment/chelsea-handler-ozempic/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 14:18:42+00:00
 - user: None

There's a great deal of conversation recently about celebrities using Type 2 diabetes medication Ozempic for weight loss.

## See how centenarian twins celebrated their birthday
 - [https://www.cnn.com/videos/world/2023/01/26/italy-twins-centenary-birthday-cprog-lon-orig-bg.cnn](https://www.cnn.com/videos/world/2023/01/26/italy-twins-centenary-birthday-cprog-lon-orig-bg.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 14:06:09+00:00
 - user: None

Francesca and Maria Ricciardi celebrated their 100th birthday with relatives and 50 grandchildren and great-grandchildren, according to Reuters.

## Spanish authorities believe fatal machete attack suspect acted alone
 - [https://www.cnn.com/2023/01/26/europe/spain-machete-churches-attack-suspect-intl/index.html](https://www.cnn.com/2023/01/26/europe/spain-machete-churches-attack-suspect-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 13:50:14+00:00
 - user: None

Spanish authorities believe the Moroccan suspect in a deadly machete attack at two churches in the southern port city of Algeciras Wednesday acted alone in the assault, which is being investigated as a suspected terror attack.

## From 7 billion years ago to the World Cup: Inside Qatar's best museums
 - [https://www.cnn.com/travel/article/qatar-museums/index.html](https://www.cnn.com/travel/article/qatar-museums/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 13:46:04+00:00
 - user: None

Qatar hasn't only been busy building soccer stadiums but also a slew of architecturally striking and accessible museums in its well-documented quest to be recognized as the arts capital of the Arabian Peninsula. Qatar travel guide

## Officers' conduct in Tyre Nichols' case is 'failing of basic humanity': police chief
 - [https://www.cnn.com/2023/01/26/us/tyre-nichols-memphis-thursday/index.html](https://www.cnn.com/2023/01/26/us/tyre-nichols-memphis-thursday/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 13:37:29+00:00
 - user: None

Memphis police officers' conduct in the confrontation that preceded this month's death of Black motorist Tyre Nichols is "is a failing of basic humanity," the Tennessee city's police chief said as officials prepare to release video of the incident.

## How Google's long period of online dominance could end
 - [https://www.cnn.com/2023/01/26/tech/google-antitrust/index.html](https://www.cnn.com/2023/01/26/tech/google-antitrust/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 13:07:33+00:00
 - user: None

For the better part of 15 years, Google has seemed like an unstoppable force, powered by the strength of its online search engine and digital advertising business. But both now look increasingly vulnerable.

## Novak Djokovic's father poses with fan wearing pro-Russia 'Z' symbol
 - [https://www.cnn.com/2023/01/26/tennis/djokovic-father-z-symbol-russia-intl-spt/index.html](https://www.cnn.com/2023/01/26/tennis/djokovic-father-z-symbol-russia-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:38:54+00:00
 - user: None

The Australian Open told CNN it has "briefed and reminded" players and their entourages about the tournament's "policy regarding flags and symbols" on Thursday after video emerged on Wednesday of Novak Djokovic's father, Srdjan, pictured at a demonstration with fans holding Russian flags, voicing his support for Russia.

## Mikaela Shiffrin: 'Holy crap, that was really good skiing!' Mom tells US skier after she breaks landmark record
 - [https://www.cnn.com/2023/01/26/sport/mikaela-shiffrin-interview-ski-records-intl-spt/index.html](https://www.cnn.com/2023/01/26/sport/mikaela-shiffrin-interview-ski-records-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:35:47+00:00
 - user: None

American skiing star Mikaela Shiffrin is having quite the 2023 -- and it could get even better before the end of January.

## Ukraine urges West to send military hardware as soon as possible
 - [https://www.cnn.com/2023/01/26/europe/ukraine-russia-strikes-tanks-thursday-intl/index.html](https://www.cnn.com/2023/01/26/europe/ukraine-russia-strikes-tanks-thursday-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:28:55+00:00
 - user: None

Ukraine has urged the West to get military hardware into the hands of its troops as quickly as possible, as Russia fired missiles toward Kyiv and other Ukrainian cities just hours after Germany and the US announced their plans to provide modern tanks to the country.

## US-born Spanish woman is now the world's oldest person, at age 115
 - [https://www.cnn.com/2023/01/26/europe/maria-branyas-morera-oldest-person-scli-intl/index.html](https://www.cnn.com/2023/01/26/europe/maria-branyas-morera-oldest-person-scli-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:21:34+00:00
 - user: None

She has survived the horrors of two world wars, a civil war and two global pandemics.

## US announces visa ban on individuals 'undermining' Nigeria's election
 - [https://www.cnn.com/2023/01/26/politics/us-visa-ban-nigeria-election/index.html](https://www.cnn.com/2023/01/26/politics/us-visa-ban-nigeria-election/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:20:30+00:00
 - user: None

The United States has announced visa restrictions on individuals believed to be "undermining the democratic process" in a recent election in Nigeria.

## Opinion: My near-death experience teaches a lesson
 - [https://www.cnn.com/2023/01/26/opinions/cardiac-arrest-cpr-training-volpp-ctrp/index.html](https://www.cnn.com/2023/01/26/opinions/cardiac-arrest-cpr-training-volpp-ctrp/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:19:21+00:00
 - user: None

Eighteen months ago, I woke up in the cardiac intensive care unit of the University of Cincinnati Medical Center. "What happened?" I repeatedly asked the clinicians taking care of me as my brain struggled to process how I had gone from a dinner with friends to being on a ventilator in a hospital.

## 'It felt so simple:' Damian Lillard explodes for 60 points to inspire Portland Trail Blazers to victory
 - [https://www.cnn.com/2023/01/26/sport/damian-lillard-portland-trail-blazers-nba-60-points-spt-intl/index.html](https://www.cnn.com/2023/01/26/sport/damian-lillard-portland-trail-blazers-nba-60-points-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 12:16:08+00:00
 - user: None

Damian Lillard was locked in on Wednesday, exploding for a season-high 60 points on just 29 shot attempts and 10 free throws, to help the Portland Trail Blazers beat the Utah Jazz 134-124.

## Israeli forces kill nine in Jenin clash with Palestinian gunmen, marking West Bank's deadliest day in over a year
 - [https://www.cnn.com/2023/01/26/middleeast/israel-raid-jenin-west-bank-intl/index.html](https://www.cnn.com/2023/01/26/middleeast/israel-raid-jenin-west-bank-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 11:40:57+00:00
 - user: None

Israeli forces killed nine Palestinians, including an elderly woman, and wounded several others during a raid in the restive West Bank city and refugee camp of Jenin on Thursday, the Palestinian Ministry of Health said.

## France recalls ambassador and will withdraw military forces from Burkina Faso
 - [https://www.cnn.com/2023/01/26/africa/france-withdraw-burkina-faso-intl/index.html](https://www.cnn.com/2023/01/26/africa/france-withdraw-burkina-faso-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 11:35:36+00:00
 - user: None

France will withdraw its military forces from Burkina Faso within a month, the French Ministry of Foreign Affairs told CNN on Wednesday.

## What it's like to travel to every country in the world
 - [https://www.cnn.com/travel/article/travel-every-country-in-the-world/index.html](https://www.cnn.com/travel/article/travel-every-country-in-the-world/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 11:34:11+00:00
 - user: None

After decades of traveling, both separately and together, Rachel Davey and Martina Sebova had each visited over 100 of the 195 UN-recognized countries and territories on the globe.

## Russian missiles strike Odesa region less than 24 hours after regional capital put on UNESCO heritage list
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-1-26-23/h_6ed184e8cdb465bae1dd7fa94e89c926](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-1-26-23/h_6ed184e8cdb465bae1dd7fa94e89c926)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 11:29:19.868782+00:00
 - user: None



## United CEO: Air travel system is 'stressed to the max'
 - [https://www.cnn.com/2023/01/26/business/united-ceo-air-travel-woes/index.html](https://www.cnn.com/2023/01/26/business/united-ceo-air-travel-woes/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 11:22:26+00:00
 - user: None

If airlines are to avoid repeats of recent service problems, they'll need to have a lot more back-up in place, according to United CEO Scott Kirby.

## Elena Rybakina beats Victoria Azarenka in straight sets to reach Australian Open final
 - [https://www.cnn.com/2023/01/26/tennis/elena-rybakina-victoria-azarenka-aryna-sabalenka-magda-linette-australian-open-semifinal-spt-intl/index.html](https://www.cnn.com/2023/01/26/tennis/elena-rybakina-victoria-azarenka-aryna-sabalenka-magda-linette-australian-open-semifinal-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 10:53:44+00:00
 - user: None

Elena Rybakina powered her way past two-time champion Victoria Azarenka to reach the Australian Open final, winning 7-6 6-3 on Thursday.

## Toyota names new CEO as Akio Toyoda steps down
 - [https://www.cnn.com/2023/01/26/business/japan-toyota-ceo-steps-down-intl-hnk/index.html](https://www.cnn.com/2023/01/26/business/japan-toyota-ceo-steps-down-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 10:15:36+00:00
 - user: None

Toyota's longtime president and CEO Akio Toyoda is stepping down and handing over the reins of the world's largest automaker to Lexus chief Koji Sato.

## Communing with the dead: A photographer spent 20 years documenting seánces
 - [https://www.cnn.com/style/article/shannon-taggart-photography-seance-spiritualism/index.html](https://www.cnn.com/style/article/shannon-taggart-photography-seance-spiritualism/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 10:04:34+00:00
 - user: None

Though photographer Shannon Taggart grew up only an hour from Lily Dale, New York, the lakeside hamlet where people congregate to commune with the dead, she didn't visit until she was 26 years old. She was interested in documenting the quaint cottage town, which first formed as a summer retreat for paranormal practitioners in the late 19th century, after the Spiritualist movement took root in the state and spread around the world.

## Memphis police to release body cam footage of violent arrest that led to Tyre Nichols' death
 - [https://www.cnn.com/2023/01/26/us/tyre-nichols-timeline-investigation/index.html](https://www.cnn.com/2023/01/26/us/tyre-nichols-timeline-investigation/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 09:07:28+00:00
 - user: None

Nearly three weeks after a traffic stop in Memphis resulted in a violent arrest and subsequent death of a driver, police are expected to release police body camera footage of the incident to the public.

## Half Moon Bay mass shooting suspect  is charged with 7 counts of murder in the deadliest attack the California county has ever seen
 - [https://www.cnn.com/2023/01/26/us/us-shootings-half-moon-bay-monterey-park-yakima/index.html](https://www.cnn.com/2023/01/26/us/us-shootings-half-moon-bay-monterey-park-yakima/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 08:20:52+00:00
 - user: None

The suspect in the Half Moon Bay, California, mass shooting was charged Wednesday with seven counts of murder and one count of attempted murder in what became the deadliest attack in San Mateo County's history, the district attorney said.

## Air sirens across Ukraine signal possible Russian attack, officials warn
 - [https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-1-26-23/index.html](https://edition.cnn.com/europe/live-news/russia-ukraine-war-news-1-26-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 07:29:18.458760+00:00
 - user: None



## Emergency power outages in several Ukrainian regions 'due to threat of a missile attack'
 - [https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-1-26-23/index.html](https://edition.cnn.com/webview/europe/live-news/russia-ukraine-war-news-1-26-23/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 07:29:18.339931+00:00
 - user: None



## IBM is cutting 3,900 jobs
 - [https://www.cnn.com/2023/01/26/tech/ibm-layoffs-intl-hnk/index.html](https://www.cnn.com/2023/01/26/tech/ibm-layoffs-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 07:16:23+00:00
 - user: None

IBM has become the latest tech giant to slash thousands of jobs, with 3,900 positions, or 1.5% of its global workforce, expected to be eliminated.

## Russian warship armed with hypersonic missiles to train with Chinese, South African navies
 - [https://www.cnn.com/2023/01/26/asia/russian-hypersonic-warship-south-africa-china-intl-hnk/index.html](https://www.cnn.com/2023/01/26/asia/russian-hypersonic-warship-south-africa-china-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 06:41:51+00:00
 - user: None

A Russian warship armed with advanced hypersonic missiles completed a drill in the Atlantic Ocean, ahead of joint naval exercises with the Chinese and South African navies scheduled for next month, the Russian Defense Ministry said Wednesday.

## Dashcam video shows woman rescued from abduction after police chase
 - [https://www.cnn.com/videos/us/2023/01/26/wisconsin-woman-abduction-police-chase-affil-wmtv-contd-vpx.cnn](https://www.cnn.com/videos/us/2023/01/26/wisconsin-woman-abduction-police-chase-affil-wmtv-contd-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 06:36:23+00:00
 - user: None

The Sheriff's office in Columbia County, Wisconsin, released footage capturing the dramatic rescue of a woman who was sleeping in her car at a rest stop when a stranger got in and drove off with her in the back seat. CNN affiliate WMTV has more.

## Viktor & Rolf couture show features upside-down and sideways gowns
 - [https://www.cnn.com/style/article/viktor-and-rolf-paris-haute-couture-week/index.html](https://www.cnn.com/style/article/viktor-and-rolf-paris-haute-couture-week/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 06:01:15+00:00
 - user: None

Paris Haute Couture Week is in full swing with dramatic runway shows and surreal, lavish looks worn by front-row A-Listers — with an unrecognizable, red-crystal-covered Doja Cat lighting up the internet earlier this week. On Wednesday, the label Viktor & Rolf (literally) turned fashion-upside down.

## Analysis: Biden gives Zelensky an 'iron fist' against Putin
 - [https://www.cnn.com/2023/01/26/politics/biden-western-alliance-against-putin/index.html](https://www.cnn.com/2023/01/26/politics/biden-western-alliance-against-putin/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 05:37:44+00:00
 - user: None

The more Russian President Vladimir Putin tries to break NATO, the stronger it gets.

## Chinese engineer sentenced to 8 years in US prison for spying
 - [https://www.cnn.com/2023/01/25/politics/chinese-engineer-sentence-spying-intl-hnk/index.html](https://www.cnn.com/2023/01/25/politics/chinese-engineer-sentence-spying-intl-hnk/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 04:52:04+00:00
 - user: None

A former graduate student in Chicago was sentenced to eight years in prison Wednesday for spying for the Chinese government by gathering information on engineers and scientists in the United States.

## Meta says it will restore Trump's Facebook and Instagram accounts
 - [https://www.cnn.com/collections/intl-2601-trump-meta/](https://www.cnn.com/collections/intl-2601-trump-meta/)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 04:25:20+00:00
 - user: None



## See what's it like in China's 'North Pole' during record-setting winter
 - [https://www.cnn.com/videos/world/2023/01/26/extreme-cold-weather-winter-asia-hancocks-pkg-oneworld-contd-intl-hnk-vpx.cnn](https://www.cnn.com/videos/world/2023/01/26/extreme-cold-weather-winter-asia-hancocks-pkg-oneworld-contd-intl-hnk-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 03:43:03+00:00
 - user: None

A wave of extreme cold has spread through northeast Asia, with parts of Japan and South Korea seeing heavy snow and record-breaking subzero temperatures during the Lunar New Year holiday. CNN's Paula Hancocks has more.

## Brazil fines Telegram for not suspending far-right congressman's account
 - [https://www.cnn.com/2023/01/25/americas/brazil-telegram-intl-latam/index.html](https://www.cnn.com/2023/01/25/americas/brazil-telegram-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 03:38:23+00:00
 - user: None

Brazil's Supreme Court Justice Alexandre de Moraes fined the messaging app Telegram on Wednesday for not suspending the account of a far-right elected official and social media influencer, according to a statement from the Supreme Court.

## How Germany's decision will change the conflict
 - [https://www.cnn.com/2023/01/25/europe/germany-leopard-tanks-ukraine-impact-explainer-intl/index.html](https://www.cnn.com/2023/01/25/europe/germany-leopard-tanks-ukraine-impact-explainer-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 03:05:15+00:00
 - user: None

After weeks of geopolitical squabbling, a major moment in the war in Ukraine has arrived: Germany has announced it will provide Leopard 2 tanks to Kyiv's troops in a major sign of support that is expected to be matched by the United States.

## Video from Antarctica shows ice shelf the size of London breaking off
 - [https://www.cnn.com/videos/world/2023/01/26/antarctica-glacier-brunt-ice-shelf-break-off-orig-contd-jc-jk.cnn](https://www.cnn.com/videos/world/2023/01/26/antarctica-glacier-brunt-ice-shelf-break-off-orig-contd-jc-jk.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 02:24:52+00:00
 - user: None

Drone footage from Antarctica shows the massive scale of an ice shelf that just broke off from Antarctica.

## Watch a sled dog's journey back to racing after a tragic accident
 - [https://www.cnn.com/videos/us/2023/01/26/sled-dogs-journey-racing-crash-affil-kbjr-pkg-cprog-vpx.kbjr](https://www.cnn.com/videos/us/2023/01/26/sled-dogs-journey-racing-crash-affil-kbjr-pkg-cprog-vpx.kbjr)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 02:14:42+00:00
 - user: None

A sled team in Brule, Wisconsin is preparing for one of their biggest races of the year; joining them, is their all-star sled dog "Wildfire" that has been on the road to recovery after a tragic snowmobile accident last winter. CNN's affiliate KBJR reports.

## Hear Wagner soldiers describe intense fighting near Bakhmut
 - [https://www.cnn.com/videos/world/2023/01/26/ukraine-russia-bakhmut-fighting-wagner-pleitgen-ebof-vpx.cnn](https://www.cnn.com/videos/world/2023/01/26/ukraine-russia-bakhmut-fighting-wagner-pleitgen-ebof-vpx.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 02:02:53+00:00
 - user: None

Russia and Ukraine are locked into a fierce fight for control of key cities in eastern Ukraine. CNN's Fred Pleitgen reports.

## Pence classified documents included briefing memos for foreign trips
 - [https://www.cnn.com/2023/01/25/politics/pence-classified-documents-briefing-memos-foreign-trips/index.html](https://www.cnn.com/2023/01/25/politics/pence-classified-documents-briefing-memos-foreign-trips/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 01:00:31+00:00
 - user: None

The roughly 12 classified documents found at the Indiana home of former Vice President Mike Pence included materials described as background briefing memos that were prepared for Pence's foreign trips, multiple sources told CNN.

## It takes these things to intervene in a mass shooting, according to experts
 - [https://www.cnn.com/2023/01/25/health/shooter-intervention-awareness-preparation-wellness/index.html](https://www.cnn.com/2023/01/25/health/shooter-intervention-awareness-preparation-wellness/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 00:36:42+00:00
 - user: None

At first, Brandon Tsay froze when a gunman aimed a firearm at him, he said. He was sure those would be his last moments.

## Japanese telescope captures mysterious blue spiral over Hawaii
 - [https://www.cnn.com/videos/us/2023/01/25/glowing-spiral-appears-hawaii-satellite-launch-cprog-orig-aw.cnn](https://www.cnn.com/videos/us/2023/01/25/glowing-spiral-appears-hawaii-satellite-launch-cprog-orig-aw.cnn)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 00:36:10+00:00
 - user: None

A Japanese telescope camera captured a 'flying spiral' in Hawaii shortly after SpaceX launched a new satellite.

## Cameroon ejected 32 players for failing age tests for a soccer tournament. How Samuel Eto'o is dealing with 'age cheating'
 - [https://www.cnn.com/2023/01/25/football/samuel-etoo-cameroon-age-players-africa-spt-intl/index.html](https://www.cnn.com/2023/01/25/football/samuel-etoo-cameroon-age-players-africa-spt-intl/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 00:33:18+00:00
 - user: None

It's been a problem for the ages but Cameroonian soccer great Samuel Eto'o appears determined to stamp it out.

## Magda Linette: Unseeded player credits calm as her weapon at Australian Open
 - [https://www.cnn.com/2023/01/25/tennis/magda-linette-profile-australian-open-intl-spt/index.html](https://www.cnn.com/2023/01/25/tennis/magda-linette-profile-australian-open-intl-spt/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 00:25:30+00:00
 - user: None

Fans and pundits alike expected a Polish player would compete in the semifinal of this year's Australian Open -- but possibly not an unseeded one.

## The UK car industry hasn't been this weak since 1956. And it's losing the EV race
 - [https://www.cnn.com/2023/01/25/cars/uk-car-production/index.html](https://www.cnn.com/2023/01/25/cars/uk-car-production/index.html)
 - RSS feed: http://rss.cnn.com/rss/edition.rss
 - date published: 2023-01-26 00:02:08+00:00
 - user: None

UK car manufacturing hit a 66-year low in 2022, as the closure of two plants, a global shortage of semiconductors and the effect of Covid lockdowns in China on auto supply chains crippled output.
