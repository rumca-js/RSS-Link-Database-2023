# Source Washington Examiner - politics, Source URL:https://feeds.feedburner.com/dcexaminer/Politics, Source language: en-US

## Congressional Democrats push back on new Biden immigration policies
 - [https://www.washingtonexaminer.com/news/house/congressional-democrats-push-back-biden-immigration](https://www.washingtonexaminer.com/news/house/congressional-democrats-push-back-biden-immigration)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-01-26 19:14:34+00:00
 - user: None

A group of more than 70 Democrats in the House and Senate sent President Joe Biden a letter Thursday urging him to reconsider policies restricting asylum access for migrants crossing the southern border.
