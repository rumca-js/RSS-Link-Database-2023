# Source The Washington Post - Tech, Source URL:https://feeds.washingtonpost.com/rss/business/technology, Source language: en-US

## FBI shuts down major ransomware gang that targeted schools, hospitals
 - [https://www.washingtonpost.com/national-security/2023/01/26/hive-ransomware-fbi-doj/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/national-security/2023/01/26/hive-ransomware-fbi-doj/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-26 11:20:02+00:00
 - user: None

Attorney General Merrick Garland said the group — called Hive — hacked and demanded ransom from hospitals, school districts, financial firms and other entities.

## How to juggle multiple TV streaming services without missing a show
 - [https://www.washingtonpost.com/technology/2022/06/28/streaming-tv-tips/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2022/06/28/streaming-tv-tips/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-26 09:32:15+00:00
 - user: None

Find out if it's okay to share your streaming password, how to save money with bundles, and the trick to pausing subscriptions.

## What Facebook and Trump have in common
 - [https://www.washingtonpost.com/technology/2023/01/26/facebook-reinstates-trump/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology](https://www.washingtonpost.com/technology/2023/01/26/facebook-reinstates-trump/?utm_source=rss&utm_medium=referral&utm_campaign=wp_business-technology)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-01-26 01:35:19+00:00
 - user: None

Facebook parent Meta announced former president Donald Trump will get his accounts back.
