# Source Wydarzenia Interia - Polska, Source URL:https://wydarzenia.interia.pl/polska/feed, Source language: pl-PL

## Kraken - nowy wariant koronawirusa - jest już w Polsce. Jakie ma objawy?
 - [https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-kraken-nowy-wariant-koronawirusa-jest-juz-w-polsce-jakie-ma-,nId,6556857](https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-kraken-nowy-wariant-koronawirusa-jest-juz-w-polsce-jakie-ma-,nId,6556857)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-01-26 13:57:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-koronawirus-chiny/polska/news-kraken-nowy-wariant-koronawirusa-jest-juz-w-polsce-jakie-ma-,nId,6556857"><img align="left" alt="Kraken - nowy wariant koronawirusa - jest już w Polsce. Jakie ma objawy?" src="https://i.iplsc.com/kraken-nowy-wariant-koronawirusa-jest-juz-w-polsce-jakie-ma/000G7TBMT8PVC2AA-C321.jpg" /></a>Kraken jest nowym subwariantem omikrona. Aktualnie jest wykrywany głównie w USA, ale przypadki zachorowań zarejestrowano również w Polsce. Wyjaśniamy jakie są objawy i czym charakteryzuje się agresywna odmiana koronawirusa.</p><br clear="all" />

## Kiedy na emeryturę idą Niemcy, a kiedy Czesi? Czyli jak na tle sąsiadów wygląda Polska
 - [https://wydarzenia.interia.pl/kraj/news-kiedy-na-emeryture-ida-niemcy-a-kiedy-czesi-czyli-jak-na-tle,nId,6556247](https://wydarzenia.interia.pl/kraj/news-kiedy-na-emeryture-ida-niemcy-a-kiedy-czesi-czyli-jak-na-tle,nId,6556247)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-01-26 06:55:22+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-kiedy-na-emeryture-ida-niemcy-a-kiedy-czesi-czyli-jak-na-tle,nId,6556247"><img align="left" alt="Kiedy na emeryturę idą Niemcy, a kiedy Czesi? Czyli jak na tle sąsiadów wygląda Polska" src="https://i.iplsc.com/kiedy-na-emeryture-ida-niemcy-a-kiedy-czesi-czyli-jak-na-tle/000GO05HJMIQ7PYR-C321.jpg" /></a>Wiek emerytalny w Polsce wynosi obecnie 65 lat w przypadku mężczyzn i 60 w przypadku kobiet. Od lat toczy się jednak na ten temat żywa dyskusja. Tymczasem okazuje się, że w porównaniu z innymi krajami europejskimi i tak pracujemy stosunkowo krótko. Ile wynosi wiek emerytalny u naszych sąsiadów?</p><br clear="all" />
