# Source pcgamer, Source URL:http://www.pcgamer.com/rss, Source language: en-US

## I was not prepared for Microsoft to surprise launch an action game that goes this hard
 - [https://www.pcgamer.com/hi-fi-rush-gameplay-impressions](https://www.pcgamer.com/hi-fi-rush-gameplay-impressions)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 23:31:55+00:00
 - user: None

Hi-Fi Rush's rhythmic combat is full of flashy combos and delicious grooves.

## The Day Before developers now say the launch delay was planned before the Steam takedown
 - [https://www.pcgamer.com/the-day-before-developers-now-say-the-launch-delay-was-planned-before-the-steam-takedown](https://www.pcgamer.com/the-day-before-developers-now-say-the-launch-delay-was-planned-before-the-steam-takedown)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 23:05:03+00:00
 - user: None

Fntastic initially blamed the eight month delay of The Day Before on a trademark dispute.

## Hogwarts Legacy will have more than 100 sidequests and doesn't care if you cast evil spells
 - [https://www.pcgamer.com/hogwarts-legacy-will-have-more-than-100-sidequests-and-doesnt-care-if-you-cast-evil-spells](https://www.pcgamer.com/hogwarts-legacy-will-have-more-than-100-sidequests-and-doesnt-care-if-you-cast-evil-spells)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 21:33:44+00:00
 - user: None

Everything in Hogwarts Legacy is "interconnected," except extreme criminality.

## Bungie's narrative team reveals why SIVA never came back in Destiny 2
 - [https://www.pcgamer.com/bungies-narrative-team-reveals-why-siva-never-came-back-in-destiny-2](https://www.pcgamer.com/bungies-narrative-team-reveals-why-siva-never-came-back-in-destiny-2)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 20:57:49+00:00
 - user: None

"SIVA is a story that was told in Rise of Iron, and was finalised in Rise of Iron."

## Meet Your Maker, one of the year's most promising shooters, is having an open beta in February
 - [https://www.pcgamer.com/meet-your-maker-one-of-the-years-most-promising-shooters-is-having-an-open-beta-in-february](https://www.pcgamer.com/meet-your-maker-one-of-the-years-most-promising-shooters-is-having-an-open-beta-in-february)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 17:30:17+00:00
 - user: None

The Dead By Daylight studio's new game will be open to all during the upcoming Steam Next Fest.

## Even if you find Deadpool funny, you won't get much out of Marvel's Midnight Suns' first DLC
 - [https://www.pcgamer.com/even-if-you-find-deadpool-funny-you-wont-get-much-out-of-marvels-midnight-suns-first-dlc](https://www.pcgamer.com/even-if-you-find-deadpool-funny-you-wont-get-much-out-of-marvels-midnight-suns-first-dlc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 17:00:28+00:00
 - user: None

Flat missions, clunky enemy design, and its star's generic combat abilities make The Good, The Bad, and The Undead an underwhelming start to the season pass

## Exclusive: The sickest pinball game of 2019 is getting a sequel
 - [https://www.pcgamer.com/xenotilt-the-sickest-pinball-game-of-2019-is-getting-a-sequel](https://www.pcgamer.com/xenotilt-the-sickest-pinball-game-of-2019-is-getting-a-sequel)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:59:09+00:00
 - user: None

Xenotilt is the sequel to the best virtual pinball game, and this time it's got cyborgs.

## Pizza Tower review: Madcap platforming at 100mph
 - [https://www.pcgamer.com/pizza-tower-review-madcap-platforming-at-100mph](https://www.pcgamer.com/pizza-tower-review-madcap-platforming-at-100mph)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:57:29+00:00
 - user: None

A non-stop, absurd, and wonderful slice of speedrunning action

## Hitman 3's new name, new mode, and new graphics tech are here
 - [https://www.pcgamer.com/hitman-3s-new-name-new-mode-and-new-graphics-tech-are-here](https://www.pcgamer.com/hitman-3s-new-name-new-mode-and-new-graphics-tech-are-here)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:43:05+00:00
 - user: None

A whole new world.

## Bungie is finally giving players a way to earn classic shaders and armour sets
 - [https://www.pcgamer.com/destiny-2-lightfall-legacy-focusing-shaders](https://www.pcgamer.com/destiny-2-lightfall-legacy-focusing-shaders)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:02:41+00:00
 - user: None

Just be warned: Those old Iron Banner and Trials sets are going to take some work to acquire.

## Dead Space Marker Fragment locations: How to get the secret ending
 - [https://www.pcgamer.com/dead-space-marker-fragment-locations-secret-ending](https://www.pcgamer.com/dead-space-marker-fragment-locations-secret-ending)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:55+00:00
 - user: None

Collect these mysterious markers to unlock a new fate.

## Everything that's new in the Dead Space remake
 - [https://www.pcgamer.com/dead-space-remake-new-stuff](https://www.pcgamer.com/dead-space-remake-new-stuff)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:39+00:00
 - user: None

Wondering what's been added to the original?

## Dead Space Security Clearance: How to unlock each level
 - [https://www.pcgamer.com/dead-space-security-clearance-all-levels](https://www.pcgamer.com/dead-space-security-clearance-all-levels)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:27+00:00
 - user: None

Gain clearance to loot locked rooms and containers.

## Dead Space weapon locations: Where to get every gun
 - [https://www.pcgamer.com/dead-space-weapon-locations-upgrades](https://www.pcgamer.com/dead-space-weapon-locations-upgrades)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:22+00:00
 - user: None

No more buying guns but you do have to spend a bit of time finding them.

## My most anticipated FPS this year comes from ex-Battlefield devs, and its destructibility looks unreal
 - [https://www.pcgamer.com/my-most-anticipated-fps-this-year-comes-from-ex-battlefield-devs-and-its-destructibility-looks-unreal](https://www.pcgamer.com/my-most-anticipated-fps-this-year-comes-from-ex-battlefield-devs-and-its-destructibility-looks-unreal)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:19+00:00
 - user: None

The Finals is coming, and it could be big.

## Dead Space Crew Rig locations for Master Override
 - [https://www.pcgamer.com/dead-space-crew-rig-locations-master-override](https://www.pcgamer.com/dead-space-crew-rig-locations-master-override)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:16+00:00
 - user: None

Complete the "You Are Not Authorised" side quest.

## Dead Space review
 - [https://www.pcgamer.com/deadspace-review](https://www.pcgamer.com/deadspace-review)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 16:00:06+00:00
 - user: None

A definitive remake and promising precedent for Dead Space's future.

## Naughty Dog is done with Uncharted, but The Last of Us is an open question
 - [https://www.pcgamer.com/naughty-dog-is-done-with-uncharted-but-the-last-of-us-is-an-open-question](https://www.pcgamer.com/naughty-dog-is-done-with-uncharted-but-the-last-of-us-is-an-open-question)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 15:37:17+00:00
 - user: None

Oh Neil, you tease.

## My heart is aching for this tiny single slot RTX 4090
 - [https://www.pcgamer.com/my-heart-is-aching-for-this-tiny-single-slot-rtx-4090](https://www.pcgamer.com/my-heart-is-aching-for-this-tiny-single-slot-rtx-4090)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 15:22:46+00:00
 - user: None

I'm drooling over this video test of Alphacool's gorgeous RTX 4090 block.

## Melting Terminator T-1000 bots can unclog your digestive system and break out of mini jail cells
 - [https://www.pcgamer.com/melting-terminator-t-1000-bots-can-unclog-your-digestive-system-and-break-out-of-a-mini-jail-cells](https://www.pcgamer.com/melting-terminator-t-1000-bots-can-unclog-your-digestive-system-and-break-out-of-a-mini-jail-cells)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 15:20:15+00:00
 - user: None

Researchers are putting "phase shifting bots" into action in a host of strange applications.

## Major US defence corp says no, playing War Thunder doesn't make you a threat to national security
 - [https://www.pcgamer.com/major-us-defence-corp-says-no-playing-war-thunder-doesnt-make-you-a-threat-to-national-security](https://www.pcgamer.com/major-us-defence-corp-says-no-playing-war-thunder-doesnt-make-you-a-threat-to-national-security)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 13:46:14+00:00
 - user: None

Raytheon has bigger fish to fry than your Steam library.

## Improve your RTX 4090's thermals by playing in a -53°C snowdrift
 - [https://www.pcgamer.com/improve-your-rtx-4090s-thermals-by-playing-in-a-53c-snowdrift](https://www.pcgamer.com/improve-your-rtx-4090s-thermals-by-playing-in-a-53c-snowdrift)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 12:45:19+00:00
 - user: None

-53°C temps in northern China has meant no overheating worries for this Intel Core i9 1300K & Nvidia RTX 4090 gaming PC build.

## Realism mod for Fallout 4 fixes its most unbelievable part: your ability to survive the intro
 - [https://www.pcgamer.com/realism-mod-for-fallout-4-fixes-its-most-unbelievable-part-your-ability-to-survive-the-intro](https://www.pcgamer.com/realism-mod-for-fallout-4-fixes-its-most-unbelievable-part-your-ability-to-survive-the-intro)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 12:14:40+00:00
 - user: None

Finally, an intro that makes sense.

## Here's when Dead Space releases in your time zone
 - [https://www.pcgamer.com/dead-space-release-times](https://www.pcgamer.com/dead-space-release-times)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 12:11:59+00:00
 - user: None

Release times broken down by region.

## Sierra's classic city builder returns next month with Pharaoh: A New Era
 - [https://www.pcgamer.com/sierras-classic-city-builder-returns-next-month-with-pharaoh-a-new-era](https://www.pcgamer.com/sierras-classic-city-builder-returns-next-month-with-pharaoh-a-new-era)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 11:26:31+00:00
 - user: None

Announced in 2020, the remake now has a release date.

## Wordle hint and answer today: Let's solve #586, January 26
 - [https://www.pcgamer.com/wordle-hint-answer-today-586-january-26](https://www.pcgamer.com/wordle-hint-answer-today-586-january-26)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 08:05:44+00:00
 - user: None

Wordle today: The solution and a hint for the #586 puzzle.

## Justice for Miranda finally achieved, thanks to Mass Effect mod
 - [https://www.pcgamer.com/justice-for-miranda-finally-achieved-thanks-to-mass-effect-mod](https://www.pcgamer.com/justice-for-miranda-finally-achieved-thanks-to-mass-effect-mod)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 04:09:51+00:00
 - user: None

Miranda's Long Walk makes the genetically engineered perfectionist worthwhile at last.

## Microsoft is shutting down its metaverse
 - [https://www.pcgamer.com/microsoft-is-shutting-down-its-metaverse](https://www.pcgamer.com/microsoft-is-shutting-down-its-metaverse)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 03:06:12+00:00
 - user: None

AltspaceVR has already been through this once.

## Oh great, crypto miners are selling repainted GPUs and passing them off as new
 - [https://www.pcgamer.com/oh-great-crypto-miners-are-selling-repainted-gpus-and-passing-them-off-as-new](https://www.pcgamer.com/oh-great-crypto-miners-are-selling-repainted-gpus-and-passing-them-off-as-new)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 01:19:02+00:00
 - user: None

Turns out those 'new' graphics cards on some Chinese retailers might not be after all.

## I played that $2,000 Steam game, and its ridiculous price is probably for the best
 - [https://www.pcgamer.com/i-played-that-dollar2000-steam-game-and-its-ridiculous-price-is-probably-for-the-best](https://www.pcgamer.com/i-played-that-dollar2000-steam-game-and-its-ridiculous-price-is-probably-for-the-best)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 00:47:34+00:00
 - user: None

You could buy the game and refund it, but I don't recommend it.

## Twitch finally plans to make pre-roll ads tolerable this year
 - [https://www.pcgamer.com/twitch-finally-plans-to-make-pre-roll-ads-tolerable-this-year](https://www.pcgamer.com/twitch-finally-plans-to-make-pre-roll-ads-tolerable-this-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-01-26 00:02:44+00:00
 - user: None

The platform is trying to make it easier to discover new streamers.
