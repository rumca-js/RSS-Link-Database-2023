# Source Reclaim The Net, Source URL:https://reclaimthenet.org/feed/, Source language: en-US

## Questions linger as Apple introduces end-to-end encryption for iCloud
 - [https://reclaimthenet.org/questions-linger-as-apple-introduces-end-to-end-encryption-for-icloud/](https://reclaimthenet.org/questions-linger-as-apple-introduces-end-to-end-encryption-for-icloud/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 20:13:41+00:00
 - user: None

<a href="https://reclaimthenet.org/questions-linger-as-apple-introduces-end-to-end-encryption-for-icloud/" rel="nofollow" title="Questions linger as Apple introduces end-to-end encryption for iCloud"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/apple-ic.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>🛡</p>
<p>The post <a href="https://reclaimthenet.org/questions-linger-as-apple-introduces-end-to-end-encryption-for-icloud/" rel="nofollow">Questions linger as Apple introduces end-to-end encryption for iCloud</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## German government secretly met with US Big Tech to censor speech
 - [https://reclaimthenet.org/germany-secretly-met-with-us-big-tech-to-censor-speech/](https://reclaimthenet.org/germany-secretly-met-with-us-big-tech-to-censor-speech/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 19:53:42+00:00
 - user: None

<a href="https://reclaimthenet.org/germany-secretly-met-with-us-big-tech-to-censor-speech/" rel="nofollow" title="German government secretly met with US Big Tech to censor speech"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/angela-a.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Lawmakers want to know whether it was a violation of the German Constitution.</p>
<p>The post <a href="https://reclaimthenet.org/germany-secretly-met-with-us-big-tech-to-censor-speech/" rel="nofollow">German government secretly met with US Big Tech to censor speech</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Adam Curry plugs GrapheneOS on Joe Rogan
 - [https://reclaimthenet.org/adam-curry-plugs-grapheneos-on-joe-rogan/](https://reclaimthenet.org/adam-curry-plugs-grapheneos-on-joe-rogan/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 19:29:13+00:00
 - user: None

<a href="https://reclaimthenet.org/adam-curry-plugs-grapheneos-on-joe-rogan/" rel="nofollow" title="Adam Curry plugs GrapheneOS on Joe Rogan"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/curry.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Support for the privacy-focussed mobile OS.</p>
<p>The post <a href="https://reclaimthenet.org/adam-curry-plugs-grapheneos-on-joe-rogan/" rel="nofollow">Adam Curry plugs GrapheneOS on Joe Rogan</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## New York to hire a “Chief Customer Experience Officer” to oversee digital ID plans
 - [https://reclaimthenet.org/new-york-to-hire-a-digitla-id-officer/](https://reclaimthenet.org/new-york-to-hire-a-digitla-id-officer/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 19:01:57+00:00
 - user: None

<a href="https://reclaimthenet.org/new-york-to-hire-a-digitla-id-officer/" rel="nofollow" title="New York to hire a &#8220;Chief Customer Experience Officer&#8221; to oversee digital ID plans"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/hochul-1.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>For access to services and more.</p>
<p>The post <a href="https://reclaimthenet.org/new-york-to-hire-a-digitla-id-officer/" rel="nofollow">New York to hire a &#8220;Chief Customer Experience Officer&#8221; to oversee digital ID plans</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## State representative hints at digital ID push
 - [https://reclaimthenet.org/dan-miller-pennsylvania-digital-id/](https://reclaimthenet.org/dan-miller-pennsylvania-digital-id/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 18:19:08+00:00
 - user: None

<a href="https://reclaimthenet.org/dan-miller-pennsylvania-digital-id/" rel="nofollow" title="State representative hints at digital ID push"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/rep-miller.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Another state putting it on the agenda.</p>
<p>The post <a href="https://reclaimthenet.org/dan-miller-pennsylvania-digital-id/" rel="nofollow">State representative hints at digital ID push</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Whistleblower alleges Twitter employees still have access to all users’ accounts, even after major hack
 - [https://reclaimthenet.org/whistleblower-twitter-employees-access-all-users-accounts/](https://reclaimthenet.org/whistleblower-twitter-employees-access-all-users-accounts/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 16:16:04+00:00
 - user: None

<a href="https://reclaimthenet.org/whistleblower-twitter-employees-access-all-users-accounts/" rel="nofollow" title="Whistleblower alleges Twitter employees still have access to all users&#8217; accounts, even after major hack"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/twitter-23.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A newly-filed FTC complaint.</p>
<p>The post <a href="https://reclaimthenet.org/whistleblower-twitter-employees-access-all-users-accounts/" rel="nofollow">Whistleblower alleges Twitter employees still have access to all users&#8217; accounts, even after major hack</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Judge calls California’s medical misinformation law “nonsense,” blocks it
 - [https://reclaimthenet.org/judge-blocks-californias-medical-misinformation-law/](https://reclaimthenet.org/judge-blocks-californias-medical-misinformation-law/)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-01-26 02:42:21+00:00
 - user: None

<a href="https://reclaimthenet.org/judge-blocks-californias-medical-misinformation-law/" rel="nofollow" title="Judge calls California&#8217;s medical misinformation law &#8220;nonsense,&#8221; blocks it"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/01/calif-misin-law.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>On First Amendment grounds.</p>
<p>The post <a href="https://reclaimthenet.org/judge-blocks-californias-medical-misinformation-law/" rel="nofollow">Judge calls California&#8217;s medical misinformation law &#8220;nonsense,&#8221; blocks it</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>
