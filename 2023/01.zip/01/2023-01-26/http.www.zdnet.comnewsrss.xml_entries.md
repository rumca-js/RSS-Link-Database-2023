# Source ZDNET, Source URL:http://www.zdnet.com/news/rss.xml, Source language: en-US

## What is Firefox Nightly and should you be using it?
 - [https://www.zdnet.com/home-and-office/work-life/what-is-firefox-nightly-and-should-you-be-using-it/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/what-is-firefox-nightly-and-should-you-be-using-it/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 20:59:30+00:00
 - user: None

If you're looking to get the newest (sometimes experimental) features in your browser, Firefox Nightly might be what you need.

## Australia, Singapore firms amongst most likely to halt digital transformation due to cyberwarfare risks
 - [https://www.zdnet.com/article/australia-singapore-firms-amongst-most-likely-to-halt-digital-transformation-due-to-cyberwarfare-risks/#ftag=RSSbaffb68](https://www.zdnet.com/article/australia-singapore-firms-amongst-most-likely-to-halt-digital-transformation-due-to-cyberwarfare-risks/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 20:48:51+00:00
 - user: None

Organisations in Australia, the US, and Singapore are amongst the top most likely to stall their digital transformation initiatives due to cyberwarfare threats, above the global average of 55%.

## Earth will have a close encounter with an asteroid this week
 - [https://www.zdnet.com/article/earth-will-have-its-closest-encounter-with-an-asteroid-this-week/#ftag=RSSbaffb68](https://www.zdnet.com/article/earth-will-have-its-closest-encounter-with-an-asteroid-this-week/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 20:29:00+00:00
 - user: None

NASA predicts that the asteroid will make one of the closest approaches by a known near-Earth object ever recorded. However, it poses no harm to mankind.

## Get a year of Peacock for only $30
 - [https://www.zdnet.com/home-and-office/home-entertainment/peacock-subscription-deal-coupon-promo-code/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/peacock-subscription-deal-coupon-promo-code/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 20:22:00+00:00
 - user: None

Ready to catch up on all-things Pawnee? This deal can have you laughing with Knope in no time. See special code.

## The 5 best indoor gardens of 2023
 - [https://www.zdnet.com/home-and-office/kitchen-household/best-indoor-garden/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/best-indoor-garden/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 20:07:00+00:00
 - user: None

Growing your own herbs is easier than ever. The best indoor gardens have autonomous watering and automatic light modes so you can easily grow your own garden.

## Bowers & Wilkins' Pi7 S2 are music to my ears, but there's a catch
 - [https://www.zdnet.com/article/bowers-wilkins-pi7-s2-are-the-best-wireless-earbuds-ive-heard-but-theres-a-catch/#ftag=RSSbaffb68](https://www.zdnet.com/article/bowers-wilkins-pi7-s2-are-the-best-wireless-earbuds-ive-heard-but-theres-a-catch/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 19:49:33+00:00
 - user: None

Improved connectivity, longer battery life, and some of the best audio output I've heard still don't make the Pi7 S2 an impulse buy, for reasons beyond my control.

## DOJ takes down ransomware group with a '21st century cyber stakeout'
 - [https://www.zdnet.com/article/doj-takes-down-ransomware-group-with-a-21st-century-cyber-stakeout/#ftag=RSSbaffb68](https://www.zdnet.com/article/doj-takes-down-ransomware-group-with-a-21st-century-cyber-stakeout/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 18:56:03+00:00
 - user: None

Authorities have disrupted the Hive ransomware group by infiltrating its computer networks and capturing its decryption keys, saving victims over $100 million in ransom payments.

## I tried to charge my Tesla with Anker's PowerHouse 767. Here’s what happened
 - [https://www.zdnet.com/article/i-tried-to-charge-my-tesla-with-ankers-powerhouse-767-heres-what-happened/#ftag=RSSbaffb68](https://www.zdnet.com/article/i-tried-to-charge-my-tesla-with-ankers-powerhouse-767-heres-what-happened/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 18:48:00+00:00
 - user: None

Is it possible to charge a Tesla with Anker's latest PowerHouse power station? Yes! Should you? That's debatable, but it didn't stop us from trying.

## Razer's Edge Gaming handheld now available in Wi-Fi and 5G flavors
 - [https://www.zdnet.com/home-and-office/home-entertainment/razers-edge-gaming-handheld-now-available-in-wi-fi-and-5g-flavors/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/razers-edge-gaming-handheld-now-available-in-wi-fi-and-5g-flavors/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 18:14:09+00:00
 - user: None

The company's long-teased, Android-based portable console is now available, and we finally know how much the 5G version exclusive to Verizon Warless will cost.

## How to take a screenshot on Android
 - [https://www.zdnet.com/article/how-to-take-a-screenshot-on-android/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-take-a-screenshot-on-android/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 18:02:33+00:00
 - user: None

Taking a screenshot on your Android phone is a convenient way to keep information handy. Here's everything you need to know.

## How to cool your Raspberry Pi (and should you?)
 - [https://www.zdnet.com/article/how-to-cool-your-raspberry-pi/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-cool-your-raspberry-pi/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 17:46:37+00:00
 - user: None

Does your Raspberry Pi need additional cooling?

## 3 security gadgets I never leave home without
 - [https://www.zdnet.com/article/3-security-gadgets-i-never-leave-home-without/#ftag=RSSbaffb68](https://www.zdnet.com/article/3-security-gadgets-i-never-leave-home-without/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 17:43:50+00:00
 - user: None

These gadgets give you a huge advantage over the hackers.

## How to add multiple keyboards to the Gmail web app
 - [https://www.zdnet.com/home-and-office/work-life/how-to-add-multiple-keyboards-to-the-gmail-web-app/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/how-to-add-multiple-keyboards-to-the-gmail-web-app/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 17:40:22+00:00
 - user: None

If you need to use different languages for different email recipients, Gmail has you covered with the Input Tools option.

## Singapore to tag unregistered SMS senders as 'likely scam'
 - [https://www.zdnet.com/article/singapore-to-tag-unregistered-sms-senders-as-likely-scam/#ftag=RSSbaffb68](https://www.zdnet.com/article/singapore-to-tag-unregistered-sms-senders-as-likely-scam/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 17:13:59+00:00
 - user: None

Businesses not registered with the Singapore SMS Sender ID Registry by January 31 will have their messages labelled as "Likely-SCAM", as the country rolls out more measures to combat online scams.

## How to change your username in Windows 11
 - [https://www.zdnet.com/article/how-to-change-your-username-in-windows-11/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-change-your-username-in-windows-11/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 15:51:38+00:00
 - user: None

You can change the name for a local account and also for a Microsoft account through Windows 11.

## How to pair Bose Bluetooth headphones to any device
 - [https://www.zdnet.com/article/how-to-pair-bose-bluetooth-headphones-to-any-device/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-pair-bose-bluetooth-headphones-to-any-device/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 14:30:17+00:00
 - user: None

Skip the pairing frustration like you would a bad '90s pop ballad: Here's how to successfully pair your Bose headphones with everything from an iPhone to a Windows PC.

## NSA and CISA alert: This phishing scam could give hackers control of your PC
 - [https://www.zdnet.com/article/nsa-and-cisa-alert-this-phishing-scam-could-give-hackers-control-of-your-pc/#ftag=RSSbaffb68](https://www.zdnet.com/article/nsa-and-cisa-alert-this-phishing-scam-could-give-hackers-control-of-your-pc/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 13:21:10+00:00
 - user: None

Cyber criminals are convincing people to install legitimate remote monitoring software - which they use to steal money from victims.

## ChatGPT can write code. Now researchers say it's good at fixing bugs too
 - [https://www.zdnet.com/article/chatgpt-can-write-code-now-researchers-say-its-good-at-fixing-bugs-too/#ftag=RSSbaffb68](https://www.zdnet.com/article/chatgpt-can-write-code-now-researchers-say-its-good-at-fixing-bugs-too/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 13:19:00+00:00
 - user: None

A developer's new best friend? ChatGPT is up with the best when it comes to automatically debugging code. But whether it saves developers' time or creates more work remains to be seen.

## How to trade in your old devices for Amazon gift cards
 - [https://www.zdnet.com/article/how-to-trade-in-your-old-devices-for-amazon-gift-cards/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-trade-in-your-old-devices-for-amazon-gift-cards/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 13:17:00+00:00
 - user: None

Here's a simple way to jumpstart your spring decluttering and get paid for it.

## The developer role is changing radically, and these figures show how
 - [https://www.zdnet.com/article/the-developer-role-is-changing-radically-and-these-figures-show-how/#ftag=RSSbaffb68](https://www.zdnet.com/article/the-developer-role-is-changing-radically-and-these-figures-show-how/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 13:08:34+00:00
 - user: None

Data from Github suggests there are now more developers than ever. Here's what has changed.

## Microsoft is testing this neat split-screen tabs feature for its Edge browser
 - [https://www.zdnet.com/home-and-office/work-life/microsoft-is-testing-this-neat-split-screen-tabs-feature-for-its-edge-browser/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/microsoft-is-testing-this-neat-split-screen-tabs-feature-for-its-edge-browser/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-01-26 10:54:29+00:00
 - user: None

Microsoft could soon give users a handy way to compare the content of two tabs in its Edge browser.
