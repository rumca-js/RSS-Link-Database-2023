# Source Wydarzenia Interia, Source URL:https://wydarzenia.interia.pl/feed, Source language: pl-PL

## Archiwa Narodowe zaapelowały do byłych prezydentów USA. Chodzi o dokumenty
 - [https://wydarzenia.interia.pl/zagranica/news-archiwa-narodowe-zaapelowaly-do-bylych-prezydentow-usa-chodz,nId,6559098](https://wydarzenia.interia.pl/zagranica/news-archiwa-narodowe-zaapelowaly-do-bylych-prezydentow-usa-chodz,nId,6559098)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 21:56:02+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-archiwa-narodowe-zaapelowaly-do-bylych-prezydentow-usa-chodz,nId,6559098"><img align="left" alt="Archiwa Narodowe zaapelowały do byłych prezydentów USA. Chodzi o dokumenty" src="https://i.iplsc.com/archiwa-narodowe-zaapelowaly-do-bylych-prezydentow-usa-chodz/000GOA5082M1951N-C321.jpg" /></a>Archiwa Narodowe Stanów Zjednoczonych zwróciły się do byłych prezydentów i wiceprezydentów z prośbą, by sprawdzili, czy nie posiadają niejawnych dokumentów. 
Apel urzędu ma związek ze znalezieniem takich materiałów u byłych najważniejszych urzędników USA oraz u obecnie urzędującego prezydenta. W dwóch przypadkach do zbadania sprawy powołano niezależnych prokuratorów.</p><br clear="all" />

## NASA pokazało zdjęcie "marsjańskiego niedźwiedzia"
 - [https://wydarzenia.interia.pl/news-nasa-pokazalo-zdjecie-marsjanskiego-niedzwiedzia,nId,6559093](https://wydarzenia.interia.pl/news-nasa-pokazalo-zdjecie-marsjanskiego-niedzwiedzia,nId,6559093)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 21:40:52+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/news-nasa-pokazalo-zdjecie-marsjanskiego-niedzwiedzia,nId,6559093"><img align="left" alt="NASA pokazało zdjęcie &quot;marsjańskiego niedźwiedzia&quot;" src="https://i.iplsc.com/nasa-pokazalo-zdjecie-marsjanskiego-niedzwiedzia/000GOA1CJUOVFGYK-C321.jpg" /></a>Głowa niedźwiedzia - tak okrzyknięto formację skał i kraterów na Marsie, która została sfotografowana przez teleskop NASA. Udało się ją uwiecznić dzięki systemowi HiRISE, który prowadzi obserwację &quot;czerwonej planety&quot;, i jest w stanie przesyłać na Ziemię zdjęcia w wysokiej rozdzielczości.</p><br clear="all" />

## Zachodnia whisky wraca do Rosji. Importerzy wymyślili obejście
 - [https://wydarzenia.interia.pl/zagranica/news-zachodnia-whisky-wraca-do-rosji-importerzy-wymyslili-obejsci,nId,6559078](https://wydarzenia.interia.pl/zagranica/news-zachodnia-whisky-wraca-do-rosji-importerzy-wymyslili-obejsci,nId,6559078)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 21:10:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zachodnia-whisky-wraca-do-rosji-importerzy-wymyslili-obejsci,nId,6559078"><img align="left" alt="Zachodnia whisky wraca do Rosji. Importerzy wymyślili obejście" src="https://i.iplsc.com/zachodnia-whisky-wraca-do-rosji-importerzy-wymyslili-obejsci/000GO9Y4QKNL2F0Q-C321.jpg" /></a>Marki takie jak Johnnie Walker i Jägermeister najprawdopodobniej wrócą na półki rosyjskich sklepów, mimo że wciąż nie zgadzają się na to producenci tych alkoholi. Wszystko dzięki mechanizmowi importu równoległego.</p><br clear="all" />

## Prosili o pomoc. Gdy TOPR dotarł na miejsce, schodzili już o własnych siłach
 - [https://wydarzenia.interia.pl/malopolskie/news-prosili-o-pomoc-gdy-topr-dotarl-na-miejsce-schodzili-juz-o-w,nId,6559083](https://wydarzenia.interia.pl/malopolskie/news-prosili-o-pomoc-gdy-topr-dotarl-na-miejsce-schodzili-juz-o-w,nId,6559083)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 21:03:12+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-prosili-o-pomoc-gdy-topr-dotarl-na-miejsce-schodzili-juz-o-w,nId,6559083"><img align="left" alt="Prosili o pomoc. Gdy TOPR dotarł na miejsce, schodzili już o własnych siłach" src="https://i.iplsc.com/prosili-o-pomoc-gdy-topr-dotarl-na-miejsce-schodzili-juz-o-w/000GO9YTTEH9UJ6A-C321.jpg" /></a>Na centralę TOPR dotarło w środę zgłoszenie od trzech turystów. Zgodnie z przekazanymi informacjami, utknęli oni w trudnym terenie i prosili o ewakuację śmigłowcem. Gdy ratownicy dotarli na miejsce, okazało się, że dwie osoby schodziły już z góry o własnych siłach. Na miejscu pozostał natomiast jeden turysta potrzebujący pomocy.</p><br clear="all" />

## Rzucił się pod pług śnieżny, by uratować córki. Stracił obie nogi
 - [https://wydarzenia.interia.pl/zagranica/news-rzucil-sie-pod-plug-sniezny-by-uratowac-corki-stracil-obie-n,nId,6559036](https://wydarzenia.interia.pl/zagranica/news-rzucil-sie-pod-plug-sniezny-by-uratowac-corki-stracil-obie-n,nId,6559036)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 20:40:26+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rzucil-sie-pod-plug-sniezny-by-uratowac-corki-stracil-obie-n,nId,6559036"><img align="left" alt="Rzucił się pod pług śnieżny, by uratować córki. Stracił obie nogi" src="https://i.iplsc.com/rzucil-sie-pod-plug-sniezny-by-uratowac-corki-stracil-obie-n/000GO9SAKOQO7W0A-C321.jpg" /></a>Amputacja dwóch nóg i liczne złamania - to obrażenia Dave'a Milna, który zaryzykował własne życie, by ratować swoje córki. Mężczyzna podczas wypoczynku w popularnym kurorcie narciarskim w Kalifornii zauważył, że na jego roczną i trzyletnią córkę jedzie pług śnieżny. Bez namysłu rzucił się między dzieci a maszynę - dziewczynki udało się uratować, ich ojca czeka teraz długa walka i przystosowanie się do nowego życia. </p><br clear="all" />

## Marian Banaś w Sejmie. Komisja zajmowała się kontrolą w PKN Orlen
 - [https://wydarzenia.interia.pl/kraj/news-marian-banas-w-sejmie-komisja-zajmowala-sie-kontrola-w-pkn-o,nId,6559073](https://wydarzenia.interia.pl/kraj/news-marian-banas-w-sejmie-komisja-zajmowala-sie-kontrola-w-pkn-o,nId,6559073)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 20:39:36+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-marian-banas-w-sejmie-komisja-zajmowala-sie-kontrola-w-pkn-o,nId,6559073"><img align="left" alt="Marian Banaś w Sejmie. Komisja zajmowała się kontrolą w PKN Orlen" src="https://i.iplsc.com/marian-banas-w-sejmie-komisja-zajmowala-sie-kontrola-w-pkn-o/000GO9V3GQAAM89L-C321.jpg" /></a>Kontrolerzy NIK mieli mieli w maju rozpocząć kontrolę w Orlenie, jednak usłyszeli, że zarząd spółki odmawia poddania się czynnościom kontrolnym. - Koncern nie może udostępnić dokumentów, jeżeli zakres kontroli NIK wykracza poza przepisy prawa - mówili w czwartek w Sejmie przedstawiciele PKN Orlen. - Kontrola NIK rozpoczyna się na podstawie przedstawienia jednostce upoważnień - mówił z kolei przedstawiciel Izby.</p><br clear="all" />

## Serbia po raz pierwszy ogłosiła, że może przyłączyć się do sankcji na Rosję
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-serbia-po-raz-pierwszy-oglosila-ze-moze-przylaczyc-sie-do-sa,nId,6559046](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-serbia-po-raz-pierwszy-oglosila-ze-moze-przylaczyc-sie-do-sa,nId,6559046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 20:17:38+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-serbia-po-raz-pierwszy-oglosila-ze-moze-przylaczyc-sie-do-sa,nId,6559046"><img align="left" alt="Serbia po raz pierwszy ogłosiła, że może przyłączyć się do sankcji na Rosję" src="https://i.iplsc.com/serbia-po-raz-pierwszy-oglosila-ze-moze-przylaczyc-sie-do-sa/000GO9PDOHC73UX9-C321.jpg" /></a>W środę minister spraw zagranicznych Serbii Ivica Daczić oznajmił, że Belgrad dopuszcza możliwość przyłączenia się do sankcji UE wobec Rosji. Była to pierwsza taka wypowiedź przedstawiciela serbskich władz od lutego 2022 roku, czyli początku inwazji Kremla na Ukrainę - poinformował w czwartek portal Euractiv.</p><br clear="all" />

## Niemcy w szeregach Rosjan. Zostali złapani w Bachmucie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-niemcy-w-szeregach-rosjan-zostali-zlapani-w-bachmucie,nId,6559024](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-niemcy-w-szeregach-rosjan-zostali-zlapani-w-bachmucie,nId,6559024)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 20:12:55+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-niemcy-w-szeregach-rosjan-zostali-zlapani-w-bachmucie,nId,6559024"><img align="left" alt="Niemcy w szeregach Rosjan. Zostali złapani w Bachmucie" src="https://i.iplsc.com/niemcy-w-szeregach-rosjan-zostali-zlapani-w-bachmucie/000GO9LBU9QVAT7L-C321.jpg" /></a>Ukraińscy żołnierze mieli w Bachmucie złapać dwóch obywateli Niemiec, którzy walczyli jako najemnicy dla tzw. grupy Wagnera. Otrzymywali miesięczne pensje w wysokości 7000 dolarów. Mogli też liczyć na premię, za zabicie cudzoziemca walczącego po stronie Ukrainy.</p><br clear="all" />

## Zmiany w Kodeksie wyborczym. Sejm za Centralnym Rejestrem Wyborców
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-sejm-za-centralnym-rejestrem-wyb,nId,6559052](https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-sejm-za-centralnym-rejestrem-wyb,nId,6559052)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 20:00:28+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-sejm-za-centralnym-rejestrem-wyb,nId,6559052"><img align="left" alt="Zmiany w Kodeksie wyborczym. Sejm za Centralnym Rejestrem Wyborców" src="https://i.iplsc.com/zmiany-w-kodeksie-wyborczym-sejm-za-centralnym-rejestrem-wyb/000GAH9YNNBL3N15-C321.jpg" /></a>Sejm uchwalił w czwartek nowelizację Kodeksu wyborczego, która m.in. wprowadza Centralny Rejestr Wyborców i ma też, wedle jej autorów, zwiększyć frekwencję wyborczą. Nowelę poparło 230 posłów, przeciw było 220, nikt nie wstrzymał się od głosu.</p><br clear="all" />

## Nowy dodatek w służbach, antyemerytalny. Sejm uchwalił ustawę
 - [https://wydarzenia.interia.pl/kraj/news-nowy-dodatek-w-sluzbach-antyemerytalny-sejm-uchwalil-ustawe,nId,6559018](https://wydarzenia.interia.pl/kraj/news-nowy-dodatek-w-sluzbach-antyemerytalny-sejm-uchwalil-ustawe,nId,6559018)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 19:52:18+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-dodatek-w-sluzbach-antyemerytalny-sejm-uchwalil-ustawe,nId,6559018"><img align="left" alt="Nowy dodatek w służbach, antyemerytalny. Sejm uchwalił ustawę" src="https://i.iplsc.com/nowy-dodatek-w-sluzbach-antyemerytalny-sejm-uchwalil-ustawe/000G5E5117WY72N8-C321.jpg" /></a>Ustawa, która wprowadzi nowy dodatek &quot;antyemerytalny&quot; dla funkcjonariuszy i żołnierzy po 15 latach służby, została w czwartek uchwalona przez Sejm. Przewiduje ona także, że obowiązujący już w kilku służbach dodatek motywacyjny po 25 latach obejmie również służby specjalne, KAS i Straż Marszałkowską. Teraz ustawa trafi do Senatu.</p><br clear="all" />

## Przygarnęła kotkę. "Nie miałam pojęcia, że tak urośnie"
 - [https://wydarzenia.interia.pl/zagranica/news-przygarnela-kotke-nie-mialam-pojecia-ze-tak-urosnie,nId,6559019](https://wydarzenia.interia.pl/zagranica/news-przygarnela-kotke-nie-mialam-pojecia-ze-tak-urosnie,nId,6559019)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 19:32:53+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przygarnela-kotke-nie-mialam-pojecia-ze-tak-urosnie,nId,6559019"><img align="left" alt="Przygarnęła kotkę. &quot;Nie miałam pojęcia, że tak urośnie&quot;" src="https://i.iplsc.com/przygarnela-kotke-nie-mialam-pojecia-ze-tak-urosnie/000GO9NC23A74XHI-C321.jpg" /></a>26-latka z USA w lipcu 2022 roku adoptowała małe kociątko - jak twierdzi, nie miała pojęcia, jak duże urośnie. Dziś zwierzak ma dziewięć miesięcy, metr długości i waży niemal 10 kilogramów. - Ludzie są zdumieni, gdy go widzą, pytają, czy nie jest skrzyżowaniem rysia z kotem. </p><br clear="all" />

## Morawiecki: Polska będzie za dostarczeniem Ukrainie samolotów bojowych
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-morawiecki-polska-bedzie-za-dostarczeniem-ukrainie-samolotow,nId,6559029](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-morawiecki-polska-bedzie-za-dostarczeniem-ukrainie-samolotow,nId,6559029)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 19:17:38+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-morawiecki-polska-bedzie-za-dostarczeniem-ukrainie-samolotow,nId,6559029"><img align="left" alt="Morawiecki: Polska będzie za dostarczeniem Ukrainie samolotów bojowych" src="https://i.iplsc.com/morawiecki-polska-bedzie-za-dostarczeniem-ukrainie-samolotow/000GO9LVOJPWGLMA-C321.jpg" /></a>Reżim Putina jest kolosem na glinianych nogach, ale pozostaje kolosem - powiedział w czwartek w wywiadzie dla francuskiej telewizji LCI premier Mateusz Morawiecki. Podkreślił jednak, że Zachód &quot;powinien być bardziej odważny&quot;, wspierając Ukrainę. Dodał też, że jeżeli rozpatrywana będzie decyzja o dostarczeniu Ukraińcom samolotów bojowych, to Polska będzie głosować &quot;za&quot;.</p><br clear="all" />

## Zgromadzenie Parlamentarne Rady Europy chce ścigania Łukaszenki i Putina
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zgromadzenie-parlamentarne-rady-europy-chce-scigania-lukasze,nId,6559021](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zgromadzenie-parlamentarne-rady-europy-chce-scigania-lukasze,nId,6559021)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 19:06:02+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zgromadzenie-parlamentarne-rady-europy-chce-scigania-lukasze,nId,6559021"><img align="left" alt="Zgromadzenie Parlamentarne Rady Europy chce ścigania Łukaszenki i Putina" src="https://i.iplsc.com/zgromadzenie-parlamentarne-rady-europy-chce-scigania-lukasze/000GO9KG7LE7VTFO-C321.jpg" /></a>Zgromadzenie Parlamentarne Rady Europy (ZPRE) przyjęło w czwartek rezolucję, popierającą ściganie zbrodni przeciwko Ukrainie, popełnionych zarówno przez przywódców wojskowych i politycznych Rosji, jak też Białorusi - poinformowano na stronie ZPRE. Jak dodano, osądzać powinien nowy, specjalnie utworzony w tym celu trybunał.</p><br clear="all" />

## Nauczycielka zmuszała ucznia do seksu. Dawała mu lepsze stopnie
 - [https://wydarzenia.interia.pl/zagranica/news-nauczycielka-zmuszala-ucznia-do-seksu-dawala-mu-lepsze-stopn,nId,6559013](https://wydarzenia.interia.pl/zagranica/news-nauczycielka-zmuszala-ucznia-do-seksu-dawala-mu-lepsze-stopn,nId,6559013)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 18:56:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nauczycielka-zmuszala-ucznia-do-seksu-dawala-mu-lepsze-stopn,nId,6559013"><img align="left" alt="Nauczycielka zmuszała ucznia do seksu. Dawała mu lepsze stopnie" src="https://i.iplsc.com/nauczycielka-zmuszala-ucznia-do-seksu-dawala-mu-lepsze-stopn/000GO9I8JC4JFH6F-C321.jpg" /></a>Nauczycielka liceum została oskarżona o przestępstwa na tle seksualnym po tym, jak zmuszała jednego ze swoich uczniów do stosunku. Jak wynika z ustaleń policji ze stanu Missouri, kobieta &quot;nagradzała&quot; nieletniego wysokimi stopniami.</p><br clear="all" />

## Białorusini o walkach pod Bachmutem: Nigdy nie widzieliśmy czegoś takiego
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorusini-o-walkach-pod-bachmutem-nigdy-nie-widzielismy-cz,nId,6558967](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorusini-o-walkach-pod-bachmutem-nigdy-nie-widzielismy-cz,nId,6558967)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 18:23:31+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-bialorusini-o-walkach-pod-bachmutem-nigdy-nie-widzielismy-cz,nId,6558967"><img align="left" alt="Białorusini o walkach pod Bachmutem: Nigdy nie widzieliśmy czegoś takiego" src="https://i.iplsc.com/bialorusini-o-walkach-pod-bachmutem-nigdy-nie-widzielismy-cz/000GFPPU3DN84V66-C321.jpg" /></a>- Nigdy wcześniej nie widzieliśmy czegoś podobnego - mówili białoruscy ochotnicy z pułku im. Konstantego Kalinowskiego na temat walk w pobliżu atakowanego przez rosyjskie wojska Bachmutu na wschodzie Ukrainy. W rozmowie z Radiem Swoboda przyznali także, że cechują się one niesłychaną intensywnością, a szturmy wroga potrafią trwać przez 13 godzin bez przerwy.</p><br clear="all" />

## Pacjenci z dziurami w nosie. Lekarze alarmują: To przez narkotyk
 - [https://wydarzenia.interia.pl/zagranica/news-pacjenci-z-dziurami-w-nosie-lekarze-alarmuja-to-przez-narkot,nId,6558800](https://wydarzenia.interia.pl/zagranica/news-pacjenci-z-dziurami-w-nosie-lekarze-alarmuja-to-przez-narkot,nId,6558800)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 18:09:09+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pacjenci-z-dziurami-w-nosie-lekarze-alarmuja-to-przez-narkot,nId,6558800"><img align="left" alt="Pacjenci z dziurami w nosie. Lekarze alarmują: To przez narkotyk" src="https://i.iplsc.com/pacjenci-z-dziurami-w-nosie-lekarze-alarmuja-to-przez-narkot/000GO99MGDF49XY3-C321.jpg" /></a>Wśród Belgów odnotowuje się coraz więcej problemów związanych z zażywaniem narkotyków. Portal VRT Nws informował, że rośnie liczba pacjentów, którzy zgłaszają się do specjalistów z dziurami w przegrodzie nosowej, co jest efektem zażywania kokainy. Lekarze mówią o &quot;uderzającym wzroście&quot; osób z dolegliwościami wywołanymi spożywaniem białego proszku.</p><br clear="all" />

## "Zakończcie tę szaloną wojnę". Trump krytykuje dostawy czołgów
 - [https://wydarzenia.interia.pl/zagranica/news-zakonczcie-te-szalona-wojne-trump-krytykuje-dostawy-czolgow,nId,6558990](https://wydarzenia.interia.pl/zagranica/news-zakonczcie-te-szalona-wojne-trump-krytykuje-dostawy-czolgow,nId,6558990)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 17:55:41+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zakonczcie-te-szalona-wojne-trump-krytykuje-dostawy-czolgow,nId,6558990"><img align="left" alt="&quot;Zakończcie tę szaloną wojnę&quot;. Trump krytykuje dostawy czołgów" src="https://i.iplsc.com/zakonczcie-te-szalona-wojne-trump-krytykuje-dostawy-czolgow/000GO9C4L656GQCI-C321.jpg" /></a>Stany Zjednoczone zdecydowały się przekazać Ukrainie 31 Abramsów, ale decyzja Joe Bidena nie wszystkim przypadła do gustu. Oprócz Rosjan skrytykował ją też były prezydent USA Donald Trump. &quot;Najpierw idą czołgi, potem atomówki&quot; - napisał polityk.</p><br clear="all" />

## Zmiany w Kodeksie pracy. Opozycja krytykuje rząd za pół roku opóźnienia
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-pracy-opozycja-krytykuje-rzad-za-pol-roku-,nId,6558802](https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-pracy-opozycja-krytykuje-rzad-za-pol-roku-,nId,6558802)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 17:49:41+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-pracy-opozycja-krytykuje-rzad-za-pol-roku-,nId,6558802"><img align="left" alt="Zmiany w Kodeksie pracy. Opozycja krytykuje rząd za pół roku opóźnienia" src="https://i.iplsc.com/zmiany-w-kodeksie-pracy-opozycja-krytykuje-rzad-za-pol-roku/000GO98A90BINQPF-C321.jpg" /></a>Sejm zajął się nowelizacją Kodeksu pracy. To implementacja przepisów unijnych z 2019 roku. Opozycja krytykuje Prawo i Sprawiedliwość za opóźnienia w pracach, bo nowe regulacje powinny zostać przyjęte do sierpnia 2022 r. Posłanki Lewicy zwracają też uwagę na różne stawki świadczeń dla ojców i matek. - Wasz cel jest jeden. Zatrzymać kobiety w domu - mówiła do polityków rządu Katarzyna Kotula.</p><br clear="all" />

## Hołownia krytyczny wobec swojej posłanki: Brak kompetencji
 - [https://wydarzenia.interia.pl/kraj/news-holownia-krytyczny-wobec-swojej-poslanki-brak-kompetencji,nId,6558690](https://wydarzenia.interia.pl/kraj/news-holownia-krytyczny-wobec-swojej-poslanki-brak-kompetencji,nId,6558690)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 17:44:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-holownia-krytyczny-wobec-swojej-poslanki-brak-kompetencji,nId,6558690"><img align="left" alt="Hołownia krytyczny wobec swojej posłanki: Brak kompetencji" src="https://i.iplsc.com/holownia-krytyczny-wobec-swojej-poslanki-brak-kompetencji/000GO7KHU1KQ1YQU-C321.jpg" /></a>Brak kompetencji i wyjście przed szereg – to zarzuty, które w stosunku do szefowej koła Polski 2050 Hanny Gill-Piątek wysunął... Szymon Hołownia. Lider ugrupowania wypowiadał się w ten sposób o swojej koleżance podczas dyskusji z kierownictwem opozycyjnych klubów parlamentarnych. – Wystawił ją – mówią nam zgodnie politycy znający szczegóły tej rozmowy.</p><br clear="all" />

## Tczew wprowadza darmową komunikację miejską. To kolejne takie miasto
 - [https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadza-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970](https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadza-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 17:39:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadza-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970"><img align="left" alt="Tczew wprowadza darmową komunikację miejską. To kolejne takie miasto" src="https://i.iplsc.com/tczew-wprowadza-darmowa-komunikacje-miejska-to-kolejne-takie/000GO97SQ7VULE95-C321.jpg" /></a>W kilkudziesięciu małych i średnich polskich miejscowościach działa darmowa komunikacja miejska. Zniesienie opłat za bilety ma na celu obniżenie kosztów ekonomicznych, ekologicznych i społecznych. Do listy dołączyło kolejne miasto - Tczew. Darmowe przejazdy mają dotyczyć wszystkich - bez względu na grupę wiekową i miejsce zamieszkania.</p><br clear="all" />

## Tczew wprowadzi darmową komunikację miejską. To kolejne takie miasto
 - [https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadzi-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970](https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadzi-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 17:39:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-tczew-wprowadzi-darmowa-komunikacje-miejska-to-kolejne-takie,nId,6558970"><img align="left" alt="Tczew wprowadzi darmową komunikację miejską. To kolejne takie miasto" src="https://i.iplsc.com/tczew-wprowadzi-darmowa-komunikacje-miejska-to-kolejne-takie/000GO97SQ7VULE95-C321.jpg" /></a>W kilkudziesięciu małych i średnich polskich miejscowościach działa darmowa komunikacja miejska. Zniesienie opłat za bilety ma na celu obniżenie kosztów ekonomicznych, ekologicznych i społecznych. Do listy dołączy kolejne miasto - Tczew. Darmowe przejazdy mają dotyczyć wszystkich - bez względu na grupę wiekową i miejsce zamieszkania.</p><br clear="all" />

## Media: Joe Biden planuje wizytę w Polsce
 - [https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-planuje-wizyte-w-polsce,nId,6558804](https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-planuje-wizyte-w-polsce,nId,6558804)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 16:33:20+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-media-joe-biden-planuje-wizyte-w-polsce,nId,6558804"><img align="left" alt="Media: Joe Biden planuje wizytę w Polsce" src="https://i.iplsc.com/media-joe-biden-planuje-wizyte-w-polsce/000GO8WOJ40OEYND-C321.jpg" /></a>Prezydent USA Joe Biden planuje wizytę w Polsce - poinformowało CNN. Z medialnych doniesień wynika, że szef Białego Domu miałby pojawić się nad Wisłą w okolicy 24 lutego - czyli pierwszej rocznicy rosyjskiej inwazji na Ukrainę. Miałaby to być część wyjazdu do Europy, który nie jest jednak potwierdzony.</p><br clear="all" />

## Podhale: Miał rzucić się na czteromiesięczne dziecko. Ciosy w szyję
 - [https://wydarzenia.interia.pl/malopolskie/news-podhale-mial-rzucic-sie-na-czteromiesieczne-dziecko-ciosy-w-,nId,6558786](https://wydarzenia.interia.pl/malopolskie/news-podhale-mial-rzucic-sie-na-czteromiesieczne-dziecko-ciosy-w-,nId,6558786)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 16:23:50+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-podhale-mial-rzucic-sie-na-czteromiesieczne-dziecko-ciosy-w-,nId,6558786"><img align="left" alt="Podhale: Miał rzucić się na czteromiesięczne dziecko. Ciosy w szyję" src="https://i.iplsc.com/podhale-mial-rzucic-sie-na-czteromiesieczne-dziecko-ciosy-w/000GO8UW1QP99GJE-C321.jpg" /></a>Usiłowanie zabójstwa czteromiesięcznej dziewczynki oraz psychiczne i fizyczne znęcanie się nad matką dziecka - takie zarzuty usłyszał konkubent kobiety po zdarzeniu, do którego doszło w ubiegłą niedzielę w jednej z miejscowości powiatu tatrzańskiego. Prokuratura Rejonowa w Zakopanem wszczęła w tej sprawie śledztwo.</p><br clear="all" />

## Milioner Bryan Johnson wydaje fortunę, by mieć ciało nastolatka
 - [https://wydarzenia.interia.pl/zagranica/news-milioner-bryan-johnson-wydaje-fortune-by-miec-cialo-nastolat,nId,6558675](https://wydarzenia.interia.pl/zagranica/news-milioner-bryan-johnson-wydaje-fortune-by-miec-cialo-nastolat,nId,6558675)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 16:10:40+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-milioner-bryan-johnson-wydaje-fortune-by-miec-cialo-nastolat,nId,6558675"><img align="left" alt="Milioner Bryan Johnson wydaje fortunę, by mieć ciało nastolatka" src="https://i.iplsc.com/milioner-bryan-johnson-wydaje-fortune-by-miec-cialo-nastolat/000GO7G1XQ0OJKBT-C321.jpg" /></a>Mam serce 37-latka, skórę 28-latka, a także płuca i budowę ciała 18-latka - chwali się przedsiębiorca technologiczny Bryan Johnsona. 45-latek chce, by każdy z jego organów funkcjonował bez zarzutu. By &quot;zachować młodość&quot; wydaje fortunę, a zespół ponad 30 lekarzy i specjalistów na bieżąco kontroluje jego stan.</p><br clear="all" />

## Nowy największy wróg Putina. Rosyjskie media żądają "nuklearnej kary"
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-najwiekszy-wrog-putina-rosyjskie-media-zadaja-nuklearne,nId,6558771](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-najwiekszy-wrog-putina-rosyjskie-media-zadaja-nuklearne,nId,6558771)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:51:32+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-nowy-najwiekszy-wrog-putina-rosyjskie-media-zadaja-nuklearne,nId,6558771"><img align="left" alt="Nowy największy wróg Putina. Rosyjskie media żądają &quot;nuklearnej kary&quot;" src="https://i.iplsc.com/nowy-najwiekszy-wrog-putina-rosyjskie-media-zadaja-nuklearne/000GIIW7BAGGW7C3-C321.jpg" /></a>Jeszcze przed kilkoma dniami rosyjska propaganda wychwalała niemiecką politykę - było tak do środy, kiedy to kanclerz Olaf Scholz poinformował o przekazaniu Ukrainie czołgów Leopard 2. Dziennik &quot;Bild&quot; pisze, że od chwili ogłoszenia decyzji, Scholz stał się największym wrogiem prezydenta Rosji Władimira Putina. &quot;Jednocześnie Kreml był na tyle zaskoczony, że uznał to za 'bezpośredni udział' Niemiec w konflikcie. Rosyjskie media domagają się ukarania Niemiec - mówi się m.in. o atakach nuklearnych&quot; - wskazuje Bild.</p><br clear="all" />

## Wielkopolskie: Około 30 byków uciekło z gospodarstwa. Policja apeluje o ostrożność
 - [https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-okolo-30-bykow-ucieklo-z-gospodarstwa-policja-,nId,6558742](https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-okolo-30-bykow-ucieklo-z-gospodarstwa-policja-,nId,6558742)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:49:27+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-wielkopolskie-okolo-30-bykow-ucieklo-z-gospodarstwa-policja-,nId,6558742"><img align="left" alt="Wielkopolskie: Około 30 byków uciekło z gospodarstwa. Policja apeluje o ostrożność" src="https://i.iplsc.com/wielkopolskie-okolo-30-bykow-ucieklo-z-gospodarstwa-policja/000GO8IHPBF8WWSB-C321.jpg" /></a>Około 30 byków uciekło z jednego z gospodarstw rolnych w gminie Niechanowo - informuje Komenda Powiatowa Policji w Gnieźnie w województwie wielkopolskim. Zbiegłe zwierzęta mogą utrudniać przejazd drogą krajową nr 15 w okolicy Żydowa. Policja apeluje do kierowców o ostrożność.</p><br clear="all" />

## Kontrola RTV? Upewnij się, że to nie oszust. "Przestępcy wciąż zmieniają metody"
 - [https://wydarzenia.interia.pl/kraj/news-kontrola-rtv-upewnij-sie-ze-to-nie-oszust-przestepcy-wciaz-z,nId,6558647](https://wydarzenia.interia.pl/kraj/news-kontrola-rtv-upewnij-sie-ze-to-nie-oszust-przestepcy-wciaz-z,nId,6558647)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:34:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-kontrola-rtv-upewnij-sie-ze-to-nie-oszust-przestepcy-wciaz-z,nId,6558647"><img align="left" alt="Kontrola RTV? Upewnij się, że to nie oszust. &quot;Przestępcy wciąż zmieniają metody&quot;" src="https://i.iplsc.com/kontrola-rtv-upewnij-sie-ze-to-nie-oszust-przestepcy-wciaz-z/000GO7OOA4QFV4YI-C321.jpg" /></a>Nie płacisz abonamentu RTV? Możesz spodziewać się kontroli. Zanim jednak wpuścisz do mieszkania pracownika Poczty Polskiej, sprawdź, czy na pewno jest osobą, za którą się podaje. Policjanci apelują o czujność. - Przestępcy próbujący wyłudzić pieniądze wciąż zmieniają swoje metody - przekazał Interii kom. Piotr Świstak z Komendy Głównej Policji. </p><br clear="all" />

## Zgwałconej 14-latce odmówiono aborcji. Kosiniak-Kamysz: Zastosowałbym klauzulę sumienia
 - [https://wydarzenia.interia.pl/kraj/news-zgwalconej-14-latce-odmowiono-aborcji-kosiniak-kamysz-zastos,nId,6558760](https://wydarzenia.interia.pl/kraj/news-zgwalconej-14-latce-odmowiono-aborcji-kosiniak-kamysz-zastos,nId,6558760)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:25:32+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zgwalconej-14-latce-odmowiono-aborcji-kosiniak-kamysz-zastos,nId,6558760"><img align="left" alt="Zgwałconej 14-latce odmówiono aborcji. Kosiniak-Kamysz: Zastosowałbym klauzulę sumienia" src="https://i.iplsc.com/zgwalconej-14-latce-odmowiono-aborcji-kosiniak-kamysz-zastos/000GO8IP5NWK3TSL-C321.jpg" /></a>Nie milkną echa sprawy zgwałconej 14-latki z umysłową niepełnosprawnością, której podlaskie szpitale odmówiły aborcji, powołując się na klauzulę sumienia. - Ciąża z gwałtu to przesłanka, która umożliwia jej przerwanie. Prawo musi być egzekwowane - oznajmił prezes PSL Władysław Kosiniak-Kamysz. Lider ludowców powiedział jednak, że on także zasłoniłby się klauzulą sumienia. Jak wyjaśnił, odpowiedzialność spoczywa na dyrektorze placówki, a nie na poszczególnych lekarzach. </p><br clear="all" />

## Gwałciciel odsiaduje wyrok w więzieniu dla kobiet. "Zostanie przeniesiony"
 - [https://wydarzenia.interia.pl/zagranica/news-gwalciciel-odsiaduje-wyrok-w-wiezieniu-dla-kobiet-zostanie-p,nId,6558731](https://wydarzenia.interia.pl/zagranica/news-gwalciciel-odsiaduje-wyrok-w-wiezieniu-dla-kobiet-zostanie-p,nId,6558731)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:23:55+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-gwalciciel-odsiaduje-wyrok-w-wiezieniu-dla-kobiet-zostanie-p,nId,6558731"><img align="left" alt="Gwałciciel odsiaduje wyrok w więzieniu dla kobiet. &quot;Zostanie przeniesiony&quot;" src="https://i.iplsc.com/gwalciciel-odsiaduje-wyrok-w-wiezieniu-dla-kobiet-zostanie-p/000GO8BEPOAFA3O6-C321.jpg" /></a>Adam Graham zgwałcił dwie kobiety, a po tym, gdy został aresztowany, rozpoczął proces korekty płci. Teraz ma 31 lat i nazywa się Isla Bryson. Wyrok chce odsiadywać w oddziale dla kobiet. W tej kontrowersyjnej sprawie głos zabrała szkocka premier. - Nie sądzę, aby gwałciciel mógł przebywać w więzieniu dla kobiet - powiedziała.</p><br clear="all" />

## Wysoko postawiony Rosjanin spłonął w "elitarnej dzielnicy"
 - [https://wydarzenia.interia.pl/zagranica/news-wysoko-postawiony-rosjanin-splonal-w-elitarnej-dzielnicy,nId,6558732](https://wydarzenia.interia.pl/zagranica/news-wysoko-postawiony-rosjanin-splonal-w-elitarnej-dzielnicy,nId,6558732)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 15:04:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wysoko-postawiony-rosjanin-splonal-w-elitarnej-dzielnicy,nId,6558732"><img align="left" alt="Wysoko postawiony Rosjanin spłonął w &quot;elitarnej dzielnicy&quot;" src="https://i.iplsc.com/wysoko-postawiony-rosjanin-splonal-w-elitarnej-dzielnicy/000GO872Q4B86AVN-C321.jpg" /></a>Nie żyje Dmitrij Pawoczka, 49-letni Rosjanin, który kierował wydziałem międzynarodowej współpracy edukacyjno-naukowej w jednej z jednostek naukowych należących do Rosyjskiego Uniwersytetu Przyjaźni Narodów w Moskwie. Wcześniej zajmował intratne stanowiska w państwowych koncernach Roskosmos, Suchoj i Łukoil. Media podają, że mężczyzna miał zasnąć z tlącym się papierosem w ręce, co doprowadziło do pożaru w jego luksusowym apartamencie. Nikt inny nie został ranny.</p><br clear="all" />

## KO zawiadamia prokuraturę ws. I prezes SN. "Weszła w polityczne buty"
 - [https://wydarzenia.interia.pl/kraj/news-ko-zawiadamia-prokurature-ws-i-prezes-sn-weszla-w-polityczne,nId,6558652](https://wydarzenia.interia.pl/kraj/news-ko-zawiadamia-prokurature-ws-i-prezes-sn-weszla-w-polityczne,nId,6558652)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 14:24:14+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-ko-zawiadamia-prokurature-ws-i-prezes-sn-weszla-w-polityczne,nId,6558652"><img align="left" alt="KO zawiadamia prokuraturę ws. I prezes SN. &quot;Weszła w polityczne buty&quot;" src="https://i.iplsc.com/ko-zawiadamia-prokurature-ws-i-prezes-sn-weszla-w-polityczne/000GO7EGGDF21114-C321.jpg" /></a>Koalicja Obywatelska zawiadamia prokuraturę w sprawie I prezes Sądu Najwyższego, która nie chce przyjąć ślubowania wybranych przez Senat 26 ławników. Zdaniem posła KO Arkadiusza Myrchy Manowska &quot;w sposób ewidentny łamie prawo&quot; oraz &quot;weszła w czysto polityczne buty&quot;. - Nie jestem notariuszem Senatu - odpowiada I prezes SN. </p><br clear="all" />

## Jan Śpiewak kontra Jacek Majchrowski. Jest decyzja sądu
 - [https://wydarzenia.interia.pl/malopolskie/news-jan-spiewak-kontra-jacek-majchrowski-jest-decyzja-sadu,nId,6558688](https://wydarzenia.interia.pl/malopolskie/news-jan-spiewak-kontra-jacek-majchrowski-jest-decyzja-sadu,nId,6558688)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 14:13:51+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-jan-spiewak-kontra-jacek-majchrowski-jest-decyzja-sadu,nId,6558688"><img align="left" alt="Jan Śpiewak kontra Jacek Majchrowski. Jest decyzja sądu" src="https://i.iplsc.com/jan-spiewak-kontra-jacek-majchrowski-jest-decyzja-sadu/000GO7MBAJX5TO00-C321.jpg" /></a>Sąd Okręgowy w Krakowie umorzył postępowanie przeciwko Janowi Śpiewakowi z powództwa Jacka Majchrowskiego. Tym samym podtrzymał decyzję sądu pierwszej instancji. Prezydent Krakowa oskarża aktywistę o znieważenie i pomówienie po tym, jak opublikował na swoim kanale film, który zatytułował &quot;Pożar miejskiego archiwum i najsłynniejsze afery z czasów Majchrowskiego&quot;.</p><br clear="all" />

## Szef MSWiA: Brat gen. Szymczyka poniesie surowe konsekwencje
 - [https://wydarzenia.interia.pl/kraj/news-szef-mswia-brat-gen-szymczyka-poniesie-surowe-konsekwencje,nId,6558668](https://wydarzenia.interia.pl/kraj/news-szef-mswia-brat-gen-szymczyka-poniesie-surowe-konsekwencje,nId,6558668)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 13:54:58+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-szef-mswia-brat-gen-szymczyka-poniesie-surowe-konsekwencje,nId,6558668"><img align="left" alt="Szef MSWiA: Brat gen. Szymczyka poniesie surowe konsekwencje" src="https://i.iplsc.com/szef-mswia-brat-gen-szymczyka-poniesie-surowe-konsekwencje/000GO7FPS5B72OCL-C321.jpg" /></a>Spięcie podczas czwartkowego posiedzenia Sejmu. Sławomir Nitras (PO) pytał szefa MSWiA o wizerunek Polskiej Policji i zarzucał służbom &quot;bezkarność komendanta głównego i jego brata&quot;. Mariusz Kamiński stanął w obronie szefa policji oraz odpowiedział na zarzuty dotyczące jego brata. - Poniesie surowe konsekwencje, bo materiał jest bardzo poważny - wskazał.</p><br clear="all" />

## Zełenski o rozmowach pokojowych z Rosją: Są bezcelowe, dopóki na czele stoi Putin
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-rozmowach-pokojowych-z-rosja-sa-bezcelowe-dopoki-,nId,6558621](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-rozmowach-pokojowych-z-rosja-sa-bezcelowe-dopoki-,nId,6558621)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 13:46:46+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-zelenski-o-rozmowach-pokojowych-z-rosja-sa-bezcelowe-dopoki-,nId,6558621"><img align="left" alt="Zełenski o rozmowach pokojowych z Rosją: Są bezcelowe, dopóki na czele stoi Putin" src="https://i.iplsc.com/zelenski-o-rozmowach-pokojowych-z-rosja-sa-bezcelowe-dopoki/000GD6Y85A03G1U6-C321.jpg" /></a>Rozmowy pokojowe z Rosją, dopóki na jej czele stoi Władimir Putin, są bezcelowe i nie ma nawet pewności, czy to on podejmuje w Rosji decyzje - ocenił prezydent Ukrainy Wołodymyr Zełenski w rozmowie ze stacją Sky News. Dodał, że po inwazji na pełną skalę Putin jest dla niego nikim. Mówił też o tym, że Ukraina będzie potrzebować 300-500 zachodnich czołgów.</p><br clear="all" />

## Zabójstwo krakowskiej prokurator. Sąd złagodził wyrok dla Przemysława J.
 - [https://wydarzenia.interia.pl/malopolskie/news-zabojstwo-krakowskiej-prokurator-sad-zlagodzil-wyrok-dla-prz,nId,6558624](https://wydarzenia.interia.pl/malopolskie/news-zabojstwo-krakowskiej-prokurator-sad-zlagodzil-wyrok-dla-prz,nId,6558624)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 13:40:27+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-zabojstwo-krakowskiej-prokurator-sad-zlagodzil-wyrok-dla-prz,nId,6558624"><img align="left" alt="Zabójstwo krakowskiej prokurator. Sąd złagodził wyrok dla Przemysława J." src="https://i.iplsc.com/zabojstwo-krakowskiej-prokurator-sad-zlagodzil-wyrok-dla-prz/000GO7FWGO4I8NM6-C321.jpg" /></a>Sąd Apelacyjny obniżył do 25 lat więzienia karę dla Przemysława J., którego oskarżono o zabójstwo ze szczególnym okrucieństwem swojej matki Anny J., wiceszefowej krakowskiej prokuratury. W 2019 roku Sąd Okręgowy skazał mężczyznę na dożywocie, ponieważ - choć w trakcie popełnienia zbrodni był niepoczytalny z uwagi na połączenie psychotropów z alkoholem - to wiedział, że nie wolno było mu tego robić i mógł temu zapobiec.</p><br clear="all" />

## PiS i KO na czele najnowszego sondażu. Obie partie zanotowały po 31 proc.
 - [https://wydarzenia.interia.pl/kraj/news-pis-i-ko-na-czele-najnowszego-sondazu-obie-partie-zanotowaly,nId,6558604](https://wydarzenia.interia.pl/kraj/news-pis-i-ko-na-czele-najnowszego-sondazu-obie-partie-zanotowaly,nId,6558604)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 13:20:15+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-pis-i-ko-na-czele-najnowszego-sondazu-obie-partie-zanotowaly,nId,6558604"><img align="left" alt="PiS i KO na czele najnowszego sondażu. Obie partie zanotowały po 31 proc." src="https://i.iplsc.com/pis-i-ko-na-czele-najnowszego-sondazu-obie-partie-zanotowaly/000GBAI7EQH8NNAI-C321.jpg" /></a>Prawo i Sprawiedliwość remisuje z Koalicją Obywatelską - wynika z najnowszego sondażu Kantar Public. Na trzecim miejscu najnowszego zestawienia znalazły się ex æquo Lewica oraz Polska 2050. W Sejmie znalazłaby się również Konfederacja, na co nie mogłoby liczyć z kolei Polskie Stronnictwo Ludowe.</p><br clear="all" />

## Pieniądze z rządu dla fundacji o. Rydzyka. Wiadomo, na jaki cel
 - [https://wydarzenia.interia.pl/kraj/news-pieniadze-z-rzadu-dla-fundacji-o-rydzyka-wiadomo-na-jaki-cel,nId,6558594](https://wydarzenia.interia.pl/kraj/news-pieniadze-z-rzadu-dla-fundacji-o-rydzyka-wiadomo-na-jaki-cel,nId,6558594)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 13:13:06+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-pieniadze-z-rzadu-dla-fundacji-o-rydzyka-wiadomo-na-jaki-cel,nId,6558594"><img align="left" alt="Pieniądze z rządu dla fundacji o. Rydzyka. Wiadomo, na jaki cel" src="https://i.iplsc.com/pieniadze-z-rzadu-dla-fundacji-o-rydzyka-wiadomo-na-jaki-cel/000GO72ZVGNXS5C9-C321.jpg" /></a>Na emisję spotów w Telewizji Trwam, programy telewizyjne pokazywane w tej samej stacji, jak i dyplomatyczno-samorządowe projekty popłynęły pieniądze z rządu do fundacji Lux Veritatis, której prezesem jest ojciec Tadeusz Rydzyk. Poinformowali o tym przedstawiciele poszczególnych ministerstw, odpowiadając na interpelacje posłanki Polski 2050 Hanny Gill-Piątek. Niektóre przelewy i dotacje opiewały na więcej niż 200 tysięcy złotych.</p><br clear="all" />

## Indie zakazały pokazywania filmu o premierze Modim. W tle masakra sprzed lat
 - [https://wydarzenia.interia.pl/zagranica/news-indie-zakazaly-pokazywania-filmu-o-premierze-modim-w-tle-mas,nId,6558381](https://wydarzenia.interia.pl/zagranica/news-indie-zakazaly-pokazywania-filmu-o-premierze-modim-w-tle-mas,nId,6558381)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 12:20:22+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-indie-zakazaly-pokazywania-filmu-o-premierze-modim-w-tle-mas,nId,6558381"><img align="left" alt="Indie zakazały pokazywania filmu o premierze Modim. W tle masakra sprzed lat" src="https://i.iplsc.com/indie-zakazaly-pokazywania-filmu-o-premierze-modim-w-tle-mas/000GO6DETDCN869R-C321.jpg" /></a>Rząd Indii zablokował dystrybucję dokumentu BBC pokazującego postawę premiera Narendry Modiego w czasie krwawych zamieszek etnicznych w 2002 roku. Film usunięto także z sieci, a studentom organizującym jego pokazy władze grożą konsekwencjami.</p><br clear="all" />

## Śmiertelny wypadek w Małopolsce. Pasażer wypadł z auta
 - [https://wydarzenia.interia.pl/malopolskie/news-smiertelny-wypadek-w-malopolsce-pasazer-wypadl-z-auta,nId,6558561](https://wydarzenia.interia.pl/malopolskie/news-smiertelny-wypadek-w-malopolsce-pasazer-wypadl-z-auta,nId,6558561)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 12:19:58+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-smiertelny-wypadek-w-malopolsce-pasazer-wypadl-z-auta,nId,6558561"><img align="left" alt="Śmiertelny wypadek w Małopolsce. Pasażer wypadł z auta" src="https://i.iplsc.com/smiertelny-wypadek-w-malopolsce-pasazer-wypadl-z-auta/000GO71DOF5HYGB9-C321.jpg" /></a>Śmiertelny wypadek samochodowy w Małopolsce. Choć 22-letni kierowca nie odniósł poważnych obrażeń, towarzyszący mu 25-latek w ciężkim stanie trafił do szpitala, gdzie zmarł. &quot;Pasażer wypadł z samochodu&quot; - wskazuje ochotnicza straż pożarna w Ropie. </p><br clear="all" />

## Matura 2023 w nowej formule. Co się zmieni?
 - [https://wydarzenia.interia.pl/kraj/news-matura-2023-w-nowej-formule-co-sie-zmieni,nId,6558556](https://wydarzenia.interia.pl/kraj/news-matura-2023-w-nowej-formule-co-sie-zmieni,nId,6558556)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 12:16:23+00:00
 - user: None

<p>- Tegoroczny egzamin maturalny nie odbywa się w oparciu o podstawy programowe, ale o odbywa się w oparciu o wymagania egzaminacyjne w związku z tym, że miała miejsce nauka zdalna i pandemia koronawirusa. Ze wszystkich przedmiotów tegoroczne wymagania egzaminacyjne są obniżone o ok. 20-25 proc. - powiedział minister edukacji i nauki na czwartkowej konferencji prasowej. Matura w 2023 r. będzie miała nową formułę.</p><br clear="all" />

## Posiedzenie komisji cyfryzacji odroczone. PiS złożyło poprawki
 - [https://wydarzenia.interia.pl/kraj/news-posiedzenie-komisji-cyfryzacji-odroczone-pis-zlozylo-poprawk,nId,6558506](https://wydarzenia.interia.pl/kraj/news-posiedzenie-komisji-cyfryzacji-odroczone-pis-zlozylo-poprawk,nId,6558506)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 11:29:47+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-posiedzenie-komisji-cyfryzacji-odroczone-pis-zlozylo-poprawk,nId,6558506"><img align="left" alt="Posiedzenie komisji cyfryzacji odroczone. PiS złożyło poprawki" src="https://i.iplsc.com/posiedzenie-komisji-cyfryzacji-odroczone-pis-zlozylo-poprawk/000DAECWGRKJ1JMI-C321.jpg" /></a>Posiedzenie sejmowej komisji cyfryzacji zostało odroczone do 6 lutego. Ma to związek z poprawkami zgłoszonymi przez posłów PiS. Na posiedzeniu miały być rozpatrywane rządowe projekty ustaw prawo komunikacji elektronicznej i przepisów ją wprowadzających. Interia informowała w środę, że PiS złoży poprawkę wykreślającą przepisy dotyczące dodatkowych kompetencji dla służb państwowych.

</p><br clear="all" />

## Niemcy: Aresztowano kolejną osobę, podejrzaną o szpiegostwo na rzecz Rosji
 - [https://wydarzenia.interia.pl/zagranica/news-niemcy-aresztowano-kolejna-osobe-podejrzana-o-szpiegostwo-na,nId,6558503](https://wydarzenia.interia.pl/zagranica/news-niemcy-aresztowano-kolejna-osobe-podejrzana-o-szpiegostwo-na,nId,6558503)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 11:27:32+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemcy-aresztowano-kolejna-osobe-podejrzana-o-szpiegostwo-na,nId,6558503"><img align="left" alt="Niemcy: Aresztowano kolejną osobę, podejrzaną o szpiegostwo na rzecz Rosji" src="https://i.iplsc.com/niemcy-aresztowano-kolejna-osobe-podejrzana-o-szpiegostwo-na/000GJ19KHUUOXMCR-C321.jpg" /></a>W Niemczech aresztowano kolejną osobę podejrzaną o szpiegowanie na rzecz Rosji - informuje agencja dpa. Pod koniec ubiegłego roku zatrzymano w tej sprawie pracownika Federalnej Służby Wywiadu (Bundesnachrichtendienst - BND).</p><br clear="all" />

## Trwają prace nad ustawą wiatrakową. Minister ds. UE: Istotny kamień milowy
 - [https://wydarzenia.interia.pl/kraj/news-trwaja-prace-nad-ustawa-wiatrakowa-minister-ds-ue-istotny-ka,nId,6558493](https://wydarzenia.interia.pl/kraj/news-trwaja-prace-nad-ustawa-wiatrakowa-minister-ds-ue-istotny-ka,nId,6558493)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 11:17:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-trwaja-prace-nad-ustawa-wiatrakowa-minister-ds-ue-istotny-ka,nId,6558493"><img align="left" alt="Trwają prace nad ustawą wiatrakową. Minister ds. UE: Istotny kamień milowy" src="https://i.iplsc.com/trwaja-prace-nad-ustawa-wiatrakowa-minister-ds-ue-istotny-ka/000GO6OGG31WIUP0-C321.jpg" /></a>Sejmowe komisje energii, klimatu i aktywów państwowych, oraz samorządu i polityki regionalnej wznowiły prace nad rządowym projektem nowelizacji ustawy o inwestycjach w zakresie elektrowni wiatrowych. - Ustawa wiatrakowa to istotny kamień milowy do wypełnienia. Bez jej przyjęcia trudno sobie wyobrazić możliwość pozytywnego rozpatrzenia przez Komisję Europejską wniosku o płatność na KPO - ocenił minister ds. UE Szymon Szynkowski vel Sęk. Po południu komisje zdecydowały o zwiększeniu z 500 do 700 metrów odległość wiatraków, ale wyłącznie od...</p><br clear="all" />

## Warszawa: Opóźnienia na kolei po usterce. Sięgały kilkudziesięciu minut
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-opoznienia-na-kolei-po-usterce-siegaly-kilkudziesie,nId,6558486](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-opoznienia-na-kolei-po-usterce-siegaly-kilkudziesie,nId,6558486)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 11:11:47+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-opoznienia-na-kolei-po-usterce-siegaly-kilkudziesie,nId,6558486"><img align="left" alt="Warszawa: Opóźnienia na kolei po usterce. Sięgały kilkudziesięciu minut" src="https://i.iplsc.com/warszawa-opoznienia-na-kolei-po-usterce-siegaly-kilkudziesie/000GO6LRSA1BHGUY-C321.jpg" /></a>Pasażerów kolei w Warszawie zaskoczyły poważne utrudnienia w ruchu. Na linii średnicowej między Dworcami Zachodnim a Wschodnim pękła szyna, dlatego pociągi m.in. Kolei Mazowieckich oraz Szybkiej Kolei Miejskiej notują opóźnienia. Sięgają one niekiedy po 40-60 minut, ponadto część połączeń regionalnych odwołano. Jak ustaliła Interia, usterkę naprawiono.</p><br clear="all" />

## Warszawa: Paraliż na kolei. Opóźnienia sięgają kilkudziesięciu minut
 - [https://wydarzenia.interia.pl/mazowieckie/news-warszawa-paraliz-na-kolei-opoznienia-siegaja-kilkudziesieciu,nId,6558486](https://wydarzenia.interia.pl/mazowieckie/news-warszawa-paraliz-na-kolei-opoznienia-siegaja-kilkudziesieciu,nId,6558486)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 11:11:47+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-warszawa-paraliz-na-kolei-opoznienia-siegaja-kilkudziesieciu,nId,6558486"><img align="left" alt="Warszawa: Paraliż na kolei. Opóźnienia sięgają kilkudziesięciu minut" src="https://i.iplsc.com/warszawa-paraliz-na-kolei-opoznienia-siegaja-kilkudziesieciu/000GO6LRSA1BHGUY-C321.jpg" /></a>Poważne utrudnienia w ruchu kolejowym w Warszawie. Na linii średnicowej między Dworcami Zachodnim a Wschodnim pękła szyna, dlatego pociągi m.in. Kolei Mazowieckich oraz Szybkiej Kolei Miejskiej notują opóźnienia. Na razie sięgają one kilkudziesięciu minut, ale mogą się zwiększyć. Pasażerowie najpewniej poczekają też dłużej na składy dalekobieżne PKP Intercity. Ponadto część połączeń regionalnych jest odwoływana.</p><br clear="all" />

## USA: Uciekali pieszo przed trąbą powietrzną. Dramatyczne nagranie
 - [https://wydarzenia.interia.pl/zagranica/news-usa-uciekali-pieszo-przed-traba-powietrzna-dramatyczne-nagra,nId,6558460](https://wydarzenia.interia.pl/zagranica/news-usa-uciekali-pieszo-przed-traba-powietrzna-dramatyczne-nagra,nId,6558460)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 10:43:34+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-uciekali-pieszo-przed-traba-powietrzna-dramatyczne-nagra,nId,6558460"><img align="left" alt="USA: Uciekali pieszo przed trąbą powietrzną. Dramatyczne nagranie" src="https://i.iplsc.com/usa-uciekali-pieszo-przed-traba-powietrzna-dramatyczne-nagra/000GO6FAIP0UC7W2-C321.jpg" /></a>Chwilę grozy przeżyli Amerykanin Zachary Peck-Chapman i jego partnerka. Tornado, które przeszło przez Teksas, minęło ich kampera zaledwie o kilkadziesiąt metrów. - Był to najstraszniejszy moment mojego życia - przyznał 34-latek, który nagranie z ucieczki opublikował w mediach społecznościowych.</p><br clear="all" />

## 98-latka wspiera WOŚP. Ofiarowała osobistą pamiątkę
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-98-latka-wspiera-wosp-ofiarowala-osobista-pamiatke,nId,6558448](https://wydarzenia.interia.pl/dolnoslaskie/news-98-latka-wspiera-wosp-ofiarowala-osobista-pamiatke,nId,6558448)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 10:36:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-98-latka-wspiera-wosp-ofiarowala-osobista-pamiatke,nId,6558448"><img align="left" alt="98-latka wspiera WOŚP. Ofiarowała osobistą pamiątkę" src="https://i.iplsc.com/98-latka-wspiera-wosp-ofiarowala-osobista-pamiatke/000GO6D4WJX60IMK-C321.jpg" /></a>98-letnia mieszkanka Milikowic (woj. dolnośląskie) po raz kolejny wsparła Wielką Orkiestrę Świątecznej Pomocy. Przekazała na aukcję własnoręcznie spisany przepis na ciasto biszkoptowe. </p><br clear="all" />

## Płód dziecka w przepompowni ścieków. Sprawą zajmuje się prokuratura
 - [https://wydarzenia.interia.pl/wielkopolskie/news-plod-dziecka-w-przepompowni-sciekow-sprawa-zajmuje-sie-proku,nId,6558435](https://wydarzenia.interia.pl/wielkopolskie/news-plod-dziecka-w-przepompowni-sciekow-sprawa-zajmuje-sie-proku,nId,6558435)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 10:19:04+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-plod-dziecka-w-przepompowni-sciekow-sprawa-zajmuje-sie-proku,nId,6558435"><img align="left" alt="Płód dziecka w przepompowni ścieków. Sprawą zajmuje się prokuratura" src="https://i.iplsc.com/plod-dziecka-w-przepompowni-sciekow-sprawa-zajmuje-sie-proku/000GO6EUUWY71KSB-C321.jpg" /></a>Płód dziecka znaleźli w miejscowości Okonek w woj. wielkopolskim pracownicy przepompowni ścieków. Doniesienia potwierdziła już policja. Na miejscu trwają czynności z udziałem prokuratora.
</p><br clear="all" />

## Włochy: Zasnęła podczas karmienia piersią. Dziecko zmarło
 - [https://wydarzenia.interia.pl/zagranica/news-wlochy-zasnela-podczas-karmienia-piersia-dziecko-zmarlo,nId,6558405](https://wydarzenia.interia.pl/zagranica/news-wlochy-zasnela-podczas-karmienia-piersia-dziecko-zmarlo,nId,6558405)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 09:51:50+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wlochy-zasnela-podczas-karmienia-piersia-dziecko-zmarlo,nId,6558405"><img align="left" alt="Włochy: Zasnęła podczas karmienia piersią. Dziecko zmarło" src="https://i.iplsc.com/wlochy-zasnela-podczas-karmienia-piersia-dziecko-zmarlo/000GO658O5QBAK0B-C321.jpg" /></a>Prokuratura bada sprawę śmierci noworodka w szpitalu Petrini w Rzymie. Matka zasnęła podczas karmienia dziecka piersią. Według wstępnych ustaleń mogła przygnieść syna. - Mimo tego, że była wyczerpana, od razu przynieśli jej dziecko do karmienia - oskarża partner kobiety. </p><br clear="all" />

## Karnet na stok za ponad 500 zł, Kasprowy Wierch za ponad 400. Czyli koszt ferii z rodziną
 - [https://wydarzenia.interia.pl/news-karnet-na-stok-za-ponad-500-zl-kasprowy-wierch-za-ponad-400-,nId,6556536](https://wydarzenia.interia.pl/news-karnet-na-stok-za-ponad-500-zl-kasprowy-wierch-za-ponad-400-,nId,6556536)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 09:45:33+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/news-karnet-na-stok-za-ponad-500-zl-kasprowy-wierch-za-ponad-400-,nId,6556536"><img align="left" alt="Karnet na stok za ponad 500 zł, Kasprowy Wierch za ponad 400. Czyli koszt ferii z rodziną" src="https://i.iplsc.com/karnet-na-stok-za-ponad-500-zl-kasprowy-wierch-za-ponad-400/000GO648VOSXBQST-C321.jpg" /></a>Ferie zimowe 2023 trwają w najlepsze. Po ciepłym początku stycznia w górach i nie tylko pojawiły się spore ilości śniegu,  dlatego do najpopularniejszych kurortów narciarskich znów zaczęli ściągać turyści. Sprawdziliśmy, z jakimi kosztami wiąże się taki wyjazd w 2023 roku.</p><br clear="all" />

## Czołgi Leopard 2 w Europie. Które kraje je posiadają?
 - [https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja,nId,6558358](https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja,nId,6558358)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 09:44:10+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja,nId,6558358"><img align="left" alt="Czołgi Leopard 2 w Europie. Które kraje je posiadają?" src="https://i.iplsc.com/czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja/000GO645IJ56HTP4-C321.jpg" /></a>Grecy mają najwięcej czołgów Leopard 2 w Europie - wynika z danych zgromadzonych przez AFP. Na podium znalazły się też Hiszpania oraz Niemcy, które są ich producentem. Wysoko na liście znajduje się też Polska, która zaproponowała koalicję państw wspomagających Ukrainę przez dostarczenie jej Leopardów. Są też kraje UE, które nie posiadają ani jednego takiego czołgu.</p><br clear="all" />

## Małżeństwo upozorowało swoją śmierć. Chcieli wyłudzić pieniądze
 - [https://wydarzenia.interia.pl/podlaskie/news-malzenstwo-upozorowalo-swoja-smierc-chcieli-wyludzic-pieniad,nId,6558348](https://wydarzenia.interia.pl/podlaskie/news-malzenstwo-upozorowalo-swoja-smierc-chcieli-wyludzic-pieniad,nId,6558348)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 09:20:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-malzenstwo-upozorowalo-swoja-smierc-chcieli-wyludzic-pieniad,nId,6558348"><img align="left" alt="Małżeństwo upozorowało swoją śmierć. Chcieli wyłudzić pieniądze" src="https://i.iplsc.com/malzenstwo-upozorowalo-swoja-smierc-chcieli-wyludzic-pieniad/000FQFEVX9FGXE5J-C321.jpg" /></a>Prokuratura Okręgowa w Suwałkach skierowała do sądu akt oskarżenia przeciwko sześciu osobom oskarżonym o udział w zorganizowanej grupie przestępczej, zajmującej się oszustwami. Dwie osoby, będące małżeństwem, upozorowały swoją śmierć, by uniknąć kary i wyłudzić ubezpieczenie.</p><br clear="all" />

## Rosjanie w szoku po decyzji Niemiec. Piszą o komorach gazowych
 - [https://wydarzenia.interia.pl/zagranica/news-rosjanie-w-szoku-po-decyzji-niemiec-pisza-o-komorach-gazowyc,nId,6558369](https://wydarzenia.interia.pl/zagranica/news-rosjanie-w-szoku-po-decyzji-niemiec-pisza-o-komorach-gazowyc,nId,6558369)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 08:55:46+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosjanie-w-szoku-po-decyzji-niemiec-pisza-o-komorach-gazowyc,nId,6558369"><img align="left" alt="Rosjanie w szoku po decyzji Niemiec. Piszą o komorach gazowych" src="https://i.iplsc.com/rosjanie-w-szoku-po-decyzji-niemiec-pisza-o-komorach-gazowyc/000GO5U9U0GB60GC-C321.jpg" /></a>Rosyjscy propagandyści nie mogą otrząsnąć się po oficjalnej deklaracji Niemiec w sprawie przekazania Ukrainie 14 czołgów Leopard 2. Oświadczenie niemieckiego rządu spotkało się z ostrą krytyką m.in. &quot;carycy&quot; propagandy Margarity Simonian, która stwierdziła, że w na lato planowane są dostawy &quot;komór gazowych&quot;. Powstają też teorie spiskowe wiążące liczbę czołgów z amerykańskimi neonazistami.</p><br clear="all" />

## Premier o decyzji Niemiec. "Czołgi nie są po to, by jeździć na defiladzie"
 - [https://wydarzenia.interia.pl/kraj/news-premier-o-decyzji-niemiec-czolgi-nie-sa-po-to-by-jezdzic-na-,nId,6558367](https://wydarzenia.interia.pl/kraj/news-premier-o-decyzji-niemiec-czolgi-nie-sa-po-to-by-jezdzic-na-,nId,6558367)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 08:53:54+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-o-decyzji-niemiec-czolgi-nie-sa-po-to-by-jezdzic-na-,nId,6558367"><img align="left" alt="Premier o decyzji Niemiec. &quot;Czołgi nie są po to, by jeździć na defiladzie&quot;" src="https://i.iplsc.com/premier-o-decyzji-niemiec-czolgi-nie-sa-po-to-by-jezdzic-na/000GO5UKNINOF7PY-C321.jpg" /></a>- Bardzo dobrze się stało, że rząd Niemiec zdecydował się wesprzeć Ukrainę. Czołgi nie są po to, by jeździć na defiladzie, lecz wspierać walczących w obronie wolności i suwerenności - stwierdził w czwartek premier Mateusz Morawiecki. Towarzyszący mu komisarz UE ds. zarządzania kryzysowego Janez Lenarčič wyliczył, że w związku z atakiem Rosji do Ukrainy dotarło około 80 tysięcy ton pomocy ze strony Unii Europejskiej i jej państw członkowskich.</p><br clear="all" />

## Rytuały, molestowanie i księża-sadyści. Tak wyglądały egzorcyzmy Ireny
 - [https://wydarzenia.interia.pl/kraj/news-rytualy-molestowanie-i-ksieza-sadysci-tak-wygladaly-egzorcyz,nId,6556898](https://wydarzenia.interia.pl/kraj/news-rytualy-molestowanie-i-ksieza-sadysci-tak-wygladaly-egzorcyz,nId,6556898)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 08:26:11+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-rytualy-molestowanie-i-ksieza-sadysci-tak-wygladaly-egzorcyz,nId,6556898"><img align="left" alt="Rytuały, molestowanie i księża-sadyści. Tak wyglądały egzorcyzmy Ireny" src="https://i.iplsc.com/rytualy-molestowanie-i-ksieza-sadysci-tak-wygladaly-egzorcyz/000GO3T4SW4V4XE6-C321.jpg" /></a>- Przemoc względem Ireny eskalowała stopniowo. Miała objawy stanów dysocjacyjnych, kiedy poddawano ją dużemu stresowi. Mogła nie pamiętać tego, co się działo. W takich okolicznościach te rytuały przybierały coraz bardziej seksualny charakter, molestowania i znęcania się. Niektórzy z księży dotykali jej miejsc intymnych, całowali, nacierali jakimiś rzekomo świętymi olejami krocze czy piersi, kładli się na niej tak, że czuła ich erekcję. Inni księża byli sadystami, którzy chcieli sprawić jej jak największy ból - mówi w rozmowie z Interią Paweł...</p><br clear="all" />

## Zmiany w Kodeksie wyborczym. Drugie czytanie projektu w Sejmie
 - [https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-drugie-czytanie-projektu-w-sejmi,nId,6558288](https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-drugie-czytanie-projektu-w-sejmi,nId,6558288)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 08:00:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zmiany-w-kodeksie-wyborczym-drugie-czytanie-projektu-w-sejmi,nId,6558288"><img align="left" alt="Zmiany w Kodeksie wyborczym. Drugie czytanie projektu w Sejmie" src="https://i.iplsc.com/zmiany-w-kodeksie-wyborczym-drugie-czytanie-projektu-w-sejmi/000CMZ8RAIMOKTEI-C321.jpg" /></a>W Sejmie trwa drugie czytanie projektu zmian w Kodeksie wyborczym zaproponowanych przez PiS. Według autorów nowelizacja ma zapewnić zwiększenie frekwencji wyborczej, z kolei zdaniem opozycji intencją partii rządzącej jest poprawienie własnego wyniku, a zmiany wprowadzane są zbyt krótko przed wyborami. Projekt upadłby na etapie pierwszego czytania, jednak część posłów opozycji wstrzymała się od głosu, co sprawiło, że trafił on do sejmowej komisji.</p><br clear="all" />

## USA: Półnaga kobieta wbiegła do kościoła. Zniszczyła figurę Jezusa
 - [https://wydarzenia.interia.pl/zagranica/news-usa-polnaga-kobieta-wbiegla-do-kosciola-zniszczyla-figure-je,nId,6558326](https://wydarzenia.interia.pl/zagranica/news-usa-polnaga-kobieta-wbiegla-do-kosciola-zniszczyla-figure-je,nId,6558326)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 07:57:19+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-polnaga-kobieta-wbiegla-do-kosciola-zniszczyla-figure-je,nId,6558326"><img align="left" alt="USA: Półnaga kobieta wbiegła do kościoła. Zniszczyła figurę Jezusa" src="https://i.iplsc.com/usa-polnaga-kobieta-wbiegla-do-kosciola-zniszczyla-figure-je/000GO5LLE4CDSYHH-C321.jpg" /></a>Kobieta bez bluzki, stanika i butów wbiegła do katolickiego kościoła w Fargo w Północnej Dakocie. Przewróciła roślinę w doniczce, a chwilę później oderwała figurę Jezusa od ściany i roztrzaskała ją o podłogę. By zatrzymać kobietę konieczna okazała się pomoc policji.</p><br clear="all" />

## Kanada ostrzega przed TikTokiem. Rząd w Pekinie może gromadzić dane
 - [https://wydarzenia.interia.pl/zagranica/news-kanada-ostrzega-przed-tiktokiem-rzad-w-pekinie-moze-gromadzi,nId,6558321](https://wydarzenia.interia.pl/zagranica/news-kanada-ostrzega-przed-tiktokiem-rzad-w-pekinie-moze-gromadzi,nId,6558321)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 07:53:00+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kanada-ostrzega-przed-tiktokiem-rzad-w-pekinie-moze-gromadzi,nId,6558321"><img align="left" alt="Kanada ostrzega przed TikTokiem. Rząd w Pekinie może gromadzić dane" src="https://i.iplsc.com/kanada-ostrzega-przed-tiktokiem-rzad-w-pekinie-moze-gromadzi/000GO5KOI59TGQDL-C321.jpg" /></a>Kanadyjski wywiad elektroniczny przygotowuje zalecenia w sprawie należącego do Chińczyków TikToka i ostrzega użytkowników, by nie zezwalali na dostęp instalowanych aplikacji do prywatnych informacji. Zwraca uwagę na niebezpieczeństwo gromadzenia danych przez rząd w Pekinie. </p><br clear="all" />

## Spuściła psa z łańcucha. Ten pogryzł dziewięciolatka na placu zabaw
 - [https://wydarzenia.interia.pl/pomorskie/news-spuscila-psa-z-lancucha-ten-pogryzl-dziewieciolatka-na-placu,nId,6558307](https://wydarzenia.interia.pl/pomorskie/news-spuscila-psa-z-lancucha-ten-pogryzl-dziewieciolatka-na-placu,nId,6558307)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 07:26:50+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-spuscila-psa-z-lancucha-ten-pogryzl-dziewieciolatka-na-placu,nId,6558307"><img align="left" alt="Spuściła psa z łańcucha. Ten pogryzł dziewięciolatka na placu zabaw" src="https://i.iplsc.com/spuscila-psa-z-lancucha-ten-pogryzl-dziewieciolatka-na-placu/000GO59AQKNL2G48-C321.jpg" /></a>Spuszczony z łańcucha pies zaatakował bawiącego się na placu zabaw dziewięciolatka. Zwierzę ugryzło chłopca i przewróciło na ziemię. Właścicielka czworonoga została ukarana mandatem karnym za niezachowanie ostrożności. </p><br clear="all" />

## Wiek emerytalny w Europie. W jakim wieku kończą pracę nasi sąsiedzi?
 - [https://wydarzenia.interia.pl/kraj/news-wiek-emerytalny-w-europie-w-jakim-wieku-koncza-prace-nasi-sa,nId,6556247](https://wydarzenia.interia.pl/kraj/news-wiek-emerytalny-w-europie-w-jakim-wieku-koncza-prace-nasi-sa,nId,6556247)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:55:22+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-wiek-emerytalny-w-europie-w-jakim-wieku-koncza-prace-nasi-sa,nId,6556247"><img align="left" alt="Wiek emerytalny w Europie. W jakim wieku kończą pracę nasi sąsiedzi?" src="https://i.iplsc.com/wiek-emerytalny-w-europie-w-jakim-wieku-koncza-prace-nasi-sa/000GO05HJMIQ7PYR-C321.jpg" /></a>Wiek emerytalny w Polsce wynosi obecnie 65 lat w przypadku mężczyzn i 60 w przypadku kobiet. Od lat toczy się jednak na ten temat żywa dyskusja. Tymczasem okazuje się, że w porównaniu z innymi krajami europejskimi i tak pracujemy stosunkowo krótko. Ile wynosi wiek emerytalny u naszych sąsiadów?</p><br clear="all" />

## Białystok: Pijany dziennikarz na antenie. Interweniowała policja
 - [https://wydarzenia.interia.pl/podlaskie/news-bialystok-pijany-dziennikarz-na-antenie-interweniowala-polic,nId,6558284](https://wydarzenia.interia.pl/podlaskie/news-bialystok-pijany-dziennikarz-na-antenie-interweniowala-polic,nId,6558284)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:47:32+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-bialystok-pijany-dziennikarz-na-antenie-interweniowala-polic,nId,6558284"><img align="left" alt="Białystok: Pijany dziennikarz na antenie. Interweniowała policja" src="https://i.iplsc.com/bialystok-pijany-dziennikarz-na-antenie-interweniowala-polic/000GO57J8VQ1XL7A-C321.jpg" /></a>Trzygodzinną audycję w Radiu Białystok prowadził nietrzeźwy dziennikarz. Interweniował prezes rozgłośni oraz patrol policji - badanie alkomatem wykazało 2,5 promila alkoholu we krwi. </p><br clear="all" />

## Mariusz Błaszczak: Pierwsze Abramsy w Polsce na wiosnę. Są lepsze od Leopardów
 - [https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-pierwsze-abramsy-w-polsce-na-wiosne-sa-lep,nId,6558278](https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-pierwsze-abramsy-w-polsce-na-wiosne-sa-lep,nId,6558278)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:32:21+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-mariusz-blaszczak-pierwsze-abramsy-w-polsce-na-wiosne-sa-lep,nId,6558278"><img align="left" alt="Mariusz Błaszczak: Pierwsze Abramsy w Polsce na wiosnę. Są lepsze od Leopardów" src="https://i.iplsc.com/mariusz-blaszczak-pierwsze-abramsy-w-polsce-na-wiosne-sa-lep/000GNZTX9OKVPWGJ-C321.jpg" /></a>Pierwsze czołgi Abrams zostaną odebrane przez Polskę na wiosnę - poinformował w czwartek Mariusz Błaszczak. Wicepremier, minister obrony narodowej podkreślił, że amerykańskie czołgi są &quot;zdecydowanie lepsze niż Leopardy&quot;.</p><br clear="all" />

## Szkocja: Gwałciciel zmienił płeć. Może trafić do żeńskiego więzienia
 - [https://wydarzenia.interia.pl/zagranica/news-szkocja-gwalciciel-zmienil-plec-moze-trafic-do-zenskiego-wie,nId,6558270](https://wydarzenia.interia.pl/zagranica/news-szkocja-gwalciciel-zmienil-plec-moze-trafic-do-zenskiego-wie,nId,6558270)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:30:35+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szkocja-gwalciciel-zmienil-plec-moze-trafic-do-zenskiego-wie,nId,6558270"><img align="left" alt="Szkocja: Gwałciciel zmienił płeć. Może trafić do żeńskiego więzienia" src="https://i.iplsc.com/szkocja-gwalciciel-zmienil-plec-moze-trafic-do-zenskiego-wie/000GO54X9EA9D5NU-C321.jpg" /></a>Adam Graham zgwałcił dwie kobiety, a po tym, gdy został aresztowany, rozpoczął proces zmiany płci. Teraz ma 31 lat, nazywa się Isla Bryson. Za około miesiąc może trafić do żeńskiego więzienia, gdzie w celi będzie z innymi skazanymi. Żona gwałciciela przekonuje, że wymyślił transseksualność, by otrzymać łagodniejszy wyrok i ostrzega, że może dopuścić się kolejnych gwałtów. Przypadek Grahama/Bryson wzmógł kontrowersje wokół szkockiej ustawy pozwalającej na prawną zmianę płci na podstawie własnej deklaracji.</p><br clear="all" />

## Kraken wykryty u dwóch polskich pacjentów. "Zakażeń jest więcej"
 - [https://wydarzenia.interia.pl/kraj/news-kraken-wykryty-u-dwoch-polskich-pacjentow-zakazen-jest-wiece,nId,6556563](https://wydarzenia.interia.pl/kraj/news-kraken-wykryty-u-dwoch-polskich-pacjentow-zakazen-jest-wiece,nId,6556563)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:16:47+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-kraken-wykryty-u-dwoch-polskich-pacjentow-zakazen-jest-wiece,nId,6556563"><img align="left" alt="Kraken wykryty u dwóch polskich pacjentów. &quot;Zakażeń jest więcej&quot;" src="https://i.iplsc.com/kraken-wykryty-u-dwoch-polskich-pacjentow-zakazen-jest-wiece/000GO231JAQXINUA-C321.jpg" /></a>Ministerstwo Zdrowia potwierdza: do Polski dotarł nowy wariant koronawirusa. XBB1.5, czyli Kraken, został wykryty u dwóch pacjentów z województwa łódzkiego. - Z pewnością osób zakażonych Krakenem jest w naszym kraju więcej - mówi Interii prof. Joanna Zajkowska, specjalistka chorób zakaźnych z Uniwersytetu Medycznego w Białymstoku. I dodaje, że zakażenia tym podwariantem Omikrona postępują szybko, przez co w ciągu kilku tygodni może on zacząć w Polsce dominować. - W tej chwili ustępuje u nas grypa i prawdopodobnie na jej miejsce wkroczy...</p><br clear="all" />

## Zakaz palenia w kominkach 2023. Gdzie i kiedy nie wolno palić w kominku?
 - [https://wydarzenia.interia.pl/kraj/news-zakaz-palenia-w-kominkach-2023-gdzie-i-kiedy-nie-wolno-palic,nId,6544249](https://wydarzenia.interia.pl/kraj/news-zakaz-palenia-w-kominkach-2023-gdzie-i-kiedy-nie-wolno-palic,nId,6544249)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 06:05:23+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/kraj/news-zakaz-palenia-w-kominkach-2023-gdzie-i-kiedy-nie-wolno-palic,nId,6544249"><img align="left" alt="Zakaz palenia w kominkach 2023. Gdzie i kiedy nie wolno palić w kominku?" src="https://i.iplsc.com/zakaz-palenia-w-kominkach-2023-gdzie-i-kiedy-nie-wolno-palic/000GN3Q4UQ6NRU1M-C321.jpg" /></a>Zakaz palenia w kominkach jest faktem, a za jego złamanie Polakom mogą grozić wysokie kary finansowe. Ponieważ jednak obowiązuje on jedynie w niektóre dni i nie dotyczy wszystkich, warto dowiedzieć się o nim jak najwięcej. Jakie są przepisy, zakazy i ograniczenia, wynikające z uchwał antysmogowych i programów ochrony powietrza poszczególnych województw? Oto, gdzie i kiedy nie wolno palić w kominku. </p><br clear="all" />

## ONZ: Pandemia sprawiła, że spadła liczba ofiar handlu ludźmi
 - [https://wydarzenia.interia.pl/zagranica/news-onz-pandemia-sprawila-ze-spadla-liczba-ofiar-handlu-ludzmi,nId,6558263](https://wydarzenia.interia.pl/zagranica/news-onz-pandemia-sprawila-ze-spadla-liczba-ofiar-handlu-ludzmi,nId,6558263)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 05:43:45+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-onz-pandemia-sprawila-ze-spadla-liczba-ofiar-handlu-ludzmi,nId,6558263"><img align="left" alt="ONZ: Pandemia sprawiła, że spadła liczba ofiar handlu ludźmi" src="https://i.iplsc.com/onz-pandemia-sprawila-ze-spadla-liczba-ofiar-handlu-ludzmi/000GO50UVHRFSSLM-C321.jpg" /></a>O 11 proc. mniej przypadków handlu ludźmi wykryto w 2020 roku, a wstępne dane za następny rok sugerują dalszy spadek w niektórych regionach - ustaliło Biuro Narodów Zjednoczonych ds. Narkotyków i Przestępczości (UNODC), działające przy ONZ. Eksperci stwierdzili, że przyczyną są trzy czynniki, ale każdy z nich związany jest z pandemią koronawirusa. Obawiają się jednocześnie, że ofiar handlu ludźmi przybędzie po tym, jak Rosja zaatakowała Ukrainę.</p><br clear="all" />

## Bułgaria: Rośnie napięcie z Macedonią Północną
 - [https://wydarzenia.interia.pl/zagranica/news-bulgaria-rosnie-napiecie-z-macedonia-polnocna,nId,6558261](https://wydarzenia.interia.pl/zagranica/news-bulgaria-rosnie-napiecie-z-macedonia-polnocna,nId,6558261)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 05:31:29+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bulgaria-rosnie-napiecie-z-macedonia-polnocna,nId,6558261"><img align="left" alt="Bułgaria: Rośnie napięcie z Macedonią Północną" src="https://i.iplsc.com/bulgaria-rosnie-napiecie-z-macedonia-polnocna/000GO50652TYCT7I-C321.jpg" /></a>Po pobiciu sekretarza bułgarskiego ośrodka kultury w Macedonii Północnej Sofia podejmuje &quot;poważne kroki, by chronić prawa bułgarskiej mniejszości&quot; w tym kraju. Jak poinformował szef MSZ Nikołaj Miłkow, przerwana zostanie m.in. realizacja wspólnych projektów ekonomicznych i kulturalnych.</p><br clear="all" />

## Meta: Donald Trump może wrócić na Facebooka
 - [https://wydarzenia.interia.pl/zagranica/news-meta-donald-trump-moze-wrocic-na-facebooka,nId,6558260](https://wydarzenia.interia.pl/zagranica/news-meta-donald-trump-moze-wrocic-na-facebooka,nId,6558260)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 05:25:44+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-meta-donald-trump-moze-wrocic-na-facebooka,nId,6558260"><img align="left" alt="Meta: Donald Trump może wrócić na Facebooka" src="https://i.iplsc.com/meta-donald-trump-moze-wrocic-na-facebooka/000954ERRXCWK4W8-C321.jpg" /></a>W najbliższych tygodniach były prezydent USA Donald Trump będzie mógł powrócić na Facebooka, o czym poinformowała w środę firma Meta, właściciel tego serwisu społecznościowego. Odblokowane mają też zostać jego konta na Messengerze, Instagramie i WhatsAppie. Zdaniem przedsiębiorstwa obecnie nie utrzymują się &quot;nadzwyczajne okoliczności&quot;, z którymi mieliśmy do czynienia dwa lata temu, gdy blokowano profile Trumpa.</p><br clear="all" />

## Wojna w Ukrainie. 337. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260621](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260621)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 04:36:51+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260621"><img align="left" alt="Wojna w Ukrainie. 337. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo/000GO4XN2V9OPHC8-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />

## Wojna w Ukrainie. 337. dzień inwazji Rosji. Relacja na żywo
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260711](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260711)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-01-26 04:36:51+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/nazywo/na-zywo-wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo,nzId,3683,akt,260711"><img align="left" alt="Wojna w Ukrainie. 337. dzień inwazji Rosji. Relacja na żywo" src="https://i.iplsc.com/wojna-w-ukrainie-337-dzien-inwazji-rosji-relacja-na-zywo/000GO4XN2V9OPHC8-C321.jpg" /></a>Zapraszamy do śledzenia relacji na żywo.</p><br clear="all" />
