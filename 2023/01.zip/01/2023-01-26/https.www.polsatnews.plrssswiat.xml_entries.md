# Source Polsat News, Source URL:https://www.polsatnews.pl/rss/swiat.xml, Source language: pl-PL

## Mateusz Morawiecki: Reżim Putina jest kolosem na glinianych nogach
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/mateusz-morawiecki-rezim-putina-jest-kolosem-na-glinianych-nogach/](https://www.polsatnews.pl/wiadomosc/2023-01-26/mateusz-morawiecki-rezim-putina-jest-kolosem-na-glinianych-nogach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 20:27:00+00:00
 - user: None

Reżim Putina jest kolosem na glinianych nogach, ale pozostaje kolosem - stwierdził w wywiadzie dla francuskiej telewizji LCI premier Mateusz Morawiecki. Polski polityk przekonywał, że Zachód musi odważnie wspierać Ukrainę w walce z agresorem. Zaznaczył też, że Paryż za bardzo ulegała wpływom rosyjskiej propagandy.

## Ukraina. Rosjanie wykorzystują mobilne krematoria. "Palą zwłoki żołnierzy bez identyfikacji"
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/ukraina-rosjanie-wykorzystuja-mobilne-krematoria-palna-zwloki-zolnierzy-bez-identyfikacji/](https://www.polsatnews.pl/wiadomosc/2023-01-26/ukraina-rosjanie-wykorzystuja-mobilne-krematoria-palna-zwloki-zolnierzy-bez-identyfikacji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 20:02:00+00:00
 - user: None

Rosjanie aktywnie korzystają z mobilnych krematoriów - informuje Hanna Malar, wiceminister obrony Ukrainy powołując się na dane wywiadu resortu. Według doniesień opublikowanych na Telegramie okupanci mają kremować zwłoki swoich żołnierzy bez wcześniejszej identyfikacji zwłok, co podyktowane ma być ogromnymi stratami na polu walki.

## Wojna w Ukrainie. Mer Melitopola: W pobliżu miasta widziano białoruskich żołnierzy
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-mer-melitopola-w-poblizu-miasta-widziano-bialoruskich-zolnierzy/](https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-mer-melitopola-w-poblizu-miasta-widziano-bialoruskich-zolnierzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 19:57:00+00:00
 - user: None

Mer Melitopola Iwan Fedorow poinformował, że w pobliże okupowanego miasta sprowadzono białoruskich żołnierzy. Takie informacje przekazali okoliczni mieszkańcy. Wojskowi z naszywkami Witebsk mają być przewożeni do Kiryłówki niedaleko Melitopola w obwodzie zaporoskim.

## Dzieli ich 14 tys. km, spotkali się dwa razy. Postanowili się zaręczyć
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/dzieli-ich-14-tys-km-spotkali-sie-dwa-razy-postanowili-sie-zareczyc/](https://www.polsatnews.pl/wiadomosc/2023-01-26/dzieli-ich-14-tys-km-spotkali-sie-dwa-razy-postanowili-sie-zareczyc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 18:11:00+00:00
 - user: None

22-letni Luke Bond i młodsza o rok Sarah Dorough to instruktorzy fitness, którzy poznali się na Instagramie w grudniu 2021 roku. Jak podaje New York Post, połączył ich zdrowy styl życia i... chrześcijaństwo. Pomimo tego, że mieszkają 13972 km od siebie, przyrzekli sobie codzienne rozmowy przez FaceTime. Wytrwali w tym postanowieniu aż do spotkania w lipcu 2022 roku. Zaręczyli się w grudniu.

## Wypadek Jeremy'ego Rennera. Aktor próbował zatrzymać pług przed uderzeniem w jego krewnego
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/wypadek-jeremyego-rennera-aktor-probowal-zatrzymac-plug-przed-uderzeniem-w-jego-krewnego/](https://www.polsatnews.pl/wiadomosc/2023-01-26/wypadek-jeremyego-rennera-aktor-probowal-zatrzymac-plug-przed-uderzeniem-w-jego-krewnego/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 17:58:00+00:00
 - user: None

Według raportu z wypadku, do którego doszło w Nowy Rok, Jeremy Renner miał powstrzymać staczający się pług śnieżny, zanim ten uderzyłby w jego siostrzeńca. Aktor został wciągnięty pod pojazd i z poważnymi obrażeniami trafił do szpitala.

## Regé-Jean Page najprzystojniejszym mężczyzną świata. Wybór oparty na starożytnym wzorze
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/reg-jean-page-najprzystojniejszym-mezczyzna-swiata-wybor-oparty-na-starozytnym-wzorze/](https://www.polsatnews.pl/wiadomosc/2023-01-26/reg-jean-page-najprzystojniejszym-mezczyzna-swiata-wybor-oparty-na-starozytnym-wzorze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 17:16:00+00:00
 - user: None

Regé-Jean Page, gwiazda serialu Bridgertonowie został uznany najprzystojniejszym mężczyzną świata. Grupa celebrytów została oceniona pod tym kątem w oparciu o starożytny wzór tzw. złotej proporcji. Dzięki badaniu udało się wyłonić 10 najatrakcyjniejszych znanych ludzi na świecie.

## USA. Pies ukradł lunch na komendzie. Zrobiono mu zdjęcie do kartoteki
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/usa-pies-ukradl-lunch-na-komendzie-zrobiono-mu-zdjecie-do-kartoteki/](https://www.polsatnews.pl/wiadomosc/2023-01-26/usa-pies-ukradl-lunch-na-komendzie-zrobiono-mu-zdjecie-do-kartoteki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 16:31:00+00:00
 - user: None

Udostępnione przez Departament Policji Wyandotte w amerykańskim stanie Michigan zdjęcie czworonoga na tle wykorzystywanym do fotografowania zatrzymanych stało się hitem internetu. Pies wabiący się Oficer Ice został oskarżony o zjedzenie posiłku jednego z funkcjonariuszy. W obronie zwierzęcia stanęli użytkownicy mediów społecznościowych.

## Media: Prezydent USA rozważa wizytę w Europie. Możliwe, że odwiedzi też Polskę
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/prezydent-usa-rozwaza-wizyte-w-europie-mozliwe-ze-odwiedzi-tez-polske/](https://www.polsatnews.pl/wiadomosc/2023-01-26/prezydent-usa-rozwaza-wizyte-w-europie-mozliwe-ze-odwiedzi-tez-polske/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 16:30:00+00:00
 - user: None

Prezydent USA ma rozważać podróż po Europie - przekazały amerykańskie media. Wizyta ma zbiec się z pierwszą rocznicą inwazji Rosji na Ukrainę. Możliwe, że Joe Biden pojawi się również w Polsce.

## Ukraina. Wołodymyr Zełenski nie chce rozmawiać z Władimirem Putinem. Dmitrij Pieskow odpowiedział
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/ukraina-wolodymyr-zelenski-nie-chce-rozmawiac-z-wladimirem-putinem-dmitrij-pieskow-odpowiedzial/](https://www.polsatnews.pl/wiadomosc/2023-01-26/ukraina-wolodymyr-zelenski-nie-chce-rozmawiac-z-wladimirem-putinem-dmitrij-pieskow-odpowiedzial/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 14:27:00+00:00
 - user: None

Po inwazji na pełną skalę dla mnie jest nikim - powiedział o prezydencie Rosji w rozmowie ze Sky News Wołodymyr Zełenski. Tłumaczył, że Władimir Putin podczas ostatniego ich spotkania przed inwazją mówił jedno, a potem robił drugie. - Prezydent Ukrainy już dawno przestał być potencjalnym rozmówcą dla prezydenta Rosji - odpowiedział rzecznik Kremla Dmitrij Pieskow cytowany przez TASS.

## Szwecja: Zdecydowana reakcja rządu po serii eksplozji. W kraju szaleją grupy przestępcze
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/zdecydowana-reakcja-szwedzkiego-rzadu-po-serii-eksplozji-w-kraju-szaleja-grupy-przestepcze/](https://www.polsatnews.pl/wiadomosc/2023-01-26/zdecydowana-reakcja-szwedzkiego-rzadu-po-serii-eksplozji-w-kraju-szaleja-grupy-przestepcze/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 12:57:00+00:00
 - user: None

Po czwartkowej eksplozji, do której doszło w miejscowości Tullinge, niedaleko Sztokholmu, szwedzki rząd zdecydowanie odpowiada. Podczas zwołanej konferencji prasowej premier Ulf Kristersson zapowiedział zmiany, które mają zbliżyć kraj do zakończenia ery działalności organizacji przestępczych. W Sztokholmie i okolicach tylko od świąt Bożego Narodzenia doszło do 16 wybuchów.

## Rosja odpowiada na dostawy czołgów atakiem. Boris Pistorius: Przyspieszymy dostawy amunicji
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/rosja-odpowiada-na-dostawy-czolgow-atakiem-boris-pistorius-przyspieszymy-dostawy/](https://www.polsatnews.pl/wiadomosc/2023-01-26/rosja-odpowiada-na-dostawy-czolgow-atakiem-boris-pistorius-przyspieszymy-dostawy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 10:40:00+00:00
 - user: None

- Zmasowany atak rakietowy Rosji na Ukrainę w czwartek to reakcja Moskwy na decyzje państw Zachodu w sprawie przekazania czołgów ukraińskim siłom zbrojnym - powiedział ambasador UE w Kijowie Matti Maasikas. Jest też reakcja Niemiec. - Chcemy przyspieszyć zamówienia na broń i zwiększyć dostawy amunicji.

## USA. Przestępcy "dżentelmeni". Byli uprzejmi, potrzymali pizzę, później zabrali kluczyki do auta
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/usa-przestepcy-dzentelmeni-byli-uprzejmi-potrzymali-pizze-pozniej-zabrali-kluczyki-do-auta/](https://www.polsatnews.pl/wiadomosc/2023-01-26/usa-przestepcy-dzentelmeni-byli-uprzejmi-potrzymali-pizze-pozniej-zabrali-kluczyki-do-auta/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 10:03:00+00:00
 - user: None

Do niecodziennego napadu doszło w Chicago. Zamaskowani i uzbrojeni mężczyźni podeszli do mężczyzny spacerującego chodnikiem i zażądali kluczyków do samochodu. By ułatwić ich znalezienie, potrzymali pudełko z pizzą, które niósł napadnięty przechodzień, a następnie podziękowali, używając słowa sir. Dżentelmeni - piszą media w USA.

## Wojna w Ukrainie. Trwa ostrzał Kijowa. Mer apeluje o pozostanie w schronach
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-trwa-ostrzal-kijowa-mer-apeluje-o-pozostanie-w-schronach/](https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-trwa-ostrzal-kijowa-mer-apeluje-o-pozostanie-w-schronach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 08:58:00+00:00
 - user: None

Wróg wystrzelił w kierunku Kijowa ponad 15 rakiet - poinformowała oficjalna strona Administracji Wojskowej Kijowa. Choć wszystkie udało się zestrzelić, odłamki uderzają w poszczególne dzielnice stolicy Ukrainy. W wyniku upadku części rakiety zginął 55-letni mężczyzna. Liczba rannych wzrasta. Władze alarmują do mieszkańców, żeby nie wychodzili ze schronów.

## Szwecja: Potężna eksplozja pod Sztokholmem
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/szwecja-potezna-eksplozja-pod-sztokholmem/](https://www.polsatnews.pl/wiadomosc/2023-01-26/szwecja-potezna-eksplozja-pod-sztokholmem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 08:06:00+00:00
 - user: None

Do wybuchu, który wstrząsnął miejscowością Tullinge, doszło w czwartek po północy w strefie przemysłowej. - W elewacji są kilkumetrowe dziury - powiedział Daniel Kaissidis, oficer dyżurny służb ratowniczych. Kamera monitoringu zarejestrowała osoby, które tuż przed wybuchem zostawiły przed budynkiem materiałową torbę. Stolicą Szwecji w ostatnich dniach wstrząsnęły liczne strzelaniny i eksplozje.

## Szkocja. Transseksualny gwałciciel uważa, że jest kobietą. Żona: Chce trafić do więzienia dla kobiet
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/szkocja-transseksualny-gwalciciel-uwaza-ze-jest-kobieta-zona-chce-trafic-do-wiezienia-dla-kobiet/](https://www.polsatnews.pl/wiadomosc/2023-01-26/szkocja-transseksualny-gwalciciel-uwaza-ze-jest-kobieta-zona-chce-trafic-do-wiezienia-dla-kobiet/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 06:59:00+00:00
 - user: None

Isla Bryson została przez sąd w Glasgow uznana winną zgwałcenia dwóch kobiet. Do gwałtów doszło, gdy Isla identyfikowała się jeszcze jako mężczyzna. Grozi jej kara pozbawienia wolności. Pytanie, czy wyrok będzie odbywać w więzieniu dla kobiet czy dla mężczyzn. Skazana nie przeszła korekty zmiany płci - jest trakcie kuracji hormonalnej, operację ma w planach.

## Wojna w Ukrainie. Turecki statek towarowy trafiony rakietami w porcie w Chersoniu
 - [https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-turecki-statek-towarowy-trafiony-rakietami-w-porcie-w-chersoniu/](https://www.polsatnews.pl/wiadomosc/2023-01-26/wojna-w-ukrainie-turecki-statek-towarowy-trafiony-rakietami-w-porcie-w-chersoniu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-01-26 05:34:00+00:00
 - user: None

Pożar na tureckim statku handlowym w porcie w Chersoniu na południu Ukrainy nad Morzem Czarnym. Jednostka miała zostać we wtorek trafiona rosyjską rakietą. Ogień został ugaszony, a w sieci pojawiły się nagrania szkód wyrządzonych przez eksplozję. Brak informacji o ofiarach. Drobnicowiec stoi w Chersoniu od początku rosyjskiej inwazji na Ukrainę.
