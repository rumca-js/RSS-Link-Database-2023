# Source BBC, Source URL:http://feeds.bbci.co.uk/news/rss.xml, Source language: en-US

## The Papers: 'Rod attacks Tories' and 'Zahawi hands over taxes'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64421168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64421168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 23:44:38+00:00
 - user: None

Many of Friday's papers cover HMRC's investigation into Nadhim Zahawi's tax affairs and Sir Rod Stewart comments about the Tory party.

## Hunt to set out plan for growth as criticism mounts
 - [https://www.bbc.co.uk/news/business-64417101?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64417101?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 22:58:52+00:00
 - user: None

It will be scrutinised by businesses who claim the government has no long-term plan for the economy.

## Reanne Evans beats Stuart Bingham to become first woman to win a match at Snooker Shoot Out
 - [https://www.bbc.co.uk/sport/snooker/64421226?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/64421226?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 22:50:48+00:00
 - user: None

Reanne Evans beats former world champion Stuart Bingham 60-8 to become the first woman to win a match in the one-frame Snooker Shoot Out in Leicester.

## Matt Hancock paid £320K for I'm a Celebrity appearance
 - [https://www.bbc.co.uk/news/uk-politics-64421025?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64421025?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 21:51:11+00:00
 - user: None

The former health secretary says he donated £10,000 of the fee to two charities.

## Kolo Toure: Wigan Athletic sack boss after no wins from nine games in charge
 - [https://www.bbc.co.uk/sport/football/64361824?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64361824?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 20:07:05+00:00
 - user: None

Wigan Athletic sack boss Kolo Toure after he failed to win any of his nine games in charge.

## Rod Stewart calls on Tories to make way for Labour
 - [https://www.bbc.co.uk/news/uk-politics-64417054?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64417054?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 20:05:41+00:00
 - user: None

The singer-songwriter, 78, says problems in the NHS have left the UK in the worst state he has seen.

## FA Cup predictions: Chris Sutton faces Krept from rap duo Krept & Konan
 - [https://www.bbc.co.uk/sport/football/64366338?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64366338?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 20:03:49+00:00
 - user: None

BBC Sport football expert Chris Sutton takes on Krept from Krept & Konan to make predictions for this weekend's FA Cup ties

## Elle Edwards: Man arrested over Christmas Eve pub shooting
 - [https://www.bbc.co.uk/news/uk-england-merseyside-64419791?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-64419791?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 19:29:52+00:00
 - user: None

The 20-year-old man has been held on suspicion of conspiracy to murder and assisting an offender.

## Leeds St James's Hospital: Man charged with planning terror attack
 - [https://www.bbc.co.uk/news/uk-england-leeds-64420363?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-64420363?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 19:23:54+00:00
 - user: None

A 27-year-old man is charged with planning a terror attack after the security scare at a hospital.

## Egypt archaeology: Gold-covered mummy among latest discoveries
 - [https://www.bbc.co.uk/news/world-middle-east-64415816?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64415816?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 19:18:47+00:00
 - user: None

The mummy is found sealed inside a sarcophagus that has been unopened for 4,300 years.

## Five Memphis police officers charged over death of Tyre Nichols
 - [https://www.bbc.co.uk/news/world-us-canada-64420124?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64420124?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 18:40:30+00:00
 - user: None

The 29-year-old was stopped in Memphis on 7 January for reckless driving and died three days later.

## Relative of Harold Shipman victim hits out at life insurance advert
 - [https://www.bbc.co.uk/news/uk-england-manchester-64419630?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-64419630?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 18:37:31+00:00
 - user: None

A life insurance firm said it wanted to "make people think" by using the serial killer's image.

## Sikh player in head covering row welcomes FA rule update for refs
 - [https://www.bbc.co.uk/news/newsbeat-64420104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64420104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 18:17:32+00:00
 - user: None

Charan Singh Basra, who was sent off in a row over his head covering - says the move is "needed".

## Israel-Palestinian conflict: Fears of wider flare-up after deadly Jenin raid
 - [https://www.bbc.co.uk/news/64417822?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/64417822?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 18:14:19+00:00
 - user: None

What's behind the raid on the West Bank city, which led to nine Palestinian deaths on Thursday?

## Pep Guardiola: 'Mikel Arteta wouldn't celebrate goals against Arsenal'
 - [https://www.bbc.co.uk/sport/av/football/64420031?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/64420031?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 17:48:51+00:00
 - user: None

Manchester City manager Pep Guardiola looks back on his time working with Mikel Arteta, and recalls how his then-assistant coach would never celebrate goals against "his club" Arsenal.

## Transpennine Express boss apologises for poor services
 - [https://www.bbc.co.uk/news/business-64412789?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64412789?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 17:39:19+00:00
 - user: None

The head of Transpennine Express admits services have not been good enough in recent months.

## Gareth Southgate: England manager on decision to stay, World Cup & human rights
 - [https://www.bbc.co.uk/sport/football/64397469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64397469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 17:03:10+00:00
 - user: None

Gareth Southgate talks to BBC sports editor Dan Roan about his decision to remain England manager, the team's performance in Qatar and why he has no regrets.

## Windrush report: Suella Braverman scraps three recommendations
 - [https://www.bbc.co.uk/news/uk-64414451?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64414451?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 16:41:34+00:00
 - user: None

The home secretary says the changes recommended in the wake of the scandal will no longer go ahead.

## Marcelo Bielsa: Ex-Leeds boss in London for further talks with Everton over managerial vacancy
 - [https://www.bbc.co.uk/sport/football/64416720?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64416720?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 16:41:30+00:00
 - user: None

Marcelo Bielsa arrives in London for further talks with the Everton hierarchy as they search for a successor to Frank Lampard.

## Andrew Bridgen threatens to sue Matt Hancock in Covid vaccine row
 - [https://www.bbc.co.uk/news/uk-politics-64414637?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64414637?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 16:39:33+00:00
 - user: None

MP Andrew Bridgen claims he was libelled, but the former health secretary is standing by his comments.

## Joanna Gosling bids an emotional farewell to BBC News live on-air
 - [https://www.bbc.co.uk/news/entertainment-arts-64418230?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64418230?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 16:09:34+00:00
 - user: None

Joanna Gosling says goodbye to viewers after 23 years in a job "that's never felt like a job".

## Ben Youngs says rugby union has 'risks' and 'rewards' following tackle height changes
 - [https://www.bbc.co.uk/sport/rugby-union/64414430?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64414430?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 15:23:29+00:00
 - user: None

England's most-capped male player Ben Youngs insists the rewards of rugby union outweigh the risks as the debate over the controversial tackle law rages on.

## German man arrested for allegedly passing intelligence to Russia
 - [https://www.bbc.co.uk/news/world-europe-64415814?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64415814?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 15:22:05+00:00
 - user: None

The suspect is believed to have been involved in a scheme to pass German intelligence to Russia.

## Artur Beterbiev v Anthony Yarde: Briton relishing underdog tag against 'scary' champion
 - [https://www.bbc.co.uk/sport/boxing/64416877?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/boxing/64416877?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 15:15:59+00:00
 - user: None

Anthony Yarde says he is relishing the chance to upset the odds and topple light-heavyweight champion Artur Beterbiev on Saturday.

## Vinicius Jr: Effigy prompts condemnation of 'repugnant' behaviour towards Real Madrid winger
 - [https://www.bbc.co.uk/sport/football/64414425?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64414425?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 15:12:28+00:00
 - user: None

La Liga says it "strongly condemns acts of hatred and intimidation against Vinicius Jr" after an effigy of the Real Madrid winger is hung from a bridge.

## South Africa v England: Jofra Archer return headlines one-day series
 - [https://www.bbc.co.uk/sport/cricket/64375699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64375699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 14:49:13+00:00
 - user: None

Jofra Archer's return headlines an otherwise low-key one-day series in South Africa that begins a crucial year for the England men's team.

## Australian Open 2023: Novak Djokovic feels he has 'something extra' at this year's tournament
 - [https://www.bbc.co.uk/sport/tennis/64413670?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64413670?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 14:36:59+00:00
 - user: None

Novak Djokovic feels he has "something extra" at this year's Australian Open as he prepares to do battle for a place in the Melbourne final.

## Duncan Ferguson: Ex-Everton assistant manager named Forest Green head coach
 - [https://www.bbc.co.uk/sport/football/64413352?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64413352?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 14:24:09+00:00
 - user: None

Forest Green Rovers appoint former Everton assistant manager Duncan Ferguson as their new head coach.

## No penalties for 'innocent' tax errors, HMRC boss says
 - [https://www.bbc.co.uk/news/uk-politics-64410490?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64410490?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 13:38:15+00:00
 - user: None

Tory Party chairman Nadhim Zahawi is facing calls to resign, after it emerged he paid a penalty to HMRC.

## Jacob Rees-Mogg to host GB News show
 - [https://www.bbc.co.uk/news/entertainment-arts-64409947?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64409947?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 13:24:09+00:00
 - user: None

The former business secretary will "debate the hot topics of the day", the broadcaster confirmed.

## Nitrous oxide: Ban on use and sale of laughing gas considered
 - [https://www.bbc.co.uk/news/uk-64408790?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64408790?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 13:23:36+00:00
 - user: None

The drug, which can have damaging side effects, is thought to be a factor in anti-social behaviour.

## Transgender rapist Isla Bryson will not be imprisoned in women's jail
 - [https://www.bbc.co.uk/news/uk-scotland-64413242?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-64413242?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 13:19:58+00:00
 - user: None

First Minister Nicola Sturgeon has confirmed convicted rapist Isla Bryson will be removed from Cornton Vale.

## Olympics 2024: IOC plan for Russian & Belarusian athletes criticised by UK Government
 - [https://www.bbc.co.uk/sport/olympics/64413035?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/olympics/64413035?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 12:49:36+00:00
 - user: None

The IOC's plan to let Russian and Belarusian athletes compete in the 2024 Olympics is a "world away from the reality of war," says UK culture secretary Michelle Donelan.

## Michail Antonio: West Ham forward says he could leave the club in January
 - [https://www.bbc.co.uk/sport/football/64410413?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/64410413?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 12:48:29+00:00
 - user: None

West Ham forward Michail Antonio says there is a possibility he could leave the club in the January transfer window.

## Lucky escape after bus plunges into Turkey lake
 - [https://www.bbc.co.uk/news/world-europe-64414073?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64414073?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 12:35:46+00:00
 - user: None

CCTV shows the driver lose control of the steering wheel in an accident that left no-one seriously hurt.

## Rachel Chinouriri joins Lewis Capaldi tour after drunk DM
 - [https://www.bbc.co.uk/news/newsbeat-64412225?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-64412225?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 12:25:16+00:00
 - user: None

Rachel Chinouriri says being picked to support the star at his stadium shows is a dream come true.

## Katherine Brunt: England bowler retires from county cricket
 - [https://www.bbc.co.uk/sport/cricket/64413288?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64413288?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 12:14:40+00:00
 - user: None

England bowler Katherine Brunt is retiring from county cricket, although she will still play in The Hundred.

## Snooker Shoot Out: Moldovan Vladislav Gradinari, 14, becomes youngest televised ranking event match winner
 - [https://www.bbc.co.uk/sport/snooker/64412217?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/snooker/64412217?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 11:33:02+00:00
 - user: None

Fourteen-year-old Vladislav Gradinari becomes the youngest player to win a televised ranking event match by beating Ng On Yee in the first round of the Snooker Shoot Out.

## Jail for former West Yorkshire PC who let wife take blame for speeding
 - [https://www.bbc.co.uk/news/uk-england-leeds-64401782?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-64401782?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 11:10:10+00:00
 - user: None

A judge says the former officer thought he could "get away with it" but had been proved wrong.

## Green claims on household basics investigated
 - [https://www.bbc.co.uk/news/business-64411003?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64411003?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 11:08:10+00:00
 - user: None

The competition watchdog is concerned shoppers are being "misled" about goods claiming to be green.

## Matt Hancock: Man charged with assaulting former health secretary
 - [https://www.bbc.co.uk/news/uk-64410489?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64410489?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 11:07:22+00:00
 - user: None

The former health secretary is not thought to have been hurt in the incident on the London Underground.

## Ukraine war: Russian missiles hit Ukraine day after West's tanks move
 - [https://www.bbc.co.uk/news/world-europe-64411259?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-64411259?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 11:04:43+00:00
 - user: None

One person died and two others were injured after strikes in Kyiv, the city's mayor says.

## Newcastle United midfielder Joelinton fined £29k for drink-driving
 - [https://www.bbc.co.uk/news/uk-england-tyne-64412529?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-tyne-64412529?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 10:57:29+00:00
 - user: None

The 26-year-old midfielder was arrested while driving his Mercedes in the early hours of 12 January.

## Australian Open 2023 results: Elena Rybakina beats Victoria Azarenka to reach final
 - [https://www.bbc.co.uk/sport/tennis/64400521?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64400521?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 10:38:15+00:00
 - user: None

Wimbledon champion Elena Rybakina reaches another major final as she beats two-time winner Victoria Azarenka in the Australian Open semi-finals.

## Video shows moment of cliff collapse on Dorset's Jurassic Coast
 - [https://www.bbc.co.uk/news/uk-england-dorset-64409758?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-64409758?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 10:00:41+00:00
 - user: None

Puffs of dust are seen in the footage before the section of cliff crumbles on to the beach below.

## Clouds gather for Rishi Sunak as cabinet meets at away day
 - [https://www.bbc.co.uk/news/uk-politics-64410484?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-64410484?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:56:01+00:00
 - user: None

Two members of the prime minister's cabinet are currently under investigation over their conduct.

## Aaron Cruden & Andre Esterhuizen set to play for Barbarians against World XV
 - [https://www.bbc.co.uk/sport/rugby-union/64409811?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/64409811?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:46:24+00:00
 - user: None

All Black fly-half Aaron Cruden and South Africa centre Andre Esterhuizen are the latest internationals set to feature for Eddie Jones' Barbarians.

## Asteroid to pass closer than some satellites
 - [https://www.bbc.co.uk/news/science-environment-64411469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-64411469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:37:13+00:00
 - user: None

About the size of a bus, the space rock will whip over the southern tip of South America.

## Nine Palestinians killed in Israeli raid in Jenin
 - [https://www.bbc.co.uk/news/world-middle-east-64410607?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-64410607?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:15:39+00:00
 - user: None

The heaviest death toll in months comes as troops battle militants in the flashpoint West Bank town.

## Dad's warning after girl, 14, dies from inhaling deodorant
 - [https://www.bbc.co.uk/news/uk-england-derbyshire-62078939?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-derbyshire-62078939?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:06:23+00:00
 - user: None

Giorgia Green's parents want clearer product labelling to warn of the potential dangers.

## Is UK being left behind in global climate investment battle?
 - [https://www.bbc.co.uk/news/business-64405020?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64405020?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:05:11+00:00
 - user: None

The future of the planet and the global economy are entwined in a potentially risky geopolitical game.

## Ben Stokes and Nat Sciver win ICC Cricketer of the Year awards
 - [https://www.bbc.co.uk/sport/cricket/64406904?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/64406904?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 09:01:39+00:00
 - user: None

Ben Stokes is named ICC Men's Test Cricketer of the Year and Nat Sciver wins the women's ODI award

## Artur Beterbiev v Anthony Yarde: Arsenal to win the league & dreaming of fast food
 - [https://www.bbc.co.uk/sport/av/boxing/64406193?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/boxing/64406193?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 08:53:20+00:00
 - user: None

BBC Sport goes 12 rounds with Anthony Yarde before his world title fight against Artur Beterbiev on Saturday.

## Chester Zoo: Rare tree kangaroo emerges from mum's pouch
 - [https://www.bbc.co.uk/news/uk-england-merseyside-64410270?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-64410270?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 08:26:53+00:00
 - user: None

The joey, the first of its kind to be born at Chester Zoo, has been developing in the pouch since July.

## Royal Mail says strikes have cost it £200m
 - [https://www.bbc.co.uk/news/business-64410443?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64410443?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 08:23:42+00:00
 - user: None

The owner of the mail delivery service reveals the cost of the ongoing dispute over pay and conditions.

## Novak Djokovic's father Srdjan filmed at Australian Open posing for pictures with Vladimir Putin supporters
 - [https://www.bbc.co.uk/sport/tennis/64409618?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64409618?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 07:11:31+00:00
 - user: None

Novak Djokovic's father Srdjan is filmed posing for pictures with supporters of Russia president Vladimir Putin at the Australian Open.

## Leah Croucher murder suspect changed appearance - police
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-64386555?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-64386555?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 06:55:25+00:00
 - user: None

Leah Croucher murder detectives believe Neil Maxwell changed his appearance to evade arrest.

## Australian Open 2023 results: Alfie Hewett into wheelchair singles and doubles finals in Melbourne
 - [https://www.bbc.co.uk/sport/tennis/64409686?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/64409686?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 06:54:22+00:00
 - user: None

Britain's Alfie Hewett will contest two Australian Open finals after winning his semi-finals in both the wheelchair singles and doubles.

## 'The joy of fen skating is a great metaphor for life'
 - [https://www.bbc.co.uk/news/uk-england-cambridgeshire-64399819?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cambridgeshire-64399819?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 06:20:36+00:00
 - user: None

Photographer Harry George Hall captures skaters during a rare moment when conditions are just right.

## Ukraine war: Zelensky urges speedy delivery of Western tanks
 - [https://www.bbc.co.uk/news/world-64408504?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-64408504?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 04:32:42+00:00
 - user: None

Ukraine's president says the modern fighting vehicles must be supplied quickly and in significant numbers.

## Julian Sands: New air search for actor missing in California
 - [https://www.bbc.co.uk/news/world-us-canada-64408501?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-64408501?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 01:47:32+00:00
 - user: None

A helicopter fitted with a device which can detect reflective material and even credit cards is being used.

## Court bid to protect tenants from ‘ghost landlords’
 - [https://www.bbc.co.uk/news/uk-64378930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64378930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 01:35:43+00:00
 - user: None

It's hoped a ruling to define what a property landlord is will help tenants in some of England's worst homes.

## Physiotherapists, 'the quiet NHS miracle workers', walk out
 - [https://www.bbc.co.uk/news/health-64404684?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-64404684?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 01:15:27+00:00
 - user: None

The strike across 30 services in England is the latest action by NHS staff in the pay dispute.

## Charities urge PM to stop using hotels to house migrant children
 - [https://www.bbc.co.uk/news/uk-64407850?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64407850?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:52:23+00:00
 - user: None

More than 100 charities warn unaccompanied child asylum seekers housed in hotels are at risk.

## Can these rocks really power light bulbs? No, say the experts
 - [https://www.bbc.co.uk/news/64390767?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/64390767?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:47:51+00:00
 - user: None

Viral videos of minerals with apparent electrical properties are not what they seem.

## Live music: How buying concert tickets could be made better
 - [https://www.bbc.co.uk/news/entertainment-arts-64372274?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-64372274?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:46:45+00:00
 - user: None

Concerts can be life-affirming. Buying tickets is the opposite. Here are eight possible solutions.

## Iranian and Russian hackers targeting politicians and journalists, warn UK officials
 - [https://www.bbc.co.uk/news/uk-64405220?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-64405220?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:38:11+00:00
 - user: None

Politicians and journalists are being targeted with espionage attacks, the UK government is warning.

## The Papers: 'United against Putin' and 'baffling Brexit plan'
 - [https://www.bbc.co.uk/news/blogs-the-papers-64408095?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-64408095?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:04:53+00:00
 - user: None

Several of Thursday's papers lead with the West's commitment to send tanks to Ukraine.

## Subscription-based bike hire schemes on a roll
 - [https://www.bbc.co.uk/news/business-64371657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64371657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:04:33+00:00
 - user: None

A growing number of people are choosing to hire a bicycle over a long period of time.

## Cost of living: Cash bonuses behind record number of bank switches
 - [https://www.bbc.co.uk/news/business-64399666?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64399666?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:03:30+00:00
 - user: None

Up to £200 was offered by some banks to switching customers - prompting the most moves since 2013.

## Chuck Wepner: Honouring the real-life 'Rocky' who floored Muhammad Ali
 - [https://www.bbc.co.uk/sport/64392108?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/64392108?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:01:38+00:00
 - user: None

Chuck Wepner's most famous fight was a defeat, but his blood-soaked legend lives on in New Jersey.

## UK car production collapses to lowest for 66 years
 - [https://www.bbc.co.uk/news/business-64399748?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64399748?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-01-26 00:01:02+00:00
 - user: None

Car production in the UK continued to fall last year, lagging further behind the US and EU.
