# Source Le Monde - science, Source URL:https://www.lemonde.fr/en/science/rss_full.xml, Source language: en-US

## The space industry wants to clean up orbit paths cluttered with debris
 - [https://www.lemonde.fr/en/science/article/2023/01/26/the-space-industry-wants-to-clean-up-orbit-paths-cluttered-with-debris_6013180_10.html](https://www.lemonde.fr/en/science/article/2023/01/26/the-space-industry-wants-to-clean-up-orbit-paths-cluttered-with-debris_6013180_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-01-26 11:45:15+00:00
 - user: None

The space industry met in Paris in January and agreed to protect the most frequently used orbit paths, which are full of debris.

## The secrets of Roman concrete revealed
 - [https://www.lemonde.fr/en/science/article/2023/01/26/the-secrets-of-roman-concrete-revealed_6013134_10.html](https://www.lemonde.fr/en/science/article/2023/01/26/the-secrets-of-roman-concrete-revealed_6013134_10.html)
 - RSS feed: https://www.lemonde.fr/en/science/rss_full.xml
 - date published: 2023-01-26 04:25:20+00:00
 - user: None

A team of MIT researchers have unlocked the mystery behind the extraordinary resistance and durability of the material used by ancient builders that can 'last for thousands of years'.
