# Source ArsTechnica, Source URL:http://feeds.arstechnica.com/arstechnica/index/, Source language: en-US

## Deepfakes for scrawl: With handwriting synthesis, no pen is necessary
 - [https://arstechnica.com/?p=1912642](https://arstechnica.com/?p=1912642)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 21:39:01+00:00
 - user: None

Free neural network demo generates dynamic, downloadable handwriting on the fly.

## Q4 2022 was a disaster for smartphone sales, sees the largest-ever drop
 - [https://arstechnica.com/?p=1912768](https://arstechnica.com/?p=1912768)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 21:00:12+00:00
 - user: None

Phone sales plummeted 18 percent last quarter, 11 percent for the entire year.

## Antibiotic resistance induced by the widespread use of… antidepressants?
 - [https://arstechnica.com/?p=1912789](https://arstechnica.com/?p=1912789)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 20:44:03+00:00
 - user: None

Bacteria evolve drug resistance more readily when antidepressants are around.

## Do mechanical keyboards really need arrow keys?
 - [https://arstechnica.com/?p=1912689](https://arstechnica.com/?p=1912689)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 20:32:08+00:00
 - user: None

Angry Miao replaces bulky arrow buttons with a 2×0.5-inch capacitive touchpad.

## MSG probed over use of facial recognition to eject lawyers from show venues
 - [https://arstechnica.com/?p=1912764](https://arstechnica.com/?p=1912764)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 20:02:45+00:00
 - user: None

MSG says policy is legal, while NY AG alleges it may violate civil rights law.

## Microsoft said to be working on an overhauled File Explorer for Windows 11
 - [https://arstechnica.com/?p=1912645](https://arstechnica.com/?p=1912645)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 17:48:07+00:00
 - user: None

Microsoft added tabs to Explorer recently, but this redesign goes further.

## Get your first look at the OnePlus Pad, OnePlus’ first tablet
 - [https://arstechnica.com/?p=1912648](https://arstechnica.com/?p=1912648)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 17:34:45+00:00
 - user: None

We've got both official and unofficial renders of the supposedly 11.6-inch tablet.

## Meta will allow Donald Trump back on Facebook, sparking wave of criticism
 - [https://arstechnica.com/?p=1912669](https://arstechnica.com/?p=1912669)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 16:23:56+00:00
 - user: None

Critics warn Meta: Trump will continue to "spread lies and... incite violence."

## Airlines and cattle ranchers have beef with Google’s climate math
 - [https://arstechnica.com/?p=1912662](https://arstechnica.com/?p=1912662)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 16:08:35+00:00
 - user: None

Businesses with sales at stake are pushing back on Google's emissions estimates.

## By learning to hunt otters, wolves decimate a deer population
 - [https://arstechnica.com/?p=1912626](https://arstechnica.com/?p=1912626)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 15:15:41+00:00
 - user: None

On an Alaskan island, wolves adapted to hunt an unexpected aquatic prey.

## RSA’s demise from quantum attacks is very much exaggerated, expert says
 - [https://arstechnica.com/?p=1912611](https://arstechnica.com/?p=1912611)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-01-26 01:15:50+00:00
 - user: None

Expert says the focus on quantum attacks may distract us from more immediate threats.
