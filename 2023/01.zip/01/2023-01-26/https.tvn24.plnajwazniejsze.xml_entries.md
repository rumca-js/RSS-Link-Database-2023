# Source TNV24 Najważniejsze, Source URL:https://tvn24.pl/najwazniejsze.xml, Source language: pl-PL

## Podniebne podróże posłów. Oto liderzy
 - [https://tvn24.pl/biznes/z-kraju/loty-poslow-2022-kto-mial-najwiecej-podrozy-bilety-kolejowe-dane-sejmu-6681511?source=rss](https://tvn24.pl/biznes/z-kraju/loty-poslow-2022-kto-mial-najwiecej-podrozy-bilety-kolejowe-dane-sejmu-6681511?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 21:00:51+00:00
 - user: None

<img alt="Podniebne podróże posłów. Oto liderzy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-05k7p0-shutterstock1294964068-6681869/alternates/LANDSCAPE_1280" />
    Zestawienie udostępnione przez Kancelarię Sejmu.

## 18. urodziny "Szkła kontaktowego". Specjalne wydanie w Teatrze 6. piętro
 - [https://tvn24.pl/go/programy,7/szklo-kontaktowe--odcinki,10888/odcinek-1519,S00E1519,975585?source=rss](https://tvn24.pl/go/programy,7/szklo-kontaktowe--odcinki,10888/odcinek-1519,S00E1519,975585?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 21:00:00+00:00
 - user: None

<img alt="18. urodziny " src="https://tvn24.pl/najnowsze/cdn-zdjecie-j0rzc2-18-urodziny-szkla-kontaktowego-6681362/alternates/LANDSCAPE_1280" />
    Druga część spektaklu z okazji rocznicy jednego z najdłużej emitowanych programów w historii polskiej telewizji.

## Linette i Świątek. Role się odwróciły
 - [https://eurosport.tvn24.pl/role-si--odwr-ci-y---wi-tek-pospieszy-a-z-gratulacjami,1134351.html?source=rss](https://eurosport.tvn24.pl/role-si--odwr-ci-y---wi-tek-pospieszy-a-z-gratulacjami,1134351.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 20:50:00+00:00
 - user: None

<img alt="Linette i Świątek. Role się odwróciły" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyar98-linette-przegrala-w-polfinale-w-australii-z-aryna-sabalenka-6682137/alternates/LANDSCAPE_1280" />
    Magda Linette zbiera pochwały i gratulacje.

## Sejm przyjął nowelizację Kodeksu wyborczego
 - [https://tvn24.pl/polska/nowelizacja-kodeksu-wyborczego-sejm-przyjal-ustawe-wprowadzajaca-miedzy-innymi-centralny-rejestr-wyborcow-6681613?source=rss](https://tvn24.pl/polska/nowelizacja-kodeksu-wyborczego-sejm-przyjal-ustawe-wprowadzajaca-miedzy-innymi-centralny-rejestr-wyborcow-6681613?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 20:28:47+00:00
 - user: None

<img alt="Sejm przyjął nowelizację Kodeksu wyborczego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wziqmz-urna-wybory-shutterstock1490322299-6549711/alternates/LANDSCAPE_1280" />
    Przeciw noweli głosowało 220 posłów, za było natomiast 230.

## To już nie zwykły osioł, a hollywoodzka gwiazda. "On ma już 20 lat, jest otrzaskany"
 - [https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2301,S00E2301,976499?source=rss](https://tvn24.pl/go/programy,7/tylko-w-tvn24-go-odcinki,283316/odcinek-2301,S00E2301,976499?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 20:27:21+00:00
 - user: None

<img alt="To już nie zwykły osioł, a hollywoodzka gwiazda. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9iosze-takunio-6681703/alternates/LANDSCAPE_1280" />
    Takunio zagrał w filmie Jerzego Skolimowskiego "IO", który został nominowany do Oskara. Jego opiekunowie zdradzają kulisy sławy osła.

## Na co jeszcze stać Magdę Linette? Odważny typ jej dumnego taty
 - [https://eurosport.tvn24.pl/na-co-jeszcze-sta--magd--linette--odwa-ny-typ-jej-dumnego-taty,1134371.html?source=rss](https://eurosport.tvn24.pl/na-co-jeszcze-sta--magd--linette--odwa-ny-typ-jej-dumnego-taty,1134371.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 20:01:00+00:00
 - user: None

<img alt="Na co jeszcze stać Magdę Linette? Odważny typ jej dumnego taty" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0sy12c-26-1930-fpf-cl-0042jpg/alternates/LANDSCAPE_1280" />
    Pracowała na ten sukces 25 lat - powiedział w rozmowie z Anitą Werner w "Faktach po Faktach" na antenie TVN24.

## "Trzeba doprowadzić do tego, żeby póki co było w Polsce egzekwowane prawo, które obowiązuje"
 - [https://tvn24.pl/polska/zgwalconej-14-latce-odmowiono-aborcji-michal-kaminski-i-krzysztof-brejza-komentuja-6681474?source=rss](https://tvn24.pl/polska/zgwalconej-14-latce-odmowiono-aborcji-michal-kaminski-i-krzysztof-brejza-komentuja-6681474?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 19:54:09+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6sgqp3-26-2000-kropka-cl-0063-6681534/alternates/LANDSCAPE_1280" />
    Wicemarszałek Senatu Michał Kamiński (PSL-Koalicja Polska) i senator Krzysztof Brejza (KO) w "Kropce nad i".

## Szósta rocznica tragicznej śmierci Piotra Szczęsnego. "Jeśli nie my, to kto?"
 - [https://tvn24.pl/polska/piotr-szczesny-podpalil-sie-przed-palacem-kultury-i-nauki-szosta-rocznica-tragedii-6681203?source=rss](https://tvn24.pl/polska/piotr-szczesny-podpalil-sie-przed-palacem-kultury-i-nauki-szosta-rocznica-tragedii-6681203?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 19:16:47+00:00
 - user: None

<img alt="Szósta rocznica tragicznej śmierci Piotra Szczęsnego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjlcwg-na-niepolomickich-bloniach-pod-krakowem-odslonieto-tablice-pamiatkowa-piotra-szczesnego-6681486/alternates/LANDSCAPE_1280" />
    W mieście, z którego pochodził "Szary Człowiek", odsłonięto tablicę pamiątkową.

## Duże zmiany w podatku od spadków i darowizn. Sejm daje zielone światło
 - [https://tvn24.pl/biznes/najnowsze/duze-zmiany-w-podatku-od-spadkow-i-darowizn-sejm-daje-zielone-swiatlo-6681513?source=rss](https://tvn24.pl/biznes/najnowsze/duze-zmiany-w-podatku-od-spadkow-i-darowizn-sejm-daje-zielone-swiatlo-6681513?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 19:14:51+00:00
 - user: None

<img alt="Duże zmiany w podatku od spadków i darowizn. Sejm daje zielone światło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qepii7-poslowie-na-sali-plenarnej-sejmu-6681518/alternates/LANDSCAPE_1280" />
    To element tak zwanej ustawy deregulacyjnej.

## Duże zmiany w podatku od spadków i darowizn. Sejm daje zielone światło
 - [https://tvn24.pl/biznes/pieniadze/duze-zmiany-w-podatku-od-spadkow-i-darowizn-sejm-daje-zielone-swiatlo-6681513?source=rss](https://tvn24.pl/biznes/pieniadze/duze-zmiany-w-podatku-od-spadkow-i-darowizn-sejm-daje-zielone-swiatlo-6681513?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 19:14:51+00:00
 - user: None

<img alt="Duże zmiany w podatku od spadków i darowizn. Sejm daje zielone światło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qepii7-poslowie-na-sali-plenarnej-sejmu-6681518/alternates/LANDSCAPE_1280" />
    To element tak zwanej ustawy deregulacyjnej.

## "Jak Andrzej Duda został wybrany, to Lech Wałęsa powiedział, że to będzie dla niego dramat i nieszczęście"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2364,S00E2364,973448?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2364,S00E2364,973448?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 19:04:19+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x0hrpl-andrzej-duda-6681515/alternates/LANDSCAPE_1280" />
    Przed Andrzejem Dudą kolejna decyzja o przyszłości Sądu Najwyższego. Jakiego wyboru dokona teraz prezydent? Czy w przeszłości wywiązywał się z roli strażnika Konstytucji?

## Atomowy strzał fatalny w skutkach
 - [https://eurosport.tvn24.pl/atomowy-strza--fatalny-w-skutkach,1134326.html?source=rss](https://eurosport.tvn24.pl/atomowy-strza--fatalny-w-skutkach,1134326.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 18:17:00+00:00
 - user: None

<img alt="Atomowy strzał fatalny w skutkach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3t9hlr-arbiter-momentalnie-upadl-na-ziemie/alternates/LANDSCAPE_1280" />
    Boli od samego patrzenia.

## Miliony dla organizacji kierowanej przez partyjnego kolegę ministra
 - [https://tvn24.pl/biznes/z-kraju/konkurs-sport-dla-wszystkich-dotacje-z-ministerstwa-sportu-dla-organizacji-kierowanej-przez-posla-partii-republikanskiej-mieczyslawa-baszki-6681355?source=rss](https://tvn24.pl/biznes/z-kraju/konkurs-sport-dla-wszystkich-dotacje-z-ministerstwa-sportu-dla-organizacji-kierowanej-przez-posla-partii-republikanskiej-mieczyslawa-baszki-6681355?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 18:00:39+00:00
 - user: None

<img alt="Miliony dla organizacji kierowanej przez partyjnego kolegę ministra" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1ewxjg-pap202301040jr-6681370/alternates/LANDSCAPE_1280" />
    Wyniki konkursu w resorcie sportu.

## "Ciągle jesteśmy trzy kroki za Rosją"
 - [https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-48,S00E48,976492?source=rss](https://tvn24.pl/go/programy,7/rozmowy-na-szczycie-odcinki,692593/odcinek-48,S00E48,976492?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 17:44:04+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7t8vbs-leopard-2-w-akcji-6681442/alternates/LANDSCAPE_1280" />
    Niemcy zdecydowały o przekazaniu czołgów Leopard 2 Ukrainie. Deklarację złożyły też USA. Co oznaczają te decyzje?

## "Musiałam wiele przejść, zapamiętam ten turniej na całe życie"
 - [https://eurosport.tvn24.pl/-musia-am-wiele-przej----zapami-tam-ten-turniej-na-ca-e--ycie-,1134305.html?source=rss](https://eurosport.tvn24.pl/-musia-am-wiele-przej----zapami-tam-ten-turniej-na-ca-e--ycie-,1134305.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 17:37:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o67rn2-magda-linette-po-polfinale-australian-open/alternates/LANDSCAPE_1280" />
    Magda Linette w rozmowie Pawłem Kuwikiem z Eurosportu.

## Włoszka odmówiła przyjęcia złotego medalu. Niesamowita historia w mistrzostwach Europy
 - [https://eurosport.tvn24.pl/w-oszka-odm-wi-a-przyj-cia-z-otego-medalu--niesamowita-historia-w-mistrzostwach-europy,1134345.html?source=rss](https://eurosport.tvn24.pl/w-oszka-odm-wi-a-przyj-cia-z-otego-medalu--niesamowita-historia-w-mistrzostwach-europy,1134345.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 17:32:00+00:00
 - user: None

<img alt="Włoszka odmówiła przyjęcia złotego medalu. Niesamowita historia w mistrzostwach Europy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lwr93b-michela-carrara-to-wloska-biathlonistka/alternates/LANDSCAPE_1280" />
    "Moje zwycięstwo nie byłoby sprawiedliwe".

## Stany Zjednoczone uderzają w Grupę Wagnera
 - [https://tvn24.pl/swiat/usa-nakladaja-sankcje-na-grupe-wagnera-i-poszerzaja-dotychczasowe-restrykcje-dzialania-maja-pomoc-ukrainie-w-walce-z-rosja-6681301?source=rss](https://tvn24.pl/swiat/usa-nakladaja-sankcje-na-grupe-wagnera-i-poszerzaja-dotychczasowe-restrykcje-dzialania-maja-pomoc-ukrainie-w-walce-z-rosja-6681301?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 17:16:05+00:00
 - user: None

<img alt="Stany Zjednoczone uderzają w Grupę Wagnera" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ydxs4t-cwiczenia-rosyjskiego-wojska-6645725/alternates/LANDSCAPE_1280" />
    Mają utrudnić Kremlowi zdolność do uzbrajania swojej machiny wojennej.

## "Donosić na Ukraińca"? Uwaga, to nie jest pismo polskiego MSWiA
 - [https://konkret24.tvn24.pl/polityka/wojna-w-ukrainie-donosic-na-ukrainca-uwaga-to-nie-jest-pismo-polskiego-mswia-6681199?source=rss](https://konkret24.tvn24.pl/polityka/wojna-w-ukrainie-donosic-na-ukrainca-uwaga-to-nie-jest-pismo-polskiego-mswia-6681199?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:59:20+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-44oq5v-donies-na-ukrainca-to-nie-jest-pismo-polskiego-mswia-6681113/alternates/LANDSCAPE_1280" />
    Ta fałszywka jest kolejnym przykładem dezinformacji wymierzonej w relacje polsko-ukraińskie.

## Kurakowa piąta na półmetku
 - [https://eurosport.tvn24.pl/kurakowa-pi-ta-na-p--metku---stres-da--o-sobie-zna--,1134328.html?source=rss](https://eurosport.tvn24.pl/kurakowa-pi-ta-na-p--metku---stres-da--o-sobie-zna--,1134328.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:58:00+00:00
 - user: None

<img alt="Kurakowa piąta na półmetku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-eu1o05-kurakowa-jest-piata-po-programie-krotkim/alternates/LANDSCAPE_1280" />
    "Stres dał o sobie znać".

## Operator koparki znalazł psa przysypanego ziemią. "Okoliczności wskazują na nieszczęśliwy wypadek"
 - [https://tvn24.pl/krakow/zabierzow-krakow-operator-koparki-znalazl-psa-przysypanego-ziemia-okolicznosci-wskazuja-na-nieszczesliwy-wypadek-6646039?source=rss](https://tvn24.pl/krakow/zabierzow-krakow-operator-koparki-znalazl-psa-przysypanego-ziemia-okolicznosci-wskazuja-na-nieszczesliwy-wypadek-6646039?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:56:00+00:00
 - user: None

<img alt="Operator koparki znalazł psa przysypanego ziemią. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-carydk-psa-w-ziemi-znalazl-operator-koparki-6645920/alternates/LANDSCAPE_1280" />
    Na policję zgłosił się właściciel czworonoga.

## Nowa Linette. Ojciec tenisistki o życiowym sukcesie w Australian Open
 - [https://eurosport.tvn24.pl/nowa-linette--ojciec-tenisistki-o--yciowym-sukcesie-w-australian-open,1134340.html?source=rss](https://eurosport.tvn24.pl/nowa-linette--ojciec-tenisistki-o--yciowym-sukcesie-w-australian-open,1134340.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:44:00+00:00
 - user: None

<img alt="Nowa Linette. Ojciec tenisistki o życiowym sukcesie w Australian Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d5m9pn-tomasz-linette-podsumowal-wystep-corki-w-australian-open-2023/alternates/LANDSCAPE_1280" />
    Magda Linette nie zagra w finale Australian Open 2023, ale kończy imprezę jako jedna z największych wygranych.

## Amerykańskie media: Biden rozważa podróż do Europy. Możliwym celem Polska
 - [https://tvn24.pl/swiat/usa-prezydent-joe-biden-rozwaza-wizyte-w-europie-w-okolicach-rocznicy-rosyjskiej-inwazji-mozliwa-podroz-do-polski-donosza-media-6681364?source=rss](https://tvn24.pl/swiat/usa-prezydent-joe-biden-rozwaza-wizyte-w-europie-w-okolicach-rocznicy-rosyjskiej-inwazji-mozliwa-podroz-do-polski-donosza-media-6681364?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:42:54+00:00
 - user: None

<img alt="Amerykańskie media: Biden rozważa podróż do Europy. Możliwym celem Polska " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjnrii-joe-biden-6669165/alternates/LANDSCAPE_1280" />
    Wizyta ma się odbyć w okolicach rocznicy rosyjskiej inwazji na Ukrainę.

## Autobus zjechał do wody, ta momentalnie zalała pojazd. Panika na pokładzie
 - [https://tvn24.pl/swiat/turcja-autobus-wjechal-do-wody-w-miescie-malatya-nagranie-z-wypadku-6681340?source=rss](https://tvn24.pl/swiat/turcja-autobus-wjechal-do-wody-w-miescie-malatya-nagranie-z-wypadku-6681340?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:40:29+00:00
 - user: None

<img alt="Autobus zjechał do wody, ta momentalnie zalała pojazd. Panika na pokładzie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vylb7w-skl-k-6681332/alternates/LANDSCAPE_1280" />
    Moment wypadku tureckiego autobusu zarejestrowały kamery.

## Przywiązała psa do auta i ciągnęła po asfalcie
 - [https://tvn24.pl/wroclaw/swidnica-przywiazala-psa-do-auta-i-ciagnela-po-asfalcie-wyrok-6681263?source=rss](https://tvn24.pl/wroclaw/swidnica-przywiazala-psa-do-auta-i-ciagnela-po-asfalcie-wyrok-6681263?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:38:21+00:00
 - user: None

<img alt="Przywiązała psa do auta i ciągnęła po asfalcie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3jv6ib-pies-mial-otwarte-krwawiace-rany-5063536/alternates/LANDSCAPE_1280" />
    Usłyszała wyrok, do więzienia nie trafi.

## Policja o nowym tropie w sprawie zaginięcia Ani
 - [https://tvn24.pl/katowice/zaginiecie-ani-jalowiczor-policja-o-nowym-tropie-w-sprawie-znikniecia-6681329?source=rss](https://tvn24.pl/katowice/zaginiecie-ani-jalowiczor-policja-o-nowym-tropie-w-sprawie-znikniecia-6681329?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:23:34+00:00
 - user: None

<img alt="Policja o nowym tropie w sprawie zaginięcia Ani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c9unfb-ania-jalowiczor-zaginela-w-styczniu-1995-roku-6681324/alternates/LANDSCAPE_1280" />
    Potwierdza, że weryfikuje nowy wątek.

## Spłonął w swoim mieszkaniu w Moskwie. Kolejna zagadkowa śmierć w rosyjskich elitach
 - [https://tvn24.pl/swiat/rosja-media-w-pozarze-zginal-dmitrij-pawoczka-wysoki-ranga-menedzer-zwiazany-z-roskosmosem-kolejna-zagadkowa-smierc-w-rosyjskich-elitach-6681129?source=rss](https://tvn24.pl/swiat/rosja-media-w-pozarze-zginal-dmitrij-pawoczka-wysoki-ranga-menedzer-zwiazany-z-roskosmosem-kolejna-zagadkowa-smierc-w-rosyjskich-elitach-6681129?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:10:13+00:00
 - user: None

<img alt="Spłonął w swoim mieszkaniu w Moskwie. Kolejna zagadkowa śmierć w rosyjskich elitach " src="https://tvn24.pl/najnowsze/cdn-zdjecie-my0od7-shutterstock259330961-6681353/alternates/LANDSCAPE_1280" />
    Dmitrij Pawoczka zginął w pożarze mieszkania - podał portal Focus. Powodem miał być tlący się papieros.

## Nie ma dyrektora i jego mebli, ale jest nagroda i znikający dokument. Oskarżający go o mobbing pracownicy: jak to możliwe?
 - [https://tvn24.pl/premium/nie-ma-dyrektora-i-jego-mebli-ale-jest-nagroda-i-znikajacy-dokument-oskarzajacy-go-o-mobbing-pracownicy-jak-to-mozliwe-6647043?source=rss](https://tvn24.pl/premium/nie-ma-dyrektora-i-jego-mebli-ale-jest-nagroda-i-znikajacy-dokument-oskarzajacy-go-o-mobbing-pracownicy-jak-to-mozliwe-6647043?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 16:07:51+00:00
 - user: None

<img alt="Nie ma dyrektora i jego mebli, ale jest nagroda i znikający dokument. Oskarżający go o mobbing pracownicy: jak to możliwe?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-putzdm-iga-6681042/alternates/LANDSCAPE_1280" />
    Gdy skargi na niego badała komisja antymobbingowa, on akurat dostał nagrodę finansową za swoją pracę. A kilka tygodni później, gdy dyrektor Jacek Zawiśliński był już odsunięty od pełnienia obowiązków i jego sprawę badała prokuratura, szefujący mu kurator powołał go do zespołu decydującego o państwowych odznaczeniach. Teraz w Warszawie zasłaniają się "omyłką", ale podwładnych Zawiślińskiego to nie uspokaja.

## "Miś na miarę naszych możliwości"
 - [https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-joanna-tyrowicz-o-dezinflacji-to-przereklamowane-haslo-6681100?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-w-polsce-joanna-tyrowicz-o-dezinflacji-to-przereklamowane-haslo-6681100?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 15:33:09+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-thbaav-sklep-zakupy-zywnosc-jedzenie-handel-inflacja-6681169/alternates/LANDSCAPE_1280" />
    Członkini RPP o inflacji w Polsce.

## Zatankowała i ruszyła. Wyrwała dystrybutor
 - [https://tvn24.pl/polska/gorzow-wielkopolski-zapomniala-wyjac-weza-z-auta-wyrwala-dystrybutor-6679871?source=rss](https://tvn24.pl/polska/gorzow-wielkopolski-zapomniala-wyjac-weza-z-auta-wyrwala-dystrybutor-6679871?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 15:13:12+00:00
 - user: None

<img alt="Zatankowała i ruszyła. Wyrwała dystrybutor" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mzqgj1-stacja-paliw-zostal-zamknieta-do-czasu-naprawienia-dystrybutora-6681186/alternates/LANDSCAPE_1280" />
    Doszło do wycieku paliwa.

## Sąd złagodził karę dla zabójcy matki. Kobieta była wiceszefową prokuratury
 - [https://tvn24.pl/krakow/krakow-sad-zlagodzil-kare-dla-zabojcy-matki-kobieta-byla-wiceszefowa-prokuratury-6681194?source=rss](https://tvn24.pl/krakow/krakow-sad-zlagodzil-kare-dla-zabojcy-matki-kobieta-byla-wiceszefowa-prokuratury-6681194?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 15:10:00+00:00
 - user: None

<img alt="Sąd złagodził karę dla zabójcy matki. Kobieta była wiceszefową prokuratury" src="https://tvn24.pl/najnowsze/cdn-zdjecie2482b605b2fd2df8ffcf27258ebcacb8-mezczyzna-zostal-skazany-na-dozywocie-wideo-archiwalne-4818671/alternates/LANDSCAPE_1280" />
    Ma w więzieniu spędzić 25 lat, w 2019 roku sąd skazał go na dożywocie.

## "Szczepią ryby, by preparat trafił do ludzi". Wyjaśniamy, co pokazuje film
 - [https://konkret24.tvn24.pl/swiat/szczepia-ryby-by-preparat-trafil-do-ludzi-wyjasniamy-co-pokazuje-film-6669201?source=rss](https://konkret24.tvn24.pl/swiat/szczepia-ryby-by-preparat-trafil-do-ludzi-wyjasniamy-co-pokazuje-film-6669201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 15:04:34+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tyr397-wyjasniamy-co-przedstawia-popularne-nagranie-6679139/alternates/LANDSCAPE_1280" />
    Nagrania pokazujące szczepienie ryb w Hiszpanii wzbudziły pytania i wątpliwości polskich internautów.

## Dziecięca aktorka nie dostanie Złotej Maliny. Organizatorzy przepraszają 12-latkę
 - [https://tvn24.pl/kultura-i-styl/zlote-maliny-2023-nominacja-dla-12-letniej-ryan-kiery-armstrong-zostala-wycofana-organizatorzy-przepraszaja-6680937?source=rss](https://tvn24.pl/kultura-i-styl/zlote-maliny-2023-nominacja-dla-12-letniej-ryan-kiery-armstrong-zostala-wycofana-organizatorzy-przepraszaja-6680937?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 14:52:27+00:00
 - user: None

<img alt="Dziecięca aktorka nie dostanie Złotej Maliny. Organizatorzy przepraszają 12-latkę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oibcb7-ryan-kiera-armstrong-pap2022073020b-1-6681002/alternates/LANDSCAPE_1280" />
    "Czasami robisz rzeczy bez zastanowienia".

## Uciekło stado byków. Policja ostrzega kierowców
 - [https://tvn24.pl/poznan/niechanowo-zydowo-byki-uciekly-z-gospodarstwa-policja-apeluje-do-kierowcow-o-ostroznosc-6681139?source=rss](https://tvn24.pl/poznan/niechanowo-zydowo-byki-uciekly-z-gospodarstwa-policja-apeluje-do-kierowcow-o-ostroznosc-6681139?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 14:38:17+00:00
 - user: None

<img alt="Uciekło stado byków. Policja ostrzega kierowców" src="https://tvn24.pl/najnowsze/cdn-zdjecie-af3fzc-byk-uciekinier-6681126/alternates/LANDSCAPE_1280" />
    Na drodze krajowej numer 15 w okolicy Żydowa (Wielkopolska).

## Ważny dokument i wyższa pensja na rękę
 - [https://tvn24.pl/biznes/dla-pracownika/pit-2-2023-wyzsza-pensja-na-reke-dla-kogo-kiedy-i-jak-go-zlozyc-wzor-6680979?source=rss](https://tvn24.pl/biznes/dla-pracownika/pit-2-2023-wyzsza-pensja-na-reke-dla-kogo-kiedy-i-jak-go-zlozyc-wzor-6680979?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 14:33:29+00:00
 - user: None

<img alt="Ważny dokument i wyższa pensja na rękę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qxh38m-praca-biuro-shutterstock321792839-4691440/alternates/LANDSCAPE_1280" />
    Przypomina Ministerstwo Finansów.

## 14-latka zmarła wskutek wdychania dezodorantu
 - [https://tvn24.pl/swiat/wielka-brytania-14-latka-zmarla-wskutek-wdychania-dezodorantu-rodzice-dziewczynki-ostrzegaja-6679600?source=rss](https://tvn24.pl/swiat/wielka-brytania-14-latka-zmarla-wskutek-wdychania-dezodorantu-rodzice-dziewczynki-ostrzegaja-6679600?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 14:31:42+00:00
 - user: None

<img alt="14-latka zmarła wskutek wdychania dezodorantu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0l4mqi-shutterstock705757138-6679598/alternates/LANDSCAPE_1280" />
    Rodzice dziewczynki ostrzegają.

## Czteromiesięczna dziewczynka zraniona w szyję narzędziem "podobnym do śrubokrętu"
 - [https://tvn24.pl/krakow/powiat-tatrzanski-zaatakowal-czteromiesieczna-corke-partnerki-narzedziem-podobnym-do-srubokretu-uslyszal-zarzut-usilowania-zabojstwa-6680518?source=rss](https://tvn24.pl/krakow/powiat-tatrzanski-zaatakowal-czteromiesieczna-corke-partnerki-narzedziem-podobnym-do-srubokretu-uslyszal-zarzut-usilowania-zabojstwa-6680518?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:59:00+00:00
 - user: None

<img alt="Czteromiesięczna dziewczynka zraniona w szyję narzędziem " src="https://tvn24.pl/najnowsze/cdn-zdjecie-czywc2-dziecko-szpital-6644903/alternates/LANDSCAPE_1280" />
    Konkubent matki dziecka usłyszał zarzut usiłowania zabójstwa.

## Prawie 200 tysięcy widzów w 20 dni. Wielki sukces komedii "Na twoim miejscu"
 - [https://tvn24.pl/polska/prawie-200-tysiecy-widzow-w-20-dni-wielki-sukces-produkcji-tvn-warner-bros-discovery-pt-na-twoim-miejscu-6680969?source=rss](https://tvn24.pl/polska/prawie-200-tysiecy-widzow-w-20-dni-wielki-sukces-produkcji-tvn-warner-bros-discovery-pt-na-twoim-miejscu-6680969?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:50:30+00:00
 - user: None

<img alt="Prawie 200 tysięcy widzów w 20 dni. Wielki sukces komedii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qv9rt7-premiera-na-twoim-miejscu-juz-6-stycznia-6588954/alternates/LANDSCAPE_1280" />
    Ten weekend może być ostatnią szansą, by zobaczyć film w kinie.

## "Choć nie ma go z nami, to czujemy jego obecność". Trzecia rocznica śmierci Bryanta
 - [https://eurosport.tvn24.pl/-cho--nie-ma-go-z-nami--to-czujemy-jego-obecno-----trzecia-rocznica--mierci-bryanta,1134290.html?source=rss](https://eurosport.tvn24.pl/-cho--nie-ma-go-z-nami--to-czujemy-jego-obecno-----trzecia-rocznica--mierci-bryanta,1134290.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:46:26+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7d2kd8-kobe-bryant-mial-41-lat/alternates/LANDSCAPE_1280" />
    Legendarny koszykarz NBA zginął w katastrofie helikoptera w Kalifornii. Miał 41 lat.

## "Pierwsza prezes Sądu Najwyższego w sposób ewidentny łamie prawo". Zawiadomienie do prokuratury
 - [https://tvn24.pl/polska/pierwsza-prezes-sadu-najwyzszego-malgorzata-manowska-nie-przyjela-slubowania-od-lawnikow-koalicja-obywatelska-zawiadamia-prokurature-6680235?source=rss](https://tvn24.pl/polska/pierwsza-prezes-sadu-najwyzszego-malgorzata-manowska-nie-przyjela-slubowania-od-lawnikow-koalicja-obywatelska-zawiadamia-prokurature-6680235?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:45:27+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5tztnu-arkadiusz-myrcha-na-konferencji-prasowej-6680348/alternates/LANDSCAPE_1280" />
    Małgorzata Manowska nie przyjęła ślubowania od 26 ławników, których kandydatury zostały zgłoszone przez Komitet Obrony Demokracji.

## Podczas cofania mężczyzna potrącił dwuletniego syna, chłopiec zmarł. Jest wyrok w sprawie
 - [https://tvn24.pl/bialystok/gmina-kock-cofajac-nie-zauwazyl-ze-za-autem-znajdowal-sie-jego-dwuletni-syn-dziecko-zginelo-zapadl-wyrok-6680646?source=rss](https://tvn24.pl/bialystok/gmina-kock-cofajac-nie-zauwazyl-ze-za-autem-znajdowal-sie-jego-dwuletni-syn-dziecko-zginelo-zapadl-wyrok-6680646?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:33:36+00:00
 - user: None

<img alt="Podczas cofania mężczyzna potrącił dwuletniego syna, chłopiec zmarł. Jest wyrok w sprawie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8j1lx-53-letni-franciszek-b-uslyszal-wyrok-za-nieumyslne-spowodowanie-smierci-6680697/alternates/LANDSCAPE_1280" />
    Przyznał się do winy. Wystąpił do sądu o skazanie go bez przeprowadzenia postępowania dowodowego.

## "Zgódźcie się, aby prawo wyborcze było przygotowywane poza okresem wyborczym"
 - [https://tvn24.pl/polska/sejm-projekt-nowelizacji-kodeksu-wyborczego-ponownie-skierowany-do-komisji-6679884?source=rss](https://tvn24.pl/polska/sejm-projekt-nowelizacji-kodeksu-wyborczego-ponownie-skierowany-do-komisji-6679884?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:29:58+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u43ya1-sejm-zajmuje-sie-sprawozdaniem-komisji-dotyczacym-trzech-projektow-nowelizacji-kodeksu-wyborczego-6680099/alternates/LANDSCAPE_1280" />
    Projekt nowelizacji Kodeksu wyborczego został ponownie skierowany do komisji.

## Wielkie słowa Sabalenki o Linette. Wskazała kluczowy moment półfinału
 - [https://eurosport.tvn24.pl/wielkie-s-owa-sabalenki-o-linette--wskaza-a-kluczowy-moment-p--fina-u,1134298.html?source=rss](https://eurosport.tvn24.pl/wielkie-s-owa-sabalenki-o-linette--wskaza-a-kluczowy-moment-p--fina-u,1134298.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:29:05+00:00
 - user: None

<img alt="Wielkie słowa Sabalenki o Linette. Wskazała kluczowy moment półfinału" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n8jhek-sabalenka-po-awansie-do-finalu-australian-open/alternates/LANDSCAPE_1280" />
    Aryna Sabalenka pokonała Magdę Linette w meczu o finał Australian Open.

## Ile pieniędzy Wielka Orkiestra Świątecznej Pomocy zebrała przez 30 lat i ile sprzętu zakupiła
 - [https://tvn24.pl/wosp-2023/wosp-ile-pieniedzy-zebrala-przez-30-lat-i-ile-sprzetu-zakupila-6668618?source=rss](https://tvn24.pl/wosp-2023/wosp-ile-pieniedzy-zebrala-przez-30-lat-i-ile-sprzetu-zakupila-6668618?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:28:57+00:00
 - user: None

<img alt="Ile pieniędzy Wielka Orkiestra Świątecznej Pomocy zebrała przez 30 lat i ile sprzętu zakupiła " src="https://tvn24.pl/najnowsze/cdn-zdjecie-a85jdf-wosp-2022-6644131/alternates/LANDSCAPE_1280" />
    Rekord padł w 2022 roku.

## MEiN: wymagania na tegorocznych maturach będą obniżone
 - [https://tvn24.pl/polska/matura-2023-obnizone-wymagania-minister-edukacji-podalszczegoly-6680594?source=rss](https://tvn24.pl/polska/matura-2023-obnizone-wymagania-minister-edukacji-podalszczegoly-6680594?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:21:25+00:00
 - user: None

<img alt="MEiN: wymagania na tegorocznych maturach będą obniżone " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y1qpu3-matura03-4601483/alternates/LANDSCAPE_1280" />
    Zapowiada minister edukacji i nauki Przemysław Czarnek.

## W aucie podczas kontroli znaleźli torbę z kosztownościami. Nie wiedzieli jeszcze o obrabowanym sejfie
 - [https://tvn24.pl/polska/bisztynek-w-aucie-podczas-kontroli-drogowej-znalezli-torbe-z-bizuteria-wtedy-jeszcze-nie-wiedzieli-o-obrabowanym-sejfie-6679664?source=rss](https://tvn24.pl/polska/bisztynek-w-aucie-podczas-kontroli-drogowej-znalezli-torbe-z-bizuteria-wtedy-jeszcze-nie-wiedzieli-o-obrabowanym-sejfie-6679664?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:10:31+00:00
 - user: None

<img alt="W aucie podczas kontroli znaleźli torbę z kosztownościami. Nie wiedzieli jeszcze o obrabowanym sejfie" src="https://tvn24.pl/pomorze/cdn-zdjecie-u7w4do-z-sejfu-zniknely-kosztownosci-o-wartosci-570-tys-zl-podejrzani-wpadli-przez-kontrole-drogowa-6679850/alternates/LANDSCAPE_1280" />
    Zniknęły funty, dolary i biżuteria o łącznej wartości 570 tysięcy złotych.

## Przygotowują szkatułki na biżuterię, pudełka na bibeloty i świeczniki. "Są wzruszeni"
 - [https://tvn24.pl/wosp-2023/wosp-2023-dolny-slask-seniorzy-z-rybnicy-lesnej-graja-z-orkiestra-6679890?source=rss](https://tvn24.pl/wosp-2023/wosp-2023-dolny-slask-seniorzy-z-rybnicy-lesnej-graja-z-orkiestra-6679890?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:10:09+00:00
 - user: None

<img alt="Przygotowują szkatułki na biżuterię, pudełka na bibeloty i świeczniki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-icx67o-wosp-2023-seniorzy-z-rybnicy-lesnej-graja-z-orkiestra-6679840/alternates/LANDSCAPE_1280" />
    Mieszkańcy Domu Seniora Jantar w dolnośląskiej Rybnicy Leśnej (pow. wałbrzyski) grają z WOŚP.

## Ktoś ostrzelał trzy tramwaje na tej samej trasie
 - [https://tvn24.pl/poznan/poznan-strzelecka-ktos-ostrzelal-trzy-tramwaje-6680198?source=rss](https://tvn24.pl/poznan/poznan-strzelecka-ktos-ostrzelal-trzy-tramwaje-6680198?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:03:52+00:00
 - user: None

<img alt="Ktoś ostrzelał trzy tramwaje na tej samej trasie" src="https://tvn24.pl/najnowsze/cdn-zdjecie0e505e9af5e5ee494875f075cf9b5b69-policja-probuje-schwytac-strzelca-1020020/alternates/LANDSCAPE_1280" />
    W Poznaniu.

## Dzielnica przejęła stary pawilon. Wyremontuje go i zmieni funkcję
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bielany-miejsce-aktywnosci-lokalnej-powstanie-przy-kasprowicza-6679857?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-bielany-miejsce-aktywnosci-lokalnej-powstanie-przy-kasprowicza-6679857?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 13:00:39+00:00
 - user: None

<img alt="Dzielnica przejęła stary pawilon. Wyremontuje go i zmieni funkcję" src="https://tvn24.pl/krakow/cdn-zdjecie-1rdwc5-pawilon-przy-ulicy-kasprowicza-14-6679860/alternates/LANDSCAPE_1280" />
    Skorzystają mieszkańcy.

## Zostawiła nowo narodzone dziecko na brzegu rzeki i odjechała. Kobiecie grozi 27 lat więzienia
 - [https://tvn24.pl/swiat/usa-zostawila-nowo-narodzone-dziecko-na-brzegu-rzeki-i-odjechala-kobiecie-grozi-27-lat-wiezienia-6679686?source=rss](https://tvn24.pl/swiat/usa-zostawila-nowo-narodzone-dziecko-na-brzegu-rzeki-i-odjechala-kobiecie-grozi-27-lat-wiezienia-6679686?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:59:42+00:00
 - user: None

<img alt="Zostawiła nowo narodzone dziecko na brzegu rzeki i odjechała. Kobiecie grozi 27 lat więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ibd731-mississippi-river-rzeka-usa-brzeg-rzeki-shutterstock363111605-6679768/alternates/LANDSCAPE_1280" />
    Oskarżona zeznała, że "robiła wiele głupich rzeczy".

## Marian Banaś: miliardy złotych Orlenu są poza kontrolą NIK
 - [https://tvn24.pl/biznes/z-kraju/prezes-nik-marian-banas-na-komisji-do-spraw-kontroli-panstwowej-o-pkn-orlen-6679858?source=rss](https://tvn24.pl/biznes/z-kraju/prezes-nik-marian-banas-na-komisji-do-spraw-kontroli-panstwowej-o-pkn-orlen-6679858?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:53:33+00:00
 - user: None

<img alt="Marian Banaś: miliardy złotych Orlenu są poza kontrolą NIK" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-k429bo-marian-banas-podczas-posiedzenia-komisji-6680409/alternates/LANDSCAPE_1280" />
    Mówił podczas posiedzenia sejmowej komisji.

## Paweł Pajewski nie żyje. Sportowiec, trener, nauczyciel i dyrektor szkoły w Mogielnicy miał 45 lat
 - [https://tvn24.pl/polska/pawel-pajewski-nie-zyje-dyrektor-szkoly-podstawowej-w-mogielnicy-mial-45-lat-6679877?source=rss](https://tvn24.pl/polska/pawel-pajewski-nie-zyje-dyrektor-szkoly-podstawowej-w-mogielnicy-mial-45-lat-6679877?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:43:14+00:00
 - user: None

<img alt="Paweł Pajewski nie żyje. Sportowiec, trener, nauczyciel i dyrektor szkoły w Mogielnicy miał 45 lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mwxg57-pawel-pajewski-nie-zyje-6679866/alternates/LANDSCAPE_1280" />
    "Nie możemy pozwolić sobie na to, żeby rezygnować z walki" - mówił w TVN24.

## Zmiana na czele japońskiego giganta. Wnuk założyciela odchodzi
 - [https://tvn24.pl/biznes/moto/toyota-zmiana-prezesa-akio-toyoda-ustepuje-zastapi-go-koji-sato-6679702?source=rss](https://tvn24.pl/biznes/moto/toyota-zmiana-prezesa-akio-toyoda-ustepuje-zastapi-go-koji-sato-6679702?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:36:46+00:00
 - user: None

<img alt="Zmiana na czele japońskiego giganta. Wnuk założyciela odchodzi" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-d228k9-akio-toyoda-6679698/alternates/LANDSCAPE_1280" />
    Podano nazwisko następcy.

## Koniec pięknego snu Linette. Polka poza finałem Australian Open
 - [https://eurosport.tvn24.pl/koniec-pi-knego-snu-linette--polka-poza-fina-em-australian-open,1134296.html?source=rss](https://eurosport.tvn24.pl/koniec-pi-knego-snu-linette--polka-poza-fina-em-australian-open,1134296.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:25:53+00:00
 - user: None

<img alt="Koniec pięknego snu Linette. Polka poza finałem Australian Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-34vuvr-magda-linette/alternates/LANDSCAPE_1280" />
    O tytuł Aryna Sabalenka zagra z reprezentującą Kazachstan Jeleną Rybakiną.

## Planetoida przeleci dziś bardzo blisko Ziemi
 - [https://tvn24.pl/tvnmeteo/nauka/nasa-planetoida-przeleci-dzis-bardzo-blisko-ziemi-6679823?source=rss](https://tvn24.pl/tvnmeteo/nauka/nasa-planetoida-przeleci-dzis-bardzo-blisko-ziemi-6679823?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:11:55+00:00
 - user: None

<img alt="Planetoida przeleci dziś bardzo blisko Ziemi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cuzxn5-planetoida-przemknie-obok-ziemi-zdjecie-pogladowe-5715221/alternates/LANDSCAPE_1280" />
    Przemknie nad Ameryką Południową na wysokości 3600 kilometrów.

## Tej nocy planetoida przeleci bardzo blisko Ziemi
 - [https://tvn24.pl/tvnmeteo/nauka/nasa-planetoida-przeleci-bardzo-blisko-ziemi-6679823?source=rss](https://tvn24.pl/tvnmeteo/nauka/nasa-planetoida-przeleci-bardzo-blisko-ziemi-6679823?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:11:55+00:00
 - user: None

<img alt="Tej nocy planetoida przeleci bardzo blisko Ziemi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cuzxn5-planetoida-przemknie-obok-ziemi-zdjecie-pogladowe-5715221/alternates/LANDSCAPE_1280" />
    Przemknie nad Ameryką Południową na wysokości 3600 kilometrów.

## Ciężarówka przejechała pieszego w zatoczce autobusowej. Mężczyzna zginął na miejscu
 - [https://tvn24.pl/bialystok/konskowola-kierowca-ciezarowki-cofal-na-zatoczce-autobusowej-smiertelnie-potracil-pieszego-6679727?source=rss](https://tvn24.pl/bialystok/konskowola-kierowca-ciezarowki-cofal-na-zatoczce-autobusowej-smiertelnie-potracil-pieszego-6679727?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:09:59+00:00
 - user: None

<img alt="Ciężarówka przejechała pieszego w zatoczce autobusowej. Mężczyzna zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bqu32w-mezczyzna-zginal-na-miejscu-6679749/alternates/LANDSCAPE_1280" />
    Policja ustala szczegóły zdarzenia. Kierowca był trzeźwy.

## Strzelał do krzyża, uszkodził figurkę Chrystusa. "Nie potrafił powiedzieć, dlaczego"
 - [https://tvn24.pl/poznan/krzepielow-ostrzelal-krzyz-uszkodzil-chrystusa-zarzuty-dla-30-latka-6679814?source=rss](https://tvn24.pl/poznan/krzepielow-ostrzelal-krzyz-uszkodzil-chrystusa-zarzuty-dla-30-latka-6679814?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:06:38+00:00
 - user: None

<img alt="Strzelał do krzyża, uszkodził figurkę Chrystusa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pgolu1-uszkodzona-figura-chrystusa-6679820/alternates/LANDSCAPE_1280" />
    Usłyszał zarzuty, przyznał się do winy.

## Co za emocje. Sabalenkę usłyszało całe Melbourne
 - [https://eurosport.tvn24.pl/co-za-emocje--sabalenk--us-ysza-o-ca-e-melbourne,1134294.html?source=rss](https://eurosport.tvn24.pl/co-za-emocje--sabalenk--us-ysza-o-ca-e-melbourne,1134294.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 12:05:38+00:00
 - user: None

<img alt="Co za emocje. Sabalenkę usłyszało całe Melbourne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c8k5nq-aryna-sabalenka-podczas-polfinalu-australian-open/alternates/LANDSCAPE_1280" />
    Aryna Sabalenka niezwykle nerwowo rozpoczęła czwartkowy półfinał Australian Open z Magdą Linette.

## Chińska aplikacja na cenzurowanym. Ostrzeżenie kanadyjskiego wywiadu
 - [https://tvn24.pl/biznes/ze-swiata/kanada-tiktok-na-cenzurowanym-ostrzezenie-kanadyjskiego-wywiadu-6679574?source=rss](https://tvn24.pl/biznes/ze-swiata/kanada-tiktok-na-cenzurowanym-ostrzezenie-kanadyjskiego-wywiadu-6679574?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:57:14+00:00
 - user: None

<img alt="Chińska aplikacja na cenzurowanym. Ostrzeżenie kanadyjskiego wywiadu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rkvu0p-tiktok-5453552/alternates/LANDSCAPE_1280" />
    Apel do użytkowników.

## "Wyobraźmy sobie, że tamten scenariusz udałby się Rosji"
 - [https://tvn24.pl/polska/wojna-w-ukrainie-pomoc-z-zachodu-premier-mateusz-morawiecki-na-konferencji-prasowej-z-unijnym-komisarzem-i-ambasadorem-ukrainy-6679431?source=rss](https://tvn24.pl/polska/wojna-w-ukrainie-pomoc-z-zachodu-premier-mateusz-morawiecki-na-konferencji-prasowej-z-unijnym-komisarzem-i-ambasadorem-ukrainy-6679431?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:57:10+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yqss8h-komisarz-ue-ds-zarzadzania-kryzysowego-janez-lenarczicz-premier-mateusz-morawiecki-ambasador-ukrainy-w-polsce-wasyl-zwarycz-6679459/alternates/LANDSCAPE_1280" />
    Premier Mateusz Morawiecki na wspólnej konferencji prasowej z unijnym komisarzem ds. zarządzania kryzysowego Janezem Lenarcziczem i ambasadorem Ukrainy Wasylem Zwaryczem.

## Prowadził audycję radiową po pijanemu. Policja zatrzymała go w aucie przed rozgłośnią
 - [https://tvn24.pl/bialystok/bialystok-byl-pijany-prowadzil-audycje-policja-zatrzymala-go-po-tym-jak-podjechal-autem-przed-rozglosnie-6679602?source=rss](https://tvn24.pl/bialystok/bialystok-byl-pijany-prowadzil-audycje-policja-zatrzymala-go-po-tym-jak-podjechal-autem-przed-rozglosnie-6679602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:51:06+00:00
 - user: None

<img alt="Prowadził audycję radiową po pijanemu. Policja zatrzymała go w aucie przed rozgłośnią" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s1a1nq-dziennikarz-prowadzil-po-pijanemu-audycje-zdjecie-ilustracyjne-6679635/alternates/LANDSCAPE_1280" />
    Dziennikarz miał w organizmie 2,5 promila alkoholu.

## Jest poprawka PiS do nowelizacji ustawy wiatrakowej. "Poważne pogorszenie warunków"
 - [https://tvn24.pl/biznes/z-kraju/ustawa-wiatrakowa-10h-pis-zglosilo-poprawke-odleglosc-wiatrakow-od-zabudowan-ma-byc-wieksza-niz-proponowano-6679713?source=rss](https://tvn24.pl/biznes/z-kraju/ustawa-wiatrakowa-10h-pis-zglosilo-poprawke-odleglosc-wiatrakow-od-zabudowan-ma-byc-wieksza-niz-proponowano-6679713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:46:47+00:00
 - user: None

<img alt="Jest poprawka PiS do nowelizacji ustawy wiatrakowej. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-s0dft1-marek-suski-6679780/alternates/LANDSCAPE_1280" />
    Poprawka budzi kontrowersje.

## Silnik samolotu "wessał" kobietę na lotnisku. Są wstępne wyniki śledztwa
 - [https://tvn24.pl/swiat/usa-silnik-samolotu-wessal-kobiete-na-lotnisku-raport-ujawnia-wstepne-wyniki-dochodzenia-6679448?source=rss](https://tvn24.pl/swiat/usa-silnik-samolotu-wessal-kobiete-na-lotnisku-raport-ujawnia-wstepne-wyniki-dochodzenia-6679448?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:41:45+00:00
 - user: None

<img alt="Silnik samolotu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wm9kh3-silnik-samolot-lotnisko-shutterstock-6584007/alternates/LANDSCAPE_1280" />
    Dochodzenie prowadzi Narodowa Rada Bezpieczeństwa Transportu (NTSB).

## Tajemnica "bezimiennego" mężczyzny z Dorset rozwiązana
 - [https://tvn24.pl/swiat/wielka-brytania-tajemnica-bezimiennego-mezczyzny-z-dorset-rozwiazana-6679557?source=rss](https://tvn24.pl/swiat/wielka-brytania-tajemnica-bezimiennego-mezczyzny-z-dorset-rozwiazana-6679557?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:30:05+00:00
 - user: None

<img alt="Tajemnica " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c7yjw9-policja-w-dorset-anglia-6679701/alternates/LANDSCAPE_1280" />
    Mężczyznę odnaleziono we wrześniu na plaży.

## Ukraińska flaga zamiast polskiej w ambasadzie Polski w Oslo?
 - [https://konkret24.tvn24.pl/polska/brak-polskiej-flagi-na-w-ambasadzie-polski-w--6668477?source=rss](https://konkret24.tvn24.pl/polska/brak-polskiej-flagi-na-w-ambasadzie-polski-w--6668477?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:29:04+00:00
 - user: None

<img alt="Ukraińska flaga zamiast polskiej w ambasadzie Polski w Oslo?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iz3yja-wpis-o-ambasadzie-polski-w-oslo-rzekomo-pozbawionej-polskiej-flagi-6668682/alternates/LANDSCAPE_1280" />
    Sprawdzamy zdjęcie krążące w mediach społecznościowych.

## Symboliczny triumf Radwańskiej w Melbourne. Wygrała turniej legend
 - [https://eurosport.tvn24.pl/symboliczny-triumf-radwa-skiej-w-melbourne--wygra-a-turniej-legend,1134292.html?source=rss](https://eurosport.tvn24.pl/symboliczny-triumf-radwa-skiej-w-melbourne--wygra-a-turniej-legend,1134292.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:28:21+00:00
 - user: None

<img alt="Symboliczny triumf Radwańskiej w Melbourne. Wygrała turniej legend" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ellme5-agnieszka-radwanska-i-daniela-hantuchova-wygraly-turniej-legend/alternates/LANDSCAPE_1280" />
    Towarzyszący wielkoszlemowemu Australian Open.

## Wjechał nieprzepisowo na rondo i "powinien przeprosić". Zamiast tego zajechał drogę. Nagranie
 - [https://tvn24.pl/katowice/tarnowskie-gory-kierowca-ciezarowki-wjechal-na-rondo-a-potem-wyjechal-z-zatoczki-autobusowej-tuz-przed-autem-osobowym-nagranie-6679362?source=rss](https://tvn24.pl/katowice/tarnowskie-gory-kierowca-ciezarowki-wjechal-na-rondo-a-potem-wyjechal-z-zatoczki-autobusowej-tuz-przed-autem-osobowym-nagranie-6679362?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:19:12+00:00
 - user: None

<img alt="Wjechał nieprzepisowo na rondo i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z4npmw-kierowca-ciezarowki-zajezdzal-innemu-kierowcy-droge-6679540/alternates/LANDSCAPE_1280" />
    Kierowca ciężarówki nie przyznał się do wykroczeń, dlatego policja skierowała do sądu wniosek o ukaranie.

## Wjechał nieprzepisowo na rondo i "powinien przeprosić". Zamiast tego zajechał drogę. Nagranie
 - [https://tvn24.pl/katowice/wieszowa-kierowca-ciezarowki-wjechal-na-rondo-a-potem-wyjechal-z-zatoczki-autobusowej-tuz-przed-autem-osobowym-nagranie-6679362?source=rss](https://tvn24.pl/katowice/wieszowa-kierowca-ciezarowki-wjechal-na-rondo-a-potem-wyjechal-z-zatoczki-autobusowej-tuz-przed-autem-osobowym-nagranie-6679362?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:19:12+00:00
 - user: None

<img alt="Wjechał nieprzepisowo na rondo i " src="https://tvn24.pl/najnowsze/cdn-zdjecie-z4npmw-kierowca-ciezarowki-zajezdzal-innemu-kierowcy-droge-6679540/alternates/LANDSCAPE_1280" />
    Kierowca ciężarówki nie przyznał się do wykroczeń, dlatego policja skierowała do sądu wniosek o ukaranie.

## Niemieckie czołgi dotrą "w odpowiednim czasie"
 - [https://tvn24.pl/swiat/niemcy-minister-obrony-boris-pistorius-kijow-otrzyma-leopardy-2-do-konca-pierwszego-kwartalu-6679596?source=rss](https://tvn24.pl/swiat/niemcy-minister-obrony-boris-pistorius-kijow-otrzyma-leopardy-2-do-konca-pierwszego-kwartalu-6679596?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:15:52+00:00
 - user: None

<img alt="Niemieckie czołgi dotrą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5tgclj-leopard-2-6679617/alternates/LANDSCAPE_1280" />
    Poinformował minister Boris Pistorius.

## Jedni są za kratkami, po innych słuch zaginął. "Jeśli to oglądacie, zostałam już zabrana"
 - [https://tvn24.pl/swiat/chiny-protestowali-przeciw-polityce-covidowej-human-rights-watch-niektorzy-sa-nadal-w-aresztach-6679542?source=rss](https://tvn24.pl/swiat/chiny-protestowali-przeciw-polityce-covidowej-human-rights-watch-niektorzy-sa-nadal-w-aresztach-6679542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 11:09:59+00:00
 - user: None

<img alt="Jedni są za kratkami, po innych słuch zaginął. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qijv1y-protesty-w-chinach-6679523/alternates/LANDSCAPE_1280" />
    Alarmuje HRW.

## Kosztowały miliardy, mogą pozostać na dłużej. Przedstawiciel banków: skrajna nieodpowiedzialność
 - [https://tvn24.pl/biznes/z-kraju/koszt-wakacji-kredytowych-dla-bankow-pomysl-przedluzenia-wakacji-kredytowych-komentuje-krzysztof-pietraszkiewicz-prezes-zbp-6679394?source=rss](https://tvn24.pl/biznes/z-kraju/koszt-wakacji-kredytowych-dla-bankow-pomysl-przedluzenia-wakacji-kredytowych-komentuje-krzysztof-pietraszkiewicz-prezes-zbp-6679394?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:58:54+00:00
 - user: None

<img alt="Kosztowały miliardy, mogą pozostać na dłużej. Przedstawiciel banków: skrajna nieodpowiedzialność" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qtmgyz-pieniadze-6555068/alternates/LANDSCAPE_1280" />
    Wakacje kredytowe miały obowiązywać do końca tego roku.

## Małżeństwo miało sfingować swoją śmierć. On nie chciał płacić kontrahentom, a ona iść do więzienia
 - [https://tvn24.pl/bialystok/suwalki-nie-placil-kontrahentom-sfingowal-wlasna-smierc-zrobila-to-tez-jego-zona-on-faktycznie-juz-nie-zyje-6679177?source=rss](https://tvn24.pl/bialystok/suwalki-nie-placil-kontrahentom-sfingowal-wlasna-smierc-zrobila-to-tez-jego-zona-on-faktycznie-juz-nie-zyje-6679177?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:47:06+00:00
 - user: None

<img alt="Małżeństwo miało sfingować swoją śmierć. On nie chciał płacić kontrahentom, a ona iść do więzienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3dd93p-akty-zgonow-zostaly-uzyskane-na-podstawie-sfalszowanych-dokumentow-lekarskich-zdjecie-ilustracyjne-6679191/alternates/LANDSCAPE_1280" />
    Oboje chcieli też wyłudzić pieniądze z polisy na życie.

## Prognoza pogody na 31. Finał WOŚP. Miejscami może mocno sypnąć śniegiem
 - [https://tvn24.pl/tvnmeteo/pogoda/wosp-2023-prognoza-pogody-pogoda-na-31-final-wosp-wielka-orkiestra-swiatecznej-pomocy-6679349?source=rss](https://tvn24.pl/tvnmeteo/pogoda/wosp-2023-prognoza-pogody-pogoda-na-31-final-wosp-wielka-orkiestra-swiatecznej-pomocy-6679349?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:47:00+00:00
 - user: None

<img alt="Prognoza pogody na 31. Finał WOŚP. Miejscami może mocno sypnąć śniegiem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vh3k4c-wosp-2023-6679562/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę na niedzielę 29 stycznia.

## Zajechał swojej partnerce drogę i ją zabił, na oczach dwuletniej córeczki
 - [https://tvn24.pl/poznan/kopydlowek-zabil-partnerke-na-oczach-coreczki-uslyszal-wyrok-6679554?source=rss](https://tvn24.pl/poznan/kopydlowek-zabil-partnerke-na-oczach-coreczki-uslyszal-wyrok-6679554?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:45:20+00:00
 - user: None

<img alt="Zajechał swojej partnerce drogę i ją zabił, na oczach dwuletniej córeczki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kc8cgs-do-zdarzenia-doszlo-na-lokalnej-drodze-w-okolicach-kopydlowka-4749053/alternates/LANDSCAPE_1280" />
    Został skazany na 25 lat więzienia.

## PiS i Koalicja Obywatelska "idą łeb w łeb". Najnowszy sondaż
 - [https://tvn24.pl/polska/sondaz-prawo-i-sprawiedliwosc-i-koalicja-obywatelska-na-czele-ile-partii-w-sejmie-6679370?source=rss](https://tvn24.pl/polska/sondaz-prawo-i-sprawiedliwosc-i-koalicja-obywatelska-na-czele-ile-partii-w-sejmie-6679370?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:44:57+00:00
 - user: None

<img alt="PiS i Koalicja Obywatelska " id="id" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ntmtkv-sejm-6679454/alternates/LANDSCAPE_1280" />
    Został przeprowadzony przez Kantar Public.

## "Uderzenie endorfin". Agata Adamek i Joanna Jabłczyńska zapraszają do morsowania
 - [https://tvn24.pl/wosp-2023/wosp-2023-aukcje-agaty-adamek-i-joanny-jablczynskiej-wspolne-morsowanie-6679277?source=rss](https://tvn24.pl/wosp-2023/wosp-2023-aukcje-agaty-adamek-i-joanny-jablczynskiej-wspolne-morsowanie-6679277?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:42:34+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-640uzd-wosp-allegro-6679361/alternates/LANDSCAPE_1280" />
    31. Finał Wielkiej Orkiestry Świątecznej Pomocy w najbliższą niedzielę.

## 87-latek stracił cały majątek przez oszustkę z aplikacji randkowej
 - [https://tvn24.pl/swiat/usa-87-latek-stracil-caly-majatek-przez-oszustke-z-aplikacji-randkowej-6679210?source=rss](https://tvn24.pl/swiat/usa-87-latek-stracil-caly-majatek-przez-oszustke-z-aplikacji-randkowej-6679210?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:30:55+00:00
 - user: None

<img alt="87-latek stracił cały majątek przez oszustkę z aplikacji randkowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rj8itk-36-letnia-peaches-stergo-z-florydy-6679255/alternates/LANDSCAPE_1280" />
    Był oszukiwany przez kobietę młodszą o ponad 50 lat.

## Najważniejsze miały być pierwsze dwie doby. Później już tylko 24 godziny. Marcelinka walczyła 16
 - [https://tvn24.pl/premium/wosp-2023-marcelinka-zmarla-na-sepse-6644697?source=rss](https://tvn24.pl/premium/wosp-2023-marcelinka-zmarla-na-sepse-6644697?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:29:33+00:00
 - user: None

<img alt="Najważniejsze miały być pierwsze dwie doby. Później już tylko 24 godziny. Marcelinka walczyła 16" src="https://tvn24.pl/najnowsze/cdn-zdjecie-oqehdi-marcelina-zmarla-na-sepse-6644880/alternates/LANDSCAPE_1280" />
    "To mała blondyneczka o niebieskich oczach, wiecznie uśmiechnięta".

## Rybakina pierwszą finalistką Australian Open
 - [https://eurosport.tvn24.pl/rybakina-pierwsz--finalistk--australian-open,1134283.html?source=rss](https://eurosport.tvn24.pl/rybakina-pierwsz--finalistk--australian-open,1134283.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:27:48+00:00
 - user: None

<img alt="Rybakina pierwszą finalistką Australian Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ovpnrk-jelena-rybakina/alternates/LANDSCAPE_1280" />
    W drugim meczu 1/2 finału Magda Linette zmierzy się z Aryną Sabalenką.

## Mimo wzrostu przychodów, będą zwalniać. Wielkie cięcia
 - [https://tvn24.pl/biznes/ze-swiata/usa-ibm-planuje-zwolnienie-3900-pracownikow-6679303?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-ibm-planuje-zwolnienie-3900-pracownikow-6679303?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:22:59+00:00
 - user: None

<img alt="Mimo wzrostu przychodów, będą zwalniać. Wielkie cięcia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5g1vb0-shutterstock2153601127-6679378/alternates/LANDSCAPE_1280" />
    U kolejnego giganta z branży IT.

## Azarenka w koszulce słynnego klubu
 - [https://eurosport.tvn24.pl/azarenka-w-koszulce-s-ynnego-klubu---jestem-teraz-pi-karsk--mam--,1134288.html?source=rss](https://eurosport.tvn24.pl/azarenka-w-koszulce-s-ynnego-klubu---jestem-teraz-pi-karsk--mam--,1134288.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:19:44+00:00
 - user: None

<img alt="Azarenka w koszulce słynnego klubu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fv13lg-wiktoria-azarenka/alternates/LANDSCAPE_1280" />
    Robi to dla swojego 7-letniego syna.

## Samoloty francuskie, rosyjskie i rodzime, a także "ludzkie piramidy". Indie świętują
 - [https://tvn24.pl/swiat/indie-dzien-republiki-kolorowa-parada-na-glownej-alei-delhi-6679414?source=rss](https://tvn24.pl/swiat/indie-dzien-republiki-kolorowa-parada-na-glownej-alei-delhi-6679414?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:19:30+00:00
 - user: None

<img alt="Samoloty francuskie, rosyjskie i rodzime, a także " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rp81q2-pokazy-akrobatyczne-z-okazji-dnia-republiki-6679434/alternates/LANDSCAPE_1280" />
    W uroczystościach udział wziął także prezydent Egiptu.

## Leżał na tylnym fotelu w aucie, nie dawał oznak życia. Śledczy sprawdzają, jak i dlaczego zmarł
 - [https://tvn24.pl/krakow/rzeszow-policja-ustala-okolicznosci-smierci-mezczyzny-ktorego-cialo-znaleziono-w-samochodzie-6679341?source=rss](https://tvn24.pl/krakow/rzeszow-policja-ustala-okolicznosci-smierci-mezczyzny-ktorego-cialo-znaleziono-w-samochodzie-6679341?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 10:09:31+00:00
 - user: None

<img alt="Leżał na tylnym fotelu w aucie, nie dawał oznak życia. Śledczy sprawdzają, jak i dlaczego zmarł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rj0j09-41-latek-zabarykadowal-sie-w-domu-mierzyl-z-broni-do-policjantow-6555205/alternates/LANDSCAPE_1280" />
    W najbliższy piątek odbędzie się sekcja zwłok zmarłego 36-latka.

## Seria rozbojów w jednym z techników. Zatrzymano pięć osób, w tym cztery niepełnoletnie
 - [https://tvn24.pl/poznan/kolo-seria-rozbojow-w-szkole-zatrzymano-piec-osob-w-tym-cztery-niepelnoletnie-6679159?source=rss](https://tvn24.pl/poznan/kolo-seria-rozbojow-w-szkole-zatrzymano-piec-osob-w-tym-cztery-niepelnoletnie-6679159?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:56:28+00:00
 - user: None

<img alt="Seria rozbojów w jednym z techników. Zatrzymano pięć osób, w tym cztery niepełnoletnie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-9jehxw-policja-zatrzymala-dziwnie-zachowujacego-sie-kierowce-zdjecie-ilustracyjne-6305372/alternates/LANDSCAPE_1280" />
    Na cel mieli brać innych uczniów.

## W jednym pokoju znaleźli ciało kobiety, w drugim spał jej syn
 - [https://tvn24.pl/lodz/gmina-zadzim-woj-lodzkie-53-latek-podejrzany-o-zabojstwo-matki-6679396?source=rss](https://tvn24.pl/lodz/gmina-zadzim-woj-lodzkie-53-latek-podejrzany-o-zabojstwo-matki-6679396?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:51:43+00:00
 - user: None

<img alt="W jednym pokoju znaleźli ciało kobiety, w drugim spał jej syn" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ifctwy-podejrzanemu-grozi-dozywocie-6679381/alternates/LANDSCAPE_1280" />
    53-latek usłyszał zarzut zabójstwa matki.

## Pieniądze z rządu dla akademii i fundacji ojca Rydzyka. Wiadomo ile
 - [https://tvn24.pl/biznes/z-kraju/ojciec-tadeusz-rydzyk-fundacja-lux-veritatis-i-akademia-kultury-spolecznej-i-medialnej-w-toruniu-otrzymuja-pieniadze-z-rzadu-ministerstwa-o-umowach-6679133?source=rss](https://tvn24.pl/biznes/z-kraju/ojciec-tadeusz-rydzyk-fundacja-lux-veritatis-i-akademia-kultury-spolecznej-i-medialnej-w-toruniu-otrzymuja-pieniadze-z-rzadu-ministerstwa-o-umowach-6679133?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:48:01+00:00
 - user: None

<img alt="Pieniądze z rządu dla akademii i fundacji ojca Rydzyka. Wiadomo ile" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ixrfon-ojciec-tadeusz-rydzyk-6679182/alternates/LANDSCAPE_1280" />
    Łączna kwota.

## Kilkadziesiąt rosyjskich pocisków wystrzelonych. Alarmy w całej Ukrainie, ofiary w Kijowie
 - [https://tvn24.pl/swiat/rosja-wystrzelila-ponad-30-pociskow-na-ukraine-6679299?source=rss](https://tvn24.pl/swiat/rosja-wystrzelila-ponad-30-pociskow-na-ukraine-6679299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:47:23+00:00
 - user: None

<img alt="Kilkadziesiąt rosyjskich pocisków wystrzelonych. Alarmy w całej Ukrainie, ofiary w Kijowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bljoy6-ukraina-charkow-6679154/alternates/LANDSCAPE_1280" />
    Ukraińskie siły powietrzne poinformowały, że Rosja wystrzeliła na Ukrainę ponad 30 rakiet.

## Kilkadziesiąt rosyjskich pocisków wystrzelonych. Alarmy w całej Ukrainie, ofiary w Kijowie
 - [https://tvn24.pl/swiat/rosja-wystrzelila-ponad-50-pociskow-na-ukraine-6679299?source=rss](https://tvn24.pl/swiat/rosja-wystrzelila-ponad-50-pociskow-na-ukraine-6679299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:47:23+00:00
 - user: None

<img alt="Kilkadziesiąt rosyjskich pocisków wystrzelonych. Alarmy w całej Ukrainie, ofiary w Kijowie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bljoy6-ukraina-charkow-6679154/alternates/LANDSCAPE_1280" />
    Ukraińskie siły powietrzne poinformowały, że Rosja wystrzeliła na Ukrainę ponad 30 rakiet.

## Obywatel Niemiec aresztowany pod zarzutem zdrady. Miał przekazywać informacje rosyjskiemu wywiadowi
 - [https://tvn24.pl/swiat/monachium-obywatel-niemiec-zatrzymany-pod-zarzutem-zdrady-mial-przekazywac-informacje-rosyjskiemu-wywiadowi-6679325?source=rss](https://tvn24.pl/swiat/monachium-obywatel-niemiec-zatrzymany-pod-zarzutem-zdrady-mial-przekazywac-informacje-rosyjskiemu-wywiadowi-6679325?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:30:49+00:00
 - user: None

<img alt="Obywatel Niemiec aresztowany pod zarzutem zdrady. Miał przekazywać informacje rosyjskiemu wywiadowi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h3zumv-lotnisko-w-monachium-6679309/alternates/LANDSCAPE_1280" />
    Przekazała w czwartek prokuratura generalna.

## Linette i Sabalenka czekają na koniec pierwszego półfinału. W nim zacięta walka
 - [https://eurosport.tvn24.pl/magda-linette---aryna-sabalenka--wynik-na--ywo-i-relacja-live---p--fina--australian-open,1134286.html?source=rss](https://eurosport.tvn24.pl/magda-linette---aryna-sabalenka--wynik-na--ywo-i-relacja-live---p--fina--australian-open,1134286.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:23:35+00:00
 - user: None

<img alt="Linette i Sabalenka czekają na koniec pierwszego półfinału. W nim zacięta walka" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rg6jsy-linette-relacja-1/alternates/LANDSCAPE_1280" />
    Transmisja w Eurosporcie 1 i w Eurosporcie Extra w Playerze. Wynik na żywo i relacja w eurosport.pl.

## Wypił i wsiadł za kierownicę. Cztery osoby, w tym dwoje dzieci, w szpitalu
 - [https://tvn24.pl/krakow/osobnica-wypil-i-wsiadl-za-kolko-cztery-osoby-w-tym-dwoje-dzieci-w-szpitalu-6679284?source=rss](https://tvn24.pl/krakow/osobnica-wypil-i-wsiadl-za-kolko-cztery-osoby-w-tym-dwoje-dzieci-w-szpitalu-6679284?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:22:52+00:00
 - user: None

<img alt="Wypił i wsiadł za kierownicę. Cztery osoby, w tym dwoje dzieci, w szpitalu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-c8e9d4-cztery-osoby-ranne-w-wypadku-w-osobnicy-w-powiecie-jasielskim-na-podkarpaciu-6679285/alternates/LANDSCAPE_1280" />
    Jak podała policja, sprawca wypadku miał blisko promil alkoholu w organizmie.

## Naukowcy ustalili, jaki rodzaj aktywności fizycznej najlepiej wpływa na pracę mózgu
 - [https://tvn24.pl/ciekawostki/zdrowie-jaki-rodzaj-aktywnosci-fizycznej-najlepiej-wplywa-na-sprawnosc-mozgu-badania-6668106?source=rss](https://tvn24.pl/ciekawostki/zdrowie-jaki-rodzaj-aktywnosci-fizycznej-najlepiej-wplywa-na-sprawnosc-mozgu-badania-6668106?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 09:04:41+00:00
 - user: None

<img alt="Naukowcy ustalili, jaki rodzaj aktywności fizycznej najlepiej wpływa na pracę mózgu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-zx7meb-aktywnosc-fizyczna-5685940/alternates/LANDSCAPE_1280" />
    Różne rodzaje aktywności w ciągu tygodnia zmieniały sprawność umysłową nawet o 2 proc.

## Co ze wspólną listą opozycji? Kosiniak-Kamysz: czytałem bardzo dobry tekst
 - [https://tvn24.pl/polska/wybory-czy-bedzie-wspolna-lista-opozycji-wladyslaw-kosiniak-kamysz-komentuje-6679198?source=rss](https://tvn24.pl/polska/wybory-czy-bedzie-wspolna-lista-opozycji-wladyslaw-kosiniak-kamysz-komentuje-6679198?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:53:53+00:00
 - user: None

<img alt="Co ze wspólną listą opozycji? Kosiniak-Kamysz: czytałem bardzo dobry tekst" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tbks0i-donald-tusk-wladyslaw-kosiniak-kamysz-i-szymon-holownia-zdjecie-z-maja-2022-roku-6679233/alternates/LANDSCAPE_1280" />
    Lider Polskiego Stronnictwa Ludowego nawiązał do ostatniego felietonu Konrada Piaseckiego.

## Gerard Piqué chwali się nową miłością na Instagramie
 - [https://tvn24.pl/kultura-i-styl/rozstanie-shakiry-i-gerarda-pique-pilkarz-pokazal-zdjecie-z-dziewczyna-na-instagramie-6679230?source=rss](https://tvn24.pl/kultura-i-styl/rozstanie-shakiry-i-gerarda-pique-pilkarz-pokazal-zdjecie-z-dziewczyna-na-instagramie-6679230?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:53:18+00:00
 - user: None

<img alt="Gerard Piqué chwali się nową miłością na Instagramie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vhxrfm-gerard-pique-ma-plany-na-przyszlosc-6194867/alternates/LANDSCAPE_1280" />
    To o niej śpiewała Shakira.

## Oślepiał laserem i ostrzelał policyjny śmigłowiec. Został zastrzelony
 - [https://tvn24.pl/swiat/detroit-oslepial-laserem-i-ostrzelal-policyjny-smiglowiec-mezczyzna-zostal-zastrzelony-6679084?source=rss](https://tvn24.pl/swiat/detroit-oslepial-laserem-i-ostrzelal-policyjny-smiglowiec-mezczyzna-zostal-zastrzelony-6679084?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:49:19+00:00
 - user: None

<img alt="Oślepiał laserem i ostrzelał policyjny śmigłowiec. Został zastrzelony " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yifrbt-mezczyzna-celowal-laserem-i-oddal-strzaly-w-strone-policyjnego-smiglowca-6679102/alternates/LANDSCAPE_1280" />
    W Detroit.

## Niemcy bez największej gwiazdy i trenera w Bad Mitterndorf
 - [https://eurosport.tvn24.pl/niemcy-bez-najwi-kszej-gwiazdy-i-trenera-w-konkursach-lot-w-narciarskich-w-bad-mitterndorf,1134228.html?source=rss](https://eurosport.tvn24.pl/niemcy-bez-najwi-kszej-gwiazdy-i-trenera-w-konkursach-lot-w-narciarskich-w-bad-mitterndorf,1134228.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:47:06+00:00
 - user: None

<img alt="Niemcy bez największej gwiazdy i trenera w Bad Mitterndorf" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w81kdb-karl-geiger/alternates/LANDSCAPE_1280" />
    W konkursach lotów narciarskich.

## "New York Times": Polska i kraje bałtyckie wypełniły próżnię na początku wojny
 - [https://tvn24.pl/swiat/new-york-times-srodek-ciezkosci-europy-przesuwa-sie-na-wschod-6679174?source=rss](https://tvn24.pl/swiat/new-york-times-srodek-ciezkosci-europy-przesuwa-sie-na-wschod-6679174?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:30:50+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9nu53h-ukraina-wojsko-6679179/alternates/LANDSCAPE_1280" />
    Wojna przyspiesza zmianę równowagi sił w Europie - pisze amerykański dziennik.

## Jan Zieliński pęka z dumy po awansie do finału. "Wzięliśmy sprawy w swoje ręce"
 - [https://eurosport.tvn24.pl/jan-zieli-ski-p-ka-z-dumy-po-awansie-do-fina-u---wzi-li-my-sprawy-w-swoje-r-ce-,1134279.html?source=rss](https://eurosport.tvn24.pl/jan-zieli-ski-p-ka-z-dumy-po-awansie-do-fina-u---wzi-li-my-sprawy-w-swoje-r-ce-,1134279.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:25:16+00:00
 - user: None

<img alt="Jan Zieliński pęka z dumy po awansie do finału. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-csbk9v-jan-zielinski-i-hugo-nys-w-finale-turnieju-deblistow-australian-open/alternates/LANDSCAPE_1280" />
    Powiedział w rozmowie z Eurosportem.

## Polska odzyskała obrazy zagrabione w czasie II wojny. Znaleziono je w muzeum w Hiszpanii
 - [https://tvn24.pl/polska/obrazy-mater-dolorosa-oraz-ecce-homo-dierica-boutsa-zgrabione-w-czasie-ii-wojny-zostaly-odzyskane-przez-skarb-panstwa-byly-w-muzeum-w-hiszpanii-6679098?source=rss](https://tvn24.pl/polska/obrazy-mater-dolorosa-oraz-ecce-homo-dierica-boutsa-zgrabione-w-czasie-ii-wojny-zostaly-odzyskane-przez-skarb-panstwa-byly-w-muzeum-w-hiszpanii-6679098?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 08:13:52+00:00
 - user: None

<img alt="Polska odzyskała obrazy zagrabione w czasie II wojny. Znaleziono je w muzeum w Hiszpanii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qt43ng-odzyskano-obrazy-zgrabione-w-czasie-ii-wojny-6679111/alternates/LANDSCAPE_1280" />
    Tworzące dyptyk religijny obrazy „Mater Dolorosa" oraz „Ecce Homo” Dierica Boutsa pochodzą z polskich zbiorów.

## "Sam czołg na polu walki jest bezbronny". Czego potrzebuje, żeby nie był?
 - [https://tvn24.pl/swiat/ukraina-general-leon-komornicki-sam-czolg-na-polu-walki-jest-bezbronny-musi-dzialac-w-okreslonym-srodowisku-6679136?source=rss](https://tvn24.pl/swiat/ukraina-general-leon-komornicki-sam-czolg-na-polu-walki-jest-bezbronny-musi-dzialac-w-okreslonym-srodowisku-6679136?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:58:39+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lin2ho-general-komornicki-w-tvn24-6679145/alternates/LANDSCAPE_1280" />
    Gość TVN24 o przekazaniu Ukrainie zachodnich czołgów.

## Brat Juliana Sandsa traci nadzieję: w głębi serca wiem, że odszedł
 - [https://tvn24.pl/swiat/usa-aktor-julian-sands-zaginal-brat-traci-nadzieje-w-glebi-serca-wiem-ze-odszedl-6679079?source=rss](https://tvn24.pl/swiat/usa-aktor-julian-sands-zaginal-brat-traci-nadzieje-w-glebi-serca-wiem-ze-odszedl-6679079?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:49:37+00:00
 - user: None

<img alt="Brat Juliana Sandsa traci nadzieję: w głębi serca wiem, że odszedł" src="https://tvn24.pl/najnowsze/cdn-zdjecie-w7vgrt-julian-sands-6638400/alternates/LANDSCAPE_1280" />
    Policja przyznaje, że nie znalazła żadnych śladów lokalizacji aktora.

## "Szykuje się nam coś nowego w pogodzie"
 - [https://tvn24.pl/tvnmeteo/pogoda/szykuje-sie-nam-cos-nowego-w-pogodzie-6678675?source=rss](https://tvn24.pl/tvnmeteo/pogoda/szykuje-sie-nam-cos-nowego-w-pogodzie-6678675?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:46:17+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aw8dyg-przed-nami-zmiana-w-pogodzie-6679125/alternates/LANDSCAPE_1280" />
    Tomasz Wasilewski o pogodzie w nadchodząchych dniach.

## Laptopy dla czwartoklasistów. Pieniądze mają pochodzić z KPO
 - [https://tvn24.pl/biznes/z-kraju/laptopy-dla-czwartoklasistow-pieniadze-maja-pochodzic-z-kpo-janusz-cieszynski-wyjasnia-6679100?source=rss](https://tvn24.pl/biznes/z-kraju/laptopy-dla-czwartoklasistow-pieniadze-maja-pochodzic-z-kpo-janusz-cieszynski-wyjasnia-6679100?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:40:11+00:00
 - user: None

<img alt="Laptopy dla czwartoklasistów. Pieniądze mają pochodzić z KPO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ghobrf-nauka-zdalna-4764759/alternates/LANDSCAPE_1280" />
    Sekretarz stanu w Kancelarii Prezesa Rady Ministrów Janusz Cieszyński o szczegółach.

## 16-letni Polak pokonał faworyta. Jest w półfinale
 - [https://eurosport.tvn24.pl/16-letni-polak-pokona--faworyta--jest-w-p--finale-australian-open,1134277.html?source=rss](https://eurosport.tvn24.pl/16-letni-polak-pokona--faworyta--jest-w-p--finale-australian-open,1134277.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:24:27+00:00
 - user: None

<img alt="16-letni Polak pokonał faworyta. Jest w półfinale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0vqe51-tomasz-berkieta-w-polfinale-juniorskiego-australian-open/alternates/LANDSCAPE_1280" />
    Juniorskiego Australian Open.

## "Prawo musi być egzekwowane. To jest obowiązek jednostki, a nie lekarza pracującego na oddziale"
 - [https://tvn24.pl/polska/zgwalcona-czternastolatka-z-podlasia-aborcja-a-klauzula-sumienia-wladyslaw-kosiniak-kamysz-o-sprawie-6679078?source=rss](https://tvn24.pl/polska/zgwalcona-czternastolatka-z-podlasia-aborcja-a-klauzula-sumienia-wladyslaw-kosiniak-kamysz-o-sprawie-6679078?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:11:59+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-buvhr7-wladyslaw-kosiniak-kamysz-w-rozmowie-piaseckiego-6678885/alternates/LANDSCAPE_1280" />
    Władysław Kosiniak-Kamysz o sprawie zgwałconej 14-latki.

## "FT": Gigant karze pracowników za wiadomości w komunikatorach. Nawet milion dolarów
 - [https://tvn24.pl/biznes/ze-swiata/usa-morgan-stanley-ukaral-pracownikow-za-uzywanie-komunikatorow-w-celach-sluzbowych-6678119?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-morgan-stanley-ukaral-pracownikow-za-uzywanie-komunikatorow-w-celach-sluzbowych-6678119?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 07:02:57+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u57ugm-shutterstock1287871834-6679058/alternates/LANDSCAPE_1280" />
    Przy ustalaniu wysokości kar, pod uwagę brano kilka kryteriów.

## Ładunek z Chin miał zawierać nawóz. W paczkach był zaczyn do produkcji amfetaminy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ladunek-z-chin-mial-zawierac-nawoz-w-paczkach-byl-zaczyn-do-produkcji-amfetaminy-6678598?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-ladunek-z-chin-mial-zawierac-nawoz-w-paczkach-byl-zaczyn-do-produkcji-amfetaminy-6678598?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:55:13+00:00
 - user: None

<img alt="Ładunek z Chin miał zawierać nawóz. W paczkach był zaczyn do produkcji amfetaminy " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-76lneh-zabezpieczono-prekursory-do-produkcji-narkotykow-6678737/alternates/LANDSCAPE_1280" />
    Ważył tonę.

## Szef MON ma "dobrą wiadomość" w sprawie Abramsów
 - [https://tvn24.pl/polska/abramsy-dla-polski-szef-mon-mariusz-blaszczak-pierwsze-czolgi-trafia-do-polski-wiosna-6679070?source=rss](https://tvn24.pl/polska/abramsy-dla-polski-szef-mon-mariusz-blaszczak-pierwsze-czolgi-trafia-do-polski-wiosna-6679070?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:47:55+00:00
 - user: None

<img alt="Szef MON ma " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lwyuey-amerykanski-czolg-abrams-podczas-cwiczen-na-lotwie-11-czerwca-2016-r-6669140/alternates/LANDSCAPE_1280" />
    Trafią do Polski.

## Eksperci zaskoczeni grą Polki. "Skąd ona się wzięła?"
 - [https://eurosport.tvn24.pl/eksperci-zaskoczeni-gr--polki---sk-d-ona-si--wzi--a--,1134244.html?source=rss](https://eurosport.tvn24.pl/eksperci-zaskoczeni-gr--polki---sk-d-ona-si--wzi--a--,1134244.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:39:18+00:00
 - user: None

<img alt="Eksperci zaskoczeni grą Polki. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7fdc3k-linette-zagra-teraz-sabalenka/alternates/LANDSCAPE_1280" />
    W czwartek Linette zagra o finał Australian Open.

## Elon Musk ma powody do zadowolenia. Tesla z rekordowymi przychodami i zyskiem powyżej oczekiwań
 - [https://tvn24.pl/biznes/rynki/tesla-producent-samochodow-elektrycznych-pokazala-wyniki-za-czwarty-kwartal-2022-roku-rekordowe-zyski-tesli-6678096?source=rss](https://tvn24.pl/biznes/rynki/tesla-producent-samochodow-elektrycznych-pokazala-wyniki-za-czwarty-kwartal-2022-roku-rekordowe-zyski-tesli-6678096?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:22:13+00:00
 - user: None

<img alt="Elon Musk ma powody do zadowolenia. Tesla z rekordowymi przychodami i zyskiem powyżej oczekiwań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wjjj3g-elon-musk-6625027/alternates/LANDSCAPE_1280" />
    Za czwarty kwartał 2022 rok.

## Manchester United o krok od finału
 - [https://eurosport.tvn24.pl/manchester-united-o-krok-od-fina-u,1134275.html?source=rss](https://eurosport.tvn24.pl/manchester-united-o-krok-od-fina-u,1134275.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:19:58+00:00
 - user: None

<img alt="Manchester United o krok od finału" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9eidl2-radosc-pilkarzy-manchesteru-united/alternates/LANDSCAPE_1280" />
    Po pierwszym meczu półfinału Pucharu Ligi Angielskiej.

## Świetna passa koszykarek Polonii
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wilanow-final-europejskiej-ligi-koszykowki-kobiet-6678158?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wilanow-final-europejskiej-ligi-koszykowki-kobiet-6678158?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:13:08+00:00
 - user: None

<img alt="Świetna passa koszykarek Polonii " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cv49iq-andreona-keys-zawodniczka-skk-polonii-warszawa-6678094/alternates/LANDSCAPE_1280" />
    Warszawa będzie gospodarzem finału.

## Sześciolatek strzelił do nauczycielki. Szkoła "zignorowała ostrzeżenia", bo "miał małe kieszenie"
 - [https://tvn24.pl/swiat/usa-uczen-postrzelil-nauczycielke-w-wirginii-prawniczka-ofiary-dyrekcja-szkoly-zignorowala-ostrzezenia-6678101?source=rss](https://tvn24.pl/swiat/usa-uczen-postrzelil-nauczycielke-w-wirginii-prawniczka-ofiary-dyrekcja-szkoly-zignorowala-ostrzezenia-6678101?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 06:12:52+00:00
 - user: None

<img alt="Sześciolatek strzelił do nauczycielki. Szkoła " src="https://tvn24.pl/najnowsze/cdn-zdjecie-x5771m-w-stanie-wirginia-6-latek-postrzelil-nauczycielke-podczas-przerwy-w-zajeciach-6599135/alternates/LANDSCAPE_1280" />
    6-latek postrzelił nauczycielkę.

## Największa taka inwestycja od blisko 70 lat.  Otwarto nowy terminal w Nowym Jorku
 - [https://tvn24.pl/biznes/ze-swiata/usa-nowy-jork-grand-central-madison-otwarto-nowy-terminal-pod-dworcem-grand-centra-6678080?source=rss](https://tvn24.pl/biznes/ze-swiata/usa-nowy-jork-grand-central-madison-otwarto-nowy-terminal-pod-dworcem-grand-centra-6678080?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:53:54+00:00
 - user: None

<img alt="Największa taka inwestycja od blisko 70 lat.  Otwarto nowy terminal w Nowym Jorku" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-wsji1f-otwarto-nowy-terminal-pod-dworcem-grand-central-6678081/alternates/LANDSCAPE_1280" />
    Po wielu latach opóźnień.

## Atak zimy w Japonii. Zginęło co najmniej pięć osób
 - [https://tvn24.pl/tvnmeteo/swiat/atak-zimy-w-japonii-zginelo-co-najmniej-piec-osob-6678087?source=rss](https://tvn24.pl/tvnmeteo/swiat/atak-zimy-w-japonii-zginelo-co-najmniej-piec-osob-6678087?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:49:52+00:00
 - user: None

<img alt="Atak zimy w Japonii. Zginęło co najmniej pięć osób" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-8ly8ss-atak-zimy-w-japonii-6678090/alternates/LANDSCAPE_1280" />
    Gwałtowna aura wywołała chaos komunikacyjny.

## "To jest prawo powszechnej inwigilacji"
 - [https://tvn24.pl/polska/kontrowersyjne-zapisy-w-lex-pilot-komentarze-politykow-i-ekspertow-6671913?source=rss](https://tvn24.pl/polska/kontrowersyjne-zapisy-w-lex-pilot-komentarze-politykow-i-ekspertow-6671913?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:34:26+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-72slam-haker-spyware-pegasus-adobestock216060817-6615590/alternates/LANDSCAPE_1280" />
    Politycy i eksperci o kontrowersyjnych zapisach w Lex pilot.

## Policzyli nagrobki na cmentarzu Grupy Wagnera. Dwa miesiące temu i teraz
 - [https://tvn24.pl/swiat/new-york-times-liczba-nagrobkow-na-cmentarzu-grupy-wagnera-w-ciagu-dwoch-miesiecy-wzrosla-siedmiokrotnie-6673061?source=rss](https://tvn24.pl/swiat/new-york-times-liczba-nagrobkow-na-cmentarzu-grupy-wagnera-w-ciagu-dwoch-miesiecy-wzrosla-siedmiokrotnie-6673061?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:19:14+00:00
 - user: None

<img alt="Policzyli nagrobki na cmentarzu Grupy Wagnera. Dwa miesiące temu i teraz" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hikq9e-rosyjscy-zolnierze-6629921/alternates/LANDSCAPE_1280" />
    "New York Times" przeanalizował zdjęcia satelitarne.

## "Nie istnieją prawne warunki". Rosjanin opuścił areszt
 - [https://tvn24.pl/swiat/norwegia-policja-zwolnila-z-aresztu-rosjanina-z-grupy-wagnera-6674273?source=rss](https://tvn24.pl/swiat/norwegia-policja-zwolnila-z-aresztu-rosjanina-z-grupy-wagnera-6674273?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:07:23+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-g671o7-czlonek-grupy-wagnera-andriej-miedwiediew-uciekl-do-norwegii-zamierza-ubiegac-sie-o-azyl-6635755/alternates/LANDSCAPE_1280" />
    Przebywał w areszcie dla imigrantów w Trandum pod Oslo.

## Największy sukces w karierze. Polak w finale debla Australian Open
 - [https://eurosport.tvn24.pl/najwi-kszy-sukces-w-karierze--polak-w-finale-debla-australian-open,1134273.html?source=rss](https://eurosport.tvn24.pl/najwi-kszy-sukces-w-karierze--polak-w-finale-debla-australian-open,1134273.html?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:03:07+00:00
 - user: None

<img alt="Największy sukces w karierze. Polak w finale debla Australian Open" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pm52jn-zielinski-i-nys-w-finale-debla-australian-open/alternates/LANDSCAPE_1280" />
    Jan Zieliński i Hugo Nys z Monako pokonali Francuzów Jeremy'ego Chardy'ego i Fabrice'a Martina w półfinale turnieju debla w Melbourne.

## "Musimy uformować pancerną pięść wolności, po której uderzeniu rosyjska tyrania już się nie podniesie"
 - [https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-musimy-uformowac-pancerna-piesc-wolnosci-6672268?source=rss](https://tvn24.pl/swiat/ukraina-wolodymyr-zelenski-musimy-uformowac-pancerna-piesc-wolnosci-6672268?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 05:03:00+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ddabt6-abrams-sepv3-01-5663320/alternates/LANDSCAPE_1280" />
    Zełenski dziękuje sojusznikom za gotowość dostarczenia Ukrainie nowoczesnych czołgów.

## Pod rosyjskimi bombami wpisani na listę zagrożonego Dziedzictwa Światowego
 - [https://tvn24.pl/swiat/unesco-przyznaje-odessie-status-zagrozonego-dziedzictwa-swiatowego-6674639?source=rss](https://tvn24.pl/swiat/unesco-przyznaje-odessie-status-zagrozonego-dziedzictwa-swiatowego-6674639?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:52:32+00:00
 - user: None

<img alt="Pod rosyjskimi bombami wpisani na listę zagrożonego Dziedzictwa Światowego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uoa840-odessa-5695570/alternates/LANDSCAPE_1280" />
    Miasto było wielokrotnie bombardowane.

## Papież: bycie homoseksualistą nie jest przestępstwem
 - [https://tvn24.pl/swiat/papiez-franciszek-bycie-homoseksualista-nie-jest-przestepstwem-6675894?source=rss](https://tvn24.pl/swiat/papiez-franciszek-bycie-homoseksualista-nie-jest-przestepstwem-6675894?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:49:49+00:00
 - user: None

<img alt="Papież: bycie homoseksualistą nie jest przestępstwem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-adxbj6-papiez-franciszek-6675750/alternates/LANDSCAPE_1280" />
    Wezwał kraje penalizujące homoseksualizm.

## "Upłynął okres zawieszenia". Trump może wrócić
 - [https://tvn24.pl/swiat/usa-donald-trump-moze-powrocic-na-facebooka-6678065?source=rss](https://tvn24.pl/swiat/usa-donald-trump-moze-powrocic-na-facebooka-6678065?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:34:27+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-0truqi-trump-shutterstock2207727635-6215333/alternates/LANDSCAPE_1280" />
    Na Facebooka.

## Same czołgi nie wystarczą. "Jeszcze pilniejsze jest wysłanie samolotów"
 - [https://tvn24.pl/swiat/wielka-brytania-eksperci-czolgi-dla-ukrainy-to-duzy-krok-naprzod-ale-to-jeszcze-za-malo-6672689?source=rss](https://tvn24.pl/swiat/wielka-brytania-eksperci-czolgi-dla-ukrainy-to-duzy-krok-naprzod-ale-to-jeszcze-za-malo-6672689?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:30:10+00:00
 - user: None

<img alt="Same czołgi nie wystarczą. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-n32m54-amerykanski-mysliwiec-f-16-6628550/alternates/LANDSCAPE_1280" />
    Zdaniem analityków Ukraina potrzebuje również samolotów.

## Odnotowali spadek liczby ofiar handlu ludźmi. Kwestia trzech czynników
 - [https://tvn24.pl/swiat/onz-odnotowano-pierwszy-spadek-liczby-ofiar-handlu-ludzmi-6677373?source=rss](https://tvn24.pl/swiat/onz-odnotowano-pierwszy-spadek-liczby-ofiar-handlu-ludzmi-6677373?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:16:31+00:00
 - user: None

<img alt="Odnotowali spadek liczby ofiar handlu ludźmi. Kwestia trzech czynników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6iz5zk-biuro-onz-ds-narkotykow-i-przestepczosci-odnotowalo-spadek-liczby-ofiar-handlu-ludzmi-6677307/alternates/LANDSCAPE_1280" />
    Autorzy raportu piszą o wykrywaniu.

## Od początku wojny Rosja "uszkodziła i zniszczyła 1206 placówek medycznych"
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-25-stycznia-2023-6677895?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-25-stycznia-2023-6677895?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:12:57+00:00
 - user: None

<img alt="Od początku wojny Rosja " src="https://tvn24.pl/najnowsze/cdn-zdjecie-o34oyc-zniszczenia-w-bachmucie-6642158/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.

## Rosja wystrzeliła kilkadziesiąt pocisków. Alarm na Ukrainie
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-26-stycznia-2023-6677895?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-26-stycznia-2023-6677895?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-01-26 04:12:57+00:00
 - user: None

<img alt="Rosja wystrzeliła kilkadziesiąt pocisków. Alarm na Ukrainie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bljoy6-ukraina-charkow-6679154/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy wydarzenia z i wokół Ukrainy.
