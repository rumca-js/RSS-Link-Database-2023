# Source TVN24 Z kraju, Source URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, Source language: pl-PL

## Grobowce zamknięte przez ponad cztery tysiące lat. Teraz otworzyli je egipscy archeolodzy
 - [https://tvn24.pl/tvnmeteo/swiat/egipt-grobowce-zamkniete-przez-ponad-cztery-tysiace-lat-teraz-otworzyli-je-egipscy-archeolodzy-to-moze-byc-najstarsza-mumia-6681630?source=rss](https://tvn24.pl/tvnmeteo/swiat/egipt-grobowce-zamkniete-przez-ponad-cztery-tysiace-lat-teraz-otworzyli-je-egipscy-archeolodzy-to-moze-byc-najstarsza-mumia-6681630?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 20:55:41+00:00
 - user: None

<img alt="Grobowce zamknięte przez ponad cztery tysiące lat. Teraz otworzyli je egipscy archeolodzy" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vocayd-znaleziono-kolejne-grobowce-faraonow-egipskich-6681594/alternates/LANDSCAPE_1280" />
    Inspektorzy, urzędnicy, kapłan i jeden mężczyzna o imieniu Hekashepes - mumie tych ludzi zostały odkryte niedawno przez egipskich archeologów w nekropolii Sakkara. Jak stwierdzili naukowcy, ich grobowce były zamknięte przez nawet 4,3 tysiąca lat. Według badaczy, jedne ze zmumifikowanych szczątek mogą być najstarszymi znalezionymi w Egipcie do tej pory.

## Wszystkie poprawki Senatu przepadły. Budżet trafi do prezydenta
 - [https://tvn24.pl/biznes/najnowsze/ustawa-budzetowa-2023-wszystkie-poprawki-senatu-przepadly-6681559?source=rss](https://tvn24.pl/biznes/najnowsze/ustawa-budzetowa-2023-wszystkie-poprawki-senatu-przepadly-6681559?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 19:54:53+00:00
 - user: None

<img alt="Wszystkie poprawki Senatu przepadły. Budżet trafi do prezydenta" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r0t2ti-mid-23126062-6681590/alternates/LANDSCAPE_1280" />
    Sejm w czwartek odrzucił wszystkie poprawki Senatu do budżetu na 2023 roku. Ustawa budżetowa trafi teraz na biurko prezydenta RP Andrzeja Dudy.

## Zgwałconej 14-latce odmówiono aborcji. "Sprawą powinna się zająć prokuratura"
 - [https://tvn24.pl/polska/michal-kaminski-i-krzysztof-brejza-6681474?source=rss](https://tvn24.pl/polska/michal-kaminski-i-krzysztof-brejza-6681474?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 19:54:09+00:00
 - user: None

<img alt="Zgwałconej 14-latce odmówiono aborcji. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6sgqp3-26-2000-kropka-cl-0063-6681534/alternates/LANDSCAPE_1280" />
    Trzeba wygrać wybory i ludzi o psychopatycznym podejściu do kobiet, ludzi o patologicznej chęci kontrolowania seksualności u kobiet, pogonić z rządu i od władzy - powiedział w "Kropce nad i" senator Krzysztof Brejza (Koalicja Obywatelska), odnosząc się do sprawy zgwałconej 14-latki z Podlasia, której odmówiono aborcji. Według wicemarszałka Senatu Michała Kamińskiego (PSL-Koalicja Polska), trzeba doprowadzić do egzekwowania obowiązującego prawa aborcyjnego. - Odmówiono tej dziewczynce w dramatycznej okoliczności aborcji dozwolonej prawem - wskazywał.

## Sejm przyjął ustawę ograniczającą podwyżki cen ciepła
 - [https://tvn24.pl/biznes/z-kraju/rachunki-za-ogrzewanie-sejm-przyjal-ustawe-ograniczajaca-podwyzki-cen-ciepla-6681544?source=rss](https://tvn24.pl/biznes/z-kraju/rachunki-za-ogrzewanie-sejm-przyjal-ustawe-ograniczajaca-podwyzki-cen-ciepla-6681544?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 19:30:00+00:00
 - user: None

<img alt="Sejm przyjął ustawę ograniczającą podwyżki cen ciepła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-shj0b2-shutterstock367720379-6635473/alternates/LANDSCAPE_1280" />
    Sejm uchwalił w czwartek nowelizację wprowadzającą mechanizm ograniczenia wzrostu cen dla odbiorców ciepła do 40 procent. Teraz ustawa trafi do dalszych prac w Senacie.

## Powodzie na Sardynii. W rzece znaleziono ciało starszego mężczyzny
 - [https://tvn24.pl/tvnmeteo/swiat/powodzie-na-sardynii-w-rzece-znaleziono-cialo-starszego-mezczyzny-6681497?source=rss](https://tvn24.pl/tvnmeteo/swiat/powodzie-na-sardynii-w-rzece-znaleziono-cialo-starszego-mezczyzny-6681497?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 19:26:09+00:00
 - user: None

<img alt="Powodzie na Sardynii. W rzece znaleziono ciało starszego mężczyzny" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-x7j3oh-wczesniej-w-poblizu-potoku-znaleziono-auto-mezczyzny-6681517/alternates/LANDSCAPE_1280" />
    Pogoda we Włoszech jest od kilku dni bardzo trudna i dynamiczna. Na Sardynii padało tak bardzo, że doszło do powodzi. W czwartek służby odnalazły ciało starszego mężczyzny, który zaginął w środę. Wcześniej znaleziono jego auto.

## Pięć aut zderzyło się na trasie S8
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-piec-aut-zderzylo-sie-na-trasie-s8-6681538?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-piec-aut-zderzylo-sie-na-trasie-s8-6681538?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 19:20:24+00:00
 - user: None

<img alt="Pięć aut zderzyło się na trasie S8" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ddw6n7-zderzenie-pieciu-aut-na-s8-6681555/alternates/LANDSCAPE_1280" />
    Do zderzenia pięciu aut osobowych doszło na wysokości Wisłostrady, na jezdni lokalnej, w kierunku Poznania. Były utrudnienia w ruchu.

## Białoruskie służby podwożą migrantów na granicę. Pokazano nagranie
 - [https://tvn24.pl/polska/grupa-migrantow-zostala-dowieziona-do-granicy-probowala-przejsc-na-teren-polski-straz-graniczna-pokazala-nagranie-6681468?source=rss](https://tvn24.pl/polska/grupa-migrantow-zostala-dowieziona-do-granicy-probowala-przejsc-na-teren-polski-straz-graniczna-pokazala-nagranie-6681468?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 18:56:57+00:00
 - user: None

<img alt="Białoruskie służby podwożą migrantów na granicę. Pokazano nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-29hchp-2-6681463/alternates/LANDSCAPE_1280" />
    W okolicach Kuźnicy na Podlasiu, przywieziona przez białoruskie służby, grupa migrantów próbowała dostać się do Polski z Białorusi, wykorzystując tory kolejowe biegnące przez granicę - poinformowała Straż Graniczna. Nagranie mające pokazywać te wydarzenia opublikował podlaski oddział SG.

## Partia popularnego leku na przeziębienie wycofana z aptek
 - [https://tvn24.pl/biznes/z-kraju/partia-febrisanu-wycofana-z-aptek-komunikat-gif-6681426?source=rss](https://tvn24.pl/biznes/z-kraju/partia-febrisanu-wycofana-z-aptek-komunikat-gif-6681426?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 18:43:31+00:00
 - user: None

<img alt="Partia popularnego leku na przeziębienie wycofana z aptek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-byaac7-apteki-narzekaja-na-zbyt-wysokie-oplaty-5689101/alternates/LANDSCAPE_1280" />
    Partia Febrisanu stosowanego przy objawach przeziębienia i grypy decyzją Głównego Inspektoratu Farmaceutycznego została wycofana z aptek. Urząd wyjaśnił, że nie ma pewności, czy "części serii skierowane do obrotu spełniają wymagania jakościowe pod względem zawartości substancji czynnych".

## Prezydent: oddajemy nasze czołgi Ukrainie tak, by Polska pozostała bezpieczna
 - [https://tvn24.pl/polska/prezydent-andrzej-duda-o-dostawach-broni-na-ukraine-i-polskim-bezpieczenstwie-6681421?source=rss](https://tvn24.pl/polska/prezydent-andrzej-duda-o-dostawach-broni-na-ukraine-i-polskim-bezpieczenstwie-6681421?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 18:38:05+00:00
 - user: None

<img alt="Prezydent: oddajemy nasze czołgi Ukrainie tak, by Polska pozostała bezpieczna" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h7oqe2-andrzej-duda-w-bodzentynie-6681425/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda spotkał się w czwartek z mieszkańcami świętokrzyskiego Bodzentyna, gdzie wziął udział w uroczystościach związanych ze 160. rocznicą powstania styczniowego. Prezydent mówił także o trwającej wojnie w Ukrainie i polskim bezpieczeństwie. - Dzisiaj przede wszystkim musimy być bezpieczni, musimy zabezpieczyć się przed tym, by nikt nie odebrał nam naszej wolności, suwerenności, niepodległości - oświadczył.

## Obywatelskie zatrzymanie pijanego kierowcy na Okęciu
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-obywatelskie-zatrzymanie-pijanego-kierowcy-na-okeciu-6681473?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-obywatelskie-zatrzymanie-pijanego-kierowcy-na-okeciu-6681473?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 18:29:30+00:00
 - user: None

<img alt="Obywatelskie zatrzymanie pijanego kierowcy na Okęciu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-yvc2rt-do-zatrzymania-pijanego-kierowcy-doszlo-na-okeciu-6681470/alternates/LANDSCAPE_1280" />
    Do zatrzymania nietrzeźwego kierowcy doszło na ulicy Komitetu Ochrony Robotników. Po przebadaniu policyjnym alkomatem okazało się, że kierujący volvo ma prawie dwa promile alkoholu w organizmie.

## Pogoda na jutro - piątek 27.01. Noc mroźna w wielu regionach. W dzień słabe opady śniegu
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-piatek-2701-noc-mrozna-w-wielu-regionach-w-dzien-slabe-opady-sniegu-6681360?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-piatek-2701-noc-mrozna-w-wielu-regionach-w-dzien-slabe-opady-sniegu-6681360?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 18:15:31+00:00
 - user: None

<img alt="Pogoda na jutro - piątek 27.01. Noc mroźna w wielu regionach. W dzień słabe opady śniegu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cj8h27-noc-bedzie-mrozna-5036456/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli piątek 27.01, zapowiada się ze słabym śniegiem w części kraju. Wcześniej jednak, nocą, chwyci mróz - miejscami termometry pokażą nawet -6 stopni Celsjusza. Zrobi się ślisko.

## Marilyn Manson miał ją więzić, gonić z siekierą i razić prądem. Aktorka wycofała pozew
 - [https://tvn24.pl/kultura-i-styl/marilyn-manson-esme-bianco-oskarzala-muzyka-o-gwalt-razenie-pradem-i-inne-formy-przemocy-zdecydowala-sie-na-ugode-6681205?source=rss](https://tvn24.pl/kultura-i-styl/marilyn-manson-esme-bianco-oskarzala-muzyka-o-gwalt-razenie-pradem-i-inne-formy-przemocy-zdecydowala-sie-na-ugode-6681205?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 17:17:47+00:00
 - user: None

<img alt="Marilyn Manson miał ją więzić, gonić z siekierą i razić prądem. Aktorka wycofała pozew " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5awb64-esme-bianco-i-marilyn-manson-6681225/alternates/LANDSCAPE_1280" />
    Esmé Bianco, aktorka znana z "Gry o tron", zdecydowała się zawrzeć ugodę pozasądową z Marilynem Mansonem - poinformował jej prawnik. Jak przekazał, zdecydowała się na ten krok, "aby ruszyć dalej ze swoim życiem i karierą". Dwa lata wcześniej Bianco złożyła pozew, w którym oskarżała muzyka m.in. o dokonywanie "brutalnych aktów seksualnych, na które nie wyrażała zgody" i inne formy przemocy.

## Iga Świątek ma wyzwanie dla swoich fanów:   12 książek lub więcej w 2023 roku
 - [https://tvn24.pl/ciekawostki/iga-swiatek-12-ksiazek-albo-wiecej-w-2023-roku-tenisistka-zaprasza-do-udzialu-w-wyzwaniu-czytelniczym-6681366?source=rss](https://tvn24.pl/ciekawostki/iga-swiatek-12-ksiazek-albo-wiecej-w-2023-roku-tenisistka-zaprasza-do-udzialu-w-wyzwaniu-czytelniczym-6681366?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 17:12:12+00:00
 - user: None

<img alt="Iga Świątek ma wyzwanie dla swoich fanów:   12 książek lub więcej w 2023 roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qmuuq2-iga-swiatek-w-ostrawie-czuje-sie-jak-w-domu-6145168/alternates/LANDSCAPE_1280" />
    Iga Świątek wzbudziła entuzjazm swoich fanów, tym razem jednak nie kolejnym sukcesem na korcie, ale wyzwaniem czytelniczym. Polega ono na przeczytaniu w 2023 roku dwunastu książek lub więcej. "Chcę motywować samą siebie do tego, żeby czytać jak najwięcej, bo czytanie pozwala mi utrzymywać równowagę między moim życiem a pracą" - napisała najlepsza polska tenisistka w mediach społecznościowych.

## "Economist": Niemcy wystawiły na próbę wspólny front NATO. Nie służyło to nikomu poza Kremlem
 - [https://tvn24.pl/polska/sprawa-czolgow-leopard-dla-ukrainy-economist-o-postawie-niemiec-6681331?source=rss](https://tvn24.pl/polska/sprawa-czolgow-leopard-dla-ukrainy-economist-o-postawie-niemiec-6681331?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 16:55:03+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4dqi32-olaf-scholz-6645699/alternates/LANDSCAPE_1280" />
    Kanclerz Niemiec Olaf Scholz, który wahał się, czy dostarczyć Ukrainie czołgi Leopard, wystawił na próbę wspólny front państw NATO wobec agresji ze strony Rosji. Nie służyło to nikomu poza Kremlem. Berlin ocenia jednak, że odniósł dyplomatyczne zwycięstwo - pisze "Economist".

## Oszuści mogą wykraść pieniądze z konta. Ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/podatki-oszusci-podszywaja-sie-pod-kas-falszywe-maile-o-rzekomym-automatycznym-zwrocie-podatku-ostrzezenie-cert-polska-6679398?source=rss](https://tvn24.pl/biznes/z-kraju/podatki-oszusci-podszywaja-sie-pod-kas-falszywe-maile-o-rzekomym-automatycznym-zwrocie-podatku-ostrzezenie-cert-polska-6679398?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 16:48:40+00:00
 - user: None

<img alt="Oszuści mogą wykraść pieniądze z konta. Ostrzeżenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-f761r9-smartfon-telefon-5037435/alternates/LANDSCAPE_1280" />
    CERT Polska ostrzega przed oszustami podszywającymi się pod Krajową Administrację Skarbową. Cyberprzestępcy w wysyłanych wiadomościach e-mail informują o rzekomym automatycznym zwrocie podatku.

## Pogoda na 5 dni. Lekki mróz nawet za dnia. W przyszłym tygodniu jest szansa na większe opady śniegu
 - [https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-weekend-kiedy-spadnie-snieg-lekki-mroz-za-dnia-w-przyszlym-tygodniu-jest-szansa-na-wieksze-opady-sniegu-6681197?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/pogoda-na-weekend-kiedy-spadnie-snieg-lekki-mroz-za-dnia-w-przyszlym-tygodniu-jest-szansa-na-wieksze-opady-sniegu-6681197?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 16:12:55+00:00
 - user: None

<img alt="Pogoda na 5 dni. Lekki mróz nawet za dnia. W przyszłym tygodniu jest szansa na większe opady śniegu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-x386rk-pojawi-sie-snieg-6681275/alternates/LANDSCAPE_1280" />
    Kiedy spadnie śnieg? Pogoda w najbliższych dniach zapowiada się pochmurno. Miejscami może słabo poprószyć śnieg. Na początku tygodnia opady będą bardziej intensywne, spadnie ponad 10 centymetrów śniegu. Lokalnie za dnia chwyci lekki mróz. W tych miejscach temperatura w najcieplejszym momencie dnia wyniesie -2 stopnie Celsjusza.

## Mała poprawka, drastyczna zmiana. "Ustawa jest bublem"
 - [https://tvn24.pl/biznes/najnowsze/ustawa-wiatrakowa-zaskakujaca-poprawka-pis-psew-ustawa-staje-sie-bublem-6681227?source=rss](https://tvn24.pl/biznes/najnowsze/ustawa-wiatrakowa-zaskakujaca-poprawka-pis-psew-ustawa-staje-sie-bublem-6681227?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 16:11:08+00:00
 - user: None

<img alt="Mała poprawka, drastyczna zmiana. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nmf3iw-posel-prawa-i-sprawiedliwosci-marek-suski-i-minister-klimatu-i-srodowiska-anna-moskwa-6681161/alternates/LANDSCAPE_1280" />
    Przyjęcie poprawki o zmianie odległości minimalnej od wiatraków z 500 na 700 metrów to dalsze blokowanie energetyki wiatrowej na lądzie - ocenia Polskie Stowarzyszenie Energetyki Wiatrowej.  Jak ocenia prezes organizacji Janusz Gajowiecki w zaproponowanej przez posłów wersji ustawa wiatrakowa jest bublem. Z szacunków PSEW wynika, że zwiększenie minimalnej odległości spowoduje redukcję możliwej mocy zainstalowanej o około 60-70 procent.

## Pijany kierowca zasnął na skrzyżowaniu, strażników przekonywał, że "jakoś da radę"
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-ursynow-pijany-kierowca-zasnal-na-skrzyzowaniu-6680972?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-ursynow-pijany-kierowca-zasnal-na-skrzyzowaniu-6680972?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:59:16+00:00
 - user: None

<img alt="Pijany kierowca zasnął na skrzyżowaniu, strażników przekonywał, że " src="https://tvn24.pl/krakow/cdn-zdjecie-2ejql3-mezczyzna-zostal-zatrzymany-6680930/alternates/LANDSCAPE_1280" />
    Patrol Straży Miejskiej zauważył dwa samochody, stojące na skrzyżowaniu, mimo zielonego światła. Okazało się, że jeden z kierowców zasnął za kierownicą. Miał ponad 1,5 promila alkoholu w wydychanym powietrzu.

## Złodziej wszedł razem z drzwiami. Uciekł, gdy zobaczył jednego z domowników
 - [https://tvn24.pl/poznan/poznan-marszalkowska-zlodziej-wszedl-razem-z-drzwiami-6681063?source=rss](https://tvn24.pl/poznan/poznan-marszalkowska-zlodziej-wszedl-razem-z-drzwiami-6681063?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:59:00+00:00
 - user: None

<img alt="Złodziej wszedł razem z drzwiami. Uciekł, gdy zobaczył jednego z domowników" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xfboxw-zlodziej-wszedl-z-drzwiami-6680783/alternates/LANDSCAPE_1280" />
    W środę przed południem w Poznaniu mężczyzna wyważył drzwi na tarasie jednego z domów, po czym pobiegł na piętro. Gdy zorientował się, że w domu są mieszkańcy, spłoszony uciekł. Sprawą zajmuje się policja.

## Ludzki płód w przepompowni ścieków
 - [https://tvn24.pl/poznan/okonek-plod-w-przepompowni-sciekow-policja-bada-sprawe-6681294?source=rss](https://tvn24.pl/poznan/okonek-plod-w-przepompowni-sciekow-policja-bada-sprawe-6681294?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:58:15+00:00
 - user: None

<img alt="Ludzki płód w przepompowni ścieków" src="https://tvn24.pl/najnowsze/cdn-zdjecie-it6esp-31-arkadiusz-d-z-zarzutem-zabojstwa-po-smiertelnym-dzgnieciu-nozem-mezczyzny-zdjecie-ilustracyjne-6553276/alternates/LANDSCAPE_1280" />
    W czwartek rano w miejscowości Okonek (woj. wielkopolskie), pracownicy przepompowni ścieków znaleźli płód dziecka. Na podstawie sieci wodociągowej ustalane będzie między innymi miejsce, z którego mógł przepłynąć.

## Oddadzą hołd ofiarom Holokaustu. Uroczystości przed pomnikiem Bohaterów Getta
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-miedzynarodowy-dzien-pamieci-o-ofiarach-holokaustu-program-obchodow-6681210?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-miedzynarodowy-dzien-pamieci-o-ofiarach-holokaustu-program-obchodow-6681210?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:57:26+00:00
 - user: None

<img alt="Oddadzą hołd ofiarom Holokaustu. Uroczystości przed pomnikiem Bohaterów Getta" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-bl1tow-dzien-pamieci-o-ofiarach-holokaustu-tak-wygladaly-obchody-poprzednich-latach-6681216/alternates/LANDSCAPE_1280" />
    W piątek, 27 stycznia - w rocznicę wyzwolenia obozu Auschwitz-Birkenau - Warszawa odda hołd ofiarom Holokaustu. Uroczystości rozpoczną się modlitwą przed Pomnikiem Bohaterów Getta. W tym dniu warszawiacy zapalą świeczki w swoich oknach, a na ulice wyjedzie pusty zabytkowy tramwaj oznaczony gwiazdą Dawida.

## Mrówki potrafią wykryć zapach raka w moczu
 - [https://tvn24.pl/tvnmeteo/nauka/mrowki-potrafia-wykryc-zapach-raka-w-moczu-badania-naukowe-wykrywanie-nowotworow-6679599?source=rss](https://tvn24.pl/tvnmeteo/nauka/mrowki-potrafia-wykryc-zapach-raka-w-moczu-badania-naukowe-wykrywanie-nowotworow-6679599?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:47:41+00:00
 - user: None

<img alt="Mrówki potrafią wykryć zapach raka w moczu" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-sodlyd-mrowki-z-gatunku-formica-fusca-6681065/alternates/LANDSCAPE_1280" />
    Badania przeprowadzone przez francuskich naukowców dowodzą, że da się przeszkolić mrówki tak, by znalazły komórki nowotworowe w moczu. Artykuł na ten temat pojawił się w czasopiśmie "Proceedings of the Royal Society B". - Wyniki są bardzo obiecujące - powiedział główny autor publikacji Baptiste Piqueret.

## Lockheed Martin zwiększy produkcję F-16. "Nie można winić Ukraińców za to, że chcą otrzymać kolejne systemy"
 - [https://tvn24.pl/swiat/usa-lockheed-martin-zwiekszy-produkcje-f-16-chce-odpowiedziec-na-potrzeby-krajow-ktore-zdecyduja-sie-wysylac-samoloty-na-ukraine-6681121?source=rss](https://tvn24.pl/swiat/usa-lockheed-martin-zwiekszy-produkcje-f-16-chce-odpowiedziec-na-potrzeby-krajow-ktore-zdecyduja-sie-wysylac-samoloty-na-ukraine-6681121?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:25:18+00:00
 - user: None

<img alt="Lockheed Martin zwiększy produkcję F-16. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ehrl8f-f-16-6681152/alternates/LANDSCAPE_1280" />
    "Amerykański koncern zbrojeniowy Lockheed Martin zamierza zwiększyć produkcję samolotów F-16 w swojej fabryce w Karolinie Północnej, by móc uzupełnić zasoby krajów, które zdecydują się wysłać myśliwce na Ukrainę - powiedział dziennikowi "Financial Times" dyrektor operacyjny spółki Frank St. John. Dodał, że w sprawie toczy się "wiele rozmów".

## Ambasador Iranu nie podał ręki królowej Hiszpanii
 - [https://tvn24.pl/swiat/hiszpania-ambasador-iranu-nie-podal-reki-krolowej-letycji-6681064?source=rss](https://tvn24.pl/swiat/hiszpania-ambasador-iranu-nie-podal-reki-krolowej-letycji-6681064?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:23:12+00:00
 - user: None

<img alt="Ambasador Iranu nie podał ręki królowej Hiszpanii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-n5rmkl-krol-6681211/alternates/LANDSCAPE_1280" />
    Ambasador Iranu w Hiszpanii Hasan Ghaszghawi nie podał ręki królowej Letycji podczas corocznego spotkania pary królewskiej z korpusem dyplomatycznym w Pałacu Królewskim w Madrycie. Na uroczystości zabrakło przedstawicieli Rosji, Wenezueli i Nikaragui.

## Poprosili o pomoc, ratownicy dotarli do jednego turysty. Dwaj sami zeszli z gór
 - [https://tvn24.pl/krakow/topr-poprosili-o-pomoc-ratownicy-dotarli-do-jednego-turysty-dwaj-sami-zeszli-z-gor-6681122?source=rss](https://tvn24.pl/krakow/topr-poprosili-o-pomoc-ratownicy-dotarli-do-jednego-turysty-dwaj-sami-zeszli-z-gor-6681122?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 15:23:12+00:00
 - user: None

<img alt="Poprosili o pomoc, ratownicy dotarli do jednego turysty. Dwaj sami zeszli z gór" src="https://tvn24.pl/najnowsze/cdn-zdjecie-o28ogl-turysci-schodzacy-w-kierunku-zawratu-6681132/alternates/LANDSCAPE_1280" />
    Trzech turystów poprosiło telefonicznie ratowników TOPR o ewakuację śmigłowcem spod Świnicy. Twierdzili, że utknęli i nie są w stanie sami bezpiecznie zejść z gór. Kiedy okazało się, że maszyna z powodu mgły nie wystartuje, turyści postanowili sami zejść z gór.

## Janusz Szymik kontra kuria w sądzie. "Nie szukam zemsty, ale sprawiedliwego wyroku"
 - [https://tvn24.pl/katowice/bielsko-biala-proces-janusza-szymika-wykorzystywanego-przez-ksiedza-jana-wodniaka-przeciwko-kurii-bielsko-zywieckiej-zeznawala-kobieta-ktora-byla-w-tej-samej-grupie-oazowej-6679797?source=rss](https://tvn24.pl/katowice/bielsko-biala-proces-janusza-szymika-wykorzystywanego-przez-ksiedza-jana-wodniaka-przeciwko-kurii-bielsko-zywieckiej-zeznawala-kobieta-ktora-byla-w-tej-samej-grupie-oazowej-6679797?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 14:34:42+00:00
 - user: None

<img alt="Janusz Szymik kontra kuria w sądzie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hr4pfw-rozprawa-janusz-szymik-kontra-kuria-swiadek-byla-w-grupie-oazowej-jana-wodniaka-6681048/alternates/LANDSCAPE_1280" />
    W procesie Janusza Szymika, który miał być wykorzystywany przez proboszcza z Międzybrodzia Bialskiego, zeznawała kobieta, która w latach 80. należała do tej samej grupy oazowej. Byli wtedy nastolatkami. Opowiadała, że Szymik mówił do księdza "Jasiek", wyjeżdżał z nim za granicę, chodził sam na plebanię, miał do niej klucze. Mówiła, że całe życie młodzieżowe skupiało się wtedy wokół kościoła, który teraz jest pusty.

## Były burmistrz pił z kolegami alkohol. Odwożąc jednego z nich, wpadł do rowu. Usłyszał wyrok
 - [https://tvn24.pl/bialystok/pulawy-byly-burmistrz-kazimierza-dolnego-wjechal-pijany-do-rowu-uslyszal-nieprawomocny-wyrok-6680987?source=rss](https://tvn24.pl/bialystok/pulawy-byly-burmistrz-kazimierza-dolnego-wjechal-pijany-do-rowu-uslyszal-nieprawomocny-wyrok-6680987?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 14:28:35+00:00
 - user: None

<img alt="Były burmistrz pił z kolegami alkohol. Odwożąc jednego z nich, wpadł do rowu. Usłyszał wyrok " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u7jv4x-trzy-kolejne-badania-wykazaly-21-196-promila-alkoholu-w-organizmie-zdjecie-ilustracyjne-6680988/alternates/LANDSCAPE_1280" />
    Sześć miesięcy pozbawienia wolności w zawieszeniu na rok próby. Taki wyrok zapadł przed Sądem Rejonowym w Puławach (woj. lubelskie) wobec 61-letniego Andrzeja P., byłego burmistrza Kazimierza Dolnego, który prowadził auto po wypiciu alkoholu. Mężczyzna dostał też trzyletni zakaz prowadzenia pojazdów mechanicznych oraz ma zapłacić pięć tysięcy złotych. Wyrok nie jest prawomocny.

## "Nękał, groził śmiercią i zawiadamiał o przestępstwach, których nie było". Nie ukrywał swojego nazwiska
 - [https://tvn24.pl/wroclaw/boleslawiec-mieszkal-w-niemczech-stalkowal-w-polsce-pod-wlasnym-nazwiskiem-nekal-grozil-pozbawieniem-zycia-6681000?source=rss](https://tvn24.pl/wroclaw/boleslawiec-mieszkal-w-niemczech-stalkowal-w-polsce-pod-wlasnym-nazwiskiem-nekal-grozil-pozbawieniem-zycia-6681000?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 14:13:47+00:00
 - user: None

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5ojwq7-mezczyzna-zostal-zatrzymany-podczas-wizyty-w-polsce-6680055/alternates/LANDSCAPE_1280" />
    Mężczyzna na stałe mieszkający w Niemczech jest podejrzany o uporczywe nękanie i grożenie pozbawieniem życia kilku osób mieszkających w powiecie bolesławieckim (Dolnośląskie). 28-latek, który w szczególności za cel obrał sobie jedną kobietę, nawet nie próbował się ukrywać, wysyłał wiadomości pod własnym imieniem i nazwiskiem. Wpadł w ręce policji, kiedy przyjechał z wizytą do Polski.

## Przekroczone stany ostrzegawcze na rzekach. IMGW ostrzega
 - [https://tvn24.pl/tvnmeteo/pogoda/przekroczone-stany-ostrzegawcze-na-rzekach-imgw-ostrzega-6679665?source=rss](https://tvn24.pl/tvnmeteo/pogoda/przekroczone-stany-ostrzegawcze-na-rzekach-imgw-ostrzega-6679665?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 14:08:32+00:00
 - user: None

<img alt="Przekroczone stany ostrzegawcze na rzekach. IMGW ostrzega " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-r5fbhp-alerty-hydrologiczne-6551538/alternates/LANDSCAPE_1280" />
    W związku ze spływem wód opadowo-roztopowych Instytut Meteorologii i Gospodarki Wodnej (IMGW) wydał ostrzeżenia hydrologiczne drugiego stopnia. Miejscami przekroczone są stany ostrzegawcze i w jednym miejscu alarmowy.

## Kraków. Tak ma wyglądać Muzeum KL Plaszow
 - [https://tvn24.pl/krakow/krakow-tak-ma-wygladac-muzeum-kl-plaszow-6680931?source=rss](https://tvn24.pl/krakow/krakow-tak-ma-wygladac-muzeum-kl-plaszow-6680931?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 13:53:38+00:00
 - user: None

<img alt="Kraków. Tak ma wyglądać Muzeum KL Plaszow" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kt826b-memorial-wizualizacja-z-widokiem-od-ul-kamienskiego-6680924/alternates/LANDSCAPE_1280" />
    Na dziedzińcu krakowskiego Muzeum Podgórza zobaczyć można zobaczyć wizualizacje Muzeum KL Plaszow, które ma być gotowe w 2025 roku. - Przechodzimy do kluczowych inwestycji budowlanych - przekazuje Monika Bednarek, kierownik Muzeum Miejsca Pamięci KL Plaszow w Krakowie.

## Porwał kobietę, bił ją i przypalał gazowym palnikiem. Ofiara zdołała uciec przez okno
 - [https://tvn24.pl/swiat/usa-sammy-martz-porwal-kobiete-bil-ja-i-przypalal-gazowym-palnikiem-ofiara-zdolala-uciec-przez-okno-6679474?source=rss](https://tvn24.pl/swiat/usa-sammy-martz-porwal-kobiete-bil-ja-i-przypalal-gazowym-palnikiem-ofiara-zdolala-uciec-przez-okno-6679474?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 12:58:09+00:00
 - user: None

<img alt="Porwał kobietę, bił ją i przypalał gazowym palnikiem. Ofiara zdołała uciec przez okno" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ut0hcq-47-letni-sammy-martz-6679496/alternates/LANDSCAPE_1280" />
    47-letni Sammy Martz został oskarżony o porwanie kobiety, którą miał więzić i torturować przypalając palnikiem gazowym - w środę poinformowała policja z miasta Philippi w Wirginii Zachodniej. Ofierze udało się uciec przez okno niedługo przed tym, jak na miejsce wezwana została policja. W domu mężczyzny znaleziono "znaczną ilość" metamfetaminy.

## W progu płonącego domu stał starszy mężczyzna, w środku była jego żona. Uratowali oboje
 - [https://tvn24.pl/poznan/bialosliwie-policjanci-wydostali-80-latke-z-plonacego-domu-6679754?source=rss](https://tvn24.pl/poznan/bialosliwie-policjanci-wydostali-80-latke-z-plonacego-domu-6679754?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:56:26+00:00
 - user: None

<img alt="W progu płonącego domu stał starszy mężczyzna, w środku była jego żona. Uratowali oboje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e5284f-pozar-wybuchl-w-tym-budynku-6679747/alternates/LANDSCAPE_1280" />
    Gdyby nie szybka interwencja policjantów z Białośliwia (woj. wielkopolskie), którzy zauważyli gęste kłęby dymu wydostające się z jednego z domów i ruszyli tam z pomocą, kobieta mogłaby zginąć. Funkcjonariusze wyprowadzili 80-latkę jeszcze przed przyjazdem straży pożarnej.

## Pękła szyna. Utrudnienia na kolei w Warszawie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-na-kolei-przez-peknieta-szyne-6679669?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-utrudnienia-na-kolei-przez-peknieta-szyne-6679669?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:54:26+00:00
 - user: None

<img alt="Pękła szyna. Utrudnienia na kolei w Warszawie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ttdf4l-tory-kolejowe-5785405/alternates/LANDSCAPE_1280" />
    W Warszawie na podmiejskiej linii średnicowej pękła szyna. Jak informują Koleje Mazowieckie, niektóre pociągi mogą być opóźnione, odwołane lub ich trasy mogą być skrócone.

## Turecka partia opozycyjna może zostać zdelegalizowana. Sąd Najwyższy nie wstrzymał wyroku
 - [https://tvn24.pl/swiat/turcja-partia-opozycyjna-hdp-moze-zostac-zdelegalizowana-sad-najwyzszy-nie-wstrzymal-wyroku-6679695?source=rss](https://tvn24.pl/swiat/turcja-partia-opozycyjna-hdp-moze-zostac-zdelegalizowana-sad-najwyzszy-nie-wstrzymal-wyroku-6679695?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:52:14+00:00
 - user: None

<img alt="Turecka partia opozycyjna może zostać zdelegalizowana. Sąd Najwyższy nie wstrzymał wyroku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8yilph-protest-zwolennikow-hdp-6679703/alternates/LANDSCAPE_1280" />
    Sąd Najwyższy Turcji odmówił odłożenia w czasie wyroku na opozycyjną Ludową Partię Demokratyczną. Oznacza to, że na kilka miesięcy przed wyborami parlamentarnymi i prezydenckimi ugrupowanie może zostać zdelegalizowane.

## Urzędnicy pracują krócej, bo muszą oszczędzać prąd
 - [https://tvn24.pl/lodz/glowno-woj-lodzkie-urzednicy-pracuja-o-godzine-krocej-urzad-miejski-tak-szuka-oszczednosci-6679697?source=rss](https://tvn24.pl/lodz/glowno-woj-lodzkie-urzednicy-pracuja-o-godzine-krocej-urzad-miejski-tak-szuka-oszczednosci-6679697?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:47:56+00:00
 - user: None

<img alt="Urzędnicy pracują krócej, bo muszą oszczędzać prąd" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nl8njn-urzednicy-w-glownie-pracuja-o-godzine-krocej-6679721/alternates/LANDSCAPE_1280" />
    Urząd Miejski w Głownie w województwie łódzkim, jak każdy inny urząd w Polsce, musiał szybko znaleźć sposób na zmniejszenie zużycia prądu. Uznano, że najlepiej będzie pracować w biurach krócej. Dokładnie o godzinę. Urzędnicy pół godziny później zaczynają pracę i o pół godziny wcześniej kończą. Ich zarobki się nie zmieniły.

## Ellie Goulding i The Kid LAROI wystąpią na Orange Warsaw Festival
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-orange-warsaw-festival-2023-koncerty-the-kid-laroi-i-ellie-goulding-6679176?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-orange-warsaw-festival-2023-koncerty-the-kid-laroi-i-ellie-goulding-6679176?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:36:40+00:00
 - user: None

<img alt="Ellie Goulding i The Kid LAROI wystąpią na Orange Warsaw Festival" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s01l1f-ellie-goulding-6679170/alternates/LANDSCAPE_1280" />
    Organizatorzy Orange Warsaw Festival ujawnili, że do line-upu imprezy dołączyli Ellie Goulding i The Kid LAROI. Festiwal odbędzie się 2 i 3 czerwca na Torze Wyścigów Konnych na Służewcu.

## Motocyklista wjechał w łańcuch na drodze, zginął na miejscu
 - [https://tvn24.pl/krakow/stepina-prokuratura-umorzyla-sledztwo-w-sprawie-tragicznego-wypadku-motocyklisty-6679520?source=rss](https://tvn24.pl/krakow/stepina-prokuratura-umorzyla-sledztwo-w-sprawie-tragicznego-wypadku-motocyklisty-6679520?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:28:30+00:00
 - user: None

<img alt="Motocyklista wjechał w łańcuch na drodze, zginął na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b0en0k-wypadek-w-kocierzu-moszczanickim-nie-zyje-motocyklista-i-jego-pasazerka-4648641/alternates/LANDSCAPE_1280" />
    Zakończyło się śledztwo w sprawie śmiertelnego wypadku 21-letniego motocyklisty, do którego doszło w Stępinie na Podkarpaciu. Młody chłopak wjechał crossem w metalowy łańcuch zabezpieczający wjazd na teren żwirowni. Zginął na miejscu.

## Latały śmigłowcem, ścigały pozorantów i zdobyły Śnieżkę. Policyjne psy ćwiczyły w Karkonoszach
 - [https://tvn24.pl/wroclaw/lataly-smiglowcem-scigaly-pozorantow-i-zdobyly-sniezke-policyjnepsycwiczyly-w-karkonoszach-6679356?source=rss](https://tvn24.pl/wroclaw/lataly-smiglowcem-scigaly-pozorantow-i-zdobyly-sniezke-policyjnepsycwiczyly-w-karkonoszach-6679356?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:21:46+00:00
 - user: None

<img alt="Latały śmigłowcem, ścigały pozorantów i zdobyły Śnieżkę. Policyjne psy ćwiczyły w Karkonoszach" src="https://tvn24.pl/wroclaw/cdn-zdjecie-wsjoij-policyjnepsybojowecwiczyly-w-karkonoszach-6679401/alternates/LANDSCAPE_1280" />
    Przewodnicy psów i ich podopieczni przeszli intensywne szkolenie w Karkonoszach. Podczas czterodniowego treningu ćwiczyli między innymi wykorzystanie psów w terenach leśnych czy w pościgu za groźnym przestępcą. Zwierzęta musiały też odbyć lot na pokładzie śmigłowca i wspiąć się na Śnieżkę.

## Załamanie na rynku kredytów mieszkaniowych. Są nowe dane
 - [https://tvn24.pl/biznes/nieruchomosci/kredyty-mieszkaniowe-2022-banki-udzielily-o-polowe-mniej-kredytow-hipotecznych-dane-bik-6679585?source=rss](https://tvn24.pl/biznes/nieruchomosci/kredyty-mieszkaniowe-2022-banki-udzielily-o-polowe-mniej-kredytow-hipotecznych-dane-bik-6679585?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:21:10+00:00
 - user: None

<img alt="Załamanie na rynku kredytów mieszkaniowych. Są nowe dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ml5iz-mieszkania-w-polsce-nieruchomosci-kredyty-6195130/alternates/LANDSCAPE_1280" />
    Banki w 2022 roku udzieliły łącznie 133,3 tysiąca kredytów hipotecznych. Oznacza to spadek o 51,4 procent w porównaniu do poprzedniego roku - wynika z danych Biura Informacji Kredytowej. Zdaniem Mariusza Cholewy, prezesa BIK "ożywienie popytu w 2023 roku byłoby możliwe w przypadku wzrostu zdolności kredytowej, a także stabilizacji cen nieruchomości".

## Uderzył w dom i praktycznie wjechał do pokoju
 - [https://tvn24.pl/wroclaw/milicz-kierowca-mercedesa-wjechal-komus-do-domu-6679627?source=rss](https://tvn24.pl/wroclaw/milicz-kierowca-mercedesa-wjechal-komus-do-domu-6679627?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 11:16:27+00:00
 - user: None

<img alt="Uderzył w dom i praktycznie wjechał do pokoju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j5i0tk-mercedes-zrobil-dziure-w-scianie-6679509/alternates/LANDSCAPE_1280" />
    W Miliczu na Dolnym Śląsku w ścianę jednego z domów jednorodzinnych uderzył osobowy mercedes. Auto praktycznie wjechało do pokoju.

## Po niegroźnej kolizji uciekł do lasu. Miał 15-letni zakaz prowadzenia i był poszukiwany
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wolka-pecherska-piaseczno-zatrzymany-kierowca-mial-przy-sobie-narkotyki-mial-zakaz-byl-poszukiwany-6679267?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wolka-pecherska-piaseczno-zatrzymany-kierowca-mial-przy-sobie-narkotyki-mial-zakaz-byl-poszukiwany-6679267?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 10:37:00+00:00
 - user: None

<img alt="Po niegroźnej kolizji uciekł do lasu. Miał 15-letni zakaz prowadzenia i był poszukiwany" src="https://tvn24.pl/krakow/cdn-zdjecie-fa8j0f-mezczyzna-uslyszal-zarzuty-i-zostal-aresztowany-6679268/alternates/LANDSCAPE_1280" />
    36-letni mężczyzna po spowodowaniu kolizji uciekł pieszo do lasu. Gdy wytropili go policjanci, okazało się, że uciekinier ma przy sobie narkotyki i nie powinien wsiadać za kierownicę z powodu orzeczonego przez sąd 15-letniego zakazu. Na sumieniu miał zresztą więcej.

## Francja odwołuje ambasadora w Burkina Faso, wcześniej wycofała wojsko
 - [https://tvn24.pl/swiat/francja-msz-odwolujemy-ambasadora-w-burkina-faso-6679427?source=rss](https://tvn24.pl/swiat/francja-msz-odwolujemy-ambasadora-w-burkina-faso-6679427?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 10:34:25+00:00
 - user: None

<img alt="Francja odwołuje ambasadora w Burkina Faso, wcześniej wycofała wojsko " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f1rf4q-stolica-burkina-faso-wagadugu-6679490/alternates/LANDSCAPE_1280" />
    Francuskie ministerstwo spraw zagranicznych poinformowało, że odwołało ambasadora Francji w Burkina Faso. "Zdecydowaliśmy o powrocie naszego ambasadora do Paryża, aby przeprowadzić konsultacje na temat stanu i perspektyw naszej dwustronnej współpracy" - podał resort dyplomacji w komunikacie. Dzień wcześniej Francja ogłosiła wycofanie swoich wojsk z leżącego w Afryce zachodniej kraju.

## Autem osobowym wjechał w ciężarówkę
 - [https://tvn24.pl/tvnwarszawa/najnowsze/urzut-s8-oplem-wjechal-w-ciezarowke-auto-kompletnie-zniszczone-kierowca-w-szpitalu-6679339?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/urzut-s8-oplem-wjechal-w-ciezarowke-auto-kompletnie-zniszczone-kierowca-w-szpitalu-6679339?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 10:30:29+00:00
 - user: None

<img alt="Autem osobowym wjechał w ciężarówkę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ofpama-zderzenie-na-s8-w-miejscowosci-urzut-6679391/alternates/LANDSCAPE_1280" />
    W nocy z środy na czwartek na trasie S8 w miejscowości Urzut doszło do groźnie wyglądającego zdarzenia. Auto osobowe uderzyło w tył ciężarówki. Połowa pojazdu została zmiażdżona. Jak podaje straż pożarna, jedna osoba została zabrana do szpitala.

## Wilk wpadł we wnyki kłusowników. "Nie miał szans się wydostać"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/adamowo-wilk-wpadl-we-wnyki-klusownikow-6679076?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/adamowo-wilk-wpadl-we-wnyki-klusownikow-6679076?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 08:46:59+00:00
 - user: None

<img alt="Wilk wpadł we wnyki kłusowników. " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-c6gpss-wilk-wpadl-we-wnyki-rozstawione-w-lesie-pod-mlawa-6679077/alternates/LANDSCAPE_1280" />
    W lesie niedaleko Mławy były leśniczy znalazł rannego wilka, który wpadł we wnyki kłusowników. Ranne, wycieńczone i odwodnione zwierzę dochodzi do siebie w ośrodku rehabilitacji.

## Auto hybrydowe, rowery, zegarki. Ratusz zachęca do płacenia podatków w stolicy i organizuje loterię
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nagrody-za-podatki-auto-hybrydowe-rowery-zegarki-loteria-ratusza-6678091?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nagrody-za-podatki-auto-hybrydowe-rowery-zegarki-loteria-ratusza-6678091?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 06:37:32+00:00
 - user: None

<img alt="Auto hybrydowe, rowery, zegarki. Ratusz zachęca do płacenia podatków w stolicy i organizuje loterię" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dy44e5-warszawa-panorama-palac-kultury-5086778/alternates/LANDSCAPE_1280" />
    Miasta walczą o podatki, a podatników kuszą nagrodami. W warszawskiej loterii można wygrać samochód hybrydowy, rowery lub zegarki. Urzędnicy przypominają: to, że ktoś gdzieś mieszka, wcale nie oznacza, że tam się rozlicza. Materiał programu "Polska i Świat".

## W Arktyce odnaleziono szczątki krewniaków ssaków naczelnych. Liczą 52 miliony lat
 - [https://tvn24.pl/tvnmeteo/nauka/w-arktyce-odnaleziono-szczatki-krewniakow-ssakow-naczelnych-licza-52-miliony-lat-6678140?source=rss](https://tvn24.pl/tvnmeteo/nauka/w-arktyce-odnaleziono-szczatki-krewniakow-ssakow-naczelnych-licza-52-miliony-lat-6678140?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 06:29:46+00:00
 - user: None

<img alt="W Arktyce odnaleziono szczątki krewniaków ssaków naczelnych. Liczą 52 miliony lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cc1vsb-arktyka-6142762/alternates/LANDSCAPE_1280" />
    Amerykańscy naukowcy odkryli na obszarze głębokiej Arktyki prehistoryczne szczątki krewniaków naczelnych. Znalezione skamieniałości mają 52 miliony lat i pochodzą z okresu eocenu. Badania zostały opublikowane na łamach "Public Library of Science ONE".

## Finlandia zaaprobowała sprzedaż materiałów wojskowych dla Turcji, po raz pierwszy od 2019 roku
 - [https://tvn24.pl/swiat/finlandia-zaaprobowala-sprzedaz-materialow-wojskowych-dla-turcji-po-raz-pierwszy-od-2019-roku-6673675?source=rss](https://tvn24.pl/swiat/finlandia-zaaprobowala-sprzedaz-materialow-wojskowych-dla-turcji-po-raz-pierwszy-od-2019-roku-6673675?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 05:24:06+00:00
 - user: None

<img alt="Finlandia zaaprobowała sprzedaż materiałów wojskowych dla Turcji, po raz pierwszy od 2019 roku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l9yide-gmach-finskiego-parlamentu-5712732/alternates/LANDSCAPE_1280" />
    Władze Finlandii wyraziły zgodę na sprzedaż Turcji materiałów wojskowych. Jesienią 2019 roku Helsinki zawiesiły eksport takich towarów ze względu na turecką ofensywę w Syrii - przypomina agencja AFP.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6677787?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-6677787?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 05:00:19+00:00
 - user: None

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3gqlt1-cwiczenia-rosyjskiego-wojska-6645725/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa 337. dzień. Rosyjska Federalna Służba Bezpieczeństwa (FSB) próbuje werbować wpływowych ukraińskich przestępców, którzy aktualnie przebywają w Zjednoczonych Emiratach Arabskich - poinformował Ołeksij Daniłow, sekretarz ukraińskiej Rady Bezpieczeństwa i Obrony (RBNiO). Oto najważniejsze wydarzenia ostatnich godzin.

## Pogoda na dziś - czwartek, 26.01. Lokalnie popada śnieg i śnieg z deszczem
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-czwartek-2601-lokalnie-popada-snieg-i-snieg-z-deszczem-6669368?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-czwartek-2601-lokalnie-popada-snieg-i-snieg-z-deszczem-6669368?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-01-26 01:00:00+00:00
 - user: None

<img alt="Pogoda na dziś - czwartek, 26.01. Lokalnie popada śnieg i śnieg z deszczem" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ztl1u8-popada-snieg-6233814/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Na czwartek 26.01 prognozuje się pochmurną aurę z niewielkimi przejaśnieniami. Miejscami pojawi się słaby śnieg i śnieg z deszczem. Termometry pokażą od 0 do 2 stopni Celsjusza. Aura niekorzystnie wpłynie na nasze samopoczucie.
