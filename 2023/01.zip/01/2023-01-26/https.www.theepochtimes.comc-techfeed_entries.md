# Source Epoch Times Tech, Source URL:https://www.theepochtimes.com/c-tech/feed/, Source language: en-US

## US Infiltrates Big Ransomware Gang: ‘We Hacked the Hackers’
 - [https://www.theepochtimes.com/us-infiltrates-big-ransomware-gang-we-hacked-the-hackers_5013202.html](https://www.theepochtimes.com/us-infiltrates-big-ransomware-gang-we-hacked-the-hackers_5013202.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 21:42:39+00:00
 - user: None

Deputy Attorney General Lisa Monaco (C) flanked by Attorney General Merrick Garland (L) and FBI Director Christopher Wray (R) speaks during a news conference to announce an international ransomware enforcement action at the Department of Justice in Washington on Jan. 26, 2023. (Jose Luis Magana/AP Photo)

## BuzzFeed Shares Soar 150 Percent After Publisher Plans to Use ChatGPT Creator OpenAI for Content
 - [https://www.theepochtimes.com/buzzfeed-shares-soar-150-percent-after-publisher-plans-to-use-chatgpt-creator-openai-for-content_5013219.html](https://www.theepochtimes.com/buzzfeed-shares-soar-150-percent-after-publisher-plans-to-use-chatgpt-creator-openai-for-content_5013219.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 19:46:19+00:00
 - user: None

Buzzfeed employees work at the company’s headquarters in New York, on Jan. 9, 2014. (Brendan McDermid/Reuters)

## Artificial Intelligence Could Make These Jobs Obsolete: ‘Not Crying Wolf’
 - [https://www.theepochtimes.com/artificial-intelligence-could-make-these-jobs-obsolete-not-crying-wolf_5012854.html](https://www.theepochtimes.com/artificial-intelligence-could-make-these-jobs-obsolete-not-crying-wolf_5012854.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 19:24:10+00:00
 - user: None

"Han the Robot" waits on stage before a discussion about the future of humanity in a demonstration of artificial intelligence (AI) by Hanson Robotics at the RISE Technology Conference in Hong Kong on July 12, 2017.
(Isaac Lawrence/AFP/Getty Images)

## Democrats Criticize Meta for Reinstating Trump’s Facebook and Instagram Accounts
 - [https://www.theepochtimes.com/democrats-criticize-meta-for-reinstating-trumps-facebook-and-instagram-accounts_5012069.html](https://www.theepochtimes.com/democrats-criticize-meta-for-reinstating-trumps-facebook-and-instagram-accounts_5012069.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 10:54:49+00:00
 - user: None

A smartphone with Facebook's logo is seen with new rebrand logo Meta in this illustration taken on Oct. 28, 2021. (Dado Ruvic/Reuters)

## FBI Says North Korea-Related Hacker Group Behind US Crypto Firm Heist
 - [https://www.theepochtimes.com/fbi-says-north-korea-related-hacker-group-behind-us-crypto-firm-heist_5006981.html](https://www.theepochtimes.com/fbi-says-north-korea-related-hacker-group-behind-us-crypto-firm-heist_5006981.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 06:47:20+00:00
 - user: None

A North Korean flag flutters at the propaganda village of Gijungdong in North Korea, in this picture taken near the truce village of Panmunjom inside the demilitarized zone (DMZ) separating the two Koreas, in South Korea on July 19, 2022.  (Kim Hong-Ji/Pool/Reuters)

## Microsoft Cloud Outage Hits Users Around the World
 - [https://www.theepochtimes.com/microsoft-cloud-outage-hits-users-around-the-world_5009341.html](https://www.theepochtimes.com/microsoft-cloud-outage-hits-users-around-the-world_5009341.html)
 - RSS feed: https://www.theepochtimes.com/c-tech/feed/
 - date published: 2023-01-26 04:30:38+00:00
 - user: None

Microsoft Teams app on the smartphone placed on the keyboard on July 26, 2021. (Dado Ruvic/Illustration/Reuters)
