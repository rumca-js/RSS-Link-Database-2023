# Source CNET, Source URL:https://www.cnet.com/rss/all/, Source language: en-US

## Got Social Security Problems? Here's How to Resolve Them     - CNET
 - [https://www.cnet.com/personal-finance/got-social-security-problems-heres-how-to-resolve-them/#ftag=CADf328eec](https://www.cnet.com/personal-finance/got-social-security-problems-heres-how-to-resolve-them/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 23:35:02+00:00
 - user: None

When a Google search doesn't address your Social Security questions, it's best to get in touch with the Social Security Administration itself. Here's how.

## Score Cheap Eggs and Other Groceries With These Discount Services     - CNET
 - [https://www.cnet.com/how-to/cheap-eggs-and-other-groceries-with-these-discount-delivery-services/#ftag=CADf328eec](https://www.cnet.com/how-to/cheap-eggs-and-other-groceries-with-these-discount-delivery-services/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 23:12:00+00:00
 - user: None

These budget-friendly online grocery services just might be your best defense against stubborn food prices.

## This Bear Really Knows How to Take a Selfie     - CNET
 - [https://www.cnet.com/science/biology/this-bear-really-knows-how-to-take-a-selfie/#ftag=CADf328eec](https://www.cnet.com/science/biology/this-bear-really-knows-how-to-take-a-selfie/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 23:08:00+00:00
 - user: None

This animal is clearly angling to become an online influencer.

## Best Streaming Services for Horror Fans     - CNET
 - [https://www.cnet.com/tech/services-and-software/best-streaming-services-horror-fans/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/best-streaming-services-horror-fans/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 23:00:03+00:00
 - user: None

Enjoy a good good scare or slasher fest every now and then? Here's where to stream horror flicks 24/7.

## 2,300-Year-Old Egyptian Mummy Covered in Gold Unwrapped After Century in Basement     - CNET
 - [https://www.cnet.com/science/biology/2300-year-old-egyptian-mummy-covered-in-gold-unwrapped-after-century-in-basement/#ftag=CADf328eec](https://www.cnet.com/science/biology/2300-year-old-egyptian-mummy-covered-in-gold-unwrapped-after-century-in-basement/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 22:32:54+00:00
 - user: None

Digitally unwrapping the mummy of a teenage boy for the first time, researchers find dozens of amulets -- and a pair of sandals.

## DOJ Stops Hive Ransomeware Network video     - CNET
 - [https://www.cnet.com/videos/doj-stops-hive-ransomeware-network/#ftag=CADf328eec](https://www.cnet.com/videos/doj-stops-hive-ransomeware-network/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 22:30:18+00:00
 - user: None

The DOJ said it stopped victims, including hospitals, schools and infrastructure operators worldwide, from paying $130 million in ransom.

## More People Should Watch This Shocking Crime Documentary on Netflix     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-should-watch-this-shocking-crime-documentary-on-netflix/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-should-watch-this-shocking-crime-documentary-on-netflix/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 21:52:00+00:00
 - user: None

But The Hatchet-Wielding Hitchhiker is less about true crime than it is about our lives on the internet.

## Composting Is So Over. This New Bin Turns Kitchen Scraps Into Chicken Feed     - CNET
 - [https://www.cnet.com/news/can-a-high-tech-trash-solve-our-food-waste-problem/#ftag=CADf328eec](https://www.cnet.com/news/can-a-high-tech-trash-solve-our-food-waste-problem/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 21:22:00+00:00
 - user: None

The high-tech Mill kitchen bin is taking aim at food waste. It even processes those pesky scraps not suitable for composting.

## How to Watch Earth's Extremely Close Encounter With an Asteroid Today     - CNET
 - [https://www.cnet.com/science/space/how-to-watch-earths-extremely-close-encounter-with-an-asteroid-today/#ftag=CADf328eec](https://www.cnet.com/science/space/how-to-watch-earths-extremely-close-encounter-with-an-asteroid-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 21:10:00+00:00
 - user: None

NASA says it poses no threat, but will make the top five list of near misses.

## Record Scratch: Spotify Recovering After Outage     - CNET
 - [https://www.cnet.com/tech/services-and-software/record-scratch-spotify-was-down-for-many-users-thursday/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/record-scratch-spotify-was-down-for-many-users-thursday/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 20:46:00+00:00
 - user: None

Spotify tweeted around 12:40 p.m. PT Thursday that the situation is "much better"

## Record Scratch: Spotify Is Down Right Now     - CNET
 - [https://www.cnet.com/tech/services-and-software/record-scratch-spotify-is-down-right-now/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/record-scratch-spotify-is-down-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:58:20+00:00
 - user: None

"Something's not quite right," the service wrote on Twitter.

## NASA Webb Telescope May Have Found Ingredients for Life in an Ice Cloud     - CNET
 - [https://www.cnet.com/science/space/nasa-webb-mightve-found-ingredients-for-life-in-a-cold-dark-cloud/#ftag=CADf328eec](https://www.cnet.com/science/space/nasa-webb-mightve-found-ingredients-for-life-in-a-cold-dark-cloud/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:41:00+00:00
 - user: None

Perhaps we aren't as unique as we thought.

## Earfun's New Air Pro 3 Earbuds Deliver Impressive Sound -- and They're Already 30% Off     - CNET
 - [https://www.cnet.com/deals/earfuns-new-air-pro-3-earbuds-deliver-impressive-sound-and-theyre-already-30-off/#ftag=CADf328eec](https://www.cnet.com/deals/earfuns-new-air-pro-3-earbuds-deliver-impressive-sound-and-theyre-already-30-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:32:00+00:00
 - user: None

Launching Jan. 30, you can pick up the Earfun Air Pro 3 noise-canceling wireless earbuds for $56 in an early-bird sale. They're a very good value at that price.

## M&Ms Spokescandies Controversy: How Things Got So Sticky     - CNET
 - [https://www.cnet.com/culture/m-ms-spokescandies-controversy-how-things-got-so-sticky/#ftag=CADf328eec](https://www.cnet.com/culture/m-ms-spokescandies-controversy-how-things-got-so-sticky/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:31:00+00:00
 - user: None

It seems likely it's all a Super Bowl publicity stunt, and Maya Rudolph won't permanently replace the candies.

## Bear Snaps 400 Selfies in One Night With Wildlife Camera     - CNET
 - [https://www.cnet.com/science/biology/bear-snaps-400-selfies-in-one-night-with-wildlife-camera/#ftag=CADf328eec](https://www.cnet.com/science/biology/bear-snaps-400-selfies-in-one-night-with-wildlife-camera/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:23:00+00:00
 - user: None

This animal is clearly angling to become an online influencer.

## 'Succession' Season 4 Trailer: 'If It Hurts Him That Doesn't Bother Me'     - CNET
 - [https://www.cnet.com/culture/entertainment/succession-season-4-trailer-if-it-hurts-him-that-doesnt-bother-me/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/succession-season-4-trailer-if-it-hurts-him-that-doesnt-bother-me/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:17:00+00:00
 - user: None

HBO's hit family drama also gets a release date in March.

## 83 Restaurants That Offer Free Food on Your Birthday     - CNET
 - [https://www.cnet.com/deals/restaurants-offer-free-food-on-your-birthday/#ftag=CADf328eec](https://www.cnet.com/deals/restaurants-offer-free-food-on-your-birthday/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 19:00:14+00:00
 - user: None

From Applebee's to Zaxby's, these national chains offer special treats to celebrate your big day.

## iOS 17 Rumored to Support Apple's AR/VR Headset     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-17-rumored-to-support-apples-ar-vr-headset/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-17-rumored-to-support-apples-ar-vr-headset/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:54:33+00:00
 - user: None

There are also rumors that changes could come to the Mail, Reminders and Files apps.

## How to Find the Absolute Weirdest Spectacles on Google Street View     - CNET
 - [https://www.cnet.com/science/how-to-find-the-absolute-weirdest-spectacles-on-google-street-view/#ftag=CADf328eec](https://www.cnet.com/science/how-to-find-the-absolute-weirdest-spectacles-on-google-street-view/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:44:00+00:00
 - user: None

With a new program, you can enjoy hundreds of strange, creepy, cute and artsy Google Street View sights.

## That Leftover Rice Should Probably Be Thrown Away. Here's Why     - CNET
 - [https://www.cnet.com/how-to/that-leftover-rice-should-probably-be-thrown-away-heres-why/#ftag=CADf328eec](https://www.cnet.com/how-to/that-leftover-rice-should-probably-be-thrown-away-heres-why/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:35:02+00:00
 - user: None

You could be saving yourself from possible food poisoning.

## Audi Activesphere Is a Mighty Morphin' EV Coupe That's Also a Pickup     - CNET
 - [https://www.cnet.com/roadshow/news/audi-activesphere-is-a-mighty-morphin-ev-coupe-thats-also-a-pickup/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/audi-activesphere-is-a-mighty-morphin-ev-coupe-thats-also-a-pickup/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:30:02+00:00
 - user: None

The electric concept transforms its body from a tall coupe to a sporty, all-terrain pickup and moving its cabin tech into the virtual world.

## Audi Activesphere Is a Transforming All-Terrain EV     - CNET
 - [https://www.cnet.com/roadshow/pictures/audi-activesphere-is-a-transforming-all-terrain-ev/#ftag=CADf328eec](https://www.cnet.com/roadshow/pictures/audi-activesphere-is-a-transforming-all-terrain-ev/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:30:01+00:00
 - user: None

Like the Skysphere concept that came before it, the new Audi Activesphere is something of a transformer itself.

## Audi Activesphere: EV Coupe That's Also a Pickup video     - CNET
 - [https://www.cnet.com/roadshow/videos/audi-activesphere-ev-coupe-thats-also-a-pickup/#ftag=CADf328eec](https://www.cnet.com/roadshow/videos/audi-activesphere-ev-coupe-thats-also-a-pickup/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:30:01+00:00
 - user: None

Audi's new concept battery electric coupe reshapes its body on-demand for improved off-road utility and reimagines the cabin with augmented reality inspired by science fiction.

## Why I'm Excited About the OnePlus 11 5G     - CNET
 - [https://www.cnet.com/tech/mobile/why-im-excited-about-the-oneplus-11-5g/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/why-im-excited-about-the-oneplus-11-5g/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:29:19+00:00
 - user: None

The new phone could be the first time we see actual new camera hardware resulting from OnePlus' partnership with Hasselblad.

## Robots Fitted With Live Locust Antennae Could Be the Next Sniffer Dogs     - CNET
 - [https://www.cnet.com/science/biology/robots-fitted-with-live-locust-antennae-could-be-the-next-sniffer-dogs/#ftag=CADf328eec](https://www.cnet.com/science/biology/robots-fitted-with-live-locust-antennae-could-be-the-next-sniffer-dogs/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:13:00+00:00
 - user: None

So far, a sniffing cyborg out of Israel can successfully "smell" things like whiskey, marzipan and lemons.

## Scientists Find Elusive, Grumpy-Looking Cats Living on Mount Everest     - CNET
 - [https://www.cnet.com/science/biology/scientists-find-elusive-grumpy-looking-cats-living-on-mount-everest/#ftag=CADf328eec](https://www.cnet.com/science/biology/scientists-find-elusive-grumpy-looking-cats-living-on-mount-everest/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:10:00+00:00
 - user: None

Pallas's cats have made a home on one of the world's most challenging peaks.

## Play On With $550 Off This 17-Inch Gaming Laptop -- Today Only     - CNET
 - [https://www.cnet.com/deals/play-on-with-550-off-this-17-inch-gaming-laptop-today-only/#ftag=CADf328eec](https://www.cnet.com/deals/play-on-with-550-off-this-17-inch-gaming-laptop-today-only/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:06:45+00:00
 - user: None

Immerse yourself in the game with the Pulse GL76 gaming laptop from MSI for just $799 during this 1-day deal.

## NFL Playoffs 2023: Bracket, Schedule and How to Watch and Stream Games With or Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-playoffs-2023-bracket-schedule-and-how-to-watch-and-stream-games-with-or-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-playoffs-2023-bracket-schedule-and-how-to-watch-and-stream-games-with-or-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:00:13+00:00
 - user: None

A trip to the Super Bowl will be on the line this weekend.

## Here's How to Pick the Best Seat for Your Flight This Year     - CNET
 - [https://www.cnet.com/personal-finance/heres-how-to-pick-the-best-seat-for-your-flight-this-year/#ftag=CADf328eec](https://www.cnet.com/personal-finance/heres-how-to-pick-the-best-seat-for-your-flight-this-year/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 18:00:08+00:00
 - user: None

Here are six tips to help you get the best seat possible.

## New iOS Tech Makes It Super Hard to Hack Your iCloud Login     - CNET
 - [https://www.cnet.com/tech/mobile/new-ios-tech-makes-it-super-hard-to-hack-your-icloud-login/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/new-ios-tech-makes-it-super-hard-to-hack-your-icloud-login/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:57:00+00:00
 - user: None

Hardware security keys are the most secure way to lock down your online accounts. They aren't for everyone, though.

## Clearing Your Android Web Browser's Cookies, Cache Is a Fast Way to Clear Junk Files     - CNET
 - [https://www.cnet.com/tech/mobile/clearing-your-android-web-browsers-cookies-cache-is-a-fast-way-to-clear-junk-files/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/clearing-your-android-web-browsers-cookies-cache-is-a-fast-way-to-clear-junk-files/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:54:26+00:00
 - user: None

You use your web browser a lot, but you don't need to keep all of the files that build up inside of that app.

## 'Shazam: Fury of the Gods' Trailer Builds DC Superhero Magic, With a Dragon     - CNET
 - [https://www.cnet.com/culture/entertainment/shazam-fury-of-the-gods-trailer-builds-dc-superhero-magic-with-a-dragon/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/shazam-fury-of-the-gods-trailer-builds-dc-superhero-magic-with-a-dragon/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:51:00+00:00
 - user: None

Following Black Adam, return to the DC universe in March with Shazam 2.

## How to Prevent Seasonal Affective Disorder and 4 Ways to Manage It     - CNET
 - [https://www.cnet.com/health/how-to-prevent-seasonal-affective-disorder-and-4-ways-to-manage-it/#ftag=CADf328eec](https://www.cnet.com/health/how-to-prevent-seasonal-affective-disorder-and-4-ways-to-manage-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:30:02+00:00
 - user: None

Let's talk about the signs, symptoms and treatment for seasonal depression.

## The Dead Space Remake May Be the Best Video Game Remake Ever     - CNET
 - [https://www.cnet.com/tech/gaming/the-dead-space-remake-may-be-the-best-video-game-remake-ever/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/the-dead-space-remake-may-be-the-best-video-game-remake-ever/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:23:00+00:00
 - user: None

Commentary: The king of sci-fi horror is back.

## Republic Bank & Trust: 2023 Home Equity Review     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/republic-bank-trust-home-equity-review/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/republic-bank-trust-home-equity-review/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:14:19+00:00
 - user: None

If you live in the South or Midwest, you may be able to secure a larger HELOC with this bank -- but look elsewhere for a home equity loan.

## Everyone Should Know Their Blood Type: Here's 3 Ways to Find Yours Out     - CNET
 - [https://www.cnet.com/health/medical/everyone-should-know-their-blood-type-heres-3-ways-to-find-yours-out/#ftag=CADf328eec](https://www.cnet.com/health/medical/everyone-should-know-their-blood-type-heres-3-ways-to-find-yours-out/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:10:03+00:00
 - user: None

How do you figure out blood type if you don't already know it? Luckily, it's pretty easy.

## 'Shazam: Fury of the Gods' Trailer Builds DC Superhero Magic     - CNET
 - [https://www.cnet.com/culture/entertainment/shazam-fury-of-the-gods-trailer-builds-dc-superhero-magic/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/shazam-fury-of-the-gods-trailer-builds-dc-superhero-magic/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:05:00+00:00
 - user: None

Following Black Adam, return to the DC universe in March.

## Feds vs. Google: What DOJ's Antitrust Lawsuit Means for Online Ads     - CNET
 - [https://www.cnet.com/tech/feds-vs-google-what-dojs-antitrust-lawsuit-means-for-online-ads/#ftag=CADf328eec](https://www.cnet.com/tech/feds-vs-google-what-dojs-antitrust-lawsuit-means-for-online-ads/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:04:00+00:00
 - user: None

The Justice Department wants split off Google's online ad business, a move that would dry up a big source of revenue.

## More People Need to Watch One of 2022's Best Horror Films     - CNET
 - [https://www.cnet.com/culture/entertainment/more-people-need-to-watch-one-of-2022s-best-horror-films/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/more-people-need-to-watch-one-of-2022s-best-horror-films/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:03:15+00:00
 - user: None

Watch if you love a Stranger Things vibe.

## GoldenEye 007 Comes to Nintendo Switch, Xbox on Friday     - CNET
 - [https://www.cnet.com/tech/gaming/goldeneye-007-comes-to-nintendo-switch-xbox-on-friday/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/goldeneye-007-comes-to-nintendo-switch-xbox-on-friday/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 17:01:34+00:00
 - user: None

The iconic 1997 Nintendo 64 first-person shooter brings classic James Bond action to Nintendo Switch Online and Xbox Game Pass.

## Department of Justice Takes Down Major Ransomware Group Hive     - CNET
 - [https://www.cnet.com/tech/services-and-software/department-of-justice-takes-down-major-ransomware-group-hive/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/department-of-justice-takes-down-major-ransomware-group-hive/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:59:41+00:00
 - user: None

The DOJ said is stopped over $100 million worth of ransoms from being paid.

## 'Doom Patrol' and 'Titans' Cancelled by HBO     - CNET
 - [https://www.cnet.com/culture/entertainment/doom-patrol-and-titans-cancelled-by-hbo/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/doom-patrol-and-titans-cancelled-by-hbo/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:57:46+00:00
 - user: None

It wasn't James Gunn's idea.

## How to Watch, Stream the Australian Open Semifinals Tonight Without Cable     - CNET
 - [https://www.cnet.com/tech/home-entertainment/how-to-watch-stream-the-australian-open-semifinals-tonight-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/home-entertainment/how-to-watch-stream-the-australian-open-semifinals-tonight-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:33:02+00:00
 - user: None

American Tommy Paul takes on Novak Djokovic in one semifinal match, and Stefanos Tsitsipas faces Karen Khachanov in the other.

## IBM Cuts Thousands of Employees in Latest Tech Layoffs     - CNET
 - [https://www.cnet.com/tech/computing/ibm-cuts-thousands-of-employees-in-latest-tech-layoffs/#ftag=CADf328eec](https://www.cnet.com/tech/computing/ibm-cuts-thousands-of-employees-in-latest-tech-layoffs/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:29:00+00:00
 - user: None

The job cuts follow the computing giant spinning off parts of its business.

## 'Succession' Season 4 Trailer and Release Date: 'If It Hurts Him That Doesn't Bother Me'     - CNET
 - [https://www.cnet.com/culture/entertainment/succession-season-4-trailer-and-release-date-if-it-hurts-him-that-doesnt-bother-me/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/succession-season-4-trailer-and-release-date-if-it-hurts-him-that-doesnt-bother-me/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:20:00+00:00
 - user: None

"This is a tightrope walk on a straight razor... Why is that making you smile?"

## Hit Your Wellness Goals With Up to 50% Off Amazon Halo Devices     - CNET
 - [https://www.cnet.com/deals/hit-your-wellness-goals-with-up-to-50-off-amazon-halo-devices/#ftag=CADf328eec](https://www.cnet.com/deals/hit-your-wellness-goals-with-up-to-50-off-amazon-halo-devices/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:14:00+00:00
 - user: None

The swimproof Halo Band and Halo View fitness trackers are solid Fitbit alternatives that can help you stay motivated this year.

## Best Tripod for Photography and Video in 2023     - CNET
 - [https://www.cnet.com/tech/computing/best-tripod-for-photos-and-video/#ftag=CADf328eec](https://www.cnet.com/tech/computing/best-tripod-for-photos-and-video/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:07:29+00:00
 - user: None

Find the best tripod to snap that perfect shot. Here are our favorites of 2023.

## Therapy Out of Reach? These 4 Tips Will Promote Better Mental Health     - CNET
 - [https://www.cnet.com/health/mental/therapy-out-of-reach-these-4-tips-will-promote-better-mental-health/#ftag=CADf328eec](https://www.cnet.com/health/mental/therapy-out-of-reach-these-4-tips-will-promote-better-mental-health/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:00:13+00:00
 - user: None

There are times when we can't go to therapy. Here's what to do in the meantime.

## Save 70% On Products With This Amazon Shopping Secret     - CNET
 - [https://www.cnet.com/deals/save-70-percent-off-products-with-this-amazon-shopping-secret/#ftag=CADf328eec](https://www.cnet.com/deals/save-70-percent-off-products-with-this-amazon-shopping-secret/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:00:03+00:00
 - user: None

There's no need for an Amazon Prime membership when you can get deep discounts with warehouse deals.

## Dead Space Is a Killer Remake Sure to Slay Fans of the Original     - CNET
 - [https://www.cnet.com/tech/gaming/dead-space-is-a-killer-remake-sure-to-slay-fans-of-the-original/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/dead-space-is-a-killer-remake-sure-to-slay-fans-of-the-original/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 16:00:00+00:00
 - user: None

Commentary: This is how remakes should be done.

## 'Poker Face' Review: Rian Johnson Follows 'Glass Onion' With Another Delicious Murder Mystery     - CNET
 - [https://www.cnet.com/culture/entertainment/poker-face-review-rian-johnson-follows-glass-onion-in-snackable-murder-mystery/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/poker-face-review-rian-johnson-follows-glass-onion-in-snackable-murder-mystery/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:53:10+00:00
 - user: None

Glass Onion meets Russian Doll in Peacock's mystery series starring Natasha Lyonne and a guest cast to die for.

## OnePlus Teases Its First Tablet Ahead of Launch Event     - CNET
 - [https://www.cnet.com/tech/computing/oneplus-teases-its-first-tablet-ahead-of-launch-event/#ftag=CADf328eec](https://www.cnet.com/tech/computing/oneplus-teases-its-first-tablet-ahead-of-launch-event/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:46:32+00:00
 - user: None

The teaser image shows a prominent camera bump along what appears to be the tablet's long edge.

## Your Wi-Fi Passwords Are Hidden on Your Mac and Windows. Here's How to Find Them     - CNET
 - [https://www.cnet.com/tech/computing/your-wi-fi-passwords-are-hidden-on-your-mac-and-windows-heres-how-to-find-them/#ftag=CADf328eec](https://www.cnet.com/tech/computing/your-wi-fi-passwords-are-hidden-on-your-mac-and-windows-heres-how-to-find-them/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:30:03+00:00
 - user: None

If you've ever connected to a Wi-Fi network on your computer, the password is saved somewhere. You just need to know where to look.

## How to Tell if You Have a Food Allergy, Sensitivity or Intolerance     - CNET
 - [https://www.cnet.com/health/nutrition/how-to-tell-if-you-have-a-food-allergy-sensitivity-or-intolerance/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/how-to-tell-if-you-have-a-food-allergy-sensitivity-or-intolerance/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:27:53+00:00
 - user: None

It can be hard to determine if you have an actual allergy or an intolerance to something you eat. Here's how to know.

## Today Only: Save $300 on the Microsoft Surface Laptop Studio     - CNET
 - [https://www.cnet.com/deals/today-only-save-300-on-the-microsoft-surface-laptop-studio/#ftag=CADf328eec](https://www.cnet.com/deals/today-only-save-300-on-the-microsoft-surface-laptop-studio/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:25:00+00:00
 - user: None

This three-in-one design makes it easy to focus on productivity, immerse yourself in entertainment and indulge creative whims, all in one workspace.

## 'Star Wars: The Bad Batch' Season 2 Schedule: When Does Episode 6 Hit Disney Plus?     - CNET
 - [https://www.cnet.com/culture/entertainment/star-wars-the-bad-batch-season-2-schedule-when-does-episode-6-hit-disney-plus/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/star-wars-the-bad-batch-season-2-schedule-when-does-episode-6-hit-disney-plus/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:18:48+00:00
 - user: None

The clone-centric Star Wars series is rolling out on Disney's streaming service each week until March.

## iOS 16.3: The New Features That Just Landed on Your iPhone     - CNET
 - [https://www.cnet.com/tech/services-and-software/ios-16-3-the-new-features-that-just-landed-on-your-iphone/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/ios-16-3-the-new-features-that-just-landed-on-your-iphone/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:08:39+00:00
 - user: None

Support for the next-generation HomePod and security keys for Apple ID are some of the new features.

## 'Poker Face': How to Watch and Where to Stream     - CNET
 - [https://www.cnet.com/tech/services-and-software/poker-face-how-to-watch-and-where-to-stream/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/poker-face-how-to-watch-and-where-to-stream/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:06:34+00:00
 - user: None

The neo-noir mystery series from Knives Out creator Rian Johnson starts streaming today.

## Didn't Get Your State Stimulus Payment? Here's How to Check on It     - CNET
 - [https://www.cnet.com/personal-finance/taxes/didnt-get-your-state-stimulus-payment-heres-how-to-check-on-it/#ftag=CADf328eec](https://www.cnet.com/personal-finance/taxes/didnt-get-your-state-stimulus-payment-heres-how-to-check-on-it/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:00:12+00:00
 - user: None

Dozens of states issued rebates in 2022. Find out where yours is.

## The Amazon Prime Feature That Will Save You Cash Monthly     - CNET
 - [https://www.cnet.com/deals/the-amazon-prime-feature-that-will-save-you-cash-monthly/#ftag=CADf328eec](https://www.cnet.com/deals/the-amazon-prime-feature-that-will-save-you-cash-monthly/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 15:00:07+00:00
 - user: None

Subscribe and save on all your favorites snacks, bathroom and kitchen essentials today.

## Quickly Stop Your iPhone Apps From Accessing Your Location, Microphone and Camera     - CNET
 - [https://www.cnet.com/tech/services-and-software/quickly-stop-your-iphone-apps-from-accessing-your-location-microphone-and-camera/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/quickly-stop-your-iphone-apps-from-accessing-your-location-microphone-and-camera/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:45:02+00:00
 - user: None

Apple's new Safety Check feature of iOS 16 lets you revoke permissions from third-party apps.

## FDA Advisers Meeting Today to Discuss Future of COVID Vaccine Campaign     - CNET
 - [https://www.cnet.com/health/medical/fda-advisers-meeting-today-to-discuss-future-of-covid-vaccine-campaign/#ftag=CADf328eec](https://www.cnet.com/health/medical/fda-advisers-meeting-today-to-discuss-future-of-covid-vaccine-campaign/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:45:00+00:00
 - user: None

The FDA has already laid out a plan similar to the way annual flu shots roll out, according to an agency document shared ahead of Thursday's meeting.

## NFL Championship Sunday: How to Watch, Stream Bengals vs. Chiefs With or Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-championship-sunday-how-to-watch-stream-bengals-vs-chiefs-with-or-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-championship-sunday-how-to-watch-stream-bengals-vs-chiefs-with-or-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:10:03+00:00
 - user: None

The Bengals and Chiefs meet again in the AFC Championship.

## The Absolute Best TV Shows to Watch on Starz Right Now     - CNET
 - [https://www.cnet.com/culture/entertainment/absolute-best-tv-shows-watch-on-starz-right-now/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/absolute-best-tv-shows-watch-on-starz-right-now/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:00:17+00:00
 - user: None

Get hip to P-Valley and Party Down or get swept up in Outlander or The Serpent Queen.

## Here Are Today's Refinance Rates, Jan. 26, 2023: Rate Increases     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-jan-26-2023-rate-increases/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/here-are-todays-refinance-rates-jan-26-2023-rate-increases/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:00:13+00:00
 - user: None

Refinance rates were mixed, but one key rate ticked up. The Fed's interest rate hikes have affected the refinance market.

## NFL Championship Sunday: How to Watch, Stream 49ers vs. Eagles With or Without Cable     - CNET
 - [https://www.cnet.com/tech/services-and-software/nfl-championship-sunday-how-to-watch-stream-49ers-vs-eagles-with-or-without-cable/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/nfl-championship-sunday-how-to-watch-stream-49ers-vs-eagles-with-or-without-cable/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:00:11+00:00
 - user: None

The Eagles host the 49ers, with a trip to Super Bowl 57 on the line.

## Current Mortgage Interest Rates on Jan. 26, 2023: Rates Trend Higher     - CNET
 - [https://www.cnet.com/personal-finance/mortgages/current-mortgage-interest-rates-on-jan-26-2023-rates-trend-higher/#ftag=CADf328eec](https://www.cnet.com/personal-finance/mortgages/current-mortgage-interest-rates-on-jan-26-2023-rates-trend-higher/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 14:00:06+00:00
 - user: None

Today some major mortgage rates climbed higher. If you're shopping for a mortgage, see how your future mortgage payments could be affected by interest rate hikes.

## Samsung's Stylish The Frame TVs Are Up to $900 Off Today Only     - CNET
 - [https://www.cnet.com/deals/samsung-the-frame-4k-tv-up-to-900-off-today/#ftag=CADf328eec](https://www.cnet.com/deals/samsung-the-frame-4k-tv-up-to-900-off-today/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:42:18+00:00
 - user: None

This sleek TV doubles as a unique piece of decor, and right now you can pick one up for hundreds off the usual price.

## Disney Plus is Taking Longer and Longer to Stream New Marvel Movies     - CNET
 - [https://www.cnet.com/news/disney-plus-is-taking-longer-and-longer-to-stream-new-marvel-movies/#ftag=CADf328eec](https://www.cnet.com/news/disney-plus-is-taking-longer-and-longer-to-stream-new-marvel-movies/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:03:02+00:00
 - user: None

Black Panther: Wakanda Forever will start streaming next week, but it's the longest wait yet.

## Can a High-Tech Trash Can Solve Our Food Waste Problem?     - CNET
 - [https://www.cnet.com/news/can-a-high-tech-trash-can-solve-our-food-waste-problem/#ftag=CADf328eec](https://www.cnet.com/news/can-a-high-tech-trash-can-solve-our-food-waste-problem/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:00:23+00:00
 - user: None

The new Mill bin, created by a Google Nest founder, turns ordinary kitchen food scraps into chicken feed. But it requires a pricey monthly membership.

## Razer Edge Game Handheld Is Here: Should You Buy One?     - CNET
 - [https://www.cnet.com/tech/gaming/razer-edge-game-handheld-arrives-what-to-know/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/razer-edge-game-handheld-arrives-what-to-know/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:00:16+00:00
 - user: None

Razer's Android gaming handheld is part mobile, part console. Here's what to know.

## The IRS Is Accepting Tax Returns. 7 Steps to Take for a Bigger Refund     - CNET
 - [https://www.cnet.com/personal-finance/taxes/the-irs-is-accepting-tax-returns-7-steps-to-take-for-a-bigger-refund/#ftag=CADf328eec](https://www.cnet.com/personal-finance/taxes/the-irs-is-accepting-tax-returns-7-steps-to-take-for-a-bigger-refund/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:00:02+00:00
 - user: None

The sooner you act, the more options you have.

## iPhone 14 Sets the Stage for 2023's Biggest Phone Trend     - CNET
 - [https://www.cnet.com/tech/mobile/the-iphone-14-set-up-2023s-biggest-phone-trend/#ftag=CADf328eec](https://www.cnet.com/tech/mobile/the-iphone-14-set-up-2023s-biggest-phone-trend/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 13:00:00+00:00
 - user: None

Everyone's jumping on the idea of texting through orbiting satellites, but is it just a fad?

## Yes, Your Router Collects Data on You. Here's How to Protect Your Privacy     - CNET
 - [https://www.cnet.com/how-to/yes-your-router-collects-data-on-you-heres-how-to-protect-your-privacy/#ftag=CADf328eec](https://www.cnet.com/how-to/yes-your-router-collects-data-on-you-heres-how-to-protect-your-privacy/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 12:00:17+00:00
 - user: None

Wi-Fi router companies claim they don't track the websites you visit. But all of them collect and share some user data. Here's what to know.

## The Best Racing Games and the Wheels and Pedals to Play Them With     - CNET
 - [https://www.cnet.com/tech/gaming/the-best-racing-games-and-the-wheels-and-pedals-to-play-them-with/#ftag=CADf328eec](https://www.cnet.com/tech/gaming/the-best-racing-games-and-the-wheels-and-pedals-to-play-them-with/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 12:00:13+00:00
 - user: None

Add a wheel and pedals to these PS5, Xbox and PC racing games and get an added level of immersion.

## Best Workout Subscription Apps for 2023: Apple Fitness Plus, Peloton, Daily Burn and More     - CNET
 - [https://www.cnet.com/health/fitness/best-streaming-workout-subscriptions/#ftag=CADf328eec](https://www.cnet.com/health/fitness/best-streaming-workout-subscriptions/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 11:30:03+00:00
 - user: None

Take almost every fitness class you could ever want right from your living room with the best workout subscription.

## Apple Studio Display Hits New All-Time Low With $299 Off at Amazon     - CNET
 - [https://www.cnet.com/deals/snag-the-apple-studio-display-all-time-low-299-off/#ftag=CADf328eec](https://www.cnet.com/deals/snag-the-apple-studio-display-all-time-low-299-off/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 09:27:06+00:00
 - user: None

Mac owners can snag this powerful 27-inch monitor for just $1,300 for a limited time.

## Lloyd Morrisett, Co-Creator of 'Sesame Street,' Dies at 93     - CNET
 - [https://www.cnet.com/culture/entertainment/lloyd-morrisett-co-creator-of-sesame-street-dies-at-93/#ftag=CADf328eec](https://www.cnet.com/culture/entertainment/lloyd-morrisett-co-creator-of-sesame-street-dies-at-93/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 06:30:00+00:00
 - user: None

The beloved show, which started out to help prepare children for school, would go on to teach many important lessons and become one of the longest running programs on TV.

## Surfshark Passes First Independent No-Logs Audit     - CNET
 - [https://www.cnet.com/tech/services-and-software/surfshark-passes-first-independent-no-logs-audit/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/surfshark-passes-first-independent-no-logs-audit/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 02:43:00+00:00
 - user: None

Auditing firm Deloitte confirmed that the configuration of Surfshark's IT systems were in line with the VPN's no-logs policy.

## Bitcoin Proposed to Become Legal Tender in Arizona     - CNET
 - [https://www.cnet.com/culture/bitcoin-proposed-to-become-legal-tender-in-arizona/#ftag=CADf328eec](https://www.cnet.com/culture/bitcoin-proposed-to-become-legal-tender-in-arizona/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 02:20:45+00:00
 - user: None

Arizona state Sen. Wendy Rogers wants to follow in the footsteps of El Salvador.

## See a Real-Life 'Terminator' Robot Liquify to Escape a Cage     - CNET
 - [https://www.cnet.com/science/see-a-real-life-terminator-robot-liquify-to-escape-a-cage/#ftag=CADf328eec](https://www.cnet.com/science/see-a-real-life-terminator-robot-liquify-to-escape-a-cage/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:54:00+00:00
 - user: None

These shape-shifting miniature robots can go almost anywhere thanks to two superpowers: melting and magnets.

## Tesla Reports Record Revenue for 2022, 1.31 Million EVs Sold     - CNET
 - [https://www.cnet.com/roadshow/news/tesla-reports-record-revenue-for-2022-1-31-million-evs-sold/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/tesla-reports-record-revenue-for-2022-1-31-million-evs-sold/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:52:58+00:00
 - user: None

Tesla reports record sales for the 2022 despite a reduction in average transaction price. The automaker now turns its attention to software to drive profit.

## Tesla Reports Record Revenue for 2022, With 1.31 Million EVs Sold     - CNET
 - [https://www.cnet.com/roadshow/news/tesla-reports-record-revenue-for-2022-with-1-31-million-evs-sold/#ftag=CADf328eec](https://www.cnet.com/roadshow/news/tesla-reports-record-revenue-for-2022-with-1-31-million-evs-sold/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:52:00+00:00
 - user: None

Tesla sold more cars and made more money than ever, despite its average transaction price falling. The automaker now turns its attention to software to drive profit.

## Twitter Still Has Security Flaws After Musk Takeover, Whistleblower Alleges     - CNET
 - [https://www.cnet.com/tech/services-and-software/twitter-still-has-security-flaws-after-musk-takeover-whistleblower-alleges/#ftag=CADf328eec](https://www.cnet.com/tech/services-and-software/twitter-still-has-security-flaws-after-musk-takeover-whistleblower-alleges/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:16:00+00:00
 - user: None

An ex-Twitter employee raised concerns that too many workers have the ability to tweet under any account.

## Smartphone Shipments Saw Biggest-Ever Drop at the End of 2022     - CNET
 - [https://www.cnet.com/tech/smartphone-shipments-saw-biggest-ever-drop-at-the-end-of-2022/#ftag=CADf328eec](https://www.cnet.com/tech/smartphone-shipments-saw-biggest-ever-drop-at-the-end-of-2022/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:10:32+00:00
 - user: None

Shipments declined almost 20% in the fourth quarter last year.

## What Is Your Poop Saying About Your Health? 10 Characteristics to Note     - CNET
 - [https://www.cnet.com/health/nutrition/what-is-your-poop-saying-about-your-health-10-characteristics-to-note/#ftag=CADf328eec](https://www.cnet.com/health/nutrition/what-is-your-poop-saying-about-your-health-10-characteristics-to-note/#ftag=CADf328eec)
 - RSS feed: https://www.cnet.com/rss/all/
 - date published: 2023-01-26 00:00:03+00:00
 - user: None

Everybody poops. Here's how to know if yours is normal.
