# Source Bankier, Source URL:https://www.bankier.pl/rss/wiadomosci.xml, Source language: pl-PL

## Wall Street w górę po wynikach Tesli
 - [https://www.bankier.pl/wiadomosc/Wall-Street-w-gore-po-wynikach-Tesli-8479143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wall-Street-w-gore-po-wynikach-Tesli-8479143.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 21:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/3b7c71993cb963-948-568-280-115-1720-1031.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Czwartkowa sesja na Wall Street zakończyła się wzrostami głównych indeksów. Uwaga inwestorów koncentrowała się na lepszych od oczekiwań wynikach finansowych Tesli.</p>

## Sejm odrzucił wszystkie poprawki Senatu do budżetu na 2023 r.
 - [https://www.bankier.pl/wiadomosc/Sejm-odrzucil-wszystkie-poprawki-Senatu-do-budzetu-na-2023-r-8479106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-odrzucil-wszystkie-poprawki-Senatu-do-budzetu-na-2023-r-8479106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 19:24:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/4/f8238841313a48-945-560-7-37-3016-1809.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm w czwartek odrzucił wszystkie poprawki Senatu do budżetu na 2023 r. Ustawa budżetowa trafi teraz do prezydenta do podpisu.</p>

## Rosja może mieć wkrótce spory ból głowy. Władze Serbii coraz mocniej dystansują się od działań Kremla
 - [https://www.bankier.pl/wiadomosc/Rosja-moze-miec-wkrotce-spory-bol-glowy-Wladze-Serbii-coraz-mocniej-dystansuja-sie-o-dzialan-Kremla-8479096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosja-moze-miec-wkrotce-spory-bol-glowy-Wladze-Serbii-coraz-mocniej-dystansuja-sie-o-dzialan-Kremla-8479096.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 18:50:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/d46849eeb648af-945-560-0-28-1607-964.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W środę minister spraw zagranicznych Serbii Ivica Daczić oznajmił, że Belgrad dopuszcza możliwość przyłączenia się do sankcji UE wobec Rosji; była to pierwsza taka wypowiedź przedstawiciela serbskich władz od lutego 2022 roku, czyli początku inwazji Kremla na Ukrainę - poinformował w czwartek portal Euractiv.</p>

## Duże zmiany w podatku od spadków i darowizn. Kwoty wolne pójdą w górę
 - [https://www.bankier.pl/wiadomosc/Duze-zmiany-w-podatku-od-spadkow-i-darowizn-Kwoty-wolne-pojda-w-gore-8479094.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duze-zmiany-w-podatku-od-spadkow-i-darowizn-Kwoty-wolne-pojda-w-gore-8479094.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 18:48:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/d2cb2b958775e3-945-560-8-226-3346-2007.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartek Sejm uchwalił ustawę deregulacyjną, nowelizującą kilkanaście ustaw. Wśród zmian wprowadzanych ustawą jest m.in. podniesienie kwot wolnych w podatku od spadków i darowizn.</p>

## Sejm zdecydował ws. tarczy dla odbiorców ciepła systemowego
 - [https://www.bankier.pl/wiadomosc/Sejm-zdecydowal-ws-tarczy-dla-odbiorcow-ciepla-systemowego-Nikt-nie-byl-przeciw-8479095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sejm-zdecydowal-ws-tarczy-dla-odbiorcow-ciepla-systemowego-Nikt-nie-byl-przeciw-8479095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 18:48:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/c/0b76076c450fe7-948-568-0-266-4096-2457.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejm uchwalił w czwartek nowelizację ustawy wprowadzającą mechanizm ograniczenia wzrostu cen dla odbiorców ciepła do 40 proc. Teraz ustawa trafi do dalszych prac w Senacie.</p>

## Będą podwyżki w KGHM. Spółka ogłosiła już, o ile wzrosną pensje
 - [https://www.bankier.pl/wiadomosc/Pensje-pracownikow-KGHM-wzrosna-od-stycznia-o-13-2-proc-8479044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pensje-pracownikow-KGHM-wzrosna-od-stycznia-o-13-2-proc-8479044.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 17:20:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/7/3fb104b6b27c2a-945-567-0-232-2950-1770.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W wyniku negocjacji ze związkami zawodowymi w sprawie m.in. wzrostu płac ustalono, że pensje pracowników KGHM wzrosną od stycznia o 13,2 proc. - podała spółka w komunikacie.</p>

## Orlen przesuwa termin publikacji raportu za IV kwartał
 - [https://www.bankier.pl/wiadomosc/PKN-Orlen-przesuwa-termin-publikacji-raportu-za-IV-kw-na-24-lutego-8479037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKN-Orlen-przesuwa-termin-publikacji-raportu-za-IV-kw-na-24-lutego-8479037.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 17:06:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/1/dbdce5e8f1e900-948-568-0-116-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKN Orlen przesuwa terminu publikacji raportu za IV kwartał 2022 roku na 24 lutego - podał Orlen w komunikacie. Publikacja raportu miała nastąpić 9 lutego. (PAP Biznes)</p>

## "Zarobki w górnictwie już dawno przestały być konkurencyjne". Związkowcy z JSW szykują się do manifestacji w Warszawie
 - [https://www.bankier.pl/wiadomosc/Zarobki-w-gornictwie-juz-dawno-przestaly-byc-konkurencyjne-Zwiazkowcy-z-JSW-szykuja-sie-do-manifestacji-w-Warszawie-8479016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zarobki-w-gornictwie-juz-dawno-przestaly-byc-konkurencyjne-Zwiazkowcy-z-JSW-szykuja-sie-do-manifestacji-w-Warszawie-8479016.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 16:45:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/1/eb8b9c3da61c5c-945-567-97-48-3790-2274.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Związkowcy z Jastrzębskiej Spółki Węglowej (JSW), domagający się 25-proc. podwyżki wynagrodzeń pracowników spółki, rozpoczęli przygotowania do zaplanowanej na 10 lutego manifestacji w Warszawie. Związkowe biura rozpoczęły zapisy chętnych na udział w pikiecie przed siedzibą MAP.</p>

## Biden może odwiedzić Europę w rocznicę wybuchu wojny w Ukrainie. Polska wśród rozważanych lokalizacji
 - [https://www.bankier.pl/wiadomosc/Biden-moze-odwiedzic-Europe-w-rocznice-wybuchu-wojny-Polska-wsrod-rozwazanych-lokalizacji-8479007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biden-moze-odwiedzic-Europe-w-rocznice-wybuchu-wojny-Polska-wsrod-rozwazanych-lokalizacji-8479007.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 16:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/1c0fc8d1e9ef7c-948-568-0-59-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezydent USA Joe Biden rozważa wizytę w Europie w czasie rocznicy rosyjskiej inwazji na Ukrainę 24 lutego - podały w czwartek telewizje CNN i NBC News, powołując się na źródła w administracji USA. Wśród rozważanych lokalizacji jest Polska.</p>

## Komplet zieleni na GPW. Kurs Dino pobił historyczny szczyt
 - [https://www.bankier.pl/wiadomosc/Komplet-zieleni-na-GPW-Kurs-Dino-pobil-historyczny-szczyt-8479001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Komplet-zieleni-na-GPW-Kurs-Dino-pobil-historyczny-szczyt-8479001.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 16:25:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/1c863c1b467f4c-945-560-2-8-1149-689.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trend boczny dalej obowiązuje na głównych indeksach, a sesje spadkowe przeplatają się z kontrami popytu i na odwrót. Tym razem, na WIG20 zagościł komplet zieleni, a inwestorzy w czasie handlu zaprowadzili kurs Dino na historycznych szczyt.</p>

## Euforia na akcjach Tesli. Dwa miliony aut i Cybertruck na horyzoncie
 - [https://www.bankier.pl/wiadomosc/Euforia-na-akcjach-Tesli-Dwa-miliony-aut-i-Cybertruck-na-horyzoncie-8478950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Euforia-na-akcjach-Tesli-Dwa-miliony-aut-i-Cybertruck-na-horyzoncie-8478950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 15:16:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/5/71d5d2ecb3083e-948-567-0-47-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs Tesli mocno rósł w handlu kasowym po ogłoszeniu wyników i wypowiedziach prezesa na temat planów spółki. Zapowiedź Elona Muska o wyprodukowaniu dwóch milionów elektryków, zachęciła inwestorów do odkupywania akcji, które jeszcze nie dawno przeceniali w obawie o przyszłość firmy.</p>

## Brytyjski przemysł motoryzacyjny wciąż w głębokim dołku. Tak źle nie było od 66 lat
 - [https://www.bankier.pl/wiadomosc/Brytyjski-przemysl-motoryzacyjny-wciaz-w-glebokim-dolku-Tak-zle-nie-bylo-od-66-lat-8478948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Brytyjski-przemysl-motoryzacyjny-wciaz-w-glebokim-dolku-Tak-zle-nie-bylo-od-66-lat-8478948.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 15:13:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/f/b178a3782fcf92-945-560-122-66-1907-1144.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Produkcja samochodów osobowych w Wielkiej Brytanii spadła w 2022 r. do najniższego poziomu od 66 lat - podało w czwartek Stowarzyszenie Producentów i Sprzedawców Samochodów (SMMT).</p>

## Po czołgach Ukraina dostanie myśliwce? Lockheed Martin zwiększy produkcję F-16
 - [https://www.bankier.pl/wiadomosc/Po-czolgach-Ukraina-dostanie-mysliwce-Lockheed-Martin-zwiekszy-produkcje-F-16-8478892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Po-czolgach-Ukraina-dostanie-mysliwce-Lockheed-Martin-zwiekszy-produkcje-F-16-8478892.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 14:15:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/d7c5a442a0b414-948-568-0-157-4512-2707.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lockheed Martin wyprodukuje więcej samolotów F-16. Dzięki temu będzie mógł uzupełnić zasoby tych krajów, które wysyłają je do Ukrainy. </p>

## W 2022 r. Europejski Bank Odbudowy i Rozwoju zainwestował w Polsce rekordową kwotę
 - [https://www.bankier.pl/wiadomosc/Europejski-Bank-Odbudowy-i-Rozwoju-zainwestowal-w-Polsce-rekordowa-kwote-8478880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Europejski-Bank-Odbudowy-i-Rozwoju-zainwestowal-w-Polsce-rekordowa-kwote-8478880.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 14:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/3b57abc9e4d156-945-560-43-0-3456-2073.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wartość inwestycji w Polsce Europejskiego Banku Odbudowy i Rozwoju osiągnęła w 2022 r. rekordowy poziom 990 mln euro względem 600 mln euro w 2021 r. – przekazał EBOiR w czwartek. 80 proc. wspartych przez bank projektów dot. transformacji niskoemisyjnej, m.in. zrównoważonego transportu.</p>

## Amerykański PKB wyższy od oczekiwań
 - [https://www.bankier.pl/wiadomosc/PKB-USA-w-IV-kwartale-2022-szybki-szacunek-8478849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKB-USA-w-IV-kwartale-2022-szybki-szacunek-8478849.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 13:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/e834775cca1ecb-948-568-0-0-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wstępny odczyt statystyk produktu krajowego brutto za IV
kwartał pokazał, że gospodarka Stanów Zjednoczonych rozwijała się szybciej, niż
się tego spodziewano.</p>

## Minimalna odległość wiatraków od domów mieszkalnych zwiększona przez sejmowe komisje
 - [https://www.bankier.pl/wiadomosc/Minimalna-odleglosc-wiatrakow-od-domow-mieszkalnych-zwiekszona-przez-sejmowe-komisje-8478850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minimalna-odleglosc-wiatrakow-od-domow-mieszkalnych-zwiekszona-przez-sejmowe-komisje-8478850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 13:25:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/7c4663f19a4917-948-568-0-17-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejmowe komisje energii, klimatu i aktywów oraz samorządu i polityki regionalnej zwiększyły w czwartek z 500 m do 700 m minimalną odległość turbin wiatrowych od domów mieszkalnych. Jednocześnie zniosły zakaz budowy budynków mieszkalnych w pobliżu wiatraków.</p>

## WOŚP 2023. Serduszka można kupić w formie tokenów NFT
 - [https://www.bankier.pl/wiadomosc/WOSP-2023-Serduszka-w-formie-NFT-8478790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WOSP-2023-Serduszka-w-formie-NFT-8478790.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 13:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/d/5847c25cba1ae3-948-568-0-343-2371-1422.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />29 stycznia odbędzie się 31. finał Wielkiej Orkiestry Świątecznej 
Pomocy, a zebrane pieniądze zostaną przekazane na walkę z sepsą. W tym 
roku będzie można dorzucić swoją cegiełkę do zbiórki w nowy sposób, 
fundacja oferuje bowiem serduszka WOŚP w formie... tokenu NFT.</p>

## Czarnek: Wymagania na tegorocznych maturach będą obniżone o 20-25 proc.
 - [https://www.bankier.pl/wiadomosc/Czarnek-Wymagania-na-tegorocznych-maturach-beda-obnizone-o-20-25-proc-8478807.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czarnek-Wymagania-na-tegorocznych-maturach-beda-obnizone-o-20-25-proc-8478807.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 12:40:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/9/e4358e21f900b4-948-568-0-138-4256-2553.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na wszystkich egzaminach maturalnych, z wszystkich przedmiotów, tegoroczne wymagania są obniżone o ok. 20-25 proc. – powiedział w czwartek minister edukacji i nauki Przemysław Czarnek. Dodał, że jest to spowodowane tym, że młodzież uczyła się częściowo zdalnie w czasie pandemii COVID-19.</p>

## PGE ma pozwolenia na budowę trzech farm fotowoltaicznych woj. lubelskim
 - [https://www.bankier.pl/wiadomosc/PGE-ma-pozwolenia-na-budowe-trzech-instalacji-o-lacznej-mocy-ok-116-GWh-8478801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PGE-ma-pozwolenia-na-budowe-trzech-instalacji-o-lacznej-mocy-ok-116-GWh-8478801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 12:36:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/bbe82ef34c2c8b-948-568-0-99-1900-1139.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PGE Energia Odnawialna otrzymała pozwolenia na budowę trzech farm fotowoltaicznych w województwie lubelskim: PV Srebrzyszcze, PV Wrzosów i PV Żółtańce. Według wstępnych szacunków, średnioroczna produkcja wszystkich trzech instalacji osiągnie poziom ok. 116 GWh – poinformowało PGE w komunikacie prasowym.</p>

## Kataklizm na rynku kredytów hipotecznych potrwa jeszcze długo. BIK podało szacunki
 - [https://www.bankier.pl/wiadomosc/Kataklizm-na-rynku-kredytow-hipotecznych-potrwa-jeszcze-dlugo-BIK-podalo-szacunki-8478771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kataklizm-na-rynku-kredytow-hipotecznych-potrwa-jeszcze-dlugo-BIK-podalo-szacunki-8478771.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 12:03:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/d/2f5bd1ad624b41-948-568-0-0-1938-1162.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W 2022 r. kwota udzielonych kredytów mieszkaniowych spadła o niemal połowę, do 45,4 mld zł rdr; również o ponad połowę spadła ich liczba - podało Biuro Informacji Kredytowe. Szacuje, że wartość kredytów hipotecznych w tym roku będzie 38 proc. niższa niż w 2022 r.</p>

## Węgry rozbudowują elektrownię atomową w Paks. Z udziałem Rosji
 - [https://www.bankier.pl/wiadomosc/Wegry-rozbudowuja-elektrownie-atomowa-w-Paks-Z-udzialem-Rosji-8478748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wegry-rozbudowuja-elektrownie-atomowa-w-Paks-Z-udzialem-Rosji-8478748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 11:33:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/e/de62ab571fd97e-948-568-627-543-1961-1176.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W rozmowie telefonicznej z Aleksandrem Nowakiem, ministrem energetyki Rosji, uzgodniliśmy przyspieszenie budowy nowych bloków elektrowni jądrowej w Paks, tam, gdzie to możliwe - poinformował w czwartek przebywający w USA minister spraw zagranicznych i handlu Węgier Peter Szijjarto.</p>

## Ważne zmiany na uczelniach. Prezydent podpisał ustawę
 - [https://www.bankier.pl/wiadomosc/Wazne-zmiany-na-uczelniach-Prezydent-podpisal-ustawe-8478743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wazne-zmiany-na-uczelniach-Prezydent-podpisal-ustawe-8478743.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 11:22:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/2/a75978e0de2663-945-560-22-22-4477-2686.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmiany w postępowaniach awansowych, obligatoryjne publiczne kolokwia habilitacyjne i dostosowanie przepisów do wprowadzenia nowych dyscyplin nauki – to wybrane założenia ustawy, którą w środę podpisał prezydent Andrzej Duda.</p>

## Wiatraki staną jednak dalej od domów? Komisje zgłaszają poprawki
 - [https://www.bankier.pl/wiadomosc/Wiatraki-stana-jednak-dalej-od-domow-Komisje-zglaszaja-poprawki-8478741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiatraki-stana-jednak-dalej-od-domow-Komisje-zglaszaja-poprawki-8478741.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 11:17:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/c/ee1b5b0003aa04-948-568-0-57-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sejmowe komisje energii, klimatu i aktywów oraz samorządu i polityki regionalnej przyjęły w czwartek poprawkę do rządowego projektu zmiany ustawy odległościowej, która zwiększa z 500 do 700 m minimalną odległość wiatraka, ale wyłącznie od budynków mieszkalnych.</p>

## Nagrody o wartości 550 zł od BNP Paribas Bank Polska za konto osobiste
 - [https://www.bankier.pl/wiadomosc/Nagrody-o-wartosci-550-zl-od-BNP-Paribas-Bank-Polska-za-konto-osobiste-8478633.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Nagrody-o-wartosci-550-zl-od-BNP-Paribas-Bank-Polska-za-konto-osobiste-8478633.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 11:14:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/04aad107c2cc5c-945-567-0-7-970-582.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />BNP Paribas Bank Polska to jeden z aktywniej walczących o nowych klientów banków. W zasadzie nie ma tygodnia, aby nie natknąć się na jakąś promocję Konta Otwartego na Ciebie. Właśnie wystartowała najnowsza oferta specjalna banku – „Noworoczny motywator”.</p>

## Kontrowersyjny pomysł inwigilacji obywateli. PiS przegrało głosowanie w komisji
 - [https://www.bankier.pl/wiadomosc/Kontrowersyjny-pomysl-inwigilacji-obywateli-PiS-przegralo-glosowanie-w-komisji-8478730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kontrowersyjny-pomysl-inwigilacji-obywateli-PiS-przegralo-glosowanie-w-komisji-8478730.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 11:02:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/b/f657fc570c03cf-948-568-7-318-1528-916.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawo i Sprawiedliwość przegrało sejmowe głosowanie 
na posiedzeniu sejmowej Komisji Cyfryzacji, Innowacyjności i 
Nowoczesnych Technologii. Komisja miała rozpatrywać rządowe projekty 
ustaw prawo komunikacji elektronicznej i przepisów ją wprowadzających, 
ale posiedzenie zostało odroczone do 6 lutego. </p>

## Wcześniejsze emerytury nauczycieli. Czarnek: Rozmawiam z prezes ZUS
 - [https://www.bankier.pl/wiadomosc/Wczesniejsze-emerytury-nauczycieli-Czarnek-Rozmawiam-z-prezes-ZUS-8478727.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wczesniejsze-emerytury-nauczycieli-Czarnek-Rozmawiam-z-prezes-ZUS-8478727.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:59:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/b1151291be1810-948-568-0-26-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />O wcześniejszych emeryturach dla nauczycieli rozmawiam już z prezes ZUS - prof. Gertrudą Uścińską - powiedział w czwartek w Polsat News szef MEiN Przemysław Czarnek. Dodał, że na 1 lutego zaplanowano spotkanie ze związkami zawodowymi na ten temat.</p>

## Polską gospodarkę w 2023 r. czeka solidne spowolnienie
 - [https://www.bankier.pl/wiadomosc/Polska-gospodarke-w-2023-r-czeka-solidne-spowolnienie-8478726.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-gospodarke-w-2023-r-czeka-solidne-spowolnienie-8478726.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:58:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/0d0523f6838a56-945-560-0-74-4252-2551.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polską gospodarkę w 2023 r. czeka solidne spowolnienie, ale nie głęboki kryzys - ocenił podczas konferencji prasowej Hubert Kmiecik, CIO Amundi Polska TFI. Jego zdaniem, obecnie inwestowanie na rynku długu jest coraz bardziej stabilne. Na rynku akcji długoterminowe perspektywy są optymistyczne, choć w krótkim terminie można oczekiwać zmienności.</p>

## Dezinflacja w Polsce? Tyrowicz: To miś na miarę naszych możliwości
 - [https://www.bankier.pl/wiadomosc/Dezinflacja-w-Polsce-Tyrowicz-To-mis-na-miare-naszych-mozliwosci-8478693.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dezinflacja-w-Polsce-Tyrowicz-To-mis-na-miare-naszych-mozliwosci-8478693.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:35:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/a3bb0eb90d9b81-948-568-0-266-3942-2365.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- Hasło „dezinflacja” wydaje się nieco przereklamowane - uważa Joanna 
Tyrowicz. Średnioroczna inflacja CPI ma w tym roku tylko nieznacznie 
spowolnić i utrzymać się na dwucyfrowym poziomie. - Może (...) jest to miś na miarę naszych możliwości - komentuje członkini RPP.</p>

## Ponad 60 proc. uchodźców z Ukrainy wciąż pozostaje bez pracy
 - [https://www.bankier.pl/wiadomosc/Ponad-60-proc-uchodzcow-z-Ukrainy-wciaz-pozostaje-bez-pracy-8478696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-60-proc-uchodzcow-z-Ukrainy-wciaz-pozostaje-bez-pracy-8478696.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:24:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/2/de33b032ef1679-948-568-0-35-1775-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Blisko 4 na 10 uchodźców z Ukrainy znalazło już
zatrudnienie w Polsce – wynika z opublikowanego dzisiaj raportu „Sytuacja
zawodowa uchodźców z Ukrainy w Polsce”, przygotowanego przez Fundację
Totalizatora Sportowego i Manpower. Osoby, które wciąż poszukują pracy, jako
główne powody wskazują niewystarczającą znajomość języka polskiego oraz brak
ofert odpowiadających ich kompetencjom. </p>

## Kredyty na cudze dowody już nie takie kuszące. Znamy najnowsze dane
 - [https://www.bankier.pl/wiadomosc/Kredyty-na-cudzy-dowod-stracily-zainteresowanie-Znamy-najnowsze-dane-8478685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kredyty-na-cudzy-dowod-stracily-zainteresowanie-Znamy-najnowsze-dane-8478685.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:09:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/560f5bb62330f0-937-562-37-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />„Tylko” 40 mln złotych próbowali wyłudzić oszuści na cudze dokumenty w IV kwartale 2022 roku – podał Związek Banków Polskich. Choć kwota na pierwszy rzut oka szokuje, to w rzeczywistości poziom ten jest wyjątkowo niski na tle historycznych danych. Zdarzały się bowiem kwartały, gdzie kwota ta sięgała powyżej 100 mln zł.</p>

## Fabryka broni dla Ukrainy w Polsce. Nowy pomysł Brytyjczyków
 - [https://www.bankier.pl/wiadomosc/Fabryka-broni-dla-Ukrainy-w-Polsce-Nowy-pomysl-Brytyjczykow-8478680.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Fabryka-broni-dla-Ukrainy-w-Polsce-Nowy-pomysl-Brytyjczykow-8478680.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:06:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/93858b71a9af4d-948-568-0-50-2508-1504.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Aby pomóc Ukrainie wygrać wojnę, w Polsce musi powstać ogromna fabryka broni, bo obecny model darowizn jest w dłuższej perspektywie nie do utrzymania - powiedział w czwartek szef komisji obrony w brytyjskiej Izbie Gmin Tobias Ellwood.</p>

## Kurorty i uzdrowiska ponad prawem? Bezprawnie pobierają opłatę klimatyczną
 - [https://www.bankier.pl/wiadomosc/Kurorty-i-uzdrowiska-ponad-prawem-Bezprawnie-pobieraja-oplate-klimatyczna-8478676.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurorty-i-uzdrowiska-ponad-prawem-Bezprawnie-pobieraja-oplate-klimatyczna-8478676.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:03:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/a/6d7403855e8e29-945-560-7-120-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zakopane, Szklarska Poręba, Krynica Zdrój, Jelenia 
Góra. Te i wiele innych miejscowości w Małopolsce i na Dolnym Śląsku nie
 spełnia prawnych standardów jakości powietrza. A to oznacza, że nie 
powinny pobierać opłaty klimatycznej - wynika z najnowszego raportu 
Fundacji ClientEarth Prawnicy dla 
Ziemi.</p>

## Coraz gorsza koniunktura w bankowości. Spodziewany wzrost kosztów działalności
 - [https://www.bankier.pl/wiadomosc/Coraz-gorsza-koniunktura-w-bankowosci-Spodziewany-wzrost-kosztow-dzialalnosci-8478672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-gorsza-koniunktura-w-bankowosci-Spodziewany-wzrost-kosztow-dzialalnosci-8478672.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:02:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/4/0af870bfaf62d4-948-567-0-60-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wskaźnik koniunktury bankowej Pengab spadł w styczniu 2023 r. w porównaniu do grudnia 2022 r. o 6,4 pkt. do 15,4 pkt. - poinformowały Związek Banków Polskich oraz Minds &amp; Roses. Z badania wynika, że znacząco spadł indeks aktywności klientów na rynku kredytów konsumpcyjnych oraz kredytów mieszkaniowych. Obniżyła się także aktywność klientów na rynku depozytowym. Według 93 proc. badanych w 2023 r. wzrosną koszty działalności banków.</p>

## Tak wygląda atak oszustów. Policja pokazuje scenariusz
 - [https://www.bankier.pl/wiadomosc/Tak-wyglada-atak-oszustow-Policja-pokazuje-scenariusz-8478671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-wyglada-atak-oszustow-Policja-pokazuje-scenariusz-8478671.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 10:01:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/bf25daa3c67ffc-948-568-0-164-3289-1973.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />„Pani pieniądze są zagrożone. Trzeba je przelać na rachunek techniczny” – telefony o takiej treści coraz częściej odbierają klienci banków. Rozmówca podaje się za przedstawiciela instytucji finansowej, a na telefonie wyświetla się prawidłowy numer. To oszustwo! – alarmuje policja.</p>

## "Rodzina 500+". Podano termin naboru wniosków na nowy okres
 - [https://www.bankier.pl/wiadomosc/Rodzina-500-Podano-termin-naboru-wnioskow-na-nowy-okres-8478653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rodzina-500-Podano-termin-naboru-wnioskow-na-nowy-okres-8478653.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 09:32:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/f/b50c28cc1febfd-948-568-4-48-1596-957.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 lutego rusza nabór wniosków na nowy okres świadczeniowy programu "Rodzina 500+". Z programu każdego miesiąca korzysta około 7 mln dzieci; od początku funkcjonowania programu wypłacono ponad 220 mld zł – powiedziała w czwartek minister rodziny i polityki społecznej Marlena Maląg.</p>

## Kernel kupił terminal w Morskim Porcie Handlowym Jużny w obwodzie odeskim
 - [https://www.bankier.pl/wiadomosc/Kernel-kupil-terminal-w-Morskim-Porcie-Handlowym-Juzny-w-obwodzie-odeskim-8478642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kernel-kupil-terminal-w-Morskim-Porcie-Handlowym-Juzny-w-obwodzie-odeskim-8478642.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 09:22:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/9d093956907b4f-945-567-0-291-4141-2485.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kernel kupił terminal w Morskim Porcie Handlowym Jużny (obwód odeski). OilExportTerminal jest w stanie przyjąć i przechowywać wszystkie rodzaje olejów roślinnych (słonecznikowy, sojowy i rzepakowy) - podała spółka w komunikacie prasowym.</p>

## Złoty coraz słabszy. Kurs euro chce opuścić kanał?
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-chce-opuscic-kanal-8478632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-chce-opuscic-kanal-8478632.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 09:11:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/e/b21675fce72d74-948-568-0-112-4500-2699.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs
euro znalazł się blisko górnego ograniczenia trwającego od listopada trendu
bocznego. 
 
  
 

 
  Normal
  0
  
  
  21
  
  
  false
  false
  false
  
  PL
  X-NONE
  X-NONE
  
   
   
   
   
   
   
   
   
   
  
  
   
   
   
   
   
   
   
   
   
   
   
  

 
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 


</p>

## W Belgii pracownicy otrzymają dodatek za dojazd do pracy rowerem
 - [https://www.bankier.pl/wiadomosc/W-Belgii-pracownicy-otrzymaja-dodatek-za-dojazd-do-pracy-rowerem-8478593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Belgii-pracownicy-otrzymaja-dodatek-za-dojazd-do-pracy-rowerem-8478593.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 09:06:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/811b3bd76d80ae-948-568-0-94-2532-1519.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 maja pracownicy otrzymają 27 centów za każdy przejechany rowerem kilometr w drodze do pracy. Świadczenie przewidziane jest dla wszystkich pracowników zatrudnionych w prywatnych firmach w Belgii. Dodatek "rowerowy" będzie obowiązywał od 1 maja.</p>

## Gaz w czwartek rano drożeje
 - [https://www.bankier.pl/wiadomosc/Gaz-w-czwartek-rano-drozeje-8478625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gaz-w-czwartek-rano-drozeje-8478625.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 09:03:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/ac8d91de74ec96-948-568-2-70-995-597.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W czwartek ok. godz. 9.45 gaz ziemny w holenderskim hubie TTF w kontraktach na luty podrożał o 4,74 proc., do 59,35 euro za MWh, a w kontraktach na marzec o 3,72 proc., do 59,25 euro za MWh. W kontraktach kwietniowych był droższy o 3,60 proc., z ceną na poziomie 59,90 euro za MWh.</p>

## Minister ds. UE: ustawa wiatrakowa potrzebna do wypłaty KPO
 - [https://www.bankier.pl/wiadomosc/Minister-ds-UE-ustawa-wiatrakowa-potrzebna-do-wyplaty-KPO-8478613.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Minister-ds-UE-ustawa-wiatrakowa-potrzebna-do-wyplaty-KPO-8478613.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 08:46:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/6a9316b50f7361-948-567-0-7-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ustawa wiatrakowa to istotny kamień milowy do wypełnienia. Bez jej przyjęcia trudno sobie wyobrazić możliwość pozytywnego rozpatrzenia przez Komisję Europejską wniosku o płatność na KPO - ocenił w czwartek minister ds. UE Szymon Szynkowski vel Sęk.</p>

## Kotecki: Stopy procentowe są zbyt niskie. Obniżka byłaby katastrofą
 - [https://www.bankier.pl/wiadomosc/Kotecki-Stopy-procentowe-sa-zbyt-niskie-Obnizka-bylaby-katastrofa-8478580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kotecki-Stopy-procentowe-sa-zbyt-niskie-Obnizka-bylaby-katastrofa-8478580.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 08:30:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/40f16837d6ed1a-948-568-0-0-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ludwik Kotecki uważa, że stopy procentowe NBP pozostają zbyt niskie na 
tle wysokiej inflacji bazowej i widzi przestrzeń na "niewielkie 
podwyżki" w tym roku. W rozmowie w "Studio Biznes" przyznaje jednak, że 
większość RPP będzie "pewnie fetyszyzować ogólny spadek inflacji".</p>

## Polska pełna innowacji. Poznaj część z nich w specjalnym wydaniu Bankier.pl – już 31 stycznia
 - [https://www.bankier.pl/wiadomosc/Dzien-innowacji-2-Specjalne-wydanie-Bankier-pl-juz-31-stycznia-8478603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dzien-innowacji-2-Specjalne-wydanie-Bankier-pl-juz-31-stycznia-8478603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 08:20:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/3/f08f6b7e15a8ce-948-568-3-7-1487-892.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przed nami nowa odsłona funduszy unijnych, które trafią do Polski. Tym razem jeszcze większy nacisk położony zostanie na finansowanie innowacyjnych przedsięwzięć. Dlatego na Bankier.pl wracamy do tematu w ramach drugiej odsłony Dnia innowacji. Zapraszamy na nasz dzień tematyczny ze sporą dawką ciekawych materiałów – już we wtorek, 31 stycznia.</p>

## Trwa atak rakietowy na Ukrainę. Wybuchy w Kijowie
 - [https://www.bankier.pl/wiadomosc/Trwa-atak-rakietowy-na-Ukraine-Wybuchy-w-Kijowie-8478598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trwa-atak-rakietowy-na-Ukraine-Wybuchy-w-Kijowie-8478598.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 08:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/b/14f04f73f29da7-948-568-0-270-4000-2400.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojska rosyjskie odpaliły w czwartek rano na regiony Ukrainy ponad 30 pocisków rakietowych - poinformował  rzecznik ukraińskich sil powietrznych pułkownik Jurij Ihnat. Zaapelował o pozostanie w schronach.</p>

## Polskie inwestycje w Ukrainie mogą wzrosnąć do 30 mld dolarów
 - [https://www.bankier.pl/wiadomosc/Polskie-inwestycje-w-Ukrainie-moga-wzrosnac-do-30-mld-dolarow-8478592.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-inwestycje-w-Ukrainie-moga-wzrosnac-do-30-mld-dolarow-8478592.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 08:04:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/9e47ab560ed6c6-948-568-0-123-1768-1060.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Skala polskich inwestycji bezpośrednich na Ukrainie w ciągu 5 lat może wzrosnąć do 30 mld USD - oceniają analitycy Polskiego Instytutu Ekonomicznego.</p>

## Revolut z nową usługą dla zamożnych. "Nie ma na rynku takiej propozycji"
 - [https://www.bankier.pl/wiadomosc/Revolut-z-nowa-usluga-dla-zamoznych-Nie-ma-na-rynku-takiej-propozycji-8478554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Revolut-z-nowa-usluga-dla-zamoznych-Nie-ma-na-rynku-takiej-propozycji-8478554.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 07:10:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/4/07d9d5012d8c21-948-568-120-59-1650-989.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fintech Revolut poinformował, że ma w planach wdrożenie nowego planu taryfowego. Plan będzie się nazywał „Ultra” i zagwarantuje powitalny cashback w wysokości 5 proc. przez miesiąc. „Nie ma na rynku w Europie takiej propozycji, żaden gracz w sektorze usług finansowych czegoś takiego nie oferuje” – zachwalają nową usługę przedstawiciele Revoluta.</p>

## TikTok niebezpieczny? Kanadyjski wywiad ostrzega
 - [https://www.bankier.pl/wiadomosc/TikTok-niebezpieczny-Kanadyjski-wywiad-ostrzega-8478536.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TikTok-niebezpieczny-Kanadyjski-wywiad-ostrzega-8478536.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:13:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/e/8b6b9d3aac6244-948-568-0-218-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kanadyjski wywiad elektroniczny przygotowuje zalecenia w sprawie chińskiej aplikacji TikTok i ostrzega użytkowników, by nie zezwalali na dostęp instalowanych aplikacji do prywatnych danych.</p>

## Gwałtowny spadek liczby nielegalnych imigrantów na granicy USA - Meksyk
 - [https://www.bankier.pl/wiadomosc/Gwaltowny-spadek-liczby-nielegalnych-imigrantow-na-granicy-USA-Meksyk-8478532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Gwaltowny-spadek-liczby-nielegalnych-imigrantow-na-granicy-USA-Meksyk-8478532.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:10:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/4fd9ad2c6fd8bc-945-560-0-58-3370-2021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wprowadzeniu przepisów o wydalaniu nielegalnych przybyszów z Kuby, Haiti, Nikaragui i Wenezueli, złapanych na przekraczaniu granicy USA z Meksykiem, o 97 proc. spadła liczba aresztowanych tam imigrantów - powiadomiły w środę amerykańskie władze.</p>

## Adopcja a urlop macierzyński. Nowe zasady wchodzą w życie od lutego
 - [https://www.bankier.pl/wiadomosc/Adopcja-a-urlop-macierzynski-Nowe-zasady-8478530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Adopcja-a-urlop-macierzynski-Nowe-zasady-8478530.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:06:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/f/1f6434745bbbc8-948-567-5-5-995-596.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 1 lutego rodzice adopcyjni i zastępczy będą mogli korzystać z urlopów według korzystniejszych reguł. Wolne od pracy będzie przysługiwało także na starsze dzieci – nawet do ukończenia 14 lat – informuje w czwartek "Rzeczpospolita”.</p>

## Oszukali 175 firm na blisko 6 mln złotych. Ruszy proces
 - [https://www.bankier.pl/wiadomosc/Oszukali-175-firm-na-blisko-6-mln-zlotych-Ruszy-proces-8478527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Oszukali-175-firm-na-blisko-6-mln-zlotych-Ruszy-proces-8478527.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:04:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/e17bac3838a529-948-568-3-9-1197-718.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Lubelski wydział Prokuratury Krajowej skierował do sądu akt oskarżenia przeciwko Arturowi P. oskarżonemu o udział w zorganizowanej grupie przestępczej, która dokonała oszustwa 175 podmiotów gospodarczych na prawie 6 milionów złotych - poinformował Dział Prasowy Prokuratury Krajowej.</p>

## Miały być hospicja prenatalne, są oszczędności dla NFZ. "Doszło do zaniechania"
 - [https://www.bankier.pl/wiadomosc/Mialy-byc-hospicja-prenatalne-sa-oszczednosci-dla-NFZ-Doszlo-do-zaniechania-8478526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mialy-byc-hospicja-prenatalne-sa-oszczednosci-dla-NFZ-Doszlo-do-zaniechania-8478526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:03:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/6ea6e03fe1e1e3-948-568-0-108-2556-1533.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W minionym roku rząd wydał na hospicja perinatalne dwa razy mniej niż w latach przed zaostrzeniem zakazu aborcji – informuje w czwartek "Dziennik Gazeta Prawna”.</p>

## Polscy żołnierze walczący w Ukrainie mogą być ścigani. Sejm zablokował projekt
 - [https://www.bankier.pl/wiadomosc/Polscy-zolnierze-walczacy-w-Ukrainie-moga-byc-scigani-Sejm-zablokowal-projekt-8478520.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polscy-zolnierze-walczacy-w-Ukrainie-moga-byc-scigani-Sejm-zablokowal-projekt-8478520.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:01:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/0/5d2f216eda9474-948-568-0-103-1720-1031.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponadpartyjny projekt znoszący odpowiedzialność za walkę Polaków w obronie Ukrainy został zablokowany w Sejmie – informuje w czwartkowym wydaniu "Rzeczpospolita”.</p>

## Firma króla Karola III pozywa Muska. Poszło o lokal w centrum Londynu
 - [https://www.bankier.pl/wiadomosc/Firma-krola-Karola-III-pozywa-Muska-Poszlo-o-lokal-w-centrum-Londynu-8478074.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Firma-krola-Karola-III-pozywa-Muska-Poszlo-o-lokal-w-centrum-Londynu-8478074.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 06:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/68605b3f18c16f-948-568-14-99-2835-1701.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chytry plan Elona Muska, by nie płacić za siedziby Twittera, spalił na panewece. The Crown Estate, agencja nadzorująca nieruchomości należące do rodziny królewskiej, pozwała platformę w związku z nieopłaconym czynszem za londyńską siedzibę. </p>

## Ubywa lumpeksów, chociaż chętniej kupujemy rzeczy używane. Era Tanich Armanich na ulicach dobiega końca?
 - [https://www.bankier.pl/wiadomosc/Ubywa-lumpeksow-chociaz-chetniej-kupujemy-rzeczy-uzywane-Era-Tanich-Armanich-na-ulicach-dobiega-konca-8478505.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ubywa-lumpeksow-chociaz-chetniej-kupujemy-rzeczy-uzywane-Era-Tanich-Armanich-na-ulicach-dobiega-konca-8478505.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:45:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/7/bfc16752e68ff1-948-568-0-0-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od 2008 r. liczba sklepów z używanymi produktami spadła aż o 40 proc. Polacy kupują "używki" chętnie, ale głównie w internecie – informuje w czwartek "Rzeczpospolita".</p>

## Więcej pieniędzy dla OPP. Ministerstwo szacuje kwoty
 - [https://www.bankier.pl/wiadomosc/Wiecej-pieniedzy-dla-OPP-Ministerstwo-szacuje-kwoty-8478498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wiecej-pieniedzy-dla-OPP-Ministerstwo-szacuje-kwoty-8478498.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:31:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/a/6923265135b110-948-568-0-19-2592-1555.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Szacujemy, że organizacje pożytku publicznego w tym roku otrzymają o 210 mln zł więcej z odpisu z PIT niż w 2022 r. – poinformowało PAP Ministerstwo Finansów.</p>

## Program lojalnościowy PKP Intercity ma powstać "własnymi siłami"
 - [https://www.bankier.pl/wiadomosc/Program-lojalnosciowy-PKP-Intercity-ma-powstac-wlasnymi-silami-8478491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Program-lojalnosciowy-PKP-Intercity-ma-powstac-wlasnymi-silami-8478491.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:19:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/3/670fede1f74cbc-948-568-0-183-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />PKP Intercity planuje własnymi siłami przygotować program lojalnościowy dla podróżnych - poinformował PAP członek zarządu kolejowej spółki Tomasz Gontarz. Wcześniej spółka myślała, aby ogłosić przetarg na wybór dostawcy systemu obsługującego program lojalnościowy.</p>

## Rośnie liczba międzynawowych świadczeń wypłacanych przez ZUS
 - [https://www.bankier.pl/wiadomosc/Rosnie-liczba-miedzynawowych-swiadczen-wyplacanych-przez-ZUS-8478490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rosnie-liczba-miedzynawowych-swiadczen-wyplacanych-przez-ZUS-8478490.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:12:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/6/6e8cae349a4236-948-568-0-143-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszej połowie 2022 roku, w ramach umów międzynarodowych, ZUS wypłacił ponad 289 tysięcy świadczeń emerytalno-rentowych o łącznej wartości 3,3 mld złotych. Większość z tych pieniędzy otrzymali mieszkańcy Polski, którzy oprócz krajowych, mieli okresy ubezpieczenia za pracę w innych państwach UE lub EFTA.</p>

## Jak inwestować i nie przepłacić? Zadbaj o swój portfel. Sprawdziliśmy najtańsze konta maklerskie
 - [https://www.bankier.pl/wiadomosc/Najlepsze-konta-maklerskie-ranking-Najtansze-rachunki-maklerskie-8468887.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najlepsze-konta-maklerskie-ranking-Najtansze-rachunki-maklerskie-8468887.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/2/2621a1049e72d4-948-568-0-0-2600-1559.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sprawdzamy, które konta maklerskie są najtańsze dla inwestorów indywidualnych, biorąc pod uwagę handel akcjami, kontraktami terminowymi oraz koszty prowadzenia rachunku. Przyglądamy się też najpopularniejszym brokerom, którzy oferują organiczny dostęp do polskiego rynku akcji.</p>

## Parkowanie w miastach coraz droższe, choć do limitów daleko
 - [https://www.bankier.pl/wiadomosc/Tyle-kosztuje-parkowanie-w-miastach-Ceny-w-gore-8478278.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tyle-kosztuje-parkowanie-w-miastach-Ceny-w-gore-8478278.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/beb23f198be112-948-568-0-69-1982-1189.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Łódź, Lublin, Rzeszów, Kielce, Opole, a wkrótce najprawdopodobniej Kraków z wyższymi cenami za parkowanie na miejskich parkingach, z kolei Warszawa, Wrocław, Poznań i Białystok z poszerzonymi strefami płatnego parkowania. Władze największych polskich miast szukają dodatkowych pieniędzy w kieszeniach kierowców. Bankier.pl sprawdza, ile obecnie trzeba zapłacić za postój na miejskich parkingach.</p>

## Zdolność kredytowa ruszyła w górę. Banki pożyczą tyle, ile przed wakacjami
 - [https://www.bankier.pl/wiadomosc/Kredyt-hipoteczny-dochod-13-tys-zl-zdolnosc-kredytowa-Styczen-2023-8478101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kredyt-hipoteczny-dochod-13-tys-zl-zdolnosc-kredytowa-Styczen-2023-8478101.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/77b656c5ce2d96-948-568-0-89-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zdecydowanie rosną szacunki zdolności kredytowej w kredytach
hipotecznych. Chociaż w porównaniu z poprzednimi miesiącami zmiana jest
odczuwalna, to trudno nazwać ją przełomową. Kredytodawcy proponują mniej więcej
takie kwoty, jakie były dostępne w czerwcu 2022 r.</p>

## Atak zimy w Japonii spowodował chaos komunikacyjny. Są ofiary śmiertelne
 - [https://www.bankier.pl/wiadomosc/Atak-zimy-w-Japonii-spowodowal-chaos-komunikacyjny-Sa-ofiary-smiertelne-8478473.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Atak-zimy-w-Japonii-spowodowal-chaos-komunikacyjny-Sa-ofiary-smiertelne-8478473.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 04:15:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/f/c6b4dc998528cc-948-568-0-181-2499-1499.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Śnieżne nawałnice i silny mróz spowodowały w Japonii śmierć co najmniej pięciu osób i chaos komunikacyjny - poinformowały w czwartek rano czasu lokalnego japońskie media.</p>

## Meta: Trump może wrócić na Facebooka
 - [https://www.bankier.pl/wiadomosc/Meta-Trump-moze-wrocic-na-Facebooka-8478469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Meta-Trump-moze-wrocic-na-Facebooka-8478469.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-01-26 01:20:00+00:00
 - user: None

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/4c2477e33cc604-948-568-0-18-1816-1089.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W najbliższych tygodniach były prezydent USA Donald Trump będzie mógł powrócić na Facebooka - poinformował w środę właściciel tego serwisu społecznościowego, firma Meta Platforms.</p>
