# Source Sky News, Source URL:http://feeds.skynews.com/feeds/rss/world.xml, Source language: en-US

## Police raid home of church machete attacker after deadly assault in Spain
 - [https://news.sky.com/story/police-raid-home-of-church-machete-attacker-after-deadly-assault-in-spain-12796208](https://news.sky.com/story/police-raid-home-of-church-machete-attacker-after-deadly-assault-in-spain-12796208)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 19:54:00+00:00
 - user: None

Police in Spain have raided the home of a Moroccan man who was arrested over machete attacks at two churches that left a church worker dead and a priest seriously injured in the southern city of Algeciras.

## UK to oppose Russian athletes competing at 2024 Paris Olympics as neutrals
 - [https://news.sky.com/story/uk-government-to-oppose-russian-athletes-competing-at-2024-paris-olympics-as-neutrals-12796055](https://news.sky.com/story/uk-government-to-oppose-russian-athletes-competing-at-2024-paris-olympics-as-neutrals-12796055)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 14:50:00+00:00
 - user: None

The British government is to summon opposition to Russian athletes being allowed to compete at the 2024 Paris Olympics as neutrals.

## Zelenskyy not in mood to compromise despite fears of Russian gains as Ukraine war drags on
 - [https://news.sky.com/story/ukraine-war-volodymyr-zelenskyy-not-in-mood-to-compromise-despite-fears-of-russian-gains-as-conflict-drags-on-12796052](https://news.sky.com/story/ukraine-war-volodymyr-zelenskyy-not-in-mood-to-compromise-despite-fears-of-russian-gains-as-conflict-drags-on-12796052)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 14:29:00+00:00
 - user: None

Ukrainian President Volodymyr Zelenskyy has branded Russia's Vladimir Putin a "nobody" and says he is not interested in talking to him.

## 'Stay away from toxic people,' advises world's oldest person
 - [https://news.sky.com/story/worlds-oldest-person-maria-branyas-morera-advises-staying-away-from-toxic-people-12796025](https://news.sky.com/story/worlds-oldest-person-maria-branyas-morera-advises-staying-away-from-toxic-people-12796025)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 14:10:00+00:00
 - user: None

The world's oldest person - a Spanish woman born in California - has recommended "staying away from toxic people".

## Nine Palestinians killed after Israeli raid
 - [https://news.sky.com/story/nine-palestinians-killed-after-israeli-raid-12796022](https://news.sky.com/story/nine-palestinians-killed-after-israeli-raid-12796022)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 14:03:00+00:00
 - user: None

Nine Palestinians have been killed and others wounded after an Israeli special forces raid in the northern West Bank city of Jenin.

## Will German tanks be enough to deter Putin?
 - [https://news.sky.com/story/ukraine-war-will-german-tanks-be-enough-to-deter-vladimir-putin-12795947](https://news.sky.com/story/ukraine-war-will-german-tanks-be-enough-to-deter-vladimir-putin-12795947)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 12:16:00+00:00
 - user: None

Faced with accusations it has lost vital time dithering over tanks for Ukraine, Germany put on a military show and fought back against its critics.

## Andrew Tate appears for second day of questioning over phones and laptops
 - [https://news.sky.com/story/andrew-tate-appears-in-romanian-prosecutors-office-for-second-day-of-questioning-over-phones-and-laptops-12795885](https://news.sky.com/story/andrew-tate-appears-in-romanian-prosecutors-office-for-second-day-of-questioning-over-phones-and-laptops-12795885)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 11:01:00+00:00
 - user: None

Andrew Tate has appeared at a prosecutors' office for a second day as forensic searches of his confiscated phones and laptops continue.&#160;

## Novak Djokovic's father joins Putin supporters at Australian Open
 - [https://news.sky.com/story/novak-djokovics-father-joins-putin-supporters-at-australian-open-12795710](https://news.sky.com/story/novak-djokovics-father-joins-putin-supporters-at-australian-open-12795710)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 07:40:00+00:00
 - user: None

Video has emerged of Novak Djokovic's father at a pro-Russian demonstration at the Australian Open tennis.

## Tanks, peace talks, Putin and Boris Johnson: Key points from Kay Burley's Zelenskyy interview
 - [https://news.sky.com/story/ukraine-war-tanks-peace-talks-putin-and-boris-johnson-key-points-from-kay-burleys-interview-with-volodymyr-zelenskyy-12795646](https://news.sky.com/story/ukraine-war-tanks-peace-talks-putin-and-boris-johnson-key-points-from-kay-burleys-interview-with-volodymyr-zelenskyy-12795646)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-01-26 04:07:00+00:00
 - user: None

Kay Burley sat down with President Volodymyr Zelenskyy in Kyiv for an exclusive Sky News interview.
