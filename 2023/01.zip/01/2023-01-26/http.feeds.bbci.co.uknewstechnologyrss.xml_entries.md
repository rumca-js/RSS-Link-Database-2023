# Source BBC tech, Source URL:http://feeds.bbci.co.uk/news/technology/rss.xml, Source language: en-US

## US hacks back against Hive ransomware crew
 - [https://www.bbc.co.uk/news/technology-64418723?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64418723?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-26 20:41:05+00:00
 - user: None

The US Department of Justice says its operation against the cyber gang was a 21st Century stakeout.

## Punchbags become smart with activity-tracking cover
 - [https://www.bbc.co.uk/news/technology-64410982?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-64410982?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-01-26 10:08:06+00:00
 - user: None

BBC Click’s Lara Lewington tries out some of the latest fitness technology.
