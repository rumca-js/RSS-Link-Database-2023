# Source Daily Mail, Source URL:https://www.dailymail.co.uk/news/index.rss, Source language: en-US

## Student nurses will get a quarter of their practical training using virtual reality in new shake-up
 - [https://www.dailymail.co.uk/news/article-11681683/Student-nurses-quarter-practical-training-using-virtual-reality-new-shake-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681683/Student-nurses-quarter-practical-training-using-virtual-reality-new-shake-up.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:51:55+00:00
 - user: None

Nurses will be taught how to treat everything from heart attack patients to crash victims using headsets as part of their courses from September.

## Katie Price admits she hit 'rock bottom' and 'tried to kill myself' after she crashed her BMW
 - [https://www.dailymail.co.uk/news/article-11681539/Katie-Price-admits-hit-rock-bottom-tried-kill-crashed-BMW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681539/Katie-Price-admits-hit-rock-bottom-tried-kill-crashed-BMW.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:49:52+00:00
 - user: None

The former glamour model, 44, said there was 'no excuse' for crashing her BMW on the B2135 near Partridge Green in West Sussex while under the influence and disqualified.

## Outback Wrangler Matt Wright reveals what happened at helicopter crash scene where Chris Wilson died
 - [https://www.dailymail.co.uk/news/article-11681451/Outback-Wrangler-Matt-Wright-reveals-happened-helicopter-crash-scene-Chris-Wilson-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681451/Outback-Wrangler-Matt-Wright-reveals-happened-helicopter-crash-scene-Chris-Wilson-died.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:49:09+00:00
 - user: None

Chris Wilson, 34, died in a chopper smash in a remote area of the Northern Territory. The Outback Wrangler star has revealed what allegedly happened when he landed at the scene of the smash.

## Anger over Woolworths shopper's 'unacceptable' act during his grocery run
 - [https://www.dailymail.co.uk/news/article-11681363/Anger-Woolworths-shoppers-unacceptable-act-grocery-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681363/Anger-Woolworths-shoppers-unacceptable-act-grocery-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:47:52+00:00
 - user: None

An image of a shoeless man shopping at Woolworths sparked online outrage before others came to his defence and said the supermarket giant was not responsible for what customers wear.

## Lidia Thorpe's agenda includes Aboriginal-led Republic amid Australia Day controversy
 - [https://www.dailymail.co.uk/news/article-11681237/Lidia-Thorpes-agenda-includes-Aboriginal-led-Republic-amid-Australia-Day-controversy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681237/Lidia-Thorpes-agenda-includes-Aboriginal-led-Republic-amid-Australia-Day-controversy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:46:27+00:00
 - user: None

The Greens senator and Indigenous rights campaigner brandished a 'battle stick' as she called for change during a fiery speech at an Invasion Day protest on Thursday in Melbourne.

## Bed Bath & Beyond defaults on its loans as bankruptcy looms
 - [https://www.dailymail.co.uk/news/article-11681569/Bed-Bath-defaults-loans-bankruptcy-looms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681569/Bed-Bath-defaults-loans-bankruptcy-looms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:37:24+00:00
 - user: None

The home goods chain said in a regulatory filing on Thursday that the default on its loans from JPMorgan Chase would force it to consider alternatives, including bankruptcy.

## ACCC crackdown on more than 100 social influencers after tip-offs from the public
 - [https://www.dailymail.co.uk/news/article-11681191/Watchdog-puts-social-influencers-notice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681191/Watchdog-puts-social-influencers-notice.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:29:13+00:00
 - user: None

Social media influencers who mislead their followers are facing a crackdown from the consumer watchdog as part of a push for more transparency.

## RNC leadership battle gets ugly as Harmeet Dhillon campaign PULLS DeSantis endorsement from website
 - [https://www.dailymail.co.uk/news/article-11681197/RNC-leadership-battle-gets-ugly-Harmeet-Dhillon-campaign-PULLS-DeSantis-endorsement-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681197/RNC-leadership-battle-gets-ugly-Harmeet-Dhillon-campaign-PULLS-DeSantis-endorsement-website.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:27:12+00:00
 - user: None

RNC challenger Harmeet Dhillon's campaign was force into an embarrassing u-turn on Thursday when it added a photograph of Florida Gov. Ron DeSantis to its endorsements page, before quickly deleting it.

## Mayor Adams vows free health care for homeless in lofty State of the City
 - [https://www.dailymail.co.uk/news/article-11681257/Mayor-Adams-vows-free-health-care-homeless-lofty-State-City.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681257/Mayor-Adams-vows-free-health-care-homeless-lofty-State-City.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:21:52+00:00
 - user: None

NYC Mayor Eric Adams has committed to using his second year in office to provide free healthcare to the city's homeless and crack down on its 'most wanted' criminals.

## Biden's promise to send 31 Abrams could take up to a YEAR - because the US has to buy more
 - [https://www.dailymail.co.uk/news/article-11681549/Bidens-promise-send-31-Abrams-YEAR-buy-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681549/Bidens-promise-send-31-Abrams-YEAR-buy-more.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:17:15+00:00
 - user: None

The process of delivering sophisticated new Abrams tanks to Ukraine will take months, with the Pentagon saying it does not have any excess tanks ready for transfer.

## 'Enjoy your freedom while you can.' Kirsten Bridegan sends a message to husband's killers
 - [https://www.dailymail.co.uk/news/article-11681359/Enjoy-freedom-Kirsten-Bridegan-sends-message-husbands-killers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681359/Enjoy-freedom-Kirsten-Bridegan-sends-message-husbands-killers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 23:01:16+00:00
 - user: None

Henry Tenon, 61, is charged with murder in the death of Jared Bridegan, 33, but authorities say hey know Tenon was not a sole actor but a co-conspirator with another person or persons.

## Louisiana man is sentenced to 45 years in prison for kidnapping and attempting to murder gay teen
 - [https://www.dailymail.co.uk/news/article-11681283/Louisiana-man-sentenced-45-years-prison-kidnapping-attempting-murder-gay-teen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681283/Louisiana-man-sentenced-45-years-prison-kidnapping-attempting-murder-gay-teen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:58:00+00:00
 - user: None

Chance Seneca, 21, was sentenced after he kidnapped and attempted to murder a gay teen he met on Grindr in 2020. Seneca sought to murder to 'satisfy a compulsive murder-fantasy'.

## The 11 women who have made the FBI's most wanted list across the agency's 73-year history
 - [https://www.dailymail.co.uk/news/article-11680923/The-11-women-FBIs-wanted-list-agencys-73-year-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680923/The-11-women-FBIs-wanted-list-agencys-73-year-history.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:56:45+00:00
 - user: None

Since its inception in 1950, the list - reserved for the nation's worst criminals - has only contained a handful of women, with just 11 of its 529 fugitives being female.

## Argentine customs agents seize $120,00 worth of currency, including bills used in Nazi camp
 - [https://www.dailymail.co.uk/news/article-11680543/Argentine-customs-agents-seize-120-00-worth-currency-including-bills-used-Nazi-camp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680543/Argentine-customs-agents-seize-120-00-worth-currency-including-bills-used-Nazi-camp.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:49:20+00:00
 - user: None

Customs agents in Argentina confiscated a large coin and bill collection that included currency from the 18th century and paper notes used in Nazi camps.

## Jeremy Hunt will vow to use 'British genius' to turbo-charge growth
 - [https://www.dailymail.co.uk/news/article-11681457/Jeremy-Hunt-vow-use-British-genius-turbo-charge-growth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681457/Jeremy-Hunt-vow-use-British-genius-turbo-charge-growth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:46:46+00:00
 - user: None

Setting out a plan for growth, the Chancellor is to hit out at the 'declinism' peddled by Labour and say this country is well placed to exploit 'the growth sectors which will define this century'.

## ISIS-inspired terrorist who killed eight people by  on NYC bike path in 2017 convicted on all counts
 - [https://www.dailymail.co.uk/news/article-11681475/ISIS-inspired-terrorist-killed-eight-people-NYC-bike-path-2017-convicted-counts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681475/ISIS-inspired-terrorist-killed-eight-people-NYC-bike-path-2017-convicted-counts.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:46:08+00:00
 - user: None

An Islamic extremist who killed eight people with a speeding truck in a 2017 rampage on a popular New York City bike path was convicted Thursday of federal crimes.

## Karate studio owner defends decision to ban student suing for discrimination
 - [https://www.dailymail.co.uk/news/article-11679805/Karate-studio-owner-defends-decision-ban-pharmacist-safety-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679805/Karate-studio-owner-defends-decision-ban-pharmacist-safety-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:45:16+00:00
 - user: None

The owner of a Long Island karate studio has defended his decision to ban his karate obsessed student trainee after the husband threatened business after learning of her affair with instructor.

## Huge 260-acre piece of land in LA's exclusive Bel-Air neighborhood up for auction
 - [https://www.dailymail.co.uk/news/article-11681161/Huge-260-acre-piece-land-LAs-exclusive-Bel-Air-neighborhood-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681161/Huge-260-acre-piece-land-LAs-exclusive-Bel-Air-neighborhood-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:39:15+00:00
 - user: None

The property is known as Senderos Canyon and covers six percent of Bel-Air. The land is currently the largest plot of land for sale in all of Los Angeles.

## Andrew 'Freddie' Flintoff 'puts his TV career on hold after horror Top Gear car crash'
 - [https://www.dailymail.co.uk/news/article-11681323/Andrew-Freddie-Flintoff-puts-TV-career-hold-horror-Gear-car-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681323/Andrew-Freddie-Flintoff-puts-TV-career-hold-horror-Gear-car-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:36:37+00:00
 - user: None

The presenter and former England ace, 45, was airlifted to hospital following a horror collision on a test track at the Dunsfold Aerodrome in Surrey on December 13 last year.

## Alice Evans facing arrest after failing to appear in court for restraining order violations
 - [https://www.dailymail.co.uk/news/article-11681025/Alice-Evans-facing-arrest-failing-appear-court-restraining-order-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681025/Alice-Evans-facing-arrest-failing-appear-court-restraining-order-violations.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:36:16+00:00
 - user: None

Alice Evans failed to appear at Airport Courthouse in LA for a scheduled arraignment on Thursday, and neither she nor her attorney called or contacted the court to explain her absence.

## Sky News commentator Sophie Elsworth slams Mike Carlton over Australian of the Year remarks
 - [https://www.dailymail.co.uk/news/article-11681153/Sky-News-commentator-Sophie-Elsworth-slams-Mike-Carlton-Australian-Year-remarks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681153/Sky-News-commentator-Sophie-Elsworth-slams-Mike-Carlton-Australian-Year-remarks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:34:55+00:00
 - user: None

Sophie Elsworth, who is the media writer for The Australian, tore into the left wing commentator over his comments about Taryn Brumfitt.

## DJ Flavinha accidentally blasting herself in the face with a confetti cannon
 - [https://www.dailymail.co.uk/news/article-11681061/DJ-Flavinha-accidentally-blasting-face-confetti-cannon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681061/DJ-Flavinha-accidentally-blasting-face-confetti-cannon.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:24:28+00:00
 - user: None

DJ Flavinha, real-name Flavia Ribiero, pictured, suffered an embarrassing blow on Saturday as her attempt to amp up the crowd with a confetti cannon at a show in Brazil backfired.

## George Santos 'stands by' his claim from 2020 that Jeffrey Epstein was murdered in jail
 - [https://www.dailymail.co.uk/news/article-11681297/George-Santos-stands-claim-2020-Jeffrey-Epstein-murdered-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681297/George-Santos-stands-claim-2020-Jeffrey-Epstein-murdered-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:24:21+00:00
 - user: None

Speaking to  reporters outside of his office including DailyMail.com, Santos also denied ever claiming he survived an assassination attempt - one of his latest in a string of public relations crises.

## Republican introduces plan to strip K-12 schools that teach critical race theory of federal funding
 - [https://www.dailymail.co.uk/news/article-11681291/Republican-introduces-plan-strip-K-12-schools-teach-critical-race-theory-federal-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681291/Republican-introduces-plan-strip-K-12-schools-teach-critical-race-theory-federal-funding.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:20:40+00:00
 - user: None

GOP Rep. Chip Roy is introducing a bill to defund public schools that practice 'racist teaching' by exposing students to 'divisive concepts' like critical race theory.

## Do your bit to mark the Coronation: Britain's biggest charities support day of volunteering
 - [https://www.dailymail.co.uk/news/article-11681423/Do-bit-mark-Coronation-Britains-biggest-charities-support-day-volunteering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681423/Do-bit-mark-Coronation-Britains-biggest-charities-support-day-volunteering.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:16:09+00:00
 - user: None

Dozens of charities have backed a day of volunteering on May 8, the Bank Holiday Monday of the Coronation long weekend, before the King's Coronation in just 100 days' time.

## James Comer suggests 'coordinated effort' by Biden admin to hide family's 'shady business schemes'
 - [https://www.dailymail.co.uk/news/article-11680587/James-Comer-suggests-coordinated-effort-Biden-admin-hide-familys-shady-business-schemes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680587/James-Comer-suggests-coordinated-effort-Biden-admin-hide-familys-shady-business-schemes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:00:59+00:00
 - user: None

The business dealings of Hunter Biden as well as if and how they ensnare President Joe Biden himself are a top priority for Comer's House Oversight and Accountability Committee.

## A towering compliment: Booming Blackpool could be the next Monte Carlo, casino boss says
 - [https://www.dailymail.co.uk/news/article-11681313/A-towering-compliment-Booming-Blackpool-Monte-Carlo-casino-boss-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681313/A-towering-compliment-Booming-Blackpool-Monte-Carlo-casino-boss-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:00:51+00:00
 - user: None

Business is booming again in Blackpool - best known for its Tower, old-school amusements and Pleasure Beach - after families developed a taste for staycations during the pandemic.

## How lack of chargers and soaring power costs have sent the electric vehicle revolution into reverse
 - [https://www.dailymail.co.uk/news/article-11681341/How-lack-chargers-soaring-power-costs-sent-electric-vehicle-revolution-reverse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681341/How-lack-chargers-soaring-power-costs-sent-electric-vehicle-revolution-reverse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 22:00:32+00:00
 - user: None

Heading to Blackpool to attend an awards ceremony, businesswoman Sophie Preston-Hall not only arrived late, but barely had time to get dressed.

## Isla Bryson enrolled in a Ayrshire College beauty course AFTER being charged for sex attacks
 - [https://www.dailymail.co.uk/news/article-11680963/Isla-Bryson-enrolled-Ayrshire-College-beauty-course-charged-sex-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680963/Isla-Bryson-enrolled-Ayrshire-College-beauty-course-charged-sex-attacks.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:53:24+00:00
 - user: None

Isla Bryson attended Ayrshire College's Kilwinning Campus in 2021. Her beauty course reportedly involved both classroom work and practical applications.

## Crooks fail to smash open an ATM after dragging it from a gas station convenience store
 - [https://www.dailymail.co.uk/news/article-11681207/Crooks-fail-smash-open-ATM-dragging-gas-station-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681207/Crooks-fail-smash-open-ATM-dragging-gas-station-convenience-store.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:52:11+00:00
 - user: None

Two crooks broke into a Washington gas station at 4.30am on January 17. They attempted to steal money out of an ATM machine, but were unable to.

## US takes out 'key operative and facilitator for ISIS global network' in Somalia
 - [https://www.dailymail.co.uk/news/article-11681203/US-takes-key-operative-facilitator-ISIS-global-network-Somalia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681203/US-takes-key-operative-facilitator-ISIS-global-network-Somalia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:48:20+00:00
 - user: None

The U.S. took out 'key' ISIS operative Bilal al-Sudani in an operation in northern Somalia, a senior U.S. official told reporters on Thursday. Ten of his ISIS companions died with him.

## The evolution of the ultimate punishment: How death penalty in the U.S has changed over 250 years
 - [https://www.dailymail.co.uk/news/article-11680405/The-evolution-ultimate-punishment-death-penalty-U-S-changed-250-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680405/The-evolution-ultimate-punishment-death-penalty-U-S-changed-250-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:48:19+00:00
 - user: None

While the punishment remains hugely controversial, the U.S remains one of only a handful of developed countries which still uses the death penalty in 2023.

## Greyhound trainer was 'battered by jilted love rival' on track ahead of race
 - [https://www.dailymail.co.uk/news/article-11681087/Greyhound-trainer-battered-jilted-love-rival-track-ahead-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681087/Greyhound-trainer-battered-jilted-love-rival-track-ahead-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:47:23+00:00
 - user: None

James Turner, 36, was allegedly attacked by jilted lover Neil Gargrow who ran out of the stands at Crayford Greyhound Track in Dartford, Kent and jumped on top of him.

## Biden makes joke about himself being 'stupid' - then gets congressman's name wrong
 - [https://www.dailymail.co.uk/news/article-11680701/Biden-makes-joke-stupid-gets-congressmans-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680701/Biden-makes-joke-stupid-gets-congressmans-wrong.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:43:49+00:00
 - user: None

President Biden accused Republicans of wanting to cause 'chaos' in the country but he fumbled his message at the start when he called Don Beyer, a well-known congressman, by the wrong name.

## Australia weather: Rain and scorching temperatures to batter country
 - [https://www.dailymail.co.uk/news/article-11680915/Australia-weather-Rain-scorching-temperatures-batter-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680915/Australia-weather-Rain-scorching-temperatures-batter-country.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:39:07+00:00
 - user: None

The mercury will soar across the country over the coming days with temperatures skyrocketing above 30C and wet weather accompanying the heat.

## Biden tapped big donor friend to get his niece Caroline a $85,000-a-year job
 - [https://www.dailymail.co.uk/news/article-11680881/Biden-tapped-big-donor-friend-niece-Caroline-85-000-year-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680881/Biden-tapped-big-donor-friend-niece-Caroline-85-000-year-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:34:51+00:00
 - user: None

Biden helped his convict 31-year-old niece Caroline Biden land an interview for a job at Masimo Corporation, whose owner is one of his biggest donors, but she balked at the $85,000-a-year salary.

## Moment gunman who fled the UK after shooting a businessman dead is taken off a plane in handcuffs
 - [https://www.dailymail.co.uk/news/article-11681083/Moment-gunman-fled-UK-shooting-businessman-dead-taken-plane-handcuffs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11681083/Moment-gunman-fled-UK-shooting-businessman-dead-taken-plane-handcuffs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:32:51+00:00
 - user: None

Tahir Zarif, 31, brutally murdered warehouse manager Akhtar Javeed in  Birmingham during an armed robbery before he fled to Pakistan. He has now been jailed for life for the killing.

## Monterey Park mass shooter was banned from dance studio where he killed 11 on Lunar New Year
 - [https://www.dailymail.co.uk/news/article-11680531/Monterey-Park-mass-shooter-banned-dance-studio-killed-11-Lunar-New-Year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680531/Monterey-Park-mass-shooter-banned-dance-studio-killed-11-Lunar-New-Year.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:32:13+00:00
 - user: None

Monterey Park gunman Huu Can Tran was not known to his victims, authorities have confirmed. Previous reports allege he was a regular at the studio he later gunned down.

## Father of LSU student, 21, shot dead in her car calls for 'culture change' in Baton Rouge
 - [https://www.dailymail.co.uk/news/article-11677051/Father-LSU-student-21-shot-dead-car-calls-culture-change-Baton-Rouge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677051/Father-LSU-student-21-shot-dead-car-calls-culture-change-Baton-Rouge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:28:14+00:00
 - user: None

Allison Rice, 21, had been on her way home from a night out with friends and was shot dead at around 2.30am in September last year near railroad tracks.

## 'Satanic' Ruth Bader-Ginsburg tribute statue slammed for horns and tentacles
 - [https://www.dailymail.co.uk/news/article-11680847/Gold-statue-horns-tentacles-paying-homage-Ruth-Bader-Ginsburg-gets-trolled-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680847/Gold-statue-horns-tentacles-paying-homage-Ruth-Bader-Ginsburg-gets-trolled-online.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:25:46+00:00
 - user: None

The eight-foot-tall statue, named 'NOW,' was placed atop a courthouse in the Flatiron District, standing alongside statues of famed lawmakers like Moses, Confucius and Zoroaster.

## Will Marianne Williamson make a comeback to take on Biden in 2024?
 - [https://www.dailymail.co.uk/news/article-11680573/Will-Marianne-Williamson-make-comeback-Biden-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680573/Will-Marianne-Williamson-make-comeback-Biden-2024.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 21:18:42+00:00
 - user: None

Author and self-help guru Marianne Williamson is headed to the early primary state of New Hampshire as she contemplates another run at the White House.

## Texas man lugs suitcase with his dead girlfriend in car trunk before he tosses it into a dumpster
 - [https://www.dailymail.co.uk/news/article-11680731/Texas-man-lugs-suitcase-dead-girlfriend-car-trunk-tosses-dumpster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680731/Texas-man-lugs-suitcase-dead-girlfriend-car-trunk-tosses-dumpster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:43:31+00:00
 - user: None

John Poulos was caught on camera placing the luggage bag with body of his dead girlfriend Valentina Trespalacios into the trunk of a car Sunday before leaving it in a dumpster in Colombia.

## Floyd Mayweather opens up about his estranged father
 - [https://www.dailymail.co.uk/news/article-11680607/Floyd-Mayweather-opens-estranged-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680607/Floyd-Mayweather-opens-estranged-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:41:34+00:00
 - user: None

The former fighter, 45, described how he 'became a man' from ages 16-21 when his father, Floyd Mayweather Sr, was in prison for drug trafficking.

## Royal expert warns Epstein revelations in Virginia Giuffre's book should concern Prince Andrew
 - [https://www.dailymail.co.uk/news/article-11680717/Royal-expert-warns-Epstein-revelations-Virginia-Giuffres-book-concern-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680717/Royal-expert-warns-Epstein-revelations-Virginia-Giuffres-book-concern-Prince-Andrew.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:39:50+00:00
 - user: None

Experts warn the revelations Prince Andrew's sex abuse accuser makes about Jeffrey Epstein will 'cause problems' for the disgraced royal as he tries to restore his reputation.

## Minnesota woman, 50, pleads guilty to leaving her newborn baby boy to die on shore of lake in 2003
 - [https://www.dailymail.co.uk/news/article-11680941/Minnesota-woman-50-pleads-guilty-leaving-newborn-baby-boy-die-shore-lake-2003.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680941/Minnesota-woman-50-pleads-guilty-leaving-newborn-baby-boy-die-shore-lake-2003.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:37:32+00:00
 - user: None

Jennifer Matter, 50, was arrested on May 10, 2022, and pleaded guilty on Wednesday for the death of her baby boy in 2003. She faces 27 years in prison if convicted.

## Priest who 'died' says he went to Hell and saw demons torturing by singing Rihanna's 'Umbrella'
 - [https://www.dailymail.co.uk/news/article-11680465/Priest-died-says-went-Hell-saw-demons-torturing-singing-Rihannas-Umbrella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680465/Priest-died-says-went-Hell-saw-demons-torturing-singing-Rihannas-Umbrella.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:26:26+00:00
 - user: None

Pastor Gerald Johnson, pictured, revealed in a viral TikTok video what he witnessed when he was sent to Hell. The Michigan man claims he saw demons torturing sinners with chart-topping songs.

## Nurse couldn't remember telling mother her child 'didn't die of prematurity', Lucy Letby TRIAL hears
 - [https://www.dailymail.co.uk/news/article-11680999/Nurse-remember-telling-mother-child-didnt-die-prematurity-Lucy-Letby-TRIAL-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680999/Nurse-remember-telling-mother-child-didnt-die-prematurity-Lucy-Letby-TRIAL-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:19:25+00:00
 - user: None

A nurse recalled the circumstances leading to a baby girl's death, while giving evidence today at the murder trial of Lucy Letby.

## Colorado black bear takes nearly 400 selfies in wildlife camera
 - [https://www.dailymail.co.uk/news/article-11680653/Colorado-black-bear-takes-nearly-400-selfies-wildlife-camera.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680653/Colorado-black-bear-takes-nearly-400-selfies-wildlife-camera.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 20:11:29+00:00
 - user: None

A bear in Colorado used a wildlife camera to take more than four hundred selfies.

## Masked prisoners run amok and pose with bloody inmates 'at HMP Wandsworth'
 - [https://www.dailymail.co.uk/news/article-11680605/Masked-prisoners-run-amok-pose-bloody-inmates-HMP-Wandsworth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680605/Masked-prisoners-run-amok-pose-bloody-inmates-HMP-Wandsworth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:48:24+00:00
 - user: None

Inmates - thought to be in HMP Wandsworth's C-wing - can be seen covered in blood and scratches as they shout and point at the camera in a clip filmed earlier this week.

## Legal expert fears attorney for Bryan Kohberger could derail his trial if she does not step down
 - [https://www.dailymail.co.uk/news/article-11680243/Legal-expert-fears-attorney-Bryan-Kohberger-derail-trial-does-not-step-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680243/Legal-expert-fears-attorney-Bryan-Kohberger-derail-trial-does-not-step-down.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:44:22+00:00
 - user: None

Chief Public defender Ann Taylor is currently representing Kohberger, 28, as the case heads to trial, but she was previously the lawyer of Cara Northington.

## Australian of the Year rips into Jelena Dokic's cruel fat-shaming trolls
 - [https://www.dailymail.co.uk/news/article-11680979/Australian-Year-rips-Jelena-Dokics-cruel-fat-shaming-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680979/Australian-Year-rips-Jelena-Dokics-cruel-fat-shaming-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:43:42+00:00
 - user: None

The new Australian of the Year, body image advocate Taryn Brumfitt, has called out trolls over the body shaming of tennis champion and Australian Open commentator Jelena Dokic.

## NYC and I-95 corridor experiencing lowest snowfalls in 50 years
 - [https://www.dailymail.co.uk/news/article-11680333/NYC-95-corridor-experiencing-lowest-snowfalls-50-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680333/NYC-95-corridor-experiencing-lowest-snowfalls-50-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:40:32+00:00
 - user: None

New York City is on track to break its late-season snowfall record of January 29. Other I-95 cities like Philadelphia and Boston have also seen minimal or no snow.

## Pub where Deborah Wood was last seen 'had been frequented by sadistic killer John Taylor'
 - [https://www.dailymail.co.uk/news/article-11680733/Pub-Deborah-Wood-seen-frequented-sadistic-killer-John-Taylor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680733/Pub-Deborah-Wood-seen-frequented-sadistic-killer-John-Taylor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:37:53+00:00
 - user: None

Taylor is likely to die behind bars for murdering Leanne Tiernan, 16, in 2000 and a string of rapes and other sex attacks, but detectives believe he may have killed four other young women

## Counter-terror police charge man after 'suspicious package' at Leeds hospital sparks evacuation
 - [https://www.dailymail.co.uk/news/article-11680935/Counter-terror-police-charge-man-suspicious-package-Leeds-hospital-sparks-evacuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680935/Counter-terror-police-charge-man-suspicious-package-Leeds-hospital-sparks-evacuation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:31:32+00:00
 - user: None

Mohammad Farooq, 27, of Roundhay, Leeds, has been charged with a series of terrorism, explosives and firearm offences in connection with an incident at St James's Hospital in Leeds last week.

## DeSantis lines up proxy battle with Trump, as he weighs into RNC contest against Ronna McDaniel
 - [https://www.dailymail.co.uk/news/article-11680753/DeSantis-lines-proxy-battle-Trump-weighs-RNC-contest-against-Ronna-McDaniel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680753/DeSantis-lines-proxy-battle-Trump-weighs-RNC-contest-against-Ronna-McDaniel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 19:24:53+00:00
 - user: None

'I think we need a change, I think we need to get some new blood in the RNC,' said Florida Gov. Ron DeSantis on Thursday, while Donald Trump backs incumbent Ronna McDaniel..

## Construction worker, 40, who was handed a £10,000 fine after refusing to pay £200
 - [https://www.dailymail.co.uk/news/article-11680795/Construction-worker-40-handed-10-000-fine-refusing-pay-200.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680795/Construction-worker-40-handed-10-000-fine-refusing-pay-200.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:55:33+00:00
 - user: None

Sean Howson, 40, was stopped by police at Green Park station, where he was using his coat to cover his nose and mouth, Southwark Crown Court heard.

## As RNC meets to pick a new leader, Donald Trump is 'elephant in the room'
 - [https://www.dailymail.co.uk/news/article-11677537/Republicans-meet-California-elect-RNC-chairman-amid-recriminations-midterms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677537/Republicans-meet-California-elect-RNC-chairman-amid-recriminations-midterms.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:52:15+00:00
 - user: None

The 168 members of the Republican National Committee are talkative when they get together for their winter meetings. But this time around they are steering clear of Donald Trump.

## Tyre Nichols death: Five fired Memphis police charged with second-degree murder
 - [https://www.dailymail.co.uk/news/article-11680707/All-five-officers-fired-death-Tyre-Nichols-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680707/All-five-officers-fired-death-Tyre-Nichols-charged.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:51:18+00:00
 - user: None

The five officers involved in the brutal death of Tyre Nichols are now in custody in Memphis, Tennessee after being charged in connection to the death of the young man.

## Biden is TRAILING Pete Buttigieg in key state of New Hampshire
 - [https://www.dailymail.co.uk/news/article-11680469/Biden-TRAILING-Pete-Buttigieg-key-state-New-Hampshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680469/Biden-TRAILING-Pete-Buttigieg-key-state-New-Hampshire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:50:39+00:00
 - user: None

President Joe Biden, who has been contending with the discovery of classified document in his home and office, trails Transportation Secretary Pete Buttigieg in New Hampshire in a new poll of Democrats.

## Cops raided Jared Bridegan's accused killer's home months before his arrest
 - [https://www.dailymail.co.uk/news/article-11679833/Cops-raided-Jared-Bridegans-accused-killers-home-months-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679833/Cops-raided-Jared-Bridegans-accused-killers-home-months-arrest.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:50:13+00:00
 - user: None

DailyMail.com has  learned some of the steps law enforcement took to tie suspect Henry Tenon to Jared Bridegan's murder including evidence allegedly garnered from a raid on his former home.

## Pictured: Pink-haired killer's victim is revealed as she is jailed for 20 years for knifing him
 - [https://www.dailymail.co.uk/news/article-11680703/Pictured-Pink-haired-killers-victim-revealed-jailed-20-years-knifing-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680703/Pictured-Pink-haired-killers-victim-revealed-jailed-20-years-knifing-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:46:48+00:00
 - user: None

Rebecca Press, 31, was under the influence of drink and drugs when she plunged a three-inch kitchen knife into the chest of Marc Ash, who was trying to calm her down after a night out.

## Biden's FCC nominee Gigi Sohn sits on board of nonprofit that honored dominatrix
 - [https://www.dailymail.co.uk/news/article-11680377/Bidens-FCC-nominee-Gigi-Sohn-sits-board-nonprofit-honored-dominatrix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680377/Bidens-FCC-nominee-Gigi-Sohn-sits-board-nonprofit-honored-dominatrix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:46:28+00:00
 - user: None

Gigi Sohn sits on the board of the Electronic Frontier Foundation which wants to uphold sex work online, and which honored an OnlyFans dominatrix in 2020 with a 'Pioneer' award.

## Pence aides didn't started packing up files until after January 6 because of Trump election denial
 - [https://www.dailymail.co.uk/news/article-11680641/Pence-aides-didnt-started-packing-files-January-6-Trump-election-denial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680641/Pence-aides-didnt-started-packing-files-January-6-Trump-election-denial.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:43:30+00:00
 - user: None

Mike Pence's team didn't start packing up his documents until after January 6, due to Donald Trump's insistence everyone act like they were staying for a second term.

## Staten Island lawyer, 38, shot dead in Chile after being gunned down by robbers
 - [https://www.dailymail.co.uk/news/article-11680233/Staten-Island-lawyer-38-shot-dead-Chile-gunned-robbers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680233/Staten-Island-lawyer-38-shot-dead-Chile-gunned-robbers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:32:26+00:00
 - user: None

Eric Eugene Garvin, 38, was last seen in Santiago, Chile on January 14, where he was vacationing with a friend. A week later, his family was informed he had been fatally shot.

## 500 suspects obsessed with school shootings referred to anti-extremism programme over past 3 years
 - [https://www.dailymail.co.uk/news/article-11680621/500-suspects-obsessed-school-shootings-referred-anti-extremism-programme-past-3-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680621/500-suspects-obsessed-school-shootings-referred-anti-extremism-programme-past-3-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:25:22+00:00
 - user: None

154 people were referred to Prevent in 2021-22 over their fixation on school murders. Data showed 80 individuals were referred to Prevent over their interest in 'incel' ideology in the past two years.

## AOC and progressive Democrats tear into Biden's border plan
 - [https://www.dailymail.co.uk/news/article-11680467/AOC-progressive-Democrats-tear-Bidens-border-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680467/AOC-progressive-Democrats-tear-Bidens-border-plan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:22:44+00:00
 - user: None

AOC and other House and Senate Democrats tore into Biden for new migrant policies and claim he is 'resurrecting' Trump-era protocols making it 'impossible' for immigrants to seek asylum.

## DR. NICOLE SAPHIER: Prescription drugs are handed like candy causing Ozempic and Adderall shortages
 - [https://www.dailymail.co.uk/news/article-11680359/DR-NICOLE-SAPHIER-Prescription-drugs-handed-like-candy-causing-Ozempic-Adderall-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680359/DR-NICOLE-SAPHIER-Prescription-drugs-handed-like-candy-causing-Ozempic-Adderall-shortages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:19:52+00:00
 - user: None

DR. SAPHIER: In an dangerous trend, America's medical industry is presenting drugs as a quick and easy solution for nearly everything that ails us - be it major, minor, or even non-existent.

## France looks for excuses NOT to send tanks to Ukraine
 - [https://www.dailymail.co.uk/news/article-11680569/France-looks-excuses-NOT-send-tanks-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680569/France-looks-excuses-NOT-send-tanks-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:17:13+00:00
 - user: None

Paris argues that, unlike the German Leopards, which are omnipresent across Europe with as many as 2,000 available, there are only about 200 Leclerc tanks. They are also no longer produced.

## Lawyer for four men accused of raping Madison Brooks says footage does not show sexual act
 - [https://www.dailymail.co.uk/news/article-11679821/Lawyer-four-men-accused-raping-Madison-Brooks-says-footage-does-not-sexual-act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679821/Lawyer-four-men-accused-raping-Madison-Brooks-says-footage-does-not-sexual-act.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 18:07:09+00:00
 - user: None

Video shows Madison Brooks, 19, directing 'choice language' at Casen Carver, 18, who is one of the four men accused of her rape.

## Southwest Airlines posts $220 MILLION Loss after holiday meltdown
 - [https://www.dailymail.co.uk/news/article-11680299/Southwest-Airlines-posts-220-MILLION-Loss-holiday-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680299/Southwest-Airlines-posts-220-MILLION-Loss-holiday-meltdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:56:46+00:00
 - user: None

Southwest Airlines reported a loss of $220 million during its fourth quarter due to its infamous holiday meltdown several weeks ago that saw close to 17,000 flights canceled.

## Boeing pleads NOT GUILTY in Texas court to deceiving regulators about plane safety 'issues'
 - [https://www.dailymail.co.uk/news/article-11680591/Boeing-pleads-NOT-GUILTY-Texas-court-deceiving-regulators-plane-safety-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680591/Boeing-pleads-NOT-GUILTY-Texas-court-deceiving-regulators-plane-safety-issues.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:48:15+00:00
 - user: None

Boeing's chief safety officer, Mike Delaney, entered the not-guilty plea on behalf of the plane-maker in an arraignment Thursday.

## Sir Rod Stewart says Government should 'stand down to give Labour a go'
 - [https://www.dailymail.co.uk/news/article-11680619/Sir-Rod-Stewart-says-Government-stand-Labour-go.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680619/Sir-Rod-Stewart-says-Government-stand-Labour-go.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:47:54+00:00
 - user: None

The rock and pop icon made a surprise call to Sky News to condemn the 'heartbreaking' current state of the NHS.

## Mother and her baby girl died in a head-on crash when they drove into path of an oncoming lorry
 - [https://www.dailymail.co.uk/news/article-11680527/Mother-baby-girl-died-head-crash-drove-path-oncoming-lorry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680527/Mother-baby-girl-died-head-crash-drove-path-oncoming-lorry.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:47:26+00:00
 - user: None

Nicola Jane Davies, 35, and 11-month-old Amelia Skye Davies died in February 2022 after Ms Davies's Ford Focus veered into the path of an oncoming lorry on the A41.

## Trans rapist Isla Bryson leaves women's prison and is put in all-male unit
 - [https://www.dailymail.co.uk/news/article-11680651/Transgender-rapist-Isla-Bryson-leaves-womens-prison-bars-male-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680651/Transgender-rapist-Isla-Bryson-leaves-womens-prison-bars-male-unit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:47:15+00:00
 - user: None

Transgender rapist Isla Bryson has today been moved out of Scotland's only all-women's prison to a male jail within hours of a humiliating U-turn by Nicola Sturgeon.

## Killer adult Afghan asylum seeker poses in school uniform while pretending to be a 14-year-old boy
 - [https://www.dailymail.co.uk/news/article-11680365/Killer-adult-Afghan-asylum-seeker-poses-school-uniform-pretending-14-year-old-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680365/Killer-adult-Afghan-asylum-seeker-poses-school-uniform-pretending-14-year-old-boy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:44:45+00:00
 - user: None

EXCLUSIVE: A photo of Lawangeen Abdulrahimzai enjoying the company of friends in school just 14 months before he killed an aspiring marine has emerged.

## Tech tycoon, 45, spends $2 million a year on team of doctors to regain his teenage body
 - [https://www.dailymail.co.uk/news/article-11679715/Tech-tycoon-45-spends-2-million-year-team-doctors-regain-teenage-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679715/Tech-tycoon-45-spends-2-million-year-team-doctors-regain-teenage-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:39:14+00:00
 - user: None

A tech tycoon worth nearly half a billion dollars has dedicated his life and body to reverse the aging process.

## Trump warns Biden sending tanks to Ukraine sets the stage for a NUCLEAR war
 - [https://www.dailymail.co.uk/news/article-11680445/Trump-warns-Biden-sending-tanks-Ukraine-sets-stage-NUCLEAR-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680445/Trump-warns-Biden-sending-tanks-Ukraine-sets-stage-NUCLEAR-war.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:33:29+00:00
 - user: None

Former President Donald Trump warned that sending tanks to Ukraine was the step before nuclear war as he claimed ending the conflict with Russia should be 'so easy.'

## Teenage boys are convicted of murdering father with 2ft Rambo knife but girlfriends are cleared
 - [https://www.dailymail.co.uk/news/article-11680139/Teenage-boys-convicted-murdering-father-2ft-Rambo-knife-girlfriends-cleared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680139/Teenage-boys-convicted-murdering-father-2ft-Rambo-knife-girlfriends-cleared.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:25:53+00:00
 - user: None

Abbie Mills (pictured), 18, was cleared of assisting an offender as three teenage boys, aged 18 and 19, were convicted of the murder of unsuspecting Frantisek Olah.

## Iraq sentences 14 ISIS fanatics to death over horrifying 2014 massacre
 - [https://www.dailymail.co.uk/news/article-11680371/Iraq-sentences-14-ISIS-fanatics-death-horrifying-2014-massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680371/Iraq-sentences-14-ISIS-fanatics-death-horrifying-2014-massacre.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:22:47+00:00
 - user: None

The massacre, one of the worst committed by ISIS in Iraq, saw the extremists in June 2014 abduct up to 1,700 mainly Shiite cadets from the Speicher military base in the Tikrit region and execute them.

## JANET STREET-PORTER: How dare the 'Diva of Divorce' tell female lawyers to put on their glad rags
 - [https://www.dailymail.co.uk/news/article-11680515/JANET-STREET-PORTER-dare-Diva-Divorce-tell-female-lawyers-glad-rags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680515/JANET-STREET-PORTER-dare-Diva-Divorce-tell-female-lawyers-glad-rags.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:19:04+00:00
 - user: None

JANET STREET-PORTER: This week, staff at top divorce lawyers Vardags were told by their boss they should dress like members of a high-end club.

## Subscribe to The Mail+ to read all the Daily Mail's news, views and features
 - [https://www.dailymail.co.uk/news/article-11644565/Subscribe-Mail-read-Daily-Mails-news-views-features.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11644565/Subscribe-Mail-read-Daily-Mails-news-views-features.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:18:10+00:00
 - user: None

Sign up to The Mail+ to keep up with the latest royal news and scandal, play the best brainteasing puzzles and get the world-beating Daily Mail newspaper digitally as it looks in print.

## West Virginia 'kidnapper', 47, looks insane in mugshot after allegedly torturing and burning a woman
 - [https://www.dailymail.co.uk/news/article-11680301/West-Virginia-kidnapper-47-looks-insane-mugshot-allegedly-torturing-burning-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680301/West-Virginia-kidnapper-47-looks-insane-mugshot-allegedly-torturing-burning-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:16:07+00:00
 - user: None

Sammy Martz, 47, of Philippi, West Virginia, flashed a disturbing smile after being arrested for allegedly kidnapping a woman, threatening to kill her and burning her on Tuesday.

## Rare amber weather warning for extreme cold is extended
 - [https://www.dailymail.co.uk/news/article-11680437/Rare-amber-weather-warning-extreme-cold-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680437/Rare-amber-weather-warning-extreme-cold-extended.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:08:24+00:00
 - user: None

The current amber weather warning for cold weather has been extended until Saturday.

## Ex-PM Boris Johnson swaps his London Tube beanie for Ukrainian Railways upgrade on Kiev trip
 - [https://www.dailymail.co.uk/news/article-11680507/Ex-PM-Boris-Johnson-swaps-London-Tube-beanie-Ukrainian-Railways-upgrade-Kiev-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680507/Ex-PM-Boris-Johnson-swaps-London-Tube-beanie-Ukrainian-Railways-upgrade-Kiev-trip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 17:06:11+00:00
 - user: None

The former prime minister, who often excites comment for his dishevelled appearance, has been sporting a new hat in vivid colours in recent days.

## Surrey Police close criminal probe into death of woman killed in dog attack at beauty spot
 - [https://www.dailymail.co.uk/news/article-11680195/Surrey-Police-close-criminal-probe-death-woman-killed-dog-attack-beauty-spot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680195/Surrey-Police-close-criminal-probe-death-woman-killed-dog-attack-beauty-spot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:58:02+00:00
 - user: None

Eight dogs were seized at the scene in Caterham and remain in police custody subject to forensic investigation, though no prosecutions are being brought against any individuals.

## Top barrister's girlfriend developed 'obsession' and messaged him after being convicted, court hears
 - [https://www.dailymail.co.uk/news/article-11680001/Top-barristers-girlfriend-developed-obsession-messaged-convicted-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680001/Top-barristers-girlfriend-developed-obsession-messaged-convicted-court-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:56:20+00:00
 - user: None

Helen Faure, 52, (pictured left) was handed a 12-month prison sentence suspended for two years after breaching a restraining order that banned five times.

## Scientology leader is MISSING as lawyers try to seek him over child trafficking lawsuit
 - [https://www.dailymail.co.uk/news/article-11679679/Scientology-leader-MISSING-lawyers-try-seek-child-trafficking-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679679/Scientology-leader-MISSING-lawyers-try-seek-child-trafficking-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:55:49+00:00
 - user: None

David Miscavige, 62, has been avoiding being served a lawsuit brought forth by former Sea Org members Valeska Paris, Gawain Baxter, and Laura Baxter.

## Holocaust survivor, 87, is swindled out of $2.8million life savings in scam by Florida woman
 - [https://www.dailymail.co.uk/news/article-11679625/Holocaust-survivor-87-swindled-2-8-million-life-savings-scam-Florida-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679625/Holocaust-survivor-87-swindled-2-8-million-life-savings-scam-Florida-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:51:04+00:00
 - user: None

The con was allegedly carried out over the course of several years by 36-year-old Peaches Stergo, and left the unnamed 87-year-old broke, while the suspect allegedly lived high on the hog.

## Texas man is extradited from Panama to Colombia to face charges for murder of DJ girlfriend
 - [https://www.dailymail.co.uk/news/article-11680069/Texas-man-extradited-Panama-Colombia-face-charges-murder-DJ-girlfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680069/Texas-man-extradited-Panama-Colombia-face-charges-murder-DJ-girlfriend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:50:42+00:00
 - user: None

John Poulos, wanted for the murder of his DJ girlfriend who was found strangled to death in a suitcase, was extradited from Panama to Colombia on Wednesday night.

## Director of GCHQ intelligence agency Jeremy Fleming 'will step down from his position'
 - [https://www.dailymail.co.uk/news/article-11680459/Director-GCHQ-intelligence-agency-Jeremy-Fleming-step-position.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680459/Director-GCHQ-intelligence-agency-Jeremy-Fleming-step-position.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:50:32+00:00
 - user: None

Since April 2017,  Fleming has been director of GCHQ - often called 'Britain's listening post', which works to defend the UK from cyber attacks and terror plots.

## EXCLUSIVE Schizophrenic woman, 38, lay dead in social housing for nearly four years
 - [https://www.dailymail.co.uk/news/article-11679975/EXCLUSIVE-Schizophrenic-woman-38-lay-dead-social-housing-nearly-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679975/EXCLUSIVE-Schizophrenic-woman-38-lay-dead-social-housing-nearly-four-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:50:25+00:00
 - user: None

EXCLUSIVE: Laura Winham is thought to have died in her flat in Woking, Surrey, in November 2017, but she was only discovered in May 2021 when family urged police to break in.

## George Santos says he's been asked to co-sponsor seven bills in Congress so far despite scandals
 - [https://www.dailymail.co.uk/news/article-11680223/George-Santos-says-hes-asked-sponsor-seven-bills-Congress-far-despite-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680223/George-Santos-says-hes-asked-sponsor-seven-bills-Congress-far-despite-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:50:23+00:00
 - user: None

Among them is an impeachment resolution against Homeland Security Secretary Alejandro Mayorkas, led by Texas GOP Rep. Pat Fallon and co-sponsored by 34 other lawmakers.

## Michigan School board member who tweeted 'whiteness is evil' says ex-husband informed her views
 - [https://www.dailymail.co.uk/news/article-11679863/Michigan-School-board-member-tweeted-whiteness-evil-says-ex-husband-informed-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679863/Michigan-School-board-member-tweeted-whiteness-evil-says-ex-husband-informed-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:44:39+00:00
 - user: None

Michigan school board member Kesha Hamilton has refused to apologize for tweets claiming 'whiteness is evil'. Hamilton, pictured, says her views are informed by marriage to a white man

## Thrill-seekers left hanging upside-down 30ft in the air after ride gets stuck at Chinese fairground
 - [https://www.dailymail.co.uk/news/article-11680061/Thrill-seekers-left-hanging-upside-30ft-air-ride-gets-stuck-Chinese-fairground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680061/Thrill-seekers-left-hanging-upside-30ft-air-ride-gets-stuck-Chinese-fairground.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:44:23+00:00
 - user: None

The nightmarish experience took place at a playground in Funan County, Anhui Province on January 19. More than 20 people were stuck for around 10 minutes.

## Shamima Begum recalls saying 'no' when her mother begged her to come home from ISIS
 - [https://www.dailymail.co.uk/news/article-11679335/Shamima-Begum-recalls-saying-no-mother-begged-come-home-ISIS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679335/Shamima-Begum-recalls-saying-no-mother-begged-come-home-ISIS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:39:16+00:00
 - user: None

Begum even suggested her devastated family were 'responsible' for her plight, saying that their tearful appeals for her to come back to the UK 'put me all over the media'.

## Animal shelter REUNITES  dog with owner who dropped her off with heart-breaking note
 - [https://www.dailymail.co.uk/news/article-11679949/Animal-shelter-tackles-homelessness-reuniting-abandoned-dog-owner-left-heart-breaking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679949/Animal-shelter-tackles-homelessness-reuniting-abandoned-dog-owner-left-heart-breaking.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:36:39+00:00
 - user: None

A Tennessee animal shelter reunited an abandoned dog named Lilo with her homeless owner. Lilo was found wandering the streets with a note on her collar that read: 'Please love me.'

## Cardiff man arrested over killing of paedophile drag queen has been released on bail
 - [https://www.dailymail.co.uk/news/article-11680057/Cardiff-man-arrested-killing-paedophile-drag-queen-released-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680057/Cardiff-man-arrested-killing-paedophile-drag-queen-released-bail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:34:50+00:00
 - user: None

A man, 50, who was detained three days after the body of drag queen and convicted child sex-offender Darren Moore, 39, was found in Cardiff city centre on January 22 has been released on bail.

## Murdered Oklahoma girl Athena Brownfield, 4, is mourned by community
 - [https://www.dailymail.co.uk/news/article-11679647/Murdered-Oklahoma-girl-Athena-Brownfield-4-mourned-community.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679647/Murdered-Oklahoma-girl-Athena-Brownfield-4-mourned-community.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:22:20+00:00
 - user: None

A heartbroken Oklahoma community has gathered to mourn the loss of four-year-old Athena Brownfield, who was murdered on Christmas Day before being tragically found almost a month later

## Connecticut investment firm banker, 46, jumps to his death from rooftop bar in Times Square
 - [https://www.dailymail.co.uk/news/article-11679471/Connecticut-investment-firm-banker-46-jumps-death-rooftop-bar-Times-Square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679471/Connecticut-investment-firm-banker-46-jumps-death-rooftop-bar-Times-Square.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:20:44+00:00
 - user: None

Dale Cheney, 46, committed suicide on Wednesday at 6.30pm, leaping from Bar 54 at the Hyatt Centric in Times Square.

## Widow of murdered Microsoft executive 'not surprised' suspect has ties to husband's ex-wife
 - [https://www.dailymail.co.uk/news/article-11679909/Widow-murdered-Microsoft-executive-not-surprised-suspect-ties-husbands-ex-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679909/Widow-murdered-Microsoft-executive-not-surprised-suspect-ties-husbands-ex-wife.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:19:54+00:00
 - user: None

The widow of murdered Microsoft executive Jared Bridegan has said she is 'not surprised' that his suspected killer has ties to her husband's ex-wife.

## Woman, 40, appears in court charged with robbing a 63-year-old man of his mobility scooter
 - [https://www.dailymail.co.uk/news/article-11680075/Woman-40-appears-court-charged-robbing-63-year-old-man-mobility-scooter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680075/Woman-40-appears-court-charged-robbing-63-year-old-man-mobility-scooter.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 16:00:55+00:00
 - user: None

Kimberley Ann Hawkins (pictured), 40, appeared before Cheltenham Magistrates' Court on Thursday charged with one offence.

## Husband of midwife who 'strangled her two kids to death' had left for 25 MINUTES to get takeout food
 - [https://www.dailymail.co.uk/news/article-11679823/Husband-midwife-strangled-two-kids-death-left-25-MINUTES-takeout-food.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679823/Husband-midwife-strangled-two-kids-death-left-25-MINUTES-takeout-food.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:50:23+00:00
 - user: None

Patrick Clancy was out for 25 minutes to grab takeout for his family when he found his wife, Lindsay, unconscious after dropping for their second-floor window and allegedly killing two of their kids.

## Biden's plea to billionaire Democrats before announcing 2024 run
 - [https://www.dailymail.co.uk/news/article-11680145/Bidens-plea-billionaire-Democrats-announcing-2024-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680145/Bidens-plea-billionaire-Democrats-announcing-2024-run.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:49:30+00:00
 - user: None

President Biden is forging ahead with plans for a 2024 campaign - despite concerns about his age - as he eyes up wealthy Democratic donors to court in the coming weeks.

## New York man quit $40,000 teaching job to make over $120K as a DOG WALKER
 - [https://www.dailymail.co.uk/news/article-11679777/New-York-man-quit-40-000-teaching-job-make-120K-DOG-WALKER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679777/New-York-man-quit-40-000-teaching-job-make-120K-DOG-WALKER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:49:00+00:00
 - user: None

Michael Josephs started walking dogs as a side-gig in 2019, and did so well he was able to quit his teaching job. He started Parkside Pups later that year, and his since hired five fulltime employees.

## Teen who filmed Madi Brooks and LAUGHED after she was 'raped' is high school Varsity Football player
 - [https://www.dailymail.co.uk/news/article-11679553/Teen-filmed-Madi-Brooks-LAUGHED-raped-high-school-Varsity-Football-player.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679553/Teen-filmed-Madi-Brooks-LAUGHED-raped-high-school-Varsity-Football-player.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:48:23+00:00
 - user: None

Kaivon Washington, 18, is on the roster for the Walker High School Varsity Football team and is expected to graduate later this summer.

## Rep. Adam Schiff is running for the Senate in California
 - [https://www.dailymail.co.uk/news/article-11680117/Rep-Adam-Schiff-running-Senate-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680117/Rep-Adam-Schiff-running-Senate-California.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:48:12+00:00
 - user: None

Rep. Adam Schiff announced Thursday that he was running for Senate, launching a bid to talk the place of 89-year-old Sen. Dianne Feinstein.

## School girl, 14, died by accident after inhaling deodorant areosol fumes
 - [https://www.dailymail.co.uk/news/article-11679037/School-girl-14-died-accident-inhaling-deodorant-areosol-fumes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679037/School-girl-14-died-accident-inhaling-deodorant-areosol-fumes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:47:14+00:00
 - user: None

Giorgia Green, 14 from Derby, was found unresponsive in her bedroom this year after accidentally inhaling deodorant. Her parents are raising awareness of the dangers of aerosol sprays

## Mentally disabled girl, 14, raped by her uncle is refused an abortion by Polish hospitals
 - [https://www.dailymail.co.uk/news/article-11680043/Mentally-disabled-girl-14-raped-uncle-refused-abortion-Polish-hospitals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680043/Mentally-disabled-girl-14-raped-uncle-refused-abortion-Polish-hospitals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:47:04+00:00
 - user: None

The Catholic nation has some of the strictest laws on abortion in Europe, and doctors can even refuse to provide them on ethical grounds, a law which has been slammed by women's rights activists.

## Hippy crack-down: Why ministers are pushing to ban dangerous 'laughing gas'
 - [https://www.dailymail.co.uk/news/article-11679241/Hippy-crack-ministers-pushing-ban-dangerous-laughing-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679241/Hippy-crack-ministers-pushing-ban-dangerous-laughing-gas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:45:43+00:00
 - user: None

Also referred to as 'nos', users breathe in laughing gas through balloons or cannisters - which cost just £25 for industrial-sized containers - causing a feeling of euphoria, relaxation and dissociation

## Serving Met Police officer, 38, appears in court to deny sexually assaulting woman
 - [https://www.dailymail.co.uk/news/article-11679995/Serving-Met-Police-officer-38-appears-court-deny-sexually-assaulting-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679995/Serving-Met-Police-officer-38-appears-court-deny-sexually-assaulting-woman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:43:42+00:00
 - user: None

A serving Metropolitan Police officer has appeared in court to deny sexually assaulting a woman.

## ChatGPT averaged a C+ when law professors used it to generate answers to law school exams
 - [https://www.dailymail.co.uk/news/article-11679757/ChatGPT-averaged-C-law-professors-used-generate-answers-law-school-exams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679757/ChatGPT-averaged-C-law-professors-used-generate-answers-law-school-exams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:39:22+00:00
 - user: None

A group of University of Minnesota Law School instructors administered ChatGPT four law school exams and discovered that the bot was a C+ student on paper.

## Terrifying moment out-of-control bus careers into a lake and fills with water in Turkey
 - [https://www.dailymail.co.uk/news/article-11679969/Terrifying-moment-control-bus-careers-lake-fills-water-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679969/Terrifying-moment-control-bus-careers-lake-fills-water-Turkey.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:36:24+00:00
 - user: None

Water cascaded into the bus as footage captured the driver and passengers as they were knocked back by the brutal force of the water in the Battalgazi district in eastern Turkey.

## Mother Lauren Watts' husband shares heartbreaking letter after her death: Queensland
 - [https://www.dailymail.co.uk/news/article-11678295/Mother-Lauren-Watts-husband-shares-heartbreaking-letter-death-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678295/Mother-Lauren-Watts-husband-shares-heartbreaking-letter-death-Queensland.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:33:21+00:00
 - user: None

Queensland mother Lauren Watts, 40, died suddenly on Tuesday as she was getting her son ready for his first day of prep. The popular nursing graduate was remembered as s 'beautiful soul'.

## Boy who could not swim, drowned when he jumped from a rope swing into lake inquest hears
 - [https://www.dailymail.co.uk/news/article-11680053/Boy-not-swim-drowned-jumped-rope-swing-lake-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11680053/Boy-not-swim-drowned-jumped-rope-swing-lake-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:24:18+00:00
 - user: None

Kyron Hibbert's friends tried to save him, but the teenager disappeared under the water of Stewartby lake, a former clay pit where swimming is banned.

## KENNY XU: The hate-filled hard left punish thousands of hard-working students of the 'wrong' race
 - [https://www.dailymail.co.uk/news/article-11679613/KENNY-XU-hate-filled-hard-left-punish-thousands-hard-working-students-wrong-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679613/KENNY-XU-hate-filled-hard-left-punish-thousands-hard-working-students-wrong-race.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:20:41+00:00
 - user: None

XU: High school bureaucrats at 17 schools in Fairfax, Loudoun and Prince William counties have admitted to withholding National Merit Commended Students awards from their kids.

## Trainee electrician killed in 'ambush as he got out of a car just yards from his west London home'
 - [https://www.dailymail.co.uk/news/article-11679487/Trainee-electrician-killed-ambush-got-car-just-yards-west-London-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679487/Trainee-electrician-killed-ambush-got-car-just-yards-west-London-home.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:18:19+00:00
 - user: None

Fernando Johnson, 23, was attacked and killed on Rosebank Way in Acton as he left his vehicle in the early hours of Thursday morning.

## JD Vance claims sending military aid to Ukraine is making US vulnerable against CHINA
 - [https://www.dailymail.co.uk/news/article-11679799/JD-Vance-claims-sending-military-aid-Ukraine-making-vulnerable-against-CHINA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679799/JD-Vance-claims-sending-military-aid-Ukraine-making-vulnerable-against-CHINA.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:17:39+00:00
 - user: None

Speaking to Fox & Friends on Thursday morning, Vance claimed Ukraine's government had a 'corruption' problem and called Russia's war against it a 'strategic quagmire.'

## Australia Day celebrations on the Gold Coast as revellers enjoy the sun ignoring Invasion Day fury
 - [https://www.dailymail.co.uk/news/article-11679151/Australia-Day-celebrations-Gold-Coast-revellers-enjoy-sun-ignoring-Invasion-Day-fury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679151/Australia-Day-celebrations-Gold-Coast-revellers-enjoy-sun-ignoring-Invasion-Day-fury.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:16:41+00:00
 - user: None

Despite the debate around keeping January 26 as Australia Day, some were content to take the public holiday as a chance to relax and enjoy some picture-perfect weather.

## Beast who faked to be taxi driver to pick up woman before kidnapping and raping jailed for 18 years
 - [https://www.dailymail.co.uk/news/article-11679793/Beast-faked-taxi-driver-pick-woman-kidnapping-raping-jailed-18-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679793/Beast-faked-taxi-driver-pick-woman-kidnapping-raping-jailed-18-years.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:15:46+00:00
 - user: None

Yuseab Woldeab, 27, lured the woman into his vehicle by pulling over and offering to drop her home after a night out.

## Two men arrested in connection with rape of LSU sorority girl Madi Brooks have been released
 - [https://www.dailymail.co.uk/news/article-11679927/Two-men-arrested-connection-rape-LSU-sorority-girl-Madi-Brooks-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679927/Two-men-arrested-connection-rape-LSU-sorority-girl-Madi-Brooks-released.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:09:59+00:00
 - user: None

Casen Carver, 18, and Everett Lee, 28, were both charged with participating or witnessing the rape of Madi, 19, on January 15.
Court records show that both were released on bail on January 24.

## Red-haired girl, 13, is stabbed with scissors by a schoolboy 'who made fun of her hair'
 - [https://www.dailymail.co.uk/news/article-11679783/Red-haired-girl-13-stabbed-scissors-schoolboy-hair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679783/Red-haired-girl-13-stabbed-scissors-schoolboy-hair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 15:07:59+00:00
 - user: None

A 13-year-old red-headed girl was left with two 15mm-deep puncture wounds in her legs after she was stabbed with a small pair of scissors at a Kent school.

## Paul Doran drowned at Seven Mile Beach at Lennox Head trying to save daughter: Family pays tribute
 - [https://www.dailymail.co.uk/news/article-11679493/Paul-Doran-drowned-Seven-Mile-Beach-Lennox-Head-trying-save-daughter-Family-pays-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679493/Paul-Doran-drowned-Seven-Mile-Beach-Lennox-Head-trying-save-daughter-Family-pays-tribute.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:57:08+00:00
 - user: None

The family of five were at Seven Mile Beach at Lennox Head in northern NSW last week when young Lyra was caught in a rip.

## Women is left 'devastated' after 'car cannibals' strip her Citroen C1 in just two hours
 - [https://www.dailymail.co.uk/news/article-11679851/Women-left-devastated-car-cannibals-strip-Citroen-C1-just-two-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679851/Women-left-devastated-car-cannibals-strip-Citroen-C1-just-two-hours.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:54:59+00:00
 - user: None

Rebecca Scotland said her car was left undriveable after parts were professionally removed as she left it in a Birmingham car park.

## National Archives weighs searching all ex-presidents and VPs for classified documents
 - [https://www.dailymail.co.uk/news/article-11679587/National-Archives-weighs-searching-ex-presidents-VPs-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679587/National-Archives-weighs-searching-ex-presidents-VPs-classified-documents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:48:30+00:00
 - user: None

The National Archives is weighing requiring all living former presidents and VPs to search personal records for classified documents after they were found at the homes of Biden, Trump and Pence.

## Russia warns it will treat uranium shells in German Leopard 2 tanks as 'dirty bombs'
 - [https://www.dailymail.co.uk/news/article-11679651/Russia-warns-treat-uranium-shells-German-Leopard-2-tanks-dirty-bombs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679651/Russia-warns-treat-uranium-shells-German-Leopard-2-tanks-dirty-bombs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:46:23+00:00
 - user: None

Konstantin Gavrilov, head of a Russian security delegation, claimed that Ukraine could arm their German-supplied Leopard 2 tanks with 'uranium core armour-piercing' shells.

## Great-grandson of Harold Shipman victim condemns life insurance firm's advert with image of killer
 - [https://www.dailymail.co.uk/news/article-11679571/Great-grandson-Harold-Shipman-victim-condemns-life-insurance-firms-advert-image-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679571/Great-grandson-Harold-Shipman-victim-condemns-life-insurance-firms-advert-image-killer.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:40:21+00:00
 - user: None

Tim Hill told MailOnline his great-grandfather Charles Henry Barlow was killed by Harold Shipman and said he finds it 'unconscionable' for DeadHappy to use the image of Shipman for 'cheap publicity.'

## Indigenous man Marcus Stewart and Voice campaigner refused Invasion Day march
 - [https://www.dailymail.co.uk/news/article-11678749/Indigenous-man-Marcus-Stewart-Voice-campaigner-refused-Invasion-Day-march.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678749/Indigenous-man-Marcus-Stewart-Voice-campaigner-refused-Invasion-Day-march.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:37:49+00:00
 - user: None

Thousands of Australians gathered for Invasion Day rallies across the country on Thursday, but one prominent Indigenous activist Marcus Stewart refused to take part.

## Warning of 'doom' for the Tories as major new poll finds middle-aged hold on to 'young' views
 - [https://www.dailymail.co.uk/news/article-11679683/Warning-doom-Tories-major-new-poll-finds-middle-aged-hold-young-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679683/Warning-doom-Tories-major-new-poll-finds-middle-aged-hold-young-views.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:26:39+00:00
 - user: None

The report by Portland Communications revealed that people were 'increasingly reaching middle age with the views they developed in their youth'.

## ALEX MURDAUGH MURDER TRAIL LIVE: First witnesses to take the stand
 - [https://www.dailymail.co.uk/news/live/article-11679627/ALEX-MURDAUGH-TRAIL-LIVE-Updates-Day4.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/live/article-11679627/ALEX-MURDAUGH-TRAIL-LIVE-Updates-Day4.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:26:26+00:00
 - user: None

DAILYMAIL LIVEBLOG: Follow along as witnesses take the stand in South Carolina legal scion's double homicide trial.

## Alex Murdaugh murder trial to hear from first responders on Day Four
 - [https://www.dailymail.co.uk/news/article-11679643/Alex-Murdaugh-murder-trial-hear-responders-Day-Four.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679643/Alex-Murdaugh-murder-trial-hear-responders-Day-Four.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:25:34+00:00
 - user: None

Alex Murdaugh, 54, is set to face testimony Thursday from first responders who arrived on the double-murder scene. Murdaugh allegedly shot his wife Maggie, 54, and son Paul, 22, on June 7, 2021.

## GMB star Noel Phillips says robber who called him N-word should have been sent to jail
 - [https://www.dailymail.co.uk/news/article-11679645/GMB-star-Noel-Phillips-says-robber-called-N-word-sent-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679645/GMB-star-Noel-Phillips-says-robber-called-N-word-sent-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:25:09+00:00
 - user: None

Mr Phillips, GMB's North America correspondent, was assaulted in Euston, central London in early September last year by the teenager (pictured being arrested), who also stole his necklace.

## Doug Emhoff takes off for Poland and Germany on trip to combat antisemitism
 - [https://www.dailymail.co.uk/news/article-11679705/Doug-Emhoff-takes-Poland-Germany-trip-combat-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679705/Doug-Emhoff-takes-Poland-Germany-trip-combat-antisemitism.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:21:19+00:00
 - user: None

Doug Emhoff departed Thursday for an historic trip to Poland and Germany aimed at combating the rising tide of antisemitism as he steps up his own role wiithin Biden's administration.

## Superfit mountaineering father-of-two, 54, was killed by altitude on Everest trek, inquest hears
 - [https://www.dailymail.co.uk/news/article-11679573/Superfit-mountaineering-father-two-54-killed-altitude-Everest-trek-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679573/Superfit-mountaineering-father-two-54-killed-altitude-Everest-trek-inquest-hears.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:19:04+00:00
 - user: None

Outdoor-lover, Kellinu Portelli, 54, set off from Britain for the 4,5000 mile trip for the 'adventure of a lifetime' trekking around the Himalayas.

## Which Wetherspoons pubs are closing in the UK?
 - [https://www.dailymail.co.uk/news/article-11679621/Which-Wetherspoons-pubs-closing-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679621/Which-Wetherspoons-pubs-closing-UK.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:16:35+00:00
 - user: None

Wetherspoons has confirmed that 10 of their pubs will be closing for good after being sold - with another 35 branches up for sale.

## Rebecca Press is jailed for 20 years for killing mother's neighbour
 - [https://www.dailymail.co.uk/news/article-11679529/Rebecca-Press-jailed-20-years-killing-mothers-neighbour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679529/Rebecca-Press-jailed-20-years-killing-mothers-neighbour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:14:37+00:00
 - user: None

Rebecca Press, 31, was under the influence of drink and drugs when she plunged a three-inch kitchen knife into the chest of Marc Ash, after a night out in south Wales.

## Unanswered Rust questions as Alec Baldwin heads to court on involuntarily manslaughter charges
 - [https://www.dailymail.co.uk/news/article-11672525/Unanswered-Rust-questions-Alec-Baldwin-heads-court-involuntarily-manslaughter-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11672525/Unanswered-Rust-questions-Alec-Baldwin-heads-court-involuntarily-manslaughter-charges.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 14:02:58+00:00
 - user: None

VIDEO: Baldwin is facing a maximum of five years in prison on involuntary manslaughter charges with a firearm enhancement.  Here, DailyMail.com breaks down the legal case against him.

## US contractor that makes F-16s are ready to ramp up production to 'backfill' supply
 - [https://www.dailymail.co.uk/news/article-11679497/US-contractor-make-F-16s-ready-ramp-production-backfill-supply.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679497/US-contractor-make-F-16s-ready-ramp-production-backfill-supply.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:54:15+00:00
 - user: None

US aerospace company Lockheed Martin said it will build more F-16s to 'backfill' any European countries who wish to supply their own jets to Ukraine via a third-party transfer.

## WATCH: Police reveal Britain's craziest drivers as loose timber and bucket fly from back of van
 - [https://www.dailymail.co.uk/news/article-11679377/WATCH-Police-reveal-Britains-craziest-drivers-loose-timber-bucket-fly-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679377/WATCH-Police-reveal-Britains-craziest-drivers-loose-timber-bucket-fly-van.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:36:36+00:00
 - user: None

Devon and Cornwall police have released a video showing footage of dangerous driving and a series of near misses which was sent in by members of the public.

## Image-obsessed 5ft 7in Putin wears high-heeled shoes while posing for pictures with Moscow students
 - [https://www.dailymail.co.uk/news/article-11679565/Image-obsessed-5ft-7in-Putin-wears-high-heeled-shoes-posing-pictures-Moscow-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679565/Image-obsessed-5ft-7in-Putin-wears-high-heeled-shoes-posing-pictures-Moscow-students.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:35:11+00:00
 - user: None

Image conscious Russian president Vladimir Putin was pictured in high heeled shoes at a photo opportunity with students in Moscow on Wednesday.

## National Grid 'made emergency requests to Europe for help to avert blackouts across the south-east'
 - [https://www.dailymail.co.uk/news/article-11679309/National-Grid-emergency-requests-Europe-help-avert-blackouts-south-east.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679309/National-Grid-emergency-requests-Europe-help-avert-blackouts-south-east.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:24:38+00:00
 - user: None

England faced its latest energy scare on Wednesday, amid claims that urgent requests were made to secure extra power for thousands of homes following a fault on the southern network.

## Italian mother wears shocking T-shirt of daughters dismembered body
 - [https://www.dailymail.co.uk/news/article-11679127/Italian-mother-wears-shocking-T-shirt-daughters-dismembered-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679127/Italian-mother-wears-shocking-T-shirt-daughters-dismembered-body.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:24:33+00:00
 - user: None

GRAPHIC WARNING. Mastropietro's mother, Alessandra Verni, attended the appeal court in Perugia yesterday, and nearly came to blows with her daughter's murderer.

## Shropshire boy aged 13 charged with string of sexual offences and attempted rapes of women and girls
 - [https://www.dailymail.co.uk/news/article-11679557/Shropshire-boy-aged-13-charged-string-sexual-offences-attempted-rapes-women-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679557/Shropshire-boy-aged-13-charged-string-sexual-offences-attempted-rapes-women-girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:24:18+00:00
 - user: None

The schoolboy had been accused of carrying out the shocking attacks in a month-long rampage in and around Telford, Shropshire on five girls aged 16-34.

## Father who raped teenage girl who took her own life could be freed
 - [https://www.dailymail.co.uk/news/article-11679423/Father-raped-teenage-girl-took-life-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679423/Father-raped-teenage-girl-took-life-freed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:23:49+00:00
 - user: None

The family of a teenage girl who took her own life after being sexually abused by her father have pleaded: 'keep this monster behind bars' after discovering he could be freed.

## Oxfordshire Council calls critics of ANPR camera net zero traffic scheme 'conspiracy theorists'
 - [https://www.dailymail.co.uk/news/article-11678887/Oxfordshire-Council-calls-critics-ANPR-camera-net-zero-traffic-scheme-conspiracy-theorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678887/Oxfordshire-Council-calls-critics-ANPR-camera-net-zero-traffic-scheme-conspiracy-theorists.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:22:55+00:00
 - user: None

In the 'dystopian' clip, Oxfordshire County Council chiefs defend a £6.5 million trial in Oxford that will create climate zones  on six inner-city roads.

## LSU student Madison Brooks died from 'multiple traumatic injuries' after being hit by a car
 - [https://www.dailymail.co.uk/news/article-11679447/LSU-student-Madison-Brooks-died-multiple-traumatic-injuries-hit-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679447/LSU-student-Madison-Brooks-died-multiple-traumatic-injuries-hit-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:22:22+00:00
 - user: None

East Baton Rouge Parish Coroners' Office says that Good Samaritans were guided by first responders on the phone in the pouring rain after Madi was hit by the ride-share car.

## Kate Middleton rolls up her sleeves with Prince William
 - [https://www.dailymail.co.uk/femail/article-11678561/Kate-Middleton-rolls-sleeves-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11678561/Kate-Middleton-rolls-sleeves-Prince-William.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:22:03+00:00
 - user: None

Prince William, 40, and Kate Middleton, 41, appeared in good spirits as they arrived at Windsor Foodshare this morning, where they prepared packages for the charity's clients to collect.

## Forget McDonald's! Paracetamol can contain as much salt as 21 PORTIONS of fries
 - [https://www.dailymail.co.uk/health/article-11670771/Forget-McDonalds-Paracetamol-contain-salt-21-PORTIONS-fries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11670771/Forget-McDonalds-Paracetamol-contain-salt-21-PORTIONS-fries.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:14:59+00:00
 - user: None

Experts are warning the millions of Brits who buy the dissolvable versions of  painkillers to be careful because their salt levels can be 'dangerously high'.

## Drones could soon be forced to have electronic NUMBER PLATES so police can track them
 - [https://www.dailymail.co.uk/sciencetech/article-11678681/Drones-soon-forced-electronic-NUMBER-PLATES-police-track-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11678681/Drones-soon-forced-electronic-NUMBER-PLATES-police-track-them.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:12:38+00:00
 - user: None

The plans are part of new regulations being drawn up by the Government that would allow a drone's speed, location, height, take-off point to be tracked - as well as the operator's location.

## Archie's ex nanny admits she compared herself to Prince William and Kate Middleton's au pair
 - [https://www.dailymail.co.uk/femail/article-11678771/Archies-ex-nanny-admits-compared-Prince-William-Kate-Middletons-au-pair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11678771/Archies-ex-nanny-admits-compared-Prince-William-Kate-Middletons-au-pair.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 13:00:19+00:00
 - user: None

Lorren Khumalo, from Zimbabwe, was hired by the Duke and Duchess of Sussex to care for their son Archie shortly after he was born in May 2019.

## Drone images capture empty £100m Brexit border control site built in Kent
 - [https://www.dailymail.co.uk/news/article-11679061/Drone-images-capture-100m-Brexit-border-control-site-built-Kent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679061/Drone-images-capture-100m-Brexit-border-control-site-built-Kent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:57:43+00:00
 - user: None

Richard Ballantyne, chief executive of the British Ports Association, said the failed port in Sevington, Kent was the product of a rush to 'get Brexit done.'

## UK strikes: When are trains, teachers, NHS staff and bus drivers walking out
 - [https://www.dailymail.co.uk/news/article-11679211/UK-strikes-trains-teachers-NHS-staff-bus-drivers-walking-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679211/UK-strikes-trains-teachers-NHS-staff-bus-drivers-walking-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:55:49+00:00
 - user: None

From teachers and nurses to border force staff and ambulance drivers, the wave of strikes that has crippled parts of Britain since late last year is continuing from today.

## Former police chief slams 'ridiculous' advice telling judges to consider their 'words and behaviour'
 - [https://www.dailymail.co.uk/news/article-11678733/Former-police-chief-slams-ridiculous-advice-telling-judges-consider-words-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678733/Former-police-chief-slams-ridiculous-advice-telling-judges-consider-words-behaviour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:25:35+00:00
 - user: None

Guidance from the Courts and Tribunals Judiciary has stressed that judges should address people 'respectfully', warning that 'shouting and snapping' should be avoided to prevent 'offence'.

## Transgender double rapist Isla Bryson will be transferred from women's prison, Nicola Sturgeon says
 - [https://www.dailymail.co.uk/news/article-11679469/Transgender-double-rapist-Isla-Bryson-transferred-womens-prison-Nicola-Sturgeon-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679469/Transgender-double-rapist-Isla-Bryson-transferred-womens-prison-Nicola-Sturgeon-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:25:17+00:00
 - user: None

The Scottish First Minister refused four times to deny the transgender double rapist remains in the all-female Cornton Vale prison in Stirling.

## Brooklyn Beckham fans criticise 'basic' vegan lasagne
 - [https://www.dailymail.co.uk/tvshowbiz/article-11678567/Brooklyn-Beckhams-fans-criticise-basic-vegan-lasagne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11678567/Brooklyn-Beckhams-fans-criticise-basic-vegan-lasagne.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:25:06+00:00
 - user: None

Brooklyn Beckham has been accused of making a recipe that school children would learn in their food technology lessons as he served up his latest cooking flop.

## Missing mum Wendy Sleeman's body in boot of Honda as son Slade Murdok is arrested: Gold Coast
 - [https://www.dailymail.co.uk/news/article-11679337/Missing-mum-Wendy-Sleemans-body-boot-Honda-son-Slade-Murdok-arrested-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679337/Missing-mum-Wendy-Sleemans-body-boot-Honda-son-Slade-Murdok-arrested-Gold-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:25:00+00:00
 - user: None

Police believe they have found the body of missing Gold Coast woman Wendy Sleeman who disappeared moments after reporting a break in at her  home on Tuesday.

## Accountant slams 'miscarriage of justice' over £200,000 Japanese knotweed bill
 - [https://www.dailymail.co.uk/news/article-11679077/Accountant-slams-miscarriage-justice-200-000-Japanese-knotweed-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679077/Accountant-slams-miscarriage-justice-200-000-Japanese-knotweed-bill.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:24:59+00:00
 - user: None

Jeremy Henderson, 41, sold his three-bedroom house in affluent Raynes Park, south-west London to Jonathan Downing, 30, but was locked in four years of legal wrangling.

## Bond girl Eva Green begins High Court legal battle with Hollywood producers over £4m sci-fi film
 - [https://www.dailymail.co.uk/news/article-11679235/Bond-girl-Eva-Green-begins-High-Court-legal-battle-Hollywood-producers-4m-sci-fi-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679235/Bond-girl-Eva-Green-begins-High-Court-legal-battle-Hollywood-producers-4m-sci-fi-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:24:31+00:00
 - user: None

The Casino Royale actress, 42, had been due to appear in A Patriot before production was shut down in October 2019.

## Homeowners' fury after 'delivery drivers leave new £2,000 leather sofa wedged in staircase'
 - [https://www.dailymail.co.uk/news/article-11679233/Homeowners-fury-delivery-drivers-leave-new-2-000-leather-sofa-wedged-staircase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679233/Homeowners-fury-delivery-drivers-leave-new-2-000-leather-sofa-wedged-staircase.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:24:10+00:00
 - user: None

Luke Ansell bought the king-size Chesterfield sofa-bed in December for his brand new home in Bournemouth, with the item being delivered on January 19.

## Dramatic moment 1,000 tons of ancient rock falls from 150ft sandstone cliffs on Jurassic Coast
 - [https://www.dailymail.co.uk/news/article-11678951/Dramatic-moment-1-000-tons-ancient-rock-falls-150ft-sandstone-cliffs-Jurassic-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678951/Dramatic-moment-1-000-tons-ancient-rock-falls-150ft-sandstone-cliffs-Jurassic-Coast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:19:36+00:00
 - user: None

The footage shows a huge chunk of the cliff as it suddenly crashes down in two stages at West Bay in Dorset, Bournemouth.

## Two relatives are arrested over murder of British man shot dead in Jamaica
 - [https://www.dailymail.co.uk/news/article-11679311/Two-relatives-arrested-murder-British-man-shot-dead-Jamaica.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679311/Two-relatives-arrested-murder-British-man-shot-dead-Jamaica.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:13:31+00:00
 - user: None

Michael Brown, 48, who had been involved in a 'bitter' family feud over properties left to him by his late mother, was gunned down in Mike Town last Thursday.

## Mother of drug-addicted son slams Biden's drug consumption centers
 - [https://www.dailymail.co.uk/news/article-11678959/Mother-drug-addicted-son-slams-Bidens-drug-consumption-centers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678959/Mother-drug-addicted-son-slams-Bidens-drug-consumption-centers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:08:45+00:00
 - user: None

Jacqui Berlinn, the co-founder of the organization 'Mothers Against Drugs Deaths', said Biden should spend money on addiction and recovery services for drug addicts - rather than enable them to take more.

## Yorkshire man becomes first British white man to star Bollywood film
 - [https://www.dailymail.co.uk/femail/article-11679065/Yorkshire-man-British-white-man-star-Bollywood-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11679065/Yorkshire-man-British-white-man-star-Bollywood-film.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 12:01:06+00:00
 - user: None

Richard Lovatt, from Huddersfield, has become the first British white man to land a starring role in a Bollywood blockbuster. He has taken 50 lessons to learn Hindi and will fly to Mumbai to shoot the film.

## Flock of 50 sheep appear to be queuing for the bus in town where they have right to graze freely
 - [https://www.dailymail.co.uk/news/article-11679271/Flock-50-sheep-appear-queuing-bus-town-right-graze-freely.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679271/Flock-50-sheep-appear-queuing-bus-town-right-graze-freely.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:57:47+00:00
 - user: None

Alan Day, 63, from Lydney, Gloucestershire, captured an amazing moment where 50 sheep appear to be queuing for the bus. An ancient tradition in the town allows them to graze freely.

## Russia Ukraine news: Putin unleashes furious response to US and Germany tank deal
 - [https://www.dailymail.co.uk/news/article-11678539/Russia-Ukraine-news-Putin-unleashes-furious-response-Germany-tank-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678539/Russia-Ukraine-news-Putin-unleashes-furious-response-Germany-tank-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:27:18+00:00
 - user: None

An air raid alert was issued over the whole of Ukraine early this morning as defence units shot down a stream of incoming missiles, while fighting also flared up in Bakhmut following the tank deal.

## Horrors of the Blitz recreated at Chatham Dockyard for World War II epic directed by Steve McQueen
 - [https://www.dailymail.co.uk/news/article-11679021/Horrors-Blitz-recreated-Chatham-Dockyard-World-War-II-epic-directed-Steve-McQueen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679021/Horrors-Blitz-recreated-Chatham-Dockyard-World-War-II-epic-directed-Steve-McQueen.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:27:08+00:00
 - user: None

Kent's  skies were lit up with explosions and searchlights last night as the Blitz was recreated for a new film.

## Man arrested for Spanish machete rampage killing one was supposed to have already been deported
 - [https://www.dailymail.co.uk/news/article-11679045/Man-arrested-Spanish-machete-rampage-killing-one-supposed-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679045/Man-arrested-Spanish-machete-rampage-killing-one-supposed-deported.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:27:05+00:00
 - user: None

Spanish media reported that the man who killed one and injured another with a machete in an attack on Spanish churches yesterday was illegally in the country.

## Afghan asylum-seeking murderer terrified vulnerable teenage girl who reveal: 'He made my skin crawl'
 - [https://www.dailymail.co.uk/news/article-11679097/Afghan-asylum-seeking-murderer-terrified-vulnerable-teenage-girl-reveal-skin-crawl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679097/Afghan-asylum-seeking-murderer-terrified-vulnerable-teenage-girl-reveal-skin-crawl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:24:21+00:00
 - user: None

Asylum seeking triple murderer Lawangeen Abdulrahimzai - who was 20 when he conned the immigration authorities into believing he was just 14 - went on to terrify vulnerable teenage girls.

## Poundland to open and relocate 50 new stores, including Scotland's biggest in Glasgow
 - [https://www.dailymail.co.uk/news/article-11679063/Poundland-open-relocate-50-new-stores-including-Scotlands-biggest-Glasgow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679063/Poundland-open-relocate-50-new-stores-including-Scotlands-biggest-Glasgow.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:22:09+00:00
 - user: None

The expansion plans will see the budget retailer, owned by Pepco, open half a million square feet of new retail space between now and September.

## Andrew Tate claims woman who accused him of rape lied after he refused to buy her a house
 - [https://www.dailymail.co.uk/news/article-11678699/Andrew-Tate-claims-woman-accused-rape-lied-refused-buy-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678699/Andrew-Tate-claims-woman-accused-rape-lied-refused-buy-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:21:39+00:00
 - user: None

Influencer and kickboxer Andrew Tate told the Bucharest Court of Appeal in Romania that the woman accusing him of rape fabricated a story after he refused to give her €200,000 to buy a house

## Neighbour, 24, who stabbed 76-year-old woman to death at her £1m Notting Hill home is sectioned
 - [https://www.dailymail.co.uk/news/article-11679125/Neighbour-24-stabbed-76-year-old-woman-death-1m-Notting-Hill-home-sectioned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679125/Neighbour-24-stabbed-76-year-old-woman-death-1m-Notting-Hill-home-sectioned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:20:34+00:00
 - user: None

A psychotic schizophrenic who brutally murdered an elderly woman in her £1m Notting Hill home as he thought he was God has avoided jail and instead been committed to hospital.

## Controversy as Novak Djokovic's dad is seen posing with Russian flag featuring Vladimir Putin's face
 - [https://www.dailymail.co.uk/sport/tennis/article-11677781/Controversy-Novak-Djokovics-dad-seen-posing-Russian-flag-featuring-Vladimir-Putins-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/tennis/article-11677781/Controversy-Novak-Djokovics-dad-seen-posing-Russian-flag-featuring-Vladimir-Putins-face.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:16:53+00:00
 - user: None

Novak Djokovic was facing more controversy today after his outspoken father Srdjan was filmed posing with a Russian flag that has Vladimir Putin's face emblazoned on it.

## How bad is my GP? The definitive guide to UK's NHS practices
 - [https://www.dailymail.co.uk/health/article-11674249/How-bad-GP-definitive-guide-UKs-NHS-practices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/health/article-11674249/How-bad-GP-definitive-guide-UKs-NHS-practices.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:08:57+00:00
 - user: None

You can use MailOnline's GP data base tool to uncover all the info the NHS holds on your local surgery, from how many patients are registered to how often doctors see patients in person.

## Meet Britain's 'Greta Thunberg of sport' who won't fly to contests
 - [https://www.dailymail.co.uk/news/article-11678849/Meet-Britains-Greta-Thunberg-sport-wont-fly-contests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678849/Meet-Britains-Greta-Thunberg-sport-wont-fly-contests.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:06:09+00:00
 - user: None

Innes FitzGerald, dubbed the 'Greta Thunberg of sport', wrote to British Athletics to tell them she would not fly to the World Cross Country Championships in Australia.

## Parents slam secondary school for arranging week-long PE trip to Abu Dhabi costing £2,500 per pupil
 - [https://www.dailymail.co.uk/news/article-11678905/Parents-slam-secondary-school-arranging-week-long-PE-trip-Abu-Dhabi-costing-2-500-pupil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678905/Parents-slam-secondary-school-arranging-week-long-PE-trip-Abu-Dhabi-costing-2-500-pupil.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:05:22+00:00
 - user: None

Ysgol Gyfun Gŵyr (Gŵyr secondary school) in Swansea told parents pupils between the ages of 14 and 16 were being offered the chance to visit the United Arab Emirates in October 2024.

## Olympic gymnastics star Ellie Downie dropped from British team for speaking out over abuse
 - [https://www.dailymail.co.uk/news/article-11678743/Olympic-gymnastics-Ellie-Downie-quit-aged-23-dropped-British-team-speaking-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678743/Olympic-gymnastics-Ellie-Downie-quit-aged-23-dropped-British-team-speaking-out.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 11:04:58+00:00
 - user: None

Ellie Downie announced her retirement from the sport earlier this week with a statement. The gymnast said that the 'difficult decision' was not taken lightly.

## Paul Mescal's sister Nell, 19, is revealed as a rising music star
 - [https://www.dailymail.co.uk/femail/article-11675661/Paul-Mescals-sister-Nell-19-revealed-rising-music-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/femail/article-11675661/Paul-Mescals-sister-Nell-19-revealed-rising-music-star.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:58:22+00:00
 - user: None

Paul Mescal, 26, isn't the only talented family member. His 19-year-ol singer-songwriter sister Nell Mescal is shooting to fame and has just released her second single, Homesick.

## Ukraine now faces logistical nightmare of getting tanks delivered and training crews
 - [https://www.dailymail.co.uk/news/article-11678829/Ukraine-faces-logistical-nightmare-getting-tanks-delivered-training-crews.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678829/Ukraine-faces-logistical-nightmare-getting-tanks-delivered-training-crews.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:58:12+00:00
 - user: None

Some tanks promised by the US are not even in their stocks at the moment, while German defence minister Boris Pistorius said Leopard 2 tanks would not be ready until the end of March/

## Mugshot of K-9 Officer Ice goes viral after cops investigated him for stealing his colleague's lunch
 - [https://www.dailymail.co.uk/news/article-11678777/Mugshot-K-9-Officer-Ice-goes-viral-cops-investigated-stealing-colleagues-lunch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678777/Mugshot-K-9-Officer-Ice-goes-viral-cops-investigated-stealing-colleagues-lunch.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:50:31+00:00
 - user: None

This month, the Wyandotte Police Department (WPD) in Michigan shared the image of the dog with a post about about the alleged crime.

## Russian conscript jumps to his death after he was ordered to return to warzone
 - [https://www.dailymail.co.uk/news/article-11678995/Russian-conscript-jumps-death-ordered-return-warzone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678995/Russian-conscript-jumps-death-ordered-return-warzone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:46:49+00:00
 - user: None

His mother - a cleaner in the Russian Foreign Ministry - saw tragic Mikhail Lyubimov jump from a window in their tenth-floor flat in the Moscow district Tsaritsyno, reports said.

## Team GB Olympic runners join revolt over plans that could mean competing against transgender women
 - [https://www.dailymail.co.uk/news/article-11678871/Team-GB-Olympic-runners-join-revolt-plans-mean-competing-against-transgender-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678871/Team-GB-Olympic-runners-join-revolt-plans-mean-competing-against-transgender-women.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:46:01+00:00
 - user: None

Team GB stars Beth Dobbin and Emily Diamond and Ellie Baker have now all said woman should not be expected to compete against transwomen due to biological advantages.

## Dominic Raab facing bullying claims 'from at least 24 civil servants'
 - [https://www.dailymail.co.uk/news/article-11679023/Dominic-Raab-facing-bullying-claims-24-civil-servants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679023/Dominic-Raab-facing-bullying-claims-24-civil-servants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:44:06+00:00
 - user: None

A top barrister is currently undertaking an investigation into the Deputy Prime Minister amid a slew of allegations about his conduct towards officials.

## East Londoner makes £7K renting out his parking spaces and uses it for holidays in Spain and Italy
 - [https://www.dailymail.co.uk/news/article-11678809/East-Londoner-makes-7K-renting-parking-spaces-uses-holidays-Spain-Italy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678809/East-Londoner-makes-7K-renting-parking-spaces-uses-holidays-Spain-Italy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:41:46+00:00
 - user: None

Alessandro Rossi, 35, has been renting his two spare spaces in Dalston, east London for six years and has earnt £7K from it. The easy gig pays for his trips to Italy and Spain each year.

## Daly River crocodile attack sees man rushed to hospital for emergency surgery
 - [https://www.dailymail.co.uk/news/article-11678639/Daly-River-crocodile-attack-sees-man-rushed-hospital-emergency-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678639/Daly-River-crocodile-attack-sees-man-rushed-hospital-emergency-surgery.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:24:29+00:00
 - user: None

A crocodile egg collector has been rushed to hospital after being bitten by one of the animals at a remote Northern Territory river.

## Network Rail 'will be prosecuted' over Stonehaven rail disaster which killed three
 - [https://www.dailymail.co.uk/news/article-11678695/Network-Rail-prosecuted-Stonehaven-rail-disaster-killed-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678695/Network-Rail-prosecuted-Stonehaven-rail-disaster-killed-three.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:22:51+00:00
 - user: None

Rail chiefs are set to face charges over health and safety shortcomings that led to the fatal ScotRail train derailment at Carmont, Aberdeenshire, in 2020.

## NatWest bank closures: 23 branches are closing in fresh blow for the high street
 - [https://www.dailymail.co.uk/news/article-11678937/NatWest-reveals-23-branches-closing-fresh-blow-high-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678937/NatWest-reveals-23-branches-closing-fresh-blow-high-street.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:22:45+00:00
 - user: None

NatWest is to shut 23 more bank branches this year in another blow for the high street.

## Man, 61, is charged with common assault after Matt Hancock was 'pushed' on Tube
 - [https://www.dailymail.co.uk/news/article-11679015/Man-61-charged-common-assault-Matt-Hancock-pushed-Tube.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11679015/Man-61-charged-common-assault-Matt-Hancock-pushed-Tube.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:21:55+00:00
 - user: None

Geza Tarjanyi, from Leyland, Lancashire, will appear in court next month charged with common assault and two public order offences, British Transport Police said.

## Newcastle United star Joelinton, 26, arrives at court to face drink-driving charge
 - [https://www.dailymail.co.uk/news/article-11678967/Newcastle-United-star-Joelinton-26-arrives-court-face-drink-driving-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678967/Newcastle-United-star-Joelinton-26-arrives-court-face-drink-driving-charge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:20:52+00:00
 - user: None

Newcastle United footballer Joelinton, 26,  has arrived at Newcastle Magistrates Court this morning to face a drink-driving charge after being pulled over by police on January 12

## Labour MP: Trans rapist Isla Bryson 'should get support to transition'
 - [https://www.dailymail.co.uk/news/article-11678631/Labour-MP-Trans-rapist-Isla-Bryson-support-transition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678631/Labour-MP-Trans-rapist-Isla-Bryson-support-transition.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:18:44+00:00
 - user: None

Paulette Hamilton, who represents Erdington, has said that Bryson must have the same support as the female prisoners experts believe the sex attacker poses a danger to at Cornton Vale prison.

## 'One in ten police officers shouldn't have made it through vetting'
 - [https://www.dailymail.co.uk/news/article-11678645/One-ten-police-officers-shouldnt-vetting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678645/One-ten-police-officers-shouldnt-vetting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:16:32+00:00
 - user: None

Inspector of Constabulary Matt Parr analysed how UK police forces were screening applicants in November after a string of stories about sexual offenders in the ranks.

## Midwife charged with strangling her children to death had struggled with post partum anxiety
 - [https://www.dailymail.co.uk/news/article-11678675/Midwife-charged-strangling-children-death-struggled-post-partum-anxiety.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678675/Midwife-charged-strangling-children-death-struggled-post-partum-anxiety.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:16:01+00:00
 - user: None

Lindsay Clancy, 32, allegedly strangled her daughter Cora, five, and son Dawson, three, to death and tried to suffocate her baby son inside the family home in Duxbury, Massachusetts.

## Girl, five, dies on the drive home from swimming lessons after choking on a deli frankfurt
 - [https://www.dailymail.co.uk/news/article-11678093/Girl-five-dies-drive-home-swimming-lessons-choking-deli-frankfurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678093/Girl-five-dies-drive-home-swimming-lessons-choking-deli-frankfurt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:11:12+00:00
 - user: None

Imogen Lennon, five, was on the way home from swimming lessons on January 16 when she suddenly started choking on one of her 'favourite treats' in the back of the car.

## Dancer who was crushed by a mechanical tree in bizarre accident on film set is suing for £300,000
 - [https://www.dailymail.co.uk/news/article-11678847/Dancer-crushed-mechanical-tree-bizarre-accident-film-set-suing-300-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678847/Dancer-crushed-mechanical-tree-bizarre-accident-film-set-suing-300-000.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 10:08:19+00:00
 - user: None

Keira Johnson suffered serious back injures after a tree mounted on a mechanical stump fell on her whilst filming an advert on location in Poland in September last year.

## Putin unleashes furious response to West's decision to send Kyiv tanks as missiles rain hit Ukraine
 - [https://www.dailymail.co.uk/news/article-11678539/Putin-unleashes-furious-response-Wests-decision-send-Kyiv-tanks-missiles-rain-hit-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678539/Putin-unleashes-furious-response-Wests-decision-send-Kyiv-tanks-missiles-rain-hit-Ukraine.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 09:18:23+00:00
 - user: None

An air raid alert was issued over the whole of Ukraine early this morning as defence units shot down a stream of incoming missiles, while fighting also flared up in Bakhmut after the deal.

## Ministers considering creating a 'pumpwatch' fuel watchdog to stop retailers ripping off drivers
 - [https://www.dailymail.co.uk/news/article-11678753/Ministers-considering-creating-pumpwatch-fuel-watchdog-stop-retailers-ripping-drivers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678753/Ministers-considering-creating-pumpwatch-fuel-watchdog-stop-retailers-ripping-drivers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 09:04:13+00:00
 - user: None

Chancellor Jeremy Hunt and Business Secretary Grant Shapps are said to be looking at a system to make petrol and diesel retailers pass on cuts in wholesale costs to consumers.

## Ex-governor of Scottish women's prison 'would have quit' over Isla Bryson
 - [https://www.dailymail.co.uk/news/article-11678509/Ex-governor-Scottish-womens-prison-quit-Isla-Bryson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678509/Ex-governor-Scottish-womens-prison-quit-Isla-Bryson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:59:56+00:00
 - user: None

Rhona Hotchkiss believes it is 'appalling' that the 31-year-old was sent to Cornton Vale jail after being convicted of raping two women while a man, Adam Graham.

## Mother ordered to wear tag after she drove young children home three times over the alcohol limit
 - [https://www.dailymail.co.uk/news/article-11678701/Mother-ordered-wear-tag-drove-young-children-home-three-times-alcohol-limit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678701/Mother-ordered-wear-tag-drove-young-children-home-three-times-alcohol-limit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:58:18+00:00
 - user: None

Rhian Hughes, 41, failed a breath and blood test after she consumed two glasses of cider during the day just hours after she enjoyed a Prosecco binge with her friends the night before.

## Watch as thugs use an angle grinder to steal a commuter's bike outside a busy rail station
 - [https://www.dailymail.co.uk/news/article-11678505/Watch-thugs-use-angle-grinder-steal-commuters-bike-outside-busy-rail-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678505/Watch-thugs-use-angle-grinder-steal-commuters-bike-outside-busy-rail-station.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:45:43+00:00
 - user: None

This is the moment brazen thieves used an angle grinder to steal a commuter bicycle outside Borough Green and Wrotham Station, Kent, in broad daylight.

## Pictured: British mother, 42, among eight Brits charged over 'fake food-poisoning scam
 - [https://www.dailymail.co.uk/news/article-11678607/Pictured-British-mother-42-eight-Brits-charged-fake-food-poisoning-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678607/Pictured-British-mother-42-eight-Brits-charged-fake-food-poisoning-scam.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:25:48+00:00
 - user: None

The two alleged criminal ringleaders, Laura Holmes Cameron (pictured) and her brother Marc Cameron Grimstead, were accused of targeting all-inclusive hotels in Majorca with the bogus claims.

## Cop Michelle 'Mully' Mullen dies in freak indoor skydiving accident in Brisbane
 - [https://www.dailymail.co.uk/news/article-11678465/Cop-Michelle-Mully-Mullen-dies-freak-indoor-skydiving-accident-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678465/Cop-Michelle-Mully-Mullen-dies-freak-indoor-skydiving-accident-Brisbane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:24:28+00:00
 - user: None

A senior police officer has died six days after suffering head and spinal injuries in an indoor skydiving accident in Chermside in Brisbane's north.

## City workers told to stop WFH on Mondays and Fridays
 - [https://www.dailymail.co.uk/news/article-11678513/City-workers-told-stop-WFH-Mondays-Fridays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678513/City-workers-told-stop-WFH-Mondays-Fridays.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:23:35+00:00
 - user: None

The capital has seen a rise in 'TWaTs' - workers who go into the office on Tuesdays, Wednesdays and Thursdays, and spend the rest of the week at home.

## Chequers mate? Rishi Sunak's is 'livid' with Nadhim Zahawi over tax affairs row
 - [https://www.dailymail.co.uk/news/article-11678577/Chequers-mate-Rishi-Sunaks-livid-Nadhim-Zahawi-tax-affairs-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678577/Chequers-mate-Rishi-Sunaks-livid-Nadhim-Zahawi-tax-affairs-row.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:17:15+00:00
 - user: None

Multi-millionaire Mr Zahawi is facing calls to quit after it was revealed he paid £5million to settle a tax bill with HM Revenue and Customs while he was chancellor last year.

## Boy, 10, struck by lightning at Warrilla Beach at Barrack Point near Shellharbour: Australia Day
 - [https://www.dailymail.co.uk/news/article-11678597/Boy-10-struck-lightning-Warrilla-Beach-Barrack-Point-near-Shellharbour-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678597/Boy-10-struck-lightning-Warrilla-Beach-Barrack-Point-near-Shellharbour-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:16:54+00:00
 - user: None

The 10-year-old was swimming on Australia Day at Warrilla Beach at Barrack Point, near Shellharbour in NSW, when he was hit by the thunderbolt.

## Undercover footage reveals Pfizer is exploring manipulating COVID to make it 'more potent'
 - [https://www.dailymail.co.uk/news/article-11678281/Undercover-footage-reveals-Pfizer-exploring-manipulating-COVID-make-potent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678281/Undercover-footage-reveals-Pfizer-exploring-manipulating-COVID-make-potent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 08:14:23+00:00
 - user: None

Project Veritas released a new video that shows alleged Pfizer executive Jordon Trishton Walker revealing that the company is exploring a way to mutate COVID in order to create more vaccines.

## Australia Day: Hikers defy Indigenous ban on climbing Mount Warning by making early morning ascent
 - [https://www.dailymail.co.uk/news/article-11678283/Australia-Day-Hikers-defy-Indigenous-ban-climbing-Mount-Warning-making-early-morning-ascent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678283/Australia-Day-Hikers-defy-Indigenous-ban-climbing-Mount-Warning-making-early-morning-ascent.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:24:43+00:00
 - user: None

Protesters have climbed to the top of the 'stunningly beautiful' Mount Warning in northern New South Wales, defying a ban imposed out of respect to Aboriginal custodians.

## Factory worker 'paid hitman £20,000 to murder her married lover when he dumped her after fling'
 - [https://www.dailymail.co.uk/news/article-11678403/Factory-worker-paid-hitman-20-000-murder-married-lover-dumped-fling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678403/Factory-worker-paid-hitman-20-000-murder-married-lover-dumped-fling.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:23:59+00:00
 - user: None

Helen Hewlett (pictured), 43, allegedly stalked Paul Belton, 50, for more than two years before making false claims of sexual harassment and eventually turning to the dark web to hire a killer.

## Michael Bublé reveals son's 'unthinkable' battle with liver cancer forced him to lose 'alter-ego'
 - [https://www.dailymail.co.uk/tvshowbiz/article-11675713/Michael-Bubl-reveals-son-Noahs-unthinkable-battle-liver-cancer-forced-lose-alter-ego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/tvshowbiz/article-11675713/Michael-Bubl-reveals-son-Noahs-unthinkable-battle-liver-cancer-forced-lose-alter-ego.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:23:33+00:00
 - user: None

The singer, 47, admitted he felt like the 'the superhero I always wanted to be' before being 'changed' by nine-year-old Noah's diagnosis at the age of three in 2016.

## TikToker compiles massive list of reasons to not have children, creates honest dialogue on pregnancy
 - [https://www.dailymail.co.uk/news/article-11678029/TikToker-compiles-massive-list-reasons-not-children-creates-honest-dialogue-pregnancy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678029/TikToker-compiles-massive-list-reasons-not-children-creates-honest-dialogue-pregnancy.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:22:50+00:00
 - user: None

One TikToker who started compiling a massive list of pros and cons about pregnancy and parenting has sparked a massive conversation about the struggles of the full-time, nonstop job.

## British mountaineer, 32, has leg amputated after falling on Argentina's Mount Aconcagua
 - [https://www.dailymail.co.uk/news/article-11678475/British-mountaineer-32-leg-amputated-falling-Argentinas-Mount-Aconcagua.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678475/British-mountaineer-32-leg-amputated-falling-Argentinas-Mount-Aconcagua.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:16:10+00:00
 - user: None

The 32-year-old also suffered a fractured skull in the accident on 22,837ft Mount Aconcagua (pictured), the highest outside Asia.

## How Putin 'won' the Battle of Soledar
 - [https://www.dailymail.co.uk/news/article-11676075/How-Putin-won-Battle-Soledar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11676075/How-Putin-won-Battle-Soledar.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:12:11+00:00
 - user: None

Chris Pleasance's video guide explains how tens of thousands of soldiers died after being used as canon fodder in pointless human wave attacks or were slaughtered by artillery.

## North Carolina police officer saved after body camera stops bullet shot at her
 - [https://www.dailymail.co.uk/news/article-11678317/North-Carolina-police-officer-saved-body-camera-stops-bullet-shot-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678317/North-Carolina-police-officer-saved-body-camera-stops-bullet-shot-her.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:09:15+00:00
 - user: None

A North Carolina police officer was saved by her own body camera after she was shot at during an attempt to serve a 60-year-old woman with an involuntary commitment order.

## Ukraine's arsenal of democracy: The US military hardware sent to help defeat Putin
 - [https://www.dailymail.co.uk/news/article-11676639/Ukraines-arsenal-democracy-military-hardware-sent-help-defeat-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11676639/Ukraines-arsenal-democracy-military-hardware-sent-help-defeat-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:04:01+00:00
 - user: None

The US promise of 31 Abrams tanks for Ukraine adds to nearly $30 billion in military assistance since Russia's invasion. DailyMail.com provides a breakdown of some of the key military aid.

## Premium Bonds may now be the best place for rainy day savings
 - [https://www.dailymail.co.uk/money/saving/article-11677403/Premium-Bonds-best-place-rainy-day-savings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/money/saving/article-11677403/Premium-Bonds-best-place-rainy-day-savings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

The prize fund rate challenges top savings deals but there are two questions you need to ask: Are Premium Bonds easy access and how likely am I to get that rate of return?

## How the 'Cookers', conspiracy theorists, and Sovereign Citizens are marking Australia Day
 - [https://www.dailymail.co.uk/news/article-11678155/How-Cookers-conspiracy-theorists-Sovereign-Citizens-marking-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678155/How-Cookers-conspiracy-theorists-Sovereign-Citizens-marking-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 06:36:44+00:00
 - user: None

They may not believe in the Australian Government, but conspiracy theorists and  'Sovereign Citizen' protestors have flooded social media with videos on Australia Day.

## Alex Murdaugh sobs in front of surviving son who is on the witness list to testify against him
 - [https://www.dailymail.co.uk/news/article-11678169/Alex-Murdaugh-sobs-surviving-son-witness-list-testify-against-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678169/Alex-Murdaugh-sobs-surviving-son-witness-list-testify-against-him.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 06:23:57+00:00
 - user: None

Alex Murdaugh's lone surviving son Buster - who is on the witness list to potentially testify against his father - witnessed father Alex sobbing during the opening statements Wednesday

## Australia Day celebrations omitting the national flag as dissent grows against the holiday
 - [https://www.dailymail.co.uk/news/article-11678129/Australia-Day-celebrations-omitting-national-flag-dissent-grows-against-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678129/Australia-Day-celebrations-omitting-national-flag-dissent-grows-against-holiday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 06:10:56+00:00
 - user: None

The Australian flag has been slowly disappearing from Australia Day celebrations nationwide as opinion on the January 26 public holiday becomes increasingly divisive.

## Portrait of Alex Murdaugh's late grandfather is removed from courthouse as trial begins
 - [https://www.dailymail.co.uk/news/article-11678125/Portrait-Alex-Murdaughs-late-grandfather-removed-courthouse-trial-begins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678125/Portrait-Alex-Murdaughs-late-grandfather-removed-courthouse-trial-begins.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 06:02:48+00:00
 - user: None

Judge Clifton Newman ordered the portrait of late 14th Circuit Solicitor Randolph 'Buster' Murdaugh Jr be removed as opening arguments began in his grandson's trial in Walterboro.

## Leah Croucher mystery deepens: Police make fresh appeal for witnesses who saw sole suspect
 - [https://www.dailymail.co.uk/news/article-11676241/Leah-Croucher-mystery-deepens-Police-make-fresh-appeal-witnesses-saw-sole-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11676241/Leah-Croucher-mystery-deepens-Police-make-fresh-appeal-witnesses-saw-sole-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 06:01:15+00:00
 - user: None

Police have released a computer-generated image of what Neil Maxwell may have looked like when Leah Croucher, 19, disappeared in February 2019.

## Australia Day 2023: TikTok influencer Fidan Shevket targeted by Invasion Day trolls
 - [https://www.dailymail.co.uk/news/article-11678123/Australia-Day-2023-TikTok-influencer-Fidan-Shevket-targeted-Invasion-Day-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678123/Australia-Day-2023-TikTok-influencer-Fidan-Shevket-targeted-Invasion-Day-trolls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 05:56:18+00:00
 - user: None

Fidan Shevket - who posts as Fidan_tok - recorded a paid restaurant review  on the social media platform and revealed its free prawn cocktail deal for Australia Day, triggering a furious backlash.

## 'I trusted her': Mom of Idaho victim slams lawyer for abandoning her to represent accused KILLER
 - [https://www.dailymail.co.uk/news/article-11677897/I-trusted-Mom-Idaho-victim-slams-lawyer-abandoning-represent-accused-KILLER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677897/I-trusted-Mom-Idaho-victim-slams-lawyer-abandoning-represent-accused-KILLER.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 05:52:58+00:00
 - user: None

Cara Northington's daughter Xana Kernodle, 20, was murdered with three friends in their student house in Moscow, Idaho. Northington's lawyer is now representing the accused killer.

## Australia Day 1970 in Newcastle NSW shows white men painted head to toe with black body paint
 - [https://www.dailymail.co.uk/news/article-11677617/Australia-Day-1970-Newcastle-NSW-shows-white-men-painted-head-toe-black-body-paint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677617/Australia-Day-1970-Newcastle-NSW-shows-white-men-painted-head-toe-black-body-paint.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 05:25:20+00:00
 - user: None

A video of young men and boys laughing and joking as they stalk onlookers while wearing blackface on Australia Day in 1970 has provided a brutal contrast to sombre Invasion Day celebrations in 2023.

## 'Distressed' Hamline University faculty calls on head of the school to RESIGN after firing professor
 - [https://www.dailymail.co.uk/news/article-11677953/Distressed-Hamline-University-faculty-calls-head-school-RESIGN-firing-professor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677953/Distressed-Hamline-University-faculty-calls-head-school-RESIGN-firing-professor.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 05:21:54+00:00
 - user: None

Faculty leaders at Hamline University said 71 of 92 members who attended a meeting Tuesday voted to call on President Fayneese Miller to resign immediately.

## Kari Lake dismisses Senate speculation as she says she plans to fight on to win lawsuit
 - [https://www.dailymail.co.uk/news/article-11678127/Kari-Lake-dismisses-Senate-speculation-says-plans-fight-win-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678127/Kari-Lake-dismisses-Senate-speculation-says-plans-fight-win-lawsuit.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 05:01:29+00:00
 - user: None

Kari Lake on Wednesday played down speculation that she is angling for a Senate run, insisting she was only interested in fighting on with her election lawsuit.

## Melbourne's Merri-bek City Council, Moreland, takes day off for Australia Day
 - [https://www.dailymail.co.uk/news/article-11677909/Melbournes-Merri-bek-City-Council-Moreland-takes-day-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677909/Melbournes-Merri-bek-City-Council-Moreland-takes-day-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 04:56:01+00:00
 - user: None

Independent councillor Oscar Yildiz has blasted Merri-bek City Council, formerly Moreland, for taking the day off for Australia Day despite leading calls to change the date of the holiday.

## Australia Day 2023: Invasion Day protester in tears at Melbourne demonstration
 - [https://www.dailymail.co.uk/news/article-11678043/Australia-Day-2023-Invasion-Day-protester-tears-Melbourne-demonstration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678043/Australia-Day-2023-Invasion-Day-protester-tears-Melbourne-demonstration.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 04:44:03+00:00
 - user: None

The intensity of Invasion Day marches proved too much for one protester - holding a sign saying 'No pride in genocide' - who burst into tears and had to be consoled as Lidia Thorpe declared war.

## Australia Day: Channel 10's Jessica Rowe said kids want to change Australia Day date from January 26
 - [https://www.dailymail.co.uk/news/article-11677991/Channel-10-star-says-Australias-kids-dont-want-to.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677991/Channel-10-star-says-Australias-kids-dont-want-to.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 04:24:14+00:00
 - user: None

Famous Australian journalist Jessica Rowe said it's 'well and truly' time to change the date of Australia - noting even her kids don't want to celebrate the holiday anymore.

## Australia Day storm slams into Sydney
 - [https://www.dailymail.co.uk/news/article-11678133/Australia-Day-storm-slams-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11678133/Australia-Day-storm-slams-Sydney.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 04:23:36+00:00
 - user: None

A 'nasty' forecast storm is rolling in from Sydney's west and is set to batter the city about 3.30pm - after the mercury hit 33 degrees and much of the country's east coast sweltered.

## Teacher admits helping students change their gender identity without their parents' knowledge
 - [https://www.dailymail.co.uk/news/article-11677513/Teacher-admits-helping-students-change-gender-identity-without-parents-knowledge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677513/Teacher-admits-helping-students-change-gender-identity-without-parents-knowledge.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 04:13:22+00:00
 - user: None

Olivia Garrison, a high school teacher in California who is nonbinary, has admitted to helping their students change their gender identity without their parents' knowledge.

## Lidia Thorpe screams 'this is WAR' at Australia Day protest
 - [https://www.dailymail.co.uk/news/article-11677473/Australia-Day-January-26-Division-Day-thousands-flood-cities-rallying-day-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677473/Australia-Day-January-26-Division-Day-thousands-flood-cities-rallying-day-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 03:23:53+00:00
 - user: None

Thousands of protesters have gathered in Belmore Park in Sydney's CBD to rally against Australia Day, demanding  the national holiday be changed to a day of mourning.

## Seaplane crashes off Queensland island as emergency responders rush to the scene
 - [https://www.dailymail.co.uk/news/article-11677923/Seaplane-crashes-Queensland-island-emergency-responders-rush-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677923/Seaplane-crashes-Queensland-island-emergency-responders-rush-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 03:17:27+00:00
 - user: None

The incident occurred at the Jumpinpin Channel on North Stradbroke Island in Queensland, which separates the island from South Stradbroke Island. There are no reports of injuries or fatalities so far.

## Julia Louis-Dreyfus speaks out on son Charlie Hall's racy scenes in The Sex Lives of College Girls
 - [https://www.dailymail.co.uk/news/article-11677625/Julia-Louis-Dreyfus-speaks-son-Charlie-Halls-racy-scenes-Sex-Lives-College-Girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677625/Julia-Louis-Dreyfus-speaks-son-Charlie-Halls-racy-scenes-Sex-Lives-College-Girls.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 03:12:11+00:00
 - user: None

Actor Julia Louis-Dreyfus is not letting a few racy scenes get in the way of supporting her son in his role on HBO Max's 'The Sex Lives of College Girls.'

## US Marine denies abducting Afghan war orphan at center of custody battle
 - [https://www.dailymail.co.uk/news/article-11677741/US-Marine-denies-abducting-Afghan-war-orphan-center-custody-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677741/US-Marine-denies-abducting-Afghan-war-orphan-center-custody-battle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 03:01:02+00:00
 - user: None

Marine Major Joshua Mast and his wife Stephanie currently have custody of the girl, identified as 'Baby L', who survived a Special Operations raid that killed her parents and five siblings in 2019.

## ABC Covid guru Norman Swan awarded membership to Order of Australia on Australia Day
 - [https://www.dailymail.co.uk/news/article-11677347/ABC-Covid-guru-Norman-Swan-awarded-membership-Order-Australia-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677347/ABC-Covid-guru-Norman-Swan-awarded-membership-Order-Australia-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:38:26+00:00
 - user: None

ABC's health guru Norman Swan was made a member of the Order of Australia on Australia Day in recognition of his Covid reporting but not everyone agrees with the honour..

## White House defends Omar, Schiff and Swalwell as Kevin McCarthy tries to kick them off committees
 - [https://www.dailymail.co.uk/news/article-11677683/White-House-defends-Omar-Schiff-Swalwell-Kevin-McCarthy-tries-kick-committees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677683/White-House-defends-Omar-Schiff-Swalwell-Kevin-McCarthy-tries-kick-committees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:32:48+00:00
 - user: None

White House Press Secretary Karine Jean-Pierre said on Wednesday that all three lawmakers 'bring a lot to the table when it comes to foreign policy and national security.'

## Two Penrith teenagers and a man charged for Michael Kerr's murder in Nowra
 - [https://www.dailymail.co.uk/news/article-11677639/Two-Penrith-teenagers-man-charged-Michael-Kerrs-murder-Nowra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677639/Two-Penrith-teenagers-man-charged-Michael-Kerrs-murder-Nowra.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:30:18+00:00
 - user: None

Two teenage boys and a man have been charged with murdering 51-year-old Michael Kerr on the NSW South Coast on January 4, 2022, in what police say was a robbery gone wrong.

## Fears grow that Prince Andrew's sex abuse accuser may overshadow the King's coronation
 - [https://www.dailymail.co.uk/news/article-11677503/Fears-grow-Prince-Andrews-sex-abuse-accuser-overshadow-Kings-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677503/Fears-grow-Prince-Andrews-sex-abuse-accuser-overshadow-Kings-coronation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:24:41+00:00
 - user: None

Publishing insiders claim  Ms Giuffre's memoir could be released just weeks before Charles' coronation, telling the Mirror: 'There will be no bigger occasion for her book than the crowning of the king.'

## EPHRAIM HARDCASTLE: Prince Harry confused over wedding response
 - [https://www.dailymail.co.uk/news/article-11677737/EPHRAIM-HARDCASTLE-Prince-Harry-confused-wedding-response.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677737/EPHRAIM-HARDCASTLE-Prince-Harry-confused-wedding-response.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:23:29+00:00
 - user: None

EPHRAIM HARDCASTLE: Harry's description of his encounter with the late Queen, asking her permission to marry Meghan, displays his bewilderment at her dry sense of humour.

## Mark Horne: Australia's most wanted man is found 'hidden in the hull of a YACHT'
 - [https://www.dailymail.co.uk/news/article-11677717/Mark-Horne-Australias-wanted-man-hidden-hull-YACHT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677717/Mark-Horne-Australias-wanted-man-hidden-hull-YACHT.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:20:56+00:00
 - user: None

Northern Territory Police's Joint Organised Crime Taskforce found Mark Horne, 32, on the boat as it tried to sail from Cullen Bay Marina in Darwin late on Wednesday afternoon.

## Out with the cold, in with the dew? Temperatures finally rise from brutal sub-zero lows
 - [https://www.dailymail.co.uk/news/article-11677831/Out-cold-dew-Temperatures-finally-rise-brutal-sub-zero-lows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677831/Out-cold-dew-Temperatures-finally-rise-brutal-sub-zero-lows.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:15:09+00:00
 - user: None

This week will see a major thaw across most of the UK following the brutal cold which saw temperatures drop to below -10C in places.

## Rishi Sunak and Dominic Raab slam Nicola Sturgeon for not moving trans rapist from women's prison
 - [https://www.dailymail.co.uk/news/article-11677693/Rishi-Sunak-Dominic-Raab-slam-Nicola-Sturgeon-not-moving-trans-rapist-womens-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677693/Rishi-Sunak-Dominic-Raab-slam-Nicola-Sturgeon-not-moving-trans-rapist-womens-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 02:13:27+00:00
 - user: None

Downing Street showed 'concerns' about the Scottish government putting a male-bodied rapist in a women's prison in a move that will place pressure on Sturgeon to reverse the decision.

## Harvard students walk out in dispute over anthropology professor accused of sex abuse
 - [https://www.dailymail.co.uk/news/article-11677587/Harvard-students-walk-dispute-anthropology-professor-accused-sex-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677587/Harvard-students-walk-dispute-anthropology-professor-accused-sex-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:52:48+00:00
 - user: None

Harvard University students publicly staged a walk-out of a class taught by Dr. John Comaroff, who was accused of having forcibly kissed and groped women in a lawsuit from three graduate students.

## Classified documents found at Mike Pence's home included briefing papers for foreign visits
 - [https://www.dailymail.co.uk/news/article-11677723/Classified-documents-Mike-Pences-home-included-briefing-papers-foreign-visits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677723/Classified-documents-Mike-Pences-home-included-briefing-papers-foreign-visits.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:43:07+00:00
 - user: None

Around 12 documents were found at Pence's Carmel, Indiana home on January 16. On Wednesday night CNN reported they were briefings prepared for foreign visits.

## Rishi Sunak backs top civil servant Simon Case despite role in a series of scandals
 - [https://www.dailymail.co.uk/news/article-11677769/Rishi-Sunak-backs-civil-servant-Simon-Case-despite-role-series-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677769/Rishi-Sunak-backs-civil-servant-Simon-Case-despite-role-series-scandals.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:42:33+00:00
 - user: None

The Prime Minister believes he is receiving good advice from Cabinet Secretary Simon Case (pictured) despite questions about his role in a series of scandals, No 10 said yesterday.

## Bosses of hospital branded a 'death trap' face criticism for gender-neutral toilets
 - [https://www.dailymail.co.uk/news/article-11677745/Bosses-hospital-branded-death-trap-face-criticism-gender-neutral-toilets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677745/Bosses-hospital-branded-death-trap-face-criticism-gender-neutral-toilets.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:36:55+00:00
 - user: None

A crumbling hospital described as a 'death trap' came under fire yesterday for spending public money on gender-neutral toilets.

## DAILY MAIL COMMENT: West must hold its nerve to thwart Vladimir Putin
 - [https://www.dailymail.co.uk/news/article-11677719/DAILY-MAIL-COMMENT-West-hold-nerve-thwart-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677719/DAILY-MAIL-COMMENT-West-hold-nerve-thwart-Vladimir-Putin.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:24:18+00:00
 - user: None

DAILY MAIL COMMENT: At long, long last, Western leaders seem to have got the message. This diplomatic breakthrough, after months of dithering and false excuses, may be a major turning point.

## Council will BAN most cars from 75% of its roads in enormous crackdown on traffic and pollution
 - [https://www.dailymail.co.uk/news/article-11677629/Council-BAN-cars-75-roads-enormous-crackdown-traffic-pollution.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677629/Council-BAN-cars-75-roads-enormous-crackdown-traffic-pollution.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:20:52+00:00
 - user: None

A Labour-run council is set to ban most vehicles from 75 per cent of its roads as it expands its network of low-traffic neighbourhoods.

## Australia Day: Mike Carlton slammed for tweet about Australian of the Year Taryn Brumfitt
 - [https://www.dailymail.co.uk/news/article-11677495/Australia-Day-Mike-Carlton-slammed-tweet-Australian-Year-Taryn-Brumfitt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677495/Australia-Day-Mike-Carlton-slammed-tweet-Australian-Year-Taryn-Brumfitt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:16:12+00:00
 - user: None

A tweet by journalist Mike Carlton disagreeing with body image campaigner Taryn Brumfitt being made Australian of the Year has been heavily criticised as 'ignorant' by women.

## January 26 becomes 'Division Day' as thousands flood cities rallying for day of mourning
 - [https://www.dailymail.co.uk/news/article-11677473/January-26-Division-Day-thousands-flood-cities-rallying-day-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677473/January-26-Division-Day-thousands-flood-cities-rallying-day-mourning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:14:11+00:00
 - user: None

Thousands of protesters have gathered in Belmore Park in Sydney's CBD to rally against Australia Day, demanding  the national holiday be changed to a day of mourning.

## We must urgently stop the rich from muzzling our Press through court action, MPs warn
 - [https://www.dailymail.co.uk/news/article-11677701/We-urgently-stop-rich-muzzling-Press-court-action-MPs-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677701/We-urgently-stop-rich-muzzling-Press-court-action-MPs-warn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:12:57+00:00
 - user: None

New laws to prevent wealthy elites from using legal action to silence the media are urgently needed, a Tory former culture secretary has warned.

## Probation officers working from home puts public at risk, watchdog says
 - [https://www.dailymail.co.uk/news/article-11677651/Probation-officers-working-home-puts-public-risk-watchdog-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677651/Probation-officers-working-home-puts-public-risk-watchdog-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:12:24+00:00
 - user: None

The Chief Inspector of Probation, Justin Russell, warned of the implications of working from home policies - and claimed it is 'eroding teamwork' among probation officers.

## Anthony Albanese PM called out by 2GB's Chris O'Keefe over Alice Springs alcohol ban
 - [https://www.dailymail.co.uk/news/article-11676919/Anthony-Albanese-PM-called-2GBs-Chris-OKeefe-Alice-Springs-alcohol-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11676919/Anthony-Albanese-PM-called-2GBs-Chris-OKeefe-Alice-Springs-alcohol-ban.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:11:32+00:00
 - user: None

Anthony Albanese flew in to crime-ridden Alice Springs but shrugged off blame, saying the previous government let alcohol bans expire, sparking a furious backlash from Chris O'Keefe.

## Radio host's blistering attack on Linda Burney's Voice claim: 'disgraceful, an outright lie'
 - [https://www.dailymail.co.uk/news/article-11677003/Radio-hosts-blistering-attack-Linda-Burneys-Voice-claim-disgraceful-outright-lie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677003/Radio-hosts-blistering-attack-Linda-Burneys-Voice-claim-disgraceful-outright-lie.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:09:14+00:00
 - user: None

Indigenous Australians Minister Linda Burney has been called out for her 'outright lie' after making the extraordinary claim  the Voice to Parliament would have prevented Alice Springs' crime wave.

## Artificial intelligence could kill off the human race and make mankind extinct, MPs are warned
 - [https://www.dailymail.co.uk/sciencetech/article-11677653/Artificial-intelligence-kill-human-race-make-mankind-extinct-MPs-warned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sciencetech/article-11677653/Artificial-intelligence-kill-human-race-make-mankind-extinct-MPs-warned.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 01:03:47+00:00
 - user: None

Experts from Oxford University said when AI eventually becomes more intelligent than us it is likely to pose as great a threat as mankind did to the dodo.

## Both Speakers call for crackdown on pressure groups set up by MPs
 - [https://www.dailymail.co.uk/news/article-11677649/Both-Speakers-call-crackdown-pressure-groups-set-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677649/Both-Speakers-call-crackdown-pressure-groups-set-MPs.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:59:51+00:00
 - user: None

Sir Lindsay Hoyle and Lord McFall said the current system has 'not prevented reputational risks to Parliament or the proliferation of APPGs' in a joint letter to Sir Chris Bryant.

## Australia Day citizenship ceremony overshadowed by boy crying as Albanese grants family citizenship
 - [https://www.dailymail.co.uk/news/article-11677409/Australia-Day-citizenship-ceremony-overshadowed-boy-crying-Albanese-grants-family-citizenship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677409/Australia-Day-citizenship-ceremony-overshadowed-boy-crying-Albanese-grants-family-citizenship.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:58:56+00:00
 - user: None

Mr Albanese was halfway through granting the Seedhom family Australian citizenship at the annual ceremony in Canberra when the boy started crying.

## The View co-hosts are all left red-faced after a FART noise is heard during the show
 - [https://www.dailymail.co.uk/news/article-11677277/The-View-hosts-left-red-faced-FART-noise-heard-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677277/The-View-hosts-left-red-faced-FART-noise-heard-show.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:55:41+00:00
 - user: None

It was an even more chaotic show Wednesday on 'The View' after viewers heard a large fart noise during the live broadcast as the group of co-hosts worked to clean up a mysterious liquid.

## Woman, 29, is charged with posing as a high school student and attending classes
 - [https://www.dailymail.co.uk/news/article-11677437/Woman-29-charged-posing-high-school-student-attending-classes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677437/Woman-29-charged-posing-high-school-student-attending-classes.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:28:31+00:00
 - user: None

Hyejeong Shin, 29, was arrested last week after attending classes at New Brunswick High School for four days before her true age was discovered, district officials said on Tuesday.

## Interfering in loved ones' big decisions could 'violate a moral right', philosopher says
 - [https://www.dailymail.co.uk/news/article-11677563/Interfering-loved-ones-big-decisions-violate-moral-right-philosopher-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677563/Interfering-loved-ones-big-decisions-violate-moral-right-philosopher-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:27:07+00:00
 - user: None

Dr Farbod Akhlaghi of Cambridge University believes that we have a duty to allow others to make 'transformative choices' such as having children, moving country or changing careers.

## George Santos said Jeffrey Epstein was 'murdered' and they met a 'couple' of times in 2020 interview
 - [https://www.dailymail.co.uk/news/article-11677439/George-Santos-said-Jeffrey-Epstein-murdered-met-couple-times-2020-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677439/George-Santos-said-Jeffrey-Epstein-murdered-met-couple-times-2020-interview.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:21:43+00:00
 - user: None

Santos said in an August 2020 interview that Ghislaine Maxwell should be 'offered the protections of...foreign custodianship, so that she is not murdered just like Epstein was.'

## Ministers eye up tough new legislation to prosecute revellers with 'hippy crack' in crackdown
 - [https://www.dailymail.co.uk/news/article-11677365/Ministers-eye-tough-new-legislation-prosecute-revellers-hippy-crack-crackdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677365/Ministers-eye-tough-new-legislation-prosecute-revellers-hippy-crack-crackdown.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:16:42+00:00
 - user: None

Sale and possession of nitrous oxide, also known as 'hippy crack', is expected to be made illegal with only those with a 'legitimate excuse' exempt from prosecution.

## Peta Credlin warns the Indigenous Voice to Paement will be the END of Australia Day
 - [https://www.dailymail.co.uk/news/article-11677145/Peta-Credlin-warns-Indigenous-Voice-Paement-END-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677145/Peta-Credlin-warns-Indigenous-Voice-Paement-END-Australia-Day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:16:27+00:00
 - user: None

A fiery Peta Credlin has lashed the Labor Party for weakening the idea of national unity in a withering column about what could be our last Australia Day.

## Mass people at Bulli Beach, NSW, after swimmers swept away by a rip
 - [https://www.dailymail.co.uk/news/article-11677289/three-people-rescued-Bulli-Beach-NSW-swimmers-caught-rip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677289/three-people-rescued-Bulli-Beach-NSW-swimmers-caught-rip.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:13:07+00:00
 - user: None

Surf Life Savers have rescued eight people at a beach in NSW after they were caught in a rip and swept away.

## Broadband customers trying to beat price hikes by switching supplier are trapped by big exit fees
 - [https://www.dailymail.co.uk/news/article-11677479/Broadband-customers-trying-beat-price-hikes-switching-supplier-trapped-big-exit-fees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677479/Broadband-customers-trying-beat-price-hikes-switching-supplier-trapped-big-exit-fees.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:06:32+00:00
 - user: None

Major internet suppliers such as BT, Sky, TalkTalk, Vodafone, EE and Virgin Media are expected to hike bills by an inflation-busting 14 per cent or more in April - adding as much as £66 to annual bills.

## Notorious Colombian cartel leader 'Otoniel' faces a minimum of 20 years in US prison
 - [https://www.dailymail.co.uk/news/article-11677299/Notorious-Colombian-cartel-leader-Otoniel-faces-minimum-20-years-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677299/Notorious-Colombian-cartel-leader-Otoniel-faces-minimum-20-years-prison.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:05:34+00:00
 - user: None

Colombian drug lord Dairo Antonio 'Otoniel' Úsuga faces a minimum of 20 years in an American prison after pleading guilty to running a multibillion-dollar cocaine empire.

## Assistant principal at the Virginia school where a 6-year-old shot
 - [https://www.dailymail.co.uk/news/article-11677301/Assistant-principal-Virginia-school-6-year-old-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677301/Assistant-principal-Virginia-school-6-year-old-shot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:02:51+00:00
 - user: None

Dr Ebony Parker, the vice principal of Richneck Elementary School in Newport News, resigned Wednesday - shortly after Abigail Zwerner, 25, said she was suing over the January 6 shooting.

## Massachusetts midwife accused of strangling her two children to death before jumping out the window
 - [https://www.dailymail.co.uk/news/article-11677093/Massachusetts-midwife-accused-strangling-two-children-death-jumping-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677093/Massachusetts-midwife-accused-strangling-two-children-death-jumping-window.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:02:28+00:00
 - user: None

A mother has been accused of strangling her two children to death and attempting to kill her eight-month-old baby before jumping out of the top window of her Massachusetts home.

## Election guru's pep talk to Tories will encourage ministers to believe they CAN win next ballot
 - [https://www.dailymail.co.uk/news/article-11677483/Election-gurus-pep-talk-Tories-encourage-ministers-believe-win-ballot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-11677483/Election-gurus-pep-talk-Tories-encourage-ministers-believe-win-ballot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-01-26 00:01:45+00:00
 - user: None

Rishi Sunak will gather his Cabinet at Chequers this afternoon for an 'away day' designed to deliver on his New Year pledges and set a course for next year's election.
