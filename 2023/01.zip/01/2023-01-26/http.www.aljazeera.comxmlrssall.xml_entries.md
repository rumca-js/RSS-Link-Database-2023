# Source Aljazeera, Source URL:http://www.aljazeera.com/xml/rss/all.xml, Source language: en-US

## California storms give state much-needed boost in water supply
 - [https://www.aljazeera.com/news/2023/1/26/california-storms-give-state-much-needed-boost-in-water-supply](https://www.aljazeera.com/news/2023/1/26/california-storms-give-state-much-needed-boost-in-water-supply)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 23:09:59+00:00
 - user: None

A series of atmospheric rivers covered the parched state with an estimated 121 trillion litres of water.

## New York City bike path attacker convicted for 2017 rampage
 - [https://www.aljazeera.com/news/2023/1/26/new-york-city-bike-path-attacker-convicted-for-2017-rampage](https://www.aljazeera.com/news/2023/1/26/new-york-city-bike-path-attacker-convicted-for-2017-rampage)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 23:03:18+00:00
 - user: None

Sayfullo Saipov, who killed eight people after driving a truck down a busy New York City bike path, faces death penalty.

## US Census could get MENA category after new recommendations
 - [https://www.aljazeera.com/news/2023/1/26/us-census-could-get-mena-category-after-new-recommendations](https://www.aljazeera.com/news/2023/1/26/us-census-could-get-mena-category-after-new-recommendations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 22:57:45+00:00
 - user: None

US government panel recommends adding box on Census to count people from the Middle East and North Africa region.

## A US state asked for evidence to ban TikTok. The FBI offered none
 - [https://www.aljazeera.com/economy/2023/1/26/a-us-state-asked-fbi-for-evidence-to-ban-tiktok-it-declined](https://www.aljazeera.com/economy/2023/1/26/a-us-state-asked-fbi-for-evidence-to-ban-tiktok-it-declined)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:49:21+00:00
 - user: None

Emails show officials in the state of Connecticut opted not to ban the Chinese-owned app after consulting with the FBI.

## Russia: NATO war involvement ‘growing’ with arms to Ukraine
 - [https://www.aljazeera.com/news/2023/1/26/russia-nato-war-involvement-growing-with-arms-to-ukraine](https://www.aljazeera.com/news/2023/1/26/russia-nato-war-involvement-growing-with-arms-to-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:36:47+00:00
 - user: None

War experts are divided on how effective Germany’s Leopard 2 and American Abrams tanks will be against Russian forces.

## US economy posts strong growth in Q4 but underlying weakness
 - [https://www.aljazeera.com/economy/2023/1/26/us-economy-posts-strong-growth-in-q4-but-underlying-weakness](https://www.aljazeera.com/economy/2023/1/26/us-economy-posts-strong-growth-in-q4-but-underlying-weakness)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:28:12+00:00
 - user: None

Most economists expect a recession by the second half of the year, though a short, mild one compared to previous ones.

## Tensions soar in Haiti’s capital after police officers killed
 - [https://www.aljazeera.com/news/2023/1/26/tensions-soar-in-haitis-capital-after-police-officers-killed](https://www.aljazeera.com/news/2023/1/26/tensions-soar-in-haitis-capital-after-police-officers-killed)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:20:30+00:00
 - user: None

Protesters erect burning barricades in Port-au-Prince as anger bubbles over following recent killings by Haitian gangs.

## US officers involved in Tyre Nichols’s death face murder charges
 - [https://www.aljazeera.com/news/2023/1/26/us-officers-involved-in-tyre-nicholss-death-face-murder-charges](https://www.aljazeera.com/news/2023/1/26/us-officers-involved-in-tyre-nicholss-death-face-murder-charges)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:13:50+00:00
 - user: None

Family says Nichols was beaten for three minutes by officers during traffic stop before dying in hospital days later.

## Peru pulls ambassador from Honduras amid regional criticism
 - [https://www.aljazeera.com/news/2023/1/26/peru-increasingly-isolated-as-protedeath-toll-climbs](https://www.aljazeera.com/news/2023/1/26/peru-increasingly-isolated-as-protedeath-toll-climbs)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 20:01:51+00:00
 - user: None

Peru has struggled with diplomatic isolation as left-wing governments criticise its crackdown on protesters.

## How will US and German tanks help Ukraine?
 - [https://www.aljazeera.com/program/inside-story/2023/1/26/how-will-us-and-german-tanks-help-ukraine](https://www.aljazeera.com/program/inside-story/2023/1/26/how-will-us-and-german-tanks-help-ukraine)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 19:25:22+00:00
 - user: None

Berlin and Washington are sending Leopard II and M1 Abrams models to Kyiv to support its fight against Russia.

## ‘Appalled’: Dozens of Democrats slam Biden’s border policies
 - [https://www.aljazeera.com/news/2023/1/26/appalled-dozens-of-democrats-slam-bidens-border-policies](https://www.aljazeera.com/news/2023/1/26/appalled-dozens-of-democrats-slam-bidens-border-policies)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 19:14:12+00:00
 - user: None

New US restrictions on asylum &#039;will not solve&#039; challenge at country&#039;s border with Mexico, Democratic legislators say.

## What is the US debt ceiling & why Congress cannot delay decision?
 - [https://www.aljazeera.com/economy/2023/1/26/what-is-the-us-debt-ceiling-why-congress-cannot-delay-a-decision](https://www.aljazeera.com/economy/2023/1/26/what-is-the-us-debt-ceiling-why-congress-cannot-delay-a-decision)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 18:46:29+00:00
 - user: None

A default by the US government could have catastrophic effects on both domestic and global economies.

## Fresh US sanctions target Russia’s Wagner mercenary group
 - [https://www.aljazeera.com/news/2023/1/26/fresh-us-sanctions-target-russias-wagner-mercenary-group](https://www.aljazeera.com/news/2023/1/26/fresh-us-sanctions-target-russias-wagner-mercenary-group)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 18:25:08+00:00
 - user: None

Washington says Moscow is relying on Wagner Group in Ukraine war amid biting Western sanctions and battlefield setbacks.

## Photos: More than 150 dead as Afghans battle cold wave
 - [https://www.aljazeera.com/gallery/2023/1/26/photos-afghans-battle-cold-weather-and-snow-hundreds-dead](https://www.aljazeera.com/gallery/2023/1/26/photos-afghans-battle-cold-weather-and-snow-hundreds-dead)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 18:07:20+00:00
 - user: None

Afghanistan is facing its worst winter in more than a decade amid an unprecedented humanitarian crisis.

## Asteroid will miss Earth in one of closest approaches ever: NASA
 - [https://www.aljazeera.com/news/2023/1/26/asteroid-will-miss-earth-in-one-of-closest-approaches-ever-nasa](https://www.aljazeera.com/news/2023/1/26/asteroid-will-miss-earth-in-one-of-closest-approaches-ever-nasa)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 18:05:38+00:00
 - user: None

Scientists say a truck-sized asteroid is expected to pass Earth on Thursday, within the orbit of broadcast satellites.

## Real Madrid’s Vinicius Jr demands punishment over hanged effigy
 - [https://www.aljazeera.com/news/2023/1/26/vinicius-jr-demands-punishment-against-racist-effigy-act](https://www.aljazeera.com/news/2023/1/26/vinicius-jr-demands-punishment-against-racist-effigy-act)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 17:38:26+00:00
 - user: None

Effigy of the winger hanged from a bridge near the club&#039;s training ground before Real&#039;s meeting with rival Atletico.

## Pakistan’s rupee plunges as IMF says mission to visit next week
 - [https://www.aljazeera.com/news/2023/1/26/pakistan-rupee-plunges-imf-visit](https://www.aljazeera.com/news/2023/1/26/pakistan-rupee-plunges-imf-visit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 17:35:18+00:00
 - user: None

Pakistan is seeking $1.1bn from the fund, part of its $6bn bailout package, to avoid default.

## Russia labels news outlet Meduza an ‘undesirable organisation’
 - [https://www.aljazeera.com/news/2023/1/26/russia-labels-news-outlet-meduza-undesirable-organisation](https://www.aljazeera.com/news/2023/1/26/russia-labels-news-outlet-meduza-undesirable-organisation)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 17:30:33+00:00
 - user: None

Authorities allege Latvia-based publication threatens Russia&#039;s constitutional system and security.

## US shuts down major ransomware network Hive
 - [https://www.aljazeera.com/economy/2023/1/26/us-shuts-down-major-ransomware-network-hive](https://www.aljazeera.com/economy/2023/1/26/us-shuts-down-major-ransomware-network-hive)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 17:12:40+00:00
 - user: None

US officials say Hive ransomware network extorted more than $100m from victims in more than 80 countries.

## Thousands of Cubans left scrambling after new US asylum policy
 - [https://www.aljazeera.com/news/2023/1/26/thousands-of-cubans-left-scrambling-after-new-us-asylum-policy](https://www.aljazeera.com/news/2023/1/26/thousands-of-cubans-left-scrambling-after-new-us-asylum-policy)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 16:23:07+00:00
 - user: None

A new policy under the Biden administration to restrict border crossings creates hurdles for Cuban asylum seekers.

## Blinken to head to Middle East amid Israeli-Palestinian tensions
 - [https://www.aljazeera.com/news/2023/1/26/blinken-to-head-to-middle-east-amid-israeli-palestinian-tensions](https://www.aljazeera.com/news/2023/1/26/blinken-to-head-to-middle-east-amid-israeli-palestinian-tensions)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 16:22:11+00:00
 - user: None

Washington says US secretary of state will stress &#039;upholding the historic status quo&#039; of the holy sites in Jerusalem.

## Canada appoints first representative to fight Islamophobia
 - [https://www.aljazeera.com/news/2023/1/26/canada-appoints-first-representative-to-fight-islamophobia](https://www.aljazeera.com/news/2023/1/26/canada-appoints-first-representative-to-fight-islamophobia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 16:07:26+00:00
 - user: None

Advocacy group welcomes appointment of Amira Elghawaby to advisory role as &#039;historic moment for Muslims in Canada&#039;.

## Transgender rapist will not serve time in women’s jail: Sturgeon
 - [https://www.aljazeera.com/news/2023/1/26/trans-rapist-will-not-serve-time-in-womens-jail-sturgeon](https://www.aljazeera.com/news/2023/1/26/trans-rapist-will-not-serve-time-in-womens-jail-sturgeon)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 15:34:49+00:00
 - user: None

Scotland&#039;s first minister says a trans woman convicted of raping two women will not serve a sentence in Cornton Vale.

## Pakistani cricket star Babar Azam named player of the year
 - [https://www.aljazeera.com/sports/2023/1/26/pakistani-cricket-star-babar-azam-named-player-of-the-year](https://www.aljazeera.com/sports/2023/1/26/pakistani-cricket-star-babar-azam-named-player-of-the-year)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 15:23:34+00:00
 - user: None

He was the only batter in international cricket who managed to cross more than 2,500 runs in all formats last year.

## UK gender battle stirs talk of independence in Scotland
 - [https://www.aljazeera.com/news/2023/1/26/scottish-gender-reform-bill-sparks-independence-talks](https://www.aljazeera.com/news/2023/1/26/scottish-gender-reform-bill-sparks-independence-talks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 15:16:08+00:00
 - user: None

Scots voted to stay in the union nine years ago, but a new cultural conflict with London has restarted a heated debate.

## India invites Pakistan foreign minister to attend SCO summit
 - [https://www.aljazeera.com/news/2023/1/26/india-invite-for-pak-fm-to-attend-sco-summit](https://www.aljazeera.com/news/2023/1/26/india-invite-for-pak-fm-to-attend-sco-summit)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 15:14:10+00:00
 - user: None

Pakistan yet to accept the invite but experts say it will not lead to thaw in ties as it is a multilateral summit.

## Why is the US worried about Israel’s new government?
 - [https://www.aljazeera.com/program/the-bottom-line/2023/1/26/why-is-the-us-worried-about-israels-new-government](https://www.aljazeera.com/program/the-bottom-line/2023/1/26/why-is-the-us-worried-about-israels-new-government)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 14:54:17+00:00
 - user: None

President Joe Biden is sending his top diplomats to meet with Israeli officials in quick succession.

## Letter from a mass grave in Mexico
 - [https://www.aljazeera.com/opinions/2023/1/26/letter-from-a-mass-grave-in-mexico](https://www.aljazeera.com/opinions/2023/1/26/letter-from-a-mass-grave-in-mexico)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 14:07:45+00:00
 - user: None

Earlier this month, I visited an unmarked grave for those who died in Mexico&#039;s US-backed war on asylum seekers.

## Families of Beirut port blast outraged by infighting over inquiry
 - [https://www.aljazeera.com/news/2023/1/26/families-of-beirut-port-blast-outraged-by-infighting-over-probe](https://www.aljazeera.com/news/2023/1/26/families-of-beirut-port-blast-outraged-by-infighting-over-probe)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 14:05:31+00:00
 - user: None

Dozens protest in Lebanese capital against the public prosecutor&#039;s attempt to stop a judge from continuing his probe.

## Pakistan poll panel announces April elections in two provinces
 - [https://www.aljazeera.com/news/2023/1/26/pakistan-poll-panel-announces-april-elections-in-two-provinces](https://www.aljazeera.com/news/2023/1/26/pakistan-poll-panel-announces-april-elections-in-two-provinces)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:56:55+00:00
 - user: None

Assemblies in Punjab and Khyber Pakhtunkhwa were dissolved this month as part of PTI bid to force early national polls.

## Turkish court rejects delay in case over pro-Kurdish HDP closure
 - [https://www.aljazeera.com/news/2023/1/26/turkish-court-rejects-delay-to-pro-kurdish-party-closure-trial](https://www.aljazeera.com/news/2023/1/26/turkish-court-rejects-delay-to-pro-kurdish-party-closure-trial)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:52:00+00:00
 - user: None

Constitutional Court declines request by HDP to delay a ruling that could lead to the party being shut down.

## Ethiopia’s PM Abiy Ahmed in Sudan on first visit since 2021 coup
 - [https://www.aljazeera.com/news/2023/1/26/ethiopias-pm-abiy-ahmed-in-sudan-on-first-visit-since-coup](https://www.aljazeera.com/news/2023/1/26/ethiopias-pm-abiy-ahmed-in-sudan-on-first-visit-since-coup)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:41:15+00:00
 - user: None

Abiy last visited Sudan in August 2020, during the transitional government of former Prime Minister Abdalla Hamdok.

## Middle East round-up: Turkey, Sweden, NATO and the Quran
 - [https://www.aljazeera.com/news/2023/1/26/middle-east-round-up-turkey-sweden-nato-and-the-quran](https://www.aljazeera.com/news/2023/1/26/middle-east-round-up-turkey-sweden-nato-and-the-quran)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:38:31+00:00
 - user: None

Here’s a round-up of Al Jazeera’s Middle East coverage this week.

## Ukraine wakes up to deadly attacks after securing battle tanks
 - [https://www.aljazeera.com/news/2023/1/26/ukraine-rocked-by-rush-hour-missile-strike](https://www.aljazeera.com/news/2023/1/26/ukraine-rocked-by-rush-hour-missile-strike)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:24:14+00:00
 - user: None

At least one man killed in Kyiv, its mayor says, a day after Russia warned Western tank deliveries signal an escalation.

## South Sudan’s displaced hope pope’s visit will bring peace
 - [https://www.aljazeera.com/news/2023/1/26/south-sudans-displaced-hope-popes-visit-will-bring-peace](https://www.aljazeera.com/news/2023/1/26/south-sudans-displaced-hope-popes-visit-will-bring-peace)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 13:22:01+00:00
 - user: None

There are 2.2 million internally displaced people in South Sudan as a civil war that began in 2013 continues to simmer.

## Fighting on two fronts: Zelenskyy battles corruption and Russia
 - [https://www.aljazeera.com/news/2023/1/26/ukraine-corruption-scandal-battle-tanks](https://www.aljazeera.com/news/2023/1/26/ukraine-corruption-scandal-battle-tanks)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 12:53:11+00:00
 - user: None

Ukraine restarts the war on graft, and Western nations promise battle tanks. Could the two events be linked?

## Photos: Israeli troops kill nine Palestinians in Jenin raid
 - [https://www.aljazeera.com/gallery/2023/1/26/photos-israeli-troops-kill-nine-palestinians-in-jenin-raid](https://www.aljazeera.com/gallery/2023/1/26/photos-israeli-troops-kill-nine-palestinians-in-jenin-raid)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 11:59:48+00:00
 - user: None

Elderly woman among dead in latest raid targeting Jenin refugee camp in occupied West Bank.

## North and South Korea violated armistice with drones: UN Command
 - [https://www.aljazeera.com/news/2023/1/26/n-korea-and-south-korea-violated-armistice-with-drone-flights-un](https://www.aljazeera.com/news/2023/1/26/n-korea-and-south-korea-violated-armistice-with-drone-flights-un)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 11:24:56+00:00
 - user: None

Flying drones into each other&#039;s airspace violated an armistice that ended fighting in the 1950-1953 Korean War, UN says.

## Match-fixing scandal threatens to turn snooker’s boom into bust
 - [https://www.aljazeera.com/sports/2023/1/26/snooker-match-fixing-chinese-players-suspended](https://www.aljazeera.com/sports/2023/1/26/snooker-match-fixing-chinese-players-suspended)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 11:09:07+00:00
 - user: None

Concerns grow over the influence of organised crime in snooker, as gangs seek to exploit vulnerabilities in the sport.

## India’s 74th Republic Day celebrations
 - [https://www.aljazeera.com/gallery/2023/1/26/photos-india-74th-republic-day-celebrations](https://www.aljazeera.com/gallery/2023/1/26/photos-india-74th-republic-day-celebrations)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 10:42:13+00:00
 - user: None

Tens of thousands gather to watch the celebrations on a newly-revamped ceremonial boulevard in New Delhi.

## Bahrain crown prince and Qatar emir discuss ‘differences’ in call
 - [https://www.aljazeera.com/news/2023/1/26/bahrain-crown-prince-qatars-emir-phone-call](https://www.aljazeera.com/news/2023/1/26/bahrain-crown-prince-qatars-emir-phone-call)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 10:10:56+00:00
 - user: None

Leaders agreed the countries will continue to communicate to achieve common goals, BNA state news agency reports.

## Myanmar women target of online abuse by pro-military social media
 - [https://www.aljazeera.com/news/2023/1/26/myanmar-women-target-of-online-abuse-by-pro-military-social-media](https://www.aljazeera.com/news/2023/1/26/myanmar-women-target-of-online-abuse-by-pro-military-social-media)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:58:34+00:00
 - user: None

Women threatened for expressing views opposing military rule with their online abusers calling for off-line punishment.

## Yemen and Lebanon landmarks added to UNESCO endangered list
 - [https://www.aljazeera.com/news/2023/1/26/yemen-and-lebanon-landmarks-added-to-unesco-endangered-list](https://www.aljazeera.com/news/2023/1/26/yemen-and-lebanon-landmarks-added-to-unesco-endangered-list)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:56:15+00:00
 - user: None

Landmarks of ancient kingdom of Saba and Rachid Karami International Fair inscribed to list of sites in danger.

## Resurrecting Australia’s Extinct Tasmanian Tiger
 - [https://www.aljazeera.com/program/101-east/2023/1/26/resurrecting-australias-extinct-tasmanian-tiger](https://www.aljazeera.com/program/101-east/2023/1/26/resurrecting-australias-extinct-tasmanian-tiger)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:37:01+00:00
 - user: None

101 East meets the scientists trying to bring the Tasmanian tiger back to life.

## Israel raids: Why are so many Palestinians being killed?
 - [https://www.aljazeera.com/news/2023/1/26/why-israeli-raids-killed-many-palestinians-this-year-explainer](https://www.aljazeera.com/news/2023/1/26/why-israeli-raids-killed-many-palestinians-this-year-explainer)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:28:34+00:00
 - user: None

Al Jazeera breaks down the reason for the increase in the number of Palestinians killed by Israel in recent months.

## India celebrates Republic Day, Egyptian leader attends parade
 - [https://www.aljazeera.com/news/2023/1/26/india-celebrates-74th-republic-day](https://www.aljazeera.com/news/2023/1/26/india-celebrates-74th-republic-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:18:16+00:00
 - user: None

India marks its 74th Republic Day with a ceremonial parade; Egypt&#039;s Abdel Fattah el-Sisi attends as a guest of honour.

## South Korea’s capital weathers snowstorm as cold spell bites
 - [https://www.aljazeera.com/gallery/2023/1/26/photos-south-korea-capital-region-weathers-snowstorm](https://www.aljazeera.com/gallery/2023/1/26/photos-south-korea-capital-region-weathers-snowstorm)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:14:35+00:00
 - user: None

Morning temperatures in Seoul and nearby regions fell to about minus 10 degrees Celsius (14 degrees Fahrenheit).

## Mali court sentences man to death over UN peacekeeper deaths
 - [https://www.aljazeera.com/news/2023/1/26/mali-court-sentences-man-to-death-over-u-n-peacekeeper-deaths](https://www.aljazeera.com/news/2023/1/26/mali-court-sentences-man-to-death-over-u-n-peacekeeper-deaths)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 09:06:14+00:00
 - user: None

The peacekeeping mission has recorded 281 deaths of its soldiers since it became operational in Mali in 2013.

## Lebanese judge at the centre of Beirut blast inquiry showdown
 - [https://www.aljazeera.com/news/2023/1/26/beirut-port-blast-judge-will-face-challenges-and-risks-lawyers](https://www.aljazeera.com/news/2023/1/26/beirut-port-blast-judge-will-face-challenges-and-risks-lawyers)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 08:47:40+00:00
 - user: None

Judge Tarek Bitar has faced intense opposition from Lebanon&#039;s establishment since resuming the investigation on Monday.

## Djokovic’s father poses with tennis fans waving pro-Russia flags
 - [https://www.aljazeera.com/sports/2023/1/26/australian-open-tennis-djokovic-father-pro-russian-flags](https://www.aljazeera.com/sports/2023/1/26/australian-open-tennis-djokovic-father-pro-russian-flags)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 08:13:10+00:00
 - user: None

The video emerged as police removed four people from the Australian Open tournament for displaying Russian flags.

## Kenyan court convicts Venezuelan diplomat of murdering ambassador
 - [https://www.aljazeera.com/news/2023/1/26/kenyan-court-convicts-venezuelan-diplomat-of-murdering-ambassador](https://www.aljazeera.com/news/2023/1/26/kenyan-court-convicts-venezuelan-diplomat-of-murdering-ambassador)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 08:12:26+00:00
 - user: None

Dwight Sagaray found guilty of killing Olga Fonseca, Venezuela&#039;s envoy in Nairobi, in 2012 over a power struggle.

## Israeli raid kills four Palestinians, including elderly woman
 - [https://www.aljazeera.com/news/2023/1/26/israeli-raid-kills-three-palestinians-in-jenin-fighting](https://www.aljazeera.com/news/2023/1/26/israeli-raid-kills-three-palestinians-in-jenin-fighting)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 07:49:12+00:00
 - user: None

Israeli forces fought with Palestinian fighters in the occupied West Bank city of Jenin.

## Man kills official in machete attack on two churches in Spain
 - [https://www.aljazeera.com/news/2023/1/26/man-kills-official-in-machete-attack-on-two-churches-in-spain](https://www.aljazeera.com/news/2023/1/26/man-kills-official-in-machete-attack-on-two-churches-in-spain)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 07:46:21+00:00
 - user: None

Prosecutors are investigating the attacks at two Catholic churches in Algeciras as a possible &#039;act of terrorism&#039;.

## Indonesia’s charity laws in spotlight after Lion Air crash scam
 - [https://www.aljazeera.com/economy/2023/1/26/indonesia-law-under-scrutiny-after-lion-air-crash-charity-scam](https://www.aljazeera.com/economy/2023/1/26/indonesia-law-under-scrutiny-after-lion-air-crash-charity-scam)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 07:17:08+00:00
 - user: None

Three charity workers have been given prison terms for misappropriating $7.8m from a victims&#039; fund set up by Boeing.

## France agrees to withdraw troops from Burkina Faso within a month
 - [https://www.aljazeera.com/news/2023/1/26/france-agrees-to-withdraw-troops-from-burkina-faso-within-a-month](https://www.aljazeera.com/news/2023/1/26/france-agrees-to-withdraw-troops-from-burkina-faso-within-a-month)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 06:47:10+00:00
 - user: None

The move comes after the Sahel country&#039;s military rulers demanded that Paris withdraw its forces.

## Philippine economy grows at fastest pace in 40 years
 - [https://www.aljazeera.com/economy/2023/1/26/philippine-economy-grows-at-fastest-pace-in-40-years](https://www.aljazeera.com/economy/2023/1/26/philippine-economy-grows-at-fastest-pace-in-40-years)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 06:32:06+00:00
 - user: None

Analysts warn global slowdown and soaring inflation point to a difficult year ahead for the Southeast Asian economy.

## Russia-Ukraine war: List of key events, day 337
 - [https://www.aljazeera.com/news/2023/1/26/russia-ukraine-war-list-of-key-events-day-337](https://www.aljazeera.com/news/2023/1/26/russia-ukraine-war-list-of-key-events-day-337)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 06:15:43+00:00
 - user: None

As the Russia-Ukraine war enters its 337th day, we take a look at the main developments.

## Thousands protest ‘invasion’ on divisive Australia holiday
 - [https://www.aljazeera.com/news/2023/1/26/thousands-protest-invasion-as-australia-marks-national-day](https://www.aljazeera.com/news/2023/1/26/thousands-protest-invasion-as-australia-marks-national-day)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 05:35:46+00:00
 - user: None

Australians rally in support of Indigenous rights on the anniversary of the day the British colonial fleet arrived.

## Northeast Asia battles severe cold snap and heavy snow
 - [https://www.aljazeera.com/news/2023/1/26/plunging-temperatures-heavy-snow-across-northeast-asia](https://www.aljazeera.com/news/2023/1/26/plunging-temperatures-heavy-snow-across-northeast-asia)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 05:10:42+00:00
 - user: None

The Korean Peninsula, Japan and China see temperatures plunge to levels not seen in a decade as snow hampers travel.

## Surveillance concerns as India issues new digital IDs in Kashmir
 - [https://www.aljazeera.com/news/2023/1/26/surveillance-concerns-as-india-issues-new-digital-ids-in-kashmir](https://www.aljazeera.com/news/2023/1/26/surveillance-concerns-as-india-issues-new-digital-ids-in-kashmir)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 05:09:40+00:00
 - user: None

In Indian-administered Kashmir, some see the new family IDs as part of campaign to exert greater control over residents.

## South Korean economy shrinks for first time since 2020
 - [https://www.aljazeera.com/economy/2023/1/26/south-korean-economy-shrinks-first-time-2020](https://www.aljazeera.com/economy/2023/1/26/south-korean-economy-shrinks-first-time-2020)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 04:47:20+00:00
 - user: None

Sagging exports and private consumption see Asia&#039;s fourth-largest economy contract for first time in 2-1/2 years.

## Lawmakers submit motion to impeach Peru President Dina Boluarte
 - [https://www.aljazeera.com/news/2023/1/26/lawmakers-submit-motion-to-impeach-peru-president-dina-boluarte](https://www.aljazeera.com/news/2023/1/26/lawmakers-submit-motion-to-impeach-peru-president-dina-boluarte)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 04:25:02+00:00
 - user: None

Move underlines severe polarisation of a country, which has had six presidents in six years.

## Opium cultivation surges since Myanmar military seized power: UN
 - [https://www.aljazeera.com/news/2023/1/26/opium-cultivation-surges-since-myanmar-military-seized-power-un](https://www.aljazeera.com/news/2023/1/26/opium-cultivation-surges-since-myanmar-military-seized-power-un)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 04:03:04+00:00
 - user: None

Opium poppy was cultivated on more than 40,000 hectares in Myanmar last year, a 33% increase compared with 2021.

## UNESCO designates Odesa as World Heritage site amid war threats
 - [https://www.aljazeera.com/news/2023/1/26/unesco-designates-odesa-as-world-heritage-site-amid-war-threats](https://www.aljazeera.com/news/2023/1/26/unesco-designates-odesa-as-world-heritage-site-amid-war-threats)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 02:28:02+00:00
 - user: None

The decision is designed to protect the &#039;outstanding universal value&#039; of the historic Black Sea port.

## Rohingya are drowning at sea. Asia’s leaders are to blame
 - [https://www.aljazeera.com/opinions/2023/1/26/rohingya-are-drowning-at-sea-asias-leaders-are-to-blame](https://www.aljazeera.com/opinions/2023/1/26/rohingya-are-drowning-at-sea-asias-leaders-are-to-blame)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 01:53:43+00:00
 - user: None

Leaders from Southeast and South Asia are acting both illegally and immorally by not helping Rohingya &quot;boat people&quot;.

## Former Colombian drug-trafficking magnate pleads guilty in US
 - [https://www.aljazeera.com/news/2023/1/26/most-dangerous-drug-trafficker-in-the-world-pleads-guilty-in-us](https://www.aljazeera.com/news/2023/1/26/most-dangerous-drug-trafficker-in-the-world-pleads-guilty-in-us)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 00:37:16+00:00
 - user: None

Dairo Antonio Usuga David, or &#039;Otoniel&#039;, was leader of the Gulf Clan, one of Colombia&#039;s largest paramilitary groups.

## Trump to return to Meta platform Facebook after two-year ban
 - [https://www.aljazeera.com/news/2023/1/26/trump-to-return-to-meta-platform-facebook-after-two-year-ban](https://www.aljazeera.com/news/2023/1/26/trump-to-return-to-meta-platform-facebook-after-two-year-ban)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-01-26 00:20:26+00:00
 - user: None

The US social media giant has called the suspension &#039;extraordinary decision taken in extraordinary circumstances&#039;.
