# Source CNN World, Source URL:http://rss.cnn.com/rss/cnn_world.rss, Source language: en-US

## Protests reach Haiti airport and Prime Minister's residence over police killings
 - [https://www.cnn.com/2023/01/26/americas/haiti-police-killings-intl-latam/index.html](https://www.cnn.com/2023/01/26/americas/haiti-police-killings-intl-latam/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-26 22:14:08+00:00
 - user: None

Protesters and some police officers protested at the official residence of Haiti's prime minister in the capital Port-au-Prince on Thursday, decrying recent killings of police, according to one of his advisors.

## The US economy grew by 2.9% in the fourth quarter, more than expected
 - [https://www.cnn.com/2023/01/26/economy/us-gdp-fourth-quarter/index.html](https://www.cnn.com/2023/01/26/economy/us-gdp-fourth-quarter/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-26 17:32:55+00:00
 - user: None

The US economy expanded again during the fourth quarter, registering solid growth to end 2022 even as consumers and businesses battled historically high inflation and rising historically high interest rates.

## One news publication had an AI tool write articles. It didn't go well
 - [https://www.cnn.com/2023/01/25/tech/cnet-ai-tool-news-stories/index.html](https://www.cnn.com/2023/01/25/tech/cnet-ai-tool-news-stories/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-26 16:23:33+00:00
 - user: None

News outlet CNET said Wednesday it has issued corrections on a number of articles, including some that it described as "substantial," after using an artificial intelligence-powered tool to help write dozens of stories.

## Southwest posts quarterly loss and warns more losses are ahead
 - [https://www.cnn.com/2023/01/26/investing/southwest-loss-from-meltdown/index.html](https://www.cnn.com/2023/01/26/investing/southwest-loss-from-meltdown/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-26 16:01:15+00:00
 - user: None

Southwest Airlines reported a loss for the fourth quarter because of the company's service meltdown over the holiday travel season, and it warned the costs from those problems will result in another loss in the first quarter.

## Stocks rise after America's economy grew more than expected
 - [https://www.cnn.com/business/live-news/stock-market-gdp-news-today-12623/index.html](https://www.cnn.com/business/live-news/stock-market-gdp-news-today-12623/index.html)
 - RSS feed: http://rss.cnn.com/rss/cnn_world.rss
 - date published: 2023-01-26 13:36:02+00:00
 - user: None


