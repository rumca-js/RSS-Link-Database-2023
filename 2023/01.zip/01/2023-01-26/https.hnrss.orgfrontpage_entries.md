# Source Hacker News - frontpage, Source URL:https://hnrss.org/frontpage, Source language: en-US

## SQLAlchemy 2.0 Released
 - [https://www.sqlalchemy.org/blog/2023/01/26/sqlalchemy-2.0.0-released/](https://www.sqlalchemy.org/blog/2023/01/26/sqlalchemy-2.0.0-released/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 23:18:24+00:00
 - user: None

<p>Article URL: <a href="https://www.sqlalchemy.org/blog/2023/01/26/sqlalchemy-2.0.0-released/">https://www.sqlalchemy.org/blog/2023/01/26/sqlalchemy-2.0.0-released/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34540251">https://news.ycombinator.com/item?id=34540251</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## ImGUI Ported to a LiteX SoC
 - [https://github.com/suarezvictor/litex_imgui_usb_demo](https://github.com/suarezvictor/litex_imgui_usb_demo)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 23:12:05+00:00
 - user: None

<p>Article URL: <a href="https://github.com/suarezvictor/litex_imgui_usb_demo">https://github.com/suarezvictor/litex_imgui_usb_demo</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34540206">https://news.ycombinator.com/item?id=34540206</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Slack is the opposite of organizational memory (2018)
 - [https://abe-winter.github.io/plea%27s/help/2018/02/11/slack.html](https://abe-winter.github.io/plea%27s/help/2018/02/11/slack.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 22:57:40+00:00
 - user: None

<p>Article URL: <a href="https://abe-winter.github.io/plea%27s/help/2018/02/11/slack.html">https://abe-winter.github.io/plea%27s/help/2018/02/11/slack.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34540085">https://news.ycombinator.com/item?id=34540085</a></p>
<p>Points: 44</p>
<p># Comments: 20</p>

## Amazon removes “contact us” support, disables support for wrong grocery orders
 - [https://news.ycombinator.com/item?id=34539901](https://news.ycombinator.com/item?id=34539901)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 22:38:29+00:00
 - user: None

<p>Received a wrong grocery item via amazon store. It now says grocery items are excluded from opening a return or refund ticket and the contact us option goes back to the main help search page. Appears now you have no recourse for amazon mistakes with their automated support.<p>Contact Us just takes you back to the support search page..<p>https://amazon.com/hz/contact-us/foresight/hubgateway</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34539901">https://news.ycombinator.com/item?id=34539901</a></p>
<p>Points: 42</p>
<p># Comments: 16</p>

## Galaga, Pac-Man, Donkey Kong Emulator for ESP32
 - [https://github.com/harbaum/galagino](https://github.com/harbaum/galagino)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 22:30:12+00:00
 - user: None

<p>Article URL: <a href="https://github.com/harbaum/galagino">https://github.com/harbaum/galagino</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34539811">https://news.ycombinator.com/item?id=34539811</a></p>
<p>Points: 13</p>
<p># Comments: 2</p>

## France's Largest Semiconductor Company Got Nationalized (2022)
 - [https://www.fabricatedknowledge.com/p/how-frances-largest-semiconductor](https://www.fabricatedknowledge.com/p/how-frances-largest-semiconductor)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 22:16:44+00:00
 - user: None

<p>Article URL: <a href="https://www.fabricatedknowledge.com/p/how-frances-largest-semiconductor">https://www.fabricatedknowledge.com/p/how-frances-largest-semiconductor</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34539669">https://news.ycombinator.com/item?id=34539669</a></p>
<p>Points: 37</p>
<p># Comments: 3</p>

## A dinosaur with a remarkably preserved face
 - [https://arstechnica.com/science/2023/01/researchers-look-a-dinosaur-in-its-remarkably-preserved-face/](https://arstechnica.com/science/2023/01/researchers-look-a-dinosaur-in-its-remarkably-preserved-face/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 21:17:08+00:00
 - user: None

<p>Article URL: <a href="https://arstechnica.com/science/2023/01/researchers-look-a-dinosaur-in-its-remarkably-preserved-face/">https://arstechnica.com/science/2023/01/researchers-look-a-dinosaur-in-its-remarkably-preserved-face/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34538965">https://news.ycombinator.com/item?id=34538965</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Arizona legislature exempts itself from public records law
 - [https://mohavedailynews.com/news/145057/legislature-changes-rules-on-retaining-correspondence/](https://mohavedailynews.com/news/145057/legislature-changes-rules-on-retaining-correspondence/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 21:08:18+00:00
 - user: None

<p>Article URL: <a href="https://mohavedailynews.com/news/145057/legislature-changes-rules-on-retaining-correspondence/">https://mohavedailynews.com/news/145057/legislature-changes-rules-on-retaining-correspondence/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34538864">https://news.ycombinator.com/item?id=34538864</a></p>
<p>Points: 47</p>
<p># Comments: 25</p>

## Resilience and Waste in Software Teams
 - [https://jessitron.com/2023/01/16/resilience-and-waste-in-software-teams/](https://jessitron.com/2023/01/16/resilience-and-waste-in-software-teams/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 20:48:48+00:00
 - user: None

<p>Article URL: <a href="https://jessitron.com/2023/01/16/resilience-and-waste-in-software-teams/">https://jessitron.com/2023/01/16/resilience-and-waste-in-software-teams/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34538604">https://news.ycombinator.com/item?id=34538604</a></p>
<p>Points: 18</p>
<p># Comments: 0</p>

## Next Rust Compiler
 - [https://matklad.github.io/2023/01/25/next-rust-compiler.html](https://matklad.github.io/2023/01/25/next-rust-compiler.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 20:06:27+00:00
 - user: None

<p>Article URL: <a href="https://matklad.github.io/2023/01/25/next-rust-compiler.html">https://matklad.github.io/2023/01/25/next-rust-compiler.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34537969">https://news.ycombinator.com/item?id=34537969</a></p>
<p>Points: 84</p>
<p># Comments: 11</p>

## Nelua, AOT statically typed Lua
 - [https://nelua.io/](https://nelua.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 19:56:34+00:00
 - user: None

<p>Article URL: <a href="https://nelua.io/">https://nelua.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34537820">https://news.ycombinator.com/item?id=34537820</a></p>
<p>Points: 28</p>
<p># Comments: 5</p>

## Librandombytes – a public domain library for generating randomness
 - [https://randombytes.cr.yp.to/](https://randombytes.cr.yp.to/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 18:46:06+00:00
 - user: None

<p>Article URL: <a href="https://randombytes.cr.yp.to/">https://randombytes.cr.yp.to/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34536605">https://news.ycombinator.com/item?id=34536605</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Swiss retailer Galaxus now displays warranty score and return rate of products
 - [https://www.galaxus.ch/en/page/refreshingly-honest-digitec-galaxus-now-displays-warranty-score-and-return-rate-25950](https://www.galaxus.ch/en/page/refreshingly-honest-digitec-galaxus-now-displays-warranty-score-and-return-rate-25950)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 18:32:07+00:00
 - user: None

<p>Article URL: <a href="https://www.galaxus.ch/en/page/refreshingly-honest-digitec-galaxus-now-displays-warranty-score-and-return-rate-25950">https://www.galaxus.ch/en/page/refreshingly-honest-digitec-galaxus-now-displays-warranty-score-and-return-rate-25950</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34536344">https://news.ycombinator.com/item?id=34536344</a></p>
<p>Points: 163</p>
<p># Comments: 37</p>

## Reverse-engineering the Intel 8086 processor's HALT circuits
 - [https://www.righto.com/2023/01/reverse-engineering-intel-8086.html](https://www.righto.com/2023/01/reverse-engineering-intel-8086.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 17:33:07+00:00
 - user: None

<p>Article URL: <a href="https://www.righto.com/2023/01/reverse-engineering-intel-8086.html">https://www.righto.com/2023/01/reverse-engineering-intel-8086.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34535150">https://news.ycombinator.com/item?id=34535150</a></p>
<p>Points: 23</p>
<p># Comments: 7</p>

## Adani Group: How 3rd Richest Man Is Pulling the Largest Con in Corporate History
 - [https://hindenburgresearch.com/?p=2376](https://hindenburgresearch.com/?p=2376)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 17:31:28+00:00
 - user: None

<p>Article URL: <a href="https://hindenburgresearch.com/?p=2376">https://hindenburgresearch.com/?p=2376</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34535109">https://news.ycombinator.com/item?id=34535109</a></p>
<p>Points: 23</p>
<p># Comments: 4</p>

## Long Covid Is Keeping Significant Numbers of People Out of Work
 - [https://www.nytimes.com/2023/01/24/health/long-covid-work.html](https://www.nytimes.com/2023/01/24/health/long-covid-work.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 17:19:38+00:00
 - user: None

<p>Article URL: <a href="https://www.nytimes.com/2023/01/24/health/long-covid-work.html">https://www.nytimes.com/2023/01/24/health/long-covid-work.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34534848">https://news.ycombinator.com/item?id=34534848</a></p>
<p>Points: 22</p>
<p># Comments: 4</p>

## Show HN: I'm a doctor and made a responsive breathing app for stress and anxiety
 - [https://www.lungy.app/](https://www.lungy.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 17:06:51+00:00
 - user: None

<p>Article URL: <a href="https://www.lungy.app/">https://www.lungy.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34534615">https://news.ycombinator.com/item?id=34534615</a></p>
<p>Points: 15</p>
<p># Comments: 6</p>

## Sexual loneliness: A neglected public health problem?
 - [https://www.researchgate.net/publication/367325876_Sexual_loneliness_A_neglected_public_health_problem](https://www.researchgate.net/publication/367325876_Sexual_loneliness_A_neglected_public_health_problem)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:49:56+00:00
 - user: None

<p>Article URL: <a href="https://www.researchgate.net/publication/367325876_Sexual_loneliness_A_neglected_public_health_problem">https://www.researchgate.net/publication/367325876_Sexual_loneliness_A_neglected_public_health_problem</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34534272">https://news.ycombinator.com/item?id=34534272</a></p>
<p>Points: 160</p>
<p># Comments: 218</p>

## Laid Off from Google Search?
 - [https://news.ycombinator.com/item?id=34534095](https://news.ycombinator.com/item?id=34534095)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:41:40+00:00
 - user: None

<p>I just got laid off from Google search after working on the ranking team for four years. Wanted to see if there's anyone out there that wants to build a search startup, especially if you're ex-Google. I have some ideas for how to build a search engine like 2010 Google, that's relatively low tech (i.e. achievable). If you're interested email me at username @ Gmail.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34534095">https://news.ycombinator.com/item?id=34534095</a></p>
<p>Points: 29</p>
<p># Comments: 19</p>

## Rails on Docker
 - [https://fly.io/ruby-dispatch/rails-on-docker/](https://fly.io/ruby-dispatch/rails-on-docker/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:32:37+00:00
 - user: None

<p>Article URL: <a href="https://fly.io/ruby-dispatch/rails-on-docker/">https://fly.io/ruby-dispatch/rails-on-docker/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533930">https://news.ycombinator.com/item?id=34533930</a></p>
<p>Points: 18</p>
<p># Comments: 1</p>

## How a CPU works: Bare metal C on my RISC-V toy CPU
 - [https://florian.noeding.com/posts/risc-v-toy-cpu/cpu-from-scratch/](https://florian.noeding.com/posts/risc-v-toy-cpu/cpu-from-scratch/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:21:06+00:00
 - user: None

<p>Article URL: <a href="https://florian.noeding.com/posts/risc-v-toy-cpu/cpu-from-scratch/">https://florian.noeding.com/posts/risc-v-toy-cpu/cpu-from-scratch/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533752">https://news.ycombinator.com/item?id=34533752</a></p>
<p>Points: 32</p>
<p># Comments: 1</p>

## Stripe sets one-year timetable to decide on going public
 - [https://www.wsj.com/articles/stripe-sets-one-year-timetable-to-decide-on-going-public-11674749304](https://www.wsj.com/articles/stripe-sets-one-year-timetable-to-decide-on-going-public-11674749304)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:18:19+00:00
 - user: None

<p>Article URL: <a href="https://www.wsj.com/articles/stripe-sets-one-year-timetable-to-decide-on-going-public-11674749304">https://www.wsj.com/articles/stripe-sets-one-year-timetable-to-decide-on-going-public-11674749304</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533710">https://news.ycombinator.com/item?id=34533710</a></p>
<p>Points: 43</p>
<p># Comments: 21</p>

## Airbyte makes 100 alpha / beta connectors free on Airbyte Cloud
 - [https://airbyte.com/blog/why-airbyte-made-alpha-and-beta-connectors-free](https://airbyte.com/blog/why-airbyte-made-alpha-and-beta-connectors-free)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 16:01:11+00:00
 - user: None

<p>Article URL: <a href="https://airbyte.com/blog/why-airbyte-made-alpha-and-beta-connectors-free">https://airbyte.com/blog/why-airbyte-made-alpha-and-beta-connectors-free</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533429">https://news.ycombinator.com/item?id=34533429</a></p>
<p>Points: 28</p>
<p># Comments: 3</p>

## Smart ovens shouting out to servers in Russia and China
 - [https://svrooij.io/2023/01/25/disconnect-your-smart-appliance/](https://svrooij.io/2023/01/25/disconnect-your-smart-appliance/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 15:59:19+00:00
 - user: None

<p>Article URL: <a href="https://svrooij.io/2023/01/25/disconnect-your-smart-appliance/">https://svrooij.io/2023/01/25/disconnect-your-smart-appliance/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533396">https://news.ycombinator.com/item?id=34533396</a></p>
<p>Points: 37</p>
<p># Comments: 21</p>

## Show HN: Knotend – a keyboard-driven flowchart editor
 - [https://www.knotend.com](https://www.knotend.com)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 15:49:02+00:00
 - user: None

<p>Hey all, I made knotend [0] because I wanted a flowchart editor that was keyboard-driven and super fast. I was tired of dragging boxes around on a canvas. You may have seen knotend around here before when I wrote an initial blog post [1] about why I wanted a new kind of flowchart editor. Thank you to everyone who has given me feedback here on HN!<p>Since that blog post I’ve been working hard to get to a v1 which I’m showing now. You can use the free version without having to sign up for an account. I would love your feedback!<p>What makes knotend different is two main things: 1) The nodes are constrained to a grid which enables a keyboard-centric experience for selection and navigation, and 2) there’s autolayout so each time you add a node, the graph automatically lays itself out and places each node in a cell.<p>In the future I’ll be working on supporting more complex editing actions, linking graphs together, collaboration, and more.<p>Please drop your feedback below, reach out on twitter [2], or email scott@knotend.com.<p>[0] <a href="https://www.knotend.com" rel="nofollow">https://www.knotend.com</a><p>[1] <a href="https://www.scottantipa.com/why-knotend" rel="nofollow">https://www.scottantipa.com/why-knotend</a><p>[2] <a href="https://twitter.com/ScottyAntipa" rel="nofollow">https://twitter.com/ScottyAntipa</a></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34533218">https://news.ycombinator.com/item?id=34533218</a></p>
<p>Points: 17</p>
<p># Comments: 6</p>

## Tell HN: IBM and SAP are cutting thousands of jobs
 - [https://news.ycombinator.com/item?id=34532983](https://news.ycombinator.com/item?id=34532983)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 15:35:04+00:00
 - user: None

<p>IBM (IBM) announced the cuts Wednesday, saying they were related to the previously announced spinoff and sale of two business units. Some 3,900 positions, or 1.5% of its global workforce, are expected to go. The move will cost IBM (IBM) about $300 million this quarter, a spokesperson confirmed.<p>SAP (SAP), Europe’s largest software company, will lay off 2.5% of its global workforce of 112,000, or around 2,800 employees, according to an earnings report published Thursday. The restructuring will cost between €250 million ($272 million) and €300 million ($381 million); the company’s shares were down 3.3% in Frankfurt.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532983">https://news.ycombinator.com/item?id=34532983</a></p>
<p>Points: 45</p>
<p># Comments: 11</p>

## The cause of depression is probably not what you think
 - [https://www.quantamagazine.org/the-cause-of-depression-is-probably-not-what-you-think-20230126/](https://www.quantamagazine.org/the-cause-of-depression-is-probably-not-what-you-think-20230126/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 15:31:55+00:00
 - user: None

<p>Article URL: <a href="https://www.quantamagazine.org/the-cause-of-depression-is-probably-not-what-you-think-20230126/">https://www.quantamagazine.org/the-cause-of-depression-is-probably-not-what-you-think-20230126/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532927">https://news.ycombinator.com/item?id=34532927</a></p>
<p>Points: 66</p>
<p># Comments: 75</p>

## IBM to cut about 3,900 workers while still hiring in ‘higher growth’ areas
 - [https://www.latimes.com/business/story/2023-01-25/ibm-layoff-3900-workers-still-hiring](https://www.latimes.com/business/story/2023-01-25/ibm-layoff-3900-workers-still-hiring)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 15:01:00+00:00
 - user: None

<p>Article URL: <a href="https://www.latimes.com/business/story/2023-01-25/ibm-layoff-3900-workers-still-hiring">https://www.latimes.com/business/story/2023-01-25/ibm-layoff-3900-workers-still-hiring</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532437">https://news.ycombinator.com/item?id=34532437</a></p>
<p>Points: 24</p>
<p># Comments: 4</p>

## An IP Attorney’s Reading of the Stable Diffusion Class Action Lawsuit
 - [https://katedowninglaw.com/2023/01/26/an-ip-attorneys-reading-of-the-stable-diffusion-class-action-lawsuit/](https://katedowninglaw.com/2023/01/26/an-ip-attorneys-reading-of-the-stable-diffusion-class-action-lawsuit/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:57:33+00:00
 - user: None

<p>Article URL: <a href="https://katedowninglaw.com/2023/01/26/an-ip-attorneys-reading-of-the-stable-diffusion-class-action-lawsuit/">https://katedowninglaw.com/2023/01/26/an-ip-attorneys-reading-of-the-stable-diffusion-class-action-lawsuit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532378">https://news.ycombinator.com/item?id=34532378</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## Fun with Gentoo: Why don't we just shuffle those ROP gadgets away?
 - [https://quitesimple.org/page/fun-gentoo-shuffle-rop-gadgets](https://quitesimple.org/page/fun-gentoo-shuffle-rop-gadgets)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:57:02+00:00
 - user: None

<p>Article URL: <a href="https://quitesimple.org/page/fun-gentoo-shuffle-rop-gadgets">https://quitesimple.org/page/fun-gentoo-shuffle-rop-gadgets</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532373">https://news.ycombinator.com/item?id=34532373</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## How thick is sea ice and how do we know?
 - [https://nsidc.org/learn/ask-scientist/how-thick-is-sea-ice](https://nsidc.org/learn/ask-scientist/how-thick-is-sea-ice)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:56:17+00:00
 - user: None

<p>Article URL: <a href="https://nsidc.org/learn/ask-scientist/how-thick-is-sea-ice">https://nsidc.org/learn/ask-scientist/how-thick-is-sea-ice</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532358">https://news.ycombinator.com/item?id=34532358</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## Tell HN: Confluent laying off 8% of staff
 - [https://news.ycombinator.com/item?id=34532295](https://news.ycombinator.com/item?id=34532295)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:51:31+00:00
 - user: None

<p>It hasn't been posted publicly but staff recieved an email from the CEO this morning announcing that 8% of staff have been cut in a "restructuring". This is especially surprising because staff have repeatedly been told that the company has strong cash reserves and is on a trajectory to profitability, even with market headwinds. No word on the breakdown by department or role.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532295">https://news.ycombinator.com/item?id=34532295</a></p>
<p>Points: 33</p>
<p># Comments: 12</p>

## Show HN: GPT Joke Writer
 - [https://punchlines.ai](https://punchlines.ai)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:46:28+00:00
 - user: None

<p>An AI joke generation tool built on top of OpenAI’s GPT-3 language models, and fine-tuned with ~15k late night comedy monologue jokes.<p>web app and model creation all open-sourced</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34532208">https://news.ycombinator.com/item?id=34532208</a></p>
<p>Points: 13</p>
<p># Comments: 12</p>

## Ask HN: What have you created that deserves a second chance on HN?
 - [https://news.ycombinator.com/item?id=34531989](https://news.ycombinator.com/item?id=34531989)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:30:30+00:00
 - user: None

<p>We all know there’s a big luck component to breaking off the /new page. I want to see the original content that you’re proud of but flopped on HN.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531989">https://news.ycombinator.com/item?id=34531989</a></p>
<p>Points: 69</p>
<p># Comments: 112</p>

## Show HN: Precloud – Dynamic tests for infrastructure-as-code. Open source
 - [https://github.com/tinystacks/precloud](https://github.com/tinystacks/precloud)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:27:40+00:00
 - user: None

<p>Infrastructure as code (IaC) often fails during deployment due to dynamic constraints such as name collisions, quota limits and other resource-specific constraints that devs run halfway into an IaC deployment. We witnessed this first hand at TinyStacks and built precloud - an open-source framework to define and run dynamic tests before IaC deployments.<p>The precloud framework currently supports Terraform and AWS CDK with several default checks (unique names, service quota checks and more) and ability to define your own!</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531943">https://news.ycombinator.com/item?id=34531943</a></p>
<p>Points: 9</p>
<p># Comments: 2</p>

## Ask HN: Good resources to become financially literate
 - [https://news.ycombinator.com/item?id=34531858](https://news.ycombinator.com/item?id=34531858)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:20:09+00:00
 - user: None

<p><p><pre><code>      I would like to change my "paycheck to paycheck" way of life and am looking to learn about financial vehicles (US based) and investment basics, and anything else that "I wish I had known when I was 20 years old".</code></pre></p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531858">https://news.ycombinator.com/item?id=34531858</a></p>
<p>Points: 43</p>
<p># Comments: 45</p>

## Show HN: Don't lose track of HN post comments
 - [https://news.ycombinator.com/item?id=34531727](https://news.ycombinator.com/item?id=34531727)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 14:08:26+00:00
 - user: None

<p>Yesterday, I got lost track of the HN post comments.<p>I fixed that problem →  http://hntoast.com<p>I make this in the last couple of hours. So, if you have any feature requests or feedback.<p>Let me know your thought about this tool.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531727">https://news.ycombinator.com/item?id=34531727</a></p>
<p>Points: 4</p>
<p># Comments: 3</p>

## Chipotle Goes on Hiring Spree of 15,000 Amid Strong Growth
 - [https://www.bloomberg.com/news/articles/2023-01-26/chipotle-jobs-restaurant-chain-to-hire-15-000-employees](https://www.bloomberg.com/news/articles/2023-01-26/chipotle-jobs-restaurant-chain-to-hire-15-000-employees)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 13:35:32+00:00
 - user: None

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-01-26/chipotle-jobs-restaurant-chain-to-hire-15-000-employees">https://www.bloomberg.com/news/articles/2023-01-26/chipotle-jobs-restaurant-chain-to-hire-15-000-employees</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531421">https://news.ycombinator.com/item?id=34531421</a></p>
<p>Points: 16</p>
<p># Comments: 13</p>

## What if AI didn't make you a bad writer, but a better thinker?
 - [https://slite.com/blog/gpt-knowledge-revolution-is-coming](https://slite.com/blog/gpt-knowledge-revolution-is-coming)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 13:29:10+00:00
 - user: None

<p>Article URL: <a href="https://slite.com/blog/gpt-knowledge-revolution-is-coming">https://slite.com/blog/gpt-knowledge-revolution-is-coming</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34531363">https://news.ycombinator.com/item?id=34531363</a></p>
<p>Points: 31</p>
<p># Comments: 19</p>

## NASA predicts asteroid to make one of closest approaches to Earth ever recorded
 - [https://www.jpl.nasa.gov/news/nasa-system-predicts-small-asteroid-to-pass-close-by-earth-this-week](https://www.jpl.nasa.gov/news/nasa-system-predicts-small-asteroid-to-pass-close-by-earth-this-week)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 12:15:09+00:00
 - user: None

<p>Article URL: <a href="https://www.jpl.nasa.gov/news/nasa-system-predicts-small-asteroid-to-pass-close-by-earth-this-week">https://www.jpl.nasa.gov/news/nasa-system-predicts-small-asteroid-to-pass-close-by-earth-this-week</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530761">https://news.ycombinator.com/item?id=34530761</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Show HN: Doc Converter – Convert PDF docs to Word documents on your computer
 - [https://docconverter.app/](https://docconverter.app/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 12:10:11+00:00
 - user: None

<p>Article URL: <a href="https://docconverter.app/">https://docconverter.app/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530710">https://news.ycombinator.com/item?id=34530710</a></p>
<p>Points: 9</p>
<p># Comments: 3</p>

## Meticulous (YC S21) Is Hiring #3 Founding Engineer in London
 - [https://news.ycombinator.com/item?id=34530631](https://news.ycombinator.com/item?id=34530631)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 12:00:12+00:00
 - user: None

<p>Hey HN,<p>I'm Gabriel, founder of Meticulous.<p>Our mission is to radically accelerate the pace of software development for every company in the world. We're starting with a tool to catch UI bugs in web applications with zero-effort from developers.<p>How it works: Insert a single line of JavaScript onto your site, and we record thousands of real user sessions. We then replay these sessions on head and base commits of PRs, take screenshots at key points, and diff those screenshots to catch visual regressions before they hit production. We employ novel techniques to eliminate flakes. You can watch a 60-second demo at [meticulous.ai](<a href="http://meticulous.ai/">http://meticulous.ai/</a>).<p>We are a London-based YC company. Our engineering team previously worked at Dropbox, Opendoor, Palantir and Google, and have previously led 100+ engineer organizations at these companies. We just raised $4m, and are backed by some of the best founders and technical leaders in Silicon Valley, including Guillermo Rauch (founder Vercel, author next.js), Jason Warner (CTO GitHub), Scott Belsky (CPO Adobe), Calvin French-Owen (founder Segment), Jared Friedman (YC partner and former CTO of Scribd) and a bunch of other incredible folks.<p>Catching visual regressions is just the start. There is an entire category of products to build on top of replay. This ranges from catching exceptions to revealing the performance impact of frontend code.<p>We want to change the way the world develops software, and influence software approaches for decades to come.<p>We are seeding a London office and hiring an onsite (few days per week) founding engineer to join our team of four.<p>You will have autonomy in building out this technology, but here are a few problems you might work on:<p>- Build a distributed system to concurrently replay thousands of sessions, such that a developer gets a result in seconds.<p>- Speed up the replay of sessions in a way that retains determinism.<p>- Derive algorithms to detect sessions that cover differing code paths and edge cases, and ignore sessions that are too similar.<p>- Help build out a team of world-class, highly collaborative, software engineers.<p>As founding engineer, you get to shape the company, and build the culture and technology from the ground up.<p>What we look for:<p>In a sentence: Technically brilliant, delightful to work with, combined with a self-awareness and strong desire to improve. We also want to make sure everyone is highly supportive of each other; we win as a team.<p>We're currently only looking to bring on folks with senior level skill sets and 5+ years of industry experience. You should have strong web fundamentals and a deep love for software engineering. Maybe you enjoy programming books like Clean Code, Designing Data Intensive Applications, Pragmatic Programmer etc. or enjoy hacking on interesting side projects. You value transparency and candid feedback, and are motivated by a strong desire to become the best engineer you can be.<p>You can read about our values here <a href="https://sumptuous-lungfish-609.notion.site/Meticulous-values-ab2b90d3324447d58f0720481081c9a6" rel="nofollow">https://sumptuous-lungfish-609.notion.site/Meticulous-values...</a><p>You will be given the space and time to up-level yourself as an engineer in terms of conferences, reading, or whatever you think will be most valuable. We will also set you up with mentorship, if you desire it, from top engineering leaders (folks running 100-engineer organizations at the world's leading tech companies).<p>You’ll get to work alongside some of the best engineers there are, break new ground solving truly novel CS problems and deliver something that transforms how software is built.<p>If this sounds interesting, please reach out to me at gabe [at] meticulous [dot] ai with “HN” in the subject line and 2-3 sentences about what you find interesting about Meticulous and your resume/LinkedIn/GitHub.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530631">https://news.ycombinator.com/item?id=34530631</a></p>
<p>Points: 1</p>
<p># Comments: 0</p>

## Blogging is not dying anytime soon
 - [https://dariusforoux.com/blogging-not-dying/](https://dariusforoux.com/blogging-not-dying/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 10:45:26+00:00
 - user: None

<p>Article URL: <a href="https://dariusforoux.com/blogging-not-dying/">https://dariusforoux.com/blogging-not-dying/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530103">https://news.ycombinator.com/item?id=34530103</a></p>
<p>Points: 31</p>
<p># Comments: 11</p>

## PayPal Data Breach Notification
 - [https://apps.web.maine.gov/online/aeviewer/ME/40/766753f1-f9c7-4dc5-9a5c-fe0f3ff51c06.shtml](https://apps.web.maine.gov/online/aeviewer/ME/40/766753f1-f9c7-4dc5-9a5c-fe0f3ff51c06.shtml)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 10:40:26+00:00
 - user: None

<p>Article URL: <a href="https://apps.web.maine.gov/online/aeviewer/ME/40/766753f1-f9c7-4dc5-9a5c-fe0f3ff51c06.shtml">https://apps.web.maine.gov/online/aeviewer/ME/40/766753f1-f9c7-4dc5-9a5c-fe0f3ff51c06.shtml</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530067">https://news.ycombinator.com/item?id=34530067</a></p>
<p>Points: 37</p>
<p># Comments: 10</p>

## Ask HN: What would be your stack if you are building an MVP today?
 - [https://news.ycombinator.com/item?id=34530052](https://news.ycombinator.com/item?id=34530052)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 10:37:49+00:00
 - user: None

<p>Specifically the backend. I'd love to hear your reasons. Do you keep one eye on what the stack would be post MVP?<p>1. Old schoolish (VPS - Maybe DO, Django/Flask/Rails/Remix/Next with postgres)<p>2. Supabase etc with JS/TS on either side of the network<p>3. Lambda/Cloud functions with Firebase/Dyanamo DB/Cosmos DB etc<p>4..n. What else and why?</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530052">https://news.ycombinator.com/item?id=34530052</a></p>
<p>Points: 79</p>
<p># Comments: 121</p>

## Realistic Computer-Generated Handwriting
 - [https://www.calligrapher.ai/](https://www.calligrapher.ai/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 10:32:04+00:00
 - user: None

<p>Article URL: <a href="https://www.calligrapher.ai/">https://www.calligrapher.ai/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34530011">https://news.ycombinator.com/item?id=34530011</a></p>
<p>Points: 9</p>
<p># Comments: 1</p>

## Show HN: 1Kb Webspace
 - [https://onekb.uber.space/](https://onekb.uber.space/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 09:29:44+00:00
 - user: None

<p>Hey guys, I wanted to introduce you my hacknight project.<p>It is a tribute to onekb.net which has stopped its service a few years ago. Currently it is still a beta where external resources are also possible (but not the point ;) ) to get your opinions.<p>When it is finished, the source code will be open source. The secret word is therefore also hackernews.<p>P.S.: The source code is currently 2.4Kb I'm trying to make it smaller. 1Kb would be my goal.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34529554">https://news.ycombinator.com/item?id=34529554</a></p>
<p>Points: 10</p>
<p># Comments: 4</p>

## Imitating Human Behaviour with Diffusion Models
 - [https://arxiv.org/abs/2301.10677](https://arxiv.org/abs/2301.10677)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 09:07:33+00:00
 - user: None

<p>Article URL: <a href="https://arxiv.org/abs/2301.10677">https://arxiv.org/abs/2301.10677</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34529401">https://news.ycombinator.com/item?id=34529401</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## An AI robot lawyer was set to argue in court. Real lawyers shut it down
 - [https://www.npr.org/2023/01/25/1151435033/a-robot-was-scheduled-to-argue-in-court-then-came-the-jail-threats](https://www.npr.org/2023/01/25/1151435033/a-robot-was-scheduled-to-argue-in-court-then-came-the-jail-threats)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 08:56:38+00:00
 - user: None

<p>Article URL: <a href="https://www.npr.org/2023/01/25/1151435033/a-robot-was-scheduled-to-argue-in-court-then-came-the-jail-threats">https://www.npr.org/2023/01/25/1151435033/a-robot-was-scheduled-to-argue-in-court-then-came-the-jail-threats</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34529340">https://news.ycombinator.com/item?id=34529340</a></p>
<p>Points: 7</p>
<p># Comments: 3</p>

## “P = NP” Polynomial-Sized LP Models for Hard Cops
 - [https://tsplp.research.uconn.edu/computational-challenge/](https://tsplp.research.uconn.edu/computational-challenge/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 08:21:50+00:00
 - user: None

<p>Article URL: <a href="https://tsplp.research.uconn.edu/computational-challenge/">https://tsplp.research.uconn.edu/computational-challenge/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34529117">https://news.ycombinator.com/item?id=34529117</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## The cathedral that failed
 - [http://riowang.blogspot.com/2023/01/the-cathedral-that-failed.html](http://riowang.blogspot.com/2023/01/the-cathedral-that-failed.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 08:18:53+00:00
 - user: None

<p>Article URL: <a href="http://riowang.blogspot.com/2023/01/the-cathedral-that-failed.html">http://riowang.blogspot.com/2023/01/the-cathedral-that-failed.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34529104">https://news.ycombinator.com/item?id=34529104</a></p>
<p>Points: 12</p>
<p># Comments: 0</p>

## The Starter House Is Nearly Extinct
 - [https://www.strongtowns.org/journal/2022/9/8/the-starter-house-is-nearly-extinct](https://www.strongtowns.org/journal/2022/9/8/the-starter-house-is-nearly-extinct)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 06:55:39+00:00
 - user: None

<p>Article URL: <a href="https://www.strongtowns.org/journal/2022/9/8/the-starter-house-is-nearly-extinct">https://www.strongtowns.org/journal/2022/9/8/the-starter-house-is-nearly-extinct</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34528505">https://news.ycombinator.com/item?id=34528505</a></p>
<p>Points: 6</p>
<p># Comments: 0</p>

## NYSE Tuesday opening mayhem traced to a staffer who left a backup system running
 - [https://www.bloomberg.com/news/articles/2023-01-25/nyse-mayhem-traced-to-a-staffer-who-left-a-backup-system-running](https://www.bloomberg.com/news/articles/2023-01-25/nyse-mayhem-traced-to-a-staffer-who-left-a-backup-system-running)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 06:47:00+00:00
 - user: None

<p>Article URL: <a href="https://www.bloomberg.com/news/articles/2023-01-25/nyse-mayhem-traced-to-a-staffer-who-left-a-backup-system-running">https://www.bloomberg.com/news/articles/2023-01-25/nyse-mayhem-traced-to-a-staffer-who-left-a-backup-system-running</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34528443">https://news.ycombinator.com/item?id=34528443</a></p>
<p>Points: 23</p>
<p># Comments: 1</p>

## Disassembly of the Asteroids arcade game firmware
 - [https://github.com/nmikstas/asteroids-disassembly](https://github.com/nmikstas/asteroids-disassembly)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 06:46:02+00:00
 - user: None

<p>Article URL: <a href="https://github.com/nmikstas/asteroids-disassembly">https://github.com/nmikstas/asteroids-disassembly</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34528433">https://news.ycombinator.com/item?id=34528433</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Two Supreme Court Cases That Could Break the Internet
 - [https://www.newyorker.com/news/q-and-a/two-supreme-court-cases-that-could-break-the-internet](https://www.newyorker.com/news/q-and-a/two-supreme-court-cases-that-could-break-the-internet)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 05:50:00+00:00
 - user: None

<p>Article URL: <a href="https://www.newyorker.com/news/q-and-a/two-supreme-court-cases-that-could-break-the-internet">https://www.newyorker.com/news/q-and-a/two-supreme-court-cases-that-could-break-the-internet</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34528119">https://news.ycombinator.com/item?id=34528119</a></p>
<p>Points: 8</p>
<p># Comments: 1</p>

## There’s No Such Thing as Affordable Housing
 - [https://www.strongtowns.org/journal/2023/1/3/theres-no-such-thing-as-affordable-housing](https://www.strongtowns.org/journal/2023/1/3/theres-no-such-thing-as-affordable-housing)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 05:29:21+00:00
 - user: None

<p>Article URL: <a href="https://www.strongtowns.org/journal/2023/1/3/theres-no-such-thing-as-affordable-housing">https://www.strongtowns.org/journal/2023/1/3/theres-no-such-thing-as-affordable-housing</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34528025">https://news.ycombinator.com/item?id=34528025</a></p>
<p>Points: 51</p>
<p># Comments: 18</p>

## Sound travels further in cold weather (2019)
 - [https://blog.weatherops.com/sound-travels-further-in-cold-weather-heres-why](https://blog.weatherops.com/sound-travels-further-in-cold-weather-heres-why)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 04:52:26+00:00
 - user: None

<p>Article URL: <a href="https://blog.weatherops.com/sound-travels-further-in-cold-weather-heres-why">https://blog.weatherops.com/sound-travels-further-in-cold-weather-heres-why</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527789">https://news.ycombinator.com/item?id=34527789</a></p>
<p>Points: 11</p>
<p># Comments: 2</p>

## The product I worked on for the last 4 years is now open-source
 - [https://www.confluent.io/blog/announcing-the-open-source-confluent-cli/](https://www.confluent.io/blog/announcing-the-open-source-confluent-cli/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 04:25:18+00:00
 - user: None

<p>Article URL: <a href="https://www.confluent.io/blog/announcing-the-open-source-confluent-cli/">https://www.confluent.io/blog/announcing-the-open-source-confluent-cli/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527670">https://news.ycombinator.com/item?id=34527670</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Newsboat: an RSS/Atom feed reader for the text console
 - [https://newsboat.org/index.html](https://newsboat.org/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 03:52:39+00:00
 - user: None

<p>Article URL: <a href="https://newsboat.org/index.html">https://newsboat.org/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527485">https://news.ycombinator.com/item?id=34527485</a></p>
<p>Points: 8</p>
<p># Comments: 0</p>

## Airframes.io an aircraft-related aggregator for ACARS, VDL, HFDL and SATCOM data
 - [https://app.airframes.io](https://app.airframes.io)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 03:21:02+00:00
 - user: None

<p>Article URL: <a href="https://app.airframes.io">https://app.airframes.io</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527340">https://news.ycombinator.com/item?id=34527340</a></p>
<p>Points: 19</p>
<p># Comments: 0</p>

## Pip and cargo are not the same
 - [https://blog.williammanley.net/2022/02/23/pip-and-cargo-are-not-the-same.html](https://blog.williammanley.net/2022/02/23/pip-and-cargo-are-not-the-same.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 02:54:44+00:00
 - user: None

<p>Article URL: <a href="https://blog.williammanley.net/2022/02/23/pip-and-cargo-are-not-the-same.html">https://blog.williammanley.net/2022/02/23/pip-and-cargo-are-not-the-same.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527206">https://news.ycombinator.com/item?id=34527206</a></p>
<p>Points: 3</p>
<p># Comments: 1</p>

## Ugly Gerry – Gerrymandering font
 - [https://fontsarena.com/ugly-gerry/](https://fontsarena.com/ugly-gerry/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 02:48:05+00:00
 - user: None

<p>Article URL: <a href="https://fontsarena.com/ugly-gerry/">https://fontsarena.com/ugly-gerry/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34527155">https://news.ycombinator.com/item?id=34527155</a></p>
<p>Points: 51</p>
<p># Comments: 12</p>

## OpenAI Major Outage
 - [https://status.openai.com/](https://status.openai.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 01:42:43+00:00
 - user: None

<p>Article URL: <a href="https://status.openai.com/">https://status.openai.com/#</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34526741">https://news.ycombinator.com/item?id=34526741</a></p>
<p>Points: 36</p>
<p># Comments: 27</p>

## VE Text Editor
 - [http://www.inverary.net/ve/ve.html](http://www.inverary.net/ve/ve.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 01:29:05+00:00
 - user: None

<p>Article URL: <a href="http://www.inverary.net/ve/ve.html">http://www.inverary.net/ve/ve.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34526651">https://news.ycombinator.com/item?id=34526651</a></p>
<p>Points: 30</p>
<p># Comments: 4</p>

## 2023: Linux rusting away into non-FOSS territory – Build rnote and you will see
 - [https://sysdfree.wordpress.com/2023/01/04/365/](https://sysdfree.wordpress.com/2023/01/04/365/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 01:16:10+00:00
 - user: None

<p>Article URL: <a href="https://sysdfree.wordpress.com/2023/01/04/365/">https://sysdfree.wordpress.com/2023/01/04/365/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34526564">https://news.ycombinator.com/item?id=34526564</a></p>
<p>Points: 10</p>
<p># Comments: 1</p>

## Nostr: Notes and Other Stuff Transmitted by Relays
 - [https://www.nostr.net/](https://www.nostr.net/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 01:15:33+00:00
 - user: None

<p>Article URL: <a href="https://www.nostr.net/">https://www.nostr.net/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34526562">https://news.ycombinator.com/item?id=34526562</a></p>
<p>Points: 17</p>
<p># Comments: 4</p>

## Landscape is an Urbit-native toolkit for staying connected with your friends
 - [https://tlon.io/](https://tlon.io/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-01-26 00:04:50+00:00
 - user: None

<p>Article URL: <a href="https://tlon.io/">https://tlon.io/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=34526038">https://news.ycombinator.com/item?id=34526038</a></p>
<p>Points: 8</p>
<p># Comments: 2</p>
