# Source MSN, Source URL:http://www.msn.com/rss/news.aspx, Source language: en-US

## Elon Musk Meets With Speaker Kevin McCarthy on Capitol Hill
 - [http://www.msn.com/en-us/news/politics/elon-musk-meets-with-speaker-kevin-mccarthy-on-capitol-hill/ar-AA16MDIJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elon-musk-meets-with-speaker-kevin-mccarthy-on-capitol-hill/ar-AA16MDIJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.137192+00:00
 - user: None



## Top Islamic State leader killed in U.S. raid in Somalia, officials say
 - [http://www.msn.com/en-us/news/world/top-islamic-state-leader-killed-in-u-s-raid-in-somalia-officials-say/ar-AA16ML6o?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/top-islamic-state-leader-killed-in-u-s-raid-in-somalia-officials-say/ar-AA16ML6o?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.129344+00:00
 - user: None



## 5 Memphis police officers charged with murder in Tyre Nichols' death
 - [http://www.msn.com/en-us/news/crime/5-memphis-police-officers-charged-with-murder-in-tyre-nichols-death/ar-AA16Medp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-memphis-police-officers-charged-with-murder-in-tyre-nichols-death/ar-AA16Medp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.121791+00:00
 - user: None



## Court demands more info in South Carolina death penalty case
 - [http://www.msn.com/en-us/news/crime/court-demands-more-info-in-south-carolina-death-penalty-case/ar-AA16MAbU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/court-demands-more-info-in-south-carolina-death-penalty-case/ar-AA16MAbU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.112461+00:00
 - user: None



## Biden says some people think he's 'stupid' just before getting congressman's name wrong
 - [http://www.msn.com/en-us/news/politics/biden-says-some-people-think-he-s-stupid-just-before-getting-congressman-s-name-wrong/ar-AA16Mwzk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-says-some-people-think-he-s-stupid-just-before-getting-congressman-s-name-wrong/ar-AA16Mwzk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.103791+00:00
 - user: None



## Ask a psychologist: Is George Santos a pathological liar?
 - [http://www.msn.com/en-us/news/politics/ask-a-psychologist-is-george-santos-a-pathological-liar/ar-AA16MEaI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ask-a-psychologist-is-george-santos-a-pathological-liar/ar-AA16MEaI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.096805+00:00
 - user: None



## DOJ takes down global ransomware group
 - [http://www.msn.com/en-us/news/politics/doj-takes-down-global-ransomware-group/ar-AA16MNXI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/doj-takes-down-global-ransomware-group/ar-AA16MNXI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.089052+00:00
 - user: None



## TikTok's 'scar girl' doesn't care if you think her scar is real or fake
 - [http://www.msn.com/en-us/news/world/tiktok-s-scar-girl-doesn-t-care-if-you-think-her-scar-is-real-or-fake/ar-AA16MNY8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/tiktok-s-scar-girl-doesn-t-care-if-you-think-her-scar-is-real-or-fake/ar-AA16MNY8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 23:56:56.081679+00:00
 - user: None



## New York City bike path terror suspect found guilty on all counts
 - [http://www.msn.com/en-us/news/crime/new-york-city-bike-path-terror-suspect-found-guilty-on-all-counts/ar-AA16MGdh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/new-york-city-bike-path-terror-suspect-found-guilty-on-all-counts/ar-AA16MGdh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.974712+00:00
 - user: None



## California’s Senate race is about to get a whole lot messier
 - [http://www.msn.com/en-us/news/politics/california-s-senate-race-is-about-to-get-a-whole-lot-messier/ar-AA16MAY5?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/california-s-senate-race-is-about-to-get-a-whole-lot-messier/ar-AA16MAY5?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.966898+00:00
 - user: None



## ‘Unfortunate Family’
 - [http://www.msn.com/en-us/news/us/unfortunate-family/ar-AA16MKMT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/unfortunate-family/ar-AA16MKMT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.959094+00:00
 - user: None



## Louisiana Jeffrey Dahmer copycat sentenced for Grindr dating app scheme to kidnap, murder men
 - [http://www.msn.com/en-us/news/us/louisiana-jeffrey-dahmer-copycat-sentenced-for-grindr-dating-app-scheme-to-kidnap-murder-men/ar-AA16MndT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/louisiana-jeffrey-dahmer-copycat-sentenced-for-grindr-dating-app-scheme-to-kidnap-murder-men/ar-AA16MndT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.951311+00:00
 - user: None



## AI wrote a bill to regulate AI. Now Rep. Ted Lieu wants Congress to pass it.
 - [http://www.msn.com/en-us/news/politics/ai-wrote-a-bill-to-regulate-ai-now-rep-ted-lieu-wants-congress-to-pass-it/ar-AA16MKMr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/ai-wrote-a-bill-to-regulate-ai-now-rep-ted-lieu-wants-congress-to-pass-it/ar-AA16MKMr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.941503+00:00
 - user: None



## Eastman faces disbarment push in California
 - [http://www.msn.com/en-us/news/politics/eastman-faces-disbarment-push-in-california/ar-AA16MB6q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/eastman-faces-disbarment-push-in-california/ar-AA16MB6q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.934458+00:00
 - user: None



## Numerous Baby Elephant Seals in California Killed by January's High Tides and Strong Storms
 - [http://www.msn.com/en-us/news/us/numerous-baby-elephant-seals-in-california-killed-by-january-s-high-tides-and-strong-storms/ar-AA16MzBW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/numerous-baby-elephant-seals-in-california-killed-by-january-s-high-tides-and-strong-storms/ar-AA16MzBW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 22:56:53.926370+00:00
 - user: None



## Ex-police officers charged with murder in connection with Tyre Nichols' death
 - [http://www.msn.com/en-us/news/crime/ex-police-officers-charged-with-murder-in-connection-with-tyre-nichols-death/ar-AA16MblB?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/ex-police-officers-charged-with-murder-in-connection-with-tyre-nichols-death/ar-AA16MblB?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.975862+00:00
 - user: None



## Madison Square Garden CEO James Dolan threatens to stop alcohol sales at Rangers game
 - [http://www.msn.com/en-us/news/us/madison-square-garden-ceo-james-dolan-threatens-to-stop-alcohol-sales-at-rangers-game/ar-AA16MFAz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/madison-square-garden-ceo-james-dolan-threatens-to-stop-alcohol-sales-at-rangers-game/ar-AA16MFAz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.968184+00:00
 - user: None



## College Board: States have not influenced our new African American studies course
 - [http://www.msn.com/en-us/news/us/college-board-states-have-not-influenced-our-new-african-american-studies-course/ar-AA16MFCc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/college-board-states-have-not-influenced-our-new-african-american-studies-course/ar-AA16MFCc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.960939+00:00
 - user: None



## ‘Landscape with Invisible Hand’ Asks: Would You Let Aliens Eavesdrop On Your Dates for Cash?
 - [http://www.msn.com/en-us/news/us/landscape-with-invisible-hand-asks-would-you-let-aliens-eavesdrop-on-your-dates-for-cash/ar-AA16MDcf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/landscape-with-invisible-hand-asks-would-you-let-aliens-eavesdrop-on-your-dates-for-cash/ar-AA16MDcf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.952510+00:00
 - user: None



## Family Searching for Answers After N.Y. Lawyer, 38, is Killed While Traveling in Chile
 - [http://www.msn.com/en-us/news/crime/family-searching-for-answers-after-n-y-lawyer-38-is-killed-while-traveling-in-chile/ar-AA16MtE7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/family-searching-for-answers-after-n-y-lawyer-38-is-killed-while-traveling-in-chile/ar-AA16MtE7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.944528+00:00
 - user: None



## Officials: Deadly Chicago high-rise fire was accidental
 - [http://www.msn.com/en-us/news/us/officials-deadly-chicago-high-rise-fire-was-accidental/ar-AA16MoOx?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/officials-deadly-chicago-high-rise-fire-was-accidental/ar-AA16MoOx?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.936782+00:00
 - user: None



## 'Hope that those officers get what they deserve,' says man who accused ex-officer in Tyre Nichols case of 2015 jailhouse assault
 - [http://www.msn.com/en-us/news/crime/hope-that-those-officers-get-what-they-deserve-says-man-who-accused-ex-officer-in-tyre-nichols-case-of-2015-jailhouse-assault/ar-AA16MyV6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/hope-that-those-officers-get-what-they-deserve-says-man-who-accused-ex-officer-in-tyre-nichols-case-of-2015-jailhouse-assault/ar-AA16MyV6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.927853+00:00
 - user: None



## Congress members introduce EACH Act to make reproductive health care more accessible
 - [http://www.msn.com/en-us/health/other/congress-members-introduce-each-act-to-make-reproductive-health-care-more-accessible/ar-AA16MoQf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/health/other/congress-members-introduce-each-act-to-make-reproductive-health-care-more-accessible/ar-AA16MoQf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 21:56:52.918164+00:00
 - user: None



## Fox’s ‘Straight News’ Anchor Harris Faulkner Lets Rick Scott Peddle His Medicare Lie
 - [http://www.msn.com/en-us/news/politics/fox-s-straight-news-anchor-harris-faulkner-lets-rick-scott-peddle-his-medicare-lie/ar-AA16M7pr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/fox-s-straight-news-anchor-harris-faulkner-lets-rick-scott-peddle-his-medicare-lie/ar-AA16M7pr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.156125+00:00
 - user: None



## BuzzFeed to use AI to produce select content
 - [http://www.msn.com/en-us/news/politics/buzzfeed-to-use-ai-to-produce-select-content/ar-AA16My5w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/buzzfeed-to-use-ai-to-produce-select-content/ar-AA16My5w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.147521+00:00
 - user: None



## Shelter Reunites Homeless Woman with Her Dog and Vows to Help Both After Finding Pet with Note
 - [http://www.msn.com/en-us/news/us/shelter-reunites-homeless-woman-with-her-dog-and-vows-to-help-both-after-finding-pet-with-note/ar-AA16MqjD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/shelter-reunites-homeless-woman-with-her-dog-and-vows-to-help-both-after-finding-pet-with-note/ar-AA16MqjD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.139531+00:00
 - user: None



## Video Shows Russian Tank Rip Apart Trees With Gunfire in Ukraine Firefight
 - [http://www.msn.com/en-us/news/world/video-shows-russian-tank-rip-apart-trees-with-gunfire-in-ukraine-firefight/ar-AA16MePM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/video-shows-russian-tank-rip-apart-trees-with-gunfire-in-ukraine-firefight/ar-AA16MePM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.127979+00:00
 - user: None



## White House says Biden 'proudly' sticks by judicial nominee, despite her flunking Kennedy's Constitution quiz
 - [http://www.msn.com/en-us/news/politics/white-house-says-biden-proudly-sticks-by-judicial-nominee-despite-her-flunking-kennedy-s-constitution-quiz/ar-AA16MkdY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/white-house-says-biden-proudly-sticks-by-judicial-nominee-despite-her-flunking-kennedy-s-constitution-quiz/ar-AA16MkdY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.117261+00:00
 - user: None



## Climate groups decry selection of oil chief to oversee COP28
 - [http://www.msn.com/en-us/news/us/climate-groups-decry-selection-of-oil-chief-to-oversee-cop28/ar-AA16LC3x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/climate-groups-decry-selection-of-oil-chief-to-oversee-cop28/ar-AA16LC3x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.109909+00:00
 - user: None



## Suspect in NYC truck attack that killed 8 found guilty in terror trial
 - [http://www.msn.com/en-us/news/crime/suspect-in-nyc-truck-attack-that-killed-8-found-guilty-in-terror-trial/ar-AA16My2h?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/suspect-in-nyc-truck-attack-that-killed-8-found-guilty-in-terror-trial/ar-AA16My2h?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 20:56:57.102331+00:00
 - user: None



## 5 ex-Memphis police officers are charged with murder in Tyre Nichols’ death
 - [http://www.msn.com/en-us/news/crime/5-ex-memphis-police-officers-are-charged-with-murder-in-tyre-nichols-death/ar-AA16M1vf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/5-ex-memphis-police-officers-are-charged-with-murder-in-tyre-nichols-death/ar-AA16M1vf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.145084+00:00
 - user: None



## Man shot dead after dog steps on hunting rifle
 - [http://www.msn.com/en-us/news/crime/man-shot-dead-after-dog-steps-on-hunting-rifle/ar-AA16MlvQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/man-shot-dead-after-dog-steps-on-hunting-rifle/ar-AA16MlvQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.136758+00:00
 - user: None



## Rodney King's daughter calls Tyre Nichols' police beating death 'sickening' 32 years after her father's assault
 - [http://www.msn.com/en-us/news/crime/rodney-king-s-daughter-calls-tyre-nichols-police-beating-death-sickening-32-years-after-her-father-s-assault/ar-AA16K6Wr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/rodney-king-s-daughter-calls-tyre-nichols-police-beating-death-sickening-32-years-after-her-father-s-assault/ar-AA16K6Wr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.127488+00:00
 - user: None



## U.S. expands sanctions on Russia's 'brutal' Wagner Group
 - [http://www.msn.com/en-us/news/world/u-s-expands-sanctions-on-russia-s-brutal-wagner-group/ar-AA16MhTw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-expands-sanctions-on-russia-s-brutal-wagner-group/ar-AA16MhTw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.119848+00:00
 - user: None



## DeSantis takes veiled shot at McDaniel in call for ‘new blood’ at RNC
 - [http://www.msn.com/en-us/news/politics/desantis-takes-veiled-shot-at-mcdaniel-in-call-for-new-blood-at-rnc/ar-AA16LRwc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/desantis-takes-veiled-shot-at-mcdaniel-in-call-for-new-blood-at-rnc/ar-AA16LRwc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.111844+00:00
 - user: None



## These are the cities with the most unhoused young adults
 - [http://www.msn.com/en-us/news/politics/these-are-the-cities-with-the-most-unhoused-young-adults/ar-AA16Merq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/these-are-the-cities-with-the-most-unhoused-young-adults/ar-AA16Merq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.103619+00:00
 - user: None



## Royal Family Tea Spilled: All About the Drama Within Denmark, Norway, Spain and Japan's Monarchies
 - [http://www.msn.com/en-us/news/world/royal-family-tea-spilled-all-about-the-drama-within-denmark-norway-spain-and-japan-s-monarchies/ar-AA16Mc6W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/royal-family-tea-spilled-all-about-the-drama-within-denmark-norway-spain-and-japan-s-monarchies/ar-AA16Mc6W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.092662+00:00
 - user: None



## Eric Adams’ annual New York City address underpins message for national Democrats
 - [http://www.msn.com/en-us/news/us/eric-adams-annual-new-york-city-address-underpins-message-for-national-democrats/ar-AA16MhYh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/eric-adams-annual-new-york-city-address-underpins-message-for-national-democrats/ar-AA16MhYh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 19:56:52.084419+00:00
 - user: None



## Five Memphis officers charged in death of Tyre Nichols
 - [http://www.msn.com/en-us/news/crime/five-memphis-officers-charged-in-death-of-tyre-nichols/ar-AA16Mbyj?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/five-memphis-officers-charged-in-death-of-tyre-nichols/ar-AA16Mbyj?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.912786+00:00
 - user: None



## Parents Charged With Murder After 4-Year-Old Son Dies From Alleged 'Exorcisms'
 - [http://www.msn.com/en-us/news/crime/parents-charged-with-murder-after-4-year-old-son-dies-from-alleged-exorcisms/ar-AA16M1R7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/parents-charged-with-murder-after-4-year-old-son-dies-from-alleged-exorcisms/ar-AA16M1R7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.905199+00:00
 - user: None



## TikTok’s master plan to win over Washington
 - [http://www.msn.com/en-us/news/politics/tiktok-s-master-plan-to-win-over-washington/ar-AA16r1p1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/tiktok-s-master-plan-to-win-over-washington/ar-AA16r1p1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.897588+00:00
 - user: None



## Egypt discovers 4,300-year-old tombs in ancient burial ground
 - [http://www.msn.com/en-us/news/world/egypt-discovers-4-300-year-old-tombs-in-ancient-burial-ground/ar-AA16Lzn4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/egypt-discovers-4-300-year-old-tombs-in-ancient-burial-ground/ar-AA16Lzn4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.889560+00:00
 - user: None



## The voters did not forget the Dobbs decision
 - [http://www.msn.com/en-us/news/politics/the-voters-did-not-forget-the-dobbs-decision/ar-AA16M6vA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-voters-did-not-forget-the-dobbs-decision/ar-AA16M6vA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.880812+00:00
 - user: None



## Scientists Find Elusive, Grumpy-Looking Cats Living on Mount Everest
 - [http://www.msn.com/en-us/news/technology/scientists-find-elusive-grumpy-looking-cats-living-on-mount-everest/ar-AA16M4eG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/scientists-find-elusive-grumpy-looking-cats-living-on-mount-everest/ar-AA16M4eG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.873127+00:00
 - user: None



## All 5 ex-Memphis police officers have been jailed in Tyre Nichols' death, records show
 - [http://www.msn.com/en-us/news/crime/all-5-ex-memphis-police-officers-have-been-jailed-in-tyre-nichols-death-records-show/ar-AA16M1vf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/all-5-ex-memphis-police-officers-have-been-jailed-in-tyre-nichols-death-records-show/ar-AA16M1vf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.864230+00:00
 - user: None



## The National Archives wants former presidents and vice presidents to see if they have any classified documents stashed anywhere
 - [http://www.msn.com/en-us/news/politics/the-national-archives-wants-former-presidents-and-vice-presidents-to-see-if-they-have-any-classified-documents-stashed-anywhere/ar-AA16MjaI?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-national-archives-wants-former-presidents-and-vice-presidents-to-see-if-they-have-any-classified-documents-stashed-anywhere/ar-AA16MjaI?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 18:56:48.855765+00:00
 - user: None



## 2 arrested for gunning down 11-year-old girl buying milk: Police
 - [http://www.msn.com/en-us/news/crime/2-arrested-for-gunning-down-11-year-old-girl-buying-milk-police/ar-AA16LWUi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/2-arrested-for-gunning-down-11-year-old-girl-buying-milk-police/ar-AA16LWUi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:49.013962+00:00
 - user: None



## Apple Avoids Layoffs Hitting the Rest of Tech, for Now
 - [http://www.msn.com/en-us/money/other/apple-avoids-layoffs-hitting-the-rest-of-tech-for-now/vi-AA16MiiV?srcref=rss](http://www.msn.com/en-us/money/other/apple-avoids-layoffs-hitting-the-rest-of-tech-for-now/vi-AA16MiiV?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:49.005517+00:00
 - user: None



## How to Measure an Asteroid in Penguins
 - [http://www.msn.com/en-us/news/technology/how-to-measure-an-asteroid-in-penguins/ar-AA16Mgaa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/how-to-measure-an-asteroid-in-penguins/ar-AA16Mgaa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.997849+00:00
 - user: None



## Homeless UK man stops armed driver's drug-fueled rampage: 'I had to act'
 - [http://www.msn.com/en-us/news/world/homeless-uk-man-stops-armed-driver-s-drug-fueled-rampage-i-had-to-act/ar-AA16Mimz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/homeless-uk-man-stops-armed-driver-s-drug-fueled-rampage-i-had-to-act/ar-AA16Mimz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.989500+00:00
 - user: None



## Court orders Detroit museum to hold onto disputed van Gogh
 - [http://www.msn.com/en-us/news/crime/court-orders-detroit-museum-to-hold-onto-disputed-van-gogh/ar-AA16Mg3R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/court-orders-detroit-museum-to-hold-onto-disputed-van-gogh/ar-AA16Mg3R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.981635+00:00
 - user: None



## The Hill’s 12:30 Report — Strong economic numbers amid another gas price rise
 - [http://www.msn.com/en-us/news/politics/the-hill-s-12-30-report-strong-economic-numbers-amid-another-gas-price-rise/ar-AA16LBrp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/the-hill-s-12-30-report-strong-economic-numbers-amid-another-gas-price-rise/ar-AA16LBrp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.973362+00:00
 - user: None



## Louisiana man sentenced to 45 years in prison for Grindr kidnapping scheme
 - [http://www.msn.com/en-us/news/us/louisiana-man-sentenced-to-45-years-in-prison-for-grindr-kidnapping-scheme/ar-AA16Mipo?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/louisiana-man-sentenced-to-45-years-in-prison-for-grindr-kidnapping-scheme/ar-AA16Mipo?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.966339+00:00
 - user: None



## Justice Department disrupts group behind thousands of ransomware attacks
 - [http://www.msn.com/en-us/news/politics/justice-department-disrupts-group-behind-thousands-of-ransomware-attacks/ar-AA16LUu6?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/justice-department-disrupts-group-behind-thousands-of-ransomware-attacks/ar-AA16LUu6?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 17:56:48.959051+00:00
 - user: None



## Republican lawmaker calls out TikTok's efforts to lobby Washington: 'Afraid of offending their overlords'
 - [http://www.msn.com/en-us/news/politics/republican-lawmaker-calls-out-tiktok-s-efforts-to-lobby-washington-afraid-of-offending-their-overlords/ar-AA16LGZL?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republican-lawmaker-calls-out-tiktok-s-efforts-to-lobby-washington-afraid-of-offending-their-overlords/ar-AA16LGZL?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.089082+00:00
 - user: None



## Who Is Henry Tenon? Man Arrested in Connection with Jared Bridegan Murder
 - [http://www.msn.com/en-us/news/crime/who-is-henry-tenon-man-arrested-in-connection-with-jared-bridegan-murder/ar-AA16M0BA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/who-is-henry-tenon-man-arrested-in-connection-with-jared-bridegan-murder/ar-AA16M0BA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.080405+00:00
 - user: None



## Intel chief stonewalls Congress on Biden and Trump documents
 - [http://www.msn.com/en-us/news/politics/intel-chief-stonewalls-congress-on-biden-and-trump-documents/ar-AA16LWJq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/intel-chief-stonewalls-congress-on-biden-and-trump-documents/ar-AA16LWJq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.072128+00:00
 - user: None



## Burned, Beaten 7-Year-Old Boy Dies After One Week in Coma, and Father is Arrested
 - [http://www.msn.com/en-us/news/crime/burned-beaten-7-year-old-boy-dies-after-one-week-in-coma-and-father-is-arrested/ar-AA16LZmZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/burned-beaten-7-year-old-boy-dies-after-one-week-in-coma-and-father-is-arrested/ar-AA16LZmZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.064444+00:00
 - user: None



## Turkey, Finland and Sweden: Strategic patience, but with a deadline
 - [http://www.msn.com/en-us/news/world/turkey-finland-and-sweden-strategic-patience-but-with-a-deadline/ar-AA16M33z?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/turkey-finland-and-sweden-strategic-patience-but-with-a-deadline/ar-AA16M33z?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.056822+00:00
 - user: None



## U.S. to send Ukraine more advanced Abrams tanks — but no secret armor
 - [http://www.msn.com/en-us/news/world/u-s-to-send-ukraine-more-advanced-abrams-tanks-but-no-secret-armor/ar-AA16McR4?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/u-s-to-send-ukraine-more-advanced-abrams-tanks-but-no-secret-armor/ar-AA16McR4?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.048234+00:00
 - user: None



## Colorado bear takes hundreds of 'selfies' on wildlife camera trap
 - [http://www.msn.com/en-us/news/us/colorado-bear-takes-hundreds-of-selfies-on-wildlife-camera-trap/ar-AA16LH29?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/colorado-bear-takes-hundreds-of-selfies-on-wildlife-camera-trap/ar-AA16LH29?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.038995+00:00
 - user: None



## Major funders call for increased support of Black feminists
 - [http://www.msn.com/en-us/news/us/major-funders-call-for-increased-support-of-black-feminists/ar-AA16M7YD?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/major-funders-call-for-increased-support-of-black-feminists/ar-AA16M7YD?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 16:56:59.029103+00:00
 - user: None



## Abortion front and center in Wisconsin Supreme Court race
 - [http://www.msn.com/en-us/news/politics/abortion-front-and-center-in-wisconsin-supreme-court-race/ar-AA16LOGb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/abortion-front-and-center-in-wisconsin-supreme-court-race/ar-AA16LOGb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.756162+00:00
 - user: None



## Former Fox News employee sues over sexual abuse under New York state survivors law
 - [http://www.msn.com/en-us/news/us/former-fox-news-employee-sues-over-sexual-abuse-under-new-york-state-survivors-law/ar-AA16LZWt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/former-fox-news-employee-sues-over-sexual-abuse-under-new-york-state-survivors-law/ar-AA16LZWt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.748287+00:00
 - user: None



## Billions of political text messages were sent last year — and there's little to stop more from coming
 - [http://www.msn.com/en-us/news/politics/billions-of-political-text-messages-were-sent-last-year-and-there-s-little-to-stop-more-from-coming/ar-AA16LMiv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/billions-of-political-text-messages-were-sent-last-year-and-there-s-little-to-stop-more-from-coming/ar-AA16LMiv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.739574+00:00
 - user: None



## US can’t afford to dawdle on investing in space-based solar power
 - [http://www.msn.com/en-us/news/technology/us-can-t-afford-to-dawdle-on-investing-in-space-based-solar-power/ar-AA16LMdM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/us-can-t-afford-to-dawdle-on-investing-in-space-based-solar-power/ar-AA16LMdM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.732138+00:00
 - user: None



## Your Wi-Fi Passwords Are Hidden on Your Mac and Windows. Here's How to Find Them
 - [http://www.msn.com/en-us/news/technology/your-wi-fi-passwords-are-hidden-on-your-mac-and-windows-here-s-how-to-find-them/ar-AAUcXnM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/your-wi-fi-passwords-are-hidden-on-your-mac-and-windows-here-s-how-to-find-them/ar-AAUcXnM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.724736+00:00
 - user: None



## Treasury imposes sanctions against Russian paramilitary firm Wagner Group
 - [http://www.msn.com/en-us/news/world/treasury-imposes-sanctions-against-russian-paramilitary-firm-wagner-group/ar-AA16LVZa?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/treasury-imposes-sanctions-against-russian-paramilitary-firm-wagner-group/ar-AA16LVZa?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.717329+00:00
 - user: None



## Schiff kicks off California Senate bid
 - [http://www.msn.com/en-us/news/politics/schiff-kicks-off-california-senate-bid/ar-AA16M2uv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schiff-kicks-off-california-senate-bid/ar-AA16M2uv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.708570+00:00
 - user: None



## Monterey Park shooting suspect had no known connection to victims, police say
 - [http://www.msn.com/en-us/news/crime/monterey-park-shooting-suspect-had-no-known-connection-to-victims-police-say/ar-AA16L1Nw?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/monterey-park-shooting-suspect-had-no-known-connection-to-victims-police-say/ar-AA16L1Nw?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:56:54.700827+00:00
 - user: None



## Putin’s Former Speechwriter Predicts Military Coup in Russia
 - [http://www.msn.com/en-us/news/world/putin-s-former-speechwriter-predicts-military-coup-in-russia/ar-AA16LGbZ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/putin-s-former-speechwriter-predicts-military-coup-in-russia/ar-AA16LGbZ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.746673+00:00
 - user: None



## Ukraine War Live Updates: Several Regions Report Power Outages Amid Russian Strikes
 - [http://www.msn.com/en-us/news/world/ukraine-war-live-updates-several-regions-report-power-outages-amid-russian-strikes/ar-AA16LE5q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-war-live-updates-several-regions-report-power-outages-amid-russian-strikes/ar-AA16LE5q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.739002+00:00
 - user: None



## Nikole Hannah-Jones retells 'The 1619 Project' amid race education pushback
 - [http://www.msn.com/en-us/news/us/nikole-hannah-jones-retells-the-1619-project-amid-race-education-pushback/ar-AA16LmzA?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nikole-hannah-jones-retells-the-1619-project-amid-race-education-pushback/ar-AA16LmzA?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.731690+00:00
 - user: None



## Blinken will travel to Mideast amid US concern over violence
 - [http://www.msn.com/en-us/news/world/blinken-will-travel-to-mideast-amid-us-concern-over-violence/ar-AA16LAF9?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/blinken-will-travel-to-mideast-amid-us-concern-over-violence/ar-AA16LAF9?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.723103+00:00
 - user: None



## Nick Clegg led Meta's decision to reinstate Trump to Facebook and Instagram. Here's how the former UK deputy prime minister charmed his way into Mark Zuckerberg's inner circle.
 - [http://www.msn.com/en-us/news/world/nick-clegg-led-meta-s-decision-to-reinstate-trump-to-facebook-and-instagram-here-s-how-the-former-uk-deputy-prime-minister-charmed-his-way-into-mark-zuckerberg-s-inner-circle/ar-AA16LwUl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nick-clegg-led-meta-s-decision-to-reinstate-trump-to-facebook-and-instagram-here-s-how-the-former-uk-deputy-prime-minister-charmed-his-way-into-mark-zuckerberg-s-inner-circle/ar-AA16LwUl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.715023+00:00
 - user: None



## Judge orders video of attack on Paul Pelosi to be released
 - [http://www.msn.com/en-us/news/politics/judge-orders-video-of-attack-on-paul-pelosi-to-be-released/ar-AA16LGi0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/judge-orders-video-of-attack-on-paul-pelosi-to-be-released/ar-AA16LGi0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.707266+00:00
 - user: None



## New 'Hook' malware allows hijacking, real-time spying on Android devices
 - [http://www.msn.com/en-us/news/technology/new-hook-malware-allows-hijacking-real-time-spying-on-android-devices/ar-AA16LXRu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/new-hook-malware-allows-hijacking-real-time-spying-on-android-devices/ar-AA16LXRu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 15:30:53.699489+00:00
 - user: None



## Razer Edge Game Handheld Is Here: Should You Buy One?
 - [http://www.msn.com/en-us/news/technology/razer-edge-game-handheld-is-here-should-you-buy-one/ar-AA1613eS?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/razer-edge-game-handheld-is-here-should-you-buy-one/ar-AA1613eS?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.344854+00:00
 - user: None



## A police chief was arrested and charged with dealing meth and cocaine
 - [http://www.msn.com/en-us/news/crime/a-police-chief-was-arrested-and-charged-with-dealing-meth-and-cocaine/ar-AA16LNvz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-police-chief-was-arrested-and-charged-with-dealing-meth-and-cocaine/ar-AA16LNvz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.337321+00:00
 - user: None



## Jeremy Renner was trying to stop snowplow from hitting nephew when he was crushed, officials say
 - [http://www.msn.com/en-us/news/us/jeremy-renner-was-trying-to-stop-snowplow-from-hitting-nephew-when-he-was-crushed-officials-say/ar-AA16Lzc0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jeremy-renner-was-trying-to-stop-snowplow-from-hitting-nephew-when-he-was-crushed-officials-say/ar-AA16Lzc0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.329896+00:00
 - user: None



## Horrific details uncovered in opening statements of South Carolina attorney's murder trial
 - [http://www.msn.com/en-us/news/crime/horrific-details-uncovered-in-opening-statements-of-south-carolina-attorney-s-murder-trial/ar-AA16LIBN?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/horrific-details-uncovered-in-opening-statements-of-south-carolina-attorney-s-murder-trial/ar-AA16LIBN?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.321700+00:00
 - user: None



## Germany apologizes for leopard jibe that upset some Africans
 - [http://www.msn.com/en-us/news/world/germany-apologizes-for-leopard-jibe-that-upset-some-africans/ar-AA16LNm8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-apologizes-for-leopard-jibe-that-upset-some-africans/ar-AA16LNm8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.312428+00:00
 - user: None



## 'War scares us stiff': Germany's reluctance to arm Ukraine is rooted in its bloodstained past
 - [http://www.msn.com/en-us/news/world/war-scares-us-stiff-germany-s-reluctance-to-arm-ukraine-is-rooted-in-its-bloodstained-past/ar-AA16LDGp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/war-scares-us-stiff-germany-s-reluctance-to-arm-ukraine-is-rooted-in-its-bloodstained-past/ar-AA16LDGp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.304300+00:00
 - user: None



## To defeat China, America needs an industrial policy
 - [http://www.msn.com/en-us/news/politics/to-defeat-china-america-needs-an-industrial-policy/ar-AA16LLhc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/to-defeat-china-america-needs-an-industrial-policy/ar-AA16LLhc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.296400+00:00
 - user: None



## 9 Palestinians killed after Israel storms West Bank refugee camp
 - [http://www.msn.com/en-us/news/world/9-palestinians-killed-after-israel-storms-west-bank-refugee-camp/ar-AA16LfNu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/9-palestinians-killed-after-israel-storms-west-bank-refugee-camp/ar-AA16LfNu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 14:30:41.286836+00:00
 - user: None



## Top GOP lawmaker questions why Biden ‘dithered’ over tank approval
 - [http://www.msn.com/en-us/news/politics/top-gop-lawmaker-questions-why-biden-dithered-over-tank-approval/ar-AA16LqMz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/top-gop-lawmaker-questions-why-biden-dithered-over-tank-approval/ar-AA16LqMz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.936711+00:00
 - user: None



## Paul Pelosi attack video ordered to be released by California judge
 - [http://www.msn.com/en-us/news/crime/paul-pelosi-attack-video-ordered-to-be-released-by-california-judge/ar-AA16LxNi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/paul-pelosi-attack-video-ordered-to-be-released-by-california-judge/ar-AA16LxNi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.912129+00:00
 - user: None



## Jury deliberating in deadly New York City truck terror attack
 - [http://www.msn.com/en-us/news/us/jury-deliberating-in-deadly-new-york-city-truck-terror-attack/ar-AA16LxLg?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jury-deliberating-in-deadly-new-york-city-truck-terror-attack/ar-AA16LxLg?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.904302+00:00
 - user: None



## Teacher to face daily fine for court order breaches
 - [http://www.msn.com/en-us/news/world/teacher-to-face-daily-fine-for-court-order-breaches/ar-AA16LHPK?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/teacher-to-face-daily-fine-for-court-order-breaches/ar-AA16LHPK?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.892807+00:00
 - user: None



## Ukraine Lion Rescued From Russian Shelling in 'Severe' Condition
 - [http://www.msn.com/en-us/news/world/ukraine-lion-rescued-from-russian-shelling-in-severe-condition/ar-AA16LKyJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/ukraine-lion-rescued-from-russian-shelling-in-severe-condition/ar-AA16LKyJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.884763+00:00
 - user: None



## JFK’s New Terminal One to host New York City’s largest rooftop solar array
 - [http://www.msn.com/en-us/news/us/jfk-s-new-terminal-one-to-host-new-york-city-s-largest-rooftop-solar-array/ar-AA16LFqY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jfk-s-new-terminal-one-to-host-new-york-city-s-largest-rooftop-solar-array/ar-AA16LFqY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.877010+00:00
 - user: None



## Boarding school ignored teen’s sickness complaints before she died, ex-staff say
 - [http://www.msn.com/en-us/news/us/boarding-school-ignored-teen-s-sickness-complaints-before-she-died-ex-staff-say/ar-AA16KWBm?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/boarding-school-ignored-teen-s-sickness-complaints-before-she-died-ex-staff-say/ar-AA16KWBm?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.869139+00:00
 - user: None



## Battles continue over who will lead California Assembly as Democrats jockey for power
 - [http://www.msn.com/en-us/news/politics/battles-continue-over-who-will-lead-california-assembly-as-democrats-jockey-for-power/ar-AA16LFr8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/battles-continue-over-who-will-lead-california-assembly-as-democrats-jockey-for-power/ar-AA16LFr8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 13:30:43.860430+00:00
 - user: None



## NASA spotted a rock formation on Mars that looks just like a giant bear face
 - [http://www.msn.com/en-us/news/technology/nasa-spotted-a-rock-formation-on-mars-that-looks-just-like-a-giant-bear-face/ar-AA16Lluz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/nasa-spotted-a-rock-formation-on-mars-that-looks-just-like-a-giant-bear-face/ar-AA16Lluz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.715995+00:00
 - user: None



## An asteroid will come extremely close to Earth on Thursday — but will miss us
 - [http://www.msn.com/en-us/news/technology/an-asteroid-will-come-extremely-close-to-earth-on-thursday-but-will-miss-us/ar-AA16Lssq?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/an-asteroid-will-come-extremely-close-to-earth-on-thursday-but-will-miss-us/ar-AA16Lssq?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.708043+00:00
 - user: None



## Shakira, Gerard Pique Drama Timeline Amid Clara Chia Marti Pic Controversy
 - [http://www.msn.com/en-us/news/world/shakira-gerard-pique-drama-timeline-amid-clara-chia-marti-pic-controversy/ar-AA16LlAU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/shakira-gerard-pique-drama-timeline-amid-clara-chia-marti-pic-controversy/ar-AA16LlAU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.700669+00:00
 - user: None



## Asian Americans are reeling from California’s back-to-back mass shootings
 - [http://www.msn.com/en-us/news/us/asian-americans-are-reeling-from-california-s-back-to-back-mass-shootings/ar-AA16LhrE?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/asian-americans-are-reeling-from-california-s-back-to-back-mass-shootings/ar-AA16LhrE?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.689690+00:00
 - user: None



## All the (Ukrainian) president’s men
 - [http://www.msn.com/en-us/news/politics/all-the-ukrainian-president-s-men/ar-AA16LlA1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/all-the-ukrainian-president-s-men/ar-AA16LlA1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.681697+00:00
 - user: None



## Republicans demand spending cuts to lift the debt limit. They won't say what to cut.
 - [http://www.msn.com/en-us/news/politics/republicans-demand-spending-cuts-to-lift-the-debt-limit-they-won-t-say-what-to-cut/ar-AA16L1Ne?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/republicans-demand-spending-cuts-to-lift-the-debt-limit-they-won-t-say-what-to-cut/ar-AA16L1Ne?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.674084+00:00
 - user: None



## Nobel laureate wants more to help probe Russian war crimes
 - [http://www.msn.com/en-us/news/world/nobel-laureate-wants-more-to-help-probe-russian-war-crimes/ar-AA16LxqM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/nobel-laureate-wants-more-to-help-probe-russian-war-crimes/ar-AA16LxqM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 12:30:39.665445+00:00
 - user: None



## Court shuts down Russia's oldest human rights organization
 - [http://www.msn.com/en-us/news/world/court-shuts-down-russia-s-oldest-human-rights-organization/ar-AA16KMb0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/court-shuts-down-russia-s-oldest-human-rights-organization/ar-AA16KMb0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.810331+00:00
 - user: None



## VA says it exceeded goal for housing homeless veterans last year
 - [http://www.msn.com/en-us/news/us/va-says-it-exceeded-goal-for-housing-homeless-veterans-last-year/ar-AA16LdVJ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/va-says-it-exceeded-goal-for-housing-homeless-veterans-last-year/ar-AA16LdVJ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.801719+00:00
 - user: None



## FAA lacks leadership amid key challenges
 - [http://www.msn.com/en-us/news/politics/faa-lacks-leadership-amid-key-challenges/ar-AA16L1hs?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/faa-lacks-leadership-amid-key-challenges/ar-AA16L1hs?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.793926+00:00
 - user: None



## Letters to the Editor: L.A.'s scandal-plagued 'Eastside politicos' also transformed California
 - [http://www.msn.com/en-us/news/us/letters-to-the-editor-l-a-s-scandal-plagued-eastside-politicos-also-transformed-california/ar-AA16L6Ve?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/letters-to-the-editor-l-a-s-scandal-plagued-eastside-politicos-also-transformed-california/ar-AA16L6Ve?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.786335+00:00
 - user: None



## Djokovic’s Dad Poses With Pro-Putin Spectators at Australian Open
 - [http://www.msn.com/en-us/news/world/djokovic-s-dad-poses-with-pro-putin-spectators-at-australian-open/ar-AA16LjxP?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/djokovic-s-dad-poses-with-pro-putin-spectators-at-australian-open/ar-AA16LjxP?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.778869+00:00
 - user: None



## Germany: Victims of fatal train attack identified as 2 teens
 - [http://www.msn.com/en-us/news/world/germany-victims-of-fatal-train-attack-identified-as-2-teens/ar-AA16L9f1?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/germany-victims-of-fatal-train-attack-identified-as-2-teens/ar-AA16L9f1?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.771499+00:00
 - user: None



## Why do people buy crackpot conspiracy theories?
 - [http://www.msn.com/en-us/news/technology/why-do-people-buy-crackpot-conspiracy-theories/ar-AA16KVX2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/why-do-people-buy-crackpot-conspiracy-theories/ar-AA16KVX2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.763530+00:00
 - user: None



## What ‘conservation’ means to Rep. Gabe Vasquez
 - [http://www.msn.com/en-us/news/politics/what-conservation-means-to-rep-gabe-vasquez/ar-AA16Le8F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/what-conservation-means-to-rep-gabe-vasquez/ar-AA16Le8F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 11:30:37.754853+00:00
 - user: None



## Cara Kernodle Feels 'Betrayed' Over Her Lawyer Representing Bryan Kohberger
 - [http://www.msn.com/en-us/news/crime/cara-kernodle-feels-betrayed-over-her-lawyer-representing-bryan-kohberger/ar-AA16Li9r?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/cara-kernodle-feels-betrayed-over-her-lawyer-representing-bryan-kohberger/ar-AA16Li9r?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.322008+00:00
 - user: None



## Consul: 20% of Americans in Hong Kong left in past 2 years
 - [http://www.msn.com/en-us/news/world/consul-20-of-americans-in-hong-kong-left-in-past-2-years/ar-AA16LhYC?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/consul-20-of-americans-in-hong-kong-left-in-past-2-years/ar-AA16LhYC?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.313389+00:00
 - user: None



## Inside the George Santos Campaign Report Blame Game
 - [http://www.msn.com/en-us/news/politics/inside-the-george-santos-campaign-report-blame-game/ar-AA16L3yF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/inside-the-george-santos-campaign-report-blame-game/ar-AA16L3yF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.305486+00:00
 - user: None



## Palestinians say 9 killed by Israeli army in raid
 - [http://www.msn.com/en-us/news/world/palestinians-say-9-killed-by-israeli-army-in-raid/ar-AA16L65I?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/palestinians-say-9-killed-by-israeli-army-in-raid/ar-AA16L65I?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.296047+00:00
 - user: None



## NYPD commissioner reveals plans for smartphone app, new cameras
 - [http://www.msn.com/en-us/news/us/nypd-commissioner-reveals-plans-for-smartphone-app-new-cameras/ar-AA16L3z0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nypd-commissioner-reveals-plans-for-smartphone-app-new-cameras/ar-AA16L3z0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.288457+00:00
 - user: None



## Biden to warn House GOP poses threat to economy
 - [http://www.msn.com/en-us/news/politics/biden-to-warn-house-gop-poses-threat-to-economy/ar-AA16Lkie?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-to-warn-house-gop-poses-threat-to-economy/ar-AA16Lkie?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.281065+00:00
 - user: None



## Sen. Rick Scott is running for re-election pushing his controversial tax plan
 - [http://www.msn.com/en-us/news/politics/sen-rick-scott-is-running-for-re-election-pushing-his-controversial-tax-plan/ar-AA16LbBl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/sen-rick-scott-is-running-for-re-election-pushing-his-controversial-tax-plan/ar-AA16LbBl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.272796+00:00
 - user: None



## 8 Palestinians killed after Israel storms West Bank refugee camp
 - [http://www.msn.com/en-us/news/world/8-palestinians-killed-after-israel-storms-west-bank-refugee-camp/ar-AA16LfNu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/8-palestinians-killed-after-israel-storms-west-bank-refugee-camp/ar-AA16LfNu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 10:30:37.264344+00:00
 - user: None



## Amazon Workers in U.K. Walk Out Over Pay, Union Vows to Extend Strike
 - [http://www.msn.com/en-us/money/other/amazon-workers-in-u-k-walk-out-over-pay-union-vows-to-extend-strike/vi-AA16L5qc?srcref=rss](http://www.msn.com/en-us/money/other/amazon-workers-in-u-k-walk-out-over-pay-union-vows-to-extend-strike/vi-AA16L5qc?srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.813849+00:00
 - user: None



## Plane Crashes into Airport Roof During Takeoff Accident—Video
 - [http://www.msn.com/en-us/news/world/plane-crashes-into-airport-roof-during-takeoff-accident-video/ar-AA16L5tk?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/plane-crashes-into-airport-roof-during-takeoff-accident-video/ar-AA16L5tk?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.804226+00:00
 - user: None



## Elaine Chao, Trump-era transportation secretary and Mitch McConnell's wife, hits back at Trump for giving her the racist nickname 'Coco Chow'
 - [http://www.msn.com/en-us/news/politics/elaine-chao-trump-era-transportation-secretary-and-mitch-mcconnell-s-wife-hits-back-at-trump-for-giving-her-the-racist-nickname-coco-chow/ar-AA16KYHi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/elaine-chao-trump-era-transportation-secretary-and-mitch-mcconnell-s-wife-hits-back-at-trump-for-giving-her-the-racist-nickname-coco-chow/ar-AA16KYHi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.796490+00:00
 - user: None



## Four Palestinians killed in Israeli raid in Jenin
 - [http://www.msn.com/en-us/news/world/four-palestinians-killed-in-israeli-raid-in-jenin/ar-AA16KYWp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/four-palestinians-killed-in-israeli-raid-in-jenin/ar-AA16KYWp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.787685+00:00
 - user: None



## 5 officers fired after Tyre Nichols' death were 'directly responsible' for his 'physical abuse,' police chief says
 - [http://www.msn.com/en-us/news/us/5-officers-fired-after-tyre-nichols-death-were-directly-responsible-for-his-physical-abuse-police-chief-says/ar-AA16L81R?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/5-officers-fired-after-tyre-nichols-death-were-directly-responsible-for-his-physical-abuse-police-chief-says/ar-AA16L81R?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.779990+00:00
 - user: None



## New queen takes the throne in epic historical fantasy
 - [http://www.msn.com/en-us/news/world/new-queen-takes-the-throne-in-epic-historical-fantasy/ar-AA16KVdU?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/new-queen-takes-the-throne-in-epic-historical-fantasy/ar-AA16KVdU?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.771753+00:00
 - user: None



## Japan launches intel satellite to watch N. Korea, disasters
 - [http://www.msn.com/en-us/news/world/japan-launches-intel-satellite-to-watch-n-korea-disasters/ar-AA16KZ9g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/japan-launches-intel-satellite-to-watch-n-korea-disasters/ar-AA16KZ9g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 09:30:37.763236+00:00
 - user: None



## North Carolina police officer saved after body camera stops bullet shot at her
 - [http://www.msn.com/en-us/news/crime/north-carolina-police-officer-saved-after-body-camera-stops-bullet-shot-at-her/ar-AA16KEqM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/north-carolina-police-officer-saved-after-body-camera-stops-bullet-shot-at-her/ar-AA16KEqM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 08:30:35.139740+00:00
 - user: None



## Populist billionaire vies with ex-general for top Czech post
 - [http://www.msn.com/en-us/news/world/populist-billionaire-vies-with-ex-general-for-top-czech-post/ar-AA16KSBX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/populist-billionaire-vies-with-ex-general-for-top-czech-post/ar-AA16KSBX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 08:30:35.131355+00:00
 - user: None



## Royal Mail says strikes have cost it £200m
 - [http://www.msn.com/en-us/news/world/royal-mail-says-strikes-have-cost-it-200m/ar-AA16KSKG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/royal-mail-says-strikes-have-cost-it-200m/ar-AA16KSKG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 08:30:35.122254+00:00
 - user: None



## Authorities find no link between Monterey Park mass shooting suspect and victims
 - [http://www.msn.com/en-us/news/crime/authorities-find-no-link-between-monterey-park-mass-shooting-suspect-and-victims/ar-AA16KPKv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/authorities-find-no-link-between-monterey-park-mass-shooting-suspect-and-victims/ar-AA16KPKv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 07:30:35.897299+00:00
 - user: None



## 'They were just dancing': Mourners gather to remember Monterey Park victims
 - [http://www.msn.com/en-us/news/us/they-were-just-dancing-mourners-gather-to-remember-monterey-park-victims/ar-AA16KS2w?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/they-were-just-dancing-mourners-gather-to-remember-monterey-park-victims/ar-AA16KS2w?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 07:30:35.890016+00:00
 - user: None



## Russia, South Africa and a 'redesigned global order': The Kremlin's hearts and minds machine is steaming ahead
 - [http://www.msn.com/en-us/news/world/russia-south-africa-and-a-redesigned-global-order-the-kremlin-s-hearts-and-minds-machine-is-steaming-ahead/ar-AA16KXs8?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-south-africa-and-a-redesigned-global-order-the-kremlin-s-hearts-and-minds-machine-is-steaming-ahead/ar-AA16KXs8?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 07:30:35.881767+00:00
 - user: None



## Russia-Ukraine live updates: Germany to send tanks to Ukraine
 - [http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-germany-to-send-tanks-to-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/russia-ukraine-live-updates-germany-to-send-tanks-to-ukraine/ar-AA11dhnl?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 07:30:35.873449+00:00
 - user: None



## Sirens across Ukraine as authorities report Russian attacks
 - [http://www.msn.com/en-us/news/world/sirens-across-ukraine-as-authorities-report-russian-attacks/ar-AA16KE9x?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/sirens-across-ukraine-as-authorities-report-russian-attacks/ar-AA16KE9x?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 07:30:35.865829+00:00
 - user: None



## Kari Lake dismisses Senate speculation as she says she plans to fight on to win lawsuit
 - [http://www.msn.com/en-us/news/politics/kari-lake-dismisses-senate-speculation-as-she-says-she-plans-to-fight-on-to-win-lawsuit/ar-AA16Kz5e?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/kari-lake-dismisses-senate-speculation-as-she-says-she-plans-to-fight-on-to-win-lawsuit/ar-AA16Kz5e?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 06:30:37.635897+00:00
 - user: None



## Trump's Facebook, Instagram Reinstatements Denounced as Win for 'Extremism'
 - [http://www.msn.com/en-us/news/politics/trump-s-facebook-instagram-reinstatements-denounced-as-win-for-extremism/ar-AA16KPts?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/trump-s-facebook-instagram-reinstatements-denounced-as-win-for-extremism/ar-AA16KPts?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 06:30:37.625811+00:00
 - user: None



## World Champion Roping Horse with the 'Fluffiest' Ears Dies Alongside Another Horse in California Barn Fire
 - [http://www.msn.com/en-us/news/us/world-champion-roping-horse-with-the-fluffiest-ears-dies-alongside-another-horse-in-california-barn-fire/ar-AA16KRRT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/world-champion-roping-horse-with-the-fluffiest-ears-dies-alongside-another-horse-in-california-barn-fire/ar-AA16KRRT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 06:30:37.616676+00:00
 - user: None



## Black box from Nepal plane crash to be sent to Singapore
 - [http://www.msn.com/en-us/news/world/black-box-from-nepal-plane-crash-to-be-sent-to-singapore/ar-AA16KGWb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/black-box-from-nepal-plane-crash-to-be-sent-to-singapore/ar-AA16KGWb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 06:30:37.607975+00:00
 - user: None



## Teacher admits helping students change their gender identity without their parents' knowledge
 - [http://www.msn.com/en-us/news/us/teacher-admits-helping-students-change-their-gender-identity-without-their-parents-knowledge/ar-AA16KMN3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/teacher-admits-helping-students-change-their-gender-identity-without-their-parents-knowledge/ar-AA16KMN3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:34.019889+00:00
 - user: None



## US bans former president of Panama over 'significant corruption'
 - [http://www.msn.com/en-us/news/world/us-bans-former-president-of-panama-over-significant-corruption/ar-AA16KbED?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/us-bans-former-president-of-panama-over-significant-corruption/ar-AA16KbED?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:34.010665+00:00
 - user: None



## War with Russia rages as Ukraine’s government confronts an old enemy: Corruption
 - [http://www.msn.com/en-us/news/world/war-with-russia-rages-as-ukraine-s-government-confronts-an-old-enemy-corruption/ar-AA16KBkp?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/war-with-russia-rages-as-ukraine-s-government-confronts-an-old-enemy-corruption/ar-AA16KBkp?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:34.003111+00:00
 - user: None



## Zelensky urges speedy delivery of Western tanks
 - [http://www.msn.com/en-us/news/world/zelensky-urges-speedy-delivery-of-western-tanks/ar-AA16KylY?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/zelensky-urges-speedy-delivery-of-western-tanks/ar-AA16KylY?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:33.994158+00:00
 - user: None



## RNC challenger not ready to concede to McDaniel
 - [http://www.msn.com/en-us/news/politics/rnc-challenger-not-ready-to-concede-to-mcdaniel/ar-AA16KDkF?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/rnc-challenger-not-ready-to-concede-to-mcdaniel/ar-AA16KDkF?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:33.984686+00:00
 - user: None



## Feds Say Romance Scammer Named Peaches Left Holocaust Survivor Broke
 - [http://www.msn.com/en-us/news/crime/feds-say-romance-scammer-named-peaches-left-holocaust-survivor-broke/ar-AA16Km9L?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/feds-say-romance-scammer-named-peaches-left-holocaust-survivor-broke/ar-AA16Km9L?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:33.974721+00:00
 - user: None



## Australia Day focuses on Black recognition in constitution
 - [http://www.msn.com/en-us/news/world/australia-day-focuses-on-black-recognition-in-constitution/ar-AA16KbQ3?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/australia-day-focuses-on-black-recognition-in-constitution/ar-AA16KbQ3?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 05:30:33.966471+00:00
 - user: None



## Everything Trump Has Said About Elaine Chao as She Finally Fires Back
 - [http://www.msn.com/en-us/news/politics/everything-trump-has-said-about-elaine-chao-as-she-finally-fires-back/ar-AA16KIbu?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/everything-trump-has-said-about-elaine-chao-as-she-finally-fires-back/ar-AA16KIbu?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.900356+00:00
 - user: None



## Classified documents found at Pence residence included briefings for foreign trips: Report
 - [http://www.msn.com/en-us/news/us/classified-documents-found-at-pence-residence-included-briefings-for-foreign-trips-report/ar-AA16KgEt?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/classified-documents-found-at-pence-residence-included-briefings-for-foreign-trips-report/ar-AA16KgEt?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.887120+00:00
 - user: None



## DOJ says Louisiana prisons hold inmates beyond their release dates
 - [http://www.msn.com/en-us/news/us/doj-says-louisiana-prisons-hold-inmates-beyond-their-release-dates/ar-AA16KoTc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/doj-says-louisiana-prisons-hold-inmates-beyond-their-release-dates/ar-AA16KoTc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.879288+00:00
 - user: None



## Half Moon Bay shooting suspect charged with 7 counts of murder allegedly felt 'disrespected'
 - [http://www.msn.com/en-us/news/crime/half-moon-bay-shooting-suspect-charged-with-7-counts-of-murder-allegedly-felt-disrespected/ar-AA16KrGc?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/half-moon-bay-shooting-suspect-charged-with-7-counts-of-murder-allegedly-felt-disrespected/ar-AA16KrGc?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.871003+00:00
 - user: None



## Report: Myanmar opium cultivation surges 33% amid violence
 - [http://www.msn.com/en-us/news/world/report-myanmar-opium-cultivation-surges-33-amid-violence/ar-AA16KJQM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/report-myanmar-opium-cultivation-surges-33-amid-violence/ar-AA16KJQM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.863009+00:00
 - user: None



## PETE HEGSETH: They have no right to be on the intel committee
 - [http://www.msn.com/en-us/news/politics/pete-hegseth-they-have-no-right-to-be-on-the-intel-committee/ar-AA16KD8W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pete-hegseth-they-have-no-right-to-be-on-the-intel-committee/ar-AA16KD8W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 04:30:32.853835+00:00
 - user: None



## DNC members fire back over New Hampshire's complaints about primary changes
 - [http://www.msn.com/en-us/news/politics/dnc-members-fire-back-over-new-hampshire-s-complaints-about-primary-changes/ar-AA16Koja?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/dnc-members-fire-back-over-new-hampshire-s-complaints-about-primary-changes/ar-AA16Koja?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.966613+00:00
 - user: None



## Schiff blasts Facebook for ending Trump’s suspension: ‘tragic decision’
 - [http://www.msn.com/en-us/news/politics/schiff-blasts-facebook-for-ending-trump-s-suspension-tragic-decision/ar-AA16Krb0?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schiff-blasts-facebook-for-ending-trump-s-suspension-tragic-decision/ar-AA16Krb0?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.958431+00:00
 - user: None



## A judge ordered the removal of a portrait of Alex Murdaugh's grandfather from the courtroom at the start of his trial on charges of murdering his wife and son
 - [http://www.msn.com/en-us/news/crime/a-judge-ordered-the-removal-of-a-portrait-of-alex-murdaugh-s-grandfather-from-the-courtroom-at-the-start-of-his-trial-on-charges-of-murdering-his-wife-and-son/ar-AA16KFhz?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/a-judge-ordered-the-removal-of-a-portrait-of-alex-murdaugh-s-grandfather-from-the-courtroom-at-the-start-of-his-trial-on-charges-of-murdering-his-wife-and-son/ar-AA16KFhz?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.950151+00:00
 - user: None



## Surfshark Passes First Independent No-Logs Audit
 - [http://www.msn.com/en-us/news/technology/surfshark-passes-first-independent-no-logs-audit/ar-AA16KlxV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/technology/surfshark-passes-first-independent-no-logs-audit/ar-AA16KlxV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.942740+00:00
 - user: None



## Students threaten to sue DeSantis over rejection of African American studies course
 - [http://www.msn.com/en-us/news/us/students-threaten-to-sue-desantis-over-rejection-of-african-american-studies-course/ar-AA16KxKM?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/students-threaten-to-sue-desantis-over-rejection-of-african-american-studies-course/ar-AA16KxKM?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.934984+00:00
 - user: None



## Schiff, Swalwell assert Trump, Russia influence in being booted from House Intel Committee
 - [http://www.msn.com/en-us/news/politics/schiff-swalwell-assert-trump-russia-influence-in-being-booted-from-house-intel-committee/ar-AA16Kos2?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/schiff-swalwell-assert-trump-russia-influence-in-being-booted-from-house-intel-committee/ar-AA16Kos2?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.926453+00:00
 - user: None



## Afghan soldier who sought asylum at US-Mexico border freed after months in detention
 - [http://www.msn.com/en-us/news/world/afghan-soldier-who-sought-asylum-at-us-mexico-border-freed-after-months-in-detention/ar-AA16Kgst?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/afghan-soldier-who-sought-asylum-at-us-mexico-border-freed-after-months-in-detention/ar-AA16Kgst?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.918200+00:00
 - user: None



## UN envoy hopes UN will OK force for Haiti to combat gangs
 - [http://www.msn.com/en-us/news/world/un-envoy-hopes-un-will-ok-force-for-haiti-to-combat-gangs/ar-AA16KHJQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/un-envoy-hopes-un-will-ok-force-for-haiti-to-combat-gangs/ar-AA16KHJQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 03:30:31.909499+00:00
 - user: None



## The West finally commits tanks to Ukraine. It took a lot of arm-twisting.
 - [http://www.msn.com/en-us/news/world/the-west-finally-commits-tanks-to-ukraine-it-took-a-lot-of-arm-twisting/ar-AA16KF2a?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/the-west-finally-commits-tanks-to-ukraine-it-took-a-lot-of-arm-twisting/ar-AA16KF2a?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.869610+00:00
 - user: None



## Manchin claims McCarthy said Social Security and Medicare cuts are off the table
 - [http://www.msn.com/en-us/news/politics/manchin-claims-mccarthy-said-social-security-and-medicare-cuts-are-off-the-table/ar-AA16KlkT?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/manchin-claims-mccarthy-said-social-security-and-medicare-cuts-are-off-the-table/ar-AA16KlkT?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.861398+00:00
 - user: None



## A 29-year-old woman was accused of enrolling at a New Jersey high school and spending 4 days in classes before anyone noticed
 - [http://www.msn.com/en-us/news/us/a-29-year-old-woman-was-accused-of-enrolling-at-a-new-jersey-high-school-and-spending-4-days-in-classes-before-anyone-noticed/ar-AA16Kxwi?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/a-29-year-old-woman-was-accused-of-enrolling-at-a-new-jersey-high-school-and-spending-4-days-in-classes-before-anyone-noticed/ar-AA16Kxwi?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.852543+00:00
 - user: None



## Pence special counsel ‘more likely than not,’ says former WH ethics lawyer
 - [http://www.msn.com/en-us/news/politics/pence-special-counsel-more-likely-than-not-says-former-wh-ethics-lawyer/ar-AA16KA7F?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/pence-special-counsel-more-likely-than-not-says-former-wh-ethics-lawyer/ar-AA16KA7F?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.844916+00:00
 - user: None



## JESSE WATTERS: This 'pay for play' scheme is right out in the open
 - [http://www.msn.com/en-us/news/us/jesse-watters-this-pay-for-play-scheme-is-right-out-in-the-open/ar-AA16KCxr?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/jesse-watters-this-pay-for-play-scheme-is-right-out-in-the-open/ar-AA16KCxr?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.837199+00:00
 - user: None



## How a Historic March Could Revive India's Opposition Movement
 - [http://www.msn.com/en-us/news/world/how-a-historic-march-could-revive-india-s-opposition-movement/ar-AA16KxBv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/how-a-historic-march-could-revive-india-s-opposition-movement/ar-AA16KxBv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.829140+00:00
 - user: None



## Teacher shot by 6-year-old texted a dire warning to a loved one before she was wounded, source says
 - [http://www.msn.com/en-us/news/us/teacher-shot-by-6-year-old-texted-a-dire-warning-to-a-loved-one-before-she-was-wounded-source-says/ar-AA16JrQV?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/teacher-shot-by-6-year-old-texted-a-dire-warning-to-a-loved-one-before-she-was-wounded-source-says/ar-AA16JrQV?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.821130+00:00
 - user: None



## Harris to visit Monterey Park to meet with victims' families
 - [http://www.msn.com/en-us/news/politics/harris-to-visit-monterey-park-to-meet-with-victims-families/ar-AA16JwgG?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/harris-to-visit-monterey-park-to-meet-with-victims-families/ar-AA16JwgG?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 02:30:30.812581+00:00
 - user: None



## Biden Has Never Been Under More Pressure From Congress to Ban TikTok
 - [http://www.msn.com/en-us/news/politics/biden-has-never-been-under-more-pressure-from-congress-to-ban-tiktok/ar-AA16KdeW?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/biden-has-never-been-under-more-pressure-from-congress-to-ban-tiktok/ar-AA16KdeW?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.065274+00:00
 - user: None



## 'Fist of freedom': Zelensky seeks ‘long-range missiles’ to pair with new tanks
 - [http://www.msn.com/en-us/news/world/fist-of-freedom-zelensky-seeks-long-range-missiles-to-pair-with-new-tanks/ar-AA16KBZX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/fist-of-freedom-zelensky-seeks-long-range-missiles-to-pair-with-new-tanks/ar-AA16KBZX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.057395+00:00
 - user: None



## Slain LSU Student Madison Brooks Remembered by Sorority as a 'Hero' That 'Made a Lasting Impact'
 - [http://www.msn.com/en-us/news/crime/slain-lsu-student-madison-brooks-remembered-by-sorority-as-a-hero-that-made-a-lasting-impact/ar-AA16KuAQ?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/slain-lsu-student-madison-brooks-remembered-by-sorority-as-a-hero-that-made-a-lasting-impact/ar-AA16KuAQ?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.049661+00:00
 - user: None



## Treasury tells Comer to wait on decision on possible Hunter Biden bank records
 - [http://www.msn.com/en-us/news/politics/treasury-tells-comer-to-wait-on-decision-on-possible-hunter-biden-bank-records/ar-AA16KC2l?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/treasury-tells-comer-to-wait-on-decision-on-possible-hunter-biden-bank-records/ar-AA16KC2l?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.040907+00:00
 - user: None



## Meta ends Trump's suspension on Facebook and Instagram while pledging 'new guardrails'
 - [http://www.msn.com/en-us/news/politics/meta-ends-trump-s-suspension-on-facebook-and-instagram-while-pledging-new-guardrails/ar-AA16K7XX?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/meta-ends-trump-s-suspension-on-facebook-and-instagram-while-pledging-new-guardrails/ar-AA16K7XX?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.033294+00:00
 - user: None



## Donald Trump allowed back on Facebook and Instagram, Meta announces
 - [http://www.msn.com/en-us/news/politics/donald-trump-allowed-back-on-facebook-and-instagram-meta-announces/ar-AA16JWmv?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/donald-trump-allowed-back-on-facebook-and-instagram-meta-announces/ar-AA16JWmv?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.023500+00:00
 - user: None



## Jury deliberations in NYC bike path killings hit early snag
 - [http://www.msn.com/en-us/news/crime/jury-deliberations-in-nyc-bike-path-killings-hit-early-snag/ar-AA16KxeO?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/jury-deliberations-in-nyc-bike-path-killings-hit-early-snag/ar-AA16KxeO?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.015720+00:00
 - user: None



## Here’s How Asian American Elders Are Fed Dangerous Lies
 - [http://www.msn.com/en-us/news/us/here-s-how-asian-american-elders-are-fed-dangerous-lies/ar-AA16KzA7?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/here-s-how-asian-american-elders-are-fed-dangerous-lies/ar-AA16KzA7?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 01:30:33.006625+00:00
 - user: None



## Virginia school board votes to replace embattled superintendent after 6-year-old boy shoots teacher
 - [http://www.msn.com/en-us/news/us/virginia-school-board-votes-to-replace-embattled-superintendent-after-6-year-old-boy-shoots-teacher/ar-AA16KdWb?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/virginia-school-board-votes-to-replace-embattled-superintendent-after-6-year-old-boy-shoots-teacher/ar-AA16KdWb?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:20.313511+00:00
 - user: None



## Is Mitch Daniels a good fit for the Senate? He’s trying to figure that out
 - [http://www.msn.com/en-us/news/politics/is-mitch-daniels-a-good-fit-for-the-senate-he-s-trying-to-figure-that-out/ar-AA16K8Uh?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/is-mitch-daniels-a-good-fit-for-the-senate-he-s-trying-to-figure-that-out/ar-AA16K8Uh?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:20.306285+00:00
 - user: None



## Meta to Restore Trump’s Facebook, Instagram Accounts After 2-year Ban
 - [http://www.msn.com/en-us/news/politics/meta-to-restore-trump-s-facebook-instagram-accounts-after-2-year-ban/ar-AA16Kase?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/politics/meta-to-restore-trump-s-facebook-instagram-accounts-after-2-year-ban/ar-AA16Kase?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:20.297844+00:00
 - user: None



## Nebraska university maintains ban on posters depicting guns: reports
 - [http://www.msn.com/en-us/news/us/nebraska-university-maintains-ban-on-posters-depicting-guns-reports/ar-AA16Ks2Q?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/us/nebraska-university-maintains-ban-on-posters-depicting-guns-reports/ar-AA16Ks2Q?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:19.159235+00:00
 - user: None



## Governor creates commission to study Arizona prison problems
 - [http://www.msn.com/en-us/news/crime/governor-creates-commission-to-study-arizona-prison-problems/ar-AA16KpWf?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/governor-creates-commission-to-study-arizona-prison-problems/ar-AA16KpWf?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:19.151566+00:00
 - user: None



## UK car production collapses to lowest for 66 years
 - [http://www.msn.com/en-us/news/world/uk-car-production-collapses-to-lowest-for-66-years/ar-AA16Ke3W?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/uk-car-production-collapses-to-lowest-for-66-years/ar-AA16Ke3W?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:19.144217+00:00
 - user: None



## Inside Washington’s about-face on sending tanks to Ukraine
 - [http://www.msn.com/en-us/news/world/inside-washington-s-about-face-on-sending-tanks-to-ukraine/ar-AA16K90g?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/world/inside-washington-s-about-face-on-sending-tanks-to-ukraine/ar-AA16K90g?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:19.136494+00:00
 - user: None



## Half Moon Bay shooting suspect charged with 7 counts of murder: DA
 - [http://www.msn.com/en-us/news/crime/half-moon-bay-shooting-suspect-charged-with-7-counts-of-murder-da/ar-AA16JD66?li=BBnbcA1&srcref=rss](http://www.msn.com/en-us/news/crime/half-moon-bay-shooting-suspect-charged-with-7-counts-of-murder-da/ar-AA16JD66?li=BBnbcA1&srcref=rss)
 - RSS feed: http://www.msn.com/rss/news.aspx
 - date published: 2023-01-26 00:22:17.997171+00:00
 - user: None


