# Source Forbs - innovation, Source URL:https://www.forbes.com/innovation/feed2, Source language: en-US

## The 12 Most Common Ways We Break Our Phones, According To AT&T
 - [https://www.forbes.com/sites/johnkoetsier/2023/01/26/the-12-most-common-ways-we-break-our-phones-according-to-att/](https://www.forbes.com/sites/johnkoetsier/2023/01/26/the-12-most-common-ways-we-break-our-phones-according-to-att/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:52:27+00:00
 - user: None

3% of people have had the misfortune of having their dog chew on their smartphones. And 5% have done what many of us only do in our dreams: throwing their phones in a fit of rage.

## Shinichiro Watanabe On Making ‘Cowboy Bebop’ And What He Thinks Of The Live-Action Adaptation
 - [https://www.forbes.com/sites/olliebarder/2023/01/26/shinichiro-watanabe-on-making-cowboy-bebop-and-what-he-thinks-of-the-live-action-adaptation/](https://www.forbes.com/sites/olliebarder/2023/01/26/shinichiro-watanabe-on-making-cowboy-bebop-and-what-he-thinks-of-the-live-action-adaptation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:37:04+00:00
 - user: None

One of the most successful directors of anime is that of Shinichiro Watanabe. Known for his work on the original and entirely peerless 'Cowboy Bebop', I was more than happy to catch up with him and discuss his long and eventful career.

## New Apple Leak Reveals Cutting-Edge iPhone 15 Feature
 - [https://www.forbes.com/sites/gordonkelly/2023/01/26/apple-iphone-15-pro-max-ultra-wifi-6e-standard-feature-upgrade/](https://www.forbes.com/sites/gordonkelly/2023/01/26/apple-iphone-15-pro-max-ultra-wifi-6e-standard-feature-upgrade/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:29:08+00:00
 - user: None

The iPhone 15 range is tipped to come with one future proof upgrade...

## New Samsung Leak Reveals Galaxy S23 Price Shock
 - [https://www.forbes.com/sites/gordonkelly/2023/01/26/samsung-galaxy-s23-plus-ultra-leaked-prices/](https://www.forbes.com/sites/gordonkelly/2023/01/26/samsung-galaxy-s23-plus-ultra-leaked-prices/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:24:21+00:00
 - user: None

Samsung's Galaxy S23 range will be up to $300 more expensive internationally...

## Laid Off Googlers Got More Severance Than Workers At Alphabet’s ‘Other Bets’ Like Waymo And Verily
 - [https://www.forbes.com/sites/richardnieva/2023/01/26/google-alphabet-verily-waymo-severance/](https://www.forbes.com/sites/richardnieva/2023/01/26/google-alphabet-verily-waymo-severance/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:11:16+00:00
 - user: None

Alphabet laid off more than 12,000 employees, giving Googlers a base of 16 weeks of severance. Other units got less.

## Tech Protagonist, Business Protagonist: Reinventing The Chief Information Officer
 - [https://www.forbes.com/sites/joemckendrick/2023/01/26/tech-protagonist-business-protagonist-reinventing-the-chief-information-officer/](https://www.forbes.com/sites/joemckendrick/2023/01/26/tech-protagonist-business-protagonist-reinventing-the-chief-information-officer/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 23:01:28+00:00
 - user: None

The CIO’s role now demands greater immersion, inspiration, and insight — into both technology and the business.

## A Beginner’s Guide To Pathfinder Second Edition
 - [https://www.forbes.com/sites/robwieland/2023/01/26/a-beginners-guide-to-pathfinder-second-edition/](https://www.forbes.com/sites/robwieland/2023/01/26/a-beginners-guide-to-pathfinder-second-edition/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 21:55:54+00:00
 - user: None

For many years, Pathfinder has presented itself as an alternative to Dungeons & Dragons. Here are the basics for anyone looking to get into a new game for the new year.

## Zoho – Running A Software Enterprise From A Village
 - [https://www.forbes.com/sites/patrickmoorhead/2023/01/26/zoho--running-a-software-enterprise-from-a-village/](https://www.forbes.com/sites/patrickmoorhead/2023/01/26/zoho--running-a-software-enterprise-from-a-village/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 20:49:05+00:00
 - user: None

#1-Ranked Industry Analyst Patrick Moorhead dives in as recently, he had the opportunity to speak with Sridhar Vembu, Zoho CEO, via Zoho Meeting.

## Kyndryl – Spinoff From IBM Making The Right Moves
 - [https://www.forbes.com/sites/patrickmoorhead/2023/01/26/kyndryl--spinoff-from-ibm-making-the-right-moves/](https://www.forbes.com/sites/patrickmoorhead/2023/01/26/kyndryl--spinoff-from-ibm-making-the-right-moves/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 20:40:46+00:00
 - user: None

#1-Ranked Industry Analyst Patrick Moorhead dives in as he recently was fortunate to speak with Martin Schroeter, Kyndryl's Chairman and CEO, about his scorecard a little over a year after the spinoff from IBM.

## Fintech: 10 Expert Predictions For 2023
 - [https://www.forbes.com/sites/moorinsights/2023/01/26/fintech-10-expert-predictions-for-2023/](https://www.forbes.com/sites/moorinsights/2023/01/26/fintech-10-expert-predictions-for-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 20:27:47+00:00
 - user: None

Vice President and Principal Analyst of FinTech, Melody Brue, dives in as based on the unpredictable ups and downs of the last few years, she tends to agree with Money 20/20’s statement. Nevertheless, there are some 2023 predictions worth paying attention to.

## Just 28% Of Americans Are Exercising Enough, CDC Says—And It’s Even Lower In Some Regions
 - [https://www.forbes.com/sites/carlieporterfield/2023/01/26/just-28-of-americans-are-exercising-enough-cdc-says-and-its-even-lower-in-some-regions/](https://www.forbes.com/sites/carlieporterfield/2023/01/26/just-28-of-americans-are-exercising-enough-cdc-says-and-its-even-lower-in-some-regions/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 20:20:01+00:00
 - user: None

A CDC analysis found stark differences in time spent doing physical activity between different regions of the U.S. and between rural areas and cities.

## U.S. Healthcare Delivery Is In Critical Condition But Failure Is Not An Option. What’s Next?
 - [https://www.forbes.com/sites/ritanumerof/2023/01/26/us-healthcare-delivery-is-in-critical-condition-but-failure-is-not-an-option-whats-next/](https://www.forbes.com/sites/ritanumerof/2023/01/26/us-healthcare-delivery-is-in-critical-condition-but-failure-is-not-an-option-whats-next/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 20:19:40+00:00
 - user: None

While signs of a new market-based model, defined by greater accountability, payment connected to outcomes and greater transparency in cost and quality, are afoot, this can only be fully realized if delivery organizations pivot in a way that puts the patient consumer squarely at the center.

## 5 Proven Strategies To Overcome Contingent Workforce Management Challenges In The Manufacturing Sector
 - [https://www.forbes.com/sites/magnit/2023/01/26/5-proven-strategies-to-overcome-contingent-workforce-management-challenges-in-the-manufacturing-sector/](https://www.forbes.com/sites/magnit/2023/01/26/5-proven-strategies-to-overcome-contingent-workforce-management-challenges-in-the-manufacturing-sector/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:57:10+00:00
 - user: None

The manufacturing sector is utilizing contract talent, also known as contingent workers, more than ever before.

## 5 Benefits Of Working With A Single Vendor To Manage Contingent Workers
 - [https://www.forbes.com/sites/magnit/2023/01/26/5-benefits-of-working-with-a-single-vendor-to-manage-contingent-workers/](https://www.forbes.com/sites/magnit/2023/01/26/5-benefits-of-working-with-a-single-vendor-to-manage-contingent-workers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:56:49+00:00
 - user: None

The benefits of these workers are clear, but the complexities for employers are just as significant.

## Is The Contingent Workforce Your X Factor For Organizational And Business Agility?
 - [https://www.forbes.com/sites/magnit/2023/01/26/is-the-contingent-workforce-your-x-factor-for-organizational-and-business-agility/](https://www.forbes.com/sites/magnit/2023/01/26/is-the-contingent-workforce-your-x-factor-for-organizational-and-business-agility/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:56:20+00:00
 - user: None

Even before high inflation and the recession set in, C-level executives began to see the wisdom of increasing the agility of their businesses.

## A Psychologist Demystifies The Trend Of Microdosing Psychedelics
 - [https://www.forbes.com/sites/traversmark/2023/01/26/a-psychologist-demystifies-the-trend-of-microdosing-psychedelics/](https://www.forbes.com/sites/traversmark/2023/01/26/a-psychologist-demystifies-the-trend-of-microdosing-psychedelics/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:29:35+00:00
 - user: None

Microdosing psychedelics to enhance cognition and mood is trendy, but do we really understand how it works?

## Free Speech Absolutist Elon Musk Removed BBC Documentary Critical Of India’s Leader
 - [https://www.forbes.com/sites/petersuciu/2023/01/26/free-speech-absolutist-elon-musk-removed-bbc-documentary-critical-of-india/](https://www.forbes.com/sites/petersuciu/2023/01/26/free-speech-absolutist-elon-musk-removed-bbc-documentary-critical-of-india/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:08:22+00:00
 - user: None

It isn't uncommon for nations to ban what they essentially see as information shared by another country's 'state media'

## Humans Have Degraded More Than A Third Of The Amazon Rainforest, Researchers Say
 - [https://www.forbes.com/sites/tylerroush/2023/01/26/humans-have-degraded-more-than-a-third-of-the-amazon-rainforest-researchers-say/](https://www.forbes.com/sites/tylerroush/2023/01/26/humans-have-degraded-more-than-a-third-of-the-amazon-rainforest-researchers-say/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:00:52+00:00
 - user: None

New estimates are larger than what scientists previously believed.

## All The Games Amazon Is Adding To Luna+ And The Prime Gaming Channel In February
 - [https://www.forbes.com/sites/krisholt/2023/01/26/all-the-games-amazon-is-adding-to-luna-and-the-prime-gaming-channel-in-february/](https://www.forbes.com/sites/krisholt/2023/01/26/all-the-games-amazon-is-adding-to-luna-and-the-prime-gaming-channel-in-february/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 19:00:41+00:00
 - user: None

'Yakuza Kiwami' headlines the latest batch of games coming to Luna+ and the Prime Gaming Channel.

## Hertz And Avis/Budget Are Renting Teslas And Other EVs But Charging It Before Return Is A Mess
 - [https://www.forbes.com/sites/bradtempleton/2023/01/26/hertz-and-avisbudget-are-renting-teslas-and-other-evs-but-charging-it-before-return-is-a-mess/](https://www.forbes.com/sites/bradtempleton/2023/01/26/hertz-and-avisbudget-are-renting-teslas-and-other-evs-but-charging-it-before-return-is-a-mess/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 18:01:40+00:00
 - user: None

You can now rent electric cars from many companies.  But what happens if you need to fill the car up again before you return it, and charging will take hours?   Some companies let you return empty, others bill you a fat fee.

## Does Your Dog Know When You’re Teasing Him?
 - [https://www.forbes.com/sites/grrlscientist/2023/01/26/does-your-dog-know-when-youre-teasing-him/](https://www.forbes.com/sites/grrlscientist/2023/01/26/does-your-dog-know-when-youre-teasing-him/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 17:10:33+00:00
 - user: None

Dogs are more patient with humans who accidentally drop a tasty treat out of reach than they are with humans who are simply teasing them, suggesting that dogs may understand human intentions

## FTX Owes Money To Every Major Tech Company, Including Google, Meta, Amazon And Apple
 - [https://www.forbes.com/sites/sarahemerson/2023/01/26/ftx-owes-money-to-every-major-tech-company-google-meta-amazon-tiktok-apple/](https://www.forbes.com/sites/sarahemerson/2023/01/26/ftx-owes-money-to-every-major-tech-company-google-meta-amazon-tiktok-apple/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 16:37:29+00:00
 - user: None

And don’t forget Microsoft, Netflix, TikTok and LinkedIn …

## Visiting Green Spaces Regularly Might Just Lower The Use Of Some Prescription Medicines
 - [https://www.forbes.com/sites/anuradhavaranasi/2023/01/26/visiting-green-spaces-regularly-might-just-lower-the-use-of-some-prescription-medicines/](https://www.forbes.com/sites/anuradhavaranasi/2023/01/26/visiting-green-spaces-regularly-might-just-lower-the-use-of-some-prescription-medicines/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 16:35:00+00:00
 - user: None

Irrespective of anyone’s socioeconomic status, those who are able to regularly visit green spaces like parks and community gardens has been associated with a lower use of prescription medicines for anxiety, depression, insomnia, asthma, and high blood pressure.

## How To Set Yourself Up For Success In 2023
 - [https://www.forbes.com/sites/quora/2023/01/26/how-to-set-yourself-up-for-success-in-2023/](https://www.forbes.com/sites/quora/2023/01/26/how-to-set-yourself-up-for-success-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 16:30:00+00:00
 - user: None

What are a few ways to set yourself up for business success this year? Answer by Charlene Walters, PhD, Business Mentor, Consultant, Corporate Trainer & Author.

## iOS 16.3 Vs iOS 15.7.3—Here’s Which iPhone Update To Choose
 - [https://www.forbes.com/sites/kateoflahertyuk/2023/01/26/ios-163-vs-ios-1573-heres-which-iphone-update-to-choose/](https://www.forbes.com/sites/kateoflahertyuk/2023/01/26/ios-163-vs-ios-1573-heres-which-iphone-update-to-choose/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 16:17:39+00:00
 - user: None

Apple has issued iOS 16.3 along with iOS 15.7.3. Both iPhone updates address major security issues, so which one should you choose?

## This Venture Capitalist Says Corporate Priorities Are Converging With His Business Model
 - [https://www.forbes.com/sites/dianebrady/2023/01/26/this-venture-capitalist-says-corporate-priorities-are-converging-with-his-business-model/](https://www.forbes.com/sites/dianebrady/2023/01/26/this-venture-capitalist-says-corporate-priorities-are-converging-with-his-business-model/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 16:15:46+00:00
 - user: None

VC Mike Edelhart shares his insights on how corporate VCs are viewing the landscape and the opportunities that creates for innovation/

## Meet The Startup Tackling The $22 Billion Super Pollutant – Nylon
 - [https://www.forbes.com/sites/mariannelehnis/2023/01/26/meet-the-startup-tackling-the-22-billion-super-pollutant--nylon/](https://www.forbes.com/sites/mariannelehnis/2023/01/26/meet-the-startup-tackling-the-22-billion-super-pollutant--nylon/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:48:02+00:00
 - user: None

Nylon – more than 8.7 million tons are produced each year.

## One Of TV’s Best Villains Is Joining Walter White And Jesse Pinkman In The ‘Breaking Bad’ Super Bowl Ad
 - [https://www.forbes.com/sites/erikkain/2023/01/26/one-of-tvs-best-villains-is-joining-walter-white-and-jesse-pinkman-in-the-breaking-bad-super-bowl-ad/](https://www.forbes.com/sites/erikkain/2023/01/26/one-of-tvs-best-villains-is-joining-walter-white-and-jesse-pinkman-in-the-breaking-bad-super-bowl-ad/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:16:05+00:00
 - user: None

Watch the first clip from the Breaking Bad PopCorners Super Bowl ad right here.

## Five Steps To Better Support A Modern Detection Team
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-steps-to-better-support-a-modern-detection-team/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-steps-to-better-support-a-modern-detection-team/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:15:00+00:00
 - user: None

Security teams need better approaches that can support them in keeping up with the rising challenges.

## Covid Vaccines: Here’s Evidence They Work—Despite Persistent Misinformation—Along With Side Effects And Common Misconceptions
 - [https://www.forbes.com/sites/ariannajohnson/2023/01/26/covid-vaccines-heres-evidence-they-work-despite-persistent-misinformation-along-with-side-effects-and-common-misconceptions/](https://www.forbes.com/sites/ariannajohnson/2023/01/26/covid-vaccines-heres-evidence-they-work-despite-persistent-misinformation-along-with-side-effects-and-common-misconceptions/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:13:35+00:00
 - user: None

Studies estimate Covid vaccines prevented millions of deaths and even more hospitalizations.

## Here Are The Amazon Prime Gaming Free Games For February 2023
 - [https://www.forbes.com/sites/krisholt/2023/01/26/here-are-the-amazon-prime-gaming-free-games-for-february-2023/](https://www.forbes.com/sites/krisholt/2023/01/26/here-are-the-amazon-prime-gaming-free-games-for-february-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:02:20+00:00
 - user: None

Amazon is offering several games created by Black developers in honor of Black History Month.

## Europe’s Auto Makers Can Handle Conventional Obstacles, But A Trade War?
 - [https://www.forbes.com/sites/neilwinton/2023/01/26/europes-auto-makers-can-handle-conventional-obstacles-but-a-trade-war/](https://www.forbes.com/sites/neilwinton/2023/01/26/europes-auto-makers-can-handle-conventional-obstacles-but-a-trade-war/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:00:46+00:00
 - user: None

European automakers need to shake off a recession, weather inflation and face down the China challenge, then they’ll have to face intensifying competition as production shakes off the semiconductor shortage straitjacket. A trade war with the U.S. is the last thing they need.

## Portfolio Orchestration: Private Equity’s New Superpower To Improve Value Creation
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/portfolio-orchestration-private-equitys-new-superpower-to-improve-value-creation/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/portfolio-orchestration-private-equitys-new-superpower-to-improve-value-creation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:00:00+00:00
 - user: None

Enterprise orchestration isn’t a panacea for all the challenges faced by PE, but it can deliver rapid ROI against the most common ones we’ve encountered as we’ve helped portcos and funds around the world accelerate their VCPs.

## Want To Keep Your Top Talent? Better Support Working Parents And Caregivers.
 - [https://www.forbes.com/sites/garydrenik/2023/01/26/want-to-keep-your-top-talent-better-support-working-parents-and-caregivers/](https://www.forbes.com/sites/garydrenik/2023/01/26/want-to-keep-your-top-talent-better-support-working-parents-and-caregivers/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 15:00:00+00:00
 - user: None

Many of us have seen family & caregiver-support offerings change over the years as employee benefits packages have been enriched with new offerings to attract & keep top workers. That said, most of us still haven’t had access to such plans, nor fully understand what is actually available out there.

## A Truck-Sized Asteroid Will Pass Earth In One Of Nearest Misses On Record — Here’s How To Watch It
 - [https://www.forbes.com/sites/roberthart/2023/01/26/a-truck-sized-asteroid-will-pass-earth-in-one-of-nearest-misses-on-record---heres-how-to-watch-it/](https://www.forbes.com/sites/roberthart/2023/01/26/a-truck-sized-asteroid-will-pass-earth-in-one-of-nearest-misses-on-record---heres-how-to-watch-it/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:58:09+00:00
 - user: None

Asteroid 2023 BU will brush past Earth at a lower altitude than most satellites but NASA said there is no risk of impact.

## How Utilities Can Support SMBs Through Energy Efficiency Efforts Post-Covid
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-utilities-can-support-smbs-through-energy-efficiency-efforts-post-covid/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-utilities-can-support-smbs-through-energy-efficiency-efforts-post-covid/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:45:00+00:00
 - user: None

By helping SMB owners improve and reduce their energy usage in ways that maintain business continuity, utilities can empower them to save money on utility bills—a top operating expense—while also promoting carbon reduction in alignment with national goals.

## ‘Destiny 2’ Is Hacking Away At FOMO With Significant Loot Changes
 - [https://www.forbes.com/sites/paultassi/2023/01/26/destiny-2-is-hacking-away-at-fomo-with-significant-loot-changes/](https://www.forbes.com/sites/paultassi/2023/01/26/destiny-2-is-hacking-away-at-fomo-with-significant-loot-changes/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:40:49+00:00
 - user: None

Even if Destiny has done this on a large scale with content vaulting, it has also done it on a smaller scale with some amount of loot and cosmetics. Now, that’s changing as of Lightfall.

## Affiliate Marketing Compliance: 4 Things You Need To Know
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/affiliate-marketing-compliance-4-things-you-need-to-know/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/affiliate-marketing-compliance-4-things-you-need-to-know/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:30:00+00:00
 - user: None

Despite its widespread popularity, the affiliate marketing industry still faces a variety of challenges and pain points, most notably with regard to regulatory compliance and consumer protection laws.

## The Importance Of Understanding Vulnerability Management Frameworks To Prioritize Security Responses
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/the-importance-of-understanding-vulnerability-management-frameworks-to-prioritize-security-responses/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/the-importance-of-understanding-vulnerability-management-frameworks-to-prioritize-security-responses/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:15:00+00:00
 - user: None

To prioritize responses to vulnerabilities, here are a few different standards to consider.

## Surprise Xbox Release ‘Hi-Fi Rush’ Attracts Stellar Scores, And Solid Sales
 - [https://www.forbes.com/sites/paultassi/2023/01/26/surprise-xbox-release-hi-fi-rush-attracts-stellar-scores-and-solid-sales/](https://www.forbes.com/sites/paultassi/2023/01/26/surprise-xbox-release-hi-fi-rush-attracts-stellar-scores-and-solid-sales/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:03:18+00:00
 - user: None

Easily the highlight of yesterday’s Xbox showcase was the surprise announcement, and then release, of Hi-Fi Rush from the team behind both Evil Within games, a jarring change in tone.

## Telecom CX: Keeping The Train On The Tracks
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/telecom-cx-keeping-the-train-on-the-tracks/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/telecom-cx-keeping-the-train-on-the-tracks/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 14:00:00+00:00
 - user: None

Once you understand your customer and chart out a successful journey with all the right components, it’s hard to stop a train once it gets rolling.

## Russians Claim To Develop Smartphone App To Locate Ukrainian Artillery
 - [https://www.forbes.com/sites/davidhambling/2023/01/26/russian-smartphone-app-to-locate-ukrainian-artillery/](https://www.forbes.com/sites/davidhambling/2023/01/26/russian-smartphone-app-to-locate-ukrainian-artillery/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:59:36+00:00
 - user: None

The Russian military has developed special software for networked smartphones to locate Ukrainian artillery by sound, reviving a technology first used over a century ago in WW1.

## ‘Doom Patrol’ And ‘Titans’ Cancelled Ahead Of The New DC Era
 - [https://www.forbes.com/sites/paultassi/2023/01/26/doom-patrol-and-titans-cancelled-ahead-of-the-new-dc-era/](https://www.forbes.com/sites/paultassi/2023/01/26/doom-patrol-and-titans-cancelled-ahead-of-the-new-dc-era/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:49:27+00:00
 - user: None

It was pretty clear for a while now that this was inevitable, but now, it’s official. Surviving DC Universe shows Titans and Doom Patrol have been cancelled ahead of a brand new era for DC under James Gunn and Peter Safran.

## The One Question I Still Have About ‘Redfall’
 - [https://www.forbes.com/sites/paultassi/2023/01/26/the-one-question-i-still-have-about-redfall/](https://www.forbes.com/sites/paultassi/2023/01/26/the-one-question-i-still-have-about-redfall/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:46:22+00:00
 - user: None

I originally tuned into the show to see more from Arkane’s Redfall, and it did indeed close the show and teased a somewhat soon release date, May 2, after being delayed out of 2022.

## How To Train And Teach A Culture Of Efficiency And Productivity
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-to-train-and-teach-a-culture-of-efficiency-and-productivity/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-to-train-and-teach-a-culture-of-efficiency-and-productivity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:45:00+00:00
 - user: None

Creating a longstanding, sustainable culture where productivity is a key value and principle in the operating model starts during periods of growth.

## 5 App Development Trends To Expect In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/5-app-development-trends-to-expect-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/5-app-development-trends-to-expect-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:30:00+00:00
 - user: None

As new technologies and user behaviors emerge, app developers will need to stay up to date and adapt to these changes to remain competitive in the fast-paced world of mobile apps.

## 15 Tech Features That Could Become Standard Fixtures In New Home Construction
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/15-tech-features-that-could-become-standard-fixtures-in-new-home-construction/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/15-tech-features-that-could-become-standard-fixtures-in-new-home-construction/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:15:00+00:00
 - user: None

Home-based smart technology, once considered a luxury or a “nice-to-have” feature, is becoming increasingly commonplace.

## Five Best Practices For Industrial Cybersecurity: Closing The Gap Between IT And OT
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-best-practices-for-industrial-cybersecurity-closing-the-gap-between-it-and-ot/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-best-practices-for-industrial-cybersecurity-closing-the-gap-between-it-and-ot/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:15:00+00:00
 - user: None

Here are five best practices for bridging the IT/OT divide to help fortify industrial cybersecurity methods.

## Tesla Slashes Prices Up To 20 Percent, Sending Shockwaves Through EV Industry
 - [https://www.forbes.com/sites/qai/2023/01/26/tesla-slashes-prices-up-to-20-percent-sending-shockwaves-through-ev-industry/](https://www.forbes.com/sites/qai/2023/01/26/tesla-slashes-prices-up-to-20-percent-sending-shockwaves-through-ev-industry/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:00:37+00:00
 - user: None

Tesla’s price drops are officially cited as a drop in supply chain prices, but others think it’s a savvy sales ploy after a rough year

## Is Xbox’s ‘Starfield’ Going To Be Delayed Again?
 - [https://www.forbes.com/sites/paultassi/2023/01/26/is-xboxs-starfield-going-to-be-delayed-again/](https://www.forbes.com/sites/paultassi/2023/01/26/is-xboxs-starfield-going-to-be-delayed-again/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:00:13+00:00
 - user: None

Yesterday, there were at least some amount of gamers who were not paying attention to the expectations Microsoft set for the Xbox showcase, as they left the production wondering where Starfield was.

## 25 Year Old Web3 Entrepreneur Secures $10M In Seed Funding For His Fashion Centric Tech
 - [https://www.forbes.com/sites/stephaniehirschmiller/2023/01/26/25-year-old-web3-entrepreneur-secures-10m-in-seed-funding-for-his-fashion-centric-tech/](https://www.forbes.com/sites/stephaniehirschmiller/2023/01/26/25-year-old-web3-entrepreneur-secures-10m-in-seed-funding-for-his-fashion-centric-tech/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:00:00+00:00
 - user: None

This brings the company's total funding to over $14 million — making its 25 year-old founder Iddris Sandu the first Black founder under 30 to raise a double-digit million seed round.

## 4 Tips A Global Team Can Teach About Leadership Success
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/4-tips-a-global-team-can-teach-about-leadership-success/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/4-tips-a-global-team-can-teach-about-leadership-success/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 13:00:00+00:00
 - user: None

Some of the best business lessons come from unexpected places and can shift an executive’s position by suddenly granting deep and unexpected knowledge.

## 3 Cybersecurity Strategy Goals For CISOs To Consider In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/3-cybersecurity-strategy-goals-for-cisos-to-consider-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/3-cybersecurity-strategy-goals-for-cisos-to-consider-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 12:45:00+00:00
 - user: None

Here are three pieces of advice for CISOs and security professionals to consider when planning their 2023 cybersecurity strategy.

## Optimizing Your Real Estate Content Marketing Strategy In 2023
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/optimizing-your-real-estate-content-marketing-strategy-in-2023/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/optimizing-your-real-estate-content-marketing-strategy-in-2023/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 12:30:00+00:00
 - user: None

Here are four tips that will help you boost your real estate content marketing strategy to enhance results while keeping costs at bay.

## India To Get An Extra OnePlus Flagship Product In The Form Of QLED TV
 - [https://www.forbes.com/sites/prakharkhanna/2023/01/26/india-to-get-an-extra-oneplus-flagship-product-in-the-form-of-qled-tv/](https://www.forbes.com/sites/prakharkhanna/2023/01/26/india-to-get-an-extra-oneplus-flagship-product-in-the-form-of-qled-tv/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 12:27:41+00:00
 - user: None

OnePlus is all set to unveil a slew of flagship products on February 7 at its Cloud 11 event in India.

## Three Ways To Optimize OOH Advertising For A More Efficient Marketing Campaign
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/three-ways-to-optimize-ooh-advertising-for-a-more-efficient-marketing-campaign/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/three-ways-to-optimize-ooh-advertising-for-a-more-efficient-marketing-campaign/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 12:15:00+00:00
 - user: None

If done right, OOH advertising could help you turn a commuting audience into real website visitors and, consequently, paying customers.

## How Brands Can Design Data Strategies To Build Consumer Trust
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-brands-can-design-data-strategies-to-build-consumer-trust/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-brands-can-design-data-strategies-to-build-consumer-trust/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 12:00:00+00:00
 - user: None

Money is the currency of transactions, but trust is the currency of interactions.

## Russian And Iranian Hackers Targeting Politicians And Journalists
 - [https://www.forbes.com/sites/emmawoollacott/2023/01/26/russian-and-iranian-hackers-targeting-politicians-and-journalists/](https://www.forbes.com/sites/emmawoollacott/2023/01/26/russian-and-iranian-hackers-targeting-politicians-and-journalists/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 11:58:13+00:00
 - user: None

State-linked hackers in Russia and Iran have been targeting politicians, journalists and others in the UK and elsewhere through a 'sophisticated' spear-phishing campaign.

## How An Omnichannel Approach Can Improve Your Marketing Communications
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-an-omnichannel-approach-can-improve-your-marketing-communications/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/how-an-omnichannel-approach-can-improve-your-marketing-communications/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 11:45:00+00:00
 - user: None

Given the rise in omnichannel marketing, here's how brands can begin developing an omnichannel strategy.

## Unlock The Potential Of Generative AI: A Guide For Tech Leaders
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/unlock-the-potential-of-generative-ai-a-guide-for-tech-leaders/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/unlock-the-potential-of-generative-ai-a-guide-for-tech-leaders/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 11:30:00+00:00
 - user: None

With advances in technology, more use cases are being discovered every day, allowing for greater automation of processes and improved efficiency.

## Five Steps For Disrupting In Today’s VC Environment
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-steps-for-disrupting-in-todays-vc-environment/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/five-steps-for-disrupting-in-todays-vc-environment/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 11:15:00+00:00
 - user: None

By applying the MAYA principle to their development, startups can pass a critical part of the VC litmus test. To help get you started, here are five easy steps to follow.

## The Future Of Work Is Hybrid, Human And Here To Stay
 - [https://www.forbes.com/sites/forbestechcouncil/2023/01/26/the-future-of-work-is-hybrid-human-and-here-to-stay/](https://www.forbes.com/sites/forbestechcouncil/2023/01/26/the-future-of-work-is-hybrid-human-and-here-to-stay/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 11:00:00+00:00
 - user: None

Companies are grappling with the reality that people want different things from their employers today.

## A Covid Test Targeting The Fast-Spreading XBB.1.5 ‘Kraken’ Variant Is Being Developed By Scientists
 - [https://www.forbes.com/sites/roberthart/2023/01/26/a-covid-test-targeting-the-fast-spreading-xbb15-kraken-variant-is-being-developed-by-scientists/](https://www.forbes.com/sites/roberthart/2023/01/26/a-covid-test-targeting-the-fast-spreading-xbb15-kraken-variant-is-being-developed-by-scientists/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 10:27:01+00:00
 - user: None

The specialized test will help experts track the fast-spreading virus and develop new strategies to contain it, Roche said.

## Electric Vehicle Charging Will Require 12 Times More Energy Than Used Today, Warns Motorway Services Boss
 - [https://www.forbes.com/sites/carltonreid/2023/01/26/electric-vehicle-charging-will-require-12-times-more-energy-than-used-today-warns-motorway-services-boss/](https://www.forbes.com/sites/carltonreid/2023/01/26/electric-vehicle-charging-will-require-12-times-more-energy-than-used-today-warns-motorway-services-boss/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 10:26:18+00:00
 - user: None

The boss of the U.K.’s most extensive motorway services provider has warned of the “challenge” ahead for grid capacity as more and more British motorists switch to electric vehicles “The electric vehicle revolution is now well underway,” Moto CEO Ken McMeikan said in a statement today “By 2040, w...

## How Digital And Distributed Technology Are Being Used To Prevent Deforestation
 - [https://www.forbes.com/sites/jamiehailstone/2023/01/26/how-digital-and-distributed-technology-are-being-used-to-prevent-deforestation/](https://www.forbes.com/sites/jamiehailstone/2023/01/26/how-digital-and-distributed-technology-are-being-used-to-prevent-deforestation/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 09:57:02+00:00
 - user: None

In 2021 alone, we lost 25 million hectares of forests which released 10 gigatons of carbon dioxide into the atmosphere.

## Data Privacy - 5 Best Practices Everyone Should Be Following
 - [https://www.forbes.com/sites/bernardmarr/2023/01/26/data-privacy5-best-practices-everyone-should-be-following/](https://www.forbes.com/sites/bernardmarr/2023/01/26/data-privacy5-best-practices-everyone-should-be-following/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 07:23:02+00:00
 - user: None

More and more of what we do is captured by data, and as companies are trying to exploit all this data, data privacy is an increasingly important topic. Here, we look at the top tips and best practices everyone should follow.

## New House Speaker McCarthy Selects Taylor Greene For Coronavirus Pandemic Subcommittee
 - [https://www.forbes.com/sites/brucelee/2023/01/26/new-house-speaker-mccarthy-selects-taylor-greene-for-coronavirus-pandemic-subcommittee/](https://www.forbes.com/sites/brucelee/2023/01/26/new-house-speaker-mccarthy-selects-taylor-greene-for-coronavirus-pandemic-subcommittee/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 05:56:12+00:00
 - user: None

How much real science will be represented on the House of Representatives Select Subcommittee on the Coronavirus Pandemic?

## Raindrop.io Is The Bookmarking Tool To Keep You Organized
 - [https://www.forbes.com/sites/tjmccue/2023/01/25/raindropio-is-the-bookmarking-tool-to-keep-you-organized/](https://www.forbes.com/sites/tjmccue/2023/01/25/raindropio-is-the-bookmarking-tool-to-keep-you-organized/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 04:38:51+00:00
 - user: None

Raindrop.io has quickly become one of my most-used apps and is helping me create a second brain. I can express how it guides my day and mindset in only three words: Keeps me organized.

## Today’s Wordle #586 Hint, Clues And Answer For Thursday, January 26th
 - [https://www.forbes.com/sites/erikkain/2023/01/25/todays-wordle-586-hint-clues-and-answer-for-thursday-january-26th/](https://www.forbes.com/sites/erikkain/2023/01/25/todays-wordle-586-hint-clues-and-answer-for-thursday-january-26th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 03:37:20+00:00
 - user: None

How to solve today's Wordle word of the day.

## Ninjas In Pyjamas Enters ‘Rocket League’ Championship Series, Aims To Rally Brazil Behind The Esport
 - [https://www.forbes.com/sites/maxthielmeyer/2023/01/25/ninjas-in-pyjamas-enters-rocket-league-championship-series-aims-to-rally-brazil-behind-the-esport/](https://www.forbes.com/sites/maxthielmeyer/2023/01/25/ninjas-in-pyjamas-enters-rocket-league-championship-series-aims-to-rally-brazil-behind-the-esport/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 02:07:21+00:00
 - user: None

The team's announcement video invokes Brazilian sporting legends Pelé and Ayrton Senna.

## Today’s ‘Heardle’ Answer And Clues For Thursday, January 26
 - [https://www.forbes.com/sites/krisholt/2023/01/25/todays-heardle-answer-and-clues-for-thursday-january-26/](https://www.forbes.com/sites/krisholt/2023/01/25/todays-heardle-answer-and-clues-for-thursday-january-26/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 01:15:27+00:00
 - user: None

Here's today's 'Heardle' song, along with some hints.

## What Tesla Brand Crisis? Musk Says His Vast Twitter Audience Confirms Popularity
 - [https://www.forbes.com/sites/alanohnsman/2023/01/25/what-tesla-brand-crisis-musk-says-his-vast-twitter-audience-confirms-popularity/](https://www.forbes.com/sites/alanohnsman/2023/01/25/what-tesla-brand-crisis-musk-says-his-vast-twitter-audience-confirms-popularity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 01:00:27+00:00
 - user: None

The EV maker's mercurial CEO encourages other companies to emulate his "entertaining" Twitter style to aid sales.

## Today’s ‘Quordle’ Answers And Clues For Thursday, January 26
 - [https://www.forbes.com/sites/krisholt/2023/01/25/todays-quordle-answers-and-clues-for-thursday-january-26/](https://www.forbes.com/sites/krisholt/2023/01/25/todays-quordle-answers-and-clues-for-thursday-january-26/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 01:00:11+00:00
 - user: None

Some hints and the solution for today's 'Quordle' are just ahead.

## Welcome To Chariklo, A Ringed World In The Solar System Just Examined By The Webb Telescope
 - [https://www.forbes.com/sites/jamiecartereurope/2023/01/25/welcome-to-chariklo-a-ringed-world-in-the-solar-system-just-examined-by-the-webb-telescope/](https://www.forbes.com/sites/jamiecartereurope/2023/01/25/welcome-to-chariklo-a-ringed-world-in-the-solar-system-just-examined-by-the-webb-telescope/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 01:00:00+00:00
 - user: None

The James Webb Space Telescope is so precise it can find rings around a tiny icy world a over two billion miles away.

## Treat Your Mac To A New Mechanical Keyboard And Boost Your Productivity
 - [https://www.forbes.com/sites/anthonykarcz/2023/01/25/treat-your-mac-to-a-new-mechanical-keyboard-and-boost-your-productivity/](https://www.forbes.com/sites/anthonykarcz/2023/01/25/treat-your-mac-to-a-new-mechanical-keyboard-and-boost-your-productivity/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 00:42:37+00:00
 - user: None

These keyboards from DROP, Keychron, and Das Keyboard truly elevate your Mac experience.

## Justin Roiland Parts Ways With ‘High On Life’ Studio Squanch Games
 - [https://www.forbes.com/sites/erikkain/2023/01/25/justin-roiland-parts-ways-with-high-on-life-studio-squanch-games/](https://www.forbes.com/sites/erikkain/2023/01/25/justin-roiland-parts-ways-with-high-on-life-studio-squanch-games/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 00:12:56+00:00
 - user: None

Justin Roiland resigns amidst ongoing controversy and scandal.

## Nikola To Run Hydrogen Production, Fuel Cell Truck Stations Under ‘HYLA’ Brand
 - [https://www.forbes.com/sites/alanohnsman/2023/01/25/nikola-to-run-hydrogen-production-fuel-cell-truck-stations-under-hyla-brand/](https://www.forbes.com/sites/alanohnsman/2023/01/25/nikola-to-run-hydrogen-production-fuel-cell-truck-stations-under-hyla-brand/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-01-26 00:08:16+00:00
 - user: None

Much like Tesla, the company is building its own fueling network to keep its hydrogen trucks running. It plans to operate 60 fuel stations by 2026.
