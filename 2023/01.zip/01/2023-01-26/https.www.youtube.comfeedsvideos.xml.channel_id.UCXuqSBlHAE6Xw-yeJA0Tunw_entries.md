# Source Linus Tech Tips, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw, Source language: en-US

## This is a computer.
 - [https://www.youtube.com/watch?v=1CBQM2X8BZQ](https://www.youtube.com/watch?v=1CBQM2X8BZQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXuqSBlHAE6Xw-yeJA0Tunw
 - date published: 2023-01-26 18:16:54+00:00
 - user: None

Subscribe to our Floatplane account for exclusive content today at https://lmg.gg/lttfloatplane

PDQ.com: Start your FREE trial now! At https://lmg.gg/PDQOct

This tiny PC is one of the coolest devices I've seen in a long time! I'm going to show you all the cool stuff it comes with (including the mini projector), what it looks like inside, and what it's like to game on it.

Discuss on the forum: https://linustechtips.com/topic/1484077-this-is-a-computer-pantera-pico-pc/

Check Out the Pantera Pico PC: https://lmg.gg/ZLpTH

Purchases made through some store links may provide some compensation to Linus Media Group.

► GET MERCH: https://lttstore.com
► SUPPORT US ON FLOATPLANE: https://www.floatplane.com/ltt
► AFFILIATES, SPONSORS & REFERRALS: https://lmg.gg/sponsors
► PODCAST GEAR: https://lmg.gg/podcastgear

FOLLOW US 
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

MUSIC CREDIT
---------------------------------------------------
Intro: Laszlo - Supernova
Video Link: https://www.youtube.com/watch?v=PKfxmFU3lWY
iTunes Download Link: https://itunes.apple.com/us/album/supernova/id936805712
Artist Link: https://soundcloud.com/laszlomusic

Outro: Approaching Nirvana - Sugar High
Video Link: https://www.youtube.com/watch?v=ngsGBSCDwcI
Listen on Spotify: http://spoti.fi/UxWkUw
Artist Link: http://www.youtube.com/approachingnirvana

Intro animation by MBarek Abdelwassaa https://www.instagram.com/mbarek_abdel/
Monitor And Keyboard by vadimmihalkevich / CC BY 4.0  https://geni.us/PgGWp
Mechanical RGB Keyboard by BigBrotherECE / CC BY 4.0 https://geni.us/mj6pHk4
Mouse Gamer free Model By Oscar Creativo / CC BY 4.0 https://geni.us/Ps3XfE

CHAPTERS
---------------------------------------------------
0:00 Intro
0:40 look at this tiny pc
1:02 cute accessories
3:09 Teardown
5:31 Intel "J-series"??
7:16 Testing NVMe compatibility
7:58 Booting up
10:48 Gaming on it
11:39 Can I stream 4K?
11:52 My thoughts
