# Source Forsal.pl, Source URL:https://forsal.pl/.feed, Source language: pl-PL

## Na ile wybory prezydenckie wpłyną na czeską gospodarkę?
 - [https://forsal.pl/gospodarka/artykuly/8646836,na-ile-wybory-prezydenckie-wplyna-na-czeska-gospodarke.html](https://forsal.pl/gospodarka/artykuly/8646836,na-ile-wybory-prezydenckie-wplyna-na-czeska-gospodarke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 20:42:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Y2gktkuTURBXy8xNmJiMTM2MS1mOGRiLTRhN2MtYjBiZS02YWNhNmFiZjRmYTAuanBlZ5GTBc0BHcyg" />Jutro (27 stycznia) wczesnym popołudniem rozpoczną się w Czechach wybory prezydenckie. Do głosowania uprawnionych jest ponad 8,2 mld osób. W piątek w godzinach 14-22 i w sobotę w godzinach 6-14 wybiorą jednej z dwóch kandydatów na urząd prezydenta – b. generała Petra Pavla bądź b. premiera Andreja Babiša. Kampanię wyborczą zdominowały kwestie związane z bezpieczeństwem. Chcielibyśmy przyjrzeć się także ich wpływowi na czeską gospodarkę.

## Masłowska z RPP: Ewentualna przestrzeń do obniżki stóp może się pojawić dopiero pod koniec 2023
 - [https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8646827,maslowska-z-rpp-ewentualna-przestrzen-do-obnizki-stop-moze-sie-pojawic-dopiero-pod-koniec-2023.html](https://forsal.pl/gospodarka/stopy-procentowe/artykuly/8646827,maslowska-z-rpp-ewentualna-przestrzen-do-obnizki-stop-moze-sie-pojawic-dopiero-pod-koniec-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 20:38:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RfEktkuTURBXy82NmM4ZjJmNy0yMWM5LTRjN2EtOGZkMS05YTdlNzlmMTNmYWYuanBlZ5GTBc0BHcyg" />Przestrzeń do obniżki stóp procentowych ma szansę pojawić się w 2024 r. lub ewentualnie pod koniec 2023 r., ocenia członkini Rady Polityki Pieniężnej (RPP) Gabriela Masłowska. Według niej, w końcu 2023 r. inflacja konsumpcyjna w Polsce ukształtuje się na poziomie niższym od 10% r/r.

## USA przekaże Ukrainie nowe czołgi M1A2 Abrams
 - [https://forsal.pl/swiat/ukraina/artykuly/8646824,usa-przekaze-ukrainie-nowe-czolgi-m1a2-abrams.html](https://forsal.pl/swiat/ukraina/artykuly/8646824,usa-przekaze-ukrainie-nowe-czolgi-m1a2-abrams.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 20:29:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5gektkuTURBXy8xN2VlYWU1MS0xYjgxLTRlOTItYjNhNy1kNjg2ZGVjZmZmMDcuanBlZ5GTBc0BHcyg" />Zamierzamy pozyskać dla Ukrainy nowe czołgi M1A2 Abrams - powiedziała w czwartek rzeczniczka Pentagonu Sabrina Singh. Jak dodała, jest to oznaka &quot;długoterminowego zobowiązania&quot; USA co do obronności Ukrainy. Singh nie odpowiedziała na pytanie PAP, czy produkcja czołgów dla Ukrainy wpłynie na termin dostaw podobnych wozów dla Polski.

## Buda z PFR: Fundacje rodzinne już niedługo będą elementem polskiego środowiska biznesowego
 - [https://forsal.pl/biznes/artykuly/8646821,buda-z-pfr-fundacje-rodzinne-elementem-polskiego-srodowiska-biznesowego.html](https://forsal.pl/biznes/artykuly/8646821,buda-z-pfr-fundacje-rodzinne-elementem-polskiego-srodowiska-biznesowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 20:24:47+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VK7ktkuTURBXy9lMWQ1ZDM0Yi1jOWI3LTQ2MDEtODM0OS00ZWViMmFkOTEzZGYuanBlZ5GTBc0BHcyg" />Pierwsze fundacje rodzinne będą mogły już niedługo powstawać także w Polsce - stwierdził minister rozwoju i technologii Waldemar Buda w czwartkowym komentarzu dla PAP. Podkreślił, że zmiana to efekt współpracy m.in. z firmami, które apelowały o wprowadzenie nowego narzędzia sukcesyjnego.

## Japoński stelita z orbity okołoziemskiej będzie obserwować m.in.Koreę Północną
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646816,japonski-stelita-z-orbity-okoloziemskiej-bedzie-obserwowac-koree-polnocna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646816,japonski-stelita-z-orbity-okoloziemskiej-bedzie-obserwowac-koree-polnocna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 20:11:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TOUktkuTURBXy9mNjc4N2U3OS03MDFmLTQ1OWQtODlkNi03ZGMzODA5M2RiZWEuanBlZ5GTBc0BHcyg" />Japonia z powodzeniem wystrzeliła w czwartek rakietę z satelitą radarowym, zbierającym m.in. dane wywiadowcze - poinformowała agencja Kyodo. Tokio chce w ten sposób usprawnić reagowanie na katastrofy i monitorować rozwój wydarzeń w północnokoreańskich obiektach wojskowych.

## Sytuacja w Autonomii Palestyńskiej zaostrza się. Umowa dotyczącą koordynacji bezpieczeństwa nie obowiązuje
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646777,umowa-dotyczaca-koordynacji-bezpieczenstwa-nie-obowiazuje-izrael-palestyna.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646777,umowa-dotyczaca-koordynacji-bezpieczenstwa-nie-obowiazuje-izrael-palestyna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 19:57:12+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rmHktkuTURBXy9lYTY4ZmJlYi03ZjY2LTQwYzItYWI1YS01OTRkNDgxNmM1ODguanBlZ5GTBc0BHcyg" />Autonomia Palestyńska ogłosiła w czwartek zakończenie porozumienia z Izraelem o koordynacji bezpieczeństwa. To efekt izraelskiej akcji wojskowej w obozie dla uchodźców w Dżaninie, mieście na północy Zachodniego Brzegu Jordanu, w trakcie której zginęło dziewięciu Palestyńczyków.

## Negocjacje w KGHM zakończone. Pensje wzrosną o 13,2 proc.
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8646774,negocjacje-w-kghm-zakonczone-pensje-wzrosna-o-132-proc.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8646774,negocjacje-w-kghm-zakonczone-pensje-wzrosna-o-132-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 19:47:52+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/5QfktkuTURBXy8zZjUwMDVkZC02MmQ3LTRiMWMtOGUzZC0yY2IwNjIyMDUzMmYuanBlZ5GTBc0BHcyg" />Po dwóch spotkaniach zarządu KGHM Polska Miedź S.A. ze związkami zawodowymi zakończyły się negocjacje w sprawie m.in. wzrostu płac. Płace zasadnicze wzrosną o 13,2 proc. Przewidywana jest również jednorazowa nagroda w wys. 2 tys. zł na pracownika - poinformowała w czwartek spółka.

## Optymistyczne założenia węgierskiego rządu. Na koniec roku inflacja może być jednocyfrowa
 - [https://forsal.pl/gospodarka/pkb/artykuly/8646756,optymistyczne-zalozenia-wegry-rzad-na-koniec-roku-inflacja-jednocyfrowa.html](https://forsal.pl/gospodarka/pkb/artykuly/8646756,optymistyczne-zalozenia-wegry-rzad-na-koniec-roku-inflacja-jednocyfrowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 19:28:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/99oktkuTURBXy85YTAyMGM3Yy1kNTEwLTQ0YWUtOTg3ZC1hYzY2NmNlOGQ2MDUuanBlZ5GTBc0BHcyg" />Węgry mogą uniknąć recesji i osiągnąć wzrost gospodarczy na poziomie 1,5 proc. oraz jednocyfrową inflację na koniec roku – ocenił w wywiadzie dla tygodnika &quot;Mandiner&quot; minister rozwoju gospodarczego Węgier Marton Nagy.

## Ukraińskie siły zbrojne sprawdzą czy w obwodzie zaporoskim przebywają białoruscy żołnierzy
 - [https://forsal.pl/swiat/ukraina/artykuly/8646752,ukrainskie-sily-zbrojne-obwod-zaporoski-przebywaja-bialoruscy-zolnierzy.html](https://forsal.pl/swiat/ukraina/artykuly/8646752,ukrainskie-sily-zbrojne-obwod-zaporoski-przebywaja-bialoruscy-zolnierzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 19:20:56+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/v9AktkuTURBXy81NWQ2Y2E1Zi1mYjZiLTQyYTctYmM4Yi0wMWJjY2VjZDEzYjguanBlZ5GTBc0BHcyg" />Iwan Fedorow, lojalny wobec Kijowa mer okupowanego przez rosyjskie wojska Melitopola, poinformował w czwartek, że w miejscowości Kyryliwka nad Morzem Azowskim byli widziani białoruscy żołnierze - oznajmił portal RBK-Ukraina. Sprawdzamy te doniesienia - zapewnił pułkownik Jewhen Jerin, rzecznik ukraińskich wojsk w obwodzie zaporoskim.

## Władze Serbii chcą przyłączyć się do sankcji UE wobec Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646713,wladze-serbii-chca-przylaczyc-sie-do-sankcji-ue-wobec-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646713,wladze-serbii-chca-przylaczyc-sie-do-sankcji-ue-wobec-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 19:14:14+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QADktkuTURBXy81ODdhYWQxNS04ZTlkLTQ3ZTYtOGM3Ni00YzI1MzJjMDBiNjkuanBlZ5GTBc0BHcyg" />W środę minister spraw zagranicznych Serbii Ivica Daczić oznajmił, że Belgrad dopuszcza możliwość przyłączenia się do sankcji UE wobec Rosji; była to pierwsza taka wypowiedź przedstawiciela serbskich władz od lutego 2022 roku, czyli początku inwazji Kremla na Ukrainę - poinformował w czwartek portal Euractiv.

## Hiszpania przekaże Ukrainie czołgi Leopard. Przed wysyłką wszystkie maszyny muszą być wyremontowane
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646616,hiszpania-ukraina-czolgi-leopard-maszyny-musza-byc-wyremontowane.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646616,hiszpania-ukraina-czolgi-leopard-maszyny-musza-byc-wyremontowane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 17:53:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YWfktkuTURBXy8wZTNhZTNkYy05OWIyLTQ5MmYtYTk4My1kZDllMjUxNDU2YmUuanBlZ5GTBc0BHcyg" />Czołgi Leopard typu 2A4, które Hiszpania wyśle Ukrainie, już wkrótce zostaną naprawiane - poinformowała w czwartek minister obrony Margarita Robles w rozmowie z TVE.

## Hiszpania przekaże Ukrainie czołgi Leopard. Wyremontuje wszystkie maszyny, które wyśle
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646616,hiszpania-przekaze-ukrainie-czolgi-leopard.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646616,hiszpania-przekaze-ukrainie-czolgi-leopard.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 17:53:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YWfktkuTURBXy8wZTNhZTNkYy05OWIyLTQ5MmYtYTk4My1kZDllMjUxNDU2YmUuanBlZ5GTBc0BHcyg" />Czołgi Leopard typu 2A4, które Hiszpania wyśle Ukrainie, już wkrótce zostaną naprawiane - poinformowała w czwartek minister obrony Margarita Robles w rozmowie z TVE.

## Trump skrytykował dostawy czołgów dla Ukrainy. Chce być mediatorem między Rosją i Ukrainą
 - [https://forsal.pl/swiat/usa/artykuly/8646611,trump-chce-byc-mediatorem-miedzy-rosja-i-ukraina.html](https://forsal.pl/swiat/usa/artykuly/8646611,trump-chce-byc-mediatorem-miedzy-rosja-i-ukraina.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 17:35:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PunktkuTURBXy8zY2M3OTM0NC00MzU0LTRjYzAtOTAxYS04YzZhZjgwMThjNTguanBlZ5GTBc0BHcyg" />Były prezydent USA Donald Trump skrytykował w czwartek na swoim portalu społecznościowym zapowiedź dostawy zachodnich czołgów na Ukrainę, sugerując że doprowadzi to do wojny jądrowej&quot;. &quot;Najpierw idą czołgi, potem atomówki&quot; - zauważył.

## Rosyjskie koncerny wiedzą jak ominąć zachodnie sankcje. Korzystają z sieci podwykonawców
 - [https://forsal.pl/swiat/rosja/artykuly/8646608,rosyjskie-koncerny-omijaja-zachodnie-sankcje-sieci-podwykonawcow.html](https://forsal.pl/swiat/rosja/artykuly/8646608,rosyjskie-koncerny-omijaja-zachodnie-sankcje-sieci-podwykonawcow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 17:29:50+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fnfktkuTURBXy80ZGFlMmRhMy1mOTNjLTQ1MTMtODM3YS1lODY2ZTkyNGZjNzIuanBlZ5GTBc0BHcyg" />Rosyjskie państwowe koncerny współpracujące z armią i przemysłem zbrojeniowym, takie jak Rostech, bez przeszkód importują zachodnie podzespoły elektroniczne; dzieje się tak dzięki rozległej sieci podwykonawców, wśród których nie brakuje firm utworzonych specjalnie w celu omijania sankcji - ujawnił niezależny rosyjski serwis Ważnyje Istorii.

## "WSJ": USA chcą by Turcja zawiesiła loty do Rosji z użyciem amerykańskich samolotów
 - [https://forsal.pl/artykuly/8646599,wsj-usa-turcja-zawiesic-loty-rosja-z-uzyciem-amerykanskich-samolotow.html](https://forsal.pl/artykuly/8646599,wsj-usa-turcja-zawiesic-loty-rosja-z-uzyciem-amerykanskich-samolotow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 17:08:46+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/S5wktkuTURBXy82MjhmMzQyMi05NWRjLTQ0ZTctYTM1MS0zNmQ0MTJiNzliYTQuanBlZ5GTBc0BHcyg" />Stany Zjednoczone chcą, aby samoloty pasażerskie amerykańskiej produkcji przestały latać na tureckich połączeniach z Rosją. Waszyngton wywiera w tej sprawie naciski na Ankarę, próbując w ten sposób wyegzekwować sankcje, nałożone na Moskwę po jej inwazji na Ukrainę - informuje w czwartek &quot;Wall Street Journal&quot;.

## Prezydent Biden może odwiedzić Polskę pod koniec lutego
 - [https://forsal.pl/swiat/ukraina/artykuly/8646585,prezydent-biden-moze-odwiedzic-polske-pod-koniec-lutego.html](https://forsal.pl/swiat/ukraina/artykuly/8646585,prezydent-biden-moze-odwiedzic-polske-pod-koniec-lutego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 16:42:17+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ceRktkuTURBXy9iYWZmYjIxNS04NGIyLTRmMmUtOWIxNi1jOWYwNDQyMTA2MWMuanBlZ5GTBc0BHcyg" />Prezydent USA Joe Biden rozważa wizytę w Europie w czasie rocznicy rosyjskiej inwazji na Ukrainę 24 lutego - podały w czwartek telewizje CNN i NBC News, powołując się na źródła w administracji USA. Wśród rozważanych lokalizacji jest Polska.

## Belgijscy laryngolodzy alarmują: Coraz więcej osób cierpi z powodu nadużywania kokainy
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8646579,belgia-laryngolodzy-coraz-wiecej-osob-cierpi-naduzywanie-kokainy.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8646579,belgia-laryngolodzy-coraz-wiecej-osob-cierpi-naduzywanie-kokainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 16:27:48+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q2QktkuTURBXy85MTIzODAzMC0wNTIyLTQ0NTYtOThlMy1iMmQ4NDkwY2Y3YjQuanBlZ5GTBc0BHcyg" />Coraz więcej Belgów ma dziury w przegrodzie nosowej spowodowane zażywaniem kokainy, informuje portal VRT Nws. Portal podaje, że lekarze odnotowują uderzający wzrost liczby pacjentów z poważnymi dolegliwościami nosa spowodowanymi używaniem białego proszku.

## Brytyjczycy wyprodukowali najmniej aut od 66 lat. „Dlaczego jesteśmy tak nisko?”
 - [https://forsal.pl/biznes/przemysl/artykuly/8646370,wielka-brytania-produkcja-aut-najnizsza-od-66-lat.html](https://forsal.pl/biznes/przemysl/artykuly/8646370,wielka-brytania-produkcja-aut-najnizsza-od-66-lat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 16:15:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uP7ktkuTURBXy8xZGM4MjNlZi05MDE5LTQ0YjUtOWExZS05YjM1MzI1NzQ1ZjcuanBlZ5GTBc0BHcyg" />Producenci samochodów w Wielkiej Brytanii zaliczyli najgorszy rok od ponad sześciu dekad. Braki na rynku półprzewodników i zamknięcia kluczowych fabryk w kraju zmniejszyły produkcję aut.

## Prosumenci wytwarzają średnio pięć razy węcej energii niż zurzywają
 - [https://forsal.pl/biznes/energetyka/artykuly/8646575,prosumenci-wytwarzaja-srednio-piec-razy-wecej-energii-niz-zurzywaja.html](https://forsal.pl/biznes/energetyka/artykuly/8646575,prosumenci-wytwarzaja-srednio-piec-razy-wecej-energii-niz-zurzywaja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 16:12:10+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xeqktkuTURBXy8zZjMxZWNkZC0zY2QzLTQ2OTgtODM5Yy0zYjViZTcxZjQwYjkuanBlZ5GTBc0BHcyg" />Prosumenci zużywają średniorocznie jedynie około 20 procent prądu ze swoich domowych instalacji fotowoltaicznych; reszta wytworzonej w nich energii trafia do sieci dystrybucyjnej - wynika z analiz grupy Tauron. Energetycy zachęcają wytwórców prądu ze słońca, by zużywali go więcej.

## Udział energetyki jądrowej w polskim miksie w 2045 r. może wynieść 17,8-35,8 proc.
 - [https://forsal.pl/biznes/energetyka/artykuly/8646572,udzial-energetyki-jadrowej-polska-miks-2045-r-wyniesc-178-358-proc.html](https://forsal.pl/biznes/energetyka/artykuly/8646572,udzial-energetyki-jadrowej-polska-miks-2045-r-wyniesc-178-358-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 16:05:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JgSktkuTURBXy9hOTZkOWVjNS02MThmLTRiN2UtYjg5Ny1jODA1MzVjYWFmMjMuanBlZ5GTBc0BHcyg" />Udział energetyki jądrowej w strukturze wytwarzania w Polsce może, w zależności od scenariusza, wynieść w 2045 roku 17,8-35,8 proc. - wynika z raportu „Łańcuch wartości energetyki jądrowej w Polsce”.

## DZIEŃ NA FX/FI: EUR/PLN nie pokonał oporu; rynek FX i FI czeka na dane inflacyjne oraz posiedzenie Fed
 - [https://forsal.pl/finanse/waluty/artykuly/8646571,dzien-na-fxfi-eurpln-nie-pokonal-oporu.html](https://forsal.pl/finanse/waluty/artykuly/8646571,dzien-na-fxfi-eurpln-nie-pokonal-oporu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 15:59:29+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KVJktkuTURBXy9hZTY0YTU2Yi0wZGJiLTQ5ZmEtYTE4Yi1iNzQ2Y2IxY2I3NGUuanBlZ5GTBc0BHcyg" />Próba pokonania oporu na 4,7240 przez EUR/PLN nie udała się w czwartek, gdyż rynku nie wsparł dolar amerykański, pomimo lepszych od oczekiwań danych makro z USA - powiedział PAP Biznes ekonomista Banku Millennium, Mateusz Sutowicz. Inwestorzy czekają na piątkowe dane inflacyjne ze Stanów Zjednoczonych, które - według niego - mogą mieć wpływ na zachowanie zarówno rynku FX, jak i długu.

## "Economist": Postawa Niemiec była na rękę Moskwie i nadwyrężyła jedność NATO
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646568,economist-postawa-niemiec-byla-na-reke-moskwie-i-nadwyrezyla-jednosc-nato.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646568,economist-postawa-niemiec-byla-na-reke-moskwie-i-nadwyrezyla-jednosc-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 15:51:45+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0VoktkuTURBXy80OTczNGNmMy0wM2MwLTRmYjYtYTJlYS0yMThkYjQwOWNjY2IuanBlZ5GTBc0BHcyg" />Kanclerz Niemiec Olaf Scholz, który wahał się, czy dostarczyć Ukrainie Leopardy, wystawił na próbę wspólny front państw NATO wobec agresji ze strony Rosji. Nie służyło to nikomu poza Kremlem. Berlin ocenia jednak, że odniósł dyplomatyczne zwycięstwo - pisze &quot;Economist&quot;.

## Wizz Air zaprasza do 6 nowych destynacji. W podróż do i z Polski zabierze ponad 12 mln turystów
 - [https://forsal.pl/transport/lotnictwo/artykuly/8646562,wizz-air-6-nowych-destynacji-podroz-do-i-z-polski-12-mln-turystow.html](https://forsal.pl/transport/lotnictwo/artykuly/8646562,wizz-air-6-nowych-destynacji-podroz-do-i-z-polski-12-mln-turystow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 15:21:57+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UA3ktkuTURBXy84MmZhNmUxZS1hOTUxLTRlYzItOTU2Mi05NDE5ZmEzZDI1MTQuanBlZ5GTBc0BHcyg" />Wizz Air zaoferuje ponad 12 mln miejsc w sprzedaży do/z Polski w tym roku, podał przewoźnik. Wielkość ta uwzględnia ogłoszony dziś rozwój na Lotnisku Chopina w Warszawie i nową trasę z Katowic do Erywania w Armenii.

## GS: Tegoroczne wahania inflacyjne odbiją się negatywnie na rynkach finansowych
 - [https://forsal.pl/gospodarka/pkb/artykuly/8646559,gs-tegoroczne-wahania-inflacyjne-odbija-sie-negatywnie-na-rynkach-finansowych.html](https://forsal.pl/gospodarka/pkb/artykuly/8646559,gs-tegoroczne-wahania-inflacyjne-odbija-sie-negatywnie-na-rynkach-finansowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 15:14:02+00:00
 - user: None



## Lockheed Martin zwiększy produkcję F-16 na potrzeby krajów wspierających Ukrainę
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646538,lockheed-martin-zwiekszy-produkcje-f-16-na-potrzeby-krajow-wspierajacych-ukraine.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646538,lockheed-martin-zwiekszy-produkcje-f-16-na-potrzeby-krajow-wspierajacych-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 14:47:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QHDktkuTURBXy85ZDM4N2NkMi0yYTc1LTQyMTQtYjAxZi03MWFiYWVlMGE1ODguanBlZ5GTBc0BHcyg" />Koncern zbrojeniowy Lockheed Martin zamierza zwiększyć produkcję samolotów F-16 w swojej fabryce w Karolinie Północnej, by móc uzupełnić zasoby krajów wysyłających samoloty na Ukrainę - powiedział dziennikowi &quot;Financial Times&quot; dyrektor operacyjny spółki Frank St. John. Dodał, że w sprawie toczy się &quot;wiele rozmów&quot;.

## MAEA: Iran ma dość wzbogaconego uranu by zbudować kilka pocisków jądrowych
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646524,maea-iran-ma-dosc-wzbogaconego-uranu-by-zbudowac-kilka-pociskow-jadrowych.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646524,maea-iran-ma-dosc-wzbogaconego-uranu-by-zbudowac-kilka-pociskow-jadrowych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 14:28:52+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mMHktkuTURBXy9kODI2ODA4YS01N2M5LTQ0OTQtODkxZS02ZjVhMGI3Y2FmOWUuanBlZ5GTBc0BHcyg" />Rafael Grossi, szef Międzynarodowej Agencji Energii Atomowej (MAEA), stwierdził, że zapasów irańskiego wzbogaconego uranu wystarczy nie na jeden, ale na kilka pocisków nuklearnych - podała agencja AP.

## PKB wzrośnie w Polsce o 0,5 proc. Stopy proc. pozostaną na obecnym poziomie, ocenia EY
 - [https://forsal.pl/gospodarka/pkb/artykuly/8646516,pkb-polska-05-proc-stopy-proc-na-obecnym-poziomie-ocenia-ey.html](https://forsal.pl/gospodarka/pkb/artykuly/8646516,pkb-polska-05-proc-stopy-proc-na-obecnym-poziomie-ocenia-ey.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 14:19:52+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pCJktkuTURBXy9hZTZkNWYyMi00ZTBjLTQ4MDctOGNlZi00YzU0ZTJjZGNiOGEuanBlZ5GTBc0BHcyg" />PKB wzrośnie w Polsce o 0,5 proc. w 2023 r., przyspieszając w kolejnych latach do 2,3 proc. w 2024 r. i 3,4 proc. w 2025 r., wynika raportu EY &quot;Global Economic Outlook. A European perspective&quot;. W scenariuszu bazowym w Polsce zostaną utrzymane stopy procentowe na obecnym poziomie w 2023 r. Inflacja w Polsce swój szczyt osiągnie w lutym, prawdopodobnie nieco poniżej 20 proc. r/r.

## Brytyjskie czołgi dotrą na Ukrainę w marcu. Żołnierze rozpoczną szkolenia 30 stycznia
 - [https://forsal.pl/swiat/brexit/artykuly/8646512,brytyjskie-czolgi-dotra-na-ukraine-w-marcu-szkolenia-od-30-stycznia.html](https://forsal.pl/swiat/brexit/artykuly/8646512,brytyjskie-czolgi-dotra-na-ukraine-w-marcu-szkolenia-od-30-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 14:10:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uUwktkuTURBXy85M2UzM2I0YS04ZjIxLTQ4MzktYjIwNC1hMzI3NTg0MTI2NGIuanBlZ5GTBc0BHcyg" />Wielka Brytania rozpocznie w przyszłym tygodniu szkolenie ukraińskich żołnierzy w zakresie obsługi i naprawy wysyłanych do tego kraju czołgów Challenger 2, zaś celem jest, by same czołgi dotarły przed końcem marca - ogłosił w czwartek wiceminister obrony Alex Chalk.

## Rosyjscy i irańscy hakerzy atakują brytyjskich polityków, media i naukowców
 - [https://forsal.pl/swiat/brexit/artykuly/8646504,rosyjscy-iranscy-hakerzy-atakuja-brytyjskich-politykow-media-naukowcow.html](https://forsal.pl/swiat/brexit/artykuly/8646504,rosyjscy-iranscy-hakerzy-atakuja-brytyjskich-politykow-media-naukowcow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 13:42:08+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YNzktkuTURBXy8wYmE3MTUwNi1iOTc5LTRhYjctYjJhOS0wYTdmYmFlYWRkYmQuanBlZ5GTBc0BHcyg" />Powiązani z państwem rosyjscy i irańscy hakerzy coraz częściej biorą na cel brytyjskich polityków, dziennikarzy i naukowców w swych spear-phishingowych atakach - ostrzegło w czwartek brytyjskie Narodowe Centrum Cyberbezpieczeństwa (NCSC).

## Musimy lepiej chronić dzieci w sporach transgranicznych. Wezwanie Komisji Europejskiej
 - [https://forsal.pl/swiat/unia-europejska/artykuly/8646491,komisja-europejska-polska-ochrona-dzieci-spory-transgraniczne.html](https://forsal.pl/swiat/unia-europejska/artykuly/8646491,komisja-europejska-polska-ochrona-dzieci-spory-transgraniczne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 13:22:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3R6ktkuTURBXy83NjQ5NTRiNy00NDRlLTRhM2ItOTQxNS0yZTU5MGE4MjdmYjkuanBlZ5GTBc0BHcyg" />Komisja Europejska wezwała Polskę do usunięcia uchybienia w związku z niezapewnieniem ochrony dzieci w transgranicznych postępowaniach z zakresu prawa rodzinnego.

## Treści o charakterze terrorystycznym w polskiej sieci nie są odpowiednio kontrolowane
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646479,komisja-europejska-polska-wdrozenie-rozporzadzenia-cyberterroryzm.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646479,komisja-europejska-polska-wdrozenie-rozporzadzenia-cyberterroryzm.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 13:14:37+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8SMktkuTURBXy8zMGE4YzBjMC00YWQxLTQ1YjgtYmNjYy00ZTc2YWVlZjc1YTAuanBlZ5GTBc0BHcyg" />Komisja Europejska wezwała Polskę do usunięcia uchybienia w związku z nieprawidłowym wdrożeniem rozporządzenia UE w sprawie przeciwdziałania rozpowszechnianiu w internecie treści o charakterze terrorystycznym.

## Komisja Europejska: Polsko, musisz zredukować emisje zanieczyszczeń
 - [https://forsal.pl/biznes/ekologia/artykuly/8646475,komisja-europejska-polska-redukcja-emicji-zanieczyszczen.html](https://forsal.pl/biznes/ekologia/artykuly/8646475,komisja-europejska-polska-redukcja-emicji-zanieczyszczen.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 13:07:21+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n6KktkuTURBXy8yMWExOTJiOS01YTQzLTQxNTAtOGViNy00MzQ0OGZhY2ViNDMuanBlZ5GTBc0BHcyg" />Komisja Europejska wezwała Polskę do redukcji emisji zanieczyszczeń powietrza, zgodnie z wymogami zawartymi w dyrektywie 2016/2284 w sprawie redukcji krajowych emisji niektórych rodzajów zanieczyszczeń atmosferycznych, poinformowała Komisja.

## Rząd wycofuje się z kontrowersyjnych przepisów, które miały rozszerzać zakres inwigilacji
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646466,rzad-inwigilacja-wycofanie.html](https://forsal.pl/gospodarka/polityka/artykuly/8646466,rzad-inwigilacja-wycofanie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 13:02:38+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/rK4ktkuTURBXy8yNjE4YzE2YS1jMjAyLTQ4NzUtYmQxYS0xYmI4N2YzM2VhOTMuanBlZ5GTBc0BHcyg" />Rząd jednak wycofuje się z kontrowersyjnych przepisów, które miały rozszerzać zakres inwigilacji. Firmy dostarczające usług takich jak poczta elektroniczna czy komunikatory nie będą musiały przechowywać danych i udostępniać ich na każde wezwanie służb. Jako pierwszy informację tę podał portal Interia.pl.

## Polska czwartym największym rynkiem dla Europejskiego Bank Odbudowy i Rozwoju
 - [https://forsal.pl/biznes/bankowosc/artykuly/8646448,ebor-polska-czwartym-najwiekszym-rynkiem.html](https://forsal.pl/biznes/bankowosc/artykuly/8646448,ebor-polska-czwartym-najwiekszym-rynkiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:50:04+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tf0ktkuTURBXy82MDcyZDdmMC1hODI1LTRhN2YtYTU3Ny05MDAyMjQyOTliNTcuanBlZ5GTBc0BHcyg" />Europejski Bank Odbudowy i Rozwoju (EBOR) zainwestował w Polsce rekordowe 990 mln euro w 2022 roku, wobec 600 mln euro w 2021 roku, podał Bank. To sprawiło, że Polska była czwartym największym rynkiem dla EBOR w minionym roku.

## Małe i średnie ukraińskie przedsiębiorstwa otrzymają wsparcie. KredoBank, Komisja Europejska i BGK podpisały umowę
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8646437,wsparcie-dla-ukrainskich-msp-kredobank-komisja-europejska-bgk.html](https://forsal.pl/biznes/aktualnosci/artykuly/8646437,wsparcie-dla-ukrainskich-msp-kredobank-komisja-europejska-bgk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:39:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LPfktkuTURBXy8zMzc4YTJlOS0wNTBjLTQ0NjMtYWM0Ni1lYjI3ODI5MzA1MDkuanBlZ5GTBc0BHcyg" />Komisja Europejska (KE), Bank Gospodarstwa Krajowego (BGK) i ukraiński KredoBank podpisały umowę wsparcia dla małych i średnich przedsiębiorstw (MSP) w Ukrainie do 20 mln euro, podał BGK. Pierwszy etap projektu zakłada 10 mln euro. Pomoc będzie udzielana w formie gwarancji BGK zabezpieczających kredyt przyznawany przez KredoBank.

## Projekt nowelizacji Kodeksu wyborczego ponownie skierowany do komisji
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646430,nowelizacja-kodeks-wyborczy-komisja.html](https://forsal.pl/gospodarka/polityka/artykuly/8646430,nowelizacja-kodeks-wyborczy-komisja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:26:15+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kJZktkuTURBXy80MmNiYzM2NC00NTdkLTQ0ZjktOTA4ZC1jMmY5OWZjYWRkZjUuanBlZ5GTBc0BHcyg" />Z uwagi na zgłoszone poprawki, projekt nowelizacji Kodeksu wyborczego został w czwartek ponownie skierowany do Komisji nadzwyczajnej ds. zmian w kodyfikacjach. Ponad 20 poprawek zgłosiła Barbara Bartuś z PiS, mają one - jak mówiła - charakter &quot;techniczno-organizacyjny&quot;.

## Największe od ponad 20 lat koszty katastrof naturalnych we Francji
 - [https://forsal.pl/biznes/ekologia/artykuly/8646424,francja-koszty-katastrof-naturalnych.html](https://forsal.pl/biznes/ekologia/artykuly/8646424,francja-koszty-katastrof-naturalnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:19:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sjYktkuTURBXy9iMWVjZmNhMS04MDNjLTQwZDEtODk0YS04NDA1MGRhZDA0Y2EuanBlZ5GTBc0BHcyg" />W 2022 roku koszty coraz częstszych i coraz bardziej dotkliwych klęsk żywiołowych we Francji wyniosły 10 mld euro - poinformowało w czwartek stowarzyszenie branży ubezpieczeniowej France Assureurs. Dodano, że ostatni raz taki poziom strat odnotowano w 1999 roku.

## Większość Niemców chce wysłać czołgi do Ukrainy. Radykalna prawica przeciwna
 - [https://forsal.pl/swiat/ukraina/artykuly/8646418,niemcy-czolgi-dla-ukrainy-opinia-publiczna.html](https://forsal.pl/swiat/ukraina/artykuly/8646418,niemcy-czolgi-dla-ukrainy-opinia-publiczna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:13:56+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Os-ktkuTURBXy84ODRmNTZjNy00NWI0LTRjNzItOTE4Mi00MmFiYTYxOGQ3MGQuanBlZ5GTBc0BHcyg" />Większość Niemców (53 proc.) popiera środową decyzję rządu federalnego o dostawie czołgów na Ukrainę – wynika z opublikowanego w czwartek sondażu, przeprowadzonego przez instytut badania opinii publicznej Forsa dla „Trendbarometru” RTL/ntv.

## Waloryzacja rent i emerytur. Ile wyniesie?
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8646416,waloryzacja-renty-emerytury.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8646416,waloryzacja-renty-emerytury.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 12:09:02+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0lAktkuTURBXy8yMzA5Yjk5Mi0wNzJlLTRkZDAtYTdmZS03MGY0M2IzMTA3ZTUuanBlZ5GTBc0BHcyg" />Wszystko wskazuje na to, że waloryzacja rent i emerytur będzie na poziomie 14,8 proc. – przekazała w czwartek minister rodziny i polityki społecznej Marlena Maląg. Prezes ZUS prof. Gertruda Uścińska poinformowała, że koszt tegorocznej waloryzacji przekroczy 40 mld zł.

## Węgry uzgodniły z Rosją przyspieszenie rozbudowy elektrowni jądrowej Paks
 - [https://forsal.pl/swiat/rosja/artykuly/8646411,wegry-rosja-elektrownia-jadrowa-paks.html](https://forsal.pl/swiat/rosja/artykuly/8646411,wegry-rosja-elektrownia-jadrowa-paks.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:59:28+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nCpktkuTURBXy9lMmVkYmQ1OS1mYjhkLTRmYWEtYWE4MS02NmNmOTZkZTcyMTguanBlZ5GTBc0BHcyg" />W rozmowie telefonicznej z Aleksandrem Nowakiem, ministrem energetyki Rosji, uzgodniliśmy przyspieszenie budowy nowych bloków elektrowni jądrowej w Paks, tam, gdzie to możliwe - poinformował w czwartek przebywający w USA minister spraw zagranicznych i handlu Węgier Peter Szijjarto.

## NASA: Nad Ziemią przeleci dzisiaj niewielka planetoida
 - [https://forsal.pl/lifestyle/nauka/artykuly/8646408,nasa-planetoida-nad-ziemia.html](https://forsal.pl/lifestyle/nauka/artykuly/8646408,nasa-planetoida-nad-ziemia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:54:23+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3OLktkuTURBXy80M2ZmNzI1NS1mZTY1LTRiYTUtODM0NS1lNmRkZTk2NDY5M2YuanBlZ5GTBc0BHcyg" />W czwartek Ziemię - na niewielkiej wysokości nad powierzchnią - minie niewielka planetoida. Przelot nie zagraża zderzeniem z Ziemią - poinformowała Amerykańska Agencja Kosmiczna NASA.

## Poważna awaria na kolei. Pęknięta szyna paraliżuje ruch w Warszawie
 - [https://forsal.pl/transport/kolej/artykuly/8646406,awaria-kolej-warszawa-skm-opoznienia-pkp-intercity-koleje-mazowieckie.html](https://forsal.pl/transport/kolej/artykuly/8646406,awaria-kolej-warszawa-skm-opoznienia-pkp-intercity-koleje-mazowieckie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:48:34+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DRRktkuTURBXy80NGYwODUyMS1hOTBiLTRjMjctOGZlYi1jYzAyZTA1MWIyNzguanBlZ5GTBc0BHcyg" />Poważna awaria na kolei. Z powodu pękniętej szyny w jednym z torów na podmiejskiej linii średnicowej występują utrudnienia w ruchu pociągów wszystkich przewoźników na odcinku Warszawa Wschodnia - Warszawa Zachodnia. Niektóre pociągi mogą być opóźnione, odwołane lub skrócone - informują Koleje Mazowieckie.

## Szczepionka Pfizera badana w związku z większą liczbą udarów mózgu u seniorów
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8646399,szczepionka-pfizer-covid-udary-mozgu.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8646399,szczepionka-pfizer-covid-udary-mozgu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:37:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Qt3ktkuTURBXy83MTk4OWYyZi05MWI1LTQ1ZmYtOGQ1ZS1hMDhkMTc5YjNmYmQuanBlZ5GTBc0BHcyg" />Dane dotyczące szczepień przeciwko COVID-19 amerykańskiego Centrum Prewencji i Kontroli Chorób (CDC) sugerują, że u seniorów zaszczepionych biwalentną szczepionką Pfizera stwierdzono więcej przypadków udaru mózgu. Nie ma jednak pewności, czy między jednym a drugim jest związek przyczynowy.

## Wydatki Funduszu Przeciwdziałania COVID-19 w 2023 roku będą znacznie niższe
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8646394,fundusz-przeciwdzialania-covid-19-wydatki-2023.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8646394,fundusz-przeciwdzialania-covid-19-wydatki-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:31:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XSzktkuTURBXy8xZGE5OTkwOC1jMzQ4LTRhMzYtYjcxNS04NTJiOWY2ZTVlNDAuanBlZ5GTBc0BHcyg" />W ramach Funduszu Przeciwdziałania COVID-19 w tym roku ma zostać wydane blisko 25 mld zł, wynika z udostępnionego Business Insider Polska planu finansowego. Tegoroczne nakłady Funduszu mają być znacznie mniejsze niż w 2022 r., kiedy jego beneficjenci wydali 43,2 mld zł, podkreślił portal.

## Amber Gold dla bogatych. Fundusz inwestycyjny profesora Uniwersytetu Gdańskiego pod lupą prokuratury
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8646390,fundusz-inwestycyjny-profesor-uniwersytet-gdanski-prokuratura.html](https://forsal.pl/biznes/aktualnosci/artykuly/8646390,fundusz-inwestycyjny-profesor-uniwersytet-gdanski-prokuratura.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:21:46+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/XzBktkuTURBXy8xMTczYjlhNC03ZmZhLTQ0MmUtODZhMC1jODZkMDVlOGMxYzEuanBlZ5GTBc0BHcyg" />Sześć osób złożyło zawiadomienia o popełnieniu przestępstwa w związku z działalnością funduszu inwestycyjnego, którego założycielem jest znany profesor Uniwersytetu Gdańskiego. Pokrzywdzeni ponieśli milionowe straty, a sprawą zajmuje się Centralne Biuro Śledcze Policji - ustaliła PAP.

## Leopardy z zasobów Bundeswehry trafią do Ukrainy do końca marca
 - [https://forsal.pl/swiat/ukraina/artykuly/8646376,niemcy-ukraina-leopardy-marzec.html](https://forsal.pl/swiat/ukraina/artykuly/8646376,niemcy-ukraina-leopardy-marzec.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:11:05+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q12ktkuTURBXy9mOWE1ZTJiNi00N2M1LTQ4YTUtYWMzYi1iNmViZWMzYWY4NDMuanBlZ5GTBc0BHcyg" />Minister obrony RFN Boris Pistorius zapowiedział dostarczenie Ukrainie niemieckich czołgów Leopard 2 do końca marca. Kijów otrzyma czołgi &quot;do końca pierwszego kwartału&quot; – poinformował Pistorius w czwartek w trakcie wizytacji wojsk w Saksonii-Anhalt.

## Poprawki do nowelizacji Kodeksu pracy. Co proponuje Lewica?
 - [https://forsal.pl/praca/aktualnosci/artykuly/8646374,nowelizacja-kodeks-pracy-poprawki-lewicy.html](https://forsal.pl/praca/aktualnosci/artykuly/8646374,nowelizacja-kodeks-pracy-poprawki-lewicy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 11:04:38+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/AhzktkuTURBXy8wY2MzMDczMi0yZWM4LTQ5NjctODQ2Ny1mNDU3YTBlMTg2ODQuanBlZ5GTBc0BHcyg" />Prawo do posługiwania się służbowym mailem do działalności związkowej, a także zrównanie wynagrodzeń kobiet i mężczyzn na urlopach rodzicielskich - to niektóre poprawki klubu Lewicy do nowelizacji Kodeksu pracy, która ma być w czwartek omawiana w Sejmie.

## Strajki pracowników we Francji. Dostawy z kilku rafinerii zakłócone
 - [https://forsal.pl/praca/aktualnosci/artykuly/8646357,francja-strajki-pracownicze-totalenergies.html](https://forsal.pl/praca/aktualnosci/artykuly/8646357,francja-strajki-pracownicze-totalenergies.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:43:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MCvktkuTURBXy9jNDY5NDc5Yy02Y2U5LTRkZGMtOTZhNy03NmVlZGVjYzAxYWQuanBlZ5GTBc0BHcyg" />Koncern paliwowy TotalEnergies poinformował w czwartek, że trwające akcje strajkowe, w których bierze udział 60 proc. pracowników tej firmy, zakłóciły dostawy z kilku rafinerii we Francji. Strajkujący protestują przeciwko rządowym planom podniesienia wieku emerytalnego.

## Pamiętasz preferencje swoich klientów? Chętniej do ciebie wrócą [BADANIE]
 - [https://forsal.pl/biznes/handel/artykuly/8646355,adobe-preferencje-klientow.html](https://forsal.pl/biznes/handel/artykuly/8646355,adobe-preferencje-klientow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:38:57+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w1HktkuTURBXy80YWFmMDgzYi0zNmE2LTRiNmEtOTI5Ni1kYmEzZmRkOTk3MjguanBlZ5GTBc0BHcyg" />Tworzenie spersonalizowanych produktów i usług będzie jednym z popularnych sposobów na kreację pozytywnych doświadczeń u klientów w 2023 r. Aż 91 proc. konsumentów chętniej robi zakupy w firmach, które pamiętają ich preferencje – wynika z raportu.

## Wielka fabryka broni dla Ukrainy ­w Polsce? "Model darowizn jest w dłuższej perspektywie nie do utrzymania"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646353,polska-fabryka-broni-dla-ukrainy.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646353,polska-fabryka-broni-dla-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:32:33+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WsgktkuTURBXy9mOTc4ZTBhOS1jMmZjLTRkNzUtYWZmOS03YjhkMmUxMGYyOGUuanBlZ5GTBc0BHcyg" />Aby pomóc Ukrainie wygrać wojnę, w Polsce musi powstać ogromna fabryka broni, bo obecny model darowizn jest w dłuższej perspektywie nie do utrzymania - powiedział w czwartek szef komisji obrony w brytyjskiej Izbie Gmin Tobias Ellwood.

## Zeroemisyjna flota InPost dostarczyła prawie 30 mln paczek
 - [https://forsal.pl/transport/aktualnosci/artykuly/8646345,inpost-samochody-elektryczne.html](https://forsal.pl/transport/aktualnosci/artykuly/8646345,inpost-samochody-elektryczne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:26:20+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/RB8ktkuTURBXy8zMDJhZTRhMC1lMWE2LTRkYjItOWNiMC00YTM1MWI0MzA0MWYuanBlZ5GTBc0BHcyg" />InPost dostarczył w ubiegłym roku 29,94 mln przesyłek przy wykorzystaniu zeroemisyjnej floty samochodów elektrycznych. Na koniec 2022 r. po polskich drogach poruszało się 463 takich pojazdów z logo InPost, które pokonały w ub.r. łącznie prawie 8 mln km, podała spółka.

## Świat według bankowców. Jaki będzie 2023 rok?
 - [https://forsal.pl/biznes/bankowosc/artykuly/8646342,monitor-bankowy-mindroses-euro-nastroje.html](https://forsal.pl/biznes/bankowosc/artykuly/8646342,monitor-bankowy-mindroses-euro-nastroje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:22:01+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ax7ktkuTURBXy9iNDZkZWNlZi00Zjc4LTQ0MDItOGIwZi04M2U5NThiMTBiNzIuanBlZ5GTBc0BHcyg" />Bankowcy oczekują, że kurs euro wobec złotego wyniesie 4,68 na koniec stycznia 2023 r., wynika z &quot;Monitora Bankowego&quot;, opublikowanego przez firmę badawczą Mind&amp;amp;Roses. Oczekiwania wobec kursu USD/PLN to 4,39 zł, a dla kursu CHF/PLN - 4,47 zł. Mniej niż połowa badanych bankowców - 43 proc. - uważa, że 2023 rok będzie dla bankowości gorszy niż poprzedni, 27 proc. badanych spodziewa się, że 2023 rok będzie lepszy, natomiast według 30 proc., 2023 rok będzie porównywalny z poprzednim, wynika z badania Mind&amp;amp;Roses.

## Akcjonariusze Render Cube zdecydują 21 II o ubieganiu się o przejście na rynek główny GPW
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8646339,akcjonariusze-render-cube-zdecyduja-21-ii-o-ubieganiu-sie-o-przejscie-na-rynek-glowny-gpw.html](https://forsal.pl/biznes/aktualnosci/artykuly/8646339,akcjonariusze-render-cube-zdecyduja-21-ii-o-ubieganiu-sie-o-przejscie-na-rynek-glowny-gpw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:17:40+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />Render Cube zwołało na 21 lutego nadzwyczajne walne zgromadzenie, na którym akcjonariusze zdecydują o dopuszczeniu i wprowadzeniu akcji do obrotu na rynku regulowanym, podała spółka. Przejściu z NewConnect nie będzie towarzyszyła emisja akcji.

## Na pracy zdalnej zyskujemy prawie godzinę życia dziennie
 - [https://forsal.pl/praca/aktualnosci/artykuly/8646335,praca-zdalna-oszczdnosc-czasu.html](https://forsal.pl/praca/aktualnosci/artykuly/8646335,praca-zdalna-oszczdnosc-czasu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:10:33+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/EXlktkuTURBXy81NTIyYmRlMS1lNDE5LTQ2ZGUtOTYwMC1kZjViMmQ2ZjMwYWIuanBlZ5GTBc0BHcyg" />W Polsce praca zdalna pozwala oszczędzić zatrudnionym średnio 54 minuty dziennie - wskazali analitycy Polskiego Instytutu Ekonomicznego. Czas ten przeznaczają głównie na odpoczynek i jakąś formę pracy - dodali.

## Dziennikarka DGP Klara Klinger wyróżniona w konkursie Lider Roku 2022 w Ochronie Zdrowia
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/8646501,dziennikarka-dgp-klara-klinger-wyroznienie-lider-roku-2022-w-ochronie-zdrowia.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/8646501,dziennikarka-dgp-klara-klinger-wyroznienie-lider-roku-2022-w-ochronie-zdrowia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 10:00:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OfuktkuTURBXy9iYjE0NDZhYy1jZDY2LTQ4MjItYmU4Zi01MzhmODU1NzRhYWQuanBlZ5GTBc0BHcyg" />Klara Klinger, dziennikarka „Dziennika Gazety Prawnej”, otrzymała wyróżnienie w kategorii media i public relations w 22. edycji konkursu Lider Roku 2022 w Ochronie Zdrowia.

## KO chce odrzucić pisowski projektu noweli Kodeksu wyborczego. "Może ubyć nawet pół miliona głosów"
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646318,nowela-kodeksu-wyborczego-pis-wniosek-o-odrzucenie-ko.html](https://forsal.pl/gospodarka/polityka/artykuly/8646318,nowela-kodeksu-wyborczego-pis-wniosek-o-odrzucenie-ko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 09:55:04+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UiPktkuTURBXy80MGI0NGM4My00MGM0LTRhYmMtOGU0NS04NGY0ODhkYjkyMDEuanBlZ5GTBc0BHcyg" />Składamy wniosek o odrzucenie projektu PiS nowelizacji Kodeksu wyborczego; jeśli zostanie on odrzucony, zgłosimy poprawki, między innymi przywracającą głosowanie korespondencyjne - zapowiedział w czwartek w Sejmie poseł KO Robert Kropiwnicki.

## Nokia idzie w górę dzięki 5G. Zysk firmy zaskoczył analityków
 - [https://forsal.pl/artykuly/8646309,nokia-5g-zysk-zaskoczyl-analitykow.html](https://forsal.pl/artykuly/8646309,nokia-5g-zysk-zaskoczyl-analitykow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 09:42:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VwSktkuTURBXy9hMjlmYjhjMy1jYWQ5LTRmNWItOTA1ZS02ZmE5ZTcxOTRlMzQuanBlZ5GTBc0BHcyg" />Nokia odnotowała wyższe zyski niż pierwotnie oczekiwano – wynika z oświadczenia firmy, która jest dostawcą sprzętu 5G. Popyt „pozostaje silny” nawet w obliczu gorszej sytuacji makroekonomicznej.

## W ciągu najbliższych 5 lat polskie inwestycje bezpośrednie w Ukrainie wzrosną trzydziestokrotnie
 - [https://forsal.pl/gospodarka/inwestycje/artykuly/8646306,polska-ukraina-inwestycje-bezposrednie.html](https://forsal.pl/gospodarka/inwestycje/artykuly/8646306,polska-ukraina-inwestycje-bezposrednie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 09:41:26+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aXrktkuTURBXy82NWNiODJkMC0yOWIyLTRjMDItOGYyMS0zODM1N2IyMGZmZWYuanBlZ5GTBc0BHcyg" />Polskie inwestycje bezpośrednie (BIZ) w Ukrainie mogą wzrosnąć do 30 mld USD w ciągu najbliższych 5 lat, wynika z szacunków Polskiego Instytutu Ekonomicznego (PIE).

## Nalot na Zachodnim Brzegu. Wojska izraelskie zabiły co najmniej osiem osób
 - [https://forsal.pl/artykuly/8646291,palestyna-izrael-nalot-na-zachodnim-brzegu.html](https://forsal.pl/artykuly/8646291,palestyna-izrael-nalot-na-zachodnim-brzegu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 09:23:12+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UuNktkuTURBXy8wOTlkMWJiZC01MWQ4LTQ1Y2UtYjE4ZC1hYzc2YWJlZTZlYjcuanBlZ5GTBc0BHcyg" />Wojska izraelskie zabiły co najmniej osiem osób, w tym 60-letnią kobietę, podczas nalotu na obóz uchodźców w mieście Dżenin na północy okupowanego Zachodniego Brzegu w czwartek rano - przekazało ministerstwo zdrowia Autonomii Palestyńskiej. Reuters, powołując się na świadków, informuje z kolei o pięciu zabitych i 16 rannych.

## Ilu uchodźców wojennych z Ukrainy chce na stałe zostać w Polsce? [BADANIE]
 - [https://forsal.pl/swiat/ukraina/artykuly/8646280,manpower-badanie-uchodxcy-z-ukrainy.html](https://forsal.pl/swiat/ukraina/artykuly/8646280,manpower-badanie-uchodxcy-z-ukrainy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 09:01:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2ERktkuTURBXy9kOGE0ZGM3Yi0wZGQ4LTRjODQtYTQxYi0yZmRjMTE3ZDdkOTMuanBlZ5GTBc0BHcyg" />Ponad 2/5 uchodźców wojennych z Ukrainy (42 proc.) planuje na dłużej osiąść w Polsce, co piąty chce wrócić do Ukrainy, ale w dłuższej perspektywie, wynika z badania „Sytuacja zawodowa uchodźców z Ukrainy w Polsce&quot; zrealizowanego przez Manpower i Fundację Totalizatora Sportowego. 14 proc. uchodźców planuje powrót do 3 lat od zakończenia wojny.

## Kiedy Sejm przyjmie ustawę wiatrakową? "Na tym posiedzeniu chyba nie zdążymy"
 - [https://forsal.pl/biznes/energetyka/artykuly/8646278,ustawa-wiatrakowa-sejm-piotr-muller.html](https://forsal.pl/biznes/energetyka/artykuly/8646278,ustawa-wiatrakowa-sejm-piotr-muller.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:53:27+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PuCktkuTURBXy85YjE1NTUyNS1mMDlkLTQ5M2ItODI4My1kNGFkMjg3NThlZmEuanBlZ5GTBc0BHcyg" />Sejm przyjmie nowelizacją ustawy o inwestycjach w zakresie elektrowni wiatrowych prawdopodobnie na kolejnym posiedzeniu, wynika z wypowiedzi rzecznika rządu Piotra Mullera. Projektowana nowelizacja zakłada odejście od zasady 10H, czyli od zakazu lokowania elektrowni w promieniu wyznaczonym przez odległość równą dziesięciokrotności całkowitej wysokości projektowanej elektrowni wiatrowej do zabudowy mieszkaniowej.

## Wybuch w Kijowie. Mieszkańcy proszeni o pozostanie w schronach
 - [https://forsal.pl/swiat/ukraina/artykuly/8646267,ukraina-wybuch-w-kijowie.html](https://forsal.pl/swiat/ukraina/artykuly/8646267,ukraina-wybuch-w-kijowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:32:11+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DbnktkuTURBXy81OWUzMWFhMy0wZGNlLTQzYjEtYTRjYy02ZTE5YTQ2YWNlMjAuanBlZ5GTBc0BHcyg" />O wybuchu w Kijowie poinformował w czwartek mer ukraińskiej stolicy Witalij Kliczko w czasie, gdy trwa rosyjski atak rakietowy i w regionach Ukrainy ogłoszono alarm przeciwlotniczy. Kliczko zaapelował do mieszkańców o pozostanie w schronach.

## Reddit, SpaceX, Discord. To może być rok wielkich debiutów giełdowych
 - [https://forsal.pl/finanse/gielda/artykuly/8646273,najwieksze-debiuty-gieldowe-2023.html](https://forsal.pl/finanse/gielda/artykuly/8646273,najwieksze-debiuty-gieldowe-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:30:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3t2ktkuTURBXy80NzA1OWU1MC03YTQxLTQ3MzUtYTYyMi1lYzUwZmNmZWU5N2IuanBlZ5GTBc0BHcyg" />Jest kilku pretendentów z innowacyjnych sektorów do przeprowadzenia dużych ofert publicznych. Możliwe, że dojdzie do tego w 2023 r.

## Rosjanie odpalili ponad 30 pocisków rakietowych. Koncentrują się na centralnej części kraju
 - [https://forsal.pl/swiat/ukraina/artykuly/8646260,ukraina-rosja-pociski-rakietowe-centralna-czesc-kraju.html](https://forsal.pl/swiat/ukraina/artykuly/8646260,ukraina-rosja-pociski-rakietowe-centralna-czesc-kraju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:24:30+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hWgktkuTURBXy8wMGFmYzEzYy0zMzZhLTRkODUtOTdmNS0xMjQ3YmI3NDE5Y2EuanBlZ5GTBc0BHcyg" />Wojska rosyjskie odpaliły w czwartek rano na regiony Ukrainy ponad 30 pocisków rakietowych - poinformował rzecznik ukraińskich sil powietrznych pułkownik Jurij Ihnat. Zaapelował o pozostanie w schronach.

## Środek ciężkości Europy przesuwa się na wschód. Ukraina scementuje ten trend
 - [https://forsal.pl/swiat/aktualnosci/artykuly/8646253,new-york-times-srodek-ciezkosci-europy.html](https://forsal.pl/swiat/aktualnosci/artykuly/8646253,new-york-times-srodek-ciezkosci-europy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:17:53+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/F09ktkuTURBXy8wYjI0YTBiMi1jMDEyLTQxM2QtYjZhYy1lMTExMWFkOTA3YTMuanBlZ5GTBc0BHcyg" />Polska była głównym lobbystą, który próbował przekonać niechętny Berlin do wysłania niemieckich czołgów na Ukrainę i upoważnienia do tego innych krajów, a środek ciężkości Europy, od rozpoczęcia rosyjskiej inwazji, przesuwa się na wschód kontynentu - oceniono w czwartkowym artykule &quot;New York Times&quot;.

## Wojska rosyjskie przygotowują się do decydującego ataku w obwodzie ługańskim
 - [https://forsal.pl/swiat/ukraina/artykuly/8646243,wojska-rosyjskie-obwod-luganski-decydujacy-atak.html](https://forsal.pl/swiat/ukraina/artykuly/8646243,wojska-rosyjskie-obwod-luganski-decydujacy-atak.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 08:10:09+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/12uktkuTURBXy81OWJjYjliZi04MmM4LTRlNzEtYjI1NC0wMWU1NGY3OTEyNTcuanBlZ5GTBc0BHcyg" />Szyk wojsk rosyjskich w obwodzie ługańskim i prowadzone w różnych miejscach ataki zakłócające sugerują, że Rosjanie mogą przygotowywać się do decydującego natarcia w tym regionie na wschodzie Ukrainy - ocenia w najnowszej analizie amerykański Instytut Studiów nad Wojną (ISW).

## Tauron przyjął aneksy wydłużające gwarancje należytego wykonania bloku w Jaworznie
 - [https://forsal.pl/biznes/aktualnosci/artykuly/8646222,tauron-rafako-aneksy-gwarancja.html](https://forsal.pl/biznes/aktualnosci/artykuly/8646222,tauron-rafako-aneksy-gwarancja.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:43:50+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UQ2ktkuTURBXy82NjBkOTU3MS1mZjZlLTQzZDEtYTM2NS05NTA1ZmNiYzYzOWYuanBlZ5GTBc0BHcyg" />Tauron Wytwarzanie podjął decyzję o przyjęciu aneksów nr 6 do gwarancji bankowych i ubezpieczeniowych stanowiących zabezpieczenie należytego wykonania w zakresie realizacji kontraktu na budowę bloku energetycznego o mocy 910 MW na parametry nadkrytyczne w Elektrowni Jaworzno III - Elektrownia II, zawartego pomiędzy konsorcjum Rafako i Mostostal Warszawa a Tauron Wytwarzanie, podał Tauron Polska Energia. Aneksy te stanowią przedłużenie zabezpieczenia należytego wykonania w zakresie realizacji kontraktu na dotychczasowych warunkach i w dotychczasowych kwotach do 10 marca 2023 r.

## PKO BP przeprowadził emisję obligacji o wartości 750 mln euro
 - [https://forsal.pl/biznes/bankowosc/artykuly/8646219,pko-bp-emisja-obligacji.html](https://forsal.pl/biznes/bankowosc/artykuly/8646219,pko-bp-emisja-obligacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:39:31+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OUtktkuTURBXy9iMGU5NDQ4Ny0xMjhmLTQ0ZDctODIyMS0wOWFjMmVjOGIyOTYuanBlZ5GTBc0BHcyg" />PKO Bank Polski (PKO BP) przeprowadził emisję trzyletnich uprzywilejowanych obligacji (senior preferred notes) obligacji o wartości 750 mln euro, podał bank.

## Kanadyjski wywiad ostrzega: uważajcie na TikToka
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646214,kanadyjski-wywiad-ostrzega-uwazajcie-na-tiktoka.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8646214,kanadyjski-wywiad-ostrzega-uwazajcie-na-tiktoka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:35:18+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/mUnktkuTURBXy8xODNkNTllMy04YTQyLTQxY2MtYmI1Mi02ZjJhOWI4M2FlNmMuanBlZ5GTBc0BHcyg" />Kanadyjski wywiad elektroniczny przygotowuje zalecenia w sprawie chińskiej aplikacji TikTok i ostrzega użytkowników, by nie zezwalali na dostęp instalowanych aplikacji do prywatnych danych.

## Ile kosztuje miedź? Poziom blisko maksimum z czerwca
 - [https://forsal.pl/finanse/notowania/artykuly/8646211,cena-miedzi-26-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8646211,cena-miedzi-26-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:33:32+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/y3GktkuTURBXy82NGU1NzNmYi04ZTgxLTQwODUtYWU1OS1iMzg3Zjc2ZjNhNWUuanBlZ5GTBc0BHcyg" />Miedź na giełdzie metali LME w Londynie jest nadal blisko najwyższego poziomu od czerwca 2022 r. Miedź w dostawach 3-miesięcznych jest wyceniana niemal bez zmian - po 9.311,00 USD za tonę - informują maklerzy.

## Znikająca zima. Klimatolożka: Musimy się do tego przyzwyczaić
 - [https://forsal.pl/biznes/ekologia/artykuly/8646205,polska-klimat-cieple-zimy.html](https://forsal.pl/biznes/ekologia/artykuly/8646205,polska-klimat-cieple-zimy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:27:26+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7rGktkuTURBXy9lZmVlZTZhNy0yNGZhLTRiZWEtYTQwNC00ZjRiNTNjZjI4OWMuanBlZ5GTBc0BHcyg" />Musimy zacząć się przyzwyczajać, że prawdziwe zimy w Polsce nizinnej będą występować coraz rzadziej, może jeszcze będą zdarzać się na wschodzie kraju - powiedziała PAP prof. dr hab. Joanna Wibig z Katedry Meteorologii i Klimatologii Wydziału Nauk Geograficznych Uniwersytetu Łódzkiego.

## Każdy czwartoklasista z własnym laptopem [WYWIAD]
 - [https://forsal.pl/lifestyle/edukacja/artykuly/8646208,kazdy-czwartoklasista-z-wlasnym-laptopem-wywiad.html](https://forsal.pl/lifestyle/edukacja/artykuly/8646208,kazdy-czwartoklasista-z-wlasnym-laptopem-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:25:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/W9_ktkuTURBXy9jZTU4YzUyMi1iNzY4LTQ4NmItYjA0My1iZmFlOGJmOGExMzYuanBlZ5GTBc0BHcyg" />Bez kryterium dochodowego czy rozróżnienia, do jakiej szkoły chodzi – według rządowych planów komputer ma dostać każde dziecko w IV klasie podstawówki. Szczegóły programu zapowiedzianego we wtorek przez premiera zdradza w rozmowie z DGP Janusz Cieszyński

## Kowalczyk: Szalone tempo wzrostu cen żywności mamy chyba za sobą
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646200,kowalczyk-szalone-tempo-wzrostu-cen-zywnosci-mamy-chyba-za-soba.html](https://forsal.pl/gospodarka/polityka/artykuly/8646200,kowalczyk-szalone-tempo-wzrostu-cen-zywnosci-mamy-chyba-za-soba.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:23:43+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JMUktkuTURBXy8zOGNhZGMzZS04Nzk0LTRmNmEtYTFjYS1iZWFmNTBmMDVmNDEuanBlZ5GTBc0BHcyg" />Szalone tempo wzrostu cen żywności mamy za sobą, no chyba że dojdzie do dramatycznej eskalacji za naszą wschodnią granicą, lub wzrosną znacznie ceny nośników energii - ocenił w środę wicepremier i minister rolnictwa Henryk Kowalczyk.

## Złoty traci wobec euro i franka, zyskuje do dolara
 - [https://forsal.pl/finanse/waluty/artykuly/8646197,kurs-zlotego-26-stycznia.html](https://forsal.pl/finanse/waluty/artykuly/8646197,kurs-zlotego-26-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:21:25+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-z5ktkuTURBXy8yNDIyY2Q5My1kZTBlLTRjMWItYjA4ZC0yMmFlOTJjZWZmNTQuanBlZ5GTBc0BHcyg" />W czwartek rano polska waluta straciła na wartości wobec euro i franka szwajcarskiego, a zyskała do dolara amerykańskiego. Euro kosztuje 4,71 zł, frank szwajcarski 4,70 zł, a dolar – 4,31 zł.

## PKP Intercity planuje własnymi siłami wprowadzić program lojalnościowy
 - [https://forsal.pl/transport/kolej/artykuly/8646195,pkp-intercity-planuje-wlasnymi-silami-wprowadzic-program-lojalnosciowy.html](https://forsal.pl/transport/kolej/artykuly/8646195,pkp-intercity-planuje-wlasnymi-silami-wprowadzic-program-lojalnosciowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:20:21+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zRhktkuTURBXy9hOGE5OGNlZi02OTAyLTRmZWMtYTY4ZC03ZTNkZjc4MWQzMTMuanBlZ5GTBc0BHcyg" />PKP Intercity planuje własnymi siłami przygotować program lojalnościowy dla podróżnych - poinformował PAP członek zarządu kolejowej spółki Tomasz Gontarz. Wcześniej spółka myślała, aby ogłosić przetarg na wybór dostawcy systemu obsługującego program lojalnościowy.

## Ceny ropy w USA nieznacznie zwyżkują. Inwestorzy czekają na sygnały z Chin
 - [https://forsal.pl/finanse/notowania/artykuly/8646169,cena-ropy26-stycznia.html](https://forsal.pl/finanse/notowania/artykuly/8646169,cena-ropy26-stycznia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:13:54+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7OwktkuTURBXy8wZTMwNWYxNS02MTVjLTRkYjYtYjFjNS1jYmQ5NWFhMzBkMDYuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku nieznacznie zwyżkują w trakcie sesji. Inwestorzy rozważają możliwe odbicie popytu na paliwa w Chinach po zakończeniu długiej noworocznej przerwy - podają maklerzy.

## Meta: Donald Trump może powrócić na Facebooka
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646165,meta-donald-trump-moze-powrocic-na-facebooka.html](https://forsal.pl/gospodarka/polityka/artykuly/8646165,meta-donald-trump-moze-powrocic-na-facebooka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:11:51+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-K7ktkuTURBXy82YjY2YWVkOS0yYmVjLTRlMTctYTA4Mi00ZTZkNTQxODc0OGQuanBlZ5GTBc0BHcyg" />W najbliższych tygodniach były prezydent USA Donald Trump będzie mógł powrócić na Facebooka - poinformował w środę właściciel tego serwisu społecznościowego, firma Meta Platforms.

## Leopardy już jadą na Ukrainę. Samoloty wkrótce
 - [https://forsal.pl/swiat/ukraina/artykuly/8646157,leopardy-juz-jada-na-ukraine-samoloty-wkrotce.html](https://forsal.pl/swiat/ukraina/artykuly/8646157,leopardy-juz-jada-na-ukraine-samoloty-wkrotce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 07:00:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/n_WktkuTURBXy82YjllNDg0Zi0zMjc4LTQzMGUtOTJkMi00MzkyZWU4ZjcyZDcuanBlZ5GTBc0BHcyg" />Niemcy przekażą Ukrainie czołgi i wydały zgodę na to, by zrobiły to inne państwa. Z kolei USA przekażą abramsy. Najpewniej wkrótce Ukraińcy doczekają się też samolotów

## Płace przegrywają z inflacją. W niektórych branżach podwyżki były jednak wyższe
 - [https://forsal.pl/praca/wynagrodzenia/artykuly/8646145,w-ktorych-branzach-place-rosna-szybciej-od-inflacji.html](https://forsal.pl/praca/wynagrodzenia/artykuly/8646145,w-ktorych-branzach-place-rosna-szybciej-od-inflacji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 06:55:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yXyktkuTURBXy83ZjM1ZTRjNC1hYTllLTQxN2MtYjA2OC02MzNlMTgzYmYyN2UuanBlZ5GTBc0BHcyg" />Górnictwo oraz transport i logistyka w 2022 r. przodowały pod względem tempa wzrostu płac. Przeciętne wynagrodzenie było w nich nominalnie o ponad jedną czwartą wyższe niż rok wcześniej. Pod uwagę bierzemy nie wynagrodzenie w ostatnim miesiącu, ale średnie od stycznia do grudnia.

## Trybunał orzekł. Państwo zapomniało. Opiekunowie walczą
 - [https://forsal.pl/gospodarka/artykuly/8646142,swiadczenie-pielegnacyjne.html](https://forsal.pl/gospodarka/artykuly/8646142,swiadczenie-pielegnacyjne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 06:50:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ThGktkuTURBXy8zODBkMjk5Zi0xYzc1LTQ1OGEtODUwZi03YjhhYmY4NTM2NTMuanBlZ5GTBc0BHcyg" />Opiekunowie osób z niepełnosprawnościami walczą o należne im świadczenia pielęgnacyjne. Z sukcesem, bo przybywa decyzji SKO w tej sprawie podejmowanych na korzyść wnioskodawców

## Ordynacyjne prawdy i mity
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646135,ocena-nowej-ordynacji-wyborczej.html](https://forsal.pl/gospodarka/polityka/artykuly/8646135,ocena-nowej-ordynacji-wyborczej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 06:40:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aP6ktkuTURBXy80ODM3OWI0Ny0yZmYzLTRhZGMtYjNkMS1iNjkzMzIwNzI1NmIuanBlZ5GTBc0BHcyg" />PiS liczy, że – mimo sprzeciwu opozycji – Sejm na obecnym posiedzeniu przegłosuje zmiany w prawie wyborczym. DGP przeanalizował, ile prawdy jest w zarzutach oraz oczekiwaniach odnośnie do tego projektu

## Opozycja ma duże szanse na przejęcie władzy. Pozostaje jednak prezydencki zgryz [SONDAŻ]
 - [https://forsal.pl/gospodarka/polityka/artykuly/8646131,szanse-opozycji-na-wygranie-wyborow-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/8646131,szanse-opozycji-na-wygranie-wyborow-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 06:30:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-0vktkuTURBXy9mMmQ3NWRlNi0wN2VjLTQxOGYtYjZlMS0wM2NjMDM1MDI4NmYuanBlZ5GTBc0BHcyg" />undefined

## Kryzys finansowy uderza w Polaków. „Życie w tym kraju to walka o spięcie budżetu miesięcznego”
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/8646111,ceny-zywnosci-inflacja-jak-przetrwac-kryzys-finansowy-w-polsce.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/8646111,ceny-zywnosci-inflacja-jak-przetrwac-kryzys-finansowy-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 06:00:03+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yuJktkuTURBXy9hZTlmNWYwYy1lMzUyLTQ4ZTktOTY1Ni1iMGVhOTJiYTg5MWUuanBlZ5GTBc0BHcyg" />- Życie w tym kraju to walka o spięcie się budżetu miesięcznego - mówi Maria. Podobną walkę każdego dnia podejmują miliony Polek i Polaków, chociaż przy wciąż rosnących cenach bywa ona nierówna. - Z czego zrezygnować, jak już wszystko ograniczyliśmy? - pytają.

## Ile naprawdę warte są big techy? Oto wycena giełdowych potęg
 - [https://forsal.pl/lifestyle/technologie/artykuly/8645547,wycena-meta-amazon-apple-microsoft-google.html](https://forsal.pl/lifestyle/technologie/artykuly/8645547,wycena-meta-amazon-apple-microsoft-google.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:55:46+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4wYktkuTURBXy9kOTlkZGQxMy1lMGU5LTQ0YzMtYThmNC02MTdmMzc1N2FlNmQuanBlZ5GTBc0BHcyg" />Obecną bessę na rynku spółek technologicznych często porównuje się do bańki na rynku spółek internetowych sprzed ponad 20 lat. Czy słusznie? Spróbuję odpowiedzieć w tym tekście na pytanie, czy wielkie spółki z tego sektora są nadal przewartościowane.

## Statystyka vs. morderczy personel medyczny. Czy da się ujawnić zabójcę na podstawie podejrzanych wzorców zgonów?
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/8644931,personel-medyczny-zabojstwa-statystyka-richard-gill-lucia-de-berk.html](https://forsal.pl/lifestyle/zdrowie/artykuly/8644931,personel-medyczny-zabojstwa-statystyka-richard-gill-lucia-de-berk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:50:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2sgktkuTURBXy9iN2I4OWUxNi1kZWMyLTQ2NDktODExZi1lNzRmN2E3ODJhZGUuanBlZ5GTBc0BHcyg" />Jeden do siedmiu miliardów. Tyle, zdaniem policji, wynosiła szansa, że holenderska pielęgniarka Lucia de Berk tylko przez przypadek uczestniczyła przy odbieraniu porodów, które kończyły się śmiercią noworodka. W sprawę zaangażowany był szanowany statystyk i to właśnie statystyka posłużyła za dowód przeciwko de Berk.

## Puste hospicja, znikające matki
 - [https://forsal.pl/gospodarka/artykuly/8646139,puste-hospicja-znikajace-matki.html](https://forsal.pl/gospodarka/artykuly/8646139,puste-hospicja-znikajace-matki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:45:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zqIktkuTURBXy84MTQyZWJlYi0yM2FhLTRkNDQtYjA1Zi0wMTVlZjVhZWQzYzUuanBlZ5GTBc0BHcyg" />Miały być realnym wsparciem dla kobiet, które po wyroku TK muszą rodzić dzieci z wadami letalnymi. Dziś w hospicjach perinatalnych spada liczba pacjentek. Dzieci śmiertelnie chorych nie rodzi się jednak mniej

## Projekt pierwszego modułowego reaktora jądrowego SMR otrzymał certyfikat w USA
 - [https://forsal.pl/swiat/usa/artykuly/8644803,projekt-pierwszego-modulowego-reaktora-jadrowego-smr-certyfikat-w-usa.html](https://forsal.pl/swiat/usa/artykuly/8644803,projekt-pierwszego-modulowego-reaktora-jadrowego-smr-certyfikat-w-usa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:20:49+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/FJvktkuTURBXy9lMDRhYTczYS1jOGZhLTQ4OTQtOWQzOC1iODhmNmE0OGRiM2YuanBlZ5GTBc0BHcyg" />Po raz pierwszy amerykańska Komisja Dozoru Jądrowego (NRC) zatwierdziła projekt zaawansowanego małego reaktora modułowego (SMR). Dzięki powyższemu certyfikatowi firmy, które wybiorą ten projekt reaktora będę mogły ubiegać się o pozwolenie na budowę i eksploatację nowej elektrowni. W ten sposób Amerykanie dali zielone światło dla całkowicie nowej generacji reaktorów jądrowych.

## 5 prognoz dla rynku nieruchomości na 2023 rok
 - [https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8645509,rynek-nieruchomosci-prognozy-2023.html](https://forsal.pl/nieruchomosci/aktualnosci/artykuly/8645509,rynek-nieruchomosci-prognozy-2023.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:00:35+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0IZktkuTURBXy82OTczYWEwZS05M2VjLTQ3MDctOTIxMy1iNWE4ODdhZTNlNGYuanBlZ5GTBc0BHcyg" />Co czeka rynek nieruchomości w 2023 roku? Co dalej z cenami i podażą mieszkań?

## Europie grozi kolejna wojna? „Kruchy pokój jest na skraju przepaści”
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/8645601,balkany-serbia-kosowo-europie-grozi-kolejna-wojna-kruchy-pokoj.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/8645601,balkany-serbia-kosowo-europie-grozi-kolejna-wojna-kruchy-pokoj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CtFktkuTURBXy9lYzlkZjgwYi0xYWNjLTQyNjItOWMzYi04NDgwODQyOTZiZDQuanBlZ5GTBc0BHcyg" />Ostatni duży konflikt na Bałkanach nigdy nie przestał się tlić, a kruchy pokój znajduje się dziś na skraju przepaści – ostrzegają Andrea Dudik i Misha Savic na łamach Bloomberga.

## Wodór w ciepłownictwie i transporcie kusi polskie miasta
 - [https://forsal.pl/biznes/energetyka/artykuly/8645553,wodor-w-cieplownictwie-i-transporcie-kusi-polskie-miasta.html](https://forsal.pl/biznes/energetyka/artykuly/8645553,wodor-w-cieplownictwie-i-transporcie-kusi-polskie-miasta.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-01-26 04:50:58+00:00
 - user: None

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7U8ktkuTURBXy9iYTIwMDAyNy05ZDc3LTQwOTMtYjMxMi0wZDc2MzE3MzQ0NjkuanBlZ5GTBc0BHcyg" />Coraz więcej polskich miast chce wykorzystać wodór w systemach ciepłowniczych. Tymczasem na Zachodzie toczy się gorąca dyskusja czy wodór powinien służyć do ogrzewania
