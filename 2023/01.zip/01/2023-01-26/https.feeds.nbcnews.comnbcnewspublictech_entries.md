# Source NBC tech, Source URL:https://feeds.nbcnews.com/nbcnews/public/tech, Source language: en-US

## AI wrote a bill to regulate AI. Now Rep. Ted Lieu wants Congress to pass it.
 - [https://www.nbcnews.com/politics/congress/ted-lieu-artificial-intelligence-bill-congress-chatgpt-rcna67752](https://www.nbcnews.com/politics/congress/ted-lieu-artificial-intelligence-bill-congress-chatgpt-rcna67752)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-26 22:35:59+00:00
 - user: None

Rep. Ted Lieu uses ChatGPT to write a bill that would recommend new federal regulations for artificial intelligence.

## TikTok tries to sell ‘Project Texas’ as it fights for survival in the U.S.
 - [https://www.nbcnews.com/tech/security/tiktok-tries-sell-project-texas-fights-survival-us-rcna67697](https://www.nbcnews.com/tech/security/tiktok-tries-sell-project-texas-fights-survival-us-rcna67697)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-26 21:47:46+00:00
 - user: None

TikTok is going on the offensive in Washington, D.C., in a stepped-up effort to counter calls to ban the app in the U.S. over its Chinese ownership.

## DOJ disrupts major ransomware group
 - [https://www.nbcnews.com/tech/security/doj-disrupts-major-ransomware-group-rcna67627](https://www.nbcnews.com/tech/security/doj-disrupts-major-ransomware-group-rcna67627)
 - RSS feed: https://feeds.nbcnews.com/nbcnews/public/tech
 - date published: 2023-01-26 15:42:01+00:00
 - user: None

The FBI has infiltrated and disrupted a major cybercriminal group that extorted schools, hospitals and critical infrastructure around the world, a law enforcement official told NBC News.
