# Source Instalki.pl, Source URL:https://www.instalki.pl, Source language: pl-PL

## Windows 11 znów otrzyma nowy Eksplorator plików. Jestem zachwycony zmianami - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/software/57912-windows-11-nowy-eksplorator-plikow-2023.html](https://www.instalki.pl/aktualnosci/software/57912-windows-11-nowy-eksplorator-plikow-2023.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 22:56:25.992113+00:00
 - user: None

Windows 11 znów otrzyma nowy Eksplorator plików. Jestem zachwycony zmianami - Instalki.pl

## Używała na mrozie -53oC topowy PC na i9 i RTX 4090. Czy sprzęt wytrzymał? - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/57911-komputer-mroz-53oc-chiny-pc-i9-13gen-rtx.html](https://www.instalki.pl/aktualnosci/hardware/57911-komputer-mroz-53oc-chiny-pc-i9-13gen-rtx.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 20:56:29.322088+00:00
 - user: None

Używała na mrozie -53oC topowy PC na i9 i RTX 4090. Czy sprzęt wytrzymał? - Instalki.pl

## Pomyłka sklepu. Zamówił 1 flagowy SSD, dostał 10 sztuk wartych 5,5 tys. złotych - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/57910-samsung-980-pro-pomylka-wiecej-sklep.html](https://www.instalki.pl/aktualnosci/hardware/57910-samsung-980-pro-pomylka-wiecej-sklep.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 17:56:21.092006+00:00
 - user: None

Pomyłka sklepu. Zamówił 1 flagowy SSD, dostał 10 sztuk wartych 5,5 tys. złotych - Instalki.pl

## Jeszcze rzeczywistość, czy już Terminator? Ten robot zamienia się w ciecz i wraca do swojego kształtu - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/technika/57908-jeszcze-rzeczywistosc-czy-juz-terminator-ten-robot-zamienia-sie-w-ciecz-i-wraca-do-swojego-ksztaltu.html](https://www.instalki.pl/aktualnosci/technika/57908-jeszcze-rzeczywistosc-czy-juz-terminator-ten-robot-zamienia-sie-w-ciecz-i-wraca-do-swojego-ksztaltu.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 15:30:25.228255+00:00
 - user: None

Jeszcze rzeczywistość, czy już Terminator? Ten robot zamienia się w ciecz i wraca do swojego kształtu - Instalki.pl

## DualSense Edge już w sklepach. Kontroler od PS5 dla wymagających graczy - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/57909-premiera-dualsense-edge.html](https://www.instalki.pl/aktualnosci/hardware/57909-premiera-dualsense-edge.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 15:30:24.970291+00:00
 - user: None

DualSense Edge już w sklepach. Kontroler od PS5 dla wymagających graczy - Instalki.pl

## Ketchup zamiast pasty termoprzewodzącej? Ktoś przeprowadził eksperyment - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/57907-ketchup-zamiast-pasty-termoprzewodzacej.html](https://www.instalki.pl/aktualnosci/hardware/57907-ketchup-zamiast-pasty-termoprzewodzacej.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 14:30:12.986776+00:00
 - user: None

Ketchup zamiast pasty termoprzewodzącej? Ktoś przeprowadził eksperyment - Instalki.pl

## Najlepszy aparat w smartfonie? Porównanie zdjęć Xiaomi 13 Pro, Galaxy S22 Ultra, vivo X80 Pro, Huawei Mate 50 Pro - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/hardware/57903-najlepszy-aparat-w-smartfonie-2023.html](https://www.instalki.pl/aktualnosci/hardware/57903-najlepszy-aparat-w-smartfonie-2023.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 11:30:09.762736+00:00
 - user: None

Najlepszy aparat w smartfonie? Porównanie zdjęć Xiaomi 13 Pro, Galaxy S22 Ultra, vivo X80 Pro, Huawei Mate 50 Pro - Instalki.pl

## Tesla Cybertruck z opóźnioną premierą. Elon Musk znów nie dotrzymał słowa - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/technika/57905-tesla-cybertruck-opozniona-premiera-2024.html](https://www.instalki.pl/aktualnosci/technika/57905-tesla-cybertruck-opozniona-premiera-2024.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 11:30:09.481417+00:00
 - user: None

Tesla Cybertruck z opóźnioną premierą. Elon Musk znów nie dotrzymał słowa - Instalki.pl

## Takich SMS nie można wysyłać Polakom. Polski urząd dał zły przykład - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/bezpieczenstwo/57904-takich-sms-nie-mozna-wysylac-polakom.html](https://www.instalki.pl/aktualnosci/bezpieczenstwo/57904-takich-sms-nie-mozna-wysylac-polakom.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 11:30:09.191843+00:00
 - user: None

Takich SMS nie można wysyłać Polakom. Polski urząd dał zły przykład - Instalki.pl

## Niespodzianka dla fanów The Last of Us w Google. Zobacz easter egg - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/internet/57906-easter-egg-w-google-dla-fanow-tle-last-of-us.html](https://www.instalki.pl/aktualnosci/internet/57906-easter-egg-w-google-dla-fanow-tle-last-of-us.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 11:30:08.835035+00:00
 - user: None

Niespodzianka dla fanów The Last of Us w Google. Zobacz easter egg - Instalki.pl

## Polski SentiOne szykuje odpowiedź na ChatGPT  - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/internet/57902-polski-sentione-szykuje-odpowiedz-na-chatgpt.html](https://www.instalki.pl/aktualnosci/internet/57902-polski-sentione-szykuje-odpowiedz-na-chatgpt.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 10:30:09.343102+00:00
 - user: None

Polski SentiOne szykuje odpowiedź na ChatGPT  - Instalki.pl

## Koniec TVP Info i abonamentu RTV? Projekt ustawy już w Sejmie - Instalki.pl
 - [https://www.instalki.pl/aktualnosci/rozrywka/57901-koniec-tvp-i-abonamentu-projekt-obywatelski-w-sejmie.html](https://www.instalki.pl/aktualnosci/rozrywka/57901-koniec-tvp-i-abonamentu-projekt-obywatelski-w-sejmie.html)
 - RSS feed: https://www.instalki.pl
 - date published: 2023-01-26 01:30:04.326605+00:00
 - user: None

Koniec TVP Info i abonamentu RTV? Projekt ustawy już w Sejmie - Instalki.pl
