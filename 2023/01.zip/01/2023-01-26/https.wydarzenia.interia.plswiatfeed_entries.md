# Source Wydarzenia Interia - Świat, Source URL:https://wydarzenia.interia.pl/swiat/feed, Source language: pl-PL

## Grupa Wagnera oficjalnie grupą przestępczą. Są też dodatkowe sankcje
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-oficjalnie-grupa-przestepcza-sa-tez-dodatkowe-,nId,6559008](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-oficjalnie-grupa-przestepcza-sa-tez-dodatkowe-,nId,6559008)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-26 18:49:10+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-grupa-wagnera-oficjalnie-grupa-przestepcza-sa-tez-dodatkowe-,nId,6559008"><img align="left" alt="Grupa Wagnera oficjalnie grupą przestępczą. Są też dodatkowe sankcje" src="https://i.iplsc.com/grupa-wagnera-oficjalnie-grupa-przestepcza-sa-tez-dodatkowe/000GN1DIB14IAWPR-C321.jpg" /></a>Grupa Wagnera została oficjalnie uznana za transnarodową grupę przestępczą przez administrację USA. Zdecydowano też o nałożeniu sankcji na związane z nią podmioty oraz oligarchów.</p><br clear="all" />

## Ekspert: Straszenie Niemców przez Warszawę było krokiem zbyt daleko idącym
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ekspert-straszenie-niemcow-przez-warszawe-bylo-krokiem-zbyt-,nId,6558789](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ekspert-straszenie-niemcow-przez-warszawe-bylo-krokiem-zbyt-,nId,6558789)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-26 16:50:52+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ekspert-straszenie-niemcow-przez-warszawe-bylo-krokiem-zbyt-,nId,6558789"><img align="left" alt="Ekspert: Straszenie Niemców przez Warszawę było krokiem zbyt daleko idącym" src="https://i.iplsc.com/ekspert-straszenie-niemcow-przez-warszawe-bylo-krokiem-zbyt/000GO8RPUHUSFTVX-C321.jpg" /></a>Niemcy w kwestii Ukrainy działają tylko na zasadzie solidarności z innymi, a sami nie są aktywni - ocenia w rozmowie z Interią Nico Lange, ekspert ds. Ukrainy i były główny doradca byłej minister obrony narodowej Annegret Kramp-Karrenbauer. Niemiecki politolog uważa, że decyzje Berlina w sprawie przekazywania wozów bojowych Marder i Leopardów zapadały za późno. Jego zdaniem obecne czasy wymagają podejmowania szybkich decyzji. Ich przeciągnie spowodowało, że opinia publiczna koncentrowała się tylko na dwóch rodzajach pojazdów, choć potrzeby...</p><br clear="all" />

## Czołgi Leopard 2 w Europie. Które kraje je posiadają? [GRAFIKA]
 - [https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja-grafika,nId,6558358](https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja-grafika,nId,6558358)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-26 09:44:10+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/zagranica/news-czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja-grafika,nId,6558358"><img align="left" alt="Czołgi Leopard 2 w Europie. Które kraje je posiadają? [GRAFIKA]" src="https://i.iplsc.com/czolgi-leopard-2-w-europie-ktore-kraje-je-posiadaja-grafika/000GO645IJ56HTP4-C321.jpg" /></a>Grecy mają najwięcej czołgów Leopard 2 w Europie - wynika z danych zgromadzonych przez AFP. Na podium znalazły się też Hiszpania oraz Niemcy, które są ich producentem. Wysoko na liście znajduje się też Polska, która zaproponowała koalicję państw wspomagających Ukrainę przez dostarczenie jej Leopardów. Są też kraje UE, które nie posiadają ani jednego takiego czołgu.</p><br clear="all" />

## Ukraina: Zmasowany atak na Ukrainę. Wybuch w Kijowie
 - [https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zmasowany-atak-na-ukraine-wybuch-w-kijowie,nId,6558385](https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zmasowany-atak-na-ukraine-wybuch-w-kijowie,nId,6558385)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-01-26 09:25:35+00:00
 - user: None

<p><a href="https://wydarzenia.interia.pl/raporty/raport-ukraina-rosja/aktualnosci/news-ukraina-zmasowany-atak-na-ukraine-wybuch-w-kijowie,nId,6558385"><img align="left" alt="Ukraina: Zmasowany atak na Ukrainę. Wybuch w Kijowie" src="https://i.iplsc.com/ukraina-zmasowany-atak-na-ukraine-wybuch-w-kijowie/000GO6121N72PCOC-C321.jpg" /></a>Jedna osoba zginęła a dwie zostały ranne w Kijowie w rosyjskim ataku rakietowym w rejonie hołosijiwskim - przekazał mer stolicy Ukrainy Witalij Kliczko. Wcześniej armia informowała, że w kierunku kilku regionów kraju Rosjanie wystrzelili ponad 30 pocisków rakietowych. Do zmasowanego ataku doszło dzień po tym, gdy władze Niemiec i USA ogłosiły gotowość do przekazania Ukrainie czołgów.</p><br clear="all" />
