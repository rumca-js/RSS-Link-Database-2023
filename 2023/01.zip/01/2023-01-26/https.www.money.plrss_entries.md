# Source Money PL, Source URL:https://www.money.pl/rss/, Source language: pl-PL

## Wyższa kwota wolna od podatku od spadków i darowizn. Sejm uchwalił ustawę
 - [https://www.money.pl/podatki/beda-wyzsze-kwoty-wolne-od-spadkow-i-darowizn-sejm-uchwalil-ustawe-6859841309399712a.html](https://www.money.pl/podatki/beda-wyzsze-kwoty-wolne-od-spadkow-i-darowizn-sejm-uchwalil-ustawe-6859841309399712a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 20:45:42+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fb325fd7-eca3-41a2-b86b-c14f294ad743" width="308" /> Sejm uchwalił ustawę deregulacyjną, która nowelizuje kilkanaście ustaw. Wśród nich znalazł się przepis mówiący o podniesieniu kwot wolnych w podatku od spadku i darowizn.

## Budżet na 2023 rok. Sejm nie przyjął poprawek Senatu
 - [https://www.money.pl/gospodarka/budzet-na-2023-rok-sejm-nie-przyjal-poprawek-senatu-6859806707030688a.html](https://www.money.pl/gospodarka/budzet-na-2023-rok-sejm-nie-przyjal-poprawek-senatu-6859806707030688a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 18:58:13+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/65180c18-82f2-4191-8fa1-20610cd16174" width="308" /> Zwiększenie budżetu na ochronę zdrowia, w tym na leczenie nowotworów u dzieci, a także na in vitro, czy zmniejszenie dotacji dla mediów publicznych - to tylko niektóre poprawki Senatu do ustawy budżetowej. Większość sejmowa zdecydowała jednak o odrzuceniu tych propozycji.

## Co dalej z rachunkami odbiorców ciepła? Sejm zdecydował
 - [https://www.money.pl/gospodarka/co-dalej-z-rachunkami-odbiorcow-ciepla-sejm-zdecydowal-6859409688656544a.html](https://www.money.pl/gospodarka/co-dalej-z-rachunkami-odbiorcow-ciepla-sejm-zdecydowal-6859409688656544a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 18:41:53+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1dd29d25-ec66-42e5-83c0-17e0a035285d" width="308" /> Rachunki odbiorców ciepła będą mogły wzrosnąć maksymalnie o 40 proc. względem tych z września 2022 r. Tak zdecydował Sejm, który przyjął ustawę zaproponowaną przez rząd. Mechanizm ograniczający wzrost cen to kolejny pomysł ulżenia Polakom korzystającym z dostaw ciepła, gdyż poprzedni nie do końca się sprawdził.

## Jest najnowsza prognoza. Polska gospodarka uniknie recesji
 - [https://www.money.pl/gospodarka/jest-najnowsza-prognoza-polska-gospodarka-uniknie-recesji-6859757140142784a.html](https://www.money.pl/gospodarka/jest-najnowsza-prognoza-polska-gospodarka-uniknie-recesji-6859757140142784a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 15:03:12+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf70c378-2974-4e01-911f-c03cc39dea80" width="308" /> Polska gospodarka uniknie recesji w 2023 roku, notując wzrost PKB o 0,5 proc. W pierwszej połowie roku czeka nas stagnacja, po której nastąpi nieznaczne ożywienie – wynika z opublikowanych w czwartek prognoz Ernst &amp; Young.

## To prawdziwe tąpnięcie. Liczba udzielonych kredytów hipotecznych spadła o połowę
 - [https://www.money.pl/banki/to-prawdziwe-tapniecie-liczba-udzielonych-kredytow-hipotecznych-spadla-o-polowe-6859717352905408a.html](https://www.money.pl/banki/to-prawdziwe-tapniecie-liczba-udzielonych-kredytow-hipotecznych-spadla-o-polowe-6859717352905408a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 12:21:17+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d3eda416-c9ea-4634-bfc0-c9dd68a63318" width="308" /> W 2022 r. kwota udzielonych kredytów mieszkaniowych spadła o niemal połowę, do 45,4 mld zł, porównując  rok do roku. Również o ponad połowę spadła ich liczba - poinformowało  Biuro Informacji Kredytowe. Szacuje, że wartość kredytów hipotecznych w tym roku będzie o 38 proc. niższa niż w 2022 r.

## Kolejny krok w stronę polskiego terminala FSRU. Gaz-System z kompletem decyzji
 - [https://www.money.pl/gielda/kolejny-krok-w-strone-polskiego-terminala-fsru-gaz-system-z-kompletem-decyzji-6859715181353664a.html](https://www.money.pl/gielda/kolejny-krok-w-strone-polskiego-terminala-fsru-gaz-system-z-kompletem-decyzji-6859715181353664a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 12:11:53+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c226f1ea-c016-4976-861a-b71e1dc3f21b" width="308" /> Polski pływający terminala LNG w Gdańsku ma zostać oddany w 2027 r. Realizujący projekt Gaz-System rozbudowuje sieć przesyłową, która ma pozwolić na efektywne rozprowadzenie gazu z rejonu Gdańska do klientów w Polsce i w regionie.

## Wcześniejsze emerytury dla nauczycieli. Czarnek: rozmawiam z prezes ZUS
 - [https://www.money.pl/emerytury/wczesniejsze-emerytury-dla-nauczycieli-czarnek-rozmawiam-z-prezes-zus-6859698564987552a.html](https://www.money.pl/emerytury/wczesniejsze-emerytury-dla-nauczycieli-czarnek-rozmawiam-z-prezes-zus-6859698564987552a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 11:42:06+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ca4326f8-1b7e-4c87-8908-2d3e74484204" width="308" /> - O wcześniejszych emeryturach dla nauczycieli rozmawiam już z prezes ZUS - prof. Gertrudą Uścińską - powiedział w czwartek w Polsat News szef MEiN Przemysław Czarnek. - Liczymy na rozwiązanie, które będzie dotyczyło wszystkich nauczycieli i będzie pozwalało pracować mimo przejścia na emeryturę - mówi w programie "Newsroom" WP Krzysztof Baszczyński, wiceprezes ZNP.

## SN rozstrzygnie w ważnej sprawie. Chodzi o kredyty hipoteczne
 - [https://www.money.pl/banki/sn-rozstrzygnie-w-waznej-sprawie-chodzi-o-kredyty-hipoteczne-6859675719932576a.html](https://www.money.pl/banki/sn-rozstrzygnie-w-waznej-sprawie-chodzi-o-kredyty-hipoteczne-6859675719932576a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 10:00:28+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2ccf38d7-b5f5-478d-aaa6-4d255692b30a" width="308" /> Czy w przypadku wcześniejszej spłaty hipoteki bank powinien zwrócić klientowi część poniesionych przez niego kosztów związanych z kredytem? Z tym pytaniem Sąd Okręgowy w Szczecinie zwrócił do Izby Cywilnej Sądu Najwyższego. Dziś SN zajmie się sprawą.

## Wakacje kredytowe będą wydłużone? Banki ostrzegają przed konsekwencjami
 - [https://www.money.pl/banki/wakacje-kredytowe-beda-wydluzone-banki-ostrzegaja-przed-konsekwencjami-6859661854300832a.html](https://www.money.pl/banki/wakacje-kredytowe-beda-wydluzone-banki-ostrzegaja-przed-konsekwencjami-6859661854300832a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 09:13:56+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf957a73-27e2-4dac-afe6-e333cc46ed7d" width="308" /> - Przedłużanie powszechnych wakacji kredytowych byłoby skrajną nieodpowiedzialnością - ocenia prezes Związku Banków Polski Krzysztof Pietraszkiewicz. Wskazuje, że mechanizm ten spowodował ograniczenie zdolności finansowania rozwoju gospodarki o ponad 300 mld zł. Z informacji money.pl wynika, że rząd planuje wydłużyć ustawowe wakacje kredytowe co najmniej o rok, czyli do końca 2024 r.

## "Prawdziwy wróg jest na wschodzie". Premier o sporze z Brukselą o KPO
 - [https://www.money.pl/gospodarka/prawdziwy-wrog-jest-na-wschodzie-premier-o-sporze-z-bruksela-o-kpo-6859667276057248a.html](https://www.money.pl/gospodarka/prawdziwy-wrog-jest-na-wschodzie-premier-o-sporze-z-bruksela-o-kpo-6859667276057248a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 08:57:34+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6f7ff13d-4749-4dec-af71-808ab1f99ef5" width="308" /> Mam nadzieję, że jesteśmy coraz bliżej, a Senat zaakceptuje naszą ustawę. Ona jest bazą do kompromisu z Unią Europejską. Jeśli tak się stanie, będziemy mogli złożyć wniosek jeszcze przed podpisaniem ustawy przez pana prezydenta - mówił premier Mateusz Morawiecki, odpowiadając na pytanie, kiedy Polska złoży wniosek o pieniądze z KPO.

## Dlaczego decydujemy się na zmianę pracy?
 - [https://www.money.pl/gospodarka/dlaczego-decydujemy-sie-na-zmiane-pracy-6859376120904384a.html](https://www.money.pl/gospodarka/dlaczego-decydujemy-sie-na-zmiane-pracy-6859376120904384a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 07:19:25+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/2c7bdb58-c612-4f27-94a7-b467178123cd" width="308" /> W życiu każdego z nas przychodzi taki moment, w którym decydujemy się na zmianę pracy. Powodów takiej decyzji może być mnóstwo i zależne będą one od indywidualnego przypadku. Obecnie wśród pokolenia Z obserwujemy coraz częstszą tendencję do zmiany stanowiska. Z czego to wynika? Dlaczego zmieniamy pracę i jak często powinniśmy to robić, by dobrze wypaść w oczach potencjalnego pracodawcy?

## Tesla z rekordowymi przychodami. Spółka Elona Muska z zyskiem powyżej oczekiwań
 - [https://www.money.pl/gielda/tesla-z-rekordowymi-przychodami-spolka-elona-muska-z-zyskiem-powyzej-oczekiwan-6859631421156000a.html](https://www.money.pl/gielda/tesla-z-rekordowymi-przychodami-spolka-elona-muska-z-zyskiem-powyzej-oczekiwan-6859631421156000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:31:40+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/897d5301-44d4-4e0d-bbfb-0e9975bd3c66" width="308" /> Producent samochodów elektrycznych Tesla pokazał w czwartym kwartale 2022 roku rekordowe przychody oraz zyski, które przebiły oczekiwania analityków. Spółka Elona Muska obroniła wynik po dramatycznej końcówce roku.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 26.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-26-01-2023-6859624947153600a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-26-01-2023-6859624947153600a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:05:23+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 26.01.2023. W czwartek za jednego dolara (USD) trzeba zapłacić 4.3153 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 26.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-26-01-2023-6859624947485376a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-26-01-2023-6859624947485376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:05:23+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 26.01.2023. W czwartek za jedno euro (EUR) trzeba zapłacić 4.7115 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 26.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-26-01-2023-6859624946264768a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-26-01-2023-6859624946264768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:05:23+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 26.01.2023. W czwartek za jednego franka (CHF) trzeba zapłacić 4.7052 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 26.01.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-26-01-2023-6859624945158816a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-26-01-2023-6859624945158816a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:05:23+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 26.01.2023. W czwartek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3513 zł.

## Kursy walut 26.01.2023. Czwartkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-26-01-2023-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6859624930589344a.html](https://www.money.pl/pieniadze/kursy-walut-26-01-2023-czwartkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6859624930589344a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 06:05:16+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 26.01.2023. W czwartek za jednego dolara (USD) zapłacimy 4.31 zł. Cena jednego funta szterlinga (GBP) to 5.35 zł, a franka szwajcarskiego (CHF) 4.70 zł. Z kolei euro (EUR) możemy zakupić za 4.71 zł.

## ZUS wypłaca emerytury za pracę za granicą. Oto na jakie świadczenia można liczyć
 - [https://www.money.pl/emerytury/zus-wyplaca-emerytury-za-prace-za-granica-oto-na-jakie-swiadczenia-mozna-liczyc-6859614190930624a.html](https://www.money.pl/emerytury/zus-wyplaca-emerytury-za-prace-za-granica-oto-na-jakie-swiadczenia-mozna-liczyc-6859614190930624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-01-26 05:23:12+00:00
 - user: None

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c4a5e7d7-b240-427a-b0b0-0ff7174fc74e" width="308" /> Tylko do końca czerwca 2022 r. ZUS wypłacił ponad 289 tysięcy świadczeń emerytalno-rentowych o łącznej wartości 3,3 mld złotych w ramach umów międzynarodowych. Większość z tych pieniędzy otrzymali obywatele Polski, którzy składki odprowadzali nie tylko w Polsce, ale i w państwach UE lub EFTA.
