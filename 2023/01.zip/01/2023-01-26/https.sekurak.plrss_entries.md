# Source Sekurak, Source URL:https://sekurak.pl/rss, Source language: pl-PL

## Znalazł publicznie dostępną bazę z danymi prawie wszystkich obywateli Austrii. Służyła do namierzania osób uchylających się od płacenia abonamentu RTV
 - [https://sekurak.pl/znalazl-publicznie-dostepna-baze-z-danymi-prawie-wszystkich-obywateli-austrii-sluzyla-do-namierzania-osob-uchylajacych-sie-od-placenia-abonamentu-rtv/](https://sekurak.pl/znalazl-publicznie-dostepna-baze-z-danymi-prawie-wszystkich-obywateli-austrii-sluzyla-do-namierzania-osob-uchylajacych-sie-od-placenia-abonamentu-rtv/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-26 20:18:14+00:00
 - user: None

<p>Celem była baza danych należąca do austriackiej organizacji GIS (zajmującej się zbieraniem opłat abonamentowych za posiadanie telewizora / radia / etc). Baza została stworzona do tego, aby namierzać osoby uchylające się od płacenia abonamentu. No więc restrukturyzacja bazy, podwykonawca, środowisko testowe&#8230; ale z danymi produkcyjnymi. Środowisko testowe, wiec &#8222;nie ma...</p>
<p>Artykuł <a href="https://sekurak.pl/znalazl-publicznie-dostepna-baze-z-danymi-prawie-wszystkich-obywateli-austrii-sluzyla-do-namierzania-osob-uchylajacych-sie-od-placenia-abonamentu-rtv/" rel="nofollow">Znalazł publicznie dostępną bazę z danymi prawie wszystkich obywateli Austrii. Służyła do namierzania osób uchylających się od płacenia abonamentu RTV</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Uderzyli w Hive – jedną z bardziej aktywnych grup ransomware. Zwinięta infrastruktura, odzyskane 1300 kluczy deszyfrujących (!)
 - [https://sekurak.pl/uderzyli-w-hive-jedna-z-bardziej-aktywnych-grup-ransomware-zwinieta-infrastruktura-odzyskane-1300-kluczy-deszyfrujacych/](https://sekurak.pl/uderzyli-w-hive-jedna-z-bardziej-aktywnych-grup-ransomware-zwinieta-infrastruktura-odzyskane-1300-kluczy-deszyfrujacych/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-26 19:49:59+00:00
 - user: None

<p>Całość to pokłosie wspólnej operacji Europolu oraz FBI. Grupa Hive działała w dość standardowym modelu: ekipa atakująca / wymuszająca okup (inkasowała ona 80% okupu) oraz deweloperzy głównego &#8222;produktu&#8221; (20%). Historycznie, czasem udawało się odszyfrować pliki zainfekowane Hive (patrz: Przyspieszony kurs łamania kryptografii Hive ransomware ;-)), ale teraz nie ma to...</p>
<p>Artykuł <a href="https://sekurak.pl/uderzyli-w-hive-jedna-z-bardziej-aktywnych-grup-ransomware-zwinieta-infrastruktura-odzyskane-1300-kluczy-deszyfrujacych/" rel="nofollow">Uderzyli w Hive &#8211; jedną z bardziej aktywnych grup ransomware. Zwinięta infrastruktura, odzyskane 1300 kluczy deszyfrujących (!)</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Zhackowali appkę, która kradła dane kart płatniczych.  Dali alert dla potencjalnych ofiar.
 - [https://sekurak.pl/zhackowali-appke-ktora-kradla-dane-kart-platniczych-dali-alert-dla-potencjalnych-ofiar/](https://sekurak.pl/zhackowali-appke-ktora-kradla-dane-kart-platniczych-dali-alert-dla-potencjalnych-ofiar/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-26 10:00:03+00:00
 - user: None

<p>Scammerzy przygotowali dość prostą appkę androidową, która pod pozorem super nagrody w postaci punktów lojalnościowych do pewnego programu, zbierała dane kart płatniczych. Hackerzy najpierw zdekompilowali appkę, gdzie widać w którym miejscu znajduje się API, z którym komunikuje się appka. Widzicie /api/signup.php ? Ten signup w sumie niewiele dawał, ale skłonił...</p>
<p>Artykuł <a href="https://sekurak.pl/zhackowali-appke-ktora-kradla-dane-kart-platniczych-dali-alert-dla-potencjalnych-ofiar/" rel="nofollow">Zhackowali appkę, która kradła dane kart płatniczych.  Dali alert dla potencjalnych ofiar.</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Szalona akcja z kilkoma paletami jajek. Jajka niespodzianki okazały się… niespodzianką: 35 latka z ~Suwałk straciła 1750 zł
 - [https://sekurak.pl/szalona-akcja-z-kilkoma-paletami-jajek-jajka-niespodzianki-okazaly-sie-niespodzianka-35-latka-z-suwalk-stracila-1750-zl/](https://sekurak.pl/szalona-akcja-z-kilkoma-paletami-jajek-jajka-niespodzianki-okazaly-sie-niespodzianka-35-latka-z-suwalk-stracila-1750-zl/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-26 09:02:32+00:00
 - user: None

<p>Cyberzbóje &#8211; trzeba przyznać &#8211; mają czasem fantazję. Jak czytamy na stronach policji: Do suwalskich policjantów zgłosiła się 35-latka, która została oszukana w sieci. Kobieta znalazła atrakcyjne ogłoszenie na jednym z portali aukcyjnych. Mieszkaniec południowej Polski oferował w nim nieodpłatnie pięć palet jajek z niespodzianką. Swoją decyzję uzasadnił tym, że...</p>
<p>Artykuł <a href="https://sekurak.pl/szalona-akcja-z-kilkoma-paletami-jajek-jajka-niespodzianki-okazaly-sie-niespodzianka-35-latka-z-suwalk-stracila-1750-zl/" rel="nofollow">Szalona akcja z kilkoma paletami jajek. Jajka niespodzianki okazały się&#8230; niespodzianką: 35 latka z ~Suwałk straciła 1750 zł</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

## Zwrot podatku? Fantastycznie! Tylko, że w tym przypadku pieniądze powędrują z Twojego konta na konto przestępcy [uwaga!]
 - [https://sekurak.pl/zwrot-podatku-fantastycznie-tylko-ze-w-tym-przypadku-pieniadze-powedruja-z-twojego-konta-na-konto-przestepcy-uwaga/](https://sekurak.pl/zwrot-podatku-fantastycznie-tylko-ze-w-tym-przypadku-pieniadze-powedruja-z-twojego-konta-na-konto-przestepcy-uwaga/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-01-26 08:44:33+00:00
 - user: None

<p>Jeden z czytelników poinformował nas o takim e-mailu, który otrzymał. Jak zwykle przestępcom coś się nie dotłumaczyło &#8211; patrz prawy dolny róg. Niektórzy rozpoznają scam po dość podejrzanym zwrocie 'Szanowny Obywatelu&#8217;. Ale powinniśmy przede wszystkim patrzyć na email, z którego ta wiadomość została wysłana: &#60;infos[@]chabrouch.com> &#8211; nie wygląda to na...</p>
<p>Artykuł <a href="https://sekurak.pl/zwrot-podatku-fantastycznie-tylko-ze-w-tym-przypadku-pieniadze-powedruja-z-twojego-konta-na-konto-przestepcy-uwaga/" rel="nofollow">Zwrot podatku? Fantastycznie! Tylko, że w tym przypadku pieniądze powędrują z Twojego konta na konto przestępcy [uwaga!]</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>
