# Source Epoch times world, Source URL:https://www.theepochtimes.com/c-world/feed/, Source language: en-US

## BC to Install Earthquake Warning Sensors to Give Life-Saving Notice
 - [https://www.theepochtimes.com/bc-to-install-earthquake-warning-sensors-to-give-life-saving-notice_5014045.html](https://www.theepochtimes.com/bc-to-install-earthquake-warning-sensors-to-give-life-saving-notice_5014045.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 23:24:43+00:00
 - user: None

Up to 50 earthquake early warning sensors are being installed around British Columbia as part of a larger plan to protect people and infrastructure in a big quake. A mobile phone customer looks at an earthquake warning application on their phone in Los Angeles, Jan. 3, 2019. (The Canadian Press/AP-Richard Vogel)

## Senate Foreign Relations Committee Hears Testimony on ‘Russian Aggression’
 - [https://www.theepochtimes.com/senate-foreign-relations-committee-hears-testimony-on-russian-aggression_5013635.html](https://www.theepochtimes.com/senate-foreign-relations-committee-hears-testimony-on-russian-aggression_5013635.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 22:48:04+00:00
 - user: None

Undersecretary of State for Political Affairs Victoria Nuland testifies before a Senate Foreign Relation Committee hearing on Ukraine, in Washington, on March 8, 2022. (Kevin Dietsch/Getty Images)

## ‘You Bring Us the World’: Australia Welcomes Newest Citizens on Australia Day
 - [https://www.theepochtimes.com/you-bring-us-the-world-australia-welcomes-newest-citizens-on-australia-day_5011955.html](https://www.theepochtimes.com/you-bring-us-the-world-australia-welcomes-newest-citizens-on-australia-day_5011955.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 22:45:07+00:00
 - user: None

A young boy waves an Australian flag during a rally for refugee rights outside Parliament House in Canberra, Australia, on Sept. 6, 2022. (AAP Image/Lukas Coch)

## Rogers-Shaw Deal Will Disproportionately Impact Lower-Income Canadians, MPs Hear
 - [https://www.theepochtimes.com/rogers-shaw-deal-will-disproportionately-impact-lower-income-canadians-mps-hear_5013139.html](https://www.theepochtimes.com/rogers-shaw-deal-will-disproportionately-impact-lower-income-canadians-mps-hear_5013139.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 22:35:36+00:00
 - user: None

A woman holds two cellphones in this photo illustration, March 29, 2021 in Chelsea, Que. (The Canadian Press/Adrian Wyld)

## New Australian Inflation Figures Reinforce Expectations of More Interest Rate Hikes in 2023
 - [https://www.theepochtimes.com/new-australian-inflation-figures-reinforce-expectations-of-more-interest-rate-hikes-in-2023_5011960.html](https://www.theepochtimes.com/new-australian-inflation-figures-reinforce-expectations-of-more-interest-rate-hikes-in-2023_5011960.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 22:10:35+00:00
 - user: None

Pedestrians move along George Street in Sydney, Australia, on Oct. 22, 2022. (Lisa Maree Williams/Getty Images)

## Toronto to Increase Police Presence on Transit System Following Spike in Violence
 - [https://www.theepochtimes.com/toronto-to-increase-police-presence-on-ttc-following-spike-in-violence_5013136.html](https://www.theepochtimes.com/toronto-to-increase-police-presence-on-ttc-following-spike-in-violence_5013136.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 21:52:01+00:00
 - user: None

Police cars surround a TTC streetcar on Spadina Ave., in Toronto on Jan. 24, 2023 after a stabbing incident. The president of a Canadian transit union wants to convene a national task force as violent attacks on public transit reach what he calls "crisis levels." (The Canadian Press/Arlyn McAdorey)

## Alberta Library’s Drag Queen Storytime for Children Meets With Protest
 - [https://www.theepochtimes.com/alberta-librarys-drag-queen-story-time-for-children-meets-with-protest_5013028.html](https://www.theepochtimes.com/alberta-librarys-drag-queen-story-time-for-children-meets-with-protest_5013028.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 21:12:52+00:00
 - user: None

A file photo of a protester demonstrating against a drag queen performance for children in Vancouver on Jan. 14, 2023. (Jeff Sandes/The Epoch Times)

## Doctors Concerned Avocado Hand Injuries on the Rise
 - [https://www.theepochtimes.com/doctors-concerned-avocado-hand-injuries-on-the-rise_5008853.html](https://www.theepochtimes.com/doctors-concerned-avocado-hand-injuries-on-the-rise_5008853.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 21:00:47+00:00
 - user: None

Don't let brunch end badly, says doctors. (AP Photo/Matthew Mead)

## Canada Drops out of Top 10 Countries in Global Ranking of ‘Human Freedom’
 - [https://www.theepochtimes.com/canada-drops-out-of-top-10-countries-in-global-ranking-of-human-freedom_5013304.html](https://www.theepochtimes.com/canada-drops-out-of-top-10-countries-in-global-ranking-of-human-freedom_5013304.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 20:58:27+00:00
 - user: None

The Canadian flag flies near the Peace Tower on Parliament Hill in Ottawa on June 17, 2020. (Adrian Wyld/The Canadian Press)

## Public Works Raises McKinsey Contract Total to $104.6M, Says Millions Awarded by Other Departments
 - [https://www.theepochtimes.com/public-works-raises-mckinsey-contract-total-to-104-6m-says-millions-awarded-by-other-departments_5013438.html](https://www.theepochtimes.com/public-works-raises-mckinsey-contract-total-to-104-6m-says-millions-awarded-by-other-departments_5013438.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 20:51:26+00:00
 - user: None

This photograph taken on April 12, 2022, shows a sign of US-based McKinsey &#038; Company management consulting firm in Geneva. (Fabrice Coffrini/AFP via Getty Images)

## ‘Let the People Decide’: Nationals Senator Propose to Put Australian Day to a Vote
 - [https://www.theepochtimes.com/let-the-people-decide-nationals-senator-propose-to-put-australian-day-to-a-vote_5011842.html](https://www.theepochtimes.com/let-the-people-decide-nationals-senator-propose-to-put-australian-day-to-a-vote_5011842.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 20:49:20+00:00
 - user: None

People attend the Australia Day parade in Melbourne, Australia, on Jan. 26, 2020. (Robert Cianflone/Getty Images)

## Former Liberal Minister Kirsty Duncan Taking Medical Leave, Will Stay on as MP
 - [https://www.theepochtimes.com/former-liberal-minister-kirsty-duncan-taking-medical-leave-will-stay-on-as-mp_5013328.html](https://www.theepochtimes.com/former-liberal-minister-kirsty-duncan-taking-medical-leave-will-stay-on-as-mp_5013328.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 19:54:59+00:00
 - user: None

Minister of Science, Sport and Persons with Disabilities Kirsty Duncan rises during Question Period in the House of Commons on Parliament Hill in Ottawa on Mar. 1, 2018. (The Canadian Press/Justin Tang)

## Liberal MPs Begin Three-Day Caucus Retreat With a Focus on Affordability
 - [https://www.theepochtimes.com/liberal-mps-begin-three-day-caucus-retreat-with-a-focus-on-affordability_5013307.html](https://www.theepochtimes.com/liberal-mps-begin-three-day-caucus-retreat-with-a-focus-on-affordability_5013307.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 19:50:53+00:00
 - user: None

Liberal Party of Canada Caucus Chair Brenda Shanahan speaks at the national caucus holiday party in Ottawa, on Dec. 14, 2022. (The Canadian Press/Spencer Colby)

## BC Says It Won’t Drop Vaccine Mandate as Rural Mayors Raise Alarm Over Nursing Shortages, Hospital Closures
 - [https://www.theepochtimes.com/bc-says-it-wont-drop-vaccine-mandate-as-rural-mayors-raise-alarm-over-nursing-shortages-hospital-closures_5012996.html](https://www.theepochtimes.com/bc-says-it-wont-drop-vaccine-mandate-as-rural-mayors-raise-alarm-over-nursing-shortages-hospital-closures_5012996.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 19:48:48+00:00
 - user: None

Ambulances are parked at the entrance to the emergency department at Richmond General Hospital, in Richmond, B.C., on Nov. 27, 2022. (The Canadian Press/Darryl Dyck)

## ‘Not Just Symbolism’: Canada Sending Four Battle Tanks to Ukraine, Says Defence Minister
 - [https://www.theepochtimes.com/not-just-symbolism-canada-sending-four-battle-tanks-to-ukraine-says-defence-minister_5013112.html](https://www.theepochtimes.com/not-just-symbolism-canada-sending-four-battle-tanks-to-ukraine-says-defence-minister_5013112.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 19:22:02+00:00
 - user: None

A Leopard 2A4 tank from Lord Strathcona’s Horse (Royal Canadians) travels on the Black Route of the 3rd Canadian Division Support Base Garrison Wainwright Training Centre in preparation for Exercise MAPLE RESOLVE 21, on April 30, 2021. ( Sailor First Class Camden Scott, Canadian Armed Forces photo via Flickr)

## Amid Rash of Violence on Toronto Transit, Officials Try to Keep People Safe
 - [https://www.theepochtimes.com/amid-rash-of-violence-on-toronto-transit-officials-try-to-keep-people-safe_5012724.html](https://www.theepochtimes.com/amid-rash-of-violence-on-toronto-transit-officials-try-to-keep-people-safe_5012724.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 19:08:11+00:00
 - user: None

A Toronto Transit Commission streetcar in a file photo. (Doug Ives/The Canadian Press)

## Pentagon Holds Briefing After the Announcement of Tanks for Ukraine
 - [https://www.theepochtimes.com/pentagon-holds-briefing-after-the-announcement-of-tanks-for-ukraine_5012784.html](https://www.theepochtimes.com/pentagon-holds-briefing-after-the-announcement-of-tanks-for-ukraine_5012784.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:47:36+00:00
 - user: None

Department of Defense Deputy press secretary Sabrina Singh holds a press briefing in Arlington, Va., on Jan. 19, 2023, in a still from video. (DVIDS via Reuters/Screenshot via NTD)

## UK Government Urged to Stop Housing Unaccompanied Immigrant Children in Hotels
 - [https://www.theepochtimes.com/uk-government-urged-to-stop-housing-unaccompanied-immigrant-children-in-hotels_5012080.html](https://www.theepochtimes.com/uk-government-urged-to-stop-housing-unaccompanied-immigrant-children-in-hotels_5012080.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:37:28+00:00
 - user: None

A group of illegal immigrants are brought in to Dover, Kent, from a Border Force vessel following a small boat incident in the English Channel, on Sept. 22, 2022. (Gareth Fuller/PA Media)

## Ex-pq Legislator Harold LeBel Sentenced to Eight Months in Jail for Sex Assault
 - [https://www.theepochtimes.com/ex-pq-legislator-harold-lebel-sentenced-to-eight-months-in-jail-for-sex-assault_5013071.html](https://www.theepochtimes.com/ex-pq-legislator-harold-lebel-sentenced-to-eight-months-in-jail-for-sex-assault_5013071.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:33:47+00:00
 - user: None

Former Parti Québécois MNA Harold LeBel walks to the courtroom after a break at the courthouse, in Rimouski, Que., Nov. 14, 2022. (The Canadian Press/Jacques Boissinot)

## No More Expensing Home Internet Bills to Taxpayers, Pierre Poilievre’s Caucus Told
 - [https://www.theepochtimes.com/no-more-expensing-home-internet-bills-to-taxpayers-pierre-poilievres-caucus-told_5013056.html](https://www.theepochtimes.com/no-more-expensing-home-internet-bills-to-taxpayers-pierre-poilievres-caucus-told_5013056.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:29:35+00:00
 - user: None

Conservative leader Pierre Poilievre holds a press conference in the foyer of the House of Commons on Parliament Hill in Ottawa on Jan. 25, 2023.(The Canadian Press/Sean Kilpatrick)

## Impersonators Posing as Homeowners Linked to 32 Fraud Cases in Ontario and BC
 - [https://www.theepochtimes.com/impersonators-posing-as-homeowners-linked-to-32-fraud-cases-in-ontario-and-bc_5013048.html](https://www.theepochtimes.com/impersonators-posing-as-homeowners-linked-to-32-fraud-cases-in-ontario-and-bc_5013048.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:25:44+00:00
 - user: None

The sign on the Aura condominium building is shown in Toronto on Jan. 17, 2023. (The Canadian Press/Frank Gunn)

## VIA Rail Execs Face Questions From MPs About Prolonged Holiday Travel Delays
 - [https://www.theepochtimes.com/via-rail-execs-face-questions-from-mps-about-prolonged-holiday-travel-delays_5012409.html](https://www.theepochtimes.com/via-rail-execs-face-questions-from-mps-about-prolonged-holiday-travel-delays_5012409.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 18:22:36+00:00
 - user: None

Signage at a Via Rail station in Ottawa on July 11, 2022. (Sean Kilpatrick/The Canadian Press)

## European Commission Approves 2 More Insect Species as ‘Food’ for Humans
 - [https://www.theepochtimes.com/european-commission-approves-2-more-insect-species-as-food-for-humans_5012286.html](https://www.theepochtimes.com/european-commission-approves-2-more-insect-species-as-food-for-humans_5012286.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 17:46:12+00:00
 - user: None

Flour ground from dried crickets and crickets in jars, for the first mass-delivered bread made of insects, are seen at the Finnish food company Fazer bakery in Helsinki, Finland, on Nov. 23, 2017. (Attila Cser/Reuters)

## More Than 160 Afghans Die in Bitterly Cold Weather
 - [https://www.theepochtimes.com/more-than-160-afghans-die-in-bitterly-cold-weather_5012594.html](https://www.theepochtimes.com/more-than-160-afghans-die-in-bitterly-cold-weather_5012594.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 17:40:11+00:00
 - user: None

People walk on a snow-covered street in Kabul, Afghanistan, on Jan. 26, 2023. (Ali Khara/Reuters)

## Australian Firm Launches Bid to Rescue Collapsed UK Battery Company Britishvolt
 - [https://www.theepochtimes.com/australian-firm-launches-bid-to-rescue-collapsed-uk-battery-company-britishvolt_5012747.html](https://www.theepochtimes.com/australian-firm-launches-bid-to-rescue-collapsed-uk-battery-company-britishvolt_5012747.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 17:33:44+00:00
 - user: None

Peter Rolton, executive chairman of electric vehicle battery start-up Britishvolt, shows a billboard at the site of the company's large planned battery plant, in the former industrial town of Blyth, England, on Jan. 27, 2022. (Nick Carey/Reuters)

## Asteroid to Pass Closer to Earth Than Satellites
 - [https://www.theepochtimes.com/asteroid-to-pass-closer-to-earth-than-satellites_5012624.html](https://www.theepochtimes.com/asteroid-to-pass-closer-to-earth-than-satellites_5012624.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 17:23:08+00:00
 - user: None

The estimated trajectory of asteroid 2023 BU, in red, and the orbit of geosynchronous satellites, in green. (NASA/JPL-Caltech via AP)

## Iranian and Russian Hackers Targeting UK Politicians and Journalists: Cyber Watchdog
 - [https://www.theepochtimes.com/iranian-and-russian-hackers-targeting-uk-politicians-and-journalists-cyber-watchdog_5012294.html](https://www.theepochtimes.com/iranian-and-russian-hackers-targeting-uk-politicians-and-journalists-cyber-watchdog_5012294.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 16:55:09+00:00
 - user: None

In an illustration image, a man types on a computer keyboard in Warsaw in this Feb. 28, 2013. (Kacper Pempel/Reuters)

## Russian Athletes Could Participate in Asian Competitions: IOC
 - [https://www.theepochtimes.com/russian-athletes-could-participate-in-asian-competitions-ioc_5012089.html](https://www.theepochtimes.com/russian-athletes-could-participate-in-asian-competitions-ioc_5012089.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 16:50:20+00:00
 - user: None

Olympic Rings in front of The Olympic House, headquarters of the International Olympic Committee (IOC) at the opening of the executive board meeting of the International Olympic Committee (IOC), in Lausanne, Switzerland, on Sept. 8, 2022. (Laurent Gillieron/Reuters)

## US and Global Economy to Grow Slower in 2023, Possibility of Recession in Some Nations: UN
 - [https://www.theepochtimes.com/us-and-global-economy-to-grow-slower-in-2023-possibility-of-recession-in-some-nations-un_5012671.html](https://www.theepochtimes.com/us-and-global-economy-to-grow-slower-in-2023-possibility-of-recession-in-some-nations-un_5012671.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 16:44:54+00:00
 - user: None

Image of national flags in front of United Nations headquarters in Geneva, Switzerland. (FABRICE COFFRINI / AFP)

## Petroleum Analyst Issues Warning to Drivers: Gas Prices to Rise Again to $4
 - [https://www.theepochtimes.com/petroleum-analyst-issues-warning-to-drivers-gas-prices-to-rise-again-to-4_5012664.html](https://www.theepochtimes.com/petroleum-analyst-issues-warning-to-drivers-gas-prices-to-rise-again-to-4_5012664.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 16:41:42+00:00
 - user: None

A gas pump is seen situated while pumping gas at a Shell gas station in Houston, Texas, on April 1, 2022. (Brandon Bell/Getty Images)

## Winter Storm Hits Southern Quebec and Atlantic Provinces
 - [https://www.theepochtimes.com/winter-storm-hits-southern-quebec-and-atlantic-provinces_5012621.html](https://www.theepochtimes.com/winter-storm-hits-southern-quebec-and-atlantic-provinces_5012621.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 16:39:07+00:00
 - user: None

A pedestrian crosses a street in Halifax during a winter storm on Jan. 20, 2023. (The Canadian Press/Darren Calabrese)

## Djokovic Targets 10th Australian Open Final, Paul Looks to Flip the Script
 - [https://www.theepochtimes.com/djokovic-targets-10th-australian-open-final-paul-looks-to-flip-the-script_5012141.html](https://www.theepochtimes.com/djokovic-targets-10th-australian-open-final-paul-looks-to-flip-the-script_5012141.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 15:57:58+00:00
 - user: None

Serbia’s Novak Djokovic celebrates winning his quarter final match against Russia’s Andrey Rublev during the Australian Open, in Melbourne Park, Melbourne, Australia, on Jan. 25, 2023. (Jaimi Joy/Reuters)

## Dow to Slash 2,000 Jobs as Part of $1 Billion Cost-Savings Plan
 - [https://www.theepochtimes.com/dow-to-slash-2000-jobs-as-part-of-1-billion-cost-savings-plan_5012540.html](https://www.theepochtimes.com/dow-to-slash-2000-jobs-as-part-of-1-billion-cost-savings-plan_5012540.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 15:49:09+00:00
 - user: None

The Dow Chemical headquarters in Midland, Michigan, on Dec. 10, 2015. (Bill Pugliano/Getty Images)

## Home Depot Gave Personal Data to Meta Without Valid Customer Consent: Watchdog
 - [https://www.theepochtimes.com/home-depot-gave-personal-data-to-meta-without-valid-customer-consent-watchdog_5012607.html](https://www.theepochtimes.com/home-depot-gave-personal-data-to-meta-without-valid-customer-consent-watchdog_5012607.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 15:46:49+00:00
 - user: None

A Home Depot logo sign is shown, May 14, 2021, in North Miami, Fla. (The Canadian Press /Wilfredo Lee)

## Russia Fires Missiles at Ukraine After Kyiv Secures Tanks
 - [https://www.theepochtimes.com/russia-fires-missiles-at-ukraine-after-kyiv-secures-tanks_5012303.html](https://www.theepochtimes.com/russia-fires-missiles-at-ukraine-after-kyiv-secures-tanks_5012303.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 15:34:33+00:00
 - user: None

Local residents remove debris from a house of their neighbour damaged by a Russian military strike, in the town of Hlevakha, outside Kyiv, Ukraine, on Jan. 26, 2023. (Valentyn Ogirenko/Reuters)

## Incel Ideology That Urges Followers to ‘Take the Red Pill’ Is on the Rise, Says UK Researcher
 - [https://www.theepochtimes.com/incel-ideology-that-urges-followers-to-take-the-red-pill-is-on-the-rise-says-uk-researcher_5003937.html](https://www.theepochtimes.com/incel-ideology-that-urges-followers-to-take-the-red-pill-is-on-the-rise-says-uk-researcher_5003937.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 15:29:09+00:00
 - user: None

A fan cosplays as Morpheus from "The Matrix" during the 2018 New York Comic-Con at Javits Center, New York City, on Oct. 7, 2018. (Roy Rochlin/Getty Images)

## Rogers Will Cut At Least 4,000 Jobs if Cabinet Approves Shaw Buyout, Claims Conservative MP
 - [https://www.theepochtimes.com/rogers-will-cut-at-least-4000-jobs-if-cabinet-approves-shaw-buyout-claims-conservative-mp_5012269.html](https://www.theepochtimes.com/rogers-will-cut-at-least-4000-jobs-if-cabinet-approves-shaw-buyout-claims-conservative-mp_5012269.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 14:55:50+00:00
 - user: None

Ethernet cables are seen in front of Rogers and Shaw Communications logos in this illustration taken, July 8, 2022. (Reuters/Dado Ruvic/Illustrations)

## Ottawa Venue Expands Seating for Jordan Peterson Lecture as Groups Try to Cancel It
 - [https://www.theepochtimes.com/ottawa-venue-expands-seating-for-jordan-peterson-lecture-as-groups-try-to-cancel-it_5012228.html](https://www.theepochtimes.com/ottawa-venue-expands-seating-for-jordan-peterson-lecture-as-groups-try-to-cancel-it_5012228.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 14:48:40+00:00
 - user: None

Jordan Peterson, Canadian clinical psychologist and professor of psychology at the University of Toronto, explains the communist roots of postmodernism during an interview with The Epoch Times on June 15, 2018. (The Epoch Times)

## On First Anniversary of Freedom Convoy, Protesters Tell Their Stories
 - [https://www.theepochtimes.com/on-first-anniversary-of-freedom-convoy-protesters-tell-their-stories_5007712.html](https://www.theepochtimes.com/on-first-anniversary-of-freedom-convoy-protesters-tell-their-stories_5007712.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 14:21:10+00:00
 - user: None

A protester holds a sign on Wellington St. during the Freedom Convoy protest in Ottawa on Feb. 12, 2022. (Noé Chartier/The Epoch Times)

## At Least 1 Dead, Several Injured in Machete Attack at Southern Spain Churches
 - [https://www.theepochtimes.com/at-least-1-dead-several-injured-in-machete-attack-at-southern-spain-churches_5012301.html](https://www.theepochtimes.com/at-least-1-dead-several-injured-in-machete-attack-at-southern-spain-churches_5012301.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 14:14:47+00:00
 - user: None

Police officers stand guard at the scene of a stabbing incident at a church in Algeciras, Spain, on Jan. 25, 2023, in this screen grab from a video. (FORTA/via Reuters/Handout via Reuters)

## Scottish First Minister Confirms Trans Rapist Won’t Be Held at All-Female Prison
 - [https://www.theepochtimes.com/scottish-first-minister-confirms-trans-rapist-wont-be-held-at-all-female-prison_5009205.html](https://www.theepochtimes.com/scottish-first-minister-confirms-trans-rapist-wont-be-held-at-all-female-prison_5009205.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 14:01:46+00:00
 - user: None

Isla Bryson, 31, formerly known as Adam Graham,  arrives at the High Court in Glasgow, who a jury found guilty of raping two women, one in Clydebank in 2016 and one in Drumchapel, Glasgow, in 2019. (Andrew Milligan/PA Media)

## SAP to Cut Up to 3,000 Jobs Worldwide, Mulls Qualtrics Sale
 - [https://www.theepochtimes.com/sap-to-cut-up-to-3000-jobs-worldwide-mulls-qualtrics-sale_5012131.html](https://www.theepochtimes.com/sap-to-cut-up-to-3000-jobs-worldwide-mulls-qualtrics-sale_5012131.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 13:16:39+00:00
 - user: None

The headquarters of German software maker SAP in Walldorf near Heidelberg, Germany, on Nov. 5, 2003. (Michael Probst/AP Photo)

## Lexus Chief to Take Over Toyota as Founder’s Grandson Steps Down
 - [https://www.theepochtimes.com/lexus-chief-to-take-over-toyota-as-founders-grandson-steps-down_5012242.html](https://www.theepochtimes.com/lexus-chief-to-take-over-toyota-as-founders-grandson-steps-down_5012242.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 13:09:46+00:00
 - user: None

Undated photo shows Toyota Motor Corp. President Akio Toyoda and Operating Officer Koji Sato test-riding Lexus's first electric vehicle model, RZ in Japan in this photo provided on Jan. 26, 2023. (Kyodo/via Reuters)

## Russia’s Military Reforms Respond to NATO’s Expansion, Ukraine: Chief of General Staff
 - [https://www.theepochtimes.com/russias-military-reforms-respond-to-natos-expansion-ukraine-chief-of-general-staff_5006326.html](https://www.theepochtimes.com/russias-military-reforms-respond-to-natos-expansion-ukraine-chief-of-general-staff_5006326.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 09:49:53+00:00
 - user: None

Chief of the General Staff of Russian Armed Forces Valery Gerasimov attends an annual meeting of the Defence Ministry Board in Moscow on Dec. 21, 2022. (Sputnik/Sergei Fadeichev/Pool via Reuters Attention Editors)

## Iran Sanctions Europeans Over Criticism of Protest Crackdown
 - [https://www.theepochtimes.com/iran-sanctions-europeans-over-criticism-of-protest-crackdown_5010904.html](https://www.theepochtimes.com/iran-sanctions-europeans-over-criticism-of-protest-crackdown_5010904.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 09:42:39+00:00
 - user: None

A locator map for Iran with its capital, Tehran. (AP Photo)

## 2 Killed in Knife Attack on Train in Northern Germany
 - [https://www.theepochtimes.com/two-killed-in-knife-attack-on-train-in-northern-germany_5010921.html](https://www.theepochtimes.com/two-killed-in-knife-attack-on-train-in-northern-germany_5010921.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 09:33:00+00:00
 - user: None

A train stands at a railway station after an incident involving a knife attack took place on a train travelling between Kiel and Hamburg in Brokstedt, Germany, on Jan. 25, 2023. (Fabian Bimmer/Reuters)

## Red Crescent: 8 Dead, 58 Missing After Shipwreck Off Libya
 - [https://www.theepochtimes.com/red-crescent-8-dead-58-missing-after-shipwreck-off-libya_5011162.html](https://www.theepochtimes.com/red-crescent-8-dead-58-missing-after-shipwreck-off-libya_5011162.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 09:15:36+00:00
 - user: None

A locator map for Libya with its capital, Tripoli. (AP Photo)

## US Board Says Boeing Max Likely Hit a Bird Before 2019 Crash
 - [https://www.theepochtimes.com/us-board-says-boeing-max-likely-hit-a-bird-before-2019-crash_5006794.html](https://www.theepochtimes.com/us-board-says-boeing-max-likely-hit-a-bird-before-2019-crash_5006794.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 08:26:35+00:00
 - user: None

Airplane parts lie on the ground at the scene of an Ethiopian Airlines flight crash near Bishoftu, or Debre Zeit, south of Addis Ababa, Ethiopia, March 11, 2019. (AP Photo/Mulugeta Ayene)

## Kremlin Expresses Alarm Over ‘Doomsday Clock,’ Blames US and NATO
 - [https://www.theepochtimes.com/kremlin-expresses-alarm-over-doomsday-clock-blames-us-and-nato_5009442.html](https://www.theepochtimes.com/kremlin-expresses-alarm-over-doomsday-clock-blames-us-and-nato_5009442.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 08:10:16+00:00
 - user: None

The clock with the Bulletin of the Atomic Scientists is being placed at a TV studio ahead of the announcement of the location of the minute hand on its Doomsday Clock, indicating what world developments mean for the perceived likelihood of nuclear catastrophe, at the National Press Club in Washington on Jan. 24, 2023. (Leah Millis/Reuters)

## Journalist Deaths Jumped 50 Percent in 2022, Led by Ukraine, Mexico
 - [https://www.theepochtimes.com/journalist-deaths-jumped-50-percent-in-2022-led-by-ukraine-mexico_5007465.html](https://www.theepochtimes.com/journalist-deaths-jumped-50-percent-in-2022-led-by-ukraine-mexico_5007465.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 07:51:49+00:00
 - user: None

Photos of slain journalists are displayed on a wall during a vigil to protest the murder of journalist Fredid Roman, outside Mexico's Attorney General's office in Mexico City on Aug. 24, 2022. (Eduardo Verdugo/AP Photo)

## Former Kickboxer Andrew Tate Says Romanian Prosecutors Have No Evidence Against Him
 - [https://www.theepochtimes.com/former-kickboxer-andrew-tate-says-romanian-prosecutors-have-no-evidence-against-him_5009427.html](https://www.theepochtimes.com/former-kickboxer-andrew-tate-says-romanian-prosecutors-have-no-evidence-against-him_5009427.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 07:43:55+00:00
 - user: None

Andrew Tate and his brother Tristan are escorted by police officers outside the headquarters of the Bucharest Court of Appeal in Bucharest, Romania, on Jan. 10, 2023. (Inquam Photos/Octav Ganea via Reuters)

## Indian Court Grants Extradition for Australia Murder Suspect
 - [https://www.theepochtimes.com/indian-court-grants-extradition-for-australia-murder-suspect_5006898.html](https://www.theepochtimes.com/indian-court-grants-extradition-for-australia-murder-suspect_5006898.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 07:19:04+00:00
 - user: None

Policemen escort Rajwinder Singh, 38, after he was arrested in New Delhi on Nov. 25, 2022. (Dinesh Joshi/AP Photo)

## Socceroos Star Awer Mabil Feels Love After Recieving Young Australian of the Year Award
 - [https://www.theepochtimes.com/socceroos-star-awer-mabil-feels-love-after-recieving-young-australian-of-the-year-award_5011753.html](https://www.theepochtimes.com/socceroos-star-awer-mabil-feels-love-after-recieving-young-australian-of-the-year-award_5011753.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 06:08:45+00:00
 - user: None

Awer Mabil of Australia reacts after scoring a goal during the International Men's Friendly match between the Australian Socceroos and the New Zealand All Whites at Suncorp Stadium in Brisbane, Thursday, September 22, 2022. (AAP Image/Dave Hunt

## Cost of Living Is ‘Number 1’ Priority, Newly Sworn in NZ PM Says as Inflation Remains at 7.2 Percent
 - [https://www.theepochtimes.com/cost-of-living-is-number-1-priority-newly-sworn-in-nz-pm-says-as-inflation-remains-at-7-2-percent_5011825.html](https://www.theepochtimes.com/cost-of-living-is-number-1-priority-newly-sworn-in-nz-pm-says-as-inflation-remains-at-7-2-percent_5011825.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 05:39:00+00:00
 - user: None

New Zealand Prime Minister Chris Hipkins speaks to media during a post-cabinet press conference at Parliament in Wellington, New Zealand, on Jan. 25, 2023. (Hagen Hopkins/Getty Images)

## Bank of Canada’s Macklem Says He Is ‘Not Even Thinking’ of Cutting Rates
 - [https://www.theepochtimes.com/bank-of-canadas-macklem-says-he-is-not-even-thinking-of-cutting-rates_5011858.html](https://www.theepochtimes.com/bank-of-canadas-macklem-says-he-is-not-even-thinking-of-cutting-rates_5011858.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 05:26:52+00:00
 - user: None

Tiff Macklem, Governor of the Bank of Canada is seen at the Bank of Canada in Ottawa, on Oct. 26, 2022. (The Canadian Press/Sean Kilpatrick)

## Terrorists Storm Government Office in Somalia’s Capital; 5 Dead
 - [https://www.theepochtimes.com/terrorists-storm-government-office-in-somalias-capital-5-dead_5003541.html](https://www.theepochtimes.com/terrorists-storm-government-office-in-somalias-capital-5-dead_5003541.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 04:59:31+00:00
 - user: None

Somalia security carry away the dead body of someone who was killed in clash between attackers and soldiers at the Banadir regional administration in Mogadishu, Somalia, on Jan. 22, 2023. (Farah Abdi Warsameh/AP Photo)

## Body Positivity Advocate Named Australian of the Year
 - [https://www.theepochtimes.com/body-positivity-advocate-named-australian-of-the-year_5011731.html](https://www.theepochtimes.com/body-positivity-advocate-named-australian-of-the-year_5011731.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 04:06:38+00:00
 - user: None

2023 Australian of the Year Taryn Brumfitt poses for photos after the 2023 Australian of the Year Awards ceremony at the National Arboretum in Canberra, Wednesday, January 25, 2023

## Australia’s World War Two Female Code Crackers Recognised For Service
 - [https://www.theepochtimes.com/australias-world-war-two-female-code-crackers-recognised-for-service_5011712.html](https://www.theepochtimes.com/australias-world-war-two-female-code-crackers-recognised-for-service_5011712.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 03:41:23+00:00
 - user: None

A supplied undated combined image obtained Wednesday, January 25, 2023 shows Joyce Grace, aged 20, during her enlistment in Paddington, Sydney, 1943. Ms Grace and two former top-secret code crackers have been recognised for their World War II service 80 years on. (AAP Image/Supplied by the National Archives Of Australia)

## Famed Australian Olympian and Rugby Player Dies Suddenly at 35
 - [https://www.theepochtimes.com/famed-australian-olympian-and-rugby-player-dies-suddenly-at-35_5009115.html](https://www.theepochtimes.com/famed-australian-olympian-and-rugby-player-dies-suddenly-at-35_5009115.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 03:28:56+00:00
 - user: None

File photo of a rugby player throwing a ball at Allianz Stadium in Sydney, Australia, on April 2, 2017.  (Mark Kolbe/Getty Images)

## Local Heroes and Community Leaders Take Centre Stage in 2023 Australia Day Awards
 - [https://www.theepochtimes.com/local-heroes-and-community-leaders-take-centre-stage-in-2023-australia-day-awards_5011629.html](https://www.theepochtimes.com/local-heroes-and-community-leaders-take-centre-stage-in-2023-australia-day-awards_5011629.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 03:21:59+00:00
 - user: None

The flag raising ceremony at Lake Burley Griffin in Canberra, Australia, on Jan. 26, 2020. (Rohan Thomson/Getty Images)

## Poilievre Launches Consultations With First Nations on Resource Revenues
 - [https://www.theepochtimes.com/poilievre-kicks-off-consultations-with-first-nations-on-resource-revenues_5011594.html](https://www.theepochtimes.com/poilievre-kicks-off-consultations-with-first-nations-on-resource-revenues_5011594.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 03:05:28+00:00
 - user: None

Conservative Leader Pierre Poilievre rises to question the government during Question Period, in Ottawa on Sept. 26, 2022. (Adrian Wyld/The Canadian Press)

## Australia Day Worth Celebrating Says Governor General
 - [https://www.theepochtimes.com/australia-day-worth-celebrating-says-governor-general_5011653.html](https://www.theepochtimes.com/australia-day-worth-celebrating-says-governor-general_5011653.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 02:58:22+00:00
 - user: None

Australia day has kicked off in Sydney with the sails of Opera House displaying  Indigenous Kamilaroi artist Rhonda Sampson’s ‘Diyan Warrane’ artwork at dawn in Sydney, January 26, 2023. (AAP Image/Bianca De Marchi)

## Is the West Too Gullible When It Comes to China
 - [https://www.theepochtimes.com/is-the-west-too-gullible-when-it-comes-to-china_5008971.html](https://www.theepochtimes.com/is-the-west-too-gullible-when-it-comes-to-china_5008971.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 02:44:07+00:00
 - user: None

Australia’s Prime Minister Anthony Albanese meets China’s President Xi Jinping in a bilateral meeting during the 2022 G20 summit in Nusa Dua, Bali, Indonesia, Australia, on Nov. 15, 2022. (AAP Image/Mick Tsikas)

## Wellington Airport Bookstore Sells Xi Jinping’s Political Theories At Premium Place
 - [https://www.theepochtimes.com/auckland-airport-bookstore-criticised-online-after-xi-jinpings-political-theories-given-premium-place_5010801.html](https://www.theepochtimes.com/auckland-airport-bookstore-criticised-online-after-xi-jinpings-political-theories-given-premium-place_5010801.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 00:58:49+00:00
 - user: None

premium place of the airport bookstore in Wellington, New Zealand’s capital. (supplied)

## Wellington Airport Bookstore Sells Xi Jinping’s Political Theories At Premium Place
 - [https://www.theepochtimes.com/wellington-airport-bookstore-criticised-online-after-xi-jinpings-political-theories-given-premium-place_5010801.html](https://www.theepochtimes.com/wellington-airport-bookstore-criticised-online-after-xi-jinpings-political-theories-given-premium-place_5010801.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 00:58:49+00:00
 - user: None

premium place of the airport bookstore in Wellington, New Zealand’s capital. (supplied)

## Alberta Premier Accuses CBC of Publishing ‘Defamatory Article’ With ‘Baseless Allegations,’ Calls for Apology
 - [https://www.theepochtimes.com/alberta-premier-accuses-cbc-of-publishing-defamatory-article-with-baseless-allegations-calls-for-apology_5011278.html](https://www.theepochtimes.com/alberta-premier-accuses-cbc-of-publishing-defamatory-article-with-baseless-allegations-calls-for-apology_5011278.html)
 - RSS feed: https://www.theepochtimes.com/c-world/feed/
 - date published: 2023-01-26 00:12:48+00:00
 - user: None

Alberta Premier Danielle Smith speaks at a press conference after members of her cabinet were sworn in, in Edmonton on Oct. 24, 2022. (Jason Franson/The Canadian Press)
