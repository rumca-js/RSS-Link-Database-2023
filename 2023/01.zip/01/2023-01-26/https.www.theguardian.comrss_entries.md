# Source The Guardian, Source URL:https://www.theguardian.com/rss, Source language: en-UK

## US military raid kills key Islamic State regional leader in Somalia, officials say
 - [https://www.theguardian.com/us-news/2023/jan/26/us-military-raid-somalia-islamic-state-leader-al-sudani-killed](https://www.theguardian.com/us-news/2023/jan/26/us-military-raid-somalia-islamic-state-leader-al-sudani-killed)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 23:13:17+00:00
 - user: None

<p>Bilal al-Sudani, ‘responsible for fostering the growing presence of IS in Africa’, was killed in strike approved by Joe Biden</p><p>A US military raid in Somalia ordered by President Joe Biden this week killed a key regional leader of the <a href="https://www.theguardian.com/world/islamic-state">Islamic State</a> group, Bilal al-Sudani, according to US officials.</p><p>Sudani was killed on Wednesday during a gunfight after US troops descended on a mountainous cave complex in northern Somalia hoping to capture him.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/us-military-raid-somalia-islamic-state-leader-al-sudani-killed">Continue reading...</a>

## Rod Stewart calls Sky News offering to pay for NHS hospital scans
 - [https://www.theguardian.com/music/2023/jan/26/rod-stewart-calls-sky-news-offering-to-pay-for-nhs-hospital-scans](https://www.theguardian.com/music/2023/jan/26/rod-stewart-calls-sky-news-offering-to-pay-for-nhs-hospital-scans)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 22:54:53+00:00
 - user: None

<p>Singer said the situation in UK was ‘so bad’ and it was time to ‘change the bloody government’ </p><p>Rod Stewart called a phone-in segment on Sky News to offer to pay for people to have hospital scans, amid the rising number of people on <a href="https://www.theguardian.com/society/2022/dec/08/nhs-england-waiting-lists-flu-rsv-norovirus">NHS waiting lists</a>.</p><p>The 78-year-old rock star, who has previously backed the Conservatives, said he had never seen the situation in the UK “so bad” and called for Labour to be given a chance to run the country, adding: “Change the bloody government.”</p> <a href="https://www.theguardian.com/music/2023/jan/26/rod-stewart-calls-sky-news-offering-to-pay-for-nhs-hospital-scans">Continue reading...</a>

## Arsenal thrive on Guardiola gifts to threaten Manchester City’s hegemony
 - [https://www.theguardian.com/football/2023/jan/26/arsenal-guardiola-gifts-manchester-city-jesus-zinchenko-fa-cup](https://www.theguardian.com/football/2023/jan/26/arsenal-guardiola-gifts-manchester-city-jesus-zinchenko-fa-cup)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 22:30:33+00:00
 - user: None

<p>Mikel Arteta transformed his team by signing Jesus and Zinchenko and returns to the Etihad on a high in the FA Cup</p><p>What would the response have been if Liverpool had tried to sign a couple of Manchester City’s fringe players last summer? The smart money is on City refusing to sell. They surely would have regarded Liverpool as the likeliest threat to their hopes of retaining the Premier League title and seen no value in making it that easy for them to strengthen their squad.</p><p>But it was different when Arsenal came calling for <a href="https://www.theguardian.com/football/2022/jun/26/gabriel-jesus-agrees-five-year-deal-to-join-arsenal-from-manchester-city">Gabriel Jesus</a> and <a href="https://www.theguardian.com/football/2022/jul/18/oleksandr-zinchenko-arsenal-medical-contract-30m-transfer-manchester-city">Oleksandr Zinchenko</a>. Liverpool had pushed City to the limit, taking the title race to the final day. Arsenal had relinquished fourth place to Tottenham, finished 24 points below City and for all their youthful promise done little to suggest that they were ready to challenge at the top.</p> <a href="https://www.theguardian.com/football/2023/jan/26/arsenal-guardiola-gifts-manchester-city-jesus-zinchenko-fa-cup">Continue reading...</a>

## Grayson Perry’s Full English review – dangerously close to tainting the artist’s brand
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/grayson-perry-full-english-review-comes-dangerously-close-to-tainting-the-artists-brand](https://www.theguardian.com/tv-and-radio/2023/jan/26/grayson-perry-full-english-review-comes-dangerously-close-to-tainting-the-artists-brand)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 22:00:32+00:00
 - user: None

<p>This series isn’t the first time Perry has explored our national identity, and it’s getting repetitive. It’s not helped by his failure to tackle one participant’s troubling xenophobia</p><p>The artist <a href="https://www.theguardian.com/artanddesign/grayson-perry">Grayson Perry</a> has been mining a profitable seam for a while now, making documentaries that in essence ask the English to explain themselves. Profitable in the widest sense, I mean – though obviously I hope and presume he is paid a fair wage for his work. The interrogations of class (in <a href="https://www.theguardian.com/tv-and-radio/2012/jun/19/best-possible-taste-grayson-perry">All in the Best Possible Taste With Grayson Perry</a>), masculinity (<a href="https://www.theguardian.com/tv-and-radio/2016/may/05/grayson-perry-all-man-preview">All Man</a>) and other forms of identity (in, for example, <a href="https://www.theguardian.com/artanddesign/2017/may/30/grayson-perry-to-unveil-brexit-vases-channel-4-show-divided-britain">Divided Britain,</a> which interviewed leavers and remainers about Brexit), in unhurried programmes directed by Neil Crombie, have all been fresh and illuminating. They are full of insights – provided by the endlessly perceptive Perry himself or by the interviewees who open up under his warm curiosity and direct, unaggressive questioning.</p><p>In the opening episode of the latest offering, Grayson Perry’s Full English (Channel 4), which is produced by Crombie but has a new director, things seem to have gone awry. Partly, I suspect, this is due to a growing sense of old ground being retrodden. Perry’s mission is to explore what people mean by “Englishness” through interviewing denizens of the north, south and the Midlands (collecting their donations to a planned exhibition on the subject that he will create when he gets home). “Is it an identity binding us or a fantasy keeping us stuck in the past?”</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/grayson-perry-full-english-review-comes-dangerously-close-to-tainting-the-artists-brand">Continue reading...</a>

## Toronto to deploy more officers on public transport amid random attacks
 - [https://www.theguardian.com/world/2023/jan/26/toronto-police-subways-public-transport-random-attacks](https://www.theguardian.com/world/2023/jan/26/toronto-police-subways-public-transport-random-attacks)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 21:21:57+00:00
 - user: None

<p>Police chief says 80 officers will be immediately dispatched to subways and stations as attacks bring city to ‘crisis point’</p><p>Toronto police has announced plans to deploy more officers on the city’s public transport system as a transit workers’ union warned that a string of random attacks on passengers had brought Canada’s largest city to “crisis point”.</p><p>The city’s police chief, Myron Demkiw, said on Thursday that 80 officers would be immediately dispatched to subways and stations “to enhance the safety and security” of transit users. Earlier in the day, police arrested one person following reports of teens shooting at a passenger with a BB gun.</p> <a href="https://www.theguardian.com/world/2023/jan/26/toronto-police-subways-public-transport-random-attacks">Continue reading...</a>

## Islamic extremist who killed eight people on New York bike path convicted
 - [https://www.theguardian.com/us-news/2023/jan/26/new-york-bike-terror-attack-2017-convicted-death-penalty](https://www.theguardian.com/us-news/2023/jan/26/new-york-bike-terror-attack-2017-convicted-death-penalty)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 21:12:27+00:00
 - user: None

<p>Sayfullo Saipov, who drove a truck down a popular bike path in 2017, could face the death penalty</p><p>An Islamic extremist who killed eight people with a speeding truck in <a href="https://apnews.com/article/terrorism-us-news-ap-top-news-uzbekistan-north-america-aa83dfe6157f4214a5e92efaba4142c9">a 2017 rampage</a> on a popular New York City bike path was convicted on Thursday of 28 federal crimes and could face the death penalty.</p><p><a href="https://apnews.com/hub/sayfullo-saipov">Sayfullo Saipov</a> bowed his head as he heard the verdict in the trial for an attack that prosecutors said was inspired by his reverence for the Islamic State militant group. Saipov was tried in a Manhattan courtroom just a few blocks from where the attack ended.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/new-york-bike-terror-attack-2017-convicted-death-penalty">Continue reading...</a>

## Poker Face review: Natasha Lyonne is magnetic in whodunnit series
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/poker-face-tv-review-peacock-natasha-lyonne](https://www.theguardian.com/tv-and-radio/2023/jan/26/poker-face-tv-review-peacock-natasha-lyonne)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 20:44:53+00:00
 - user: None

<p>The detective series from Knives Out writer Rian Johnson puts a refreshing twist on the mystery-of-the-week structure</p><p>Poker Face, writer-director Rian Johnson’s whodunnit series for Peacock, is the rare show to deliver on the elusive promise of fun. Plenty of TV shows aim for it – fun via competency porn, addictiveness, skewering societal critique, sexiness, suspense or brain numbness. But fun, as in well-structured, confidently filmed visual treats with the aim of delivering pure, non-binged enjoyment? Hard to come by, and suavely delivered by Poker Face’s comfortable rhythm and Natasha Lyonne’s charismatic, bumbling detective.</p><p>If last year’s <a href="https://www.theguardian.com/film/2022/sep/11/glass-onion-a-knives-out-mystery-review-sequel-has-more-bung-for-buck-but-blunter-weapon">Glass Onion</a> got bigger, more explosive and ludicrous than Johnson’s theatrical hit Knives Out, Poker Face represents ambition steadying out. (Johnson wrote and directed the pilot; the subsequent nine episodes are written and directed by numerous others, including one episode by Lyonne.) The six episodes made available for review are assured, stylish television that delivers on a near-unending string of scene-chewing guest performances, a reliable mystery-of-the-week structure and a magnetic Columbo update in Lyonne’s Charlie Cale.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/poker-face-tv-review-peacock-natasha-lyonne">Continue reading...</a>

## Man charged with terror offence after arrest at St James’s hospital in Leeds
 - [https://www.theguardian.com/uk-news/2023/jan/26/man-charged-with-terror-offence-after-arrest-at-st-jamess-hospital-in-leeds](https://www.theguardian.com/uk-news/2023/jan/26/man-charged-with-terror-offence-after-arrest-at-st-jamess-hospital-in-leeds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 20:41:10+00:00
 - user: None

<p>Mohammad Farooq, 27, from Leeds, faces charges of firearm possession and keeping explosive</p><p>A man has been charged with a terror offence after being arrested at St James’s hospital in Leeds last Friday.</p><p>Mohammad Farooq faces one charge of engaging in an act of terrorism, one charge of possessing an imitation firearm and one charge of keeping an explosive with intent to endanger life or property.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/man-charged-with-terror-offence-after-arrest-at-st-jamess-hospital-in-leeds">Continue reading...</a>

## Adam Schiff, lead prosecutor of Trump’s first impeachment, declares Senate run
 - [https://www.theguardian.com/us-news/2023/jan/26/adam-schiff-senate-run-dianne-feinstein-trump-impeachment](https://www.theguardian.com/us-news/2023/jan/26/adam-schiff-senate-run-dianne-feinstein-trump-impeachment)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:55:35+00:00
 - user: None

<p>California congressman makes play for Dianne Feinstein’s seat, which is being eyed by at least three other candidates</p><p>Adam Schiff, the California congressman who became a household name as the lead prosecutor in Donald Trump’s first impeachment, said he will seek the California Senate seat currently held by Dianne Feinstein.</p><p>“I wish I could say the threat of Maga extremists is over,” said Schiff, 62, in a video announcing his campaign. “We’re in the fight of our lives – a fight I’m ready to lead as California’s next US senator”.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/adam-schiff-senate-run-dianne-feinstein-trump-impeachment">Continue reading...</a>

## Woman lay dead in Surrey flat for more than three years, hearing told
 - [https://www.theguardian.com/uk-news/2023/jan/26/woman-lay-dead-in-surrey-flat-for-more-than-three-years-hearing-told](https://www.theguardian.com/uk-news/2023/jan/26/woman-lay-dead-in-surrey-flat-for-more-than-three-years-hearing-told)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:34:19+00:00
 - user: None

<p>Laura Winham, 38, had severe mental illnesses and was ‘abandoned’ by NHS and social services, family allege</p><p>A severely mentally ill woman whose dead body lay in her home unnoticed for more than three years was effectively “abandoned and left to die” by NHS and social services who missed repeated chances to save her, her family has alleged.</p><p>Laura Winham, 38, had schizophrenia, struggled to look after herself, and had become estranged from her family. She was found in a “mummified, almost skeletal state” at her social housing flat in Woking, Surrey, by police and relatives in May 2021.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/woman-lay-dead-in-surrey-flat-for-more-than-three-years-hearing-told">Continue reading...</a>

## ‘More like Annabel’s’: London law firm seeks to redress dress code
 - [https://www.theguardian.com/uk-news/2023/jan/26/more-like-annabels-london-law-firm-seeks-to-redress-dress-code](https://www.theguardian.com/uk-news/2023/jan/26/more-like-annabels-london-law-firm-seeks-to-redress-dress-code)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:33:17+00:00
 - user: None

<p>Vardags advises staff to be ‘wildly fabulous and express yourselves to the full’ with their office attire</p><ul><li><a href="https://www.theguardian.com/fashion/2023/jan/26/law-has-lagged-behind-trends-towards-casual-dressing-for-too-long">Law has lagged behind trends towards casual dressing for too long</a></li></ul><p>An electric blue sequined jacket and gold leather trousers topped with a funky pink hairdo might be a fashion connoisseur’s outfit of choice for a glitzy night on the town. At the legal firm Vardags, however, it is seen as appropriate office attire.</p><p>The divorce and family law firm suggested to its 120 staff they could shun the cuff links and business suits associated with “bankers and estate agents” and wear these items instead.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/more-like-annabels-london-law-firm-seeks-to-redress-dress-code">Continue reading...</a>

## Hunt to promote low-tax and private sector ‘re-tooling’ of industry
 - [https://www.theguardian.com/politics/2023/jan/26/hunt-chancellor-promote-low-tax-private-sector-re-tooling-industry](https://www.theguardian.com/politics/2023/jan/26/hunt-chancellor-promote-low-tax-private-sector-re-tooling-industry)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:32:12+00:00
 - user: None

<p>Chancellor also expected to tell markets that government spending will remain within strict limits</p><ul><li><a href="https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest">UK politics live – latest news updates</a></li></ul><p>Jeremy Hunt will defend the government’s vision for Britain’s <a href="https://www.theguardian.com/business/economicgrowth">economic future</a>, in a speech to City executives in London on Friday when he will lay out plans for investment and growth.</p><p>The UK chancellor will say that he wants to promote policies that allow the private sector to re-tool the UK’s industrial base and re-skill the workforce to generate strong growth over the next decade.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/hunt-chancellor-promote-low-tax-private-sector-re-tooling-industry">Continue reading...</a>

## Ben Jennings on Suella Braverman’s approach to immigration — cartoon
 - [https://www.theguardian.com/commentisfree/picture/2023/jan/26/ben-jennings-on-suella-bravermans-approach-to-immigration-cartoon](https://www.theguardian.com/commentisfree/picture/2023/jan/26/ben-jennings-on-suella-bravermans-approach-to-immigration-cartoon)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:27:06+00:00
 - user: None

<a href="https://www.theguardian.com/commentisfree/picture/2023/jan/26/ben-jennings-on-suella-bravermans-approach-to-immigration-cartoon">Continue reading...</a>

## Department of Health wasted £15bn on unused Covid supplies, watchdog finds
 - [https://www.theguardian.com/society/2023/jan/26/department-of-health-wasted-15bn-on-unused-covid-supplies-watchdog-finds](https://www.theguardian.com/society/2023/jan/26/department-of-health-wasted-15bn-on-unused-covid-supplies-watchdog-finds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:25:14+00:00
 - user: None

<p>National Audit Office finds ‘extraordinary waste’ along with failures of governance, oversight and financial controls</p><p>The Department of Health has wasted a total of £15bn on unused personal protective equipment, Covid tests and vaccines, prompting heavy criticism from the Whitehall spending watchdog.</p><p>The department spent £8.9bn during 2020/21 and another £6bn last year on such supplies, including masks and gowns for NHS staff that have proved unuseable and are now being burned.</p> <a href="https://www.theguardian.com/society/2023/jan/26/department-of-health-wasted-15bn-on-unused-covid-supplies-watchdog-finds">Continue reading...</a>

## Human activity and drought ‘degrading more than a third of Amazon rainforest’
 - [https://www.theguardian.com/environment/2023/jan/26/human-activity-and-drought-degrading-more-than-a-third-of-amazon-rainforest](https://www.theguardian.com/environment/2023/jan/26/human-activity-and-drought-degrading-more-than-a-third-of-amazon-rainforest)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:24:23+00:00
 - user: None

<p>Fires, land conversion, logging and water shortages have weakened resilience of 2.5m sq km of forest, says study</p><p>Human activity and drought may have degraded more than a third of the Amazon rainforest, double the previous estimate, according to a study that heightens concerns that the globally important ecosystem is slipping towards a point of no return.</p><p>Fires, land conversion, logging and water shortages, have weakened the resilience of up to 2.5m sq km of the forest, an area 10 times the size of the UK. This area is now drier, more flammable and more vulnerable than before, prompting the authors to warn of “megafires” in the future.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/human-activity-and-drought-degrading-more-than-a-third-of-amazon-rainforest">Continue reading...</a>

## US National Archives asks ex-presidents to check for classified papers
 - [https://www.theguardian.com/us-news/2023/jan/26/national-archives-classified-documents-obama-bush-clinton-cheney-gore](https://www.theguardian.com/us-news/2023/jan/26/national-archives-classified-documents-obama-bush-clinton-cheney-gore)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:23:55+00:00
 - user: None

<p>Ex-presidents and vice-presidents including Obama, Bush, Cheney and Gore receive letters on reviewing their personal records</p><p>The US National Archives has asked representatives for former presidents and vice-presidents on Thursday to review their personal records for any classified-marked documents in their possession <a href="https://www.theguardian.com/us-news/2023/jan/24/mike-pence-classified-documents-discovered-home-indiana">after a series of such discoveries</a> at the homes of Joe Biden, Donald Trump and Mike Pence.</p><p>The archives sent letters to the presidents and vice-presidents in the previous six administrations that are covered under the Presidential Records Act, which requires materials from their time in the White House to be turned over to the agency when they leave office.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/national-archives-classified-documents-obama-bush-clinton-cheney-gore">Continue reading...</a>

## UK far-right teenager inspired US gay nightclub shooting suspect, judge told
 - [https://www.theguardian.com/uk-news/2023/jan/26/uk-far-right-teenager-inspired-us-gay-nightclub-shooting-suspect-judge-told](https://www.theguardian.com/uk-news/2023/jan/26/uk-far-right-teenager-inspired-us-gay-nightclub-shooting-suspect-judge-told)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:13:59+00:00
 - user: None

<p>Daniel Harris faces jail after being convicted of publishing terrorist material from his grandfather’s house in Glossop</p><p>A teenage extremist from Derbyshire inspired the suspect accused of killing five people and wounding 17 others in a mass shooting at a gay nightclub in the US, a judge has been told.</p><p>Daniel Harris, 19, is facing jail after being convicted of publishing far-right terrorist material from his grandfather’s spare bedroom in Glossop.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/uk-far-right-teenager-inspired-us-gay-nightclub-shooting-suspect-judge-told">Continue reading...</a>

## Rebel Haiti police rampage through capital to protest cop killings by gangs
 - [https://www.theguardian.com/world/2023/jan/26/haiti-rebel-police-rampage-gang-killings-protest](https://www.theguardian.com/world/2023/jan/26/haiti-rebel-police-rampage-gang-killings-protest)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:11:53+00:00
 - user: None

<p>At least 10 officers killed in past week amid escalating violence and political chaos in the Caribbean nation</p><ul><li><a href="https://www.theguardian.com/world/2023/jan/12/haiti-crisis-jovenel-moise-gangs-water-way-out">Explainer: How did the Haiti crisis get so bad?</a></li></ul><p>Disgruntled rebel police officers have rampaged through the streets of Haiti’s capital of Port-au-Prince, blocking roads and shooting guns into the air to protest a slew of <a href="https://apnews.com/article/crime-caribbean-haiti-port-au-prince-e32e5a1ea6e7d07a56a51f41d63f53bc">killings of police officers by Haitian gangs</a>.</p><p>Gangs have killed at least 10 officers in the past week; another is missing and one more has severe bullet wounds, according to the Haitian national police.</p> <a href="https://www.theguardian.com/world/2023/jan/26/haiti-rebel-police-rampage-gang-killings-protest">Continue reading...</a>

## Science journals ban listing of ChatGPT as co-author on papers
 - [https://www.theguardian.com/science/2023/jan/26/science-journals-ban-listing-of-chatgpt-as-co-author-on-papers](https://www.theguardian.com/science/2023/jan/26/science-journals-ban-listing-of-chatgpt-as-co-author-on-papers)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:00:29+00:00
 - user: None

<p>Some publishers also banning use of bot in preparation of submissions but others see its adoption as inevitable</p><p>The publishers of thousands of scientific journals have banned or restricted contributors’ use of an advanced AI-driven chatbot amid concerns that it could pepper academic literature with flawed and even fabricated research.</p><p>ChatGPT, a <a href="https://www.theguardian.com/commentisfree/2023/jan/07/chatgpt-bot-excel-ai-chatbot-tech">fluent but flaky chatbot</a> developed by OpenAI in California, has impressed or distressed more than a million human users by rattling out poems, short stories, essays and even personal advice since its launch in November.</p> <a href="https://www.theguardian.com/science/2023/jan/26/science-journals-ban-listing-of-chatgpt-as-co-author-on-papers">Continue reading...</a>

## UK sugar tax ‘prevents 5,000 cases of obesity in year 6 girls annually’
 - [https://www.theguardian.com/society/2023/jan/26/uk-sugar-tax-prevents-5000-cases-of-obesity-in-year-6-girls-annually](https://www.theguardian.com/society/2023/jan/26/uk-sugar-tax-prevents-5000-cases-of-obesity-in-year-6-girls-annually)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 19:00:29+00:00
 - user: None

<p>Reduction in obesity greatest among girls in deprived areas, study says, but no effect was found in year 6 boys </p><p>The tax on sugary drinks may have prevented more than 5,000 cases of obesity every year among girls in their final year of primary school, research suggests.</p><p>Experts led by the University of Cambridge analysed the impact of the sugar tax, <a href="https://www.theguardian.com/society/2018/apr/04/sin-tax-sugar-alcohol-tobacco-to-help-the-poor">which came into force in 2018</a> as part of plans to tackle childhood obesity.</p> <a href="https://www.theguardian.com/society/2023/jan/26/uk-sugar-tax-prevents-5000-cases-of-obesity-in-year-6-girls-annually">Continue reading...</a>

## Nadhim Zahawi faces questions over source of £30m unsecured loans to wife’s property company
 - [https://www.theguardian.com/uk-news/2023/jan/26/nadhim-zahawi-faces-questions-over-source-of-30m-unsecured-loans-to-wifes-property-company](https://www.theguardian.com/uk-news/2023/jan/26/nadhim-zahawi-faces-questions-over-source-of-30m-unsecured-loans-to-wifes-property-company)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:59:13+00:00
 - user: None

<p>Tory party chair urged to explain how he has managed his family’s fortune, after controversy over his tax affairs</p><p>Nadhim Zahawi, the beleaguered former chancellor and current chair of the Conservative party, is under pressure to reveal the source of about £30m of unsecured loans made to his wife’s UK property company.</p><p>The loans were used to finance parts of a large UK property portfolio, reported last year as worth about £100m, and were declared in company accounts which span a period from 2017 to 2021 but give no information about who the lenders are.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/nadhim-zahawi-faces-questions-over-source-of-30m-unsecured-loans-to-wifes-property-company">Continue reading...</a>

## The Guardian view on civil service chiefs: be champions not courtiers | Editorial
 - [https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-civil-service-chiefs-be-champions-not-courtiers](https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-civil-service-chiefs-be-champions-not-courtiers)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:58:14+00:00
 - user: None

<p>Better government does not merely require new political leadership. It needs a new approach at the top of Whitehall too</p><p>Good government requires ministers and civil servants to pull together. To pull together there must be trust. Trust requires both sides to respect the rules that cover the relationship. Ministers are elected politicians. Civil servants are career government officials. They have different responsibilities but shared goals. Many codes cover the way they should behave.</p><p>So far, so traditional. But these are not traditional times. The economy is on the rack after Brexit, Covid and the Ukraine war. The past year has seen extreme turmoil in government, with three prime ministers and multiple reshuffles. Relations between ministers and civil servants have been strained for a range of reasons. Nadhim Zahawi’s tax affairs and allegations of bullying against <a href="https://www.theguardian.com/politics/2023/jan/25/dominic-raab-much-broader-inquiry-civil-servants-complaints">Dominic Raab</a> are two of the most recent.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-civil-service-chiefs-be-champions-not-courtiers">Continue reading...</a>

## Gareth Southgate reveals family persuaded him to stay as England manager
 - [https://www.theguardian.com/football/2023/jan/26/gareth-southgate-family-persuaded-him-to-stay-england-manager](https://www.theguardian.com/football/2023/jan/26/gareth-southgate-family-persuaded-him-to-stay-england-manager)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:55:47+00:00
 - user: None

<ul><li>Defeat in Qatar prompted thoughts of stepping down</li><li>‘I’m in a job with the chance to make some history’</li></ul><p>Gareth Southgate has admitted he considered his England future before and after the World Cup, but his family spurred him on. A desperate day in June 2022 – where a timid England slumped to <a href="https://www.theguardian.com/football/2022/jun/14/england-hungary-nations-league-match-report">a 4-0 defeat to Hungary</a> in the Nations League – left Southgate wondering whether he was the right man for the job as the boos rang around Molineux.</p><p>However, after talking with his family, the 52-year-old led England to an impressive World Cup campaign, when they departed after <a href="https://www.theguardian.com/football/2022/dec/10/england-france-world-cup-quarter-final-match-report">a 2-1 defeat to France</a> in the quarter-finals.</p> <a href="https://www.theguardian.com/football/2023/jan/26/gareth-southgate-family-persuaded-him-to-stay-england-manager">Continue reading...</a>

## The Guardian view on carbon offsetting: a model with dangerous flaws | Editorial
 - [https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-carbon-offsetting-a-model-with-dangerous-flaws](https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-carbon-offsetting-a-model-with-dangerous-flaws)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:53:47+00:00
 - user: None

<p>Protecting nature requires financial incentives. Serious problems uncovered in carbon markets must be fixed</p><p>The strong reaction to the Guardian’s joint <a href="https://www.theguardian.com/environment/2023/jan/18/revealed-forest-carbon-offsets-biggest-provider-worthless-verra-aoe">investigation into carbon offsetting</a> shows how much is at stake when the effectiveness of market mechanisms in combating global heating is challenged. Already, in Australia, politicians and scientists have <a href="https://www.theguardian.com/environment/2023/jan/24/australia-councils-sydney-melbourne-brisbane-buy-overseas-emissions-offsets">renewed their criticism</a> of public entities using international carbon credit schemes to offset local emissions. Verra, the Washington-based non-profit at the centre of the story, is the world’s leading carbon standard, certifying the credits that companies use to make claims about their environmental impact. It is a blow to anyone committed to the idea that emissions trading can help the world to reach net zero, to learn that 90% of the rainforest credits analysed are unlikely to represent genuine carbon reductions.</p><p>The problem, which was <a href="https://www.theguardian.com/news/audio/2023/jan/23/exposing-rainforest-carbon-credits-why-offsetting-isnt-working">uncovered by journalists</a> working alongside experts using satellite images, is the methodology used by Verra to certify its credits. While Verra disputes the findings, and is due to publish its own assessment, the researchers found that the evidence used to calculate offsets was flawed. Predictions of what would have happened in the absence of credits were unreliable, and benefits were overstated.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/the-guardian-view-on-carbon-offsetting-a-model-with-dangerous-flaws">Continue reading...</a>

## Former MP Jared O’Mara owed thousands to drug dealer, court hears
 - [https://www.theguardian.com/uk-news/2023/jan/26/former-mp-jared-omara-debt-drug-dealer-court-hears](https://www.theguardian.com/uk-news/2023/jan/26/former-mp-jared-omara-debt-drug-dealer-court-hears)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:42:20+00:00
 - user: None

<p>Former Labour MP for Sheffield Hallam accused of making fraudulent expenses claims of nearly £30,000</p><p>A former Labour MP accused of expenses fraud was thousands of pounds in debt to a drug dealer and regularly took up to five grams of cocaine a day, a court has heard.</p><p>Jared O’Mara also once drank a litre of vodka before a television interview with BBC Look North and believed “a shadowy government cabal” was out to get him, his former chief of staff Gareth Arnold said in messages and police interviews read to jurors at Leeds crown court.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/former-mp-jared-omara-debt-drug-dealer-court-hears">Continue reading...</a>

## How much of Morrisons’ weak financial result was self-inflicted? | Nils Pratley
 - [https://www.theguardian.com/business/nils-pratley-on-finance/2023/jan/26/how-much-of-morrisons-weak-financial-result-was-self-inflicted](https://www.theguardian.com/business/nils-pratley-on-finance/2023/jan/26/how-much-of-morrisons-weak-financial-result-was-self-inflicted)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:37:08+00:00
 - user: None

<p>The grocer’s buyout by a US private equity firm in late 2021 was spectacularly badly timed</p><p>It was a year of transition, said David Potts, chief executive of Morrisons, referring to <a href="https://www.theguardian.com/business/2021/oct/19/morrisons-shareholders-wave-through-7bn-takeover">the grocer’s £7bn takeover by the US private equity firm Clayton Dubilier &amp; Rice (CD&amp;R)</a> in late 2021. He could equally have meant the other significant change: Morrisons transitioned from fourth largest supermarket chain in the UK before the buyout barons took control, to fifth.</p><p>One can see in <a href="https://www.theguardian.com/business/2023/jan/26/morrisons-sales-profits-dive-2022-price-rises-shoppers-pessimistic-cost-of-living-political-uncertainty">Thursday’s numbers</a> how it happened. Aldi, the operator on the rise, opened a few stores but the critical contributor was the mighty 4.2% fall in Morrisons’ like-for-like sales last year. That was in a period in which virtually everybody else has been firmly in positive territory thanks to inflationary breezes.</p> <a href="https://www.theguardian.com/business/nils-pratley-on-finance/2023/jan/26/how-much-of-morrisons-weak-financial-result-was-self-inflicted">Continue reading...</a>

## Tyre Nichols: five ex-Memphis police officers face murder charges over motorist’s death
 - [https://www.theguardian.com/us-news/2023/jan/26/tyre-nichols-five-ex-police-officers-custody](https://www.theguardian.com/us-news/2023/jan/26/tyre-nichols-five-ex-police-officers-custody)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:32:55+00:00
 - user: None

<p>Nichols, 29, died three days after a January traffic stop in Tennessee led to a brutal beating</p><p>Five former police officers are in custody and each facing a murder charge in connection with the death of <a href="https://www.theguardian.com/us-news/2023/jan/26/tyre-nichols-death-memphis-police-killing">Tyre Nichols</a>, a Black motorist in Memphis, Tennessee, who died three days after a 7 January traffic stop spiraled into a fatal physical attack by the men, local media reported.</p><p>Shelby county sheriff’s office online records show that Tadarrius Bean, Demetrius Haley, Desmond Mills Jr, Emmitt Martin III and Justin Smith were in custody. All five are charged with second-degree murder, aggravated assault, aggravated kidnapping, official misconduct and official oppression.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/tyre-nichols-five-ex-police-officers-custody">Continue reading...</a>

## Boris Johnson may get more taxpayers’ money for Partygate defence
 - [https://www.theguardian.com/politics/2023/jan/26/boris-johnson-may-get-more-taxpayers-money-for-partygate-defence](https://www.theguardian.com/politics/2023/jan/26/boris-johnson-may-get-more-taxpayers-money-for-partygate-defence)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:23:27+00:00
 - user: None

<p>Senior civil servant admits budget of £220,000 for ex-PM to defend claims he misled parliament could rise</p><p>Boris Johnson could get more taxpayers’ money to cover extra legal support as the inquiry into his Partygate denials drags on, it has emerged.</p><p>The cost of helping the former prime minister defend himself over claims he misled parliament about law-breaking parties during Covid “could potentially exceed” the current £222,000 budget, a senior civil servant admitted.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/boris-johnson-may-get-more-taxpayers-money-for-partygate-defence">Continue reading...</a>

## Bielsa arrives in England as Moshiri tries to convince him to take Everton job
 - [https://www.theguardian.com/football/2023/jan/26/marcelo-bielsa-arrives-england-everton-farhad-moshiri-manager](https://www.theguardian.com/football/2023/jan/26/marcelo-bielsa-arrives-england-everton-farhad-moshiri-manager)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:19:52+00:00
 - user: None

<ul><li>Owner will attempt to remove former Leeds manager’s doubts</li><li>Everton want to keep midfielder Onana amid Chelsea interest</li></ul><p>Marcelo Bielsa has been pictured arriving at Heathrow as Everton’s owner, Farhad Moshiri, continues attempts to persuade the former Leeds manager to succeed Frank Lampard.</p><p>Bielsa is Moshiri’s first choice but has doubts over whether to accept the challenge. He is believed to have reservations over a club that has sacked six permanent managers in just under seven years and the suitability of the squad to his methods, particularly when a relegation battle leaves little room for error or time to bed in his tactics.</p> <a href="https://www.theguardian.com/football/2023/jan/26/marcelo-bielsa-arrives-england-everton-farhad-moshiri-manager">Continue reading...</a>

## Russia outlaws Meduza in attempt to stamp out independent news
 - [https://www.theguardian.com/media/2023/jan/26/russia-outlaws-meduza-in-attempt-to-stamp-out-independent-news](https://www.theguardian.com/media/2023/jan/26/russia-outlaws-meduza-in-attempt-to-stamp-out-independent-news)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:17:15+00:00
 - user: None

<p>Outlet declared ‘undesirable’, with journalists, sources and donors facing threat of prosecution</p><p>Russia has declared the news outlet Meduza an “undesirable organisation”, in effect outlawing one of the country’s best-known sources of independent reporting on the Kremlin and war in Ukraine.</p><p>Meduza, <a href="https://www.theguardian.com/world/2014/oct/23/russian-journalists-meduza-project-latvia-kremlin-crackdown">founded by Russian journalists in Riga, Latvia, in 2014</a>, was declared an undesirable organisation by the general prosecutor’s office on Thursday for “posing a threat to the foundations of the Russian Federation’s constitutional order and national security”.</p> <a href="https://www.theguardian.com/media/2023/jan/26/russia-outlaws-meduza-in-attempt-to-stamp-out-independent-news">Continue reading...</a>

## Eva Green portrayed as ‘diva’ to shift blame for film collapse, high court hears
 - [https://www.theguardian.com/uk-news/2023/jan/26/eva-green-high-court-case-patriot-film](https://www.theguardian.com/uk-news/2023/jan/26/eva-green-high-court-case-patriot-film)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:15:49+00:00
 - user: None

<p>Actor is suing White Lantern Films and SMC Speciality finance for fee for A Patriot but two firms are countersuing</p><p>The Hollywood actor <a href="https://www.theguardian.com/culture/eva-green">Eva Green</a> has been unfairly portrayed as a “diva” by producers and financiers in an attempt to shift blame for the collapse of a sci-fi film in which she was supposed to star, the high court has heard.</p><p>The former Bond Girl is suing White Lantern Films and SMC Speciality finance for her $1m (£807,000) fee for A Patriot but the two companies are countersuing, alleging that Green pulled out of and breached her contract.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/eva-green-high-court-case-patriot-film">Continue reading...</a>

## Zara Aleena was failed by a privatised probation service | Letters
 - [https://www.theguardian.com/uk-news/2023/jan/26/zara-aleena-was-failed-by-a-privatised-probation-service](https://www.theguardian.com/uk-news/2023/jan/26/zara-aleena-was-failed-by-a-privatised-probation-service)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:11:46+00:00
 - user: None

<p><strong>Sue Hobbs</strong> outlines the inaccurate risk assessments of the young woman’s murderer, while <strong>Sarah Compton</strong> says nothing has changed since the murder of her brother in 2015</p><p>Your article (<a href="https://www.theguardian.com/society/2023/jan/24/probation-service-ministers-blood-hands-zara-aleena-family-inspector-report">Probation service and ministers have ‘blood on hands’, say Zara Aleena’s family, 24 January</a>) identifies the undeniable case work failures by the National Probation Service (NPS) that led to the appalling murder of Zara Aleena. But what it overlooks is the impact of the privatisation of the probation service. In 2014, it was split in two, with private “community rehabilitation companies” supervising low- to medium-risk cases, and the pre-existing NPS supervising high-risk cases.</p><p>As HM Inspectorate of Probation’s independent serious further offence review of Jordan McSweeney spells out, in 2021 McSweeney was the responsibility of the profit-driven London Community Rehabilitation Company. Despite McSweeney’s known risk being present in custody, such as his possession of weapons and threatening behaviour, as well as subsequent information received about the serious risk he posed to women, the company assessed him to be medium-risk.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/zara-aleena-was-failed-by-a-privatised-probation-service">Continue reading...</a>

## It will take more than wealth taxes to tackle this gross inequality | Letters
 - [https://www.theguardian.com/money/2023/jan/26/it-will-take-more-than-wealth-taxes-to-tackle-this-gross-inequality](https://www.theguardian.com/money/2023/jan/26/it-will-take-more-than-wealth-taxes-to-tackle-this-gross-inequality)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:11:25+00:00
 - user: None

<p><strong>Martin Lyster </strong>suggests dismantling the mechanisms that concentrate wealth, while <strong>Naomi Roberts </strong>calls for taxes to include the modestly rich</p><p>Your <a href="https://www.theguardian.com/commentisfree/2023/jan/16/the-guardian-view-on-wealth-taxes-uk-needs-one-on-millionaires-and-billionaires">editorial</a> (16 January) calls for wealth taxes to address extreme inequality, but this is just a sticking plaster. We must dismantle the mechanisms that concentrate wealth in the first place. Your editorial <a href="https://www.theguardian.com/commentisfree/2023/jan/12/the-guardian-view-on-a-property-owning-democracy-tory-dream-becomes-a-nightmare">three days earlier</a> correctly identified the extractive model of housing as one of the most powerful of these, but there are many, including private monopolies of essentials; insecure employment on poverty wages; bailouts for the rich and austerity for the rest.</p><p>The amassing of vast fortunes by a few while millions cannot afford the basics is not the natural outcome of market forces in a meritocracy, but a deliberate political choice. A wealth tax, on its own, would allow the heist to continue, while taking a small rake-off, like a bent cop. We should turn off the wealth pumps. A flatter distribution will result. Progressive taxation can help, but cannot do the job alone.<br /><strong>Martin Lyster</strong><br /><em>Oxford</em></p> <a href="https://www.theguardian.com/money/2023/jan/26/it-will-take-more-than-wealth-taxes-to-tackle-this-gross-inequality">Continue reading...</a>

## Large rise in men referred to Prevent over women-hating incel ideology
 - [https://www.theguardian.com/uk-news/2023/jan/26/large-rise-in-men-referred-to-prevent-over-women-hating-incel-ideology](https://www.theguardian.com/uk-news/2023/jan/26/large-rise-in-men-referred-to-prevent-over-women-hating-incel-ideology)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:08:51+00:00
 - user: None

<p>Counter-terror officers say incel makes up 1% of referral to anti-extremism scheme</p><p>There has been a large rise in the number of young men referred to the government’s Prevent scheme over the women-hating ‘incel’ ideology, official statistics have shown.</p><p>A senior counter-terrorism officer described incel as an “emerging risk” making up 1% of all referrals to the anti-extremism scheme in the year to March 2022 – 77 cases – triggered by concerns that mainly young men were falling for its message.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/large-rise-in-men-referred-to-prevent-over-women-hating-incel-ideology">Continue reading...</a>

## Steve Borthwick bringing ‘real clarity’ to England’s style, reveals Lewis Ludlam
 - [https://www.theguardian.com/sport/2023/jan/26/steve-borthwick-bringing-real-clarity-to-englands-style-reveals-lewis-ludlam](https://www.theguardian.com/sport/2023/jan/26/steve-borthwick-bringing-real-clarity-to-englands-style-reveals-lewis-ludlam)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:00:28+00:00
 - user: None

<ul><li>Ludlam: new coach has re-established ‘emotional connection’</li><li>Borthwick preparing for Calcutta Cup clash against Scotland</li></ul><p>No bouncy castles, no paddleboarding and, mercifully, not a judo mat in sight. As yet no reports of Steve Borthwick throwing anybody a packet of sweets, handing out a crate of beer or promising a prime cut of beef then sending sausages because “you’re not ready for steak yet”. Indeed, searching England’s Bagshot hotel for tangible signs <a href="https://www.theguardian.com/sport/2022/dec/23/in-borthwick-has-the-rfu-found-englands-gareth-southgate-or-its-steve-mcclaren">the Borthwick era</a> is up and running was proving a thankless task until the penny dropped: it was their very absence that revealed so much more.</p><p>This week England were due to be at a warm-weather training camp in Portugal. In the last year they have been to Brighton and Jersey, even Thorpe Park, performing numerous exercises designed to build social capital. This is not to belittle Eddie Jones’s methods – history shows that they were incredibly popular and mightily effective in his first few years as head coach – but it will come as little surprise to hear that it is not Borthwick’s style.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/steve-borthwick-bringing-real-clarity-to-englands-style-reveals-lewis-ludlam">Continue reading...</a>

## Resilient Tsitsipas ready to take major step forward at Australian Open
 - [https://www.theguardian.com/sport/2023/jan/26/resilient-stefanos-tsitsipas-ready-to-take-major-step-forward-at-australian-open](https://www.theguardian.com/sport/2023/jan/26/resilient-stefanos-tsitsipas-ready-to-take-major-step-forward-at-australian-open)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 18:00:27+00:00
 - user: None

<p>The 24-year-old is now reaching his physical peak, but it’s his mental strength that gives him a chance to reach the final</p><p>As Stefanos Tsitsipas was dragged <a href="https://www.theguardian.com/sport/2023/jan/22/tsitsipas-into-last-eight-of-australian-open-despite-sinners-best-efforts">unwillingly to a fifth set</a> after leading Jannik Sinner in his fourth-round match at the Australian Open, the signs were concerning. Every service game was a painful fight, with Tsitsipas facing 18 break points in the third and fourth sets alone, and the final set began with his opponent in control. Sinner prowled on top of the baseline, dictating play and prepared to shut him out.</p><p>But under immense pressure Tsitsipas thrived. He hustled out an early break against the run of play, taking advantage of Sinner’s nerves, and as the momentum shifted he refused to let go. His serve was supreme for the rest of the set, he didn’t face the break point and somehow he survived.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/resilient-stefanos-tsitsipas-ready-to-take-major-step-forward-at-australian-open">Continue reading...</a>

## Pantera shows cancelled after frontman’s Nazi salute prompts fan backlash
 - [https://www.theguardian.com/music/2023/jan/26/pantera-shows-cancelled-after-frontmans-nazi-salute-prompts-fan-backlash](https://www.theguardian.com/music/2023/jan/26/pantera-shows-cancelled-after-frontmans-nazi-salute-prompts-fan-backlash)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:51:23+00:00
 - user: None

<p>Phil Anselmo’s 2016 salute and shout of ‘white power’ have come back to haunt him as German and Austrian venues refuse to host the metal band</p><p>Three shows of Pantera’s forthcoming reunion tour have been cancelled this week, seemingly due to a 2016 incident in which frontman Phil Anselmo made a Nazi salute and yelled “white power” at a concert.</p><p>As Consequence <a href="https://consequence.net/2023/01/pantera-removed-german-festivals/">reports</a>, the revered Texas metal band, who have not toured in more than 20 years, were dropped from the lineups of Germany’s Rock am Ring and Rock im Park festivals earlier this week. The promoter of the festivals cited public backlash to Pantera’s booking as the reason for dropping the band, saying the decision was made due to “intensive conversations with artists, our partners and you, the festival fans”.</p> <a href="https://www.theguardian.com/music/2023/jan/26/pantera-shows-cancelled-after-frontmans-nazi-salute-prompts-fan-backlash">Continue reading...</a>

## Braverman, Raab, Zahawi: who’s next in Rish!’s Tory circus of inaction? | John Crace
 - [https://www.theguardian.com/politics/2023/jan/26/braverman-raab-zahawi-who-next-rishi-sunak-tory-circus-inaction](https://www.theguardian.com/politics/2023/jan/26/braverman-raab-zahawi-who-next-rishi-sunak-tory-circus-inaction)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:37:53+00:00
 - user: None

<p>Motionless in terror, the PM waits for the onslaught to dematerialise, for crises to pass of their own accord</p><p>Here’s a thought. Rishi Sunak does not appear to be possessed of an inquisitive mind. An unusual quality in a prime minister. Rather he seems almost inert. To the point of being comatose. He worries a bit about the economy, the health service, the cost of living crisis, the strikes. But he never really seems to do anything effective about them.</p><p>Rish! stares motionless in terror, like a rabbit caught in headlights. Waiting for the onslaught to somehow dematerialise. For the crises to pass of their own accord. It’s as if he is the embodiment of the Tory government that after 13 years has finally admitted defeat. He knows the game is up. Anything he does will be wrong, so best to do nothing at all. Just let the world unravel.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/braverman-raab-zahawi-who-next-rishi-sunak-tory-circus-inaction">Continue reading...</a>

## Why Scotland’s gender reform bill is sparking anxiety over trans prisoner policies
 - [https://www.theguardian.com/society/2023/jan/26/trans-prisoners-in-scotland-case-by-case](https://www.theguardian.com/society/2023/jan/26/trans-prisoners-in-scotland-case-by-case)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:37:05+00:00
 - user: None

<p>Analysts warn of legal challenges if bill makes inmates’ access to gender recognition certificates easier – though jail allocation is decided case by case</p><p>The outcry over the placement of the convicted double rapist and transgender woman Isla Bryson in a women’s prison is set against anxieties about Scottish Prison Service policy on trans prisoners and how Scotland’s gender recognition reforms could affect that. </p><p>In 2014, the Scottish Prison Service (SPS) introduced its gender identity and gender reassignment policy, which it developed with the Scottish Trans Alliance. It advises that – where an individual is permanently living in a gender other than that assigned at birth – “establishment allocation should usually be the new gender in which they are living”.</p> <a href="https://www.theguardian.com/society/2023/jan/26/trans-prisoners-in-scotland-case-by-case">Continue reading...</a>

## Sam Smith: Gloria review | Alexis Petridis's album of the week
 - [https://www.theguardian.com/music/2023/jan/26/sam-smith-gloria-review-emi-fourth-album](https://www.theguardian.com/music/2023/jan/26/sam-smith-gloria-review-emi-fourth-album)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:33:53+00:00
 - user: None

<p><strong>(EMI)<br /></strong>With hints of R&amp;B, trap and disco, Smith’s fourth album tiptoes away from their trademark piano-led ballads – but isn’t the ‘edgy’ departure they think it is</p><p>A mainstream artist making noises about their forthcoming release being “the album I always wanted to make” is the kind of thing that makes record companies nervous. It comes with the implicit suggestion that the music that made them famous wasn’t quite the ticket, and the sense that the fans who loved said music might be in for a shock. But when that artist is Sam Smith – who has said just that about their fourth album, Gloria, bolstered by a press release talking up the album’s “edgy, experimental” nature – it’s worth remembering that we’ve been here before. Smith couched Gloria’s predecessor in similar terms: their third album <a href="https://www.theguardian.com/music/2020/oct/29/sam-smith-love-goes-review">Love Goes</a> was supposedly “experimental”, and “allowed me to be whoever I wanted to be in the studio that day” etc. As it turned out, it was about as experimental as a packet of digestive biscuits, unless said experiment involved amping up the singer’s trademark romantic misery even further than before. The sense that Smith might not be the best judge of their own work, at least when it comes to its ability to spring surprises, thus took shape.</p><p>Still, the chart-topping collaboration with Kim Petras that preceded Gloria’s release represented a departure for Smith and a historical milestone for Petras – Unholy was the first time a trans or non-binary artist had topped the Billboard Hot 100 – even if its sound wasn’t particularly novel; you can detect trap, the gothic atmospherics of <a href="https://www.theguardian.com/music/billie-eilish">Billie Eilish</a> circa 2019 and <a href="https://www.theguardian.com/music/2018/mar/14/sophie-review-heaven-london">Sophie</a>’s hyperpop production style in its DNA. The story of a straight married father secretly “getting hot” at a gay club called the Body Shop, it featured a dramatic choral hook and a stark electronic sound – as did its minimal, dancehall-influenced follow-up Gimme.</p> <a href="https://www.theguardian.com/music/2023/jan/26/sam-smith-gloria-review-emi-fourth-album">Continue reading...</a>

## South Africa’s desperation gives ODI series against England extra frisson
 - [https://www.theguardian.com/sport/2023/jan/26/south-africas-desperation-gives-odi-series-against-england-extra-frisson](https://www.theguardian.com/sport/2023/jan/26/south-africas-desperation-gives-odi-series-against-england-extra-frisson)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:26:04+00:00
 - user: None

<p>While Jos Buttler’s side focus on defending their World Cup title, the Proteas need to ensure they make it the tournament</p><p>England’s cricketers may be gearing up to defend <a href="https://www.theguardian.com/sport/2019/dec/23/jawdropping-moments-2019-england-win-cricket-world-cup">their 50-over World Cup title</a> in India in October but their opposition on Friday in the first of three ODIs have a more pressing matter at hand: just being at the tournament.</p><p>South Africa need to win this series and then beat the Netherlands in two Covid-postponed ODIs at the beginning of April to avoid the ignominy of taking part in a secondary, 10-team qualifying tournament in Harare in June involving Ireland, Scotland, Namibia, the Netherlands and the UAE, among others. One of Sri Lanka or West Indies will also be there. Progression to the main event is anything but guaranteed.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/south-africas-desperation-gives-odi-series-against-england-extra-frisson">Continue reading...</a>

## Shell puts 2,000 UK jobs at risk with review of Shell Energy retail division
 - [https://www.theguardian.com/business/2023/jan/26/shell-puts-2000-uk-jobs-at-risk-with-review-of-shell-energy-retail-division](https://www.theguardian.com/business/2023/jan/26/shell-puts-2000-uk-jobs-at-risk-with-review-of-shell-energy-retail-division)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:19:54+00:00
 - user: None

<p>Company weighing options including exit from domestic energy and broadband sectors in UK, Netherlands and Germany</p><p>Shell has put more than 2,000 jobs in the UK at risk after launching a “strategic review” of its domestic energy and telecoms supply division.</p><p>The oil and gas supermajor said on Thursday that it had told staff in Shell Energy, which has operations in the UK, the Netherlands and Germany, that it has begun analysis of future options for the business, which could include exiting the sectors.</p> <a href="https://www.theguardian.com/business/2023/jan/26/shell-puts-2000-uk-jobs-at-risk-with-review-of-shell-energy-retail-division">Continue reading...</a>

## Saddam Hussein mural painter creates a world of turmoil – Mohammed Sami review
 - [https://www.theguardian.com/artanddesign/2023/jan/26/saddam-hussein-mural-painter-turmoil-mohammed-sami-review](https://www.theguardian.com/artanddesign/2023/jan/26/saddam-hussein-mural-painter-turmoil-mohammed-sami-review)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:14:44+00:00
 - user: None

<p><strong>Camden Art Centre, London<br /></strong>Sami, a refugee from Iraq, learned his trade painting his country’s then leader. His disquieting works, full of tortured surfaces, feel like distillations of death and chaos</p><p>I thought I saw figures in black crossing the squares of the city and standing on its flat rooftops, the sort of figures painters casually sketch in to give a scene a sense of life and scale. But there was actually no one there, just black and white flecks floating down on the clusters of buildings under a dark sky. Ashfall, by Iraqi-born painter Mohammad Sami, is an unpeopled and silent aftermath.</p><p>Clogged, compressed, scraped down, sprayed, loosely brushed: the surfaces of Sami’s paintings have been through a lot. They evidence turmoil, however quiet the images they describe appear. This is deceptive. Sami’s paintings are filled with doubts and ambiguities. You can’t always be sure what you’re looking at and the paintings often say one thing, their titles another. A gilded, upholstered throne is called Electric Chair, and a huge painting of what appear to be piles of shirts (are they collars of military shirts?) is titled Study of Guts. In The Parliament Room, rows of unoccupied chairs recede into darkness. They look like headstones.</p> <a href="https://www.theguardian.com/artanddesign/2023/jan/26/saddam-hussein-mural-painter-turmoil-mohammed-sami-review">Continue reading...</a>

## Succession season 4: new trailer showcases more Roy family drama
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/succession-new-trailer-season-4-premiere-date-hbo](https://www.theguardian.com/tv-and-radio/2023/jan/26/succession-new-trailer-season-4-premiere-date-hbo)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 17:03:53+00:00
 - user: None

<p>The fourth season of the critically acclaimed HBO series about a tumultuous media conglomerate family will return on 26 March</p><p>The Roy family is back and seemingly as dysfunctional and cutthroat as ever. A <a href="https://www.youtube.com/watch?v=sWlURhM5P5Q">new teaser trailer</a> for <a href="https://www.theguardian.com/tv-and-radio/series/succession-episode-by-episode">Succession</a>, the popular show from British creator Jesse Armstrong, suggests the media conglomerate-owning, billionaire family’s travails and scathing power struggles will continue in the fourth season, which HBO announced will return in March.</p><p>The trailer finds the Roy siblings – futile presidential candidate Connor (Alan Ruck), former golden boy Kendall (Jeremy Strong), puerile Roman (Kieran Culkin) and scheming daughter Shiv (Sarah Snook) – in turmoil following their failed coup in the <a href="https://www.theguardian.com/tv-and-radio/2021/dec/13/succession-recap-series-three-finale-the-most-biblical-betrayal-of-all">third season finale</a> and their father’s proposed sale of the company to tech mogul Lukas Matsson (Alexander Skarsgård).</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/succession-new-trailer-season-4-premiere-date-hbo">Continue reading...</a>

## Ukrainian security service ‘needs cleanout’ after arrest of accused spy
 - [https://www.theguardian.com/world/2023/jan/26/ukrainian-security-service-needs-cleanout-after-arrest-of-accused-spy](https://www.theguardian.com/world/2023/jan/26/ukrainian-security-service-needs-cleanout-after-arrest-of-accused-spy)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:59:57+00:00
 - user: None

<p>Former security official Viktor Yahun says Ukraine’s SBU agency has long been overly close to Russia’s FSB</p><p><a href="https://www.theguardian.com/world/live/2023/jan/26/russia-ukraine-war-live-key-thing-now-is-speed-and-volume-says-zelenskiy-as-allies-commit-to-tanks">Russia-Ukraine war – latest news updates</a></p><p>The arrest of a high-ranking Ukrainian intelligence agent accused of spying for Russia has highlighted the urgent need for a cleanout of the country’s key security service, a former deputy head of the agency has said.</p><p>The Ukrainian security service (SBU) reported on Thursday that they arrested a lieutenant colonel in their ranks on suspicion of “high treason” and published a photograph of bundles of cash found in his home.</p> <a href="https://www.theguardian.com/world/2023/jan/26/ukrainian-security-service-needs-cleanout-after-arrest-of-accused-spy">Continue reading...</a>

## Boy, 13, drowned in Bedfordshire lake after jumping off rope swing, inquest hears
 - [https://www.theguardian.com/uk-news/2023/jan/26/boy-13-drowned-in-bedfordshire-lake-after-jumping-off-rope-swing-inquest-hears](https://www.theguardian.com/uk-news/2023/jan/26/boy-13-drowned-in-bedfordshire-lake-after-jumping-off-rope-swing-inquest-hears)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:56:08+00:00
 - user: None

<p>Kyron Hibbert, who couldn’t swim, died in Stewartby lake during last summer’s heatwave</p><p>A “happy, cheeky, funny, intelligent” 13-year-old boy drowned when he jumped from a rope swing over a lake during last summer’s heatwave, a coroner has heard.</p><p>Kyron Hibbert, who could not swim, disappeared under the water of Stewartby lake as his friends tried vainly to save him. His body was recovered early the following morning, the inquest heard on Thursday.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/boy-13-drowned-in-bedfordshire-lake-after-jumping-off-rope-swing-inquest-hears">Continue reading...</a>

## GP was not told Plymouth shooter had shotgun certificate, inquest hears
 - [https://www.theguardian.com/uk-news/2023/jan/26/gp-not-told-jake-davison-plymouth-shooter-shotgun-certificate-inquest-hears](https://www.theguardian.com/uk-news/2023/jan/26/gp-not-told-jake-davison-plymouth-shooter-shotgun-certificate-inquest-hears)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:36:56+00:00
 - user: None

<p>Dr Ben Dawson had declined to acknowledge Jake Davison’s suitability to own a weapon, inquest hears</p><p>Jake Davison’s GP was never told that his patient, who went on to kill five people, had been granted a shotgun certificate after the doctor declined to provide an opinion on his suitability to own a weapon, an inquest has heard.</p><p>Dr Ben Dawson said he refused because he was not qualified to comment on the “assessment of behavioural and personality disorders”.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/gp-not-told-jake-davison-plymouth-shooter-shotgun-certificate-inquest-hears">Continue reading...</a>

## Post your questions for Ben Whishaw
 - [https://www.theguardian.com/film/2023/jan/26/post-your-questions-for-ben-whishaw](https://www.theguardian.com/film/2023/jan/26/post-your-questions-for-ben-whishaw)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:36:49+00:00
 - user: None

<p>Whether you want to know about kitting out James Bond or sinking his claws into Paddington Bear, Britain’s most likable actor is here to tell all</p><p>You’ll probably know Ben Whishaw best for taking over from Desmond Llewelyn (and briefly John Cleese) as Q in the past three James Bond films. And as the voice of Paddington Bear, where he was brought in at the last minute to replace Colin Firth.</p><p>Whishaw brings something so very likable to every role he plays: John Keats in Jane Campion’s Bright Star, Sebastian Flyte in the 2008 version of Brideshead Revisited and the grown-up Michael Banks in Mary Poppins Returns. And that includes his TV work: Norman Scott in A Very English Scandal and junior doctor Adam Kay in This Is Going to Hurt.</p> <a href="https://www.theguardian.com/film/2023/jan/26/post-your-questions-for-ben-whishaw">Continue reading...</a>

## Andrew Bridgen to sue Matt Hancock over criticism of Covid vaccine remarks
 - [https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-criticism-of-covid-vaccine-remarks](https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-criticism-of-covid-vaccine-remarks)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:32:52+00:00
 - user: None

<p>MP who lost Tory whip after appearing to compare vaccines to Holocaust says he is suing Hancock for defamation</p><p>An independent MP who lost the Tory whip after appearing to compare Covid vaccines to the Holocaust is suing Matt Hancock for criticising his remarks.</p><p>Andrew Bridgen is suing the former health secretary for £100,000 over a tweet in which Hancock accused Bridgen of spouting “antisemitic, anti-vax, anti-scientific conspiracy theories” over the vaccine.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-criticism-of-covid-vaccine-remarks">Continue reading...</a>

## Andrew Bridgen to sue Matt Hancock over tweet calling him antisemitic
 - [https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-tweet-calling-him-antisemitic](https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-tweet-calling-him-antisemitic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:32:52+00:00
 - user: None

<p>MP who lost Tory whip after appearing to compare vaccines to Holocaust says he is suing Hancock for £100,000</p><p>An independent MP who lost the Tory whip after appearing to compare Covid vaccines to the Holocaust is suing Matt Hancock for criticising his remarks.</p><p>Andrew Bridgen is suing the former health secretary for £100,000 over a tweet in which Hancock accused Bridgen of spouting “antisemitic, anti-vax, anti-scientific conspiracy theories” over the vaccine.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/andrew-bridgen-to-sue-matt-hancock-over-tweet-calling-him-antisemitic">Continue reading...</a>

## When the bailiffs come a-knocking: new agency aims to tackle bad image
 - [https://www.theguardian.com/business/2023/jan/26/new-agency-aims-to-tackle-bad-image-bailiffs-enforcement-conduct-board](https://www.theguardian.com/business/2023/jan/26/new-agency-aims-to-tackle-bad-image-bailiffs-enforcement-conduct-board)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:32:38+00:00
 - user: None

<p>Head of Enforcement Conduct Board for England and Wales finds it extraordinary there has been no previous regulation</p><p>“It’s like that loan shark mentality of, there’s money due to us, we will get it at whatever means, and we don’t care – if that means you’re not able to feed yourself for the next one or two weeks, that’s not our problem.”</p><p>Ada, whose car was seized for non-payment of a parking fine, recounts a recent brush with bailiffs, in research carried out by the Enforcement Conduct Board (ECB) – a new agency, tasked with the job of raising standards in this controversial industry.</p> <a href="https://www.theguardian.com/business/2023/jan/26/new-agency-aims-to-tackle-bad-image-bailiffs-enforcement-conduct-board">Continue reading...</a>

## Morrisons reveals sales and profits dived in 2022 despite putting up prices
 - [https://www.theguardian.com/business/2023/jan/26/morrisons-sales-profits-dive-2022-price-rises-shoppers-pessimistic-cost-of-living-political-uncertainty](https://www.theguardian.com/business/2023/jan/26/morrisons-sales-profits-dive-2022-price-rises-shoppers-pessimistic-cost-of-living-political-uncertainty)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:29:20+00:00
 - user: None

<p>Slide blamed on shoppers’ increasing pessimism amid rising living costs and political uncertainty</p><p>Morrisons has revealed its sales and profits fell last year even as it put prices up, blaming the slide on shoppers becoming “increasingly pessimistic” amid the rising cost of living and political uncertainty.</p><p>The retailer, which <a href="https://www.theguardian.com/business/2022/sep/17/big-four-uk-grocers-aldi-morrisons-cost-of-living-crisis">lost its spot</a> at the UK’s fourth largest supermarket to Aldi last year, said underlying profits fell 15% to £828m in the year to 30 October, as sales at established stores decreased by 4.2%.</p> <a href="https://www.theguardian.com/business/2023/jan/26/morrisons-sales-profits-dive-2022-price-rises-shoppers-pessimistic-cost-of-living-political-uncertainty">Continue reading...</a>

## ‘Stringing us along’: Windrush U-turns let down those whose lives were ruined
 - [https://www.theguardian.com/uk-news/2023/jan/26/stringing-us-along-windrush-u-turns-disappoint-those-whose-lives-were-ruined](https://www.theguardian.com/uk-news/2023/jan/26/stringing-us-along-windrush-u-turns-disappoint-those-whose-lives-were-ruined)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:20:41+00:00
 - user: None

<p>Suella Braverman’s abandonment of key commitments is the latest in a series of blows to those seeking justice</p><p>Last year Anthony Williams decided to leave the UK after 53 years, 13 of which were spent as a soldier serving with the Royal Artillery. He said his decision to move was directly linked to the pain of being caught up in the Windrush scandal and his sense of disappointment that government promises to make amends were being quietly abandoned.</p><p>“I just didn’t feel welcome any more. I spent the best part of my life serving the British army, and when I needed help everyone turned their back on me,” he said by telephone from Jamaica. Williams arrived in Birmingham aged seven in 1971, with his mother, a hospital cleaner, and his father, who worked at the Longbridge British Leyland car manufacturing plant. He was <a href="https://www.theguardian.com/uk-news/2020/jun/21/i-feel-targeted-windrush-victim-decries-compensation-delays-as-racism">wrongly classified as an illegal immigrant</a> and sacked from his job in 2013, and spent five years nearly destitute, unable to work or claim benefits.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/stringing-us-along-windrush-u-turns-disappoint-those-whose-lives-were-ruined">Continue reading...</a>

## Feline uncertain? Cats do give clues if the fur’s about to fly, study finds
 - [https://www.theguardian.com/science/2023/jan/26/feline-uncertain-cats-do-give-clues-if-the-furs-about-to-fly-study-finds](https://www.theguardian.com/science/2023/jan/26/feline-uncertain-cats-do-give-clues-if-the-furs-about-to-fly-study-finds)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:26+00:00
 - user: None

<p>Study of 105 pairs of interacting felines decodes the cat behaviour that puzzles humans – and flags up the unsubtle battle cry of claws and yowling</p><p>When cats get together it can be difficult to tell rough and tumble play from a full-blown scrap. Now researchers say they have decoded feline behaviour to help owners spot when the fur might be about to fly.</p><p>Dr Noema Gajdoš‑Kmecová, first author of the research from the University of Veterinary Medicine and Pharmacy, in Košice, Slovakia – a cat owner herself – said understanding feline interactions could be difficult.</p> <a href="https://www.theguardian.com/science/2023/jan/26/feline-uncertain-cats-do-give-clues-if-the-furs-about-to-fly-study-finds">Continue reading...</a>

## Loyalty card data could help spot ovarian cancer cases sooner
 - [https://www.theguardian.com/society/2023/jan/26/loyalty-card-data-could-help-spot-ovarian-cancer-cases-sooner](https://www.theguardian.com/society/2023/jan/26/loyalty-card-data-could-help-spot-ovarian-cancer-cases-sooner)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:26+00:00
 - user: None

<p>Researchers find pain and indigestion medication purchases were higher in women who went on to be diagnosed</p><p>Loyalty card data on over-the-counter medicine purchases could help spot ovarian cancer cases earlier and enable more patients to fully recover, researchers have found.</p><p>Pain and indigestion medication purchases were higher in women who went on to be diagnosed with ovarian cancer, usually about eight months later, according to a study of almost 300 women led by Imperial College London researchers.</p> <a href="https://www.theguardian.com/society/2023/jan/26/loyalty-card-data-could-help-spot-ovarian-cancer-cases-sooner">Continue reading...</a>

## The Arcs’ Dan Auerbach and Leon Michels remember Richard Swift: ‘He gave you all the confidence in the world’
 - [https://www.theguardian.com/music/2023/jan/26/the-arcs-dan-auerbach-and-leon-michels-remember-richard-swift-he-gave-you-all-the-confidence-in-the-world](https://www.theguardian.com/music/2023/jan/26/the-arcs-dan-auerbach-and-leon-michels-remember-richard-swift-he-gave-you-all-the-confidence-in-the-world)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:26+00:00
 - user: None

<p>As they release the last album the indie supergroup recorded together, the Black Keys’ singer and the leader of the El Michels Affair recall their friend and producer’s verve, spirit – and troubled inner life</p><p>If you were ever lucky enough to visit Richard Swift’s recording studio in Cottage Grove, Oregon, you would have found a private kingdom hidden in the back yard behind his family home: keyboards triple-stacked among thrift-store finds, a sea of vintage guitars, a custom-made drum kit, plumes of palo santo half-covering the scent of weed.</p><p>“It was basically his art space,” says Dan Auerbach, usually of the Black Keys. “He modelled it after the videos of Lee Perry and his studio.” Here, Swift would spend his days honing the warm, soulful sound he brought to his own music and the records he produced. “He used to do all sorts of cool shit,” recalls Leon Michels of <a href="https://bigcrownrecords.com/artists/el-michels-affair/">El Michels Affair</a>. “One time he told me he recorded a song to cassette and then took the tape out, crumpled it up and put it back. I always thought that was the coolest thing. It sounded completely fucked up.”</p> <a href="https://www.theguardian.com/music/2023/jan/26/the-arcs-dan-auerbach-and-leon-michels-remember-richard-swift-he-gave-you-all-the-confidence-in-the-world">Continue reading...</a>

## C of E staff subjected to ‘horrific abuse and bullying’, says safeguarding official
 - [https://www.theguardian.com/world/2023/jan/26/c-of-e-officials-subjected-horrific-bullying-by-abuse-survivors](https://www.theguardian.com/world/2023/jan/26/c-of-e-officials-subjected-horrific-bullying-by-abuse-survivors)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:25+00:00
 - user: None

<p>Alexander Kubeyinje makes claims of abuse on staff, including death threats, in paper for General Synod</p><p>Church of England officials have been subjected to “horrific abuse and bullying”, including death threats, from a small number of survivors of sexual abuse and people with safeguarding concerns, an official church document says.</p><p>The claims come from the C of E’s national director of safeguarding, Alexander Kubeyinje, in <a href="https://www.churchofengland.org/sites/default/files/2023-01/GS%20Misc%201335%20NST%20update.pdf">a paper for the church’s legislative body</a>, the General Synod, which meets next month.</p> <a href="https://www.theguardian.com/world/2023/jan/26/c-of-e-officials-subjected-horrific-bullying-by-abuse-survivors">Continue reading...</a>

## Celtic cool or Scots cosplay? Alan Cumming’s strong looks on US Traitors assessed
 - [https://www.theguardian.com/fashion/2023/jan/26/celtic-cool-or-scots-cosplay-alan-cummings-strong-looks-on-us-traitors-assessed](https://www.theguardian.com/fashion/2023/jan/26/celtic-cool-or-scots-cosplay-alan-cummings-strong-looks-on-us-traitors-assessed)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:25+00:00
 - user: None

<p>Each week the show’s Scottish host adds to the drama with his elaborate tartan outfits – a fashion historian gives his verdict on their faithfulness</p><p>‘I’m like a less butch Agatha Christie in a fabulous outfit,” declares Alan Cumming in an early episode of the TV show The Traitors US. The outfit in question? A navy and green tartan suit teamed with a neon green knitted tie and a gold and green sparkly brooch.</p><p>The show, which originally launched late last year in the UK, was fronted by Claudia Winkleman and became an instant success, being streamed more than 28m times on BBC iPlayer. <a href="https://www.theguardian.com/tv-and-radio/2023/jan/24/tv-tonight-can-the-traitors-us-really-be-as-devilishly-good-as-the-uk-series">This week</a> saw the release of a US version on BBC Three. Spread over 10 episodes, there are two big changes to the format. The first: the arrival of the dapperly dressed Cumming as host. The second: contestants who hail from a reality TV background, selected from shows including The Real Housewives of Beverly Hills.</p> <a href="https://www.theguardian.com/fashion/2023/jan/26/celtic-cool-or-scots-cosplay-alan-cummings-strong-looks-on-us-traitors-assessed">Continue reading...</a>

## ‘I have to give up food for sanitary products’: UK readers on the cost of living crisis
 - [https://www.theguardian.com/business/2023/jan/26/readers-uk-cost-of-living-crisis](https://www.theguardian.com/business/2023/jan/26/readers-uk-cost-of-living-crisis)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 16:00:25+00:00
 - user: None

<p>Four people share the drastic measures they are taking to cut costs and stay financially afloat</p><p>As the cost of living crisis rages and UK inflation <a href="https://www.theguardian.com/business/2023/jan/18/uk-inflation-dips-people-continue-to-feel-pinch">remains at one of the highest levels in 40 years</a>, many people are finding that even the most meticulous budgeting can no longer make up for <a href="https://www.theguardian.com/business/2023/jan/18/uk-inflation-fall-masks-continued-price-rise-pain-for-households">astronomical price rises in many areas of life</a>.</p><p>Here, four people from different parts of the country share why they have had to take more drastic cost-cutting measures to stay financially afloat.</p> <a href="https://www.theguardian.com/business/2023/jan/26/readers-uk-cost-of-living-crisis">Continue reading...</a>

## Reed and McIlroy beat Dubai floods to stay on course for perfect Teegate finale
 - [https://www.theguardian.com/sport/2023/jan/26/reed-and-mcilroy-beat-dubai-floods-to-stay-on-course-for-perfect-teegate-finale](https://www.theguardian.com/sport/2023/jan/26/reed-and-mcilroy-beat-dubai-floods-to-stay-on-course-for-perfect-teegate-finale)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:50:40+00:00
 - user: None

<ul><li>American one behind leader Pieters after shortened day one </li><li>Reed: ‘You are all blowing up Teegate way bigger than it really is’</li></ul><p>The money-can’t-buy scenario for organisers of a disrupted Dubai Desert Classic involves Rory McIlroy and Patrick Reed, <a href="https://www.theguardian.com/sport/2023/jan/25/rory-mcilroy-defends-blanking-patrick-reed-dubai-tee-throwing-incident-golf">fresh from Teegate</a>, side by side in a weekend group. Reed, having played a key role in early week theatre, now has eyes fixed firmly on the prize. McIlroy is a Dubai specialist.</p><p>Reed’s propensity to block out background noise is nothing new. It was perhaps no surprise, then, to see the former Masters champion race to four under par and within one shot of the lead before time was called on day one at the Emirates Club. “Once you get inside the ropes, you put the blinders on and go play golf,” said Reed with a shrug.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/reed-and-mcilroy-beat-dubai-floods-to-stay-on-course-for-perfect-teegate-finale">Continue reading...</a>

## Runner declines to represent GB in Australia over travel climate impact
 - [https://www.theguardian.com/environment/2023/jan/26/runner-gb-australia-climate-innes-fitzgerald-cross-country](https://www.theguardian.com/environment/2023/jan/26/runner-gb-australia-climate-innes-fitzgerald-cross-country)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:36:09+00:00
 - user: None

<p>Teenage athlete Innes FitzGerald says opportunity is ‘privilege’ but cites ‘deep concern’ over travel issue</p><p>A promising teenage athlete has declined to represent Great Britain in a competition due to be held in Australia because she is concerned about the environmental impact of the associated travel.</p><p>Innes FitzGerald, a leading junior endurance runner, cited her “deep concern” over the issue in a letter to British Athletics in which she asked not to be considered for selection for the World Cross Country Championships.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/runner-gb-australia-climate-innes-fitzgerald-cross-country">Continue reading...</a>

## Football Daily | Duncan Ferguson takes his first bite of full-time football management
 - [https://www.theguardian.com/football/2023/jan/26/football-daily-email-duncan-ferguson-forest-green](https://www.theguardian.com/football/2023/jan/26/football-daily-email-duncan-ferguson-forest-green)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:31:58+00:00
 - user: None

<p><a href="https://www.theguardian.com/info/2022/nov/14/football-daily-email-sign-up">Sign up now! Sign up now! Sign up now? Sign up now!</a></p><p>It was only after his retirement as a player whose largely successful career had spanned 16 years that it occurred to Football Daily that we had never actually heard Duncan Ferguson speak. Throughout spells at Dundee United, Rangers, Everton, Newcastle and Everton again, the fearsome striker enjoyed hero status, scored some memorable goals, and got himself in several on- and off-field scrapes, seemingly managing to do so without so much as a single public utterance. This refusal to stand in front of a microphone may have had its origins in a court conviction for an on-field incident that even nowadays would merit little more than a red card and certainly not the three-month stretch in the Big House handed down by a Scottish beak. Not entirely unreasonably, Big Dunc felt he had been the victim of a stitch-up and there were plenty who agreed with him.</p><p>That photo of Jacob Murphy waving off Duje Caleta-Car after his red card (yesterday’s News, Bits and Bobs, full email edition) made me think: why stop there? Next time the opposition receive a red card, maybe the other team can form a guard of (dis)honour, all wave and clap as the disgraced red-carder departs the pitch, walking off on a hastily-deployed red carpet, to the sound of a 21-gun salute from canons specially deployed on top of the stand, as the floodlights flash from white to red, and Nelson Muntz’s trademark ‘ha-haaaa’ played on a loop. Maybe a quick entry in the ‘How Far Can I Kick a Drinks Bottle’ competition sponsored by a betting company on the way out too, complete with officials in white coats with tape measures? And if they take an age arguing with the ref about the decision, have an opera singer stroll out to the middle of the pitch and sing the national anthem. All six verses. Hopefully there’ll still be time for a quick firework display and marching band before they eventually get to the tunnel” – Steve Malone.</p> <a href="https://www.theguardian.com/football/2023/jan/26/football-daily-email-duncan-ferguson-forest-green">Continue reading...</a>

## Don’t be fooled: Germany’s U-turn on sending tanks to Ukraine is a reluctant one | Jan-Philipp Hein
 - [https://www.theguardian.com/commentisfree/2023/jan/26/germany-u-turn-tanks-ukraine-reluctant-olaf-scholz](https://www.theguardian.com/commentisfree/2023/jan/26/germany-u-turn-tanks-ukraine-reluctant-olaf-scholz)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:23:25+00:00
 - user: None

<p>The invasion of Ukraine has shaken Germany out of its decades-long commitment to pacifism</p><p>If the German chancellor, Olaf Scholz, chose to upgrade Germany’s <a href="https://www.theguardian.com/world/2023/jan/25/germany-leopard-2-tanks-ukraine">military assistance</a> to Ukraine this week, it was only as a result of the extreme amount of pressure that had been building up in recent days.</p><p>Russia’s full-scale invasion of Ukraine has thrust upon Germany the necessity of some serious self-analysis. It has shattered many certainties, including even that most iron-clad tenet of postwar German history, which maintained that no conflict could ever be resolved militarily. Germany’s famous creed “Wandel durch Handel”, change through trade<em>,</em> was directly derived from this thinking that had permeated virtually every part of its society.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/germany-u-turn-tanks-ukraine-reluctant-olaf-scholz">Continue reading...</a>

## ‘Sexy and dangerous’: why the erotic thriller is about to take over TV
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/sexy-and-dangerous-why-the-erotic-thriller-is-about-to-take-over-tv](https://www.theguardian.com/tv-and-radio/2023/jan/26/sexy-and-dangerous-why-the-erotic-thriller-is-about-to-take-over-tv)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:14:16+00:00
 - user: None

<p>Sexually charged films were big business in the 80s and 90s. Now an explosion of remakes is turning steamy classics into prestige television</p><p>When Richard Gere cruised down an LA highway at the start of the 1980 film American Gigolo – gleaming convertible, sharp suit – it shifted the tectonic plates of cinema. Here was a man, filmed in attentive, ogling closeups, who invited us to objectify him: a sex worker dedicated to pleasing his older clientele, his skin doused in hot California sun, a wardrobe bestowed by Giorgio Armani.</p><p>It helped signal a new way of watching men on screen, kickstarting two decades of films that tied pleasure and danger into a heady knot, ready for audiences to lasciviously unpick. By the mid-90s, erotic thrillers were banking not just several hundred million dollars at the box office, but Oscar nominations for the leads.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/sexy-and-dangerous-why-the-erotic-thriller-is-about-to-take-over-tv">Continue reading...</a>

## Jacob Rees-Mogg to host own chatshow on GB News
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/jacob-rees-mogg-to-host-own-chatshow-on-gb-news](https://www.theguardian.com/tv-and-radio/2023/jan/26/jacob-rees-mogg-to-host-own-chatshow-on-gb-news)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:12:28+00:00
 - user: None

<p>Conservative MP’s TV programme to showcase his ‘wide-ranging interests’ in front of live audiences</p><p>The Conservative MP Jacob Rees-Mogg has joined the rightwing TV channel GB News as a presenter. The former cabinet minister will host his own chatshow, which will tour the country to record in front of live audiences.</p><p>His show will “debate the hot topics of the day” and feature guests from “across the political spectrum”, according to the broadcaster.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/jacob-rees-mogg-to-host-own-chatshow-on-gb-news">Continue reading...</a>

## Visitor to UK parliament made to cover ‘stop Brexit’ sticker on laptop
 - [https://www.theguardian.com/uk-news/2023/jan/26/visitor-to-uk-parliament-made-to-cover-stop-brexit-sticker-on-laptop](https://www.theguardian.com/uk-news/2023/jan/26/visitor-to-uk-parliament-made-to-cover-stop-brexit-sticker-on-laptop)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:09:21+00:00
 - user: None

<p>Anna Betz says she was told to remove sticker with her fingernails and then given tape to hide it</p><p>A woman invited to parliament to attend the opening of an exhibition was asked to scratch off an old “stop Brexit” sticker from the top of her laptop before entering, the Guardian has been told.</p><p>Anna Betz, 66, a retired social worker, was told she had to remove the sticker in case she held the computer in the air to stage a protest.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/visitor-to-uk-parliament-made-to-cover-stop-brexit-sticker-on-laptop">Continue reading...</a>

## Season review – atmospheric road trip game with a muddled message
 - [https://www.theguardian.com/games/2023/jan/26/season-review-pc-playstation](https://www.theguardian.com/games/2023/jan/26/season-review-pc-playstation)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:00:24+00:00
 - user: None

<p><strong>PC, PlayStation 4/5 (version played); Scavengers Studio<br /></strong>A girl is trying to record her world at the end of an era, but what promises to be an emotional experience can often feel artificial</p><p>Exploration is a powerful motivator: no matter what kind of game we’re playing, we are driven by what stories, sights or characters wait around the next bend. Scavengers Studio makes use of that fascination with the unknown by making exploration the entire point of Season. You control a young, nameless woman, who decides to record as much of her world as she can and deliver her findings to a museum before the end of the current season, the term the game uses for its different historical eras. As she travels on foot and by bicycle, her sketches, audio recordings and photographs go into her scrapbook; the narration comes from someone reading that scrapbook in the future.</p><p>Season makes great use of its gameplay tools. Its camera comes with different filters and a focusing tool, which makes taking pictures pleasant. You have the freedom to snap or record whatever you want; even when you’re supposed to capture specific things to make sense of a mystery, the game leaves it completely up to you whether you want to engage or not, and for how long. Cycling feels great, and there is lots to see.</p><p>Season is out on 31 January; £24.99.</p> <a href="https://www.theguardian.com/games/2023/jan/26/season-review-pc-playstation">Continue reading...</a>

## Spitting Image stages revival – and this time the puppets are on a mission
 - [https://www.theguardian.com/stage/2023/jan/26/spitting-image-stages-revival-and-this-time-the-puppets-are-on-a-mission](https://www.theguardian.com/stage/2023/jan/26/spitting-image-stages-revival-and-this-time-the-puppets-are-on-a-mission)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:00:24+00:00
 - user: None

<p>Live theatre version of 1980s TV satire features Tom Cruise and other showbiz stars trying to save ‘broken Britain’</p><p>Writing a political satire for the stage in today’s tumultuous times is no easy task, as the writers of the new Spitting Image Live were quick to find out.</p><p>They had originally planned to base the show around Boris Johnson, but ended up binning the whole script the day after he left Downing Street.</p> <a href="https://www.theguardian.com/stage/2023/jan/26/spitting-image-stages-revival-and-this-time-the-puppets-are-on-a-mission">Continue reading...</a>

## Stravinsky: Les Noces; Ravel: Boléro review | Andrew Clements' classical album of the week
 - [https://www.theguardian.com/music/2023/jan/26/stravinsky-les-noces-ravel-bolero-review-aparte-ensemble-aedes-les-siecles](https://www.theguardian.com/music/2023/jan/26/stravinsky-les-noces-ravel-bolero-review-aparte-ensemble-aedes-les-siecles)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 15:00:24+00:00
 - user: None

<p><strong>(Aparté)<br />Ensemble Aedes/Les Siècles/Romano<br /></strong>The unfinished 1913 landmark work, completed by Theo Verney almost 100 years after Stravinsky conceived it, is earthy, lean and superbly performed</p><p>First performed by the Ballets Russes in Paris in 1923, with choreography by <a href="https://www.calvertjournal.com/articles/show/12439/bronislava-nijinsky-choreography-of-bronislava-women-recollected">Bronislava Nijinska</a>, Les Noces (The Wedding) was reputedly <a href="https://www.theguardian.com/music/2020/jul/22/stravinsky-where-to-start-with-his-music">Stravinsky’s</a> favourite of all his works. By any standard, it’s one of his greatest, most startlingly original creations, as much of a landmark in 20th-century modernism as the more celebrated Rite of Spring, but it was a score that took 10 years to reach the form in which it’s usually heard today – the singers accompanied by untuned and tuned percussion, including a quartet of pianos.</p><p>Stravinsky had first conceived the idea of a ballet based on the wedding rituals of Russian peasants in 1913. He completed the short score of the work four years later, and in 1919 began to orchestrate for an ensemble of two cimbaloms, harmonium, pianola and percussion. Yet he abandoned that score after just a couple of scenes, deciding (erroneously as it happened) that it would be impossible in performance to coordinate the mechanical pianola with the live instrumentalists and singers. But in 2007, the Dutch composer Theo Verbey continued where Stravinsky had left off, completing the remaining scenes of 1919 version, with the pianola taking a central role.</p> <a href="https://www.theguardian.com/music/2023/jan/26/stravinsky-les-noces-ravel-bolero-review-aparte-ensemble-aedes-les-siecles">Continue reading...</a>

## Donald Trump’s Truth Social posts bode ill for his return to Facebook
 - [https://www.theguardian.com/us-news/2023/jan/26/donald-trump-truth-social-posts-bode-ill-return-facebook](https://www.theguardian.com/us-news/2023/jan/26/donald-trump-truth-social-posts-bode-ill-return-facebook)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:52:50+00:00
 - user: None

<p>As Trump was reinstated, Meta’s Nick Clegg stressed ‘guardrails’ were in place. He could soon find them tested</p><p>If Donald Trump’s activity on his Truth Social account is a reliable indicator of what his return to Facebook and Instagram will unleash, then Nick Clegg is going to be busy.</p><p>The former US president has used his rightwing social media platform to push baseless claims of election fraud and amplified content related to the QAnon conspiracy multiverse. These were two issues that received a special mention from Clegg, the former British deputy prime minister turned president of global affairs at Meta, Facebook and Instagram’s parent, as he <a href="https://about.fb.com/news/2023/01/trump-facebook-instagram-account-suspension/">explained the decision</a> to end Trump’s two-year exile on Wednesday.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/donald-trump-truth-social-posts-bode-ill-return-facebook">Continue reading...</a>

## Outrage greets Meta decision to lift Trump Facebook ban – US politics live
 - [https://www.theguardian.com/us-news/live/2023/jan/26/trump-facebook-ban-meta-biden-economy-politics-live-updates](https://www.theguardian.com/us-news/live/2023/jan/26/trump-facebook-ban-meta-biden-economy-politics-live-updates)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:19:44+00:00
 - user: None

<ul><li>Ex-president allowed back on platform after two years away</li><li><a href="https://www.theguardian.com/info/2018/sep/17/guardian-us-morning-briefing-sign-up-to-stay-informed">Sign up to receive First Thing – our daily briefing by email</a></li></ul><p>Reactions to the <strong><a href="https://www.theguardian.com/us-news/2023/jan/25/trump-facebook-ban-lifted-unbanned-instagram-meta-pages-latest">decision by Meta</a></strong> to allow Donald Trump back on its Facebook and Instagram platforms is fierce.</p><p>The former US president was thrown off the platforms in relation to inflammatory posts about the January 6, 2021, insurrection at the US Capitol as his extremist supporters tried (ultimately in vain) to stop the certification of Joe Biden’s election victory over him.</p> <a href="https://www.theguardian.com/us-news/live/2023/jan/26/trump-facebook-ban-meta-biden-economy-politics-live-updates">Continue reading...</a>

## Britain lavishes benefits on plenty of rich pensioners. Let’s means test them now | Polly Toynbee
 - [https://www.theguardian.com/commentisfree/2023/jan/26/britain-rich-pensioners-state-pension-age-68-poor](https://www.theguardian.com/commentisfree/2023/jan/26/britain-rich-pensioners-state-pension-age-68-poor)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:16:08+00:00
 - user: None

<p>Bumping the state pension age up to 68 will do little to help those who are so poor, they won’t even reach that age</p><p>In a country so grossly unequal, nothing is fair. As the government plans to <a href="https://www.theguardian.com/money/2023/jan/25/uk-state-pension-age-rise-68#:~:text=For%20those%20born%20after%205,those%20born%20after%20April%201977.">raise the state pension age </a>from 66 to 68 at a much earlier date than previously announced, it looks increasingly unjust to pay out the pension at the same rate and at the same age for everyone, regardless of wildly differing circumstances.</p><p>A universal state retirement age means wealthy people will receive payments for many years more than the poor. The tyranny of averages conceals vast social class differences within Britain. Men in Richmond-on-Thames will, on average, <a href="https://www.health.org.uk/evidence-hub/health-inequalities/map-of-healthy-life-expectancy-at-birth">live healthily</a> until the age of 71, while for men in Blackpool, a healthy life expectancy is just 53 years, meaning they will wait in bad health, unable to work for 13 years, before qualifying for their pension at 66. In Blackpool’s Bloomfield ward, <a href="https://www.lancs.live/news/cost-of-living/blackpool-slams-bonkers-planned-new-26065860">reports LancsLive</a>, the average life expectancy of men is just 67 years and three months. That means many will never make it to drawing a pension if the government’s plan goes ahead. Prof Sir Michael Marmot, whose groundbreaking research analyses the effect of poverty, deprivation and deadening jobs on health and longevity, tells me: “If 68 becomes the new pension age, 60% of men never reach that age without a disability that prevents them working.”</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/britain-rich-pensioners-state-pension-age-68-poor">Continue reading...</a>

## Premiership Rugby to test shot clock in weekend fixtures
 - [https://www.theguardian.com/sport/2023/jan/26/premiership-rugby-to-test-new-shot-clock-technology-in-weekend-fixtures](https://www.theguardian.com/sport/2023/jan/26/premiership-rugby-to-test-new-shot-clock-technology-in-weekend-fixtures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:14:37+00:00
 - user: None

<ul><li>Shot clocks to be displayed for penalties and conversions</li><li>World Rugby eager to speed up the game</li></ul><p>The Premiership has announced plans to test new shot-clock technology for the first time this weekend, as the league trials World Rugby’s latest measure aimed at speeding up the game. <a href="https://www.theguardian.com/sport/2022/dec/22/world-rugby-union-time-limit-kickers">Under World Rugby’s new guidelines</a>, kickers have to take conversations within 90 seconds of a try being scored, while penalties must be kicked within 60 seconds of being awarded.</p><p>“The shot clock technology will be tested for the first time in a live match setting with match officials and timekeepers briefed on the introduction ahead of the weekend’s matches,” Premiership Rugby said. “Throughout the trial phase, the existing processes by which referees determine the time permitted for the kicker will remain in place to maintain the sporting integrity of the competition.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/premiership-rugby-to-test-new-shot-clock-technology-in-weekend-fixtures">Continue reading...</a>

## Sexual offences logged by police in England and Wales hit record high
 - [https://www.theguardian.com/society/2023/jan/26/sexual-offences-logged-by-police-england-wales-record-high](https://www.theguardian.com/society/2023/jan/26/sexual-offences-logged-by-police-england-wales-record-high)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:10:09+00:00
 - user: None

<p>There were 199,021 sexual offences and 70,633 rapes recorded by forces in the year to September 2022</p><p>The number of sexual offences recorded by police reached a record high in the year to September – increasing by more than a fifth compared with before the pandemic.</p><p>Home Office figures published on Thursday found there were 199,021 sexual offences recorded by forces across England and Wales in the year to September 2022, as well as 70,633 rapes.</p> <a href="https://www.theguardian.com/society/2023/jan/26/sexual-offences-logged-by-police-england-wales-record-high">Continue reading...</a>

## Lord Pickles ‘desperate’ for construction of UK Holocaust memorial to begin
 - [https://www.theguardian.com/world/2023/jan/26/lord-pickles-desperate-for-construction-of-uk-holocaust-memorial-to-begin](https://www.theguardian.com/world/2023/jan/26/lord-pickles-desperate-for-construction-of-uk-holocaust-memorial-to-begin)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:05:25+00:00
 - user: None

<p>Co-chair of memorial foundation says urgency of need to start work has increased given number of survivors dying</p><p>Lord Pickles, co-chair of the body overseeing a new £100m UK Holocaust memorial said he is “desperate” to finally start building given the dwindling number of survivors of the second world war genocide.</p><p>On Wednesday, the prime minister said he would legislate to work around a court ruling preventing the memorial and learning centre being erected on the grade-II-listed Victoria Tower Gardens beside the Houses of Parliament. The scheme has been in development since 2014 but has been mired in controversy.</p> <a href="https://www.theguardian.com/world/2023/jan/26/lord-pickles-desperate-for-construction-of-uk-holocaust-memorial-to-begin">Continue reading...</a>

## Kelley Deal: ‘I threw a TV out of a hotel window with Nirvana’
 - [https://www.theguardian.com/music/2023/jan/26/kelley-deal-breeders-r-ring-i-threw-a-tv-out-of-a-hotel-window-with-nirvana](https://www.theguardian.com/music/2023/jan/26/kelley-deal-breeders-r-ring-i-threw-a-tv-out-of-a-hotel-window-with-nirvana)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:25+00:00
 - user: None

<p>The Breeders and R Ring member answers your questions on twin telepathy with sister Kim, humming Ewoks and why knitting is rock’n’roll </p><p><strong>Which other rock star do you most often get confused with? </strong><em>Flashbleu</em></p><p>Dave Grohl! No. When Pixies first started getting big on college radio, I was at an amusement park and these two students came up, kind of trembling, and asked: “Are you Kim Deal?” I told them I was her identical twin and I knew they didn’t believe me. Kim has had the reverse experience. When we were infants our parents painted our toenails different colours to tell us apart.</p> <a href="https://www.theguardian.com/music/2023/jan/26/kelley-deal-breeders-r-ring-i-threw-a-tv-out-of-a-hotel-window-with-nirvana">Continue reading...</a>

## ‘Surfing in a sewer’: British windsurfer quits for Spain over water pollution
 - [https://www.theguardian.com/sport/2023/jan/26/surfing-in-a-sewer-british-windsurfer-sarah-jackson-quits-for-spain-over-water-pollution](https://www.theguardian.com/sport/2023/jan/26/surfing-in-a-sewer-british-windsurfer-sarah-jackson-quits-for-spain-over-water-pollution)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:25+00:00
 - user: None

<ul><li>Sarah Jackson, world No 2 in world in slalom, relocating</li><li>‘It’s not just unpleasant it’s actually health threatening’</li></ul><p>One of the world’s leading windsurfers has quit the English south coast for Spain after describing training near her home like “surfing in a sewer”. Sarah Jackson has won two world championship silver medals and is ranked second in the world in her slalom discipline.</p><p>The 24-year-old has been forced to relocate, however, due to the conditions of the water at Hayling Island, a windsurfing hotspot in Hampshire.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/surfing-in-a-sewer-british-windsurfer-sarah-jackson-quits-for-spain-over-water-pollution">Continue reading...</a>

## Cyclist Chloe Hosking: ‘My career is facing its end, when I don’t feel I’m done’ | Kieran Pender
 - [https://www.theguardian.com/sport/2023/jan/27/cyclist-chloe-hosking-my-career-is-facing-its-end-when-i-dont-feel-im-done](https://www.theguardian.com/sport/2023/jan/27/cyclist-chloe-hosking-my-career-is-facing-its-end-when-i-dont-feel-im-done)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:24+00:00
 - user: None

<p>After her new team collapsed, one of Australia’s most successful cyclists will be forced to retire unless a contract arises in the coming weeks</p><p>Chloe Hosking is one of the most successful Australian road cyclists of all time. She has notched up over 40 wins in her career, including sprint victories on the iconic Champs-Élysées and at her home Commonwealth Games. But speaking to Guardian Australia at a coffee shop in Canberra, Hosking is in tears. They are tears of disappointment and tears of frustration.</p><p>In early December, Hosking’s professional team, French outfit B&amp;B Hotels, collapsed. The 32-year-old was in Tenerife, Spain, training solo at altitude ahead of what she hoped to be a big 2023, when she was pulled into a Zoom call. “One of the moments that really stood out to me,” she says, “I was obviously very disappointed, and I was told to smile. I was like: ‘I don’t have a job, my 13-year career is over. Why should I smile?’”</p> <a href="https://www.theguardian.com/sport/2023/jan/27/cyclist-chloe-hosking-my-career-is-facing-its-end-when-i-dont-feel-im-done">Continue reading...</a>

## I’m a boy in my teens and I’m worried about my oldest friend. We’ve hit a divide over politics | Leading questions
 - [https://www.theguardian.com/lifeandstyle/2023/jan/27/im-a-boy-in-my-teens-and-im-worried-about-my-oldest-friend-weve-hit-a-divide-over-politics](https://www.theguardian.com/lifeandstyle/2023/jan/27/im-a-boy-in-my-teens-and-im-worried-about-my-oldest-friend-weve-hit-a-divide-over-politics)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:24+00:00
 - user: None

<p>Beliefs respond to how we live and what we feel, writes advice columnist <strong>Eleanor Gordon-Smith</strong>. You can give your friend experiences that could help change his</p><p><strong>I’m a boy in my late/middle teens, and I’m worried about my oldest friend. He’s also my cousin and, as you might expect, we’ve known each other </strong><strong> our entire lives. We’re the same age, similar interests and we’ve been extremely close since early childhood, however as we’ve grown up we’ve hit a divide: politics.</strong></p><p><strong>I support slow progression over generations into socialism, whereas he’s a rightwinger who says he’s “centrist”. He also has slightly edgy views around things which have polluted the minds of our peers, saying things such as “I can see Tate’s point, the world has come to discriminate against men,” or “It’s no longer acceptable for men to be masculine.”</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/27/im-a-boy-in-my-teens-and-im-worried-about-my-oldest-friend-weve-hit-a-divide-over-politics">Continue reading...</a>

## My bad trip – I took a voyage of self-discovery, but the self I discovered was a total buzzkill
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/my-bad-trip-i-took-a-voyage-of-self-discovery-but-the-self-i-discovered-was-a-total-buzzkill](https://www.theguardian.com/lifeandstyle/2023/jan/26/my-bad-trip-i-took-a-voyage-of-self-discovery-but-the-self-i-discovered-was-a-total-buzzkill)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:24+00:00
 - user: None

<p>Getting dumped right before a solo overland journey from Barcelona to Beijing derailed my bid to rebrand myself as a woman of the world</p><ul><li>Follow the <a href="https://www.theguardian.com/lifeandstyle/series/my-bad-trip">My bad trip</a> series</li><li><a href="https://www.theguardian.com/newsletters/2019/oct/18/saved-for-later-sign-up-for-guardian-australias-culture-and-lifestyle-email?CMP=cvau_sfl">Get our weekend culture and lifestyle email</a></li></ul><p>It was meant to be a voyage of self-discovery. But two days before I left, my boyfriend dumped me. The self I discovered was a total buzzkill.</p><p>“It’s not you, it’s me,” he swore, but I was crying my 21-year-old heart out in the front seat of an Uber as we wove through East Fremantle – a panic attack playing peekaboo in my gut.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/my-bad-trip-i-took-a-voyage-of-self-discovery-but-the-self-i-discovered-was-a-total-buzzkill">Continue reading...</a>

## The one change that didn’t work: I deleted all my social media apps – and found myself bored
 - [https://www.theguardian.com/media/2023/jan/26/the-one-change-that-didnt-work-giving-up-social-media-left-me-bored](https://www.theguardian.com/media/2023/jan/26/the-one-change-that-didnt-work-giving-up-social-media-left-me-bored)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 14:00:24+00:00
 - user: None

<p>I really did have more time on my hands when I quit addictive online platforms. But I missed connecting with friends and discovering unexpected inspiration</p><p>A year into the pandemic, in early 2021, I was spending most of my time online. I sat and I scrolled – on <a href="https://www.theguardian.com/media/social-media">Facebook, Twitter and Instagram</a> – letting the latest horrifying news wash over me, or watching videos of cute animals, or messaging bored friends about our mutual states of crisis.</p><p>The more I scrolled, the more all-consuming it became. I found myself instinctively reaching for my phone whenever I could. I would write a paragraph of a piece with a tight deadline, then have a browse on Twitter as a treat. I would watch TV and simultaneously check Instagram during scenes that lost my attention; even in bed, I would scroll to get to sleep and wake up to my phone’s blue light.</p> <a href="https://www.theguardian.com/media/2023/jan/26/the-one-change-that-didnt-work-giving-up-social-media-left-me-bored">Continue reading...</a>

## Culture secretary criticises IOC moves to allow Russian athletes at Paris 2024
 - [https://www.theguardian.com/sport/2023/jan/26/culture-secretary-criticises-ioc-moves-to-allow-russian-athletes-at-paris-2024](https://www.theguardian.com/sport/2023/jan/26/culture-secretary-criticises-ioc-moves-to-allow-russian-athletes-at-paris-2024)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:51:53+00:00
 - user: None

<ul><li>Michelle Donelan takes dim view of IOC’s stance</li><li>‘This position is a world away from the reality of war’</li></ul><p>Moves to reintegrate Russian athletes <a href="https://www.theguardian.com/sport/2023/jan/25/ioc-gives-green-light-for-russian-and-belarusian-athletes-at-paris-olympics">into next year’s Paris Olympics</a> amid the invasion of Ukraine have been criticised by the British government.</p><p>The International Olympic Committee said on Wednesday it was continuing to work on a pathway which would enable Russian and Belarusian athletes to compete as neutrals.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/culture-secretary-criticises-ioc-moves-to-allow-russian-athletes-at-paris-2024">Continue reading...</a>

## NatWest to close another 23 branches in England and Wales
 - [https://www.theguardian.com/business/2023/jan/26/natwest-to-close-another-23-branches-in-england-and-wales](https://www.theguardian.com/business/2023/jan/26/natwest-to-close-another-23-branches-in-england-and-wales)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:39:51+00:00
 - user: None

<p>High street banks have now announced 87 closures so far this year – see full list of NatWest closures below</p><p>NatWest is to shut another 23 branches in England and Wales, adding to a raft of high street banking closures already announced this month.</p><p>The sites will close in the first half of this year. The bank said the closures were due to more customers moving to mobile and online banking.</p> <a href="https://www.theguardian.com/business/2023/jan/26/natwest-to-close-another-23-branches-in-england-and-wales">Continue reading...</a>

## Banned Confederation of African Football media officer accused of more ‘indecent behaviour’
 - [https://www.theguardian.com/football/2023/jan/26/banned-confederation-of-african-football-media-officer-accused-of-more-indecent-behaviour](https://www.theguardian.com/football/2023/jan/26/banned-confederation-of-african-football-media-officer-accused-of-more-indecent-behaviour)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:39:28+00:00
 - user: None

<ul><li>Accusations of misconduct relate to two tournaments</li><li>Felix Sohounde Peperipé denies wrongdoing</li></ul><p>The Confederation of African Football media officer provisionally <a href="https://www.theguardian.com/football/2023/jan/24/confederation-of-african-football-media-officer-suspended-over-alleged-sexual-assault">banned for five years</a> after it was claimed he sexually abused a female official in his hotel room during the African Nations Championship in Algeria has been accused of offering to pay another official to “come to his room” at a previous tournament.</p><p>Felix Sohounde Peperipé – a Beninese journalist who has been working as one of the confederation’s media officers on a freelance basis during the tournament for African players playing in their national leagues – was sent home this week after a hearing of the Caf disciplinary committee in Algiers. </p> <a href="https://www.theguardian.com/football/2023/jan/26/banned-confederation-of-african-football-media-officer-accused-of-more-indecent-behaviour">Continue reading...</a>

## Australian Open: Aryna Sabalenka swats aside Linette to reach first slam final
 - [https://www.theguardian.com/sport/2023/jan/26/australian-open-aryna-sabalenka-swats-aside-linette-to-reach-first-slam-final](https://www.theguardian.com/sport/2023/jan/26/australian-open-aryna-sabalenka-swats-aside-linette-to-reach-first-slam-final)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:35:33+00:00
 - user: None

<ul><li>No 5 seed overpowers opponent in 7-6 (1), 6-2 victory</li><li>Belarusian will face Elena Rybakina in Saturday’s final</li></ul><p>The first-set tie-break said it all – Magda Linette lost it 7-1 and she had not done anything wrong. Until then it was toe to toe and anyone’s guess who would leave Rod Laver Arena with <a href="https://www.theguardian.com/sport/2023/jan/26/elena-rybakina-wins-bruising-tussle-with-victoria-azarenka-to-reach-australian-tennis-open-final">an appointment to see Elena Rybakina</a>on Saturday. </p><p>Aryna Sabalenka generally does not shift through the gears, mainly because she starts at full throttle and keeps her foot down for the entire match. But there was another, supersonic something or other she had kept in her back pocket for Thursday’s semi-final.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/australian-open-aryna-sabalenka-swats-aside-linette-to-reach-first-slam-final">Continue reading...</a>

## Madrid exhibition tells story of Spaniards sent to Nazi concentration camp
 - [https://www.theguardian.com/world/2023/jan/26/madrid-exhibition-tells-story-of-spaniards-sent-to-nazi-concentration-camp](https://www.theguardian.com/world/2023/jan/26/madrid-exhibition-tells-story-of-spaniards-sent-to-nazi-concentration-camp)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:17:52+00:00
 - user: None

<p>About 7,500 Spanish Republicans who fled to France were deported to Mauthausen camp in Austria</p><p>When, on 5 May 1945, two tanks from the US army’s 11th Armored Division finally rolled into Mauthausen, one of the camp’s prisoners caught a glimpse of himself and his fellow inmates in their liberators’ faces.</p><p>“Before their eyes,” recalled Alfonso Maeso, “marched a dismal procession of men devastated by years of suffering, massing before them, some whispering, others sobbing inconsolably.”</p> <a href="https://www.theguardian.com/world/2023/jan/26/madrid-exhibition-tells-story-of-spaniards-sent-to-nazi-concentration-camp">Continue reading...</a>

## Asda shake-up puts more than 300 jobs at risk
 - [https://www.theguardian.com/business/2023/jan/26/asda-plans-to-cut-300-jobs-reduce-pay-4300-staff-night-shift-post-office-pharmacies](https://www.theguardian.com/business/2023/jan/26/asda-plans-to-cut-300-jobs-reduce-pay-4300-staff-night-shift-post-office-pharmacies)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:16:56+00:00
 - user: None

<p>Managerial roles mainly at risk as part of changes affecting night shifts, Post Office outlets and pharmacies</p><p>More than 300 jobs at <a href="https://www.theguardian.com/business/asda">Asda</a> are at risk and 4,300 of the supermarket’s staff will end up with a pay cut after a swathe of changes to night shifts, Post Office outlets and pharmacies to save costs.</p><p>The supermarket chain said 211 night shift manager roles were going and a further 4,137 staff would lose out on premiums of at least £2.52 an hour for working nights as it switched the restocking of packaged groceries and frozen food to daytimes and evenings.</p> <a href="https://www.theguardian.com/business/2023/jan/26/asda-plans-to-cut-300-jobs-reduce-pay-4300-staff-night-shift-post-office-pharmacies">Continue reading...</a>

## TSB staff in line for bigger bonuses as profits hit record high
 - [https://www.theguardian.com/business/2023/jan/26/tsb-staff-in-line-for-bigger-bonuses-as-profits-reach-record-high](https://www.theguardian.com/business/2023/jan/26/tsb-staff-in-line-for-bigger-bonuses-as-profits-reach-record-high)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:11:26+00:00
 - user: None

<p>Bank hails successful turnaround from IT meltdown in 2018 with profits up 16.5% to £182.5m</p><p>TSB bankers will take home bigger bonuses this year, after rising interest rates pushed the high street lender’s annual profits to record highs.</p><p>The once-beleaguered bank, which suffered <a href="https://www.theguardian.com/business/2018/jun/06/timeline-of-trouble-how-the-tsb-it-meltdown-unfolded">a catastrophic IT meltdown in 2018</a>, reported a 16.5% rise in annual profits to £182.5m for 2022, as rising interest rates meant it was able to charge more for customer loans and mortgages.</p> <a href="https://www.theguardian.com/business/2023/jan/26/tsb-staff-in-line-for-bigger-bonuses-as-profits-reach-record-high">Continue reading...</a>

## India marks Republic Day and Sydney protests: Thursday’s best photos
 - [https://www.theguardian.com/news/gallery/2023/jan/26/india-marks-republic-day-and-sydney-protests-thursdays-best-photos](https://www.theguardian.com/news/gallery/2023/jan/26/india-marks-republic-day-and-sydney-protests-thursdays-best-photos)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:07:31+00:00
 - user: None

<p>The Guardian’s picture editors select photo highlights from around the world</p> <a href="https://www.theguardian.com/news/gallery/2023/jan/26/india-marks-republic-day-and-sydney-protests-thursdays-best-photos">Continue reading...</a>

## John Mulaney review – upbeat tales of addiction and downfall
 - [https://www.theguardian.com/stage/2023/jan/26/john-mulaney-review-standup-comedy-hammersmith-apollo-london](https://www.theguardian.com/stage/2023/jan/26/john-mulaney-review-standup-comedy-hammersmith-apollo-london)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:07:18+00:00
 - user: None

<p><strong>Hammersmith Apollo, London<br /></strong>The standup comedian may have lost some of the gloss on his reputation after nearly destroying himself with drugs, but his good cheer remains in place</p><p>‘If you’ve seen me do standup before, I have a kind of different vibe now.” Well, quite. Rare is the reputational reversal as complete as <a href="https://www.theguardian.com/tv-and-radio/2022/feb/27/saturday-night-live-john-mulaney-ukraine-tribute">John Mulaney</a>’s, who in short order these last two years went from being comedy’s happily married Mr Nice, via rehab for cocaine addiction, to a divorce and new relationship that <a href="https://www.theguardian.com/lifeandstyle/2021/sep/26/the-allure-of-fantasy-friends">sent fans into a tailspin</a>. There’s not a squeak about his domestic life in this confessional new show, which focuses instead on what happened when Mulaney’s celebrity pals staged an intervention to arrest his self-destructive slide into pharmaceutical oblivion.</p><p>Given the fashion for public self-flagellation, and indeed for heart-on-sleeve solo comedy, one braces for a show in which Mulaney reckons, lip perhaps a-tremble, with his public fall from grace. But, different vibe notwithstanding, that’s not his style. Yes, he dedicates the whole show to lurid stories of addiction and dysfunctional behaviour. But – as with the one about buying a Rolex watch to trade for drug money, or the one about “equine therapy” for recovering junkies – he makes them <em>fun</em>. There’s no sackcloth and ashes: heart on sleeve isn’t Mulaney’s mode. In the 40-year-old’s telling, at least in retrospect, addiction and rehab is a bit of a hoot.</p> <a href="https://www.theguardian.com/stage/2023/jan/26/john-mulaney-review-standup-comedy-hammersmith-apollo-london">Continue reading...</a>

## As a footballer I am surrounded by gambling ads. This needs to stop | David Wheeler
 - [https://www.theguardian.com/football/2023/jan/26/footballer-gambling-ads-stop-david-wheeler-wycombe](https://www.theguardian.com/football/2023/jan/26/footballer-gambling-ads-stop-david-wheeler-wycombe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:00:22+00:00
 - user: None

<p>I would rather be paid less if it meant not profiting from addiction, harm and suicide – and I am not the only one</p><p>I’ve been a professional footballer for more than a decade. In nearly all of my 500 appearances, I’ve had an online casino advert either on my shirt or surrounding me on the pitch.</p><p>It’s no surprise. It’s impossible to watch a match in the top five men’s divisions in England without seeing adverts for gambling. My career has not taken me to the Premier League (yet) but these ads can appear <a href="https://www.theguardian.com/society/2021/jun/05/gambling-logos-feature-700-times-in-football-match-says-ch4-documentary">more than 700 times a match</a> on television in our top flight, where nearly half the teams have a betting sponsor on the front of their shirts.</p> <a href="https://www.theguardian.com/football/2023/jan/26/footballer-gambling-ads-stop-david-wheeler-wycombe">Continue reading...</a>

## If you’re rich there are legal – and not so legal – ways to lower your tax bill | Robert Palmer
 - [https://www.theguardian.com/commentisfree/2023/jan/26/lower-tax-bill-british-tax-system-wealthy-nadhim-zahawi](https://www.theguardian.com/commentisfree/2023/jan/26/lower-tax-bill-british-tax-system-wealthy-nadhim-zahawi)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:00:21+00:00
 - user: None

<p>Ordinary people may play by the rules, but the British tax system is stacked in favour of the wealthy – who take full advantage</p><p>Last week the <a href="https://www.theguardian.com/uk-news/2023/jan/20/nadhim-zahawi-agreed-on-penalty-to-settle-tax-bill-worth-millions">Guardian reported</a> that a senior minister, Nadhim Zahawi, has paid a penalty of around £1m to HMRC for being “careless” with his taxes. This might seem galling to those who are spending this month carefully filling out their tax returns, or those who automatically pay their taxes through PAYE.</p><p>According to <a href="https://www.gov.uk/government/statistics/measuring-tax-gaps/7-tax-gaps-illustrative-tax-gap-by-behaviour">HMRC figures</a>, £6.1bn a year is lost to people “failing to take reasonable care” with their tax returns. Some of this will be caught by the tax authorities, but much of it will go unnoticed.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/lower-tax-bill-british-tax-system-wealthy-nadhim-zahawi">Continue reading...</a>

## Pathaan review – daft Shah Rukh Khan spy caper is more fun than Bond
 - [https://www.theguardian.com/film/2023/jan/26/pathaan-review-daft-shah-rukh-khan-spy-caper-is-more-fun-than-bond](https://www.theguardian.com/film/2023/jan/26/pathaan-review-daft-shah-rukh-khan-spy-caper-is-more-fun-than-bond)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 13:00:21+00:00
 - user: None

<p>The Bollywood megastar plays an unfeasibly ripped agent brought out of retirement to foil the fiendish terror plots of Outfit X</p><p>This enjoyable high-octane action spy movie from India is possibly the most fun you can currently have at the cinema – for the first two hours of its running time at least. At the packed London cinema where I watched it on opening night, the crowd erupted with whoops the moment Bollywood superstar Shah Rukh Khan appeared on screen – face battered to a pulp, gazing up through a bloody swollen half-shut eye.</p><p>The film is the latest instalment in the <a href="https://en.wikipedia.org/wiki/YRF_Spy_Universe">YRF Spy Universe</a>: Khan is Pathaan, a James Bond-ish spy brought out of retirement to take down an international terror organisation known as Outfit X. Its leader is another former Indian spy, Jim (John Abraham), who’s gone rogue, committing atrocities for the likes of Boko Haram and Islamic State in return for cash. Now Jim has got his hands on a biological weapon of mass destruction.</p> <a href="https://www.theguardian.com/film/2023/jan/26/pathaan-review-daft-shah-rukh-khan-spy-caper-is-more-fun-than-bond">Continue reading...</a>

## Dining across the divide: ‘I was at Oxford, and people had to walk past a statue of a coloniser every day’
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/dining-across-the-divide-i-was-at-oxford-and-people-had-to-walk-past-a-statue-of-a-coloniser-every-day](https://www.theguardian.com/lifeandstyle/2023/jan/26/dining-across-the-divide-i-was-at-oxford-and-people-had-to-walk-past-a-statue-of-a-coloniser-every-day)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:30:21+00:00
 - user: None

<p>They might agree on Jeremy Corbyn, but are they as closely aligned on colonialism or the monarchy?</p><p><strong>Derren, 52, East Grinstead, West Sussex</strong></p><p><strong>Occupation</strong> Senior estimator at a demolition company<em> </em></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/dining-across-the-divide-i-was-at-oxford-and-people-had-to-walk-past-a-statue-of-a-coloniser-every-day">Continue reading...</a>

## Trans woman found guilty of rape will not be held in women’s prison, says Sturgeon
 - [https://www.theguardian.com/uk-news/2023/jan/26/trans-woman-isla-bryson-found-guilty-rape-not-be-held-in-womens-prison-sturgeon](https://www.theguardian.com/uk-news/2023/jan/26/trans-woman-isla-bryson-found-guilty-rape-not-be-held-in-womens-prison-sturgeon)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:27:01+00:00
 - user: None

<p>First minister tells MSPs Isla Bryson will not be imprisoned in Scotland’s all-female Cornton Vale prison</p><p>Isla Bryson, a transgender woman found guilty of raping two women before transitioning, will not be imprisoned in Scotland’s all-female Cornton Vale prison, Nicola Sturgeon has told the Scottish parliament.</p><p><em>More details soon …</em></p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/trans-woman-isla-bryson-found-guilty-rape-not-be-held-in-womens-prison-sturgeon">Continue reading...</a>

## We are all playing Covid roulette. Without clean air, the next infection could permanently disable you | George Monbiot
 - [https://www.theguardian.com/commentisfree/2023/jan/26/covid-roulette-clean-air-ventilation-long-covid](https://www.theguardian.com/commentisfree/2023/jan/26/covid-roulette-clean-air-ventilation-long-covid)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:26:06+00:00
 - user: None

<p>As rich people plough money into ventilation to protect themselves, those with long Covid are treated as an embarrassment</p><p>You could see Covid-19 as an empathy test. Who was prepared to suffer disruption and inconvenience for the sake of others, and who was not? The answer was often surprising. I can think, for instance, of five prominent environmentalists who denounced lockdowns, vaccines and even masks as intolerable intrusions on our liberties, while proposing no meaningful measures to prevent transmission of the virus. Four of them became active spreaders of disinformation.</p><p>If environmentalism means anything, it’s that our damaging gratifications should take second place to the interests of others. Yet these people immediately failed the test, placing their own convenience above the health and lives of others.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/covid-roulette-clean-air-ventilation-long-covid">Continue reading...</a>

## Windrush inquiry head disappointed as Braverman drops ‘crucial’ measures
 - [https://www.theguardian.com/uk-news/2023/jan/26/windrush-inquiry-head-wendy-williams-disappointed-suella-braverman-drops-crucial-measures](https://www.theguardian.com/uk-news/2023/jan/26/windrush-inquiry-head-wendy-williams-disappointed-suella-braverman-drops-crucial-measures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:24:47+00:00
 - user: None

<p>Wendy Williams’ remarks come after home secretary confirms three key commitments will not now be implemented</p><ul><li><a href="https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest">UK politics live – latest news updates</a></li></ul><p>The head of the inquiry into the Windrush debacle has expressed disappointment after Suella Braverman confirmed she has dropped three key reform commitments made in the wake of the Home Office scandal.</p><p>The home secretary said she will not implement two changes which would have increased independent scrutiny of the Home Office’s immigration policies and a third promise to run reconciliation events with Windrush families.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/windrush-inquiry-head-wendy-williams-disappointed-suella-braverman-drops-crucial-measures">Continue reading...</a>

## Frances McDormand’s 10 best performances – ranked!
 - [https://www.theguardian.com/film/2023/jan/26/frances-mcdormand-films-ranked](https://www.theguardian.com/film/2023/jan/26/frances-mcdormand-films-ranked)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:18:48+00:00
 - user: None

<p>Shortly to be seen on our screens in Women Talking, the actor is enjoying a fruitful – and Oscar-hauling – career third act, creating work that is empathic, political, and often doesn’t look like acting at all</p><p>As the pregnant married lover of Michael Douglas’s silver-fox creative writing professor, this is the kind of fairly thankless ancillary role that McDormand does so well: giving us a subtle insight into the human frailties under the surface of an otherwise tough-nut authority figure.</p> <a href="https://www.theguardian.com/film/2023/jan/26/frances-mcdormand-films-ranked">Continue reading...</a>

## The Virgin Suicides at 30: why I’m obsessed with this dark, dreamy novel
 - [https://www.theguardian.com/books/2023/jan/26/the-virgin-suicides-at-30-why-im-obsessed-with-this-dark-dreamy-novel](https://www.theguardian.com/books/2023/jan/26/the-virgin-suicides-at-30-why-im-obsessed-with-this-dark-dreamy-novel)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:17:31+00:00
 - user: None

<p>I grew up in Florida, but Jeffrey Eugenides’s story of five doomed midwestern sisters felt intensely familiar. What is it that makes me return to this bleakly comic novel again and again?</p><p>The Virgin Suicides was published in 1993, the year Bill Clinton became president, the first Beanie Baby went on sale, and Cern released the world wide web source code into the public domain. It was also the year I was born. Fifteen years later, I saw Sofia Coppola’s film adaptation, and my instant messenger avatar became Kirsten Dunst, picking petals from a daisy, stained pink by sunset. Along with many girls in my high school, I wasted hours with digital cameras trying to capture the same dreamy aesthetic as the movie. We held bougainvillaea flowers and posed by stinking suburban lakes, hiding behind our hair, always disappointed by the results that turned out too bright, too childlike, too true.<strong> </strong></p><p>The book soon got passed around the more committed, easily-influenced-by-Tumblr girls. Although I grew up in Orlando, and the novel is set in the suburbs of mid-70s Detroit, where I have never been, the landscape felt so intensely familiar that I read it for the first time as though remembering it. I fell even more deeply in love with the five Lisbon sisters – blonde, long-haired and beloved by the boys across the street, who narrate the novel from a distance. I was as quick as the boys to believe the girls were angels: beautiful, tragically cool. I didn’t realise then, but I shared a viewpoint, not with the sisters as I hoped, but with the boys who never got near them. Dumb with longing, we all completely missed the point.</p> <a href="https://www.theguardian.com/books/2023/jan/26/the-virgin-suicides-at-30-why-im-obsessed-with-this-dark-dreamy-novel">Continue reading...</a>

## Sound of the Underground review – magnificent explosion of mesmerising drag
 - [https://www.theguardian.com/stage/2023/jan/26/sound-of-the-underground-royal-court-london](https://www.theguardian.com/stage/2023/jan/26/sound-of-the-underground-royal-court-london)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 12:05:46+00:00
 - user: None

<p><strong>Royal Court, London</strong><br />A plot to kill RuPaul for dragging drag into the mainstream, followed by song and dance numbers, fires up an exhilarating show with breathtaking costumes, radical politics and filthy humour</p><p>It takes some time for Travis Alabanza’s show about the underground drag scene to set alight. But once it does, somewhere in the later part of the first act – after the awkward early scenes – it is a magnificent explosion of burlesque, feather boas, radical politics, pain, anger, filthy humour and breathtaking drag.</p><p>Co-created and directed by Debbie Hannan, the fire lies in the song and dance numbers, thunderous in their power, that come in the second act. But before that there are discussions on the state of the art today. Issues such as low pay and unionisation are flagged up, a little woodenly, but the show begins to bare its heart as the set is dismantled to reveal the naked walls of the theatre beyond.</p><p><a href="https://royalcourttheatre.com/whats-on/sound-of-the-underground/">Sound of the Underground</a> is at Royal Court, London, until 25 February<br /></p> <a href="https://www.theguardian.com/stage/2023/jan/26/sound-of-the-underground-royal-court-london">Continue reading...</a>

## Chartbuster: cyclist rides 7,000 miles across every Ordnance Survey map
 - [https://www.theguardian.com/uk-news/2023/jan/26/chartbuster-cyclist-rides-7000-miles-across-every-ordnance-survey-map](https://www.theguardian.com/uk-news/2023/jan/26/chartbuster-cyclist-rides-7000-miles-across-every-ordnance-survey-map)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:45:55+00:00
 - user: None

<p>Mark Wedgwood traverses territory covered by every one of the 204 Landrangers and says none of his trousers fit any more</p><p>Beloved by armchair explorers and outdoors enthusiasts alike, Ordnance Survey’s Landranger maps have inspired countless adventures.</p><p>But for one keen cyclist they sparked a challenge that is almost certainly a first: riding across every <a href="https://www.theguardian.com/uk-news/2018/sep/09/uk-worst-selling-map-empty-landscape-ordnance-survey-os440-glen-cassley">map in Great Britain</a> in a journey of more than 7,000 miles (11,250km).</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/chartbuster-cyclist-rides-7000-miles-across-every-ordnance-survey-map">Continue reading...</a>

## Mexico City’s crumbling metro system casts shadow on mayor’s 2024 ambitions
 - [https://www.theguardian.com/world/2023/jan/26/mexico-city-metro-system-mayor-claudia-sheinbaum-2024-campaign](https://www.theguardian.com/world/2023/jan/26/mexico-city-metro-system-mayor-claudia-sheinbaum-2024-campaign)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:35:17+00:00
 - user: None

<p>String of mishaps of cantankerous subway system could throw a wrench in Claudia Sheinbaum’s presidential aspirations</p><p>Smoke filled the subway station, the tunnel <a href="https://twitter.com/El_Universal_Mx/status/1617578708977733633">turning gray</a> in the choking haze as hundreds of passengers were evacuated from the train. More than a dozen were treated for smoke inhalation, the authorities said, after a <a href="https://www.eluniversal.com.mx/metropoli/tambien-en-barranca-del-muerto-falta-cable-informa-director-del-metro-en-total-18-personas-fueron-dar-hospital">short circuit</a> apparently caused the wafting fumes.</p><p>The incident on Monday, which soon billowed across <a href="https://twitter.com/_LosTitulares/status/1617622449277014017">Mexican social media</a>, is just the latest in a string of mishaps on Mexico City’s cantankerous subway system which have left more than two dozen people dead – and potentially thrown a major wrench into the presidential aspirations of the capital’s mayor, Claudia Sheinbaum.</p> <a href="https://www.theguardian.com/world/2023/jan/26/mexico-city-metro-system-mayor-claudia-sheinbaum-2024-campaign">Continue reading...</a>

## Kovac steers Wolves out of the woods amid shambles of Hertha Berlin | Andy Brassell
 - [https://www.theguardian.com/football/blog/2023/jan/26/bundesliga-wolfsburg-hertha-berlin-niko-kovac](https://www.theguardian.com/football/blog/2023/jan/26/bundesliga-wolfsburg-hertha-berlin-niko-kovac)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:32:22+00:00
 - user: None

<p>Niko Kovac’s heart may be ‘attached to Hertha’ but his surging Wolfsburg team showed them little mercy in a Bundesliga rout</p><p>Wolves are built to thrive in bitter winter, so with the champions still struggling to de-ice the windscreen and get the motor running, who better to assume the role of Bayern for now? In a glacial Olympiastadion in Berlin on Tuesday, Wolfsburg flamed their hosts, Hertha, 5-0 to make it two wins, 11 goals scored and none conceded. They remain seventh but only three points off third place and now with a better goal difference, and defensive record, than any team beyond Bayern.</p><p>They are imperious. It was <em>Die Wölfe</em>’s sixth league win in a row, and they’ve kept clean sheets in five. Niko Kovac’s team have not lost since a defeat at Union in mid-September and it didn’t look for a minute as if the <em>Köpenickers</em>’ capsizing neighbours Hertha had the chops to change that.</p> <a href="https://www.theguardian.com/football/blog/2023/jan/26/bundesliga-wolfsburg-hertha-berlin-niko-kovac">Continue reading...</a>

## Counterfeiting, contraband, cocaine: how Panama’s trade hub lost its lustre
 - [https://www.theguardian.com/world/2023/jan/26/colon-panama-counterfeiting-contraband-cocaine](https://www.theguardian.com/world/2023/jan/26/colon-panama-counterfeiting-contraband-cocaine)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:30:17+00:00
 - user: None

<p>Colón’s tree trade zone was meant to be hub for the Americas but it has become a byword for drugs, gangs and violence</p><p>In the Colón Free Trade Zone, near the Caribbean entrance to the Panama Canal, the dated Perspex and glass buildings are emblazoned with brand names for electronics, perfumes and textiles. Behind loom vast warehouses and dozens of port cranes, while on the street, shop owners unload merchandise from shipping containers.</p><p>Established in 1948, the world’s second largest free-trade zone was envisioned as a wholesale redistribution centre for Latin America and the Caribbean, but it has become a global hub of counterfeiting, contraband and cocaine.</p> <a href="https://www.theguardian.com/world/2023/jan/26/colon-panama-counterfeiting-contraband-cocaine">Continue reading...</a>

## The Brides review – overblown antics from David Glass and co, and for LIMF the end of an era
 - [https://www.theguardian.com/stage/2023/jan/26/the-brides-david-glass-ensemble-topi-dalmata-review-jacksons-lane-limf-london-international-mime-festival](https://www.theguardian.com/stage/2023/jan/26/the-brides-david-glass-ensemble-topi-dalmata-review-jacksons-lane-limf-london-international-mime-festival)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:30:17+00:00
 - user: None

<p><strong>Jacksons Lane, London</strong> <br />Glass’s latest collaboration cites female power but suggests the opposite, and comes as London’s influential mime festival prepares to disperse</p><p>After 47 appearances, the <a href="https://mimelondon.com/festival/">London international mime festival</a> is taking its final bow as a large-scale, multi-venue extravaganza. From now on, physical and visual theatre productions under its umbrella will appear at venues around the UK throughout the year. Why the change? No reason has been given. The festival’s current directors, Helen Lannaghan and Joseph Seelig, simply say that future plans will be announced on the website “in due course”.</p><p>Festival stalwart David Glass and <a href="https://davidglassensemble.co.uk/">his ensemble</a> embody, in some respects, the ethos of the event: international, inclusive, innovative. This year, in collaboration with the Italian company <a href="http://topidalmata.it/en/about-us/">Topi Dalmata</a>, led by Margherita Fusi and Silvia Bruni, he presents <em><a href="https://davidglassensemble.co.uk/productions/the-brides/">The Brides</a></em>.</p><p><em><a href="https://www.jacksonslane.org.uk/events/the-brides/?cn-reloaded=1">The Brides</a></em><a href="https://www.jacksonslane.org.uk/events/the-brides/?cn-reloaded=1"> is at Jacksons Lane, London, until 29 January</a></p><p><a href="https://mimelondon.com/festival/">The 2023 London international mime festival continues until 5 February</a></p> <a href="https://www.theguardian.com/stage/2023/jan/26/the-brides-david-glass-ensemble-topi-dalmata-review-jacksons-lane-limf-london-international-mime-festival">Continue reading...</a>

## Newcastle’s Joelinton banned and fined £31,085 for drink-driving
 - [https://www.theguardian.com/football/2023/jan/26/newcastle-joelinton-banned-driving-fined-drink-driving](https://www.theguardian.com/football/2023/jan/26/newcastle-joelinton-banned-driving-fined-drink-driving)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:29:33+00:00
 - user: None

<ul><li>Drink-driving course would reduce ban from 12 months to nine</li><li>Brazilian’s fine amounts to less than one week’s wages</li></ul><p>Newcastle United’s Joelinton has been banned from driving for 12 months and fined £31,085 after pleading <a href="https://www.theguardian.com/football/2023/jan/12/newcastle-joelinton-charged-with-drink-driving-arrest">guilty to drink-driving</a> during a court appearance on Tyneside on Thursday.</p><p>The 26-year-old Brazilian will have his driving licence returned after nine months if he completes a drink-driving rehabilitation course. The midfielder or forward, a £40m signing from Hoffenheim in 2019, was driving home from Newcastle city centre to his home in the Northumberland village of Ponteland in his black Mercedes when, at almost 1.20am on 12 January, police officers pulled him over for suspected speeding.</p> <a href="https://www.theguardian.com/football/2023/jan/26/newcastle-joelinton-banned-driving-fined-drink-driving">Continue reading...</a>

## 'Toothless' Leopards and 'battered' Abrams: Russian TV mocks Nato tanks promised to Ukraine – video
 - [https://www.theguardian.com/world/video/2023/jan/26/toothless-leopards-and-battered-abrams-russian-tv-mocks-nato-tanks-promised-to-ukraine-video](https://www.theguardian.com/world/video/2023/jan/26/toothless-leopards-and-battered-abrams-russian-tv-mocks-nato-tanks-promised-to-ukraine-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:27:43+00:00
 - user: None

<p>Russian state TV reacted with acerbic putdowns on Wednesday to the news that the US and Germany had finally agreed to send tanks to&nbsp;Ukraine. The Rossiya-24 TV channel broadcast a series of mocking stories. In one on-air sequence titled 'Toothless cats', the presenter said the German-made tanks were 'more primitive', heavier, less manoeuvrable and had a shorter firing range compared with Russian T-90s. Pointing to an on-screen graphic showing a fictional battle between T-90 and Leopard tanks, the news anchor said half of the Nato platoon would be hit before even reaching the battlefield. Another withering sequence called the US-made tanks 'battered Abrams' and showed footage of the armoured vehicles being struck in a number of past battles&nbsp;</p><ul><li><a href="https://www.theguardian.com/world/live/2023/jan/26/russia-ukraine-war-live-key-thing-now-is-speed-and-volume-says-zelenskiy-as-allies-commit-to-tanks#maincontent">Russia-Ukraine war - live updates</a></li><li><a href="https://www.theguardian.com/world/2023/jan/26/ukraine-mass-missile-attack-kyiv-day-after-tanks-promise">Ukraine under mass missile attack a day after west’s promise of tanks</a><br /></li><li><a href="https://www.theguardian.com/world/2023/jan/26/ukraine-says-us-and-german-tank-pledges-only-the-beginning-and-calls-for-fighter-jets">Ukraine says US and German tank pledges ‘only the beginning’ and calls for fighter jets</a><br /></li></ul> <a href="https://www.theguardian.com/world/video/2023/jan/26/toothless-leopards-and-battered-abrams-russian-tv-mocks-nato-tanks-promised-to-ukraine-video">Continue reading...</a>

## Why are M&M’s caving to right-wing anti-woke pressure? | Tayo Bero
 - [https://www.theguardian.com/commentisfree/2023/jan/26/mms-mascot-debate-woke-culture-war-maya-rudolph](https://www.theguardian.com/commentisfree/2023/jan/26/mms-mascot-debate-woke-culture-war-maya-rudolph)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:22:17+00:00
 - user: None

<p>The brand made a vague symbolic gesture – and rightwing pundits twisted it into a devious agenda. Now they’re retreating</p><p>They were <a href="https://www.dailykos.com/stories/2023/1/9/2146311/-Fox-News-thinks-M-M-s-new-women-focused-campaign-could-give-way-to-a-Chinese-takeover-of-U-S">inciting</a> a communist takeover. They were promoting radical wokeness. Worst of all, they weren’t hot any more.</p><p>A year after it first began, one of the most ridiculous back-and-forths between a large corporation and the media I’ve witnessed in my lifetime is finally over. The M&amp;M’s<em> </em>have pulled their beloved spokescandies.</p><p>Tayo Bero is a Guardian US columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/mms-mascot-debate-woke-culture-war-maya-rudolph">Continue reading...</a>

## Nineteen massacred in three days in one state. When will we say enough is enough? | Jill Filipovic
 - [https://www.theguardian.com/commentisfree/2023/jan/26/nineteen-massacred-in-three-days-in-one-state-when-will-we-say-enough-is-enough](https://www.theguardian.com/commentisfree/2023/jan/26/nineteen-massacred-in-three-days-in-one-state-when-will-we-say-enough-is-enough)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:15:17+00:00
 - user: None

<p>Why does America allow civilians to amass weapons of war, but not to live free of a constant threat of random violence?</p><p>Three days. Three mass shootings. One state. Nineteen dead.</p><p>These numbers are stark enough that, in a sane society, they’d engender outrage and then change. But this is the United States, and when it comes to our tolerance of mass gun deaths, we are truly exceptional. Thanks to our feckless supreme court and the Republican party death cult, even the most progressive parts of the country have no real ability to crack down on guns and keep their residents safe. We are collectively stuck living in a dangerous, weapon-happy dystopia, all because reactionary, fearful conservatives want to cosplay as tough guys with deadly toys.</p><p>Jill Filipovic is the author of the The H-Spot: The Feminist Pursuit of Happiness</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/nineteen-massacred-in-three-days-in-one-state-when-will-we-say-enough-is-enough">Continue reading...</a>

## Africa has become ‘less safe, secure and democratic’ in past decade, report finds
 - [https://www.theguardian.com/global-development/2023/jan/26/africa-less-safe-secure-and-democratic-in-past-decade-ibrahim-index](https://www.theguardian.com/global-development/2023/jan/26/africa-less-safe-secure-and-democratic-in-past-decade-ibrahim-index)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:15:15+00:00
 - user: None

<p>Progress in key areas has stalled because of Covid, conflict and the climate crisis, but peaceful nations are performing better</p><p>Africa is less safe, secure and democratic than a decade ago, with insecurity holding back progress in health, education and economic opportunities, according to an assessment of the continent.</p><p>The <a href="https://iiag.online/downloads.html">Ibrahim index of African governance</a>, which examines how well governments have delivered on policies and services, including security, health, education, rights and democratic participation, said Covid had contributed to the stalling of progress over the past three years. </p> <a href="https://www.theguardian.com/global-development/2023/jan/26/africa-less-safe-secure-and-democratic-in-past-decade-ibrahim-index">Continue reading...</a>

## Link’s game, an aide’s shame and a poor lost Norfolk seal – take the Thursday quiz
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/the-guardian-thursday-quiz-general-knowledge-topical-news-trivia-92](https://www.theguardian.com/lifeandstyle/2023/jan/26/the-guardian-thursday-quiz-general-knowledge-topical-news-trivia-92)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:00:07+00:00
 - user: None

<p>Fifteen questions on general knowledge and topical trivia, plus a few jokes every Thursday. How will you fare?</p><p>Scientifically proven to be the fourth Thursday in the month, it marks yet another chance for you to tackle 15 questions on vaguely topical news subjects and general knowledge. Filled with repetitive in-jokes and hidden references to children’s favourite Doctor Who to spot, it is just for fun and there are no prizes. But let us know how you got on in the comments, and make the quiz master laugh to earn bonus points.</p><p><strong>The Thursday quiz, No 92</strong></p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/the-guardian-thursday-quiz-general-knowledge-topical-news-trivia-92">Continue reading...</a>

## The one change that didn’t work: every dog is an emotional support animal – except mine
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-my-new-dog-was-the-opposite-of-an-emotional-support-animal](https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-my-new-dog-was-the-opposite-of-an-emotional-support-animal)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:00:07+00:00
 - user: None

<p>Dogs can do so much for you – but try one that isn’t a bald, psychopathic wrecking ball with a raw, tenacious savagery</p><p>There are so many benefits to having a dog, really life-altering ones: dogs give you structure, force you to exercise, help you to forge casual but, over time, meaningful bonds with the owners of other dogs, offer companionship. But more than any of that, they love you above all others. They love you to reaches you don’t even understand; one might say they teach you what love is. Every dog is an emotional support animal.</p><p>But you know what? Not my dog. Romeo is an emotional drain animal.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-my-new-dog-was-the-opposite-of-an-emotional-support-animal">Continue reading...</a>

## New York City could lose 10,000 Airbnb listings in short-term rental crackdown
 - [https://www.theguardian.com/us-news/2023/jan/26/nyc-airbnb-short-term-rental-new-law](https://www.theguardian.com/us-news/2023/jan/26/nyc-airbnb-short-term-rental-new-law)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:00:06+00:00
 - user: None

<p>New rules spark furious debate as city tightens regulation of illegal rentals in attempt to defend housing stock for tenants</p><p>New York City’s latest plans to crack down on illegal short-term rentals – which could remove as many as 10,000 Airbnb listings later this year – is sparking fierce debates about housing, hotels, the tourist market and residents’ rights.</p><p>The new rules will hit those New Yorkers who make extra income by hosting – renting out apartments on <a href="https://www.theguardian.com/technology/airbnb">Airbnb</a> and similar platforms – but flout city laws, while potentially easing the burden on <a href="https://www.theguardian.com/lifeandstyle/ng-interactive/2022/feb/08/new-york-rent-housing-market-pandemic-trends">long-suffering city renters</a>.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/nyc-airbnb-short-term-rental-new-law">Continue reading...</a>

## The Mysterious Case of the Alperton Angels by Janice Hallett review – on the trail of a cult
 - [https://www.theguardian.com/books/2023/jan/26/the-mysterious-case-of-the-alperton-angels-by-janice-hallett-review-on-the-trail-of-a-cult](https://www.theguardian.com/books/2023/jan/26/the-mysterious-case-of-the-alperton-angels-by-janice-hallett-review-on-the-trail-of-a-cult)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:00:06+00:00
 - user: None

<p>The author of The Appeal compiles a dossier of evidence with dramatic results in this dark tale of Satanic rituals </p><p>You have a key that opens a safe deposit box. Inside is a bundle of documents … You must read it and make a decision.” So begins <a href="https://www.theguardian.com/books/2021/nov/20/the-appeal-writer-janice-hallett-i-wrote-about-bubble-bath-for-15-years">Janice Hallett</a>’s third novel, The Mysterious Case of the Alperton Angels. As will be apparent to readers of her previous books, <a href="https://www.theguardian.com/books/2021/oct/28/cosy-and-greek-myth-retellings-the-waterstones-book-of-the-year-shortlist">The Appeal</a> and <a href="https://www.theguardian.com/books/2022/jan/14/the-best-recent-and-thrillers-review-roundup">The Twyford Code</a>, we are in familiar territory. Will this be a carefully curated dossier, involving multiple voices, some of them intriguingly unreliable? Will there be emails, text exchanges, news clippings, pages from screenplays? And, most importantly, will there be a dense mystery that will be satisfyingly solved by sheer authorial ingenuity in the last 50 pages? In that case, please toss another log on the fire.</p><p>The mystery concerns a long-ago triple suicide in a London cult, involving a leader self-styled as the Angel Gabriel. Amanda Bailey, a terrier-like true-crime author, is determined to dig up the truth as quickly as possible, because she’s on a deadline. Lying to people is second nature to Amanda (“No, I’m not recording this”), as is the naked exploitation of every acquaintance and contact. Enjoyably complicating Amanda’s sections is a second voice, that of her empathic assistant Ellie Cooper, who transcribes interviews and adds comments. In Ellie’s seemingly superfluous asides – which naturally repay attention – there are echoes of The Appeal’s wonderful central creation, the slippery Isabel Beck.</p> <a href="https://www.theguardian.com/books/2023/jan/26/the-mysterious-case-of-the-alperton-angels-by-janice-hallett-review-on-the-trail-of-a-cult">Continue reading...</a>

## ‘Prepare to be blown away – literally’: readers’ favourite trips in Ireland
 - [https://www.theguardian.com/travel/2023/jan/26/readers-favourite-trips-in-ireland-holidays-tips](https://www.theguardian.com/travel/2023/jan/26/readers-favourite-trips-in-ireland-holidays-tips)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 11:00:06+00:00
 - user: None

<p>Our tipsters confirm that the Emerald Isle’s pubs, cafes and literary hotspots offer brilliant backup for its huge variety of outdoor adventures. <strong>Scroll down to see the winner</strong></p><p>I was fortunate to spend a few days in the seaside village of Portnoo, which made a great jumping-off point for exploring the multitude of white sand beaches – many of which wouldn’t have looked out of place in southern Italy. <a href="https://www.donegaldayout.ie/dooey-beach">Dooey beach</a> was a particular highlight and, other than a few surfers, was all but empty during my visit. The challenging but rewarding <a href="https://www.thewildatlanticway.com/">Wild Atlantic Way</a> stretches along the coast and can be tackled in short stages. Proper pubs are abundant but <a href="https://www.nancysbarardara.com/">Nancy’s</a> in Ardara had the combination of excellent beers, food and craic.<br /><strong>Michael</strong></p> <a href="https://www.theguardian.com/travel/2023/jan/26/readers-favourite-trips-in-ireland-holidays-tips">Continue reading...</a>

## Man, 61, charged with assaulting Matt Hancock on tube
 - [https://www.theguardian.com/uk-news/2023/jan/26/man-61-charged-with-assaulting-matt-hancock-on-tube-london-underground](https://www.theguardian.com/uk-news/2023/jan/26/man-61-charged-with-assaulting-matt-hancock-on-tube-london-underground)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:29:34+00:00
 - user: None

<p>Geza Tarjanyi accused of attack on former health secretary and two public order offences, police say</p><p>A 61-year-old man has been charged with assaulting the former health secretary Matt Hancock on the London underground.</p><p>Geza Tarjanyi, from Leyland, Lancashire, will appear in court next month charged with common assault and two public order offences, British Transport Police said.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/man-61-charged-with-assaulting-matt-hancock-on-tube-london-underground">Continue reading...</a>

## NHS pay dispute could cause serious long-term harm, says health boss
 - [https://www.theguardian.com/society/2023/jan/26/nhs-pay-dispute-could-cause-serious-long-term-harm-says-health-boss](https://www.theguardian.com/society/2023/jan/26/nhs-pay-dispute-could-cause-serious-long-term-harm-says-health-boss)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:28:42+00:00
 - user: None

<p>Julian Hartley calls for speedy resolution as strikes hamper efforts to tackle A&amp;E delays and care backlog </p><ul><li><a href="https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest">UK politics live – latest news updates</a></li></ul><p>The NHS faces “serious and significant” long-term damage unless the increasingly bitter pay battle between staff and ministers is resolved soon, a senior health service boss has said.</p><p>The growing wave of strikes will hamper the NHS’s efforts to tackle the growing chaos in A&amp;E and the 7.2 million-strong backlog of people needing hospital treatment, Sir Julian Hartley said.</p> <a href="https://www.theguardian.com/society/2023/jan/26/nhs-pay-dispute-could-cause-serious-long-term-harm-says-health-boss">Continue reading...</a>

## Advising others on crucial life choices ‘immoral’ says Cambridge philosopher
 - [https://www.theguardian.com/world/2023/jan/26/advising-others-on-crucial-life-choices-immoral-says-cambridge-philosopher](https://www.theguardian.com/world/2023/jan/26/advising-others-on-crucial-life-choices-immoral-says-cambridge-philosopher)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:23:39+00:00
 - user: None

<p>Dr Farbod Akhlaghi argues that everyone has a right to ‘self authorship’, which is violated even by well-meaning advice</p><p>Giving friends and relations advice about crucial life choices such as whether to take a new job or start a family is immoral, according to a new paper by a Cambridge philosopher.</p><p>Dr Farbod Akhlaghi, a moral philosopher at Christ’s College, argues that everyone has a right to “self authorship”, so must make decisions about transformative experiences for themselves.</p> <a href="https://www.theguardian.com/world/2023/jan/26/advising-others-on-crucial-life-choices-immoral-says-cambridge-philosopher">Continue reading...</a>

## Sunak and cabinet head to Chequers as pressure grows on PM to sack Zahawi – UK politics live
 - [https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest](https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:22:30+00:00
 - user: None

<p>Latest updates: Lib Dems criticise Tory ‘hideaway day’ as ethics probe into Tory party chair’s tax affairs continues</p><p>Ukraine’s president, <strong>Volodymyr Zelenskiy,</strong> has said he has a “special bond” with <strong>Boris Johnson</strong> in an interview where he branded <strong>Vladimir Putin</strong> a “nobody” and suggested it was too late for face-to-face talks with the Russian leader.</p><p>Speaking to Sky News, Zelenskiy declined to say whether Johnson, who he described as “a good guy”, should get an official role representing the UK on Ukraine. Laughing, he said:</p><p>Who knows? With pleasure, with pleasure, really.</p><p>I think that is not correct for me to support Johnson to be prime minister. We have good relations with Sunak. I think we had more long relations with Johnson, because it was more long-time. I saw Johnson in different situations, I saw him not in war and then in full-scale war, that’s why we have special relations.</p> <a href="https://www.theguardian.com/politics/live/2023/jan/26/rishi-sunak-cabinet-chequers-nadhim-zahawi-conservatives-uk-politics-latest">Continue reading...</a>

## UK households will face more pain, says Bank’s former chief economist
 - [https://www.theguardian.com/business/2023/jan/26/more-pain-to-come-bank-of-england-andy-haldane](https://www.theguardian.com/business/2023/jan/26/more-pain-to-come-bank-of-england-andy-haldane)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:20:50+00:00
 - user: None

<p>Andy Haldane says starting mortgage rate rises sooner would have nipped inflation in the bud</p><p>The former chief economist of the Bank of England has warned there is “more pain to come” for households and the wider economy as mortgage rate increases hit people’s bank accounts and weigh on spending.</p><p>Andy Haldane, who is now chief executive of the Royal Society of Arts, said it was painful to see the effects of rising interest rates, after <a href="https://www.theguardian.com/business/2021/apr/13/andy-haldane-bank-of-england-royal-society-of-arts">leaving the Bank of England</a> and its rate-setting monetary policy committee in June 2021.</p> <a href="https://www.theguardian.com/business/2023/jan/26/more-pain-to-come-bank-of-england-andy-haldane">Continue reading...</a>

## Low-rise waistlines: the return of Y2K’s most debauched trend
 - [https://www.theguardian.com/fashion/2023/jan/26/low-rise-waistlines-the-return-of-y2ks-most-debauched-trend](https://www.theguardian.com/fashion/2023/jan/26/low-rise-waistlines-the-return-of-y2ks-most-debauched-trend)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:00:03+00:00
 - user: None

<p>Until now, the 00s revival seemed like harmless fun. Then stars including Dua Lipa and Julia Fox began wearing the era’s trickiest, most controversial look</p><p>Low-rise blue-denim jeans were to 00s nightlife what gladiators’ loincloths were to those at the Colosseum in ancient Rome. Two thousand years ago, half-naked young men were thrust into a public arena to do battle with lions for the entertainment of the watching masses. Fast-forward two millennia and it was Britney Spears, Paris Hilton and Lindsay Lohan being thrown to the wolves. Bronzed torso flesh was bared, this time between hip-bone-grazing waistbands and shrunken vests, as young women were pursued by paparazzi baying for blood – or, at least, for a photo of a “whale tail” thong protruding from those bootcut jeans with their three-inch fly.</p><p>Sorry if the analogy sounds a little hysterical, but the return of the low-rise jean is ringing alarm bells. Until now, the Y2K revival has seemed like harmless fun: scrunchies, ballet pumps, Uggs. So far, so cute. But low-rise jeans? Well, that’s different.</p> <a href="https://www.theguardian.com/fashion/2023/jan/26/low-rise-waistlines-the-return-of-y2ks-most-debauched-trend">Continue reading...</a>

## My dad died five years ago. I’ve learned it’s better to talk about death imperfectly than not at all | Owen Jones
 - [https://www.theguardian.com/commentisfree/2023/jan/26/dad-died-talk-death-silent-loss-taboo](https://www.theguardian.com/commentisfree/2023/jan/26/dad-died-talk-death-silent-loss-taboo)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:00:03+00:00
 - user: None

<p>I didn’t have a proper vocabulary to talk about loss, but discovered that breaking the taboo was vital for healing</p><p></p><p>Did my father know that his death was imminent? After he was wheeled back to my parents’ flat in Edinburgh for his last Christmas five years ago, delusion seemed to prevail. He was getting better, he reassured me; then aged 72, he insisted would make it to his 80s. But his eyes seemed to suggest otherwise: there was something about how they welled up as I blared <a href="https://www.classical-music.com/features/works/a-guide-to-nimrod-from-elgars-enigma-variations/">Edward Elgar’s Nimrod</a> from the living room speakers. He loved that variation. My mother hasn’t been able to listen to it since, because it’s one of those emotional landmines that grief lays after a bereavement. Why stand on it, if you have the choice?</p><p>Just over two weeks later, he was dead, but he wouldn’t have felt disappointment in that moment of finality. Sometimes I wonder if he could hear his family in that hospice, whispering their love, or the baritone notes of the Bruce Springsteen songs we played. Before he fell ill, he used to loop around his armchair, clicking his fingers and roaring out the chorus as he listened to the Boss. His eyes seemed to moisten in those final moments, too. But was this a silent emotional response to his family wishing him farewell, or just another symptom of a human body shutting down for good?</p><p>Owen Jones is a Guardian columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/dad-died-talk-death-silent-loss-taboo">Continue reading...</a>

## Biden claims ‘no regrets’ but classified papers case could come back to bite him
 - [https://www.theguardian.com/us-news/2023/jan/26/joe-biden-classified-documents-democrat-response-2024](https://www.theguardian.com/us-news/2023/jan/26/joe-biden-classified-documents-democrat-response-2024)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:00:02+00:00
 - user: None

<p>While there are major differences between the president and Trump’s cases,  the controversy arrives at a delicate time for Biden</p><p>At the invitation of Joe Biden’s legal team, federal investigators carried out an extraordinary 13-hour search of the president’s Delaware residence, scouring every room of the house from the bedrooms to the bathrooms. </p><p>It was a remarkable gesture meant to demonstrate the president’s full cooperation with the investigation. But it also led to the discovery of half a dozen items with classified markings, the latest in a series of findings that have put Biden and his presidency on the defensive as he prepares to seek a second term.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/joe-biden-classified-documents-democrat-response-2024">Continue reading...</a>

## Eccentric names the norm in Brazil but ‘Samba’ rejected as too outlandish
 - [https://www.theguardian.com/world/2023/jan/26/brazil-names-samba-seu-jorge](https://www.theguardian.com/world/2023/jan/26/brazil-names-samba-seu-jorge)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 10:00:02+00:00
 - user: None

<p>São Paulo registry office snubs music star Seu Jorge’s choice for newborn son, despite far more unusual names being accepted </p><p>As the country that produced footballers called Sócrates Brasileiro Sampaio de Souza Vieira de Oliveira and Élvis Vieira Araújo, Brazil is no stranger to unconventional – albeit familiar-sounding – names.</p><p><a href="https://twitter.com/tomphillipsin/status/1615745164344950785?s=20&amp;t=k3bALoSbEgx-uWbCVQl0mQ">A scan of the names</a> of the far-right vandals who were arrested for storming government buildings in Brasília earlier this month confirms the Brazilian penchant for <a href="https://www.theguardian.com/world/2015/may/07/richard-nixon-arrested-elvis-lives-why-brazilians-insist-on-a-name-less-ordinary">eye-catching monikers.</a> <a href="https://seape.df.gov.br/wp-content/uploads/2023/01/LISTA-FINAL-1398-PRESOS-Copia.pdf">The list</a> throws up a Bach and a Mozart, as well as a Ditter Marx and creative twists on more conventional first names, such as Marileide (Mary Lady), Rosemeire (Rosemary), and Dawydy (David).</p> <a href="https://www.theguardian.com/world/2023/jan/26/brazil-names-samba-seu-jorge">Continue reading...</a>

## England’s coast faces ‘multiple threats’ of dredging, sewage and pollution
 - [https://www.theguardian.com/environment/2023/jan/26/englands-coast-faces-multiple-threats-of-dredging-sewage-and-pollution](https://www.theguardian.com/environment/2023/jan/26/englands-coast-faces-multiple-threats-of-dredging-sewage-and-pollution)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:47:01+00:00
 - user: None

<p>Environment Agency paints bleak picture of  coastal regions with eco-systems and people coming under increased pressure</p><p>Dredging is likely to increase around the English coast, while pollution and sewage are piling pressure on coastal eco-systems, and an increasing number of people are at risk of coastal flooding, the Environment Agency has warned.</p><p>Three quarters of shellfish waters around England failed to meet “aspirational” standards for environmental protection in 2021, the <a href="https://www.gov.uk/government/organisations/environment-agency">report by the agency’s chief scientist’s group found</a>.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/englands-coast-faces-multiple-threats-of-dredging-sewage-and-pollution">Continue reading...</a>

## Best podcasts of the week: The adult actress who became the unwitting face of a thousand catfishing scams
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/hear-here-love-janessa-podcast](https://www.theguardian.com/tv-and-radio/2023/jan/26/hear-here-love-janessa-podcast)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:46:15+00:00
 - user: None

<p>In this week’s newsletter: Janessa Brazil’s pictures were used to entrap victims, costing them millions – find out how in Love, Janessa. Plus: five of the best podcasts for film fans</p><ul><li><strong><a href="https://www.theguardian.com/info/2017/may/10/hear-here-podcast-recommendations-sign-up-for-unexpected-audio-pleasures">Don’t get Hear Here delivered to your inbox? Sign up for the full article here</a></strong></li></ul><p><strong><a href="https://www.bbc.co.uk/sounds/brand/m001hf1w">Buried</a><br />BBC Sounds, all episodes out now<br /></strong>Dan Ashby and Lucy Taylor’s 10-part investigation into the scandal surrounding UK waste disposal is explosively revelatory. It features deathbed confessions, gangs, an illegal Northern Irish site harbouring 1m tonnes of dumped recycling and the news that a fifth of all UK waste is handled by criminals. A shocking listen that’s a must for anyone who cares about our planet – not bad given episodes are only 15 minutes long. <em>Alexi Duggins</em></p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/hear-here-love-janessa-podcast">Continue reading...</a>

## Palestinians say nine killed in Israeli raid on Jenin refugee camp
 - [https://www.theguardian.com/world/2023/jan/26/palestinians-say-nine-killed-in-israeli-raid-on-jenin-refugee-camp](https://www.theguardian.com/world/2023/jan/26/palestinians-say-nine-killed-in-israeli-raid-on-jenin-refugee-camp)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:43:58+00:00
 - user: None

<p>Officials also accuse Israeli forces of using teargas inside children’s ward of a hospital in West Bank</p><p>An Israeli raid on the Jenin refugee camp in the occupied West Bank killed nine Palestinians including an elderly woman, Palestinian officials have said. They also accused the forces of using teargas inside a hospital’s children’s ward.</p><p>The health ministry said that in addition to the nine dead, multiple people were wounded.</p> <a href="https://www.theguardian.com/world/2023/jan/26/palestinians-say-nine-killed-in-israeli-raid-on-jenin-refugee-camp">Continue reading...</a>

## Protesters gather across Melbourne and Sydney for Invasion Day rallies – video
 - [https://www.theguardian.com/australia-news/video/2023/jan/26/protesters-gather-across-melbourne-and-sydney-for-invasion-day-rallies-video](https://www.theguardian.com/australia-news/video/2023/jan/26/protesters-gather-across-melbourne-and-sydney-for-invasion-day-rallies-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:40:41+00:00
 - user: None

<p>Thousands of people attended Invasion Day rallies where First Nations speakers called for action on deaths in custody and an end to the removal of Aboriginal children. The rallies were dominated by speeches on the <a href="https://www.theguardian.com/australia-news/indigenous-voice-to-parliament">Indigenous voice to parliament</a>, with attenders saying the strong opposition expressed by organisers will shape how they vote in the referendum slated for later this year</p><ul><li><a href="https://www.theguardian.com/australia-news/commentisfree/2023/jan/25/the-day-of-mourning-in-1938-set-out-a-peaceful-beautiful-message-the-voice-is-a-legacy-of-that-unfinished-business">'The Day of Mourning in 1938 set out a peaceful, beautiful message. The voice is a legacy of that unfinished business'</a></li><li><a href="https://www.theguardian.com/australia-news/gallery/2023/jan/26/invasion-day-protests-around-australia-in-pictures">Invasion Day protests around Australia – in pictures</a></li><li><a href="https://www.theguardian.com/australia-news/audio/2023/jan/26/wesley-enoch-on-australias-day-of-mourning">Wesley Enoch on Australia’s Day of Mourning – podcast</a></li></ul> <a href="https://www.theguardian.com/australia-news/video/2023/jan/26/protesters-gather-across-melbourne-and-sydney-for-invasion-day-rallies-video">Continue reading...</a>

## Why rivers shouldn't look like this – video
 - [https://www.theguardian.com/environment/video/2023/jan/26/why-rivers-shouldnt-look-like-this-video](https://www.theguardian.com/environment/video/2023/jan/26/why-rivers-shouldnt-look-like-this-video)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:33:12+00:00
 - user: None

<p>The quintessential image of a river you might recognise from post cards and paintings – nice and straight with a tidy riverbank – is not actually how it is supposed to look. It's the result of centuries of industrial and agricultural development. And it's become a problem, exacerbating the impact of both extreme flooding and extreme drought. Josh Toussaint-Strauss looks into how so many rivers ended up this way, and how river restoration is helping to reestablish biodiversity and combat some of the effects of the climate crisis</p><p><a href="https://www.theguardian.com/environment/2022/sep/20/dutch-rewilding-project-turns-back-the-clock-500-years-aoe">‘This is what a river should look like’: Dutch rewilding project turns back the clock 500 years</a></p><p><a href="https://www.theguardian.com/environment/2022/jun/21/pioneering-dutch-rewilding-project-oostvaardersplassen-works-to-rebuild-controversial-reputation-aoe">‘We make nature here’: pioneering Dutch project repairs image after outcry over starving animals</a></p> <a href="https://www.theguardian.com/environment/video/2023/jan/26/why-rivers-shouldnt-look-like-this-video">Continue reading...</a>

## Can video games change people’s minds about the climate crisis?
 - [https://www.theguardian.com/games/2023/jan/26/can-video-games-change-peoples-minds-about-the-climate-crisis](https://www.theguardian.com/games/2023/jan/26/can-video-games-change-peoples-minds-about-the-climate-crisis)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:30:01+00:00
 - user: None

<p>A new wave of game makers are attempting to influence a generation of environmentally conscious players. Will it work, and is it enough?</p><p>“It was scary. It made you realise how, despite all the sophistication of modern society, we’re still reliant on water falling from the sky.” Sam Alfred, the lead designer at Cape Town-based video game studio <a href="https://freelives.net/games/">Free Lives</a>, vividly remembers his city nearly running out of water. During 2018, the area surrounding South Africa’s second largest city suffered months of dwindling rainfall. Dams were unable to replenish themselves at the rate its inhabitants required. Water was rationed. Businesses shut. The situation even called for its own grim version of the Doomsday Clock: hour by hour, the city ticked ever closer to <a href="https://www.theguardian.com/cities/ng-interactive/2018/feb/03/day-zero-how-cape-town-running-out-water">Day Zero</a>, marking the end of its fresh water supply.</p><p><a href="https://store.steampowered.com/app/1593030/Terra_Nil/">Terra Nil</a>, the video game that Alfred has been developing since 2019, is a response to these terrifying events. Dubbed a “city-builder in reverse”, it foregoes the consumption and expansion of genre classics such as Civilisation and SimCity to paint a picture of environmental restoration. Starting with arid desert, it’s up to the player to rewild a landscape using various technologies – a toxin scrubber, for example, or a beehive. At light-speed, and with eye-massaging flushes of emerald green and azure blue, the environment transforms into lush vegetation. Terra Nil’s simplicity is as beautiful as its visuals, offering the satisfaction of a colouring book while doling out a clear-eyed critique of environment-wrecking extraction.</p> <a href="https://www.theguardian.com/games/2023/jan/26/can-video-games-change-peoples-minds-about-the-climate-crisis">Continue reading...</a>

## Good early years teaching may boost earnings of children in England – study
 - [https://www.theguardian.com/education/2023/jan/26/good-early-years-teaching-may-boost-earnings-of-children-in-england-study](https://www.theguardian.com/education/2023/jan/26/good-early-years-teaching-may-boost-earnings-of-children-in-england-study)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:30:01+00:00
 - user: None

<p>Study reports one in 40 primary schools in England produce entire classes likely to earn more than their peers</p><p>Never mind getting a place at Oxbridge – a child’s future earnings can be significantly improved by the quality of their teachers at the age of four, according to new research.</p><p>The researchers used Department for Education (DfE) databases to connect adults’ earnings to the reception classes attended. The results highlight the outsized influence of early years’ education, finding that one in 40 primary schools in England produce entire classes likely to gain more money than their peers.</p> <a href="https://www.theguardian.com/education/2023/jan/26/good-early-years-teaching-may-boost-earnings-of-children-in-england-study">Continue reading...</a>

## Duncan Ferguson poised to take manager’s job at Forest Green
 - [https://www.theguardian.com/football/2023/jan/26/duncan-ferguson-forest-green-manager-job](https://www.theguardian.com/football/2023/jan/26/duncan-ferguson-forest-green-manager-job)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:29:48+00:00
 - user: None

<ul><li>Former Everton assistant and caretaker holds positive talks</li><li>Forest Green are bottom of League One after promotion</li></ul><p>Duncan Ferguson is set to become the manager of the League One strugglers Forest Green Rovers.</p><p>The former Everton assistant manager was approached on Wednesday after the sacking of Ian Burchnall, and positive talks have been held. Forest Green sit bottom of League One, four points from safety, having taken 21 points from their opening 28 matches after promotion.</p> <a href="https://www.theguardian.com/football/2023/jan/26/duncan-ferguson-forest-green-manager-job">Continue reading...</a>

## Coal power stations warmed up for third time this week as UK cold snap persists
 - [https://www.theguardian.com/business/2023/jan/26/national-grid-coal-power-stations-standby-cold-edf](https://www.theguardian.com/business/2023/jan/26/national-grid-coal-power-stations-standby-cold-edf)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:27:26+00:00
 - user: None

<p>National Grid put Drax and EDF’s West Burton generator on standby, with the latter stood down at 5am</p><p>National Grid asked coal-fired power stations to warm up on Thursday for the third time this week in case they are needed as cold weather across the UK continues.</p><p>Two units at Drax in Yorkshire and one at West Burton in Nottinghamshire were asked to fire up just before midnight on Wednesday. The West Burton unit was stood down at 5:13am, but the Drax units have continued to heat up, according to notifications sent to the industry.</p> <a href="https://www.theguardian.com/business/2023/jan/26/national-grid-coal-power-stations-standby-cold-edf">Continue reading...</a>

## UK ban on laughing gas sale or possession poised to go ahead
 - [https://www.theguardian.com/society/2023/jan/26/uk-ban-on-laughing-gas-sale-or-possession-poised-to-go-ahead](https://www.theguardian.com/society/2023/jan/26/uk-ban-on-laughing-gas-sale-or-possession-poised-to-go-ahead)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:20:22+00:00
 - user: None

<p>Suella Braverman pushing plan to change law on nitrous oxide as part of crackdown on antisocial behaviour</p><p>The Home Office is preparing to introduce a long-mooted ban on the sale or possession of nitrous oxide, one of the most popular recreational drugs among young people, as part of a wider crackdown on antisocial behaviour.</p><p>The plan is being pushed by the home secretary, Suella Braverman, according to officials, and would lead to people found with laughing gas, which is usually inhaled from balloons filled via small metal cylinders, facing prosecution.</p> <a href="https://www.theguardian.com/society/2023/jan/26/uk-ban-on-laughing-gas-sale-or-possession-poised-to-go-ahead">Continue reading...</a>

## Bible study and work without pay: the shadowy world of sober living homes
 - [https://www.theguardian.com/us-news/2023/jan/26/sober-living-homes-unregulated-montana](https://www.theguardian.com/us-news/2023/jan/26/sober-living-homes-unregulated-montana)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:00:00+00:00
 - user: None

<p>In a largely unregulated industry, some residents trying to get sober are made to work 40 hours a week at restaurants – but don’t receive a paycheck</p><p><em>This article was first published in <a href="https://montanafreepress.org/2023/01/03/the-unregulated-world-of-montanas-sober-living-recovery-homes/">Montana Free Press</a></em></p><p></p><p>Kaitlyn, 32, applied for a spot at Hope Center Ministries near the end of 2021 because it seemed like her best option at the time. She had pleaded guilty in February to one count of criminal endangerment related to reckless driving and, after being released, violated her probation by reportedly failing to show up for check-ins and possessing drug paraphernalia.</p><p>Court records say she had told her probation officer she’d been using methamphetamine, even as she denied having a problem with drugs or alcohol. The women’s sober living home, her attorney advised, would help her get out of jail and give her a structured environment to recover from substance use.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/sober-living-homes-unregulated-montana">Continue reading...</a>

## Deep Fake Neighbour Wars review – the puerile joy of Idris Elba fighting Kim Kardashian over a wheelbarrow
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/deep-fake-neighbour-wars-review](https://www.theguardian.com/tv-and-radio/2023/jan/26/deep-fake-neighbour-wars-review)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:00:00+00:00
 - user: None

<p>From Phoebe Waller-Bridge nicking Rihanna’s pants to Jay-Z having it out with Tom Hiddleston, this silly comedy uses tech to put A-list celebs in humdrum situations. But is it OK?</p><p>Catford, south-east London. Idris Elba – handyman, barman, mobile phone repairer, chef, delivery driver and DJ – is having a run-in with new neighbour Kim Kardashian over the communal garden. It’s Idris’s pride and joy, where he tends his brassicas and makes perfume out of rose petals and water that he sells on Etsy. First, he finds towels hanging off his pergola. Two days later, a paddling pool. Then one of those rotary washing lines with a squeak “that went right through me”, says Idris with a shudder. As for bus driver Kim, having a garden to call her own is “a huge blessing” and she refuses to stop sunbathing in it. Let the neighbour wars begin!</p><p>This is a reality TV spoof with a difference: the first deepfake comedy to grace our screens. So not only do you see a person who sounds and acts exactly like Kardashian griping about the garden hose, wheelbarrow and Flymo Elba has placed on her path to block access to the garden (“Once, I had to jump eight things,” she wails. “Do I look like a hurdlist?”), she looks exactly like her, too. Welcome to Deep Fake Neighbour Wars (ITVX), where thanks to some ethically questionable and up-to-the-minute AI technology I don’t fully understand, we can now indulge in such puerile pleasures as watching Harry Kane have his patio tile cracked by Stormzy. Or Olivia Colman and monosyllabic hubby Jay-Z arguing with Tom Hiddleston (an estate agent, obvs) over his renaming of their cat Giovani. Or Usain Bolt and new wife Phoebe Waller-Bridge-Bolt nicking neighbour Rihanna’s pants. Or Greta Thunberg losing it on the local Facebook community page over a year-round Christmas garden display by Conor McGregor and Ariana Grande. Ha ha … but is it OK? Only, perhaps, because it’s so silly.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/deep-fake-neighbour-wars-review">Continue reading...</a>

## Living for Pleasure by Emily A Austin – an Epicurean guide to happiness
 - [https://www.theguardian.com/books/2023/jan/26/living-for-pleasure-by-emily-a-austin-an-epicurean-guide-to-happiness](https://www.theguardian.com/books/2023/jan/26/living-for-pleasure-by-emily-a-austin-an-epicurean-guide-to-happiness)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 09:00:00+00:00
 - user: None

<p>A timely guide to the Greek philosopher – and rival to the Stoics – who saw freedom from anxiety as the ultimate goal</p><p>No one today would dream of practising the physics, medicine or biology of the ancient Greeks. But their thoughts on how to live remain perennially inspiring. <a href="https://www.theguardian.com/books/plato">Plato</a>, Aristotle and the Stoics have all had their 21st-century evangelists. Now it is Epicurus’s turn, and his advocate is American philosopher Emily A Austin.</p><p>Living for Pleasure is likely to evoke feelings of deja vu. One reason why “ancient wisdom” is so enduring is that most thinkers came to very similar conclusions on certain key points. Do not be seduced by the shallow temptations of wealth or glory. Pursue what is of real value to you, not what society tells you is most important. Be the sovereign of your desires, not a slave to them. Do not be scared of death, since only the superstitious fear divine punishment.</p> <a href="https://www.theguardian.com/books/2023/jan/26/living-for-pleasure-by-emily-a-austin-an-epicurean-guide-to-happiness">Continue reading...</a>

## Former Bank of England chief economist warns of ‘more pain to come’ in rising mortgage costs and falling real wages – business live
 - [https://www.theguardian.com/business/live/2023/jan/26/former-bank-england-chief-economist-warns-more-pain-come-rising-mortgage-costs-falling-real-wages-business-live](https://www.theguardian.com/business/live/2023/jan/26/former-bank-england-chief-economist-warns-more-pain-come-rising-mortgage-costs-falling-real-wages-business-live)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:23:31+00:00
 - user: None

<p>Andy Haldane says political chaos is contributing to poor economic performance and the UK lacks a medium-term plan for growth</p><p>The <strong>National Grid</strong> has asked coal plants to warm up in case they are needed on Thursday, amid continued cold weather across the UK.</p><p>Two coal units at Drax in Yorkshire and one at West Burton in Nottinghamshire were asked to fire up just before midnight on Wednesday. The West Burton unit was stood down at 5:13am, but the Drax units have continued to heat up, according to notifications sent to the industry.</p> <a href="https://www.theguardian.com/business/live/2023/jan/26/former-bank-england-chief-economist-warns-more-pain-come-rising-mortgage-costs-falling-real-wages-business-live">Continue reading...</a>

## Australian Open 2023 semi-finals: Rybakina v Azarenka, Linette v Sabalenka – live
 - [https://www.theguardian.com/sport/live/2023/jan/26/tennis-australian-open-2023-womens-semi-finals-elena-rybakina-v-victoria-azarenka-magda-linette-v-aryna-sabalenka-live](https://www.theguardian.com/sport/live/2023/jan/26/tennis-australian-open-2023-womens-semi-finals-elena-rybakina-v-victoria-azarenka-magda-linette-v-aryna-sabalenka-live)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:21:11+00:00
 - user: None

<ul><li>Live updates from women’s semi-finals at Melbourne Park</li><li>Any comments? You can <a href="mailto:Luke.McLaughlin.Casual@theguardian.com">email Luke</a> or <a href="https://twitter.com/LukeMcLaughlin">tweet Luke</a></li></ul><p><strong>You know what time it is.</strong></p><p>“<strong>Since like 14 years old</strong> the coaches have been telling us ‘we need new Americans, we need new Americans’. It’s kind of engraved in my head. It’s important to me. I think we all want it pretty bad for ourselves, but we want it for US tennis too.”</p> <a href="https://www.theguardian.com/sport/live/2023/jan/26/tennis-australian-open-2023-womens-semi-finals-elena-rybakina-v-victoria-azarenka-magda-linette-v-aryna-sabalenka-live">Continue reading...</a>

## Jets, Dolphins or back to the Ravens: where will Lamar Jackson end up in 2023?
 - [https://www.theguardian.com/sport/2023/jan/26/lamar-jackson-baltimore-ravens-contract-interested-teams-nfl-football](https://www.theguardian.com/sport/2023/jan/26/lamar-jackson-baltimore-ravens-contract-interested-teams-nfl-football)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:10:53+00:00
 - user: None

<p>The 2019 MVP’s future is still up in the air. Will he stay put or head to a team desperate for a quarterback of his extravagant talent?</p><p>With apologies to Tom Brady’s <a href="https://www.theguardian.com/sport/2023/jan/18/tom-brady-next-team-nfl-football-tampa-jets-raiders-patriots">impending free agency/retirement</a>, Lamar Jackson’s standoff with the Baltimore Ravens lingers as the most intriguing storyline of the offseason.</p><p>Jackson is a perennial MVP candidate, the closest thing the league has to a one-man offense. He’s only just turned 26. But he also plays a distinctive, collision-based style, and his last two seasons have ended with injuries. His <em>current </em>style has a shelf life – and there are questions about whether he can evolve as he ages or how that evolution affects his value.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/lamar-jackson-baltimore-ravens-contract-interested-teams-nfl-football">Continue reading...</a>

## A stitch in time: the enduring influence of the Gee’s Bend quilters
 - [https://www.theguardian.com/artanddesign/2023/jan/26/the-new-bend-gees-bend-quilters](https://www.theguardian.com/artanddesign/2023/jan/26/the-new-bend-gees-bend-quilters)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:00:54+00:00
 - user: None

<p>A new exhibition celebrates the remarkable legacy of the master makers from a tiny Alabama hamlet who found worldwide fame two decades ago </p><p>Anyone who thought abstract art was a club of white, male “lone geniuses” got an unexpected wake-up call in 2002, when quilts from the Alabama hamlet of <a href="https://www.theguardian.com/artanddesign/2019/dec/02/american-quilts-gees-bend-miraculous-art-turner-contemporary-margate?page=with%3Aimg-2">Gee’s Bend</a> first toured US museums. The quilts’ luscious hues, scissored shapes and improvised visual rhythms garnered comparisons to <a href="https://www.theguardian.com/artanddesign/klee">Paul Klee</a> and <a href="https://www.theguardian.com/artanddesign/2014/apr/14/henri-matisse-cut-outs-tate-modern-review">Henri Matisse</a>. Their creators were an intergenerational community of African American women who, to this day, work in the tiny conurbation that was once a slave-owner’s plantation.</p><p>For Legacy Russell, an American feminist theorist and curator, the quilters’ impact has only grown in the two decades since that stunning museum tour. The New Bend, the travelling exhibition she has curated, <a href="https://www.theguardian.com/artanddesign/2020/dec/02/equals-klee-matisse-alabama-quilt-makers-shook-america">explores the legacy</a> of the Gee’s Bend quilters and the artists still working in their lineage, bringing together a 13-strong lineup of radical textile artists.</p> <a href="https://www.theguardian.com/artanddesign/2023/jan/26/the-new-bend-gees-bend-quilters">Continue reading...</a>

## Biden’s clean energy brainwave paves Britain’s way to post-Brexit growth. Dare we copy him? | Larry Elliott
 - [https://www.theguardian.com/commentisfree/2023/jan/26/joe-biden-clean-energy-britain-brexit-growth-us-eu-uk](https://www.theguardian.com/commentisfree/2023/jan/26/joe-biden-clean-energy-britain-brexit-growth-us-eu-uk)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:00:53+00:00
 - user: None

<p>Where the US leads in using state aid and subsidies, the EU is now following. But the UK will need a change of mindset</p><p>Stagnation nation. That’s an apt two-word description of the UK, where after 15 years of sluggish economic performance the prospect is for a shallow recession this year.</p><p>Politicians know they have a problem. In the past 13 years, David Cameron, Theresa May, Boris Johnson, Liz Truss and now Rishi Sunak have all proposed different ways of fixing things, none of which have moved the dial that much. Jeremy Hunt says his budget, on 15 March will be all about growth, but don’t hold your breath.</p><p>Larry Elliott is the Guardian’s economics editor</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/joe-biden-clean-energy-britain-brexit-growth-us-eu-uk">Continue reading...</a>

## Rainford-Brent and Ace making progress while cricket awaits damning report | Andy Bull
 - [https://www.theguardian.com/sport/2023/jan/26/rainford-brent-ace-progress-cricket-racism-report](https://www.theguardian.com/sport/2023/jan/26/rainford-brent-ace-progress-cricket-racism-report)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:00:53+00:00
 - user: None

<p>Report should lift the lid on discrimination in the game but a programme is already addressing some of the sport’s issues</p><p>There’s an iceberg looming over English cricket, and some day soon the sport is going to run slap-bang into it. The independent commission (ICEC) set up in 2021 is due to publish its report on Equity in Cricket “early in 2023”. The chair, Cindy Butts, has already said that they had a “staggering” response to their call for evidence about discrimination in the game, and, behind the scenes, the England and Wales Cricket Board, which has already lost three major sponsors, is bracing itself for the fallout, which <a href="https://www.thecricketer.com/Topics/cricket-racism-crisis/ecb_apology_acknowledge_change_needed_icec_report.html">it expects will involve</a> an “intense degree of public scrutiny” and “a high degree of government criticism”.</p><p>You can get a taste of exactly how bad it is going to be from a <a href="https://www.bristolcore.co.uk/news/core-reports-findings-on-racism-in-cricket-to-the-national-independent-commission-on-equity-in-cricket-icec">document published by Bristol’s Mayoral Commission on Race Equality</a> (Core), which was submitted as evidence to the ICEC. It includes allegations of “constant abuse and racism” aimed at two minority clubs and states that when it was reported “nothing was done” except that the players were “threatened by officials” for speaking out. It describes a culture in which minority-background players have “a palpable sense of unfairness and injustice” and a pervading belief that “non-white clubs are treated differently”.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/rainford-brent-ace-progress-cricket-racism-report">Continue reading...</a>

## UK climate minister received donations from fuel and aviation companies
 - [https://www.theguardian.com/politics/2023/jan/26/uk-climate-minister-received-donations-fuel-aviation-companies](https://www.theguardian.com/politics/2023/jan/26/uk-climate-minister-received-donations-fuel-aviation-companies)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:00:53+00:00
 - user: None

<p>Exclusive: Graham Stuart received £12,000 towards campaign from fuel distributor and aviation consultant</p><p>The UK climate minister – who recently stated not all fossil fuels were the “spawn of the devil” – received campaign donations from one of the largest fuel distributors in the UK as well as an aviation consultant and recruiter, it has emerged.</p><p>Graham Stuart, Conservative MP for Beverley and Holderness, was appointed climate minister by Rishi Sunak in September. He has responsibility for net zero strategy and low carbon generation, and is the Commons lead for clean heat.</p> <a href="https://www.theguardian.com/politics/2023/jan/26/uk-climate-minister-received-donations-fuel-aviation-companies">Continue reading...</a>

## Will Still: ‘I’m managing a Ligue 1 club at 30 and could not be happier’
 - [https://www.theguardian.com/football/2023/jan/26/will-still-managing-ligue-1-club-30-couldnt-be-happier-neymar-mbappe](https://www.theguardian.com/football/2023/jan/26/will-still-managing-ligue-1-club-30-couldnt-be-happier-neymar-mbappe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 08:00:52+00:00
 - user: None

<p>I never thought I’d be in charge of a team against Neymar and Kylian Mbappé at this age. Life can be crazy</p><p>By <a href="https://www.coachesvoice.com/">The Coaches’ Voice</a> for the <a href="https://www.theguardian.com/sport/series/guardian-sport-network">Guardian Sport Network</a></p><p>At basically any point in my life, if someone had told me I’d be the head coach of a Ligue 1 side at 30, I’d have told them to punch me in the face. It would have been a totally ridiculous suggestion. The idea that, at 30, I’d be managing a team against Neymar, Kylian Mbappé, Sergio Ramos and Marco Verratti, and in the opposition dugout to Christophe Galtier, was equally mad.</p><p>Life can be crazy, though. I’ve never set any boundaries or limits on what I might achieve, but I’ve also never set any specific goals. When I went into coaching, I didn’t set out to make it to the top tier in France by a specific age. Not at all. I’m just not like that as a person. The key thing for me is just to enjoy what I’m doing now.</p> <a href="https://www.theguardian.com/football/2023/jan/26/will-still-managing-ligue-1-club-30-couldnt-be-happier-neymar-mbappe">Continue reading...</a>

## The World and All That It Holds by Aleksandar Hemon review – an engrossing epic
 - [https://www.theguardian.com/books/2023/jan/26/the-world-and-all-that-it-holds-by-aleksandar-hemon-review-an-engrossing-epic](https://www.theguardian.com/books/2023/jan/26/the-world-and-all-that-it-holds-by-aleksandar-hemon-review-an-engrossing-epic)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:30:52+00:00
 - user: None

<p>Opening in Sarajevo as the first world war is triggered, this magnificent globe‑trotting, century-spanning novel mingles fact with the fabulous</p><p>Aleksandar Hemon’s new novel is immense. Not because it is inordinately long – it isn’t – but because it contains almost as much as its title promises: journeys that take years, and lives that span continents; falling empires and storied cities; so many wars they blur and merge in the characters’ memories; indelible loves, unbearable losses; dreams and songs and megalomaniac delusions; witty allusions, rude jokes. By turns lyrical and sardonic, it is as emotionally compelling as it is clever. I’ll be surprised if I enjoy a novel more this year.</p><p>It begins in <a href="https://www.theguardian.com/world/from-the-archive-blog/2018/jul/13/siege-of-sarajevo-ian-traynor-maggie-okane-1993">Sarajevo</a>. Hemon, a Bosnian now living in the US, has written in several genres about the 1990s siege of that city. This book, though, takes us back to 1914, when it was the setting for the assassination that triggered the first world war. Our witness is Rafael Pinto: Sephardic-Jewish, Vienna-educated, pharmacist, homosexual, opium-user. As Archduke Franz Ferdinand and his wife drive into town, Pinto is in his shop, planting a kiss on the moustachioed lips of an Austrian <em>Rittmeister</em>. It’s an audacious act, but this is Sarajevo, a polyglot, multifaith city, and unorthodox conjunctions are worth daring. Until “the Holy One” – the being who “repeatedly creates worlds and destroys them” – puts an end to the world in which Pinto grew up and sends him off on foot all the way across the Eurasian landmass, eventually bringing him, 35 years later, to Shanghai, and to a plangent <em>Liebestod</em>.</p> <a href="https://www.theguardian.com/books/2023/jan/26/the-world-and-all-that-it-holds-by-aleksandar-hemon-review-an-engrossing-epic">Continue reading...</a>

## Azerbaijan sues Armenia for wartime environmental damage
 - [https://www.theguardian.com/environment/2023/jan/26/azerbaijan-sues-armenia-for-wartime-environmental-damage-bern-convention-biodiversity-aoe](https://www.theguardian.com/environment/2023/jan/26/azerbaijan-sues-armenia-for-wartime-environmental-damage-bern-convention-biodiversity-aoe)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:15:52+00:00
 - user: None

<p>Case brought under Bern convention on nature may set precedent for destruction of biodiversity in war</p><p>Azerbaijan has launched a landmark legal challenge against Armenia for allegedly destroying its environment and biodiversity during nearly three decades of occupation of the <a href="https://www.theguardian.com/artanddesign/2020/oct/13/trench-warfare-drones-and-cowering-civilians-on-the-ground-in-nagorno-karabakh">disputed Nagorno-Karabakh</a> region.</p><p>An international tribunal will consider evidence of widespread environmental destruction during the conflict between the two nations, including deforestation and pollution, and will be asked to order Armenia to pay reparations.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/azerbaijan-sues-armenia-for-wartime-environmental-damage-bern-convention-biodiversity-aoe">Continue reading...</a>

## A Bavarian fairytale: hiking, frosty peaks and an ivory castle
 - [https://www.theguardian.com/travel/2023/jan/26/bavaria-walking-holiday-hiking-germany-south](https://www.theguardian.com/travel/2023/jan/26/bavaria-walking-holiday-hiking-germany-south)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:53+00:00
 - user: None

<p>The tale of a starry-eyed monarch’s fantasy fortress provides the backdrop to a dazzling walking holiday in Germany’s far south</p><p>In a clearing at the foot of the Bavarian Alps, a stoat breaks cover. The little creature flows quickly across the grass, its eyes set ahead, the ice white of its fur broken only by the black tip of its tail. The dazzle of its winter coat provides zero camouflage on this cold, mid-January morning – all the snow is further up the slopes – but its button nose and exquisite colouring are a vision all the same, a cartoon come to life in <a href="https://www.theguardian.com/travel/germany">Germany</a>’s far south.</p><p>The stoat isn’t the only thing to have fallen from a Disney animation. Minutes away, set against a frost-dusted cragscape of dark peaks, a hilltop palace spears into the sky. It is spectacular and preposterous, an ivory fortress that seems to have been formed in a dream. Turrets zoom up towards the clouds, asymmetric balconies gaze out across the land, statues of knights stand on pinnacles. This is Neuschwanstein Castle – the most flamboyant of many such creations here in the hills – and the story behind it is every bit as bonkers as its design.</p> <a href="https://www.theguardian.com/travel/2023/jan/26/bavaria-walking-holiday-hiking-germany-south">Continue reading...</a>

## Misophonia: how ‘sound rage’ destroys relationships and forces people to move home
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/misophonia-how-sound-rage-destroys-relationships-and-forces-people-to-move-home](https://www.theguardian.com/lifeandstyle/2023/jan/26/misophonia-how-sound-rage-destroys-relationships-and-forces-people-to-move-home)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:53+00:00
 - user: None

<p>Sent into apoplexy by whistling noses? Can’t bear the sound of people eating? You could be one of the many people affected by this potentially debilitating condition</p><p>As a teenager, I remember being moved almost to tears by the sound of a family member chewing muesli. A friend eating dumplings once forced me to flee the room. The noises one former housemate makes when chomping popcorn mean I have declined their invitations to the cinema for nearly 20 years.</p><p>I am not proud of myself for reacting like this – in fact, I am pretty embarrassed – but my responses feel unavoidable. It is probable that I have misophonia. According to <a href="https://psyarxiv.com/jwpeq/">a scientific paper published last year</a>, so do 18% of people in the UK.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/misophonia-how-sound-rage-destroys-relationships-and-forces-people-to-move-home">Continue reading...</a>

## Art for auction in support of Ukrainian academy – in pictures
 - [https://www.theguardian.com/world/gallery/2023/jan/26/art-for-auction-in-support-of-ukrainian-academy-in-pictures](https://www.theguardian.com/world/gallery/2023/jan/26/art-for-auction-in-support-of-ukrainian-academy-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>Members of the Royal Academy of Arts (RA) in London including Tracey Emin, Antony Gormley and Conrad Shawcross have banded together with members of the National Academy of Arts of Ukraine (NAAU) such as Boris Mikhailov and Pavlo Makov, and international artists including Stephen Shore and Juergen Teller, to try to help save the NAAU. On 28 January, the RA will host a charity auction of donated works, in collaboration with the Natalia Cola Foundation, in support of the NAAU</p> <a href="https://www.theguardian.com/world/gallery/2023/jan/26/art-for-auction-in-support-of-ukrainian-academy-in-pictures">Continue reading...</a>

## Baby Trump set to fly again as Museum of London reinflates blimp
 - [https://www.theguardian.com/us-news/2023/jan/26/baby-trump-set-to-fly-again-as-museum-of-london-reinflates-blimp](https://www.theguardian.com/us-news/2023/jan/26/baby-trump-set-to-fly-again-as-museum-of-london-reinflates-blimp)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>Inflatable produced to lampoon former US president during his UK visits undergoes testing prior to installation in museum’s protest collection</p><p>While Donald Trump’s hopes for re-election as US president may be faltering, the nappy-wearing depiction of him made famous during a UK protest in 2018 has had new life breathed into it, as the Museum of London has reinflated it.</p><p>The baby blimp inflatable, which flew above a march in Parliament Square in London in July 2018, was given a test inflation this week.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/baby-trump-set-to-fly-again-as-museum-of-london-reinflates-blimp">Continue reading...</a>

## Joan Didion to David Hockney: facing up to the art stars – in pictures
 - [https://www.theguardian.com/artanddesign/gallery/2023/jan/26/joan-didion-to-david-hockney-facing-up-to-the-art-stars-in-pictures](https://www.theguardian.com/artanddesign/gallery/2023/jan/26/joan-didion-to-david-hockney-facing-up-to-the-art-stars-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>A new exhibition features bracing, intimate portraits of compelling cultural figures by Brigitte Lacombe, Catherine Opie and Tacita Dean</p> <a href="https://www.theguardian.com/artanddesign/gallery/2023/jan/26/joan-didion-to-david-hockney-facing-up-to-the-art-stars-in-pictures">Continue reading...</a>

## Victor Navasky, the New York Times and a key moment in gay history
 - [https://www.theguardian.com/books/2023/jan/26/victor-navasky-new-york-times-gay-history](https://www.theguardian.com/books/2023/jan/26/victor-navasky-new-york-times-gay-history)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>The great editor, who died this week, prompted one of the most important pieces ever published about homosexuality</p><p>Victor Navasky, <a href="https://www.theguardian.com/books/2023/jan/25/victor-navasky-author-editor-the-nation-dies-90">who died this week aged 90</a>, was famous for his books about the McCarthy period in the 1950s and Robert Kennedy’s justice department in the 1960s, his longtime editorship of the Nation magazine, and positions at Columbia University including chairing the Columbia Journalism Review.</p><p>What almost no one remembers is how his homophobic reaction to a famously homophobic article in Harper’s magazine led him to commission the most pro-gay piece the New York Times had published up to that time – a foundational document which appeared in 1971, at the dawn of the movement for gay liberation.</p> <a href="https://www.theguardian.com/books/2023/jan/26/victor-navasky-new-york-times-gay-history">Continue reading...</a>

## Who are these people who love to feel sand between their toes? I hate it | Adrian Chiles
 - [https://www.theguardian.com/commentisfree/2023/jan/26/who-are-these-people-who-love-to-feel-sand-between-their-toes-i-hate-it](https://www.theguardian.com/commentisfree/2023/jan/26/who-are-these-people-who-love-to-feel-sand-between-their-toes-i-hate-it)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>I adore the sea but what’s to love about a grainy, abrasive substance that gets everywhere?</p><p>I hate sand. I love the coast; being from Birmingham, it’s always filled me with wonder. My Croatian grandad used to say that if you dipped your toe in the sea, you were connected to the whole world. This idea enchants me still. But I say again, I bloody hate sand. It gets everywhere. In sandwiches on the beach as a kid; in my toenails; in my hair; in every last crevice of my body, including my mind. And once it’s wherever it is, it’s always there. </p><p>Who are these people who love to feel the sand between their toes? When I walk on a beach, I am hermetically sealed from the knees down, but somehow it finds its way in. I might get myself a Hazmat suit – whatever it takes. It might be the Croat in me. On the Adriatic it’s all rocks. Some of them are decidedly jagged and sharp and difficult to negotiate. But I’ll take lacerated feet over sandy feet all day long.</p><p>Adrian Chiles is a writer, broadcaster and Guardian columnist</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/who-are-these-people-who-love-to-feel-sand-between-their-toes-i-hate-it">Continue reading...</a>

## Why can’t AvantiGas deliver? We’re about to run out of fuel
 - [https://www.theguardian.com/money/2023/jan/26/why-cant-avantigas-deliver-were-about-to-run-out-of-fuel](https://www.theguardian.com/money/2023/jan/26/why-cant-avantigas-deliver-were-about-to-run-out-of-fuel)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:52+00:00
 - user: None

<p>Our LPG tank is down to 3% and will only last a couple of days</p><p><strong>I was told by our Liquid Petroleum Gas supplier, AvantiGas, to place an advance order on 3 November, with a delivery window of 7-10 days expected. Two months on, we are still waiting. Our tank is now down to 3% capacity and will run out in the next couple of days. We’ve turned off the heating to conserve supplies for cooking.</strong></p><p><strong>It told me I would get a delivery “before Christmas”, then “as soon as possible”, then, when our tank was at 20%, then 10% and now 5% capacity. It warned me several times that if it expedited a delivery, and the gauge was above 10% when it arrived, it would charge £210 +VAT extra. Now it mentions “unplanned operational difficulties” and says it is prioritising people with medical needs. Is the company about to go out of business? Have they run out of gas? What is happening?<br /></strong><em><strong>DB, Hereford</strong></em></p> <a href="https://www.theguardian.com/money/2023/jan/26/why-cant-avantigas-deliver-were-about-to-run-out-of-fuel">Continue reading...</a>

## Imagine: a Love Island for middle-aged, tired, soft-bodied people. I’d watch it | Lucy Mangan
 - [https://www.theguardian.com/commentisfree/2023/jan/26/love-island-middle-aged-itv-the-romance-retreat](https://www.theguardian.com/commentisfree/2023/jan/26/love-island-middle-aged-itv-the-romance-retreat)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 07:00:51+00:00
 - user: None

<p>ITV’s new show The Romance Retreat sounds more ‘real’ than the antics in Casa Amor. But just how true-to-life will it be?</p><p>There is a <a href="https://youtube.com/watch?v=zU6l3aox00o">scene</a> in Tina Fey’s comedy show 30 Rock where the small-screen diva<strong> </strong>Jenna Maroney must reluctantly accept that she has been cast in a YA show not as one of the main characters, but as the ailing mother. Her final line? “I’m 41 now,” she says, falling back on the sofa. “Time … to die.” Tina Fey also appears in the famous <a href="https://www.youtube.com/watch?v=vDz2kcjWpOs">Last ***kable Day sketch</a>, from Inside Amy Schumer, in which various female actors d’un certain age gather over wine to mark the passing of the days of being cast by male directors.</p><p>The cultural obsession with youth – especially in any kind of visual medium like film and TV – is a widely recognised, if not widely addressed, phenomenon. But it is at its most unbending when it comes to the reality show genre. There, in whatever sun-kissed villa or island the participants have been put into in order to discover their soulmates and/or a new strain of chlamydia, anyone over the age of roughly 25 can expect to become den mother at best, or left out in a bathchair in the broiling sun at worst. It is an unspoken rule that anyone over 30 approaching the love palace is shot on sight.</p><p>Lucy Mangan is a Guardian TV critic</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/love-island-middle-aged-itv-the-romance-retreat">Continue reading...</a>

## Russia-Ukraine war live: drones shot down over Kyiv; Zelenskiy urges swift delivery of tanks
 - [https://www.theguardian.com/world/live/2023/jan/26/russia-ukraine-war-live-key-thing-now-is-speed-and-volume-says-zelenskiy-as-allies-commit-to-tanks](https://www.theguardian.com/world/live/2023/jan/26/russia-ukraine-war-live-key-thing-now-is-speed-and-volume-says-zelenskiy-as-allies-commit-to-tanks)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:16:38+00:00
 - user: None

<p>‘Today is a day of extremely good news for Ukraine,’ says president; Germany’s decision paves way for other European nations to supply tanks</p><ul><li><a href="https://www.theguardian.com/world/series/russia-ukraine-war-at-a-glance">Russia-Ukraine war at a glance</a></li></ul><p>Ukraine has now declared an air raid alert over most of the country with regional authorities warned of a possible missile attack.</p><p>The DTEK electricity company says it is performing emergency shutdowns of electro power in the capital Kyiv, the rest of the Kyiv region, and also the regions of Odesa and Dnipropetrovsk due to a danger of missile attack.</p> <a href="https://www.theguardian.com/world/live/2023/jan/26/russia-ukraine-war-live-key-thing-now-is-speed-and-volume-says-zelenskiy-as-allies-commit-to-tanks">Continue reading...</a>

## TV tonight: Grayson Perry’s controversial new exhibition about Englishness
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/tv-tonight-grayson-perrys-controversial-new-exhibition-about-englishness](https://www.theguardian.com/tv-and-radio/2023/jan/26/tv-tonight-grayson-perrys-controversial-new-exhibition-about-englishness)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:15:50+00:00
 - user: None

<p>Colourful characters feature as Grayson Perry’s Full English begins. Plus: Lord Sugar and Marie Antoinette (not together). Here’s what to watch this evening</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/tv-tonight-grayson-perrys-controversial-new-exhibition-about-englishness">Continue reading...</a>

## Britishvolt ‘collapsed owing £120m’ as UK car industry reports dismal year
 - [https://www.theguardian.com/business/2023/jan/26/britishvolt-collapsed-owing-120m-as-uk-car-industry-reports-dismal-year](https://www.theguardian.com/business/2023/jan/26/britishvolt-collapsed-owing-120m-as-uk-car-industry-reports-dismal-year)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:01:50+00:00
 - user: None

<p>Several bids are understood to have been made for assets of failed electric vehicle battery startup</p><p>The battery startup Britishvolt owed as much as £120m to creditors when it collapsed last week in a major blow to hopes of sustaining the British car industry, it can be revealed.</p><p>Creditors are expected to recover a very small proportion of the debts, according to a source with knowledge of the matter, although there are understood to be several bids for the company and its assets. EY, a professional services firm, is handling the administration.</p> <a href="https://www.theguardian.com/business/2023/jan/26/britishvolt-collapsed-owing-120m-as-uk-car-industry-reports-dismal-year">Continue reading...</a>

## Britain, here’s a plan: stop applying old fixes to new problems. And stop obsessing about growth | David Edgerton
 - [https://www.theguardian.com/commentisfree/2023/jan/26/britain-growth-crises-productivity-wealth-inequality-80s-green](https://www.theguardian.com/commentisfree/2023/jan/26/britain-growth-crises-productivity-wealth-inequality-80s-green)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:53+00:00
 - user: None

<p>Crises in productivity and wealth inequality won’t be solved with ideas from the 80s. It’s not about a bigger pie – we need a different one</p><p>According to our politicians and most of the media, the central problem facing the British economy is a lack of growth. We need growth, we are told, to pay for this or that public service, or good wages, or housing. Just this week it was reported that the chancellor would need to <a href="https://www.thetimes.co.uk/article/gloomier-uk-economy-growth-prospects-leave-jeremy-hunt-with-black-hole-in-budget-l8fcpkgx8">plan further cuts in expenditure</a> as a result of the Office for Budget Responsibility downgrading the UK’s growth prospects.</p><p>But we should beware framing the lack of growth as the main affliction. In any case, the solutions to the growth problem have been tried and largely failed, whether the <a href="https://www.theguardian.com/politics/2022/oct/22/austerity-brexit-and-44-days-in-purgatory-the-key-stages-of-tory-rule">austerity</a> of the Cameron years, the tax cuts <a href="https://www.theguardian.com/business/2022/oct/20/the-mini-budget-that-broke-britain-and-liz-truss">proposed by Liz Truss and Kwasi Kwarteng</a> or the innovation promised<strong> </strong>by all governments since the 1990s. The problems of the present are genuinely novel, and require not so much growing the British economy as transforming it.</p> <a href="https://www.theguardian.com/commentisfree/2023/jan/26/britain-growth-crises-productivity-wealth-inequality-80s-green">Continue reading...</a>

## The one change that didn’t work: I pounded through exercise classes – until my doctor prescribed rest
 - [https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-i-exercised-obsessively-to-wipe-out-my-grief-but-my-body-rebelled](https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-i-exercised-obsessively-to-wipe-out-my-grief-but-my-body-rebelled)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:53+00:00
 - user: None

<p>I was grief-stricken and exhausted when I began high-intensity interval training. Then came a short, sharp scream in my knees and intense thumping in my chest</p><p>Picturing myself during the last three years is a lot like looking at a childhood photo. I know that it’s me, but the gulf between selves is wide. Personally, I was grief-stricken. My mother died in the summer of 2020, alone in a London hospice, while <a href="https://www.theguardian.com/politics/2022/jan/12/boris-johnson-admits-attending-downing-street-party-during-lockdown">the prime minister and his top officials partied</a> in Westminster. Grief changes a person irreparably; when someone you love dies, they take a version of you with them. And then? A more broken and watchful self is born. </p><p>In the weeks and months after my mother’s death, this new version of me developed some strange new habits. I started waking every night at 3am – the hour when my mother died – and could only get back to sleep by listening to Martin Jarvis reading Dickens. I started making my own body cream out of essential oils, raw cocoa butter and 100% unrefined pure natural anxiety – the kind of knit-your-own-earrings-and-sell-them-on-Etsy behaviour at which I would have previously scoffed. I impulse-bought a year’s supply of antihistamines online (adorably, my equally grief-stricken sister did the exact same thing 400 miles away in London). And, most uncharacteristically of all, I started doing high-intensity interval training (HIIT) at home in Leith on the living room rug, surrounded by (and often underneath) my six-year-old, my two-year-old and my eight-year-old rescue staffie. While – and this is where it gets ultra-pandemicky – monitoring my heart rate using a pulse oximeter. I know. What larks.</p> <a href="https://www.theguardian.com/lifeandstyle/2023/jan/26/the-one-change-that-didnt-work-i-exercised-obsessively-to-wipe-out-my-grief-but-my-body-rebelled">Continue reading...</a>

## US-born Spanish woman, 115, becomes world’s oldest person
 - [https://www.theguardian.com/us-news/2023/jan/26/worlds-oldest-person-115-maria-branyas-morera-california](https://www.theguardian.com/us-news/2023/jan/26/worlds-oldest-person-115-maria-branyas-morera-california)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:53+00:00
 - user: None

<p>María Branyas Morera, born in 1907, now in Guinness record books after death of Lucille Randon, 118, in French town of Toulon</p><p>María Branyas Morera has lived through two world wars, the Spanish civil war, the 1918 flu pandemic and Covid.</p><p>Now the California-born woman is the world’s oldest living person.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/worlds-oldest-person-115-maria-branyas-morera-california">Continue reading...</a>

## Battle of the botanic garden: the horticulture war roiling the Isle of Wight
 - [https://www.theguardian.com/environment/2023/jan/26/battle-of-the-botanic-garden-the-horticulture-war-roiling-the-isle-of-wight](https://www.theguardian.com/environment/2023/jan/26/battle-of-the-botanic-garden-the-horticulture-war-roiling-the-isle-of-wight)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:52+00:00
 - user: None

<p>When a US businessman took over a beloved garden a decade ago, he decided on a radical new approach, all in the name of sustainability. But angry critics claim it’s just plain neglect</p><p>John Curtis’s enemies – and for a man who runs a mid-sized botanical garden on the Isle of Wight, he has surprisingly many – have a tendency to refer to him as “the American Businessman”, a phrase that, for many islanders, carries overtones of rapaciousness and cultural barbarism. He would rather not have quite so many adversaries, but neither does it seem especially to disturb him to be the object of simmering ill will on the island. He is not in the business of deliberately goading his detractors, but he tends, in his discussion of the increasingly public argument unfolding around his stewardship of the garden, toward a certain easygoing, sprightly provocation. “I’m a lightning rod,” as he put it to me in our first conversation, and on several occasions thereafter.</p><p>Curtis is a slight man in his early 60s with a neat, greying beard and nimble features. He is an intent listener and a rapid and agile talker. He doesn’t strike you as the sort of person who would wind up running a botanic garden on the Isle of Wight, or anywhere else for that matter. Such is his quality of flinty refinement that it is easy to imagine him a senior partner at a white-shoe Manhattan law firm, dispensing astringent wisdom to a younger colleague over a tumbler of scotch at the Yale Club. He was born into one of Connecticut’s oldest families, and is a direct descendent of the Puritan preacher John Winthrop, who founded the Massachusetts Bay Colony in the 1630s, and whose A Model of Christian Charity sermon – popularly known as the “City upon a hill” speech – is a core text of American exceptionalism.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/battle-of-the-botanic-garden-the-horticulture-war-roiling-the-isle-of-wight">Continue reading...</a>

## Children go hungry at Kenya refugee camp as malnutrition numbers soar
 - [https://www.theguardian.com/global-development/2023/jan/26/children-go-hungry-at-kenya-refugee-camp-as-malnutrition-numbers-soar](https://www.theguardian.com/global-development/2023/jan/26/children-go-hungry-at-kenya-refugee-camp-as-malnutrition-numbers-soar)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:52+00:00
 - user: None

<p>MSF charity reports 33% rise in malnourished patients at giant Dadaab complex after influx from drought-stricken Somalia</p><p>Malnutrition among children in one of the world’s largest refugee camps has surged over the past year as concerns grow at worsening conditions at the site in Kenya.</p><p>Médecins Sans Frontières said its health facility in Dagahaley, a camp in the Dadaab refugee complex, has treated 33% more patients – mainly children – for malnutrition over the past year, while the rate of malnourishment in the camps grew by 45% in the last six months of 2022.</p> <a href="https://www.theguardian.com/global-development/2023/jan/26/children-go-hungry-at-kenya-refugee-camp-as-malnutrition-numbers-soar">Continue reading...</a>

## Did a lightning strike change the course of Mary Anning’s life?
 - [https://www.theguardian.com/world/2023/jan/26/did-lightning-strike-change-course-of-mary-anning-life](https://www.theguardian.com/world/2023/jan/26/did-lightning-strike-change-course-of-mary-anning-life)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:52+00:00
 - user: None

<p>Girl from poor family who became famed fossil collector had near-death experience aged 15 months</p><p><a href="https://www.theguardian.com/artanddesign/2022/may/21/mary-anning-fossil-hunting-pioneer-statue-lyme-regis-dorset">Mary Anning</a> became world-famous for her fossil discoveries but her life was hard. She came from a poor background, and life grew even worse when her father died when she was young.</p><p>On 19 August 1800, aged 15 months, she narrowly escaped death. She was taken to see an outdoor equestrian event by a family friend, Elizabeth Haskings, and two other women. The afternoon grew very sultry before “there was an awful peal of thunder” and Mary’s group ran for shelter under a tree before lightning struck and the three women were killed. Mary also appeared dead but she was rushed home, given a warm bath and miraculously revived. Her biographer, George Roberts, wrote: “Mary Anning was born a dull child but after the accident grew up lively and intelligent.”<br /><br />On very rare occasions lightning has led to other life-changing miracles. The neurologist Oliver Sacks in his book Musicophilia described how a surgeon, Tony Cicoria, was almost killed by lightning in 1994. He recovered and became obsessed with music: he heard it in his head, learned to play the piano and composed his own music.</p> <a href="https://www.theguardian.com/world/2023/jan/26/did-lightning-strike-change-course-of-mary-anning-life">Continue reading...</a>

## Flying shame: the scandalous rise of private jets
 - [https://www.theguardian.com/environment/2023/jan/26/flying-shame-the-scandalous-rise-of-private-jets](https://www.theguardian.com/environment/2023/jan/26/flying-shame-the-scandalous-rise-of-private-jets)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:51+00:00
 - user: None

<p>Last week, Rishi Sunak flew from London to Blackpool – his third private jet trip in 10 days. He’s far from the only one using air travel for short journeys. Just how much damage is this doing?</p><p>It was a Labour spokesperson who said the prime minister was behaving “like an A-list celeb”, after Rishi Sunak made his third trip by private jet in 10 days. Last week, he flew from London to Blackpool in a 14-seat RAF jet – a 230-mile journey that would have taken about three hours by train. The week before, he did the same to Leeds, which he could have done in two and a half hours by train, but which wouldn’t have looked nearly so glamorous – to go by the ludicrous photograph of him looking important and being saluted as he boarded the aircraft.</p><p>Private planes are up to 14 times more polluting, per passenger, than commercial planes and 50 times more polluting than trains, according to a report by Transport &amp; Environment, a European clean transport campaign organisation. “It goes against the fact that the government has <a href="https://www.theguardian.com/environment/2023/jan/24/net-zero-by-2050-in-england-and-wales-equals-extra-2m-years-of-life?ref=upstract.com">committed to net zero by 2050</a>,” says Alice Ridley, a spokesperson for the Campaign for Better Transport. “They have said they want to see more journeys by public transport, walking and cycling. Taking a private jet is extremely damaging for the environment, especially when there are other alternatives that would be far less polluting and would also be cheaper.”</p> <a href="https://www.theguardian.com/environment/2023/jan/26/flying-shame-the-scandalous-rise-of-private-jets">Continue reading...</a>

## In stark contrast: the warming of Europe’s ski resorts – photo essay
 - [https://www.theguardian.com/environment/2023/jan/26/warming-europe-ski-resorts-photo-essay-satellite-images-winter-lack-of-snow](https://www.theguardian.com/environment/2023/jan/26/warming-europe-ski-resorts-photo-essay-satellite-images-winter-lack-of-snow)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:51+00:00
 - user: None

<p>Comparison of satellite images from start of 2023 and those from last winter shows unprecedented lack of snow</p><p>We take a look at several European ski resorts comparing the snow cover this winter at the start of the year with that of last season. Méteo France reported that 2022 had ended with some of the warmest weather ever recorded in France for the time of year.</p><p>Snowfall at the start of 2023 was close to normal in the southern Alps and at altitude to the north, it said, but very scarce below 2,200 metres and in the Pyrenees.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/warming-europe-ski-resorts-photo-essay-satellite-images-winter-lack-of-snow">Continue reading...</a>

## UK telecoms firms urged to let customers leave before record price rise
 - [https://www.theguardian.com/business/2023/jan/26/uk-telecoms-firms-urged-to-let-customers-leave-before-record-price-rise](https://www.theguardian.com/business/2023/jan/26/uk-telecoms-firms-urged-to-let-customers-leave-before-record-price-rise)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:51+00:00
 - user: None

<p>Which? calls on firms to let customers break contracts penalty-free ahead of expected 14% rise in April</p><p>The UK’s biggest telecoms firms are being urged to allow customers to exit contracts penalty-free after it emerged they are due to impose their biggest price increases ever – over 14% – from April.</p><p>BT, EE, Plusnet, Shell, TalkTalk and Vodafone <a href="https://www.theguardian.com/money/2023/jan/19/uk-mobile-broadband-users-bill-rises-bt-ee-talktalk-three-vodafone-monthly-charges">are all on track to increase home internet bills by the inflation busting figure</a> – adding about £60 a year – but most customers are on fixed-term contracts with break-clause fees of up to £219 if they try to leave.</p> <a href="https://www.theguardian.com/business/2023/jan/26/uk-telecoms-firms-urged-to-let-customers-leave-before-record-price-rise">Continue reading...</a>

## Treasury was aware of investigation into Nadhim Zahawi’s finances, sources claim
 - [https://www.theguardian.com/uk-news/2023/jan/26/treasury-was-aware-investigation-nadhim-zahawi-finances-sources-claim](https://www.theguardian.com/uk-news/2023/jan/26/treasury-was-aware-investigation-nadhim-zahawi-finances-sources-claim)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:50+00:00
 - user: None

<p>No 10 says ‘categorically untrue’ that Rishi Sunak knew about tax fine at time of appointment</p><p>The matter of who knew what about Nadhim Zahawi’s dealings with the taxman and when in Whitehall and No 10 is the subject of intense scrutiny and could yet define Rishi Sunak’s premiership.</p><p>Sunak has sought to <a href="https://www.theguardian.com/uk-news/2023/jan/23/sunak-under-pressure-over-when-he-knew-about-nadhim-zahawi-tax-inquiry">put down suggestions</a> he was aware that Zahawi paid a penalty to HMRC prior to his appointment as the Conservative party’s chair on 25 October 2022.</p> <a href="https://www.theguardian.com/uk-news/2023/jan/26/treasury-was-aware-investigation-nadhim-zahawi-finances-sources-claim">Continue reading...</a>

## UK facing crisis point in abortion provision, experts say
 - [https://www.theguardian.com/society/2023/jan/26/uk-facing-crisis-point-in-abortion-provision-experts-say](https://www.theguardian.com/society/2023/jan/26/uk-facing-crisis-point-in-abortion-provision-experts-say)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:50+00:00
 - user: None

<p>Women said to be travelling hundreds of miles for appointments or waiting several weeks</p><p>The UK is facing a “crisis point” in abortion provision, experts say, with rising demand and restricted access to care in many areas putting unprecedented pressure on struggling NHS services.</p><p>Healthcare professionals described a “terrifying” state of affairs in which women are travelling hundreds of miles for appointments or waiting several weeks before they are seen.</p> <a href="https://www.theguardian.com/society/2023/jan/26/uk-facing-crisis-point-in-abortion-provision-experts-say">Continue reading...</a>

## ‘Founding spirit’ of Notting Hill carnival to be honoured with blue plaque
 - [https://www.theguardian.com/culture/2023/jan/26/claudia-jones-founding-spirit-notting-hill-carnival-blue-plaque-london-home-english-heritage](https://www.theguardian.com/culture/2023/jan/26/claudia-jones-founding-spirit-notting-hill-carnival-blue-plaque-london-home-english-heritage)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 06:00:50+00:00
 - user: None

<p>Journalist and activist Claudia Jones among five women whose life and legacy will be marked by English Heritage</p><p>The woman described as the “founding spirit” of the Notting Hill carnival is to be commemorated with a blue plaque at her former London home this year.</p><p>Claudia Jones, a feminist, political activist and journalist who was born in Trinidad in 1915, is one of five women whose achievements and legacy will be marked by English Heritage. A sixth blue plaque will commemorate the violinist Yehudi Menuhin.</p> <a href="https://www.theguardian.com/culture/2023/jan/26/claudia-jones-founding-spirit-notting-hill-carnival-blue-plaque-london-home-english-heritage">Continue reading...</a>

## Thousands attend Invasion Day rallies on Australia’s national holiday as colonisation debates rages
 - [https://www.theguardian.com/australia-news/2023/jan/26/thousands-attend-invasion-day-rallies-on-australias-national-holiday-as-colonisation-debates-rages](https://www.theguardian.com/australia-news/2023/jan/26/thousands-attend-invasion-day-rallies-on-australias-national-holiday-as-colonisation-debates-rages)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:49:03+00:00
 - user: None

<p>With Australia increasingly uneasy about celebrating its national day, recognition of Indigenous people in the constitution has become a new flashpoint</p><p>Tens of thousands of people have marked Australia’s national day by attending protest rallies in cities across the nation, amid a rising political and social reckoning with the country’s colonial history.</p><p>Australia Day – 26 January – commemorates the landing of the British first fleet of convicts at Sydney Cove in 1788, the beginning of the settlement that entrenched European colonisation of the Australian continent.</p> <a href="https://www.theguardian.com/australia-news/2023/jan/26/thousands-attend-invasion-day-rallies-on-australias-national-holiday-as-colonisation-debates-rages">Continue reading...</a>

## Why is Trump allowed back on Facebook and will Meta’s ‘guardrails’ contain him?
 - [https://www.theguardian.com/us-news/2023/jan/26/why-is-donald-trump-being-allowed-back-on-facebook-instagram-ban-meta-guardrails](https://www.theguardian.com/us-news/2023/jan/26/why-is-donald-trump-being-allowed-back-on-facebook-instagram-ban-meta-guardrails)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:26:18+00:00
 - user: rumpel
 - tags: facebook,moderation,censorship,trump,meta

<p>Meta’s leadership say the risk has ‘sufficiently receded’, as the former US president has the ban on his accounts lifted for the first time in two years</p><p>Former US president Donald Trump will have the ban on his Facebook and Instagram accounts <a href="https://www.theguardian.com/us-news/2023/jan/25/trump-facebook-ban-lifted-unbanned-instagram-meta-pages-latest">lifted for the first time in two years</a>, parent company Meta has announced. But what are the “guardrails” it says will deter repeat offences, what will it mean for the platform, and what would it take for him to be banned again?</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/why-is-donald-trump-being-allowed-back-on-facebook-instagram-ban-meta-guardrails">Continue reading...</a>

## Bangkok air pollution prompts advice to work from home
 - [https://www.theguardian.com/world/2023/jan/26/bangkok-air-pollution-prompts-advice-to-work-from-home](https://www.theguardian.com/world/2023/jan/26/bangkok-air-pollution-prompts-advice-to-work-from-home)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:20:37+00:00
 - user: None

<p>Thai capital’s already bad air made worse by forest fires and burning on farms</p><p>People in Bangkok have been advised to work from home and wear face masks due to air pollution that has worsened to unhealthy levels.</p><p>Officials urged people to use public transport rather than private cars for commuting, and said the authorities would seek to reduce sources of pollution such as outdoor burning and construction activities. Face masks would also be distributed to vulnerable people, Bangkok authorities said.</p> <a href="https://www.theguardian.com/world/2023/jan/26/bangkok-air-pollution-prompts-advice-to-work-from-home">Continue reading...</a>

## ‘Reckless’: Fury among rights groups as Facebook lifts Trump ban
 - [https://www.theguardian.com/us-news/2023/jan/26/reckless-fury-among-rights-groups-as-facebook-lifts-trump-ban](https://www.theguardian.com/us-news/2023/jan/26/reckless-fury-among-rights-groups-as-facebook-lifts-trump-ban)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:01:40+00:00
 - user: None

<p>Civil rights groups voice anger at ‘unethical’ decision, while others say the public has an interest in hearing directly from candidates for political office</p><p>The news that Meta will <a href="https://www.theguardian.com/us-news/2023/jan/25/trump-facebook-ban-lifted-unbanned-instagram-meta-pages-latest">allow Donald Trump back on Facebook and Instagram</a> following a two-year ban has been met with fury and indignation among civil rights and online safety advocates.</p><p>The former US president will be allowed to <a href="https://www.theguardian.com/us-news/2023/jan/25/trump-facebook-ban-lifted-unbanned-instagram-meta-pages-latest">return to the platforms</a> “in coming weeks” but “with new guardrails in place to deter repeat offences”, Meta’s president of global affairs, Nick Clegg, wrote in a <a href="https://about.fb.com/news/2023/01/trump-facebook-instagram-account-suspension/">blogpost</a> explaining the decision on Wednesday.</p> <a href="https://www.theguardian.com/us-news/2023/jan/26/reckless-fury-among-rights-groups-as-facebook-lifts-trump-ban">Continue reading...</a>

## How will ChatGPT transform creative work? – podcast
 - [https://www.theguardian.com/science/audio/2023/jan/26/how-will-chatgpt-transform-creative-work-podcast](https://www.theguardian.com/science/audio/2023/jan/26/how-will-chatgpt-transform-creative-work-podcast)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:00:50+00:00
 - user: None

<p>ChatGPT has been causing a stir since its launch last year. The chatbot’s ability to produce convincing essays, stories and even song lyrics has impressed users, and this week attracted a multibillion-dollar investment from Microsoft. Ian Sample speaks to Prof John Naughton about how ChatGPT works, hears from author Patrick Jackson about how it will change publishing, and asks where the technology could end up</p><p>After launching in November, ChatGPT became an immediate hit that has both entertained and alarmed its users. Given a command or question, the chatbot is able to return convincing essays, simple recipes and even life advice in a matter of seconds. This impressive feat is performed by a large language model that lies behind its interface. Using a staggering amount of text drawn from the internet, the model builds up words and sentences based on statistical probability. It’s been described as a vastly scaled-up version of predictive text messaging. The result is a technology that has attracted a <a href="https://www.theguardian.com/technology/2023/jan/23/microsoft-confirms-multibillion-dollar-investment-in-firm-behind-chatgpt">multibillion-dollar investment from Microsoft</a>, and got many wondering how viable their jobs might soon become.</p><p><strong>Ian Sample</strong> speaks to the Observer columnist Prof <strong>John Naughton </strong>about how ChatGPT works and <a href="https://www.theguardian.com/commentisfree/2023/jan/07/chatgpt-bot-excel-ai-chatbot-tech">what could be next for this technology</a>, and hears from the children’s author <strong>Patrick Jackson</strong> on how he plans to use it and why he’s enthusiastic about how it could change his work</p> <a href="https://www.theguardian.com/science/audio/2023/jan/26/how-will-chatgpt-transform-creative-work-podcast">Continue reading...</a>

## ‘I want to live’: the Ukraine hotline encouraging Russians to surrender
 - [https://www.theguardian.com/world/2023/jan/26/ukraine-hotline-encouraging-russians-to-surrender](https://www.theguardian.com/world/2023/jan/26/ukraine-hotline-encouraging-russians-to-surrender)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:00:50+00:00
 - user: None

<p>It is claimed 6,543 Russian personnel have surrendered since the hotline launched in September 2022</p><p>More than 6,500 Russian military personnel have sought to surrender through a bespoke “I want to live” hotline, Ukraine’s government has claimed, with the call centre said to have been recently moved to a secret location to avoid Moscow interference.</p><p>Vitaly Matvienko, spokesperson at the department for prisoners of war, said those who had made contact through the service had been verified as serving in the Russian forces using their personal data and service number.</p> <a href="https://www.theguardian.com/world/2023/jan/26/ukraine-hotline-encouraging-russians-to-surrender">Continue reading...</a>

## EU toughens stance on non-EU countries taking back citizens denied right to stay
 - [https://www.theguardian.com/world/2023/jan/26/eu-toughens-stance-on-non-eu-countries-taking-back-citizens-denied-right-to-stay](https://www.theguardian.com/world/2023/jan/26/eu-toughens-stance-on-non-eu-countries-taking-back-citizens-denied-right-to-stay)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:00:49+00:00
 - user: None

<p>Campaigners say bloc’s plan to use development aid, trade policy and access to visas as ‘leverage’ fails to put human rights first</p><p>The European Union could use development aid, trade policy and access to visas as “leverage” over non-EU countries that are deemed to be failing to take back their citizens denied the right to stay in Europe, according to a draft communique seen by the Guardian.</p><p>The EU’s 27 national leaders could endorse a plan at a summit in Brussels next month to use “all relevant EU policies, instruments and tools, including development, trade and visas as well as opportunities for legal migration” as “leverage” over migrants’ countries of origin.</p> <a href="https://www.theguardian.com/world/2023/jan/26/eu-toughens-stance-on-non-eu-countries-taking-back-citizens-denied-right-to-stay">Continue reading...</a>

## Italian hospital investigated after newborn dies under sleeping mother
 - [https://www.theguardian.com/world/2023/jan/26/italian-hospital-investigated-after-newborn-dies-under-sleeping-mother](https://www.theguardian.com/world/2023/jan/26/italian-hospital-investigated-after-newborn-dies-under-sleeping-mother)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:00:49+00:00
 - user: None

<p>Thousands sign petition calling for better postnatal care amid concerns over conditions in maternity units</p><p>Controversy is mounting in Italy over conditions in hospital maternity units after a newborn is believed to have died by suffocation under the weight of his mother who fell asleep after breastfeeding him.</p><p>An investigation is under way into the tragedy, which occurred at the Sandro Pertini hospital in Rome on 8 January. The results of the autopsy are expected within 60 days.</p> <a href="https://www.theguardian.com/world/2023/jan/26/italian-hospital-investigated-after-newborn-dies-under-sleeping-mother">Continue reading...</a>

## Paul Mescal’s latest role: global film star
 - [https://www.theguardian.com/film/2023/jan/26/paul-mescals-latest-role-global-film-star](https://www.theguardian.com/film/2023/jan/26/paul-mescals-latest-role-global-film-star)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 05:00:49+00:00
 - user: None

<p>Irish actor, 26, has been nominated for an Oscar for Aftersun role but still coaches Gaelic football in home town</p><p>When <a href="https://www.theguardian.com/culture/paul-mescal">Paul Mescal </a>was studying drama at Dublin’s Lir Academy he yearned to play Stanley Kowalski, the thuggish lead character in A Streetcar Named Desire.</p><p>Loughlin Deegan, the course director, told Mescal he was more suited to play the sensitive, courteous Mitch and that to have any chance of ever playing Stanley he would have to be brave and take risks as an actor.</p> <a href="https://www.theguardian.com/film/2023/jan/26/paul-mescals-latest-role-global-film-star">Continue reading...</a>

## Invasion Day protests around Australia – in pictures
 - [https://www.theguardian.com/australia-news/gallery/2023/jan/26/invasion-day-protests-around-australia-in-pictures](https://www.theguardian.com/australia-news/gallery/2023/jan/26/invasion-day-protests-around-australia-in-pictures)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 04:35:53+00:00
 - user: None

<p>From smoking ceremonies to marches, thousands flock to <a href="https://www.theguardian.com/australia-news/2023/jan/25/invasion-survival-day-guide-protest-events-marches-26-january-melbourne-sydney-brisbane-australia">Invasion Day events across the country</a> to celebrate First Nations culture and survival, and to call for change. Some attenders say the day has made them feel differently about the referendum on an <a href="https://www.theguardian.com/australia-news/indigenous-voice-to-parliament">Indigenous voice to parliament</a></p><ul><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul> <a href="https://www.theguardian.com/australia-news/gallery/2023/jan/26/invasion-day-protests-around-australia-in-pictures">Continue reading...</a>

## Novak Djokovic’s father seen posing with flagbearing supporters of Vladimir Putin at Australian Open
 - [https://www.theguardian.com/sport/2023/jan/26/novak-djokovics-father-seen-posing-with-flagbearing-supporters-of-vladimir-putin-at-australian-open](https://www.theguardian.com/sport/2023/jan/26/novak-djokovics-father-seen-posing-with-flagbearing-supporters-of-vladimir-putin-at-australian-open)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 04:12:08+00:00
 - user: None

<ul><li>Srdjan Djokovic filmed<strong> </strong>telling pro-Putin supporters ‘long live Russian citizens’</li><li>Footage follows arrest of pro-Russian fans at Australian Open</li></ul><p>Srdjan Djokovic, the father of Novak Djokovic, has been pictured posing for photos with Vladimir Putin supporters at the Australian Open on Wednesday night.</p><p>Four men had been evicted from Melbourne Park by Victoria police on Wednesday night after chanting pro-Russian and pro-Vladimir Putin slogans on the steps of Rod Laver Arena while brandishing numerous Russian flags, including one with the face of Putin on it.</p> <a href="https://www.theguardian.com/sport/2023/jan/26/novak-djokovics-father-seen-posing-with-flagbearing-supporters-of-vladimir-putin-at-australian-open">Continue reading...</a>

## Why are women in Britain having to travel hundreds of miles to get an abortion? podcast
 - [https://www.theguardian.com/news/audio/2023/jan/26/why-british-women-travelling-hundreds-miles-abortions-podcast](https://www.theguardian.com/news/audio/2023/jan/26/why-british-women-travelling-hundreds-miles-abortions-podcast)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 03:00:46+00:00
 - user: None

<p>Record numbers of abortions are being carried out and services are struggling to cope. Why is the system under so much pressure and what toll is it taking on women?</p><p>An unprecedented demand for abortions in the UK is leading to a crisis in abortion services. While women in the early stages of pregnancy can now receive abortion pills in the post, services that provide surgical abortions are being pushed to the limit.</p><p>At Homerton hospital, east London, doctors explain to <strong>Hannah Moore</strong> why women with complications, such as anaemia, are having to travel hundreds of miles to get the care they need and, in some cases, face delays of weeks before they can have a termination.</p> <a href="https://www.theguardian.com/news/audio/2023/jan/26/why-british-women-travelling-hundreds-miles-abortions-podcast">Continue reading...</a>

## Ukraine’s Odesa, the ‘pearl of the Black Sea’, added to Unesco World Heritage list
 - [https://www.theguardian.com/world/2023/jan/26/ukraines-odesa-the-pearl-of-the-black-sea-added-to-unesco-world-heritage-list](https://www.theguardian.com/world/2023/jan/26/ukraines-odesa-the-pearl-of-the-black-sea-added-to-unesco-world-heritage-list)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 02:02:01+00:00
 - user: None

<p>The status will ensure the historic port city is ‘preserved from further destruction,’ Unesco director-general Audrey Azoulay said</p><p>The United Nations’ cultural agency, Unesco, has added the historic centre of Ukraine’s city of Odesa to its World Heritage List, describing it as “the duty of all humanity” to protect it.</p><p>The status, awarded by a Unesco panel meeting in Paris on Wednesday, is designed to help protect the port city’s cultural heritage, which has been under threat since Russia’s invasion.</p> <a href="https://www.theguardian.com/world/2023/jan/26/ukraines-odesa-the-pearl-of-the-black-sea-added-to-unesco-world-heritage-list">Continue reading...</a>

## Ukraine says US and German tank pledges ‘only the beginning’ and calls for fighter jets
 - [https://www.theguardian.com/world/2023/jan/26/ukraine-says-us-and-german-tank-pledges-only-the-beginning-and-calls-for-fighter-jets](https://www.theguardian.com/world/2023/jan/26/ukraine-says-us-and-german-tank-pledges-only-the-beginning-and-calls-for-fighter-jets)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 01:48:18+00:00
 - user: None

<p>President Volodymyr Zelenskiy praised the decision by western allies but urged speed in the delivery of new weaponry</p><ul><li><a href="https://www.theguardian.com/world/ukraine">See all our Ukraine coverage</a></li></ul><p>Commitments from the United States and Germany to send advanced battle tanks to counter Russian aggression has been hailed as “only the beginning” by a senior official in Ukraine, who said hundreds of tanks were needed, as Kyiv renewed its calls for fighter jets.</p><p>Andriy Yermak, the head of Ukraine’s presidential administration, made the comments as President Volodymyr Zelenskiy praised the decision by western allies, urging them to provide large quantities of tanks quickly.</p> <a href="https://www.theguardian.com/world/2023/jan/26/ukraine-says-us-and-german-tank-pledges-only-the-beginning-and-calls-for-fighter-jets">Continue reading...</a>

## Asteroid 2023 BU about to pass Earth in one of closest ever encounters
 - [https://www.theguardian.com/science/2023/jan/26/asteroid-2023-bu-about-to-pass-earth-in-one-of-closest-ever-encounters](https://www.theguardian.com/science/2023/jan/26/asteroid-2023-bu-about-to-pass-earth-in-one-of-closest-ever-encounters)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 01:24:52+00:00
 - user: None

<p>No danger, says Nasa, from delivery truck-sized asteroid that was discovered on Saturday and will pass lower than communication satellites </p><p>An asteroid the size of a delivery truck will pass Earth in one of the closest such encounters ever recorded – coming within a tenth of the distance of most communication satellites’ orbit.</p><p>Nasa said the newly discovered asteroid would pass 2,200 miles (3,600km) above the southern tip of South America at 7.27pm US eastern time on Thursday (12.27am GMT on Friday).</p> <a href="https://www.theguardian.com/science/2023/jan/26/asteroid-2023-bu-about-to-pass-earth-in-one-of-closest-ever-encounters">Continue reading...</a>

## Who is Taryn Brumfitt? Here’s what you need to know about the 2023 Australian of the Year
 - [https://www.theguardian.com/australia-news/2023/jan/26/who-is-taryn-brumfitt-2023-australian-of-the-year-body-image-activist](https://www.theguardian.com/australia-news/2023/jan/26/who-is-taryn-brumfitt-2023-australian-of-the-year-body-image-activist)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 01:20:39+00:00
 - user: None

<p>The writer and director’s body image advocacy started with a viral post and is headed for the upper echelons of government</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/jan/26/australia-news-live-invasion-day-protests-under-way-pro-russian-tennis-fans-quizzed-by-police">Follow our Australia news live blog for the latest updates</a></li><li>Get our <a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://www.theguardian.com/technology/ng-interactive/2018/may/15/the-guardian-app?CMP=cvau_sfl">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Bestselling writer, director and body image campaigner <a href="https://www.theguardian.com/australia-news/2023/jan/25/australian-of-the-year-2023-taryn-brumfitt">Taryn Brumfitt</a> has been named the 2023 Australian of the Year.</p><p>The 45-year-old mother of four first came into public life in 2013, when a simple “before and after” photo on Facebook went viral showing how her body had changed.</p><p><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">Sign up for Guardian Australia’s free morning and afternoon</a></strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed"> </a><strong><a href="https://www.theguardian.com/australia-news/2022/oct/29/email-newsletters-guardian-australia-best-daily-news-emails-newsletter-free-sign-up-inbox-subscribe-headlines?CMP=copyembed">email newsletters for your daily news roundup</a></strong></p> <a href="https://www.theguardian.com/australia-news/2023/jan/26/who-is-taryn-brumfitt-2023-australian-of-the-year-body-image-activist">Continue reading...</a>

## Justin Roiland dropped from two more TV shows after domestic abuse charges
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/justin-roiland-dropped-koala-man-solar-opposites-tv-shows-rick-and-morty-domestic-abuse-charges](https://www.theguardian.com/tv-and-radio/2023/jan/26/justin-roiland-dropped-koala-man-solar-opposites-tv-shows-rick-and-morty-domestic-abuse-charges)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 01:19:12+00:00
 - user: None

<p>Roiland, who has pleaded not guilty, will no longer work on Hulu shows Solar Opposites or Koala Man, as well as being dropped from Rick and Morty</p><p>Justin Roiland has been dropped from two more animated shows, Solar Opposites and Koala Man, after being charged with felony domestic violence against a former girlfriend,<a href="https://www.theguardian.com/tv-and-radio/2023/jan/25/justin-roiland-dropped-from-rick-and-morty-after-domestic-abuse-charges"> a day after he was dropped from hit series Rick and Morty.</a></p><p>US network Hulu announced on Wednesday that it had “ended our association with Justin Roiland”, a day after Rick and Morty distributor Adult Swim released a similar statement saying he would no longer voice the titular characters or work as showrunnner.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/justin-roiland-dropped-koala-man-solar-opposites-tv-shows-rick-and-morty-domestic-abuse-charges">Continue reading...</a>

## Netflix denies any Squid Game reality show contestants have suffered ‘serious injury’
 - [https://www.theguardian.com/tv-and-radio/2023/jan/26/netflix-denies-any-squid-game-reality-show-contestants-have-suffered-serious-injury](https://www.theguardian.com/tv-and-radio/2023/jan/26/netflix-denies-any-squid-game-reality-show-contestants-have-suffered-serious-injury)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 01:07:57+00:00
 - user: None

<p>Streaming giant says three people were treated for mild conditions while filming competition based on hit South Korean drama, after contestant claims ‘it was like a war zone’</p><p>Three people received medical treatment during the filming of a Squid Game reality show, Netflix has confirmed, but said “claims of serious injury are untrue” after a contestant claimed people were stretchered out.</p><p>Squid Game: The Challenge will see 456 contestants competing for a huge cash prize, just like in the hit South Korean fictional drama. The reality show is currently being filmed in Cardington Studios, a former RAF base in Bedfordshire in the United Kingdom.</p> <a href="https://www.theguardian.com/tv-and-radio/2023/jan/26/netflix-denies-any-squid-game-reality-show-contestants-have-suffered-serious-injury">Continue reading...</a>

## Russia-Ukraine war at a glance: what we know on day 337 of the invasion
 - [https://www.theguardian.com/world/2023/jan/26/russia-ukraine-war-at-a-glance-what-we-know-on-day-337-of-the-invasion](https://www.theguardian.com/world/2023/jan/26/russia-ukraine-war-at-a-glance-what-we-know-on-day-337-of-the-invasion)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:26:34+00:00
 - user: None

<p>US and Germany confirm that they will supply Ukraine with tanks; Russia accuses Berlin of taking conflict “to a new level of confrontation”</p><ul><li><strong><a href="https://www.theguardian.com/world/ukraine">See all our Russia-Ukraine war coverage</a></strong></li></ul> <a href="https://www.theguardian.com/world/2023/jan/26/russia-ukraine-war-at-a-glance-what-we-know-on-day-337-of-the-invasion">Continue reading...</a>

## Onion smuggling rackets thrive as staple becomes a luxury in Philippines
 - [https://www.theguardian.com/world/2023/jan/26/onion-smuggling-rackets-thrive-as-staple-becomes-a-luxury-in-philippines](https://www.theguardian.com/world/2023/jan/26/onion-smuggling-rackets-thrive-as-staple-becomes-a-luxury-in-philippines)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:19:34+00:00
 - user: None

<p>Millions of dollars’ worth of onions seized by authorities as inflation crisis sees the cost of other basics soar </p><p>Their price soared so rapidly, some likened them to gold. Restaurants stripped them from their menus, officials warned travellers not to import them without special permission and millions of pesos’ worth have reportedly been seized in raids.</p><p>Between 500m and 600m pesos ($9m – $11m) worth of onions were impounded by officials last year, according to local media. The vegetable accounted for 30% of smuggled farm products. <br /><br />Bags have been found in warehouse raids, and hidden among shipments of clothing. Last month, authorities uncovered 17m pesos’ worth of yellow onions inside containers labelled as holding blouses, slippers, and various household items. A few days before that, 20m pesos’ worth of onions, weighing 50,000kg, were found hidden among pastries and bread products.</p> <a href="https://www.theguardian.com/world/2023/jan/26/onion-smuggling-rackets-thrive-as-staple-becomes-a-luxury-in-philippines">Continue reading...</a>

## Good governance should bring cash rewards, insists football clubs’ body
 - [https://www.theguardian.com/football/2023/jan/26/good-governance-cash-fair-game-sustainability-index-premier-league-championship](https://www.theguardian.com/football/2023/jan/26/good-governance-cash-fair-game-sustainability-index-premier-league-championship)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:01:44+00:00
 - user: None

<ul><li>Fair Game’s ‘sustainability index’ paints troubling picture</li><li>Only two Championship clubs given a score ranked ‘good’</li></ul><p>Football clubs should be financially rewarded if they show good governance and engage properly with their fans, according to a group of clubs championing greater sustainability within the game.</p><p>A new ‘sustainability index’ created by Fair Game, which counts 34 EFL and non-league clubs among its members, paints a troubling picture of the state of England’s top two divisions. The index combines scores awarded on financial stability, good governance, fan engagement and equality standards. Weeks before the expected publication of <a href="https://www.theguardian.com/football/2022/oct/18/reform-of-english-football-delayed-by-politics-says-tracey-crouch">government plans for an independent regulator</a>, only two Championship clubs and half of the Premier League are given a score ranked ‘good’.</p> <a href="https://www.theguardian.com/football/2023/jan/26/good-governance-cash-fair-game-sustainability-index-premier-league-championship">Continue reading...</a>

## Details of long-awaited farm subsidies overhaul in England revealed
 - [https://www.theguardian.com/environment/2023/jan/26/details-long-awaited-farming-subsidies-overhaul-england-revealed](https://www.theguardian.com/environment/2023/jan/26/details-long-awaited-farming-subsidies-overhaul-england-revealed)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:01:43+00:00
 - user: None

<p>Farmers will be eligible for funding for up to 280 actions that protect environment under new system</p><ul><li><a href="https://www.theguardian.com/environment/2023/jan/26/new-farm-subsidies-regime-could-be-great-for-nature-properly-funded">New farm subsidies regime could be great for nature – if properly funded</a></li></ul><p>Farmers in England will be able to receive government funding for up to 280 different actions that protect the environment, from conserving <a href="https://www.theguardian.com/environment/2022/dec/06/farmers-urge-uk-government-fund-hedge-creation-biodiversity">hedgerows</a> to maintaining peatlands, under a comprehensive overhaul of farming subsidies.</p><p>The long-awaited announcement on Thursday shows farmers what will be expected of them if they apply for government incentives called environmental land management schemes (ELMs), worth £2.4bn a year for this parliament.</p> <a href="https://www.theguardian.com/environment/2023/jan/26/details-long-awaited-farming-subsidies-overhaul-england-revealed">Continue reading...</a>

## State-linked hackers in Russia and Iran are targeting UK groups, NCSC warns
 - [https://www.theguardian.com/technology/2023/jan/26/state-linked-hackers-in-russia-and-iran-are-targeting-uk-groups-ncsc-warns](https://www.theguardian.com/technology/2023/jan/26/state-linked-hackers-in-russia-and-iran-are-targeting-uk-groups-ncsc-warns)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:01:43+00:00
 - user: None

<p>Sophisticated campaigns against politicians and media aim to steal secrets or embarrass high-profile figures rather than to extort money</p><p>Russian and Iranian state-linked hackers are increasingly targeting British politicians, journalists and researchers with sophisticated campaigns aimed at gaining access to a person’s email, Britain’s online security agency warned on Thursday.</p><p>The National Cyber Security Centre (NCSC) issued an alert about two groups from Russia and Iran, warning those in government, defence, thinktanks and the media against clicking on malicious links from people posing as conference hosts, journalists or even colleagues.</p> <a href="https://www.theguardian.com/technology/2023/jan/26/state-linked-hackers-in-russia-and-iran-are-targeting-uk-groups-ncsc-warns">Continue reading...</a>

## UK students skipping meals because of cost of living crisis
 - [https://www.theguardian.com/education/2023/jan/26/uk-students-skipping-meals-because-of-cost-of-living-crisis](https://www.theguardian.com/education/2023/jan/26/uk-students-skipping-meals-because-of-cost-of-living-crisis)
 - RSS feed: https://www.theguardian.com/rss
 - date published: 2023-01-26 00:01:43+00:00
 - user: None

<p>One in four students say they are in danger of dropping out of university – survey</p><p>Students are skipping meals and relying on hardship funds and family support because of the cost of living crisis, with one in four saying they are in danger of dropping out of university, according to a survey.</p><p>Research carried out this month for the <a href="https://www.suttontrust.com/">Sutton Trust</a> found nearly a quarter of the 1,000 UK students interviewed said they were “less likely” to be able to complete their degree because of cost pressures, while one in three said they were cutting down on food to save money.</p> <a href="https://www.theguardian.com/education/2023/jan/26/uk-students-skipping-meals-because-of-cost-of-living-crisis">Continue reading...</a>
