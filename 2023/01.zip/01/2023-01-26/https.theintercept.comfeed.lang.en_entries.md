# Source The Intercept, Source URL:https://theintercept.com/feed/?lang=en, Source language: en-US

## White House Refuses to Say Whether Ukraine Will Receive Toxic Depleted Uranium Ammo
 - [https://theintercept.com/2023/01/26/ukraine-uranium-bradley-fighting-vehicle/](https://theintercept.com/2023/01/26/ukraine-uranium-bradley-fighting-vehicle/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-26 23:36:48+00:00
 - user: None

<p>A Biden official wouldn’t disclose whether Bradley Fighting Vehicles will be equipped with the anti-tank rounds, linked to cancer and birth defects.</p>
<p>The post <a href="https://theintercept.com/2023/01/26/ukraine-uranium-bradley-fighting-vehicle/" rel="nofollow">White House Refuses to Say Whether Ukraine Will Receive Toxic Depleted Uranium Ammo</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Local Cops Harassed and Threatened U.S. Veteran Because of Terror Watchlist, Lawsuit Says
 - [https://theintercept.com/2023/01/26/terror-watchlist-police-harassment/](https://theintercept.com/2023/01/26/terror-watchlist-police-harassment/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-26 21:54:45+00:00
 - user: None

<p>Police officers once leveled guns at Saadiq Long, a veteran with no criminal record — a result of the feds coordinating with local authorities on their watchlist.</p>
<p>The post <a href="https://theintercept.com/2023/01/26/terror-watchlist-police-harassment/" rel="nofollow">Local Cops Harassed and Threatened U.S. Veteran Because of Terror Watchlist, Lawsuit Says</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## NIH Urged to Consider Banning Wuhan Institute of Virology From Future Grants
 - [https://theintercept.com/2023/01/26/coronavirus-nih-ecohealth-wuhan/](https://theintercept.com/2023/01/26/coronavirus-nih-ecohealth-wuhan/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-26 21:40:19+00:00
 - user: None

<p>The Wuhan lab has continued to stonewall NIH and EcoHealth Alliance on scientific documentation, an inspector general report confirmed.</p>
<p>The post <a href="https://theintercept.com/2023/01/26/coronavirus-nih-ecohealth-wuhan/" rel="nofollow">NIH Urged to Consider Banning Wuhan Institute of Virology From Future Grants</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

## Apple Brings Mainland Chinese Web Censorship to Hong Kong
 - [https://theintercept.com/2023/01/26/apple-china-censorship-hong-kong-gitlab/](https://theintercept.com/2023/01/26/apple-china-censorship-hong-kong-gitlab/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-01-26 11:00:22+00:00
 - user: None

<p>Apple quietly expanded the use of Chinese company Tencent’s website blacklist to users in Hong Kong — and no one will answer questions about it.</p>
<p>The post <a href="https://theintercept.com/2023/01/26/apple-china-censorship-hong-kong-gitlab/" rel="nofollow">Apple Brings Mainland Chinese Web Censorship to Hong Kong</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>
