# Source Fox News, Source URL:https://moxie.foxnews.com/google-publisher/latest.xml, Source language: en-US

## Britney Spears says fans went a 'little too far,' 'invaded' privacy in calls that prompted welfare check
 - [https://www.foxnews.com/entertainment/britney-spears-says-fans-went-little-too-far-invaded-privacy-calls-prompted-welfare-check](https://www.foxnews.com/entertainment/britney-spears-says-fans-went-little-too-far-invaded-privacy-calls-prompted-welfare-check)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:40:54+00:00
 - user: None

Britney Spears called out fans for invading her privacy this week when calls to the Ventura County Sheriff's Office prompted a welfare check by deputies.

## Arkansas Supreme Court overrules judge on mask mandate ban
 - [https://www.foxnews.com/us/arkansas-supreme-court-overrules-judge-mask-mandate-ban](https://www.foxnews.com/us/arkansas-supreme-court-overrules-judge-mask-mandate-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:31:45+00:00
 - user: None

The Arkansas Supreme Court has overruled a lower court judge's decision to strike down a public sector mask mandate ban, which lawmakers have been looking to reinstate.

## Critics rip new nationwide school program pushing community-set standards, warn it uses kids as 'experiments'
 - [https://www.foxnews.com/media/critics-rip-new-nationwide-school-program-pushing-community-set-standards-warn-it-uses-kids-as-experiments](https://www.foxnews.com/media/critics-rip-new-nationwide-school-program-pushing-community-set-standards-warn-it-uses-kids-as-experiments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:30:21+00:00
 - user: None

Educators at 120 districts across the country are implementing a new curriculum that critics believe undermines parental rights to unwittingly sign their children up for the 'social educational experiment.'

## Chiefs' Willie Gay says 'nothing' impresses him about Bengals' offense
 - [https://www.foxnews.com/sports/chiefs-lwillie-gay-nothing-impresses-him-about-bengals-offense](https://www.foxnews.com/sports/chiefs-lwillie-gay-nothing-impresses-him-about-bengals-offense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:28:44+00:00
 - user: None

Kansas City Chiefs linebacker Willie Gay might have given the Cincinnati Bengals some bulletin-board material after saying their offense doesn't impress him.

## Biden slams critics who don't think U.S. can lead the world in manufacturing
 - [https://www.foxnews.com/politics/biden-slams-critics-think-u-s-lead-the-world-manufacturing](https://www.foxnews.com/politics/biden-slams-critics-think-u-s-lead-the-world-manufacturing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:26:54+00:00
 - user: None

President Biden slammed critics on Thursday, who do not believe America can lead the world in manufacturing, after boasting the creation of 750,000 jobs during his first two years.

## Kansas man charged in fire that killed 2 small children and girlfriend
 - [https://www.foxnews.com/us/kansas-man-charged-fire-killed-2-small-children-girlfriend](https://www.foxnews.com/us/kansas-man-charged-fire-killed-2-small-children-girlfriend)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:24:52+00:00
 - user: None

A Kansas man was charged Wesnesday for his part in a fire that killed two children and his girlfriend. Kyle Tyler was treated for smoke inhalation when he was found outside the home.

## Super Bowl champ's brother found guilty in murders of 2 women
 - [https://www.foxnews.com/sports/super-bowl-champs-brother-found-guilty-murders-2-women](https://www.foxnews.com/sports/super-bowl-champs-brother-found-guilty-murders-2-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:22:21+00:00
 - user: None

Former Pittsburgh Steelers wide receiver Antwaan Randle El's brother, Marcus, a former Wisconsin Badger, has been found guilty of murdering two women nearly three years ago.

## Biden says Tyre Nichols death a 'painful reminder' of 'disparately impacted' minorities in justice system
 - [https://www.foxnews.com/politics/president-biden-says-tyre-nichols-death-painful-reminder-criminal-justice-work-needs-happen](https://www.foxnews.com/politics/president-biden-says-tyre-nichols-death-painful-reminder-criminal-justice-work-needs-happen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:22:18+00:00
 - user: None

President Biden said in a statement on Thursday that Tyre Nichols death is a "painful reminder" of criminal justice work that needs to take place.

## Chiefs’ Patrick Mahomes says sprained ankle is ‘probably better than I expected’ ahead of AFC Championship
 - [https://www.foxnews.com/sports/chiefs-patrick-mahomes-says-sprained-ankle-probably-better-than-i-expected-ahead-afc-championship](https://www.foxnews.com/sports/chiefs-patrick-mahomes-says-sprained-ankle-probably-better-than-i-expected-ahead-afc-championship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:19:33+00:00
 - user: None

Patrick Mahomes says his sprained ankle is "probably better than I expected" as the Kansas City Chiefs prepare to play the Cincinnati Bengals on Sunday.

## Former Florida police officers accused of beating homeless man
 - [https://www.foxnews.com/us/former-florida-police-officers-accused-beating-homeless-man](https://www.foxnews.com/us/former-florida-police-officers-accused-beating-homeless-man)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 23:16:52+00:00
 - user: None

Two former Florida police officers have been accused of beating a homeless man who had been drinking outside a shopping center. The two officers turned themselves in on Thursday morning.

## Ellen Greenberg's parents vow to keep up fight for justice 12 years after brutal stabbing ruled suicide
 - [https://www.foxnews.com/us/ellen-greenbergs-parents-vow-fight-for-justice-12-years-after-brutal-stabbing-ruled-suicide](https://www.foxnews.com/us/ellen-greenbergs-parents-vow-fight-for-justice-12-years-after-brutal-stabbing-ruled-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:44:28+00:00
 - user: None

Ellen Greenberg's family is still fighting for justice 12 years after she was found dead in her Philadelphia apartment under suspicious circumstances.

## Evidence in case against Illinois July 4 shooter's father goes before grand jury
 - [https://www.foxnews.com/us/evidence-case-against-illinois-july-4-shooters-father-grand-jury](https://www.foxnews.com/us/evidence-case-against-illinois-july-4-shooters-father-grand-jury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:42:15+00:00
 - user: None

Robert Crimo Jr. is charged with seven felony counts for his alleged role in his son, Robert III's perpetration of the July 4, 2022 parade shooting in Highland Park, Illinois.

## Convicted drug trafficker sentenced in overdose, dismemberment case
 - [https://www.foxnews.com/us/convicted-drug-trafficker-sentenced-overdose-dismemberment-case](https://www.foxnews.com/us/convicted-drug-trafficker-sentenced-overdose-dismemberment-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:40:28+00:00
 - user: None

A convicted drug trafficker was sentenced to 50 years in prison for his involvement in an overdose and dismemberment case. The man traveled from Georgia to West Virginia to sell drugs.

## ‘White’ federal workers would no longer include Middle Eastern, North African heritage under new Biden plan
 - [https://www.foxnews.com/politics/white-federal-workers-no-longer-include-middle-eastern-north-african-heritage-under-biden-plan](https://www.foxnews.com/politics/white-federal-workers-no-longer-include-middle-eastern-north-african-heritage-under-biden-plan)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:36:26+00:00
 - user: None

The Biden administration on Thursday proposed several changes to the way the federal government collects data on the race and ethnicity of federal workers.

## Louisiana Jeffrey Dahmer copycat sentenced for Grindr dating app scheme to kidnap, murder men
 - [https://www.foxnews.com/us/louisiana-jeffrey-dahmer-copycat-sentenced-grindr-dating-app-scheme-kidnap-murder-men](https://www.foxnews.com/us/louisiana-jeffrey-dahmer-copycat-sentenced-grindr-dating-app-scheme-kidnap-murder-men)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:35:42+00:00
 - user: None

Chance Seneca, 21, of Lafayette, Louisiana, was sentenced to 45 years in prison on Wednesday for plotting to kidnap and murder gay men through the dating app Grindr.

## Georgia agency approves rules for medical marijuana sales
 - [https://www.foxnews.com/us/georgia-agency-approves-rules-medical-marijuana-sales](https://www.foxnews.com/us/georgia-agency-approves-rules-medical-marijuana-sales)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:33:57+00:00
 - user: None

A Georgia agency has approved rules for medical marijuana sales, expected to start in the coming months. Georgia's Medical Cannabis Commission voted unanimously to approve new rules.

## DoJ says 7 arrested in $7.5M PPP fraud scheme
 - [https://www.foxnews.com/us/doj-says-7-arrested-7-5m-ppp-fraud-scheme](https://www.foxnews.com/us/doj-says-7-arrested-7-5m-ppp-fraud-scheme)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:30:53+00:00
 - user: None

Seven people have been arrested in connection with a scheme to defraud the federal government for $7.5 million through the Paycheck Protection Program, the Justice Department reports.

## Children’s hospital president promotes 'anti-racism' book for White women: ‘Deconstructing Karen’
 - [https://www.foxnews.com/media/childrens-hospital-president-promotes-anti-racism-book-white-women](https://www.foxnews.com/media/childrens-hospital-president-promotes-anti-racism-book-white-women)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:30:21+00:00
 - user: None

The CEO of a Canadian children's hospital was slammed by Twitter users for suggesting her friends read a book on how White women can unlearn their racism.

## Rhode Island cop acquitted in teen's shooting
 - [https://www.foxnews.com/us/rhode-island-cop-acquitted-teens-shooting](https://www.foxnews.com/us/rhode-island-cop-acquitted-teens-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:29:21+00:00
 - user: None

Daniel Dolan, an off-duty Pawtucket, Rhode Island, police officer who shot and wounded an 18-year-old he witnessed speeding, was cleared of four charges Thursday.

## Biden admin moves against planned Minnesota mining project
 - [https://www.foxnews.com/politics/biden-admin-moves-against-planned-minnesota-mining-project](https://www.foxnews.com/politics/biden-admin-moves-against-planned-minnesota-mining-project)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 22:27:42+00:00
 - user: None

The Biden administration has begun to move to stop a planned mining project in the northeastern Minnesota wilderness from getting underway.

## Former Virginia Teacher Union president arrested for embezzling over $400K
 - [https://www.foxnews.com/sports/former-virginia-teacher-union-president-arrested-embezzling-over](https://www.foxnews.com/sports/former-virginia-teacher-union-president-arrested-embezzling-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:43:49+00:00
 - user: None

The former president of the Arlington Education Association has been arrested and charged with multiple felonies after police say she stole hundreds of thousands of thousands from the organization.

## Tyre Nichols death: Shelby County DA says all 5 officers responsible, video to be released Friday evening
 - [https://www.foxnews.com/us/tyre-nichols-death-shelby-county-da-says-all-5-officers-responsible-video-released-friday-evening](https://www.foxnews.com/us/tyre-nichols-death-shelby-county-da-says-all-5-officers-responsible-video-released-friday-evening)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:38:55+00:00
 - user: None

District Attorney Steve Mulroy said during a Thursday press conference that the video showing the confrontation between Tyre Nichols and Memphis police officers will be released Friday.

## DeSantis rejects 'woke' cash bail reform: 'An ideological agenda'
 - [https://www.foxnews.com/politics/desantis-rejects-woke-miami-cash-bail-reform-ideological-agenda](https://www.foxnews.com/politics/desantis-rejects-woke-miami-cash-bail-reform-ideological-agenda)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:36:29+00:00
 - user: None

Republican Florida Gov. Ron DeSantis said his administration would continue to reject the "ideological agenda" of eliminating cash bail.

## Michigan court throttles planned minimum wage hike
 - [https://www.foxnews.com/politics/michigan-court-throttles-planned-minimum-wage-hike](https://www.foxnews.com/politics/michigan-court-throttles-planned-minimum-wage-hike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:32:51+00:00
 - user: None

The Michigan Court of Appeals has ruled a 2018 move by Republicans in the state legislature to stem a nearly $3 minimum wage hike to be constituional.

## Biden official who pushed to ban gas stoves calls anger over it ‘misdirected’
 - [https://www.foxnews.com/media/biden-official-pushed-ban-gas-stoves-calls-anger-misdirected](https://www.foxnews.com/media/biden-official-pushed-ban-gas-stoves-calls-anger-misdirected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:30:37+00:00
 - user: None

Richard Trumpka Jr. told the Washington Post the anger over his suggestion the government ban gas stoves due to health concerns was 'misdirected.'

## US kills key ISIS facilitator Bilal al-Sudani, 10 operatives in counterterrorism mission in Somalia
 - [https://www.foxnews.com/politics/us-kills-key-isis-facilitator-bilal-sudani-operatives-counterterrorism-mission-somalia](https://www.foxnews.com/politics/us-kills-key-isis-facilitator-bilal-sudani-operatives-counterterrorism-mission-somalia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:30:18+00:00
 - user: None

The U.S. military killed a key ISIS facilitator Bilal al-Sudani and about10 ISIS operatives in a counterterrorism mission that saw no casualties among American service members or civilians.

## Madison Square Garden CEO James Dolan threatens to stop alcohol sales at Rangers game
 - [https://www.foxnews.com/sports/madison-square-garden-ceo-james-dolan-threatens-stop-alcohol-sales-rangers-game](https://www.foxnews.com/sports/madison-square-garden-ceo-james-dolan-threatens-stop-alcohol-sales-rangers-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:27:50+00:00
 - user: None

As the New York State Liquor Authority investigates MSG regarding its facial recognition technology, CEO James Dolan said he may stop alcohol sales completely at a future Rangers game.

## New Mexico school bus failed to yield before collision
 - [https://www.foxnews.com/us/new-mexico-school-bus-failed-yield-collision](https://www.foxnews.com/us/new-mexico-school-bus-failed-yield-collision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:26:49+00:00
 - user: None

New Mexico police said that a school bus that collided with a tractor-trailer failed to yield on Wednesday. Officials said one student suffered critical injuries.

## German victims of fatal train attack identified as 2 teens
 - [https://www.foxnews.com/world/german-victims-fatal-train-attack-identified-2-teens](https://www.foxnews.com/world/german-victims-fatal-train-attack-identified-2-teens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:24:23+00:00
 - user: None

German victims of a fatal train attack Wednesday afternoon have been identified as two teenagers. There is an ongoing investigation into the suspect's motive.

## Indian businessman charged with organized crime in Bosnia
 - [https://www.foxnews.com/world/indian-businessman-charged-organized-crime-bosnia](https://www.foxnews.com/world/indian-businessman-charged-organized-crime-bosnia)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 21:22:33+00:00
 - user: None

An Indian businessman was charged Thursday with leading an organized crime group and aubsing his power of office while in Bosnia. The individual stole nearly $12 million from GIKIL.

## Apple users with certain old iPhone, iPad devices should install this security update
 - [https://www.foxnews.com/tech/apple-users-old-iphone-ipad-install-security-update](https://www.foxnews.com/tech/apple-users-old-iphone-ipad-install-security-update)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:42:46+00:00
 - user: None

Apple released the iOS 12.5.7 update for older generations of iPhones and iPads. The update aims to address a security vulnerability flagged by Google's Threat Analysis Group.

## Former Alabama lawmaker sues police chief claiming he was 'set-up' by political enemies
 - [https://www.foxnews.com/us/former-alabama-lawmaker-sues-police-chief-claiming-set-political-enemies](https://www.foxnews.com/us/former-alabama-lawmaker-sues-police-chief-claiming-set-political-enemies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:40:52+00:00
 - user: None

A former Alabama lawmaker is suing the city of Montgomery and its police chief claiming he was set-up in a sex abuse charge. Former Rep. Perry Hooper Jr. claims political motive in case.

## NYC bike path terror attack: Sayfullo Saipov convicted on all counts
 - [https://www.foxnews.com/us/nyc-bike-path-terror-attack-sayfullo-saipov-convicted-counts](https://www.foxnews.com/us/nyc-bike-path-terror-attack-sayfullo-saipov-convicted-counts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:40:20+00:00
 - user: None

Sayfullo Saipov, the man who killed eight people when he sped down a bike path in a rental truck along the Hudson River in an ISIS-inspired attack, was convicted on all 28 counts on Thursday.

## Sylvester Stallone refutes Pamela Anderson's claims he offered her gifts to be his 'No 1. girl'
 - [https://www.foxnews.com/entertainment/sylvester-stallone-refutes-pamela-andersons-claims-offered-gifts-be-no-1-girl](https://www.foxnews.com/entertainment/sylvester-stallone-refutes-pamela-andersons-claims-offered-gifts-be-no-1-girl)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:37:21+00:00
 - user: None

Sylvester Stallone is firing back at Pamela Anderson's claims he propositioned her to be his "No. 1 girl." Anderson's allegations are reportedly made in her Netflix documentary.

## 1st legal sales of Mississippi medical marijuana are made
 - [https://www.foxnews.com/us/1st-legal-sales-mississippi-medical-marijuana-are-made](https://www.foxnews.com/us/1st-legal-sales-mississippi-medical-marijuana-are-made)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:36:36+00:00
 - user: None

The first legal sales of Mississippi medical marijuana were made on Wednesday at The Cannabis Company in Brookhaven. These were the first sales of the product since the legalization.

## Court orders Detroit museum to hold onto Van Gogh painting amid dispute with collector
 - [https://www.foxnews.com/us/court-orders-detroit-museum-hold-van-gogh-painting-dispute-collector](https://www.foxnews.com/us/court-orders-detroit-museum-hold-van-gogh-painting-dispute-collector)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:35:04+00:00
 - user: None

A federal appeals court has ordered a Detroit museum to retain possession of a Van Gogh painting amid an ongoing ownership dispute with a Brazilian collector.

## Goodyear tires subject to grand jury probe
 - [https://www.foxnews.com/us/goodyear-tires-subject-grand-jury-probe](https://www.foxnews.com/us/goodyear-tires-subject-grand-jury-probe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:33:40+00:00
 - user: None

A Los Angeles federal grand jury is conducting a criminal investigation of Goodyear over faulty tires blamed for eight car accident deaths.

## Rob Gronkowski backs return of Bill O'Brien as Patriots OC: 'I loved playing for him'
 - [https://www.foxnews.com/sports/rob-gronkowski-backs-return-obill-obrien-patriots-oc-loved-playing-for-him](https://www.foxnews.com/sports/rob-gronkowski-backs-return-obill-obrien-patriots-oc-loved-playing-for-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:33:16+00:00
 - user: None

Former Patriots tight end Rob Gronkowski is among those connected to the team who supports the decision to bring Bill O’Brien back to New England as offensive coordinator.

## Astros hire longtime Braves scouting executive Dana Brown as next GM
 - [https://www.foxnews.com/sports/astros-hire-longtime-braves-scouting-executive-dana-brown-as-next-gm](https://www.foxnews.com/sports/astros-hire-longtime-braves-scouting-executive-dana-brown-as-next-gm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:30:09+00:00
 - user: None

Dana Brown replaces James Click, who rejected a contract offer from the Astros last year and decided to publicly air his grievances with team owner Jim Crane.

## Idaho 'Cult Mom' Lori Vallow wants case dismissed over 'speedy trial' concerns after 1,169 days in jail
 - [https://www.foxnews.com/us/idaho-cult-mom-lori-vallow-wants-case-dismissed-speedy-trial-concerns-after-days-jail](https://www.foxnews.com/us/idaho-cult-mom-lori-vallow-wants-case-dismissed-speedy-trial-concerns-after-days-jail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 20:29:32+00:00
 - user: None

Lori Vallow is trying to dismiss her case after spending 1,169 days in jail since she was initially arrested in 2020, arguing her right to a speedy trial has been violated.

## Progressive group attacks Rep. Adam Schiff for failed record on Trump following Senate campaign announcement
 - [https://www.foxnews.com/politics/progressive-group-attacks-rep-adam-schiff-failed-record-trump-senate-campaign-announcement](https://www.foxnews.com/politics/progressive-group-attacks-rep-adam-schiff-failed-record-trump-senate-campaign-announcement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:50:25+00:00
 - user: None

The Progressive Change Campaign Committee accused Rep. Adam Schiff of playing the "role of Trump antagonist on TV" while failing to hold the former president accountable.

## State Dept faces backlash as nursing diplomats barred from using electronic breast pumps in their offices: rep
 - [https://www.foxnews.com/politics/state-dept-faces-backlash-nursing-diplomats-barred-from-using-electronic-breast-pumps-their-offices-rep](https://www.foxnews.com/politics/state-dept-faces-backlash-nursing-diplomats-barred-from-using-electronic-breast-pumps-their-offices-rep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:49:08+00:00
 - user: None

Nursing mothers working as U.S. diplomats are facing problems at some embassies, where security has not allowed them to bring electronic breast pumps into their offices.

## 'New' 1969 Chevrolet Camaros on sale for a small fortune — here's why
 - [https://www.foxnews.com/auto/new-1969-chevrolet-camaro-sale-fortune](https://www.foxnews.com/auto/new-1969-chevrolet-camaro-sale-fortune)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:44:46+00:00
 - user: None

Finale Speed has unveiled a 1969 Chevrolet Camaro that's been completely recreated with lightweight carbon fiber bodywork and a modern drivetrain.

## Hunter Biden’s art dealer praises first son, says his perspective is 'very much needed' as probes heat up
 - [https://www.foxnews.com/politics/hunter-bidens-art-dealer-praises-first-son-perspective-much-needed-probes-heat-up](https://www.foxnews.com/politics/hunter-bidens-art-dealer-praises-first-son-perspective-much-needed-probes-heat-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:43:36+00:00
 - user: None

Hunter Biden’s art dealer said Thursday that the first son's "art gives us hope; it reminds us that tomorrow brings a new day, a new beginning, a new possibility."

## Alabama father and son catch record-breaking, 162-pound alligator gar
 - [https://www.foxnews.com/lifestyle/alabama-father-son-catch-record-breaking-162-pound-alligator-gar](https://www.foxnews.com/lifestyle/alabama-father-son-catch-record-breaking-162-pound-alligator-gar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:36:00+00:00
 - user: None

A father and son from Alabama caught an alligator gar on Thanksgiving and the 100-plus pound fish was officially recognized as a new state fishing record in January 2023.

## Panthers hire Frank Reich to be next head coach
 - [https://www.foxnews.com/sports/panthers-hire-frank-reich-next-head-coach](https://www.foxnews.com/sports/panthers-hire-frank-reich-next-head-coach)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:35:24+00:00
 - user: None

The Carolina Panthers are hiring their first-ever quarterback, Frank Reich, to be their next head coach after he spent the last five seasons with the Colts.

## South Dakota legislator claims she was punished for vaccine views
 - [https://www.foxnews.com/politics/south-dakota-legislator-claims-punished-vaccine-views](https://www.foxnews.com/politics/south-dakota-legislator-claims-punished-vaccine-views)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:31:16+00:00
 - user: None

Republican South Dakota state Sen. Julie Frye-Mueller claims she lost her committee assignments for speaking out against childhood vaccination requirements.

## Former Lions linebacker Jessie Lemonier dead at 25: 'Gone far too soon'
 - [https://www.foxnews.com/sports/former-lions-linebacker-jessie-lemonier-dead](https://www.foxnews.com/sports/former-lions-linebacker-jessie-lemonier-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:22:50+00:00
 - user: None

The Detroit Lions announced Thursday that former linebacker Jessie Lemonier has died. He was 25.

## 2 alleged white supremacist gang members imprisoned for trying to kill inmate
 - [https://www.foxnews.com/us/2-alleged-white-supremacist-gang-members-imprisoned-trying-kill-inmate](https://www.foxnews.com/us/2-alleged-white-supremacist-gang-members-imprisoned-trying-kill-inmate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:19:23+00:00
 - user: None

Two people who are alledgedlly apart of a white supremacist prison gang were imprisoned for trying to kill another inmate. The two wanted to gain entry into the "Aryan Circle."

## Japan to downgrade COVID-19 classification to a less serious disease on May 8
 - [https://www.foxnews.com/health/japan-downgrade-covid-19-classification-less-serious-disease-may-8](https://www.foxnews.com/health/japan-downgrade-covid-19-classification-less-serious-disease-may-8)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 19:18:31+00:00
 - user: None

Japan is planning to downgrade its coronavirus classification on May 8. The country will revise its COVID-19 protection guidelines as well.

## Houston Police release video of suspect delivering vicious punch to driver in ‘road rage incident’
 - [https://www.foxnews.com/us/houston-police-department-video-suspect-road-rage-incident-punch](https://www.foxnews.com/us/houston-police-department-video-suspect-road-rage-incident-punch)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:36:20+00:00
 - user: None

The Houston Police Department has released footage of a driver punching another in its search for a suspect involved in a road rage incident earlier this month.

## Idaho murders: Xana Kernodle's mother says lawyer 'betrayed' her to defend Bryan Kohberger
 - [https://www.foxnews.com/us/idaho-murders-xana-kernodles-mother-lawyer-bretrayed-her-defend-bryan-kohberger](https://www.foxnews.com/us/idaho-murders-xana-kernodles-mother-lawyer-bretrayed-her-defend-bryan-kohberger)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:31:35+00:00
 - user: None

Xana Kernodle's mom said in an interview she felt 'heartbroken' and 'betrayed' after learning her lawyer withdrew to defend her daughter's alleged killer.

## Maine's lead attorney from state's first 5 public defenders resigns a month into taking the job
 - [https://www.foxnews.com/us/maines-lead-attorney-states-first-5-public-defenders-resigns-month-taking-job](https://www.foxnews.com/us/maines-lead-attorney-states-first-5-public-defenders-resigns-month-taking-job)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:29:29+00:00
 - user: None

Seth Levy, the lead attorney for a group of Maine public defenders, resigned a month into taking the job. Maine official declined to comment on the reason for Levy's resignation.

## Mike Rowe warns government enabling millions of men to quit working: 'Not letting them fail'
 - [https://www.foxnews.com/media/mike-rowe-warns-government-enabling-millions-men-quit-working-letting-them-fail](https://www.foxnews.com/media/mike-rowe-warns-government-enabling-millions-men-quit-working-letting-them-fail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:29:07+00:00
 - user: None

Mike Rowe warned millions of men have left the workforce and spend time watching television instead of looking for jobs, suggesting government handouts were to blame.

## Joel Embiid's crotch-chop celebration irks Kevin Durant; 76ers star laughs off critical tweet
 - [https://www.foxnews.com/sports/joel-embiids-crotch-chop-celebration-irks-kevin-durant-76ers-star-laughs-off-critical-tweet](https://www.foxnews.com/sports/joel-embiids-crotch-chop-celebration-irks-kevin-durant-76ers-star-laughs-off-critical-tweet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:24:52+00:00
 - user: None

Philadelphia 76ers star Joel Embiid laughed off Kevin Durant's critical tweet of his celebration following an And-1 play in his game against the Brooklyn Nets.

## IN girl who was seriously injured in Indianapolis apartment fire dies after being hospitalized for 2 weeks
 - [https://www.foxnews.com/us/girl-seriously-injured-indianapolis-apartment-fire-dies-hospitalized-2-weeks](https://www.foxnews.com/us/girl-seriously-injured-indianapolis-apartment-fire-dies-hospitalized-2-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:20:06+00:00
 - user: None

A girl who was injured in an Indiana apartment fire that hospitalized five people has died. The girl's father and 15-month-old sister also died in the fire.

## Investigators in 2022 Pittsburgh bridge collapse looking at damages to the legs of the structure
 - [https://www.foxnews.com/us/investigators-2022-pittsburgh-bridge-collapse-looking-damages-legs-structure](https://www.foxnews.com/us/investigators-2022-pittsburgh-bridge-collapse-looking-damages-legs-structure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:19:26+00:00
 - user: None

The Fern Hollow Bridge in Pittsburgh, Pennsylvania, collapsed nearly a year ago. Investigators are looking at the damage to the legs of the bridge.

## Biden administration delays protections for imperiled bat, prairie chicken
 - [https://www.foxnews.com/us/biden-administration-delays-protections-imperiled-bat-prairie-chicken](https://www.foxnews.com/us/biden-administration-delays-protections-imperiled-bat-prairie-chicken)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:18:14+00:00
 - user: None

Protection efforts for imperiled prairie chickens and northern long-eared bats have been delayed. Affected industries such as ranchers have until March 31 to adjust to the change.

## Tyre Nichols case: 5 former Memphis police officers charged with second-degree murder
 - [https://www.foxnews.com/us/tyre-nichols-case-5-former-memphis-police-officers-charged-second-degree-murder](https://www.foxnews.com/us/tyre-nichols-case-5-former-memphis-police-officers-charged-second-degree-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 18:13:31+00:00
 - user: None

The 5 Memphis Police Department officers fired following the death of Tyre Nichols after a traffic stop on Jan. 7 are now facing second-degree murder charges.

## MSNBC panel melts down over Facebook ‘devil's bargain’ with Trump, warns it will end democracy
 - [https://www.foxnews.com/media/msnbc-panel-melts-down-facebook-devil-bargain-reinstate-trump-end-democracy](https://www.foxnews.com/media/msnbc-panel-melts-down-facebook-devil-bargain-reinstate-trump-end-democracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:29:36+00:00
 - user: None

The "Morning Joe" panel called the move to reinstate Former President Trump "ridiculous" and "mystifying" and suggested it could destroy U.S. democracy

## Homeless UK man stops armed driver's drug-fueled rampage: 'I had to act'
 - [https://www.foxnews.com/world/homeless-uk-man-stops-armed-drivers-drug-fueled-rampage-i-had-to-act](https://www.foxnews.com/world/homeless-uk-man-stops-armed-drivers-drug-fueled-rampage-i-had-to-act)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:28:47+00:00
 - user: None

A homeless man in England was praised by police for his actions in helping subdue an armed driver who was high on drugs when he struck a cyclist and attempted to flee the scene.

## Alex Murdaugh hysterical but dry-eyed at crime scene, body cam shows
 - [https://www.foxnews.com/us/alex-murdaugh-hysterical-dry-eyed-crime-scene-body-cam-shows](https://www.foxnews.com/us/alex-murdaugh-hysterical-dry-eyed-crime-scene-body-cam-shows)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:27:48+00:00
 - user: None

Alex Murdaugh was hysterical but had no 'physical tears' after he says he found the slain bodies of his wife and youngest son, a prosecution witness testified Thursday.

## German government calls for tougher restrictions on advertising of alcohol, tobacco, sports betting
 - [https://www.foxnews.com/world/german-government-calls-tougher-restrictions-advertising-alcohol-tobacco-sports-betting](https://www.foxnews.com/world/german-government-calls-tougher-restrictions-advertising-alcohol-tobacco-sports-betting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:27:43+00:00
 - user: None

Government officials in Germany, such as Burkhard Blienert, are pushing for more restrictions on advertisements featuring tobacco, sports gambling, and alcohol in the country.

## AZ Gov. Katie Hobbs creates commission to study state’s prison problems
 - [https://www.foxnews.com/politics/az-gov-katie-hobbs-creates-commission-study-states-prison-problems](https://www.foxnews.com/politics/az-gov-katie-hobbs-creates-commission-study-states-prison-problems)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:22:25+00:00
 - user: None

Arizona Gov. Katie Hobbs is creating a commission to study problems state prisons are facing, including staffing levels, mental health care, and drug treatment programs.

## Top George Soros director has frequent Biden White House access, records show
 - [https://www.foxnews.com/politics/top-george-soros-director-frequent-biden-white-house-access-records-show](https://www.foxnews.com/politics/top-george-soros-director-frequent-biden-white-house-access-records-show)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:21:38+00:00
 - user: None

A George Soros director at his nonprofit network has frequent access to President Biden's White House and appears in visitor logs 13 times on eight different days, records show.

## Pete Hegseth: Parents 'should exit' the public school system as fast as they can
 - [https://www.foxnews.com/media/pete-hegseth-parents-should-exit-public-school-system-fast-they-can](https://www.foxnews.com/media/pete-hegseth-parents-should-exit-public-school-system-fast-they-can)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:20:54+00:00
 - user: None

Pete Hegseth spoke with Fox News Digital about the newest season of Fox Nation's 'The MisEducation of America' and the corresponding live summit.

## ID lawmaker proposes legislation to reenact tougher ballot initiative rules
 - [https://www.foxnews.com/politics/id-lawmaker-proposes-legislation-reenact-tougher-ballot-initiative-rules](https://www.foxnews.com/politics/id-lawmaker-proposes-legislation-reenact-tougher-ballot-initiative-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:17:43+00:00
 - user: None

Idaho lawmakers have introduced a joint resolution that would it more difficult to get initiatives on the ballot. If approved, voters would be asked to change the state’s constitution.

## Salma Hayek shows off her curves and goes sheer for ‘Magic Mike’s Last Dance’ premiere
 - [https://www.foxnews.com/entertainment/salma-hayek-shows-off-curves-goes-sheer-magic-mikes-last-dance-premiere](https://www.foxnews.com/entertainment/salma-hayek-shows-off-curves-goes-sheer-magic-mikes-last-dance-premiere)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:15:41+00:00
 - user: None

Mexican American actress Salma Hayek stepped out on the red carpet for the "Magic Mike's Last Dance" premiere in a see-through black netted dress, embellished with floral designs.

## DOJ seizes Hive ransomware gang website
 - [https://www.foxnews.com/politics/doj-seizes-hive-ransomware-gang-website](https://www.foxnews.com/politics/doj-seizes-hive-ransomware-gang-website)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 17:01:17+00:00
 - user: None

The U.S. Department of Justice has taken hold of the website run by a ransomware group called 'Hive' which has targeted companies worldwide.

## Porsche rebooted its first car to celebrate 75th birthday
 - [https://www.foxnews.com/auto/porsche-rebooted-first-car-celebrate-birthday](https://www.foxnews.com/auto/porsche-rebooted-first-car-celebrate-birthday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:49:26+00:00
 - user: None

The Porsche 357 is a one-off car inspired by the 356 that the automaker has created to celebrate 75 years of building production sports cars.

## Sen. Rick Scott running for re-election, not for president, he says
 - [https://www.foxnews.com/politics/sen-rick-scott-running-re-election-not-president-he-says](https://www.foxnews.com/politics/sen-rick-scott-running-re-election-not-president-he-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:45:14+00:00
 - user: None

Florida Republican Sen. Rick Scott will seek re-election to the upper chamber, squashing speculation over whether he might make a presidential run in 2024.

## ESPN pundit says Jets ‘could win it all’ if New York lands this superstar quarterback
 - [https://www.foxnews.com/sports/espn-pundit-says-jets-could-win-all-new-york-lands-superstar-quarterback](https://www.foxnews.com/sports/espn-pundit-says-jets-could-win-all-new-york-lands-superstar-quarterback)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:43:01+00:00
 - user: None

ESPN pundit Stephen A. Smith said Wednesday the Jets "could win it all" if they are able to acquire Green Bay Packers quarterback Aaron Rodgers in the offseason.

## Robert Redford wore two pairs of undies to ‘protect himself' from Barbra Streisand in ‘The Way We Were’: book
 - [https://www.foxnews.com/entertainment/robert-redford-wore-two-pairs-undies-protect-himself-barbra-streisand-way-we](https://www.foxnews.com/entertainment/robert-redford-wore-two-pairs-undies-protect-himself-barbra-streisand-way-we)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:42:47+00:00
 - user: None

Robert Hofler wrote "The Way They Were: How Epic Battles and Bruised Egos Brought a Classic Hollywood Love Story to the Screen." It's timed to the film's 50th anniversary.

## Minnesota woman pleads guilty to leaving newborn to die on Mississippi River bank
 - [https://www.foxnews.com/us/minnesota-woman-pleads-guilty-leaving-newborn-die-mississippi-river-bank](https://www.foxnews.com/us/minnesota-woman-pleads-guilty-leaving-newborn-die-mississippi-river-bank)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:40:57+00:00
 - user: None

Minnesota woman Jennifer Matter, 50, admitted in a guilty plea Wednesday that she left her newborn baby boy to die on the banks of the Mississippi River back in in 2003.

## Corruption trial for former Ohio House speaker temporarily paused after juror tests positive for COVID-19
 - [https://www.foxnews.com/us/corruption-trial-former-ohio-house-speaker-temporarily-paused-after-juror-tests-positive-covid-19](https://www.foxnews.com/us/corruption-trial-former-ohio-house-speaker-temporarily-paused-after-juror-tests-positive-covid-19)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:38:10+00:00
 - user: None

Larry Householder's trial has been paused temporarily after a juror tested positive for coronavirus. Householder faces up to 20 years in the corruption trial.

## Biden and VP Harris plan spree of fundraisers ahead of expected 2024 announcement
 - [https://www.foxnews.com/politics/biden-vp-harris-plan-spree-fundraisers-expected-2024-announcement](https://www.foxnews.com/politics/biden-vp-harris-plan-spree-fundraisers-expected-2024-announcement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:37:32+00:00
 - user: None

President Biden and Vice President Harris will begin fundraising in earnest in the coming, starting off with two events in New York City and Philadelphia next week.

## US authorities see 97% decline in illegal border crossings by migrants from Cuba, Haiti, Nicaragua, Venezuela
 - [https://www.foxnews.com/us/us-authorities-97-decline-illegal-border-crossings-migrants-cuba-haiti-nicaragua-venezuela](https://www.foxnews.com/us/us-authorities-97-decline-illegal-border-crossings-migrants-cuba-haiti-nicaragua-venezuela)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:34:23+00:00
 - user: None

The Biden administration announced a 97% decrease in illegal border crossings by migrants from Cuba, Venezuela, Nicaragua, and Haiti after Mexico began accepting migrants.

## California mass shooting: Gunman Huu Can Tran didn’t know Monterey Park dance hall victims, sheriff says
 - [https://www.foxnews.com/us/california-mass-shooting-gunman-huu-can-tran-didnt-know-monterey-park-dance-hall-victims-sheriff-says](https://www.foxnews.com/us/california-mass-shooting-gunman-huu-can-tran-didnt-know-monterey-park-dance-hall-victims-sheriff-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:33:44+00:00
 - user: None

Los Angeles County Sheriff Robert Luna on Wednesday said that a motive for the mass shooting that killed 11 people in Monterey Park, California, still eludes investigators.

## Afghan soldier who was seeking US asylum freed after spending months in immigration detention center
 - [https://www.foxnews.com/us/afghan-soldier-seeking-us-asylum-freed-spending-months-immigration-detention-center](https://www.foxnews.com/us/afghan-soldier-seeking-us-asylum-freed-spending-months-immigration-detention-center)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 16:31:39+00:00
 - user: None

Abdul Wasi Safi was freed from an immigration detention center after spending months there for trying to cross the Mexico border. Safi is an Afghan soldier who was seeking U.S. asylum.

## Chinese national who enrolled in US Army Reserves sentenced to 8 years for spying
 - [https://www.foxnews.com/us/chinese-national-enrolled-us-army-reserves-sentenced-8-years-spying](https://www.foxnews.com/us/chinese-national-enrolled-us-army-reserves-sentenced-8-years-spying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:47:43+00:00
 - user: None

Ji Chaoqun was sentenced after being found guilty of trying to recruit people who worked as engineers and scientists for U.S. defense contractors as spies for China.

## Warriors’ Steph Curry ejected for throwing mouthpiece out of frustration with teammate
 - [https://www.foxnews.com/sports/warriors-steph-curry-ejected-throwing-mouthpiece-frustration-teammate](https://www.foxnews.com/sports/warriors-steph-curry-ejected-throwing-mouthpiece-frustration-teammate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:41:36+00:00
 - user: None

Golden State Warriors star Steph Curry was ejected late in the fourth quarter against the Memphis Grizzlies for throwing his mouthpiece.

## Sen. Kennedy stumps Biden nominee with basic questions about the Constitution
 - [https://www.foxnews.com/politics/sen-kennedy-stumps-biden-nominee-basic-questions-constitution](https://www.foxnews.com/politics/sen-kennedy-stumps-biden-nominee-basic-questions-constitution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:39:34+00:00
 - user: None

Louisiana Sen. John Kennedy grilled four Biden judicial nominees on the Constitution during a confirmation hearing Wednesday and one could not answer his questions.

## Winter weather moves over Northeast after dumping snow on Michigan, Indiana
 - [https://www.foxnews.com/us/winter-weather-northeast-snow-michigan-indiana](https://www.foxnews.com/us/winter-weather-northeast-snow-michigan-indiana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:37:58+00:00
 - user: None

Severe winter weather is expected to continue to track eastward on Thursday. Snow, sleet and freezing rain from the storm was forecast to impact travel conditions.

## Florida man charged in Microsoft executive Jared Bridegan's murder held without bond
 - [https://www.foxnews.com/us/florida-man-charged-microsoft-executive-jared-bridegan-murder-held-bond](https://www.foxnews.com/us/florida-man-charged-microsoft-executive-jared-bridegan-murder-held-bond)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:36:29+00:00
 - user: None

Henry Tenon, 61, faced a judge in a Duval County courtroom on Thursday morning, when he was ordered held without bond in connection with the most serious charge: murder.

## North Carolina police find razor blades inside pumps at several gas stations: 'Evil thing to do'
 - [https://www.foxnews.com/us/north-carolina-police-find-razor-blades-inside-pumps-several-gas-stations-evil-thing-do](https://www.foxnews.com/us/north-carolina-police-find-razor-blades-inside-pumps-several-gas-stations-evil-thing-do)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:33:17+00:00
 - user: None

Police are investigating after razor blades were found inside the handles of gas pumps in multiple locations across a county in western North Carolina.

## Rep. Comer vows to probe Hunter Biden’s art sales, dealer’s China connections: 'It is deeply concerning'
 - [https://www.foxnews.com/politics/rep-comer-vows-probe-hunter-bidens-art-sales-dealers-china-connections-deeply-concerning](https://www.foxnews.com/politics/rep-comer-vows-probe-hunter-bidens-art-sales-dealers-china-connections-deeply-concerning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:32:43+00:00
 - user: None

Rep. James Comer, R-Ky., chairman of the House Committee on Oversight and Accountability, vowed Wednesday to "get to the bottom" of Hunter Biden's art sales.

## Shakira's ex Gerard Piqué goes public with new girl Clara Chia Marti, 23, after being burned in diss track
 - [https://www.foxnews.com/entertainment/shakiras-ex-gerard-pique-goes-public-new-girl-clara-chia-marti-23-being-burned-diss-track](https://www.foxnews.com/entertainment/shakiras-ex-gerard-pique-goes-public-new-girl-clara-chia-marti-23-being-burned-diss-track)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:27:25+00:00
 - user: None

Shakira's ex-partner Gerard Piqué is not letting her diss track stand in the way of his new relationship. The former soccer player posted a photo with girlfriend Clara Chia Marti on Instagram.

## Syrian Kurdish-led forces capture Islamic State group commander in eastern Syria
 - [https://www.foxnews.com/world/syrian-kurdish-forces-capture-islamic-state-group-commander-eastern-syria](https://www.foxnews.com/world/syrian-kurdish-forces-capture-islamic-state-group-commander-eastern-syria)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:24:58+00:00
 - user: None

An Islamic State group commander was captured in Ragga by Syrian Kurdish-led forces. He was among the 68 militants who were detained in an operation targeting sleeper cells.

## ‘Satanic golden medusa’ abortion statue outside New York City courthouse ruthlessly mocked: ‘Monstrosity’
 - [https://www.foxnews.com/media/satanic-golden-medusa-abortion-statue-new-york-city-courthouse-ruthlessly-mocked-monstrosity](https://www.foxnews.com/media/satanic-golden-medusa-abortion-statue-new-york-city-courthouse-ruthlessly-mocked-monstrosity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:23:43+00:00
 - user: None

The "Now" statue placed atop a New York City courthouse was slammed by Twitter users who compared the art piece to demons, aliens, and sci-fi characters.

## Danish teen charged with joining international white supremacist group, trying to recruit others to join
 - [https://www.foxnews.com/world/danish-teen-charged-joining-international-white-supremacist-group-trying-recruit-others-join](https://www.foxnews.com/world/danish-teen-charged-joining-international-white-supremacist-group-trying-recruit-others-join)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:11:05+00:00
 - user: None

A teen from Denmark was charged with joining a white supremacist group that the country has described as neo-Nazi. The teen also tried to recruit others to join the group.

## Boston Mayor Michelle Wu wants to reach peak population while guarding against surging housing costs
 - [https://www.foxnews.com/us/boston-mayor-michelle-wu-reach-peak-population-guarding-against-surging-housing-costs](https://www.foxnews.com/us/boston-mayor-michelle-wu-reach-peak-population-guarding-against-surging-housing-costs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:10:40+00:00
 - user: None

Boston's mayor announced that she wants to avoid surging housing prices as the population continues to grow. The rise in housing prices has pushed low-income residents out of the city.

## Novak Djokovic's father spotted posing for pictures with pro-Russia supporters at Australian Open
 - [https://www.foxnews.com/sports/novak-djokovics-father-spotted-posing-pictures-pro-russia-supporters](https://www.foxnews.com/sports/novak-djokovics-father-spotted-posing-pictures-pro-russia-supporters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:06:21+00:00
 - user: None

Srdjan Djokovic, the father of Novak Djokovic, was spotted posing for a picture with pro-Russian supporters at the Australian Open.

## New 'Hook' malware allows hijacking, real-time spying on Android devices
 - [https://www.foxnews.com/tech/new-hook-malware-allows-hijacking-real-time-spying-android-devices](https://www.foxnews.com/tech/new-hook-malware-allows-hijacking-real-time-spying-android-devices)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:00:49+00:00
 - user: None

A new banking app for Android devices called Hook contains malware that could leave your Android device susceptible to remote hacking.

## Biden is derelict in his duty on the debt limit. It's time for him to step up and get in the game
 - [https://www.foxnews.com/opinion/biden-derelict-duty-debt-limit-step-up-game](https://www.foxnews.com/opinion/biden-derelict-duty-debt-limit-step-up-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:00:48+00:00
 - user: None

Economists say the U.S. is likely to reach the drop-dead date to pay its bills later this summer. It is time for the White House to engage in serious, bipartisan conversations.

## California lawmaker wants reparations proposal to be a nationwide ‘blueprint,’ beyond ‘financial compensation’
 - [https://www.foxnews.com/media/california-lawmaker-reparations-proposal-nationwide-blueprint-beyond-financial-compensation](https://www.foxnews.com/media/california-lawmaker-reparations-proposal-nationwide-blueprint-beyond-financial-compensation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:00:25+00:00
 - user: None

A Democratic state lawmaker and a member of the California reparations committee believes their proposal for reparations will be the roadmap for the rest of the country.

## 'Jersey Shore' star 'The Situation' had to 'force accountability' after prison, credits sobriety for success
 - [https://www.foxnews.com/entertainment/jersey-shore-star-the-situation-force-accountability-after-prison-credits-sobriety-success](https://www.foxnews.com/entertainment/jersey-shore-star-the-situation-force-accountability-after-prison-credits-sobriety-success)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 15:00:13+00:00
 - user: None

Mike "The Situation" Sorrentino said his positivity helped change the negative narrative after prison. He found fame on the "Jersey Shore" nearly 15 years ago.

## Russia reacts to US, Germany tank deliveries to Ukraine: 'Direct involvement in the conflict'
 - [https://www.foxnews.com/world/russia-reacts-us-germany-tank-deliveries-ukraine-direct-involvement-conflict](https://www.foxnews.com/world/russia-reacts-us-germany-tank-deliveries-ukraine-direct-involvement-conflict)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 14:58:59+00:00
 - user: None

Russia on Thursday responded to President Biden's decision to send Abrams M1 tanks to Ukraine and accused it of "direct involvement in the conflict."

## Nixed your New Year’s resolutions already? This mom moved past 'failure,' found joy in a 'positive past'
 - [https://www.foxnews.com/lifestyle/nixed-new-years-resolutions-mom-moved-past-failure-found-joy-positive-past](https://www.foxnews.com/lifestyle/nixed-new-years-resolutions-mom-moved-past-failure-found-joy-positive-past)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 14:48:47+00:00
 - user: None

A mom of four in Florida shares her tips and advice for getting past New Year's resolutions that may have failed already — and staying focused and positive on making the best of a New Year.

## Sen. Wicker pledges 'rigorous' oversight of Ukraine aid as conflict reaches tipping point
 - [https://www.foxnews.com/politics/wicker-pledges-rigorous-oversight-ukraine-aid-conflict-reaches-tipping-point](https://www.foxnews.com/politics/wicker-pledges-rigorous-oversight-ukraine-aid-conflict-reaches-tipping-point)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 14:44:47+00:00
 - user: None

Sen. Wicker plans to use his first floor speech as the top SASC Republican to note the high importance of making clear the United States' interest in Ukraine.

## Philadelphia teen street gang burglarized multiple Pennsylvania gun stores, stole nearly 100 firearms, DA says
 - [https://www.foxnews.com/us/philadelphia-teen-street-gang-burglarized-multiple-pennsylvania-gun-stores-stole-nearly-100-firearms-da-says](https://www.foxnews.com/us/philadelphia-teen-street-gang-burglarized-multiple-pennsylvania-gun-stores-stole-nearly-100-firearms-da-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 14:13:50+00:00
 - user: None

Philadelphia's so-called "54th Street" neighborhood gang of teens burglarized three gun stores across Pennsylvania last year, stealing nearly 100 firearms, authorities said.

## DeSantis' rejection of AP course 'carries the stench of white slaveowners,' claims Boston Globe opinion piece
 - [https://www.foxnews.com/media/desantis-rejection-ap-course-carries-stench-white-slaveowners-claims-boston-globe-opinion-piece](https://www.foxnews.com/media/desantis-rejection-ap-course-carries-stench-white-slaveowners-claims-boston-globe-opinion-piece)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 14:08:32+00:00
 - user: None

Boston Globe opinion columnist Renée Graham joined the chorus of criticism against Gov. Ron DeSantis' decision to ban an AP African-American studies class for 'woke' content.

## Got an iPad? Apple just gave it an amazing new trick
 - [https://www.foxnews.com/tech/got-ipad-apple-just-gave-it-amazing-new-trick](https://www.foxnews.com/tech/got-ipad-apple-just-gave-it-amazing-new-trick)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:56:57+00:00
 - user: None

Using an iPad just got easier. Kurt "CyberGuy" Knutsson explains the new iOS update that adds a feature called Stage Manager, which iPad users might find useful.

## United States new ambassador to Russia arrives in Moscow
 - [https://www.foxnews.com/world/united-states-new-ambassador-russia-arrives-moscow](https://www.foxnews.com/world/united-states-new-ambassador-russia-arrives-moscow)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:55:20+00:00
 - user: None

Lynne Tracy, the new U.S. ambassador to Russia, traveled to Moscow Thursday. Tensions between the United States and Russia have recently been high as the war in Ukraine continues.

## NYPD officer goes to court over punishment for Trump patch, says she left judge 'speechless'
 - [https://www.foxnews.com/media/nypd-officer-goes-court-punishment-trump-patch-says-left-judge-speechless](https://www.foxnews.com/media/nypd-officer-goes-court-punishment-trump-patch-says-left-judge-speechless)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:53:22+00:00
 - user: None

NYPD Sgt. Dana Martillo asked a judge to overturn lost pay over a pro-Trump patch worn on duty, alleging her administrative trial was "very biased and politically motivated."

## The 'incredible' Tesla Cybertruck might go on sale this summer, but not to many of them
 - [https://www.foxnews.com/auto/incredible-tesla-cybertruck-sale-summer](https://www.foxnews.com/auto/incredible-tesla-cybertruck-sale-summer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:52:16+00:00
 - user: None

Tesla is installing the machinery needed to build the Cybertruck pickup and expects to begin low volume production sometime this summer in Texas.

## Serbia, caught between Europe and Russia, could move one step closer to normalizing relations with Kosovo
 - [https://www.foxnews.com/world/serbia-caught-between-europe-russia-could-move-one-step-closer-normalizing-relations-kosovo](https://www.foxnews.com/world/serbia-caught-between-europe-russia-could-move-one-step-closer-normalizing-relations-kosovo)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:49:59+00:00
 - user: None

Serbia, Russia's longtime ally in Europe, is getting pressure from European Union and U.S. officials to finally normalize relations with its former province, Kosovo, which broke away from Serbia following the 1999 NATO war against Serbia.

## Former Chicago gang member who escaped the streets to help young people shot in attack that killed 2 teens
 - [https://www.foxnews.com/us/former-chicago-gang-member-escaped-streets-help-young-people-shot-attack-killed-2-teens](https://www.foxnews.com/us/former-chicago-gang-member-escaped-streets-help-young-people-shot-attack-killed-2-teens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:49:56+00:00
 - user: None

Will Keeps, a former Chicago gang member who escaped the streets, was shot in Des Moines, Iowa. Two teens who were involved in Keep's youth program were killed in the shooting

## German authorities arrest 2nd person in treason case for passing secrets obtained by BND spy agency employee
 - [https://www.foxnews.com/world/german-authorities-arrest-2nd-person-treason-case-passing-secrets-obtained-bnd-spy-agency-employee](https://www.foxnews.com/world/german-authorities-arrest-2nd-person-treason-case-passing-secrets-obtained-bnd-spy-agency-employee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:48:02+00:00
 - user: None

A 2nd suspect has been arrested in connection with an espionage case in Germany. The man is accused of treason for passing secrets obtained by an acquaintance working at a spy agency.

## ChatGPT leads lawmakers to call for regulating artificial intelligence
 - [https://www.foxnews.com/politics/chatgpt-leads-lawmakers-call-regulating-artificial-intelligence](https://www.foxnews.com/politics/chatgpt-leads-lawmakers-call-regulating-artificial-intelligence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:34:03+00:00
 - user: None

Members of Congress are calling for the government to take action to regulate artificial intelligence, citing the sophistication of software like the ChatGPT bot.

## IOC clears path for Russian athletes to compete under Asia in upcoming Olympics
 - [https://www.foxnews.com/sports/ioc-clears-path-russian-athletes-compete-under-asia-upcoming-olympics](https://www.foxnews.com/sports/ioc-clears-path-russian-athletes-compete-under-asia-upcoming-olympics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:16:24+00:00
 - user: None

The International Olympic Committee has cleared a path for Russian and Belarusian athletes to compete in the upcoming 2024 Summer Olympics under the Council of Asia.

## 20% of Americans in Hong Kong have left for various reasons, including COVID-19 measures, in the past 2 years
 - [https://www.foxnews.com/world/20-americans-hong-kong-left-various-reasons-covid-19-measures-past-2-years](https://www.foxnews.com/world/20-americans-hong-kong-left-various-reasons-covid-19-measures-past-2-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:15:30+00:00
 - user: None

Roughly 15,000 Americans have left Hong Kong in the past two years for various reasons. Strict COVID-19 measures and "diminishing freedom" are two reasons Americans leave.

## 49ers' Deebo Samuel downplays loudness of Lincoln Financial Field ahead of NFC Championship
 - [https://www.foxnews.com/sports/49ers-deebo-samuel-downplays-loudness-lincoln-financial-field-nfc-championship](https://www.foxnews.com/sports/49ers-deebo-samuel-downplays-loudness-lincoln-financial-field-nfc-championship)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:08:12+00:00
 - user: None

San Francisco 49ers wide receiver Deebo Samuel may have given Philadelphia Eagles fans some bulletin board material for Sunday's game.

## NIH gave EcoHealth Alliance money for risky coronavirus research without proper oversight, watchdog finds
 - [https://www.foxnews.com/politics/nih-gave-ecohealth-alliance-money-risky-coronavirus-research-without-proper-oversight-watchdog-finds](https://www.foxnews.com/politics/nih-gave-ecohealth-alliance-money-risky-coronavirus-research-without-proper-oversight-watchdog-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:03:01+00:00
 - user: None

A watchdog found that the National Institutes of Health made errors in its oversight of research grants to EcoHealth Alliance to study bat coronaviruses in China.

## China could shut down our military in a minute if we don't fix the looming rare earths supply crisis
 - [https://www.foxnews.com/opinion/china-shut-down-military-minute-fix-looming-rare-earths-supply-crisis](https://www.foxnews.com/opinion/china-shut-down-military-minute-fix-looming-rare-earths-supply-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 13:00:06+00:00
 - user: None

China has already stopped the export of rare earth elements once. The odds of it happening again are 9.5 on a scale of 1 to 10. We must prepare aggressively for the future.

## Reporter's Notebook: The Ayatollah’s Off-Ramp?
 - [https://www.foxnews.com/world/reporters-notebook-the-ayatollahs-off-ramp](https://www.foxnews.com/world/reporters-notebook-the-ayatollahs-off-ramp)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:51:55+00:00
 - user: None

A former Iranian diplomat has written a letter to Iran's Supreme Leader Ayatollah Ali Khamenei appealing for him to do "the right thing," in regards to the country's protests.

## Aaron Rodgers-Jets rumors heat up with offseason weeks away
 - [https://www.foxnews.com/sports/aaron-rodgers-jets-rumors-heat-up-offseason-weeks-away](https://www.foxnews.com/sports/aaron-rodgers-jets-rumors-heat-up-offseason-weeks-away)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:41:51+00:00
 - user: None

The Aaron Rodgers to the New York Jets rumor heated up again Thursday with the official start to the NFL offseason only a few weeks away.

## Biden admin expert claims obesity cannot be treated with exercise and good diet
 - [https://www.foxnews.com/media/biden-admin-expert-claims-obesity-cannot-treated-exercise-good-diet](https://www.foxnews.com/media/biden-admin-expert-claims-obesity-cannot-treated-exercise-good-diet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:32:39+00:00
 - user: None

Dr. Fatima Cody Stanford, who said on '60 Minutes' that diet and exercise have less impact on obesity than genetics, was appointed to a USDA committee last Thursday.

## Gwyneth Paltrow’s Goop recommends ‘scandalous’ napkins, 'glamorous' lube for Valentine's Day
 - [https://www.foxnews.com/media/gwyneth-paltrows-goop-recommends-scandalous-napkins-for-valentines-day](https://www.foxnews.com/media/gwyneth-paltrows-goop-recommends-scandalous-napkins-for-valentines-day)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:30:16+00:00
 - user: None

Gwyneth Paltrow's Goop released its 2023 Valentine's Day gift guide and included a set of "scandalous" dinner napkins, nearly 50 vibrators and a 24- karat razor.

## Paul Pelosi attack video ordered to be released by California judge
 - [https://www.foxnews.com/politics/paul-pelosi-attack-video-ordered-released-california-judge](https://www.foxnews.com/politics/paul-pelosi-attack-video-ordered-released-california-judge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:24:42+00:00
 - user: None

A California judge has ordered the release of a video allegedly showing David DePape’s attack on Paul Pelosi on Oct. 28 in San Francisco.

## Pakistan's rupee plummets against the dollar as country's government agrees to comply with IMF
 - [https://www.foxnews.com/world/pakistans-rupee-plummets-against-dollar-countrys-government-agrees-comply-imf](https://www.foxnews.com/world/pakistans-rupee-plummets-against-dollar-countrys-government-agrees-comply-imf)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:20:54+00:00
 - user: None

Pakistan has agreed to comply with the International Monetary Fund as the country's rupee plummets. The country is seeking an installment of $1.1 billion from the IMF.

## Road-building, logging restrictions reinstated for Alaska’s Tongass National Forest
 - [https://www.foxnews.com/us/road-building-logging-restrictions-reinstated-alaskas-tongass-national-forest](https://www.foxnews.com/us/road-building-logging-restrictions-reinstated-alaskas-tongass-national-forest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:18:50+00:00
 - user: None

The U.S. is reinstating road-building and logging restrictions on the country’s largest national forest Tongass National Forest located in Alaska.

## Marijuana grow house in NV loses license after auditors find unregistered plants in attic, closet
 - [https://www.foxnews.com/us/marijuana-grow-house-nv-loses-license-auditors-find-unregistered-plants-attic-closet](https://www.foxnews.com/us/marijuana-grow-house-nv-loses-license-auditors-find-unregistered-plants-attic-closet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:10:36+00:00
 - user: None

A cannabis production facility in Las Vegas, Nevada, lost its license after inspectors found untagged and untested cannabis plants in the attic and closet.

## Democratic National Committee panel votes to give NH, GA more time on new primary calendar
 - [https://www.foxnews.com/politics/democratic-national-committee-panel-votes-give-nh-ga-more-time-primary-calendar](https://www.foxnews.com/politics/democratic-national-committee-panel-votes-give-nh-ga-more-time-primary-calendar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:10:10+00:00
 - user: None

Georgia and New Hampshire will receive more time to make changes to be a part of the Democratic presidential primary next year. The DNC voted 25-0 to extend the deadline until June 3.

## Michigan Gov. Whitmer plans to enact stricter gun laws, repeal abortion restrictions, provide tax relief
 - [https://www.foxnews.com/politics/michigan-gov-whitmer-plans-to-enact-stricter-gun-laws-repeal-abortion-restrictions-provide-tax-relief](https://www.foxnews.com/politics/michigan-gov-whitmer-plans-to-enact-stricter-gun-laws-repeal-abortion-restrictions-provide-tax-relief)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:01:54+00:00
 - user: None

Michigan Gov. Gretchen Whitmer gave her State of the State address on Wednesday. She plans to enact stricter gun laws, provide immediate tax relief, and repeal abortion laws.

## Kristi Noem under fire from state Freedom Caucus for allegedly overstepping South Dakota constitutional limits
 - [https://www.foxnews.com/politics/kristi-noem-fire-state-freedom-caucus-overstepping-south-dakota-constitutional-limits](https://www.foxnews.com/politics/kristi-noem-fire-state-freedom-caucus-overstepping-south-dakota-constitutional-limits)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:00:51+00:00
 - user: None

South Dakota Gov. Kristi Noem is getting heat from some state Freedom Caucus members who say her executive branch has “overstepped” its constitutional authority.

## Pelosi slammed for selling Google stocks right before DOJ announced antitrust suit: 'Convenient timing'
 - [https://www.foxnews.com/media/pelosi-slammed-selling-google-stocks-right-before-doj-announced-antitrust-suit-convenient-timing](https://www.foxnews.com/media/pelosi-slammed-selling-google-stocks-right-before-doj-announced-antitrust-suit-convenient-timing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 12:00:37+00:00
 - user: None

Rep. Nancy Pelosi was criticized Wednesday for selling stocks in Google's parent company, Alphabet, just one month before the DOJ announced a lawsuit against the company.

## Shot putter opposes World Athletics' proposal for transgender female athletes: 'Serious disadvantage'
 - [https://www.foxnews.com/sports/shot-putter-opposes-world-athletics-proposal-transgender-female-athletes-serious-disadvantage](https://www.foxnews.com/sports/shot-putter-opposes-world-athletics-proposal-transgender-female-athletes-serious-disadvantage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:58:53+00:00
 - user: None

Amelia Strickler, a shot putter who competes for Britain, spoke out against World Athletics' latest proposal to govern the eligibility of transgender female athletes.

## Arsenal tighten grip on Premier League race in 5-goal stunner against Manchester United
 - [https://www.foxnews.com/sports/arsenal-tighten-grip-premier-league-race-5-goal-stunner-manchester-united](https://www.foxnews.com/sports/arsenal-tighten-grip-premier-league-race-5-goal-stunner-manchester-united)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:37:47+00:00
 - user: None

Mikel Arteta and his men have yet to play Manchester City this season; their first test against 'the best team in the world' comes during Friday's FA Cup match.

## Schiff gets roasted after posting TikTok video about losing committee spot: ‘China is laughing at us’
 - [https://www.foxnews.com/media/schiff-gets-roasted-posting-tiktok-video-losing-committee-spot-china-laughing-at-us](https://www.foxnews.com/media/schiff-gets-roasted-posting-tiktok-video-losing-committee-spot-china-laughing-at-us)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:11:45+00:00
 - user: None

Twitter users roasted Rep. Adam Schiff, D-Calif., for complaining that he no longer had access to classified information — on an app tied to the Chinese government.

## Nun stops burglary with quick thinking and prayers: 'This is God's property'
 - [https://www.foxnews.com/media/nun-stops-burglary-quick-thinking-prayers-tucker-carlson-tonight](https://www.foxnews.com/media/nun-stops-burglary-quick-thinking-prayers-tucker-carlson-tonight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:00:48+00:00
 - user: None

Response to Love Center's Sister Mary Johnice details how she stopped an attempted burglary after Saturday morning prayers on "Tucker Carlson Tonight."

## Science professor says challenging university diversity and climate initiatives has been 'career suicide'
 - [https://www.foxnews.com/media/science-professor-challenging-university-diversity-climate-initiatives-career-suicide](https://www.foxnews.com/media/science-professor-challenging-university-diversity-climate-initiatives-career-suicide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:00:42+00:00
 - user: None

Dr. Matthew Wielicki joined "Fox & Friends First" to discuss leaving the University of Alabama amid the rise of DEI initiatives and a "false climate emergency."

## Could President Biden's classified documents scandal evolve into a counter-espionage case?
 - [https://www.foxnews.com/media/could-president-bidens-classified-documents-scandal-evolve-counter-espionage-case](https://www.foxnews.com/media/could-president-bidens-classified-documents-scandal-evolve-counter-espionage-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 11:00:34+00:00
 - user: None

RealClearInvestigations reporter Paul Sperry takes a look at the classified documents case against President Biden and why it could delve into something bigger.

## NBC Sports' Tony Dungy targeted by NBC News over his 'anti-LGBTQ history'
 - [https://www.foxnews.com/media/nbc-sports-tony-dungy-targeted-nbc-news-anti-lgbtq-history](https://www.foxnews.com/media/nbc-sports-tony-dungy-targeted-nbc-news-anti-lgbtq-history)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:30:42+00:00
 - user: None

NBC News took aim at Tony Dungy, a colleague at its sister network NBC Sports, for his alleged "anti-LGBTQ history" after the NFL legend faced backlash for a tweet.

## Ukraine sounds country-wide alarms amid Russian drone strikes; Western tank training to begin
 - [https://www.foxnews.com/world/ukraine-sounds-country-wide-alarms-russian-drone-strikes-western-tank-training-begin](https://www.foxnews.com/world/ukraine-sounds-country-wide-alarms-russian-drone-strikes-western-tank-training-begin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:28:59+00:00
 - user: None

Ukrainian officials said the capital city of Kyiv was under siege by Russian missile and drone strikes Wednesday, as the Ukrainian military is set to undergo Western tank training.

## NYC lawyer shot dead while vacationing in Chile, father says
 - [https://www.foxnews.com/world/nyc-lawyer-shot-dead-vacationing-chile-father-says](https://www.foxnews.com/world/nyc-lawyer-shot-dead-vacationing-chile-father-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:23:13+00:00
 - user: None

Eric Garvin, a 38-year-old New York City attorney, was killed in an apparently random attack while he was vacationing in Chile, his father announced on social media.

## Colorado man intentionally drove pickup truck into police department lobby 'in order to be heard': police
 - [https://www.foxnews.com/us/colorado-man-intentionally-drove-pickup-truck-police-department-lobby-order-heard](https://www.foxnews.com/us/colorado-man-intentionally-drove-pickup-truck-police-department-lobby-order-heard)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:13:47+00:00
 - user: None

Grand Junction, Colorado police say a man intentionally drove his pickup truck into the lobby of a police station on Tuesday, but say no one was injured.

## Biden's FCC nominee sits on board of group that opposes anti-sex trafficking efforts
 - [https://www.foxnews.com/politics/bidens-fcc-nominee-sits-board-group-opposes-anti-sex-trafficking-efforts](https://www.foxnews.com/politics/bidens-fcc-nominee-sits-board-group-opposes-anti-sex-trafficking-efforts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:00:16+00:00
 - user: None

Gigi Sohn, President Biden's nominee for the Federal Communications Commission, serves on the board of directors for a group that has opposed efforts to combat online sex trafficking.

## Iowa school board member gets ripped for saying public education is 'not to teach kids what parents want’
 - [https://www.foxnews.com/media/iowa-school-board-member-gets-ripped-saying-public-ed-teach-kids-parents-want](https://www.foxnews.com/media/iowa-school-board-member-gets-ripped-saying-public-ed-teach-kids-parents-want)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 10:00:10+00:00
 - user: None

An Iowa school board member said that public education is not to teach kids what parents want, but rather what the community needs, which sparked backlash.

## Jane Fonda links the 'climate crisis' to racism: 'Everything's connected'
 - [https://www.foxnews.com/media/jane-fonda-links-climate-crisis-racism-everythings-connected](https://www.foxnews.com/media/jane-fonda-links-climate-crisis-racism-everythings-connected)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 09:30:30+00:00
 - user: None

Jane Fonda blames the "climate crisis" on racism during a recent appearance on "The Kelly Clarkson Show" while discussing her social activism.

## Mars shelves M&M spokescandies in latest woke corporate fiasco
 - [https://www.foxnews.com/opinion/mars-shelves-mm-spokescandies-latest-woke-corporate-fiasco](https://www.foxnews.com/opinion/mars-shelves-mm-spokescandies-latest-woke-corporate-fiasco)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 09:00:45+00:00
 - user: None

If you are a corporate mascot, you are in danger

## NBC News boss can prove she’s more than a ‘figurehead’ by revealing truth behind retracted Paul Pelosi report
 - [https://www.foxnews.com/media/nbc-news-boss-can-prove-shes-more-than-figurehead-by-revealing-truth-behind-retracted-paul-pelosi-report](https://www.foxnews.com/media/nbc-news-boss-can-prove-shes-more-than-figurehead-by-revealing-truth-behind-retracted-paul-pelosi-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 09:00:24+00:00
 - user: None

Incoming NBC News boss Rebecca Blumenstein has a chance to provide transparency about Miguel Almaguer’s infamous Paul Pelosi report was retracted by the previous regime.

## Man helps save woman aboard JetBlue flight after she suffers mid-air medical emergency
 - [https://www.foxnews.com/us/man-helps-save-woman-aboard-jetblue-flight-after-suffers-mid-air-medical-emergency](https://www.foxnews.com/us/man-helps-save-woman-aboard-jetblue-flight-after-suffers-mid-air-medical-emergency)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 08:57:00+00:00
 - user: None

A man is being credited with saving a woman's life after she fainted aboard a JetBlue flight from New York to Florida. A passenger on the flight said the man was a trained EMT.

## Tyre Nichols video: Police chief warns Memphis not to react violently after body cam footage release
 - [https://www.foxnews.com/us/tyre-nichols-video-police-chief-warns-memphis-violently-body-cam-footage-release](https://www.foxnews.com/us/tyre-nichols-video-police-chief-warns-memphis-violently-body-cam-footage-release)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 08:51:47+00:00
 - user: None

Memphis Police Chief Cerelyn Davis gave an address Wednesday evening ahead of a decision by the police department to release the body cam footage in Tyre Nichols' death.

## Trump’s bid for the White House is Mission Impossible. Or is it?
 - [https://www.foxnews.com/shows/media-buzz/trumps-bid-white-house-mission-impossible](https://www.foxnews.com/shows/media-buzz/trumps-bid-white-house-mission-impossible)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 08:01:23+00:00
 - user: None

Former President Donald Trump's bid to become president in 2024 may or may not be an uphill battle. The media, Joe Biden and Ron DeSantis, among others, will play a deciding factor.

## California: Police give update on Monterey Park shooting, identify weapons used in Lunar New Year assault
 - [https://www.foxnews.com/us/police-update-monterey-park-shooting-identify-weapons-lunar-new-year-assault](https://www.foxnews.com/us/police-update-monterey-park-shooting-identify-weapons-lunar-new-year-assault)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:06:57+00:00
 - user: None

Los Angeles County Sheriff Robert Luna identified multiple weapons used by the suspected shooter, who killed 11 people at the Star Dance Ballroom Studio in Monterey Park, California.

## Iowa just latest government-school domino to fall, and there's nothing teachers' unions can do about it
 - [https://www.foxnews.com/opinion/iowa-latest-government-school-domino-fall-nothing-teachers-unions](https://www.foxnews.com/opinion/iowa-latest-government-school-domino-fall-nothing-teachers-unions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:54+00:00
 - user: None

The Republican-controlled Iowa Legislature passed an expansive school choice proposal and Gov. Kim Reynolds signed the bill Tuesday.

## Prince Harry's 'Spare': Megan Markle's attempt to 'distance' herself amid Hollywood fallout
 - [https://www.foxnews.com/entertainment/prince-harrys-spare-megan-markles-attempt-distance-herself-amid-hollywood](https://www.foxnews.com/entertainment/prince-harrys-spare-megan-markles-attempt-distance-herself-amid-hollywood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:39+00:00
 - user: None

According to a new report, the Duchess of Sussex "may have raised gentle concerns" about Prince Harry's memoir "Spare" and whether it was the right move.

## Prince Harry's 'Spare': Meghan Markle's attempt to 'distance' herself amid Hollywood fallout
 - [https://www.foxnews.com/entertainment/prince-harrys-spare-meghan-markles-attempt-distance-herself-amid-hollywood](https://www.foxnews.com/entertainment/prince-harrys-spare-meghan-markles-attempt-distance-herself-amid-hollywood)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:39+00:00
 - user: None

According to a new report, the Duchess of Sussex "may have raised gentle concerns" about Prince Harry's memoir "Spare" and whether it was the right move.

## Raleigh’s cop shortage, lingering anti-police sentiment blamed for record-high violence in 2022: expert
 - [https://www.foxnews.com/us/raleighs-cop-shortage-lingering-anti-police-sentiment-blamed-for-record-high-violence-in-2022-expert](https://www.foxnews.com/us/raleighs-cop-shortage-lingering-anti-police-sentiment-blamed-for-record-high-violence-in-2022-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:35+00:00
 - user: None

Raleigh, North Carolina, reported a 48% increase in homicides in 2022, which one expert says is likely due to the police department's staffing issues and anti-cop sentiment.

## GOP brawl: The competitive, combustible, bitter battle for Republican National Committee chair
 - [https://www.foxnews.com/politics/gop-brawl-competitive-combustible-bitter-battle-republican-national-committee-chair](https://www.foxnews.com/politics/gop-brawl-competitive-combustible-bitter-battle-republican-national-committee-chair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:17+00:00
 - user: None

The battle between RNC Chair Ronna McDaniel and top challenger Harmeet Dhillon has turned combative ahead of Friday's election to steer the GOP the next.

## After 14 failed adoptions, North Carolina pup with 'unlucky' history goes viral, finally finds a home
 - [https://www.foxnews.com/lifestyle/14-failed-adoptions-north-carolina-pup-unlucky-history-goes-viral-finds-home](https://www.foxnews.com/lifestyle/14-failed-adoptions-north-carolina-pup-unlucky-history-goes-viral-finds-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:14+00:00
 - user: None

Ronald, a puppy from the SPCA of Wake County in Raleigh, North Carolina, has ended his "unlucky streak" and found his new home after 14 pending adoptions.

## After Chesa Boudin, new San Francisco DA cracks down on crime, but anti-cop views stall progress
 - [https://www.foxnews.com/politics/chesa-boudin-new-san-francisco-da-cracks-crime-anti-cop-views-stall-progress](https://www.foxnews.com/politics/chesa-boudin-new-san-francisco-da-cracks-crime-anti-cop-views-stall-progress)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 07:00:00+00:00
 - user: None

After a district attorney recall thrusted Brooke Jenkins into power this summer, the new DA has been tougher on crime, a San Francisco activist told Fox News.

## Chiefs' Patrick Mahomes expresses confidence in injured ankle ahead of AFC Championship: 'It's doing good'
 - [https://www.foxnews.com/sports/chiefs-patrick-mahomes-expresses-confidence-injured-ankle-ahead-afc-championship-doing-good](https://www.foxnews.com/sports/chiefs-patrick-mahomes-expresses-confidence-injured-ankle-ahead-afc-championship-doing-good)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 06:37:12+00:00
 - user: None

Patrick Mahomes suffered a high ankle sprain in the first quarter of the Kansas City Chiefs' divisional round playoff victory over the Jacksonville Jaguars.

## Uber Eats delivery man stops college basketball game after walking on court to find customer
 - [https://www.foxnews.com/sports/uber-eats-delivery-man-stops-college-basketball-game-walking-court-find-customer](https://www.foxnews.com/sports/uber-eats-delivery-man-stops-college-basketball-game-walking-court-find-customer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 05:41:23+00:00
 - user: None

The Loyola Chicago Ramblers and Duquesne Dukes had their college basketball game stopped in its tracks after an Uber Eats delivery man walked on the court looking for his customer.

## On this day in history, Jan. 26, 1979, 'The Dukes of Hazzard' premieres, becomes pop-culture hit
 - [https://www.foxnews.com/lifestyle/this-day-history-jan-26-1979-dukes-hazzard-premieres-pop-culture-hit](https://www.foxnews.com/lifestyle/this-day-history-jan-26-1979-dukes-hazzard-premieres-pop-culture-hit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 05:02:34+00:00
 - user: None

"The Dukes of Hazzard" debuted on television on this day in history, Jan. 26, 1979. It aired for seven season and 147 episodes, defying TV experts and CBS executives with its success.

## Scouting report reveals what contributed to 49ers QB Brock Purdy's drop in NFL Draft
 - [https://www.foxnews.com/sports/scouting-report-reveals-what-contributed-49ers-qb-brock-purdys-drop-nfl-draft](https://www.foxnews.com/sports/scouting-report-reveals-what-contributed-49ers-qb-brock-purdys-drop-nfl-draft)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:52:47+00:00
 - user: None

Rookie Brock Purdy finished the regular season with 13 touchdowns and a 5-0 regular-season record as a starter. He's continued to defy odds with two playoff wins so far.

## Raiders legend and Hall of Famer Tim Brown doesn't want Tom Brady in Vegas
 - [https://www.foxnews.com/sports/raiders-legend-hall-of-famer-tim-brown-doesnt-want-tom-brady-vegas](https://www.foxnews.com/sports/raiders-legend-hall-of-famer-tim-brown-doesnt-want-tom-brady-vegas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:37:42+00:00
 - user: None

Pro Football Hall of Famer Tim Brown may have an unpopular opinion: He does not want Tom Brady anywhere near his former Las Vegas Raiders.

## Trump issues statement after Meta announces end of 2-year Facebook ban, allowing him to return to the platform
 - [https://www.foxnews.com/politics/trump-issues-statement-meta-announces-year-facebook-ban](https://www.foxnews.com/politics/trump-issues-statement-meta-announces-year-facebook-ban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:35:06+00:00
 - user: None

Facebook and parent company, Meta, announced Donald Trump will be allowed to return to the platform 'in the coming weeks,' drawing a response from the former president.

## GREG GUTFELD: Trans activists are 'boiling mad' over a video game JK Rowling has nothing to do with
 - [https://www.foxnews.com/opinion/greg-gutfeld-trans-activists-are-boiling-mad-over-jk-rowling](https://www.foxnews.com/opinion/greg-gutfeld-trans-activists-are-boiling-mad-over-jk-rowling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:33:16+00:00
 - user: None

Fox News host Greg Gutfeld weighs in on the "fake boycott" against Harry Potter author J.K. Rowling amid a new video game coming out called "Hogwarts Legacy" on "Gutfeld!"

## SEAN HANNITY: House Speaker Kevin McCarthy removed these 'idiots' for good reason
 - [https://www.foxnews.com/media/sean-hannity-house-speaker-kevin-mccarthy-removed-idiots-good-reason](https://www.foxnews.com/media/sean-hannity-house-speaker-kevin-mccarthy-removed-idiots-good-reason)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:15:06+00:00
 - user: None

Sean Hannity discusses how speaker of the House Kevin McCarthy removed CA Reps. Adam Schiff and Eric Swalwell from the House Intelligence Committee on "Hannity."

## PETE HEGSETH: They have no right to be on the intel committee
 - [https://www.foxnews.com/media/pete-hegseth-they-have-no-right-intel-committee](https://www.foxnews.com/media/pete-hegseth-they-have-no-right-intel-committee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:10:18+00:00
 - user: None

Fox News' Pete Hegseth lays out the 'extremely valid concerns' of House Speaker Kevin McCarthy after he refused to seat Reps. Eric Swalwell and Adam Schiff on the House Intelligence Committee.

## MSNBC anchor lectures viewers on the importance of getting a fourth COVID shot: 'Here's the deal, moron'
 - [https://www.foxnews.com/media/msnbc-anchor-lectures-viewers-importance-getting-fourth-covid-shot-heres-deal-moron](https://www.foxnews.com/media/msnbc-anchor-lectures-viewers-importance-getting-fourth-covid-shot-heres-deal-moron)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 04:00:39+00:00
 - user: None

MSNBC host Joe Scarborough of Morning Joe hammered skeptics of the coronavirus vaccine, particularly those who mock him for getting a fourth dose.

## Florida man swept away in shark-infested waters by powerful current details shocking survival
 - [https://www.foxnews.com/media/florida-man-swept-away-into-shark-infested-waters-by-powerful-current-details-shocking-survival](https://www.foxnews.com/media/florida-man-swept-away-into-shark-infested-waters-by-powerful-current-details-shocking-survival)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 03:37:09+00:00
 - user: None

Dylan Gartenmayer details his spearfishing experience when he was carried away by a powerful current on 'Tucker Carlson Tonight.'

## DOJ officials 'frustrated,' 'irritated' with Biden team over classified docs scandal: report
 - [https://www.foxnews.com/media/doj-officials-frustrated-irritated-biden-team-classified-docs-scandal-report](https://www.foxnews.com/media/doj-officials-frustrated-irritated-biden-team-classified-docs-scandal-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 03:30:19+00:00
 - user: None

CNN's Paula Reid reported Wednesday that Department of Justice officials are "frustrated" with President Biden's handling of the classified documents scandal.

## Dennis Schröder stunned by Lakers trade during live stream: 'Oh no, hell no'
 - [https://www.foxnews.com/sports/dennis-schroder-stunned-lakers-trade-during-live-stream](https://www.foxnews.com/sports/dennis-schroder-stunned-lakers-trade-during-live-stream)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 03:00:47+00:00
 - user: None

The Los Angeles Lakers traded for Rui Hachimura from the Washington Wizards Monday, and Dennis Schröder couldn't believe it when a livestream viewer broke the news to him.

## Game show mocking Ron Klain's wild retweets wraps up amid reports of pending exit as Biden chief of staff
 - [https://www.foxnews.com/media/game-show-mocking-ron-klains-wild-retweets-wraps-up-amid-reports-pending-exit](https://www.foxnews.com/media/game-show-mocking-ron-klains-wild-retweets-wraps-up-amid-reports-pending-exit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 03:00:42+00:00
 - user: None

The "Ruthless" podcast officially retired its long-running game show that poked fun at outgoing White House chief of staff Ron Klain's prolific Twitter activity.

## TUCKER CARLSON: A look into the strange circumstances around Jeffrey Epstein's death
 - [https://www.foxnews.com/opinion/tucker-carlson-look-strange-circumstances-jeffrey-epsteins-death](https://www.foxnews.com/opinion/tucker-carlson-look-strange-circumstances-jeffrey-epsteins-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 03:00:17+00:00
 - user: None

Fox News host Tucker Carlson analyzes the real cause of Jeffrey Epstein's death despite officials labeling it as a suicide on "Tucker Carlson Tonight."

## California Half Moon Bay shooting suspect charged with 7 counts of murder: DA
 - [https://www.foxnews.com/us/california-half-moon-bay-shooting-suspect-charged-counts-murder-da](https://www.foxnews.com/us/california-half-moon-bay-shooting-suspect-charged-counts-murder-da)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:57:09+00:00
 - user: None

The suspect in a deadly mass shooting in Half Moon Bay, California, was charged with seven counts of murder, the local district attorney said.

## Former Baltimore State's Attorney Marilyn Mosby's entire legal team seeks to withdraw from case
 - [https://www.foxnews.com/politics/former-baltimore-states-attorney-marilyn-mosbys-entire-legal-team-seeks-withdraw-case](https://www.foxnews.com/politics/former-baltimore-states-attorney-marilyn-mosbys-entire-legal-team-seeks-withdraw-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:49:13+00:00
 - user: None

Former Baltimore State's Attorney Marilyn Mosby's is asking a federal judge to withdraw from representing the former prosecutor in a federal case.

## Schiff, Swalwell assert Trump, Russia influence in being booted from House Intel Committee
 - [https://www.foxnews.com/media/schiff-swalwell-assert-trump-russia-influence-booted-house-intel-committee](https://www.foxnews.com/media/schiff-swalwell-assert-trump-russia-influence-booted-house-intel-committee)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:49:00+00:00
 - user: None

Reps. Eric Swalwell and Adam Schiff blamed Donald Trump and Russia’s influence on the GOP for losing their positions on the House Intelligence Committee.

## California judge issues preliminary injunction blocking COVID ‘misinformation’ law: reports
 - [https://www.foxnews.com/politics/california-judge-issues-preliminary-injunction-blocking-covid-misinformation-law](https://www.foxnews.com/politics/california-judge-issues-preliminary-injunction-blocking-covid-misinformation-law)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:47:19+00:00
 - user: None

A California judge issued a preliminary injunction against the 'misinformation' law, as five doctors challenge the law and claim it violates First Amendment.

## Former NFL tight end details 'worst' interview moment during NFL Combine
 - [https://www.foxnews.com/sports/former-nfl-tight-end-details-worst-interview-moment-during-nfl-combine](https://www.foxnews.com/sports/former-nfl-tight-end-details-worst-interview-moment-during-nfl-combine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:40:02+00:00
 - user: None

When Benjamin Watson was at the NFL Combine in 2004, he was interviewing with all the teams, but one of his sit-downs was unlike any other.

## Woman gets over 6 years in prison for involvement in romance scams
 - [https://www.foxnews.com/us/woman-gets-6-years-prison-involvement-romance-scams](https://www.foxnews.com/us/woman-gets-6-years-prison-involvement-romance-scams)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:39:05+00:00
 - user: None

A Texas woman was sentenced to over six years in prison for involvement in a scam that stole $2.6 million from victims. The woman was charged with fraud and conspiracy.

## Florida man suspected of serial rapes convicted in 1 attack
 - [https://www.foxnews.com/us/florida-man-suspected-serial-rapes-convicted-in-1-attack](https://www.foxnews.com/us/florida-man-suspected-serial-rapes-convicted-in-1-attack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:36:58+00:00
 - user: None

A Florida man who was suspected of serial rapes in the 1980s was convicted in one of the attacks. Robert Koehler was found gulity of sexual battery, kidnapping, and burglary Wednesay.

## Massachusetts congressman reads AI-generated speech on House floor
 - [https://www.foxnews.com/politics/massachusetts-congressman-reads-ai-generated-speech-house-floor](https://www.foxnews.com/politics/massachusetts-congressman-reads-ai-generated-speech-house-floor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:18:02+00:00
 - user: None

Democratic Massachusetts Rep. Jake Auchincloss used an online chatbot to generate a speech on establishing a U.S.-Israel artificial intelligence center that he read on the House floor.

## FDA safety official resigns over 'structural issues'
 - [https://www.foxnews.com/us/fda-safety-official-resigns-structural-issues](https://www.foxnews.com/us/fda-safety-official-resigns-structural-issues)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:16:55+00:00
 - user: None

Frank Yiannas, the FDA's deputy commissioner for food policy and response, resigned Wednesday over apparent structural issues within the agency.

## Vermont State Police investigating incoming sheriff's finances
 - [https://www.foxnews.com/us/vermont-state-police-investigating-incoming-sheriffs-finances](https://www.foxnews.com/us/vermont-state-police-investigating-incoming-sheriffs-finances)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:15:40+00:00
 - user: None

The finances of Franklin County, Vermont, sheriff-elect John Grismore are being probed as he is investigated for kicking a suspect in the groin.

## Defense argues Tennessee road rage killer's actions not premeditated
 - [https://www.foxnews.com/us/defense-argues-tennessee-road-rage-killers-actions-not-premeditated](https://www.foxnews.com/us/defense-argues-tennessee-road-rage-killers-actions-not-premeditated)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:14:43+00:00
 - user: None

Tennessee prosecutors are accusing Devaunte Hill of first-degree murder for killing nurse Caitlyn Kaufman, though defense attorneys argue the crime was not premeditated.

## JESSE WATTERS: This 'pay for play' scheme is right out in the open
 - [https://www.foxnews.com/media/jesse-watters-pay-play-scheme-right-out-in-open](https://www.foxnews.com/media/jesse-watters-pay-play-scheme-right-out-in-open)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:10:15+00:00
 - user: None

Fox News host Jesse Watters gives his take on how the Biden family got so rich and weighs in on the classified documents scandal on "Jesse Watters Primetime."

## Hulk Hogan accidentally pleads for toilet paper on social media: 'Brother, help!'
 - [https://www.foxnews.com/sports/hulk-hogan-accidentally-pleads-toilet-paper-social-media-brother-help](https://www.foxnews.com/sports/hulk-hogan-accidentally-pleads-toilet-paper-social-media-brother-help)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:06:10+00:00
 - user: None

Hulk Hogan went viral for an apparent accidental tweet asking for more toilet paper on Wednesday after he had a nice tweet about seeing his buddies again.

## MA preschool teacher fired after Libs of TikTok exposes her allegedly filming OnlyFans content in school
 - [https://www.foxnews.com/media/ma-preschool-teacher-fired-libs-tiktok-exposes-allegedly-filming-onlyfans-content-school](https://www.foxnews.com/media/ma-preschool-teacher-fired-libs-tiktok-exposes-allegedly-filming-onlyfans-content-school)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:04:53+00:00
 - user: None

A Massachusetts preschool teacher was reportedly let go from her job after Libs of TikTok revealed that she allegedly filmed OnlyFans content on school grounds.

## Mexico health officials issue warning over social media tranquilizer challenge: reports
 - [https://www.foxnews.com/world/mexico-health-officials-issue-warning-social-media-tranquilizer-challenge-reports](https://www.foxnews.com/world/mexico-health-officials-issue-warning-social-media-tranquilizer-challenge-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 02:02:48+00:00
 - user: None

Mexico's health department issued a warning this week after sever students were treated for taking tranquilizers as part of an internet challenge to see who can stay awake.

## Schiff, Swalwell forced to face the music for 'weaponizing' intel committee, Nunes says: 'You caused this'
 - [https://www.foxnews.com/media/schiff-swalwell-forced-face-music-weaponizing-intel-committee-nunes-says-you-caused-this](https://www.foxnews.com/media/schiff-swalwell-forced-face-music-weaponizing-intel-committee-nunes-says-you-caused-this)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:57:20+00:00
 - user: None

Reps. Adam Schiff and Eric Swalwell bear sole responsibility for "weaponizing" the House Intelligence Committee, former ranking member Devin Nunes alleged.

## Patrick Mahomes highlights NFL MVP award finalists for 2022 season
 - [https://www.foxnews.com/sports/patrick-mahomes-highlights-nfl-mvp-award-finalists-2022-season](https://www.foxnews.com/sports/patrick-mahomes-highlights-nfl-mvp-award-finalists-2022-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:56:35+00:00
 - user: None

The Associated Press announced the finalists for its NFL awards this season, including NFL MVP. Patrick Mahomes, Jalen Hurts and others were among those voted on.

## California murderer Scott Forrest Collins removed from death row in September dies in prison
 - [https://www.foxnews.com/us/california-murderer-scott-forrest-collins-removed-death-row-september-dies-prison](https://www.foxnews.com/us/california-murderer-scott-forrest-collins-removed-death-row-september-dies-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:14:34+00:00
 - user: None

Scott Forrest Collins, a convicted Los Angeles murderer who gunned down a father in 1992, died in prison just months after being removed from death row.

## 49ers' Nick Bosa takes parting shot at Cowboys following playoff win
 - [https://www.foxnews.com/sports/49ers-nick-bosa-takes-parting-shot-cowboys-playoff-win](https://www.foxnews.com/sports/49ers-nick-bosa-takes-parting-shot-cowboys-playoff-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:14:15+00:00
 - user: None

San Francisco 49ers defensive end Nick Bosa had one last parting shot for the Dallas Cowboys after eliminating them from the postseason on Sunday.

## Virginia school board removes superintendent after 6-year-old shoots teacher
 - [https://www.foxnews.com/us/virginia-school-board-removes-superintendent-6-year-old-shoots-teacher](https://www.foxnews.com/us/virginia-school-board-removes-superintendent-6-year-old-shoots-teacher)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:01:42+00:00
 - user: None

Virginia school officials ousted Newport News Superintendent George Parker Wednesday after a 6-year-old boy shot a teacher earlier this month.

## Philadelphia Inquirer calls Ron DeSantis receiving local prestigious award 'a step backwards'
 - [https://www.foxnews.com/media/philadelphia-inquirer-calls-ron-desantis-receiving-local-prestigious-award-step-backwards](https://www.foxnews.com/media/philadelphia-inquirer-calls-ron-desantis-receiving-local-prestigious-award-step-backwards)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 01:00:26+00:00
 - user: None

The Philadelphia Inquirer published an editorial Wednesday that criticized the Union League of Philadelphia's decision to award Florida Gov. Ron DeSantis with their gold medal.

## Austin gas station shooting: longtime customers rally behind clerk charged with murder
 - [https://www.foxnews.com/us/austin-gas-station-shooting-longtime-customers-rally-behind-clerk-charged-with-murder](https://www.foxnews.com/us/austin-gas-station-shooting-longtime-customers-rally-behind-clerk-charged-with-murder)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:54:11+00:00
 - user: None

The Austin Police Department arrested a 25-year-old man for murder following a shooting in East Austin. Longtime customers have come to his defense.

## 'Home Improvement' star Patricia Richardson responds to resurfaced clip of Tim Allen flashing her on set
 - [https://www.foxnews.com/entertainment/home-improvement-star-patricia-richardson-responds-resurfaced-clip-tim-allen-flashing-her-on-set](https://www.foxnews.com/entertainment/home-improvement-star-patricia-richardson-responds-resurfaced-clip-tim-allen-flashing-her-on-set)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:52:20+00:00
 - user: None

A clip from "Home Improvement" has resurfaced, and Patricia Richardson told Fox News Digital Tim Allen did not flash his naked body to her in a blooper clip from the '90s sitcom.

## Nikki Bella explains why she wore John Cena wedding dress for nuptials to Artem Chigvintsev
 - [https://www.foxnews.com/entertainment/nikki-bella-explains-why-wore-john-cena-wedding-dress-nuptials-artem-chigvintsev](https://www.foxnews.com/entertainment/nikki-bella-explains-why-wore-john-cena-wedding-dress-nuptials-artem-chigvintsev)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:45:31+00:00
 - user: None

Nikki Bella said she fell in love with the dress she bought for her nuptials with then-fiancé John Cena, so she kept it for her wedding with Artem Chigvintsev.

## Ted Cruz says it's 'critical' for FBI to search Hunter Biden's home for classified docs
 - [https://www.foxnews.com/politics/ted-cruz-says-critical-fbi-search-hunter-bidens-home-classified-docs](https://www.foxnews.com/politics/ted-cruz-says-critical-fbi-search-hunter-bidens-home-classified-docs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:44:42+00:00
 - user: None

Ted Cruz is calling on the FBI to search Hunter Biden's home and business for classified documents following the discovery of classified documents at President Biden's Wilmington home.

## 'Young and the Restless' star Tracey Bregman receives replacement Emmy award after devastating 2018 fire
 - [https://www.foxnews.com/entertainment/young-restless-star-tracey-bregman-receives-replacement-emmy-award-devastating-2018-fire](https://www.foxnews.com/entertainment/young-restless-star-tracey-bregman-receives-replacement-emmy-award-devastating-2018-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:35:55+00:00
 - user: None

Soap opera actress Tracey Bregman received a replacement Emmy Award on Tuesday after she lost her home and her award in the devastating Woolsey Fire in 2018.

## Penn State basketball coach rips refs after 20-point loss: 'I'm done sending in clips'
 - [https://www.foxnews.com/sports/penn-state-basketball-coach-rips-refs-20-point-loss-done-sending-clips](https://www.foxnews.com/sports/penn-state-basketball-coach-rips-refs-20-point-loss-done-sending-clips)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:35:18+00:00
 - user: None

After losing by 20 to Rutgers Tuesday night, Penn State head coach Micah Shrewsberry admitted his team was "soft," but he took some shots at the refs too.

## 49ers' Charles Omenihu will play in NFC Championship despite domestic violence arrest earlier this week
 - [https://www.foxnews.com/sports/49ers-charles-omenihu-will-play-nfc-championship-despite-domestic-violence-arrest-earlier-this-week](https://www.foxnews.com/sports/49ers-charles-omenihu-will-play-nfc-championship-despite-domestic-violence-arrest-earlier-this-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:06:34+00:00
 - user: None

San Francisco 49ers defensive lineman Charles Omenihu will play in the NFC Championship on Sunday despite being charged with a domestic violence misdemeanor.

## New Mexico school bus crash leaves 7 injured, 1 critical condition
 - [https://www.foxnews.com/us/new-mexico-school-bus-crash-leaves-7-injured-1-critical-condition](https://www.foxnews.com/us/new-mexico-school-bus-crash-leaves-7-injured-1-critical-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:04:59+00:00
 - user: None

A New Mexico school bus and a large vehicle crashed into each other on Wednesday leaving 7 children hospitalized and one with serious injuries. Officials didn't provide further details.

## Tom Brady spends time with his kids after NFL season ends, calls daughter his 'cutest roomie'
 - [https://www.foxnews.com/entertainment/tom-brady-spends-time-kids-nfl-season-ends-calls-daughter-cutest-roomie](https://www.foxnews.com/entertainment/tom-brady-spends-time-kids-nfl-season-ends-calls-daughter-cutest-roomie)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:04:12+00:00
 - user: None

Tom Brady gave fans a glimpse into his time spent with the children he shares with ex-wife Gislee Bündchen on Instagram. The NFL quarterback's 23rd season came to an end on Jan. 16.

## Major addition to NYC's Grand Central Station finished
 - [https://www.foxnews.com/us/major-addition-nyc-grand-central-station-finished](https://www.foxnews.com/us/major-addition-nyc-grand-central-station-finished)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:03:17+00:00
 - user: None

A new terminal, dubbed Grand Central Madison, has been completed at New York City's Grand Central Terminal after years of delayed construction.

## Federal court hears Texas citizen journalist's case
 - [https://www.foxnews.com/us/federal-court-hears-texas-citizen-journalists-case](https://www.foxnews.com/us/federal-court-hears-texas-citizen-journalists-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:01:19+00:00
 - user: None

Online citizen journalist Priscilla Villarreal is contesting an arrest by Laredo, Texas, police after requesting non-public information in 2017.

## Razzies retreat after facing backlash for nominating child actor: 'Repulsive and wrong,' 'tacky new low'
 - [https://www.foxnews.com/media/razzies-retreat-facing-backlash-nominating-child-actor-repulsive-wrong-tacky-new-low](https://www.foxnews.com/media/razzies-retreat-facing-backlash-nominating-child-actor-repulsive-wrong-tacky-new-low)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-01-26 00:00:58+00:00
 - user: None

Movie critics, former child actors and social media users blasted the Razzies, an award show highlighting the worst movies in Hollywood, for nominating a child actor.
