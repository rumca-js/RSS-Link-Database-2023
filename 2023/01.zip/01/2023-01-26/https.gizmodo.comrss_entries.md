# Source Gizmodo, Source URL:https://gizmodo.com/rss, Source language: en-US

## What Is Carbon Capture? With Gizmodo’s Molly Taft | Techmodo
 - [https://gizmodo.com/what-is-carbon-capture-with-gizmodo-s-molly-taft-1850037953](https://gizmodo.com/what-is-carbon-capture-with-gizmodo-s-molly-taft-1850037953)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 23:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QUOuj_3S--/c_fit,fl_progressive,q_80,w_636/750f68663f454b5f64617a34a7568e91.jpg" /><p><a href="https://gizmodo.com/what-is-carbon-capture-with-gizmodo-s-molly-taft-1850037953">Read more...</a></p>

## 16 Fun (and Sometimes False) Facts We Learned About the Making of Willow
 - [https://gizmodo.com/willow-behind-the-scenes-warwick-davis-disney-lucasfilm-1850032315](https://gizmodo.com/willow-behind-the-scenes-warwick-davis-disney-lucasfilm-1850032315)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 23:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--hBMJxN_c--/c_fit,fl_progressive,q_80,w_636/6ad3554cb735d3fd9f3f05b7b184867f.jpg" /><p>Anyone who watched <a href="https://gizmodo.com/willow-season-2-questions-season-1-finale-spoilers-kasd-1849982846">Lucasfilm’s new Disney+ show <em>Willow</em></a> won’t be surprised by this next sentence. The behind-the-scenes documentary, <em>Willow: Behind the Magic</em>, is only half-serious, much <a href="https://gizmodo.com/willow-disney-plus-sequel-warwick-davis-lucasfilm-kasda-1849782473">like the show it’s based on</a>. </p><p><a href="https://gizmodo.com/willow-behind-the-scenes-warwick-davis-disney-lucasfilm-1850032315">Read more...</a></p>

## Twitter Is Making Font Adjustments Again
 - [https://gizmodo.com/twitter-font-elon-musk-1850037417](https://gizmodo.com/twitter-font-elon-musk-1850037417)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 22:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--o9Rs7l4y--/c_fit,fl_progressive,q_80,w_636/60cce7b3aad50a448b0fade0cfdaa30f.jpg" /><p>It’s subtle, but if you look hard enough, the difference is there: in the curve at the base of the lowercase L’s, the serifs on the uppercase I’s, and the slash through the zeros. Twitter has made some alterations to its font—specifically in site user’s handles. The change was <a href="https://www.theverge.com/2023/1/26/23572746/twitter-changed-font-impersonators" rel="noopener noreferrer" target="_blank">first reported on</a> by the Verge, and first…</p><p><a href="https://gizmodo.com/twitter-font-elon-musk-1850037417">Read more...</a></p>

## Titan Promises to Fix Kamen Rider Kuuga Manga After Translation Controversy
 - [https://gizmodo.com/kamen-rider-kuuga-manga-english-translation-fixes-titan-1850036956](https://gizmodo.com/kamen-rider-kuuga-manga-english-translation-fixes-titan-1850036956)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 22:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--5tYti8Ny--/c_fit,fl_progressive,q_80,w_636/bf50480c347f0f81e3d39a6f980b277f.png" /><p>After <a href="https://gizmodo.com/kamen-rider-kuuga-manga-english-translation-titan-error-1850031241">days of fan concerns</a> about the state of the <a href="https://gizmodo.com/kamen-rider-kuuga-manga-translation-preview-vol-1-2-1849406396"><em>Kamen Rider Kuuga</em> manga</a>’s English translation, publishers Titan Comics and StoneBot have announced plans to fix the litany of errors and disparities in future releases and re-prints.<br /></p><p><a href="https://gizmodo.com/kamen-rider-kuuga-manga-english-translation-fixes-titan-1850036956">Read more...</a></p>

## France Is Facing a Mysterious 'Nightmare' of Tiny Plastic Pellets
 - [https://gizmodo.com/france-plastic-pellets-beaches-disaster-1850035738](https://gizmodo.com/france-plastic-pellets-beaches-disaster-1850035738)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 22:08:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--dxloR5_X--/c_fit,fl_progressive,q_80,w_636/41ae148c18e7e39513f3f18c9c8ca5bf.jpg" /><p>For the past year on the  coast of France, the waves crashing ashore have borne evidence of an unsettling mystery. An untold number of tiny plastic pellets are landing on the beaches of Brittany, Pays de la Loire, and elsewhere.<br /></p><p><a href="https://gizmodo.com/france-plastic-pellets-beaches-disaster-1850035738">Read more...</a></p>

## Falcon 9 Rocket Sets New Payload Weight Record During SpaceX Starlink Launch
 - [https://gizmodo.com/spacex-falcon-9-payload-weight-record-starlink-1850037136](https://gizmodo.com/spacex-falcon-9-payload-weight-record-starlink-1850037136)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--JOhxlGsE--/c_fit,fl_progressive,q_80,w_636/11bb9c3de8c56a111dd5551792ec0f9e.png" /><p>SpaceX’s freakishly reliable Falcon 9 continues to impress. The rocket delivered 56 Starlink satellites to Earth orbit this morning, and with a collective weight  around 17.4 metric tons, it’s now the heaviest payload ever lifted by a Falcon 9 rocket.<br /></p><p><a href="https://gizmodo.com/spacex-falcon-9-payload-weight-record-starlink-1850037136">Read more...</a></p>

## Rahul Kohli on How Fandom Can Bring Old Games Back
 - [https://gizmodo.com/rahul-kohli-sega-new-like-a-dragon-ishin-yakuza-rpg-1850035766](https://gizmodo.com/rahul-kohli-sega-new-like-a-dragon-ishin-yakuza-rpg-1850035766)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iF1KnTpk--/c_fit,fl_progressive,q_80,w_636/6ce49de45c91a1cacc8712ca796c4334.png" /><p><a href="https://gizmodo.com/rahul-kohli-on-his-daddy-status-1849837323">Beloved nerd</a>, noted horror/comedy actor, and <a href="https://gizmodo.com/rahul-kohli-in-netflix-midnight-club-mike-flanagan-1849490773">internet handsome man</a> <a href="https://gizmodo.com/next-exit-mali-elfman-katie-parker-rahul-kohli-1849808679">Rahul Kohli</a> is going to be in a video game. I don’t mean he’s going to be voice acting (although, you know I wouldn’t hate that at all), but he’s actually going to be featured on a new Trooper Card in the upcoming English version of Sega’s <a href="https://ishin.sega.com/" rel="noopener noreferrer" target="_blank"><em>Like a</em>…</a></p><p><a href="https://gizmodo.com/rahul-kohli-sega-new-like-a-dragon-ishin-yakuza-rpg-1850035766">Read more...</a></p>

## AI Will Start Writing BuzzFeed's Notorious Personalized Quizzes
 - [https://gizmodo.com/ai-buzzfeed-chatgpt-quiz-1850036965](https://gizmodo.com/ai-buzzfeed-chatgpt-quiz-1850036965)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:40:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--b5_EApzW--/c_fit,fl_progressive,q_80,w_636/8fea373d749715dfcbe4768a647f0955.jpg" /><p>BuzzFeed is already jumping the gun trying to answer its upcoming quiz: Will AI Take Your Job Next?</p><p><a href="https://gizmodo.com/ai-buzzfeed-chatgpt-quiz-1850036965">Read more...</a></p>

## NASA Announces Successful Test of New Propulsion Technology for Treks to Deep Space
 - [https://gizmodo.com/nasa-validates-propulsion-technology-deep-space-1850036531](https://gizmodo.com/nasa-validates-propulsion-technology-deep-space-1850036531)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LuDl3pZ2--/c_fit,fl_progressive,q_80,w_636/900398a3c4e060e035ded76809d9c39c.png" /><p>As NASA gears up for a return to the Moon with the Artemis missions, the administration has announced that its researchers have successfully developed and tested a new type of supersonic rocket engine called a rotating detonation rocket engine.<br /></p><p><a href="https://gizmodo.com/nasa-validates-propulsion-technology-deep-space-1850036531">Read more...</a></p>

## Spotify Users Hit With Second Outage in Two Weeks
 - [https://gizmodo.com/spotify-music-streaming-service-spotify-down-1850037344](https://gizmodo.com/spotify-music-streaming-service-spotify-down-1850037344)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--qImxbx9s--/c_fit,fl_progressive,q_80,w_636/ba640eea160081debf478108e620374b.jpg" /><p><a href="https://gizmodo.com/spotify-apple-youtube-music-playlist-sync-how-to-not-1849942375">Spotify</a> users reported outages on the streaming service beginning at about 1 p.m. ET on Thursday, saying the primary issues are app-related. Users are complaining that the app won’t load or allow them to stream content including music, <a href="https://gizmodo.com/apple-audio-books-ai-authors-ebooks-1849952963">audiobooks</a>, and <a href="https://gizmodo.com/7-podcasts-us-government-fbi-cdc-fda-social-security-1849717581">podcasts</a>.</p><p><a href="https://gizmodo.com/spotify-music-streaming-service-spotify-down-1850037344">Read more...</a></p>

## 9 Episodes From Deep Space Nine's First Season That Prove It's Better Than You Remember
 - [https://gizmodo.com/deep-space-nine-season-1-best-episodes-star-trek-1850036262](https://gizmodo.com/deep-space-nine-season-1-best-episodes-star-trek-1850036262)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 21:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s---QAvqmvQ--/c_fit,fl_progressive,q_80,w_636/740d71ba8427d433a7bb6874360c2fc2.png" /><p><a href="https://gizmodo.com/star-trek-deep-space-nine-s-must-watch-episodes-1842983112"><em>Deep Space Nine</em></a>, which <a href="https://gizmodo.com/star-trek-deep-space-nine-30th-anniversary-emissary-1849945866">turned 30 this month</a>, is most remembered for its later seasons, which <a href="https://gizmodo.com/star-treks-ira-steven-behr-looks-back-on-the-complex-le-1834401786">radically challenged the tenets</a> of <em>Star Trek</em> as a franchise—often to the point that people actively brush aside or look down on its early seasons as skippable, or a trudge to get to the good stuff. But while there are…</p><p><a href="https://gizmodo.com/deep-space-nine-season-1-best-episodes-star-trek-1850036262">Read more...</a></p>

## 10 (Sad!) Reminders of Trump's Bad Social Media Behavior
 - [https://gizmodo.com/donald-trump-meta-facebook-twitter-truth-social-1850035563](https://gizmodo.com/donald-trump-meta-facebook-twitter-truth-social-1850035563)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 20:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--K4hmqboP--/c_fit,fl_progressive,q_80,w_636/23d7206e129e3d23dbaa013f046d3756.jpg" /><p>Meta is <a href="https://about.fb.com/news/2023/01/trump-facebook-instagram-account-suspension/" rel="noopener noreferrer" target="_blank">lifting former President Donald Trump’s two-year ban</a> on Facebook and Instagram following controversial posts after he lost the 2020 presidential election to Joe Biden and in response to his posts that lead up to the January 6 insurrection.</p><p><a href="https://gizmodo.com/donald-trump-meta-facebook-twitter-truth-social-1850035563">Read more...</a></p>

## Pentagon Directive Warns of AI's 'Increasing Role' in Warfare
 - [https://gizmodo.com/ai-pentagon-war-directive-warns-increasing-role-drones-1850036547](https://gizmodo.com/ai-pentagon-war-directive-warns-increasing-role-drones-1850036547)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 20:41:32+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--afYQobe6--/c_fit,fl_progressive,q_80,w_636/ce89495274393e7337d4b193cca8d826.jpg" /><p>The U.S. The Department of Defense has peeked into the future, and it sees a world rife with automated weapons of war. In its first update since 2012, DoD’s guidance overseeing the development, testing, and use of autonomous and semi-autonomous weapons warned of artificial intelligence’s “increasing role” in wars to…</p><p><a href="https://gizmodo.com/ai-pentagon-war-directive-warns-increasing-role-drones-1850036547">Read more...</a></p>

## Feet Data: $25 Million Lawsuit Accuses Foot Locker of Harvesting Details of Conversations About Your Feet
 - [https://gizmodo.com/foot-locker-customer-support-lawsuit-data-privacy-feet-1850024991](https://gizmodo.com/foot-locker-customer-support-lawsuit-data-privacy-feet-1850024991)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 20:23:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--q6E1xPEE--/c_fit,fl_progressive,q_80,w_636/422e8c59512f22f0ed380c23cfaf1e23.jpg" /><p>Move over, OnlyFans, there’s a new feet-sharing game in town. At least, that’s what the plaintiffs argue in a new $25 million class-action privacy lawsuit filed against Foot Locker on Monday. I’m sorry to say that even your feet data isn’t safe.</p><p><a href="https://gizmodo.com/foot-locker-customer-support-lawsuit-data-privacy-feet-1850024991">Read more...</a></p>

## The Most Essential Tips For Keeping Your Most Sensitive Files Private
 - [https://gizmodo.com/encrypt-password-private-files-documents-windows-mac-pc-1850000011](https://gizmodo.com/encrypt-password-private-files-documents-windows-mac-pc-1850000011)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 20:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--es3QiQ06--/c_fit,fl_progressive,q_80,w_636/055bcf5f9a30c7496c814d484c049c4a.jpg" /><p>Your digital files, from photos of your family to your financial records, are likely to be very important to you. So it’s essential that they’re well secured... and well secured means going above and beyond just putting a password on your laptop or a passcode on your phone. There are plenty of other security…</p><p><a href="https://gizmodo.com/encrypt-password-private-files-documents-windows-mac-pc-1850000011">Read more...</a></p>

## Infinity Pool Is an Astonishing, Outrageously Icky Triumph
 - [https://gizmodo.com/infinity-pool-horror-movie-review-cronenberg-mia-goth-1850032455](https://gizmodo.com/infinity-pool-horror-movie-review-cronenberg-mia-goth-1850032455)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 20:15:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--W7DO9wQ_--/c_fit,fl_progressive,q_80,w_636/c39d39a4e4534b801a0d734da5cd0c2e.png" /><p>Of course io9 wants you to read this review, but <a href="https://gizmodo.com/infinity-pool-trailer-brandon-cronenberg-horror-movie-1849869891"><em>Infinity Pool</em></a>—<a href="https://gizmodo.com/2023-movie-preview-marvel-dc-ninja-turtles-saw-snyder-1850003096">the latest from Brandon Cronenberg</a> <em>(Antiviral, <a href="https://gizmodo.com/sean-bean-looks-doomed-again-in-the-trippy-intense-pos-1844917172">Possessor</a>)</em>—is one of those movies you shouldn’t know too much about before you watch it. No spoilers here, but if you want to go in totally blind, you’ve been warned.<br /></p><p><a href="https://gizmodo.com/infinity-pool-horror-movie-review-cronenberg-mia-goth-1850032455">Read more...</a></p>

## Dead Fish, Dead Cows, and Dead Crops in Argentina
 - [https://gizmodo.com/argentina-drought-dead-fish-cows-crops-photos-1850036348](https://gizmodo.com/argentina-drought-dead-fish-cows-crops-photos-1850036348)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 19:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--GFe8duqd--/c_fit,fl_progressive,q_80,w_636/b0e6eeaa62556696913020fc677caeaf.jpg" /><p>Thousands of dead fish washed up along the shore of a river in Argentina this weekend, in the latest symptom of the extreme drought and heat that has gripped the country in recent months, the AP reported.<br /></p><p><a href="https://gizmodo.com/argentina-drought-dead-fish-cows-crops-photos-1850036348">Read more...</a></p>

## Natasha Lyonne Gives Relationship Advice In This Poker Face Clip
 - [https://gizmodo.com/natasha-lyonne-relationship-advice-in-this-poker-face-1850020055](https://gizmodo.com/natasha-lyonne-relationship-advice-in-this-poker-face-1850020055)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 19:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UF0alER8--/c_fit,fl_progressive,q_80,w_636/51176dad9f24ff1e2f4f35652a9b2c8f.jpg" /><p><a href="https://gizmodo.com/natasha-lyonne-relationship-advice-in-this-poker-face-1850020055">Read more...</a></p>

## The Best Third Party Email Apps, Web Browsers, and More
 - [https://gizmodo.com/best-third-party-email-web-browser-notes-music-apps-1850016522](https://gizmodo.com/best-third-party-email-web-browser-notes-music-apps-1850016522)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 19:20:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--8LNuw4_V--/c_fit,fl_progressive,q_80,w_636/e6bad2e4df67deec2338f08a1d46fd22.jpg" /><p>When it comes to the phone apps you rely on every day, from web browsing to email, you might not think too much about switching off the defaults that come with your phone. But the app stores on both Android and iOS are packed with a wealth of alternatives that are worth checking out. Spending some time looking at what…</p><p><a href="https://gizmodo.com/best-third-party-email-web-browser-notes-music-apps-1850016522">Read more...</a></p>

## Concept Video Unveils Robotic Arm for Retrieving Surface Samples on Mars
 - [https://gizmodo.com/sample-transfer-arm-video-mars-sample-return-mission-1850035060](https://gizmodo.com/sample-transfer-arm-video-mars-sample-return-mission-1850035060)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 19:15:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--uU3rGt9A--/c_fit,fl_progressive,q_80,w_636/38ace23199dd61f3c4dc078726232e55.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--HIEppB7a--/c_fit,fl_progressive,q_80,w_636/38ace23199dd61f3c4dc078726232e55.mp4" type="video/mp4" /></video><p>The Mars Sample Return Program is a bold plan to deliver precious samples of Martian soil back to Earth without human intervention. A part of the plan includes  a roughly 8.2-foot-long (2.5 meters) robotic arm that will deliver tubes full of Martian soil to a rocket for delivery back to Earth.<br /></p><p><a href="https://gizmodo.com/sample-transfer-arm-video-mars-sample-return-mission-1850035060">Read more...</a></p>

## Utilities Use Customer Dollars to Pay for Their Lobbying. Here’s How Lawmakers Can Stop It
 - [https://gizmodo.com/utilities-use-customer-dollars-to-pay-for-their-lobbyin-1850036251](https://gizmodo.com/utilities-use-customer-dollars-to-pay-for-their-lobbyin-1850036251)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 19:03:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ZMJ6EnOX--/c_fit,fl_progressive,q_80,w_636/9ee015430b56e747d10a808056ca3302.jpg" /><p><em>This story was originally published by <a href="https://grist.org/" rel="noopener noreferrer" target="_blank">Grist</a>. You can <a href="https://go.grist.org/signup/weekly?utm_campaign=signup-page&amp;utm_medium=web&amp;utm_source=grist&amp;utm_content=weekly" rel="noopener noreferrer" target="_blank">subscribe to its weekly newsletter here</a>.<br /></em></p><p><a href="https://gizmodo.com/utilities-use-customer-dollars-to-pay-for-their-lobbyin-1850036251">Read more...</a></p>

## The FBI Hacked and Infiltrated a Ransomware Gang for Months Before Dismantling It
 - [https://gizmodo.com/fbi-hacks-hive-ransomware-gang-dark-web-1850034645](https://gizmodo.com/fbi-hacks-hive-ransomware-gang-dark-web-1850034645)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 18:57:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Tqtyn62u--/c_fit,fl_progressive,q_80,w_636/38b37b4e6e870a8a6108e87501908ab3.jpg" /><p>In one of the FBI’s most sophisticated cybercrime operations to date, agents infiltrated and spent approximately six months embedded in a prominent ransomware gang’s network,  Justice Department officials announced Thursday. That gang, known as <a href="https://techcrunch.com/2022/11/18/fbi-cisa-hive-ransomware-warning/" rel="noopener noreferrer" target="_blank">Hive</a>, was disrupted earlier this week when  agents  seized its server…</p><p><a href="https://gizmodo.com/fbi-hacks-hive-ransomware-gang-dark-web-1850034645">Read more...</a></p>

## This Scientist Was Fired for Her Activism. She Says It’s Not Going to Stop Her
 - [https://gizmodo.com/rose-abramoff-scientist-arrested-climate-activism-1850011130](https://gizmodo.com/rose-abramoff-scientist-arrested-climate-activism-1850011130)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 18:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--N_V38zXP--/c_fit,fl_progressive,q_80,w_636/b25d14703f976861b0ac7d091d871b3d.jpg" /><p>Last April, Tennessee-based soil scientist Rose Abramoff was arrested after <a href="https://gizmodo.com/it-s-not-political-to-tell-the-truth-scientists-arrest-1848795165">chaining herself to a White House fence</a>. She was one of  about 1,000 scientists around the world who engaged in civil disobedience that week, organized by <a href="https://scientistrebellion.com/" rel="noopener noreferrer" target="_blank">Scientist Rebellion</a>. They demanded “emergency decarbonization” and wealth distribution. </p><p><a href="https://gizmodo.com/rose-abramoff-scientist-arrested-climate-activism-1850011130">Read more...</a></p>

## Netflix's We Have a Ghost Turns David Harbour Into a Supernatural Schlub
 - [https://gizmodo.com/we-have-a-ghost-trailer-david-harbour-netflix-mackie-1850035570](https://gizmodo.com/we-have-a-ghost-trailer-david-harbour-netflix-mackie-1850035570)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 18:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--PpXf_-UI--/c_fit,fl_progressive,q_80,w_636/b4514b521aeac37b98655891e1ae465c.jpg" /><p>After making folks swoon with his daddy-ness in <a href="https://gizmodo.com/stranger-things-vol-4-part-2-review-netflix-1849147031"><em>Stranger Things</em></a>, David Harbour doesn’t seem to have ridden on the coattails of his handsomeness. He hid behind pounds of prosthetics in <a href="https://gizmodo.com/hellboys-blood-soaked-horns-are-too-dull-to-leave-much-1833944953"><em>Hellboy</em></a>, and got extra paunchy for his role as Red Guardian in <a href="https://gizmodo.com/black-widows-supporting-cast-elevates-marvels-solo-stor-1847123839"><em>Black Widow</em></a> and Santa in <a href="https://gizmodo.com/violent-night-2-hot-wheels-a-knock-at-the-cabin-modok-1850022226"><em>Violet Night</em></a>. But are you ready for the sad-…</p><p><a href="https://gizmodo.com/we-have-a-ghost-trailer-david-harbour-netflix-mackie-1850035570">Read more...</a></p>

## Size Does Matter: PlayStation Edge Controller’s Shrunken Battery Explains Its Shorter Operating Life
 - [https://gizmodo.com/dualsense-edge-battery-life-sony-ps5-premium-controller-1850035798](https://gizmodo.com/dualsense-edge-battery-life-sony-ps5-premium-controller-1850035798)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 18:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--UoAzYz8N--/c_fit,fl_progressive,q_80,w_636/45cbc0a4f9ea98abb7e568eaefdeec73.png" /><p>The $200 PlayStation 5 Dualsense Edge controller Sony <a href="https://gizmodo.com/ps5-edge-controller-sony-1849672579">announced last year</a> is meant to provide ultimate try-hard gamers with new options to stomp their opponents. However paying the extra $130 over than the original DualSense’s $70 to access those extra bells and whistles also means cutting a marathon gaming session…</p><p><a href="https://gizmodo.com/dualsense-edge-battery-life-sony-ps5-premium-controller-1850035798">Read more...</a></p>

## What You Need to Know About Critical Role's Mighty Nein
 - [https://gizmodo.com/critical-role-mighty-nein-character-breakdown-1850032120](https://gizmodo.com/critical-role-mighty-nein-character-breakdown-1850032120)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 18:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--sqkNiUFU--/c_fit,fl_progressive,q_80,w_636/3adb36478b7abc6f410a1767d85013bf.jpg" /><p><a href="https://gizmodo.com/legend-of-vox-machina-season-2-trailer-critical-role-1849899058"><em>The Legend of Vox Machina</em></a><em> </em>has been so successful that it was no surprise when Prime Video announced a third season of <em>Critical Role</em>’s animated fantasy was in development—or when the streamer confirmed that <a href="https://gizmodo.com/critical-role-matt-mercer-marisha-ray-opendnd-dnd-ogl-1850019716">the beloved TTRPG’s</a> second campaign, <a href="https://gizmodo.com/mighty-nein-critical-role-tv-show-amazon-prime-video-1850029855"><em>The Mighty Nein</em></a><em>, </em>is now getting an adaptation of its own.<br /></p><p><a href="https://gizmodo.com/critical-role-mighty-nein-character-breakdown-1850032120">Read more...</a></p>

## National Threat Assessment Center Releases First of Its Kind Report on Mass Attacks
 - [https://gizmodo.com/secret-service-mass-shootings-discord-gun-violence-1850034144](https://gizmodo.com/secret-service-mass-shootings-discord-gun-violence-1850034144)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:55:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--QXla9j79--/c_fit,fl_progressive,q_80,w_636/fd3bb403237669d46549a75d4fe7d70d.jpg" /><p>A white supremacist <a href="https://www.npr.org/2022/11/28/1138700312/buffalo-tops-shooter-guilty-plea-state-charges" rel="noopener noreferrer" target="_blank">killed 10 people and injured three others</a> in a Buffalo, New York supermarket in May 2022. While the gunman was carrying out his heinous act of violence, he <a href="https://gizmodo.com/buffalo-shooting-discord-terrorist-twitch-livestream-ge-1848935365">was also livestreaming</a> the shooting on Twitch. For months leading up to the attack, the shooter posted about his plans on Discord. The 19-year…</p><p><a href="https://gizmodo.com/secret-service-mass-shootings-discord-gun-violence-1850034144">Read more...</a></p>

## Amazon Warns Employees to Beware of ChatGPT
 - [https://gizmodo.com/amazon-chatgpt-ai-software-job-coding-1850034383](https://gizmodo.com/amazon-chatgpt-ai-software-job-coding-1850034383)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:45:00+00:00
 - user: rumpel
 - tags: artificial intelligence,amazon

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ejleosYA--/c_fit,fl_progressive,q_80,w_636/f0d50e13dd642982d36d4f28f8ff4a43.jpg" /><p>ChatGPT has been <a href="https://gizmodo.com/google-openai-chatgpt-google-search-1849922839">making the tech industry sweat</a> since its rise in popularity last year, and now <a href="https://gizmodo.com/amazon-prime-rxpass-launch-pharmacy-generic-drugs-1850023034">Amazon</a> is feeling the heat too. According to internal communications from the company as viewed by <a href="https://www.businessinsider.com/amazon-chatgpt-openai-warns-employees-not-share-confidential-information-microsoft-2023-1" rel="noopener noreferrer" target="_blank">Insider</a>, an Amazon lawyer has urged employees not to share code with the <a href="https://gizmodo.com/chat-gpt-openai-ai-finance-ai-everything-we-know-1850018307">AI chatbot</a>.<br /></p><p><a href="https://gizmodo.com/amazon-chatgpt-ai-software-job-coding-1850034383">Read more...</a></p>

## FTX's 'More Than 1 Million Creditors' Include Netflix, DoorDash, and Airbnb
 - [https://gizmodo.com/ftx-sam-bankman-fried-crypto-netflix-airbnb-1850034516](https://gizmodo.com/ftx-sam-bankman-fried-crypto-netflix-airbnb-1850034516)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:35:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--LHf0kDUQ--/c_fit,fl_progressive,q_80,w_636/7acfec39d9c70ebc4314a22aeec9b489.jpg" /><p>The ongoing Chapter 11 bankruptcy of FTX is still trying to claw back the billions of dollars needed to make customers and investors whole. One problem with this lofty goal is the nearly <a href="https://gizmodo.com/ftx-sbf-bitcoin-price-crypto-bankrupt-17-ftc-complaints-1849917506">10 million FTX customers</a> who still had funds on the exchange before its collapse are apparently being lumped in with FTX employees’…</p><p><a href="https://gizmodo.com/ftx-sam-bankman-fried-crypto-netflix-airbnb-1850034516">Read more...</a></p>

## Scientists Watched Hours of Cat Videos to Learn Something New About Kitty Behavior
 - [https://gizmodo.com/cats-playing-or-fighting-research-1850034848](https://gizmodo.com/cats-playing-or-fighting-research-1850034848)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:31:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--kf_3tXgz--/c_fit,fl_progressive,q_80,w_636/6b01e8cbb715833c9fabdef9559134f3.jpg" /><p>Veterinarians have conducted the sort of research that most anyone on the internet would sign up for: Watching over a hundred videos of cats hanging out with other cats. The lessons learned from their marathon viewing may help owners better identify when their cats are playfully tussling or about to get into a serious…</p><p><a href="https://gizmodo.com/cats-playing-or-fighting-research-1850034848">Read more...</a></p>

## NASA's Lucy Probe to Visit Bonus Asteroid This Year
 - [https://gizmodo.com/nasa-lucy-probe-visit-bonus-asteroid-1850034827](https://gizmodo.com/nasa-lucy-probe-visit-bonus-asteroid-1850034827)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:10:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--nCWhNK2D--/c_fit,fl_progressive,q_80,w_636/be017762a53b90edc3b44dbf54e90e7f.jpg" /><p>There’s been a slight change to Lucy’s already-impressive itinerary. The NASA spacecraft, currently en route to visit Jupiter’s mysterious Trojan asteroids, will fly past a tiny main belt asteroid in order to test an innovative tracking system.<br /></p><p><a href="https://gizmodo.com/nasa-lucy-probe-visit-bonus-asteroid-1850034827">Read more...</a></p>

## The New Shazam: Fury of the Gods Trailer Is Bursting With Fury and Gods
 - [https://gizmodo.com/shazam-2-trailer-fury-of-the-gods-zachary-levi-dc-films-1850031092](https://gizmodo.com/shazam-2-trailer-fury-of-the-gods-zachary-levi-dc-films-1850031092)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--iTSYinwL--/c_fit,fl_progressive,q_80,w_636/6a98ba2d37393ac2a72b080050423afc.jpg" /><p>The <a href="https://gizmodo.com/a-brief-guide-to-shazams-surprising-mid-credits-charact-1834004429">balance of power</a> in the DC Universe is about to change. We’re, of course, talking about new heads of the DC Films division, <a href="https://gizmodo.com/james-gunn-head-of-dc-movies-and-tv-warner-bros-1849701460">James Gunn and Peter Safran</a>, the latter of whom produced <a href="https://gizmodo.com/how-shazam-will-use-childlike-wonder-to-set-it-apart-fr-1831816883">the long-awaited <em>Shazam</em> sequel</a>, <em>Shazam: Fury of the Gods,</em> which has a new trailer out today<em>.</em> What, did you think we were talking <a href="https://gizmodo.com/black-adam-review-dwayne-johnson-the-rock-superman-dc-1849627545">about…</a></p><p><a href="https://gizmodo.com/shazam-2-trailer-fury-of-the-gods-zachary-levi-dc-films-1850031092">Read more...</a></p>

## You Can Minecraft Your Life With These Pixelated Building Toys
 - [https://gizmodo.com/voxart-voxel-pixel-building-toy-minecraft-legos-system-1850034775](https://gizmodo.com/voxart-voxel-pixel-building-toy-minecraft-legos-system-1850034775)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 17:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_FQw1JPE--/c_fit,fl_progressive,q_80,w_636/4d8a7383f847eb10f49d8e762c6b2bb6.jpg" /><p>Enamored with the low-poly aesthetic of Minecraft’s blocky worlds? Wish your life was more like a pixelated 8-bit video game? <a href="https://vox.art/" rel="noopener noreferrer" target="_blank">Voxart is a new building toy</a> that can also be used to <a href="https://www.kickstarter.com/projects/951366942/clixel-click-tile-construction-set-in-pixel-art-style" rel="noopener noreferrer" target="_blank">create retro-style art pieces</a> for those ready to shun modern conveniences like anti-aliasing and finally ban curved surfaces from their…</p><p><a href="https://gizmodo.com/voxart-voxel-pixel-building-toy-minecraft-legos-system-1850034775">Read more...</a></p>

## Axon Board Member Volunteers for Tasing Weeks After LAPD Tased Unarmed Black Man Who Died Hours Later
 - [https://gizmodo.com/taser-axon-live-demo-lapd-keenan-anderson-death-tased-1850031962](https://gizmodo.com/taser-axon-live-demo-lapd-keenan-anderson-death-tased-1850031962)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 16:44:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--KYVHDP5r--/c_fit,fl_progressive,q_80,w_636/49d6f238afc3b64fb5191ce67174b8c5.jpg" /><p>When Silicon Valley investor and Axon board member Hadi Partovi strutted onstage to address a packed crowd at this week’s <a href="https://www.axon.com/tasercon-livestream" rel="noopener noreferrer" target="_blank">TASERCON</a> event, he did it to put to rest a nagging critique often levied at the policing tech company’s top executives. If the so-called “non-lethal” electric-shock weapons, Axon’s patented Tasers,…</p><p><a href="https://gizmodo.com/taser-axon-live-demo-lapd-keenan-anderson-death-tased-1850031962">Read more...</a></p>

## Doom Patrol and Titans Have Officially Been Doomed
 - [https://gizmodo.com/doom-patrol-titans-canceled-season-5-hbo-max-james-gunn-1850034230](https://gizmodo.com/doom-patrol-titans-canceled-season-5-hbo-max-james-gunn-1850034230)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 16:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--ky4KLa4s--/c_fit,fl_progressive,q_80,w_636/380146a72cc1fad57c56891e5ed4ba40.jpg" /><p>The fourth and final seasons of HBO Max’s excellent <a href="https://gizmodo.com/doom-patrol-season-4-trailer-new-hbo-max-dc-universe-1849627885"><em>Doom Patrol</em></a><em> </em>and arguably not-quite-as-excellent <a href="https://gizmodo.com/titans-season-4-trailer-hbo-max-brother-blood-dc-comics-1849627758"><em>Titans</em></a> TV series will end after their fourth seasons, according to <a href="https://www.hollywoodreporter.com/tv/tv-news/titans-doom-patrol-ending-hbo-max-1235310044/" rel="noopener noreferrer" target="_blank"><em>The Hollywood Reporter</em></a>. And according to James Gunn, who so recently became <a href="https://gizmodo.com/james-gunn-head-of-dc-movies-and-tv-warner-bros-1849701460">overseer of the DC live-action universe</a>, and who’s been wiping the…</p><p><a href="https://gizmodo.com/doom-patrol-titans-canceled-season-5-hbo-max-james-gunn-1850034230">Read more...</a></p>

## Nationwide Ban on TikTok Inches Closer to Reality
 - [https://gizmodo.com/tiktok-china-byte-dance-ban-viral-videos-privacy-1850034366](https://gizmodo.com/tiktok-china-byte-dance-ban-viral-videos-privacy-1850034366)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 16:25:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--E2shlcT4--/c_fit,fl_progressive,q_80,w_636/56588556a8c47c096ba0b7070a5c3042.jpg" /><p>The White House is facing mounting pressure from Congress to ban the widely popular TikTok app nationwide after Sen. Josh Hawley (R-MO)<strong> </strong>and Congressman Ken Buck (R-CO) introduced a piece of <a href="https://files.constantcontact.com/60ec52f3801/85673deb-ea76-4f35-8891-bfe50422c042.pdf" rel="noopener noreferrer" target="_blank">legislation</a> on Wednesday to curb its use. A similar bill to <a href="https://gizmodo.com/tiktok-bans-are-dumb-1849958652">ban TikTok</a> in the U.S. was filed during the last Congressional session…</p><p><a href="https://gizmodo.com/tiktok-china-byte-dance-ban-viral-videos-privacy-1850034366">Read more...</a></p>

## 65 Promises a Lone Wolf and Cub Plot Amid Dino Terror
 - [https://gizmodo.com/65-dinosaur-adam-driver-film-trailer-1850034166](https://gizmodo.com/65-dinosaur-adam-driver-film-trailer-1850034166)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 15:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--_4W9LlRE--/c_fit,fl_progressive,q_80,w_636/267a89f75165a287b264b7ff9d3a16e2.png" /><p>If any film can prove that you can take a goofy ass premise (time travel! <a href="https://gizmodo.com/dinosaurs-like-t-rex-were-more-tyrannical-than-we-real-1846353911">dinosaurs</a>!) and make something decent and exciting out of it, it’ll be <a href="https://gizmodo.com/adam-driver-65-trailer-sci-fi-dinosaurs-movie-1849892530"><em>65</em></a>. Starring <a href="https://gizmodo.com/adam-driver-65-trailer-sci-fi-dinosaurs-movie-1849892530">Adam Driver</a> and Ariana Greenblatt, the trailer already has me pretty invested with tight editing, a clear level set of expectations, decent Dino VFX, and (lo and…</p><p><a href="https://gizmodo.com/65-dinosaur-adam-driver-film-trailer-1850034166">Read more...</a></p>

## Star Trek: Picard's Final Season Won't End Well For Every TNG Hero
 - [https://gizmodo.com/star-trek-picard-season-3-tng-cast-potential-deaths-1850030245](https://gizmodo.com/star-trek-picard-season-3-tng-cast-potential-deaths-1850030245)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 15:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--i6JJ9UWf--/c_fit,fl_progressive,q_80,w_636/5cdb3daff686df46a506b312feb9c529.png" /><p><em>Aqua Teen Hunger Force</em> will return for a 12th season. Roxanne Benjamin is still working on her <em>Night of the Comet </em>remake. Get another glimpse at <em>The Flash</em>’s final season. Plus, <em>Gotham Knights</em> casting, and a new look at <em>Shazam: Fury of the Gods</em>. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/star-trek-picard-season-3-tng-cast-potential-deaths-1850030245">Read more...</a></p>

## The Year Ahead in Generative AI
 - [https://gizmodo.com/ai-chatgpt-dalle-midjourney-stable-diffusion-deepfake-1849910573](https://gizmodo.com/ai-chatgpt-dalle-midjourney-stable-diffusion-deepfake-1849910573)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 14:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--RC6Jvbet--/c_fit,fl_progressive,q_80,w_636/f074d4b3d36d8242ba75d437bfbbc68b.jpg" /><p>At this very moment, I could boot up OpenAI’s popular <a href="https://gizmodo.com/chat-gpt-openai-ai-finance-ai-everything-we-know-1850018307">ChatGPT</a> and ask it to <a href="https://gizmodo.com/chatgpt-gizmodo-artificial-intelligence-openai-media-1849876066">write this article for me</a>. Or I could ask it to “write a lullaby about a cool goose who just wants to honk.” I could pull up Midjourney, Stable Diffusion, DALL-E 2, or any number of <a href="https://gizmodo.com/ai-art-generator-midjourney-starry-ai-1849397263">AI art generators</a> and order it to craft me an portrait of…</p><p><a href="https://gizmodo.com/ai-chatgpt-dalle-midjourney-stable-diffusion-deepfake-1849910573">Read more...</a></p>

## Elon Tries to Convince Tesla Investors That Twitter Isn’t a Problem, Really
 - [https://gizmodo.com/tesla-twitter-elon-musk-earnings-1850033951](https://gizmodo.com/tesla-twitter-elon-musk-earnings-1850033951)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 14:14:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--J4GpCqaw--/c_fit,fl_progressive,q_80,w_636/ae43ac57c93cf58899ad21b6bde419d6.jpg" /><p>Tesla CEO Elon Musk tried to convince investors that his chaotic ownership of Twitter was actually good for the electric carmaker, despite the fact that Tesla shareholders have seen their <a href="https://www.wsj.com/articles/tesla-stock-is-headed-for-its-biggest-ever-annual-decline-11672374248" rel="noopener noreferrer" target="_blank">stock price plummet</a> since Musk decided to buy the blue bird app on a whim last year. </p><p><a href="https://gizmodo.com/tesla-twitter-elon-musk-earnings-1850033951">Read more...</a></p>

## The HP Dragonfly Folio G3 is One of the Fastest 2-in-1s We’ve Tested
 - [https://gizmodo.com/hp-dragonfly-folio-g3-laptop-tablet-convertible-busines-1850032311](https://gizmodo.com/hp-dragonfly-folio-g3-laptop-tablet-convertible-busines-1850032311)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 13:30:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--vnLvBuEI--/c_fit,fl_progressive,q_80,w_636/a575162dfb5466fd86c4f874452f0208.jpg" /><p>Notebooks capable of transforming into tablets have been a staple of the business world for years, but HP’s Dragonfly Folio G3 brings a unique twist to the classic 2-in-1 productivity PC. Designed with business professionals in mind, it offers a stylish leather-trimmed look, security-enhanced (and IT-compliant)…</p><p><a href="https://gizmodo.com/hp-dragonfly-folio-g3-laptop-tablet-convertible-busines-1850032311">Read more...</a></p>

## Elon Musk Reportedly Strives to Raise $3 Billion to Save Twitter
 - [https://gizmodo.com/elon-musk-twitter-debt-1850032137](https://gizmodo.com/elon-musk-twitter-debt-1850032137)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 13:16:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Su5IWF-O--/c_fit,fl_progressive,q_80,w_636/1410e9a1631b604a6bb96da166d78b24.jpg" /><p>Twitter CEO <a href="https://gizmodo.com/elon-musk-twitter-agreed-with-himself-elon-tweets-1849960815">Elon Musk</a> is reportedly looking into raising $3 billion to offset the recent debt the company has accrued since he took over in October. The company is currently $13 billion in debt, according to people familiar with the matter, and Musk said in December that he planned to sell $3 billion of his Twitter…</p><p><a href="https://gizmodo.com/elon-musk-twitter-debt-1850032137">Read more...</a></p>

## The Best and Weirdest Gadgets For Minimizing Sofa Interruptions During the Super Bowl
 - [https://gizmodo.com/super-bowl-best-weirdest-gadgets-party-kitchen-snacks-1850029494](https://gizmodo.com/super-bowl-best-weirdest-gadgets-party-kitchen-snacks-1850029494)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 13:00:00+00:00
 - user: None

<video loop="" poster="https://i.kinja-img.com/gawker-media/image/upload/s--7a7BZlLB--/c_fit,fl_progressive,q_80,w_636/da1b9aa081bf86b05bc01e31e770be6f.jpg"><source src="https://i.kinja-img.com/gawker-media/image/upload/s--ehLOy7GC--/c_fit,fl_progressive,q_80,w_636/da1b9aa081bf86b05bc01e31e770be6f.mp4" type="video/mp4" /></video><p>Super Bowl Sunday poses a big challenge for binge-watchers. Streaming services let you pause a show for the occasional snack run, and while broadcast TV still serves up convenient commercial breaks, the ads are often the best part of the big game. If you don’t want to miss a moment, you’ll need to plan ahead to…</p><p><a href="https://gizmodo.com/super-bowl-best-weirdest-gadgets-party-kitchen-snacks-1850029494">Read more...</a></p>

## DoNotPay Retires 'Robot Lawyer' Before It Even Has Its First Case
 - [https://gizmodo.com/donotpay-robot-lawyer-ai-parking-ticket-1850031456](https://gizmodo.com/donotpay-robot-lawyer-ai-parking-ticket-1850031456)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 12:45:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--IW9br0c1--/c_fit,fl_progressive,q_80,w_636/77fa1fcf2490bab0ed006f670f72d885.jpg" /><p>If you’ve been fantasizing about the day when artificial intelligence could get you out of paying traffic tickets, you’ll just have to keep dreaming. DoNotPay has backed out of its <a href="https://gizmodo.com/donotpay-speeding-ticket-chatgpt-1849960272?rev=1674677940179">plans to use an AI-powered “robot lawyer”</a> to council a  defendant through a courtroom hearing in real time. The reason why? Well,…</p><p><a href="https://gizmodo.com/donotpay-robot-lawyer-ai-parking-ticket-1850031456">Read more...</a></p>

## Everything You Need to Know About the Google Antitrust Lawsuit
 - [https://gizmodo.com/google-lawsuit-justice-department-ads-antitrust-explain-1850031288](https://gizmodo.com/google-lawsuit-justice-department-ads-antitrust-explain-1850031288)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 11:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--pr7tT0Pn--/c_fit,fl_progressive,q_80,w_636/1fc245f2ad1e65b0ff3bde37b45d6f9b.jpg" /><p>On Tuesday, the US Department of Justice <a href="https://gizmodo.com/google-ads-gmail-monopoly-lawsuit-justice-department-1850025279">filed an antitrust lawsuit</a> against Google. Joined by eight state attorneys general, the federal government said the tech giant is running an illegal monopoly in the digital ad market, and it wants the courts to compel Google to sell its subsidiary ad businesses, breaking the…</p><p><a href="https://gizmodo.com/google-lawsuit-justice-department-ads-antitrust-explain-1850031288">Read more...</a></p>

## Here's a Sneak Peek of Mickey and Minnie's Runaway Railway Queue at Disneyland
 - [https://gizmodo.com/disneyland-sneak-peek-mickey-minnies-runaway-railway-1850032533](https://gizmodo.com/disneyland-sneak-peek-mickey-minnies-runaway-railway-1850032533)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-01-26 01:00:00+00:00
 - user: None

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/s--Boe2ib2P--/c_fit,fl_progressive,q_80,w_636/6134bae9f6e56469ac3587096f9f0ad6.jpg" /><p>This week, io9 was invited to preview <em>Mickey and Minnie’s Runaway Railway</em>— <a href="https://gizmodo.com/theme-park-news-disney-parks-universal-studios-marvel-1849999143">Disney Parks</a>’ latest attraction—just in time for the Disney100 celebration, which kicks off at the <a href="https://gizmodo.com/best-of-theme-parks-2022-disney-universal-studios-1849901949">Disneyland Resort</a> this week. </p><p><a href="https://gizmodo.com/disneyland-sneak-peek-mickey-minnies-runaway-railway-1850032533">Read more...</a></p>
