# Source NY times technology, Source URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, Source language: en-US

## A Federal Court Blocks California’s New Medical Misinformation Law
 - [https://www.nytimes.com/2023/01/26/technology/federal-court-blocks-california-medical-misinformation-law.html](https://www.nytimes.com/2023/01/26/technology/federal-court-blocks-california-medical-misinformation-law.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-26 23:47:04+00:00
 - user: None

California’s law sought to punish doctors who give patients false information about Covid-19.

## Justice Dept. Dismantles a Major Ransomware Operation
 - [https://www.nytimes.com/2023/01/26/us/politics/justice-department-ransomware-hive.html](https://www.nytimes.com/2023/01/26/us/politics/justice-department-ransomware-hive.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-26 21:25:57+00:00
 - user: None

The department said it had successfully prevented victims from having to pay $130 million in ransoms to Hive, a prolific ransomware gang, before seizing two of the group’s servers on Wednesday night.

## Stripe Hires Investment Banks to Explore Public Listing
 - [https://www.nytimes.com/2023/01/26/technology/stripe-potential-public-listing.html](https://www.nytimes.com/2023/01/26/technology/stripe-potential-public-listing.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-26 19:55:07+00:00
 - user: None

The payments processing start-up, one of the world’s most valuable private companies, could go public in the next year, people with knowledge of the matter said.

## University of Texas Will Offer Large-Scale Online Master’s Degree in A.I.
 - [https://www.nytimes.com/2023/01/26/technology/ai-masters-degree-texas.html](https://www.nytimes.com/2023/01/26/technology/ai-masters-degree-texas.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-26 13:00:07+00:00
 - user: None

Amid a boom in new tools like ChatGPT, the Austin campus plans to train thousands of students in sought-after skills in artificial intelligence.

## TikTok’s New Defense in Washington: Going on the Offense
 - [https://www.nytimes.com/2023/01/26/technology/tiktok-bytedance-data-security.html](https://www.nytimes.com/2023/01/26/technology/tiktok-bytedance-data-security.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-01-26 10:00:30+00:00
 - user: None

Keeping its head down has not paid off for the company, which now faces regulatory pressure on many fronts. So it is starting to speak out.
