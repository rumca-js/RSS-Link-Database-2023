# Source wiadomości.gazeta.pl, Source URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, Source language: pl-PL

## Zaginięcie Iwony Wieczorek. Śledczy wciąż drążą. "To może pójść w złym kierunku"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402095,zaginiecie-iwony-wieczorek-sledczy-wciaz-draza-to-moze-pojsc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402095,zaginiecie-iwony-wieczorek-sledczy-wciaz-draza-to-moze-pojsc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 20:48:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7e/dc/1b/z29215870M,Iwona-Wieczorek.jpg" vspace="2" />O sprawie Iwony Wieczorek od ponad dekady mówi cała Polska. W ostatnim czasie śledczy zintensyfikowali działania, dostarczając opinii publicznej materiał do snucia domysłów. - Chyba błądzą po omacku - komentuje w Onecie Marta Bilska. - Cały czas nie ma ani jednego dowodu, który pomógłby nam wskazać sprawcę albo rozwiązanie - mówi "Faktowi" Mikołaj Podolski. Dziennikarze są zgodni, że dochodzenie "może pójść w złym kierunku".

## Olkusz. Zakaz wstępu do lasów do marca. Powodem niebezpieczne zapadliska
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402046,olkusz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402046,olkusz.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 20:16:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/14/0a/1c/z29402132M,Zapadliska-na-terenie-Olkusza-i-okolic.jpg" vspace="2" />Nadleśnictwo Olkusz w związku z niebezpiecznymi zapadliskami powstającymi na terenie powiatu olkuskiego wprowadziło zakaz wstępu do lasów. Ma on obowiązywać do końca marca 2023 roku, jednak w związku z nadal występującym zagrożeniem nadleśnictwo planuje przedłużyć okres obowiązywania zakazu - informuje "Gazeta Krakowska".

## Pomorskie. Bezwzględne więzienie za zabicie i odcięcie głowy żubra. Kłusownik twierdził, że się pomylił
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402096,pomorskie-bezwzgledne-wiezienie-za-zabicie-i-odciecie-glowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29402096,pomorskie-bezwzgledne-wiezienie-za-zabicie-i-odciecie-glowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 19:30:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d6/fc/1b/z29346518M.jpg" vspace="2" />17 miesięcy bezwzględnego więzienia dla kłusownika, który zabił żubra w miejscowości Dąbrówno w województwie pomorskim, a następnie ze wspólnikiem odciął mu głowę. Sąd nie przyjął tłumaczenia, że mężczyzna rzekomo pomylił żubra z dzikiem. Wyrok zapadł ponad trzy lata po zabiciu zwierzęcia - podaje "Gazeta Wyborcza".

## Tatry. Skandaliczne zachowanie turystów. Wezwali pomoc, zostawili kolegę na szlaku i okłamali toprowców
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401786,tatry-skandaliczne-zachowanie-turystow-wezwali-pomoc-zostawili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401786,tatry-skandaliczne-zachowanie-turystow-wezwali-pomoc-zostawili.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 18:21:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e4/0a/1c/z29401828M,Smiglowiec-TOPR--zdjecie-ilustrujace-.jpg" vspace="2" />TOPR poinformowało w swoich mediach społecznościowych o skandalicznym zachowaniu trzech turystów. Ci w środę 25 stycznia poprosili telefonicznie o ewakuację śmigłowcem, która nie mogła odbyć się z powodu warunków pogodowych. Dwójka z nich pozostawiła więc na szlaku swojego kolegę, a kiedy w drodze na dół spotkali spieszących z ratunkiem toprowców, okłamali ich, twierdząc, że "nie wiedzą nic o osobach potrzebujących pomocy".

## Podlasie. Zgwałconej 14-latce odmówiono legalnej aborcji. Ginekolog: To zwykłe ku***stwo
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401531,podlasie-zgwalconej-14-latce-odmowiono-legalnej-aborcji-ginekolog.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401531,podlasie-zgwalconej-14-latce-odmowiono-legalnej-aborcji-ginekolog.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 18:09:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/34/95/1a/z27874100M,Federa-do-ginekologow-i-ginekolozek--Promujcie-poz.jpg" vspace="2" />Lekarze odmówili legalnej aborcji zgwałconej 14-latce z niepełnosprawnością intelektualną. Powód? Klauzula sumienia. Dziewczynce pomogły aktywistki. Zabieg przerwania ciąży przeprowadzono w Warszawie. - To już nie jest kwestia bycia lekarzem, ale bycia człowiekiem. Jeśli ktoś odmawia pomocy w takiej sytuacji, to powinien zastanowić się nad swoim człowieczeństwem - komentuje w rozmowie z Gazeta.pl dr Maciej W. Socha, ordynator oddziału położniczo-ginekologicznego.

## Dorota Bawołek nie pracuje już w Polsacie. Było o niej głośno za sprawą Tuska. Media: Podpadła Solorzowi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401650,polsat-zakonczyl-wspolprace-z-dorota-bawolek-media-spekuluja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401650,polsat-zakonczyl-wspolprace-z-dorota-bawolek-media-spekuluja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 17:31:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f5/0a/1c/z29401845M,Dorota-Bawolek-i-Donald-Tusk--zdj--ilustracyjne-.jpg" vspace="2" />Polsat po 15 latach zakończył współpracę z dziennikarką Dorotą Bawołek, co potwierdził rzecznik prasowy telewizji w rozmowie z Wirtualnymi Mediami. Nie podał jednak powodu takiej decyzji. Tym samym stacja została bez stałego korespondenta w Brukseli. Niedawno o Bawołek było głośno za sprawą zarzutów TVP, iż "przeszkodziła" ekipie stacji w uzyskaniu komentarza od Donalda Tuska.

## Zabierzów. Policja: Pies nie został zakopany żywcem. Odnaleziono jego właściciela
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401330,zabierzow-wlasciciel-zakopanego-psa-odnaleziony-kochamy-tego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401330,zabierzow-wlasciciel-zakopanego-psa-odnaleziony-kochamy-tego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 17:10:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f8/0a/1c/z29401592M,Wlasciciel-zakopanego-psa-odnaleziony.jpg" vspace="2" />Małopolska policja poinformowała o zgłoszeniu się na komisariat właściciela psa, który 23 stycznia został wykopany z ziemi. Psa odnaleźli robotnicy podczas pracy koparką na terenie wsi Zabierzów (woj. małopolskie). Funkcjonariusze podkreślają, że pies nie został "zakopany żywcem", a był to jedynie nieszczęśliwy wypadek, a zwierzę ugrzęzło w błocie.

## Podhale. Mężczyzna usiłował zabić niemowlę. Prokuratura podaje szczegóły
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401563,podhale-mezczyzna-usilowal-zabic-niemowle-prokuratura-podaje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29401563,podhale-mezczyzna-usilowal-zabic-niemowle-prokuratura-podaje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 16:12:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/78/0a/1c/z29401720M,Policja-na-Podhalu.jpg" vspace="2" />29-latek, który próbował zabić czteromiesięczne dziecko, trafił do aresztu. Policja zatrzymała mężczyznę i poinformował, że napastnik użył przedmiotu przypominającego śrubokręt, a życie dziecka uratowała natychmiastowa reakcja mamy i pomoc lekarzy.

## Agata Młynarska w Porannej Rozmowie Gazeta.pl - już w piątek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29400739,agata-mlynarska-w-porannej-rozmowie-gazeta-pl-juz-w-piatek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29400739,agata-mlynarska-w-porannej-rozmowie-gazeta-pl-juz-w-piatek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 15:26:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/df/0a/1c/z29401567M,Agata-Mlynarska-goscinia-Porannej-Rozmowy-Gazeta-p.jpg" vspace="2" />31. Finał Wielkiej Orkiestry Świątecznej Pomocy już w niedzielę, a w naszym studiu gości Agata Młynarska, która była przy narodzinach WOŚP. Wielu z nas pamięta jeszcze, jak współprowadziła pierwszy finał - w miętowej koszuli i krawacie. Jak wspomina go sama Młynarska?

## Komendant rozkazał mi czynność seksualną. Gdy to zgłosiłam, próbowano mnie zniszczyć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399709,komendat-rozkazal-mi-czynnosc-seksualna-gdy-to-zglosilam-probowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399709,komendat-rozkazal-mi-czynnosc-seksualna-gdy-to-zglosilam-probowano.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 14:51:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/09/1c/z29399897M,Sylwia-Szary-spotkala-sie-z-mobbingiem-i-molestowa.jpg" vspace="2" />Policjantka Sylwia Szary ze Słubic zgłosiła działania mobbingowe i molestowanie seksualne, a zaraz potem rozpoczęto wobec niej szereg działań odwetowych. - Próbowano mnie zniszczyć - wspomina funkcjonariuszka. - Przeciwko mnie działał cały aparat władzy za publiczne pieniądze - zaznacza.

## Poznań. Złodziej kaskader włamał się na rympał. Do domu wszedł razem z drzwiami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29400685,poznan-wlamal-sie-do-domu-na-rympal-i-od-razu-ruszyl-na-pietro.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29400685,poznan-wlamal-sie-do-domu-na-rympal-i-od-razu-ruszyl-na-pietro.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 14:37:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/80/09/1c/z29400960M,Zlodziej-wlamal-sie-do-domu-w-Poznaniu.jpg" vspace="2" />Złodziej włamał się do jednego z domów w dzielnicy Grunwald w Poznaniu na rympał - wyważył całe drzwi balkonowe. Włamywacz był przekonany, że w domu nikogo nie ma. Przepłoszył go sąsiad.

## Kłodzino. Pies poszukiwany od tygodnia ugrzązł w studzience. "Patrzył wzrokiem błagającym o pomoc"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398879,pies-poszukiwany-od-tygodnia-ugrzazl-w-studzience-kanalizacyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398879,pies-poszukiwany-od-tygodnia-ugrzazl-w-studzience-kanalizacyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 12:27:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4c/09/1c/z29400396M,Klodzino--Pies-ugrzazl-w-studzience-kanalizacyjnej.jpg" vspace="2" />Pies Robin, który uciekł z gospodarstwa w miejscowości Rosiny, został po tygodniu odnaleziony. Na zwierzę uwięzione w studzience kanalizacyjnej natrafili turyści zwiedzający ruiny pałacu w Kłodzinie. Właściciel psa, który już stracił nadzieję, że Robin się odnajdzie, był wzruszony.

## Podkarpacie. Były proboszcz z Domostawy usłyszał zarzuty. Chodzi o przywłaszczenie 450 tys. zł
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399933,podkarpacie-byly-proboszcz-z-domostawy-uslyszal-zarzuty-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399933,podkarpacie-byly-proboszcz-z-domostawy-uslyszal-zarzuty-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 12:01:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/7c/1b/z28823383M.jpg" vspace="2" />Byłemu proboszczowi z Domostawy (woj. podkarpackie) postawiono zarzut przywłaszczenia mienia. Chodzi o 450 tys. zł, które według prokuratury należały do parafii. Duchowny twierdzi, że były to jego prywatne środki.

## Wielkopolska. W oczyszczalni ścieków znaleziono płód dziecka
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399387,wielkopolska-w-oczyszczalni-sciekow-znaleziono-plod-dziecka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29399387,wielkopolska-w-oczyszczalni-sciekow-znaleziono-plod-dziecka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 10:36:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/00/1c/z29360577M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W oczyszczalni ścieków w miejscowości Okonek (woj. wielkopolskie) znaleziono płód dziecka. Informacje te przekazało RMF FM. Na miejscu pracują służby.

## Mińsk Mazowiecki. Pacjenci ewakuowani z SOR-u. Mieli skarżyć się na pieczenie oczu i swędzenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398627,minsk-mazowiecki-pacjenci-ewakuowani-z-sor-u-mieli-skarzyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398627,minsk-mazowiecki-pacjenci-ewakuowani-z-sor-u-mieli-skarzyc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 06:21:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/69/94/1a/z27873129M,Straz-pozarna---zdjecie-ilustracyjne.jpg" vspace="2" />Na SOR-ze szpitala w Mińsku Mazowieckim doszło do ewakuacji. Podejrzewano, że na oddziale może znajdować się substancja chemiczna, która źle wpływa na znajdujące się tam osoby. Pacjenci mieli skarżyć się bowiem na swędzenie skóry i pieczenie oczu.

## PIT 2022. Komu skarbówka zwróci ponad 3000 zł? Ważnych kilka czynników
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398385,pit-2022-komu-skarbowka-zwroci-ponad-3000-zl-waznych-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398385,pit-2022-komu-skarbowka-zwroci-ponad-3000-zl-waznych-kilka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 06:00:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/42/12/1b/z28387650M,PIT--zdjecie-ilustracyjne-.jpg" vspace="2" />IKZE (Indywidualne Konto Zabezpieczenia Emerytalnego) wiąże się z dodatkowymi przywilejami, o czym warto pamiętać przy składaniu deklaracji podatkowej za 2022 rok. Wpłaty można odliczyć od podstawy opodatkowania.

## Kolęda. Wpadki z wizyt księży. "Proszę zabrać to grzeszne zwierzę", "a buzi?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398187,koleda-wpadki-z-wizyt-ksiezy-prosze-zabrac-to-grzeszne-zwierze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398187,koleda-wpadki-z-wizyt-ksiezy-prosze-zabrac-to-grzeszne-zwierze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 05:45:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/29/01/1c/z29366569M,Koleda--zdjecie-ilustracyjne-.jpg" vspace="2" />Czasem coś się zgubi i trzeba kombinować, innym razem pies "nagrzeszy" i zdenerwuje księdza - przebieg kolędy w może wymknąć się spod kontroli. Internauci wspominają, co zabawnego spotkało ich podczas domowej wizyty duszpasterskiej.

## Pogoda długoterminowa - luty 2023. Rozpadnie się wir polarny, wróci zima. Burze śnieżne i siarczysty mróz
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398056,pogoda-na-luty-2023-synoptycy-zapowiadaja-powrot-zimy-czekaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,29398056,pogoda-na-luty-2023-synoptycy-zapowiadaja-powrot-zimy-czekaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

<img align="left" hspace="4" src="https://bi.im-g.pl/im/90/09/1c/z29398160M,Zima--zdjecie-ilustrujace-.jpg" vspace="2" />Synoptycy opublikowali pierwsze długoterminowe prognozy pogody na luty 2023. Ma być on nieco cieplejszy niż w ubiegłych latach, jednak zdaniem specjalistów nie wyklucza to pojawienia się burz śnieżnych i dużych mrozów. Według prognoz możemy spodziewać się kolejnego ataku zimy.
