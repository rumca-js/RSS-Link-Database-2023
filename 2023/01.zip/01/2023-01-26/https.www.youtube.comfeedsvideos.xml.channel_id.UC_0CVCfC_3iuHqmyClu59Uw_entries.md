# Source ETA PRIME, Source URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, Source language: en-US

## Nuc Box 10 Hands-On Review, A Fast Ultra Tiny Ryzen Powered 4K Mini PC
 - [https://www.youtube.com/watch?v=W35o_Lh-IF4](https://www.youtube.com/watch?v=W35o_Lh-IF4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-01-26 15:07:00+00:00
 - user: None

In this video, we take look at the new GMKtec Nuc Box 10 Ryzen-powered mini PC. We do an unboxing, run some benchmarks, Test some PC games in windows and run some emulators like RPCS3 for PS3, CEMU for Wii U, and PS2 using PCSX2.

Get The NucBox 10 On Amazon: https://amzn.to/3wxB9cs

Official Website Discount:
$30 OFF Code: ETA-KB10$30
https://www.gmktec.com/products/amd-ryzen%E2%84%A2-7-5800u-mini-pc-nucbox-10

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

25% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows10 Home Key($14): https://biitt.ly/2tPi1
Windows 11 Pro Key($22): https://biitt.ly/RUZiX
Office 2019 pro key($49): https://biitt.ly/o0OQT

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and description contains affiliate links, which means that if you click on one of the product links, I’ll receive a small commission at no extra cost to you!
Under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education, and research.
No Games Are Included Or Added

This video and Channel and Video are for viewers 14 years older and up. This video is not made for viewers under the age of 14. 

00:00 Introduction
00:12 Unboxing
00:50 Overview
01:25 tear down
01:55 specs
02:34 Alt Mode
03:14 Overall windows performance
04:21 4k Video playback test
05:02 Benchmarks
06:05 Gaming Test
07:19 PS2 emulation
07:55 Wii U EMulation
08:15 PS3 emulation
08:33 Power consumption and CPU temps

Want to send me something?
ETAPRIME 
12520 Capital Blvd Ste 401 Number 108
Wake Forest, NC 27587 US

THIS VIDEO IS FOR EDUCATIONAL PURPOSES ONLY!

#ryzen #minipc #etaprime
