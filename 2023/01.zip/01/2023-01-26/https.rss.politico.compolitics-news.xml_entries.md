# Source Politico, Source URL:https://rss.politico.com/politics-news.xml, Source language: en-US

## Trump unveils new education policy loaded with culture war proposals
 - [https://www.politico.com/news/2023/01/26/trump-unveils-education-policy-culture-war-00079784](https://www.politico.com/news/2023/01/26/trump-unveils-education-policy-culture-war-00079784)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-01-26 17:37:13+00:00
 - user: None

The proposal reflects the degree to which Republicans want the next election to be waged around classrooms as much as boardrooms.

## Adams outlines ‘Working People’s Agenda’ in State of the City speech
 - [https://www.politico.com/video/2023/01/26/adams-outlines-working-peoples-agenda-in-state-of-the-city-speech-821764](https://www.politico.com/video/2023/01/26/adams-outlines-working-peoples-agenda-in-state-of-the-city-speech-821764)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-01-26 16:39:44+00:00
 - user: None



## DeSantis scrambles RNC race after praising Dhillon and urging ‘new blood’
 - [https://www.politico.com/news/2023/01/26/desantis-scrambles-rnc-race-after-praising-dhillon-and-urging-new-blood-00079737](https://www.politico.com/news/2023/01/26/desantis-scrambles-rnc-race-after-praising-dhillon-and-urging-new-blood-00079737)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-01-26 15:54:45+00:00
 - user: None

The Florida governor weighed in on the race just 24 hours before the RNC’s 168 voting members are set to elect their next chair on Friday.
