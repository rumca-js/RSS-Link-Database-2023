# Source Chip.pl, Source URL:https://www.chip.pl/feed, Source language: pl-PL

## Warszawa jeszcze nie wprowadziła Strefy Czystego Transportu, a już należałoby ją poprawić
 - [https://www.chip.pl/2023/01/warszawa-strefa-czystego-transportu-normy-emisji-mapa](https://www.chip.pl/2023/01/warszawa-strefa-czystego-transportu-normy-emisji-mapa)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 20:30:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="788" src="https://konto.chip.pl/wp-content/uploads/2021/06/bmw-m3-competition-2021-13.jpg" style="margin-bottom: 10px;" width="1400" /><p><img src="https://konto.chip.pl/wp-content/uploads/2021/06/bmw-m3-competition-2021-13.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Władze Warszawy szykują się do wprowadzenia Strefy Czystego Transportu (SCT). Wbrew pozorom restrykcje nie będą aż tak duże, jak mogłoby się to wydawać. Strefa Czystego Transportu w Warszawie od 2024 roku. Przytłaczająca większość mieszkańców tego chce A konkretnie od lipca 2024 roku i obejmie obszar wokół szeroko pojętego centru miasta. Może nie aż tak szeroko, [&#8230;]</p>

## Rekordowo krótki impuls elektronowy. Do niedawna taki wynik wydawał się niemożliwy do osiągnięcia
 - [https://www.chip.pl/2023/01/rekordowo-krotki-impuls-elektronowy](https://www.chip.pl/2023/01/rekordowo-krotki-impuls-elektronowy)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 20:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1125" src="https://konto.chip.pl/wp-content/uploads/2023/01/impuls-elektronowy.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/impuls-elektronowy.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Impuls elektronowy wygenerowany niedawno przez naukowców trwał 53 attosekundy. To mało, nawet bardzo. Przeliczymy jednak tę wartość na nieco bardziej ludzkie jednostki. Na czele zespołu zajmującego się tą sprawą stanął Eleftherios Goulielmakis z Uniwersytetu w Rostocku. Celem prowadzonych badań było skrócenie czasu trwania impulsów elektronowych, co powinno przełożyć się na wzrost prędkości w zakresie transmisji [&#8230;]</p>

## Kłamał, podjudzał i chciał doprowadzić do przewrotu. Donald Trump powróci na Facebooka
 - [https://www.chip.pl/2023/01/wolnosc-slowa-donald-trump-facebook](https://www.chip.pl/2023/01/wolnosc-slowa-donald-trump-facebook)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 19:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/ziemia-apokalipsa.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/ziemia-apokalipsa.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jestem wzrokowcem, więc niektóre obrazy pozostają mi na długo w pamięci. Wśród nich znajduje się kilka przebitek ze szturmu zwolenników Donalda Trumpa na Kapitol w styczniu 2021 roku. Nie dysponuję mocą wskazania ostatecznego winnego (lub winnych) tragicznych wydarzeń sprzed dwóch lat, mam jednak wrażenie, że były prezydent USA sprytnie wykorzystał narzędzie o zasięgu nieporównywalnym z [&#8230;]</p>

## Po co się ograniczać? Motorola wprowadza do Polski aż cztery nowe smartfony z serii moto g
 - [https://www.chip.pl/2023/01/motorola-moto-g13-moto-g23-moto-g53-moto-g73-premiera-w-polsce-ceny-specyfikacja](https://www.chip.pl/2023/01/motorola-moto-g13-moto-g23-moto-g53-moto-g73-premiera-w-polsce-ceny-specyfikacja)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 19:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/01/motorola-moto-g73-2.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/motorola-moto-g73-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Zaledwie dwa dni temu Motorola globalnie zaprezentowała swoje nowe smartfony, a te już trafiły do Polski. moto g73 5G, moto g53 5G, moto g23 oraz moto g13, bo to o nich mowa, już niedługo trafią do sprzedaży. Co oferują i w jakich cenach? Sprawdźmy. Nowe smartfony Motoroli to modele raczej budżetowe, choć najdziemy wśród nich [&#8230;]</p>

## Planetoida leci w kierunku Ziemi. Będzie blisko
 - [https://www.chip.pl/2023/01/planetoida-2023-bu](https://www.chip.pl/2023/01/planetoida-2023-bu)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 18:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="587" src="https://konto.chip.pl/wp-content/uploads/2023/01/2023-bu-przelot.jpg" style="margin-bottom: 10px;" width="1041" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/2023-bu-przelot.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Planetoida 2023 BU jest wielkości ciężarówki i dzisiaj w nocy dokona bliskiego przelotu obok Ziemi. Znajdzie się w odległości mniejszej niż satelity telekomunikacyjne, ale o żadnym zagrożeniu nie ma mowy. W nocy, z 26 na 27 stycznia, dojdzie do bliskiego spotkania planetoidy 2023 BU z naszą planetą. O 19:27 EST (1:27 w nocy naszego czasu) [&#8230;]</p>

## Wyjątkowy iRobot Roomba na aukcji WOŚP. Takiego robota odkurzającego wszyscy będą ci zazdrościć
 - [https://www.chip.pl/2023/01/wyjatkowa-roomba-na-aukcji-wosp](https://www.chip.pl/2023/01/wyjatkowa-roomba-na-aukcji-wosp)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 17:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="878" src="https://konto.chip.pl/wp-content/uploads/2023/01/irtobot-aukcja-wosp.jpg" style="margin-bottom: 10px;" width="1007" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/irtobot-aukcja-wosp.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Lubimy otaczać się unikalnymi przedmiotami, o czym doskonale zdają sobie sprawę różne firmy. Dlatego raz na jakiś czas wypuszczają limitowane produkty, które mają za zadanie skraść nasze serca i sprawić, byśmy sięgnęli głębiej w nasze portfele. iRobot też tak zrobił, ale w przypadku robota odkurzająco-mopującego Roomba Combo j7+ cel jest szczytny, bo choć za unikalną [&#8230;]</p>

## Skończył się dzień dziecka. Google dostanie srogie lanie od amerykańskiej administracji
 - [https://www.chip.pl/2023/01/google-dostanie-srogie-lanie-od-amerykanskiej-administracji](https://www.chip.pl/2023/01/google-dostanie-srogie-lanie-od-amerykanskiej-administracji)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 15:30:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/sprawiedliwosc.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/sprawiedliwosc.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Pamiętacie być może z czasów dzieciństwa słynne określenie “poczekaj, aż ojciec wróci z pracy”? Działało to zazwyczaj mrożąco na osobę, która coś przeskrobała i mam takie poczucie, że wśród kierownictwa spółki Alphabet może panować obecnie podobna atmosfera. Wszystko za sprawą pozwu wytoczonego przez Departament Sprawiedliwości USA oraz osiem amerykańskich stanów, dotyczącego praktyk monopolistycznych Google na [&#8230;]</p>

## Test KFA2 GeForce RTX 4080 SG
 - [https://www.chip.pl/2023/01/kfa2-geforce-rtx-4080-sg-test-recenzja-opinia](https://www.chip.pl/2023/01/kfa2-geforce-rtx-4080-sg-test-recenzja-opinia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 15:00:00+00:00
 - user: None

<img alt="test KFA2 GeForce RTX 4080 SG, recenzja KFA2 GeForce RTX 4080 SG, opinia KFA2 GeForce RTX 4080 SG" class="attachment-full size-full wp-post-image" height="1000" src="https://konto.chip.pl/wp-content/uploads/2023/01/KFA2-GeForce-RTX-4080-SG-12.jpg" style="margin-bottom: 10px;" width="1333" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/KFA2-GeForce-RTX-4080-SG-12.jpg" style="display: block; margin: 1em auto;" /></p>
<p>KFA2 GeForce RTX 4080 SG to kolejny ciekawy przedstawiciel serii RTX 4080. Jak wypadnie w porównaniu do innych modeli, które miałem okazję już testować? Jak wygląda i co oferuje KFA2 GeForce RTX 4080 SG? W zestawie oprócz przejściówki na 3x 8-pin oraz holdera, znajdziemy dodatkowy wentylator (1-Click Booster 2.0) oraz dwa kable ARGB. Sam holder [&#8230;]</p>

## Chcieli zatrzymać zmiany klimatu i wystrzelili chemię do atmosfery. Decyzja władz była stanowcza
 - [https://www.chip.pl/2023/01/zmiany-klimatu-dwutlenek-siarki-wystrzelili-do-atmosfery](https://www.chip.pl/2023/01/zmiany-klimatu-dwutlenek-siarki-wystrzelili-do-atmosfery)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 14:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1280" src="https://konto.chip.pl/wp-content/uploads/2023/01/climate-change-issue-7575216_1920.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/climate-change-issue-7575216_1920.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Czy można odwrócić zmiany klimatu i spowodować, aby na Ziemi było chłodniej? Zdaniem niektórych odważnych – tak. Po próbach wystrzelenia do stratosfery dwutlenku siarki przez startup Make Sunsets zrobiło się głośno na świecie i pojawiła się dyskusja nad tym, czy powinniśmy już teraz prowokować klimat do ochładzania się. W 2022 roku startup Make Sunsets przeprowadził [&#8230;]</p>

## Zapomniany system, któremu zawdzięczamy istnienie macOS. Lisa dostępna dla każdego
 - [https://www.chip.pl/2023/01/kod-lisa-zapomniany-system-apple](https://www.chip.pl/2023/01/kod-lisa-zapomniany-system-apple)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 12:30:00+00:00
 - user: None

<img alt="Kod źródłowy Apple Lisa został udostępniony" class="attachment-full size-full wp-post-image" height="905" src="https://konto.chip.pl/wp-content/uploads/2023/01/System-Apple-Lisa-kod-zrodlowy-2.jpg" style="margin-bottom: 10px;" width="1280" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/System-Apple-Lisa-kod-zrodlowy-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Jeśli interesujecie się starym oprogramowaniem i chcecie poznać to, jak drzewiej pisało się systemy operacyjne na rozszerzeniu języka Pascal o obiektowość (Object Pascal), to najnowsza inicjatywa Muzeum Historii Komputerów będzie dla was nie lada gratką. Organizacja umożliwiła nam bowiem zagłębienie się w to, czym dokładnie był zapomniany system Apple o nazwie Lisa, udostępniając jego kod [&#8230;]</p>

## Pierwsza gra z DirectStorage robi wrażenie. Sprawdź, czy czeka cię wymiana dysku na nowy
 - [https://www.chip.pl/2023/01/gra-directstorage-wydajnosc-dysk](https://www.chip.pl/2023/01/gra-directstorage-wydajnosc-dysk)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 11:30:00+00:00
 - user: None

<img alt="Skuteczność DirectStorage w grach" class="attachment-full size-full wp-post-image" height="1124" src="https://konto.chip.pl/wp-content/uploads/2022/03/Skutecznosc-DirectStorage-w-Forspoken.-Jak-bardzo-technologia-Microsoftu-przyspiesza-wczytywanie-3.jpg" style="margin-bottom: 10px;" width="2030" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/03/Skutecznosc-DirectStorage-w-Forspoken.-Jak-bardzo-technologia-Microsoftu-przyspiesza-wczytywanie-3.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Technologia DirectStorage już od pierwszych zapowiedzi jest uważana za coś, co nada zupełnie nowy sens zakupowi wydajnych dysków przez graczy. Wreszcie możemy zweryfikować to na rzeczywistym przykładzie, bo tak się składa, że Forspoken to pierwsza w historii gra, która wykorzystuje właśnie API DirectStorage firmy Microsoft. Rewolucja bardziej niż pewna. DirectStorage sprawdza się w rzeczywistości tak [&#8230;]</p>

## Zestrzelił cztery sowieckie myśliwce w rekordowym pojedynku powietrznym. Prawda wyszła na jaw po wielu dekadach
 - [https://www.chip.pl/2023/01/rekordowy-pojedynek-powietrzny-mig-15](https://www.chip.pl/2023/01/rekordowy-pojedynek-powietrzny-mig-15)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 10:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2023/01/Mysliwce-na-lotniskowcu.jpg" style="margin-bottom: 10px;" width="1469" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/Mysliwce-na-lotniskowcu.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Ponad siedem dekad temu niejaki E Royce Williams, pełniący wtedy rolę porucznika marynarki wojennej Stanów Zjednoczonych i podejmujące misje podczas wojny koreańskiej, dokonał czegoś niebywałego. Nie tylko przeżył potencjalnie najdłuższy pojedynek powietrzny w historii amerykańskiej armii, ale też zestrzelił podczas niego cztery znacznie bardziej zaawansowane sowieckie myśliwce. Do niedawna świat nie wiedział, że odpowiada za [&#8230;]</p>

## Fotograficzna recenzja Canon EOS R6 Mark II. Gdyby nie jeden szczegół, biłby rekordy sprzedaży
 - [https://www.chip.pl/2023/01/canon-eos-r6-mark-ii-test-recenzja-zdjecia](https://www.chip.pl/2023/01/canon-eos-r6-mark-ii-test-recenzja-zdjecia)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 09:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1200" src="https://konto.chip.pl/wp-content/uploads/2023/01/canon-eos-r6-mark-ii-08.jpg" style="margin-bottom: 10px;" width="1800" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/canon-eos-r6-mark-ii-08.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Canon EOS R6 Mark II pojawił się na rynku nieco z zaskoczenia. Nie była to wyczekiwana premiera, tym bardziej że jego poprzednik jest na rynku niewiele ponad rok. Po czasie spędzonym z aparatem mogę powiedzieć jedno – brałbym! Ale… Specyfikacja Canon EOS R6 Mark II Canon EOS R6 Mark II to kawał aparatu. Bardzo wygodnego [&#8230;]</p>

## Kometa zbliżyła się do Słońca i gorzko tego pożałowała. Zobacz niesamowite ujęcie z tego zdarzenia
 - [https://www.chip.pl/2023/01/kometa-c-2022-e3-zniszczony-ogon](https://www.chip.pl/2023/01/kometa-c-2022-e3-zniszczony-ogon)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 08:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1061" src="https://konto.chip.pl/wp-content/uploads/2023/01/kometa.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/kometa.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Gdyby tylko miała taką możliwość, kometa C/2022 E3 raczej nie wspominałaby zbyt dobrze swojego ostatniego spotkania ze Słońcem. Jej ogon został bowiem zdmuchnięty. Kluczową w tym kontekście rolę odegrał koronalny wyrzut masy pochodzący z powierzchni naszej gwiazdy. Wystrzelona za jego sprawą materia usunęła część tej, która tworzyła ogon wspomnianej komety. Jej powitanie w granicach Układu [&#8230;]</p>

## Polecieli w kosmos, aby przekonać się, jak wpływa na kości. Czego możemy się spodziewać?
 - [https://www.chip.pl/2023/01/pobyt-w-kosmosie-wplyw-na-kosci-iss-eksperyment](https://www.chip.pl/2023/01/pobyt-w-kosmosie-wplyw-na-kosci-iss-eksperyment)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 08:00:00+00:00
 - user: None

<img alt="" class="attachment-full size-full wp-post-image" height="1327" src="https://konto.chip.pl/wp-content/uploads/2023/01/astronauta.jpg" style="margin-bottom: 10px;" width="1500" /><p><img src="https://konto.chip.pl/wp-content/uploads/2023/01/astronauta.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Uczestnicy ekspedycji numer 68 prowadzą badania poświęcone kondycji kości w czasie pobytu w przestrzeni kosmicznej. Na tym jednak eksperymenty się nie kończą. Te mają rzecz jasna miejsce na pokładzie Międzynarodowej Stacji Kosmicznej, gdzie czwórka astronautów analizuje wzrost i zachowanie tkanki kostnej. Poza tym testują również sprzęt komunikacyjny i prowadzą badania dotyczące oczu. Dzięki uzyskanym rezultatom [&#8230;]</p>

## Amerykańskie niszczyciele muszą stać się bardziej niszczycielskie. Na przeszkodzie stoi&#8230; energia
 - [https://www.chip.pl/2023/01/amerykanskie-niszczyciele-modernizacja-arleigh-burke](https://www.chip.pl/2023/01/amerykanskie-niszczyciele-modernizacja-arleigh-burke)
 - RSS feed: https://www.chip.pl/feed
 - date published: 2023-01-26 04:30:29+00:00
 - user: None

<img alt="Amerykańskie niszczyciele" class="attachment-full size-full wp-post-image" height="1080" src="https://konto.chip.pl/wp-content/uploads/2022/08/Te-niszczyciele-maja-zapewnic-marynarce-USA-przewage-nad-wrogimi-flotami-2.jpg" style="margin-bottom: 10px;" width="1920" /><p><img src="https://konto.chip.pl/wp-content/uploads/2022/08/Te-niszczyciele-maja-zapewnic-marynarce-USA-przewage-nad-wrogimi-flotami-2.jpg" style="display: block; margin: 1em auto;" /></p>
<p>Stany Zjednoczone chcą zrewolucjonizować swoją flotę niszczycieli za pomocą programu DDG(X), ale szereg opóźnień pozostawia jego rychłe wprowadzenie na służbę pod znakiem zapytania. Jednak amerykańskie niszczyciele muszą stać się bardziej niszczycielskie &#8220;tu i teraz&#8221;, dlatego firma Northrop Grumman opracowała rozwiązanie ich energetycznego problemu. Nowe amerykańskie niszczyciele zaliczają opóźnienia, a broń nowej generacji jest potrzebna tu [&#8230;]</p>
