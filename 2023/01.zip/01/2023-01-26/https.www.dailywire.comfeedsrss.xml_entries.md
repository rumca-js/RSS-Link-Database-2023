# Source Daily Wire, Source URL:https://www.dailywire.com/feeds/rss.xml, Source language: en-US

## WATCH: Robot Liquefies Then Re-Forms In Scientific Breakthrough
 - [https://www.dailywire.com/news/watch-robot-liquefies-then-re-forms-in-scientific-breakthrough](https://www.dailywire.com/news/watch-robot-liquefies-then-re-forms-in-scientific-breakthrough)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 19:51:24+00:00
 - user: None

In a recent breakthrough, scientists have created a robot that can transition back and forth between solid and liquid states, allowing it to navigate through numerous obstacles and environments. Researchers applied the technology in a few different scenarios. The robot was able to navigate obstacle courses and deliver and retrieve objects to and from a ...

## ‘No F***ing Man Is Ever Going To Have’: Megyn Kelly Speaks Out Against Trans Person Claiming To Have OB-GYN In YMCA Locker Room Defense
 - [https://www.dailywire.com/news/no-fing-man-is-ever-going-to-have-megyn-kelly-speaks-out-against-trans-person-claiming-to-have-ob-gyn-in-ymca-locker-room-defense](https://www.dailywire.com/news/no-fing-man-is-ever-going-to-have-megyn-kelly-speaks-out-against-trans-person-claiming-to-have-ob-gyn-in-ymca-locker-room-defense)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 19:43:08+00:00
 - user: None

Megyn Kelly spoke out Thursday against a biological adult male named Christynne Woods who cited an OB-GYN in his defense of why he should be allowed to change in a YMCA female locker room with minors. During Sirius XM’s “The Megyn Kelly Show&#8221; podcast, the host was speaking with conservative commentators Mary Katharine Ham and Bethany ...

## Pay-It-Forward Story Of Farmer Inspires People Around The Country
 - [https://www.dailywire.com/news/pay-it-forward-story-of-farmer-inspires-people-around-the-country](https://www.dailywire.com/news/pay-it-forward-story-of-farmer-inspires-people-around-the-country)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 19:04:37+00:00
 - user: None

A pay-it-forward story is inspiring people after a farmer’s good deeds were revealed after he passed away on New Year’s Day. Hody Childress, a farmer and Air Force veteran from Alabama, went into a drugstore about a decade ago and asked the owner if there were people who weren’t able to pay for their medicine. ...

## Hunter Biden’s Art Dealer Declares Him ‘One Of The Most Consequential Artists In This Century’ After House Demands His Records
 - [https://www.dailywire.com/news/hunter-bidens-art-dealer-declares-him-one-of-the-most-consequential-artists-in-this-century-after-house-demands-his-records](https://www.dailywire.com/news/hunter-bidens-art-dealer-declares-him-one-of-the-most-consequential-artists-in-this-century-after-house-demands-his-records)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 18:59:58+00:00
 - user: None

The art gallerist who deals in Hunter Biden&#8216;s artwork issued a fawning statement on Thursday about the first son&#8217;s paintings, just a day after Republicans requested his records. George Berges, the owner of the George Berges art gallery in New York City, praised the younger Biden and his artwork effusively in a statement to the ...

## Gaetz Takes Jab At Schiff With ‘PENCIL Act’ Reintroduction
 - [https://www.dailywire.com/news/gaetz-takes-jab-at-schiff-with-pencil-act-reintroduction](https://www.dailywire.com/news/gaetz-takes-jab-at-schiff-with-pencil-act-reintroduction)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 18:27:27+00:00
 - user: None

U.S. Rep. Matt Gaetz (R-FL) reintroduced legislation Thursday titled the “PENCIL Act” that would call to ban fellow Rep. Adam Schiff (D-CA) from handling any classified information. Gaetz derived the resolution acronym, “Preventing Extreme Negligence with Classified Information Licenses,” from former President Donald Trump, who first called Schiff “little pencil neck” during a rally in ...

## ‘It’s His Job To Cross The Line’: Pamela Anderson Defends Tim Allen For Flashing Her – Which He Flatly Denies
 - [https://www.dailywire.com/news/its-his-job-to-cross-the-line-pamela-anderson-defends-tim-allen-for-flashing-her-which-he-flatly-denies](https://www.dailywire.com/news/its-his-job-to-cross-the-line-pamela-anderson-defends-tim-allen-for-flashing-her-which-he-flatly-denies)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 18:12:46+00:00
 - user: None

Former &#8220;Baywatch&#8221; star Pamela Anderson is not letting go of her claim that comedian and actor Tim Allen once flashed her on the set of &#8220;Home Improvement&#8221; — a claim that he has flatly denied. Anderson defended Allen on Thursday in a new statement provided to entertainment site Variety, saying that as a comedian it ...

## Proposed New York Law Could Put Criminally Insane Male Inmates In Women’s Prisons, Advocates Fear
 - [https://www.dailywire.com/news/proposed-new-york-law-could-put-criminally-insane-male-inmates-in-womens-prisons-advocates-fear](https://www.dailywire.com/news/proposed-new-york-law-could-put-criminally-insane-male-inmates-in-womens-prisons-advocates-fear)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 18:08:41+00:00
 - user: None

A proposed law in New York could allow mentally ill male inmates to assume a non-male identity and be granted access to women&#8217;s prisons, according to a women&#8217;s advocacy group. Yesterday, the New York Senate added an amendment to Senate Bill 2860, euphemistically called the &#8220;gender identity respect, dignity and safety act,&#8221; that would allow ...

## Hunter Biden Claimed He Paid $50,000/Month In Rent In Favor For Paroled Niece
 - [https://www.dailywire.com/news/hunter-biden-claimed-he-paid-50000-month-in-rent-in-favor-for-paroled-niece](https://www.dailywire.com/news/hunter-biden-claimed-he-paid-50000-month-in-rent-in-favor-for-paroled-niece)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:59:36+00:00
 - user: None

Hunter Biden incorrectly claimed to pay roughly $50,000 a month in rent on a 2018 form that surfaced amid controversy of classified documents found stored in President Joe Biden’s home in Wilmington, Delaware, revealed this month. The form also lists the president’s Wilmington home as his son Hunter’s address. Hunter Biden’s financial entanglements with foreign ...

## Madison Square Garden Uses Facial Recognition Technology To Stop Certain People From Entering
 - [https://www.dailywire.com/news/madison-square-garden-uses-facial-recognition-technology-to-stop-certain-people-from-entering](https://www.dailywire.com/news/madison-square-garden-uses-facial-recognition-technology-to-stop-certain-people-from-entering)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:44:21+00:00
 - user: None

Madison Square Garden Entertainment is using facial recognition technology to prevent attorneys from law firms representing clients suing the company from entering iconic venues in New York City. The policy may violate state and federal laws prohibiting discrimination and retaliation toward individuals engaged in protected activities, such as “taking on legitimate cases, including sexual harassment ...

## U.S. Military Kills Top ISIS Leader Along With Nearly A Dozen ISIS Operatives In Africa
 - [https://www.dailywire.com/news/u-s-military-kills-top-isis-leader-along-with-nearly-a-dozen-isis-operatives-in-africa](https://www.dailywire.com/news/u-s-military-kills-top-isis-leader-along-with-nearly-a-dozen-isis-operatives-in-africa)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:40:40+00:00
 - user: None

The U.S. military killed a high-level ISIS leader during an operation in Africa this week along with nearly a dozen ISIS operatives. A senior administration official told CNN that the operation took place in a &#8220;mountainous cave complex in northern Somalia&#8221; where ISIS was planning its expansion into Africa and beyond. &#8220;Given the remote location ...

## Thursday Afternoon Update: Pelosi Bodycam Footage To Be Released, Memphis Police Officers Fired, And More
 - [https://www.dailywire.com/news/thursday-afternoon-update-pelosi-bodycam-footage-to-be-released-memphis-police-officers-fired-and-more](https://www.dailywire.com/news/thursday-afternoon-update-pelosi-bodycam-footage-to-be-released-memphis-police-officers-fired-and-more)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:37:15+00:00
 - user: None

This article is a companion piece to today’s Morning Wire Afternoon Update. To listen to the podcast version, click here. National Archives Asks Ex-Presidents and Veeps To Search For Classified Docs The National Archives is now officially requesting that former U.S. presidents and vice presidents review their personal records for any classified documents or other presidential ...

## Zoey Saldana Makes Box Office History After Four Films Cross Incredible Milestone
 - [https://www.dailywire.com/news/zoey-saldana-makes-box-office-history-after-four-films-cross-incredible-milestone](https://www.dailywire.com/news/zoey-saldana-makes-box-office-history-after-four-films-cross-incredible-milestone)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:32:34+00:00
 - user: None

Superstar Zoey Saldana made box office history after multiple films she was a part of each grossed more than $2 billion after the &#8220;Avatar&#8221; sequel recently crossed that benchmark globally. The 44-year-old actress became the first actor ever to appear in four films that have crossed the $2 billion mark after James Cameron&#8217;s &#8220;Avatar: The ...

## Memphis Braces For Race Riots After Irresponsible Message From Police Chief
 - [https://www.dailywire.com/news/memphis-braces-for-race-riots-after-irresponsible-message-from-police-chief](https://www.dailywire.com/news/memphis-braces-for-race-riots-after-irresponsible-message-from-police-chief)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 17:29:05+00:00
 - user: None

Do you know what we haven&#8217;t had in a while? Race riots. Don&#8217;t worry, though, because George Floyd, 2.0 is potentially coming to Memphis, Tennessee. At least, that&#8217;s what it seems like after listening to Memphis Police Chief Cerelyn Davis break down the death of Tyre Nichols.  Nichols was involved in a traffic stop on ...

## ‘They Brought Me Back’: Fox News Reporter Reveals What Saved Him After Bomb Blast In Ukraine
 - [https://www.dailywire.com/news/they-brought-me-back-fox-news-reporter-reveals-what-saved-him-after-bomb-blast-in-ukraine](https://www.dailywire.com/news/they-brought-me-back-fox-news-reporter-reveals-what-saved-him-after-bomb-blast-in-ukraine)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:33:23+00:00
 - user: None

Fox News foreign correspondent Benjamin Hall revealed what saved his life in his first on-air interview since a bomb blast outside of Kyiv, Ukraine, killed two of his colleagues and nearly claimed his life as well. Hall joined hosts Steve Doocy, Ainsley Earhardt, and Brian Kilmeade on Thursday&#8217;s broadcast of &#8220;Fox &amp; Friends&#8221; to talk ...

## Jane Fonda Says There’d Be No ‘Climate Crisis’ If Not For ‘Racism’ And Twitter Has Thoughts
 - [https://www.dailywire.com/news/jane-fonda-says-thered-be-no-climate-crisis-if-not-for-racism-and-twitter-has-thoughts](https://www.dailywire.com/news/jane-fonda-says-thered-be-no-climate-crisis-if-not-for-racism-and-twitter-has-thoughts)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:27:15+00:00
 - user: None

Jane Fonda claimed that there&#8217;d be no &#8220;climate crisis&#8221; if not for &#8220;racism&#8221; and Twitter users definitely had some thoughts, with many people blasting the actress for her comment. During a recent episode of &#8220;The Kelly Clarkson Show,&#8221; the 85-year-old actress was joined by her &#8220;80 for Brady&#8221; co-stars as she talked about what had ...

## Ron DeSantis Appears To Back Candidate In Race For RNC Chair
 - [https://www.dailywire.com/news/ron-desantis-appears-to-back-candidate-in-race-for-rnc-chair](https://www.dailywire.com/news/ron-desantis-appears-to-back-candidate-in-race-for-rnc-chair)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:26:57+00:00
 - user: None

Florida Governor Ron DeSantis appeared during an interview on Thursday to back attorney Harmeet Dhillon in her bid to become the new chair of the Republican National Committee. DeSantis&#8217; remarks come one day before RNC committee members will vote on a secret ballot for positions in the party, including the chairmanship. “I think we need to ...

## House Republican Passes Out Grenades To Colleagues
 - [https://www.dailywire.com/news/house-republican-passes-out-grenades-to-colleagues](https://www.dailywire.com/news/house-republican-passes-out-grenades-to-colleagues)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:25:33+00:00
 - user: None

A freshman House Republican is starting out the new session of Congress with a bang. Rep. Cory Mills (R-FL) passed out what he says are inert grenades to colleagues, marking his appointment to committees charged with protecting national security. Daily Mail reporter Morgan Phillips shared a photo Thursday of one of the grenades, which features ...

## ‘The Poor, The Mentally Ill, The French’: What’s With The Morons At The Associated Press?
 - [https://www.dailywire.com/news/the-poor-the-mentally-ill-the-french-whats-with-the-morons-at-the-associated-press](https://www.dailywire.com/news/the-poor-the-mentally-ill-the-french-whats-with-the-morons-at-the-associated-press)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:14:44+00:00
 - user: None

Did you hear the story about the poor, the mentally ill, and the French? Well, not in the pages of the Associated Press, you didn&#8217;t. According to the AP&#8217;s official Style Guide, all three of those terms are offensive and &#8220;dehumanizing.&#8221; &#8220;We recommend avoiding general and often dehumanizing &#8216;the&#8217; labels such as the poor, the ...

## 5 Former Memphis Police Officers Charged In Man’s Death; City Braces For Possible Riots
 - [https://www.dailywire.com/news/5-former-memphis-police-officers-charged-in-mans-death-city-braces-for-possible-riots](https://www.dailywire.com/news/5-former-memphis-police-officers-charged-in-mans-death-city-braces-for-possible-riots)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 16:05:44+00:00
 - user: None

Five former Memphis Police Department officers are in custody and face several charges after their involvement in the death of a 29-year-old male, who died earlier this month in a hospital days after a confrontation with authorities. Tyre Nichols died on January 10, three days after Memphis police pulled him over in a traffic stop, ...

## Alleged Vandals Indicted Over Attacking Pregnancy Centers In Florida
 - [https://www.dailywire.com/news/alleged-vandals-indicted-over-attacking-pregnancy-centers-in-florida](https://www.dailywire.com/news/alleged-vandals-indicted-over-attacking-pregnancy-centers-in-florida)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:55:59+00:00
 - user: None

On Tuesday, the Department of Justice announced charges for two people over the vandalization of pregnancy centers in Florida. A federal grand jury indicted the two residents of Florida for the act of spray-painting threatening phrases on the resource centers that assist men and women who may be facing unplanned pregnancies. The charge alleges that ...

## ‘You’re Bulls****ing People’: Joe Rogan Blows Up On Media Over Riot, COVID Coverage
 - [https://www.dailywire.com/news/youre-bullsing-people-joe-rogan-blows-up-on-media-over-riot-covid-coverage](https://www.dailywire.com/news/youre-bullsing-people-joe-rogan-blows-up-on-media-over-riot-covid-coverage)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:43:30+00:00
 - user: None

Joe Rogan called out the media over its coverage of COVID and riots, arguing that they&#8217;re &#8220;not the f***ing propaganda department.&#8221; During &#8220;The Joe Rogan Experience&#8221; podcast on Wednesday, the host told his guest, former MTV DJ/podcaster Adam Curry, that modern politics is similar to tribalism. Rogan said humans have always wanted &#8220;other people to ...

## ‘But They Knew!’: ‘The View’ Blows Up Over Red Flag Laws, Student Who Shot Teacher
 - [https://www.dailywire.com/news/but-they-knew-the-view-blows-up-over-red-flag-laws-student-who-shot-teacher](https://www.dailywire.com/news/but-they-knew-the-view-blows-up-over-red-flag-laws-student-who-shot-teacher)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:25:54+00:00
 - user: None

&#8220;The View&#8221; devolved into a shouting match on Thursday as the co-hosts debated red flag laws — whether or not they were a good idea and whether or not they were effective. The conversation came about as a response to a shooting that took place when a six-year-old student brought a gun to school and ...

## BuzzFeed Will Use Artificial Intelligence To Generate Content
 - [https://www.dailywire.com/news/buzzfeed-will-use-artificial-intelligence-to-generate-content](https://www.dailywire.com/news/buzzfeed-will-use-artificial-intelligence-to-generate-content)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:08:57+00:00
 - user: None

One digital media company is generating a great deal of buzz with a plan to feed readers with content created with the help of artificial intelligence. A memo to BuzzFeed staff on Thursday revealed the company would soon rely on tools made by OpenAI, the creator of the ChatGPT chatbot that is taking the world ...

## Michael Bublé Reflects On How His Son’s ‘Unthinkable’ Cancer Diagnosis Changed His Perspective On Life
 - [https://www.dailywire.com/news/michael-buble-reflects-on-how-his-sons-unthinkable-cancer-diagnosis-changed-his-perspective-on-life](https://www.dailywire.com/news/michael-buble-reflects-on-how-his-sons-unthinkable-cancer-diagnosis-changed-his-perspective-on-life)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:06:17+00:00
 - user: None

Singer Michael Bublé said his young son’s “unthinkable” battle with cancer gave him a new perspective on life, forcing him to abandon his “alter ego.” The 47-year-old Grammy Award winner said he felt like “the superhero I always wanted to be” before his son Noah was diagnosed with hepatoblastoma, a form of liver cancer, at ...

## Here’s Where Gas Prices Are Eating Into Residents’ Incomes The Most
 - [https://www.dailywire.com/news/heres-where-gas-prices-are-eating-into-residents-incomes-the-most](https://www.dailywire.com/news/heres-where-gas-prices-are-eating-into-residents-incomes-the-most)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 15:00:14+00:00
 - user: None

Gas prices relative to local incomes are highest in Nevada and other states in the western part of the country, according to an analysis from HiRoad. The insurance company compared localized fuel price data from GasBuddy with average hourly salary data from the Bureau of Labor Statistics, thereby revealing where Americans are spending the largest ...

## Inflation Is Slowing, But Grocery Prices Anticipated To Remain High In 2023
 - [https://www.dailywire.com/news/inflation-is-slowing-but-grocery-prices-anticipated-to-remain-high-in-2023](https://www.dailywire.com/news/inflation-is-slowing-but-grocery-prices-anticipated-to-remain-high-in-2023)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 14:55:02+00:00
 - user: None

Americans are still feeling the pinch at the grocery store even with inflation slightly decreasing, and prices will likely still be high in 2023.  Food costs are anticipated to rise but at a slower rate than in 2022, according to the U.S. Department of Agriculture. Prices will continue to be higher than the historical averages.  ...

## A Spiritual Food Fight: How Cancel Culture Weaponizes Food To Bully The Faithful
 - [https://www.dailywire.com/news/a-spiritual-food-fight-how-cancel-culture-weaponizes-food-to-bully-the-faithful](https://www.dailywire.com/news/a-spiritual-food-fight-how-cancel-culture-weaponizes-food-to-bully-the-faithful)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 14:42:45+00:00
 - user: None

The battle between good and evil can be likened to a messy food fight. God originally created food to foster health, unity, comfort, and goodness. But in the hands of the enemy, it creates the perfect opportunity for Cancel Culture to attack the dinner table and the people around it. During the riots of 2020, ...

## Tesla Posts Highest Profits Ever Despite Concerns About Musk’s Twitter Purchase Causing Brand Risk
 - [https://www.dailywire.com/news/tesla-posts-highest-profits-ever-despite-concerns-about-musks-twitter-purchase-causing-brand-risk](https://www.dailywire.com/news/tesla-posts-highest-profits-ever-despite-concerns-about-musks-twitter-purchase-causing-brand-risk)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 14:19:43+00:00
 - user: None

Tesla reported record financial performance that exceeded expectations despite concern over the recent purchase of Twitter by Elon Musk, the electric automaker’s chief executive. Tesla boasted revenues of $24.32 billion for the fourth quarter, surpassing analysts’ expectations of $24.16 billion and reflecting a 37% year-over-year increase. Total gross profits were $5.78 billion, marking a 19% ...

## District Judge Blocks California’s COVID ‘Misinformation’ Law
 - [https://www.dailywire.com/news/district-judge-blocks-californias-covid-misinformation-law](https://www.dailywire.com/news/district-judge-blocks-californias-covid-misinformation-law)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 14:10:51+00:00
 - user: None

A federal judge blocked a California law that allowed the state to punish doctors who shared alleged &#8220;misinformation&#8221; about COVID. U.S. District Judge William Shubb ruled Wednesday that Assembly Bill 2098, signed by Democratic Gov. Gavin Newsom in September, was unconstitutional. “Because the definition of misinformation ‘fails to provide a person of ordinary intelligence fair ...

## Guest Star Confronts ‘Boy Meets World’ Cast With Awkward Moment That Bothered Him For 30 Years
 - [https://www.dailywire.com/news/guest-star-confronts-boy-meets-world-cast-with-awkward-moment-that-bothered-him-for-30-years](https://www.dailywire.com/news/guest-star-confronts-boy-meets-world-cast-with-awkward-moment-that-bothered-him-for-30-years)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 14:01:56+00:00
 - user: None

Actor Adam Scott finally confronted the cast members of the hit sitcom “Boy Meets World,” recalling an awkward exchange from when he was a guest star on the show that he said had bothered him for 29 years. Scott, who had a recurring guest spot as Griff during the show’s second and third seasons, made ...

## If Regime Change In Russia Is The Goal, Shouldn’t We Think About What Comes Next?
 - [https://www.dailywire.com/news/if-regime-change-in-russia-is-the-goal-shouldnt-we-think-about-what-comes-next](https://www.dailywire.com/news/if-regime-change-in-russia-is-the-goal-shouldnt-we-think-about-what-comes-next)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 13:48:50+00:00
 - user: None

Good people everywhere want to see Ukraine defend itself against the brutal Russian invasion, but if the real goal of U.S. foreign policy is to oust Vladimir Putin, let&#8217;s hope the diplomats and spies have thought things through. You don&#8217;t have to be a Russian stooge to worry about what could happen in a destabilized Russia, ...

## Madonna Biopic Scrapped By Universal After Grueling Audition Process
 - [https://www.dailywire.com/news/madonna-biopic-scrapped-by-universal-after-grueling-audition-process](https://www.dailywire.com/news/madonna-biopic-scrapped-by-universal-after-grueling-audition-process)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 13:40:54+00:00
 - user: None

A Hollywood biopic on the life and career of Madonna has officially been called off. The project was being developed by Universal Pictures, according to Variety, but all activity has ceased on the heels of Madonna announcing an upcoming tour of North America and Europe. The singer said she plans to make the movie in ...

## Cell Phone Evidence Puts Disgraced Attorney Alex Murdaugh At Scene Of Family Murder, Prosecutors Say
 - [https://www.dailywire.com/news/cell-phone-evidence-puts-disgraced-attorney-alex-murdaugh-at-scene-of-family-murder-prosecutors-say](https://www.dailywire.com/news/cell-phone-evidence-puts-disgraced-attorney-alex-murdaugh-at-scene-of-family-murder-prosecutors-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 13:11:17+00:00
 - user: None

Opening statements have begun in the murder trial involving a prominent South Carolina legal dynasty, with prosecutors revealing new evidence against disgraced former attorney Alex Murdaugh. Murdaugh is accused of murdering his wife, Maggie, and youngest son, Paul, to build sympathy for himself as his embezzlement of millions of dollars from his law firm and ...

## Officials Hold Back LeBron James After Fan Taunts Him Over ‘Receding Hairline’
 - [https://www.dailywire.com/news/officials-hold-back-lebron-james-after-fan-taunts-him-over-receding-hairline](https://www.dailywire.com/news/officials-hold-back-lebron-james-after-fan-taunts-him-over-receding-hairline)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 13:10:32+00:00
 - user: None

Officials held back Los Angeles Lakers star LeBron James during a game this week against the Los Angeles Clippers. The incident happened on Tuesday night as the 38-year-old was headed toward the locker rooms during halftime at the Crypto.com Arena. “Hey Bron! Hey Bron!” the man shouted at James. “You better get this s*** together! ...

## Chelsea Handler: ‘I Didn’t Even Know’ That I Was Taking Diabetes Medication
 - [https://www.dailywire.com/news/chelsea-handler-i-didnt-even-know-that-i-was-taking-diabetes-medication](https://www.dailywire.com/news/chelsea-handler-i-didnt-even-know-that-i-was-taking-diabetes-medication)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 13:07:40+00:00
 - user: None

Leftist Chelsea Handler claimed during an interview this week that she had no idea she was taking diabetic medication. The comedian told Alex Cooper on the &#8220;Call Her Daddy&#8221; podcast that her doctor gave her Ozempic, which is intended to treat people with type 2 diabetes, and she didn&#8217;t know what it was. &#8220;My anti-aging ...

## Mother Strangled Her Children Then Attempted Suicide, Prosecutors Say
 - [https://www.dailywire.com/news/mother-strangled-her-children-then-attempted-suicide-prosecutors-say](https://www.dailywire.com/news/mother-strangled-her-children-then-attempted-suicide-prosecutors-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:51:54+00:00
 - user: None

A Massachusetts mother will be charged with murder after she allegedly strangled her children before attempting suicide, prosecutors say. On Tuesday night, a man called 911 saying a woman had attempted suicide by jumping out of a window. The woman was identified as Lindsay Clancy, 32, of Duxbury, Massachusetts, and the caller was identified as ...

## Biden District Court Nominee Stumped By John Kennedy’s Most Basic Questions About The Constitution
 - [https://www.dailywire.com/news/biden-district-court-nominee-stumped-by-john-kennedys-most-basic-questions-about-the-constitution](https://www.dailywire.com/news/biden-district-court-nominee-stumped-by-john-kennedys-most-basic-questions-about-the-constitution)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:49:08+00:00
 - user: None

Federal District Court nominee Charnelle Marie Bjelkengren appeared to struggle with the most basic of questions during her Thursday morning hearing before the Senate Judiciary Committee, failing to recall the purpose of both Article V and Article II of the United States Constitution. Sen. John Kennedy (R-LA) attempted to keep his questions simple, asking directly ...

## PragerU Presents Michele Tafoya: ‘My Freedom To Speak Meant More Than My Job’
 - [https://www.dailywire.com/news/prageru-presents-michele-tafoya-my-freedom-to-speak-meant-more-than-my-job](https://www.dailywire.com/news/prageru-presents-michele-tafoya-my-freedom-to-speak-meant-more-than-my-job)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:37:32+00:00
 - user: None

Why would Emmy-award-winning sportscaster Michele Tafoya walk away from her successful television career? PragerU presents Tafoya&#8217;s account in its latest &#8220;Stories of Us&#8221; video. Tafoya discusses the highlights of working in the sports journalism industry, the struggle to start her family, and why she refuses to apologize for her values. Raised in Manhattan Beach, California, ...

## Southwest Airlines Reports Massive Revenue Hit After Christmas Meltdown
 - [https://www.dailywire.com/news/southwest-airlines-reports-massive-revenue-hit-after-christmas-meltdown](https://www.dailywire.com/news/southwest-airlines-reports-massive-revenue-hit-after-christmas-meltdown)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:32:49+00:00
 - user: None

Southwest Airlines reported a $220 million loss in the fourth quarter and warned investors that fallout from the company’s holiday meltdown would continue. Southwest canceled a high number of flights relative to competitors over the Christmas holidays, even after severe winter weather conditions had subsided. The losses, which will cost investors $0.37 per diluted share, ...

## Project Veritas Video: Pfizer Official Says Firm Considering Ways To ‘Mutate’ Virus Via ‘Directed Evolution’
 - [https://www.dailywire.com/news/project-veritas-video-pfizer-official-says-firm-considering-ways-to-mutate-virus-via-directed-evolution](https://www.dailywire.com/news/project-veritas-video-pfizer-official-says-firm-considering-ways-to-mutate-virus-via-directed-evolution)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:23:41+00:00
 - user: None

A new undercover video from Project Veritas allegedly captures a Pfizer official saying the company has considered mutating the virus in order to create effective vaccines in advance, declaring that COVID will be a &#8220;cash cow&#8221; for years, and claiming federal regulators go easy on Pfizer in hopes of getting jobs later. The 10-minute video, which ...

## New York GOP Leaders Demand Answers For Migrant Relocation In Upstate Town
 - [https://www.dailywire.com/news/new-york-gop-leaders-demand-answers-for-migrant-relocation-in-upstate-town](https://www.dailywire.com/news/new-york-gop-leaders-demand-answers-for-migrant-relocation-in-upstate-town)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 12:09:24+00:00
 - user: None

Two New York GOP leaders are calling for answers from the Biden administration over secretly transporting migrants across the U.S. after dozens of Columbian immigrants have moved to the upstate community of Jamestown. Republican Reps. Claudia Tenney and Elise Stefanik expressed their concern in a Wednesday letter that was co-signed by fellow New York GOP ...

## Fox Host Says NY Should Dump Hochul And Bring Spitzer Back: ‘I Don’t Care If He Sleeps With Escorts, He Was Smart’
 - [https://www.dailywire.com/news/fox-host-says-ny-should-dump-hochul-and-bring-spitzer-back-i-dont-care-if-he-sleeps-with-escorts-he-was-smart](https://www.dailywire.com/news/fox-host-says-ny-should-dump-hochul-and-bring-spitzer-back-i-dont-care-if-he-sleeps-with-escorts-he-was-smart)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:52:30+00:00
 - user: None

Fox News host Jesse Watters said on Wednesday that New York might be in better shape if the state were to dump current Democratic Governor Kathy Hochul and bring back disgraced former Governor Eliot Spitzer, who was also a Democrat. Spitzer earned a reputation for holding financial services professionals accountable and rooting out corruption while ...

## Bad Medicine: How DEI Is Dismantling UNC’s Medical School And Endangering Patients
 - [https://www.dailywire.com/news/bad-medicine-how-dei-is-dismantling-uncs-medical-school-and-endangering-patients](https://www.dailywire.com/news/bad-medicine-how-dei-is-dismantling-uncs-medical-school-and-endangering-patients)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:47:16+00:00
 - user: None

Imagine you’re under the scope. The operating room lights partially blind you as you drift into an anesthetic-induced coma. Barely clinging to consciousness as the doctors surround you and prepare to fix your heart, you can only hear flickers of conversation before you go. But one line is unmistakable: the last thing you hear out ...

## Woke Pope? Nope. Francis Made No News With Gay Declaration.
 - [https://www.dailywire.com/news/woke-pope-nope-francis-made-no-news-with-gay-declaration](https://www.dailywire.com/news/woke-pope-nope-francis-made-no-news-with-gay-declaration)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:40:33+00:00
 - user: None

The hard-Left Associated Press blared the &#8220;news&#8221; from the rooftops: &#8220;Pope says homosexuality not a crime,&#8221; screamed the headline on Wednesday. &#8220;Pope Francis criticized laws that criminalize homosexuality as &#8216;unjust,&#8217; saying God loves all his children just as they are and called on Catholic bishops who support the laws to welcome LGBTQ people into the ...

## ‘A Catastrophe’: Dennis Prager Explores Secular Extremism In New Daily Wire+ Series
 - [https://www.dailywire.com/news/a-catastrophe-dennis-prager-explores-secular-extremism-in-new-daily-wire-series](https://www.dailywire.com/news/a-catastrophe-dennis-prager-explores-secular-extremism-in-new-daily-wire-series)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:28:09+00:00
 - user: None

NASHVILLE, Tenn. — As the elitists of the World Economic Forum wrap up their 2023 meeting of the tyrannical minds, intellectual powerhouse Dennis Prager inspires wisdom over wokeness in his new DailyWire+ series “THE MASTER&#8217;S PROGRAM WITH DENNIS PRAGER.” Compliance with the plans pushed by Davos-attendee elitists requires the core pillars of woke ideology to ...

## Adam Schiff Will Run For Dianne Feinstein’s Senate Seat
 - [https://www.dailywire.com/news/adam-schiff-will-run-for-dianne-feinsteins-senate-seat](https://www.dailywire.com/news/adam-schiff-will-run-for-dianne-feinsteins-senate-seat)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:20:10+00:00
 - user: None

Rep. Adam Schiff (D-CA) announced on Thursday that he will run for the Senate seat currently held by fellow Democrat Dianne Feinstein. Schiff, a former House Intelligence Committee chair and proponent of the unfounded Trump-Russia collusion theory, posted a video to Twitter highlighting his case, dedicating multiple portions of the ad to former President Donald ...

## Man Charged With Murdering Microsoft Executive, But Authorities Say He Didn’t Act Alone
 - [https://www.dailywire.com/news/man-charged-with-murdering-microsoft-executive-but-authorities-say-he-didnt-act-alone](https://www.dailywire.com/news/man-charged-with-murdering-microsoft-executive-but-authorities-say-he-didnt-act-alone)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 11:04:08+00:00
 - user: None

A Florida man was arrested and charged Wednesday for murdering a Microsoft executive nearly a year ago. Henry Tenon, 61, was charged with conspiracy to commit murder, second-degree murder, and accessory after the fact to a capital felony, as well as child abuse, People Magazine reported. The charges relate to the February 16, 2022, murder ...

## Economy Grew In Fourth Quarter As Recession Fears Loom For 2023
 - [https://www.dailywire.com/news/economy-grew-in-fourth-quarter-as-recession-fears-loom-for-2023](https://www.dailywire.com/news/economy-grew-in-fourth-quarter-as-recession-fears-loom-for-2023)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 10:56:19+00:00
 - user: None

The American economy grew at a 2.9% annualized rate in the fourth quarter of 2022, slightly surpassing expectations even as recessionary concerns loom. Real gross domestic product, the sum of all final goods and services produced in the economy adjusted for inflation, expanded at a slower pace than the 3.2% annualized rate seen in the ...

## Judge Declares Mistrial In OMG Dolls Lawsuit After ‘Cultural Appropriation’ Testimony
 - [https://www.dailywire.com/news/judge-declares-mistrial-in-omg-dolls-lawsuit-after-cultural-appropriation-testimony](https://www.dailywire.com/news/judge-declares-mistrial-in-omg-dolls-lawsuit-after-cultural-appropriation-testimony)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 09:51:54+00:00
 - user: None

The maker of the popular children’s toy L.O.L. Surprise! OMG Dolls was granted a mistrial this week when a federal judge ruled that prohibited testimony on cultural appropriation was introduced during proceedings. Toymaker MGA Entertainment is currently involved in an intellectual property dispute with rapper T.I. and former teen pop group OMG Girlz. The company ...

## Police Perform Wellness Check On Britney Spears After Panicked Fans Call Them Over Deleted Instagram Account
 - [https://www.dailywire.com/news/police-perform-wellness-check-on-britney-spears-after-panicked-fans-call-them-over-deleted-instagram-account](https://www.dailywire.com/news/police-perform-wellness-check-on-britney-spears-after-panicked-fans-call-them-over-deleted-instagram-account)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 09:42:56+00:00
 - user: None

Concerned fans called the police after pop singer Britney Spears deleted her Instagram account, prompting law enforcement to perform a wellness check at her California home late Tuesday night. The 41-year-old celebrity had her 13-year-long conservatorship lifted in November 2021 amid the popularity of the #FreeBritney movement. Ever since then, Spears has engaged in erratic ...

## Swalwell Seems To Threaten McCarthy After Boot From Committee: ‘He’ll Regret Giving All Three Of Us More Time On Our Hands’
 - [https://www.dailywire.com/news/swalwell-seems-to-threaten-mccarthy-after-boot-from-committee-hell-regret-giving-all-three-of-us-more-time-on-our-hands](https://www.dailywire.com/news/swalwell-seems-to-threaten-mccarthy-after-boot-from-committee-hell-regret-giving-all-three-of-us-more-time-on-our-hands)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 09:37:57+00:00
 - user: None

Rep. Eric Swalwell (D-CA) appeared to threaten House Speaker Kevin McCarthy (R-CA) after the Democrat was bounced from the House Intelligence Committee. Swalwell, who allegedly had an affair with a Chinese spy, told McCarthy he thinks he&#8217;ll &#8220;regret&#8221; the move, seeming to hint at political retribution of some kind. &#8220;We will not be quiet,&#8221; Swalwell ...

## ‘I Continue To Lean On Him’: First Rookie QB To Possibly Go To Super Bowl A Devout Christian
 - [https://www.dailywire.com/news/i-continue-to-lean-on-him-first-rookie-qb-to-possibly-go-to-super-bowl-a-devout-christian](https://www.dailywire.com/news/i-continue-to-lean-on-him-first-rookie-qb-to-possibly-go-to-super-bowl-a-devout-christian)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 08:32:43+00:00
 - user: None

The NFL quarterback who could become the first rookie to take his team to the Super Bowl is a devout Christian. San Francisco 49ers quarterback Brock Purdy started seven games in the 2022 season and won them all. Astonishingly, he was the last player selected in the 2022 NFL draft. The 49ers started the 2022 ...

## FBI Director Christopher Wray Summons Bureau’s Jet To D.C.-Area Airport To Dodge Traffic: Whistleblower
 - [https://www.dailywire.com/news/fbi-director-christopher-wray-summons-bureaus-jet-to-d-c-area-airport-to-dodge-traffic-whistleblower](https://www.dailywire.com/news/fbi-director-christopher-wray-summons-bureaus-jet-to-d-c-area-airport-to-dodge-traffic-whistleblower)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-01-26 08:00:05+00:00
 - user: None

When FBI Director Christopher Wray wants to use the bureau&#8217;s $60 million Gulfstream G550, he typically summons it to nearby Reagan National Airport instead of being driven 30 miles to the regional airport where it&#8217;s kept, a whistleblower told The Daily Wire, describing a costly habit paid for by U.S. taxpayers. Records obtained by The ...
