# Source Business insider, Source URL:https://businessinsider.com.pl/.feed, Source language: en-US

## USA nałożyły sankcje na Grupę Wagnera
 - [https://businessinsider.com.pl/wiadomosci/wojna-w-ukrainie-usa-nalozyly-sankcje-na-grupe-wagnera/7zkyczr](https://businessinsider.com.pl/wiadomosci/wojna-w-ukrainie-usa-nalozyly-sankcje-na-grupe-wagnera/7zkyczr)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 20:50:15+00:00
 - user: None

Administracja USA nałożyła dodatkowe sankcje na Grupę Wagnera i rosyjski sektor zbrojeniowy. "Sankcje ograniczą możliwości Putina, by zbroić i wyposażać swoją machinę wojenną" — ocenia sekretarz skarbu Janet Yellen. Restrykcjami objęte zostały m.in. firmy współpracujące z Grupą Wagnera.

## Nie dosypiasz? Będziesz zaskoczony, jak bardzo wpływa to na twoją pracę
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/brak-snu-a-wydajnosc-w-pracy-bezsennosc-a-praca/cgf31n4](https://businessinsider.com.pl/rozwoj-osobisty/kariera/brak-snu-a-wydajnosc-w-pracy-bezsennosc-a-praca/cgf31n4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 20:30:00+00:00
 - user: None

Problemy ze snem to we współczesnym świecie poważny problem, który - jak alarmuje Ośrodek Medycyny Snu Instytutu Psychiatrii i Neurologii w Warszawie - "zagraża zdrowiu i jakości życia 45 proc. światowej populacji". Nie można ich bagatelizować. Jeszcze w 2015 roku - a więc na długo przed pandemią COVID-19 - TNS opublikował badanie "Sen Polaków", z którego wynikało, że dla 14 proc. Polaków sen to luksus, na który nie mogą sobie pozwolić. Z kolei 46 proc. z nas przyznawało wówczas, że rzadko lub bardzo rzadko śpi dobrze.

## 9 oznak tego, że kiepski z ciebie manager. Nawet jeśli myślisz, że jest inaczej
 - [https://businessinsider.com.pl/rozwoj-osobisty/kariera/po-czym-poznac-zlego-managera-najpopularniejsze-bledy-popelniane-przez-szefow/bvtyvs6](https://businessinsider.com.pl/rozwoj-osobisty/kariera/po-czym-poznac-zlego-managera-najpopularniejsze-bledy-popelniane-przez-szefow/bvtyvs6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 20:28:00+00:00
 - user: None

To, że ktoś pełni funkcję managera, nie znaczy jeszcze, że wie, jak nim być. Właściwie prowadzony nadzór nad zespołem przesądza o tym, czy lider nadaje się na to stanowisko. A złych managerów jest mnóstwo w świecie biznesu.

## Tak zwalnia Google. Przykra niespodzianka przed wejściem do pracy
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/zwolnienia-w-google-przykra-niespodzianka-przed-wejsciem-do-pracy/0t7j0xq](https://businessinsider.com.pl/twoje-pieniadze/praca/zwolnienia-w-google-przykra-niespodzianka-przed-wejsciem-do-pracy/0t7j0xq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 20:21:28+00:00
 - user: None

Byli pracownicy Google nie wiedzieli, że zostali zwolnieni, dopóki ich przepustki nie przestały działać.

## MFW szykuje pakiet pomocowy dla Ukrainy. Nawet 16 mld dol.
 - [https://businessinsider.com.pl/gospodarka/pomoc-dla-ukrainy-mfw-szykuje-pakiet-wart-miliardy-dolarow/lvtw1rj](https://businessinsider.com.pl/gospodarka/pomoc-dla-ukrainy-mfw-szykuje-pakiet-wart-miliardy-dolarow/lvtw1rj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 19:48:27+00:00
 - user: None

Międzynarodowy Fundusz Walutowy może wdrożyć wieloletni pakiet pomocowy dla Ukrainy o wartości nawet 16 mld dol. — ustalił Bloomberg.

## Ustawa budżetowa 2023 r. Sejm zdecydował
 - [https://businessinsider.com.pl/gospodarka/ustawa-budzetowa-2023-r-sejm-odrzucil-poprawki-senatu/e94r8k6](https://businessinsider.com.pl/gospodarka/ustawa-budzetowa-2023-r-sejm-odrzucil-poprawki-senatu/e94r8k6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 19:24:48+00:00
 - user: None

Sejm odrzucił w czwartek wszystkie poprawki Senatu do budżetu na 2023 r. Ustawa budżetowa trafi teraz do podpisu prezydenta.

## Koniec z drastycznymi podwyżkami cen ciepła. Sejm zdecydował
 - [https://businessinsider.com.pl/twoje-pieniadze/koniec-z-drastycznymi-podwyzkami-cen-ciepla-sejm-zdecydowal/5bejh1s](https://businessinsider.com.pl/twoje-pieniadze/koniec-z-drastycznymi-podwyzkami-cen-ciepla-sejm-zdecydowal/5bejh1s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 18:52:25+00:00
 - user: None

Sejm uchwalił w czwartek nowelizację ustawy wprowadzającą mechanizm ograniczenia wzrostu cen dla odbiorców ciepła do 40 proc. Teraz ustawa trafi do dalszych prac w Senacie.

## Składka zdrowotna 2023 dla przedsiębiorcy. ZUS podał kwoty
 - [https://businessinsider.com.pl/twoje-pieniadze/skladka-zdrowotna-w-2023-r-dla-przedsiebiorcy-zasady-ogolne-i-karta-podatkowa/r38lqg2](https://businessinsider.com.pl/twoje-pieniadze/skladka-zdrowotna-w-2023-r-dla-przedsiebiorcy-zasady-ogolne-i-karta-podatkowa/r38lqg2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 18:49:40+00:00
 - user: None

ZUS podał, ile wyniesie w 2023 r. minimalna składka na ubezpieczenie zdrowotne dla przedsiębiorców na zasadach ogólnych lub stosujący kartę podatkową. Jaką składkę przedsiębiorcy muszą zapłacić w styczniu, a jaką w lutym? Czy jej wysokość wzrośnie w połowie roku, wraz z podwyżką płacy minimalnej?

## Dzięki ChatGPT napisał artykuł o wartości 600 dol. w zaledwie 30 sekund
 - [https://businessinsider.com.pl/wiadomosci/dzieki-chatgpt-napisal-artykul-do-gazety-o-wartosci-600-dol-w-zaledwie-30-sekund/nk09wdl](https://businessinsider.com.pl/wiadomosci/dzieki-chatgpt-napisal-artykul-do-gazety-o-wartosci-600-dol-w-zaledwie-30-sekund/nk09wdl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 18:45:48+00:00
 - user: None

Freelancer zajmujący się tworzeniem tekstem opowiada, jak jego pierwotne rozbawienie aplikacją ChatGPT stworzoną przez Open AI zamieniło się w "zgrozę", gdy bot wyprodukował niemal gotowy artykuł marketingowy w zaledwie 30 sekund.

## KGHM daje rekordowe podwyżki. Firma porozumiała się ze związkowcami
 - [https://businessinsider.com.pl/firmy/podwyzki-w-2023-r-w-kghm-beda-rekordowe/n61e52j](https://businessinsider.com.pl/firmy/podwyzki-w-2023-r-w-kghm-beda-rekordowe/n61e52j)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 18:15:34+00:00
 - user: None

Płace zasadnicze w KGHM wzrosną o 13,2 proc. Przewidywana jest również jednorazowa nagroda dla pracowników — poinformowała w czwartek spółka.

## Netflix zmienia zasady. "Zostało mniej niż 10 tygodni"
 - [https://businessinsider.com.pl/twoje-pieniadze/wspoldzielenie-konta-netflix-zmienia-regulamin/pqnchbg](https://businessinsider.com.pl/twoje-pieniadze/wspoldzielenie-konta-netflix-zmienia-regulamin/pqnchbg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 17:43:07+00:00
 - user: None

Zostało mniej niż 10 tygodni, aby pozwolić mamie, bratu lub komukolwiek spoza domu używać twojego konta na Netflix. Potem trzeba będzie zapłacić.

## Górnicy z JSW jadą protestować do Warszawy. Związkowcy podali datę
 - [https://businessinsider.com.pl/twoje-pieniadze/gornicy-zapowiadaja-protest-w-warszawie-beda-pikietowac-pod-resortem-sasina/ld5lph8](https://businessinsider.com.pl/twoje-pieniadze/gornicy-zapowiadaja-protest-w-warszawie-beda-pikietowac-pod-resortem-sasina/ld5lph8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 17:27:10+00:00
 - user: None

Związkowcy z Jastrzębskiej Spółki Węglowej (JSW), domagający się 25-proc. podwyżki wynagrodzeń pracowników spółki, rozpoczęli przygotowania do zaplanowanej na 10 lutego manifestacji w Warszawie. Związkowe biura rozpoczęły zapisy chętnych na udział w pikiecie przed siedzibą MAP.

## Chce znów mieć ciało 18-latka. 45-latek poddaje się eksperymentowi za 2 mln dol
 - [https://businessinsider.com.pl/wiadomosci/chce-odwrocic-proces-starzenia-45-latek-rozpoczal-eksperyment-wart-2-mln-dol/ztsdc62](https://businessinsider.com.pl/wiadomosci/chce-odwrocic-proces-starzenia-45-latek-rozpoczal-eksperyment-wart-2-mln-dol/ztsdc62)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 16:59:21+00:00
 - user: None

45-letni założyciel i dyrektor firmy biotechnologicznej cofnął swój wiek biologiczny o co najmniej pięć lat dzięki rygorystycznemu programowi medycznemu, który może kosztować nawet 2 mln dol. rocznie, jak donosi Bloomberg.

## Wojenny biznes się rozkręca. Największe koncerny zbrojeniowe urosły o 100 mld dol.
 - [https://businessinsider.com.pl/gielda/wiadomosci/wojna-w-ukrainie-to-wielki-biznes-tyle-urosly-najwieksze-koncerny-zbrojeniowe/wc3exnn](https://businessinsider.com.pl/gielda/wiadomosci/wojna-w-ukrainie-to-wielki-biznes-tyle-urosly-najwieksze-koncerny-zbrojeniowe/wc3exnn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 16:04:05+00:00
 - user: None

Niemiecki producent czołgów Leopard w rok zwiększył rynkową wartość swojego biznesu o 150 proc., co daje 6 mld euro. Kwotowo podobny wzrost zaliczył amerykański producent abramsów, a prawie trzykrotnie większy skok zanotował producent samolotów F-16. Lista beneficjentów eskalacji konfliktów jest długa. Sprawdziliśmy też, czy mogą na tym zarobić osoby postronne.

## Australian Open. Ile Magda Linette zarobiła za udział w półfinale?
 - [https://businessinsider.com.pl/sport/linette-przegrala-z-sabalenka-w-australian-open-tyle-zarobila/5451mk1](https://businessinsider.com.pl/sport/linette-przegrala-z-sabalenka-w-australian-open-tyle-zarobila/5451mk1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 15:54:56+00:00
 - user: None

Magda Linette przegrała w czwartek w półfinale Australian Open, jednak dojście do tego etapu to dla 30-letniej poznanianki ogromny sukces, również finansowy. Ile zarobiła za udział w półfinale?

## PiS chce większej odległości wiatraków od domów. "Poprawka napisana na kolanie"
 - [https://businessinsider.com.pl/biznes/pis-chce-wiekszej-odleglosci-wiatrakow-od-domow-poprawke-zglosil-posel-suski/wfkmwlt](https://businessinsider.com.pl/biznes/pis-chce-wiekszej-odleglosci-wiatrakow-od-domow-poprawke-zglosil-posel-suski/wfkmwlt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 15:36:39+00:00
 - user: None

Minimalna odległość farm wiatrowych od domów mieszkalnych ma sięgać 700 m — taką poprawkę do projektu ustawy zgłosiły w czwartek sejmowe komisje energii, klimatu i aktywów oraz samorządu i polityki regionalnej. Poprzednia propozycja pozwalała na budowę trubin w odległości 500 m. Odblokowanie inwestycji w energetykę wiatrową na lądzie jest jednym z warunków do wypłaty Polsce pieniędzy z Krajowego Planu Odbudowy. — PiS chce wypełnić kamień milowy, ale tak naprawdę nie chce wiatraków w Polsce — komentują politycy opozycji.

## To będzie rok wysokiej inflacji i słabszego wzrostu gospodarczego
 - [https://businessinsider.com.pl/gospodarka/najnowsze-prognozy-dotyczace-inflacji-pkb-i-stop-procentowych-w-polsce/xh3j085](https://businessinsider.com.pl/gospodarka/najnowsze-prognozy-dotyczace-inflacji-pkb-i-stop-procentowych-w-polsce/xh3j085)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 15:26:23+00:00
 - user: None

PKB wzrośnie w Polsce o 0,5 proc. w 2023 r., przyspieszając w kolejnych latach do 2,3 proc. w 2024 r. i 3,4 proc. w 2025 r. — wynika raportu EY. W scenariuszu bazowym w Polsce zostaną utrzymane stopy procentowe na obecnym poziomie w 2023 r. Inflacja w swój szczyt osiągnie w lutym, prawdopodobnie nieco poniżej 20proc. rok do roku.

## Rosja. Nie żyje kolejny biznesmen związany z przemysłem zbrojeniowym
 - [https://businessinsider.com.pl/wiadomosci/rosja-kolejna-zagadkowa-smierc-biznesmena-mial-zasnac-z-papierosem/04tl165](https://businessinsider.com.pl/wiadomosci/rosja-kolejna-zagadkowa-smierc-biznesmena-mial-zasnac-z-papierosem/04tl165)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 15:02:59+00:00
 - user: None

W pożarze w Moskwie w elitarnej dzielnicy zginął Dmitrij Pawoczka, wysoki rangą menadżer związany m.in. z Roskosmosem i Łukoil. To kolejna zagadkowa śmierć osoby powiązanej z przemysłem zbrojeniowym — podają media. Nikt poza menadżerem nie ucierpiał w pożarze.

## Amerykańska gospodarka hamuje, ale w nowych danych trudno doszukiwać się recesji
 - [https://businessinsider.com.pl/finanse/makroekonomia/gospodarka-usa-traci-impet-ale-trudno-doszukiwac-sie-recesji-dane-o-pkb-za-iv-kwartal/6t20csv](https://businessinsider.com.pl/finanse/makroekonomia/gospodarka-usa-traci-impet-ale-trudno-doszukiwac-sie-recesji-dane-o-pkb-za-iv-kwartal/6t20csv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 14:44:51+00:00
 - user: None

Wprawdzie ostatnie odczyty ze Stanów Zjednoczonych wskazywały na mniejszą konsumpcję i produkcję przemysłową, to dane o PKB w całym IV kwartale 2022 r. nie sugerują nadejścia recesji w największej gospodarce świata.

## Branża turystyczna przy granicy z Białorusią dostanie wsparcie. KE dała zielone światło
 - [https://businessinsider.com.pl/biznes/jest-zgoda-ke-na-pomoc-publiczna-dla-branzy-turystycznej-przy-granicy-z-bialorusia/zwpysg3](https://businessinsider.com.pl/biznes/jest-zgoda-ke-na-pomoc-publiczna-dla-branzy-turystycznej-przy-granicy-z-bialorusia/zwpysg3)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 14:09:57+00:00
 - user: None

Komisja Europejska zatwierdziła w czwartek polski program pomocy publicznej dla sektora turystycznego o wartości 21 mln euro. Ma on na celu zrekompensowanie przedsiębiorstwom działającym w sektorze turystyki strat poniesionych w wyniku środków ograniczających przyjętych przez Polskę w odpowiedzi na instrumentalizację migrantów przez władze białoruskie na zewnętrznej granicy UE.

## Trybunał Sprawiedliwości zdecydował w polskiej sprawie frankowej. Łączenia postępowań nie będzie
 - [https://businessinsider.com.pl/finanse/jest-decyzja-tsue-we-frankowej-sprawie-polaczenia-postepowan-nie-bedzie/nrcvmze](https://businessinsider.com.pl/finanse/jest-decyzja-tsue-we-frankowej-sprawie-polaczenia-postepowan-nie-bedzie/nrcvmze)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 13:53:32+00:00
 - user: None

Trybunał Sprawiedliwości Unii Europejskiej zdecydował, że nie połączy obu polskich spraw frankowych dotyczących opłaty za korzystanie z kapitału. To oznacza, że najprawdopodobniej opinia rzecznika generalnego TSUE zostanie przedstawiona zgodnie z planem, czyli 12 lutego. Pozostaje jednak wątpliwość, czy w wyroku, spodziewanym jesienią, luksemburski trybunał w pełni odpowie na pytania dotyczące sposobu rozliczeń obu stron.

## Kobiety w kamasze. Kolejny kraj wprowadzi obowiązkowy pobór
 - [https://businessinsider.com.pl/wiadomosci/obowiazkowy-pobor-do-wojska-w-tym-kraju-kobiety-pojda-w-kamasze/hnc1mde](https://businessinsider.com.pl/wiadomosci/obowiazkowy-pobor-do-wojska-w-tym-kraju-kobiety-pojda-w-kamasze/hnc1mde)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 13:50:35+00:00
 - user: None

Dania dąży do znacznego zwiększenia liczebności swoich sił zbrojnych i planuje obowiązkowy pobór do wojska dla kobiet — podaje Bloomberg.

## Zbliża się pierwsza w tym roku niedziela handlowa. Sklepy szykują oferty
 - [https://businessinsider.com.pl/biznes/przed-nami-pierwsza-niedziela-handlowa-w-2023-r-sprawdz-co-przygotowaly-sieci/fldm7h8](https://businessinsider.com.pl/biznes/przed-nami-pierwsza-niedziela-handlowa-w-2023-r-sprawdz-co-przygotowaly-sieci/fldm7h8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 13:46:52+00:00
 - user: None

W 2023 r. czeka nas siedem niedziel handlowych. Pierwsza z nich przypadnie 29 stycznia. Sieci handlowe już informują o przygotowanych na ten dzień promocjach, ale też o wyjątkowych godzinach otwarcia swoich sklepów.

## Który smartwatch Polara kupić? Przegląd zegarków sportowych
 - [https://businessinsider.com.pl/technologie/ktory-smartwatch-polara-kupic-przeglad-zegarkow-sportowych/3j70gnh](https://businessinsider.com.pl/technologie/ktory-smartwatch-polara-kupic-przeglad-zegarkow-sportowych/3j70gnh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 13:23:00+00:00
 - user: None

Polar ma w swojej ofercie sporo ciekawych zegarków sportowych. Użytkownicy chwalą je nie tylko za funkcjonalność i design, ale doceniają również cały system Polara oraz aplikację mobilną. Sprawdź, który smartwatch będzie idealny dla ciebie.

## Słynna brytyjska firma zmienia nazwę. Po 140 latach
 - [https://businessinsider.com.pl/biznes/140-lat-i-wystarczy-provident-financial-porzuca-nazwe/7whl688](https://businessinsider.com.pl/biznes/140-lat-i-wystarczy-provident-financial-porzuca-nazwe/7whl688)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:52:57+00:00
 - user: None

Słynna brytyjska firma finansowa wyspecjalizowana w udzielaniu kredytów wysokiego ryzyka Provident Financial zmieni swoją nazwę po 140 latach — donosi "Financial Times". Decyzja o porzuceniu legendarnej już nazwy to efekt zmiany modelu biznesowego firmy.

## Waloryzacja rent i emerytur. Minister podała szczegóły
 - [https://businessinsider.com.pl/twoje-pieniadze/waloryzacja-rent-i-emerytur-minister-podala-szczegoly/ry9skgw](https://businessinsider.com.pl/twoje-pieniadze/waloryzacja-rent-i-emerytur-minister-podala-szczegoly/ry9skgw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:41:47+00:00
 - user: None

Wszystko wskazuje na to, że waloryzacja rent i emerytur będzie na poziomie 14,8 proc. — przekazała w czwartek minister rodziny i polityki społecznej Marlena Maląg. Prezes ZUS prof. Gertruda Uścińska poinformowała, że koszt tegorocznej waloryzacji przekroczy 40 mld zł.

## Rolników czeka trudny rok. Upadnie wiele rodzinnych gospodarstw
 - [https://businessinsider.com.pl/gospodarka/rolnikow-czeka-trudny-rok-upadnie-wiele-rodzinnych-gospodarstw/zftqs00](https://businessinsider.com.pl/gospodarka/rolnikow-czeka-trudny-rok-upadnie-wiele-rodzinnych-gospodarstw/zftqs00)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:39:23+00:00
 - user: None

Ten rok może być bardzo trudny dla rolników, z uwagi na rosnące koszty produkcji, słabnące zyski, w tym niskie ceny skupu, a także wydłużające się zatory płatnicze. Eksperci prognozują, że wiosną przybędzie dłużników w tym sektorze, a najgorzej będzie w połowie roku.

## Rewolucja kadrowa na szczycie Toyoty. Akio Toyoda rezygnuje
 - [https://businessinsider.com.pl/technologie/motoryzacja/rewolucja-kadrowa-na-szczycie-toyoty-akio-toyoda-rezygnuje-ze-stanowiska/xp94znn](https://businessinsider.com.pl/technologie/motoryzacja/rewolucja-kadrowa-na-szczycie-toyoty-akio-toyoda-rezygnuje-ze-stanowiska/xp94znn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:22:21+00:00
 - user: None

Akio Toyoda, wnuk założyciela firmy, która dziś znana jest pod marką Toyota, przestanie formalnie szefować koncernowi. Nowym prezesem Koji Sato, który z firmą związany jest od 30 lat.

## Rewolucja kadrowa na szczycie Toyoty. Akio Toyoda rezygnuje
 - [https://businessinsider.com.pl/technologie/motoryzacja/rewolucja-kadrowa-toyoty-nazwisko-zalozyciela-firmy-znika-szczytu-koncernu/xp94znn](https://businessinsider.com.pl/technologie/motoryzacja/rewolucja-kadrowa-toyoty-nazwisko-zalozyciela-firmy-znika-szczytu-koncernu/xp94znn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:22:21+00:00
 - user: None

Akio Toyoda, wnuk założyciela firmy, która dziś znana jest pod marką Toyota, przestanie formalnie szefować koncernowi. Nowym prezesem Koji Sato, który z firmą związany jest od 30 lat.

## Najpopularniejsze piekarniki do zabudowy — sprawdź obiektywny ranking
 - [https://businessinsider.com.pl/technologie/najpopularniejsze-piekarniki-do-zabudowy-sprawdz-obiektywny-ranking/xkn3ksv](https://businessinsider.com.pl/technologie/najpopularniejsze-piekarniki-do-zabudowy-sprawdz-obiektywny-ranking/xkn3ksv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:10:00+00:00
 - user: None

W najnowszym rankingu popularności piekarników do zabudowy nastąpiło kilka przetasowań. Wśród najlepszej piątki są jednak świetne urządzenia, które bez obaw można kupić do własnej kuchni. Dane pochodzą z porównywarki cen Skąpiec.pl.

## Ważny termin w sprawie 500 plus. Minister przypomina
 - [https://businessinsider.com.pl/twoje-pieniadze/wazny-termin-w-sprawie-500-plus-minister-malag-przypomina/qwjh822](https://businessinsider.com.pl/twoje-pieniadze/wazny-termin-w-sprawie-500-plus-minister-malag-przypomina/qwjh822)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 12:07:32+00:00
 - user: None

Od 1 lutego rusza nabór wniosków na nowy okres świadczeniowy programu Rodzina 500 plus. Każdego miesiąca z programu korzysta około 7 mln dzieci – powiedziała w czwartek minister rodziny Marlena Maląg.

## Złowieszcze prognozy dla rynku hipotek. O kredyt nadal będzie bardzo trudno
 - [https://businessinsider.com.pl/finanse/o-hipoteki-w-2023-r-wciaz-bedzie-trudno-bik-prognozuje-spadek-sprzedazy/bl0knl2](https://businessinsider.com.pl/finanse/o-hipoteki-w-2023-r-wciaz-bedzie-trudno-bik-prognozuje-spadek-sprzedazy/bl0knl2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 11:56:06+00:00
 - user: None

Wzrost inflacji i stóp procentowych oraz zaostrzone wymogi regulacyjne przy jednoczesnych dalszych zwyżkach cen mieszkań spowodowały, że zdolność kredytowa Polaków w 2022 r. mocno spadła. Prognozy Biura Informacji Kredytowej wskazują, że w tym roku lepiej nie będzie.

## Szef brytyjskiej komisji obrony: w Polsce powinna powstać wielka fabryka broni dla Ukrainy
 - [https://businessinsider.com.pl/gospodarka/szef-brytyjskiej-komisji-obrony-w-polsce-powinna-powstac-wielka-fabryka-broni-dla/2qdcbzq](https://businessinsider.com.pl/gospodarka/szef-brytyjskiej-komisji-obrony-w-polsce-powinna-powstac-wielka-fabryka-broni-dla/2qdcbzq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 11:50:29+00:00
 - user: None

Aby pomóc Ukrainie wygrać wojnę, w Polsce musi powstać ogromna fabryka broni, bo obecny model darowizn jest w dłuższej perspektywie nie do utrzymania — powiedział w czwartek szef komisji obrony w brytyjskiej Izbie Gmin Tobias Ellwood.

## Narty coraz bardziej elitarne. Tak drożeją skipassy
 - [https://businessinsider.com.pl/twoje-pieniadze/elitarnie-jak-na-nartach-za-skipassy-trzeba-placic-setkami/w4s1hg9](https://businessinsider.com.pl/twoje-pieniadze/elitarnie-jak-na-nartach-za-skipassy-trzeba-placic-setkami/w4s1hg9)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 11:30:15+00:00
 - user: None

Wyjazd na ferie w góry nigdy nie był sprawą tanią i drożał w zasadzie co roku. Obecna sytuacja gospodarczo-polityczna wywindowała jednak ceny ekstremalnie. Doskonale widać to po biletach wstępu na stoki.

## Bankowcy biorą WIBOR w obronę. Ich zdaniem jest uczciwie wyznaczaną stawką
 - [https://businessinsider.com.pl/finanse/bankowcy-bronia-wibor-ich-zdaniem-jest-uczciwie-wyznaczana-stawka/vtfhjjd](https://businessinsider.com.pl/finanse/bankowcy-bronia-wibor-ich-zdaniem-jest-uczciwie-wyznaczana-stawka/vtfhjjd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 11:09:19+00:00
 - user: None

Wskaźnik referencyjny WIBOR, stosowany do wyznaczania m.in. oprocentowania zdecydowanej większości hipotek, jest wyliczany rzetelnie i wiarygodnie, nie dochodziło do manipulacji tym wskaźnikiem — ocenia w swoim stanowisku Związek Banków Polskich. Zdaniem ZBP oczekiwanie, że sądy będą usuwać z umowy ten wskaźnik, jest nierealistyczne.

## Rynkowy rollercoaster – podsumowanie rynku nieruchomości i kredytów hipotecznych w 2022 r.
 - [https://businessinsider.com.pl/twoje-pieniadze/rynkowy-rollercoaster-podsumowanie-rynku-nieruchomosci-i-kredytow-hipotecznych-w-2022/50hb4xy](https://businessinsider.com.pl/twoje-pieniadze/rynkowy-rollercoaster-podsumowanie-rynku-nieruchomosci-i-kredytow-hipotecznych-w-2022/50hb4xy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 11:00:00+00:00
 - user: None

Rosnące koszty zobowiązań kredytowych i niepewność wywołana trudną do przewidzenia ogólną sytuacją gospodarczą skutecznie sparaliżowały popyt na kredyty hipoteczne. Kłopoty z uzyskaniem finansowania na zakup nieruchomości przełożyły się na spadek zainteresowania mieszkaniami. Ofert sprzedażowych na rynku nieruchomości przybywa, a poszukujących jak na lekarstwo. Otwierają się za to perspektywy przed inwestorami z gotówką. Jak wygląda sytuacja na rynku kredytowym? Jakich zmian spodziewać się na rynku mieszkaniowym? W jaki sposób obie branże wspierają się w obliczu kryzysu? I dlaczego dopiero teraz kredytobiorcy doceniają wsparcie ekspertów kredytowych?

## Kolejni technologiczni giganci zwalniają. Wielkie cięcie trwa w najlepsze
 - [https://businessinsider.com.pl/technologie/kolejni-technologiczni-giganci-zwalniaja-ibm-i-sap-oglosily-swoje-plany/ysdkwhh](https://businessinsider.com.pl/technologie/kolejni-technologiczni-giganci-zwalniaja-ibm-i-sap-oglosily-swoje-plany/ysdkwhh)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 10:54:00+00:00
 - user: None

Niemiecki SAP i amerykański IBM dołączyły do grona firm technologicznych, które będą zwalniać. Z pracą w SAP pożegna się do 3 tys. pracowników. W IBM zwolnienia sięgną niemal 4 tys. osób.

## Polskie inwestycje w Ukrainie mogą skokowo wzrosnąć. Oto najnowsze prognozy
 - [https://businessinsider.com.pl/finanse/makroekonomia/polskie-inwestycje-w-ukrainie-wystrzela-najnowsze-prognozy-pie/320e5mg](https://businessinsider.com.pl/finanse/makroekonomia/polskie-inwestycje-w-ukrainie-wystrzela-najnowsze-prognozy-pie/320e5mg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 10:40:33+00:00
 - user: None

Polskie inwestycje bezpośrednie (BIZ) w Ukrainie mogą wzrosnąć do 30 mld dolarów w najbliższych pięciu latach lat — wynika z szacunków Polskiego Instytutu Ekonomicznego (PIE). To byłby kilkukrotny wzrost w porównaniu do ostatniego roku sprzed wybuchu wojny.

## Tyle czasu Polacy oszczędzają na pracy zdalnej. Wiadomo, jak go wykorzystują
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/tyle-czasu-polacy-oszczedzaja-na-pracy-zdalnej-wiadomo-jak-go-wykorzystuja/7c77x6t](https://businessinsider.com.pl/twoje-pieniadze/praca/tyle-czasu-polacy-oszczedzaja-na-pracy-zdalnej-wiadomo-jak-go-wykorzystuja/7c77x6t)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 10:38:21+00:00
 - user: None

Polak pracujący zdalnie oszczędza na dojeździe do pracy mniej niż średnia dla badanych państw. Duża część osób zaoszczędzony czas i tak poświęca na pracę.

## Rząd chce szybko działać w sprawie KPO. Nie będzie czekał na prezydenta
 - [https://businessinsider.com.pl/wiadomosci/rzad-chce-szybko-dzialac-w-sprawie-kpo-nie-bedzie-czekal-na-prezydenta/deblgfy](https://businessinsider.com.pl/wiadomosci/rzad-chce-szybko-dzialac-w-sprawie-kpo-nie-bedzie-czekal-na-prezydenta/deblgfy)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 10:02:02+00:00
 - user: None

Wniosek w sprawie KPO zostanie złożony do Komisji Europejskiej przed przekazaniem noweli ustawy o Sądzie Najwyższym do prezydenta — powiedział premier Mateusz Morawiecki.

## Sztuczna inteligencja przejmuje stery. Zwolnienia i cięcia wynagrodzeń na rynku IT
 - [https://businessinsider.com.pl/wiadomosci/in-business-jaroslaw-krolewski-prezes-synerise-o-sztucznej-inteligencji-i/xs2nme8](https://businessinsider.com.pl/wiadomosci/in-business-jaroslaw-krolewski-prezes-synerise-o-sztucznej-inteligencji-i/xs2nme8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 10:00:00+00:00
 - user: None

Zwolnienia i cięcia wynagrodzeń na rynku IT, Chat GPT zmieniający świat i przyszłość sztucznej inteligencji. Między innymi o tym w najnowszym odcinku In Business z prezesem Synerise Jarosławem Królewskim rozmawiał Mikołaj Kunica.

## Wakacje kredytowe. Tak obciążają wyniki banków
 - [https://businessinsider.com.pl/gielda/wiadomosci/tak-wakacje-kredytowe-obciazaja-wyniki-bankow-najnowsze-dane/tfllgg6](https://businessinsider.com.pl/gielda/wiadomosci/tak-wakacje-kredytowe-obciazaja-wyniki-bankow-najnowsze-dane/tfllgg6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 09:51:17+00:00
 - user: None

Analitycy biur maklerskich podsumowują koszty, jakie z powodu wakacji kredytowych na lata 2022-2023 zanotują polskie banki. Założone przez instytucje wskaźniki partycypacji mocno różnią się między sobą.

## Nie dostał kredytu, bo jest otyły. Bank zabiera głos
 - [https://businessinsider.com.pl/finanse/nie-dostal-kredytu-bo-jest-otyly-bank-zabiera-glos/g091pdw](https://businessinsider.com.pl/finanse/nie-dostal-kredytu-bo-jest-otyly-bank-zabiera-glos/g091pdw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 09:44:15+00:00
 - user: None

Serwis Subiektywnie o Finansach opisał historię mężczyzny, który nie dostał kredytu przez swoją otyłość. Brzmi absurdalnie, a jednak. Wszystko przez odmowę obowiązkowego ubezpieczenia.

## Kontrowersyjna poprawka w ustawie wiatrakowej
 - [https://businessinsider.com.pl/wiadomosci/kontrowersyjna-poprawka-w-ustawie-wiatrakowej/ytdmzdb](https://businessinsider.com.pl/wiadomosci/kontrowersyjna-poprawka-w-ustawie-wiatrakowej/ytdmzdb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:36:31+00:00
 - user: None

Do projektu nowelizacji ustawy wiatrakowej Solidarna chce wpisać poprawkę, która mówi, że w każdym miejscu, w którym mają stanąć wiatraki, powinno odbyć się referendum wśród mieszkańców. Samorządy poprawkę krytykują, rząd jest "otwarty na różne korekty".

## Zielone światło dla przekazania F-16 Ukraińcom. Producent zabrał głos
 - [https://businessinsider.com.pl/wiadomosci/zielone-swiatlo-dla-przekazania-f-16-ukraincom-producent-zabral-glos/7qsvnsn](https://businessinsider.com.pl/wiadomosci/zielone-swiatlo-dla-przekazania-f-16-ukraincom-producent-zabral-glos/7qsvnsn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:35:01+00:00
 - user: None

Lockheed Martin powiedział, że jest gotowy zaspokoić popyt na swoje samoloty F-16 — podaje "Financial Times". To reakcja na doniesienia, że niektóre kraje wznawiają starania o dostarczenie myśliwców do Kijowa.

## O poważnej dezinflacji nie ma mowy. To hasło jest przereklamowane - pisze członkini RPP
 - [https://businessinsider.com.pl/finanse/makroekonomia/o-powaznej-dezinflacji-nie-ma-mowy-to-haslo-jest-przereklamowane/6tzjt9n](https://businessinsider.com.pl/finanse/makroekonomia/o-powaznej-dezinflacji-nie-ma-mowy-to-haslo-jest-przereklamowane/6tzjt9n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:23:04+00:00
 - user: None

Hasło "dezinflacja" wydaje się nieco przereklamowane. Średnioroczna inflacja w 2022 roku wyniosła około 14,3 proc., podczas gdy prognozy na 2023 r., nawet te bardziej optymistyczne, wskazują na średnioroczną inflację na poziomie 11-12 proc. — uważa prof. Joanna Tyrowicz, członkini Rady Polityki Pieniężnej. Zwraca uwagę, że problemem jest rosnąca inflacja bazowa.

## Prezes ZBP ostro o przedłużaniu wakacji kredytowych
 - [https://businessinsider.com.pl/finanse/prezes-zbp-ostro-o-przedluzaniu-wakacji-kredytowych/vh61njw](https://businessinsider.com.pl/finanse/prezes-zbp-ostro-o-przedluzaniu-wakacji-kredytowych/vh61njw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:20:05+00:00
 - user: None

Przedłużanie powszechnych wakacji kredytowych byłoby skrajną nieodpowiedzialnością — ocenia prezes Związku Banków Polski Krzysztof Pietraszkiewicz. Wskazuje, że mechanizm ten spowodował ograniczenie zdolności finansowania rozwoju gospodarki o ponad 300 mld zł.

## "Najsłabszy miesiąc od II wojny światowej". Demograficzny problem Polski przebija czarny scenariusz
 - [https://businessinsider.com.pl/wiadomosci/najslabszy-miesiac-od-ii-wojny-swiatowej-demograficzny-problem-polski-przebija-czarny/j596t14](https://businessinsider.com.pl/wiadomosci/najslabszy-miesiac-od-ii-wojny-swiatowej-demograficzny-problem-polski-przebija-czarny/j596t14)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:19:38+00:00
 - user: None

Polska zmaga się z kryzysem demograficznym i na razie tę walkę przegrywa. Jak zauważa ekonomista Rafał Mundry, w listopadzie liczba narodzin była rekordowo niska.

## Kurs euro 26 stycznia powyżej 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-26-stycznia-2023/gdgws68](https://businessinsider.com.pl/gielda/kursy-walut/kurs-euro-eurpln-notowania-walut-26-stycznia-2023/gdgws68)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:04:35+00:00
 - user: None

Kurs euro powyżej 4,7. W czwartek rano 26 stycznia 2022 r. kurs EUR/PLN wynosił 4,7209 zł.

## Kurs dolara 26 stycznia powyżej 4,3
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-stycznia-2023/ef8gt9h](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-25-stycznia-2023/ef8gt9h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:03:12+00:00
 - user: None

Kurs dolara powyżej 4,3. W czwartek rano 26 stycznia 2022 r. kurs USD/PLN wynosi 4,3231.

## Kurs franka 26 stycznia powyżej 4,7
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-26-stycznia-2023/g3ebsh2](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-26-stycznia-2023/g3ebsh2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 08:01:18+00:00
 - user: None

Frank szwajcarski powyżej 4,7. W czwartek rano 26 stycznia 2022 r. kurs tej waluty wobec polskiego złotego wynosi 4,7134.

## Kilometrówki do zmiany. Stawki dopiero co wzrosły, a już szykuje się kolejna nowość
 - [https://businessinsider.com.pl/twoje-pieniadze/kilometrowki-do-zmiany-stawki-dopiero-co-wzrosly-a-juz-szykuje-sie-kolejna-nowosc/1z1tqz2](https://businessinsider.com.pl/twoje-pieniadze/kilometrowki-do-zmiany-stawki-dopiero-co-wzrosly-a-juz-szykuje-sie-kolejna-nowosc/1z1tqz2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 07:21:36+00:00
 - user: None

W styczniu po 15 latach zmieniły się stawki tzw. kilometrówek, czyli zwrotu kosztów używania do celów służbowych pojazdów niebędących własnością pracodawcy. Tymczasem rząd już pracuje nad kolejną nowością.

## Polskie uzdrowiska bezprawnie pobierają opłaty za czyste powietrze
 - [https://businessinsider.com.pl/wiadomosci/polskie-uzdrowiska-bezprawnie-pobieraja-oplaty-za-czyste-powietrze/fc9xs8z](https://businessinsider.com.pl/wiadomosci/polskie-uzdrowiska-bezprawnie-pobieraja-oplaty-za-czyste-powietrze/fc9xs8z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 07:02:40+00:00
 - user: None

Kilkadziesiąt zanieczyszczonych kurortów górskich i uzdrowisk z Małopolski i Dolnego Śląska bezprawnie pobiera tzw. opłaty klimatyczne od odwiedzających. Stan powietrza w tych miejscowościach dalece przekracza normy czystości — informuje portalsamorzadowy.pl powołując się na dane z najnowszego raportu Fundacji ClientEarth.

## Milionowe nagrody w Ministerstwie Finansów. Resort tłumaczy, że to nie za Polski Ład
 - [https://businessinsider.com.pl/finanse/milionowe-nagrody-w-ministerstwie-finansow-resort-tlumaczy-ze-to-nie-za-polski-lad/86vjxee](https://businessinsider.com.pl/finanse/milionowe-nagrody-w-ministerstwie-finansow-resort-tlumaczy-ze-to-nie-za-polski-lad/86vjxee)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 06:43:57+00:00
 - user: None

64 mln zł w ramach nagród wypłacono pracownikom Ministerstwa Finansów w 2022 r. Ministerstwo Finansów w 2022 r. Resort przekonuje, że nagrody nie mają nić wspólnego z Polskim Ładem, co sugerował jeden z portali.

## Każdy czwartoklasista z własnym laptopem. Są szczegóły programu
 - [https://businessinsider.com.pl/wiadomosci/kazdy-czwartoklasista-z-wlasnym-laptopem-sa-szczegoly-programu/lesj371](https://businessinsider.com.pl/wiadomosci/kazdy-czwartoklasista-z-wlasnym-laptopem-sa-szczegoly-programu/lesj371)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 06:21:49+00:00
 - user: None

Każde dziecko, które będzie szło do IV klasy od nowego roku szkolnego 2023/2024, będzie miało swój komputer do użycia w szkole i po szkole — powiedział "DGP" sekretarz stanu w KPRM, pełnomocnik rządu ds. cyberbezpieczeństwa Janusz Cieszyński.

## Gdzie się podziały tamte lumpeksy? W Polsce ubywa second-handów
 - [https://businessinsider.com.pl/firmy/gdzie-sie-podzialy-tamte-lumpeksy-w-polsce-ubywa-second-handow/85el9nl](https://businessinsider.com.pl/firmy/gdzie-sie-podzialy-tamte-lumpeksy-w-polsce-ubywa-second-handow/85el9nl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 06:09:04+00:00
 - user: None

Sklepy z używaną odzieżą znikają z polskich miast i miasteczek. W 2022 r. prawie 600 takich lokali zawiesiło lub zakończyło działalność.

## Wiatr zmian w PKP Intercity. Teraz planuje wprowadzić program lojalnościowy
 - [https://businessinsider.com.pl/wiadomosci/wiatr-zmian-w-pkp-intercity-teraz-planuje-wprowadzic-program-lojalnosciowy/wplbc9d](https://businessinsider.com.pl/wiadomosci/wiatr-zmian-w-pkp-intercity-teraz-planuje-wprowadzic-program-lojalnosciowy/wplbc9d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:59:56+00:00
 - user: None

PKP Intercity planuje przygotować program lojalnościowy dla podróżnych. Ma to zrobić własnymi siłami — poinformował członek zarządu kolejowej spółki Tomasz Gontarz. Wcześniej spółka myślała, aby ogłosić przetarg na wybór dostawcy systemu obsługującego program lojalnościowy.

## Napoje energetyczne kupią tylko dorośli? Jest pomysł
 - [https://businessinsider.com.pl/finanse/handel/napoje-energetyczne-kupia-tylko-dorosli-jest-pomysl/8d0lk7g](https://businessinsider.com.pl/finanse/handel/napoje-energetyczne-kupia-tylko-dorosli-jest-pomysl/8d0lk7g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:45:26+00:00
 - user: None

Posłowie pytają Ministerstwo Zdrowia, na jakim etapie są prace nad ustawą zakazującą sprzedaży napojów energetycznych osobom poniżej 16. lat — piszą wiadomoscihandlowe.pl.

## Wakacje kredytowe mogą być dłuższe — nikt tego nie mówi oficjalnie, ale giełda i tak wpadła w popłoch
 - [https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-26012023/380ynt7](https://businessinsider.com.pl/gospodarka/piec-najciekawszych-wydarzen-w-gospodarce-teraz-26012023/380ynt7)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:45:18+00:00
 - user: None

Widmo wydłużonych wakacji kredytowych przeraziło inwestorów giełdowych i wzbudziło obawy o to, jak może wyglądać udzielanie kredytów hipotecznych w przyszłości. Stopa bezrobocia lekko urosła, za to zamówienia w fabrykach maleją. Kanada jako pierwsza wśród rozwiniętych gospodarek ogłosiła koniec podwyżek stóp, a Tesla pokazała najlepsze wyniki finansowe w swojej historii. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Sejm zaczyna rewolucję w Kodeksie pracy. Urlopy i okres próbny do poprawki?
 - [https://businessinsider.com.pl/prawo/praca/urlopy-i-umowy-na-okres-probny-co-zmieni-sie-w-kodeksie-pracy/fes825g](https://businessinsider.com.pl/prawo/praca/urlopy-i-umowy-na-okres-probny-co-zmieni-sie-w-kodeksie-pracy/fes825g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:30:29+00:00
 - user: None

Pracownicy zyskają wreszcie dodatkowe urlopy, w tym te opiekuńcze oraz lepszą ochronę przed zwolnieniem. Sejm zaczyna prace nad spóźnioną, bardzo szeroką nowelizacją Kodeksu pracy, która wdraża unijną dyrektywę, m.in. o work-life balance. Zdaniem pracodawców i związkowców posłowie powinni poprawić przepisy, w tym np. dotyczące umów na okres próbny.

## Na rynku węgla trwa hossa, a do kopalń i tak dokładamy
 - [https://businessinsider.com.pl/biznes/na-rynku-wegla-trwa-hossa-a-do-kopaln-i-tak-dokladamy/rqfp7x2](https://businessinsider.com.pl/biznes/na-rynku-wegla-trwa-hossa-a-do-kopaln-i-tak-dokladamy/rqfp7x2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:22:24+00:00
 - user: None

Polskie kopalnie zarobiły w minionym roku krocie, ale i tak sięgnęły po pomoc publiczną od państwa w wysokości 1,6 mld zł. Cel: redukcja zdolności produkcyjnych. Tymczasem spółki węglowe pracowały na pełnych obrotach, by zapełnić lukę na rynku po rosyjskim węglu i mówią wprost, że zamierzają inwestować w zwiększenie wydobycia. Co więcej, program pomocy dla górnictwa wciąż nie uzyskał akceptacji Komisji Europejskiej, choć wniosek w tej sprawie trafił do Brukseli w marcu 2022 r. — Dotychczasowy dialog nie wskazuje na brak zrozumienia ze strony KE — przekonuje resort aktywów państwowych.

## Facebook pozwala na powrót Donalda Trumpa
 - [https://businessinsider.com.pl/media/internet/facebook-pozwala-na-powrot-donalda-trumpa/h0lnsrc](https://businessinsider.com.pl/media/internet/facebook-pozwala-na-powrot-donalda-trumpa/h0lnsrc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:20:37+00:00
 - user: None

W najbliższych tygodniach były prezydent USA Donald Trump będzie mógł powrócić na Facebooka — poinformował w środę właściciel tego serwisu społecznościowego, firma Meta Platforms.

## Specfundusz się kurczy, ale miliardy nadal płyną poza budżetem. Najwięcej do KPRM [TYLKO U NAS]
 - [https://businessinsider.com.pl/finanse/specfundusz-sie-kurczy-ale-miliardy-nadal-plyna-poza-budzetem-najwiecej-do-kprm/qtkxvgq](https://businessinsider.com.pl/finanse/specfundusz-sie-kurczy-ale-miliardy-nadal-plyna-poza-budzetem-najwiecej-do-kprm/qtkxvgq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:11:15+00:00
 - user: None

Fundusz Przeciwdziałania COVID-19 będzie miał do wydania w tym roku 25 mld zł. To znacznie mniejsza kwota niż została rozdysponowana w ubiegłym roku i dowód, że specjalny wehikuł finansowy powołany przez rząd w pandemii zaczyna się kurczyć. To zaś daje nadzieję, że deficyt całego sektora finansów publicznych także będzie mniejszy, niż przewiduje minister finansów. Pieniądze z Funduszu już nie idą na walkę z pandemią, ale na programy inwestycyjne i ograniczanie skutków kryzysu energetycznego.

## Na produkcji jajek zbudowali w Polsce imperium. Nie mają dobrych wiadomości [TYLKO U NAS]
 - [https://businessinsider.com.pl/firmy/na-jajach-zbudowali-imperium-teraz-uderza-w-nich-kryzys-i-ptasia-grypa/96g71yg](https://businessinsider.com.pl/firmy/na-jajach-zbudowali-imperium-teraz-uderza-w-nich-kryzys-i-ptasia-grypa/96g71yg)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-01-26 05:00:00+00:00
 - user: None

— To kryzys o wymiarze światowym — przyznaje w rozmowie z Business Insider Barbara Woźniak, pełnomocnik zarządu Ferm Drobiu Woźniak, firmy będącej największym w Polsce i drugim w Europie dostawcą jaj. Nie ma złudzeń, że kryzys obejmuje również Polskę. Podaje dane świadczące o tym, że rodzime fermy kurczą się w oczach i wskazuje, jakie będą tego konsekwencje dla zwykłych Polaków.
