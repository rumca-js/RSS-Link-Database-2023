# Source IT hardware PL, Source URL:https://ithardware.pl/feed, Source language: pl-PL

## Call of Duty: Warzone 2.0. Gra dostanie sporo nowej zawartości w Sezonie 2
 - [https://ithardware.pl/aktualnosci/call_of_duty_warzone_2_0_gra_dostanie_sporo_nowej_zawartosci_w_sezonie_2-25528.html](https://ithardware.pl/aktualnosci/call_of_duty_warzone_2_0_gra_dostanie_sporo_nowej_zawartosci_w_sezonie_2-25528.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 23:21:55+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25528_1.jpg" />            Sezon 2 w Call of Duty: Warzone 2.0 wystartuje za dwa tygodnie. Tymczasem Infinity Ward ujawniło szczeg&oacute;ły o zmianach, kt&oacute;re będą dostępne w grze i jest ich całkiem sporo.

Inifinity Ward potwierdziło, że Call of Duty: Warzone 2.0...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/call_of_duty_warzone_2_0_gra_dostanie_sporo_nowej_zawartosci_w_sezonie_2-25528.html">https://ithardware.pl/aktualnosci/call_of_duty_warzone_2_0_gra_dostanie_sporo_nowej_zawartosci_w_sezonie_2-25528.html</a></p>

## Escape from Tarkov dostępny na Steam? Nic z tych rzeczy. Gra została wykorzystana przez oszustów
 - [https://ithardware.pl/aktualnosci/escape_from_tarkov_dostepny_na_steam_nic_z_tych_rzeczy_gra_zostala_wykorzystana_przez_oszustow-25527.html](https://ithardware.pl/aktualnosci/escape_from_tarkov_dostepny_na_steam_nic_z_tych_rzeczy_gra_zostala_wykorzystana_przez_oszustow-25527.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 22:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25527_1.jpg" />            Escape from Tarkov, sieciowa strzelanka od&nbsp;Battlestate Games posłużyła do oszustwa na Steam. Przestępcy pr&oacute;bowali za sprawą gry wyłudzić od graczy pieniądze.

Escape from Tarkov dostępny jest na Steam od kilku lat. Sieciowa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/escape_from_tarkov_dostepny_na_steam_nic_z_tych_rzeczy_gra_zostala_wykorzystana_przez_oszustow-25527.html">https://ithardware.pl/aktualnosci/escape_from_tarkov_dostepny_na_steam_nic_z_tych_rzeczy_gra_zostala_wykorzystana_przez_oszustow-25527.html</a></p>

## Skanowanie twarzy wymagane do aktywacji karty SIM w Argentynie
 - [https://ithardware.pl/aktualnosci/skanowanie_twarzy_wymagane_do_aktywacji_karty_sim_w_argentynie-25526.html](https://ithardware.pl/aktualnosci/skanowanie_twarzy_wymagane_do_aktywacji_karty_sim_w_argentynie-25526.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 21:28:21+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25526_1.jpg" />            Argentyńczycy będą mocno pilnować posiadanych kart SIM, bo zakup nowych wiąże się z obowiązkiem pozostawienia skany twarzy w państwowej bazie danych.

Nakaz pobierania danych biometrycznych, aby m&oacute;c korzystać z karty SIM, wyszedł od...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/skanowanie_twarzy_wymagane_do_aktywacji_karty_sim_w_argentynie-25526.html">https://ithardware.pl/aktualnosci/skanowanie_twarzy_wymagane_do_aktywacji_karty_sim_w_argentynie-25526.html</a></p>

## ChatGPT zaliczył egzaminy MBA i lekarski. OpenAI nie przestaje zaskakiwać
 - [https://ithardware.pl/aktualnosci/chatgpt_zaliczyl_egzaminy_mba_i_lekarski_openai_nie_przestaje_zaskakiwac-25524.html](https://ithardware.pl/aktualnosci/chatgpt_zaliczyl_egzaminy_mba_i_lekarski_openai_nie_przestaje_zaskakiwac-25524.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 20:56:18+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25524_1.jpg" />            Organizacja OpenAI i jej system sztucznej inteligencji ChatGPT świętują kolejny sukces. System został sprawdzany pod kątem możliwości zdawania egzamin&oacute;w i zaliczył oba testy, jeden nawet z bardzo przyzwoitym wynikiem.

Wspierany przez...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/chatgpt_zaliczyl_egzaminy_mba_i_lekarski_openai_nie_przestaje_zaskakiwac-25524.html">https://ithardware.pl/aktualnosci/chatgpt_zaliczyl_egzaminy_mba_i_lekarski_openai_nie_przestaje_zaskakiwac-25524.html</a></p>

## Tak wygląda pierwszy tablet od OnePlus
 - [https://ithardware.pl/aktualnosci/tak_wyglada_pierwszy_tablet_od_oneplus-25523.html](https://ithardware.pl/aktualnosci/tak_wyglada_pierwszy_tablet_od_oneplus-25523.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 18:34:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25523_1.jpg" />            Do premiery pierwszego tabletu w ofercie chińskiej marki OnePlus zostały niespełna 2 tygodnie. Do sieci trafiły już rendery prezentujące wygląd nadchodzącego urządzenia. Co więcej, na indyjskiej stronie firmy opublikowano&nbsp;zapowiedź...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tak_wyglada_pierwszy_tablet_od_oneplus-25523.html">https://ithardware.pl/aktualnosci/tak_wyglada_pierwszy_tablet_od_oneplus-25523.html</a></p>

## Firma SiFive połączyła siły z Intelem, aby wypuścić nową płytę wyposażoną w procesor RISC-V
 - [https://ithardware.pl/aktualnosci/firma_sifive_polaczyla_sily_z_intelem_aby_wypuscic_nowa_plyte_wyposazona_w_procesor_risc_v-25520.html](https://ithardware.pl/aktualnosci/firma_sifive_polaczyla_sily_z_intelem_aby_wypuscic_nowa_plyte_wyposazona_w_procesor_risc_v-25520.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 17:12:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25520_1.jpg" />            Firma produkująca chipy w architekturze RISC-V, SiFive, wsp&oacute;łpracuje z Intelem nad płytą o nazwie HiFive Pro P550. Konstrukcja będzie wyposażona w 4-rdzeniowy procesor &quot;Horse Creek&quot;. Płyta jest produkowana w procesie Intel 4 i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/firma_sifive_polaczyla_sily_z_intelem_aby_wypuscic_nowa_plyte_wyposazona_w_procesor_risc_v-25520.html">https://ithardware.pl/aktualnosci/firma_sifive_polaczyla_sily_z_intelem_aby_wypuscic_nowa_plyte_wyposazona_w_procesor_risc_v-25520.html</a></p>

## Mac mini z chipem M2 oferuje prawie dwukrotnie wyższą wydajność od Maca Pro za ułamek jego ceny
 - [https://ithardware.pl/aktualnosci/mac_mini_z_chipem_m2_oferuje_prawie_dwukrotnie_wyzsza_wydajnosc_od_maca_pro_za_ulamek_jego_ceny-25519.html](https://ithardware.pl/aktualnosci/mac_mini_z_chipem_m2_oferuje_prawie_dwukrotnie_wyzsza_wydajnosc_od_maca_pro_za_ulamek_jego_ceny-25519.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 16:16:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25519_1.jpg" />            Komputer Mac Pro stał się chyba najmniej opłacalnym urządzeniem w ofercie Apple. Nowe wyniki test&oacute;w pokazują, że świeżo zaprezentowany Mac mini z chipem M2 osiąga prawie dwukrotnie wyższą wydajność jednordzeniową, oferując...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mac_mini_z_chipem_m2_oferuje_prawie_dwukrotnie_wyzsza_wydajnosc_od_maca_pro_za_ulamek_jego_ceny-25519.html">https://ithardware.pl/aktualnosci/mac_mini_z_chipem_m2_oferuje_prawie_dwukrotnie_wyzsza_wydajnosc_od_maca_pro_za_ulamek_jego_ceny-25519.html</a></p>

## Telefon Coca-Coli jest prawdziwy i wkrótce zostanie wprowadzony na rynek
 - [https://ithardware.pl/aktualnosci/telefon_coca_coli_jest_prawdziwy_i_wkrotce_zostanie_wprowadzony_na_rynek-25521.html](https://ithardware.pl/aktualnosci/telefon_coca_coli_jest_prawdziwy_i_wkrotce_zostanie_wprowadzony_na_rynek-25521.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 15:26:40+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25521_1.jpg" />            Wszystko wskazuje na to, że telefon Coca-Coli wkr&oacute;tce trafi do sprzedaży. Firma podobno potwierdziła wiarygodnemu informatorowi wprowadzenie urządzenia&nbsp;sygnowanego swoim logo.

&nbsp;Podobno telefon Coca-Coli trafi do sprzedaży w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/telefon_coca_coli_jest_prawdziwy_i_wkrotce_zostanie_wprowadzony_na_rynek-25521.html">https://ithardware.pl/aktualnosci/telefon_coca_coli_jest_prawdziwy_i_wkrotce_zostanie_wprowadzony_na_rynek-25521.html</a></p>

## Najlepsze routery 2022 - TOP 10
 - [https://ithardware.pl/rankingi/najlepsze_routery_2022_top_10-25517.html](https://ithardware.pl/rankingi/najlepsze_routery_2022_top_10-25517.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 14:47:30+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25517_1.jpg" />            Routery to sprzęt często lekceważony przez użytkownik&oacute;w, kt&oacute;rzy przeważnie zadowalają się tym, co oferuje dostawca usług internetowych. P&oacute;źniej jednak zaczynają się narzekania na zrywanie połączenia, zbyt słaby sygnał...
            <p>Pełna wersja strony <a href="https://ithardware.pl/rankingi/najlepsze_routery_2022_top_10-25517.html">https://ithardware.pl/rankingi/najlepsze_routery_2022_top_10-25517.html</a></p>

## Mercusys Halo H80X – domowy system mesh z Wi-Fi 6
 - [https://ithardware.pl/aktualnosci/mercusys_halo_h80x_domowy_system_mesh_z_wi_fi_6-25518.html](https://ithardware.pl/aktualnosci/mercusys_halo_h80x_domowy_system_mesh_z_wi_fi_6-25518.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 14:00:00+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25518_1.jpg" />            Mercusys Halo H80X to nowy domowy system mesh z Wi-Fi 6, kt&oacute;ry debiutuje w sklepach. Jest sprzedawany w pakiecie z dwiema lub trzema jednostkami i zapewni wsparcie dla dom&oacute;w jednorodzinnych oraz mieszkań.

Sprzęt Mercusys z serii Halo...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mercusys_halo_h80x_domowy_system_mesh_z_wi_fi_6-25518.html">https://ithardware.pl/aktualnosci/mercusys_halo_h80x_domowy_system_mesh_z_wi_fi_6-25518.html</a></p>

## Zhakowanie serwerów LastPass niesie poważniejsze skutki niż przypuszczano
 - [https://ithardware.pl/aktualnosci/zhhakowanie_serwerow_lastpass_niesie_powazniejsze_skutki_niz_przypuszczano-25512.html](https://ithardware.pl/aktualnosci/zhhakowanie_serwerow_lastpass_niesie_powazniejsze_skutki_niz_przypuszczano-25512.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 12:08:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25512_1.jpg" />            Po zhakowaniu LastPass nieznani hakerzy byli w stanie włamać się na serwery innych usług oferowanych przez firmę macierzystą LastPass, GoTo. Nowa wiadomość od dyrektora generalnego wyjaśnia prawdziwy zakres incydentu, ale nie oferuje klientom...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/zhhakowanie_serwerow_lastpass_niesie_powazniejsze_skutki_niz_przypuszczano-25512.html">https://ithardware.pl/aktualnosci/zhhakowanie_serwerow_lastpass_niesie_powazniejsze_skutki_niz_przypuszczano-25512.html</a></p>

## Przewodniczący Intela rezygnuje na moment przed ogłoszeniem wyników finansowych
 - [https://ithardware.pl/aktualnosci/przewodniczacy_intela_rezygnuje_na_moment_przed_ogloszeniem_wynikow_finansowych-25511.html](https://ithardware.pl/aktualnosci/przewodniczacy_intela_rezygnuje_na_moment_przed_ogloszeniem_wynikow_finansowych-25511.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 11:25:02+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25511_1.jpg" />            Przewodniczący rady dyrektor&oacute;w Intela, Omar Ishrak, ustępuje ze stanowiska na kilka dni przed tym, jak producent procesor&oacute;w ma ogłosić swoje wyniki za czwarty kwartał.

Ishrak objął dotychczasowe stanowisko w 2020 roku, czyli...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/przewodniczacy_intela_rezygnuje_na_moment_przed_ogloszeniem_wynikow_finansowych-25511.html">https://ithardware.pl/aktualnosci/przewodniczacy_intela_rezygnuje_na_moment_przed_ogloszeniem_wynikow_finansowych-25511.html</a></p>

## Najlepsze obudowy komputerowe 2022. Ranking TOP 10
 - [https://ithardware.pl/rankingi/najlepsze_obudowy_komputerowe_2022_ranking_top_10-25473.html](https://ithardware.pl/rankingi/najlepsze_obudowy_komputerowe_2022_ranking_top_10-25473.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 11:06:30+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25473_1.jpg" />            Obudowa komputerowa to często pomijany element podczas składania nowego komputera. Jasne, można wszystkie komponenty wrzucić nawet do kartonowego pudła, a następnie umieścić pod biurkiem, ale przez ostatnie kilka lat element ten nie pełni...
            <p>Pełna wersja strony <a href="https://ithardware.pl/rankingi/najlepsze_obudowy_komputerowe_2022_ranking_top_10-25473.html">https://ithardware.pl/rankingi/najlepsze_obudowy_komputerowe_2022_ranking_top_10-25473.html</a></p>

## Wyniki finansowe Tesli: Kolejne rekordy wcale nie wyglądają na zwiastowane problemy...
 - [https://ithardware.pl/aktualnosci/wyniki_finansowe_tesli_kolejne_rekordy_wcale_nie_wygladaja_na_zwiastowane_problemy-25516.html](https://ithardware.pl/aktualnosci/wyniki_finansowe_tesli_kolejne_rekordy_wcale_nie_wygladaja_na_zwiastowane_problemy-25516.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 10:52:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25516_1.jpg" />            Tesla opublikowała swoje wyniki finansowe i chyba nikogo nie zaskoczy, że wbrew szeroko zapowiadanym problemom firmy, padł kolejny rekord przychod&oacute;w i zysk&oacute;w.

Wydarzenia ostatnich tygodni mogły wyglądać nieco myląco, a...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wyniki_finansowe_tesli_kolejne_rekordy_wcale_nie_wygladaja_na_zwiastowane_problemy-25516.html">https://ithardware.pl/aktualnosci/wyniki_finansowe_tesli_kolejne_rekordy_wcale_nie_wygladaja_na_zwiastowane_problemy-25516.html</a></p>

## Wielki powrót Intela do segmentu HEDT? Xeon W9-3495X zmierzy się z nowymi Threadripperami
 - [https://ithardware.pl/aktualnosci/wielki_powrot_intela_do_segmentu_hedt_xeon_w9_3495x_zmierzy_sie_z_nowymi_threadripperami-25510.html](https://ithardware.pl/aktualnosci/wielki_powrot_intela_do_segmentu_hedt_xeon_w9_3495x_zmierzy_sie_z_nowymi_threadripperami-25510.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 10:35:01+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25510_1.jpg" />            Intel ma wprowadzić na rynek swoje procesory z serii Xeon W-2400 i Xeon W-3400 dla high-endowych komputer&oacute;w stacjonarnych i stacji roboczych 15 lutego. Jak to zwykle bywa, nadchodzący flagowy procesor HEDT od Intela &mdash; 56-rdzeniowy Xeon...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wielki_powrot_intela_do_segmentu_hedt_xeon_w9_3495x_zmierzy_sie_z_nowymi_threadripperami-25510.html">https://ithardware.pl/aktualnosci/wielki_powrot_intela_do_segmentu_hedt_xeon_w9_3495x_zmierzy_sie_z_nowymi_threadripperami-25510.html</a></p>

## Kary za "dezinformację" COVID-19 to "nonsens". Sąd blokuje nowe przepisy
 - [https://ithardware.pl/aktualnosci/kary_za_dezinformacje_covid_19_to_nonsens_sad_blokuje_nowe_przepisy-25515.html](https://ithardware.pl/aktualnosci/kary_za_dezinformacje_covid_19_to_nonsens_sad_blokuje_nowe_przepisy-25515.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 10:08:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25515_1.jpg" />            Sędzia federalny zakwestionował nowe prawo&nbsp;kalifornijskie, kt&oacute;re karze lekarzy za dzielenie się &bdquo;dezinformacją&rdquo; dotyczącą COVID-19.

Nowe prawo, kt&oacute;re weszło w życie 1 stycznia tego roku, zabrania lekarzom...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kary_za_dezinformacje_covid_19_to_nonsens_sad_blokuje_nowe_przepisy-25515.html">https://ithardware.pl/aktualnosci/kary_za_dezinformacje_covid_19_to_nonsens_sad_blokuje_nowe_przepisy-25515.html</a></p>

## DirectStorage ma negatywny wpłw na wydajność gier. 10% spadek liczby fpsów na RTX 4090
 - [https://ithardware.pl/aktualnosci/directstorage_ma_negatywny_wplw_na_wydajnosc_gier_10_spadek_liczby_fpsow_na_rtx_4090-25509.html](https://ithardware.pl/aktualnosci/directstorage_ma_negatywny_wplw_na_wydajnosc_gier_10_spadek_liczby_fpsow_na_rtx_4090-25509.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 10:06:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25509_1.jpg" />            DirectStorage od Microsoftu zapewnia błyskawiczne czasy ładowania gier. Okazuje się jednak, że przynosi nie tylko same korzyści, bo według najnowszego testu przeprowadzonego przez niemiecki portal PC Games Hardware, technologia może powodować...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/directstorage_ma_negatywny_wplw_na_wydajnosc_gier_10_spadek_liczby_fpsow_na_rtx_4090-25509.html">https://ithardware.pl/aktualnosci/directstorage_ma_negatywny_wplw_na_wydajnosc_gier_10_spadek_liczby_fpsow_na_rtx_4090-25509.html</a></p>

## Poco X5 i X5 Pro nadchodzą. Mocni zawodnicy wagi średniej
 - [https://ithardware.pl/aktualnosci/poco_x5_i_x5_pro_nadchodza_mocni_zawodnicy_wagi_sredniej-25508.html](https://ithardware.pl/aktualnosci/poco_x5_i_x5_pro_nadchodza_mocni_zawodnicy_wagi_sredniej-25508.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 08:47:20+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25508_1.jpg" />            Jakiś czas temu nadchodzący Poco X5 został zauważony w rękach gwiazdy krykieta, ale wygląda na to, że otrzymamy też wariant Pro. Europejski sklep umieścił taki telefon w swojej ofercie, oznaczając jego premierę jako...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/poco_x5_i_x5_pro_nadchodza_mocni_zawodnicy_wagi_sredniej-25508.html">https://ithardware.pl/aktualnosci/poco_x5_i_x5_pro_nadchodza_mocni_zawodnicy_wagi_sredniej-25508.html</a></p>

## Ten oczyszczacz powietrza sam jeździ po domu. Oto Ecovacs Airbot Z1
 - [https://ithardware.pl/aktualnosci/ten_oczyszczacz_powietrza_sam_jezdzi_po_domu-25514.html](https://ithardware.pl/aktualnosci/ten_oczyszczacz_powietrza_sam_jezdzi_po_domu-25514.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 08:44:10+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25514_1.jpg" />            Ecovas Robotics przedstawia Airbota Z1, swoją nowość klasy premium. Nie dość, że ten robot samodzielnie jeździ po domu, oczyszczając powietrze m.in. dzięki zaawansowanemu filtrowi HEPA H13, to jeszcze potrafi w tym czasie umilić czas muzyką,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ten_oczyszczacz_powietrza_sam_jezdzi_po_domu-25514.html">https://ithardware.pl/aktualnosci/ten_oczyszczacz_powietrza_sam_jezdzi_po_domu-25514.html</a></p>

## Facebook przywraca konto Donalda Trumpa. Ban trwał 2 lata
 - [https://ithardware.pl/aktualnosci/facebook_przywraca_konto_donalda_trumpa_ban_trwal_2_lata-25513.html](https://ithardware.pl/aktualnosci/facebook_przywraca_konto_donalda_trumpa_ban_trwal_2_lata-25513.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 08:25:43+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25513_1.jpg" />            Meta&nbsp;ogłosiła decyzję o przywr&oacute;ceniu&nbsp;kont na&nbsp;Facebooku&nbsp;i&nbsp;Instagramie byłego prezydenta Donalda Trumpa. Jego konta na obu platformach zostały zawieszone na czas nieokreślony po zamieszkach na Kapitolu Stan&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/facebook_przywraca_konto_donalda_trumpa_ban_trwal_2_lata-25513.html">https://ithardware.pl/aktualnosci/facebook_przywraca_konto_donalda_trumpa_ban_trwal_2_lata-25513.html</a></p>

## Redfall - polowanie na wampiry wystartuje za kilka miesięcy
 - [https://ithardware.pl/aktualnosci/redfall_polowanie_na_wampiry_wystartuje_za_kilka_miesiecy-25507.html](https://ithardware.pl/aktualnosci/redfall_polowanie_na_wampiry_wystartuje_za_kilka_miesiecy-25507.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 07:23:37+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25507_1.jpg" />            Xbox Developer_Direct pozowliło nam przyjrzeć się rozgrywce w Redfall, pokazując, jak będzie prezentować się nowy otwarty świat w grze Arkane, a przy okazji poznaliśmy datę premiery.

Pomimo kilkumiesięcznego op&oacute;źnienia, kolejna...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/redfall_polowanie_na_wampiry_wystartuje_za_kilka_miesiecy-25507.html">https://ithardware.pl/aktualnosci/redfall_polowanie_na_wampiry_wystartuje_za_kilka_miesiecy-25507.html</a></p>

## Nowa Forza Motorsport przyniesie 500 aut i rozgrywkę 4K w 60 kl./s z ray tracingiem
 - [https://ithardware.pl/aktualnosci/nowa_forza_motorsport_przyniesie_500_aut_i_rozgrywke_4k_w_60_kl_s_z_ray_tracingiem-25506.html](https://ithardware.pl/aktualnosci/nowa_forza_motorsport_przyniesie_500_aut_i_rozgrywke_4k_w_60_kl_s_z_ray_tracingiem-25506.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-01-26 07:08:09+00:00
 - user: None

<img src="https://ithardware.pl/artykuly/min/25506_1.jpg" />            Wczorajsza prezentacja Xbox Developer_Direct przyniosła nam m.in. nową prezentację najnowszej odsłony symulacyjnej serii wyścigowej Microsoftu, czyli Forza Motorsport. Ta po dłużej przerwie przynieść ma sporo nowości.&nbsp;

Od dłuższego...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nowa_forza_motorsport_przyniesie_500_aut_i_rozgrywke_4k_w_60_kl_s_z_ray_tracingiem-25506.html">https://ithardware.pl/aktualnosci/nowa_forza_motorsport_przyniesie_500_aut_i_rozgrywke_4k_w_60_kl_s_z_ray_tracingiem-25506.html</a></p>
