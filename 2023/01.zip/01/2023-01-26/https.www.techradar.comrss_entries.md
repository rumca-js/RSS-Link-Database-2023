# Source Techradar, Source URL:https://www.techradar.com/rss, Source language: en-US

## Your apps and Windows devices could be facing a whole new kind of threat
 - [https://www.techradar.com/news/your-apps-and-windows-devices-could-be-facing-a-whole-new-kind-of-threat](https://www.techradar.com/news/your-apps-and-windows-devices-could-be-facing-a-whole-new-kind-of-threat)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 22:22:41+00:00
 - user: None

What if fake apps aren't recognized as such - but rather as legitimate products?

## League of Legends source code auctioned off by hackers
 - [https://www.techradar.com/news/league-of-legends-source-code-auctioned-off-by-hackers](https://www.techradar.com/news/league-of-legends-source-code-auctioned-off-by-hackers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 22:03:24+00:00
 - user: None

Seven-figure sum sought in exchange for LoL and Packman source codes.

## Samsung morphs the Odyssey Neo G7 into its first flatscreen mini-LED display
 - [https://www.techradar.com/news/samsung-morphs-the-odyssey-neo-g7-into-its-first-flatscreen-mini-led-display](https://www.techradar.com/news/samsung-morphs-the-odyssey-neo-g7-into-its-first-flatscreen-mini-led-display)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 21:34:57+00:00
 - user: None

Similar to the original model, the new 43-inch Samsung Odyssey Neo G7 sports 4K resolutions but also addresses glare.

## Microsoft is making a big push into solar energy
 - [https://www.techradar.com/news/microsoft-is-making-a-big-push-into-solar-energy](https://www.techradar.com/news/microsoft-is-making-a-big-push-into-solar-energy)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 19:53:25+00:00
 - user: None

Plans to be powered by renewable energy by 2030 have seen Microsoft go in big on solar energy.

## Razer Edge gaming handheld finally launches in both 5G and WiFi flavors
 - [https://www.techradar.com/news/razer-edge-gaming-handheld-finally-launches-in-both-5g-and-wifi-flavors](https://www.techradar.com/news/razer-edge-gaming-handheld-finally-launches-in-both-5g-and-wifi-flavors)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 18:09:23+00:00
 - user: None

Razer released its Steam Deck competitor, the Razer Edge, and it comes in both WiFi and 5G versions.

## The Marvel movies timeline is about get much easier to follow
 - [https://www.techradar.com/news/the-marvel-movies-timeline-is-about-get-much-easier-to-follow](https://www.techradar.com/news/the-marvel-movies-timeline-is-about-get-much-easier-to-follow)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 17:46:36+00:00
 - user: None

A new Marvel Studios book will finally shed light on where each film and TV show fits on the complicated MCU timeline.

## Kinsta and Liquid Web branded the most reliable hosts as WordPress turns 20
 - [https://www.techradar.com/news/kinsta-and-liquid-web-branded-the-most-reliable-hosts-as-wordpress-turns-20](https://www.techradar.com/news/kinsta-and-liquid-web-branded-the-most-reliable-hosts-as-wordpress-turns-20)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 17:37:42+00:00
 - user: None

Just in time for WordPress' 20th anniversary, StatusGator names the top seven most reliable WordPress hosting services.

## Top stock photo site gets AI image generator
 - [https://www.techradar.com/news/top-stock-photo-site-gets-ai-image-generator](https://www.techradar.com/news/top-stock-photo-site-gets-ai-image-generator)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 17:22:56+00:00
 - user: None

Shutterstock launches new OpenAI-powered AI image generator.

## You can now see exactly when you were mentioned in a Microsoft Teams call
 - [https://www.techradar.com/news/you-can-now-see-exactly-when-you-were-mentioned-in-a-microsoft-teams-call](https://www.techradar.com/news/you-can-now-see-exactly-when-you-were-mentioned-in-a-microsoft-teams-call)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 17:02:51+00:00
 - user: None

If your ears are burning, Microsoft Teams can show you why.

## Why now might be the best time to switch password managers
 - [https://www.techradar.com/news/why-now-might-be-the-best-time-to-switch-password-managers](https://www.techradar.com/news/why-now-might-be-the-best-time-to-switch-password-managers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 16:36:18+00:00
 - user: None

If you're looking for a change in security supplier, now could be a great time for a refresh.

## The new Minecraft game absolutely nails what's special about the original
 - [https://www.techradar.com/news/the-new-minecraft-game-absolutely-nails-whats-special-about-the-original](https://www.techradar.com/news/the-new-minecraft-game-absolutely-nails-whats-special-about-the-original)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 16:34:39+00:00
 - user: None

Mojang has come out swinging with a new PvP mode for Minecraft Legends, and it looks to be the best of both worlds.

## This Mass Effect 3 mod readds cut content to add new emotional gut punches
 - [https://www.techradar.com/news/this-mass-effect-3-mod-readds-cut-content-to-add-new-emotional-gut-punches](https://www.techradar.com/news/this-mass-effect-3-mod-readds-cut-content-to-add-new-emotional-gut-punches)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 16:23:10+00:00
 - user: None

Two modders have released an unofficial patch for Mass Effect 3 which adds all sorts of extra goodies to the sci-fi RPG.

## Yamaha's new wireless earbuds bring aptX Adaptive Hi-Res sound for cheap
 - [https://www.techradar.com/news/yamahas-new-wireless-earbuds-bring-aptx-adaptive-hi-res-sound-for-cheap](https://www.techradar.com/news/yamahas-new-wireless-earbuds-bring-aptx-adaptive-hi-res-sound-for-cheap)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 16:18:15+00:00
 - user: None

Yamaha's new TW-E3C wireless earbuds will use the brand's expertise and aptX Adaptive Hi-Res sound to deliver a great performance.

## The Samsung Galaxy S23 could be the toughest mainstream phone yet
 - [https://www.techradar.com/news/the-samsung-galaxy-s23-could-be-the-toughest-mainstream-phone-yet](https://www.techradar.com/news/the-samsung-galaxy-s23-could-be-the-toughest-mainstream-phone-yet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 16:15:55+00:00
 - user: None

Corning has confirmed that the next flagship Samsung phones will be the first to use Gorilla Glass Victus 2.

## PlayStation Plus may start adding a brilliant feature to its games
 - [https://www.techradar.com/news/playstation-plus-may-start-adding-a-brilliant-feature-to-its-games](https://www.techradar.com/news/playstation-plus-may-start-adding-a-brilliant-feature-to-its-games)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:57:10+00:00
 - user: None

Sony could add a new feature to retro PlayStation Plus games thanks to Super Stardust Portable.

## New cyberattacks are being launched every minute
 - [https://www.techradar.com/news/new-cyberattacks-are-being-launched-every-minute](https://www.techradar.com/news/new-cyberattacks-are-being-launched-every-minute)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:56:28+00:00
 - user: None

BlackBerry report claims the US and Windows users are most targeted - but macOS users are not immune.

## GoldenEye 007 comes to Nintendo Switch with game-changing new mode
 - [https://www.techradar.com/news/goldeneye-007-comes-to-nintendo-switch-with-game-changing-new-mode](https://www.techradar.com/news/goldeneye-007-comes-to-nintendo-switch-with-game-changing-new-mode)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:55:23+00:00
 - user: None

Iconic Nintendo 64 title GoldenEye 007 is about to get a new life on Nintendo Switch, complete with a brand new feature.

## We now know why the DualSense Edge's battery life is so poor
 - [https://www.techradar.com/news/we-now-know-why-the-dualsense-edges-battery-life-is-so-poor](https://www.techradar.com/news/we-now-know-why-the-dualsense-edges-battery-life-is-so-poor)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:52:03+00:00
 - user: None

A teardown of the DualSense Edge has shown exactly why its battery life is worse off than its base model counterpart.

## Netflix's streaming dominance laid bare in fascinating new data
 - [https://www.techradar.com/news/netflixs-streaming-dominance-laid-bare-in-fascinating-new-data](https://www.techradar.com/news/netflixs-streaming-dominance-laid-bare-in-fascinating-new-data)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:37:57+00:00
 - user: None

Despite a turbulent 2022, Netflix continues to reign supreme, according to the latest data.

## Thanks to the PS5 controller, you really feel the dismemberment in Dead Space
 - [https://www.techradar.com/news/thanks-to-the-ps5-controller-you-really-feel-the-dismemberment-in-dead-space](https://www.techradar.com/news/thanks-to-the-ps5-controller-you-really-feel-the-dismemberment-in-dead-space)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:22:48+00:00
 - user: None

The Dead Space remake is right around the corner, and Sony has detailed how the game uses the PS5 hardware.

## These Russian and Iranian hackers are fooling vital industries
 - [https://www.techradar.com/news/these-russian-and-iranian-hackers-are-fooling-vital-industries](https://www.techradar.com/news/these-russian-and-iranian-hackers-are-fooling-vital-industries)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:15:29+00:00
 - user: None

National Cyber Security Centre details the very devious tactics used to compromise high-level targets.

## US government agencies are falling victim to some very obvious attacks
 - [https://www.techradar.com/news/us-government-agencies-are-falling-victim-to-some-very-obvious-attacks](https://www.techradar.com/news/us-government-agencies-are-falling-victim-to-some-very-obvious-attacks)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 15:02:23+00:00
 - user: None

Crooks are using legitimate software to steal money from US government agencies and employees.

## Apple slashes iPhone trade-in prices – here's where to sell your phone instead
 - [https://www.techradar.com/news/apple-just-slashed-its-iphone-trade-in-prices-sell-your-phone-here-instead](https://www.techradar.com/news/apple-just-slashed-its-iphone-trade-in-prices-sell-your-phone-here-instead)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 14:25:58+00:00
 - user: None

Apple has just cut the trade-in prices on many of its iPhones – here's where to sell your old phone instead.

## OpenCore lets you install macOS Ventura on unsupported Macs - but please don't
 - [https://www.techradar.com/news/opencore-lets-you-install-macos-ventura-on-unsupported-macs-but-please-dont](https://www.techradar.com/news/opencore-lets-you-install-macos-ventura-on-unsupported-macs-but-please-dont)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 14:21:32+00:00
 - user: None

If you've been wanting to try out Ventura on a 2013 Mac Pro, here's your chance - but is there a point?

## Delaying this multiplayer take on The Last of Us is a good thing
 - [https://www.techradar.com/news/delaying-this-multiplayer-take-on-the-last-of-us-is-a-good-thing](https://www.techradar.com/news/delaying-this-multiplayer-take-on-the-last-of-us-is-a-good-thing)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 14:20:25+00:00
 - user: None

After complications with copyrighting, The Day Before has been delayed until the end of the year.

## Flexible working is now more important than holidays for new jobseekers
 - [https://www.techradar.com/news/flexible-working-is-now-more-important-than-holidays-for-new-jobseekers](https://www.techradar.com/news/flexible-working-is-now-more-important-than-holidays-for-new-jobseekers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 14:04:36+00:00
 - user: None

Flexibility is of growing interest to workers in Europe, but not all countries are catching up quite so fast.

## Exclusive: here’s your first look at the OnePlus Pad, launching alongside the OnePlus 11
 - [https://www.techradar.com/news/exclusive-oneplus-pad-first-official-image](https://www.techradar.com/news/exclusive-oneplus-pad-first-official-image)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 14:00:12+00:00
 - user: None

OnePlus has given us the first glimpse of the OnePlus Pad, in a stunning green shade.

## It looks like Samsung’s first 77-inch OLED TV will beat LG in one way: a high price
 - [https://www.techradar.com/news/it-looks-like-samsungs-first-77-inch-oled-tv-will-beat-lg-in-one-way-a-high-price](https://www.techradar.com/news/it-looks-like-samsungs-first-77-inch-oled-tv-will-beat-lg-in-one-way-a-high-price)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 13:09:44+00:00
 - user: None

The 77-inch Samsung S95C OLED has had its price leaked, and it'll cost more than LG's best 77-inch TV from 2022.

## Now it's IBM's turn to announce major job cuts
 - [https://www.techradar.com/news/now-its-ibms-turn-to-announce-major-job-cuts](https://www.techradar.com/news/now-its-ibms-turn-to-announce-major-job-cuts)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 13:02:12+00:00
 - user: None

IBM announcement will see 3,900 workers losing their jobs.

## The iPhone 15 Ultra could have better cameras and more power than the Pro
 - [https://www.techradar.com/news/the-iphone-15-ultra-could-have-better-cameras-and-more-power-than-the-pro](https://www.techradar.com/news/the-iphone-15-ultra-could-have-better-cameras-and-more-power-than-the-pro)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 12:10:55+00:00
 - user: None

Leaked iOS 17 code holds hints to what we might see in the iPhone 15 series.

## Microsoft just rolled out its most secure Microsoft 365 version yet
 - [https://www.techradar.com/news/microsoft-just-rolled-out-its-most-secure-microsoft-365-version-yet](https://www.techradar.com/news/microsoft-just-rolled-out-its-most-secure-microsoft-365-version-yet)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 11:52:56+00:00
 - user: None

With Office 365 Government Secret Cloud, Uncle Sam might be collecting your data, but at least he’s keeping it under lock and key.

## This official Samsung Galaxy S23 pre-order deal makes the phones more affordable
 - [https://www.techradar.com/news/this-official-samsung-galaxy-s23-pre-order-deal-makes-the-phones-more-affordable](https://www.techradar.com/news/this-official-samsung-galaxy-s23-pre-order-deal-makes-the-phones-more-affordable)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 11:02:44+00:00
 - user: None

Samsung has revealed that UK buyers will get a free storage upgrade if they pre-order a Galaxy S23, S23 Plus or S23 Ultra.

## HBO Max is stealthily removing The Dark Knight Trilogy soon
 - [https://www.techradar.com/news/hbo-max-is-stealthily-removing-the-dark-knight-trilogy-soon](https://www.techradar.com/news/hbo-max-is-stealthily-removing-the-dark-knight-trilogy-soon)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 10:49:40+00:00
 - user: None

HBO Max's superhero catalog is getting a major downgrade over the coming weeks.

## This new Python malware is going after Windows machines
 - [https://www.techradar.com/news/this-new-python-malware-is-going-after-windows-machines](https://www.techradar.com/news/this-new-python-malware-is-going-after-windows-machines)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 10:49:08+00:00
 - user: None

Dangerous malware is stealing data and logging keystrokes, and researchers still don't know who is behind it.

## The most spoofed company over the last few months is a major blast from the past
 - [https://www.techradar.com/news/the-most-spoofed-company-over-the-last-few-months-is-a-major-blast-from-the-past](https://www.techradar.com/news/the-most-spoofed-company-over-the-last-few-months-is-a-major-blast-from-the-past)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 10:06:12+00:00
 - user: None

Holiday season was lucrative for fraudsters sending out phishing emails, experts warn.

## The best Dolby Atmos Xbox Series X games: hear the difference
 - [https://www.techradar.com/news/hear-the-difference-the-best-dolby-atmos-xbox-series-x-games](https://www.techradar.com/news/hear-the-difference-the-best-dolby-atmos-xbox-series-x-games)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-01-26 09:50:54+00:00
 - user: None

Here's the best Dolby Atmos Xbox Series X games that take full advantage of the spatial audio technology.
