# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Scholz zapowiada: Musimy deportować więcej i szybciej
 - [https://wydarzenia.interia.pl/zagranica/news-scholz-zapowiada-musimy-deportowac-wiecej-i-szybciej,nId,7099891](https://wydarzenia.interia.pl/zagranica/news-scholz-zapowiada-musimy-deportowac-wiecej-i-szybciej,nId,7099891)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-10-20T18:39:47+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-scholz-zapowiada-musimy-deportowac-wiecej-i-szybciej,nId,7099891"><img align="left" alt="Scholz zapowiada: Musimy deportować więcej i szybciej" src="https://i.iplsc.com/scholz-zapowiada-musimy-deportowac-wiecej-i-szybciej/000HUGLSSI6C7Y8B-C321.jpg" /></a>Musimy deportować więcej i szybciej - powiedział kanclerz Olaf Scholz, komentując wzmożoną, nielegalną migrację do Niemiec. Zdaniem szefa rządu jego państwo musi pozostać &quot;otwarte i nowoczesne&quot;, ale Berlin ma &quot;prawo określać, kogo chcemy przyjąć&quot;, dlatego &quot;trzeba mieć siłę powiedzieć ludziom, że niestety nie mogą tu zostać&quot;. Scholz odniósł się również do antysemickich demonstracji i incydentów w Niemczech. &quot;Zrobimy wszystko, by chronić żydowskie życie&quot; - oświadczył kanclerz.</p><br clear="all" />

## Mieli dostęp do tajnych danych. Szwedzki oficer i jego żona zatrzymani
 - [https://wydarzenia.interia.pl/zagranica/news-mieli-dostep-do-tajnych-danych-szwedzki-oficer-i-jego-zona-z,nId,7099072](https://wydarzenia.interia.pl/zagranica/news-mieli-dostep-do-tajnych-danych-szwedzki-oficer-i-jego-zona-z,nId,7099072)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-10-20T11:39:07+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mieli-dostep-do-tajnych-danych-szwedzki-oficer-i-jego-zona-z,nId,7099072"><img align="left" alt="Mieli dostęp do tajnych danych. Szwedzki oficer i jego żona zatrzymani" src="https://i.iplsc.com/mieli-dostep-do-tajnych-danych-szwedzki-oficer-i-jego-zona-z/000HUCKWL8EBDWJW-C321.jpg" /></a>Szwedzka służba kontrwywiadowcza zatrzymała najwyższego rangą oficera szwedzkiego wojska i jego żonę. Parze zarzuca się nieuprawnione korzystanie z utajnionych dokumentów. Media poskreślają, że &quot;sprawa owiana jest tajemnicą&quot;, ponieważ śledczy nie udostępniają na ten temat żadnych dodatkowych informacji, a podejrzani są odizolowani.</p><br clear="all" />

## Aline i Babet idą przez Europę. Pierwsze ofiary śmiertelne
 - [https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsze-ofiary-smiertelne,nId,7099167](https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsze-ofiary-smiertelne,nId,7099167)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-10-20T10:10:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsze-ofiary-smiertelne,nId,7099167"><img align="left" alt="Aline i Babet idą przez Europę. Pierwsze ofiary śmiertelne" src="https://i.iplsc.com/aline-i-babet-ida-przez-europe-pierwsze-ofiary-smiertelne/000HUC6L3RNXPRQD-C321.jpg" /></a>Dwie potężne burze - Aline i Babet - przetaczają się przez zachodnią Europę. W wielu krajach ogłoszono czerwony alarm. W części Francji zamknięto szkoły i uniwersytety. W Hiszpanii odnotowano ponad tysiąc interwencji, ulice Madrytu zostały zalane z powodu największej od ponad stu lat ulewy. W Szkocji setki ludzi trzeba było ewakuować z domów zagrożonych powodzią, stwierdzono też pierwsze śmiertelne ofiary żywiołu.</p><br clear="all" />

