# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Friday evening news briefing: Sunak doing worse than Major
 - [https://www.telegraph.co.uk/news/2023/10/20/friday-evening-news-briefing-sunak-doing-worse-than-major/](https://www.telegraph.co.uk/news/2023/10/20/friday-evening-news-briefing-sunak-doing-worse-than-major/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-20T16:37:42+00:00



## UK weather latest: Storm Babet uproots trees causing chaos on roads and railways
 - [https://www.telegraph.co.uk/news/2023/10/20/uk-weather-live-floods-storm-babet-latest/](https://www.telegraph.co.uk/news/2023/10/20/uk-weather-live-floods-storm-babet-latest/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-20T07:20:07+00:00



## Bank worker told to 'get used to feeling discomfort' because she was pregnant, tribunal hears
 - [https://www.telegraph.co.uk/news/2023/10/20/lloyds-bank-bristol-pregnant-toilet-break-compensation/](https://www.telegraph.co.uk/news/2023/10/20/lloyds-bank-bristol-pregnant-toilet-break-compensation/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-20T00:23:50+00:00



