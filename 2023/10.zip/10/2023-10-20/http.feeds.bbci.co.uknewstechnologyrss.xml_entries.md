# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Elon Musk says X to have two new premium tiers
 - [https://www.bbc.co.uk/news/technology-67167804?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67167804?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-10-20T07:51:59+00:00

The latest change to the platform will see two layers of subscriptions - one with adverts and one without.

