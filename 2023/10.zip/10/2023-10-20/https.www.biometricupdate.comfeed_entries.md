# Source:Biometric Update, URL:https://www.biometricupdate.com/feed, language:en-US

## FaceTec reveals liveness check milestone, a new state mDL, high marks in BixeLab test
 - [https://www.biometricupdate.com/202310/facetec-reveals-liveness-check-milestone-a-new-state-mdl-high-marks-in-bixelab-test](https://www.biometricupdate.com/202310/facetec-reveals-liveness-check-milestone-a-new-state-mdl-high-marks-in-bixelab-test)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T20:00:34+00:00

<img alt="passive biometric liveness" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="900" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2021/07/21110527/passive-biometric-liveness.jpg" width="1200" />
		<a href="https://www.biometricupdate.com/companies/facetec-inc">FaceTec, Inc.</a> now conducts over two billion 3D biometric liveness checks yearly, of which 475 million were performed in Q3 2023, the company has revealed in a review of s3everal new developments. With a year-over-year growth rate of 172 percent in this field, FaceTec emphasized the rising demand for biometric cybersecurity provided by liveness detection.

"Our Q3 results reflect the growing need for effective Liveness-proven biometric cybersecurity. Organizations must defend against generative AI deepfakes to prevent digital impersonation of their employees and end-users using trusted identity reverification with strong, liveness-proven biometrics," says Kevin Alan Tussy, C

## EU parliament formally adopts digital visas
 - [https://www.biometricupdate.com/202310/eu-parliament-formally-adopts-digital-visas](https://www.biometricupdate.com/202310/eu-parliament-formally-adopts-digital-visas)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T19:45:52+00:00

<img alt="smart-borders-eu-biometric-entry-exit-system" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="492" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2020/09/28125611/smart-borders-eu-biometric-entry-exit-system.jpg" width="1000" />
		Europe has made one of the final steps towards adopting digital visas for the Schengen area.

On Wednesday, the European Parliament voted to support the law on digitalization of visas, which will enable applications for Schengen visas through a single online platform. The Visa Information System (VIS) platform will require the collection of <a href="https://home-affairs.ec.europa.eu/policies/schengen-borders-and-visa/visa-information-system_en">fingerprint and face biometrics</a> for first-time applicants.

The finalization of the legislation is expected on November 12, <a href="https://www.euractiv.com/section/all/news/eu-ready-to-introduce-digitalisation-of-visa-procedures-in-the-schengen-area/">accordi

## Business group pitches BIPA reform while flow of new cases continues
 - [https://www.biometricupdate.com/202310/business-group-pitches-bipa-reform-while-flow-of-new-cases-continues](https://www.biometricupdate.com/202310/business-group-pitches-bipa-reform-while-flow-of-new-cases-continues)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T19:27:47+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1319" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/01/12153709/time-attendance-scaled.jpg" width="2048" />
		A business advocacy group is calling for a landmark biometric privacy law in the United States to be amended to limit potentially ruinous lawsuit payouts.

As the call was made came word of a two new, fairly typical, potential class actions. One was filed by a cook against his employer, a Wendy's fast-food chain in suburban Chicago and the other accuses an employee-services software firm.

The state of Illinois' Biometric Information Privacy Act, passed in 2008, requires non-government organizations to get the consent of people before collecting their biometric data and to publicize how that data is managed.

Because firms can be sued for each collection and residents have the right to sue under the law, awards can be huge. Facebook <a href="https://www.nbcnews.com/tec

## Advocates say people think of biometric identification all wrong
 - [https://www.biometricupdate.com/202310/advocates-say-people-think-of-biometric-identification-all-wrong](https://www.biometricupdate.com/202310/advocates-say-people-think-of-biometric-identification-all-wrong)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T17:52:28+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1152" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/02/14134710/facial-recogntiion-street-crowd-scaled.jpg" width="2048" />
		A digital rights organization says the popular view of biometric identification and surveillance is backward and the result is the commodification of people for government control and business profit.

<a href="https://www.accessnow.org/">Access Now</a>, which is particularly focused on the impact of AI on economically disadvantaged communities, has <a href="https://www.accessnow.org/wp-content/uploads/2023/10/Bodily-harms-mapping-the-risks-of-emerging-biometric-tech.pdf">published</a> a report with what it sees as unnecessary risks of biometrics-based tools.

Instead of viewing the tools as mere collection systems, executives with Access Now see algorithms as programmed categorizers. They impose a desired order on what is by definition a spectrum of qu

## Software in fingerprint biometric gun safe sensor fails; death prompts product recall
 - [https://www.biometricupdate.com/202310/software-in-fingerprint-biometric-gun-safe-sensor-fails-death-prompts-product-recall](https://www.biometricupdate.com/202310/software-in-fingerprint-biometric-gun-safe-sensor-fails-death-prompts-product-recall)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T17:46:27+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="631" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/10/20134505/fortress-safe.png" width="1123" />
		A biometrics-enabled personal gun safe that is implicated in the gunshot death of a child in the United States has been recalled.

Models of <a href="https://www.fortresssafe.com/home.html">Fortress Safe</a>'s keeps that use the same fingerprint-scanning software are being pulled from the market. Each vault also has a key lock.

It is possible for an adult to think the safe is locked when it is not.

The Consumer Product Safety Commission yesterday <a href="https://www.cpsc.gov/Recalls/2024/Fortress-Safe-Announces-Recall-of-Biometric-Gun-Safes-Due-to-Serious-Injury-Hazard-and-Risk-of-Death-One-Death-Reported">recalled</a> 61,000 biometric safes, pistol vaults, gun cabinets and other personal safes. They are sold under the brand names Fortress, Cabela’s, Gettysburg and Legend Ran

## Safety, privacy professionals caution against facial recognition in US schools
 - [https://www.biometricupdate.com/202310/safety-privacy-professionals-caution-against-facial-recognition-in-us-schools](https://www.biometricupdate.com/202310/safety-privacy-professionals-caution-against-facial-recognition-in-us-schools)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T17:10:47+00:00

<img alt="face-biometrics-privacy-children-large" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="729" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2021/04/02114722/3025CDA7-1DB4-4909-AEBF-E13BC58EA9D8.jpeg" width="1021" />
		As facial recognition deployments and restrictions proliferate among American schools, observers are calling for sober evaluation of claims made by biometrics vendors. There have been 33 school shootings resulting in injury or death in the U.S. so far this year, <a href="https://www.govtech.com/education/k-12/what-educators-should-know-about-facial-recognition-tech">GovTech</a> reports, but the assessment that informed <a href="https://www.biometricupdate.com/202309/facial-recognition-shut-out-of-new-york-state-schools">New York’s move</a> to ban facial recognition in state schools says facial recognition “may only offer the appearance of safer schools.”

Kenneth Trump, President of consulting firm National School Saf

## Sumsub launches a free tool to detect deepfakes and synthetic fraud
 - [https://www.biometricupdate.com/202310/sumsub-launches-a-free-tool-to-detect-deepfakes-and-synthetic-fraud](https://www.biometricupdate.com/202310/sumsub-launches-a-free-tool-to-detect-deepfakes-and-synthetic-fraud)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T17:06:12+00:00

<img alt="DHS-PII-access-management" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="854" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2018/07/03145243/DHS-PII-access-management.jpg" width="1280" />
		<a href="https://www.biometricupdate.com/companies/sumsub">Sumsub</a> has announced the release of <a href="https://huggingface.co/Sumsub">For Fake’s Sake</a>, a set of models enabling the detection of deepfakes and synthetic fraud in visual assets. It is the first solution developed by a verification provider and made available to all for free. For Fake's Sake helps users estimate how likely it is that an uploaded image was created artificially.

Sumsub’s AI/ML Research Lab developed For Fake’s Sake—a set of four distinct machine learning-driven models for deepfake and synthetic fraud detection. This release presents an experimental technical strategy to help people responsibly engage with AI-generated content. This tool also has the potenti

## Will the EUDI Wallet go global? Experts discuss standardization
 - [https://www.biometricupdate.com/202310/will-the-eudi-wallet-go-global-experts-discuss-standardization](https://www.biometricupdate.com/202310/will-the-eudi-wallet-go-global-experts-discuss-standardization)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T16:25:12+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="600" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2021/12/16150546/digital-services-for-citizens.jpg" width="1440" />
		As Europe prepares to launch its European Digital Identity (<a href="https://www.biometricupdate.com/tag/eu-digital-identity-wallet">EUDI</a>) Wallet, its creators have been busy building up foundational frameworks and standards. The task is even more important as the wallet has ambitions beyond the continent: Standardization organizations are working on making the EUDI accepted even across the European Union’s border.

The EUDI will allow each European citizen to access public and private digital services with a tap on their mobile phones. In July, the project <a href="https://www.biometricupdate.com/202307/eudi-wallet-is-kicking-off-its-pilots">kicked off four pilots</a> involving more than 250 private and public organizations across Europe. The European Commis

## Texas university launching large synthetic face biometrics training dataset
 - [https://www.biometricupdate.com/202310/texas-university-launching-large-synthetic-face-biometrics-training-dataset](https://www.biometricupdate.com/202310/texas-university-launching-large-synthetic-face-biometrics-training-dataset)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T15:58:40+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1027" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2022/08/25131017/face-photos-dataset-scaled.jpg" width="2048" />
		Using synthetic data instead of real people's faces to train facial recognition systems has been <a href="https://www.biometricupdate.com/202309/use-of-synthetic-data-for-training-biometric-systems-on-the-rise">gaining ground</a> among biometrics companies around the world. A university in Dallas, Texas now wants to create one of the largest balanced synthetic databases for facial recognition.

The Southern Methodist University (SMU) plans to generate a database of facial images from text descriptions with a high-performance computing platform specifically designed for AI called the Nvidia DGX SuperPOD. The goal is to tackle <a href="https://www.biometricupdate.com/202309/synthetic-faces-could-solve-algorithmic-bias-and-ethical-data-quandary-idverse">bias issues</a

## Go beyond overall biometrics accuracy testing, early and broadly
 - [https://www.biometricupdate.com/202310/go-beyond-overall-biometrics-accuracy-testing-early-and-broadly](https://www.biometricupdate.com/202310/go-beyond-overall-biometrics-accuracy-testing-early-and-broadly)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T15:43:15+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="1152" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/07/17114352/phone-fingerprint-sensor-passkeys-scaled.jpg" width="2048" />
		Biometric systems with generally high accuracy can have hidden performance problems in the form of differentials in error rates for different groups of people or based on various other factors. How those differentials are found and addressed in a laboratory setting was explored by <a href="https://www.biometricupdate.com/companies/fime">Fime</a> Laboratory Biometric Service Line Manager Joel Di Manno in a presentation at the <a href="https://www.biometricupdate.com/companies/fido-alliance">FIDO Alliance</a>’s <a href="https://authenticatecon.com/event/authenticate-2023/">Authenticate 2023</a> conference.

In his presentation, “How can bias influence the usage of biometrics?”, Di Manno recounted an experience with a customer seeking quality assurance t

## C-level moves at Facephi, Plaid, Prove, JumpCloud, new VPs for Mitek and ID.me
 - [https://www.biometricupdate.com/202310/c-level-moves-at-facephi-plaid-prove-jumpcloud-new-vps-for-mitek-and-id-me](https://www.biometricupdate.com/202310/c-level-moves-at-facephi-plaid-prove-jumpcloud-new-vps-for-mitek-and-id-me)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T15:37:42+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="947" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/02/28142030/appointments-new-jobs-scaled.jpg" width="2048" />
		Executive positions have been filled at several prominent face biometrics providers, with Facephi, Mitek and ID.me announcing hires, while digital identity and fintech players Prove, JumpCloud and Plaid added new leaders, and Digital Identity NZ seeks council nominations.
<h2>Facephi CRO Jorge Sanz to become general manager</h2>
<a href="https://www.biometricupdate.com/companies/facephi">Facephi</a> has announced the appointment of <a href="https://www.linkedin.com/in/jorge-sanz-estrada-440b513b/?originalSubdomain=es">Jorge Sanz</a> as the company’s new General Manager.  Jorge Sanz has over 12 years of experience at the face biometrics company and has been serving as its CRO (Chief Revenue Officer).

In his new role, Jorge Sanz will focus on customer and operation

## Japanese companies, including Toppan, Fujitsu and Hitachi, create decentralized identity consortium
 - [https://www.biometricupdate.com/202310/japanese-companies-including-toppan-fujitsu-and-hitachi-create-decentralized-identity-consortium](https://www.biometricupdate.com/202310/japanese-companies-including-toppan-fujitsu-and-hitachi-create-decentralized-identity-consortium)
 - RSS feed: https://www.biometricupdate.com/feed
 - date published: 2023-10-20T14:00:45+00:00

<img alt="" class="attachment-post-thumbnail size-post-thumbnail wp-post-image" height="624" src="https://d1sr9z1pdl3mb7.cloudfront.net/wp-content/uploads/2023/03/16200347/digital-identity-interest-group-scaled.jpg" width="2048" />
		Japanese conglomerates <a href="https://www.biometricupdate.com/companies/fujitsu">Fujitsu</a>, <a href="https://www.biometricupdate.com/companies/hitachi">Hitachi</a>, <a href="https://www.biometricupdate.com/tag/ntt-data">NTT Data</a> and <a href="https://www.biometricupdate.com/companies/toppan-inc">Toppan</a> Digital are among the companies partnering with Japan’s largest financial group Mitsubishi UFJ Financial Group (<a href="https://www.mufg.jp/english/index.html">MUFG</a>) to create a decentralized identity (DID) and verifiable credential (VC) consortium.

Also joining the consortium are <a href="https://www.amt-law.com/en/">Anderson Mori &amp; Tomotsune</a> law firm, systems integrator Itochu Techno-Solutions Corporation (<a href="https://www.ct

