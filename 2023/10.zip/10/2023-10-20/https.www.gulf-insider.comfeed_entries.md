# Source:Gulf Insider, URL:https://www.gulf-insider.com/feed, language:en-US

## The COVID Gravy Train Is Over: Pfizer & Moderna Shares Down 35% & 49% This Year
 - [https://www.gulf-insider.com/the-covid-gravy-train-is-over-pfizer-moderna-shares-down-35-49-this-year/](https://www.gulf-insider.com/the-covid-gravy-train-is-over-pfizer-moderna-shares-down-35-49-this-year/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T11:56:44+00:00

<p>It took what felt like forever, but at least some reality is making its way back into healthcare. We guess this means no more dancing nurse Tik Tok videos, though. And now that we&#8217;ve seen the &#8220;pump&#8221; on the healthcare industry from Covid-19, it&#8217;s time for the &#8220;dump&#8221;. That was the topic of a new report from Bloomberg which &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/the-covid-gravy-train-is-over-pfizer-moderna-shares-down-35-49-this-year/" rel="nofollow">The COVID Gravy Train Is Over: Pfizer &amp; Moderna Shares Down 35% &amp; 49% This Year</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Indian Budget Airline Indigo Announces up to 25% Discount on Domestic and International Flights
 - [https://www.gulf-insider.com/indian-budget-airline-indigo-announces-up-to-25-discount-on-domestic-and-international-flights/](https://www.gulf-insider.com/indian-budget-airline-indigo-announces-up-to-25-discount-on-domestic-and-international-flights/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T11:41:59+00:00

<p>Indian budget airline IndiGo announced on Friday a special Dussehra sale, offering up to 25 percent discount on airfares on domestic and international flights. The limited-time offer will be available for booking from October 20 to 23, the airline said in a media statement. The offer is valid for flights between October 23 and December &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/indian-budget-airline-indigo-announces-up-to-25-discount-on-domestic-and-international-flights/" rel="nofollow">Indian Budget Airline Indigo Announces up to 25% Discount on Domestic and International Flights</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## British Airways Announces Return to Abu Dhabi, With Special Rates for Early Bookings
 - [https://www.gulf-insider.com/british-airways-announces-return-to-abu-dhabi-with-special-rates-for-early-bookings/](https://www.gulf-insider.com/british-airways-announces-return-to-abu-dhabi-with-special-rates-for-early-bookings/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T11:14:11+00:00

<p>British Airways has announced the return of Abu Dhabi to its route map following a four-year hiatus. Starting Friday, passengers can now book flights year-round from London Heathrow. Set to be operated by a Boeing 787-9 three times a day from Heathrow. To celebrate the return, British Airways is offering special rates in its World &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/british-airways-announces-return-to-abu-dhabi-with-special-rates-for-early-bookings/" rel="nofollow">British Airways Announces Return to Abu Dhabi, With Special Rates for Early Bookings</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Emirates Enhances In-Flight Meals for 92 Routes
 - [https://www.gulf-insider.com/emirates-enhances-in-flight-meals-for-92-routes/](https://www.gulf-insider.com/emirates-enhances-in-flight-meals-for-92-routes/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T08:16:25+00:00

<p>Emirates is expanding its in-flight meal ordering service to 30 new routes across its network. The Emirates Inflight Meal Preordering Service is now live across 92 routes globally, with 30 new routes including Riyadh, Jeddah, Delhi, Mumbai and Kuala Lumpur now offering the service. More than 10,000 preorders have already been delivered on more than 3,000 flights, &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/emirates-enhances-in-flight-meals-for-92-routes/" rel="nofollow">Emirates Enhances In-Flight Meals for 92 Routes</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## 10,000 Nurses in Kuwait to Benefit From Revised Work Allowance, With a Monthly Increase of KD50
 - [https://www.gulf-insider.com/10000-nurses-in-kuwait-to-benefit-from-revised-work-allowance-with-a-monthly-increase-of-kd50/](https://www.gulf-insider.com/10000-nurses-in-kuwait-to-benefit-from-revised-work-allowance-with-a-monthly-increase-of-kd50/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T07:45:54+00:00

<p>The Kuwaiti Ministry of Health has announced a reclassification of the nature of work allowance for nurses with the new system streamlining the previous three categories (A,B and C) down to two categories of A and B. The change aims to foster a more favourable work environment for the nursing staff and serves as a &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/10000-nurses-in-kuwait-to-benefit-from-revised-work-allowance-with-a-monthly-increase-of-kd50/" rel="nofollow">10,000 Nurses in Kuwait to Benefit From Revised Work Allowance, With a Monthly Increase of KD50</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Saudi Arabia Blocks More Than 200 Fake Websites in Two Months
 - [https://www.gulf-insider.com/saudi-arabia-blocks-more-than-200-fake-websites-in-two-months/](https://www.gulf-insider.com/saudi-arabia-blocks-more-than-200-fake-websites-in-two-months/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T07:36:26+00:00

<p>Saudi Arabia has blocked more than 200 websites impersonating the kingdom’s Ministry of Commerce over the past two months, an official has disclosed. “The ministry combats swindle and fraud through two tracks: daily proactive monitoring and cooperation with partners,” the ministry’s spokesman Abdul Rahman Al Hussain added at an awareness promotion forum. The official underlined &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/saudi-arabia-blocks-more-than-200-fake-websites-in-two-months/" rel="nofollow">Saudi Arabia Blocks More Than 200 Fake Websites in Two Months</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Riyadh Bus Service: New Routes, Stations, Stops, Timetables, Tickets and More Essential Information
 - [https://www.gulf-insider.com/riyadh-bus-service-new-routes-stations-stops-timetables-tickets-and-more-essential-information/](https://www.gulf-insider.com/riyadh-bus-service-new-routes-stations-stops-timetables-tickets-and-more-essential-information/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T07:31:52+00:00

<p>Riyadh’s bus service has launched a new phase, with more transport options for residents and visitors in the city. The Royal Commission for Riyadh City has announced the launch of Stage 4 of the Riyadh Bus service. The service is part of the King Abdulaziz Project for Riyadh Public Transport (KAPT) network, which aims to provide &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/riyadh-bus-service-new-routes-stations-stops-timetables-tickets-and-more-essential-information/" rel="nofollow">Riyadh Bus Service: New Routes, Stations, Stops, Timetables, Tickets and More Essential Information</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Strict Measures to Solve Random Waste Disposal Problem in Bahrain
 - [https://www.gulf-insider.com/strict-measures-to-solve-random-waste-disposal-problem-in-bahrain/](https://www.gulf-insider.com/strict-measures-to-solve-random-waste-disposal-problem-in-bahrain/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T07:25:48+00:00

<p>The Northern Municipality has taken a firm stance against the rampant issue of random waste disposal in public spaces and residential neighborhoods. In an effort to combat this problem, individuals caught throwing waste indiscriminately will now face hefty fines of up to BD300. The increasing urban development in the Northern Governorate has led to a &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/strict-measures-to-solve-random-waste-disposal-problem-in-bahrain/" rel="nofollow">Strict Measures to Solve Random Waste Disposal Problem in Bahrain</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## GITEX 2023: AI, Sustainability at Top of Agenda as Tech Companies Gear Up for COP28 in UAE
 - [https://www.gulf-insider.com/gitex-2023-ai-sustainability-at-top-of-agenda-as-tech-companies-gear-up-for-cop28-in-uae/](https://www.gulf-insider.com/gitex-2023-ai-sustainability-at-top-of-agenda-as-tech-companies-gear-up-for-cop28-in-uae/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T07:09:25+00:00

<p>Sustainability and generative AI become the most defining trends at this year’s GITEX Technology Week in Dubai Major technology players attending GITEX 2023 in Dubai this week shared their visions for AI and sustainability, as the industry gears up for the pivotal COP28 climate talks in the UAE. With exhibitors highlighting automation, data optimisation and AI-driven &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/gitex-2023-ai-sustainability-at-top-of-agenda-as-tech-companies-gear-up-for-cop28-in-uae/" rel="nofollow">GITEX 2023: AI, Sustainability at Top of Agenda as Tech Companies Gear Up for COP28 in UAE</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Telethon to Support Palestinians Today on Bahrain TV
 - [https://www.gulf-insider.com/telethon-to-support-palestinians-today-on-bahrain-tv/](https://www.gulf-insider.com/telethon-to-support-palestinians-today-on-bahrain-tv/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T06:11:22+00:00

<p>The telethon in support of the Palestinian people in the Gaza  Strip, organised by the Bahraini National Committee for Supporting the Palestinian People in Gaza in collaboration with Bahrain TV, will start at 5pm (Bahrain Time) today. This comes in implementation of the directives of His Majesty King Hamad bin Isa Al Khalifa, the Honorary &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/telethon-to-support-palestinians-today-on-bahrain-tv/" rel="nofollow">Telethon to Support Palestinians Today on Bahrain TV</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Adulterated Cosmetic Drugs Seized From Health Institution in Oman
 - [https://www.gulf-insider.com/adulterated-cosmetic-drugs-seized-from-health-institution-in-oman/](https://www.gulf-insider.com/adulterated-cosmetic-drugs-seized-from-health-institution-in-oman/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T05:56:22+00:00

<p>The Ministry of Health (MoH) referred a private health institution to the Public Prosecution after seizing samples of cosmetic injectable medical drugs suspected of being adulterated. The drugs are of unknown origin, and not imported through legal and official means, according to the procedures followed by the General Directorate of Pharmacy and Drug Control. MoH &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/adulterated-cosmetic-drugs-seized-from-health-institution-in-oman/" rel="nofollow">Adulterated Cosmetic Drugs Seized From Health Institution in Oman</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Hajj Pilgrims Registration Begins in Oman
 - [https://www.gulf-insider.com/hajj-pilgrims-registration-begins-in-oman/](https://www.gulf-insider.com/hajj-pilgrims-registration-begins-in-oman/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T05:48:29+00:00

<p>The Ministry of Endowments and Religious Affairs announced the start of registration of pilgrims wishing to perform Hajj rituals for the year 1445 AH. Citizens and residents in Oman can register through the electronic website (www.hajj.om) from 23 October to 5 November 2023. The Ministry pointed out that male and female pilgrims with visual or &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/hajj-pilgrims-registration-begins-in-oman/" rel="nofollow">Hajj Pilgrims Registration Begins in Oman</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## National Museum Hosts “India on Canvas”Exhibition
 - [https://www.gulf-insider.com/national-museum-hosts-india-on-canvasexhibition/](https://www.gulf-insider.com/national-museum-hosts-india-on-canvasexhibition/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T05:42:27+00:00

<p>The National Museum launched today an exhibition titled “India on Canvas: Masterpieces of Modern Indian Painting” in collaboration with the National Gallery of Modern Art (NGMA) in New Delhi, India, and the Embassy of India in the Sultanate of Oman. The exhibition is held in conjunction with the 75th anniversary of the Independence of the &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/national-museum-hosts-india-on-canvasexhibition/" rel="nofollow">National Museum Hosts “India on Canvas”Exhibition</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Whatsapp to Allow 2 Accounts on 1 Phone
 - [https://www.gulf-insider.com/whatsapp-to-allow-2-accounts-on-1-phone/](https://www.gulf-insider.com/whatsapp-to-allow-2-accounts-on-1-phone/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T05:37:46+00:00

<p>WhatsApp will soon allow users to operate two WhatsApp accounts on a single phone. The long-awaited feature was announced by Meta boss Mark Zuckerberg and confirmed in an official company blog post. Zuckerberg said: “Soon you’ll be able to have two WhatsApp accounts on one phone within the app”. WhatsApp to support two accounts on one &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/whatsapp-to-allow-2-accounts-on-1-phone/" rel="nofollow">Whatsapp to Allow 2 Accounts on 1 Phone</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## UAE’s 3-Month Visit Visas Discontinued
 - [https://www.gulf-insider.com/uaes-3-month-visit-visas-discontinued/](https://www.gulf-insider.com/uaes-3-month-visit-visas-discontinued/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T05:19:23+00:00

<p>The issuance of three-month visit visas in the UAE has been discontinued, Khaleej Times can reveal. A Federal Authority For Identity, Citizenship, Customs &#38; Port Security (ICP) call centre executive said the three-month visas are no longer available. The call centre executive informed, “The three-month entry permit was available a few months ago, but not &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/uaes-3-month-visit-visas-discontinued/" rel="nofollow">UAE’s 3-Month Visit Visas Discontinued</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Oil Markets Underestimating the Risk of a Middle East Blowout
 - [https://www.gulf-insider.com/oil-markets-underestimating-the-risk-of-a-middle-east-blowout/](https://www.gulf-insider.com/oil-markets-underestimating-the-risk-of-a-middle-east-blowout/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T03:15:42+00:00

<p>Last week, the Israeli government ordered its state-run electricity company to halt power supply to the Gaza Strip days after Palestinian militant group Hamas launched a surprise attack on the country. The Israeli prime minister&#8217;s office revealed that the security cabinet has approved several steps to destroy the military and governmental capabilities of Hamas and &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/oil-markets-underestimating-the-risk-of-a-middle-east-blowout/" rel="nofollow">Oil Markets Underestimating the Risk of a Middle East Blowout</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## US Embassy Tells Americans in Lebanon ‘Get Out While You Still Can’ as 20 Hezbollah Rockets Land on Israel
 - [https://www.gulf-insider.com/us-embassy-tells-americans-in-lebanon-get-out-while-you-still-can-as-20-hezbollah-rockets-land-on-israel/](https://www.gulf-insider.com/us-embassy-tells-americans-in-lebanon-get-out-while-you-still-can-as-20-hezbollah-rockets-land-on-israel/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T02:27:38+00:00

<p>Regional media is reporting that since midnight, and after President Biden departed Israel, Israeli forces have intensified their strikes across the Gaza strip, starting with Rafah, which according to Al Jazeera killed 33 people. There are reports that Biden in private comments told Netanyahu he has a &#8220;green light&#8221; from Washington to launch a fuller &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/us-embassy-tells-americans-in-lebanon-get-out-while-you-still-can-as-20-hezbollah-rockets-land-on-israel/" rel="nofollow">US Embassy Tells Americans in Lebanon ‘Get Out While You Still Can’ as 20 Hezbollah Rockets Land on Israel</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## Threads Ban on Search Terms Related to COVID-19 Is ‘Temporary’: Instagram Chief
 - [https://www.gulf-insider.com/threads-ban-on-search-terms-related-to-covid-19-is-temporary-instagram-chief/](https://www.gulf-insider.com/threads-ban-on-search-terms-related-to-covid-19-is-temporary-instagram-chief/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T01:42:00+00:00

<p>Social media platform Threads&#8217;s ban on search terms related to COVID-19 is only temporary, Instagram chief Adam Mosseri has revealed. In an Oct. 17 post on Threads, Mr. Mosseri said he didn&#8217;t have a firm date on when the ban would be lifted, but he didn&#8217;t think it would be a permanent situation. &#8220;I don&#8217;t &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/threads-ban-on-search-terms-related-to-covid-19-is-temporary-instagram-chief/" rel="nofollow">Threads Ban on Search Terms Related to COVID-19 Is ‘Temporary’: Instagram Chief</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## US Lawmakers Demand Biden Declassify Intelligence on Gaza Hospital Disaster
 - [https://www.gulf-insider.com/us-lawmakers-demand-biden-declassify-intelligence-on-gaza-hospital-disaster/](https://www.gulf-insider.com/us-lawmakers-demand-biden-declassify-intelligence-on-gaza-hospital-disaster/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T01:12:00+00:00

<p>During his Tel Aviv visit on Wednesday, President Biden had been pressed by reporters as to what convinced him to side with Israel&#8217;s denial that it didn&#8217;t strike Al-Ahli Baptist Hospital in Gaza, killing up to 200-300 people, according to local health officials. Biden had said that data from his Defense Department showed the explosion &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/us-lawmakers-demand-biden-declassify-intelligence-on-gaza-hospital-disaster/" rel="nofollow">US Lawmakers Demand Biden Declassify Intelligence on Gaza Hospital Disaster</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

## US Bases Hit by Drones, Rockets in Syria as Israeli Army Given ‘Green Light’ To Enter Gaza
 - [https://www.gulf-insider.com/us-bases-hit-by-drones-rockets-in-syria-as-israeli-army-given-green-light-to-enter-gaza/](https://www.gulf-insider.com/us-bases-hit-by-drones-rockets-in-syria-as-israeli-army-given-green-light-to-enter-gaza/)
 - RSS feed: https://www.gulf-insider.com/feed
 - date published: 2023-10-20T00:45:00+00:00

<p>A huge escalation from Iran-linked militants, just after international headlines reported Israel&#8217;s military has been given the &#8220;green light&#8221; to enter Gaza: According to CNN, a U.S. Navy vessel operating in the Middle East region intercepted multiple missiles launched from Yemen. A U.S. official says the missiles were launched from the Iran-backed Houthi militant group. &#8230;</p>
<p>The post <a href="https://www.gulf-insider.com/us-bases-hit-by-drones-rockets-in-syria-as-israeli-army-given-green-light-to-enter-gaza/" rel="nofollow">US Bases Hit by Drones, Rockets in Syria as Israeli Army Given ‘Green Light’ To Enter Gaza</a> appeared first on <a href="https://www.gulf-insider.com" rel="nofollow">Gulf Insider</a>.</p>

