# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## 3 Ways Tomorrow's AI Will Differ From Today's Chatbots
 - [https://www.wsj.com/articles/3-ways-tomorrows-ai-will-differ-from-todays-chatbots-6a86ea6b?mod=rss_Technology](https://www.wsj.com/articles/3-ways-tomorrows-ai-will-differ-from-todays-chatbots-6a86ea6b?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-10-20T12:00:00+00:00

In an interview, OpenAI’s CEO Sam Altman discusses job disruption, data and the ‘person-ness’ of bots.

## Apple's Tim Cook Makes Surprise China Visit as iPhone Sales Slump
 - [https://www.wsj.com/articles/apples-tim-cook-makes-surprise-china-visit-as-iphone-sales-slump-94ed2fa7?mod=rss_Technology](https://www.wsj.com/articles/apples-tim-cook-makes-surprise-china-visit-as-iphone-sales-slump-94ed2fa7?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-10-20T03:00:00+00:00

The CEO’s second visit to China in roughly seven months highlights Apple’s increasingly complex relationship with the world’s second-largest economy.

