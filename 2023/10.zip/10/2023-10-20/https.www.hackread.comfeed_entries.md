# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Ragnar Locker Ransomware Gang Dismantled, Key Suspect Arrested, Site Seized
 - [https://www.hackread.com/ragnar-locker-ransomware-gang-dismantled-site-seized/](https://www.hackread.com/ragnar-locker-ransomware-gang-dismantled-site-seized/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-20T21:35:22+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>Global law enforcement involving 11 countries has shuts down Ragnar Locker ransomware gang.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/ragnar-locker-ransomware-gang-dismantled-site-seized/" rel="nofollow">Ragnar Locker Ransomware Gang Dismantled, Key Suspect Arrested, Site Seized</a></p>

## New Windows Infostealer ‘ExelaStealer’ Being Sold on Dark Web
 - [https://www.hackread.com/windows-infostealer-exelastealer-sold-on-dark-web/](https://www.hackread.com/windows-infostealer-exelastealer-sold-on-dark-web/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-20T17:51:12+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>Another day, another malware threat against Windows devices and users!</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/windows-infostealer-exelastealer-sold-on-dark-web/" rel="nofollow">New Windows Infostealer &#8216;ExelaStealer&#8217; Being Sold on Dark Web</a></p>

## PDF Security – How To Keep Sensitive Data Secure in a PDF File
 - [https://www.hackread.com/pdf-security-how-sensitive-data-secure-pdf-file/](https://www.hackread.com/pdf-security-how-sensitive-data-secure-pdf-file/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-20T16:20:49+00:00

<p>By <a href="https://www.hackread.com/author/owais/" rel="nofollow">Owais Sultan</a></p>
<p>As we progress further into digital life, PDF security has evolved increasingly complex.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/pdf-security-how-sensitive-data-secure-pdf-file/" rel="nofollow">PDF Security &#8211; How To Keep Sensitive Data Secure in a PDF File</a></p>

## Chinese Scammers Use Fake Loan Apps for Money Laundering
 - [https://www.hackread.com/chinese-scammers-fake-loan-apps-money-laundering/](https://www.hackread.com/chinese-scammers-fake-loan-apps-money-laundering/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-20T15:31:34+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>A large number of victims of these scams are unsuspecting users in India.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/chinese-scammers-fake-loan-apps-money-laundering/" rel="nofollow">Chinese Scammers Use Fake Loan Apps for Money Laundering</a></p>

