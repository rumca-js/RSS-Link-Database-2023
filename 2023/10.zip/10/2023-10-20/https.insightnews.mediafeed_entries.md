# Source:Insight News Media, URL:https://insightnews.media/feed/, language:en-US

## EU to define the details of 12th package of sanctions against Russia
 - [https://insightnews.media/eu-to-define-the-details-of-12th-package-of-sanctions-against-russia/](https://insightnews.media/eu-to-define-the-details-of-12th-package-of-sanctions-against-russia/)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-10-20T09:42:58+00:00

<p>Consultations will soon begin between the European Commission and EU nations on the details of the 12th package of sanctions against Russia. This process is &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/eu-to-define-the-details-of-12th-package-of-sanctions-against-russia/"> <span class="screen-reader-text">EU to define the details of 12th package of sanctions against Russia</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/eu-to-define-the-details-of-12th-package-of-sanctions-against-russia/" rel="nofollow">EU to define the details of 12th package of sanctions against Russia</a> appeared first on <a href="https://insightnews.media" rel="nofollow">Insight News Media</a>.</p>

## ATACMS strike on airfield in Berdiansk impact Russian capabilities on the frontline – British Intelligence
 - [https://insightnews.media/atacms-strike-on-airfield-in-berdiansk-impact-russian-capabilities-on-the-frontline-british-intelligence/](https://insightnews.media/atacms-strike-on-airfield-in-berdiansk-impact-russian-capabilities-on-the-frontline-british-intelligence/)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-10-20T09:18:37+00:00

<p>British Intelligence believes that Russia&#8217;s loss of combat helicopters due to Ukraine&#8217;s first use of ATACMS on the airfield in Russian-occupied Berdiansk will significantly affect &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/atacms-strike-on-airfield-in-berdiansk-impact-russian-capabilities-on-the-frontline-british-intelligence/"> <span class="screen-reader-text">ATACMS strike on airfield in Berdiansk impact Russian capabilities on the frontline &#8211; British Intelligence</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/atacms-strike-on-airfield-in-berdiansk-impact-russian-capabilities-on-the-frontline-british-intelligence/" rel="nofollow">ATACMS strike on airfield in Berdiansk impact Russian capabilities on the frontline &#8211; British Intelligence</a> appeared first on <a href="https://insightnews.media" rel="nofollow">Insight News Media</a>.</p>

## EU has approved the extension of protection for Ukrainian refugees
 - [https://insightnews.media/eu-has-approved-the-extension-of-protection-for-ukrainian-refugees/](https://insightnews.media/eu-has-approved-the-extension-of-protection-for-ukrainian-refugees/)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-10-20T08:30:42+00:00

<p>The EU states have finally approved the extension of temporary protection for refugees from Ukraine until March 2025. Poland and the Czech Republic requested additional &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/eu-has-approved-the-extension-of-protection-for-ukrainian-refugees/"> <span class="screen-reader-text">EU has approved the extension of protection for Ukrainian refugees</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/eu-has-approved-the-extension-of-protection-for-ukrainian-refugees/" rel="nofollow">EU has approved the extension of protection for Ukrainian refugees</a> appeared first on <a href="https://insightnews.media" rel="nofollow">Insight News Media</a>.</p>

## Biden compared Hamas and Putin and requested more aid for Ukraine and Israel
 - [https://insightnews.media/biden-compared-hamas-and-putin-and-requested-more-aid-for-ukraine-and-israel/](https://insightnews.media/biden-compared-hamas-and-putin-and-requested-more-aid-for-ukraine-and-israel/)
 - RSS feed: https://insightnews.media/feed/
 - date published: 2023-10-20T08:10:37+00:00

<p>On the night of 19-20 October, US President Joe Biden delivered a speech on the war in Ukraine and Israel. Joe Biden announced an urgent &#8230;</p>
<p class="read-more"> <a class="ast-button" href="https://insightnews.media/biden-compared-hamas-and-putin-and-requested-more-aid-for-ukraine-and-israel/"> <span class="screen-reader-text">Biden compared Hamas and Putin and requested more aid for Ukraine and Israel</span> Read More »</a></p>
<p>The post <a href="https://insightnews.media/biden-compared-hamas-and-putin-and-requested-more-aid-for-ukraine-and-israel/" rel="nofollow">Biden compared Hamas and Putin and requested more aid for Ukraine and Israel</a> appeared first on <a href="https://insightnews.media" rel="nofollow">Insight News Media</a>.</p>

