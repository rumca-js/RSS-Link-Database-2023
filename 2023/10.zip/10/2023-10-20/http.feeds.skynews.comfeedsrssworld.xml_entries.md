# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Little to show for frenzy of diplomatic activity - with ground attacks just days away
 - [https://news.sky.com/story/israel-hamas-war-little-to-show-for-frenzy-of-diplomatic-activity-with-ground-attacks-just-days-away-12988604](https://news.sky.com/story/israel-hamas-war-little-to-show-for-frenzy-of-diplomatic-activity-with-ground-attacks-just-days-away-12988604)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T18:12:00+00:00

A frenzy of diplomatic activity is under way, but there is little to show for it.

## 'After the ninth person was shot I stopped counting': Violence and protests in the West Bank
 - [https://news.sky.com/story/israel-hamas-war-i-stopped-counting-after-the-ninth-person-was-shot-in-front-of-us-12988564](https://news.sky.com/story/israel-hamas-war-i-stopped-counting-after-the-ninth-person-was-shot-in-front-of-us-12988564)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T17:23:00+00:00

I stopped counting after the ninth person was shot in front of us on another day of protests in the West Bank.&#160;

## US mother and daughter released by Hamas 'for humanitarian reasons'
 - [https://news.sky.com/story/israel-hamas-war-two-us-hostages-released-for-humanitarian-reasons-sky-news-understands-12988544](https://news.sky.com/story/israel-hamas-war-two-us-hostages-released-for-humanitarian-reasons-sky-news-understands-12988544)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T16:55:00+00:00

Hamas has released two US hostages - a mother and her daughter - "for humanitarian reasons", Sky News understands.

## Trump fined $5,000 for 'disparaging' claim about court clerk
 - [https://news.sky.com/story/donald-trump-fined-5000-for-disparaging-claim-about-court-clerk-in-250m-fraud-case-12988477](https://news.sky.com/story/donald-trump-fined-5000-for-disparaging-claim-about-court-clerk-in-250m-fraud-case-12988477)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T15:27:00+00:00

Donald Trump has been fined $5,000 (&#163;4,100) for failing to delete an "untrue and disparaging" claim online about a court clerk in his New York civil fraud case.

## Man charged after reported rape of British policewoman near Eiffel Tower
 - [https://news.sky.com/story/french-man-charged-after-reported-rape-of-british-policewoman-near-eiffel-tower-in-paris-12988328](https://news.sky.com/story/french-man-charged-after-reported-rape-of-british-policewoman-near-eiffel-tower-in-paris-12988328)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T11:53:00+00:00

A French man has been charged with the rape of a British woman near the Eiffel Tower, prosecutors have said.

## Ousted president's escape attempt thwarted, Niger junta says
 - [https://news.sky.com/story/ousted-presidents-escape-attempt-thwarted-niger-junta-says-12988283](https://news.sky.com/story/ousted-presidents-escape-attempt-thwarted-niger-junta-says-12988283)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T10:24:00+00:00

Niger's ruling military junta has said it thwarted an overnight attempt by deposed President Mohamed Bazoum to escape detention.

## US soldier who fled to North Korea hit with child abuse image and desertion charges
 - [https://news.sky.com/story/travis-king-us-soldier-who-fled-to-north-korea-hit-with-child-abuse-image-and-desertion-charges-12988269](https://news.sky.com/story/travis-king-us-soldier-who-fled-to-north-korea-hit-with-child-abuse-image-and-desertion-charges-12988269)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T09:57:00+00:00

Travis King, the US soldier who fled to North Korea, has been charged with desertion and the solicitation of indecent images of children.

## Striking actors told not to dress up as film characters for Halloween - as Ryan Reynolds responds
 - [https://news.sky.com/story/striking-actors-told-not-to-dress-up-as-film-characters-for-halloween-as-ryan-reynolds-responds-12988242](https://news.sky.com/story/striking-actors-told-not-to-dress-up-as-film-characters-for-halloween-as-ryan-reynolds-responds-12988242)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T09:25:00+00:00

Striking actors have been told not to dress up as popular film or TV characters this Halloween.

## Wine growers destroy cargoes of cava and rose in protest
 - [https://news.sky.com/story/french-wine-growers-protest-cargoes-of-spanish-cava-and-rose-destroyed-by-demonstrators-waging-economic-war-12988225](https://news.sky.com/story/french-wine-growers-protest-cargoes-of-spanish-cava-and-rose-destroyed-by-demonstrators-waging-economic-war-12988225)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T09:07:00+00:00

Hundreds of crates of cava have been smashed and thousands of gallons of rose dumped by French wine growers in protest at cheap imports from Spain.

## Instagram apologises after inserting 'terrorist' into some Palestinian profiles
 - [https://news.sky.com/story/instagram-apologises-after-inserting-terrorist-into-some-palestinian-profiles-12988227](https://news.sky.com/story/instagram-apologises-after-inserting-terrorist-into-some-palestinian-profiles-12988227)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T09:02:00+00:00

Meta has apologised after Instagram inserted the word "terrorist" into some Palestinian users' profile bios.

## Italian prime minister splits with partner after sexism claims
 - [https://news.sky.com/story/italian-prime-minister-giorgia-meloni-splits-with-partner-andrea-giambruno-after-sexism-claims-12988217](https://news.sky.com/story/italian-prime-minister-giorgia-meloni-splits-with-partner-andrea-giambruno-after-sexism-claims-12988217)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T08:53:00+00:00

Italian Prime Minister Giorgia Meloni says she has separated from her partner Andrea Giambruno who has faced criticism for alleged sexist comments.

## US warship shoots down missiles 'potentially' heading for Israel as troops attacked
 - [https://news.sky.com/story/us-warship-shoots-down-missiles-potentially-heading-for-israel-as-troops-attacked-in-iraq-and-syria-12988084](https://news.sky.com/story/us-warship-shoots-down-missiles-potentially-heading-for-israel-as-troops-attacked-in-iraq-and-syria-12988084)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T06:33:00+00:00

A US Navy warship has shot down missiles possibly headed for Israel as American forces in the Middle East have also been targeted by drone strikes, fuelling fears the Gaza conflict could spread.

## Biden's speech to nation in time of deep uncertainty tried to mould US influence on Ukraine and Israel-Hamas wars
 - [https://news.sky.com/story/joe-bidens-speech-to-nation-in-time-of-deep-uncertainty-tried-to-mould-american-influence-on-ukraine-and-israel-hamas-wars-12988076](https://news.sky.com/story/joe-bidens-speech-to-nation-in-time-of-deep-uncertainty-tried-to-mould-american-influence-on-ukraine-and-israel-hamas-wars-12988076)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T06:17:00+00:00

This was only the second time President Biden has used the Oval Office for an address to the nation - a framing to emphasise a time of deep uncertainty.

## Canada withdraws 41 diplomats from India over murder dispute
 - [https://news.sky.com/story/hardeep-singh-nijjar-canada-withdraws-41-diplomats-from-india-over-sikh-leaders-murder-dispute-12988044](https://news.sky.com/story/hardeep-singh-nijjar-canada-withdraws-41-diplomats-from-india-over-sikh-leaders-murder-dispute-12988044)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-20T04:47:00+00:00

Canada has withdrawn dozens of its diplomats from India after the Indian government said it would revoke their diplomatic immunity, amid an ongoing dispute over the murder of a Sikh separatist leader.

