# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## EA Sports FC 24. Kuriozalny błąd przykleja piłkę do nogi zawodnika
 - [https://ithardware.pl/aktualnosci/ea_sports_fc_24_kuriozalny_blad_przykleja_pilke_do_nogi_zawodnika-29856.html](https://ithardware.pl/aktualnosci/ea_sports_fc_24_kuriozalny_blad_przykleja_pilke_do_nogi_zawodnika-29856.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T21:47:50+00:00

<img src="https://ithardware.pl/artykuly/min/29856_1.jpg" />            Gracze&nbsp;EA Sports FC 24 skarżą się na pewien glitch, kt&oacute;rych ich zdaniem sprawia, iż gra jest niegrywalna. Deweloperzy wiedzą o problemie i go badają.

EA Sports FC 24 z błędem psującym rozgrywkę

EA poinformowało, że bada...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ea_sports_fc_24_kuriozalny_blad_przykleja_pilke_do_nogi_zawodnika-29856.html">https://ithardware.pl/aktualnosci/ea_sports_fc_24_kuriozalny_blad_przykleja_pilke_do_nogi_zawodnika-29856.html</a></p>

## Cyberpunk 2077 dostanie aktualizację 2.02. Oto pierwsze szczegóły
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_dostanie_aktualizacje_2_02_oto_pierwsze_szczegoly-29855.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_dostanie_aktualizacje_2_02_oto_pierwsze_szczegoly-29855.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T19:44:24+00:00

<img src="https://ithardware.pl/artykuly/min/29855_1.jpg" />            Do Cyberpunka 2077 zmierza kolejna aktualizacja, kt&oacute;ra nie wniesie wielu poprawek, ale i tak usprawni kilka rzeczy. Jak na razie data wydania patcha nie jest znana.

Cyberpunk 2077 otrzyma update 2.02

Cyberpunk 2077 dostanie update oznaczony...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_dostanie_aktualizacje_2_02_oto_pierwsze_szczegoly-29855.html">https://ithardware.pl/aktualnosci/cyberpunk_2077_dostanie_aktualizacje_2_02_oto_pierwsze_szczegoly-29855.html</a></p>

## Aktor głosowy wcielający się w Jensena z Deux Ex oburzony generatorami AI
 - [https://ithardware.pl/aktualnosci/aktor_glosowy_wcielajacy_sie_w_jensena_z_deux_ex_oburzony_generatorami_ai-29854.html](https://ithardware.pl/aktualnosci/aktor_glosowy_wcielajacy_sie_w_jensena_z_deux_ex_oburzony_generatorami_ai-29854.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T17:45:49+00:00

<img src="https://ithardware.pl/artykuly/min/29854_1.jpg" />            Sztuczna inteligencja jest wykorzystywana także w branży gier do zastępowania zmarłych aktor&oacute;w, a idealnym przykładem pozostaje artysta, kt&oacute;ry użyczył głosu postaci w Cyberpunku 2077. Aktorzy głosowi zazwyczaj sceptycznie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/aktor_glosowy_wcielajacy_sie_w_jensena_z_deux_ex_oburzony_generatorami_ai-29854.html">https://ithardware.pl/aktualnosci/aktor_glosowy_wcielajacy_sie_w_jensena_z_deux_ex_oburzony_generatorami_ai-29854.html</a></p>

## Valve cofa niesłusze bany związane z funkcją Anti-Lag+ i zabezpiecza graczy CS2
 - [https://ithardware.pl/aktualnosci/valve_cofa_nieslusze_bany_zwiazane_z_funkcja_anti_lag_i_zabezpiecza_graczy_cs2-29853.html](https://ithardware.pl/aktualnosci/valve_cofa_nieslusze_bany_zwiazane_z_funkcja_anti_lag_i_zabezpiecza_graczy_cs2-29853.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T16:33:50+00:00

<img src="https://ithardware.pl/artykuly/min/29853_1.jpg" />            Kilka dni temu głośno zrobiło się o problemie związanym z technologią AMD Anti-Lag+, kt&oacute;ra powodowała otrzymywanie przez graczy blokad w popularnych tytułach online. Valve ogłosiło już rozpoczęcie cofania niesłusznych ban&oacute;w i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/valve_cofa_nieslusze_bany_zwiazane_z_funkcja_anti_lag_i_zabezpiecza_graczy_cs2-29853.html">https://ithardware.pl/aktualnosci/valve_cofa_nieslusze_bany_zwiazane_z_funkcja_anti_lag_i_zabezpiecza_graczy_cs2-29853.html</a></p>

## MediaTek Dimensity 9300 przetestowany. Wydajność wielordzeniowa robi wrażenie
 - [https://ithardware.pl/aktualnosci/mediatek_dimensity_9300_przetestowany_wydajnosc_wielordzeniowa_robi_wrazenie-29852.html](https://ithardware.pl/aktualnosci/mediatek_dimensity_9300_przetestowany_wydajnosc_wielordzeniowa_robi_wrazenie-29852.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T15:27:40+00:00

<img src="https://ithardware.pl/artykuly/min/29852_1.jpg" />            Do premiery chipu Dimensity 9300 zostało niewiele czasu. Nic więc dziwnego, że w bazie programu Geekbench 6 można odnaleźć już wyniki przedstawiające jego wydajność. Jak nadchodzący SoC od MediaTeka wypada w por&oacute;wnaniu do innych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mediatek_dimensity_9300_przetestowany_wydajnosc_wielordzeniowa_robi_wrazenie-29852.html">https://ithardware.pl/aktualnosci/mediatek_dimensity_9300_przetestowany_wydajnosc_wielordzeniowa_robi_wrazenie-29852.html</a></p>

## Nokia w kryzysie? Firma zwolni część pracowników
 - [https://ithardware.pl/aktualnosci/nokia_w_kryzysie_firma_zwolni_czesc_pracownikow-29851.html](https://ithardware.pl/aktualnosci/nokia_w_kryzysie_firma_zwolni_czesc_pracownikow-29851.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T14:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/29851_1.jpg" />            Nokia to kolejna marka technologiczna, kt&oacute;rą dotknął kryzys i zmuszona jest przeprowadzić redukcję etat&oacute;w. Wiemy ile os&oacute;b pożegna się z posadami.

Nokia zwalnia pracownik&oacute;w

Nokia w dawnych czasach niezwykle...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nokia_w_kryzysie_firma_zwolni_czesc_pracownikow-29851.html">https://ithardware.pl/aktualnosci/nokia_w_kryzysie_firma_zwolni_czesc_pracownikow-29851.html</a></p>

## Apple idzie w stronę generatywnej AI. iOS 18 może być w tej kwestii przełomowy
 - [https://ithardware.pl/aktualnosci/apple_idzie_w_strone_generatywnej_ai_ios_18_moze_byc_w_tej_kwestii_przelomowy-29850.html](https://ithardware.pl/aktualnosci/apple_idzie_w_strone_generatywnej_ai_ios_18_moze_byc_w_tej_kwestii_przelomowy-29850.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T13:52:00+00:00

<img src="https://ithardware.pl/artykuly/min/29850_1.jpg" />            Według analityka, Apple zamierza wprowadzić generatywną sztuczną inteligencję do iPhon&oacute;w oraz iPad&oacute;w. W najlepszym wypadku technologia pojawi się już pod koniec przyszłego roku. Z nowych informacji wynika, że jeszcze w tym roku...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/apple_idzie_w_strone_generatywnej_ai_ios_18_moze_byc_w_tej_kwestii_przelomowy-29850.html">https://ithardware.pl/aktualnosci/apple_idzie_w_strone_generatywnej_ai_ios_18_moze_byc_w_tej_kwestii_przelomowy-29850.html</a></p>

## iiyama gra w zielone. Znajdziesz ją również w Punkcie Zwrotnym
 - [https://ithardware.pl/aktualnosci/iiyama_gra_w_zielone_znajdziesz_ja_rowniez_w_punkcie_zwrotnym-29849.html](https://ithardware.pl/aktualnosci/iiyama_gra_w_zielone_znajdziesz_ja_rowniez_w_punkcie_zwrotnym-29849.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T13:16:00+00:00

<img src="https://ithardware.pl/artykuly/min/29849_1.jpg" />            inf.prasowa iiyama

iiyama od lat dokłada wszelkich starań, by dostarczane na rynek rozwiązania charakteryzowały się nie tylko najwyższą jakością, ale i dbałością o środowisko. W myśl tej zasady wyświetlacze marki wspierają liczne...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/iiyama_gra_w_zielone_znajdziesz_ja_rowniez_w_punkcie_zwrotnym-29849.html">https://ithardware.pl/aktualnosci/iiyama_gra_w_zielone_znajdziesz_ja_rowniez_w_punkcie_zwrotnym-29849.html</a></p>

## Test i recenzja Corsair Platform:6 Elevate. Tak to można grać, uczyć się i pracować
 - [https://ithardware.pl/testyirecenzje/test_i_recenzja_biurka_corsair_platform_6_tak_to_mozna_grac_uczyc_sie_i_pracowac-29847.html](https://ithardware.pl/testyirecenzje/test_i_recenzja_biurka_corsair_platform_6_tak_to_mozna_grac_uczyc_sie_i_pracowac-29847.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T13:11:00+00:00

<img src="https://ithardware.pl/artykuly/min/29847_1.jpg" />            Za oknem ciemno, zimno, a na p&oacute;łkach sklepowych pierwsze czekoladowe mikołaje? To już pewne, że mamy jesień i będziemy więcej czasu spędzać w domu, na nauce, pracy czy wirtualnej rozrywce. Co łączy te wszystkie codzienne aktywności?...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_i_recenzja_biurka_corsair_platform_6_tak_to_mozna_grac_uczyc_sie_i_pracowac-29847.html">https://ithardware.pl/testyirecenzje/test_i_recenzja_biurka_corsair_platform_6_tak_to_mozna_grac_uczyc_sie_i_pracowac-29847.html</a></p>

## Core i5-14600 i Core i3-14100 - tańsze procesory Intel Raport Lake Refresh przetestowane
 - [https://ithardware.pl/aktualnosci/core_i5_14600_i_core_i3_14100_tansze_procesory_intel_raport_lake_refresh_przetestowane-29846.html](https://ithardware.pl/aktualnosci/core_i5_14600_i_core_i3_14100_tansze_procesory_intel_raport_lake_refresh_przetestowane-29846.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T11:27:01+00:00

<img src="https://ithardware.pl/artykuly/min/29846_1.jpg" />            Intel jak na razie wypuścił tylko trzy procesory z serii Raptor Lake Refresh, czyli odblokowane modele Core i9-14900K, Core i7-14700K i Core i5-14600K (plus ich warianty F bez iGPU). Wkr&oacute;tce jednak powinny zadebiutować kolejne procesory z tej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/core_i5_14600_i_core_i3_14100_tansze_procesory_intel_raport_lake_refresh_przetestowane-29846.html">https://ithardware.pl/aktualnosci/core_i5_14600_i_core_i3_14100_tansze_procesory_intel_raport_lake_refresh_przetestowane-29846.html</a></p>

## Sojusz Five Eyes: Nie ma większego zagrożenia dla innowacji i bezpieczeństwa niż Chiny
 - [https://ithardware.pl/aktualnosci/sojusz_five_eyes_nie_ma_wiekszego_zagrozenia_dla_innowacji_i_bezpieczenstwa_niz_chiny-29848.html](https://ithardware.pl/aktualnosci/sojusz_five_eyes_nie_ma_wiekszego_zagrozenia_dla_innowacji_i_bezpieczenstwa_niz_chiny-29848.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T11:07:40+00:00

<img src="https://ithardware.pl/artykuly/min/29848_1.jpg" />            Agencje wywiadowcze należące do sojuszu Five Eyes wyrażają publicznie swoje obawy dotyczące sytuacji w Chinach.

Przedstawiciele Stan&oacute;w Zjednoczonych, Wielkiej Brytanii, Australii, Kanady i Nowej Zelandii podczas spotkania na Uniwersytecie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/sojusz_five_eyes_nie_ma_wiekszego_zagrozenia_dla_innowacji_i_bezpieczenstwa_niz_chiny-29848.html">https://ithardware.pl/aktualnosci/sojusz_five_eyes_nie_ma_wiekszego_zagrozenia_dla_innowacji_i_bezpieczenstwa_niz_chiny-29848.html</a></p>

## Uwaga na groźną lukę w WinRAR. Potrzebna szybka aktualizacja
 - [https://ithardware.pl/aktualnosci/uwaga_na_grozna_luke_w_winrar_potrzebna_szybka_aktualizacja-29843.html](https://ithardware.pl/aktualnosci/uwaga_na_grozna_luke_w_winrar_potrzebna_szybka_aktualizacja-29843.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T10:08:01+00:00

<img src="https://ithardware.pl/artykuly/min/29843_1.jpg" />            Jeśli korzystacie z WinRAR w starszej wersji niż 6.23 wydana w sierpniu, powinniście zaktualizować ten program tak szybko, jak to możliwe. Najnowsza wersja łata lukę znaną od miesięcy. Z ostatnich raport&oacute;w wynika, że ​​hakerzy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/uwaga_na_grozna_luke_w_winrar_potrzebna_szybka_aktualizacja-29843.html">https://ithardware.pl/aktualnosci/uwaga_na_grozna_luke_w_winrar_potrzebna_szybka_aktualizacja-29843.html</a></p>

## Pierwszy handheld PC z procesorem Meteor Lake zaprezentowany. Intel rzuca wyzwanie AMD
 - [https://ithardware.pl/aktualnosci/pierwszy_handheld_pc_z_procesorem_meteor_lake_zaprezentowany_intel_rzuca_wyzwanie_amd-29842.html](https://ithardware.pl/aktualnosci/pierwszy_handheld_pc_z_procesorem_meteor_lake_zaprezentowany_intel_rzuca_wyzwanie_amd-29842.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T09:43:02+00:00

<img src="https://ithardware.pl/artykuly/min/29842_1.jpg" />            Coraz większa popularność przenośnych komputer&oacute;w do gier wynika m.in. z najnowszych APU firmy AMD, kt&oacute;re świetnie nadają się do tego typu urządzeń. Intel może jednak wkr&oacute;tce powalczyć o ten segment rynku, a to za sprawą...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwszy_handheld_pc_z_procesorem_meteor_lake_zaprezentowany_intel_rzuca_wyzwanie_amd-29842.html">https://ithardware.pl/aktualnosci/pierwszy_handheld_pc_z_procesorem_meteor_lake_zaprezentowany_intel_rzuca_wyzwanie_amd-29842.html</a></p>

## Na chińskim rynku już brakuje RTX 4090. To pokłosie decyzji USA
 - [https://ithardware.pl/aktualnosci/na_chinskim_rynku_juz_brakuje_rtx_4090_to_poklosie_decyzji_usa-29844.html](https://ithardware.pl/aktualnosci/na_chinskim_rynku_juz_brakuje_rtx_4090_to_poklosie_decyzji_usa-29844.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T08:44:40+00:00

<img src="https://ithardware.pl/artykuly/min/29844_1.jpg" />            Administracja Stan&oacute;w Zjednoczonych postanowiła zaktualizować przepisy dotyczące ograniczeń związanych z eksportem zaawansowanych kart graficznych do Chin. Na liście znalazł się m.in. RTX 4090, z kt&oacute;rym już teraz są niemałe...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/na_chinskim_rynku_juz_brakuje_rtx_4090_to_poklosie_decyzji_usa-29844.html">https://ithardware.pl/aktualnosci/na_chinskim_rynku_juz_brakuje_rtx_4090_to_poklosie_decyzji_usa-29844.html</a></p>

## Pierwsze szczegóły na temat karty GeForce RTX 4070 SUPER (i nowego RTX 4070)
 - [https://ithardware.pl/aktualnosci/pierwsze_szczegoly_na_temat_karty_geforce_rtx_4070_super_i_nowego_rtx_4070-29841.html](https://ithardware.pl/aktualnosci/pierwsze_szczegoly_na_temat_karty_geforce_rtx_4070_super_i_nowego_rtx_4070-29841.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T08:19:01+00:00

<img src="https://ithardware.pl/artykuly/min/29841_1.jpg" />            W tym tygodniu w sieci pojawiły się pierwsze plotki o szykowanych przez NVIDIĘ modelach SUPER w ramach rodziny GeForce RTX 40, a teraz docierają do nas pierwsze szczeg&oacute;ły na temat karty GeForce RTX 4070 SUPER, a także nowego wariantu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/pierwsze_szczegoly_na_temat_karty_geforce_rtx_4070_super_i_nowego_rtx_4070-29841.html">https://ithardware.pl/aktualnosci/pierwsze_szczegoly_na_temat_karty_geforce_rtx_4070_super_i_nowego_rtx_4070-29841.html</a></p>

## Epic Games Store z kolejnymi darmowymi grami. Co nowego tym razem?
 - [https://ithardware.pl/aktualnosci/epic_games_store_z_kolejnymi_darmowymi_grami_co_nowego_tym_razem-29845.html](https://ithardware.pl/aktualnosci/epic_games_store_z_kolejnymi_darmowymi_grami_co_nowego_tym_razem-29845.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T07:33:47+00:00

<img src="https://ithardware.pl/artykuly/min/29845_1.jpg" />            W tym tygodniu do sklepu Epic Games Store dodano dwie kolejne bezpłatne gry dla graczy PC, kt&oacute;re można na zawsze dodać do swojej biblioteki. Oferta obowiązuje do godziny 17:00 czasu 26 października.

The Evil Within

Jedną z dw&oacute;ch...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/epic_games_store_z_kolejnymi_darmowymi_grami_co_nowego_tym_razem-29845.html">https://ithardware.pl/aktualnosci/epic_games_store_z_kolejnymi_darmowymi_grami_co_nowego_tym_razem-29845.html</a></p>

## OnePlus Open w końcu oficjalnie. Mocny składak, tylko ta cena
 - [https://ithardware.pl/aktualnosci/oneplus_open_w_koncu_oficjalnie_mocny_skladak_tylko_ta_cena-29840.html](https://ithardware.pl/aktualnosci/oneplus_open_w_koncu_oficjalnie_mocny_skladak_tylko_ta_cena-29840.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T07:10:53+00:00

<img src="https://ithardware.pl/artykuly/min/29840_1.jpg" />            OnePlus wreszcie oficjalnie zaprezentowało swojego składaka, czyli OnePlus Open. Oferuje on kr&oacute;tszą i szerszą składaną konstrukcję przypominającą książkę, dzięki czemu jego obsługa jest znacznie wygodniejsza. Co ciekawe, Open bazuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oneplus_open_w_koncu_oficjalnie_mocny_skladak_tylko_ta_cena-29840.html">https://ithardware.pl/aktualnosci/oneplus_open_w_koncu_oficjalnie_mocny_skladak_tylko_ta_cena-29840.html</a></p>

## AMD wprowadza swoją najmocniejszą mobilną grafikę - Radeon RX 7900M
 - [https://ithardware.pl/aktualnosci/amd_wprowadza_swoja_najmocniejsza_mobilna_grafike_radeon_rx_7900m-29839.html](https://ithardware.pl/aktualnosci/amd_wprowadza_swoja_najmocniejsza_mobilna_grafike_radeon_rx_7900m-29839.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-20T06:04:24+00:00

<img src="https://ithardware.pl/artykuly/min/29839_1.jpg" />            AMD wprowadza na rynek pierwsze GPU do laptop&oacute;w oparte na konstrukcji chipletu. Mowa to o mobilnej karcie graficznej Radeon RX 7900M, kt&oacute;ra na razie debiutuje wyłącznie w notebooku Alienware. Ten będzie dostępny w połączeniu z...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/amd_wprowadza_swoja_najmocniejsza_mobilna_grafike_radeon_rx_7900m-29839.html">https://ithardware.pl/aktualnosci/amd_wprowadza_swoja_najmocniejsza_mobilna_grafike_radeon_rx_7900m-29839.html</a></p>

