# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## A Tale Of Two Snow Whites
 - [https://www.youtube.com/watch?v=YAxkfMB9ggo](https://www.youtube.com/watch?v=YAxkfMB9ggo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-10-20T16:45:01+00:00

So it turns out the Daily Wire is going to be releasing their own version of Snow White next year, starring Brett Cooper, in a deliberate middle-finger to Disney. Is it a parody or a legit movie? And could it possibly hope to challenge the House of Mouse?

