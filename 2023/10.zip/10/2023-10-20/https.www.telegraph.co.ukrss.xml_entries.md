# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Introducing Battle Lines: Israel-Gaza, a new Telegraph podcast
 - [https://www.telegraph.co.uk/world-news/2023/10/20/battlelines-podcast-telegraph-israel-gaza-palestine/](https://www.telegraph.co.uk/world-news/2023/10/20/battlelines-podcast-telegraph-israel-gaza-palestine/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T18:15:11+00:00



## Argentina v New Zealand live: Score and updates from the Rugby World Cup semi-final
 - [https://www.telegraph.co.uk/rugby-union/2023/10/20/argentina-v-new-zealand-rugby-world-cup-semi-final-live/](https://www.telegraph.co.uk/rugby-union/2023/10/20/argentina-v-new-zealand-rugby-world-cup-semi-final-live/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T17:21:49+00:00



## Delica pumpkin with nduja, maple spiced seeds and polenta recipe
 - [https://www.telegraph.co.uk/recipes/2023/10/20/delica-pumpkin-with-nduja-maple-spiced-seeds-polenta-recipe/](https://www.telegraph.co.uk/recipes/2023/10/20/delica-pumpkin-with-nduja-maple-spiced-seeds-polenta-recipe/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T17:00:00+00:00



## Watch: Workers left hanging 500ft in air after scaffolding collapses
 - [https://www.telegraph.co.uk/world-news/2023/10/20/workers-left-dangling-after-building-collapse-in-brazil/](https://www.telegraph.co.uk/world-news/2023/10/20/workers-left-dangling-after-building-collapse-in-brazil/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T16:59:28+00:00



## Ukraine: The Latest - Biden draws direct parallels between Hamas and Putin
 - [https://www.telegraph.co.uk/world-news/2023/10/19/biden-draws-direct-parallels-between-hamas-and-putin/](https://www.telegraph.co.uk/world-news/2023/10/19/biden-draws-direct-parallels-between-hamas-and-putin/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T15:40:55+00:00



## Almost half the world’s population could be at risk from dengue due to global warming
 - [https://www.telegraph.co.uk/global-health/science-and-disease/global-dengue-fever-risk-warning-mosquitoes-climate-change/](https://www.telegraph.co.uk/global-health/science-and-disease/global-dengue-fever-risk-warning-mosquitoes-climate-change/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T15:16:10+00:00



## The best hotels near Disneyland Paris for a magical (and fuss-free) visit
 - [https://www.telegraph.co.uk/travel/destinations/europe/france/paris/articles/the-best-disneyland-paris-hotels/](https://www.telegraph.co.uk/travel/destinations/europe/france/paris/articles/the-best-disneyland-paris-hotels/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T15:00:00+00:00



## Professionalising Super League is netball’s game-changing moment
 - [https://www.telegraph.co.uk/netball/2023/10/20/super-league-professional-gamechanger-2025/](https://www.telegraph.co.uk/netball/2023/10/20/super-league-professional-gamechanger-2025/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T13:17:48+00:00



## How to stay safe when driving through flood water in the UK
 - [https://www.telegraph.co.uk/cars/advice/how-drive-safely-flood-water-heavy-rain-wind-uk-weather/](https://www.telegraph.co.uk/cars/advice/how-drive-safely-flood-water-heavy-rain-wind-uk-weather/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T11:48:49+00:00



## Australia vs Pakistan live: score and updates from the 2023 Cricket World
 - [https://www.telegraph.co.uk/cricket/2023/10/20/australia-vs-pakistan-cricket-world-cup-live-score-latest/](https://www.telegraph.co.uk/cricket/2023/10/20/australia-vs-pakistan-cricket-world-cup-live-score-latest/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T07:58:25+00:00



## Virgil van Dijk must be Liverpool’s talisman for a title challenge – and the signs look good
 - [https://www.telegraph.co.uk/football/2023/10/20/virgil-van-dijk-liverpool-talisman-title-challenge/](https://www.telegraph.co.uk/football/2023/10/20/virgil-van-dijk-liverpool-talisman-title-challenge/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T07:00:00+00:00



## Ukraine-Russia war live: Ukraine to receive ATACMS 'regularly'
 - [https://www.telegraph.co.uk/world-news/2023/10/20/ukraine-russia-war-live-biden-aid-atacams-latest/](https://www.telegraph.co.uk/world-news/2023/10/20/ukraine-russia-war-live-biden-aid-atacams-latest/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T06:34:39+00:00



## Israel-Gaza latest news: Gaza tunnels and Hamas bases struck overnight, says Israel
 - [https://www.telegraph.co.uk/world-news/2023/10/20/israel-gaza-latest-news-updates-hamas-palestine-day-14-live/](https://www.telegraph.co.uk/world-news/2023/10/20/israel-gaza-latest-news-updates-hamas-palestine-day-14-live/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T06:30:31+00:00



## Tories suffer worst by-election defeat since Second World War as Labour seizes Tamworth
 - [https://www.telegraph.co.uk/politics/2023/10/20/tamworth-byelection-tories-suffer-worst-defeat-labour-wins/](https://www.telegraph.co.uk/politics/2023/10/20/tamworth-byelection-tories-suffer-worst-defeat-labour-wins/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-10-20T05:11:28+00:00



