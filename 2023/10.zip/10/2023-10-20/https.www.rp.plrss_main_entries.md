# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Rzadki arabski głos. Poważany saudyjski książę krytykuje Hamas
 - [https://www.rp.pl/konflikty-zbrojne/art39303921-rzadki-arabski-glos-powazany-saudyjski-ksiaze-krytykuje-hamas](https://www.rp.pl/konflikty-zbrojne/art39303921-rzadki-arabski-glos-powazany-saudyjski-ksiaze-krytykuje-hamas)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T21:50:00+00:00

Saudyjski książę Turki al-Faisala wygłosił przemówienie do amerykańskiej publiczności na Uniwersytecie Rice w Houston. Jego wypowiedź jest rzadkim arabskim głosem krytykującym Hamas.

## Puchar Świata w rugby. Nowa Zelandia w finale
 - [https://www.rp.pl/rugby/art39303881-puchar-swiata-w-rugby-nowa-zelandia-w-finale](https://www.rp.pl/rugby/art39303881-puchar-swiata-w-rugby-nowa-zelandia-w-finale)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T21:11:17+00:00

Pierwszymi finalistami kończącego się we Francji Pucharu Świata w rugby zostali Nowozelandczycy. Pokonali wysoko na Stade de France Argentynę 44:6. W sobotni wieczór czas na drugi półfinał: Anglia – Afryka Południowa.

## Szwajcaria. Detektorysta znalazł na polu marchwi biżuterię sprzed 3,5 tysiąca lat
 - [https://www.rp.pl/archeologia/art39303791-szwajcaria-detektorysta-znalazl-na-polu-marchwi-bizuterie-sprzed-3-5-tysiaca-lat](https://www.rp.pl/archeologia/art39303791-szwajcaria-detektorysta-znalazl-na-polu-marchwi-bizuterie-sprzed-3-5-tysiaca-lat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T21:05:00+00:00

Podczas szukania złomu na świeżo zaoranym polu marchwi miejscowego rolnika, szwajcarski detektorysta znalazł bogaty zbiór biżuterii z 1500 r. p.n.e.

## Jarosław Kaczyński skomentował wynik wyborów. „Urojona rzeczywistość opanowała umysły znacznej części Polaków”
 - [https://www.rp.pl/wybory/art39303771-jaroslaw-kaczynski-skomentowal-wynik-wyborow-urojona-rzeczywistosc-opanowala-umysly-znacznej-czesci-polakow](https://www.rp.pl/wybory/art39303771-jaroslaw-kaczynski-skomentowal-wynik-wyborow-urojona-rzeczywistosc-opanowala-umysly-znacznej-czesci-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T20:47:32+00:00

- Jeżeli mamy znów zwyciężyć, to musimy zwyciężyć w tej Polsce innej, niż była jakiś czas temu - powiedział Jarosław Kaczyński, prezes Prawa i Sprawiedliwości, podsumowując wyniki wyborów parlamentarnych.

## Zaginął, po 9 latach znaleziono jego ciało w zamrażarce. Policja wyznaczyła nagrodę za wskazanie sprawcy
 - [https://www.rp.pl/przestepczosc/art39303731-zaginal-po-9-latach-znaleziono-jego-cialo-w-zamrazarce-policja-wyznaczyla-nagrode-za-wskazanie-sprawcy](https://www.rp.pl/przestepczosc/art39303731-zaginal-po-9-latach-znaleziono-jego-cialo-w-zamrazarce-policja-wyznaczyla-nagrode-za-wskazanie-sprawcy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T20:04:31+00:00

Londyńska policja prosi o pomoc w znalezieniu osoby odpowiedzialnej za śmierć mężczyzny, którego ciało znaleziono w zamrażarce w opuszczonym pubie, po prawie dziesięciu latach od jego zaginięcia.

## Strzelanina w Brukseli. Minister sprawiedliwości Belgii podał się do dymisji
 - [https://www.rp.pl/przestepczosc/art39303711-strzelanina-w-brukseli-minister-sprawiedliwosci-belgii-podal-sie-do-dymisji](https://www.rp.pl/przestepczosc/art39303711-strzelanina-w-brukseli-minister-sprawiedliwosci-belgii-podal-sie-do-dymisji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T20:03:00+00:00

Po przeprowadzonym przez obywatela Tunezji ataku terrorystycznym, w którym w Brukseli zginęło dwóch szwedzkich kibiców, minister sprawiedliwości Belgii podał się do dymisji.

## Maersk przerzucił dostawy kontenerów z Gdańska do Gdyni
 - [https://logistyka.rp.pl/morski/art39303691-maersk-przerzucil-dostawy-kontenerow-z-gdanska-do-gdyni](https://logistyka.rp.pl/morski/art39303691-maersk-przerzucil-dostawy-kontenerow-z-gdanska-do-gdyni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T19:31:05+00:00

Włoski strajk pracowników sparaliżował pracę Baltic Hub. Spedytorzy obawiają się, że trwające od kilku miesięcy kłopotu terminalu spowodują przeniesienie oceanicznych serwisów z Gdańska do Hamburga.

## Przede wszystkim: Scorsese! Jego „Czas krwawego księżyca” trzeba obejrzeć
 - [https://www.rp.pl/film/art39303531-przede-wszystkim-scorsese-jego-czas-krwawego-ksiezyca-trzeba-obejrzec](https://www.rp.pl/film/art39303531-przede-wszystkim-scorsese-jego-czas-krwawego-ksiezyca-trzeba-obejrzec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T19:04:16+00:00

Dużo się teraz dzieje w Polsce, ale w kinie nie da się odetchnąć. W „Czasie krwawego księżyca” Scorsese, „Klubie cudownych kobiet” O’Sullivana, „Różyczce 2” Kidawy-Błońskiego i „Figurancie” Glińskiego odbijają się traumy ludzi i społeczeństw

## Władysław Kosiniak-Kamysz: Nie ma innego scenariusza niż wspólny rząd Trzeciej Drogi z Lewicą i KO
 - [https://www.rp.pl/polityka/art39301971-wladyslaw-kosiniak-kamysz-nie-ma-innego-scenariusza-niz-wspolny-rzad-trzeciej-drogi-z-lewica-i-ko](https://www.rp.pl/polityka/art39301971-wladyslaw-kosiniak-kamysz-nie-ma-innego-scenariusza-niz-wspolny-rzad-trzeciej-drogi-z-lewica-i-ko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T18:32:18+00:00

Wierzę, że prezydent uszanuje decyzje wyborców, którzy pierwszy raz wyrazili tak silnie swoją wolę od 1989 roku - mówi Władysław Kosiniak-Kamysz, prezes Polskiego Stronnictwa Ludowego, w rozmowie z „Rzeczpospolitą”.

## 4 mln dolarów za list Krzysztofa Kolumba. Dom aukcyjny zapewnia, że to oryginał
 - [https://www.rp.pl/biznes/art39303541-4-mln-dolarow-za-list-krzysztofa-kolumba-dom-aukcyjny-zapewnia-ze-to-oryginal](https://www.rp.pl/biznes/art39303541-4-mln-dolarow-za-list-krzysztofa-kolumba-dom-aukcyjny-zapewnia-ze-to-oryginal)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T18:29:57+00:00

List Krzysztofa Kolumba z 1493 roku został sprzedany za prawie 4 mln dolarów przez nowojorski dom aukcyjny Christie's.

## Hamas uwalnia dwie amerykańsko-izraelskie zakładniczki
 - [https://www.rp.pl/konflikty-zbrojne/art39303521-hamas-uwalnia-dwie-amerykansko-izraelskie-zakladniczki](https://www.rp.pl/konflikty-zbrojne/art39303521-hamas-uwalnia-dwie-amerykansko-izraelskie-zakladniczki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T18:28:00+00:00

Dwie amerykańsko-izraelskie zakładniczki, Judith i Natalie Raanan, przetrzymywane przez Hamas od soboty 7 października, zostały przekazane Czerwonemu Krzyżowi,

## Olaf Scholz: Ograniczamy nielegalną migrację. Musimy deportować więcej i szybciej
 - [https://www.rp.pl/niemcy/art39303291-olaf-scholz-ograniczamy-nielegalna-migracje-musimy-deportowac-wiecej-i-szybciej](https://www.rp.pl/niemcy/art39303291-olaf-scholz-ograniczamy-nielegalna-migracje-musimy-deportowac-wiecej-i-szybciej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T17:35:00+00:00

Kanclerz Niemiec uderza w nowy, twardy ton w polityce migracyjnej. - Musimy deportować więcej i szybciej – mówi w wywiadzie z magazynem „Der Spiegel”.

## Łotwa wyrzuca rosyjskie statki z Bałtyku. Jest jeden warunek
 - [https://energia.rp.pl/gaz/art39302511-lotwa-wyrzuca-rosyjskie-statki-z-baltyku-jest-jeden-warunek](https://energia.rp.pl/gaz/art39302511-lotwa-wyrzuca-rosyjskie-statki-z-baltyku-jest-jeden-warunek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T17:11:13+00:00

Prezydent Łotwy wezwał szefów NATO, aby zastanowili się nad zamknięciem Morza Bałtyckiego dla rosyjskich statków. Warunkiem jest udowodniony udział Rosji w uszkodzeniu gazociągu Balticconnector łączącego Finlandię i Estonię.

## Łukasz Mejza ujawnił plan PiS. „Po kilku miesiącach wrócimy do władzy”
 - [https://www.rp.pl/wybory/art39302501-lukasz-mejza-ujawnil-plan-pis-po-kilku-miesiacach-wrocimy-do-wladzy](https://www.rp.pl/wybory/art39302501-lukasz-mejza-ujawnil-plan-pis-po-kilku-miesiacach-wrocimy-do-wladzy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T17:03:15+00:00

- Jeżeli Prawo i Sprawiedliwość, nawet w tym pierwszym kroku nie utworzy rządu, (...) po kilku miesiącach wrócimy do władzy - zapowiedział Łukasz Mejza, poseł Partii Republikańskiej. Podkreślał przy tym, że „Jarosław Kaczyński jest absolutnie genialnym strategiem”.

## Izraelskie media: Terroryści z Hamasu pod wpływem narkotyków
 - [https://www.rp.pl/konflikty-zbrojne/art39301751-izraelskie-media-terrorysci-z-hamasu-pod-wplywem-narkotykow](https://www.rp.pl/konflikty-zbrojne/art39301751-izraelskie-media-terrorysci-z-hamasu-pod-wplywem-narkotykow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T17:01:00+00:00

Izraelskie media twierdzą, że przy terrorystach, którzy zginęli w trwającym konflikcie w Strefie Gazy, znaleziono tabletki Captagonu, narkotyku nazywanego kokainą dla ubogich.

## NBP ma coraz więcej złota. Glapiński marzy by było go dwa razy tyle
 - [https://www.rp.pl/banki/art39302531-nbp-ma-coraz-wiecej-zlota-glapinski-marzy-by-bylo-go-dwa-razy-tyle](https://www.rp.pl/banki/art39302531-nbp-ma-coraz-wiecej-zlota-glapinski-marzy-by-bylo-go-dwa-razy-tyle)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:54:30+00:00

Ilość złota wchodzącego w skład rezerw walutowych Narodowego Banku Polskiego (NBP) wyniosła 10,729 mln uncji na koniec września tego roku w porównaniu do 10,108 mln uncji miesiąc wcześniej – poinformował polski bank centralny.

## TSUE: Firmy wypłacą większe pieniądze za nadgodziny
 - [https://www.rp.pl/place/art39302491-tsue-firmy-wyplaca-wieksze-pieniadze-za-nadgodziny](https://www.rp.pl/place/art39302491-tsue-firmy-wyplaca-wieksze-pieniadze-za-nadgodziny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:50:38+00:00

Dodatkowe wynagrodzenie za pracę w godzinach nadliczbowych powinno uwzględniać wymiar czasu pracy pracownika. Po wyroku Trybunału Sprawiedliwości UE polskie firmy powinny przyjrzeć się swoim praktykom.

## Najlepiej zarabiający aktorzy chcą końca strajku w Hollywood. Oferta na 150 mln dolarów
 - [https://www.rp.pl/media/art39301541-najlepiej-zarabiajacy-aktorzy-chca-konca-strajku-w-hollywood-oferta-na-150-mln-dolarow](https://www.rp.pl/media/art39301541-najlepiej-zarabiajacy-aktorzy-chca-konca-strajku-w-hollywood-oferta-na-150-mln-dolarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:40:13+00:00

George Clooney, Scarlett Johansson, Ben Affleck, Emma Stone, Tyler Perry to część osób, które aby przyczynić się do zakończenia strajku aktorów w Hollywood, zaproponowały 150 mln dol. Jest już odpowiedź strajkujących.

## Konkurs mający obalić Krzysztofa Głuchowskiego w Teatrze Słowackiego unieważniony
 - [https://www.rp.pl/teatr/art39302171-konkurs-majacy-obalic-krzysztofa-gluchowskiego-w-teatrze-slowackiego-uniewazniony](https://www.rp.pl/teatr/art39302171-konkurs-majacy-obalic-krzysztofa-gluchowskiego-w-teatrze-slowackiego-uniewazniony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:28:29+00:00

Zarząd Województwa Małopolskiego z uwagi na nieusuwalną wadę procedury konkursowej, podjął decyzję o unieważnieniu konkursu na stanowisko dyrektora Teatru im. Juliusza Słowackiego w Krakowie.

## Skomplikowany CIT dla spółek zarządzanych przez fundacje rodzinne
 - [https://firma.rp.pl/finanse/art39301761-skomplikowany-cit-dla-spolek-zarzadzanych-przez-fundacje-rodzinne](https://firma.rp.pl/finanse/art39301761-skomplikowany-cit-dla-spolek-zarzadzanych-przez-fundacje-rodzinne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:08:45+00:00

Fundacja rodzinna, to rozwiązanie z którego od tego roku mogą korzystać przedsiębiorcy. Umożliwia ono zachowanie ciągłości działania i dalszego rozwoju firmom rodzinnym. Przy wszystkich zaletach w obrębie fundacji tworzą się także pewne komplikacje.

## Media: Węgrzy w sztabie Prawa i Sprawiedliwości. "Robili co chcieli"
 - [https://www.rp.pl/wybory/art39301921-media-wegrzy-w-sztabie-prawa-i-sprawiedliwosci-robili-co-chcieli](https://www.rp.pl/wybory/art39301921-media-wegrzy-w-sztabie-prawa-i-sprawiedliwosci-robili-co-chcieli)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:05:00+00:00

Tygodnik "Polityka", powołując się na źródła w PiS, pisze, że sztabowi partii Jarosława Kaczyńskiego miała doradzać węgierska firma, która pomogła w zwycięstwie nad opozycją Viktorowi Orbanowi.

## 93-letni Sobiesław Zasada startuje w kolejnym rajdzie
 - [https://moto.rp.pl/tu-i-teraz/art39301781-93-letni-sobieslaw-zasada-startuje-w-kolejnym-rajdzie](https://moto.rp.pl/tu-i-teraz/art39301781-93-letni-sobieslaw-zasada-startuje-w-kolejnym-rajdzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T16:03:26+00:00

Sobiesław Zasada wsiądzie za kierownicę Porsche Dakar RED58 Special, indywidualnej wersji modelu 911 nawiązującej do czerwono-pomarańczowego auta, którym on sam z Markiem Wachowskim pokonał w 1968 roku maraton z Wielkiej Brytanii do Australii.

## Na rynku walut dziwnie spokojnie
 - [https://www.rp.pl/waluty/art39301741-na-rynku-walut-dziwnie-spokojnie](https://www.rp.pl/waluty/art39301741-na-rynku-walut-dziwnie-spokojnie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:45:00+00:00

Mijający tydzień przyniósł sporą zmienność walut, ale ostatni dzień tygodnia jest wyjątkowo stabilny.

## Greta Thunberg solidaryzuje się z Palestyńczykami i Gazą
 - [https://www.rp.pl/konflikty-zbrojne/art39301451-greta-thunberg-solidaryzuje-sie-z-palestynczykami-i-gaza](https://www.rp.pl/konflikty-zbrojne/art39301451-greta-thunberg-solidaryzuje-sie-z-palestynczykami-i-gaza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:32:33+00:00

Szwedzka aktywistka klimatyczna Greta Thunberg wyraziła solidarność z Palestyną. "Świat musi wezwać do wolności dla Palestyńczyków" - oświadczyła w mediach społecznościowych.

## Dziennik Ustaw z 20 października 2023 (2258-2273)
 - [https://www.rp.pl/akty-prawne/art39301711-dziennik-ustaw-z-20-pazdziernika-2023-2258-2273](https://www.rp.pl/akty-prawne/art39301711-dziennik-ustaw-z-20-pazdziernika-2023-2258-2273)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:07:56+00:00



## "Corps à corps. Historie fotografii”: Tożsamość zaklęta w zdjęciach
 - [https://www.rp.pl/plus-minus/art39297781-corps-a-corps-historie-fotografii-tozsamosc-zakleta-w-zdjeciach](https://www.rp.pl/plus-minus/art39297781-corps-a-corps-historie-fotografii-tozsamosc-zakleta-w-zdjeciach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

Jesteśmy uwięzieni w swoich twarzach i gestach. Splątani historiami, które nas stworzyły lub zniszczyły. Jeśli nie potrafimy uchwycić istoty samych siebie, może zrobi to za nas obiektyw aparatu?

## Czy sztukę abstrakcyjną można zrozumieć?
 - [https://www.rp.pl/plus-minus/art39297731-czy-sztuke-abstrakcyjna-mozna-zrozumiec](https://www.rp.pl/plus-minus/art39297731-czy-sztuke-abstrakcyjna-mozna-zrozumiec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

Abstrakcja jest czasem postrzegana oraz sprowadzana przez niektórych widzów do niezrozumiałych, pozbawionych treści plam i gestów lub czystej estetyczności, czyli dekoracji bliskiej kładzionym na ścianach wzorkom. Co w istocie mieści w sobie tak pojemny formalnie i wieloznaczny termin?

## Eutanazja wcale nie musi być najlepszym rozwiązaniem
 - [https://www.rp.pl/plus-minus/art39297821-eutanazja-wcale-nie-musi-byc-najlepszym-rozwiazaniem](https://www.rp.pl/plus-minus/art39297821-eutanazja-wcale-nie-musi-byc-najlepszym-rozwiazaniem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

Godnym sposobem zaradzenia cierpieniom, jakie stają się udziałem śmiertelnie chorych, nie jest eutanazja. Trzeba czegoś innego: zredukowania bólu fizycznego, opieki pielęgniarskiej, odciążenia rodziny.

## Jan Maciejewski: Porażka PiS-u jest mi bliska, choć on sam jest mi obcy
 - [https://www.rp.pl/plus-minus/art39297861-jan-maciejewski-porazka-pis-u-jest-mi-bliska-choc-on-sam-jest-mi-obcy](https://www.rp.pl/plus-minus/art39297861-jan-maciejewski-porazka-pis-u-jest-mi-bliska-choc-on-sam-jest-mi-obcy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

PiS jest mi ze wszech miar obcy, ale jego klęska pozostaje mi bliska. Bo tylko biorąc ją za własną, wypijając do dna, można się spróbować wyrwać z zaklętego kręgu autodestrukcji. Budować afirmatywny – chcący być, pragnący bytu, a nie chowający się przed nim ze strachu w kicz i cepelię – konserwatyzm.

## Tanie wino Hemingwaya
 - [https://www.rp.pl/plus-minus/art39297851-tanie-wino-hemingwaya](https://www.rp.pl/plus-minus/art39297851-tanie-wino-hemingwaya)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

Gdybym miał przedstawić mój ranking seriali, to myślę, że na czele byłaby „Sukcesja”, a potem długo, długo nic…

## Tomasz Terlikowski: Zamiast koncentrować się na polityce warto sięgnąć po głębsze teksty
 - [https://www.rp.pl/plus-minus/art39297701-tomasz-terlikowski-zamiast-koncentrowac-sie-na-polityce-warto-siegnac-po-glebsze-teksty](https://www.rp.pl/plus-minus/art39297701-tomasz-terlikowski-zamiast-koncentrowac-sie-na-polityce-warto-siegnac-po-glebsze-teksty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

Nie samą polityką żyje człowiek. Czasem warto sięgnąć także po teksty, które wprowadzają nas w głąb naszego życia duchowego. Takie jak nowa adhortacja apostolska Franciszka poświęcona św. Teresie od Dzieciątka Jezus.

## „Biada Babilonowi”: Bez uchodźców z chorobą popromienną
 - [https://www.rp.pl/plus-minus/art39297881-biada-babilonowi-bez-uchodzcow-z-choroba-popromienna](https://www.rp.pl/plus-minus/art39297881-biada-babilonowi-bez-uchodzcow-z-choroba-popromienna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T15:00:00+00:00

W Europie wkraczamy w okres, w którym zagrożenie użyciem broni atomowej wzrosło – oświadczyła Jessica Cox kierująca polityką nuklearną NATO. Można rzec, że powieść Pata Franka „Biada Babilonowi” sprzed 60 lat ukazuje się u nas w dobrym momencie.

## Marek Borowski: Bądźcie ciszej, kiedy tworzy się rząd
 - [https://www.rp.pl/polityka/art39300661-marek-borowski-badzcie-ciszej-kiedy-tworzy-sie-rzad](https://www.rp.pl/polityka/art39300661-marek-borowski-badzcie-ciszej-kiedy-tworzy-sie-rzad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:59:47+00:00

Każde słowo, a szczególnie każdy epitet, który pada między partnerami, ma siłę granatnika z Komendy Głównej Policji. A każda kandydatura na ministra pali się tym szybciej, im wcześniej została zgłoszona.

## Do Ziemi dotarł rekordowy szybki błysk radiowy sprzed 8 miliardów lat
 - [https://www.rp.pl/kosmos/art39299301-do-ziemi-dotarl-rekordowy-szybki-blysk-radiowy-sprzed-8-miliardow-lat](https://www.rp.pl/kosmos/art39299301-do-ziemi-dotarl-rekordowy-szybki-blysk-radiowy-sprzed-8-miliardow-lat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:40:37+00:00

Astronomowie wykryli błysk radiowy, który dotarł na Ziemię z odległej galaktyki. To jeden z najmocniejszych i najbardziej odległych sygnałów znanych jako FRB, jakie do tej pory zaobserwowano.

## Stworzono modyfikowane genetycznie drzewa. Szybko rosną i pochłaniają mnóstwo CO2
 - [https://klimat.rp.pl/klimat/art39300921-stworzono-modyfikowane-genetycznie-drzewa-szybko-rosna-i-pochlaniaja-mnostwo-co2](https://klimat.rp.pl/klimat/art39300921-stworzono-modyfikowane-genetycznie-drzewa-szybko-rosna-i-pochlaniaja-mnostwo-co2)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:11:15+00:00

Naukowcy stworzyli modyfikowane genetycznie drzewa, które mogą pomóc w walce ze zmianami klimatu. Eksperci szacują, ze jeśli do 2030 roku obsadzone zostałyby nimi cztery miliony akrów, mogłoby to doprowadzić do pochłonięcia ponad 600 megaton CO2 z atmosfery.

## Nowe badanie: Coraz częściej Polacy chodzą na zakupy spożywcze
 - [https://www.rp.pl/handel/art39300861-nowe-badanie-coraz-czesciej-polacy-chodza-na-zakupy-spozywcze](https://www.rp.pl/handel/art39300861-nowe-badanie-coraz-czesciej-polacy-chodza-na-zakupy-spozywcze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:09:41+00:00

Statystyczny kupujący odwiedza sieci handlowe co dwa dni, a w tym roku wszystkie sektory notują ich więcej niż przed rokiem. Najwyższy wzrost widać w przypadku supermarketów i dyskontów.

## Moody’s ostrzega: rating Izraela może spać z powodu konfliktu z Hamasem
 - [https://www.rp.pl/gospodarka/art39300331-moody-s-ostrzega-rating-izraela-moze-spac-z-powodu-konfliktu-z-hamasem](https://www.rp.pl/gospodarka/art39300331-moody-s-ostrzega-rating-izraela-moze-spac-z-powodu-konfliktu-z-hamasem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:02:57+00:00

Agencja ratingowa Moody’s Investor Service ostrzegła w czwartek, że rating kredytowy Izraela może być nie do utrzymania.

## Moody’s ostrzega: rating Izraela może spaść z powodu konfliktu z Hamasem
 - [https://www.rp.pl/gospodarka/art39300331-moody-s-ostrzega-rating-izraela-moze-spasc-z-powodu-konfliktu-z-hamasem](https://www.rp.pl/gospodarka/art39300331-moody-s-ostrzega-rating-izraela-moze-spasc-z-powodu-konfliktu-z-hamasem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T12:02:57+00:00

Agencja ratingowa Moody’s Investor Service ostrzegła w czwartek, że rating kredytowy Izraela może być nie do utrzymania.

## „My, prawniczki!” Mężczyzn też warto pytać, jak łączą karierę i opiekę nad domem
 - [https://kobieta.rp.pl/prawo/art39300571-my-prawniczki-mezczyzn-tez-warto-pytac-jak-lacza-kariere-i-opieke-nad-domem](https://kobieta.rp.pl/prawo/art39300571-my-prawniczki-mezczyzn-tez-warto-pytac-jak-lacza-kariere-i-opieke-nad-domem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:55:35+00:00

Prawniczki za chęć bycia doskonałymi w pracy i życiu osobistym nierzadko płacą zdrowiem. Coraz częściej jednak mówią: pas - i pytają, dlaczego o godzenie ról nikt nie pyta mężczyzn.

## Nie każdy posiłek dla pracownika bez składek ZUS
 - [https://firma.rp.pl/prawo-i-podatki/art39300821-nie-kazdy-posilek-dla-pracownika-bez-skladek-zus](https://firma.rp.pl/prawo-i-podatki/art39300821-nie-kazdy-posilek-dla-pracownika-bez-skladek-zus)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:28:06+00:00

ZUS wydał ważne stanowisko w sprawie oskładkowania bonów i kart żywieniowych dla pracowników.

## Joe Biden porównuje Władimira Putina do Hamasu. Jest reakcja Kremla
 - [https://www.rp.pl/konflikty-zbrojne/art39300781-joe-biden-porownuje-wladimira-putina-do-hamasu-jest-reakcja-kremla](https://www.rp.pl/konflikty-zbrojne/art39300781-joe-biden-porownuje-wladimira-putina-do-hamasu-jest-reakcja-kremla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:27:04+00:00

W swoim czwartkowym orędziu Joe Biden wskazywał na podobieństwa między Władimirem Putinem a Hamasem. Do słów tych odniósł się rzecznik Kremla.

## Łukasz Greinke nowym przewodniczącym Rady Interesantów Portu Gdańsk
 - [https://logistyka.rp.pl/w-branzy/art39300831-lukasz-greinke-nowym-przewodniczacym-rady-interesantow-portu-gdansk](https://logistyka.rp.pl/w-branzy/art39300831-lukasz-greinke-nowym-przewodniczacym-rady-interesantow-portu-gdansk)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:22:21+00:00

Walne Zebranie Członków Rady Interesantów Portu Gdańsk wybrało 19 października nowe władze. Członkowie wybrali jednogłośnie na przewodniczącego byłego prezesa Zarządu Morskiego Portu Gdańsk Łukasza Greinke.

## Opozycja przygotowuje się na konsultacje z Andrzejem Dudą w sprawie nowego rządu
 - [https://www.rp.pl/polityka/art39300591-opozycja-przygotowuje-sie-na-konsultacje-z-andrzejem-duda-w-sprawie-nowego-rzadu](https://www.rp.pl/polityka/art39300591-opozycja-przygotowuje-sie-na-konsultacje-z-andrzejem-duda-w-sprawie-nowego-rzadu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:15:54+00:00

Liderzy Koalicji Obywatelskiej, Trzeciej Drogi i Lewicy spotkają się w poniedziałek, by wypracować wspólne stanowisko w konsultacjach z prezydentem na temat nowego rządu.

## Wieczna Mahsa Amini - historia Iranki, której śmierć wstrząsnęła całym światem
 - [https://kobieta.rp.pl/jej-historia/art39300351-wieczna-mahsa-amini-historia-iranki-ktorej-smierc-wstrzasnela-calym-swiatem](https://kobieta.rp.pl/jej-historia/art39300351-wieczna-mahsa-amini-historia-iranki-ktorej-smierc-wstrzasnela-calym-swiatem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:13:48+00:00

Rok po tragicznej śmierci Iranka Mahsa Amini została uhonorowana przez Parlament Europejski. Podjęto decyzję o przyznaniu jej Nagrody Sacharowa za wolność myśli. Oto jej historia.

## Szejna: Tusk premierem? Ze strony Lewicy kandydatura będzie zaakceptowana
 - [https://www.rp.pl/polityka/art39300731-szejna-tusk-premierem-ze-strony-lewicy-kandydatura-bedzie-zaakceptowana](https://www.rp.pl/polityka/art39300731-szejna-tusk-premierem-ze-strony-lewicy-kandydatura-bedzie-zaakceptowana)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:06:00+00:00

Dla mnie to oczywiste, że w ramach naszej koalicji zjednoczonej opozycji, w ramach pewnego programu, pierwszy kandydat lub kandydatka, który powinien być zgłoszony, to osoba zgłoszona przez Koalicję Obywatelską - powiedział w rozmowie z RMF FM Andrzej Szejna, poseł Lewicy.

## W Gdyni znaleziono ciało sześciolatka. Trwa obława na sprawcę
 - [https://www.rp.pl/przestepczosc/art39300711-w-gdyni-znaleziono-cialo-szesciolatka-trwa-oblawa-na-sprawce](https://www.rp.pl/przestepczosc/art39300711-w-gdyni-znaleziono-cialo-szesciolatka-trwa-oblawa-na-sprawce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T11:04:52+00:00

W mieszkaniu w dzielnicy Karwiny w Gdyni odnaleziono zwłoki sześcioletniego dziecka. Z doniesień mediów wynika, że chłopiec padł ofiarą zabójstwa. Trwa obława na sprawcę. W akcji bierze udział Żandarmeria Wojskowa, poszukiwany może być żołnierzem Wojska Polskiego.

## Izrael wyłączy Al-Jazeerę powołując się na względy bezpieczeństwa? Prawo zadziała wstecz
 - [https://www.rp.pl/konflikty-zbrojne/art39300541-izrael-wylaczy-al-jazeere-powolujac-sie-na-wzgledy-bezpieczenstwa-prawo-zadziala-wstecz](https://www.rp.pl/konflikty-zbrojne/art39300541-izrael-wylaczy-al-jazeere-powolujac-sie-na-wzgledy-bezpieczenstwa-prawo-zadziala-wstecz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:53:57+00:00

Izraelski rząd zatwierdził przepisy, które pozwolą tymczasowo zawiesić nadawanie w kraju zagranicznych kanałów informacyjnych w czasie stanu wyjątkowego.

## Banki PEKAO pod lupą. Chodzi m.in. o wakacje kredytowe i pożyczki "na klik"
 - [https://www.rp.pl/konsumenci/art39300401-banki-pekao-pod-lupa-chodzi-m-in-o-wakacje-kredytowe-i-pozyczki-na-klik](https://www.rp.pl/konsumenci/art39300401-banki-pekao-pod-lupa-chodzi-m-in-o-wakacje-kredytowe-i-pozyczki-na-klik)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:46:26+00:00

Rzecznik Finansowy zwrócił się do UOKiK  o zbadanie działalności Banku Pekao S.A. oraz Pekao Banku Hipotecznego S.A. pod kątem potencjalnego naruszenia zbiorowych interesów konsumentów. Skarżą się oni na nieprawidłową realizację ustawy o wakacjach kredytowych, przekraczanie terminów rozpatrywania reklamacji czy niezwracanie środków utraconych wskutek nieautoryzowanych transakcji.

## Jędrzej Bielecki: W krucjacie Joe Bidena Polska może okazać się kluczowym sojusznikiem
 - [https://www.rp.pl/komentarze/art39300101-jedrzej-bielecki-w-krucjacie-joe-bidena-polska-moze-okazac-sie-kluczowym-sojusznikiem](https://www.rp.pl/komentarze/art39300101-jedrzej-bielecki-w-krucjacie-joe-bidena-polska-moze-okazac-sie-kluczowym-sojusznikiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:39:00+00:00

Prezydent ogłasza świętą wojnę w obronie demokracji na Ukrainie i w Izraelu. Jednak kolejne sondaże w USA wskazują, że amerykańskie społeczeństwo stopniowo przesuwa się w stronę izolacjonizmu. Projekt scalania demokracji na świecie może stać się wielką szansą dla Polski.

## Właściciele mieszkań na wynajem już apelują do przyszłych władz
 - [https://www.rp.pl/nieruchomosci/art39300411-wlasciciele-mieszkan-na-wynajem-juz-apeluja-do-przyszlych-wladz](https://www.rp.pl/nieruchomosci/art39300411-wlasciciele-mieszkan-na-wynajem-juz-apeluja-do-przyszlych-wladz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:35:30+00:00

Ulgi, zachęty, regulacje. Zasób mieszkań na wynajem w Polsce może być większy - ocenia stowarzyszenie „Mieszkanicznik”.

## Jacek Sasin: Tęczowa koalicja już wycofuje się z obietnic
 - [https://www.rp.pl/wybory/art39300501-jacek-sasin-teczowa-koalicja-juz-wycofuje-sie-z-obietnic](https://www.rp.pl/wybory/art39300501-jacek-sasin-teczowa-koalicja-juz-wycofuje-sie-z-obietnic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:30:00+00:00

Minister aktywów państwowych Jacek Sasin krytykuje opozycję, zaznaczając, że "już wycofuje się z obietnic". Polityk pisze w mediach społecznościowych o "kompletnej niespójności ideowych postulatów" i ostrzega, że "szykuje się cyrk”.

## Sondaż: Nie przeszkadza nam zamknięta granica południowa
 - [https://www.rp.pl/polityka/art39300341-sondaz-nie-przeszkadza-nam-zamknieta-granica-poludniowa](https://www.rp.pl/polityka/art39300341-sondaz-nie-przeszkadza-nam-zamknieta-granica-poludniowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:26:25+00:00

Większość Polaków zgadza się na tymczasowe przywrócenie kontroli granicznej ze Słowacją, skąd napływają uchodźcy m.in. z Bliskiego Wschodu.

## PiS szykuje kontrofensywę, prezydent gra we własną grę
 - [https://www.rp.pl/polityka/art39300461-pis-szykuje-kontrofensywe-prezydent-gra-we-wlasna-gre](https://www.rp.pl/polityka/art39300461-pis-szykuje-kontrofensywe-prezydent-gra-we-wlasna-gre)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:18:45+00:00

- Prezydent Andrzej Duda w tej części swojej kadencji nie będzie ani pupilkiem opozycji, ani nie będzie realizował tylko strategii PiS – ocenił w podcaście "Polityczne Michałki" Michał Kolanko. Razem z Michałem Szułdrzyńskim analizował on grę prezydenta i PiS po wyborach, w których partia Jarosława Kaczyńskiego osiągnęła najlepszy wynik, ale nie jest w stanie utrzymać rządów

## USA "zaniepokojone" spotkaniem Viktora Orbana z Władimirem Putinem
 - [https://www.rp.pl/dyplomacja/art39300301-usa-zaniepokojone-spotkaniem-viktora-orbana-z-wladimirem-putinem](https://www.rp.pl/dyplomacja/art39300301-usa-zaniepokojone-spotkaniem-viktora-orbana-z-wladimirem-putinem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T10:08:28+00:00

Ambasador USA w Budapeszcie, David Pressman, w wydanym oświadczeniu wyraził "obawy" w związku z relacjami łączącymi Węgry z Rosją.

## Kolejny ruch samorządu lekarskiego ws. Uniwersytetu Kaliskiego
 - [https://www.rp.pl/zdrowie/art39300291-kolejny-ruch-samorzadu-lekarskiego-ws-uniwersytetu-kaliskiego](https://www.rp.pl/zdrowie/art39300291-kolejny-ruch-samorzadu-lekarskiego-ws-uniwersytetu-kaliskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:59:07+00:00

Zespół ds. naruszeń w ochronie zdrowia Naczelnej Rady Lekarskiej złożył do Naczelnego Rzecznika Odpowiedzialności Zawodowej zawiadomienie na prof. dr. hab. n. med. Andrzeja Wojtyłę, rektora Uniwersytetu Kaliskiego.

## Psycholożka o ataku nożownika w Poznaniu: "Z tej tragedii można wynieść lekcję"
 - [https://kobieta.rp.pl/psychologia/art39299651-psycholozka-o-ataku-nozownika-w-poznaniu-z-tej-tragedii-mozna-wyniesc-lekcje](https://kobieta.rp.pl/psychologia/art39299651-psycholozka-o-ataku-nozownika-w-poznaniu-z-tej-tragedii-mozna-wyniesc-lekcje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:47:11+00:00

Środowy atak nożownika w Poznaniu na 5-letniego chłopca to jedno z tych wydarzeń, o którym mówią wszyscy. Czy tragedię, której rozmiar trudno pojąć, można próbować racjonalnie wytłumaczyć?

## Rośnie południowy jedwabny szlak
 - [https://logistyka.rp.pl/szynowy/art39300261-rosnie-poludniowy-jedwabny-szlak](https://logistyka.rp.pl/szynowy/art39300261-rosnie-poludniowy-jedwabny-szlak)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:46:55+00:00

Koleje odgrywają ważną rolę w handlu z Chinami, wojnie na Ukrainie i w jej przyszłej odbudowie, a państwa, przez które przebiegają korytarze transportowe prowadzą duże inwestycje infrastrukturalne.

## Pogoda w Polsce: IMGW informuje, że może paść rekord ciepła
 - [https://www.rp.pl/spoleczenstwo/art39300251-pogoda-w-polsce-imgw-informuje-ze-moze-pasc-rekord-ciepla](https://www.rp.pl/spoleczenstwo/art39300251-pogoda-w-polsce-imgw-informuje-ze-moze-pasc-rekord-ciepla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:44:00+00:00

Jakiej pogody możemy spodziewać się w nadchodzący weekend? IMGW informuje, że niewykluczone jest, iż padną nowe rekordy temperatury. Nieco chłodniej ma być zaś w północnych regionach kraju.

## Rozliczenie PiS. Krzysztof Bosak: Konfederacja chce, żeby winni poszli do więzienia
 - [https://www.rp.pl/wybory/art39299251-rozliczenie-pis-krzysztof-bosak-konfederacja-chce-zeby-winni-poszli-do-wiezienia](https://www.rp.pl/wybory/art39299251-rozliczenie-pis-krzysztof-bosak-konfederacja-chce-zeby-winni-poszli-do-wiezienia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:35:55+00:00

- Będziemy zdecydowanie za rozliczeniem PiS-u - zadeklarował lider Konfederacji Krzysztof Bosak. - Chcemy, żeby ludzie, którzy są winni złamania prawa, poszli do więzienia - dodał w rozmowie z Jackiem Nizinkiewiczem prezes Ruchu Narodowego.

## Prezes PSL zapowiada utworzenie "najlepszego rządu na jaki zasługuje Polska"
 - [https://www.rp.pl/polityka/art39300081-prezes-psl-zapowiada-utworzenie-najlepszego-rzadu-na-jaki-zasluguje-polska](https://www.rp.pl/polityka/art39300081-prezes-psl-zapowiada-utworzenie-najlepszego-rzadu-na-jaki-zasluguje-polska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:26:04+00:00

Prosimy pana prezydenta, aby nie zwlekał ze wskazywaniem kandydata na premiera - mówił na konferencji prasowej prezes PSL, Władysław Kosiniak-Kamysz.

## Tania ropa z Rosji płynie do Chin. W zamian Kreml dostanie cenne technologie
 - [https://energia.rp.pl/ropa/art39299791-tania-ropa-z-rosji-plynie-do-chin-w-zamian-kreml-dostanie-cenne-technologie](https://energia.rp.pl/ropa/art39299791-tania-ropa-z-rosji-plynie-do-chin-w-zamian-kreml-dostanie-cenne-technologie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:20:30+00:00

Chiny bez skrupułów wykorzystują wojnę w Ukrainie do tanich zakupów w Rosji. W tym roku import rosyjskiej ropy zwiększył się o blisko jedną czwartą. Pomimo to chińskie koncerny zapłaciły Rosjanom o 2,3 proc. mniej niż rok wcześniej.

## Ponad połowa nabywców aut elektrycznych w USA wraca do modeli spalinowych
 - [https://moto.rp.pl/na-prad/art39299911-ponad-polowa-nabywcow-aut-elektrycznych-w-usa-wraca-do-modeli-spalinowych](https://moto.rp.pl/na-prad/art39299911-ponad-polowa-nabywcow-aut-elektrycznych-w-usa-wraca-do-modeli-spalinowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:18:00+00:00

Przeprowadzone ostatnio badania doprowadziły do intrygujących wniosków. Właściciele elektrycznych samochodów w USA nie wierni idei podróżowania bez emisji spalin.

## Zabójstwo pięciolatka w Poznaniu. Jest decyzja ws. aresztu dla nożownika
 - [https://www.rp.pl/przestepczosc/art39299941-zabojstwo-pieciolatka-w-poznaniu-jest-decyzja-ws-aresztu-dla-nozownika](https://www.rp.pl/przestepczosc/art39299941-zabojstwo-pieciolatka-w-poznaniu-jest-decyzja-ws-aresztu-dla-nozownika)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:06:00+00:00

Zbysław C., któremu prokuratura stawia zarzut zabójstwa pięcioletniego chłopca w Poznaniu, został decyzją sądu tymczasowo aresztowany.

## Samorządy zapłacą więcej za tzw. radców z urzędu. Duża podwyżka stawek
 - [https://regiony.rp.pl/finanse-w-regionach/art39300031-samorzady-zaplaca-wiecej-za-tzw-radcow-z-urzedu-duza-podwyzka-stawek](https://regiony.rp.pl/finanse-w-regionach/art39300031-samorzady-zaplaca-wiecej-za-tzw-radcow-z-urzedu-duza-podwyzka-stawek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:05:41+00:00

Samorządy będą ponosić koszty nieopłaconej pomocy prawnej udzielonej przez radcę prawnego ustanowionego z urzędu - wynika z projektu rozporządzenia. Regulacja zakłada zrównanie stawek dla „radców z urzędu” ze stawkami radców z wyboru.

## Zmiana czasu 2023. Kiedy przestawić zegarek na czas zimowy?
 - [https://www.rp.pl/spoleczenstwo/art39299821-zmiana-czasu-2023-kiedy-przestawic-zegarek-na-czas-zimowy](https://www.rp.pl/spoleczenstwo/art39299821-zmiana-czasu-2023-kiedy-przestawic-zegarek-na-czas-zimowy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T09:05:00+00:00

Pod koniec października nastąpi zmiana czasu z letniego na czas zimowy. Kiedy dokładnie powinniśmy przestawić zegarki?

## Ta szwedzka marka motoryzacyjna miała być przełomowa. Teraz ogłosiła bankructwo
 - [https://moto.rp.pl/na-prad/art39299711-ta-szwedzka-marka-motoryzacyjna-miala-byc-przelomowa-teraz-oglosila-bankructwo](https://moto.rp.pl/na-prad/art39299711-ta-szwedzka-marka-motoryzacyjna-miala-byc-przelomowa-teraz-oglosila-bankructwo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:43:40+00:00

Szwedzka marka, która powstała w 2019 roku i otrzymała europejską homologację na elektryczną ciężarówkę, złożyła wniosek o upadłość. Decyzja jest efektem bankructwa dostawcy akumulatorów – firmy Proterra – która miała być kluczowa przy produkcji pojazdu.

## Pentagon: Chiny za siedem lat będą miały 1 000 głowic atomowych. Jest reakcja Chin
 - [https://www.rp.pl/dyplomacja/art39299671-pentagon-chiny-za-siedem-lat-beda-mialy-1-000-glowic-atomowych-jest-reakcja-chin](https://www.rp.pl/dyplomacja/art39299671-pentagon-chiny-za-siedem-lat-beda-mialy-1-000-glowic-atomowych-jest-reakcja-chin)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:36:32+00:00

Raport Pentagonu, z którego wynika, że Chiny będą miały ponad 1 000 głowic atomowych do 2030 roku, jest pełen "uprzedzeń i zniekształconych faktów" - oświadczyła rzeczniczka MSZ Chin, Mao Ning.

## Ziobro skarży do TK unijny zakaz sprzedaży aut spalinowych
 - [https://www.rp.pl/prawo-dla-ciebie/art39299721-ziobro-skarzy-do-tk-unijny-zakaz-sprzedazy-aut-spalinowych](https://www.rp.pl/prawo-dla-ciebie/art39299721-ziobro-skarzy-do-tk-unijny-zakaz-sprzedazy-aut-spalinowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:29:46+00:00

Minister Sprawiedliwości Zbigniew Ziobro poinformował o skierowaniu do Trybunału Konstytucyjnego wniosku o zbadanie legalności unijnych przepisów, wprowadzających zakaz sprzedaży nowych samochodów spalinowych w 2035 roku.

## Polacy kupują coraz mniej, szczególnie te produkty. Nowe dane GUS
 - [https://www.rp.pl/dane-gospodarcze/art39299741-polacy-kupuja-coraz-mniej-szczegolnie-te-produkty-nowe-dane-gus](https://www.rp.pl/dane-gospodarcze/art39299741-polacy-kupuja-coraz-mniej-szczegolnie-te-produkty-nowe-dane-gus)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:29:24+00:00

Sprzedaż detaliczna (w cenach stałych) spadła o 0,3 proc. r/r we wrześniu 2023 r. - podał Główny Urząd Statystyczny (GUS). W ujęciu miesięcznym odnotowano spadek o 0,3 proc.

## Wojewodowie ogłaszają nabory wniosków z funduszu autobusowego
 - [https://regiony.rp.pl/inwestycje/art39299701-wojewodowie-oglaszaja-nabory-wnioskow-z-funduszu-autobusowego](https://regiony.rp.pl/inwestycje/art39299701-wojewodowie-oglaszaja-nabory-wnioskow-z-funduszu-autobusowego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:21:10+00:00

Wojewodowie ogłaszają nabory wniosków o dopłatę w roku 2024 z Funduszu rozwoju przewozów autobusowych o charakterze użyteczności publicznej.

## Władimir Putin zorganizuje igrzyska. Świat sportu przed wielką próbą
 - [https://www.rp.pl/sport/art39294651-wladimir-putin-zorganizuje-igrzyska-swiat-sportu-przed-wielka-proba](https://www.rp.pl/sport/art39294651-wladimir-putin-zorganizuje-igrzyska-swiat-sportu-przed-wielka-proba)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:17:35+00:00

Władimir Putin, choć przez lata szedł pod rękę z Thomasem Bachem, atakuje dziś Międzynarodowy Komitet Olimpijski (MKOl), mówi o dyskryminacji i zapowiada własne igrzyska - dla połowy świata, już w przyszłym roku.

## Lubnauer: Im szybciej Tusk zostanie premierem, tym szybciej będą środki z KPO
 - [https://www.rp.pl/polityka/art39299661-lubnauer-im-szybciej-tusk-zostanie-premierem-tym-szybciej-beda-srodki-z-kpo](https://www.rp.pl/polityka/art39299661-lubnauer-im-szybciej-tusk-zostanie-premierem-tym-szybciej-beda-srodki-z-kpo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:16:00+00:00

Tym szybciej pieniądze z KPO mogą trafić do Polski, im szybciej Tusk zostanie nominowany przez prezydenta do utworzenia nowego rządu. Z tego prostego powodu, że tylko rząd i premier mogą wysłać wniosek o wypłatę tych pieniędzy. To jest jeszcze kolejny argument dla Andrzeja Dudy, żeby jak najszybciej powołał właśnie Donalda Tuska, a nie grał na czas - powiedziała w rozmowie z RMF FM Katarzyna Lubnauer.

## Ed Sheeran zagra w Polsce w 2024 r.
 - [https://www.rp.pl/muzyka-popularna/art39299481-ed-sheeran-zagra-w-polsce-w-2024-r](https://www.rp.pl/muzyka-popularna/art39299481-ed-sheeran-zagra-w-polsce-w-2024-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:15:41+00:00

Ed Sheeran zawita z trasą matematyczną „+ - = ÷ x” do Azji i Europy w 2024 roku. W Polsce zagra 12 lipca w Polsat Plus Arena Gdańsk.

## Antoni Dudek: Koniec prawicowej rewolucji. Jarosławowi Kaczyńskiemu zabrakło politycznej wyobraźni
 - [https://www.rp.pl/plus-minus/art39297541-antoni-dudek-koniec-prawicowej-rewolucji-jaroslawowi-kaczynskiemu-zabraklo-politycznej-wyobrazni](https://www.rp.pl/plus-minus/art39297541-antoni-dudek-koniec-prawicowej-rewolucji-jaroslawowi-kaczynskiemu-zabraklo-politycznej-wyobrazni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

Jarosławowi Kaczyńskiemu zabrakło politycznej wyobraźni. Do rewolucji, na jaką się porwał, nie wystarczy mieć tylko większości w Sejmie i worka publicznych pieniędzy - mówi Antoni Dudek, historyk i politolog.

## Kampania wyborcza pokazała, że niemożliwy jest powrót do polityki z lat 2015-2020
 - [https://www.rp.pl/plus-minus/art39297561-kampania-wyborcza-pokazala-ze-niemozliwy-jest-powrot-do-polityki-z-lat-2015-2020](https://www.rp.pl/plus-minus/art39297561-kampania-wyborcza-pokazala-ze-niemozliwy-jest-powrot-do-polityki-z-lat-2015-2020)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

Wygrywający PiS nie stworzy rządu, ale będzie szykował się do kontrofensywy. Jej rezultat będzie zależny od tego, jakie wnioski wyciągną doradcy prezesa Kaczyńskiego z kampanii, zaskakującej komentatorów oraz wyborców na tak wielu poziomach.

## Po wyborach tworzymy mity, a powinniśmy zderzyć się z rzeczywistością
 - [https://www.rp.pl/plus-minus/art39297581-po-wyborach-tworzymy-mity-a-powinnismy-zderzyc-sie-z-rzeczywistoscia](https://www.rp.pl/plus-minus/art39297581-po-wyborach-tworzymy-mity-a-powinnismy-zderzyc-sie-z-rzeczywistoscia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

Opozycja wcale nie musi spełnić zapowiadanych obietnic wyborczych, a dogadanie się z koalicjantami nie będzie proste. Nikt tak właściwie nie wie, jakie są plany Donalda Tuska. Jednak nie ma co się oszukiwać – PiS te wybory przegrał i będzie miał coraz mniejsze pole manewru.

## Prawo i Sprawiedliwość nigdy nie było partią katolicką
 - [https://www.rp.pl/plus-minus/art39297591-prawo-i-sprawiedliwosc-nigdy-nie-bylo-partia-katolicka](https://www.rp.pl/plus-minus/art39297591-prawo-i-sprawiedliwosc-nigdy-nie-bylo-partia-katolicka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

Przegrana PiS to wbrew pozorom ogromna szansa dla Kościoła. Im szybciej ołtarz oddzieli się od tronu, a duchowni i świeccy zrozumieją, że związek z prawicą szkodzi katolicyzmowi, tym lepiej dla przyszłości wiary.

## W internecie nie będzie kobiecej rewolucji
 - [https://www.rp.pl/plus-minus/art39297571-w-internecie-nie-bedzie-kobiecej-rewolucji](https://www.rp.pl/plus-minus/art39297571-w-internecie-nie-bedzie-kobiecej-rewolucji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

W erze prasy drukowanej i telewizji mogliśmy emocjonować się tym czy owym, ale w sposób konieczny nie mogło to trwać cały dzień. Wcześniej III Rzesza czy Związek Radziecki do mistrzostwa doprowadziły rytuały, które miały odciągnąć obywateli od refleksji politycznej. W dobie Twittera i TikToka bieżące tematy są tak absorbujące, że na ową refleksję brakuje nam już czasu.

## Zagraniczna prasa cieszy się ze zwycięstwa Donalda Tuska
 - [https://www.rp.pl/plus-minus/art39297601-zagraniczna-prasa-cieszy-sie-ze-zwyciestwa-donalda-tuska](https://www.rp.pl/plus-minus/art39297601-zagraniczna-prasa-cieszy-sie-ze-zwyciestwa-donalda-tuska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

Z pariasa Unii nasz kraj w jedną noc stał się kandydatem na jednego z rozgrywających we Wspólnocie. Z liberalnych kręgów na Zachodzie dobiega westchnienie ulgi. Unijnej centrali opłaciła się ryzykowna strategia obliczona na polityczną zmianę w Warszawie.

## Zaorać przeciwnika politycznego – jak polityka tożsamości zmienia zasady gry
 - [https://www.rp.pl/plus-minus/art39297611-zaorac-przeciwnika-politycznego-jak-polityka-tozsamosci-zmienia-zasady-gry](https://www.rp.pl/plus-minus/art39297611-zaorac-przeciwnika-politycznego-jak-polityka-tozsamosci-zmienia-zasady-gry)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T08:00:00+00:00

By zmienić wyborcę PiS-u w wyborcę PO, trzeba by starszego mieszkańca wsi zmienić w wykształconego prezesa dużej firmy w metropolii. Tego nie da się zrobić, bo trzeba by najpierw zmienić jego tożsamość.

## Włochy: Giorgia Meloni rozstała się z partnerem po 10 latach
 - [https://www.rp.pl/polityka/art39299461-wlochy-giorgia-meloni-rozstala-sie-z-partnerem-po-10-latach](https://www.rp.pl/polityka/art39299461-wlochy-giorgia-meloni-rozstala-sie-z-partnerem-po-10-latach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:58:00+00:00

"Moja relacja z Andreą Giambruno, która trwała niemal 10 lat, kończy się tutaj" - napisała na swoim profilu na Facebooku Giorgia Meloni, premier Włoch.

## Rusza Puchar Świata. Polscy łyżwiarze z nadzieją na medale
 - [https://www.rp.pl/sporty-zimowe/art39292991-rusza-puchar-swiata-polscy-lyzwiarze-z-nadzieja-na-medale](https://www.rp.pl/sporty-zimowe/art39292991-rusza-puchar-swiata-polscy-lyzwiarze-z-nadzieja-na-medale)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:55:50+00:00

Są nowe twarze, ale cele pozostają bez zmian. Reprezentacja Polski w short tracku zaczyna kolejny sezon, który zainauguruje Pucharem Świata w Montrealu. Plany są ambitne, choć tej zimy nie wystartuje Natalia Maliszewska.

## Kurs złotego na koniec tygodnia. Ile płacą za dolara i euro?
 - [https://www.rp.pl/waluty/art39299491-kurs-zlotego-na-koniec-tygodnia-ile-placa-za-dolara-i-euro](https://www.rp.pl/waluty/art39299491-kurs-zlotego-na-koniec-tygodnia-ile-placa-za-dolara-i-euro)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:48:46+00:00

W piątek z rana za dolara inwestorzy płacą 4,21 zł, a za euro 4,45 zł. Kursy obu walut są zbliżone do tych z czwartku.

## Polityk Koalicji Obywatelskiej zapowiada weryfikację tysięcy sędziów
 - [https://www.rp.pl/sady-i-trybunaly/art39299431-polityk-koalicji-obywatelskiej-zapowiada-weryfikacje-tysiecy-sedziow](https://www.rp.pl/sady-i-trybunaly/art39299431-polityk-koalicji-obywatelskiej-zapowiada-weryfikacje-tysiecy-sedziow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:42:55+00:00

Poseł Koalicji Obywatelskiej Arkadiusz Myrcha zapowiedział zmiany w Krajowej Radzie Sądownictwa, Sądzie Najwyższym i prokuraturze po przejęciu władzy przez dotychczasową opozycję. Będzie też weryfikacja powołań sędziowskich.

## USA: Będący na wymianie uczeń z Polski uratował życie szkolnemu koledze
 - [https://www.rp.pl/spoleczenstwo/art39299421-usa-bedacy-na-wymianie-uczen-z-polski-uratowal-zycie-szkolnemu-koledze](https://www.rp.pl/spoleczenstwo/art39299421-usa-bedacy-na-wymianie-uczen-z-polski-uratowal-zycie-szkolnemu-koledze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:38:00+00:00

W jednej z amerykańskich szkół, podczas gry w koszykówkę, licealista doznał nagłego zatrzymania akcji serca. Dwaj jego koledzy – w tym jeden uczeń pochodzący z Polski – udzielili chłopakowi pierwszej pomocy, dzięki czemu udało się uratować mu życie.

## Sztuczna inteligencja pomoże wybrać opcje przy konfiguracji Porsche
 - [https://moto.rp.pl/innowacje/art39299241-sztuczna-inteligencja-pomoze-wybrac-opcje-przy-konfiguracji-porsche](https://moto.rp.pl/innowacje/art39299241-sztuczna-inteligencja-pomoze-wybrac-opcje-przy-konfiguracji-porsche)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:26:30+00:00

Porsche wprowadziło w Polsce zmiany w konfiguratorze. Dzięki Prekonfiguracji oraz Narzędziu Rekomendacji Opcji skompletowanie idealnie dobranego wyposażenia jest teraz o wiele łatwiejsze. W wybraniu odpowiednich opcji klientów wspomaga sztuczna inteligencja.

## Smog znów truje Polskę. W niektórych przypadkach normy przekroczone o 1300 proc.
 - [https://klimat.rp.pl/klimat/art39296861-smog-znow-truje-polske-w-niektorych-przypadkach-normy-przekroczone-o-1300-proc](https://klimat.rp.pl/klimat/art39296861-smog-znow-truje-polske-w-niektorych-przypadkach-normy-przekroczone-o-1300-proc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:21:41+00:00

W nocy ze środy na czwartek w niektórych miejscach w kraju normy jakości powietrza zostały przekroczone o 1300 proc.

## Czas zakończyć spalanie lasów. Apel do spółek energetycznych i banków
 - [https://klimat.rp.pl/lasy/art39299371-czas-zakonczyc-spalanie-lasow-apel-do-spolek-energetycznych-i-bankow](https://klimat.rp.pl/lasy/art39299371-czas-zakonczyc-spalanie-lasow-apel-do-spolek-energetycznych-i-bankow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:21:12+00:00

Skończmy z nowymi inwestycjami w spalanie biomasy drzewnej w Polsce - aktywiści apelują do spółek energetycznych i banków.

## Senator z Lewicy nie chce odpowiedzieć na pytanie, czy Donald Tusk będzie premierem
 - [https://www.rp.pl/wybory/art39299281-senator-z-lewicy-nie-chce-odpowiedziec-na-pytanie-czy-donald-tusk-bedzie-premierem](https://www.rp.pl/wybory/art39299281-senator-z-lewicy-nie-chce-odpowiedziec-na-pytanie-czy-donald-tusk-bedzie-premierem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:19:53+00:00

- Nie tylko Lewica, ale też Koalicja Obywatelska obiecywały w czasie kampanii, że nic co zostało dane, nie będzie odebrane - mówiła w rozmowie z Jackiem Nizinkiewiczem Magdalena Biejat, wybrana do Senatu w ramach paktu senackiego, współprzewodnicząca Lewicy Razem.

## GIF pokazał oryginalny i fałszywy Ozempic. Zaleca czujność
 - [https://www.rp.pl/zdrowie/art39299221-gif-pokazal-oryginalny-i-falszywy-ozempic-zaleca-czujnosc](https://www.rp.pl/zdrowie/art39299221-gif-pokazal-oryginalny-i-falszywy-ozempic-zaleca-czujnosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:07:00+00:00

W legalnym łańcuchu dystrybucji na terenie Unii Europejskiej pojawiły się  fabrycznie napełnione wstrzykiwacze fałszywie oznaczone jako produkt  leczniczy Ozempic - ostrzega Główny Inspektor Farmaceutyczny i zaleca ostrożność podczas zakupu i stosowania tego bardzo popularnego leku na cukrzycę i otyłość.

## Mattia Preti – mistrz baroku z Malty w Łazienkach Królewskich w Warszawie
 - [https://www.rp.pl/malarstwo/art39299181-mattia-preti-mistrz-baroku-z-malty-w-lazienkach-krolewskich-w-warszawie](https://www.rp.pl/malarstwo/art39299181-mattia-preti-mistrz-baroku-z-malty-w-lazienkach-krolewskich-w-warszawie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T07:02:35+00:00

W Podchorążówce w Łazienkach można od dziś oglądać bogaty wybór prac znakomitego XVII-wiecznego artysty, powstałych we Włoszech, jak i na Malcie.

## Izrael ewakuuje mieszkańców z miasta przy granicy z Libanem
 - [https://www.rp.pl/konflikty-zbrojne/art39299211-izrael-ewakuuje-mieszkancow-z-miasta-przy-granicy-z-libanem](https://www.rp.pl/konflikty-zbrojne/art39299211-izrael-ewakuuje-mieszkancow-z-miasta-przy-granicy-z-libanem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T06:52:15+00:00

Ministerstwo Obrony Izraela poinformowało o rozpoczęciu ewakuacji z miasta Kirjat Szemona, na północy kraju, przy granicy z Libanem, w związku z rosnącym napięciem na granicy.

## Nowa płyta The Rolling Stones: Jagger jak Dawid Podsiadło, goście jak z „Misia” Barei
 - [https://www.rp.pl/muzyka-popularna/art39298951-nowa-plyta-the-rolling-stones-jagger-jak-dawid-podsiadlo-goscie-jak-z-misia-barei](https://www.rp.pl/muzyka-popularna/art39298951-nowa-plyta-the-rolling-stones-jagger-jak-dawid-podsiadlo-goscie-jak-z-misia-barei)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:56:11+00:00

„Hackney Diamonds” pierwszy od 18 lat nowy album The Rolling Stones to świetna płyta z drobnymi wyjątkami. O zespole z przeszłości, który nie chce odejść do historii.

## Izabela Leszczyna: PiS jeszcze rządzi, a PiS-owskie media już nas rozliczają
 - [https://www.rp.pl/wybory/art39298991-izabela-leszczyna-pis-jeszcze-rzadzi-a-pis-owskie-media-juz-nas-rozliczaja](https://www.rp.pl/wybory/art39298991-izabela-leszczyna-pis-jeszcze-rzadzi-a-pis-owskie-media-juz-nas-rozliczaja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:52:33+00:00

Trudno zrozumieć, że prezydent chce przegrać, tak spektakularnie przegrać - mówiła w rozmowie z TVN24 Izabela Leszczyna, posłanka Koalicji Obywatelskiej, wiceprzewodnicząca PO.

## "Stuu" w brytyjskim areszcie na podstawie decyzji sądu
 - [https://www.rp.pl/prawo-karne/art39298931-stuu-w-brytyjskim-areszcie-na-podstawie-decyzji-sadu](https://www.rp.pl/prawo-karne/art39298931-stuu-w-brytyjskim-areszcie-na-podstawie-decyzji-sadu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:40:00+00:00

Youtuber Stuart "Stuu" B. zamieszany w aferę "Pandora gate" trafił do aresztu na podstawie decyzji sądu w Wielkiej Brytanii.

## Prezydent Autonomii Palestyńskiej nie chciał odebrać telefonu od Bidena
 - [https://www.rp.pl/dyplomacja/art39298911-prezydent-autonomii-palestynskiej-nie-chcial-odebrac-telefonu-od-bidena](https://www.rp.pl/dyplomacja/art39298911-prezydent-autonomii-palestynskiej-nie-chcial-odebrac-telefonu-od-bidena)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:38:23+00:00

Mahmud Abbas, prezydent Autonomii Palestyńskiej, stojący na czele władz kontrolujących Zachodni Brzeg, odmówił odbycia rozmowy telefonicznej z Joe Bidenem w czasie, gdy ten przebywał z wizytą w Izraelu.

## NSA: częściowy cel publiczny nie pozbawia gminy preferencji w VAT
 - [https://www.rp.pl/finanse/art39296371-nsa-czesciowy-cel-publiczny-nie-pozbawia-gminy-preferencji-w-vat](https://www.rp.pl/finanse/art39296371-nsa-czesciowy-cel-publiczny-nie-pozbawia-gminy-preferencji-w-vat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:23:40+00:00

Wydatki inwestycyjne na stworzenie strefy aktywności gospodarczej dają prawo do odliczenia VAT.

## Dawid Milczarek: Wdrożenie obowiązkowego KSeF warto przesunąć
 - [https://www.rp.pl/opinie-prawne/art39296381-dawid-milczarek-wdrozenie-obowiazkowego-ksef-warto-przesunac](https://www.rp.pl/opinie-prawne/art39296381-dawid-milczarek-wdrozenie-obowiazkowego-ksef-warto-przesunac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:19:36+00:00

Setki tysięcy drobnych przedsiębiorców nie mają zapewne świadomości zbliżających się wyzwań.

## Młodzi prawnicy chcą więcej empatii w zarządzaniu kancelarią
 - [https://www.rp.pl/zawody-prawnicze/art39296341-mlodzi-prawnicy-chca-wiecej-empatii-w-zarzadzaniu-kancelaria](https://www.rp.pl/zawody-prawnicze/art39296341-mlodzi-prawnicy-chca-wiecej-empatii-w-zarzadzaniu-kancelaria)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:08:36+00:00

Młodzi prawnicy, którzy nie chcą pracować z zamkniętym w gabinecie szefem, wymusili zmiany w kancelariach.

## W PiS wskazują przyczyny wyborczej porażki: "Tłuste koty", "jedynki", Morawiecki
 - [https://www.rp.pl/wybory/art39298881-w-pis-wskazuja-przyczyny-wyborczej-porazki-tluste-koty-jedynki-morawiecki](https://www.rp.pl/wybory/art39298881-w-pis-wskazuja-przyczyny-wyborczej-porazki-tluste-koty-jedynki-morawiecki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T05:07:56+00:00

Jarosław Kaczyński wstrzymał personalne rozliczenia w PiS i wziął na siebie odpowiedzialność za wyborczy wynik partii, ale w PiS zbliża się czas rozliczeń - pisze Onet.

## Nie tak łatwo uniknąć ZUS od posiłku
 - [https://www.rp.pl/zus/art39296361-nie-tak-latwo-uniknac-zus-od-posilku](https://www.rp.pl/zus/art39296361-nie-tak-latwo-uniknac-zus-od-posilku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T04:57:09+00:00

Pracownik korzystający z bonów i kart żywieniowych może być obciążony nie tylko podatkiem, ale także składkami.

## Sędzia Sądu Najwyższego nie zdał testu bezstronności
 - [https://www.rp.pl/sady-i-trybunaly/art39296321-sedzia-sadu-najwyzszego-nie-zdal-testu-bezstronnosci](https://www.rp.pl/sady-i-trybunaly/art39296321-sedzia-sadu-najwyzszego-nie-zdal-testu-bezstronnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T04:52:14+00:00

Kolejny „nowy” sędzia powołany przy udziale obecnej Krajowej Rady Sądownictwa oblał test bezstronności i niezawisłości.

## Minister obrony Izraela do żołnierzy: Widzicie Gazę z daleka. Niedługo zobaczycie od środka
 - [https://www.rp.pl/konflikty-zbrojne/art39298861-minister-obrony-izraela-do-zolnierzy-widzicie-gaze-z-daleka-niedlugo-zobaczycie-od-srodka](https://www.rp.pl/konflikty-zbrojne/art39298861-minister-obrony-izraela-do-zolnierzy-widzicie-gaze-z-daleka-niedlugo-zobaczycie-od-srodka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T03:53:30+00:00

- Rozkaz przyjdzie - mówił izraelskim żołnierzom stacjonującym na granicy Strefy Gazy minister obrony Izraela, Jo'aw Gallant sugerując, że wkrótce rozpocznie się lądowa inwazja Izraela na Strefę Gazy.

## Amerykańscy żołnierze atakowani na Bliskim Wschodzie
 - [https://www.rp.pl/konflikty-zbrojne/art39298841-amerykanscy-zolnierze-atakowani-na-bliskim-wschodzie](https://www.rp.pl/konflikty-zbrojne/art39298841-amerykanscy-zolnierze-atakowani-na-bliskim-wschodzie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T03:33:09+00:00

W ostatnich dniach żołnierze USA stacjonujący w Syrii i Iraku byli kilkukrotnie celem ataków - informują przedstawiciele administracji USA.

## Joe Biden ostrzega: Jeśli Władimir Putin nie zostanie zatrzymany może zagrozić Polsce
 - [https://www.rp.pl/polityka/art39298821-joe-biden-ostrzega-jesli-wladimir-putin-nie-zostanie-zatrzymany-moze-zagrozic-polsce](https://www.rp.pl/polityka/art39298821-joe-biden-ostrzega-jesli-wladimir-putin-nie-zostanie-zatrzymany-moze-zagrozic-polsce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T03:11:03+00:00

W orędziu wygłoszonym w Gabinecie Owalnym Białego Domu prezydent USA Joe Biden oświadczył, że USA muszą zwiększyć wsparcie udzielane Ukrainie i Izraelowi, które są pogrążone w nieprzewidywalnych i krwawych wojnach.

## Wojna Rosji z Ukrainą. Dzień 604
 - [https://www.rp.pl/swiat/art39298801-wojna-rosji-z-ukraina-dzien-604](https://www.rp.pl/swiat/art39298801-wojna-rosji-z-ukraina-dzien-604)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T02:41:50+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski rozmawiał telefonicznie z Joe Bidenem o dalszym wsparciu militarnym USA dla Ukrainy.

## Wojna Rosji z Ukrainą. Dzień 604
 - [https://www.rp.pl/konflikty-zbrojne/art39298801-wojna-rosji-z-ukraina-dzien-604](https://www.rp.pl/konflikty-zbrojne/art39298801-wojna-rosji-z-ukraina-dzien-604)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T02:41:00+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski rozmawiał telefonicznie z Joe Bidenem o dalszym wsparciu militarnym USA dla Ukrainy.

## "Czas krwawego księżyca": Gdy chciwość usypia sumienie
 - [https://www.rp.pl/film/art39296421-czas-krwawego-ksiezyca-gdy-chciwosc-usypia-sumienie](https://www.rp.pl/film/art39296421-czas-krwawego-ksiezyca-gdy-chciwosc-usypia-sumienie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

W „Czasie krwawego księżyca” Scorsese o zbrodni wobec Indian De Niro, DiCaprio i Gladstone pokazują znakomitą aktorską formę.

## Amerykańskie obligacje sięgają rekordowych poziomów
 - [https://www.rp.pl/finanse/art39296991-amerykanskie-obligacje-siegaja-rekordowych-poziomow](https://www.rp.pl/finanse/art39296991-amerykanskie-obligacje-siegaja-rekordowych-poziomow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Dochodowość amerykańskich papierów dziesięcioletnich stała się najwyższa od 2007 r. W górę pnie się też ona dla długu krajów Europy Zachodniej i Japonii.

## Bardzo dziwny konkurs na dyrektora Teatru im. Słowackiego
 - [https://www.rp.pl/teatr/art39296431-bardzo-dziwny-konkurs-na-dyrektora-teatru-im-slowackiego](https://www.rp.pl/teatr/art39296431-bardzo-dziwny-konkurs-na-dyrektora-teatru-im-slowackiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

„Zbieram wszystkie dowody łamania prawa” – mówi Krzysztof Głuchowski, dyrektor Teatru im. Słowackiego, gdzie samorząd przeprowadza konkurs na dyrektora.

## Bezużyteczne prawo Jacka Sasina. Prawie nikt nie skorzystał z martwych przepisów
 - [https://www.rp.pl/abc-firmy/art39296351-bezuzyteczne-prawo-jacka-sasina-prawie-nikt-nie-skorzystal-z-martwych-przepisow](https://www.rp.pl/abc-firmy/art39296351-bezuzyteczne-prawo-jacka-sasina-prawie-nikt-nie-skorzystal-z-martwych-przepisow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

W ciągu roku od wejścia w życie reformy k.s.h. nie widać zainteresowania tworzeniem grup kapitałowych opartych na nowych regulacjach prawa holdingowego.

## Bezużyteczne prawo Jacka Sasina. Przez rok nikt nie skorzystał z martwych przepisów
 - [https://www.rp.pl/abc-firmy/art39296351-bezuzyteczne-prawo-jacka-sasina-przez-rok-nikt-nie-skorzystal-z-martwych-przepisow](https://www.rp.pl/abc-firmy/art39296351-bezuzyteczne-prawo-jacka-sasina-przez-rok-nikt-nie-skorzystal-z-martwych-przepisow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

W ciągu roku od wejścia w życie reformy k.s.h. nie powstała ani jedna grupa kapitałowa oparta na nowych regulacjach.

## Błaszczak nie przekonał cywilów do założenia munduru
 - [https://www.rp.pl/wojsko/art39296751-blaszczak-nie-przekonal-cywilow-do-zalozenia-munduru](https://www.rp.pl/wojsko/art39296751-blaszczak-nie-przekonal-cywilow-do-zalozenia-munduru)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Niewiele ponad trzy procent pracowników cywilnych wojska zdecydowało się nałożyć mundur wojskowy.

## Dodatkowe urlopy się nie przyjęły. Eksperci wskazują powody
 - [https://www.rp.pl/prawo-pracy/art39296311-dodatkowe-urlopy-sie-nie-przyjely-eksperci-wskazuja-powody](https://www.rp.pl/prawo-pracy/art39296311-dodatkowe-urlopy-sie-nie-przyjely-eksperci-wskazuja-powody)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Wolne z powodu działania siły wyższej oraz dodatkowy urlop opiekuńczy nie są wykorzystywane.

## E-sklepy uderzone spowolnieniem w sprzedaży
 - [https://www.rp.pl/handel/art39296941-e-sklepy-uderzone-spowolnieniem-w-sprzedazy](https://www.rp.pl/handel/art39296941-e-sklepy-uderzone-spowolnieniem-w-sprzedazy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Przeterminowane zadłużenie firm handlujących online przez rok wzrosło niemal dwa razy bardziej niż w handlu detalicznym i przekroczyło 400 mln zł.

## Eksperci alarmują: Wybory 2023 były pełne hejtu
 - [https://www.rp.pl/wybory/art39296721-eksperci-alarmuja-wybory-2023-byly-pelne-hejtu](https://www.rp.pl/wybory/art39296721-eksperci-alarmuja-wybory-2023-byly-pelne-hejtu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Jeszcze żadna kampania wyborcza nie obfitowała w tak wiele przypadków mowy nienawiści, co ta ostatnia – alarmują eksperci.

## Ewa Szadkowska: Wielka klapa prawa holdingowego. Biznes pokazał czerwoną kartkę Sasinowi
 - [https://www.rp.pl/opinie-prawne/art39296301-ewa-szadkowska-wielka-klapa-prawa-holdingowego-biznes-pokazal-czerwona-kartke-sasinowi](https://www.rp.pl/opinie-prawne/art39296301-ewa-szadkowska-wielka-klapa-prawa-holdingowego-biznes-pokazal-czerwona-kartke-sasinowi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Gdy za uszczęśliwianie przedsiębiorców zabierają się politycy, którzy nie mają pojęcia o tym, jak funkcjonują spółki, nie ma co liczyć na cuda. W przypadku prawa holdingowego cudem jest jednak to, że nikt nie ucierpiał.

## Krzysztof A. Kowalczyk: Z dziurą budżetową Morawieckiego poradzi sobie tylko silny minister finansów
 - [https://www.rp.pl/opinie-ekonomiczne/art39296871-krzysztof-a-kowalczyk-z-dziura-budzetowa-morawieckiego-poradzi-sobie-tylko-silny-minister-finansow](https://www.rp.pl/opinie-ekonomiczne/art39296871-krzysztof-a-kowalczyk-z-dziura-budzetowa-morawieckiego-poradzi-sobie-tylko-silny-minister-finansow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Wymagania, jakim musi sprostać nowy szef resortu finansów, są wysokie. Dlatego nie wyobrażam sobie, by był bez wpływu na politykę gospodarczą państwa, jak dziś.

## Kto niszczy gazociągi i kable na Bałtyku? Tajemnicze awarie
 - [https://www.rp.pl/konflikty-zbrojne/art39296591-kto-niszczy-gazociagi-i-kable-na-baltyku-tajemnicze-awarie](https://www.rp.pl/konflikty-zbrojne/art39296591-kto-niszczy-gazociagi-i-kable-na-baltyku-tajemnicze-awarie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Po zniszczeniu gazociągu Balticconnector oraz kabli telekomunikacyjnych łączących Estonię z Finlandią oraz Szwecją, na Bałtyku i Morzu Północnym trwają poszukiwania sprawców.

## Lewica za liberalizacją aborcji, TD za referendum
 - [https://www.rp.pl/polityka/art39296731-lewica-za-liberalizacja-aborcji-td-za-referendum](https://www.rp.pl/polityka/art39296731-lewica-za-liberalizacja-aborcji-td-za-referendum)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Będziemy obstawali – tak samo jak KO – przy liberalizacji prawa aborcyjnego – zapowiada w rozmowie #Rzeczopolityce Anna Górska, nowo wybrana senatorka z Lewicy.

## Ludovic Subran: Czy Niemcy mogą przeprowadzić reformy strukturalne
 - [https://www.rp.pl/opinie-ekonomiczne/art39296971-ludovic-subran-czy-niemcy-moga-przeprowadzic-reformy-strukturalne](https://www.rp.pl/opinie-ekonomiczne/art39296971-ludovic-subran-czy-niemcy-moga-przeprowadzic-reformy-strukturalne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Kluczowe pytanie dziś brzmi: czy niemieccy decydenci są w stanie wykazać się determinacją i wykorzystać obecny kryzys do przezwyciężenia problemów, które narosły w ostatnich dwóch dekadach?

## Michał Szułdrzyński: Dlaczego PiS chce ukraść opozycji miodowy miesiąc
 - [https://www.rp.pl/komentarze/art39296841-michal-szuldrzynski-pis-chce-ukrasc-opozycji-miodowy-miesiac](https://www.rp.pl/komentarze/art39296841-michal-szuldrzynski-pis-chce-ukrasc-opozycji-miodowy-miesiac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Choć zwycięska koalicja dostała historyczne 11,5 mln głosów i ma gigantyczny mandat demokratyczny, to PiS będzie kreować wrażenie chaosu, kłótni i napięć w jej obozie, by nowy rząd rozpoczął urzędowanie nie na fali powyborczego tryumfu, ale w zatrutej atmosferze.

## Nadciąga burzliwa jesień producentów gier. Na co czekają gracze?
 - [https://www.rp.pl/biznes/art39296931-nadciaga-burzliwa-jesien-producentow-gier-na-co-czekaja-gracze](https://www.rp.pl/biznes/art39296931-nadciaga-burzliwa-jesien-producentow-gier-na-co-czekaja-gracze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

W ostatnim czasie na globalny rynek trafiły premiery produkcji CD Projektu i CI Games, a przed nami premiery gier 11 bit studios i PlayWaya.

## Netflix znów rośnie jak w pandemii. Rosną też ceny, a abonenci płacą mniej
 - [https://www.rp.pl/media/art39296911-netflix-znow-rosnie-jak-w-pandemii-rosna-tez-ceny-a-abonenci-placa-mniej](https://www.rp.pl/media/art39296911-netflix-znow-rosnie-jak-w-pandemii-rosna-tez-ceny-a-abonenci-placa-mniej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Streamingowa platforma w trzy miesiące zyskała prawie 9 mln abonentów. Choć ciągle słychać, że podnosi ceny, to jej przeciętny abonent płaci mniej. To koszt walki ze spółdzielniami kont i rozwoju biznesu reklamowego.

## Orange Polska wyraźnie wyhamował. W czym leży problem firmy
 - [https://www.rp.pl/biznes/art39296921-orange-polska-wyraznie-wyhamowal-w-czym-lezy-problem-firmy](https://www.rp.pl/biznes/art39296921-orange-polska-wyraznie-wyhamowal-w-czym-lezy-problem-firmy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Problem firmy leży z jednej strony w spowolnieniu wzrostu wpływów ze sprzedaży smartfonów, a z drugiej w braku albo przesunięciu kontraktów informatycznych spółek należących do Orange Polska na IV kwartał.

## Pacjent ma prawo do dobrego menu
 - [https://www.rp.pl/diagnostyka-i-terapie/art39296411-pacjent-ma-prawo-do-dobrego-menu](https://www.rp.pl/diagnostyka-i-terapie/art39296411-pacjent-ma-prawo-do-dobrego-menu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Dobre odżywianie pacjenta ma kluczowe znaczenie dla przebiegu procesu leczenia szpitalnego.

## PiS zostawia finanse w marnym stanie. Rekordowa dziura i ogromny wzrost długu
 - [https://www.rp.pl/budzet-i-podatki/art39296881-pis-zostawia-finanse-w-marnym-stanie-rekordowa-dziura-i-ogromny-wzrost-dlugu](https://www.rp.pl/budzet-i-podatki/art39296881-pis-zostawia-finanse-w-marnym-stanie-rekordowa-dziura-i-ogromny-wzrost-dlugu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Kulejące dochody z podatków, ogromne wydatki sztywne i rekordowo wysoki deficyt – to kondycja finansów państwa, jaką zostawia swoim następcom obecna władza.

## Polskie firmy coraz bardziej cyfrowe. Zwłaszcza duże
 - [https://www.rp.pl/biznes/art39296901-polskie-firmy-coraz-bardziej-cyfrowe-zwlaszcza-duze](https://www.rp.pl/biznes/art39296901-polskie-firmy-coraz-bardziej-cyfrowe-zwlaszcza-duze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Pandemia wpłynęła na przyspieszenie cyfryzacji przedsiębiorstw nad Wisłą, ale nadal daleko im do Zachodu.

## Prezydenci bezrobotni, bo zostali parlamentarzystami
 - [https://www.rp.pl/wybory/art39296781-prezydenci-bezrobotni-bo-zostali-parlamentarzystami](https://www.rp.pl/wybory/art39296781-prezydenci-bezrobotni-bo-zostali-parlamentarzystami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Kilkunastu samorządowców odchodzi do Sejmu i Senatu. Skomplikowana sytuacja jest na Śląsku, bo wojewoda, który wyznacza komisarzy, również został parlamentarzystą.

## Rosja straszy Armenię. "Ukraina nr 3"
 - [https://www.rp.pl/polityka/art39296701-rosja-straszy-armenie-ukraina-nr-3](https://www.rp.pl/polityka/art39296701-rosja-straszy-armenie-ukraina-nr-3)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Władze w Erywaniu coraz bardziej sugerują, że chcą zbliżenia z Zachodem. W Moskwie Ormianom wróżą los Ukraińców.

## Rusza nowy sezon PlusLigi. Trudne życie gwiazd
 - [https://www.rp.pl/siatkowka/art39296391-rusza-nowy-sezon-plusligi-trudne-zycie-gwiazd](https://www.rp.pl/siatkowka/art39296391-rusza-nowy-sezon-plusligi-trudne-zycie-gwiazd)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Startuje nowy sezon PlusLigi. Faworyci są powszechnie znani, ale przynajmniej na początku rozgrywek nie powinno zabraknąć niespodzianek.

## Tragiczny wypadek na A1. Czy ktoś krył kierowcę?
 - [https://www.rp.pl/przestepczosc/art39296821-tragiczny-wypadek-na-a1-czy-ktos-kryl-kierowce](https://www.rp.pl/przestepczosc/art39296821-tragiczny-wypadek-na-a1-czy-ktos-kryl-kierowce)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Mogło dojść do nadużyć po tragedii na A1. Są bowiem dwie policyjne notatki, które wzajemnie sobie przeczą – ustaliła „Rz”.

## W MSZ strach przed resetem. Kto straci stanowisko?
 - [https://www.rp.pl/dyplomacja/art39296711-w-msz-strach-przed-resetem-kto-straci-stanowisko](https://www.rp.pl/dyplomacja/art39296711-w-msz-strach-przed-resetem-kto-straci-stanowisko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Ambasadorowie dzielą się na tych, których jeszcze chwilę obroni prezydent Duda, i tych, którzy tej osłony nie mają.

## Wielka gra wokół PSL. "Żadnych rozmów z PiS-em"
 - [https://www.rp.pl/wybory/art39296851-wielka-gra-wokol-psl-zadnych-rozmow-z-pis-em](https://www.rp.pl/wybory/art39296851-wielka-gra-wokol-psl-zadnych-rozmow-z-pis-em)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T01:00:00+00:00

Prawo i Sprawiedliwość nie poddaje się i podejmie próbę stworzenia rządu w pierwszym kroku konstytucyjnym. Potrzebuje jednak koalicjanta. Czy przekona część obecnej opozycji?

## Firma posiada nieruchomości rolne? Będą (większe) problemy
 - [https://www.rp.pl/finanse/art39291621-firma-posiada-nieruchomosci-rolne-beda-wieksze-problemy](https://www.rp.pl/finanse/art39291621-firma-posiada-nieruchomosci-rolne-beda-wieksze-problemy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T00:00:00+00:00

Nowelizacja ustawy o kształtowaniu ustroju rolnego, która weszła w życie 5 października, miała doprecyzować obowiązujące przepisy, ale zaostrzyła je ograniczając jeszcze bardziej obrót nieruchomościami rolnymi. Zmiany szczególnie odczują fundacje rodzinne i grupy kapitałowe. Nowe obowiązki ustawa nakłada też na notariuszy.

## Ograniczenia w zawieraniu umów z członkami zarządu w spółkach kapitałowych
 - [https://www.rp.pl/abc-firmy/art39291641-ograniczenia-w-zawieraniu-umow-z-czlonkami-zarzadu-w-spolkach-kapitalowych](https://www.rp.pl/abc-firmy/art39291641-ograniczenia-w-zawieraniu-umow-z-czlonkami-zarzadu-w-spolkach-kapitalowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T00:00:00+00:00

Przy zawieraniu umów pomiędzy spółką kapitałową, a członkami zarządu, spółkę powinna reprezentować rada nadzorcza lub pełnomocnik. Sankcją jest nieważność wadliwie podpisanej umowy.

## Przetargi pod lupą prokuratora
 - [https://www.rp.pl/abc-firmy/art39291631-przetargi-pod-lupa-prokuratora](https://www.rp.pl/abc-firmy/art39291631-przetargi-pod-lupa-prokuratora)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-20T00:00:00+00:00

Nowelizacja kodeksu karnego, która obowiązuje od 1 października br. wprowadziła istotne zmiany w zakresie przestępstw przetargowych. Pole kryminalizacji jest szersze, a kary surowsze. Zmiany rodzą bardzo duże ryzyka karnoprawne dla osób występujących w przetargach i postępowaniach o udzielenie zamówienia publicznego.

