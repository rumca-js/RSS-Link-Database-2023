# Source:LinuxGizmos.com, URL:https://linuxgizmos.com/feed/, language:en-US

## CanMV K230 features dual RISC-V processors and KPU
 - [https://linuxgizmos.com/canmv-k230-features-dual-risc-v-processors-and-kpu/](https://linuxgizmos.com/canmv-k230-features-dual-risc-v-processors-and-kpu/)
 - RSS feed: https://linuxgizmos.com/feed/
 - date published: 2023-10-20T05:59:44+00:00

AnalogLamb recently featured a new development platform powered by the Kendryte K230 chip which incorporates two RISC-V C908 cores and a new generation Knowledge Process Unit for AI computing. The Kendryte K230 aims for applications such as robotics, computer vision, and other smart applications. The product page indicates that the Kendryte K230 chip has the [&#8230;]

