# Source:RT - Daily news, URL:https://www.rt.com/rss/, language:en

## Confidence in US media hits record low – poll
 - [https://www.rt.com/news/585453-trust-media-gallup-record-low/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585453-trust-media-gallup-record-low/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T23:20:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65330a3385f540205c21e230.jpeg" style="margin-right: 10px;" /> Nearly 40% of Americans completely lack confidence in mainstream media, in levels of distrust not seen since 2016 <br /><a href="https://www.rt.com/news/585453-trust-media-gallup-record-low/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## White House proposes to cut Ukraine financial support
 - [https://www.rt.com/news/585447-ukraine-budget-funding-decrease/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585447-ukraine-budget-funding-decrease/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T22:01:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532f46e203027196c746a69.jpg" style="margin-right: 10px;" /> Kiev would have to make do with $275 million less each month while still getting US cash subsidies worth $11.7 billion <br /><a href="https://www.rt.com/news/585447-ukraine-budget-funding-decrease/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US Justice Dept recommends police hire former criminals
 - [https://www.rt.com/news/585449-justice-department-police-hire-criminals/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585449-justice-department-police-hire-criminals/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T21:40:59+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532f35d203027179f3f6540.jpeg" style="margin-right: 10px;" /> A criminal record or history of drug use shouldn’t disqualify a person from police work, the Department of Justice argued <br /><a href="https://www.rt.com/news/585449-justice-department-police-hire-criminals/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Lavrov explains how truth about Gaza hospital strike can be established
 - [https://www.rt.com/russia/585450-lavrov-truth-gaza-hospital-strike/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585450-lavrov-truth-gaza-hospital-strike/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T21:31:58+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532ef9b85f5402c8d3745fc.jpg" style="margin-right: 10px;" /> Russian Foreign Minister Sergey Lavrov has called on the US to release satellite images of a strike on a hospital in Gaza <br /><a href="https://www.rt.com/russia/585450-lavrov-truth-gaza-hospital-strike/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Scott Ritter: Both Hamas and Israel could have reasons to hide the truth about the Al-Ahli hospital blast
 - [https://www.rt.com/news/585443-gaza-hospital-strike-truth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585443-gaza-hospital-strike-truth/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T21:05:26+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532dcc220302719df3e93f4.jpg" style="margin-right: 10px;" /> A former UN weapons expert attempts to use evidence to dispel the fog of war and provide insight into the deadly attack <br /><a href="https://www.rt.com/news/585443-gaza-hospital-strike-truth/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state threatens to close Baltic Sea to Russian ships
 - [https://www.rt.com/news/585445-nato-latvia-baltic-blockade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585445-nato-latvia-baltic-blockade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T20:00:55+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532cb1a2030271f1e484b47.jpg" style="margin-right: 10px;" /> Latvia has proposed a naval blockade if Moscow is found to be behind the Balticonnector pipeline breach <br /><a href="https://www.rt.com/news/585445-nato-latvia-baltic-blockade/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Humans can’t live without war’, Christian patriarch laments
 - [https://www.rt.com/russia/585444-humans-live-without-war-patriarch/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585444-humans-live-without-war-patriarch/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T19:16:51+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532ccda2030272c5a51625e.jpg" style="margin-right: 10px;" /> Although wars appear to be a part of human nature, the world should try to minimize the suffering linked to them, Patriarch Kirill has said <br /><a href="https://www.rt.com/russia/585444-humans-live-without-war-patriarch/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Every Middle East agenda derailed by the Israel-Hamas conflict, explained
 - [https://www.rt.com/news/585439-israel-hamas-middle-east-agendas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585439-israel-hamas-middle-east-agendas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T19:01:21+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532ce3785f5403bdc00f34b.jpg" style="margin-right: 10px;" /> The war in West Asia puts the participants and their supporters, including those not involved, in a very difficult situation <br /><a href="https://www.rt.com/news/585439-israel-hamas-middle-east-agendas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Hamas releases American hostages
 - [https://www.rt.com/news/585441-hamas-releases-american-hostages/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585441-hamas-releases-american-hostages/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T18:45:40+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532c8462030271f1e484b3d.jpg" style="margin-right: 10px;" /> A Hamas spokesman has said that two American women were freed from captivity for “humanitarian reasons” <br /><a href="https://www.rt.com/news/585441-hamas-releases-american-hostages/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO state to pay Ukrainians to leave
 - [https://www.rt.com/news/585437-norway-ukraine-refugee-cash/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585437-norway-ukraine-refugee-cash/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T18:10:09+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532b0f485f54031bd7ce54a.jpg" style="margin-right: 10px;" /> Norway has offered repatriation assistance of over $1,500 in cash to those who return to Ukraine voluntarily <br /><a href="https://www.rt.com/news/585437-norway-ukraine-refugee-cash/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France evacuates airports over hoax bomb threats – media
 - [https://www.rt.com/news/585440-france-evacuates-airports-bomb-hoaxes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585440-france-evacuates-airports-bomb-hoaxes/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T17:47:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532bce5203027120c595d2c.jpg" style="margin-right: 10px;" /> At least eight French airports were forced to evacuate after receiving bomb threats <br /><a href="https://www.rt.com/news/585440-france-evacuates-airports-bomb-hoaxes/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ex-Soviet state announces nuclear war preparations
 - [https://www.rt.com/russia/585436-georgia-prepares-nuclear-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585436-georgia-prepares-nuclear-war/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T16:28:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532a48a85f54038157d2faf.jpg" style="margin-right: 10px;" /> Georgia says it has developed a plan and prescribed special procedures in case of a possible use of nuclear weapons in the region  <br /><a href="https://www.rt.com/russia/585436-georgia-prepares-nuclear-war/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China ‘rapidly’ expanding its nuclear arsenal – Pentagon
 - [https://www.rt.com/news/585434-china-nuclear-weapons-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585434-china-nuclear-weapons-report/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T16:25:25+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532a1c920302719df3e93c2.jpg" style="margin-right: 10px;" /> China has expanded its nuclear arsenal faster than the US predicted and now has 500 warheads, according to a new Pentagon report <br /><a href="https://www.rt.com/news/585434-china-nuclear-weapons-report/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel will launch ground invasion of Gaza – ambassador
 - [https://www.rt.com/news/585435-israel-ground-invasion-gaza-ambassador/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585435-israel-ground-invasion-gaza-ambassador/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T16:10:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532a25985f540205c21e20e.jpg" style="margin-right: 10px;" /> Israel has already made the decision to launch a ground operation in Gaza, its envoy to Moscow has said <br /><a href="https://www.rt.com/news/585435-israel-ground-invasion-gaza-ambassador/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kremlin denies campaign to persecute US citizens
 - [https://www.rt.com/russia/585422-no-persecution-us-citizens-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585422-no-persecution-us-citizens-russia/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T15:00:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/653289c585f5402c262b127b.jpg" style="margin-right: 10px;" /> Russia is not involved in any crackdown on US citizens but will take action against those who break the law, the Kremlin has said <br /><a href="https://www.rt.com/russia/585422-no-persecution-us-citizens-russia/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Fueling Africa: How cooking gas can reshape the post-colonial economy
 - [https://www.rt.com/africa/585409-africa-energy-security-gas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/585409-africa-energy-security-gas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T14:48:46+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65326d8985f5401b823ae3b4.jpg" style="margin-right: 10px;" /> LPG can play an important role in ensuring the energy security of Africa. But first, postcolonial economic models need to be restructured <br /><a href="https://www.rt.com/africa/585409-africa-energy-security-gas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia charges Canadian parliament SS Nazi with ‘genocide’
 - [https://www.rt.com/russia/585425-russia-charges-canadian-nazi/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585425-russia-charges-canadian-nazi/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T14:47:27+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532919485f54031bd7ce53a.jpg" style="margin-right: 10px;" /> Russian investigators have found evidence that Yaroslav Hunka took part in ethnic cleansing while serving in the SS Galicia unit in Ukraine <br /><a href="https://www.rt.com/russia/585425-russia-charges-canadian-nazi/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Palestinian leader refused Biden phone call – media
 - [https://www.rt.com/news/585423-abbas-refused-biden-call/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585423-abbas-refused-biden-call/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T14:28:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65328d1c85f5406c2a3b62ab.jpg" style="margin-right: 10px;" /> Palestinian Authority President Mahmoud Abbas reportedly turned down an offer of a phone call from US President Joe Biden on Wednesday <br /><a href="https://www.rt.com/news/585423-abbas-refused-biden-call/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Assange to become honorary citizen of major EU capital – officials
 - [https://www.rt.com/news/585419-assange-become-honorary-citizen-rome/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585419-assange-become-honorary-citizen-rome/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T14:10:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532894f85f54031bd7ce535.jpg" style="margin-right: 10px;" /> Imprisoned WikiLeaks founder Julian Assange will receive honorary citizenship of Rome, a city councilor has said <br /><a href="https://www.rt.com/news/585419-assange-become-honorary-citizen-rome/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Chinese firm to build major oil refinery in Angola – Bloomberg
 - [https://www.rt.com/africa/585418-china-angola-oil-refinery/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/585418-china-angola-oil-refinery/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T14:05:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65327ece85f540205c21e1fe.jpg" style="margin-right: 10px;" /> Angola will reportedly sign a $6 billion deal with China on the construction of the Lobito oil refinery <br /><a href="https://www.rt.com/africa/585418-china-angola-oil-refinery/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Instagram apologizes for branding Palestinians as ‘terrorists’
 - [https://www.rt.com/news/585417-instagram-palestinian-bio-terrorists/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585417-instagram-palestinian-bio-terrorists/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T13:37:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65327cc320302737572cdb92.jpg" style="margin-right: 10px;" /> Instagram’s parent company has apologized for mistranslating some profile bios into messages of support for “Palestinian terrorists” <br /><a href="https://www.rt.com/news/585417-instagram-palestinian-bio-terrorists/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Timofey Bordachev: Poland’s election was meaningless, because the US controls the country
 - [https://www.rt.com/news/585414-poland-election-us-control/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585414-poland-election-us-control/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T13:15:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532747320302721277049ce.jpg" style="margin-right: 10px;" /> It doesn't matter who runs the government in Warsaw; what matters is who is really in control <br /><a href="https://www.rt.com/news/585414-poland-election-us-control/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Kremlin blasts Biden’s Putin-Hamas comparison
 - [https://www.rt.com/russia/585413-peskov-biden-putin-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585413-peskov-biden-putin-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T13:11:23+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/653271a42030271d424497b6.jpg" style="margin-right: 10px;" /> Kremlin spokesman Dmitry Peskov has responded after US President Joe Biden vowed to fight Hamas and Vladimir Putin <br /><a href="https://www.rt.com/russia/585413-peskov-biden-putin-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Ousted Nigerien president attempts escape – coup leaders
 - [https://www.rt.com/africa/585412-niger-deposed-president-escape-attempt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/585412-niger-deposed-president-escape-attempt/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T13:06:32+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532774985f54031bd7ce52a.jpg" style="margin-right: 10px;" /> The coup leaders in Niger said they foiled an escape attempt by ousted President Mohamed Bazoum and his family <br /><a href="https://www.rt.com/africa/585412-niger-deposed-president-escape-attempt/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel moves closer to blocking Al Jazeera
 - [https://www.rt.com/news/585415-israel-regulation-blocking-aljazeera/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585415-israel-regulation-blocking-aljazeera/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T12:47:56+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532759320302713452eb712.jpg" style="margin-right: 10px;" /> The Israeli government has approved regulations that could allow it to block Al Jazeera over alleged “propaganda” <br /><a href="https://www.rt.com/news/585415-israel-regulation-blocking-aljazeera/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Another rating agency mulls downgrading Israel
 - [https://www.rt.com/business/585407-moodys-mulls-israel-downgrade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/585407-moodys-mulls-israel-downgrade/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T12:16:19+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532692d20302714f321ca64.jpg" style="margin-right: 10px;" /> Moody’s has placed Israel’s A1 rating on negative review amid the escalation of hostilities in Gaza <br /><a href="https://www.rt.com/business/585407-moodys-mulls-israel-downgrade/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## French government blasts football star over Gaza support
 - [https://www.rt.com/news/585408-french-football-gaza-support/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585408-french-football-gaza-support/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T11:27:03+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532609d85f5402c262b126f.jpg" style="margin-right: 10px;" /> Karim Benzema has been accused of having ties to the Muslim Brotherhood, a group considered a terrorist organization in France <br /><a href="https://www.rt.com/news/585408-french-football-gaza-support/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Turkish councilman praises Hitler for killing Jews
 - [https://www.rt.com/news/585405-turkish-politician-praises-hitler/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585405-turkish-politician-praises-hitler/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T11:17:28+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532617f85f540205c21e1f6.jpg" style="margin-right: 10px;" /> Turkish politician Suleyman Sezen has praised Hitler for the Holocaust and said he wants the world to be “cleansed of Jews” <br /><a href="https://www.rt.com/news/585405-turkish-politician-praises-hitler/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## New Delhi to continue humanitarian aid to Palestine
 - [https://www.rt.com/india/585406-india-humanitarian-aid-palestine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/585406-india-humanitarian-aid-palestine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T11:12:12+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65325fef85f54038157d2f7d.jpg" style="margin-right: 10px;" /> Indian PM Narendra Modi promised to continue supporting the Palestinian people in a call with Palestinian President Mahmoud Abbas <br /><a href="https://www.rt.com/india/585406-india-humanitarian-aid-palestine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian tech giant boosted by EU’s Google crackdown – Bloomberg
 - [https://www.rt.com/business/585399-yandex-eu-regulation-google/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/585399-yandex-eu-regulation-google/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T11:07:36+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532485c85f5402c262b1265.jpg" style="margin-right: 10px;" /> Yandex has become one of the five most popular search engines among Android smartphone users in the EU, Bloomberg reports <br /><a href="https://www.rt.com/business/585399-yandex-eu-regulation-google/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russian theater artists coming to Senegal
 - [https://www.rt.com/africa/585392-russia-gitis-senegal-theatre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/585392-russia-gitis-senegal-theatre/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T11:03:13+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65323eb485f5402c8d37459e.jpg" style="margin-right: 10px;" /> The Russian Institute of Theater Arts and the Grand Theater of Dakar have signed a cooperation agreement <br /><a href="https://www.rt.com/africa/585392-russia-gitis-senegal-theatre/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## NATO envoys hold ‘emergency meeting’ over Putin-Orban talks – media
 - [https://www.rt.com/news/585404-nato-envoys-emergency-meeting/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585404-nato-envoys-emergency-meeting/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T10:33:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/653256982030271f1e484b0d.jpg" style="margin-right: 10px;" /> NATO ambassadors have held a meeting in Budapest to reportedly discuss “security concerns” <br /><a href="https://www.rt.com/news/585404-nato-envoys-emergency-meeting/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## France and Nigeria hold joint naval exercises in Gulf of Guinea
 - [https://www.rt.com/africa/585402-france-nigeria-joint-naval-drills/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/africa/585402-france-nigeria-joint-naval-drills/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T10:00:50+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65324e8820302717b5634c25.jpg" style="margin-right: 10px;" /> The French Navy and Nigerian Navy joined forces to combat piracy and trafficking in the Gulf of Guinea <br /><a href="https://www.rt.com/africa/585402-france-nigeria-joint-naval-drills/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Putin visits military HQ in southern Russia
 - [https://www.rt.com/russia/585397-putin-rostov-military-hq-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/russia/585397-putin-rostov-military-hq-ukraine/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T09:50:43+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532441a85f54038157d2f76.png" style="margin-right: 10px;" /> Vladimir Putin met with top military commanders at an HQ in Rostov-on-Don amid the Ukraine conflict <br /><a href="https://www.rt.com/russia/585397-putin-rostov-military-hq-ukraine/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## China ratchets up US securities sell-off
 - [https://www.rt.com/business/585345-china-dumping-us-investments/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/585345-china-dumping-us-investments/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T09:39:54+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65316f9185f540244744faa1.jpg" style="margin-right: 10px;" /> Chinese investors sold $5.1 billion of American stocks and bonds in August, the highest in four years <br /><a href="https://www.rt.com/business/585345-china-dumping-us-investments/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US State Department arms transfers chief resigns over Israel
 - [https://www.rt.com/news/585396-state-department-resignation-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585396-state-department-resignation-israel/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T09:35:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532453d85f5406c2a3b628c.jpg" style="margin-right: 10px;" /> An open resignation letter by a senior US State Department official supervising arms transfers has denounced Washington’s Israel policy <br /><a href="https://www.rt.com/news/585396-state-department-resignation-israel/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Canada withdraws 41 diplomats from India amid deepening diplomatic row
 - [https://www.rt.com/india/585395-india-canada-withdraw-diplomats/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/india/585395-india-canada-withdraw-diplomats/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T09:04:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/653241e085f5406c2a3b6287.jpg" style="margin-right: 10px;" /> India’s decision will “impact levels of services to citizens of both countries,” Ottawa stated <br /><a href="https://www.rt.com/india/585395-india-canada-withdraw-diplomats/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US sets off underground blast amid ‘global nuclear threats’
 - [https://www.rt.com/news/585390-us-underground-explosion-nevada/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585390-us-underground-explosion-nevada/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T08:25:30+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532288b203027376650e3d1.jpg" style="margin-right: 10px;" /> The US Department of Energy has reported an experiment at a nuclear testing site in Nevada <br /><a href="https://www.rt.com/news/585390-us-underground-explosion-nevada/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US shaping Israel’s ground campaign against Hamas – Bloomberg
 - [https://www.rt.com/news/585393-us-shaping-israel-ground-campaign-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585393-us-shaping-israel-ground-campaign-hamas/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T07:25:17+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65322ae720302717b5634c14.jpg" style="margin-right: 10px;" /> The US is pressuring Israel to change its war plans over fears of a major escalation in the Middle East, Bloomberg has reported <br /><a href="https://www.rt.com/news/585393-us-shaping-israel-ground-campaign-hamas/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Finnish tech giant announces massive job cuts
 - [https://www.rt.com/business/585347-nokia-job-cuts-profit-plunge/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/585347-nokia-job-cuts-profit-plunge/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T05:09:16+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65316f3785f5400c8e5f4ee6.jpg" style="margin-right: 10px;" /> Nokia announced a major overhaul of its business that includes slashing up to 14,000 workers to reduce costs <br /><a href="https://www.rt.com/business/585347-nokia-job-cuts-profit-plunge/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Russia to boost gas supplies to China – Gazprom
 - [https://www.rt.com/business/585340-gazprom-russia-gas-supplies-china/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/business/585340-gazprom-russia-gas-supplies-china/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T05:09:08+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6531393320302733a6510ad7.jpg" style="margin-right: 10px;" /> Russia will provide additional volumes of gas to China this year under a new deal between Gazprom and CNPC <br /><a href="https://www.rt.com/business/585340-gazprom-russia-gas-supplies-china/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Israel recalls all diplomats from NATO country – media
 - [https://www.rt.com/news/585387-israel-diplomats-nato-country/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585387-israel-diplomats-nato-country/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T04:41:10+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/65320358203027294a1ab0b4.jpg" style="margin-right: 10px;" /> Israel has pulled its diplomats from Türkiye amid fears of violent reprisals due to ongoing fighting in Gaza, multiple news outlets reported <br /><a href="https://www.rt.com/news/585387-israel-diplomats-nato-country/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## MTV award show canceled over security fears
 - [https://www.rt.com/pop-culture/585386-mtv-music-show-canceled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/pop-culture/585386-mtv-music-show-canceled/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T04:22:42+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6532002f85f5401ee823a38c.jpg" style="margin-right: 10px;" /> The MTV Europe Music Awards show in France has been scrapped due to security fears <br /><a href="https://www.rt.com/pop-culture/585386-mtv-music-show-canceled/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## Biden to request ‘urgent’ aid for Israel and Ukraine
 - [https://www.rt.com/news/585384-biden-israel-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585384-biden-israel-ukraine-aid/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T03:03:38+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6531ebc72030272a44530460.jpg" style="margin-right: 10px;" /> US President Joe Biden said he will ask Congress to approve an “unprecedented” military aid package for Israel and Ukraine <br /><a href="https://www.rt.com/news/585384-biden-israel-ukraine-aid/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## ‘Don’t be blinded by rage’, Biden tells Israel
 - [https://www.rt.com/news/585383-biden-israel-blind-rage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585383-biden-israel-blind-rage/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T02:16:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6531e24120302745896dc2d8.jpg" style="margin-right: 10px;" /> US President Joe Biden has urged Israel not to become “blinded by rage” during its hostilities with Hamas <br /><a href="https://www.rt.com/news/585383-biden-israel-blind-rage/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## How the EU discredited itself in the Israel-Palestine conflict
 - [https://www.rt.com/news/585370-eu-israel-palestine-leyen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585370-eu-israel-palestine-leyen/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T01:19:31+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6531d5472030272cfe72b3fe.jpg" style="margin-right: 10px;" /> The European Union’s early reaction to the war raging in the Middle East only served the US’ disruptive interests <br /><a href="https://www.rt.com/news/585370-eu-israel-palestine-leyen/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

## US warship shoots down missiles, drones near Israel – Pentagon
 - [https://www.rt.com/news/585379-us-ship-intercepts-missiles/?utm_source=rss&utm_medium=rss&utm_campaign=RSS](https://www.rt.com/news/585379-us-ship-intercepts-missiles/?utm_source=rss&utm_medium=rss&utm_campaign=RSS)
 - RSS feed: https://www.rt.com/rss/
 - date published: 2023-10-20T00:38:00+00:00

<img align="left" alt="Preview" src="https://mf.b37mrtl.ru/files/2023.10/thumbnail/6531cb9d85f540176d2fb7c9.jpg" style="margin-right: 10px;" /> A US naval vessel intercepted several missiles and drones in the Middle East <br /><a href="https://www.rt.com/news/585379-us-ship-intercepts-missiles/?utm_source=rss&amp;utm_medium=rss&amp;utm_campaign=RSS">Read Full Article at RT.com</a>

