# Source:Argentina - Buenos Aires Times, URL:https://www.batimes.com.ar/feed, language:en

## Pumas out of Rugby World Cup after semi-final defeat to New Zealand
 - [https://www.batimes.com.ar/news/sports/pumas-out-of-rugby-world-cup-after-semi-final-defeat-to-new-zealand.phtml](https://www.batimes.com.ar/news/sports/pumas-out-of-rugby-world-cup-after-semi-final-defeat-to-new-zealand.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T21:11:49+00:00

<p><img alt="argentina new zealand rugby world cup" src="https://fotos.perfil.com/2023/10/20/trim/540/304/argentina-new-zealand-rugby-world-cup-1679801.jpg" /></p>New Zealand have booked themselves a place in the Rugby World Cup final after outclassing Argentina 44-6 in Paris.
 <a href="https://www.batimes.com.ar/news/sports/pumas-out-of-rugby-world-cup-after-semi-final-defeat-to-new-zealand.phtml">Leer más</a>

## The conflict in the Middle East is not a war between Muslims and Jews
 - [https://www.batimes.com.ar/news/opinion-and-analysis/the-conflict-in-the-middle-east-is-not-a-war-between-muslims-and-jews.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/the-conflict-in-the-middle-east-is-not-a-war-between-muslims-and-jews.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T20:50:24+00:00

<p><img alt="Prayers for peace." src="https://fotos.perfil.com/2023/10/20/trim/540/304/prayers-for-peace-1679785.jpg" /></p>The conflict between Hamas and Israel is not a war between Muslims and Jews. Both Judaism and Islam are not a threat to each other's existence but are guarantors of universal brotherhood and peaceful coexistence. <a href="https://www.batimes.com.ar/news/opinion-and-analysis/the-conflict-in-the-middle-east-is-not-a-war-between-muslims-and-jews.phtml">Leer más</a>

## Argentina depletes room to intervene in currency futures ahead of election
 - [https://www.batimes.com.ar/news/economy/argentina-depletes-room-to-intervene-in-currency-futures-ahead-of-election.phtml](https://www.batimes.com.ar/news/economy/argentina-depletes-room-to-intervene-in-currency-futures-ahead-of-election.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T19:47:07+00:00

<p><img alt="Central Bank stock" src="https://fotos.perfil.com/2023/08/16/trim/540/304/central-bank-stock-1633681.jpg" /></p>Central Bank almost out of room to intervene in currency futures, the main avenue it’s been using to prop up the plunging peso. <a href="https://www.batimes.com.ar/news/economy/argentina-depletes-room-to-intervene-in-currency-futures-ahead-of-election.phtml">Leer más</a>

## What you need to know about the election in Buenos Aires City
 - [https://www.batimes.com.ar/news/argentina/what-you-need-to-know-about-the-election-in-buenos-aires-city.phtml](https://www.batimes.com.ar/news/argentina/what-you-need-to-know-about-the-election-in-buenos-aires-city.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T19:28:01+00:00

<p><img alt="Candidates to be the next mayor of Buenos Aires City line up onstage ahead of the first televised debate." src="https://fotos.perfil.com/2023/09/28/trim/540/304/candidates-to-be-the-next-mayor-of-buenos-aires-city-line-up-onstage-ahead-of-the-first-televised-debate-1664104.jpeg" /></p>Unlike the PASO primaries, people in Buenos Aires will vote for local positions with a paper ballot, just as they will nationwide. <a href="https://www.batimes.com.ar/news/argentina/what-you-need-to-know-about-the-election-in-buenos-aires-city.phtml">Leer más</a>

## Argentina's electoral curfew kicks in of general election
 - [https://www.batimes.com.ar/news/argentina/electoral-curfew-starts-ahead-of-the-general-election.phtml](https://www.batimes.com.ar/news/argentina/electoral-curfew-starts-ahead-of-the-general-election.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T18:41:49+00:00

<p><img alt="Argentina election 2023." src="https://fotos.perfil.com/2023/10/20/trim/540/304/argentina-election-2023-1679558.jpg" /></p>Candidates may not conduct any rallies or publish campaign messages. What are the limits for members of the public and the penalties for non-compliance with the curfew. <a href="https://www.batimes.com.ar/news/argentina/electoral-curfew-starts-ahead-of-the-general-election.phtml">Leer más</a>

## What we learned this week: October 13 to 20
 - [https://www.batimes.com.ar/news/argentina/what-we-learned-this-week-review-october-13-to-20.phtml](https://www.batimes.com.ar/news/argentina/what-we-learned-this-week-review-october-13-to-20.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T17:54:39+00:00

<p><img alt="buenos aires skyline, centre, 9 de julio" src="https://fotos.perfil.com/2023/10/20/trim/540/304/buenos-aires-skyline-centre-9-de-julio-1679553.jpg" /></p>A selection of the stories – and one story in particular – that caught our eye this week.  <a href="https://www.batimes.com.ar/news/argentina/what-we-learned-this-week-review-october-13-to-20.phtml">Leer más</a>

## Trash is a lifeline for ‘los cartoneros,’ Argentina’s army of recyclers
 - [https://www.batimes.com.ar/news/argentina/trash-is-a-lifeline-for-los-cartoneros-argentinas-army-of-recyclers.phtml](https://www.batimes.com.ar/news/argentina/trash-is-a-lifeline-for-los-cartoneros-argentinas-army-of-recyclers.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T13:52:00+00:00

<p><img alt="cartoneros Sabrina Sosa and Ayelen Torres" src="https://fotos.perfil.com/2023/10/19/trim/540/304/cartoneros-sabrina-sosa-and-ayelen-torres-1678372.jpg" /></p>Argentina’s ‘cartoneros’ emerged in 2001, when the country experienced the worst economic, social and political crisis in recent history. Today, more than 150,000 people face the daily struggle of recycling rubbish in a nation stricken by crisis. <a href="https://www.batimes.com.ar/news/argentina/trash-is-a-lifeline-for-los-cartoneros-argentinas-army-of-recyclers.phtml">Leer más</a>

## Here are the assets to watch ahead of Argentina’s presidential election
 - [https://www.batimes.com.ar/news/economy/here-are-the-assets-to-watch-ahead-of-argentinas-presidential-election.phtml](https://www.batimes.com.ar/news/economy/here-are-the-assets-to-watch-ahead-of-argentinas-presidential-election.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T10:41:00+00:00

<p><img alt="Argentina goes to the polls stock" src="https://fotos.perfil.com/2023/10/20/trim/540/304/argentina-goes-to-the-polls-stock-1679547.jpg" /></p>Investors in Argentine assets are bracing for losses ahead of Sunday’s presidential election, with uncertainty high as voters grapple with triple-digit inflation and economic gloom. Here are key assets to watch ahead of the vote. <a href="https://www.batimes.com.ar/news/economy/here-are-the-assets-to-watch-ahead-of-argentinas-presidential-election.phtml">Leer más</a>

## Argentina prepares to step into the unknown
 - [https://www.batimes.com.ar/news/opinion-and-analysis/argentina-prepares-to-step-into-the-unknown.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/argentina-prepares-to-step-into-the-unknown.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T10:28:00+00:00

<p><img alt="Presidential candidate Javier Milei" src="https://fotos.perfil.com/2023/10/20/trim/540/304/presidential-candidate-javier-milei-1679588.jpg" /></p>Nation heads to the polls for a crucial election that will define the country’s immediate and economic future. One thing’s for certain, it certainly won’t be boring. <a href="https://www.batimes.com.ar/news/opinion-and-analysis/argentina-prepares-to-step-into-the-unknown.phtml">Leer más</a>

## Judgement Day finally arrives
 - [https://www.batimes.com.ar/news/opinion-and-analysis/judgement-day-finally-arrives.phtml](https://www.batimes.com.ar/news/opinion-and-analysis/judgement-day-finally-arrives.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T08:11:00+00:00

<p><img alt="Time to break the piggy bank?" src="https://fotos.perfil.com/2023/10/20/trim/540/304/time-to-break-the-piggy-bank-1679578.jpg" /></p>Nobody has much idea as to which of the three main contenders will come first or second, but all conceivable outcomes look likely to make a terrible situation even worse. <a href="https://www.batimes.com.ar/news/opinion-and-analysis/judgement-day-finally-arrives.phtml">Leer más</a>

## Five candidates for the Casa Rosada
 - [https://www.batimes.com.ar/news/argentina/five-candidates-for-the-casa-rosada.phtml](https://www.batimes.com.ar/news/argentina/five-candidates-for-the-casa-rosada.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T03:29:23+00:00

<p><img alt="Patricia Bullrich, Sergio Massa, Javier Milei, Juan Schiaretti, Myriam Bregman" src="https://fotos.perfil.com/2023/10/20/trim/540/304/patricia-bullrich-sergio-massa-javier-milei-juan-schiaretti-myriam-bregman-1679166.jpg" /></p>Javier Milei, Sergio Massa, Patricia Bullrich, Juan Schiaretti, Myriam Bregman… one of these individuals will be Argentina’s next president. Who are they and what do they stand for? <a href="https://www.batimes.com.ar/news/argentina/five-candidates-for-the-casa-rosada.phtml">Leer más</a>

## ‘He will win, I feel it’ – Milei supporters dare to dream as election nears
 - [https://www.batimes.com.ar/news/argentina/he-will-win-i-feel-it-milei-supporters-dare-to-dream-as-election-nears.phtml](https://www.batimes.com.ar/news/argentina/he-will-win-i-feel-it-milei-supporters-dare-to-dream-as-election-nears.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T02:12:53+00:00

<p><img alt="Javier Milei's closing campaign rally" src="https://fotos.perfil.com/2023/10/19/trim/540/304/javier-mileis-closing-campaign-rally-1679142.jpg" /></p>With a crunch presidential election just days away, Javier Milei’s supporters remain confident that Argentina is set to choose a libertarian future.
 <a href="https://www.batimes.com.ar/news/argentina/he-will-win-i-feel-it-milei-supporters-dare-to-dream-as-election-nears.phtml">Leer más</a>

## Argentines head to polls, seeking elixir for economic ills
 - [https://www.batimes.com.ar/news/argentina/argentines-head-to-polls-seeking-elixir-for-economic-ills.phtml](https://www.batimes.com.ar/news/argentina/argentines-head-to-polls-seeking-elixir-for-economic-ills.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T01:14:00+00:00

<p><img alt="milei supporters" src="https://fotos.perfil.com/2023/10/20/trim/540/304/milei-supporters-1679305.jpg" /></p>Fury and fatigue after decades of economic crises have provided fertile ground for Javier Milei, who has surged to the front of the race with his vow to take a chainsaw to the bloated state and dollarise the economy. <a href="https://www.batimes.com.ar/news/argentina/argentines-head-to-polls-seeking-elixir-for-economic-ills.phtml">Leer más</a>

## Old guard vs upstart: Argentina's presidential candidates
 - [https://www.batimes.com.ar/news/argentina/old-guard-vs-upstart-argentinas-presidential-candidates.phtml](https://www.batimes.com.ar/news/argentina/old-guard-vs-upstart-argentinas-presidential-candidates.phtml)
 - RSS feed: https://www.batimes.com.ar/feed
 - date published: 2023-10-20T01:08:00+00:00

<p><img alt="Election 2023 ballots: Patricia Bullrich, Sergio Massa, Javier Milei, Juan Schiaretti, Myriam Bregman" src="https://fotos.perfil.com/2023/10/20/trim/540/304/election-2023-ballots-patricia-bullrich-sergio-massa-javier-milei-juan-schiaretti-myriam-bregman-1679167.jpg" /></p>Leading candidates are battling for three different visions of Argentina, centred on their proposed remedies for the country's perennial economic ills. <a href="https://www.batimes.com.ar/news/argentina/old-guard-vs-upstart-argentinas-presidential-candidates.phtml">Leer más</a>

