# Source:Screen Junkies, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A, language:en-US

## Who Wants to See Some Lightsaber Tricks? | Ahsoka Honest Trailer
 - [https://www.youtube.com/watch?v=O1Lk5XPvJek](https://www.youtube.com/watch?v=O1Lk5XPvJek)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCOpcACMWblDls9Z6GERVi1A
 - date published: 2023-10-20T19:11:01+00:00

Watch the full Honest Trailer here: https://youtu.be/pHXDbVRxojo
#shorts #ahsoka #starwars #honesttrailers

