# Source:Babylon Bee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg, language:en-US

## VICE News Wrote A Smear Piece About @AwakenWithJP
 - [https://www.youtube.com/watch?v=K4qPoM5Gd6I](https://www.youtube.com/watch?v=K4qPoM5Gd6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCyl5V3-J_Bsy3x-EBCJwepg
 - date published: 2023-10-20T18:43:26+00:00

Watch the interview with JP Sears: https://www.youtube.com/watch?v=j0RaTANY1Sw&amp;t=2s

 #babylonbee #comedy #woke #awakenwithjp

