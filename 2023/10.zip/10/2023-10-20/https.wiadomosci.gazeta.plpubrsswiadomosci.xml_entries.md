# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Rosja zareagowała na orędzie Joe Bidena. Dmitrij Pieskow: Nie przystoi odpowiedzialnym przywĂłdcom
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325776,pieskow-reaguje-na-oredzie-bidena-taka-retoryka-nie-przystoi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325776,pieskow-reaguje-na-oredzie-bidena-taka-retoryka-nie-przystoi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T20:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/75/eb/1c/z30325877M,Dmitrij-Pieskow--zdj--ilustracyjne-.jpg" vspace="2" />Joe Biden porĂłwnał Władimira Putina do Hamasu. Na słowa prezydenta StanĂłw Zjednoczonych zareagował Kreml. - Nazwisko Putina jest integralną częścią wewnętrznego życia politycznego w USA - skomentował Dmitrij Pieskow. - Nie powiedział ani słowa o tym, że jak dotąd wszystkie wysiłki mające na celu powstrzymanie Rosji były bardzo, bardzo nieskuteczne - dodał.

## Pierwsze wystąpienie Jarosława Kaczyńskiego po wyborach: Mamy powtĂłrkę z 2007 roku
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325801,pierwsze-wystapienie-jaroslawa-kaczynskiego-po-wyborach-powtorka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325801,pierwsze-wystapienie-jaroslawa-kaczynskiego-po-wyborach-powtorka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T20:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a9/eb/1c/z30325929M,Jaroslaw-Kaczynski.jpg" vspace="2" />W Spale rozpoczął IX Nadzwyczajny Zjazd KlubĂłw "Gazety Polskiej". Potrwa do niedzieli. Na spotkanie przyjadą przedstawiciele ponad pięciuset KlubĂłw z Polski i z zagranicy. W uroczystej inauguracji uczestniczył prezes PiS Jarosław Kaczyński. Jak stwierdził, mobilizacja wyborcĂłw opozycji została "przeprowadzona w sposĂłb perfidny". Kaczyński ubolewał też, że "ludzie nie głosują z wdzięczności".

## Potrącenie dziecka w Żorach. Policja publikuje nagranie ku przestrodze i przypomina ważną zasadę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325805,potracenie-dziecka-w-zorach-policja-publikuje-nagranie-ku-przestrodze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325805,potracenie-dziecka-w-zorach-policja-publikuje-nagranie-ku-przestrodze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T20:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/40/eb/1c/z30325824M,Potracenie-dziecka-w-Zorach.jpg" vspace="2" />W Żorach doszło do potrącenia 10-latka. Chłopiec nie upewnił się, czy może przejść przez jezdnię. Policja publikuje ku przestrodze wideo ze zdarzenia.

## 19-latek uderzył w przyczepę ciągnika. Jego samochĂłd doszczętnie spłonął
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325797,wypadek-na-dk91-19-latek-najechal-w-tyl-ciagnika-jego-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325797,wypadek-na-dk91-19-latek-najechal-w-tyl-ciagnika-jego-samochod.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T19:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/eb/1c/z30325828M,19-latek-zderzyl-sie-z-ciagnikiem--Jego-auto-splon.jpg" vspace="2" />W miejscowości Krężlewice (woj. łĂłdzkie) na drodze krajowej nr 91 samochĂłd osobowy wjechał w tył przyczepy ciągnika. W wyniku zderzenia auto, ktĂłre prowadził 19-latek, stanęło w płomieniach. Młody kierowca został przetransportowany do szpitala.

## Hamas uwolnił pierwszych więźniĂłw. Decyzją chce uderzyć w prezydenta USA
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325728,hamas-uwolnil-pierwszych-wiezniow-decyzja-chce-uderzyc-w-prezydenta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325728,hamas-uwolnil-pierwszych-wiezniow-decyzja-chce-uderzyc-w-prezydenta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T19:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/eb/1c/z30325794M,Hamas-uwolnil-pierwszych-wiezniow--Decyzja-chce-ud.jpg" vspace="2" />Hamas uwolnił dwie obywatelki StanĂłw Zjednoczonych, ktĂłre zostały pojmane 7 października podczas bezprecedensowego i brutalnego ataku na ludność cywilną Izraela. To Judith Raanan i jej 18-letnia cĂłrka Natalie Raanan. Strona izraelska potwierdziła, że Amerykanki zostały uwolnione.

## Hiszpania. Tak obficie nie padało od ponad 160 lat. Na ulicach wodospady i gejzery
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325380,katastrofalne-ulewy-w-hiszpanii-czegos-takiego-nie-bylo-od.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325380,katastrofalne-ulewy-w-hiszpanii-czegos-takiego-nie-bylo-od.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T19:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/17/eb/1c/z30325783M,Katastrofalne-powodzie-w-Hiszpanii.jpg" vspace="2" />Gigantyczne ulewy sparaliżowały znaczną część Hiszpanii. Pod wodą znalazł się m.in. Madryt, w ktĂłrym ogłoszono czwarty stopień zagrożenia pogodowego. Schody zamieniły się w wodospady, ulice w rwące potoki, a studzienki kanalizacyjne zaczęły przypominać gejzery. Według doniesień hiszpańskiej agencji meteorologicznej tak dużej sumy opadĂłw nie odnotowano na PĂłłwyspie Iberyjskim od ponad 160 lat.

## Rząd PiS? Paweł Kukiz: Teraz szanse minimalne, ale za pĂłł roku niekoniecznie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325684,rzad-pis-pawel-kukiz-teraz-szanse-minimalne-ale-za-pol-roku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325684,rzad-pis-pawel-kukiz-teraz-szanse-minimalne-ale-za-pol-roku.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T19:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/eb/1c/z30325758M,Pawel-Kukiz.jpg" vspace="2" />Paweł Kukiz powiedział w Radiu Zet, że szanse na utworzenie rządu przez PiS są obecnie "minimalne". Zasugerował jednak, że sytuacja może zmienić się w ciągu kilku miesięcy. Według polityka niewykluczone są przyspieszone wybory.

## Gdynia. Obława na ojca po zabĂłjstwie sześciolatka. Żandarmeria Wojskowa: Jest czynnym żołnierzem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325604,oblawa-w-gdyni-po-zabojstwie-szesciolatka-na-jego-ojca-zandarmeria.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325604,oblawa-w-gdyni-po-zabojstwie-szesciolatka-na-jego-ojca-zandarmeria.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T18:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/eb/1c/z30325769M,Oblawa-w-Gdyni.jpg" vspace="2" />Policja poszukuje 44-letniego Grzegorza Borysa podejrzewanego o zabĂłjstwo 6-letniego chłopca w Gdyni. Publikuje też zdjęcia mężczyzny. Ciało dziecka znaleziono przed południem w jednym z mieszkań przy ulicy GĂłrniczej. Żandarmeria Wojskowa potwierdziła, że jest on czynnym żołnierzem Wojska Polskiego. W związku z obławą mieszkańcy Gdyni muszą się liczyć z kontrolami.

## "Histerycznie nie potrafią się pogodzić ze stratą władzy". Nie, to nie słowa opozycji w 2023 r.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30325397,ci-ktorzy-stracili-wladze-dzis-histerycznie-nie-potrafia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30325397,ci-ktorzy-stracili-wladze-dzis-histerycznie-nie-potrafia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T18:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/eb/1c/z30325536M,Beata-Szydlo--oredzie-telewizyjne-nowo-zaprzysiezo.jpg" vspace="2" />"Wola narodu się uzewnętrzniła" - w ten sposĂłb wynik wyborĂłw parlamentarnych w 2015 roku komentował prezydent Andrzej Duda. Kiedy władzę w Polsce miało przejąć jego środowisko polityczne, prezydent apelował do ustępującej koalicji PO-PSL o niepodejmowanie "poważnych zmian". Dziś nic podobnego nie słyszymy. W archiwach nie brakuje też wypowiedzi politykĂłw PiS-u, ktĂłre dziś w ich tronę mogłaby kierować szykująca się do przejęcia rządĂłw koalicja.

## Doniesienia o niszczeniu dokumentĂłw. Donald Tusk reaguje. Zagadnął Kaczyńskiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325605,doniesienia-o-niszczeniu-dokumentow-donald-tusk-reaguje-zagadnal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325605,doniesienia-o-niszczeniu-dokumentow-donald-tusk-reaguje-zagadnal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T18:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/e9/1c/z30317980M,Donald-Tusk.jpg" vspace="2" />Donald Tusk odniĂłsł się do doniesień, jakoby po wyborach w instytucjach państwa dochodziło do niszczenia dokumentĂłw. Szef Koalicji Obywatelskiej nawiązał do słynnego dialogu z "PsĂłw" Władysława Pasikowskiego.

## Afera mailowa. Takie wymagania miał wspĂłłpracownik Morawieckiego: Mieszkanie w centrum Warszawy, iPhone
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325379,afera-mailowa-takie-wymagania-mial-wspolpracownik-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325379,afera-mailowa-takie-wymagania-mial-wspolpracownik-morawieckiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T18:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8c/eb/1c/z30325644M,Andrzej-Pawluszek--Michal-Dworczyk-i-Mateusz-Moraw.jpg" vspace="2" />Do sieci trafiła wiadomość, ktĂłrą Andrzej Pawluszek miał wysłać do Michała Dworczyka przed objęciem stanowiska sekretarza Mateusza Morawieckiego. W treści przedstawiono liczne wymagania dotyczące pracy. Wymieniono tam m.in. "w miarę sensowne wynagrodzenie", "mieszkanie w centrum Warszawy" i "telefon z dużym wyświetlaczem".

## Nowe doniesienia ws. wypadku na A1. Sebastian M. był kryty? Policja skomentowała "dwie notatki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325499,nowe-doniesienia-ws-wypadku-na-a1-sebastian-m-byl-kryty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325499,nowe-doniesienia-ws-wypadku-na-a1-sebastian-m-byl-kryty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T17:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bc/d7/1c/z30243260M,Sluzby-na-miejscu-wypadku-na-autostradzie-A1.jpg" vspace="2" />Trwa śledztwo w sprawie wypadku na autostradzie A1, w ktĂłrym zginęła trzyosobowa rodzina. Dziennikarze "Rzeczpospolitej" ustalili, że mogło dojść do nadużyć przy ustalaniu przebiegu zdarzeń, a funkcjonariusze prĂłbowali wybielić Sebastiana M. ŁĂłdzka policja odniosła się do doniesień i wydała oświadczenie.

## Mejza pozwał Giertycha za komentowanie jego biznesĂłw. Jest rozstrzygnięcie sądu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30325263,mejza-pozwal-giertycha-sad-rozstrzygnal-w-tej-sprawie-karnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30325263,mejza-pozwal-giertycha-sad-rozstrzygnal-w-tej-sprawie-karnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T17:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/60/eb/1c/z30325344M,Lukasz-Mejza-pozwal-Romana-Giertycha--Sad-rozstrzy.jpg" vspace="2" />Po ujawnieniu w 2021 roku działalności firmy Łukasza Mejzy, ktĂłrego za wysokie ceny oferowała eksperymentalne i niepotwierdzone leczenie chorym, poseł PiS-u złożył do sądu szereg pozwĂłw przeciwko politykom, ktĂłrzy komentowali sprawę. Jednym z nich był Roman Giertych. Prawnik właśnie poinformował, że zapadła decyzja sądu w tym postępowaniu.

## Wielki finał wyborĂłw, Korwin-Mikke zawieszony [TYGODNIK WYBORCZY]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30324932,wielki-final-wyborow-korwin-mikke-zawieszony-tygodnik-wyborczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30324932,wielki-final-wyborow-korwin-mikke-zawieszony-tygodnik-wyborczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T17:16:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/05/eb/1c/z30324997M,Warszawa--Przewodniczacy-PO-Donald-Tusk-w-wieczor-.jpg" vspace="2" />Opozycja odniosła wielkie zwycięstwo wyborcze przy najwyższej frekwencji w historii. Polacy jasno pokazali, że chcą nowej władzy - pisze dla Gazeta.pl Tomasz Sawczuk z "Kultury Liberalnej".

## Rosjanie prĂłbują odzyskać inicjatywę i wytrącić UkraińcĂłw z rĂłwnowagi. Płacą za to ciężkimi stratami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324051,rosjanie-probuja-odzyskac-inicjatywe-i-wytracic-ukraincow-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324051,rosjanie-probuja-odzyskac-inicjatywe-i-wytracic-ukraincow-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T17:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/46/eb/1c/z30324294M,Sytuacja-na-froncie-w-Ukrainie--Raport-z-konca-paz.jpg" vspace="2" />Kolejny tydzień środek ciężkości wojny jest w rejonie Awdijiwki. Rosjanie szturmują tam bez większego skutku silnie umocnionych UkraińcĂłw. Ponoszą przy tym ogromne straty. Według UkraińcĂłw jedne z największych w czasie wojny. Świadczy to jednak o tym, że letnia ofensywa Ukrainy nie złamała Rosjan.

## Starcie Tomczyka z reporterką. Wymienia obietnice: Odpolitycznienie TVP, a także odpolitycznienie TVP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325273,starcie-tomczyka-z-reporterka-wymienia-obietnice-odpolitycznienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325273,starcie-tomczyka-z-reporterka-wymienia-obietnice-odpolitycznienie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T17:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/dc/eb/1c/z30325468M,Cezary-Tomczyk.jpg" vspace="2" />Cezary Tomczyk starł się z pracownicą TVP. W trakcie wywiadu sam wyjął telefon i zaczął nagrywać reporterkę. Gdy ta pytała o wyborcze obietnice, poseł kilkukrotnie wymienił jedną z priorytetowych - odpolitycznienie Telewizji Polskiej.

## Wrocław nie chce już finansować lekcji religii. Radni: Mamy w mieście istotniejsze wydatki
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325226,wroclaw-nie-bedzie-finansowal-lekcji-religii-radni-przeglosowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325226,wroclaw-nie-bedzie-finansowal-lekcji-religii-radni-przeglosowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T16:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4d/eb/1c/z30325325M,Lekcja-religii--zdjecie-ilustracyjne-.jpg" vspace="2" />Wrocław nie chce już płacić za lekcje religii. Radni zdecydowali, że za zajęcia powinno płacić państwo. - Mamy we Wrocławiu wydatki, ktĂłre są o wiele istotniejsze - podkreślił polityk Nowej Lewicy Dominik Kłosowski.

## Chłopiec przyniĂłsł do przedszkola "skręta" z marihuaną. Ojciec czterolatka świętował swoje urodziny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325167,chlopiec-przyniosl-do-przedszkola-skreta-z-marihuana-ojciec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325167,chlopiec-przyniosl-do-przedszkola-skreta-z-marihuana-ojciec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T16:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/eb/1c/z30325246M,Przedszkole---zdj--ilustr.jpg" vspace="2" />W Piasecznie (woj. mazowieckie) czterolatek przyniĂłsł do przedszkola niedopałek z marihuaną. Dyrekcja wezwała policję. Ojciec tłumaczył, że świętował swoje urodziny i nie wie, w jaki sposĂłb "skręt" trafił w ręce syna.

## Ukraińcy zadali Rosjanom dotkliwy cios na froncie. Rekordowe straty agresora
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325072,ukraincy-zadali-rosjanom-dotkliwy-cios-na-froncie-rekordowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30325072,ukraincy-zadali-rosjanom-dotkliwy-cios-na-froncie-rekordowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T16:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ca/eb/1c/z30325194M,Wojna-w-Ukrainie--Ukraincy-zadali-Rosjanom-dotkliw.jpg" vspace="2" />DowĂłdztwo ukraińskiej armii poinformowało, że w czwartek zadało najbardziej dotkliwy cios Rosjanom od początku ich pełnoskalowej inwazji 24 lutego 2022 roku. W ciągu doby agresorzy stracili 1380 żołnierzy. Na południowym froncie Ukraińcy zniszczyli także potężny kompleks obronny i broń wroga.

## Prezydencki minister o pierwszym posiedzeniu Sejmu. Padły daty. "Na to wskazują okoliczności"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325073,prezydencki-minister-o-pierwszym-posiedzeniu-sejmu-padly-daty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30325073,prezydencki-minister-o-pierwszym-posiedzeniu-sejmu-padly-daty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T15:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/eb/1c/z30325145M,Andrzej-Duda.jpg" vspace="2" />Szef gabinetu prezydenta Paweł Szrot przekazał, że pierwsze posiedzenie Sejmu nowej kadencji odbędzie się prawdopodobnie 13 lub 14 listopada. - Na to wskazują wszystkie okoliczności - powiedział.

## Korea PĂłłnocna oskarża USA o celowe prowokacje i grozi atakiem. "Nasza reakcja będzie odpowiednia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324928,korea-polnocna-grozi-atakiem-wyprzedzajacym-to-celowe-prowokowanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324928,korea-polnocna-grozi-atakiem-wyprzedzajacym-to-celowe-prowokowanie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T15:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/eb/1c/z30325208M,Kim-Dzong-Un.jpg" vspace="2" />Korea PĂłłnocna zarzuciła Stanom Zjednoczonym podejmowanie działań, ktĂłre mają na celu wywołanie wojny nuklearnej. Zdaniem władz Pjongjangu, to właśnie dlatego na pĂłłwyspie koreańskim pojawiły się amerykańskie bombowce - poinformowała reżimowa agencja prasowa KCNA.

## Spekulacje ws. składu rządu. Ludowcy liczą na kluczowy resort. Kosiniak-Kamysz na wicepremiera
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30324816,spekulacje-ws-skladu-rzadu-ludowcy-licza-na-kluczowy-resort.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30324816,spekulacje-ws-skladu-rzadu-ludowcy-licza-na-kluczowy-resort.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T15:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/e8/1c/z30313381M,Donald-Tusk-i-Wladyslaw-Kosiniak-Kamysz.jpg" vspace="2" />Pojawiają się kolejne nieoficjalne doniesienia na temat obsady przyszłego rządu. Z nieoficjalnych ustaleń wynika, że Władysław Kosiniak-Kamysz mĂłgłby objąć resort odpowiedzialny za gospodarkę.

## Zima na Podlasiu. W Suwałkach spadł już pierwszy śnieg. IMGW wydał ostrzeżenia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324684,zima-na-podlasiu-w-suwalkach-padl-juz-pierwszy-snieg-imgw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324684,zima-na-podlasiu-w-suwalkach-padl-juz-pierwszy-snieg-imgw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T15:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/25/eb/1c/z30324773M,20-pazdziernika-w-Suwalkach-spadl-pierwszy-snieg.jpg" vspace="2" />W Suwałkach spadł pierwszy w tym roku śnieg. Podrygi zimy to nie jedyna anomalia pogodowa, jaka czeka na w najbliższych dniach. IMGW wydał serię ostrzeżeń meteorologicznych i hydrologicznych.

## Poszukiwany Grzegorz Borys na plac zabaw z synem chodził w kominiarce i z nożem. "Każdy się obawiał"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325020,poszukiwany-grzegorz-borys-na-plac-zabaw-z-synem-chodzil-w-kominiarce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30325020,poszukiwany-grzegorz-borys-na-plac-zabaw-z-synem-chodzil-w-kominiarce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T14:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5a/eb/1c/z30324826M.jpg" vspace="2" />Grzegorz Borys, mężczyzna podejrzewany o zabĂłjstwo sześcioletniego syna, jest wciąż poszukiwany. Zdaniem sąsiadĂłw 44-latek już od jakiegoś czasu zachowywał się niepokojąco. Chodził po osiedlu w ciemnych okularach i kominiarce. Nosił przy sobie nĂłż, nawet na placu zabaw. - Po zachowaniu tego pana można było się wszystkiego spodziewać. Wszystko go bardzo szybko frustrowało - powiedziała jedna z kobiet.

## B. senator PiS: "Demokracja jest groźna dla katolikĂłw". Nowa władza? "Rozdawnictwo LGBT-owskie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324445,jan-zaryn-demokracja-jest-grozna-dla-katolikow-byly-senator.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324445,jan-zaryn-demokracja-jest-grozna-dla-katolikow-byly-senator.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T14:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4b/eb/1c/z30324811M,Jan-Zaryn.jpg" vspace="2" />Były senator PiS i obecny dyrektor Instytutu Dziedzictwa Myśli Narodowej Jan Żaryn powiedział, że demokracja stanowi zagrożenie dla katolikĂłw. Stwierdził także, przewidując utratę pokaźnego funduszu, że w związku z przejęciem rządu przez opozycję, nowa władza "będzie nastawiona na łamanie prawa" i "rozdawnictwo LGBT-owskie".

## Zbigniew Ziobro, by wygłosić oświadczenie, sprasza dziennikarzy. Ale nie pozwala im o nic pytać
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324652,briefing-prasowy-zbigniewa-ziobry-nagle-wyszedl-dziennikarze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324652,briefing-prasowy-zbigniewa-ziobry-nagle-wyszedl-dziennikarze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T13:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/89/eb/1c/z30324873M,Zbigniew-Ziobro.jpg" vspace="2" />Ministerstwo Sprawiedliwości zorganizowało briefing prasowy ministra sprawiedliwości. Jednak Zbigniew Ziobro, po wygłoszeniu oświadczenia, natychmiast wyszedł. Zebrani dziennikarze nie mogli zadać pytań, m.in. o przyszłość Suwerennej Polski, koalicjanta PiS.

## Biały Dom przyznał się do błędu i usunął zdjęcie żołnierzy. Pokazano ich twarze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324552,bialy-dom-przyznal-sie-do-bledu-i-usunal-zdjecie-zolnierzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324552,bialy-dom-przyznal-sie-do-bledu-i-usunal-zdjecie-zolnierzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T13:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0c/eb/1c/z30324748M,Joe-Biden.jpg" vspace="2" />Biały Dom opublikował w mediach społecznościowych zdjęcie, na ktĂłrym widać członkĂłw amerykańskiej jednostki specjalnej przebywających w Izraelu. Na fotografii nie zamazano twarzy żołnierzy. Administracja usunęła zdjęcie i przyznała się do błędu.

## Izrael zaatakował kościĂłł w Gazie. ONZ: Strefa Gazy jest obecnie piekłem dla ludności cywilnej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324286,armia-zaatakowala-kosciol-w-gazie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30324286,armia-zaatakowala-kosciol-w-gazie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T13:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b6/eb/1c/z30324406M.jpg" vspace="2" />W wyniku ataku na kościĂłł św. Porfiriusza w Strefie Gazy zginęło 18 PalestyńczykĂłw, ktĂłrzy schronili się wewnątrz - głoszą najnowsze dane. Izrael twierdzi, że celem ataku była sąsiadująca z kościołem kryjĂłwka.

## Turystyka wyborcza na Podlasiu. Mundurowi przy granicy z Białorusią "nabili" wynik w małej gminie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323720,turystyka-wyborcza-na-podlasiu-mundurowi-przy-granicy-z-bialorusia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323720,turystyka-wyborcza-na-podlasiu-mundurowi-przy-granicy-z-bialorusia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T12:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/eb/1c/z30323834M.jpg" vspace="2" />Na Podlasiu, gdzie stacjonuje straż graniczna, policja i wojsko, w tym roku doszło do "turystyki wyborczej". Jak wyglądają wyniki w porĂłwnaniu z 2019 rokiem? Odnotowano spore rĂłżnice.

## Horoskop na weekend 21-22 października 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30320923,horoskop-na-weekend-21-22-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30320923,horoskop-na-weekend-21-22-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T12:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/eb/1c/z30324362M,Horoskop--zdjecie-ilustracyjne-.jpg" vspace="2" />Horoskop na weekend 21-22 października 2023. Przedostatni weekend października to bardzo interesujący czas dla wielu znakĂłw zodiaku. W tych dniach należy zwrĂłcić szczegĂłlną uwagę na osoby żyjące w naszym najbliższym otoczeniu. Znaki zodiaku powinny pamiętać, że los zawsze zwraca nam to, co dajemy innym.

## Konin. Szkolny autobus "o włos uniknął tragedii" na zamykającym się przejeździe kolejowym [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323794,konin-szkolny-autobus-o-wlos-uniknal-tragedii-na-zamykajacym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323794,konin-szkolny-autobus-o-wlos-uniknal-tragedii-na-zamykajacym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T12:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/eb/1c/z30324292M,Autobus-wjechal-na-zamykajacy-sie-przejazd-kolejow.jpg" vspace="2" />Pod Koninem kierowca szkolnego autobusu wjechał na przejazd kolejowy w trakcie opadania rogatek. 60-latek odpowie za to przed sądem. Policja poinformowała, że mężczyzna, ktĂłry naruszył zasady bezpieczeństwa, stracił już prawo jazdy.

## Zbrodnia w Sławęcinie. 20-latek usłyszał zarzut zabĂłjstwa matki ze szczegĂłlnym okrucieństwem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323596,zbrodnia-w-slawecinie-20-latek-uslyszal-zarzut-zabojstwa-matki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323596,zbrodnia-w-slawecinie-20-latek-uslyszal-zarzut-zabojstwa-matki.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T12:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/e2/1c/z30289034M,Policja---zdjecie-ilustracyjne.jpg" vspace="2" />Jakub W., podejrzany o dokonanie zbrodni w Sławęcinie, usłyszał zarzuty. Mężczyznę oskarżono o zabĂłjstwo matki i usiłowanie zabĂłjstwa ojca.

## Strażnicy miejscy mają większe uprawnienia. Mogą wystawiać więcej mandatĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323841,straznicy-miejscy-maja-wieksze-uprawnienia-moga-wystawiac-wiecej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323841,straznicy-miejscy-maja-wieksze-uprawnienia-moga-wystawiac-wiecej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T12:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/e5/1c/z30300509M,Straz-miejska---zdjecie-ilustracyjne.jpg" vspace="2" />Od 20 października strażnicy miejscy i gminni mają większe uprawnienia. Mogą już ukarać mandatem osoby poruszające się rowerem lub hulajnogą po drogach przeznaczonych dla pieszych oraz te, ktĂłre nie mają odpowiednich uprawnień. Jakie mandaty grożą za te wykroczenia?

## Psy ratowały życie ludzi, narażając przy tym swoje. Teraz potrzebują pomocy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30320939,psy-wielokrotnie-ratowaly-ludzkie-zycie-narazajac-przy-tym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30320939,psy-wielokrotnie-ratowaly-ludzkie-zycie-narazajac-przy-tym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T11:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/eb/1c/z30323974M,Marki--Psy-z-grupy-poszukiwawczo-ratowniczej-ratow.jpg" vspace="2" />Poszukiwanie zaginionych osĂłb jest wyzwaniem, ktĂłremu nie zawsze mogą sprostać ludzie. Wtedy do akcji wkraczają psy z Grupy Poszukiwawczo-Ratowniczej OSP Marki. Jak się okazuje, psi ratownicy znaleźli się w sytuacji, w ktĂłrej sami potrzebują pomocy ludzi.

## ZabĂłjstwo sześciolatka w Gdyni. Policja poszukuje Grzegorza Borysa. 44-latek uciekł z miejsca zbrodni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324060,gdynia-policja-poszukuje-grzegorza-borysa-44-latek-mial-zabic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30324060,gdynia-policja-poszukuje-grzegorza-borysa-44-latek-mial-zabic.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T11:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/76/eb/1c/z30324086M,Poszukiwany-ws--zabojstwa-szescioletniego-dziecka.jpg" vspace="2" />Policja opublikowała wizerunek mężczyzny poszukiwanego w sprawie śmierci sześcioletniego dziecka. Mężczyzna jest ojcem chłopca, ktĂłrego ciało po powrocie z pracy w mieszkaniu w Gdyni znalazła jego matka.

## Andrzej Duda komentuje konsultacje z partiami. "Zadam sakramentalne pytanie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30323896,andrzej-duda-komentuje-konsultacje-z-partiami-zadam-sakramentalne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30323896,andrzej-duda-komentuje-konsultacje-z-partiami-zadam-sakramentalne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T11:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/35/e8/1c/z30313269M,Andrzej-Duda.jpg" vspace="2" />W przyszłym tygodniu Andrzej Duda spotka się z przedstawicielami wszystkich komitetĂłw wyborczych, aby rozmawiać o przyszłym rządzie. - Zadam sakramentalne pytanie, czy uważają, że dysponują większością, ktĂłra pozwalałby im na przeforsowanie swojego kandydata na premiera - powiedział prezydent.

## Prasa podaje nazwiska możliwych kandydatĂłw na szefa MSZ. Zapowiadają się czystki wśrĂłd ambasadorĂłw
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323175,prasa-podaje-nazwiska-mozliwych-kandydatow-na-szefa-msz-zapowiadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323175,prasa-podaje-nazwiska-mozliwych-kandydatow-na-szefa-msz-zapowiadaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T11:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/04/de/1c/z30270724M.jpg" vspace="2" />"Rzeczpospolita" podaje nazwiska ambasadorĂłw, ktĂłrzy niebawem mogą stracić stanowisko. Gazeta ujawnia też, kto mimo zbliżających się czystek, może się czuć bezpiecznie. Pojawiają się rĂłwnież kandydaci na przyszłego szefa resortu dyplomacji.

## Uczył dziewięciu przedmiotĂłw, prowadził program w TVN. Będzie posłem, bo "wygrał z partyjnym betonem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323356,uczyl-dziewieciu-przedmiotow-i-prowadzil-program-w-tvn-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323356,uczyl-dziewieciu-przedmiotow-i-prowadzil-program-w-tvn-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T11:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/07/eb/1c/z30323719M,Marcin-Jozefaciuk.jpg" vspace="2" />Marcin JĂłzefaciuk dostał się do Sejmu z łĂłdzkiej listy Koalicji Obywatelskiej, pokonując politykĂłw ze znacznie większym stażem. Gospodarz programu "Nastolatki rządzą... kasą" ma doświadczenie jako nauczyciel i nowy styl uprawiania polityki, dzięki ktĂłremu zdołał "wygrać z partyjnym betonem".

## Giorgia Meloni rozstała się z partnerem. Wcześniej wyciekły szokujące nagrania z jego udziałem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30323358,giorgia-meloni-rozstala-sie-z-partnerem-wczesniej-wyciekly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30323358,giorgia-meloni-rozstala-sie-z-partnerem-wczesniej-wyciekly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:55:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/30/eb/1c/z30323760M,Giorgia-Meloni.jpg" vspace="2" />Giorgia Meloni, premierka Włoch oznajmiła, że rozstała się ze swoim wieloletnim partnerem Andreą Giambruno. Może to mieć związek z ujawnionymi przez włoskie media wypowiedziami prezentera. "Nasze ścieżki rozeszły się jakiś czas temu i nadszedł moment, aby to przyznać" - napisała Meloni w mediach społecznościowych.

## TwĂłrca "miasta 15-minutowego": Uzależnienie od samochodĂłw blokuje zmiany w naszych miastach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,174372,30316312,tworca-miasta-15-minutowego-uzaleznienie-od-samochodow-blokuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,174372,30316312,tworca-miasta-15-minutowego-uzaleznienie-od-samochodow-blokuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/e9/1c/z30316941M,Lodz.jpg" vspace="2" />- Chcemy zerwać z uzależnieniem od samochodĂłw, ale nie traktujemy ich jako wroga. Chodzi o to, żeby odzyskać przestrzeń publiczną, miejską, dla ludzi - mĂłwi nam prof. Carlos Moreno, urbanista i twĂłrca słynnej koncepcji miasta 15-minutowego. Jego pomysł doczekał się nawet teorii spiskowych, ale Moreno przyznaje, że propozycje transformacji miast budzą nawet agresję. - Zmiana naszego sposobu myślenia zajmie lata - mĂłwi.

## Czołowe zderzenie na DK2. Z osobowego auta niemal nic nie zostało. Jego kierowca zginął na miejscu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323364,czolowe-zderzenie-samochodu-osobowego-z-ciezarowka-kierowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323364,czolowe-zderzenie-samochodu-osobowego-z-ciezarowka-kierowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/78/eb/1c/z30323576M,Zabce--Smiertelny-wypadek-na-DK2--Samochod-osoby-z.jpg" vspace="2" />Kierowca samochodu osobowego nie przeżył zderzenia czołowego z ciężarĂłwką na krajowej "dwĂłjce". A z jego auta niewiele zostało. Do wypadku doszło w czwartek w miejscowości Żabce (woj. podlaskie). Policja wstępnie ustaliła, w jaki sposĂłb doszło do zderzenia i zbadała trzeźwość kierowcy, ktĂłry przeżył.

## Poznań. Wyszli z rozbitych aut, wjechał w nich samochĂłd. Pięć osĂłb trafiło do szpitala
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322950,poznan-wyszli-z-rozbitych-aut-wjechal-w-nich-samochod-piec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322950,poznan-wyszli-z-rozbitych-aut-wjechal-w-nich-samochod-piec.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/bb/1c/z30128370M,Straz-pozarna-w-drodze-na-miejsce-wypadku--zdjecie.jpg" vspace="2" />Wieczorem w Poznaniu zderzyły się dwa auta. Osoby, ktĂłre nimi jechały, wyszły z pojazdĂłw o własnych siłach i stanęły na poboczu. Wtedy wjechał w nich samochĂłd. Pięć osĂłb trafiło do szpitala, stan jednej z nich jest ciężki.

## W Gdyni znaleziono ciało sześciolatka. Trwa policyjna obława
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323641,w-gdyni-znaleziono-cialo-szesciolatka-trwa-policyjna-oblawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323641,w-gdyni-znaleziono-cialo-szesciolatka-trwa-policyjna-oblawa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:20:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f4/eb/1c/z30323700M,Policja--zdjecie-ilustracyjne-.jpg" vspace="2" />W Gdyni znalezione zostały zwłoki sześcioletniego chłopca. Z nieoficjalnych ustaleń Polsatu News wynika, że w mieście trwa policyjna obława za mężczyzną. Poszukiwany jest prawdopodobnie ojcem dziecka.

## Szef Rady MediĂłw Narodowych dowiedział się o planach opozycji wobec TVP. MĂłwi, że jest zdumiony
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323258,szef-rady-mediow-narodowych-dowiedzial-sie-o-planach-opozycji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323258,szef-rady-mediow-narodowych-dowiedzial-sie-o-planach-opozycji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6e/eb/1c/z30323310M,Przewodniczacy-RMN-Krzysztof-Czabanski.jpg" vspace="2" />- Nie można bezprawnie uchylać obowiązujących ustaw - powiedział Krzysztof Czabański, przewodniczący Rady MediĂłw Narodowych RMN w rozmowie z IAR. Przypomniał, że jeśli zmiana ustawy musi odbywać się drogą ustawodawczą. - Musi to zaakceptować Sejm, Senat i pan prezydent. Inne zmiany nie są możliwe - mĂłwił. Plany opozycji określił jako "zapowiedź bezprawia".

## Zakonnica rzuciła się na aktywistę i powaliła go na ziemię. "NaprzĂłd chrześcijańscy żołnierze" [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322954,zakonnica-rzucila-sie-na-aktywiste-i-powalila-go-na-ziemie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322954,zakonnica-rzucila-sie-na-aktywiste-i-powalila-go-na-ziemie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T10:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/eb/1c/z30323287M,Francja--Zakonnica-powalila-na-ziemie-aktywiste--K.jpg" vspace="2" />Zakonnica rzuciła się na aktywistę, ktĂłry protestował przeciwko budowie kościoła i powaliła go na ziemię. Inwestycja w wiosce Saint-Pierre-de-Colombier w Ardeche (Francja) wywołała wiele kontrowersji, ponieważ we wsi liczącej 411 mieszkańcĂłw budowany jest kościĂłł, ktĂłry ma pomieścić 3500 osĂłb.

## Patryk Jaki lubi już robaki? "Himalaje hipokryzji" europosłĂłw PiS. Uznali "potencjał spożywczy owadĂłw"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322943,europoslowie-pis-zdobyli-himalaje-hipokryzji-poparli-uchwale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322943,europoslowie-pis-zdobyli-himalaje-hipokryzji-poparli-uchwale.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T09:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/67/eb/1c/z30323303M,Patryk-Jaki-zaglosowal-za-rezolucja-o-potencjalne-.jpg" vspace="2" />Europosłowie PiS głosowali za rezolucją Parlamentu Europejskiego, w ktĂłrej stwierdzono, że "rośnie potencjał białka pochodzącego z owadĂłw, przeznaczonego do spożycia przez ludzi". WśrĂłd popierających projekt znalazł się m.in. Patryk Jaki z PiS. Jeszcze niedawno Jaki protestował przeciw rzekomemu zmuszaniu obywateli Polski do jedzenia owadĂłw i manifestował swoje przywiązanie do kotleta.

## Poseł KO alarmuje: Setki workĂłw ze zmielonymi dokumentami. Sceny jak z filmu "Psy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322744,posel-ko-alarmuje-setki-workow-ze-zmielonymi-dokumentami-sceny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322744,posel-ko-alarmuje-setki-workow-ze-zmielonymi-dokumentami-sceny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T09:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/eb/1c/z30322755M,Dariusz-Jonski-i-Michal-Szczerba.jpg" vspace="2" />Agencja Bezpieczeństwa Wewnętrznego pięć dni przed wyborami rozpisała przetarg na zakup kartonu offsetowego, papieru do druku cyfrowego i 55 niszczarek. W sumie na to zamĂłwienie ABW było gotowe przeznaczyć niemal 400 tysięcy złotych. Poseł Michał Szczerba donosi z kolei o "sygnałach o wywożonych setkach workĂłw w nocy". Ministerstwo Obrony Narodowej natomiast już wcześniej zaprzeczało, że nikt dokumentĂłw nie niszczy.

## Leszczyna: Obajtek dzwoni do ludzi z opozycji. Zapewnia, że jest dobrym menadżerem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322720,leszczyna-obajtek-dzwoni-do-ludzi-z-opozycji-zapewnia-ze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322720,leszczyna-obajtek-dzwoni-do-ludzi-z-opozycji-zapewnia-ze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T09:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/be/e3/1c/z30290366M,-Konferencja-prezesa-PKN-Orlen-Daniela-Obajtka.jpg" vspace="2" />- Słyszałam, że Daniel Obajtek szuka teraz kontaktĂłw w naszym środowisku i dzwoni do rĂłżnych ludzi z opozycji. Szuka nowego parasola ochronnego, ale wśrĂłd nas na pewno go nie znajdzie - mĂłwiła w rozmowie z Money.pl Izabela Leszczyna, posłanka KO. - Przekonuje, że naprawdę jest bardzo dobrym menadżerem. MĂłwi, że już nawet te statki nie będą się teraz nazywały imionami ofiar katastrofy smoleńskiej, tylko będą takie inne już teraz - dodała polityczka.

## Masowe odejścia z TVP. Graczak i Borecki szukają nowej pracy. "Ewakuacja może być wizerunkowo lepsza"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323040,zmiany-w-tvp-dziennikarze-maja-masowo-odchodzic-z-pracy-ewakuacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30323040,zmiany-w-tvp-dziennikarze-maja-masowo-odchodzic-z-pracy-ewakuacja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T09:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/2d/1c/z29545381M,TVP-Info--zdjecie-ilustracyjne-.jpg" vspace="2" />Dziennikarze TVP oraz TVP Info mają planować odejścia ze stacji. - Ewakuacja może być dla nich wizerunkowo lepsza i bardziej honorowa niż zwolnienie - przyznał jeden z dziennikarzy TVP.

## Kłopoty opozycji. Nieoficjalnie: Nie będzie umowy koalicyjnej? Platforma Obywatelska może ją zastąpić
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323045,zgrzyty-na-opozycji-nieoficjalnie-nie-bedzie-umowy-koalicyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30323045,zgrzyty-na-opozycji-nieoficjalnie-nie-bedzie-umowy-koalicyjnej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T08:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/ea/1c/z30321921M,Liderzy-partii-opozycyjnych.jpg" vspace="2" />Z nieoficjalnych ustaleń WP.pl wynika, że kierownictwo PO rozważa inne rozwiązania w przypadku przedłużających się rozmĂłw z Trzecią Drogą i Lewicą o umowie koalicyjnej. Partia Donalda Tuska może wĂłwczas zaproponować deklarację koalicyjną. Podobna sytuacja miała już miejsce w 2007 roku. WĂłwczas na niespełna dwĂłch stronach napisano zasady utworzenia koalicji przez PO i PSL.

## Orban i Putin ściskają sobie dłonie. Zniesmaczona premierka Estonii krytykuje Węgry. Jest riposta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322667,orban-i-putin-sciskaja-sobie-dlonie-zniesmaczona-premierka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322667,orban-i-putin-sciskaja-sobie-dlonie-zniesmaczona-premierka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T08:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/eb/1c/z30322809M,Viktor-Orban-i-Wladimir-Putin-17-pazdziernik-2023.jpg" vspace="2" />- Jak można uścisnąć dłoń przestępcy, ktĂłry prowadzi agresywną wojnę, zwłaszcza jeśli pochodzi się z kraju, ktĂłry ma historię taką jak Węgry? - powiedziała premierka Estonii Kaja Kallas, komentując spotkanie, na ktĂłrym Viktor Orban i Władimir Putin wymienili uścisk dłoni. "Hipokryzja osiągnęła szczyt" - odpowiedział jej szef węgierskiego MSZ Peter Szijjarto.

## Szokujące ustalenia ws. wypadku na A1. Ujawniono dwie policyjne notatki. Ich treść sobie zaprzecza
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322739,szokujace-ustalenia-ws-wypadku-na-a1-ujawniono-dwie-policyjne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322739,szokujace-ustalenia-ws-wypadku-na-a1-ujawniono-dwie-policyjne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T08:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b8/dc/1c/z30265272M,Bmw-zniszczone-w-wyniku-wypadku-na-autostradzie-A1.jpg" vspace="2" />Po wypadku na A1 policjanci sporządzili dwie notatki, ktĂłre mają sobie wzajemnie zaprzeczać - wynika z ustaleń "Rzeczpospolitej". Według jednej z nich, sporządzonej przez oficera policji Sebastian M. nie spowodował wypadku. Z tym stwierdzeniem nie zgadzają się jednak policjanci, ktĂłrzy byli na miejscu wypadku, zaraz po tragedii.

## Roman Giertych wejdzie do rządu KO? "Podporządkuję się każdemu zadaniu, jakie wyznaczy mi Donald Tusk"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322647,roman-giertych-wejdzie-do-rzadu-ko-podporzadkuje-sie-kazdemu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322647,roman-giertych-wejdzie-do-rzadu-ko-podporzadkuje-sie-kazdemu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T08:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/c1/eb/1c/z30322881M,Roman-Giertych.jpg" vspace="2" />Roman Giertych uważa, że mĂłgłby zostać doradcą Donalda Tuska, gdy Koalicja Obywatelska przejmie władzę. Przyszły poseł odniĂłsł się rĂłwnież do możliwości wejścia w skład rządu. Tusk stwierdził, że "widzi rolę dla Giertycha" w nowym układzie politycznym. Część potencjalnych koalicjantĂłw KO nie jest tym zachwycona.

## ZabĂłjstwo 5-latka w Poznaniu. Sąd zdecydował ws. aresztu dla 71-letniego Zbysława C.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322962,smierc-5-latka-w-poznaniu-sad-zdecydowal-ws-aresztu-dla-71-letniego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322962,smierc-5-latka-w-poznaniu-sad-zdecydowal-ws-aresztu-dla-71-letniego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T08:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a7/ea/1c/z30320551M.jpg" vspace="2" />Sąd zdecydował o areszcie dla 71-letniego Zbysława C. Mężczyzna zadał śmiertelny cios pięcioletniemu Maurycemu. Usłyszał już zarzut zabĂłjstwa.

## Duda zaprasza na rozmowy ws. rządu. Będzie wspĂłlne oświadczenie liderĂłw opozycji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30322743,duda-zaprasza-na-rozmowy-ws-rzadu-bedzie-wspolne-oswiadczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30322743,duda-zaprasza-na-rozmowy-ws-rzadu-bedzie-wspolne-oswiadczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T07:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/78/46/1b/z28601976M,Wlodzimierz-Czarzasty--Szymon-Holownia--Donald-Tus.jpg" vspace="2" />- WspĂłlne oświadczenie liderĂłw ma być w poniedziałek. We wtorek są konsultacje i prezydent usłyszy jeden głos - przekazała Katarzyna Lubnauer. Jak dodała, "a już w środę, czwartek Donald Tusk wybiera się do Brukseli, by rozmawiać o pieniądzach z KPO".

## Raport Pentagonu nie pozostawia złudzeń: Chiny gwałtownie rozbudowały arsenał nuklearny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322489,raport-pentagonu-nie-pozostawia-zludzen-chiny-gwaltownie-rozbudowaly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322489,raport-pentagonu-nie-pozostawia-zludzen-chiny-gwaltownie-rozbudowaly.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T07:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/46/ea/1c/z30322502M,Xi-Jinping.jpg" vspace="2" />Zdaniem amerykańskich urzędnikĂłw, Chiny znacznie rozbudowały swĂłj arsenał nuklearny w ciągu ostatniego roku - podało w piątek BBC. Eksperci twierdzą, że Pekin "działa szybciej niż szacowano".

## Lublin. Wyborcy dostali w komisji ścieralny długopis. "Mogło być więcej podobnych przypadkĂłw"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322505,lublin-wyborcom-dano-scieralny-dlugopis-moglo-byc-wiecej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322505,lublin-wyborcom-dano-scieralny-dlugopis-moglo-byc-wiecej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T07:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ae/ea/1c/z30322606M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Wyborcy w Lublinie dostali w jednej z komisji ścieralny długopis do wypełnienia kart wyborczych. W związku z podejrzeniem naruszenia prawa wyborczego na terenie lokalu doszło do interwencji policji. Funkcjonariusze zabezpieczyli długopis, a obecnie trwa wyjaśnianie tej sprawy.

## Przyjrzeliśmy się wynikom PiS-u i KO, zauważyliśmy ważny szczegĂłł. To w tym KO była lepsza od konkurenta
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322402,przyjrzelismy-sie-wynikom-pis-u-i-ko-zauwazylismy-wazny-szczegol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322402,przyjrzelismy-sie-wynikom-pis-u-i-ko-zauwazylismy-wazny-szczegol.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/83/ea/1c/z30322563M,Jaroslaw-Kaczynski.jpg" vspace="2" />Choć Prawo i Sprawiedliwość zebrało ponad milion głosĂłw więcej od Koalicji Obywatelskiej, to KO miała silniejsze "jedynki" - wynika z naszej analizy. Na listach partii Jarosława Kaczyńskiego częściej zdarzało się, że dany lider był przeskakiwany przez inną osobę. Średnio "jedynki" PiS-u miały też niższy odsetek głosĂłw niż w przypadku KO.

## Kto będzie w nowym rządzie? Ruszyła giełda nazwisk
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322424,media-walka-o-najwazniejsze-stanowiska-w-nowym-rzadzie-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322424,media-walka-o-najwazniejsze-stanowiska-w-nowym-rzadzie-chodzi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:50:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/08/ea/1c/z30320648M,Donald-Tusk.jpg" vspace="2" />Najbardziej problematycznym do obsadzenia stanowiskiem dla rządu partii opozycyjnych będzie funkcja marszałka Sejmu. Jak dowiedział się "Newsweek", zainteresowani tą rolą są Szymon Hołownia, Piotr Zgorzelski z PSL, a także lider Nowej Lewicy Włodzimierz Czarzasty. Jednocześnie Donald Tusk chciałby powierzyć to stanowisko kobiecie ze swojego ugrupowania, co w jego ocenie dobrze wpłynęłoby na wspĂłłpracę z rządem. Kandydatką KO byłaby Marzena Okła-Drewnowicz, szefowa Platformy w Świętokrzyskiem.

## W Konfederacji spĂłr o wybory. Mentzen cytuje Biblię, szef sztabu oskarżony o romans. "Fanatycy Korwina"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322395,w-konfederacji-spor-o-wybory-mentzen-cytuje-biblie-szef-sztabu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322395,w-konfederacji-spor-o-wybory-mentzen-cytuje-biblie-szef-sztabu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0a/ca/1c/z30189066M,Konwencja-Konfederacji-w-Warszawie.jpg" vspace="2" />Witold Tumanowicz, ktĂłry wszedł w konflikt z Januszem Korwin-Mikkem i zgłosił go do sądu partyjnego, został oskarżony przez zwolennikĂłw Korwina o to, że zdradzał żonę. Politycy Konfederacji unikają komentowania tej sprawy. O tajemniczy wpis pokusił się jednak Sławomir Mentzen.

## Nieoficjalnie: Z polecenia Kaczyńskiego PiS przygotowuje się do oddania władzy. "Nikt nie rozmawia z PSL"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322388,nieoficjalnie-z-polecenia-kaczynskiego-pis-przygotowuje-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322388,nieoficjalnie-z-polecenia-kaczynskiego-pis-przygotowuje-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e5/ea/1c/z30322405M.jpg" vspace="2" />- Naprawdę ciężko sobie wyobrazić takie rozmowy, jeśli przez ostatnie osiem lat waliło się w Polskie Stronnictwo Ludowe i personalnie w politykĂłw tej partii - mĂłwi rozmĂłwca ze środowiska Prawa i Sprawiedliwości w rozmowie z Onetem. Ponadto Suwerenna Polska podobno nie planuje porzucać ugrupowania Jarosława Kaczyńskiego, mimo zdobytych 18 mandatĂłw w wyborach.

## Pogoda. Synoptycy IMGW wydali żĂłłte i pomarańczowe alerty. Wiatr do 160 km/h i anomalia temperatury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322387,pogoda-synoptycy-imgw-wydali-zolte-i-pomaranczowe-alerty-wiatr.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30322387,pogoda-synoptycy-imgw-wydali-zolte-i-pomaranczowe-alerty-wiatr.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/33/8c/1c/z29933875M,Pogoda--Alerty-IMGW--Synoptycy-zapowiadaja-silny-w.jpg" vspace="2" />Synoptycy Instytutu Meteorologii i Gospodarki Wodnej wydali ostrzeżenia pierwszego i drugiego stopnia przed silnym wiatrem. W najbliższych godzinach w Polsce pogoda będzie zmienna - na pĂłłnocy znacznie się ochłodzi, jednak na południu termometry wskażą nawet 20 st. C. W sobotę może paść rekord temperatury w październiku.

## Bohater memĂłw z "panem Areczkiem" stanął na czele dawnej partii Gowina. To skutek żądań Szymona Hołowni
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322383,bohater-memow-panie-areczku-stanal-na-czele-dawnej-partii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322383,bohater-memow-panie-areczku-stanal-na-czele-dawnej-partii.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:26:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/78/c5/1c/z30168696M,Stanislaw-Derehajlo.jpg" vspace="2" />Stanisław Derehajło, znany z memĂłw "panie Areczku", przejął zarządzanie Porozumieniem. Magdalena Sroka, dotychczasowa prezeska dawnej partii Jarosława Gowina, musiała zrezygnować ze swojej funkcji, aby kandydować z list Trzeciej Drogi do Sejmu. Kluczową rolę odegrała w tych negocjacjach Polska 2050 Szymona Hołowni.

## Włodzimierz Czarzasty o działaniu na zwłokę przez Andrzeja Dudę: Na sto procent niszczą dokumenty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322382,wlodzimierz-czarzasty-o-graniu-na-zwloke-pis-przez-andrzeja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30322382,wlodzimierz-czarzasty-o-graniu-na-zwloke-pis-przez-andrzeja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T06:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/03/ea/1c/z30322435M,Wlodzimierz-Czarzasty-z-partii-Nowa-Lewica.jpg" vspace="2" />Włodzimierz Czarzasty odniĂłsł się w Polsat News do kwestii kandydatury Donalda Tuska na premiera. Zdaniem polityka proces desygnacji może być zakłĂłcony przez "granie na zwłokę PiS" i "niszczenie dokumentĂłw". Lider partii Nowa Lewica zapowiedział, że opozycja sprawdzi i wyjawi tyle spraw, że "stĂłł się ugnie".

## Raport wywiadu USA ws. ataku na szpital w Gazie. Znacząco mniejsza liczba ofiar i brak kraterĂłw uderzeniowych
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322379,raport-wywiadu-usa-ws-ataku-na-szpital-w-gazie-znaczaco-mniejsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322379,raport-wywiadu-usa-ws-ataku-na-szpital-w-gazie-znaczaco-mniejsza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T05:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a4/ea/1c/z30320804M,Zdjecie-z-parkingu-szpitala-Al-Ahli--Widac-glownie.jpg" vspace="2" />Reuters dotarł do tajnego raportu amerykańskiego wywiadu, ktĂłry opisuje tragiczny pożar szpitala w Strefie Gazy. Z informacji USA wynika, że to nie Izrael był odpowiedzialny za atak rakietowy. W raporcie stwierdzono, że "zaobserwowano jedynie lekkie uszkodzenia strukturalne w szpitalu" i "nie zaobserwowano żadnych uszkodzeń głĂłwnego budynku szpitala ani kraterĂłw uderzeniowych". Znacząco mniejsza ma być też liczba ofiar.

## Niemcy przekażą 50 mln euro na pomoc Strefie Gazy. ONZ: Bliski WschĂłd jest na skraju przepaści
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322364,niemcy-przekaza-50-mln-euro-na-pomoc-strefie-gazy-onz-bliski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322364,niemcy-przekaza-50-mln-euro-na-pomoc-strefie-gazy-onz-bliski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T05:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/df/ea/1c/z30322399M,Strefa-Gazy.jpg" vspace="2" />Niemiecka ministerka spraw zagranicznych Annalena Baerbock ogłosiła pomoc w wysokości 50 milionĂłw euro dla ludności cywilnej w Strefie Gazy. Z oświadczenia resortu dyplomacji wynika, że Berlin przygotowuje się także do wysłania zespołĂłw medycznych do Strefy Gazy.

## Biden w orędziu o zagrożeniach dla Polski: Jeśli apetyt Putina nie zostanie powstrzymany, to pĂłjdzie on dalej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322363,biden-w-oredziu-o-zagrozeniach-dla-polski-jesli-apetyt-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30322363,biden-w-oredziu-o-zagrozeniach-dla-polski-jesli-apetyt-putina.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T04:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/ea/1c/z30321719M,Joe-Biden--zdjecie-ilustracyjne.jpg" vspace="2" />Joe Biden w telewizyjnym orędziu przekonywał, że nie można pozwolić, by Rosja przejęła kontrolę nad Ukrainą, ponieważ następne w kolejności mogą być Polska lub kraje bałtyckie. - Jeśli apetyt Putina nie zostanie powstrzymany na Ukrainie, to pĂłjdzie on dalej - podkreślał. W przemĂłwieniu prezydent USA porĂłwnał działania Rosji wobec Ukrainy do ataku Hamasu na Izrael.

## Czym powinna zająć się opozycja? Prof. Dudek wskazuje fundamentalną kwestię. "Było wiadomo, że będą swary"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30321783,czym-powinna-zajac-sie-opozycja-prof-dudek-wskazuje-fundamentalna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30321783,czym-powinna-zajac-sie-opozycja-prof-dudek-wskazuje-fundamentalna.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T04:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/ea/1c/z30321921M,Liderzy-partii-opozycyjnych.jpg" vspace="2" />- Od początku było wiadomo, że na opozycji będą swary i na to PiS gra. Jeśli ktoś pyta, po co PiS przedłuża proces przekazywania władzy, to właśnie po to - żeby pani Żukowska pożarła się z jakimś PSL-owcem, a PSL-owiec dowalił platformersowi - mĂłwi w Gazeta.pl prof. Antoni Dudek.

## Horoskop dzienny - piątek 20 października 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30320736,horoskop-dzienny-piatek-20-pazdziernika-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30320736,horoskop-dzienny-piatek-20-pazdziernika-2023-baran-byk.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-20T03:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/13/89/1c/z29924371M,Horoskop-dzienny---piatek.jpg" vspace="2" />Dla wielu ten dzień będzie zarĂłwno końcem, jak i początkiem nowego etapu w wielu sferach. Co czeka poszczegĂłlne znaki zodiaku? Horoskop dzienny na piątek 20 października odpowiada, co może się zdarzyć.

