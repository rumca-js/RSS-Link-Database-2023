# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## Three OBVIOUS Hobby Tips You Might Not Know
 - [https://www.youtube.com/watch?v=SFA9Qr4x5aU](https://www.youtube.com/watch?v=SFA9Qr4x5aU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-10-20T07:00:10+00:00

These are important hobby tips that some might call obvious, but they aren't obvious to everyone. Are you doing these three things (and one bonus)?

Vince Venturella and I made another game! Check out MAJESTIC 13 at http://www.majestic13game.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

