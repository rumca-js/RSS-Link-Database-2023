# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Rosja: Nowy dowódca sił powietrzno-kosmicznych. Zastąpił Surowikina
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-nowy-dowodca-sil-powietrzno-kosmicznych-zastapil-surow,nId,7099942](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-nowy-dowodca-sil-powietrzno-kosmicznych-zastapil-surow,nId,7099942)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T21:58:15+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosja-nowy-dowodca-sil-powietrzno-kosmicznych-zastapil-surow,nId,7099942"><img align="left" alt="Rosja: Nowy dowódca sił powietrzno-kosmicznych. Zastąpił Surowikina" src="https://i.iplsc.com/rosja-nowy-dowodca-sil-powietrzno-kosmicznych-zastapil-surow/000HUH53VK9L76B2-C321.jpg" /></a>Generał Wiktor Afzałow został mianowany dowódcą rosyjskich sił powietrzno-kosmicznych. Wcześniej, po marszu na Moskwę Grupy Wagnera, odsunięty z tego stanowiska został generał Siergiej Surowikin. Informacje na ten temat podaje Reuters, powołując się na rosyjskie państwowe agencje informacyjne RIA Nowosti i TASS.</p><br clear="all" />

## Jarosław Kaczyński o kampanii wyborczej PiS. "Popełniliśmy szereg błędów"
 - [https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-kampanii-wyborczej-pis-popelnilismy-sze,nId,7099938](https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-kampanii-wyborczej-pis-popelnilismy-sze,nId,7099938)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T20:43:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-jaroslaw-kaczynski-o-kampanii-wyborczej-pis-popelnilismy-sze,nId,7099938"><img align="left" alt="Jarosław Kaczyński o kampanii wyborczej PiS. &quot;Popełniliśmy szereg błędów&quot;" src="https://i.iplsc.com/jaroslaw-kaczynski-o-kampanii-wyborczej-pis-popelnilismy-sze/000HUGZJVY4O5P4E-C321.jpg" /></a>- Prawo i Sprawiedliwość popełniło szereg błędów w czasie kampanii wyborczej - powiedział Jarosław Kaczyński w Spale. Prezes partii rządzącej stwierdził, że przez ostatnie lata zmieniła się struktura elektoratu Polski, a proces ten będzie wciąż postępował. - Jeżeli PiS ma znów zwyciężać, musi wziąć to pod uwagę - podkreślił.</p><br clear="all" />

## Niezwykła anomalia. 23 stopnie w nocy na południu Polski
 - [https://wydarzenia.interia.pl/kraj/news-niezwykla-anomalia-23-stopnie-w-nocy-na-poludniu-polski,nId,7099930](https://wydarzenia.interia.pl/kraj/news-niezwykla-anomalia-23-stopnie-w-nocy-na-poludniu-polski,nId,7099930)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T20:29:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-niezwykla-anomalia-23-stopnie-w-nocy-na-poludniu-polski,nId,7099930"><img align="left" alt="Niezwykła anomalia. 23 stopnie w nocy na południu Polski" src="https://i.iplsc.com/niezwykla-anomalia-23-stopnie-w-nocy-na-poludniu-polski/000HUGY24H321111-C321.jpg" /></a>Niemal 23 stopnie Celsjusza pokazały termometry w Bielsko-Białej w piątek o godz. 21. Tymczasem w Elblągu słupki rtęci spadły do niespełna 2 stopni, by w ciągu nocy zbliżyć się w okolice zera. Pogoda przyzwyczaiła nas w tym roku do anomalii, jednak temperatura powyżej dwudziestu kresek w drugiej połowie października może zaskoczyć.</p><br clear="all" />

## Strefa Gazy. Uwolniono dwie pierwsze amerykańskie zakładniczki
 - [https://wydarzenia.interia.pl/zagranica/news-strefa-gazy-uwolniono-dwie-pierwsze-amerykanskie-zakladniczk,nId,7099933](https://wydarzenia.interia.pl/zagranica/news-strefa-gazy-uwolniono-dwie-pierwsze-amerykanskie-zakladniczk,nId,7099933)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T20:23:50+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-strefa-gazy-uwolniono-dwie-pierwsze-amerykanskie-zakladniczk,nId,7099933"><img align="left" alt="Strefa Gazy. Uwolniono dwie pierwsze amerykańskie zakładniczki" src="https://i.iplsc.com/strefa-gazy-uwolniono-dwie-pierwsze-amerykanskie-zakladniczk/000HUGWY5DEV9NHJ-C321.jpg" /></a>Większość zakładników uprowadzonych przez bojowników Hamasu do Strefy Gazy żyje - przekazały w piątek Siły Obronne Izraela (IDF), dodając, że ponad 20 z nich to osoby niepełnoletnie. Zgodnie z wcześniejszymi informacjami terroryści porwali z Izraela około 200 ludzi, a wśród nich znajdują się kobiety, dzieci i osoby starsze. Tego samego dnia rzecznik zbrojnego skrzydła palestyńskiego Hamasu Abu Obeida poinformował w komunikacie, że organizacja uwolniła dwie amerykańskie zakładniczki - matkę i córkę. Powodem miały być &quot;względy humanitarne&quot; i...</p><br clear="all" />

## Groza w Gdyni. Grzegorz Borys wciąż poszukiwany po morderstwie dziecka
 - [https://wydarzenia.interia.pl/pomorskie/news-groza-w-gdyni-grzegorz-borys-wciaz-poszukiwany-po-morderstwi,nId,7099868](https://wydarzenia.interia.pl/pomorskie/news-groza-w-gdyni-grzegorz-borys-wciaz-poszukiwany-po-morderstwi,nId,7099868)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T20:19:12+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-groza-w-gdyni-grzegorz-borys-wciaz-poszukiwany-po-morderstwi,nId,7099868"><img align="left" alt="Groza w Gdyni. Grzegorz Borys wciąż poszukiwany po morderstwie dziecka" src="https://i.iplsc.com/groza-w-gdyni-grzegorz-borys-wciaz-poszukiwany-po-morderstwi/000HUGXFI0IJ69R2-C321.jpg" /></a>- Na ulicach jest mniej osób. W autobusach można usłyszeć rozmowy, że ludzie boją się wychodzić z domu - mówią mieszkańcy Gdyni, gdzie trwa obława za 44-letnim Grzegorzem Borysem. Sąsiedzi są sfrustrowani - nie wiedzą, w jakim stanie psychicznym jest poszukiwany i do czego jest zdolny. Dyrektor pobliskiej szkoły zawiadomił wszystkich rodziców, że dzieci zostaną wypuszczone do domów tylko pod opieką osób dorosłych. Rodzice zapewniają, że będą ich odprowadzać do placówki, dopóki Borys nie zostanie schwytany. </p><br clear="all" />

## Tomasz Siemoniak: Polska nie jest w stanie zbudować 300-tysięcznej armii
 - [https://wydarzenia.interia.pl/kraj/news-tomasz-siemoniak-polska-nie-jest-w-stanie-zbudowac-300-tysie,nId,7099923](https://wydarzenia.interia.pl/kraj/news-tomasz-siemoniak-polska-nie-jest-w-stanie-zbudowac-300-tysie,nId,7099923)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T19:53:11+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-tomasz-siemoniak-polska-nie-jest-w-stanie-zbudowac-300-tysie,nId,7099923"><img align="left" alt="Tomasz Siemoniak: Polska nie jest w stanie zbudować 300-tysięcznej armii" src="https://i.iplsc.com/tomasz-siemoniak-polska-nie-jest-w-stanie-zbudowac-300-tysie/000HUGVADXL51N9A-C321.jpg" /></a>- Optymalnym wariantem jest 150-tysięczna armia zawodowa: 30-40 tysięcy obrony terytorialnej, 20-30 tysięcy dobrowolnej zasadniczej służby wojskowej i zbudowanie kilkusettysięcznej rezerwy - wskazał w piątek Tomasz Siemoniak. Jak zaznaczył były szef MON, Polska nie jest w stanie zbudować 300-tysięcznej armii, o której mówił na początku roku Mariusz Błaszczak, bo kraj &quot;nie posiada takiego potencjału demograficznego&quot;. Na słowa Siemoniaka zareagował szef MON.</p><br clear="all" />

## Putin spotkał się z Gierasimowem. Zwrócono uwagę na szczegół na zdjęciu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-spotkal-sie-z-gierasimowem-zwrocono-uwage-na-szczegol-,nId,7099896](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-spotkal-sie-z-gierasimowem-zwrocono-uwage-na-szczegol-,nId,7099896)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T19:35:13+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-spotkal-sie-z-gierasimowem-zwrocono-uwage-na-szczegol-,nId,7099896"><img align="left" alt="Putin spotkał się z Gierasimowem. Zwrócono uwagę na szczegół na zdjęciu" src="https://i.iplsc.com/putin-spotkal-sie-z-gierasimowem-zwrocono-uwage-na-szczegol/000HUGL4WNINOJML-C321.jpg" /></a>Prezydent Rosji Władimir Putin udał się do kwatery głównej wojsk rosyjskich w Rostowie nad Donem, gdzie spotkał się m.in. z Walerijem Gierasimowem. Z szefem sztabu generalnego rozmawiał o aktualnej sytuacji dotyczącej specjalnej operacji wojskowej (wojny w Ukrainie - red.). Według raportu realizacja celów idzie &quot;zgodnie z planem&quot;. Na zdjęcia ze spotkania zwrócił uwagę doradca szefa MSW Ukrainy, Anton Heraszczenko. Widać na nich prezydenta Rosji pochylającego się nad pustymi kartkami. &quot;Putin i Gierasimow posługują się bardzo dziwnymi mapami -...</p><br clear="all" />

## Maść wycofana z aptek w całej Polsce. "Skażenie substancji"
 - [https://wydarzenia.interia.pl/kraj/news-masc-wycofana-z-aptek-w-calej-polsce-skazenie-substancji,nId,7099847](https://wydarzenia.interia.pl/kraj/news-masc-wycofana-z-aptek-w-calej-polsce-skazenie-substancji,nId,7099847)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T19:24:04+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-masc-wycofana-z-aptek-w-calej-polsce-skazenie-substancji,nId,7099847"><img align="left" alt="Maść wycofana z aptek w całej Polsce. &quot;Skażenie substancji&quot;" src="https://i.iplsc.com/masc-wycofana-z-aptek-w-calej-polsce-skazenie-substancji/000HUG2M61M3LOQK-C321.jpg" /></a>Dwie partie maści Dexamytrex zostały wycofane z aptek w całej Polsce. Główny Inspektor Farmaceutyczny (GIF) poinformował w specjalnym komunikacie, że w preparacie wykryto mikrobiologiczne zanieczyszczenie substancji czynnej. Na ten sam krok zdecydowała się również niemiecka agencja lekowa.</p><br clear="all" />

## Groza na pokładzie. Samolot wypadł z pasa podczas lądowania
 - [https://wydarzenia.interia.pl/zagranica/news-groza-na-pokladzie-samolot-wypadl-z-pasa-podczas-ladowania,nId,7099872](https://wydarzenia.interia.pl/zagranica/news-groza-na-pokladzie-samolot-wypadl-z-pasa-podczas-ladowania,nId,7099872)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T19:00:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-groza-na-pokladzie-samolot-wypadl-z-pasa-podczas-ladowania,nId,7099872"><img align="left" alt="Groza na pokładzie. Samolot wypadł z pasa podczas lądowania" src="https://i.iplsc.com/groza-na-pokladzie-samolot-wypadl-z-pasa-podczas-ladowania/000HUG469WR5HYF6-C321.jpg" /></a>Przechodząca przez Wielką Brytanię Burza Babet przyniosła niemałe zawirowania nie tylko w pogodzie. Samolot lecący z Korfu podczas lądowania na lotnisku Leeds Bradford zjechał z pasa startowego wprost na trawnik. Służby oraz rzecznik portu lotniczego zapewniają, że nikt nie doznał obrażeń. Po zdarzeniu lotnisko zostało zamknięte.</p><br clear="all" />

## Donald Tusk do Jarosława Kaczyńskiego. "Co wy tam palicie?"
 - [https://wydarzenia.interia.pl/kraj/news-donald-tusk-do-jaroslawa-kaczynskiego-co-wy-tam-palicie,nId,7099900](https://wydarzenia.interia.pl/kraj/news-donald-tusk-do-jaroslawa-kaczynskiego-co-wy-tam-palicie,nId,7099900)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T18:40:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-donald-tusk-do-jaroslawa-kaczynskiego-co-wy-tam-palicie,nId,7099900"><img align="left" alt="Donald Tusk do Jarosława Kaczyńskiego. &quot;Co wy tam palicie?&quot;" src="https://i.iplsc.com/donald-tusk-do-jaroslawa-kaczynskiego-co-wy-tam-palicie/000HUGPNOM5RFW9I-C321.jpg" /></a>&quot;Kaczyński, co wy tam palicie? Przecież kopie są już u nas&quot; - napisał na platformie X Donald Tusk, komentując doniesienia o rzekomym niszczeniu dokumentów przez obecną partię rządzącą. Do oskarżeń wysuwanych przez dotychczasową opozycję odniósł się już wcześniej rzecznik rządu. - Mogę tylko się uśmiechnąć, bo takie rzeczy po prostu nie mają miejsca - stwierdził Piotr Müller, dodając że polityczni rywale &quot;naoglądali się filmów&quot;.</p><br clear="all" />

## Dwie policyjne notatki po wypadku na A1? Jest oświadczenie służb
 - [https://wydarzenia.interia.pl/lodzkie/news-dwie-policyjne-notatki-po-wypadku-na-a1-jest-oswiadczenie-sl,nId,7099890](https://wydarzenia.interia.pl/lodzkie/news-dwie-policyjne-notatki-po-wypadku-na-a1-jest-oswiadczenie-sl,nId,7099890)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T18:20:55+00:00

<p><a href="https://wydarzenia.interia.pl/lodzkie/news-dwie-policyjne-notatki-po-wypadku-na-a1-jest-oswiadczenie-sl,nId,7099890"><img align="left" alt="Dwie policyjne notatki po wypadku na A1? Jest oświadczenie służb" src="https://i.iplsc.com/dwie-policyjne-notatki-po-wypadku-na-a1-jest-oswiadczenie-sl/000HUGBESQCHDH9U-C321.jpg" /></a>&quot;Po wypadku, do którego doszło 16 września 2023 roku na autostradzie A1, została sporządzona tylko jedna notatka urzędowa mówiąca o przebiegu zdarzenia&quot;- oświadczyła łódzka policja, odnosząc się do publikacji &quot;Rzeczpospolitej&quot;. Jak dodano, &quot;autorem tego dokumentu nie jest 'wysoki oficer policji'&quot;. W komunikacie podkreślono, że rzekoma druga notatka nie powstała.</p><br clear="all" />

## Mocne słowa Bidena o Putinie. Kreml reaguje
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-bidena-o-putinie-kreml-reaguje,nId,7099705](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-bidena-o-putinie-kreml-reaguje,nId,7099705)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T17:58:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-mocne-slowa-bidena-o-putinie-kreml-reaguje,nId,7099705"><img align="left" alt="Mocne słowa Bidena o Putinie. Kreml reaguje" src="https://i.iplsc.com/mocne-slowa-bidena-o-putinie-kreml-reaguje/000HUGAKWHQA8APS-C321.jpg" /></a>- Nie akceptujemy takiego tonu wobec Rosji i naszego prezydenta - zaznaczył Dmitrij Pieskow, odnosząc się do wcześniejszych słów Joe Bidena. Prezydent USA w swoim przemówieniu mówił, że &quot;nie pozwolą takim terrorystom jak Hamas i tyranom jak Władimir Putin wygrać&quot;. Zdaniem rzecznika Kremla takie słowa nie przystoją &quot;odpowiedzialnym przywódcom państw&quot;.</p><br clear="all" />

## Wichura w Zakopanem. Łamie drzewa i niszczy budynki
 - [https://wydarzenia.interia.pl/malopolskie/news-wichura-w-zakopanem-lamie-drzewa-i-niszczy-budynki,nId,7099839](https://wydarzenia.interia.pl/malopolskie/news-wichura-w-zakopanem-lamie-drzewa-i-niszczy-budynki,nId,7099839)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T17:35:20+00:00

<p><a href="https://wydarzenia.interia.pl/malopolskie/news-wichura-w-zakopanem-lamie-drzewa-i-niszczy-budynki,nId,7099839"><img align="left" alt="Wichura w Zakopanem. Łamie drzewa i niszczy budynki" src="https://i.iplsc.com/wichura-w-zakopanem-lamie-drzewa-i-niszczy-budynki/000HUFZ1MPOBJR8V-C321.jpg" /></a>W południowej części Małopolski przez niebezpieczne warunki pogodowe strażacy odnotowują coraz więcej interwencji. W Zakopanem silny wiatr niszczy budynki, ogrodzenia i wywraca drzewa. W Tatrach mowa też o huraganowym wietrze, osiągającym nawet 140 km/h. Służby za pośrednictwem mediów społecznościowych ostrzegają mieszkańców przed kolejnymi wichurami i publikują zdjęcia szkód. Wydano ostrzeżenia drugiego stopnia.</p><br clear="all" />

## Chciał napompować oponę. Sięgnął po gaśnicę
 - [https://wydarzenia.interia.pl/zagranica/news-chcial-napompowac-opone-siegnal-po-gasnice,nId,7099637](https://wydarzenia.interia.pl/zagranica/news-chcial-napompowac-opone-siegnal-po-gasnice,nId,7099637)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T17:06:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chcial-napompowac-opone-siegnal-po-gasnice,nId,7099637"><img align="left" alt="Chciał napompować oponę. Sięgnął po gaśnicę" src="https://i.iplsc.com/chcial-napompowac-opone-siegnal-po-gasnice/000HUEUW4A6X656I-C321.jpg" /></a>Na niezwykły pomysł wpadł mężczyzna z Czech, który zatrzymując się na stacji paliw zdecydował się na napompowanie opony... gaśnicą. Ten niecodzienny sposób zarejestrowała kamera monitoringu. Nagranie trafiło do sieci, gdzie stało się prawdziwym hitem - pojawiła się masa komentarzy, a filmik obejrzano już milion razy. </p><br clear="all" />

## Uszkodzony gazociąg na Bałtyku. Tajemniczy przedmiot na dnie
 - [https://wydarzenia.interia.pl/zagranica/news-uszkodzony-gazociag-na-baltyku-tajemniczy-przedmiot-na-dnie,nId,7099679](https://wydarzenia.interia.pl/zagranica/news-uszkodzony-gazociag-na-baltyku-tajemniczy-przedmiot-na-dnie,nId,7099679)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T16:46:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-uszkodzony-gazociag-na-baltyku-tajemniczy-przedmiot-na-dnie,nId,7099679"><img align="left" alt="Uszkodzony gazociąg na Bałtyku. Tajemniczy przedmiot na dnie" src="https://i.iplsc.com/uszkodzony-gazociag-na-baltyku-tajemniczy-przedmiot-na-dnie/000HUFKWSFQG5B4P-C321.jpg" /></a>Pojawiają się nowe fakty w sprawie uszkodzenia podwodnego gazociągu i kabla telekomunikacyjnego łączącego Finlandię z Estonią. Obecnie dochodzenie w tej sprawie koncentruje się na roli chińskiego kontenerowca NewNew Polar Bear - przekazał w piątek Reuters, powołując się na oświadczenie fińskiego Krajowego Biura Śledczego. W komunikacie mowa także m.in. o &quot;ciężkim przedmiocie&quot; znalezionym na dnie morskim w pobliżu uszkodzenia rurociągu.</p><br clear="all" />

## Ruchy na Krymie mogą okazać się strategicznym błędem Rosji . "Irracjonalne"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ruchy-na-krymie-moga-okazac-sie-strategicznym-bledem-rosji-i,nId,7099313](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ruchy-na-krymie-moga-okazac-sie-strategicznym-bledem-rosji-i,nId,7099313)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T16:29:59+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ruchy-na-krymie-moga-okazac-sie-strategicznym-bledem-rosji-i,nId,7099313"><img align="left" alt="Ruchy na Krymie mogą okazać się strategicznym błędem Rosji . &quot;Irracjonalne&quot;" src="https://i.iplsc.com/ruchy-na-krymie-moga-okazac-sie-strategicznym-bledem-rosji-i/000HUCWO5KGJB2AC-C321.jpg" /></a>- Rosja podejmuje duże ryzyko, przerzucając swoje MiG-31 na Krym - uważa ekspert wojskowy Serhij Zgurec. Ocenia ten ruch jako fatalny, tłumacząc, że myśliwce stają się w ten sposób dobrym celem dla ukraińskich systemów uderzeniowych. Zgurec wyjaśnia, że decyzja Moskwy jest ruchem czysto propagandowym. Poprzez stworzenie nowego zagrożenia na Morzu Czarnym, Kreml chce wywrzeć presję na Zachód.</p><br clear="all" />

## Zabójstwo 6-latka w Gdyni. "Mężczyzna agresywny, chodził w kominiarce"
 - [https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-6-latka-w-gdyni-mezczyzna-agresywny-chodzil-w-komi,nId,7099670](https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-6-latka-w-gdyni-mezczyzna-agresywny-chodzil-w-komi,nId,7099670)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T15:55:53+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-zabojstwo-6-latka-w-gdyni-mezczyzna-agresywny-chodzil-w-komi,nId,7099670"><img align="left" alt="Zabójstwo 6-latka w Gdyni. &quot;Mężczyzna agresywny, chodził w kominiarce&quot;" src="https://i.iplsc.com/zabojstwo-6-latka-w-gdyni-mezczyzna-agresywny-chodzil-w-komi/000HUFKHQWGJAVIX-C321.jpg" /></a>- Poszukiwany ojciec dziecka przychodził na plac zabaw ze swoim synem i bywał bardzo agresywny. Zwracał uwagę ubiorem, nosił kominiarkę i okulary przeciwsłoneczne, jak jakiś komandos. Przeczuwaliśmy, że może się coś stać - mówią zaniepokojeni gdynianie po morderstwie sześciolatka na Wielkim Kacku. Według sąsiadów mężczyzna, za którym trwa obława, łatwo się denerwował, a &quot;syn i żona chodzili przy nim jak na szpilkach&quot;.  </p><br clear="all" />

## Alarmy bombowe paraliżują Francję. Ewakuacje tysięcy obywateli
 - [https://wydarzenia.interia.pl/zagranica/news-alarmy-bombowe-paralizuja-francje-ewakuacje-tysiecy-obywatel,nId,7099622](https://wydarzenia.interia.pl/zagranica/news-alarmy-bombowe-paralizuja-francje-ewakuacje-tysiecy-obywatel,nId,7099622)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T15:21:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-alarmy-bombowe-paralizuja-francje-ewakuacje-tysiecy-obywatel,nId,7099622"><img align="left" alt="Alarmy bombowe paraliżują Francję. Ewakuacje tysięcy obywateli" src="https://i.iplsc.com/alarmy-bombowe-paralizuja-francje-ewakuacje-tysiecy-obywatel/000HUEXQV0F5GTRD-C321.jpg" /></a>Dziesiątki alarmów bombowych zastraszają od kilku dni francuskie społeczeństwo. Niepokojące wiadomości trafiają do instytucji publicznych i lotnisk, wymuszając ewakuację tysięcy osób. Wśród zatrzymanych znalazł się m.in. 16-latek, który miał wywołać alarm w jeden z podparyskich szkół. Państwo zobowiązało się walczyć z &quot;małymi żartownisiami bez poczucia odpowiedzialności&quot;. Stołeczna prokurator ostrzega przed wysokimi karami.</p><br clear="all" />

## Nie zgłosili transportu 20 ton gazu. Akcja służb
 - [https://wydarzenia.interia.pl/kraj/news-nie-zglosili-transportu-20-ton-gazu-akcja-sluzb,nId,7099591](https://wydarzenia.interia.pl/kraj/news-nie-zglosili-transportu-20-ton-gazu-akcja-sluzb,nId,7099591)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T14:25:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nie-zglosili-transportu-20-ton-gazu-akcja-sluzb,nId,7099591"><img align="left" alt="Nie zgłosili transportu 20 ton gazu. Akcja służb" src="https://i.iplsc.com/nie-zglosili-transportu-20-ton-gazu-akcja-sluzb/000HUDSEP26OXNF9-C321.jpg" /></a>Kara o łącznej wysokości 25 tys. złotych została nałożona na przewoźnika i kierowcę, którzy nie zarejestrowali przewozu 20 ton gazu propan-butan w Systemie Elektronicznego Nadzoru Transportu. Ładunek jechał z Łotwy na Słowację, jednak taki transfer zgodnie z przepisami wymaga również rejestracji w polskim systemie bezpieczeństwa.</p><br clear="all" />

## Jak nowy rząd zamierza przejąć kontrolę nad TVP? Poznaliśmy cztery możliwe scenariusze
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-jak-nowy-rzad-zamierza-przejac-kontrole-nad-tvp-poznalismy-c,nId,7099585](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-jak-nowy-rzad-zamierza-przejac-kontrole-nad-tvp-poznalismy-c,nId,7099585)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T13:54:56+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-jak-nowy-rzad-zamierza-przejac-kontrole-nad-tvp-poznalismy-c,nId,7099585"><img align="left" alt="Jak nowy rząd zamierza przejąć kontrolę nad TVP? Poznaliśmy cztery możliwe scenariusze" src="https://i.iplsc.com/jak-nowy-rzad-zamierza-przejac-kontrole-nad-tvp-poznalismy-c/000HUDMXAOJNQPBF-C321.jpg" /></a>Jedną z pierwszych decyzji nowej koalicji rządzącej ma być rewolucja w TVP. Nie będzie to jednak proste. Wszelkie zmiany może bowiem zablokować prezydent. Politycy, którzy za chwilę będą współtworzyć rząd, szukają więc sposobu, jak obejść prezydenckie weto i przeprowadzić zmiany bez konieczności uchwalania ustaw. - To jest trudne, ale nie niemożliwe - twierdzą nasi rozmówcy. - Widzimy, co się dzieje i jesteśmy przygotowani na różne scenariusze - zapowiada w rozmowie z Interią Krzysztof Czabański, szef Rady Mediów Narodowych.</p><br clear="all" />

## Wtedy zbierze się nowy Sejm. "Na to wskazują wszystkie okoliczności"
 - [https://wydarzenia.interia.pl/kraj/news-wtedy-zbierze-sie-nowy-sejm-na-to-wskazuja-wszystkie-okolicz,nId,7099529](https://wydarzenia.interia.pl/kraj/news-wtedy-zbierze-sie-nowy-sejm-na-to-wskazuja-wszystkie-okolicz,nId,7099529)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T12:50:53+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wtedy-zbierze-sie-nowy-sejm-na-to-wskazuja-wszystkie-okolicz,nId,7099529"><img align="left" alt="Wtedy zbierze się nowy Sejm. &quot;Na to wskazują wszystkie okoliczności&quot;" src="https://i.iplsc.com/wtedy-zbierze-sie-nowy-sejm-na-to-wskazuja-wszystkie-okolicz/000HUCT6X5TO26RB-C321.jpg" /></a>Szef Gabinetu Prezydenta Paweł Szrot zapewnił, że zwołanie pierwszego posiedzenia Sejmu nowej kadencji nie będzie w żaden sposób &quot;przeciągane&quot;. Wskazał też, kiedy biorąc pod uwagę &quot;wszystkie okoliczności&quot; się ono odbędzie. - Będzie to robione w takim samym trybie i tempie, w jakim były wszystkie poprzednie zmiany - zapowiedział. </p><br clear="all" />

## Król Holandii zaatakowany. Interweniowała policja i ochrona
 - [https://wydarzenia.interia.pl/zagranica/news-krol-holandii-zaatakowany-interweniowala-policja-i-ochrona,nId,7099537](https://wydarzenia.interia.pl/zagranica/news-krol-holandii-zaatakowany-interweniowala-policja-i-ochrona,nId,7099537)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T12:39:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-krol-holandii-zaatakowany-interweniowala-policja-i-ochrona,nId,7099537"><img align="left" alt="Król Holandii zaatakowany. Interweniowała policja i ochrona" src="https://i.iplsc.com/krol-holandii-zaatakowany-interweniowala-policja-i-ochrona/000HUCTY9IWY6W4T-C321.jpg" /></a>Król Niderlandów Wilhelm Aleksander został zaatakowany przez demonstrantów przed muzeum niewolnictwa w Kapsztadzie w RPA. Protestujący ubrani w tradycyjne stroje trzymali tabliczki z napisami &quot;szanuj nas&quot; i &quot;oddaj nasz kraj&quot;. Na udostępnionych w sieci nagraniach widać szybką reakcję ochrony.</p><br clear="all" />

## Rosjanie chcą wysłać tysiące nastolatków na front. Ruszyły szkolenia
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-chca-wyslac-tysiace-nastolatkow-na-front-ruszyly-sz,nId,7099294](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-chca-wyslac-tysiace-nastolatkow-na-front-ruszyly-sz,nId,7099294)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T12:22:32+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-rosjanie-chca-wyslac-tysiace-nastolatkow-na-front-ruszyly-sz,nId,7099294"><img align="left" alt="Rosjanie chcą wysłać tysiące nastolatków na front. Ruszyły szkolenia" src="https://i.iplsc.com/rosjanie-chca-wyslac-tysiace-nastolatkow-na-front-ruszyly-sz/000H3E69G8UKAQTX-C321.jpg" /></a>Rosjanie chcą zaangażować w działania wojenne tysiące nastolatków. Mają uzupełnić braki, które posiada rosyjska armia. Specjalne kursy są przeznaczone dla dzieci, które zamieszkują okupowany przez Rosjan obwód ługański. </p><br clear="all" />

## Nagłe zniknięcie miliardów krabów. Naukowcy podejrzewają, co się z nimi stało
 - [https://wydarzenia.interia.pl/zagranica/news-nagle-znikniecie-miliardow-krabow-naukowcy-podejrzewaja-co-s,nId,7099149](https://wydarzenia.interia.pl/zagranica/news-nagle-znikniecie-miliardow-krabow-naukowcy-podejrzewaja-co-s,nId,7099149)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T12:07:15+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nagle-znikniecie-miliardow-krabow-naukowcy-podejrzewaja-co-s,nId,7099149"><img align="left" alt="Nagłe zniknięcie miliardów krabów. Naukowcy podejrzewają, co się z nimi stało" src="https://i.iplsc.com/nagle-znikniecie-miliardow-krabow-naukowcy-podejrzewaja-co-s/000HUBHZPWJWWVQ1-C321.jpg" /></a>W ostatnich latach z wód wokół Alaski zniknęły miliardy krabów śnieżnych. Przez długi czas naukowcy nie wiedzieli, co może być przyczyną wymierania skorupiaków. Okazało się, że winne najprawdopodobniej są fale upałów, które podwyższyły temperaturę oceanów. Zwierzęta umierały z głodu.</p><br clear="all" />

## Ukraiński minister reaguje na ruch Orbana. "Mam nadzieję, że umył ręce"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainski-minister-reaguje-na-ruch-orbana-mam-nadzieje-ze-um,nId,7099220](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainski-minister-reaguje-na-ruch-orbana-mam-nadzieje-ze-um,nId,7099220)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:58:34+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainski-minister-reaguje-na-ruch-orbana-mam-nadzieje-ze-um,nId,7099220"><img align="left" alt="Ukraiński minister reaguje na ruch Orbana. &quot;Mam nadzieję, że umył ręce&quot;" src="https://i.iplsc.com/ukrainski-minister-reaguje-na-ruch-orbana-mam-nadzieje-ze-um/000HUC6FXPSSMPQL-C321.jpg" /></a>- Mam nadzieję, że przynajmniej umył i zdezynfekował ręce po uścisku dłoni z Putinem - odpowiedział minister spraw zagranicznych Ukrainy Dmytro Kułeba, gdy zapytano go o niedawne spotkanie premiera Węgier Viktora Orbana z rosyjskim dyktatorem. Dyplomata nie krył oburzenia spotkaniem, które wywołało w przestrzeni medialnej ogromne poruszenie. Bulwersująca była nie tylko rozmowa, ale i sam fakt, że Orban wojnę w Ukrainie ku uciesze Rosjan nazywał &quot;operacją wojskową&quot;.</p><br clear="all" />

## Jechał pod prąd na ekspresówce. Wiózł dzieci do domu
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-jechal-pod-prad-na-ekspresowce-wiozl-dzieci-do-domu,nId,7099173](https://wydarzenia.interia.pl/warminsko-mazurskie/news-jechal-pod-prad-na-ekspresowce-wiozl-dzieci-do-domu,nId,7099173)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:45:37+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-jechal-pod-prad-na-ekspresowce-wiozl-dzieci-do-domu,nId,7099173"><img align="left" alt="Jechał pod prąd na ekspresówce. Wiózł dzieci do domu" src="https://i.iplsc.com/jechal-pod-prad-na-ekspresowce-wiozl-dzieci-do-domu/000HUCIQPHDCN740-C321.jpg" /></a>Kierowca busa wiozący dzieci wjechał pod prąd na drogę ekspresową S7 i nie ustąpił pierwszeństwa prawidłowo jadącym pojazdom. Wiózł dzieci, które wracały do domu po meczu piłki nożnej. Niebezpieczne zachowanie mężczyzny zostało zarejestrowano przez kamerkę samochodową innego auta. </p><br clear="all" />

## Ciało młodej kobiety w warszawskim hotelu. Znalazł je personel
 - [https://wydarzenia.interia.pl/mazowieckie/news-cialo-mlodej-kobiety-w-warszawskim-hotelu-znalazl-je-persone,nId,7099250](https://wydarzenia.interia.pl/mazowieckie/news-cialo-mlodej-kobiety-w-warszawskim-hotelu-znalazl-je-persone,nId,7099250)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:26:04+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-cialo-mlodej-kobiety-w-warszawskim-hotelu-znalazl-je-persone,nId,7099250"><img align="left" alt="Ciało młodej kobiety w warszawskim hotelu. Znalazł je personel" src="https://i.iplsc.com/cialo-mlodej-kobiety-w-warszawskim-hotelu-znalazl-je-persone/000D96DKF8UKD5NU-C321.jpg" /></a>W jednym z warszawskim hoteli odnaleziono ciało młodej kobiety. Prokuratura nie wyklucza, że do jej śmierci doszło w wyniku działań osób trzecich. Media informują, że kobieta była wcześniej poszukiwana. </p><br clear="all" />

## Mieszkańcy nie chcieli dewelopera. "Radni po prostu wyszli"
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-mieszkancy-nie-chcieli-dewelopera-radni-po-prostu-wyszli,nId,7099234](https://wydarzenia.interia.pl/dolnoslaskie/news-mieszkancy-nie-chcieli-dewelopera-radni-po-prostu-wyszli,nId,7099234)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:24:26+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-mieszkancy-nie-chcieli-dewelopera-radni-po-prostu-wyszli,nId,7099234"><img align="left" alt="Mieszkańcy nie chcieli dewelopera. &quot;Radni po prostu wyszli&quot;" src="https://i.iplsc.com/mieszkancy-nie-chcieli-dewelopera-radni-po-prostu-wyszli/000HUC961EWE93O6-C321.jpg" /></a>Wrocławscy radni zajmowali się sprawą uchwalenia miejscowego planu zagospodarowania przestrzennego. Planom miasta sprzeciwiają się jednak mieszkańcy ulic, których plan zagospodarowania dotyczy. Uważają, że magistrat daje zarobić deweloperowi kosztem ich jakości życia. Kiedy członek zarządu wspólnoty mieszkaniowej wszedł na mównicę, radni z klubu Forum Jacka Sutryka mieli wyjść z sali. &quot;Nie byli kompletnie zainteresowani tym, co mówi wrocławianin&quot; - relacjonuje &quot;Gazeta Wrocławska&quot;.</p><br clear="all" />

## Co dalej z zakazem handlu w niedziele? Jasny sygnał i komplikacje
 - [https://wydarzenia.interia.pl/kraj/news-co-dalej-z-zakazem-handlu-w-niedziele-jasny-sygnal-i-komplik,nId,7099224](https://wydarzenia.interia.pl/kraj/news-co-dalej-z-zakazem-handlu-w-niedziele-jasny-sygnal-i-komplik,nId,7099224)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:23:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-co-dalej-z-zakazem-handlu-w-niedziele-jasny-sygnal-i-komplik,nId,7099224"><img align="left" alt="Co dalej z zakazem handlu w niedziele? Jasny sygnał i komplikacje" src="https://i.iplsc.com/co-dalej-z-zakazem-handlu-w-niedziele-jasny-sygnal-i-komplik/000HUCE4SO0XS5DE-C321.jpg" /></a>Koalicja Obywatelska w swoim wyborczym programie zapisała, że zniesie zakaz handlu w niedziele. O obowiązujących obecnie przepisach ograniczających pracę w dzień wolny Szymon Hołownia mówi: &quot;absurdalne&quot;. Politycy PSL wprowadzenie zmian popierają, bo &quot;tak wynika z rozmów&quot;. Lewica od pomysłu się nie odcina. Zapytaliśmy polityków, czy to oznacza, że ograniczenie handlu obowiązujące od pięciu lat zostanie zniesione? Przedstawiciele branży do pomysłu podchodzą z ostrożnością, a część z nich mówi wprost: jesteśmy zadowoleni z obecnego systemu. </p><br clear="all" />

## Ukraińskie ministerstwo pokazało najnowszy raport. Cytują Napoleona
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-ministerstwo-pokazalo-najnowszy-raport-cytuja-nap,nId,7098996](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-ministerstwo-pokazalo-najnowszy-raport-cytuja-nap,nId,7098996)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:19:55+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukrainskie-ministerstwo-pokazalo-najnowszy-raport-cytuja-nap,nId,7098996"><img align="left" alt="Ukraińskie ministerstwo pokazało najnowszy raport. Cytują Napoleona" src="https://i.iplsc.com/ukrainskie-ministerstwo-pokazalo-najnowszy-raport-cytuja-nap/000HU8ABWX06UUP0-C321.jpg" /></a>Ukraińcy w najnowszym raporcie ministerstwa obrony podsumowali straty wojenne Rosjan od początku inwazji. W trakcie walk życie straciło już niemal 300 tysięcy rosyjskich żołnierzy. Wpis, w którym zaprezentowano dane okraszono cytatem z Napoleona. Sztab Generalny przekazał, że ostatniej doby zabito 1380 Rosjan, co jest rekordową liczbą. </p><br clear="all" />

## Spięcie na konferencji lidera PSL. "Każdy może się wypowiedzieć"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-spiecie-na-konferencji-lidera-psl-kazdy-moze-sie-wypowiedzie,nId,7099159](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-spiecie-na-konferencji-lidera-psl-kazdy-moze-sie-wypowiedzie,nId,7099159)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T11:13:09+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-spiecie-na-konferencji-lidera-psl-kazdy-moze-sie-wypowiedzie,nId,7099159"><img align="left" alt="Spięcie na konferencji lidera PSL. &quot;Każdy może się wypowiedzieć&quot;" src="https://i.iplsc.com/spiecie-na-konferencji-lidera-psl-kazdy-moze-sie-wypowiedzie/000HUBQYSB6W3QH4-C321.jpg" /></a>- Proszę państwa, widzicie, to jest zmiana sposobu rządzenia - powiedział Władysław Kosiniak-Kamysz, gdy próbowano przerwać wypowiedź zadającego pytanie seniora. Gdy ten skończył, lider ludowców odpowiedział, a następnie podkreślił, że &quot;każdy ma prawo się wypowiedzieć&quot;. - To jest zmiana podejścia do każdego obywatela. Szacunek, a nie wyłączanie mikrofonu - kilkukrotnie powtarzał polityk. Dodał też, że &quot;każdy będzie miał w naszej ojczyźnie godne miejsce i będzie zaopiekowany&quot;.</p><br clear="all" />

## Gdynia: Nie żyje sześcioletni chłopiec. Trwa policyjna obława
 - [https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletni-chlopiec-trwa-policyjna-oblawa,nId,7099198](https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletni-chlopiec-trwa-policyjna-oblawa,nId,7099198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T10:12:49+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletni-chlopiec-trwa-policyjna-oblawa,nId,7099198"><img align="left" alt="Gdynia: Nie żyje sześcioletni chłopiec. Trwa policyjna obława" src="https://i.iplsc.com/gdynia-nie-zyje-szescioletni-chlopiec-trwa-policyjna-oblawa/000HUCFAEDOAFCF6-C321.jpg" /></a>W Gdyni znaleziono zwłoki sześcioletniego chłopca. Na miejscu pracują służby. - Do śmierci dziecka przyczyniły się prawdopodobnie osoby trzecie - przekazała Interii rzeczniczka pomorskiej policji kom. Karina Kamińska. Na miejscu trwa policyjna obława. Funkcjonariusze poszukują ojca dziecka 44-letniego Grzegorza Borysa.</p><br clear="all" />

## Gdynia: Nie żyje sześcioletnie dziecko. Trwa policyjna obława
 - [https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletnie-dziecko-trwa-policyjna-oblawa,nId,7099198](https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletnie-dziecko-trwa-policyjna-oblawa,nId,7099198)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T10:12:49+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-gdynia-nie-zyje-szescioletnie-dziecko-trwa-policyjna-oblawa,nId,7099198"><img align="left" alt="Gdynia: Nie żyje sześcioletnie dziecko. Trwa policyjna obława" src="https://i.iplsc.com/gdynia-nie-zyje-szescioletnie-dziecko-trwa-policyjna-oblawa/000FZ899M2IC99HN-C321.jpg" /></a>W Gdyni znaleziono zwłoki sześciolatka. Na miejscu pracują służby. - Do śmierci dziecka przyczyniły się prawdopodobnie osoby trzecie - przekazała Interii rzeczniczka pomorskiej policji. Jak ustalił Polsat News, na miejscu trwa policyjna obława, funkcjonariusze mają szukać ojca dziecka.</p><br clear="all" />

## Aline i Babet idą przez Europę. Pierwsza ofiara śmiertelna
 - [https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsza-ofiara-smiertelna,nId,7099167](https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsza-ofiara-smiertelna,nId,7099167)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T10:10:20+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-aline-i-babet-ida-przez-europe-pierwsza-ofiara-smiertelna,nId,7099167"><img align="left" alt="Aline i Babet idą przez Europę. Pierwsza ofiara śmiertelna" src="https://i.iplsc.com/aline-i-babet-ida-przez-europe-pierwsza-ofiara-smiertelna/000HUC3I21YR1T41-C321.jpg" /></a>Dwie potężne burze - Aline i Babet - przetaczają się przez zachodnią Europę. W wielu krajach ogłoszono czerwony alarm. W części Francji zamknięto szkoły i uniwersytety. W Hiszpanii odnotowano ponad tysiąc interwencji, ulice Madrytu zostały zalane z powodu największej od ponad stu lat ulewy. W Szkocji setki ludzi trzeba było ewakuować z domów zagrożonych powodzią, stwierdzono też pierwszą śmiertelną ofiarę żywiołu.</p><br clear="all" />

## Zderzenie trzech pojazdów na Mazowszu. Jabłka zasypały drogę
 - [https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-trzech-pojazdow-na-mazowszu-jablka-zasypaly-droge,nId,7099130](https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-trzech-pojazdow-na-mazowszu-jablka-zasypaly-droge,nId,7099130)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T09:44:44+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-zderzenie-trzech-pojazdow-na-mazowszu-jablka-zasypaly-droge,nId,7099130"><img align="left" alt="Zderzenie trzech pojazdów na Mazowszu. Jabłka zasypały drogę " src="https://i.iplsc.com/zderzenie-trzech-pojazdow-na-mazowszu-jablka-zasypaly-droge/000HUBNUOM60F8UN-C321.jpg" /></a>Niebezpieczne zderzenie i zablokowana droga w powiecie żyrardowskim. Trzy samochody, w tym ciężarówka wypełniona owocami, brały udział w kolizji w miejscowości Kamion. - Jedna osoba w wyniku zderzenia zostało przewieziona do szpitala - potwierdziła w rozmowie z Interią st. sierż. Patrycja Sochacka. Policja zabezpiecza miejsce i zaleca korzystanie z objazdów.</p><br clear="all" />

## Zdjęcie szefa linii lotniczych wywołało burzę. "Miałem stresujący dzień"
 - [https://wydarzenia.interia.pl/zagranica/news-zdjecie-szefa-linii-lotniczych-wywolalo-burze-mialem-stresuj,nId,7099059](https://wydarzenia.interia.pl/zagranica/news-zdjecie-szefa-linii-lotniczych-wywolalo-burze-mialem-stresuj,nId,7099059)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T09:20:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zdjecie-szefa-linii-lotniczych-wywolalo-burze-mialem-stresuj,nId,7099059"><img align="left" alt="Zdjęcie szefa linii lotniczych wywołało burzę. &quot;Miałem stresujący dzień&quot;" src="https://i.iplsc.com/zdjecie-szefa-linii-lotniczych-wywolalo-burze-mialem-stresuj/000HUBHTTKE7VUNN-C321.jpg" /></a>Szef linii lotniczych AirAsia Tony Fernandes opublikował nietypowe zdjęcie w serwisie Linkedin. Mężczyzna był masowany podczas spotkania zarządu. Nie miał na sobie koszulki. &quot;Miałem stresujący tydzień&quot; - napisał i załączył fotografię. Wpis wywołał burzę i po kilku dniach został usunięty. &quot;Nie sądzę, aby kobiety w twojej firmie czuły się w tym kontekście komfortowo i bezpiecznie&quot; - napisała jedna z internautek. </p><br clear="all" />

## Premier Włoch rozstała się z partnerem. To efekt skandalu
 - [https://wydarzenia.interia.pl/zagranica/news-premier-wloch-rozstala-sie-z-partnerem-to-efekt-skandalu,nId,7099113](https://wydarzenia.interia.pl/zagranica/news-premier-wloch-rozstala-sie-z-partnerem-to-efekt-skandalu,nId,7099113)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T09:06:17+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-premier-wloch-rozstala-sie-z-partnerem-to-efekt-skandalu,nId,7099113"><img align="left" alt="Premier Włoch rozstała się z partnerem. To efekt skandalu" src="https://i.iplsc.com/premier-wloch-rozstala-sie-z-partnerem-to-efekt-skandalu/000HUB7BKD4JC4KJ-C321.jpg" /></a>Premier Włoch Giorgia Meloni poinformowała, że rozstaje się ze swoim partnerem Andreą Giambrunem. Ich związek trwał prawie dziesięć lat. &quot;Dziękuję mu za wspaniałe lata, które spędziliśmy razem, za trudności, przez które przeszliśmy i za to, że dał mi najważniejszą rzecz w moim życiu, czyli naszą córkę Ginevrę&quot; - napisała szefowa włoskiego rządu. Andrea Giambruno wywołał skandal swoimi kontrowersyjnymi wypowiedziami, a jedna z telewizji ujawniła nagranie, prezentujące jego wulgarne zachowanie.</p><br clear="all" />

## Uciekają z TVP jeszcze przed zmianą władzy. Nieoficjalne doniesienia
 - [https://wydarzenia.interia.pl/kraj/news-uciekaja-z-tvp-jeszcze-przed-zmiana-wladzy-nieoficjalne-doni,nId,7099102](https://wydarzenia.interia.pl/kraj/news-uciekaja-z-tvp-jeszcze-przed-zmiana-wladzy-nieoficjalne-doni,nId,7099102)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T08:59:50+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-uciekaja-z-tvp-jeszcze-przed-zmiana-wladzy-nieoficjalne-doni,nId,7099102"><img align="left" alt="Uciekają z TVP jeszcze przed zmianą władzy. Nieoficjalne doniesienia " src="https://i.iplsc.com/uciekaja-z-tvp-jeszcze-przed-zmiana-wladzy-nieoficjalne-doni/000HUB81CQPDPEXI-C321.jpg" /></a>Choć od wyborów minęło zaledwie kilka dni, opozycja nie przejęła dotąd władzy, a ewentualne zmiany w Telewizji Polskiej to perspektywa miesięcy, a nie dni, część pracowników &quot;Wiadomości&quot; i TVP Info już nosi się z zamiarem odejścia - informuje nieoficjalnie portal Wirtualnemedia.pl. - Jeśli mają za co żyć, to ewakuacja może być dla nich wizerunkowo lepsza i bardziej honorowa niż zwolnienie - twierdzi jeden z zatrudnionych w TVP. Wstępnie padają nazwiska dwóch osób.</p><br clear="all" />

## Zabójstwo kobiety w Suwałkach. Mieszkańcy obawiają się kolejnych ataków
 - [https://wydarzenia.interia.pl/podlaskie/news-zabojstwo-kobiety-w-suwalkach-mieszkancy-obawiaja-sie-kolejn,nId,7099053](https://wydarzenia.interia.pl/podlaskie/news-zabojstwo-kobiety-w-suwalkach-mieszkancy-obawiaja-sie-kolejn,nId,7099053)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T08:45:39+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-zabojstwo-kobiety-w-suwalkach-mieszkancy-obawiaja-sie-kolejn,nId,7099053"><img align="left" alt="Zabójstwo kobiety w Suwałkach. Mieszkańcy obawiają się kolejnych ataków" src="https://i.iplsc.com/zabojstwo-kobiety-w-suwalkach-mieszkancy-obawiaja-sie-kolejn/000HUAKB850KUNNE-C321.jpg" /></a>- Nie otrzymaliśmy zgłoszeń o atakach nożownika w Suwałkach - powiedział Interii rzecznik podlaskiej policji podkom. Marcin Gawryluk. Mundurowi uspokajają i proszą o nierozpowszechnianie niepotwierdzonych informacji. Doniesienia pojawiły się w związku z trwającą na Podlasiu obławą za 53-letnim Tadeuszem Zagórskim, podejrzanym o zabójstwo kobiety. Policja opublikowała wizerunek poszukiwanego i prosi o informacje każdego, kto może wiedzieć, gdzie mężczyzna się ukrywa. </p><br clear="all" />

## Śmierć pięciolatka w Poznaniu. Tymczasowy areszt dla 71-letniego nożownika
 - [https://wydarzenia.interia.pl/wielkopolskie/news-smierc-pieciolatka-w-poznaniu-tymczasowy-areszt-dla-71-letni,nId,7099104](https://wydarzenia.interia.pl/wielkopolskie/news-smierc-pieciolatka-w-poznaniu-tymczasowy-areszt-dla-71-letni,nId,7099104)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T08:31:02+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-smierc-pieciolatka-w-poznaniu-tymczasowy-areszt-dla-71-letni,nId,7099104"><img align="left" alt="Śmierć pięciolatka w Poznaniu. Tymczasowy areszt dla 71-letniego nożownika " src="https://i.iplsc.com/smierc-pieciolatka-w-poznaniu-tymczasowy-areszt-dla-71-letni/000HUB5YBBOJML1D-C321.jpg" /></a>Sąd rejonowy w Poznaniu podjął w piątek decyzję o tymczasowym aresztowaniu 71-letniego Zbysława C. - przekazał rzecznik Prokuratury Okręgowej w Poznaniu prokurator Łukasz Wawrzyniak. Mężczyzna śmiertelnie ugodził nożem 5-letniego chłopca. </p><br clear="all" />

## "Możliwe przerwy w dostawie prądu". Wydano alert RCB
 - [https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mozliwe-przerwy-w-dostawie-pradu-wydano-alert-rcb,nId,7099100](https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mozliwe-przerwy-w-dostawie-pradu-wydano-alert-rcb,nId,7099100)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T08:25:16+00:00

<p><a href="https://wydarzenia.interia.pl/wiadomosci-lokalne/news-mozliwe-przerwy-w-dostawie-pradu-wydano-alert-rcb,nId,7099100"><img align="left" alt="&quot;Możliwe przerwy w dostawie prądu&quot;. Wydano alert RCB" src="https://i.iplsc.com/mozliwe-przerwy-w-dostawie-pradu-wydano-alert-rcb/000HUAOZUKCYWOPI-C321.jpg" /></a>Silny wiatr zagraża wielu miejscom w kraju. Okazuje się, że istnieje niebezpieczeństwo, że gwałtowna pogoda może nawet doprowadzić do przerwania dostaw prądu. Wydano alert RCB dla trzech polskich województw. Z ostrzeżenia wynika, że najtrudniejsza sytuacja wystąpi w nocy z piątku na sobotę. Dowiedz się, gdzie sytuacja będzie najgorsza.</p><br clear="all" />

## Pierwsze wystąpienie Z. Ziobry po wyborach. Skierował wniosek do TK
 - [https://wydarzenia.interia.pl/kraj/news-ziobro-kieruje-wniosek-do-tk-chodzi-o-samochody-spalinowe,nId,7099048](https://wydarzenia.interia.pl/kraj/news-ziobro-kieruje-wniosek-do-tk-chodzi-o-samochody-spalinowe,nId,7099048)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T08:22:20+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-ziobro-kieruje-wniosek-do-tk-chodzi-o-samochody-spalinowe,nId,7099048"><img align="left" alt="Pierwsze wystąpienie Z. Ziobry po wyborach. Skierował wniosek do TK" src="https://i.iplsc.com/pierwsze-wystapienie-z-ziobry-po-wyborach-skierowal-wniosek/000HUB6F2ADXMBQQ-C321.jpg" /></a>Minister Sprawiedliwości Zbigniew Ziobro zapowiedział złożenie wniosku do Trybunału Konstytucyjnego w związku z decyzją Unii Europejskiej w sprawie samochodów spalinowych. - Razem z tworzącym się nowym rządem UE chce pozbawić Polaków wolności decydowania, jakimi samochodami mają jeździć - ocenił Zbigniew Ziobro. Plany UE nazwał &quot;ideologicznym szaleństwem&quot; oraz wskazał, że pomysły te cieszą się &quot;życzliwym wsparciem nowej koalicji rządzącej&quot;. To pierwsze publiczne wystąpienie ministra i szefa Suwerennej Polski po niedzielnych wyborach...</p><br clear="all" />

## Pandora Gate: Nowe dowody na Marcina Dubiela. Łzawa odpowiedź
 - [https://wydarzenia.interia.pl/kraj/news-pandora-gate-nowe-dowody-na-marcina-dubiela-lzawa-odpowiedz,nId,7099045](https://wydarzenia.interia.pl/kraj/news-pandora-gate-nowe-dowody-na-marcina-dubiela-lzawa-odpowiedz,nId,7099045)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T07:53:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pandora-gate-nowe-dowody-na-marcina-dubiela-lzawa-odpowiedz,nId,7099045"><img align="left" alt="Pandora Gate: Nowe dowody na Marcina Dubiela. Łzawa odpowiedź" src="https://i.iplsc.com/pandora-gate-nowe-dowody-na-marcina-dubiela-lzawa-odpowiedz/000HU9BF8AQSTSGY-C321.jpg" /></a>Ciąg dalszy afery Pandora Gate. Sylwester Wardęga opublikował nowy film poświęcony Marcinowi Dubielowi. Zarzuca w nim znanemu youtuberowi, że ten namawiał 14-latkę na spotkanie z dorosłym Stuu. Jako dowód pokazał fragmenty rozmów nastolatki z Dubielem. Jak dodał, materiał dowodowy ma też prokurator. Youtuber zdążył odpowiedzieć na pojawiające się zarzuty. W nagraniu zapewnił, że nigdy nie zrobił krzywdy dziecku, a cała afera najmocniej odbiła się na członkach jego rodziny.</p><br clear="all" />

## Stanie niemal cały kraj. Masowe strajki przewoźników we Włoszech
 - [https://wydarzenia.interia.pl/zagranica/news-stanie-niemal-caly-kraj-masowe-strajki-przewoznikow-we-wlosz,nId,7099012](https://wydarzenia.interia.pl/zagranica/news-stanie-niemal-caly-kraj-masowe-strajki-przewoznikow-we-wlosz,nId,7099012)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T07:43:28+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stanie-niemal-caly-kraj-masowe-strajki-przewoznikow-we-wlosz,nId,7099012"><img align="left" alt="Stanie niemal cały kraj. Masowe strajki przewoźników we Włoszech" src="https://i.iplsc.com/stanie-niemal-caly-kraj-masowe-strajki-przewoznikow-we-wlosz/000HU82K1T2RQG0N-C321.jpg" /></a>Włosi organizują ogólnokrajowy strajk. Na wiele godzin staną autobusy i pociągi, odwołano także dziesiątki lotów. Związkowcy domagają się &quot;ogólnego wzrostu płac na poziomie inflacji”. Akcja protestacyjna nie będzie obowiązywać podczas porannego oraz popołudniowego szczytu. </p><br clear="all" />

## Błyskawiczna reakcja na słowa Bidena. Zacharowa mówi o wielkim "oszustwie"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-blyskawiczna-reakcja-na-slowa-bidena-zacharowa-mowi-o-wielki,nId,7098974](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-blyskawiczna-reakcja-na-slowa-bidena-zacharowa-mowi-o-wielki,nId,7098974)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T07:34:39+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-blyskawiczna-reakcja-na-slowa-bidena-zacharowa-mowi-o-wielki,nId,7098974"><img align="left" alt="Błyskawiczna reakcja na słowa Bidena. Zacharowa mówi o wielkim &quot;oszustwie&quot;" src="https://i.iplsc.com/blyskawiczna-reakcja-na-slowa-bidena-zacharowa-mowi-o-wielki/000FVQUI47NPKR37-C321.jpg" /></a>Joe Biden wygłosił kilkunastominutowe orędzie poświęcone Ukrainie i Izraelowi. W trakcie wystąpienia wskazywał, że pomoc Ukrainie jest &quot;mądrą inwestycją&quot;, która stanowi rodzaj dywidendy. Na słowa amerykańskiego przywódcy natychmiast zareagowała rzeczniczka rosyjskiego MSZ Marija Zacharowa. Określiła politykę USA czystą &quot;kalkulacją&quot;. &quot;Po prostu oszukali świat, ukrywając się za wartościami, które dla Waszyngtonu nie istnieją&quot; - napisała w mediach społecznościowych. </p><br clear="all" />

## "Każdy chce mieć swoją policję". Szef związkowców ma plan
 - [https://wydarzenia.interia.pl/kraj/news-kazdy-chce-miec-swoja-policje-szef-zwiazkowcow-ma-plan,nId,7097219](https://wydarzenia.interia.pl/kraj/news-kazdy-chce-miec-swoja-policje-szef-zwiazkowcow-ma-plan,nId,7097219)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T07:33:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kazdy-chce-miec-swoja-policje-szef-zwiazkowcow-ma-plan,nId,7097219"><img align="left" alt="&quot;Każdy chce mieć swoją policję&quot;. Szef związkowców ma plan" src="https://i.iplsc.com/kazdy-chce-miec-swoja-policje-szef-zwiazkowcow-ma-plan/000HU9B20DVAT9VM-C321.jpg" /></a>- Apolityczność policji poprzez wprowadzenie kadencyjności komendanta głównego na wzór rzecznika praw obywatelskich i niezależny od MSWiA budżet. To dwie rzeczy, które mogłyby zadziać się w formacji w najbliższym czasie, skończyłaby się ta gra policją, to podważanie zaufania do instytucji państwa odpowiedzialnej za nasze bezpieczeństwo - mówi w rozmowie z Interią Rafał Jankowski, szef policyjnych związkowców. I zapowiada, że w najbliższym czasie zwróci się w tej sprawie z petycją do polityków. - Trzeba powiedzieć: sprawdzam i zobaczyć, ile...</p><br clear="all" />

## Opozycyjny spór o aborcję. Trzaskowski: Mówiłem, by głosować na KO
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycyjny-spor-o-aborcje-trzaskowski-mowilem-by-glosowac-na,nId,7098957](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycyjny-spor-o-aborcje-trzaskowski-mowilem-by-glosowac-na,nId,7098957)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T07:05:23+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycyjny-spor-o-aborcje-trzaskowski-mowilem-by-glosowac-na,nId,7098957"><img align="left" alt="Opozycyjny spór o aborcję. Trzaskowski: Mówiłem, by głosować na KO" src="https://i.iplsc.com/opozycyjny-spor-o-aborcje-trzaskowski-mowilem-by-glosowac-na/000HU9A7N2BE4A75-C321.jpg" /></a>- Za każdym razem mówiłem, żeby głosować na Koalicję Obywatelską - podkreślił Rafał Trzaskowski pytany o rozmowy koalicyjne w kontekście aborcyjnego sporu pomiędzy PSL a KO i Lewicą. - To, że Władysław Kosiniak-Kamysz i Szymon Hołownia mówili, że będą decydować poszczególni posłowie, też wiemy - oceniał prezydent Warszawy, wskazując, że jego formacja z propozycją uchwały nowego prawa aborcyjnego &quot;szła na sztandarach&quot;.</p><br clear="all" />

## Poseł Koalicji Obywatelskiej alarmuje: Sceny jak z filmu "Psy"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-posel-koalicji-obywatelskiej-alarmuje-sceny-jak-z-filmu-psy,nId,7099002](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-posel-koalicji-obywatelskiej-alarmuje-sceny-jak-z-filmu-psy,nId,7099002)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T06:45:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-posel-koalicji-obywatelskiej-alarmuje-sceny-jak-z-filmu-psy,nId,7099002"><img align="left" alt="Poseł Koalicji Obywatelskiej alarmuje: Sceny jak z filmu &quot;Psy&quot;" src="https://i.iplsc.com/posel-koalicji-obywatelskiej-alarmuje-sceny-jak-z-filmu-psy/000HU859VEACT3YN-C321.jpg" /></a>Michał Szczerba zamieścił w mediach społecznościowych wpis, w którym podzielił się zdobytymi informacjami. &quot;Dostaję sygnały o wywożonych w nocy setkach worków ze zmielonymi dokumentami, naprędce szukanych specjalistach od uszkadzania twardych dysków i pierwszych zatopionych laptopach&quot; - napisał poseł KO. Kilka dni wcześniej Szczerba donosił, że przed wyborami m.in. ABW miało rozpisać przetarg na zakup niszczarek. </p><br clear="all" />

## Nie mają praw wyborczych, ale "zagłosowali". "Oczekują szybkich zmian"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaglosowali-choc-nie-maja-praw-wyborczych-kto-wygral,nId,7097158](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaglosowali-choc-nie-maja-praw-wyborczych-kto-wygral,nId,7097158)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T06:30:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zaglosowali-choc-nie-maja-praw-wyborczych-kto-wygral,nId,7097158"><img align="left" alt="Nie mają praw wyborczych, ale &quot;zagłosowali&quot;. &quot;Oczekują szybkich zmian&quot;" src="https://i.iplsc.com/nie-maja-praw-wyborczych-ale-zaglosowali-oczekuja-szybkich-z/000HU2OHM6W4UYAK-C321.jpg" /></a>Część z nich nie ma jeszcze czynnych praw wyborczych. Mogli jednak zagłosować w… symulacji wyborów. Blisko 100 tys. uczniów i uczennic z niemal 600 szkół wzięło udział w akcji &quot;Młodzi głosują&quot;. Wiemy, przy którym komitecie wyborczym najchętniej stawiali krzyżyk.</p><br clear="all" />

## Archeolodzy odkryli prehistoryczną biżuterię. Leżała wśród marchwi
 - [https://wydarzenia.interia.pl/zagranica/news-archeolodzy-odkryli-prehistoryczna-bizuterie-lezala-wsrod-ma,nId,7098975](https://wydarzenia.interia.pl/zagranica/news-archeolodzy-odkryli-prehistoryczna-bizuterie-lezala-wsrod-ma,nId,7098975)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T06:29:55+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-archeolodzy-odkryli-prehistoryczna-bizuterie-lezala-wsrod-ma,nId,7098975"><img align="left" alt="Archeolodzy odkryli prehistoryczną biżuterię. Leżała wśród marchwi" src="https://i.iplsc.com/archeolodzy-odkryli-prehistoryczna-bizuterie-lezala-wsrod-ma/000HU7DBSW9GMPQI-C321.jpg" /></a>Podczas wykopalisk w Getyndze na terenie szwajcarskiego kantonu Turgowia archeolodzy odkryli biżuterię z epoki brązu. W ziemi zakopane był także inne &quot;skarby&quot; - m.in. skamieniały ząb rekina. Prehistoryczne artefakty zostały znalezione na polu marchwi. </p><br clear="all" />

## Kradli w Niemczech, sprzedawali w Polsce. Gang złodziei rozbity
 - [https://wydarzenia.interia.pl/kraj/news-kradli-w-niemczech-sprzedawali-w-polsce-gang-zlodziei-rozbit,nId,7098973](https://wydarzenia.interia.pl/kraj/news-kradli-w-niemczech-sprzedawali-w-polsce-gang-zlodziei-rozbit,nId,7098973)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T06:00:31+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-kradli-w-niemczech-sprzedawali-w-polsce-gang-zlodziei-rozbit,nId,7098973"><img align="left" alt="Kradli w Niemczech, sprzedawali w Polsce. Gang złodziei rozbity " src="https://i.iplsc.com/kradli-w-niemczech-sprzedawali-w-polsce-gang-zlodziei-rozbit/000HU7FMJR91BLY3-C321.jpg" /></a>Polskie służby we współpracy z niemieckimi mundurowymi rozbiły gang złodziei samochodów. Zatrzymano dziewięciu podejrzanych, wszyscy trafili do aresztu. Sprawcy stoją za kradzieżą ponad stu luksusowych samochodów i motocykli na terenie Niemiec. Następnie pojazdy były przerzucane do Polski i sprzedawane.</p><br clear="all" />

## "The Economist": Ludzkość o krok od wynalezienia "eliksiru długowieczności"
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ludzkosc-o-krok-od-wynalezienia-eliksiru-dlugo,nId,7078980](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ludzkosc-o-krok-od-wynalezienia-eliksiru-dlugo,nId,7078980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T05:56:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ludzkosc-o-krok-od-wynalezienia-eliksiru-dlugo,nId,7078980"><img align="left" alt="&quot;The Economist&quot;: Ludzkość o krok od wynalezienia &quot;eliksiru długowieczności&quot;" src="https://i.iplsc.com/the-economist-ludzkosc-o-krok-od-wynalezienia-eliksiru-dlugo/000HS8Y7UQ6LJVTI-C321.jpg" /></a>Przez wieki próby powstrzymania starzenia były domeną szarlatanów, często z katastrofalnym skutkiem dla ludzi. Tymczasem już wkrótce osiągnięcie 100. urodzin może stać się normą. Istnieje jednak wiele zagrożeń z tym związanych, włącznie z zawłaszczeniem &quot;eliksiru&quot; długowieczności przez bogatych kosztem biednych.</p><br clear="all" />

## "The Guardian": Przyszłość należy do nich. Będą znaczyć więcej niż Chiny czy Indie
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-guardian-przyszlosc-nalezy-do-nich-beda-znaczyc-wiecej-n,nId,7093186](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-guardian-przyszlosc-nalezy-do-nich-beda-znaczyc-wiecej-n,nId,7093186)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T05:54:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-guardian-przyszlosc-nalezy-do-nich-beda-znaczyc-wiecej-n,nId,7093186"><img align="left" alt="&quot;The Guardian&quot;: Przyszłość należy do nich. Będą znaczyć więcej niż Chiny czy Indie" src="https://i.iplsc.com/the-guardian-przyszlosc-nalezy-do-nich-beda-znaczyc-wiecej-n/000HTZKIQESTRFQI-C321.jpg" /></a>Afryka zostanie gospodarczym zwycięzcą najbliższych dekad? Wiele na to wskazuje. Ma fantastyczną demografię z punktu widzenia rynku pracy i ogromne zasoby m.in. 80 proc. światowej platyny. Do tego rosnąca klasa średnia i najniższy na świecie wskaźnik niewypłacalności. Akinwumi Adesina, szef Afrykańskiego Banku Rozwoju przekonuje, że rola Afryki będzie wyłącznie rosła.</p><br clear="all" />

## "The Washington Post": Spektakularne znalezisko w Kanadzie. "Wybryk natury"
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-spektakularne-znalezisko-w-kanadzie-wybr,nId,7080645](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-spektakularne-znalezisko-w-kanadzie-wybr,nId,7080645)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T05:52:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-spektakularne-znalezisko-w-kanadzie-wybr,nId,7080645"><img align="left" alt="&quot;The Washington Post&quot;: Spektakularne znalezisko w Kanadzie. &quot;Wybryk natury&quot;" src="https://i.iplsc.com/the-washington-post-spektakularne-znalezisko-w-kanadzie-wybr/000HS5WK8K7C17UQ-C321.jpg" /></a>46 metrów wysokości i 5,3 metra średnicy. 39-letni TJ Watt nie mógł uwierzyć własnemu szczęściu, gdy przed oczami wyrósł mu 1000-letni cedr kanadyjski. -  Znalazłem tysiące drzew i zrobiłem setki tysięcy zdjęć w lasach. Ale nigdy nie widziałem tak imponującego drzewa jak to - komentuje oszołomiony.</p><br clear="all" />

## Wybory wystrzeliły Polskę do europejskiej elity. Utrzymać się w niej nie będzie łatwo
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-wystrzelily-polske-do-europejskiej-elity-utrzymac-sie,nId,7097111](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-wystrzelily-polske-do-europejskiej-elity-utrzymac-sie,nId,7097111)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T05:45:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-wystrzelily-polske-do-europejskiej-elity-utrzymac-sie,nId,7097111"><img align="left" alt="Wybory wystrzeliły Polskę do europejskiej elity. Utrzymać się w niej nie będzie łatwo" src="https://i.iplsc.com/wybory-wystrzelily-polske-do-europejskiej-elity-utrzymac-sie/000HU2CT8TFN180E-C321.jpg" /></a>Największym bohaterem zakończonych wyborów nie był żaden z politycznych obozów, ale rekordowa frekwencja wyborcza. To ona - wraz z polaryzacją i mobilizacją - rozdała karty partiom. Czy Polska już na trwałe weszła do grona dojrzałych, zachodnich demokracji, w których miażdżąca większość społeczeństwa bierze udział w wyborach? Nie do końca. Sytuacja, z którą mieliśmy do czynienia, jest wypadkową kilku ważnych czynników. Ich równoczesne wystąpienie będzie ciężkie do powtórzenia w przyszłości.</p><br clear="all" />

## Powyborcza dymisja w KRRiT. "Powody odejścia zachowam dla siebie"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-powyborcza-dymisja-w-krrit-powody-odejscia-zachowam-dla-sieb,nId,7098960](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-powyborcza-dymisja-w-krrit-powody-odejscia-zachowam-dla-sieb,nId,7098960)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T05:13:35+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-powyborcza-dymisja-w-krrit-powody-odejscia-zachowam-dla-sieb,nId,7098960"><img align="left" alt="Powyborcza dymisja w KRRiT. &quot;Powody odejścia zachowam dla siebie&quot;" src="https://i.iplsc.com/powyborcza-dymisja-w-krrit-powody-odejscia-zachowam-dla-sieb/000HU7CYXY2BHI54-C321.jpg" /></a>Dyrektor departamentu prawnego w Krajowej Radzie Radiofonii i Telewizji kończy pracę - przekazał portal Press. - Powody mojego odejścia wolałabym zachować dla siebie - skomentowała Kinga Szyguła, która kierowała komórką od ponad 11 lat.</p><br clear="all" />

## Ursula von der Leyen nie gryzła się w język. "Rosja i Hamas są podobni"
 - [https://wydarzenia.interia.pl/zagranica/news-ursula-von-der-leyen-nie-gryzla-sie-w-jezyk-rosja-i-hamas-sa,nId,7098949](https://wydarzenia.interia.pl/zagranica/news-ursula-von-der-leyen-nie-gryzla-sie-w-jezyk-rosja-i-hamas-sa,nId,7098949)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T04:38:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ursula-von-der-leyen-nie-gryzla-sie-w-jezyk-rosja-i-hamas-sa,nId,7098949"><img align="left" alt="Ursula von der Leyen nie gryzła się w język. &quot;Rosja i Hamas są podobni&quot;" src="https://i.iplsc.com/ursula-von-der-leyen-nie-gryzla-sie-w-jezyk-rosja-i-hamas-sa/000HU7AG1G8TEICA-C321.jpg" /></a>Przewodnicząca KE Ursula von der Leyen rozpoczęła swoją wizytę w Waszyngtonie. - Rosja i Hamas są do siebie podobni - powiedziała, komentując bieżące wydarzenia. Wskazała, że konflikt na Bliskim Wschodzie może się rozprzestrzenić z powodu &quot;gniewu arabskich ulic&quot;. Zaapelowała o nałożenie sankcji na Iran, który wspiera Rosjan i palestyńską organizację terrorystyczną. </p><br clear="all" />

## Nowe prawo w USA. "Aresztowania za bezdomność"
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-prawo-w-usa-aresztowania-za-bezdomnosc,nId,7097625](https://wydarzenia.interia.pl/zagranica/news-nowe-prawo-w-usa-aresztowania-za-bezdomnosc,nId,7097625)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T04:34:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-prawo-w-usa-aresztowania-za-bezdomnosc,nId,7097625"><img align="left" alt="Nowe prawo w USA. &quot;Aresztowania za bezdomność&quot;" src="https://i.iplsc.com/nowe-prawo-w-usa-aresztowania-za-bezdomnosc/000HU6K26448SCDS-C321.jpg" /></a>W Miami Beach na Florydzie będzie można aresztować bezdomnych, którzy śpią na ulicach i nie godzą się na umieszczenie w schroniskach - wynika z prawa uchwalonego w środę. Zdania w sprawie nowego rozwiązania są podzielone. Zwolennicy przekonują, że w ten sposób uda im się rozwiązać problem bezdomności, co nie przekonuje przeciwników. - To rozporządzenie jest okrutne, rasistowskie i szkodliwe. Zachęcam do poszukiwania bardziej postępowych, humanitarnych i sprawdzonych rozwiązań - apelowała lokalna aktywistka Kat Duesterhaus. </p><br clear="all" />

## "Dziwne" SMS-y u Polaków. Wiadomo, o co chodzi
 - [https://wydarzenia.interia.pl/kraj/news-dziwne-sms-y-u-polakow-wiadomo-o-co-chodzi,nId,7097595](https://wydarzenia.interia.pl/kraj/news-dziwne-sms-y-u-polakow-wiadomo-o-co-chodzi,nId,7097595)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T04:18:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-dziwne-sms-y-u-polakow-wiadomo-o-co-chodzi,nId,7097595"><img align="left" alt="&quot;Dziwne&quot; SMS-y u Polaków. Wiadomo, o co chodzi" src="https://i.iplsc.com/dziwne-sms-y-u-polakow-wiadomo-o-co-chodzi/000HU68V38VTFN17-C321.jpg" /></a>Fałszywa wiadomość i atak hakerski czy może ruch resortu cyfryzacji? To pytanie zadało sobie zapewne wielu Polaków, którzy otrzymali w czwartek sms o wygasającej ważności profilu zaufanego z linkiem. O co chodzi i czy faktycznie jest się czego obawiać? Sprawdziliśmy.</p><br clear="all" />

## Joe Biden przestrzega przed Rosją. "Putin już zagroził Polsce"
 - [https://wydarzenia.interia.pl/zagranica/news-joe-biden-przestrzega-przed-rosja-putin-juz-zagrozil-polsce,nId,7098947](https://wydarzenia.interia.pl/zagranica/news-joe-biden-przestrzega-przed-rosja-putin-juz-zagrozil-polsce,nId,7098947)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-20T03:58:39+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-joe-biden-przestrzega-przed-rosja-putin-juz-zagrozil-polsce,nId,7098947"><img align="left" alt="Joe Biden przestrzega przed Rosją. &quot;Putin już zagroził Polsce&quot;" src="https://i.iplsc.com/joe-biden-przestrzega-przed-rosja-putin-juz-zagrozil-polsce/000HU78WGYGGW9JV-C321.jpg" /></a>- Władimir Putin już zagroził Polsce, że jej zachodnie ziemie są &quot;darem&quot; od Rosji - mówił w specjalnym orędziu prezydent USA, wskazując, że rosyjskiego dyktatora trzeba powstrzymać, bo w przeciwnym razie nie zatrzyma się na Ukrainie. W przemówieniu podkreślał również, jak kluczowa jest pomoc zarówno Ukrainie, jak i Izraelowi, podkreślając, że takim &quot;terrorystom jak Hamas i tyranom jak Putin nie pozwoli wygrać&quot;. Zapowiedział, że w piątek zwróci się do Kongresu o znaczący pakiet środków dla obu państw.</p><br clear="all" />

