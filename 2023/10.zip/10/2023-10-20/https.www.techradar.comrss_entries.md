# Source:Techradar, URL:https://www.techradar.com/rss, language:en-US

## Facebook is trialing robots that can autonomously move massive computer racks —  let’s just hope they don’t forget to unplug before they move
 - [https://www.techradar.com/pro/facebook-is-trialing-robots-that-can-autonomously-move-massive-computer-racks-lets-just-hope-they-dont-forget-to-unplug-racks-before-they-move](https://www.techradar.com/pro/facebook-is-trialing-robots-that-can-autonomously-move-massive-computer-racks-lets-just-hope-they-dont-forget-to-unplug-racks-before-they-move)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T21:54:45+00:00

Automating the movement of IT equipment can lead to efficiency gains and free up staff to do something better with their time.

## Google Search can help people learn English with new language tutor tool
 - [https://www.techradar.com/computing/software/google-search-can-help-people-learn-english-with-new-language-tutor-tool](https://www.techradar.com/computing/software/google-search-can-help-people-learn-english-with-new-language-tutor-tool)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T19:55:02+00:00

Google's English tutor will engage with students via interactive lessons and provide personal feedback to help them learn.

## Report: Scammers are targeting over-heating iPhone 15 issue with fake recall scam
 - [https://www.techradar.com/phones/iphone/report-scammers-are-targeting-over-heating-iphone-15-issue-with-fake-recall-scam](https://www.techradar.com/phones/iphone/report-scammers-are-targeting-over-heating-iphone-15-issue-with-fake-recall-scam)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T18:05:08+00:00

New reports indicate that scammers have seized on Apple's misfortune and are telling people to send them overheating iPhone 15 devices

## Beware - this fake KeePass download site is just spreading malware
 - [https://www.techradar.com/pro/security/fake-keepass-download-site-used-to-spread-malware](https://www.techradar.com/pro/security/fake-keepass-download-site-used-to-spread-malware)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T17:36:22+00:00

Scam site even has a legitimate-looking Google Ads campaign included.

## Sony has made a $2 million donation towards humanitarian aid for Israel-Gaza conflict
 - [https://www.techradar.com/gaming/consoles-pc/sony-has-made-a-dollar2-million-donation-towards-humanitarian-aid-for-israel-gaza-conflict](https://www.techradar.com/gaming/consoles-pc/sony-has-made-a-dollar2-million-donation-towards-humanitarian-aid-for-israel-gaza-conflict)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T16:31:47+00:00

Sony and Devolver Digital have each made respective donations towards humanitarian aid charities amid the ongoing Israel-Gaza conflict.

## Casio data breach hits users in 149 countries
 - [https://www.techradar.com/pro/security/casio-data-breach-hits-users-in-149-countries](https://www.techradar.com/pro/security/casio-data-breach-hits-users-in-149-countries)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T15:33:31+00:00

Hackers stole data from a development environment, but the corresponding app remains operational.

## This week's best early Black Friday deals - the 14 deals worth buying now
 - [https://www.techradar.com/seasonal-sales/this-weeks-best-early-black-friday-deals-the-14-deals-worth-buying-now](https://www.techradar.com/seasonal-sales/this-weeks-best-early-black-friday-deals-the-14-deals-worth-buying-now)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T15:21:59+00:00

New early Black Friday deals are launching all the time so I've picked out the best ones worth buying this week.

## FBI warns of North Korean hackers using VPNs to infiltrate businesses
 - [https://www.techradar.com/computing/cyber-security/fbi-warns-of-north-korean-hackers-using-vpns-to-infiltrate-businesses](https://www.techradar.com/computing/cyber-security/fbi-warns-of-north-korean-hackers-using-vpns-to-infiltrate-businesses)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T15:16:07+00:00

Requiring freelancers to shut off their VPNs is one US and South Korean guideline to avoid hiring North Korean agents. Here's what's happening right now.

## Wargaming is offering special game bundles to raise money for Ukraine
 - [https://www.techradar.com/gaming/consoles-pc/wargaming-is-offering-special-game-bundles-to-raise-money-for-ukraine](https://www.techradar.com/gaming/consoles-pc/wargaming-is-offering-special-game-bundles-to-raise-money-for-ukraine)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T14:59:03+00:00

Developer Wargaming has launched a brand new charity initiative called WargamingUnited with the aim to raise money for Ukraine.

## Microsoft delays one of Windows 11's most promising new features due to bugs
 - [https://www.techradar.com/computing/windows/microsoft-delays-one-of-windows-11s-most-promising-new-features-due-to-bugs](https://www.techradar.com/computing/windows/microsoft-delays-one-of-windows-11s-most-promising-new-features-due-to-bugs)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T14:32:43+00:00

In its latest update, Windows 11 temporarily halts the casting feature upgrade, focusing on enhancing system navigation and user experience.

## 7 new movies and TV shows to stream on Netflix, Prime Video, Max, and more this weekend (October 20)
 - [https://www.techradar.com/streaming/7-new-movies-and-tv-shows-to-stream-on-netflix-prime-video-max-and-more-this-weekend-october-20-2023](https://www.techradar.com/streaming/7-new-movies-and-tv-shows-to-stream-on-netflix-prime-video-max-and-more-this-weekend-october-20-2023)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T14:00:00+00:00

From new Netflix thrillers to acclaimed novel adaptations, there’s plenty to watch this weekend.

## Baz Luhrmann’s wartime-epic show on Hulu and Disney Plus could give his least popular film a new lease of life
 - [https://www.techradar.com/streaming/baz-luhrmanns-wartime-epic-show-on-hulu-and-disney-plus-could-give-his-least-popular-film-a-new-lease-of-life](https://www.techradar.com/streaming/baz-luhrmanns-wartime-epic-show-on-hulu-and-disney-plus-could-give-his-least-popular-film-a-new-lease-of-life)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T13:49:16+00:00

The new trailer gives a hint of what's to come from this expansion of Luhrmann's Australia, starring Nicole Kidman and Hugh Jackman.

## RagnarLocker dark web sites seized in major crackdown
 - [https://www.techradar.com/pro/security/ragnarlocker-dark-web-sites-seized-in-major-crackdown](https://www.techradar.com/pro/security/ragnarlocker-dark-web-sites-seized-in-major-crackdown)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T13:22:14+00:00

The FBI, Europol, and other agencies teamed up to take down RagnarLocker website.

## ChromeOS 118 brings nifty improvements to Chromebooks for password recovery, touchscreens, and printers
 - [https://www.techradar.com/computing/chromebooks/chromeos-118-brings-nifty-improvements-to-chromebooks-for-password-recovery-touchscreens-and-printers](https://www.techradar.com/computing/chromebooks/chromeos-118-brings-nifty-improvements-to-chromebooks-for-password-recovery-touchscreens-and-printers)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T13:06:53+00:00

Forget your Chromebook password? File loss disasters are a thing of the past with ChromeOS 118.

## Fallout makes its Magic: The Gathering debut in March 2024
 - [https://www.techradar.com/gaming/consoles-pc/fallout-makes-its-magic-the-gathering-debut-in-march-2024](https://www.techradar.com/gaming/consoles-pc/fallout-makes-its-magic-the-gathering-debut-in-march-2024)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T12:41:35+00:00

Magic: The Gathering's Fallout crossover has an official release date.

## Google Meet wants to make you look even better for those big calls
 - [https://www.techradar.com/pro/google-meet-wants-to-make-you-look-even-better-for-those-big-calls](https://www.techradar.com/pro/google-meet-wants-to-make-you-look-even-better-for-those-big-calls)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T12:24:39+00:00

New filter coming to Google Meet irons out those wrinkles and touches up those blemishes, but only on mobile (for now).

## Vampire Survivors’ latest update adds 6 new achievements, a bonus stage and more
 - [https://www.techradar.com/gaming/consoles-pc/vampire-survivors-latest-update-adds-6-new-achievements-a-bonus-stage-and-more](https://www.techradar.com/gaming/consoles-pc/vampire-survivors-latest-update-adds-6-new-achievements-a-bonus-stage-and-more)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T12:17:52+00:00

Vampire Survivors' snow-themed Whiteout update adds a bunch of new free content.

## Amazon's Prime Air delivery drones are finally taking off – here's what they look like
 - [https://www.techradar.com/cameras/drones/amazons-prime-air-delivery-drones-are-finally-taking-off-heres-what-they-look-like](https://www.techradar.com/cameras/drones/amazons-prime-air-delivery-drones-are-finally-taking-off-heres-what-they-look-like)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:47:06+00:00

Amazon announces it is to expand its Prime Air deliveries to the UK, Italy and more cities in the US.

## Apex Legends offers another nod to Titanfall with new character Conduit
 - [https://www.techradar.com/gaming/consoles-pc/apex-legends-offers-another-nod-to-titanfall-with-new-character-conduit](https://www.techradar.com/gaming/consoles-pc/apex-legends-offers-another-nod-to-titanfall-with-new-character-conduit)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:25:44+00:00

Respawn Entertainment has revealed the next playable character to join Apex Legends ahead of the release of Season 19.

## Is this the end of wires? Apple, Meta and Google win access to super-fast 6GHz Wi-Fi
 - [https://www.techradar.com/computing/wi-fi-broadband/is-this-the-end-of-wires-apple-meta-and-google-win-access-to-super-fast-6ghz-wi-fi](https://www.techradar.com/computing/wi-fi-broadband/is-this-the-end-of-wires-apple-meta-and-google-win-access-to-super-fast-6ghz-wi-fi)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:21:47+00:00

Apple, Meta and Google get more access to next-gen 6GHz Wi-Fi – and it could be a game-changer for Vision Pro and other VR and AR headsets.

## Attention YouTube addicts: Microsoft could add a seriously handy feature to Edge
 - [https://www.techradar.com/computing/edge/attention-youtube-addicts-microsoft-could-add-a-seriously-handy-feature-to-edge](https://www.techradar.com/computing/edge/attention-youtube-addicts-microsoft-could-add-a-seriously-handy-feature-to-edge)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:19:42+00:00

Microsoft is pushing ahead with developing the translation powers of Edge on several fronts.

## Windows 11's  Microsoft Store gets slightly less annoying - but I still won’t use it
 - [https://www.techradar.com/computing/windows/windows-11s-microsoft-store-gets-slightly-less-annoying-but-i-still-wont-use-it](https://www.techradar.com/computing/windows/windows-11s-microsoft-store-gets-slightly-less-annoying-but-i-still-wont-use-it)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:19:00+00:00

The Microsoft Store now runs slightly faster - great news for the 3 people that use it.

## iOS 18 tipped to debut Apple’s new generative AI – and that’s good news for Siri
 - [https://www.techradar.com/computing/artificial-intelligence/ios-18-tipped-to-debut-apples-new-generative-ai-and-thats-good-news-for-siri](https://www.techradar.com/computing/artificial-intelligence/ios-18-tipped-to-debut-apples-new-generative-ai-and-thats-good-news-for-siri)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:13:34+00:00

A new report suggests Apple could give Siri get a generative AI boost in iOS 18.

## Was the iPhone 15 worth the hype? Apple fans give their verdict
 - [https://www.techradar.com/phones/iphone/was-the-iphone-15-worth-the-hype-apple-fans-give-their-verdict](https://www.techradar.com/phones/iphone/was-the-iphone-15-worth-the-hype-apple-fans-give-their-verdict)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:11:37+00:00

Apple fans have weighed in on the success of the iPhone 15 line.

## Apple tipped to be working on a giant 12.9-inch iPad Air
 - [https://www.techradar.com/tablets/ipad-air/apple-tipped-to-be-working-on-a-giant-129-inch-ipad-air](https://www.techradar.com/tablets/ipad-air/apple-tipped-to-be-working-on-a-giant-129-inch-ipad-air)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:08:15+00:00

A re claims Apple is looking at making a 12.9-inch iPad Air, potentially as an affordable alternative to the high-end iPad Pro.

## Microsoft and Amazon team up to fight Indian fake tech support scams
 - [https://www.techradar.com/pro/microsoft-and-amazon-team-up-to-fight-indian-fake-tech-support-scams](https://www.techradar.com/pro/microsoft-and-amazon-team-up-to-fight-indian-fake-tech-support-scams)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:07:33+00:00

A number of raids and arrests have been made through intelligence provided by Microsoft and Amazon.

## Marvel’s Spider-Man 2 day-one patch irons out a progression-blocking bug and improves performance
 - [https://www.techradar.com/gaming/playstation/marvels-spider-man-2-day-one-patch-irons-out-a-progression-blocking-bug-and-improves-performance](https://www.techradar.com/gaming/playstation/marvels-spider-man-2-day-one-patch-irons-out-a-progression-blocking-bug-and-improves-performance)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T11:02:01+00:00

Marvel's Spider-Man 2 version 1.001.002 is available to download now, and includes notable improvements and fixes.

## Lots of developers are planning to embrace AI to help boost their coding skills
 - [https://www.techradar.com/pro/lots-of-developers-are-planning-to-embrace-ai-to-help-boost-their-coding-skills](https://www.techradar.com/pro/lots-of-developers-are-planning-to-embrace-ai-to-help-boost-their-coding-skills)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T10:37:24+00:00

Developers love to use AI, but many are increasingly concerned about their job security.

## More cybersecurity firms could collapse soon, experts warn
 - [https://www.techradar.com/pro/security/more-cybersecurity-firms-could-collapse-soon-experts-warn](https://www.techradar.com/pro/security/more-cybersecurity-firms-could-collapse-soon-experts-warn)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T10:20:01+00:00

Cybersecurity leaders think that other firms may go the way of IronNet if they don't get their priorities right.

## Apple TV Plus’ may have lost Jon Stewart’s show over episodes about China and AI – and it's not the first clash between Apple TV and Apple corporate
 - [https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-may-have-lost-jon-stewarts-show-over-episodes-about-china-and-ai-and-its-not-the-first-clash-between-apple-tv-and-apple-corporate](https://www.techradar.com/streaming/apple-tv-plus/apple-tv-plus-may-have-lost-jon-stewarts-show-over-episodes-about-china-and-ai-and-its-not-the-first-clash-between-apple-tv-and-apple-corporate)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T10:04:21+00:00

Apple HQ appears to have a problem with The Problem With Jon Stewart – and right now, it may take the show off the air completely

## I will be there day one for these translucent Nitro Deck models
 - [https://www.techradar.com/gaming/i-will-be-there-day-one-for-these-translucent-nitro-deck-models](https://www.techradar.com/gaming/i-will-be-there-day-one-for-these-translucent-nitro-deck-models)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:43:00+00:00

CRKD has announced the Nitro Deck Limited Edition Crystal Collection, bringing back one of the 90s' coolest aesthetics.

## A Venom spinoff after Marvel's Spider-Man 2 is possible if 'that's what fans really want'
 - [https://www.techradar.com/gaming/playstation/a-venom-spinoff-after-marvels-spider-man-2-is-possible-if-thats-what-fans-really-want](https://www.techradar.com/gaming/playstation/a-venom-spinoff-after-marvels-spider-man-2-is-possible-if-thats-what-fans-really-want)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:38:30+00:00

Spider-Man 2 director says Vemon standalone is possible 'there's such a rich universe'.

## EA Motive offers a new update on its Iron Man game but it's still a long way off
 - [https://www.techradar.com/gaming/consoles-pc/ea-motive-offers-a-new-update-on-its-iron-man-game-but-its-still-a-long-way-off](https://www.techradar.com/gaming/consoles-pc/ea-motive-offers-a-new-update-on-its-iron-man-game-but-its-still-a-long-way-off)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:35:31+00:00

EA Motive has provided a brand new update on its Iron Man.

## Elden Ring’s official streetwear range costs up to $1,700, if you really want to look like Elden Lord
 - [https://www.techradar.com/gaming/elden-rings-official-streetwear-range-costs-up-to-dollar1700-if-you-really-want-to-look-like-elden-lord](https://www.techradar.com/gaming/elden-rings-official-streetwear-range-costs-up-to-dollar1700-if-you-really-want-to-look-like-elden-lord)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:35:10+00:00

Elden Ring's new collaboration with luxury streetwear brand ARK/8 includes several fancy (but very expensive) pieces of clothing.

## Marvel's Spider-Man 2 recorded the sounds of New York in a charmingly old-school way
 - [https://www.techradar.com/gaming/consoles-pc/marvels-spider-man-2-recorded-the-sounds-of-new-york-in-a-charmingly-old-school-way](https://www.techradar.com/gaming/consoles-pc/marvels-spider-man-2-recorded-the-sounds-of-new-york-in-a-charmingly-old-school-way)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:34:14+00:00

Marvel's Spider-Man 2's audio director spilled the beans on how they got the game's virtual New York City to sound so authentic.

## The Samsung Galaxy Z Fold 6 might not have a new camera, and that would be a big mistake
 - [https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-z-fold-6-might-not-have-a-new-camera-and-that-would-be-a-big-mistake](https://www.techradar.com/phones/samsung-galaxy-phones/the-samsung-galaxy-z-fold-6-might-not-have-a-new-camera-and-that-would-be-a-big-mistake)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:30:55+00:00

Samsung reportedly won't upgrade any of the cameras for the Galaxy Z Fold 6.

## Many SMBs wouldn't trust employees with confidential information
 - [https://www.techradar.com/pro/security/many-smbs-wouldnt-trust-employees-with-confidential-information](https://www.techradar.com/pro/security/many-smbs-wouldnt-trust-employees-with-confidential-information)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T09:02:36+00:00

Some business leaders don’t trust workers with confidential data, but many were also found to be lacking in key policies.

## Lord of the Rings: Return to Moria has gone gold, but the PS5 launch has been delayed until December
 - [https://www.techradar.com/gaming/lord-of-the-rings-return-to-moria-has-gone-gold-but-the-ps5-launch-has-been-delayed-until-december](https://www.techradar.com/gaming/lord-of-the-rings-return-to-moria-has-gone-gold-but-the-ps5-launch-has-been-delayed-until-december)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T08:59:39+00:00

Lord of the Rings: Return to Moria has gone gold in advance of its launch on PC in a few days, but the PS5 release has been delayed.

## Diablo 4 gets a 10-hour trial on Xbox this weekend
 - [https://www.techradar.com/gaming/consoles-pc/diablo-4-gets-a-10-hour-trial-on-xbox-this-weekend](https://www.techradar.com/gaming/consoles-pc/diablo-4-gets-a-10-hour-trial-on-xbox-this-weekend)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T08:57:05+00:00

You can play Diablo 4 for ten hours on Xbox consoles this weekend, if you don't own the game yet.

## Young people are increasingly worried about privacy in the AI age
 - [https://www.techradar.com/pro/young-people-are-increasingly-worried-about-privacy-in-the-ai-age](https://www.techradar.com/pro/young-people-are-increasingly-worried-about-privacy-in-the-ai-age)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T08:50:33+00:00

Consumers are increasingly concerned about, and willing to act upon, data privacy. But who’s to blame?

## 'We tried to work him in': Loki season 2's Victor Timely almost appeared in an earlier Marvel TV show
 - [https://www.techradar.com/streaming/disney-plus/we-tried-to-work-him-in-loki-season-2s-victor-timely-almost-appeared-in-an-earlier-marvel-tv-show](https://www.techradar.com/streaming/disney-plus/we-tried-to-work-him-in-loki-season-2s-victor-timely-almost-appeared-in-an-earlier-marvel-tv-show)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T07:01:00+00:00

One of Loki's executive producers reveals how season 2's Kang variant almost made his MCU debut in another Disney Plus project.

## Another 3D monitor that you can use without glasses just launched — and that’s excellent news for VR fans out there
 - [https://www.techradar.com/pro/another-3d-monitor-that-you-can-use-without-glasses-just-launched-and-thats-excellent-news-for-vr-fans-out-there](https://www.techradar.com/pro/another-3d-monitor-that-you-can-use-without-glasses-just-launched-and-thats-excellent-news-for-vr-fans-out-there)
 - RSS feed: https://www.techradar.com/rss
 - date published: 2023-10-20T04:34:36+00:00

The SpatialLabs View Pro 27 boasts a stereoscopic 3D display with HDR support and an ergonomic design.

