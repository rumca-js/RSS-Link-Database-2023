# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## The Papers: Sunak's by-election blues and US hostages freed
 - [https://www.bbc.co.uk/news/blogs-the-papers-67178048?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-67178048?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T22:53:28+00:00

Some of Saturday's front pages reflect on Labour's jubilant double by-election win.

## Rugby World Cup: Watch highlights as New Zealand beat Argentina 44-6 to reach final
 - [https://www.bbc.co.uk/sport/av/rugby-union/67178370?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/rugby-union/67178370?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T22:44:40+00:00

Watch highlights as New Zealand thrash Argentina 44-6 to reach their record fifth Rugby World Cup final.

## United States Grand Prix: Charles Leclerc takes pole position for Sunday's race
 - [https://www.bbc.co.uk/sport/formula1/67177287?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67177287?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T22:12:08+00:00

Ferrari's Charles Leclerc takes pole position in a tight qualifying session in the United States Grand Prix, with Max Verstappen down in sixth on the grid.

## Storm Babet: Second red alert in a week as flooding rages on
 - [https://www.bbc.co.uk/news/uk-scotland-67175318?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67175318?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T21:57:11+00:00

More downpours are forecast on Saturday as rain and wind cause three deaths and UK-wide disruption.

## Moody's boosts view of UK after mini-Budget chaos
 - [https://www.bbc.co.uk/news/business-67175072?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67175072?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T21:24:37+00:00

Ratings agency says "predictability has been restored" following last year's mini-Budget.

## Argentina 6-44 New Zealand: All Blacks cruise into record fifth final
 - [https://www.bbc.co.uk/sport/rugby-union/67177704?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67177704?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T21:03:04+00:00

Will Jordan scores an impressive hat-trick as seven-try New Zealand crush Argentina at Stade de France to reach a record fifth Rugby World Cup final.

## Junior and specialist doctors in England to hold strike talks with government
 - [https://www.bbc.co.uk/news/health-67177954?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67177954?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T21:01:42+00:00

The BMA says it will hold talks with the government to avert strikes by junior and specialist doctors.

## BBC reports from inside destroyed Gaza neighbourhood
 - [https://www.bbc.co.uk/news/world-middle-east-67176203?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67176203?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T20:19:43+00:00

BBC Arabic's Adnan El-Bursh speaks to residents in a destroyed neighbourhood in Gaza.

## Republicans back to square one as Speaker crisis deepens
 - [https://www.bbc.co.uk/news/world-us-canada-67165183?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67165183?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T20:07:51+00:00

Jim Jordan's sudden demise shows how hard it will be for any candidate to unite the party in the House.

## United States Grand Prix: Max Verstappen tops practice before qualifying
 - [https://www.bbc.co.uk/sport/formula1/67177281?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67177281?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T18:47:38+00:00

Red Bull's Max Verstappen heads Ferrari's Charles Leclerc and Mercedes' Lewis Hamilton in first practice at the US Grand Prix.

## Super Mario Bros game Wonder a 'notebook of chaos', critics say
 - [https://www.bbc.co.uk/news/entertainment-arts-67167404?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67167404?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:37:58+00:00

The latest Nintendo adventure follows the gang through the new Flower Kingdom.

## Cricket World Cup 2023: David Warner hits 163 as Australia beat Pakistan
 - [https://www.bbc.co.uk/sport/cricket/67171930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67171930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:36:41+00:00

David Warner's superb 163 inspires Australia to a 62-run victory over Pakistan as they breathe life into their World Cup campaign.

## Rishi Sunak renews plea for Gaza aid during visit to Egypt
 - [https://www.bbc.co.uk/news/uk-67166963?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67166963?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:22:55+00:00

The PM met Palestinian leader Mahmoud Abbas and Egypt's president, calling for the Gaza border to reopen.

## Kenneth Chesebro: Second Trump lawyer pleads guilty to conspiracy
 - [https://www.bbc.co.uk/news/world-us-canada-67174576?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67174576?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:19:54+00:00

Kenneth Chesebro admits conspiracy charge in 2020 election interference case in Georgia.

## ICC Cricket World Cup 2023 highlights: David Warner & Mitchell Marsh inspire Australia to win over Pakistan
 - [https://www.bbc.co.uk/sport/av/cricket/67171721?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67171721?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:12:33+00:00

Watch highlights as centuries from openers David Warner and Mitchell Marsh inspire Australia to a 62-run win over Pakistan in Bangalore in the 2023 ICC Cricket World Cup.

## Israel aims to cut Gaza ties after Hamas defeat
 - [https://www.bbc.co.uk/news/world-middle-east-67175094?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67175094?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T17:06:46+00:00

The long-term goal of the campaign against Hamas is to sever all links with Gaza, Israel's defence minister says.

## Judge threatens to jail Trump for 'blatant' gag order violation
 - [https://www.bbc.co.uk/news/world-us-canada-67175328?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67175328?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:53:13+00:00

The judge said Mr Trump had failed to take down a post from his website mocking a court clerk.

## Chris Mason: Is it back to the 1990s for Labour?
 - [https://www.bbc.co.uk/news/uk-politics-67172485?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67172485?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:51:07+00:00

Huge by-election swings to Labour raise parallels with Blair in 1997 but these are very different times.

## Jakob, Henrik and Filip Ingebrigtsen accuse father of violence
 - [https://www.bbc.co.uk/sport/athletics/67164888?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/athletics/67164888?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:41:34+00:00

Olympic 1500m champion Jakob Ingebrigtsen and his older brothers Henrik and Filip accuse their father and former coach Gjert of being "very aggressive and controlling".

## Rotherham v Ipswich: Championship game postponed after River Don floods
 - [https://www.bbc.co.uk/sport/football/67097336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67097336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:32:25+00:00

Friday's Championship match between Rotherham and Ipswich is postponed after Storm Babet causes flooding in the area.

## Leeds Bradford Airport closed after plane skids off runway in storm
 - [https://www.bbc.co.uk/news/uk-england-leeds-67174117?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-leeds-67174117?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:27:13+00:00

Leeds Bradford Airport evacuates passengers and urges travellers to check with airlines.

## Liverpool v Everton: Jurgen Klopp 'couldn't be less interested' in derby record
 - [https://www.bbc.co.uk/sport/football/67168456?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67168456?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:08:18+00:00

Liverpool boss Jurgen Klopp says his excellent record in the Merseyside derby will count for nothing on Saturday.

## Tamworth and Mid Beds by-elections: Keir Starmer hails results as game-changer
 - [https://www.bbc.co.uk/news/uk-politics-67167297?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67167297?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:01:25+00:00

Overturning huge majorities in Mid Beds and Tamworth shows Labour "can win anywhere", Sir Keir says.

## Met Police: IOPC to investigate water pistol response
 - [https://www.bbc.co.uk/news/uk-england-london-67171426?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-67171426?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T16:00:32+00:00

The IOPC was initially not set to look at the case of a 13-year-old boy confronted by armed police.

## French minister Darmanin spars with footballer Karim Benzema in Gaza row
 - [https://www.bbc.co.uk/news/world-europe-67167925?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67167925?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T15:58:02+00:00

The former French international threatens to sue Gérald Darmanin for accusing him of Islamist links.

## Hate crimes in London see big jump, police say
 - [https://www.bbc.co.uk/news/uk-67173038?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67173038?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T15:36:46+00:00

There has been a rise in antisemitic and Islamophobic hate crimes since the Hamas attack on Israel.

## Orionid meteor shower to light up the skies
 - [https://www.bbc.co.uk/news/science-environment-67173468?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67173468?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T15:15:23+00:00

The streaks of light from the debris of Halley's comet will be at their peak on Saturday.

## England v South Africa: Cobus Reinach 'in good space' despite threats sent online
 - [https://www.bbc.co.uk/sport/rugby-union/67172978?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67172978?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T14:28:30+00:00

Cobus Reinach "is in a good space", says South Africa assistant coach Mzwandile Stick, after the scrum-half was sent threats online.

## ICC Cricket World Cup 2023: Sean Abbott drops Abdullah Shafique over boundary rope for six
 - [https://www.bbc.co.uk/sport/av/cricket/67168800?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67168800?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T14:19:22+00:00

Australia substitute fielder Sean Abbott drops a chance from Pakistan opener Abdullah Shafique over the boundary rope for six runs in their ICC Cricket World Cup 2023 match in Bangalore.

## Lib Dem plan to protect workers from sex harassment to become law
 - [https://www.bbc.co.uk/news/uk-politics-67169750?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67169750?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T14:17:07+00:00

MPs approve Lib Dem workplace plan but only after the House of Lords make significant changes.

## Czech village priest sorry for smashing pumpkins
 - [https://www.bbc.co.uk/news/world-europe-67168388?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67168388?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T14:07:05+00:00

The parish priest said he would have acted differently had he known they were carved by children.

## Instagram sorry for adding 'terrorist' to some Palestinian user bios
 - [https://www.bbc.co.uk/news/technology-67169228?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67169228?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T12:56:47+00:00

It says it fixed a problem "that briefly caused inappropriate translations" in some Instagram profiles.

## Rugby World Cup semi-finals: How England can upset the odds and beat South Africa
 - [https://www.bbc.co.uk/sport/rugby-union/67171844?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67171844?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T12:22:21+00:00

Former England international Paul Grayson and ex-Springbok Bobby Skinstad plot a path to victory for underdogs England in Saturday's World Cup semi-final.

## Actress Haydn Gwynne dies aged 66
 - [https://www.bbc.co.uk/news/entertainment-arts-67172672?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67172672?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T12:19:47+00:00

Acclaimed actress Haydn Gwynne, known for roles in The Windsors and Drop the Dead Donkey, dies aged 66

## Women's Champions League: Chelsea drawn in group with Real Madrid
 - [https://www.bbc.co.uk/sport/football/67168336?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67168336?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T12:11:40+00:00

Chelsea will face Real Madrid, BK Hacken and Paris FC in the Women's Champions League group stage.

## Cricket World Cup 2023: England ready for South Africa test
 - [https://www.bbc.co.uk/sport/cricket/67168646?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67168646?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T12:03:58+00:00

England's white-ball team returns to the scene of a memorable victory against South Africa when the two teams meet again on Saturday.

## Italy PM Giorgia Meloni splits from partner after off-air lewd TV remarks
 - [https://www.bbc.co.uk/news/world-europe-67168294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67168294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T11:38:17+00:00

Giorgia Meloni says the relationship is over after a TV show airs her partner's off-air comments.

## Minimum staff levels demanded in school strikes
 - [https://www.bbc.co.uk/news/education-67168084?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-67168084?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T10:31:08+00:00

Education Secretary Gillian Keegan writes to teaching unions to discuss the proposals.

## MOTDx: Jermaine Jenas' Match of the Day spin-off show cancelled
 - [https://www.bbc.co.uk/news/entertainment-arts-67168083?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67168083?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T10:26:56+00:00

Jermaine Jenas hosted the TV programme but the BBC will now be "producing even more digital content".

## Cardiff University Students' Union bans blue shirts and chinos
 - [https://www.bbc.co.uk/news/uk-wales-67168572?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-67168572?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T10:13:45+00:00

The ban comes after "dangerous behaviour" by a group of students on a Students' Union club night.

## ICC Cricket World Cup 2023: David Warner hits roof with massive six off Haris Rauf
 - [https://www.bbc.co.uk/sport/av/cricket/67168585?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67168585?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T09:24:04+00:00

Australia opener David Warner hits the roof of the stadium in Bangalore with a massive six off Pakistan bowler Haris Rauf in their ICC Men's Cricket World Cup 2023 group stage match.

## Don't dress as Barbie at Halloween, striking Hollywood actors told
 - [https://www.bbc.co.uk/news/entertainment-arts-67168074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67168074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T09:16:58+00:00

Stars are banned from wearing outfits based on hit TV shows and films under the Hollywood strike.

## ICC Cricket World Cup 2023: David Warner dropped on 10 by Usama Mir
 - [https://www.bbc.co.uk/sport/av/cricket/67168582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67168582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T09:08:33+00:00

Watch as Australia opening batter David Warner is dropped on 10 by Pakistan's Usama Mir during their ICC Cricket World Cup 2023 match in Bangalore.

## French arrests after bomb scares trigger evacuations at airports and Versailles
 - [https://www.bbc.co.uk/news/world-europe-67167918?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67167918?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T09:07:41+00:00

The Palace of Versailles, the Louvre as well as schools, airports and hospitals have been targeted.

## Cricket World Cup: Steven Finn on England vs South Africa and Chris Woakes
 - [https://www.bbc.co.uk/sport/cricket/67155135?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67155135?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T09:04:04+00:00

Steven Finn tells BBC Sport that England can capitalise on South Africa's defeat by Netherlands by reopening old wounds in Saturday's match in Mumbai.

## Megan Thee Stallion: Rapper settles legal dispute with former label
 - [https://www.bbc.co.uk/news/newsbeat-67163267?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67163267?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T08:43:47+00:00

Record label 1501 Certified Entertainment say they wish Megan "the very best in her life and career".

## WXV1: England 42-7 Australia - Red Roses make winning start in Wellington
 - [https://www.bbc.co.uk/sport/rugby-union/67166623?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67166623?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T08:11:44+00:00

England beat Australia 42-7 in Wellington to make a winning start to WXV1, the new global tournament in women's rugby.

## Warm weather hits clothing sales in September
 - [https://www.bbc.co.uk/news/business-67166921?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67166921?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T07:40:49+00:00

Shoppers reined back spending on autumn clothes amid rising prices and warm weather.

## Emma Raducanu: British tennis star says 'provoking' questions have contributed to turnover of coaches
 - [https://www.bbc.co.uk/sport/tennis/67166854?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67166854?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T07:31:01+00:00

Former British number one Emma Raducanu says she is constantly asking questions and challenging her coaches.

## Government borrows less than expected in September
 - [https://www.bbc.co.uk/news/business-67166913?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67166913?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T06:58:39+00:00

Public borrowing was £14.3bn last month, lower than most economists had anticipated.

## US warship intercepts missiles fired from Yemen 'potentially towards Israel'
 - [https://www.bbc.co.uk/news/world-middle-east-67166863?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67166863?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T06:52:08+00:00

The USS Carney in the Red Sea downed missiles and drones fired "potentially towards targets in Israel".

## Why goalkeeper Robert Sanchez could be Chelsea’s smartest signing
 - [https://www.bbc.co.uk/sport/football/67141657?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67141657?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T06:47:17+00:00

Former England number one Karen Bardsley takes a deeper look at why goalkeeper Robert Sanchez might turn out to be Chelsea's smartest signing from their recent spending spree.

## Eric Cantona - the singer: 'The Rolling Stones should support me'
 - [https://www.bbc.co.uk/news/entertainment-arts-66808131?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66808131?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T06:17:18+00:00

The football idol on singing about his kung fu kick and why his debut album will be recorded live.

## Travis King: Soldier who fled to North Korea 'charged back in US'
 - [https://www.bbc.co.uk/news/world-us-canada-67166125?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67166125?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T06:05:44+00:00

Charges against Travis King reportedly include desertion and possessing sexual images of a child.

## John Curtice: By-election results show terrible night for Tories
 - [https://www.bbc.co.uk/news/uk-politics-67166028?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67166028?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T05:36:42+00:00

Polling expert Prof Sir John Curtice says the results corroborate the message that the Tories are in electoral trouble.

## Football Focus: Newcastle's boys from Brazil Bruno Guimaraes & Joelinton
 - [https://www.bbc.co.uk/sport/av/football/67161658?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/67161658?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T05:34:26+00:00

Newcastle's Bruno Guimaraes and Joelinton sit down with Football Focus' Caroline de Moraes to talk about their Brazilian bromance, Champions League football and life in the Premier League.

## Residents leave as tension grows at Israel-Lebanon border
 - [https://www.bbc.co.uk/news/world-middle-east-67158836?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67158836?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T05:33:15+00:00

Fears fighting could erupt between Hezbollah and Israel are seeing communities on both sides evacuate.

## Alex Bendall death: Family criticises 'insensitive' police response
 - [https://www.bbc.co.uk/news/uk-england-dorset-67155899?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-dorset-67155899?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T05:06:31+00:00

Alex Bendall was found dead in a river near Dorchester weeks after going missing on a walk home.

## Israel Gaza: Community frozen as Hamas atrocities continue to emerge
 - [https://www.bbc.co.uk/news/world-middle-east-67165128?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67165128?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T02:37:15+00:00

Israeli communities are struggling as bodies continue to be found after Hamas attacked on 7 October.

## Rempang Eco-City: 'We will not leave', say the islanders fighting eviction
 - [https://www.bbc.co.uk/news/world-asia-67051969?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67051969?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T00:34:57+00:00

Fishing communities on this Indonesian island are locked in a battle with the government over land.

## Christmas hope for turkey farmers as bird flu cases drop
 - [https://www.bbc.co.uk/news/science-environment-67159294?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/science-environment-67159294?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T00:29:12+00:00

A fall in the number of avian influenza outbreaks is welcomed by the UK's Christmas turkey farmers.

## Rising tide of homelessness could bankrupt seaside town
 - [https://www.bbc.co.uk/news/uk-67076914?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67076914?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T00:13:59+00:00

In Hastings, 500 homeless families are in temporary accommodation, costing the council £5.6m this year.

## Two-tier care crisis: People forced to pay or wait
 - [https://www.bbc.co.uk/news/health-67145869?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67145869?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-20T00:08:26+00:00

Staffing, funding and cost of living pressures mean a greater risk of an unfair system, says watchdog.

