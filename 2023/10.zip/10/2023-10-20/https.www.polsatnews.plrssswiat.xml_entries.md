# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Niepokój w USA. Przyczyną relacje Rosji i Węgier
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/niepokoj-w-usa-przyczyna-relacje-rosji-i-wegier/](https://www.polsatnews.pl/wiadomosc/2023-10-20/niepokoj-w-usa-przyczyna-relacje-rosji-i-wegier/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T20:37:00+00:00

USA są zaniepokojone relacjami Węgier i Rosji - podaje agencja Reuters, powołując się na ambasadę USA w Budapeszcie. Niepokój budzi decyzja węgierskiego premiera Viktora Orbana o spotkaniu z Władimirem Putinem, do którego doszło we wtorek, 17 października w Pekinie.

## USA. Biały Dom prosi o miliardy dla Izraela i Ukrainy. "Świat patrzy"
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-bialy-dom-prosi-o-miliardy-dlaizraelaiukrainy-swiat-patrzy/](https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-bialy-dom-prosi-o-miliardy-dlaizraelaiukrainy-swiat-patrzy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T19:56:00+00:00

Biały Dom zwrócił się do Kongresu USA o dodatkowe finansowanie pomocy dla Izraela i Ukrainy. W grę wchodzą dziesiątki miliardów dolarów. Pieniądze mają też zostać przeznaczone na wzmocnienie amerykańskich służb granicznych. Administracja argumentuje, że środki przyczynią się do zwiększenia amerykańskiego bezpieczeństwa.

## Rosja. Rodziny żołnierzy piszą listy do Putina. Chcą powrotu swoich bliskich do domu
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/rosja-rodziny-zolnierzy-pisza-listy-do-putina-chca-powrotu-swoich-bliskich-do-domu/](https://www.polsatnews.pl/wiadomosc/2023-10-20/rosja-rodziny-zolnierzy-pisza-listy-do-putina-chca-powrotu-swoich-bliskich-do-domu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T19:24:00+00:00

Krewni rosyjskich żołnierzy zmobilizowanych na wojnę z Ukrainą domagają się powrotu swoich bliskich do domu. Rodziny wojskowych wysłały ponad pięć tysięcy listów w tej sprawie do prezydenta Rosji Władimira Putina oraz ministra obrony Siergieja Szojgu. Krewni zmobilizowanych przedstawili władzom również pewną propozycję - uzupełnienie braków kadrowych w armii o dodatkowe kategorie obywateli.

## USA. Szukali małży. Odnaleźli wrak zaginionego statku
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-szukali-malzy-odnalezli-wrak-zaginionego-statku/](https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-szukali-malzy-odnalezli-wrak-zaginionego-statku/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T17:46:00+00:00

Filmowcy odkryli na dnie jeziora statek, który zaginął ponad 100 lat temu. Wrak został odnaleziony przez przypadek podczas nagrywania filmu o małżach.

## Finlandia. Uszkodzony gazociąg. Na dnie Bałtyku znaleziono "ciężki przedmiot"
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/finlandia-uszkodzony-gazociag-na-dnie-baltyku-znaleziono-ciezki-przedmiot/](https://www.polsatnews.pl/wiadomosc/2023-10-20/finlandia-uszkodzony-gazociag-na-dnie-baltyku-znaleziono-ciezki-przedmiot/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T17:06:00+00:00

W pobliżu gazociągu Balticconnector na dnie Morza Bałtyckiego odnaleziono ciężki przedmiot, który mógł doprowadzić do jego uszkodzenia - poinformowała fińska policja. Śledczy badają obecnie wątek statku towarowego pływającego pod banderą Hongkongu, który przepływał w pobliżu podwodnej instalacji w momencie jej uszkodzenia.

## Niemcy. "Atmosfera jest podgrzana". Przez Berlin przetaczają się propalestyńskie protesty
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/niemcy-atmosfera-jest-podgrzana-przez-belin-przetaczaja-sie-propalestynskie-protesty/](https://www.polsatnews.pl/wiadomosc/2023-10-20/niemcy-atmosfera-jest-podgrzana-przez-belin-przetaczaja-sie-propalestynskie-protesty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T15:13:00+00:00

Przez Belin przetaczają się propalestyńskie protesty. W manifestacjach w ostatnich dniach zatrzymano kilkadziesiąt osób, rannych zostało 80 policjantów. - W weekend spodziewane są kolejne manifestacje, w tym osób wspierających Izrael. Może być gorąco, bo na pewno będą starali się tam pojawić przeciwnicy izraelskiego rządu - przekazał korespondent Polsat News w Berlinie Tomasz Lejman.

## Chaos na diabelskim młynie. Ludzie zwisali głowami w dół
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/chaos-na-diabelskim-mlynie-ludzie-zwisali-glowami-w-dol/](https://www.polsatnews.pl/wiadomosc/2023-10-20/chaos-na-diabelskim-mlynie-ludzie-zwisali-glowami-w-dol/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T14:26:00+00:00

Chwile grozy przeżyły osoby, które zdecydowały się na przejażdżkę diabelskim młynem podczas festynu w indyjskim Dehli. W pewnym momencie atrakcja zatrzymała się, a dwa z wagoników, w których siedzieli ludzie obróciły się o 180 stopni. Nad ziemią utknęło 20 osób. Sieć obiegły nagrania z akcji ratunkowej.

## Rosja: Próba zamachu na Władimira Sołowjowa. Sprawa trafiła do sądu
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/rosja-proba-zamachu-na-kremlowskiego-propagandyste-sprawa-trafila-do-sadu/](https://www.polsatnews.pl/wiadomosc/2023-10-20/rosja-proba-zamachu-na-kremlowskiego-propagandyste-sprawa-trafila-do-sadu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T13:54:00+00:00

Do sądu w Moskwie trafiła sprawa dotycząca przygotowania zabójstwa kremlowskiego propagandysty Władimira Sołowjowa - podała rosyjska agencja TASS. Jak przekazano, Wasilij Striżakow usłyszał sześć zarzutów. W sprawie planowanego zamachu zatrzymano łącznie sześć osób. Rosja o zlecenie działań oskarżyła Ukrainę.

## Japonia. Przeciążony samolot nie mógł wystartować. Na pokładzie zawodnicy sumo
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/japonia-przeciazony-samolot-nie-mogl-wystartowac-na-pokladzie-zawodnicy-sumo/](https://www.polsatnews.pl/wiadomosc/2023-10-20/japonia-przeciazony-samolot-nie-mogl-wystartowac-na-pokladzie-zawodnicy-sumo/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T13:30:00+00:00

Nietypowy problem japońskich linii lotniczych Japan Airlines. Okazało się, że samolot używany na regularnym połączeniu z Tokio do Amami Oshima nie będzie mógł bezpiecznie wystartować. Powodem byli pasażerowie - zapaśnicy sumo - a dokładnie ich waga.

## Tajemniczy podmuch pobił rekordy. Może pomóc rozwiązać sekrety wszechświata
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/tajemniczy-podmuch-pobil-rekordy-moze-pomoc-rozwiazac-sekrety-wszechswiata/](https://www.polsatnews.pl/wiadomosc/2023-10-20/tajemniczy-podmuch-pobil-rekordy-moze-pomoc-rozwiazac-sekrety-wszechswiata/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T12:05:00+00:00

Astronomowie wykryli tajemniczy podmuch fal radiowych, których dotarcie do Ziemi zajęło aż osiem miliardów lat. Szybki rozbłysk był najstarszym i najbardziej oddalonym podmuchem jaki kiedykolwiek zaobserwowano. Trwał mniej niż milisekundę, ale wygenerował energię równoważną 30 lat emisji energetycznej Słońca.

## Wielka Brytania: Rekord świata w mruczeniu. Bella głośniejsza niż telewizor
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/wielka-brytania-rekord-swiata-w-mruczeniu-bella-glosniejsza-niz-telewizor/](https://www.polsatnews.pl/wiadomosc/2023-10-20/wielka-brytania-rekord-swiata-w-mruczeniu-bella-glosniejsza-niz-telewizor/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T12:02:00+00:00

14-letnia kotka Bella została wpisana do Księgi Rekordów Guinessa. Podopieczna brytyjskiej rodziny pobiła rekord w głośności mruczenia. Zwierzę specjalizuje się m.in. w utrudnianiu właścicielce oglądania programów telewizyjnych.

## Panama: Alarm w samolocie i awaryjne lądowanie. Bo znaleźli pieluchę
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/panama-alarm-w-samolocie-i-awaryjne-ladowanie-bo-znalezli-pieluche/](https://www.polsatnews.pl/wiadomosc/2023-10-20/panama-alarm-w-samolocie-i-awaryjne-ladowanie-bo-znalezli-pieluche/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T11:49:00+00:00

To nie był standardowy lot z Panama City do Tampa na Florydzie. Przerażenie wśród pasażerów, a następnie awaryjne lądowanie i akcję policyjnych techników wywołało tajemnicze zawiniątko odnalezione na pokładzie. Przeprowadzono ewakuację i dopiero później okazało się, że służby mają do czynienia jedynie z niegroźną pieluchą dla dorosłych.

## Niezwykłe odkrycie na polu marchwi. Znalezisko ma 3500 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/niezwykle-odkrycie-na-polu-marchwi-znalezisko-ma-3500-lat/](https://www.polsatnews.pl/wiadomosc/2023-10-20/niezwykle-odkrycie-na-polu-marchwi-znalezisko-ma-3500-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T11:42:00+00:00

O niezwykłym szczęściu może mówić mieszkaniec Szwajcarii hobbystycznie przeszukujący okolice niewielkiej miejscowości Güttingen za pomocą wykrywacza metali. W świeżo zaoranym polu marchwi znalazł metalowy krążek. Jak się szybko okazało, pod powierzchnią skrywał się cały zestaw biżuterii z epoki brązu.

## Włochy: Giorgia Meloni rozstała się z partnerem. Powodem skandaliczne nagrania
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/wlochy-giorgia-meloni-rozstala-sie-z-partnerem-powodem-skandaliczne-nagrania/](https://www.polsatnews.pl/wiadomosc/2023-10-20/wlochy-giorgia-meloni-rozstala-sie-z-partnerem-powodem-skandaliczne-nagrania/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T11:20:00+00:00

Premier Włoch Giorgia Meloni przekazała, że po blisko 10 latach rozstała się z partnerem i ojcem jej dziecka Andreą Giambruno. Ostateczna decyzja o zakończeniu związku zapadła po tym, gdy światło dzienne ujrzały skandaliczne nagrania z udziałem mężczyzny. Prezenter telewizyjny zachowywał się na nich w sposób nieprzyzwoity, składał też jednoznaczne propozycje swoim koleżankom z pracy.

## Potężne straty Rosji w jedną dobę. Ukraińcy: Padł rekord
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/potezne-straty-rosji-w-jedna-dobe-ukraincy-padl-rekord/](https://www.polsatnews.pl/wiadomosc/2023-10-20/potezne-straty-rosji-w-jedna-dobe-ukraincy-padl-rekord/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T09:55:00+00:00

Ukraińskie media nie mają wątpliwości: Ostatniej doby padł rekord wyeliminowanych rosyjskich żołnierzy na froncie. Okupanci mają ponosić ciężkie straty w obwodzie donieckim. Łupem kontrofensywy padło również kilkadziesiąt czołgów i 120 wozów opancerzonych.

## Więcej patroli NATO na Bałtyku. Sojusz reaguje na dziwne zdarzenia
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/wiecej-patroli-nato-na-baltyku-sojusz-reaguje-na-dziwne-zdarzenia/](https://www.polsatnews.pl/wiadomosc/2023-10-20/wiecej-patroli-nato-na-baltyku-sojusz-reaguje-na-dziwne-zdarzenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T09:32:00+00:00

Sojusz Północnoatlantycki, po ostatnich awariach gazociągu oraz systemu kabli poprowadzonych przez Bałtyk, zwiększy swoją obecność na tym morzu. Państwa Sojuszu przypuszczają bowiem, że do uszkodzeń instalacji doszło celowo. NATO zapewnia, że monitoruje sytuację i pozostaje w stałym kontakcie z władzami krajów należących do paktu.

## USA: Kawa odporna na "zmiany w powietrzu" w samolotach. Ma smakować lepiej
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-kawa-odporna-na-zmiany-w-powietrzu-w-samolotach-ma-smakowac-lepiej/](https://www.polsatnews.pl/wiadomosc/2023-10-20/usa-kawa-odporna-na-zmiany-w-powietrzu-w-samolotach-ma-smakowac-lepiej/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T07:42:00+00:00

Linie lotnicze z Alaski zorientowały się, że pasażerom niekoniecznie smakuje kawa serwowana na pokładach. Doszły do wniosku, że przyczyną są zmiany w powietrzu, które następują podczas podróży w przestworzach. Zamierzają więc wprowadzić do samolotowego menu specjalny rodzaj kawy. Opracowano go tak, aby napój smakował jak najlepiej w trakcie lotu.

## Nie płacił w restauracjach. Przy rachunku dostawał "ataku serca"
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/oszust-nie-placil-w-restauracjach-przy-rachunku-dostawal-ataku-serca/](https://www.polsatnews.pl/wiadomosc/2023-10-20/oszust-nie-placil-w-restauracjach-przy-rachunku-dostawal-ataku-serca/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T07:17:00+00:00

W hiszpańskich restauracjach zamawiał owoce morza, sałatkę rosyjską i popijał whisky. Następnie 50-letni Aidas J. wstawał od stolika i kierował się do wyjścia, bez płacenia. W przypadku zatrzymania przez obsługę Litwin udawał... atak serca. Służby w Alicante informują, że mężczyzna zrobił tak co najmniej 20 razy. Mimo kolejnych interwencji policji, od blisko roku czuje się bezkarny.

## Orędzie prezydenta USA. Joe Biden wspomniał o Polsce
 - [https://www.polsatnews.pl/wiadomosc/2023-10-20/oredzie-prezydenta-usa-joe-biden-wspomnial-o-polsce/](https://www.polsatnews.pl/wiadomosc/2023-10-20/oredzie-prezydenta-usa-joe-biden-wspomnial-o-polsce/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T06:01:00+00:00

- Hamas oraz Rosja reprezentują różne zagrożenia. Ale mają to ze sobą wspólnego, że chcą kompletnie unicestwić sąsiednie demokracje - zauważył Joe Biden w orędziu wygłoszonym z Gabinetu Owalnego. Ostrzegał, że jeśli apetyt Putina na podbijanie innych krajów nie zostanie zahamowany, Rosja może zagrażać innym państwom. W tym kontekście wspomniał o Polsce oraz państwach bałtyckich.

## Francuscy winiarze mają dosyć. Wylali tysiące litrów wina
 - [https://www.polsatnews.pl/wiadomosc/2023-10-19/francuscy-winiarze-maja-dosyc-wylali-tysiace-litrow-wina/](https://www.polsatnews.pl/wiadomosc/2023-10-19/francuscy-winiarze-maja-dosyc-wylali-tysiace-litrow-wina/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-20T04:42:00+00:00

Francuscy winiarze mają dosyć importu wina z Hiszpanii. W czwartek podjęli protest, w którego trakcie wdarli się na naczepy ciężarówek i wylali tysiące litrów trunku z sąsiedniego kraju.

