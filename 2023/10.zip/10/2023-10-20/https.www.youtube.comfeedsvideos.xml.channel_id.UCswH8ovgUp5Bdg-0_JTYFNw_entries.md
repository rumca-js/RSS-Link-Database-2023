# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## So, It’s Over Then?
 - [https://www.youtube.com/watch?v=y64N3G8iVw8](https://www.youtube.com/watch?v=y64N3G8iVw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-10-20T17:55:42+00:00

Before the tax clock runs out give https://www.taxnetworkusa.com/brand a shout out

Twitter user Douglass Mackey has been sentenced to 7 months in prison after being found guilty of election interference for making memes disparaging Hillary Clinton.

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

