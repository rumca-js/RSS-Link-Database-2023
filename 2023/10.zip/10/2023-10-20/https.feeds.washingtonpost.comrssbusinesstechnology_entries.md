# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Supreme Court says White House can continue requests to tech companies
 - [https://www.washingtonpost.com/politics/2023/10/20/supreme-court-tech-companies-social-media-posts/](https://www.washingtonpost.com/politics/2023/10/20/supreme-court-tech-companies-social-media-posts/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-20T20:48:12+00:00

A lower court found top officials improperly pressured tech companies to take down what they saw as problematic health- and election-related posts.

## This is the best AI technology you’re probably not using
 - [https://www.washingtonpost.com/technology/2023/10/20/swipe-to-type-iphones-android/](https://www.washingtonpost.com/technology/2023/10/20/swipe-to-type-iphones-android/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-20T16:30:00+00:00

I’m terrible at typing on my glass phone screen. If you are, too, try using swipe to type.

## Pro-Palestinian creators evade social media suppression by using ‘algospeak’
 - [https://www.washingtonpost.com/technology/2023/10/20/palestinian-tiktok-instagram-algospeak-israel-hamas/](https://www.washingtonpost.com/technology/2023/10/20/palestinian-tiktok-instagram-algospeak-israel-hamas/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-20T11:00:09+00:00

From ‘terrier’ to ‘P*les+in1ans,’ creators are changing up their language to evade big tech’s content rules.

## Newspapers want payment for articles used to power ChatGPT
 - [https://www.washingtonpost.com/technology/2023/10/20/artificial-intelligence-battle-online-data/](https://www.washingtonpost.com/technology/2023/10/20/artificial-intelligence-battle-online-data/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-20T09:51:35+00:00

The artificial intelligence gold rush has sparked a battle over online information that stands to make winners very rich and leave losers in the dust.

