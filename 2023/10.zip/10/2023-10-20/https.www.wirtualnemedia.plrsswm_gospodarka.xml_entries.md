# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Biogaz i biometan źródłem zielonej bioenergii
 - [https://www.wirtualnemedia.pl/artykul/biogaz-i-biometan-zrodlem-zielonej-bioenergii](https://www.wirtualnemedia.pl/artykul/biogaz-i-biometan-zrodlem-zielonej-bioenergii)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-20T07:24:00+00:00

Rozwój produkcji biogazu i biometanu może znacząco wspomóc dekarbonizację – jako stabilne źródło zielonej energii w elektroenergetyce, ogrzewaniu czy transporcie. To także istotne wsparcie w gospodarowaniu odpadami – uważa Adam Juszczak, analityk z zespołu klimatu i energii w Polskim Instytucie Ekonomicznym.

## Rynek pracy w Polsce nie wykorzystuje potencjału pracowników w wieku 45-64 lata
 - [https://www.wirtualnemedia.pl/artykul/rynek-pracy-w-polsce-nie-wykorzystuje-potencjalu-pracownikow-w-wieku-45-64-lata](https://www.wirtualnemedia.pl/artykul/rynek-pracy-w-polsce-nie-wykorzystuje-potencjalu-pracownikow-w-wieku-45-64-lata)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-20T06:10:03.624116+00:00

Rynek pracy nie wykorzystuje potencjału pracowników w wieku 45-64 lata w krajach OECD, a zjawisko ich dyskryminacji występuje też na polskim rynku pracy – wskazał Polski Instytut Ekonomiczny. Zaznaczono, że udział tych osób w ogóle ludności w wieku produkcyjnym rośnie w krajach OECD jak i w Polsce.

## Grypa to jedna z głównych przyczyn zachorowań i zgonów wśród seniorów
 - [https://www.wirtualnemedia.pl/artykul/grypa-objawy-zabija-ludzi-starszych](https://www.wirtualnemedia.pl/artykul/grypa-objawy-zabija-ludzi-starszych)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-20T05:03:36.293191+00:00

Grypa stanowi jedną z głównych przyczyn zachorowań i zgonów wśród seniorów. Co roku z powodu jej powikłań umiera ok. 6 tys. osób po 65. roku życia. Dlatego tak ważne jest szczepienie przeciw grypie osób w podeszłym wieku – przypomina pulmonolog prof. Adam Antczak.

## Spółka z holdingu Palikota i Wojewódzkiego wprowadza w błąd ws. Buntu Finansowego? Ma dostać miliony od inwestorów
 - [https://www.wirtualnemedia.pl/artykul/janusz-palikot-pozyczki-bunt-finansowy-jak-splaci-dlug-zalegle-pensje](https://www.wirtualnemedia.pl/artykul/janusz-palikot-pozyczki-bunt-finansowy-jak-splaci-dlug-zalegle-pensje)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-20T05:03:36.292675+00:00

Rzecznik Finansowy wezwał Tenczynek Dystrybucję, spółkę zależną Manufaktury Piwa Wódki i Wina, żeby przestała wprowadzać konsumentów w błąd nazwą Bunt Finansowy. - Złożyliśmy obszerne wyjaśnienia, bo nie mamy nic do ukrycia, ale informowaliśmy rzecznika, że nie jesteśmy podmiotem rynku finansowego - podkreśla Janusz Palikot. I zapowiada, że po zatwierdzeniu układu z wierzycielami Manufaktura dostanie 11-13 mln zł od grupy inwestorów.

