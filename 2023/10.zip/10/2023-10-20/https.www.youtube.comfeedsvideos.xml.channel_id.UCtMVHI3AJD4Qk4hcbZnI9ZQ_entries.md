# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## YouTube's Terrible Response...
 - [https://www.youtube.com/watch?v=hPfe56Ow0tE](https://www.youtube.com/watch?v=hPfe56Ow0tE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-10-20T22:52:13+00:00

Hello guys and gals, it's me Mutahar again! YouTube's responded to the SSSniperwolf situation and it equates to the flimsiest slap on the wrist and a complete lack of acknowledgement on the more serious of TOS violations she's seemed to have committed. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest episode of the podcast: https://youtu.be/RRGRrAMHvxQ

