# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why The Goofy Movie Never Should Have Worked
 - [https://www.youtube.com/watch?v=3ZtfIU7vrZg](https://www.youtube.com/watch?v=3ZtfIU7vrZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-10-20T17:00:05+00:00

From the moment it was conceptualized, A Goofy Movie had to fight to get out from under the overbearing thumb of Disney executives.  But upon it's release, A Goofy Movie proved to be the right move at the right time.  Dealing with creative conflict, budgetary constraints, and a disheartening lack of faith within Disney, A Goofy Movie proved that a little faith in a smaller movie can pay off huge in the long run. 

#agoofymovie #disney #goofy #animation 

SOURCES
https://www.vanityfair.com/hollywood/2020/04/goofy-movie-anniversary-disney
https://www.slashfilm.com/573719/a-goofy-movie-oral-history/
https://www.hollywoodreporter.com/news/general-news/epic-disney-blow-up-1994-694476/
https://www.latimes.com/archives/la-xpm-1994-04-04-mn-42417-story.html
https://www.cartoonbrew.com/series/atlanta-goofy-movie-making-of-mocumentary-223273.html
https://www.youtube.com/watch?v=WY7UVqLVg8k
https://www.youtube.com/watch?v=I1RkXekdCHU

