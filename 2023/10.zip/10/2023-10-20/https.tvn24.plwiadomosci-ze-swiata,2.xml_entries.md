# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Kaczyński tworzy "projekt na dalsze działania - i te ofensywne, i te defensywne"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-jaroslaw-kaczynski-prezes-pis-z-naszej-strony-byl-szereg-bledow-7402287?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-jaroslaw-kaczynski-prezes-pis-z-naszej-strony-byl-szereg-bledow-7402287?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-10-20T20:47:37+00:00

<img alt="Kaczyński tworzy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-g6mrs8-jaroslaw-kaczynski-7402289/alternates/LANDSCAPE_1280" />
    Jarosław Kaczyński, prezes PiS, wicepremier powiedział w Spale, że po wyborach jego partia musi przeprowadzić "analizę tego, co się stało" i mieć projekt 'na dalsze działania - i te ofensywne, i te defensywne". - Mieliśmy tu oczywiście także do czynienia z szeregiem błędów z naszej strony - przyznał. Dodał, że w ciągu ostatnich kilku lat "zmieniła się także struktura elektoratu".

## Joe Biden z orędziem do narodu. Mówił o zagrożeniu Rosji, Polsce, państwach bałtyckich, Ukrainie i terroryzmie
 - [https://tvn24.pl/swiat/joe-biden-w-oredziu-do-narodu-o-putinie-polsce-panstwach-baltyckich-ukrainie-izraelu-i-walce-z-terrorem-7400371?source=rss](https://tvn24.pl/swiat/joe-biden-w-oredziu-do-narodu-o-putinie-polsce-panstwach-baltyckich-ukrainie-izraelu-i-walce-z-terrorem-7400371?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-10-20T03:33:25+00:00

<img alt="Joe Biden z orędziem do narodu. Mówił o zagrożeniu Rosji, Polsce, państwach bałtyckich, Ukrainie i terroryzmie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ce0hnq-prezydent-usa-joe-biden-7400370/alternates/LANDSCAPE_1280" />
    Prezydent USA Joe Biden w orędziu do narodu stwierdził, że jeśli demokratyczna wspólnota międzynarodowa nie powstrzyma Władimira Putina, nie zatrzyma się on na Ukrainie. - Putin już zagroził, że przypomni Polsce, że jej zachodnie ziemie są "darem" od Rosji - powiedział, wskazując też na słowa płynące z Kremla pod adresem Litwy, Łotwy i Estonii. Podkreślił, że USA będą bronić każdej piędzi ziemi NATO. Joe Biden zapowiedział równocześnie, że w piątek zwróci się do Kongresu o znaczący pakiet środków dla Ukrainy i Izraela.

