# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Michigan Senate Votes To Strip ‘Woman’ Out Of Breastfeeding Law, Giving Chestfeeders Another Win
 - [https://www.louderwithcrowder.com/michigan-breastfeeding-law](https://www.louderwithcrowder.com/michigan-breastfeeding-law)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T20:28:00+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50019418&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Over half of the Michigan State Senate does not know what a woman is. Or at the very least, they are trying to erase women from the law. Which may even be worse. </p><p>The Michigan state Senate voted on legislation that stripped references to “woman” and “she” from a 2014 breastfeeding law, <a href="https://www.themidwesterner.news/2023/10/michigan-senate-passes-bill-to-strip-woman-out-of-breastfeeding-antidiscrimination-act/" rel="noopener noreferrer" target="_blank">according </a>to The Midwesterner. </p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/Th_Midwesterner/status/1715025704310423841"></a>
</blockquote>
<p>No, lawmakers did not have anything better to do. </p><p>You know, because the truth hurts and you would not want to hurt someone's feelin

## Watch: Arrest Follows School District’s Approval Of Sex Ed Opposing “Female” and “Male”  In Florida
 - [https://www.louderwithcrowder.com/florida-district-female](https://www.louderwithcrowder.com/florida-district-female)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T20:22:43+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=50018477&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>One individual was <a href="https://www.sun-sentinel.com/2023/10/17/new-sex-ed-curriculum-is-approved-for-broward-schools-exchange-leads-to-arrest/" rel="noopener noreferrer" target="_blank">arrested </a>after being escorted out of a Florida school board meeting after a debate over a proposed sexual education curriculum caused tempers to fume. </p><p> Broward County School District voted to approve a sex education curriculum that denies reality and opposes the terms “female” and “male” after a debate Tuesday night. The debate subsequently led to the arrest of a local advocate.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/smtravis/status/1714354782939267348"></a>
</blockquote>
<p>You know, because truth is a crime now. </p><p>In one section, the docu

## Federal Judge Overturns California’s Unconstitutional Assault Weapons Ban Again
 - [https://www.louderwithcrowder.com/assault-weapon-california](https://www.louderwithcrowder.com/assault-weapon-california)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T17:46:07+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49992020&amp;width=1200&amp;height=800&amp;coordinates=147%2C0%2C148%2C0" /><br /><br /><p>As Pelosi would <a href="https://www.facebook.com/watch/?v=1637276419978894" rel="noopener noreferrer" target="_blank">say</a>: “There’s no point in saying good morning because it certainly is not one.”</p><p>Well, it is a good morning for us. But for Elected officials in the People's Republic of California, let’s just say they are not too happy today.</p><p>A federal judge came in locked and loaded on Thursday when he <a href="https://www.cnn.com/2023/10/20/us/judge-blocks-california-assault-weapon-ban/index.html" rel="noopener noreferrer" target="_blank">overturned California’s </a>30-year prohibition on so-called assault weapons AGAIN, saying banning semi-automatic firearms violates the constitutional right to bear arms.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a hr

## Did Elon Musk Strip NYT's  Verification Badge Over Their Fake News And Anti-Israel Misinformation?
 - [https://www.louderwithcrowder.com/nyt-blue-checkmark](https://www.louderwithcrowder.com/nyt-blue-checkmark)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T17:15:31+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49986576&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C1" /><br /><br /><p>Reports flooded social media Friday morning after some people alleged that The New York Times lost its verification badge, following a flood of disinformation it published on the Israel-Hamas war. As of writing this, The Times currently has its little blue checkmark. </p><p><br /></p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/stoolpresidente/status/1715380374375686401"></a>
</blockquote>
<p>There are three things that are true right now. We have seen <a href="https://twitter.com/DrEliDavid/status/1715320477617631548?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed%7Ctwterm%5E1715320477617631548%7Ctwgr%5Ebbe0e52e52968ac01b3f3a6839e25ae8fc859860%7Ctwcon%5Es1_&amp;ref_url=https%3A%2F%2Fwww.dailywire.com%2Fnews%2Fafter-it-lied-about-israel-new-york-times-verifi

## WaPo's word choice to water down Hamas kidnapping Jews looks worse after what they did next
 - [https://www.louderwithcrowder.com/wapo-kidnapping](https://www.louderwithcrowder.com/wapo-kidnapping)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T16:55:51+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=49978363&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Before we get to the latest edition of <em>The Washington Post: Derpocracy Derps in the Darkness</em>, I'd like to draw your attention to two items. One is a new Gallup poll that <a href="https://thefederalist.com/2023/10/20/poll-more-americans-than-ever-have-zero-trust-in-media/" target="_blank">shows distrust in the media at an all-time high</a>. The other is this popular meme.</p><p class="shortcode-media shortcode-media-rebelmouse-image">
<img alt="" class="rm-shortcode" id="c049c" src="https://www.louderwithcrowder.com/media-library/image.jpg?id=49979274&amp;width=980" />
</p><p>WaPo created content that claimed an Israeli woman's children were detained. Not KIDNAPPED, but detained. As if they were being questioned by the police.</p><p><a href="https://townhall.com/tipsheet/mattvespa/2023/10/20/wait-thats-how-the-washington

## 411 congressional staffers anonymously sign a letter demanding Israel ceasefire, and of course, The Squad supports them
 - [https://www.louderwithcrowder.com/congressional-staffers-anonymous-letter](https://www.louderwithcrowder.com/congressional-staffers-anonymous-letter)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T14:21:50+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=49951245&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>411 congressional staffers signed an open letter to the congressmembers who gave them jobs demanding an Israel ceasefire against Hamas terrorists. The letter was allegedly anonymously signed by Muslim AND Jewish staffers, as well as allies. </p><p>I say allegedly because we don't know for a fact. They signed anonymously. It could only be two Jewish staffers. It could have been people bullied and terrorized into signing. And it could have been people who put their name on a letter because they were asked and didn't really care. What can you do? </p><p>People have been calling for an Israel ceasefire since before Israel returned fire. There are always two stages of this. The first is <a href="https://www.louderwithcrowder.com/harbard-israel-hamas-protest" target="_blank">progressives celebrating</a> the <a href="https://www.louder

## Watch: The highlight of Joe Biden's address to the nation are these eight seconds he didn't know he was live
 - [https://www.louderwithcrowder.com/joe-biden-address-to-the-nation](https://www.louderwithcrowder.com/joe-biden-address-to-the-nation)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T13:09:43+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49936582&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Joe Biden, Mr. 81 Million, addressed the nation on Thursday night to say he was calling on Congress to pass his emergency $100 Billion aid package to Ukraine. Israel gets some too. We had no idea he was going to be on until we woke up this morning and saw people making fun of him not knowing the cameras were on. Besides, who watches network television anymore?</p><p>Policywise, there were two key points, The first is the more money he wants to give to Ukraine... and Israel too. It has to be tied together, though. We can't vote separately on giving aid to Israel and giving MORE aid to Ukraine based on the individual merits of doing either. And unlike Zelenskyy, I wasn't aware Netanyahu asked for anything.</p><p>The other is warning people about, in response to Hamas launching a terrorist attack against Israel and people in Americ

## Actor goes BANANAS on the "jew hating" Democrat members of The Squad: "You fake news f*cks"
 - [https://www.louderwithcrowder.com/michael-rapaport-the-squad](https://www.louderwithcrowder.com/michael-rapaport-the-squad)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T12:17:57+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49925178&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Yes, it's Michael Rapaport. I know some of you are saying "But he hates Trump and is our enemy, don't give him attention." <a href="https://www.louderwithcrowder.com/michael-rapaport-antifa-trump-arraignment" target="_blank">We are well aware of that</a>, but it's still hilarious to see how many times one man can use the f-word to describe members of The Squad. Pull the stick out of your arse and enjoy the content.</p><p>Rapaport, who is Jewish, took a break from beefing with John Cusack (<a href="https://www.louderwithcrowder.com/john-cusack-desantis-elon-twitter" target="_blank">who is also nuts</a>) to go after the Antisemitism spread by congresswomen Rashida Tlaib and Ilhan Omar and by social media influencer Rep. AOC. After Hamas paraglided into Israel and start killing and raping, the Democrat Party stars were in their glo

## Watch: Victoria's Secret Ditches Fat Chicks & Brings Back Sexy Models
 - [https://www.louderwithcrowder.com/victorias-secret-brings-back-sexy](https://www.louderwithcrowder.com/victorias-secret-brings-back-sexy)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-20T11:34:43+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49917506&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Comment if you're ready to have hot models back again.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Victoria's Secret Ditches Fat Chicks & Brings Back Sexy Models!</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=hLFcklYBD_A" target="_blank">www.youtube.com</a>
</small>
</p>

