# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Soul Glo - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=KS78vsJa8fw](https://www.youtube.com/watch?v=KS78vsJa8fw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T18:33:58+00:00

http://KEXP.ORG presents Soul Glo performing live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

Songs:
Jump!! (Or Get Jumped!!!)((by the future))
We Wants Revenge
Driponomics (feat. Mother Maryrose)
Gold Chain Punk (whogonbeatmyass?)

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Jump!! (Or Get Jumped!!!) ((by the future)) (Live on KEXP)
 - [https://www.youtube.com/watch?v=2t6qxOnXBQo](https://www.youtube.com/watch?v=2t6qxOnXBQo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T18:33:24+00:00

http://KEXP.ORG presents Soul Glo performing “Jump!! (Or Get Jumped!!!) ((by the future))” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - We Wants Revenge (Live on KEXP)
 - [https://www.youtube.com/watch?v=VTqK4dcryc8](https://www.youtube.com/watch?v=VTqK4dcryc8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T18:33:24+00:00

http://KEXP.ORG presents Soul Glo performing “We Wants Revenge” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Driponomics (Live on KEXP)
 - [https://www.youtube.com/watch?v=Mziyw2q8m9g](https://www.youtube.com/watch?v=Mziyw2q8m9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T18:33:23+00:00

http://KEXP.ORG presents Soul Glo performing “Driponomics” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Gold Chain Punk (whogonbeatmyass) (Live on KEXP)
 - [https://www.youtube.com/watch?v=3bPx7XXYQjg](https://www.youtube.com/watch?v=3bPx7XXYQjg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T18:33:23+00:00

http://KEXP.ORG presents Soul Glo performing “Gold Chain Punk (whogonbeatmyass)” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=IvAgN_bQNxY](https://www.youtube.com/watch?v=IvAgN_bQNxY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T15:00:13+00:00

http://KEXP.ORG presents Soul Glo performing live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

Songs:
Jump!! (Or Get Jumped!!!)((by the future))
We Wants Revenge
Driponomics (feat. Mother Maryrose)
Gold Chain Punk (whogonbeatmyass?)

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Jump!! (Or Get Jumped!!!)((by the future)) (Live on KEXP)
 - [https://www.youtube.com/watch?v=iQg_LUVoyxQ](https://www.youtube.com/watch?v=iQg_LUVoyxQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T11:00:40+00:00

http://KEXP.ORG presents Soul Glo performing “Jump!! (Or Get Jumped!!!)((by the future))” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Driponomics (feat. Mother Maryrose) (Live on KEXP)
 - [https://www.youtube.com/watch?v=XmCgpRqKRUY](https://www.youtube.com/watch?v=XmCgpRqKRUY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T11:00:27+00:00

http://KEXP.ORG presents Soul Glo performing “Driponomics (feat. Mother Maryrose)” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - We Wants Revenge (Live on KEXP)
 - [https://www.youtube.com/watch?v=bx3lSVEqv6I](https://www.youtube.com/watch?v=bx3lSVEqv6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T11:00:27+00:00

http://KEXP.ORG presents Soul Glo performing “We Wants Revenge” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

## Soul Glo - Gold Chain Punk (whogonbeatmyass) (Live on KEXP)
 - [https://www.youtube.com/watch?v=Rk3fxt0e1wM](https://www.youtube.com/watch?v=Rk3fxt0e1wM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-20T11:00:21+00:00

http://KEXP.ORG presents Soul Glo performing “Gold Chain Punk (whogonbeatmyass)” live at THING Festival at Fort Warden in Port Townsend, Washington. Recorded August 25, 2023

PIERCE JORDAN - Vocals, Electronics
GG GUERRA - Guitar, Electronics
ROB BLACKWELL - Bass
T.J. STEVENSON - Drums

Host: DJ Morgan
Audio Engineers: Kevin Suggs, Matt Ogaz
Audio Mixer: Julian Martlew
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Ettie Wahl, Luke Knecht
Director: Scott Holpainen
Editor: Jonathan Jacobson

https://soulglophl.com
http://kexp.org

Join this channel to get access to perks:
https://www.youtube.com/channel/UC3I2GFN_F8WudD_2jUZbojA/join

