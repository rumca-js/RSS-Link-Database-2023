# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Kaczyński: Trzeba mieć drugi budżet i drugie finanse publiczne, żeby zrealizować obietnice opozycji
 - [https://www.bankier.pl/wiadomosc/Kaczynski-Trzeba-miec-drugi-budzet-i-drugie-finanse-publiczne-zeby-zrealizowac-obietnice-opozycji-8633340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kaczynski-Trzeba-miec-drugi-budzet-i-drugie-finanse-publiczne-zeby-zrealizowac-obietnice-opozycji-8633340.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T22:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/28e28e278d6432-948-568-22-90-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Żeby zrealizować obietnice  opozycji, trzeba mieć nie tylko drugi budżet, ale  ile drugie finanse publiczne - mówił w piątek  prezes PiS Jarosław Kaczyński na IX Nadzwyczajnym Zjeździe Klubów "Gazety Polskiej" w Spale.</p>

## Wspólna deklaracja USA-UE: będziemy karać podmioty z państw trzecich wspierające Rosję
 - [https://www.bankier.pl/wiadomosc/Wspolna-deklaracja-USA-UE-bedziemy-karac-podmioty-z-panstw-trzecich-wspierajace-Rosje-8633339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wspolna-deklaracja-USA-UE-bedziemy-karac-podmioty-z-panstw-trzecich-wspierajace-Rosje-8633339.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T22:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/c63e7ebff369e8-948-568-0-112-1593-956.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będziemy działać przeciwko podmiotom z państw trzecich, które wspierają wojnę Rosji przeciwko Ukrainie - zapowiedzieli w piątek przywódcy USA i  UE we wspólnym oświadczeniu po spotkaniu w Białym Domu. Joe Biden, Ursula von der Leyen i Charles Michel wezwali też Chiny do nacisków na Moskwę, by powstrzymała swoją agresję.</p>

## Media: Negocjacje między Węgrami a UE przyspieszyły; możliwe szybkie porozumienie
 - [https://www.bankier.pl/wiadomosc/Media-Negocjacje-miedzy-Wegrami-a-UE-przyspieszyly-mozliwe-szybkie-porozumienie-8633334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Negocjacje-miedzy-Wegrami-a-UE-przyspieszyly-mozliwe-szybkie-porozumienie-8633334.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T22:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/62788bb1748b6b-948-568-0-327-3968-2380.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Negocjacje między węgierskim rządem a UE przyspieszyły, możliwe jest szybkie porozumienie w sprawie zablokowanych funduszy – poinformował dziennik „Nepszava”, powołując się na swoje źródła w Brukseli.</p>

## Wall Street znów w dół. S&P spadł czwartą sesję z rzędu
 - [https://www.bankier.pl/wiadomosc/Wall-Street-znow-w-dol-S-P-spadl-czwarta-sesje-z-rzedu-8633313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wall-Street-znow-w-dol-S-P-spadl-czwarta-sesje-z-rzedu-8633313.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T20:24:23.602360+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/c/6b41e0444bb6ed-948-568-204-399-3888-2333.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Piątkowa sesja przyniosła pogłębienie spadkowej korekty na nowojorskich
parkietach.</p>

## Scholz o nielegalnej migracji: trzeba deportować ludzi na dużą skalę
 - [https://www.bankier.pl/wiadomosc/Scholz-o-nielegalnej-migracji-trzeba-deportowac-ludzi-na-duza-skale-8633294.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Scholz-o-nielegalnej-migracji-trzeba-deportowac-ludzi-na-duza-skale-8633294.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T19:19:28.110347+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/69da236919ded1-948-568-0-142-3158-1894.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kanclerz Olaf Scholz (SPD) zapowiedział w piątek 
bardziej zdecydowane działania przeciwko nielegalnej imigracji w 
Niemczech. Jego zdaniem deportacje powinny być dokonywane na dużą skalę –
 informuje portal ZDFheute.</p>

## Armia Izraela: większość zakładników Hamasu żyje, ponad 20 to dzieci
 - [https://www.bankier.pl/wiadomosc/Armia-Izraela-wiekszosc-zakladnikow-Hamasu-zyje-ponad-20-to-dzieci-8633287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Armia-Izraela-wiekszosc-zakladnikow-Hamasu-zyje-ponad-20-to-dzieci-8633287.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T18:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/d5b0a91420c585-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Większość zakładników uprowadzonych przez bojowników Hamasu do Strefy Gazy żyje, a ponad 20 z nich to osoby niepełnoletnie – ogłosiły w piątek Siły Obronne Izraela (IDF). Według wcześniejszych informacji terroryści porwali z Izraela około 200 ludzi, w tym kobiety, dzieci i osoby starsze.</p>

## USA wysłały pomoc humanitarną do Strefy Gazy
 - [https://www.bankier.pl/wiadomosc/USA-wyslaly-pomoc-humanitarna-do-Strefy-Gazy-8633282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/USA-wyslaly-pomoc-humanitarna-do-Strefy-Gazy-8633282.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T18:45:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/910bbbc3daae51-948-568-0-315-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Myślę, że pierwsze ciężarówki z pomocą humanitarną dotrą do Gazy w ciągu 24-48 godzin - oświadczył w piątek prezydent USA Joe Biden podczas spotkania z przewodniczącymi Komisji Europejskiej i Rady Europejskiej, Ursulą von der Leyen i Charlesem Michelem. Przywódcy będą rozmawiać o sytuacji w Izraelu i Ukrainie oraz omówią negocjacje handlowe dotyczące m.in. zielonej transformacji.</p>

## Kukiz: Szanse na stworzenie przez PiS samodzielnego rządu są minimalne
 - [https://www.bankier.pl/wiadomosc/Kukiz-Szanse-na-stworzenie-przez-PiS-samodzielnego-rzadu-sa-minimalne-8633280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kukiz-Szanse-na-stworzenie-przez-PiS-samodzielnego-rzadu-sa-minimalne-8633280.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T18:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/356dc18cdba97f-948-568-0-0-3779-2267.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jakieś szanse zawsze istnieją, jednak w tej chwili są one minimalne; ale za pół roku niekoniecznie musi tak być, gdy do realnej polityki dojdzie opozycja; Donald Tusk już ma problemy z realizacją obietnic - powiedział w Radiu Zet lider Kukiz'15 Paweł Kukiz, pytany czy widzi szansę na stworzenie przez PiS samodzielnego rządu.</p>

## Siemoniak: Premierem koalicyjnym będzie Donald Tusk – to rzecz przesądzona
 - [https://www.bankier.pl/wiadomosc/Siemoniak-Premierem-koalicyjnym-bedzie-Donald-Tusk-to-rzecz-przesadzona-8633274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Siemoniak-Premierem-koalicyjnym-bedzie-Donald-Tusk-to-rzecz-przesadzona-8633274.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T17:56:39.694874+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/c/8faaabdd4410d0-948-568-0-201-3356-2013.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przesądzone jest, że premierem będzie Donald Tusk – powiedział w piątek w radiu RMF FM wiceprzewodniczący PO Tomasz Siemoniak. Polityk podkreślił, że liczy na to, że prezydent Andrzej Duda, powierzając misję tworzenia nowego rządu, zauważy, że PiS nie ma zdolności koalicyjnej.</p>

## Wypadek na A1. Doszło do nadużyć? Łódzka policja reaguje na doniesienia mediów
 - [https://www.bankier.pl/wiadomosc/Wypadek-na-A1-Doszlo-do-naduzyc-Lodzka-policja-reaguje-na-doniesienia-mediow-8633259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wypadek-na-A1-Doszlo-do-naduzyc-Lodzka-policja-reaguje-na-doniesienia-mediow-8633259.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T17:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/1/1ecca260cff66e-948-567-0-28-950-569.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po wypadku, do którego doszło 16 września 2023 roku na autostradzie A1, została sporządzona tylko jedna notatka urzędowa mówiąca o przebiegu zdarzenia - oświadczyła w piątek po południu łódzka w związku z publikacją w "Rzeczpospolitej". Chodzi o tło wypadku i pożaru, w którym zginęła trzyosobowa rodzina.</p>

## "Wodospad" na Pepco trwa. Bardzo zmienny tydzień na WIG20
 - [https://www.bankier.pl/wiadomosc/Wodospad-na-Pepco-trwa-Bardzo-zmienny-tydzien-na-WIG20-8633198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wodospad-na-Pepco-trwa-Bardzo-zmienny-tydzien-na-WIG20-8633198.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T16:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/2/1efde1c5715f33-948-568-0-784-1950-1169.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzeci z rzędu dzień spadków na GPW nie przeszkodził WIG20 zamknąć zmiennego tygodnia na plusie. Skrajne postawy inwestorów w pierwszej połowie tygodnia koncentrowały się czynnikach lokalnych, by w jego drugiej części najwięcej czerpać z zewnętrznego sentymentu.  </p>

## Biały Dom zwrócił się do Kongresu o ponad 60 mld dol. na pomoc dla Ukrainy i 14 mld dla Izraela
 - [https://www.bankier.pl/wiadomosc/Bialy-Dom-zwrocil-sie-do-Kongresu-o-ponad-60-mld-dol-na-pomoc-dla-Ukrainy-i-14-mld-dla-Izraela-8633202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bialy-Dom-zwrocil-sie-do-Kongresu-o-ponad-60-mld-dol-na-pomoc-dla-Ukrainy-i-14-mld-dla-Izraela-8633202.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T16:03:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/ee1851a2298f1c-948-568-8-141-3534-2120.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biały Dom zwrócił się w piątek do Kongresu o uchwalenie dodatkowego pakietu 105 mld dolarów na pomoc dla Ukrainy, Izraela, sojuszników USA w Indo-Pacyfiku oraz na wzmocnienie bezpieczeństwa granic. Administracja Joe Bidena chce ponad 60 mld dolarów na wydatki związane z pomocą gospodarczą i wojskową Ukrainie i 14 mld na wsparcie wojskowe Izraela.</p>

## Do tej pory wpłynęło 20 protestów wyborczych i 11 referendalnych do Sądu Najwyższego
 - [https://www.bankier.pl/wiadomosc/Do-tej-pory-wplynelo-20-protestow-wyborczych-i-11-referendalnych-do-Sadu-Najwyzszego-8633164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Do-tej-pory-wplynelo-20-protestow-wyborczych-i-11-referendalnych-do-Sadu-Najwyzszego-8633164.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T15:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/7/149aae4ee5860b-948-568-0-202-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W piątek w Sądzie Najwyższym do godz. 15.30 odnotowano 20 protestów odnoszących się do wyborów parlamentarnych oraz 11 protestów przeciwko ważności referendum - poinformowało PAP w piątek po południu biuro prasowe Sądu Najwyższego.</p>

## Zadłużenie Skarbu Państwa mocno wzrosło i wynosi już ponad 1,3 biliona złotych
 - [https://www.bankier.pl/wiadomosc/Zadluzenie-Skarbu-Panstwa-mocno-wzroslo-i-wynosi-juz-ponad-1-3-biliona-zlotych-8633145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zadluzenie-Skarbu-Panstwa-mocno-wzroslo-i-wynosi-juz-ponad-1-3-biliona-zlotych-8633145.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T14:28:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/10cf782cf1224f-948-568-0-168-4168-2501.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zadłużenie Skarbu Państwa na koniec września wzrosło o 27,2 mld zł (+2,1 proc.) mdm i wyniosło ok. 1.305,3 mld zł - MF.  - podał resort finansów w szacunkowych danych.</p>

## List Krzysztofa Kolumba z 1493 roku sprzedany na aukcji za 4 mln dolarów
 - [https://www.bankier.pl/wiadomosc/List-Krzysztofa-Kolumba-z-1493-roku-sprzedany-na-aukcji-za-4-mln-dolarow-8633141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/List-Krzysztofa-Kolumba-z-1493-roku-sprzedany-na-aukcji-za-4-mln-dolarow-8633141.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T14:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/3/cd51a55d264cef-948-567-0-31-1040-623.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />List Krzysztofa Kolumba z 1493 roku został sprzedany za prawie 4 mln dolarów przez nowojorski dom aukcyjny Christie's - poinformowała w piątek włoska telewizja Rai News.</p>

## "Lech Kaczyński" ostatni? Flota Orlenu wraca do nie PiS-owskich nazw
 - [https://www.bankier.pl/wiadomosc/Lech-Kaczynski-ostatni-Flota-Orlenu-wraca-do-nie-PiS-owych-nazw-8633087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lech-Kaczynski-ostatni-Flota-Orlenu-wraca-do-nie-PiS-owych-nazw-8633087.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/e/596a7e9b9b2064-948-568-193-33-1497-898.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Lech Kaczyński" i "Grażyna Gęsicka" - tak nazywają się statki do przewozu LNG. Otrzymały one imiona polityków PiS, którzy zginęli w katastrofie smoleńskiej. Teraz Orlen zapowiada odejście od tej praktyki, bo poinformował o kolejnych nazwach.</p>

## Piotr Duda (Solidarność) o dobrowolnym ZUS-ie: to niedopuszczalne
 - [https://www.bankier.pl/wiadomosc/Piotr-Duda-Solidarnosc-o-dobrowolnym-ZUS-ie-to-niedopuszczalne-8633117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Piotr-Duda-Solidarnosc-o-dobrowolnym-ZUS-ie-to-niedopuszczalne-8633117.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T13:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/61fadd7873e0d9-948-568-0-54-1154-692.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />„Solidarność” będzie broniła programów socjalnych. Zobaczymy jak sytuacja polityczna w kraju się rozwinie, od tego uzależnimy nasze działania, czy będzie to przy stole negocjacji, czy będzie to ulica - powiedział PAP w piątek przewodniczący NSZZ Solidarność Piotr Duda.</p>

## Kiedy pierwsze posiedzenie Sejmu nowej kadencji? Szef Gabinetu Prezydenta wskazuje datę
 - [https://www.bankier.pl/wiadomosc/Kiedy-pierwsze-posiedzenie-Sejmu-nowej-kadencji-Szef-Gabinetu-Prezydenta-wskazuje-date-8633100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kiedy-pierwsze-posiedzenie-Sejmu-nowej-kadencji-Szef-Gabinetu-Prezydenta-wskazuje-date-8633100.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T13:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/8/768135a12c708a-948-568-0-44-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wszystkie okoliczności wskazują na to, że pierwsze posiedzenie Sejmu nowej kadencji odbędzie się 13 lub 14 listopada - powiedział w piątek w rozmowie z TVN24 szef Gabinetu Prezydenta Paweł Szrot. Jak podkreślił, nic nie będzie "przeciągane" ponad to, co wyznacza prawo.</p>

## Amazon przysyła do Włoch pierwsze drony, które mają dostarczać paczki do klientów
 - [https://www.bankier.pl/wiadomosc/Amazon-przysyla-do-Wloch-pierwsze-drony-ktore-maja-dostarczac-paczki-do-klientow-8633079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amazon-przysyla-do-Wloch-pierwsze-drony-ktore-maja-dostarczac-paczki-do-klientow-8633079.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T12:35:49.453146+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/9e42438536722b-945-567-0-0-2230-1338.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W przyszłym roku sklep internetowy Amazon rozpocznie dostarczanie klientom we Włoszech i Wielkiej Brytanii paczek przy pomocy dronów. Do Italii trafiają właśnie pierwsze modele specjalnych bezzałogowców – poinformowała włoska agencja informacyjna Ansa.</p>

## NBP znów dokupił złota. Potwierdziły się wcześniejsze wyliczenia Bankier.pl
 - [https://www.bankier.pl/wiadomosc/NBP-znow-dokupil-zlota-Potwierdzily-sie-wczesniejsze-wyliczenia-Bankier-pl-8633091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-znow-dokupil-zlota-Potwierdzily-sie-wczesniejsze-wyliczenia-Bankier-pl-8633091.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T12:35:49.446828+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/b/ad5269171406eb-948-568-0-9-1200-719.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NBP zwiększył we wrześniu zasoby złota - poinformował
 bank centralny, potwierdzając tym samym wczesniejsze wyliczenia 
Krzysztofa Kolanego, głównego analityka Bankier.pl.   </p>

## Tym będą żyły rynki: wyborów i wyników ciąg dalszy
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-wyborow-i-wynikow-ciag-dalszy-8633053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-wyborow-i-wynikow-ciag-dalszy-8633053.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T12:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/8/009f7af0146bdf-948-568-0-52-1737-1042.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na rynkach akcji wejdziemy w najgorętszą część sezonu
publikacji wyników za III kwartał. Oczywiście dotyczy to głównie giełd w USA i
Europie a nie GPW.</p>

## Kosiniak-Kamysz: Chcemy stworzyć rząd, który utworzą formacje, będące do tej pory w opozycji
 - [https://www.bankier.pl/wiadomosc/Kosiniak-Kamysz-Chcemy-stworzyc-rzad-ktory-utworza-formacje-bedace-do-tej-pory-w-opozycji-8633029.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kosiniak-Kamysz-Chcemy-stworzyc-rzad-ktory-utworza-formacje-bedace-do-tej-pory-w-opozycji-8633029.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T11:34:46.908087+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/9/e96ab6faf3fa24-948-568-0-28-1019-611.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Mamy jeden cel - stworzyć rząd, który utworzą formacje paktu senackiego, formacje demokratyczne, które do tej pory były w opozycji - powiedział w piątek w Tarnowie szef PSL Władysław Kosiniak-Kamysz.</p>

## To już nie science fiction. Pierwszy kraj wprowadza latające taksówki
 - [https://www.bankier.pl/wiadomosc/To-juz-nie-science-fiction-Pierwszy-kraj-wprowadza-latajace-taksowki-8633018.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/To-juz-nie-science-fiction-Pierwszy-kraj-wprowadza-latajace-taksowki-8633018.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T11:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/0/04337b6eeab4a0-948-568-135-57-1070-642.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiele wskazuje na to, że latające taksówki będzie można podziwiać już nie tylko w filmach science fiction, ale już za chwilę staną się codziennością. Pierwsza firma otrzymała zielone światło do komercyjnych lotów w dwóch prowincjach w Chinach – informuje Business Insider.
 </p>

## Duda: Mają szczęście, że jestem prezydentem. To zapowiedź "wiecznego" veto?
 - [https://www.bankier.pl/wiadomosc/Duda-Maja-szczescie-ze-jestem-prezydentem-To-zapowiedz-wiecznego-veto-8633011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Duda-Maja-szczescie-ze-jestem-prezydentem-To-zapowiedz-wiecznego-veto-8633011.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T11:23:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/8bd41c41827c8d-948-568-0-0-2000-1200.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Będę pytał przedstawicieli komitetów wyborczych o potencjalnych kandydatów na premiera, o plany na przyszłość i politykę gospodarczą, energetyczną oraz obronności - zapowiedział w wywiadzie dla "Tygodnika Solidarność" prezydent Andrzej Duda.</p>

## MF widzi konieczność szybkiej nowelizacji przepisów dotyczących ASI
 - [https://www.bankier.pl/wiadomosc/MF-widzi-koniecznosc-szybkiej-nowelizacji-przepisow-dotyczacych-ASI-Szwarc-8633009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/MF-widzi-koniecznosc-szybkiej-nowelizacji-przepisow-dotyczacych-ASI-Szwarc-8633009.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T11:22:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/6c91cfdb73b2d4-948-568-0-670-3316-1990.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo finansów widzi konieczność jak najszybszej nowelizacji przepisów dotyczących alternatywnych spółek inwestycyjnych (ASI) - poinformowała PAP Biznes pełnomocniczka ministra finansów ds. Strategii Rozwoju Rynku Kapitałowego Katarzyna Szwarc.</p>

## Bank Pocztowy: wrześniowe dane o sprzedaży detalicznej lepsze od oczekiwań
 - [https://www.bankier.pl/wiadomosc/Bank-Pocztowy-wrzesniowe-dane-o-sprzedazy-detalicznej-lepsze-od-oczekiwan-8632987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bank-Pocztowy-wrzesniowe-dane-o-sprzedazy-detalicznej-lepsze-od-oczekiwan-8632987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T10:24:05.412020+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/0bfc712f1f6b3d-945-567-35-245-3465-2082.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ujęciu realnym sprzedaży detalicznej widać poprawę, spadła ona we wrześniu o 0,3 proc. rdr, czyli najmniej w tym roku - wskazała w komentarzu do danych GUS Monika Kurtek z Banku Pocztowego. Jej zdaniem dane okazały się lepsze od oczekiwań rynkowych.</p>

## Rezygnacja w Orlenie. Czy zacznie się lawina odejść ze spółek Skarbu Państwa?
 - [https://www.bankier.pl/wiadomosc/Rezygnacje-w-Orlenie-Czy-zacznie-sie-lawina-odejsc-ze-spolek-Skarbu-Panstwa-8632971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rezygnacje-w-Orlenie-Czy-zacznie-sie-lawina-odejsc-ze-spolek-Skarbu-Panstwa-8632971.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T10:24:05.407465+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/e/5a5668b10eb939-948-568-510-884-1862-1117.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć to prezes Daniel Obajtek obiecał dymisję, jeśli opozycja dojdzie do władzy, to już sypią się pierwsze rezygnacje jego współpracowników. Z fotela w radzie nadzorczej spółki zrezygnował Michał Klimaszewski.</p>

## Koniec wyborczej promocji. Ceny paliw ruszyły w górę
 - [https://www.bankier.pl/wiadomosc/Koniec-wyborczej-promocji-Ceny-paliw-ruszyly-w-gore-8632986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Koniec-wyborczej-promocji-Ceny-paliw-ruszyly-w-gore-8632986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T10:24:05.404544+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/6/e5c10af98150ef-948-568-0-0-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />„Promocyjne” ceny paliw w
Polsce zdołały
utrzymać się tylko do wyborów parlamentarnych. I od tego czasu zaczęły
rosnąć, co było raczej trudne do uniknięcia.</p>

## Software Mansion zadebiutowało na NewConnect; kurs wzrósł o 43 proc.
 - [https://www.bankier.pl/wiadomosc/Software-Mansion-zadebiutowalo-na-NewConnect-kurs-wzrosl-o-43-proc-8632950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Software-Mansion-zadebiutowalo-na-NewConnect-kurs-wzrosl-o-43-proc-8632950.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T10:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/6/e025ec47654d79-830-498-0-0-830-498.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Software Mansion zadebiutowało w piątek na NewConnect, kurs akcji spółki na otwarciu w pierwszym dniu notowań wzrósł o 43 proc. do 25,5 zł.</p>

## Ziobro o zakazie dla aut spalinowych. Twierdzi, że Polsce grozi "wielka katastrofa, armageddon"
 - [https://www.bankier.pl/wiadomosc/Ziobro-o-zakazie-dla-aut-spalinowych-Twierdzi-ze-Polsce-grozi-wielka-katastrofa-armageddon-8632946.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ziobro-o-zakazie-dla-aut-spalinowych-Twierdzi-ze-Polsce-grozi-wielka-katastrofa-armageddon-8632946.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T10:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/8/14ab076f363b2d-948-568-8-0-3342-2005.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Podjąłem decyzję, aby skierować wniosek do Trybunału Konstytucyjnego, aby dokonał oceny, czy rozporządzenie Rady UE i PE ws. redukcji emisji CO2 w przypadku nowych pojazdów po 2035 r. jest zgodne z polską konstytucją - powiedział w piątek minister sprawiedliwości Zbigniew Ziobro.</p>

## Przedstawicielka szkoły z 7400 zarzutami. Odpowie za wyłudzanie dotacji
 - [https://www.bankier.pl/wiadomosc/Przedstawicielka-szkoly-z-7400-zarzutami-Odpowie-za-wyludzanie-dotacji-8632941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przedstawicielka-szkoly-z-7400-zarzutami-Odpowie-za-wyludzanie-dotacji-8632941.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T09:56:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/5/095c94d48cd942-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie 7400 zarzutów oszustwa usłyszała przedstawicielka prywatnej szkoły wieczorowej z Sosnowca. Kobieta przedstawiała niezgodne z prawdą dokumenty, na podstawie których jej placówka otrzymała w sumie blisko 4,5 mln zł gminnego dofinansowania - podała policja.</p>

## Kurs euro będzie zmierzał ku 4,50 zł? Zadecyduje zagranica
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-bedzie-zmierzal-ku-4-50-zl-Zadecyduje-zagranica-8632942.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-bedzie-zmierzal-ku-4-50-zl-Zadecyduje-zagranica-8632942.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T09:19:03.553405+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/11010b3f75f6ff-948-568-0-428-4037-2422.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Z powyborczego rajdu złotego powoli zaczęło uchodzić
powietrze. Analitycy spekulują, że kurs
euro może w najbliższym czasie powrócić w pobliże poziomu 4,50 zł.</p>

## "Rząd już musi ciąć wydatki". Borys przyznaje się do katastrofy budżetowej?
 - [https://www.bankier.pl/wiadomosc/Rzad-juz-musi-ciac-wydatki-Borys-przyznaje-sie-do-katastrofy-budzetowej-8632875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzad-juz-musi-ciac-wydatki-Borys-przyznaje-sie-do-katastrofy-budzetowej-8632875.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T09:19:03.550741+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/6/881f8d706fed27-948-568-30-15-2692-1615.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tuż po wyborach, co nomen omen ze względu na liczby, nie jest zaskoczeniem, poznaliśmy dane odnośnie do deficytu budżetowego, określonego przez opozycję mianem "dziury Morawieckiego". Zdaniem ekspertów bez cięcia wydatków nie będzie możliwe zamknięcie budżetu. Co więcej, musi to zacząć robić obecny rząd. </p>

## Największe banki z Wall Street tną zatrudnienie. Jest tylko jeden wyjątek
 - [https://www.bankier.pl/wiadomosc/Goldman-Sachs-Wells-Fargo-i-Citigroup-zwalniaja-na-potege-Wyjatkiem-JP-Morgan-8620987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Goldman-Sachs-Wells-Fargo-i-Citigroup-zwalniaja-na-potege-Wyjatkiem-JP-Morgan-8620987.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T09:19:03.549353+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/6caa11ea31587d-945-560-195-63-1301-780.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć amerykański rynek pracy trzyma się mocno, to od ponad roku trwają potężne zwolnienia w IT. Po cichu zwalniają też największe banki w USA, a najgorsze ma dopiero nadejść.</p>

## Coś drgnęło w handlu. Sprzedaż detaliczna już tylko z niewielkim minusem
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-detaliczna-w-Polsce-wrzesien-2023-8632905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-detaliczna-w-Polsce-wrzesien-2023-8632905.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T09:13:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/7/2470d1a2d75bae-948-568-566-35-2976-1785.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wrześniowe wyniki sprzedaży detalicznej, choć wciąż były
niższe niż rok temu, to równocześnie spadek był najsłabszy od stycznia.</p>

## Estonia chce w ramach sankcji wprowadzenia pełnego zakazu handlu z Rosją
 - [https://www.bankier.pl/wiadomosc/Estonia-chce-w-ramach-sankcji-wprowadzenia-pelnego-zakazu-handlu-z-Rosja-8632890.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Estonia-chce-w-ramach-sankcji-wprowadzenia-pelnego-zakazu-handlu-z-Rosja-8632890.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T08:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/fa06255148f33a-948-567-0-49-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Estonia zabiega o wprowadzenie w nowym pakiecie sankcji Unii Europejskiej pełnego zakazu handlu z Rosją - powiedział Erki Kodar, zastępca sekretarza generalnego ds. prawnych i konsularnych w estońskim ministerstwie spraw zagranicznych.</p>

## Izraelski szekel najsłabszy od lat
 - [https://www.bankier.pl/wiadomosc/Izraelski-szekel-najslabszy-od-lat-8632876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Izraelski-szekel-najslabszy-od-lat-8632876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T08:14:05.460178+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/0/0c5b678bb53643-945-567-26-11-1473-884.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jedną z ofiar wojny w Strefie Gazy okazała się waluta Izraela.
Kurs szekla do dolara osiągnął najsłabsze poziomy od 2015 roku.</p>

## Pół miliona gospodarstw domowych bez dostępu do TVP? Dopłat nie przewidziano
 - [https://www.bankier.pl/wiadomosc/Pol-miliona-gospodarstw-domowych-bez-dostepu-do-TVP-Doplat-nie-przewidziano-8632874.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pol-miliona-gospodarstw-domowych-bez-dostepu-do-TVP-Doplat-nie-przewidziano-8632874.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T08:14:05.457029+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/4/cb1e1364f3d532-948-568-0-69-1985-1190.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ubiegłym roku miała miejsce zmiana standardu nadawania telewizji do DVB-T2/HEVC. Nieliczne stacje nadają jeszcze w starym standardzie, a po zmianach nawet pół miliona gospodarstw domowych może stracić dostęp do TVP1, TVP2, TVP3, TVP Info, TVP Sport, TVP Historia. Ministerstwo Cyfryzacji informuje z kolei, że nie jest przewidziane żadne dofinansowanie do dekodera lub telewizora.</p>

## Aplikacja e-Paragony 2.0 z falstartem. "Wydrukuje" paragony dopiero za kilka miesięcy
 - [https://www.bankier.pl/wiadomosc/Aplikacja-e-Paragony-2-0-z-falstartem-Wydrukuje-paragony-dopiero-za-kilka-miesiecy-8632864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Aplikacja-e-Paragony-2-0-z-falstartem-Wydrukuje-paragony-dopiero-za-kilka-miesiecy-8632864.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:58:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/b/bc319874c54492-948-568-15-195-2992-1795.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć aplikacja e-Paragony 2.0 działa już od ponad miesiąca, to wciąż nie pozwala ona na pobieranie elektronicznych paragonów. Problemem jest brak odpowiednich kas. Może się to zmienić dopiero za kilka miesięcy – informuje Business Insider.</p>

## Domański: Pieniądze na realizację programu KO są i będą. Świadczenia będą utrzymane
 - [https://www.bankier.pl/wiadomosc/Domanski-Pieniadze-na-realizacje-programu-KO-sa-i-beda-Swiadczenia-beda-utrzymane-8632835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Domanski-Pieniadze-na-realizacje-programu-KO-sa-i-beda-Swiadczenia-beda-utrzymane-8632835.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:09:26.456876+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/54902636675cbb-948-568-33-3-1248-749.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wykonanie budżetu jest słabe, ale pieniądze na programy zapowiadane w trakcie kampanii przez Koalicję Obywatelską są i będą - poinformował w Radiu Zet poseł elekt i współtwórca programu PO Andrzej Domański. Jak wskazał, obecne programy społeczne zostaną utrzymane.</p>

## Leszczyna: Musimy wprowadzić autopoprawką do budżetu pierwsze nasze konkrety
 - [https://www.bankier.pl/wiadomosc/Leszczyna-Musimy-wprowadzic-autopoprawka-do-budzetu-pierwsze-nasze-konkrety-8632850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Leszczyna-Musimy-wprowadzic-autopoprawka-do-budzetu-pierwsze-nasze-konkrety-8632850.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:09:26.456361+00:00

<p>Musimy wprowadzić autopoprawką do budżetu pierwsze nasze konkrety; to jest podwyżka dla nauczycieli i kwota wolna – powiedziała w piątek w TVN24 wiceprzewodnicząca Platformy Obywatelskiej Izabela Leszczyna. Dzień po utworzeniu nowego rządu jesteśmy w stanie zdjąć blokadę z KPO - dodała.</p>

## Tak Polacy łatają dziury w budżecie. Wrześniowy wzrost liczby nowych pożyczek
 - [https://www.bankier.pl/wiadomosc/Tak-Polacy-lataja-dziury-w-budzecie-Wrzesniowy-wzrost-liczby-nowych-pozyczek-8632846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-Polacy-lataja-dziury-w-budzecie-Wrzesniowy-wzrost-liczby-nowych-pozyczek-8632846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:09:26.455336+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/7/8901fcdeabef27-945-560-0-80-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firmy pożyczkowe udzieliły we wrześniu br. o niemal 253 proc. więcej nowych pożyczek wobec września 2022 r., a ich wartość zwiększyła się o 71 proc., do 1,325 mld zł - poinformowało w piątek Biuro Informacji Kredytowej (BIK). Średnia wartość pożyczki gotówkowej to 2319 zł.</p>

## W poniedziałek spotkanie opozycji ws. wspólnego oświadczenia
 - [https://www.bankier.pl/wiadomosc/W-poniedzialek-spotkanie-opozycji-ws-wspolnego-oswiadczenia-8632843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-poniedzialek-spotkanie-opozycji-ws-wspolnego-oswiadczenia-8632843.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:09:26.454819+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/ac76eed5321294-945-560-76-343-983-589.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W poniedziałek liderzy partii opozycyjnych spotkają się w celu wydania wspólnego oświadczenia; wtedy będzie już zupełnie jasne, że jedyna koalicja, która jest w stanie rządzić w Polsce po tych wyborach, to koalicja KO, Lewicy i Trzeciej Drogi - powiedziała w piątek w RMF FM posłanka Katarzyna Lubnauer (KO).</p>

## 55 nowych niszczarek tylko dla ABW. Opozycja bije na alarm, rząd odpowiada
 - [https://www.bankier.pl/wiadomosc/55-nowych-niszczarek-tylko-dla-ABW-Opozycja-bije-na-alarm-8632829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/55-nowych-niszczarek-tylko-dla-ABW-Opozycja-bije-na-alarm-8632829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T07:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/2/99c1850f9ca8bb-948-568-97-247-2650-1589.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />55 niszczarek dostarczonych nie później niż 15 grudnia - takie zamówienie publiczne pojawiło się na stronach Agencji Bezpieczeństwa Wewnętrznego. Jak alarmuje opozycja, to tylko czubek góry lodowej i trwa niszczenie akt w trybie przyspieszonym. "Sceny jak z filmu Psy" - kwituje poseł PO Michał Szczerba.</p>

## Warren Buffet też miewa wpadki. Komputery nie dały zarobić
 - [https://www.bankier.pl/wiadomosc/Warren-Buffet-tez-miewa-wpadki-Komputery-nie-daly-zarobic-8632816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Warren-Buffet-tez-miewa-wpadki-Komputery-nie-daly-zarobic-8632816.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T06:42:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/0/5c8177f251c68e-948-568-0-14-1124-674.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Warren Buffet, "wyrocznia z Omaha", to wzór do naśladowania przez wielu inwestorów. Jednak miliarderowi też zdarzają się potknięcia i stratne transakcje.</p>

## Rzecznik Finansowy ma zastrzeżenia dot. działań Pekao. Zwrócił się do UOKiK
 - [https://www.bankier.pl/wiadomosc/Rzecznik-Finansowy-ma-zastrzezenia-dot-dzialan-Pekao-zwrocil-sie-do-UOKiK-8632801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Rzecznik-Finansowy-ma-zastrzezenia-dot-dzialan-Pekao-zwrocil-sie-do-UOKiK-8632801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T06:03:46.528181+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/d8799b46b313f9-948-568-0-158-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rzecznik Finansowy skierował pismo do Prezesa UOKiK, w którym poinformował o  możliwych nieprawidłowościach w działaniach Banku Pekao oraz Pekao Banku Hipotecznego i zwrócił się o zbadanie sprawy pod kątem potencjalnego stosowania praktyk naruszających zbiorowe interesy konsumentów - podała instytucja w komunikacie.</p>

## Posypią się mandaty za jazdę rowerami czy hulajnogami. Wlepią je strażnicy miejscy
 - [https://www.bankier.pl/wiadomosc/Posypia-sie-mandaty-za-jazde-rowerami-czy-hulajnogami-Wlepia-je-straznicy-miejscy-8632789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Posypia-sie-mandaty-za-jazde-rowerami-czy-hulajnogami-Wlepia-je-straznicy-miejscy-8632789.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T06:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/e/dd4f713d54c6f0-945-560-22-236-4387-2632.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Strażnicy miejscy będą mogli ukarać mandatem w wysokości do 200 zł osoby jeżdżące rowerem czy hulajnogą bez uprawnień. Z kolei sąd może ukarać sprawcę tego wykroczenia grzywną do 1500 zł. I to już od piątku, 20 października.</p>

## Silversi mają pod górkę na polskim rynku pracy. Niewykorzystany potencjał
 - [https://www.bankier.pl/wiadomosc/Silversi-maja-pod-gorke-na-polskim-rynku-pracy-Niewykorzystany-potencjal-8632785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Silversi-maja-pod-gorke-na-polskim-rynku-pracy-Niewykorzystany-potencjal-8632785.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T06:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/f/8d83d14841d8bf-948-568-0-277-997-598.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prawie co piąty pracownik w grupie wiekowej 55-65 lat doświadczył dyskryminacji ze względu na wiek w miejscu pracy, tj. problemy z awansem, niechęć zatrudnienia czy gorsze warunki pracy. Niewiele niższy odsetek doświadczył...</p>

## Masz profil zaufany? Niedługo możesz stracić dostęp do niego i wielu funkcji
 - [https://www.bankier.pl/wiadomosc/Masz-profil-zaufany-Niedlugo-mozesz-stracic-dostep-do-niego-i-wielu-funkcji-8632360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Masz-profil-zaufany-Niedlugo-mozesz-stracic-dostep-do-niego-i-wielu-funkcji-8632360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T04:58:45.905396+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/9357bed8faee46-948-568-19-58-3906-2343.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo Cyfryzacji w komunikacie poinformowało, że 31 października wygasną profile zaufane o ważności automatycznie przedłużonej podczas pandemii. Zmiany mogą dotknąć wielu użytkowników, więc warto sprawdzić, czy nie znajdujesz się na tej liście.
</p>

## Dziennikarze TVP stracą pracę? "Nie pokazujemy się i liczymy na cud"
 - [https://www.bankier.pl/wiadomosc/Dziennikarze-TVP-straca-prace-Nie-pokazujemy-sie-i-liczymy-na-cud-8632444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Dziennikarze-TVP-straca-prace-Nie-pokazujemy-sie-i-liczymy-na-cud-8632444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T04:58:45.904871+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/7800490c40d29b-948-568-22-60-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wiele wskazuje na to, że po wyborach parlamentarnych dojdzie do zmiany władzy. To może wpłynąć również na działalność nadawcy publicznego. Dziennikarze tam pracujący opowiedzieli portalowi Wirtualne Media, jaka atmosfera panuje obecnie w TVP.</p>

## Wrocław liderem w rozwoju nowoczesnych technologii i AI? Wszystko na dobrej drodze
 - [https://www.bankier.pl/wiadomosc/Wroclaw-liderem-w-rozwoju-nowoczesnych-technologii-i-AI-Wszystko-na-dobrej-drodze-8632540.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wroclaw-liderem-w-rozwoju-nowoczesnych-technologii-i-AI-Wszystko-na-dobrej-drodze-8632540.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T04:58:45.904338+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/3/4ffa4859b44551-948-568-69-176-1093-655.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Miasto, w którym jest
najwięcej startupów w Polsce, tworzone są najnowsze technologie, również
kosmiczne, a Intel wybiera je na miejsce swojej inwestycji. To właśnie Wrocław
jest miejscem, które coraz częściej jest nazywane polską Doliną Krzemową. </p>

## Polski system emerytalny w ogonie Europy. Co trzeba poprawić?
 - [https://www.bankier.pl/wiadomosc/Polski-system-emerytalny-w-ogonie-Europy-Co-trzeba-poprawic-8632476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polski-system-emerytalny-w-ogonie-Europy-Co-trzeba-poprawic-8632476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T04:58:45.903783+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/9/9394ab9936f27e-948-568-0-115-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polski system emerytalny znów spadł w najnowszym zestawieniu porównującym inne rozwiązania z blisko 50 krajów świata. Co prawda jesteśmy wyżej od Japonii czy Włoch, ale ustępujemy takim krajom jak choćby Kazachstan, Kolumbia czy kraje arabskie.</p>

## W Finlandii Rosjanom coraz trudniej kupić nieruchomości
 - [https://www.bankier.pl/wiadomosc/W-Finlandii-Rosjanom-coraz-trudniej-kupic-nieruchomosci-8632750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/W-Finlandii-Rosjanom-coraz-trudniej-kupic-nieruchomosci-8632750.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T02:41:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/b/8b99595b30520f-948-568-21-220-4179-2507.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Fińskie ministerstwo obrony poinformowało w czwartek o zablokowaniu trzech transakcji sprzedaży atrakcyjnych nieruchomości w ośrodkach wypoczynkowych w fińskiej Karelii. Dwie z nich chciał nabyć znany na wschodzie kraju biznesmen z Petersburga. Pozwolenia na zakup nie otrzymał także nabywca mający podwójne - rosyjskie oraz izraelskie obywatelstwo.</p>

## Biden: Putin już zagroził Polsce, że jej zachodnie ziemie są "darem" od Rosji
 - [https://www.bankier.pl/wiadomosc/Biden-Putin-juz-zagrozil-Polsce-ze-jej-zachodnie-ziemie-sa-darem-od-Rosji-8632748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Biden-Putin-juz-zagrozil-Polsce-ze-jej-zachodnie-ziemie-sa-darem-od-Rosji-8632748.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-20T02:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/4/55fad114a4a178-948-568-24-49-3244-1946.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Jeśli nie powstrzymamy Putina, nie zatrzyma się na Ukrainie. Już zagroził i "przypomniał" Polsce, że jej zachodnie ziemie są "darem" od Rosji - powiedział prezydent USA Joe Biden w orędziu do narodu na temat konieczności dalszej pomocy Ukrainie i Izraelowi. Zapowiedział, że w piątek zwróci się do Kongresu o znaczący pakiet środków dla obu państw.</p>

