# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Australians Warned Not to Visit Lebanon
 - [https://www.theepochtimes.com/world/australians-warned-not-to-visit-lebanon-5513739](https://www.theepochtimes.com/world/australians-warned-not-to-visit-lebanon-5513739)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T01:41:40+00:00

Protesters try to remove barbed wires that block a road leading to the U.S. embassy, during a demonstration in Beirut, Lebanon, on Oct. 18, 2023. (AP Photo/Bilal Hussein)

## Australian Senate Backs Royal Commission Investigation into COVID-19 Response
 - [https://www.theepochtimes.com/world/australian-senate-backs-royal-commission-investigation-into-covid-19-response-5513156](https://www.theepochtimes.com/world/australian-senate-backs-royal-commission-investigation-into-covid-19-response-5513156)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T01:30:43+00:00

A protestor holds up a sign during rallies against government-mandated health restrictions and impending Pandemic legislation in Melbourne, Australia, on Nov. 2, 2021. (Supplied)

## Biden Calls for Support for Israel, Ukraine in Oval Office Address
 - [https://www.theepochtimes.com/us/biden-calls-for-support-for-israel-ukraine-in-oval-office-address-5513728](https://www.theepochtimes.com/us/biden-calls-for-support-for-israel-ukraine-in-oval-office-address-5513728)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T01:09:25+00:00

President Joe Biden addresses the nation from the Oval Office of the White House in Washington on Oct. 19, 2023. (Jonathan Ernst - Pool/Getty Images)

## Live View From Southern Israel Towards Gaza (Oct. 20)
 - [https://www.theepochtimes.com/epochtv/live-view-from-southern-israel-towards-gaza-oct-20-post-5513718](https://www.theepochtimes.com/epochtv/live-view-from-southern-israel-towards-gaza-oct-20-post-5513718)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T00:53:52+00:00

Smoke in the Gaza Strip as seen from Israel's border with the Gaza Strip, in southern Israel, on Oct. 18, 2023. (Amir Cohen/Reuters)

## Fijian PM Proposes Pacific ‘Peace Zone’ Amid Beijing Aggression
 - [https://www.theepochtimes.com/world/fijian-pm-proposes-pacific-peace-zone-amid-beijing-aggression-5513137](https://www.theepochtimes.com/world/fijian-pm-proposes-pacific-peace-zone-amid-beijing-aggression-5513137)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T00:44:57+00:00

People's Alliance Party leader Sitiveni Rabuka gestures during a press conference while counting resumes after the Fijian election in Suva, Fiji, on Dec. 17, 2022. (Mick Tsikas/AAP Image via AP)

## LIVE 9 AM ET: Live View of Tel Aviv Skyline as the Cross Border Counter-Terrorist War Continues
 - [https://www.theepochtimes.com/epochtv/live-view-of-tel-aviv-skyline-as-the-cross-border-counter-terrorist-war-continues-5513698](https://www.theepochtimes.com/epochtv/live-view-of-tel-aviv-skyline-as-the-cross-border-counter-terrorist-war-continues-5513698)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-20T00:23:46+00:00

Keren Schem, mother of Mia Schem—who was kidnapped in Israel by Hamas terrorists on Oct. 7—at a press conference in Tel Aviv, Israel, on Oct. 17, 2023. (Ohad Zwigenberg/AP Photo)

