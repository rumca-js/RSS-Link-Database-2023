# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## Greta Thunberg Stands With....Palestine
 - [https://www.youtube.com/watch?v=kXz_pRkeyoQ](https://www.youtube.com/watch?v=kXz_pRkeyoQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T23:00:22+00:00

Greta Thunberg took to Twitter to proclaim that she stands with Palestine and Gaza, and in doing so, continues to prove that she has absolutely no idea what she's talking about. People need to quit paying attention to her.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1833 - https://youtu.be/rN9qEIvWWqw

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Take the first step toward resolving your tax debt!
http://www.TaxNetworkUSA.com/Shapiro 

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #GretaThunberg #Thunberg #Greta #Gaza #Twitter #Palestine #MiddleEast #Israel #WokeActivists #Woke

## Biden Is Garbling the Message
 - [https://www.youtube.com/watch?v=pJd83GNv7_0](https://www.youtube.com/watch?v=pJd83GNv7_0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T21:30:04+00:00



## There Is No Peace Process
 - [https://www.youtube.com/watch?v=QjuiizjfKt8](https://www.youtube.com/watch?v=QjuiizjfKt8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T21:00:12+00:00

During Biden's Oval Office address intended to back Israel against terrorism, he unexpectedly shifted the focus to the "peace process," seemingly backing the actions of Palestine. Why is Biden not addressing Gaza's support for Hamas?

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1833 - https://youtu.be/rN9qEIvWWqw

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Exclusive discount for my listeners!
https://genucel.com/Shapiro 

Try Hallow for 3 months FREE: https://hallow.com/shaprio

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #Biden #JoeBiden #OvalOffice #OvalOfficeAddress #BidenSpeech #PresidentBiden #Gaza #Israel #HumanitarianAid #MiddleEast

## Pro-Palestine Protests at the Capital
 - [https://www.youtube.com/watch?v=ZBuL0HIqs4Y](https://www.youtube.com/watch?v=ZBuL0HIqs4Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T19:00:16+00:00



## Will Biden’s Weakness Blow Up The World?
 - [https://www.youtube.com/watch?v=rN9qEIvWWqw](https://www.youtube.com/watch?v=rN9qEIvWWqw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T17:00:09+00:00

Joe Biden gives a scattershot Oval Office address linking aid to Israel with aid to Ukraine; the Middle East waits to see whether Biden is bluffing; and State Department staff protest against support for Israel.

International Fellowship of Christians & Jews: http://IFCJ.org

Friends of Israel Defense Forces (FIDF): http://FIDF.org 

Israel Rescue: http://IsraelRescue.org

American Friends of Magen David Adom: http://Afmda.org

The Ari Fuld Project: http://AriFuld.org

Ep.1833

- - -

1️⃣  Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣ Check out Bentkey here: https://bit.ly/46NTTVo

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Hallow - Try Hallow for 3 months FREE: https://hallow.com/shapiro

Tax Network - Take the first step toward resolving your tax debt!
http://www.TaxNetworkUSA.com/Shapiro 

Genucel - Exclusive discount for my liste

## Ben Obliterates a Pro-Puberty Blocker Student |  @YAFTV
 - [https://www.youtube.com/watch?v=04fB8pRHFEI](https://www.youtube.com/watch?v=04fB8pRHFEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-10-20T01:00:00+00:00



