# Source:Hacker News - frontpage, URL:https://hnrss.org/frontpage, language:en-US

## Cloudflare mitigated yet another Okta compromise
 - [https://blog.cloudflare.com/how-cloudflare-mitigated-yet-another-okta-compromise/](https://blog.cloudflare.com/how-cloudflare-mitigated-yet-another-okta-compromise/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T21:39:58+00:00

<p>Article URL: <a href="https://blog.cloudflare.com/how-cloudflare-mitigated-yet-another-okta-compromise/">https://blog.cloudflare.com/how-cloudflare-mitigated-yet-another-okta-compromise/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961860">https://news.ycombinator.com/item?id=37961860</a></p>
<p>Points: 23</p>
<p># Comments: 7</p>

## The unexplainable growing wage gap
 - [https://www.bls.gov/opub/mlr/2017/beyond-bls/the-unexplainable-growing-black-white-wage-gap.htm](https://www.bls.gov/opub/mlr/2017/beyond-bls/the-unexplainable-growing-black-white-wage-gap.htm)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T21:23:10+00:00

<p>Article URL: <a href="https://www.bls.gov/opub/mlr/2017/beyond-bls/the-unexplainable-growing-black-white-wage-gap.htm">https://www.bls.gov/opub/mlr/2017/beyond-bls/the-unexplainable-growing-black-white-wage-gap.htm</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961710">https://news.ycombinator.com/item?id=37961710</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Hetzner does run a (MitM) proxy in front of my server
 - [https://old.reddit.com/r/hetzner/comments/17ccp3i/hetzner_does_run_a_mitm_proxy_in_front_of_my/](https://old.reddit.com/r/hetzner/comments/17ccp3i/hetzner_does_run_a_mitm_proxy_in_front_of_my/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T21:01:04+00:00

<p>Article URL: <a href="https://old.reddit.com/r/hetzner/comments/17ccp3i/hetzner_does_run_a_mitm_proxy_in_front_of_my/">https://old.reddit.com/r/hetzner/comments/17ccp3i/hetzner_does_run_a_mitm_proxy_in_front_of_my/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961464">https://news.ycombinator.com/item?id=37961464</a></p>
<p>Points: 25</p>
<p># Comments: 1</p>

## Emerge (YC W21) is hiring a senior front end engineer (remote, small team)
 - [https://www.emergetools.com/careers/jobs/senior-frontend-engineer](https://www.emergetools.com/careers/jobs/senior-frontend-engineer)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T21:00:12+00:00

<p>Article URL: <a href="https://www.emergetools.com/careers/jobs/senior-frontend-engineer">https://www.emergetools.com/careers/jobs/senior-frontend-engineer</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961453">https://news.ycombinator.com/item?id=37961453</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## How the creator of Alone in the Dark came back to games
 - [https://news.play.date/news/skew/](https://news.play.date/news/skew/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T20:40:00+00:00

<p>Article URL: <a href="https://news.play.date/news/skew/">https://news.play.date/news/skew/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961232">https://news.ycombinator.com/item?id=37961232</a></p>
<p>Points: 13</p>
<p># Comments: 4</p>

## Mitigating the Hetzner/Linode XMPP.ru MitM interception incident
 - [https://www.devever.net/~hl/xmpp-incident](https://www.devever.net/~hl/xmpp-incident)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T20:31:29+00:00

<p>Article URL: <a href="https://www.devever.net/~hl/xmpp-incident">https://www.devever.net/~hl/xmpp-incident</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961166">https://news.ycombinator.com/item?id=37961166</a></p>
<p>Points: 34</p>
<p># Comments: 1</p>

## DMCA Excemptions to "Copyright Protection Systems" Being Reconsidered
 - [https://www.copyright.gov/1201/2024/](https://www.copyright.gov/1201/2024/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T20:17:37+00:00

<p>Article URL: <a href="https://www.copyright.gov/1201/2024/">https://www.copyright.gov/1201/2024/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37961007">https://news.ycombinator.com/item?id=37961007</a></p>
<p>Points: 5</p>
<p># Comments: 1</p>

## Progress on No-GIL CPython
 - [https://lwn.net/Articles/947138/](https://lwn.net/Articles/947138/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T20:10:52+00:00

<p>Article URL: <a href="https://lwn.net/Articles/947138/">https://lwn.net/Articles/947138/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37960941">https://news.ycombinator.com/item?id=37960941</a></p>
<p>Points: 56</p>
<p># Comments: 32</p>

## OpenSSL Adds Support for Raw Public Key (RFC7250)
 - [https://www.openssl.org/blog/blog/2023/10/20/ossl-rpk/](https://www.openssl.org/blog/blog/2023/10/20/ossl-rpk/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T19:47:01+00:00

<p>Article URL: <a href="https://www.openssl.org/blog/blog/2023/10/20/ossl-rpk/">https://www.openssl.org/blog/blog/2023/10/20/ossl-rpk/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37960666">https://news.ycombinator.com/item?id=37960666</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## Windows 11 Pro's On-by-Default Encryption Slows SSDs Up to 45%
 - [https://www.tomshardware.com/news/windows-software-bitlocker-slows-performance](https://www.tomshardware.com/news/windows-software-bitlocker-slows-performance)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T19:21:24+00:00

<p>Article URL: <a href="https://www.tomshardware.com/news/windows-software-bitlocker-slows-performance">https://www.tomshardware.com/news/windows-software-bitlocker-slows-performance</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37960330">https://news.ycombinator.com/item?id=37960330</a></p>
<p>Points: 45</p>
<p># Comments: 36</p>

## Accounting prof testifies about FTX's misuse of customers' money
 - [https://www.coindesk.com/policy/2023/10/18/sbf-trial-a-witness-contrasts-sam-bankman-frieds-house-testimony-with-ftxs-dangerous-secrets/](https://www.coindesk.com/policy/2023/10/18/sbf-trial-a-witness-contrasts-sam-bankman-frieds-house-testimony-with-ftxs-dangerous-secrets/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T19:18:13+00:00

<p>Article URL: <a href="https://www.coindesk.com/policy/2023/10/18/sbf-trial-a-witness-contrasts-sam-bankman-frieds-house-testimony-with-ftxs-dangerous-secrets/">https://www.coindesk.com/policy/2023/10/18/sbf-trial-a-witness-contrasts-sam-bankman-frieds-house-testimony-with-ftxs-dangerous-secrets/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37960289">https://news.ycombinator.com/item?id=37960289</a></p>
<p>Points: 56</p>
<p># Comments: 7</p>

## Why America Is Out of Ammunition
 - [https://www.thebignewsletter.com/p/why-america-is-out-of-ammunition](https://www.thebignewsletter.com/p/why-america-is-out-of-ammunition)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T19:14:12+00:00

<p>Article URL: <a href="https://www.thebignewsletter.com/p/why-america-is-out-of-ammunition">https://www.thebignewsletter.com/p/why-america-is-out-of-ammunition</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37960239">https://news.ycombinator.com/item?id=37960239</a></p>
<p>Points: 29</p>
<p># Comments: 10</p>

## Geany 2.0 Is Out
 - [https://www.geany.org/news/geany-20-is-out/](https://www.geany.org/news/geany-20-is-out/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T18:53:09+00:00

<p>Article URL: <a href="https://www.geany.org/news/geany-20-is-out/">https://www.geany.org/news/geany-20-is-out/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959979">https://news.ycombinator.com/item?id=37959979</a></p>
<p>Points: 15</p>
<p># Comments: 1</p>

## Geany 2.0 – Flyweight IDE
 - [https://geany.org/](https://geany.org/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T18:53:09+00:00

<p>Article URL: <a href="https://geany.org/">https://geany.org/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959979">https://news.ycombinator.com/item?id=37959979</a></p>
<p>Points: 66</p>
<p># Comments: 16</p>

## Leaving the Phone at Home
 - [https://josem.co/leaving-the-phone-at-home/](https://josem.co/leaving-the-phone-at-home/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T18:48:47+00:00

<p>Article URL: <a href="https://josem.co/leaving-the-phone-at-home/">https://josem.co/leaving-the-phone-at-home/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959931">https://news.ycombinator.com/item?id=37959931</a></p>
<p>Points: 11</p>
<p># Comments: 5</p>

## Hackers Stole Access Tokens from Okta's Support Unit
 - [https://krebsonsecurity.com/2023/10/hackers-stole-access-tokens-from-oktas-support-unit/](https://krebsonsecurity.com/2023/10/hackers-stole-access-tokens-from-oktas-support-unit/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T18:46:28+00:00

<p>Article URL: <a href="https://krebsonsecurity.com/2023/10/hackers-stole-access-tokens-from-oktas-support-unit/">https://krebsonsecurity.com/2023/10/hackers-stole-access-tokens-from-oktas-support-unit/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959904">https://news.ycombinator.com/item?id=37959904</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## They can and will ruin everything you love
 - [https://www.welcometohellworld.com/they-can-and-will-ruin-everything-you-love/](https://www.welcometohellworld.com/they-can-and-will-ruin-everything-you-love/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T18:10:50+00:00

<p>Article URL: <a href="https://www.welcometohellworld.com/they-can-and-will-ruin-everything-you-love/">https://www.welcometohellworld.com/they-can-and-will-ruin-everything-you-love/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959540">https://news.ycombinator.com/item?id=37959540</a></p>
<p>Points: 176</p>
<p># Comments: 90</p>

## PowerDNS Starts to Use Rust
 - [https://mailman.powerdns.com/pipermail/pdns-announce/2023-October/001284.html](https://mailman.powerdns.com/pipermail/pdns-announce/2023-October/001284.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T17:57:35+00:00

<p>Article URL: <a href="https://mailman.powerdns.com/pipermail/pdns-announce/2023-October/001284.html">https://mailman.powerdns.com/pipermail/pdns-announce/2023-October/001284.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959376">https://news.ycombinator.com/item?id=37959376</a></p>
<p>Points: 17</p>
<p># Comments: 1</p>

## Implication for C++ [pdf]
 - [https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2023/p2971r1.pdf](https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2023/p2971r1.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T17:54:28+00:00

<p>Article URL: <a href="https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2023/p2971r1.pdf">https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2023/p2971r1.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37959340">https://news.ycombinator.com/item?id=37959340</a></p>
<p>Points: 5</p>
<p># Comments: 0</p>

## Killings in the U.S. are dropping at a historic rate. Will anyone notice?
 - [https://www.latimes.com/politics/newsletter/2023-10-20/killings-in-the-u-s-are-dropping-at-an-historic-rate-will-anyone-notice-essential-politics](https://www.latimes.com/politics/newsletter/2023-10-20/killings-in-the-u-s-are-dropping-at-an-historic-rate-will-anyone-notice-essential-politics)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T17:27:53+00:00

<p>Article URL: <a href="https://www.latimes.com/politics/newsletter/2023-10-20/killings-in-the-u-s-are-dropping-at-an-historic-rate-will-anyone-notice-essential-politics">https://www.latimes.com/politics/newsletter/2023-10-20/killings-in-the-u-s-are-dropping-at-an-historic-rate-will-anyone-notice-essential-politics</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958979">https://news.ycombinator.com/item?id=37958979</a></p>
<p>Points: 6</p>
<p># Comments: 2</p>

## DHS to Propose Amending H-1B, F-1 Regulations
 - [https://www.natlawreview.com/article/dhs-propose-amending-h-1b-f-1-regulations](https://www.natlawreview.com/article/dhs-propose-amending-h-1b-f-1-regulations)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T17:25:16+00:00

<p>Article URL: <a href="https://www.natlawreview.com/article/dhs-propose-amending-h-1b-f-1-regulations">https://www.natlawreview.com/article/dhs-propose-amending-h-1b-f-1-regulations</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958952">https://news.ycombinator.com/item?id=37958952</a></p>
<p>Points: 4</p>
<p># Comments: 2</p>

## EasyPost (YC S13) Is Hiring
 - [https://www.easypost.com/careers](https://www.easypost.com/careers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T17:00:12+00:00

<p>Article URL: <a href="https://www.easypost.com/careers">https://www.easypost.com/careers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958633">https://news.ycombinator.com/item?id=37958633</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Show HN: No Feed? Unlimited Productivity
 - [https://github.com/kwkr/feed-remover](https://github.com/kwkr/feed-remover)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T16:54:04+00:00

<p>Your own browser extension to get rid of unwanted social media feed! 5 minutes to setup, hours saved.</p>
<hr />
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958555">https://news.ycombinator.com/item?id=37958555</a></p>
<p>Points: 13</p>
<p># Comments: 6</p>

## RIP to my 8-port Unifi switch after years and years of Texas outdoor temps
 - [https://arstechnica.com/gadgets/2023/10/saying-goodbye-to-great-hardware-my-8-port-unifi-switch-finally-buys-the-farm/](https://arstechnica.com/gadgets/2023/10/saying-goodbye-to-great-hardware-my-8-port-unifi-switch-finally-buys-the-farm/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T16:31:02+00:00

<p>Article URL: <a href="https://arstechnica.com/gadgets/2023/10/saying-goodbye-to-great-hardware-my-8-port-unifi-switch-finally-buys-the-farm/">https://arstechnica.com/gadgets/2023/10/saying-goodbye-to-great-hardware-my-8-port-unifi-switch-finally-buys-the-farm/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958263">https://news.ycombinator.com/item?id=37958263</a></p>
<p>Points: 9</p>
<p># Comments: 11</p>

## Top Crypto Firms Named in $1B Fraud Lawsuit
 - [https://www.bbc.com/news/business-67161638](https://www.bbc.com/news/business-67161638)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T16:21:20+00:00

<p>Article URL: <a href="https://www.bbc.com/news/business-67161638">https://www.bbc.com/news/business-67161638</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37958143">https://news.ycombinator.com/item?id=37958143</a></p>
<p>Points: 12</p>
<p># Comments: 1</p>

## Brazil police arrest two intel agents for alleged illegal surveillance
 - [https://www.reuters.com/world/americas/brazil-police-arrest-two-intel-agents-alleged-illegal-surveillance-2023-10-20/](https://www.reuters.com/world/americas/brazil-police-arrest-two-intel-agents-alleged-illegal-surveillance-2023-10-20/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T15:44:35+00:00

<p>Article URL: <a href="https://www.reuters.com/world/americas/brazil-police-arrest-two-intel-agents-alleged-illegal-surveillance-2023-10-20/">https://www.reuters.com/world/americas/brazil-police-arrest-two-intel-agents-alleged-illegal-surveillance-2023-10-20/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37957733">https://news.ycombinator.com/item?id=37957733</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

## "<ESC>[31M"? ANSI Terminal security in 2023 and finding 10 CVEs
 - [https://dgl.cx/2023/09/ansi-terminal-security](https://dgl.cx/2023/09/ansi-terminal-security)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T15:22:52+00:00

<p>Article URL: <a href="https://dgl.cx/2023/09/ansi-terminal-security">https://dgl.cx/2023/09/ansi-terminal-security</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37957397">https://news.ycombinator.com/item?id=37957397</a></p>
<p>Points: 64</p>
<p># Comments: 13</p>

## "Useless Ruby sugar": Pattern matching (Pt. 1)
 - [https://zverok.space/blog/2023-10-20-syntax-sugar2-pattern-matching.html](https://zverok.space/blog/2023-10-20-syntax-sugar2-pattern-matching.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T15:08:12+00:00

<p>Article URL: <a href="https://zverok.space/blog/2023-10-20-syntax-sugar2-pattern-matching.html">https://zverok.space/blog/2023-10-20-syntax-sugar2-pattern-matching.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37957189">https://news.ycombinator.com/item?id=37957189</a></p>
<p>Points: 3</p>
<p># Comments: 0</p>

## The ten year anniversary of the Healthcare.gov rescue
 - [https://www.pauladamsmith.com/blog/2023/10/the-10-year-anniversary-of-the-healthcare.gov-rescue.html](https://www.pauladamsmith.com/blog/2023/10/the-10-year-anniversary-of-the-healthcare.gov-rescue.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T15:06:21+00:00

<p>Article URL: <a href="https://www.pauladamsmith.com/blog/2023/10/the-10-year-anniversary-of-the-healthcare.gov-rescue.html">https://www.pauladamsmith.com/blog/2023/10/the-10-year-anniversary-of-the-healthcare.gov-rescue.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37957152">https://news.ycombinator.com/item?id=37957152</a></p>
<p>Points: 29</p>
<p># Comments: 3</p>

## Flappy Bird Implemented in TypeScript Types
 - [https://zackoverflow.dev/writing/flappy-bird-in-type-level-typescript/](https://zackoverflow.dev/writing/flappy-bird-in-type-level-typescript/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T14:47:52+00:00

<p>Article URL: <a href="https://zackoverflow.dev/writing/flappy-bird-in-type-level-typescript/">https://zackoverflow.dev/writing/flappy-bird-in-type-level-typescript/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956856">https://news.ycombinator.com/item?id=37956856</a></p>
<p>Points: 37</p>
<p># Comments: 6</p>

## Eclipse October 2023
 - [https://www.gridstatus.io/dashboards/eclipse-oct-2023](https://www.gridstatus.io/dashboards/eclipse-oct-2023)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T14:44:17+00:00

<p>Article URL: <a href="https://www.gridstatus.io/dashboards/eclipse-oct-2023">https://www.gridstatus.io/dashboards/eclipse-oct-2023</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956816">https://news.ycombinator.com/item?id=37956816</a></p>
<p>Points: 44</p>
<p># Comments: 0</p>

## Ray-Ban Meta smart glasses: a turning point
 - [https://www.theverge.com/23922425/ray-ban-meta-smart-glasses-review](https://www.theverge.com/23922425/ray-ban-meta-smart-glasses-review)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T14:39:34+00:00

<p>Article URL: <a href="https://www.theverge.com/23922425/ray-ban-meta-smart-glasses-review">https://www.theverge.com/23922425/ray-ban-meta-smart-glasses-review</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956747">https://news.ycombinator.com/item?id=37956747</a></p>
<p>Points: 17</p>
<p># Comments: 8</p>

## Cops Are Suing a Teen for Invasion of Privacy After False Arrest Vid Goes Viral
 - [https://www.vice.com/en/article/jg5a88/cops-sue-teen-invasion-of-privacy-false-arrest](https://www.vice.com/en/article/jg5a88/cops-sue-teen-invasion-of-privacy-false-arrest)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T14:37:25+00:00

<p>Article URL: <a href="https://www.vice.com/en/article/jg5a88/cops-sue-teen-invasion-of-privacy-false-arrest">https://www.vice.com/en/article/jg5a88/cops-sue-teen-invasion-of-privacy-false-arrest</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956714">https://news.ycombinator.com/item?id=37956714</a></p>
<p>Points: 241</p>
<p># Comments: 126</p>

## Mathematicians Found 12,000 Solutions to the Notoriously Hard Three-Body Problem
 - [https://www.popularmechanics.com/science/math/a45074216/three-body-problem-solutions/](https://www.popularmechanics.com/science/math/a45074216/three-body-problem-solutions/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T14:17:01+00:00

<p>Article URL: <a href="https://www.popularmechanics.com/science/math/a45074216/three-body-problem-solutions/">https://www.popularmechanics.com/science/math/a45074216/three-body-problem-solutions/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956374">https://news.ycombinator.com/item?id=37956374</a></p>
<p>Points: 27</p>
<p># Comments: 15</p>

## Humming-Birds
 - [https://www.c82.net/work/?id=395](https://www.c82.net/work/?id=395)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T13:58:21+00:00

<p>Article URL: <a href="https://www.c82.net/work/?id=395">https://www.c82.net/work/?id=395</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37956089">https://news.ycombinator.com/item?id=37956089</a></p>
<p>Points: 32</p>
<p># Comments: 2</p>

## AI tidies up Wikipedia's references – and boosts reliability
 - [https://www.nature.com/articles/d41586-023-02894-x](https://www.nature.com/articles/d41586-023-02894-x)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T13:25:52+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-02894-x">https://www.nature.com/articles/d41586-023-02894-x</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955658">https://news.ycombinator.com/item?id=37955658</a></p>
<p>Points: 48</p>
<p># Comments: 12</p>

## Confidential computing and AI fit together
 - [https://www.edgeless.systems/blog/how-confidential-computing-and-ai-fit-together/](https://www.edgeless.systems/blog/how-confidential-computing-and-ai-fit-together/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T13:22:25+00:00

<p>Article URL: <a href="https://www.edgeless.systems/blog/how-confidential-computing-and-ai-fit-together/">https://www.edgeless.systems/blog/how-confidential-computing-and-ai-fit-together/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955620">https://news.ycombinator.com/item?id=37955620</a></p>
<p>Points: 14</p>
<p># Comments: 2</p>

## Versioning data in Postgres? Testing a Git like approach
 - [https://www.specfy.io/blog/7-git-like-versioning-in-postgres](https://www.specfy.io/blog/7-git-like-versioning-in-postgres)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T13:22:20+00:00

<p>Article URL: <a href="https://www.specfy.io/blog/7-git-like-versioning-in-postgres">https://www.specfy.io/blog/7-git-like-versioning-in-postgres</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955617">https://news.ycombinator.com/item?id=37955617</a></p>
<p>Points: 78</p>
<p># Comments: 45</p>

## In search of the least viewed article on Wikipedia (2022)
 - [http://colinmorris.github.io/blog/unpopular-wiki-articles](http://colinmorris.github.io/blog/unpopular-wiki-articles)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T13:20:35+00:00

<p>Article URL: <a href="http://colinmorris.github.io/blog/unpopular-wiki-articles">http://colinmorris.github.io/blog/unpopular-wiki-articles</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955600">https://news.ycombinator.com/item?id=37955600</a></p>
<p>Points: 182</p>
<p># Comments: 111</p>

## 'Mind-blowing' IBM chip speeds up AI
 - [https://www.nature.com/articles/d41586-023-03267-0](https://www.nature.com/articles/d41586-023-03267-0)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T12:59:01+00:00

<p>Article URL: <a href="https://www.nature.com/articles/d41586-023-03267-0">https://www.nature.com/articles/d41586-023-03267-0</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955421">https://news.ycombinator.com/item?id=37955421</a></p>
<p>Points: 6</p>
<p># Comments: 3</p>

## Nakatomi Space
 - [https://www.bldgblog.com/2010/01/nakatomi-space/](https://www.bldgblog.com/2010/01/nakatomi-space/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T12:56:48+00:00

<p>Article URL: <a href="https://www.bldgblog.com/2010/01/nakatomi-space/">https://www.bldgblog.com/2010/01/nakatomi-space/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955402">https://news.ycombinator.com/item?id=37955402</a></p>
<p>Points: 148</p>
<p># Comments: 65</p>

## Find the date of your birthday in the number pi
 - [https://www.mypiday.com/](https://www.mypiday.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T12:24:00+00:00

<p>Article URL: <a href="https://www.mypiday.com/">https://www.mypiday.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955137">https://news.ycombinator.com/item?id=37955137</a></p>
<p>Points: 7</p>
<p># Comments: 0</p>

## RabbitOS
 - [https://www.rabbit.tech/](https://www.rabbit.tech/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T12:22:51+00:00

<p>Article URL: <a href="https://www.rabbit.tech/">https://www.rabbit.tech/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37955130">https://news.ycombinator.com/item?id=37955130</a></p>
<p>Points: 4</p>
<p># Comments: 0</p>

## UpCodes (YC S17) is hiring remote engineers to help architects with compliance
 - [https://up.codes/careers](https://up.codes/careers)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T12:00:57+00:00

<p>Article URL: <a href="https://up.codes/careers">https://up.codes/careers</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37954980">https://news.ycombinator.com/item?id=37954980</a></p>
<p>Points: 0</p>
<p># Comments: 0</p>

## Friday Factorio Facts #381 – Space Platforms
 - [https://factorio.com/blog/post/fff-381](https://factorio.com/blog/post/fff-381)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T11:42:44+00:00

<p>Article URL: <a href="https://factorio.com/blog/post/fff-381">https://factorio.com/blog/post/fff-381</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37954854">https://news.ycombinator.com/item?id=37954854</a></p>
<p>Points: 23</p>
<p># Comments: 2</p>

## What's new in C# 12: overview
 - [https://pvs-studio.com/en/blog/posts/csharp/1074/](https://pvs-studio.com/en/blog/posts/csharp/1074/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T09:57:31+00:00

<p>Article URL: <a href="https://pvs-studio.com/en/blog/posts/csharp/1074/">https://pvs-studio.com/en/blog/posts/csharp/1074/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37954171">https://news.ycombinator.com/item?id=37954171</a></p>
<p>Points: 32</p>
<p># Comments: 12</p>

## Royal College considers no confidence move after Excel recruitment debacle
 - [https://www.theregister.com/2023/10/20/royal_college_excel_blunder/](https://www.theregister.com/2023/10/20/royal_college_excel_blunder/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T09:17:40+00:00

<p>Article URL: <a href="https://www.theregister.com/2023/10/20/royal_college_excel_blunder/">https://www.theregister.com/2023/10/20/royal_college_excel_blunder/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37953920">https://news.ycombinator.com/item?id=37953920</a></p>
<p>Points: 25</p>
<p># Comments: 6</p>

## The Unix Game
 - [https://unixgame.io/unix50](https://unixgame.io/unix50)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T08:50:42+00:00

<p>Article URL: <a href="https://unixgame.io/unix50">https://unixgame.io/unix50</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37953741">https://news.ycombinator.com/item?id=37953741</a></p>
<p>Points: 23</p>
<p># Comments: 8</p>

## A tutorial for the sam command language (1986) [pdf]
 - [http://doc.cat-v.org/bell_labs/sam_lang_tutorial/sam_tut.pdf](http://doc.cat-v.org/bell_labs/sam_lang_tutorial/sam_tut.pdf)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T08:23:10+00:00

<p>Article URL: <a href="http://doc.cat-v.org/bell_labs/sam_lang_tutorial/sam_tut.pdf">http://doc.cat-v.org/bell_labs/sam_lang_tutorial/sam_tut.pdf</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37953569">https://news.ycombinator.com/item?id=37953569</a></p>
<p>Points: 6</p>
<p># Comments: 1</p>

## Alexei Navalny's lawyers are arrested
 - [https://www.economist.com/europe/2023/10/19/alexei-navalnys-lawyers-are-arrested](https://www.economist.com/europe/2023/10/19/alexei-navalnys-lawyers-are-arrested)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T07:37:16+00:00

<p>Article URL: <a href="https://www.economist.com/europe/2023/10/19/alexei-navalnys-lawyers-are-arrested">https://www.economist.com/europe/2023/10/19/alexei-navalnys-lawyers-are-arrested</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37953336">https://news.ycombinator.com/item?id=37953336</a></p>
<p>Points: 43</p>
<p># Comments: 11</p>

## GnuCash Tutorial and Concepts Guide
 - [https://www.gnucash.org/viewdoc.phtml?rev=5&lang=C&doc=guide](https://www.gnucash.org/viewdoc.phtml?rev=5&lang=C&doc=guide)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T06:51:32+00:00

<p>Article URL: <a href="https://www.gnucash.org/viewdoc.phtml?rev=5&amp;lang=C&amp;doc=guide">https://www.gnucash.org/viewdoc.phtml?rev=5&lang;=C&amp;doc=guide</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37953094">https://news.ycombinator.com/item?id=37953094</a></p>
<p>Points: 22</p>
<p># Comments: 6</p>

## In Plane Sight: Drug agents searching passengers for cash at airport gates
 - [https://www.atlantanewsfirst.com/2023/10/19/plane-sight-drug-agents-searching-passengers-cash-airport-gates/](https://www.atlantanewsfirst.com/2023/10/19/plane-sight-drug-agents-searching-passengers-cash-airport-gates/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T05:51:59+00:00

<p>Article URL: <a href="https://www.atlantanewsfirst.com/2023/10/19/plane-sight-drug-agents-searching-passengers-cash-airport-gates/">https://www.atlantanewsfirst.com/2023/10/19/plane-sight-drug-agents-searching-passengers-cash-airport-gates/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37952741">https://news.ycombinator.com/item?id=37952741</a></p>
<p>Points: 16</p>
<p># Comments: 2</p>

## Using extra Firefox profiles to make my life better
 - [https://utcc.utoronto.ca/~cks/space/blog/web/FirefoxExtraProfilesHack](https://utcc.utoronto.ca/~cks/space/blog/web/FirefoxExtraProfilesHack)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T05:48:47+00:00

<p>Article URL: <a href="https://utcc.utoronto.ca/~cks/space/blog/web/FirefoxExtraProfilesHack">https://utcc.utoronto.ca/~cks/space/blog/web/FirefoxExtraProfilesHack</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37952719">https://news.ycombinator.com/item?id=37952719</a></p>
<p>Points: 58</p>
<p># Comments: 28</p>

## Pepper X
 - [https://en.wikipedia.org/wiki/Pepper_X](https://en.wikipedia.org/wiki/Pepper_X)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T05:21:20+00:00

<p>Article URL: <a href="https://en.wikipedia.org/wiki/Pepper_X">https://en.wikipedia.org/wiki/Pepper_X</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37952597">https://news.ycombinator.com/item?id=37952597</a></p>
<p>Points: 20</p>
<p># Comments: 5</p>

## Irish privacy group files complaint against YouTube adblock detection system
 - [https://twitter.com/alexanderhanff/status/1714944718205755483](https://twitter.com/alexanderhanff/status/1714944718205755483)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T04:05:24+00:00

<p>Article URL: <a href="https://twitter.com/alexanderhanff/status/1714944718205755483">https://twitter.com/alexanderhanff/status/1714944718205755483</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37952279">https://news.ycombinator.com/item?id=37952279</a></p>
<p>Points: 56</p>
<p># Comments: 30</p>

## Does Go Have Subtyping?
 - [https://journal.stuffwithstuff.com/2023/10/19/does-go-have-subtyping/](https://journal.stuffwithstuff.com/2023/10/19/does-go-have-subtyping/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T03:26:24+00:00

<p>Article URL: <a href="https://journal.stuffwithstuff.com/2023/10/19/does-go-have-subtyping/">https://journal.stuffwithstuff.com/2023/10/19/does-go-have-subtyping/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37952079">https://news.ycombinator.com/item?id=37952079</a></p>
<p>Points: 17</p>
<p># Comments: 5</p>

## OS/2 Warp, PowerPC Edition
 - [http://ps-2.kev009.com/michaln/history/os2ppc/index.html](http://ps-2.kev009.com/michaln/history/os2ppc/index.html)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T02:48:12+00:00

<p>Article URL: <a href="http://ps-2.kev009.com/michaln/history/os2ppc/index.html">http://ps-2.kev009.com/michaln/history/os2ppc/index.html</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37951837">https://news.ycombinator.com/item?id=37951837</a></p>
<p>Points: 8</p>
<p># Comments: 3</p>

## Which Interpreters Are Faster, AST or Bytecode?
 - [https://stefan-marr.de/2023/10/ast-vs-bytecode-interpreters/](https://stefan-marr.de/2023/10/ast-vs-bytecode-interpreters/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T01:47:06+00:00

<p>Article URL: <a href="https://stefan-marr.de/2023/10/ast-vs-bytecode-interpreters/">https://stefan-marr.de/2023/10/ast-vs-bytecode-interpreters/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37951343">https://news.ycombinator.com/item?id=37951343</a></p>
<p>Points: 11</p>
<p># Comments: 0</p>

## Nota is a language for writing documents, like academic papers and blog posts
 - [https://nota-lang.org/#def-nota](https://nota-lang.org/#def-nota)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T01:00:51+00:00

<p>Article URL: <a href="https://nota-lang.org/#def-nota">https://nota-lang.org/#def-nota</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37950952">https://news.ycombinator.com/item?id=37950952</a></p>
<p>Points: 17</p>
<p># Comments: 2</p>

## Replit permanently moves to paid hosting after 7 years of free service
 - [https://noreplit.com/](https://noreplit.com/)
 - RSS feed: https://hnrss.org/frontpage
 - date published: 2023-10-20T00:13:51+00:00

<p>Article URL: <a href="https://noreplit.com/">https://noreplit.com/</a></p>
<p>Comments URL: <a href="https://news.ycombinator.com/item?id=37950534">https://news.ycombinator.com/item?id=37950534</a></p>
<p>Points: 13</p>
<p># Comments: 0</p>

