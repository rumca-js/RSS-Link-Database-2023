# Source:GeekWire, URL:https://www.geekwire.com/feed/, language:en-US

## Writers respond to techno-optimism about AI with a manifesto of their own: ‘It’s mostly nonsense’
 - [https://www.geekwire.com/2023/writers-techno-optimism-ai-nonsense/](https://www.geekwire.com/2023/writers-techno-optimism-ai-nonsense/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-20T18:27:11+00:00

<img alt="Ted Chiang at GeekWire Summit on AI" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/10/20231019_GeekWire_Summit_791-1260x840.jpg" width="1260" /><br />How will &#8220;The Techno-Optimist Manifesto,&#8221; venture capitalist Marc Andreessen&#8217;s paean to economic growth and artificial intelligence, play to a wider audience? The reviews are in from two award-winning writers who are familiar with the impact of generative AI on creative professions. &#8220;I think it&#8217;s mostly nonsense,&#8221; science-fiction writer Ted Chiang said Thursday at the GeekWire Summit in Seattle. Chiang, a longtime Seattle-area resident, is best-known as the author of &#8220;Story of Your Life,&#8221; the novella that was adapted for the Oscar-nominated 2016 movie &#8220;Arrival.&#8221; But he&#8217;s also won acclaim as a commentator on AI&#8217;s effects for The New Yorker and&#8230; <a href="https://www.geekwire.com/2023/wri

## GeekWire Summit recap: AI gets real in Seattle as historic theater plays host to future-focused event
 - [https://www.geekwire.com/2023/geekwire-summit-recap-ai-gets-real-in-seattle-as-historic-theater-plays-host-to-future-focused-event/](https://www.geekwire.com/2023/geekwire-summit-recap-ai-gets-real-in-seattle-as-historic-theater-plays-host-to-future-focused-event/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-20T17:48:57+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="945" src="https://cdn.geekwire.com/wp-content/uploads/2023/10/summit2023-1260x945.jpeg" width="1260" /><br />In a Seattle building full of history and nostalgia, the GeekWire Summit returned Thursday with an agenda focused on rapidly advancing technology and what it will mean for the future. A crowd of nearly 600 attendees filled the SIFF Cinema — formerly the Cinerama movie theater — in Belltown for our annual technology conference, titled &#8220;AI Gets Real&#8221; this year in a nod to how artificial intelligence is transforming society. Panel discussions featuring Seattle tech leaders addressed AI&#8217;s impact on technology, business and strategy, and culture. Experts shared how AI is changing transportation, design and agriculture. It was all set&#8230; <a href="https://www.geekwire.com/2023/geekwire-summit-recap-ai-gets-real-in-seattle-as-historic-theater-plays-host-to-future-focused-event/">Read More</a>

## ‘The markets crushed us’: In tearful farewell to employees, Convoy execs reflect on shutdown
 - [https://www.geekwire.com/2023/the-markets-crushed-us-in-tearful-farewell-to-employees-convoy-execs-reflect-on-shutdown/](https://www.geekwire.com/2023/the-markets-crushed-us-in-tearful-farewell-to-employees-convoy-execs-reflect-on-shutdown/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-20T14:57:07+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2019/10/2663-Summit-20191008-DD-1260x840.jpg" width="1260" /><br />Convoy CEO Dan Lewis, eyes watery from an emotional speech, said goodbye. Mark Okerstrom, the company&#8217;s president, stood up and parted his flannel to show the Convoy logo on his shirt underneath, in an apparent attempt at a final display of solidarity. And with that, an 8-year journey for one of Seattle&#8217;s most high-profile startups was essentially over. Convoy exhausted every possible strategic option to survive over the past four months, but it wasn&#8217;t enough to save the trucking marketplace company from a sudden and surprising collapse. That was the message to employees from Lewis and Okerstrom on a company-wide&#8230; <a href="https://www.geekwire.com/2023/the-markets-crushed-us-in-tearful-farewell-to-employees-convoy-execs-reflect-on-shutdown/">Read More</a>

