# Source:CBC | Top Stories News, URL:https://www.cbc.ca/webfeed/rss/rss-topstories, language:en

## Company that arranges military moves has been hacked, defence department confirms
 - [https://www.cbc.ca/news/politics/military-relocation-hacked-bgrs-1.7003766?cmp=rss](https://www.cbc.ca/news/politics/military-relocation-hacked-bgrs-1.7003766?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T18:33:05+00:00

<img alt="A row of while prefab houses." height="349" src="https://i.cbc.ca/1.3332475.1696627123!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/cfb-trenton-refugee-housing.JPG" title="Many of the 25,000 Syrian refugees coming to Canada will stay on military bases.  At CFB Trenton in southeastern Ontario, they will stay on bunk-beds in buildings that normally house air cadets while they are training.  " width="620" /><p>The private company that assists members of the Canadian military and foreign service when they move across the country or around the world has been hacked, says a Department of National Defence note issued internally late Friday.</p>

## Canada's Christine Sinclair explains her retirement decision
 - [https://www.cbc.ca/sports/canada-s-christine-sinclair-explains-her-retirement-decision-1.7003831?cmp=rss](https://www.cbc.ca/sports/canada-s-christine-sinclair-explains-her-retirement-decision-1.7003831?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T18:22:00+00:00

<img alt="" height="349" src="https://thumbnails.cbc.ca/maven_legacy/thumbnails/194/891/christinefinaloct20.jpg" title="" width="620" /><p>The Canadian soccer legend talks about some of the reasons she decided to hang up her cleats.</p>

## Eating the world's hottest pepper might make you 'throw up immediately,' says breeder
 - [https://www.cbc.ca/radio/day6/pepper-x-worlds-hottest-1.7002884?cmp=rss](https://www.cbc.ca/radio/day6/pepper-x-worlds-hottest-1.7002884?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T16:12:27+00:00

<img alt="A pepper being held between fingers in a close up photos." height="349" src="https://i.cbc.ca/1.7000096.1697817889!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/world-s-hottest-pepper.jpg" title="A Pepper X pepper is shown on Tuesday, Oct. 10, 2023, in Fort Mill, S.C. The pepper variety is now the hottest pepper in the world according to the Guinness Book of World Records" width="620" /><p>Ed Currie had already held the record for the world’s hottest pepper, the Carolina Reaper, but he apparently did not fear the reaper, and upped the ante with his new record-breaker, Pepper X.</p>

## Premiers call on Ottawa to extend CEBA forgiveness deadline by a year
 - [https://www.cbc.ca/news/politics/premiers-calling-for-ceba-forgiveness-deadline-extension-1.7003354?cmp=rss](https://www.cbc.ca/news/politics/premiers-calling-for-ceba-forgiveness-deadline-extension-1.7003354?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T15:34:47+00:00

<img alt="A restaurant patio displays a sign that reads &quot;Take out only.&quot; " height="349" src="https://i.cbc.ca/1.7003391.1697829897!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/in-the-news-20200624.jpg" title="A restaurant in Toronto displays a &quot;Take Out Only&quot; sign on Wednesday, March 18, 2020. Ontario&apos;s two most heavily populated regions will see more businesses open their doors today as Toronto and Peel move into the next stage of the province&apos;s COVID-19 recovery plan." width="620" /><p>Canada's premiers are calling on the federal government to push back the deadline for businesses to repay their government-backed pandemic loans in order to access the forgivable portion.</p>

## Residential school healing retreat had Métis survivors giggling, 'staying up until 12:30 a.m.'
 - [https://www.cbc.ca/news/indigenous/metis-residential-school-survivors-retreat-1.7003014?cmp=rss](https://www.cbc.ca/news/indigenous/metis-residential-school-survivors-retreat-1.7003014?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T15:05:26+00:00

<img alt="Angie Crerar wears an orange vest while smiling brightly and looking at the camera." height="349" src="https://i.cbc.ca/1.7002084.1697828625!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/angie-crerar.jpg" title="Métis elder Angie Crerar said being around other survivors helped her with the loneliness and pain that comes from her experience at St. Joseph’s Indian Residential School." width="620" /><p>Métis residential school survivors recently had the chance to spend three days together at Métis Crossing cultural interpretative centre in Alberta. Survivors say they felt something special from the moment they arrived.</p>

## More than 30 MPs — including 23 Liberals — call for ceasefire in Israel-Hamas war
 - [https://www.cbc.ca/news/politics/33-mps-letter-trudeau-ceasfire-israel-gaza-1.7003256?cmp=rss](https://www.cbc.ca/news/politics/33-mps-letter-trudeau-ceasfire-israel-gaza-1.7003256?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T14:55:18+00:00

<img alt="Smoke rises over the Gaza Strip." height="349" src="https://i.cbc.ca/1.7003286.1697827192!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/israel-palestinians.jpg" title="Smoke rises following an Israeli airstrike in the Gaza Strip, as seen from southern Israel, Tuesday, Oct. 17, 2023. Israel has been striking targets throughout Gaza since a bloody, cross-border attack by Hamas militants killed over 1,400 and captured many Israelis on Oct. 7." width="620" /><p>More than 30 MPs — 23 of them Liberals — have written a letter to Prime Minister Justin Trudeau calling on him to advocate for a ceasefire between Israel and Hamas.</p>

## Canadian officials provide update on Israel-Hamas war
 - [https://www.cbc.ca/news/canada/canadian-officials-provide-update-on-israel-hamas-war-1.7002926?cmp=rss](https://www.cbc.ca/news/canada/canadian-officials-provide-update-on-israel-hamas-war-1.7002926?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T13:00:00+00:00

<img alt="" height="349" src="https://liveimages.cbc.ca/4HMsf5M5KGyEMlhMCFx8/thumbnail.jpeg" title="" width="620" /><p>Officials from Global Affairs Canada, the Department of National Defence and Immigration, Refugees and Citizenship Canada give an update in Ottawa on the Israel-Hamas war.</p>

## India making life 'unbelievably difficult' for millions by ordering diplomats out, says Trudeau
 - [https://www.cbc.ca/news/politics/trudeau-india-making-life-difficult-1.7002961?cmp=rss](https://www.cbc.ca/news/politics/trudeau-india-making-life-difficult-1.7002961?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T12:56:03+00:00

<img alt="Prime Minister Justin Trudeau stands at a podium" height="349" src="https://i.cbc.ca/1.7002989.1697820237!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/prime-minister-justin-trudeau.jpeg" title="Prime Minister Justin Trudeau, speaking in Brampton Ont. Oct. 20, 2023, tells reporters that all countries in the world should be worried about India&apos;s decision to revoke the diplomatic immunity of 41 Canadian diplomats in the country. " width="620" /><p>India’s decision to revoke diplomatic immunity for dozens of Canadian diplomats is making life “unbelievably difficult” for millions of people with ties to that country, Prime Minister Justin Trudeau said Friday.</p>

## Kenneth Chesebro pleads guilty over efforts to overturn Trump's 2020 loss in Georgia
 - [https://www.cbc.ca/news/world/trump-georgia-trial-chesebro-prosecutors-1.7002977?cmp=rss](https://www.cbc.ca/news/world/trump-georgia-trial-chesebro-prosecutors-1.7002977?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T12:53:52+00:00

<img alt="Lawyer Kenneth Chesebro, appears before Judge Scott MacAfee during a motions hearing on Oct. 10, 2023, in Atlanta." height="349" src="https://i.cbc.ca/1.7003009.1697820050!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/october-2023-file-photo-of-lawyer-kenneth-chesebro-appearing-in-atlanta-courtroom.jpg" title="Lawyer Kenneth Chesebro, appears before Judge Scott MacAfee during a motions hearing on Oct. 10, 2023, in Atlanta. Jury selection is set to begin for Chesebro, the first defendant to go to trial in the Georgia case that accuses former President Donald Trump and others of illegally scheming to overturn the 2020 election in the state. " width="620" /><p>Lawyer Kenneth Chesebro pleaded guilty to a felony on Friday just as jury selection was getting underway in his trial on charges accusing him of participating in efforts to overturn Donald Trump's loss in the 2020 election in Georgia.</p>

## Iconic Toronto condo project placed into receivership due to $1.6B in unpaid debt
 - [https://www.cbc.ca/news/business/toronto-condo-1-bloor-mizrahi-1.7002651?cmp=rss](https://www.cbc.ca/news/business/toronto-condo-1-bloor-mizrahi-1.7002651?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T10:58:00+00:00

<img alt="Construction of The One condo tower in Toronto" height="349" src="https://i.cbc.ca/1.7002845.1697815394!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/the-one-condo-construction.jpg" title="The One, Sam Mizrahi and Jenny Coco’s 85-storey luxury condo under development is seen at the corner of Yonge and Bloor streets in Toronto, Thursday, October 19, 2023." width="620" /><p>A high-profile Toronto condominium project that has been plagued with delays and setbacks for more than a decade has been placed into receivership by its biggest lender, refusing to foot the bill for $1.6 billion in unpaid debts until someone else is in charge.</p>

## Poilievre steps into Alberta's pension dispute with Ottawa, says province should stay in CPP
 - [https://www.cbc.ca/news/politics/poilievre-trudeau-smith-alberta-pensions-1.7002596?cmp=rss](https://www.cbc.ca/news/politics/poilievre-trudeau-smith-alberta-pensions-1.7002596?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T09:25:04+00:00

<img alt="Pierre Poilievre speaks from the podium" height="349" src="https://i.cbc.ca/1.6966994.1694717182!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/pierre-poilievre.jpg" title="Pierre Poilievre, leader of the Conservative Party of Canada, is pictured during a press conference in Vancouver, B.C, on Thursday, September 14, 2023." width="620" /><p>Conservative Leader Pierre Poilievre has waded into the pension debate between Alberta and Ottawa, blaming the dispute on the prime minister and urging Albertans to remain in the Canada Pension Plan. </p>

## Move over, Ryan Reynolds: Canadian soccer whistleblower now co-owner, CEO of Irish football club
 - [https://www.cbc.ca/news/canada/british-columbia/ciara-mccormack-treaty-united-football-club-1.7000844?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/ciara-mccormack-treaty-united-football-club-1.7000844?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T08:00:00+00:00

<img alt="Male soccer players stand with their backs to the camera at Markets Field Stadium in Limerick, Ireland." height="349" src="https://i.cbc.ca/1.7002282.1697757117!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/treaty-united.jpg" title="Treaty United FC&apos;s home is the 4,500 seat Markets Field Stadium in Limerick, Ireland. The men&apos;s team plays in the League of Ireland first division, while the women&apos;s team plays in the premier women&apos;s division." width="620" /><p>Ciara McCormack's recent purchase of Treaty United Football Club in Limerick has shades of Ted Lasso and a plot line ripped straight out of Welcome to Wrexham.</p>

## Move over, Ryan Reynolds: Canadian soccer whistleblower now co-owner, CEO of Irish football club
 - [https://www.cbc.ca/news/canada/british-columbia/mccormack-treaty-football-vancouver-limerick-1.7000844?cmp=rss](https://www.cbc.ca/news/canada/british-columbia/mccormack-treaty-football-vancouver-limerick-1.7000844?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T08:00:00+00:00

<img alt="Male soccer players stand with their backs to the camera at Markets Field Stadium in Limerick, Ireland." height="349" src="https://i.cbc.ca/1.7002282.1697836262!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/treaty-united.jpg" title="Treaty United FC&apos;s home is the 4,500 seat Markets Field Stadium in Limerick, Ireland. The men&apos;s team plays in the League of Ireland first division, while the women&apos;s team plays in the premier women&apos;s division." width="620" /><p>Ciara McCormack's recent purchase of Treaty United Football Club in Limerick has shades of Ted Lasso and a plot line ripped straight out of Welcome to Wrexham.</p>

## Severe childbirth injuries from forceps, vacuum 'unacceptably high' in Canada, research shows
 - [https://www.cbc.ca/news/health/forceps-injury-1.7002212?cmp=rss](https://www.cbc.ca/news/health/forceps-injury-1.7002212?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T08:00:00+00:00

<img alt="A mother holds the hand of her baby in hospital." height="349" src="https://i.cbc.ca/1.7002238.1697754931!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/germany-newborn.JPG" title="A mother holds the hand of her baby at the Munich hospital &apos;Rechts der Isar&apos; January 18, 2011.  " width="620" /><p>Canadian mothers face high rates of severe, long-term injuries from the use of forceps or vacuum in childbirth, and urgent action is needed to reduce it, the authors of a new analysis paper say.</p>

## Indigenous pot shops face crowded market, constitutional questions 5 years since legalization
 - [https://www.cbc.ca/news/canada/sudbury/indigenous-cannabis-northern-ontario-five-years-legalization-1.7001169?cmp=rss](https://www.cbc.ca/news/canada/sudbury/indigenous-cannabis-northern-ontario-five-years-legalization-1.7001169?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T07:07:39+00:00

<img alt="A container of flower cannabis sits on a counter with a mural of a tradtional-looking Indigenous man behind" height="349" src="https://i.cbc.ca/1.7002533.1697795147!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/creator-s-choice-cannabis-wahnapitae-first-nation.JPG" title="Indigenous dispensaries were the first to sell legal cannabis in northern Ontario, but are now facing stiff competition from dozens of provincially-licensed pot shops. " width="620" /><p>Five years after the legalization of cannabis, the future of the Indigenous side of the industry in northern Ontario is hazy. On-reserve dispensaries that once dominated now face increased competition, and some First Nations see cannabis as the next battleground for constitutional rights. </p>

## Sask. government's pronoun policy relied heavily on 1 U.S. expert
 - [https://www.cbc.ca/news/canada/saskatchewan/sask-pronoun-policy-expert-1.7001660?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/sask-pronoun-policy-expert-1.7001660?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T07:00:00+00:00

<img alt="A youth waves a LGBTQ2+ flag on the steps of the provincial legislature in Regina, Sask. " height="349" src="https://i.cbc.ca/1.6999378.1697579054!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/student-walkout-pronoun-policy.jpeg" title="Students across the City of Regina walked out of school on Tuesday and gathered at the provincial legislature to protest the Saskatchewan government&apos;s controversial pronoun policy. " width="620" /><p>Court documents filed in response to a court challenge over the constitutionality of Saskatchewan's proposed pronoun policy show the government cited one U.S. expert it relied on in coming up with the policy.</p>

## Sask. government poised to pass Parents' Bill of Rights
 - [https://www.cbc.ca/news/canada/saskatchewan/sask-parental-rights-law-1.7002088?cmp=rss](https://www.cbc.ca/news/canada/saskatchewan/sask-parental-rights-law-1.7002088?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T06:00:00+00:00

<img alt="Saskatchewan Premier Scott Moe&apos;s government is expected to pass Bill 137 and on Friday." height="349" src="https://i.cbc.ca/1.7002329.1697758670!/cpImage/httpImage/image.jpg_gen/derivatives/16x9_620/sask-trans-student-bill-20231010.jpg" title="Saskatchewan Premier Scott Moe&apos;s government is expected to pass Bill 137 and on Friday." width="620" /><p>The Saskatchewan government is expected to pass Bill 137, which requires parental consent before a child under 16 can use a different gender-related name or pronoun at school, on Friday.</p>

## 'Panic' as people line up round the clock at Brampton's Indian visa office
 - [https://www.cbc.ca/news/canada/toronto/indian-visa-brampton-lineup-1.6999972?cmp=rss](https://www.cbc.ca/news/canada/toronto/indian-visa-brampton-lineup-1.6999972?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T05:00:00+00:00

<img alt="Line up outside Brampton BLS international for OCI applications." height="349" src="https://i.cbc.ca/1.7000070.1697645268!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/line-up-outside-brampton-bls-international-for-oci-applications.jpg" title="Line up of hopeful OCI applicants outside the Brampton BLS international office. " width="620" /><p>As India’s festive season approaches, Indian-born Canadians are trying to access the only service the Indian government hasn’t suspended: the Overseas Citizens of India card.</p>

## Canada has fewer entrepreneurs today than it did 20 years ago — and that's a big problem for everyone
 - [https://www.cbc.ca/news/business/canada-entrepreneurs-shortage-solutions-1.7002171?cmp=rss](https://www.cbc.ca/news/business/canada-entrepreneurs-shortage-solutions-1.7002171?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:08+00:00

<img alt="A man with short blond hair and blue eyes sits on metal staircase in a basement warehouse space with his Golden Retriever.    " height="349" src="https://i.cbc.ca/1.7002279.1697756539!/fileImage/httpImage/image.jpeg_gen/derivatives/16x9_620/james-lynn.jpeg" title="James Lynn, the founder of Kalū, an independent pet food-maker in Montreal, at work with his dog Sunshine.  Lynn is one of an increasingly small number of Canadian getting into entrepreneurship.   " width="620" /><p>A new report from the Business Development Bank of Canada says an “alarming decline” in the number of Canadian entrepreneurs could hurt economic growth and slow innovation. It estimates the country has 100,000 fewer entrepreneurs today than it had in 2000.</p>

## 'Ultimate win-win': Global impact brings Olympics, cricket back together again
 - [https://www.cbc.ca/sports/olympics/cricket-canada-global-impact-of-olympic-status-ioc-icc-1.6999623?cmp=rss](https://www.cbc.ca/sports/olympics/cricket-canada-global-impact-of-olympic-status-ioc-icc-1.6999623?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="The Canadian men&apos;s national cricket team celebrates a wicket against hosts Bermuda at the ICC Men&apos;s T20 World Cup Americas Qualifier." height="349" src="https://i.cbc.ca/1.6999687.1697737844!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/icc-cricket-canada-oct-18.JPG" title="Canada&apos;s men&apos;s cricket team qualified for the Men&apos;s T20 World Cup for the first-time ever after defeating Bermuda by 39 runs earlier in October. The dynamic faster-paced shortened format of the game will be played at the 2028 Los Angeles Games after the sport was officially added to the Olympic program." width="620" /><p>After more than a century and now with an estimated 2.5 billion fans worldwide — cricket is returning to the Olympics. The continued growth of the sport and the very first Major League Cricket season contributed to its inclusion for the 2028 Games in Los Angeles.</p>

## A different kind of Mean Streets — How Scorsese's Killers of the Flower Moon earns its epic runtime
 - [https://www.cbc.ca/news/entertainment/killers-of-the-flower-moon-review-1.7002358?cmp=rss](https://www.cbc.ca/news/entertainment/killers-of-the-flower-moon-review-1.7002358?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="Ernest the driver offers Mollie, a wealthy Osage woman a ride, in an opening scene from Killers of the Flower Moon starring Leonardo DiCaprio and Lily Gladstone. " height="349" src="https://i.cbc.ca/1.7002366.1697762515!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/killers-of-the-flower-moon.jpg" title="Ernest the driver offers Mollie, a wealthy Osage woman a ride, in an opening scene from Killers of the Flower Moon starring Leonardo DiCaprio and Lily Gladstone. " width="620" /><p>Love, lies and greed. That's just some of what's waiting for audiences in Killers of the Flower Moon, the latest film from director Martin Scorsese. The runtime may be over three hours, but CBC's Eli Glasner says the director makes the most of it.</p>

## Doug Ford's government promised 1 inspector for every 2 long-term care homes. That hasn't happened
 - [https://www.cbc.ca/news/canada/toronto/ontario-long-term-care-home-inspections-1.7001238?cmp=rss](https://www.cbc.ca/news/canada/toronto/ontario-long-term-care-home-inspections-1.7001238?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="Two female long-term care residents sitting in wheelchairs use an interactive table.  " height="349" src="https://i.cbc.ca/1.7001776.1697740337!/cumulusImage/httpImage/image.jpg_gen/derivatives/16x9_620/misericordia-place-residents-in-winnipeg-on-15-nov-2021.jpg" title="The $14,000 state-of-the-art Tovertafel or &apos;Magic Table&apos; from the Netherlands is designed to both engage and challenge long-term care residents, including 91-year-old Juliana D’Souza, left." width="620" /><p>Premier Doug Ford's government is falling short of its promises to conduct annual inspections of every long-term care home in Ontario and to boost the ratio of inspectors to homes, according to information obtained by CBC News.</p>

## I first walked the Camino de Santiago at age 73. What could go wrong a second time?
 - [https://www.cbc.ca/news/canada/montreal/first-person-camino-de-santiago-1.7000686?cmp=rss](https://www.cbc.ca/news/canada/montreal/first-person-camino-de-santiago-1.7000686?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="A woman stands in front of an old cathedral." height="349" src="https://i.cbc.ca/1.7000688.1697739845!/fileImage/httpImage/image.png_gen/derivatives/16x9_620/at-73-i-finished-an-800-km-pilgrimage-but-my-second-trek-challenged-me-in-unexpected-ways-image-1.png" title="Isobel Cunningham had hoped to make it to the Santiago Cathedral by foot a second time, but difficult terrain and a sore hip got in the way." width="620" /><p>When Isobel Cunningham embarked on her second Camino de Santiago trek this year, she thought taking a shorter route would make things easier. When it didn't go as planned, she looked for other ways to find meaning in the journey.</p>

## In the wondrous new Super Mario game, every level is 'that one weird level
 - [https://www.cbc.ca/radio/day6/super-mario-bros-wonder-review-1.6998211?cmp=rss](https://www.cbc.ca/radio/day6/super-mario-bros-wonder-review-1.6998211?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="Video game screenshot of Mario, green pipes and a floating blue flower." height="349" src="https://i.cbc.ca/1.6998227.1697496780!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/super-mario-bros-wonder-01.jpg" title="Mario eyes a Wonder Flower in Super Mario Bros Wonder for the Nintendo Switch." width="620" /><p>SMB Wonder is the best 2D Mario game in more than 30 years, managing to feel fresh while remaining faithful to the blueprint set back in 1986 that, for many, codified what a video game is.</p>

## LGBTQ advocates in Thunder Bay, Ont., say Canada's laws aren't protecting them from hate
 - [https://www.cbc.ca/news/canada/thunder-bay/lgbtq-advocates-thunder-bay-unsafe-1.7000329?cmp=rss](https://www.cbc.ca/news/canada/thunder-bay/lgbtq-advocates-thunder-bay-unsafe-1.7000329?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="People in a crowd hold rainbow-coloured pride flags." height="349" src="https://i.cbc.ca/1.6973596.1695263859!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/thunder-bay-pride-rally.JPG" title="Moe than 100 people gather at Thunder Bay City Hall to show support for trans youth as part of the Rainbow Collective of Thunder Bay&apos;s Love Always Wins Healing Rally." width="620" /><p>LGBTQ organizations in Thunder Bay, Ont., say there's a rising tide of anti-LGBTQ sentiment across Canada, with advocates saying hate crime laws aren't strong enough to protect them. </p>

## Montreal museum brings together unprecedented collection of historical wampum belts
 - [https://www.cbc.ca/news/indigenous/mccord-stewart-museum-wampum-belt-exhibit-1.7001954?cmp=rss](https://www.cbc.ca/news/indigenous/mccord-stewart-museum-wampum-belt-exhibit-1.7001954?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="4 historical wampum belts displayed in a glass case." height="349" src="https://i.cbc.ca/1.7002032.1697747887!/fileImage/httpImage/image.JPG_gen/derivatives/16x9_620/wampum-belts.JPG" title="Over 40 wampum belts are a part of the exhibition, which runs until March 2024 at the McCord Stuart Museum in Montreal." width="620" /><p>Forty historical wampum belts currently held by public and private institutions across Europe, Quebec, and Ontario are part of a new exhibition at the McCord Stewart Museum.</p>

## Ontario doctor suspended from work, doxed after pro-Palestinian social media posts
 - [https://www.cbc.ca/news/canada/doctor-doxed-suspended-palestinian-posts-1.7001887?cmp=rss](https://www.cbc.ca/news/canada/doctor-doxed-suspended-palestinian-posts-1.7001887?cmp=rss)
 - RSS feed: https://www.cbc.ca/webfeed/rss/rss-topstories
 - date published: 2023-10-20T04:00:00+00:00

<img alt="A sign that says Mackenzie Richmond Hill Hospital, and Emergency" height="349" src="https://i.cbc.ca/1.3482363.1697747124!/fileImage/httpImage/image.jpg_gen/derivatives/16x9_620/toronto-mackenzie-richmond-hill-hospital.jpg" title="The hospital ..." width="620" /><p>Dr. Ben Thomson, a nephrologist at Mackenzie Richmond Hill Hospital, has posted opinions on social media about the war between Israel and Hamas. Along with threats to his safety, earlier this month he was suspended for one month, but the health authority denies he 'was suspended for his views.'</p>

