# Source:Gadgets 360, URL:https://feeds.feedburner.com/gadgets360-latest, language:en

## OnePlus to Unveil New BOE Display on October 24, Might Offer 3,000 Nits Brightness
 - [https://www.gadgets360.com/mobiles/news/oneplus-boe-oppo-smartphone-display-october-24-launch-3000-nits-brightness-weibo-leak-4499833](https://www.gadgets360.com/mobiles/news/oneplus-boe-oppo-smartphone-display-october-24-launch-3000-nits-brightness-weibo-leak-4499833)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T12:20:38+00:00

OnePlus Open's inner and outer screens are rated to deliver a peak brightness of 2,800 nits

## Spider-Man 2 Will Add New Game Plus Mode Later This Year, Insomniac Confirms
 - [https://www.gadgets360.com/games/news/spider-man-2-new-game-plus-release-date-features-mission-replay-post-launch-update-day-one-ps5-insomniac-playstation-4500026](https://www.gadgets360.com/games/news/spider-man-2-new-game-plus-release-date-features-mission-replay-post-launch-update-day-one-ps5-insomniac-playstation-4500026)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T12:12:18+00:00

You can switch between Peter Parker and Miles Morales in the open world

## Apple's First Foldable Could Be an iPad With Small-Scale Production Said to Begin End of 2024: Report
 - [https://www.gadgets360.com/mobiles/news/apple-ipad-foldable-2024-2025-launch-production-report-4499871](https://www.gadgets360.com/mobiles/news/apple-ipad-foldable-2024-2025-launch-production-report-4499871)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T11:22:00+00:00

Apple’s smallest iPad is currently its Mini which was last refreshed in 2021

## PS5 Slimmer Variant Will Reportedly Launch November 10 in the US, Spider-Man 2 Bundle Leaked
 - [https://www.gadgets360.com/games/news/ps5-slim-release-date-and-price-2023-november-10-us-japan-spider-man-2-bundle-specs-playstation-sony-4499591](https://www.gadgets360.com/games/news/ps5-slim-release-date-and-price-2023-november-10-us-japan-spider-man-2-bundle-specs-playstation-sony-4499591)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T10:18:32+00:00

The PS5 Slim will be available in both Digital and disc variants

## Vivo X90 Pro Price in India Slashed by Rs. 10,000: Here's How Much It Costs Now
 - [https://www.gadgets360.com/mobiles/news/vivo-x90-pro-price-in-india-drop-cut-rs-74999-specifications-4499389](https://www.gadgets360.com/mobiles/news/vivo-x90-pro-price-in-india-drop-cut-rs-74999-specifications-4499389)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T09:41:52+00:00

Vivo X90 Pro is available in a single Legendary Black shade

## Google for India 2023: AI-Powered Search Becomes More Visual and Local, New Services on Google Pay
 - [https://www.gadgets360.com/apps/news/google-for-india-2023-event-announcements-ai-search-generative-experience-google-pay-4499213](https://www.gadgets360.com/apps/news/google-for-india-2023-event-announcements-ai-search-generative-experience-google-pay-4499213)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T09:06:10+00:00

Google’s Search Generative Experience is available in both English and Hindi in India

## iQoo 12 Series Could Launch on November 7; Colour Options, Battery Details Leaked
 - [https://www.gadgets360.com/mobiles/news/iqoo-12-pro-launch-november-7-colour-options-battery-specifications-leak-weibo-4499133](https://www.gadgets360.com/mobiles/news/iqoo-12-pro-launch-november-7-colour-options-battery-specifications-leak-weibo-4499133)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T09:02:26+00:00

iQoo 11 5G (above) features Qualcomm's flagship Snapdragon 8 Gen 2 SoC

## OTT Releases This Week: Kaala Paani, King of Kotha, The Fall of the House of Usher, More
 - [https://www.gadgets360.com/entertainment/news/ott-release-this-week-india-october-20-kaala-paani-fall-house-usher-kong-of-kotha-netflix-hotstar-prime-video-4499089](https://www.gadgets360.com/entertainment/news/ott-release-this-week-india-october-20-kaala-paani-fall-house-usher-kong-of-kotha-netflix-hotstar-prime-video-4499089)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T07:46:16+00:00

Rahul Kohli in a still from The Fall of the House of Usher

## Crypto Price Today: Bitcoin Price Breaches $29,000 Mark, Losses Hit Tether, Ripple Among Other Coins
 - [https://www.gadgets360.com/cryptocurrency/news/bitcoin-ether-price-today-india-october-20-losses-strike-tether-ripple-cryptocurrency-4498942](https://www.gadgets360.com/cryptocurrency/news/bitcoin-ether-price-today-india-october-20-losses-strike-tether-ripple-cryptocurrency-4498942)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T06:47:30+00:00

The crypto market valuation stands at $1.11 trillion as of October 20

## Apple Watch Series 9 Review: What’s New?
 - [https://www.gadgets360.com/wearables/reviews/apple-watch-series-9-review-price-in-india-colours-double-tap-4485640](https://www.gadgets360.com/wearables/reviews/apple-watch-series-9-review-price-in-india-colours-double-tap-4485640)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T06:46:20+00:00

Apple’s Watch Series 9 is priced from Rs. 41,900 in India

## India Smartphone Shipments Fall 3 Percent YoY in Q3, Samsung Retains Leadership: Canalys
 - [https://www.gadgets360.com/mobiles/news/india-smartphone-shipments-q3-2023-samsung-xiaomi-vivo-realme-oppo-canalys-4498789](https://www.gadgets360.com/mobiles/news/india-smartphone-shipments-q3-2023-samsung-xiaomi-vivo-realme-oppo-canalys-4498789)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T06:34:53+00:00

Premium smartphone segment also witnessed robust growth in the just-ended quarter

## Cryptocurrency Firms Gemini, DCG, Genesis Sued in US for Alleged $1 Billion Fraud
 - [https://www.gadgets360.com/cryptocurrency/news/cryptocurrency-firm-genesis-dcg-gemini-crypto-fraud-usd-1-billion-lawsuit-us-4498848](https://www.gadgets360.com/cryptocurrency/news/cryptocurrency-firm-genesis-dcg-gemini-crypto-fraud-usd-1-billion-lawsuit-us-4498848)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T06:15:18+00:00

Genesis and Gemini have clashed several times over the past few months

## WhatsApp Introduces Multiple Accounts on Android: Here’s How to Enable the Feature
 - [https://www.gadgets360.com/apps/news/whatsapp-multiple-accounts-feature-rollout-android-app-meta-4498678](https://www.gadgets360.com/apps/news/whatsapp-multiple-accounts-feature-rollout-android-app-meta-4498678)
 - RSS feed: https://feeds.feedburner.com/gadgets360-latest
 - date published: 2023-10-20T05:20:02+00:00

Users can switch between work and personal accounts

