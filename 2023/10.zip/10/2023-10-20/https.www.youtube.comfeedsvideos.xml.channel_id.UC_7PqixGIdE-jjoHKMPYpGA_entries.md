# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Przełyk ośmiornicy nie mógł być w dziwniejszym miejscu #short
 - [https://www.youtube.com/watch?v=pPDxGi3Bb7c](https://www.youtube.com/watch?v=pPDxGi3Bb7c)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2023-10-20T18:17:07+00:00

#short o anatomii ośmiornicy

