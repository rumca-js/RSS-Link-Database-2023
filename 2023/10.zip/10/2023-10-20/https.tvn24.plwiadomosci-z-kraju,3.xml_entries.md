# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Wypadek i kolizja na Wale Miedzeszyńskim. Osiem osób poszkodowanych
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-wypadki-na-wale-miedzeszynskim-osiem-osob-poszkodowanych-7402271?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-dwa-wypadki-na-wale-miedzeszynskim-osiem-osob-poszkodowanych-7402271?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T20:33:43+00:00

<img alt="Wypadek i kolizja na Wale Miedzeszyńskim. Osiem osób poszkodowanych" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hwke6v-zderzenie-citroena-i-busa-7402280/alternates/LANDSCAPE_1280" />
    Na Wale Miedzeszyńskim, na jezdni w kierunku centrum zderzył się citroen i bus, poszkodowanych zostało osiem osób. Kilkadziesiąt minut później na tej samej ulicy  zderzyła się toyota z mercedesem.

## Arabia Saudyjska chce zorganizować mundial kobiet. Wciąż nie zapewnia im jednak podstawowych praw
 - [https://fakty.tvn24.pl/fakty-o-swiecie/arabia-saudyjska-chce-zorganizowac-mundial-kobiet-wciaz-nie-zapewnia-im-jednak-podstawowych-praw-7402192?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/arabia-saudyjska-chce-zorganizowac-mundial-kobiet-wciaz-nie-zapewnia-im-jednak-podstawowych-praw-7402192?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T20:33:12+00:00

<img alt="Arabia Saudyjska chce zorganizować mundial kobiet. Wciąż nie zapewnia im jednak podstawowych praw" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-c44txe-arabia-saudyjska-chce-zorganizowac-mundial-kobiet-wciaz-nie-zapewnia-im-jednak-podstawowych-praw-7402175/alternates/LANDSCAPE_1280" />
    Mają już Cristiano Ronaldo, chcą mieć mundial kobiet. Arabia Saudyjska przebojem podbija świat sportu, a szczególnie tę dyscyplinę, w której są wielkie pieniądze. Nawet wśród federacji sportowych i zawodników pojawiają się komentarze, że to próba wybielenia wizerunku. Stadiony za petrodolary nie zmienią bowiem kultury i saudyjskiego prawa, zgodnie z którym kobieta może uprawiać sport, ale nie bez zgody mężczyzny. Nawet największa impreza tego nie zmieni.

## "Oddaje hołd tym, którzy zginęli, przypomina o konsekwencjach obojętności"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/oddaje-hold-tym-ktorzy-zgineli-przypomina-o-konsekwencjach-obojetnosci-7402064?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/oddaje-hold-tym-ktorzy-zgineli-przypomina-o-konsekwencjach-obojetnosci-7402064?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T19:56:05+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-3dn9cw-mural-autorstwa-wilhelma-sasnala-7402238/alternates/LANDSCAPE_1280" />
    W Muzeum Historii Żydów Polskich POLIN odsłonięto mural autorstwa jednego z najbardziej znanych polskich artystów, Wilhelma Sasnala. Mural przedstawia bezbronną, ale dumnie wyprostowaną kobietę, prowadzoną przez żołnierza. Symbolizuje przeciwstawianie się złu.

## W kibucu doszło do rzezi. "Zapanował chaos. Weszło tu z dwustu bojowników Hamasu"
 - [https://fakty.tvn24.pl/zobacz-fakty/w-kibucu-doszlo-do-rzezi-zapanowal-chaos-weszlo-tu-z-dwustu-bojownikow-hamasu-7402132?source=rss](https://fakty.tvn24.pl/zobacz-fakty/w-kibucu-doszlo-do-rzezi-zapanowal-chaos-weszlo-tu-z-dwustu-bojownikow-hamasu-7402132?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T19:52:27+00:00

<img alt="W kibucu doszło do rzezi. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-bqeuaw-w-kibucu-doszlo-do-rzezi-zapanowal-chaos-weszlo-tu-z-dwustu-bojownikow-hamasu-7402133/alternates/LANDSCAPE_1280" />
    Życie na południu Izraela jeszcze długo nie wróci do normy. Hamas zaatakował jednocześnie w 21 miejscach. Zginęło 1300 osób, a około 200 jest przetrzymywanych w Strefie Gazy.

## Donald Tusk wyjedzie do Brukseli z misją. "Wszyscy tych pieniędzy potrzebujemy"
 - [https://fakty.tvn24.pl/zobacz-fakty/kpo-donald-tusk-wyjezdza-do-brukseli-z-misja-wszyscy-tych-pieniedzy-potrzebujemy-7402120?source=rss](https://fakty.tvn24.pl/zobacz-fakty/kpo-donald-tusk-wyjezdza-do-brukseli-z-misja-wszyscy-tych-pieniedzy-potrzebujemy-7402120?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T19:46:30+00:00

<img alt="Donald Tusk wyjedzie do Brukseli z misją. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-ep5q5z-donald-tusk-wyjezdza-do-brukseli-z-misja-wszyscy-tych-pieniedzy-potrzebujemy-7402052/alternates/LANDSCAPE_1280" />
    Kiedy Polacy dostaną miliardy euro na KPO? Donald Tusk w przyszłym tygodniu jedzie rozmawiać o tym w Brukseli, ale przecież pieniędzy nie przywiezie od razu w walizkach. Te pieniądze od dawna Polakom się po prostu należą. Są pilnie potrzebne. Rząd PiS zostawia po sobie w budżecie dziurę.

## Opłata na rachunku za prąd jednak w górę. Jest rozporządzenie
 - [https://tvn24.pl/biznes/pieniadze/ceny-pradu-2024-oplata-kogeneracyjna-w-gore-jest-rozporzadzenie-ministerstwa-klimatu-i-srodowiska-7402131?source=rss](https://tvn24.pl/biznes/pieniadze/ceny-pradu-2024-oplata-kogeneracyjna-w-gore-jest-rozporzadzenie-ministerstwa-klimatu-i-srodowiska-7402131?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T18:22:34+00:00

<img alt="Opłata na rachunku za prąd jednak w górę. Jest rozporządzenie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-qmzd9i-prad-gniazdko-2220917/alternates/LANDSCAPE_1280" />
    Stawka opłaty kogeneracyjnej w 2024 roku wzrośnie do 6,18 zł za megawatogodzinę (MWh) z 4,96 zł w tym roku. Tak wynika z rozporządzenia Ministerstwa Klimatu i Środowiska, które opublikowano w piątek. Pierwotnie resort zapowiadał, że wysokość opłaty nie zmieni się. Opłata kogeneracyjna to jedna z pozycji na rachunku za prąd.

## Pogoda na jutro - sobota 21.10. Nocą może silnie wiać. Za dnia miejscami powyżej 20 stopni i burze
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-2110noca-moze-silnie-wiac-za-dnia-miejscami-powyzej-20-stopni-i-burze-7401910?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-jutro-sobota-2110noca-moze-silnie-wiac-za-dnia-miejscami-powyzej-20-stopni-i-burze-7401910?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T17:13:04+00:00

<img alt="Pogoda na jutro - sobota 21.10. Nocą może silnie wiać. Za dnia miejscami powyżej 20 stopni i burze" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ev5jk1-noc-deszcz-opady-deszczu-6628653/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na sobotę 21.10. Kolejne godziny na znacznym obszarze kraju będą pochmurne i deszczowe. Spodziewane są silne podmuchy wiatru. W dzień w niektórych regionach po południu może zagrzmieć. Termometry pokażą od 10 do 23 stopni Celsjusza.

## Spacerował nad rzeką, zauważył ciało mężczyzny
 - [https://tvn24.pl/lublin/chlewiska-spacerowicz-zauwazyl-w-rzece-zwloki-mezczyzny-policja-sprawdza-jak-zginal-7401940?source=rss](https://tvn24.pl/lublin/chlewiska-spacerowicz-zauwazyl-w-rzece-zwloki-mezczyzny-policja-sprawdza-jak-zginal-7401940?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T16:13:22+00:00

<img alt="Spacerował nad rzeką, zauważył ciało mężczyzny" src="https://tvn24.pl/najnowsze/cdn-zdjecie-69tbpl-w-rzece-wieprz-odnaleziono-zwloki-mezczyzny-7401944/alternates/LANDSCAPE_1280" />
    Policja pod nadzorem prokuratury wyjaśnia przyczyny i okoliczności śmierci 61-letniego mężczyzny, którego zwłoki wyłowiono z rzeki Wieprz w miejscowości Chlewiska (woj. lubelskie).

## 21-latek nie miał uprawnień do prowadzenia auta, policjantom powiedział, że "jedzie zapisać się na egzamin"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/21-latek-nie-mial-uprawnien-do-prowadzenia-auta-policjantom-powiedzial-ze-jedzie-zapisac-sie-na-egzamin-7401882?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/21-latek-nie-mial-uprawnien-do-prowadzenia-auta-policjantom-powiedzial-ze-jedzie-zapisac-sie-na-egzamin-7401882?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T16:02:11+00:00

<img alt="21-latek nie miał uprawnień do prowadzenia auta, policjantom powiedział, że " src="https://tvn24.pl/najnowsze/cdn-zdjecie-bgje0k-kierowca-przekroczyl-dozwolona-predkosc-zdjecie-ilustracyjne-7401902/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali do kontroli 21-letniego kierowcę volkswagena. Powodem było przekroczenie dozwolonej prędkości. Na jaw wyszło, że mężczyzna nie ma uprawnień do kierowania autem. Mundurowym tłumaczył, że... jedzie zapisać się na egzamin.

## Z samorządów przechodzą do Sejmu. Apelują o wyznaczenie "niepolitycznych komisarzy"
 - [https://tvn24.pl/rzeszow/ustrzyki-dolne-swilcza-z-samorzadu-do-sejmu-wojta-i-burmistrza-zastapia-komisarze-nie-chca-nominatow-z-pis-u-7401825?source=rss](https://tvn24.pl/rzeszow/ustrzyki-dolne-swilcza-z-samorzadu-do-sejmu-wojta-i-burmistrza-zastapia-komisarze-nie-chca-nominatow-z-pis-u-7401825?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T15:46:12+00:00

<img alt="Z samorządów przechodzą do Sejmu. Apelują o wyznaczenie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6fd7ax-bartosz-romowicz-burmistrz-ustrzyk-dolnych-6207279/alternates/LANDSCAPE_1280" />
    Wójt gminy Świlcza Adam Dziedzic i burmistrz Ustrzyk Dolnych Bartosz Romowicz startujący z list Trzeciej Drogi na Podkarpaciu zdobyli mandaty poselskie w niedzielnych wyborach. Samorządowcy zaapelowali do wojewody podkarpackiej Ewy Leniart o wskazanie "niepolitycznych komisarzy" na ich miejsce.

## Czeka nas powrót burz. Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-burze-i-bardzo-duze-roznice-temperatury-bedzie-ponad-20-stopni-7401713?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-weekend-burze-i-bardzo-duze-roznice-temperatury-bedzie-ponad-20-stopni-7401713?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T15:06:50+00:00

<img alt="Czeka nas powrót burz. Pogoda na 5 dni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-6i2ora-burze-7401820/alternates/LANDSCAPE_1280" />
    W weekend temperatura w części kraju przekroczy 20 stopni Celsjusza. Na dużym obszarze Polski będzie deszczowo, a w niektórych regionach pojawią się również burze. Na większą ilość słońca trzeba poczekać do następnego tygodnia.

## Niemiecka minister chce deportować popleczników Hamasu. "Musimy to zrobić"
 - [https://tvn24.pl/swiat/niemiecka-minister-chce-deportowac-poplecznikow-hamasu-7401702?source=rss](https://tvn24.pl/swiat/niemiecka-minister-chce-deportowac-poplecznikow-hamasu-7401702?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T14:43:45+00:00

<img alt="Niemiecka minister chce deportować popleczników Hamasu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6rmd64-pap_20231018_1vv-7401760/alternates/LANDSCAPE_1280" />
    Zwolennicy Hamasu powinni zostać deportowani z kraju, jeśli to możliwe - oświadczyła w piątek minister spraw wewnętrznych Niemiec. Dodała, że tamtejsze władze będą bacznie obserwować islamskich ekstremistów.

## "Powstał z miłości do Warszawy", ściana skateparku zburzona bez uprzedzenia. Co dalej z Szaber Bowl?
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/powstal-z-milosci-do-warszawy-sciana-skateparku-zburzona-bez-uprzedzenia-co-dalej-z-szaber-bowl-7401445?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/powstal-z-milosci-do-warszawy-sciana-skateparku-zburzona-bez-uprzedzenia-co-dalej-z-szaber-bowl-7401445?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T14:40:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gb2ga4-mjn-sciana-popularnego-skateparku-wyburzona-bez-uprzedzenia-7401761/alternates/LANDSCAPE_1280" />
    Jedna ze ścian popularnego skateparku pod remontowanym mostem Poniatowskiego została wyburzona - alarmują aktywiści z Miasto Jest Nasze. Zarząd Dróg Miejskich tłumaczy, że wykonawca prac występował o zgodę na rozebranie części rampy do Zarządu Terenów Publicznych, który odpowiada za to miejsce i taką zgodę dostał. Podkreśla też, że Szaber Bowl jest samowolą budowlaną, która powinna być rozebrana. Sprawę komplikuje jednak brak "właściciela" obiektu.

## "Rzeczpospolita": są dwie sprzeczne notatki służbowe po wypadku na A1. Bada to prokuratura, stanowisko policji
 - [https://tvn24.pl/lodz/sieroslaw-tragedia-na-autostradzie-a1-rzeczpospolita-sporzadzono-dwie-notatki-policyjne-ktore-sobie-przecza-7401081?source=rss](https://tvn24.pl/lodz/sieroslaw-tragedia-na-autostradzie-a1-rzeczpospolita-sporzadzono-dwie-notatki-policyjne-ktore-sobie-przecza-7401081?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T12:39:58+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3oee4v-tragiczny-wypadek-na-autostradzie-a1-kolo-piotrkowa-trybunalskiego-7352239/alternates/LANDSCAPE_1280" />
    Dwie notatki policyjne z przeczącą sobie treścią miały zostać sporządzone po tragicznym wypadku na autostradzie A1 pod Piotrkowem Trybunalskim, w którym zginęła trzyosobowa rodzina - informuje "Rzeczpospolita". Prokuratura Okręgowa w Warszawie, do której trafiły materiały wyłączone z postępowania piotrkowskiej prokuratury, prowadzi śledztwo w sprawie niedopełnienia obowiązków lub przekroczenia uprawnień przez funkcjonariusza publicznego. - Nie jest możliwe wskazanie, co było podstawą do wszczęcia tego postępowania - przekazują śledczy.

## Przyszła zagłosować, dostała ścieralny długopis. Sprawą zajmuje się policja
 - [https://tvn24.pl/lublin/lublin-przyszla-zaglosowac-dostala-scieralny-dlugopis-sprawa-zajmuje-sie-policja-7401285?source=rss](https://tvn24.pl/lublin/lublin-przyszla-zaglosowac-dostala-scieralny-dlugopis-sprawa-zajmuje-sie-policja-7401285?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T12:11:36+00:00

<img alt="Przyszła zagłosować, dostała ścieralny długopis. Sprawą zajmuje się policja" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6uxqf8-zauwazyla-ze-dlugopis-ma-gumke-zdjecie-ilustracyjne-7401097/alternates/LANDSCAPE_1280" />
    Kobieta głosująca w jednym z lokali wyborczych w Lublinie chciała postawić krzyżyk przy wybranym nazwisku, ale zauważyła, że robi to ścieralnym długopisem. Na miejscu interweniowała policja. Długopis został zabezpieczony. Trwają ustalenia, czy wydał go kogoś z komisji wyborczej, czy może został przyniesiony do lokalu przez kogoś z głosujących.

## Ewa Leja, producentka "MasterChefa", z nagrodą Akademii Gastronomicznej
 - [https://tvn24.pl/kultura-i-styl/masterchef-ewa-leja-producentka-programu-z-prestizowa-nagroda-ars-coquinaria-7401083?source=rss](https://tvn24.pl/kultura-i-styl/masterchef-ewa-leja-producentka-programu-z-prestizowa-nagroda-ars-coquinaria-7401083?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T11:33:48+00:00

<img alt="Ewa Leja, producentka " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wzje5j-ewa-leja-producentka-masterchefa-7401177/alternates/LANDSCAPE_1280" />
    Ewa Leja, producentka programów TVN "MasterChef" i "MasterChef Junior", dostała prestiżową nagrodę Ars Coquinaria przyznawaną przez Akademię Gastronomiczną w Polsce. Została wyróżniona jako Przyjaciel Smaku.

## Briefing Zbigniewa Ziobry. Dziennikarze próbują zadać pytania
 - [https://tvn24.pl/wybory-parlamentarne-2023/pytania-do-zbigniewa-ziobry-na-briefingu-minister-nie-odpowiedzial-7401134?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/pytania-do-zbigniewa-ziobry-na-briefingu-minister-nie-odpowiedzial-7401134?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T11:18:54+00:00

<img alt="Briefing Zbigniewa Ziobry. Dziennikarze próbują zadać pytania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vsf4d4-ziobro-7401092/alternates/LANDSCAPE_1280" />
    Reporterka TVN24 Karolina Wasilewska próbowała zapytać ministra sprawiedliwości, prokuratora generalnego Zbigniewa Ziobrę na briefingu prasowym o przyszłość Suwerennej Polski, koalicjanta PiS. Ziobro nie odpowiadał na pytania dziennikarzy. Wyszedł tuż po wygłoszeniu oświadczenia.

## Utrudnienia w kilku bankach. "Nie zalogujesz się"
 - [https://tvn24.pl/biznes/z-kraju/przerwy-i-prace-serwisowe-w-bankach-santander-bank-polska-ing-bank-slaski-bnp-paribas-pocztowy-velo-nest-lista-7400387?source=rss](https://tvn24.pl/biznes/z-kraju/przerwy-i-prace-serwisowe-w-bankach-santander-bank-polska-ing-bank-slaski-bnp-paribas-pocztowy-velo-nest-lista-7400387?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T11:15:37+00:00

<img alt="Utrudnienia w kilku bankach. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t0l4r6-38-latek-zostal-oszukany-metoda-na-pracownika-banku-zdj-ilustracyjne-7396409/alternates/LANDSCAPE_1280" />
    Santander Bank Polska, ING Bank Śląski, BNP Paribas czy Bank Pocztowy - to tylko niektóre banki, które zaplanowały prace serwisowe w najbliższych dniach. W związku z tym klienci muszą przygotować się na utrudnienia. Część osób nie będzie mogła się zalogować do bankowości internetowej i mobilnej.

## Straciła panowanie nad autem i wjechała do kanału. Wiozła dwoje małych dzieci
 - [https://tvn24.pl/rzeszow/krawce-panowanie-nad-kierownica-i-wjechala-do-kanalu-z-woda-26-latka-wiozla-dwoje-dzieci-7400876?source=rss](https://tvn24.pl/rzeszow/krawce-panowanie-nad-kierownica-i-wjechala-do-kanalu-z-woda-26-latka-wiozla-dwoje-dzieci-7400876?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T10:09:29+00:00

<img alt="Straciła panowanie nad autem i wjechała do kanału. Wiozła dwoje małych dzieci " src="https://tvn24.pl/najnowsze/cdn-zdjecie-113x9x-w-samochodzie-wiosla-dwoje-dzieci-7400902/alternates/LANDSCAPE_1280" />
    26-letnia kobieta i jej trzyletnie dziecko trafili do szpitala w wyniku wypadku, do którego doszło w miejscowości Krawce (woj. podkarpackie). 26-latka straciła panowanie nad kierownicą i wjechała do kanału. Wiozła dwoje małych dzieci.

## Uderzył w drzewa, autem zawisł na jednym z nich. 25-latek nie żyje
 - [https://tvn24.pl/bialystok/stare-konopki-uderzyl-w-drzewa-autem-zawisl-na-jednym-z-nich-25-latek-nie-zyje-7400881?source=rss](https://tvn24.pl/bialystok/stare-konopki-uderzyl-w-drzewa-autem-zawisl-na-jednym-z-nich-25-latek-nie-zyje-7400881?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T10:00:17+00:00

<img alt="Uderzył w drzewa, autem zawisł na jednym z nich. 25-latek nie żyje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aljpbj-auto-wbilo-sie-w-drzewo-7400885/alternates/LANDSCAPE_1280" />
    Wypadek w rejonie miejscowości Stare Konopki (woj. podlaskie). 25-letni wypadł z drogi i uderzył w drzewa. Siła uderzenia była tak duża, że z auta wypadł silnik, a pojazd zawisł na drzewie. Kierowca podróżował sam. Nie przeżył.

## "10-latek zapomniał się upewnić, czy może bezpiecznie przejść przez jezdnię". Chłopca potrącił samochód. Nagranie
 - [https://tvn24.pl/katowice/zory-wyszedl-ze-sklepu-po-chwili-10-latek-wbiegl-wprost-pod-samochod-policja-pokazuje-nagranie-7400622?source=rss](https://tvn24.pl/katowice/zory-wyszedl-ze-sklepu-po-chwili-10-latek-wbiegl-wprost-pod-samochod-policja-pokazuje-nagranie-7400622?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T09:01:22+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-s5vhba-chlopiec-wtargnal-na-jezdnie-7400596/alternates/LANDSCAPE_1280" />
    W Żorach (woj. śląskie) 10-latek wbiegł na jezdnię i został potrącony przez auto. Policja pokazuje nagranie ze zdarzenia i podkreśla, że chłopiec nie upewnił się, czy może bezpiecznie pokonać ulicę.

## Gwiazdy "Skazanej" o trzecim sezonie serialu. Kogo zobaczymy w nowej serii?
 - [https://tvn24.pl/kultura-i-styl/skazana-3-kiedy-premiera-nowi-aktorzy-i-ciekawostki-z-planu-serialu-7400709?source=rss](https://tvn24.pl/kultura-i-styl/skazana-3-kiedy-premiera-nowi-aktorzy-i-ciekawostki-z-planu-serialu-7400709?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T08:58:58+00:00

<img alt="Gwiazdy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7m5egp-skazana-3-kosa-marta-malikowska-7400712/alternates/LANDSCAPE_1280" />
    Już 10 listopada w Playerze premiera pierwszego odcinka "Skazanej 3". Nowa seria wielkiego hitu będzie miała siedem odcinków. Pojawią się nowi aktorzy, a na jaw wyjdą kolejne tajemnice. Producenci zapowiadają też zwroty akcji. Czego możemy się spodziewać?

## Czerwone światło na sygnalizatorze, autokar na przejeździe kolejowym. Kierowca "mówił, że nie zauważył"
 - [https://tvn24.pl/poznan/patrzykow-kierowca-autokaru-wjechal-na-przejazd-kolejowy-gdy-palilo-sie-czerwone-swiatlo-opadly-rogatki-nagranie-7400467?source=rss](https://tvn24.pl/poznan/patrzykow-kierowca-autokaru-wjechal-na-przejazd-kolejowy-gdy-palilo-sie-czerwone-swiatlo-opadly-rogatki-nagranie-7400467?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T08:40:13+00:00

<img alt="Czerwone światło na sygnalizatorze, autokar na przejeździe kolejowym. Kierowca " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m0lrli-wjechal-na-przejazd-po-chwili-na-autobus-opadla-rogatka-7400432/alternates/LANDSCAPE_1280" />
    Kara grzywny grozi 60-letniemu kierowcy autokaru, który zignorował sygnalizację i wjechał na przejazd kolejowy w Patrzykowie (woj. wielkopolskie) w trakcie zamykania się rogatek. Jedna z nich opadła na pojazd. Nagranie ze zdarzenia opublikowała policja.

## Toksyczny gaz zbierał się w łazience. 14-latka trafiła do szpitala
 - [https://tvn24.pl/rzeszow/przemysl-14-latka-zatrula-sie-czadem-7400665?source=rss](https://tvn24.pl/rzeszow/przemysl-14-latka-zatrula-sie-czadem-7400665?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T08:39:30+00:00

<img alt="Toksyczny gaz zbierał się w łazience. 14-latka trafiła do szpitala" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fnxiax-wanna-5066324/alternates/LANDSCAPE_1280" />
    14-letnia dziewczyna trafiła do szpitala w Przemyślu (woj. podkarpackie) z objawiamy zatrucia tlenkiem węgla. Toksyczny gaz zbierał się w łazience. Strażacy apelują o przeglądy instalacji grzewczych i montaż czujników tlenku węgla.

## Straż miejska może wystawić mandat za jazdę rowerem lub hulajnogą po chodniku
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-straz-miejska-z-nowymi-uprawnieniami-moze-wystawic-mandat-za-jazde-rowerem-lub-hulajnoga-po-chodniku-7400399?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-straz-miejska-z-nowymi-uprawnieniami-moze-wystawic-mandat-za-jazde-rowerem-lub-hulajnoga-po-chodniku-7400399?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T07:54:25+00:00

<img alt="Straż miejska może wystawić mandat za jazdę rowerem lub hulajnogą po chodniku" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ia4j52-mandaty-za-jazde-hulajnoga-zdj-ilustracyjne-7400640/alternates/LANDSCAPE_1280" />
    W piątek 20 października weszła w życie nowelizacja przepisów, która nadaje strażnikom miejskim nowe uprawnienia mandatowe. Od piątku funkcjonariusze tej formacji będą mogli ukarać mandatem w wysokości do 200 złotych osoby jeżdżące rowerem czy hulajnogą bez uprawnień. Z kolei sąd może nałożyć na sprawcę grzywnę w wysokości 1500 zł.

## Zderzenie trzech aut. Ciężarówka na boku, jabłka w rowie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/kamion-pod-zyrardowem-zderzenie-trzech-pojazdow-ciezarowka-na-boku-jablka-w-rowie-7400534?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/kamion-pod-zyrardowem-zderzenie-trzech-pojazdow-ciezarowka-na-boku-jablka-w-rowie-7400534?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T07:33:29+00:00

<img alt="Zderzenie trzech aut. Ciężarówka na boku, jabłka w rowie" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-560rrc-zderzenie-pod-zyrardowem-7400573/alternates/LANDSCAPE_1280" />
    W Kamionie pod Żyrardowem (Mazowieckie) doszło do zderzenia trzech pojazdów. Przewróciła się ciężarówka przewożąca jabłka, a cały ładunek wylądował w rowie i na jezdni. Utrudnienia potrwają kilka godzin.

## W Madrycie tak obficie nie padało od 163 lat
 - [https://tvn24.pl/tvnmeteo/swiat/madryt-wodospady-na-ulicach-polamane-drzewa-ewakuacje-ponad-tysiac-interwencji-po-przejsciu-burzy-aline-7400530?source=rss](https://tvn24.pl/tvnmeteo/swiat/madryt-wodospady-na-ulicach-polamane-drzewa-ewakuacje-ponad-tysiac-interwencji-po-przejsciu-burzy-aline-7400530?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T07:25:09+00:00

<img alt="W Madrycie tak obficie nie padało od 163 lat" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-p9uuxk-ulewy-nawiedzily-madryt-7401640/alternates/LANDSCAPE_1280" />
    Burza Aline przeszła w czwartek nad Półwyspem Iberyjskim. W Madrycie, stolicy Hiszpanii, żywioł przyniósł ze sobą opady, jakich nie zanotowano od ponad 160 lat. Woda wdzierała się na stacje metra i do przejść podziemnych, zalewała domy i samochody.

## Wyniki Lotto z 19 października 2023. Jakie liczby padły podczas ostatniego losowania?
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia191023-liczby-z-ostatniego-losowania-7400377?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-z-dnia191023-liczby-z-ostatniego-losowania-7400377?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T07:23:35+00:00

<img alt="Wyniki Lotto z 19 października 2023. Jakie liczby padły podczas ostatniego losowania?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-b9g3az-gdzie-padla-wygrana-3651170/alternates/LANDSCAPE_1280" />
    W czwartek w Lotto nie padła główna wygrana. W najbliższym losowaniu będzie można wygrać 7 milionów złotych. Oto wyniki Lotto oraz Lotto Plus z 19 października 2023 roku.

## Jechał za szybko, wyprzedzał na przejściu dla pieszych. Kierowca ferrari nie przyjął mandatu
 - [https://tvn24.pl/lubuskie/zielona-gora-jechal-za-szybko-wyprzedzal-na-przejsciu-dla-pieszych-kierowca-ferrari-nie-przyjal-mandatu-7400520?source=rss](https://tvn24.pl/lubuskie/zielona-gora-jechal-za-szybko-wyprzedzal-na-przejsciu-dla-pieszych-kierowca-ferrari-nie-przyjal-mandatu-7400520?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T06:44:25+00:00

<img alt="Jechał za szybko, wyprzedzał na przejściu dla pieszych. Kierowca ferrari nie przyjął mandatu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xxgk0q-jechal-za-szybko-wyprzedzil-na-przejsciu-kierowca-ferrari-nie-przyjal-mandatu-7400493/alternates/LANDSCAPE_1280" />
    Policjanci z Zielonej Góry zauważyli kierowcę ferrari, który w terenie zabudowanym jechał szybciej, niż pozwalają na to przepisy. Co więcej, wyprzedzał inne auto na przejściu dla pieszych. Kierowcy groził wysoki mandat i pokaźna liczba punktów karnych, ale nie zdecydował się przyjąć kary pieniężnej. Sprawą zajmie się teraz sąd.

## Zmiany klimatu wymuszają ekspansję rolnictwa. Coraz bardziej cierpi przez to dzika przyroda
 - [https://tvn24.pl/tvnmeteo/nauka/zmiany-klimatu-wymuszaja-ekspansje-rolnictwa-coraz-bardziej-cierpi-przez-to-dzika-przyroda-7400419?source=rss](https://tvn24.pl/tvnmeteo/nauka/zmiany-klimatu-wymuszaja-ekspansje-rolnictwa-coraz-bardziej-cierpi-przez-to-dzika-przyroda-7400419?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T06:30:12+00:00

<img alt="Zmiany klimatu wymuszają ekspansję rolnictwa. Coraz bardziej cierpi przez to dzika przyroda" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zer19v-przeksztalcanie-obszarow-dzikiej-przyrody-sprawia-ze-cierpia-zwierzeta-7400472/alternates/LANDSCAPE_1280" />
    Z powodu zmian klimatu, rolnictwo przenosi się na coraz szersze obszary. Według nowych badań, za kilkadziesiąt lat grunty przeznaczone pod uprawę będą rozciągać się niemal na całym globie. W procesie najbardziej ucierpią obszary dzikie, w tym zamieszkujące je zwierzęta.

## Zderzył się z ciągnikiem, jego auto stanęło w płomieniach. 19-latek w szpitalu
 - [https://tvn24.pl/lodz/krezelewice-leczyca-wjechal-w-ciagnik-rolniczy-auto-zapalilo-sie-19-latek-w-szpitalu-7400411?source=rss](https://tvn24.pl/lodz/krezelewice-leczyca-wjechal-w-ciagnik-rolniczy-auto-zapalilo-sie-19-latek-w-szpitalu-7400411?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T06:11:38+00:00

<img alt="Zderzył się z ciągnikiem, jego auto stanęło w płomieniach. 19-latek w szpitalu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dyaz5m-samochod-splonal-po-zderzeniu-z-ciagnikiem-rolniczym-7400405/alternates/LANDSCAPE_1280" />
    Samochód osobowy spłonął po zderzeniu z ciągnikiem rolniczym na drodze krajowej nr 91 w Krężelewicach (woj. łódzkie). Jak informuje policja, ranny został 19-letni kierowca auta. Droga była zablokowana kilka godzin.

## W weekend asfaltowanie na Grochowie i Woli
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-w-weekend-asfaltowanie-na-grochowskiej-i-wolskiej-7399160?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-w-weekend-asfaltowanie-na-grochowskiej-i-wolskiej-7399160?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T05:57:36+00:00

<img alt="W weekend asfaltowanie na Grochowie i Woli" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-vpk4eo-w-weekend-asfaltowanie-na-pradze-poludnie-i-woli-zdj-ilustracyjne-7399168/alternates/LANDSCAPE_1280" />
    W najbliższy weekend, 20-22 października, drogowcy mają w planach remont nawierzchni prawego pasa ulicy Grochowskiej. Nowy asfalt pojawi się na jezdni w stronę ulicy Marsa - na odcinku od Podolskiej do Jubilerskiej. W tym samym czasie podobne prace przeprowadzą również budowniczowie trasy tramwajowej na Woli - wyrównają nawierzchnię na ulicy Wolskiej - między Redutową a Sowińskiego.

## Strefa Gazy. USA chce wysłać pomoc dla cywilów i utworzyć bezpieczne strefy. Trwają negocjacje
 - [https://tvn24.pl/swiat/strefa-gazy-usa-chce-wyslac-pomoc-dla-cywilow-i-utworzyc-bezpieczne-strefy-trwaja-negocjacje-7400344?source=rss](https://tvn24.pl/swiat/strefa-gazy-usa-chce-wyslac-pomoc-dla-cywilow-i-utworzyc-bezpieczne-strefy-trwaja-negocjacje-7400344?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T05:51:53+00:00

<img alt="Strefa Gazy. USA chce wysłać pomoc dla cywilów i utworzyć bezpieczne strefy. Trwają negocjacje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-joim42-gaza-7391170/alternates/LANDSCAPE_1280" />
    Przedstawiciele USA, Egiptu i Izraela ustalają szczegóły mechanizmu dostarczania pomocy humanitarnej do Strefy Gazy - poinformował rzecznik Departamentu Stanu USA Matthew Miller. W Gazie mają zostać utworzone również bezpieczne strefy dla cywilów.

## Uciekł do Korei Północnej, został deportowany do USA. Szereg zarzutów dla amerykańskiego żołnierza
 - [https://tvn24.pl/swiat/usa-korea-polnocna-zolnierz-travis-king-deportowany-do-usa-uslyszal-zarzuty-7400379?source=rss](https://tvn24.pl/swiat/usa-korea-polnocna-zolnierz-travis-king-deportowany-do-usa-uslyszal-zarzuty-7400379?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T05:16:32+00:00

<img alt="Uciekł do Korei Północnej, został deportowany do USA. Szereg zarzutów dla amerykańskiego żołnierza" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jpzgo1-travis-king-7400389/alternates/LANDSCAPE_1280" />
    23-letni amerykański żołnierz Travis King usłyszał szereg zarzutów po tym, jak został deportowany z Korei Północnej - poinformował Reuters. Poza dezercją, dotyczą one też napaści na innych żołnierzy i posiadania dziecięcej pornografii.

## Niebezpieczne godziny w kilku regionach. Alerty IMGW drugiego stopnia
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-i-intensywne-opady-deszczu-pomaranczowe-ostrzezenia-7400378?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-i-intensywne-opady-deszczu-pomaranczowe-ostrzezenia-7400378?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T04:34:40+00:00

<img alt="Niebezpieczne godziny w kilku regionach. Alerty IMGW drugiego stopnia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-dhsgrx-silny-wiatr-5605776/alternates/LANDSCAPE_1280" />
    Instytut Meteorologii i Gospodarki Wodnej ostrzega przed silnym wiatrem na północy i południu kraju. Dla niektórych województw ogłoszono alerty drugiego stopnia. W północnych regionach możliwe są również intensywne opady deszczu, przed czym także ostrzega IMGW.

## Porywisty wiatr w części kraju. Są alerty IMGW, także drugiego stopnia
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-porywisty-wiatr-w-czesci-kraju-alarmy-drugiego-i-pierwszego-stopnia-pogoda-w-piatek-2010-7400378?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-porywisty-wiatr-w-czesci-kraju-alarmy-drugiego-i-pierwszego-stopnia-pogoda-w-piatek-2010-7400378?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T04:34:40+00:00

<img alt="Porywisty wiatr w części kraju. Są alerty IMGW, także drugiego stopnia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ul0yoc-silny-wiatr-6757549/alternates/LANDSCAPE_1280" />
    IMGW ostrzega przed niebezpieczną pogodą. W niektórych regionach obowiązują alarmy drugiego i pierwszego stopnia. Sprawdź, gdzie wydano ostrzeżenia.

## Joe Biden z orędziem do narodu. Mówił o zagrożeniu Rosji, Polsce, państwach bałtyckich, Ukrainie i terroryzmie
 - [https://tvn24.pl/swiat/usa-prezydent-biden-putin-juz-zagrozil-polsce-ze-jej-zachodnie-ziemie-sa-darem-od-rosji-7400371?source=rss](https://tvn24.pl/swiat/usa-prezydent-biden-putin-juz-zagrozil-polsce-ze-jej-zachodnie-ziemie-sa-darem-od-rosji-7400371?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T03:33:25+00:00

<img alt="Joe Biden z orędziem do narodu. Mówił o zagrożeniu Rosji, Polsce, państwach bałtyckich, Ukrainie i terroryzmie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6t634k-prezydent-usa-joe-biden-7400370/alternates/LANDSCAPE_1280" />
    Prezydent USA Joe Biden w orędziu do narodu stwierdził, że jeśli demokratyczna wspólnota międzynarodowa nie powstrzyma Władimira Putina, nie zatrzyma się on na Ukrainie. - Putin już zagroził, że przypomni Polsce, że jej zachodnie ziemie są "darem" od Rosji - powiedział, wskazując też na słowa płynące z Kremla pod adresem Litwy, Łotwy i Estonii. Podkreślił, że USA będą bronić każdej piędzi ziemi NATO. Joe Biden zapowiedział równocześnie, że w piątek zwróci się do Kongresu o znaczący pakiet środków dla Ukrainy i Izraela.

## Pięć rzeczy, które warto wiedzieć 20 października
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-20-pazdziernika-2023-roku-7400367?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-20-pazdziernika-2023-roku-7400367?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T03:13:04+00:00

<img alt="Pięć rzeczy, które warto wiedzieć 20 października" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9g6yso-viktor-orban-spotkal-sie-z-wladimirem-putinem-7398623/alternates/LANDSCAPE_1280" />
    Zarząd Platformy Obywatelskiej upoważnił Donalda Tuska do rozmów koalicyjnych. Sędzia Paweł Juszczyszyn został laureatem tegorocznej Nagrody imienia Edwarda Wende. Z kolei na Viktora Orbana spada krytyka za spotkanie z Władimirem Putinem w Pekinie. Oto pięć rzeczy, które warto wiedzieć 20 października.

## NATO intensyfikuje patrole na Morzu Bałtyckim w związku z uszkodzeniami infrastruktury podmorskiej
 - [https://tvn24.pl/swiat/nato-intensyfikuje-patrole-na-morzu-baltyckim-w-zwiazku-z-uszkodzeniami-infrastruktury-podmorskiej-7400345?source=rss](https://tvn24.pl/swiat/nato-intensyfikuje-patrole-na-morzu-baltyckim-w-zwiazku-z-uszkodzeniami-infrastruktury-podmorskiej-7400345?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T03:11:26+00:00

<img alt="NATO intensyfikuje patrole na Morzu Bałtyckim w związku z uszkodzeniami infrastruktury podmorskiej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjyxye-pilot-hiszpanskiego-f-18s-obserwuje-rosyjska-maszyne-nad-morzem-baltyckim-5693071/alternates/LANDSCAPE_1280" />
    NATO zwiększa działania związane z ochroną infrastruktury podmorskiej w regionie Morza Bałtyckiego. Decyzję tę podjęło w konsekwencji uszkodzenia kabla telekomunikacyjnego łączącego Szwecję i Estonię oraz gazociągu Balticconnector, łączącego Finlandię z Estonią.

## Pogoda na dziś - piątek 20.10. Ogromna różnica temperatury pomiędzy Suwałkami a Krakowem
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-2010-ogromna-roznica-temperatury-pomiedzy-suwalkami-a-krakowem-7399862?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-2010-ogromna-roznica-temperatury-pomiedzy-suwalkami-a-krakowem-7399862?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-20T00:00:00+00:00

<img alt="Pogoda na dziś - piątek 20.10. Ogromna różnica temperatury pomiędzy Suwałkami a Krakowem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i7yt0y-deszcz-ze-sniegiem-5059788/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Piątek 20.10 w niemal całej Polsce przyniesie opady. W większości miejsc  popada deszcz i mżawka, ale w części kraju pojawią się opady deszczu ze śniegiem. Będzie duża różnica temperatury między północą a południem kraju.

