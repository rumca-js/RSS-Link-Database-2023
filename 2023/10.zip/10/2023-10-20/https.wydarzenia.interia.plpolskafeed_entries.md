# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Janina Ochojska chce nowego święta. Posłanka Lewicy: Żenujące
 - [https://wydarzenia.interia.pl/kraj/news-janina-ochojska-chce-nowego-swieta-poslanka-lewicy-zenujace,nId,7099573](https://wydarzenia.interia.pl/kraj/news-janina-ochojska-chce-nowego-swieta-poslanka-lewicy-zenujace,nId,7099573)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-20T13:39:12+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-janina-ochojska-chce-nowego-swieta-poslanka-lewicy-zenujace,nId,7099573"><img align="left" alt="Janina Ochojska chce nowego święta. Posłanka Lewicy: Żenujące" src="https://i.iplsc.com/janina-ochojska-chce-nowego-swieta-poslanka-lewicy-zenujace/000HUD8OP1YRYL4P-C321.jpg" /></a>Politycy partii opozycyjnych cieszą się z wyniku niedzielnych wyborów i możliwości stworzenia większości w przyszłym parlamencie. Choć nowy rząd KO, Trzeciej Drogi i Lewicy jeszcze nie powstał, pojawiają się pierwsze pomysły co do tego, w jaki sposób celebrować odsunięcie PiS od władzy. Eurodeputowana Janina Ochojska zaproponowała ustanowienie z tej okazji nowego święta państwowego. Pomysł ten nie spotkał się jednak z entuzjazmem.</p><br clear="all" />

## Janusz Korwin-Mikke wbija szpilę Karinie Bosak. "Mam to w nosie"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-janusz-korwin-mikke-wbija-szpile-karinie-bosak-mam-to-w-nosi,nId,7099230](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-janusz-korwin-mikke-wbija-szpile-karinie-bosak-mam-to-w-nosi,nId,7099230)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-20T12:44:52+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-janusz-korwin-mikke-wbija-szpile-karinie-bosak-mam-to-w-nosi,nId,7099230"><img align="left" alt="Janusz Korwin-Mikke wbija szpilę Karinie Bosak. &quot;Mam to w nosie&quot;" src="https://i.iplsc.com/janusz-korwin-mikke-wbija-szpile-karinie-bosak-mam-to-w-nosi/000HUC9BNMAHJC4I-C321.jpg" /></a>Możliwość zakazu wynajmu pokoi hotelowych dla par, które nie są małżeństwami - o tym kontrowersyjnym postulacie Ordo Iuris znów mówi cała Polska. Wszystko za sprawą Kariny Bosak, która broniła tego pomysłu na antenie RMF FM. Do sprawy odniósł się teraz Janusz Korwin-Mikke, którego żona Krzysztofa Bosaka pokonała w wyborczym wyścigu. &quot;Mam to w nosie, kto z kim śpi&quot; - ocenił pomysł Ordo Iuris.</p><br clear="all" />

## Straż miejska ma nowe uprawnienia. Posypią się mandaty
 - [https://wydarzenia.interia.pl/kraj/news-straz-miejska-ma-nowe-uprawnienia-posypia-sie-mandaty,nId,7099180](https://wydarzenia.interia.pl/kraj/news-straz-miejska-ma-nowe-uprawnienia-posypia-sie-mandaty,nId,7099180)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-20T10:45:56+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-straz-miejska-ma-nowe-uprawnienia-posypia-sie-mandaty,nId,7099180"><img align="left" alt="Straż miejska ma nowe uprawnienia. Posypią się mandaty" src="https://i.iplsc.com/straz-miejska-ma-nowe-uprawnienia-posypia-sie-mandaty/000HUC36IHYGBAGH-C321.jpg" /></a>Od piątku strażnicy miejscy dostają nowe uprawnienia. Będą mogli m.in. ukarać mandatem osoby jeżdżące rowerem czy hulajnogą po drodze przeznaczonej tylko dla pieszych. Mandat grozi także tym, którzy kierują pojazdem bez uprawnień. Kary nie dostaną popełniające wykroczenia dzieci. Będzie ona nałożona na rodziców.</p><br clear="all" />

## Łona o inspiracjach przy nowej płycie. "Taksówkarz jest niewidzialny"
 - [https://wydarzenia.interia.pl/autor/piotr-witwicki/news-lona-o-inspiracjach-przy-nowej-plycie-taksowkarz-jest-niewid,nId,7097138](https://wydarzenia.interia.pl/autor/piotr-witwicki/news-lona-o-inspiracjach-przy-nowej-plycie-taksowkarz-jest-niewid,nId,7097138)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-20T08:01:12+00:00

<p><a href="https://wydarzenia.interia.pl/autor/piotr-witwicki/news-lona-o-inspiracjach-przy-nowej-plycie-taksowkarz-jest-niewid,nId,7097138"><img align="left" alt="Łona o inspiracjach przy nowej płycie. &quot;Taksówkarz jest niewidzialny&quot;" src="https://i.iplsc.com/lona-o-inspiracjach-przy-nowej-plycie-taksowkarz-jest-niewid/000HU2VICU6B3IC6-C321.jpg" /></a>- Odkryłem jedną oczywistą rzecz, że taksówkarz jest niewidzialny, że taksówkarz to jest tylko para oczu w lusterku i tyle mniej więcej widzi pasażer - powiedział raper Łona, gość videocastu Piotra Witwickiego. Szczeciński raper opowiedział o kulisach tworzenia swojej nowej płyty &quot;Taxi&quot;, którą poświęca taksówkarzom i ich historiom. Artysta zabrał również głos na temat współczesnych mediów i roli polityków. - Mi się udaje prowadzić rozmowy z ludźmi, którzy głosują na PiS. Głęboko się z nimi nie zgadzam, ale jestem w stanie z nimi rozmawiać....</p><br clear="all" />

## Nieudany fortel władzy. Rubelka zyskali, ale cnotę stracili
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nieudany-fortel-wladzy-rubelka-zyskali-ale-cnote-stracili,nId,7097229](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nieudany-fortel-wladzy-rubelka-zyskali-ale-cnote-stracili,nId,7097229)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-20T05:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-nieudany-fortel-wladzy-rubelka-zyskali-ale-cnote-stracili,nId,7097229"><img align="left" alt="Nieudany fortel władzy. Rubelka zyskali, ale cnotę stracili" src="https://i.iplsc.com/nieudany-fortel-wladzy-rubelka-zyskali-ale-cnote-stracili/000HU4KNXL641U6C-C321.jpg" /></a>Opozycja zdobyłaby jeszcze więcej mandatów, gdyby Sejm, zgodnie z prawem, przeprowadził wcześniej tzw. korektę demograficzną. Przez to zaniechanie PiS wprowadził do izby niższej ośmiu posłów więcej. </p><br clear="all" />

