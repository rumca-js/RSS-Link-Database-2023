# Source:The Guardian - World, URL:https://www.theguardian.com/world/rss, language:en-US

## Russia working to undermine trust in elections globally, US intelligence says
 - [https://www.theguardian.com/world/2023/oct/20/russia-spy-network-elections-democracy-us-intelligence](https://www.theguardian.com/world/2023/oct/20/russia-spy-network-elections-democracy-us-intelligence)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T21:50:40+00:00

<p>Moscow using spy network, state-run media and social media to shake confidence in democracy, report sent to 100 countries claims</p><p>Russia is using its spy network, state-run media and social media to undermine public trust in elections around the world, according to a US intelligence report that has been shared with about 100 countries.</p><p>“<a href="https://www.theguardian.com/world/russia">Russia</a> is focused on carrying out operations to degrade public confidence in election integrity,” said the report released on Friday, citing findings from the US intelligence community.</p> <a href="https://www.theguardian.com/world/2023/oct/20/russia-spy-network-elections-democracy-us-intelligence">Continue reading...</a>

## Belgium’s justice minister resigns after Brussels terror attack
 - [https://www.theguardian.com/world/2023/oct/20/belgiums-justice-minister-resigns-after-brussels-terror-attack](https://www.theguardian.com/world/2023/oct/20/belgiums-justice-minister-resigns-after-brussels-terror-attack)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T21:45:44+00:00

<p>Vincent Van Quickenborne stands down after it emerged Islamic extremist was denied asylum and was sought for extradition</p><p>Belgium’s justice minister has resigned after it emerged that the Islamic extremist who <a href="https://www.theguardian.com/world/2023/oct/16/people-killed-brussels-shooting-police-say">shot dead two Swedes in Brussels</a> this week had been denied asylum and was sought for extradition by Tunisia.</p><p>Justice minister Vincent Van Quickenborne said late on Friday that he and other officials had been searching for details to understand how Abdesalem Lassoued had disappeared off the map two years ago after being denied asylum.</p> <a href="https://www.theguardian.com/world/2023/oct/20/belgiums-justice-minister-resigns-after-brussels-terror-attack">Continue reading...</a>

## Hearing sheds light on how Mar-a-Lago worker implicated Trump and valet
 - [https://www.theguardian.com/us-news/2023/oct/20/yuscil-taveras-trump-classified-documents-hearing](https://www.theguardian.com/us-news/2023/oct/20/yuscil-taveras-trump-classified-documents-hearing)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T21:09:34+00:00

<p>Details on how Yuscil Taveras became a cooperating witness against ex-president and Walt Nauta revealed for first time</p><p>When the technology director at <a href="https://www.theguardian.com/us-news/donaldtrump">Donald Trump’s</a> Mar-a-Lago club implicated the former US president and his valet in a scheme to erase subpoenaed security camera footage in the classified documents case, it was the culmination of weeks of talks with prosecutors about an immunity deal.</p><p>The employee – <a href="https://www.theguardian.com/us-news/2023/jul/27/trump-mar-a-lago-classified-documents-case-carlos-de-oliveira">identified as “Trump Employee 4” in the superseding indictment</a> but named by people familiar with the matter as Yuscil Taveras – became crucial to special counsel prosecutors over several weeks in July after he decided to cooperate with the criminal investigation.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/yuscil-taveras-trump-classified-documents-hearing">Con

## US man found guilty of wife’s murder in row over Zombie House Flipping show
 - [https://www.theguardian.com/us-news/2023/oct/20/david-tronnes-guilty-murdering-wife-zombie-house-florida](https://www.theguardian.com/us-news/2023/oct/20/david-tronnes-guilty-murdering-wife-zombie-house-florida)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T17:53:14+00:00

<p>Florida jury convicts David Tronnes for murder of Shanti Cooper-Tronnes after she refused to appear on home renovation show</p><p>Shanti Cooper-Tronnes abruptly walked out of a meeting with the producers of a home renovation television series that her husband coveted appearing on in 2018. She was beaten to death days later.</p><p>This week, a jury in <a href="https://www.theguardian.com/us-news/florida">Florida</a> found her husband, David Tronnes, guilty of murdering her because he was so enraged by her refusal to go on the show, which he believed would bail them out of costly improvements to their house.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/david-tronnes-guilty-murdering-wife-zombie-house-florida">Continue reading...</a>

## Police seek man suspected of shooting Maryland judge who denied him child custody
 - [https://www.theguardian.com/us-news/2023/oct/20/maryland-circuit-court-judge-andrew-wilkinson-shot-killed](https://www.theguardian.com/us-news/2023/oct/20/maryland-circuit-court-judge-andrew-wilkinson-shot-killed)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T17:18:17+00:00

<p>Judge had awarded custody of the suspect’s children to his wife on the day of the killing, authorities say</p><p>Police are searching for a man suspected of fatally shooting a Maryland judge who had awarded custody of the suspect’s children to his wife on the day of the killing, authorities said Friday.</p><p>The circuit court judge was fatally shot in the driveway of his home in Maryland on Thursday night, police have said.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/maryland-circuit-court-judge-andrew-wilkinson-shot-killed">Continue reading...</a>

## UK weather: Met Office issues second red warning for eastern Scotland
 - [https://www.theguardian.com/uk-news/2023/oct/20/uk-weather-met-office-issues-second-red-warning-for-eastern-scotland](https://www.theguardian.com/uk-news/2023/oct/20/uk-weather-met-office-issues-second-red-warning-for-eastern-scotland)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:57:50+00:00

<p>Rare warning for severe flooding and disruption covers parts of Angus and southern Aberdeenshire on Saturday</p><p>Eastern Scotland is braced for further heavy flooding and storm damage after the Met Office issued a second “danger to life” red weather warning, as the death toll from Storm Babet rose to three.</p><p>The emergency services rescued about 60 people from Brechin in Angus, but were unable to reach others stranded in their homes after the South Esk river surged to record heights, overwhelming flood defences erected seven years ago.</p> <a href="https://www.theguardian.com/uk-news/2023/oct/20/uk-weather-met-office-issues-second-red-warning-for-eastern-scotland">Continue reading...</a>

## Jim Jordan loses third House speaker vote as Republican holdouts reach 25
 - [https://www.theguardian.com/us-news/2023/oct/20/jim-jordan-house-speaker-vote](https://www.theguardian.com/us-news/2023/oct/20/jim-jordan-house-speaker-vote)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:55:31+00:00

<p>Republicans plan to retreat once again behind closed doors to chart next steps following third vote over far-right congressman</p><p>The far-right congressman Jim Jordan lost a third consecutive bid for speaker on Friday, failing to overcome entrenched opposition from a widening group of Republican holdouts, some of whom say they have received death threats for blocking his ascent to the gavel.</p><p>With the House leaderless for an 18th day, Jordan, a founder of the ultra-conservative House Freedom caucus and hard-charging ally of Donald Trump who led the congressional effort to overturn the 2020 presidential election, won 194 votes, well shy of the majority needed to be elected speaker.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/jim-jordan-house-speaker-vote">Continue reading...</a>

## Sunak reiterates support for two-state solution in meeting with Abbas
 - [https://www.theguardian.com/world/2023/oct/20/sunak-reiterates-support-for-two-state-solution-in-meeting-with-abbas](https://www.theguardian.com/world/2023/oct/20/sunak-reiterates-support-for-two-state-solution-in-meeting-with-abbas)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:52:48+00:00

<p>PM met Palestinian Authority leader in Egypt as part of tour of the region to try to prevent the conflict escalating</p><ul><li><a href="https://www.theguardian.com/world/live/2023/oct/20/israel-hamas-war-live-joe-biden-address-the-nation-gaza-ground-offensive-invasion-border-troops">Israel and Hamas at war – live updates</a></li></ul><p>Rishi Sunak has held talks in Cairo with the leader of the Palestinian Authority, Mahmoud Abbas, where the two men condemned Hamas and the prime minister reiterated the UK’s support for a two-state solution to the Israeli-Palestinian conflict.</p><p>“The leaders agreed on the need for all parties to take steps to protect civilians, and civilian infrastructure, and minimise the loss of innocent lives,” a spokesperson for Sunak said.</p> <a href="https://www.theguardian.com/world/2023/oct/20/sunak-reiterates-support-for-two-state-solution-in-meeting-with-abbas">Continue reading...</a>

## Pro-Trump lawyer accepts plea deal in Georgia ‘fake electors’ case
 - [https://www.theguardian.com/us-news/2023/oct/20/kenneth-chesebro-plea-deal-fulton-county-racketeering-case](https://www.theguardian.com/us-news/2023/oct/20/kenneth-chesebro-plea-deal-fulton-county-racketeering-case)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:37:11+00:00

<p>Kenneth Chesebro was facing seven felonies related to plan to falsely certify that Trump won in 2020</p><p>Kenneth Chesebro, the attorney who allegedly devised the “fake electors” plan to prevent Joe Biden from winning the 2020 election, has accepted a plea deal and will avoid going to trial in the Fulton county racketeering case in Georgia involving Donald Trump and 17 others.</p><p>Chesebro pleaded guilty on Friday morning to one felony charge of conspiracy to commit filing false documents, in a last-minute deal.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/kenneth-chesebro-plea-deal-fulton-county-racketeering-case">Continue reading...</a>

## Antisemitic hate crimes in London up 1,350%, Met police say
 - [https://www.theguardian.com/news/2023/oct/20/antisemitic-hate-crimes-in-london-rise-1350-since-israel-hamas-war-met-says](https://www.theguardian.com/news/2023/oct/20/antisemitic-hate-crimes-in-london-rise-1350-since-israel-hamas-war-met-says)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:27:08+00:00

<p>Israel-Hamas war sees hate crimes increase across UK, with Islamophobic offences in capital rising by 140%</p><ul><li><strong><a href="https://www.theguardian.com/world/live/2023/oct/20/israel-hamas-war-live-joe-biden-address-the-nation-gaza-ground-offensive-invasion-border-troops">Israel and Hamas at war – live updates</a></strong></li></ul><p>There has been a 1,350% increase in hate crimes against Jewish people as the Middle East crisis erupted, the Metropolitan police have said, with no arrests so far in nine out of 10 alleged offences.</p><p>Figures from the Met covering London show that 218 antisemitic offences were recorded from 1 October to 18 October this year, compared with 15 in the same period last year.</p> <a href="https://www.theguardian.com/news/2023/oct/20/antisemitic-hate-crimes-in-london-rise-1350-since-israel-hamas-war-met-says">Continue reading...</a>

## Biden sends $106bn aid request to Congress for Israel, Ukraine and Gaza
 - [https://www.theguardian.com/us-news/2023/oct/20/biden-israel-ukraine-gaza-aid-request-congress](https://www.theguardian.com/us-news/2023/oct/20/biden-israel-ukraine-gaza-aid-request-congress)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T16:22:30+00:00

<p>Move follows president’s prime-time address to nation but faces uncertain future with House of Representatives still paralysed</p><p>The Biden administration on Friday submitted a $106bn request to Congress for military and humanitarian aid for Israel and Ukraine and humanitarian assistance for Gaza, insisting lawmakers had an obligation to support US allies standing up to tyranny and aggression worldwide.</p><p>White House officials spelled out the urgency of the request at a morning press briefing, reinforcing Joe Biden’s assertion in a <a href="https://www.theguardian.com/us-news/2023/oct/20/joe-biden-tv-address-to-nation-oval-office-speech-vladimir-putin-hamas-aid-for-israel-ukraine">televised address to the nation</a> on Thursday night from the Oval Office that there were links between the 2022 Russian invasion of Ukraine and the deadly attacks on Israel by Hamas on 7 October.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/biden-israel-ukraine-gaza-aid-request-c

## Republican former Florida lawmaker sent to prison for Covid-19 aid fraud
 - [https://www.theguardian.com/us-news/2023/oct/20/florida-lawmaker-covid-19-fraud-prison-joe-harding](https://www.theguardian.com/us-news/2023/oct/20/florida-lawmaker-covid-19-fraud-prison-joe-harding)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T15:39:33+00:00

<p>Joe Harding, a Republican who sponsored ‘don’t say gay’ law, must serve four months for claiming $150,000 in relief funds</p><p>A former Florida state lawmaker who sponsored the state’s divisive law nicknamed <a href="https://www.theguardian.com/us-news/2022/mar/28/dont-say-gay-bill-florida-ron-desantis">don’t say gay</a> was sentenced to prison on Thursday for fraudulently collecting Covid-19 pandemic small business government aid.</p><p>The former Republican representative, Joe Harding, faced a maximum sentence of 20 years, but was sentenced to four months in federal prison.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/florida-lawmaker-covid-19-fraud-prison-joe-harding">Continue reading...</a>

## Iranian official in UK warns of danger of Israel-Hamas escalation
 - [https://www.theguardian.com/world/2023/oct/20/iranian-official-in-uk-warns-of-danger-of-israel-hamas-escalation](https://www.theguardian.com/world/2023/oct/20/iranian-official-in-uk-warns-of-danger-of-israel-hamas-escalation)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T15:00:20+00:00

<p>Chargé d’affaires at embassy says situation is very volatile and Iran has no control over ‘resistance forces’</p><ul><li><a href="https://www.theguardian.com/world/live/2023/oct/20/israel-hamas-war-live-joe-biden-address-the-nation-gaza-ground-offensive-invasion-border-troops">Israel and Hamas at war – live updates</a></li></ul><p>The war in the Middle East could expand in unpredictable and dangerous ways if Israel further increases its attacks on Gaza, Iran’s most senior diplomat in the UK has warned.</p><p>Mehdi Hosseini Matin, the Iranian chargé d’affaires, said that if this happened it was possible that UK interests would be affected.</p> <a href="https://www.theguardian.com/world/2023/oct/20/iranian-official-in-uk-warns-of-danger-of-israel-hamas-escalation">Continue reading...</a>

## Victorian Liberals’ moderate credentials looking shaky as commitment to treaty wavers
 - [https://www.theguardian.com/australia-news/2023/oct/21/victorian-liberals-moderate-credentials-looking-shaky-as-commitment-to-treaty-wavers](https://www.theguardian.com/australia-news/2023/oct/21/victorian-liberals-moderate-credentials-looking-shaky-as-commitment-to-treaty-wavers)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T14:00:21+00:00

<p>After the voice referendum, John Pesutto appears non-committal on treaty – but it’s unclear whether an about-face will be well-received in the ‘Massachusetts of Australia’</p><ul><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>It was not even 18 months ago that the Victorian Coalition was seeking to dispel the “myth” that only the Labor party supported a treaty with the state’s First Nations people.</p><p>“This side of the house, both the Liberal and the National parties, are committed to working with the Indigenous community on treaty,” the Nationals leader, Peter Walsh, <a href="https://www.parliament.vic.gov.au/images/stories/daily-hansard/Assembly_2022/Legislative_Assembly_2022-06-22.pdf">told parliament</a> last year when he spoke i

## Jewish and Arab Australians channel hopes and fears into help amid Israel-Hamas war
 - [https://www.theguardian.com/australia-news/2023/oct/21/jewish-and-arab-australians-channel-hopes-and-fears-into-help-amid-israel-hamas-war](https://www.theguardian.com/australia-news/2023/oct/21/jewish-and-arab-australians-channel-hopes-and-fears-into-help-amid-israel-hamas-war)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T14:00:20+00:00

<p>Some channel their efforts into humanitarian work while others believe political pressure can limit the loss of life</p><ul><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>As Arab and Jewish communities in Australia watch Israel prepare to embark on <a href="https://www.theguardian.com/world/2023/oct/19/israel-security-officials-signal-readiness-for-ground-offensive-into-gaza">a ground offensive in Gaza</a> they are both fearful and determined to help in any way they can.</p><p>For some, the response is humanitarian, supporting volunteer efforts in the Middle East or helping to organise and fund repatriation flights.</p> <a href="https://www.theguardian.com/australia-news/2023/oct/21/jewish-and-arab-australians-channel-hopes-and-fears-in

## Santos angers Tiwi people as it pushes ahead with plans to lay pipeline in Barossa offshore gas project
 - [https://www.theguardian.com/australia-news/2023/oct/21/santos-angers-tiwi-people-as-it-pushes-ahead-with-plans-to-lay-pipeline-in-barossa-offshore-gas-project](https://www.theguardian.com/australia-news/2023/oct/21/santos-angers-tiwi-people-as-it-pushes-ahead-with-plans-to-lay-pipeline-in-barossa-offshore-gas-project)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T14:00:20+00:00

<p>Community says company has not been in contact about plans for drilling operation ‘threatening our environment and our cultural way of life’</p><ul><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Tiwi people have expressed anger at a Santos announcement that the company plans to commence laying one of the pipelines for its Barossa offshore gas project, which they say threatens burial grounds and sacred sites.</p><p>In its <a href="https://www.santos.com/wp-content/uploads/2023/10/2023_Third_Quarter_Report.pdf">quarterly report</a>, the fossil fuel company said it had notified Australia’s offshore petroleum regulator Nopsema that it had complied with a direction issued earlier this year to survey for underwater cultural heritage sites.</p

## Twin byelection success is unalloyed good news for Labour
 - [https://www.theguardian.com/politics/2023/oct/20/twin-byelection-success-is-unalloyed-good-news-for-labour](https://www.theguardian.com/politics/2023/oct/20/twin-byelection-success-is-unalloyed-good-news-for-labour)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T11:00:55+00:00

<p>Ability to regain marginals as well as eat into Tory heartlands shows party is on course for stunning general election win</p><ul><li><strong><a href="https://www.theguardian.com/politics/live/2023/oct/20/byelections-live-tamworth-mid-bedfordshire-conservatives-tories-labour-liberal-democrats">UK politics live – latest updates</a></strong></li><li><strong><a href="https://www.theguardian.com/politics/2023/oct/20/labour-takes-nadine-dorries-former-seat-in-mid-bedfordshire-byelection">‘Historic’: Labour takes Dorries’ former seat in Mid Bedfordshire byelection</a></strong></li></ul><p>Labour are deservedly basking in their byelection successes in Mid Bedfordshire and Tamworth. The 2019 general election results left them with a mountain to climb if they were to achieve an overall majority. They needed a huge swing to reclaim many traditional marginals that had supported Tony Blair back in the day, or else make progress in constituencies that had never been Labour before even at the p

## Republicans continue effort to erode US child labor rules despite teen deaths
 - [https://www.theguardian.com/us-news/2023/oct/20/republican-child-labor-law-death](https://www.theguardian.com/us-news/2023/oct/20/republican-child-labor-law-death)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T11:00:15+00:00

<p>Violations have soared but legislative effort to strengthen protection for young workers have received little support</p><p>Child labor violations have been soaring in the US, but efforts to render solutions through legislation have received little support, and Republicans at the state level continue pushing bills that would roll back current child labor protections.</p><p>In most recent fiscal year, the US Department of Labor wage and hour division <a href="https://www.dol.gov/agencies/whd/data/charts/child-labor">reported</a> 835 cases of child labor violations affecting 3,876 minors, and 688 minors employed in violation of hazardous occupation, a <a href="https://www.epi.org/blog/florida-legislature-proposes-dangerous-roll-back-of-child-labor-protections-at-least-16-states-have-introduced-bills-putting-children-at-risk/">283%</a> increase since 2015. Civil penalties against employers totaled just under $4.3m.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/republic

## First Thing: Biden calls for urgent funding for Israel and Ukraine
 - [https://www.theguardian.com/us-news/2023/oct/20/first-thing-biden-calls-for-urgent-funding-for-israel-and-ukraine](https://www.theguardian.com/us-news/2023/oct/20/first-thing-biden-calls-for-urgent-funding-for-israel-and-ukraine)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T10:17:17+00:00

<p>US president says Americans must not walk away from their role as a ‘beacon to the world’. Plus, Britney Spears details 2008 breakdown in memoir</p><ul><li><strong><a href="https://www.theguardian.com/info/2018/sep/17/guardian-us-morning-briefing-sign-up-to-stay-informed">Don’t already get First Thing in your inbox? Sign up here</a></strong></li></ul><p>Good morning.</p><p>Joe Biden has drawn a direct, provocative <a href="https://www.theguardian.com/us-news/2023/oct/20/joe-biden-tv-address-to-nation-oval-office-speech-vladimir-putin-hamas-aid-for-israel-ukraine">link between Russia’s invasion of Ukraine and Hamas’s attack on Israel</a> as he urged Americans not to walk away from their role as “a beacon to the world”.</p><p><strong>What did Biden say?</strong> “Hamas and Putin represent different threats, but they share this in common: they both want to completely annihilate a neighboring democracy,” said Biden, sitting at the Resolute desk with flags, family photos, gold curtains

## Storm Babet live: rescue services grapple with fifth severe flood warning after ‘exceptional’ rainfall
 - [https://www.theguardian.com/world/live/2023/oct/20/storm-babet-live-uk-weather-scotland-flood-warning-latest](https://www.theguardian.com/world/live/2023/oct/20/storm-babet-live-uk-weather-scotland-flood-warning-latest)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T10:06:37+00:00

<p>Search underway in Aberdeenshire following reports of a man trapped in his vehicle in flood water</p><ul><li><a href="https://www.theguardian.com/global/2023/oct/19/tell-us-have-you-been-affected-by-storm-babet-in-the-uk">Tell us: have you been affected by Storm Babet in the UK?</a></li></ul><p>Local residents have been posting videos on X to demonstrate the power of Storm Babet.</p><p>One commenter posted a video in which he kicks a football into the air, only for it to be returned by the force of the wind:</p> <a href="https://www.theguardian.com/world/live/2023/oct/20/storm-babet-live-uk-weather-scotland-flood-warning-latest">Continue reading...</a>

## US university professors are tired of being Republican culture war targets
 - [https://www.theguardian.com/us-news/2023/oct/20/us-universities-faculty-republican-culture-war](https://www.theguardian.com/us-news/2023/oct/20/us-universities-faculty-republican-culture-war)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T09:00:13+00:00

<p>The GOP’s fight to seize control of American colleges is leading to resignations by higher education faculty</p><p>During his 18-year tenure at Louisiana’s largest public university, journalism professor Robert Mann courted backlash for speaking out against the state’s top political leaders.</p><p>Republicans called for Mann’s firing after he criticized former governor Bobby Jindal amid the state’s <a href="https://www.theguardian.com/us-news/2016/mar/09/louisiana-budget-deficit-crisis-hospitals-higher-education">2016 budget crisis.</a> In 2021, Mann drew the ire of Jeff Landry, then state attorney general, for a tweet lambasting Landry’s effort to block a Covid-19 vaccine mandate at Louisiana State University.</p> <a href="https://www.theguardian.com/us-news/2023/oct/20/us-universities-faculty-republican-culture-war">Continue reading...</a>

## Sydney businessman accused of foreign interference tells court police evidence contains ‘exaggerations’
 - [https://www.theguardian.com/australia-news/2023/oct/20/sydney-businessman-accused-of-foreign-interference-tells-court-police-evidence-contains-exaggerations](https://www.theguardian.com/australia-news/2023/oct/20/sydney-businessman-accused-of-foreign-interference-tells-court-police-evidence-contains-exaggerations)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T08:15:15+00:00

<p>Judge denies Alexander Csergo bail during hearing at Sydney’s Downing Centre on Friday</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>A Sydney businessman alleged to have been an agent for Chinese state intelligence has told a court there are “numerous exaggerations” in the police version of evidence presented against him.</p><p>Alexander Csergo, charged with one count of reckless foreign interference, is alleged to have swapped reports on business and politics with two Chinese handlers, known to him only by 

## Labour success will send chill through spines of Tory MPs
 - [https://www.theguardian.com/politics/2023/oct/20/heavy-tory-beating-in-double-labour-victory-breaks-byelection-record](https://www.theguardian.com/politics/2023/oct/20/heavy-tory-beating-in-double-labour-victory-breaks-byelection-record)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T07:50:09+00:00

<p>Tory ground troops stayed away and Tory voters stayed at home in two traditionally very Conservative areas</p><ul><li><a href="https://www.theguardian.com/politics/live/2023/oct/20/byelections-live-tamworth-mid-bedfordshire-conservatives-tories-labour-liberal-democrats">UK politics live – latest updates</a></li></ul><p>There were endless predictions before Thursday’s twin byelections, all with their own potential political messages. But as it turns out, Rishi Sunak wakes up on his trip <a href="https://www.theguardian.com/world/2023/oct/19/israel-counting-uk-continuous-support-war-hamas-netanyahu-tells-sunak">to the Middle East</a> facing the simplest, and for him, worst of them all: a double Labour victory.</p><p>Governments often get a pounding from voters and the Conservatives had heavily managed expectations in advance, briefing in particular that they fully expected to lose their near-20,000 majority in Tamworth.</p> <a href="https://www.theguardian.com/politics/2023/oct/20/h

## Queensland treaty is going ahead, assures interim body charged with implementing it
 - [https://www.theguardian.com/australia-news/2023/oct/20/queensland-treaty-is-going-ahead-assures-interim-body-charged-with-implementing-it](https://www.theguardian.com/australia-news/2023/oct/20/queensland-treaty-is-going-ahead-assures-interim-body-charged-with-implementing-it)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T07:30:38+00:00

<p>Co-chair of truth and treaty group, Aaron Fa’Aoso, says he remains confident after meeting government representatives on Friday</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The co-chair of Queensland’s interim truth and treaty body, Aaron Fa’Aoso, says the state government has given assurances that its treaty process will proceed, <a href="https://www.theguardian.com/australia-news/2023/oct/19/indigenous-queenslanders-in-double-mourning-as-states-pathway-to-treaty-loses-bipartisan-support">after the opposit

## Friday briefing: Double defeat for Tories as Labour takes two seats in byelection victory
 - [https://www.theguardian.com/world/2023/oct/20/friday-briefing-double-defeat-for-tories-as-labour-takes-two-seats-in-byelection-victory](https://www.theguardian.com/world/2023/oct/20/friday-briefing-double-defeat-for-tories-as-labour-takes-two-seats-in-byelection-victory)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T06:21:37+00:00

<p>In today’s newsletter: The Conservative party suffered a crushing defeat as Labour wins Tamworth and Mid Bedfordshire seats in historic byelections</p><p><strong>• <a href="https://www.theguardian.com/global/2022/sep/20/sign-up-for-the-first-edition-newsletter-our-free-news-email">Sign up here for our daily newsletter, First Edition</a></strong></p><p>Good morning.</p><p>So, here we go again. More byelections. Every political party has been tempering expectations: Labour said a victory for them in Tamworth or Mid Bedfordshire would be a “moonshot”, insisting that “neither of them are on our target list”. But no one has been more disheartened about their chances than the government. A <a href="https://www.theguardian.com/politics/2023/oct/19/rishi-sunak-tories-low-expectations-byelection">leaked memo</a> indicated that the Tories were expecting losses in both byelections, even though they have held Mid Bedfordshire comfortably since 1931.</p><p><em><strong>Israel</strong></em><stro

## PwC partner at centre of tax advice scandal banned by Asic for eight years
 - [https://www.theguardian.com/business/2023/oct/20/pwc-partner-at-centre-of-tax-advice-scandal-banned-by-asic-for-eight-years](https://www.theguardian.com/business/2023/oct/20/pwc-partner-at-centre-of-tax-advice-scandal-banned-by-asic-for-eight-years)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T06:20:22+00:00

<p>Financial regulator finds Peter John Collins is ‘not a fit and proper person to provide financial services’</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Australia’s financial watchdog has issued an eight-year ban to a former PwC partner at the heart of a confidentiality scandal that triggered a reputation crisis at the firm and a costly sell-off.</p><p>The Australian Securities and Investments Commission has been investigating the conduct of Peter John Collins, of Sandringham in Victoria, who has been accus

## Labour hails ‘biggest byelection shock in history’, taking Tamworth and Mid Bedfordshire from Tories – live
 - [https://www.theguardian.com/politics/live/2023/oct/20/byelections-live-tamworth-mid-bedfordshire-conservatives-tories-labour-liberal-democrats](https://www.theguardian.com/politics/live/2023/oct/20/byelections-live-tamworth-mid-bedfordshire-conservatives-tories-labour-liberal-democrats)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T05:39:05+00:00

<p>Labour wins Tamworth in Staffordshire with swing of 23.9 percentage points away from Tories, then scoops up Mid Bedfordshire in largest ever turnaround of a majority in a UK byelection. Follow the news and reaction here</p><p>Good morning. The word “historic” is overused by journalists, but even the most curmudgeonly subeditor is not going to object to it being allowed out of the cupboard this morning after Labour two byelection gains in what the party described as “the biggest byelection shock in history”.</p><p>The results came within an hour of each other. Shortly before 3am, Labour won Tamworth, the previously safe Tory seat in Staffordshire where the byelection was caused by the resignation of the former deputy chief whip over a groping scandal that contributed to the downfall of Boris Johnson. Labour won with a swing of 23.9 percentage points, the second largest swing the party has achieved in a byelection since 1945.</p><p>This is a huge night. Make no bones about it, this 

## Australia rules out cancelling Chinese company’s lease over Port of Darwin
 - [https://www.theguardian.com/world/2023/oct/20/australia-eyes-breakthrough-on-wine-as-it-moves-to-scrap-tariffs-on-chinese-wind-towers](https://www.theguardian.com/world/2023/oct/20/australia-eyes-breakthrough-on-wine-as-it-moves-to-scrap-tariffs-on-chinese-wind-towers)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T04:36:12+00:00

<p>Government also presses for removal of imposts on wine ahead of Anthony Albanese’s visit to Beijing next month</p><ul><li><strong><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></strong></li><li><strong>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></strong></li></ul><p>Australia is moving to repair ties with China ahead of Anthony Albanese’s trip to Beijing, ruling out cancelling a Chinese company’s lease over the strategically important Port of Darwin.</p><p>The move, which is likely to be welcomed by the Chinese government, comes as Australia also prepares to scrap tariffs on imports

## Russian, South African and US athletes get rushed Australian citizenships ahead of 2024 Olympics
 - [https://www.theguardian.com/australia-news/2023/oct/20/russian-south-african-and-us-athletes-get-rushed-australian-citizenships-ahead-of-2024-olympics](https://www.theguardian.com/australia-news/2023/oct/20/russian-south-african-and-us-athletes-get-rushed-australian-citizenships-ahead-of-2024-olympics)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T04:02:36+00:00

<p><strong>Exclusive:</strong> Government fast-tracked applications of canoeist, wrestler and water polo player backed by AOC</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The Australian government has fast-tracked the citizenship of three athletes from South Africa, Russia and the US, in an effort to boost the nation’s chances of winning gold medals at the 2024 Olympics in Paris.</p><p>With the support of the Australian Olympic Committee (AOC), South African canoeist Pierre Van der Westhuyzen, Russian wrestler

## Instagram apologises for adding ‘terrorist’ to some Palestinian user profiles
 - [https://www.theguardian.com/technology/2023/oct/20/instagram-palestinian-user-profile-bios-terrorist-added-translation-meta-apology](https://www.theguardian.com/technology/2023/oct/20/instagram-palestinian-user-profile-bios-terrorist-added-translation-meta-apology)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T03:30:26+00:00

<p>Parent company Meta says bug caused ‘inappropriate’ auto-translations and was now fixed while employee says it pushed ‘a lot of people over the edge’</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>Meta has apologised after inserting the word “terrorist” into the profile bios of some Palestinian Instagram users, in what the company says was a bug in auto-translation.</p><p>The issue, which was <a href="https://www.404media.co/instagram-palestinian-arabic-bio-translation/">first reported by 404media</a>, affect

## Controversial US dog trainer Dog Daddy says he cancelled Australian tour due to backlash
 - [https://www.theguardian.com/australia-news/2023/oct/20/dog-daddy-trainer-augusto-deoliveira-youtube-star-australian-tour-cancelled](https://www.theguardian.com/australia-news/2023/oct/20/dog-daddy-trainer-augusto-deoliveira-youtube-star-australian-tour-cancelled)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T03:26:29+00:00

<p>YouTube star Augusto Deoliveira – who also cancelled trips to the UK and Italy – stands by his tough approach to training canines</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/05/australia-news-live-adam-goodes-indigenous-voice-to-parliament-referendum-floods-victoria-gippsland-evacuation-tax-cuts">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The controversial US-based dog trainer known as the Dog Daddy says he cancelled his planned visit to Australia after a <a href="https://www.theguardian.com/australia-news/2023/sep/27/dog-daddy-youtube-trainer-augusto-deoliveira-calls-to-ban-from-australia-prong-collars-change-petition">backlash from anim

## First Nations groups reject Peter Dutton’s call for royal commission into child abuse
 - [https://www.theguardian.com/australia-news/2023/oct/20/first-nations-groups-reject-peter-dutton-royal-commission-child-abuse](https://www.theguardian.com/australia-news/2023/oct/20/first-nations-groups-reject-peter-dutton-royal-commission-child-abuse)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T02:17:53+00:00

<p>More than 100 community Aboriginal and Torres Strait Islander organisations say safety of Indigenous children ‘should not be politicised’</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>More than a hundred First Nations advocacy groups and organisations have banded together to oppose Peter Dutton’s calls for a royal commission into the abuse of Indigenous children, accusing the opposition of “political point-scoring” and “demonising” communities.</p><p>The opposition leader and his shadow Indigenous Australian

## Queensland police search for missing man who fled into river inhabited by crocodiles
 - [https://www.theguardian.com/australia-news/2023/oct/20/missing-man-crocodile-filled-water-fitzroy-river-rockhampton-police-queensland-australia](https://www.theguardian.com/australia-news/2023/oct/20/missing-man-crocodile-filled-water-fitzroy-river-rockhampton-police-queensland-australia)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T02:02:14+00:00

<p>Multiple aircraft and boats looking for man who was allegedly seeking to evade police when he jumped into Fitzroy River near Rockhampton</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p><a href="https://www.theguardian.com/australia-news/queensland">Queensland</a> police were on Friday using aircraft and boats to continue the search for a man who fled officers into a river inhabited by crocodiles near Rockhampton.</p><p>The 36-year-old man, from Kawana, allegedly fled police just before 6pm on Thursday night, a

## Australia’s live music scene ‘decimated’, with 1,300 venues lost since pandemic
 - [https://www.theguardian.com/culture/2023/oct/20/australias-live-music-scene-decimated-with-1300-venues-lost-since-pandemic](https://www.theguardian.com/culture/2023/oct/20/australias-live-music-scene-decimated-with-1300-venues-lost-since-pandemic)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T01:55:34+00:00

<p>Apra Amcos boss calls for tax incentives to revive the sector, after report reveals number of venues for small to medium gigs shrank by a third over three years</p><ul><li><a href="https://www.theguardian.com/newsletters/2019/oct/18/saved-for-later-sign-up-for-guardian-australias-culture-and-lifestyle-email?CMP=cvau_sfl">Get our weekend culture and lifestyle email</a></li></ul><p>More than 1,300 live music venues and stages across Australia have been lost permanently since Covid restrictions began, shrinking the live music scene for small to medium gigs by one-third over the past three years, according to Apra Amcos’s annual report.</p><p>Australian music fans flocking to large-scale concerts by huge international acts such as Ed Sheeran, Elton John and Harry Styles has delivered a record year in licensing fee earnings for Australasia’s music rights collecting agency Apra Amcos. However, recovery at the grassroots level of the local music industry has been shackled by a dearth of 

## Indigenous boy, 16, dies a week after being found unresponsive in WA’s Casuarina prison
 - [https://www.theguardian.com/australia-news/2023/oct/20/indigenous-boy-16-dies-perth-casuarina-prison-after-being-found-unresponsive](https://www.theguardian.com/australia-news/2023/oct/20/indigenous-boy-16-dies-perth-casuarina-prison-after-being-found-unresponsive)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T00:28:13+00:00

<p>Department says teenager died at Perth’s Sir Charles Gairdner hospital shortly after 10pm on Thursday</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>An Aboriginal teenager has died in a Perth hospital a week after being found unresponsive inside a maximum security prison that is holding more than a dozen young detainees.</p><p>Last Thursday the boy, 16, was found unresponsive in his cell at a youth detention unit within the Casuarina prison by staff in the early hours of the morning.</p><p><strong><a href="ht

## High court to rule on Catholic church’s liability for abuse committed by paedophile priests
 - [https://www.theguardian.com/world/2023/oct/20/high-court-to-rule-on-catholic-churchs-liability-for-abuse-committed-by-paedophile-priests](https://www.theguardian.com/world/2023/oct/20/high-court-to-rule-on-catholic-churchs-liability-for-abuse-committed-by-paedophile-priests)
 - RSS feed: https://www.theguardian.com/world/rss
 - date published: 2023-10-20T00:15:01+00:00

<p>Church has been granted special leave to appeal Victorian judgment that found Ballarat diocese was vicariously liable for abuse of child</p><ul><li><a href="https://www.theguardian.com/australia-news/live/2023/oct/20/australia-news-live-climate-action-free-trade-anthony-albanese-peter-dutton-gaza-israel">Follow our Australia news live blog for latest updates</a></li><li>Get our <a href="https://www.theguardian.com/email-newsletters?CMP=cvau_sfl">morning and afternoon news emails</a>, <a href="https://app.adjust.com/w4u7jx3">free app</a> or <a href="https://www.theguardian.com/australia-news/series/full-story?CMP=cvau_sfl">daily news podcast</a></li></ul><p>The Catholic church has won the right to challenge in the high court a landmark Victorian ruling forcing the church to take on greater liability for the actions of paedophile priests within its ranks.</p><p>In the past two years, the Victorian courts have delivered and <a href="https://www.theguardian.com/australia-news/2022/jan

