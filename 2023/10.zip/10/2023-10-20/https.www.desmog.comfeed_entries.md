# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Activists Decry FERC Rush to Construct LNG Gas Terminal, Say Permits for More Potential ‘Train Wreck’
 - [https://www.desmog.com/2023/10/20/lng-export-facilities-louisiana-mckibben-ferc-venture-global-salt-dome/](https://www.desmog.com/2023/10/20/lng-export-facilities-louisiana-mckibben-ferc-venture-global-salt-dome/)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-10-20T22:14:41+00:00

<p>On my lastest flight surveying fossil fuel industry sites in southwest Louisiana at the end of September, I photographed liquified natural gas (LNG) export facilities, signs of drought, fire-scarred stretches of marsh, and a salt dome site at risk of collapsing. The visuals illustrate issues climate advocates publicized this week related to impacts fossil fuel [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/10/20/lng-export-facilities-louisiana-mckibben-ferc-venture-global-salt-dome/" rel="nofollow">Activists Decry FERC Rush to Construct LNG Gas Terminal, Say Permits for More Potential ‘Train Wreck’</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

