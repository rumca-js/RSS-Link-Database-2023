# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Parliamentary speech on excess deaths
 - [https://www.youtube.com/watch?v=97qRUqYLNu0](https://www.youtube.com/watch?v=97qRUqYLNu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-10-20T16:06:14+00:00

If you live in the UK, you can contact your MP using this link, https://www.parliament.uk/get-involved/contact-an-mp-or-lord/contact-your-mp/

Watch the debate live, https://www.parliamentlive.tv/Event/Index/00961342-e42c-431c-b26b-fda858dba69b

