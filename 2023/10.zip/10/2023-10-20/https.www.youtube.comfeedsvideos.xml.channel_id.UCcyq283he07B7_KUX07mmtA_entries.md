# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Calacatta marble extraction begins with precision drilling and strategic cuts #Design #Marble #Stone
 - [https://www.youtube.com/watch?v=_R80Me7sBms](https://www.youtube.com/watch?v=_R80Me7sBms)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T22:20:25+00:00



## The demand for #lobster is growing, which is driving up prices. #seafood #MaineLobster
 - [https://www.youtube.com/watch?v=6TJ-J6_XQUA](https://www.youtube.com/watch?v=6TJ-J6_XQUA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T21:00:03+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## Today, less than 20% of discarded #tires end up in landfills. #climate #waste
 - [https://www.youtube.com/watch?v=Zwrxq8p1kj0](https://www.youtube.com/watch?v=Zwrxq8p1kj0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T20:00:10+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## Christophe Laud Damiel makes some of the most luxurious perfumes. #perfume #fragrance #luxury
 - [https://www.youtube.com/watch?v=ND8oi8Ayajs](https://www.youtube.com/watch?v=ND8oi8Ayajs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T19:00:11+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## Eric Louis is continuing the centuries long tradition of #NativeAmerican horse hair #pottery. #art
 - [https://www.youtube.com/watch?v=86zk6M6chtU](https://www.youtube.com/watch?v=86zk6M6chtU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T18:00:04+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## Inside the untold story of those who make salt farming possible in India. #salt #India #farming
 - [https://www.youtube.com/watch?v=Eu2Uqcr6PjY](https://www.youtube.com/watch?v=Eu2Uqcr6PjY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T17:36:16+00:00



## Creating this highly admired #spirit from scratch is not an easy process. 🥃 #singlemalt #whiskey
 - [https://www.youtube.com/watch?v=yltPWHZEw1M](https://www.youtube.com/watch?v=yltPWHZEw1M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T16:00:51+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## 20 Million Workers Sort Our Trash. Now They're Unionizing | World Wide Waste | Insider Business
 - [https://www.youtube.com/watch?v=w4DO1_ClyNk](https://www.youtube.com/watch?v=w4DO1_ClyNk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T15:00:49+00:00

Globally, an estimated 20 million informal waste pickers are responsible for more than half of all plastic waste collected. Now, a 30-year fight for fair wages and legal protection has culminated in these workers' first international union. This video explores their essential role in how the world handles trash.

00:00 Intro
01:10 Landfill Pickers In Indonesia
10:37 Collecting Metal From Old Ships
22:18 The Children Working In Delhi's E-Waste Market
27:50 Earning A Living Off A Flaming Landfill
38:28 Hunting For Deadly Explosives In Afghanistan
47:56 The World's First International Waste Pickers Union
51:41 Credits

MORE WORLD WIDE WASTE VIDEOS:
How People In Gaza Turn Trash Into Cash
https://www.youtube.com/watch?v=hw4CH-Jg6lY
How The World's Largest Paper Company Makes 1/3 of Cardboard Boxes In America
https://www.youtube.com/watch?v=_lsC0aXyY6g
How Disney's Magical Trash Tubes Ended Up In New York City
https://www.youtube.com/watch?v=u_9ngalquVU

----------------------------------

## Watch farmers #harvest #quinoa in relaxing #asmr.
 - [https://www.youtube.com/watch?v=6gafqvazJUc](https://www.youtube.com/watch?v=6gafqvazJUc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-20T15:00:05+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

