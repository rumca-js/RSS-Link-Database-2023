# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## The Dark Money Behind The Attack on Your Privacy
 - [https://reclaimthenet.org/the-dark-money-behind-the-attack-on-your-privacy](https://reclaimthenet.org/the-dark-money-behind-the-attack-on-your-privacy)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-20T15:43:30+00:00

<a href="https://reclaimthenet.org/the-dark-money-behind-the-attack-on-your-privacy" rel="nofollow" title="The Dark Money Behind The Attack on Your Privacy"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/encrypt-mon.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Opaque lobbying.</p>
<p>The post <a href="https://reclaimthenet.org/the-dark-money-behind-the-attack-on-your-privacy" rel="nofollow">The Dark Money Behind The Attack on Your Privacy</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Lawmakers Demand Amazon Censors Alexa After WaPo Complains Its Responses Referenced Rumble, Substack
 - [https://reclaimthenet.org/lawmakers-amazon-alexa-misinformation-rumble-substack](https://reclaimthenet.org/lawmakers-amazon-alexa-misinformation-rumble-substack)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-20T15:24:30+00:00

<a href="https://reclaimthenet.org/lawmakers-amazon-alexa-misinformation-rumble-substack" rel="nofollow" title="Lawmakers Demand Amazon Censors Alexa After WaPo Complains Its Responses Referenced Rumble, Substack"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/lawmakers-amazon-alexa-misinformation-rumble-substack.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Not happy that Alexa dared to highlight alternative viewpoints and independent creators.</p>
<p>The post <a href="https://reclaimthenet.org/lawmakers-amazon-alexa-misinformation-rumble-substack" rel="nofollow">Lawmakers Demand Amazon Censors Alexa After WaPo Complains Its Responses Referenced Rumble, Substack</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Rights Groups Push Back Against EU Censorship Chief Thierry Breton After He Pressured Platforms to Censor “Disinformation”
 - [https://reclaimthenet.org/rights-groups-push-back-against-eu-censorship-chief-thierry-breton-after-he-pressured-platforms-to-censor-disinformation](https://reclaimthenet.org/rights-groups-push-back-against-eu-censorship-chief-thierry-breton-after-he-pressured-platforms-to-censor-disinformation)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-20T15:20:13+00:00

<a href="https://reclaimthenet.org/rights-groups-push-back-against-eu-censorship-chief-thierry-breton-after-he-pressured-platforms-to-censor-disinformation" rel="nofollow" title="Rights Groups Push Back Against EU Censorship Chief Thierry Breton After He Pressured Platforms to Censor &#8220;Disinformation&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/breton32.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Many are getting tired of the EU's bureaucracy and interference with speech.</p>
<p>The post <a href="https://reclaimthenet.org/rights-groups-push-back-against-eu-censorship-chief-thierry-breton-after-he-pressured-platforms-to-censor-disinformation" rel="nofollow">Rights Groups Push Back Against EU Censorship Chief Thierry Breton After He Pressured Platforms to Censor &#8220;Disinformation&#8221;</a> appeared first on <a href="https://reclaimthenet.org" re

## The Westminster Declaration: Artists, Journalists, and Intellectuals Demand The Censorship Industrial Complex is Dismantled
 - [https://reclaimthenet.org/the-westminster-declaration](https://reclaimthenet.org/the-westminster-declaration)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-20T15:18:26+00:00

<a href="https://reclaimthenet.org/the-westminster-declaration" rel="nofollow" title="The Westminster Declaration: Artists, Journalists, and Intellectuals Demand The Censorship Industrial Complex is Dismantled"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/westminster-declaration.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>United in support of free speech.</p>
<p>The post <a href="https://reclaimthenet.org/the-westminster-declaration" rel="nofollow">The Westminster Declaration: Artists, Journalists, and Intellectuals Demand The Censorship Industrial Complex is Dismantled</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Apple Reportedly Cancels John Stewart Show Over His Content Critical of AI and China
 - [https://reclaimthenet.org/apple-reportedly-cancels-john-stewart-show-over-his-content-critical-of-ai-and-china](https://reclaimthenet.org/apple-reportedly-cancels-john-stewart-show-over-his-content-critical-of-ai-and-china)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-20T14:51:17+00:00

<a href="https://reclaimthenet.org/apple-reportedly-cancels-john-stewart-show-over-his-content-critical-of-ai-and-china" rel="nofollow" title="Apple Reportedly Cancels John Stewart Show Over His Content Critical of AI and China"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/js-apple.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Apple is accused of trying to suppress voices to please China.</p>
<p>The post <a href="https://reclaimthenet.org/apple-reportedly-cancels-john-stewart-show-over-his-content-critical-of-ai-and-china" rel="nofollow">Apple Reportedly Cancels John Stewart Show Over His Content Critical of AI and China</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

