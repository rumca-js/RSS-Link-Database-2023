# Source:HackRead, URL:https://www.hackread.com/feed, language:en-US

## Hacker Claims to Have Data of 7 Million 23andMe Users from DNA Service
 - [https://www.hackread.com/hacker-claims-dna-service-23andme-users-data/](https://www.hackread.com/hacker-claims-dna-service-23andme-users-data/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-06T17:43:32+00:00

<p>By <a href="https://www.hackread.com/author/hackread/" rel="nofollow">Waqas</a></p>
<p>23andMe Investigating Potential Data Breach, Says Credentials May Have Been Gathered From Other Breaches.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/hacker-claims-dna-service-23andme-users-data/" rel="nofollow">Hacker Claims to Have Data of 7 Million 23andMe Users from DNA Service</a></p>

## Some Meta Employees and Security Guards Hacked User Accounts
 - [https://www.hackread.com/meta-employees-hacked-accounts/](https://www.hackread.com/meta-employees-hacked-accounts/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-06T14:08:16+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>The fired individuals included on-contract security guards who worked for Meta and could access an internal tool for employees.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/meta-employees-hacked-accounts/" rel="nofollow">Some Meta Employees and Security Guards Hacked User Accounts</a></p>

## Largest Dark Web Webinjects Marketplace “In The Box” Discovered
 - [https://www.hackread.com/dark-web-webinject-market-in-the-box/](https://www.hackread.com/dark-web-webinject-market-in-the-box/)
 - RSS feed: https://www.hackread.com/feed
 - date published: 2023-10-06T14:02:25+00:00

<p>By <a href="https://www.hackread.com/author/deeba/" rel="nofollow">Deeba Ahmed</a></p>
<p>A new dark web marketplace called InTheBox has surfaced online, serving smartphone malware developers and operators.</p>
<p>This is a post from HackRead.com Read the original post: <a href="https://www.hackread.com/dark-web-webinject-market-in-the-box/" rel="nofollow">Largest Dark Web Webinjects Marketplace “In The Box” Discovered</a></p>

