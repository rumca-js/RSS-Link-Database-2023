# Source:pcgamer, URL:http://www.pcgamer.com/rss, language:en-US

## A heroic Starfield modder just straight-up deleted those repetitive temple 'puzzles' from the game
 - [https://www.pcgamer.com/a-heroic-starfield-modder-just-straight-up-deleted-those-repetitive-temple-puzzles-from-the-game](https://www.pcgamer.com/a-heroic-starfield-modder-just-straight-up-deleted-those-repetitive-temple-puzzles-from-the-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T22:14:29+00:00

Chasing a buncha blinking lights in zero-G was enjoyable once. Once.

## One of Baldur's Gate 3's sound designers studied blacksmithing and made a pair of metal shoes just to record armor clanking noises for the game
 - [https://www.pcgamer.com/one-of-baldurs-gate-3s-sound-designers-studied-blacksmithing-and-made-a-pair-of-metal-shoes-just-to-record-armor-clanking-noises-for-the-game](https://www.pcgamer.com/one-of-baldurs-gate-3s-sound-designers-studied-blacksmithing-and-made-a-pair-of-metal-shoes-just-to-record-armor-clanking-noises-for-the-game)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T21:11:58+00:00

Um, excuse me, they're called sabatons?

## It sure looks like edgy Pinocchio retelling Lies of P is getting some kind of DLC
 - [https://www.pcgamer.com/it-sure-looks-like-edgy-pinocchio-retelling-lies-of-p-is-getting-some-kind-of-dlc](https://www.pcgamer.com/it-sure-looks-like-edgy-pinocchio-retelling-lies-of-p-is-getting-some-kind-of-dlc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T20:49:30+00:00

A job listing essentially confirms the strong hint that Neowiz dropped in September.

## Ghostwire: Tokyo is free for Amazon Prime subscribers
 - [https://www.pcgamer.com/ghostwire-tokyo-is-free-for-amazon-prime-subscribers](https://www.pcgamer.com/ghostwire-tokyo-is-free-for-amazon-prime-subscribers)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T19:29:56+00:00

Kick yokai ass on the abandoned streets of Tokyo.

## This company will build you a 15-foot mech for a trifling $3 million
 - [https://www.pcgamer.com/this-company-will-build-you-a-15-foot-mech-for-a-trifling-dollar3-million](https://www.pcgamer.com/this-company-will-build-you-a-15-foot-mech-for-a-trifling-dollar3-million)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T19:23:27+00:00

Honestly, this is a bargain for a mech.

## You're doomed from the start in 'merciless' survival city builder Dotage, but trying to survive the apocalypse is all part of the fun
 - [https://www.pcgamer.com/youre-doomed-from-the-start-in-merciless-survival-city-builder-dotage-but-trying-to-survive-the-apocalypse-is-all-part-of-the-fun](https://www.pcgamer.com/youre-doomed-from-the-start-in-merciless-survival-city-builder-dotage-but-trying-to-survive-the-apocalypse-is-all-part-of-the-fun)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T18:40:11+00:00

The apocalypse is nigh in this turn-based roguelike—can you build a city strong enough to survive it?

## How to use an Xbox controller on PC: Xbox Series, Xbox One, Xbox 360, and even OG Xbox
 - [https://www.pcgamer.com/xbox-one-controller-on-pc](https://www.pcgamer.com/xbox-one-controller-on-pc)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T18:15:12+00:00

Tips for connecting Microsoft's Xbox controllers via USB, wireless adapter, or Bluetooth.

## Stardew Valley creator reveals a new and very important addition coming in the 1.6 update: 'Hats on cats (and dogs)'
 - [https://www.pcgamer.com/stardew-valley-creator-reveals-a-new-and-very-important-addition-coming-in-the-16-update-hats-on-cats-and-dogs](https://www.pcgamer.com/stardew-valley-creator-reveals-a-new-and-very-important-addition-coming-in-the-16-update-hats-on-cats-and-dogs)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T18:08:38+00:00

This is all you really need.

## Cozy fishing horror Dredge gets some chilling DLC next month
 - [https://www.pcgamer.com/cozy-fishing-horror-dredge-gets-some-chilling-dlc-next-month](https://www.pcgamer.com/cozy-fishing-horror-dredge-gets-some-chilling-dlc-next-month)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T17:30:17+00:00

The Pale Ridge adds new story, equipment, and fish.

## The most bizarre Final Fantasy 14 bug to date is giving everyone random buffs and making them go Super Saiyan
 - [https://www.pcgamer.com/the-most-bizarre-final-fantasy-14-bug-to-date-is-giving-everyone-random-buffs-and-making-them-go-super-saiyan](https://www.pcgamer.com/the-most-bizarre-final-fantasy-14-bug-to-date-is-giving-everyone-random-buffs-and-making-them-go-super-saiyan)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T17:00:38+00:00

Buffs are perhaps *too* buff right now.

## Mark Zuckerberg's first interview entirely in the Metaverse is slightly robotic but that's not all down to the tech
 - [https://www.pcgamer.com/mark-zuckerbergs-first-interview-entirely-in-the-metaverse-is-slightly-robotic-but-thats-not-all-down-to-the-tech](https://www.pcgamer.com/mark-zuckerbergs-first-interview-entirely-in-the-metaverse-is-slightly-robotic-but-thats-not-all-down-to-the-tech)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T16:46:02+00:00

The first interview entirely conducted in the Metaverse is out and it's, well, decide for yourself…

## SilverStone has taken the 'all' in all-in-one cooling way too literally with its stackable system
 - [https://www.pcgamer.com/silverstone-has-taken-the-all-in-all-in-one-cooling-way-too-literally-with-its-stackable-system](https://www.pcgamer.com/silverstone-has-taken-the-all-in-all-in-one-cooling-way-too-literally-with-its-stackable-system)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T16:43:28+00:00

Cool everything in your case, gaming room, and apartment block.

## Baldur's Gate 3's new hotfix is here and I used its main addition to turn a hireling into a woman named Darryl
 - [https://www.pcgamer.com/baldurs-gate-3s-new-hotfix-is-here-and-i-used-its-main-addition-to-turn-a-hireling-into-a-woman-named-darryl](https://www.pcgamer.com/baldurs-gate-3s-new-hotfix-is-here-and-i-used-its-main-addition-to-turn-a-hireling-into-a-woman-named-darryl)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T16:39:52+00:00

Also, bug fixes or something.

## Deep Rock Galactic is going rogue with an all-new spinoff game coming next year
 - [https://www.pcgamer.com/deep-rock-galactic-is-going-rogue-with-an-all-new-spinoff-game-coming-next-year](https://www.pcgamer.com/deep-rock-galactic-is-going-rogue-with-an-all-new-spinoff-game-coming-next-year)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T16:27:15+00:00

Deep Rock Galactic: Rogue Core is—you guessed it—a roguelite.

## How to use DLSS Swapper: a handy frame rate boosting tool if you know what you're doing
 - [https://www.pcgamer.com/how-to-use-dlss-swapper](https://www.pcgamer.com/how-to-use-dlss-swapper)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T16:10:31+00:00

Nvidia's DLSS upscaling is magic, but changing the hat can improve the rabbit that's pulled out of it.

## Upcoming indie RPG says forget about looting treasure chests—now you are one
 - [https://www.pcgamer.com/upcoming-indie-rpg-says-forget-about-looting-treasure-chestsnow-you-are-one](https://www.pcgamer.com/upcoming-indie-rpg-says-forget-about-looting-treasure-chestsnow-you-are-one)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T15:44:36+00:00

Help, I've been reincarnated as a chest?

## AMD gives Intel short shrift when asked if its competitor's foundry expansion can succeed: 'Of course not'
 - [https://www.pcgamer.com/amd-gives-intel-short-shrift-when-asked-if-its-competitors-foundry-expansion-can-succeed-of-course-not](https://www.pcgamer.com/amd-gives-intel-short-shrift-when-asked-if-its-competitors-foundry-expansion-can-succeed-of-course-not)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T14:59:52+00:00

Come on AMD, say what you really think.

## More people are playing Arkane's Prey than Redfall on Steam right now
 - [https://www.pcgamer.com/more-people-are-playing-arkanes-prey-than-redfall-on-steam-right-now](https://www.pcgamer.com/more-people-are-playing-arkanes-prey-than-redfall-on-steam-right-now)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T14:44:55+00:00

Xbox bosses have said they want to turn Redfall around, but it might take a miracle at this point.

## Watch the powerful firebender Azula kick the crap out of Stimpy in the final Nickelodeon All-Star Brawl 2 character reveal
 - [https://www.pcgamer.com/watch-the-powerful-firebender-azula-kick-the-crap-out-of-stimpy-in-the-final-nickelodeon-all-star-brawl-2-character-reveal](https://www.pcgamer.com/watch-the-powerful-firebender-azula-kick-the-crap-out-of-stimpy-in-the-final-nickelodeon-all-star-brawl-2-character-reveal)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T14:01:52+00:00

Nickelodeon All-Star Brawl 2 is coming in November, and Azula is the final character to be revealed.

## Intel's betting on a big 'Windows refresh' in 2024 to boost revenue client CPU revenue, seemingly confirming Windows 12 release date rumours
 - [https://www.pcgamer.com/intels-betting-on-a-big-windows-refresh-in-2024-to-boost-revenue-client-cpu-revenue-seemingly-confirming-windows-12-release-date-rumours](https://www.pcgamer.com/intels-betting-on-a-big-windows-refresh-in-2024-to-boost-revenue-client-cpu-revenue-seemingly-confirming-windows-12-release-date-rumours)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T12:51:30+00:00

Chipzilla is playing all coy with its words but it surely means Windows 12.

## I was obsessed with real-time ray tracing in Cyberpunk 2077, until playing it on an older laptop delivered a sorely needed slap to the face
 - [https://www.pcgamer.com/i-was-obsessed-with-real-time-ray-tracing-in-cyberpunk-2077-until-playing-it-on-an-older-laptop-delivered-a-sorely-needed-slap-to-the-face](https://www.pcgamer.com/i-was-obsessed-with-real-time-ray-tracing-in-cyberpunk-2077-until-playing-it-on-an-older-laptop-delivered-a-sorely-needed-slap-to-the-face)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:59:49+00:00

The allure of pretty graphics, like the dark side of the Force, can be very powerful

## Where to find Solafite in Sons of the Forest
 - [https://www.pcgamer.com/sons-of-the-forest-solafite-ore](https://www.pcgamer.com/sons-of-the-forest-solafite-ore)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:56:39+00:00

Don't forget to grab the pickaxe first.

## History unfortunately repeats itself as Telltale Games lays off 'most' of its staff
 - [https://www.pcgamer.com/history-unfortunately-repeats-itself-as-telltale-games-lays-off-most-of-its-staff](https://www.pcgamer.com/history-unfortunately-repeats-itself-as-telltale-games-lays-off-most-of-its-staff)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:46:25+00:00

The developer maintains that it still has games in the pipeline, though.

## How to upgrade your weapons and outfit in Assassin's Creed Mirage
 - [https://www.pcgamer.com/ac-mirage-upgrade-weapons-outfits](https://www.pcgamer.com/ac-mirage-upgrade-weapons-outfits)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:38:26+00:00

Slay with style.

## CD Projekt pops the cork on Cyberpunk's big numbers as it revels in the post-expansion victory lap
 - [https://www.pcgamer.com/cd-projekt-pops-the-cork-on-cyberpunks-big-numbers-as-it-revels-in-the-post-expansion-victory-lap](https://www.pcgamer.com/cd-projekt-pops-the-cork-on-cyberpunks-big-numbers-as-it-revels-in-the-post-expansion-victory-lap)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:21:46+00:00

Clearly, we need to put a big celebrity face in the next Witcher game. I nominate David Lynch.

## Twitter sleuths suggest a new Steam Deck is on its way, but any updates are likely to be for Valve's benefit not ours
 - [https://www.pcgamer.com/twitter-sleuths-suggest-a-new-steam-deck-is-on-its-way-but-any-updates-are-likely-to-be-for-valves-benefit-not-ours](https://www.pcgamer.com/twitter-sleuths-suggest-a-new-steam-deck-is-on-its-way-but-any-updates-are-likely-to-be-for-valves-benefit-not-ours)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T11:21:25+00:00

Valve has confirmed it's sticking with the current Steam Deck performance level for a while, so what updates will there be?

## Rtings latest OLED monitor burn-in tests are not good news for Samsung
 - [https://www.pcgamer.com/rtings-latest-oled-monitor-burn-in-tests-are-not-good-news-for-samsung](https://www.pcgamer.com/rtings-latest-oled-monitor-burn-in-tests-are-not-good-news-for-samsung)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T10:59:47+00:00

LG panel tech seems to be holding up better after four months.

## Wordle today: Hint and answer for #839 Friday, October 6
 - [https://www.pcgamer.com/wordle-today-answer-839-october-6](https://www.pcgamer.com/wordle-today-answer-839-october-6)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T03:06:44+00:00

Get all the help you need with today's Wordle.

## AMD APUs are set to make their AM5 debut after support was added to AMD's latest BIOS microcode
 - [https://www.pcgamer.com/amd-apus-are-set-to-make-their-am5-debut-after-support-was-added-to-amds-latest-bios-microcode](https://www.pcgamer.com/amd-apus-are-set-to-make-their-am5-debut-after-support-was-added-to-amds-latest-bios-microcode)
 - RSS feed: http://www.pcgamer.com/rss
 - date published: 2023-10-06T00:18:53+00:00

Phoenix Ryzing.

