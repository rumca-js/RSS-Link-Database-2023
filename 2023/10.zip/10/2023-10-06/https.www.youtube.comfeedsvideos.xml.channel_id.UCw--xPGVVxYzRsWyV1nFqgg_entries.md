# Source:Daniel Greene, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg, language:en-US

## "Documentary" Steals From Sanderson🏴‍☠️ Cyberpunk Live Action🎥 Bobiverse Adaptation☄️ FANTASY NEWS
 - [https://www.youtube.com/watch?v=Ib0FvyixX7g](https://www.youtube.com/watch?v=Ib0FvyixX7g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCw--xPGVVxYzRsWyV1nFqgg
 - date published: 2023-10-06T13:30:07+00:00

Let's jump into the Fantasy News! Back the war of the Worlds Kickstarter here: https://tinyurl.com/wotwFN 

merch: https://www.danielbgreene.com
My books: https://tinyurl.com/NGPreOrder 
Neon Ghosts: https://amzn.to/3Y2N1QI (digital)
Neon Ghosts: Physical: https://tinyurl.com/NGPreOrder 
Breach of Peace: https://tinyurl.com/BoPTLT  
Rebels Creed: https://tinyurl.com/RCTLTDG 

Patreon: https://www.patreon.com/DanielBGreene 
Join the Discord here: https://discord.gg/xUrPj6EP3f
All the Me Social Links: https://linktr.ee/DanielGreene

00:00 Live Action Cyberpunk 2077: https://press.cdprojektred.com/en/news/1453/cd-projekt-red-partners-with-anonymous-content-to-develop-live-action-project 

02:29 New Culture Covers: https://twitter.com/orbitbooks/status/1709531674172608670 

03:23 VFX members vote to unionize: https://iatse.net/walt-disney-pictures-vfx-workers-vote-unanimously-for-unionization-in-labor-board-election/#:~:text=The%20unanimous%20unionization%20of%20Walt,previously%20unrepre

