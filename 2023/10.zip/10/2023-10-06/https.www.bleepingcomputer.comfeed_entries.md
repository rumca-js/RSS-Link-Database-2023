# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## Blackbaud agrees to $49.5 million settlement for ransomware data breach
 - [https://www.bleepingcomputer.com/news/security/blackbaud-agrees-to-495-million-settlement-for-ransomware-data-breach/](https://www.bleepingcomputer.com/news/security/blackbaud-agrees-to-495-million-settlement-for-ransomware-data-breach/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-10-06T18:43:05+00:00

Cloud computing provider Blackbaud reached a $49.5 million agreement with attorneys general from 49 U.S. states to settle a multi-state investigation of a May 2020 ransomware attack and the resulting data breach. [...]

## FTC warns of ‘staggering’ losses to social media scams since 2021
 - [https://www.bleepingcomputer.com/news/security/ftc-warns-of-staggering-losses-to-social-media-scams-since-2021/](https://www.bleepingcomputer.com/news/security/ftc-warns-of-staggering-losses-to-social-media-scams-since-2021/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-10-06T17:07:17+00:00

The Federal Trade Commission says Americans have lost at least $2.7 billion to social media scams since 2021, with the real number likely many times larger due to unreported incidents.  [...]

## Genetics firm 23andMe says user data stolen in credential stuffing attack
 - [https://www.bleepingcomputer.com/news/security/genetics-firm-23andme-says-user-data-stolen-in-credential-stuffing-attack/](https://www.bleepingcomputer.com/news/security/genetics-firm-23andme-says-user-data-stolen-in-credential-stuffing-attack/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-10-06T15:48:13+00:00

23andMe has confirmed to BleepingComputer that it is aware of user data from its platform circulating on hacker forums and attributes the leak to a credential-stuffing attack. [...]

## MGM Resorts ransomware attack led to $100 million loss, data theft
 - [https://www.bleepingcomputer.com/news/security/mgm-resorts-ransomware-attack-led-to-100-million-loss-data-theft/](https://www.bleepingcomputer.com/news/security/mgm-resorts-ransomware-attack-led-to-100-million-loss-data-theft/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-10-06T13:53:05+00:00

MGM Resorts reveals that last month's cyberattack cost the company $100 million and allowed the hackers to steal customers' personal information. [...]

## MGM Resorts says ransomware attack cost $100 million, data stolen
 - [https://www.bleepingcomputer.com/news/security/mgm-resorts-says-ransomware-attack-cost-100-million-data-stolen/](https://www.bleepingcomputer.com/news/security/mgm-resorts-says-ransomware-attack-cost-100-million-data-stolen/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-10-06T13:53:05+00:00

MGM Resorts reveals that last month's cyberattack cost the company $100 million and allowed the hackers to steal customers' personal information. [...]

