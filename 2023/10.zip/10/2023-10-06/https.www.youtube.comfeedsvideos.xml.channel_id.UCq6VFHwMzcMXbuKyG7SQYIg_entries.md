# Source:penguinz0, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg, language:en-US

## I'm A Professional Wrestler Now
 - [https://www.youtube.com/watch?v=mxjfmy1rJv4](https://www.youtube.com/watch?v=mxjfmy1rJv4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-10-06T19:00:33+00:00

This is the greatest wrestling class of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/

## New Assassin's Creed Mirage
 - [https://www.youtube.com/watch?v=yi7b3UxmDSw](https://www.youtube.com/watch?v=yi7b3UxmDSw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-10-06T06:44:46+00:00

Merch https://moistglobal.com/
Comics https://badegg.co/

## YandereDev Situation is Crazy
 - [https://www.youtube.com/watch?v=TpCeUyy6264](https://www.youtube.com/watch?v=TpCeUyy6264)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCq6VFHwMzcMXbuKyG7SQYIg
 - date published: 2023-10-06T00:00:10+00:00

Official Podcast channel https://www.youtube.com/@theofficialytchannel 
This is the greatest yandere dev moment of All Time
Merch https://moistglobal.com/
Comics https://badegg.co/
Get Gamer Supps https://gamersupps.gg/moist

