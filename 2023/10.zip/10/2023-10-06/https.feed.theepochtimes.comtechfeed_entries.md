# Source:Epoch Times - Tech, URL:https://feed.theepochtimes.com/tech/feed, language:en-US

## China ‘Worst Abuser of Internet Freedom’ for 9th Consecutive Year: Report
 - [https://www.theepochtimes.com/china/china-ranks-bottom-on-internet-freedoms-list-for-9th-consecutive-year-report-5505177](https://www.theepochtimes.com/china/china-ranks-bottom-on-internet-freedoms-list-for-9th-consecutive-year-report-5505177)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-10-06T14:56:22+00:00

People play computer games at an internet cafe in Beijing on Sept. 10, 2021. (Greg Baker/AFP via Getty Images)

## Huawei’s Chip Breakthrough ‘Incredibly Disturbing’: Commerce Secretary Raimondo
 - [https://www.theepochtimes.com/china/huaweis-chip-breakthrough-incredibly-disturbing-commerce-secretary-raimondo-5504780](https://www.theepochtimes.com/china/huaweis-chip-breakthrough-incredibly-disturbing-commerce-secretary-raimondo-5504780)
 - RSS feed: https://feed.theepochtimes.com/tech/feed
 - date published: 2023-10-06T13:44:24+00:00

Commerce Secretary Gina Raimondo testifies before the House Committee on Science, Space, and Technology at the Rayburn House Office Building in Washington on Sept. 19, 2023. (Kevin Dietsch/Getty Images)

