# Source:Wirtualne Media - Internet, URL:https://www.wirtualnemedia.pl/rss/wm_internet.xml, language:pl-PL

## Szef agencji stojącej za Teamem X: nie mam żadnych dowodów ws. Stuu
 - [https://www.wirtualnemedia.pl/artykul/stuu-zarzuty-pedofilia-spotlight-agency-move-federation-wojciech-szaniawski](https://www.wirtualnemedia.pl/artykul/stuu-zarzuty-pedofilia-spotlight-agency-move-federation-wojciech-szaniawski)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T19:49:00+00:00

- Nie mam żadnych dowodów z przeszłości, obecnych, jakichkolwiek związanych ze sprawą Stuarta Bartona - stwierdził Wojciech Szaniawski, szef i współwłaściciel Spotlight Agency (która realizowała trzy edycje projektu Team X) oraz Move Federation. Zapowiedział, że z Move Federation będą wykluczane osoby żartujące z kontaktów seksualnych z nieletnimi.

## Reklamodawca Kanału Sportowego odcina się od słów youtubera do nastolatek
 - [https://www.wirtualnemedia.pl/artykul/maciej-dabrowski-czlowiek-warga-kanal-sportowy-youtube-koniec](https://www.wirtualnemedia.pl/artykul/maciej-dabrowski-czlowiek-warga-kanal-sportowy-youtube-koniec)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T19:08:00+00:00

Marka Lipton, partner reklamowy porannego programu Kanału Sportowego, po przypomnieniu wulgarnych wypowiedzi do nastolatek youtubera Macieja Dąbrowskiego (Człowieka Wargi), podkreśla, że sprzeciwia się każdej formie przemocy. Krzysztof Stanowski zapowiedział, że Dąbrowski nie będzie się już pojawiał się w porannym programie.

## Człowiek Warga znika z Kanału Sportowego. Przez obleśne odzywki do nastolatek
 - [https://www.wirtualnemedia.pl/artykul/czlowiek-warga-maciej-dabrowski-youtube-znika-z-kanalu-sportowego](https://www.wirtualnemedia.pl/artykul/czlowiek-warga-maciej-dabrowski-youtube-znika-z-kanalu-sportowego)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T13:30:46.915856+00:00

Krzysztof Stanowski zapowiedział, że youtuber Maciej Dąbrowski (Człowiek Warga) nie będzie już współprowadził z nim w poniedziałki porannego programu na Kanale Sportowym. Przyczyną jest film sprzed 9 lat, na którym Dąbrowski podpowiadał chłopakowi wulgarne odzywki o seksie do nastolatek. - Przepraszam Was za ten niesamowicie głupi i niesmaczny „żart”. Moja wina - przyznaje Dąbrowski.

## Rusza pakiet Onet Premium & TVN24 GO. "Wolne media chcą ze sobą współpracować"
 - [https://www.wirtualnemedia.pl/artykul/onet-premium-tvn24-go-pakiet-cena-oferta](https://www.wirtualnemedia.pl/artykul/onet-premium-tvn24-go-pakiet-cena-oferta)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T11:19:21.879898+00:00

Grupy medialne Ringier Axel Springer Polska i TVN Warner Bros. Discovery stworzyły wspólny pakiet łączący serwisy subskrypcyjne TVN24 GO oraz Onet Premium. Wykupić go można w cenie 19,90 zł miesięcznie.

## Szlachecka wieś w krzywym zwierciadle. Netflix zapowiada nowy polski serial "1670"
 - [https://www.wirtualnemedia.pl/artykul/serial-1670-netflix-obsada-premiera-zwiastun-opinie](https://www.wirtualnemedia.pl/artykul/serial-1670-netflix-obsada-premiera-zwiastun-opinie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T04:33:32.673121+00:00

Obraz sarmackiego życia w “sielankowych” czasach pańszczyzny, zdobiony absurdem, czarnym humorem i refleksami współczesności, czeka na widzów w nowym polskim serialu “1670”. To satyryczna produkcja serwisu Netflix w reżyserii Macieja Buchwalda i Kordiana Kądzieli. Premiera w serwisie w grudniu br.

## Ponad 2,3 mln zł dla OKO.press z 1,5 proc. podatku
 - [https://www.wirtualnemedia.pl/artykul/oko-press-fundacja-osrodek-kontroli-obywatelskiej-oko-podatek-1-5-procent](https://www.wirtualnemedia.pl/artykul/oko-press-fundacja-osrodek-kontroli-obywatelskiej-oko-podatek-1-5-procent)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T04:33:32.672592+00:00

Fundacja Ośrodek Kontroli Obywatelskiej „OKO” otrzymała w tym roku z tytułu wpłat 1,5 proc. podatku aż 2 369 417,14 zł. To prawie 860 tys. zł więcej niż w roku ubiegłym. Pozyskane w ten sposób środki przeznacza na dalszy rozwój portalu.

## Influencerka mówi o seksie grupowym z 14-latką w Teamie X. „To działo się notorycznie”
 - [https://www.wirtualnemedia.pl/artykul/team-x-seks-grupowy-14-latka-paulina-kostrzycka-stuu-dubiel](https://www.wirtualnemedia.pl/artykul/team-x-seks-grupowy-14-latka-paulina-kostrzycka-stuu-dubiel)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T04:33:32.672045+00:00

Kolejna odsłona seks afery w polskiej branży influencerksiej. Paulina Kostrzycka twierdzi, że podczas imprezy Teamu X była świadkiem seksu grupowego z udziałem 14-letniej dziewczyny. - To nie była jednorazowa sytuacja ani jedna impreza, to działo się notorycznie - przekonuje.

## Fame MMA zrywa współpracę z Dubielem i DeeJaypallaside
 - [https://www.wirtualnemedia.pl/artykul/koniec-fame-mma-marcin-dubiel-fagata-deejaypallaside-pedofilia-porno-erotyka-stuu](https://www.wirtualnemedia.pl/artykul/koniec-fame-mma-marcin-dubiel-fagata-deejaypallaside-pedofilia-porno-erotyka-stuu)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_internet.xml
 - date published: 2023-10-06T04:33:32.670979+00:00

Federacja freak-fightowa Fame MMA wypowiedziała kontrakt z Marcinem Dubielem i zerwała współpracę z Danielem Pawlakiem (znanym jako DeeJaypallaside), ponadto nie przedłuży umowy z Agatą Fąk (Fagatą). To kolejne konsekwencje seksafery w środowisku influcencerów.

