# Source:The Piano Guys, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw, language:en-US

## Jesu Joy - Johann Sebastian Bach (Piano & Cello Cover) The Piano Guys
 - [https://www.youtube.com/watch?v=hedVDRWEZqM](https://www.youtube.com/watch?v=hedVDRWEZqM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmKurapML4BF9Bjtj4RbvXw
 - date published: 2023-10-06T12:00:40+00:00

“Jesu Joy” by Bach (ft. ARTIST) piano & cello cover from The Piano Guys.
Stream Lullaby: https://lnk.to/tpglullaby | WE’RE ON TOUR: https://lnk.to/tpgtour | Subscribe: https://bit.ly/2XH4GCF | Our NEWEST videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&amp;playnext=1&amp;index=2

Learn about our beliefs here: https://lnk.to/tpgbeliefs

Follow The Piano Guys:
Instagram: https://instagram.com/thepianoguys
Facebook: https://facebook.com/ThePianoGuys
TikTok: https://tiktok.com/@thepianoguys 
Twitter: https://twitter.com/thepianoguys

Watch More of The Piano Guys: 
Covers: https://youtube.com/playlist?list=PL7j5iXGSdMwc7n8Tsjl-I8zEOEZsjWydx&amp;playnext=1&amp;index=2 
Official Music Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwfDukj_bIIB_1JhbYtaWRYg&amp;playnext=1&amp;index=2 
Newest Videos: https://youtube.com/playlist?list=PL7j5iXGSdMwdfnzc8Faa-HJITq9hPEEdI&amp;playnext=1&amp;index=2
Most Popular: https://youtube.com/playlist?list=PL7j5iXGSdMweXm56WE

