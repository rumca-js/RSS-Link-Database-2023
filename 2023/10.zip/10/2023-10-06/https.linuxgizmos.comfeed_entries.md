# Source:LinuxGizmos.com, URL:https://linuxgizmos.com/feed/, language:en-US

## Cost-effective Tiny Code Reader powered by RP2040
 - [https://linuxgizmos.com/cost-effective-tiny-code-reader-powered-by-rp2040/](https://linuxgizmos.com/cost-effective-tiny-code-reader-powered-by-rp2040/)
 - RSS feed: https://linuxgizmos.com/feed/
 - date published: 2023-10-06T06:09:49+00:00

The distributor OKDO recently featured a low-cost device which incorporates an image sensor and the RP2040 microcontroller. The Tiny Code Reader can be used in projects that involve QR codes and it&#8217;s also compatible with open-source programming platforms such as Arduino, CircuitPython and more. The Tiny Code Reader, developed by Useful Sensors, is specifically designed [&#8230;]

