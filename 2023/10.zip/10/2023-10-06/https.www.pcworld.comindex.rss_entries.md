# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## Save $300 on this spacious 4K Samsung gaming monitor
 - [https://www.pcworld.com/article/2096820/2096820.html](https://www.pcworld.com/article/2096820/2096820.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-10-06T14:52:40+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>If you&rsquo;re a PC gamer, you better strap in, as I&rsquo;ve unearthed a scrumptious monitor deal from the depths of the Internet. Amazon&rsquo;s selling the <a href="http://buy.geni.us/Proxy.ashx?TSID=14154&amp;GR_URL=https://www.amazon.com/SAMSUNG-FreeSync-Compatible-Ultrawide-LS32BG702ENXGO/dp/B0BGVCF2SG/?ascsubtag=2-1-2096820-1-0-0" rel="nofollow">Samsung Odyssey G70B gaming monitor for $699</a>, which is a massive savings of $300. Not only is the screen size a spacious 32-inches, but the resolution is also 4K. I mean, there&rsquo;s nothing more immersive than a big screen and a crazy sharp resolution. Let&rsquo;s dive right into the specs because I&rsquo;m sure you&rsquo;re dying to know what&rsquo;s going on inside.</p>



<p>The Samsung Odyssey features a resolution of 3840&times;2160, a refresh rate of 144Hz, and a response time of 1ms. Given those num

## Alienware x16 review: Awesomely powerful and super thin
 - [https://www.pcworld.com/article/2084512/alienware-x16-review.html](https://www.pcworld.com/article/2084512/alienware-x16-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-10-06T11:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><img alt="Editors' Choice" class="review-logo" src="https://www.pcworld.com/wp-content/uploads/2021/09/PC-ED-CHOICE.png" /><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Excellent CPU and GPU power</li><li>The QHD+ display is gorgeous with a rich color saturation</li><li>The AlienFX RGB lighting is stunning</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>It gets very hot and can throttle performance</li><li>The rear port placement means it&rsquo;s tricky to plug things in</li><li>The battery life is quite short</li></ul></di

## How to format USB sticks and external drives in Windows
 - [https://www.pcworld.com/article/2091375/to-format-usb-sticks-and-external-hard-disks-under-windows.html](https://www.pcworld.com/article/2091375/to-format-usb-sticks-and-external-hard-disks-under-windows.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-10-06T10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>You can format an external drive quickly and easily in Windows, without the need of any third-party tools. But before you format your USB drive, you need to consider which file system to use. File systems are methods of organizing data on a storage medium such as a hard drive or SD card. </p>



<p>The support for different file systems varies depending on the operating system. Windows 10 and 11 offer three file system options when formatting a USB storage device: FAT32, NTFS, and exFAT. </p>



<p>The most popular and probably also the easiest way to format a storage device is directly via the integrated file explorer utility of Windows. The procedure is identical for internal and external storage devices: In a File Explorer window, right-click on the drive and select <em>Format</em> from the context menu. Then define the file system to which you would like to 

