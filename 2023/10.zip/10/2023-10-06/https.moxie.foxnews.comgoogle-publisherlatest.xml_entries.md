# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Ex-NBA star suing insurance company for $40M for allegedly denying coverage for COVID-19-related heart disease
 - [https://www.foxnews.com/sports/ex-nba-star-suing-insurance-company-40-million-denying-coverage-covid-19-related-heart-disease](https://www.foxnews.com/sports/ex-nba-star-suing-insurance-company-40-million-denying-coverage-covid-19-related-heart-disease)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T23:28:26+00:00

Former NBA player Michael Kidd-Gilchrist is suing an insurance company for $40 million for denying coverage of his COVID-19-related heart disease.

## Los Angeles model found dead in apartment died from 'homicidal violence,' medical examiner rules
 - [https://www.foxnews.com/us/los-angeles-model-found-dead-apartment-died-homicidal-violence-medical-examiner-rules](https://www.foxnews.com/us/los-angeles-model-found-dead-apartment-died-homicidal-violence-medical-examiner-rules)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T23:21:52+00:00

A model found dead in her downtown Los Angeles apartment last month died from &quot;homicidal violence, the medical examiner&apos;s office said.

## Critics deride Biden's rosy rhetoric on economy: 'My grocery bill is up almost 300%'
 - [https://www.foxnews.com/media/critics-deride-bidens-rosy-rhetoric-economy-grocery-bill-300](https://www.foxnews.com/media/critics-deride-bidens-rosy-rhetoric-economy-grocery-bill-300)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T23:05:23+00:00

Biden claimed that Americans are &quot;better off financially than they were before,&quot; citing a recent jobs report, but conservatives on social media disagreed.

## Hunter Biden took thousands from daughter's college fund for 'hookers and drugs': report
 - [https://www.foxnews.com/politics/hunter-biden-took-thousands-daughters-college-fund-hookers-drugs](https://www.foxnews.com/politics/hunter-biden-took-thousands-daughters-college-fund-hookers-drugs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T22:56:04+00:00

A new report shows Hunter Biden took $20,000 from his daughter Maisy&apos;s college savings fund to to spend on &quot;hookers and drugs&quot; in 2018.

## Trevor Bauer's 27-minute phone call with accuser following sexual encounter revealed
 - [https://www.foxnews.com/sports/trevor-bauers-27-minute-phone-call-accuser-sexual-encounter-revealed](https://www.foxnews.com/sports/trevor-bauers-27-minute-phone-call-accuser-sexual-encounter-revealed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T22:47:05+00:00

A May 22, 2021, phone call between Trevor Bauer and his accuser was released on YouTube, and the two discussed how Hill&apos;s injuries came about in their sexual encounter.

## Colorado 'green' funeral home under investigation after 'disturbing discovery' of over 115 decaying bodies
 - [https://www.foxnews.com/us/colorado-green-funeral-home-investigation-disturbing-discovery-115-decaying-bodies](https://www.foxnews.com/us/colorado-green-funeral-home-investigation-disturbing-discovery-115-decaying-bodies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:57:08+00:00

The Return to Nature Funeral Home in Colorado, which specializes in &quot;green&quot; burials, is accused of improperly storing bodies at its facility.

## Ex-Seahawks RB Marshawn Lynch rips Pete Carroll, says he laughed in coach's face after Super Bowl interception
 - [https://www.foxnews.com/sports/ex-seahawks-rb-marshawn-lynch-rips-pete-carroll-says-laughed-coachs-face-super-bowl-interception](https://www.foxnews.com/sports/ex-seahawks-rb-marshawn-lynch-rips-pete-carroll-says-laughed-coachs-face-super-bowl-interception)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:27:13+00:00

The Seattle Seahawks fall from grace seems to be laced with drama, and former NFL great Marshawn Lynch peeled the curtain back even more when he detailed his shaky relationship with Seahawks coach Pete Carroll.

## Puerto Rican man sentenced to 7 years in prison for decades of dogfighting
 - [https://www.foxnews.com/us/puerto-rican-man-sentenced-7-years-prison-decades-dogfighting](https://www.foxnews.com/us/puerto-rican-man-sentenced-7-years-prison-decades-dogfighting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:20:21+00:00

A man with a long history of breeding dogs for fighting and exhibiting &quot;extraordinary cruelty&quot; has been sentenced to seven years in prison, as announced by the U.S. Attorney&apos;s Office.

## Ivory Coast President Alassane Ouattara dismisses PM and dissolves government in major reshuffle
 - [https://www.foxnews.com/world/ivory-coast-president-alassane-ouattara-dismisses-pm-dissolves-government-major-reshuffle](https://www.foxnews.com/world/ivory-coast-president-alassane-ouattara-dismisses-pm-dissolves-government-major-reshuffle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:18:40+00:00

Ivorian President Alassane Ouattara has initiated a significant government reshuffle by removing the country&apos;s prime minister and dissolving the existing government.

## Florida parents arrested after twin infant dies, sibling suffers 'severe injuries,' police say
 - [https://www.foxnews.com/us/florida-parents-arrested-twin-infant-dies-sibling-suffers-severe-injuries-police-say](https://www.foxnews.com/us/florida-parents-arrested-twin-infant-dies-sibling-suffers-severe-injuries-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:17:05+00:00

A pair of Florida parents are facing child abuse charges after one of their a 3-month-old twins died and the other sustained &apos;severe injuries,&apos; police said.

## Federal appeals court upholds Tennessee law restricting distribution of absentee ballot applications
 - [https://www.foxnews.com/us/federal-appeals-court-upholds-tennessee-law-restricting-distribution-absentee-ballot-applications](https://www.foxnews.com/us/federal-appeals-court-upholds-tennessee-law-restricting-distribution-absentee-ballot-applications)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:16:51+00:00

An appeals court panel declined to revive a legal challenge against a law that classifies it as a felony for anyone besides election officials to give out absentee ballot applications.

## US Treasury Department to allow $7,500 electric vehicle tax credit as point-of-sale rebate starting in January
 - [https://www.foxnews.com/us/us-treasury-department-allow-7500-electric-vehicle-tax-credit-point-sale-rebate-starting-january](https://www.foxnews.com/us/us-treasury-department-allow-7500-electric-vehicle-tax-credit-point-sale-rebate-starting-january)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:15:31+00:00

The U.S. Treasury Department has issued new guidelines for the $7,500 electric vehicle (EV) tax credit, allowing it to be used as a point-of-sale rebate starting in January.

## Philadelphia police ID murder suspect on the run in journalist killing, both were 'acquaintances,' cops say
 - [https://www.foxnews.com/us/philadelphia-police-id-murder-suspect-run-journalist-killing-both-were-acquaintances-cops-say](https://www.foxnews.com/us/philadelphia-police-id-murder-suspect-run-journalist-killing-both-were-acquaintances-cops-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:05:08+00:00

Philadelphia police have issued an arrest warrant for Robert Davis, who is suspected of killing local journalist Josh Kruger inside his home this week.

## Houston robbery suspects snatch money bag from disabled man in wheelchair after stalking him: police
 - [https://www.foxnews.com/us/houston-robbery-suspects-snatch-money-bag-disabled-man-wheelchair-stalking-police](https://www.foxnews.com/us/houston-robbery-suspects-snatch-money-bag-disabled-man-wheelchair-stalking-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T21:00:54+00:00

Three robbery suspects are being sought in Houston after being captured in surveillance video stalking a victim before taking his money, police said.

## 'View' hosts slam Biden administration disconnect on border wall: 'Their messaging sucks'
 - [https://www.foxnews.com/media/view-slams-biden-admin-disconnect-border-wall-messaging-sucks](https://www.foxnews.com/media/view-slams-biden-admin-disconnect-border-wall-messaging-sucks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:50:40+00:00

The co-hosts of ABC&apos;s &quot;The View&quot; slammed the Biden administration&apos;s bad messaging about the construction of miles of new border wall amid the migrant crisis.

## Southern Mexico bus crash kills 18 migrants, mostly from Venezuela and Haiti
 - [https://www.foxnews.com/us/southern-mexico-bus-crash-kills-18-migrants-mostly-venezuela-haiti](https://www.foxnews.com/us/southern-mexico-bus-crash-kills-18-migrants-mostly-venezuela-haiti)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:49:52+00:00

A Friday bus crash in southern Mexico claimed the lives of at least 18 migrants, primarily hailing from Venezuela and Haiti, authorities confirmed.

## Biden signs bill into law that reverses his admin's defunding of school hunting, shooting programs
 - [https://www.foxnews.com/politics/biden-signs-bill-into-law-reverses-his-admins-defunding-school-hunting-shooting-programs](https://www.foxnews.com/politics/biden-signs-bill-into-law-reverses-his-admins-defunding-school-hunting-shooting-programs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:49:00+00:00

On Friday, President Biden signed the Protecting Hunting Heritage and Education Act, reversing his Education Department&apos;s decision to withhold funds for school hunting classes.

## 24-year-old woman charged in Indianapolis shooting that left 3 dead and others injured
 - [https://www.foxnews.com/us/24-year-old-woman-charged-indianapolis-shooting-left-3-dead-others-injured](https://www.foxnews.com/us/24-year-old-woman-charged-indianapolis-shooting-left-3-dead-others-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:48:00+00:00

A 24-year-old woman has been charged in connection with a shooting resulting in the deaths of three individuals in an Indianapolis entertainment district.

## Kevin McCarthy denies report he is considering resigning Congress after being ousted as House speaker
 - [https://www.foxnews.com/politics/kevin-mccarthy-denies-report-considering-resigning-from-congress-after-being-ousted-as-house-speaker](https://www.foxnews.com/politics/kevin-mccarthy-denies-report-considering-resigning-from-congress-after-being-ousted-as-house-speaker)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:44:29+00:00

Rep. Kevin McCarthy, R-Calif., the former Speaker of the House, confirmed to Fox News that he is not resigning from Congress after another outlet reported he was considering it.

## Biden says 'possibility' of meeting with Xi Jinping, first since Chinese spy craft shot down over Atlantic
 - [https://www.foxnews.com/politics/biden-says-possibility-meeting-xi-jinping-first-since-chinese-spy-craft-shot-down-atlantic](https://www.foxnews.com/politics/biden-says-possibility-meeting-xi-jinping-first-since-chinese-spy-craft-shot-down-atlantic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:28:51+00:00

President Biden said Friday that the expected meeting with Chinese President Xi Jinping in San Francisco, California is not yet set up but remains a possibility.

## Juventus star Paul Pogba facing four-year suspension for positive test for banned substance
 - [https://www.foxnews.com/sports/juventus-star-paul-pogba-facing-4-year-suspension-positive-test-banned-substance](https://www.foxnews.com/sports/juventus-star-paul-pogba-facing-4-year-suspension-positive-test-banned-substance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:24:40+00:00

Juventus midfielder and France national star Paul Pogba could be suspended for four years after tests revealed enhanced testosterone levels.

## Democrat senator to keynote LGBT luncheon honoring advocates of gender transitioning for children
 - [https://www.foxnews.com/politics/democrat-senator-keynote-lgbt-luncheon-honoring-advocates-gender-transitioning-children](https://www.foxnews.com/politics/democrat-senator-keynote-lgbt-luncheon-honoring-advocates-gender-transitioning-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:21:43+00:00

Sen. Tammy Baldwin will keynote a Human Rights Campaign luncheon Saturday, where other speakers include transgender advocates who have lobbied for puberty blockers for children.

## Arkansas coach emailed students who criticized him following loss: report
 - [https://www.foxnews.com/sports/arkansas-coach-emailed-students-who-criticized-him-following-loss-report](https://www.foxnews.com/sports/arkansas-coach-emailed-students-who-criticized-him-following-loss-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:01:23+00:00

Offensive coordinator Dan Enos reportedly sent emails to students who criticized his play-calling during Arkansas&apos; lost to Texas A&amp;M last week.

## Scalise makes House speaker pitch after Trump endorses Jordan: I know how to 'unify'
 - [https://www.foxnews.com/media/scalise-makes-house-speaker-pitch-trump-endorses-jordan-know-unify](https://www.foxnews.com/media/scalise-makes-house-speaker-pitch-trump-endorses-jordan-know-unify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T20:00:59+00:00

House Majority Leader Rep. Steve Scalise, R-La., shares his pitch on why he should be the next House speaker despite former President Trump endorsing Rep. Jim Jordan.

## Travis Kelce responds to Aaron Rodgers’ COVID-19 vaccine dig: ‘Mr. Pfizer vs. the Johnson and Johnson family’
 - [https://www.foxnews.com/sports/travis-kelce-responds-aaron-rodgers-covid-19-vaccine-dig-mr-pfizer-vs-johnson-johnson-family](https://www.foxnews.com/sports/travis-kelce-responds-aaron-rodgers-covid-19-vaccine-dig-mr-pfizer-vs-johnson-johnson-family)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:59:06+00:00

Travis Kelce can appreciate Aaron Rodgers&apos; dig on him over his recent partnership with pharmaceutical giant Pfizer, but he responded Friday with his own witty remark.

## White House mocks 'dysfunction-engulfed House Republicans' amid speaker battle
 - [https://www.foxnews.com/politics/white-house-mocks-dysfunction-engulfed-house-republicans-amid-speaker-battle](https://www.foxnews.com/politics/white-house-mocks-dysfunction-engulfed-house-republicans-amid-speaker-battle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:51:53+00:00

The White House mocked “dysfunction-engulfed House Republicans&quot; on Friday after the House voted to remove Rep. Kevin McCarthy from his speakership role.

## Ex-US Army sergeant indicted for attempting to give classified information to China
 - [https://www.foxnews.com/us/ex-us-army-sergeant-indicted-attempting-give-classified-information-china](https://www.foxnews.com/us/ex-us-army-sergeant-indicted-attempting-give-classified-information-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:51:40+00:00

An ex-U.S. Army sergeant has been charged with two felonies for allegedly trying to give national security secrets to Chinese intelligence.

## First case of avian flu detected on US commercial poultry farm since April
 - [https://www.foxnews.com/us/first-case-avian-flu-detected-us-commercial-poultry-farm-april](https://www.foxnews.com/us/first-case-avian-flu-detected-us-commercial-poultry-farm-april)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:45:30+00:00

The United States has identified its first case of avian flu on a commercial poultry farm since April, involving a flock of 47,300 turkeys located in Jerauld County, South Dakota.

## Arnold Schwarzenegger warns future of America may be ‘generation of wimps’
 - [https://www.foxnews.com/entertainment/arnold-schwarzenegger-warns-future-america-generation-wimps](https://www.foxnews.com/entertainment/arnold-schwarzenegger-warns-future-america-generation-wimps)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:43:21+00:00

Former California governor Arnold Schwarzenegger, 76, criticized the younger generation and raised concerns that this nation is &quot;creating a generation&quot; of &quot;weak people.&quot;

## Biden chides reporters for not being happy enough when reporting on economy: 'Gotta choose my words here'
 - [https://www.foxnews.com/media/biden-chides-reporters-happy-enough-reporting-economy-gotta-choose-words](https://www.foxnews.com/media/biden-chides-reporters-happy-enough-reporting-economy-gotta-choose-words)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:42:26+00:00

President Biden derided critiques of the economy under his administration by suggesting reporters were only interested in driving negative coverage on the topic.

## Lebanese prison fire leaves 3 dead, 16 injured
 - [https://www.foxnews.com/world/lebanese-prison-fire-leaves-3-dead-16-injured](https://www.foxnews.com/world/lebanese-prison-fire-leaves-3-dead-16-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:37:43+00:00

A prison incident in Lebanon took a tragic turn on Friday when inmates set their cells ablaze, resulting in three deaths and 16 injuries.

## Canada applauds trade dispute panel's ruling on US softwood lumber policy review
 - [https://www.foxnews.com/world/canada-applauds-trade-dispute-panels-ruling-us-softwood-lumber-policy-review](https://www.foxnews.com/world/canada-applauds-trade-dispute-panels-ruling-us-softwood-lumber-policy-review)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:36:20+00:00

Canada expressed its satisfaction with a ruling from a trade dispute panel, which stated that the U.S. should reevaluate certain aspects of its policy concerning softwood lumber.

## Biden stumbles over response to question about border wall funding
 - [https://www.foxnews.com/politics/biden-stumbles-response-question-border-wall-funding](https://www.foxnews.com/politics/biden-stumbles-response-question-border-wall-funding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:29:45+00:00

President Biden, after saying he just tried to “redirect&quot; funds for Texas border wall, says he &quot;tried to ask the Congress to consider changing the law.&quot;

## Typhoon Koinu approaches southern China, Hong Kong after Taiwan sees record-breaking winds
 - [https://www.foxnews.com/world/typhoon-koinu-approaches-southern-china-hong-kong-taiwan-sees-record-breaking-winds](https://www.foxnews.com/world/typhoon-koinu-approaches-southern-china-hong-kong-taiwan-sees-record-breaking-winds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:29:42+00:00

A typhoon is advancing towards southern China and Hong Kong after unleashing record-breaking winds and causing one fatality in Taiwan.

## Heavy rainfall triggers deadly flooding and landslides in Sri Lanka, leaving 6 dead
 - [https://www.foxnews.com/world/heavy-rainfall-triggers-deadly-flooding-landslides-sri-lanka-leaving-6-dead](https://www.foxnews.com/world/heavy-rainfall-triggers-deadly-flooding-landslides-sri-lanka-leaving-6-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:28:16+00:00

Heavy rainfall has triggered devastating floods, mudslides, and the toppling of trees in various regions of Sri Lanka, resulting in the deaths of at least six individuals.

## Rachel Bilson defends herself after Whoopi Goldberg slams her controversial statements on sex
 - [https://www.foxnews.com/entertainment/rachel-bilson-defends-herself-after-whoopi-goldberg-slams-her-controversial-statements-on-sex](https://www.foxnews.com/entertainment/rachel-bilson-defends-herself-after-whoopi-goldberg-slams-her-controversial-statements-on-sex)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:27:30+00:00

Rachel Bilson is defending herself against Whoopi Goldberg after &quot;The View&quot; host questioned the actress&apos;s statements about men with few sexual partners.

## Dem Pennsylvania Gov. Shapiro blasted over handling of sexual harassment allegations
 - [https://www.foxnews.com/politics/dem-pennsylvania-gov-shapiro-blasted-handling-sexual-harassment-allegations](https://www.foxnews.com/politics/dem-pennsylvania-gov-shapiro-blasted-handling-sexual-harassment-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:21:02+00:00

Pennsylvania Democrat Gov. Josh Shapiro was criticized by female GOP lawmakers over his handling of sexual harassment allegations against a top aide

## Lawyer claims NYC teen charged in poet slaying is 'great kid' who wasn't 'looking for trouble'
 - [https://www.foxnews.com/us/lawyer-claims-nyc-teen-charged-poet-slaying-great-kid-wasnt-looking-trouble](https://www.foxnews.com/us/lawyer-claims-nyc-teen-charged-poet-slaying-great-kid-wasnt-looking-trouble)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:13:00+00:00

A lawyer for a teen accused of randomly stabbing a NYC community activist to death in an ambush caught on camera requested bail, citing his client&apos;s lack of a criminal record.

## How to smartly organize your photos on a Mac
 - [https://www.foxnews.com/tech/how-smartly-organize-photos-mac](https://www.foxnews.com/tech/how-smartly-organize-photos-mac)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T19:03:48+00:00

You can organize the photos on your Macbook by using the &quot;Smart Album&quot; feature, which helps label the photos of each individual within your Apple icloud.

## Tom Brady, Paris Hilton, Snoop Dogg and Kendall Jenner change their names for AI
 - [https://www.foxnews.com/tech/tom-brady-paris-hilton-snoop-dogg-kendall-jenner-change-names-ai](https://www.foxnews.com/tech/tom-brady-paris-hilton-snoop-dogg-kendall-jenner-change-names-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T18:52:17+00:00

Tom Brady, Paris Hilton, Snoop Dogg and Kendall Jenner team up with Meta to create AI alter egos as they try to catch up to ChatGPT and its success so far.

## Bills' Von Miller says 'safe bet' he'll make his return in game against Jaguars in London
 - [https://www.foxnews.com/sports/bills-von-miller-says-safe-bet-hell-make-his-return-game-against-jaguars-london](https://www.foxnews.com/sports/bills-von-miller-says-safe-bet-hell-make-his-return-game-against-jaguars-london)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T18:29:55+00:00

The Buffalo Bills recently opened Von Miller&apos;s practice window, but head coach Sean McDermott said he was not sure whether the seven-time All-Pro would be available Sunday.

## Speaker candidates make their case to a fractured House GOP ahead of next week's vote
 - [https://www.foxnews.com/politics/speaker-candidates-make-their-case-fractured-house-gop-ahead-next-weeks-vote](https://www.foxnews.com/politics/speaker-candidates-make-their-case-fractured-house-gop-ahead-next-weeks-vote)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T18:15:01+00:00

Reps. Steve Scalise, Jim Jordan and Kevin Hern are making their pitches for speaker to a fractured House GOP conference ahead of next week&apos;s vote.

## MSNBC alarmed by Biden polling deficits on economy, sees 'big warning signs' for White House
 - [https://www.foxnews.com/media/msnbc-alarmed-biden-polling-deficits-economy-sees-big-warning-signs-white-house](https://www.foxnews.com/media/msnbc-alarmed-biden-polling-deficits-economy-sees-big-warning-signs-white-house)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T18:08:11+00:00

MSNBC&apos;s &apos;Morning Joe&apos; expressed alarm over new polls on who voters trust on the economy, saying the numbers should be &quot;warning signs&quot; for Democrats going into 2024 election.

## The big mistake in Pope Francis's new climate change scolding
 - [https://www.foxnews.com/opinion/big-mistake-pope-francis-new-climate-change-scolding](https://www.foxnews.com/opinion/big-mistake-pope-francis-new-climate-change-scolding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T18:00:02+00:00

There is an essential problem at the heart of Pope Francis&apos;s recent Apostolic Exhortation, Laudate Deum.

## Doctors Without Borders reports artillery fire in troubled Sudanese city, leaving 11 dead and 90 injured
 - [https://www.foxnews.com/world/doctors-borders-reports-artillery-fire-troubled-sudanese-city-leaving-11-dead-90-injured](https://www.foxnews.com/world/doctors-borders-reports-artillery-fire-troubled-sudanese-city-leaving-11-dead-90-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:44:55+00:00

Doctors Without Borders disclosed that a barrage of heavy artillery fire in a strife-ridden Sudanese city has resulted in the deaths of at least 11, with 90 others sustaining injuries.

## Indonesia denies responsibility for haze in Malaysia amid cross-border air quality concerns
 - [https://www.foxnews.com/world/indonesia-denies-responsibility-haze-malaysia-cross-border-air-quality-concerns](https://www.foxnews.com/world/indonesia-denies-responsibility-haze-malaysia-cross-border-air-quality-concerns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:43:25+00:00

On Friday, Indonesia refuted claims that the forest and peat fires occurring on Sumatra and Borneo islands were responsible for the haze in Malaysia.

## No charges for Georgia state troopers in fatal shooting at 'Cop City' protest site
 - [https://www.foxnews.com/us/charges-georgia-state-troopers-fatal-shooting-cop-city-protest-site](https://www.foxnews.com/us/charges-georgia-state-troopers-fatal-shooting-cop-city-protest-site)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:42:31+00:00

Georgia state troopers who fatally shot an activist near Atlanta will not face charges, as their use of deadly force was deemed &quot;objectively reasonable.&quot;

## Beautiful butterfly: Remarkable pictures show extremely rare long-tailed flying insect
 - [https://www.foxnews.com/lifestyle/beautiful-butterfly-pictures-show-extremely-rare-long-tailed-flying-insect](https://www.foxnews.com/lifestyle/beautiful-butterfly-pictures-show-extremely-rare-long-tailed-flying-insect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:41:55+00:00

Rare and unique butterflies were spotted in the United Kingdom ahead of the changing of the seasons. See the beautiful pictures of these insects in action!

## Former French President Nicolas Sarkozy faces preliminary charges in Libya campaign financing scandal
 - [https://www.foxnews.com/world/former-french-president-nicolas-sarkozy-faces-preliminary-charges-libya-campaign-financing-scandal](https://www.foxnews.com/world/former-french-president-nicolas-sarkozy-faces-preliminary-charges-libya-campaign-financing-scandal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:41:36+00:00

Investigative judges filed preliminary charges against ex-French President Nicolas Sarkozy Friday in connection with an alleged attempt to manipulate magistrates.

## Hunter Biden attorney withdraws from federal gun charge case
 - [https://www.foxnews.com/politics/hunter-biden-attorney-withdraws-federal-gun-charge-case](https://www.foxnews.com/politics/hunter-biden-attorney-withdraws-federal-gun-charge-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:30:31+00:00

An attorney for Hunter Biden, Richard Jones, filed paperwork Friday to withdraw himself from a federal gun charge case involving the president&apos;s son.

## Police find dead man in stranded driver's passenger seat: 'we got into it'
 - [https://www.foxnews.com/us/police-find-dead-man-stranded-drivers-passenger-seat-we-got-into-it](https://www.foxnews.com/us/police-find-dead-man-stranded-drivers-passenger-seat-we-got-into-it)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:29:40+00:00

Jihad Abdul Malik Gasaway was charged with abuse of a corpse, then murder, after police who pulled over to jump his car found Kemp Xavier Sherrod Harriel dead inside.

## House Republicans to hold conference meeting on Columbus Day amid speaker fight
 - [https://www.foxnews.com/politics/house-republicans-hold-conference-meeting-columbus-day-speaker-fight](https://www.foxnews.com/politics/house-republicans-hold-conference-meeting-columbus-day-speaker-fight)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:16:19+00:00

The House Republican conference will meet on Columbus Day amid the fight for the speaker&apos;s gavel after now-former House Speaker Kevin McCarthy&apos;s ouster on Tuesday.

## 'Jeopardy!' contestant slammed for 'bonehead wager': 'Can't he count?'
 - [https://www.foxnews.com/entertainment/jeopardy-contestant-slammed-bonehead-wager](https://www.foxnews.com/entertainment/jeopardy-contestant-slammed-bonehead-wager)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:01:22+00:00

A &quot;Jeopardy!&quot; contestant lost his game by making a surprising wager for Final Jeopardy, and fans of the game show are not impressed.

## Donna Kelce on meeting Taylor Swift amid rumored relationship with Chiefs star Travis Kelce: ‘It was okay’
 - [https://www.foxnews.com/sports/donna-kelce-meeting-taylor-swift-amid-rumored-relationship-chiefs-star-travis-kelce-it-was-okay](https://www.foxnews.com/sports/donna-kelce-meeting-taylor-swift-amid-rumored-relationship-chiefs-star-travis-kelce-it-was-okay)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:00:17+00:00

Donna Kelce briefly described what it was like meeting Taylor Swift for the first time amid rumors that her son, Kansas City Chiefs star Travis Kelce, is dating the pop star.

## Rod Blagojevich calls out Biden, Democrat leaders for creating migrant crisis: 'Whose side are you on?'
 - [https://www.foxnews.com/media/rod-blagojevich-calls-biden-democrat-leaders-creating-migrant-crisis-side](https://www.foxnews.com/media/rod-blagojevich-calls-biden-democrat-leaders-creating-migrant-crisis-side)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T17:00:06+00:00

Former Illinois Democratic Gov. Rod Blagojevich reacts to Democrats changing their tune on the border crisis as migrants overwhelm city resources.

## Timeline of Sen Bob Menendez's indictment with wife alleges yearslong corruption
 - [https://www.foxnews.com/politics/timeline-of-sen-bob-menendezs-indictment-with-wife-alleges-yearslong-corruption](https://www.foxnews.com/politics/timeline-of-sen-bob-menendezs-indictment-with-wife-alleges-yearslong-corruption)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:55:54+00:00

The timeline of the federal bribery scheme charges against Sen. Bob Menendez and his wife, Nadine Arslanian Menendez, alleges yearslong corruption.

## Navy sailor assigned to USS Germantown vanishes in San Diego
 - [https://www.foxnews.com/us/navy-sailor-assigned-uss-germantown-vanishes-san-diego](https://www.foxnews.com/us/navy-sailor-assigned-uss-germantown-vanishes-san-diego)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:36:14+00:00

Nija &quot;Towny&quot; Townsend Jr., 20, was last seen around 1 p.m. Saturday, while on shore leave from USS Germantown landing ship in San Diego.

## Growing Democratic anger with Biden on immigration becoming 'political headache' for POTUS: report
 - [https://www.foxnews.com/media/growing-democratic-anger-biden-immigration-becoming-political-headache-potus-report](https://www.foxnews.com/media/growing-democratic-anger-biden-immigration-becoming-political-headache-potus-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:35:47+00:00

There is growing anger within the Democratic Party over President Biden&apos;s inability to stem the current migrant crisis, according to a new report.

## Shooting inside Connecticut police station leads to arrest of woman accused of firing at officers
 - [https://www.foxnews.com/us/shooting-connecticut-police-station-leads-arrest-connecticut-woman-accused-firing-officers](https://www.foxnews.com/us/shooting-connecticut-police-station-leads-arrest-connecticut-woman-accused-firing-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:26:57+00:00

A woman is facing multiple charges in Connecticut after allegedly firing “multiple rounds&quot; inside the Bristol Police Department headquarters.

## US to help restore Oregon’s sacred Native American site destroyed by highway construction in 2008
 - [https://www.foxnews.com/us/us-help-restore-oregons-sacred-native-american-site-destroyed-highway-construction-2008](https://www.foxnews.com/us/us-help-restore-oregons-sacred-native-american-site-destroyed-highway-construction-2008)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:25:19+00:00

In 2008, a highway construction project destroyed a sacred Native American site in Oregon. The U.S. government has agreed to help restore the site and its stone alter.

## US Customs seize giraffe feces at Minnesota airport from woman who wanted to make jewelry with it
 - [https://www.foxnews.com/us/us-customs-seize-giraffe-feces-minnesota-airport-woman-wanted-make-jewelry](https://www.foxnews.com/us/us-customs-seize-giraffe-feces-minnesota-airport-woman-wanted-make-jewelry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:24:12+00:00

On Sept. 29, a woman from Iowa attempted to bring giraffe feces into the U.S. while she was returning from a trip to Kenya. US Customs have since seized and destroyed the fecal matter.

## Washington seaplane crash that led to 10 deaths was caused by mechanical issue, NTSB says
 - [https://www.foxnews.com/us/washington-seaplane-crash-led-10-deaths-caused-mechanical-issue-ntsb-says](https://www.foxnews.com/us/washington-seaplane-crash-led-10-deaths-caused-mechanical-issue-ntsb-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:23:28+00:00

Last year, a seaplane crashed into Puget Sound, Washington, and left 10 passengers dead. According to the NTSB, the crash was caused by a mechanical failure.

## Son of Buc-ee's co-founder accused of secretly filming guests in bathroom
 - [https://www.foxnews.com/us/son-buc-ees-co-founder-accused-secretly-filming-guests-bathroom](https://www.foxnews.com/us/son-buc-ees-co-founder-accused-secretly-filming-guests-bathroom)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:12:31+00:00

Mitchell Wasek, the son of Buc-ee&apos;s cofounder Don Wasek, is facing a total of 28 counts of invasive visual recording after he allegedly recorded people in bathrooms.

## Zelenskyy accuses Russia of 'terror' following bombing of Ukrainian village that killed 52: 'Absolute evil'
 - [https://www.foxnews.com/world/zelenskyy-accuses-russia-terror-bombing-ukrainian-village-killed-52-absolute-evil](https://www.foxnews.com/world/zelenskyy-accuses-russia-terror-bombing-ukrainian-village-killed-52-absolute-evil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:06:08+00:00

Ukrainian President Volodymyr Zelenskyy addressed the Russian bombing of a village shop and café in Hroza that left dozens of civilians dead.

## 20 surprising tips that adults wish they could tell their younger selves
 - [https://www.foxnews.com/lifestyle/20-surprising-tips-that-adults-wish-they-could-tell-younger-selves](https://www.foxnews.com/lifestyle/20-surprising-tips-that-adults-wish-they-could-tell-younger-selves)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T16:04:30+00:00

A study found the top 20 tips that adults would give their younger selves. Although most people live with no regrets, here are the most popular pieces of advice — with some surprises.

## Utah quarterback Cam Rising reveals full extent of knee injury
 - [https://www.foxnews.com/sports/utah-quarterback-cam-rising-reveals-full-extent-knee-injury](https://www.foxnews.com/sports/utah-quarterback-cam-rising-reveals-full-extent-knee-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:56:54+00:00

Utah Utes quarterback Cam Rising revealed the full extent of the knee injury he suffered in January&apos;s Rose Bowl game in a Thursday interview with ESPN 700.

## Chris Hemsworth makes major lifestyle changes after learning he's high risk for Alzheimer's disease
 - [https://www.foxnews.com/entertainment/chris-hemsworth-major-lifestyle-changes-high-risk-alzheimers](https://www.foxnews.com/entertainment/chris-hemsworth-major-lifestyle-changes-high-risk-alzheimers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:50:04+00:00

Australian actor Chris Hemsworth, 40, candidly spoke out about switching up his mind-and-body fitness routines after discovering he&apos;s at high risk for Alzheimer&apos;s disease.

## Bears move on from Chase Claypool, trade wide receiver to Dolphins
 - [https://www.foxnews.com/sports/bears-move-chase-claypool-trade-wide-receiver-dolphins](https://www.foxnews.com/sports/bears-move-chase-claypool-trade-wide-receiver-dolphins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:47:48+00:00

The Chicago Bears are moving on from wide receiver Chase Claypool, sending him to the Miami Dolphins on Friday. Miami has the best offense in the NFL.

## 45 Republicans call for House rules overhaul after McCarthy ouster: 'Ashamed and embarrassed'
 - [https://www.foxnews.com/politics/45-republicans-call-house-rules-overhaul-mccarthy-ouster-ashamed-embarrassed](https://www.foxnews.com/politics/45-republicans-call-house-rules-overhaul-mccarthy-ouster-ashamed-embarrassed)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:43:43+00:00

Nearly four dozen House Republicans are calling for significant changes to the chamber rules after former Speaker McCarthy was forced out of leadership this week.

## Man savagely kills, torches woman he mistakenly thought was his ex-girlfriend: prosecutors
 - [https://www.foxnews.com/us/man-savagely-kills-torches-woman-he-mistakenly-thought-was-his-ex-girlfriend-prosecutors](https://www.foxnews.com/us/man-savagely-kills-torches-woman-he-mistakenly-thought-was-his-ex-girlfriend-prosecutors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:41:19+00:00

A woman was brutally slaughtered and set on fire by a man who thought she was his ex-girlfriend who had ended their relationship a month earlier, according to prosecutors.

## House Judiciary Chairman Jordan praised for leadership on border crisis as speaker's race heats up
 - [https://www.foxnews.com/politics/house-judiciary-chairman-jordan-praised-leadership-border-crisis-speakers-race-heats-up](https://www.foxnews.com/politics/house-judiciary-chairman-jordan-praised-leadership-border-crisis-speakers-race-heats-up)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:39:34+00:00

Rep. Jim Jordan is receiving support from members on the committee for his leadership on border security and illegal immigration, after a busy year amid a migrant crisis.

## Dallas mayor abandons Democrat Party over defund the police 'nonsense,' says Black communities want safety
 - [https://www.foxnews.com/media/dallas-mayor-abandons-democrat-party-defund-police-nonsense-says-black-communities-safety](https://www.foxnews.com/media/dallas-mayor-abandons-democrat-party-defund-police-nonsense-says-black-communities-safety)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:31:22+00:00

Dallas Mayor Eric Johnson spoke with &quot;FOX &amp; Friends&quot; exclusively about his switch to the Republican Party, calling out the &quot;lawlessness&quot; in Democrat-run cities.

## Iranian Security forces arrest, threaten mother of teen girl in coma over dress code clash: report
 - [https://www.foxnews.com/world/iranian-security-forces-arrest-threaten-mother-teen-girl-coma-dress-code-clash-report](https://www.foxnews.com/world/iranian-security-forces-arrest-threaten-mother-teen-girl-coma-dress-code-clash-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:26:48+00:00

The morality police arrested and released Armita Geravand&apos;s mother allegedly on condition that she not speak to the public or media about her daughter&apos;s health.

## Footprints found at ancient lake in New Mexico challenge old belief of first humans in Americas
 - [https://www.foxnews.com/us/footprints-found-ancient-lake-new-mexico-challenges-old-belief-first-humans-americas](https://www.foxnews.com/us/footprints-found-ancient-lake-new-mexico-challenges-old-belief-first-humans-americas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:26:32+00:00

New research finds that humans might have first entered the New World not over the Bering land bridge between Russia and Alaska, but thousands of years earlier.

## Singer Maren Morris blasts country music culture as hateful, suggests female fans have 'internalized misogyny'
 - [https://www.foxnews.com/media/singer-maren-morris-blasts-country-music-culture-hateful-suggests-female-fans-have-internalized-misogyny](https://www.foxnews.com/media/singer-maren-morris-blasts-country-music-culture-hateful-suggests-female-fans-have-internalized-misogyny)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:18:48+00:00

Singer Maren Morris said it was &quot;hyperbolic&quot; to say she&apos;s leaving country music, after she slammed the &quot;really toxic&quot; and &quot;racist&quot; industry in a recent interview.

## Michigan police officer shoots, kills armed woman while serving search warrant
 - [https://www.foxnews.com/us/michigan-police-officer-shoots-kills-armed-woman-serving-search-warrant](https://www.foxnews.com/us/michigan-police-officer-shoots-kills-armed-woman-serving-search-warrant)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:17:07+00:00

A 41-year-old armed woman was shot and killed Thursday by a police officer who was executing a search warrant in Norwich Township, Michigan.

## Whales, dolphins in US waters facing habitat loss, food scarcity due to warming waters, study finds
 - [https://www.foxnews.com/us/whales-dolphins-us-waters-facing-habitat-loss-food-scarcity-due-warming-waters-study-finds](https://www.foxnews.com/us/whales-dolphins-us-waters-facing-habitat-loss-food-scarcity-due-warming-waters-study-finds)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:04:15+00:00

According to a study by the National Oceanic and Atmospheric Administration, a majority of America’s marine mammals are being threatened by climate change.

## Menendez controversy: Officer at scene of future wife's deadly car crash identified
 - [https://www.foxnews.com/politics/menendez-controversy-officer-scene-future-wifes-deadly-car-crash-identified](https://www.foxnews.com/politics/menendez-controversy-officer-scene-future-wifes-deadly-car-crash-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:01:47+00:00

A retired police official helped Robert Menendez’s future wife leave the scene of a deadly car crash without a sobriety test or giving up her phone, the New York Post reveals.

## NYC Mayor Eric Adams goes to Mexico to discuss migrants, says there is ‘no more room in New York’
 - [https://www.foxnews.com/world/nyc-mayor-eric-adams-goes-mexico-discuss-migrants-says-no-more-room-new-york](https://www.foxnews.com/world/nyc-mayor-eric-adams-goes-mexico-discuss-migrants-says-no-more-room-new-york)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T15:00:23+00:00

New York City Mayor Eric Adams, during his trip to Latin America, said in Mexico that there is “no more room&quot; in his city for migrants.

## Biden's war on Elon Musk, Matt Gaetz villain or hero? and more from Fox News Opinion
 - [https://www.foxnews.com/opinion/biden-war-elon-musk-matt-gaetz-villain-hero-fox-news-opinion](https://www.foxnews.com/opinion/biden-war-elon-musk-matt-gaetz-villain-hero-fox-news-opinion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:55:23+00:00

Read the latest from Fox News Opinion &amp; watch videos from Sean Hannity, Raymond Arroyo &amp; more.

## Darien jungle, a treacherous route for migrants, becomes more accessible as Panama sees uptick in arrivals
 - [https://www.foxnews.com/world/darien-jungle-treacherous-route-migrants-becomes-accessible-panama-sees-uptick-arrivals](https://www.foxnews.com/world/darien-jungle-treacherous-route-migrants-becomes-accessible-panama-sees-uptick-arrivals)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:52:17+00:00

Panama is still facing a massive flow of migrants from the Darien Gap, one of the world’s most dangerous areas. A route has been organized to allow migrants to reach Panama in two days.

## Taste-tasters deliver verdict on Coca-Cola’s new AI-generated recipe
 - [https://www.foxnews.com/us/taste-tasters-deliver-verdict-coca-colas-new-ai-generated-recipe](https://www.foxnews.com/us/taste-tasters-deliver-verdict-coca-colas-new-ai-generated-recipe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:45:52+00:00

Coca-Cola&apos;s new futuristic flavor was co-created using artificial intelligence. Some Americans said it tasted better than the original recipe, but others couldn&apos;t stomach a whole can.

## Donna Kelce says NFL is ‘laughing all the way to the bank’ with Taylor Swift, Travis Kelce dating rumors
 - [https://www.foxnews.com/sports/donna-kelce-says-nfl-laughing-all-way-bank-taylor-swift-travis-kelce-dating-rumors](https://www.foxnews.com/sports/donna-kelce-says-nfl-laughing-all-way-bank-taylor-swift-travis-kelce-dating-rumors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:35:05+00:00

Donna Kelce thinks the NFL is &quot;laughing all the way to the bank&quot; with the hype surrounding the rumored romance between Travis Kelce and Taylor Swift.

## Advocacy groups accuse Ohio Statehouse maps of favoring Republicans, despite bipartisan support
 - [https://www.foxnews.com/politics/advocacy-groups-accuse-ohio-statehouse-maps-favoring-republicans-despite-bipartisan-support](https://www.foxnews.com/politics/advocacy-groups-accuse-ohio-statehouse-maps-favoring-republicans-despite-bipartisan-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:13:43+00:00

An Ohio district map, which received bipartisan support following a string of failed proposals, has been challenged again. Groups claimed that the latest proposal favors Republicans.

## California-based procrastination book club finally finishes its first tome after 28 years
 - [https://www.foxnews.com/lifestyle/california-procrastination-book-club-finally-finishes-first-tome-28-years](https://www.foxnews.com/lifestyle/california-procrastination-book-club-finally-finishes-first-tome-28-years)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:12:27+00:00

A book club based in Los Angeles has finally finished reading its first book selection — which it began 28 years ago. The group finished &quot;Finnegans Wake&quot; by James Joyce this week.

## Joe Rogan derides ‘woke’ military practices, jokes ‘inclusion is really important when you’re killing folks’
 - [https://www.foxnews.com/media/joe-rogan-derides-woke-military-practices-jokes-inclusion-really-important-when-youre-killing-folks](https://www.foxnews.com/media/joe-rogan-derides-woke-military-practices-jokes-inclusion-really-important-when-youre-killing-folks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T14:00:00+00:00

Podcaster Joe Rogan and his guests mocked modern DEI policies in the English-speaking world, noting militaries in the U.S. and the U.K. have parallel problems.

## In NYC, dad weeps as officials announce charges in day care drug operation that left his toddler dead
 - [https://www.foxnews.com/us/nyc-dad-weeps-officials-announce-charges-day-care-drug-operation-left-s-toddler-dead](https://www.foxnews.com/us/nyc-dad-weeps-officials-announce-charges-day-care-drug-operation-left-s-toddler-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:48:59+00:00

Otoniel Feliz, the father of a toddler who died from an apparent overdose at a Bronx day care center, was seen weeping as officials announced charges against three suspects.

## Magic Johnson critical of Commanders in Bears loss: ‘Played with no intensity or fire'
 - [https://www.foxnews.com/sports/magic-johnson-critical-commanders-bears-loss-played-no-intensity-fire](https://www.foxnews.com/sports/magic-johnson-critical-commanders-bears-loss-played-no-intensity-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:47:55+00:00

Washington Commanders part-owner Magic Johnson took to X following Washington&apos;s loss to the Chicago Bears, saying the team &quot;played with no intensity or fire.&quot;

## AOC demands Biden 'reverse course' on border wall construction amid migrant surge: 'Cruel policy'
 - [https://www.foxnews.com/politics/aoc-demands-biden-reverse-course-border-wall-construction-migrant-surge-cruel-policy](https://www.foxnews.com/politics/aoc-demands-biden-reverse-course-border-wall-construction-migrant-surge-cruel-policy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:37:16+00:00

Rep. Alexandria Ocasio-Cortez, a New York Democrat, has urged President Biden to stop constructing a wall at the U.S.-Mexico border amid a migrant surge.

## A snapshot into Jennifer Aniston's decades-long career in the TV and film industries
 - [https://www.foxnews.com/entertainment/jennifer-aniston-tv-movie-career](https://www.foxnews.com/entertainment/jennifer-aniston-tv-movie-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:34:05+00:00

Jennifer Aniston&apos;s career took off after the show &quot;Friends,&quot; but she has continued far beyond the sitcom. She has continued to act in shows and movies over her many years as an actress.

## NYC subway mass shooter who injured 10 gets life in prison
 - [https://www.foxnews.com/us/nyc-subway-mass-shooter-who-injured-10-gets-life-in-prison](https://www.foxnews.com/us/nyc-subway-mass-shooter-who-injured-10-gets-life-in-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:25:57+00:00

The Brooklyn subway mass shooter, who injured a dozen people while everyone was trapped in a moving train in 2022, has been sentenced. Frank James has received life in prison.

## PM Sunak's new proposal aims to completely ban cigarettes
 - [https://www.foxnews.com/world/pm-sunak-new-proposal-aimes-completely-ban-cigarettes](https://www.foxnews.com/world/pm-sunak-new-proposal-aimes-completely-ban-cigarettes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:23:50+00:00

United Kingdom Prime Minister Rishi Sunak is proposing a progressive age ban on smoking that would ultimately bar anyone in England from buying cigarettes.

## 2 Ohio men sentenced in the killing of a Michigan woman in 2017
 - [https://www.foxnews.com/us/2-ohio-men-sentenced-in-the-killing-of-a-michigan-woman-in-2017](https://www.foxnews.com/us/2-ohio-men-sentenced-in-the-killing-of-a-michigan-woman-in-2017)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:22:43+00:00

A couple of Ohio men have been sentenced in the killing of Egypt Covington, a 27-year-old Michigan woman who was shot in the head. Covington was found dead in her home.

## 'Django Unchained' actor Keith Jefferson dead at 53
 - [https://www.foxnews.com/entertainment/django-unchained-actor-keith-jefferson-dead-53](https://www.foxnews.com/entertainment/django-unchained-actor-keith-jefferson-dead-53)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T13:20:23+00:00

Actor Keith Jefferson has died at the age of 53. Jefferson worked alongside Jamie Foxx, Samuel L. Jackson and other stars in Quentin Tarantino&apos;s movies.

## Banff grizzly bear attack: Uncle reveals chilling final message he received from Canadian couple before deaths
 - [https://www.foxnews.com/world/banff-grizzly-bear-attack-uncle-reveals-chilling-final-message-received-canadian-couple-before-deaths](https://www.foxnews.com/world/banff-grizzly-bear-attack-uncle-reveals-chilling-final-message-received-canadian-couple-before-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T12:50:28+00:00

The relative of one of the victims of a fatal bear attack in Canada’s Banff National Park says he received an SOS call and message from the couple.

## In Lebanon, less than half of the 4 million people that need humanitarian aid have received help, UN says
 - [https://www.foxnews.com/world/lebanon-half-4-million-people-need-humanitarian-aid-received-help-un-says](https://www.foxnews.com/world/lebanon-half-4-million-people-need-humanitarian-aid-received-help-un-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T12:34:56+00:00

According to the U.N., four million people in Lebanon are in need of food, including Syrians, Palestinian refugees, and migrants. However less than half have received humanitarian aid.

## 31 dead in India’s Himalayan northeast after lake bursts through major dam
 - [https://www.foxnews.com/world/31-dead-indias-himalayan-northeast-lake-bursts-major-dam](https://www.foxnews.com/world/31-dead-indias-himalayan-northeast-lake-bursts-major-dam)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T12:29:49+00:00

Flooding caused by an overflowing glacial lake that broke through a major dam in India has caused 31 deaths. Relief camps have been set up to assist the thousands of people affected.

## Putin suggests adding India, other countries to UN Security Council
 - [https://www.foxnews.com/world/putin-suggests-adding-india-other-countries-un-security-council](https://www.foxnews.com/world/putin-suggests-adding-india-other-countries-un-security-council)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T12:06:46+00:00

Russian President Vladimir Putin pitched changes to international law during a speech at the Valdai Discussion Club, including adding members to the U.N. Security Council.

## Supreme Court could bring Big Tech's armageddon
 - [https://www.foxnews.com/opinion/supreme-court-could-bring-big-tech-armageddon](https://www.foxnews.com/opinion/supreme-court-could-bring-big-tech-armageddon)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T12:00:21+00:00

The Supreme Court is poised to resolve decide who is protected by the First Amendment.

## Florida man accused of carjacking woman at gas station was released from jail days prior
 - [https://www.foxnews.com/us/florida-man-accused-carjacking-woman-gas-station-released-jail-days-prior](https://www.foxnews.com/us/florida-man-accused-carjacking-woman-gas-station-released-jail-days-prior)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:38:22+00:00

A Florida man who was arrested in August in connection with two burglaries is back behind bars after surveillance footage at a gas station allegedly shows him carjacking a woman.

## 6 dead, 38 injured in Mumbai after fire engulfs 6-story residential building
 - [https://www.foxnews.com/world/6-dead-38-injured-mumbai-fire-engulfs-6-story-residential-building](https://www.foxnews.com/world/6-dead-38-injured-mumbai-fire-engulfs-6-story-residential-building)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:28:55+00:00

A fire has erupted at a six-story residential building in Mumbai, the financial and entertainment hub of India. The blaze caused six deaths and dozens of injuries.

## 3 bears captured and killed in Japan after sneaking into factory
 - [https://www.foxnews.com/world/3-bears-captured-killed-japan-sneaking-factory](https://www.foxnews.com/world/3-bears-captured-killed-japan-sneaking-factory)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:28:18+00:00

A bear and two cubs, which likely left the forests to look for food, have snuck into a factory in northern Japan. The animals have since been captured and killed.

## North Korea preparing for satellite launch attempt, South Korean think tank warns
 - [https://www.foxnews.com/world/north-korea-preparing-satellite-launch-attempt-south-korean-think-tank-warns](https://www.foxnews.com/world/north-korea-preparing-satellite-launch-attempt-south-korean-think-tank-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:19:21+00:00

North Korea is expected to make a third attempt at launching a spy satellite in the middle of October, according to a South Korean think tank.

## Jailed Iranian activist Narges Mohammadi wins 2023 Nobel Peace Prize
 - [https://www.foxnews.com/world/jailed-iranian-activist-narges-mohammadi-wins-2023-nobel-peace-prize](https://www.foxnews.com/world/jailed-iranian-activist-narges-mohammadi-wins-2023-nobel-peace-prize)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:07:31+00:00

Narges Mohammadi, a jailed Iranian activist, is the winner of this year’s Nobel Peace Prize and should be released, the Nobel committee chair announced.

## Scalise touts fundraising numbers to supporters amid heated speakers race
 - [https://www.foxnews.com/politics/scalise-touts-fundraising-numbers-to-supporters-amid-heated-speakers-race](https://www.foxnews.com/politics/scalise-touts-fundraising-numbers-to-supporters-amid-heated-speakers-race)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T11:00:33+00:00

House Majority Leader Steve Scalise is pitching himself as a &quot;fundraising powerhouse&quot; in a new memo to donors and supporters within the House GOP.

## Trump announces speaker endorsement, Biden's Hunter-linked nomination 'raises concerns' and more top headlines
 - [https://www.foxnews.com/us/trump-announces-house-speaker-endorsement](https://www.foxnews.com/us/trump-announces-house-speaker-endorsement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:45:00+00:00

Get all the stories you need-to-know from the most powerful name in news delivered first thing every morning to your inbox.

## Hillary Clinton floats 'formal deprogramming' of Trump supporters, suggests GOP base is made of bigots
 - [https://www.foxnews.com/media/hillary-clinton-floats-formal-deprogramming-trump-supporters-suggests-gop-base-bigots](https://www.foxnews.com/media/hillary-clinton-floats-formal-deprogramming-trump-supporters-suggests-gop-base-bigots)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:25:44+00:00

Former Secretary of State Hillary Clinton floated the idea of a &quot;formal deprogramming&quot; of Trump supporters and suggested the Republican base is made up of bigots.

## Philippines furious after Chinese coast guard ship comes within 3 feet of colliding with Philippine vessel
 - [https://www.foxnews.com/world/philippines-furious-after-chinese-coast-guard-ship-comes-within-feet-colliding-philippine-vessel](https://www.foxnews.com/world/philippines-furious-after-chinese-coast-guard-ship-comes-within-feet-colliding-philippine-vessel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:09:49+00:00

The Philippines strongly condemned China&apos;s navy for a &apos;dangerous&apos; maneuver in the South China Sea, near Second Thomas Shoal, when two ships nears collided.

## Nancy Mace defends vote to oust McCarthy as unity opportunity: 'He was fired for not keeping promises'
 - [https://www.foxnews.com/media/nancy-mace-defends-oust-mccarthy-unity-opportunity-fired-not-keeping-promises](https://www.foxnews.com/media/nancy-mace-defends-oust-mccarthy-unity-opportunity-fired-not-keeping-promises)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:00:49+00:00

Rep. Nancy Mace, R-S.C., defended her vote to oust Rep. Kevin McCarthy, R-Calif., from the House speakership, telling &quot;The Story&quot; he didn&apos;t keep promises.

## Chicago youth football team to protest after city's plan to house migrants threatens to displace program
 - [https://www.foxnews.com/sports/chicago-youth-football-team-protest-citys-plan-house-migrants-threatens-displace-program](https://www.foxnews.com/sports/chicago-youth-football-team-protest-citys-plan-house-migrants-threatens-displace-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:00:27+00:00

Chicago residents are speaking out after the city&apos;s plans to utilize a local field house to house migrants threatens to displace a youth football team.

## Shohei Ohtani, next team will have to decide his future on the mound, MLB legend says
 - [https://www.foxnews.com/sports/shohei-ohtani-next-team-will-have-decide-future-mound-mlb-legend-says](https://www.foxnews.com/sports/shohei-ohtani-next-team-will-have-decide-future-mound-mlb-legend-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:00:18+00:00

Baseball Hall of Famer Tom Glavine appeared on OutKick&apos;s &quot;Don&apos;t @ Me with Dan Dakich&quot; and discussed Shohei Ohtani&apos;s future in Major League Baseball.

## 2023 MLB Postseason: What to know about the Division Series matchups
 - [https://www.foxnews.com/sports/2023-mlb-postseason-what-to-know-division-series-matchups](https://www.foxnews.com/sports/2023-mlb-postseason-what-to-know-division-series-matchups)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:00:17+00:00

The Division Series in the MLB Postseason is set to kick off Saturday. Here&apos;s a deep dive into all eight teams ahead of the four matchups.

## Super Bowl champion Bobby Wagner says his current Seahawks team hasn't 'reached its potential yet'
 - [https://www.foxnews.com/sports/super-bowl-champion-bobby-wagner-says-current-seahawks-team-hasnt-reached-its-potential-yet](https://www.foxnews.com/sports/super-bowl-champion-bobby-wagner-says-current-seahawks-team-hasnt-reached-its-potential-yet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T10:00:08+00:00

Seattle Seahawks linebacker Bobby Wagner once played in back-to-back Super Bowls, so he knows what it takes to get to the promised land.

## 'The Exorcist: Believer' replicates 1973 horror movie by leaving viewers ‘shaken to their core’: filmmakers
 - [https://www.foxnews.com/entertainment/the-exorcist-believer-replicates-1973-horror-movie-leaving-viewers-shaken-core-filmmakers](https://www.foxnews.com/entertainment/the-exorcist-believer-replicates-1973-horror-movie-leaving-viewers-shaken-core-filmmakers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:30:54+00:00

&quot;The Exorcist: Believer&quot; director David Gordon Green and producer Jason Blum spoke about how they reinvented the story for a sequel 50 years in the making.

## Yelling at kids could cause long-term harm to their psyches, says new study: ‘A hidden problem’
 - [https://www.foxnews.com/health/yelling-kids-could-cause-long-term-harm-psyches-study-hidden-problem](https://www.foxnews.com/health/yelling-kids-could-cause-long-term-harm-psyches-study-hidden-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:30:39+00:00

Parents or caregivers who yell at their kids could create negative effects on kids’ mental and physical health, a new study suggests. Experts weigh in on the dangers of childhood verbal abuse.

## The more people exercise, the lazier they are throughout the rest of the day, study suggests
 - [https://www.foxnews.com/health/more-people-exercise-lazier-they-are-throughout-day-study-suggests](https://www.foxnews.com/health/more-people-exercise-lazier-they-are-throughout-day-study-suggests)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:15:09+00:00

The amount of time you spend following a structured exercise routine, the more likely you are to cut back on other physical daily activities, according to a recent study. Experts weigh in.

## Trump endorses Jim Jordan for speaker of the House: 'Complete & Total Endorsement'
 - [https://www.foxnews.com/politics/trump-endorses-jim-jordan-for-speaker-house-complete-total-endorsement](https://www.foxnews.com/politics/trump-endorses-jim-jordan-for-speaker-house-complete-total-endorsement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:11:30+00:00

Former President Trump gave Rep. Jim Jordan his “Complete &amp; Total Endorsement&quot; for speaker of the House, saying he is is “respected by all.&quot;

## Here's how to pick next House Speaker. This is the way to do it, Republicans
 - [https://www.foxnews.com/opinion/pick-house-speaker-way-do-republicans](https://www.foxnews.com/opinion/pick-house-speaker-way-do-republicans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:00:48+00:00

Kevin McCarthy has lost his role as speaker of the House. But before Republicans select the next speaker it&apos;s time to rethink the process. It&apos;s time for Republicans to do this right.

## Student loan repayments are back. Will colleges continue to get a free pass for this mess?
 - [https://www.foxnews.com/opinion/student-loan-repayments-back-will-colleges-continue-free-pass-mess](https://www.foxnews.com/opinion/student-loan-repayments-back-will-colleges-continue-free-pass-mess)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:00:48+00:00

Student loan repayments are back. Will colleges continue to get a free pass for this mess? And will anyone point fingers at the government for its role in the fiasco?

## St. Louis woman declared dead 16 years ago begs government to acknowledge she's alive: 'One is too many'
 - [https://www.foxnews.com/media/st-louis-woman-declared-dead-15-years-begs-government-still-alive](https://www.foxnews.com/media/st-louis-woman-declared-dead-15-years-begs-government-still-alive)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:00:15+00:00

A St. Louis resident told Fox News Digital about her predicament with trying to prove she&apos;s alive 16 years after her she was declared deceased.

## Josh Duhamel blames Hollywood for Fergie divorce, says it can 'suck the soul out of you'
 - [https://www.foxnews.com/entertainment/josh-duhamel-blames-hollywood-for-fergie-divorce-says-it-can-suck-the-soul-out-of-you](https://www.foxnews.com/entertainment/josh-duhamel-blames-hollywood-for-fergie-divorce-says-it-can-suck-the-soul-out-of-you)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:00:07+00:00

Josh Duhamel opened up in an interview on “In Depth with Graham Bensinger&quot; about his divorce from Fergie and why he felt like he never fit in with fame and Hollywood.

## Team Biden let Iran infiltrate the nuclear deal. That puts all of us at risk
 - [https://www.foxnews.com/opinion/team-biden-iran-infiltrate-nuclear-deal-puts-risk](https://www.foxnews.com/opinion/team-biden-iran-infiltrate-nuclear-deal-puts-risk)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T09:00:05+00:00

Team Biden let Iran infiltrate the nuclear deal. That puts all of us at risk as our enemy was working both sides of the negotiations. Now it&apos;s time for Congress to get answers.

## Hot chocolate isn’t healthy, but it can be with one surprising twist
 - [https://www.foxnews.com/lifestyle/hot-chocolate-isnt-healthy-but-can-be-one-surprising-twist](https://www.foxnews.com/lifestyle/hot-chocolate-isnt-healthy-but-can-be-one-surprising-twist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:45:43+00:00

Food experts reveal one key way to make hot chocolate healthier than it generally is — the secret is using dark chocolate in the mix. Read on for other smart nutrition and health tips.

## Former cops, activists seek answers as police departments hemorrhage officers: 'A real crisis'
 - [https://www.foxnews.com/media/former-cops-activists-weigh-in-on-why-police-departments-are-hemorrhaging-officers-a-real-crisis](https://www.foxnews.com/media/former-cops-activists-weigh-in-on-why-police-departments-are-hemorrhaging-officers-a-real-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:30:49+00:00

Former police officers and community activists weigh in on why police departments are struggling to attract applicants, and how to improve morale.

## Pennsylvania K-9 who helped catch convicted murderer retires after eight years of service: 'He loved to work'
 - [https://www.foxnews.com/lifestyle/pennsylvania-k-9-helped-catch-convicted-murderer-retires-eight-years-service-he-loved-to-work](https://www.foxnews.com/lifestyle/pennsylvania-k-9-helped-catch-convicted-murderer-retires-eight-years-service-he-loved-to-work)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:30:37+00:00

A German Shepherd has retired from the K-9 unit at the Lower Paxton Township Police Department in Pennsylvania, after more than eight years of service and hundreds of apprehensions.

## Sophie Turner battles Joe Jonas from Taylor Swift-owned pad, seen with pitbull attorney who represents royalty
 - [https://www.foxnews.com/entertainment/sophie-turner-battles-joe-jonas-taylor-swift-owned-pad-seen-pitbull-attorney-represents-royalty](https://www.foxnews.com/entertainment/sophie-turner-battles-joe-jonas-taylor-swift-owned-pad-seen-pitbull-attorney-represents-royalty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:30:14+00:00

Joe Jonas and Sophie Turner&apos;s divorce battle took a surprising turn after a judge approved mediation. The musician and actress have been fighting over custody of their children.

## Former Manhattan assistant DA says Letitia James made 'tactical error' in blasting Trump over trial
 - [https://www.foxnews.com/media/former-manhattan-assistant-da-says-letitia-james-made-tactical-error-blasting-trump-trial](https://www.foxnews.com/media/former-manhattan-assistant-da-says-letitia-james-made-tactical-error-blasting-trump-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:57+00:00

MSBNC legal analyst Rebecca Roiphe argued that New York Attorney General Letitia James&apos; recent condemnation of former President Donald Trump during his trial was a &quot;tactical error.&quot;

## 'Wonder Years' star Danica McKellar’s move to Tennessee was a ‘total quality of life improvement’
 - [https://www.foxnews.com/entertainment/danica-mckellars-new-faith-era-move-tennessee-total-quality-life-improvement](https://www.foxnews.com/entertainment/danica-mckellars-new-faith-era-move-tennessee-total-quality-life-improvement)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:55+00:00

&quot;Wonder Years&quot; star Danica McKellar spoke to Fox News Digital about moving to Tennessee and her new journey into faith aided by friend Candace Cameron Bure.

## GOP rebels continue to blast McCarthy after sending House business into chaos: 'That's just silly'
 - [https://www.foxnews.com/politics/gop-rebels-continue-blast-mccarthy-sending-house-business-chaos-thats-just-silly](https://www.foxnews.com/politics/gop-rebels-continue-blast-mccarthy-sending-house-business-chaos-thats-just-silly)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:53+00:00

Two House Republicans defended their votes to oust Rep. Kevin McCarthy as House speaker and defended the criticism that they needed Democrat support in order to do so.

## Foreign policy experts call on House to solve 'chaos,' warn 'enemies will be emboldened'
 - [https://www.foxnews.com/us/foreign-policy-experts-call-house-solve-chaos-warn-enemies-emboldened](https://www.foxnews.com/us/foreign-policy-experts-call-house-solve-chaos-warn-enemies-emboldened)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:47+00:00

The ouster of McCarthy as House speaker and the chaos that ensued could lead U.S. adversaries to take advantage of the crippling state of Congress, foreign policy experts say.

## Time’s up for Christie allies urging Democrats to switch parties to vote against Trump in primary
 - [https://www.foxnews.com/politics/christie-allies-urging-democrats-switch-parties-vote-against-trump-primary](https://www.foxnews.com/politics/christie-allies-urging-democrats-switch-parties-vote-against-trump-primary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:44+00:00

Chris Christie allies urging New Hampshire Democrats to change their voter registration and support Christie and oppose Trump in the state&apos;s GOP presidential primary face a deadline

## Republican investigations proceed despite House Speaker drama: 'Keeping our foot on the gas'
 - [https://www.foxnews.com/politics/republican-investigations-proceed-despite-house-speaker-drama](https://www.foxnews.com/politics/republican-investigations-proceed-despite-house-speaker-drama)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:40+00:00

The House GOP will not slow their sprawling investigations into the Biden administration despite the recent vote to oust House Speaker Kevin McCarthy, Fox News Digital has learned.

## Biden's choice of Hunter's ex-colleague for whistleblower post 'raises concerns' he's guarding his son: Comer
 - [https://www.foxnews.com/politics/bidens-choice-hunters-ex-colleague-whistleblower-post-raises-concerns-guarding-son-comer](https://www.foxnews.com/politics/bidens-choice-hunters-ex-colleague-whistleblower-post-raises-concerns-guarding-son-comer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:35+00:00

Biden nominated an individual previously tied to a law firm with his son to head a whistleblower office, which House Oversight Committee Chairman James Comer says raises concerns.

## New York Dem's Capitol Hill fire alarm incident referred to feds for charges similar to Jan. 6 rioters
 - [https://www.foxnews.com/politics/new-york-dems-capitol-hill-fire-alarm-incident-referred-feds-charges-similar-jan-6-rioters](https://www.foxnews.com/politics/new-york-dems-capitol-hill-fire-alarm-incident-referred-feds-charges-similar-jan-6-rioters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:34+00:00

A conservative think tank&apos;s watchdog arm sent a criminal referral to the FBI and Capitol Police, among others, about New York Democrat Rep. Jamaal Bowman pulling a fire alarm.

## Meet the American who paved the way for the interstate, Gen. Lucius Clay, master planner, hero of two nations
 - [https://www.foxnews.com/lifestyle/meet-american-paved-way-interstate-gen-lucius-clay-master-planner-hero-nations](https://www.foxnews.com/lifestyle/meet-american-paved-way-interstate-gen-lucius-clay-master-planner-hero-nations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:24+00:00

Gen. Lucius D. Clay was called by President Dwight Eisenhower to create a plan to build the Interstate Highway System, after a career of grand logistics achievements.

## Crime-fighting mom who led campaign against prolific bike thief shocked by judge's decision
 - [https://www.foxnews.com/world/crime-fighting-mom-led-campaign-prolific-bike-thief-shocked-judges-decision](https://www.foxnews.com/world/crime-fighting-mom-led-campaign-prolific-bike-thief-shocked-judges-decision)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:13+00:00

A U.K. mom who took fighting crime into her own hands when her son&apos;s bike was stolen said she&apos;s &quot;angry&quot; with the &quot;slap on the wrist&quot; sentencing for the alleged thief.

## Charlotte Sena case: FBI child abduction unit making 'miracle' recoveries more common
 - [https://www.foxnews.com/us/charlotte-sena-case-fbi-child-abduction-unit-making-miracle-recoveries-more-common](https://www.foxnews.com/us/charlotte-sena-case-fbi-child-abduction-unit-making-miracle-recoveries-more-common)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:08+00:00

The FBI&apos;s CARD – Child Abduction Rapid Deployment – team has helped find abducted children alive nearly 50% of the time, the agency said.

## Mother weighs in on winning court ruling in favor of parents' rights to know about their child's transition
 - [https://www.foxnews.com/media/mother-weighs-court-ruling-favor-parents-rights-know-childs-transition](https://www.foxnews.com/media/mother-weighs-court-ruling-favor-parents-rights-know-childs-transition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:08+00:00

A Wisconsin judge ruled in favor of parents who sued a school district over a policy that affirmed students&apos; gender transitions without parental consent.

## Parents of Jared Bridegan's ex-wife 'patently lying' in child custody docs after mom's murder arrest: expert
 - [https://www.foxnews.com/us/parents-jared-bridegan-ex-wife-patently-lying-child-custody-docs-moms-murder-arrest-expert](https://www.foxnews.com/us/parents-jared-bridegan-ex-wife-patently-lying-child-custody-docs-moms-murder-arrest-expert)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T08:00:06+00:00

Shanna Gardner-Fernandez&apos;s parents are seeking custody of the children she shares with her ex-husband, Jared Bridegan, who prosecutors say she had murdered.

## Why the handyman who turned the tables on squatters confronted a celebrity chef accused of living rent-free
 - [https://www.foxnews.com/media/why-handyman-turned-tables-squatters-confronted-celebrity-chef-accused-living-rent-free](https://www.foxnews.com/media/why-handyman-turned-tables-squatters-confronted-celebrity-chef-accused-living-rent-free)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T07:30:18+00:00

A handyman said he successfully helped get Iron Chef winner and former judge Adam Fleischman to leave a woman&apos;s Hollywood home. Fleischman denies he was squatting.

## Vermont State Police searching for 'armed and dangerous' suspect in 'suspicious death' of woman on trail
 - [https://www.foxnews.com/us/vermont-state-police-searching-armed-dangerous-suspect-suspicious-death-woman-trail](https://www.foxnews.com/us/vermont-state-police-searching-armed-dangerous-suspect-suspicious-death-woman-trail)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T07:30:09+00:00

Vermont State Police is leading a multi-agency investigation into a woman&apos;s &quot;suspicious death&quot; on the Rail Trail in Castleton. An alert for an &quot;armed and dangerous&quot; man has been issued.

## Professor warns California's equity-based math curriculum will be a 'complete failure'
 - [https://www.foxnews.com/media/professor-warns-california-equity-based-math-curriculum-complete-failure](https://www.foxnews.com/media/professor-warns-california-equity-based-math-curriculum-complete-failure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T07:00:55+00:00

Stanford math professor Brian Conrad warned California&apos;s new &apos;equity&apos;-based math curriculum could backfire as students continue to battle the impact of pandemic learning loss.

## UK prime minister says country shouldn't 'be bullied' into believing there are more than 2 genders
 - [https://www.foxnews.com/world/uk-prime-minister-says-country-shouldnt-be-bullied-believing-there-are-more-than-2-genders](https://www.foxnews.com/world/uk-prime-minister-says-country-shouldnt-be-bullied-believing-there-are-more-than-2-genders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T06:00:58+00:00

U.K. Prime Minister Rishi Sunak went viral for his speech this week, saying that U.K. citizens shouldn&apos;t be &quot;bullied into believing that people can be any sex they want.&quot;

## After House speaker gets ousted, some Americans say democracy is at risk: ‘radicals more and more in charge’
 - [https://www.foxnews.com/politics/house-speaker-gets-ousted-americans-say-democracy-risk-radicals-charge](https://www.foxnews.com/politics/house-speaker-gets-ousted-americans-say-democracy-risk-radicals-charge)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T06:00:55+00:00

Americans walking in the nation&apos;s capital weighed in on the state of democracy in the country after former House Speaker Kevin McCarthy was removed from his position.

## Robin Williams’ daughter, and Tom Hanks, Keira Knightley among stars fighting against AI
 - [https://www.foxnews.com/entertainment/robin-williams-daughter-tom-hanks-keira-knightley-among-stars-fighting-against-ai](https://www.foxnews.com/entertainment/robin-williams-daughter-tom-hanks-keira-knightley-among-stars-fighting-against-ai)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T06:00:55+00:00

Robin Williams&apos; daughter, Zelda, spoke out amid the actors strike about her father&apos;s voice being used by AI without his consent as experts weigh in on the technology&apos;s use in Hollywood.

## What my interview with Saudi Crown Prince Mohammed bin Salman reveals about the power of democracy
 - [https://www.foxnews.com/opinion/interview-saudi-crown-prince-mohammed-bin-salman-reveals-power-democracy](https://www.foxnews.com/opinion/interview-saudi-crown-prince-mohammed-bin-salman-reveals-power-democracy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T06:00:45+00:00

I recently interviewed the crown prince of Saudia Arabia. The Kingdom&apos;s leader sat down for his first interview entirely in English. Our discussion inspired reflections on democracy.

## Studies find it 'impossible' to create any 'reliable' AI watermarks: 'Very sophisticated' problem
 - [https://www.foxnews.com/us/studies-find-impossible-create-reliable-ai-watermarks-sophisticated-problem](https://www.foxnews.com/us/studies-find-impossible-create-reliable-ai-watermarks-sophisticated-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T06:00:26+00:00

The current proposal for watermarking AI material does not stop other actors who get their hands on the technology or methods to apply them separately to remove the watermarks.

## Bears hold off Commanders' second half comeback to snap 14-game losing streak
 - [https://www.foxnews.com/sports/bears-hold-off-commanders-second-half-comeback-snap-14-game-losing-streak](https://www.foxnews.com/sports/bears-hold-off-commanders-second-half-comeback-snap-14-game-losing-streak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T04:15:53+00:00

The Chicago Bears can finally etch one in the win column, as they snapped a 14-game losing streak that spanned to the 2022 season with a 40-20 win over the Washington Commanders.

## GREG GUTFELD: Los Angeles Unified is more focused on National Coming Out Day than reading, math scores
 - [https://www.foxnews.com/opinion/greg-gutfeld-los-angeles-unified-more-focused-national-coming-out-day-reading-math-scores](https://www.foxnews.com/opinion/greg-gutfeld-los-angeles-unified-more-focused-national-coming-out-day-reading-math-scores)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T04:11:36+00:00

FOX News host Greg Gutfeld sounds off on Los Angeles Unified School District for pushing National Coming Out Day on &quot;Gutfeld!&quot;

## Missouri teacher resigned after discovery of OnlyFans account, turned full focus on porn: 'I'm that teacher'
 - [https://www.foxnews.com/us/missouri-teacher-resigned-after-discovery-onlyfans-account-turned-full-focus-porn-teacher](https://www.foxnews.com/us/missouri-teacher-resigned-after-discovery-onlyfans-account-turned-full-focus-porn-teacher)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T04:04:39+00:00

A Missouri high school English teacher resigned from teaching after officials found that she had an OnlyFans account as a side hustle. She is now turning to pornography full time.

## On this day in history, October 6, 1927, 'The Jazz Singer' released, first film with synchronized sound
 - [https://www.foxnews.com/lifestyle/this-day-history-oct-6-1927-jazz-singer-released-film-synchronized-sound](https://www.foxnews.com/lifestyle/this-day-history-oct-6-1927-jazz-singer-released-film-synchronized-sound)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T04:02:36+00:00

&quot;The Jazz Singer&quot; starring Al Jolson, the first movie with talking actors, was released on this day in history, Oct. 6, 1927. The cinema landmark caused a sensation.

## SEAN HANNITY: The Biden White House is happy to ignore the border crisis
 - [https://www.foxnews.com/media/sean-hannity-biden-white-house-happy-ignore-border-crisis](https://www.foxnews.com/media/sean-hannity-biden-white-house-happy-ignore-border-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T02:12:56+00:00

FOX News host Sean Hannity calls out the Biden administration over the influx of illegal immigrants across the country on &quot;Hannity.&quot;

## Ramaswamy dismisses alleged hit-and-run incident, defends peaceful detractors: They're 'hungry for a cause'
 - [https://www.foxnews.com/media/ramaswamy-dismisses-alleged-hit-run-incident-defends-peaceful-detractors-hungry-cause](https://www.foxnews.com/media/ramaswamy-dismisses-alleged-hit-run-incident-defends-peaceful-detractors-hungry-cause)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T02:02:54+00:00

Vivek Ramaswamy told &quot;Jesse Watters Primetime&quot; that many of the protesters who engage with him are not the enemy, but instead Americans in search of purpose.

## JESSE WATTERS: Politicians have decided Chicago is now Guadalajara
 - [https://www.foxnews.com/media/jesse-watters-politicians-chicago-now-guadalajara](https://www.foxnews.com/media/jesse-watters-politicians-chicago-now-guadalajara)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:59:37+00:00

FOX News host Jesse Watters breaks down the migrant influx disturbing Chicago residents on &quot;Jesse Watters Primetime.&quot;

## Bears' DJ Moore makes fantasy owners happy after torching Commanders in first half
 - [https://www.foxnews.com/sports/bears-dj-moore-makes-fantasy-owners-happy-torching-commanders-first-half](https://www.foxnews.com/sports/bears-dj-moore-makes-fantasy-owners-happy-torching-commanders-first-half)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:54:50+00:00

Chicago Bears top wide receiver D.J. Moore helped his winless team get off to a hot start against the Washington Commanders, collecting two touchdowns in just over 15 minutes.

## Kansas homeless man charged with murder and rape of 5-year-old girl in Topeka
 - [https://www.foxnews.com/us/kansas-homeless-man-charged-murder-rape-5-year-old-girl-topeka](https://www.foxnews.com/us/kansas-homeless-man-charged-murder-rape-5-year-old-girl-topeka)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:45:36+00:00

A 25-year-old homeless man in Kansas was formally charged on Thursday with murder and rape in connection with the tragic killing of a 5-year-old girl, Zoey Felix, earlier this week.

## Washington governor requests federal aid for wildfire recovery
 - [https://www.foxnews.com/us/washington-governor-requests-federal-aid-wildfire-recovery](https://www.foxnews.com/us/washington-governor-requests-federal-aid-wildfire-recovery)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:41:53+00:00

Washington Governor Inslee has reached out to Joe Biden, requesting federal assistance and a disaster declaration to aid in the recovery efforts following the destructive wildfires.

## Former Samsung executive reveals Google pressure in antitrust trial
 - [https://www.foxnews.com/us/former-samsung-executive-reveals-google-pressure-antitrust-trial](https://www.foxnews.com/us/former-samsung-executive-reveals-google-pressure-antitrust-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:40:05+00:00

A former executive at Samsung Electronics&apos; venture capital arm revealed in an antitrust trial that his proposal to install Branch Metrics&apos; software in Samsung smartphones faced resistance due to pressure from Google.

## US poised to tighten restrictions on chip equipment exports to China
 - [https://www.foxnews.com/us/us-poised-tighten-restrictions-chip-equipment-exports-china](https://www.foxnews.com/us/us-poised-tighten-restrictions-chip-equipment-exports-china)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:38:21+00:00

A rule aimed at restricting exports of U.S. chipmaking equipment to China is in the final stages of review, suggesting the Biden administration is tightening restrictions on Beijing.

## Maryland smash-and-grab suspects caught on camera raiding cellphone storefront
 - [https://www.foxnews.com/us/maryland-smash-grab-suspects-caught-camera-raiding-cellphone-storefront](https://www.foxnews.com/us/maryland-smash-grab-suspects-caught-camera-raiding-cellphone-storefront)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:14:27+00:00

Maryland police released footage of a suspect breaking into a cellphone store at 2 a.m. and stealing merchandise.

## Undersea video of lost WWII aircraft carriers provides new clues about their dramatic last moments
 - [https://www.foxnews.com/lifestyle/undersea-video-lost-wwii-aircraft-carriers-provides-clues-last-moments](https://www.foxnews.com/lifestyle/undersea-video-lost-wwii-aircraft-carriers-provides-clues-last-moments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:09:03+00:00

New video footage of three aircraft carriers sunk during the Battle of Midway in 1942 has provided additional insight into the last moments of the doomed ships.

## Trump drops lawsuit against Michael Cohen, vows to re-file after he has 'prevailed' in other cases
 - [https://www.foxnews.com/politics/trump-drops-suit-against-michael-cohen-vows-refile-prevailed-cases](https://www.foxnews.com/politics/trump-drops-suit-against-michael-cohen-vows-refile-prevailed-cases)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:03:20+00:00

Former President Trump is voluntarily dismissing his lawsuit against his former attorney Michael Cohen, but vowed to refile against him once he has “prevailed&quot; in the “witch hunts against him,&quot; Fox News Digital has learned.

## Karine Jean-Pierre ripped for deflecting questions about Biden admin building border wall: ‘She’s a joke'
 - [https://www.foxnews.com/media/karine-jean-pierre-ripped-deflecting-questions-biden-admin-building-border-wall-shes-joke](https://www.foxnews.com/media/karine-jean-pierre-ripped-deflecting-questions-biden-admin-building-border-wall-shes-joke)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:01:36+00:00

X users ridiculed White House Press Secretary Karine Jean-Pierre after she claimed she had &quot;not seen&quot; DHS Secretary Alejandro Mayorkas&apos; request for increased border wall.

## Raiders' Davante Adams supports backup QB Aidan O'Connell, who filled in for injured Jimmy Garoppolo: report
 - [https://www.foxnews.com/sports/raiders-davante-adams-supports-backup-qb-aidan-oconnell-who-filled-in-for-injured-jimmy-garoppolo-report](https://www.foxnews.com/sports/raiders-davante-adams-supports-backup-qb-aidan-oconnell-who-filled-in-for-injured-jimmy-garoppolo-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T01:00:19+00:00

The Raiders spent a fourth-round draft pick on quarterback Aidan O&apos;Connell. Last week, the rookie stepped up, throwing for more than 200 yards in his first NFL game as a starter.

## Alabama Gov. Ivey sending 275 National Guard troops to Mexico border: ‘Every state has become a border state'
 - [https://www.foxnews.com/politics/alabama-gov-ivey-sending-national-guard-troops-mexico-border-every-state-has-become-border-state](https://www.foxnews.com/politics/alabama-gov-ivey-sending-national-guard-troops-mexico-border-every-state-has-become-border-state)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:53:05+00:00

Alabama Gov. Kay Ivey is sending 275 National Guard troops to the southern border, saying &quot;every state has become a border state&quot; amid a migrant crisis.

## LAURA INGRAHAM: Biden is pretending to secure the border because he feels enormous political pressure
 - [https://www.foxnews.com/media/laura-ingraham-biden-pretending-secure-border-because-he-feels-enormous-political-pressure](https://www.foxnews.com/media/laura-ingraham-biden-pretending-secure-border-because-he-feels-enormous-political-pressure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:50:28+00:00

FOX News&apos; Laura Ingraham says the Biden administration has a &apos;full-blown&apos; political crisis on their hands on &apos;The Ingraham Angle.&apos;

## Illinois woman stabbed ex-husband over grocery store purchases: Police
 - [https://www.foxnews.com/us/illinois-woman-stabbed-ex-husband-grocery-store-purchases-police](https://www.foxnews.com/us/illinois-woman-stabbed-ex-husband-grocery-store-purchases-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:47:05+00:00

An Illinois woman allegedly stabbed her former husband several times this week during a fight over his grocery stores purchases, police said

## Virginia swimmers unite, speak out after biological male pulls Lia Thomas, tries to join team
 - [https://www.foxnews.com/sports/virginia-swimmers-unite-biological-male-lia-thomas-team](https://www.foxnews.com/sports/virginia-swimmers-unite-biological-male-lia-thomas-team)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:41:55+00:00

Members of the Roanoke College women’s swim team spoke out Thursday about their experience after a transgender student student had requested permission to swim with the women’s team.

## Hillary Clinton warns Trump has 'cult' support, calls 2016 election 'pretty traumatic'
 - [https://www.foxnews.com/media/hillary-clinton-warns-trump-cult-support-calls-2016-election-pretty-traumatic](https://www.foxnews.com/media/hillary-clinton-warns-trump-cult-support-calls-2016-election-pretty-traumatic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:22:14+00:00

Former Democratic presidential candidate Hillary Clinton demeaned Trump followers once again by comparing them to “being in a cult&quot; on “PBS Newshour.&quot;

## WATCH: Florida man slaps piping hot coffee onto fast-food employee over cost of drink
 - [https://www.foxnews.com/us/watch-moment-florida-man-slaps-piping-hot-coffee-onto-fast-food-employee-over-cost-drink](https://www.foxnews.com/us/watch-moment-florida-man-slaps-piping-hot-coffee-onto-fast-food-employee-over-cost-drink)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-10-06T00:10:20+00:00

A Florida man was arrested after he slapped a cup of hot coffee out of a fast-food employee&apos;s hands at the drive-thru window because he was upset about how much he paid.

