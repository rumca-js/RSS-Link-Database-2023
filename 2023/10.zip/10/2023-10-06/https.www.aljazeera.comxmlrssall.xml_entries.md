# Source:Aljazeera, URL:https://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Her son was killed by the Colombian military. Now, she’s getting an apology
 - [https://www.aljazeera.com/news/2023/10/6/her-son-was-killed-by-the-colombian-military-now-shes-getting-an-apology?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/her-son-was-killed-by-the-colombian-military-now-shes-getting-an-apology?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T22:12:01+00:00

Defence Minister Ivan Velasquez has apologised to families of 19 civilians killed by soldiers under false pretenses.

## US auto workers halt strike expansion after concessions on EV battery plant
 - [https://www.aljazeera.com/news/2023/10/6/us-auto-workers-halt-strike-expansion-after-concessions-on-ev-battery-plant?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/us-auto-workers-halt-strike-expansion-after-concessions-on-ev-battery-plant?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T20:47:58+00:00

UAW President Fain praises breakthrough, with implications for labour arrangements undergirding green transition.

## Poland and Hungary clash with EU leaders over migration reform
 - [https://www.aljazeera.com/news/2023/10/6/poland-and-hungary-clash-with-eu-leaders-over-migration-reform?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/poland-and-hungary-clash-with-eu-leaders-over-migration-reform?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T19:27:34+00:00

Migration has become a flashpoint in the European continent’s politics and a central focus of far-right parties.

## Has Bashar al-Assad really won the war in Syria?
 - [https://www.aljazeera.com/program/inside-story/2023/10/6/has-bashar-al-assad-really-won-the-war-in-syria?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2023/10/6/has-bashar-al-assad-really-won-the-war-in-syria?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T19:13:35+00:00

Government blames armed groups for attack on military academy in Homs.

## UK’s opposition Labour Party gets a boost from Scotland by-election victory
 - [https://www.aljazeera.com/news/2023/10/6/uks-opposition-labour-party-gets-a-boost-from-scotland-by-election-victory?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/uks-opposition-labour-party-gets-a-boost-from-scotland-by-election-victory?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T18:40:24+00:00

Labour leader Keir Starmer hails &#039;seismic result&#039; as his party takes a parliamentary seat from the SNP.

## Iowa risks millions of dollars as it faces losing first-vote status
 - [https://www.aljazeera.com/economy/2023/10/6/iowa-risks-millions-of-dollars-as-it-faces-losing-first-vote-status?traffic_source=rss](https://www.aljazeera.com/economy/2023/10/6/iowa-risks-millions-of-dollars-as-it-faces-losing-first-vote-status?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T18:13:06+00:00

Democrats moving from Iowa to South Carolina for first vote in primary cycle means less money for Midwestern state.

## US jobs growth exceeds expectations, fuels interest rate hike fears
 - [https://www.aljazeera.com/news/2023/10/6/us-jobs-growth-exceeds-expectations-fuels-interest-rate-hike-fears?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/us-jobs-growth-exceeds-expectations-fuels-interest-rate-hike-fears?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T16:27:09+00:00

The US economy added 336,000 jobs in September, far more than many economists expected.

## Palestinian killed as Israeli settlers attack West Bank town of Huwara
 - [https://www.aljazeera.com/news/2023/10/6/palestinian-killed-as-israeli-settlers-attack-west-bank-town-of-huwara?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/palestinian-killed-as-israeli-settlers-attack-west-bank-town-of-huwara?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T16:08:58+00:00

The killing of 19-year-old Labib Dumaidi comes amid a period of rising settler violence across the West Bank.

## Pakistan beat Netherlands by 81 runs in ICC Cricket World Cup 2023
 - [https://www.aljazeera.com/sports/2023/10/6/pakistan-beat-netherlands-by-runs-in-icc-cricket-world-cup-2023?traffic_source=rss](https://www.aljazeera.com/sports/2023/10/6/pakistan-beat-netherlands-by-runs-in-icc-cricket-world-cup-2023?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T15:52:12+00:00

Haris Rauf took three wickets as Pakistan&#039;s bowlers dismissed Netherlands for 205.

## ‘They miscalculated’: Ukraine turns the tables on Russia’s Black Sea Fleet
 - [https://www.aljazeera.com/news/2023/10/6/they-miscalculated-ukraine-turns-the-tables-on-russias-black-sea-fleet?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/they-miscalculated-ukraine-turns-the-tables-on-russias-black-sea-fleet?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T14:47:16+00:00

Russia relocates ships from Sevastopol while the UK lauds Kyiv&#039;s &#039;functional defeat of the Black Sea Fleet.

## Afghanistan vs Bangladesh: ICC Cricket World Cup 2023 preview
 - [https://www.aljazeera.com/sports/2023/10/6/bangladesh-vs-afghanistan-icc-cricket-world-cup-2023-preview?traffic_source=rss](https://www.aljazeera.com/sports/2023/10/6/bangladesh-vs-afghanistan-icc-cricket-world-cup-2023-preview?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T14:26:48+00:00

Afghanistan have never beaten Bangladesh at the ICC Cricket World Cup and will aim to change that in Saturday&#039;s match.

## Who is Nobel Peace Prize winner Narges Mohammadi?
 - [https://www.aljazeera.com/news/2023/10/6/who-is-nobel-peace-prize-winner-narges?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/who-is-nobel-peace-prize-winner-narges?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T13:46:30+00:00

The jailed Nobel laureate has been a prominent voice in Iran&#039;s women&#039;s movement.

## Why is the Biden administration forgiving student debt?
 - [https://www.aljazeera.com/news/2023/10/6/why-is-the-biden-administration-forgiving-student-debt?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/why-is-the-biden-administration-forgiving-student-debt?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T13:31:05+00:00

This week Joe Biden announced debt relief worth billions of dollars for struggling graduates.

## ‘You can still smell the blood’: Shock turns to grief in Ukraine’s Hroza
 - [https://www.aljazeera.com/news/2023/10/6/you-can-still-smell-the-blood-shock-turns-to-grief-in-ukraines-hroza?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/you-can-still-smell-the-blood-shock-turns-to-grief-in-ukraines-hroza?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T13:25:18+00:00

Relatives struggling to cope after attack that killed more than 50 people in tiny village in northeastern Ukraine.

## Abaya ban in French public schools: Secularism or discrimination?
 - [https://www.aljazeera.com/program/upfront/2023/10/6/abaya-ban-in-french-public-schools-secularism-or-discrimination?traffic_source=rss](https://www.aljazeera.com/program/upfront/2023/10/6/abaya-ban-in-french-public-schools-secularism-or-discrimination?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T12:49:28+00:00

UpFront examines discrimination and secularism in France after the government bans the abaya in public schools.

## Nagorno-Karabakh: Ethnic cleansing or restoring sovereignty?
 - [https://www.aljazeera.com/program/upfront/2023/10/6/nagorno-karabakh-ethnic-cleansing-or-restoring-sovereignty?traffic_source=rss](https://www.aljazeera.com/program/upfront/2023/10/6/nagorno-karabakh-ethnic-cleansing-or-restoring-sovereignty?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T12:46:57+00:00

Marc Lamont Hill challenges the Azerbaijani Ambassador to the United Kingdom on the situation in Nagorno-Karabakh.

## Under Sunak, can the right-wing Conservatives win another UK election?
 - [https://www.aljazeera.com/news/2023/10/6/is-the-uk-conservative-partys-governance-working?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/is-the-uk-conservative-partys-governance-working?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T12:24:43+00:00

Party, which held a divisive conference this week, has been in power for 13 years but is struggling in opinion polls.

## European Union leaders meet in Granada to discuss enlargement, migration
 - [https://www.aljazeera.com/news/2023/10/6/european-union-leaders-meet-in-granada-to-discuss-enlargement-migration?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/european-union-leaders-meet-in-granada-to-discuss-enlargement-migration?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T12:11:23+00:00

Summit comes a day after dozens of European leaders pledged continued support for Ukraine in fight against Russia.

## Ethnic Armenians who fled Nagorno-Karabakh long for home, decry Azerbaijan
 - [https://www.aljazeera.com/news/2023/10/6/ethnic-armenians-who-fled-karabakh?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/ethnic-armenians-who-fled-karabakh?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T11:48:41+00:00

Having fled Nagorno-Karabakh, ethnic Armenians say they won&#039;t return as they bank on more support from Armenia.

## Who are the 2023 Nobel Prize winners so far?
 - [https://www.aljazeera.com/news/2023/10/6/who-are-the-2023-nobel-prize-winners-so-far?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/who-are-the-2023-nobel-prize-winners-so-far?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T11:41:05+00:00

This year&#039;s laureates have opened doors for disease control, technological advancements and subversive literature.

## India is weaponising FATF recommendations against civil society
 - [https://www.aljazeera.com/opinions/2023/10/6/india-is-weaponising-fatf-recommendations-against-civil-society?traffic_source=rss](https://www.aljazeera.com/opinions/2023/10/6/india-is-weaponising-fatf-recommendations-against-civil-society?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T11:40:23+00:00

The terrorism financing watchdog should beware of India&#039;s misuse of its recommendations to stifle dissent.

## Egypt’s bonds spiral lower after Moody’s downgrade over economic woes
 - [https://www.aljazeera.com/economy/2023/10/6/egypts-bonds-spiral-lower-after-moodys-downgrade-over-economic-woes?traffic_source=rss](https://www.aljazeera.com/economy/2023/10/6/egypts-bonds-spiral-lower-after-moodys-downgrade-over-economic-woes?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T10:21:36+00:00

The agency says Egypt&#039;s worsening debt affordability led to its decision to cut the country&#039;s credit rating.

## Syria mourns dozens of people killed in Homs drone attack
 - [https://www.aljazeera.com/news/2023/10/6/syria-mourns-dozens-of-people-killed-in-homs-drone-attack?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/syria-mourns-dozens-of-people-killed-in-homs-drone-attack?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T10:06:03+00:00

Funerals held for victims of attack on military academy during graduation ceremony.

## World Bank reform will remain elusive until this is understood
 - [https://www.aljazeera.com/opinions/2023/10/6/world-bank-reform-will-remain-elusive-until-this-is-understood?traffic_source=rss](https://www.aljazeera.com/opinions/2023/10/6/world-bank-reform-will-remain-elusive-until-this-is-understood?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T09:57:26+00:00

The bank has actually been very successful - just not for the poor it’s claimed to serve.

## Why is Pakistan deporting undocumented Afghans?
 - [https://www.aljazeera.com/news/2023/10/6/why-is-pakistan-deporting-undocumented-afghans?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/why-is-pakistan-deporting-undocumented-afghans?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T09:52:05+00:00

Afghan government has called Pakistan&#039;s decision to expel Afghans living in the country without approval &#039;unacceptable&#039;.

## Biden administration to extend US border wall, begin Venezuela deportations
 - [https://www.aljazeera.com/news/2023/10/6/biden-administration-to-extend-us-border-wall-begin-venezuela-deportations?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/biden-administration-to-extend-us-border-wall-begin-venezuela-deportations?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T09:31:10+00:00

President Joe Biden&#039;s government to carry forward a signature policy of former President Donald Trump.

## Iran’s jailed rights advocate Narges Mohammadi wins 2023 Nobel Peace Prize
 - [https://www.aljazeera.com/news/2023/10/6/irans-narges-mohammadi-wins-2023-nobel-peace-prize?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/irans-narges-mohammadi-wins-2023-nobel-peace-prize?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T09:03:08+00:00

Mohammadi is honoured for her fight against &#039;the oppression of women&#039; in Iran at &#039;tremendous personal costs&#039;.

## Death toll rises to 40 in India’s Sikkim flooding after lake overflow
 - [https://www.aljazeera.com/news/2023/10/6/death-toll-rises-to-40-in-indias-sikkim-flooding-after-lake-overflow?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/death-toll-rises-to-40-in-indias-sikkim-flooding-after-lake-overflow?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T08:51:54+00:00

Thousands are rescued but dozens remain missing two days after heavy rainfall prompted a glacial lake to overflow.

## Deadly floods in India’s Himalayas after lake bursts through major dam
 - [https://www.aljazeera.com/gallery/2023/10/6/deadly-floods-in-indias-himalayas-after-lake-bursts-through-major-dam?traffic_source=rss](https://www.aljazeera.com/gallery/2023/10/6/deadly-floods-in-indias-himalayas-after-lake-bursts-through-major-dam?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T08:43:33+00:00

Rescue workers are searching for nearly 100 people after flash floods triggered by heavy rainfall killed at least 40.

## US shoots down Turkish drone over Syria after attacks near Hasakah
 - [https://www.aljazeera.com/news/2023/10/6/us-shoots-down-turkeys-drone-over-syria-after-strikes-near-hasakeh?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/us-shoots-down-turkeys-drone-over-syria-after-strikes-near-hasakeh?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T08:37:34+00:00

The incident comes as Turkey intensifies its military operation in northern Syria after a suicide bombing in Ankara.

## Who is Rachin Ravindra, New Zealand’s Cricket World Cup star?
 - [https://www.aljazeera.com/sports/2023/10/6/who-is-rachin-ravindra-new-zealands-cricket-world-cup-star?traffic_source=rss](https://www.aljazeera.com/sports/2023/10/6/who-is-rachin-ravindra-new-zealands-cricket-world-cup-star?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T07:58:55+00:00

Ravindra&#039;s story came full circle as his cricket-mad parents watched him make a World Cup 100 for New Zealand in India.

## A look back at 1973’s October War
 - [https://www.aljazeera.com/gallery/2023/10/6/a-look-back-at-1973s-october-war?traffic_source=rss](https://www.aljazeera.com/gallery/2023/10/6/a-look-back-at-1973s-october-war?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T07:44:31+00:00

It is 50 years since the start of the war between Israel, Egypt and Syria, known to Arabs as the October War.

## Ex-President Donald Trump endorses Jim Jordan to be US House Speaker
 - [https://www.aljazeera.com/news/2023/10/6/ex-president-donald-trump-endorses-jim-jordan-to-be-us-house-speaker?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/ex-president-donald-trump-endorses-jim-jordan-to-be-us-house-speaker?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T07:41:19+00:00

The former president backs House Judiciary Committee chairman for the key position after removal of Kevin McCarthy.

## The October 1973 War: How it led to the first Arab recognition of Israel
 - [https://www.aljazeera.com/news/2023/10/6/the-october-1973-war-how-it-led-to-the-first-arab-recognition-of-israel?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/the-october-1973-war-how-it-led-to-the-first-arab-recognition-of-israel?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T07:10:21+00:00

Fifty years after the Arab-Israeli war, Israel continues to occupy the West Bank, East Jerusalem and Gaza.

## How the October War changed the world
 - [https://www.aljazeera.com/features/2023/10/6/how-the-october-war-changed-the-world?traffic_source=rss](https://www.aljazeera.com/features/2023/10/6/how-the-october-war-changed-the-world?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T05:44:32+00:00

Fifty years later, it&#039;s clear the war not only transformed Arab-Israeli relations, but also global alliances.

## WADA warns of ‘consequences’ over North Korean flag at Asian Games
 - [https://www.aljazeera.com/news/2023/10/6/wada-warns-of-consequences-over-north-korean-flag-at-asian-games?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/wada-warns-of-consequences-over-north-korean-flag-at-asian-games?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T05:23:33+00:00

The North Korean flag has been routinely hoisted whenever their athletes have made the podium despite a ban.

## Philippines’ drag artist Pura Luka Vega arrested for ‘offending religion’
 - [https://www.aljazeera.com/news/2023/10/6/philippines-drag-artist-pura-luka-vega-arrested-for-offending-religion?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/philippines-drag-artist-pura-luka-vega-arrested-for-offending-religion?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T04:59:42+00:00

Performer faces as many as 12 years in prison after their punk rock rendition of the Lord&#039;s Prayer went viral.

## Trump revealed US nuclear submarine secrets to Australia businessman: Media
 - [https://www.aljazeera.com/news/2023/10/6/trump-revealed-us-nuclear-subs-secrets-to-australian-businessman-us-media?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/trump-revealed-us-nuclear-subs-secrets-to-australian-businessman-us-media?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T04:40:58+00:00

Trump reported to have told Australian billionaire Anthony Pratt about tactical capabilities of US nuclear submarines.

## Bangladesh gets first uranium shipment from Russia for nuclear power plant
 - [https://www.aljazeera.com/news/2023/10/6/bangladesh-gets-first-uranium-shipment-from-russia-for-nuclear-power-plant?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/bangladesh-gets-first-uranium-shipment-from-russia-for-nuclear-power-plant?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T03:52:45+00:00

Russia is financing 90 percent of $12.65bn project to build Bangladesh&#039;s first nuclear power plant in Rooppur.

## Putin says Ukraine would last ‘a week’ if Western military support stops
 - [https://www.aljazeera.com/news/2023/10/6/putin-says-ukraine-would-last-a-week-if-western-military-support-stops?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/putin-says-ukraine-would-last-a-week-if-western-military-support-stops?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T03:02:58+00:00

Putin&#039;s prediction comes as concerns mount about future of US funding for Ukraine amid political turmoil in Washington.

## As vote nears, ‘horrific racism’ mars Australian Voice referendum campaign
 - [https://www.aljazeera.com/news/2023/10/6/as-vote-nears-horrific-racism-mars-australian-voice-referendum-campaign?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/as-vote-nears-horrific-racism-mars-australian-voice-referendum-campaign?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T02:51:52+00:00

Campaigning for historic vote on October 14 has exposed sharp divides in society and within the Indigenous community.

## Russia-Ukraine war: List of key events, day 590
 - [https://www.aljazeera.com/news/2023/10/6/russia-ukraine-war-list-of-key-events-day-590?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/russia-ukraine-war-list-of-key-events-day-590?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T01:22:10+00:00

As the war enters its 590th day, these are the main developments.

## Putin suggests Wagner mercenary chief’s plane brought down by grenade blast
 - [https://www.aljazeera.com/news/2023/10/6/putin-suggests-wagner-mercenary-chiefs-plane-brought-down-by-grenade-blast?traffic_source=rss](https://www.aljazeera.com/news/2023/10/6/putin-suggests-wagner-mercenary-chiefs-plane-brought-down-by-grenade-blast?traffic_source=rss)
 - RSS feed: https://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-10-06T01:04:24+00:00

Russian leader says grenade fragments found in bodies of those killed in crash where Wagner&#039;s Yevgeny Prigozhin died.

