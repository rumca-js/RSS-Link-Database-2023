# Source:Russel Brand, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw, language:en-US

## This Is What They Planned All Along
 - [https://www.youtube.com/watch?v=hEn13LgMnC4](https://www.youtube.com/watch?v=hEn13LgMnC4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-10-06T17:38:29+00:00

Go to http://stickermule.com/russell for FREE STICKERS

George W. Bush Is Building a Memorial to the War on Terror. He Wants Your Feedback. Over 4.5 million people will not be submitting comments because they are dead.

WATCH THE FULL UNCUT VIDEO HERE: https://rumble.com/v3new2p-this-is-what-they-planned-all-along.html

Support Me Directly HERE: https://rb.rumble.com

WATCH me LIVE weekdays on Rumble: https://bit.ly/russellbrand-rumble

## “THEY’LL SHUT YOU DOWN!” - Dr John Campbell On Vaccines, Big Pharma & WHO Treaty - #218 PREVIEW
 - [https://www.youtube.com/watch?v=oLjNhe7kIUg](https://www.youtube.com/watch?v=oLjNhe7kIUg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCswH8ovgUp5Bdg-0_JTYFNw
 - date published: 2023-10-06T12:17:13+00:00

Join us here for a PREVIEW of our daily one-hour RUMBLE show.
To continue watching the show in full, join me exclusively over on RUMBLE:
https://bit.ly/StayFree-218-Dr-Campbell

Grab a limited-edition sticker pack here: https://www.stickermule.com/russell

TODAY - Chrystia Freeland & Hillary Clinton say Ukrainians are dying right now so that NATO can send a message to China. In ‘Here’s The News’, George W. Bush is building a memorial to the War on Terror and he wants your feedback! Over 4.5 million people will not be submitting comments though… because they’re dead. Plus, our guest is Dr John Campbell on the truth behind the WHO’s Pandemic Treaty, will AI be used for control? And concern over elites dominating our food sources.

--------------------------------------------------------------------------------------------------------------------------

FOLLOW and WATCH me LIVE weekdays on Rumble https://rumble.com/russellbrand
5:00PM BST | 12:00 PM EST | 9:00AM PST

Support this channe

