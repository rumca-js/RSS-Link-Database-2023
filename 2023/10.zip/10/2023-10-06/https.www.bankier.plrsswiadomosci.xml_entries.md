# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Odbicie na Wall Street. S&P500 zanotował najlepszy dzień od sierpnia
 - [https://www.bankier.pl/wiadomosc/Odbicie-na-Wall-Street-S-P500-zanotowal-najlepszy-dzien-od-sierpnia-8624829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Odbicie-na-Wall-Street-S-P500-zanotowal-najlepszy-dzien-od-sierpnia-8624829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T20:57:50.606251+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/a/b740b7a30831a5-948-568-0-97-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pomimo początkowych spadków dzień zakończył się po
myśli giełdowych byków, a S&amp;P500 odnotował największy dzienny wzrost od
sierpnia.</p>

## 49 firm z restrykcjami. Poszło o zaopatrywanie Rosji w półprzewodniki
 - [https://www.bankier.pl/wiadomosc/49-firm-z-restrykcjami-Poszlo-o-zaopatrywanie-Rosji-w-polprzewodniki-8624767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/49-firm-z-restrykcjami-Poszlo-o-zaopatrywanie-Rosji-w-polprzewodniki-8624767.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T17:42:41.996993+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/2/4c5649941491ca-948-568-0-0-2001-1200.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Amerykańskie ministerstwo (departament) handlu ogłosił w piątek nałożenie restrykcji handlowych na 49 firm, zaopatrujących Rosję w półprzewodniki i elektronikę pochodzącą z USA. Zdecydowana większość z nich - 42 - to podmioty z Chin.</p>

## Holandia przeznaczy dodatkowe 102 mln euro na pomoc Ukrainie
 - [https://www.bankier.pl/wiadomosc/Holandia-przeznaczy-dodatkowe-102-mln-euro-na-pomoc-Ukrainie-8624784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Holandia-przeznaczy-dodatkowe-102-mln-euro-na-pomoc-Ukrainie-8624784.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T17:42:41.995983+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/c/6b9e46dacabd3f-948-568-0-39-1773-1064.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Holandia przeznaczy 102 mln euro na kolejny, trzeci w tym roku, pakiet pomocowy dla Ukrainy - poinformował w piątek holenderski rząd.</p>

## Amazon wystrzeli na orbitę dwa satelity systemu Kuiper. To konkurencja dla Starlinka
 - [https://www.bankier.pl/wiadomosc/Amazon-wystrzeli-na-orbite-dwa-satelity-systemu-Kuiper-To-konkurencja-dla-Starlinka-8624753.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amazon-wystrzeli-na-orbite-dwa-satelity-systemu-Kuiper-To-konkurencja-dla-Starlinka-8624753.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T17:33:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/d/ca33febce2bda5-948-568-0-60-2977-1786.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Firma Amazona zamierza w piątek wystrzelić na orbitę dwa pierwsze satelity konstelacji Kuiper, która ma docelowo liczyć ponad 3,2 tys. satelitów dostarczających internet. System ten ma być konkurencją dla Starlinka Elona Muska - podaje w piątek amerykański portal Semafor.</p>

## Czy kobiety interesują się polityką? Nastąpiła zmiana
 - [https://www.bankier.pl/wiadomosc/Czy-kobiety-interesuja-sie-polityka-Nastapila-zmiana-8624745.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Czy-kobiety-interesuja-sie-polityka-Nastapila-zmiana-8624745.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T17:18:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/8/652977a33d46db-948-568-172-67-2650-1589.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kobiety rzadziej interesują się polityką, rzadziej deklarują pewność udziału w wyborach i częściej mają niesprecyzowane poglądy polityczne. W ostatnim czasie nastąpił jednak umiarkowany wzrost zainteresowania tą tematyką wśród Polek – wynika z komunikatu z badań CBOS pt. „Kobiety i polityka”.</p>

## Tysiące dzieci bez lekcji w efekcie strajku nauczycieli
 - [https://www.bankier.pl/wiadomosc/Tysiace-dzieci-bez-lekcji-w-efekcie-strajku-nauczycieli-8624715.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tysiace-dzieci-bez-lekcji-w-efekcie-strajku-nauczycieli-8624715.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T16:37:38.346288+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/4/c1128db2fd2416-948-568-0-12-1730-1038.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Władze oświatowe Portugalii odwołały w piątek zajęcia w kilkuset szkołach na terenie całego kraju z powodu rozpoczętego rano strajku nauczycieli. W efekcie protestu tysiące uczniów pozostało w domach.</p>

## Przemysł energochłonny otrzyma miliardy złotych. KE wydała zgodę
 - [https://www.bankier.pl/wiadomosc/Przemysl-energochlonny-otrzyma-miliardy-zlotych-UE-wydala-zgode-8624694.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przemysl-energochlonny-otrzyma-miliardy-zlotych-UE-wydala-zgode-8624694.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T16:19:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/6/87c1bff76025ec-948-568-0-57-1920-1151.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Komisja Europejska zatwierdziła w piątek polski program pomocy państwowej o wartości 1,2 mld euro (5,5 mld złotych), mający na celu wsparcie energochłonnych przedsiębiorstw, borykających się z rosnącymi kosztami energii w kontekście wojny Rosji z Ukrainą.</p>

## Donald Trump ujawnił tajemnice o nuklearnych okrętach podwodnych
 - [https://www.bankier.pl/wiadomosc/Donald-Trump-ujawnil-tajemnice-o-nuklearnych-okretach-podwodnych-8624641.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Donald-Trump-ujawnil-tajemnice-o-nuklearnych-okretach-podwodnych-8624641.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T15:32:43.372689+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/2/5e0635acb2afd4-948-568-0-119-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Były prezydent Donald Trump ujawnił tajemnice nt. nuklearnych okrętów podwodnych australijskiemu miliarderowi Anthony'emu Prattowi, zdradzając mu szczegóły dotyczące zdolności okrętów - podały w czwartek ABC News i "New York Times". Pratt miał później powtórzyć te informacje dziesiątkom osób.</p>

## Premier: Oficjalnie odrzucam cały paragraf konkluzji szczytu RE dotyczący migracji
 - [https://www.bankier.pl/wiadomosc/Premier-Oficjalnie-odrzucam-caly-paragraf-konkluzji-szczytu-RE-dotyczacy-migracji-8624652.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Premier-Oficjalnie-odrzucam-caly-paragraf-konkluzji-szczytu-RE-dotyczacy-migracji-8624652.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T15:32:43.372178+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/1205d525a6cd60-948-568-372-248-968-580.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Odpowiadam za bezpieczeństwo Polski i jej obywateli; dlatego jako odpowiedzialny polityk oficjalnie odrzucam cały paragraf konkluzji szczytu Rady Europejskiej dotyczący migracji - przekazał w piątek premier Mateusz Morawiecki.</p>

## Siła banków i słabość branżowych gigantów na WIG20. GPW zareagowała na amerykańskie zaskoczenie
 - [https://www.bankier.pl/wiadomosc/Sila-bankow-i-slabosc-branzowych-gigantow-na-WIG20-GPW-zareagowala-na-amerykanskie-zaskoczenie-8624664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sila-bankow-i-slabosc-branzowych-gigantow-na-WIG20-GPW-zareagowala-na-amerykanskie-zaskoczenie-8624664.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T15:32:43.363832+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/3/92a0f94f34fb2f-948-568-872-223-3383-2030.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Finał giełdowego tygodnia na GPW skoncentrowany był wokół przeceny Allegro i CD Projektu, kolejnej mocnej sesji sektora bankowego oraz reakcji inwestorów na dane z amerykańskiego rynku pracy. Chociaż reprezentacyjny indeks zdołał w piątek utrzymać się nad kreską, to w skali tygodnia zaliczył największy spadek od początku września.</p>

## Kupowanie letnich paliw przed zimą na zapas nie ma sensu
 - [https://www.bankier.pl/wiadomosc/Kupowanie-letnich-paliw-przed-zima-na-zapas-nie-ma-sensu-8624584.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kupowanie-letnich-paliw-przed-zima-na-zapas-nie-ma-sensu-8624584.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T14:27:53.907386+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/f/899ea628cc042d-945-560-617-0-1534-920.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kupowanie na zapas benzyn i oleju napędowego o parametrach letnich przed zimą nie ma sensu i może przysporzyć problemów kierowcom - ostrzega prezes Instytutu Jagiellońskiego Marcin Roszkowski. Jego zdaniem to nie jest, więc najlepszy moment, żeby wpadać w zakupową panikę.</p>

## Wizz Air stawia na lotnisko w Radomiu. Już niedługo pierwsze loty
 - [https://www.bankier.pl/wiadomosc/Wizz-Air-stawia-na-lotnisko-w-Radomiu-Juz-niedlugo-pierwsze-loty-8624596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wizz-Air-stawia-na-lotnisko-w-Radomiu-Juz-niedlugo-pierwsze-loty-8624596.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T14:27:53.903312+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/4/07cfcb78926209-948-568-0-37-3012-1807.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Serwis Fly4Free.pl bazując na informacjach z Radio dla Ciebie, poinformował, że węgierski przewoźnik zdecydował się na uruchomienie swojej siatki połączeń z Radomia. Niektóre z nich mają mieć premierę już niedługo.</p>

## Samochód elektryczny porwał kierowcę. Musiała interweniować policja
 - [https://www.bankier.pl/wiadomosc/Samochod-elektryczny-porwal-kierowce-Musiala-interweniowac-policja-8624312.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Samochod-elektryczny-porwal-kierowce-Musiala-interweniowac-policja-8624312.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T14:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/f/6494dbac6aedc0-948-568-11-0-1488-893.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Samochody elektryczne jako pierwsze zaczęły bunt 
maszyn? Ten w Wielkiej Brytanii na pewno. Podczas przejażdżki przestał 
reagować na polecenia kierowcy - sam hamował, a następnie przyspieszał 
do prędkości 50 km/h. Nikt nie wiedział, jak go wyłączyć. Nawet wypadek 
go nie zatrzymał.
</p>

## Szalone dane z amerykańskiego rynku pracy
 - [https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-wrzesien-2023-8624526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Amerykanski-rynek-pracy-wrzesien-2023-8624526.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T13:22:34.986100+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/c/3223700a993bd5-948-568-220-160-3780-2267.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />
Tak mocnego wyniku nie spodziewał się chyba nikt. Liczba nowych miejsc pracy w sektorach pozarolniczych okazała się być blisko dwukrotnie wyższa od rynkowego konsensusu. Co więcej, wyraźnie w górę zrewidowano dane za sierpień.

</p>

## NBP „cały czas” kupuje złoto
 - [https://www.bankier.pl/wiadomosc/NBP-kupuje-zloto-wrzesien-2023-8624478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NBP-kupuje-zloto-wrzesien-2023-8624478.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/3/057bcabff7f529-948-568-2-14-954-572.png" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Statystyki za wrzesień niedwuznacznie sugerują, że Narodowy Bank Polski ponownie zwiększył rezerwy złota. Według obliczeń Bankier.pl w skarbcach NBP przybyło ponad 19 ton żółtego metalu.
</p>

## Pekao: Najbliższe miesiące mogą być wyzwaniem
 - [https://www.bankier.pl/wiadomosc/Najblizsze-miesiace-moga-byc-wyzwaniem-ale-w-Pekao-akcja-kredytowa-firm-nie-slabnie-wywiad-8624507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Najblizsze-miesiace-moga-byc-wyzwaniem-ale-w-Pekao-akcja-kredytowa-firm-nie-slabnie-wywiad-8624507.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T12:17:52.743012+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/7/d8799b46b313f9-948-568-0-158-1672-1003.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Najbliższe miesiące w gospodarce mogą być wyzwaniem, gdyż jest sporo sygnałów świadczących o spowolnieniu, zwłaszcza w Europie - ocenia wiceprezes Banku Pekao Jerzy Kwieciński. Jego zdaniem, nie maleje jednak chęć przedsiębiorstw do inwestowania, a w akcji kredytowej dla firm w Pekao jest stabilizacja.</p>

## Tym będą żyły rynki: bankowy piątek, 13-tego
 - [https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-bankowy-piatek-13-tego-8624476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tym-beda-zyly-rynki-bankowy-piatek-13-tego-8624476.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T12:17:52.737939+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/5/a4e4e8f8307545-948-568-11-0-2276-1365.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Na Wall Street najważniejszym dniem tygodnia będzie piątek, 13 października, gdy wyniki
kwartalne pokażą trzy wielkie banki.</p>

## Niektórzy z RPP oceniali we wrześniu, że poziom stóp jest właściwy z możliwością ich cięcia w przyszłości
 - [https://www.bankier.pl/wiadomosc/Niektorzy-z-RPP-oceniali-we-wrzesniu-ze-poziom-stop-jest-wlasciwy-8624515.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Niektorzy-z-RPP-oceniali-we-wrzesniu-ze-poziom-stop-jest-wlasciwy-8624515.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T12:17:52.736389+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/3/1d514eb0348ac0-948-568-0-122-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niektórzy z RPP oceniali we wrześniu, że poziom stóp proc. jest właściwy, z możliwością ich cięcia w przyszłości - podano w opisie dyskusji z posiedzenia RPP w dn. 5-6 września. Większość Rady poparła dostosowanie stóp procentowych o 75 pb. Pojawiła się opinia, że poziom stóp proc. w IX jest zbyt niski.</p>

## Silne spadki giełdowych cen paliw. Po wyborach jednak drożej nie będzie?
 - [https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-pazdziernik-2023-Ile-kosztuje-benzyna-i-olej-napedowy-8624467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ceny-paliw-w-Polsce-pazdziernik-2023-Ile-kosztuje-benzyna-i-olej-napedowy-8624467.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T12:09:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/1/77981639f698f2-948-568-0-150-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Końcówka września przyniosła stabilizację cen paliw w Polsce
na nienaturalnie niskich poziomach. Nie oznacza to jednak, że po wyborach benzyna
i ON skokowo podrożeją.</p>

## Polska powstrzymała wzrost cen prądu lepiej od Niemiec i Francji
 - [https://www.bankier.pl/wiadomosc/Polska-powstrzymala-wzrost-cen-pradu-lepiej-od-Niemiec-i-Francji-8624466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-powstrzymala-wzrost-cen-pradu-lepiej-od-Niemiec-i-Francji-8624466.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T12:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/9/74c620a92020e1-948-567-0-42-980-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny prądu dla gospodarstw domowych w Polsce od września 2021 r. do stycznia br. wzrosły o 12,9 proc., a wydatki na ich ochronę wyniosły ok. 2 proc. PKB - wynika z raportu Agencji Rynku Energii. Zaznaczono, że Polska powstrzymała wzrost cen energii bardziej niż Niemcy i Francja, wydając na ten cel mniej.</p>

## Sąd Najwyższy pyta TSUE o kredyty we frankach. Chodzi o prawo zatrzymania
 - [https://www.bankier.pl/wiadomosc/Sad-Najwyzszy-pyta-TSUE-o-kredyty-we-frankach-Chodzi-o-prawo-zatrzymania-8624444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sad-Najwyzszy-pyta-TSUE-o-kredyty-we-frankach-Chodzi-o-prawo-zatrzymania-8624444.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T11:12:28.111230+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/d/854e83e36b4596-948-568-20-77-979-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />SN doszedł do przekonania, że umowa kredytu jest umową wzajemną, ale otwartą kwestią pozostaje w związku z tym stosowanie tzw. prawa zatrzymania - ocenił szerszy skład Izby Cywilnej SN. W związku z tym zdecydował w piątek o skierowaniu pytania do Trybunału Sprawiedliwości UE.</p>

## "TVP – Bizancjum za publiczne pieniądze". Mocny raport NIK o finansach Telewizji Polskiej
 - [https://www.bankier.pl/wiadomosc/TVP-Bizancjum-za-publiczne-pieniadze-Mocny-raport-NIK-o-finansach-Telewizji-Polskiej-8624424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/TVP-Bizancjum-za-publiczne-pieniadze-Mocny-raport-NIK-o-finansach-Telewizji-Polskiej-8624424.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T11:12:28.108082+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/4/e/da860c6d6f2a17-948-568-0-244-3763-2257.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Telewizja Publiczna w coraz większym stopniu jest finansowana z budżetu państwa. NIK postanowiła zbadać finanse TVP w latach 2021 i 2022. Wyniki kontroli nie są pocieszające.</p>

## Polacy na zakupach obligacji, choć do rekordu daleko. Październikowe papiery dadzą zarobić więcej
 - [https://www.bankier.pl/wiadomosc/Wrzesniowa-sprzedaz-obligacji-byla-nizsza-niz-w-wakacje-8624372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wrzesniowa-sprzedaz-obligacji-byla-nizsza-niz-w-wakacje-8624372.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/d/03866e938cb859-948-568-0-239-3543-2125.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Znamy przybliżone wrześniowe wyniki sprzedaży 
obligacji oszczędnościowych Skarbu Państwa. Łączna kwota zakupów 
sięgnęła 4,7 mld zł. Które papiery cieszyły się największym 
zainteresowaniem Polaków?</p>

## Taylor Swift bije rekordy. Jej trasa koncertowa może przynieść 1,4 mld dol
 - [https://www.bankier.pl/wiadomosc/Taylor-Swift-bije-rekordy-Jej-trasa-koncertowa-moze-przyniesc-1-4-mld-dol-8624276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Taylor-Swift-bije-rekordy-Jej-trasa-koncertowa-moze-przyniesc-1-4-mld-dol-8624276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T11:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/4/55636a3cd5ef3a-948-567-50-45-950-569.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trasa Eras Tour Taylor Swift okazał się ogromnym 
sukcesem. Za tydzień odbędzie się kinowa premiera filmu stanowiącego 
zapis jednego z koncertów. Już teraz globalna sprzedaż biletów 
przekroczyła 100 mln dolarów, co czyni go niekwestionowanym hitem. </p>

## Polregio zawarło porozumienie z pracownikami. Będą podwyżki dla wszystkich
 - [https://www.bankier.pl/wiadomosc/Polregio-zawarlo-porozumienie-z-pracownikami-Beda-podwyzki-dla-wszystkich-8624387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polregio-zawarlo-porozumienie-z-pracownikami-Beda-podwyzki-dla-wszystkich-8624387.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T10:49:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/6/3773fd6eb95b82-945-560-0-37-979-587.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zarząd Polregio podpisał porozumienie z pracownikami dotyczące podwyżki w woj. zachodniopomorskim. Oznacza to, że pracownicy Polregio we wszystkich zakładach przewoźnika od 1 września otrzymają podwyżki wynagrodzenia w wysokości 800 zł - poinformował w piątek kolejowy przewoźnik.</p>

## Tomasz Grodzki wyłudzał pieniądze od pacjentów? Jest wniosek o uchylenie immunitetu marszałkowi senatu
 - [https://www.bankier.pl/wiadomosc/Tomasz-Grodzki-wyludzal-pieniadze-od-pacjentow-Jest-wniosek-o-uchylenie-immunitetu-marszalkowi-senatu-8624383.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tomasz-Grodzki-wyludzal-pieniadze-od-pacjentow-Jest-wniosek-o-uchylenie-immunitetu-marszalkowi-senatu-8624383.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T10:48:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/6/aa3eec9d54463a-948-568-0-4-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prokuratura Regionalna w Szczecinie skierowała do Senatu RP wniosek o wyrażenie zgody na pociągnięcie do odpowiedzialności karnej marszałka senatu Tomasza Grodzkiego - poinformował w piątek rzecznik Prokuratury Krajowej Łukasz Łapczyński.</p>

## Pokojowa Nagroda Nobla trafia do będącej w więzieniu irańskiej obrończyni praw kobiet
 - [https://www.bankier.pl/wiadomosc/Pokojowa-Nagroda-Nobla-dla-Narges-Mohammadi-iranskiej-obronczyni-praw-kobiet-8624356.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pokojowa-Nagroda-Nobla-dla-Narges-Mohammadi-iranskiej-obronczyni-praw-kobiet-8624356.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T10:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/6/a3442445957136-948-568-0-163-1630-977.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przebywająca w więzieniu obrończyni praw kobiet w 
Iranie Narges Mohammadi została laureatką Pokojowej Nagrody Nobla za 
2023 rok - ogłosił w piątek Norweski Komitet Noblowski.</p>

## CD Projekt najniżej od maja. Sprzedaż faktów i nowa cena analityka
 - [https://www.bankier.pl/wiadomosc/CD-Projekt-najnizej-od-maja-Sprzedaz-faktow-i-nowa-cena-analityka-8624335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/CD-Projekt-najnizej-od-maja-Sprzedaz-faktow-i-nowa-cena-analityka-8624335.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T09:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/d41ccc9036a937-948-568-65-160-1935-1160.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Cena akcji CD Projektu w czasie piątkowej sesji na GPW znalazła się najniżej od maja, a obserwowane spadki wśród największych polskich spółek ustępują tylko tym na walorach Allegro. Wzmożona wyprzedaż papierów CD Projektu to kontynuacja przeceny, jaka nastąpiła w dniu inwestora oraz kolejny etap sprzedaży faktów związanej z ostatnią dużą premierą studia. W dodatku jedno z biur obniżyło cenę docelową dla spółki. </p>

## Poczta Polska chce zarobić na nowej obowiązkowej usłudze. "E-maile będą droższe niż papierowy list"
 - [https://www.bankier.pl/wiadomosc/Poczta-Polska-ma-monopol-na-nowa-obowiazkowa-usluge-Operator-sporo-na-niej-zarobi-8624285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Poczta-Polska-ma-monopol-na-nowa-obowiazkowa-usluge-Operator-sporo-na-niej-zarobi-8624285.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T09:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/f06c71e668823b-948-568-0-225-2100-1259.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Poczta Polska podnosi ceny za e-doręczenia. Operator 
narodowy zamierza zarobić na nowej i obowiązkowej od 10 grudnia br. 
korespondencji elektronicznej dla podmiotów sektora publicznego w 
Polsce. </p>

## Kurs euro blisko 4,60 zł. Zdecydują dane z Ameryki
 - [https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-4-60-zl-Zdecyduja-dane-z-Ameryki-8624291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kurs-euro-blisko-4-60-zl-Zdecyduja-dane-z-Ameryki-8624291.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T08:37:33.597418+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/0024dfd64ae747-948-568-0-97-3550-2129.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs euro stabilizuje się w pobliżu 4,60 zł w
oczekiwaniu na popołudniowy raport z amerykańskiego rynku pracy.</p>

## ZUS kontroluje firmy. Chodzi o różnice w deklaracji PIT i do składki zdrowotnej
 - [https://www.bankier.pl/wiadomosc/ZUS-kontroluje-dochody-firm-Interesuja-go-roznice-w-deklaracji-PIT-i-do-skladki-zdrowotnej-8624234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/ZUS-kontroluje-dochody-firm-Interesuja-go-roznice-w-deklaracji-PIT-i-do-skladki-zdrowotnej-8624234.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T08:37:33.593283+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/1/81fe54b30fefbc-948-568-168-0-2529-1517.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zakład Ubezpieczeń Społecznych rozpoczął kontrole 
rocznych rozliczeń składki zdrowotnej przedsiębiorców. Właściciele firm,
 które wykazały inny dochód w deklaracji PIT niż w zeznaniu składanym do
 ZUS-u, muszą wytłumaczyć rozbieżności. Instytucja rozpoczęła wysyłkę 
pism z informacją o wszczęciu postępowania administracyjnego.</p>

## Trwa proces "króla kryptowalut". "Zabrał miliardy dolarów tysiącom ofiar"
 - [https://www.bankier.pl/wiadomosc/Trwa-proces-zalozyciela-gieldy-FTX-8624293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trwa-proces-zalozyciela-gieldy-FTX-8624293.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T08:37:33.592688+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/a/5/88eff738e57164-948-568-0-0-3024-1814.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Upadek giełdy kryptowalut FTX w listopadzie ubiegłego roku wstrząsnął rynkiem. W Nowym Jorku trwa proces Samuela Bankmana-Frieda, a prokuratorzy przyznają, że "wszystko zbudowano na kłamstwach".</p>

## Druga duża transakcja na Allegro w tym roku. Kurs nurkuje
 - [https://www.bankier.pl/wiadomosc/Drugie-ABB-na-Allegro-w-tym-roku-Kurs-nurkuje-8624281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Drugie-ABB-na-Allegro-w-tym-roku-Kurs-nurkuje-8624281.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T08:37:33.590248+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/9/490f5bb7a2ceca-948-568-105-135-1895-1136.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Kurs Allegro szybko dostosował się w piątek do ceny związanej z kolejnym w tym roku procesem budowy przyspieszonej księgi popytu (ABB) i rozpoczął sesję luką spadkową. Handel akcjami giganta e-commerce dołuje indeks WIG20, chociaż na rynkach bazowych obserwowane są wzrosty. Drugim hamulcowym benchmarku jest kurs CD Projektu.</p>

## Borys: Skala spadku inflacji jest duża, a złoty zaczął się umacniać
 - [https://www.bankier.pl/wiadomosc/Borys-Skala-spadku-inflacji-jest-duza-a-zloty-zaczal-sie-umacniac-8624241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-Skala-spadku-inflacji-jest-duza-a-zloty-zaczal-sie-umacniac-8624241.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T07:32:25.363160+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/5/9a0d5ed3b8010e-948-568-0-190-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Decyzja o obcięciu stóp o 75 pkt. bazowych zaskoczyła inwestorów, co zaszkodziło złotemu. Teraz wydaje się, że nie była błędna, skala spadku inflacji jest duża, a złoty ostatnio zaczął się umacniać - powiedział w piątek prezes Polskiego Funduszu Rozwoju Paweł Borys w TVN24.</p>

## Masłowska (RPP): Wydaje się, że trend obniżek stóp będzie utrzymany
 - [https://www.bankier.pl/wiadomosc/Maslowska-RPP-Wydaje-sie-ze-trend-obnizek-stop-bedzie-utrzymany-8624258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Maslowska-RPP-Wydaje-sie-ze-trend-obnizek-stop-bedzie-utrzymany-8624258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T07:32:25.362582+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/8/8cdcdf22f24b3a-948-568-26-131-3473-2084.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wydaje się, że trend obniżania stóp będzie utrzymywany, ale nie można obecnie powiedzieć, czy będzie to po 25 pb., czy więcej - wynika z wypowiedzi członkini RPP Gabrieli Masłowskiej w Radiu Lublin.</p>

## Milionerzy z "Wiadomości". Praca w TVP się opłaca - im szczególnie
 - [https://www.bankier.pl/wiadomosc/Milionerzy-z-Wiadomosci-Ile-zarabia-Holecka-i-Adamczyk-8624240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Milionerzy-z-Wiadomosci-Ile-zarabia-Holecka-i-Adamczyk-8624240.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T07:32:25.360447+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/9/71d6cd2fa282a6-945-560-0-0-1750-1049.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Oglądając programy informacyjne w państwowej 
telewizji, można odnieść wrażenie, że żyje się w innym świecie. Jednak 
prowadzący "Wiadomości" nie moga narzekać, bo program dał im zarobić 
miliony.</p>

## PKO BP i spółka bez bankowości internetowej i mobilnej w weekend
 - [https://www.bankier.pl/wiadomosc/PKO-BP-Alior-Santander-i-Toyota-Banku-z-przerwa-techniczna-8624236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/PKO-BP-Alior-Santander-i-Toyota-Banku-z-przerwa-techniczna-8624236.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T07:32:25.359899+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/7/7a767b96b5a767-948-568-0-133-1980-1188.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zbliżający się wielkimi krokami weekend dla klientów kilku dużych banków będzie stał pod znakiem utrudnień w korzystaniu z usług bankowości internetowej i mobilnej. Jak co tydzień na Bankier.pl publikujemy pełną listą przerw technicznych zaplanowanych przez instytucje na nadchodzący weekend. Sprawdź, czy twój bank planuje ograniczenia w dostępie do podstawowych usług.</p>

## Borys: PFR prefinansował ok. 5 mld zł projektów z KPO
 - [https://www.bankier.pl/wiadomosc/Borys-PFR-prefinansowal-ok-5-mld-zl-projektow-z-KPO-8624221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Borys-PFR-prefinansowal-ok-5-mld-zl-projektow-z-KPO-8624221.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T07:06:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/c/198b7c15b74edc-948-568-0-0-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Do tej pory PFR prefinansował ok. 5 mld zł projektów z KPO - poinformował prezes PFR Paweł Borys. Dodał, że obecnie PFR nie podejmuje działań związanych z emisją obligacji.</p>

## SPAR zniknie z Polski? Spółka wydała nowy komunikat
 - [https://www.bankier.pl/wiadomosc/SPAR-zniknie-z-Polski-Spolka-wydala-nowy-komunikat-8624220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/SPAR-zniknie-z-Polski-Spolka-wydala-nowy-komunikat-8624220.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T06:27:36.119513+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/f/9669c579fb3bed-948-567-0-0-1080-647.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Choć było blisko do pożegnania się z polskim rynkiem, sieć sklepów SPAR jednak na nim pozostanie. Wątpliwości rozwiano w najnowszym komunikacie spółki.</p>

## Kredytobiorcy cieszą się z obniżek stóp proc. Nie odczują ich od razu
 - [https://www.bankier.pl/wiadomosc/Kredytobiorcy-ciesza-sie-z-obnizek-stop-proc-Nie-odczuja-ich-od-razu-8624188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Kredytobiorcy-ciesza-sie-z-obnizek-stop-proc-Nie-odczuja-ich-od-razu-8624188.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T06:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/9/b4c90632ae05e8-948-568-0-230-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przy wysokich stopach procentowych, kredytobiorcy oglądają każdą złotówkę przed zrobieniem przelewu. I niestety wciąż będą musieli to zrobić. O tym, kiedy odczują "ulgę", decydować będzie moment, kiedy banki aktualizują oprocentowanie. - Część klientów obniżkę zobaczy już w listopadzie, ale niektórzy dopiero na początku przyszłego roku – powiedział główny analityk firmy Expander Advisors Jarosław Sadowski.</p>

## Ziobro z odsieczą dla frankowców. Złożył już 56 skarg nadzwyczajnych
 - [https://www.bankier.pl/wiadomosc/Ziobro-z-odsiecza-dla-frankowcow-Zlozyl-juz-56-skarg-nadzwyczajnych-8624186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ziobro-z-odsiecza-dla-frankowcow-Zlozyl-juz-56-skarg-nadzwyczajnych-8624186.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:57:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/96c820112cec41-948-568-0-90-2000-1199.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Dotychczas Prokurator Generalny skierował do Sądu Najwyższego łącznie 56 skarg nadzwyczajnych związanych z kwestiami kredytów frankowych; w ostatnim czasie do SN trafiły trzy takie skargi - poinformowała PAP Prokuratura Krajowa.</p>

## Polskie firmy coraz śmielej podbijają globalne rynki
 - [https://www.bankier.pl/wiadomosc/Polskie-firmy-coraz-smielej-podbijaja-globalne-rynki-8624182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polskie-firmy-coraz-smielej-podbijaja-globalne-rynki-8624182.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:50:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/5/4b51450bb6a466-948-568-0-30-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Większość polskich inwestycji jest zlokalizowana w Europie, ale coraz popularniejszym kierunkiem są również Stany Zjednoczone, Indie czy Bliski Wschód. Według danych NBP na koniec 2022 roku wartość polskich...</p>

## WARS planuje rozwój gastronomii kolejowej i stacjonarnego cateringu
 - [https://www.bankier.pl/wiadomosc/WARS-planuje-rozwoj-gastronomii-kolejowej-i-stacjonarnego-cateringu-8624171.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/WARS-planuje-rozwoj-gastronomii-kolejowej-i-stacjonarnego-cateringu-8624171.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:22:21.355225+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/5/7509bc5d68d480-945-560-0-90-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Głównym celem spółki WARS jest rozwój gastronomii kolejowej w pociągach oraz stacjonarnych usług cateringowych - przekazał PAP Grzegorz Bębenek, główny specjalista ds. Marketingu w spółce.</p>

## Polacy mniej chętni, by pomagać Ukrainie
 - [https://www.bankier.pl/wiadomosc/Polacy-mniej-chetni-by-pomagac-Ukrainie-8624178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-mniej-chetni-by-pomagac-Ukrainie-8624178.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:22:21.353641+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/4/0294ae55d2b1c1-948-568-0-110-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polacy są mniej chętni, by pomagać Ukrainie; przeciwni przedłużaniu pomocy dla uchodźców z Ukrainy są w większości wyborcy partii opozycyjnych, a nie PiS - informuje w piątek "Rzeczpospolita", powołując się na sondaż IBRiS przeprowadzony dla tej gazety i radia RMF FM.</p>

## Burmistrz Nowego Jorku stara się zniechęcić migrantów: nie mamy już miejsca
 - [https://www.bankier.pl/wiadomosc/Burmistrz-Nowego-Jorku-stara-sie-zniechecic-migrantow-nie-mamy-juz-miejsca-8624168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Burmistrz-Nowego-Jorku-stara-sie-zniechecic-migrantow-nie-mamy-juz-miejsca-8624168.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:16:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/8/2ef224fe4bcbf8-948-568-52-131-1447-868.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Burmistrz Nowego Jorku podczas wizyty w meksykańskim stanie Puebla podkreślał przyjazne relacje, ale jednocześnie w obliczu narastającego kryzysu migracyjnego starał się zniechęcić kolejne osoby do przyjazdu. „Mój dom jest twoim domem", ale „nie ma już miejsca” – mówił Eric Adams .</p>

## Pieniądze to nie wszystko. "Branża IT wymaga dbałości o dobrostan psychiczny pracowników"
 - [https://www.bankier.pl/wiadomosc/Pieniadze-to-nie-wszystko-Branza-IT-wymaga-dbalosci-o-dobrostan-psychiczny-pracownikow-8624165.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pieniadze-to-nie-wszystko-Branza-IT-wymaga-dbalosci-o-dobrostan-psychiczny-pracownikow-8624165.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T05:08:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/a69f6b23d717a6-948-568-0-60-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Konkurencyjność na rynku pracy to nie tylko atrakcyjne wynagrodzenie, to także dbałość o dobrostan psychiczny pracowników, w tym dostęp do opieki psychologicznej - przekonują eksperci Organizacji Pracodawców Usług IT SoDA.</p>

## "Dom za opiekę nad rodzicami". Czy bank przyzna "Bezpieczny kredyt" w przypadku dożywotniej renty?
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-a-renta-dozywotnia-Co-z-dofinansowaniem-8623486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-a-renta-dozywotnia-Co-z-dofinansowaniem-8623486.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:17:23.892853+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/d/e21a1b57593fbf-948-568-0-240-4000-2399.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spływają do nas kolejne pytania
dotyczące „Bezpiecznego kredytu 2 proc.”. Pani Sylwia pyta, czy będzie mogła
skorzystać z dofinansowania, jeśli rodzice planują zapisać jej dom w ramach tzw. renty
dożywotniej. Za opiekę nad nimi miałaby w przyszłości otrzymać dom rodzinny.
Ekspert wyjaśnia jej wątpliwości.</p>

## Tak sprawdzisz, czy jesteś na liście wyborców i gdzie możesz głosować
 - [https://www.bankier.pl/wiadomosc/Tak-sprawdzisz-czy-jestes-na-liscie-wyborcow-i-gdzie-mozesz-glosowac-8623603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tak-sprawdzisz-czy-jestes-na-liscie-wyborcow-i-gdzie-mozesz-glosowac-8623603.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:17:23.892323+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/5/92579748a61d38-948-567-10-7-990-593.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wybory do Sejmu i Senatu Rzeczypospolitej Polskiej odbędą się 15 października. Aby uniknąć niemiłej niespodzianki, warto przed głosowaniem upewnić się, czy znajdujemy się na liście wyborców w miejscu, gdzie planujemy oddać głos.</p>

## Coraz trudniej o darmowe przelewy i konto za 0 zł dla firm
 - [https://www.bankier.pl/wiadomosc/Ranking-kont-firmowych-pazdziernik-2023-r-8623622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kont-firmowych-pazdziernik-2023-r-8623622.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:17:23.891243+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/24bf93c6a4a054-948-568-1207-0-2310-1386.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Nielimitowane bezpłatne przelewy i konto firmowe za 0 zł przestają być standardem w bankach. Z analizy Bankier.pl wynika, że jeszcze trzy miesiące temu taką ofertę dla przedsiębiorców miało w swoim portfolio sześć instytucji. W październiku ich liczba stopniała do trzech na rynku. Sprawdź najnowszy ranking kont firmowych.</p>

## Przemeblowanie w hipotekach – dominują podwyżki. Ale obniżki stóp odwracają uwagę klientów
 - [https://www.bankier.pl/wiadomosc/Promocje-kredytow-hipotecznych-pazdziernik-2023-8623597.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Promocje-kredytow-hipotecznych-pazdziernik-2023-8623597.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:17:23.890633+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/d7d196c5574c55-845-506-155-55-845-506.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />U progu jesieni wiele banków zaktualizowało warunki proponowane kredytobiorcom hipotecznym. W promocyjnych cennikach zaszło sporo zmian, w większości zbieżnych z ogólnym trendem na rynku – dominują podwyżki. Okoliczności są sprzyjające dla kredytodawców – spadek stóp odwraca uwagę klientów.</p>

## Palikot tłumaczy się wierzycielom. Zastawił dom, w którym mieszka
 - [https://www.bankier.pl/wiadomosc/Palikot-odpowiada-na-pytania-wierzycieli-Zastawil-dom-8623752.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Palikot-odpowiada-na-pytania-wierzycieli-Zastawil-dom-8623752.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:17:23.890066+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/0/58c4dcbf6de769-948-568-7-207-3179-1907.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W Polmosie się udało i tu też może się udać - zapewnia Janusz Palikot w nowym nagraniu skierowanym do wierzycieli Manufaktury Piwa Wódki i Wina. Jak twierdzi, spółka może rozwinąć się i przynosić 200 mln zł rocznego przychodu. Jest jednak kilka "ale" oraz "jeśli".</p>

## Mur między USA a Meksykiem przedłużony. Biden: Zostałem do tego zmuszony
 - [https://www.bankier.pl/wiadomosc/Mur-miedzy-USA-a-Meksykiem-przedluzony-Biden-Zostalem-do-tego-zmuszony-8624154.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Mur-miedzy-USA-a-Meksykiem-przedluzony-Biden-Zostalem-do-tego-zmuszony-8624154.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T04:07:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/6/4fd9ad2c6fd8bc-945-560-0-58-3370-2021.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Biały Dom zrzuca winę za budowę kolejnego odcinka muru na granicy z Meksykiem, twierdząc że do wydania pieniędzy na ten cel został zmuszony przez Kongres jeszcze w 2019 r. Jak sam Biden przyznaje, zapora nie jest skuteczna. </p>

## Media: Korea Północna zaczęła wysyłać artylerię do Rosji po spotkaniu Kima z Putinem
 - [https://www.bankier.pl/wiadomosc/Media-Korea-Polnocna-zaczela-wysylac-artylerie-do-Rosji-po-spotkaniu-Kima-z-Putinem-8624152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Media-Korea-Polnocna-zaczela-wysylac-artylerie-do-Rosji-po-spotkaniu-Kima-z-Putinem-8624152.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-10-06T03:17:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/b/21b2436b61ee17-948-568-0-9-3822-2293.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Korea Północna zaczęła wysyłać artylerię do atakującej Ukrainę Rosji – podała w czwartek CBS News, powołując się na anonimowe źródło rządowe w USA. Amerykańska stacja wiąże to z niedawnym spotkaniem Kim Dzong Una i Władimira Putina.</p>

