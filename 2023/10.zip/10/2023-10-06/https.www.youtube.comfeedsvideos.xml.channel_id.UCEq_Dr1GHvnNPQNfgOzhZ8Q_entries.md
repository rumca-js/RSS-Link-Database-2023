# Source:Solid jj, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q, language:en-US

## Doctor Doom Takes Charge
 - [https://www.youtube.com/watch?v=nQlaLoGU3pY](https://www.youtube.com/watch?v=nQlaLoGU3pY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCEq_Dr1GHvnNPQNfgOzhZ8Q
 - date published: 2023-10-06T19:11:18+00:00

Spider-Man faces off against Doctor Doom as he claims the entire world for himself. Of course these videos would start getting political… boo!

10% Gamer Supps (Code: SOLID) ▼
https://gamersupps.gg/SOLID

Second channel: @Solidusjj   
Patreon: https://patreon.com/solidjj
BadTakeDelete Discord: https://discord.gg/X5ttfJR6es

