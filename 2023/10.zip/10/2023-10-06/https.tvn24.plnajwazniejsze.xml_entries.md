# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## "Czas Decyzji. Wybory Kobiet". Program specjalny z udziałem dziennikarek "Faktów" TVN i TVN24
 - [https://tvn24.pl/wybory-parlamentarne-2023/czas-decyzji-wybory-kobiet-program-specjalny-z-udzialem-dziennikarek-faktow-tvn-i-tvn24-7378542?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/czas-decyzji-wybory-kobiet-program-specjalny-z-udzialem-dziennikarek-faktow-tvn-i-tvn24-7378542?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T20:03:20+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qnj4br-on-czas-decyji-wybory-kobiet-0810_h-7379043/alternates/LANDSCAPE_1280" />
    W najbliższą niedzielę na antenie TVN24.

## Gauff bez tajemnic przed Świątek. "Wykorzystam te informacje"
 - [https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-przed-meczem-z-coco-gauff-w-1-2-finalu-turnieju-wta-china-open-w-pekinie_sto9826151/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-przed-meczem-z-coco-gauff-w-1-2-finalu-turnieju-wta-china-open-w-pekinie_sto9826151/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T20:00:01+00:00

<img alt="Gauff bez tajemnic przed Świątek. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9pbj0k-iga-swiatek-i-coco-gauff-7379272/alternates/LANDSCAPE_1280" />
    Półfinał w sobotę.

## Kumulacja w Eurojackpot rośnie
 - [https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-z-dnia-061023-liczby-z-ostatniego-losowania-7379195?source=rss](https://tvn24.pl/biznes/pieniadze/eurojackpot-wyniki-z-dnia-061023-liczby-z-ostatniego-losowania-7379195?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T19:51:44+00:00

<img alt="Kumulacja w Eurojackpot rośnie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-u5ba2s-eurojackpot-4729989/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Alert RCB dla dwóch regionów. "Zabezpiecz rzeczy, które może porwać wiatr"
 - [https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-w-piatek-i-sobote-6710-silny-wiatr-7379248?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alert-rcb-w-piatek-i-sobote-6710-silny-wiatr-7379248?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T19:36:40+00:00

<img alt="Alert RCB dla dwóch regionów. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-fbgooy-alert-rcb-7379262/alternates/LANDSCAPE_1280" />
    Ostrzeżenie dotyczy silnego wiatru.

## "Pan się tak nie poci", czyli co dziennikarz może usłyszeć od polityka
 - [https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-137,S00E137,1178670?source=rss](https://tvn24.pl/go/programy,7/sejm-wita-odcinki,404598/odcinek-137,S00E137,1178670?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T19:03:44+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8tiuee-sejm-wita-7379218/alternates/LANDSCAPE_1280" />
    Wrześniowe wakacje, czekające ustawy, wspólne zdjęcie i wycieczka.

## Tysiące ludzi biorą zaświadczenia. Padnie rekord frekwencji w wyborach?
 - [https://fakty.tvn24.pl/zobacz-fakty/polacy-szturmuja-urzedy-dopisuja-sie-do-spisu-pobieraja-zaswiadczenia-o-prawie-do-glosowania-7379025?source=rss](https://fakty.tvn24.pl/zobacz-fakty/polacy-szturmuja-urzedy-dopisuja-sie-do-spisu-pobieraja-zaswiadczenia-o-prawie-do-glosowania-7379025?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T18:55:49+00:00

<img alt="Tysiące ludzi biorą zaświadczenia. Padnie rekord frekwencji w wyborach?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wpmtyc-komisja-wyborcza-wybory-7333465/alternates/LANDSCAPE_1280" />
    Wszystko wskazuje na to, że idziemy na rekord. Urzędy wydają rekordowe liczby zaświadczeń o prawie do głosowania.

## Polska Akcja Humanitarna: w ataku zginęła nasza pracownica
 - [https://tvn24.pl/swiat/polska-akcja-humanitarna-w-ataku-na-ukrainska-wioske-zginela-nasza-pracownica-7379182?source=rss](https://tvn24.pl/swiat/polska-akcja-humanitarna-w-ataku-na-ukrainska-wioske-zginela-nasza-pracownica-7379182?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T18:42:02+00:00

<img alt="Polska Akcja Humanitarna: w ataku zginęła nasza pracownica" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8bbzg7-akcja-ratunkowo-poszukiwawcza-we-wsi-hroza-w-obwodzie-charkowskim-7377567/alternates/LANDSCAPE_1280" />
    "Uczestniczyła w uroczystości rodzinnej".

## Jest śledztwo w sprawie afery z udziałem legionistów
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/afera-w-alkmaar.-uefa-wszczela-sledztwo_sto9826310/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/afera-w-alkmaar.-uefa-wszczela-sledztwo_sto9826310/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T18:23:48+00:00

<img alt="Jest śledztwo w sprawie afery z udziałem legionistów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ws5huj-legia-warszawa-7379185/alternates/LANDSCAPE_1280" />
    Poinformowała UEFA.

## Tomczyk: jestem przekonany, że kandydat PiS-u będzie znał pytania
 - [https://tvn24.pl/wybory-parlamentarne-2023/debata-w-telewizji-rzadowej-donald-tusk-zapowiada-udzial-jaroslaw-kaczynski-ma-byc-nieobecny-cezary-tomczyk-i-paulina-hennig-kloska-komentuja-7379134?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/debata-w-telewizji-rzadowej-donald-tusk-zapowiada-udzial-jaroslaw-kaczynski-ma-byc-nieobecny-cezary-tomczyk-i-paulina-hennig-kloska-komentuja-7379134?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T18:23:41+00:00

<img alt="Tomczyk: jestem przekonany, że kandydat PiS-u będzie znał pytania" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ssud2-fakty-po-faktach-7379130/alternates/LANDSCAPE_1280" />
    Dyskusja w "Faktach po Faktach" o przedwyborczej debacie.

## Członek RPP przeprasza za Glapińskiego. "Brak szacunku"
 - [https://tvn24.pl/biznes/z-kraju/czlonek-rpp-ludwik-kotecki-przeprasza-za-slowa-adama-glapinskiego-7379038?source=rss](https://tvn24.pl/biznes/z-kraju/czlonek-rpp-ludwik-kotecki-przeprasza-za-slowa-adama-glapinskiego-7379038?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T18:16:23+00:00

<img alt="Członek RPP przeprasza za Glapińskiego. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-y1092c-adam-glapinski-7377063/alternates/LANDSCAPE_1280" />
    Echa konferencji szefa NBP.

## Czarzasty o Kaczyńskim: wie, że nie da rady
 - [https://tvn24.pl/wybory-parlamentarne-2023/czarzasty-w-radomiu-zeby-trafic-na-debate-trzeba-nie-bac-sie-ludzi-7378942?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/czarzasty-w-radomiu-zeby-trafic-na-debate-trzeba-nie-bac-sie-ludzi-7378942?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T17:34:26+00:00

<img alt="Czarzasty o Kaczyńskim: wie, że nie da rady" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fa2gje-forum-0811463434-1-7378973/alternates/LANDSCAPE_1280" />
    Lider Lewicy komentuje decyzję Jarosława Kaczyńskiego.

## Nocą porywy wiatru mogą sięgać 100 kilometrów na godzinę
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-0710noca-porywy-wiatru-moga-siegac-100-kilometrow-na-godzine-7379087?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-sobota-0710noca-porywy-wiatru-moga-siegac-100-kilometrow-na-godzine-7379087?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T17:28:13+00:00

<img alt="Nocą porywy wiatru mogą sięgać 100 kilometrów na godzinę" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-kfi39r-silny-wiatr-noc-6686902/alternates/LANDSCAPE_1280" />
    Sprawdź prognozę pogody na noc i na jutro.

## Joel Embiid wybrał reprezentację, z którą powalczy o medal igrzysk
 - [https://eurosport.tvn24.pl/koszykowka/media-joel-embiid-podjal-decyzje-w-sprawie-wyboru-reprezentacji-narodowej_sto9825228/story.shtml?source=rss](https://eurosport.tvn24.pl/koszykowka/media-joel-embiid-podjal-decyzje-w-sprawie-wyboru-reprezentacji-narodowej_sto9825228/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T17:04:41+00:00

<img alt="Joel Embiid wybrał reprezentację, z którą powalczy o medal igrzysk" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xelwd6-joel-embiid-7379084/alternates/LANDSCAPE_1280" />
    Gospodarze najważniejszej imprezy czterolecia nie będą zachwyceni.

## Muszą opuścić Łotwę. Rosjanie otrzymują wilcze bilety
 - [https://tvn24.pl/swiat/lotwa-ponad-trzy-tysiace-rosjan-musi-opuscic-kraj-7379004?source=rss](https://tvn24.pl/swiat/lotwa-ponad-trzy-tysiace-rosjan-musi-opuscic-kraj-7379004?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T16:42:50+00:00

<img alt="Muszą opuścić Łotwę. Rosjanie otrzymują wilcze bilety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ozs4db-ryga-litwa-shutterstock_2215937405-7379000/alternates/LANDSCAPE_1280" />
    Powodem są zmiany w prawie imigracyjnym.

## Media: piłkarz Legii opuścił areszt, drugi złożył wyjaśnienia
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/media-josue-opuscil-areszt-radovan-pankov-zlozyl-wyjasnienia-po-meczu-az-alkmaar-legia-warszawa-w-li_sto9826176/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/media-josue-opuscil-areszt-radovan-pankov-zlozyl-wyjasnienia-po-meczu-az-alkmaar-legia-warszawa-w-li_sto9826176/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T16:15:40+00:00

<img alt="Media: piłkarz Legii opuścił areszt, drugi złożył wyjaśnienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ymlgu7-radovan-pankov-z-lewej-i-josue-7379054/alternates/LANDSCAPE_1280" />
    Josue i Radovan Pankov zostali zatrzymani przez holenderską policję po meczu Ligi Konferencji z AZ Alkmaar.

## "Jarek, gdzie jesteś, gdzie się chowasz?" Tusk o "abdykacji" Kaczyńskiego
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-donald-tusk-w-przemyslu-prezes-pis-jaroslaw-kaczynski-chowa-sie-abdykowal-7378900?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-donald-tusk-w-przemyslu-prezes-pis-jaroslaw-kaczynski-chowa-sie-abdykowal-7378900?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T16:11:02+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5p22s8-donald-tusk-7378951/alternates/LANDSCAPE_1280" />
    Spotkanie lidera PO w Przemyślu.

## Ostrzeżenie przed produktem. Spożycie może wywołać reakcję alergiczną
 - [https://tvn24.pl/biznes/z-kraju/wycofanie-produktu-maka-z-ziarna-ciecierzycy-1-kg-o-numerze-partiidacie-trwalosci-25022024-ostrzezenie-gis-7378740?source=rss](https://tvn24.pl/biznes/z-kraju/wycofanie-produktu-maka-z-ziarna-ciecierzycy-1-kg-o-numerze-partiidacie-trwalosci-25022024-ostrzezenie-gis-7378740?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T16:07:37+00:00

<img alt="Ostrzeżenie przed produktem. Spożycie może wywołać reakcję alergiczną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rz67f8-sklep-zakupy-shutterstock_2142130445-7308428/alternates/LANDSCAPE_1280" />
    Komunikat GIS.

## Reportaże "Czarno na białym" na antenie TVN7
 - [https://tvn24.pl/polska/reportaze-czarno-na-bialym-na-antenie-tvn7-7378827?source=rss](https://tvn24.pl/polska/reportaze-czarno-na-bialym-na-antenie-tvn7-7378827?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T15:43:09+00:00

<img alt="Reportaże " src="https://tvn24.pl/najnowsze/cdn-zdjecie-xaiu2y-czarno-na-bialym-7307533/alternates/LANDSCAPE_1280" />
    Emisje do 13 października, w dni robocze o 17:55, w sobotę 14:25, w niedzielę 13:05.

## Ambasador Królestwa Niderlandów wezwana do polskiego MSZ
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/msz-reaguje-po-skandalu-w-holandii.-wezwa-ambasador_sto9826118/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/msz-reaguje-po-skandalu-w-holandii.-wezwa-ambasador_sto9826118/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T15:39:00+00:00

<img alt="Ambasador Królestwa Niderlandów wezwana do polskiego MSZ" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x05dk9-dariusz-mioduski-7378980/alternates/LANDSCAPE_1280" />
    Jest reakcja na wydarzenia w Alkmaar.

## "Okaże się nagle, że cała ta propaganda, która była nam serwowana, nie ma pokrycia w rzeczywistości"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debata-wyborcza-w-tvp-trzaskowski-widzowie-zobacza-ze-donald-tusk-umie-mowic-po-polsku-7378871?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debata-wyborcza-w-tvp-trzaskowski-widzowie-zobacza-ze-donald-tusk-umie-mowic-po-polsku-7378871?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T15:22:10+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nmxrvy-rafal-trzaskowski-w-bytomiu-7378901/alternates/LANDSCAPE_1280" />
    Rafał Trzaskowski na spotkaniu w Bytomiu.

## Nowe światło na wydarzenia w Alkmaar. Holendrzy przedstawiają swoją wersję
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/oswiadczenie-holenderskiej-policji-prokuratury-wladz-alkmaar-i-klubu-po-meczu-az-alkmaar-legia-warsz_sto9826107/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/oswiadczenie-holenderskiej-policji-prokuratury-wladz-alkmaar-i-klubu-po-meczu-az-alkmaar-legia-warsz_sto9826107/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T15:17:05+00:00

<img alt="Nowe światło na wydarzenia w Alkmaar. Holendrzy przedstawiają swoją wersję" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y2ai1s-mecz-az-alkmaar-legia-warszawa-zakonczyl-sie-skandalem-7378944/alternates/LANDSCAPE_1280" />
    "Legia nierzetelnym partnerem".

## Hołownia: jesteśmy atakowani przez PiS "wyssanymi z palca odgrzewanymi kotletami"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-szymon-holownia-trzecia-droga-jest-atakowana-przez-pis-odgrzewanymi-kotletami-7378666?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-szymon-holownia-trzecia-droga-jest-atakowana-przez-pis-odgrzewanymi-kotletami-7378666?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T14:38:53+00:00

<img alt="Hołownia: jesteśmy atakowani przez PiS " src="https://tvn24.pl/najnowsze/cdn-zdjecie-f83ssm-szymon-holownia-7378807/alternates/LANDSCAPE_1280" />
    "Długopis. 15 października to będzie nasze berło i narzędzie sprawowania w Polsce władzy."

## Polonia w USA zmobilizowana, listy pękają w szwach. Konsulat ostrzega przed kolejkami
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-glosowanie-polonii-w-usa-konsulat-ostrzega-przed-mozliwymi-kolejkami-w-komisjach-wyborczych-7378825?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-glosowanie-polonii-w-usa-konsulat-ostrzega-przed-mozliwymi-kolejkami-w-komisjach-wyborczych-7378825?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T14:35:38+00:00

<img alt="Polonia w USA zmobilizowana, listy pękają w szwach. Konsulat ostrzega przed kolejkami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ocrq0f-nowy-jork-usa-13102019-polacy-glosuja-w-konsulacie-rp-w-nowym-jorku-7378799/alternates/LANDSCAPE_1280" />
    W całych Stanach Zjednoczonych utworzono 5 okręgów wyborczych i 52 komisje.

## Świątek poznała ostatnie rywalki w WTA Finals
 - [https://eurosport.tvn24.pl/tenis/marketa-vondrousova-ons-jabeur-i-karolina-muchova-zagraja-w-wta-finals-w-cancun_sto9826036/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/marketa-vondrousova-ons-jabeur-i-karolina-muchova-zagraja-w-wta-finals-w-cancun_sto9826036/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T14:17:33+00:00

<img alt="Świątek poznała ostatnie rywalki w WTA Finals" src="https://tvn24.pl/najnowsze/cdn-zdjecie-42j8z2-ons-jabeur-san-diego-open-7378847/alternates/LANDSCAPE_1280" />
    Marketa Vondrousova, Ons Jabeur i Karolina Muchova uzupełniły stawkę kończącego sezon turnieju WTA Finals w Cancun. Wcześniej udział w meksykańskiej imprezie zapewniła sobie między innymi Iga Świątek.

## Prawybory w liceum. Wygrała opozycja, a PiS na 5. miejscu. Zareagowało kuratorium
 - [https://tvn24.pl/lubuskie/gorzow-wielkopolski-prawybory-w-liceum-wygrala-opozycja-pis-dopiero-na-piatym-miejscu-kuratorium-reaguje-7378795?source=rss](https://tvn24.pl/lubuskie/gorzow-wielkopolski-prawybory-w-liceum-wygrala-opozycja-pis-dopiero-na-piatym-miejscu-kuratorium-reaguje-7378795?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T14:15:22+00:00

<img alt="Prawybory w liceum. Wygrała opozycja, a PiS na 5. miejscu. Zareagowało kuratorium" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j9lg2j-prawybory-w-liceum-w-gorzowie-wielkopolskim-wygrala-opozycja-7378775/alternates/LANDSCAPE_1280" />
    Szkoła organizuje tego typu akcje od ponad 20 lat.

## Co z cenami paliw? "Mamy pierwsze podwyżki"
 - [https://tvn24.pl/biznes/moto/ceny-paliw-pb95-i-diesla-pazdziernik-2023-analiza-reflex-i-e-petrol-7378667?source=rss](https://tvn24.pl/biznes/moto/ceny-paliw-pb95-i-diesla-pazdziernik-2023-analiza-reflex-i-e-petrol-7378667?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T13:55:12+00:00

<img alt="Co z cenami paliw? " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m5e0rt-stacja-benzynowa-tankowanie-benzyna-shutterstock1704390262jpg/alternates/LANDSCAPE_1280" />
    Analizy i prognozy.

## Rakiety uderzyły w Charków. Spod gruzów wydobyto ciało 10-letniego chłopca, zginęła też jego babcia
 - [https://tvn24.pl/swiat/charkow-rosyjski-atak-spod-gruzow-wydobyto-cialo-10-letniego-chlopca-zginela-takze-jego-babcie-7378603?source=rss](https://tvn24.pl/swiat/charkow-rosyjski-atak-spod-gruzow-wydobyto-cialo-10-letniego-chlopca-zginela-takze-jego-babcie-7378603?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T13:00:09+00:00

<img alt="Rakiety uderzyły w Charków. Spod gruzów wydobyto ciało 10-letniego chłopca, zginęła też jego babcia " src="https://tvn24.pl/najnowsze/cdn-zdjecie-s9dy80-charkow-7378655/alternates/LANDSCAPE_1280" />
    Liczba osób rannych w wyniku ataku wzrosła do 30.

## Awaryjne lądowanie bez wysuniętego podwozia
 - [https://tvn24.pl/swiat/usa-samolot-firmy-fedex-ladowal-bez-wysunietego-podwozia-w-miescie-chattanooga-nagranie-7378578?source=rss](https://tvn24.pl/swiat/usa-samolot-firmy-fedex-ladowal-bez-wysunietego-podwozia-w-miescie-chattanooga-nagranie-7378578?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T12:58:19+00:00

<img alt="Awaryjne lądowanie bez wysuniętego podwozia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vxji74-samolot-twitter-7378647/alternates/LANDSCAPE_1280" />
    Media publikują nagranie.

## Uczelnia gościła polityków w swojej auli, teraz jej rektor startuje w wyborach
 - [https://tvn24.pl/premium/uczelnia-goscila-politykow-w-swojej-auli-teraz-jej-rektor-startuje-w-wyborach-7373007?source=rss](https://tvn24.pl/premium/uczelnia-goscila-politykow-w-swojej-auli-teraz-jej-rektor-startuje-w-wyborach-7373007?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T12:34:32+00:00

<img alt="Uczelnia gościła polityków w swojej auli, teraz jej rektor startuje w wyborach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-k44skb-prezes-pis-podczas-wystapienia-w-auli-politechniki-opolskiej-7373595/alternates/LANDSCAPE_1280" />
    Senat Politechniki Opolskiej zakazał udostępniania sali na wydarzenia polityczne, ale zdaniem rektora tej uczelni wspomniana uchwała go nie obowiązuje. We wrześniu ubiegłego roku salę wynajęło Prawo i Sprawiedliwość, a w grudniu konferencję naukową zorganizowali tam parlamentarzyści Suwerennej Polski. Rok po wiecu prezesa PiS rektor Politechniki Opolskiej został kandydatem tej partii w wyborach do Senatu RP.

## W mieszkaniu znaleziono ciała mężczyzny i kobiety
 - [https://tvn24.pl/katowice/radlin-zwloki-dwoch-osob-w-mieszkaniu-przy-ulicy-mariackiej-7378175?source=rss](https://tvn24.pl/katowice/radlin-zwloki-dwoch-osob-w-mieszkaniu-przy-ulicy-mariackiej-7378175?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T12:32:36+00:00

<img alt="W mieszkaniu znaleziono ciała mężczyzny i kobiety" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fwlvdn-okolicznosci-tragedii-bada-policja-zdjecie-ilustracyjne-7378167/alternates/LANDSCAPE_1280" />
    Prokuratura bada okoliczności.

## Konferencja Legii po wydarzeniach w Holandii. "To nie był incydent"
 - [https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/dariusz-mioduski-na-konferencji-w-warszawie-dzien-po-meczu-az-alkmaar-legia-w-lidze-konferencji-i-sk_sto9825744/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/liga-konferencji/2023-2024/dariusz-mioduski-na-konferencji-w-warszawie-dzien-po-meczu-az-alkmaar-legia-w-lidze-konferencji-i-sk_sto9825744/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T12:26:00+00:00

<img alt="Konferencja Legii po wydarzeniach w Holandii. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jf91x3-konferencja-prezesa-legii-po-przyjezdzie-z-holandii-7378650/alternates/LANDSCAPE_1280" />
    Prezes Legii Warszawa na spotkaniu z dziennikarzami.

## Nowe informacje o stanie zdrowia Sophii Loren
 - [https://tvn24.pl/kultura-i-styl/sophia-loren-nowe-informacje-o-stanie-zdrowia-po-wypadku-7378409?source=rss](https://tvn24.pl/kultura-i-styl/sophia-loren-nowe-informacje-o-stanie-zdrowia-po-wypadku-7378409?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T12:01:41+00:00

<img alt="Nowe informacje o stanie zdrowia Sophii Loren" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gilhh4-sophia-loren-7359673/alternates/LANDSCAPE_1280" />
    Aktorka przewróciła się w swoim domu.

## "Wyzywał od zdrajców Polski, potem wyciągnął scyzoryk". Atak na biuro senatora
 - [https://tvn24.pl/lodz/lodz-atak-na-biuro-senatorskie-krzysztofa-kwiatkowskiego-7378537?source=rss](https://tvn24.pl/lodz/lodz-atak-na-biuro-senatorskie-krzysztofa-kwiatkowskiego-7378537?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T11:59:54+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-83103k-do-zdarzenia-doszlo-w-piatek-7378545/alternates/LANDSCAPE_1280" />
    O zdarzeniu została poinformowana policja.

## Kajdanki na rękach piłkarzy. "W Europie jeszcze chyba nie było takiej sytuacji"
 - [https://eurosport.tvn24.pl/pilka-nozna/zatrzymanie-pilkarzy-legii.-w-europie-jeszcze-chyba-nie-bylo-takiej-sytuacji_sto9825843/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/zatrzymanie-pilkarzy-legii.-w-europie-jeszcze-chyba-nie-bylo-takiej-sytuacji_sto9825843/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T11:46:03+00:00

<img alt="Kajdanki na rękach piłkarzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-u8nabs-legia-wrocila-do-kraju-bez-dwoch-pilkarzy-7378549/alternates/LANDSCAPE_1280" />
    Wydarzenia, do jakich doszło w Holandii przy okazji spotkania Legii, to sytuacja bez precedensu.

## "Policja groziła, że autokar zostanie wzięty szturmem"
 - [https://eurosport.tvn24.pl/pilka-nozna/awantura-w-alkmaar.-zatrzymani-pilkarze-legii-popychany-prezes.-krzyczelismy-ze-to-wlasciciel-klubu_sto9825811/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/awantura-w-alkmaar.-zatrzymani-pilkarze-legii-popychany-prezes.-krzyczelismy-ze-to-wlasciciel-klubu_sto9825811/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T11:17:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q1aknb-josue-i-pankov-opuscili-autokar-i-zostali-w-holandii-7378493/alternates/LANDSCAPE_1280" />
    - Ciągle jestem w szoku, nikt nie wie, z czego to, ta cała agresja, wyniknęło – wspomina nocne zajścia w Alkmaar Marcin Szymczyk. Był jednym z dziennikarzy, który z bliska obserwował przepychanki.

## Nie zjawią się na debacie, są gotowi jechać do Przysuchy. "By Jarosław Kaczyński czuł nasz oddech na plecach"
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-debata-w-telewizji-rzadowej-politycy-opozycji-sugeruja-wyjazd-za-jaroslawem-kaczynskim-do-przysuchy-7378245?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-debata-w-telewizji-rzadowej-politycy-opozycji-sugeruja-wyjazd-za-jaroslawem-kaczynskim-do-przysuchy-7378245?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:59:32+00:00

<img alt="Nie zjawią się na debacie, są gotowi jechać do Przysuchy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-m66d88-jaroslaw-kaczynski-7378376/alternates/LANDSCAPE_1280" />
    Prezes PiS odmówił udziału w debacie telewizji rządowej.

## Raport NIK po kontroli w telewizji rządowej. "Wyniki są zatrważające"
 - [https://tvn24.pl/polska/raport-nik-po-kontroli-w-tvp-marian-banas-wyniki-sa-zatrwazajace-niewiele-wspolnego-z-realizacja-misji-publicznej-7378267?source=rss](https://tvn24.pl/polska/raport-nik-po-kontroli-w-tvp-marian-banas-wyniki-sa-zatrwazajace-niewiele-wspolnego-z-realizacja-misji-publicznej-7378267?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:53:06+00:00

<img alt="Raport NIK po kontroli w telewizji rządowej. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ds8h8x-06-1115-nik-0004-7378232/alternates/LANDSCAPE_1280" />
    Marian Banaś na konferencji prasowej.

## Zakaz chodzenia po schodach ruchomych wszedł w życie
 - [https://tvn24.pl/swiat/japonia-zakaz-chodzenia-po-schodach-ruchomych-w-miescie-nagoja-ma-zapobiegac-wypadkom-7378214?source=rss](https://tvn24.pl/swiat/japonia-zakaz-chodzenia-po-schodach-ruchomych-w-miescie-nagoja-ma-zapobiegac-wypadkom-7378214?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:52:43+00:00

<img alt="Zakaz chodzenia po schodach ruchomych wszedł w życie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z6zj1k-tokio-japonia-schody-ruchome-streetvj-shutterstock_1100620739-7378347/alternates/LANDSCAPE_1280" />
    Ma zapobiegać wypadkom.

## Zbłąkana kula trafiła ciężarną w autobusie. Jej dziecko nie przeżyło
 - [https://tvn24.pl/swiat/usa-zblakana-kula-trafila-ciezarna-w-autobusie-jej-dziecko-nie-przezylo-dwoch-mezczyzn-z-zarzutami-7377980?source=rss](https://tvn24.pl/swiat/usa-zblakana-kula-trafila-ciezarna-w-autobusie-jej-dziecko-nie-przezylo-dwoch-mezczyzn-z-zarzutami-7377980?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:39:34+00:00

<img alt="Zbłąkana kula trafiła ciężarną w autobusie. Jej dziecko nie przeżyło" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cz5u1z-policja-usa-6743069/alternates/LANDSCAPE_1280" />
    Dwóch mężczyzn z zarzutami.

## Szantaż Brukseli, linia hańby Tuska, przymusowa relokacja. Fałsz w wyborczych przekazach PiS
 - [https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-szantaz-brukseli-linia-hanby-tuska-przymusowa-relokacja-falsz-w-wyborczych-przekazach-pis-st7377647?source=rss](https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-szantaz-brukseli-linia-hanby-tuska-przymusowa-relokacja-falsz-w-wyborczych-przekazach-pis-st7377647?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:07:16+00:00

<img alt="Szantaż Brukseli, linia hańby Tuska, przymusowa relokacja. Fałsz w wyborczych przekazach PiS" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tcqhy7-glowne-tezy-wyborcze-pis-na-czym-polega-manipulacja-7376829/alternates/LANDSCAPE_1280" />
    Przedstawiamy istotne narracje w kampanii Prawa i Sprawiedliwości, które wprowadzają w błąd.

## Debata w telewizji rządowej. Kto zmierzy się z Donaldem Tuskiem?
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debata-tvp-kto-wystapi-lista-uczestnikow-7377717?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debata-tvp-kto-wystapi-lista-uczestnikow-7377717?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T10:03:09+00:00

<img alt="Debata w telewizji rządowej. Kto zmierzy się z Donaldem Tuskiem?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fipmfw-donald-tusk-7375144/alternates/LANDSCAPE_1280" />
    Dojdzie do niej w poniedziałek.

## Szokujące zimno, ale i letnie gorąco
 - [https://tvn24.pl/tvnmeteo/prognoza/jet-stream-zmrozi-polske-pogoda-na-pazdziernik-2023-wroci-duze-cieplo-i-pojawi-sie-mroz-dlugoterminowa-prognoza-7377955?source=rss](https://tvn24.pl/tvnmeteo/prognoza/jet-stream-zmrozi-polske-pogoda-na-pazdziernik-2023-wroci-duze-cieplo-i-pojawi-sie-mroz-dlugoterminowa-prognoza-7377955?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:58:30+00:00

<img alt="Szokujące zimno, ale i letnie gorąco" src="https://tvn24.pl/najnowsze/cdn-zdjecie-itgdof-jesien-drv-7378054/alternates/LANDSCAPE_1280" />
    Nasza synoptyk przygotowała prognozę na październik.

## Apel Tuska do wyborców Trzeciej Drogi i Lewicy
 - [https://tvn24.pl/polska/wybory-2023-apel-donalda-tuska-do-wyborcow-trzeciej-drogi-i-lewicy-glosujcie-na-swoich-7378173?source=rss](https://tvn24.pl/polska/wybory-2023-apel-donalda-tuska-do-wyborcow-trzeciej-drogi-i-lewicy-glosujcie-na-swoich-7378173?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:52:46+00:00

<img alt="Apel Tuska do wyborców Trzeciej Drogi i Lewicy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ec2uy-donald-tusk-w-rzeszowie-7378174/alternates/LANDSCAPE_1280" />
    W czasie spotkania z mieszkańcami Rzeszowa.

## Nie żyje Keith Jefferson
 - [https://tvn24.pl/kultura-i-styl/keith-jefferson-nie-zyje-aktor-gral-w-filmach-quentina-tarantino-7378144?source=rss](https://tvn24.pl/kultura-i-styl/keith-jefferson-nie-zyje-aktor-gral-w-filmach-quentina-tarantino-7378144?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:52:19+00:00

<img alt="Nie żyje Keith Jefferson" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2ugrl4-keith-jefferson-7378140/alternates/LANDSCAPE_1280" />
    Grał w filmach Quentina Tarantino.

## Piłkarze Legii "zatrzymani za napaść". Holendrzy piszą o poszkodowanym ochroniarzu
 - [https://eurosport.tvn24.pl/pilka-nozna/skandal-po-meczu-legii-w-holandii.-policja-podala-za-co-zostali-zatrzymani-pilkarze_sto9825741/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/skandal-po-meczu-legii-w-holandii.-policja-podala-za-co-zostali-zatrzymani-pilkarze_sto9825741/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:52:09+00:00

<img alt="Piłkarze Legii " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aako8-po-meczu-legii-bylo-niespokojnie-7378224/alternates/LANDSCAPE_1280" />
    Holenderska policja przekazała pierwsze informacje dotyczące zawodników Legii i wydarzeń po jej czwartkowym meczu z AZ Alkmaar.

## Przyznano Pokojową Nagrodę Nobla
 - [https://tvn24.pl/swiat/przyznano-pokojowa-nagrode-nobla-narges-mohammadi-laureatka-7378130?source=rss](https://tvn24.pl/swiat/przyznano-pokojowa-nagrode-nobla-narges-mohammadi-laureatka-7378130?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:06:49+00:00

<img alt="Przyznano Pokojową Nagrodę Nobla" src="https://tvn24.pl/najnowsze/cdn-zdjecie-iiuvgd-narges-mohammadi-7378157/alternates/LANDSCAPE_1280" />
    Uhonorowana irańska działaczka na rzecz praw człowieka.

## Mistrzyni US Open czeka na Świątek
 - [https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-poznala-rywalke-w-polfinale-turnieju-wta-1000-w-pekinie.-z-kim-zagra-w-1-2-finalu_sto9825694/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-poznala-rywalke-w-polfinale-turnieju-wta-1000-w-pekinie.-z-kim-zagra-w-1-2-finalu_sto9825694/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T09:05:00+00:00

<img alt="Mistrzyni US Open czeka na Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ilxew-coco-gauff-podczas-china-open-7378126/alternates/LANDSCAPE_1280" />
    Polka już wie, z kim zagra w półfinale turnieju WTA 1000 w Pekinie.

## Aplauz na korcie po słowach Świątek
 - [https://eurosport.tvn24.pl/tenis/wta-pekin/2023/wypowiedz-igi-swiatek-po-meczu-z-caroline-garcia-wta-1000-pekin_sto9825655/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-pekin/2023/wypowiedz-igi-swiatek-po-meczu-z-caroline-garcia-wta-1000-pekin_sto9825655/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T08:32:41+00:00

<img alt="Aplauz na korcie po słowach Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y66kcv-iga-swiatek-zagra-o-final-w-pekinie-7378059/alternates/LANDSCAPE_1280" />
    Jest już w półfinale turnieju WTA 1000 w Pekinie.

## Morawiecki: zawetowałem zapis dotyczący migracji. Macron: to nie zablokuje porozumienia
 - [https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-wecie-komentarze-europejskich-liderow-7377903?source=rss](https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-wecie-komentarze-europejskich-liderow-7377903?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T08:15:29+00:00

<img alt="Morawiecki: zawetowałem zapis dotyczący migracji. Macron: to nie zablokuje porozumienia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5mdbw4-premier-mateusz-morawiecki-po-szczycie-ue-w-grenadzie-7378975/alternates/LANDSCAPE_1280" />
    Nieformalny szczyt Unii Europejskiej w Hiszpanii.

## Trudny początek Polaków. Rywale odjeżdżają
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-siatkarzy/2023/polska-argentyna-wynik-meczu-na-zywo-i-relacja-live-kwalifikacje-do-igrzysk-olimpijskich-siatkarzy_sto9825627/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-siatkarzy/2023/polska-argentyna-wynik-meczu-na-zywo-i-relacja-live-kwalifikacje-do-igrzysk-olimpijskich-siatkarzy_sto9825627/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T08:13:00+00:00

<img alt="Trudny początek Polaków. Rywale odjeżdżają" src="https://tvn24.pl/najnowsze/cdn-zdjecie-7rl9ww-siatkarze-reprezentacji-polski-sliwka-kaczmarek-i-kochanowski-7377956/alternates/LANDSCAPE_1280" />
    Polska - Argentyna, kolejny mecz naszych zawodników w kwalifikacjach do igrzysk olimpijskich. Relacja z meczu w eurosport.pl.

## 3,5 miliona za nadzorowanie "Wiadomości" TVP. "Były moim oczkiem w głowie". Ujawniamy raport NIK
 - [https://tvn24.pl/premium/35-miliona-za-nadzorowanie-wiadomosci-tvp-byly-moim-oczkiem-w-glowie-ujawniamy-raport-nik-7377798?source=rss](https://tvn24.pl/premium/35-miliona-za-nadzorowanie-wiadomosci-tvp-byly-moim-oczkiem-w-glowie-ujawniamy-raport-nik-7377798?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T07:57:20+00:00

<img alt="3,5 miliona za nadzorowanie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-nnlxmb-pap_20210914_2s4-7377941/alternates/LANDSCAPE_1280" />
    10 najlepiej zarabiających pracowników TVP tylko w 2022 roku zarobiło łącznie 9 mln zł, a odpowiadający za "Wiadomości" Jarosław Olechowski przez trzy lata zarobił ponad 3,5 mln złotych - wynika z raportu pokontrolnego Najwyższej Izby Kontroli w TVP, do którego dotarł portal tvn24.pl. Były prezes TVP Jacek Kurski zeznał w NIK, że godził się na takie stawki, bo "za pośrednictwem 'Wiadomości'" on sam był "oceniany przez czynniki polityczne".

## Kosmiczny mecz Świątek. Była w opałach, jest w półfinale
 - [https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-caroline-garcia-wynik-i-relacja-z-cwiercfinalu-wta-1000-w-pekinie-2023_sto9825538/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-pekin/2023/iga-swiatek-caroline-garcia-wynik-i-relacja-z-cwiercfinalu-wta-1000-w-pekinie-2023_sto9825538/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T07:16:22+00:00

<img alt="Kosmiczny mecz Świątek. Była w opałach, jest w półfinale" src="https://tvn24.pl/najnowsze/cdn-zdjecie-hhyrm9-iga-swiatek-podczas-china-open-7377882/alternates/LANDSCAPE_1280" />
    Po emocjonującym meczu pokonała Caroline Garcię w ćwierćfinale turnieju w Pekinie 6:7(8), 7:6(5), 6:1.

## Jak zmienił się poziom bezpieczeństwa kobiet podczas porodów za rządów PiS?
 - [https://tvn24.pl/polska/bezpieczenstwo-kobiet-podczas-porodow-wczasie-rzadow-pis-sondaz-dla-faktow-tvn-itvn24-7377767?source=rss](https://tvn24.pl/polska/bezpieczenstwo-kobiet-podczas-porodow-wczasie-rzadow-pis-sondaz-dla-faktow-tvn-itvn24-7377767?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T07:11:49+00:00

<img alt="Jak zmienił się poziom bezpieczeństwa kobiet podczas porodów za rządów PiS?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ggqdhm-szpital-porod-ciaza-shutterstock_1181843014-7350377/alternates/LANDSCAPE_1280" />
    Sondaż dla "Faktów" TVN i TVN24

## Przepychanki i zatrzymania legionistów. PZPN reaguje
 - [https://eurosport.tvn24.pl/pilka-nozna/pzpn-reaguje-po-zatrzymaniach-pilkarzy-legii-w-holandii_sto9825559/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pzpn-reaguje-po-zatrzymaniach-pilkarzy-legii-w-holandii_sto9825559/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T06:47:47+00:00

<img alt="Przepychanki i zatrzymania legionistów. PZPN reaguje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cx26me-policja-prowadzi-josue-7377827/alternates/LANDSCAPE_1280" />
    Po awanturze w Holandii.

## Skąd się biorą "awarie" na stacjach Orlenu? Szef PFR odpowiada
 - [https://tvn24.pl/polska/awarie-na-stacjach-orlenu-skad-sie-biora-szef-pfr-pawel-borys-odpowiada-7377784?source=rss](https://tvn24.pl/polska/awarie-na-stacjach-orlenu-skad-sie-biora-szef-pfr-pawel-borys-odpowiada-7377784?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T06:39:56+00:00

<img alt="Skąd się biorą " src="https://tvn24.pl/najnowsze/cdn-zdjecie-jxgr57-zdjecia-ze-stacji-orlenu-przy-ulicy-powsinskiej-w-warszawie-29-wrzesnia-2023-7367630/alternates/LANDSCAPE_1280" />
    Prezes Polskiego Funduszu Rozwoju (PFR) Paweł Borys w "Jeden na jeden" w TVN24.

## Potężne pieniądze dla Polski w zawieszeniu. "Dyskutujemy z ministerstwem jak zarządzać płynnością"
 - [https://tvn24.pl/biznes/z-kraju/kpo-pawel-borys-jezeli-srodki-naplyna-do-to-nie-ma-problemu-7377747?source=rss](https://tvn24.pl/biznes/z-kraju/kpo-pawel-borys-jezeli-srodki-naplyna-do-to-nie-ma-problemu-7377747?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T06:36:14+00:00

<img alt="Potężne pieniądze dla Polski w zawieszeniu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-k3ftdu-06-0730-jnj-cl-0004-7377756/alternates/LANDSCAPE_1280" />
    Szef PFR Paweł Borys "Jeden na Jeden".

## "Znaleziono fragmenty granatów ręcznych". Putin o katastrofie, w której zginął Prigożyn
 - [https://tvn24.pl/swiat/rosja-wladimir-putin-o-mozliwej-przyczynie-katastrofy-samolotu-jewgienija-prigozyna-7377707?source=rss](https://tvn24.pl/swiat/rosja-wladimir-putin-o-mozliwej-przyczynie-katastrofy-samolotu-jewgienija-prigozyna-7377707?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T06:18:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-nhh6kf-wladimir-putin-7377704/alternates/LANDSCAPE_1280" />
    Zapewnia, że nie doszło do ataku rakietowego.

## Byłe pierwsze damy zachęcają do udziału w wyborach
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-byle-pierwsze-damy-zachecaja-do-udzialu-w-wyborach-7377686?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-byle-pierwsze-damy-zachecaja-do-udzialu-w-wyborach-7377686?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T05:31:41+00:00

<img alt="Byłe pierwsze damy zachęcają do udziału w wyborach" src="https://tvn24.pl/najnowsze/cdn-zdjecie-65agkn-byle-pierwsze-damy-2251494/alternates/LANDSCAPE_1280" />
    Odpowiedź obecnej pierwszej damy wymagała komentarza.

## Partia popularnego produktu wycofana ze sklepów. Ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/parowki-z-szynki-stowki-firmy-sokolow-jedna-z-partii-wycofana-ze-sklepow-ostrzezenie-gis-7377581?source=rss](https://tvn24.pl/biznes/z-kraju/parowki-z-szynki-stowki-firmy-sokolow-jedna-z-partii-wycofana-ze-sklepow-ostrzezenie-gis-7377581?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T05:12:27+00:00

<img alt="Partia popularnego produktu wycofana ze sklepów. Ostrzeżenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-unrtv6-koszyk-sklep-supermarketshutterstock_1933509284-1-5670658/alternates/LANDSCAPE_1280" />
    Komunikat GIS.

## 50 milionów czulszy od oka. Powstaje najpotężniejszy teleskop w historii
 - [https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-95,S00E95,1177839?source=rss](https://tvn24.pl/go/programy,7/kijek-w-kosmosie-odcinki,607116/odcinek-95,S00E95,1177839?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T05:00:00+00:00

<img alt="50 milionów czulszy od oka. Powstaje najpotężniejszy teleskop w historii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-snee4h-gigantyczny-teleskop-magellana-budowa-7377666/alternates/LANDSCAPE_1280" />
    Teleskop ma być cztery razy potężniejszym od kosmicznego obserwatorium Jamesa Webba.

## Kiedy Lewandowski wróci do gry?
 - [https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-jest-kontuzjowany.-czy-napastnik-barcelony-zdazy-na-el-clasico-z-realem-madryt-ki_sto9825076/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/primera-division/2023-2024/robert-lewandowski-jest-kontuzjowany.-czy-napastnik-barcelony-zdazy-na-el-clasico-z-realem-madryt-ki_sto9825076/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:58:08+00:00

<img alt="Kiedy Lewandowski wróci do gry?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3qcslf-robert-lewandowski-doznal-kontuzji-po-tym-ataku-carmo-7376168/alternates/LANDSCAPE_1280" />
    W Barcelonie obawiają się najgorszego.

## Uwaga, nadciąga wichura! IMGW ogłosił pomarańczowe alerty
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-w-piatek-i-sobote-nadciaga-wichura-porywy-beda-przekraczac-100-kmh-7377720?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-silny-wiatr-w-piatek-i-sobote-nadciaga-wichura-porywy-beda-przekraczac-100-kmh-7377720?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:36:59+00:00

<img alt="Uwaga, nadciąga wichura! IMGW ogłosił pomarańczowe alerty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tbmfbe-uwaga-na-silny-wiatr-5601408/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie będzie niebezpiecznie.

## Uwaga, nadciąga wichura! IMGW ogłosił pomarańczowe alerty
 - [https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-silny-wiatr-w-piatek-i-sobote-nadciaga-wichura-porywy-beda-przekraczac-100-kmh-7377720?source=rss](https://tvn24.pl/tvnmeteo/prognoza/alerty-imgw-silny-wiatr-w-piatek-i-sobote-nadciaga-wichura-porywy-beda-przekraczac-100-kmh-7377720?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:36:59+00:00

<img alt="Uwaga, nadciąga wichura! IMGW ogłosił pomarańczowe alerty" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tbmfbe-uwaga-na-silny-wiatr-5601408/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie będzie niebezpiecznie.

## Świątek walczy o półfinał w Pekinie
 - [https://eurosport.tvn24.pl/tenis/wta-pekin/2023/live-caroline-garcia-iga-swiatek_mtc1475460/live-commentary.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-pekin/2023/live-caroline-garcia-iga-swiatek_mtc1475460/live-commentary.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:35:51+00:00

<img alt="Świątek walczy o półfinał w Pekinie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ivssw-iga-swiatek-gra-w-pekinie-7377723/alternates/LANDSCAPE_1280" />
    Rywalką Caroline Garcia. Relacja w eurosport.pl.

## Kumulacja w Lotto rośnie
 - [https://tvn24.pl/biznes/z-kraju/wyniki-lotto-i-lotto-plus-z-dnia-051023-liczby-z-ostatniego-losowania-7377721?source=rss](https://tvn24.pl/biznes/z-kraju/wyniki-lotto-i-lotto-plus-z-dnia-051023-liczby-z-ostatniego-losowania-7377721?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:34:20+00:00

<img alt="Kumulacja w Lotto rośnie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lojhor-lotto-s-shutterstock_275295956-5128640/alternates/LANDSCAPE_1280" />
    Wyniki losowania.

## Piłkarze Legii zatrzymani przez policję. Skandal po meczu w Holandii
 - [https://eurosport.tvn24.pl/pilka-nozna/josue-i-radovan-pankov-z-legii-zatrzymani-przez-policje-po-meczu-z-az-alkmaar_sto9825533/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/josue-i-radovan-pankov-z-legii-zatrzymani-przez-policje-po-meczu-z-az-alkmaar_sto9825533/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:13:52+00:00

<img alt="Piłkarze Legii zatrzymani przez policję. Skandal po meczu w Holandii" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5rsx7-do-przepychanek-doszlo-po-meczu-7377718/alternates/LANDSCAPE_1280" />
    Josue i Radovan Pankov zakuci w kajdanki, właściciel Legii Dariusz Mioduski poturbowany.

## Polityk PiS pochwalił się budową drogi. Inwestycja nie miała wsparcia budżetu państwa
 - [https://tvn24.pl/polska/polityk-pis-pochwalil-sie-budowa-drogi-inwestycja-nie-miala-wsparcia-budzetu-panstwa-7377646?source=rss](https://tvn24.pl/polska/polityk-pis-pochwalil-sie-budowa-drogi-inwestycja-nie-miala-wsparcia-budzetu-panstwa-7377646?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:10:41+00:00

<img alt="Polityk PiS pochwalił się budową drogi. Inwestycja nie miała wsparcia budżetu państwa" src="https://tvn24.pl/najnowsze/cdn-zdjecie-exe55i-0510n360xr-pis-dnz-wieczorek-7377606/alternates/LANDSCAPE_1280" />
    Samorząd szybko skomentował wideo.

## "Boimy się, że nagle się okaże, że coś zostanie wykryte"
 - [https://tvn24.pl/polska/mammografia-badanie-ktore-moze-uratowac-zycie-7377648?source=rss](https://tvn24.pl/polska/mammografia-badanie-ktore-moze-uratowac-zycie-7377648?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:07:38+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bpzwsf-mammografia-6164678/alternates/LANDSCAPE_1280" />
    Z roku na rok coraz mniej kobiet w Polsce robi mammografię.

## Gajewska: Mam tego już cholernie dosyć. Ja nie przyszłam do Sejmu po to, żeby się komuś podobać
 - [https://tvn24.pl/go/programy,7/wybory-kobiet-odcinki,1172124/odcinek-2,S00E02,1177825?source=rss](https://tvn24.pl/go/programy,7/wybory-kobiet-odcinki,1172124/odcinek-2,S00E02,1177825?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T04:00:00+00:00

<img alt="Gajewska: Mam tego już cholernie dosyć. Ja nie przyszłam do Sejmu po to, żeby się komuś podobać " src="https://tvn24.pl/najnowsze/cdn-zdjecie-6wn84u-wybory-kobiet-aleksandra-gajewskaok-7377660/alternates/LANDSCAPE_1280" />
    Posłanka KO była gościnią podcastu "Wybory Kobiet".

## Topnieje różnica między PiS i KO. Opozycja z sejmową większością
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-sondaz-topnieje-roznica-miedzy-pis-i-ko-opozycja-przejmuje-wladze-7377709?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-sondaz-topnieje-roznica-miedzy-pis-i-ko-opozycja-przejmuje-wladze-7377709?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:55:12+00:00

<img alt="Topnieje różnica między PiS i KO. Opozycja z sejmową większością" src="https://tvn24.pl/najnowsze/cdn-zdjecie-jq2ws4-donald-tusk-7377708/alternates/LANDSCAPE_1280" />
    Najnowszy sondaż IBRiS dla Onetu.

## Tusk pójdzie do TVP, Trump myśli o urzędzie spikera, tragiczny wypadek z udziałem miliardera i aktorki
 - [https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-6-pazdziernika-2023-roku-7377712?source=rss](https://tvn24.pl/swiat/piec-rzeczy-ktore-warto-wiedziec-6-pazdziernika-2023-roku-7377712?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:32:03+00:00

<img alt="Tusk pójdzie do TVP, Trump myśli o urzędzie spikera, tragiczny wypadek z udziałem miliardera i aktorki" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e08a4c-donald-trump-7377710/alternates/LANDSCAPE_1280" />
    Podsumowujemy.

## Gutek: zmagałem się z życiem i odpowiedzi szukałem w kinie
 - [https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-50,S00E50,1177849?source=rss](https://tvn24.pl/go/programy,7/monika-olejnik-otwarcie-odcinki,511079/odcinek-50,S00E50,1177849?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:30:00+00:00

<img alt="Gutek: zmagałem się z życiem i odpowiedzi szukałem w kinie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5b53j2-roman-gutek-i-monika-olejnik-7377618/alternates/LANDSCAPE_1280" />
    Twórca Warszawskiego Festiwalu Filmowego i współzałożyciel firmy Gutek Film w rozmowie z Moniką Olejnik.

## Prezydent ostrzega przed "scenariuszem zastosowanym przez Rosję na Krymie"
 - [https://tvn24.pl/swiat/kosowo-prezydent-serbia-planuje-anektowanie-polnocy-kraju-korzystajac-ze-scenariusza-zastosowanego-na-krymie-7377702?source=rss](https://tvn24.pl/swiat/kosowo-prezydent-serbia-planuje-anektowanie-polnocy-kraju-korzystajac-ze-scenariusza-zastosowanego-na-krymie-7377702?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:28:40+00:00

<img alt="Prezydent ostrzega przed " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4hrmmp-funkcjonariusz-kosowskiej-policji-przy-klasztorze-we-wsi-banjska-7366115/alternates/LANDSCAPE_1280" />
    Prezydent Kosowa w rozmowie z niemieckim dziennikiem "Welt".

## Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-7377713?source=rss](https://tvn24.pl/swiat/ukraina-walczy-najwazniejsze-wydarzenia-ostatnich-godzin-7377713?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:09:48+00:00

<img alt="Ukraina walczy. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tfegkj-uczestnik-akcji-ratunkowo-poszukiwawczej-we-wsi-hroza-w-obwodzie-charkowskim-7377564/alternates/LANDSCAPE_1280" />
    Rosyjska pełnoskalowa inwazja na Ukrainę trwa od 590 dni.

## Media: Korea Północna zaczęła wysyłać artylerię do Rosji
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-w-piatek-6-pazdziernika-2023-7377714?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-relacja-w-piatek-6-pazdziernika-2023-7377714?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-10-06T03:05:07+00:00

<img alt="Media: Korea Północna zaczęła wysyłać artylerię do Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpkx9y-rosyjska-artyleria-5757946/alternates/LANDSCAPE_1280" />
    W tvn24.pl relacjonujemy najważniejsze wydarzenia z i wokół Ukrainy.

