# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Nation Of Language - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=gTla9xP9atk](https://www.youtube.com/watch?v=gTla9xP9atk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T15:00:26+00:00

http://KEXP.ORG presents Nation Of Language performing live in the KEXP gathering space. Recorded August 15, 2023

Songs:
Weak In Your Light
On Division Street
Stumbling Still
Friend Machine
Too Much, Enough

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

## Nation Of Language - Weak In Your Light (Live on KEXP)
 - [https://www.youtube.com/watch?v=iKka6wQZSZg](https://www.youtube.com/watch?v=iKka6wQZSZg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T11:00:41+00:00

http://KEXP.ORG presents Nation Of Language performing "Weak In Your Light" live in the KEXP gathering space. Recorded August 15, 2023

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

## Nation Of Language - Friend Machine (Live on KEXP)
 - [https://www.youtube.com/watch?v=cIBMb-WeQw8](https://www.youtube.com/watch?v=cIBMb-WeQw8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T11:00:36+00:00

http://KEXP.ORG presents Nation Of Language performing "Friend Machine" live in the KEXP gathering space. Recorded August 15, 2023

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

## Nation Of Language - Too Much, Enough (Live on KEXP)
 - [https://www.youtube.com/watch?v=cuE9TuSXFGQ](https://www.youtube.com/watch?v=cuE9TuSXFGQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T11:00:35+00:00

http://KEXP.ORG presents Nation Of Language performing "Too Much, Enough" live in the KEXP gathering space. Recorded August 15, 2023

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

## Nation Of Language -  (Live on KEXP)
 - [https://www.youtube.com/watch?v=5gfR6Yg3COE](https://www.youtube.com/watch?v=5gfR6Yg3COE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T11:00:07+00:00

http://KEXP.ORG presents Nation Of Language performing "On Division Street" live in the KEXP gathering space. Recorded August 15, 2023

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

## Nation Of Language - Stumbling Still (Live on KEXP)
 - [https://www.youtube.com/watch?v=3xdSAk-LiFs](https://www.youtube.com/watch?v=3xdSAk-LiFs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-10-06T11:00:04+00:00

http://KEXP.ORG presents Nation Of Language performing "Stumbling Still" live in the KEXP gathering space. Recorded August 15, 2023

Ian Devaney - Vocals, Guitar
Aidan Noel - Synth, Vocals
Alex MacKay - Bass, Vocals

Host: Cheryl Waters
Audio Engineers: Kevin Suggs, Julian Martlew
Guest Audio Engineer: Ian "Skinny" Salazar
Audio Mixer: Kevin Suggs
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen, Luke Knecht, Kendall Rock
Editor: Scott Holpainen

https://www.nationoflanguage.com
http://kexp.org

