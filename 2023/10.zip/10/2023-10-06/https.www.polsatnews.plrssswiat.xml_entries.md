# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Białoruś rusza z propagandową audycją o Polsce. Wabi antysystemowców
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/bialorus-rusza-z-propagandowa-audycja-o-polsce-wabi-antysystemowcow/](https://www.polsatnews.pl/wiadomosc/2023-10-06/bialorus-rusza-z-propagandowa-audycja-o-polsce-wabi-antysystemowcow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T20:01:00+00:00

Myśli o Polsce: refleksje, dyskusje, komentarze - pod taką nazwą Międzynarodowe Radio Białoruś należące do państwowego koncernu stworzyło projekt społeczno-polityczny, który ma poruszać tematy związane z Polską. Według niezależnej od Mińska telewizji Biełsat ruch białoruskiego reżimu nie jest przypadkowy.

## Nowość dla wegan z drukarki 3D. Danie "bardzo ładnie się łuszczy"
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/nowosc-dla-wegan-z-drukarki-3d-danie-bardzo-ladnie-sie-luszczy/](https://www.polsatnews.pl/wiadomosc/2023-10-06/nowosc-dla-wegan-z-drukarki-3d-danie-bardzo-ladnie-sie-luszczy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T19:59:00+00:00

Wegańskiego łososia produkowanego w drukarce 3D wprowadziła do oferty firma spożywcza zajmująca się nowoczesną technologią spożywczą. Pierwsza partia filetów powstałych w tak nietypowy sposób wyprzedała się w sklepach w Wiedniu. Zdaniem szefa firmy wydrukowany łosoś bardzo ładnie się łuszczy i ma smak podobny do prawdziwej ryby.

## Łotwa deportuje ponad trzy tysiące Rosjan. Nie zdali testu
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/lotwa-deportuje-ponad-trzy-tysiace-rosjan-nie-zdali-testu/](https://www.polsatnews.pl/wiadomosc/2023-10-06/lotwa-deportuje-ponad-trzy-tysiace-rosjan-nie-zdali-testu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T19:41:00+00:00

Wystarczyło zdać egzamin na podstawową znajomość języka łotewskiego. Nie wszyscy Rosjanie dopełnili jednak tej prostej formalności, więc rząd w Rydze nakazał wyjechać osobom, które nie przystąpiły do testu. Władza rozesłała listy nakazujące opuścić kraj. Termin minął wraz z końcem września.

## Historyczne odkrycie w USA. Ludzie zasiedlili Amerykę prędzej niż uważano
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/historyczne-odkrycie-w-usa-ludzie-zasiedlili-ameryke-predzej-niz-uwazano/](https://www.polsatnews.pl/wiadomosc/2023-10-06/historyczne-odkrycie-w-usa-ludzie-zasiedlili-ameryke-predzej-niz-uwazano/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T17:48:00+00:00

Naukowcy znaleźli kolejne potwierdzenie na to, że ludzie przybyli do obydwu Ameryk ponad 20 tysięcy lat temu. Chodzi o odciski stóp na skraju pradawnego jeziora. Dotychczas dominująca teoria wskazywała, że człowiek pojawił się za Atlantykiem znacznie później. Jeden z uczonych zajmujących się odkryciem stwierdził, że teraz lepiej rozumiemy, jak wyglądał ostatni rozdział zaludniania świata.

## Holandia. Władze Alkmaar: Potępiamy zachowanie Legii Warszawa
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/holandia-wladze-alkmaar-potepiamy-zachowanie-legii-warszawa/](https://www.polsatnews.pl/wiadomosc/2023-10-06/holandia-wladze-alkmaar-potepiamy-zachowanie-legii-warszawa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T17:09:00+00:00

Piłkarze Legii Warszawa musieli zostać na stadionie ze względu na własne bezpieczeństwo. Wielu najwyraźniej nie zgodziło się z tym i użyło przemocy - twierdzą przedstawiciele niderlandzkiego miasta Alkmaar, w którym doszło do skandalu z udziałem policji i polskich sportowców. W oświadczeniu czytamy m.in., że potępiają zachowanie legionistów, a nie mundurowych atakujących naszych sportowców.

## Japonia: Masowe zatrucie w restauracji. Setki osób w szpitalach, jeszcze więcej poszkodowanych
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/japonia-masowe-zatrucie-w-restauracji-setki-osob-w-szpitalach-jeszcze-wiecej-poszkodowanych/](https://www.polsatnews.pl/wiadomosc/2023-10-06/japonia-masowe-zatrucie-w-restauracji-setki-osob-w-szpitalach-jeszcze-wiecej-poszkodowanych/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T16:27:00+00:00

Ponad tysiąc klientów japońskiej restauracji Nagashi Somen doznało zatrucia pokarmowego. Ponad 600 z nich przewieziono do szpitali. Sprawą zajęły się lokalne władze, analizując, jaki składnik pożywienia wywołał tak szkodliwe skutki. Przyjrzeli się jednej z potraw, z której słynął lokal - i to była trafna decyzja.

## Szczyt w Grenadzie. Premier Morawiecki: Zawetowałem konkluzje dotyczące migracji
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/premier-mateusz-morawiecki-podjalem-decyzje-o-zawetowaniu-czesci-dotyczacej-migracji/](https://www.polsatnews.pl/wiadomosc/2023-10-06/premier-mateusz-morawiecki-podjalem-decyzje-o-zawetowaniu-czesci-dotyczacej-migracji/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T14:58:00+00:00

Podjąłem decyzję o zawetowaniu części dotyczącej migracji. Nie ma tego zapisu w konkluzji szczytu - powiedział po piątkowym szczycie Unii Europejskiej premier Mateusz Morawiecki. Jak dodał, rząd PiS jest jedynym gwarantem powstrzymania fali nielegalnej imigracji, która chce UE rozlokować po całej Europie.

## UNESCO chce stworzyć pierwsze na świecie wirtualne muzeum przedstawiające skradzione eksponaty
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/unesco-chce-stworzyc-pierwsze-na-swiecie-wirtualne-muzeum-przedstawiajace-skradzione-eksponaty/](https://www.polsatnews.pl/wiadomosc/2023-10-06/unesco-chce-stworzyc-pierwsze-na-swiecie-wirtualne-muzeum-przedstawiajace-skradzione-eksponaty/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T09:16:00+00:00

UNESCO ogłosiła plany powstania pierwszego wirtualnego muzeum skradzionych eksponatów. Niespotykana dotąd wystawa ma uchronić cenne przedmioty od zapomnienia. Naszym celem jest przywrócenie tych dzieł w centrum uwagi i przywrócenie społeczeństwu prawa do dostępu do swojego dziedzictwa, doświadczania go i nauki o nim - głosiła przedstawicielka organizacji.

## Pokojowa Nagroda Nobla 2023 przyznana. Trafiła do Narges Mohammadi
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/pokojowa-nagroda-nobla-2023-przyznana/](https://www.polsatnews.pl/wiadomosc/2023-10-06/pokojowa-nagroda-nobla-2023-przyznana/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T09:00:00+00:00

Przyznano Pokojową Nagrodę Nobla 2023. Laureatem została Narges Mohammadi - irańska obrończyni praw kobiet. W uzasadnieniu uhonorowano jej walkę z uciskiem kobiet w Iranie oraz walkę na rzecz promowania praw człowieka i wolności dla wszystkich.

## Naukowiec ostrzega. Denga zagrozi Europie w kolejnych latach
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/naukowiec-ostrzega-denga-zagrozi-europie-kolejnych-latach/](https://www.polsatnews.pl/wiadomosc/2023-10-06/naukowiec-ostrzega-denga-zagrozi-europie-kolejnych-latach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T08:49:00+00:00

Groźna choroba tropikalna niedługo zagrozi Europie. Jeszcze w tej dekadzie denga stanie się poważnym problemem dla południa Europy, części stanów USA oraz kolejnych obszarów Afryki - ostrzega główny naukowiec Światowej Organizacji Zdrowia (WHO) Jeremy Farrar. Jak wskazał, rosnące temperatury ułatwiają roznoszenie choroby przez komary.

## Japonia: Władze chcą zakazać Halloween w jednej z dzielnic. Powodem zbyt duże tłumy
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/japonia-wladze-chca-zakazac-halloween-w-jednej-z-dzielnic-powodem-zbyt-duze-tlumy/](https://www.polsatnews.pl/wiadomosc/2023-10-06/japonia-wladze-chca-zakazac-halloween-w-jednej-z-dzielnic-powodem-zbyt-duze-tlumy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T08:00:00+00:00

Władze japońskiej dzielnicy chcą zakazać plenerowych zabaw z okazji Halloween. Ograniczenia mają zostać wprowadzone już pięć dni przed obchodzonym świętem. Pomysł tłumaczony jest obawą o bezpieczeństwo obywateli i turystów. Urzędnicy obawiają się powtórki z ubiegłorocznej tragedii, która kosztowała życie 156 osób.

## Rząd przygotowuje ewakuacje. Włosi obawiają się Pól Flegrejskich
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/rzad-przygotowuje-ewakuacje-wlosi-obawiaja-sie-pol-flegrejskich/](https://www.polsatnews.pl/wiadomosc/2023-10-06/rzad-przygotowuje-ewakuacje-wlosi-obawiaja-sie-pol-flegrejskich/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T06:12:00+00:00

Rząd Włoch przygotowuje plany ewakuacji dziesiątek tysięcy mieszkańców południowych Włoch. Administracja chce być przygotowana na wypadek erupcji kraterów na Polach Flegrejskich (Campi Flegrei) koło Neapolu.

## Swiatłana Cichanouska o reżimie Łukaszenki: Jest jak krzesło na trzech nogach
 - [https://www.polsatnews.pl/wiadomosc/2023-10-06/swiatlana-cichanouska-o-rezimie-lukaszenki-jest-jak-krzeslo-o-trzech-nogach/](https://www.polsatnews.pl/wiadomosc/2023-10-06/swiatlana-cichanouska-o-rezimie-lukaszenki-jest-jak-krzeslo-o-trzech-nogach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-10-06T05:24:00+00:00

Swiatłana Cichanouska, liderka opozycji białoruskiej, wypowiedziała się w Polsat News o reżimie Łukaszenki. Nazwała go dyktatorem i przestępcą. Zaznaczyła, że naród białoruski nie jest tym samym, co reżim Łukaszenki. - On jest jak krzesło na trzech nogach - represje, pieniądze i Rosja. Jeżeli jedna noga będzie zniszczona, upadnie całe krzesło i reżim - zaznaczyła w Dniu na Świecie.

