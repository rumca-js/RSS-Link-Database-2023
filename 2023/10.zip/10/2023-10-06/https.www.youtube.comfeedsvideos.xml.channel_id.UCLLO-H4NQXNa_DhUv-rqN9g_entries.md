# Source:CD-Action, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g, language:pl

## The Crew Motorfest: najbardziej rzetelna recenzja
 - [https://www.youtube.com/watch?v=4kBNvekpPFM](https://www.youtube.com/watch?v=4kBNvekpPFM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCLLO-H4NQXNa_DhUv-rqN9g
 - date published: 2023-10-06T20:49:40+00:00

Matko, to już drugi materiał o wyścigówkach w tym tygodniu! Z tym że ten traktujcie trochę jak recenzję, a trochę jak... polemikę. Zapraszam!

Koniecznie zobacz nas w innych miejscach:

Strona :: https://cdaction.pl/
Sklep :: https://sklep.cdaction.pl/
Instagram :: https://instagram.com/magazyncdaction
Facebook :: http://fb.me/CDAction/
Twitter :: https://twitter.com/cdaction
Discord CD-Action :: https://discord.gg/9Aqf3Cjcxx
Kontakt :: youtube@cdaction.pl

Prowadzenie i scenariusz: Krzysztof „Bastian” Freudenberger (http://twitter.com/BastianCDA)

Montaż: Mateusz Pietrasiak

