# Source:Npr, URL:https://feeds.npr.org/1001/rss.xml, language:en-US

## How to make sense of the country's stunningly strong job market
 - [https://www.npr.org/2023/10/06/1204179771/jobs-labor-market-employers-economy-inflation-interest-rates](https://www.npr.org/2023/10/06/1204179771/jobs-labor-market-employers-economy-inflation-interest-rates)
 - RSS feed: https://feeds.npr.org/1001/rss.xml
 - date published: 2023-10-06T17:53:28+00:00

U.S. employers added about twice as many jobs in September as forecasters expected. That's good for people looking for work, but the strong report could complicate the Fed's effort to curb inflation.

