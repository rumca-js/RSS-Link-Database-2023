# Source:The Hill, URL:https://thehill.com/news/feed, language:en-US

## RNC chairwoman says GOP 'can't afford' House Speakership race taking 'too long'
 - [https://thehill.com/homenews/house/4242836-rnc-mcdaniel-house-republicans-speakership-race/](https://thehill.com/homenews/house/4242836-rnc-mcdaniel-house-republicans-speakership-race/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T22:17:06+00:00

Republican National Committee (RNC) Chairwoman Ronna McDaniel implied Friday that her party “cannot afford” for House Speaker race to last "too long." “I don't think our country can afford that to take too long, and I think it's bad for our party,” McDaniel said on Fox News. “I also hope they get rid of this...

## Speaker battle may determine new Ukraine aid
 - [https://thehill.com/newsletters/defense-national-security/4242858-speaker-battle-may-determine-new-ukraine-aid/](https://thehill.com/newsletters/defense-national-security/4242858-speaker-battle-may-determine-new-ukraine-aid/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T22:15:11+00:00

Welcome to The Hill's Defense &#038; NatSec newsletter {beacon} Defense &#038;National Security Defense &#038;National Security &#8202; The Big Story  Will new House Speaker support Ukraine aid? Approved money for Ukraine is running out as the House races to elect a new leader. © AP Three major contenders have emerged in the GOP for next House...

## Speaker vacancy fuels shutdown fears
 - [https://thehill.com/newsletters/business-economy/4242855-speaker-vacancy-fuels-shutdown-fears/](https://thehill.com/newsletters/business-economy/4242855-speaker-vacancy-fuels-shutdown-fears/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T22:13:48+00:00

Welcome to The Hill's Business &#38; Economy newsletter {beacon} Business &#38; Economy Business &#38; Economy The Big Story  Markets wobble amid leadership vacuum in House The stock and bond markets are straining under a lack of leadership in the House and fears of a government shutdown. © AP Photo/Gene J. Puskar The historic ouster this...

## FCC mulls Wi-Fi for school buses
 - [https://thehill.com/newsletters/technology/4242808-fcc-mulls-wi-fi-for-school-buses/](https://thehill.com/newsletters/technology/4242808-fcc-mulls-wi-fi-for-school-buses/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T22:02:50+00:00

Welcome to The Hill's Technology newsletter {beacon} Technology Technology The Big Story  Battle brews over FCC plan to bring Wi-Fi to school buses A growing partisan fight is emerging over a push to expand internet access on public school buses.  © Jake May/The Flint Journal via AP Federal Communications Commission (FCC) Chair Jessica Rosenworcel, a...

## Americans without college degrees aren't living as long: study
 - [https://thehill.com/changing-america/well-being/longevity/4242779-americans-without-college-degrees-arent-living-as-long-study/](https://thehill.com/changing-america/well-being/longevity/4242779-americans-without-college-degrees-arent-living-as-long-study/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T22:00:34+00:00

Story at a glance Americans without a college degree don’t live as long as those with a degree, according to a new study. And the gap between how long those with and without an undergraduate degree are living is widening. The study, featured the fall 2023 edition of the Brookings Papers on Economic Activity, found...

## The complicated truth about EVs and jobs
 - [https://thehill.com/newsletters/energy-environment/4242795-the-complicated-truth-about-evs-and-jobs/](https://thehill.com/newsletters/energy-environment/4242795-the-complicated-truth-about-evs-and-jobs/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T21:55:11+00:00

Welcome to The Hill's Energy &#038; Environment newsletter {beacon} Energy &#038; Environment Energy &#038; Environment &#8202; The Big Story  What does the transition to EVs mean for workers?  President Biden has depicted the transition to electric vehicles (EVs) as a gain for workers; Republicans denounce it as a job-killer. The truth is more complex than...

## Trump seeks to exert power in Speaker race
 - [https://thehill.com/newsletters/evening-report/4242758-trump-exerts-power-in-speaker-race/](https://thehill.com/newsletters/evening-report/4242758-trump-exerts-power-in-speaker-race/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T21:19:40+00:00

Plus: Republican voters remain split over McCarthy removal {beacon}    Evening Report Friday, October 6   ©  AP Trump seeks to exert power in Speaker race DONALD TRUMP'S endorsement of Rep. Jim Jordan (R-Ohio) to be the next Speaker underscores the former president's continued efforts to wield influence over congressional Republicans as he seeks a White...

## RFK Jr. set to speak at CPAC event
 - [https://thehill.com/homenews/campaign/4242110-rfk-jr-set-to-speak-at-cpac-event/](https://thehill.com/homenews/campaign/4242110-rfk-jr-set-to-speak-at-cpac-event/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T18:31:12+00:00

Democratic presidential candidate Robert F. Kennedy, Jr. will be a headline speaker at a Conservative Political Action Conference event in Las Vegas later this month, the conference announced Friday. The anti-establishment environmental lawyer has run a longshot primary campaign against President Biden, but is expected to change affiliation to independent next week. “Robert F. Kennedy...

## Choose strength, choose unity, choose Scalise for House Speaker
 - [https://thehill.com/opinion/congress-blog/4242274-choose-strength-choose-unity-choose-scalise-for-house-speaker/](https://thehill.com/opinion/congress-blog/4242274-choose-strength-choose-unity-choose-scalise-for-house-speaker/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T18:30:00+00:00

We're at a crossroads, and the decisions we make today will impact not just this Congress but the very trajectory of our country. That's why I'm not just endorsing Rep. Steve Scalise (R-La.) for Speaker of the House; I'm urgently calling for all hands on deck to make this vision a reality. The Unity Architect ...

## Oil prices drop, set to bring some relief at pump
 - [https://thehill.com/policy/energy-environment/4242269-oil-prices-drop-pump/](https://thehill.com/policy/energy-environment/4242269-oil-prices-drop-pump/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:43:55+00:00

Oil prices fell this week, which is expected to result in relief at the pump for consumers. The price of U.S. crude oil has fallen significantly over the past several days, falling from as high as $94 per barrel last week down to about $90 earlier this week.  Prices dropped for a second time this...

## Congress raises alarm on aging military barracks, housing
 - [https://thehill.com/policy/defense/4242116-congress-raises-alarm-on-aging-military-barracks-housing/](https://thehill.com/policy/defense/4242116-congress-raises-alarm-on-aging-military-barracks-housing/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:35:10+00:00

Lawmakers are upset about deteriorating military barracks and housing conditions, expressing serious concerns about delayed repairs and failing conditions, including mold and non-functioning air condition and heating units. The issue was amplified this week after Sen. Josh Hawley (R-Mo.) threatened to withhold all Army civilian nominations that require Senate confirmation, or the most senior positions...

## Jeffries calls effort to kick Pelosi, Hoyer out of hideaway offices ‘petty, partisan and petulant’
 - [https://thehill.com/homenews/house/4242262-jeffries-pelosi-hoyer-hideaway-offices-petty-partisan-gop/](https://thehill.com/homenews/house/4242262-jeffries-pelosi-hoyer-hideaway-offices-petty-partisan-gop/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:34:25+00:00

House Minority Leader Hakeem Jeffries (D-N.Y.) on Friday condemned the efforts taken by Republicans to kick two senior Democrats out of their offices in the Capitol. The decision to remove Speaker Emerita Nancy Pelosi (D-Calif.) and Rep. Steny Hoyer (D-Md.) from their offices was “petty, partisan and petulant,” Jeffries wrote in an op-ed for The...

## Why book ‘bans’ are fake news
 - [https://thehill.com/opinion/education/4240486-why-book-bans-are-fake-news/](https://thehill.com/opinion/education/4240486-why-book-bans-are-fake-news/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:30:00+00:00

Discretion in the selection process of kids’ books is not the same as banning.

## Televised Fox News Speaker forum called off after candidates pull out
 - [https://thehill.com/homenews/house/4242236-televised-fox-news-speaker-forum-called-off-after-candidates-pull-out/](https://thehill.com/homenews/house/4242236-televised-fox-news-speaker-forum-called-off-after-candidates-pull-out/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:17:26+00:00

Plans for a televised Fox News forum with three contenders for House Speaker fell apart soon after they were announced. Host Bret Baier was slated to have House Majority Leader Scalise (R-La.), House Judiciary Committee Chairman Jim Jordan (R-Ohio) and Republican Study Committee Chairman Kevin Hern (R-Okla.) for a Monday event that Fox News billed...

## Biden says November meeting with China's Xi is 'a possibility'
 - [https://thehill.com/homenews/administration/4242237-biden-says-november-meeting-with-chinas-xi-is-a-possibility/](https://thehill.com/homenews/administration/4242237-biden-says-november-meeting-with-chinas-xi-is-a-possibility/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T17:14:31+00:00

President Biden on Friday said a meeting with Chinese President Xi Jinping in the United States next month is possible. When questioned on reporting that the two leaders will meet face-to-face in California next month, Biden wouldn’t confirm a meeting is scheduled. “There is no such meeting set up, but it is a possibility,” the...

## The Hill's 12:30 Report — Trump backs Jordan after House sacks McCarthy
 - [https://thehill.com/newsletters/1230-report/4242125-the-hills-1230-report-trump-backs-jordan-after-house-sacks-mccarthy/](https://thehill.com/newsletters/1230-report/4242125-the-hills-1230-report-trump-backs-jordan-after-house-sacks-mccarthy/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T16:32:47+00:00

{beacon} 12:30 REPORT It’s FRIDAY. Heading into our first October weekend. Football season, pumpkin spice season, jeans and flannel season, scary movie season and (hopefully) a little cooler weather. We’ve made it to fall! I think... Here's what's coming up:  Former President Trump is throwing his weight behind one of his top House allies —...

## Media outlets ask for cameras in court for Trump election interference trial
 - [https://thehill.com/homenews/4242098-trump-election-trial-cameras-court/](https://thehill.com/homenews/4242098-trump-election-trial-cameras-court/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T16:09:35+00:00

A coalition of media outlets is pushing the judge overseeing the election interference case of former President Trump to allow cameras in the courtroom – asking for an unprecedented shift in the federal court system. “We have never, in the history of our Nation, had a federal criminal trial that warrants audiovisual access more than...

## How To Negotiate Flexible Working
 - [https://thehill.com/lobbying/4242074-how-to-negotiate-flexible-working/](https://thehill.com/lobbying/4242074-how-to-negotiate-flexible-working/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T16:08:30+00:00

Flexible working used to be taboo in many American workplaces – a modular, bespoke arrangement that was viewed by many as simply working less, rather than working better or more flexibly. More often than not, it was considered a perk or purely the realm of women and mothers. Nobody ever got to CEO by asking...

## Questionable waivers threaten the World Trade Organization’s relevance
 - [https://thehill.com/opinion/international/4240369-questionable-waivers-threaten-the-world-trade-organizations-relevance/](https://thehill.com/opinion/international/4240369-questionable-waivers-threaten-the-world-trade-organizations-relevance/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T16:00:00+00:00

Free trade is unraveling, in no small part because of this waiver frenzy.

## Texas Democrat praises new Biden border wall, 'a necessary step’
 - [https://thehill.com/homenews/administration/4241942-texas-democrat-praises-biden-border-wall/](https://thehill.com/homenews/administration/4241942-texas-democrat-praises-biden-border-wall/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T15:46:22+00:00

Rep. Colin Allred (D-Texas) came out in support Friday of the Biden administration’s decision to expand construction of new border wall on the U.S.-Mexico border, an issue which has divided Democrats. “This is a necessary step to help Texas’ overwhelmed border communities deal with this current surge of migrants,” Allred said in a statement to...

## DeSantis: US doesn't need any more presidents who 'have lost the zip on their fastball'
 - [https://thehill.com/homenews/campaign/4241767-desantis-us-doesnt-need-any-more-presidents-who-have-lost-the-zip-on-their-fastball/](https://thehill.com/homenews/campaign/4241767-desantis-us-doesnt-need-any-more-presidents-who-have-lost-the-zip-on-their-fastball/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T14:02:02+00:00

Florida Gov. Ron DeSantis (R) lashed out at former President Trump at a campaign event Thursday, knocking his age and saying Republicans nominating Trump in 2024 would actually help Democrats. “He energized Democrats. You could have John Kennedy walk through the door right now and he wouldn’t energize Democrats as much as Donald Trump does,”...

## How the House battle for a new Speaker could topple Trump’s bid for the presidency
 - [https://thehill.com/opinion/campaign/4240942-how-the-house-battle-for-a-new-speaker-could-topple-trumps-bid-for-the-presidency/](https://thehill.com/opinion/campaign/4240942-how-the-house-battle-for-a-new-speaker-could-topple-trumps-bid-for-the-presidency/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T14:00:00+00:00

The possibility of a Speaker Trump might help settle one of the core disputes of the 2024 presidential election.

## Extreme weather events expected to displace millions of children: UNICEF
 - [https://thehill.com/policy/energy-environment/4241791-extreme-weather-events-expected-to-displace-millions-of-children-unicef/](https://thehill.com/policy/energy-environment/4241791-extreme-weather-events-expected-to-displace-millions-of-children-unicef/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T13:48:53+00:00

Extreme weather events could displace millions of children over the next three decades, according to a new report from the United Nations International Children's Emergency Fund (UNICEF). The analysis found that 43.1 million child displacements over the last six years, or 20,000 child displacements per day, were linked to weather-related disasters. Most of the displacements...

## Fox News’s Bret Baier to host televised forum with three Speaker candidates
 - [https://thehill.com/homenews/house/4241800-fox-newss-bret-baier-to-host-televised-forum-with-three-speaker-candidates/](https://thehill.com/homenews/house/4241800-fox-newss-bret-baier-to-host-televised-forum-with-three-speaker-candidates/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T13:44:10+00:00

Fox News's Bret Baier will host a televised forum for the three candidates for Speaker of the House — an unusual move that follows Rep. Kevin McCarthy’s (R-Calif.) unprecedented ouster as Speaker. House Majority Leader Scalise (R-La.), House Judiciary Committee Chairman Jim Jordan (R-Ohio) and Republican Study Committee Chairman Kevin Hern (R-Okla.) would participate in...

## Republicans will regret kowtowing to unions' agenda
 - [https://thehill.com/opinion/4239790-republicans-will-regret-kowtowing-to-unions-agenda/](https://thehill.com/opinion/4239790-republicans-will-regret-kowtowing-to-unions-agenda/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T13:00:00+00:00

Politics certainly does make strange bedfellows. On Sept. 26 and 27, the two 2024 presidential frontrunners visited locations connected to the United Autoworkers strike in Michigan to show support and solidarity in their campaign for a 36 percent pay hike, 40 hours of pay for 32 hours of work, and guaranteed pensions, among other demands....

## 7 in 10 Democrats say they'll get latest COVID shot compared to 28 percent of Republicans: survey
 - [https://thehill.com/policy/healthcare/4241755-7-in-10-democrats-say-theyll-get-latest-covid-shot-compared-to-28-percent-of-republicans-survey/](https://thehill.com/policy/healthcare/4241755-7-in-10-democrats-say-theyll-get-latest-covid-shot-compared-to-28-percent-of-republicans-survey/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:57:25+00:00

Differences in political party affiliation is the primary force dividing whether Americans are going to get the latest COVID-19 booster shot, a recent poll found. Seventy percent of Democrats say they are likely to or have already received the updated shot, while 28 percent of Republicans say they will, the Ipsos poll found. The survey...

## Russian lawmakers to consider revoking nuclear test ban ratification
 - [https://thehill.com/policy/international/4241740-russian-lawmakers-to-consider-revoking-nuclear-test-ban-ratification/](https://thehill.com/policy/international/4241740-russian-lawmakers-to-consider-revoking-nuclear-test-ban-ratification/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:51:22+00:00

The Russian parliament will consider revoking the ratification of a ban on nuclear tests, the leader of its lower house announced Friday. State Duma speaker Vyacheslav Volodin cited western allies' support for Ukraine against Russian invasion as one reason to consider going back on the ban. “Washington and Brussels have unleashed a war against our...

## Police: No evidence to support Ramaswamy claim protesters intentionally rammed his car in Iowa
 - [https://thehill.com/homenews/campaign/4241724-police-in-iowa-say-no-evidence-to-support-ramaswamy-claim-protesters-rammed-his-car-in-iowa/](https://thehill.com/homenews/campaign/4241724-police-in-iowa-say-no-evidence-to-support-ramaswamy-claim-protesters-rammed-his-car-in-iowa/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:36:51+00:00

Police say there is no evidence to back up GOP presidential candidate Vivek Ramaswamy's claim that a protestor intentionally rammed his care in Iowa in retaliation after an exchange on the campaign trail. Ramaswamy was visiting a coffee shop in Grinnell, Iowa during a presidential campaign visit when he claims he was met by a...

## US added 336k jobs in September, far above expectations
 - [https://thehill.com/business/4241722-us-added-336k-jobs-in-september-far-above-expectations/](https://thehill.com/business/4241722-us-added-336k-jobs-in-september-far-above-expectations/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:31:59+00:00

The U.S. added a whopping 336,000 jobs in September and the unemployment rate stayed even at 3.8 percent, according to data released Friday by the Labor Department. The September jobs report far exceeded expectations after several months of slowing employment gains. Economists projected the U.S. to have added 170,000 jobs last month, according to consensus...

## Can Tanya Chutkan actually judge Trump fairly and without bias? Can anyone?
 - [https://thehill.com/opinion/judiciary/4240630-can-tanya-chutkan-actually-judge-trump-fairly-and-without-bias/](https://thehill.com/opinion/judiciary/4240630-can-tanya-chutkan-actually-judge-trump-fairly-and-without-bias/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:30:00+00:00

Even the likes of Khalid Shaikh Mohammed deserve a fairness that even cynics wouldn’t question.

## Hillary Clinton: MAGA 'cult members' need 'deprogramming'
 - [https://thehill.com/blogs/blog-briefing-room/4241678-hillary-clinton-maga-cult-members-need-deprogramming/](https://thehill.com/blogs/blog-briefing-room/4241678-hillary-clinton-maga-cult-members-need-deprogramming/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:04:52+00:00

Former Democratic presidential nominee State Hillary Clinton railed against supporters of former President Trump during a new CNN interview, comparing those who still support the former president after the Jan. 6, 2021 insurrection to members of a cult. “Maybe there needs to be a formal deprogramming of the cult members,” she said in a clip released...

## China continues its drive to dominate the Pacific region
 - [https://thehill.com/opinion/international/4240665-china-continues-its-drive-to-dominate-the-pacific-region/](https://thehill.com/opinion/international/4240665-china-continues-its-drive-to-dominate-the-pacific-region/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T12:00:00+00:00

Washington cannot slacken its efforts both to expand and deepen its ties throughout the wider Pacific region.

## Jailed Iranian activist Narges Mohammadi wins Nobel Peace Prize
 - [https://thehill.com/policy/international/4241674-jailed-iranian-activist-narges-mohammadi-wins-nobel-peace-prize/](https://thehill.com/policy/international/4241674-jailed-iranian-activist-narges-mohammadi-wins-nobel-peace-prize/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T11:36:56+00:00

The Nobel Peace Prize was awarded to jailed Iranian activist Narges Mohammadi on Friday for her campaign for women’s rights and democracy in the country. Mohammadi, who has spent years in custody in Iran, was sentenced to 16 years in prison in 2016. “This prize is first and foremost a recognition of the very important...

## Why Kevin McCarthy was sacked, and how the next House Speaker can avoid his fate
 - [https://thehill.com/opinion/finance/4238716-why-kevin-mccarthy-was-sacked-and-how-the-next-house-speaker-can-avoid-his-fate/](https://thehill.com/opinion/finance/4238716-why-kevin-mccarthy-was-sacked-and-how-the-next-house-speaker-can-avoid-his-fate/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T11:30:00+00:00

After the cleanup of the fiscal 2024 appropriations mess, there will be a real opportunity to learn from McCarthy’s mistakes.

## Seven wild plot twists that could upend the 2024 election
 - [https://thehill.com/opinion/4240000-seven-wild-plot-twists-that-could-upend-the-2024-election/](https://thehill.com/opinion/4240000-seven-wild-plot-twists-that-could-upend-the-2024-election/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T11:00:00+00:00

Expect the unexpected.

## Morning Report — The GOP’s leadership limbo
 - [https://thehill.com/newsletters/morning-report/4241633-morning-report-the-gops-leadership-limbo/](https://thehill.com/newsletters/morning-report/4241633-morning-report-the-gops-leadership-limbo/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T10:22:23+00:00

Congressional Republicans are facing a leadership vacuum as the search for a Speaker heats up and the next government funding deadline draws near. With just over 40 days to fund the government, jockeying to be the next Speaker of the House is in full swing after Kevin McCarthy’s (R-Calif.) shocking ouster earlier this week. The...

## McCarthy ousted as Speaker: What comes next?
 - [https://thehill.com/homenews/house/4240428-mccarthy-ousted-as-speaker-what-comes-next/](https://thehill.com/homenews/house/4240428-mccarthy-ousted-as-speaker-what-comes-next/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:45:49+00:00

The House is in uncharted territory after Rep. Kevin McCarthy (R-Calif.) was ousted from his Speakership this week, leaving members trying to navigate a way forward amid the chaos. McCarthy was booted from the top spot in a 216-210 vote on Tuesday.  The situation is unprecedented, leaving many wondering what comes next. Who is leading...

## Biden stuns allies with border wall bombshell
 - [https://thehill.com/latino/4241165-bidens-border-wall-bombshell-shocks-allies/](https://thehill.com/latino/4241165-bidens-border-wall-bombshell-shocks-allies/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

President Biden’s decision this week to move forward with border wall construction that Democrats have long denounced shocked allies and immigration advocates. The stunning reversal came just days after administration officials participated in an immigration roundtable at the Capitol featuring Congressional Hispanic Caucus (CHC) members and immigration advocates. The administration's participation in the roundtable drew praise...

## Menendez indictment opens door for crowded Senate primary
 - [https://thehill.com/homenews/campaign/4239014-menendez-indictment-opens-door-for-crowded-senate-primary/](https://thehill.com/homenews/campaign/4239014-menendez-indictment-opens-door-for-crowded-senate-primary/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

A rowdy and crowded primary could be in store for New Jersey Democrats as much of the party has come out against the now-indicted Sen. Robert Menendez (D). Menendez has asserted his innocence against bribery charges brought last month, while many of his Senate Democratic colleagues and state party leaders are calling on him to resign. Instead,...

## RFK Jr. independent bid poses threat to Biden and Trump
 - [https://thehill.com/homenews/campaign/4238858-rfk-jr-independent-bid-poses-threat-to-biden-and-trump/](https://thehill.com/homenews/campaign/4238858-rfk-jr-independent-bid-poses-threat-to-biden-and-trump/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

Robert F. Kennedy Jr.’s likely party switch from Democrat to independent would be a major wild card with the power to reshape the 2024 presidential election — it’s just unclear for which side. Kennedy’s doomed primary bid against President Biden has kept the nominating contest concentrated around the president, even as he faces dips in...

## The Memo: Biden builds a wall and ignites a storm
 - [https://thehill.com/homenews/administration/4241240-the-memo-biden-builds-a-wall-and-ignites-a-storm/](https://thehill.com/homenews/administration/4241240-the-memo-biden-builds-a-wall-and-ignites-a-storm/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

One of the most striking political u-turns of the Biden administration is underway. President Biden will, after all, build a section of border wall, it has emerged — despite having at one time pledged that “not another foot” would be constructed. The dramatic news came in the undramatic shape of an announcement in the Federal...

## Thune flexes muscle in shadow Senate GOP leadership race
 - [https://thehill.com/homenews/senate/4241191-thune-flexes-muscle-in-shadow-senate-gop-leadership-race/](https://thehill.com/homenews/senate/4241191-thune-flexes-muscle-in-shadow-senate-gop-leadership-race/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

Senate Republican Whip John Thune (S.D.) is asserting himself in the Senate GOP’s raucous debate over how to avoid a government shutdown, showcasing his ability to lead ahead of any future race to succeed Senate Republican Leader Mitch McConnell (R-Ky.).   Republican senators say the quiet jockeying among the “three Johns” in the mix to...

## What does the transition to EVs mean for workers?
 - [https://thehill.com/policy/energy-environment/4238445-what-does-the-transition-to-evs-mean-for-workers/](https://thehill.com/policy/energy-environment/4238445-what-does-the-transition-to-evs-mean-for-workers/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T09:00:00+00:00

Former President Trump and other GOP hopefuls are demonizing the shift to electric vehicles (EVs) as part of an effort to win over disaffected workers in Michigan. At the same time, President Biden is making the case that the transition can go hand-in-hand with job creation.  The reality is grayer than politicians on either side of the aisle say,...

## Trump endorses Jim Jordan for Speaker
 - [https://digital-dev.thehill.com/homenews/house/4241501-trump-endorses-jim-jordan-for-speaker/](https://digital-dev.thehill.com/homenews/house/4241501-trump-endorses-jim-jordan-for-speaker/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T04:39:50+00:00

Former President Trump threw his support behind Rep. Jim Jordan (R-Ohio) to be the next House Speaker late Thursday night, giving the conservative firebrand a boost in his effort to win the gavel. "He is a STRONG on Crime, Borders, our Military/Vets, &#38; 2nd Amendment. Jim, his wife, Polly, &#38; family are outstanding - He will be a...

## Actor Mark Ruffalo dubs Trump an ‘enemy of America’
 - [https://digital-dev.thehill.com/blogs/in-the-know/4241443-actor-mark-ruffalo-dubs-trump-an-enemy-of-america/](https://digital-dev.thehill.com/blogs/in-the-know/4241443-actor-mark-ruffalo-dubs-trump-an-enemy-of-america/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T02:58:02+00:00

Actor Mark Ruffalo in a Thursday post slammed former President Donald Trump, calling him an “enemy of America” in response to a recent opinion audio piece by the New York Times. The Times published an Opinion Shorts audio clip Thursday titled, “Now Is the Time to Pay Attention to Trump’s Violent Language," in which editor...

## Sources say Trump set to endorse Jordan for Speakership
 - [https://digital-dev.thehill.com/homenews/house/4241429-sources-say-trump-set-to-endorse-jordan-for-speakership/](https://digital-dev.thehill.com/homenews/house/4241429-sources-say-trump-set-to-endorse-jordan-for-speakership/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T02:32:13+00:00

Former President Donald Trump is expected to endorse Rep. Jim Jordan (R-Ohio) to be the next House Speaker, Rep. Troy Nehls (R-Texas) claimed in a post online. After the House removed former Speaker Kevin McCarthy in a historic vote Tuesday, several names have floated around as his replacement. Jordan, the Judiciary Committee Chairman, and House...

## Steube says GOP would change House rules for Trump
 - [https://digital-dev.thehill.com/homenews/4241412-steube-says-gop-would-change-house-rules-for-trump/](https://digital-dev.thehill.com/homenews/4241412-steube-says-gop-would-change-house-rules-for-trump/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T02:16:49+00:00

Rep. Greg Steube (R-Fla.) said House Republicans would change House rules if need be to make former President Donald Trump the next House Speaker. A handful of Republicans have floated the possibility of electing Trump to replace former Speaker Kevin McCarthy (R-Calif.), who was ousted from his leadership position Tuesday. Trump initially dismissed the call...

## Lara Trump says Trump mentioned Speakership to her during phone call
 - [https://digital-dev.thehill.com/homenews/house/4241336-lara-trump-says-trump-mentioned-speakership-to-her-during-phone-call/](https://digital-dev.thehill.com/homenews/house/4241336-lara-trump-says-trump-mentioned-speakership-to-her-during-phone-call/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T02:09:07+00:00

Lara Trump said her father-in-law, former President Trump, brought up the prospect of becoming Speaker of the House on a phone call with her on Thursday. “Just got off the phone with him not too long ago. He brought it up to me,” she said in an interview with radio host John Castimatidis on WABC...

## Trump voluntarily dismisses lawsuit against Michael Cohen
 - [https://digital-dev.thehill.com/regulation/court-battles/4241379-trump-voluntarily-dismisses-lawsuit-against-michael-cohen/](https://digital-dev.thehill.com/regulation/court-battles/4241379-trump-voluntarily-dismisses-lawsuit-against-michael-cohen/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T01:28:46+00:00

Former President Trump filed to voluntarily dismiss his lawsuit against Michael Cohen on Thursday evening, court documents show. The sudden twist comes just days before Trump was set to sit for a deposition in the case. Trump sued Cohen, his longtime attorney and fixer, in April for $500 million over accusations that Cohen maliciously worked...

## MTG surveying constituents for Speakership vote, despite saying Trump is ‘perfect man for the job’
 - [https://digital-dev.thehill.com/homenews/house/4241355-mtg-surveying-constituents-for-speakership-vote/](https://digital-dev.thehill.com/homenews/house/4241355-mtg-surveying-constituents-for-speakership-vote/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T01:00:15+00:00

Rep. Marjorie Taylor Greene (R-Ga.) is asking her constituents for input on who they think should be the next Speaker of the House. “The House of Representatives is scrambling to find the next Speaker of the House,” she said in a page on her Congressional website. After Tuesday’s historic vote ousted former Speaker Kevin McCarthy...

## Ocasio-Cortez on border wall announcement: President must 'take responsibility,' 'reverse course'
 - [https://thehill.com/homenews/4241327-ocasio-cortez-on-border-wall-announcement-president-must-take-responsibility-reverse-course/](https://thehill.com/homenews/4241327-ocasio-cortez-on-border-wall-announcement-president-must-take-responsibility-reverse-course/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T00:35:57+00:00

Rep. Alexandria Ocasio-Cortez (D-N.Y.) released a statement Thursday condemning the Biden administration’s decision to waive 26 federal laws, which will allow border wall construction to commence in Texas. “The Biden administration was not required to expand construction of the border wall — and they certainly were not required to waive several environmental laws to expedite...

## Ocasio-Cortez on border wall announcement: President must 'take responsibility,' 'reverse course'
 - [https://digital-dev.thehill.com/homenews/4241327-ocasio-cortez-on-border-wall-announcement-president-must-take-responsibility-reverse-course/](https://digital-dev.thehill.com/homenews/4241327-ocasio-cortez-on-border-wall-announcement-president-must-take-responsibility-reverse-course/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T00:35:57+00:00

Rep. Alexandria Ocasio-Cortez (D-N.Y.) released a statement Thursday condemning the Biden administration’s decision to waive 26 federal laws, which will allow border wall construction to commence in Texas. “The Biden administration was not required to expand construction of the border wall — and they certainly were not required to waive several environmental laws to expedite...

## Grassley says Biden border wall decision made because 'big blue cities' are 'facing the reality' of migrant crisis
 - [https://thehill.com/homenews/administration/4241269-grassley-says-biden-administration-border-wall-decision-made-because-big-blue-cities-are-facing-the-reality-of-migrant-crisis/](https://thehill.com/homenews/administration/4241269-grassley-says-biden-administration-border-wall-decision-made-because-big-blue-cities-are-facing-the-reality-of-migrant-crisis/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T00:35:09+00:00

Sen. Chuck Grassley (R-Iowa) had backhanded praise for the Biden administration’s decision to expand the border wall on the U.S.-Mexico border in Texas on Thursday, saying the shift proves Republican border policy right. Grassley celebrated the move, but said previous Biden administration policies caused the mass undocumented immigration that made more wall necessary. "never shld...

## Grassley says Biden border wall decision made because 'big blue cities' are 'facing the reality' of migrant crisis
 - [https://digital-dev.thehill.com/homenews/administration/4241269-grassley-says-biden-administration-border-wall-decision-made-because-big-blue-cities-are-facing-the-reality-of-migrant-crisis/](https://digital-dev.thehill.com/homenews/administration/4241269-grassley-says-biden-administration-border-wall-decision-made-because-big-blue-cities-are-facing-the-reality-of-migrant-crisis/)
 - RSS feed: https://thehill.com/news/feed
 - date published: 2023-10-06T00:35:09+00:00

Sen. Chuck Grassley (R-Iowa) had backhanded praise for the Biden administration’s decision to expand the border wall on the U.S.-Mexico border in Texas on Thursday, saying the shift proves Republican border policy right. Grassley celebrated the move, but said previous Biden administration policies caused the mass undocumented immigration that made more wall necessary. "never shld...

