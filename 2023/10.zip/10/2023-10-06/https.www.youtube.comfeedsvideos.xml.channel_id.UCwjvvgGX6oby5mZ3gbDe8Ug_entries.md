# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## Food was cleared in 2 minutes! The Comedy & Tragedy: Community Cafeteria + One Village One Cafeteria
 - [https://www.youtube.com/watch?v=QfE-YiM2z34](https://www.youtube.com/watch?v=QfE-YiM2z34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-10-06T18:45:09+00:00

#Chinainsights#Chinanews
This widely circulated footage shocked many overseas Chinese. They felt the "communal kitchen" of the past was back. When the big wok of food was cleared in 2 minutes, it made the audience wonder if China was having a food crisis, or whether the local villagers were impoverished and too hungry.

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against the person(s) concerned.

