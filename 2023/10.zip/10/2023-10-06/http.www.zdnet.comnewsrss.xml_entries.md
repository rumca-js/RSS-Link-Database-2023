# Source:ZDNET, URL:http://www.zdnet.com/news/rss.xml, language:en-US

## DJI Mini 4 Pro hands-on: What a time to be alive
 - [https://www.zdnet.com/home-and-office/dji-mini-4-pro-hands-on-what-a-time-to-be-alive/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/dji-mini-4-pro-hands-on-what-a-time-to-be-alive/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T21:02:12+00:00

The improvements might be more evolutionary than revolutionary, but that's what is needed right now.

## The 12 best early October Prime Day security camera deals
 - [https://www.zdnet.com/home-and-office/best-early-october-prime-day-security-camera-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-early-october-prime-day-security-camera-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T20:37:00+00:00

Gearing up for Amazon's October Prime Day sale? Here are the best security camera sales ahead of Amazon's Prime Big Deal Days, with selections from Ring, Arlo, Blink, and more.

## The best early Walmart holiday deals: AirPods, TVs, laptops, smartwatches, and more
 - [https://www.zdnet.com/home-and-office/best-walmart-deals/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-walmart-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T20:32:04+00:00

Score deals from top brands on all of your tech needs during Walmart's Holiday Kickoff savings event.

## The 9 best early October Prime Day weird tech deals
 - [https://www.zdnet.com/article/best-early-october-prime-day-weird-tech-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-weird-tech-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T20:31:00+00:00

Don't know what to spend your Prime Day budget on? Check out these discounted gadgets and gizmos that you didn't know you needed.

## Best early October Prime Day laptop deals
 - [https://www.zdnet.com/article/best-early-october-prime-day-laptop-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-laptop-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T20:20:23+00:00

Find big discounts on top laptops and monitors ahead of Amazon's Prime Big Deal Days sale.

## HP just unveiled a portable all-in-one computer, and that wasn't the craziest announcement
 - [https://www.zdnet.com/article/everything-announced-at-hp-imagine-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/everything-announced-at-hp-imagine-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T19:27:00+00:00

The HP Imagine 2023 conference laid out the company's roadmap for 2024 and showed off some impressive new projects and devices, some of which you can already preorder.

## Top Best Buy deals ahead of October Prime Day: MacBooks, robot vacuums, and more
 - [https://www.zdnet.com/article/best-early-october-prime-day-bestbuy-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-bestbuy-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T19:13:00+00:00

Score tech deals at Best Buy that rival those of Amazon's Prime Big Deal Days.

## The best early October Prime Day deals from Best Buy, Walmart, and more
 - [https://www.zdnet.com/home-and-office/best-early-october-prime-day-alternative-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/best-early-october-prime-day-alternative-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T18:59:00+00:00

Don't have Prime, or don't want to shop on Amazon? Check out these great deals from other retailers happening alongside the Prime Big Deal Days sale.

## The best early October Prime Day phone deals
 - [https://www.zdnet.com/article/best-early-october-prime-day-phone-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-phone-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T18:44:46+00:00

Shopping for a new smartphone? Here are the best early phone sales ahead of Amazon's Prime Big Deal Days event, with offers on the latest iPhone, Pixel, Samsung Galaxy, and more.

## The best Roborock vacuums of 2023
 - [https://www.zdnet.com/home-and-office/kitchen-household/best-roborock-robot-vacuum/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/kitchen-household/best-roborock-robot-vacuum/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T18:34:00+00:00

ZDNET tested the best Roborock robot vacuums and mops that will do all of the cleaning for you.

## The best early October Prime Day Fire TV deals
 - [https://www.zdnet.com/home-and-office/home-entertainment/best-early-october-prime-day-fire-tv-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/best-early-october-prime-day-fire-tv-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T18:20:45+00:00

Amazon's second Prime Day of the year is coming, but we already found some hefty discounts on Fire TVs ahead of the Prime Big Deal Days sale.

## Buy a Sam's Club membership for just $15 right now
 - [https://www.zdnet.com/home-and-office/home-entertainment/buy-a-sams-club-membership-for-just-15-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/buy-a-sams-club-membership-for-just-15-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T18:00:25+00:00

Get a one-year Sam's Club membership on super sale right now, and shop for everything from groceries to gadgets.

## Need help putting your phone down? This free app activates 'monk mode' for you
 - [https://www.zdnet.com/article/need-help-putting-your-phone-down-this-free-app-activates-monk-mode-for-you/#ftag=RSSbaffb68](https://www.zdnet.com/article/need-help-putting-your-phone-down-this-free-app-activates-monk-mode-for-you/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T17:49:27+00:00

Freedom is a productivity app that helps you keep your phone away when you need to fully concentrate on a task. Here's how it works.

## The 15 best early October Prime Day Samsung deals
 - [https://www.zdnet.com/article/best-early-october-prime-day-samsung-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-samsung-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T17:45:31+00:00

These are the best deals on Samsung appliances, TVs, phones, and more, ahead of Amazon's Prime Big Deal Days sale.

## Magnifier app rolls out for Pixel phones, and it's a fantastic leap in accessibility
 - [https://www.zdnet.com/article/google-releases-magnifier-app-for-pixel-phones-and-its-a-fantastic-leap-in-accessibility/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-releases-magnifier-app-for-pixel-phones-and-its-a-fantastic-leap-in-accessibility/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T17:23:19+00:00

Announced just last week, Magnifier makes the world around you a lot easier to read.

## Last chance: Upgrade to Windows 11 Pro and Microsoft Office Pro for just $50
 - [https://www.zdnet.com/article/last-chance-upgrade-to-windows-11-pro-and-microsoft-office-pro-for-just-50/#ftag=RSSbaffb68](https://www.zdnet.com/article/last-chance-upgrade-to-windows-11-pro-and-microsoft-office-pro-for-just-50/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T17:07:22+00:00

Buy a lifetime license to both Windows 11 Pro and Microsoft Office Pro to improve your computer's security and work features.

## The new and improved Microsoft Teams app is now generally available
 - [https://www.zdnet.com/home-and-office/work-life/the-new-and-improved-microsoft-teams-app-is-now-generally-available-heres-why-you-should-care/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/work-life/the-new-and-improved-microsoft-teams-app-is-now-generally-available-heres-why-you-should-care/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T17:03:15+00:00

With a fresh user interface, faster speeds, and AI capabilities, the new Teams is sure to optimize your workflow.

## The Amazon $150 50-inch TV deal is back by invitation only. Here's how to sign up
 - [https://www.zdnet.com/home-and-office/home-entertainment/how-to-sign-up-for-amazons-invite-only-prime-day-deals/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/how-to-sign-up-for-amazons-invite-only-prime-day-deals/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T16:58:00+00:00

Amazon's Prime Big Deal Days are only days away, but you can already secure your spot for some amazing deals.

## iPhone 15 Pro Max: 50 photos that show what the new camera system can do
 - [https://www.zdnet.com/article/iphone-15-pro-max-50-photos-that-show-what-the-new-camera-system-can-do/#ftag=RSSbaffb68](https://www.zdnet.com/article/iphone-15-pro-max-50-photos-that-show-what-the-new-camera-system-can-do/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T16:51:23+00:00

See Apple's 5x telephoto in action and get a look at the iPhone 15 Pro Max's improvements in portrait mode, night mode, capturing detail, and more.

## The best early October Prime Day Apple deals
 - [https://www.zdnet.com/article/best-early-october-prime-day-apple-deals-2023/#ftag=RSSbaffb68](https://www.zdnet.com/article/best-early-october-prime-day-apple-deals-2023/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T16:42:16+00:00

Amazon's October Prime Day is the perfect opportunity to snag a deal on Apple iPads, AirPods, Apple Watches, and more, and there are lots of great savings to be had already.

## Get lifetime access to a CompTIA course bundle for just $50
 - [https://www.zdnet.com/education/get-lifetime-access-to-a-comptia-course-bundle-for-just-50/#ftag=RSSbaffb68](https://www.zdnet.com/education/get-lifetime-access-to-a-comptia-course-bundle-for-just-50/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T15:45:20+00:00

Access 13 courses and learn CompTIA fundamentals with this bundle through Oct. 15.

## My new favorite desk charger for all my Apple devices is $50 off right now
 - [https://www.zdnet.com/home-and-office/my-new-favorite-desk-charger-for-all-my-apple-devices-is-50-off-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/my-new-favorite-desk-charger-for-all-my-apple-devices-is-50-off-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T14:01:06+00:00

It's powerful enough to keep my MacBook Pro topped up, offers fast wireless charging for the iPhone, and has plenty of ports to spare.

## Learn a new language with this Babbel deal
 - [https://www.zdnet.com/education/learn-a-new-language-with-this-babbel-deal/#ftag=RSSbaffb68](https://www.zdnet.com/education/learn-a-new-language-with-this-babbel-deal/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T14:00:26+00:00

Score premium lessons on 14 languages with a discounted lifetime Babbel subscription.

## Save on holiday travel now with a lifetime subscription to Dollar Flight Club
 - [https://www.zdnet.com/article/save-on-holiday-travel-now-with-a-lifetime-subscription-to-dollar-flight-club/#ftag=RSSbaffb68](https://www.zdnet.com/article/save-on-holiday-travel-now-with-a-lifetime-subscription-to-dollar-flight-club/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T12:30:26+00:00

Don't worry about how you're going to afford the trips you want to take. Dollar Flight Club can help you find much cheaper flights.

## Want to join Costco? Buy a membership and get a free $30 gift card right now
 - [https://www.zdnet.com/home-and-office/home-entertainment/want-to-join-costco-buy-a-membership-and-get-a-free-30-gift-card-right-now/#ftag=RSSbaffb68](https://www.zdnet.com/home-and-office/home-entertainment/want-to-join-costco-buy-a-membership-and-get-a-free-30-gift-card-right-now/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T10:30:26+00:00

Get more for your money by shopping at any of the 500-plus Costco stores across the US. This deal effectively gets you half-off an annual Gold Star Costco membership.

## Google Home will get a generative AI boost, too
 - [https://www.zdnet.com/article/google-home-will-get-a-generative-ai-boost-too/#ftag=RSSbaffb68](https://www.zdnet.com/article/google-home-will-get-a-generative-ai-boost-too/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T09:50:33+00:00

Let the Google Home app act as your personal security guard that you can carry in your pocket.

## Customized test benchmarks and openness crucial as generative AI models evolve
 - [https://www.zdnet.com/article/customized-test-benchmarks-and-openness-crucial-as-generative-ai-models-evolve/#ftag=RSSbaffb68](https://www.zdnet.com/article/customized-test-benchmarks-and-openness-crucial-as-generative-ai-models-evolve/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T09:24:58+00:00

Benchmarks for large language models and openness within the industry will be critical to business success.

## How to enable Studio Light in MacOS Sonoma Facetime to get the best look from your lighting
 - [https://www.zdnet.com/article/how-to-enable-studio-light-in-macos-sonoma-facetime-to-get-the-best-look-from-your-lighting/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-enable-studio-light-in-macos-sonoma-facetime-to-get-the-best-look-from-your-lighting/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T08:13:48+00:00

To get the best light for your FaceTime calls, you'll want to turn to Studio Light. Here's how it's used on MacOS Sonoma.

## How to use Bing Image Creator (and why it's better than ever)
 - [https://www.zdnet.com/article/how-to-use-bing-image-creator/#ftag=RSSbaffb68](https://www.zdnet.com/article/how-to-use-bing-image-creator/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T07:36:00+00:00

It's free, there's no waitlist, and you don't even need to use Edge to access it. Here's everything else you need to know to get started using Microsoft's AI art generator.

## Humanizing technology: The 100-year legacy of Steve Jobs
 - [https://www.zdnet.com/article/humanizing-technology-the-100-year-legacy-of-steve-jobs/#ftag=RSSbaffb68](https://www.zdnet.com/article/humanizing-technology-the-100-year-legacy-of-steve-jobs/#ftag=RSSbaffb68)
 - RSS feed: http://www.zdnet.com/news/rss.xml
 - date published: 2023-10-06T00:16:26.051362+00:00

On the 12th anniversary of the passing of Steve Jobs, we're republishing this essay from Oct. 5, 2011 on the powerful legacy Jobs left not just for Apple but for the broader tech industry and humanity

