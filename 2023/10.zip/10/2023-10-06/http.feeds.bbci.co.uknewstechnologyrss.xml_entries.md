# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Tweet saying FTX was "fine" was false, court hears
 - [https://www.bbc.co.uk/news/business-67035976?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67035976?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-10-06T21:01:35+00:00

The FTX co-founder tells court that Sam Bankman-Fried's public claims about FTX did not match reality.

## Snap might have to withdraw its AI chatbot, watchdog says
 - [https://www.bbc.co.uk/news/technology-67027282?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67027282?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-10-06T13:37:12+00:00

The UK's data watchdog has raised concerns the My AI tool may be a risk to children’s privacy.

## Windsor crossbow case: What are the dangers of AI chatbots?
 - [https://www.bbc.co.uk/news/technology-67012224?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-67012224?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-10-06T11:17:59+00:00

The case of Jaswant Singh Chail raises questions about the safety of AI-powered chatbots.

