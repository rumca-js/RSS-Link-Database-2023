# Source:Latest News from Science Magazine, URL:https://www.science.org/rss/news_current.xml, language:en-US

## Should you pick Novavax’s COVID-19 shot over mRNA options?
 - [https://www.science.org/content/article/should-you-pick-novavax-s-covid-19-shot-over-mrna-options](https://www.science.org/content/article/should-you-pick-novavax-s-covid-19-shot-over-mrna-options)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-10-06T22:33:10.153238+00:00

Limited data and lack of head-to-head studies make comparisons tricky

## Meet the world’s least picky insect—a spreader of deadly crop disease
 - [https://www.science.org/content/article/meet-world-least-picky-insect-spreader-deadly-crop-disease](https://www.science.org/content/article/meet-world-least-picky-insect-spreader-deadly-crop-disease)
 - RSS feed: https://www.science.org/rss/news_current.xml
 - date published: 2023-10-06T17:32:47.416587+00:00

Spittlebugs munch on more than 1300 species of plants, the broadest insect diet yet seen

