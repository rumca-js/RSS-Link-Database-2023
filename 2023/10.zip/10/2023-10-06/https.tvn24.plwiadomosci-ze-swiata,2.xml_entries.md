# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## "Ludzie, którzy głosują na PiS, tego absolutnie nie rozumieją"
 - [https://tvn24.pl/wybory-parlamentarne-2023/jaroslaw-kaczynski-odmowil-udzialu-w-debacie-tvp-dariusz-jonski-ludzie-ktorzy-glosuja-na-pis-tego-absolutnie-nie-rozumieja-7379132?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/jaroslaw-kaczynski-odmowil-udzialu-w-debacie-tvp-dariusz-jonski-ludzie-ktorzy-glosuja-na-pis-tego-absolutnie-nie-rozumieja-7379132?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-10-06T20:19:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-doj1xu-06-2000-bez-kitu-cl-0003-7379173/alternates/LANDSCAPE_1280" />
    Jarosław Kaczyński ucieka nie tylko przed Donaldem Tuskiem, ale także przed Szymonem Hołownią i innymi politykami opozycji - mówił w "Kampanii #BezKitu" Jan Strzeżek (Trzecia Droga), komentując decyzję prezesa PiS o tym, by nie uczestniczyć w debacie organizowanej przez TVP. - Ludzie, którzy głosują na PiS, tego absolutnie nie rozumieją. Twierdzą, że to jest niezrozumiałe - stwierdził Dariusz Joński (Koalicja Obywatelska).

## Jak chronić dzieci przed zagrożeniami w internecie, w tym pedofilami? Eksperci radzą
 - [https://fakty.tvn24.pl/fakty-o-swiecie/jak-chronic-dzieci-przed-zagrozeniami-w-internecie-w-tym-pedofilami-eksperci-radza-7379233?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/jak-chronic-dzieci-przed-zagrozeniami-w-internecie-w-tym-pedofilami-eksperci-radza-7379233?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-10-06T20:18:12+00:00

<img alt="Jak chronić dzieci przed zagrożeniami w internecie, w tym pedofilami? Eksperci radzą" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-gcgyli-fos-zuber-7379235/alternates/LANDSCAPE_1280" />
    Opinią publiczną wstrząsnęły ostatnio wiadomości o czynach pedofilskich, których mieli się dopuścić polscy youtuberzy, bardzo popularni wśród młodych internautów. Trwa śledztwo w tej sprawie, ale przestępcze działania wobec młodych ludzi, których początkiem jest nawiązywanie kontaktów przez internet, to problem widziany już wcześniej w wielu krajach na świecie. Dlatego warto przypomnieć, jak można ochronić najmłodszych użytkowników sieci przed obecnymi tam zagrożeniami.

## Ed Sheeran zbudował sobie za domem grobowiec. Wyjaśnia dlaczego
 - [https://tvn24.pl/kultura-i-styl/ed-sheeran-zbudowal-sobie-za-domem-grobowiec-wyjasnia-dlaczego-7378466?source=rss](https://tvn24.pl/kultura-i-styl/ed-sheeran-zbudowal-sobie-za-domem-grobowiec-wyjasnia-dlaczego-7378466?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-10-06T13:51:24+00:00

<img alt="Ed Sheeran zbudował sobie za domem grobowiec. Wyjaśnia dlaczego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-og5k2j-ed-sheeran-7378634/alternates/LANDSCAPE_1280" />
    Ed Sheeran zbudował na podwórku za swoim domem kaplicę. Budynek służyć ma przede wszystkim jako rodzinny grobowiec. - Kiedy przyjdzie mój czas i odejdę, zostanę tam pochowany - mówi brytyjski piosenkarz.

