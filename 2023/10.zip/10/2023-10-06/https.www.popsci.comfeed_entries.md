# Source:Popular Science, URL:https://www.popsci.com/feed, language:en-US

## Disease plagues Tasmanian devils—except for on one island
 - [https://www.popsci.com/environment/tasmanian-devil-cancer/](https://www.popsci.com/environment/tasmanian-devil-cancer/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T22:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The Tasmanian devils that live on Maria Island in Tasmania, Australia, are the hope of the entire species. " class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/04/Depositphotos_7230551_L-1.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">The Tasmanian devils that live on Maria Island in Tasmania, Australia, are the hope of the entire species. <span class="orgnc-SingleImage-credit">DepositPhotos</span></figcaption></figure><p>There are three known wild contagious cancers in vertebrates, and Tasmanian devils have two of them. What does that mean for the endangered marsupials?</p>
<p>The post <a href="https://www.popsci

## How horror movie soundtracks prey on our fears
 - [https://www.popsci.com/science/horror-movie-soundtracks-psychology/](https://www.popsci.com/science/horror-movie-soundtracks-psychology/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T19:10:04+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A movie still from &#039;Psycho,&#039; showing the silhouette of a man holding a knife." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="932" src="https://www.popsci.com/uploads/2023/10/06/psycho-hitchcock-horror-movie-scary-music.jpg?auto=webp&amp;width=1440&amp;height=932.4" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Bernard Herrmann's shrieking score to 'Psycho' remains a touchstone for modern horror soundtracks. <span class="orgnc-SingleImage-credit">Sunset Boulevard/Corbis via Getty Images</span></figcaption></figure><p>The best spine-chilling scores use several psychological and musical tricks to entertain.</p>
<p>The post <a href="https://www.popsci.com/science/horror-movie-soundtracks-psychol

## Watch robot dogs train on obstacle courses to avoid tripping
 - [https://www.popsci.com/technology/dog-robot-vine-course/](https://www.popsci.com/technology/dog-robot-vine-course/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T18:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Better navigation of complex environments could help robots walk in the wild." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/Screen-Shot-2023-10-06-at-4.47.22-PM.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Better navigation of complex environments could help robots walk in the wild. <span class="orgnc-SingleImage-credit"><a href="https://www.youtube.com/watch?v=aM3qdtm1Ets&amp;ab_channel=RobomechanicsLab">Carnegie Mellon University</a></span></figcaption></figure><p>Four legged robots have a tough time traipsing through heavy vegetation, but a new stride pattern could help.</p>
<p>The post <a href="https

## Save up to $50 on Govee smart lighting during this early Amazon Prime Day sale
 - [https://www.popsci.com/gear/govee-smart-lighting-deal-amazon-prime-day-2023/](https://www.popsci.com/gear/govee-smart-lighting-deal-amazon-prime-day-2023/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T17:55:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Govee RGB strip lights tiled" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/GOVEE-SMART-LIGHTS-DEAL.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stan Horaczek</span></figcaption></figure><p>The best LED strip lights are getting the early Prime Day treatment in the form of very solid discounts across the board.</p>
<p>The post <a href="https://www.popsci.com/gear/govee-smart-lighting-deal-amazon-prime-day-2023/" rel="nofollow">Save up to $50 on Govee smart lighting during this early Amazon Prime Day sale</a> appeared first on <a href="https://www.popsci.com" rel="nofo

## Moon-bound Artemis III spacesuits have some functional luxury sewn in
 - [https://www.popsci.com/science/artemis-prada-spacesuit/](https://www.popsci.com/science/artemis-prada-spacesuit/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T16:30:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Close up of Axiom Space Prada lunar spacesuit glove" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/COM_AxEMUStudioShoot_20230621_DGB_AXP00649-2-1.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Astronauts will wear the spacesuits during humanity's first moonwalk in over 50 years. <span class="orgnc-SingleImage-credit"><a href="https://www.axiomspace.com/news/prada-axiom-suit">Axiom Space</a></span></figcaption></figure><p>NASA meets Prada.</p>
<p>The post <a href="https://www.popsci.com/science/artemis-prada-spacesuit/" rel="nofollow">Moon-bound Artemis III spacesuits have some functional luxury sewn in</a> 

## Make a classic pinhole camera to watch the upcoming solar eclipse
 - [https://www.popsci.com/diy/how-to-make-a-pinhole-camera/](https://www.popsci.com/diy/how-to-make-a-pinhole-camera/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T16:19:21+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A cardboard pinhole camera to watch an eclipse" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/how-to-make-pinhole-camera-eclipse.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Listen, we know this is not the most sophisticated-looking artifact, but it does a great job at protecting your eyes when you want to look at the sun. <span class="orgnc-SingleImage-credit">Sandra Gutierrez</span></figcaption></figure><p>This DIY projector might be the easiest you ever build.</p>
<p>The post <a href="https://www.popsci.com/diy/how-to-make-a-pinhole-camera/" rel="nofollow">Make a classic pinhole camera to watch the upc

## A newly discovered sauropod dinosaur left behind some epic footprints
 - [https://www.popsci.com/science/garumbatitan-morellensis-dinosaur/](https://www.popsci.com/science/garumbatitan-morellensis-dinosaur/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T15:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Evolution photo" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/spain-sauropod-dig.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div></figure><p>Garumbatitan morellensis' vertebrae alone were nearly 3 feet wide.</p>
<p>The post <a href="https://www.popsci.com/science/garumbatitan-morellensis-dinosaur/" rel="nofollow">A newly discovered sauropod dinosaur left behind some epic footprints</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

## The world’s most powerful computer could soon help the US build better nuclear reactors
 - [https://www.popsci.com/technology/argonne-exascale-supercomputer-nuclear-reactor/](https://www.popsci.com/technology/argonne-exascale-supercomputer-nuclear-reactor/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T14:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="aurora supercomputer at Argonne" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/Aurora_front.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Argonne National Laboratory</span></figcaption></figure><p>Here’s how engineers will use it to model the complex physics inside the heart of a nuclear power plant. </p>
<p>The post <a href="https://www.popsci.com/technology/argonne-exascale-supercomputer-nuclear-reactor/" rel="nofollow">The world&#8217;s most powerful computer could soon help the US build better nuclear reactors</a> appeared first on <a href="https://www.popsci.com"

## USDA bans French poultry imports over avian influenza vaccine
 - [https://www.popsci.com/health/usda-france-avian-influenza-vaccine/](https://www.popsci.com/health/usda-france-avian-influenza-vaccine/)
 - RSS feed: https://www.popsci.com/feed
 - date published: 2023-10-06T13:00:00+00:00

<figure class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A pair of chickens at a poultry farm. Bird flu has been detected in at least 67 countries." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/10/06/avian-influenza-vaccine-ban.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><figcaption class="orgnc-SingleImage-caption">Bird flu has been detected in at least 67 countries. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/chickens-on-traditional-free-range-poultry-farm-165158270.html">Deposit Photos</a></span></figcaption></figure><p>The ban comes after France begins Europe’s only mass-vaccination campaign against bird flu.</p>
<p>The post <a href="https://www.popsci.com/health/usda-fr

