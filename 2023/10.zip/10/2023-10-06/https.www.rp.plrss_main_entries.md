# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Orbán: Bruksela legalnie zgwałciła Polskę i Węgry, naruszając pakt migracyjny
 - [https://www.rp.pl/polityka/art39232201-orban-bruksela-legalnie-zgwalcila-polske-i-wegry-naruszajac-pakt-migracyjny](https://www.rp.pl/polityka/art39232201-orban-bruksela-legalnie-zgwalcila-polske-i-wegry-naruszajac-pakt-migracyjny)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T21:39:00+00:00

Nie będzie żadnego kompromisu w sprawie migracji. Ani dzisiaj, ani w nadchodzących latach. Będziemy bronić naszych granic przed migrantami i brukselskimi biurokratami! - powiedział w nagraniu w mediach społecznościowych węgierski premier Viktor Orbán.

## Korea Północna dostarcza Rosji artylerię. USA Ukrainie - irańskie pociski
 - [https://www.rp.pl/konflikty-zbrojne/art39232181-korea-polnocna-dostarcza-rosji-artylerie-usa-ukrainie-iranskie-pociski](https://www.rp.pl/konflikty-zbrojne/art39232181-korea-polnocna-dostarcza-rosji-artylerie-usa-ukrainie-iranskie-pociski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T21:33:00+00:00

Korea Północna dostarcza Rosji artylerię na wojnę na Ukrainie, podczas gdy Stany Zjednoczone przekazują Kijowowi amunicję skonfiskowaną od Iranu - informuje CBS News.

## Po zwycięstwie Fico Słowacja wstrzymuje pomoc wojskową dla Ukrainy
 - [https://www.rp.pl/polityka/art39232121-po-zwyciestwie-fico-slowacja-wstrzymuje-pomoc-wojskowa-dla-ukrainy](https://www.rp.pl/polityka/art39232121-po-zwyciestwie-fico-slowacja-wstrzymuje-pomoc-wojskowa-dla-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T20:40:00+00:00

Rząd tymczasowy Słowacji oświadczył, że wstrzymał wysyłanie dalszej pomocy wojskowej na Ukrainę, ponieważ rozmowy w sprawie utworzenia koalicji  rządzącej prowadzą partie polityczne sprzeciwiające się takiemu wsparciu.

## Rosyjski atak na Hrozę. Zginęła pracowniczka Polskiej Akcji Humanitarnej
 - [https://www.rp.pl/konflikty-zbrojne/art39232081-rosyjski-atak-na-hroze-zginela-pracowniczka-polskiej-akcji-humanitarnej](https://www.rp.pl/konflikty-zbrojne/art39232081-rosyjski-atak-na-hroze-zginela-pracowniczka-polskiej-akcji-humanitarnej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T20:01:00+00:00

Podczas rosyjskiego ataku na wieś Hroza w obwodzie charkowskim zginęły 52 osoby. Wśród nich - pracownica Polskiej Akcji Humanitarnej.

## Putin mści się na martwym, czyli co zabiło Jewgienija Prigożyna
 - [https://www.rp.pl/konflikty-zbrojne/art39230471-putin-msci-sie-na-martwym-czyli-co-zabilo-jewgienija-prigozyna](https://www.rp.pl/konflikty-zbrojne/art39230471-putin-msci-sie-na-martwym-czyli-co-zabilo-jewgienija-prigozyna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T18:48:11+00:00

Rosyjski prezydent zasugerował, że szefowie Grupy Wagnera w trakcie lotu samolotem sami się pozabijali w narkotycznym transie.

## Sondaż. Tylko cztery partie w Sejmie. Jedna piąta Polaków niezdecydowana
 - [https://www.rp.pl/wybory/art39231231-sondaz-tylko-cztery-partie-w-sejmie-jedna-piata-polakow-niezdecydowana](https://www.rp.pl/wybory/art39231231-sondaz-tylko-cztery-partie-w-sejmie-jedna-piata-polakow-niezdecydowana)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T18:37:00+00:00

Na dziesięć dni przed wyborami w sondażach wciąż prowadzi Prawo i Sprawiedliwość. W ciągu miesiąca o 6 pkt. proc. wzrósł odsetek niezdecydowanych. Sondaż pracowni Opinia24 dla "Gazety Wyborczej".

## Praworządności mogą zagrażać ludzie i komputerowe algorytmy
 - [https://www.rp.pl/sady-i-trybunaly/art39231921-praworzadnosci-moga-zagrazac-ludzie-i-komputerowe-algorytmy](https://www.rp.pl/sady-i-trybunaly/art39231921-praworzadnosci-moga-zagrazac-ludzie-i-komputerowe-algorytmy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T18:01:57+00:00

Prawo może być narzędziem niszczenia praworządności, jeśli jest wprowadzane i stosowane ze złą wolą – twierdzili prawnicy zgromadzeni na międzynarodowej konferencji Federacji Adwokatur Europejskich w Gdańsku.

## Od jazzmanów do żołnierzy Legii Cudzoziemskiej. Na co wybrać się do kina?
 - [https://www.rp.pl/film/art39230861-od-jazzmanow-do-zolnierzy-legii-cudzoziemskiej-na-co-wybrac-sie-do-kina](https://www.rp.pl/film/art39230861-od-jazzmanow-do-zolnierzy-legii-cudzoziemskiej-na-co-wybrac-sie-do-kina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T17:49:32+00:00

Dwa bardzo różne dokumenty: „Na zawsze Melomani” i „Adamant” i dwa bardzo różne filmy: „Święto Ognia” i „Disco Boy”. Każdy może znaleźć coś dla siebie

## Piłkarze Legii Warszawa zwolnieni z aresztu w Alkmaar
 - [https://www.rp.pl/pilka-nozna/art39231241-pilkarze-legii-warszawa-zwolnieni-z-aresztu-w-alkmaar](https://www.rp.pl/pilka-nozna/art39231241-pilkarze-legii-warszawa-zwolnieni-z-aresztu-w-alkmaar)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T17:36:00+00:00

Radovan Pankov i Josue zostali zwolnieni z aresztu w Alkmaar- poinformował w mediach społecznościowych klub Legia Warszawa.

## Inwestorzy przestali wierzyć w Nestle, przez nowy lek na otyłość
 - [https://www.rp.pl/przemysl-spozywczy/art39231821-inwestorzy-przestali-wierzyc-w-nestle-przez-nowy-lek-na-otylosc](https://www.rp.pl/przemysl-spozywczy/art39231821-inwestorzy-przestali-wierzyc-w-nestle-przez-nowy-lek-na-otylosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T17:29:02+00:00

Akcje Nestle znalazły się w piątek pod presją, ponieważ inwestorzy rozważali potencjalny wpływ popularnego leku odchudzającego Wegovy firmy Novo Nordisk i tego, jak mógłby on zmniejszyć wydatki na żywność, a zwłaszcza słodycze.

## Konkurs Chopinowski: Niespodziewany przyjazd Marthy Argerich
 - [https://www.rp.pl/muzyka-klasyczna/art39230731-konkurs-chopinowski-niespodziewany-przyjazd-marthy-argerich](https://www.rp.pl/muzyka-klasyczna/art39230731-konkurs-chopinowski-niespodziewany-przyjazd-marthy-argerich)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T17:21:52+00:00

82-letnia Martha Argerich pojawiła się bez zapowiedzi na koncercie inauguracyjnym Konkursu Chopinowskiego na Instrumentach Historycznych i zagrała tak, że entuzjazm słuchaczy niemal rozsadził salę Filharmonii Narodowej.

## El Niño winduje ceny cukru. Od 13 lat nie było tak drogo
 - [https://www.rp.pl/przemysl-spozywczy/art39231171-el-nino-winduje-ceny-cukru-od-13-lat-nie-bylo-tak-drogo](https://www.rp.pl/przemysl-spozywczy/art39231171-el-nino-winduje-ceny-cukru-od-13-lat-nie-bylo-tak-drogo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T17:02:58+00:00

El Niño powoduje upały i suszę w niektórych regionach świata, a ulewne deszcze w innych. Produkcja cukru cierpi, głównie w Indiach i Tajlandii. Wysokie ceny ropy naftowej powodują również wzrost cen cukru do najwyższego poziomu od wielu lat.

## Wypadek na zlocie supersamochodów na Sardynii. Małżeństwo spłonęło w Ferrari
 - [https://moto.rp.pl/tu-i-teraz/art39228311-wypadek-na-zlocie-supersamochodow-na-sardynii-malzenstwo-splonelo-w-ferrari](https://moto.rp.pl/tu-i-teraz/art39228311-wypadek-na-zlocie-supersamochodow-na-sardynii-malzenstwo-splonelo-w-ferrari)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:57:08+00:00

Koszmarny wypadek miał miejsce na trasie przejazdu zlotu supersamochodów. Nagranych zostało kilka sportowych aut, które wyprzedzają na linii ciągłej. Chwilę później zarejestrowany został moment zdarzenia Lamborghini z Ferrari i kampera, który wywraca się na bok.

## Gwiazdy „Znachora” mają już swoje plany. Nowe produkcje z Marią Kowalską i Leszkiem Lichotą
 - [https://www.rp.pl/film/art39230241-gwiazdy-znachora-maja-juz-swoje-plany-nowe-produkcje-z-maria-kowalska-i-leszkiem-lichota](https://www.rp.pl/film/art39230241-gwiazdy-znachora-maja-juz-swoje-plany-nowe-produkcje-z-maria-kowalska-i-leszkiem-lichota)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:46:12+00:00

„Znachor” zawsze lansował gwiazdy lub czynił je jeszcze sławniejszymi. Sukces produkcji Netfliksa sprawia, że nabiorą rozpędu kariery Leszka Lichoty i Marii Kowalskiej, grających profesora Wilczura i jego córkę.

## Dziennik Ustaw z 6 października 2023 (2142-2155)
 - [https://www.rp.pl/akty-prawne/art39230721-dziennik-ustaw-z-6-pazdziernika-2023-2142-2155](https://www.rp.pl/akty-prawne/art39230721-dziennik-ustaw-z-6-pazdziernika-2023-2142-2155)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:32:12+00:00



## Monitor Polski z 6 października 2023 (1073-1081)
 - [https://www.rp.pl/akty-prawne/art39230711-monitor-polski-z-6-pazdziernika-2023-1073-1081](https://www.rp.pl/akty-prawne/art39230711-monitor-polski-z-6-pazdziernika-2023-1073-1081)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:27:57+00:00



## Dolar znów zyskuje do euro i złotego
 - [https://www.rp.pl/waluty/art39230451-dolar-znow-zyskuje-do-euro-i-zlotego](https://www.rp.pl/waluty/art39230451-dolar-znow-zyskuje-do-euro-i-zlotego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:22:13+00:00

Po lepszych od oczekiwań danych z amerykańskiego rynku pracy, dolar zyskuje do euro i złotego.

## Po meczu Legia - Alkmaar. Holandia przedstawia własną wersję wydarzeń. MSZ wzywa ambasadorkę Królestwa Niderlandów
 - [https://www.rp.pl/pilka-nozna/art39230111-po-meczu-legia-alkmaar-holandia-przedstawia-wlasna-wersje-wydarzen-msz-wzywa-ambasadorke-krolestwa-niderlandow](https://www.rp.pl/pilka-nozna/art39230111-po-meczu-legia-alkmaar-holandia-przedstawia-wlasna-wersje-wydarzen-msz-wzywa-ambasadorke-krolestwa-niderlandow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:14:00+00:00

W związku z incydentem po meczu Legii Warszawa  w Alkmaar i zatrzymaniu dwóch piłkarzy klubu, Ministerstwo Spraw Zagranicznych wezwało ambasador Królestwa Niderlandów Daphne Bergsma.

## Miejskie pamiątki: Designerskie i niebanalne? Najlepsze są tradycyjne
 - [https://regiony.rp.pl/z-regionow/art39230371-miejskie-pamiatki-designerskie-i-niebanalne-najlepsze-sa-tradycyjne](https://regiony.rp.pl/z-regionow/art39230371-miejskie-pamiatki-designerskie-i-niebanalne-najlepsze-sa-tradycyjne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:12:08+00:00

Maskotka smoka wawelskiego z Krakowa, krasnal z Wrocławia, jelonek z Jeleniej Góry, a może pluszowa gęś Pipa - hit tegorocznych wakacji? Jakich pamiątek szukają turyści?

## Wszczęto śledztwo ws. zaginięcia sprzed 23 lat. Archiwum X podejrzewa zabójstwo
 - [https://www.rp.pl/prawo-karne/art39230281-wszczeto-sledztwo-ws-zaginiecia-sprzed-23-lat-archiwum-x-podejrzewa-zabojstwo](https://www.rp.pl/prawo-karne/art39230281-wszczeto-sledztwo-ws-zaginiecia-sprzed-23-lat-archiwum-x-podejrzewa-zabojstwo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T16:05:02+00:00

Po 23 latach rodzina zdecydowała się na złożenie zawiadomienia o podejrzeniu popełnienia przestępstwa.

## Szułdrzyński: Witaminowe koktajle – jak uciec z ciała
 - [https://www.rp.pl/plus-minus/art39230261-szuldrzynski-witaminowe-koktajle-jak-uciec-z-ciala](https://www.rp.pl/plus-minus/art39230261-szuldrzynski-witaminowe-koktajle-jak-uciec-z-ciala)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:49:14+00:00

Skoro nie możemy sprawić, by nasze ciało nie umarło, może trzeba z niego uciec?

## Kataryna: „Reset” jest gorszym paszkwilem niż „Zielona granica”
 - [https://www.rp.pl/plus-minus/art39230231-kataryna-reset-jest-gorszym-paszkwilem-niz-zielona-granica](https://www.rp.pl/plus-minus/art39230231-kataryna-reset-jest-gorszym-paszkwilem-niz-zielona-granica)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:40:28+00:00

Jarosław Kaczyński: „Oni zostali tam przedstawieni – i znów nie ma innego słowa, trzeba powiedzieć: haniebnie. To jest paszkwil. Odrażający, obrzydliwy paszkwil. Murem za polskim mundurem. To mówimy my”.

## Robert Mazurek: Sposób na istnienie
 - [https://www.rp.pl/plus-minus/art39230221-robert-mazurek-sposob-na-istnienie](https://www.rp.pl/plus-minus/art39230221-robert-mazurek-sposob-na-istnienie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:36:08+00:00

Cisza wyborcza powinna trwać dwa tygodnie. Albo dwa miesiące, im dłużej, tym lepiej. Dlatego dziś nic o wyborach, ale z polityką jak z teściową w kiepskich kabaretach – nie uciekniesz od niej.

## Generacja Z ma dość życia w stresie i presji. „Snail Girl” to nowy wzorzec
 - [https://sukces.rp.pl/spoleczenstwo/art39228611-generacja-z-ma-dosc-zycia-w-stresie-i-presji-snail-girl-to-nowy-wzorzec](https://sukces.rp.pl/spoleczenstwo/art39228611-generacja-z-ma-dosc-zycia-w-stresie-i-presji-snail-girl-to-nowy-wzorzec)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:34:12+00:00

Generacja Z wymyśliła oryginalną nazwę na potrzebę starą jak świat. Zjawisko określane jako „snail girl” robi furorę wśród młodych kobiet, które mają dość pogoni za deadline'ami i życia w stresie.

## Wojciech Tumidalski: Zmarnowana szansa Sądu Najwyższego
 - [https://www.rp.pl/opinie-prawne/art39229821-wojciech-tumidalski-zmarnowana-szansa-sadu-najwyzszego](https://www.rp.pl/opinie-prawne/art39229821-wojciech-tumidalski-zmarnowana-szansa-sadu-najwyzszego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:34:04+00:00

Członkowie Izby Kontroli Nadzwyczajnej i Spraw Publicznych nie skorzystali z szansy uwiarygodnienia się w oczach opinii publicznej i przeszli do porządku dziennego nad tym, że udział w referendum grozi naruszeniem zasady tajności głosowania.

## Wina Mazurka: Kamień gładzony
 - [https://www.rp.pl/krotkie-formy/art39230201-wina-mazurka-kamien-gladzony](https://www.rp.pl/krotkie-formy/art39230201-wina-mazurka-kamien-gladzony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:33:28+00:00

Ostatecznie pozostają tylko dwie istoty: Bóg i wino – rozpoczyna swoją „Filozofię wina” wielki Béla Hamvas, przekonując, że będzie pisał o Bogu, używając słowa wino, bo na jedno wychodzi.

## Paweł Konzal: Granice wyobraźni patriotycznej
 - [https://www.rp.pl/plus-minus/art39230161-pawel-konzal-granice-wyobrazni-patriotycznej](https://www.rp.pl/plus-minus/art39230161-pawel-konzal-granice-wyobrazni-patriotycznej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:30:26+00:00

Niekompletność opowieści o Piłsudskim i Dmowskim widać wyraźnie podczas obchodów Święta Niepodległości, kiedy razi brak refleksji nad postawami obydwu protagonistów.

## Członkowie RPP przepraszają za słowa prezesa NBP Adama Glapińskiego
 - [https://www.rp.pl/banki/art39230141-czlonkowie-rpp-przepraszaja-za-slowa-prezesa-nbp-adama-glapinskiego](https://www.rp.pl/banki/art39230141-czlonkowie-rpp-przepraszaja-za-slowa-prezesa-nbp-adama-glapinskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:29:21+00:00

Ludwik Kotecki, członek Rady Polityki Pieniężnej, przeprosił osoby, które poczuły się urażone wypowiedziami szefa RPP, Adama Glapińskiego. Kontrowersyjne słowa padły podczas czwartkowej konferencji prasowej. Nie jest on jedynym członkiem rady, który publicznie przeprasza.

## Sarmacki diabeł już wystarczająco objadł się polską duszą
 - [https://www.rp.pl/plus-minus/art39230151-sarmacki-diabel-juz-wystarczajaco-objadl-sie-polska-dusza](https://www.rp.pl/plus-minus/art39230151-sarmacki-diabel-juz-wystarczajaco-objadl-sie-polska-dusza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:26:21+00:00

Kiedy była na to szansa, nie zrobiliśmy nic, albo bardzo niewiele, by zwalczyć uśpionego chwilowo sarmackiego diabła wypasionego na tak bliskiej polskiej duszy romantycznej mistyce. Teraz jest za późno.

## Gagarin nie mógł zadzwonić tylko do żony, bo nie miała telefonu
 - [https://www.rp.pl/plus-minus/art39230131-gagarin-nie-mogl-zadzwonic-tylko-do-zony-bo-nie-miala-telefonu](https://www.rp.pl/plus-minus/art39230131-gagarin-nie-mogl-zadzwonic-tylko-do-zony-bo-nie-miala-telefonu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:22:31+00:00

Chruszczow zakończył rozmowę. „Do widzenia, drogi Nikito Siergiejewiczu” – odpowiedział Gagarin i też odłożył słuchawkę. Właśnie zaprzyjaźnił się z najpotężniejszym człowiekiem w ZSRR. Uśmiechnął się i był to naprawdę szeroki uśmiech.

## Franciszek Stefaniuk: PSL nie wyszedł dobrze na żadnej koalicji
 - [https://www.rp.pl/plus-minus/art39229691-franciszek-stefaniuk-psl-nie-wyszedl-dobrze-na-zadnej-koalicji](https://www.rp.pl/plus-minus/art39229691-franciszek-stefaniuk-psl-nie-wyszedl-dobrze-na-zadnej-koalicji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:16:45+00:00

Dzisiaj, kiedy trwa walka wielkich partii o to, żeby na scenie politycznej pozostały tylko dwa bloki, ci mniejsi znowu są „zgniatani” z obu stron, aby nie mieli racji bytu. Ale jeżeli będą tylko dwa bloki, to żegnaj, demokracjo, bo wtedy przejdziemy do rządów monopartyjnych. Rozmowa z Franciszkiem Stefaniukiem, posłem PSL od 1989 do 2015 roku

## Debata jest ryzykiem i dla Tuska i dla Morawieckiego. "Tusk wystawia się na ostrzał"
 - [https://www.rp.pl/wybory/art39230011-debata-jest-ryzykiem-i-dla-tuska-i-dla-morawieckiego-tusk-wystawia-sie-na-ostrzal](https://www.rp.pl/wybory/art39230011-debata-jest-ryzykiem-i-dla-tuska-i-dla-morawieckiego-tusk-wystawia-sie-na-ostrzal)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:07:22+00:00

Czy udział w debacie w TVP jest ryzykiem dla Donalda Tuska? Dlaczego PiS zmienia taktykę wobec PSL? Co nas czeka w finałowym tygodniu kampanii wyborczej? O tym w podkaście "Polityczne Michałki" rozmawiali Michał Kolanko i Michał Szułdrzyński.

## Marek Isański: Kiedy NSA zacznie stosować Konstytucję
 - [https://www.rp.pl/opinie-prawne/art39229991-marek-isanski-kiedy-nsa-zacznie-stosowac-konstytucje](https://www.rp.pl/opinie-prawne/art39229991-marek-isanski-kiedy-nsa-zacznie-stosowac-konstytucje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:05:48+00:00

Z analizy orzecznictwa w sprawach podatkowych wynika, że NSA do dziś nie zauważył zmiany ustroju Rzeczpospolitej, która nastąpiła dokładnie 26 lat temu. Weszła bowiem w życie Konstytucja dająca obywatelom pełnię praw. W tym prawo do dobrego prawa. Wyroki sądowe nadal chronią instytucje a nie obywateli, zachęcają ustawodawcę do tworzenia złego/coraz gorszego prawa, akceptują wiele patologii w działaniu administracji, ignorują prawa obywateli. Klasa polityczna tego nie widzi i nie reaguje.

## Morawiecki w imieniu Polski odrzuca paragraf konkluzji szczytu RE dotyczący migracji
 - [https://www.rp.pl/polityka/art39230121-morawiecki-w-imieniu-polski-odrzuca-paragraf-konkluzji-szczytu-re-dotyczacy-migracji](https://www.rp.pl/polityka/art39230121-morawiecki-w-imieniu-polski-odrzuca-paragraf-konkluzji-szczytu-re-dotyczacy-migracji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:03:00+00:00

"Jako odpowiedzialny polityk oficjalnie ODRZUCAM cały paragraf konkluzji szczytu dotyczący migracji. Polska jest i pozostanie bezpieczna pod rządami Prawa i Sprawiedliwości!" - napisał szef rządu na Facebooku.

## Bogusław Chrabota: Krótkowzroczność wobec Ukrainy
 - [https://www.rp.pl/plus-minus/art39226831-boguslaw-chrabota-krotkowzrocznosc-wobec-ukrainy](https://www.rp.pl/plus-minus/art39226831-boguslaw-chrabota-krotkowzrocznosc-wobec-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Brutalna wojna Putina staje się mitem założycielskim nowej Ukrainy. Buduje nowy patriotyzm i nowy nacjonalizm. Byłoby bardzo źle, gdyby wskutek nieodpowiedzialności polityków obrócić tę mentalność przeciwko Polsce.

## Chińczykom nie smakują polskie jabłka, ale trzymają się mocno w Egipcie
 - [https://www.rp.pl/plus-minus/art39229391-chinczykom-nie-smakuja-polskie-jablka-ale-trzymaja-sie-mocno-w-egipcie](https://www.rp.pl/plus-minus/art39229391-chinczykom-nie-smakuja-polskie-jablka-ale-trzymaja-sie-mocno-w-egipcie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Jabłko z wieczora… – zaczyna się popularne powiedzenie, ale dokończmy je inaczej: to gest ambasadora. Skąd się wzięły na naszych ziemiach „złe grusze” i jak stworzyliśmy polskie odmiany jabłek, które podbijają dziś świat?

## Krykiet mogą pogrzebać zakłady bukmacherskie
 - [https://www.rp.pl/plus-minus/art39229671-krykiet-moga-pogrzebac-zaklady-bukmacherskie](https://www.rp.pl/plus-minus/art39229671-krykiet-moga-pogrzebac-zaklady-bukmacherskie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Ruszają mistrzostwa świata w krykiecie. Odpowiedź na pytanie, kogo to obchodzi, brzmi: jakieś 2 miliardy ludzi. A w dodatku dla wielu z nich to znacznie więcej niż sport.

## Kurt Vonnegut ocalał z bombardowania Drezna dzięki rzeźni
 - [https://www.rp.pl/plus-minus/art39229651-kurt-vonnegut-ocalal-z-bombardowania-drezna-dzieki-rzezni](https://www.rp.pl/plus-minus/art39229651-kurt-vonnegut-ocalal-z-bombardowania-drezna-dzieki-rzezni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Kurt Vonnegut ocalał w czasie bombardowania Drezna przez aliantów tylko dlatego, że wraz z pozostałymi 150 Amerykanami umieszczono go w magazynie mięsa, wykutym w skale trzy piętra pod tytułową rzeźnią. Gorąc z góry tu nie docierał.

## Maciejewski: Pisanie jest związane z samotnością, ale tylko pozornie
 - [https://www.rp.pl/plus-minus/art39228551-maciejewski-pisanie-jest-zwiazane-z-samotnoscia-ale-tylko-pozornie](https://www.rp.pl/plus-minus/art39228551-maciejewski-pisanie-jest-zwiazane-z-samotnoscia-ale-tylko-pozornie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Samotność związana z pisaniem jest do wytrzymania tylko pod warunkiem, że na jej drugim końcu Ktoś jest. Najlepiej ta sama osoba, która znajdowała się też na początku. Ta sama towarzyszka pierwszego wrażenia i ostatniego zdania.

## Tomasz Terlikowski: Już na początku synodu papież odpalił prawdziwą bombę
 - [https://www.rp.pl/plus-minus/art39229271-tomasz-terlikowski-juz-na-poczatku-synodu-papiez-odpalil-prawdziwa-bombe](https://www.rp.pl/plus-minus/art39229271-tomasz-terlikowski-juz-na-poczatku-synodu-papiez-odpalil-prawdziwa-bombe)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Już na początku sesji plenarnej Synodu o synodalności Franciszek odpalił prawdziwą bombę. Odpowiedź na tzw. dubia kardynałów oznacza bowiem przyspieszenie na drodze zmiany doktryny moralnej Kościoła.

## Viktor Orbán chce wrócić do czasów Miklósa Horthyego – Węgry śnią o potędze
 - [https://www.rp.pl/cywilizacja/art39227731-viktor-orban-chce-wrocic-do-czasow-miklosa-horthyego-wegry-snia-o-potedze](https://www.rp.pl/cywilizacja/art39227731-viktor-orban-chce-wrocic-do-czasow-miklosa-horthyego-wegry-snia-o-potedze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T15:00:00+00:00

Dzisiaj na Węgrzech kwitną podobne jak w epoce Horthyego sny o potędze, co pociąga za sobą hasła rewizjonizmu. A Viktor Orbán podsyca je w swoich wystąpieniach, zamiast zajmować się teraźniejszością. Dokąd prowadzą Węgrów jego wielkie plany i wizje?

## Walka o władzę i majątek w słynnej marce luksusowej. Siostra przeciw siostrom
 - [https://sukces.rp.pl/ludzie/art39227911-walka-o-wladze-i-majatek-w-slynnej-marce-luksusowej-siostra-przeciw-siostrom](https://sukces.rp.pl/ludzie/art39227911-walka-o-wladze-i-majatek-w-slynnej-marce-luksusowej-siostra-przeciw-siostrom)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T14:58:00+00:00

Dwie siostry Bulgari, dziedziczki twórcy słynnej włoskiej marki luksusowej, walczą ze sobą o spadek po swojej matce, żonie założyciela marki. Co konkretnie skłóciło dziedziczki?

## Co to jest mental fitness - dlaczego mózg i ciało tak bardzo go potrzebują?
 - [https://kobieta.rp.pl/psychologia/art39229551-co-to-jest-mental-fitness-dlaczego-mozg-i-cialo-tak-bardzo-go-potrzebuja](https://kobieta.rp.pl/psychologia/art39229551-co-to-jest-mental-fitness-dlaczego-mozg-i-cialo-tak-bardzo-go-potrzebuja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T14:42:16+00:00

Zdrowie psychiczne jest tak samo ważne jak fizyczne. Aby utrzymać ciało w dobrej formie i wzmocnić odporność, dorosły człowiek powinien każdego dnia ćwiczyć około 30 minut dziennie. Jak zatem dbać o umysł, aby jego sprawność pomagała w pokonywaniu codziennych problemów?

## Joanna Kulig będzie miała wpływ na to, kto otrzyma Oscara
 - [https://kobieta.rp.pl/kultura/art39227991-joanna-kulig-bedzie-miala-wplyw-na-to-kto-otrzyma-oscara](https://kobieta.rp.pl/kultura/art39227991-joanna-kulig-bedzie-miala-wplyw-na-to-kto-otrzyma-oscara)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:52:00+00:00

Dobra passa Joanny Kulig trwa. Amerykańska Akademia Filmowa podała nazwiska kolejnych osób, które zasilą jej szeregi i będą miały wpływ na to, komu zostanie przyznany Oscar. Polka znalazła się na tej liście.

## Miażdżący raport NIK o finansach TVP. "Bizancjum za publiczne pieniądze"
 - [https://www.rp.pl/polityka/art39229251-miazdzacy-raport-nik-o-finansach-tvp-bizancjum-za-publiczne-pieniadze](https://www.rp.pl/polityka/art39229251-miazdzacy-raport-nik-o-finansach-tvp-bizancjum-za-publiczne-pieniadze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:47:10+00:00

Dziesięciu pracowników TVP o najwyższych rocznych przychodach zarobiło w ubiegłym roku aż 9 mln 267 tys. zł - o blisko 2 mln zł więcej niż jeszcze dwa lata wcześniej - wynika z raportu NIK o finansach TVP S.A.

## SN oddalił skargę Trzeciej Drogi ws. wydawania kart wyborczych i referendalnych
 - [https://www.rp.pl/prawo-dla-ciebie/art39229561-sn-oddalil-skarge-trzeciej-drogi-ws-wydawania-kart-wyborczych-i-referendalnych](https://www.rp.pl/prawo-dla-ciebie/art39229561-sn-oddalil-skarge-trzeciej-drogi-ws-wydawania-kart-wyborczych-i-referendalnych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:37:00+00:00

Sąd Najwyższy oddalił zarzut komitetu wyborczego Trzecia Droga Polska 2050 Szymona Hołowni - Polskie Stronnictwo Ludowe naruszenia, czy raczej zagrożenia dla tajności głosowania w najbliższych wyborach i referendum przez odnotowywanie przypadków niepobrania karty referendalnej.

## „Nie poddawajcie się, bo jest nadzieja" - mówi Narges Mohammadi, laureatka Pokojowej Nagrody Nobla
 - [https://kobieta.rp.pl/ludzie/art39229331-nie-poddawajcie-sie-bo-jest-nadzieja-mowi-narges-mohammadi-laureatka-pokojowej-nagrody-nobla](https://kobieta.rp.pl/ludzie/art39229331-nie-poddawajcie-sie-bo-jest-nadzieja-mowi-narges-mohammadi-laureatka-pokojowej-nagrody-nobla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:17:34+00:00

Pokojową Nagrodę Nobla przyznano Narges Mohammadi dokładnie 20 lat po tym, jak to samo wyróżnienie trafiło do Szirin Ebadi - twórczyni Centrum Obrońców Praw Człowieka. To ważny symbol.

## Tenis w Szanghaju. Hubert Hurkacz wrócił i wygrał
 - [https://www.rp.pl/tenis/art39229531-tenis-w-szanghaju-hubert-hurkacz-wrocil-i-wygral](https://www.rp.pl/tenis/art39229531-tenis-w-szanghaju-hubert-hurkacz-wrocil-i-wygral)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:16:59+00:00

Po ponad miesięcznej przerwie Hubert Hurkacz znów pojawił się w ATP World Tour. W Szanghaju zwyciężył na dobry początek Thanasiego Kokkinakisa 7:6 (7-5), 6:4

## Natalia Żyto: Telewizja Publiczna niszczy polskie społeczeństwo
 - [https://www.rp.pl/polityka/art39228371-natalia-zyto-telewizja-publiczna-niszczy-polskie-spoleczenstwo](https://www.rp.pl/polityka/art39228371-natalia-zyto-telewizja-publiczna-niszczy-polskie-spoleczenstwo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T13:14:50+00:00

TVP szczuje, kłamie, manipuluje i obraża ludzi - mówiła Natalia Żyto, rzeczniczka Agrounii, w rozmowie z Michałem Kolanką, pytana o symptomy zaostrzenia się kampanii wyborczej.

## Morze Czarne: Eksplozja w pobliżu tureckiego statku towarowego
 - [https://www.rp.pl/konflikty-zbrojne/art39229411-morze-czarne-eksplozja-w-poblizu-tureckiego-statku-towarowego](https://www.rp.pl/konflikty-zbrojne/art39229411-morze-czarne-eksplozja-w-poblizu-tureckiego-statku-towarowego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T12:53:40+00:00

W pobliżu pływającego pod turecką banderą statku płynącego do położonego na Ukrainie portu Izmaił doszło do eksplozji, która jednak nie uszkodziła statku.

## Prezes Legii Warszawa o wydarzeniach w Holandii: Absolutny skandal, nie odpuścimy
 - [https://www.rp.pl/sport/art39229311-prezes-legii-warszawa-o-wydarzeniach-w-holandii-absolutny-skandal-nie-odpuscimy](https://www.rp.pl/sport/art39229311-prezes-legii-warszawa-o-wydarzeniach-w-holandii-absolutny-skandal-nie-odpuscimy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T12:22:00+00:00

Prezes Legii Warszawa Dariusz Mioduski odniósł się do wydarzeń, do których doszło w Holandii po meczu Ligi Konferencji Europy UEFA pomiędzy AZ Alkmaar a stołeczną drużyną. Mioduski powiedział, że doszło do skandalu i wydarzeń bez precedensu.

## Szymon Hołownia idzie na debatę. Władysław Kosiniak-Kamysz jedzie za Jarosławem Kaczyńskim. Hołownia wskazuje "oręż demokracji"
 - [https://www.rp.pl/wybory/art39229291-szymon-holownia-idzie-na-debate-wladyslaw-kosiniak-kamysz-jedzie-za-jaroslawem-kaczynskim-holownia-wskazuje-orez-demokracji](https://www.rp.pl/wybory/art39229291-szymon-holownia-idzie-na-debate-wladyslaw-kosiniak-kamysz-jedzie-za-jaroslawem-kaczynskim-holownia-wskazuje-orez-demokracji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T12:18:52+00:00

Naszym hasłem, od wielu tygodni jest "Dość kłótni, do przodu". Jeżdżąc po Polsce widzimy, jak to hasło jest celne, potrzebne, jak odpowiada potrzebom Polaków - mówił na konferencji prasowej Szymon Hołownia, lider Polski 2050.

## Drake zaprosił gwiazdy i uderzył w Westa
 - [https://www.rp.pl/muzyka-popularna/art39229101-drake-zaprosil-gwiazdy-i-uderzyl-w-westa](https://www.rp.pl/muzyka-popularna/art39229101-drake-zaprosil-gwiazdy-i-uderzyl-w-westa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T12:06:49+00:00

W piątek 6 października ukazał się długooczekiwany album „For All the Dogs”. Drake w charakterze cesarza rapu zaprosił największe gwiazdy. To Bad Bunny, J. Cole, SZA i Lil Yachty. Kanye West został poza burtą.

## NSA: rozwijanie produktów przy pomocy zewnętrznych podmiotów daje ulgę IP Box
 - [https://firma.rp.pl/pit-cit-vat/art39229241-nsa-rozwijanie-produktow-przy-pomocy-zewnetrznych-podmiotow-daje-ulge-ip-box](https://firma.rp.pl/pit-cit-vat/art39229241-nsa-rozwijanie-produktow-przy-pomocy-zewnetrznych-podmiotow-daje-ulge-ip-box)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T12:03:52+00:00

Fiskus nieprawidłowo odmówił 5-proc. ulgi IP Box spółce, która nabywa od innych specjalistów fragmenty kodów i tworzy z nich kompletne programy komputerowe.

## Jacek Nizinkiewicz: Dlaczego Kaczyński nie weźmie udziału w debacie TVP. Czy PiS na tym zyska?
 - [https://www.rp.pl/publicystyka/art39228431-jacek-nizinkiewicz-dlaczego-kaczynski-nie-wezmie-udzialu-w-debacie-tvp-czy-pis-na-tym-zyska](https://www.rp.pl/publicystyka/art39228431-jacek-nizinkiewicz-dlaczego-kaczynski-nie-wezmie-udzialu-w-debacie-tvp-czy-pis-na-tym-zyska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:54:55+00:00

Donald Tusk i inni liderzy partyjni stawią się na poniedziałkowej debacie w Telewizji Publicznej. Nieobecny będzie tylko Jarosław Kaczyński. Mateusz Morawiecki zastąpi prezesa PiS, który ma powody, dla których unika spotkania z konkurentami.

## Narges Mohammadi. Laureatka Pokojowej Nagrody Nobla 2023 symbolem świata walczącego o prawa kobiet
 - [https://kobieta.rp.pl/ludzie/art39228711-narges-mohammadi-laureatka-pokojowej-nagrody-nobla-2023-symbolem-swiata-walczacego-o-prawa-kobiet](https://kobieta.rp.pl/ludzie/art39228711-narges-mohammadi-laureatka-pokojowej-nagrody-nobla-2023-symbolem-swiata-walczacego-o-prawa-kobiet)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:50:42+00:00

Przyznanie Pokojowej Nagrody Nobla Narges Mohammadi to nie tylko wyraz uznania dla jej działań. Komitet Noblowski swoją decyzją zwraca uwagę na to, jakie tematy są ważne we współczesnym świecie.

## W Warszawie trwają dni Pamięci Pawiaka
 - [https://www.rp.pl/historia-polski/art39228381-w-warszawie-trwaja-dni-pamieci-pawiaka](https://www.rp.pl/historia-polski/art39228381-w-warszawie-trwaja-dni-pamieci-pawiaka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:46:13+00:00

W Warszawie obchodzone są Dni Pamięci Pawiaka, największego więzienia dla Polaków, który funkcjonował na terenie Generalnego Gubernatorstwa w czasie niemieckiej okupacji Rzeczpospolitej.

## Na CD Projekcie znów leje się krew. Duża wyprzedaż akcji twórców „Cyberpunka”
 - [https://www.rp.pl/biznes/art39229171-na-cd-projekcie-znow-leje-sie-krew-duza-wyprzedaz-akcji-tworcow-cyberpunka](https://www.rp.pl/biznes/art39229171-na-cd-projekcie-znow-leje-sie-krew-duza-wyprzedaz-akcji-tworcow-cyberpunka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:42:00+00:00

Po wczorajszej mocnej wyprzedaży, dziś akcje studia na giełdzie też tracą ponad 6 proc. Od czasu premiery „Widma Wolności” kapitalizacja spółki stopniała o ponad 4 mld zł.

## Ceny olejów, mięsa i nabiału na świecie w dół. Cukru i zbóż - w górę
 - [https://www.rp.pl/przemysl-spozywczy/art39229081-ceny-olejow-miesa-i-nabialu-na-swiecie-w-dol-cukru-i-zboz-w-gore](https://www.rp.pl/przemysl-spozywczy/art39229081-ceny-olejow-miesa-i-nabialu-na-swiecie-w-dol-cukru-i-zboz-w-gore)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:37:03+00:00

Mimo wahań cen żywności na świecie we wrześniu ich indeks jest już o blisko 1/4 poniżej rekordowego poziomu zanotowanego po wybuchu wojny w Ukrainie.

## Uzbrojony w nóż wtargnął do biura senatora Krzysztofa Kwiatkowskiego
 - [https://www.rp.pl/polityka/art39229121-uzbrojony-w-noz-wtargnal-do-biura-senatora-krzysztofa-kwiatkowskiego](https://www.rp.pl/polityka/art39229121-uzbrojony-w-noz-wtargnal-do-biura-senatora-krzysztofa-kwiatkowskiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:35:00+00:00

"Jedziemy dokonać zgłoszenia przestępstwa na policję" - oświadczył senator Krzysztof Kwiatkowski. Pojawiły się doniesienia, że do biura senatora wtargnęła osoba uzbrojona w nóż.

## Premier Armenii rozbija rosyjski sojusz. Uderza w Władimira Putina i Aleksandra Łukaszenkę
 - [https://www.rp.pl/dyplomacja/art39228601-premier-armenii-rozbija-rosyjski-sojusz-uderza-w-wladimira-putina-i-aleksandra-lukaszenke](https://www.rp.pl/dyplomacja/art39228601-premier-armenii-rozbija-rosyjski-sojusz-uderza-w-wladimira-putina-i-aleksandra-lukaszenke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:33:29+00:00

Premier Armenii spotkał się w Hiszpanii z prezydentem Ukrainy. Porozmawiał też z liderką wolnej Białorusi. W ten sposób przełamał tabu w sterowanym przez Rosję sojuszu militarnym.

## Kaufland kontra związek zawodowy. Demonstracja i lista żądań
 - [https://www.rp.pl/handel/art39228701-kaufland-kontra-zwiazek-zawodowy-demonstracja-i-lista-zadan](https://www.rp.pl/handel/art39228701-kaufland-kontra-zwiazek-zawodowy-demonstracja-i-lista-zadan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:32:21+00:00

Działający w Kauflandzie związek zawodowy Konfederacja Pracy domaga się od firmy zwiększenia obsady sklepów. I zamierza protestować.

## Kim jest Narges Mohammadi, laureatka Pokojowej Nagrody Nobla?
 - [https://www.rp.pl/spoleczenstwo/art39229011-kim-jest-narges-mohammadi-laureatka-pokojowej-nagrody-nobla](https://www.rp.pl/spoleczenstwo/art39229011-kim-jest-narges-mohammadi-laureatka-pokojowej-nagrody-nobla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:16:28+00:00

Swoje dzieci, Alego i Kianę, ostani raz widziała osiem lat temu. Tegoroczna laureatka Pokojowej Nagrody Nobla prawie wszystko oddała za walkę o wolność.

## Wybory 2023: mijają ważne terminy
 - [https://www.rp.pl/w-sadzie-i-w-urzedzie/art39229031-wybory-2023-mijaja-wazne-terminy](https://www.rp.pl/w-sadzie-i-w-urzedzie/art39229031-wybory-2023-mijaja-wazne-terminy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:08:21+00:00

Już w przyszłą niedzielę, 15 października odbędą się wybory parlamentarne oraz rządowe referendum. W przyszłym tygodniu mijają ostateczne terminy na załatwienie spraw związanych z głosowaniem.

## Wybory 2023: 10. i 12. października mijają ważne terminy
 - [https://www.rp.pl/prawo-dla-ciebie/art39229031-wybory-2023-10-i-12-pazdziernika-mijaja-wazne-terminy](https://www.rp.pl/prawo-dla-ciebie/art39229031-wybory-2023-10-i-12-pazdziernika-mijaja-wazne-terminy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T11:08:00+00:00

Już w przyszłą niedzielę, 15 października odbędą się wybory parlamentarne oraz rządowe referendum. W przyszłym tygodniu mijają ostateczne terminy na załatwienie spraw związanych z głosowaniem w wyborach.

## Polscy siatkarze pokonali Argentynę. Polacy jedną nogą w Paryżu
 - [https://www.rp.pl/siatkowka/art39229001-polscy-siatkarze-pokonali-argentyne-polacy-jedna-noga-w-paryzu](https://www.rp.pl/siatkowka/art39229001-polscy-siatkarze-pokonali-argentyne-polacy-jedna-noga-w-paryzu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:59:49+00:00

Mecz z Argentyną był kluczowy dla układu tabeli turnieju kwalifikacyjnego. Porażka mogła wpędzić Polaków w poważne kłopoty. Nie obyło się bez nerwów, ale na szczęście udało się pokonać Argentynę 3:1.

## Debata TVP: Wiadomo kto będzie reprezentował PiS
 - [https://www.rp.pl/polityka/art39228741-debata-tvp-wiadomo-kto-bedzie-reprezentowal-pis](https://www.rp.pl/polityka/art39228741-debata-tvp-wiadomo-kto-bedzie-reprezentowal-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:58:59+00:00

Debata wyborcza odbędzie się w TVP 9 października, o godzinie 18:30. Koalicję Obywatelską będzie na niej reprezentował Donald Tusk. Wiadomo już też, kto będzie reprezentować Prawo i Sprawiedliwość.

## Maksymalnie 15 punktów za kilka wykroczeń na drodze? Jest odpowiedź MSWiA
 - [https://www.rp.pl/prawo-drogowe/art39228731-maksymalnie-15-punktow-za-kilka-wykroczen-na-drodze-jest-odpowiedz-mswia](https://www.rp.pl/prawo-drogowe/art39228731-maksymalnie-15-punktow-za-kilka-wykroczen-na-drodze-jest-odpowiedz-mswia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:57:22+00:00

Rzecznik praw obywatelskich wystąpił do MSWiA o zmianę przepisów za wykroczenia drogowe. Zaproponował, że jeśli suma punktów odpowiadających naruszeniom przekraczałaby 15, to kierowca otrzymywałby ich właśnie tyle.

## Skandal po meczu Legii w Holandii. Minister sportu interweniuje
 - [https://www.rp.pl/pilka-nozna/art39228671-skandal-po-meczu-legii-w-holandii-minister-sportu-interweniuje](https://www.rp.pl/pilka-nozna/art39228671-skandal-po-meczu-legii-w-holandii-minister-sportu-interweniuje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:46:20+00:00

Po meczu piłkarskiej Ligi Konferencji Europy UEFA pomiędzy AZ Alkmaar a Legią Warszawa doszło do poturbowania właściciela Legii, Dariusza Mioduskiego i zatrzymania przez policję dwóch warszawskich piłkarzy - Josuégo, kapitana Legii, oraz Radovana Pankova. Z interwencją wystąpił minister sportu i turystyki Kamil Bortniczuk.

## Nowe prawo ojców do urlopów rodzicielskich. Matki mogą na nim dużo zyskać
 - [https://kobieta.rp.pl/psychologia/art39227661-nowe-prawo-ojcow-do-urlopow-rodzicielskich-matki-moga-na-nim-duzo-zyskac](https://kobieta.rp.pl/psychologia/art39227661-nowe-prawo-ojcow-do-urlopow-rodzicielskich-matki-moga-na-nim-duzo-zyskac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:35:50+00:00

"Urlop rodzicielski został poszerzony o dziewięć tygodni i każdy z rodziców ma swoich dziewięć nietransferowalnych tygodni. W przypadku ojców to jest totalna rewolucja, semantyka jest zupełnie inna niż do tej pory. To bardzo zmienia sposób rozmowy między partnerami", tłumaczy Karolina Andrian, aktywistka działająca na rzecz kobiet i równouprawnienia płci.

## Francuska sieć supermarketów uratowana przez czeskiego miliardera
 - [https://www.rp.pl/handel/art39228481-francuska-siec-supermarketow-uratowana-przez-czeskiego-miliardera](https://www.rp.pl/handel/art39228481-francuska-siec-supermarketow-uratowana-przez-czeskiego-miliardera)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:27:30+00:00

Casino, francuska sieć supermarketów, nie zbankrutuje. Zawarła umowę o restrukturyzacji długu z głównymi wierzycielami, zgrupowanymi wokół czeskiego miliardera Daniela Kretinsky'ego.

## PO zapowiada likwidację TVP Info i "Wiadomości". Porównanie do "Russia Today"
 - [https://www.rp.pl/wybory/art39228581-po-zapowiada-likwidacje-tvp-info-i-wiadomosci-porownanie-do-russia-today](https://www.rp.pl/wybory/art39228581-po-zapowiada-likwidacje-tvp-info-i-wiadomosci-porownanie-do-russia-today)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:26:57+00:00

Cała ta władza PiS opiera się na kłamstwie, a tuba propagandowa PiS-u, czyli Telewizja zwana kiedyś publiczną jest narzędziem, by robić ludziom wodę z mózgu - mówił na konferencji prasowej Cezary Tomczyk, poseł Koalicji Obywatelskiej.

## Gwiazda „Stranger Things” buduje swój biznes. Najbogatsza nastolatka w Hollywood
 - [https://sukces.rp.pl/ludzie/art39182171-gwiazda-stranger-things-buduje-swoj-biznes-najbogatsza-nastolatka-w-hollywood](https://sukces.rp.pl/ludzie/art39182171-gwiazda-stranger-things-buduje-swoj-biznes-najbogatsza-nastolatka-w-hollywood)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:24:02+00:00

Millie Bobby Brown stała się gwiazdą dzięki roli Jedenastki w serialu „Stranger Things”. Dzisiaj ma 19 lat i walczy o to, by nie zostać aktorką jednej roli. Z sukcesami próbuje sił w biznesie.

## Park w Zabrzu: 77,5 tys. metrów dla logistyki
 - [https://www.rp.pl/nieruchomosci/art39228561-park-w-zabrzu-77-5-tys-metrow-dla-logistyki](https://www.rp.pl/nieruchomosci/art39228561-park-w-zabrzu-77-5-tys-metrow-dla-logistyki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T10:16:02+00:00

Kamień węgielny pod park logistyczny w Zabrzu wmurował Fortress Real Estate Investments. Obiekt ma być oddany w II kwartale 2024 r.

## Początek końca ekościemy. Nowe przepisy UE
 - [https://klimat.rp.pl/prawo/art39228491-poczatek-konca-ekosciemy-nowe-przepisy-ue](https://klimat.rp.pl/prawo/art39228491-poczatek-konca-ekosciemy-nowe-przepisy-ue)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:57:40+00:00

Unia Europejska zapowiada wprowadzenie przepisów, które mają mocno ograniczyć zjawisko greenwashingu czyli ekościemy - wskazuje Konfederacja Lewiatan.

## Skandal po meczu Legii Warszawa. Resort Ziobry: będą twarde działania
 - [https://www.rp.pl/prawo-karne/art39228281-skandal-po-meczu-legii-warszawa-resort-ziobry-beda-twarde-dzialania](https://www.rp.pl/prawo-karne/art39228281-skandal-po-meczu-legii-warszawa-resort-ziobry-beda-twarde-dzialania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:56:00+00:00

Ministerstwo Sprawiedliwości zapowiedziało działania prawne w związku z wydarzeniami po meczu Legii Warszawa w Alkmaar. Doszło tam do poturbowania właściciela stołecznego klubu, Dariusza Mioduskiego i zatrzymania przez policję dwóch warszawskich piłkarzy - kapitana Legii, Josue i Radovana Pankova.

## Kryzys paliwowy. Rosja zmuszona do sięgnięcia po nadzwyczajne środki
 - [https://energia.rp.pl/paliwa/art39228201-kryzys-paliwowy-rosja-zmuszona-do-siegniecia-po-nadzwyczajne-srodki](https://energia.rp.pl/paliwa/art39228201-kryzys-paliwowy-rosja-zmuszona-do-siegniecia-po-nadzwyczajne-srodki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:50:24+00:00

Kryzys na rosyjskim rynku paliw, spowodowany wywołaną przez Kreml wojną, zmusił reżim do sięgnięcia po nadzwyczajne środki. Koncernom zostały narzucone obowiązkowe wielkości dostaw na rynek krajowy. Cło zaporowe w eksporcie będzie obowiązywać do końca 2025 r.

## WHO ostrzega: Europie i USA zagraża nowa choroba. Przez zmiany klimatu
 - [https://www.rp.pl/zdrowie/art39228251-who-ostrzega-europie-i-usa-zagraza-nowa-choroba-przez-zmiany-klimatu](https://www.rp.pl/zdrowie/art39228251-who-ostrzega-europie-i-usa-zagraza-nowa-choroba-przez-zmiany-klimatu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:44:28+00:00

Szerząca się dotychczas w Ameryce Łacińskiej i Azji gorączka denga, która powoduje ok. 20 tys. zgonów rocznie, wkrótce może stać się poważnym zagrożeniem dla południowych Stanów Zjednoczonych oraz południowej Europy i nowych częściach Afryki - alarmuje WHO.

## Firma „kucharza Putina” już nie nakarmi rosyjskiej armii. Kreml zrywa kontrakt
 - [https://www.rp.pl/uslugi/art39228131-firma-kucharza-putina-juz-nie-nakarmi-rosyjskiej-armii-kreml-zrywa-kontrakt](https://www.rp.pl/uslugi/art39228131-firma-kucharza-putina-juz-nie-nakarmi-rosyjskiej-armii-kreml-zrywa-kontrakt)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:39:29+00:00

Rosyjskie Ministerstwo Obrony zerwało kontrakt z firmą cateringową zmarłego Jewgienija Prigożyna - Concord Catering.

## Rewolucja w reprezentacji Polski. Michał Probierz wysłał jasny sygnał
 - [https://www.rp.pl/pilka-nozna/art39228111-rewolucja-w-reprezentacji-polski-michal-probierz-wyslal-jasny-sygnal](https://www.rp.pl/pilka-nozna/art39228111-rewolucja-w-reprezentacji-polski-michal-probierz-wyslal-jasny-sygnal)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:17:32+00:00

Michał Probierz powołał kadrę na mecze eliminacji Euro 2024 z Wyspami Owczymi (12 października) i Mołdawią (15 października). Są powroty, kilku nieobecnych oraz sygnał, że nowy selekcjoner nie przywiązuje się do nazwisk.

## Unia Europejska przeciwko Chińczykom. Pod lupą chińska elektromobilność
 - [https://moto.rp.pl/na-prad/art39228121-unia-europejska-przeciwko-chinczykom-pod-lupa-chinska-elektromobilnosc](https://moto.rp.pl/na-prad/art39228121-unia-europejska-przeciwko-chinczykom-pod-lupa-chinska-elektromobilnosc)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:13:16+00:00

UE formalnie wszczęła dochodzenie w sprawie subsydiów do aut elektrycznych produkowanych w Chinach. To może skutkować wprowadzeniem ceł wyrównawczych już w ciągu najbliższych dziewięciu miesięcy. Chińczycy są oburzeni.

## Szwedzkie rakiety RBS15 coraz bliżej Miecznika
 - [https://radar.rp.pl/modernizacja-sil-zbrojnych/art39228161-szwedzkie-rakiety-rbs15-coraz-blizej-miecznika](https://radar.rp.pl/modernizacja-sil-zbrojnych/art39228161-szwedzkie-rakiety-rbs15-coraz-blizej-miecznika)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:09:51+00:00

Podpisanie umowy na zintegrowane systemy obserwacji, czyli system walki dla „Mieczników" zwróciło uwagę na rakietowy oręż przyszłych wielozadaniowych fregat dla polskiej Marynarki.

## Ziobro składa trzy skargi nadzwyczajne ws. kredytów frankowych
 - [https://www.rp.pl/konsumenci/art39227981-ziobro-sklada-trzy-skargi-nadzwyczajne-ws-kredytow-frankowych](https://www.rp.pl/konsumenci/art39227981-ziobro-sklada-trzy-skargi-nadzwyczajne-ws-kredytow-frankowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:03:46+00:00

Prokurator Generalny Zbigniew Ziobro skierował do Sądu Najwyższego kolejne trzy skargi nadzwyczajne w sprawach kredytów frankowych - przekazała Prokuratura Krajowa.

## Pokojowa Nagroda Nobla 2023 przyznana
 - [https://www.rp.pl/spoleczenstwo/art39227831-pokojowa-nagroda-nobla-2023-przyznana](https://www.rp.pl/spoleczenstwo/art39227831-pokojowa-nagroda-nobla-2023-przyznana)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T09:01:00+00:00

Norweski Komitet Noblowski przyznał w piątek Pokojową Nagrodę Nobla. Laureatką została Narges Mohammadi.

## Kurs złotego stabilny na koniec tygodnia
 - [https://www.rp.pl/waluty/art39227951-kurs-zlotego-stabilny-na-koniec-tygodnia](https://www.rp.pl/waluty/art39227951-kurs-zlotego-stabilny-na-koniec-tygodnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:54:35+00:00

Kursy euro i dolara lekko zniżkują w piątek z rana. Złotego wspiera stabilizacja EUR/USD

## Sąd Najwyższy pyta TSUE o prawo zatrzymania wobec frankowicza
 - [https://www.rp.pl/konsumenci/art39228101-sad-najwyzszy-pyta-tsue-o-prawo-zatrzymania-wobec-frankowicza](https://www.rp.pl/konsumenci/art39228101-sad-najwyzszy-pyta-tsue-o-prawo-zatrzymania-wobec-frankowicza)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:46:47+00:00

Sąd Najwyższy odroczył rozstrzygnięcie sporu dotyczącego prawa zatrzymania przez banki w stosunku do frankowiczów. Zwrócił się w tej sprawie do Trybunału Sprawiedliwości UE.

## Władimir Putin chwali się udanym testem rakiety o nieograniczonym zasięgu
 - [https://www.rp.pl/konflikty-zbrojne/art39227921-wladimir-putin-chwali-sie-udanym-testem-rakiety-o-nieograniczonym-zasiegu](https://www.rp.pl/konflikty-zbrojne/art39227921-wladimir-putin-chwali-sie-udanym-testem-rakiety-o-nieograniczonym-zasiegu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:39:25+00:00

Prezydent Rosji, Władimir Putin, poinformował o udanym teście rakiety manewrującej nowego typu, Buriewiestnik (NATO określa ją jako SSC-X-9 Skyfall). Pocisk jest wyposażony w silnik jądrowy, dzięki któremu ma mieć nieograniczony zasięg.

## W wyniku obniżki cen prądu rosną straty energetyki
 - [https://energia.rp.pl/elektroenergetyka/art39227691-w-wyniku-obnizki-cen-pradu-rosna-straty-energetyki](https://energia.rp.pl/elektroenergetyka/art39227691-w-wyniku-obnizki-cen-pradu-rosna-straty-energetyki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:35:50+00:00

Kolejna spółka informuje o stracie wynikającej z urzędowej obniżki cen prądu w tym roku o 12 proc. Po Tauronie teraz Energa informuje, że ta decyzja obniży wynik EBITDA spółki o 320 mln zł. Z dużych, giełdowych spółek takich informacji nie podali jeszcze PGE i Enea. Straty jednak mogą ponieść wszyscy sprzedawcy energii.

## Wybory 2023. Uruchomiono bazę mężów zaufania. Jest też specjalna aplikacja
 - [https://www.rp.pl/prawo-dla-ciebie/art39227891-wybory-2023-uruchomiono-baze-mezow-zaufania-jest-tez-specjalna-aplikacja](https://www.rp.pl/prawo-dla-ciebie/art39227891-wybory-2023-uruchomiono-baze-mezow-zaufania-jest-tez-specjalna-aplikacja)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:15:00+00:00

Ministerstwo Cyfryzacji poinformowało o uruchomieniu usługi, służącej do przekazywania informacji o osobach pełniących funkcję męża zaufania w wyborach i referendum. W dniu wyborów będzie też działać specjalna aplikacja dla osób, sprawujących tę funkcję.

## Kolejny najgorętszy miesiąc w historii świata. „Zmiana klimatu już nadeszła”.
 - [https://klimat.rp.pl/planeta/art39227841-kolejny-najgoretszy-miesiac-w-historii-swiata-zmiana-klimatu-juz-nadeszla](https://klimat.rp.pl/planeta/art39227841-kolejny-najgoretszy-miesiac-w-historii-swiata-zmiana-klimatu-juz-nadeszla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:07+00:00

Według danych usługi Copernicus Climate Change Service (C3S), we wrześniu średnia temperatura powietrza na powierzchni Ziemi wyniosła 16,38°C i była o 0,93°C wyższa od średniej miesięcznej z lat 1991–2020 oraz o 0,5°C wyższa od poprzedniego rekordu z roku 2020.

## Był minister i nie ma ministra. Czy Chiny szykują się do inwazji na Tajwan?
 - [https://www.rp.pl/cywilizacja/art39226691-byl-minister-i-nie-ma-ministra-czy-chiny-szykuja-sie-do-inwazji-na-tajwan](https://www.rp.pl/cywilizacja/art39226691-byl-minister-i-nie-ma-ministra-czy-chiny-szykuja-sie-do-inwazji-na-tajwan)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

W Chinach trwa czystka w armii na ogromną skalę. W ostatnim czasie „zniknęło” kilku generałów oraz sam minister obrony. Nieoficjalnie mówi się, że chodzi o korupcję, choć pojawiają się też głosy, że może to mieć związek z planami ataku na Tajwan.

## Covid dał Nobla nierokującego technologii
 - [https://www.rp.pl/plus-minus/art39226801-covid-dal-nobla-nierokujacego-technologii](https://www.rp.pl/plus-minus/art39226801-covid-dal-nobla-nierokujacego-technologii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

To, że szczepionka przeciw covidowi powstała błyskawicznie, nie byłoby możliwe bez wcześniejszych 40 lat mrówczej pracy w laboratoriach, wielkich porażek i drobnych sukcesów oraz uporu córki pewnego węgierskiego rzeźnika.

## Jan Pawlicki: PiS nie potrafi tworzyć kultury
 - [https://www.rp.pl/cywilizacja/art39226621-jan-pawlicki-pis-nie-potrafi-tworzyc-kultury](https://www.rp.pl/cywilizacja/art39226621-jan-pawlicki-pis-nie-potrafi-tworzyc-kultury)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Prawo i Sprawiedliwość nie buduje instytucji, lecz je kolonizuje, podporządkowuje – od kultury przez media po sądownictwo. Po utracie władzy wajcha zostanie przełożona, co pewnie poskutkuje dalszym osłabieniem struktur państwa. Rozmowa z Janem Pawlickim, Producentem telewizyjnym

## Kasia Sienkiewicz i Jacek Sienkiewicz z Kwiatu Jabłoni: Jeszcze nigdy tak bardzo nie obawialiśmy się o wynik wyborów
 - [https://www.rp.pl/kultura/art39226741-kasia-sienkiewicz-i-jacek-sienkiewicz-z-kwiatu-jabloni-jeszcze-nigdy-tak-bardzo-nie-obawialismy-sie-o-wynik-wyborow](https://www.rp.pl/kultura/art39226741-kasia-sienkiewicz-i-jacek-sienkiewicz-z-kwiatu-jabloni-jeszcze-nigdy-tak-bardzo-nie-obawialismy-sie-o-wynik-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Patrzymy na siebie przez pryzmat uprzedzeń: jedna połowa społeczeństwa jest zła dla drugiej ze względu na swoje życiowe i polityczne wybory. Kultura, pochodzenie, kolor skóry czy orientacja są powodem podziałów. Rozmowa z Kasią Sienkiewicz i Jackiem Sienkiewiczem, grupą Kwiat Jabłoni

## Młodzi nie oglądają kablówki, ale telewizja wciąż trzyma się mocno
 - [https://www.rp.pl/cywilizacja/art39226421-mlodzi-nie-ogladaja-kablowki-ale-telewizja-wciaz-trzyma-sie-mocno](https://www.rp.pl/cywilizacja/art39226421-mlodzi-nie-ogladaja-kablowki-ale-telewizja-wciaz-trzyma-sie-mocno)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Część polskiego społeczeństwa nie pisze się już na klasycznie przygotowywaną ofertę telewizyjną, czyli nadawane w sposób ciągły, linearny, programy o konkretnych porach, przeplatane marketingowymi przekazami stacji oraz ich biznesowych klientów. Jednak tradycyjna telewizja wcale nie zamierza się poddać.

## To internet, a nie telewizja może zadecydować o wyniku wyborów
 - [https://www.rp.pl/cywilizacja/art39226401-to-internet-a-nie-telewizja-moze-zadecydowac-o-wyniku-wyborow](https://www.rp.pl/cywilizacja/art39226401-to-internet-a-nie-telewizja-moze-zadecydowac-o-wyniku-wyborow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Kampania wyborcza zdaje się wyglądać tak jak dawniej, ale jednak zmieniło się wszystko. Wzrost znaczenia mediów społecznościowych, inna żywotność tematów wyborczych, poszerzenie elektoratu oraz postępująca walka z mediami to nowe akordy tegorocznej kampanii. I teraz politycy muszą się nauczyć grać zgodnie z tymi nowymi regułami.

## UE rezygnuje z obostrzeń klimatycznych. Europa jest na nie za biedna
 - [https://www.rp.pl/cywilizacja/art39226681-ue-rezygnuje-z-obostrzen-klimatycznych-europa-jest-na-nie-za-biedna](https://www.rp.pl/cywilizacja/art39226681-ue-rezygnuje-z-obostrzen-klimatycznych-europa-jest-na-nie-za-biedna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Walka z zanieczyszczeniem środowiska schodzi w Europie na drugi plan, bo rządy największych krajów widzą, że wyborcy obciążeni kosztami proekologicznej polityki zwracają się ku radykałom. Wobec groźby utraty władzy na rzecz populistów blednie nawet wizja katastrofy klimatycznej.

## W kampanii wyborczej strach jest po obu stronach – zarówno w PiS, jak i w KO
 - [https://www.rp.pl/cywilizacja/art39226511-w-kampanii-wyborczej-strach-jest-po-obu-stronach-zarowno-w-pis-jak-i-w-ko](https://www.rp.pl/cywilizacja/art39226511-w-kampanii-wyborczej-strach-jest-po-obu-stronach-zarowno-w-pis-jak-i-w-ko)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T08:00:00+00:00

Dla wszystkich kampania wyborcza to rozgrywka ostateczna. Dla PiS to perspektywa nie tylko masowych czystek personalnych, ale być może też braku szans na odzyskanie władzy kiedykolwiek. Z kolei dla KO, Trzeciej Drogi i Lewicy trzecie zwycięstwo obozu władzy byłoby podważeniem liberalno-lewicowej wizji świata.

## Iga Świątek zagra w półfinale w Pekinie
 - [https://www.rp.pl/tenis/art39227751-iga-swiatek-zagra-w-polfinale-w-pekinie](https://www.rp.pl/tenis/art39227751-iga-swiatek-zagra-w-polfinale-w-pekinie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:59:38+00:00

Po znakomitym ćwierćfinale z Caroline Garcią zakończonym wynikiem 6:7 (8-10), 7:6 (7-5), 6:1 dla Polki, Iga Świątek jest w najlepszej czwórce turnieju China Open. Kolejny mecz zagra w sobotę z Coco Gauff lub Marią Sakkari.

## Orlen kupi dwie farmy wiatrowe od brytyjskiego funduszu
 - [https://energia.rp.pl/oze/art39227671-orlen-kupi-dwie-farmy-wiatrowe-od-brytyjskiego-funduszu](https://energia.rp.pl/oze/art39227671-orlen-kupi-dwie-farmy-wiatrowe-od-brytyjskiego-funduszu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:52:58+00:00

W portfelu koncernu mają znaleźć się instalacje w Kuślinie (woj. wielkopolskie) i Krzęcinie (woj. zachodniopomorskie) o łącznej mocy około 60 MW. Wartości potencjalnej transakcji nie podano.

## Ile zarabiają prezenterzy prowadzący "Wiadomości" TVP"? Nieoficjalnie: Miliony
 - [https://www.rp.pl/spoleczenstwo/art39227541-ile-zarabiaja-prezenterzy-prowadzacy-wiadomosci-tvp-nieoficjalnie-miliony](https://www.rp.pl/spoleczenstwo/art39227541-ile-zarabiaja-prezenterzy-prowadzacy-wiadomosci-tvp-nieoficjalnie-miliony)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:51:51+00:00

W ciągu pięciu lat czworo prezenterów "Wiadomości" TVP, w tym Danuta Holecka i Michał Adamczyk, może zainkasować prawie 12 mln zł netto - pisze Onet. Portal podaje, że poznał umowy, jakie Telewizja Polska podpisała z prezenterami sztandarowego programu informacyjnego TVP.

## Kompetencje przyszłości 4K: rusza kolejna edycja programu #YouthEmpowered 2023
 - [https://sukces.rp.pl/spoleczenstwo/art39213841-kompetencje-przyszlosci-4k-rusza-kolejna-edycja-programu-youthempowered-2023](https://sukces.rp.pl/spoleczenstwo/art39213841-kompetencje-przyszlosci-4k-rusza-kolejna-edycja-programu-youthempowered-2023)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:43:19+00:00

Tysiące młodych ludzi, inspirujące wystąpienia ekspertów, a także kompetencje przyszłości jako temat przewodni – 10 października 2023 o godz. 10.00 odbędzie się spotkanie otwierające kolejną edycję programu #YouthEmpowered 2023 – Skills4Future, organizowanego realizowanego przez Coca-Cola HBC Polska i kraje bałtyckie oraz Fundację Młodzieżowej Przedsiębiorczości.

## Nowa strategia LOT. 20 nowych kierunków
 - [https://www.rp.pl/transport/art39227511-nowa-strategia-lot-20-nowych-kierunkow](https://www.rp.pl/transport/art39227511-nowa-strategia-lot-20-nowych-kierunkow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:42:43+00:00

W ciągu najbliższych pięciu lat LOT doda 20 nowych kierunków i zwiększy przewozy do 17 mln pasażerów. Przewiezie ich 110 samolotami. I będzie trwale rentowny. To główne założenia nowej strategii LOT.

## Twórcy ChatGPT chcą produkować chipy. Wiemy, ile kosztują firmę odpowiedzi bota
 - [https://cyfrowa.rp.pl/globalne-interesy/art39227621-tworcy-chatgpt-chca-produkowac-chipy-wiemy-ile-kosztuja-firme-odpowiedzi-bota](https://cyfrowa.rp.pl/globalne-interesy/art39227621-tworcy-chatgpt-chca-produkowac-chipy-wiemy-ile-kosztuja-firme-odpowiedzi-bota)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:37:00+00:00

Firma OpenAI, stojąca za ChatGPT, może stworzyć i produkować procesory sztucznej inteligencji. Szuka nawet w tym celu firm do przejęcia.

## Dominika Lasota: Kaczyński? Tusk? Są w polityce od dekad. Mam wrażenie, że stracili kontakt z rzeczywistością
 - [https://www.rp.pl/wybory/art39227581-dominika-lasota-kaczynski-tusk-sa-w-polityce-od-dekad-mam-wrazenie-ze-stracili-kontakt-z-rzeczywistoscia](https://www.rp.pl/wybory/art39227581-dominika-lasota-kaczynski-tusk-sa-w-polityce-od-dekad-mam-wrazenie-ze-stracili-kontakt-z-rzeczywistoscia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:21:03+00:00

Kobiety czują, że polityka ma na nich wywalone, więc im ciężko dostrzec siebie tak przewrotnie. Więc my pokazujemy środkowy palec, czy też gest Lichockiej i mówimy: "Idziemy po swoje, cicho już byłyśmy" - mówiła w rozmowie z Michałem Kolanką aktywistka Dominika Lasota z Inicjatywy Wschód.

## Święto kina świętem polskich filmów
 - [https://www.rp.pl/film/art39227531-swieto-kina-swietem-polskich-filmow](https://www.rp.pl/film/art39227531-swieto-kina-swietem-polskich-filmow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T07:00:55+00:00

Czy wyniki ostatniego weekendu, podczas którego bilety do kin kosztowały 12 zł, mogą napawać optymizmem na przyszłość?

## Nie tylko Netflix podrożeje. Ile w Polsce kosztują serwisy z filmami i serialami
 - [https://cyfrowa.rp.pl/globalne-interesy/art39224651-nie-tylko-netflix-podrozeje-ile-w-polsce-kosztuja-serwisy-z-filmami-i-serialami](https://cyfrowa.rp.pl/globalne-interesy/art39224651-nie-tylko-netflix-podrozeje-ile-w-polsce-kosztuja-serwisy-z-filmami-i-serialami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T06:19:00+00:00

Serwisy filmowe zmieniają ceny i wprowadzają tańsze usługi z reklamami. Zaczynają też walczyć ze współdzieleniem kont przez użytkowników. Oto, ile kosztują w Polsce usługi operatorów platform streamingowych.

## Krzysztof Bosak o debacie w TVP: A co ten Niemiec Weber tak ważny dla Kaczyńskiego? O co chodzi?
 - [https://www.rp.pl/wybory/art39227481-krzysztof-bosak-o-debacie-w-tvp-a-co-ten-niemiec-weber-tak-wazny-dla-kaczynskiego-o-co-chodzi](https://www.rp.pl/wybory/art39227481-krzysztof-bosak-o-debacie-w-tvp-a-co-ten-niemiec-weber-tak-wazny-dla-kaczynskiego-o-co-chodzi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T06:18:12+00:00

Boją się tej debaty. Nie chcą być wypunktowani. PiS to partia, która oddaje walkowerem debaty - mówił w rozmowie z Polsat News lider Ruchu Narodowego, poseł Konfederacji, Krzysztof Bosak.

## Sondaż: Jarosław Kaczyński nie chce debatować z Tuskiem. Jak oceniają to Polacy?
 - [https://www.rp.pl/wybory/art39227241-sondaz-jaroslaw-kaczynski-nie-chce-debatowac-z-tuskiem-jak-oceniaja-to-polacy](https://www.rp.pl/wybory/art39227241-sondaz-jaroslaw-kaczynski-nie-chce-debatowac-z-tuskiem-jak-oceniaja-to-polacy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:41:18+00:00

Jarosław Kaczyński zapowiedział, że nie weźmie udziału w debacie wyborczej organizowanej przez TVP bo tego dnia ma zaplanowane spotkanie z wyborcami w Przysusze. W sondażu Kantar dla TVN24 i "Faktów" TVN fakt, że Kaczyński nie chce debaty z Tuskiem, oceniali Polacy.

## Sąd: rozwijanie e-portalu z ulgą IP Box
 - [https://www.rp.pl/podatki/art39224661-sad-rozwijanie-e-portalu-z-ulga-ip-box](https://www.rp.pl/podatki/art39224661-sad-rozwijanie-e-portalu-z-ulga-ip-box)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:17:37+00:00

Spółka, która nabywa od innych specjalistów fragmenty kodów i tworzy z nich kompletne programy komputerowe, ma prawo do preferencyjnej 5-proc. stawki IP Box.

## Dariusz Adamski: Wyborcze straszenie likwidacją państw narodowych
 - [https://www.rp.pl/opinie-prawne/art39224671-dariusz-adamski-wyborcze-straszenie-likwidacja-panstw-narodowych](https://www.rp.pl/opinie-prawne/art39224671-dariusz-adamski-wyborcze-straszenie-likwidacja-panstw-narodowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:13:13+00:00

Wbrew ostrzeżeniom polskiego premiera, w praktyce jakiekolwiek głosowanie Parlamentu Europejskiego w sprawie traktatów UE znaczy niewiele.

## Nie każdy błąd jest unikaniem podatków
 - [https://www.rp.pl/podatki/art39224451-nie-kazdy-blad-jest-unikaniem-podatkow](https://www.rp.pl/podatki/art39224451-nie-kazdy-blad-jest-unikaniem-podatkow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:10:59+00:00

Klauzula obejścia prawa bywa opacznie rozumiana przez organy skarbowe. Sądy administracyjne, a nawet szef KAS tępią jednak jej nadużywanie.

## Pierwsze powołania Michała Probierza. Jest kilka niespodzianek, nowe twarze
 - [https://www.rp.pl/pilka-nozna/art39226971-pierwsze-powolania-michala-probierza-jest-kilka-niespodzianek-nowe-twarze](https://www.rp.pl/pilka-nozna/art39226971-pierwsze-powolania-michala-probierza-jest-kilka-niespodzianek-nowe-twarze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:04:03+00:00

Nowy selekcjoner wybrał 25 piłkarzy na mecze z Wyspami Owczymi i Mołdawią w eliminacjach Euro 2024. Jest kilku debiutantów, nie ma m.in. Jana Bednarka i Nicoli Zalewskiego.

## Unia wesprze miasta w sporze z platformami najmu
 - [https://www.rp.pl/nieruchomosci/art39224431-unia-wesprze-miasta-w-sporze-z-platformami-najmu](https://www.rp.pl/nieruchomosci/art39224431-unia-wesprze-miasta-w-sporze-z-platformami-najmu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:03:21+00:00

Airbnb, Booking.com czy inne platformy krótkoterminowego najmu zmieniają centra miast. UE chce wiedzieć, czy na dobre, czy na złe.

## Producent naczep Schmitz na plusie po ubiegłym roku
 - [https://logistyka.rp.pl/drogowy/art39225351-producent-naczep-schmitz-na-plusie-po-ubieglym-roku](https://logistyka.rp.pl/drogowy/art39225351-producent-naczep-schmitz-na-plusie-po-ubieglym-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T05:02:26+00:00

Największy europejski producent naczep wyszedł ze strat i zakończył ostatni rok obrachunkowy zyskami. Konkurenci także poprawili wyniki.

## Skandal po meczu Legii. Dwóch piłkarzy z Warszawy zatrzymanych przez policję
 - [https://www.rp.pl/pilka-nozna/art39227141-skandal-po-meczu-legii-dwoch-pilkarzy-z-warszawy-zatrzymanych-przez-policje](https://www.rp.pl/pilka-nozna/art39227141-skandal-po-meczu-legii-dwoch-pilkarzy-z-warszawy-zatrzymanych-przez-policje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T04:56:55+00:00

Po meczu Ligi Konferencji Europy pomiędzy AZ Alkmaar i Legią Warszawa (Legia przegrała 0:1) doszło do poturbowania właściciela Legii, Dariusza Mioduskiego i zatrzymania przez policję dwóch warszawskich piłkarzy - kapitana Legii, Josue i Radovana Pankova.

## USA zestrzeliły drona swojego sojusznika z NATO?
 - [https://www.rp.pl/konflikty-zbrojne/art39227111-usa-zestrzelily-drona-swojego-sojusznika-z-nato](https://www.rp.pl/konflikty-zbrojne/art39227111-usa-zestrzelily-drona-swojego-sojusznika-z-nato)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T04:00:14+00:00

Pentagon poinformował o zestrzeleniu nad Syrią tureckiego drona, który miał pojawić się w pobliżu miejsca stacjonowania żołnierzy USA. To pierwszy przypadek zestrzelenia przez USA drona należącego do Turcji, sojusznika USA z NATO.

## USA wracają do budowania muru na granicy z Meksykiem. Donald Trump triumfuje i chce przeprosin
 - [https://www.rp.pl/polityka/art39227091-usa-wracaja-do-budowania-muru-na-granicy-z-meksykiem-donald-trump-triumfuje-i-chce-przeprosin](https://www.rp.pl/polityka/art39227091-usa-wracaja-do-budowania-muru-na-granicy-z-meksykiem-donald-trump-triumfuje-i-chce-przeprosin)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T03:28:13+00:00

Administracja prezydenta USA, Joe Bidena, oświadczyła w czwartek, że zbuduje kolejne odcinki muru, który ma powstrzymać napływ nielegalnych imigrantów z Meksyku. Będzie to oznaczać kontynuację polityki realizowanej przez byłego prezydenta, Donalda Trumpa.

## Joe Biden znalazł sposób, by przekazać więcej pomocy wojskowej Ukrainie?
 - [https://www.rp.pl/dyplomacja/art39227071-joe-biden-znalazl-sposob-by-przekazac-wiecej-pomocy-wojskowej-ukrainie](https://www.rp.pl/dyplomacja/art39227071-joe-biden-znalazl-sposob-by-przekazac-wiecej-pomocy-wojskowej-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T03:04:50+00:00

Administracja Joe Bidena rozważa wykorzystanie programu grantów przydzielanych przez Departament Stanu, by wysłać dodatkową pomoc wojskową dla Ukrainy w czasie, gdy Kongres spiera się czy przyznać administracji dodatkowe środki na pomoc, w tym pomoc wojskową, dla Ukrainy - pisze "Politico".

## Wojna Rosji z Ukrainą. Dzień 590
 - [https://www.rp.pl/swiat/art39227051-wojna-rosji-z-ukraina-dzien-590](https://www.rp.pl/swiat/art39227051-wojna-rosji-z-ukraina-dzien-590)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T02:44:24+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. Wołodymyr Zełenski w swoim wieczornym wystąpieniu mówił, że "zło nie może zwyciężyć".

## Apteki na bakier z prawem
 - [https://www.rp.pl/abc-firmy/art39224401-apteki-na-bakier-z-prawem](https://www.rp.pl/abc-firmy/art39224401-apteki-na-bakier-z-prawem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Podsłuchiwani i zmuszani do łamania przepisów. Tak pracują farmaceuci i technicy farmaceutyczni.

## Apteki na bakier z prawem. Farmaceuci zmuszani i podsłuchiwani
 - [https://www.rp.pl/abc-firmy/art39224401-apteki-na-bakier-z-prawem-farmaceuci-zmuszani-i-podsluchiwani](https://www.rp.pl/abc-firmy/art39224401-apteki-na-bakier-z-prawem-farmaceuci-zmuszani-i-podsluchiwani)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Podsłuchiwani i zmuszani do łamania przepisów. Tak pracują farmaceuci i technicy farmaceutyczni.

## Boom na kursy kasujące punkty karne
 - [https://www.rp.pl/prawo-drogowe/art39224441-boom-na-kursy-kasujace-punkty-karne](https://www.rp.pl/prawo-drogowe/art39224441-boom-na-kursy-kasujace-punkty-karne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Są w Polsce miasta, w których kurs odbywa się nawet cztery razy dziennie. A i tak np. w Warszawie pierwszy wolny termin to dopiero 8 listopada. Chętnych na pozbycie się punktów nie zraża cena – od 850 zł do 1000 zł.

## Czy kobiety zadecydują o wyniku wyborów? Jest raport
 - [https://www.rp.pl/wybory/art39225381-czy-kobiety-zadecyduja-o-wyniku-wyborow-jest-raport](https://www.rp.pl/wybory/art39225381-czy-kobiety-zadecyduja-o-wyniku-wyborow-jest-raport)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Największa grupa niezdecydowanych wyborców to kobiety – wynika z raportu Fundacji im. Stefana Batorego „Siła głosu kobiet. Jak będą wybierać Polki?”.

## Dlaczego przywrócono kontrole na granicy ze Słowacją? Ujawniamy fałszywy syryjski ślad
 - [https://www.rp.pl/spoleczenstwo/art39225401-dlaczego-przywrocono-kontrole-na-granicy-ze-slowacja-ujawniamy-falszywy-syryjski-slad](https://www.rp.pl/spoleczenstwo/art39225401-dlaczego-przywrocono-kontrole-na-granicy-ze-slowacja-ujawniamy-falszywy-syryjski-slad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Brak nadzoru na Słowacji wykorzystywali Syryjczycy – ujawniamy powody przywrócenia kontroli na granicach.

## Joanna Ćwiek: Pandora Gate pokazuje prawdę o internecie. Zawiodło państwo, rodzice, a także szkoła
 - [https://www.rp.pl/komentarze/art39225261-joanna-cwiek-pandora-gate-pokazuje-prawde-o-internecie-zawiodlo-panstwo-rodzice-a-takze-szkola](https://www.rp.pl/komentarze/art39225261-joanna-cwiek-pandora-gate-pokazuje-prawde-o-internecie-zawiodlo-panstwo-rodzice-a-takze-szkola)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Dzieci nie są w żaden sposób chronione w sieci. Politycy PiS od lat zapowiadali, że się tym zajmą, ale nie zrobili nic.

## Jon Fosse od lat pojawiał się na noblowskiej giełdzie. Było niemal pewne, że kiedyś dostanie nagrodę
 - [https://www.rp.pl/literatura/art39226261-jon-fosse-od-lat-pojawial-sie-na-noblowskiej-gieldzie-bylo-niemal-pewne-ze-kiedys-dostanie-nagrode](https://www.rp.pl/literatura/art39226261-jon-fosse-od-lat-pojawial-sie-na-noblowskiej-gieldzie-bylo-niemal-pewne-ze-kiedys-dostanie-nagrode)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

64-letni Jon Fosse, któremu w walce ze społecznym lękiem i alkoholizmem pomógł katolicyzm, stworzył własny język – oszczędny i pełen powtórzeń.

## Już teraz latamy drogo. A ma być jeszcze drożej
 - [https://www.rp.pl/transport/art39225431-juz-teraz-latamy-drogo-a-ma-byc-jeszcze-drozej](https://www.rp.pl/transport/art39225431-juz-teraz-latamy-drogo-a-ma-byc-jeszcze-drozej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Linie lotnicze w Europie będą miały w tym roku rekordowe zyski. Dla rządów w krajach UE to impuls, by branżę lotniczą obłożyć nowymi podatkami.

## Mariusz Cieślik: Polacy nie mają powodu, żeby przepraszać za rasizm
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39225281-mariusz-cieslik-polacy-nie-maja-powodu-zeby-przepraszac-za-rasizm](https://www.rp.pl/opinie-polityczno-spoleczne/art39225281-mariusz-cieslik-polacy-nie-maja-powodu-zeby-przepraszac-za-rasizm)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Mówienie o polskim blackface czy niewolnictwie dowodzi braku elementarnej wiedzy. A także ekspansji wzorców made in USA. Amerykanie mają powody, żeby przepraszać za rasizm. My nie.

## Marzena Tabor-Olszewska: Najem krótkoterminowy to często koszmar dla sąsiadów
 - [https://www.rp.pl/opinie-prawne/art39225031-marzena-tabor-olszewska-najem-krotkoterminowy-to-czesto-koszmar-dla-sasiadow](https://www.rp.pl/opinie-prawne/art39225031-marzena-tabor-olszewska-najem-krotkoterminowy-to-czesto-koszmar-dla-sasiadow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Pijackie śpiewy do piątej nad ranem, bałagan, niszczenie klatek schodowych – to częste utrapienia wynikające z braku regulacji zasad wynajmu krótkoterminowego.

## Najem krótkoterminowy nie dla turystów. Unia i miasta chcą ograniczeń
 - [https://www.rp.pl/nieruchomosci/art39225041-najem-krotkoterminowy-nie-dla-turystow-unia-i-miasta-chca-ograniczen](https://www.rp.pl/nieruchomosci/art39225041-najem-krotkoterminowy-nie-dla-turystow-unia-i-miasta-chca-ograniczen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Wielkie europejskie miasta zaczynają walczyć z najmem krótkoterminowym. Unijne rozporządzenie może pomóc ucywilizować to zjawisko, ale i otworzyć furtkę do wprowadzania ograniczeń.

## Najem krótkoterminowy nie dla turystów. Unia może otworzyć furtkę do wprowadzania ograniczeń
 - [https://www.rp.pl/nieruchomosci/art39225041-najem-krotkoterminowy-nie-dla-turystow-unia-moze-otworzyc-furtke-do-wprowadzania-ograniczen](https://www.rp.pl/nieruchomosci/art39225041-najem-krotkoterminowy-nie-dla-turystow-unia-moze-otworzyc-furtke-do-wprowadzania-ograniczen)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Wielkie europejskie miasta zaczynają walczyć z najmem krótkoterminowym. Unijne rozporządzenie może pomóc ucywilizować to zjawisko, ale i otworzyć furtkę do wprowadzania ograniczeń.

## Ożywienie na rynku IPO raczej dopiero w 2024 r.
 - [https://www.rp.pl/gielda/art39225441-ozywienie-na-rynku-ipo-raczej-dopiero-w-2024-r](https://www.rp.pl/gielda/art39225441-ozywienie-na-rynku-ipo-raczej-dopiero-w-2024-r)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Liczba i wartość ofert publicznych na świecie w ciągu dziewięciu miesięcy 2023 roku spadła, ale pojawiają się sygnały ożywienia.

## Paweł Wojciechowski: Układ (prawie) domknięty
 - [https://www.rp.pl/opinie-ekonomiczne/art39225531-pawel-wojciechowski-uklad-prawie-domkniety](https://www.rp.pl/opinie-ekonomiczne/art39225531-pawel-wojciechowski-uklad-prawie-domkniety)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

„Cud cenowy” na Orlenie przypomniał czasy gospodarki centralnie planowanej, kiedy ręczne sterowanie cenami prowadziło do okresowych niedoborów, a następnie reglamentacji i kartek.

## Polski rynek nowych samochodów osobowych odrabia straty
 - [https://www.rp.pl/biznes/art39225451-polski-rynek-nowych-samochodow-osobowych-odrabia-straty](https://www.rp.pl/biznes/art39225451-polski-rynek-nowych-samochodow-osobowych-odrabia-straty)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Sprzedaż samochodów rośnie piąty miesiąc z rzędu. Blisko trzy czwarte nowych aut kupują firmy.

## Posiadacze kredytów o stałej stopie sfrustrowani. Są sposoby na obniżenie rat
 - [https://www.rp.pl/banki/art39225331-posiadacze-kredytow-o-stalej-stopie-sfrustrowani-sa-sposoby-na-obnizenie-rat](https://www.rp.pl/banki/art39225331-posiadacze-kredytow-o-stalej-stopie-sfrustrowani-sa-sposoby-na-obnizenie-rat)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Im bardziej spada WIBOR, tym większa nerwowość tych Polaków, którzy mają hipoteki ze stałym oprocentowaniem. Istnieją jednak sposoby na obniżenie rat, inne niż np. pozwanie banku.

## Przez oszczędności Polaków te sklepy zaczynają mieć problemy
 - [https://www.rp.pl/handel/art39225421-przez-oszczednosci-polakow-te-sklepy-zaczynaja-miec-problemy](https://www.rp.pl/handel/art39225421-przez-oszczednosci-polakow-te-sklepy-zaczynaja-miec-problemy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Spada sprzedaż w efekcie konsumenckich oszczędności. Na dodatek coraz więcej klientów właśnie te kategorie chce kupować tylko online. Sklepom stacjonarnym coraz trudniej utrzymać poziomy sprzedaży.

## Pół miliona w materacu. W USA wybuchła jedna z największych w historii afer korupcyjnych z udziałem senatora
 - [https://www.rp.pl/polityka/art39225551-pol-miliona-w-materacu-w-usa-wybuchla-jedna-z-najwiekszych-w-historii-afer-korupcyjnych-z-udzialem-senatora](https://www.rp.pl/polityka/art39225551-pol-miliona-w-materacu-w-usa-wybuchla-jedna-z-najwiekszych-w-historii-afer-korupcyjnych-z-udzialem-senatora)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Senator Bob Menendez, jego żona Nadine oraz trójka jej znajomych – lokalnych biznesmenów mających powiązania z rządem egipskim – zostali oskarżeni o udział w spisku, którego celem było przekierowanie federalnej pomocy i sprzedaży broni do Egiptu.

## Simone Biles wygrała z demonami. Sukces może oznaczać coś więcej niż bicie rekordów
 - [https://www.rp.pl/inne-sporty/art39226291-simone-biles-wygrala-z-demonami-sukces-moze-oznaczac-cos-wiecej-niz-bicie-rekordow](https://www.rp.pl/inne-sporty/art39226291-simone-biles-wygrala-z-demonami-sukces-moze-oznaczac-cos-wiecej-niz-bicie-rekordow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Simone Biles zdjęła z ramion ciężar świata i po dwóch latach wróciła na mistrzostwa świata silniejsza niż kiedykolwiek – przede wszystkim psychicznie.

## Sondaż: Polacy mniej chętni, by pomagać Ukrainie
 - [https://www.rp.pl/spoleczenstwo/art39225461-sondaz-polacy-mniej-chetni-by-pomagac-ukrainie](https://www.rp.pl/spoleczenstwo/art39225461-sondaz-polacy-mniej-chetni-by-pomagac-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Przeciwni przedłużaniu pomocy dla uchodźców z Ukrainy są w większości wyborcy partii opozycyjnych, a nie PiS - wynika z sondażu IBRiS dla "Rzeczpospolitej".

## Sytuacja w Poczcie Polskiej jest niewesoła. Może dojść do strajku
 - [https://www.rp.pl/biznes/art39225391-sytuacja-w-poczcie-polskiej-jest-niewesola-moze-dojsc-do-strajku](https://www.rp.pl/biznes/art39225391-sytuacja-w-poczcie-polskiej-jest-niewesola-moze-dojsc-do-strajku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

W środę w państwowym molochu ma dojść do strajku. Władze spółki apelują o zawieszenie sporu do grudnia, co argumentują sytuacją finansową – dowiedziała się „Rzeczpospolita”.

## Tomasz Pietryga: Regulacja najmu krótkoterminowego zaszkodzi wolnościom obywatelskim
 - [https://www.rp.pl/opinie-prawne/art39225021-tomasz-pietryga-regulacja-najmu-krotkoterminowego-zaszkodzi-wolnosciom-obywatelskim](https://www.rp.pl/opinie-prawne/art39225021-tomasz-pietryga-regulacja-najmu-krotkoterminowego-zaszkodzi-wolnosciom-obywatelskim)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Bruksela, zabierając się za uregulowanie krótkoterminowego najmu, chce dołożyć kolejną regulację, która zaszkodzi nie tylko gospodarce, ale też wolnościom obywatelskim.

## Trzecia Droga na koniec kampanii na celowniku PiS. Jarosław Kaczyński zmienił taktykę
 - [https://www.rp.pl/wybory/art39225371-trzecia-droga-na-koniec-kampanii-na-celowniku-pis-jaroslaw-kaczynski-zmienil-taktyke](https://www.rp.pl/wybory/art39225371-trzecia-droga-na-koniec-kampanii-na-celowniku-pis-jaroslaw-kaczynski-zmienil-taktyke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

PiS chce zawalczyć o część wyborców PSL – wynika z naszych informacji. Stąd zmiana taktyki w ostatnich dniach.

## U premiera Morawieckiego na bogato. Budżet jego kancelarii przebił sufit
 - [https://www.rp.pl/polityka/art39225341-u-premiera-morawieckiego-na-bogato-budzet-jego-kancelarii-przebil-sufit](https://www.rp.pl/polityka/art39225341-u-premiera-morawieckiego-na-bogato-budzet-jego-kancelarii-przebil-sufit)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Po raz pierwszy w historii roczny budżet Kancelarii Premiera ma przebić barierę 2 mld zł. Zdaniem rządu wydatki są uzasadnione, opozycja uważa inaczej.

## Unia Europejska będzie większa? Wojna rewiduje poszerzenie
 - [https://www.rp.pl/polityka/art39225521-unia-europejska-bedzie-wieksza-wojna-rewiduje-poszerzenie](https://www.rp.pl/polityka/art39225521-unia-europejska-bedzie-wieksza-wojna-rewiduje-poszerzenie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Przywódcy 44 państw mieli nakreślić wizję Wspólnoty od Lizbony po Kijów. Zełenskiego bardziej martwi jednak, jak jego kraj przetrwa kolejny rok.

## Unia może nałożyć cła na chińskie samochody elektryczne. Będzie odwet Pekinu?
 - [https://www.rp.pl/biznes/art39225471-unia-moze-nalozyc-cla-na-chinskie-samochody-elektryczne-bedzie-odwet-pekinu](https://www.rp.pl/biznes/art39225471-unia-moze-nalozyc-cla-na-chinskie-samochody-elektryczne-bedzie-odwet-pekinu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Bruksela wszczęła postępowanie w sprawie subsydiowania przez Pekin chińskich producentów aut elektrycznych. Aby obronić się przed ich zalewem, europejscy producenci będą musieli się mocno napracować.

## Zuzanna Dąbrowska: Działacze opozycji już nie są wobec siebie złośliwi. Prawda czasu, prawda etapu
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39225361-zuzanna-dabrowska-dzialacze-opozycji-juz-nie-sa-wobec-siebie-zlosliwi-prawda-czasu-prawda-etapu](https://www.rp.pl/opinie-polityczno-spoleczne/art39225361-zuzanna-dabrowska-dzialacze-opozycji-juz-nie-sa-wobec-siebie-zlosliwi-prawda-czasu-prawda-etapu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Zachowanie partii politycznych na ostatnim etapie kampanii to obietnica tego, jaką rzeczywistość polityczną zgotują nam po wyborach.

## Zuzanna Dąbrowska: Nastał czas zgody na opozycji
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39225361-zuzanna-dabrowska-nastal-czas-zgody-na-opozycji](https://www.rp.pl/opinie-polityczno-spoleczne/art39225361-zuzanna-dabrowska-nastal-czas-zgody-na-opozycji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T01:00:00+00:00

Zachowanie partii politycznych na ostatnim etapie kampanii to obietnica tego, jaką rzeczywistość polityczną zgotują nam po wyborach.

## LOT ma strategię na pięć lat. A w niej 20 nowych tras, w tym do Azji i Ameryki
 - [https://turystyka.rp.pl/linie-lotnicze/art39227031-lot-ma-strategie-na-piec-lat-a-w-niej-20-nowych-tras-w-tym-do-azji-i-ameryki](https://turystyka.rp.pl/linie-lotnicze/art39227031-lot-ma-strategie-na-piec-lat-a-w-niej-20-nowych-tras-w-tym-do-azji-i-ameryki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-10-06T00:37:55+00:00

17 milionów pasażerów rocznie, 35 samolotów więcej, 20 nowych kierunków i 640 milionów złotych zysku – zapowiedział w strategii na najbliższych pięć lat prezes LOT-u Michał Fijoł.

