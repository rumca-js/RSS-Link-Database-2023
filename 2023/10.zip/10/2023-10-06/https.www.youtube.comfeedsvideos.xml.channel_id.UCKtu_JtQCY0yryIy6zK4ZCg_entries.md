# Source:Marc Brunet, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg, language:en-US

## This is by FAR the #1 art skill 🛑 #drawingtips #learntodraw  #howtodraw
 - [https://www.youtube.com/watch?v=sqltfkMIdcw](https://www.youtube.com/watch?v=sqltfkMIdcw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKtu_JtQCY0yryIy6zK4ZCg
 - date published: 2023-10-06T01:30:49+00:00

👨‍🎨 Don't miss out on the HUGE SALE for my ART School program here! ➡️ cgart.school

