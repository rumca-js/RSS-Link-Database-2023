# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## Wheel of Time Season 3 Is Going to Be 'Massive'
 - [https://gizmodo.com/wheel-of-time-prime-video-s3-rosamund-pike-fantasy-show-1850907492](https://gizmodo.com/wheel-of-time-prime-video-s3-rosamund-pike-fantasy-show-1850907492)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-10-06T21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/d1f561c03f302352ee30f3ab9bc786aa.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/wheel-of-time-s2-review-prime-video-rosamund-pike-1850757798">Prime Video’s The Wheel of Time</a>, adapted from the Robert Jordan book series, just dropped its <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/wheel-of-time-season-2-finale-prime-video-fantasy-show-1850897619">season two finale</a>. A third installment <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/san-diego-comic-con-2022-wheel-of-time-renewed-season-3-1849179744">was announced back in 2022</a> at San Diego Comic-Con, and stars Rosamund Pike and Daniel Henney have teased what fans might expect when <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/prime-video-wheel-of-time-s1-catchu

## Glowing Mammals Are Really Common, Actually
 - [https://gizmodo.com/biofluorescent-mammals-glowing-animals-uv-light-cats-1850906932](https://gizmodo.com/biofluorescent-mammals-glowing-animals-uv-light-cats-1850906932)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-10-06T17:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/8a7529b694baced65494aa07727c3360.jpg" /><p>Move over monotremes and the range of rodents known to glow: over one hundred other furry creatures do, too, new research shows, vastly increasing the number of mammals known to show the spooky trait.<br /></p><p><a href="https://gizmodo.com/biofluorescent-mammals-glowing-animals-uv-light-cats-1850906932">Read more...</a></p>

## 12 Times Elon Musk's Headline Decapitation Hilariously Backfired on Him
 - [https://gizmodo.com/twitter-x-musk-headline-removal-backfired-on-him-1850906283](https://gizmodo.com/twitter-x-musk-headline-removal-backfired-on-him-1850906283)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-10-06T16:55:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/e88b3cb7c0c79008d4b1c07a4bf2aa6a.jpg" /><p>Of all the bizarre decisions to come out of Twitter following Elon Musk’s takeover last October, removing headlines might be the dumbest. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/elon-musks-x-twitter-purges-headlines-from-news-links-1850902113">The social media platform has officially beheaded all links</a> in a curious crusade against news organizations and the platform’s shrinking user base. </p><p><a href="https://gizmodo.com/twitter-x-musk-headline-removal-backfired-on-him-1850906283">Read more...</a></p>

## DIRECTV Is the Latest Provider to Announce a Price Hike
 - [https://gizmodo.com/directv-streaming-satellite-price-increase-sports-fees-1850905071](https://gizmodo.com/directv-streaming-satellite-price-increase-sports-fees-1850905071)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-10-06T13:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/89e4216dccf0314b0e419349dab50ed4.png" /><p>Hey, if the likes of <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/netflix-ad-supported-plans-getting-another-price-hike-1850895876">Netflix</a> and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/youtube-raises-the-price-for-premium-1850658998">YouTube Premium</a> and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/discovery-plus-price-increase-warner-bros-streaming-1850896850">Discovery+</a> can increase their prices—and they’re just <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/how-much-have-streaming-prices-increased-1850661604">a few recent services that’ve done so</a>—why not DIRECTV? As of November 5, DIRECTV’s satellite service and DIRECTV STREAM customers will both be paying more.

## Microsoft Reportedly Hopes to Close Activision Deal Next Week
 - [https://gizmodo.com/microsoft-hopes-to-close-activision-deal-next-week-1850906033](https://gizmodo.com/microsoft-hopes-to-close-activision-deal-next-week-1850906033)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-10-06T12:25:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/39671add7903ec4119714aa9ce1c96bf.jpg" /><p>The biggest acquisition in video game history appears to be coming to a close. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/microsoft-to-swallow-activision-blizzard-for-68-7-bill-1848375237">After Microsoft offered to buy Activision Blizzard</a> nearly two years ago—and faced a barrage of government hurdles along the way—the tech company is reportedly readying to close the sale.</p><p><a href="https://gizmodo.com/microsoft-hopes-to-close-activision-deal-next-week-1850906033">Read more...</a></p>

