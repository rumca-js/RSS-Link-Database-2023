# Source:Times of India, URL:http://timesofindia.indiatimes.com/rssfeedstopstories.cms, language:en-gb

## UK reaffirms position after Canada-India diplomatic spat
 - [https://timesofindia.indiatimes.com/india/uk-reaffirms-position-after-canada-india-diplomatic-spat/articleshow/104224156.cms](https://timesofindia.indiatimes.com/india/uk-reaffirms-position-after-canada-india-diplomatic-spat/articleshow/104224156.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T22:03:33+00:00

On Friday, Britain restated its stance emphasizing the importance of all nations adhering to sovereignty and the principles of law. This came in response to reports indicating that India had requested Canada to recall 41 diplomats.

## Sikkim flood toll rises to 44, list of missing doubles to 142
 - [https://timesofindia.indiatimes.com/india/sikkim-flash-flood-death-toll-rises-to-44-list-of-missing-doubles-to-142/articleshow/104223878.cms](https://timesofindia.indiatimes.com/india/sikkim-flash-flood-death-toll-rises-to-44-list-of-missing-doubles-to-142/articleshow/104223878.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T21:00:28+00:00

The death toll from the flash flood in North Sikkim has risen to 44, with six more bodies being found in neighbouring Bengal. The number of missing people has also increased to 142. Rescue attempts have been hindered by bad weather conditions, and families of the missing are anxiously waiting for news. The Sikkim government has announced compensation for the families of the deceased, and priority will be given to rescuing the elderly, infirm, and those needing medical assistance.

## After 'Ajit split', Sharad Pawar meets Congress netas to discuss alliance
 - [https://timesofindia.indiatimes.com/india/after-ajit-split-ncp-chief-sharad-pawar-meets-congress-netas-to-discuss-alliance/articleshow/104223801.cms](https://timesofindia.indiatimes.com/india/after-ajit-split-ncp-chief-sharad-pawar-meets-congress-netas-to-discuss-alliance/articleshow/104223801.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T20:32:37+00:00

NCP chief Sharad Pawar met with Congress President Mallikarjun Kharge and Rahul Gandhi to discuss the way forward for the opposition in India and Maharashtra. They also discussed the INDIA alliance and invited Rahul Gandhi to visit an agricultural institute in Baramati. The discussions included strategy for national polls and for Maharashtra, where NCP will be part of an alliance with Shiv Sena and Congress.

## This school goes to the doorstep of dropouts
 - [https://timesofindia.indiatimes.com/india/this-school-goes-to-the-doorstep-of-dropouts/articleshow/104223767.cms](https://timesofindia.indiatimes.com/india/this-school-goes-to-the-doorstep-of-dropouts/articleshow/104223767.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T20:23:18+00:00

A teacher in Uttar Pradesh, India, has taken the initiative to bring school to students who were not attending. Amit Verma, an assistant teacher with 14 years of experience, took the entire Class 4 - 33 students - to the house of two children who had stopped coming to school. He conducted classes outside their home to demonstrate the importance of education. His efforts were successful, and the two children have since returned to school.

## 38 lakh foreigners visited India between Apr-Oct 2022
 - [https://timesofindia.indiatimes.com/india/38-lakh-foreigners-visited-india-between-april-to-october-2022-bangladeshis-topped-list/articleshow/104223704.cms](https://timesofindia.indiatimes.com/india/38-lakh-foreigners-visited-india-between-april-to-october-2022-bangladeshis-topped-list/articleshow/104223704.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T20:06:58+00:00

According to the annual report of India's home ministry, over 38.3 lakh foreigners visited India between April and October 2022. The largest number of arrivals were from Bangladesh, followed by the US and UK. The report also highlighted a significant increase in the number of Bangladeshi and US citizens visiting India compared to the previous year. However, the total number of foreign visitors to India is still below pre-Covid levels.

## Uttarakhand okays home mini-bar licence policy, but with riders
 - [https://timesofindia.indiatimes.com/india/uttarakhand-okays-home-mini-bar-licence-policy-but-with-riders/articleshow/104223666.cms](https://timesofindia.indiatimes.com/india/uttarakhand-okays-home-mini-bar-licence-policy-but-with-riders/articleshow/104223666.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:51:24+00:00

The latest excise policy for 2023-24 by the Uttarakhand government includes a new provision allowing individuals to obtain a license for maintaining mini-bars at their residences, subject to specific conditions. Upon approval, license holders are permitted to store up to nine liters of Indian made foreign liquor, 18 liters of foreign alcohol, nine liters of wine, and 15.6 liters of beer at home.

## 2 identical twins are company, but 10 of them a class apart
 - [https://timesofindia.indiatimes.com/india/2-identical-twins-are-company-but-10-of-them-a-class-apart/articleshow/104223657.cms](https://timesofindia.indiatimes.com/india/2-identical-twins-are-company-but-10-of-them-a-class-apart/articleshow/104223657.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:50:38+00:00

A high school in India has an unusual situation with five sets of identical twins studying in the same class. The teacher, Juliet Lona D'Sa, struggles to differentiate between the twins and has resorted to calling out their names without making eye contact. This method works for the most part. The twins have been studying together since grade one and will continue to do so until they complete high school.

## Teacher shot in leg by students claiming to be 'gangsters'
 - [https://timesofindia.indiatimes.com/india/teacher-shot-in-leg-by-students-claiming-to-be-gangsters/articleshow/104223630.cms](https://timesofindia.indiatimes.com/india/teacher-shot-in-leg-by-students-claiming-to-be-gangsters/articleshow/104223630.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:42:14+00:00

Two class 12 students in Agra shot their tuition teacher in the leg and threatened to shoot him 40 more times in a video they recorded. The incident was inspired by gangster videos. The students were arrested and charged with attempted murder and criminal intimidation. One of the students was upset that the teacher had informed his family about his affair.

## Want to be judge, be tech-friendly: CJI DY Chandrachud
 - [https://timesofindia.indiatimes.com/india/want-to-be-judge-be-tech-friendly-cji/articleshow/104223595.cms](https://timesofindia.indiatimes.com/india/want-to-be-judge-be-tech-friendly-cji/articleshow/104223595.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:34:39+00:00

The Chief Justice of India, D Y Chandrachud, has urged all high courts to embrace technology and implement virtual modes of hearing cases within two weeks. He criticized the Allahabad High Court and the Bombay High Court for being resistant to technology, despite the Supreme Court's successful adoption of digital platforms for conducting court proceedings.

## Canada shifts most of its diplomats posted in India to S'pore, Malaysia
 - [https://timesofindia.indiatimes.com/india/canada-shifts-most-of-its-diplomats-posted-in-india-to-singapore-malaysia/articleshow/104223552.cms](https://timesofindia.indiatimes.com/india/canada-shifts-most-of-its-diplomats-posted-in-india-to-singapore-malaysia/articleshow/104223552.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:26:11+00:00

Canada has reportedly relocated the majority of its diplomats in India to Malaysia and Singapore, in response to the Indian government's request to withdraw 41 diplomats. The move comes after Canadian Prime Minister Justin Trudeau accused Indian agents of involvement in the killing of a Canadian national. Concerns have been raised about potential delays in visa processing for Indian nationals, particularly students. The US has expressed support for Canada's investigation into the killing, while also acknowledging the potential for disinformation campaigns in the India-Canada dispute.

## Indian-origin family of four found dead in US home
 - [https://timesofindia.indiatimes.com/nri/us-canada-news/indian-origin-family-of-four-found-dead-in-us-home/articleshow/104223471.cms](https://timesofindia.indiatimes.com/nri/us-canada-news/indian-origin-family-of-four-found-dead-in-us-home/articleshow/104223471.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:21:04+00:00

An Indian-origin couple and their two children were found dead in their home in New Jersey. The authorities are treating the case as a homicide and have launched an investigation. The victims have been identified as Tej Pratap Singh, Sonal Parihar, and their two children.

## Left-wing extremism will be finished in 2 years: Amit Shah
 - [https://timesofindia.indiatimes.com/india/left-wing-extremism-will-be-finished-in-2-years-union-home-minister-amit-shah/articleshow/104223479.cms](https://timesofindia.indiatimes.com/india/left-wing-extremism-will-be-finished-in-2-years-union-home-minister-amit-shah/articleshow/104223479.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T19:16:31+00:00

Home Minister Amit Shah has stated that Left-wing extremism in India is in its last phase and will be completely eradicated within the next two years. The government's priorities include deploying central forces to counter Maoists, rationalizing development, and establishing security camps in areas where the administrative machinery has not been able to make inroads.

## Ramaswamy slams Zelenskyy for seeking funds for elections
 - [https://timesofindia.indiatimes.com/world/us/putin-is-bad-doesnt-mean-ukraine-is-good-ramaswamy-slams-zelenskyy-for-seeking-funds-for-elections/articleshow/104223012.cms](https://timesofindia.indiatimes.com/world/us/putin-is-bad-doesnt-mean-ukraine-is-good-ramaswamy-slams-zelenskyy-for-seeking-funds-for-elections/articleshow/104223012.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T18:11:48+00:00

Indian-American entrepreneur and Republican leader Vivek Ramaswamy criticized Ukrainian President Volodymyr Zelenskyy, stating that just because Russian President Vladimir Putin is "bad," doesn't mean Ukraine is good. Ramaswamy accused Zelenskyy of banning opposition parties, consolidating media as state broadcaster, having a corrupt record, and honouring a Nazi collaborator in the Canadian Parliament.

## 'Ajit's lawyers told EC that Sharad Pawar behaved like a dictator'
 - [https://timesofindia.indiatimes.com/india/ncp-leader-says-ajit-pawars-lawyers-told-ec-that-sharad-pawar-behaved-like-a-dictator/articleshow/104222489.cms](https://timesofindia.indiatimes.com/india/ncp-leader-says-ajit-pawars-lawyers-told-ec-that-sharad-pawar-behaved-like-a-dictator/articleshow/104222489.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T17:21:20+00:00

Ajit Pawar, who has claimed leadership of the Nationalist Congress Party (NCP), accused his uncle Sharad Pawar of behaving like a dictator and not following democratic principles. Ajit Pawar, who split from the NCP to join the BJP government, claimed support from 42 MLAs, six MLCs, and two MPs from Maharashtra.

## Russia claims to have successfully tested nuclear-power 9M730 Burevestnik
 - [https://timesofindia.indiatimes.com/world/rest-of-world/russia-claims-to-have-successfully-tested-its-nuclear-powered-nuclear-armed-cruise-missile-all-you-need-to-know-about-9m730-burevestnik/articleshow/104221941.cms](https://timesofindia.indiatimes.com/world/rest-of-world/russia-claims-to-have-successfully-tested-its-nuclear-powered-nuclear-armed-cruise-missile-all-you-need-to-know-about-9m730-burevestnik/articleshow/104221941.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T17:01:51+00:00

Russia has claimed to have successfully tested its nuclear-powered, nuclear-armed cruise missile, the Burevestnik. This missile is part of a series of new strategic weapons unveiled by Russian President Vladimir Putin in 2018. Previous tests of the Burevestnik were plagued by failures and a fatal accident in 2019. The missile is described as a subsonic nuclear-powered cruise missile with global reach and the ability to bypass missile defense systems. Concerns have been raised about the implications of this weapon, both strategically and environmentally.

## Asian Games: Full India schedule on October 7
 - [https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/hangzhou-asian-games-full-india-schedule-and-results-on-october-7-live-updates-live-streaming-details/articleshow/104221980.cms](https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/hangzhou-asian-games-full-india-schedule-and-results-on-october-7-live-updates-live-streaming-details/articleshow/104221980.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T16:32:54+00:00

India is already guaranteed to add seven more medals to its tally across various disciplines on Saturday, including kabaddi (2), archery (3), badminton (1), and cricket (1). This achievement reflects India's growing prowess and success in the world of sports on the Asian stage.

## Columbus Day vs. Indigenous Peoples' Day
 - [https://timesofindia.indiatimes.com/world/us/columbus-day-vs-indigenous-peoples-day-a-clash-of-historical-perspectives/articleshow/104221875.cms](https://timesofindia.indiatimes.com/world/us/columbus-day-vs-indigenous-peoples-day-a-clash-of-historical-perspectives/articleshow/104221875.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T16:26:56+00:00

The clash between Columbus Day and Indigenous Peoples' Day arises from differing perspectives on the historical significance of Christopher Columbus's arrival in the Americas and the treatment of Indigenous peoples. Columbus Day celebrates European exploration and the founding of the New World, while Indigenous Peoples' Day highlights the history and contributions of Indigenous communities and recognizes the injustices they endured.

## WC: Pakistan brush aside Netherlands to make winning start
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/odi-world-cup-pakistan-brush-aside-netherlands-to-make-winning-start/articleshow/104221900.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/odi-world-cup-pakistan-brush-aside-netherlands-to-make-winning-start/articleshow/104221900.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T16:23:14+00:00

Pakistan's Mohammad Rizwan and Saud Shakeel hit identical half-centuries in an otherwise underwhelming batting effort in their World Cup opener against the Netherlands on Friday, before the bowlers sealed a routine 81-run win for the 1992 champions.

## India-made image data processing tech aids unravel cosmic secrets
 - [https://timesofindia.indiatimes.com/india/india-made-image-data-processing-tech-aids-unravel-cosmic-secrets/articleshow/104221748.cms](https://timesofindia.indiatimes.com/india/india-made-image-data-processing-tech-aids-unravel-cosmic-secrets/articleshow/104221748.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T16:12:25+00:00

The Automated Radio Telescope Image Processing Pipeline (ARTIP), developed by global technology consultancy firm Thoughtworks, has aided in significant discoveries made by the MeerKAT Telescope in South Africa. ARTIP has processed over 1PB of MeerKAT data, leading to the detection of the hydroxyl radical and the identification of huge hydrogen atoms in distant galaxies. The pipeline is highly configurable and can be used on data generated by other telescopes as well.

## Reliance Retail to raise Rs 4,966.80 crore from ADIA
 - [https://timesofindia.indiatimes.com/business/india-business/reliance-retail-to-raise-rs-4966-80-crore-from-abu-dhabi-investment-authority/articleshow/104221696.cms](https://timesofindia.indiatimes.com/business/india-business/reliance-retail-to-raise-rs-4966-80-crore-from-abu-dhabi-investment-authority/articleshow/104221696.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T16:00:20+00:00



## Was there a huge blast near Pak army's nuclear facility?
 - [https://timesofindia.indiatimes.com/world/pakistan/was-there-a-huge-blast-near-pakistan-armys-nuclear-facility-heres-what-a-top-official-said/articleshow/104218913.cms](https://timesofindia.indiatimes.com/world/pakistan/was-there-a-huge-blast-near-pakistan-armys-nuclear-facility-heres-what-a-top-official-said/articleshow/104218913.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T14:53:50+00:00



## 'He is not technically out for the first game': Dravid on Gill
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/he-is-not-technically-out-for-the-first-game-rahul-dravid-wants-to-wait-for-36-hours-before-taking-a-call-on-shubman-gill/articleshow/104220549.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/he-is-not-technically-out-for-the-first-game-rahul-dravid-wants-to-wait-for-36-hours-before-taking-a-call-on-shubman-gill/articleshow/104220549.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T14:52:25+00:00

The BCCI has not officially confirmed the nature of Shubman Gill's illness. However, despite the uncertainty surrounding Gill's participation, head coach Rahul Dravid remains optimistic, as there are still 36 hours remaining before the crucial match.

## F1 2023: Verstappen leads Qatar GP FP1, looks set to seal Championship tomorrow
 - [https://timesofindia.indiatimes.com/auto/motorsports/f1-2023-verstappen-leads-qatar-gp-fp1-looks-set-to-seal-championship-tomorrow/articleshow/104220294.cms](https://timesofindia.indiatimes.com/auto/motorsports/f1-2023-verstappen-leads-qatar-gp-fp1-looks-set-to-seal-championship-tomorrow/articleshow/104220294.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T14:46:52+00:00

Max Verstappen only needs to finish sixth or higher in the Sprint race regardless of where his teammate finishes to secure his third-straight World Championship title.

## Dhankar slams Gehlot for questioning VP's Rajasthan visits
 - [https://timesofindia.indiatimes.com/india/he-has-neither-read-law-nor-constitution-jagdeep-dhankars-strong-retort-to-ashok-gehlot-over-vps-rajasthan-visits/articleshow/104218623.cms](https://timesofindia.indiatimes.com/india/he-has-neither-read-law-nor-constitution-jagdeep-dhankars-strong-retort-to-ashok-gehlot-over-vps-rajasthan-visits/articleshow/104218623.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:38:46+00:00

Vice-President Jagdeep Dhankhar criticized Rajasthan chief minister Ashok Gehlot for questioning his frequent visits to the state, stating that people in constitutional positions should not be dragged into politics. Dhankhar emphasized the need for respect for constitutional positions and clarified that his visits were in accordance with the Constitution and for the welfare of the people. The BJP also criticized Gehlot for his remarks, suggesting that he is not interested in the state's development.

## Govt issues notices to X to remove child sexual abuse content
 - [https://timesofindia.indiatimes.com/india/govt-issues-notices-to-x-youtube-telegram-to-remove-child-sexual-abuse-content-warns-of-action/articleshow/104218932.cms](https://timesofindia.indiatimes.com/india/govt-issues-notices-to-x-youtube-telegram-to-remove-child-sexual-abuse-content-warns-of-action/articleshow/104218932.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:28:09+00:00

The Indian Ministry of Electronics and IT has issued notices to social media platforms X (formerly Twitter), YouTube, and Telegram, instructing them to remove Child Sexual Abuse Material (CSAM) from their platforms. The notices highlight the importance of prompt and permanent removal of such content and the implementation of proactive measures to prevent its dissemination. Failure to comply may result in the withdrawal of legal liability protection for the platforms.

## In a first, a century of medals assured for India at Asian Games
 - [https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/in-a-first-a-century-of-medals-assured-for-india-at-asian-games/articleshow/104218756.cms](https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/in-a-first-a-century-of-medals-assured-for-india-at-asian-games/articleshow/104218756.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:21:11+00:00

India are poised to celebrate a historic century of medals at the Asian Games after wrestlers bagged three medals, the sport of sepaktakraw added a historic bronze and the men's hockey team reclaimed the gold to take the country's tally to 95 in Hangzhou on Friday.

## Priyanka promises caste census, housing for poor in Chhattisgarh
 - [https://timesofindia.indiatimes.com/india/priyanka-gandhi-promises-caste-census-housing-for-poor-in-chhattisgarh/articleshow/104218556.cms](https://timesofindia.indiatimes.com/india/priyanka-gandhi-promises-caste-census-housing-for-poor-in-chhattisgarh/articleshow/104218556.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:15:18+00:00

Congress General Secretary Priyanka Gandhi Vadra pledged to conduct a caste census in Chhattisgarh if the party remains in power after the upcoming elections. She also promised to construct one million houses for the poor. Priyanka criticized the BJP and Prime Minister Narendra Modi, highlighting issues such as unemployment, privatization of PSUs, and the alleged diversion of public funds for personal use. She emphasized the successful government schemes implemented by the Congress and stressed the importance of trust in the party's leadership.

## Canada plays into Russian narrative that it is 'denazifying' Ukraine
 - [https://timesofindia.indiatimes.com/world/rest-of-world/standing-ovation-for-nazi-veteran-canada-plays-into-russian-narrative-that-it-is-denazifying-ukraine/articleshow/104214420.cms](https://timesofindia.indiatimes.com/world/rest-of-world/standing-ovation-for-nazi-veteran-canada-plays-into-russian-narrative-that-it-is-denazifying-ukraine/articleshow/104214420.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:04:17+00:00

Canadian Prime Minister Justin Trudeau and his lawmakers unintentionally gave Russian President Vladimir Putin a reason to justify his invasion of Ukraine. This happened after the Canadian parliament gave a standing ovation to a Ukrainian World War II veteran who had fought alongside the Nazis. The incident played into Putin's narrative that he invaded Ukraine to "denazify" the country. Putin criticized the incident and stated that it confirmed Russia's goal of denazifying Ukraine.

## 'INDIA will win': Pawar meets Kharge and Rahul in Delhi
 - [https://timesofindia.indiatimes.com/india/india-will-win-sharad-pawar-meets-mallikarjun-kharge-and-rahul-gandhi-in-delhi/articleshow/104218442.cms](https://timesofindia.indiatimes.com/india/india-will-win-sharad-pawar-meets-mallikarjun-kharge-and-rahul-gandhi-in-delhi/articleshow/104218442.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T13:01:49+00:00



## HS Prannoy's historic Asian Games bronze is worth the 'wait' in gold
 - [https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/legs-gone-back-injured-body-at-50-hs-prannoys-historic-asian-games-bronze-is-worth-the-wait-in-gold/articleshow/104217769.cms](https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/legs-gone-back-injured-body-at-50-hs-prannoys-historic-asian-games-bronze-is-worth-the-wait-in-gold/articleshow/104217769.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T12:54:19+00:00

The battles of an athlete often go beyond what the fans see, enjoy, celebrate or get frustrated and disappointed with. What's on show is the player giving it his or her best. What the eyes see takes the shape of opinion. HS Prannoy's bronze -- a men's individual Asian Games medal in badminton after 41 years for India -- is a story on those lines.

## 'Leasing costs to drop by over $1 billion,' says govt
 - [https://timesofindia.indiatimes.com/business/india-business/leasing-costs-to-drop-by-over-1-billion-says-government-after-ensuring-no-more-goair-kind-of-holding-on-to-planes-in-future/articleshow/104217658.cms](https://timesofindia.indiatimes.com/business/india-business/leasing-costs-to-drop-by-over-1-billion-says-government-after-ensuring-no-more-goair-kind-of-holding-on-to-planes-in-future/articleshow/104217658.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T12:38:58+00:00

India's promise that its airports will in future not become the graveyard for leased aircraft and engines stuck with bankrupt airlines - like grounded GoAir's fleet at present - has led to aircraft leasing watchdog Aviation Working Group (AWG) lifting its red flags recently issued for leasing planes to desi carriers.

## Indian men's hockey team reclaims Asian Games gold after 9 years
 - [https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/india-mens-hockey-team-reclaims-asian-games-gold-after-9-years-qualify-for-paris-olympics/articleshow/104217722.cms](https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/india-mens-hockey-team-reclaims-asian-games-gold-after-9-years-qualify-for-paris-olympics/articleshow/104217722.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T12:35:22+00:00

A dominant Indian men's hockey team thrashed defending champions Japan 5-1 to reclaim the Asian Games gold medal after nine years and qualify for next year's Paris Olympics.

## Funds came from China: Delhi Police FIR against NewsClick
 - [https://timesofindia.indiatimes.com/india/funds-came-from-china-to-disrupt-indias-sovereignty-delhi-police-fir-against-newsclick/articleshow/104216891.cms](https://timesofindia.indiatimes.com/india/funds-came-from-china-to-disrupt-indias-sovereignty-delhi-police-fir-against-newsclick/articleshow/104216891.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T12:05:58+00:00



## Saint-Gobain to invest Rs 3,400 crore in Tamil Nadu
 - [https://timesofindia.indiatimes.com/business/india-business/saint-gobain-to-invest-rs-3400-crore-in-tamil-nadu/articleshow/104216034.cms](https://timesofindia.indiatimes.com/business/india-business/saint-gobain-to-invest-rs-3400-crore-in-tamil-nadu/articleshow/104216034.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T11:43:38+00:00

Saint-Gobain, the French construction and industrial materials company, announced that it will invest Rs 3,400 crore in greenfield and brownfield projects in Tamil Nadu. This brings the company's total investment in the state to over Rs 8,000 crore. The investment will be made in various businesses including glasswool, gypsum plasterboard, acoustic ceiling, float glass, and solar glass. Saint-Gobain has a manufacturing facility and a research facility in Tamil Nadu. The company had sales of €51.2 billion in 2022 and employs 168,000 people worldwide.

## Canada shifts some diplomats to Kuala Lampur, Singapore: Report
 - [https://timesofindia.indiatimes.com/india/canada-moves-some-of-its-diplomats-in-india-to-kuala-lampur-singapore-after-new-delhis-demand-for-parity-report/articleshow/104213592.cms](https://timesofindia.indiatimes.com/india/canada-moves-some-of-its-diplomats-in-india-to-kuala-lampur-singapore-after-new-delhis-demand-for-parity-report/articleshow/104213592.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T10:41:14+00:00

Canada has moved several of its diplomats stationed outside New Delhi to either Kuala Lumpur or Singapore, following a request from India to reduce its diplomatic staff. The move comes amid an ongoing row between the two countries after Canadian Prime Minister Justin Trudeau linked Indian agents to the killing of a Khalistani terrorist. India has reportedly given Canada until October 10 to reduce its diplomatic staff to match the number of Indian diplomats in Canada.

## Hospital deaths: Bombay HC pulls up Maharashtra govt
 - [https://timesofindia.indiatimes.com/city/mumbai/hospital-deaths-bombay-hc-pulls-up-maharashtra-govt-says-state-cant-escape-onus/articleshow/104213620.cms](https://timesofindia.indiatimes.com/city/mumbai/hospital-deaths-bombay-hc-pulls-up-maharashtra-govt-says-state-cant-escape-onus/articleshow/104213620.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T10:35:42+00:00

The Bombay high court on Friday told the Maharashtra government that it cannot escape its responsibility by citing the high burden of patients coming to its hospitals while hearing suo motu a PIL following deaths in two state-run hospitals in Nanded and Sambhajinagar.

## Rajasthan to have 3 new districts: CM Ashok Gehlot
 - [https://timesofindia.indiatimes.com/city/jaipur/rajasthan-to-have-three-new-districts-cm-ashok-gehlot/articleshow/104212826.cms](https://timesofindia.indiatimes.com/city/jaipur/rajasthan-to-have-three-new-districts-cm-ashok-gehlot/articleshow/104212826.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T10:13:00+00:00

Gehlot posted on X that the decision has been taken "in consonance with a high-level panel". He added that the government would keep addressing delimitation issues "as per the panel's recommendation in future too."

## Sikkim flash flood toll 40, army readies airlift rescue op
 - [https://timesofindia.indiatimes.com/city/kolkata/sikkim-flash-flood-toll-rises-to-40-as-army-readies-airlift-rescue-operations-bodies-recovered-in-west-bengal/articleshow/104212522.cms](https://timesofindia.indiatimes.com/city/kolkata/sikkim-flash-flood-toll-rises-to-40-as-army-readies-airlift-rescue-operations-bodies-recovered-in-west-bengal/articleshow/104212522.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T10:04:22+00:00

The flash floods struck the remote state of Sikkim on Wednesday following the sudden bursting of a high-altitude glacial lake near the borders of India, China, and Nepal. Climate scientists warn that such disasters are likely to increase in the Himalayas as global temperatures rise and ice continues to melt.

## Who is Nobel Peace Prize winner Narges Mohammadi?
 - [https://timesofindia.indiatimes.com/world/rest-of-world/who-is-nobel-peace-prize-winner-irans-narges-mohammadi/articleshow/104211644.cms](https://timesofindia.indiatimes.com/world/rest-of-world/who-is-nobel-peace-prize-winner-irans-narges-mohammadi/articleshow/104211644.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T09:28:17+00:00



## Nobel Peace Prize awarded to imprisoned Iranian activist Narges Mohammadi
 - [https://timesofindia.indiatimes.com/world/rest-of-world/nobel-peace-prize-2023-norway-ukraine-human-rights-narges-mohammadi-oppression-women-iran-human-freedom/articleshow/104210320.cms](https://timesofindia.indiatimes.com/world/rest-of-world/nobel-peace-prize-2023-norway-ukraine-human-rights-narges-mohammadi-oppression-women-iran-human-freedom/articleshow/104210320.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T09:02:48+00:00

Narges Mohammadi has been awarded the 2023 Nobel Peace Prize for her fight against the oppression of women in Iran and her promotion of human rights. The committee also recognized the hundreds of thousands of people who have demonstrated against Iran's discriminatory and oppressive policies targeting women. Mohammadi has faced personal costs for her brave struggle, including multiple arrests and convictions.

## 'Trudeau under fire for not revealing full cost of Montana trip'
 - [https://timesofindia.indiatimes.com/world/rest-of-world/justin-trudeau-under-fire-for-not-revealing-full-cost-of-montana-trip/articleshow/104210456.cms](https://timesofindia.indiatimes.com/world/rest-of-world/justin-trudeau-under-fire-for-not-revealing-full-cost-of-montana-trip/articleshow/104210456.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T08:53:24+00:00

Justin Trudeau's Easter weekend retreat in Montana incurred costs of almost a quarter of a million dollars for Canadian taxpayers, significantly higher than the amount disclosed to Parliament, according to CBC News. The total expenses for the April 6-10 trip exceeded $228,839 when accounting for the expenses covered by the Canadian Armed Forces, the Privy Council Office, and the Royal Canadian Mounted Police(RCMP).

## SC refuses to pass status quo order on Bihar caste survey
 - [https://timesofindia.indiatimes.com/india/supreme-court-refuses-to-pass-status-quo-order-on-bihar-caste-survey/articleshow/104208916.cms](https://timesofindia.indiatimes.com/india/supreme-court-refuses-to-pass-status-quo-order-on-bihar-caste-survey/articleshow/104208916.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T07:51:39+00:00

The Supreme Court on Friday refused to pass status quo order on Bihar caste survey, saying that restraining the state government from taking policy decision would be wrong.

## Sikkim flash floods: Military equipment washed away in Teesta
 - [https://timesofindia.indiatimes.com/city/kolkata/sikkim-flash-floods-military-equipment-washed-away-in-teesta-river-cops-in-bengal-urge-people-to-be-vigilant/articleshow/104208337.cms](https://timesofindia.indiatimes.com/city/kolkata/sikkim-flash-floods-military-equipment-washed-away-in-teesta-river-cops-in-bengal-urge-people-to-be-vigilant/articleshow/104208337.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T07:42:34+00:00

Police in West Bengal have issued a public alert saying that due to the  Sikkim floods, firearms and explosives belonging to the Army have been washed away and may end up on the Teesta riverbank. Police said they were stepping up vigil along the riverbanks.

## Freebies ahead of polls: SC seeks response from Raj, MP govts
 - [https://timesofindia.indiatimes.com/india/freebies-ahead-of-assembly-polls-sc-takes-note-of-pil-seeks-response-from-rajasthan-mp-govts/articleshow/104207538.cms](https://timesofindia.indiatimes.com/india/freebies-ahead-of-assembly-polls-sc-takes-note-of-pil-seeks-response-from-rajasthan-mp-govts/articleshow/104207538.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T07:14:17+00:00

The SC-bench, comprising CJI DY Chandrachud and justices JB Pardiwala &amp; Manoj Misra, also issued notice to the Centre, Election Commission (EC) and the Reserve Bank of India (RBI) on the PIL alleging taxpayers' money have been used to bribe voters ahead of assembly polls. The top court asked the Centre, states and the poll panel to file their responses in four weeks.

## NewsClick moves Delhi HC challenging FIR, arrests, remand order
 - [https://timesofindia.indiatimes.com/india/newsclick-moves-delhi-hc-challenging-fir-arresting-and-remand-order/articleshow/104207951.cms](https://timesofindia.indiatimes.com/india/newsclick-moves-delhi-hc-challenging-fir-arresting-and-remand-order/articleshow/104207951.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T07:14:13+00:00

According to the concerned lawyers, Newsclick has moved two petitions. One is seeking quashing of FIR and stating that arresting of accused persons is illegal. Another petition is challenging the Patiala House Court's order sending them seven days of remand.

## No bail for Chennai bike rider doing stunts on roads: HC
 - [https://timesofindia.indiatimes.com/auto/bikes/no-bail-for-chennai-bike-rider-doing-stunts-on-roads-says-high-court/articleshow/104207584.cms](https://timesofindia.indiatimes.com/auto/bikes/no-bail-for-chennai-bike-rider-doing-stunts-on-roads-says-high-court/articleshow/104207584.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T07:07:21+00:00

The Madras High Court has denied bail to a Chennai bike rider who was arrested for rash riding on a public road. The rider, who is also a vlogger, was caught on CCTV performing stunts and losing control of his bike.

## Ghosal leaves Hangzhou with a dream unfulfilled, but his head held high
 - [https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/indian-squash-legend-saurav-ghosal-leaves-hangzhou-with-a-dream-unfulfilled-but-his-head-held-high/articleshow/104206917.cms](https://timesofindia.indiatimes.com/sports/asian-games-2023/india-asian-games/indian-squash-legend-saurav-ghosal-leaves-hangzhou-with-a-dream-unfulfilled-but-his-head-held-high/articleshow/104206917.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T06:47:13+00:00

Indian squash player Saurav Ghosal, who has been part of six Asian Games editions, has failed to achieve an individual Asian Games gold medal. In the final at the 2014 Games, he won the first two games against Kuwait's Abdullah Al-Muzayen, but lost the next three, resulting in a silver medal. In Hangzhou, he again couldn't prevent his opponent's comeback bid, a goal he had aspired to achieve since his debut in 2002.

## Drunk passenger urinates on senior citizens onboard train in UP
 - [https://timesofindia.indiatimes.com/city/lucknow/drunk-passenger-urinates-on-senior-citizen-couple-in-up-sampark-kranti-express/articleshow/104206533.cms](https://timesofindia.indiatimes.com/city/lucknow/drunk-passenger-urinates-on-senior-citizen-couple-in-up-sampark-kranti-express/articleshow/104206533.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T06:27:15+00:00

The incident took place on Wednesday night inside B3 coach. The train was cruising towards Virangana Lakshmibai Jhansi Junction.

## No more Global NCAP crash tests for Indian cars
 - [https://timesofindia.indiatimes.com/auto/news/no-more-gncap-crash-certified-cars-for-india-what-will-happen-to-safety-ratings-now-explained/articleshow/104205701.cms](https://timesofindia.indiatimes.com/auto/news/no-more-gncap-crash-certified-cars-for-india-what-will-happen-to-safety-ratings-now-explained/articleshow/104205701.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T05:58:52+00:00

The Bharat New Car Assessment Programme (BNCAP) that was launched by Nitin Gadkari, Union Minister of Road Transport and Highways, on August 22 and has come into effect from October 1. The BNCAP guidelines are an iteration of the GNCAP tests, however, more geared towards Indian Standards, specifically, the Automotive Industry Standard (AIS) 197. The goal is to rigorously assess new vehicles of up to 3.5 tonnes for their safety standards.

## Student assaults 'Physics Wallah' teacher by slippers in class
 - [https://timesofindia.indiatimes.com/city/delhi/caught-on-cam-student-assaults-physics-wallah-teacher-by-slippers-in-class/articleshow/104205271.cms](https://timesofindia.indiatimes.com/city/delhi/caught-on-cam-student-assaults-physics-wallah-teacher-by-slippers-in-class/articleshow/104205271.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T05:44:17+00:00



## Chanchal Chowdhury: Borders won't hinder our cultural exchange
 - [https://timesofindia.indiatimes.com/entertainment/bengali/movies/news/chanchal-chowdhury-no-loc-between-india-and-bangladesh-can-stop-us-from-exchanging-our-cultural-heritage-exclusive/articleshow/104203433.cms](https://timesofindia.indiatimes.com/entertainment/bengali/movies/news/chanchal-chowdhury-no-loc-between-india-and-bangladesh-can-stop-us-from-exchanging-our-cultural-heritage-exclusive/articleshow/104203433.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T05:00:42+00:00

While he has received numerous offers from Tollywood, Chanchal Chowdhury is selective about his roles, emphasizing the importance of story, director, and character. He is wary of repeating roles and wishes to continually present new avatars to his audience. The actor cherishes his role in 'Karagar' and hopes for a third season, though the decision rests with the makers. He believes OTT platforms have expanded the audience reach and stresses the potential of cultural exchanges between India and Bangladesh.

## American cars, bikes that failed to succeed in India
 - [https://timesofindia.indiatimes.com/auto/cars/american-cars-bikes-that-failed-to-succeed-in-india-reasons-explained/articleshow/104202000.cms](https://timesofindia.indiatimes.com/auto/cars/american-cars-bikes-that-failed-to-succeed-in-india-reasons-explained/articleshow/104202000.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T04:59:35+00:00

A host of car manufacturers have tried entering the Indian market over the years, and unfortunately, not many managed to sustain for one reason or another, thereby ending their operations in the country.

## No impact on EMIs as RBI keeps key rate unchanged at 6.5%
 - [https://timesofindia.indiatimes.com/business/india-business/rbi-mpc-meet-repo-rate-emis-shaktikanta-das-inflation/articleshow/104202093.cms](https://timesofindia.indiatimes.com/business/india-business/rbi-mpc-meet-repo-rate-emis-shaktikanta-das-inflation/articleshow/104202093.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T04:36:29+00:00

The Reserve Bank of India (RBI) has decided to keep the repo rate unchanged at 6.5% for the fourth consecutive time. The RBI governor, Shaktikanta Das, stated that India is poised to be the new growth engine of the world. The RBI has maintained the repo rate at 6.5% since May 2022 to control rising prices. However, retail inflation stood at 6.83% in August, surpassing the RBI's acceptable threshold.

## Devoleena Bhattacharjee on being trolled for her choice of partner
 - [https://timesofindia.indiatimes.com/tv/news/hindi/devoleena-bhattacharjee-on-being-trolled-for-her-choice-of-partner-if-i-had-married-a-wealthy-man-id-have-been-labelled-a-gold-digger/articleshow/104202668.cms](https://timesofindia.indiatimes.com/tv/news/hindi/devoleena-bhattacharjee-on-being-trolled-for-her-choice-of-partner-if-i-had-married-a-wealthy-man-id-have-been-labelled-a-gold-digger/articleshow/104202668.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T04:29:48+00:00

Devoleena Bhattacharjee, currently seen in Dil Diyaan Gallaan, also shares her thoughts on embracing motherhood. She says that she would like to go the family way soon.

## Anthony Pratt, billionaire Trump shared nuclear secrets with?
 - [https://timesofindia.indiatimes.com/world/us/who-is-anthony-pratt-the-billionaire-trump-allegedly-shared-nuclear-secrets-with/articleshow/104202137.cms](https://timesofindia.indiatimes.com/world/us/who-is-anthony-pratt-the-billionaire-trump-allegedly-shared-nuclear-secrets-with/articleshow/104202137.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T04:08:31+00:00

Australian billionaire Anthony Pratt has been hurled into the spotlight after US press reports alleged that former President Donald Trump spilled secrets about US nuclear subs to the businessman.

## Will Ashwin, Jadeja and Kuldeep weave magic against Australia?
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/world-cup-will-spin-trio-of-ravichandran-ashwin-ravindra-jadeja-and-kuldeep-yadav-weave-magic-against-australia/articleshow/104202157.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/world-cup-will-spin-trio-of-ravichandran-ashwin-ravindra-jadeja-and-kuldeep-yadav-weave-magic-against-australia/articleshow/104202157.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T03:59:22+00:00

Jasprit Bumrah had an extensive batting session during India's practice ahead of their game against Australia. The team management is concerned about the lack of batting contributions from the lower order, and Bumrah's talent with the bat could make him a handy No. 9. Ravichandran Ashwin also had a quality batting session, while his primary skill of off-spinning will be crucial in the middle overs.

## 'Donald Trump told Australian businessman US nuclear subs secrets'
 - [https://timesofindia.indiatimes.com/world/us/donald-trump-told-australian-businessman-us-nuclear-subs-secrets/articleshow/104201997.cms](https://timesofindia.indiatimes.com/world/us/donald-trump-told-australian-businessman-us-nuclear-subs-secrets/articleshow/104201997.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T03:50:04+00:00

Former President Donald Trump is alleged to have shared classified information about US nuclear submarines with Australian billionaire Anthony Pratt at Mar-a-Lago, according to a report. Pratt then reportedly shared this information with multiple individuals, including foreign officials.

## Kerala: UP youths flew in, boarded trains & robbed passengers
 - [https://timesofindia.indiatimes.com/city/kochi/up-youths-flew-in-boarded-trains-and-robbed-passengers/articleshow/104201852.cms](https://timesofindia.indiatimes.com/city/kochi/up-youths-flew-in-boarded-trains-and-robbed-passengers/articleshow/104201852.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T03:42:23+00:00

Two young men from Uttar Pradesh flew down from Delhi to commit a series of robberies on trains in Southern Railways. The duo snatched gold ornaments from passengers on different trains before being arrested in Mangaluru. CCTV footage from various railway stations was analyzed by the Railway Police Force in Kerala to identify the robbers. The thieves targeted vulnerable passengers, including women and elderly men, who wore gold ornaments. The youths had planned to sell the stolen gold ornaments in Mirzapur, Uttar Pradesh.

## Political roads filled with turmoil, guide me: Shivraj to sadhus
 - [https://timesofindia.indiatimes.com/city/indore/political-roads-filled-with-turmoil-guide-me-madhya-pradesh-cm-shivraj-singh-chouhan-to-sadhus/articleshow/104201549.cms](https://timesofindia.indiatimes.com/city/indore/political-roads-filled-with-turmoil-guide-me-madhya-pradesh-cm-shivraj-singh-chouhan-to-sadhus/articleshow/104201549.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T03:29:04+00:00

Madhya Pradesh Chief Minister Shivraj Singh Chouhan sought the blessings of saints to guide him in upholding Sanatan Dharma (eternal religion). Chouhan expressed his need for guidance and support to stay on the right path in the midst of political challenges. He emphasized that Sanatan culture cannot be ended and condemned those who question it. Chouhan's position as the undisputed face for Chief Minister is being challenged by multiple potential candidates, including Jyotiraditya Scindia. He received support from Akhil Bharatiya Akhara Parishad president Ravindra Puri, who urged him to come to power and become the CM.

## Meet the Unstoppable 21 under 21
 - [https://timesofindia.indiatimes.com/india/meet-the-unstoppable-21-under-21/articleshow/104200027.cms](https://timesofindia.indiatimes.com/india/meet-the-unstoppable-21-under-21/articleshow/104200027.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T02:49:09+00:00



## India's Shubman Gill doubtful for World Cup opener
 - [https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/shubman-gills-world-cup-opener-in-doubt-due-to-health-concerns/articleshow/104199732.cms](https://timesofindia.indiatimes.com/sports/cricket/icc-world-cup/shubman-gills-world-cup-opener-in-doubt-due-to-health-concerns/articleshow/104199732.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T02:09:46+00:00

Indian cricketer Shubman Gill's participation in the opening World Cup match against Australia is doubtful due to health issues. Gill, who has been in good form recently, is suffering from high fever and is scheduled for dengue testing. If diagnosed with dengue, he may miss multiple games.

## Man without bladder taken for gallstone op, doc removes appendix
 - [https://timesofindia.indiatimes.com/city/kolkata/man-doesnt-have-gall-bladder-doctor-removes-appendix/articleshow/104199760.cms](https://timesofindia.indiatimes.com/city/kolkata/man-doesnt-have-gall-bladder-doctor-removes-appendix/articleshow/104199760.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T02:07:13+00:00

A constable with West Bengal Police underwent an unnecessary appendix removal surgery after a diagnostic center wrongly reported that he had a gallstone. The West Bengal Clinical Establishment Regulatory Commission has ordered the diagnostic center to pay for all the patient's tests. The patient had initially received a report stating he had a gallbladder stone, but a second report mentioned a "contracted" gallbladder. It was later discovered that the patient had a congenital absence of a gallbladder. The commission has advised the patient to file a complaint against the surgeon and radiologists involved.

## 7 dead in massive building fire in Mumbai's Goregaon
 - [https://timesofindia.indiatimes.com/city/mumbai/31-injured-after-major-fire-breaks-out-in-mumbai-building/articleshow/104199654.cms](https://timesofindia.indiatimes.com/city/mumbai/31-injured-after-major-fire-breaks-out-in-mumbai-building/articleshow/104199654.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T02:00:52+00:00



## Cop deserts & 'dies', then joins UP Police
 - [https://timesofindia.indiatimes.com/city/lucknow/cop-deserts-dies-then-joins-up-police/articleshow/104199569.cms](https://timesofindia.indiatimes.com/city/lucknow/cop-deserts-dies-then-joins-up-police/articleshow/104199569.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T01:48:38+00:00

A constable, who was declared deserter by the Chhattisgarh police, managed to change his identity with fake papers and become a police officer in Uttar Pradesh. The constable, Manoj Kumar, applied for a job in the UP police recruitment board using a different name after being declared dead based on a fake certificate. The forgery was discovered after an anonymous letter was received by the SP Mathura, leading to an investigation and the filing of criminal charges.

## Sikkim glacial lake’s size trebled in 3 decades before bursting
 - [https://timesofindia.indiatimes.com/india/time-bomb-sikkim-glacial-lakes-size-trebled-in-3-decades-before-bursting/articleshow/104199048.cms](https://timesofindia.indiatimes.com/india/time-bomb-sikkim-glacial-lakes-size-trebled-in-3-decades-before-bursting/articleshow/104199048.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T00:58:30+00:00



## Sikkim glacial lake’s size trebled in 3 decades before bursting
 - [https://timesofindia.indiatimes.com/city/kolkata/time-bomb-sikkim-glacial-lakes-size-trebled-in-3-decades-before-bursting/articleshow/104199048.cms](https://timesofindia.indiatimes.com/city/kolkata/time-bomb-sikkim-glacial-lakes-size-trebled-in-3-decades-before-bursting/articleshow/104199048.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T00:58:30+00:00



## Ruthless approach needed to combat terror, says Amit Shah
 - [https://timesofindia.indiatimes.com/india/ruthless-approach-needed-to-combat-terror-says-amit-shah/articleshow/104199051.cms](https://timesofindia.indiatimes.com/india/ruthless-approach-needed-to-combat-terror-says-amit-shah/articleshow/104199051.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T00:48:51+00:00

Home Minister Amit Shah has called for a "ruthless" approach towards terrorism and urged the central and state police forces to focus on dismantling the "terror eco-system" that supports terrorists. Speaking at an anti-terror conference, Shah emphasized the need for collaboration at both the national and international levels to combat terrorism.

## Cooling tomato prices bring down thali rates
 - [https://timesofindia.indiatimes.com/business/india-business/cooling-tomato-prices-bring-down-thali-rates/articleshow/104198898.cms](https://timesofindia.indiatimes.com/business/india-business/cooling-tomato-prices-bring-down-thali-rates/articleshow/104198898.cms)
 - RSS feed: http://timesofindia.indiatimes.com/rssfeedstopstories.cms
 - date published: 2023-10-06T00:23:24+00:00

In September, the cost of vegetarian and non-vegetarian thalis decreased due to lower tomato prices. The cost of a vegetarian thali fell 17% month-on-month, while the cost of a non-vegetarian thali declined 9%. Onion prices increased, but overall food prices eased, resulting in lower retail inflation. Fuel costs also decreased, contributing to the decrease in thali costs. Chillies also had a cooling effect on thali prices.

