# Source:NY times technology, URL:http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml, language:en-US

## How to Watch Amazon Launch the First 2 Project Kuiper Satellites
 - [https://www.nytimes.com/2023/10/06/science/amazon-project-kuiper-launch.html](https://www.nytimes.com/2023/10/06/science/amazon-project-kuiper-launch.html)
 - RSS feed: http://rss.nytimes.com/services/xml/rss/nyt/Technology.xml
 - date published: 2023-10-06T15:13:48+00:00

The two prototype spacecraft will test systems to be used in a planned megaconstellation to provide internet service from orbit that will eventually compete with SpaceX’s Starlink service.

