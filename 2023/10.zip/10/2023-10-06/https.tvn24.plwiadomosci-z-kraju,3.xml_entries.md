# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Rosjanie przegrupowują siły. W jednym miejscu skumulowali ponad 120 tysięcy żołnierzy. "Nowy cel wroga"
 - [https://tvn24.pl/swiat/rosjanie-przegrupowuja-sily-na-odcinku-kupiansko-lymanskim-skumulowali-ponad-100-tysiecy-zolnierzy-7379146?source=rss](https://tvn24.pl/swiat/rosjanie-przegrupowuja-sily-na-odcinku-kupiansko-lymanskim-skumulowali-ponad-100-tysiecy-zolnierzy-7379146?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T18:59:08+00:00

<img alt="Rosjanie przegrupowują siły. W jednym miejscu skumulowali ponad 120 tysięcy żołnierzy. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-wh55bv-rosyjscy-zolnierze-zdjecie-ilustracyjne-7370306/alternates/LANDSCAPE_1280" />
    Odcinek kupiańsko-łymański stał się priorytetem dla ofensywy sił rosyjskich. W tym miejscu toczą się najzacieklejsze walki - powiedział telewizji Espreso ukraiński analityk wojskowy Dmytro Sniegiriow.

## Opozycja zapewnia o współpracy. "Chcemy pokazać, że inna polityka jest możliwa"
 - [https://fakty.tvn24.pl/zobacz-fakty/opozycja-zapewnia-o-wspolpracy-chcemy-pokazac-ze-inna-polityka-jest-mozliwa-7379057?source=rss](https://fakty.tvn24.pl/zobacz-fakty/opozycja-zapewnia-o-wspolpracy-chcemy-pokazac-ze-inna-polityka-jest-mozliwa-7379057?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T18:47:47+00:00

<img alt="Opozycja zapewnia o współpracy. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-a148ma-kkz-7379170/alternates/LANDSCAPE_1280" />
    Opozycja od dawna mówi o szansie na wspólny rząd po wyborach, ale jeszcze nigdy nie mówiła "my" tak przekonująco jak teraz. Na ostatniej prostej kampanii wyborczej Donald Tusk odwołuje się do takich pojęć jak: wspólnota, współpraca, pojednanie. W ślad za nim idą też liderzy Trzeciej Drogi i Nowej Lewicy.

## Fałszywe mandaty za parkowanie. Zeskanujesz kod QR, możesz mieć kłopot
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-falszywe-mandaty-za-nielegalne-parkowanie-jak-wygladaja-czym-sie-roznia-7378418?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-falszywe-mandaty-za-nielegalne-parkowanie-jak-wygladaja-czym-sie-roznia-7378418?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T18:10:42+00:00

<img alt="Fałszywe mandaty za parkowanie. Zeskanujesz kod QR, możesz mieć kłopot" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-i0wxyz-straz-ostrzega-przed-oszustami-7378575/alternates/LANDSCAPE_1280" />
    Strażnicy miejscy ostrzegają przed fałszywymi mandatami. Wezwania wkładane są za wycieraczki samochodów na warszawskich ulicach. Tym razem do próby oszustwa doszło na Pradze Północ. Oszuści udoskonalili metodę - druczek zawiera kod QR, które zeskanowanie przenosi na podejrzaną stronę.

## Uciekał przed policją. Był pijany, na koncie miał dwa dożywotnie zakazy prowadzenia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-kierowca-mitsubishi-uciekal-przed-policjantami-byl-pijany-mial-dwa-dozywotnie-zakazy-prowadzenia-7378142?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/minsk-mazowiecki-kierowca-mitsubishi-uciekal-przed-policjantami-byl-pijany-mial-dwa-dozywotnie-zakazy-prowadzenia-7378142?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T18:04:03+00:00

<img alt="Uciekał przed policją. Był pijany, na koncie miał dwa dożywotnie zakazy prowadzenia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ytsxzy-policjanci-zatrzymali-kierowce-mitsubishi-zdjecie-ilustracyjne-7378169/alternates/LANDSCAPE_1280" />
    Policjanci z Mińska Mazowieckiego zauważyli podejrzanie poruszające się mitsubishi. Postanowili zatrzymać kierującego do kontroli, ale ten zaczął uciekać - najpierw samochodem, a potem pieszo. Okazało się, że 46-latek miał kilka spraw do ukrycia.

## Frezowanie ulicy Krasnowolskiej. Utrudnienia
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prace-drogowe-na-ulicy-krasnowolskiej-utrudnienia-7378568?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-prace-drogowe-na-ulicy-krasnowolskiej-utrudnienia-7378568?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T16:51:06+00:00

<img alt="Frezowanie ulicy Krasnowolskiej. Utrudnienia" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-us33cg-prace-drogowe-na-ulicy-krasnowolskiej-zdjecie-ilustracyjne-7378605/alternates/LANDSCAPE_1280" />
    W weekend odbędzie się wymiana nawierzchni ulicy Krasnowolskiej. Odcinek, na którym będą odbywać się prace zostanie wyłączony z ruchu. Linia autobusowa 239 zostanie zawieszona.

## Wiele urzędów wydłuża godziny pracy, by wydawać zaświadczenia o prawie do głosowania
 - [https://fakty.tvn24.pl/fakty-po-poludniu/wiele-urzedow-wydluza-godziny-pracy-by-wydawac-zaswiadczenia-o-prawie-do-glosowania-7378932?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/wiele-urzedow-wydluza-godziny-pracy-by-wydawac-zaswiadczenia-o-prawie-do-glosowania-7378932?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T16:33:29+00:00

<img alt="Wiele urzędów wydłuża godziny pracy, by wydawać zaświadczenia o prawie do głosowania" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-c5gqbb-balu-7378940/alternates/LANDSCAPE_1280" />
    Liderzy i kandydaci są na ostatniej przedwyborczej prostej, bo ostatni tydzień kampanii to dla nich czas największej mobilizacji. Mobilizacja jest też po stronie wyborców - i tu też czas ma znaczenie. Do 12 października można pobierać zaświadczenia o prawie do głosowania lub dopisać się do spisu wyborców, dlatego niektóre urzędy wydłużyły godziny pracy, a na gdańskich uczelniach stanęły mobilne punkty.

## Co z tegoroczną dziurą ozonową? Jest "jedną z największych w historii"
 - [https://tvn24.pl/tvnmeteo/nauka/co-z-tegoroczna-dziura-ozonowa-jest-jedna-z-najwiekszych-w-historii-7378937?source=rss](https://tvn24.pl/tvnmeteo/nauka/co-z-tegoroczna-dziura-ozonowa-jest-jedna-z-najwiekszych-w-historii-7378937?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T16:19:03+00:00

<img alt="Co z tegoroczną dziurą ozonową? Jest " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-7d6y0e-maksymalny-zasieg-dziury-ozonowej-nad-antarktyda-w-2023-roku-7379051/alternates/LANDSCAPE_1280" />
    Dziura ozonowa nad Antarktydą ponownie urosła do olbrzymich rozmiarów. Jak pokazują dane satelitarne, w tym roku ubytek warstwy ozonowej osiągnął powierzchnię 26 milionów kilometrów kwadratowych. Przyczyną tak sporego ubytku ozonu może być jednak w pełni naturalne zjawisko.

## To "długi covid" czy "długie przeziębienie"? Naukowcy wskazali różnice
 - [https://tvn24.pl/ciekawostki/dlugotrwale-objawy-po-przeziebieniu-sa-tak-powszechne-jak-dlugi-covid-7378894?source=rss](https://tvn24.pl/ciekawostki/dlugotrwale-objawy-po-przeziebieniu-sa-tak-powszechne-jak-dlugi-covid-7378894?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T15:51:19+00:00

<img alt="To " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v0uqly-grypa-choroba-przeziebienie-shutterstock_1523330795-7198487/alternates/LANDSCAPE_1280" />
    O długotrwałych skutkach zakażenia COVID-19 naukowcy mówią od dawna. Ale po przebyciu zwykłego przeziębienia męczące objawy również mogą utrzymywać się przez wiele miesięcy. Jak odróżnić jedno od drugiego?

## W coraz cieplejszym świecie rośliny mogą zanieczyszczać powietrze, a nie je oczyszczać
 - [https://tvn24.pl/tvnmeteo/nauka/rosliny-a-zmiany-klimatu-w-ogrzewajacym-sie-swiecie-moga-one-zanieczyszczac-powietrze-7378824?source=rss](https://tvn24.pl/tvnmeteo/nauka/rosliny-a-zmiany-klimatu-w-ogrzewajacym-sie-swiecie-moga-one-zanieczyszczac-powietrze-7378824?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T15:18:49+00:00

<img alt="W coraz cieplejszym świecie rośliny mogą zanieczyszczać powietrze, a nie je oczyszczać" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5jahnv-topole-czarne-w-miescie-7378913/alternates/LANDSCAPE_1280" />
    Rośliny mogą przyczyniać się do zwiększania zanieczyszczenia powietrza na skutek zmian klimatu. Amerykańscy naukowcy zaobserwowali, że im cieplej, tym więcej produkują one izoprenu - związku organicznego, który jest prekursorem wielu substancji szkodliwych dla ludzi i środowiska. Ten sam związek może jednak być naszym przyjacielem.

## Walczy z cieniem czy "zadeptuje krokodyle"? Niecodzienne zachowanie łosia w wodzie. Nagranie
 - [https://tvn24.pl/bialystok/nadlesnictwo-dojlidy-los-w-wodzie-przylapany-przez-fotopulapke-nagranie-7378796?source=rss](https://tvn24.pl/bialystok/nadlesnictwo-dojlidy-los-w-wodzie-przylapany-przez-fotopulapke-nagranie-7378796?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:52:29+00:00

<img alt="Walczy z cieniem czy " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4u2x6l-gdy-woda-pluska-on-probuje-kopac-w-pojawiajace-sie-w-tafli-kola-7378509/alternates/LANDSCAPE_1280" />
    Nadleśnictwo Dojlidy (woj. podlaskie) publikuje filmy z fotopułaki, na których widać łosia nazwanego przez leśników Kacperkiem. Zwierzę biega po bagnie, jakby "walczyło" z wodą. Internauci żartują, że "zadeptuje krokodyle" lub zgubiło telefon.

## Kierowca autobusu uderzył w latarnię. Ta spadła na kobietę
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-kierowca-autobusu-skasowal-latarnie-ta-spadla-na-kobiete-7378852?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-kierowca-autobusu-skasowal-latarnie-ta-spadla-na-kobiete-7378852?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:42:16+00:00

<img alt="Kierowca autobusu uderzył w latarnię. Ta spadła na kobietę" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ve1wck-kierowca-autobusu-uderzyl-w-latarnie-7378837/alternates/LANDSCAPE_1280" />
    Na ulicy Puławskiej kierowca autobusu miejskiego wjechał w latarnię. Ta przewróciła się i spadła na pasażerkę, która stała na przystanku. Kobieta trafiła do szpitala.

## Nie chciał zapłacić za pizzę. Gdy przyjechała policja, okazało się, że jest poszukiwany
 - [https://tvn24.pl/szczecin/szczecin-nie-chcial-zaplacic-za-pizze-nie-bylo-to-jego-jedyne-przewinienie-7377842?source=rss](https://tvn24.pl/szczecin/szczecin-nie-chcial-zaplacic-za-pizze-nie-bylo-to-jego-jedyne-przewinienie-7377842?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:41:45+00:00

<img alt="Nie chciał zapłacić za pizzę. Gdy przyjechała policja, okazało się, że jest poszukiwany" src="https://tvn24.pl/najnowsze/cdn-zdjecie-l79dly-pizza-shutterstock_2207124827-6859046/alternates/LANDSCAPE_1280" />
    Mężczyzna odmówił zapłacenia rachunku za zjedzoną pizzę. Gdy przyjechała policja okazało się, że jest poszukiwany przez funkcjonariuszy z powiatu wejherowskiego (woj. Pomorskie) jako podejrzany w sprawie kradzieży roweru. 40-latek został zatrzymany.

## Apelują, by nie robić tego w Halloween. "Szkody stały się poważne"
 - [https://tvn24.pl/swiat/tokio-apel-wladz-do-turystow-przed-halloween-nie-chca-powtorki-z-seulu-7378679?source=rss](https://tvn24.pl/swiat/tokio-apel-wladz-do-turystow-przed-halloween-nie-chca-powtorki-z-seulu-7378679?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:41:13+00:00

<img alt="Apelują, by nie robić tego w Halloween. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-1nlvhg-helloween-dasian-shutterstock_2220546407-7378723/alternates/LANDSCAPE_1280" />
    Władze jednej z dzielnic Tokio zaapelowały do turystów, by w okolicach Halloween nie gromadzili się w rejonie najbardziej zatłoczonego skrzyżowania w mieście - podaje CNN. Rok temu w trakcie imprezy halloweenowej w stolicy Korei Południowej w tłumie wybuchła panika. Zginęło ponad 150 osób.

## Wypadek na zamkniętym odcinku Trasy Łazienkowskiej. Kierowca przewozu osób uderzył w auto dostawcze
 - [https://tvn24.pl/tvnwarszawa/ulice/warszawa-wypadek-na-zamknietym-odcinku-trasy-lazienkowskiej-7378810?source=rss](https://tvn24.pl/tvnwarszawa/ulice/warszawa-wypadek-na-zamknietym-odcinku-trasy-lazienkowskiej-7378810?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:27:04+00:00

<img alt="Wypadek na zamkniętym odcinku Trasy Łazienkowskiej. Kierowca przewozu osób uderzył w auto dostawcze" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-dix3l-wypadek-na-zamknietym-odcinku-trasy-lazienkowskiej-7378819/alternates/LANDSCAPE_1280" />
    Jeszcze nie oddali jej do użytku, a już doszło do wypadku. Kierowca jednej z firm przewozowych wjechał na zamknięty odcinek Trasy Łazienkowskiej. Tam uderzył w samochód dostawczy ekipy budowlanej.

## Kiedy przyjdzie złota polska jesień. Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/kiedy-przyjdzie-zlota-polska-jesien-pogoda-na-5-dni-7378757?source=rss](https://tvn24.pl/tvnmeteo/pogoda/kiedy-przyjdzie-zlota-polska-jesien-pogoda-na-5-dni-7378757?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T14:19:09+00:00

<img alt="Kiedy przyjdzie złota polska jesień. Pogoda na 5 dni" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-0pc7lz-niedziela-chlodna-ale-sloneczna-5445956/alternates/LANDSCAPE_1280" />
    Kolejne dni przyniosą nam prawdziwą walkę w pogodzie. W weekend panowanie nad polską aurą sprawować będzie wir niżowy Patrick, przynoszący ze sobą chłodne powietrze, opady deszczu, a miejscami nawet śnieg. Po nim znajdziemy się jednak pod panowaniem rozległego wyżu, który przypomni nam o polskiej, złotej jesieni - na jak długo?

## Karambol na S5. Zderzyło się pięć pojazdów
 - [https://tvn24.pl/poznan/karambol-na-s5-zderzylo-sie-piec-pojazdow-7378739?source=rss](https://tvn24.pl/poznan/karambol-na-s5-zderzylo-sie-piec-pojazdow-7378739?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T13:44:24+00:00

<img alt="Karambol na S5. Zderzyło się pięć pojazdów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h5p5qw-wypadek-koscian-7378713/alternates/LANDSCAPE_1280" />
    Na drodze S5 pomiędzy węzłami Kościan Południe i Kościan Północ w kierunku Poznania doszło do zderzenia pięciu pojazdów. Rannych zostało dwóch kierowców.

## "Skandaliczna cenzura". Polska Press odmawia publikacji reklam opozycji i wydaje oświadczenie
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-polska-press-odmawia-reklamowania-kandydatow-opozycji-lewicy-i-trzeciej-drogi-7378412?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-polska-press-odmawia-reklamowania-kandydatow-opozycji-lewicy-i-trzeciej-drogi-7378412?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T12:54:11+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-x5zd7n-polska-press-grupa-odmowa-7378296/alternates/LANDSCAPE_1280" />
    "Echo Kieleckie", "Nasze Miasto Gorzów" i portal echodnia.eu - należące do grupy medialnej Polska Press - odmówiły trojgu kandydatów Nowej Lewicy i Trzeciej Drogi publikacji reklam wyborczych. Powód? Jak wskazał wydawca, wartości prezentowane przez polityków tych ugrupowań "są nie do pogodzenia z jego linią programową". - To skandaliczna cenzura prewencyjna - ocenia kandydat paktu senackiego z Kielc Henryk Milcarz. Polska Press w przesłanym redakcji tvn24.pl oświadczeniu pisze w odpowiedzi o "kłamliwych twierdzeniach rozczarowanego kandydata".

## "Uszkodzone jest około 600 metrów sieci trakcyjnej"
 - [https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-zerwana-siec-trakcyjna-utrudnienia-w-kursowaniu-tramwajow-7378660?source=rss](https://tvn24.pl/tvnwarszawa/srodmiescie/warszawa-zerwana-siec-trakcyjna-utrudnienia-w-kursowaniu-tramwajow-7378660?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T12:44:33+00:00

<img alt="" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-hkeouf-zerwana-siec-trakcyjna-utrudnienia-w-kursowaniu-tramwajow-zdjecie-ilustracyjne-7378661/alternates/LANDSCAPE_1280" />
    Na skrzyżowaniu ulicy Prostej z Żelazną doszło do zerwania sieci trakcyjnej. Pięć linii tramwajowych skierowano na objazdy.

## 15 października napłynie do nas chłód z dalekiej północy. Prognoza pogody na wybory 2023
 - [https://tvn24.pl/tvnmeteo/prognoza/wybory-2023-pogoda-prognoza-na-niedziele-15-pazdziernika-7378511?source=rss](https://tvn24.pl/tvnmeteo/prognoza/wybory-2023-pogoda-prognoza-na-niedziele-15-pazdziernika-7378511?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T12:41:18+00:00

<img alt="15 października napłynie do nas chłód z dalekiej północy. Prognoza pogody na wybory 2023" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1mp3t5-lokal-wyborczy-7378638/alternates/LANDSCAPE_1280" />
    W niedzielę 15 października odbędą się wybory parlamentarne. Polacy wybiorą 460 posłów do Sejmu i 100 senatorów do Senatu na czteroletnią kadencję. Jaka będzie pogoda, gdy ruszymy do urn? Sprawdź wstępną prognozę.

## Kobieta zginęła na deptaku, przejechał ją kierowca dostawczaka. Jest akt oskarżenia
 - [https://tvn24.pl/bialystok/lubin-szla-deptakiem-potracil-ja-samochod-dostawczy-jest-akt-oskarzenia-7378134?source=rss](https://tvn24.pl/bialystok/lubin-szla-deptakiem-potracil-ja-samochod-dostawczy-jest-akt-oskarzenia-7378134?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T12:16:58+00:00

<img alt="Kobieta zginęła na deptaku, przejechał ją kierowca dostawczaka. Jest akt oskarżenia" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ese5w1-kobieta-szla-deptakiem-potracil-ja-samochod-dostawczy-6997348/alternates/LANDSCAPE_1280" />
    25-letni Filip K. będzie odpowiadał za śmiertelne potrącenie 47-letniej kobiety na Krakowskim Przedmieściu w Lublinie. Do sądu trafił właśnie akt oskarżenia. Zdaniem śledczych, mężczyzna, cofając samochodem dostawczym, nie zachował szczególnej ostrożności. Przyznał się do winy. Grozi mu do ośmiu lat więzienia.

## Przyjechał pijany na przesłuchanie. Auto zaparkował przed posterunkiem. Nagranie
 - [https://tvn24.pl/najnowsze/bransk-przyjechal-pijany-na-przesluchanie-auto-zaparkowal-przed-posterunkiem-nagranie-7378093?source=rss](https://tvn24.pl/najnowsze/bransk-przyjechal-pijany-na-przesluchanie-auto-zaparkowal-przed-posterunkiem-nagranie-7378093?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T11:39:28+00:00

<img alt="Przyjechał pijany na przesłuchanie. Auto zaparkował przed posterunkiem. Nagranie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m95k4k-52-latek-zaparkowal-przed-posterunkiem-7377990/alternates/LANDSCAPE_1280" />
    Niecodzienne zdarzenie – tak policjanci z Brańska (woj. podlaskie) określają to, do czego doszło na posterunku. Pojawił się tam 52-latek, który miał być przesłuchany w sprawie picia alkoholu w miejscu publicznym. Okazało się, że był nietrzeźwy i przyjechał autem, parkując przed posterunkiem.

## Mapa bogactwa w Europie. "Sprzeczne z narracją rządzących"
 - [https://tvn24.pl/biznes/pieniadze/pkb-per-capita-w-polsce-dane-eurostatu-komentuje-slawomir-kalinowski-7378208?source=rss](https://tvn24.pl/biznes/pieniadze/pkb-per-capita-w-polsce-dane-eurostatu-komentuje-slawomir-kalinowski-7378208?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T11:33:29+00:00

<img alt="Mapa bogactwa w Europie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fb1p6a-eurostat-sklej-7378513/alternates/LANDSCAPE_1280" />
    Gorszą sytuację w Europie, jeśli chodzi o PKB na mieszkańca, ma tylko Serbia, Bułgaria i Rumunia - napisał w mediach społecznościowych ekonomista Sławomir Kalinowski z Polskiej Akademii Nauk, odnosząc się do nowych danych Eurostatu. - To jest dosyć niebezpieczne i sprzeczne z narracją rządzących - skomentował w rozmowie z TVN24 Biznes. Na wpis ekonomisty zareagowało Ministerstwo Finansów.

## Miała ponad 4 promile. Prosiła, żeby nie wzywać policji, bo jedzie po dzieci
 - [https://tvn24.pl/lodz/sieradz-miala-ponad-4-promile-prosila-zeby-nie-wzywac-policji-bo-jedzie-po-dzieci-7377893?source=rss](https://tvn24.pl/lodz/sieradz-miala-ponad-4-promile-prosila-zeby-nie-wzywac-policji-bo-jedzie-po-dzieci-7377893?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T11:24:57+00:00

<img alt="Miała ponad 4 promile. Prosiła, żeby nie wzywać policji, bo jedzie po dzieci" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ej11vh-kobieta-miala-blisko-poltora-promila-alkoholu-w-organizmie-trafila-do-aresztu-zdjecie-ilustracyjne-7228910/alternates/LANDSCAPE_1280" />
    Ponad cztery promile alkoholu miała w organizmie mieszkanka Sieradza (woj. łódzkie), którą zatrzymali inni kierowcy. Kobieta prosiła, żeby nie wzywać na miejsce policji, bo jedzie po dzieci. Za jazdę w stanie nietrzeźwości grozi jej do dwóch lat pozbawienia wolności.

## Śmierć czterolatka na placu zabaw. Nowe informacje z kuratorium. Wniosek prokuratury
 - [https://tvn24.pl/krakow/zabierzow-smierc-czterolatka-na-placu-zabaw-prokuratura-wnioskuje-o-przekazanie-sprawy-innej-jednostce-7378121?source=rss](https://tvn24.pl/krakow/zabierzow-smierc-czterolatka-na-placu-zabaw-prokuratura-wnioskuje-o-przekazanie-sprawy-innej-jednostce-7378121?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T11:16:17+00:00

<img alt="Śmierć czterolatka na placu zabaw. Nowe informacje z kuratorium. Wniosek prokuratury " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pyl1ou-zabierzow-7367228/alternates/LANDSCAPE_1280" />
    Prokuratura, która prowadzi postępowanie dotyczące śmierci czterolatka na placu zabaw w Zabierzowie (woj. małopolskie), zawnioskowała o przekazanie tej sprawy innej jednostce. We wniosku tłumaczy, że chce uniknąć zarzutu "braku bezstronności z uwagi na osobę pokrzywdzonego w sprawie". Małopolska Kurator Oświaty przekazała zaś, że dzieci przebywające na placu zabaw, gdzie doszło do tragedii, nie miały zapewnionej odpowiedniej opieki.

## Obiekty, których nie przewidziała żadna teoria, zauważone w Mgławicy Oriona
 - [https://tvn24.pl/tvnmeteo/nauka/kosmos-nowe-zdjecie-z-kosmicznego-teleskopu-jamesa-webba-zaskakujace-obiekty-w-mglawicy-oriona-7378278?source=rss](https://tvn24.pl/tvnmeteo/nauka/kosmos-nowe-zdjecie-z-kosmicznego-teleskopu-jamesa-webba-zaskakujace-obiekty-w-mglawicy-oriona-7378278?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T11:06:59+00:00

<img alt="Obiekty, których nie przewidziała żadna teoria, zauważone w Mgławicy Oriona" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-55whq3-zdjecie-mglawicy-oriona-i-gromady-trapez-na-zdjeciu-kosmicznego-teleskopu-jamesa-webba-7378383/alternates/LANDSCAPE_1280" />
    Naukowcy dokonali zaskakującego odkrycia na nowym zdjęciu z Kosmicznego Teleskopu Jamesa Webba. W Mgławicy Oriona zaobserwowano obiekty podobne do planet, których według istniejących teorii wcale nie powinno tam być.

## Policja: W marcu napadł na sklep, sterroryzował ekspedientkę. Właśnie został zatrzymany
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-targowek-w-marcu-napadl-na-sklep-sterroryzowal-ekspedientke-wlasnie-zostal-zatrzymany-7377960?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-targowek-w-marcu-napadl-na-sklep-sterroryzowal-ekspedientke-wlasnie-zostal-zatrzymany-7377960?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:56:17+00:00

<img alt="Policja: W marcu napadł na sklep, sterroryzował ekspedientkę. Właśnie został zatrzymany " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-45l30u-policjanci-zatrzymali-podejrzanego-7366406/alternates/LANDSCAPE_1280" />
    Policjanci zatrzymali podejrzanego o napad na sklep na Targówku. Mężczyzna miał wtargnąć za ladę, zagrozić ekspedientce nożem, a następnie zabrać gotówkę. Grozi mu kilkanaście lat więzienia.

## Pijana zapytała strażników miejskich o wyjazd z parkingu. Chwilę później wsiadła za kółko
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wilanow-pijana-zapytala-straznikow-miejskich-o-wyjazd-z-parkingu-pozniej-na-ich-oczach-wsiadla-za-kolko-7378293?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wilanow-pijana-zapytala-straznikow-miejskich-o-wyjazd-z-parkingu-pozniej-na-ich-oczach-wsiadla-za-kolko-7378293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:37:05+00:00

<img alt="Pijana zapytała strażników miejskich o wyjazd z parkingu. Chwilę później wsiadła za kółko " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-1sarb7-straznicy-miejscy-interweniowali-w-wilanowie-7191801/alternates/LANDSCAPE_1280" />
    Do strażników miejskich podeszła pijana kobieta i zapytała, gdzie znajduje się wyjazd z parkingu. Po chwili wsiadła za kółko. - Miała blisko trzy promile alkoholu w organizmie - informują funkcjonariusze.

## Onet Premium & TVN24 GO w jednym pakiecie. Rusza wspólny projekt TVN Warner Bros. Discovery i RAS Polska
 - [https://tvn24.pl/polska/onet-premium-and-tvn24-go-wspolny-pakiet-ras-polska-i-tvn-warner-bros-discovery-co-zawiera-7378215?source=rss](https://tvn24.pl/polska/onet-premium-and-tvn24-go-wspolny-pakiet-ras-polska-i-tvn-warner-bros-discovery-co-zawiera-7378215?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:36:35+00:00

<img alt="Onet Premium &amp; TVN24 GO w jednym pakiecie. Rusza wspólny projekt TVN Warner Bros. Discovery i RAS Polska" src="https://tvn24.pl/najnowsze/cdn-zdjecie-75l87t-tvn24-5336261/alternates/LANDSCAPE_1280" />
    Ruszył kolejny projekt RAS Polska i TVN Warner Bros. Discovery. W ramach nowej oferty można zakupić pakiet łączący TVN24 GO oraz Onet Premium. Dodatkowo użytkownicy mają możliwość zalogowania się na obu serwisach za pomocą własnych loginów, tj. kontem TVN i poprzez O!Konto.

## Duże utrudnienia dla klientów. Na liście największy bank w Polsce
 - [https://tvn24.pl/biznes/z-kraju/przerwy-w-bankach-pko-bp-santander-bank-polska-ing-bank-slaski-alior-bank-bank-bps-oraz-bank-pocztowy-utrudnienia-lista-7378219?source=rss](https://tvn24.pl/biznes/z-kraju/przerwy-w-bankach-pko-bp-santander-bank-polska-ing-bank-slaski-alior-bank-bank-bps-oraz-bank-pocztowy-utrudnienia-lista-7378219?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:33:52+00:00

<img alt="Duże utrudnienia dla klientów. Na liście największy bank w Polsce" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-e63lyx-platnosc-karta-w-internecie-4221857/alternates/LANDSCAPE_1280" />
    PKO BP, Santander Bank Polska, ING Bank Śląski, Alior Bank, Bank BPS oraz Bank Pocztowy - to banki, które zaplanowały prace serwisowe w najbliższych dniach. W związku z tym klienci muszą się przygotować na utrudnienia. Część z nich może mieć problemy z płatnościami kartą w internecie.

## Kolejny pakiet pomocy dla Kijowa. "Wyraz zaangażowania Szwecji w długoterminowe wsparcie Ukrainy"
 - [https://tvn24.pl/swiat/szwecja-kolejny-pakiet-pomocy-wojskowej-dla-ukrainy-7378326?source=rss](https://tvn24.pl/swiat/szwecja-kolejny-pakiet-pomocy-wojskowej-dla-ukrainy-7378326?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:32:12+00:00

<img alt="Kolejny pakiet pomocy dla Kijowa. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ylmkrh-ukraina-wojsko-7290680/alternates/LANDSCAPE_1280" />
    Rząd Szwecji ogłosił w piątek czternasty pakiet wsparcia Ukrainy w jej wojnie obronnej z Rosją. Darowizna zawiera między innymi amunicję artyleryjską kalibru 155 mm oraz amunicję do przekazanego wcześniej wozu bojowego piechoty CV90. Zlecono również analizę możliwości odstąpienia samolotów bojowych Gripen.

## Wiceminister Jabłoński publikuje sprostowanie i oświadczenie. Jedno przeczy drugiemu
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wiceminister-pawel-jablonski-zamiescil-sprostowanie-i-oswiadczenie-po-przegranym-procesie-chodzilo-o-film-agnieszki-holland-7377923?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wiceminister-pawel-jablonski-zamiescil-sprostowanie-i-oswiadczenie-po-przegranym-procesie-chodzilo-o-film-agnieszki-holland-7377923?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:24:58+00:00

<img alt="Wiceminister Jabłoński publikuje sprostowanie i oświadczenie. Jedno przeczy drugiemu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-35ik2-jablonski-wpis-7378082/alternates/LANDSCAPE_1280" />
    Wiceminister spraw zagranicznych Paweł Jabłoński, startujący do Sejmu z listy PiS, zamieścił nakazane przez sąd sprostowanie po przegranym procesie w trybie wyborczym wytoczonym przez Marzannę Gądek-Radwanowską, nauczycielkę i kandydatkę KO. Proces dotyczył jego wpisu, w którym stwierdził, że "nauczycielka-polityk PO chciała wysłać uczniów na putinowski film A. Holland". Razem ze sprostowaniem zamieścił także oświadczenie, w którym stwierdza, że sprostowanie nakazał "sąd-cenzor", a jego treść "jest oczywiście nieprawdziwa".

## Jechał boso i bez kasku, miał ptasie pióra i głośnik. "Taki styl bycia"
 - [https://tvn24.pl/lodz/lodz-motocyklista-jechal-boso-bez-kasku-i-uprawnien-przy-kierownicy-mial-ptasie-piora-i-glosnik-7378195?source=rss](https://tvn24.pl/lodz/lodz-motocyklista-jechal-boso-bez-kasku-i-uprawnien-przy-kierownicy-mial-ptasie-piora-i-glosnik-7378195?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:17:06+00:00

<img alt="Jechał boso i bez kasku, miał ptasie pióra i głośnik. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-hpbrzy-jechal-bez-kasku-boso-i-bez-uprawnien-motocyklem-7378148/alternates/LANDSCAPE_1280" />
    Policjanci z łódzkiej drogówki zatrzymali motocyklistę, który jechał przez miasto boso i bez kasku. Dodatkowo mężczyzna nie posiadał uprawnień do kierowania pojazdem. Jak informuje policja, motocyklista ozdobił kierownicę ptasimi piórami i zamontował głośnik bluetooth, żeby wyraźniej słyszeć muzykę w trakcie jazdy. Podczas kontroli wyjaśnił, że ma "taki styl bycia".

## 43 miliony dzieci zmuszonych do opuszczenia swoich domów. Średnio 20 tysięcy dziennie
 - [https://tvn24.pl/tvnmeteo/najnowsze/zmiany-klimatu-kataklizmy-pogodowe-spowodowaly-przesiedlenia-ponad-43-milionow-dzieci-unicef-7378129?source=rss](https://tvn24.pl/tvnmeteo/najnowsze/zmiany-klimatu-kataklizmy-pogodowe-spowodowaly-przesiedlenia-ponad-43-milionow-dzieci-unicef-7378129?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:14:39+00:00

<img alt="43 miliony dzieci zmuszonych do opuszczenia swoich domów. Średnio 20 tysięcy dziennie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-q7ynw2-dzieci-powodz-tangerang-indonezja-2021-rok-7378116/alternates/LANDSCAPE_1280" />
    Ponad 43 miliony dzieci musiało opuścić swoje domy w latach 2016-2021 z powodu kataklizmów pogodowych, wywołanych zmianami klimatu, alarmuje organizacja UNICEF. Autorzy raportu przewidują, że w kolejnych 30 latach liczba ta zwiększy się - przesiedlenia mogą objąć 100 milionów dzieci.

## 43-latka wysiadła z auta po kolizji i ruszyła w poprzek drogi. Zginęła na miejscu
 - [https://tvn24.pl/lodz/tomaszow-mazowiecki-43-latka-smiertelnie-potracona-przez-autobus-na-s8-chwile-wczesniej-miala-kolizje-7377862?source=rss](https://tvn24.pl/lodz/tomaszow-mazowiecki-43-latka-smiertelnie-potracona-przez-autobus-na-s8-chwile-wczesniej-miala-kolizje-7377862?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T10:05:38+00:00

<img alt="43-latka wysiadła z auta po kolizji i ruszyła w poprzek drogi. Zginęła na miejscu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-so1i0m-do-tragedii-doszlo-w-czwartek-wieczorem-7377863/alternates/LANDSCAPE_1280" />
    Policja pod nadzorem prokuratury bada okoliczności śmierci 43-letniej kobiety, która została śmiertelnie potrącona przez autobus na drodze S8 w pobliżu Tomaszowa Mazowieckiego (woj. łódzkie). - Z naszych ustaleń wynika, że kobieta najpierw miała kolizję z ciężarówką, a potem ruszyła w poprzek drogi ekspresowej - przekazuje aspirant sztabowy Grzegorz Stasiak z tomaszowskiej komendy powiatowej.

## Samorządowiec zginął w wypadku samochodowym. Są wyniki sekcji zwłok
 - [https://tvn24.pl/rzeszow/nowy-grebow-samorzadowiec-zginal-w-wypadku-samochodowym-sa-wyniki-sekcji-zwlok-7377986?source=rss](https://tvn24.pl/rzeszow/nowy-grebow-samorzadowiec-zginal-w-wypadku-samochodowym-sa-wyniki-sekcji-zwlok-7377986?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:50:52+00:00

<img alt="Samorządowiec zginął w wypadku samochodowym. Są wyniki sekcji zwłok" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vujc5e-samorzadowiec-zginal-w-wypadku-samochodowym-7377991/alternates/LANDSCAPE_1280" />
    Ostra niewydolność krążeniowo-oddechowa spowodowana poważnym urazem głowy była przyczyną śmierci 60-letniego samorządowca z Podkarpacia, który zginął we wrześniu w wypadku. Do zdarzenia doszło w miejscowości Nowy Grębów (woj. podkarpackie).

## Nie ustąpił pierwszeństwa i wjechał pod ciężarówkę. 35-latek nie żyje
 - [https://tvn24.pl/lodz/stara-sobotka-leczyca-nie-ustapil-pierwszenstwa-i-wjechal-pod-nadjezdzajaca-ciezarowke-35-latek-nie-zyje-7378043?source=rss](https://tvn24.pl/lodz/stara-sobotka-leczyca-nie-ustapil-pierwszenstwa-i-wjechal-pod-nadjezdzajaca-ciezarowke-35-latek-nie-zyje-7378043?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:47:18+00:00

<img alt="Nie ustąpił pierwszeństwa i wjechał pod ciężarówkę. 35-latek nie żyje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-i4xn0n-tragiczny-wypadek-pod-leczyca-7377962/alternates/LANDSCAPE_1280" />
    Tragiczny wypadek w Starej Sobótce koło Łęczycy (woj. łódzkie). Kierujący samochodem osobowym nie ustąpił pierwszeństwa i wjechał pod nadjeżdżającą ciężarówkę. Jak informuje policja, 35-latek zginął na miejscu, a ranny 40-letni kierowca ciężarówki został zabrany do szpitala.

## Dziewięciolatek wyszedł z autobusu szkolnego i wpadł pod koła wozu strażackiego
 - [https://tvn24.pl/lublin/majdany-dziewieciolatek-potracony-przez-woz-strazacki-chlopiec-mial-wbiec-pod-samochod-7377796?source=rss](https://tvn24.pl/lublin/majdany-dziewieciolatek-potracony-przez-woz-strazacki-chlopiec-mial-wbiec-pod-samochod-7377796?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:39:15+00:00

<img alt="Dziewięciolatek wyszedł z autobusu szkolnego i wpadł pod koła wozu strażackiego" src="https://tvn24.pl/trojmiasto/cdn-zdjecie-oxyyym-chlopiec-trafil-do-szpitala-4661565/alternates/LANDSCAPE_1280" />
    Dziewięcioletni chłopiec został ranny i przetransportowany do szpitala po tym, jak w miejscowości Majdany (woj. lubelskie) został potrącony przez wóz strażacki. Jak przekazała policja, dziecko miało "wtargnąć" na drogę pod nadjeżdżający samochód.

## Ukradł posąg orła i sprzedał na złom, a skradzioną tablicę pamiątkową schował w tapczanie
 - [https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-kradziez-posagu-orla-z-pamiatkowa-tablica-calosc-byla-warta-prawie-100-tysiecy-zlotych-7377886?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-kradziez-posagu-orla-z-pamiatkowa-tablica-calosc-byla-warta-prawie-100-tysiecy-zlotych-7377886?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:34:46+00:00

<img alt="Ukradł posąg orła i sprzedał na złom, a skradzioną tablicę pamiątkową schował w tapczanie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wit0fx-zlodziej-ukradl-posag-z-posesji-7377922/alternates/LANDSCAPE_1280" />
    Policjanci pracowali nad sprawą kradzieży posągu orła, wraz z tablicą pamiątkową, o łącznej wartości prawie 100 tysięcy złotych. Wytypowali podejrzanego o kradzież i złożyli mu "wizytę". Okazało się, że 31 latek z Ciechanowa orła sprzedał, a tablicę ukrył w tapczanie.

## "Polki boją się zachodzić w ciąże i będą się bały". Wyborczy debiutanci o powodach obaw o bezpieczeństwo kobiet
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debiutanci-edyta-lipniowiecka-trzecia-droga-mikolaj-szczepanowski-bezpartyjni-samorzadowcy-o-prawach-kobiet-aborcji-i-in-vitro-7378070?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-debiutanci-edyta-lipniowiecka-trzecia-droga-mikolaj-szczepanowski-bezpartyjni-samorzadowcy-o-prawach-kobiet-aborcji-i-in-vitro-7378070?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:23:17+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-us7zrp-06-0935-debiuty-goscie-2-0015-7377932/alternates/LANDSCAPE_1280" />
    Kandydujący po raz pierwszy do Sejmu Edyta Lipniowiecka (Trzecia Droga) i Mikołaj Szczepanowski (Bezpartyjni Samorządowcy) w "Czasie decyzji: debiuty" w TVN24 mówili o bezpieczeństwie kobiet przy porodach, aborcji oraz in vitro. - To oczywiste, że naruszenie kompromisu aborcyjnego mogło naruszyć poczucie bezpieczeństwa kobiet - powiedział Szczepanowski. - Polki boją się zachodzić w ciąże i będą się bały - podkreśliła Lipniowiecka.

## Ostatnie w tym roku mycie pętli autobusowej przy Dworcu Centralnym. Przystanki będą częściowo wyłączone
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mycie-petli-przy-dworcu-centralnym-utrudnienia-7378025?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mycie-petli-przy-dworcu-centralnym-utrudnienia-7378025?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:18:39+00:00

<img alt="Ostatnie w tym roku mycie pętli autobusowej przy Dworcu Centralnym. Przystanki będą częściowo wyłączone" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-kx87s5-zadaszenia-sa-myte-woda-pod-cisnieniem-7378078/alternates/LANDSCAPE_1280" />
    Sprzątanie pętli autobusowej przy Dworcu Centralnym rozpocznie się rano, w sobotę 7 października i potrwa do 8 października. Prace spowodują zmiany w odjazdach autobusów - zapowiada Zarząd Oczyszczania Miasta.

## WHO: Śmiertelna choroba znana z tropików zagraża Europie
 - [https://tvn24.pl/swiat/who-denga-zagraza-europie-ostrzega-ekspert-chorobe-przenosza-komary-7377780?source=rss](https://tvn24.pl/swiat/who-denga-zagraza-europie-ostrzega-ekspert-chorobe-przenosza-komary-7377780?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:11:52+00:00

<img alt="WHO: Śmiertelna choroba znana z tropików zagraża Europie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ocnpnb-komar-egipski-aedes-aegypti-7082424/alternates/LANDSCAPE_1280" />
    Jeszcze w tej dekadzie denga rozprzestrzeni się w Europie, USA i Afryce, ostrzega ekspert Światowej Organizacji Zdrowia. Według niego kraje muszą się odpowiednio przygotować na nadejście dengi, bo będzie ona stanowić znaczne obciążenie dla szpitali.

## Bruksela szykuje duże zmiany. "Potężna gałąź przemysłu"
 - [https://tvn24.pl/biznes/ze-swiata/nieruchomosci-najem-krotkoterminowy-miasta-dostana-furtke-do-wprowadzenia-ograniczen-7377947?source=rss](https://tvn24.pl/biznes/ze-swiata/nieruchomosci-najem-krotkoterminowy-miasta-dostana-furtke-do-wprowadzenia-ograniczen-7377947?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T09:10:03+00:00

<img alt="Bruksela szykuje duże zmiany. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-qi64h1-paryz-francja-s2511-shutterstock_2090668288_1-7377995/alternates/LANDSCAPE_1280" />
    Unijne rozporządzenie może pomóc ucywilizować zjawisko najmu krótkoterminowego, ale i otworzyć furtkę do wprowadzania ograniczeń - informuje "Rzeczpospolita".  Dziennik wskazuje, że nowe regulacje są kluczowe dla miast, które od lat chcą zapanować nad tym zjawiskiem.

## PE potępia atak Azerbejdżanu na Górski Karabach: obecna sytuacja jest równoznaczna z czystkami etnicznymi
 - [https://tvn24.pl/swiat/parlament-europejski-azerbejdzan-sytuacja-ormian-uciekajacych-z-gorskiego-karabachu-jest-rownoznaczna-z-czystkami-etnicznymi-7377695?source=rss](https://tvn24.pl/swiat/parlament-europejski-azerbejdzan-sytuacja-ormian-uciekajacych-z-gorskiego-karabachu-jest-rownoznaczna-z-czystkami-etnicznymi-7377695?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:46:40+00:00

<img alt="PE potępia atak Azerbejdżanu na Górski Karabach: obecna sytuacja jest równoznaczna z czystkami etnicznymi" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-7z3qd2-trwa-ucieczka-tysiecy-ormian-z-gorskiego-karabachu-7369011/alternates/LANDSCAPE_1280" />
    Unia Europejska musi dokonać przeglądu swoich stosunków z Azerbejdżanem w związku z sytuacją w Górskim Karabachu - uznał Parlament Europejski w przyjętej w czwartek rezolucji. PE ocenił, że obecna sytuacja Ormian uciekających z Górskiego Karabachu jest równoznaczna z czystkami etnicznymi. Posłowie wezwali Turcję do powstrzymania swojego sojusznika - Azerbejdżanu.

## Sprawca zamachów w nowojorskim metrze skazany na dożywocie. "Akt czystego zła"
 - [https://tvn24.pl/swiat/usa-sprawca-zamachu-w-nowojorskim-metrze-skazany-na-10-krotne-dozywocie-7377776?source=rss](https://tvn24.pl/swiat/usa-sprawca-zamachu-w-nowojorskim-metrze-skazany-na-10-krotne-dozywocie-7377776?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:36:40+00:00

<img alt="Sprawca zamachów w nowojorskim metrze skazany na dożywocie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-v26bul-frank-james-7378023/alternates/LANDSCAPE_1280" />
    Sąd federalny dla nowojorskiego Brooklynu skazał sprawcę ataku terrorystycznego w metrze na karę dziesięciokrotnego dożywocia, informują media. Mężczyzna w kwietniu ubiegłego roku otworzył ogień w pociągu metra, raniąc dziesięć osób. Podczas procesu stwierdził, że nie planował nikogo zabić, a "jedynie poważnie zranić".

## U Morawieckiego na bogato. Nowy rekord
 - [https://tvn24.pl/biznes/z-kraju/budzet-kancelarii-premiera-przebil-sufit-7377878?source=rss](https://tvn24.pl/biznes/z-kraju/budzet-kancelarii-premiera-przebil-sufit-7377878?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:33:44+00:00

<img alt="U Morawieckiego na bogato. Nowy rekord" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-5a09rt-premier-mateusz-morawiecki-7377890/alternates/LANDSCAPE_1280" />
    Po raz pierwszy w historii roczny budżet kancelarii premiera ma przebić barierę dwóch miliardów złotych - podaje "Rzeczpospolita". Dziennik dodaje, że zdaniem rządu wydatki są uzasadnione, opozycja uważa inaczej.

## Morawiecki o pakiecie migracyjnym po nieformalnym szczycie UE
 - [https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-wecie-7377903?source=rss](https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-wecie-7377903?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:15:29+00:00

<img alt="Morawiecki o pakiecie migracyjnym po nieformalnym szczycie UE" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5mdbw4-premier-mateusz-morawiecki-po-szczycie-ue-w-grenadzie-7378975/alternates/LANDSCAPE_1280" />
    Podjąłem decyzję o zawetowaniu tej części, która dotyczyła migracji. Nie ma tego zapisu - powiedział w piątek premier Mateusz Morawiecki po zakończonym nieformalnym szczycie Unii Europejskiej w hiszpańskiej Grenadzie. Jak ustalił korespondent TVN24 Maciej Sokołowski, działania Mateusza Morawieckiego nie zmieniają jednak wcześniejszych ustaleń dotyczących migracji, które zostały przekazane do negocjacji w Parlamencie Europejskim.

## Nieformalny szczyt Unii Europejskiej. Morawiecki w Grenadzie o "partii Tuska" i "dyktacie, który płynie z Brukseli i Berlina"
 - [https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-stanowisku-polskiego-rzadu-7377903?source=rss](https://tvn24.pl/swiat/unia-europejska-migracja-szczyt-w-grenadzie-premier-morawiecki-o-stanowisku-polskiego-rzadu-7377903?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:15:29+00:00

<img alt="Nieformalny szczyt Unii Europejskiej. Morawiecki w Grenadzie o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ad6rv3-premier-mateusz-morawiecki-w-grenadzie-7377887/alternates/LANDSCAPE_1280" />
    W hiszpańskiej Grenadzie odbywa się nieformalny szczyt Unii Europejskiej, który jest poświęcony między innymi kwestiom migracyjnym. Przed posiedzeniem premier Mateusz Morawiecki zapowiedział, że polski rząd odrzuca proponowane rozwiązania. - My chcemy spokoju, bezpieczeństwa i chcemy przewidywalności - stwierdził.

## Słowenia: elektrownia jądrowa w Krsko wyłączona z powodu wycieku w systemie chłodzenia
 - [https://tvn24.pl/swiat/slowenia-sta-elektrownia-jadrowa-w-krsko-zostanie-wylaczona-z-powodu-wycieku-w-systemie-chlodzenia-7377694?source=rss](https://tvn24.pl/swiat/slowenia-sta-elektrownia-jadrowa-w-krsko-zostanie-wylaczona-z-powodu-wycieku-w-systemie-chlodzenia-7377694?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:08:51+00:00

<img alt="Słowenia: elektrownia jądrowa w Krsko wyłączona z powodu wycieku w systemie chłodzenia" src="https://tvn24.pl/najnowsze/cdn-zdjecieb41b9d7eccf01d6944a1a223c8b08c59-0506-elektrownia-avi-559561/alternates/LANDSCAPE_1280" />
    Elektrownia jądrowa na wschodzie Słowenii, umiejscowiona 50 kilometrów od stolicy Chorwacji - Zagrzebia, została w czwartek wyłączona z powodu wycieku w systemie chłodzenia reaktora – poinformowała słoweńska agencja informacyjna STA. Tymczasem planowana jest już budowa drugiego reaktora elektrowni, której współwłaścicielem jest Chorwacja.

## "Myśmy już, jako kierowcy, za tę obniżkę zapłacili"
 - [https://tvn24.pl/biznes/z-kraju/sytuacja-na-rynku-paliw-inflacja-stopy-procentowe-w-polsce-komentuje-grazyna-piotrowska-oliwa-7377797?source=rss](https://tvn24.pl/biznes/z-kraju/sytuacja-na-rynku-paliw-inflacja-stopy-procentowe-w-polsce-komentuje-grazyna-piotrowska-oliwa-7377797?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T08:02:43+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h56u7p-pap_20230104_0ou-7377963/alternates/LANDSCAPE_1280" />
    Nie trzeba być wybitnym ekonomistą czy prezesem NBP, żeby wiedzieć, że jeśli podaż nie spotyka się z popytem, to niestety może być tylko jeden efekt: awaria dystrybutora - powiedziała w TVN24 Grażyna Piotrowska-Oliwa, menadżerka, inwestorka i była prezeska PGNiG na antenie TVN24. Jej zdaniem wysokie ceny ropy w połączeniu ze słabym złotym powodują, że ceny paliw powinny być wyższe. Inna sytuacja na obserwowana obecnie na stacjach to - jak oceniła - "płynna kiełbasa wyborcza".

## Pies Joe Bidena usunięty z Białego Domu po serii pogryzień personelu
 - [https://tvn24.pl/swiat/joe-biden-pies-prezydenta-pogryzl-agentow-i-personel-zostal-usuniety-z-bialego-domu-7377741?source=rss](https://tvn24.pl/swiat/joe-biden-pies-prezydenta-pogryzl-agentow-i-personel-zostal-usuniety-z-bialego-domu-7377741?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T07:39:56+00:00

<img alt="Pies Joe Bidena usunięty z Białego Domu po serii pogryzień personelu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ymuyus-joe-biden-i-jego-pies-commander-7363141/alternates/LANDSCAPE_1280" />
    Pies prezydenta USA Joe Bidena Commander został usunięty z Białego Domu w związku z serią incydentów, kiedy to pogryzł zatrudniony tam personel, w tym funkcjonariuszy Secret Service.

## Jedna osoba nie żyje, a prawie 400 jest rannych. Tajfun idzie dalej
 - [https://tvn24.pl/tvnmeteo/swiat/tajfun-koinu-zagraza-chinom-jedna-osoba-nie-zyje-a-prawie-400-jest-rannych-na-tajwanie-7377901?source=rss](https://tvn24.pl/tvnmeteo/swiat/tajfun-koinu-zagraza-chinom-jedna-osoba-nie-zyje-a-prawie-400-jest-rannych-na-tajwanie-7377901?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T07:36:00+00:00

<img alt="Jedna osoba nie żyje, a prawie 400 jest rannych. Tajfun idzie dalej" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-a2pade-zniszczenia-na-poludniu-tajwanu-7377908/alternates/LANDSCAPE_1280" />
    Tajfun Koinu zagraża południowo-wschodnim prowincjom Chin po tym, jak spowodował śmierć jednej osoby i obrażenia u setek innych na Tajwanie. Służby meteorologiczne ostrzegają przed ulewami i silnym wiatrem.

## Donald Trump nie będzie ubiegał się o funkcję spikera Izby Reprezentantów
 - [https://tvn24.pl/swiat/usa-donald-trumpnie-bedzie-ubiegal-sie-o-funkcje-spikera-izby-reprezentantow-jim-jordan-z-poparciem-bylego-prezydenta-7377782?source=rss](https://tvn24.pl/swiat/usa-donald-trumpnie-bedzie-ubiegal-sie-o-funkcje-spikera-izby-reprezentantow-jim-jordan-z-poparciem-bylego-prezydenta-7377782?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T07:33:54+00:00

<img alt="Donald Trump nie będzie ubiegał się o funkcję spikera Izby Reprezentantów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4o7szy-donald-trump-7377795/alternates/LANDSCAPE_1280" />
    Były prezydent USA Donald Trump nie będzie ubiegał się o funkcję spikera Izby Reprezentantów. Polityk ogłosił, że popiera kandydaturę na to stanowisko Jima Jordana, republikańskiego kongresmena i swojego bliskiego współpracownika - podała w piątek agencja AP.

## Tragiczny wypadek. Samochód uderzył w drzewo, nie żyją dwie młode osoby
 - [https://tvn24.pl/olsztyn/sawica-zjechali-z-drogi-i-uderzyli-w-drzewo-nie-zyje-22-latek-i-17-latka-23-latek-walczy-o-zycie-w-szpitalu-7377810?source=rss](https://tvn24.pl/olsztyn/sawica-zjechali-z-drogi-i-uderzyli-w-drzewo-nie-zyje-22-latek-i-17-latka-23-latek-walczy-o-zycie-w-szpitalu-7377810?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T07:18:02+00:00

<img alt="Tragiczny wypadek. Samochód uderzył w drzewo, nie żyją dwie młode osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kr2fwz-auto-uderzylo-w-drzewo-7377816/alternates/LANDSCAPE_1280" />
    Na wysokości miejscowości Sawica (woj. warmińsko-mazurskie) samochód uderzył w drzewo. Nie żyją dwie osoby, trzecia trafiła w bardzo ciężkim stanie do szpitala. Policja zatrzymała 26-latka, który wyszedł z wypadku bez szwanku. Był nietrzeźwy.

## Nie działa sygnalizacja, rogatki podniesione. Kierowca zatrzymuje autobus tuż przed rozpędzonym pociągiem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/plock-rogatki-w-gorze-na-stacje-wjezdza-pociag-film-7377726?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/plock-rogatki-w-gorze-na-stacje-wjezdza-pociag-film-7377726?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T07:10:02+00:00

<img alt="Nie działa sygnalizacja, rogatki podniesione. Kierowca zatrzymuje autobus tuż przed rozpędzonym pociągiem" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pq50ig-do-zdarzenia-doszlo-w-plocku-7377743/alternates/LANDSCAPE_1280" />
    Do niebezpiecznej sytuacji doszło w czwartek rano w Płocku. Autobus miejski zbliżał się to torów. Rogatki były w górze, a na przejazd wjechał pociąg. Sprawę wyjaśnia powołania przez kolejarzy komisja, dróżnik został zawieszony.

## "Dzieci pragną być blisko swoich idoli". Czy rodzic powinien kontrolować, co robią w internecie?
 - [https://tvn24.pl/polska/afera-z-polskimi-youtuberami-jak-rozmawiac-z-dziecmi-mowia-eksperci-7376314?source=rss](https://tvn24.pl/polska/afera-z-polskimi-youtuberami-jak-rozmawiac-z-dziecmi-mowia-eksperci-7376314?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T06:55:28+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-risku-dziecko-dziewczeta-telefon-depresja-smutek-7358971/alternates/LANDSCAPE_1280" />
    Doniesienia o nadużyciach, jakich mieli dopuszczać się internetowi influencerzy, mogą wzbudzić niepokój rodziców dzieci, dla których osoby znane z ekranu smartfona są często idolami. Jak przygotować najmłodszych na zagrożenia? Jak z nim rozmawiać? Czy i jak kontrolować aktywność dziecka w internecie? Zapytaliśmy o to ekspertów.

## Dzieci w sieci: Bezpieczne dziecko to takie, które jest świadome, że jeszcze wszystkiego nie wie
 - [https://tvn24.pl/polska/pandora-gate-afera-z-polskimi-youtuberami-jak-rozmawiac-z-dziecmi-mowia-eksperci-7376314?source=rss](https://tvn24.pl/polska/pandora-gate-afera-z-polskimi-youtuberami-jak-rozmawiac-z-dziecmi-mowia-eksperci-7376314?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T06:55:28+00:00

<img alt="Dzieci w sieci: Bezpieczne dziecko to takie, które jest świadome, że jeszcze wszystkiego nie wie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-risku-dziecko-dziewczeta-telefon-depresja-smutek-7358971/alternates/LANDSCAPE_1280" />
    Doniesienia o nadużyciach, jakich mieli dopuszczać się internetowi influencerzy, mogą wzbudzić niepokój rodziców dzieci, dla których osoby znane z ekranu smartfona są często idolami. Jak przygotować najmłodszych na zagrożenia? Jak z nim rozmawiać? Czy i jak kontrolować aktywność dziecka w internecie? Zapytaliśmy o to ekspertów.

## Seria wstrząsów w rejonie superwulkanu koło Neapolu. Próbne ewakuacje w szpitalach
 - [https://tvn24.pl/tvnmeteo/swiat/wlochy-superwulkan-trzesienia-ziemi-kolo-neapolu-probne-ewakuacje-w-szpitalach-7377779?source=rss](https://tvn24.pl/tvnmeteo/swiat/wlochy-superwulkan-trzesienia-ziemi-kolo-neapolu-probne-ewakuacje-w-szpitalach-7377779?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T06:48:58+00:00

<img alt="Seria wstrząsów w rejonie superwulkanu koło Neapolu. Próbne ewakuacje w szpitalach" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-op090r-skutki-trzesienia-7373338/alternates/LANDSCAPE_1280" />
    Na piątek zaplanowano próbne ewakuacje ze szpitali na Polach Flegrejskich w południowych Włoszech. To ćwiczenia na wypadek silnego trzęsienia ziemi na terenie superwulkanu. W ciągu ostatnich tygodni doszło tam do serii wstrząsów, co spowodowało obawy ludności i apele ekspertów o opracowanie planów ewakuacji.

## W sobotę pielęgnacja drzew przy torowiskach. Tramwaje pojadą objazdami
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wykonaja-prace-pielegnacyjne-drzew-tramwaje-na-objazdach-7377759?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-wykonaja-prace-pielegnacyjne-drzew-tramwaje-na-objazdach-7377759?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T06:03:59+00:00

<img alt="W sobotę pielęgnacja drzew przy torowiskach. Tramwaje pojadą objazdami " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-iwznkn-tramwaje-pojada-objazdami-7377762/alternates/LANDSCAPE_1280" />
    W sobotę, w pobliżu torowisk tramwajowych na Pradze, będą wykonywane prace pielęgnacyjne drzew. W tym czasie, jak informuje Zarząd Transportu Miejskiego, tramwaje linii 6, 20, 23 i 28 pojadą objazdami.

## Pękła tama, jezioro polodowcowe zalało miejscowości. Znajdują kolejne ciała
 - [https://tvn24.pl/tvnmeteo/swiat/indie-rosnie-liczba-ofiar-powodzi-pekla-tama-jezioro-polodowcowe-zalalo-miasta-i-wsie-7377738?source=rss](https://tvn24.pl/tvnmeteo/swiat/indie-rosnie-liczba-ofiar-powodzi-pekla-tama-jezioro-polodowcowe-zalalo-miasta-i-wsie-7377738?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T05:56:08+00:00

<img alt="Pękła tama, jezioro polodowcowe zalało miejscowości. Znajdują kolejne ciała" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-o0otey-powodz-blyskawiczna-w-indiach-7377766/alternates/LANDSCAPE_1280" />
    Rośnie liczba śmiertelnych ofiar gwałtownej powodzi, do której doszło w górzystym stanie Indii po przepełnieniu się jeziora polodowcowego. Władze poinformowały, że zginęło co najmniej 40 osób, a około 100 osób jest uznawanych za zaginionych. Trwają ewakuacje tysięcy turystów, którzy utknęli na zalanych terenach.

## Wicepremier Ukrainy: nasza Armia IT wstrzymała działanie największych lotnisk w Rosji
 - [https://tvn24.pl/swiat/ukraina-wicepremier-nasza-armia-it-wstrzymala-dzialanie-najwiekszych-lotnisk-w-rosji-7377703?source=rss](https://tvn24.pl/swiat/ukraina-wicepremier-nasza-armia-it-wstrzymala-dzialanie-najwiekszych-lotnisk-w-rosji-7377703?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T05:49:18+00:00

<img alt="Wicepremier Ukrainy: nasza Armia IT wstrzymała działanie największych lotnisk w Rosji" src="https://tvn24.pl/najnowsze/cdn-zdjecie-byzoy3-domodedovo-airport-7300049/alternates/LANDSCAPE_1280" />
    Ukraińska Armia IT wstrzymała działanie największych lotnisk w Rosji. Cyberofensywa trwa - oświadczył ukraiński wicepremier Mychajło Fedorow. "Jeśli ukraińskie lotniska nie mogą działać z powodu wojny, to czemu mają rosyjskie?" - napisał.

## Atak dronów na akademię wojskową w Syrii. Setki zabitych i rannych
 - [https://tvn24.pl/swiat/syria-po-ataku-dronow-na-akademie-wojskowa-setki-zabitych-i-rannych-7377699?source=rss](https://tvn24.pl/swiat/syria-po-ataku-dronow-na-akademie-wojskowa-setki-zabitych-i-rannych-7377699?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T05:47:46+00:00

<img alt="Atak dronów na akademię wojskową w Syrii. Setki zabitych i rannych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-mokd7q-wielu-zabitych-i-rannych-w-ataku-dronow-na-akademie-wojskowa-w-syrii-7377696/alternates/LANDSCAPE_1280" />
    Ponad 110 osób zginęło, a co najmniej 120 zostało rannych w czwartkowym ataku dronów na akademię wojskową w Homs - podało w nocy z czwartku na piątek Syryjskie Obserwatorium Praw Człowieka. Wcześniej władze w Damaszku informowały o 80 zabitych i 240 rannych. Istnieją obawy, że liczba ofiar śmiertelnych może jeszcze wzrosnąć, ponieważ wielu rannych jest w stanie ciężkim lub krytycznym - przekazała agencja AP.

## "Absurd nie czytać". To będzie wyjątkowa noc w stołecznych bibliotekach
 - [https://tvn24.pl/tvnwarszawa/kultura/warszawa-absurd-nie-czytac-noc-bibliotek-kiedy-gdzie-7377237?source=rss](https://tvn24.pl/tvnwarszawa/kultura/warszawa-absurd-nie-czytac-noc-bibliotek-kiedy-gdzie-7377237?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T05:40:36+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie138c44eff5f81436b0bc1a2a02a27cb5-ksiazki-sa-brakuje-czytelnikow-2419103/alternates/LANDSCAPE_1280" />
    W sobotę, 9 października, odbędzie się Noc Bibliotek. Dziewiątej edycji tej ogólnopolskiej akcji przyświeca hasło "Absurd nie czytać". W samej Warszawie około 50 bibliotek przygotowało atrakcje dla całych rodzin.

## Park Bródnowski. "Mieszkańcy z niepokojem patrzą na koncepcję zmian, wiele z nich budzi kontrowersje"
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mieszkancy-nie-chca-zmian-w-parku-brodnowskim-7364665?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-mieszkancy-nie-chca-zmian-w-parku-brodnowskim-7364665?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T04:08:09+00:00

<img alt="Park Bródnowski. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9pogto-park-brodnowski-7371734/alternates/LANDSCAPE_1280" />
    Mieszkańcy obawiają się, że po zakończeniu planowanych prac w Parku Bródnowskim, to miejsce utraci swój spokojny, zielony charakter. Wskazują na planowane wycinki drzew czy budowę drogi pożarowej, która - ich zdaniem - w praktyce oznaczać będzie wpuszczenie aut.

## Pogoda na dziś - piątek 06.10. W niektórych regionach spadnie deszcz i silnie powieje
 - [https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-0610-w-niektorych-regionach-spadnie-deszcz-i-silnie-powieje-7377634?source=rss](https://tvn24.pl/tvnmeteo/prognoza/pogoda-na-dzis-piatek-0610-w-niektorych-regionach-spadnie-deszcz-i-silnie-powieje-7377634?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-10-06T00:00:00+00:00

<img alt="Pogoda na dziś - piątek 06.10. W niektórych regionach spadnie deszcz i silnie powieje" src="https://tvn24.pl/najnowsze/cdn-zdjecie-adunpu-szykuje-sie-deszczowy-dzien-6122603/alternates/LANDSCAPE_1280" />
    Piątek 06.10 będzie pochmurny. Niektórzy powinni spodziewać się opadów deszczu. W części kraju prognozowane są silne porywy wiatru.

