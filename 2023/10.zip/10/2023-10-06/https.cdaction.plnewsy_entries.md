# Source:CD-Action - Newsy, URL:https://cdaction.pl/newsy, language:pl

## The Talos Principle 2: Twórcy ukryli demo na Steamie – CD-Action
 - [https://cdaction.pl/newsy/the-talos-principle-2-tworcy-ukryli-demo-na-steamie](https://cdaction.pl/newsy/the-talos-principle-2-tworcy-ukryli-demo-na-steamie)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T15:47:49.299942+00:00

The Talos Principle 2: Twórcy ukryli demo na Steamie – CD-Action

## Rząd Wielkiej Brytanii stawia kolejny krok na drodze do wdrożenia systemu rozpoznawania twarzy – CD-Action
 - [https://cdaction.pl/newsy/rzad-wielkiej-brytanii-stawia-kolejny-krok-na-drodze-do-wdrozenia-systemu-rozpoznawania-twarzy](https://cdaction.pl/newsy/rzad-wielkiej-brytanii-stawia-kolejny-krok-na-drodze-do-wdrozenia-systemu-rozpoznawania-twarzy)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T15:07:34.029882+00:00

Rząd Wielkiej Brytanii stawia kolejny krok na drodze do wdrożenia systemu rozpoznawania twarzy – CD-Action

## Bungie: Była pracownica pozywa studio za bezprawne zwolnienie – CD-Action
 - [https://cdaction.pl/newsy/bungie-byla-pracownica-pozywa-studio-za-bezprawne-zwolnienie](https://cdaction.pl/newsy/bungie-byla-pracownica-pozywa-studio-za-bezprawne-zwolnienie)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T14:28:20.538898+00:00

Bungie: Była pracownica pozywa studio za bezprawne zwolnienie – CD-Action

## Nowe sterowniki Intela do GPU Arc poprawiają wydajność w 20 grach – CD-Action
 - [https://cdaction.pl/newsy/nowe-sterowniki-intela-do-gpu-arc-poprawiaja-wydajnosc-w-20-grach](https://cdaction.pl/newsy/nowe-sterowniki-intela-do-gpu-arc-poprawiaja-wydajnosc-w-20-grach)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T13:47:32.522443+00:00

Nowe sterowniki Intela do GPU Arc poprawiają wydajność w 20 grach – CD-Action

## Assassin’s Creed Mirage: A nie, jednak będą DLC – CD-Action
 - [https://cdaction.pl/newsy/assassins-creed-mirage-a-nie-jednak-beda-dlc](https://cdaction.pl/newsy/assassins-creed-mirage-a-nie-jednak-beda-dlc)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T13:07:29.718003+00:00

Assassin’s Creed Mirage: A nie, jednak będą DLC – CD-Action

## Payday 3: Nowy patch z opóźnieniem – CD-Action
 - [https://cdaction.pl/newsy/payday-3-nowy-patch-z-opoznieniem](https://cdaction.pl/newsy/payday-3-nowy-patch-z-opoznieniem)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T12:47:33.842068+00:00

Payday 3: Nowy patch z opóźnieniem – CD-Action

## EA Sports WRC na nowym dziesięciominutowym zwiastunie – CD-Action
 - [https://cdaction.pl/newsy/ea-sports-wrc-na-nowym-dziesieciominutowym-zwiastunie](https://cdaction.pl/newsy/ea-sports-wrc-na-nowym-dziesieciominutowym-zwiastunie)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T12:07:33.645275+00:00

EA Sports WRC na nowym dziesięciominutowym zwiastunie – CD-Action

## Commandos: Origins zapowiedziane. Będzie nowa odsłona kultowej serii strategii wojennych – CD-Action
 - [https://cdaction.pl/newsy/commandos-origins-zapowiedziane-bedzie-nowa-odslona-kultowej-serii-strategii-wojennych](https://cdaction.pl/newsy/commandos-origins-zapowiedziane-bedzie-nowa-odslona-kultowej-serii-strategii-wojennych)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T11:47:31.959798+00:00

Commandos: Origins zapowiedziane. Będzie nowa odsłona kultowej serii strategii wojennych – CD-Action

## Epic Games zmienia ceny korzystania z Unreal Engine – CD-Action
 - [https://cdaction.pl/newsy/epic-games-zmienia-ceny-korzystania-z-unreal-engine](https://cdaction.pl/newsy/epic-games-zmienia-ceny-korzystania-z-unreal-engine)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T10:47:26.527390+00:00

Epic Games zmienia ceny korzystania z Unreal Engine – CD-Action

## Call of Duty: Modern Warfare 3 – Nowe szczegóły, zwiastuny i gameplaye po CoD Next – CD-Action
 - [https://cdaction.pl/newsy/call-of-duty-modern-warfare-3-nowe-szczegoly-zwiastuny-i-gameplaye-po-cod-next](https://cdaction.pl/newsy/call-of-duty-modern-warfare-3-nowe-szczegoly-zwiastuny-i-gameplaye-po-cod-next)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T10:08:33.193223+00:00

Call of Duty: Modern Warfare 3 – Nowe szczegóły, zwiastuny i gameplaye po CoD Next – CD-Action

## Sony Pictures Core: Nowa usługa VOD trafiła na PlayStation 4 i 5 – CD-Action
 - [https://cdaction.pl/newsy/sony-pictures-core-nowa-usluga-vod-trafila-na-playstation-4-i-5](https://cdaction.pl/newsy/sony-pictures-core-nowa-usluga-vod-trafila-na-playstation-4-i-5)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T09:27:46.164440+00:00

Sony Pictures Core: Nowa usługa VOD trafiła na PlayStation 4 i 5 – CD-Action

## Kolejny cyberatak na Sony. Wykradziono dane tysięcy pracowników – CD-Action
 - [https://cdaction.pl/newsy/kolejny-cyberatak-na-sony-wykradziono-dane-tysiecy-pracownikow](https://cdaction.pl/newsy/kolejny-cyberatak-na-sony-wykradziono-dane-tysiecy-pracownikow)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T08:47:32.243043+00:00

Kolejny cyberatak na Sony. Wykradziono dane tysięcy pracowników – CD-Action

## CD Projekt: Adam Kiciński zamierza zrezygnować z funkcji CEO – CD-Action
 - [https://cdaction.pl/newsy/cd-projekt-adam-kicinski-zamierza-zrezygnowac-z-funkcji-ceo](https://cdaction.pl/newsy/cd-projekt-adam-kicinski-zamierza-zrezygnowac-z-funkcji-ceo)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T07:47:25.855918+00:00

CD Projekt: Adam Kiciński zamierza zrezygnować z funkcji CEO – CD-Action

## Telltale Games: Kolejne studio zwalnia pracowników – CD-Action
 - [https://cdaction.pl/newsy/telltale-games-kolejne-studio-zwalnia-pracownikow](https://cdaction.pl/newsy/telltale-games-kolejne-studio-zwalnia-pracownikow)
 - RSS feed: https://cdaction.pl/newsy
 - date published: 2023-10-06T06:47:25.524616+00:00

Telltale Games: Kolejne studio zwalnia pracowników – CD-Action

