# Source:Sekurak, URL:https://sekurak.pl/rss, language:pl-PL

## Mega Sekurak Hacking Party – 19.10.2023 – teraz można zapisać się również online :-) Super prezentacje, extra atmosfera, nagrania i brak uporczywego marketingu :)
 - [https://sekurak.pl/mega-sekurak-hacking-party-19-10-2023-teraz-mozna-zapisac-sie-rowniez-online-super-prezentacje-extra-atmosfera-nagrania-i-brak-uporczywego-marketingu/](https://sekurak.pl/mega-sekurak-hacking-party-19-10-2023-teraz-mozna-zapisac-sie-rowniez-online-super-prezentacje-extra-atmosfera-nagrania-i-brak-uporczywego-marketingu/)
 - RSS feed: https://sekurak.pl/rss
 - date published: 2023-10-06T08:52:46+00:00

<p>W tym roku nasze całodniowe wydarzenie (można cały czas się zapisywać) odbędzie się w krakowskim centrum kongresowym ICE (19.10.2023). Od dzisiaj można również wykupić dostęp on-line do całości (w tym dostęp do nagrań): Ważne: osoby, które wykupiły dostęp on-site (cały czas zapraszamy!) otrzymają dostęp on-line gratis. W ramach &#8222;biletu uczestnictwo...</p>
<p>Artykuł <a href="https://sekurak.pl/mega-sekurak-hacking-party-19-10-2023-teraz-mozna-zapisac-sie-rowniez-online-super-prezentacje-extra-atmosfera-nagrania-i-brak-uporczywego-marketingu/" rel="nofollow">Mega Sekurak Hacking Party &#8211; 19.10.2023 &#8211; teraz można zapisać się również online :-) Super prezentacje, extra atmosfera, nagrania i brak uporczywego marketingu :)</a> pochodzi z serwisu <a href="https://sekurak.pl" rel="nofollow">Sekurak</a>.</p>

