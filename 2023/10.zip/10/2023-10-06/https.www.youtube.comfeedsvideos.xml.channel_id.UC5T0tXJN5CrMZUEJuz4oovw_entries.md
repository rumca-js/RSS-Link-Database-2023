# Source:Nerdrotic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw, language:en-US

## Ahsoka Finally Ends, Loki's Girl Bosses Begin | Friday Night Tights #270 w/ Disparu
 - [https://www.youtube.com/watch?v=rOewxP50-eo](https://www.youtube.com/watch?v=rOewxP50-eo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-10-06T18:01:48+00:00

Welcome to Friday Night Tights: a @nerdrotic and @GeeksandGamers  production

With special guest: @disparutoo 


1/4 Black and Dave Landau's NEW SHOW Normal World 
Subscribe! @NormalWorld 


Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Streamlab Donations LINK: https://streamlabs.com/sutrowatchtower/tip

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Join https://www.geeksandgamers.com/

SPONSORS

Sponsored by Meta PCs. 
For a discount, click here: https://Metapcs.com/Nerdrotic/ref

Sponsored by Geek Grind Coffee. 
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/nerdrotic-all-hail-blend-private-blend

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/bm15oz-15-oz-black-mug-2?_pos=2&_sid=b6f535164&_ss=r

The Lads: 
Gary from @nerdrotic @NerdroticDaily @NerdroticLive 
Jeremy from @DDayCobra @

## Ahsoka Is a Massive FAILURE | The Force Is Female Incompetence
 - [https://www.youtube.com/watch?v=vymO7j8d3mo](https://www.youtube.com/watch?v=vymO7j8d3mo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC5T0tXJN5CrMZUEJuz4oovw
 - date published: 2023-10-06T16:33:38+00:00

Ahsoka is EVERYTHING wrong with Disney Star Wars. A show about boring women in space getting lost. 
#Disney #StarWars #Ahsoka

Become a Nerdrotic Channel Member
www.youtube.com/c/sutrowatchtower/join

Subscribe to The Nerdrotic Network: @nerdrotic @NerdroticLive @NerdroticDaily  

Edited by @QTRBlackGarrett 

Nerdrotic Merch Store!
https://mixedtees.com/nerdrotic

FNT T-Shirt!
https://mixedtees.com/nerdrotic/friday-night-tights

Sponsored by MetaPCs!
Click here to get a discount on a PC: http://Metapcs.com/Nerdrotic/ref

Sponsored by GEEK GRIND!
Nerdrotic Blend Coffee from Geek Grind
Use Promo Code "Nerdrotic" for 20% off:
https://geekgrindcoffee.com/products/...

Nerdrotic Coffee Cup from Geek Grind:
https://geekgrindcoffee.com/products/...

