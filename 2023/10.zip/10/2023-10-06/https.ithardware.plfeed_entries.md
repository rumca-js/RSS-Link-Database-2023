# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Nintendo Switch 2- znamy potencjalne i datę premiery. Konsola ma być dostępna w dwóch wersjach
 - [https://ithardware.pl/aktualnosci/nintendo_switch_2_znamy_potencjalne_i_date_premiery_konsola_ma_byc_dostepna_w_dwoch_wersjach-29643.html](https://ithardware.pl/aktualnosci/nintendo_switch_2_znamy_potencjalne_i_date_premiery_konsola_ma_byc_dostepna_w_dwoch_wersjach-29643.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T21:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/29643_1.jpg" />            O następcy Nintendo Switch krążą r&oacute;żne pogłoski łącznie z tą, że zadebiutuje w 2024 roku. Teraz też poznaliśmy prawdopodobną cenę konsoli będącą na poziomie ceny poprzedniego modelu.

Nintendo Switch 2 w dw&oacute;ch wersjach....
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nintendo_switch_2_znamy_potencjalne_i_date_premiery_konsola_ma_byc_dostepna_w_dwoch_wersjach-29643.html">https://ithardware.pl/aktualnosci/nintendo_switch_2_znamy_potencjalne_i_date_premiery_konsola_ma_byc_dostepna_w_dwoch_wersjach-29643.html</a></p>

## Telltale Games zwolniło deweloperów. Co dalej z The Wolf Among Us 2?
 - [https://ithardware.pl/aktualnosci/telltale_games_zwolnilo_deweloperow_co_dalej_z_the_wolf_among_us_2-29642.html](https://ithardware.pl/aktualnosci/telltale_games_zwolnilo_deweloperow_co_dalej_z_the_wolf_among_us_2-29642.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T20:01:56+00:00

<img src="https://ithardware.pl/artykuly/min/29642_1.jpg" />            Branża gier mierzy się z kryzysem. Wyrzucani są kolejni deweloperzy, a tylko ostatnio pisaliśmy o zwolnieniach w Naughty Dog i zamrożeniu projektu multiplayera The Last of Us. Teraz przyszła kolej na Telltale Games.

Telltale Games to kolejna...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/telltale_games_zwolnilo_deweloperow_co_dalej_z_the_wolf_among_us_2-29642.html">https://ithardware.pl/aktualnosci/telltale_games_zwolnilo_deweloperow_co_dalej_z_the_wolf_among_us_2-29642.html</a></p>

## Cyberpunk 2077: Ultimate Edition dostrzeżony na stronie PEGI
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_ultimate_edition_dostrzezony_na_stronie_pegi-29641.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_ultimate_edition_dostrzezony_na_stronie_pegi-29641.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T16:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/29641_1.jpg" />            CD Projekt RED aktualizacją 2.0 zakończył rozw&oacute;j Cyberpunka 2077 i skupia się&nbsp;na innych projektach w tym kontynuacji futurystycznej strzelanki. Oczywiście nie znaczy to, że gra zostanie pozbawiona wsparcia, bo zapewne jakieś mniejsze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_ultimate_edition_dostrzezony_na_stronie_pegi-29641.html">https://ithardware.pl/aktualnosci/cyberpunk_2077_ultimate_edition_dostrzezony_na_stronie_pegi-29641.html</a></p>

## Podsumowanie newsów ITHardware - tydzień 125. Sprawdź co Cię ominęło
 - [https://ithardware.pl/aktualnosci/podsumowanie_newsow_ithardware_tydzien_sto_dwudziesty_piaty_pazdziernik_2023_sprawdz_co_cie_ominelo-29640.html](https://ithardware.pl/aktualnosci/podsumowanie_newsow_ithardware_tydzien_sto_dwudziesty_piaty_pazdziernik_2023_sprawdz_co_cie_ominelo-29640.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T15:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/29640_1.jpg" />            Jak co tydzień zapraszamy naszych czytelnik&oacute;w do odwiedzenia kanału&nbsp;ITHardware&nbsp;na YouTube i do zapoznania się z materiałem prezentującym najważniejsze wydarzenia minionych 7 dni.

Za powstanie wideo odpowiada&nbsp;nasz redakcyjny...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/podsumowanie_newsow_ithardware_tydzien_sto_dwudziesty_piaty_pazdziernik_2023_sprawdz_co_cie_ominelo-29640.html">https://ithardware.pl/aktualnosci/podsumowanie_newsow_ithardware_tydzien_sto_dwudziesty_piaty_pazdziernik_2023_sprawdz_co_cie_ominelo-29640.html</a></p>

## MSI Immerse GH50 Wireless. Bezprzewodowa Immersja dla wymagających graczy
 - [https://ithardware.pl/artykuly/msi_immerse_gh50_wireless_bezprzewodowa_immersja_dla_wymagajacych_graczy-29616.html](https://ithardware.pl/artykuly/msi_immerse_gh50_wireless_bezprzewodowa_immersja_dla_wymagajacych_graczy-29616.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T14:30:10+00:00

<img src="https://ithardware.pl/artykuly/min/29616_1.jpg" />            W świecie gier komputerowych odpowiednie narzędzia potrafią zdecydowanie podnieść komfort rozgrywki. I nie chodzi już tu wyłącznie o wyposażenie komputera w postaci wydajnego procesora czy karty graficznej, ale r&oacute;wnież o peryferia i...
            <p>Pełna wersja strony <a href="https://ithardware.pl/artykuly/msi_immerse_gh50_wireless_bezprzewodowa_immersja_dla_wymagajacych_graczy-29616.html">https://ithardware.pl/artykuly/msi_immerse_gh50_wireless_bezprzewodowa_immersja_dla_wymagajacych_graczy-29616.html</a></p>

## Kingston. Zewnętrzne dyski SSD dla profesjonalistów branży kreatywnej
 - [https://ithardware.pl/aktualnosci/kingston_zewnetrzne_dyski_ssd_dla_profesjonalistow_branzy_kreatywnej-29638.html](https://ithardware.pl/aktualnosci/kingston_zewnetrzne_dyski_ssd_dla_profesjonalistow_branzy_kreatywnej-29638.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T13:02:50+00:00

<img src="https://ithardware.pl/artykuly/min/29638_1.jpg" />            Kingston prezentuje dyski SSD przygotowane z myślą o profesjonalistach z branży kreatywnej. Są to modele o dużej pojemności umieszczone w kompaktowej obudowie. Jednym z nich jest&nbsp;Kingston SSD XS1000.

Tw&oacute;rcy z r&oacute;żnych dziedzin...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kingston_zewnetrzne_dyski_ssd_dla_profesjonalistow_branzy_kreatywnej-29638.html">https://ithardware.pl/aktualnosci/kingston_zewnetrzne_dyski_ssd_dla_profesjonalistow_branzy_kreatywnej-29638.html</a></p>

## Seria Samsung Galaxy S24 będzie miała tytanową ramkę we wszystkich modelach
 - [https://ithardware.pl/aktualnosci/seria_samsung_galaxy_s24_bedzie_miala_tytanowa_ramke_we_wszystkich_modelach-29639.html](https://ithardware.pl/aktualnosci/seria_samsung_galaxy_s24_bedzie_miala_tytanowa_ramke_we_wszystkich_modelach-29639.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T12:09:20+00:00

<img src="https://ithardware.pl/artykuly/min/29639_1.jpg" />            Seria telefon&oacute;w Samsung Galaxy S24, w skład kt&oacute;rej wchodzą zapewne modele Galaxy S24, Galaxy S24+, oraz Galaxy S24 Ultra,&nbsp;zostanie prawdopodobnie wyprodukowana z nowego materiału, zamiast tradycyjnego aluminium.

Apple niedawno...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/seria_samsung_galaxy_s24_bedzie_miala_tytanowa_ramke_we_wszystkich_modelach-29639.html">https://ithardware.pl/aktualnosci/seria_samsung_galaxy_s24_bedzie_miala_tytanowa_ramke_we_wszystkich_modelach-29639.html</a></p>

## Exynos 2400 już oficjalnie. Samsung wraca do gry
 - [https://ithardware.pl/aktualnosci/exynos_2400_juz_oficjalnie_samsung_wraca_do_gry-29635.html](https://ithardware.pl/aktualnosci/exynos_2400_juz_oficjalnie_samsung_wraca_do_gry-29635.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T11:32:01+00:00

<img src="https://ithardware.pl/artykuly/min/29635_1.jpg" />            Samsung w tym roku odpuścił wypuszczanie swojego nowego flagowego chipsetu i wiele os&oacute;b zastanawiało się czy w og&oacute;le powr&oacute;ci do high-endowych Exynos&oacute;w, ale koreański gigant właśnie oficjalnie zapowiedział sw&oacute;j...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/exynos_2400_juz_oficjalnie_samsung_wraca_do_gry-29635.html">https://ithardware.pl/aktualnosci/exynos_2400_juz_oficjalnie_samsung_wraca_do_gry-29635.html</a></p>

## Premierowa poprawka do Assassin's Creed Mirage po cichu dodała... Denuvo
 - [https://ithardware.pl/aktualnosci/gracze_sa_wsciekli_na_ubisoft_poprawka_do_assassin_s_creed_mirage_po_cichu_dodala_denuvo-29637.html](https://ithardware.pl/aktualnosci/gracze_sa_wsciekli_na_ubisoft_poprawka_do_assassin_s_creed_mirage_po_cichu_dodala_denuvo-29637.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T10:45:50+00:00

<img src="https://ithardware.pl/artykuly/min/29637_1.jpg" />            Ubisoft udostępnił aktualizację Assassin's Creed Mirage, jednakże nie wszyscy gracze są zachwyceni zawartością poprawki. Okazuje&nbsp;się, że patch zawiera kontrowersyjny system antypiracki&nbsp;Denuvo DRM.

Wielu graczy jest przeciwnych...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/gracze_sa_wsciekli_na_ubisoft_poprawka_do_assassin_s_creed_mirage_po_cichu_dodala_denuvo-29637.html">https://ithardware.pl/aktualnosci/gracze_sa_wsciekli_na_ubisoft_poprawka_do_assassin_s_creed_mirage_po_cichu_dodala_denuvo-29637.html</a></p>

## Kultowy Commandos powróci na PC w przyszłym roku
 - [https://ithardware.pl/aktualnosci/kultowy_commandos_powroci_na_pc_w_przyszlym_roku-29634.html](https://ithardware.pl/aktualnosci/kultowy_commandos_powroci_na_pc_w_przyszlym_roku-29634.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T10:15:01+00:00

<img src="https://ithardware.pl/artykuly/min/29634_1.jpg" />            Na początku 2020 roku doczekaliśmy się odświeżonej edycji gry Commandos 2, ale już w przyszłym roku otrzymać mamy zupełnie nową odsłonę tej kultowej serii taktycznych skradanek osadzonej w czasie II wojny światowej.&nbsp;

Commandosi...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kultowy_commandos_powroci_na_pc_w_przyszlym_roku-29634.html">https://ithardware.pl/aktualnosci/kultowy_commandos_powroci_na_pc_w_przyszlym_roku-29634.html</a></p>

## Procesor Intel Lunar Lake pojawił się w bazie danych SiSoftware
 - [https://ithardware.pl/aktualnosci/procesor_intel_lunar_lake_pojawil_sie_w_bazie_danych_sisoftware-29633.html](https://ithardware.pl/aktualnosci/procesor_intel_lunar_lake_pojawil_sie_w_bazie_danych_sisoftware-29633.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T09:40:01+00:00

<img src="https://ithardware.pl/artykuly/min/29633_1.jpg" />            Zdaje się, że Intel rozpoczął już testowanie swojej kolejnej generacji konsumenckich procesor&oacute;w PC, znanych pod nazwą kodową Lunar Lake.&nbsp;

Warto na wstępie wyjaśnić, że gigant z Santa Clara wyraźnie sugerował, że ​​Lunar...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/procesor_intel_lunar_lake_pojawil_sie_w_bazie_danych_sisoftware-29633.html">https://ithardware.pl/aktualnosci/procesor_intel_lunar_lake_pojawil_sie_w_bazie_danych_sisoftware-29633.html</a></p>

## Windows 12 - nowe przecieki wskazują, że system może bazować na subskrypcji
 - [https://ithardware.pl/aktualnosci/windows_12_nowe_przecieki_wskazuja_ze_system_moze_bazowac_na_subskrypcji-29632.html](https://ithardware.pl/aktualnosci/windows_12_nowe_przecieki_wskazuja_ze_system_moze_bazowac_na_subskrypcji-29632.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T08:24:01+00:00

<img src="https://ithardware.pl/artykuly/min/29632_1.jpg" />            Chociaż w kuluarach coraz więcej się o tym m&oacute;wiło, to nowy przeciek zdaje się potwierdzać, że Microsoft może rozważać uczynienie Windowsa 12 systemem operacyjnym opartym na subskrypcji.&nbsp;

Niemiecki serwis Deskmodder zauważył...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/windows_12_nowe_przecieki_wskazuja_ze_system_moze_bazowac_na_subskrypcji-29632.html">https://ithardware.pl/aktualnosci/windows_12_nowe_przecieki_wskazuja_ze_system_moze_bazowac_na_subskrypcji-29632.html</a></p>

## Pandora Gate: Hakerzy Anonymous biorą się za polskich YouTuberów. O sprawie pisze nawet Elon Musk
 - [https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow_o_sprawie_pisze_nawet_elon_musk-29636.html](https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow_o_sprawie_pisze_nawet_elon_musk-29636.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T08:16:20+00:00

<img src="https://ithardware.pl/artykuly/min/29636_1.jpg" />            Sprawa z #PandoraGate stała się na tyle głośna, że tematem zainteresowała się grupa znanych hacker&oacute;w, a nawet Elon Musk.

Afera pedofilska, w kręgu popularnych na naszej scenie YouTuber&oacute;w, zatacza coraz szersze kręgi. W sprawę...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow_o_sprawie_pisze_nawet_elon_musk-29636.html">https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow_o_sprawie_pisze_nawet_elon_musk-29636.html</a></p>

## Pandora Gate: Hakerzy z Anonymous biorą się za polskich YouTuberów
 - [https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow-29636.html](https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow-29636.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T08:16:20+00:00

<img src="https://ithardware.pl/artykuly/min/29636_1.jpg" />            Sprawa z #PandoraGate stała się na tyle głośna, że tematem zainteresowała się grupa znanych hacker&oacute;w.

Grupa&nbsp;Anounymous&nbsp;w przeszłości wielokrotnie włączała się w akcje wymierzone w pedofil&oacute;w.

Afera pedofilska, w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow-29636.html">https://ithardware.pl/aktualnosci/hakerzy_z_anonymous_biora_sie_za_polskich_youtuberow-29636.html</a></p>

## Kupiłeś Forza Motorsport i czekasz na premierę, a piraci już grają i się z ciebie śmieją
 - [https://ithardware.pl/aktualnosci/kupiles_forza_motorsport_i_czekasz_na_premiere_a_piraci_juz_graja_i_sie_z_ciebie_smieja-29631.html](https://ithardware.pl/aktualnosci/kupiles_forza_motorsport_i_czekasz_na_premiere_a_piraci_juz_graja_i_sie_z_ciebie_smieja-29631.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T08:04:01+00:00

<img src="https://ithardware.pl/artykuly/min/29631_1.jpg" />            Kilka dni temu Microsoft wypuścił Forza Motorsport we wczesnym dostępie. I chociaż gra zostanie oficjalnie w wydana 10 października, to piraci mogą już grać w ten tytuł, przed osobami, kt&oacute;re czekają na legalną premierę.&nbsp;

Nowa...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kupiles_forza_motorsport_i_czekasz_na_premiere_a_piraci_juz_graja_i_sie_z_ciebie_smieja-29631.html">https://ithardware.pl/aktualnosci/kupiles_forza_motorsport_i_czekasz_na_premiere_a_piraci_juz_graja_i_sie_z_ciebie_smieja-29631.html</a></p>

## Subskrybenci PS Plus Premium otrzymali dostęp do przeszło 100 filmów Sony bez dodatkowych kosztów
 - [https://ithardware.pl/aktualnosci/subskrybenci_ps_plus_premium_otrzymali_dostep_do_przeszlo_100_filmow_sony_bez_dodatkowych_kosztow-29630.html](https://ithardware.pl/aktualnosci/subskrybenci_ps_plus_premium_otrzymali_dostep_do_przeszlo_100_filmow_sony_bez_dodatkowych_kosztow-29630.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T07:30:30+00:00

<img src="https://ithardware.pl/artykuly/min/29630_1.jpg" />            Sony zmienia nazwę swojej usługi VOD, Bravia Core i po raz pierwszy wprowadza ją na konsole PlayStation 4 i PlayStation 5. Bravia Core (skr&oacute;t od Center of Real Entertainment) zadebiutowało w kwietniu 2021 roku, umożliwiając właścicielom...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/subskrybenci_ps_plus_premium_otrzymali_dostep_do_przeszlo_100_filmow_sony_bez_dodatkowych_kosztow-29630.html">https://ithardware.pl/aktualnosci/subskrybenci_ps_plus_premium_otrzymali_dostep_do_przeszlo_100_filmow_sony_bez_dodatkowych_kosztow-29630.html</a></p>

## Cyberpunk 2077 sprzedaje się dużo lepiej niż Wiedźmin 3. Nadchodzi aktorski film/serial
 - [https://ithardware.pl/aktualnosci/cyberpunk_2077_sprzedaje_sie_duzo_lepiej_niz_wiedzmin_3_nadchodzi_aktorski_film_serial-29629.html](https://ithardware.pl/aktualnosci/cyberpunk_2077_sprzedaje_sie_duzo_lepiej_niz_wiedzmin_3_nadchodzi_aktorski_film_serial-29629.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-10-06T06:18:04+00:00

<img src="https://ithardware.pl/artykuly/min/29629_1.jpg" />            CD Projekt Red podczas spotkania z inwestorami podzielił się informacjami i planami odnośnie Cyberpunka 2077. Co ciekawe, gra, pomimo bardzo trudnego początku, sprzedaje się znacznie szybciej niż Wiedźmin 3, a możemy też liczyć na projekt live...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/cyberpunk_2077_sprzedaje_sie_duzo_lepiej_niz_wiedzmin_3_nadchodzi_aktorski_film_serial-29629.html">https://ithardware.pl/aktualnosci/cyberpunk_2077_sprzedaje_sie_duzo_lepiej_niz_wiedzmin_3_nadchodzi_aktorski_film_serial-29629.html</a></p>

