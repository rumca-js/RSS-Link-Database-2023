# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Meksyk. Wypadek autobusu z migrantami. Nie żyje 16 osób
 - [https://wydarzenia.interia.pl/zagranica/news-meksyk-wypadek-autobusu-z-migrantami-nie-zyje-16-osob,nId,7071917](https://wydarzenia.interia.pl/zagranica/news-meksyk-wypadek-autobusu-z-migrantami-nie-zyje-16-osob,nId,7071917)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-10-06T22:03:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-meksyk-wypadek-autobusu-z-migrantami-nie-zyje-16-osob,nId,7071917"><img align="left" alt="Meksyk. Wypadek autobusu z migrantami. Nie żyje 16 osób" src="https://i.iplsc.com/meksyk-wypadek-autobusu-z-migrantami-nie-zyje-16-osob/000HRG1V8OQO6VUN-C321.jpg" /></a>Na południu Meksyku doszło do wypadku autobusowego. Zginęło co najmniej 16 wenezuelskich i haitańskich migrantów - poinformowały władze stanowe. Pojazd miał przewrócić się na ostrym łuku drogi. Pasażerowie zmierzali na północ Meksyku, a ich celem była granica z USA. </p><br clear="all" />

