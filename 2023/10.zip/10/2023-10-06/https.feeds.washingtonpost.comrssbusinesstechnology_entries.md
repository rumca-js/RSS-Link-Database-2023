# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Amazon launches first internet satellites in bid to compete with Starlink
 - [https://www.washingtonpost.com/technology/2023/10/06/amazon-launch-kuiper-internet-satellite-starlink/](https://www.washingtonpost.com/technology/2023/10/06/amazon-launch-kuiper-internet-satellite-starlink/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-06T18:30:03+00:00

The Kuiper constellation is planned as a rival to Elon Musk’s Starlink but is years behind the 5,000 satellites Starlink already has in orbit.

## Apple’s stealth power is changing how you buy books, too
 - [https://www.washingtonpost.com/technology/2023/10/06/spotify-audiobooks-cant-buy-app/](https://www.washingtonpost.com/technology/2023/10/06/spotify-audiobooks-cant-buy-app/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-06T16:30:00+00:00

Apple has been instrumental in higher prices for e-books and in slowing Spotify’s challenge to Amazon’s dominance of audiobooks.

## The final 11 seconds of a fatal Tesla Autopilot crash
 - [https://www.washingtonpost.com/technology/interactive/2023/tesla-autopilot-crash-analysis/](https://www.washingtonpost.com/technology/interactive/2023/tesla-autopilot-crash-analysis/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-10-06T10:00:04+00:00

A lawsuit over the crash could determine whether the maker of the technology bears some responsibility when things go wrong in a vehicle guided by Autopilot.

