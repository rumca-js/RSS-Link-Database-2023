# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## Professor Dalgleish
 - [https://www.youtube.com/watch?v=PnJ5T1Enwq4](https://www.youtube.com/watch?v=PnJ5T1Enwq4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-10-06T20:00:45+00:00

Well worth the time to listen

