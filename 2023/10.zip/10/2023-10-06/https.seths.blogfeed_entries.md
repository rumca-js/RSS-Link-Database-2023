# Source:Seth's Blog, URL:https://seths.blog/feed, language:en-US

## Getting better at bucket management
 - [https://seths.blog/2023/10/how-big-is-the-vessel/](https://seths.blog/2023/10/how-big-is-the-vessel/)
 - RSS feed: https://seths.blog/feed
 - date published: 2023-10-06T08:10:00+00:00

If you throw a bucket of water on a small campfire, you&#8217;ll succeed in putting it out. Pour a bucketful of sake into one of those little glasses and you&#8217;ll waste most of it and ruin the table setting. And try to use a bucket to refill a dried-out lake and not much will happen. [&#8230;]

