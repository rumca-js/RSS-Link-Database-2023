# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Don’t travel to Scotland because of heavy rain, train company warns
 - [https://www.telegraph.co.uk/news/2023/10/07/weather-scotland-rain-travel-trains-latest-manchester-uk/](https://www.telegraph.co.uk/news/2023/10/07/weather-scotland-rain-travel-trains-latest-manchester-uk/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T23:06:33+00:00



## Top Gear will not return after Flintoff crash – report
 - [https://www.telegraph.co.uk/news/2023/10/06/top-gear-new-series-andrew-freddie-flintoff-crash-bbc/](https://www.telegraph.co.uk/news/2023/10/06/top-gear-new-series-andrew-freddie-flintoff-crash-bbc/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T22:54:28+00:00



## Rapists wrongly labelled as ‘women’ by police
 - [https://www.telegraph.co.uk/news/2023/10/06/rapists-wrongly-labelled-as-women-by-police/](https://www.telegraph.co.uk/news/2023/10/06/rapists-wrongly-labelled-as-women-by-police/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T20:00:00+00:00



## Friday evening news briefing: By-election win ‘big step’ towards becoming PM, says Starmer
 - [https://www.telegraph.co.uk/news/2023/10/06/friday-evening-news-briefing-starmer-by-election-win/](https://www.telegraph.co.uk/news/2023/10/06/friday-evening-news-briefing-starmer-by-election-win/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T16:31:29+00:00



## Pictured: Sinkhole swallows bin lorry on Welsh promenade
 - [https://www.telegraph.co.uk/news/2023/10/06/bin-lorry-falls-down-sinkhole-promenade-wales-rhyl/](https://www.telegraph.co.uk/news/2023/10/06/bin-lorry-falls-down-sinkhole-promenade-wales-rhyl/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T12:15:39+00:00



## Mercy killings may not always be prosecuted, new guidance suggests
 - [https://www.telegraph.co.uk/news/2023/10/06/mercy-killings-may-not-always-be-prosecuted-new-guidance/](https://www.telegraph.co.uk/news/2023/10/06/mercy-killings-may-not-always-be-prosecuted-new-guidance/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-10-06T05:00:00+00:00



