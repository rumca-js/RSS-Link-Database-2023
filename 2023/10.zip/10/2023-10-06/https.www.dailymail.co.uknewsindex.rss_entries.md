# Source:Daily Mail, URL:https://www.dailymail.co.uk/news/index.rss, language:en-US

## Fury as the BBC's Jimmy Savile drama buries its Newsnight probe - as the broadcaster denies long-awaited series The Reckoning is a 'face-saving exercise'
 - [https://www.dailymail.co.uk/news/article-12603991/Fury-BBCs-Jimmy-Savile-drama-buries-Newsnight-probe-broadcaster-denies-long-awaited-series-Reckoning-face-saving-exercise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603991/Fury-BBCs-Jimmy-Savile-drama-buries-Newsnight-probe-broadcaster-denies-long-awaited-series-Reckoning-face-saving-exercise.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T23:02:47+00:00

BBC bosses have denied a long-awaited Jimmy Savile drama is a 'face-saving exercise', after it emerged the series does not dramatise the shelved Newsnight probe into the paedophile presenter.

## Only a quarter of Red Wall voters back Labour's pledge to reintroduce 2030 car ban - but the majority support Rishi Sunak's plan to delay the restriction on new petrol and diesel cars to 2035
 - [https://www.dailymail.co.uk/news/article-12604071/Only-quarter-Red-Wall-voters-Labours-pledge-reintroduce-2030-car-ban-majority-support-Rishi-Sunaks-plan-delay-restriction-new-petrol-diesel-cars-2035.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12604071/Only-quarter-Red-Wall-voters-Labours-pledge-reintroduce-2030-car-ban-majority-support-Rishi-Sunaks-plan-delay-restriction-new-petrol-diesel-cars-2035.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T23:01:11+00:00

Labour frontbenchers have said the party would recommit to the original date as part of moves to switch to electric cars, but just 27 per cent of Red Wall voters backed the decision, a poll reveals.

## DAILY MAIL COMMENT: Halt woke march of the male menopause
 - [https://www.dailymail.co.uk/news/article-12603975/DAILY-MAIL-COMMENT-woke-march-male-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603975/DAILY-MAIL-COMMENT-woke-march-male-menopause.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:54:46+00:00

DAILY MAIL COMMENT: The truth is, public bodies and company boardrooms have been captured by the 'woke' agenda, where identity politics is as important as their core purpose.

## Facebook's own account is 'hacked': Social media users left bemused by bizarre posts including one demanding to 'release' ex-Pakistani prime minister Imran Khan
 - [https://www.dailymail.co.uk/news/article-12604017/Facebook-account-hacked-Social-media-bizarre-posts-ex-Pakistani-prime-minister-Imran-Khan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12604017/Facebook-account-hacked-Social-media-bizarre-posts-ex-Pakistani-prime-minister-Imran-Khan.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:54:06+00:00

A flurry of unusual posts were put online from the social media giant's official Facebook account.

## The mystery of Billy Connolly's missing banjo and the dolphin skull that simply vanished
 - [https://www.dailymail.co.uk/news/article-12604005/The-mystery-Billy-Connollys-missing-banjo-dolphin-skull-simply-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12604005/The-mystery-Billy-Connollys-missing-banjo-dolphin-skull-simply-vanished.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:39:01+00:00

Last summer, the charity that manages museums across Scotland's largest city started deliberately giving away more than 50 priceless objects from its collections. These precious cultural arte

## 'Second home owners ARE welcome here': Businesses in holiday home hotspots erect signs outside shops and warn tourist money is vital for their survival as heated debate reaches boiling point
 - [https://www.dailymail.co.uk/news/article-12603773/Second-home-owners-welcome-Businesses-holiday-hotspots-shops-tourist-money-survival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603773/Second-home-owners-welcome-Businesses-holiday-hotspots-shops-tourist-money-survival.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:35:24+00:00

EXCLUSIVE: The debate over bans on second homes in popular coastal holiday destinations reached boiling point last night after businesses branded locals opposed to outsiders 'extremists'.

## So has TV star Toff found true love at last in a sleepy Scottish village? (With the BrewDog beer magnate said to be worth £260 million!)
 - [https://www.dailymail.co.uk/news/article-12603613/So-TV-star-Toff-true-love-sleepy-Scottish-village-BrewDog-beer-magnate-said-worth-260-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603613/So-TV-star-Toff-true-love-sleepy-Scottish-village-BrewDog-beer-magnate-said-worth-260-million.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:34:28+00:00

Had you been strolling along the narrow seafront a couple of weeks back at Crovie, a tiny village with just a handful of houses tucked away in rural Banffshire, you might well have thought

## We may look back on this result as the moment the tide turned on the SNP, writes EDDIE BARNES
 - [https://www.dailymail.co.uk/news/article-12603579/We-look-result-moment-tide-turned-SNP-writes-EDDIE-BARNES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603579/We-look-result-moment-tide-turned-SNP-writes-EDDIE-BARNES.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:33:54+00:00

A week on Thursday, Scotland was supposed to be having another independence referendum. Nicola Sturgeon told us so last year. October 19, 2023, she announced, would be the date fo

## EMMA COWING'S must read Saturday column: The phone zombies are missing out on a whole (real) world
 - [https://www.dailymail.co.uk/news/article-12603421/EMMA-COWINGS-read-Saturday-column-phone-zombies-missing-real-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603421/EMMA-COWINGS-read-Saturday-column-phone-zombies-missing-real-world.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:33:36+00:00

I've become quite good at spotting them. The lowered head. The shuffling gait. Usually, but not always, under 25. Hands stretched out unnaturally, thumbs poised at the ready.

## Abuser told student victims: I'm testing you for radiation from Chernobyl
 - [https://www.dailymail.co.uk/news/article-12603369/Abuser-told-student-victims-Im-testing-radiation-Chernobyl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603369/Abuser-told-student-victims-Im-testing-radiation-Chernobyl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:33:09+00:00

A former student carried out sexual assaults at a Scots university after claiming to be conducting radiation testing for the Ministry of Defence.
John Beaumont subjected victims to fake

## Northern beaches crash: Teenager critical and five others injured after driver lost control of a ute and crashed into a tree
 - [https://www.dailymail.co.uk/news/article-12604003/Northern-beaches-crash-teenager-critical-five-injured-driver-lost-control-ute-crashed-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12604003/Northern-beaches-crash-teenager-critical-five-injured-driver-lost-control-ute-crashed-tree.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:32:40+00:00

One teenager is in a critical condition and five others are injured after a ute left the road and smashed into a tree at Bayview on Sydney's northern beaches.

## Boy, 13, stabbed to death on MTA bus in Staten Island, suspect in custody
 - [https://www.dailymail.co.uk/news/article-12603833/Staten-island-nyc-bus-stabbing-death-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603833/Staten-island-nyc-bus-stabbing-death-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T22:31:15+00:00

A teenage boy was stabbed to death on a bus in Staten Island on Friday. The victim, 13, was transported to Staten Island University Hospital, where he died.

## BETH HALE: What turned Laurence Fox, once that lovely detective from Lewis, into a ranting misogynist whose life is in freefall?
 - [https://www.dailymail.co.uk/news/article-12603409/Laurence-Fox-Lewis-misogynist-life-freefall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603409/Laurence-Fox-Lewis-misogynist-life-freefall.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:59:02+00:00

The 45-year-old, who was sacked from GB News earlier this week, has undergone several incarnations since he landed his best-known role as DS James Hathaway in ITV drama Lewis

## Kevin McCarthy insists he's staying in Congress after historic ousting as Speaker: Republican shuts down reports he will resign - and hints he'll run for re-election next year
 - [https://www.dailymail.co.uk/news/article-12603597/Kevin-McCarthy-expected-RESIGN-Congress-Republicans-choose-successor-word-planned-departure-comes-days-stunning-ouster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603597/Kevin-McCarthy-expected-RESIGN-Congress-Republicans-choose-successor-word-planned-departure-comes-days-stunning-ouster.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:58:06+00:00

Kevin McCarthy insisted he will not resign from Congress despite being ousted from the speakership this week and said he will even run for re-election in 2024.

## The real victims of the HS2 fiasco: Devastated families whose homes were sold on the cheap and left to rot
 - [https://www.dailymail.co.uk/news/article-12603803/The-real-victims-HS2-fiasco-Devastated-families-homes-sold-cheap-left-rot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603803/The-real-victims-HS2-fiasco-Devastated-families-homes-sold-cheap-left-rot.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:57:35+00:00

Broom Manor is an elegant 19th-century mansion - or, at least, it used to be - near the upmarket town of Knutsford in the heart of the Cheshire countryside.

## Rwanda deal 'is the key to whether we leave European Convention on Human Rights', ministers claim, as the Supreme Court decides whether to block the government's asylum deal
 - [https://www.dailymail.co.uk/news/article-12603479/Rwanda-deal-key-leave-European-Convention-Human-Rights-ministers-claim-Supreme-Court-decides-block-governments-asylum-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603479/Rwanda-deal-key-leave-European-Convention-Human-Rights-ministers-claim-Supreme-Court-decides-block-governments-asylum-deal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:57:16+00:00

Up to a third of Rishi Sunak 's Cabinet already believe he will have to quit the convention if judges block the flagship policy. Allies of Suella Braverman said she is ready to press for the move.

## Amish men shunned following emergency alert test that outed them for having cell phones
 - [https://www.dailymail.co.uk/news/article-12603615/Amish-men-shunned-following-emergency-alert-test-outed-having-cell-phones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603615/Amish-men-shunned-following-emergency-alert-test-outed-having-cell-phones.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:54:04+00:00

Smartphones received an alert on Wednesday as part of a nationwide test for an emergency alert system. The alert also involved a powerful alarm sound that outed some Amish people's cellphones

## Nato, Britain's defences and the man who says Labour can keep us safe: JASON GROVES talks to Labour's shadow defence secretary John Healey
 - [https://www.dailymail.co.uk/news/article-12603925/John-Healey-shadow-defence-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603925/John-Healey-shadow-defence-secretary.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:46:08+00:00

Healey has one of the toughest jobs in politics - convincing Britain that after the chaos of the Jeremy Corbyn years, Labour can be trusted with the nation's defences again.

## Ex-Transport Secretary Chris Grayling to stand down as an MP at the next election after cancer diagnosis
 - [https://www.dailymail.co.uk/news/article-12603923/Chris-Grayling-stand-MP-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603923/Chris-Grayling-stand-MP-cancer-diagnosis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:40:02+00:00

The ex-minister is among more than 40 Conservatives who have announced they will not defend their seat in a vote expected next year.

## Trump says illegal migrants are 'poisoning the blood of our country' sparking accusations of 'toxic racism' as his campaign says it is a 'normal phrase used in everyday life'
 - [https://www.dailymail.co.uk/news/article-12603727/Trump-says-illegal-migrants-poisoning-blood-country-sparking-accusations-toxic-racism-campaign-says-normal-phrase-used-everyday-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603727/Trump-says-illegal-migrants-poisoning-blood-country-sparking-accusations-toxic-racism-campaign-says-normal-phrase-used-everyday-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:35:29+00:00

Trump in an interview with the National Pulse said immigration is 'poisoning the blood of our country,' in a phrase that drew a harsh rebuke from the ADL and former Trump friend Geraldo Rivera.

## Kanye West 'secretly fights to trademark the phrase YEWS which he plans to use for everything from music to restaurants and financial services'
 - [https://www.dailymail.co.uk/news/article-12603511/Kanye-West-trademark-phrase-YEWS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603511/Kanye-West-trademark-phrase-YEWS.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:35:12+00:00

Kanye West , who goes by Ye, is understood to be working to trademark the phrase 'YEWS' for use across a range of sectors including music, food, beauty and financial services.

## Drunk cemetery caretaker turns himself in to Dominican Republic police after the bodies of six newborns were found outside a gravesite saying he 'forgot about the corpses'
 - [https://www.dailymail.co.uk/news/article-12603525/drunk-cemetery-gravesite-Dominican-Republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603525/drunk-cemetery-gravesite-Dominican-Republic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:08:48+00:00

A cemetery caretake has turned himself in to authorities after the bodies of six newborns were found outside a Dominican Republic gravesite wrapped in hospital bed sheets.

## Earthquake rattles Lakes Entrance in eastern Victoria as residents say they woke to a 'loud rumble'
 - [https://www.dailymail.co.uk/news/article-12603793/Earthquake-rattles-Lakes-Entrance-eastern-Victoria-residents-say-woke-loud-rumble.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603793/Earthquake-rattles-Lakes-Entrance-eastern-Victoria-residents-say-woke-loud-rumble.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T21:08:24+00:00

A 3.0 magnitude earthquake has struck in east ern Victoria. The quake was recorded about 12.03am on Saturday in Lakes Entrance, a coastal town some 319km from Melbourne.

## New England braces for post-tropical cyclone Philippe with threat of heavy winds, rain and power outages - as New York City is put under ANOTHER flood warning
 - [https://www.dailymail.co.uk/news/article-12603509/new-england-braces-tropical-cyclone-philippe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603509/new-england-braces-tropical-cyclone-philippe.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T20:52:49+00:00

The Northeast looks to another wet weekend ahead as the remnants of Tropical Storm Philippe and an incoming cold front will soak New England and potentially flood New York... again.

## Suspect in murder of Philadelphia journalist Josh Kruger is identified as Robert Davis, 19
 - [https://www.dailymail.co.uk/news/article-12603535/josh-kruger-murder-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603535/josh-kruger-murder-suspect.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T20:49:29+00:00

Pennsylvania police have named the 'armed and dangerous' 19-year-old suspect in the shooting murder of Philadelphia journalist  and community advocate Josh Kruger.

## Biden picking Hunter's former colleague for special counsel's office raises 'concerns' he is doing more to protect his son, top Republican says
 - [https://www.dailymail.co.uk/news/article-12603405/Biden-picking-Hunters-former-colleague-special-counsels-office-raises-concerns-doing-protect-son-Republican-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603405/Biden-picking-Hunters-former-colleague-special-counsels-office-raises-concerns-doing-protect-son-Republican-says.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T20:42:56+00:00

A senior Republican accused President Joe Biden of trying to protect his son by nominating one of Hunter's former colleagues to lead the Office of Special Counsel.

## Colombian president's daughter calls on restaurant in France to remove painting of Pablo Escobar that is 'insulting and denigrating'
 - [https://www.dailymail.co.uk/news/article-12602963/Colombian-presidents-daughter-calls-restaurant-France-remove-painting-Pablo-Escobar-insulting-denigrating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602963/Colombian-presidents-daughter-calls-restaurant-France-remove-painting-Pablo-Escobar-insulting-denigrating.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T20:08:35+00:00

Andrea Petro has called out a restaurant in Marseilles, France and asked it to remove a mural of Pablo Escobar because it portrays Colombians negatively. The painting is located at Le Populo.

## Democrat Henry Cuellar's former staffer turned GOP opponent in Texas race seeks to have assault record wiped clean
 - [https://www.dailymail.co.uk/news/article-12603207/Democrat-Henry-Cuellars-former-staffer-turned-GOP-opponent-Texas-race-seeks-assault-record-wiped-clean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603207/Democrat-Henry-Cuellars-former-staffer-turned-GOP-opponent-Texas-race-seeks-assault-record-wiped-clean.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:46:25+00:00

The Republican seeking to oust pro-life Democrat Henry Cuellar is trying to wipe away a record on his violent past.

## Hannibal creator Bryan Fuller is sued for sexual assault by Queer for Fear series producer who claims he 'pressed his penis against his buttocks'
 - [https://www.dailymail.co.uk/news/article-12603355/Hannibal-creator-Bryan-Fuller-lawsuit-samuel-wineman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603355/Hannibal-creator-Bryan-Fuller-lawsuit-samuel-wineman.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:39:23+00:00

Hannibal creator Bryan Fuller has been accused of sexual assault by the producer of his series Queer for Fear.

## Halloween treat warning as 146,000 'rolling ball' candies are urgently recalled after 7-year-old girl choked to death
 - [https://www.dailymail.co.uk/news/article-12603027/Halloween-rolling-candies-recalled-girl-choked-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603027/Halloween-rolling-candies-recalled-girl-choked-death.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:19:38+00:00

The U.S. Consumer Product Safety Commission announced to recall millions of rolling ball candies due to the risk of fatal choking.

## Ryan Thoresen Carson's 'grifter' friends are branded 'abhorrent' for setting up $70k GoFundMe to take time off work after his brutal murder
 - [https://www.dailymail.co.uk/news/article-12603273/Ryan-Thoresen-Carsons-grifter-friends-branded-abhorrent-setting-70k-GoFundMe-time-work-brutal-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603273/Ryan-Thoresen-Carsons-grifter-friends-branded-abhorrent-setting-70k-GoFundMe-time-work-brutal-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:14:33+00:00

The fundraising effort, established initially with his girlfriend named as the beneficiary, is on behalf of a 'collective' of Carson's friends.

## Bigger than Barbie? How Taylor Swift angered Hollywood's elite as she cut out the middleman and went direct to AMC to distribute The Eras Tour movie - raking in $100M in presales
 - [https://www.dailymail.co.uk/news/article-12602625/taylor-swift-eras-tour-movie-hollywood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602625/taylor-swift-eras-tour-movie-hollywood.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:06:24+00:00

Taylor Swift has already conquered the music industry - now she's reshaping Hollywood.

## Retired bank clerk, 60, was killed while out for a Sunday stroll in city centre after cocaine-fuelled mother-of-four, 33, lost control of her hire car at 68mph when her partner yanked on the handbrake as they argued over their relationship
 - [https://www.dailymail.co.uk/news/article-12603249/Retiree-killed-Liverpool-cocaine-fuelled-mother-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603249/Retiree-killed-Liverpool-cocaine-fuelled-mother-car.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T19:03:08+00:00

Jennifer Blackwood (pictured) was driving a Vauxhall Crossland at 68mph - more than double the speed limit - along Brownlow Hill in Liverpool City Centre in January last year.

## 'I was bombed out of Rangers because Cathy was a Catholic': How Alex Ferguson felt he was shown the door at Ibrox because of his wife's religion and regretted not standing up to bosses when they quizzed him on it
 - [https://www.dailymail.co.uk/news/article-12603011/Sir-Alex-Ferguson-bombed-Rangers-Lady-Cathy-Catholic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603011/Sir-Alex-Ferguson-bombed-Rangers-Lady-Cathy-Catholic.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:46:14+00:00

Sir Alex Ferguson's wife Lady Cathy Ferguson, who was described as his 'tower of strength', died on Thursday aged 84, it was announced today.

## 'Oh, the wall thing': Biden dismisses fury and insists he was 'told he had no choice' but to start constructions as Democrats accuse him of 'flip-flopping' and being 'cruel'
 - [https://www.dailymail.co.uk/news/article-12603217/Oh-wall-thing-Biden-dismisses-fury-insists-told-no-choice-start-constructions-Democrats-accuse-flip-flopping-cruel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603217/Oh-wall-thing-Biden-dismisses-fury-insists-told-no-choice-start-constructions-Democrats-accuse-flip-flopping-cruel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:45:13+00:00

President Joe Biden on Friday dismissed criticism of his decision to start rebuilding Donald Trump's border wall, shruggin off anger by repeating his argument that he had no choice.

## Hillary calls from Trump supporters to be 'DE-PROGRAMMED': Clinton calls MAGA a 'cult' in another attack on the 'deplorables'
 - [https://www.dailymail.co.uk/news/article-12603085/Hillary-Clinton-attacks-deplorables-Democrat-says-Trump-supporters-need-deprogrammed-calls-MAGA-army-bigots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603085/Hillary-Clinton-attacks-deplorables-Democrat-says-Trump-supporters-need-deprogrammed-calls-MAGA-army-bigots.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:43:35+00:00

Hillary Clinton sat for a CNN interview where she said there were 'sane' House Republicans, but compared some 'MAGA extremists' to 'cult' members.

## Elon Musk had secretly taken legal action against ex Grimes over parental rights of their three kids a MONTH before she decided to sue
 - [https://www.dailymail.co.uk/news/article-12603289/Elon-Musk-secretly-taken-legal-action-against-ex-Grimes-parental-rights-three-kids-MONTH-decided-sue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603289/Elon-Musk-secretly-taken-legal-action-against-ex-Grimes-parental-rights-three-kids-MONTH-decided-sue.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:36:46+00:00

Elon Musk had secretly taken legal action for the parental rights of his three children with his Musician ex Grimes a month prior to her suing the billionaire.

## Biden rambles about TV news being dominated by dogs being 'pushed' in lakes as he blames 'unhappy' reporters for Americans thinking the economy is dire
 - [https://www.dailymail.co.uk/news/article-12603163/Biden-rambles-TV-news-dominated-dogs-pushed-lakes-blames-unhappy-reporters-Americans-thinking-economy-dire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603163/Biden-rambles-TV-news-dominated-dogs-pushed-lakes-blames-unhappy-reporters-Americans-thinking-economy-dire.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:28:50+00:00

Joe Biden blamed the press when asked Friday why Americans think the economy is dire, telling a group of White House reporters 'you all are not the happiest people in the world.'

## Toxic stupidity of the bleeding-heart border fools: The Left screamed it was racist to keep America secure... now, says DAVID MARCUS, they're pleading with migrants to keep out - and Biden's building the wall!
 - [https://www.dailymail.co.uk/news/article-12598525/border-migrant-crisis-wall-biden-trump-david-marcus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12598525/border-migrant-crisis-wall-biden-trump-david-marcus.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:26:00+00:00

It is easy to be a progressive prone to pipe dreams of impossible utopias. But it takes courage to avoid knee-jerk, bleeding-heart answers that may not be the best solutions.

## Pictured: Husband accused of murdering Sarah Ferguson's long-term personal assistant after he was arrested 200 miles from where her body was found in Texas
 - [https://www.dailymail.co.uk/news/article-12603029/Pictured-Husband-accused-murdering-Sarah-Fergusons-long-term-personal-assistant-arrested-200-miles-body-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603029/Pictured-Husband-accused-murdering-Sarah-Fergusons-long-term-personal-assistant-arrested-200-miles-body-Texas.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:09:26+00:00

James Patrick, 48, was arrested in Austin, Texas last Wednesday, and is now being held at North Tower Detention Facility in Dallas after being booked in at 4.06pm yesterday, authorities revealed.

## Cocaine-fuelled postman, 43, who bludgeoned escort, 50, to death with a dumbbell while she phoned a taxi to pick her up before hiding her body in his home for 11 days is jailed
 - [https://www.dailymail.co.uk/news/article-12603265/Cocaine-fuelled-postman-43-bludgeoned-escort-50-death-dumbbell-phoned-taxi-pick-hiding-body-home-11-days-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603265/Cocaine-fuelled-postman-43-bludgeoned-escort-50-death-dumbbell-phoned-taxi-pick-hiding-body-home-11-days-jailed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T18:06:23+00:00

Mark Nicholls, 43, hit Emily Sanderson, 50, at least 13 times with the weapon while she called a taxi to pick her up from his home in Sheffield, South Yorkshire, on May 19.

## Moment 'drunk rich girl' in Tesla gets pulled over for DUI - and unleashes barrage of abuse on cops including telling them 'my father owns an island'
 - [https://www.dailymail.co.uk/news/article-12602819/drunk-spoilt-girl-tells-police-dad-owns-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602819/drunk-spoilt-girl-tells-police-dad-owns-island.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:41:09+00:00

Stephanie Bloodworth, then 24, was pulled over in February 2022 for speeding around her Florida island in a tesla and told the police that her dad 'owns an island;.

## Ukrainian geeks who went to war: The unlikely band of videogamers who run top secret 'Griselda' unit linked to the death of three Russian generals and targeted hundreds of soldiers
 - [https://www.dailymail.co.uk/news/article-12602069/Ukrainian-geeks-went-war-unlikely-band-videogamers-run-secret-Griselda-unit-linked-death-three-Russian-generals-targeted-hundreds-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602069/Ukrainian-geeks-went-war-unlikely-band-videogamers-run-secret-Griselda-unit-linked-death-three-Russian-generals-targeted-hundreds-soldiers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:40:35+00:00

These are the video game developers who have become a deadly part of Ukraine 's war effort.

## 'Oops': What FTX staff wrote on spreadsheet showing $20billion in losses as co-founder Gary Wang testifies at Sam Bankman-Fried trial the company had been stealing its customers' money for three years before it collapsed
 - [https://www.dailymail.co.uk/news/article-12602901/Oops-FTX-staff-wrote-spreadsheet-showing-20billion-losses-founder-Gary-Wang-testifies-Sam-Bankman-Fried-trial-company-stealing-customers-money-three-years-collapsed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602901/Oops-FTX-staff-wrote-spreadsheet-showing-20billion-losses-founder-Gary-Wang-testifies-Sam-Bankman-Fried-trial-company-stealing-customers-money-three-years-collapsed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:33:30+00:00

FTX co-founder Gary Wang took the stand Friday at Sam Bankman-Fried's trial and claimed the company had been stealing customers' money for three years.

## Cops hunt for 'armed and dangerous' man after woman was found dead on popular Vermont hiking trail
 - [https://www.dailymail.co.uk/news/article-12602839/Armed-man-woman-dead-Vermont-hiking-trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602839/Armed-man-woman-dead-Vermont-hiking-trail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:33:00+00:00

A manhunt is in progress for an 'armed and dangerous' man following the discovery of a woman's body on the Delaware and Hudson Rail Trail in Vermont.

## Somalian NHS scientist wins £60,000 race discrimination payout after colleagues gave her offensive nickname on work spreadsheet
 - [https://www.dailymail.co.uk/news/article-12603139/Somalian-NHS-scientist-wins-60-000-race-discrimination-payout-colleagues-gave-offensive-nickname-work-spreadsheet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603139/Somalian-NHS-scientist-wins-60-000-race-discrimination-payout-colleagues-gave-offensive-nickname-work-spreadsheet.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:28:55+00:00

Ubah Jama was considered a 'troublemaker' after complaining about a fellow biochemist throwing a test tube in her direction, an employment tribunal heard.

## NHS trust and ward manager appear in court charged with manslaughter of mental health patient Alice Figueiredo, 22, who was found dead at hospital
 - [https://www.dailymail.co.uk/news/article-12603137/NHS-trust-ward-manager-manslaughter-mental-health-patient-Alice-Figueiredo-dead-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12603137/NHS-trust-ward-manager-manslaughter-mental-health-patient-Alice-Figueiredo-dead-hospital.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:28:48+00:00

Alice Figueiredo was found dead at Goodmayes Hospital in east London , and an investigation into her death was opened in April 2016.

## EXCLUSIVE: Hunter Biden withdrew $20,000 from daughter Maisy's college fund and spent it on hookers and drugs after bankers warned he had just 44 cents left in his account
 - [https://www.dailymail.co.uk/news/article-12598997/Hunter-Biden-withdrew-20-000-daughter-Maisys-college-fund-spent-hookers-drugs-bankers-warned-just-44-cents-left-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12598997/Hunter-Biden-withdrew-20-000-daughter-Maisys-college-fund-spent-hookers-drugs-bankers-warned-just-44-cents-left-account.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:28:01+00:00

In late 2018 Hunter Biden withdrew his $20,000 from daughter Maisy's college savings to help fund a months-long drug and hooker binge.

## Grinning Florida 'The Villages' resident, 77, is charged with peddling erectile dysfunction pills to other seniors in $1,800 drugs enterprise
 - [https://www.dailymail.co.uk/news/article-12602903/senior-charged-erectile-dysfunction-pills-Villages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602903/senior-charged-erectile-dysfunction-pills-Villages.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:27:30+00:00

A grinning 77-year-old Florida resident was arrested for peddling erectile dysfunction pills to other seniors in a retirement community The Villages, known as the 'STD capital of the US'.

## Steve Coogan opens up about feeling enormous responsibility playing Jimmy Savile in BBC's The Reckoning and describes the 'risk' of portraying the paedophile DJ
 - [https://www.dailymail.co.uk/news/article-12601715/Steve-Coogan-interview-playing-Jimmy-Savile-BBC-Reckoning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601715/Steve-Coogan-interview-playing-Jimmy-Savile-BBC-Reckoning.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:26:24+00:00

But the two-time Oscar-nominee insisted it is important not to ignore the case. After years of filming, The Reckoning debuts on BBC One on October 9 at 9pm with the first of its four parts.

## Iron Chef winner Adam Fleischman is accused of SQUATTING in elderly woman's Hollywood home by refusing to pay rent since May
 - [https://www.dailymail.co.uk/news/article-12602159/Iron-Chef-winner-Adam-Fleischman-accused-squatting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602159/Iron-Chef-winner-Adam-Fleischman-accused-squatting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:20:27+00:00

Iron Chef winner Adam Fleischman was removed from the elderly woman's Hollywood home after being accused of squatting there for months.

## Moment Kari Lake confronts her Democratic rival Ruben Gallego outside an airport men's room, says she's going to 'beat him' as they tussle over border crisis
 - [https://www.dailymail.co.uk/news/article-12602347/Moment-Kari-Lake-confronts-Democratic-rival-Ruben-Gallego-outside-airport-mens-room-says-shes-going-beat-tussle-border-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602347/Moment-Kari-Lake-confronts-Democratic-rival-Ruben-Gallego-outside-airport-mens-room-says-shes-going-beat-tussle-border-crisis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:13:39+00:00

Kari Lake confronted her Democratic opponent Ruben Gallego outside an airport men's room and told him she didn't want to work with him but instead would 'beat him.'

## 'Drunk' former Ohio mayor Cathy Luks leads cops on dramatic chase before being arrested and telling officers 'what you are doing is wrong'
 - [https://www.dailymail.co.uk/news/article-12602485/Drunk-Ohio-mayor-cops-chase-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602485/Drunk-Ohio-mayor-cops-chase-arrested.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T17:10:51+00:00

Cathy Luks , 66, a former mayor of small town Ohio, was arrested and charged with drunk driving after leading cops on a high-speed chase.

## Charlotte Sena kidnap suspect faces being probed to potential links to two unsolved murders in upstate New York 20 years ago, cops say
 - [https://www.dailymail.co.uk/news/article-12602749/Charlotte-Sena-kidnap-suspect-faces-probed-potential-links-two-unsolved-murders-upstate-New-York-20-years-ago-cops-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602749/Charlotte-Sena-kidnap-suspect-faces-probed-potential-links-two-unsolved-murders-upstate-New-York-20-years-ago-cops-say.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:35:48+00:00

Saratoga County Sheriff's Office said that they are looking into the possibility that Craig Ross, 46, could be linked to the killings of Christina White, 19, and Jennifer Hammond, 18.

## Denver sends flyers to border towns telling asylum seekers to stay away after 21,000 arrivals this year
 - [https://www.dailymail.co.uk/news/article-12602557/Denver-migrant-crisis-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602557/Denver-migrant-crisis-border.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:32:55+00:00

Denver's liberal government has asked officials at border towns to distribute fliers telling asylum seekers to stay away from the Colorado capital.

## Senior female armed police officer who was made to strip to her underwear and told 'just because you have t**s does not mean you can't do a press-up' wins sex discrimination case
 - [https://www.dailymail.co.uk/news/article-12602637/Female-armed-police-officer-West-Midlands-wins-sex-discrimination-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602637/Female-armed-police-officer-West-Midlands-wins-sex-discrimination-case.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:28:04+00:00

DI Rebecca Kalam (pictured) was told 'just because you have t**s does not mean you cannot do a press up', and forced to pose for a photoshoot when five months pregnant, a tribunal heard.

## 'Manopause' guidelines: Councils, universities, police forces and fire services draw up 'male menopause' policies which let men struggling with falling testosterone work from home, start late or alternate shifts
 - [https://www.dailymail.co.uk/news/article-12602715/Fury-string-public-bodies-develop-male-menopause-policies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602715/Fury-string-public-bodies-develop-male-menopause-policies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:23:24+00:00

In what critics described as a 'further erosion of women's rights ', a string of public bodies have drawn up ' woke ' protocols that insist 'men may also experience menopause symptoms'.

## 'Dear Kaiser Bill, may you never live to see this card': Hate mail patriotic Brits sent to Wilhem II during the First World War belittling him as the 'clown prince' are discovered a century later
 - [https://www.dailymail.co.uk/news/article-12602681/Dear-Kaiser-Bill-never-live-card-Hate-mail-patriotic-Brits-sent-Wilhem-II-World-War-belittling-clown-prince-discovered-century-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602681/Dear-Kaiser-Bill-never-live-card-Hate-mail-patriotic-Brits-sent-Wilhem-II-World-War-belittling-clown-prince-discovered-century-later.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:20:49+00:00

Despite being the grandson of Queen Victoria , the German king was public enemy number one while Britain and Germany were at war, and received a torrent of abusive letters.

## Arming Ukraine with long-range missiles will push Putin 'to put the nuclear red button on the table', Belarus dictator Lukashenko warns
 - [https://www.dailymail.co.uk/news/article-12602927/Ukraine-long-range-missiles-push-Putin-nuclear-red-button-Belarus-dictator-Lukashenko.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602927/Ukraine-long-range-missiles-push-Putin-nuclear-red-button-Belarus-dictator-Lukashenko.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:19:43+00:00

Belarus dictator Alexander Lukashenko (pictured) today cautioned the West not to turn his ally Vladimir Putin into a cornered Russian bear.

## Rio de Janeiro police find bodies of four dead drug traffickers who 'killed' three surgeons and wounded another in botched hit job
 - [https://www.dailymail.co.uk/news/article-12602283/Rio-Janeiro-police-bodies-four-dead-drug-traffickers-killed-three-surgeons-wounded-botched-hit-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602283/Rio-Janeiro-police-bodies-four-dead-drug-traffickers-killed-three-surgeons-wounded-botched-hit-job.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:18:33+00:00

The dead bodies of two drug dealers suspected of mistakenly murdering three orthopedic surgeons and wounding another at a hotel bar in Brazil were found in two separate vehicles.

## Stealth taxes will cost hardworking Brits £40BILLION a year by 2028 - £10bn more than previous estimates
 - [https://www.dailymail.co.uk/news/article-12602915/taxes-cost-40billion-2028.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602915/taxes-cost-40billion-2028.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:17:10+00:00

Taxes will raise £40billion a year from personal incomes by 2028 in a move likely to intensify calls for Chancellor Jeremy Hunt to cut taxes ahead of a potential general election

## BORIS JOHNSON: Rishi's smoking ban is barmy. Child A will be free to smoke like a chimney to the end of his days. Child B - born only a day later - will be a criminal if he does... How the hell is that supposed to work?
 - [https://www.dailymail.co.uk/news/article-12602423/BORIS-JOHNSON-Child-free-smoke-like-chimney-end-days-Child-B-born-day-later-criminal-does-hell-supposed-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602423/BORIS-JOHNSON-Child-free-smoke-like-chimney-end-days-Child-B-born-day-later-criminal-does-hell-supposed-work.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:08:50+00:00

How would you feel if you were told that the cops couldn't investigate a burglary at your home because they were dealing with a completely new category of crime - smoking?

## Prince William was in the Aston Villa dressing room before and after the midweek victory over Zrinjski Mostar  - and Matty Cash says the 'massive fan' regularly appears at training sessions
 - [https://www.dailymail.co.uk/sport/football/article-12602899/Prince-William-Aston-Villa-dressing-room-midweek-victory-Zrinjski-Mostar-Matty-Cash-says-massive-fan-regularly-appears-training-sessions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/sport/football/article-12602899/Prince-William-Aston-Villa-dressing-room-midweek-victory-Zrinjski-Mostar-Matty-Cash-says-massive-fan-regularly-appears-training-sessions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:04:57+00:00

Aston Villa's attempts to crack the Premier League elite has royal backing with Prince William making regular appearances at training sessions.

## Who was Sir Alex Ferguson's wife Cathy and how many children did they have together?
 - [https://www.dailymail.co.uk/news/article-12602569/Sir-Alex-Ferguson-wife-Cathy-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602569/Sir-Alex-Ferguson-wife-Cathy-children.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T16:04:14+00:00

Lady Cathy Ferguson, wife of Sir Alex Ferguson , has died aged 84, the family has announced today. Cathy was described by her husband as his 'bedrock'.

## Democrats pile on fury at 'flip-flopping' Biden for border wall u-turn that's a 'ploy' for 2024 votes: Hispanic lawmakers, immigration activists and environmentalists call move 'horrific' and 'backwards'
 - [https://www.dailymail.co.uk/news/article-12602521/Democrats-pile-fury-flip-flopping-Biden-border-wall-u-turn-thats-ploy-2024-votes-Hispanic-lawmakers-immigration-activists-environmentalists-call-horrific-backwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602521/Democrats-pile-fury-flip-flopping-Biden-border-wall-u-turn-thats-ploy-2024-votes-Hispanic-lawmakers-immigration-activists-environmentalists-call-horrific-backwards.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:48:40+00:00

Many Democrats are furious with President Joe Biden for resuming construction on the border wall, calling it hypocritical and a play for votes in the 2024 election.

## Netflix's 'Take Care of Maya' teen Maya Kowalski's father gives emotional testimony in $220 million case against Johns Hopkins All Children's Hospital saying showering left his daughter 'screaming in pain'
 - [https://www.dailymail.co.uk/news/article-12602461/Maya-Kowalski-Netflix-trial-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602461/Maya-Kowalski-Netflix-trial-father.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:44:15+00:00

Jack Kowalski, father of Maya Kowalski, took to the stand to describe his daughter's medical condition at the time she was separated from her family and detained in a Florida hospital.

## Hunter Biden moves to DISMISS federal gun charges: President's troubled son insists plea deal that collapsed STILL remains 'in force'
 - [https://www.dailymail.co.uk/news/article-12602551/Hunter-Biden-moves-DISMISS-federal-gun-charges-Presidents-troubled-son-insists-plea-deal-collapsed-remains-force.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602551/Hunter-Biden-moves-DISMISS-federal-gun-charges-Presidents-troubled-son-insists-plea-deal-collapsed-remains-force.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:41:50+00:00

Hunter Biden lawyer Abbe Lowell wrote in a filing that a plea deal granting immunity from prosecution is still operative, and asked a judge to dismiss gun charges against him.

## The little boy murdered in his Spider-Man pyjamas: Family photos show ten-year-old smiling with the father who will never see his son grow up after the child was killed by Putin's missiles
 - [https://www.dailymail.co.uk/news/article-12602561/The-little-boy-murdered-Spider-Man-pyjamas-Family-photos-ten-year-old-smiling-father-never-son-grow-child-killed-Putins-missiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602561/The-little-boy-murdered-Spider-Man-pyjamas-Family-photos-ten-year-old-smiling-father-never-son-grow-child-killed-Putins-missiles.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:27:06+00:00

GRAPHIC CONTENT WARNING: Family photos show a ten-year-old boy smiling with his father - but the heartbroken parent will never see his son grow up after the small child was killed in Kharkiv.

## A chef's kiss! Stephen Terry looks loved up as couple seen for the first time since restaurateur announced he was leaving his wife for wine shop assistant nearly 25 years his junior
 - [https://www.dailymail.co.uk/news/article-12602627/A-chefs-kiss-Stephen-Terry-looks-loved-couple-seen-time-restaurateur-announced-leaving-wife-wine-shop-assistant-nearly-25-years-junior.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602627/A-chefs-kiss-Stephen-Terry-looks-loved-couple-seen-time-restaurateur-announced-leaving-wife-wine-shop-assistant-nearly-25-years-junior.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:26:47+00:00

TV chef Stephen Terry, 56, who was Gordon Ramsay's best man, was spotted cosying up to his new much-younger girlfriend after announcing his split from his wife.

## Innovative Formula E racing car built from electronic waste such as iPhones, chargers and vapes goes on show at New Scientist Live this weekend
 - [https://www.dailymail.co.uk/news/article-12602559/Formula-E-car-built-electronic-waste-New-Scientist-Live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602559/Formula-E-car-built-electronic-waste-New-Scientist-Live.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:26:38+00:00

The Recover E car, which belongs to this year's Formula E world champions Envision Racing, is going on display at the New Scientist Live event at the ExCel in London this weekend.

## EXCLUSIVE: 'Train Karen' Brianna Pinnix is accused of xenophobic abuse of boss by telling him he's a 'Scottish piece of s***' - as he claims she 'was not a good drunk'
 - [https://www.dailymail.co.uk/news/article-12602753/Brianna-Pinnix-xenophobic-Scottish-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602753/Brianna-Pinnix-xenophobic-Scottish-boss.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:25:05+00:00

'Train Karen' Brianna Pinnix has been accused of a second xenophobic attack for once calling her boss a 'Scottish piece of s***' and telling him she 'hoped he would be deported.'

## Jim Jordan admits he NEVER wanted to be speaker - but believes HE is the one to unite a Republican party at war after getting Trump's endorsement
 - [https://www.dailymail.co.uk/news/article-12602335/Jim-Jordan-admits-NEVER-wanted-speaker-believes-one-unite-Republican-party-war-getting-Trumps-endorsement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602335/Jim-Jordan-admits-NEVER-wanted-speaker-believes-one-unite-Republican-party-war-getting-Trumps-endorsement.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:12:55+00:00

Jim Jordan said Friday the speaker's race would come down to not Donald Trump 's endorsement of him but who can 'unite' the warring factions within his party.

## San Francisco DA Brooke Jenkins is sued by former investigator in her office after she 'painted him as dishonest' after she dropped charges against cop for fatally shooting carjacking suspect
 - [https://www.dailymail.co.uk/news/article-12602245/investigator-Jack-Friedman-sued-Brooke-Jenkins-cop-Samayoa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602245/investigator-Jack-Friedman-sued-Brooke-Jenkins-cop-Samayoa.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T15:03:06+00:00

A former investigator from the San Francisco District Attorney's Office, Jack Friedman, has filed a federal lawsuit Monday against DA Brooke Jenkins and the city and county of San Francisco.

## Michigan student charged with a felony after hurling a metal chair at her teacher faces expulsion as educator is set to return to the classroom
 - [https://www.dailymail.co.uk/news/article-12602277/michigan-student-expulsion-hurling-chair-teacher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602277/michigan-student-expulsion-hurling-chair-teacher.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:27:29+00:00

A student caught the moment their classmate launched a chair across the room at her teacher on camera - now the viral video is giving the school a 'bad name', according to School Board President

## Lake George Canberra: Listen to air traffic control's desperate attempts to reach doomed plane carrying grandfather and his three grandchildren after it plunged 9,000ft and crashed, killing everyone on board - as chilling final transmission is revealed
 - [https://www.dailymail.co.uk/news/article-12602193/Lake-George-Canberra-air-crash-ATC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602193/Lake-George-Canberra-air-crash-ATC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:23:11+00:00

Air traffic recordings captured the moment controllers realised something had gone terribly wrong with the light aircraft after taking off from Canberra on Friday afternoon.

## Sir Alex Ferguson's wife Cathy dies aged 84: Heartbroken Man Utd legend's family confirm loss of wife of more than five decades who he had three sons and 12 grandchildren with
 - [https://www.dailymail.co.uk/news/article-12602463/Sir-Alex-Fergusons-wife-Cathy-died-ex-Man-Utd-boss-family-announces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602463/Sir-Alex-Fergusons-wife-Cathy-died-ex-Man-Utd-boss-family-announces.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:21:41+00:00

Lady Cathy was described by her husband as his 'bedrock', who had had helped nurse him back to health after his stroke after he retired after 26 years at the club in 2013.

## Rachel Reeves drops party conference plan to unveil five top UK companies who agreed to become business advisers to Labour amid fury from Tories including Chancellor Jeremy Hunt at 'partisan' move
 - [https://www.dailymail.co.uk/news/article-12602513/Rachel-Reeves-party-conference-UK-companies-business-advisers-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602513/Rachel-Reeves-party-conference-UK-companies-business-advisers-Labour.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:20:59+00:00

The shadow chancellor was planning to unveil a British infrastructure council in Liverpool next week, as part of a campaign to show the party can be trusted with the economy.

## New Jersey cop rushed to help Bob Menendez's wife after Mercedes crash despite being retired and convinced patrolman on duty to let her go without a sobriety test or having to hand over her phone
 - [https://www.dailymail.co.uk/news/article-12602251/New-Jersey-cop-rushed-help-Bob-Menendezs-wife-Mercedes-crash-despite-retired-convinced-patrolman-duty-let-without-sobriety-test-having-hand-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602251/New-Jersey-cop-rushed-help-Bob-Menendezs-wife-Mercedes-crash-despite-retired-convinced-patrolman-duty-let-without-sobriety-test-having-hand-phone.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:13:53+00:00

Menendez's wife Nadine Arslanian fatally struck 49-year-old Richard Koop in Bogota, New Jersey, on December 12, 2018. She was dating the New Jersey Democratic Senator.

## Iron Chef winner Adam Fleischman is accused of SQUATTING in elderly woman's Hollywood home by refusing to pay rent since May
 - [https://www.dailymail.co.uk/news/article-12602159/Iron-Chef-winner-Adam-Fleischman-accused-SQUATTING-elderly-womans-Hollywood-home-refusing-pay-rent-May.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602159/Iron-Chef-winner-Adam-Fleischman-accused-SQUATTING-elderly-womans-Hollywood-home-refusing-pay-rent-May.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:12:16+00:00

Iron Chef winner Adam Fleischman was removed from the elderly woman's Hollywood home after being accused of squatting there for months.

## Headteacher's mobile phones ban infuriates parents who have to pick up their children's confiscated handsets at end of school day
 - [https://www.dailymail.co.uk/news/article-12602023/Headteachers-mobile-phones-ban-infuriates-parents-pick-childrens-confiscated-handsets-end-school-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602023/Headteachers-mobile-phones-ban-infuriates-parents-pick-childrens-confiscated-handsets-end-school-day.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:11:19+00:00

Parents of pupils at The Romsey School in Hampshire are fuious at a new policy in which they have to pick up their child's confiscated phone. They claim is has caused 'chaos'.

## Revealed: Supercar convoy 'jumped red lights and breached traffic regulations' before fatal crash that saw couple burn to death - as billionaire Lamborghini driver under police investigation returns to India
 - [https://www.dailymail.co.uk/news/article-12602421/Supercar-convoy-jumped-red-lights-breached-traffic-regulations-fatal-crash-saw-couple-burn-death-billionaire-Lamborghini-driver-police-investigation-returns-India.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602421/Supercar-convoy-jumped-red-lights-breached-traffic-regulations-fatal-crash-saw-couple-burn-death-billionaire-Lamborghini-driver-police-investigation-returns-India.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:10:45+00:00

Graphic footage captured the horrific moment billionaire Vikas Oberoi's Lamborghini appeared to turn into the path of a red Ferrari that was about to overtake him.

## Moment Tory MP Gary Streeter is caught on CCTV ripping security camera off home he rents to single mother, 38, who he is battling to evict
 - [https://www.dailymail.co.uk/news/article-12602189/Tory-MP-Gary-Streeter-rip-CCTV-camera-battling-evict-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602189/Tory-MP-Gary-Streeter-rip-CCTV-camera-battling-evict-mother.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:04:00+00:00

Gary Streeter, who has been an MP since 1992, has been trying to get mother-of-one Layla Williams out from a bungalow on his farm in Devon.

## Chicago residents slam city for accommodating massive influx of migrants as winter looms - and not looking after its own homeless
 - [https://www.dailymail.co.uk/news/article-12602185/Chicago-residents-slam-city-accommodating-massive-influx-migrants-winter-looms-not-looking-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602185/Chicago-residents-slam-city-accommodating-massive-influx-migrants-winter-looms-not-looking-homeless.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T14:02:17+00:00

Chicago residents have expressed fury at the city's government for offering shelter to a massive influx of asylum seekers.

## Rylee-Rose Peverill was left to roast for more than five hours as temperatures passed 50C in her mum's Toyota Prado - while her mother Laura Rose Peverill and her boyfriend binge-watched Shameless on Netflix
 - [https://www.dailymail.co.uk/news/article-12601937/Rylee-Rose-Peverill-left-roast-five-hours-temperatures-passed-50C-mums-Toyota-Prado-mother-Laura-Rose-Peverill-boyfriend-binge-watched-Shameless-Netflix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601937/Rylee-Rose-Peverill-left-roast-five-hours-temperatures-passed-50C-mums-Toyota-Prado-mother-Laura-Rose-Peverill-boyfriend-binge-watched-Shameless-Netflix.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:58:34+00:00

Rylee spent five hours locked inside the hot car in the shade-less Queensland driveway during a heatwave.

## EXCLUSIVE: Charlotte Sena's suspected kidnapper Craig Ross targeted the nine-year-old and held her for ransom after learning of her late grandfather Patrick Sena's fortune
 - [https://www.dailymail.co.uk/news/article-12598835/Charlotte-Sena-kidnapper-Craig-Ross-targeted-ransom-grandfather-Patrick-fortune.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12598835/Charlotte-Sena-kidnapper-Craig-Ross-targeted-ransom-grandfather-Patrick-fortune.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:58:24+00:00

A former girlfriend of Craig Ross told DailyMail.com she believes he kidnapped and held nine-year-old Charlotte Sena for ransom due to his financial troubles.

## Staggering 1,000 birds die in 'massive carnage' after crashing into Chicago four-story building while migrating north - the highest number in a single day on record
 - [https://www.dailymail.co.uk/news/article-12602183/birds-die-Chicago-record.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602183/birds-die-Chicago-record.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:58:16+00:00

At least 960 birds died, crashing into lit windows at McCormick Place Lakeside Center even when monitors collected the casualties, the Chicago Tribune reported.

## SNP infighting rages after Rutherglen by-election disaster with bungling Humza Yousaf warned it can't be 'business as usual' as polls show support slumping and independence dream stalled
 - [https://www.dailymail.co.uk/news/article-12602381/SNP-infighting-rages-Rutherglen-election-disaster-bungling-Humza-Yousaf-warned-business-usual-polls-support-slumping-independence-dream-stalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602381/SNP-infighting-rages-Rutherglen-election-disaster-bungling-Humza-Yousaf-warned-business-usual-polls-support-slumping-independence-dream-stalled.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:56:25+00:00

The SNP was dealt a shattering blow as Labour overturned a majority of more than 5,000 to seize Rutherglen & Hamilton West by a margin of 9,400.

## Moment cub scouts as young as seven dodge traffic on dark country lane after getting lost on map reading exercise that was only supposed to be one mile
 - [https://www.dailymail.co.uk/news/article-12602225/moment-cub-scouts-dodge-traffic-dark-country-lane-getting-lost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602225/moment-cub-scouts-dodge-traffic-dark-country-lane-getting-lost.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:52:32+00:00

Shocking CCTV footage shows the scared youngsters dodging cars on a busy country lane just off the A44 in Worcestershire in pitch-darkness.

## We don't care if New York's full Eric, we want to be a part of it! Inside Mexican shelter where migrants still plan a new life in the Big Apple and LAUGH at Adams' warnings not to come
 - [https://www.dailymail.co.uk/news/article-12598411/Mexico-New-York-migrants-Eric-Adams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12598411/Mexico-New-York-migrants-Eric-Adams.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:16:04+00:00

'I don't care if the place is crowded,' said Genso Perez, from Venezuela, with a laugh at a shelter about an hour's drive from where Adams was receiving a honorary degree.

## Teacher, 33, who had sex with pupil, 15, in her car and a flat after plying him with booze faces jail
 - [https://www.dailymail.co.uk/news/article-12602201/Teacher-33-sex-pupil-15-car-flat-plying-booze-faces-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602201/Teacher-33-sex-pupil-15-car-flat-plying-booze-faces-jail.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:11:52+00:00

Siobhan McLean, 33, met the boy in her role as head of pupil support at a secondary school in Lanarkshire before contacting him outside of school, Hamilton Sheriff Court (pictured) heard.

## Terrifying moment Russian skydiver plunges to his death at contest dedicated to Putin
 - [https://www.dailymail.co.uk/news/article-12602051/moment-russian-skydiver-plunges-death-contest-putin-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12602051/moment-russian-skydiver-plunges-death-contest-putin-birthday.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T13:04:51+00:00

Dmitry Belyayev, 45, was filmed swooping in at high speed from a considerable height before hitting the water at a planned event in Gudermes, Chechnya .

## Idaho elk hunter shoots and kills a female grizzly bear after it charged at him in 'surprise' attack near Henrys Lake State Park
 - [https://www.dailymail.co.uk/news/article-12601919/Idaho-elk-hunter-shoots-kills-female-grizzly-bear-charged-surprise-attack-near-Henrys-Lake-State-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601919/Idaho-elk-hunter-shoots-kills-female-grizzly-bear-charged-surprise-attack-near-Henrys-Lake-State-Park.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T12:39:54+00:00

The man was making his way through heavy timber in Idaho when the grizzly appeared from the brush a short distance away. After the hunter yelled to his partner, the bear charged at him.

## Fury over Putin's claim Prigozhin plane was blown up by mercenaries high on coke - as Wagner aides release AI audio of their former chief mocking Vlad
 - [https://www.dailymail.co.uk/news/article-12601819/Fury-Putins-claim-Prigozhin-plane-blown-mercenaries-high-coke-Wagner-aides-release-AI-audio-former-chief-mocking-Vlad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601819/Fury-Putins-claim-Prigozhin-plane-blown-mercenaries-high-coke-Wagner-aides-release-AI-audio-former-chief-mocking-Vlad.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T12:10:08+00:00

Putin's cocaine-and-drugs explanation was met with incredulity and has only served to deepen the view Prigozhin - once close to the dictator - was assassinated in a state killing.

## Pictured: Tourist dad-of-five accused of stabbing his wife to death in front of his horrified children while on holiday in Australia
 - [https://www.dailymail.co.uk/news/article-12600963/Rimoni-Muliaga-wife-murder-accused-melton-victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600963/Rimoni-Muliaga-wife-murder-accused-melton-victoria.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T12:07:36+00:00

Rimoni Muliaga, 42, has been charged with the murder of Lise Muliaga who died at Melton on Melbourne's north-west outskirts on September 18.

## Two Legia Warsaw players are arrested following European match against AZ Alkmaar during chaotic scenes in Holland - with Polish club's president 'hit in the face' by officers
 - [https://www.dailymail.co.uk/news/article-12601897/Two-Legia-Warsaw-players-arrested-following-European-match-against-AZ-Alkmaar-chaotic-scenes-Holland-Polish-clubs-president-hit-face-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601897/Two-Legia-Warsaw-players-arrested-following-European-match-against-AZ-Alkmaar-chaotic-scenes-Holland-Polish-clubs-president-hit-face-officers.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T12:03:07+00:00

Officers said they had detained a 28-year-old man from Serbia and a 33-year-old man from Portugal after Thursday's match and that they were still in custody after AZ Alkmaar's 1-0 victory.

## THE GREAT DEBATE: Do YOU think the Government should be banning 14 year olds from ever buying cigarettes in their lifetimes - and will it work?
 - [https://www.dailymail.co.uk/news/article-12601425/smoking-ban-cigarette-age-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601425/smoking-ban-cigarette-age-debate.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T11:53:43+00:00

THE GREAT DEBATE: Do YOU think the Government should be banning 14 year olds from ever buying cigarettes in their lifetimes - and will it work? Join the debate in the comments now.

## Someone's in trouble! Kia Sportage spray painted with the words 'cheater' and w***e' is spotted driving around Perth
 - [https://www.dailymail.co.uk/news/article-12601611/Someones-trouble-Kia-Sportage-spray-painted-words-cheater-w-e-spotted-driving-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601611/Someones-trouble-Kia-Sportage-spray-painted-words-cheater-w-e-spotted-driving-Perth.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T10:46:41+00:00

The saying goes that hell hath no fury like a woman scorned. And while it's unclear who exactly was behind this intriguing paint job, it's safe to say they weren't happy.

## Donald Trump endorses 'star' GOP congressman Jim Jordan to succeed Kevin McCarthy as House speaker
 - [https://www.dailymail.co.uk/news/article-12601515/Donald-Trump-endorses-star-GOP-congressman-Jim-Jordan-succeed-Kevin-McCarthy-House-speaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601515/Donald-Trump-endorses-star-GOP-congressman-Jim-Jordan-succeed-Kevin-McCarthy-House-speaker.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T10:04:26+00:00

Ohio Congressman Jim Jordan has won the all-important Trump endorsement ahead of his bid to become House speaker.

## Revealed: Britain's best 40 fish and chip takeaways are named on national awards shortlist after secret taste test - does YOUR local chippy make the list?
 - [https://www.dailymail.co.uk/news/article-12601413/Britains-best-fish-chip-takeaways-named-national-awards-shortlist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601413/Britains-best-fish-chip-takeaways-named-national-awards-shortlist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T10:04:05+00:00

The National Fish and Chip Awards' panel of 'a-fish-onados' assessed chippies on food, as well as their environmental sustainability, product knowledge and practices as employers.

## 'Shocked' Alison Hammond and Dermot O'Leary send 'love and hugs' to Holly Willoughby over 'kidnap and kill' plot - as Lorraine Kelly says it's 'a terrible thing to go through'
 - [https://www.dailymail.co.uk/news/article-12601495/Shocked-Alison-Hammond-Dermot-OLeary-send-love-hugs-Holly-Willoughby-kidnap-kill-plot-Lorraine-Kelly-says-terrible-thing-through.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601495/Shocked-Alison-Hammond-Dermot-OLeary-send-love-hugs-Holly-Willoughby-kidnap-kill-plot-Lorraine-Kelly-says-terrible-thing-through.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T10:01:53+00:00

The This Morning hosts opened today's show with an emotional message for their co-host, who remains at home under police guard.

## Workmen resurface road around a Vauxhall Corsa after dopey driver ignores 'no parking' signs
 - [https://www.dailymail.co.uk/news/article-12601483/Workmen-resurface-road-Vauxhall-Corsa-Scarborough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601483/Workmen-resurface-road-Vauxhall-Corsa-Scarborough.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T10:01:25+00:00

Workmen were forced to work around a Vauxhall Corsa as they resurfaced the road in Scarborough, North Yorkshire - after the dopey driver ignored 'no parking' signs.

## Revealed: Consultants appointed to help 'bankrupt' Birmingham City Council out of its financial troubles can charge up to £8,900 per DAY
 - [https://www.dailymail.co.uk/news/article-12601437/Consultants-appointed-help-bankrupt-Birmingham-City-Council-financial-troubles-charge-8-900-DAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601437/Consultants-appointed-help-bankrupt-Birmingham-City-Council-financial-troubles-charge-8-900-DAY.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T09:52:30+00:00

Bankrupt Birmingham City Council is to be aided out of its financial woes by a team of commissioners - who could claim a combined fee of £8,900 a day.

## Buc-ee's co-founder's son is arrested for secretly recording dozens of guests having SEX, showering, using the toilet and undressing at his father's multi-million-dollar Texas lake house
 - [https://www.dailymail.co.uk/news/article-12601293/Buc-ees-founders-son-arrested-secretly-recording-dozens-guests-having-SEX-showering-using-toilet-undressing-fathers-multi-million-dollar-Texas-lake-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601293/Buc-ees-founders-son-arrested-secretly-recording-dozens-guests-having-SEX-showering-using-toilet-undressing-fathers-multi-million-dollar-Texas-lake-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T09:20:48+00:00

Mitchell Wasek, 28, allegedly recorded at least 13 people using bathrooms in the Texas lake house and other properties. He is facing 28 separate state jail felony

## Coles and Woolworths strikes: What are my supermarket opening hours this weekend?
 - [https://www.dailymail.co.uk/news/article-12600959/Coles-Woolworths-strikes-supermarket-opening-hours-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600959/Coles-Woolworths-strikes-supermarket-opening-hours-weekend.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:32:33+00:00

Employees represented by the Retail and Fast Food Workers Union will stop work from 10am on Saturday for two hours at stores in NSW , Victoria, Queensland , WA , SA and the ACT.

## Indigenous artist Esme Timbery dies aged 92
 - [https://www.dailymail.co.uk/news/article-12601339/Esme-Timbery-dies-aged-92-Indigenous-artist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601339/Esme-Timbery-dies-aged-92-Indigenous-artist.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:31:40+00:00

Renowned Indigenous artist Esme Timbery has died aged 92.

## Top sport star's fury as they learn their child attended daycare where Australia's worst ever alleged paedophile worked
 - [https://www.dailymail.co.uk/news/article-12600997/Top-sport-stars-fury-learns-child-attended-daycare-Australias-worst-alleged-paedophile-worked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600997/Top-sport-stars-fury-learns-child-attended-daycare-Australias-worst-alleged-paedophile-worked.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:30:01+00:00

Ashley Paul Griffith, 45, was this week identified as the man charged with 1600 offences including 136 rapes while working in Queensland child care.

## Police issue CCTV of man with orange bike as they hunt sex attacker who raped teenage girl in a flat in Brighton
 - [https://www.dailymail.co.uk/news/article-12601143/Police-issue-CCTV-photo-rape-reported-Brighton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601143/Police-issue-CCTV-photo-rape-reported-Brighton.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:24:08+00:00

Police have issued a photo of a man with an orange bike as they hunt for a sex attacker who raped a teenage girl in a flat in Brighton.

## 'Torture porn' fiend who went on sick Bunnings supply run before bludgeoning a woman to death in a luxury hotel learns his fate
 - [https://www.dailymail.co.uk/news/article-12600869/Bunnings-Matthew-Shane-Donaldson-torture-porn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600869/Bunnings-Matthew-Shane-Donaldson-torture-porn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:23:40+00:00

A man obsessed with 'torture porn' has been jailed for bludgeoning a sex worker with a hammer in a vicious attack at a luxurious hotel.

## Dairy farmer, 24, inspired by Jeremy Clarkson's Diddly Squat farm is caught drunk at the wheel of his BMW after downing lager to celebrate launch of his new milkshake business
 - [https://www.dailymail.co.uk/news/article-12601139/driver-inspired-jeremy-clarkson-diddly-squat-farm-caught-drink-driving-bmw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601139/driver-inspired-jeremy-clarkson-diddly-squat-farm-caught-drink-driving-bmw.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T08:22:44+00:00

Jack Allwood, 24, who was inspired to start dairy farming by Jeremy Clarkson, was caught drunk at the wheel of his BMW at 2am when he was out celebrating the launch of his new business.

## British man, 41, drowns after getting swept out to sea by strong current on Portuguese beach
 - [https://www.dailymail.co.uk/news/article-12601173/British-man-41-drowns-getting-swept-sea-strong-current-Portuguese-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12601173/British-man-41-drowns-getting-swept-sea-strong-current-Portuguese-beach.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T07:27:15+00:00

The British man, 41, drowned after he was swept out to sea by strong currents at Sao Pedro de Moel beach near the town of Nazare north of Lisbon in Portugal.

## Pioneer of the Aboriginal land rights movement - who handed back one of Australia's most beautiful areas to traditional owners - reveals why he's voting 'No' to the Voice to Parliament
 - [https://www.dailymail.co.uk/news/article-12600323/Pioneer-Aboriginal-land-rights-movement-handed-one-Australias-beautiful-areas-traditional-owners-reveals-hes-voting-No-Voice-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600323/Pioneer-Aboriginal-land-rights-movement-handed-one-Australias-beautiful-areas-traditional-owners-reveals-hes-voting-No-Voice-Parliament.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:53:54+00:00

Former Northern Territory chief minister Marshall Perron, whose government returned 292,000 hectares of land to Aboriginal traditional owners, has revealed he's against the Voice.

## Tupac Shakur suspect Duane 'Keefe D' Davis, 60, is seen brazenly boasting about the 'biggest case in Las Vegas history' in shocking bodycam arrest video
 - [https://www.dailymail.co.uk/news/article-12600961/Tupac-Shakur-suspect-Duane-Keefe-Davis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600961/Tupac-Shakur-suspect-Duane-Keefe-Davis.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:22:35+00:00

Tupac Shakur's murder suspect brazenly boasted about being part of the 'biggest case' in Las Vegas history when he was arrested, shocking bodycam revealed.

## Joseph and the Amazing Technicolour Hypocrite: Just Stop Oil eco-clown who invaded Les Miserables to the fury of £175-a-ticket audience once starred in a musical himself
 - [https://www.dailymail.co.uk/news/article-12597507/Joseph-Just-Stop-Oil-Les-Miserables-Noah-Crane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12597507/Joseph-Just-Stop-Oil-Les-Miserables-Noah-Crane.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:22:31+00:00

MailOnline has unearthed footage of Noah Crane struggling through One More Angel in Heaven during the production of Joseph and the Amazing Technicolor Dreamcoat at his Norfolk school.

## That's one way to beat the school run traffic! Moment motorist drives down pavement to skip queues at drop off time in affluent neighbourhood - sparking FURY from parents
 - [https://www.dailymail.co.uk/news/article-12599125/Thats-one-way-beat-school-run-traffic-Moment-motorist-drives-pavement-skip-queues-drop-time-affluent-neighbourhood-sparking-FURY-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12599125/Thats-one-way-beat-school-run-traffic-Moment-motorist-drives-pavement-skip-queues-drop-time-affluent-neighbourhood-sparking-FURY-parents.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:20:24+00:00

Pedestrians were shocked to see the grey Suzuki Swift motoring down the pavement down the pavement in Dulwich, southeast London.

## This could be anyone's child: Mother whose 18-year-old was groomed by county lines gang warns other parents their children can fall into drugs trap - as terrifying footage shows her son running for his life before murder
 - [https://www.dailymail.co.uk/news/article-12598699/This-anyones-child-Warning-heartbroken-mother-18-year-old-groomed-county-lines-gang-terrifying-footage-shows-running-life-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12598699/This-anyones-child-Warning-heartbroken-mother-18-year-old-groomed-county-lines-gang-terrifying-footage-shows-running-life-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:18:19+00:00

Joe Dix, 18, (pictured) was stabbed to death in Vale Green, Norwich, in January last year and died an hour later at the Norfolk and Norwich University Hospital.

## We were becoming strangers in our own village: Furious Norfolk seaside residents blast 'rude' outsiders 'destroying' the local community after voting to BAN second homes amid rebellion against wealthy townies
 - [https://www.dailymail.co.uk/news/article-12592969/We-strangers-village-Furious-Norfolk-seaside-residents-blast-rude-outsiders-destroying-local-community-voting-BAN-second-homes-amid-rebellion-against-wealthy-townies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12592969/We-strangers-village-Furious-Norfolk-seaside-residents-blast-rude-outsiders-destroying-local-community-voting-BAN-second-homes-amid-rebellion-against-wealthy-townies.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:14:29+00:00

EXCLUSIVE: Locals in Blakeney complained they were being swamped by 'rude' outsiders during the peak season and weekends, while at other times large numbers of homes were left empty.

## Why the Australian dollar is in freefall - what it means for you and why it could keep plummeting
 - [https://www.dailymail.co.uk/news/article-12600783/Why-Australian-dollar-freefall-means-plummeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600783/Why-Australian-dollar-freefall-means-plummeting.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:08:32+00:00

The Australian dollar this week fell below 63 US cents for the first time in a year and Westpac is tipping it will sink to 62 US cents by the end of October - potentially falling back to 60 US cents.

## Lake George Canberra: Plane crashes and catches fire as emergency services rush to the scene
 - [https://www.dailymail.co.uk/news/article-12600939/Lake-George-Canberra-Plane-crashes-catches-fire-emergency-services-rush-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600939/Lake-George-Canberra-Plane-crashes-catches-fire-emergency-services-rush-scene.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:08:29+00:00

A light plane has crashed near Lake George north-east of Canberra at approximately 3pm today. NSW Police described the crash as 'fatal' but without details of the deceased, so far.

## Alabama sends 275 National Guard troops to border - as nation ramps up battle against influx of illegal crossings
 - [https://www.dailymail.co.uk/news/article-12600841/Alabama-sends-National-Guard-troops-border-illegal-crossings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600841/Alabama-sends-National-Guard-troops-border-illegal-crossings.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:07:03+00:00

Alabama Gov. Kay Ivey announced Thursday she is sending the troops because 'every state has become a border state', with over 200,000 migrants crossing the border illegally last month.

## DeSantis skewers Trump for 'energizing' Democrats MORE than JFK in one of his sharpest attacks to date and says America does not need a president who 'couldn't even stop Joe'
 - [https://www.dailymail.co.uk/news/article-12600853/DeSantis-attacks-Trump-GOP-primary-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600853/DeSantis-attacks-Trump-GOP-primary-updates.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:04:21+00:00

Florida Governor Ron DeSantis has escalated his verbal attacks on Donald Trump, in some of his sharpest criticism yet as they vie for the Republican presidential nomination.

## The dog ate my novel! Fragment from John Steinbeck's original Of Mice and Men manuscript that was destroyed by his Irish setter Toby goes up for auction
 - [https://www.dailymail.co.uk/news/article-12597485/Fragment-John-Steinbecks-original-Mice-Men-manuscript-destroyed-dog-Toby-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12597485/Fragment-John-Steinbecks-original-Mice-Men-manuscript-destroyed-dog-Toby-auction.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:00:49+00:00

The tiny piece of paper features writing from the famous 1937 novel's first chapter, where Steinbeck was introducing his central characters, George Milton and Lennie Small.

## Man, 64, is charged as police probe rape and sexual assault of elderly woman and man, both 72, at assisted living home in Manchester
 - [https://www.dailymail.co.uk/news/article-12600955/Man-64-charged-police-probe-rape-sexual-assault-elderly-woman-man-72-assisted-living-home-Manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600955/Man-64-charged-police-probe-rape-sexual-assault-elderly-woman-man-72-assisted-living-home-Manchester.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T06:00:35+00:00

Police had been called to the residency at 2:30pm on March 18 after receiving disclosure from a 72-year-old woman who reported she'd been raped the night before.

## Iowa woman tries to bring box of giraffe POO in her luggage after picking up feces on Kenya trip in hopes of making it into a necklace
 - [https://www.dailymail.co.uk/news/article-12600883/Iowa-woman-tries-bring-box-giraffe-POO-luggage-picking-feces-Kenya-trip-hopes-making-necklace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600883/Iowa-woman-tries-bring-box-giraffe-POO-luggage-picking-feces-Kenya-trip-hopes-making-necklace.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:56:57+00:00

Federal customs agents pooh-poohed the plans of an Iowa woman who wanted to make jewelry from giraffe poop she picked up on a trip to Kenya and brought back to the US in her luggage.

## Famed Michelin Guide will now start rating HOTELS with key emblems as it expands beyond restaurants
 - [https://www.dailymail.co.uk/news/article-12600743/Famed-Michelin-Guide-start-rating-HOTELS-key-emblems-expands-restaurants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600743/Famed-Michelin-Guide-start-rating-HOTELS-key-emblems-expands-restaurants.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:52:39+00:00

Michelin Guide is expanding from recommending prestigious restaurants to now also designating 'Michelin Key' hotels that are worthy of patronage.

## Teen who allegedly abducted Glen Huntly schoolboy and left him with brain damage hit with new charges over alleged robbery of 13-year-old girl
 - [https://www.dailymail.co.uk/news/article-12600911/Teen-allegedly-abducted-Glen-Huntly-schoolboy-left-brain-damage-hit-new-charges-alleged-robbery-13-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600911/Teen-allegedly-abducted-Glen-Huntly-schoolboy-left-brain-damage-hit-new-charges-alleged-robbery-13-year-old-girl.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:50:09+00:00

A 15-year-old boy has been hit with five new charges, including three relating to alleged robbery of a girl, 13, after a vicious crime spree in September that left a 14-year-old in a six-day coma.

## Brisbane real estate agent forced to explain the brutal 'prison cell' aesthetic of $300-a-week rental
 - [https://www.dailymail.co.uk/news/article-12600749/Agent-prison-cell-300-week-rental.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600749/Agent-prison-cell-300-week-rental.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:42:59+00:00

An Aussie real estate agent has been forced to explain the stark appearance of a rental property that's been compared to a 'prison cell'.

## Ruby Franke's husband Kevin says he's seen her just four times since they split last year after marriage counselor Jodi Hildebrandt got involved in their lives - and says he was 'shocked' by child abuse allegations
 - [https://www.dailymail.co.uk/news/article-12599507/Ruby-Franke-husband-Kevin-child-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12599507/Ruby-Franke-husband-Kevin-child-abuse.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:28:29+00:00

YouTube mom Ruby Franke's estranged husband has said he's only seen the alleged child abuser four times since their martial split last year.

## Twist in case of Sunbury family who feared becoming homeless after insurance company rejected claim on their mouldy, mice-infested house
 - [https://www.dailymail.co.uk/news/article-12600739/Twist-case-Sunbury-family-feared-homeless-insurance-company-rejected-claim-mouldy-mice-infested-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600739/Twist-case-Sunbury-family-feared-homeless-insurance-company-rejected-claim-mouldy-mice-infested-house.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:17:23+00:00

A Melbourne family left stranded and at risk of becoming homeless by their insurance company RACV has had a stroke of luck with their claim finally being covered in full.

## 'We trusted her': Father of one-year-old boy who died from fentanyl exposure at Bronx daycare tearfully holds photo of his son and says he feels 'betrayed' - as owner, her husband and cousin are face murder charges
 - [https://www.dailymail.co.uk/news/article-12600745/nicholas-feliz-dominici-father-betrayed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600745/nicholas-feliz-dominici-father-betrayed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:13:14+00:00

The father of one-year-old who died from a Fentanyl overdose at a Bronx daycare spoke out about how he 'trusted' its owner, who now faces murder charges alongside her husband and his cousin.

## Victim of Darwin murder-suicide attempt is identified as an Irish nurse as family flock to Australia after ex-boyfriend 'attacked her and then took his own life'
 - [https://www.dailymail.co.uk/news/article-12600715/Victim-Darwin-murder-suicide-attempt-identified-Irish-nurse-family-flock-Australia-ex-boyfriend-attacked-took-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600715/Victim-Darwin-murder-suicide-attempt-identified-Irish-nurse-family-flock-Australia-ex-boyfriend-attacked-took-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:08:18+00:00

A woman shot in a murder-suicide attempt by her ex-boyfriend which killed him and left her fighting for her life has been identified as an Irish nurse, as her frantic family flies in to Darwin.

## Florida judge exonerates Christian teacher who was fired for refusing to use a student's preferred pronouns because 'God makes no mistakes': Controversial ruling labels transgenderism a 'new secular faith'
 - [https://www.dailymail.co.uk/news/article-12600721/Florida-judge-exonerates-Christian-teacher-fired-preferred-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600721/Florida-judge-exonerates-Christian-teacher-fired-preferred-pronouns.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:04:37+00:00

Florida law judge John Van Laningham called for Science teacher Yojary Mundaray to be exonerated after she was fired for refusing to use a student's preferred pronouns.

## Crazed man, 33, unleashes random attacks on three people at NYC Whole Foods as he whacks shoppers with glass bottle
 - [https://www.dailymail.co.uk/news/article-12600847/Crazed-man-33-unleashes-random-attacks-three-people-NYC-Foods-whacks-shoppers-glass-bottle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600847/Crazed-man-33-unleashes-random-attacks-three-people-NYC-Foods-whacks-shoppers-glass-bottle.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T05:02:46+00:00

A man who carried out random and unprovoked attacks on three people with a glass bottle in New York City Thursday has been arrested and charged with assault.

## Just like NYC! Mayor Eric Adams says Mexico feels like a 'little slice of home' because so many of the population live in the Big Apple - as he continues his South American campaign to dissuade migrants from crossing border
 - [https://www.dailymail.co.uk/news/article-12600729/eric-adams-migrants-mexico-puebla.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600729/eric-adams-migrants-mexico-puebla.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:56:24+00:00

Eric Adams, the mayor of New York, was in the Mexican city of Puebla on Thursday, where he said he felt at home because so many people from Puebla live in New York City.

## Major superannuation change by Albanese government could affect 200,000 people under 30 - thousands more than first claimed
 - [https://www.dailymail.co.uk/news/article-12600717/Major-superannuation-change-Albanese-government-affect-200-000-people-30-thousands-claimed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600717/Major-superannuation-change-Albanese-government-affect-200-000-people-30-thousands-claimed.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:41:35+00:00

Prime Minister Anthony Albanese's government is being warned more than 200,000 Australians under 30 stand to be affected by Labor's planned super changes, targeted at the rich.

## Voice referendum: Gen Z and millennial Yes voters are told to hide their parents' remotes, change their iPad's language settings and demand their parents love them to save the Voice in Groom a Boomer campaign
 - [https://www.dailymail.co.uk/news/article-12600617/Voice-referendum-groom-boomer-campaign-yes-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600617/Voice-referendum-groom-boomer-campaign-yes-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:32:58+00:00

In a lighthearted new advertising campaign, millennials and Gen Z Yes voters are told to hide their boomer parents' remotes and change their iPads from English to Danish.

## Sam Newman's podcast could be in big trouble with cohost uncertain to return after harsh attack from former footy star
 - [https://www.dailymail.co.uk/news/article-12600725/Sam-Newman-Don-Scott-podcast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600725/Sam-Newman-Don-Scott-podcast.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:30:08+00:00

Don Scott won't confirmed if he'll return to the You Cannot Be Serious podcast after co-host Sam Newman launched a scathing attack on him.

## Brisbane man Tom Robinson rescued by P&O cruise ship after attempt to row across the Pacific Ocean went wrong
 - [https://www.dailymail.co.uk/news/article-12600597/Brisbane-Tom-Robinson-rescued-cruise-row-Pacific.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600597/Brisbane-Tom-Robinson-rescued-cruise-row-Pacific.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:18:03+00:00

A Brisbane man attempting to be the youngest person to ever row the Pacific Ocean was rescued by a cruise ship after his boat flipped.

## W Hotel Sydney opening: See inside the city's most eye-catching new luxury hotel as the bold design by the harbour finally opens after pandemic delays
 - [https://www.dailymail.co.uk/news/article-12600331/W-Hotel-Sydney-opening-inside-citys-eye-catching-new-luxury-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600331/W-Hotel-Sydney-opening-inside-citys-eye-catching-new-luxury-hotel.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:11:23+00:00

An eye-catching luxury stay from one of the world's leading boutique hotel operators is set to open in Sydney next week.

## I only ate sandwiches for two years to afford my first home in Sydney: Here's why millennial fears of never owning a house are overstated - and my five tips to becoming a homeowner
 - [https://www.dailymail.co.uk/news/article-12600299/I-ate-sandwiches-two-years-afford-home-Sydney-Heres-millennial-fears-never-owning-home-overstated-five-tips-homeowner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600299/I-ate-sandwiches-two-years-afford-home-Sydney-Heres-millennial-fears-never-owning-home-overstated-five-tips-homeowner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:11:15+00:00

A Sydney woman who bought her first inner-city Redfern unit in 2016 expanded her property portfolio in nearby St Peters three years later. Here's how she did it.

## Kansas girl, 5, is raped and murdered at homeless campsite after her own MOTHER kicked her out of 'deplorable' home: Police arrest man, 25, who 'knew the girl'
 - [https://www.dailymail.co.uk/news/article-12600655/Kansas-girl-5-raped-murdered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600655/Kansas-girl-5-raped-murdered.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:08:17+00:00

A 25-year-old homeless man was charged Thursday in the rape and killing of a 5-year-old Kansas girl who neighbors say had been kicked out of her dilapidated house by her own mother.

## Yes campaigner, 99, tells how No voters at aged care home shut him down with three brutal words -  as he gives honest assessment of the Voice
 - [https://www.dailymail.co.uk/news/article-12596319/Doug-Peterson-Voice-campaigner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12596319/Doug-Peterson-Voice-campaigner.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T04:04:34+00:00

For 99-year-old Doug Peterson, Saturday will be the 27th time he has voted in a referendum. In his lifetime, only six have been successful, and they all had bipartisan support.

## Climate change activists push for quotas to limit how many flights people take - following calls for dogs to go vegan to reduce emissions
 - [https://www.dailymail.co.uk/news/article-12600345/Climate-change-activists-push-quotas-limit-flights-people-following-calls-dogs-vegan-reduce-emissions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600345/Climate-change-activists-push-quotas-limit-flights-people-following-calls-dogs-vegan-reduce-emissions.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T03:32:21+00:00

Climate change activist Dr Helen Hutchinson told 3AW's Tom Elliott on Thursday that tourists should prioritise ground transport when travelling, in a bid to stop aviation-related emissions.

## Oklahoma woman, 43, shoots her teen daughter dead while aiming for stray dog that was attacking kittens on her front porch - as she now faces 8 years in federal prison
 - [https://www.dailymail.co.uk/news/article-12600649/Oklahoma-woman-shoots-teen-daughter-dead-stray-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600649/Oklahoma-woman-shoots-teen-daughter-dead-stray-dog.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T03:07:06+00:00

Amanda Myrene Fields Moffett, 43, admitted she was 'grossly negligent' in the 2018 shooting death of her 16-year-old daughter Laramie, when she believed she was aiming for a stray dog.

## Los Angeles elementary schools with students as young as five will celebrate 'National Coming Out Day' with a week of LGBT lessons including an 'identity map' activity
 - [https://www.dailymail.co.uk/news/article-12600549/Los-Angeles-elementary-schools-students-young-five-celebrate-National-Coming-Day-week-LGBT-lessons-including-identity-map-activity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600549/Los-Angeles-elementary-schools-students-young-five-celebrate-National-Coming-Day-week-LGBT-lessons-including-identity-map-activity.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T03:06:34+00:00

Los Angeles elementary schools with students as young as five will participate in a weeklong celebration of 'National Coming Out Day' starting Monday.

## AOC slams Biden and demands he 'takes responsibility and reverses' border wall construction - as his administration u-turns AGAIN and starts deporting thousands of Venezuelans to combat migrant surge
 - [https://www.dailymail.co.uk/news/article-12600653/AOC-Biden-border-wall-deporting-Venezuelans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600653/AOC-Biden-border-wall-deporting-Venezuelans.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T02:47:06+00:00

The Biden administration will resume deporting Venezuelans in another migration u-turn - as staunch Democrat AOC slammed the president for his policy.

## MGM Resorts admits cyberattack that paralyzed its hotels and casinos on the Strip cost $100M in lost profits - after the company REFUSED to pay off hackers' ransom demands
 - [https://www.dailymail.co.uk/news/article-12600537/MGM-Resorts-data-breach-profits-ransom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600537/MGM-Resorts-data-breach-profits-ransom.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T02:42:57+00:00

MGM made the disclosure in a regulatory filing on Thursday evening, nearly a month after hackers caused disruptions that froze online booking systems and knocked slots machines offline.

## Aussies reveal what tourists should never do in Bali while on holiday
 - [https://www.dailymail.co.uk/news/article-12600459/Aussies-reveal-advice-Bali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600459/Aussies-reveal-advice-Bali.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:47:54+00:00

One woman who booked a trip to the Indonesian holiday hotspot put a callout for advice on 'what not to do' ahead of her vacation.

## EXCLUSIVE: Brooklyn stabbing suspect Brian Dowling, 18, appears in court after being charged with murder of Ryan Thoresen Carson
 - [https://www.dailymail.co.uk/news/article-12600437/Brooklyn-stabbing-suspect-Brian-Dowling-court-charged-murder-Ryan-Thoresen-Carson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600437/Brooklyn-stabbing-suspect-Brian-Dowling-court-charged-murder-Ryan-Thoresen-Carson.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:46:39+00:00

Dowling, 18, was in court hours after he was charged with the shocking stabbing death of Brooklyn social justice activist Ryan Carson, who died after being stabbed in the heart at around 4am Monday.

## Moped runs a red light in St Marys, Sydney and smashes into a car - sending teen riders flying onto the road
 - [https://www.dailymail.co.uk/news/article-12600241/Sydney-electric-scooter-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600241/Sydney-electric-scooter-crash.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:44:16+00:00

The three riders of an electric scooter were thrown into the air after allegedly running a red light and crashing into a Toyota Corolla.

## Extraordinary details emerge about 'secrets' Donald Trump allegedly spilled to an Australian billionaire
 - [https://www.dailymail.co.uk/news/article-12600521/donald-trump-billionaire-anthony-pratt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600521/donald-trump-billionaire-anthony-pratt.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:27:50+00:00

The New York Times reports former US ambassador Joe Hockey downplayed Mr Trump's alleged disclosures.

## Brooklyn activist Ryan Thoresen Carson's 'working class' friends raise $68,000 in fundraiser so they can 'take time off of work to properly mourn'
 - [https://www.dailymail.co.uk/news/article-12600333/Brooklyn-activist-Ryan-Thoresen-Carsons-friends-fundraiser-properly-mourn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600333/Brooklyn-activist-Ryan-Thoresen-Carsons-friends-fundraiser-properly-mourn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:10:43+00:00

A GoFundMe set up by the Brooklyn social justice activist's friends has raked in over $68,000 in response to his stabbing death on Monday, which they say is to help them take time off work.

## Joey Barton claims Kevin Keegan is 'bang on' after ex-Newcastle boss said he doesn't 'like listening to ladies talking about the England men's team'
 - [https://www.dailymail.co.uk/news/article-12600465/Joey-Barton-claims-Kevin-Keegan-bang-ex-Newcastle-boss-said-doesnt-like-listening-ladies-talking-England-mens-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600465/Joey-Barton-claims-Kevin-Keegan-bang-ex-Newcastle-boss-said-doesnt-like-listening-ladies-talking-England-mens-team.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:08:53+00:00

Keegan, 72, was branded a relic of the 1970s after he told an audience at a live event in the West Country: 'I don't like to listen to ladies talking about the England men's team'.

## Meghan Markle and Prince Harry will return to NYC next week to host Archewell's mental health summit - five months after their 'near catastrophic car chase' in Big Apple
 - [https://www.dailymail.co.uk/news/article-12600309/Meghan-Markle-Prince-Harry-Archewell-Summit-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600309/Meghan-Markle-Prince-Harry-Archewell-Summit-NYC.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T01:02:09+00:00

Meghan Markle and Prince Harry will return to New York City in mid-October for Archewell's mental health summit, the first ever in-person event for the foundation.

## Vile abuser who beat his girlfriend to death in savage attack and told her family 'she deserved it' admits murder
 - [https://www.dailymail.co.uk/news/article-12600411/Vile-abuser-beat-girlfriend-death-savage-attack-admits-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600411/Vile-abuser-beat-girlfriend-death-savage-attack-admits-murder.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:59:51+00:00

Christopher Cook, 41, of no fixed abode, killed support worker 54-year-old Jacqueline Kerr (pictured) in a vicious frenzy at her flat in Aberdeen, Scotland, on January 15.

## Labour thrash SNP in by-election in stinging blow for independence supporters - though turnout was nearly HALF that of 2019 vote
 - [https://www.dailymail.co.uk/news/article-12600489/Labour-thrash-SNP-election-stinging-blow-independence-supporters-turnout-nearly-HALF-2019-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600489/Labour-thrash-SNP-election-stinging-blow-independence-supporters-turnout-nearly-HALF-2019-vote.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:56:14+00:00

The party's candidate, Michael Shanks, took the Westminster seat in the by-election - which was called after former SNP MP Margaret Ferrier was ousted for breaking Covid rules.

## Alabama teen, 14, with family 'hit list' shoots dead brother, 17, before confessing to school friend and asking for help to murder his remaining relatives
 - [https://www.dailymail.co.uk/news/article-12600257/alabama-teen-murders-brother-hit-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600257/alabama-teen-murders-brother-hit-list.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:55:58+00:00

The incident took place in the Pike County town of Banks when, on October 3, sheriff's deputies were called to a home after the boy's father had found the 17-year-old dead.

## Nine rapes were reported to civilian police in 13 months at army training centre for teenagers where tragic Jaysley-Louise Beck had 'toxic 20-month relationship with former instructor' before 'taking her own life'
 - [https://www.dailymail.co.uk/news/article-12600327/Nine-rapes-reported-civilian-police-13-months-army-training-centre-teenagers-tragic-Jaysley-Louise-Beck-toxic-20-month-relationship-former-instructor-taking-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600327/Nine-rapes-reported-civilian-police-13-months-army-training-centre-teenagers-tragic-Jaysley-Louise-Beck-toxic-20-month-relationship-former-instructor-taking-life.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:53:35+00:00

New figures have raised serious questions about safeguarding at Harrogate military college (pictured), which trains 16 and 17-year-olds and was rated as 'outstanding' by Ofsted.

## Family friend of Brooklyn knifing suspect Brian Dowling, 18, says he 'can't think of what triggered him to go that way' - as cops charge shackled teen with murder for unprovoked 4am attack on Ryan Thoresen Carson
 - [https://www.dailymail.co.uk/news/article-12600263/brian-dowling-knife-attack-ryan-thoresen-carson-murder-brooklyn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600263/brian-dowling-knife-attack-ryan-thoresen-carson-murder-brooklyn.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:50:34+00:00

Brian Dowling, 18, was arrested on Thursday and charged with fatal stabbing  Ryan Thoresen Carson, 32, in the early hours of Monday. A family friend said they cannot understand the killing.

## Mike Lindell admits he is 'broke' as MyPillow attorneys say he owes them 'millions' in unpaid fees for defending him in election defamation lawsuits
 - [https://www.dailymail.co.uk/news/article-12600311/Mike-Lindell-broke-MyPillow-lawsuit-defamation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600311/Mike-Lindell-broke-MyPillow-lawsuit-defamation.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:40:38+00:00

In a court filing on Thursday, Lindell's attorneys said he owes 'millions of dollars' in unpaid legal fees, and sought to drop him as a client in election defamation lawsuits.

## Sir Roger Moore's family sell the 007 star's personal collection of James Bond memorabilia for £1.1 million including white ski suit from A View to a Kill
 - [https://www.dailymail.co.uk/news/article-12600481/Roger-Moores-007-collection-James-Bond-memorabilia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600481/Roger-Moores-007-collection-James-Bond-memorabilia.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:38:28+00:00

The family of Sir Roger Moore have auctioned off the late 007 actor's collection of memorabilia and personal items for an impressive £1.1million.

## Read the bizarre note that has caught the attention of an entire Sydney neighbourhood: 'I hope this man finds what he is looking for'
 - [https://www.dailymail.co.uk/news/article-12599873/Read-bizarre-note-caught-attention-entire-Sydney-neighbourhood-hope-man-finds-looking-for.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12599873/Read-bizarre-note-caught-attention-entire-Sydney-neighbourhood-hope-man-finds-looking-for.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:25:39+00:00

A bizarre handwritten note from a bachelor looking for love pole has sparked the attention of an Sydney neighbourhood after it was posted on a telephone pole.

## Under-25s are more likely to binge-drink than the rest of the population despite also having the highest rate of teetotallers, research finds
 - [https://www.dailymail.co.uk/news/article-12600403/Under-25s-binge-drink-teetotal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600403/Under-25s-binge-drink-teetotal.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:19:46+00:00

They are often referred to as Generation Sensible for their focus on healthy living and apparent lack of interest in alcohol.

## Brighton stabbing: Boy, 16, is arrested on suspicion of murder after death of 17-year-old
 - [https://www.dailymail.co.uk/news/article-12600401/Brighton-stabbing-Boy-16-arrested-suspicion-murder-death-17-year-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490](https://www.dailymail.co.uk/news/article-12600401/Brighton-stabbing-Boy-16-arrested-suspicion-murder-death-17-year-old.html?ns_mchannel=rss&ns_campaign=1490&ito=1490)
 - RSS feed: https://www.dailymail.co.uk/news/index.rss
 - date published: 2023-10-06T00:15:26+00:00

Emergency services were called to Queens Road, a busy city centre street in Brighton, at around 5pm to reports that a 17-year-old boy had been stabbed.

