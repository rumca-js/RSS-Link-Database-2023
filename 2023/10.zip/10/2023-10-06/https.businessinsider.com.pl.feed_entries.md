# Source:Business insider, URL:https://businessinsider.com.pl/.feed, language:pl-PL

## Biden chce się spotkać z Xi Jinpingiem. Pekin jest na "tak"
 - [https://businessinsider.com.pl/wiadomosci/joe-biden-chce-sie-spotkac-z-xi-jinpingiem-w-usa/w1qh393](https://businessinsider.com.pl/wiadomosci/joe-biden-chce-sie-spotkac-z-xi-jinpingiem-w-usa/w1qh393)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T18:58:21+00:00

Prezydent USA Joe Biden potwierdził, że może spotkać się w listopadzie z przywódcą Chin Xi Jinpingiem przy okazji szczytu APEC w San Francisco. Według prasy, przygotowania do spotkania przywódców są w toku, lecz prezydent zaznaczył, że nic nie zostało jeszcze ustalone

## Nawet 15 lat więzienia. Prawnicy tłumaczą, jaka kara może spotkać polskich youtuberów
 - [https://businessinsider.com.pl/wiadomosci/co-grozi-youtuberom-zamieszanym-w-pandoragate-prawnicy-nie-maja-watpliwosci/pj4g3xt](https://businessinsider.com.pl/wiadomosci/co-grozi-youtuberom-zamieszanym-w-pandoragate-prawnicy-nie-maja-watpliwosci/pj4g3xt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T18:11:40+00:00

Prawnicy nie mają wątpliwości — jeśli oskarżenia pojawiające się w filmie Sylwestra Wardęgi się potwierdzą, polscy youtuberzy mogą ponieść konsekwencje karne. I to spore. Już za samo wysyłanie wiadomości tekstowych czy głosowych o charakterze seksualnym do małoletnich poniżej 15. roku życia można pójść do więzienia nawet na kilka lata. Pojawiające się informacje wskazują, że w tzw. aferze Pandoragate na wysyłaniu wiadomości się nie kończyło. I choć prokuratura jeszcze nie postawiła żadnemu youtuberowi wymienionemu w materiale Wardęgi zarzutów, to służby intensywnie badają sprawę.

## USA blokuje firmy dostarczające Rosji chipy. Pochodzą głównie z jednego kraju
 - [https://businessinsider.com.pl/gospodarka/usa-blokuje-firmy-dostarczajace-rosji-chipy-pochodza-glownie-z-jednego-kraju/fr0jl7z](https://businessinsider.com.pl/gospodarka/usa-blokuje-firmy-dostarczajace-rosji-chipy-pochodza-glownie-z-jednego-kraju/fr0jl7z)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T17:30:05+00:00

Amerykańskie ministerstwo (departament) handlu ogłosił w piątek nałożenie restrykcji handlowych na 49 firm, zaopatrujących Rosję w półprzewodniki i elektronikę pochodzącą z USA. Zdecydowana większość z nich — 42 — to podmioty z Chin.

## Niemiecki gigant wybuduje centrum innowacji na Podkarpaciu
 - [https://businessinsider.com.pl/firmy/niemiecki-gigant-wybuduje-centrum-innowacji-na-podkarpaciu/yglnvpj](https://businessinsider.com.pl/firmy/niemiecki-gigant-wybuduje-centrum-innowacji-na-podkarpaciu/yglnvpj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T17:13:03+00:00

Spółka BSH zawarła umowę dotyczącą budowy nowej siedziby dla Centrum Badań i Rozwoju małego AGD w Rzeszowie. Jeden z największych producentów AGD na świecie właśnie rozpoczął już przygotowanie placu budowy. Wartość inwestycji to prawie 24 mln zł.

## Android 14 już dostępny dla wybranych telefonów. Ma AI do generowania tapet
 - [https://businessinsider.com.pl/technologie/nowe-technologie/android-14-juz-dostepny-dla-wybranych-telefonow-ma-ai-do-generowania-tapet/zrv743k](https://businessinsider.com.pl/technologie/nowe-technologie/android-14-juz-dostepny-dla-wybranych-telefonow-ma-ai-do-generowania-tapet/zrv743k)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T16:44:46+00:00

Najnowsza wersja Androida dodaje konfigurowalne ekrany blokady, lepsze wsparcie dla kluczy dostępu oraz nowe funkcje zdrowotne na urządzeniu. Na razie jednak dostępna jest tylko dla smartfonów Pixel. Inne telefony otrzymają system później w tym roku.

## Roboty podające piwo to przepis na sukces giełdowy. Oto największe w tym roku IPO w Korei Południowej
 - [https://businessinsider.com.pl/gielda/wiadomosci/roboty-podajace-piwo-to-przepis-na-sukces-gieldowy-najwieksze-ipo/m7tvty5](https://businessinsider.com.pl/gielda/wiadomosci/roboty-podajace-piwo-to-przepis-na-sukces-gieldowy-najwieksze-ipo/m7tvty5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T16:23:17+00:00

Doosan Robotics zebrało 310 mln dol. w swoim IPO, a akcje na dzień debiutu wzrosły o 160 proc. To największa w tym roku oferta publiczna w Korei Południowej i wbrew pozorom nie pochodzi z sektora energetycznego, jak w zeszłym roku, ale z robotyki.

## Przemysł energochłonny otrzyma 5,5 mld zł. Bruksela daje zielone światło
 - [https://businessinsider.com.pl/gospodarka/przemysl-energochlonny-otrzyma-55-mld-zl-bruksela-daje-zielone-swiatlo/hjmsl30](https://businessinsider.com.pl/gospodarka/przemysl-energochlonny-otrzyma-55-mld-zl-bruksela-daje-zielone-swiatlo/hjmsl30)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T15:39:12+00:00

Komisja Europejska zatwierdziła w piątek polski program pomocy państwowej o wartości 1,2 mld euro (5,5 mld zł), mający na celu wsparcie energochłonnych przedsiębiorstw, borykających się z rosnącymi kosztami energii w kontekście wojny Rosji z Ukrainą.

## X testuje nowe poziomy płatnego członkostwa. Chce zrekompensować słabe przychody z reklam
 - [https://businessinsider.com.pl/technologie/nowe-technologie/x-testuje-nowe-poziomy-platnego-czlonkostwa-wersja-darmowa-moze-zniknac/ks0n4mk](https://businessinsider.com.pl/technologie/nowe-technologie/x-testuje-nowe-poziomy-platnego-czlonkostwa-wersja-darmowa-moze-zniknac/ks0n4mk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T15:19:40+00:00

Firma wcześniej znana jako Twitter rozważa zwiększenie przychodów poprzez wprowadzenie trzech poziomów subskrypcji Premium, różniących się ilością wyświetlanych reklam. Nie jest jeszcze jasne, czy zostanie utrzymana darmowa wersja serwisu społecznościowego.

## Horrendalne kwoty ubezpieczenia samochodów elektrycznych. Nawet 26 tys. zł
 - [https://businessinsider.com.pl/gospodarka/horrendalne-kwoty-ubezpieczenia-samochodow-elektrycznych-nawet-26-tys-zl/r0twd67](https://businessinsider.com.pl/gospodarka/horrendalne-kwoty-ubezpieczenia-samochodow-elektrycznych-nawet-26-tys-zl/r0twd67)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T15:19:07+00:00

Nie tylko sam zakup, ale też utrzymanie samochodów elektrycznych może słono kosztować. Brytyjski dziennik "The Guardian" opisuje, że właściciele elektryków muszą płacić fortunę za roczne ubezpieczenie swoich aut.

## Jedna subskrypcja, dwa serwisy. RAS Polska i TVN Warner Bros łączą oferty
 - [https://businessinsider.com.pl/wiadomosci/jedna-subskrypcja-dwa-serwisy-nowa-oferta-na-rynku/qqzjnhp](https://businessinsider.com.pl/wiadomosci/jedna-subskrypcja-dwa-serwisy-nowa-oferta-na-rynku/qqzjnhp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T14:58:00+00:00

RAS Polska oraz TVN Warner Bros łączą siły, oferując wspólny pakiet TVN24 Go oraz Onet Premium. Oznacza to możliwość zakupu wspólnego pakietu i logowania się do obu serwisów przy pomocy konta TVN lub O'Konta.

## Przeprosiny za kontrowersyjne słowa prezesa NBP. "Niegodne zachowanie"
 - [https://businessinsider.com.pl/finanse/kolejne-przeprosiny-za-kontrowersyjne-slowa-prezesa-nbp-niegodne-zachowanie/h3f7rvc](https://businessinsider.com.pl/finanse/kolejne-przeprosiny-za-kontrowersyjne-slowa-prezesa-nbp-niegodne-zachowanie/h3f7rvc)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T14:42:06+00:00

Ludwik Kotecki, członek Rady Polityki Pieniężnej, przeprosił osoby, które poczuły się urażone wypowiedziami szefa RPP, Adama Glapińskiego. Kontrowersyjne słowa padły podczas czwartkowej konferencji prasowej.

## PO zapowiada likwidację TVP Info i "Wiadomości". Tuba propagandowa
 - [https://businessinsider.com.pl/wiadomosci/po-zapowiada-likwidacje-tvp-info-i-wiadomosci/f27ncnk](https://businessinsider.com.pl/wiadomosci/po-zapowiada-likwidacje-tvp-info-i-wiadomosci/f27ncnk)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T14:40:20+00:00

Podczas konferencji prasowej Cezary Tomczyk, poseł Koalicji Obywatelskiej, krytykował rząd PiS-u za to, co uważa za propagandę prowadzoną przez Telewizję Polską, którą kiedyś nazywano telewizją publiczną. Tomczyk argumentował, że obecna władza PiS-u opiera się na kłamstwie, a telewizja służy jako narzędzie manipulacji opinii publicznej.

## Irak zakazuje używania dolara w transakcjach gotówkowych
 - [https://businessinsider.com.pl/gospodarka/irak-zakazuje-uzywania-dolara-w-transakcjach-gotowkowych/3tqg8tx](https://businessinsider.com.pl/gospodarka/irak-zakazuje-uzywania-dolara-w-transakcjach-gotowkowych/3tqg8tx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T14:26:35+00:00

Irak jest gotowy do dedolaryzacji. Od początku przyszłego roku wprowadzi zakaz gotówkowego obrotu dolarem amerykańskim, a globalny ruch przeciwko dolarowi nabiera tempa. Informację podał Reutersowi jeden z najważniejszych decydentów finansowych w Iraku.

## Wyspa Margarita — karaibski raj na wyciągniecie ręki. Pokoje z widokiem na ocean
 - [https://businessinsider.com.pl/lifestyle/podroze/wyspa-margarita-karaibski-raj-na-wyciagniecie-reki-pokoje-z-widokiem-na-ocean/k5znmgw](https://businessinsider.com.pl/lifestyle/podroze/wyspa-margarita-karaibski-raj-na-wyciagniecie-reki-pokoje-z-widokiem-na-ocean/k5znmgw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T14:03:01+00:00

Wyspa Margarita, zwana „Perłą Karaibów”, jest jednym z najbardziej urokliwych i różnorodnych kierunków wenezuelskich. Położona na turkusowych wodach Morza Karaibskiego, ta wyspa jest prawdziwym rajem dla miłośników słońca, pięknych plaż i egzotycznej kuchni. Czym jeszcze przyciąga turystów? Z pewnością różnorodnością krajobrazu: od piaszczystych plaż przez górzyste tereny aż po bujne lasy tropikalne. Nie można również zapomnieć o słynnych perłach, które przez wieki były głównym źródłem bogactwa wyspy. W artykule polecamy sprawdzone hotele, które mają dostępne terminy i są różnorodne pod względem standardu i ceny. Zapraszamy!

## LOT odświeży Dreamlinery. Nowe wnętrza samolotów [WIZUALIZACJE]
 - [https://businessinsider.com.pl/wiadomosci/lot-odswiezy-dreamlinery-nowe-wnetrza-samolotow-wizualizacje/jzmk9m4](https://businessinsider.com.pl/wiadomosci/lot-odswiezy-dreamlinery-nowe-wnetrza-samolotow-wizualizacje/jzmk9m4)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:46:04+00:00

Wnętrza szerokokadłubowych samolotów Boeing 787 Dreamliner należących do LOT-u zostaną poddane gruntownej modernizacji. Wprowadzone zostaną nowe fotele i ulepszony wystrój. Dodatkowo pasażerowie będą mogli korzystać z bezprzewodowego internetu w trakcie lotu.

## Wizz Air poleci z Radomia. Pierwsze połączenia już wkrótce
 - [https://businessinsider.com.pl/gospodarka/wizz-air-poleci-z-radomia-wiemy-kiedy-pierwsze-polaczenia/827phdw](https://businessinsider.com.pl/gospodarka/wizz-air-poleci-z-radomia-wiemy-kiedy-pierwsze-polaczenia/827phdw)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:20:46+00:00

Jak podaje Radio dla Ciebie i serwis Fly4free, Wizz Air podjął ostateczną decyzję w sprawie lotów z lotniska w Radomiu. Pierwsze loty mogą odbyć się jeszcze zimą.

## Nieoczekiwany ruch Sądu Najwyższego. Pierwszy raz pyta TSUE o sprawę frankową
 - [https://businessinsider.com.pl/prawo/pierwszy-raz-w-historii-sad-najwyzszy-pyta-tsue-o-frankowiczow/bxmc6d8](https://businessinsider.com.pl/prawo/pierwszy-raz-w-historii-sad-najwyzszy-pyta-tsue-o-frankowiczow/bxmc6d8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:15:01+00:00

Piątek 6 października może przejść do historii spraw frankowych. Tego dnia Sąd Najwyższy po raz pierwszy skierował pytanie do Trybunału Sprawiedliwości Unii Europejskiej dotyczące frankowiczów. W TSUE na rozpatrzenie czekają już dwa pytania w sprawie do zatrzymania, ale zdaniem SN nie do końca dobrze uzasadnione.

## Dobre dane to złe dane. Amerykański rynek pracy silny jak byk
 - [https://businessinsider.com.pl/gospodarka/dobre-dane-to-zle-dane-amerykanski-rynek-pracy-silny-jak-byk/3qqxktn](https://businessinsider.com.pl/gospodarka/dobre-dane-to-zle-dane-amerykanski-rynek-pracy-silny-jak-byk/3qqxktn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:14:53+00:00

Dziś poznaliśmy dane o zatrudnieniu w sektorze pozarolniczym (NFP) w USA, które są jednymi z najważniejszych publikacji makroekonomicznych. Rezultaty okazały się zaskakująco mocne, co rodzi obawy o to, czy uda się zdławić inflację. Zwiększać to może prawdopodobieństwo utrzymania na wysokim poziomie, a może nawet kolejnej podwyżki, stóp procentowych.

## Dobre dane to złe dane. Amerykański rynek pracy silny jak byk
 - [https://businessinsider.com.pl/finanse/dobre-dane-to-zle-dane-amerykanski-rynek-pracy-silny-jak-byk/ljej0wt](https://businessinsider.com.pl/finanse/dobre-dane-to-zle-dane-amerykanski-rynek-pracy-silny-jak-byk/ljej0wt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:14:53+00:00

Dziś poznaliśmy dane o zatrudnieniu w sektorze pozarolniczym (NFP) w USA, które są jednymi z najważniejszych publikacji makroekonomicznych. Rezultaty okazały się zaskakująco mocne, nie widać oznak recesji. To rodzi obawy, czy uda się prędko zdławić inflację. Zwiększać to może prawdopodobieństwo utrzymania na wysokim poziomie, a może nawet kolejnej podwyżki, stóp procentowych.

## Członkini RPP przeprasza za "wystąpienie" Adama Glapińskiego
 - [https://businessinsider.com.pl/biznes/czlonkini-rpp-przeprasza-za-wystapienie-adama-glapinskiego/wddxew2](https://businessinsider.com.pl/biznes/czlonkini-rpp-przeprasza-za-wystapienie-adama-glapinskiego/wddxew2)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T13:09:37+00:00

Członkini Rady Polityki Pieniężnej, Joanna Tyrowicz, przeprosiła na LinkedIn za ostatni "występ" Adama Glapińskiego.  W swoim wpisie "pocieszyła" internautów, że podczas konferencji powiedziano zbyt wiele na temat gospodarki. Nawiązała również pośrednio do obraźliwych słów, które prezes NBP kierował w stronę innych ekonomistów.

## Nowy inwestor SpaceX dużym zaskoczeniem. To największy bank we Włoszech
 - [https://businessinsider.com.pl/biznes/elon-musk-zyskal-wloskiego-inwestora-dla-spacex-to-ogromny-bank/9r10yhe](https://businessinsider.com.pl/biznes/elon-musk-zyskal-wloskiego-inwestora-dla-spacex-to-ogromny-bank/9r10yhe)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:49:39+00:00

Włoski Intesa Sanpaolo zainwestował niespodziewanie w firmę Space Exploration Technologies Corp. (SpaceX) Elona Muska. Powód? Bank zwraca się w stronę przemysłu lotniczego i kosmicznego jako kluczowego motoru globalnego wzrostu.

## Jak głosują kobiety, komu opłaca się agresja, kto wygra, nie rosnąc. Prezes IBRiS o sondażowej kuchni
 - [https://businessinsider.com.pl/wiadomosci/sondaze-wyborcze-kluczowe-narzedzie-kampanii/en50qs8](https://businessinsider.com.pl/wiadomosci/sondaze-wyborcze-kluczowe-narzedzie-kampanii/en50qs8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:47:35+00:00

Ostatnie dni przed wyborami to najgorętszy moment kampanii wyborczej. Jak powstają sondaże preferencji politycznych? Które partie mają szansę odnotować wzrost na ostatniej prostej? To wyjaśnił nam Marcin Duma, prezes pracowni sondażowej IBRiS.

## Nalot Niemców na posiadłości rosyjskiego oligarchy. Wielka akcja służb
 - [https://businessinsider.com.pl/wiadomosci/nalot-niemcow-na-posiadlosci-rosyjskiego-oligarchy-wielka-akcja-sluzb/kyhewp8](https://businessinsider.com.pl/wiadomosci/nalot-niemcow-na-posiadlosci-rosyjskiego-oligarchy-wielka-akcja-sluzb/kyhewp8)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:41:15+00:00

Niemieckie służby celne i policja weszły w czwartek do kilku nieruchomości w południowej części Niemiec, należących do rosyjskiego miliardera — informuje Reuters. Ma to związek z zamrożeniem majątku w ramach zachodnich sankcji dla rosyjskich oligarchów, szczegóły jednak nie są znane.

## Jądrowa historia Polski właśnie się zaczyna. "Transformacja tutaj może zmienić rynek na świecie"
 - [https://businessinsider.com.pl/gospodarka/jadrowa-historia-polski-wlasnie-sie-zaczyna-transformacja-tu-zmieni-rynek-na-swiecie/g8d5cde](https://businessinsider.com.pl/gospodarka/jadrowa-historia-polski-wlasnie-sie-zaczyna-transformacja-tu-zmieni-rynek-na-swiecie/g8d5cde)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:35:27+00:00

Czy Polska ma szansę stać się wiodącym eksporterem modułów elektrowni jądrowej? Amerykanie wierzą, że tak i do tej idei przekonują coraz więcej dużych podmiotów. A demonstracyjny moduł w całości wyprodukowany w naszym kraju jest najlepszym dowodem na to, że jądrowa historia Polski właśnie zaczyna się na nowo.

## Gorąca dyskusja RPP na posiedzeniu, podczas którego zdecydowano o obniżce stóp
 - [https://businessinsider.com.pl/finanse/taka-byla-dyskusja-rpp-na-posiedzeniu-podczas-ktorego-zdecydowano-o-obnizce-stop/f118p8l](https://businessinsider.com.pl/finanse/taka-byla-dyskusja-rpp-na-posiedzeniu-podczas-ktorego-zdecydowano-o-obnizce-stop/f118p8l)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:29:45+00:00

Większość członków RPP oceniła, podejmując wrześniową decyzję o skokowym cięciu stóp procentowych, że inflacja będzie się dalej obniżać. Jako czynniki to powodujące wymieniono m.in. osłabienie popytu, pogorszenie krajowej i zagranicznej koniunktury, spadek presji kosztowej i schłodzenie rynku kredytowego. Były jednak także głosy odrębne.

## Adam Glapiński znów kupuje złoto. W tym roku to już ponad 100 ton
 - [https://businessinsider.com.pl/gospodarka/adam-glapinski-znow-kupuje-zloto-w-tym-roku-to-juz-ponad-100-ton/frn00nb](https://businessinsider.com.pl/gospodarka/adam-glapinski-znow-kupuje-zloto-w-tym-roku-to-juz-ponad-100-ton/frn00nb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T12:24:05+00:00

Adam Glapiński znów zdecydował o zakupie złota. W skarbcu Narodowego Banku Polskiego znajduje się obecnie niemal 334 tony złota — wynika z wyliczeń BI Polska. To oznacza, że wrzesień był szóstym z rzędu miesiącem, gdy bank centralny kupował kruszec.

## Biedronka przeżywa boom budowlany i uderza w Żabkę. Oto mapa
 - [https://businessinsider.com.pl/gospodarka/biedronka-przezywa-boom-budowlany-oto-mapa/9p7ytp0](https://businessinsider.com.pl/gospodarka/biedronka-przezywa-boom-budowlany-oto-mapa/9p7ytp0)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T11:45:29+00:00

Biedronka otworzyła we wrześniu 29 punktów w całym kraju i wyremontowała 30 swoich sklepów. Firma wyjaśnia, na czym polegają przebudowy.

## Philips na giełdzie. Akcje spadają po problemach z respiratorami
 - [https://businessinsider.com.pl/biznes/philips-na-gieldzie-akcje-spadaja-po-problemach-z-respiratorami/tzx3syp](https://businessinsider.com.pl/biznes/philips-na-gieldzie-akcje-spadaja-po-problemach-z-respiratorami/tzx3syp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T11:41:55+00:00

Akcje Philips, firmy technologicznej oraz działającej w branży zdrowotnej, wyraźnie spadły po tym, jak amerykański regulator ds. leków uznał jej sposób zarządzania wycofaniem produktu z rynku za niewystarczający.

## Turbulentne czasy dla złotego. Zagraniczne wydarzenia zdecydują o naszej walucie
 - [https://businessinsider.com.pl/finanse/zagraniczne-wydarzenia-zdecyduja-o-notowaniach-zlotego/mctw53n](https://businessinsider.com.pl/finanse/zagraniczne-wydarzenia-zdecyduja-o-notowaniach-zlotego/mctw53n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T11:13:13+00:00

Złoty w najbliższym czasie będzie pozostawał pod wpływem wydarzeń za granicą, głównie w USA. Na razie kluczowymi informacjami będą te z amerykańskiego rynku pracy i inflacji. Dodatkowym czynnikiem ryzyka się wybory parlamentarne w Polsce.

## Zastąpił 90 proc. pracowników pomocy technicznej sztuczną inteligencją. "Bot jest 100 razy mądrzejszy"
 - [https://businessinsider.com.pl/twoje-pieniadze/praca/zastapil-90-proc-pracownikow-pomocy-technicznej-sztuczna-inteligencja-nie-ma-miejsca/phk7gcz](https://businessinsider.com.pl/twoje-pieniadze/praca/zastapil-90-proc-pracownikow-pomocy-technicznej-sztuczna-inteligencja-nie-ma-miejsca/phk7gcz)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T11:00:24+00:00

CEO zastąpił 90 proc. pracowników pomocy technicznej sztuczną inteligencją. Twierdzi, że nie ma już miejsca na pracę polegającą na kopiowaniu i wklejaniu

## Leki na otyłość zyskują na popularności. Firmy spożywcze obawiają się o mniejszą sprzedaż
 - [https://businessinsider.com.pl/wiadomosci/leki-na-otylosc-zaszkodza-branzy-spozywczej-producenci-boja-sie-o-sprzedaz/j909txt](https://businessinsider.com.pl/wiadomosci/leki-na-otylosc-zaszkodza-branzy-spozywczej-producenci-boja-sie-o-sprzedaz/j909txt)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T10:52:11+00:00

Na świecie rośnie liczba recept na leki takie jak Wegovy i Ozempic. Z tego powodu sprzedawcy żywności coraz częściej zmagają się z pytaniami o to, czy ludzie będą teraz kupować mniej jedzenia.

## Debata TVP. Szymon Hołownia też potwierdził obecność
 - [https://businessinsider.com.pl/wiadomosci/szymon-holownia-w-debacie-tvp-kosiniak-kamysz-nieobecny/07trj0d](https://businessinsider.com.pl/wiadomosci/szymon-holownia-w-debacie-tvp-kosiniak-kamysz-nieobecny/07trj0d)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T10:04:42+00:00

Szymon Hołownia zadeklarował udział w debacie TVP. Będzie reprezentantem Trzeciej Drogi, a informację tę przekazał Władysław Kosiniak-Kamysz.

## Dawali bezdomnym 4 tys. zł miesięcznie. Zaskakujące wyniki eksperymentu
 - [https://businessinsider.com.pl/wiadomosci/dawali-bezdomnym-4-tys-zl-miesiecznie-zaskakujace-wyniki-eksperymentu/k9d31cd](https://businessinsider.com.pl/wiadomosci/dawali-bezdomnym-4-tys-zl-miesiecznie-zaskakujace-wyniki-eksperymentu/k9d31cd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:55:54+00:00

W Denver przeprowadzono eksperyment. Część bezdomnych mieszkańców otrzymało 1000 dol. miesięcznie. Wnioski? Problem bezdomności się zmniejszył, za to zatrudnienie w pełnym wymiarze godzin wzrosło.

## Morawiecki stanie do debaty z Tuskiem w TVP. "Widzimy się w telewizji"
 - [https://businessinsider.com.pl/wiadomosci/morawiecki-vs-tusk-premier-z-pis-podejmuje-wyzwanie-w-debacie-tvp/dfy9x7g](https://businessinsider.com.pl/wiadomosci/morawiecki-vs-tusk-premier-z-pis-podejmuje-wyzwanie-w-debacie-tvp/dfy9x7g)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:49:20+00:00

Premier Mateusz Morawiecki zadeklarował swoje uczestnictwo w nadchodzącej debacie przedwyborczej w TVP, reprezentując komitet PiS.

## Oto scenariusz dla stóp procentowych w Polsce. Członkini RPP przemówiła
 - [https://businessinsider.com.pl/gospodarka/oto-scenariusz-dla-stop-procentowych-w-polsce-czlonkini-rpp-przemowila/k3c6l7c](https://businessinsider.com.pl/gospodarka/oto-scenariusz-dla-stop-procentowych-w-polsce-czlonkini-rpp-przemowila/k3c6l7c)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:37:34+00:00

Wygląda na to, że Rada Polityki Pieniężnej rozpoczęła cykl i ostatnie obniżki nie były tylko jednorazowym dostosowaniem kosztu pieniądza. — Wydaje się, że trend obniżania stóp będzie utrzymywany, ale nie można obecnie powiedzieć, czy będzie to po 0,25 pkt proc., czy więcej — wynika z wypowiedzi Gabrieli Masłowskiej w Radiu Lublin. Członkini RPP zapowiada spadek inflacji.

## Pokojowa Nagroda Nobla 2023. Jednak nie Zełenski
 - [https://businessinsider.com.pl/wiadomosci/pokojowa-nagroda-nobla-2023-jednak-nie-zelenski/6z7857h](https://businessinsider.com.pl/wiadomosci/pokojowa-nagroda-nobla-2023-jednak-nie-zelenski/6z7857h)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:21:32+00:00

Irańska obrończyni praw kobiet Narges Mohammadi została laureatką Pokojowej Nagrody Nobla - ogłosił Norweski Komitet Noblowski.

## "Bizancjum". NIK przedstawia raport o finansowaniu TVP
 - [https://businessinsider.com.pl/gospodarka/nik-przedstawia-raport-o-finansowaniu-tvp/mdq9zm6](https://businessinsider.com.pl/gospodarka/nik-przedstawia-raport-o-finansowaniu-tvp/mdq9zm6)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:15:06+00:00

Naruszenie zasad legalności, rzetelności, celowości lub gospodarności stwierdziła w wydatkach Telewizji Polskiej SA Najwyższa Izba Kontroli. "Wyniki kontroli są zatrważające", powiedział prezes NIK Marian Banaś.

## Globalna awaria popularnej aplikacji. Firmy mogą mieć kłopoty
 - [https://businessinsider.com.pl/technologie/globalna-awaria-slacka-firmy-moga-miec-klopoty/b8zkjrx](https://businessinsider.com.pl/technologie/globalna-awaria-slacka-firmy-moga-miec-klopoty/b8zkjrx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T09:07:37+00:00

W piątek przed południem internauci z całego świata zaczęli zgłaszać problemy z funkcjonowaniem aplikacji Slack. To popularny komunikator używany m.in. w korporacjach.

## Paliw brakuje już nie tylko na Orlenie. Miejska spółka ma problem z wywożeniem śmieci
 - [https://businessinsider.com.pl/wiadomosci/paliw-brakuje-juz-nie-tylko-na-orlenie-miejska-spolka-ma-problem-z-wywozeniem-smieci/e1efbtn](https://businessinsider.com.pl/wiadomosci/paliw-brakuje-juz-nie-tylko-na-orlenie-miejska-spolka-ma-problem-z-wywozeniem-smieci/e1efbtn)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T08:35:16+00:00

"W związku z brakiem paliwa ON na stacjach mogą wystąpić opóźnienia w odbiorze odpadów. Prosimy o cierpliwość i zrozumienie" — z takim komunikatem zwróciło się do mieszkańców Przedsiębiorstwo Gospodarki Komunalnej w Wołowie na Dolnym Śląsku. Od mieszkańca tego miasta otrzymaliśmy też zdjęcia z lokalnej stacji paliw MOL.

## Akcje Allegro znowu licytowane. Nerwowa reakcja inwestorów na giełdzie
 - [https://businessinsider.com.pl/gielda/wiadomosci/czolowi-akcjonariusze-wycofuja-z-allegro-kolejna-miliardowa-transakcja/z8yv3e5](https://businessinsider.com.pl/gielda/wiadomosci/czolowi-akcjonariusze-wycofuja-z-allegro-kolejna-miliardowa-transakcja/z8yv3e5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T08:32:19+00:00

Duzi akcjonariusze Allegro kolejny raz wystawili na sprzedaż spore pakiety akcji tej e-commercowej spółki. Tym razem chodzi o transakcję wartą potencjalnie blisko 1,22 mld zł. Rynek, jak często bywa w takich sytuacjach, zareagował spadkiem notowań.

## 5 błędów w CV które sprawiają, że rekruter nie dzwoni
 - [https://businessinsider.com.pl/poradnik-finansowy/5-bledow-w-cv-ktore-sprawiaja-ze-rekruter-nie-dzwoni/e1q9x5w](https://businessinsider.com.pl/poradnik-finansowy/5-bledow-w-cv-ktore-sprawiaja-ze-rekruter-nie-dzwoni/e1q9x5w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T08:27:17+00:00

Choć bezrobocie jest dziś niskie, wciąż wielu kandydatów narzeka, że rekruterzy ich ignorują i nawet nie reagują na ich aplikacje. Gdzie leży przyczyna? Amerykański serwis forbes.com opisuje pięć podstawowych błędów przy pisaniu CV. To one mogą być przyczyną tego, że wciąż nie możemy dostać zaproszenia na rozmowę kwalifikacyjną.

## Ile można zyskać i stracić na obniżkach stóp procentowych. Oto wyliczenia
 - [https://businessinsider.com.pl/poradnik-finansowy/kredyty/ile-mozna-zyskac-i-stracic-na-obnizkach-stop-procentowych-oto-wyliczenia/d4tvym5](https://businessinsider.com.pl/poradnik-finansowy/kredyty/ile-mozna-zyskac-i-stracic-na-obnizkach-stop-procentowych-oto-wyliczenia/d4tvym5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:51:01+00:00

Spadek stóp procentowych z jednej strony oznacza niższe raty kredytów, ale z drugiej także mniejsze oprocentowanie depozytów. O tym, kiedy kredytobiorcy odczują spadek stóp, decydować będzie moment, kiedy banki aktualizują oprocentowanie. Część klientów obniżkę zobaczy już teraz, ale niektórzy dopiero za parę miesięcy.

## Międzynarodowy skandal po meczu Legii. Interweniują polskie władze
 - [https://businessinsider.com.pl/wiadomosci/miedzynarodowy-skandal-po-meczu-legii-interweniuja-polskie-wladze/s9d5c66](https://businessinsider.com.pl/wiadomosci/miedzynarodowy-skandal-po-meczu-legii-interweniuja-polskie-wladze/s9d5c66)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:31:28+00:00

Porażką na boisku 0:1 i skandalem poza boiskiem zakończyło się wyjazdowe spotkanie Legii Warszawa z AZ Alkmaar w Lidze Konferencji. Dwóch piłkarzy polskiego klubu — Portugalczyk Josue i Serb Radovan Pankov — zostało przez holenderską policję wyprowadzonych z autokaru i przewiezionych na komisariat. Poturbowany został też biznesmen Dariusz Mioduski, który jest właścicielem Legii. W sprawę włączyły się polskie władze na czele z premierem Mateuszem Morawieckim.

## ZUS włączył się w kampanię wyborczą? Wysyła maile do Polaków
 - [https://businessinsider.com.pl/wiadomosci/zus-wysyla-pisma-do-polakow-tuz-przed-wyborami-standardowa-procedura/s98xdmj](https://businessinsider.com.pl/wiadomosci/zus-wysyla-pisma-do-polakow-tuz-przed-wyborami-standardowa-procedura/s98xdmj)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:14:11+00:00

Chociaż kwota świadczenia 500 plus ma wzrosnąć dopiero od stycznia 2024 r., ZUS właśnie teraz, na krótko przed wyborami parlamentarnymi, wysyła do milionów Polaków listy ze stosowną informacją. Jako pierwszy pod pismem widnieje podpis premiera Mateusza Morawieckiego.

## Kurs dolara 6 października poniżej 4,4 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-6-pazdziernika-2023/bjwte5w](https://businessinsider.com.pl/gielda/kursy-walut/kurs-dolara-usdpln-notowania-walut-6-pazdziernika-2023/bjwte5w)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:12:31+00:00

Kurs dolara poniżej 4,4 zł. W piątek rano 6 października 2023 r. rano kurs USD/PLN wynosi 4,3654.

## Kurs franka 6 października poniżej 4,8 zł
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-6-pazdziernika-2023/cv9shzp](https://businessinsider.com.pl/gielda/kursy-walut/kurs-franka-frank-szwajcarski-chfpln-6-pazdziernika-2023/cv9shzp)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:09:49+00:00

Frank szwajcarski poniżej 4,8 zł. W piątek rano 6 października 2023 r. kurs tej waluty wobec polskiego złotego wynosi 4,7766.

## 5-drzwiowe MINI Cooper Hatch - kultowy styl, praktyczne podejście
 - [https://businessinsider.com.pl/technologie/motoryzacja/5-drzwiowe-mini-cooper-hatch-kultowy-styl-praktyczne-podejscie/ylyptpl](https://businessinsider.com.pl/technologie/motoryzacja/5-drzwiowe-mini-cooper-hatch-kultowy-styl-praktyczne-podejscie/ylyptpl)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T07:00:00+00:00

MINI Cooper Hatch stanowi zręczne połączenie kultowego stylu z uniwersalnością, która przekłada się na łatwiejsze funkcjonowanie w życiu codziennym. Samo auto jest kompaktowe, jednak zalety podróżowania nim są ogromne. Jak tego dokonano?

## Rosja zdecydowała. Dobre wieści dla kierowców
 - [https://businessinsider.com.pl/gospodarka/rzad-rosji-zezwoli-na-powrot-eksportu-oleju-napedowego/rlcy824](https://businessinsider.com.pl/gospodarka/rzad-rosji-zezwoli-na-powrot-eksportu-oleju-napedowego/rlcy824)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T06:38:27+00:00

Rząd Rosji zezwoli na powrót eksportu oleju napędowego. To nagła zmiana polityki Kremla, wprowadzona raptem kilka tygodni po wprowadzeniu zakazu – podaje Bloomberg. To oznacza, że ceny w Europie powinny spadać.

## Niemcy nagle przestali kupować elektryki
 - [https://businessinsider.com.pl/gospodarka/niemcy-nagle-przestali-kupowac-elektryki-oto-powod/zsby46s](https://businessinsider.com.pl/gospodarka/niemcy-nagle-przestali-kupowac-elektryki-oto-powod/zsby46s)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T06:27:16+00:00

Z rządowych danych wynika, że we wrześniu na niemieckie ulice wyjechało 31 tys. nowych aut elektrycznych. To gigantyczny spadek, ale eksperci się tego spodziewali.

## LOT szykuje 20 nowych kierunków. Dokąd poleci polski przewoźnik?
 - [https://businessinsider.com.pl/wiadomosci/lot-szykuje-20-nowych-kierunkow-dokad-poleci-polski-przewoznik/dzx8mvm](https://businessinsider.com.pl/wiadomosci/lot-szykuje-20-nowych-kierunkow-dokad-poleci-polski-przewoznik/dzx8mvm)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T06:18:15+00:00

Spółka PLL LOT przedstawiła strategię na lata 2024-2028. Dla pasażerów najistotniejsze będzie zapewne 20 nowych kierunków. Polski przewoźnik stawia na dalekie trasy i potrzebuje do tego nowych samolotów.

## Holecka jest milionerką dzięki TVP. Onet dotarł do umów
 - [https://businessinsider.com.pl/gospodarka/holecka-jest-milionerka-dzieki-tvp-onet-dotarl-do-umow/dxtdvmf](https://businessinsider.com.pl/gospodarka/holecka-jest-milionerka-dzieki-tvp-onet-dotarl-do-umow/dxtdvmf)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:55:20+00:00

Onet poznał zapisy umów czworga prowadzących "Wiadomości" TVP. Z informacji Andrzeja Stankiewicz wynika, że najbardziej znani pracownicy stacji stali się milionerami za rządów PiS.

## Granaty, alkohol i narkotyki, czyli Putin o katastrofie samolotu Prigożyna
 - [https://businessinsider.com.pl/wiadomosci/kto-stoi-za-smiercia-prigozyna-putin-podsumowal-sledztwo-w-sprawie-wypadku/8t6rnb5](https://businessinsider.com.pl/wiadomosci/kto-stoi-za-smiercia-prigozyna-putin-podsumowal-sledztwo-w-sprawie-wypadku/8t6rnb5)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:40:09+00:00

Władimir Putin powiedział, że śledztwo w sprawie katastrofy lotniczej, w której w sierpniu zginął Jewgienij Prigożyn, ujawniło "brak wpływu zewnętrznego" — podaje "Financial Times". Rosyjski przywódca zasugerował też, że wagnerowcy sami mogli być winni katastrofy samolotu.

## Znana sieć handlowa zapewnia, że jednak nie wyjdzie z Polski
 - [https://businessinsider.com.pl/gospodarka/znana-siec-handlowa-zapewnia-ze-jednak-nie-wyjdzie-z-polski/znxg1qv](https://businessinsider.com.pl/gospodarka/znana-siec-handlowa-zapewnia-ze-jednak-nie-wyjdzie-z-polski/znxg1qv)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:35:55+00:00

Niedawno Grupa Spar komunikowała, że "podjęła kroki w kierunku sprzedaży swoich aktywów w Polsce". Teraz jest nowy komunikat i okazuje się, że sieć zapewnia, że nie chce znikać z naszego kraju.

## To koniec legendarnej galerii handlowej w sercu Berlina
 - [https://businessinsider.com.pl/gospodarka/to-koniec-legendarnej-galerii-handlowej-w-sercu-berlina/ecwltgx](https://businessinsider.com.pl/gospodarka/to-koniec-legendarnej-galerii-handlowej-w-sercu-berlina/ecwltgx)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:22:55+00:00

To był jeden z najbardziej luksusowych domów towarowych w Berlinie. Słynna galeria wyniesie się jednak z miasta do końca przyszłego roku. Wiele wskazuje na to, że w jej miejsce otworzy się biblioteka.

## Wrze w Poczcie Polskiej. Spotkanie ostatniej szansy albo strajk
 - [https://businessinsider.com.pl/wiadomosci/wrze-w-poczcie-polskiej-spotkanie-ostatniej-szansy-albo-strajk/d1x8517](https://businessinsider.com.pl/wiadomosci/wrze-w-poczcie-polskiej-spotkanie-ostatniej-szansy-albo-strajk/d1x8517)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:22:13+00:00

Jeśli w poniedziałek nie uda się osiągnąć porozumienia między szefostwem Poczty Polskiej a związkowcami, pracownicy państwowej spółki mają zastrajkować. I stanie się to jeszcze przed wyborami.

## Światowy rynek paliw wygląda coraz dziwniej, diesel w jeden dzień potaniał o 6 proc.
 - [https://businessinsider.com.pl/gospodarka/swiatowy-rynek-paliw-wyglada-coraz-dziwniej-diesel-w-jeden-dzien-potanial-o-6-proc/rcn7nm1](https://businessinsider.com.pl/gospodarka/swiatowy-rynek-paliw-wyglada-coraz-dziwniej-diesel-w-jeden-dzien-potanial-o-6-proc/rcn7nm1)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:11:25+00:00

Ceny diesla na świecie spadły jednego dnia o ponad 6 proc., wyraźnie tanieje też ropa naftowa, a rynek ma problem z odpowiedzią na pytanie: dlaczego tak nagle? Prezes NBP zapowiada spadki inflacji, ale z jego słów wynika też, że ceny w Polsce znowu rosną. Zapowiedział ponadto, że bank centralny nie będzie skupował w przyszłym roku rządowych obligacji z rynku. Jakość rządów w Polsce jest zdaniem Banku Światowego gorsza niż dwa lata temu, natomiast w Rosji za dolara trzeba płacić już ponad sto rubli. Oto pięć najciekawszych wydarzeń w gospodarce teraz.

## Polacy zaciskają pasa, te sklepy mają problem
 - [https://businessinsider.com.pl/gospodarka/polacy-zaciskaja-pasa-te-sklepy-maja-problem/tzs3h1b](https://businessinsider.com.pl/gospodarka/polacy-zaciskaja-pasa-te-sklepy-maja-problem/tzs3h1b)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:09:19+00:00

W niełatwych gospodarczo czasach klienci szukają oszczędności – a na dodatek "duże" zakupy coraz częściej przenoszą się do sieci. Tracą tradycyjne sklepy.

## Kurs EUR/PLN 6 października 2023 r.
 - [https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-6-pazdziernika-2023-r/n97n3dd](https://businessinsider.com.pl/gielda/kursy-walut/kurs-eurpln-6-pazdziernika-2023-r/n97n3dd)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T05:00:01+00:00

Przedstawiamy bieżące notowania kursu waluty EUR oraz zmiany w ujęciu tygodniowym i dzień po dniu na 6 października 2023. Pokazujemy, jak zmienia się kurs euro w stosunku do polskiego złotego. Czy nasza waluta obecnie traci? Wczoraj kurs EUR wynosił: 4,60225 zł. Wszystkiego dowiesz się z poniższego artykułu.

## Wars już nie chce być tylko od wagonów. Postawi na wesela
 - [https://businessinsider.com.pl/gospodarka/wars-juz-nie-chce-byc-tylko-od-wagonow-gastronomicznych/mzg7e5n](https://businessinsider.com.pl/gospodarka/wars-juz-nie-chce-byc-tylko-od-wagonow-gastronomicznych/mzg7e5n)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:50:11+00:00

Głównym celem spółki Wars jest "rozwój gastronomii kolejowej", jak przekazuje Grzegorz Bębenek, główny specjalista ds. marketingu w spółce. Ale firma chce też spróbować swoich sił m.in. w cateringu biznesowym oraz w weselach.

## Dla biznesu estoński CIT to jedno z najatrakcyjniejszych rozwiązań. Jakie są alternatywy?
 - [https://businessinsider.com.pl/prawo/podatki/estonski-cit-to-atrakcyjna-forma-opodatkowania-spolek-co-od-niej-odstrasza/mjj2r39](https://businessinsider.com.pl/prawo/podatki/estonski-cit-to-atrakcyjna-forma-opodatkowania-spolek-co-od-niej-odstrasza/mjj2r39)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:44:24+00:00

Estoński CIT to duże korzyści podatkowe. Ministerstwo Finansów zapowiadało, że będzie z niego korzystało 200 tys. firm, ale na razie wybiera go niewielki odsetek. Zobacz, co odstrasza od estońskiego CIT i jakie są konkurencyjne rozwiązania podatkowe dla spółek.

## Izery jeszcze nie ma, ale będzie jeździła na minuty
 - [https://businessinsider.com.pl/gospodarka/izery-jeszcze-nie-ma-ale-bedzie-jezdzila-na-minuty/nbj6hbq](https://businessinsider.com.pl/gospodarka/izery-jeszcze-nie-ma-ale-bedzie-jezdzila-na-minuty/nbj6hbq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:37:06+00:00

Pojazdów Izera wciąż nie ma na naszych drogach – i nie wiadomo, kiedy się pojawią oraz czy w ogóle tak się stanie. Niemniej zarządzająca projektem spółka ma nową umowę, z jednym z liderów carsharingu.

## Te pociski od USA mogą powstrzymać rosyjskie helikoptery. Nie załatwią jednak sprawy za Ukraińców
 - [https://businessinsider.com.pl/wiadomosci/rosjanie-moga-zaczac-sie-obawiac-nowa-bron-dla-kijowa-z-usa/5rn273m](https://businessinsider.com.pl/wiadomosci/rosjanie-moga-zaczac-sie-obawiac-nowa-bron-dla-kijowa-z-usa/5rn273m)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:30:32+00:00

Stany Zjednoczone najprawdopodobniej wyślą Ukrainie system rakietowy MGM-140 Army Tactical Missile System obejmujący pociski balistyczne krótkiego zasięgu, na które Kijów od dawna czeka. ATACMS ma większy zasięg niż inne ukraińskie pociski rakietowe, co pozwoliłoby mu niszczyć cenne rosyjskie cele. Eksperci twierdzą jednak, że jego skuteczne wykorzystanie będzie wymagało dokładnych danych wywiadowczych i precyzyjnego celowania.

## Pan D’Hondt zdecyduje o wyborach. To on podzieli mandaty. Pokazujemy jak
 - [https://businessinsider.com.pl/prawo/opinie/jak-metoda-dhondta-wplywa-na-wyniki-wyborow/j1gtpnb](https://businessinsider.com.pl/prawo/opinie/jak-metoda-dhondta-wplywa-na-wyniki-wyborow/j1gtpnb)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:25:00+00:00

W systemie D’Hondta nie ma żadnej nadzwyczajnej premii dla zwycięzcy, a nawoływanie do głosowania na najsilniejszą partię w obozie opozycji grozi osunięciem się którejś z mniejszych partii pod próg wyborczy. To oznacza dla niej wyborczą klęskę. Widać, że doskonale rozumie to Donald Tusk. Jak działa system D’Hondta, wyjaśnia Andrzej Machowski, analityk badań sondażowych.

## Kancelaria Mateusza Morawieckiego niczym TVP. Tego jeszcze nie było
 - [https://businessinsider.com.pl/wiadomosci/kancelaria-mateusza-morawieckiego-niczym-tvp/d7h3ltq](https://businessinsider.com.pl/wiadomosci/kancelaria-mateusza-morawieckiego-niczym-tvp/d7h3ltq)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:16:28+00:00

Po raz pierwszy w historii roczny budżet Kancelarii Premiera ma przebić barierę 2 mld zł – podaje "Rzeczpospolita". Opozycja jest oburzona.

## Po spotkaniu z Putinem, Kim Dzong Un zaczął wysyłać artylerię do Rosji
 - [https://businessinsider.com.pl/wiadomosci/kim-dzong-un-zaczal-wysylac-artylerie-do-rosji/1mpf658](https://businessinsider.com.pl/wiadomosci/kim-dzong-un-zaczal-wysylac-artylerie-do-rosji/1mpf658)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:06:09+00:00

Korea Północna zaczęła wysyłać artylerię do atakującej Ukrainę Rosji – podaje CBS News, powołując się na anonimowe źródło rządowe w USA. Amerykańska stacja wiąże to z niedawnym spotkaniem Kim Dzong Una i Władimira Putina.

## Tu PiS ma 88 proc., a KO nie ma nawet jednego. Oto bastiony największych partii [MAPA]
 - [https://businessinsider.com.pl/wiadomosci/oto-najbardziej-pisowskie-i-platformerskie-gminy/r30jkty](https://businessinsider.com.pl/wiadomosci/oto-najbardziej-pisowskie-i-platformerskie-gminy/r30jkty)
 - RSS feed: https://businessinsider.com.pl/.feed
 - date published: 2023-10-06T04:05:00+00:00

Obecna kampania jest wyjątkowo emocjonująca – choć wybory są za pasem, wciąż nie możemy być pewni wyniku. Są natomiast w Polsce miejsca, gdzie już można wskazać wygranych. Pozostaje tylko pytanie, jak bardzo PiS czy PO rozgromią tam swoich rywali. Oto najbardziej "pisowskie" i "platformerskie" gminy w Polsce, które ustaliliśmy na podstawie sejmowych wyborów w 2019 r.

