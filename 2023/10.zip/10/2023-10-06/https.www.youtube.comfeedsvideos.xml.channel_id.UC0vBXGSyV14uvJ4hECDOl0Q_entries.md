# Source:Techquickie, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q, language:en-US

## Is Your Indoor Camera Watching You?
 - [https://www.youtube.com/watch?v=aSMGKPJkNpk](https://www.youtube.com/watch?v=aSMGKPJkNpk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC0vBXGSyV14uvJ4hECDOl0Q
 - date published: 2023-10-06T19:25:41+00:00

Remove your personal information from the web at http://joindeleteme.com/techquickie and use code Techquickie for 20% off.

Thanks to Troy Hunt for his help with this video!

How can you minimize the risk that a hacker ends up watching you through your indoor smart camera?

Leave a reply with your requests for future episodes.

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners

FOLLOW US ELSEWHERE
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
Twitch: https://www.twitch.tv/linustech

