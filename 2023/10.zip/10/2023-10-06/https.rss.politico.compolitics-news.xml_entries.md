# Source:Politico, URL:https://rss.politico.com/politics-news.xml, language:en-US

## Iowa police dispute Ramaswamy campaign's claim that protesters rammed their car
 - [https://www.politico.com/news/2023/10/06/vivek-ramaswamy-iowa-car-00120318](https://www.politico.com/news/2023/10/06/vivek-ramaswamy-iowa-car-00120318)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-10-06T06:49:54+00:00

"Our investigation has revealed no evidence to substantiate" the claim that protesters hit Ramaswamy's car on purpose and fled, police said.

## How to fight a president, please a billionaire and save a newspaper
 - [https://www.politico.com/news/2023/10/06/pbdd-marty-baron-bezos-trump-00120192](https://www.politico.com/news/2023/10/06/pbdd-marty-baron-bezos-trump-00120192)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-10-06T04:00:00+00:00

Marty Baron, longtime editor of The Washington Post, spills the tea on what actually happened between owner Jeff Bezos and former President Donald Trump; what the media should be doing to earn your trust; and whether billionaires like Bezos are secretly pulling the strings behind closed doors.

## The nation’s cartoonists on the week in politics
 - [https://www.politico.com/gallery/2023/10/06/the-nations-cartoonists-on-the-week-in-politics-00120137](https://www.politico.com/gallery/2023/10/06/the-nations-cartoonists-on-the-week-in-politics-00120137)
 - RSS feed: https://rss.politico.com/politics-news.xml
 - date published: 2023-10-06T04:00:00+00:00

Every week political cartoonists throughout the country and across the political spectrum apply their ink-stained skills to capture the foibles, memes, hypocrisies and other head-slapping events in the world of politics. The fruits of these labors are hundreds of cartoons that entertain and enrage readers of all political stripes. Here's an offering of the best of this week's crop, picked fresh off the Toonosphere. Edited by Matt Wuerker.

