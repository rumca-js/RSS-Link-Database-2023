# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index, language:en-US

## Jury awards $229M to victims of “Real Water” tainted with rocket fuel chemical
 - [https://arstechnica.com/?p=1974240](https://arstechnica.com/?p=1974240)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T22:41:59+00:00

An expert witness testified hydrazine was likely formed during an electrolysis process.

## A live-action Cyberpunk 2077 adaptation has been announced
 - [https://arstechnica.com/?p=1974195](https://arstechnica.com/?p=1974195)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T21:48:25+00:00

We're betting it'll rake in a few eddies.

## HP wireless all-in-one has 83 Wh rechargeable battery, handle for portability
 - [https://arstechnica.com/?p=1974095](https://arstechnica.com/?p=1974095)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T20:32:27+00:00

A 24-inch Windows PC weighing 9 pounds.

## It cost $120M for Cyberpunk 2077 patches and DLC to fix the game’s image
 - [https://arstechnica.com/?p=1973983](https://arstechnica.com/?p=1973983)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T19:21:16+00:00

Moving to Unreal Engine, and splitting dev sites, seems like a wise plan.

## Visually stunning The Creator is a rare piece of original sci-fi filmmaking
 - [https://arstechnica.com/?p=1973729](https://arstechnica.com/?p=1973729)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T18:55:44+00:00

Ars chats with director of photography Oren Soffer about the making of the sci-fi film.

## The Heybike Tyson e-bike is janky, fun, and sometimes dangerous
 - [https://arstechnica.com/?p=1973956](https://arstechnica.com/?p=1973956)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T18:28:40+00:00

This foldable e-bike looks the part but is tough to recommend.

## Zombie star’s strange behavior ascribed to what it’s eating
 - [https://arstechnica.com/?p=1973620](https://arstechnica.com/?p=1973620)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T18:02:43+00:00

Neutron star winds, an accretion disk, and jets combine for complex interactions.

## It’s time to toss the dice as The Wheel of Time’s second season concludes
 - [https://arstechnica.com/?p=1973495](https://arstechnica.com/?p=1973495)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T18:00:38+00:00

Recap: The season ends with fire and spectacle, but some expectations are subverted.

## Amazon’s first two Internet satellites will launch into orbit today
 - [https://arstechnica.com/?p=1973955](https://arstechnica.com/?p=1973955)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T17:30:47+00:00

Amazon really doesn't want to show anyone what its satellites look like.

## Getty Images built a “socially responsible” AI tool that rewards artists
 - [https://arstechnica.com/?p=1973987](https://arstechnica.com/?p=1973987)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T17:11:42+00:00

Getty Images CEO: AI makers that don’t pay artists create “a sad world.”

## Musk refused to testify in Twitter stock probe, claimed SEC is harassing him
 - [https://arstechnica.com/?p=1973958](https://arstechnica.com/?p=1973958)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T16:38:17+00:00

After being sued by SEC, Musk says he wants US regulators to be punished.

## Valve’s leaked Steam Deck “Model 1030” probably isn’t a full “Version 2.0”
 - [https://arstechnica.com/?p=1973923](https://arstechnica.com/?p=1973923)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T15:40:21+00:00

Extra portable pixel-pushing power from Valve is still likely a few years off.

## AI firms working on “constitutions” to keep AI from spewing toxic content
 - [https://arstechnica.com/?p=1973907](https://arstechnica.com/?p=1973907)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T13:42:56+00:00

Broken guardrails for AI systems lead to push for new safety measures .

## Long gone, DEC is still powering the world of computing
 - [https://arstechnica.com/?p=1967053](https://arstechnica.com/?p=1967053)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T11:30:32+00:00

One of the early pioneers in computing, the company disappeared in the late 1990s.

## Rocket Report: NASA to test new RS-25 engines; Russia’s phantom rockets
 - [https://arstechnica.com/?p=1973490](https://arstechnica.com/?p=1973490)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T11:00:21+00:00

"Really it was more of a timeline and uncertainty shrinker, if you will."

## Dealmaster: Deals from Apple and Sony ahead of Amazon’s big event
 - [https://arstechnica.com/?p=1973594](https://arstechnica.com/?p=1973594)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index
 - date published: 2023-10-06T00:03:30+00:00

Get some major deals just ahead of Amazon's next Prime Day sales event.

