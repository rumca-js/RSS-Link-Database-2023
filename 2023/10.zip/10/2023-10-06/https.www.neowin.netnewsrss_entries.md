# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Amazon Luna now allows users to buy games directly, but only if they are Ubisoft games
 - [https://www.neowin.net/news/amazon-luna-now-allows-users-to-buy-games-directly-but-only-if-they-are-ubisoft-games/](https://www.neowin.net/news/amazon-luna-now-allows-users-to-buy-games-directly-but-only-if-they-are-ubisoft-games/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T21:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696623927_1_a0-c5nbkf-fgktgziz70sg_medium.jpg" /></div>You can now purchase Ubisoft games directly from the Amazon Luna cloud gaming service by using your Amazon account and linking it to your Ubisoft account. You can also play that game on the PC offline <a href="https://www.neowin.net/news/amazon-luna-now-allows-users-to-buy-games-directly-but-only-if-they-are-ubisoft-games">Read more...</a>

## Surface Studio 2+ and Pro 8 get new firmware with network and system stability improvements
 - [https://www.neowin.net/news/surface-studio-2-and-pro-8-get-new-firmware-with-network-and-system-stability-improvements/](https://www.neowin.net/news/surface-studio-2-and-pro-8-get-new-firmware-with-network-and-system-stability-improvements/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T19:28:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/10/1665402043_surface_studio_2_plus_medium.jpg" /></div>Microsoft is rolling out new firmware for the Surface Pro 8 and Studio 2+. The October 2023 update improves system stability, Wi-Fi, and Bluetooth connections. It also resolves security issues. <a href="https://www.neowin.net/news/surface-studio-2-and-pro-8-get-new-firmware-with-network-and-system-stability-improvements">Read more...</a>

## Speculations reveal Spotify could provide lossless audio on a new service for $19.99/month
 - [https://www.neowin.net/news/speculations-reveal-spotify-could-provide-lossless-audio-on-a-new-service-for-1999month/](https://www.neowin.net/news/speculations-reveal-spotify-could-provide-lossless-audio-on-a-new-service-for-1999month/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T18:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/07/1595942809_spotify_logo_2_medium.jpg" /></div>Spotify may finally provide users with the long-awaited lossless audio streaming capability. Recent rumors reveal new features, longer listening times, advanced mixing tools, and more on Spotify. <a href="https://www.neowin.net/news/speculations-reveal-spotify-could-provide-lossless-audio-on-a-new-service-for-1999month">Read more...</a>

## Windows Server vNext build 259567 for Windows Insiders is now available
 - [https://www.neowin.net/news/windows-server-vnext-build-259567-for-windows-insiders-is-now-available/](https://www.neowin.net/news/windows-server-vnext-build-259567-for-windows-insiders-is-now-available/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T18:16:08+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/09/1599088855_windows_server_vnext_insider_preview_2_medium.jpg" /></div>The new Windows Server vNext build 25967 for Windows Insiders is now available to download, but the change log for the new build is nearly the same as the previous Insider Windows Server release. <a href="https://www.neowin.net/news/windows-server-vnext-build-259567-for-windows-insiders-is-now-available">Read more...</a>

## Price Drop! Microsoft Windows 11 Professional (3 devices) for only $29.97
 - [https://www.neowin.net/deals/price-drop-microsoft-windows-11-professional-3-devices-for-only-2997/](https://www.neowin.net/deals/price-drop-microsoft-windows-11-professional-3-devices-for-only-2997/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T18:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/06/1686147138_img_0095_medium.jpg" /></div>Today&#039;s highlighted Neowin Deal lets you upgrade your Windows OS and enjoy a more enhanced UI, better multitasking, and improved security for a fraction of the normal cost. Save $169 today! <a href="https://www.neowin.net/deals/price-drop-microsoft-windows-11-professional-3-devices-for-only-2997">Read more...</a>

## Redfall finally adds its 60fps Performance Mode for Xbox Series X|S with its 1.2 patch
 - [https://www.neowin.net/news/redfall-finally-adds-its-60fps-performance-mode-for-xbox-series-xs-with-its-12-patch/](https://www.neowin.net/news/redfall-finally-adds-its-60fps-performance-mode-for-xbox-series-xs-with-its-12-patch/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T17:38:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696612619_redfall-12_medium.jpg" /></div>Developer Arkane Austin and publisher Bethesda Softworks have released the 1.2 patch for its vampire shooter Redfall, adding the much-promised 60fps Performance Mode for Xbox Series X|S consoles. <a href="https://www.neowin.net/news/redfall-finally-adds-its-60fps-performance-mode-for-xbox-series-xs-with-its-12-patch">Read more...</a>

## A new report denies rumors of a subscription-based Windows 12
 - [https://www.neowin.net/news/a-new-report-denies-rumors-of-a-subscription-based-windows-12/](https://www.neowin.net/news/a-new-report-denies-rumors-of-a-subscription-based-windows-12/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T16:07:18+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696607944_windows_12_medium.jpg" /></div>A new report sheds some light on the recent discovery of a potential subscription-based Windows &quot;12.&quot; Turns out, those bits are linked to one of Windows 11&#039;s SKUs, not the next-gen Windows. <a href="https://www.neowin.net/news/a-new-report-denies-rumors-of-a-subscription-based-windows-12">Read more...</a>

## Download the "Mastering Linux Security and Hardening" eBook (worth $36) for free
 - [https://www.neowin.net/sponsored/download-the-mastering-linux-security-and-hardening-ebook-worth-36-for-free/](https://www.neowin.net/sponsored/download-the-mastering-linux-security-and-hardening-ebook-worth-36-for-free/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T16:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696602422_packt-publishing_mastering-linux-security-and-hardening_medium.jpg" /></div>A comprehensive guide to mastering the art of preventing your Linux system from getting compromised. By the end of this new edition, you will confidently be able to set up a Linux server. <a href="https://www.neowin.net/sponsored/download-the-mastering-linux-security-and-hardening-ebook-worth-36-for-free">Read more...</a>

## The Microsoft Store site has a new look made with web components tools
 - [https://www.neowin.net/news/the-microsoft-store-site-has-a-new-look-made-with-web-components-tools/](https://www.neowin.net/news/the-microsoft-store-site-has-a-new-look-made-with-web-components-tools/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T15:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/06/1655478251_microsoft_store_logo_medium.jpg" /></div>A new look for the Microsoft Store website rolled out this week. Its development team used a wide variety of web component tools to create the new site, which more closely resembles the Windows 11 app <a href="https://www.neowin.net/news/the-microsoft-store-site-has-a-new-look-made-with-web-components-tools">Read more...</a>

## Battlefield 2042 Season 6 hands-on preview: A proper meat grinder map is finally here
 - [https://www.neowin.net/news/battlefield-2042-season-6-hands-on-preview-a-proper-meat-grinder-map-is-finally-here/](https://www.neowin.net/news/battlefield-2042-season-6-hands-on-preview-a-proper-meat-grinder-map-is-finally-here/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T15:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696597560_battlefield_2042_screenshot_2023.10.03_-_13.14.01.90_medium.jpg" /></div>The Redacted map for Battlefield 2042 is delivering the much-needed Operation Metro and Locker meat grinder experience to the shooter. Here&#039;s our thoughts on the new map and content of Season 6. <a href="https://www.neowin.net/news/battlefield-2042-season-6-hands-on-preview-a-proper-meat-grinder-map-is-finally-here">Read more...</a>

## Which? calls for broadband mid-contract price hike ban
 - [https://www.neowin.net/news/which-calls-for-broadband-mid-contract-price-hike-ban/](https://www.neowin.net/news/which-calls-for-broadband-mid-contract-price-hike-ban/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T14:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1682302118_unionjackbroadband_medium.jpg" /></div>Which? has called on the broadband regulator, Ofcom, to put a ban in place on mid-contract price rises. It said consumers will face steep price increases in 2024 just as they have in 2023. <a href="https://www.neowin.net/news/which-calls-for-broadband-mid-contract-price-hike-ban">Read more...</a>

## Get the new Razer Cobra Pro wireless gaming mouse for its biggest discount ever at Amazon
 - [https://www.neowin.net/deals/get-the-new-razer-cobra-pro-wireless-gaming-mouse-for-its-biggest-discount-ever-at-amazon/](https://www.neowin.net/deals/get-the-new-razer-cobra-pro-wireless-gaming-mouse-for-its-biggest-discount-ever-at-amazon/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T12:00:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696587862_razer-cobra-pro_medium.jpg" /></div>The Razer Cobra Pro wireless gaming mouse has a 30,000 DPI optical sensor, can last up to 170 hours on a single charge, and has 10 customizable controls. It currently is discounted to $89.94 <a href="https://www.neowin.net/deals/get-the-new-razer-cobra-pro-wireless-gaming-mouse-for-its-biggest-discount-ever-at-amazon">Read more...</a>

## Microsoft reportedly may close its Activision Blizzard purchase on Friday, October 13
 - [https://www.neowin.net/news/microsoft-reportedly-may-close-its-activision-blizzard-purchase-on-friday-october-13/](https://www.neowin.net/news/microsoft-reportedly-may-close-its-activision-blizzard-purchase-on-friday-october-13/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T11:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/03/1679079213_ms-bliz12_medium.jpg" /></div>A new report claims that Microsoft is planning to officially announce it has closed the deal to acquire Activision Blizzard on Friday, October 13, barring any last minute surprise from the UK CMA. <a href="https://www.neowin.net/news/microsoft-reportedly-may-close-its-activision-blizzard-purchase-on-friday-october-13">Read more...</a>

## Windows 11 gets sort of improved Quick Settings menu, here is how to enable it
 - [https://www.neowin.net/news/windows-11-gets-sort-of-improved-quick-settings-menu-here-is-how-to-enable-it/](https://www.neowin.net/news/windows-11-gets-sort-of-improved-quick-settings-menu-here-is-how-to-enable-it/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T10:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/12/1671191051_windows_11_(10)_medium.jpg" /></div>The recently released Windows 11 build 25967 introduces a slightly reworked Quick Settings section, allowing users to scroll it when using more than six buttons. Here is how to enable it.
 <a href="https://www.neowin.net/news/windows-11-gets-sort-of-improved-quick-settings-menu-here-is-how-to-enable-it">Read more...</a>

## Microsoft Excel for the web replaces Automate a Task button with Automate Work
 - [https://www.neowin.net/news/microsoft-excel-for-the-web-replaces-automate-a-task-button-with-automate-work/](https://www.neowin.net/news/microsoft-excel-for-the-web-replaces-automate-a-task-button-with-automate-work/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T10:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/02/1613555356_product_37970_product_shots1_medium.jpg" /></div>The new Automate Work button in Microsoft Excel for the web will help its users by offering a number of pre-built templates that can help speed up certain workflows and tasks with Power Automate. <a href="https://www.neowin.net/news/microsoft-excel-for-the-web-replaces-automate-a-task-button-with-automate-work">Read more...</a>

## The Microsoft Mesh developer toolkit is now available in a public preview
 - [https://www.neowin.net/news/the-microsoft-mesh-developer-toolkit-is-now-available-in-a-public-preview/](https://www.neowin.net/news/the-microsoft-mesh-developer-toolkit-is-now-available-in-a-public-preview/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T09:42:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696577110_img2-scaled_medium.jpg" /></div>The Microsoft Mesh toolkit is now officially available as a public preview. Developers can download and use the Mesh toolkit to create unique 3D online meetings and collaborative experiences <a href="https://www.neowin.net/news/the-microsoft-mesh-developer-toolkit-is-now-available-in-a-public-preview">Read more...</a>

## Samsung bringing mobile driving licenses to Samsung Wallet
 - [https://www.neowin.net/news/samsung-bringing-mobile-driving-licenses-to-samsung-wallet/](https://www.neowin.net/news/samsung-bringing-mobile-driving-licenses-to-samsung-wallet/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T08:16:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696579508_samsung-wallet-sdc23-feature_medium.jpg" /></div>Driver&#039;s licenses and state ID&#039;s will be available in Samsung Wallet soon in a few US states. Samsung is working with IDEMIA to deliver the feature. The Korean firm will bring it to other states soon. <a href="https://www.neowin.net/news/samsung-bringing-mobile-driving-licenses-to-samsung-wallet">Read more...</a>

## Telltale Games confirms layoffs but claims all of its upcoming games are still in production
 - [https://www.neowin.net/news/telltale-games-confirms-layoffs-but-claims-all-of-its-upcoming-games-are-still-in-production/](https://www.neowin.net/news/telltale-games-confirms-layoffs-but-claims-all-of-its-upcoming-games-are-still-in-production/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T07:12:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/09/1537569074_telltalegames_medium.jpg" /></div>The episodic game developer and publisher has confirmed it has laid off some of its team members this week. It said that its upcoming projects, including The Wolf Among Us 2, are still in production. <a href="https://www.neowin.net/news/telltale-games-confirms-layoffs-but-claims-all-of-its-upcoming-games-are-still-in-production">Read more...</a>

## The new HP Envy Move all-in-one PC is designed to be transported easily
 - [https://www.neowin.net/news/the-new-hp-envy-move-all-in-one-pc-is-designed-to-be-transported-easily/](https://www.neowin.net/news/the-new-hp-envy-move-all-in-one-pc-is-designed-to-be-transported-easily/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T06:44:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/10/1696572693_hp-envy-move_medium.jpg" /></div>The HP Envy Move is a 23.8-inch all-in-one touchscreen PC that has a built-in handle and two kickstands that make it easy to transport it to different parts of the house, or even to work. <a href="https://www.neowin.net/news/the-new-hp-envy-move-all-in-one-pc-is-designed-to-be-transported-easily">Read more...</a>

## Apple held talks with DuckDuckGo about using its search engine instead of Google's
 - [https://www.neowin.net/news/apple-held-talks-with-duckduckgo-about-using-its-search-engine-instead-of-googles/](https://www.neowin.net/news/apple-held-talks-with-duckduckgo-about-using-its-search-engine-instead-of-googles/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T05:58:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/09/1632273495_duckduckgo-carbon-negative_medium.jpg" /></div>Newly revealed transcripts from the ongoing Google antitrust trial have revealed that DuckDuckGo had numerous discussions with Apple about using its search engine as the default for Apple products. <a href="https://www.neowin.net/news/apple-held-talks-with-duckduckgo-about-using-its-search-engine-instead-of-googles">Read more...</a>

## Samsung Galaxy S24 series may feature Titanium frames, like the iPhone 15
 - [https://www.neowin.net/news/samsung-galaxy-s24-series-may-feature-titanium-frames-like-the-iphone-15/](https://www.neowin.net/news/samsung-galaxy-s24-series-may-feature-titanium-frames-like-the-iphone-15/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T05:34:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/02/1675275544_samsung-galaxy-s23-1_medium.jpg" /></div>Samsung Galaxy S24 series may feature Titanium as the company is planning to use the new metal to build the frames of the phone. The Korean giant already uses Titanium in its smartwatches. <a href="https://www.neowin.net/news/samsung-galaxy-s24-series-may-feature-titanium-frames-like-the-iphone-15">Read more...</a>

## Google Drive consolidates all your recent activity into one page
 - [https://www.neowin.net/news/google-drive-consolidates-all-your-recent-activity-into-one-page/](https://www.neowin.net/news/google-drive-consolidates-all-your-recent-activity-into-one-page/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T04:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/01/1579727682_google_drive_medium.jpg" /></div>Google is rolling out a new Activity tab in Google Drive for all Workspace customers. The new feature allows users to view and take action on their recent Google Drive activity from a single place. <a href="https://www.neowin.net/news/google-drive-consolidates-all-your-recent-activity-into-one-page">Read more...</a>

## Instagram starts testing multiple audience lists for Stories
 - [https://www.neowin.net/news/instagram-starts-testing-multiple-audience-lists-for-stories/](https://www.neowin.net/news/instagram-starts-testing-multiple-audience-lists-for-stories/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-10-06T03:24:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/11/1605645087_untitled_design_(4)_medium.jpg" /></div>Instagram head Adam Mosseri announced that the company is testing the ability to create multiple lists. The new feature will allow users to share specific Stories with specific groups of followers. <a href="https://www.neowin.net/news/instagram-starts-testing-multiple-audience-lists-for-stories">Read more...</a>

