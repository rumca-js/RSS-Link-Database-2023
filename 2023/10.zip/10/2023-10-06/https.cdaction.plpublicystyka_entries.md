# Source:CD-Action - publicystyka, URL:https://cdaction.pl/publicystyka, language:pl

## Mamy pierwszy związek zawodowy w polskim gamedevie [WYWIAD] – CD-Action
 - [https://cdaction.pl/publicystyka/mamy-pierwszy-zwiazek-zawodowy-w-polskim-gamedevie-wywiad](https://cdaction.pl/publicystyka/mamy-pierwszy-zwiazek-zawodowy-w-polskim-gamedevie-wywiad)
 - RSS feed: https://cdaction.pl/publicystyka
 - date published: 2023-10-06T10:27:36.302344+00:00

Mamy pierwszy związek zawodowy w polskim gamedevie [WYWIAD] – CD-Action

