# Source:Tabletop Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ, language:en-US

## SOLUTION: Should I Switch to One Page Rules from 40k?
 - [https://www.youtube.com/watch?v=OlKzaLF9jGc](https://www.youtube.com/watch?v=OlKzaLF9jGc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2CKTY1TXQ4YQ3AHvyCgtbQ
 - date published: 2023-10-06T07:00:10+00:00

Warhammer 40k rules are a constantly moving target - and an expensive one, at that. Can I move my 1000 Imperial Guard army over to Grimdark Future from One Page Rules? How will it translate?

Vince Venturella and I made another game! Check out MAJESTIC 13 at http://www.majestic13game.com

I'm now a partner on Twitch! I paint minis every Friday morning and Monday night, and sometimes take paint breaks (play video games poorly). Follow me: http://www.twitch.tv/tabletopminions

Official Tabletop Minions t-shirts: http://bit.ly/merchbunker

Help support the channel on Patreon, and get access to the Discord: http://www.patreon.com/tabletopminions

Twitter: http://www.twitter.com/tabletopminions
Instagram: http://www.instagram.com/tabletopminions

