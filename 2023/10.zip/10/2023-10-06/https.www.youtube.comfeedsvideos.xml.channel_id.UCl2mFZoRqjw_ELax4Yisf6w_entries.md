# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## HP is scraping the bottom of the barrel
 - [https://www.youtube.com/watch?v=ACX_VfsjkZA](https://www.youtube.com/watch?v=ACX_VfsjkZA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-10-06T19:35:27+00:00

🔵 We fix Macbooks & offer free estimates. https://rossmanngroup.com
🔵 Send us your Macbook for repair! http://bit.ly/sendmacbook
🔵 We'll send you a box with a pre-paid shipping label for your repair! http://bit.ly/sendyourmacbook
🔵 We offer iPhone data recovery: http://bit.ly/2BDBX4G
🔵 We offer lab hard drive data recovery: http://bit.ly/labdatarecovery

👉 Matrix chat: https://matrix.to/#/#rossmannrepair-general:matrix.org

👉 LEARN HOW TO DO THIS:
› Beginner's guide: http://bit.ly/2k6uz84
› Support forum: $29/mo https://boards.rossmanngroup.com

👉 CHIPS & COMPONENTS:
› http://bit.ly/2jaAOXM

👉 TOOLS USED:
✓ Soldering Irons:
› Louis' Hakko station(no tweezers): http://amzn.to/2cKkMyO 
› Paul's Hakko station(works with tweezers): http://amzn.to/2yMvWNy
› Micro Soldering Pencil: http://amzn.to/2d5MWUP
› Hot tweezers: http://amzn.to/2yMvZsZ
› Atten ST-862D hot air station with bent nozzles: https://bit.ly/atten862

✓ CHEAP HAKKO ALTERNATIVES:
› TS100 soldering iron: https://amzn.to/2Gy1F

## the most important clickbait you'll ever click
 - [https://www.youtube.com/watch?v=D-szlVc0jk8](https://www.youtube.com/watch?v=D-szlVc0jk8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-10-06T13:40:13+00:00



