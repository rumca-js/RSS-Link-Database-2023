# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## How Efforts to Restrict Democracy in Ohio Make It Harder to Fight Climate Change
 - [https://www.desmog.com/2023/10/06/how-efforts-to-restrict-democracy-in-ohio-make-it-harder-to-fight-climate-change/](https://www.desmog.com/2023/10/06/how-efforts-to-restrict-democracy-in-ohio-make-it-harder-to-fight-climate-change/)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-10-06T20:15:17+00:00

<p>This article by Energy News Network is published here as part of the global journalism collaboration Covering Climate Now. Ohio’s adoption of gerrymandered voting district maps last week is the latest in a series of anti-democratic measures that thwart action to address climate change, critics say. Data&#160;from the Yale Program on Climate Change Communication show a [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/10/06/how-efforts-to-restrict-democracy-in-ohio-make-it-harder-to-fight-climate-change/" rel="nofollow">How Efforts to Restrict Democracy in Ohio Make It Harder to Fight Climate Change</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

