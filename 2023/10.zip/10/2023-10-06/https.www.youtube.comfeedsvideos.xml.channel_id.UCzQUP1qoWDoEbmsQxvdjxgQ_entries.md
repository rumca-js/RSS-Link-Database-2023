# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## OpenAI CEO on Artificial Intelligence Changing Society
 - [https://www.youtube.com/watch?v=MTJZpO3bTpg](https://www.youtube.com/watch?v=MTJZpO3bTpg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-10-06T20:53:56+00:00

Taken from JRE #2044 w/Sam Altman:
https://open.spotify.com/episode/66edV3LAbUXa26HG1ZQaKB?si=9cc981eab2b04e53

