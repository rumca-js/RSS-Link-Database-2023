# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## Fwupd 1.9.6 Linux Firmware Updater Adds Support for AMD dGPUs Navi3x and Later
 - [https://9to5linux.com/fwupd-1-9-6-linux-firmware-updater-adds-support-for-amd-dgpus-navi3x-and-later](https://9to5linux.com/fwupd-1-9-6-linux-firmware-updater-adds-support-for-amd-dgpus-navi3x-and-later)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-10-06T10:16:39+00:00

<p>Fwupd 1.9.6 Linux firmware updating utility is now available for download with support for AMD dGPUs Navi3x and later, StarBook Mk VIr2, Google Rex Intel USB-4 retimers, and other devices.</p>
<p>The post <a href="https://9to5linux.com/fwupd-1-9-6-linux-firmware-updater-adds-support-for-amd-dgpus-navi3x-and-later" rel="nofollow">Fwupd 1.9.6 Linux Firmware Updater Adds Support for AMD dGPUs Navi3x and Later</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Proton 8.0-4 Released with Support for More Windows Games on Linux
 - [https://9to5linux.com/proton-8-0-4-released-with-support-for-more-windows-games-on-linux](https://9to5linux.com/proton-8-0-4-released-with-support-for-more-windows-games-on-linux)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-10-06T02:35:53+00:00

<p>Proton 8.0-4 compatibility tool for Steam Play is out with support for more Windows games to play on Linux, as well as various improvements. Here’s what’s new!</p>
<p>The post <a href="https://9to5linux.com/proton-8-0-4-released-with-support-for-more-windows-games-on-linux" rel="nofollow">Proton 8.0-4 Released with Support for More Windows Games on Linux</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

