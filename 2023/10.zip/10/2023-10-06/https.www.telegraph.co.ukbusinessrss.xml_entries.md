# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## House prices fall for fifth month in a row amid rising mortgage costs - latest updates
 - [https://www.telegraph.co.uk/business/2023/10/06/ftse-100-markets-news-house-prices-live-bonds-oil-latest/](https://www.telegraph.co.uk/business/2023/10/06/ftse-100-markets-news-house-prices-live-bonds-oil-latest/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-10-06T06:06:38+00:00



