# Source:GeekWire, URL:https://www.geekwire.com/feed/, language:en-US

## Tech Moves: Former Sprint CEO rejoins F5 board; Flexport engineering exec departs; and more
 - [https://www.geekwire.com/2023/tech-moves-former-sprint-ceo-rejoins-f5-board-flexport-engineering-exec-departs-and-more/](https://www.geekwire.com/2023/tech-moves-former-sprint-ceo-rejoins-f5-board-flexport-engineering-exec-departs-and-more/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-06T17:09:22+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/10/Combes-3-1260x840.jpg" width="1260" /><br />— Michel Combes, a longtime telecommunications and finance executive, rejoined F5&#8217;s board of directors. He previously stepped down from the board in 2021 after serving for about three years. Combes is the executive vice president at global investment firm Claure Group. Before that, he was CEO and president of SoftBank Group for two years, following a two-year stint as president and CEO of Sprint. He also held leadership roles at Altice N.V., Alcatel-Lucent, Vodafone Europe, TDF Group, and France Telecom. &#8220;His experience leading some of the world&#8217;s largest telecom operators gives him unparalleled insight into a large segment of F5&#8217;s&#8230; <a href="https://www.geekwire.com/2023/tech-moves-former-sprint-ceo-rejoins-f5-board-flexport-engineering-exec-departs-and-more/">Read More</a>

## Life goals: Megan Rapinoe says goodbye to soccer, and Seattle tech leaders share how she inspired
 - [https://www.geekwire.com/2023/life-goals-megan-rapinoe-says-goodbye-to-soccer-and-seattle-tech-leaders-share-how-she-inspired/](https://www.geekwire.com/2023/life-goals-megan-rapinoe-says-goodbye-to-soccer-and-seattle-tech-leaders-share-how-she-inspired/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-06T14:22:15+00:00

<img alt="" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/10/JG3_8313-1260x840.jpg" width="1260" /><br />Megan Rapinoe&#8217;s reign is drawing to a close. But the global soccer star&#8217;s influence and activism is sure to continue to be felt on and off the pitch. After 11 seasons with Seattle&#8217;s OL Reign —&#160;and a decorated international career that includes two Olympic medals and two World Cup titles —&#160;Rapinoe is playing her final regular season home match on Friday night at Lumen Field. It&#8217;s been a weeklong celebration in Seattle in Rapinoe&#8217;s honor, and the party will continue at the stadium where a record 28,000+ fans are expected to take in numerous activities and tributes tied to the&#8230; <a href="https://www.geekwire.com/2023/life-goals-megan-rapinoe-says-goodbye-to-soccer-and-seattle-tech-leaders-share-how-she-inspired/">Read More</a>

## Follow the countdown to the first launch of Amazon’s Project Kuiper satellites
 - [https://www.geekwire.com/2023/amazon-kuiper-satellite-atlas-protolaunch/](https://www.geekwire.com/2023/amazon-kuiper-satellite-atlas-protolaunch/)
 - RSS feed: https://www.geekwire.com/feed/
 - date published: 2023-10-06T13:43:22+00:00

<img alt="Atlas V on launch pad with Amazon Project Kuiper satellites" class="webfeedsFeaturedVisual wp-post-image" height="840" src="https://cdn.geekwire.com/wp-content/uploads/2023/10/231006-atlas-1260x840.jpeg" width="1260" /><br />The countdown is on for the first-ever launch of Amazon satellites, aimed at testing out the hardware and software for the Seattle company&#8217;s worldwide Project Kuiper broadband internet constellation. Two prototype satellites &#8212; known as KuiperSat 1 and 2 &#8212; are due to ride a United Launch Alliance Atlas V rocket from Cape Canaveral Space Force Station in Florida into low Earth orbit at 2 p.m. ET (11 a.m. PT). Forecasters say there&#8217;s a 70% chance of acceptable weather for launch, and there&#8217;s a two-hour launch window to accommodate potential delays. ULA is providing live updates on what it calls&#8230; <a href="https://www.geekwire.com/2023/amazon-kuiper-satellite-atlas-protolaunch/">Read More</a>

