# Source:Squidmar Miniatures, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g, language:en-US

## Duel of the Titans – unreal diorama / 12 months work / 70 kg of clear resin / Warhammer
 - [https://www.youtube.com/watch?v=xV3QKhGscTI](https://www.youtube.com/watch?v=xV3QKhGscTI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCDvZTWvHZPTxJ4K1yTD2a1g
 - date published: 2023-10-06T14:53:04+00:00

Head to https://squarespace.com/squidmar to save 10% off your first purchase of a website or domain using code squidmar

This video is the ultimate compilation of all the work we put in to the Warlord Titan diorama featuring 2 warhammer warlord titans from forgeworld. We spent over 8 months working on this beast and we're so happy to finally be done with it!

________________________

Grab the brand spanking new Squidmar Airbrush - H&amp;S Ultra while you can: https://harder-airbrush.net/products/squidmar-ultra-2024?sca_ref=4445841.N2Xdu4mHZE
________________________

🏆 Support me on Patreon: https://www.patreon.com/squidmarminiatures 
👍 Squidmars website for full list of gear I use: https://www.squidmar.com/gear  
👕 Order Squidmar Merch: https://teespring.com/stores/squidmarminiatures

__________________________

🖌️EU/UK hobby store affiliate - Reference code for extra store credit: EMI7383 
https://elementgames.co.uk/paints-hobby-and-scenery/element-essentials/egaps/squidmar-miniat

