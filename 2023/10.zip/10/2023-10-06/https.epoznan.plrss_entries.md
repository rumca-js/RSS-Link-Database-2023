# Source:E Poznan, URL:https://epoznan.pl/rss, language:pl-PL

## Lech Poznań wygrał z Puszczą Niepołomice 4:1. Wielki powrót do formy Kolejorza!
 - [https://epoznan.pl/news-news-143782-lech_poznan_wygral_z_puszcza_niepolomice_41_wielki_powrot_do_formy_kolejorza?rss=1](https://epoznan.pl/news-news-143782-lech_poznan_wygral_z_puszcza_niepolomice_41_wielki_powrot_do_formy_kolejorza?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T20:48:00+00:00

Mecz przy Bułgarskiej rozpoczął się o 20:40.

## Olbrzymie korki w mieście przed meczem Lecha z Puszczą Niepołomice
 - [https://epoznan.pl/news-news-143781-olbrzymie_korki_w_miescie_przed_meczem_lecha_z_puszcza_niepolomice?rss=1](https://epoznan.pl/news-news-143781-olbrzymie_korki_w_miescie_przed_meczem_lecha_z_puszcza_niepolomice?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T18:43:00+00:00

W piątek o 20:40 na Enea stadionie przy ul. Bułgarskiej w Poznaniu rozpoczął się mecz.

## Mateusz Morawiecki jednak nie przyjedzie w niedzielę do Wielkopolski
 - [https://epoznan.pl/news-news-143780-mateusz_morawiecki_jednak_nie_przyjedzie_w_niedziele_do_wielkopolski?rss=1](https://epoznan.pl/news-news-143780-mateusz_morawiecki_jednak_nie_przyjedzie_w_niedziele_do_wielkopolski?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T17:59:00+00:00

Miał pojawić się w Przygodzicach i w Kaliszu.

## Seniorka upadła na chodnik i trafiła do szpitala, ale policja i lekarze nie znają jej tożsamości
 - [https://epoznan.pl/news-news-143779-seniorka_upadla_na_chodnik_i_trafila_do_szpitala_ale_policja_i_lekarze_nie_znaja_jej_tozsamosci?rss=1](https://epoznan.pl/news-news-143779-seniorka_upadla_na_chodnik_i_trafila_do_szpitala_ale_policja_i_lekarze_nie_znaja_jej_tozsamosci?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T17:25:00+00:00

W piątkowe popołudnie w Gnieźnie seniorka upadła na chodnik.

## Jadwiga Emilewicz zaprosiła seniorki z powiatu poznańskiego na wspólny Nordic Walking. Trwa kampania wyborcza
 - [https://epoznan.pl/news-news-143778-jadwiga_emilewicz_zaprosila_seniorki_z_powiatu_poznanskiego_na_wspolny_nordic_walking_trwa_kampania_wyborcza?rss=1](https://epoznan.pl/news-news-143778-jadwiga_emilewicz_zaprosila_seniorki_z_powiatu_poznanskiego_na_wspolny_nordic_walking_trwa_kampania_wyborcza?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T16:50:00+00:00

W sobotę odbędzie się &quot;Spacer po Zdrowie&quot;.

## Światowy Dzień Mózgowego Porażenia Dziecięcego. Ważyli osoby z niepełnosprawnościami
 - [https://epoznan.pl/news-news-143777-swiatowy_dzien_mozgowego_porazenia_dzieciecego_wazyli_osoby_z_niepelnosprawnosciami?rss=1](https://epoznan.pl/news-news-143777-swiatowy_dzien_mozgowego_porazenia_dzieciecego_wazyli_osoby_z_niepelnosprawnosciami?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T16:17:00+00:00

Już od 5 lat w Poznaniu z inicjatywy Stowarzyszenia na Rzecz Dzieci i Dorosłych z Mózgowym Porażeniem Dziecięcym &quot;Żurawinka&quot;, organizowany jest Tydzień MPD &quot;Dajemy zielone światło&quot;.

## Dziecko wyszło zza zaparkowanego auta i zostało potrącone przez rozpędzonego kierowcę hulajnogi. Poszkodowany 7-latek trafił do szpitala.
 - [https://epoznan.pl/news-news-143776-dziecko_wyszlo_zza_zaparkowanego_auta_i_zostalo_potracone_przez_rozpedzonego_kierowce_hulajnogi_poszkodowany_7_latek_trafil_do_szpitala?rss=1](https://epoznan.pl/news-news-143776-dziecko_wyszlo_zza_zaparkowanego_auta_i_zostalo_potracone_przez_rozpedzonego_kierowce_hulajnogi_poszkodowany_7_latek_trafil_do_szpitala?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T15:36:00+00:00

Do zdarzenia doszło w czwartek na terenie Ostrowa Wielkopolskiego.

## Korki między węzłami Poznań Północ i Poznań Rokietnica. Kolizja dwóch pojazdów
 - [https://epoznan.pl/news-news-143775-korki_miedzy_wezlami_poznan_polnoc_i_poznan_rokietnica_kolizja_dwoch_pojazdow?rss=1](https://epoznan.pl/news-news-143775-korki_miedzy_wezlami_poznan_polnoc_i_poznan_rokietnica_kolizja_dwoch_pojazdow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T15:15:00+00:00

W piątek po godzinie 16:00 na S11 w kierunku Wrocławia.

## Marszałek województwa wielkopolskiego nie zgadza się na propagandę wyborczą w pociągach POLREGIO. Złożył sprzeciw
 - [https://epoznan.pl/news-news-143774-marszalek_wojewodztwa_wielkopolskiego_nie_zgadza_sie_na_propagande_wyborcza_w_pociagach_polregio_zlozyl_sprzeciw?rss=1](https://epoznan.pl/news-news-143774-marszalek_wojewodztwa_wielkopolskiego_nie_zgadza_sie_na_propagande_wyborcza_w_pociagach_polregio_zlozyl_sprzeciw?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T15:00:00+00:00

W piątek złożył oficjalne pismo u prezesa zarządu POLREGIO Adama Pawlika.

## Głogowska: tramwaje stały z powodu kolizji. Winny kierowca samochodu osobowego
 - [https://epoznan.pl/news-news-143773-glogowska_tramwaje_staly_z_powodu_kolizji_winny_kierowca_samochodu_osobowego?rss=1](https://epoznan.pl/news-news-143773-glogowska_tramwaje_staly_z_powodu_kolizji_winny_kierowca_samochodu_osobowego?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T14:23:00+00:00

Do zderzenia doszło w piątek po godzinie 15:00.

## Mężczyzna onanizował się w miejskim autobusie. Szuka go policja
 - [https://epoznan.pl/news-news-143768-mezczyzna_onanizowal_sie_w_miejskim_autobusie_szuka_go_policja?rss=1](https://epoznan.pl/news-news-143768-mezczyzna_onanizowal_sie_w_miejskim_autobusie_szuka_go_policja?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:55:00+00:00

Do zdarzenia doszło 21 września.

## Na MTP ruszyła kolejna edycja Poznań Game Arena. To święto fanów gier
 - [https://epoznan.pl/news-news-143771-na_mtp_ruszyla_kolejna_edycja_poznan_game_arena_to_swieto_fanow_gier?rss=1](https://epoznan.pl/news-news-143771-na_mtp_ruszyla_kolejna_edycja_poznan_game_arena_to_swieto_fanow_gier?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:50:00+00:00

Impreza odbywa się w sześciu pawilonach.

## Weekendowe utrudnienia komunikacyjne na Wildzie. Awaryjna naprawa torowiska, nie pojadą tramwaje!
 - [https://epoznan.pl/news-news-143766-weekendowe_utrudnienia_komunikacyjne_na_wildzie_awaryjna_naprawa_torowiska_nie_pojada_tramwaje?rss=1](https://epoznan.pl/news-news-143766-weekendowe_utrudnienia_komunikacyjne_na_wildzie_awaryjna_naprawa_torowiska_nie_pojada_tramwaje?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:30:00+00:00

To pokłosie wykolejenia, do którego doszło w czwartek.

## Ruszyły targi Retro Motor Show
 - [https://epoznan.pl/news-news-143770-ruszyly_targi_retro_motor_show?rss=1](https://epoznan.pl/news-news-143770-ruszyly_targi_retro_motor_show?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:27:00+00:00

Na MTP tłumy.

## Dachowanie auta na Warszawskiej
 - [https://epoznan.pl/news-news-143769-dachowanie_auta_na_warszawskiej?rss=1](https://epoznan.pl/news-news-143769-dachowanie_auta_na_warszawskiej?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:17:00+00:00

Do zdarzenia doszło na wysokości salonu Porsche.

## Do wielkopolskiego miasta ma wrócić kolej. Podano szczegóły wielomilionowej inwestycji
 - [https://epoznan.pl/news-news-143765-do_wielkopolskiego_miasta_ma_wrocic_kolej_podano_szczegoly_wielomilionowej_inwestycji?rss=1](https://epoznan.pl/news-news-143765-do_wielkopolskiego_miasta_ma_wrocic_kolej_podano_szczegoly_wielomilionowej_inwestycji?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T12:10:00+00:00

PKP PLK podpisały umowę na przygotowanie projektu rewitalizacji linii kolejowej Czarnków - Rogoźno - Wągrowiec.

## Kolejny wypadek na S5 pod Kościanem. Trasa zablokowana, lądował śmigłowiec LPR!
 - [https://epoznan.pl/news-news-143767-kolejny_wypadek_na_s5_pod_koscianem_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1](https://epoznan.pl/news-news-143767-kolejny_wypadek_na_s5_pod_koscianem_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T11:58:00+00:00

Do zdarzenia doszło na jezdni w kierunku Poznania.

## S5: Ciężarówka zmiażdżyła busa. Trasa zablokowana, lądował śmigłowiec LPR
 - [https://epoznan.pl/news-news-143767-s5_ciezarowka_zmiazdzyla_busa_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1](https://epoznan.pl/news-news-143767-s5_ciezarowka_zmiazdzyla_busa_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T11:58:00+00:00

Do zdarzenia doszło na jezdni w kierunku Poznania.

## S5: Ciężarówki zmiażdżyły busa. Trasa zablokowana, lądował śmigłowiec LPR
 - [https://epoznan.pl/news-news-143767-s5_ciezarowki_zmiazdzyly_busa_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1](https://epoznan.pl/news-news-143767-s5_ciezarowki_zmiazdzyly_busa_trasa_zablokowana_ladowal_smiglowiec_lpr?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T11:58:00+00:00

Do zdarzenia doszło na jezdni w kierunku Poznania.

## Jest ostrzeżenie meteo dla części województwa
 - [https://epoznan.pl/news-news-143763-jest_ostrzezenie_meteo_dla_czesci_wojewodztwa?rss=1](https://epoznan.pl/news-news-143763-jest_ostrzezenie_meteo_dla_czesci_wojewodztwa?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T11:25:00+00:00

Tym razem przed silnym wiatrem.

## Wkrótce zmiana czasu, kiedy przestawiamy zegarki?
 - [https://epoznan.pl/news-news-143762-wkrotce_zmiana_czasu_kiedy_przestawiamy_zegarki?rss=1](https://epoznan.pl/news-news-143762-wkrotce_zmiana_czasu_kiedy_przestawiamy_zegarki?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T10:40:00+00:00

Zmiana odbywa się zawsze w październiku.

## Pojechali na interwencję domową, w ogródku znaleźli uprawę konopi
 - [https://epoznan.pl/news-news-143759-pojechali_na_interwencje_domowa_w_ogrodku_znalezli_uprawe_konopi?rss=1](https://epoznan.pl/news-news-143759-pojechali_na_interwencje_domowa_w_ogrodku_znalezli_uprawe_konopi?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T09:55:00+00:00

Wpadli bracia.

## Prymasa Polski zapytano o to, na którą partię polityczną powinien głosować katolik. Co odpowiedział?
 - [https://epoznan.pl/news-news-143758-prymasa_polski_zapytano_o_to_na_ktora_partie_polityczna_powinien_glosowac_katolik_co_odpowiedzial?rss=1](https://epoznan.pl/news-news-143758-prymasa_polski_zapytano_o_to_na_ktora_partie_polityczna_powinien_glosowac_katolik_co_odpowiedzial?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T09:10:00+00:00

Arcybiskup Wojciech Polak udzielił wywiadu Katolickiej Agencji Informacyjnej.

## 10-tysięczny sklep poznańskiej sieci otworzy się w Starym Browarze. Wkrótce sklepy &quot;drive thru&quot;
 - [https://epoznan.pl/news-news-143757-10_tysieczny_sklep_poznanskiej_sieci_otworzy_sie_w_starym_browarze_wkrotce_sklepy_drive_thru?rss=1](https://epoznan.pl/news-news-143757-10_tysieczny_sklep_poznanskiej_sieci_otworzy_sie_w_starym_browarze_wkrotce_sklepy_drive_thru?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T08:25:00+00:00

Mowa o Żabce.

## Ksiądz sypiał z parafiankami, do sieci trafiły jego nagie zdjęcia. Duchowny chciał ukarania sprawcy, ale sprawę umorzono
 - [https://epoznan.pl/news-news-143755-ksiadz_sypial_z_parafiankami_do_sieci_trafily_jego_nagie_zdjecia_duchowny_chcial_ukarania_sprawcy_ale_sprawe_umorzono?rss=1](https://epoznan.pl/news-news-143755-ksiadz_sypial_z_parafiankami_do_sieci_trafily_jego_nagie_zdjecia_duchowny_chcial_ukarania_sprawcy_ale_sprawe_umorzono?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T07:40:00+00:00

Skandal wybuchł w Trzcinicy na terenie powiatu kępińskiego.

## Poznański szpital ma się rozbudować o nową część. Co może w niej powstać?
 - [https://epoznan.pl/news-news-143754-poznanski_szpital_ma_sie_rozbudowac_o_nowa_czesc_co_moze_w_niej_powstac?rss=1](https://epoznan.pl/news-news-143754-poznanski_szpital_ma_sie_rozbudowac_o_nowa_czesc_co_moze_w_niej_powstac?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T07:00:00+00:00

Mowa o szpitalu im. Strusia z ulicy Szwajcarskiej.

## 58-latek podejrzany o pedofilię. Wpadł dzięki reakcji starszej siostry pokrzywdzonej dziewczynki
 - [https://epoznan.pl/news-news-143753-58_latek_podejrzany_o_pedofilie_wpadl_dzieki_reakcji_starszej_siostry_pokrzywdzonej_dziewczynki?rss=1](https://epoznan.pl/news-news-143753-58_latek_podejrzany_o_pedofilie_wpadl_dzieki_reakcji_starszej_siostry_pokrzywdzonej_dziewczynki?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T06:25:00+00:00

Sytuacja miała miejsce w powiecie gostyńskim.

## Budują drogę rowerową w centrum Poznania. Ma znacznie ułatwić życie rowerzystom, ale teraz komplikuje życie kierowców
 - [https://epoznan.pl/news-news-143752-buduja_droge_rowerowa_w_centrum_poznania_ma_znacznie_ulatwic_zycie_rowerzystom_ale_teraz_komplikuje_zycie_kierowcow?rss=1](https://epoznan.pl/news-news-143752-buduja_droge_rowerowa_w_centrum_poznania_ma_znacznie_ulatwic_zycie_rowerzystom_ale_teraz_komplikuje_zycie_kierowcow?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T05:50:00+00:00

Chodzi o ścieżkę w rejonie Estkowskiego, Wolnica i Solnej.

## &quot;Awarie&quot; dystrybutorów na Orlenie rozlewają się na coraz więcej stacji. Także w Poznaniu
 - [https://epoznan.pl/news-news-143751-awarie_dystrybutorow_na_orlenie_rozlewaja_sie_na_coraz_wiecej_stacji_takze_w_poznaniu?rss=1](https://epoznan.pl/news-news-143751-awarie_dystrybutorow_na_orlenie_rozlewaja_sie_na_coraz_wiecej_stacji_takze_w_poznaniu?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T05:16:00+00:00



## Trasa S5 zablokowana po zderzeniu dwóch ciężarówek
 - [https://epoznan.pl/news-news-143750-trasa_s5_zablokowana_po_zderzeniu_dwoch_ciezarowek?rss=1](https://epoznan.pl/news-news-143750-trasa_s5_zablokowana_po_zderzeniu_dwoch_ciezarowek?rss=1)
 - RSS feed: https://epoznan.pl/rss
 - date published: 2023-10-06T05:00:00+00:00

Do zdarzenia doszło około 4.00 na wysokości Kościana.

