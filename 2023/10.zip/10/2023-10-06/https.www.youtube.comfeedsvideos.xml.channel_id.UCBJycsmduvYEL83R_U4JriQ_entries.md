# Source:Marques Brownlee, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ, language:en-US

## Can You Trust Google?
 - [https://www.youtube.com/watch?v=dxVaP0-aFIE](https://www.youtube.com/watch?v=dxVaP0-aFIE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2023-10-06T19:50:22+00:00

Pixel 8's 7 years of software updates is revolutionary... maybe

https://killedbygoogle.com/

MKBHD Merch: http://shop.MKBHD.com

Tech I'm using right now: https://www.amazon.com/shop/MKBHD

Playlist of MKBHD Intro music: https://goo.gl/B3AWV5

~
http://twitter.com/MKBHD
http://instagram.com/MKBHD
http://facebook.com/MKBHD

## Your Phone Plan Costs More Than You Think #visiblewireless #visible_partner
 - [https://www.youtube.com/watch?v=RlJYdxqPG-I](https://www.youtube.com/watch?v=RlJYdxqPG-I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2023-10-06T17:14:52+00:00

Your phone plan costs more than you think...

## Your Phone Plan Costs More Than You Think #visiblewireless #visible_partner
 - [https://www.youtube.com/watch?v=slq9NgbPQ1w](https://www.youtube.com/watch?v=slq9NgbPQ1w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBJycsmduvYEL83R_U4JriQ
 - date published: 2023-10-06T16:48:04+00:00



