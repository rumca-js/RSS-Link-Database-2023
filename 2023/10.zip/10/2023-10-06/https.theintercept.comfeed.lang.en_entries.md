# Source:The Intercept, URL:https://theintercept.com/feed/?lang=en, language:en-US

## Hijacked Hope: Why a Decade of Mass Protest Backfired
 - [https://theintercept.com/2023/10/06/deconstructed-mass-protest-movements-vincent-bevins/](https://theintercept.com/2023/10/06/deconstructed-mass-protest-movements-vincent-bevins/)
 - RSS feed: https://theintercept.com/feed/?lang=en
 - date published: 2023-10-06T10:00:00+00:00

<p>Vincent Bevins discusses his new book, “If We Burn: The Mass Protest Decade and the Missing Revolution,” and the global protest movements of the 2010s.</p>
<p>The post <a href="https://theintercept.com/2023/10/06/deconstructed-mass-protest-movements-vincent-bevins/" rel="nofollow">Hijacked Hope: Why a Decade of Mass Protest Backfired</a> appeared first on <a href="https://theintercept.com" rel="nofollow">The Intercept</a>.</p>

