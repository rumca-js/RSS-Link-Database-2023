# Source:Japan Today, URL:https://japantoday.com/feed, language:en

## France rout Italy 60-7 to reach quarterfinals in style
 - [https://japantoday.com/category/rugby-world-cup-2023/france-routs-italy-60-7-to-reach-rugby-world-cup-quarterfinals-in-style](https://japantoday.com/category/rugby-world-cup-2023/france-routs-italy-60-7-to-reach-rugby-world-cup-quarterfinals-in-style)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T23:18:42+00:00

Damian Penaud extended his try-scoring streak to seven matches as Rugby World Cup host France blew apart Italy 60-7 to reach the quarterfinals in style on Friday.
France…

## Amazon launches test satellites for its planned internet service to compete with SpaceX
 - [https://japantoday.com/category/tech/amazon-launches-test-satellites-for-its-planned-internet-service-to-compete-with-spacex](https://japantoday.com/category/tech/amazon-launches-test-satellites-for-its-planned-internet-service-to-compete-with-spacex)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:32:27+00:00

Amazon launched the first test satellites for its planned internet service on Friday as a rival to SpaceX’s broadband network.
United Launch Alliance’s Atlas V rocket blasted off…

## Auto workers stop expanding strikes against Detroit Three after GM makes battery plant concession
 - [https://japantoday.com/category/business/auto-workers-stop-expanding-strikes-against-detroit-three-after-gm-makes-battery-plant-concession](https://japantoday.com/category/business/auto-workers-stop-expanding-strikes-against-detroit-three-after-gm-makes-battery-plant-concession)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:31:58+00:00

The United Auto Workers union said Friday it will not expand its strikes against Detroit's three automakers after General Motors made a breakthrough concession on unionizing electric vehicle…

## S Korea's filmmaking diaspora telling their 'own stories'
 - [https://japantoday.com/category/entertainment/s.-korea%27s-filmmaking-diaspora-telling-their-%27own-stories%271](https://japantoday.com/category/entertainment/s.-korea%27s-filmmaking-diaspora-telling-their-%27own-stories%271)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:30:30+00:00

The rise of South Korean diasporic cinema -- characterised by films like Lee Isaac Chung's &quot;Minari&quot; and Justin Chon's &quot;Jamojaya&quot; -- has allowed the artists involved to feel…

## Advance ticket sales for Taylor Swift concert movie top $100 mil
 - [https://japantoday.com/category/entertainment/advance-ticket-sales-for-taylor-swift-concert-movie-top-100-mn1](https://japantoday.com/category/entertainment/advance-ticket-sales-for-taylor-swift-concert-movie-top-100-mn1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:30:20+00:00

Advance ticket sales for the movie of Taylor Swift's &quot;Eras&quot; tour have topped $100 million worldwide, theater operator AMC said Thursday, making it the best-selling feature-length concert film…

## Turkish Airlines plane diverted from route, flew over central Tokyo
 - [https://japantoday.com/category/national/turkish-airlines-plane-diverted-from-route-flew-over-central-tokyo](https://japantoday.com/category/national/turkish-airlines-plane-diverted-from-route-flew-over-central-tokyo)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:28:43+00:00

A Turkish Airlines passenger aircraft erroneously diverted from its route and flew over Tokyo Tower and other central parts of the Japanese capital last month, Japanese transport ministry…

## Breakdancing wows Asian Games ahead of Olympic bow
 - [https://japantoday.com/category/sports/%27coolest-thing%27-breakdancing-wows-asian-games-ahead-of-olympic-bow1](https://japantoday.com/category/sports/%27coolest-thing%27-breakdancing-wows-asian-games-ahead-of-olympic-bow1)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:28:25+00:00

When South Korean Kim Hong-yul was a teenager in the late 1990s, hip-hop ruled the airwaves and breakdancing was &quot;the coolest thing in the world&quot;, he says.
Now…

## Lewis Hamilton says he'd welcome a new Formula One team but wants it to improve diversity
 - [https://japantoday.com/category/sports/lewis-hamilton-says-he%27d-welcome-a-new-formula-one-team-but-wants-it-to-improve-diversity](https://japantoday.com/category/sports/lewis-hamilton-says-he%27d-welcome-a-new-formula-one-team-but-wants-it-to-improve-diversity)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:28:15+00:00

Seven-time Formula One champion Lewis Hamilton said Friday he’d welcome an 11th team joining the Formula One grid but argued for stricter criteria on improving diversity in the…

## Biles wins 21st world title with all-around gymnastics gold
 - [https://japantoday.com/category/sports/biles-wins-21st-world-title-with-all-around-gymnastics-gold](https://japantoday.com/category/sports/biles-wins-21st-world-title-with-all-around-gymnastics-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:28:02+00:00

U.S. superstar Simone Biles continued her spectacular return from a two-year break by claiming a 21st world title with gold in the women's all-around at the world gymnastics…

## Swiatek to play Gauff in China Open semi-finals
 - [https://japantoday.com/category/sports/swiatek-to-play-gauff-in-china-open-semi-finals](https://japantoday.com/category/sports/swiatek-to-play-gauff-in-china-open-semi-finals)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:27:51+00:00

Iga Swiatek will play Coco Gauff in the China Open women's semifinals, after the world's second and third-ranked players both won in Beijing on Friday.
World number two…

## Third seed Rune, Zverev out of Shanghai Masters on day of upsets
 - [https://japantoday.com/category/sports/third-seed-rune-out-of-shanghai-masters-on-day-of-upsets](https://japantoday.com/category/sports/third-seed-rune-out-of-shanghai-masters-on-day-of-upsets)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:27:41+00:00

Shanghai Masters third seed Holger Rune crashed out of the tournament in straight sets on Friday, the highest-profile of several top-20 players to be knocked out that day.…

## China keeps raking in the golds as it dominates Asian Games on home soil in Hangzhou
 - [https://japantoday.com/category/sports/china-keeps-raking-in-the-golds-as-it-dominates-asian-games-on-home-soil-in-hangzhou](https://japantoday.com/category/sports/china-keeps-raking-in-the-golds-as-it-dominates-asian-games-on-home-soil-in-hangzhou)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:27:27+00:00

Chinese swimmer Wu Shutong took Asian Games gold Friday in the 10-kilometer race, finishing seconds ahead of her competition from Japan in the more-than two-hour race, which she…

## Japan defy crowd to beat North Korea for Asian Games women's soccer gold
 - [https://japantoday.com/category/sports/japan-beat-north-korea-for-asian-games-women%27s-football-gold](https://japantoday.com/category/sports/japan-beat-north-korea-for-asian-games-women%27s-football-gold)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:26:15+00:00

Japan were booed but kept their cool in an &quot;interesting&quot; atmosphere to beat North Korea 4-1 and retain their Asian Games women's soccer crown on Friday.
The crowd…

## 3 bears captured after sneaking into Akita tatami factory
 - [https://japantoday.com/category/national/3-bears-are-captured-after-sneaking-into-a-tatami-factory-as-northern-japan-faces-a-growing-problem](https://japantoday.com/category/national/3-bears-are-captured-after-sneaking-into-a-tatami-factory-as-northern-japan-faces-a-growing-problem)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:25:58+00:00

Three bears that snuck into a tatami mat factory in northern Japan and were holed up inside for nearly a day have been captured and killed, according to…

## Japanese gov't aims to seek Unification Church's dissolution on Oct 13
 - [https://japantoday.com/category/national/japan-gov%27t-aims-to-seek-unification-church%27s-dissolution-on-oct.-13](https://japantoday.com/category/national/japan-gov%27t-aims-to-seek-unification-church%27s-dissolution-on-oct.-13)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:25:34+00:00

The Japanese government is making arrangements to seek a court order to disband the Unification Church as early as Oct 13, government sources said Friday.
The move would…

## Bedbugs force closure of seven schools in France
 - [https://japantoday.com/category/world/bedbugs-force-closure-of-seven-schools-in-france-minister](https://japantoday.com/category/world/bedbugs-force-closure-of-seven-schools-in-france-minister)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:24:31+00:00

France has been forced to shut seven schools over growing concerns over an infestation of bedbugs, Education Minister Gabriel Attal said Friday.
&quot;Bedbugs were detected at various levels…

## Discovery of Dutch prince's Nazi membership card revives calls for inquiry
 - [https://japantoday.com/category/world/discovery-of-dutch-prince%27s-nazi-membership-card-revives-calls-for-inquiry3](https://japantoday.com/category/world/discovery-of-dutch-prince%27s-nazi-membership-card-revives-calls-for-inquiry3)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:24:19+00:00

The discovery of a Nazi membership card in the name of late Dutch Prince Bernhard, a German who married into the Dutch royal family in the 1930s, revived…

## 18 migrants killed, and 29 injured in a bus crash in southern Mexico
 - [https://japantoday.com/category/world/18-migrants-killed-and-27-injured-in-a-bus-crash-in-southern-mexico](https://japantoday.com/category/world/18-migrants-killed-and-27-injured-in-a-bus-crash-in-southern-mexico)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:24:07+00:00

At least 18 migrants from Venezuela and Peru died early Friday in a bus crash in southern Mexico, authorities said.
Mexico's National Immigration Institute said the dead include…

## French ex-president Sarkozy charged in witness tampering probe
 - [https://japantoday.com/category/world/french-ex-president-sarkozy-charged-in-witness-tampering-probe](https://japantoday.com/category/world/french-ex-president-sarkozy-charged-in-witness-tampering-probe)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:23:47+00:00

Former French President Nicolas Sarkozy was on Friday charged as part of an investigation into possible witness tampering, adding to his long list of legal woes, including over…

## Trump's New York civil fraud trial rolls on after an appeals judge declines to halt it
 - [https://japantoday.com/category/world/donald-trump%E2%80%99s-lawyers-seek-to-halt-civil-fraud-trial-and-block-ruling-disrupting-real-estate-empire](https://japantoday.com/category/world/donald-trump%E2%80%99s-lawyers-seek-to-halt-civil-fraud-trial-and-block-ruling-disrupting-real-estate-empire)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:23:37+00:00

Former President Donald Trump’s civil fraud trial will roll ahead next week after he lost a bid Friday to postpone it.
Trump wanted to halt the trial while…

## U.S. expels two Russian diplomats to retaliate for expulsion of two American diplomats from Moscow
 - [https://japantoday.com/category/world/us-expels-two-russian-diplomats-to-retaliate-for-the-expulsion-of-two-american-diplomats-from-moscow](https://japantoday.com/category/world/us-expels-two-russian-diplomats-to-retaliate-for-the-expulsion-of-two-american-diplomats-from-moscow)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:23:27+00:00

The Biden administration on Friday ordered two Russian diplomats expelled from the United States in retaliation for the expulsion of two U.S. diplomats from Moscow last month. 
The…

## Turkey steps up strikes on militants as conflict escalates in Syria
 - [https://japantoday.com/category/world/turkey-steps-up-strikes-on-militants-as-conflict-escalates-in-syria4](https://japantoday.com/category/world/turkey-steps-up-strikes-on-militants-as-conflict-escalates-in-syria4)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:23:09+00:00

Turkish security forces attacked Kurdish militants in northern Syria and eastern Turkey, and Ankara said it will continue to destroy their capabilities across the region as conflict escalated…

## Russian lawmakers to consider rescinding ratification of global nuclear test ban, speaker says
 - [https://japantoday.com/category/world/russian-lawmakers-will-consider-rescinding-ratification-of-global-nuclear-test-ban-speaker-says](https://japantoday.com/category/world/russian-lawmakers-will-consider-rescinding-ratification-of-global-nuclear-test-ban-speaker-says)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:22:45+00:00

Russian lawmakers will consider revoking the ratification of a global nuclear test ban, the parliament speaker said Friday.
The statement from Vyacheslav Volodin, the speaker of the lower…

## EU summit points to reforms bloc needs in order to welcome Ukraine and others as new members
 - [https://japantoday.com/category/world/eu-summit-to-look-at-changes-the-bloc-needs-to-make-to-welcome-ukraine-others-as-new-members](https://japantoday.com/category/world/eu-summit-to-look-at-changes-the-bloc-needs-to-make-to-welcome-ukraine-others-as-new-members)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:22:19+00:00

European Union leaders acknowledged Friday that just as aspiring members must meet exacting criteria to join the bloc, the 27 member nations also must work hard to reform…

## Joseph makes one changes for crunch match against Argentina
 - [https://japantoday.com/category/rugby-world-cup-2023/joseph-changes-one-for-crunch-japan-match-against-argentina](https://japantoday.com/category/rugby-world-cup-2023/joseph-changes-one-for-crunch-japan-match-against-argentina)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:21:26+00:00

Japan coach Jamie Joseph has made just one change to his starting XV from their 28-22 victory against Samoa for the crunch World Cup match against Argentina in…

## The price tags and perils of being a prostitute in Shinjuku
 - [https://japantoday.com/category/features/kuchikomi/The-price-tags-and-perils-of-being-a-prostitute-in-Shinjuku](https://japantoday.com/category/features/kuchikomi/The-price-tags-and-perils-of-being-a-prostitute-in-Shinjuku)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:13:38+00:00

Coming on the heels of the hottest September in recorded history, October 2023 will be remembered as the month when the Tokyo Metropolitan Police Department launched the biggest…

## Toranomon Hills Station Tower opens
 - [https://japantoday.com/category/picture-of-the-day/toranomon-hills-station-tower-opens](https://japantoday.com/category/picture-of-the-day/toranomon-hills-station-tower-opens)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:12:10+00:00

From left: Guillaume Paupy, managing director of Hotel Toranomon Hills, Akiyoshi Yamamura, president of Tokyo Metro, Mori Building Co CEO Shingo Tsuji, Masahiro Nakajima, president of the Urban…

## The price tags and perils of being a prostitution in Shinjuku
 - [https://japantoday.com/category/features/kuchikomi/the-price-tags-and-perils-of-being-a-prostitution-in-shinjuku](https://japantoday.com/category/features/kuchikomi/the-price-tags-and-perils-of-being-a-prostitution-in-shinjuku)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T21:00:06+00:00

Coming on the heels of the hottest September in recorded history, October 2023 will be remembered as the month when the Tokyo Metropolitan Police Department launched the biggest…

## Jailed Iranian activist Narges Mohammadi wins 2023 Nobel Peace Prize
 - [https://japantoday.com/category/world/jailed-iranian-activist-narges-mohammadi-wins-2023-nobel-peace-prize2](https://japantoday.com/category/world/jailed-iranian-activist-narges-mohammadi-wins-2023-nobel-peace-prize2)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T10:05:05+00:00

Narges Mohammadi, an Iranian women's rights advocate serving 12 years in jail, won the 2023 Nobel Peace Prize on Friday in a decision likely to anger Tehran.
The…

## Japan household spending falls 2.5% in August on rising prices
 - [https://japantoday.com/category/business/update1-japan-household-spending-falls-2.5-in-august-on-rising-prices](https://japantoday.com/category/business/update1-japan-household-spending-falls-2.5-in-august-on-rising-prices)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T07:38:28+00:00

Japan's household spending in August dropped 2.5 percent from a year earlier, declining for the sixth consecutive month, as rising prices prompted people to cut back on food…

## 78-year-old woman goes on trial for attempted murder of 9-year-old grandson
 - [https://japantoday.com/category/crime/78-year-old-woman-goes-on-trial-for-attempted-murder-of-9-year-old-grandson](https://japantoday.com/category/crime/78-year-old-woman-goes-on-trial-for-attempted-murder-of-9-year-old-grandson)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T07:36:22+00:00

A 78-year-old woman pleaded guilty to the attempted murder of her 9-year-old grandson at their home in Katori, Chiba Prefecture, in March, at the opening session of her…

## Russia open to potential dialogue offer from Japan, Putin says
 - [https://japantoday.com/category/politics/russia-open-to-potential-dialogue-offer-from-japan-putin-says](https://japantoday.com/category/politics/russia-open-to-potential-dialogue-offer-from-japan-putin-says)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T07:34:52+00:00

Russia is ready to accept Japan's potential offer of dialogue, President Vladimir Putin said, according to local media, at a time when bilateral relations have deteriorated sharply in…

## Reports Sapporo will drop 2030 Winter Games bid draw mixed reaction
 - [https://japantoday.com/category/sports/update1-reports-sapporo-will-drop-2030-winter-games-bid-draw-mixed-reaction](https://japantoday.com/category/sports/update1-reports-sapporo-will-drop-2030-winter-games-bid-draw-mixed-reaction)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T07:34:38+00:00

Residents of Sapporo showed a mixed reaction Friday after multiple sources said the city will abandon its bid to host the 2030 Winter Olympics and Paralympics.
The city…

## South Korea to face Japan in Asian Games soccer final, with military exemptions on the line
 - [https://japantoday.com/category/sports/south-korea-to-face-japan-in-asian-games-soccer-final-with-military-exemptions-on-the-line](https://japantoday.com/category/sports/south-korea-to-face-japan-in-asian-games-soccer-final-with-military-exemptions-on-the-line)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T07:06:45+00:00

South Korea’s under-24 players are preparing for the biggest game of their careers on Saturday, but standing between Asian Games gold and military exemption is traditional foe Japan.…

## Italy and Britain pledge joint action against 'illegal migration'
 - [https://japantoday.com/category/world/italy-and-britain-pledge-joint-action-against-%27illegal-migration%27](https://japantoday.com/category/world/italy-and-britain-pledge-joint-action-against-%27illegal-migration%27)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T06:57:58+00:00

Italy and Britain want to lead the way in Europe in the fight against &quot;illegal migration&quot;, the right-wing prime ministers of the two countries said in a joint…

## Millions of children displaced due to extreme weather events
 - [https://japantoday.com/category/world/millions-of-children-are-displaced-due-to-extreme-weather-events.-climate-change-will-make-it-worse](https://japantoday.com/category/world/millions-of-children-are-displaced-due-to-extreme-weather-events.-climate-change-will-make-it-worse)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T04:05:04+00:00

Storms, floods, fires and other extreme weather events led to more than 43 million displacements involving children between 2016 and 2021, according to a United Nations report.
More…

## U.S. regulator says Musk dodging Twitter share buy questions
 - [https://japantoday.com/category/business/us-regulator-says-musk-dodging-twitter-share-buy-questions](https://japantoday.com/category/business/us-regulator-says-musk-dodging-twitter-share-buy-questions)
 - RSS feed: https://japantoday.com/feed
 - date published: 2023-10-06T02:03:23+00:00

U.S. market regulators on Thursday asked a judge to order Elon Musk to comply with a subpoena to answer questions about his purchases of Twitter shares last year.…

