# Source:Wydarzenia Interia - Polska, URL:https://wydarzenia.interia.pl/polska/feed, language:pl-PL

## Wybory 2023. Co załatwisz przez internet? Lista jest długa
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-co-zalatwisz-przez-internet-lista-jest-dluga,nId,7071148](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-co-zalatwisz-przez-internet-lista-jest-dluga,nId,7071148)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-06T12:50:50+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-co-zalatwisz-przez-internet-lista-jest-dluga,nId,7071148"><img align="left" alt="Wybory 2023. Co załatwisz przez internet? Lista jest długa" src="https://i.iplsc.com/wybory-2023-co-zalatwisz-przez-internet-lista-jest-dluga/000HRCZRIML4QH5A-C321.jpg" /></a>Wybory parlamentarne 2023 do Sejmu i Senatu zbliżają się wielkimi krokami. Niektóre osoby chcące załatwić sprawy związane z wyborami muszą się pospieszyć. Na szczęście w wielu przypadkach można to zrobić za pośrednictwem internetu. Jakie wnioski związane z wyborami parlamentarnymi można wysłać przez ePUAP? Odpowiadamy.</p><br clear="all" />

## Atak na biuro senatora Krzysztofa Kwiatkowskiego. "Wyciągnął nóż"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-krzysztofa-kwiatkowskiego-wyciagnal-n,nId,7071387](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-krzysztofa-kwiatkowskiego-wyciagnal-n,nId,7071387)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-06T10:54:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-krzysztofa-kwiatkowskiego-wyciagnal-n,nId,7071387"><img align="left" alt="Atak na biuro senatora Krzysztofa Kwiatkowskiego. &quot;Wyciągnął nóż&quot;" src="https://i.iplsc.com/atak-na-biuro-senatora-krzysztofa-kwiatkowskiego-wyciagnal-n/000HRCDCKX2F0PN3-C321.jpg" /></a>Nieznany mężczyzna z nożem w ręku wtargnął do biura senatora Krzysztofa Kwiatkowskiego. Napastnik miał obrażać parlamentarzystce i grozić współpracowniczce polityka. - Ja rozumiem, że jest kampania wyborcza, ale to nie jest normalne, nie powinno być na to przyzwolenia - powiedziała zaatakowana dyrektorka biura Kwiatkowskiego. Parlamentarzysta zapowiedział zgłoszenie sprawy na policję.</p><br clear="all" />

## Wybory 2023. Politycy walczą o głosy. Relacja na żywo [POLSKA WYBIERA]
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-politycy-walcza-o-glosy-relacja-na-zywo-polska-w,nzId,4822](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-politycy-walcza-o-glosy-relacja-na-zywo-polska-w,nzId,4822)
 - RSS feed: https://wydarzenia.interia.pl/polska/feed
 - date published: 2023-10-06T04:29:36+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/na-zywo-wybory-2023-politycy-walcza-o-glosy-relacja-na-zywo-polska-w,nzId,4822"><img align="left" alt="Wybory 2023. Politycy walczą o głosy. Relacja na żywo [POLSKA WYBIERA]" src="https://i.iplsc.com/wybory-2023-politycy-walcza-o-glosy-relacja-na-zywo-polska-w/000HRAGQQMVJ4W9K-C321.jpg" /></a>Wybory parlamentarne za 9 dni. Politycy niemal wszystkich ugrupowań kontynuują kampanię i w czwartek ponownie wyruszają w Polskę.</p><br clear="all" />

