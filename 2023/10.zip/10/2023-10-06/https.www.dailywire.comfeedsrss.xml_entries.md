# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Mike Lindell Is Broke, May Lose Legal Team After 2020 Election Lawsuits: ‘We’ve Lost Everything’
 - [https://www.dailywire.com/news/mike-lindell-is-broke-may-lose-legal-team-after-2020-election-lawsuits-weve-lost-everything](https://www.dailywire.com/news/mike-lindell-is-broke-may-lose-legal-team-after-2020-election-lawsuits-weve-lost-everything)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T18:07:33+00:00

Pillow magnate Mike Lindell is broke and millions of dollars behind on legal fees after lengthy court battles over his election fraud claims. Lindell’s legal team filed to separate from him on Thursday, citing “millions of dollars” in unpaid bills. The “My Pillow Guy” said he is not trying to stiff his attorneys, he simply ...

## Top Official For George Santos’ Campaign Pleads Guilty To Multiple Federal Crimes
 - [https://www.dailywire.com/news/top-official-for-george-santos-campaign-pleads-guilty-to-multiple-federal-crimes](https://www.dailywire.com/news/top-official-for-george-santos-campaign-pleads-guilty-to-multiple-federal-crimes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T17:43:14+00:00

Nancy Marks, the former campaign treasurer for Rep. George Santos (R-NY), pled guilty this week to multiple federal charges stemming from her role in falsely reporting that Santos made a $500,000 loan to his campaign to make it appear as though he had more support than he really had. Marks pleaded guilty to committing wire ...

## Travis Kelce Responds To Aaron Rodgers Calling Him ‘Mr. Pfizer’
 - [https://www.dailywire.com/news/travis-kelce-responds-to-aaron-rodgers-calling-him-mr-pfizer](https://www.dailywire.com/news/travis-kelce-responds-to-aaron-rodgers-calling-him-mr-pfizer)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T17:39:08+00:00

Chiefs&#8217; star player Travis Kelce responded to New York Jets quarterback Aaron Rodgers calling him Mr. Pfizer and joked, &#8220;Who knew I would get into the vax wars with Aaron Rodgers&#8221; after Kelce appeared in an ad for the pharmaceutical company. During a press conference on Friday, the Kansas City tight end laughed about the ...

## Chicago’s Migrant Housing Plan Would Boot Youth Football Team, Angry Residents Say
 - [https://www.dailywire.com/news/chicagos-migrant-housing-plan-would-boot-youth-football-team-angry-residents-say](https://www.dailywire.com/news/chicagos-migrant-housing-plan-would-boot-youth-football-team-angry-residents-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T17:28:42+00:00

Chicago&#8217;s plan to house illegal migrants in a field house at a local park would kick out a youth football team, according to angry residents. On Monday, Alderman Chris Taliaferro said he was informed that the city plans to house about 200 migrants in the Amundsen Park field house in northwest Chicago. The migrants will ...

## Life’s Tough. Get A Helmet, Man.
 - [https://www.dailywire.com/news/lifes-tough-get-a-helmet-man](https://www.dailywire.com/news/lifes-tough-get-a-helmet-man)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T17:27:15+00:00

Raise your hand if you have ever felt personally victimized by Candace Owens. Apparently some college students have, as I learned earlier this week when I visited a college campus in Albany, New York. Being eight months pregnant, I’ve lost any tolerance I had for nonsense, but even prior to pregnancy, when I compare the ...

## Ohio Attorney General: Proposed Constitutional Amendment Would Legalize All Abortion
 - [https://www.dailywire.com/news/ohio-attorney-general-proposed-constitutional-amendment-would-legalize-all-abortion](https://www.dailywire.com/news/ohio-attorney-general-proposed-constitutional-amendment-would-legalize-all-abortion)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T16:32:15+00:00

Next month, Ohio voters may effectively legalize all abortion, at any stage of pregnancy and for any reason. Ohio Attorney General Dave Yost issued a legal analysis on Thursday declaring that the proposed constitutional amendment on abortion would give greater rights to abortion than even the Supreme Court’s overturned Roe v. Wade ruling. “[T]he Amendment ...

## Left-Wing Activists Are Dying By Their Own Ideology
 - [https://www.dailywire.com/news/left-wing-activists-are-dying-by-their-own-ideology](https://www.dailywire.com/news/left-wing-activists-are-dying-by-their-own-ideology)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T15:54:04+00:00

The other day I talked briefly about the murder of Ryan Carson. He&#8217;s the 32-year-old reported Antifa activist who was stabbed to death around 4:00 a.m. in Brooklyn on Monday. I said that, among other things, his killing shows the importance of knowing your surroundings and taking proactive steps to protect yourself and your family. ...

## Chris Rock In Final Negotiations To Direct Martin Luther King Jr. Movie
 - [https://www.dailywire.com/news/chris-rock-in-final-negotiations-to-direct-martin-luther-king-jr-movie](https://www.dailywire.com/news/chris-rock-in-final-negotiations-to-direct-martin-luther-king-jr-movie)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T15:36:10+00:00

Chris Rock is in final negotiations to direct and produce a Martin Luther King Jr. biopic for Universal based on Jonathan Eig&#8217;s 2023 biography &#8220;King: A Life,&#8221; according to The Hollywood Reporter. Eig&#8217;s critically acclaimed book is based on the recent release of FBI documents, letters, oral histories and other material, along with White House ...

## Tom Hanks And Steven Spielberg’s Next WWII Series To Finally Air After Over A Decade Of Delays
 - [https://www.dailywire.com/news/tom-hanks-and-steven-spielbergs-next-wwii-series-to-finally-air-after-over-a-decade-of-delays](https://www.dailywire.com/news/tom-hanks-and-steven-spielbergs-next-wwii-series-to-finally-air-after-over-a-decade-of-delays)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T15:21:58+00:00

Tom Hanks and Steven Spielberg&#8216;s next WWII miniseries, &#8220;Masters of the Air,&#8221; has finally gotten an air date after over a decade of delays. Originally announced by HBO back in 2013, the show is set now to release on January 26, 2024, with a two-episode debut and will continue with one episode per week until ...

## CRIME AT COLONY RIDGE: Teen Abducted In Heavily Scrutinized Texas Development, Two Suspects On The Run
 - [https://www.dailywire.com/news/crime-at-colony-ridge-teen-abducted-in-heavily-scrutinized-texas-development-two-suspects-on-the-run](https://www.dailywire.com/news/crime-at-colony-ridge-teen-abducted-in-heavily-scrutinized-texas-development-two-suspects-on-the-run)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T15:13:08+00:00

A teen was abducted, beaten, and shot at on the public street in Texas’s Colony Ridge development, which has become a hotbed for crime and is the subject of a special legislative session next week.

## Ukraine ‘Corrupt At All Levels Of Society,’ Not Ready To Join E.U., Former European Commission President Says
 - [https://www.dailywire.com/news/ukraine-corrupt-at-all-levels-of-society-not-ready-to-join-e-u-former-european-commission-president-says](https://www.dailywire.com/news/ukraine-corrupt-at-all-levels-of-society-not-ready-to-join-e-u-former-european-commission-president-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:50:32+00:00

Jean-Claude Juncker, the former president of the European Commission, slammed the idea of Ukraine joining the European Union, saying the country must root out the corruption that touches “all levels” of its society.   Juncker, who presided over the European Commission, a governing body within the E.U., from 2014 to 2019, told German outlet Augsburger Allgemeine ...

## Alabama GOP Gov Latest To Send National Guard To Southern Border
 - [https://www.dailywire.com/news/alabama-gop-gov-latest-to-send-national-guard-to-southern-border](https://www.dailywire.com/news/alabama-gop-gov-latest-to-send-national-guard-to-southern-border)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:48:18+00:00

Alabama GOP Governor Kay Ivey will send 275 National Guard troops to the southern border. Numerous other GOP governors have sent National Guard troops to the border, starting with Ohio, which sent 185 troops in 2021. Florida Governor Ron DeSantis sent 800 National Guardsmen to Texas’ border with Mexico in May 2023. Virginia Gov. Glenn ...

## Fired Michigan State Football Coach Provides Text Messages Allegedly Showing Accuser Looking To Get His Money
 - [https://www.dailywire.com/news/fired-michigan-state-football-coach-provides-text-messages-allegedly-showing-accuser-looking-to-get-his-money](https://www.dailywire.com/news/fired-michigan-state-football-coach-provides-text-messages-allegedly-showing-accuser-looking-to-get-his-money)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:46:52+00:00

Michigan State head football coach Mel Tucker’s defense attorneys have released text messages from his accuser allegedly showing she was looking to get money from the wealthy coach. Tucker was fired in September over sexual harassment allegations made by activist Brenda Tracy, who gets paid to speak to schools about sexual violence. She accused Tucker ...

## L.A. School District Indoctrinates 5-Year-Olds With Celebration Of LGBTQ Values
 - [https://www.dailywire.com/news/l-a-school-district-indoctrinates-5-year-olds-with-celebration-of-lgbtq-values](https://www.dailywire.com/news/l-a-school-district-indoctrinates-5-year-olds-with-celebration-of-lgbtq-values)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:38:30+00:00

Starting next week, many children as young as 5 who attend Los Angeles Unified public schools will participate in a weeklong celebration of “National Coming Out Day,” which falls on October 11. The district issued its “Week of Action Toolkit,” emblazoned with a Black Power Fist over neon rainbow stripes and is nominally optional, although ...

## Phone Call Between Trevor Bauer And Lindsey Hill Released
 - [https://www.dailywire.com/news/phone-call-between-trevor-bauer-and-lindsey-hill-released](https://www.dailywire.com/news/phone-call-between-trevor-bauer-and-lindsey-hill-released)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:28:40+00:00

Lindsey Hill, who accused former MLB pitcher Trevor Bauer of rape and assault, had a 27-minute phone conversation with him in the days after the alleged assault. The call was secretly recorded by the Pasadena Police Department with Hill’s cooperation, and was publicly released on Thursday, just days after Bauer revealed text messages showing Hill ...

## Republicans Scrap Potential House Speaker Debate: Report
 - [https://www.dailywire.com/news/republicans-scrap-potential-house-speaker-debate-report](https://www.dailywire.com/news/republicans-scrap-potential-house-speaker-debate-report)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:10:13+00:00

Plans for a televised debate involving candidates for House speaker were scrapped after the two announced contenders reportedly agreed that such an event &#8220;wouldn&#8217;t be wise.&#8221; Fox News was reportedly planning to host a televised speaker debate between Republican Reps. Jim Jordan of Ohio and Steve Scalise of Louisiana on Monday night, according to Punch ...

## ‘The Wonder Years’ Star Danica McKellar Discusses ‘Quality Of Life Improvement’ After Moving To Red State
 - [https://www.dailywire.com/news/the-wonder-years-star-danica-mckellar-discusses-quality-of-life-improvement-after-moving-to-red-state](https://www.dailywire.com/news/the-wonder-years-star-danica-mckellar-discusses-quality-of-life-improvement-after-moving-to-red-state)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T14:07:37+00:00

Actress Danica McKellar of “The Wonder Years” fame is just another celebrity who’s embracing life outside of Los Angeles. The 48-year-old star gushed about some of the things she loves about living in Tennessee while speaking with Fox News Digital.  &#8220;Tennessee is a total quality of life improvement. It’s gorgeous, I love the seasons,&#8221; McKellar ...

## Full Woke: Disney And Netflix Created The Most ‘LGBTQ-Inclusive’ Content In 2022
 - [https://www.dailywire.com/news/full-woke-disney-and-netflix-created-the-most-lgbtq-inclusive-content-in-2022](https://www.dailywire.com/news/full-woke-disney-and-netflix-created-the-most-lgbtq-inclusive-content-in-2022)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T13:36:27+00:00

Netflix and Disney are responsible for pushing the gay agenda and creating the most LGBTQ content in Hollywood for movies in 2022, with an overall 8% increase over the prior year. GLAAD&#8217;s Annual Studio Responsibility Index was released on Monday and showed that of the top 10 major motion picture studios that were analyzed, Disney ...

## How COVID Edicts From Fauci And The Elites Produced Public Rebels
 - [https://www.dailywire.com/news/how-covid-edicts-from-fauci-and-the-elites-produced-public-rebels](https://www.dailywire.com/news/how-covid-edicts-from-fauci-and-the-elites-produced-public-rebels)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T11:45:23+00:00

The following excerpt is taken from the new book Deception: The Great Covid Cover-Up, by Rand Paul, (Regnery Publishing, October 2023) In April of 2020, Martin Kulldorff, Harvard professor of medicine and one of the world’s most respected biostatisticians and epidemiologists, wrote an article called “COVID-19 Counter Measures Should Be Age Specific” and posted it ...

## Chris Hemsworth Said He’s Taking These Steps To Combat Increased Alzheimer’s Risk
 - [https://www.dailywire.com/news/chris-hemsworth-said-hes-taking-these-steps-to-combat-increased-alzheimers-risk](https://www.dailywire.com/news/chris-hemsworth-said-hes-taking-these-steps-to-combat-increased-alzheimers-risk)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T11:20:46+00:00

Chris Hemsworth says he’s making some lifestyle changes after a genetic test revealed he has a higher-than-average risk of developing Alzheimer’s disease. The 40-year-old “Thor” actor said he’s been changing his diet and workout routines, but has also focused on searching for inner peace.  “Now, I&#8217;m incorporating more solitude into my life,” Hemsworth told Men’s ...

## ‘Convicting A Murderer’ Recap: Candace Owens Examines Brendan Dassey’s Disturbing Confession In Episode 7
 - [https://www.dailywire.com/news/convicting-a-murderer-recap-candace-owens-examines-brendan-dasseys-disturbing-confession-in-episode-7](https://www.dailywire.com/news/convicting-a-murderer-recap-candace-owens-examines-brendan-dasseys-disturbing-confession-in-episode-7)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T11:00:20+00:00

Candace Owens examines the details of the disturbing rape and murder confession from Steven Avery’s nephew Brendan Dassey in episode 7 of “Convicting a Murderer.”  The episode, titled “The Vial of Blood,” features key pieces from Dassey’s confession to interrogators, including describing the murder of Teresa Halbach and his uncle’s actions after they killed her. ...

## Josh Duhamel Says Hollywood Can ‘Suck The Soul Out Of You,’ Discusses Reasons For Divorcing Fergie
 - [https://www.dailywire.com/news/josh-duhamel-says-hollywood-can-suck-the-soul-out-of-you-discusses-reasons-for-divorcing-fergie](https://www.dailywire.com/news/josh-duhamel-says-hollywood-can-suck-the-soul-out-of-you-discusses-reasons-for-divorcing-fergie)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T10:44:25+00:00

Actor Josh Duhamel said he’s happy to have left Hollywood behind. The 50-year-old actor discussed his thoughts on returning to his home state of North Dakota and how he’s changed since getting divorced from Black-Eyed Peas singer Fergie. “I don&#8217;t think I ever really got comfortable with all of it,&#8221; he said during a conversation ...

## AOC Calls For Biden To ‘Reverse Course’ On Border Wall Construction: ‘It Is A Cruel Policy’
 - [https://www.dailywire.com/news/aoc-calls-for-biden-to-reverse-course-on-border-wall-construction-it-is-a-cruel-policy](https://www.dailywire.com/news/aoc-calls-for-biden-to-reverse-course-on-border-wall-construction-it-is-a-cruel-policy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T10:39:07+00:00

Rep. Alexandria Ocasio-Cortez (D-NY) blasted President Joe Biden Thursday after his administration announced it would waive dozens of federal laws to begin constructing the southern border wall.  To fight the “high illegal entry” of migrants in recent months, Homeland Security Secretary Alejandro Mayorkas announced Wednesday that he is waiving 26 federal laws through his power ...

## Ed Sheeran Confirms He Dug His Own Grave In The Backyard: ‘People Think It’s Really… Morbid’
 - [https://www.dailywire.com/news/ed-sheeran-confirms-he-dug-his-own-grave-in-the-backyard-people-think-its-really-morbid](https://www.dailywire.com/news/ed-sheeran-confirms-he-dug-his-own-grave-in-the-backyard-people-think-its-really-morbid)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T10:14:06+00:00

Singer Ed Sheeran is extremely prepared for the end of his life, but admits that some people find his methods “morbid.” The 32-year-old British singer-songwriter confirmed a rumor about him having a burial spot ready to go in his backyard. “I wouldn’t say it’s a crypt,” Sheeran told GQ Hype in an interview published on ...

## Hillary Clinton Suggests ‘Formal Deprogramming Of The Cult Members’ Of MAGA
 - [https://www.dailywire.com/news/hillary-clinton-suggests-formal-deprogramming-of-the-cult-members-of-maga](https://www.dailywire.com/news/hillary-clinton-suggests-formal-deprogramming-of-the-cult-members-of-maga)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T09:56:25+00:00

Looks like twice-failed presidential candidate Hillary Clinton still isn&#8217;t over her 2016 loss — and still hasn&#8217;t come to grips with the fact that millions of Americans detest her worldview. On Thursday night, Clinton sat down with CNN&#8217;s international propagandist Christiane Amanpour to discuss a range of issues, including former President Donald J. Trump&#8217;s sustained ...

## ‘World’s Largest’ Women’s Tech Conference Taken Over By Men Identifying As ‘Non-Binary’
 - [https://www.dailywire.com/news/worlds-largest-womens-tech-conference-taken-over-by-men-identifying-as-non-binary](https://www.dailywire.com/news/worlds-largest-womens-tech-conference-taken-over-by-men-identifying-as-non-binary)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T09:44:41+00:00

A career-building conference intended to boost women’s opportunities to get a job in the tech industry was invaded by crowds of men who identified as “non-binary.”  The Grace Hopper Celebration (GHC) event held in Orlando, Florida, from September 26-29 was touted as “the world’s largest gathering of women and non-binary technologists.” A video circulating on ...

## Trump Endorses Jim Jordan For Speaker Of The House
 - [https://www.dailywire.com/news/trump-endorses-jim-jordan-for-speaker-of-the-house](https://www.dailywire.com/news/trump-endorses-jim-jordan-for-speaker-of-the-house)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T07:15:35+00:00

Former President Donald Trump endorsed House Judiciary Committee Chairman Jim Jordan (R-OH) to be the next Speaker of the House after a small number of Republicans teamed up with the entire House Democrat Caucus to oust Rep. Kevin McCarthy (R-CA) from the position this week. The endorsement came after reports from Thursday said that Trump ...

## Police Say ‘No Evidence’ Protester ‘Intentionally Rammed’ Ramaswamy Campaign’s Car; Campaign Stands By Statement
 - [https://www.dailywire.com/news/police-say-no-evidence-protester-intentionally-rammed-ramaswamy-campaigns-car-campaign-stands-by-statement](https://www.dailywire.com/news/police-say-no-evidence-protester-intentionally-rammed-ramaswamy-campaigns-car-campaign-stands-by-statement)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-10-06T00:28:10+00:00

Local Iowa law enforcement officials disputed Republican presidential candidate Vivek Ramaswamy&#8217;s claims on social media on Thursday that two left-wing protesters intentionally rammed their car into his campaign vehicle during an event, saying that there was &#8220;no evidence&#8221; that the people were involved in the protest or that they intentionally crashed their car into his ...

