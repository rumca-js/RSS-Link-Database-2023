# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Do Kosowa przybędzie więcej żołnierzy NATO
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316304,do-kosowa-przybedzie-wiecej-zolnierzy-nato.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316304,do-kosowa-przybedzie-wiecej-zolnierzy-nato.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T20:28:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LsiktkuTURBXy8yMDE4Y2RhYS1jOGIxLTQ2YzctODI3Yi1hYWM0MzUzNmYxZWIuanBlZ5GTBc0BHcyg" />Do Kosowa - z Rumunii i innych krajów sojuszniczych - przybędzie wkrótce więcej żołnierzy NATO; większa liczba wojsk Sojuszu w kraju jest konieczna, by misja mogła spełniać swój mandat - powiedział w piątek dowódca sił pokojowych NATO w Kosowie gen. Angelo Michele Ristuccia, Dodał, że &quot;tylko rozwiązanie polityczne może zapewnić w regionie pokój&quot;.

## Więzień w pracy magisterskiej przyznał się do trzech zbrodni, za które nie został skazany
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316297,wiezien-w-pracy-magisterskiej-przyznal-sie-do-trzech-zbrodni-za-ktore.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316297,wiezien-w-pracy-magisterskiej-przyznal-sie-do-trzech-zbrodni-za-ktore.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T19:31:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dr-ktkuTURBXy8xZmUzMzkzMS01YTllLTQ2OWQtOThjYi00Y2ZkODU1YmJjNTkuanBlZ5GTBc0BHcyg" />33-latek, odbywający karę więzienia w Kalabrii na południu Włoch, obronił tam z wyróżnieniem pracę magisterską z socjologii, w której przyznał się do udziału w trzech zabójstwach mafijnych, za jakie nigdy nie został skazany - podała w piątek prasa. O kopię pracy wystąpiła prokuratura do walki z mafią.

## "WSJ": Pentagon planuje zmiany ws. sił specjalnych
 - [https://forsal.pl/swiat/usa/artykuly/9316218,pentagon-planuje-zmiany-ws-sil-specjalnych.html](https://forsal.pl/swiat/usa/artykuly/9316218,pentagon-planuje-zmiany-ws-sil-specjalnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T18:44:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/OF-ktkuTURBXy83OGM2NTZlMy1mYzQ4LTRiOGItYjZhZi0xOGQyNDkyNGZhNWMuanBlZ5GTBc0BHcyg" />Pentagon planuje zredukowanie liczby żołnierzy sił specjalnych, również legendarnych zielonych beretów, ponieważ uwaga armii przesuwa się z walki z terrorystami na Bliskim Wschodzie ku zagrożeniu ze strony Chin - informuje w piątek &quot;Wall Street Journal&quot;.

## UNESCO stworzy wirtualne muzeum skradzionych obiektów kultury
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316214,unesco-stworzy-wirtualne-muzeum-skradzionych-obiektow-kultury.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316214,unesco-stworzy-wirtualne-muzeum-skradzionych-obiektow-kultury.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T18:04:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3pHktkuTURBXy84MzEwNDdiOS1iZjYyLTQxMDctYTllNi0wYjI4MWIwMDQyZWYuanBlZ5GTBc0BHcyg" />UNESCO stworzy wirtualne muzeum skradzionych obiektów kultury - poinformował w piątek portal Guardian. Na liście Interpolu, na której zbierane są dane o obiektach skradzionych z muzeów, prywatnych zbiorów czy stanowisk archeologicznych, odnotowano 52 tysiące pozycji.

## Holandia przeznaczy dodatkowe 102 mln euro na pomoc Ukrainie
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316208,holandia-przeznaczy-dodatkowe-102-mln-euro-na-pomoc-ukrainie.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316208,holandia-przeznaczy-dodatkowe-102-mln-euro-na-pomoc-ukrainie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T17:52:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1-JktkuTURBXy9iNjIxZTY5ZS0xMjNjLTRmYmMtOWM3NS04ZDMyYTQyYzBhYzMuanBlZ5GTBc0BHcyg" />Holandia przeznaczy 102 mln euro na kolejny, trzeci w tym roku, pakiet pomocowy dla Ukrainy - poinformował w piątek holenderski rząd.

## "Plaga pluskiew" we Francji. Jest reakcja rządu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316207,plaga-pluskiew-we-francji-jest-reakcja-rzadu.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316207,plaga-pluskiew-we-francji-jest-reakcja-rzadu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T17:38:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SXtktkuTURBXy9iYWNkNzVkYy1jNmMxLTQ0MjgtOTMwMS00ZDk2YjBlNjQyOGIuanBlZ5GTBc0BHcyg" />Rząd zapewnia, że „bardzo uważnie” monitoruje sytuację w kwestii pluskiew, których plaga dotyka jakoby Paryż i inne miasta we Francji oraz międzymiastowy transport publiczny. Minister transportu apeluje, by „nie wpadać w psychozę&quot;.

## Szef MON: W Janowie Lubelskim powstanie jednostka wojskowa; będzie to batalion logistyczny
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316205,szef-mon-w-janowie-lubelskim-powstanie-jednostka-wojskowa-bedzie-to-batalion-logistyczny.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316205,szef-mon-w-janowie-lubelskim-powstanie-jednostka-wojskowa-bedzie-to-batalion-logistyczny.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T17:34:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/csKktkuTURBXy81ZWQ1NmU2OC1mNzM3LTRmYTEtYWE0Yy0wMTljOTQ1OTU3ZjMuanBlZ5GTBc0BHcyg" />W Janowie Lubelskiem powstanie jednostka wojskowa; będzie to batalion logistyczny wchodzący w skład 4. Brygady Logistycznej - powiedział na spotkaniu z mieszkańcami tego miasta minister obrony narodowej Mariusz Błaszczak.

## Amazon wystrzeli na orbitę dwa pierwsze satelity systemu Kuiper
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9316200,amazon-wystrzeli-na-orbite-dwa-pierwsze-satelity-systemu-kuiper.html](https://forsal.pl/biznes/aktualnosci/artykuly/9316200,amazon-wystrzeli-na-orbite-dwa-pierwsze-satelity-systemu-kuiper.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T16:54:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/TXbktkuTURBXy8yYjZkYmQ0MC0yN2Q5LTRmZjktYTI5Yy1mNGExZTU5YTVjZmIuanBlZ5GTBc0BHcyg" />Firma Amazon zamierza w piątek wystrzelić na orbitę dwa pierwsze satelity konstelacji Kuiper, która ma docelowo liczyć ponad 3,2 tys. satelitów dostarczających internet. System ten ma być konkurencją dla Starlinka Elona Muska - podaje w piątek amerykański portal Semafor.

## Wybory 2023. Kobiety czy mężczyźni? Kto rzadziej  interesuje się polityką? Oto najnowszy sondaż
 - [https://forsal.pl/gospodarka/polityka/artykuly/9316196,wybory-2023-kobiety-czy-mezczyzni-kto-rzadziej-interesuje-sie-polityka-oto-najnowszy-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9316196,wybory-2023-kobiety-czy-mezczyzni-kto-rzadziej-interesuje-sie-polityka-oto-najnowszy-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T16:39:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LG0ktkuTURBXy85ZmMxZmIwNi0yM2NiLTRjNTUtYWQyYS1lOGZiNWMwNmJmNmYuanBlZ5GTBc0BHcyg" />Kobiety rzadziej interesują się polityką, rzadziej deklarują pewność udziału w wyborach i częściej mają niesprecyzowane poglądy polityczne. W ostatnim czasie nastąpił jednak umiarkowany wzrost zainteresowania tą tematyką wśród Polek – wynika z komunikatu z badań CBOS pt. „Kobiety i polityka”.

## Pakt migracyjny. Czy sprzeciw Polski i Węgier ostatecznie zablokuje porozumienie?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316194,pakt-migracyjny-czy-sprzeciw-polski-i-wegier-ostatecznie-zablokuje-porozumienie.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316194,pakt-migracyjny-czy-sprzeciw-polski-i-wegier-ostatecznie-zablokuje-porozumienie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T16:28:27+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/LobktkuTURBXy9mNjkxM2Y5MS1kODEyLTRhNDAtYjU4Yi0wMWFjODRlMDA0MzQuanBlZ5GTBc0BHcyg" />Prezydent Francji Emmanuel Macron oświadczył w piątek, że choć Polska i Węgry wyraziły swój sprzeciw wobec paktu migracyjnego, nie musi to oznaczać, że ostateczne porozumienie w tej sprawie zostanie zablokowane.

## ARP: Wzrost cen węgla na międzynarodowym rynku
 - [https://forsal.pl/biznes/energetyka/artykuly/9316192,arp-wzrost-cen-wegla-na-miedzynarodowym-rynku.html](https://forsal.pl/biznes/energetyka/artykuly/9316192,arp-wzrost-cen-wegla-na-miedzynarodowym-rynku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T16:19:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1UpktkuTURBXy82MGM0MzYzNi1hZTcxLTQ0YmYtYWE0NS1kMDQ5NjZkNzY0YzUuanBlZ5GTBc0BHcyg" />We wrześniu główne indeksy cen węgla wysokoenergetycznego na międzynarodowym rynku spot drugi miesiąc z rzędu wykazały w krótkim terminie tendencję wzrostową, jednak poziomy notowań były wciąż znacznie niższe od tegorocznych maksimów - wynika z opracowania Agencji Rozwoju Przemysłu (ARP).

## 1,2 mld euro dla przedsiębiorstw energochłonnych. KE zatwierdziła polski program pomocy
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9316189,12-mld-euro-dla-przedsiebiorstw-energochlonnych-ke-zatwierdzila-pols.html](https://forsal.pl/swiat/unia-europejska/artykuly/9316189,12-mld-euro-dla-przedsiebiorstw-energochlonnych-ke-zatwierdzila-pols.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T15:54:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gKBktkuTURBXy8xN2Q5YjAyNC1lNTc3LTRiYTAtOGU1Yi1iODA2M2Q4N2UwYTkuanBlZ5GTBc0BHcyg" />Komisja Europejska zatwierdziła w piątek polski program pomocy państwowej o wartości 1,2 mld euro (5,5 mld złotych), mający na celu wsparcie energochłonnych przedsiębiorstw, borykających się z rosnącymi kosztami energii w kontekście wojny Rosji z Ukrainą.

## Premier po szczycie RE: Przedstawiłem 5-punktowy plan
 - [https://forsal.pl/gospodarka/artykuly/9316187,premier-po-szczycie-re-przedstawilem-5-punktowy-plan.html](https://forsal.pl/gospodarka/artykuly/9316187,premier-po-szczycie-re-przedstawilem-5-punktowy-plan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T15:47:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KHFktkuTURBXy82ZDE3Nzk5Yy0yNDI3LTQxYmEtODRmMS0wNDc4ZTZjNTFiMjkuanBlZ5GTBc0BHcyg" />Przedstawiłem 5-punktowy plan walki z nielegalnymi imigrantami. To m.in. silna ochrona granic zewnętrznych i zdecydowana walka z przemytnikami ludzi - powiedział w piątek w Grenadzie premier Mateusz Morawiecki. Zaznaczył, że brakuje np. wzmocnionej kontroli poprzez statki przybrzeżne Straży Granicznej na całym Morzu Śródziemnym.

## Złoty w piątek umocnił się wobec głównych walut
 - [https://forsal.pl/finanse/waluty/artykuly/9316183,zloty-w-piatek-umocnil-sie-wobec-glownych-walut.html](https://forsal.pl/finanse/waluty/artykuly/9316183,zloty-w-piatek-umocnil-sie-wobec-glownych-walut.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T15:23:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ESwktkuTURBXy8xZDRiMmVlZS01NTI3LTQ1YjUtODBhNS1lZGVlMjgwNjJjZDMuanBlZ5GTBc0BHcyg" />W piątek ok. godz. 17.00 złoty umocnił się wobec euro, dolara amerykańskiego i franka szwajcarskiego. Euro kosztowało prawie 4,59 zł, dolar 4,35 zł, a frank 4,76 zł.

## Media: Trump ujawnił tajemnice o nuklearnych okrętach podwodnych
 - [https://forsal.pl/swiat/usa/artykuly/9316167,media-trump-ujawnil-tajemnice-o-nuklearnych-okretach-podwodnych.html](https://forsal.pl/swiat/usa/artykuly/9316167,media-trump-ujawnil-tajemnice-o-nuklearnych-okretach-podwodnych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T14:49:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-K7ktkuTURBXy82YjY2YWVkOS0yYmVjLTRlMTctYTA4Mi00ZTZkNTQxODc0OGQuanBlZ5GTBc0BHcyg" />Były prezydent Donald Trump ujawnił tajemnice nt. nuklearnych okrętów podwodnych australijskiemu miliarderowi Anthony'emu Prattowi, zdradzając mu szczegóły dotyczące zdolności okrętów - podały w czwartek ABC News i &quot;New York Times&quot;. Pratt miał później powtórzyć te informacje dziesiątkom osób.

## Blisko 900 osób doznało zatrucia po zjedzeniu "płynącego makaronu"
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9316162,blisko-900-osob-doznalo-zatrucia-po-zjedzeniu-plynacego-makaronu.html](https://forsal.pl/swiat/aktualnosci/artykuly/9316162,blisko-900-osob-doznalo-zatrucia-po-zjedzeniu-plynacego-makaronu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T14:19:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KAgktkuTURBXy9kNjE3NmMxZS1kNjdiLTQ4N2EtYjdiNy1iYWRjZWFhYTYyYTQuanBlZ5GTBc0BHcyg" />862 osoby doznały zatrucia pokarmowego po zjedzeniu posiłku w restauracji serwującej tzw. płynący makaron – nagashi somen – w mieście Tsubata w prefekturze Ishikawa, leżącej w środkowej części japońskiej wyspy Honsiu – pisze w piątek dziennik &quot;Asahi Shimbun&quot;.

## Warsaw Security Forum. Straciliśmy okazję, by nie siedzieć cicho [OPINIA]
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316148,warsaw-security-forum-stracilismy-okazje-by-nie-siedziec-cicho-opin.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316148,warsaw-security-forum-stracilismy-okazje-by-nie-siedziec-cicho-opin.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T14:12:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2dOktkuTURBXy9hMDQyMTYyMS0yNzVlLTRkYjUtOTE4Ny04NTY1NTc1ZjMxNjIuanBlZ5GTBc0BHcyg" />Wyszło głupio. Nie było nas tam, a mówili o nas. Na Warsaw Security Forum, bez mała największym wydarzeniu polityczno-dyplomatycznym w tym roku nad Wisłą, zabrakło wysokich rangą polskich urzędników - pisze w opinii Mateusz Obremski.

## Wybory 2023. Na kogo głosować? Google ujawnił, o co w internecie pytają Polacy
 - [https://forsal.pl/gospodarka/polityka/artykuly/9316155,wybory-2023-na-kogo-glosowac-google-ujawnil-o-co-w-internecie-pytaj.html](https://forsal.pl/gospodarka/polityka/artykuly/9316155,wybory-2023-na-kogo-glosowac-google-ujawnil-o-co-w-internecie-pytaj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T14:06:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YhbktkuTURBXy84NzBjZGRmMi03MzY5LTRjM2MtODQ5ZC05MGRlMTQ0Y2IyN2MuanBlZ5GTBc0BHcyg" />„Na kogo głosować 2023”, „na kogo zagłosują młodzi ludzie” i „na jaką partię powinienem głosować?” – to trzy z pięciu najczęściej wyszukiwanych w internecie fraz związanych z wyborami w Polsce. Dane Google potwierdzają, że właśnie toczy się gra o niezdecydowanych.

## Rzecznik PO: Jarosław Kaczyński ucieka przed debatą z Donaldem Tuskiem
 - [https://forsal.pl/gospodarka/polityka/artykuly/9316142,rzecznik-po-jaroslaw-kaczynski-ucieka-przed-debata-z-donaldem-tuskiem.html](https://forsal.pl/gospodarka/polityka/artykuly/9316142,rzecznik-po-jaroslaw-kaczynski-ucieka-przed-debata-z-donaldem-tuskiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T13:37:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/No-ktkuTURBXy8wYWM5MzBiMy0yODFhLTQwMzUtYjZiMy05YWU4M2I0YjFjZDguanBlZ5GTBc0BHcyg" />Prezes PiS Jarosław Kaczyński od miesięcy mówi głównie o liderze PO Donaldzie Tusku, ale ucieka, kiedy ma okazje skonfrontować się z nim w debacie; to strach przed przegraną - mówił w piątek rzecznik PO Jan Grabiec.

## Stopa bezrobocia w USA. Są najnowsze dane
 - [https://forsal.pl/praca/bezrobocie/artykuly/9316134,stopa-bezrobocia-w-usa-sa-najnowsze-dane.html](https://forsal.pl/praca/bezrobocie/artykuly/9316134,stopa-bezrobocia-w-usa-sa-najnowsze-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T13:20:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MFIktkuTURBXy8xZDZhODZlNi03MDBlLTQyZmQtOGMyNS1jMDk4NTViZjY3NzQuanBlZ5GTBc0BHcyg" />undefined

## Wybory landowe w Bawarii i Hesji w niedzielę. 28 proc. uprawnionych nie wie na kogo odda głos
 - [https://forsal.pl/gospodarka/polityka/artykuly/9316113,wybory-landowe-w-bawarii-i-hesji-w-niedziele-28-proc-uprawnionych-ni.html](https://forsal.pl/gospodarka/polityka/artykuly/9316113,wybory-landowe-w-bawarii-i-hesji-w-niedziele-28-proc-uprawnionych-ni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T13:02:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qvFktkuTURBXy8yZDU3N2JiZC1hNGVjLTRhMDQtOWU4Yi02MmM5N2NmNDY1ZmMuanBlZ5GTBc0BHcyg" />Na krótko przed wyborami landowymi w Bawarii chadecka partia CSU nadal ma zdecydowanie największe poparcie, wynika z najnowszego sondażu &quot;Politbarometer&quot; dla telewizji ZDF. W Hesji, gdzie wybory - podobnie jak w Bawarii - odbędą się w niedzielę, prowadzi chadecka CDU.

## Rewolucja w Dreamlinerach LOT-u. Samoloty zyskają nowe wnętrza [WIZUALIZACJE]
 - [https://forsal.pl/transport/lotnictwo/artykuly/9316114,rewolucja-w-dreamlinerach-lot-u-samoloty-zyskaja-nowe-wnetrza-wizual.html](https://forsal.pl/transport/lotnictwo/artykuly/9316114,rewolucja-w-dreamlinerach-lot-u-samoloty-zyskaja-nowe-wnetrza-wizual.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T13:02:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BdTktktTURBXy8xNzI3NDJlNy03YWE5LTQ0MzgtOTk1OS02ZmYzZTlmYzYwY2IucG5nkZMFzQEdzKA" />Wnętrza szerokokadłubowych boeingów 787 Dreamliner LOT-u czeka prawdziwa rewolucja. Pojawią się m.in. nowe fotele i wystrój. Jednocześnie pasażerowie zyskają w czasie rejsu dostęp do internetu.

## BBC: Rosja próbowała stworzyć brygadę najemników z Serbii
 - [https://forsal.pl/swiat/rosja/artykuly/9316090,bbc-rosja-probowala-stworzyc-brygade-najemnikow-z-serbii.html](https://forsal.pl/swiat/rosja/artykuly/9316090,bbc-rosja-probowala-stworzyc-brygade-najemnikow-z-serbii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T12:53:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/QADktkuTURBXy81ODdhYWQxNS04ZTlkLTQ3ZTYtOGM3Ni00YzI1MzJjMDBiNjkuanBlZ5GTBc0BHcyg" />Rosja próbowała sformować brygadę najemników z Serbii w ramach jednej z dywizji wojsk powietrznodesantowych, lecz te działania nie przyniosły oczekiwanych efektów; dotychczas udało się zwerbować zaledwie około 100 Serbów - poinformowała w piątek rosyjska redakcja stacji BBC.

## Kolejny zestaw Bayraktarów przeszedł pomyślnie testy w Bazie w Mirosławcu
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316034,kolejny-zestaw-bayraktarow-przeszedl-pomyslnie-testy-w-bazie-w-mirosla.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9316034,kolejny-zestaw-bayraktarow-przeszedl-pomyslnie-testy-w-bazie-w-mirosla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T12:04:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KRyktkuTURBXy82NzJhZTkzYy01NWI4LTQyYmEtYTI0YS1jZjViZDYxMDlkZDUuanBlZ5GTBc0BHcyg" />Zakończyliśmy odbiór trzeciego zestawu bezzałogowców - poinformował w piątek minister obrony narodowej Mariusz Błaszczak. Przekazał, że kolejne drony Bayraktar są już po testach w 12 Bazie Bezzałogowych Statków Powietrznych w Mirosławcu.

## Artifex Mundi miał wstępnie 23,6 mln zł przychodów w III kw. 2023r., wzrost o 166 %
 - [https://forsal.pl/finanse/gielda/artykuly/9316033,artifex-mundi-mial-wstepnie-236-mln-zl-przychodow-w-iii-kw-2023r-w.html](https://forsal.pl/finanse/gielda/artykuly/9316033,artifex-mundi-mial-wstepnie-236-mln-zl-przychodow-w-iii-kw-2023r-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T12:04:14+00:00



## Backlog Synektik wyniósł szacunkowo 75 mln zł na koniec września
 - [https://forsal.pl/finanse/gielda/artykuly/9316026,backlog-synektik-wyniosl-szacunkowo-75-mln-zl-na-koniec-wrzesnia.html](https://forsal.pl/finanse/gielda/artykuly/9316026,backlog-synektik-wyniosl-szacunkowo-75-mln-zl-na-koniec-wrzesnia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:59:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fBMktkuTURBXy81ZTVlNDFlNy1hMzE1LTRlMGMtYmRjZS02NDlhZGZmZTk3NWIuanBlZ5GTBc0BHcyg" />undefined

## Huuuge miało wstępnie 72 mln USD przychodów w III kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9316025,huuuge-mialo-wstepnie-72-mln-usd-przychodow-w-iii-kw-2023-r.html](https://forsal.pl/finanse/gielda/artykuly/9316025,huuuge-mialo-wstepnie-72-mln-usd-przychodow-w-iii-kw-2023-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:57:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hTdktkuTURBXy9mYWYxOTM2ZC0zMmI0LTRiYWEtYTFlYS1iN2ZiYTMxZmM3ODIuanBlZ5GTBc0BHcyg" />undefined

## Atak na biuro senatora Kwiatkowskiego w Łodzi. Mężczyzna z nożem groził jego dyrektorce
 - [https://forsal.pl/gospodarka/polityka/artykuly/9316021,atak-na-biuro-senatora-kwiatkowskiego-w-lodzi-mezczyzna-z-nozem-grozi.html](https://forsal.pl/gospodarka/polityka/artykuly/9316021,atak-na-biuro-senatora-kwiatkowskiego-w-lodzi-mezczyzna-z-nozem-grozi.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:54:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SmLktkuTURBXy9lM2RiN2FmMC02NDA1LTRjOGEtOWM4Yy0wN2NjNjRkZGJhYzMuanBlZ5GTBc0BHcyg" />Do biura senatora Krzysztofa Kwiatkowskiego, startującego w wyborach w ramach paktu senackiego, wszedł w piątek mężczyzna, który najpierw miał wyrażać się obelżywie o polityku, obrażał też dyrektorkę biura, po czym wyjął nóż i zaczął nim jej grozić.

## W ofercie publ. Polenergii objęto 10,42 mln akcji AB, redukcja zapisów dodatkowych 80,62 proc.
 - [https://forsal.pl/finanse/gielda/artykuly/9316020,w-ofercie-publ-polenergii-objeto-1042-mln-akcji-ab-redukcja-zapisow.html](https://forsal.pl/finanse/gielda/artykuly/9316020,w-ofercie-publ-polenergii-objeto-1042-mln-akcji-ab-redukcja-zapisow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:54:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## Holenderska policja o zatrzymaniu piłkarzy Legii Warszawa w Alkmaar: Powodem aresztowania była napaść
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9316008,holenderska-policja-o-zatrzymaniu-pilkarzy-legii-warszawa-w-alkmaar-p.html](https://forsal.pl/swiat/unia-europejska/artykuly/9316008,holenderska-policja-o-zatrzymaniu-pilkarzy-legii-warszawa-w-alkmaar-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:34:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/s1gktkuTURBXy85ZTg0NDQ3OC01YmNjLTQ3OTktOGQ0MC0yZTJkZjk5MTc0MGIuanBlZ5GTBc0BHcyg" />Holenderska policja poinformowała PAP, że w związku z wydarzeniami, do których doszło w czwartek wieczorem po meczu piłkarskim AZ Alkmaar - Legia Warszawa w Alkmaar, aresztowano dwie osoby.

## Echo Investment chce wypłacić 0,22 zł za akcję zaliczki na dywidendę za 2023 r.
 - [https://forsal.pl/finanse/artykuly/9316004,echo-investment-chce-wyplacic-022-zl-za-akcje-zaliczki-na-dywidende-z.html](https://forsal.pl/finanse/artykuly/9316004,echo-investment-chce-wyplacic-022-zl-za-akcje-zaliczki-na-dywidende-z.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:32:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZQZktkuTURBXy9jM2ZkOTgzNC0zYzhiLTRjOGEtYWU5OC1iMzFmODQ5ZjRkMTEuanBlZ5GTBc0BHcyg" />undefined

## Creotech Instruments zaoferuje inwestorom 396 557 akcji serii J w cenie emisyjnej 150 zł
 - [https://forsal.pl/finanse/gielda/artykuly/9316001,creotech-instruments-zaoferuje-inwestorom-396-557-akcji-serii-j-w-ceni.html](https://forsal.pl/finanse/gielda/artykuly/9316001,creotech-instruments-zaoferuje-inwestorom-396-557-akcji-serii-j-w-ceni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:29:03+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zn1ktkuTURBXy8yN2U3OTYxYS0wNWVmLTRmYzctOTgwNC1mZjkyOWJkYjkyZTkuanBlZ5GTBc0BHcyg" />undefined

## Już nie tylko benefity i dobra pensja. Coraz więcej firm dba o dobrostan psychiczny pracowników
 - [https://forsal.pl/praca/aktualnosci/artykuly/9315873,juz-nie-tylko-benefity-i-dobra-pensja-coraz-wiecej-firm-dba-o-dobrost.html](https://forsal.pl/praca/aktualnosci/artykuly/9315873,juz-nie-tylko-benefity-i-dobra-pensja-coraz-wiecej-firm-dba-o-dobrost.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:28:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CUiktkuTURBXy9mMmVmMGE0MS0zYWUyLTQxMTYtODRmMC0zMDYzZDJkNzA0NDAuanBlZ5GTBc0BHcyg" />Konkurencyjność na rynku pracy to nie tylko atrakcyjne wynagrodzenie, to także dbałość o dobrostan psychiczny pracowników, w tym dostęp do opieki psychologicznej - przekonują eksperci Organizacji Pracodawców Usług IT SoDA.

## Kredyty frankowe: Do Sądu Najwyższego trafiło już 56 skarg nadzwyczajnych
 - [https://forsal.pl/biznes/bankowosc/artykuly/9315901,kredyty-frankowe-do-sadu-najwyzszego-trafilo-juz-56-skarg-nadzwyczajn.html](https://forsal.pl/biznes/bankowosc/artykuly/9315901,kredyty-frankowe-do-sadu-najwyzszego-trafilo-juz-56-skarg-nadzwyczajn.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:20:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/nvektkuTURBXy83NGY2ZGNkZi05MTZlLTQzMjEtYjUzZC1jNjBmZTAyYjJjMTYuanBlZ5GTBc0BHcyg" />Dotychczas Prokurator Generalny skierował do Sądu Najwyższego łącznie 56 skarg nadzwyczajnych związanych z kwestiami kredytów frankowych; w ostatnim czasie do SN trafiły trzy takie skargi - poinformowała PAP Prokuratura Krajowa.

## Szwedzi wspierają Ukrainę amunicją i szkoleniami. Co z Gripenami?
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9315909,szwedzi-wspieraja-ukraine-amunicja-i-szkoleniami-co-z-gripenami.html](https://forsal.pl/swiat/aktualnosci/artykuly/9315909,szwedzi-wspieraja-ukraine-amunicja-i-szkoleniami-co-z-gripenami.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:18:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NDsktkuTURBXy8zY2Q3ZTg4Yy03OTEwLTRmY2EtYWVlNy01NWYwZjc5MjkzMzguanBlZ5GTBc0BHcyg" />Rząd Szwecji ogłosił w piątek czternasty pakiet wsparcia Ukrainy w jej wojnie obronnej z Rosją. Darowizna zawiera m.in. amunicję artyleryjską kalibru 155 mm oraz amunicję do przekazanego wcześniej wozu bojowego piechoty CV90. Zlecono również analizę możliwości odstąpienia samolotów bojowych Gripen.

## Ceny ropy w USA lecą w dół. Może być groźnie
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9315914,ceny-ropy-w-usa-leca-w-dol-moze-byc-groznie.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9315914,ceny-ropy-w-usa-leca-w-dol-moze-byc-groznie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:16:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BBnktkuTURBXy8wNTNhYmVmNy00YzZkLTRjNTMtOWFiYi01ZTNmNGNjYmFmMDcuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku notują niewielkie zmiany, ale są na drodze do największego tygodniowego spadku od marca 2023 r. Inwestorzy obawiają się o perspektywy dla światowej gospodarki.

## Irańskie media: Mohammadi dostała Nobla za działania przeciw „bezpieczeństwu narodowemu”
 - [https://forsal.pl/swiat/artykuly/9315981,iranskie-media-mohammadi-dostala-nobla-za-dzialania-przeciw-bezpiecz.html](https://forsal.pl/swiat/artykuly/9315981,iranskie-media-mohammadi-dostala-nobla-za-dzialania-przeciw-bezpiecz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T11:06:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vDNktkuTURBXy9lNDY4ZTU3OC04NjQ4LTRmNDUtYTFiNi00NmRkZjZiZTY0NTYuanBlZ5GTBc0BHcyg" />Irańska obrończyni praw kobiet Narges Mohammadi dostała w piątek Pokojową Nagrodę Nobla za „swoje działania przeciw bezpieczeństwu narodowemu Iranu” – oznajmiła półoficjalna irańska agencja prasowa Fars.

## Polscy producenci zbóż i nasion oleistych otrzymają pomoc finansową. KE zatwierdziła program
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9315967,polscy-producenci-zboz-i-nasion-oleistych-otrzymaja-pomoc-finansowa-k.html](https://forsal.pl/biznes/rolnictwo/artykuly/9315967,polscy-producenci-zboz-i-nasion-oleistych-otrzymaja-pomoc-finansowa-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T10:54:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1JPktkuTURBXy9mMTBmZTc1Ni0yZmZlLTRjMWYtYjFmNC0xNGRkNDY4NmE1MmUuanBlZ5GTBc0BHcyg" />Komisja Europejska zatwierdziła w piątek polski program pomocy państwowej o wartości około 132,3 mln euro (610 mln złotych) na wsparcie producentów zbóż i nasion oleistych w kontekście wojny Rosji z Ukrainą.

## Pracownicy Polregio dostaną podwyżkę. Negocjacje wsparli marszałkowie województw
 - [https://forsal.pl/transport/kolej/artykuly/9315950,pracownicy-polregio-dostana-podwyzke-negocjacje-wsparli-marszalkowie.html](https://forsal.pl/transport/kolej/artykuly/9315950,pracownicy-polregio-dostana-podwyzke-negocjacje-wsparli-marszalkowie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T10:27:07+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3fDktkuTURBXy8wODFmY2YyYy0wZjBiLTQ0NmEtODNhMC0xNTY1NmNjNTdhZTkuanBlZ5GTBc0BHcyg" />Zarząd Polregio podpisał porozumienie z pracownikami dotyczące podwyżki w woj. zachodniopomorskim. Oznacza to, że pracownicy Polregio we wszystkich zakładach przewoźnika od 1 września otrzymają podwyżki wynagrodzenia w wysokości 800 zł - poinformował w piątek kolejowy przewoźnik.

## Opozycja ostro o lawirowaniu kanclerza Scholza w sprawie dostarczenia broni Ukrainie: To porażka rządu
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9315943,opozycja-ostro-o-lawirowaniu-kanclerza-scholza-w-sprawie-dostarczenia.html](https://forsal.pl/swiat/unia-europejska/artykuly/9315943,opozycja-ostro-o-lawirowaniu-kanclerza-scholza-w-sprawie-dostarczenia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T10:19:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/684ktkuTURBXy81ZWI0MGU1MC0xYTdkLTQwNjktYTMyMi1jODk1ZWM1NjVlZmIuanBlZ5GTBc0BHcyg" />Ciągły opór niemieckiego kanclerza Olafa Scholza wobec dostaw pocisków manewrujących Taurus na Ukrainę spotkał się z ostrą krytyką ze strony opozycyjnej chadecji, ale także niektórych polityków z partii rządowej koalicji. Zdaniem polityka CDU Norberta Roettgena postawa kanclerza w sprawie dostarczenia Taurusów Ukraińcom &quot;przyczynia się do przedłużenia wojny&quot;. I jak dodał &quot;podążanie za kanclerzem jest zbiorową porażką rządu&quot;.

## Masłowska z RPP: Gospodarka powoli się ożywia. Widać to w danych o PKB za III kw.
 - [https://forsal.pl/gospodarka/pkb/artykuly/9315930,maslowska-z-rpp-gospodarka-powoli-sie-ozywia-widac-to-w-danych-o-pkb.html](https://forsal.pl/gospodarka/pkb/artykuly/9315930,maslowska-z-rpp-gospodarka-powoli-sie-ozywia-widac-to-w-danych-o-pkb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T10:03:05+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/C_0ktkuTURBXy82MmU3MDkzYi0xYmFmLTRlNTctYTJlMC01OGUxYzY5MzFiNTMuanBlZ5GTBc0BHcyg" />undefined

## 110 samolotów, 17 mln pasażerów, wyższy zysk. Jest nowa strategia LOT-u
 - [https://forsal.pl/transport/lotnictwo/artykuly/9315928,lot-nowa-strategia-110-samolotow-17-mln-pasazerow-wyzszy-zysk.html](https://forsal.pl/transport/lotnictwo/artykuly/9315928,lot-nowa-strategia-110-samolotow-17-mln-pasazerow-wyzszy-zysk.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:58:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ft_ktkuTURBXy81MWY0MWFmMi03YjkyLTRjZDEtOTI0YS1iYjk2NDMwYjJlNzMuanBlZ5GTBc0BHcyg" />Za pięć lat Lot chce obsłużyć o 7 mln pasażerów więcej, niż ma ich teraz. Szykuje 20 nowych tras – do Ameryki Północnej, dalekiej Azji i na Bliski Wschód. Wśród proponowanych połączeń są m.in. San Francisco, Boston, Bangkok, Hanoi, Teheran czy Rijad.

## Chodorkowski ostro o rosyjskim przywódcy: Putin jest słabszy niż pokazuje to propaganda Kremla
 - [https://forsal.pl/swiat/rosja/artykuly/9315915,chodorkowski-ostro-o-rosyjskim-przywodcy-putin-jest-slabszy-niz-pokaz.html](https://forsal.pl/swiat/rosja/artykuly/9315915,chodorkowski-ostro-o-rosyjskim-przywodcy-putin-jest-slabszy-niz-pokaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:38:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/0itktkuTURBXy9lNGMzM2Y4Yy0xNjZiLTQ5ZWEtOTQxOC1lN2ZkZmJjZDZjOWYuanBlZ5GTBc0BHcyg" />Władimir Putin jest “znacznie słabszy niż chcą to pokazać propaganda Kremla i jego przemówienia” - powiedział włoskiemu dziennikowi „La Repubblica” w piątek rosyjski przedsiębiorca i opozycjonista Michaił Chodorkowski. „Nie wierzcie w jego groźby nuklearne” - zaapelował do Zachodu.

## Biden chce ominąć Kongres ws. pomocy dla Ukrainy. Nie wiadomo, kto będzie nowym spikerem
 - [https://forsal.pl/swiat/usa/artykuly/9315855,biden-chce-ominac-kongres-ws-pomocy-dla-ukrainy-nie-wiadomo-kto-bed.html](https://forsal.pl/swiat/usa/artykuly/9315855,biden-chce-ominac-kongres-ws-pomocy-dla-ukrainy-nie-wiadomo-kto-bed.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:26:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZxZktkuTURBXy8xOWM0ZDM4ZC03N2I0LTRlMTUtOGQ2Yi0yYWE3ZmM2Y2M1NDUuanBlZ5GTBc0BHcyg" />Administracja Joe Bidena rozważa wykorzystanie środków z innych programów rządowych, w tym z Departamentu Stanu, by finansować zbrojenie Ukrainy w obliczu niejasnej sytuacji w Kongresie - podał w czwartek portal Politico. O możliwości alternatywnych rozwiązań w tej sprawie mówił wcześniej prezydent Joe Biden.

## Czy niemieccy nacjonaliści są patriotami? Zaskakujące wyniki sondażu
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9315846,afd-czy-niemieccy-nacjonalisci-sa-patriotami-zaskakujace-wyniki-sondazu.html](https://forsal.pl/swiat/unia-europejska/artykuly/9315846,afd-czy-niemieccy-nacjonalisci-sa-patriotami-zaskakujace-wyniki-sondazu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:24:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uxYktkuTURBXy8yN2ExODdlMy0wZjgwLTRmNzUtOGYwNy1jMzFkMmUxZDY5ODcuanBlZ5GTBc0BHcyg" />Zdecydowana większość obywateli niemieckich (78 proc.) twierdzi, że lubi mieszkać w Niemczech; 19 proc. wolałoby żyć &quot;w innym kraju&quot; - wynika z sondażu instytutu Forsa dla stacji RTL i ntv. Wśród zwolenników prawicowej partii Alternatywa dla Niemiec (AfD) 46 proc. wolałoby mieszkać w innym kraju, podczas gdy 49 proc. wskazuje na Niemcy.

## Amerykanie zestrzelili turecki dron nad Syrią. "Pożałowania godny incydent"
 - [https://forsal.pl/swiat/usa/artykuly/9315836,amerykanie-zestrzelili-turecki-dron-nad-syria-pozalowania-godny-incy.html](https://forsal.pl/swiat/usa/artykuly/9315836,amerykanie-zestrzelili-turecki-dron-nad-syria-pozalowania-godny-incy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:23:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/o4MktkuTURBXy9iOGE4NzA0MC1jODgzLTQzNzctOGZjOC0wNTc1NDMyOTQwNGEuanBlZ5GTBc0BHcyg" />Siły USA zestrzeliły turecki dron w Syrii w samoobronie, bo prowadził atak lotniczy zbyt blisko żołnierzy USA - poinformował w czwartek rzecznik Pentagonu gen. Pat Ryder. Urzędnik ocenił, że był to &quot;pożałowania godny incydent&quot; i był przedmiotem rozmów szefów resortów obrony obu państw.

## Burmistrz Nowego Jorku: Nie ma już miejsca dla migrantów
 - [https://forsal.pl/swiat/usa/artykuly/9315882,burmistrz-nowego-jorku-nie-ma-juz-miejsca-dla-migrantow.html](https://forsal.pl/swiat/usa/artykuly/9315882,burmistrz-nowego-jorku-nie-ma-juz-miejsca-dla-migrantow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:21:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/M2aktkuTURBXy9jMjdlYzJjMy01NWE1LTQyYzgtYTFiMi04Yzg4ZjVjYzZhYzEuanBlZ5GTBc0BHcyg" />Burmistrz Nowego Jorku podczas wizyty w meksykańskim stanie Puebla podkreślał przyjazne relacje, ale jednocześnie w obliczu narastającego kryzysu migracyjnego starał się zniechęcić kolejne osoby do przyjazdu. „Mój dom jest twoim domem&quot;, ale „nie ma już miejsca” – mówił Eric Adams .

## Norweski Komitet Noblowski przyznała Pokojową Nagrodę Nobla. Kim jest laureatka?
 - [https://forsal.pl/swiat/artykuly/9315903,norweski-komitet-noblowski-przyznala-pokojowa-nagrode-nobla-kim-jest.html](https://forsal.pl/swiat/artykuly/9315903,norweski-komitet-noblowski-przyznala-pokojowa-nagrode-nobla-kim-jest.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T09:17:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HKRktkuTURBXy9hNTRjYjljOS1iNjBhLTQ2MzMtYTc4MC0xNmUxN2IwMjZiODQuanBlZ5GTBc0BHcyg" />Tegoroczną Pokojową Nagrodę Nobla otrzymała irańska obrończyni praw kobiet Narges Mohammadi

## Duże zmiany w CD Projekt. Wieloletni prezes zrezygnuje ze stanowiska
 - [https://forsal.pl/biznes/firma/artykuly/9315888,cd-projekt-adam-kicinski-wieloletni-prezes-zrezygnuje-ze-stanowiska.html](https://forsal.pl/biznes/firma/artykuly/9315888,cd-projekt-adam-kicinski-wieloletni-prezes-zrezygnuje-ze-stanowiska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T08:54:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h5tktkuTURBXy82MjEwZmUzOS02OTA1LTQ4YjctYjdmNC1mODRjNjRiNzJkNjEuanBlZ5GTBc0BHcyg" />undefined

## Brukselski think tank: Scholz gra na dwa fronty. Niby popiera Ukrainę, ale tak by nie urazić Kremla
 - [https://forsal.pl/swiat/ukraina/artykuly/9315886,brukselski-think-tank-scholz-gra-na-dwa-fronty-niby-popiera-ukraine.html](https://forsal.pl/swiat/ukraina/artykuly/9315886,brukselski-think-tank-scholz-gra-na-dwa-fronty-niby-popiera-ukraine.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T08:51:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1ddktkuTURBXy9jMDBjZDdjOS05MWEwLTQ1NzQtOGE2Mi0wZTE3NDc2OTk4OWUuanBlZ5GTBc0BHcyg" />Kanclerz Niemiec Olaf Scholz prowadzi podwójną grę w sprawie Ukrainy - taki wniosek wyciąga brukselski instytut Eurointelligence analizując decyzję Berlina o niewysyłaniu Kijowowi pocisków manewrujących Taurus.

## ISW: Putin gra na rozbicie NATO. Nie planuje a nie stworzyć nowy wielobiegunowy porządek na świecie
 - [https://forsal.pl/swiat/rosja/artykuly/9315842,isw-putin-gra-na-rozbicie-nato-nie-planuje-a-nie-stworzyc-nowy-wielo.html](https://forsal.pl/swiat/rosja/artykuly/9315842,isw-putin-gra-na-rozbicie-nato-nie-planuje-a-nie-stworzyc-nowy-wielo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T07:44:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_vqktkuTURBXy83NzhmOWEwNC1lOWUwLTQ5MWYtODRkZS1mNmEzOWQwOGRiOTEuanBlZ5GTBc0BHcyg" />Władimir Putin niezgodnie z prawdą twierdzi, że Rosja chce ustalić zasady nowego wielobiegunowego porządku światowego, podczas gdy w istocie Kreml dąży do zwiększenia siły Rosji, unicestwienia państwowości Ukrainy i rozbicia NATO – ocenia amerykański Instytut Studiów nad Wojną (ISW) w najnowszym raporcie.

## Szef PFR: skala spadku inflacji jest duża a złoty ostatnio zaczął się umacniać
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9315824,szef-pfr-skala-spadku-inflacji-jest-duza-a-zloty-ostatnio-zaczal-sie.html](https://forsal.pl/gospodarka/inflacja/artykuly/9315824,szef-pfr-skala-spadku-inflacji-jest-duza-a-zloty-ostatnio-zaczal-sie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T07:26:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ow-ktktTURBXy8zZTM4ZGRiYy1kMmM5LTRjMzMtOTlkNC02NzM0NTNlMzlkMmQucG5nkZMFzQEdzKA" />Decyzja o obcięciu stóp o 75 pkt. bazowych zaskoczyła inwestorów, co zaszkodziło złotemu. Teraz wydaje się, że nie była błędna, skala spadku inflacji jest duża a złoty ostatnio zaczął się umacniać - powiedział w piątek prezes Polskiego Funduszu Rozwoju Paweł Borys w TVN24.

## Donald Trump jednak nie będzie spikerem Izby Reprezentantów. Czyją kandydaturę poparł?
 - [https://forsal.pl/swiat/usa/artykuly/9315766,donald-trump-jednak-nie-bedzie-spikerem-izby-reprezentantow-czyja-kan.html](https://forsal.pl/swiat/usa/artykuly/9315766,donald-trump-jednak-nie-bedzie-spikerem-izby-reprezentantow-czyja-kan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T06:10:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dVektkuTURBXy9lZjA5ZmQzNC01N2ZjLTRmOTItOTllNC1mMmUwOWUxMjU0NWYuanBlZ5GTBc0BHcyg" />Wbrew czwartkowym doniesieniom portalu Politico, Donald Trump nie będzie ubiegał się o funkcję spikera Izby Reprezentantów; były prezydent USA ogłosił, że popiera kandydaturę na to stanowisko Jima Jordana, republikańskiego kongresmena i swojego bliskiego współpracownika - podała w piątek agencja AP.

## Kursy walut: Złoty w piątek mocniejszy do euro, słabszy do dolara
 - [https://forsal.pl/finanse/waluty/artykuly/9315763,kursy-walut-zloty-w-piatek-mocniejszy-do-euro-slabszy-do-dolara.html](https://forsal.pl/finanse/waluty/artykuly/9315763,kursy-walut-zloty-w-piatek-mocniejszy-do-euro-slabszy-do-dolara.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T06:04:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/JWpktkuTURBXy8yYzcwMWEzOS02MDU2LTQ2YzctOGFmZS03NWExMWFkM2ZlNzMuanBlZ5GTBc0BHcyg" />W piątek rano euro potaniało w stosunku do złotego o nieco ponad 0,05 proc. i ok. godz. 7.30 kosztowało niespełna 4,6 zł. Złoty stracił w stosunku do dolara.

## Nieformalne posiedzenie Rady Europejskiej w Grenadzie. Polski rząd: "Dla nas granice są świętością"
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9315759,nieformalne-posiedzenie-rady-europejskiej-w-grenadzie-polski-rzad-d.html](https://forsal.pl/swiat/unia-europejska/artykuly/9315759,nieformalne-posiedzenie-rady-europejskiej-w-grenadzie-polski-rzad-d.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T06:00:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w00ktkuTURBXy9iNmM5YzFiYy00MTQwLTQwY2YtODAwOC0xM2FhMmU4NmMzYmMuanBlZ5GTBc0BHcyg" />W piątek w Grenadzie, odbędzie się nieformalny szczyt Unii Europejskiej. Dzień wcześniej premier RP Mateusz Morawiecki zapowiedział, że przedstawi &quot;twarde weto wobec nielegalnej imigracji na Radzie Europejskiej.&quot;

## Jakie są plany obronne NATO? "Powrót do korzeni sojuszu, czyli obrony kolektywnej"
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9315755,jakie-sa-plany-obronne-nato-powrot-do-korzeni-sojuszu-czyli-obrony.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9315755,jakie-sa-plany-obronne-nato-powrot-do-korzeni-sojuszu-czyli-obrony.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:56:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yu8ktkuTURBXy83NzYwNzQwOS0yNjczLTQzNWEtYjE0MS1lMGZlYzRhMDA3ZTMuanBlZ5GTBc0BHcyg" />Przyjęte podczas szczytu NATO w Wilnie plany obronne zawierają m.in. obronę Przesmyku Suwalskiego czy Bramy Brzeskiej przed ewentualnym atakiem Rosjan – powiedział PAP szef komitetu wojskowego NATO admirał Rob Bauer.

## Korea Północna wysyła artylerię do Rosji. To efekt spotkania Kim Dzong Una i Władimira Putina
 - [https://forsal.pl/swiat/rosja/artykuly/9315750,korea-polnocna-wysyla-artylerie-do-rosji-to-efekt-spotkania-kim-dzong.html](https://forsal.pl/swiat/rosja/artykuly/9315750,korea-polnocna-wysyla-artylerie-do-rosji-to-efekt-spotkania-kim-dzong.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:50:24+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DgFktkuTURBXy85MjU1YjMzMi03ZWE3LTRkMWEtOWRkNi0yNTg2YzJkZDc0ZDIuanBlZ5GTBc0BHcyg" />Korea Północna zaczęła wysyłać artylerię do atakującej Ukrainę Rosji – podała w czwartek CBS News, powołując się na anonimowe źródło rządowe w USA. Amerykańska stacja wiąże to z niedawnym spotkaniem Kim Dzong Una i Władimira Putina.

## Mauritius zdekryminalizował związki homoseksualne
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9315747,mauritius-zdekryminalizowal-zwiazki-homoseksualne.html](https://forsal.pl/swiat/aktualnosci/artykuly/9315747,mauritius-zdekryminalizowal-zwiazki-homoseksualne.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:47:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sC2ktkuTURBXy8xMzg4MjUyMS0zNTBjLTRjMjQtOGIyYS03NmI2YWUyMDcwYmUuanBlZ5GTBc0BHcyg" />Sąd Najwyższy Mauritiusu, wyspiarskiego państwa na Oceanie Indyjskim, zniósł wprowadzone jeszcze w czasach kolonialnych przepisy zakazujące współżycia osób tej samej płci – przekazała w czwartek agencja Reutera.

## Turcja przeprowadziła ataki z powietrza na pozycje kurdyjskie w północnej Syrii
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9315740,turcja-przeprowadzila-ataki-z-powietrza-na-pozycje-kurdyjskie-w-polnoc.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9315740,turcja-przeprowadzila-ataki-z-powietrza-na-pozycje-kurdyjskie-w-polnoc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:40:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/90hktkuTURBXy8wZjBlNmE3MS0zMzlmLTQ3ODgtODAwYS03ZDg2ZDc2OWNlZmIuanBlZ5GTBc0BHcyg" />Tureckie lotnictwo przeprowadziło w czwartek wieczorem kolejne intensywne ataki na pozycje i cele bojowników kurdyjskich w północnej Syrii, &quot;uderzając w składy broni i amunicji oraz szyby naftowe&quot; - poinformowało ministerstwo obrony Turcji.

## Donald Trump nowym spikerem Izby Reprezentantów? Rozważa ubieganie się o ten urząd
 - [https://forsal.pl/swiat/usa/artykuly/9315738,donald-trump-nowym-spikerem-izby-reprezentantow-rozwaza-ubieganie-sie.html](https://forsal.pl/swiat/usa/artykuly/9315738,donald-trump-nowym-spikerem-izby-reprezentantow-rozwaza-ubieganie-sie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:37:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PunktkuTURBXy8zY2M3OTM0NC00MzU0LTRjYzAtOTAxYS04YzZhZjgwMThjNTguanBlZ5GTBc0BHcyg" />Były prezydent USA Donald Trump rozważa ubieganie się o urząd spikera Izby Reprezentantów i prawdopodobnie uda się do Kapitolu, gdy Partia Republikańska wybierać będzie kandydata na przewodniczącego Izby - podaje w czwartek Politico, powołując się na źródła wśród Republikanów.

## Główne indeksy na Wall Street wróciły do trendu zniżkowego
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9315732,glowne-indeksy-na-wall-street-wrocily-do-trendu-znizkowego.html](https://forsal.pl/biznes/aktualnosci/artykuly/9315732,glowne-indeksy-na-wall-street-wrocily-do-trendu-znizkowego.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:33:10+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/i2KktkuTURBXy82NTBkMDI5Ny1iYmY1LTQzNzEtOTA1Ny1iMDFjYzcyNDEzMmYuanBlZ5GTBc0BHcyg" />Czwartkowa sesja na Wall Street zakończyła się lekkimi spadkami głównych indeksów. Po jednym dniu wzrostów wróciły one tym samym do trendu zniżkowego. Inwestorzy analizowali najnowsze dane z amerykańskiej gospodarki w oczekiwaniu na początek sezonu publikacji wyników kwartalnych przez spółki.

## Kryzys migracyjny. Włosi przedłużają stan kryzysowy o pół roku
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9315728,kryzys-migracyjny-wlosi-przedluzaja-stan-kryzysowy-o-pol-roku.html](https://forsal.pl/swiat/aktualnosci/artykuly/9315728,kryzys-migracyjny-wlosi-przedluzaja-stan-kryzysowy-o-pol-roku.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:29:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dvvktkuTURBXy8xOGYxZjYzNS04ODU1LTRhMTUtYTZmZS0yZTBmZDhlNjhhMGMuanBlZ5GTBc0BHcyg" />Rząd Włoch przedłużyl o sześć następnych miesięcy stan kryzysowy w kraju z powodu nasilenia się fali migracyjnej. Został on wprowadzony przez gabinet Giorgii Meloni 11 kwietnia tego roku.

## Wybory 2023: Debata w TVP. Większość komitetów wybrała już reprezentantów
 - [https://forsal.pl/gospodarka/polityka/artykuly/9315724,wybory-2023-debata-w-tvp-wiekszosc-komitetow-wybrala-juz-reprezentan.html](https://forsal.pl/gospodarka/polityka/artykuly/9315724,wybory-2023-debata-w-tvp-wiekszosc-komitetow-wybrala-juz-reprezentan.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T05:25:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/4LkktkuTURBXy8wYzFmMzZmMi01NDFhLTRhNzQtYTQxYi1kMjIyNGM2YjNmMTIuanBlZ5GTBc0BHcyg" />Donald Tusk z KW Koalicja Obywatelska PO.N iPL Zieloni, Krzysztof Bosak z Konfederacji WiN oraz Krzysztof Maj z KW Bezpartyjni Samorządowcy wezmą udział w debacie wyborczej w TVP. Pozostałe Komitety nie zdecydowały jeszcze, kto będzie ich reprezentantem. W debacie nie weźmie udziału prezes PiS Jarosław Kaczyński.

## Pobyt w sanatorium 2023: ile kosztuje i kiedy jest najtaniej?
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9314877,pobyt-w-sanatorium-2023-ile-kosztuje-i-kiedy-jest-najtaniej.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9314877,pobyt-w-sanatorium-2023-ile-kosztuje-i-kiedy-jest-najtaniej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:37:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DljktkuTURBXy9hZmE3NGMyZi00ZjM2LTRiNzgtOWZlYy1jYjVkZGQyMTZiYzkuanBlZ5GTBc0BHcyg" />Wiele osób nie zadaje sobie sprawy, że pobyt w sanatorium w ramach NFZ nie jest całkowicie bezpłatny. Pacjenci muszą opłacić swoje zakwaterowanie. Koszt sanatorium zależy również od sezonu, w którym decydujemy się na wyjazd.

## Ceny biletów kolejowych dla turystów w Japonii mocno w górę. To pierwsza podwyżka od... 40 lat
 - [https://forsal.pl/lifestyle/turystyka/artykuly/9314327,ceny-biletow-kolejowych-dla-turystow-w-japonii-mocno-w-gore-to-pierws.html](https://forsal.pl/lifestyle/turystyka/artykuly/9314327,ceny-biletow-kolejowych-dla-turystow-w-japonii-mocno-w-gore-to-pierws.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:36:04+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/L3yktkuTURBXy80NzBjYzM0Mi03YWFlLTQyMDEtYmFlNy1jNDc4OWI1NDQ2NzIuanBlZ5GTBc0BHcyg" />Turyści w Japonii zapłacą więcej za bilety kolejowe. Po raz pierwszy od czterdziestu lat, sieć kolejowa JR podniosła ceny średnio o 70 proc. Mimo tak drastycznej podwyżki popyt prawdopodobnie nadal pozostanie wysoki, dzięki osłabieniu jena i napływowi dużej liczby turystów.

## Kim są najbogatsi ludzie w Ameryce? Niewyobrażalny majątek [LISTA]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9315273,najbogatsi-ludzie-w-usa-2023-lista-elon-musk-jeff-bezos.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9315273,najbogatsi-ludzie-w-usa-2023-lista-elon-musk-jeff-bezos.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:34:43+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SMHktkuTURBXy9jNzUyYmJjNS02MjQ3LTQxZDYtYjRjNy0yZDhlYjQ1ZGNhZTAuanBlZ5GTBc0BHcyg" />Elon Musk znalazł się na pierwszym miejscu opublikowanej we wtorek listy najbogatszych ludzi w Ameryce magazynu Forbes. Według stanu na 8 września majątek 52-letniego współzałożyciela Tesli i SpaceX wynosił 251 mld dol.

## W tych krajach ceny żywności rosną najszybciej. Jak wypada Polska? [MAPA]
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9315178,inflacja-cen-zywnosci-na-swiecie-jak-wypada-polska-mapa.html](https://forsal.pl/gospodarka/inflacja/artykuly/9315178,inflacja-cen-zywnosci-na-swiecie-jak-wypada-polska-mapa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:29:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ev9ktkuTURBXy9mNzY5N2Q4MC0xM2E5LTQ4NjUtYjYzOS1jZjUxMjc5YWY2MWYuanBlZ5GTBc0BHcyg" />Według Banku Światowego inflacja krajowych cen żywności utrzymuje się na wysokim poziomie. Wysokie ceny żywności dotkają szczególnie ludność w Wenezueli, Libanie, Argentynie, Turcji i Egipcie. Jak wypada Polska?

## Każdy Polak zarobi wkrótce 10 tys. zł. Co za nie kupi? Bilet do Zimbabwe [OPINIA]
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9315363,kazdy-polak-zarobi-wkrotce-10-tys-zl-co-za-nie-kupi-bilet-do-zimbab.html](https://forsal.pl/gospodarka/inflacja/artykuly/9315363,kazdy-polak-zarobi-wkrotce-10-tys-zl-co-za-nie-kupi-bilet-do-zimbab.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:28:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/H-HktkuTURBXy9jNTQ1NTkxOS0wYTQ3LTQ2MzAtOGIwZC01NzlhNTExNjUxYTQuanBlZ5GTBc0BHcyg" />Na koniec trzeciej kadencji PiS średnie wynagrodzenie w Polsce ma wzrosnąć z obecnych 7 do 10 tys. Słabo! Podniesienie płacy minimalnej w Turcji z 5 do 10 tys. zajęło zaledwie rok. Przeciętny Węgier od wiosny zarabia ponad pół miliona. Na tym tle tragicznie wypadają Szwajcarzy: ich pensje wzrosły w rok o 2,5 proc. – do 6 538. Oczywiście, kpię. I zarazem drżę. Kiedyś już zarabiałem miliony.

## Przewoźnicy tracą na obniżkach cen paliw. Dlaczego w hurcie trzeba płacić więcej niż na stacjach benzynowych?
 - [https://forsal.pl/transport/aktualnosci/artykuly/9315336,przewoznicy-traca-na-obnizkach-cen-paliw-dlaczego-w-hurcie-trzeba-pla.html](https://forsal.pl/transport/aktualnosci/artykuly/9315336,przewoznicy-traca-na-obnizkach-cen-paliw-dlaczego-w-hurcie-trzeba-pla.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:27:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-3EktkuTURBXy9iYzFmNjE1YS0xYWIxLTRkYTMtOTQ0Mi1kMWQ4MmQ3ZGQ3YmMuanBlZ5GTBc0BHcyg" />Dostawcy nie realizują w całości zawartych umów, a zaopatrywanie się na tzw. rynku spotowym oznacza koszty wyższe nawet o ponad 1 zł, którymi przewoźnicy nie mogą obciążyć swoich klientów.

## Rynek energii – pacjent żyje, ale czeka na decyzję lekarzy
 - [https://forsal.pl/biznes/energetyka/artykuly/9315237,rynek-energii-pacjent-zyje-ale-czeka-na-decyzje-lekarzy.html](https://forsal.pl/biznes/energetyka/artykuly/9315237,rynek-energii-pacjent-zyje-ale-czeka-na-decyzje-lekarzy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-10-06T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tJrktkuTURBXy9hOGNjMmI4OC1kMDM5LTQxYmYtYmM2Yi1hZjhhMTM2MmIwMjEuanBlZ5GTBc0BHcyg" />Kiedy w zeszłym roku rząd wprowadzał wszystkie antykryzysowe środki, które miały złagodzić olbrzymie podwyżki cen energii, wieszczyliśmy koniec rynku energii jaki znamy. Po roku widać, że pacjent przeżył, choć końska kuracja zaordynowana przez rząd wywołała skutki, których do końca przewidzieć się nie dało.

