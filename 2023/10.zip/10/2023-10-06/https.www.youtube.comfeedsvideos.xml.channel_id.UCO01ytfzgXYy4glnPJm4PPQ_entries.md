# Source:Matt Walsh, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ, language:en-US

## Recent Murders Show How Sick Our Society Is
 - [https://www.youtube.com/watch?v=WnQlK-AvAMQ](https://www.youtube.com/watch?v=WnQlK-AvAMQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-10-06T22:15:02+00:00

These recent murders have exposed some very ugly things about leftism. 

Get a FREE Jumpstart Trial Bag
RuffGreens.com/Matt
Or call 844-RUFF-700

Save up to 40% off your order! 
Use code WALSH40 at CozyEarth.com

Become a DailyWire+ member and watch the full show: https://bit.ly/3xI9PZL

LIKE & SUBSCRIBE for new videos every day. https://www.youtube.com/c/MattWalsh?sub_confirmation=1

Watch the full episode here: Ep.1237 - https://bit.ly/3F4s7bg 

Stop giving your money to woke corporations that hate you. Get your Jeremy’s Razors today at https://bit.ly/3lSGpWa

Watch my hit documentary, “What Is A Woman?” here: https://utm.io/ueSdV

Represent the Sweet Baby Gang by shopping my merch: https://tinyurl.com/y5dscrmm

#MattWalsh #TheMattWalshShow #News #Politics #DailyWire #WhatIsAWoman

## Activist Attacked in Brooklyn
 - [https://www.youtube.com/watch?v=aAmpQjsfyLA](https://www.youtube.com/watch?v=aAmpQjsfyLA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-10-06T19:00:00+00:00



## German Family Gets Deported?
 - [https://www.youtube.com/watch?v=dlMqhoARgKQ](https://www.youtube.com/watch?v=dlMqhoARgKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCO01ytfzgXYy4glnPJm4PPQ
 - date published: 2023-10-06T17:00:28+00:00



