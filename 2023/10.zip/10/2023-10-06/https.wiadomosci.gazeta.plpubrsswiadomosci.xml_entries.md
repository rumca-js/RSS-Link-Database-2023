# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Skandal na plebanii w Dąbrowie GĂłrniczej. Sprawa księdza Tomasza Z. trafi do Watykanu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272664,skandal-na-plebanii-w-dabrowie-gorniczej-sprawa-ksiedza-tomasza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272664,skandal-na-plebanii-w-dabrowie-gorniczej-sprawa-ksiedza-tomasza.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T20:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ed/de/1c/z30272749M,Watykan--Bazylika-Sw--Piotra.jpg" vspace="2" />Kuria diecezjalna w Sosnowcu potwierdziła, że komisja kościelna badająca sprawę ks. Tomasza Z. z Dąbrowy GĂłrniczej przekazała wyniki prac biskupowi Kaszakowi. Aby podkreślić bezstronność procesu, biskup sosnowiecki postanowił zlecić dalszą pracę prawnikom spoza diecezji. Jak dowiadujemy się z komunikatu kurii, ostateczną decyzję w sprawie wydać ma Watykan.

## Dopisanie do spisu wyborcĂłw i zaświadczenia o prawie do głosowania. Polacy ruszyli do urzędĂłw przed wyborami
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272694,dopisanie-do-spisu-wyborcow-i-zaswiadczenia-o-prawie-do-glosowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272694,dopisanie-do-spisu-wyborcow-i-zaswiadczenia-o-prawie-do-glosowania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T20:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/19/de/1c/z30272793M,Ludzie-masowo-dopisuja-sie-do-spisu-wyborcow---zdj.jpg" vspace="2" />68 proc. uprawnionych do głosowania zamierza wziąć udział w wyborach parlamentarnych 15 października - wynika z sondażu Opinia24 dla "Gazety Wyborczej". Oznaczałoby to historycznie najwyższą frekwencję w wyborach w Polsce po 1989 roku. Do tej pory najwięcej PolakĂłw poszło do urn 4 czerwca 1989 roku - było to 62 proc. uprawnionych do głosowania. Duże zainteresowanie PolakĂłw dopisywaniem się do spisu wyborcĂłw i pobieraniem zaświadczeń o prawie do głosowania wskazuje, że sondażowe prognozy mogą się sprawdzić.

## Jest pismo do prezesa TVP ws. organizacji debaty. "Zmiana godzinowa oznacza zmniejszenie widowni"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272675,jest-pismo-do-prezesa-tvp-ws-organizacji-debaty-zmiana-godzinowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272675,jest-pismo-do-prezesa-tvp-ws-organizacji-debaty-zmiana-godzinowa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T19:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bd/de/1c/z30272701M,TVP--Zdjecie-ilustracyjne.jpg" vspace="2" />Zmiana godziny poniedziałkowej debaty przedwyborczej i miejsce jej organizacji - na te dwa aspekty zwrĂłcili uwagę w piśmie do prezesa TVP dwaj członkowie Rady Programowej. Jak zaznaczyli, nie dość, że debata będzie odbywała się w porze niższej oglądalności, to jeszcze Telewizja Polska nie będzie korzystała z własnego studia.

## W ostrzale wsi Groza w Ukrainie zginęła pracownica Polskiej Akcji Humanitarnej. Pomagała seniorom
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272617,w-ostrzale-wsi-groza-w-ukrainie-zginela-pracownica-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272617,w-ostrzale-wsi-groza-w-ukrainie-zginela-pracownica-polskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T19:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/96/de/1c/z30272662M,Wojna-w-Ukrainie--Atak-na-obwod-charkowski--5-pazd.jpg" vspace="2" />Polska Akcja Humanitarna poinformowała, że podczas ostrzału wsi Groza w obwodzie charkowskim w Ukrainie zginęła pracownica tej organizacji. W czwartkowym ataku Rosjan na sklep spożywczy i kawiarnię zginęło 51 osĂłb. Prezydent Ukrainy nazwał ostrzał "świadomym aktem terroru".

## Rudy nowym członkiem załogi Tuskobusa. "Bardzo go pokochaliśmy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272553,rudy-nowym-czlonkiem-zalogi-tuskobusa-bardzo-go-pokochalismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272553,rudy-nowym-czlonkiem-zalogi-tuskobusa-bardzo-go-pokochalismy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T19:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/de/1c/z30272613M,Donald-Tusk-z-kotem-Rudym.jpg" vspace="2" />Do ekipy Donalda Tuska podrĂłżującej po Polsce Tuskobusem dołączył w ostatnich dniach kot, ktĂłrego przewodniczący PO znalazł pod Krosnem. Zwierzę ma trafić pod stałą opiekę jednego ze wspĂłłpracownikĂłw szefa ugrupowania. - Kot wydaje się być zrelaksowany, chyba szczęśliwy, a my go wszyscy bardzo pokochaliśmy - stwierdził w piątek Tusk.

## Były minister sprawiedliwości komentuje ekstradycję Sebastiana M. Kiedy kierowca BMW wrĂłci do kraju?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272292,byly-minister-sprawiedliwosci-komentuje-ekstradycje-sebastiana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272292,byly-minister-sprawiedliwosci-komentuje-ekstradycje-sebastiana.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T19:01:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fb/de/1c/z30272507M,Mecenas-Zbigniew-Cwiakalski-komentuje-ekstradycje-.jpg" vspace="2" />Sebastian M., głĂłwny podejrzany w sprawie głośnego wypadku na autostradzie A1, został zatrzymany w Dubaju. Do Zjednoczonych EmiratĂłw Arabskich został wysłany wniosek o ekstradycję. Zdaniem mecenasa Zbigniewa Ćwiąkalskiego, byłego ministra sprawiedliwości, mogą jednak minąć miesiące, zanim Sebastian M. zostanie sprowadzony z powrotem do Polski.

## Morawiecki pisze o odrzuceniu paktu migracyjnego. Ale go nie zablokował. Jest w innym dokumencie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272415,morawiecki-pisze-o-odrzuceniu-paktu-migracyjnego-zapisy-o-nim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272415,morawiecki-pisze-o-odrzuceniu-paktu-migracyjnego-zapisy-o-nim.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T18:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/47/de/1c/z30272583M,Morawiecki-pisze-o-odrzuceniu-paktu-migracyjnego--.jpg" vspace="2" />Premier Mateusz Morawiecki poinformował, że na szczycie przywĂłdcĂłw Unii Europejskiej w Grenadzie odrzucił zapis deklaracji na temat migracji. W efekcie paragraf nie znalazł się w tym dokumencie, ale trafi do deklaracji szefa Rady Europejskiej Charlesa Michela. Ta zmiana nie ma wpływu na dalsze procedowanie przepisĂłw o solidarności w sprawie migrantĂłw - zwracają uwagę media i korespondenci z Brukseli.

## Sondaż dla "GW": Koalicja Obywatelska blisko PiS-u. Podium rĂłwnież dla Trzeciej Drogi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272251,sondaz-dla-gw-koalicja-obywatelska-blisko-pis-u-podium-rowniez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272251,sondaz-dla-gw-koalicja-obywatelska-blisko-pis-u-podium-rowniez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T17:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/81/de/1c/z30272385M,Jaroslaw-Kaczynski.jpg" vspace="2" />Niecałe dwa punkty procentowe dzielą Prawo i Sprawiedliwość i Koalicję Obywatelską - wynika z sondażu pracowni Opinia24 dla "Gazety Wyborczej". Badanie wskazuje rĂłwnież, że Konfederacja z poparciem na poziomie 6,5 proc. spadła w okolice 5-procentowego progu wyborczego.

## Ambasadorka Holandii została wezwana do MSZ. Powodem skandaliczne działania wobec polskich piłkarzy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272053,ambasadorka-holandii-zostala-wezwana-do-msz-powodem-skandaliczne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30272053,ambasadorka-holandii-zostala-wezwana-do-msz-powodem-skandaliczne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T16:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/67/de/1c/z30272103M,Pawel-Jablonski--podsekretarz-stanu-w-MSZ.jpg" vspace="2" />Ambasadorka KrĂłlestwa NiderlandĂłw została wezwana na sobotę (7 października) do polskiego MSZ z powodu zajść, jakie miały miejsce po wyjazdowym meczu Legii Warszawa w mieście Alkmaar. Według informacji przekazanych przez media funkcjonariusze holenderskiej policji mieli dopuścić się aktĂłw przemocy wobec piłkarzy, sztabu oraz prezesa polskiego klubu. W wyniku zdarzeń zatrzymanych zostało dwĂłch legionistĂłw.

## Grenada: Polska nie zgodziła się na deklarację 27 państw UE z zapisami dotyczącymi migracji. Zostały usunięte
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272182,grenada-polska-nie-zgodzila-sie-na-deklaracje-27-panstw-ue.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30272182,grenada-polska-nie-zgodzila-sie-na-deklaracje-27-panstw-ue.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T16:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d8/de/1c/z30272216M,Hiszpania--Grenada--Polska-nie-zgodzila-sie-na-dek.jpg" vspace="2" />Polska nie zgodziła się na deklarację 27 państwo Unii Europejskiej z zapisami dotyczącymi migracji na zakończenie szczytu w Grenadzie. Zapadła decyzja o ich usunięciu. Szczyt w Hiszpanii zakończył się zatem przyjęciem przez władze krajĂłw członkowskich dwĂłch dokumentĂłw: wspĂłlnego oświadczenia na temat strategii WspĂłlnoty na przyszłość i rozszerzenia oraz deklaracją poświęconą migracji przewodniczącego Rady Europejskiej Charlesa Michela.

## Kaczyński ucieka z debaty w TVP, cenzurowanie opozycji w gazetach Orlenu [TYGODNIK WYBORCZY]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272060,kaczynski-ucieka-z-debaty-w-tvp-cenzurowanie-opozycji-w-gazetach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30272060,kaczynski-ucieka-z-debaty-w-tvp-cenzurowanie-opozycji-w-gazetach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T16:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a3/de/1c/z30271907M,Donald-Tusk--Zdjecie-archiwalne.jpg" vspace="2" />PiS kontroluje Orlen, następnie Orlen kupuje media lokalne, a media lokalne zabraniają reklam opozycji. Piękny system, prawda? - pisze dla Gazeta.pl Tomasz Sawczuk z "Kultury Liberalnej"

## Przegląd wyborczy ORB News dla Gazeta.pl. Wszystko, co chcielibyście wiedzieć o Prawie i Sprawiedliwości
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271403,przeglad-wyborczy-orb-news-dla-gazeta-pl-wszystko-co-chcielibyscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271403,przeglad-wyborczy-orb-news-dla-gazeta-pl-wszystko-co-chcielibyscie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T16:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5c/de/1c/z30271836M,Przeglad-wyborczy-ORB--Prawo-i-Sprawiedliwosc.jpg" vspace="2" />- Przekonujmy ludzi, żeby szli na wybory, to po pierwsze. Po drugie, żeby głosowali w referendum - zachęcał w czwartek wyborcĂłw z Buska-Zdroju prezes PiS Jarosław Kaczyński. Niezależnie od tego, że prezes chwilę pĂłźniej się pomylił i zachęcił do głosowania 4xTAK, a nie 4xNIE, jak zaleca partia, to właśnie PiS jest liderem każdego przedwyborczego sondażu. A z jakim programem idzie do wyborĂłw?

## Pogoda gwałtownie się zmieni. Ostrzeżenia przed niszczycielką siłą. IMGW: Front zostanie na dłużej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271903,pogoda-gwaltownie-sie-zmieni-ostrzezenia-przed-niszczycielka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271903,pogoda-gwaltownie-sie-zmieni-ostrzezenia-przed-niszczycielka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T15:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4b/de/1c/z30272075M,Pogoda-gwaltownie-sie-zmieni--Ostrzezenia-przed-ni.jpg" vspace="2" />Nawet 110 km/h mogą osiągnąć podmuchy silnego wiatru nad Bałtykiem - takie wartości podaje w najnowszej prognozie pogody Instytut Meteorologii i Gospodarki Wodnej. Dla większość kraju wydano ostrzeżenia pierwszego i drugiego stopnia. Synoptycy wskazali też, jak długo pogodę w Polsce ma kształtować chłodny front.

## Debata w TVP. Tusk o udziale Morawieckiego: Jesteśmy świadkami zmiany szefostwa w PiS
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271889,debata-w-tvp-tusk-o-udziale-morawieckiego-jestesmy-swiadkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271889,debata-w-tvp-tusk-o-udziale-morawieckiego-jestesmy-swiadkami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T15:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a2/de/1c/z30271906M,Donald-Tusk--Zdjecie-archiwalne.jpg" vspace="2" />- Nie wiem, z czego to wynika, że Kaczyński abdykował, chowa się. Właściwie jesteśmy świadkami zmiany szefostwa w PiS-ie, bo tak to wygląda. Ale że ja doczekam tego momentu, że mĂłj były doradca zostanie szefem Kaczyńskiego, to naprawdę jest poważna chwila - mĂłwił w piątek w Przemyślu przewodniczący PO Donald Tusk. Skomentował w ten sposĂłb planowany udział premiera Mateusza Morawieckiego w poniedziałkowej debacie w TVP.

## PiS przegrał z kretesem w LO w Gorzowie Wlkp. Kuratorka oburzona. Prof. Matczak: Absolutnie nie ma racji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271918,pis-przegral-z-kretesem-w-lo-w-gorzowie-wlkp-kuratorka-oburzona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271918,pis-przegral-z-kretesem-w-lo-w-gorzowie-wlkp-kuratorka-oburzona.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T15:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cd/de/1c/z30271949M,Prawybory-w-II-LO-w-Gorzowie-Wielkopolskim.jpg" vspace="2" />"Samo pokazanie w szkole wszystkich programĂłw wyborczych nie jest absolutnie agitacją" - komentuje w rozmowie z Gorzowskie.pl prawnik prof. Marcin Matczak. To reakcja na prawybory organizowane w II LO w Gorzowie Wielkopolskim, ktĂłre zakończyły się słabym wynikiem Prawa i Sprawiedliwości. Krytyczny komunikat wydało pĂłźniej tamtejsze kuratorium. W najbliższych dniach głosowanie planuje kolejna placĂłwka w mieście.

## Krytyczne głosy na temat udziału Scheuring-Wielgus w debacie TVP. Sztab Lewicy: Niesztampowy ruch
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271734,krytyczne-glosy-na-temat-udzialu-scheuring-wielgus-w-debacie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271734,krytyczne-glosy-na-temat-udzialu-scheuring-wielgus-w-debacie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T15:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/94/de/1c/z30271892M,Krytyczne-komentarze-na-temat-udzialu-Joanny-Scheu.jpg" vspace="2" />Lewica przekazała do wiadomości, że partię podczas poniedziałkowej debaty w TVP reprezentować będzie posłanka Joanna Scheuring-Wielgus. WybĂłr przedstawicielki stronnictwa spotkał się z szeroką krytyką użytkownikĂłw mediĂłw społecznościowych. Dziennikarze portalu OKO.press skontaktowali się ze sztabem wyborczym Lewicy, ktĂłry uzasadnił wybĂłr reprezentantki w starciu politykĂłw.

## Finał sprawy księdza Wiesława, ktĂłry mężatkom wysyłał nagie zdjęcia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271627,final-sprawy-ksiedza-wieslawa-ktory-mezatkom-wysylal-nagie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271627,final-sprawy-ksiedza-wieslawa-ktory-mezatkom-wysylal-nagie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T14:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/55/dd/1c/z30266709M,Ksiadz--zdjecie-ilustracyjne-.jpg" vspace="2" />Koniec sprawy księdza Wiesława C. z Trzcinicy w wojewĂłdztwie wielkopolskim. Duchowny wysyłał swoje nagie zdjęcia mężatkom z parafii, w ktĂłrej był proboszczem, miał z kilkoma romans i doprowadził do rozbicia jednego małżeństwa. Po prawie roku policja umorzyła sprawę, a ksiądz zniknął.

## Sąd Najwyższy oddalił skargę Trzeciej Drogi. Chodziło o odmowę udziału w referendum
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271807,sad-najwyzszy-oddalil-skarge-trzeciej-drogi-chodzilo-o-odmowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271807,sad-najwyzszy-oddalil-skarge-trzeciej-drogi-chodzilo-o-odmowe.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T14:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b4/ab/1c/z30061236M,Urna-wyborcza--zdjecie-ilustracyjne-.jpg" vspace="2" />Sąd Najwyższy oddalił w piątek skargę Trzeciej Drogi, ktĂłra sprzeciwiała się wytycznym PKW ws. odnotowywania odmowy udziału w referendum. Według SN to nie sposĂłb prowadzenia ewidencji wydanych kart, a sama koncepcja połączenia referendum z wyborami "może prowadzić do pośredniego ujawniania preferencji wyborcĂłw".

## Nieoficjalnie: "Gazeta Polska" w pociągach Polregio tuż przed wyborami. "Nie kryjemy oburzenia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271584,nieoficjalnie-gazeta-polska-w-pociagach-polregio-tuz-przed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271584,nieoficjalnie-gazeta-polska-w-pociagach-polregio-tuz-przed.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T14:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f9/de/1c/z30271737M,Zdjecie-ilustracyjne.jpg" vspace="2" />Na dwa dni przed dniem wyborĂłw parlamentarnych w pociągach Polregio w całym kraju ma znaleźć się kilkadziesiąt tysięcy egzemplarzy prawicowej "Gazety Polskiej", sympatyzującej z Prawem i Sprawiedliwością - podaje nieoficjalnie "Gazeta Wyborcza". SpĂłłka twierdzi, że taka umowa nie została podpisana, co nie oznacza, że nie dojdzie do jej podpisania w najbliższych dniach.

## Wypadek luksusowych aut w Sardynii. Miał go spowodować indyjski miliarder. Zginęły dwie osoby
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30271205,wypadek-luksusowych-aut-w-sardynii-mial-go-spowodowac-indyjski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30271205,wypadek-luksusowych-aut-w-sardynii-mial-go-spowodowac-indyjski.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T14:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/de/1c/z30271641M,Wypadek-luksusowych-aut-w-Sardynii--Mial-go-spowod.jpg" vspace="2" />Włoska policja prowadzi śledztwo ws. wypadku luksusowych aut, do ktĂłrego doszło na południu Sardynii. Miał go spowodować indyjski miliarder. Wskutek zdarzenia zginęło małżeństwo.

## Donald Tusk przedstawił swojego podopiecznego i zażartował z Kaczyńskiego. OdniĂłsł się do debaty TVP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271279,donald-tusk-przedstawil-swojego-podopiecznego-i-zazartowal-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271279,donald-tusk-przedstawil-swojego-podopiecznego-i-zazartowal-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T14:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/43/de/1c/z30271555M,Zartobliwy-wpis-Donalda-Tuska.jpg" vspace="2" />W czwartek (5 października) Donald Tusk ogłosił swĂłj udział w debacie przedwyborczej organizowanej przez TVP. Tego samego dnia Jarosław Kaczyński potwierdził, że nie weźmie udziału w spotkaniu. Lider PO skomentował kolejną z rzędu odmowę prezesa PiS w żartobliwym wpisie opublikowanym w mediach społecznościowych.

## Jak dopisać się do spisu wyborcĂłw? Wystarczy złożyć odpowiedni wniosek. Podpowiadamy, jak to zrobić
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269886,jak-dopisac-sie-do-spisu-wyborcow-wystarczy-zlozyc-odpowiedni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269886,jak-dopisac-sie-do-spisu-wyborcow-wystarczy-zlozyc-odpowiedni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T13:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/dc/1c/z30261921M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Wybory parlamentarne odbędą się już 15 października. Zanim jednak wybierzemy się do urn, należy sprawdzić, czy aby na pewno nasze nazwisko znajduje się na liście wyborczej. W tym roku po raz pierwszy spis wyborcĂłw tworzony będzie na podstawie Centralnego Rejestru WyborcĂłw. Jeżeli w dniu wyborĂłw nie będziemy mogli przebywać w miejscu stałego zamieszkania lub zameldowania, wĂłwczas należy zadbać o dopisanie nas do spisĂłw wyborcĂłw. Jak to zrobić?

## Pogoda. Patryk wkracza do Polski. Przyniesie wichury i bańkę chłodu. IMGW wydało ostrzeżenia
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270683,niz-patryk-wkracza-do-polski-przyniesie-zmiane-pogody-imgw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270683,niz-patryk-wkracza-do-polski-przyniesie-zmiane-pogody-imgw.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T13:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a2/de/1c/z30271138M,Pogode-w-najblizszy-weekend-bedzie-ksztaltowac-niz.jpg" vspace="2" />Do Polski zbliża się niż Patryk znad południowej Skandynawii, ktĂłry w najbliższych dniach będzie kształtował pogodę w Polsce. Od soboty czeka nas ochłodzenie, a synoptycy IMGW wydali ostrzeżenia przez silnym wiatrem w wielu rejonach kraju.

## Debata w TVP. Wiadomo już, kto będzie reprezentował Lewicę. "Głos kobiet musi być słyszalny"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271284,debata-w-tvp-wiadomo-juz-kto-bedzie-reprezentowal-lewice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30271284,debata-w-tvp-wiadomo-juz-kto-bedzie-reprezentowal-lewice.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T13:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/de/1c/z30271312M,Zdjecie-ilustracyjne.jpg" vspace="2" />Reprezentantką Lewicy w poniedziałkowej debacie organizowanej przez Telewizję Polską będzie posłanka Joanna Scheuring-Wielgus. "Głos kobiet musi być słyszalny" - przekazało w piątek ugrupowanie.

## Horoskop na weekend 7 - 8 października 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30268875,horoskop-na-weekend-7-8-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30268875,horoskop-na-weekend-7-8-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T13:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8b/5a/1c/z29729931M,Horoskop--zdjecie-ilustracyjne-.jpg" vspace="2" />Horoskop na weekend 6-7 października. Czego spodziewać się w tym czasie? Przedstawiamy przepowiednie dla wszystkich znakĂłw zodiaku.

## Kilkudziesięciu adwokatĂłw i radcĂłw szantażowanych przez cyberoszusta. Prokuratura umorzyła sprawę
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271029,kilkudziesieciu-radcow-i-adwokatow-szantazowanych-przez-cyberoszusta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30271029,kilkudziesieciu-radcow-i-adwokatow-szantazowanych-przez-cyberoszusta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T12:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f2/e4/19/z27149810M,Adwokat---zdjecie-ilustracyjne.jpg" vspace="2" />Prokuratura Rejonowa ŁĂłdź-ŚrĂłdmieście umorzyła trwające osiem miesięcy śledztwo w sprawie szantażysty kilkudziesięciu prawnikĂłw. Służbom nie udało się wykryć sprawcy przestępstwa. Według ustaleń Radia Zet proceder, przez ktĂłry ucierpiało kilkudziesięciu adwokatĂłw w całej Polsce, nadal trwa.

## Szymon Hołownia będzie na debacie w TVP. Kosiniak-Kamysz zadba, by Kaczyński "czuł oddech na plecach"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270844,debata-tvp-szymon-holownia-bedzie-reprezentowal-trzecia-droge.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270844,debata-tvp-szymon-holownia-bedzie-reprezentowal-trzecia-droge.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T12:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cc/dc/1c/z30261964M,Wladyslaw-Kosianiak-Kamysz-na-spotkaniu-z-wyborcam.jpg" vspace="2" />Szymon Hołownia będzie reprezentował partię Trzecia Droga podczas debaty TVP. Władysław Kosiniak-Kamysz poinformował, że będzie w tym czasie w innym miejscu "by Jarosław Kaczyński czuł oddech na plecach". Debata TVP odbędzie się w najbliższy poniedziałek.

## Lewica i Trzecia Droga nie mogą się reklamować w gazetach Orlenu, bo głoszą "niewłaściwe" poglądy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270414,lewica-i-trzecia-droga-nie-moga-reklamowac-sie-w-gazetach-orlenu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270414,lewica-i-trzecia-droga-nie-moga-reklamowac-sie-w-gazetach-orlenu.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T12:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/96/de/1c/z30270870M,Stacja-paliw-Orlen-i-gazeta--Polska-The-Times-.jpg" vspace="2" />Gazety należące do kontrolowanej przez Orlen grupy wydawniczej Polska Press odmĂłwiły kandydatom Lewicy i Trzeciej Drogi publikacji reklam wyborczych. Oficjalnie przyznano, że odmowa była podyktowana "wartościami i rozumieniem racji stanu" charakteryzującym wspomniane ugrupowania.

## "PiS = klub milionerĂłw, drożyzna". Za taki baner ściga policja kryminalna. "Zamiast łapać złodziei"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270419,jastrzebska-policja-zamiast-lapac-zlodziei-szuka-odpowiedzialnych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270419,jastrzebska-policja-zamiast-lapac-zlodziei-szuka-odpowiedzialnych.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T12:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/af/de/1c/z30270895M,Jaroslaw-Kaczynski.jpg" vspace="2" />Policja wszczęła postępowanie w sprawie antypisowskiego billboardu, ktĂłry zawisł na elewacji jednego z blokĂłw w Jastrzębiu-Zdroju. Mundurowi w piśmie do spĂłłdzielni mieszkaniowej zażądali wskazania winowajcy oraz potraktowania sprawy jako pilnej. - Obok wisi billboard posła PiS, ale tego już nie sprawdzamy - podkreślił anonimowo jeden z jastrzębskich policjantĂłw.

## Pokojowy Nobel dla Iranki. Dziennikarz: Rozpłakałem się. I to w pracy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30270962,pokojowy-nobel-dla-iranki-dziennikarz-rozplakalem-sie-i-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30270962,pokojowy-nobel-dla-iranki-dziennikarz-rozplakalem-sie-i-to.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T12:14:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/de/1c/z30271183M,Narges-Mohammadi--laureatka-Pokojowego-Nobla--w-sr.jpg" vspace="2" />To wyczekiwane wyrĂłżnienie. Nie tylko dlatego, że laureatka w reżimowych więzieniach spędziła ponad 31 lat. RĂłwnież dlatego, że ma charakter powszechny i dotyczy praw i wolności naruszanych na całym świecie. W tym roku laureatką Pokojowej Nagrody Nobla została Narges Mohammadi, Iranka, ktĂłrej zamknięcie w celi i chłosta nie przeszkodziły kierować trwającą ponad rok rewolucją kobiet w jej kraju.

## Tragedia na A1. Sąsiad o Sebastianie M. Kierowca bmw był "sympatyczny, ale lubił się wozić"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270415,sasiad-zabral-glos-w-sprawie-sebastiana-m-kierowca-bmw-byl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270415,sasiad-zabral-glos-w-sprawie-sebastiana-m-kierowca-bmw-byl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T11:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/01/de/1c/z30270721M,Wypadek-na-A1--Sasiad-wyjawil-szczegoly-na-temat-S.jpg" vspace="2" />- Sympatyczny. Tylko mĂłwię, za dużo kasy - powiedział sąsiad dziennikarzom Polsatu o Sebastianie M. podejrzanym o spowodowanie wypadku na autostradzie A1. Policja ustaliła, że kierowca bmw jechał z prędkością ponad 250 km/h, gdy zderzył się z kią. W zdarzeniu zginęło młode małżeństwo i ich 5-letni syn. Rodzina spłonęła w samochodzie.

## Jak zagłosować poza miejscem zamieszkania? Możliwości są dwie, wystarczą odpowiednie wnioski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269738,jak-zaglosowac-poza-miejscem-zamieszkania-mozliwosci-sa-dwie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269738,jak-zaglosowac-poza-miejscem-zamieszkania-mozliwosci-sa-dwie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T11:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/42/dd/1c/z30269250M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Czy w wyborach parlamentarnych można głosować poza miejscem zamieszkania? Okazuje się, że tak, są dwie możliwości. Wyborca może wskazać konkretne miejsce głosowania (inne niż adres zameldowania czy zamieszkania) lub w ogĂłle go nie wybierać, wĂłwczas ma możliwość głosowania w dowolnym lokalu wyborczym, w całej Polsce. Co należy zrobić w każdym przypadku i o czym pamiętać?

## Do biura senatora Kwiatkowskiego wtargnął nożownik. "Wyzywał od zdrajcĂłw Polski"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270866,do-biura-senatora-kwiatkowskiego-wtargnal-nozownik-wyzywal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270866,do-biura-senatora-kwiatkowskiego-wtargnal-nozownik-wyzywal.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T11:33:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9a/5d/1a/z27647642M,Krzysztof-Kwiatkowski.jpg" vspace="2" />Do biura senatora Krzysztof Kwiatkowskiego wtargnął uzbrojony w nĂłż mężczyzna. Zaczął grozić pracownikom, wyzywał też polityka od "zdrajcĂłw Polski". - Ta kampania jest najgorsza od lat jeśli chodzi o agresję - powiedziała szefowa biura Martyna Stasiak.

## Tarnobrzeg. Nowe informacje ws. śmierci samorządowca z PiS. Są wyniki sekcji zwłok
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270530,tarnobrzeg-nowe-informacje-ws-smierci-samorzadowca-z-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270530,tarnobrzeg-nowe-informacje-ws-smierci-samorzadowca-z-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T11:28:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/c8/1c/z30182446M,Marek-Ozga.jpg" vspace="2" />Są wyniki sekcji zwłok Marka Ożgi. Samorządowiec z PiS zmarł na skutek poważnego urazu głowy, ktĂłrego doznał w wypadku drogowym. Śledczy sprawdzili, czy w momencie zdarzenia znajdował się pod wpływem alkoholu.

## Prymas Polski krytykuje kampanię wyborczą. Apeluje o opamiętanie się: Nie ma partii bliskiej Kościołowi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270133,prymas-polski-stanowczo-o-kampanii-wyborczej-i-identyfikacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270133,prymas-polski-stanowczo-o-kampanii-wyborczej-i-identyfikacji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T11:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2d/de/1c/z30270509M,Abp-Wojciech-Polak.jpg" vspace="2" />- KościĂłł nie jest i z żadnego powodu nie powinien być narzędziem wykorzystywanym do prowadzenia doraźnej polityki. W tym znaczeniu nie jest i nie może być nigdy częścią kampanii wyborczej - powiedział abp Wojciech Polak. Prymas Polski odniĂłsł się do obecnej kampanii wyborczej i przekazał, że "KościĂłł nie identyfikuje się z żadną partią polityczną".

## Znamy szczegĂłły niespodzianki, ktĂłrą TVP zaserwuje w superponiedziałek. Potrwa aż dwie godziny
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270536,znamy-szczegoly-niespodzianki-ktora-tvp-zaserwuje-w-superponiedzialek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270536,znamy-szczegoly-niespodzianki-ktora-tvp-zaserwuje-w-superponiedzialek.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T10:58:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d3/dc/1c/z30263763M,Pracowniczka-Czerwonego-Krzyza-siedzi-posrod-imigr.jpg" vspace="2" />TVP wyemituje w superponiedziałek, czyli w dzień debaty przedwyborczej, dwa odcinki filmu dokumentalnego "Migranci", ktĂłry wyreżyserowali Sławomir Czyrnek i Jacek Łęski. Od 21:10 do 23:00 na antenie TVP1. Materiał ma "podgrzać" narrację PiS ws. migracji, ktĂłra jest przedmiotem pytania referendalnego 15 października.

## "Sebastian M. to bezmyślny idiota". Mariusz Kamiński komentuje doniesienia o związkach z policją
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270096,szef-mswia-sebastian-m-to-bezmyslny-idiota-kaminski-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30270096,szef-mswia-sebastian-m-to-bezmyslny-idiota-kaminski-komentuje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T10:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/dc/1c/z30262685M,Sebastian-M--zatrzymany.jpg" vspace="2" />Mariusz Kamiński odniĂłsł się do tragicznego wypadku na A1. Minister spraw wewnętrznych i administracji powiedział, że "nie będzie przeszkĂłd", aby Sebastian M. "poniĂłsł wszelkie konsekwencje" swoich czynĂłw. Szef MSWiA skomentował rĂłwnież informacje o rzekomych powiązaniach kierowcy bmw z policją.

## PO zażądała, by Michał Rachoń tym razem nie mĂłgł przerywać Donaldowi Tuskowi. Ujawniamy zasady debaty TVP
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270380,po-zazadala-by-michal-rachon-tym-razem-nie-mogl-przerywac-donaldowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270380,po-zazadala-by-michal-rachon-tym-razem-nie-mogl-przerywac-donaldowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T10:23:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/ce/1c/z30206586M,Donald-Tusk--Michal-Rachon.jpg" vspace="2" />Koalicja Obywatelska zażądała, aby do zasad debaty wyborczej TVP wprost zapisać zakaz przerywania wypowiedzi uczestnikĂłw przez prowadzących to wydarzenie - ustaliła Gazeta.pl. Wynika to z obawy, że Michał Rachoń, ktĂłry ma zadawać pytania, może przerywać i komentować wypowiedzi przede wszystkim lidera PO Donalda Tuska.

## Jak sprawdzić, gdzie mogę głosować? PKW przygotowała specjalną wyszukiwarkę [WYBORY 2023]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269731,wybory-2023-jak-sprawdzic-gdzie-mozna-glosowac-pkw-przygotowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269731,wybory-2023-jak-sprawdzic-gdzie-mozna-glosowac-pkw-przygotowala.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T10:12:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ea/d3/1c/z30227690M,Wybory-2023--zdjecie-ilustracyjne-.jpg" vspace="2" />Państwowa Komisja Wyborcza przygotowała wyszukiwarkę obwodowych komisji, pozwalającą w łatwy sposĂłb sprawdzić, gdzie można będzie oddać głos w nadchodzących wyborach parlamentarnych. Wystarczy skorzystać ze strony internetowej PKW, aby uzyskać wszystkie niezbędne informacje.

## Debata TVP wcale nie odbędzie się w siedzibie TVP. "Miejsce wywołało poruszenie"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270163,debata-tvp-wcale-nie-odbedzie-sie-w-siedzibie-tvp-miejsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30270163,debata-tvp-wcale-nie-odbedzie-sie-w-siedzibie-tvp-miejsce.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:43:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2e/dd/1c/z30267182M,Siedziba-TVP-na-ul--Woronicza.jpg" vspace="2" />Debata wyborcza TVP ma się odbyć w studiach ATM w Warszawie przy ul. Wał Miedzeszyński, a nie w siedzibie TVP przy ul. Woronicza - ustaliła Gazeta.pl. Szykuje się superponiedziałek w kampanii wyborczej.

## Mateusz Morawiecki potwierdza swĂłj udział w debacie TVP. "Nie mogę się doczekać!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270175,mateusz-morawiecki-potwierdza-swoj-udzial-w-debacie-tvp-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30270175,mateusz-morawiecki-potwierdza-swoj-udzial-w-debacie-tvp-nie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/50/de/1c/z30270288M,Mateusz-Morawiecki.jpg" vspace="2" />Mateusz Morawiecki weźmie udział w debacie na antenie TVP. Zmierzy się m.in. z Donaldem Tuskiem, ktĂłry będzie reprezentował Koalicję Obywatelską. "Nie mogę się doczekać!" - napisał. "Debata Wyborcza 2023" odbędzie się 9 października o godz. 18.30.

## Dwa wpisy za to 75 tys. zł i dziewięć razy droższy "Sylwester Marzeń". NIK o TVP: Zatrważające wnioski
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30269842,tvp-w-czasach-pis-otrzymala-7-2-mld-zlotych-z-budzetu-panstwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30269842,tvp-w-czasach-pis-otrzymala-7-2-mld-zlotych-z-budzetu-panstwa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/c3/1c/z30162081M.jpg" vspace="2" />Najwyższa Izba Kontroli analizowała działania Telewizji Polskiej, a w piątek przedstawiła pokontrolny raport. Co z niego wynika? NIK wykazała m.in. nieprawidłowości w organizacji "Sylwestera Marzeń" w TVP, ktĂłrego koszt był dziewięciokrotnie wyższy, niż planowano. Wiązało się to z umowami z Mel C i Black Eyed Peas. Wielu pracownikĂłw nie posiadało też minimalnego wynagrodzenia - każdego roku problem ten miał dotyczyć kilkuset pracownikĂłw. TVP zatrudniła też cztery osoby, ktĂłre miały tworzyć wpisy na koncie na Facebooku. Przez dziewięć miesięcy funkcjonowania SwipeTo w mediach społecznościowych zamieszczone zostały dwa wpisy, a koszt tej pracy miał wynieść 75 tys. złotych.

## Politolog o debacie w TVP: Jest takie przekonanie, że to będzie jakaś ucieczka, że ktoś się boi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269632,politolog-o-debacie-w-tvp-jest-takie-przekonanie-ze-to-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269632,politolog-o-debacie-w-tvp-jest-takie-przekonanie-ze-to-bedzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bb/a5/1c/z30039227M,Jaroslaw-Kaczynski-i-Donald-Tusk.jpg" vspace="2" />- Wiadomo, że ta debata telewizyjna przed wieloma laty, w ktĂłrej wzięli udział Kaczyński i Tusk, tylko we dwĂłch, skończyła się niezbyt pomyślnie dla prezesa PiS. Pewnie stawia się w takiej sytuacji znowu, więc ktoś inny weźmie udział - wspomina w rozmowie z Gazeta.pl politolog dr hab. Bartłomiej Biskup, pytany o dyskusję przedwyborczą w TVP. - Taka jest taktyka PiS-u, aby nie doprowadzać do tej bezpośredniej konfrontacji - dodaje.

## Rozpędzony pociąg przeciął w Płocku drogę autobusowi. Dlaczego rogatki nie były opuszczone? [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269609,plock-rozpedzony-pociag-przecial-droge-autobusowi-kierowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269609,plock-rozpedzony-pociag-przecial-droge-autobusowi-kierowca.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/75/de/1c/z30269813M,Plock--Rozpedzony-pociag-przecial-droge-autobusowi.jpg" vspace="2" />Kierowca autobusu zareagował w ostatniej chwili, zanim jego drogę przeciął rozpędzony pociąg. Jak się okazało, na przejeździe kolejowym w Płocku nie były opuszczone rogatki. Komunikacja Miejska Płock udostępniła wideo ze zdarzenia i zaapelowała do PKP.

## Pilne pisma i wnioski ws. zajść po meczu Legii w Alkmaar. Politycy podejmują działania
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269641,pilne-pisma-i-wnioski-po-zajsciu-w-alkmaar-politycy-podejmuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269641,pilne-pisma-i-wnioski-po-zajsciu-w-alkmaar-politycy-podejmuja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/93/de/1c/z30269843M,Minister-sportu-i-turystyki-Kamil-Bortniczuk.jpg" vspace="2" />Minister sportu i turystyki Kamil Bortniczuk poinformował, że w trybie pilnym skierował pismo do ministra sportu Holandii w celu wyjaśnienia zajść, do ktĂłrych doszło w Alkmaar po meczu miejscowego AZ z Legią Warszawa. Europoseł Patryk Jaki zapowiada z kolei złożenie pilnego wniosku o debatę w Parlamencie Europejskim.

## Pokojowa Nagroda Nobla przyznana. Otrzymała ją Narges Mohammadi za walkę o prawa kobiet
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30269258,pokojowa-nagroda-nobla-wreczona-otrzymala-ja-narges-mohammadi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30269258,pokojowa-nagroda-nobla-wreczona-otrzymala-ja-narges-mohammadi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T09:02:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/bf/de/1c/z30270143M,Pokojowa-Nagroda-Nobla-przyznana--Otrzymala-ja-Nar.jpg" vspace="2" />Laureatką Pokojowej Nagrody Nobla została Narges Mohammadi. Irańska działaczka na rzecz praw człowieka była aresztowana już 13 razy.

## Strzegom. Skradziona figura Maryi "powieszona niczym wisielec". Biskup wydał oświadczenie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269521,skradziona-figura-maryi-powieszona-niczym-wisielec-wandalom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269521,skradziona-figura-maryi-powieszona-niczym-wisielec-wandalom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T08:57:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7b/de/1c/z30269819M,Wandale-ukradli-figurke-Maryi-i-powiesili-ja-na-ru.jpg" vspace="2" />DwĂłch wandali ukradło stojącą w przyklasztornej grocie w Strzegomiu figurę Matki Boskiej i umieściło ją na pobliskim rusztowaniu. Biskup świdnicki Marek Mendyk nazwał ten akt obrazą uczuć religijnych i zniewagą. Sprawa została zgłoszona organom ścigania, ktĂłre zatrzymały dwĂłch podejrzanych nastolatkĂłw. Grozi im do dwĂłch lat pozbawienia wolności.

## Czy karta do referendum może zostać podarta lub wyniesiona z lokalu wyborczego? Co za to grozi?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30262716,czy-karta-do-referendum-moze-zostac-podarta-lub-wyniesiona-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30262716,czy-karta-do-referendum-moze-zostac-podarta-lub-wyniesiona-z.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T08:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/de/1c/z30269531M,Wybory-2023--Referendum--zdjecie-ilustracyjne-.jpg" vspace="2" />Referendum odbędzie się tego samego dnia, co wybory parlamentarne. To oznacza, że wraz z kartami do głosowania do pobrania dostępna będzie także karta do referendum. Warto pamiętać, że udział w obu głosowaniach jest dobrowolny i można odmĂłwić przyjęcia ktĂłrejkolwiek z kart. Czy to oznacza, że można podrzeć formularz lub wynieść go z lokalu wyborczego?

## Commander się doszczekał. Pies Joe Bidena opuścił Biały Dom, bo ugryzł 11 agentĂłw. Co najmniej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30269547,commander-sie-doszczekal-pies-joe-bidena-opuscil-bialy-dom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30269547,commander-sie-doszczekal-pies-joe-bidena-opuscil-bialy-dom.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T08:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/0d/de/1c/z30269709M,Commander-Biden.jpg" vspace="2" />Pies rodziny BidenĂłw, Commander, musiał odejść z Białego Domu. Powodem było zachowanie zwierzaka, ktĂłry atakował personel prezydenta. Rzeczniczka pierwszej damy przekazała, że na razie nie wiadomo, co stanie się z owczarkiem niemieckim, ktĂłry miał być zaangażowany w około 11 incydentĂłw.

## "Zwierzęta same o siebie nie zadbają". Lewica przedstawiła nowy program ochrony praw zwierząt
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269278,zwierzeta-same-o-siebie-nie-zadbaja-lewica-przedstawila-nowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269278,zwierzeta-same-o-siebie-nie-zadbaja-lewica-przedstawila-nowy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/41/de/1c/z30269505M,Przedstawiciele-Lewicy-w-schronisku-dla-bezdomnych.jpg" vspace="2" />Lewica zaprezentowała program dla zwierząt, ktĂłry zakłada m.in. wprowadzenie zakazu chowu klatkowego oraz kontrolę nad schroniskami. Podczas konferencji prasowej wybrzmiały też takie postulaty jak: powołanie Rzecznika Praw Zwierząt, czy wprowadzenie bezpłatnych kastracji i sterylizacji dla psĂłw i kotĂłw. - Zawsze byliśmy i zawsze będziemy po stronie zwierząt - podkreślała posłanka Anna-Maria Żukowska.

## Tragiczny finał egzaminu na prawo jazdy w Ostrołęce. 63-letni kursant zasłabł w trakcie jazdy
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269304,tragiczny-final-egzaminu-na-prawo-jazdy-w-ostrolece-63-letni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269304,tragiczny-final-egzaminu-na-prawo-jazdy-w-ostrolece-63-letni.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9d/6e/17/z24568477M,Egzamin-na-prawo-jazdy--zdjecie-ilustracyjne-.jpg" vspace="2" />Do tragicznego zdarzenia doszło w Ostrołęce podczas egzaminu na prawo jazdy. 63-letni kursant nagle zasłabł, po czym stracił przytomność. Mimo długiej reanimacji życia mężczyzny nie udało się uratować.

## Kaczyński odmĂłwił debaty z Tuskiem. "Wiadomości" TVP zarzuciły ucieczkę przed pytaniami... liderowi KO
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269243,kaczynski-odmowil-debaty-z-tuskiem-wiadomosci-tvp-zarzucily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269243,kaczynski-odmowil-debaty-z-tuskiem-wiadomosci-tvp-zarzucily.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b9/dd/1c/z30269369M,-Wiadomosci--TVP-oskarzyly-Donalda-Tuska-o-uciekan.jpg" vspace="2" />Jarosław Kaczyński odrzucił zaproszenie na debatę wyborczą TVP z udziałem Donalda Tuska. Tego samego dnia "Wiadomości" wyemitowały materiał, w ktĂłrym to liderowi Koalicji Obywatelskiej zarzuciły uciekanie przed niewygodnymi pytaniami.

## Szokująca intencja na Jasnej GĂłrze. Modlono się o "mądrość" na wybory 2023 i "nawrĂłcenie wrogĂłw ojczyzny"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269192,wybory-2023-jasna-gora-modli-sie-w-intencji-madrosci-w-czasie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269192,wybory-2023-jasna-gora-modli-sie-w-intencji-madrosci-w-czasie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/dd/1c/z30269345M,Wybory-2023--Jasna-Gora-modli-sie-w-intencji--madr.jpg" vspace="2" />Wybory parlamentarne są coraz bliżej, a na Jasnej GĂłrze trwają msze w intencji "dobrego wyboru przedstawicieli narodu". KościĂłł przekazał, że modlitwa będzie dotyczyć także nawrĂłcenia "wrogĂłw ojczyzny i wiary". To nie pierwszy raz, kiedy Jasna GĂłra staje się miejscem, gdzie pojawia się polityka.

## Onet: TVP zrobiło z Holeckiej i Adamczyka milionerĂłw. "Podpisali też deklarację apolityczności"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269212,onet-tvp-zrobilo-z-holeckiej-i-adamczyka-milionerow-podpisali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269212,onet-tvp-zrobilo-z-holeckiej-i-adamczyka-milionerow-podpisali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:18:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/45/89/1c/z29925189M,-Wiadomosci--TVP.jpg" vspace="2" />Onet ujawnił zarobki czołowych prowadzących "Wiadomości" TVP. Dzięki przelewom z Telewizji Polskiej Danuta Holecka i Michał Adamczyk stali się milionerami - podkreśla portal.

## Grzybiarze z Rumunii znĂłw w lasach na Podkarpaciu. 120 osĂłb na jednej łące, szpaler autokarĂłw. "Inwazja"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269190,grzybiarze-z-rumunii-znow-w-lasach-na-podkarpaciu-na-jednej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269190,grzybiarze-z-rumunii-znow-w-lasach-na-podkarpaciu-na-jednej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T07:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8d/db/1c/z30260621M,Gdzie-na-grzyby-.jpg" vspace="2" />W lasach na Podkarpaciu znĂłw pojawiły się duże grupy grzybiarzy z Rumunii. Podczas jednej z kontroli policja naliczyła aż 120 zbieraczy. - To prawdziwa inwazja. Nie mamy z nimi szans - narzekają mieszkańcy regionu.

## Kobiety mogłyby zdecydować o wyniku wyborĂłw. Dlaczego Polki nie chcą głosować?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269163,najwieksza-grupa-niezdecydowanych-wyborcow-to-kobiety-dlaczego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269163,najwieksza-grupa-niezdecydowanych-wyborcow-to-kobiety-dlaczego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T06:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9e/ec/19/z27181470M,Wybory--zdjecie-ilustracyjne-.jpg" vspace="2" />Kobiety są najbardziej niezdecydowaną grupą osĂłb, ktĂłre na nieco podnad tydzień przed wyborami nadal nie wiedzą, czy będą uczestniczyły w głosowaniach - tak wynika z najnowszego raportu opublikowanego przez "Rzeczpospolitą". Według autorĂłw opracowania, "udział w głosowaniu deklaruje 52 proc. kobiet w wieku 18-45 lat i 66 proc. kobiet 45 plus, w porĂłwnaniu z 58 proc. i 76 proc. mężczyzn w analogicznych grupach wiekowych". Co więcej, rĂłwnie znacząca rĂłżnica występuje w przypadku wyboru konkretnej opcji politycznej.

## Łukasz Mejza pożyczył 300 tys. zł. Kandydat PiS nie ujawnia, od kogo i w jakim celu. "Złamał przepisy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269160,lukasz-mejza-pozyczyl-300-tys-zl-kandydat-pis-nie-ujawnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269160,lukasz-mejza-pozyczyl-300-tys-zl-kandydat-pis-nie-ujawnia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T06:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ca/cb/1a/z28097994M,Lukasz-Mejza.jpg" vspace="2" />Łukasz Mejza napisał w swoim oświadczeniu majątkowym, że wziął 300 tysięcy złotych od osoby fizycznej. Kandydat PiS nie ujawnił, kto i na jakich warunkach udzielił mu pożyczki. Prawnik komentujący tę sprawę stwierdził, że Mejza złamał przepisy. Ekspert wspomniał rĂłwnież o potencjalnym konflikcie interesĂłw.

## Spora wpadka Jarosława Kaczyńskiego podczas wiecu w Busku-Zdroju. "O Jezus Maria, Panie Boże wybacz!"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269188,spora-wpadka-jaroslawa-kaczynskiego-podczas-wiecu-o-jezus.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30269188,spora-wpadka-jaroslawa-kaczynskiego-podczas-wiecu-o-jezus.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T06:13:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/16/dd/1c/z30269206M,Jaroslaw-Kaczynski.jpg" vspace="2" />- Przekonujmy ludzi, żeby szli na wybory, to po pierwsze. Po drugie, żeby głosowali w referendum - zachęcał wyborcĂłw z Buska-Zdroju prezes PiS Jarosław Kaczyński. Chwilę pĂłźniej zaliczył solidną wpadkę. - O przepraszam! O Jezus Maria, Panie Boże, wybacz mi - skomentował zaskoczony swoją pomyłką.

## Ekstradycja Sebastiana M. do Polski. Kierowca BMW ma podwĂłjne obywatelstwo. Jest reakcja Niemiec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269161,ekstradycja-sebastiana-m-do-polski-kierowca-bmw-ma-podwojne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269161,ekstradycja-sebastiana-m-do-polski-kierowca-bmw-ma-podwojne.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T06:05:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/dc/1c/z30261386M,Sebastian-M--zatrzymany.jpg" vspace="2" />Sebastian M., ktĂłry miał spowodować tragiczny wypadek na autostradzie A1, czeka w Zjednoczonych Emiratach Arabskich na ekstradycję do Polski. Ta procedura może potrwać nawet kilka miesięcy. Tymczasem na działania polskich służb związane z 32-latkiem, ktĂłry posiada podwĂłjne obywatelstwo, zareagowało MSZ Niemiec.

## Aleksander Kwaśniewski zmaga się z chorobą. "Dwie godziny pĂłźniej nie mogłem wstać z fotela"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269159,aleksander-kwasniewski-zmaga-sie-z-grozna-bakteria-dwie-godziny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30269159,aleksander-kwasniewski-zmaga-sie-z-grozna-bakteria-dwie-godziny.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T05:48:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fc/dd/1c/z30269180M,Aleksander-Kwasniewski.jpg" vspace="2" />Aleksander Kwaśniewski ujawnił, że od pewnego czasu zmaga się z niepokojącymi dolegliwościami, ktĂłre pojawiły się po niewielkim zabiegu kolana wykonanym przed sezonem narciarskim. Zdaniem polityka odpowiedzialna za to jest groźna bakteria.

## Awantura w TVP. Lubnauer do Kłeczka: Wiemy, kto panu pisze pytania
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30269136,awantura-w-tvp-lubnauer-do-kleczka-wiemy-kto-panu-pisze-pytania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30269136,awantura-w-tvp-lubnauer-do-kleczka-wiemy-kto-panu-pisze-pytania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T05:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d0/d4/1c/z30229200M,Katarzyna-Lubnauer-w-trakcie-debaty-w-Gazeta-pl.jpg" vspace="2" />W czwartkowy wieczĂłr w programie "Minęła 20" doszło do spięcia między pracownikiem TVP Info Miłoszem Kłeczkiem a posłanką Koalicji Obywatelskiej Katarzyną Lubnauer. - Pan się zachowuje jak przedstawiciel PiS w tym programie. Pan ma zadawać pytania o nasze poglądy, a nie odpytywać mnie. Nie jest pan do tego - mĂłwiła polityczka.

## Brudziński się wściekł. Radził swoim ludziom "kury szczać prowadzać, a nie robić politykę"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30266977,brudzinski-sie-wsciekl-radzil-swoim-ludziom-kury-szczac-prowadzac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30266977,brudzinski-sie-wsciekl-radzil-swoim-ludziom-kury-szczac-prowadzac.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6d/81/1c/z29889389M,Joachim-Brudzinski.jpg" vspace="2" />Szef sztabu PiS europoseł Joachim Brudziński wściekł się za przeciek z zamkniętej grupy parlamentarzystĂłw, na ktĂłrej instruuje, jak mają prowadzić kampanię w internecie. Radził naszym rozmĂłwcom z PiS "kury szczać prowadzać, a nie robić politykę".

## Koalicja Konfederacji z PiS? Wipler: Nie. My będziemy podbierać im posłĂłw. Rozmawiam już z nimi
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30265512,wipler-w-gazeta-pl-czesc-naszych-dzialaczy-to-ludzie-niemadrzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30265512,wipler-w-gazeta-pl-czesc-naszych-dzialaczy-to-ludzie-niemadrzy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/86/dd/1c/z30267014M,Przemyslaw-Wipler.jpg" vspace="2" />- Część naszych działaczy to ludzie niedoświadczeni lub po prostu niemądrzy, ale nie będę tutaj odnosił się do każdego z osobna. O Sikorskim nikt nie mĂłwi "były polityk PiS", a mi się to wyciąga, choć w PiS-ie byłem 10 lat temu przez rok. MĂłwcie to do Sikorskiego, Kowala, Poncyljusza. Tylko nas się o to pyta i tylko nam wyciąga się radykałĂłw - rozmowa z Przemysławem Wiplerem z Konfederacji.

## Rozdział Kościoła od państwa w kampanii wyborczej. PrzemĂłwienia z ambony, ulotki i "polecenia"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30265135,rozdzial-kosciola-od-panstwa-w-kampanii-wyborczej-przemowienia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30265135,rozdzial-kosciola-od-panstwa-w-kampanii-wyborczej-przemowienia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:45:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/c3/1c/z30161465M,Kosciol--zdjecie-ilustracyjne-.jpg" vspace="2" />W kampanii wyborczej, ktĂłra miała miejsce cztery lata temu, naliczyliśmy o wiele więcej incydentĂłw związanych z pojawianiem się polityki w kościołach. W 2023 roku takich przypadkĂłw jest zdecydowanie mniej, być może za sprawą apeli prymasa Polski Wojciecha Polaka czy kardynała Grzegorza Rysia. Co ciekawe, wymienione niżej incydenty związane są głĂłwnie z jedną partią polityczną - Prawem i Sprawiedliwością.

## KtĂłra partia pozwoli na aborcję? Prawa kobiet w programach [PiS, KO, Konfederacja, Trzecia Droga, Lewica]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30248567,ktora-partia-pozwoli-na-aborcje-prawa-kobiet-w-programach-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30248567,ktora-partia-pozwoli-na-aborcje-prawa-kobiet-w-programach-pis.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d9/ca/19/z27042777M,ZDJECIE-ILUSTRACYJNE--Demonstracja-przeciwko-zaost.jpg" vspace="2" />51,7 proc. polskiego społeczeństwa stanowią kobiety, dlatego też do nich skierowana jest część postulatĂłw wyborczych partii przed wyborami parlamentarnymi w 2023 roku. KtĂłra partia opowiada się za legalną aborcją? Kto oferuje dostęp do bezpłatnej antykoncepcji, a kto opowiada się za "obroną rodziny naturalnej"? Przedstawiamy analizę programĂłw wyborczych KO, PiS, Konfederacji, Trzeciej Drogi, Lewicy oraz Bezpartyjnych SamorządowcĂłw.

## "Ekscytacja" Rafała Bochenka debatą w TVP. "Panie Donaldzie, odwagi"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30268974,ekscytacja-rafala-bochenka-debata-w-tvp-panie-donaldzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30268974,ekscytacja-rafala-bochenka-debata-w-tvp-panie-donaldzie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/39/dd/1c/z30268985M,Rafal-Bochenek-o-debacie-TVP-w-udzialem-Donalda-Tu.jpg" vspace="2" />"Panie Donaldzie, odwagi, to będzie Pana chwila prawdy, prawdziwy test" - zachęca i przestrzega byłego premiera, byłego szefa Rady Europejskiej i przewodniczącego największej partii opozycyjnej w Polsce Rafał Bochenek. Rzecznik PiS-u skomentował w sieci udział Donalda Tuska w debacie TVP, ktĂłra jest zaplanowana na 9 października.

## Rosjanie masowo rezygnują z telewizji. Mają dość kremlowskiej propagandy?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30268654,rosjanie-masowo-rezygnuja-z-telewizji-maja-dosc-kremlowskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30268654,rosjanie-masowo-rezygnuja-z-telewizji-maja-dosc-kremlowskiej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/dd/1c/z30268787M,Wladimir-Putin.jpg" vspace="2" />Mimo miliardĂłw przeznaczanych na utrzymanie państwowych mediĂłw, odsetek osĂłb, ktĂłre zrezygnowały z oglądania telewizji wzrĂłsł blisko trzykrotnie w ciągu zaledwie pięciu lat - poinformował dyrektor generalny OgĂłlnorosyjskiego Centrum Badań Opinii Publicznej (VTsIOM). Co więcej, za sprawą propagandowych przekazĂłw zanotowano rekordowo niski poziom zaufania Rosjan do publicznych przekazĂłw.

## Miał przyjść pijany na egzamin na prawo jazdy. Teraz na przez wiele lat może nie wsiąść za kĂłłko
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30268247,mial-przyjsc-pijany-na-egzamin-na-prawo-jazdy-teraz-na-przez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30268247,mial-przyjsc-pijany-na-egzamin-na-prawo-jazdy-teraz-na-przez.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T04:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/73/dd/1c/z30268275M,30-latek-mial-pojawic-sie-na-panstwowym-egzaminie-.jpg" vspace="2" />Przygotował się do jazdy i wykonał pierwszy manewr na placu - tyle zdążył zrobić 30-latek, nim egzaminator wyczuł od niego woń alkoholu. Podczas egzaminu w ośrodku w Pile (woj. wielkopolskie), mężczyzna miał mieć ponad pĂłł promila alkoholu w organizmie. Teraz grozi mu grzywna, nawet dwa lata więzienia i wieloletni zakaz prowadzenia pojazdĂłw.

## USA. Kobieta utknęła pod nowojorskim molo. Na ratunek ruszyła łĂłdź policyjna [WIDEO]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30268679,usa-kobieta-utknela-pod-nowojorskim-molo-na-ratunek-ruszyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30268679,usa-kobieta-utknela-pod-nowojorskim-molo-na-ratunek-ruszyla.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T03:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5f/dd/1c/z30268767M,Nowojorscy-policjanci-pomogli-kobiecie--ktora-utkn.jpg" vspace="2" />Sukcesem zakończyła się akcja ratunkowa przeprowadzona przez nowojorskich policjantĂłw na brooklińskim molo. Funkcjonariusze pomogli młodej kobiecie, ktĂłra z nieznanych przyczyn utknęła pod pomostem. Nagraniem z zajścia podzielili się w mediach społecznościowych.

## Horoskop dzienny - piątek 6 października 2023 [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30266292,horoskop-dzienny-piatek-6-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30266292,horoskop-dzienny-piatek-6-pazdziernika-2023-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-10-06T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2c/d0/1c/z30214700M,Horoskop-na-piatek.jpg" vspace="2" />Horoskop dzienny - piątek 6 października 2023 r. Barany, Wodniki i Koziorożce będą pełne energii do działania i nowych pomysłĂłw. Nieco inaczej będą się dziś czuły Wodniki i Skorpiony, ktĂłre będą wyjątkowo zapobiegawcze. Co czeka pozostałe znaki zodiaku?

