# Source:SciShow, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow, language:en-US

## The Rocket that Hopped
 - [https://www.youtube.com/watch?v=0T663FfZul4](https://www.youtube.com/watch?v=0T663FfZul4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCZYTClx2T1of7BRZ86-8fow
 - date published: 2023-10-06T21:00:00+00:00

Surveyor 6 may not have been the first craft to make a soft landing on the Moon, but it *is* the first craft to take off from the surface of another world. And it did so in a very adorable way. Long before any Apollo astronaut, Surveyor 6 hopped on the Moon.

Hosted by: Savannah Geary (they/them)
----------
Support SciShow by becoming a patron on Patreon: https://www.patreon.com/scishow
----------
Huge thanks go to the following Patreon supporters for helping us keep SciShow free for everyone forever: Adam Brainard, Alex Hackman, Ash, Bryan Cloer, charles george, Chris Mackey, Chris Peters, Christoph Schwanke, Christopher R Boucher, Dr. Melvin Sanicas, Harrison Mills, Jaap Westera, Jason A Saslow, Jeffrey Mckishen, Jeremy Mattern, Kevin Bealer, Matt Curls, Michelle Dove, Piya Shedden, Rizwan Kassim, Sam Lutfi
----------
Looking for SciShow elsewhere on the internet?
SciShow Tangents Podcast: https://scishow-tangents.simplecast.com/
TikTok: https://www.tiktok.com/@scishow 
Twitter: ht

