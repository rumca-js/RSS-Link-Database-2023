# Source:Nautilus, URL:https://nautil.us/feed/, language:en-US

## The Usefulness of a Memory Guides Where the Brain Saves It
 - [https://nautil.us/the-usefulness-of-a-memory-guides-where-the-brain-saves-it-410256/](https://nautil.us/the-usefulness-of-a-memory-guides-where-the-brain-saves-it-410256/)
 - RSS feed: https://nautil.us/feed/
 - date published: 2023-10-06T21:19:45+00:00

<p>New research finds that the memories useful for future generalizations are held in the brain separately from those recording unusual events.</p>
<p>The post <a href="https://nautil.us/the-usefulness-of-a-memory-guides-where-the-brain-saves-it-410256/" rel="nofollow">The Usefulness of a Memory Guides Where the Brain Saves It</a> appeared first on <a href="https://nautil.us" rel="nofollow">Nautilus</a>.</p>

## My 3 Greatest Revelations
 - [https://nautil.us/my-3-greatest-revelations-3-410146/](https://nautil.us/my-3-greatest-revelations-3-410146/)
 - RSS feed: https://nautil.us/feed/
 - date published: 2023-10-06T19:18:50+00:00

<p>The author on writing his new book “Crossings,” about the environmental destruction of roads.</p>
<p>The post <a href="https://nautil.us/my-3-greatest-revelations-3-410146/" rel="nofollow">My 3 Greatest Revelations</a> appeared first on <a href="https://nautil.us" rel="nofollow">Nautilus</a>.</p>

