# Source:Louder With Crowder, URL:http://louderwithcrowder.com/feed/, language:en-US

## Woke School Cancels Halloween, Ruins Fun In The Name Of "Equity" And "Inclusion"
 - [https://www.louderwithcrowder.com/northboro-halloween-canceled](https://www.louderwithcrowder.com/northboro-halloween-canceled)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T21:11:20+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49271895&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Progressives are very miserable people who try to ruin everything for everyone else. This includes crushing all the fun and joy for kids. </p><p>In yet another attempt to solve racism or whatever, Halloween has been canceled. </p><p>This week, school officials from Northboro Public Schools notified parents that students would not be allowed to wear costumes to school for Halloween, and the parade through the halls would be canceled.</p><p class="shortcode-media shortcode-media-youtube">
<span class="rm-shortcode" style="display: block; padding-top: 56.25%;"></span>
<small class="image-media media-caption">Northboro schools change Halloween festivities to promote "equity and inclusion"</small>
<small class="image-media media-photo-credit">
<a href="https://www.youtube.com/watch?v=50TtX7tTry8" target="_blank">www.youtube.com</a>
<

## Los Angeles Students Young As 5 Set For Week-Long Celebrations Of ‘National Coming Out Day’
 - [https://www.louderwithcrowder.com/lausd-national-coming-out-day](https://www.louderwithcrowder.com/lausd-national-coming-out-day)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T20:41:08+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49271551&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C1%2C0" /><br /><br /><p>One way to tell if a social movement is degenerate is to see if it targets children. </p><p>Los Angeles Unified test results revealed that for 2022, 58.29 percent of students did not meet state standards in English, and only 28.49 percent of students met the state standard in Math, with 71.51 percent not meeting it, <a href="https://caaspp.edsource.org/sbac/los-angeles-unified-19647330000000#:~:text=Overall%20Test%20Results,of%20%2D4.98%25%20from%202019." rel="noopener noreferrer" target="_blank">according </a>to EdSource. </p><p>So, you would think that the Los Angeles Board of Education would be focused on education given the dire test scores. </p><p>Well, they actually have more important things to do. </p><p><a href="https://www.foxnews.com/media/la-elementary-schools-celebrate-national-coming-out-day-week-lgbtq-lessons" rel

## Watch: Here's All The Derpy Moments Joe Biden Has During Speech On His Economic Disasters
 - [https://www.louderwithcrowder.com/biden-drowning-dog](https://www.louderwithcrowder.com/biden-drowning-dog)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T20:33:58+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49271488&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C2%2C0" /><br /><br /><p>How is the leader of the free world doing? Well, he did not <a href="https://www.dailymail.co.uk/news/article-12562995/Joe-Biden-trips-short-stairs-Air-Force-One-secret-mission.html" rel="noopener noreferrer" target="_blank">fall </a>up the stairs today.</p>
<p>At least we can praise the <a href="https://www.axios.com/2023/09/26/biden-trip-2024-campaign-sneakers" rel="noopener noreferrer" target="_blank">success </a>of mission “don't-let-him-trip.” </p>
<p>Sleepy Joe attempted to tout a “better-than-expected job growth” in September by claiming that the U.S. added 336,000 jobs. However, he did not provide any details other than that. </p>
<p>Naturally, Biden took this as the perfect moment to praise Bidenomics as he continues to lie and deny reality. </p>
<p>But unfortunately, viewers were left even more confused than ever. </p>

## Watch: Tucker Carlson's Face After Being Told What Caused Trans Boom Says It All
 - [https://www.louderwithcrowder.com/tucker-chris-moritz](https://www.louderwithcrowder.com/tucker-chris-moritz)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T18:00:52+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49267015&amp;width=1200&amp;height=800&amp;coordinates=101%2C0%2C291%2C0" /><br /><br /><p>In case you didn't know, politicians do not actually read legislation that they vote on. </p><p>“We have to pass [ObamaCare] so that you can find out what is in it,” Nancy Pelosi once <a href="https://posey.house.gov/news/documentsingle.aspx?DocumentID=176009" rel="noopener noreferrer" target="_blank">said</a>. </p><p>Well, that may have been one of the only truthful things that the former speaker has ever said. </p><p>It is often understood that political corruption can be brought to light when you ‘follow the money.’ </p><p>Chris Moritz, a policy expert who claims to have been doing just that, went on Tucker Carlson’s <a href="https://twitter.com/TuckerCarlson/status/1709689853661913465" rel="noopener noreferrer" target="_blank">show </a>on X to discuss the significant increase in the number of young people who identify as

## Watch: Teacher on leave after being caught watching porn in front of students, enjoying himself a little bit too much
 - [https://www.louderwithcrowder.com/california-teacher-masturbating-watching-porn](https://www.louderwithcrowder.com/california-teacher-masturbating-watching-porn)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T17:16:05+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49266104&amp;width=1200&amp;height=800&amp;coordinates=117%2C0%2C117%2C0" /><br /><br /><p>Being a pervert is bad enough. Being a pervert who is also a teacher should get you on a list. Being a pervert who is not only a teacher but also a moron is why we have this story. A California (of course) teacher is on leave after getting caught watching porn on his phone in front of the class. He was also, I think I have to say "allegedly", pleasuring himself while doing so.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/KGETnews/status/1710107118223654946"></a>
</blockquote>

<p>Funny thing about high school students? They all have phones of their own. And social media accounts. Not that this is the first teacher <a href="https://www.louderwithcrowder.com/teacher-being-sneaky-parents" target="_blank">who has proven</a> they don't <a href="https

## Watch: Hillary Clinton Stops Pretending, Demands 'Formal Deprogramming' Of MAGA 'Cult Members'
 - [https://www.louderwithcrowder.com/clinton-maga-deprogramming](https://www.louderwithcrowder.com/clinton-maga-deprogramming)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T16:11:44+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49265479&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>Anyone who is not considered loyal enough to the progressive left may soon be sent to re-education camps for brainwashing. </p><p>Hilary Clinton, who was probably the most unlikable presidential candidate in American history, thinks that anyone who did not vote for her in 2016 needs to be <a href="https://www.foxnews.com/media/hillary-clinton-floats-formal-deprogramming-trump-supporters-suggests-gop-base-bigots" rel="noopener noreferrer" target="_blank">‘deprogrammed</a>.’ </p><p>Killary called for a "formal deprogramming" for many Trump supporters during a CNN interview.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/alexharmstrong/status/1710286659055501569"></a>
</blockquote>
<p>Clinton compared the "sane" part of the GOP that helped prevent a shut

## Congressman Jim Jordan will be the next Speaker of the House
 - [https://www.louderwithcrowder.com/jim-jordan-speaker-of-the-house](https://www.louderwithcrowder.com/jim-jordan-speaker-of-the-house)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T14:19:27+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.jpg?id=49263699&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>It's not official until the vote happens. But I don't see how Congressman Jim Jordan is not the Speaker of the House by this time next week.</p><p>Right now there are only two people who have announced they were running: Jordan and Rep. Steve Scalise, and I can't see Scalise staying in as momentum goes Jordan's way. <a href="https://www.louderwithcrowder.com/byron-donalds-speaker-of-the-house" target="_blank">There were rumors of Rep. Byron Donalds being the frontrunner</a>, but considering he shared the announcement that the former president endorsed Jordan, I don't think he's going to run himself.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/ByronDonalds/status/1710259448067830171"></a>
</blockquote>

<p>Jordan as Speaker will make things very int

## Keith Olbermann lashes out at reporter for accurately reporting the accusations against Trevor Bauer were bullplop
 - [https://www.louderwithcrowder.com/keith-olbermann-trevor-bauer](https://www.louderwithcrowder.com/keith-olbermann-trevor-bauer)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T13:37:46+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49263001&amp;width=1245&amp;height=700&amp;coordinates=0%2C0%2C0%2C0" /><br /><br /><p>The apology is never as aloud as the disrespect. It's not like we expected journalsimers to admit they were wrong when they found MLB player Trevor Bauer guilty in the court of public opinion over sexual assault allegations we know now to be false. But Keith Olbermann is a special brand of douche. He's angry at a single reporter for reporting the facts as we know them NOW.</p><p>This is Trevor Bauer, explaining after two years of having his life destroyed, that professional 304 Lindsey Hill lied about him sexually assaulting her, <a href="https://www.louderwithcrowder.com/trevor-bauer-speaks-out" target="_blank">complete with a video of her smiling after they had sex</a>.</p><blockquote class="rm-embed twitter-tweet">
<div style="margin: 1em 0;"></div> —  (@)
        <a href="https://twitter.com/BauerOutage/status/17089045257242

## Watch: Euro smokeshow goes viral showing Americans how to wreck shoplifters (it includes pepper spraying them)
 - [https://www.louderwithcrowder.com/finland-shoplifer](https://www.louderwithcrowder.com/finland-shoplifer)
 - RSS feed: http://louderwithcrowder.com/feed/
 - date published: 2023-10-06T12:34:54+00:00

<img src="https://www.louderwithcrowder.com/media-library/image.png?id=49247536&amp;width=1200&amp;height=800&amp;coordinates=200%2C0%2C0%2C0" /><br /><br /><p>A Friday palate cleanser for all my Dot Commies. The internet over the past few years has shown a ton of shoplifters waltzing out the door since stealing is legal-ish in America. On the rare instance a store employee so much as increases the bass in their voice, they get fired. Compare that to Finland, where a smokeshow of a store clerk dragged a thief back into the store. After blasting them with pepper spray.</p><p>The video is going viral today thanks to <a href="https://twitter.com/CatchUpFeed" target="_blank">the Catch Up Network</a>. It's from 2015. HOWEVER, there is a key point to be made, You know how we at the Louder with Crowder Dot Com website are fond of saying "<a href="https://www.louderwithcrowder.com/australian-bank-cash" target="_blank">Pay Attention, America</a>" to Europe because <a href="https://www.louderw

