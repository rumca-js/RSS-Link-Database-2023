# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Kredyt na studia medyczne - rusza przyjmowanie wniosków
 - [https://www.wirtualnemedia.pl/artykul/kredyt-na-studia-medyczne-jak-zdobyc-bank-pekao-oferta](https://www.wirtualnemedia.pl/artykul/kredyt-na-studia-medyczne-jak-zdobyc-bank-pekao-oferta)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T08:59:00+00:00

Bank Pekao S.A., jako jedyny bank w Polsce, kolejny raz rozpoczyna nabór wniosków o sfinansowanie czesnego za płatne studia na kierunku lekarskim. Kwota refinansowania może sięgnąć nawet 22 tys. złotych za semestr. W pierwszej edycji programu – w roku akademickim 2022/2023, Bank Pekao S.A. udzielił blisko 1800 takich kredytów.

## Żabka z 10 tys. sklepów. Będą też całodobowe i drive thru
 - [https://www.wirtualnemedia.pl/artykul/zabka-nowe-sklepy-calodobowe-drive-thru](https://www.wirtualnemedia.pl/artykul/zabka-nowe-sklepy-calodobowe-drive-thru)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T05:37:58.258278+00:00

Grupa Żabka Polska w październiku przekroczy poziom 10 tys. sklepów. Otworzy też swoje pierwsze placówki handlowe w dwóch nowych formatach: całodobowym (pod marką Żabka Non Stop) i drive thru.

## Branża IT wymaga dbałości o dobrostan psychiczny pracowników? "Konkurencyjność to nie tylko wynagrodzenie"
 - [https://www.wirtualnemedia.pl/artykul/branza-it-wymaga-dbalosci-o-dobrostan-psychiczny-pracownikow-konkurencyjnosc-to-nie-tylko-wynagrodzenie](https://www.wirtualnemedia.pl/artykul/branza-it-wymaga-dbalosci-o-dobrostan-psychiczny-pracownikow-konkurencyjnosc-to-nie-tylko-wynagrodzenie)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T05:37:58.257769+00:00

Konkurencyjność na rynku pracy to nie tylko atrakcyjne wynagrodzenie, to także dbałość o dobrostan psychiczny pracowników, w tym dostęp do opieki psychologicznej - przekonują eksperci Organizacji Pracodawców Usług IT SoDA.

## WARS zapowiada rozwój gastronomii kolejowej i stacjonarnego cateringu
 - [https://www.wirtualnemedia.pl/artykul/wars-rozwoj-gastronomia-kolejowa-stacjonarny-catering](https://www.wirtualnemedia.pl/artykul/wars-rozwoj-gastronomia-kolejowa-stacjonarny-catering)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T05:37:58.257238+00:00

Głównym celem spółki WARS jest rozwój gastronomii kolejowej w pociągach oraz stacjonarnych usług cateringowych - przekazał Grzegorz Bębenek, główny specjalista ds. marketingu w spółce.

## Prezes NBP: Wzywam TVN, Radio Zet, TOK FM, RMF żeby przestały szkodzić Polakom
 - [https://www.wirtualnemedia.pl/artykul/prezes-nbp-stopy-procentowe-inflacja-ceny-pali-wzywam-tvn-radio-zet-tok-fm-rmf-zeby-przestaly-szkodzic-polakom](https://www.wirtualnemedia.pl/artykul/prezes-nbp-stopy-procentowe-inflacja-ceny-pali-wzywam-tvn-radio-zet-tok-fm-rmf-zeby-przestaly-szkodzic-polakom)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T05:37:58.256721+00:00

Spadek cen paliw nie ma wpływu na wysokość inflacji - powiedział w czwartek na konferencji prezes Narodowego Banku Polskiego (NBP) Adam Glapiński. Dodał, że inflacja szybko spada. Naszym celem inflacyjnym jest 2,5 proc. - przypomniał.

## Akcje Allegro za 1,3 mld zł na sprzedaż
 - [https://www.wirtualnemedia.pl/artykul/allegro-akcje-sprzedaz-glowni-inwestorzy](https://www.wirtualnemedia.pl/artykul/allegro-akcje-sprzedaz-glowni-inwestorzy)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T04:33:32.001679+00:00

Według agencji Bloomberg główni akcjonariusze Allegro znów wystawiają pakiet jego walorów na sprzedaż. Tym razem to 42 mln akcji, przy obecnym kursie wycenianych na 1,3 mld zł.

## Niemiecki kanał sportowy szykuje ekspansję w Polsce
 - [https://www.wirtualnemedia.pl/artykul/jak-odbierac-sport1-kanal-sportowy-oferta](https://www.wirtualnemedia.pl/artykul/jak-odbierac-sport1-kanal-sportowy-oferta)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-10-06T04:33:32.001126+00:00

Kanał  Sport1, obecny w polskich sieciach kablowych w latach 90. jako DSF, inwestuje nad Wisłą. Firma stworzyła centrum technologiczne S1 Technology Hub z siedzibą w Warszawie i zapowiedziała „ekspansję w Polsce w celu uzyskania jeszcze silniejszej pozycji w obszarze cyfrowym”.

