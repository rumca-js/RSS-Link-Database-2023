# Source:Fearless & Far, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg, language:en-US

## How The Mayan Tribe Hunt!
 - [https://www.youtube.com/watch?v=CVA_biK78VU](https://www.youtube.com/watch?v=CVA_biK78VU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg
 - date published: 2023-10-06T15:00:09+00:00

While traveling through Mexico's Yucatan Peninsula, we uncovered the intriguing world of Mayan hunting, where the tribe utilizes homemade firearms crafted from reclaimed materials.

Watch The Full Video: https://youtu.be/jDSUveKJ9aY?si

