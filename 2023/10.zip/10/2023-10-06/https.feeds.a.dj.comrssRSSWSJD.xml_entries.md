# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## Amazon Launches First Satellites in Bid to Challenge SpaceX's Starlink
 - [https://www.wsj.com/articles/amazon-project-kuiper-satellite-launch-a0843bfc?mod=rss_Technology](https://www.wsj.com/articles/amazon-project-kuiper-satellite-launch-a0843bfc?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-10-06T18:14:00+00:00

A rocket carrying the e-commerce firm’s Project Kuiper prototypes lifted off from Florida.

## Tired of Ill-Fitting Shoes? These Customizable Sneaker Brands Want to Help
 - [https://www.wsj.com/articles/shoes-dont-fit-try-customizable-sneakers-9ac57a02?mod=rss_Technology](https://www.wsj.com/articles/shoes-dont-fit-try-customizable-sneakers-9ac57a02?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-10-06T15:00:00+00:00

From scanning your foot with an app to being able to tighten different parts of your shoe independently, sneaker technology has come a long way in making your shod feet comfortable

