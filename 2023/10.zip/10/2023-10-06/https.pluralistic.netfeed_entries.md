# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Serializing the opening of "The Lost Cause" (06 Oct 2023)
 - [https://pluralistic.net/2023/10/06/green-new-deal-fic/](https://pluralistic.net/2023/10/06/green-new-deal-fic/)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2023-10-06T11:37:20+00:00

Today's links Serializing the opening of "The Lost Cause": My novel of climate hope, out on November 14. Hey look at this: Delights to delectate. This day in history: 2003, 2008, 2013, 2018, 2022 Colophon: Recent publications, upcoming/recent appearances, current writing projects, current reading Serializing the opening of "The Lost Cause" (permalink) My next novel is The Lost Cause, a hopeful tale of the climate emergency, which comes out on November 14. Kim Stanley Robinson called it "an unforgettable vision of what could be": https://us.macmillan.com/books/9781250865939/the-lost-cause I'm currently running a Kickstarter campaign to pre-sell the audiobook, which I produced and narrated myself (for complex and awful reasons, Amazon won't carry my audiobooks, see the Kickstarter campaign page for details). You can also pre-order the ebook and hardcovers, including signed and personalized copies: http://lost-cause.org For the next week or so, I'm going to be serializing the prologue o

