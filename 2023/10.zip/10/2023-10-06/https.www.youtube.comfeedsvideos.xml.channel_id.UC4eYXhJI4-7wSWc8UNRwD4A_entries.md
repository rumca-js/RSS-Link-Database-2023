# Source:NPR Music, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A, language:en-US

## Villano Antillano: Tiny Desk Concert
 - [https://www.youtube.com/watch?v=RxhleZbLF64](https://www.youtube.com/watch?v=RxhleZbLF64)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC4eYXhJI4-7wSWc8UNRwD4A
 - date published: 2023-10-06T09:00:15+00:00

This Latinx Heritage Month Tiny Desk is celebrating with an 'El Tiny' takeover, featuring a wide array of artists from all corners of Latinidad.

October 6, 2023 | Isabella Gomez Sarmiento

Villano Antillano kicked off her Tiny Desk Concert with a Britney Spears-approved message: Dump. Him.

"Yo Tengo un Novio," off the Puerto Rican rapper's debut LP, La Sustancia X, called out the toxic, controlling expectations of one of her ex-jevos. Through her sharp Caribbean flow, Antillano broke down the confines of monogamy in her first song before casting light on drug use and escapism as a means of queer survival in "Kaleidoscópica."

Throughout her performance, Antillano showed why she's one of the most exciting voices in Latin trap and reggaeton right now. She flaunted her sexual prowess on "Cuero," and "Cáscara de Coco," then intentionally honored her religious upbringing and place in the church, which she noted isn't always a welcoming space for LGBTQ+ communities. The artist keeps prov

