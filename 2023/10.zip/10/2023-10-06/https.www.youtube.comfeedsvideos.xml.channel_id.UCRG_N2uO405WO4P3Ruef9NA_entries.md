# Source:Friday Checkout, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA, language:en-US

## First major smartphone made in Europe!
 - [https://www.youtube.com/watch?v=IAo6Oumr6mA](https://www.youtube.com/watch?v=IAo6Oumr6mA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRG_N2uO405WO4P3Ruef9NA
 - date published: 2023-10-06T16:32:40+00:00

Get a $20 discount on Nebula using my link (sponsored): https://go.nebula.tv/tfc

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬  
 
►►► This video ◄◄◄  

This week Nokia launched its first phone made in Europe, the Google Pixel 8 series was announced, ending the age of good prices, Microsoft admits Bing is worse than Google and Samung Developer Conference reveals new updates.

Episode 167
 
This video on Nebula: https://nebula.tv/videos/tfc-first-major-smartphone-made-in-europe

▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬

►►► TechAltar links ◄◄◄  
 
Social media:  
https://mas.to/@techaltar
https://bsky.app/profile/techaltar.bsky.social
https://instagram.com/TechAltar 
https://discord.gg/npKQebe  
 
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
►►► Attributions & Time stamps◄◄◄
 
Writing & Research: Tristan Rayner
Music by Edemski: https://soundcloud.com/edemski 
Fingerprint icon by Pixel perfect, via Flaticon: https://www.flaticon.com/free-icons/touch-id

0:00 Intro
0:17 Nokia, made in Europe
1:24 Pixel price thoughts
4:06 Satya blames Bi

