# Source:Nerdstalgic, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ, language:en-US

## Why Do Sitcoms Tell Us When To Laugh?
 - [https://www.youtube.com/watch?v=ijRjvY17aSI](https://www.youtube.com/watch?v=ijRjvY17aSI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCXjmz8dFzRJZrZY8eFiXNUQ
 - date published: 2023-10-06T17:00:29+00:00

Use code NERDSTALGIC50 to get 50% off your first Factor box at https://bit.ly/3LoT5hq!

The Laugh Track has become synonymous with sitcoms since the early days of television.  The Laugh Track was used to give at home audiences the feeling of a live studio performance, but over the years it became a crutch to let the audience know when to laugh.   Though most modern sitcoms have stopped using the laugh track, looking back it's a wonder why it stuck around as long as it did. 

#sitcom #laughtrack #nerdstalgic 

SOURCES
https://nymag.com/arts/tv/features/laughtracks-2011-12/
https://www.videomaker.com/how-to/directing/film-history/the-history-of-the-laugh-track/
https://collider.com/tv-laugh-tracks-do-we-really-need-them/
https://www.britannica.com/story/why-do-television-shows-use-laugh-tracks
https://www.cell.com/current-biology/fulltext/S0960-9822(19)30687-6?_returnURL=https%3A%2F%2Flinkinghub.elsevier.com%2Fretrieve%2Fpii%2FS0960982219306876%3Fshowall%3Dtrue#%20
https://www.semantic

