# Source:Mateusz Chrobok, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw, language:pl-PL

## 📦 Tajemniczy prompt!
 - [https://www.youtube.com/watch?v=g9DfFBntid4](https://www.youtube.com/watch?v=g9DfFBntid4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCTTZqMWBvLsUYqYwKTdjvkw
 - date published: 2023-10-06T04:30:25+00:00

To fragment dłuższego podkastu, który wspólnie popełniliśmy.
Zachęcam do jego obejrzenia!

👨‍🏫 Odnośnik do szkolenia AI_Devs (afiliacyjny)
https://aidevs.pl/?ref=mc

Moimi gośćmi byli:
Adam “overment” Gospodarczyk https://www.youtube.com/@overment
Jakub “unknow” Mrugalski https://www.youtube.com/@uwteamorg

