# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## Man Utd 2-2 Arsenal: Cloe Lacasse goal in stoppage time salvages draw for visitors
 - [https://www.bbc.co.uk/sport/football/66956508?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66956508?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:44:38+00:00

Substitute Cloe Lacasse scores to salvage a dramatic draw for Arsenal at Manchester United in the Women's Super League.

## 180kg Fred caught after going wild in the city
 - [https://www.bbc.co.uk/news/world-us-canada-67036162?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67036162?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:40:40+00:00

Colorado officials say he is "always hungry" and "loves his belly scratches".

## France 60-7 Italy: Hosts earn crushing win to reach World Cup quarter-finals
 - [https://www.bbc.co.uk/sport/rugby-union/67032236?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67032236?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:39:31+00:00

Hosts France cruise to top spot in Pool A at the Rugby World Cup as they beat Italy, and will face one of South Africa, Ireland or Scotland in the quarter-finals.

## Inquiry ordered over England schools funding blunder
 - [https://www.bbc.co.uk/news/education-67033455?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/education-67033455?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:37:11+00:00

Schools in England will receive £370m less than promised in July after an accounting error is uncovered.

## VAR: Tottenham boss Ange Postecoglou would ditch system 'in current form'
 - [https://www.bbc.co.uk/sport/football/67035093?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67035093?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:36:48+00:00

Tottenham boss Ange Postecoglou says he would dispose of the video assistant referee system "in its current form".

## Super League: Catalans Dragons 12-6 St Helens - Sam Tomkins the hero as reigning champions downed
 - [https://www.bbc.co.uk/sport/rugby-league/66992811?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-league/66992811?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:27:16+00:00

Sam Tomkins delivers the clutch try to take Catalans Dragons back to Old Trafford and end St Helens' hold on the Super League title.

## Talks after US fighter jet shoots down armed Turkish drone in Syria
 - [https://www.bbc.co.uk/news/world-middle-east-67034560?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67034560?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T21:20:33+00:00

Ankara vows to continue targeting Kurdish groups but the US calls for more coordination between the Nato allies.

## Simone Biles wins all-around gold for 21st world title
 - [https://www.bbc.co.uk/sport/gymnastics/67035852?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/gymnastics/67035852?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T20:38:02+00:00

American Simone Biles continues her impressive return after a two-year break by winning women's all-around gold at the World Gymnastics Championships in Belgium.

## Simone Biles: Sixth World Gymnastics Championships all-around gold for US star
 - [https://www.bbc.co.uk/sport/av/gymnastics/67035966?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/gymnastics/67035966?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T20:30:29+00:00

USA's Simone Biles wins her sixth world all-around gold at the World Gymnastics Championships in Antwerp, Belgium.

## Surrey MP Chris Grayling to step down after cancer diagnosis
 - [https://www.bbc.co.uk/news/uk-england-surrey-67034851?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-surrey-67034851?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T19:24:42+00:00

The Epsom and Ewell MP and former Transport Secretary says he will step down at the next election.

## Max Verstappen on pole position for Sunday's Qatar Grand Prix as title looms
 - [https://www.bbc.co.uk/sport/formula1/67033216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67033216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T18:09:34+00:00

Max Verstappen storms to pole position at the Qatar Grand Prix and needed only one run in the final qualifying session to do it.

## Scotland v Ireland: Scots knocking out formidable Irish would be a revelation
 - [https://www.bbc.co.uk/sport/rugby-union/67032053?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67032053?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T18:07:17+00:00

BBC Scotland's chief sports writer Tom English previews the task facing Scotland against Ireland in the Rugby World Cup.

## Rapper Drake taking break from music to focus on health
 - [https://www.bbc.co.uk/news/world-us-canada-67035523?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67035523?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T18:02:42+00:00

"I need to focus on my health first," the rapper said, adding that he suffers from stomach issues.

## Dale Vince: Major Labour donor to stop funding Just Stop Oil
 - [https://www.bbc.co.uk/news/uk-politics-67031062?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67031062?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T17:23:49+00:00

Businessman Dale Vince says the group's tactics have become "counterproductive" for the green cause.

## Ireland v Scotland: Irish nowhere near invincible at World Cup and won't be complacent, says James Lowe
 - [https://www.bbc.co.uk/sport/rugby-union/67029085?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67029085?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T17:18:13+00:00

Ireland are nowhere near being invincible and won't let complacency creep into their game against Scotland, insists James Lowe.

## Scarborough road resurfaced around parked car
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-67034731?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-67034731?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T17:17:38+00:00

North Yorkshire Council say they will return to complete the work at a later date.

## Brighton murder inquiry: Police name Mustafa Momand as stabbed teen
 - [https://www.bbc.co.uk/news/uk-england-sussex-67033469?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-sussex-67033469?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T17:12:18+00:00

Mustafa Momand, 17, was stabbed to death in Brighton on Thursday, prompting a murder inquiry.

## Taxpayers to pay £40bn due to threshold freeze, think tank says
 - [https://www.bbc.co.uk/news/business-67031930?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67031930?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T16:57:18+00:00

New analysis suggests the Treasury will now net £40bn in income tax due to inflation.

## Ed Sheeran scores seventh straight number one album with Autumn Variations
 - [https://www.bbc.co.uk/news/entertainment-arts-67032473?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67032473?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T16:54:54+00:00

Autumn Variations divided the critics but fans are all still firmly behind the singer-songwriter.

## Cricket World Cup 2023: Pakistan recover to avoid shock defeat by Netherlands
 - [https://www.bbc.co.uk/sport/cricket/67030729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/67030729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T16:17:23+00:00

Bas de Leede's impressive all-round efforts are in vain as Pakistan beat Netherlands by 81 runs in the World Cup.

## Labour 'blew the doors off' in by-election win - Starmer
 - [https://www.bbc.co.uk/news/uk-scotland-scotland-politics-67029360?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-scotland-politics-67029360?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T16:11:54+00:00

Michael Shanks won the Rutherglen and Hamilton West by-election with double the votes of the SNP.

## Rutherglen and Hamilton West: Should SNP's Humza Yousaf be worried?
 - [https://www.bbc.co.uk/news/uk-scotland-67026372?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67026372?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T15:54:24+00:00

The new party leader faced his first electoral test and things did not go well, writes the BBC's Philip Sim.

## WSL: It is time to grow league to 18 teams, says Emma Hayes
 - [https://www.bbc.co.uk/sport/football/67029898?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67029898?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T15:09:13+00:00

Chelsea manager Emma Hayes wants the Women's Super League to be increased from 12 to 18 teams.

## Bukayo Saka injury update: Arsenal forward 'in contention' to face Manchester City
 - [https://www.bbc.co.uk/sport/football/67032727?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67032727?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T15:05:44+00:00

Arsenal boss Mikel Arteta says Bukayo Saka could be in contention to face Premier League champions Manchester City on Sunday.

## HS2: What has been built so far?
 - [https://www.bbc.co.uk/news/uk-67029579?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67029579?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:43:25+00:00

A visual guide to the progress made on one of the most expensive rail projects in the world.

## Max Verstappen tops Qatar Grand Prix practice before qualifying
 - [https://www.bbc.co.uk/sport/formula1/67033211?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/formula1/67033211?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:42:45+00:00

Max Verstappen makes a good start to the weekend on which he will likely clinch his third world title by setting the pace in first practice in Qatar.

## Sir Alex Ferguson's wife Lady Cathy dies aged 84
 - [https://www.bbc.co.uk/sport/football/67032729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67032729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:37:26+00:00

Lady Cathy Ferguson, the wife of former Manchester United manager Sir Alex Ferguson, dies aged 84.

## American tourist arrested for smashing Israel Museum statues
 - [https://www.bbc.co.uk/news/world-middle-east-67027881?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67027881?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:34:03+00:00

Images shared by Israeli police show the two ancient Roman sculptures lying broken on the floor.

## Watch: Moment Tupac's murder suspect gets arrested
 - [https://www.bbc.co.uk/news/world-us-canada-67032696?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67032696?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:27:59+00:00

The 60-year-old former gang leader was indicted on one count of murder with a deadly weapon.

## Error to open pubs not schools, Covid inquiry told
 - [https://www.bbc.co.uk/news/articles/cw5w76p62eqo?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/cw5w76p62eqo?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:09:31+00:00

The ex-children's commissioner in England says most senior officials did not put children first.

## 'I no longer feel safe': Rape adviser quits role and UK
 - [https://www.bbc.co.uk/news/uk-67022205?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67022205?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:03:39+00:00

Emily Hunt says her own experiences of abuse and the UK courts have pushed her to leave for the US.

## Ukraine war: Blood stains visible in the soil as village of Hroza mourns
 - [https://www.bbc.co.uk/news/world-europe-67031817?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67031817?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T14:03:33+00:00

Interior Minister Ihor Klymenko says every family in Hroza has been affected by Thursday's missile strike.

## Paul Pogba: Juventus midfielder's B sample confirms positive drugs test
 - [https://www.bbc.co.uk/sport/football/67031763?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67031763?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T13:59:25+00:00

Juventus midfielder Paul Pogba's failed drugs test is confirmed after his B sample also tests positive.

## Ireland v Scotland: 'Ireland must learn from past mistakes in Paris showdown'
 - [https://www.bbc.co.uk/sport/rugby-union/67019584?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/67019584?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T12:44:05+00:00

Ireland cannot afford to underestimate Scotland in pursuit of their ultimate dream of World Cup glory, writes Tommy Bowe.

## Cricket World Cup 2023: Pakistan's Mohammad Nawaz run out on 39 after a comedy of errors
 - [https://www.bbc.co.uk/sport/av/cricket/67027683?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/cricket/67027683?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T12:15:26+00:00

A mix-up between Pakistan batters Mohammad Nawaz and Shaheen Afridi results in a run out against Netherlands in the Cricket World Cup clash at Hyderabad.

## Four Green MPs absolutely realistic - co-leader
 - [https://www.bbc.co.uk/news/uk-politics-67027074?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67027074?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T12:00:35+00:00

The Green co-leader says she is confident of adding more MPs after "record-breaking" local elections.

## What's going on at Metro Bank?
 - [https://www.bbc.co.uk/news/business-67027436?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67027436?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:46:39+00:00

Bosses say there are no concerns about its finances after reports it was looking to raise millions.

## Iran's activist Narges Mohammadi wins Nobel Peace Prize
 - [https://www.bbc.co.uk/news/world-middle-east-67026216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-middle-east-67026216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:43:46+00:00

The imprisoned campaigner is honoured for her fight against the oppression of women in Iran.

## NFL: DJ Moore scores three times for Chicago Bears in win over Washington Commanders
 - [https://www.bbc.co.uk/sport/av/american-football/67030793?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/american-football/67030793?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:35:29+00:00

Wide receiver DJ Moore records 230 yards and scores three touchdowns in the Chicago Bears' 40-20 win over the Washington Commanders.

## France bedbug panic: Officials respond as Paris school infested
 - [https://www.bbc.co.uk/news/world-europe-67027138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67027138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:05:12+00:00

Government officials meet as teachers refuse to work following the latest reported infestation.

## Jason Derulo sued for sexual harassment by fellow singer
 - [https://www.bbc.co.uk/news/entertainment-arts-67026450?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67026450?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:03:12+00:00

Singer Emaza Gibson claims the star signed her to his label then demanded sex, which he denies.

## Watch: Video shows moment driver loses control on motorway
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67026743?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67026743?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T11:01:51+00:00

Police cameras capture the moment a driver loses control of his car on the M25 at night.

## UK weather: Last dose of summer expected for much of UK
 - [https://www.bbc.co.uk/news/uk-67028073?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-67028073?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T10:44:08+00:00

Parts of the UK could see temperatures up to 26C at the weekend, but rain is predicted in Scotland.

## Australian man rowing across Pacific Ocean rescued after capsizing
 - [https://www.bbc.co.uk/news/world-australia-67027878?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-67027878?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T10:38:13+00:00

Tom Robinson, 24, had been hoping to become the youngest person to row across the ocean.

## Saudi Pro League: Zlatan Ibrahimovic questions players' moves to 'lower stage'
 - [https://www.bbc.co.uk/sport/football/67027689?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67027689?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T10:32:49+00:00

Zlatan Ibrahimovic says footballers who move to Saudi Arabia risk being remembered for what they earned rather than their talent.

## How is the ADHD medication shortage in the UK affecting people?
 - [https://www.bbc.co.uk/news/newsbeat-67010493?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-67010493?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T10:05:02+00:00

People with the condition say they face uncertain times as their supplies run out or run low.

## House price falls expected into new year, Halifax says
 - [https://www.bbc.co.uk/news/business-67028467?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67028467?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T10:01:17+00:00

The UK's biggest mortgage lender says prices are still falling, but the rate of reduction has slowed.

## China Open: Coco Gauff sets up Iga Swiatek semi-final by beating Caroline Garcia
 - [https://www.bbc.co.uk/sport/tennis/67026231?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/tennis/67026231?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T09:26:42+00:00

Coco Gauff extends her winning streak to 16 matches as the American sets up a semi-final against Iga Swiatek at the China Open.

## Plaid Cymru: Independence not pie in the sky, says Rhun ap Iorwerth
 - [https://www.bbc.co.uk/news/uk-wales-politics-67012483?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-politics-67012483?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T09:19:04+00:00

Ahead of party's conference, Rhun ap Iorwerth says it has to "bring people with us" on the issue.

## Holly Willoughby: Man charged over alleged kidnap plot
 - [https://www.bbc.co.uk/news/entertainment-arts-67027015?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-67027015?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T09:16:56+00:00

A 36-year-old has been charged with soliciting to murder and incitement to kidnap.

## 'Long colds' are a thing, like Long Covid say experts
 - [https://www.bbc.co.uk/news/health-67016985?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-67016985?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T08:06:20+00:00

Common 'long cold' symptoms people reported include a cough, stomach pain, and diarrhoea.

## Chris Mason: Thunderbolt win changes political weather
 - [https://www.bbc.co.uk/news/uk-politics-67027065?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-67027065?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T07:50:58+00:00

Labour's victory in Rutherglen and Hamilton West allows them to dream of a Scottish revival.

## Permanent home for Paralympic flame revealed
 - [https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67020029?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-beds-bucks-herts-67020029?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T06:28:49+00:00

The flame will be lit there from the Paris 2024 Paralympic Games onwards.

## Arsenal v Man City: Are Gunners in better position to beat City and win Premier League title?
 - [https://www.bbc.co.uk/sport/football/67005715?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/67005715?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:42:54+00:00

As Arsenal prepare to host Manchester City on Sunday, we assess whether they are in a better position to win the Premier League title this season.

## Sikkim flood: Rescue efforts continue as death toll rises
 - [https://www.bbc.co.uk/news/world-asia-india-67017845?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-india-67017845?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:22:32+00:00

The flash flood in Sikkim state has caused massive damage and left thousands stranded.

## Off-course turtle named after Scottish island taken 1,700 miles home
 - [https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-67021532?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-york-north-yorkshire-67021532?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:15:39+00:00

A lost turtle found in Scotland and rehabilitated in Yorkshire is released back into the wild.

## Watch: Formation of Chinese ships blocks Philippine boats
 - [https://www.bbc.co.uk/news/world-asia-67025727?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67025727?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:08:35+00:00

The BBC saw first-hand how Chinese ships were manoeuvring in the South China Sea to block Philippine vessels.

## Manchester Corinthians: Pioneering women's football club honoured
 - [https://www.bbc.co.uk/news/uk-england-manchester-67017610?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-manchester-67017610?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:05:21+00:00

Manchester Corinthians helped pave the way for the Lionesses by defying an FA ban on women's football.

## MLB Saturday Showdown: Can cricketer Stuart Broad play baseball?
 - [https://www.bbc.co.uk/sport/av/baseball/67011568?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/baseball/67011568?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:04:49+00:00

Watch ex-England cricketer Stuart Broad try his hand at baseball, with the help of MLB great Chase Utley, before the MLB Saturday Showdown live on the BBC.

## BBC witnesses Chinese ships blocking Philippines supply boats
 - [https://www.bbc.co.uk/news/world-asia-67015857?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67015857?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:01:10+00:00

It resulted in a standoff that lasted several hours before the Philippine ships turned back.

## I was innocent - but it cost me £500,000 to prove it
 - [https://www.bbc.co.uk/news/uk-66928735?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66928735?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T05:01:06+00:00

People found not guilty of crimes say winning their freedom has left them financially devastated.

## Labour's Scottish by-election win explained in 120 seconds
 - [https://www.bbc.co.uk/news/uk-scotland-67026044?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67026044?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T04:45:22+00:00

The BBC’s Kirsten Campbell explains the significance of the result in Rutherglen and Hamilton West.

## Philippines 'Jesus' drag queen arrested for obscenity
 - [https://www.bbc.co.uk/news/world-asia-67025750?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-asia-67025750?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T04:15:18+00:00

Pura Luka Vega, 33, faces up to 12 years in jail under the Catholic-majority country's laws.

## Taylor Swift tour film tops $100m in advance ticket sales
 - [https://www.bbc.co.uk/news/business-67025651?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-67025651?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T04:05:08+00:00

The film of the Eras tour is due to be released in cinemas in more than 100 countries next Friday.

## What does Rutherglen and Hamilton West by-election victory mean for Labour?
 - [https://www.bbc.co.uk/news/uk-scotland-67024349?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-67024349?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T03:58:20+00:00

The victory over the SNP in Rutherglen and Hamilton West exceeded the party's wildest expectations.

## Ukraine war: ‘Every family’ in Hroza village affected by missile attack
 - [https://www.bbc.co.uk/news/world-europe-67025706?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-67025706?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T03:56:33+00:00

At least 51 people were killed in a strike during a wake in the eastern village of Hroza on Thursday.

## Trump seeks to dismiss election interference charges
 - [https://www.bbc.co.uk/news/world-us-canada-67024517?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67024517?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T01:49:30+00:00

His lawyers say his statements about election fraud fell within the "outer perimeter" of his duties.

## Watch: Sparks sent flying in precarious landing without landing gears
 - [https://www.bbc.co.uk/news/world-us-canada-67025726?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-67025726?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T01:40:17+00:00

Emergency crews were ready as the plane skidded along the tarmac at Chattanooga Metropolitan Airport.

## The papers: 'Red October' and Kate 'the princess of wheels'
 - [https://www.bbc.co.uk/news/blogs-the-papers-67024771?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/blogs-the-papers-67024771?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-10-06T01:17:08+00:00

Friday's papers feature a mix of reports, including concerns over "record" temperatures.

