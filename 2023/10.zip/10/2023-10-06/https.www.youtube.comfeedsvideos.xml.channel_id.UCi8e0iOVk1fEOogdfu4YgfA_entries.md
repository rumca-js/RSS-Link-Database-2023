# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Asking Strangers If They're Excited for The Exorcist: Believer
 - [https://www.youtube.com/watch?v=pW0tlpRn6wE](https://www.youtube.com/watch?v=pW0tlpRn6wE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-10-06T21:00:26+00:00

On this episode of "On the Street," we experience Halloween Horror Nights and ask folks, if they are excited to see 'The Exorcist: Believer'?

► Buy Tickets for The Exorcist: Believer: https://www.fandango.com/the-exorcist-believer-2023-231976/movie-overview?cmp=Trailers_YouTube_Desc 
► Learn more: https://www.rottentomatoes.com/m/the_exorcist_believer?cmp=Trailers_YouTube_Desc

## Asking Strangers What's The Scariest Movie Of All Time
 - [https://www.youtube.com/watch?v=2OGLrqYW90M](https://www.youtube.com/watch?v=2OGLrqYW90M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-10-06T20:00:01+00:00

On this episode of "On the Street," we experience Halloween Horror Nights and ask folks, what's the scariest movie of all time?

► Buy Tickets for The Exorcist: Believer: https://www.fandango.com/the-exorcist-believer-2023-231976/movie-overview?cmp=Trailers_YouTube_Desc 
► Learn more: https://www.rottentomatoes.com/m/the_exorcist_believer?cmp=Trailers_YouTube_Desc 
 
Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy  

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M
 
Music: 
Courtesy of Extreme Music 
 
Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and first looks for all the best upcoming movies. Be the first to see everything coming to theaters and your favorite streaming platforms - all in

## The Concierge Trailer #1 (2024)
 - [https://www.youtube.com/watch?v=vWwg87LkIyA](https://www.youtube.com/watch?v=vWwg87LkIyA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-10-06T17:17:04+00:00

Check out the official trailer for The Concierge starring Natsumi Kawaida! 
► Visit Fandango: https://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: 2024
Starring: Natsumi Kawaida, Nobuo Tobita, Takeo Ōtsuka
Director: Yoshimi Itazu
Synopsis: The film, an adaptation of Tsuchika Nishimura’s The Concierge at Hokkyoku Department Store, follows Akino, a trainee concierge, who works at a very special store – the customers are all animals and the most valued among them are extinct species.
► Learn more: https://www.rottentomatoes.com/m/the_concierge?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers 

