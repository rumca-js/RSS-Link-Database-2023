# Source:Kotaku, URL:https://kotaku.com/rss, language:en

## This Last of Us Clicker Bread Sculpture Is Scary As Hell
 - [https://kotaku.com/last-of-us-clicker-bread-sculpture-joel-ellie-1850908509](https://kotaku.com/last-of-us-clicker-bread-sculpture-joel-ellie-1850908509)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T21:50:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/1342584992fbb64ec6ec6b9b9a8232c1.jpg" /><p>A bakery in San Francisco constructed a sculpture of a Last of Us Clicker, one of the series’ menacing, mushroom-infested zombies, out of bread. And it looks pretty darn scary.</p><p><a href="https://kotaku.com/last-of-us-clicker-bread-sculpture-joel-ellie-1850908509">Read more...</a></p>

## Around 100 Devs At Just Cause Studio Are Unionizing
 - [https://kotaku.com/avalanche-studios-group-just-cause-contraband-union-1850908204](https://kotaku.com/avalanche-studios-group-just-cause-contraband-union-1850908204)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T20:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/7bfff71f25a1db278914b6e5c33a7ed8.jpg" /><p>Around 100 employees at Just Cause developer Avalanche Studios Group are unionizing. This means around a fifth of the 500-person Swedish team is now bargaining with the company’s management for a fair contract.<br /></p><p><a href="https://kotaku.com/avalanche-studios-group-just-cause-contraband-union-1850908204">Read more...</a></p>

## Detective Pikachu Returns Has A Fun Joke About The 2019 Movie
 - [https://kotaku.com/pokemon-detective-pikachu-returns-live-action-movie-1850907630](https://kotaku.com/pokemon-detective-pikachu-returns-live-action-movie-1850907630)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T19:29:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/269b97e390f9606d0bfca02a9e7a7ec0.jpg" /><p>Detective Pikachu Returns is out on Switch today, October 6, and as someone who considers the original 2016 3DS game to be one of my <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/detective-pikachu-returns-pokemon-3ds-game-switch-1850601737">favorite things Pokémon has ever done</a>, I’m stoked. But Nintendo’s adventure game sequel exists in a weird place, because the 2019 live-action Detective Pikachu movie may have already…</p><p><a href="https://kotaku.com/pokemon-detective-pikachu-returns-live-action-movie-1850907630">Read more...</a></p>

## Big Oil's Using Fortnite, TikTok, And Twitch In Effort To Convince Kids Fossil Fuels Are Cool
 - [https://kotaku.com/shell-big-oil-roadtrips-fortnite-map-collab-tiktok-ign-1850907435](https://kotaku.com/shell-big-oil-roadtrips-fortnite-map-collab-tiktok-ign-1850907435)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T18:37:09+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/b4c0c5a0561e4fbecc7bca4c233ea3e4.jpg" /><p>Kids today only care about online free-to-play shooter Fortnite. They don’t even talk about how great gasoline is! Luckily for us, one large oil company wants to change that using <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/fortnite-2022-quests-zero-build-fun-indiana-jones-1849327938">Fortnite</a>, TikTok stars, and Twitch streamers. Welcome to Hell. </p><p><a href="https://kotaku.com/shell-big-oil-roadtrips-fortnite-map-collab-tiktok-ign-1850907435">Read more...</a></p>

## Redfall Finally Gets 60fps Mode On Console In Its Biggest Update Yet
 - [https://kotaku.com/redfall-xbox-game-pass-60fps-patch-notes-bethesda-1850907241](https://kotaku.com/redfall-xbox-game-pass-60fps-patch-notes-bethesda-1850907241)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T17:40:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/1f31239f96911bb226d0cc1d98a1c203.jpg" /><p>After months of silence, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/xbox-redfall-game-pass-exclusive-shooter-bethesda-1850616260">vampire shooter Redfall</a> is receiving its biggest update yet following a disastrous launch back in May. The second big patch will add the Game Pass multiplayer game’s long-awaited 60 frames-per-second mode on Xbox Series X/S, as well as a host of gameplay improvements and bug fixes. </p><p><a href="https://kotaku.com/redfall-xbox-game-pass-60fps-patch-notes-bethesda-1850907241">Read more...</a></p>

## Castlevania: Nocturne Renewed For Second Season
 - [https://kotaku.com/castlevania-nocturne-second-season-richter-alucard-1850907256](https://kotaku.com/castlevania-nocturne-second-season-richter-alucard-1850907256)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T17:35:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/51b85c88e246d6408611b1d1e1389d17.jpg" /><p>Castlevania: Nocturne, the sequel to Netflix’s surprise-hit Castlevania anime, premiered on the streamer last week to rave reviews from critics and fans alike. So it’s probably not startling to hear that the vampire-killing series has been renewed for a second season, but that won’t stop me from pumping my fist in the…</p><p><a href="https://kotaku.com/castlevania-nocturne-second-season-richter-alucard-1850907256">Read more...</a></p>

## Just-Discovered Baldur’s Gate 3 Feature Reminds Gamers They Should Shower
 - [https://kotaku.com/reddit-baldurs-gate-3-hotfix-9-bg3-blood-magic-mirror-1850906850](https://kotaku.com/reddit-baldurs-gate-3-hotfix-9-bg3-blood-magic-mirror-1850906850)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T16:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/e8523b0177e4cee81fe5a784246e22f4.jpg" /><p>Dungeons & Dragons role-playing game Baldur’s Gate 3 is a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/baldurs-gate-3-romance-sex-scene-bear-shadowheart-gale-1850771533">horny</a> elven fantasy until you end up in a fight. Then, you and your companions get blood spatter all over your faces—very real and sobering—and it’s hard to woo each other at a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://baldursgate3.wiki.fextralife.com/Camp" rel="noopener noreferrer" target="_blank">safe campsite</a> while you’re staring at gore. Some players try to freshen up their…</p><p><a href="https://kotaku.com/reddit-baldurs-gate-3-hotfix-9-bg3-blood-magic-mirror-1850906850">Read more...</a></p>

## Major Patch Nerfs Armored Core VI’s Most OP Guns
 - [https://kotaku.com/armored-core-6-fromsoftware-patch-notes-zimmerman-1850906860](https://kotaku.com/armored-core-6-fromsoftware-patch-notes-zimmerman-1850906860)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T16:10:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/e4f4e387346c69eda1b0d7e571819f5e.jpg" /><p>It was only a matter of time, I suppose. <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/armored-core-6-balteus-elden-ring-ps5-steam-reviews-1850781108">Everyone’s favorite broken Armored Core VI build</a> is no more. FromSoftware released a new update for the mech shooter that makes its beloved Zimmerman shotguns less godlike. 621’s days of skating around Rubicon smashing and staggering everything in sight with ease are over.</p><p><a href="https://kotaku.com/armored-core-6-fromsoftware-patch-notes-zimmerman-1850906860">Read more...</a></p>

## Is Detective Pikachu A Cop? Kotaku Investigates
 - [https://kotaku.com/pokemon-detective-pikachu-returns-switch-acab-is-a-cop-1850906651](https://kotaku.com/pokemon-detective-pikachu-returns-switch-acab-is-a-cop-1850906651)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T15:20:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/e880e929ca840f0438250fa9c76f5450.jpg" /><p>Detective Pikachu Returns is out October 6 on Nintendo Switch, and it brings a new mystery for the titular Pokémon investigator to solve. But it also dredges up an old mystery that has plagued the character since his debut in 2016: is Detective Pikachu a cop? Well, the only way to solve a mystery is to look at the…</p><p><a href="https://kotaku.com/pokemon-detective-pikachu-returns-switch-acab-is-a-cop-1850906651">Read more...</a></p>

## Police Seize 1,000 Cards In Pokémon Counterfeiting Bust
 - [https://kotaku.com/pokemon-trading-cards-pikachu-charizard-counterfeit-1850906447](https://kotaku.com/pokemon-trading-cards-pikachu-charizard-counterfeit-1850906447)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T14:40:55+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/6554d6e88bdda7f318cb362fcb19bc8a.jpg" /><p>The crackdown on counterfeit Pikachus and Charizards continues. Earlier this week, an investigation by police in Annaka City, Japan led them to a haul of 1,000 cards believed to be fake, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://kotaku.com/pokemon-tcg-cards-value-crown-zenith-paldea-evolved-1850552711">including Pokémon trading card game products</a>. The 21-year-old suspect they allegedly belonged to had been caught selling a few of…</p><p><a href="https://kotaku.com/pokemon-trading-cards-pikachu-charizard-counterfeit-1850906447">Read more...</a></p>

## Kotaku’s Weekend Guide: 8 Intriguing Games To Greet October With
 - [https://kotaku.com/games-to-play-assassins-creed-alan-wake-cyberpunk-1850904737](https://kotaku.com/games-to-play-assassins-creed-alan-wake-cyberpunk-1850904737)
 - RSS feed: https://kotaku.com/rss
 - date published: 2023-10-06T13:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/e5f80b2d2156a078c81e75755ea9755c.jpg" /><p>Happy October. We’re in spooky month territory at long last, even if it has felt a little warm for Fall. Many of us are also looking forward to a three-day weekend here in the States, so that means a nice long chunk of time to get some gaming in—and you can pair it with a pumpkin spice latte! </p><p><a href="https://kotaku.com/games-to-play-assassins-creed-alan-wake-cyberpunk-1850904737">Read more...</a></p>

