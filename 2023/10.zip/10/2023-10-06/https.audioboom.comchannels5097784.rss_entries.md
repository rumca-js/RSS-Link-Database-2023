# Source:Lateral with Tom Scott, URL:https://audioboom.com/channels/5097784.rss, language:en-US

## 52: Square-eyed dogs
 - [https://audioboom.com/posts/8376295](https://audioboom.com/posts/8376295)
 - RSS feed: https://audioboom.com/channels/5097784.rss
 - date published: 2023-10-06T14:15:00+00:00

<div>Michelle Khare, Kip Heath and Joe Hanson face questions about far-flung flights, rapping records and odd opposites.<br />
LATERAL is a weekly podcast about interesting questions and even more interesting answers, hosted by Tom Scott. For business enquiries, contestant appearances or question submissions, visit <a href="https://www.lateralcast.com">https://www.lateralcast.com</a>.<br />
HOST: Tom Scott. QUESTION PRODUCER: David Bodycombe. RECORDED AT: The Podcast Studios, Dublin. EDITED BY: Julie Hassett. MUSIC: Karl-Ola Kjellholm ('Private Detective'/'Agrumes', courtesy of <a href="http://epidemicsound.com">epidemicsound.com</a>). ADDITIONAL QUESTIONS: Brian. FORMAT: Pad 26 Limited/Labyrinth Games Ltd. EXECUTIVE PRODUCERS: David Bodycombe and Tom Scott. © Pad 26 Limited (<a href="https://www.pad26.com">https://www.pad26.com</a>) / Labyrinth Games Ltd. 2023.</div>

