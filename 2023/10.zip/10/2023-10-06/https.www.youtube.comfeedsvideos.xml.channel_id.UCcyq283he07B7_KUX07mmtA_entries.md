# Source:InsiderBusiness, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA, language:en-US

## Fish maw trade is not only harmful to #marinelife but also impacts #ecosystems worldwide. #FishMaw
 - [https://www.youtube.com/watch?v=5pbrrx6pcMI](https://www.youtube.com/watch?v=5pbrrx6pcMI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-06T20:17:13+00:00



## Driving Company Growth Through Creating a Culture of Ownership
 - [https://www.youtube.com/watch?v=xJRFvhGljWo](https://www.youtube.com/watch?v=xJRFvhGljWo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-06T20:16:58+00:00

Sponsored by Morgan Stanely at Work

As companies stay private longer, businesses must navigate a changing landscape when it comes to driving growth and managing liquidity expectations for shareholders, investors and employees. At the same time, embracing a culture of ownership can be essential for talent recruitment and longevity while driving performance.

In this panel discussion, hear from thought leaders at Morgan Stanley at Work, Acorns and Norwest Venture Partners, as they explore:

Current practices for attracting and retaining talent and how companies can create a compelling employee equity experience that supports a culture of ownership
What retention equity is and how companies can adjust their compensation plans to account for staying private longer
Expansion into global markets and how companies can provide a holistic participant experience to international employees
Trends in the market when it comes to liquidity events, secondaries, and availability of capital, and how

## Workers clip and shear these carpets to a specific height by hand. #carpet #cleaning #weaving
 - [https://www.youtube.com/watch?v=6qHrOJlC2iI](https://www.youtube.com/watch?v=6qHrOJlC2iI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-06T19:00:03+00:00

------------------------------------------------------

Business Insider tells you all you need to know about business, finance, tech, retail, and more.

Visit our homepage for the top stories of the day: https://www.businessinsider.com
Insider Business on Facebook: https://www.facebook.com/businessinsider
Insider Business on Instagram: https://www.instagram.com/insiderbusiness
Insider Business on Twitter: https://www.twitter.com/businessinsider
Insider Business on Snapchat: https://www.snapchat.com/discover/Business_Insider/5319643143
Insider Business on TikTok: https://www.tiktok.com/@businessinsider

## 14 Fascinating Jobs In India That Go Back Centuries | Still Standing Marathon | Insider Business
 - [https://www.youtube.com/watch?v=O030fzDUAOw](https://www.youtube.com/watch?v=O030fzDUAOw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCcyq283he07B7_KUX07mmtA
 - date published: 2023-10-06T15:00:29+00:00

India is home to some of the world’s oldest and rarest crafts and traditions. From a family stomping cashew fruit to a small community transforming pumpkins into musical instruments, we’ll take you on a tour of 14 ancient traditions still standing in India. 

00:00:00 Mud Wrestling
00:10:05 Perfume
00:17:38 Feni
00:26:45 Pumpkin Tanpuras
00:39:41 Mirrors
00:50:35 Shuttlecocks
00:57:54 Bidri Art
01:04:40 Silk Saris
01:12:18 Bone Carving
01:21:51 Dhokra
01:32:30 Paper
01:38:00 Floating Market
01:47:42 Rogan Art
01:54:32 Carpets

MORE STILL STANDING VIDEOS:
How Lebanon’s Oldest Soap Factory Makes 30,000 Olive Oil Bars | Still Standing | Insider Business
https://youtu.be/2YVb4s1DGzw
Why The Moulin Rouge Spent $4 Million In Costumes | Still Standing | Insider Business
https://www.youtube.com/watch?v=Qpf90cB7Kh4
Five Fascinating Ancient Japanese Traditions Survived Centuries | Still Standing | Insider Business
https://www.youtube.com/watch?v=iQ5kbdGR93Q

#Marathon #India #StillStanding
---

