# Source:Jordan Peterson, URL:https://www.jordanbpeterson.com/feed/, language:en-US

## The Laptop From Hell | Miranda Devine | EP 386
 - [https://www.jordanbpeterson.com/podcast/the-laptop-from-hell-miranda-devine-ep-386/](https://www.jordanbpeterson.com/podcast/the-laptop-from-hell-miranda-devine-ep-386/)
 - RSS feed: https://www.jordanbpeterson.com/feed/
 - date published: 2023-10-06T01:34:49+00:00

<p>Dr. Jordan B Peterson and writer Miranda Devine discuss her 2021 book “Laptop from Hell: Hunter Biden, Big Tech, and the Dirty Secrets the President Tried to Hide.” They delve into Hunter Biden’s depravity, the corruption of his family's business dealings, how they built and maintain their regime, the insane and far-reaching coverup from the deep state to the mainstream media, and the unfortunate aftermath for not just those directly involved, not just American citizens, but innocent people all across the world who find themselves in the midst of political and physical warfare.</p>
<p>Miranda Devine is an Australian radio host, columnist, and writer who now lives in New York. She has written for the The Sydney Morning Herald, the Sun-Herald, the Daily Telegraph, Sunday Telegraph, the Sunday Herald Sun, the Sunday Times, and the New York Times. Her 2021 publication, “Laptop from Hell: Hunter Biden, Big Tech, and the Dirty Secrets the President Tried to Hide,” details who Hunter Bid

