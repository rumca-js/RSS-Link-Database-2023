# Source:Jeremy Jahns, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q, language:en-US

## Totally Killer - Movie Review
 - [https://www.youtube.com/watch?v=NICcizonqeo](https://www.youtube.com/watch?v=NICcizonqeo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC7v3-2K1N84V67IF-WTRG-Q
 - date published: 2023-10-06T13:00:14+00:00

The world of streaming services is full of new releases that fly under the radar. But for your Halloween movie party, I might have found something...
Here's my review of TOTALLY KILLER!

#TotallyKiller

