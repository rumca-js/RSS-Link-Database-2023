# Source:Money PL, URL:https://www.money.pl/rss/rss.xml, language:pl-PL

## Podróż Kazachstanu w kierunku dywersyfikacji i zwiększonej konkurencyjności
 - [https://www.money.pl/gospodarka/podroz-kazachstanu-w-kierunku-dywersyfikacji-i-zwiekszonej-konkurencyjnosci-6949236469791328a.html](https://www.money.pl/gospodarka/podroz-kazachstanu-w-kierunku-dywersyfikacji-i-zwiekszonej-konkurencyjnosci-6949236469791328a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T14:10:40+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e283359e-f30c-4b51-827c-e68b8de8b3b5" width="308" /> W swoim niedawnym orędziu o stanie państwa, wygłoszonym 1 września, prezydent Kazachstanu Kassym-Jomart Tokajew wyznaczył cel - osiągnięcie 6-7% wzrostu gospodarczego i zwiększenie wolumenu gospodarczego do 450 miliardów dolarów do 2029 roku. Jakich zmian potrzebuje kraj, aby zrealizować ten ambitny plan? – zastanawia się Ruslan Sultanov, przewodniczący zarządu Instytutu Badań Ekonomicznych w Kazachstanie.

## Walka z inflacją. "Prezes NBP nie powinien przypisywać sobie zasług"
 - [https://www.money.pl/gospodarka/walka-z-inflacja-prezes-nbp-nie-powinien-przypisywac-sobie-zaslug-6949247098541697v.html](https://www.money.pl/gospodarka/walka-z-inflacja-prezes-nbp-nie-powinien-przypisywac-sobie-zaslug-6949247098541697v.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T12:00:02+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/79881e03-936b-400b-a88a-73ba255087e7.jpg" width="308" /> W środę Rada Polityki Pieniężnej podjęła decyzję o kolejnej obniżce stóp procentowych. Prezes NBP Adam Glapiński ogłosił dzień później, że Polska ma wielki sukces w walce z inflacją. Na ile jednak spadek inflacji to efekt działań NBP? - NBP ma na to znikomy wpływ - ocenił Jan Oleszczuk-Zygmuntowski w programie Debata Gospodarcza Money.pl. Jak wskazywał, kryzys inflacyjny był bowiem związany z wieloma innymi czynnikami, na które decyzje RPP nie mają wpływu. Z kolei Łukasz Komuda przypominał, że prezes Glapiński zapierał się przed podnoszeniem stóp procentowych, co potem i tak zrobił.

## LOT prezentuje nowe wnętrze Deamlinerów. "Nie zapominamy o naszym dziedzictwie kulturowym"
 - [https://www.money.pl/gospodarka/lot-prezentuje-nowe-wnetrze-deamlinerow-nie-zapominamy-o-naszym-dziedzictwie-kulturowym-6949228211231328a.html](https://www.money.pl/gospodarka/lot-prezentuje-nowe-wnetrze-deamlinerow-nie-zapominamy-o-naszym-dziedzictwie-kulturowym-6949228211231328a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T10:43:53+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ac492d34-6862-495f-9980-b87112e6e38c" width="308" /> Samoloty Boeing 787-8 Dreamliner należące do spółki PLL LOT przejdą modernizację. Całkowicie zmienią się ich wnętrza, co pokazują wizualizacje firmy. – Nie zapominamy o akcentach z naszego dziedzictwa kulturowego – zapewniają przedstawiciele firmy. Podróżni będą mogli skorzystać z internetu na pokładzie.

## To nie koniec obniżek stóp procentowych? Członkini RPP mówi, co dalej
 - [https://www.money.pl/gospodarka/to-nie-koniec-obnizek-stop-procentowych-czlonkini-rpp-mowi-co-dalej-6949223271615072a.html](https://www.money.pl/gospodarka/to-nie-koniec-obnizek-stop-procentowych-czlonkini-rpp-mowi-co-dalej-6949223271615072a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T10:21:49+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ad6a993b-08f6-4ea1-9cd2-867050fd33d7" width="308" /> Wydaje się, że trend obniżania stóp będzie utrzymywany, ale nie można obecnie powiedzieć, czy będzie to po 25 pb., czy więcej - wynika z wypowiedzi członkini RPP Gabrieli Masłowskiej w Radiu Lublin. Dodała, że pod koniec roku inflacja może wzrosnąć do nieco ponad 7 proc., a w 2024 r. wzrost PKB Polski wyniesie ponad 2 proc.

## "Nigdy tak nie ma". Ekonomiści kontrują tezę Glapińskiego o bezrobociu
 - [https://www.money.pl/gospodarka/nigdy-tak-nie-ma-ekonomisci-kontruja-teze-glapinskiego-o-bezrobociu-6949219446941313v.html](https://www.money.pl/gospodarka/nigdy-tak-nie-ma-ekonomisci-kontruja-teze-glapinskiego-o-bezrobociu-6949219446941313v.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T10:10:04+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/afa940f3-b60f-4426-ad24-2bc0ef0767a4.jpg" width="308" /> Prezes NBP Adam Glapiński podczas ostatniej konferencji stwierdził, że gdyby walka z inflacją była ostrzejsza, to mogłaby skutkować dużym wzrostem bezrobocia, które odbiłoby się na sytuacji Polaków. Podczas Debaty Gospodarczej Money.pl ekonomista Łukasz Komuda wyjaśniał jednak, że jest to "fałszywy dualizm". - Nigdy tak nie ma, że mamy tylko opcje A i B. Możemy wybrać korytarz polityki, która będzie mało szkodliwa - ocenił Komuda. Wyjaśnił też, że niskie bezrobocie to efekt m.in. demografii. - Tracimy co miesiąc ok. 20 tys. osób w wieku produkcyjnym. To spuszcza powietrze z napięcia, które inaczej by istniało i generowało większą liczbę zwolnień i efekt bezrobocia - podkreślił.

## Producenci słodkich napojów tracą. Inwestorzy przestraszyli się, że Ameryka chce iść na dietę
 - [https://www.money.pl/gielda/producenci-slodkich-napojow-traca-inwestorzy-przestraszyli-sie-ze-ameryka-chce-isc-na-diete-6949218002254432a.html](https://www.money.pl/gielda/producenci-slodkich-napojow-traca-inwestorzy-przestraszyli-sie-ze-ameryka-chce-isc-na-diete-6949218002254432a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T10:00:23+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d73dd6b5-02ff-4fb6-834c-425b1ffdef53" width="308" /> Coca-Cola i PepsiCo tracą na amerykańskiej giełdzie. Wahnięcie jest na tyle duże, że pakiet akcji, które posiada Warren Buffet, staniał o miliard dol. Skąd pesymizm inwestorów? Powodem jest wzrost popularności leku na otyłość. Ozempic może sprawić, że Ameryka przestanie pić tyle słodkich napojów.

## "Nie powinniśmy odtrąbiać sukcesu". Widmo inflacji wciąż wisi nad Polską
 - [https://www.money.pl/gospodarka/nie-powinnismy-odtrabiac-sukcesu-widmo-inflacji-wciaz-wisi-nad-polska-6949203228710529v.html](https://www.money.pl/gospodarka/nie-powinnismy-odtrabiac-sukcesu-widmo-inflacji-wciaz-wisi-nad-polska-6949203228710529v.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T09:12:04+00:00

<img src="https://i.wpimg.pl/308x/wptv-upload-api.wpcdn.pl/07f0df64-875a-4d2f-b20d-9d0711bb9eb5.jpg" width="308" /> W czwartek prezes Narodowego Banku Polskiego ogłosił "wielki sukces w walce z inflacją". Jak jednak wskazują eksperci w Debacie Gospodarczej Money.pl, jest za wcześnie na ogłaszanie tryumfu. Jan Oleszczuk-Zygmuntowski i Łukasz Komuda opowiedzieli m.in. o tym, jakie czynniki wciąż mogą wywołać wzrost inflacji w najbliższych miesiącach.

## Orlen nabędzie dwie farmy wiatraków od Brytyjczyków. Jest umowa
 - [https://www.money.pl/gospodarka/orlen-nabedzie-dwie-farmy-wiatrakow-od-brytyjczykow-jest-umowa-6949197205117536a.html](https://www.money.pl/gospodarka/orlen-nabedzie-dwie-farmy-wiatrakow-od-brytyjczykow-jest-umowa-6949197205117536a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T08:35:45+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bf090bae-339b-4d53-88e2-bed47f06f084" width="308" /> Orlen zawarł warunkową umowę zakupu dwóch farm wiatrowych ze spółką należącą do brytyjskiego Octopus Renewables Infrastructure Trust PLC – przekazał koncern. Instalacje o łącznej mocy ok. 60 MW znajdują się w województwach wielkopolskim i zachodniopomorskim.

## Prezes znanej spółki rezygnuje po 13 latach. Polski gigant gier traci na giełdzie
 - [https://www.money.pl/gielda/prezes-znanej-spolki-rezygnuje-po-13-latach-polski-gigant-gier-traci-na-gieldzie-6949193386224224a.html](https://www.money.pl/gielda/prezes-znanej-spolki-rezygnuje-po-13-latach-polski-gigant-gier-traci-na-gieldzie-6949193386224224a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T08:24:07+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8e2d556e-b80f-4f04-acc6-61c6f25692b4" width="308" /> Adam Kiciński, który od 2010 roku pełni funkcję prezesa CD Projekt, ogłosił rezygnację ze stanowiska. Pozostaje jednak w spółce. Zarząd poinformował z kolei o zmianach w strukturze zarządzania. Notowania twórców Wiedźmina i Cyberpunk 2077 wyraźnie tracą na giełdzie.

## OpenAI ma dość niedoborów chipów na rynku. Rozważa stworzenie własnych
 - [https://www.money.pl/gospodarka/openai-ma-dosc-niedoborow-chipow-na-rynku-rozwaza-stworzenie-wlasnych-6949178974141024a.html](https://www.money.pl/gospodarka/openai-ma-dosc-niedoborow-chipow-na-rynku-rozwaza-stworzenie-wlasnych-6949178974141024a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T07:21:35+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/7a7f3d61-ad76-4f7d-92e3-5d46fad38858" width="308" /> OpenAI, firma stojąca za sztuczną inteligencją ChatGPT, rozważa stworzenie własnych chipów AI – podaje Reuters, który powołuje się na swoje nieoficjalne ustalenia. W tym celu rozważa nawet potencjalne przejęcie jednej z firm produkujących mikroprocesory.

## Tak zarabiają banki. Zyski z lokat spadają szybciej niż raty kredytów
 - [https://www.money.pl/banki/tak-zarabiaja-banki-zyski-z-lokat-spadaja-szybciej-niz-raty-kredytow-6949178524625504a.html](https://www.money.pl/banki/tak-zarabiaja-banki-zyski-z-lokat-spadaja-szybciej-niz-raty-kredytow-6949178524625504a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T07:19:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/92640b9f-d738-45d8-80e3-cb0ad1b81d98" width="308" /> Rada Polityki Pieniężnej obniżyła po październikowym posiedzeniu wszystkie stopy procentowe NBP o 25 punktów bazowych. "Fakt" informuje, że bankom nie śpieszy się do zmiany oprocentowania kredytów, za to "szybko tną oprocentowanie lokat".

## Ofensywa Żabki. Sieć otworzy sklepy całodobowe i typu drive-thru
 - [https://www.money.pl/gospodarka/ofensywa-zabki-siec-otworzy-sklepy-calodobowe-i-typu-drive-thru-6949164450986592a.html](https://www.money.pl/gospodarka/ofensywa-zabki-siec-otworzy-sklepy-calodobowe-i-typu-drive-thru-6949164450986592a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T06:22:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4465e86d-c41c-4850-afdc-611d6fee1fd5" width="308" /> Już w październiku na handlowej mapie Polski będzie 10 tys. sklepów z szyldem Żabki. W tym samym miesiącu sieć uruchomi też dwa nowe formaty. Klienci będą mogli zrobić zakupy w punktach całodobowych lub bez wysiadania z samochodu. Gigant pokazał też swoje wyniki finansowe.

## Mur na granicy z Meksykiem. Jest ważna deklaracja USA
 - [https://www.money.pl/gospodarka/mur-na-granicy-z-meksykiem-jest-wazna-deklaracja-usa-6949156962720384a.html](https://www.money.pl/gospodarka/mur-na-granicy-z-meksykiem-jest-wazna-deklaracja-usa-6949156962720384a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:52:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/85192356-3eb6-42c9-bf8d-776461ecdbef" width="308" /> Ogłoszenie budowy kolejnego odcinka muru granicznego na granicy z Meksykiem nie oznacza zmiany polityki administracji w tej kwestii - oświadczyli w czwartek przedstawiciele administracji Joe Bidena. Sam prezydent stwierdził, że wciąż uważa, że mur nie jest skuteczny.

## Kursy walut 06.10.2023. Piątkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-06-10-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6949149354109568a.html](https://www.money.pl/pieniadze/kursy-walut-06-10-2023-piatkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6949149354109568a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:21:04+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 06.10.2023. W piątek za jednego dolara (USD) zapłacimy 4,3634 zł. Cena jednego funta szterlinga (GBP) to 5,3127 zł, a franka szwajcarskiego (CHF) 4,7770 zł. Z kolei euro (EUR) możemy zakupić za 4,5993 zł.

## Chcą ograniczyć swobodę najmu krótkoterminowego. Dlatego, że brakuje mieszkań w miastach
 - [https://www.money.pl/gospodarka/chca-ograniczyc-swobode-najmu-krotkoterminowego-dlatego-ze-brakuje-mieszkan-w-miastach-6949147684768384a.html](https://www.money.pl/gospodarka/chca-ograniczyc-swobode-najmu-krotkoterminowego-dlatego-ze-brakuje-mieszkan-w-miastach-6949147684768384a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:14:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b79db8fc-d4f1-4b18-bd8e-c4b6edda1e9e" width="308" /> Wielkie europejskie miasta wypowiadają wojnę najmowi krótkoterminowemu. Chcą ograniczyć plagę wynajmowania w ten sposób zasobów mieszkaniowych. Pomóc w tym ma szykowane unijne rozporządzenie. Akt ma ucywilizować rynek, jak również wprowadzić ograniczenia.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 06.10.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-06-10-2023-6949144237005408a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-06-10-2023-6949144237005408a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 06.10.2023. W piątek za jednego dolara (USD) trzeba zapłacić 4.3618 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 06.10.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-06-10-2023-6949144236735104a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-06-10-2023-6949144236735104a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 06.10.2023. W piątek za jedno euro (EUR) trzeba zapłacić 4.5974 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 06.10.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-06-10-2023-6949144239024768a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-06-10-2023-6949144239024768a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 06.10.2023. W piątek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3115 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 06.10.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-06-10-2023-6949144236255840a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-06-10-2023-6949144236255840a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T05:00:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 06.10.2023. W piątek za jednego franka (CHF) trzeba zapłacić 4.7745 zł.

## Nie oszczędzają. Budżet kancelarii premiera przebił kolejną granicę
 - [https://www.money.pl/gospodarka/nie-oszczedzaja-budzet-kancelarii-premiera-przebil-kolejna-granice-6949141178210944a.html](https://www.money.pl/gospodarka/nie-oszczedzaja-budzet-kancelarii-premiera-przebil-kolejna-granice-6949141178210944a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T04:47:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5b5a869d-ca96-42df-ad44-b7a1abdef134" width="308" /> Po raz pierwszy w historii roczny budżet Kancelarii Premiera ma przebić barierę 2 mld zł. Zdaniem rządu wydatki są uzasadnione, opozycja uważa inaczej - informuje "Rzeczpospolita". I dodaje, że w 2024 wydatki w Kancelarii Prezesa Rady Ministrów mają wynosić dokładnie 2,069 mld zł.

## Biden ominie Kongres? Tak chce pomóc Ukrainie
 - [https://www.money.pl/gospodarka/biden-ominie-kongres-tak-chce-pomoc-ukrainie-6949134638230144a.html](https://www.money.pl/gospodarka/biden-ominie-kongres-tak-chce-pomoc-ukrainie-6949134638230144a.html)
 - RSS feed: https://www.money.pl/rss/rss.xml
 - date published: 2023-10-06T04:21:10+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/6db35fe0-4004-4639-b867-64fd8f21af4b" width="308" /> Administracja Joe Bidena rozważa wykorzystanie środków z innych programów rządowych, w tym z Departamentu Stanu, by finansować zbrojenie Ukrainy w obliczu niejasnej sytuacji w Kongresie - poinformował portal Politico. O możliwości alternatywnych rozwiązań w tej sprawie mówił wcześniej prezydent Joe Biden.

