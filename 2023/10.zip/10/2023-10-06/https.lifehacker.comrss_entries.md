# Source:Lifehacker, URL:https://lifehacker.com/rss, language:en-US

## You Can Get Flux 7 Earbuds on Sale for $23 Right Now
 - [https://lifehacker.com/you-can-get-flux-7-earbuds-on-sale-for-23-right-now-1850899669](https://lifehacker.com/you-can-get-flux-7-earbuds-on-sale-for-23-right-now-1850899669)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-10-06T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/83b6b747c8259f2ab05c229410c879d5.png" /><p>The Flux 7 Earbuds are a cheaper AirPod alternative that works on both iOS and Android devices, and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://shop.lifehacker.com/sales/flux-7-tws-earbuds-w-wireless-charging-case-power-bank-black?utm_source=lifehacker.com&amp;utm_medium=referral&amp;utm_campaign=flux-7-tws-earbuds-w-wireless-charging-case-power-bank-black&amp;utm_term=scsf-580683&amp;utm_content=a0xRn0000001HICIA2&amp;scsonar=1" rel="noopener noreferrer" target="_blank">they’re on sale</a>: You can get a single pair for $22.97 (reg. $69.99) or two pairs for $34.97 (reg. $99.99) until Oct. 15. </p><p><a href="https://lifehacker.com/you-can-get-flux-7-earbuds-on-sale-for-23-right-now-1850899669">Read more...</a></p>

## The 23 Gayest Horror Movies Ever Made
 - [https://lifehacker.com/the-23-gayest-horror-movies-ever-made-1850902784](https://lifehacker.com/the-23-gayest-horror-movies-ever-made-1850902784)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-10-06T14:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/f6cde2db8fd680b38bf152d491ff8102.png" /><p>Just a few short years ago, the pickings were extremely slim for horror movies with explicitly queer characters and themes—plenty of great movies with subtext (some of which we’ll get to), but very few that made that subtext into text. That, despite horror movies having legions of queer fans (seriously, the biggest…</p><p><a href="https://lifehacker.com/the-23-gayest-horror-movies-ever-made-1850902784">Read more...</a></p>

## The Easiest Way to Ask Your Bank for a Higher Credit Limit
 - [https://lifehacker.com/the-easiest-way-to-ask-your-bank-for-a-higher-credit-li-1850903120](https://lifehacker.com/the-easiest-way-to-ask-your-bank-for-a-higher-credit-li-1850903120)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-10-06T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/3c4a8e734e396a9f6658809d57d664d2.jpg" /><p>Having a higher credit limit on your credit card can be beneficial in several ways. It can help improve your credit score by lowering your credit utilization ratio. It also gives you more purchasing power and flexibility with your spending. But automatic credit limit increases aren’t automatic—you have to ask your…</p><p><a href="https://lifehacker.com/the-easiest-way-to-ask-your-bank-for-a-higher-credit-li-1850903120">Read more...</a></p>

## How to Freeze Apples so You Don’t Ruin Them for Later
 - [https://lifehacker.com/how-to-freeze-apples-so-you-don-t-ruin-them-for-later-1850904637](https://lifehacker.com/how-to-freeze-apples-so-you-don-t-ruin-them-for-later-1850904637)
 - RSS feed: https://lifehacker.com/rss
 - date published: 2023-10-06T12:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/image/upload/c_fit,fl_progressive,q_80,w_636/ebeb77f45bd2acd63a091bcd550e2850.jpg" /><p>Apples are a hearty fruit. They’ll stay fresh for a whole week on the counter (berries could never), and up to two months in the refrigerator, or a cool, dark cellar. It is, however, easy to get a little overenthusiastic while apple-picking, which is when the freezer becomes your friend. Here’s how to store apples in…</p><p><a href="https://lifehacker.com/how-to-freeze-apples-so-you-don-t-ruin-them-for-later-1850904637">Read more...</a></p>

