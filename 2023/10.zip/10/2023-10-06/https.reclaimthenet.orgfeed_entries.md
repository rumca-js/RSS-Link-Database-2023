# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## Canada Plots to Increase Online Regulation, Target Search and Social Media Algorithms
 - [https://reclaimthenet.org/canada-plots-to-increase-online-regulation-target-search-and-social-media-algorithms](https://reclaimthenet.org/canada-plots-to-increase-online-regulation-target-search-and-social-media-algorithms)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T19:12:22+00:00

<a href="https://reclaimthenet.org/canada-plots-to-increase-online-regulation-target-search-and-social-media-algorithms" rel="nofollow" title="Canada Plots to Increase Online Regulation, Target Search and Social Media Algorithms"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/trudeau-99.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>More government manipulation.</p>
<p>The post <a href="https://reclaimthenet.org/canada-plots-to-increase-online-regulation-target-search-and-social-media-algorithms" rel="nofollow">Canada Plots to Increase Online Regulation, Target Search and Social Media Algorithms</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## California’s Anti-“Misinformation” Law Collapses Thanks to the First Amendment
 - [https://reclaimthenet.org/californias-anti-misinformation-law-collapses-thanks-to-the-first-amendment](https://reclaimthenet.org/californias-anti-misinformation-law-collapses-thanks-to-the-first-amendment)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T18:49:45+00:00

<a href="https://reclaimthenet.org/californias-anti-misinformation-law-collapses-thanks-to-the-first-amendment" rel="nofollow" title="California&#8217;s Anti-&#8220;Misinformation&#8221; Law Collapses Thanks to the First Amendment"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/newsom023.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The authoritarian law will be officially repealed.</p>
<p>The post <a href="https://reclaimthenet.org/californias-anti-misinformation-law-collapses-thanks-to-the-first-amendment" rel="nofollow">California&#8217;s Anti-&#8220;Misinformation&#8221; Law Collapses Thanks to the First Amendment</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The DHS Plot To Combine Mass Surveillance With AI
 - [https://reclaimthenet.org/the-dhs-plot-to-combine-mass-surveillance-with-ai](https://reclaimthenet.org/the-dhs-plot-to-combine-mass-surveillance-with-ai)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T18:47:30+00:00

<a href="https://reclaimthenet.org/the-dhs-plot-to-combine-mass-surveillance-with-ai" rel="nofollow" title="The DHS Plot To Combine Mass Surveillance With AI"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/dhs-ai.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Surveillance is about to accelerate.</p>
<p>The post <a href="https://reclaimthenet.org/the-dhs-plot-to-combine-mass-surveillance-with-ai" rel="nofollow">The DHS Plot To Combine Mass Surveillance With AI</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Facebook Censors Report On Study About Covid Vaccine mRNA Found in Breast Milk
 - [https://reclaimthenet.org/facebook-censors-study-covid-vaccine-mrna-found-in-breast-milk](https://reclaimthenet.org/facebook-censors-study-covid-vaccine-mrna-found-in-breast-milk)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T18:43:18+00:00

<a href="https://reclaimthenet.org/facebook-censors-study-covid-vaccine-mrna-found-in-breast-milk" rel="nofollow" title="Facebook Censors Report On Study About Covid Vaccine mRNA Found in Breast Milk"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/fb-censor-article.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Censoring accurate information.</p>
<p>The post <a href="https://reclaimthenet.org/facebook-censors-study-covid-vaccine-mrna-found-in-breast-milk" rel="nofollow">Facebook Censors Report On Study About Covid Vaccine mRNA Found in Breast Milk</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## More Rights Groups Challenge New York’s “Anti-Hate” Censorship Law
 - [https://reclaimthenet.org/more-rights-groups-challenge-new-yorks-anti-hate-censorship-law](https://reclaimthenet.org/more-rights-groups-challenge-new-yorks-anti-hate-censorship-law)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T15:34:25+00:00

<a href="https://reclaimthenet.org/more-rights-groups-challenge-new-yorks-anti-hate-censorship-law" rel="nofollow" title="More Rights Groups Challenge New York&#8217;s &#8220;Anti-Hate&#8221; Censorship Law"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/hochul.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>A challenge invoking the First Amendment.</p>
<p>The post <a href="https://reclaimthenet.org/more-rights-groups-challenge-new-yorks-anti-hate-censorship-law" rel="nofollow">More Rights Groups Challenge New York&#8217;s &#8220;Anti-Hate&#8221; Censorship Law</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## EU Media Freedom Act, Which Makes it Legal (In Some Circumstances) to Install Spyware on Journalists’ Devices, Passes Key Vote
 - [https://reclaimthenet.org/eu-media-freedom-act-passes-key-vote](https://reclaimthenet.org/eu-media-freedom-act-passes-key-vote)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-10-06T14:25:15+00:00

<a href="https://reclaimthenet.org/eu-media-freedom-act-passes-key-vote" rel="nofollow" title="EU Media Freedom Act, Which Makes it Legal (In Some Circumstances) to Install Spyware on Journalists’ Devices, Passes Key Vote"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/10/Jourova.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Another crazy idea from the EU.</p>
<p>The post <a href="https://reclaimthenet.org/eu-media-freedom-act-passes-key-vote" rel="nofollow">EU Media Freedom Act, Which Makes it Legal (In Some Circumstances) to Install Spyware on Journalists’ Devices, Passes Key Vote</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

