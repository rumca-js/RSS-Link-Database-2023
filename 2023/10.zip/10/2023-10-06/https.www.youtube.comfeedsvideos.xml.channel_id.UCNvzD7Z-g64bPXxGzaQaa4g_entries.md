# Source:Gameranx, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g, language:en-US

## NEW GRAPHICS DEMO LOOKS INSANELY REAL, WHERE IS KOTOR? & MORE
 - [https://www.youtube.com/watch?v=u5GRPs_1Ukg](https://www.youtube.com/watch?v=u5GRPs_1Ukg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-10-06T17:35:34+00:00

Thank you Factor for sponsoring this video.Use code GAMERANX50 to get 50% off your first Factor box at https://bit.ly/3EYP7Zl.


~~SOURCES~~



Crazy graphics
https://youtu.be/5kJljpC5sHE?si=YrVE_9HIJoYfZCCY

Black Ops….6?
https://www.gamingbible.com/news/platform/xbox/call-of-duty-black-ops-2-free-download-surprises-fans-155645-20230925

What’s up with KOTOR?
https://www.ign.com/articles/renewed-we concern-for-star-wars-knights-of-the-old-republic-remake-as-trailers-and-tweets-are-culled

Another Crab’s Treasure demo
https://store.steampowered.com/app/1887840/Another_Crabs_Treasure/

Robocop Rogue City demo
https://store.steampowered.com/app/1681430/RoboCop_Rogue_City/

Animal Crossing Lego
https://jaysbrickblog.com/news/lego-animal-crossing-officially-announced/


The making of Fable 2 
https://www.thegamer.com/the-making-of-fable-2-peter-molyneux-dene-carter-interviews/

Forza Motorsport 
AC Mirage
https://youtu.be/XgW6AxYFVz8?si=_6L7qi0mNdazd1ub

Call of Duty Next updates
https:/

## Assassin's Creed Mirage: 10 Things The Game Doesn't Tell You
 - [https://www.youtube.com/watch?v=sn8nZkKVP_s](https://www.youtube.com/watch?v=sn8nZkKVP_s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCNvzD7Z-g64bPXxGzaQaa4g
 - date published: 2023-10-06T01:37:28+00:00

Assassin's Creed Mirage (PC, PS5, Xbox Series X, PS4, Xbox One) is packed with things to learn and secrets to find. Here are some tips to guide you on your playthrough.
Subscribe for more: https://www.youtube.com/gameranxTV?sub_confirmation=1    

0:00 Intro
0:47 Number 10
1:56 Number 9
3:33 Number 8
5:08 Number 7
6:35 Number 6
8:05 Number 5
9:07 Number 4
9:53 Number 3 
10:45 Number 2 
11:52 Number 1

