# Source:Epoch Times - World, URL:https://feed.theepochtimes.com/world/feed, language:en-US

## Liberal MP Who Broke Ranks on Vote to Axe Carbon Tax Says Policy is Hurting Rural Canadians
 - [https://www.theepochtimes.com/world/liberal-mp-who-broke-ranks-on-vote-to-axe-carbon-tax-says-policy-is-hurting-rural-canadians-5505180](https://www.theepochtimes.com/world/liberal-mp-who-broke-ranks-on-vote-to-axe-carbon-tax-says-policy-is-hurting-rural-canadians-5505180)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T16:23:47+00:00

A woman fills up her vehicle with gas in Toronto on April 1, 2019. (The Canadian Press/Christopher Katsarov)

## Heavy Rain and Floods Kill 6 People in Sri Lanka and Force Schools to Close
 - [https://www.theepochtimes.com/world/heavy-rain-and-floods-kill-6-people-in-sri-lanka-and-force-schools-to-close-5505244](https://www.theepochtimes.com/world/heavy-rain-and-floods-kill-6-people-in-sri-lanka-and-force-schools-to-close-5505244)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T15:23:10+00:00

A security officer stands by a bus that was damaged when a tree fell on it in Colombo, Sri Lanka, on Oct. 6, 2023. (AP Photo)

## Russia Signals Intent to Quickly Revoke Ratification of Nuclear Test Ban Treaty
 - [https://www.theepochtimes.com/world/russia-signals-intent-to-quickly-revoke-ratification-of-nuclear-test-ban-treaty-5505163](https://www.theepochtimes.com/world/russia-signals-intent-to-quickly-revoke-ratification-of-nuclear-test-ban-treaty-5505163)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T15:04:25+00:00

Russia's State Duma Speaker Vyacheslav Volodin attends a military parade on Victory Day, in Red Square in central Moscow on May 9, 2022. (Maxim Shemetov/Reuters)

## Depression, Self-Harm, Suicidal Thoughts Plagued Elderly in Lockdowns, COVID-19 Inquiry Hears
 - [https://www.theepochtimes.com/world/depression-self-harm-suicidal-thoughts-plagued-elderly-in-lockdowns-covid-19-inquiry-hears-5505111](https://www.theepochtimes.com/world/depression-self-harm-suicidal-thoughts-plagued-elderly-in-lockdowns-covid-19-inquiry-hears-5505111)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T14:44:22+00:00

Care home resident Dot Hendy holds her daughter Louise's hand for the first time since March after Louise successfully passed a Rapid COVID-19 Test immediately before meeting her mother at the King Charles Court Care Home, Falmouth, England, on Nov. 18, 2020. (Hugh Hastings/Getty Images)

## Economy Adds 64K Jobs in September, Unemployment Rate Holds Steady at 5.5%
 - [https://www.theepochtimes.com/world/economy-adds-64k-jobs-in-september-unemployment-rate-holds-steady-at-5-5-post-5505185](https://www.theepochtimes.com/world/economy-adds-64k-jobs-in-september-unemployment-rate-holds-steady-at-5-5-post-5505185)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T14:08:22+00:00

Signage marks the Statistics Canada offices in Ottawa on July 21, 2010. (The Canadian Press/Sean Kilpatrick)

## Ghost Guns Showing up at Crime Scenes in Canada but RCMP Not Keeping Statistics
 - [https://www.theepochtimes.com/world/ghost-guns-showing-up-at-crime-scenes-in-canada-but-rcmp-not-keeping-statistics-5505174](https://www.theepochtimes.com/world/ghost-guns-showing-up-at-crime-scenes-in-canada-but-rcmp-not-keeping-statistics-5505174)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T13:58:43+00:00

Quebec provincial police Sgt. Audrey-Ane Bilodeau shows some of the 3D-printed ghost guns seized in Operation Centaure during a news conference in Montreal, on June 21, 2023. (The Canadian Press/Ryan Remiorz)

## BC and Ottawa Applaud NAFTA Decision on US Softwood Lumber Duties
 - [https://www.theepochtimes.com/world/bc-and-ottawa-applaud-nafta-decision-on-us-softwood-lumber-duties-5505162](https://www.theepochtimes.com/world/bc-and-ottawa-applaud-nafta-decision-on-us-softwood-lumber-duties-5505162)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T13:27:40+00:00

A stack of lumber is pictured in Merritt, B.C., on May 2, 2017. (The Canadian Press/Jonathan Hayward)

## China Will Invade Taiwan Unless Convinced Peaceful Unification Possible: Experts
 - [https://www.theepochtimes.com/china/china-will-invade-taiwan-unless-convinced-peaceful-unification-possible-experts-5504812](https://www.theepochtimes.com/china/china-will-invade-taiwan-unless-convinced-peaceful-unification-possible-experts-5504812)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T13:26:45+00:00

Taiwan's armed forces hold two days of routine drills to show combat readiness ahead of Lunar New Year holidays at a military base in Kaohsiung, Taiwan, on Jan. 12, 2023. (Annabelle Chih/Getty Images)

## Jailed Iranian Activist Narges Mohammadi Wins Nobel Peace Prize
 - [https://www.theepochtimes.com/world/jailed-iranian-activist-narges-mohammadi-wins-nobel-peace-prize-5505149](https://www.theepochtimes.com/world/jailed-iranian-activist-narges-mohammadi-wins-nobel-peace-prize-5505149)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T13:08:41+00:00

Iranian human rights activist and the vice president of the Defenders of Human Rights Center (DHRC) Narges Mohammadi poses in this undated handout picture. (Mohammadi family archive photos/Handout via Reuters)

## Sunak Makes Deals With European Countries to Tackle Illegal Immigration
 - [https://www.theepochtimes.com/world/sunak-makes-deals-with-european-countries-to-tackle-illegal-immigration-5505123](https://www.theepochtimes.com/world/sunak-makes-deals-with-european-countries-to-tackle-illegal-immigration-5505123)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T12:10:23+00:00

A group of illegal immigrants in a small boat travelling France and heading in the direction of Dover, England, on Aug. 29, 2023. (Gareth Fuller/PA)

## Couple With ‘Everything in Life’ Quit Jobs and Sell Everything to Travel the World With Their 4 Kids
 - [https://www.theepochtimes.com/bright/couple-with-everything-in-life-quit-jobs-and-sell-everything-to-travel-the-world-with-their-4-kids-5503679](https://www.theepochtimes.com/bright/couple-with-everything-in-life-quit-jobs-and-sell-everything-to-travel-the-world-with-their-4-kids-5503679)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T10:30:30+00:00

(SWNS)

## MPs Back Call to ‘Immediately Stop’ Live Facial Recognition Surveillance
 - [https://www.theepochtimes.com/world/mps-back-call-to-immediately-stop-live-facial-recognition-surveillance-5505094](https://www.theepochtimes.com/world/mps-back-call-to-immediately-stop-live-facial-recognition-surveillance-5505094)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T10:22:54+00:00

An undated image showing two activists holding up placards and wearing masks of policing minister Chris Philp (L) and Home Secretary Suella Braverman (R) outside the Houses of Parliament in Westminster, London. (Big Brother Watch)

## Labour Hails ‘Seismic’ By-election Win in Rutherglen and Hamilton West
 - [https://www.theepochtimes.com/world/labour-hails-seismic-by-election-win-in-rutherglen-and-hamilton-west-5505078](https://www.theepochtimes.com/world/labour-hails-seismic-by-election-win-in-rutherglen-and-hamilton-west-5505078)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T09:46:27+00:00

Scottish Labour leader Anas Sarwar (R) with candidate Michael Shanks after Labour won the Rutherglen and Hamilton West by-election, at South Lanarkshire Council Headquarters in Hamilton, England, on Oct. 6, 2023. (Jane Barlow/PA)

## Japan Starts Releasing Second Batch of Fukushima Treated Water
 - [https://www.theepochtimes.com/world/japan-starts-releasing-second-batch-of-fukushima-treated-water-5504971](https://www.theepochtimes.com/world/japan-starts-releasing-second-batch-of-fukushima-treated-water-5504971)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T07:00:23+00:00

The Fukushima Daiichi nuclear power plant in Fukushima, northern Japan, on Aug. 24, 2023. (Kyodo News via AP)

## Melbourne’s e-Scooter Trial Extended Again
 - [https://www.theepochtimes.com/world/melbournes-e-scooter-trial-extended-again-5505029](https://www.theepochtimes.com/world/melbournes-e-scooter-trial-extended-again-5505029)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T06:28:16+00:00

In this file image, a row of electric scooters is seen in in London, England on July 5, 2021. (Leon Neal/Getty Images)

## ‘Incredibly Weak’: Greens Push Victorian Government to Pass Lenient Bail Laws
 - [https://www.theepochtimes.com/world/incredibly-weak-greens-push-victorian-government-to-pass-lenient-bail-laws-5504990](https://www.theepochtimes.com/world/incredibly-weak-greens-push-victorian-government-to-pass-lenient-bail-laws-5504990)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T05:25:21+00:00

Victorian Deputy Premier Jacinta Allan addresses the media during a press conference in Melbourne, Australia, on Dec. 29, 2020. (AAP Image/James Ross)

## NSW Commission Calls for 2 Million Flu Jabs in Mass Campaign Against the Flu
 - [https://www.theepochtimes.com/world/nsw-commission-calls-for-2-million-flu-jabs-in-mass-campaign-against-the-flu-5505026](https://www.theepochtimes.com/world/nsw-commission-calls-for-2-million-flu-jabs-in-mass-campaign-against-the-flu-5505026)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T04:56:54+00:00

Three 10-dose influenza virus vaccine vials are seen at Ballin Pharmacy in Chicago, Illinois on October 8, 2004. (Tim Boyle/Getty Images)

## Australia Will Closely Monitor the UK’s Crackdown on Cigarettes: Health Minister
 - [https://www.theepochtimes.com/world/australia-will-closely-monitor-the-uks-crackdown-on-cigarettes-health-minister-5505015](https://www.theepochtimes.com/world/australia-will-closely-monitor-the-uks-crackdown-on-cigarettes-health-minister-5505015)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T04:28:42+00:00

A person shows off the new rubbish bins for smokers as part of the ACC plan to keep cigarette butts off the streets, in Auckland, New Zealand, on Dec. 10 2004. (Michael Bradley/Getty Images)

## Australian Living in the US Receives Multiple Mail-In Votes for the Voice Referendum
 - [https://www.theepochtimes.com/world/australian-living-in-the-us-receives-multiple-mail-in-votes-for-the-voice-referendum-5504988](https://www.theepochtimes.com/world/australian-living-in-the-us-receives-multiple-mail-in-votes-for-the-voice-referendum-5504988)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T04:26:53+00:00

Two postal votes were received by an Australian voter currently living in Seattle (Credit: Aisling Salisbury)

## Tropical Storm Philippe Chugs Toward Bermuda on Path to Atlantic Canada and New England
 - [https://www.theepochtimes.com/us/tropical-storm-philippe-chugs-toward-bermuda-on-path-to-atlantic-canada-and-new-england-5504834](https://www.theepochtimes.com/us/tropical-storm-philippe-chugs-toward-bermuda-on-path-to-atlantic-canada-and-new-england-5504834)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T03:54:32+00:00

A satellite image shows Tropical Storm Philippe (center R) on Oct. 2 2023. (NOAA via AP)

## Over 1,000 Coles, Woolies Workers Set to Strike
 - [https://www.theepochtimes.com/world/over-1000-coles-woolies-workers-set-to-strike-in-nationally-coordinated-effort-5504910](https://www.theepochtimes.com/world/over-1000-coles-woolies-workers-set-to-strike-in-nationally-coordinated-effort-5504910)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T03:38:01+00:00

Coles and Woolworths signs are seen outside a shopping centre in Melbourne, Australia, on May 25, 2015. (Quinn Rooney/Getty Images)

## ‘None of Us Understood’ Hunka’s Nazi Background, Says Freeland
 - [https://www.theepochtimes.com/world/none-of-us-understood-hunkas-nazi-background-says-freeland-5504719](https://www.theepochtimes.com/world/none-of-us-understood-hunkas-nazi-background-says-freeland-5504719)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T02:40:26+00:00

Canada’s Deputy Prime Minister Chrystia Freeland addresses a crowd at the Empire Club of Canada in Toronto, on June 16, 2022. (The Canadian Press/Cole Burston)

## Trudeau Contradicts Defence Officials on $1 Billion in Cuts to Military
 - [https://www.theepochtimes.com/world/trudeau-contradicts-defence-officials-on-1-billion-in-cuts-to-military-5504702](https://www.theepochtimes.com/world/trudeau-contradicts-defence-officials-on-1-billion-in-cuts-to-military-5504702)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T02:31:19+00:00

Prime Minister Justin Trudeau arrives to a caucus meeting on Parliament Hill in Ottawa on Oct. 4, 2023. (The Canadian Press/Sean Kilpatrick)

## York School Board Memo Directs Teachers to Keep Gender Transition of Students Secret From Parents
 - [https://www.theepochtimes.com/world/york-school-board-memo-directs-teachers-to-keep-gender-transition-of-students-secret-from-parents-5504903](https://www.theepochtimes.com/world/york-school-board-memo-directs-teachers-to-keep-gender-transition-of-students-secret-from-parents-5504903)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T01:22:21+00:00

A person walks in the hall at a school in Scarborough, Ont., in a file photo. (The Canadian Press/Nathan Denette)

## Chinese ‘Thousand Talents’ Scholar Serves on Academic Committee at Toronto Private School
 - [https://www.theepochtimes.com/world/chinese-thousand-talents-scholar-serves-on-academic-committee-at-toronto-private-school-5501088](https://www.theepochtimes.com/world/chinese-thousand-talents-scholar-serves-on-academic-committee-at-toronto-private-school-5501088)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T00:50:48+00:00

A Chinese flag is seen among Canadian flags in the Hall of Honour on Parliament Hill in Ottawa in a file photo. (The Canadian Press/Adrian Wyld)

## Daniel Andrews Has Left Victoria Worse for Wear
 - [https://www.theepochtimes.com/opinion/daniel-andrews-has-left-victoria-worse-for-wear-5504406](https://www.theepochtimes.com/opinion/daniel-andrews-has-left-victoria-worse-for-wear-5504406)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T00:46:19+00:00

Former Victorian Premier Daniel Andrews arrives ahead of the Labor caucus meeting  at Victorian Parliament House in Melbourne, Australia, on Sept. 27, 2023. (Asanka Ratnayake/Getty Images)

## Australian State Removes Common Anaesthetic in ‘Low Carbon’ Push
 - [https://www.theepochtimes.com/world/australian-state-removes-common-anaesthetic-in-low-carbon-push-5503615](https://www.theepochtimes.com/world/australian-state-removes-common-anaesthetic-in-low-carbon-push-5503615)
 - RSS feed: https://feed.theepochtimes.com/world/feed
 - date published: 2023-10-06T00:09:31+00:00

(Ryan M. Breeden/Getty Images)

