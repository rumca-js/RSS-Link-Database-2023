# Source:Ign - YouTube, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw, language:en-US

## Top 10 Assassin's Creed Games (Mirage Update)
 - [https://www.youtube.com/watch?v=WWXo-Lg8GuU](https://www.youtube.com/watch?v=WWXo-Lg8GuU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T23:00:21+00:00

Updated for Assassin's Creed Mirage.

The Assassin's Creed franchise has spanned the globe since it debuted in 2007, and entries have taken players from Renaissance Italy to Ancient Greece to the American Revolution. Along the way, the series has changed dramatically, from sequels that made good on the promise of past entries to entirely new takes on character progression. IGN's biggest Assassin's Creed fans came together to agree, argue, and eventually cull together our favorites.

#IGN #Gaming #AssassinsCreed

## Assassin’s Creed Mirage Collector’s Case UNBOXING! Presented by @AssassinsCreed #unboxing #mirage
 - [https://www.youtube.com/watch?v=DWqZ6Othwdw](https://www.youtube.com/watch?v=DWqZ6Othwdw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T22:55:01+00:00



## Top 10 PlayStation characters as voted by IGN readers! #playstation #top10 #list #sony #spiderman
 - [https://www.youtube.com/watch?v=tW8hrcx5AEI](https://www.youtube.com/watch?v=tW8hrcx5AEI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T22:15:36+00:00



## Your Lucky Day - Official Trailer (2023) Angus Cloud
 - [https://www.youtube.com/watch?v=SZHWlVtof0I](https://www.youtube.com/watch?v=SZHWlVtof0I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T22:00:19+00:00

After a dispute over a winning lottery ticket turns into a deadly hostage situation, the witnesses must decide exactly how far they’ll go—and how much blood they’re willing to spill—for a cut of the $156 million.

Your Lucky Day premiered on September 23 at Fantastic Fest 2023.

#IGN

## Killers of the Flower Moon - Official Clip (2023) Leonardo DiCaprio, Lily Gladstone
 - [https://www.youtube.com/watch?v=BX4_tCIwTaQ](https://www.youtube.com/watch?v=BX4_tCIwTaQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T20:30:00+00:00

Check out this clip from Killers of the Flower Moon, an upcoming film starring Leonardo DiCaprio, Robert De Niro, Lily Gladstone, and Jesse Plemons.

At the turn of the 20th century, oil brought a fortune to the Osage Nation, who became some of the richest people in the world overnight. The wealth of these Native Americans immediately attracted white interlopers, who manipulated, extorted, and stole as much Osage money as they could before resorting to murder. Based on a true story and told through the improbable romance of Ernest Burkhart (Leonardo DiCaprio) and Mollie Kyle (Lily Gladstone), Killers of the Flower Moon is an epic Western crime saga, where real love crosses paths with unspeakable betrayal. 

Killers of the Flower Moon is directed by Academy Award winner Martin Scorsese from a screenplay by Eric Roth and Martin Scorsese, based on David Grann’s best-selling book. It is produced by Martin Scorsese, Dan Friedkin, Bradley Thomas, and Daniel Lupi. Leonardo DiCaprio, Rick Yo

## Nickelodeon All-Star Brawl 2 - Official Azula Reveal Trailer
 - [https://www.youtube.com/watch?v=h1Uaz8mwIwM](https://www.youtube.com/watch?v=h1Uaz8mwIwM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T18:53:05+00:00

Azula from Avatar: The Last Airbender joins Nickelodeon All-Star Brawl 2. Check out the reveal trailer to see the character in action. Nickelodeon All-Star Brawl 2 will be available on PlayStation, Xbox, Nintendo Switch, and PC.

#IGN #Gaming

## Killers of the Flower Moon - Official Clip (2023) Leonardo DiCaprio, Robert De Niro
 - [https://www.youtube.com/watch?v=VzXcBZhuLSo](https://www.youtube.com/watch?v=VzXcBZhuLSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T17:30:02+00:00

Check out this tense clip from Killers of the Flower Moon, an upcoming film starring Leonardo DiCaprio, Robert De Niro, Lily Gladstone, and Jesse Plemons.

At the turn of the 20th century, oil brought a fortune to the Osage Nation, who became some of the richest people in the world overnight. The wealth of these Native Americans immediately attracted white interlopers, who manipulated, extorted, and stole as much Osage money as they could before resorting to murder. Based on a true story and told through the improbable romance of Ernest Burkhart (Leonardo DiCaprio) and Mollie Kyle (Lily Gladstone), Killers of the Flower Moon is an epic Western crime saga, where real love crosses paths with unspeakable betrayal. 

Killers of the Flower Moon is directed by Academy Award winner Martin Scorsese from a screenplay by Eric Roth and Martin Scorsese, based on David Grann’s best-selling book. It is produced by Martin Scorsese, Dan Friedkin, Bradley Thomas, and Daniel Lupi. Leonardo DiCaprio, R

## Fortnite x Transformers - Official Collaboration Pack Release Date Trailer
 - [https://www.youtube.com/watch?v=8Hs2beAYC3E](https://www.youtube.com/watch?v=8Hs2beAYC3E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T16:40:21+00:00

See what's included in the Fortnite x Transformers Pack in this new trailer for the popular battle royale game. This new Fortnite pack includes: three new outfits (Bumblebee, Megatron, Battlebus), three new Back Blings, three new pickaxes, two new emotes, and 1,000 V-Bucks. The trailer also reveals that the Fortnite Transformers Pack will be available at select retailers starting October 13 and digitally from October 20.

## Silent Hill: Ascension - Official Premiere Date Reveal Trailer
 - [https://www.youtube.com/watch?v=g0eo-0yi6_k](https://www.youtube.com/watch?v=g0eo-0yi6_k)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T14:00:35+00:00

Silent Hill: Ascension will host its world premiere on October 31, 2023 at 6pm PT/ 9pm ET/ November 1 at 2am UK/ 11am AEST. Join Genvid CEO and executive producer Jacob Navok to learn more about the upcoming live series premiere and get an idea of what to expect.

Silent Hill: Ascension is a new Genvid Interactive series where you, along with the rest of the community, can influence the Silent Hill canon. Tune in at the same time everyday to participate and watch the story unfold.

#IGN #SilentHill #SilentHillAscension

## 17 Minutes of Forza Motorsport Gameplay on Xbox Series X in 4K
 - [https://www.youtube.com/watch?v=uBNruQZGnCk](https://www.youtube.com/watch?v=uBNruQZGnCk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T13:09:38+00:00

Forza Motorsport 2023 gameplay from two of our favorite races running on the Xbox Series X in Quality Mode.

(0:00) Suzuka
(08:22) Spa

#IGN #Gaming #ForzaMotorsport

## Alan Wake 2 Dev on 30fps vs 60, Xbox Series S, and More - Next-Gen Console Watch
 - [https://www.youtube.com/watch?v=14rb-di1nj8](https://www.youtube.com/watch?v=14rb-di1nj8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T13:00:01+00:00

Welcome back to Next-Gen Console Watch, our show following all the news and rumors on the PlayStation 5 and Xbox Series. This week Max Scoville is filling in for Daemon Hatfield, and he's joined by Ryan McCaffrey, Executive Previews Editor and host of IGN’s Xbox podcast, Podcast Unlocked, and Miranda Sanchez, Executive Editor of the IGN guides team. On this episode we have a very special guest: joining us all the way from Finland is Thomas Puha, Communications Director for Remedy, the studio behind one of this year’s most anticipated games, Alan Wake 2. We take a dive into the challenges of adding a performance mode to a next-gen game, talk framerates and resolution, sneak in some Xbox Series S discourse, and ask him what Remedy would be looking for in a possible Nintendo Switch 2.

00:00 Intro
01:51 How important was getting performance mode ready for launch?
08:38 What are the trade-offs in quality and performance mode in Alan Wake II?
11:28 Is it reasonable for gamers to expect 4K

## RoboCop: Rogue City - Official Steam Demo Teaser Trailer
 - [https://www.youtube.com/watch?v=QlSrxSTUOak](https://www.youtube.com/watch?v=QlSrxSTUOak)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T11:30:38+00:00

The RoboCop: Rogue City demo is now available to download and play on Steam. Featuring the first three levels of the upcoming first-person shooter, play as unstoppable cyborg, RoboCop, and protect the city. Check out the first 23 minutes here: https://www.youtube.com/watch?v=MIs43_mh_wM 

Prepare to venture into Detroit, where the city lies on the edge of ruin and crime runs rampant. Omni Consumer Products corporation (OCP) has taken control of the Detroit Police Department in an attempt to restore order. RoboCop: Rogue City will be released on November 2, 2023 on Xbox Series X|S, PlayStation 5, and PC.

#IGN #Gaming #RoboCop

## Horizon Forbidden West Complete Edition - Official PS5 Launch Accolades Trailer
 - [https://www.youtube.com/watch?v=kYMlnXeLr9g](https://www.youtube.com/watch?v=kYMlnXeLr9g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T10:07:35+00:00

Horizon Forbidden West Complete Edition, which includes Horizon Forbidden West and the Horizon Forbidden West: Burning Shores DLC, is out now on PlayStation 5. Its PC version (Steam and Epic Games Store) will be available in early 2024. 

Check out the trailer for another peek at Aloy's journey as she braves the Forbidden West – a majestic but dangerous frontier teeming with mysterious new threats - and beyond, to the ruins of Los Angeles.

#IGN #Gaming #HorizonForbiddenWest

## Pet Sematary Bloodlines - Official Trailer
 - [https://www.youtube.com/watch?v=8vjJLJhRncc](https://www.youtube.com/watch?v=8vjJLJhRncc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T04:00:07+00:00

Watch the new trailer for the supernatural horror thriller from director Lindsey Anderson Beer, starring Henry Thomas, Samantha Mathis, David Duchovny, Jackson White, and Jack Mulhern. Screenplay is by Lindsey Anderson Beer and Jeff Buhler, based on the novel "Pet Sematary" by Stephen King. The film is also produced by Adam Bohling, Jason Fuchs, and David Reid. 

Pet Sematary Bloodlines is now streaming on Paramount+.

## This might be the best “easy mode” in a game ever. #gameplay #easy #anothercrabstreasure #soulslike
 - [https://www.youtube.com/watch?v=TJNRlghwq10](https://www.youtube.com/watch?v=TJNRlghwq10)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T00:53:32+00:00



## DC Universe Online - Official Justice League Dark Cursed Trailer
 - [https://www.youtube.com/watch?v=R9VXZSLQBjU](https://www.youtube.com/watch?v=R9VXZSLQBjU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCKy1dAqELo0zrOtPkf0eTMw
 - date published: 2023-10-06T00:00:10+00:00

DC Universe Online's latest episode, Justice League Dark Cursed, is available now on PC, PlayStation 4, and Xbox One, and coming later in October to Nintendo Switch. Watch the latest trailer for DC Universe Online to see what to expect with episode 46, which brings open-world missions, a solo, an alert, and a raid to the free-to-play MMO. This new episode will also feature DC characters including Batman, Wonder Woman, Zatanna, John Constantine, Deadman, Hecate, and more.

A powerful curse is burning through the world's most powerful magic users, escalating their powers to dangerously violent extremes! Hoping Batman can take on the hard work, John Constantine's transported his House of Mystery to overlook Gotham Cemetery, where he and it are now under attack. In Justice League Dark Cursed, players will join forces with Batman and members of the Justice League Dark to put an end to this threat to all magic.

#IGN #Gaming

