## The Age of Surveillance Capitalism - Wikipedia
 - [https://en.m.wikipedia.org/wiki/The_Age_of_Surveillance_Capitalism](https://en.m.wikipedia.org/wiki/The_Age_of_Surveillance_Capitalism)
 - RSS feed: https://en.m.wikipedia.org
 - date published: 2023-10-06T15:23:06+00:00

The Age of Surveillance Capitalism - Wikipedia

