# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Our Best Secret Shopper Yet
 - [https://www.youtube.com/watch?v=WMX9L68rpaI](https://www.youtube.com/watch?v=WMX9L68rpaI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-10-06T16:00:25+00:00

Linus leaks details about the new Monk-themed secret shopper. 

See Part one of the new secret shopper: https://www.youtube.com/watch?v=OskeOonpJZI 

Watch the full WAN Show: https://www.youtube.com/watch?v=yFujQ4xvi9o&amp;list=PL8mG-RkN2uTw7PhlnAr4pZZz2QubIbujH&amp;index=1

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

