# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Rosyjska broń jądrowa mogłaby zniknąć z Białorusi. Jest jeden warunek
 - [https://wydarzenia.interia.pl/zagranica/news-rosyjska-bron-jadrowa-moglaby-zniknac-z-bialorusi-jest-jeden,nId,7071899](https://wydarzenia.interia.pl/zagranica/news-rosyjska-bron-jadrowa-moglaby-zniknac-z-bialorusi-jest-jeden,nId,7071899)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T20:44:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosyjska-bron-jadrowa-moglaby-zniknac-z-bialorusi-jest-jeden,nId,7071899"><img align="left" alt="Rosyjska broń jądrowa mogłaby zniknąć z Białorusi. Jest jeden warunek" src="https://i.iplsc.com/rosyjska-bron-jadrowa-moglaby-zniknac-z-bialorusi-jest-jeden/000HRFTNBVHRGXFA-C321.jpg" /></a>Rosyjska broń jądrowa mogłaby zniknąć z terytorium Białorusi, gdyby USA i NATO całkowicie wycofały się ze swoim arsenałem z Europy - wynika ze słów członka rosyjskiego MSZ Konstantina Woroncowa. Dyplomata przyznał, że obecna sytuacja geopolityczna sprawia jednak, że rozmowa na ten temat jest całkowicie nierealistyczna. - Rosja nie wycofa broni nuklearnej z Białorusi, dopóki Stany Zjednoczone nie zabiorą swojej z Europy - stwierdził i dodał, że rosyjski arsenał rozmieszczony jest na terenie kraju Łukaszenki w zgodzie z obowiązującymi przepisami.</p><br clear="all" />

## Długotrwałe skutki infekcji nie tylko po COVID-19. Opublikowano wyniki badań
 - [https://wydarzenia.interia.pl/zagranica/news-dlugotrwale-skutki-infekcji-nie-tylko-po-covid-19-opublikowa,nId,7071906](https://wydarzenia.interia.pl/zagranica/news-dlugotrwale-skutki-infekcji-nie-tylko-po-covid-19-opublikowa,nId,7071906)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T20:36:46+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-dlugotrwale-skutki-infekcji-nie-tylko-po-covid-19-opublikowa,nId,7071906"><img align="left" alt="Długotrwałe skutki infekcji nie tylko po COVID-19. Opublikowano wyniki badań" src="https://i.iplsc.com/dlugotrwale-skutki-infekcji-nie-tylko-po-covid-19-opublikowa/000HRFWMT2U55A1A-C321.jpg" /></a>Naukowcy z Queen Mary University of London (QMUL) odkryli, że długotrwałe występowanie symptomów zdarza się nie tylko po przejściu COVID-19, ale także wielu innych infekcjach. Wyniki przeprowadzonych przez nich badań rzuciły nowe światło na kwestię skutków różnych infekcji dróg oddechowych, przy wykluczeniu koronawirusa. Niektóre z nich pokrywają się z tymi, których doświadczają osoby, które przeszły COVID-19.</p><br clear="all" />

## Nadleśnictwo opublikowało nagranie. Uprzedza: To nie skunks
 - [https://wydarzenia.interia.pl/podkarpackie/news-nadlesnictwo-opublikowalo-nagranie-uprzedza-to-nie-skunks,nId,7071897](https://wydarzenia.interia.pl/podkarpackie/news-nadlesnictwo-opublikowalo-nagranie-uprzedza-to-nie-skunks,nId,7071897)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T20:27:00+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-nadlesnictwo-opublikowalo-nagranie-uprzedza-to-nie-skunks,nId,7071897"><img align="left" alt="Nadleśnictwo opublikowało nagranie. Uprzedza: To nie skunks" src="https://i.iplsc.com/nadlesnictwo-opublikowalo-nagranie-uprzedza-to-nie-skunks/000HRFRJ4KITLIRE-C321.jpg" /></a>Nadleśnictwo Jarosław udostępniło nagranie z czarnym ssakiem, który szybko krąży wokół zbiornika wodnego. Przekazano, że to borsuk, dość często mylony jednak ze skunksem. Organizacja przypomniała też, by nie obawiać się, gdy zwierzę - z uwagi na słaby wzrok - może przypadkiem podejść dość blisko człowieka. </p><br clear="all" />

## Impreza na plebanii w Dąbrowie Górniczej. Akta trafią do Watykanu
 - [https://wydarzenia.interia.pl/slaskie/news-impreza-na-plebanii-w-dabrowie-gorniczej-akta-trafia-do-waty,nId,7071900](https://wydarzenia.interia.pl/slaskie/news-impreza-na-plebanii-w-dabrowie-gorniczej-akta-trafia-do-waty,nId,7071900)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T20:03:34+00:00

<p><a href="https://wydarzenia.interia.pl/slaskie/news-impreza-na-plebanii-w-dabrowie-gorniczej-akta-trafia-do-waty,nId,7071900"><img align="left" alt="Impreza na plebanii w Dąbrowie Górniczej. Akta trafią do Watykanu" src="https://i.iplsc.com/impreza-na-plebanii-w-dabrowie-gorniczej-akta-trafia-do-waty/000HRFSNMS5C9AMB-C321.jpg" /></a>&quot;Biskup Sosnowiecki zdecydował o wszczęciu procesu karnego, na mocy którego można zastosować wobec duchownego najcięższe kary kościelne, w tym wydalenie ze stanu duchownego&quot; - podano w komunikacie kurii diecezji sosnowieckiej. To pokłosie imprezy w mieszkaniu księdza na plebanii parafii w Dąbrowie Górniczej. Po zakończonej sprawie akta procesu trafią do Stolicy Apostolskiej. </p><br clear="all" />

## Ostrzał wsi Groza. Zginęła pracowniczka Polskiej Akcji Humanitarnej
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ostrzal-wsi-groza-zginela-pracowniczka-polskiej-akcji-humani,nId,7071872](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ostrzal-wsi-groza-zginela-pracowniczka-polskiej-akcji-humani,nId,7071872)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T19:39:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ostrzal-wsi-groza-zginela-pracowniczka-polskiej-akcji-humani,nId,7071872"><img align="left" alt="Ostrzał wsi Groza. Zginęła pracowniczka Polskiej Akcji Humanitarnej" src="https://i.iplsc.com/ostrzal-wsi-groza-zginela-pracowniczka-polskiej-akcji-humani/000HRFQMO5NS5C99-C321.jpg" /></a>Nie żyje wolontariuszka Polskiej Akcji Humanitarnej - przekazała organizacja na Facebooku. Kobieta zginęła podczas czwartkowego ostrzału wsi Groza w obwodzie charkowskim w Ukrainie. W ataku śmierć poniosło ponad 50 osób. </p><br clear="all" />

## Włamano się na pocztę rosyjskiego dowódcy. Dowody na udział w inwazji
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wlamano-sie-na-poczte-rosyjskiego-dowodcy-dowody-na-udzial-w,nId,7071875](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wlamano-sie-na-poczte-rosyjskiego-dowodcy-dowody-na-udzial-w,nId,7071875)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T19:22:37+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-wlamano-sie-na-poczte-rosyjskiego-dowodcy-dowody-na-udzial-w,nId,7071875"><img align="left" alt="Włamano się na pocztę rosyjskiego dowódcy. Dowody na udział w inwazji" src="https://i.iplsc.com/wlamano-sie-na-poczte-rosyjskiego-dowodcy-dowody-na-udzial-w/000HRFOBVLD4H30R-C321.jpg" /></a>Ukraińskim działaczom z KiberSprotyv udało się włamać na pocztę elektroniczną pułkownika Romana Erszowa - informuje Ukraińska Prawda. Znaleziono tam materiały, które są dowodami na udział w inwazji w Prypeci rosyjskich policyjnych oddziałów prewencji. Oprócz tego uzyskano dostęp do dokumentów analitycznych dotyczących broni, a także raportów.</p><br clear="all" />

## Polacy za granicą szturmem na wybory. Padł absolutny rekord
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-polacy-za-granica-szturmem-na-wybory-padl-absolutny-rekord,nId,7071862](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-polacy-za-granica-szturmem-na-wybory-padl-absolutny-rekord,nId,7071862)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T19:05:36+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-polacy-za-granica-szturmem-na-wybory-padl-absolutny-rekord,nId,7071862"><img align="left" alt="Polacy za granicą szturmem na wybory. Padł absolutny rekord" src="https://i.iplsc.com/polacy-za-granica-szturmem-na-wybory-padl-absolutny-rekord/000HRFKD4NYVIW1F-C321.jpg" /></a>Rekordowo dużo osób chce wziąć udział w wyborach parlamentarnych 15 października poza granicami Polski, o czym świadczą najnowsze dane. Do głosowania za granicą zarejestrowało się już ponad 350 tysięcy osób, a więc o niemal 40 tysięcy więcej niż w 2019 roku - wynika z informacji opublikowanych przez polskie MSZ. W przestrzeni medialnej mowa już nawet o 380 tysiącach. Rekordowo prezentuje się również liczba utworzonych obwodów głosowania (417) - ona też nigdy wcześniej nie była większa.</p><br clear="all" />

## Zdemolował muzeum w Izraelu. Powodem "bluźniercze posągi"
 - [https://wydarzenia.interia.pl/zagranica/news-zdemolowal-muzeum-w-izraelu-powodem-bluzniercze-posagi,nId,7071842](https://wydarzenia.interia.pl/zagranica/news-zdemolowal-muzeum-w-izraelu-powodem-bluzniercze-posagi,nId,7071842)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T18:29:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zdemolowal-muzeum-w-izraelu-powodem-bluzniercze-posagi,nId,7071842"><img align="left" alt="Zdemolował muzeum w Izraelu. Powodem &quot;bluźniercze posągi&quot; " src="https://i.iplsc.com/zdemolowal-muzeum-w-izraelu-powodem-bluzniercze-posagi/000HRFEH4PAAL4SO-C321.jpg" /></a>40-letni mężczyzna ze Stanów Zjednoczonych oglądał eksponaty w Muzeum Izraela w Jerozolimie, a następnie zrzucił dwa z nich. Turysta został zatrzymany przez policję, której miał tłumaczyć, że dokonał zniszczeń, bo uznał je za &quot;bluźniercze&quot; i &quot;naruszające Torę&quot;. Prawnik sprawcy tłumaczył z kolei, że jego klient doznał &quot;syndromu jerozolimskiego&quot;.</p><br clear="all" />

## Nie żyje Andrzej Koziara. Dziennikarz i fotograf miał 66 lat
 - [https://wydarzenia.interia.pl/kraj/news-nie-zyje-andrzej-koziara-dziennikarz-i-fotograf-mial-66-lat,nId,7071855](https://wydarzenia.interia.pl/kraj/news-nie-zyje-andrzej-koziara-dziennikarz-i-fotograf-mial-66-lat,nId,7071855)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T18:11:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nie-zyje-andrzej-koziara-dziennikarz-i-fotograf-mial-66-lat,nId,7071855"><img align="left" alt="Nie żyje Andrzej Koziara. Dziennikarz i fotograf miał 66 lat" src="https://i.iplsc.com/nie-zyje-andrzej-koziara-dziennikarz-i-fotograf-mial-66-lat/000HRFCYGP6RB9FB-C321.jpg" /></a>W w wieku 66 lat zmarł dziennikarz, filmowiec i fotograf Andrzej Koziara. Był korespondentem wojennym w Kaukazie i Jugosławii, pracował za granicą. W latach 1978-1981 związany z zespołem Bajm. </p><br clear="all" />

## Wykryli amerykański patrol. Rosjanie poderwali myśliwiec
 - [https://wydarzenia.interia.pl/zagranica/news-wykryli-amerykanski-patrol-rosjanie-poderwali-mysliwiec,nId,7071559](https://wydarzenia.interia.pl/zagranica/news-wykryli-amerykanski-patrol-rosjanie-poderwali-mysliwiec,nId,7071559)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T18:02:01+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wykryli-amerykanski-patrol-rosjanie-poderwali-mysliwiec,nId,7071559"><img align="left" alt="Wykryli amerykański patrol. Rosjanie poderwali myśliwiec" src="https://i.iplsc.com/wykryli-amerykanski-patrol-rosjanie-poderwali-mysliwiec/000HRDEUUEEV8HRC-C321.jpg" /></a>Na Morzu Norweskim wykryto w piątek amerykański samolot patrolowy, który zbliżał się do rosyjskiej granicy - informują Rosjanie i dodają, że &quot;w związku z tym poderwano myśliwiec MiG-31, by przechwycił i odeskortował maszynę obcego państwa&quot;. Przekazano również, że ostatecznie do naruszenia rosyjskiej przestrzeni powietrznej nie doszło, a całą operację przeprowadzono zgodnie z przepisami. Amerykanie nie skomentowali sprawy.</p><br clear="all" />

## Rosja planowała zamach stanu w Mołdawii. Władze ujawniają
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-moldawii-wladze-ujawniaja,nId,7071844](https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-moldawii-wladze-ujawniaja,nId,7071844)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T17:39:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-moldawii-wladze-ujawniaja,nId,7071844"><img align="left" alt="Rosja planowała zamach stanu w Mołdawii. Władze ujawniają" src="https://i.iplsc.com/rosja-planowala-zamach-stanu-w-moldawii-wladze-ujawniaja/000GBZT12BF5I7EF-C321.jpg" /></a>Jewgienij Prigożyn planował zamach stanu w Mołdawii na początku tego roku - przekazała prezydent Mołdawii Maia Sandu. Według niej Federacja Rosyjska miała przygotowany przez grupę pod wodzą &quot;kucharza Putina&quot; plan. Zgodnie z nim antyrządowe protesty miały przybrać &quot;brutalny&quot; charakter i doprowadzić do obalenia rządu i prezydenta.</p><br clear="all" />

## Rosja planowała zamach stanu w kraju NATO. Władze ujawniają
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-kraju-nato-wladze-ujawniaja,nId,7071844](https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-kraju-nato-wladze-ujawniaja,nId,7071844)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T17:39:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-planowala-zamach-stanu-w-kraju-nato-wladze-ujawniaja,nId,7071844"><img align="left" alt="Rosja planowała zamach stanu w kraju NATO. Władze ujawniają" src="https://i.iplsc.com/rosja-planowala-zamach-stanu-w-kraju-nato-wladze-ujawniaja/000GBZT12BF5I7EF-C321.jpg" /></a>Jewgienij Prigożyn planował zamach stanu w Mołdawii na początku tego roku - przekazała prezydent Mołdawii Maia Sandu. Według niej Federacja Rosyjska miała przygotowany przez grupę pod wodzą &quot;kucharza Putina&quot; plan. Zgodnie z nim antyrządowe protesty miały przybrać &quot;brutalny&quot; charakter i doprowadzić do obalenia rządu i prezydenta.</p><br clear="all" />

## Radny PiS zaatakowany. Poszło o banery wyborcze
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-radny-pis-zaatakowany-poszlo-o-banery-wyborcze,nId,7071835](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-radny-pis-zaatakowany-poszlo-o-banery-wyborcze,nId,7071835)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T17:11:56+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-radny-pis-zaatakowany-poszlo-o-banery-wyborcze,nId,7071835"><img align="left" alt="Radny PiS zaatakowany. Poszło o banery wyborcze" src="https://i.iplsc.com/radny-pis-zaatakowany-poszlo-o-banery-wyborcze/000GGSI23CHFQDOA-C321.jpg" /></a>Niebezpieczne zdarzenie przed wyborami parlamentarnymi. W Szczecinie zaatakowano Marcina Pawlickiego, przewodniczący klubu radnych PiS. Radny miał próbować przeszkodzić mężczyźnie w niszczeniu banerów wyborczych, wtedy sprawca miał się &quot;rzucić na niego z rękoma i uderzać&quot;. - Trwają czynności wyjaśniające w sprawie zniszczenia banerów oraz naruszenia nietykalności cielesnej - przekazała Interii oficer prasowa KMP w Szczecinie Anna Gembala.</p><br clear="all" />

## Viktor Orban wprost. "Bruksela legalnie zdeptała Polskę i Węgry"
 - [https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wprost-bruksela-legalnie-zdeptala-polske-i-wegr,nId,7071659](https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wprost-bruksela-legalnie-zdeptala-polske-i-wegr,nId,7071659)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T17:02:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-viktor-orban-wprost-bruksela-legalnie-zdeptala-polske-i-wegr,nId,7071659"><img align="left" alt="Viktor Orban wprost. &quot;Bruksela legalnie zdeptała Polskę i Węgry&quot;" src="https://i.iplsc.com/viktor-orban-wprost-bruksela-legalnie-zdeptala-polske-i-wegr/000HRF0W0S0KUKBT-C321.jpg" /></a>- Bruksela legalnie zdeptała Polskę i Węgry, forsując tzw. pakt migracyjny - przekazał na nagraniu w mediach społecznościowych premier Viktor Orban, odnosząc się do nacisków Komisji Europejskiej w kwestii rozwiązań migracyjnych. Szef węgierskiego rządu dodał, że &quot;ani dziś, ani w nadchodzących latach&quot; nie zamierza wykonywać poleceń &quot;brukselskich biurokratów&quot;. Jeszcze mocniejsze słowa padły we wpisie polityka.</p><br clear="all" />

## Zjedli makaron w japońskiej restauracji. Zatruło się prawie 900 osób
 - [https://wydarzenia.interia.pl/zagranica/news-zjedli-makaron-w-japonskiej-restauracji-zatrulo-sie-prawie-9,nId,7071726](https://wydarzenia.interia.pl/zagranica/news-zjedli-makaron-w-japonskiej-restauracji-zatrulo-sie-prawie-9,nId,7071726)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T16:48:08+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zjedli-makaron-w-japonskiej-restauracji-zatrulo-sie-prawie-9,nId,7071726"><img align="left" alt="Zjedli makaron w japońskiej restauracji. Zatruło się prawie 900 osób" src="https://i.iplsc.com/zjedli-makaron-w-japonskiej-restauracji-zatrulo-sie-prawie-9/000HREZHN3FU1LWR-C321.jpg" /></a>Niemal 900 osób doznało zatrucia pokarmowego po spożyciu posiłku w restauracji serwującej nagashi somen - czyli tzw. płynący makaron. Do masowego zatrucia doszło w mieście Tsubata w prefekturze Ishikawa w Japonii. Restauracja po wypłaceniu odszkodowań poszkodowanym klientom planuje zamknięcie działalności.</p><br clear="all" />

## Putin chwali się "przyjaciółmi" u sąsiada Polski
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-chwali-sie-przyjaciolmi-u-sasiada-polski,nId,7071619](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-chwali-sie-przyjaciolmi-u-sasiada-polski,nId,7071619)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T16:25:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-putin-chwali-sie-przyjaciolmi-u-sasiada-polski,nId,7071619"><img align="left" alt="Putin chwali się &quot;przyjaciółmi&quot; u sąsiada Polski" src="https://i.iplsc.com/putin-chwali-sie-przyjaciolmi-u-sasiada-polski/000HRELXK52T0KR9-C321.jpg" /></a>Władimir Putin zaapelował do Niemców i stwierdził, że &quot;powinni pamiętać, co Gerhard Schröder zrobił dla ich kraju&quot;. 79-letni były kanclerz - mimo zaostrzenia rosyjskiej inwazji na Ukrainę - nadal utrzymuje przyjaźń z przywódcą Rosji. Szef Kremla stwierdził w tym samym wystąpieniu, że liczba jego przyjaciół w Niemczech rośnie.</p><br clear="all" />

## Donald Tusk ostro o premierze i TVP. "Dwie fabryki kłamstw"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-ostro-o-premierze-i-tvp-dwie-fabryki-klamstw,nId,7071623](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-ostro-o-premierze-i-tvp-dwie-fabryki-klamstw,nId,7071623)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T15:45:59+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-donald-tusk-ostro-o-premierze-i-tvp-dwie-fabryki-klamstw,nId,7071623"><img align="left" alt="Donald Tusk ostro o premierze i TVP. &quot;Dwie fabryki kłamstw&quot;" src="https://i.iplsc.com/donald-tusk-ostro-o-premierze-i-tvp-dwie-fabryki-klamstw/000HREICHUSJ8L9K-C321.jpg" /></a>- Codziennie mam nowy materiał do tego ponurego serialu, co PiS zrobił złego - mówił Donald Tusk w Przemyślu, na spotkaniu przed wyborami parlamentarnymi. Lider KO wprost nazwał Kancelarię Premiera oraz Telewizję Polską &quot;fabrykami kłamstw&quot;, w których nie ma granic, do których trafia mnóstwo środków, bo &quot;to się im opłaca&quot;. Były premier mówił także o wolności mediów. - Każdy, kto sięga do prawdziwych źródeł informacji, już nie zagłosuje na partię PiS (...), ale to trzeba wiedzieć - komentował. - PiS może liczyć na głosy tych, których zniewolił...</p><br clear="all" />

## Emmanuel Macron szczerze o Polsce. "Przy stole przekazali sprzeciw"
 - [https://wydarzenia.interia.pl/zagranica/news-emmanuel-macron-szczerze-o-polsce-przy-stole-przekazali-sprz,nId,7071632](https://wydarzenia.interia.pl/zagranica/news-emmanuel-macron-szczerze-o-polsce-przy-stole-przekazali-sprz,nId,7071632)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T15:30:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-emmanuel-macron-szczerze-o-polsce-przy-stole-przekazali-sprz,nId,7071632"><img align="left" alt="Emmanuel Macron szczerze o Polsce. &quot;Przy stole przekazali sprzeciw&quot;" src="https://i.iplsc.com/emmanuel-macron-szczerze-o-polsce-przy-stole-przekazali-sprz/0007ZBF3JGLQU42V-C321.jpg" /></a>- Chociaż Polska i Węgry wyraziły swój sprzeciw wobec polityki migracyjnej Unii Europejskiej, nie musi to oznaczać, że ostateczne porozumienie w tej sprawie zostanie zablokowane - przekazał w piątek prezydent Francji Emmanuel Macron, cytowany przez agencję Reutera. Sam Mateusz Morawiecki na platformie X zamieścił oświadczenie, w którym stwierdził, że &quot;jako odpowiedzialny polityk oficjalnie odrzuca cały paragraf konkluzji szczytu dotyczący migracji. Polska jest i pozostanie bezpieczna pod rządami PiS!&quot; - napisał.</p><br clear="all" />

## "Kabriolet" na ulicach Słowacji. Brakowało więcej niż dachu
 - [https://wydarzenia.interia.pl/zagranica/news-kabriolet-na-ulicach-slowacji-brakowalo-wiecej-niz-dachu,nId,7071605](https://wydarzenia.interia.pl/zagranica/news-kabriolet-na-ulicach-slowacji-brakowalo-wiecej-niz-dachu,nId,7071605)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T15:12:05+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kabriolet-na-ulicach-slowacji-brakowalo-wiecej-niz-dachu,nId,7071605"><img align="left" alt="&quot;Kabriolet&quot; na ulicach Słowacji. Brakowało więcej niż dachu" src="https://i.iplsc.com/kabriolet-na-ulicach-slowacji-brakowalo-wiecej-niz-dachu/000HREJVLAK3PBE3-C321.jpg" /></a>Na Słowacji doszło do nietypowej kontroli drogowej. Policjanci zatrzymali 25-latka, który przekroczył prędkość. Szybko okazało się, że to nie był jedyny problem kierowcy. Mężczyzna podróżował specyficznym &quot;kabrioletem&quot; - oprócz dachu brakowało również drzwi, szyb, maski czy tablic rejestracyjnych. W sieci pojawiło się sporo komentarzy, w których użytkownicy nie powstrzymują się od żartów.</p><br clear="all" />

## Weto premiera w sprawie migracji. Przedstawił pięciopunktowy plan
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-weto-premiera-w-sprawie-migracji-przedstawil-pieciopunktowy-,nId,7071644](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-weto-premiera-w-sprawie-migracji-przedstawil-pieciopunktowy-,nId,7071644)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T15:03:17+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-weto-premiera-w-sprawie-migracji-przedstawil-pieciopunktowy-,nId,7071644"><img align="left" alt="Weto premiera w sprawie migracji. Przedstawił pięciopunktowy plan" src="https://i.iplsc.com/weto-premiera-w-sprawie-migracji-przedstawil-pieciopunktowy/000HREMGOWITP0VH-C321.jpg" /></a>- Podjąłem decyzję o zawetowaniu części dotyczącej migracji. Nie ma tego zapisu w konkluzji szczytu UE - oświadczył premier Mateusz Morawiecki podczas konferencji prasowej w Grenadzie. Szef rządu przedstawił także pięciopunktowy plan, który zawiera m.in. ochronę granic zewnętrznych.</p><br clear="all" />

## MSZ reaguje po skandalu w Holandii. Wezwą ambasador
 - [https://wydarzenia.interia.pl/kraj/news-msz-reaguje-po-skandalu-w-holandii-wezwa-ambasador,nId,7071636](https://wydarzenia.interia.pl/kraj/news-msz-reaguje-po-skandalu-w-holandii-wezwa-ambasador,nId,7071636)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T14:54:15+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-msz-reaguje-po-skandalu-w-holandii-wezwa-ambasador,nId,7071636"><img align="left" alt="MSZ reaguje po skandalu w Holandii. Wezwą ambasador" src="https://i.iplsc.com/msz-reaguje-po-skandalu-w-holandii-wezwa-ambasador/000HREMV3H6HTSI6-C321.jpg" /></a>Jest reakcja polskiego rządu po skandalu, jaki miał miejsce po meczu między Legią Warszawa a drużyną z Alkmaar. &quot;W związku z wiarygodnymi, bardzo niepokojącymi informacjami o dyskryminacyjnych działaniach holenderskich służb wobec obywateli RP m.in. na terenie miasta Alkmaar, do MSZ została na sobotę wezwana Ambasador Królestwa Niderlandów&quot; - przekazał wiceszef MSZ Paweł Jabłoński.</p><br clear="all" />

## Pokazała "porcelanowego grzyba". Może pomóc w chorobach skóry
 - [https://wydarzenia.interia.pl/kraj/news-pokazala-porcelanowego-grzyba-moze-pomoc-w-chorobach-skory,nId,7071479](https://wydarzenia.interia.pl/kraj/news-pokazala-porcelanowego-grzyba-moze-pomoc-w-chorobach-skory,nId,7071479)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T14:21:35+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pokazala-porcelanowego-grzyba-moze-pomoc-w-chorobach-skory,nId,7071479"><img align="left" alt="Pokazała &quot;porcelanowego grzyba&quot;. Może pomóc w chorobach skóry" src="https://i.iplsc.com/pokazala-porcelanowego-grzyba-moze-pomoc-w-chorobach-skory/000HRCXUOF0T2U40-C321.jpg" /></a>To jeden z najpiękniejszych grzybów spotykanych na terenie Karkonoskiego Parku Narodowego. Autorka strony &quot;Leśne wojaże&quot; na Facebooku pokazała użytkownikom &quot;porcelanowego grzyba&quot;, który rośnie na drzewie. Ten wyjątkowy okaz to monetka bukowa. Ma on zastosowanie w leczeniu chorób skóry. </p><br clear="all" />

## Alaksandr Łukaszenka straszy Ukraińców. Wskazuje na plany Polaków
 - [https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-straszy-ukraincow-wskazuje-na-plany-pol,nId,7071553](https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-straszy-ukraincow-wskazuje-na-plany-pol,nId,7071553)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T14:16:51+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-alaksandr-lukaszenka-straszy-ukraincow-wskazuje-na-plany-pol,nId,7071553"><img align="left" alt="Alaksandr Łukaszenka straszy Ukraińców. Wskazuje na plany Polaków" src="https://i.iplsc.com/alaksandr-lukaszenka-straszy-ukraincow-wskazuje-na-plany-pol/000HRDEMBAKY71LY-C321.jpg" /></a>- Jeszcze raz mówię: trzeba przestać, bo będzie coraz gorzej. Widzicie, że Polacy są już gotowi do zajęcia zachodniej Ukrainy - mówił Alaksandr Łukaszenka. Białoruski dyktator kolejny raz, zgodnie z narracją Kremla, straszył obywateli Ukrainy atakiem ze strony Polski.</p><br clear="all" />

## Pandora Gate. Komentował aferę, nagle wyciągnięto mu skandaliczne nagranie. Teraz przeprasza
 - [https://wydarzenia.interia.pl/kraj/news-pandora-gate-komentowal-afere-nagle-wyciagnieto-mu-skandalic,nId,7071514](https://wydarzenia.interia.pl/kraj/news-pandora-gate-komentowal-afere-nagle-wyciagnieto-mu-skandalic,nId,7071514)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T14:03:37+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pandora-gate-komentowal-afere-nagle-wyciagnieto-mu-skandalic,nId,7071514"><img align="left" alt="Pandora Gate. Komentował aferę, nagle wyciągnięto mu skandaliczne nagranie. Teraz przeprasza " src="https://i.iplsc.com/pandora-gate-komentowal-afere-nagle-wyciagnieto-mu-skandalic/000HRDF3GNYUFKK7-C321.jpg" /></a>Ciąg dalszy afery zwanej Pandora Gate. Człowiek Warga, popularny youtuber, pojawił się w piątek w roli eksperta w radiu RMF FM, w którym komentował skandale dotyczące internetowych twórców. Parę godzin później okazało się, że on sam w przeszłości dopuszczał się skandalicznych żartów wobec nastolatek. Audycja z jego udziałem zniknęła z sieci. Sam Warga wydał oświadczenie, w którym przeprosił za &quot;wybryk&quot; sprzed dziewięciu lat.</p><br clear="all" />

## Rozprawa Sądu Najwyższego ws. referendum. Wydano wyrok
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-rozprawa-sadu-najwyzszego-ws-referendum-wydano-wyrok,nId,7068818](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-rozprawa-sadu-najwyzszego-ws-referendum-wydano-wyrok,nId,7068818)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:40:35+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-rozprawa-sadu-najwyzszego-ws-referendum-wydano-wyrok,nId,7068818"><img align="left" alt="Rozprawa Sądu Najwyższego ws. referendum. Wydano wyrok" src="https://i.iplsc.com/rozprawa-sadu-najwyzszego-ws-referendum-wydano-wyrok/000G6143VEDPG6HY-C321.jpg" /></a>Skarga Trzeciej Drogi na uchwałę PKW, która zobowiązuje członków obwodowych komisji do załączenia adnotacji w przypadku odmowy odbioru karty referendalnej, została oddalona. &quot;Odmowa odebrania którejkolwiek karty do głosowania w wyborach do Sejmu i do Senatu lub w referendum ogólnokrajowym musi być odnotowywana w spisie wyborców, gdyż tylko to pozwoli prawidłowo rozliczyć się przez obwodową komisję wyborczą z liczby otrzymanych kart do głosowania&quot; - wynika z wyroku Sądu Najwyższego w sprawie referendum, odbywającego się w ten sam dzień, co...</p><br clear="all" />

## Kupili go od kobiet z Melitopola. 11 Rosjan nie żyje
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kupili-go-od-kobiet-z-melitopola-11-rosjan-nie-zyje,nId,7071504](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kupili-go-od-kobiet-z-melitopola-11-rosjan-nie-zyje,nId,7071504)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:37:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-kupili-go-od-kobiet-z-melitopola-11-rosjan-nie-zyje,nId,7071504"><img align="left" alt="Kupili go od kobiet z Melitopola. 11 Rosjan nie żyje" src="https://i.iplsc.com/kupili-go-od-kobiet-z-melitopola-11-rosjan-nie-zyje/000HRE43F6OWK4TR-C321.jpg" /></a>11 rosyjskich żołnierzy, służących w Ukrainie, zmarło po spożyciu samogonu, który kupili od kobiet z Melitopola. Początkowo sądzono, że alkohol był złej jakości, jednak w rzeczywistości dodano do niego &quot;kilka trutek&quot;. Funkcjonariusze próbowali odnaleźć nieznane kobiety, jednak te zniknęły i nie udało się ustalić, gdzie przebywają. Rosjanie podejrzewają, że doszło do kolejnego sabotażu.</p><br clear="all" />

## PiS szykuje dużą zmianę w szkołach. "Za przykład może posłużyć Finlandia"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pis-szykuje-duza-zmiane-w-szkolach-za-przyklad-moze-posluzyc,nId,7071417](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pis-szykuje-duza-zmiane-w-szkolach-za-przyklad-moze-posluzyc,nId,7071417)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:26:44+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-pis-szykuje-duza-zmiane-w-szkolach-za-przyklad-moze-posluzyc,nId,7071417"><img align="left" alt="PiS szykuje dużą zmianę w szkołach. &quot;Za przykład może posłużyć Finlandia&quot;" src="https://i.iplsc.com/pis-szykuje-duza-zmiane-w-szkolach-za-przyklad-moze-posluzyc/000HRD3F8IW2IGP8-C321.jpg" /></a>Prawo i Sprawiedliwość wypowiada wojnę... korepetycjom. Politycy tej partii w swoim programie wyborczym chcą dodatkowych zajęć w szkołach, na których uczniowie mieliby uzupełniać swoje braki. Rodzice, nauczyciele, a nawet korepetytor, z którym rozmawiamy, są &quot;za&quot; i sami przyznają: rynek korepetycji jest patologiczny. Jednak w ich ocenie ten rośnie przez reformy PiS, a walka z tym zjawiskiem powinna wyglądać zupełnie inaczej. </p><br clear="all" />

## Potężny karambol w kierunku Poznania. Utrudnienia, w akcji LPR
 - [https://wydarzenia.interia.pl/wielkopolskie/news-potezny-karambol-w-kierunku-poznania-utrudnienia-w-akcji-lpr,nId,7071529](https://wydarzenia.interia.pl/wielkopolskie/news-potezny-karambol-w-kierunku-poznania-utrudnienia-w-akcji-lpr,nId,7071529)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:21:55+00:00

<p><a href="https://wydarzenia.interia.pl/wielkopolskie/news-potezny-karambol-w-kierunku-poznania-utrudnienia-w-akcji-lpr,nId,7071529"><img align="left" alt="Potężny karambol w kierunku Poznania. Utrudnienia, w akcji LPR" src="https://i.iplsc.com/potezny-karambol-w-kierunku-poznania-utrudnienia-w-akcji-lpr/000HRDBSON9BR0M7-C321.jpg" /></a>Dwie osoby zostały ranne w karambolu na S5 między węzłami Kościan Południe i Kościan Północ. Ciężarówka najechała na busa, który z kolei najechał na tył innego samochodu ciężarowego. W zdarzeniu brały udział również dwie osobówki. Utrudnienia na trasie w kierunku Poznania mogą potrwać kilka godzin.</p><br clear="all" />

## Mocne słowa na inauguracji roku akademickiego SGGW. Niektórzy wyszli z sali
 - [https://wydarzenia.interia.pl/kraj/news-mocne-slowa-na-inauguracji-roku-akademickiego-sggw-niektorzy,nId,7071488](https://wydarzenia.interia.pl/kraj/news-mocne-slowa-na-inauguracji-roku-akademickiego-sggw-niektorzy,nId,7071488)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:15:41+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-mocne-slowa-na-inauguracji-roku-akademickiego-sggw-niektorzy,nId,7071488"><img align="left" alt="Mocne słowa na inauguracji roku akademickiego SGGW. Niektórzy wyszli z sali" src="https://i.iplsc.com/mocne-slowa-na-inauguracji-roku-akademickiego-sggw-niektorzy/000HRD14L05RDM3H-C321.jpg" /></a>- Polską rządzą dzisiaj demagodzy. Tylko zakompleksieni, prymitywni, kontrolujący machinerię presji politycy, zamiast podjąć poważną dyskusję z suwerenem, ucinają wszelki dialog, którego boją się jak ognia i obrzucają przeciwnika inwektywami. Brzmi jak powtórka z 1968 roku - mówił prof. Andrzej Krakowski podczas inauguracji roku akademickiego w Szkole Głównej Gospodarstwa Wiejskiego (SGGW) w Warszawie. - Będę okrutny. Nie łudźcie się. Nie żyjecie w demokracji. Żyjecie w innej wersji PRL-u - dodał. W trakcie jego wystąpienia część...</p><br clear="all" />

## Wybuch w pobliżu Mińska. Fala uderzeniowa odczuwana w promieniu ośmiu kilometrów
 - [https://wydarzenia.interia.pl/zagranica/news-wybuch-w-poblizu-minska-fala-uderzeniowa-odczuwana-w-promien,nId,7071494](https://wydarzenia.interia.pl/zagranica/news-wybuch-w-poblizu-minska-fala-uderzeniowa-odczuwana-w-promien,nId,7071494)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T13:06:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wybuch-w-poblizu-minska-fala-uderzeniowa-odczuwana-w-promien,nId,7071494"><img align="left" alt="Wybuch w pobliżu Mińska. Fala uderzeniowa odczuwana w promieniu ośmiu kilometrów " src="https://i.iplsc.com/wybuch-w-poblizu-minska-fala-uderzeniowa-odczuwana-w-promien/000HRD3E16TLK2LV-C321.jpg" /></a>W nocy z czwartku na piątek doszło do potężnego wybuchu w rejonie torów kolejowych w miejscowości Ozeriszcze niedaleko Mińska na Białorusi. Według relacji świadków, pracujący na miejscu śledzczy mówią o możliwym ataku terrorystycznym. Miejscem wybuchu jest stacja, która okresowo służy do załadunku sprzętu wojskowego. </p><br clear="all" />

## Prawomocny wyrok przed wyborami. Europoseł PiS starł się z posłanką KO
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-prawomocny-wyrok-przed-wyborami-europosel-pis-starl-sie-z-po,nId,7071460](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-prawomocny-wyrok-przed-wyborami-europosel-pis-starl-sie-z-po,nId,7071460)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T12:57:12+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-prawomocny-wyrok-przed-wyborami-europosel-pis-starl-sie-z-po,nId,7071460"><img align="left" alt="Prawomocny wyrok przed wyborami. Europoseł PiS starł się z posłanką KO" src="https://i.iplsc.com/prawomocny-wyrok-przed-wyborami-europosel-pis-starl-sie-z-po/000HRD356LJY61M3-C321.jpg" /></a>Kolejny wyrok sądu przed wyborami parlamentarnymi. Patryk Jaki musi przeprosić posłankę Agnieszkę Pomaską - orzekł Sąd Apelacyjny w Gdańsku, który podtrzymał decyzję Sądu Okręgowego. Europarlamentarzysta Suwerennej Polski złożył zażalenie, jednak II instancja oddaliła jego wniosek. Spór dotyczy zdjęcia posłanki, stojącej obok samochodu z wulgarnym napisem. Jaki nazwał decyzję &quot;absurdem&quot;, który &quot;ośmiesza sędziów&quot;.</p><br clear="all" />

## Groźny żeglarz dopłynął do Walii. Mieszkańcy ostrzeżeni
 - [https://wydarzenia.interia.pl/zagranica/news-grozny-zeglarz-doplynal-do-walii-mieszkancy-ostrzezeni,nId,7071510](https://wydarzenia.interia.pl/zagranica/news-grozny-zeglarz-doplynal-do-walii-mieszkancy-ostrzezeni,nId,7071510)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T12:54:42+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-grozny-zeglarz-doplynal-do-walii-mieszkancy-ostrzezeni,nId,7071510"><img align="left" alt="Groźny żeglarz dopłynął do Walii. Mieszkańcy ostrzeżeni" src="https://i.iplsc.com/grozny-zeglarz-doplynal-do-walii-mieszkancy-ostrzezeni/000HRD6YPWD7VTJ6-C321.jpg" /></a>Ma piękne kolory i wygląda łagodnie, jednak dotknięcie go może być śmiertelnie niebezpieczne. Na jednej z plaż w Walii znaleziono wyrzuconego z morza żeglarza portugalskiego. Miejscowe władze ostrzegają, by nie zbliżać się do tego wyjątkowo groźnego stworzenia. Coraz częściej na te ciepłolubne zwierzęta można się natknąć dalej od równika. Powodem jest wzrost temperatur na całym świecie.</p><br clear="all" />

## Otworzyli bagaż turystki i nie dowierzali. Dziwaczna "pamiątka" z Kenii
 - [https://wydarzenia.interia.pl/zagranica/news-otworzyli-bagaz-turystki-i-nie-dowierzali-dziwaczna-pamiatka,nId,7071415](https://wydarzenia.interia.pl/zagranica/news-otworzyli-bagaz-turystki-i-nie-dowierzali-dziwaczna-pamiatka,nId,7071415)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:54:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-otworzyli-bagaz-turystki-i-nie-dowierzali-dziwaczna-pamiatka,nId,7071415"><img align="left" alt="Otworzyli bagaż turystki i nie dowierzali. Dziwaczna &quot;pamiątka&quot; z Kenii " src="https://i.iplsc.com/otworzyli-bagaz-turystki-i-nie-dowierzali-dziwaczna-pamiatka/000HRCIPQXK2HC9B-C321.jpg" /></a>To było absolutnie zaskakujące odkrycie nawet dla doświadczonych celników pracujących na międzynarodowym lotnisku w Minneapolis. Turystka tłumaczyła się jednak, dlaczego przewozi zakazane &quot;pamiątki&quot; z wakacji, czym jeszcze bardziej zadziwiła służby. </p><br clear="all" />

## Wzywają do bojkotu. Oburzenie po nagraniu Amnesty International
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wzywaja-do-bojkotu-oburzenie-po-nagraniu-amnesty-internation,nId,7071164](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wzywaja-do-bojkotu-oburzenie-po-nagraniu-amnesty-internation,nId,7071164)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:36:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wzywaja-do-bojkotu-oburzenie-po-nagraniu-amnesty-internation,nId,7071164"><img align="left" alt="Wzywają do bojkotu. Oburzenie po nagraniu Amnesty International " src="https://i.iplsc.com/wzywaja-do-bojkotu-oburzenie-po-nagraniu-amnesty-internation/000HRCDDTUREMYXV-C321.jpg" /></a>Nie daj sobie wcisnąć referendum - brzmi najnowsza kampania Amnesty International Polska. W opublikowanym spocie organizacja zachęca, by 15 października nie pobierać karty do głosowania w referendum. W sieci zawrzało - pojawiły się zarzuty o promowanie antydemokratycznych postaw. - Nie negujemy referendum jako narzędzia demokracji. Mamy obawy co do tego konkretnego referendum i dwóch zawartych w nich pytań - mówi Interii rzeczniczka polskiego Amnesty.</p><br clear="all" />

## Uciekł z auta, w którym zginęli jego znajomi. Nie wiadomo, kto prowadził
 - [https://wydarzenia.interia.pl/warminsko-mazurskie/news-uciekl-z-auta-w-ktorym-zgineli-jego-znajomi-nie-wiadomo-kto-,nId,7071163](https://wydarzenia.interia.pl/warminsko-mazurskie/news-uciekl-z-auta-w-ktorym-zgineli-jego-znajomi-nie-wiadomo-kto-,nId,7071163)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:28:59+00:00

<p><a href="https://wydarzenia.interia.pl/warminsko-mazurskie/news-uciekl-z-auta-w-ktorym-zgineli-jego-znajomi-nie-wiadomo-kto-,nId,7071163"><img align="left" alt="Uciekł z auta, w którym zginęli jego znajomi. Nie wiadomo, kto prowadził" src="https://i.iplsc.com/uciekl-z-auta-w-ktorym-zgineli-jego-znajomi-nie-wiadomo-kto/000HRCCOR8TFN05M-C321.jpg" /></a>22-latek i 17-latka zginęli w wypadku w miejscowości Sawica w województwie warmińsko-mazurskim. Auto, którym jechali uderzyło w drzewo. W pojeździe podróżowały łącznie cztery osoby - dwie z nich zginęły. Policja wyjaśnia przyczyny zdarzenia. Trwa także ustalanie, kto kierował pojazdem. - Po przybyciu służb na miejsce wszystkie osoby znajdowały się poza pojazdem - przekazała Interii sierżant Agata Stefaniak z policji w Szczytnie.</p><br clear="all" />

## "Gazeta Polska" w pociągach? Kolej odpowiada tajemniczo
 - [https://wydarzenia.interia.pl/raport-transport-publiczny/news-gazeta-polska-w-pociagach-kolej-odpowiada-tajemniczo,nId,7071158](https://wydarzenia.interia.pl/raport-transport-publiczny/news-gazeta-polska-w-pociagach-kolej-odpowiada-tajemniczo,nId,7071158)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:17:27+00:00

<p><a href="https://wydarzenia.interia.pl/raport-transport-publiczny/news-gazeta-polska-w-pociagach-kolej-odpowiada-tajemniczo,nId,7071158"><img align="left" alt="&quot;Gazeta Polska&quot; w pociągach? Kolej odpowiada tajemniczo" src="https://i.iplsc.com/gazeta-polska-w-pociagach-kolej-odpowiada-tajemniczo/000HRCD3PJLE6OYR-C321.jpg" /></a>13 października, dwa dni przed wyborami do Sejmu i Senatu, w pociągach Polregio mają znaleźć się egzemplarze &quot;Gazety Polskiej&quot; Tomasza Sakiewicza - wynika z nieoficjalnych informacji. Decyzję miał podjąć szef spółki Adam Pawlik. Interia skontaktowała się z przedstawicielami przewoźnika. Jego rzeczniczka zapewniła, że żadnej umowy z &quot;Gazetą Polską&quot; nie ma, ale teraz - pozostawiając furtkę. Inny stwierdził, że nie zna sprawy, a kolejny - iż nikt nie powiadomił go o prasowo-kolejowej inicjatywie.</p><br clear="all" />

## Cierpi na nietypową fobię. "Ludzie się ze mnie śmieją"
 - [https://wydarzenia.interia.pl/zagranica/news-cierpi-na-nietypowa-fobie-ludzie-sie-ze-mnie-smieja,nId,7071123](https://wydarzenia.interia.pl/zagranica/news-cierpi-na-nietypowa-fobie-ludzie-sie-ze-mnie-smieja,nId,7071123)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:07:22+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-cierpi-na-nietypowa-fobie-ludzie-sie-ze-mnie-smieja,nId,7071123"><img align="left" alt="Cierpi na nietypową fobię. &quot;Ludzie się ze mnie śmieją&quot; " src="https://i.iplsc.com/cierpi-na-nietypowa-fobie-ludzie-sie-ze-mnie-smieja/000HRC8DQQKMF91F-C321.jpg" /></a>Filmy na TikToku to nie zawsze prosta rozrywka. Czasem internauci mogą natknąć się na wyjątkowe, ludzkie historie. Takim przykładem jest 34-latek John Junior.</p><br clear="all" />

## Zamieszanie wyborcze w Holandii. Zaniepokojeni Polacy dostają kolejne maile
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zamieszanie-wyborcze-w-holandii-zaniepokojeni-polacy-dostaja,nId,7071054](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zamieszanie-wyborcze-w-holandii-zaniepokojeni-polacy-dostaja,nId,7071054)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T11:01:17+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-zamieszanie-wyborcze-w-holandii-zaniepokojeni-polacy-dostaja,nId,7071054"><img align="left" alt="Zamieszanie wyborcze w Holandii. Zaniepokojeni Polacy dostają kolejne maile" src="https://i.iplsc.com/zamieszanie-wyborcze-w-holandii-zaniepokojeni-polacy-dostaja/000HRC464O013DKS-C321.jpg" /></a>Ambasada RP w Hadze zasugerowała, by Polki i Polacy przepisali się do obwodowych komisji wyborczych w innych krajach, gdzie zainteresowanie wyborami jest mniejsze. Szybko jednak wycofano się z tego pomysłu, proponując wyborcom kolejną alternatywę. Ci zaś nie kryją zaniepokojenia, czytając kolejne maile z ambasady.</p><br clear="all" />

## Atak na biuro senatora Kwiatkowskiego. "Wyciągnął nóż"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-kwiatkowskiego-wyciagnal-noz,nId,7071387](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-kwiatkowskiego-wyciagnal-noz,nId,7071387)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T10:54:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-atak-na-biuro-senatora-kwiatkowskiego-wyciagnal-noz,nId,7071387"><img align="left" alt="Atak na biuro senatora Kwiatkowskiego. &quot;Wyciągnął nóż&quot;" src="https://i.iplsc.com/atak-na-biuro-senatora-kwiatkowskiego-wyciagnal-noz/000HRCDCKX2F0PN3-C321.jpg" /></a>Nieznany mężczyzna z nożem w ręku wtargnął do biura senatora Krzysztofa Kwiatkowskiego. Napastnik groził współpracowniczce polityka.</p><br clear="all" />

## Wybory 2023: Polacy pobiją rekord? Cztery lata temu frekwencja zaskoczyła
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/poradnik/news-wybory-2023-polacy-pobija-rekord-cztery-lata-temu-frekwencja,nId,7069058](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/poradnik/news-wybory-2023-polacy-pobija-rekord-cztery-lata-temu-frekwencja,nId,7069058)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T10:37:55+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/poradnik/news-wybory-2023-polacy-pobija-rekord-cztery-lata-temu-frekwencja,nId,7069058"><img align="left" alt="Wybory 2023: Polacy pobiją rekord? Cztery lata temu frekwencja zaskoczyła " src="https://i.iplsc.com/wybory-2023-polacy-pobija-rekord-cztery-lata-temu-frekwencja/000G9XEZ1KR8TI0I-C321.jpg" /></a>Wybory 2023 odbędą się 15 października. Zgodnie z konstytucją wybory parlamentarne odbywają się w Polsce co cztery lata. Wyjątkiem są wybory przedterminowe lub przedłużenie kadencji z uwagi na stan nadzwyczajny. Poprzednie mieliśmy 13 października 2019 roku. Kto je wygrał i jak rozłożyły się głosy? Przypominamy wyniki oraz frekwencję poprzedniej batalii. </p><br clear="all" />

## Tragiczny wypadek na Pomorzu. Z bmw nic nie zostało
 - [https://wydarzenia.interia.pl/pomorskie/news-tragiczny-wypadek-na-pomorzu-z-bmw-nic-nie-zostalo,nId,7071103](https://wydarzenia.interia.pl/pomorskie/news-tragiczny-wypadek-na-pomorzu-z-bmw-nic-nie-zostalo,nId,7071103)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T10:15:24+00:00

<p><a href="https://wydarzenia.interia.pl/pomorskie/news-tragiczny-wypadek-na-pomorzu-z-bmw-nic-nie-zostalo,nId,7071103"><img align="left" alt="Tragiczny wypadek na Pomorzu. Z bmw nic nie zostało" src="https://i.iplsc.com/tragiczny-wypadek-na-pomorzu-z-bmw-nic-nie-zostalo/000HRC2D74WCXPRQ-C321.jpg" /></a>20-letni kierowca bmw i 19-letni pasażer zginęli w wypadku w miejscowości Graniczna Wieś na Pomorzu. Według wstępnych ustaleń policji, kierowca stracił panowanie nad autem, zjechał na pobocze i uderzył w drzewo. Podczas zdarzenia ranny został drugi z pasażerów. Auto zostało doszczętnie zniszczone.</p><br clear="all" />

## Kolejne problemy Elona Muska. SEC zastawia sidła na miliardera
 - [https://wydarzenia.interia.pl/zagranica/news-kolejne-problemy-elona-muska-sec-zastawia-sidla-na-miliarder,nId,7071049](https://wydarzenia.interia.pl/zagranica/news-kolejne-problemy-elona-muska-sec-zastawia-sidla-na-miliarder,nId,7071049)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:56:41+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kolejne-problemy-elona-muska-sec-zastawia-sidla-na-miliarder,nId,7071049"><img align="left" alt="Kolejne problemy Elona Muska. SEC zastawia sidła na miliardera " src="https://i.iplsc.com/kolejne-problemy-elona-muska-sec-zastawia-sidla-na-miliarder/000HNL53PDM4N03E-C321.jpg" /></a>Amerykańska Komisja Papierów Wartościowych i Giełd (SEC) chce zmusić Elona Muska do złożenia zeznań finansowych. W sprawie chodzi o zeszłoroczny zakup Twittera za kwotę blisko 44 miliardów dolarów.</p><br clear="all" />

## Nowy członek Unii Europejskiej na horyzoncie. Nie chodzi o Ukrainę
 - [https://wydarzenia.interia.pl/zagranica/news-nowy-czlonek-unii-europejskiej-na-horyzoncie-nie-chodzi-o-uk,nId,7071066](https://wydarzenia.interia.pl/zagranica/news-nowy-czlonek-unii-europejskiej-na-horyzoncie-nie-chodzi-o-uk,nId,7071066)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:46:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowy-czlonek-unii-europejskiej-na-horyzoncie-nie-chodzi-o-uk,nId,7071066"><img align="left" alt="Nowy członek Unii Europejskiej na horyzoncie. Nie chodzi o Ukrainę" src="https://i.iplsc.com/nowy-czlonek-unii-europejskiej-na-horyzoncie-nie-chodzi-o-uk/000HRBUOH8OPHCBI-C321.jpg" /></a>Unia Europejska jest na kursie zmierzającym do rozszerzenia wspólnoty. Jak zdecydowali eurodeputowani w Strasburgu, Bruksela musi rozpocząć rozmowy akcesyjne z Mołdawią jeszcze przed końcem tego roku. Kiszyniów jest w trakcie gruntownych reform, spełniając tym samym warunki nałożone przez Komisję Europejską. Europarlament wzywa do kontynuowania prac nad położeniem kresu oligarchizacji, reformą zarządzania finansami publicznymi i zwalczaniem przestępczości zorganizowanej.</p><br clear="all" />

## Otwarte karty przed debatą w TVP. Nie tylko premier
 - [https://wydarzenia.interia.pl/kraj/news-otwarte-karty-przed-debata-w-tvp-nie-tylko-premier,nId,7071083](https://wydarzenia.interia.pl/kraj/news-otwarte-karty-przed-debata-w-tvp-nie-tylko-premier,nId,7071083)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:30:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-otwarte-karty-przed-debata-w-tvp-nie-tylko-premier,nId,7071083"><img align="left" alt="Otwarte karty przed debatą w TVP. Nie tylko premier" src="https://i.iplsc.com/otwarte-karty-przed-debata-w-tvp-nie-tylko-premier/000HRCE9U2TXAM8B-C321.jpg" /></a>Nie mogę się doczekać! Widzimy się w polskiej telewizji! - napisał premier Mateusz Morawiecki w mediach społecznościowych. Oznacza to, że szef rządu weźmie udział w debacie, którą 9 października zorganizuje telewizja publiczna. Swój udział w dyskusji zapowiedział lider PO Donald Tusk oraz szef PSL Władysław Kosiniak-Kamysz. Z kolei Lewicę reprezentowała będzie Joanna Scheuring-Wielgus.</p><br clear="all" />

## Premier zdecydował. Weźmie udział w debacie wyborczej w TVP
 - [https://wydarzenia.interia.pl/kraj/news-premier-zdecydowal-wezmie-udzial-w-debacie-wyborczej-w-tvp,nId,7071083](https://wydarzenia.interia.pl/kraj/news-premier-zdecydowal-wezmie-udzial-w-debacie-wyborczej-w-tvp,nId,7071083)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:30:39+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-zdecydowal-wezmie-udzial-w-debacie-wyborczej-w-tvp,nId,7071083"><img align="left" alt="Premier zdecydował. Weźmie udział w debacie wyborczej w TVP" src="https://i.iplsc.com/premier-zdecydowal-wezmie-udzial-w-debacie-wyborczej-w-tvp/000FZ899M2IC99HN-C321.jpg" /></a>Nie mogę się doczekać! Widzimy się w polskiej telewizji! - napisał premier Mateusz Morawiecki w mediach społecznościowych. </p><br clear="all" />

## "Zatrważające" wyniki kontroli NIK w TVP. Stanowcza wypowiedź Mariana Banasia
 - [https://wydarzenia.interia.pl/kraj/news-zatrwazajace-wyniki-kontroli-nik-w-tvp-stanowcza-wypowiedz-m,nId,7070980](https://wydarzenia.interia.pl/kraj/news-zatrwazajace-wyniki-kontroli-nik-w-tvp-stanowcza-wypowiedz-m,nId,7070980)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:22:00+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zatrwazajace-wyniki-kontroli-nik-w-tvp-stanowcza-wypowiedz-m,nId,7070980"><img align="left" alt="&quot;Zatrważające&quot; wyniki kontroli NIK w TVP. Stanowcza wypowiedź Mariana Banasia" src="https://i.iplsc.com/zatrwazajace-wyniki-kontroli-nik-w-tvp-stanowcza-wypowiedz-m/000HRC39OYRXGFTS-C321.jpg" /></a>- Wyniki kontroli NIK w Telewizji Polskiej są zatrważające, a działalność TVP ma niewiele wspólnego z misją telewizji publicznej - powiedział prezes NIK Marian Banaś. Szef Izby podkreślił, że w mediach publicznych wykryto wiele nieprawidłowości, które są niezgodne z prawem, powodują straty finansowe spółki i generują korupcję.</p><br clear="all" />

## Ukraina: Burzliwy finał interwencji. Bójka z udziałem posłów
 - [https://wydarzenia.interia.pl/zagranica/news-ukraina-burzliwy-final-interwencji-bojka-z-udzialem-poslow,nId,7071008](https://wydarzenia.interia.pl/zagranica/news-ukraina-burzliwy-final-interwencji-bojka-z-udzialem-poslow,nId,7071008)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:08:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraina-burzliwy-final-interwencji-bojka-z-udzialem-poslow,nId,7071008"><img align="left" alt="Ukraina: Burzliwy finał interwencji. Bójka z udziałem posłów" src="https://i.iplsc.com/ukraina-burzliwy-final-interwencji-bojka-z-udzialem-poslow/000HRBDMJ69PTYGB-C321.jpg" /></a>Posłowie do Rady Najwyższej Ukrainy Artem Dmytruk i Oleksandr Kunicki wzięli udział w bójce podczas interwencji w fałszywym call center. Jak twierdzi pobity mężczyzna politycy zażądali od niego pieniędzy i oskarżali go za oszustwa.</p><br clear="all" />

## Pokojowa Nagroda Nobla przyznana. Ogłoszono laureatkę
 - [https://wydarzenia.interia.pl/zagranica/news-pokojowa-nagroda-nobla-przyznana-ogloszono-laureatke,nId,7070996](https://wydarzenia.interia.pl/zagranica/news-pokojowa-nagroda-nobla-przyznana-ogloszono-laureatke,nId,7070996)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T09:00:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pokojowa-nagroda-nobla-przyznana-ogloszono-laureatke,nId,7070996"><img align="left" alt="Pokojowa Nagroda Nobla przyznana. Ogłoszono laureatkę" src="https://i.iplsc.com/pokojowa-nagroda-nobla-przyznana-ogloszono-laureatke/000HRBUTAF9088D9-C321.jpg" /></a>Narges Mohammadi, irańska działaczka na rzecz praw człowieka laureatką Pokojowej Nagrody Nobla 2023. Wyróżnienie zostało ogłoszone w piątek w Oslo przez Norweski Komitet Noblowski. </p><br clear="all" />

## Konfederacja dystansuje się od słów kandydatki. "Możemy wybaczyć modelce"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-dystansuje-sie-od-slow-kandydatki-mozemy-wybacz,nId,7071005](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-dystansuje-sie-od-slow-kandydatki-mozemy-wybacz,nId,7071005)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T08:54:01+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-dystansuje-sie-od-slow-kandydatki-mozemy-wybacz,nId,7071005"><img align="left" alt="Konfederacja dystansuje się od słów kandydatki. &quot;Możemy wybaczyć modelce&quot;" src="https://i.iplsc.com/konfederacja-dystansuje-sie-od-slow-kandydatki-mozemy-wybacz/000HRBFPM3G5C865-C321.jpg" /></a>Samuela Torkowska, kandydatka Konfederacji do Sejmu, miała trudność z wytypowaniem, kto jej zdaniem powinien wygrać wojnę w Ukrainie. Jak sama przyznała, odpowiedź na to pytanie jest &quot;dosyć niepoprawna politycznie&quot;. Od jej słów dystansuje się jeden z liderów Konfederacji, Krzysztof Bosak. - Myślę, że możemy wybaczyć modelce, że nie interesuje się tak głęboko polityką międzynarodową - ocenił. Jak dodał, to Konrad Berkowicz &quot;wziął ją na listę w Krakowie&quot;.</p><br clear="all" />

## Skandal po meczu Legii. Ostra reakcja polskich polityków
 - [https://wydarzenia.interia.pl/kraj/news-skandal-po-meczu-legii-ostra-reakcja-polskich-politykow,nId,7070998](https://wydarzenia.interia.pl/kraj/news-skandal-po-meczu-legii-ostra-reakcja-polskich-politykow,nId,7070998)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T08:39:28+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-skandal-po-meczu-legii-ostra-reakcja-polskich-politykow,nId,7070998"><img align="left" alt="Skandal po meczu Legii. Ostra reakcja polskich polityków" src="https://i.iplsc.com/skandal-po-meczu-legii-ostra-reakcja-polskich-politykow/000HRBG4YDWGKIVU-C321.jpg" /></a>Złożę wniosek o pilną debatę w Parlamencie Europejskim w sprawie naruszenia praworządności przez Holandię - stwierdził europoseł Patryk Jaki, komentując zdarzenia po meczu Legii Warszawa z AZ Alkmaar. Zatrzymanych zostało dwóch piłkarzy stołecznej drużyny. Skandal odbił się szerokim echem wśród polityków, a komentarze płyną zarówno ze strony obozu władzy, jak i opozycji. </p><br clear="all" />

## Ludzie, idźcie na referendum!
 - [https://wydarzenia.interia.pl/felietony/news-ludzie-idzcie-na-referendum,nId,7070992](https://wydarzenia.interia.pl/felietony/news-ludzie-idzcie-na-referendum,nId,7070992)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T08:20:50+00:00

<p><a href="https://wydarzenia.interia.pl/felietony/news-ludzie-idzcie-na-referendum,nId,7070992"><img align="left" alt="Ludzie, idźcie na referendum!" src="https://i.iplsc.com/ludzie-idzcie-na-referendum/000HRB6AKMIMM8BT-C321.jpg" /></a>Warto przed tymi wyborami spojrzeć w lustro i zapytać samego siebie: czy można z czystym sumieniem perorować w jednym zdaniu o potrzebie &quot;bycia demokratą&quot; i zaraz potem nawoływać do zignorowania nadchodzącego referendum?</p><br clear="all" />

## Konfederacja pikuje w sondażach. Mówią o "zorganizowanej akcji"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-pikuje-w-sondazach-mowia-o-zorganizowanej-akcji,nId,7069532](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-pikuje-w-sondazach-mowia-o-zorganizowanej-akcji,nId,7069532)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T08:18:05+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-konfederacja-pikuje-w-sondazach-mowia-o-zorganizowanej-akcji,nId,7069532"><img align="left" alt="Konfederacja pikuje w sondażach. Mówią o &quot;zorganizowanej akcji&quot;" src="https://i.iplsc.com/konfederacja-pikuje-w-sondazach-mowia-o-zorganizowanej-akcji/000HRBEO06X77DCL-C321.jpg" /></a>Konfederacja szuka sposobu na odzyskanie utraconych wyborców. Politycy ugrupowania twierdzą, że odpłynęły od nich głównie młode kobiety i wierzą, że są w stanie je odzyskać. Jednocześnie do twardych wyborców kierują przekaz wymierzony w Ukraińców. - Wierzę, że zrobimy trzeci wynik w Polsce, różnice są małe i jest to w naszym zasięgu - mówi Interii Witold Tumanowicz, szef sztabu Konfederacji.</p><br clear="all" />

## Putin do państw Zachodu: Przetrzyjcie oczy. Dawna era minęła i nigdy nie wróci
 - [https://wydarzenia.interia.pl/zagranica/news-putin-do-panstw-zachodu-przetrzyjcie-oczy-dawna-era-minela-i,nId,7070950](https://wydarzenia.interia.pl/zagranica/news-putin-do-panstw-zachodu-przetrzyjcie-oczy-dawna-era-minela-i,nId,7070950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T08:07:38+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-putin-do-panstw-zachodu-przetrzyjcie-oczy-dawna-era-minela-i,nId,7070950"><img align="left" alt="Putin do państw Zachodu: Przetrzyjcie oczy. Dawna era minęła i nigdy nie wróci" src="https://i.iplsc.com/putin-do-panstw-zachodu-przetrzyjcie-oczy-dawna-era-minela-i/000HRAVBMBRWAOKU-C321.jpg" /></a>- Czas wreszcie pozbyć się tego myślenia o epoce rządów kolonialnych. Chcę powiedzieć: przetrzyjcie oczy! - mówił Władimir Putin, zwracając się do państw Zachodu. Przywódca Rosji w trakcie sesji plenarnej Międzynarodowego Klubu Dyskusyjnego Wałdaj kolejny raz podjął temat budowy wielobiegunowego świata. Jego zdaniem, &quot;dawna era minęła i nigdy nie wróci&quot;. </p><br clear="all" />

## Opozycja bez reklam w gazetach Polska Press. "Wartości nie do pogodzenia"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycja-bez-reklam-w-gazetach-polska-press-wartosci-nie-do-,nId,7070967](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycja-bez-reklam-w-gazetach-polska-press-wartosci-nie-do-,nId,7070967)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T07:56:58+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-opozycja-bez-reklam-w-gazetach-polska-press-wartosci-nie-do-,nId,7070967"><img align="left" alt="Opozycja bez reklam w gazetach Polska Press. &quot;Wartości nie do pogodzenia&quot;" src="https://i.iplsc.com/opozycja-bez-reklam-w-gazetach-polska-press-wartosci-nie-do/000HRB6NAL63WAPS-C321.jpg" /></a>Kandydaci Lewicy oraz Trzeciej Drogi nie mogą reklamować się w gazetach grupy wydawniczej Polska Press, należącej do spółki PKN ORLEN. W uzasadnieniu przekazano, że reprezentowane przez nich wartości są &quot;nie do pogodzenia z linią programową&quot;. &quot;Interes gazety interesem partii&quot; - ocenia Polska 2050. </p><br clear="all" />

## Zboże z Ukrainy - o co chodzi w konflikcie Polski z Ukrainą?
 - [https://wydarzenia.interia.pl/kraj/news-zboze-z-ukrainy-o-co-chodzi-w-konflikcie-polski-z-ukraina,nId,7069150](https://wydarzenia.interia.pl/kraj/news-zboze-z-ukrainy-o-co-chodzi-w-konflikcie-polski-z-ukraina,nId,7069150)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T07:14:17+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-zboze-z-ukrainy-o-co-chodzi-w-konflikcie-polski-z-ukraina,nId,7069150"><img align="left" alt="Zboże z Ukrainy - o co chodzi w konflikcie Polski z Ukrainą?" src="https://i.iplsc.com/zboze-z-ukrainy-o-co-chodzi-w-konflikcie-polski-z-ukraina/000HOFGZAGH30PKP-C321.jpg" /></a>Ukraina zawiesiła skargę w Światowej Organizacji Handlu (WTO) przeciwko Polsce, Słowacji i Węgrom - ogłosił Taras Kaczka. Wiceminister gospodarki Ukrainy podkreślił, że jest to kolejny krok do &quot;całościowego rozwiązania sporu&quot;. Przypominamy, w jaki sposób rozwijał się jeden z najgorętszych politycznych sporów na linii Warszawa - Kijów w ostatnich miesiącach.</p><br clear="all" />

## Unijny szczyt ws. migrantów. Stanowcza zapowiedź premiera Morawieckiego
 - [https://wydarzenia.interia.pl/zagranica/news-unijny-szczyt-ws-migrantow-stanowcza-zapowiedz-premiera-mora,nId,7070932](https://wydarzenia.interia.pl/zagranica/news-unijny-szczyt-ws-migrantow-stanowcza-zapowiedz-premiera-mora,nId,7070932)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T06:48:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-unijny-szczyt-ws-migrantow-stanowcza-zapowiedz-premiera-mora,nId,7070932"><img align="left" alt="Unijny szczyt ws. migrantów. Stanowcza zapowiedź premiera Morawieckiego" src="https://i.iplsc.com/unijny-szczyt-ws-migrantow-stanowcza-zapowiedz-premiera-mora/000HRAWD4GWANF9X-C321.jpg" /></a>- Polska zdecydowanie odrzuca pakt migracyjny ze względu na bezpieczeństwo naszego kraju - powiedział premier Mateusz Morawiecki tuż przed rozpoczęciem nieformalnego szczytu Rady Europejskiej w Grenadzie. Spotkanie w Hiszpanii zorganizowano, by omówić szczegóły nowego paktu migracyjnego Unii Europejskiej.</p><br clear="all" />

## Rosja może wznowić próby jądrowe. Wymowne słowa kluczowego polityka
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-moze-wznowic-proby-jadrowe-wymowne-slowa-kluczowego-po,nId,7070899](https://wydarzenia.interia.pl/zagranica/news-rosja-moze-wznowic-proby-jadrowe-wymowne-slowa-kluczowego-po,nId,7070899)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T06:33:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-moze-wznowic-proby-jadrowe-wymowne-slowa-kluczowego-po,nId,7070899"><img align="left" alt="Rosja może wznowić próby jądrowe. Wymowne słowa kluczowego polityka" src="https://i.iplsc.com/rosja-moze-wznowic-proby-jadrowe-wymowne-slowa-kluczowego-po/0005OEHR5NUEDPHC-C321.jpg" /></a>- Sytuacja na świecie uległa zmianie, ponieważ Waszyngton i Bruksela rozpętały wojnę przeciwko naszemu krajowi - powiedział przewodniczący Dumy Państwowej Wiaczesław Wołodin i zadeklarował, że izba rozważa uchylenie uznania przez Rosję Traktatu o całkowitym zakazie prób z bronią jądrową. Jak stwierdził szef Dumy, parlament &quot;z pewnością omówi kwestię unieważnienia ratyfikacji&quot;, do czego dojdzie najprawdopodobniej na najbliższym posiedzeniu.</p><br clear="all" />

## Rosja rozważa uchylenie kluczowego traktatu. Padła deklaracja
 - [https://wydarzenia.interia.pl/zagranica/news-rosja-rozwaza-uchylenie-kluczowego-traktatu-padla-deklaracja,nId,7070899](https://wydarzenia.interia.pl/zagranica/news-rosja-rozwaza-uchylenie-kluczowego-traktatu-padla-deklaracja,nId,7070899)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T06:33:26+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosja-rozwaza-uchylenie-kluczowego-traktatu-padla-deklaracja,nId,7070899"><img align="left" alt="Rosja rozważa uchylenie kluczowego traktatu. Padła deklaracja " src="https://i.iplsc.com/rosja-rozwaza-uchylenie-kluczowego-traktatu-padla-deklaracja/000HRB6H6NPO9AOL-C321.jpg" /></a>- Sytuacja na świecie uległa zmianie, ponieważ Waszyngton i Bruksela rozpętały wojnę przeciwko naszemu krajowi - powiedział przewodniczący Dumy Państwowej Wiaczesław Wołodin i zadeklarował, że izba rozważa uchylenie uznania przez Rosję Traktatu o całkowitym zakazie prób z bronią jądrową. Jak stwierdził szef Dumy, parlament &quot;z pewnością omówi kwestię unieważnienia ratyfikacji&quot;, do czego dojdzie najprawdopodobniej na najbliższym posiedzeniu.</p><br clear="all" />

## Pilot musiał wykonać niebezpieczny manewr. Awaryjne lądowanie w USA
 - [https://wydarzenia.interia.pl/zagranica/news-pilot-musial-wykonac-niebezpieczny-manewr-awaryjne-ladowanie,nId,7070909](https://wydarzenia.interia.pl/zagranica/news-pilot-musial-wykonac-niebezpieczny-manewr-awaryjne-ladowanie,nId,7070909)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T06:21:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-pilot-musial-wykonac-niebezpieczny-manewr-awaryjne-ladowanie,nId,7070909"><img align="left" alt="Pilot musiał wykonać niebezpieczny manewr. Awaryjne lądowanie w USA" src="https://i.iplsc.com/pilot-musial-wykonac-niebezpieczny-manewr-awaryjne-ladowanie/000HRALYNRUX9EBC-C321.jpg" /></a>Pilot Boeinga musiał wykazać się nie lada umiejętnościami. Na skutek usterki w maszynie nie wysunęło się podwozie. Konieczne było awaryjne lądowanie &quot;na brzuchu&quot;. Samolot uderzył o pas startowy, a następnie sunął po nim w morzu iskier. Jak wynika z informacji straży pożarnej, pilot zanim zdecydował się na lądowanie okrążył całe lotnisko.</p><br clear="all" />

## "The Economist": UE czekają poważne zmiany. Nie wszyscy będą zadowoleni
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ue-czekaja-powazne-zmiany-nie-wszyscy-beda-zad,nId,7064986](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ue-czekaja-powazne-zmiany-nie-wszyscy-beda-zad,nId,7064986)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:57:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-economist-ue-czekaja-powazne-zmiany-nie-wszyscy-beda-zad,nId,7064986"><img align="left" alt="&quot;The Economist&quot;: UE czekają poważne zmiany. Nie wszyscy będą zadowoleni" src="https://i.iplsc.com/the-economist-ue-czekaja-powazne-zmiany-nie-wszyscy-beda-zad/000HR5Q6R1SW8GLK-C321.jpg" /></a>Już wkrótce Unia Europejska może powiększyć się o kilku nowych członków. Paryż i Berlin zgadzają się na rozszerzenie UE, jeśli pójdzie za tym reforma Wspólnoty. Zmiany mogą spowodować sprzeciw wielu rządów. &quot;Rozszerzenie było kiedyś napędzane nadzieją. Teraz jest napędzane strachem&quot; - stwierdził pewien dyplomata, mając na myśli inwazję Rosji na Ukrainę. Nie brakuje jednak głosów, że zablokowanie procesu rozszerzenia byłoby dla Wspólnoty dużo bardziej kosztowne niż przyjęcie dziewięciu nowych państw.</p><br clear="all" />

## "The Washington Post": Najostrzejsze hobby świata. Padł rekord Guinessa
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-najostrzejsze-hobby-swiata-padl-rekord-g,nId,7066800](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-najostrzejsze-hobby-swiata-padl-rekord-g,nId,7066800)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:53:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-the-washington-post-najostrzejsze-hobby-swiata-padl-rekord-g,nId,7066800"><img align="left" alt="&quot;The Washington Post&quot;: Najostrzejsze hobby świata. Padł rekord Guinessa" src="https://i.iplsc.com/the-washington-post-najostrzejsze-hobby-swiata-padl-rekord-g/000HQUYXOE0RW9JX-C321.jpg" /></a>Jedzenie ostrych papryczek sprawia ból nie do opisania, nad którym trudno zapanować. Zjedzenie jednej papryczki Carolina reaper - uznawanej za najostrzejszą na świecie - może skończyć się wizytą w szpitalu. 41-letni śmiałek z Kanady nie obawia się potencjalnych konsekwencji. Mężczyzna w niecałe siedem minut zjadł 50 papryczek, które są ponad 200 razy ostrzejsze niż zwykłe jalapeño. - Chciałem dokonać czegoś wielkiego - mówi Mike Jack. 
</p><br clear="all" />

## Przez przypadek kupili ruderę w Szkocji. Pomyłka odmieniła ich życie
 - [https://wydarzenia.interia.pl/raport-media-zagraniczne/news-przez-przypadek-kupili-rudere-w-szkocji-pomylka-odmienila-ic,nId,7066880](https://wydarzenia.interia.pl/raport-media-zagraniczne/news-przez-przypadek-kupili-rudere-w-szkocji-pomylka-odmienila-ic,nId,7066880)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:49:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-media-zagraniczne/news-przez-przypadek-kupili-rudere-w-szkocji-pomylka-odmienila-ic,nId,7066880"><img align="left" alt="Przez przypadek kupili ruderę w Szkocji. Pomyłka odmieniła ich życie" src="https://i.iplsc.com/przez-przypadek-kupili-rudere-w-szkocji-pomylka-odmienila-ic/000HR6LPWD3DN4LP-C321.jpg" /></a>Cal Hunter i Claire Segeren nie planowali zakupu znajdującej się w ruinie wiktoriańskiej wilii z XIX w. Los zdecydował inaczej. Gdy ochłonęli, zakasali rękawy i przystąpili do wielkiego remontu. Swoją historią podzielili się z tysiącami internautów, a BBC nakręciło o nich film dokumentalny. Po ponad czterech latach wytężonej pracy efekt jest piorunujący. </p><br clear="all" />

## Premier reaguje po skandalu z piłkarzami Legii. "Pilne działania"
 - [https://wydarzenia.interia.pl/kraj/news-premier-reaguje-po-skandalu-z-pilkarzami-legii-pilne-dzialan,nId,7070910](https://wydarzenia.interia.pl/kraj/news-premier-reaguje-po-skandalu-z-pilkarzami-legii-pilne-dzialan,nId,7070910)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:43:02+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-premier-reaguje-po-skandalu-z-pilkarzami-legii-pilne-dzialan,nId,7070910"><img align="left" alt="Premier reaguje po skandalu z piłkarzami Legii. &quot;Pilne działania&quot; " src="https://i.iplsc.com/premier-reaguje-po-skandalu-z-pilkarzami-legii-pilne-dzialan/000HRAM07KBT8OSW-C321.jpg" /></a>Premier Mateusz Morawiecki zareagował po skandalu, do którego doszło w Holandii po meczu Legii Warszawa. &quot;Poleciłem MSZ pilne działania dyplomatyczne w celu weryfikacji wydarzeń z nocy. Polscy zawodnicy i kibice muszą być traktowani zgodnie z prawem. Nie ma zgody na jego łamanie&quot; - powiadomił w mediach społecznościowych. Do sprawy odniósł się również wiceszef MSZ Paweł Jabłoński. W nocy z czwartku na piątek doszło do ataku holenderskiej policji na piłkarzach, działaczach i trenerach Legii. Piłkarze Josue i Radovan Pankov zostali aresztowani. </p><br clear="all" />

## Prezydent Słowacji zmienia zdanie ws. pomocy dla Ukrainy. Apel do rządu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-prezydent-slowacji-zmienia-zdanie-ws-pomocy-dla-ukrainy-apel,nId,7070897](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-prezydent-slowacji-zmienia-zdanie-ws-pomocy-dla-ukrainy-apel,nId,7070897)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:33:00+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-prezydent-slowacji-zmienia-zdanie-ws-pomocy-dla-ukrainy-apel,nId,7070897"><img align="left" alt="Prezydent Słowacji zmienia zdanie ws. pomocy dla Ukrainy. Apel do rządu" src="https://i.iplsc.com/prezydent-slowacji-zmienia-zdanie-ws-pomocy-dla-ukrainy-apel/000HRAI68ECJNNEY-C321.jpg" /></a>Prezydent Słowacji Zuzana Čaputová uważa, że pomoc wojskowa dla Ukrainy powinna być kontynuowana, mimo innego zdania partii Smer Roberta Fico, która zwyciężyła w wyborach parlamentarnych. &quot;Każda słowacka administracja powinna dostrzegać, że chodzi tu w takim samym stopniu o bezpieczeństwo Ukrainy, jaki i Słowacji&quot; - zaapelowała. Zaledwie wczoraj pojawiły się doniesienia, że Čaputová potwierdziła wstrzymanie kolejnego pakietu pomocy militarnej. </p><br clear="all" />

## Przygotowują się na trzęsienie ziemi. Będą ćwiczenia
 - [https://wydarzenia.interia.pl/zagranica/news-przygotowuja-sie-na-trzesienie-ziemi-beda-cwiczenia,nId,7070884](https://wydarzenia.interia.pl/zagranica/news-przygotowuja-sie-na-trzesienie-ziemi-beda-cwiczenia,nId,7070884)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T05:23:43+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-przygotowuja-sie-na-trzesienie-ziemi-beda-cwiczenia,nId,7070884"><img align="left" alt="Przygotowują się na trzęsienie ziemi. Będą ćwiczenia" src="https://i.iplsc.com/przygotowuja-sie-na-trzesienie-ziemi-beda-cwiczenia/000HRAG7N2BGB867-C321.jpg" /></a>Na piątek zaplanowano próbne ewakuacje ze szpitali na wypadek silnego trzęsienia ziemi na terenie superwulkanu na Polach Flegrejskich na południu Włoch. Ćwiczenia zorganizowano w związku z dwoma niedawnymi wstrząsami sejsmicznymi i rosnącymi obawami mieszkańców. Także eksperci apelowali o opracowanie planów ewakuacji. </p><br clear="all" />

## Biden chce dalej pomagać Ukrainie. Szuka sposobów
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-szuka-sposobow,nId,7070883](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-szuka-sposobow,nId,7070883)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T04:27:12+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-szuka-sposobow,nId,7070883"><img align="left" alt="Biden chce dalej pomagać Ukrainie. Szuka sposobów" src="https://i.iplsc.com/biden-chce-dalej-pomagac-ukrainie-szuka-sposobow/000HRAG6IB2DODT2-C321.jpg" /></a>Administracja Joe Bidena szuka innych sposobów, by finansować zbrojenie Ukrainy w obliczu niejasnej sytuacji w Kongresie. Pod uwagę brane jest m.in. wykorzystanie środków z innych programów rządowych, w tym z Departamentu Stanu - podał portal Politico. O możliwości alternatywnych rozwiązań mówił wcześniej prezydent Joe Biden.</p><br clear="all" />

## Biden chce dalej pomagać Ukrainie. Znalazł sposób
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-znalazl-sposob,nId,7070883](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-znalazl-sposob,nId,7070883)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T04:27:12+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-biden-chce-dalej-pomagac-ukrainie-znalazl-sposob,nId,7070883"><img align="left" alt="Biden chce dalej pomagać Ukrainie. Znalazł sposób" src="https://i.iplsc.com/biden-chce-dalej-pomagac-ukrainie-znalazl-sposob/000HRAG6IB2DODT2-C321.jpg" /></a>Administracja Joe Bidena szuka innych sposobów, by finansować zbrojenie Ukrainy w obliczu niejasnej sytuacji w Kongresie. Pod uwagę brane jest m.in. wykorzystanie środków z innych programów rządowych, w tym z Departamentu Stanu - podał portal Politico. O możliwości alternatywnych rozwiązań mówił wcześniej prezydent Joe Biden.</p><br clear="all" />

## Po spotkaniu z Putinem zaczęli wysyłać broń. "Nie wiadomo, co dostają w zamian"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-po-spotkaniu-z-putinem-zaczeli-wysylac-bron-nie-wiadomo-co-d,nId,7070881](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-po-spotkaniu-z-putinem-zaczeli-wysylac-bron-nie-wiadomo-co-d,nId,7070881)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-10-06T03:51:14+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-po-spotkaniu-z-putinem-zaczeli-wysylac-bron-nie-wiadomo-co-d,nId,7070881"><img align="left" alt="Po spotkaniu z Putinem zaczęli wysyłać broń. &quot;Nie wiadomo, co dostają w zamian&quot;" src="https://i.iplsc.com/po-spotkaniu-z-putinem-zaczeli-wysylac-bron-nie-wiadomo-co-d/000HRAFJFWCWNGCD-C321.jpg" /></a>Rosja zaczęła otrzymywać artylerię od Korei Północnej - podała CBS News, powołując się na anonimowe źródło rządowe w USA. Amerykańska stacja wiąże to z niedawnym spotkaniem Kim Dzong Una i Władimira Putina. Nie wiadomo, co Moskwa obiecała Pjongjangowi w zamian - zaznacza stacja. </p><br clear="all" />

