# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Guitarist Nels Cline reflects on 19 years in Wilco #shorts
 - [https://www.youtube.com/watch?v=fQGHaqfe1vo](https://www.youtube.com/watch?v=fQGHaqfe1vo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-10-06T22:21:20+00:00

In an interview with The Current's Bill DeVille, Wilco guitarist Nels Cline reflects on his 19 years (and counting!) with the band Wilco. Listen to The Current on Saturday, Oct. 7, at 1:30 p.m. CDT to hear Bill's complete interview with Nels Cline; at that same time, the complete interview video will be posted at thecurrent.org and on our YouTube and Facebook channels.

Wilco's latest album, "Cousin" — which Bill and Nels talk about in the full interview — is out now. @wilco 

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#interview #music #wilco

## Lucius -- Stranger Danger (live on The Current)
 - [https://www.youtube.com/watch?v=Jz1TZObHhgI](https://www.youtube.com/watch?v=Jz1TZObHhgI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-10-06T02:00:06+00:00

Lucius visited The Current in St. Paul, Minnesota, where they lit up The Current studio with a performance of "Stranger Danger", above.

Musicians
Lead singers – Jess Wolfe, Holly Laessig
Drums – Dan Molad
Bass – Solomon Dorsey
Piano, Guitar – Alex Pfender
Guitar – Jacob Peter

Credits
Guests – @Luciusyt 
Host – Jill Riley
Producer – Derrick Stevens
Video Director – Eric Xu Romani
Camera Operators – Micah Kopecky, Eric Xu Romani
Audio – Josh Sauvageau
Graphics – Natalia Toledo
Digital Producer – Luke Taylor

You rely on The Current to keep you connected to the music you love, and we rely on you to power this station. Everything you find here is only possible because of listener support. Give now at: http://www.support.mpr.org/youtube  

Subscribe to our channel:
http://www.youtube.com/user/893TheCurrent?sub_confirmation=1  

Like/Follow:
https://www.facebook.com/TheCurrent/  
https://www.instagram.com/thecurrent/
https://www.tiktok.com/@thecurrent.org

#lucius #studio #music

