# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## US tourist accused of smashing second-century Roman statues at museum in Israel
 - [https://news.sky.com/story/us-tourist-accused-of-smashing-second-century-roman-statues-at-museum-in-israel-12978700](https://news.sky.com/story/us-tourist-accused-of-smashing-second-century-roman-statues-at-museum-in-israel-12978700)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T20:35:00+00:00

An American tourist has been arrested after allegedly smashing two second-century Roman statues at the Israel Museum - with his lawyer claiming he was experiencing a mental disorder called "Jerusalem syndrome".

## Mother pleads guilty to accidentally killing daughter while shooting at dog attacking kittens
 - [https://news.sky.com/story/mother-pleads-guilty-to-accidentally-killing-daughter-while-shooting-at-dog-attacking-kittens-12978596](https://news.sky.com/story/mother-pleads-guilty-to-accidentally-killing-daughter-while-shooting-at-dog-attacking-kittens-12978596)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T19:08:00+00:00

A woman has pleaded guilty to accidentally killing her teenage daughter while trying to shoot a stray dog that was attacking kittens.

## Drake to take break from music due to 'craziest problems' with stomach
 - [https://news.sky.com/story/drake-to-take-break-from-music-due-to-craziest-problems-with-stomach-as-he-releases-new-album-featuring-son-adonis-12978401](https://news.sky.com/story/drake-to-take-break-from-music-due-to-craziest-problems-with-stomach-as-he-releases-new-album-featuring-son-adonis-12978401)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T15:38:00+00:00

Drake has revealed he will take a break from music after suffering "the craziest problems for years" with his stomach.

## UEFA vice president quits role as Swedish sports chief after Sky News revealed he voted for Russia's football return
 - [https://news.sky.com/story/uefa-vice-president-karl-erik-nilsson-quits-role-as-swedish-sports-chief-after-sky-news-revealed-he-voted-for-russias-football-return-12978332](https://news.sky.com/story/uefa-vice-president-karl-erik-nilsson-quits-role-as-swedish-sports-chief-after-sky-news-revealed-he-voted-for-russias-football-return-12978332)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T14:17:00+00:00

UEFA's second in command has quit his role leading sport in Sweden after facing criticism sparked by Sky News revealing he voted to end Russia's blanket ban from European football.

## The spectre of a second war in Europe looms large after period of relative calm
 - [https://news.sky.com/story/the-spectre-of-a-second-war-in-europe-looms-large-with-tensions-extraordinarily-high-in-kosovo-12978280](https://news.sky.com/story/the-spectre-of-a-second-war-in-europe-looms-large-with-tensions-extraordinarily-high-in-kosovo-12978280)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T13:05:00+00:00

They move efficiently down the mountain paths and through the brush.

## NASA to explore giant metal asteroid - here's why it could reveal secrets about solar system
 - [https://news.sky.com/story/nasa-to-explore-giant-metal-asteroid-psyche-heres-why-it-could-reveal-secrets-about-solar-system-12978246](https://news.sky.com/story/nasa-to-explore-giant-metal-asteroid-psyche-heres-why-it-could-reveal-secrets-about-solar-system-12978246)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T12:08:00+00:00

NASA and SpaceX are set to send a spacecraft to a giant metal asteroid discovered back in the 1800s.

## Man found on top of handmade boat in Pacific Ocean before being rescued
 - [https://news.sky.com/story/man-found-naked-on-top-of-handmade-boat-in-pacific-ocean-before-being-rescued-by-cruise-ship-12978205](https://news.sky.com/story/man-found-naked-on-top-of-handmade-boat-in-pacific-ocean-before-being-rescued-by-cruise-ship-12978205)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T11:08:00+00:00

A man trying to become the youngest person to cross the Pacific Ocean in a handmade boat had to be rescued by a cruise ship after it capsized.

## 'Long colds' just as common as long COVID, scientists say
 - [https://news.sky.com/story/long-colds-just-as-common-as-long-covid-and-can-leave-prolonged-symptoms-12978130](https://news.sky.com/story/long-colds-just-as-common-as-long-covid-and-can-leave-prolonged-symptoms-12978130)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T09:20:00+00:00

'Long colds' can be just as common as long COVID, scientists have discovered.

## Nobel Peace Prize awarded to jailed Iranian activist for 'fight against oppression of women'
 - [https://news.sky.com/story/nobel-peace-prize-awarded-to-irans-narges-mohammadi-12978009](https://news.sky.com/story/nobel-peace-prize-awarded-to-irans-narges-mohammadi-12978009)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T06:49:00+00:00

Jailed Iranian activist Narges Mohammadi has won the prestigious Nobel Peace Prize for 2023.

## At least 40 people dead after glacial lake flooding in Indian Himalayas
 - [https://news.sky.com/story/at-least-40-people-dead-after-glacial-lake-flooding-in-indias-himalayan-region-12977956](https://news.sky.com/story/at-least-40-people-dead-after-glacial-lake-flooding-in-indias-himalayan-region-12977956)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T04:43:00+00:00

At least 40 people have been killed in flooding in India's Himalayan region, officials have said.

## Up to 20,000 children displaced every day by storms, floods and wildfires, UNICEF says
 - [https://news.sky.com/story/up-to-20000-children-displaced-every-day-by-storms-floods-and-wildfires-unicef-says-12977935](https://news.sky.com/story/up-to-20000-children-displaced-every-day-by-storms-floods-and-wildfires-unicef-says-12977935)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-10-06T01:04:00+00:00

Storms, floods and wildfires led to more than 43 million displacements of children between 2016 and 2021, UNICEF has said.

