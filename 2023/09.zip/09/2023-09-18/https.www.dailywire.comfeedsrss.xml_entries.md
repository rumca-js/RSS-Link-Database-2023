# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## ‘The View’ Hosts Duke It Out Over Trump’s NBC Interview: ‘Nobody Looks Good’
 - [https://www.dailywire.com/news/the-view-hosts-duke-it-out-over-trumps-nbc-interview-nobody-looks-good](https://www.dailywire.com/news/the-view-hosts-duke-it-out-over-trumps-nbc-interview-nobody-looks-good)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T18:44:43+00:00

New host Kristen Welker took a virtual barrage of hatred over her maiden voyage at the helm of &#8220;Meet the Press&#8221; — and the cohosts of ABC&#8217;s &#8220;The View&#8221; used Monday&#8217;s broadcast to join the pile-on. The hate stemmed from the fact that Welker&#8217;s first show featured a one-on-one interview with former President Donald Trump ...

## ‘Weak Sauce’: Megyn Kelly Hits Trump For His Answer To Question On Radical Gender Theory
 - [https://www.dailywire.com/news/weak-sauce-megyn-kelly-hits-trump-for-his-answer-to-question-on-radical-gender-theory](https://www.dailywire.com/news/weak-sauce-megyn-kelly-hits-trump-for-his-answer-to-question-on-radical-gender-theory)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T18:37:21+00:00

Conservative podcast host and journalist Megyn Kelly was not impressed with former President Donald Trump’s answer to her question on transgenderism during her sit-down with Trump last week.  Kelly joined radio host and The Blaze founder Glenn Beck on Monday to discuss her interview with the former president, telling Beck that she wished Trump would’ve ...

## Coach Prime Blasts ‘Feel Good’ Culture In Interview On How He Turned CU Into ‘Epicenter’ Of Football
 - [https://www.dailywire.com/news/coach-prime-blasts-feel-good-culture-in-interview-on-how-he-turned-cu-into-epicenter-of-football](https://www.dailywire.com/news/coach-prime-blasts-feel-good-culture-in-interview-on-how-he-turned-cu-into-epicenter-of-football)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T18:04:01+00:00

Colorado Football Head Coach Deion Sanders — commonly referred to as &#8220;Coach Prime&#8221; — continued to be the dominant topic of conversation in the world of sports over the weekend as he led the Buffaloes to a 3-0 record after a double overtime win against in-state rival Colorado State in a game that ESPN said ...

## Michigan State Officials Plan To Fire Head Football Coach Mel Tucker Over Sexual Harassment Allegations
 - [https://www.dailywire.com/news/michigan-state-officials-plan-to-fire-head-football-coach-mel-tucker-over-sexual-harassment-allegations](https://www.dailywire.com/news/michigan-state-officials-plan-to-fire-head-football-coach-mel-tucker-over-sexual-harassment-allegations)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T18:02:40+00:00

Michigan State University officials on Monday delivered a notice of termination to the school&#8217;s head football coach Mel Tucker after a prominent rape survivor and activist recently accused him of sexual harassment during a phone call. Tucker, 51, who signed a $95 million decade-long contract extension less than two years ago, made headlines last week ...

## Massachusetts Has A New Plan To Crack Down On Plastic Bottles
 - [https://www.dailywire.com/news/massachusetts-has-a-new-plan-to-crack-down-on-plastic-bottles](https://www.dailywire.com/news/massachusetts-has-a-new-plan-to-crack-down-on-plastic-bottles)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T17:52:02+00:00

Amidst duel crises of illegal immigration and rising drug overdoses, Massachusetts Democratic Governor Maura Healey has decided to crack down on the real culprit of the Bay State&#8217;s problems: Single-use plastic bottles. Monday morning, the governor announced at The Clinton Global Initiative in New York City that she will be banning state agencies from purchasing ...

## Marines Order Stand-Down For Aviation Units Amid Search For Missing F-35
 - [https://www.dailywire.com/news/marines-order-stand-down-for-aviation-units-amid-search-for-missing-f-35](https://www.dailywire.com/news/marines-order-stand-down-for-aviation-units-amid-search-for-missing-f-35)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T17:40:29+00:00

The U.S. Marines ordered a two-day stand-down of aviation units while the search for a missing F-35 stealth fighter jet continues, according to a new report. In an email to his military branch on Monday, Marine Corps Commandant Eric Smith said the temporary pause on flights will give officials time to discuss safety measures and ...

## DeSantis Criticizes U.S. Senate Dress Code Change To Accommodate Fetterman
 - [https://www.dailywire.com/news/desantis-criticizes-u-s-senate-dress-code-change-to-accommodate-fetterman](https://www.dailywire.com/news/desantis-criticizes-u-s-senate-dress-code-change-to-accommodate-fetterman)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T16:26:05+00:00

Florida Governor Ron DeSantis criticized the U.S. Senate on Monday after the chamber of Congress eliminated its dress code for lawmakers over the weekend, appearing to accommodate Pennsylvania Democrat Sen. John Fetterman. &#8220;We need to be lifting up our standards in this country, not dumbing down our standards in this country,&#8221; DeSantis said. On Sunday, ...

## 11th U.S. Senator Endorses Trump
 - [https://www.dailywire.com/news/11th-u-s-senator-endorses-trump](https://www.dailywire.com/news/11th-u-s-senator-endorses-trump)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T15:45:52+00:00

Sen. Mike Braun (R-IN) endorsed Donald Trump on Monday, becoming the 11th GOP senator to rally behind the former president&#8217;s 2024 bid to retake the White House. Braun, who is running for governor of Indiana, made the announcement in a statement posted to his campaign account on X. He picked Trump over fellow Hoosier Mike Pence, ...

## 3 Pro-Life Advocates Involved In Abortion Clinic Barricade Convicted On FACE Act Charges
 - [https://www.dailywire.com/news/3-pro-life-advocates-involved-in-abortion-clinic-barricade-convicted-on-face-act-charges](https://www.dailywire.com/news/3-pro-life-advocates-involved-in-abortion-clinic-barricade-convicted-on-face-act-charges)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T15:41:43+00:00

Three pro-life advocates face more than a decade in prison after a federal jury convicted them on Friday for conspiring to barricade themselves in a Washington, D.C.-based abortion clinic in 2020. The defendants – Jonathan Darnel, 41, of Arlington, Va.; Jean Marshall, 73, of Kingston, Mass.; and Joan Bell, 74, of Montague, NJ – were ...

## Apple Worships Mother Nature. Welcome To Pagan America.
 - [https://www.dailywire.com/news/apple-worships-mother-nature-welcome-to-pagan-america](https://www.dailywire.com/news/apple-worships-mother-nature-welcome-to-pagan-america)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T15:39:47+00:00

The pagan mentality that’s taking over corporate America is truly astonishing.   Apple just released an ad in which they effectively call for worship of Mother Nature. This is just pure pagan-Gaia-worship nonsense. In the commercial, Apple CEO Tim Cook and what we are to assume is the rest of the Apple board are meeting with ...

## Drug-Infested Philadelphia Passes Bill To Ban Supervised Drug Sites
 - [https://www.dailywire.com/news/drug-infested-philadelphia-passes-bill-to-ban-supervised-drug-sites](https://www.dailywire.com/news/drug-infested-philadelphia-passes-bill-to-ban-supervised-drug-sites)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T15:06:56+00:00

Philadelphia passed a bill last week banning supervised drug consumption sites across most of the city in the latest attempt by a Democrat-run city to curb rampant public drug use. The Philadelphia City Council approved the ban Thursday in a 13-1 vote during a heated meeting where dozens of people on both sides of the ...

## Are The Sexual Assault Allegations Against Russell Brand His Punishment For Questioning The Left?
 - [https://www.dailywire.com/news/are-the-sexual-assault-allegations-against-russell-brand-his-punishment-for-questioning-the-left](https://www.dailywire.com/news/are-the-sexual-assault-allegations-against-russell-brand-his-punishment-for-questioning-the-left)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T14:56:11+00:00

Danny Masterson is an actor most people haven&#8217;t thought about for a long time, if at all. By all accounts, his career peaked all the way back in 2006, with the conclusion of the sitcom &#8220;That 70&#8217;s Show.&#8221; But a few years ago, all of a sudden, Masterson&#8217;s name was everywhere. That&#8217;s because in March ...

## Suspect Arrested In Ambush Killing Of L.A. County Sheriff’s Deputy
 - [https://www.dailywire.com/news/suspect-arrested-in-ambush-killing-of-l-a-county-sheriffs-deputy](https://www.dailywire.com/news/suspect-arrested-in-ambush-killing-of-l-a-county-sheriffs-deputy)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T14:47:05+00:00

A suspect was arrested on Monday in connection to the fatal shooting of Los Angeles County Sheriff’s Deputy Ryan Clinkunbroomer over the weekend. Kevin Salazar, 29, was detained in the morning following an hours-long standoff at the suspect&#8217;s residence in Palmdale, California, Sheriff Robert Luna announced in a press conference. &#8220;We are extremely confident we ...

## ‘Smear’: IRS Whistleblower Responds To Hunter Biden Lawsuit Targeting Him
 - [https://www.dailywire.com/news/smear-irs-whistleblower-responds-to-hunter-biden-lawsuit-targeting-him](https://www.dailywire.com/news/smear-irs-whistleblower-responds-to-hunter-biden-lawsuit-targeting-him)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T13:12:56+00:00

After news broke that President Biden’s son Hunter had filed a lawsuit against the IRS, IRS Supervisory Special Agent Gary Shapley’s legal team issued a statement condemning the action. Biden filed the lawsuit claiming that IRS agents Gary Shapley and Joseph Ziegler revealed confidential information about his taxes in public interviews and statements. “This suit ...

## ‘Better Call Saul’ Star Admits He Ignored ‘Cranky Conservative’ Doctor’s Advice Before Heart Attack
 - [https://www.dailywire.com/news/better-call-saul-star-admits-he-ignored-cranky-conservative-doctors-advice-before-heart-attack](https://www.dailywire.com/news/better-call-saul-star-admits-he-ignored-cranky-conservative-doctors-advice-before-heart-attack)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T12:19:10+00:00

“Better Call Saul” and “Breaking Bad” actor Bob Odenkirk acknowledged that he ignored the advice of a “cranky conservative” doctor and later had a heart attack.  The 60-year-old discussed what happened during a recent episode of the podcast “Don’t Ask Tig.”  &#8220;When I was 50, I went in, he was a heart doctor, Cedar-Sinai, and ...

## Massachusetts Mom Accused Of Strangling Her 3 Young Children Indicted
 - [https://www.dailywire.com/news/massachusetts-mom-accused-of-strangling-her-3-young-children-indicted](https://www.dailywire.com/news/massachusetts-mom-accused-of-strangling-her-3-young-children-indicted)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T12:07:25+00:00

A grand jury has indicted a Massachusetts mother who allegedly strangled her three young children. Lindsay Clancy, 32, has been charged on three counts each of murder and strangulation for the deaths of 5-year-old Cora, 3-year-old Dawson, and Callan, who was only eight months old, Inside Edition reported. Clancy was previously indicted in Plymouth District ...

## Hunter Biden Sues IRS Over Whistleblower Leaks
 - [https://www.dailywire.com/news/hunter-biden-sues-irs-over-whistleblower-leaks](https://www.dailywire.com/news/hunter-biden-sues-irs-over-whistleblower-leaks)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T11:51:35+00:00

Hunter Biden sued the IRS on Monday over alleged violations of his privacy when agents went to Congress with details of the agency’s investigation into Biden’s taxes. Biden is under pressure from federal investigators and prosecutors and has adopted an adversarial stance since a plea deal fell apart in July. The first son’s approach to ...

## ‘Not Cool’: Halle Berry Trashes Drake For Using Pic Of Her Covered In Slime After She Said ‘No’
 - [https://www.dailywire.com/news/not-cool-halle-berry-trashes-drake-for-using-pic-of-her-covered-in-slime-after-she-said-no](https://www.dailywire.com/news/not-cool-halle-berry-trashes-drake-for-using-pic-of-her-covered-in-slime-after-she-said-no)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T11:38:13+00:00

Actress Halle Berry said she asked Drake not to use a photo of her covered in slime while promoting his new single, but he did it anyway. Drake and SZA used an image of Berry covered in green slime that was taken at the 2012 Nickelodeon Kids’ Choice Awards as the cover art for the ...

## Hugh Jackman Having ‘Difficult Time’ After Announcing Divorce From Wife Of 27 Years
 - [https://www.dailywire.com/news/hugh-jackman-having-difficult-time-after-announcing-divorce-from-wife-of-27-years](https://www.dailywire.com/news/hugh-jackman-having-difficult-time-after-announcing-divorce-from-wife-of-27-years)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T11:02:54+00:00

Hugh Jackman addressed his impending divorce over the weekend for the first time since he and Deborra-lee Furness announced they were splitting after 27 years of marriage. “I don’t feel quite right talking about it on the street,” the “Wolverine” star said after being approached in public over the weekend in New York City, per ...

## Biden Hands Iran $6 Billion; 5 Americans Freed
 - [https://www.dailywire.com/news/biden-hands-iran-6-billion-5-americans-freed](https://www.dailywire.com/news/biden-hands-iran-6-billion-5-americans-freed)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T10:30:51+00:00

After President Biden released $6 billion in frozen oil revenues to Iran, the theocratic despotic Iranian regime released five American prisoners it had detained for years. “A plane carrying the five Americans and two of their relatives has taken off from Iran and is en route to Qatar, which had helped broker the swap,” NBC ...

## Drew Barrymore Does About-Face, Pauses Talk Show Until Strike Ends
 - [https://www.dailywire.com/news/drew-barrymore-does-about-face-pauses-talk-show-until-strike-ends](https://www.dailywire.com/news/drew-barrymore-does-about-face-pauses-talk-show-until-strike-ends)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T10:18:17+00:00

Drew Barrymore has reversed course, now deciding to pause her eponymous talk show as the writers strike in Hollywood drags on. The 48-year-old celebrity faced enormous pressure following her decision to keep filming during the strike. It was enough to change her mind on the matter. “I have listened to everyone, and I am making ...

## Joint Chiefs Of Staff Chairman Milley Protests: I’m Not Sure What Woke Means
 - [https://www.dailywire.com/news/joint-chiefs-of-staff-chairman-milley-protests-im-not-sure-what-woke-means](https://www.dailywire.com/news/joint-chiefs-of-staff-chairman-milley-protests-im-not-sure-what-woke-means)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T09:22:55+00:00

General Mark Milley, the chairman of the Joint Chiefs of Staff, insisted that he was not sure what the word “woke” means. Milley spoke on Sunday with CNN’s Fareed Zakaria, who stated, “You talk about how the military is not woke. How the military officers should be reading Karl Marx,” then asked, “Is the U.S. ...

## Weekend Media Wrap, Vol. 9: What You Missed If You Weren’t Glued To The Sunday Shows
 - [https://www.dailywire.com/news/weekend-media-wrap-vol-9-what-you-missed-if-you-werent-glued-to-the-sunday-shows](https://www.dailywire.com/news/weekend-media-wrap-vol-9-what-you-missed-if-you-werent-glued-to-the-sunday-shows)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-18T08:53:04+00:00

Every Sunday morning, legacy media outlets are taken over by elected officials, aspiring elected officials, administration insiders, and the usual collection of talking heads — all of whom are there to discuss specific policies, push talking points, or simply promote their own campaigns. For those who don&#8217;t spend their Sunday mornings glued to the television ...

