# Source:Neowin, URL:https://www.neowin.net/news/rss/, language:en-us

## Intel Arc GPU beta graphics driver 31.0.101.4826 adds Phantom Liberty and Payday 3 support
 - [https://www.neowin.net/news/intel-arc-gpu-beta-graphics-driver-3101014826-adds-phantom-liberty-and-payday-3-support/](https://www.neowin.net/news/intel-arc-gpu-beta-graphics-driver-3101014826-adds-phantom-liberty-and-payday-3-support/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T22:34:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/04/1681468966_intel_arc_beta_medium.jpg" /></div>The Intel Arc and Iris Xe GPU beta graphics driver 31.0.101.4826 update also adds support for Lies of P and Party Animals, along with performance improvements for Hitman Absolution and more <a href="https://www.neowin.net/news/intel-arc-gpu-beta-graphics-driver-3101014826-adds-phantom-liberty-and-payday-3-support">Read more...</a>

## Microsoft brings big Windows WSL upgrade with better memory, disk, network management
 - [https://www.neowin.net/news/microsoft-brings-big-windows-wsl-upgrade-with-better-memory-disk-network-management/](https://www.neowin.net/news/microsoft-brings-big-windows-wsl-upgrade-with-better-memory-disk-network-management/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T22:14:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1682950344_windows_11_medium.jpg" /></div>The Windows Subsystem for Linux has received a new update today. The new release brings several interesting features that upgrade memory and disk management, as well as networking improvements. <a href="https://www.neowin.net/news/microsoft-brings-big-windows-wsl-upgrade-with-better-memory-disk-network-management">Read more...</a>

## Windows 10 22H2 Release Preview Build 19045.3513 (KB5030300) is now available
 - [https://www.neowin.net/news/windows-10-22h2-release-preview-build-190453513-kb5030300-is-now-available/](https://www.neowin.net/news/windows-10-22h2-release-preview-build-190453513-kb5030300-is-now-available/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T22:02:52+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/10/1665146156_windows_10_source-_neowin_plus_22h2_medium.jpg" /></div>The new Windows 10 22H2 Release Preview Build 19045.3513 (KB5030300) includes an improved search box experience on the taskbar, along with new taskbar icon animations, among other changes. <a href="https://www.neowin.net/news/windows-10-22h2-release-preview-build-190453513-kb5030300-is-now-available">Read more...</a>

## Unity could cap revenues it gets from its biggest game developer customers
 - [https://www.neowin.net/news/unity-could-cap-revenues-it-gets-from-its-biggest-game-developer-customers/](https://www.neowin.net/news/unity-could-cap-revenues-it-gets-from-its-biggest-game-developer-customers/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T21:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/02/1614159939_unity-2d-game-development_medium.jpg" /></div>A new report claims Unity may now try to limit its game engine and runtime fees to 4 percent of a game&#039;s revenue for developers who make over $1 million, but that plan has not been finalized yet. <a href="https://www.neowin.net/news/unity-could-cap-revenues-it-gets-from-its-biggest-game-developer-customers">Read more...</a>

## Rejoice! Intel confirms Wi-Fi 7 support in Windows 11 and in Windows 10 too
 - [https://www.neowin.net/news/rejoice-intel-confirms-wi-fi-7-support-in-windows-11-and-in-windows-10-too/](https://www.neowin.net/news/rejoice-intel-confirms-wi-fi-7-support-in-windows-11-and-in-windows-10-too/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T20:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/07/1689237861_thumbs_up_medium.jpg" /></div>Recently it was speculated by the media that Intel and Microsoft may limit Wi-Fi 7 to Windows 11 and newer Windows versions. Intel, though, has seemingly now confirmed that&#039;s not going to be the case. <a href="https://www.neowin.net/news/rejoice-intel-confirms-wi-fi-7-support-in-windows-11-and-in-windows-10-too">Read more...</a>

## Rumor: Nvidia RTX 5090 could pack 24.5K cores, 32GB GDDR7 VRAM, and 3GHz boost clocks
 - [https://www.neowin.net/news/rumor-nvidia-rtx-5090-could-pack-245k-cores-32gb-gddr7-vram-and-3ghz-boost-clocks/](https://www.neowin.net/news/rumor-nvidia-rtx-5090-could-pack-245k-cores-32gb-gddr7-vram-and-3ghz-boost-clocks/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T20:36:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695067795_geforce-rtx-5090-alleged_medium.jpg" /></div>Recent leaks revealed Nvidia&#039;s plans for the RTX 5090. It will reportedly have 50% increase in CUDA cores, 52% faster memory bandwidth through GDDR7, and a 15% increase in clock speed to over 3GHz. <a href="https://www.neowin.net/news/rumor-nvidia-rtx-5090-could-pack-245k-cores-32gb-gddr7-vram-and-3ghz-boost-clocks">Read more...</a>

## Microsoft Paint may add an AI art generator in the future similar to Bing Image Creator
 - [https://www.neowin.net/news/microsoft-paint-may-add-an-ai-art-generator-in-the-future-similar-to-bing-image-creator/](https://www.neowin.net/news/microsoft-paint-may-add-an-ai-art-generator-in-the-future-similar-to-bing-image-creator/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T19:52:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/01/1675095115_paint_medium.jpg" /></div>Code strings discovered in the latest Microsoft Paint Insider release may point to an AI image generator called Cocreator that may let users type in a prompt to make artwork in the app. <a href="https://www.neowin.net/news/microsoft-paint-may-add-an-ai-art-generator-in-the-future-similar-to-bing-image-creator">Read more...</a>

## New report claims former Surface head Panos Panay is jumping ship from Microsoft to Amazon
 - [https://www.neowin.net/news/new-report-claims-former-surface-head-panos-panay-is-jumping-ship-from-microsoft-to-amazon/](https://www.neowin.net/news/new-report-claims-former-surface-head-panos-panay-is-jumping-ship-from-microsoft-to-amazon/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T18:42:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2015/07/sddefault_medium.jpg" /></div>A new but unconfirmed report claims former Surface leader Panos Panay, who was announced as leaving Microsoft today, is actually headed over to rival Amazon to run its hardware and Alexa divisions. <a href="https://www.neowin.net/news/new-report-claims-former-surface-head-panos-panay-is-jumping-ship-from-microsoft-to-amazon">Read more...</a>

## Nintendo reportedly told Activision that Switch 2 will match Xbox One/PS4 performance
 - [https://www.neowin.net/news/nintendo-reportedly-told-activision-that-switch-2-will-match-xbox-oneps4-performance/](https://www.neowin.net/news/nintendo-reportedly-told-activision-that-switch-2-will-match-xbox-oneps4-performance/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:50:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2019/01/1547397516_nintendoswitch2_medium.jpg" /></div>Newly leaked emails from 2022 reveal that Activision was briefed on Nintendo&#039;s next-gen Switch 2. The emails suggest that the new system would offer performance on par with the Xbox One/PS4. <a href="https://www.neowin.net/news/nintendo-reportedly-told-activision-that-switch-2-will-match-xbox-oneps4-performance">Read more...</a>

## Microsoft updates Paint with layers and transparency support for Insiders
 - [https://www.neowin.net/news/microsoft-updates-paint-with-layers-and-transparency-support-for-insiders/](https://www.neowin.net/news/microsoft-updates-paint-with-layers-and-transparency-support-for-insiders/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:32:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/04/1618144930_paint_medium.jpg" /></div>Microsoft has prepared another update for Paint, one of the oldest stock Windows apps. The latest preview release introduces layers and transparency support, and it is now rolling out to Insiders. <a href="https://www.neowin.net/news/microsoft-updates-paint-with-layers-and-transparency-support-for-insiders">Read more...</a>

## Microsoft launches the experimental Python Editor from Excel Labs
 - [https://www.neowin.net/news/microsoft-launches-the-experimental-python-editor-from-excel-labs/](https://www.neowin.net/news/microsoft-launches-the-experimental-python-editor-from-excel-labs/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:20:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695055089_excel-python-editor_medium.jpg" /></div>The Python Editor has been created by Microsoft to help expand the recently added support for the Python coding language in Excel spreadsheets for longer and more complex coding jobs. <a href="https://www.neowin.net/news/microsoft-launches-the-experimental-python-editor-from-excel-labs">Read more...</a>

## You can't have these six iOS 17 features right now
 - [https://www.neowin.net/news/you-cant-have-these-six-ios-17-features-right-now/](https://www.neowin.net/news/you-cant-have-these-six-ios-17-features-right-now/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:10:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695037257_screenshot_2023-09-18_at_5.08.09_pm_medium.jpg" /></div>The new iOS 17 update is on its way to iPhones across the globe. But there are some features Apple is currently baking that will arrive in the later months of the year in subsequent updates. <a href="https://www.neowin.net/news/you-cant-have-these-six-ios-17-features-right-now">Read more...</a>

## iPadOS 17 is out with redesigned lock screen, Health app, PDF improvements, and more
 - [https://www.neowin.net/news/ipados-17-is-out-with-redesigned-lock-screen-health-app-pdf-improvements-and-more/](https://www.neowin.net/news/ipados-17-is-out-with-redesigned-lock-screen-health-app-pdf-improvements-and-more/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:03:55+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695030289_ipados_17_medium.jpg" /></div>iPadOS 17 is now rolling out to all users with compatible iPads. The latest update delivers a redesigned lock screen with widgets, the Health app, Stage Manager improvements, and many more. <a href="https://www.neowin.net/news/ipados-17-is-out-with-redesigned-lock-screen-health-app-pdf-improvements-and-more">Read more...</a>

## Apple releases watchOS 10 with redesigned apps and new health metrics
 - [https://www.neowin.net/news/apple-releases-watchos-10-with-redesigned-apps-and-new-health-metrics/](https://www.neowin.net/news/apple-releases-watchos-10-with-redesigned-apps-and-new-health-metrics/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:03:45+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1694003561_watchos_10_medium.jpg" /></div>watchOS 10, Apple&#039;s latest operating system for smartwatches, is now available. It introduces redesigned stock apps, more health metrics, two new watch faces, new APIs for workouts, and more. <a href="https://www.neowin.net/news/apple-releases-watchos-10-with-redesigned-apps-and-new-health-metrics">Read more...</a>

## Apple releases iOS 17 with redesigned communication apps, AirDrop improvements, more
 - [https://www.neowin.net/news/apple-releases-ios-17-with-redesigned-communication-apps-airdrop-improvements-more/](https://www.neowin.net/news/apple-releases-ios-17-with-redesigned-communication-apps-airdrop-improvements-more/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:03:33+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1694796208_ios_17_medium.jpg" /></div>iOS 17 is now available for download. Announced at WWDC earlier this year, Apple&#039;s latest mobile OS brings redesigned communication experiences, new apps, AirDrop improvements, and many more. <a href="https://www.neowin.net/news/apple-releases-ios-17-with-redesigned-communication-apps-airdrop-improvements-more">Read more...</a>

## 10 Machine Learning Blueprints You Should Know for Cybersecurity | FREE download
 - [https://www.neowin.net/sponsored/10-machine-learning-blueprints-you-should-know-for-cybersecurity--free-download/](https://www.neowin.net/sponsored/10-machine-learning-blueprints-you-should-know-for-cybersecurity--free-download/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T17:00:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/03/1616432345_cybersecurity-lazarus-hacking-technique_medium.jpg" /></div>Normally costing $39.99 but now free until September 27, by the end of this book, you&#039;ll be able to apply machine learning algorithms to detect malware, fake news, deep fakes, and more. <a href="https://www.neowin.net/sponsored/10-machine-learning-blueprints-you-should-know-for-cybersecurity--free-download">Read more...</a>

## Microsoft Xbox becomes the Official Console Partner of BWT Alpine F1 team
 - [https://www.neowin.net/news/microsoft-xbox-becomes-the-official-console-partner-of-bwt-alpine-f1-team/](https://www.neowin.net/news/microsoft-xbox-becomes-the-official-console-partner-of-bwt-alpine-f1-team/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T16:32:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695053534_fphwgbcxsaej7ut-1_medium.jpg" /></div>Further expanding Microsoft&#039;s partnership with the BWT Alpine F1 team in Formula 1, Xbox has announced that it has become the Official Console Partner, and PC Game Pass becomes an Official Partner. <a href="https://www.neowin.net/news/microsoft-xbox-becomes-the-official-console-partner-of-bwt-alpine-f1-team">Read more...</a>

## Microsoft researchers leak 38TB of sensitive data due to misconfigured storage on GitHub
 - [https://www.neowin.net/news/microsoft-researchers-leak-38tb-of-sensitive-data-due-to-misconfigured-storage-on-github/](https://www.neowin.net/news/microsoft-researchers-leak-38tb-of-sensitive-data-due-to-misconfigured-storage-on-github/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T16:18:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/06/1528588712_microsoftgithub_medium.jpg" /></div>Due to a misconfigured cloud storage setting on GitHub, Microsoft accidentally exposed over 38TB of internal data for over two years. This includes backups of employee passwords and messages. <a href="https://www.neowin.net/news/microsoft-researchers-leak-38tb-of-sensitive-data-due-to-misconfigured-storage-on-github">Read more...</a>

## Intel is working on making new chips with glass substrates to help pack in more transistors
 - [https://www.neowin.net/news/intel-is-working-on-making-new-chips-with-glass-substrates-to-help-pack-in-more-transistors/](https://www.neowin.net/news/intel-is-working-on-making-new-chips-with-glass-substrates-to-help-pack-in-more-transistors/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T16:02:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695046741_intel-glass_medium.jpg" /></div>Intel says that using glass substrates for chips instead of organic materials should allow for even more transistors to be packed into the same space, but we will have to wait a while for these chips. <a href="https://www.neowin.net/news/intel-is-working-on-making-new-chips-with-glass-substrates-to-help-pack-in-more-transistors">Read more...</a>

## Microsoft reorganizes its Windows and Surface teams under new leaders
 - [https://www.neowin.net/news/microsoft-reorganizes-its-windows-and-surface-teams-under-new-leaders/](https://www.neowin.net/news/microsoft-reorganizes-its-windows-and-surface-teams-under-new-leaders/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T15:30:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1660889587_windows_11_green_logo_medium.jpg" /></div>With today&#039;s departure of Panos Panay, Microsoft is making a lot of changes to its Windows and Surface teams, with new leaders for those divisions, and a new Windows and Web Experiences team. <a href="https://www.neowin.net/news/microsoft-reorganizes-its-windows-and-surface-teams-under-new-leaders">Read more...</a>

## Starfield overtakes Forza Horizon 5 as the biggest Xbox launch in Europe
 - [https://www.neowin.net/news/starfield-overtakes-forza-horizon-5-as-the-biggest-xbox-launch-in-europe/](https://www.neowin.net/news/starfield-overtakes-forza-horizon-5-as-the-biggest-xbox-launch-in-europe/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T15:08:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/08/1690905492_stafield_medium.jpg" /></div>Bethesda&#039;s Starfield had a very strong opening week in European markets, topping both the physical and digital game charts for last week. It is also the 5th biggest launch in Europe to date. <a href="https://www.neowin.net/news/starfield-overtakes-forza-horizon-5-as-the-biggest-xbox-launch-in-europe">Read more...</a>

## The Elder Scrolls 6 will not be released on PlayStation 5
 - [https://www.neowin.net/news/the-elder-scrolls-6-will-not-be-released-on-playstation-5/](https://www.neowin.net/news/the-elder-scrolls-6-will-not-be-released-on-playstation-5/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T14:56:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2018/06/1528687601_2018-06-11_(3)_medium.jpg" /></div>In recent documents that have been released during the FTC vs. Microsoft case, it&#039;s been confirmed that the next installment of The Elder Scrolls franchise won&#039;t be coming to PlayStation 5 <a href="https://www.neowin.net/news/the-elder-scrolls-6-will-not-be-released-on-playstation-5">Read more...</a>

## Microsoft Windows and Surface leader Panos Panay is departing the company after 19 years
 - [https://www.neowin.net/news/microsoft-windows-and-surface-leader-panos-panay-is-departing-the-company-after-19-years/](https://www.neowin.net/news/microsoft-windows-and-surface-leader-panos-panay-is-departing-the-company-after-19-years/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T14:28:24+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/08/1597528185_panos_panay_(6)_medium.jpg" /></div>Panos Panay, who joined Microsoft in 2004 and has led the Windows and Surface divisions for a number of years, is leaving the company. A specific reason for his departure was not revealed. <a href="https://www.neowin.net/news/microsoft-windows-and-surface-leader-panos-panay-is-departing-the-company-after-19-years">Read more...</a>

## Microsoft may be working to stream PC games as well as Xbox titles
 - [https://www.neowin.net/news/microsoft-may-be-working-to-stream-pc-games-as-well-as-xbox-titles/](https://www.neowin.net/news/microsoft-may-be-working-to-stream-pc-games-as-well-as-xbox-titles/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T14:04:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2021/03/1615131719_ignite-msw_medium.jpg" /></div>Newly revealed internal emails from Microsoft executives showed that the company was working in 2021 on a PC game streaming service similar to its current Xbox Cloud Gaming service. <a href="https://www.neowin.net/news/microsoft-may-be-working-to-stream-pc-games-as-well-as-xbox-titles">Read more...</a>

## Australia tells dating apps to improve safety standards or face legislation
 - [https://www.neowin.net/news/australia-tells-dating-apps-to-improve-safety-standards-or-face-legislation/](https://www.neowin.net/news/australia-tells-dating-apps-to-improve-safety-standards-or-face-legislation/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T13:40:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/05/1683899364_tinder_logo_on_phone_medium.jpg" /></div>Dating apps like Tinder and Bumble have been told by the Australian government to improve user safety by 30 July 2024. If they fail to do so, the government has said it will introduce legislation. <a href="https://www.neowin.net/news/australia-tells-dating-apps-to-improve-safety-standards-or-face-legislation">Read more...</a>

## Save 57% off a 1-Yr subscription to FlexJobs, now just $29.99
 - [https://www.neowin.net/deals/save-57-off-a-1-yr-subscription-to-flexjobs-now-just-2999/](https://www.neowin.net/deals/save-57-off-a-1-yr-subscription-to-flexjobs-now-just-2999/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T12:54:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2020/05/1590582226_flexjobs_medium.jpg" /></div>With today&#039;s highlighted deal, discover the perfect platform to search for jobs that fit your schedule! Browse and apply to thousands of remote work from home jobs and save more than half the cost! <a href="https://www.neowin.net/deals/save-57-off-a-1-yr-subscription-to-flexjobs-now-just-2999">Read more...</a>

## UK public service broadcasters to launch broadband-based live TV service in 2024
 - [https://www.neowin.net/news/uk-public-service-broadcasters-to-launch-broadband-based-live-tv-service-in-2024/](https://www.neowin.net/news/uk-public-service-broadcasters-to-launch-broadband-based-live-tv-service-in-2024/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T12:02:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1660730731_pexels-jeshootscom-1201996_medium.jpg" /></div>UK public service broadcasters including BBC, ITV, Channel 4, and Channel 5 have announced a new TV service called Freely which will replicate the Freeview experience over broadband. <a href="https://www.neowin.net/news/uk-public-service-broadcasters-to-launch-broadband-based-live-tv-service-in-2024">Read more...</a>

## Get this LG 27-inch 240Hz QHD gaming PC monitor for its lowest price ever at Amazon
 - [https://www.neowin.net/deals/get-this-lg-27-inch-240hz-qhd-gaming-pc-monitor-for-its-lowest-price-ever-at-amazon/](https://www.neowin.net/deals/get-this-lg-27-inch-240hz-qhd-gaming-pc-monitor-for-its-lowest-price-ever-at-amazon/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T11:14:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695033758_5d65f1bf-e27f-4c74-8f65-be56fa13914e.__cr0,0,650,350_pt0_sx650_v1____medium.jpg" /></div>This LG Ultragear 27GR83Q 27-inch gaming PC monitor has a fast 240Hz refresh rate and a QHD resolution of 2,560 x 1,440. It&#039;s available at Amazon now for the discounted sales price of $399.99. <a href="https://www.neowin.net/deals/get-this-lg-27-inch-240hz-qhd-gaming-pc-monitor-for-its-lowest-price-ever-at-amazon">Read more...</a>

## Amazon will hold another exclusive sales event, Prime Big Deals Days, on October 10-11
 - [https://www.neowin.net/news/amazon-will-hold-another-exclusive-sales-event-prime-big-deals-days-on-october-10-11/](https://www.neowin.net/news/amazon-will-hold-another-exclusive-sales-event-prime-big-deals-days-on-october-10-11/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T10:26:01+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2023/09/1695031207_amazon-prme-big-deal-days_medium.jpg" /></div>Amazon will get a head start on the holiday shopping season with the upcoming Prime Big Deal Days October 10-11, with deep discounts promised 
 for millions of items for Prime members. <a href="https://www.neowin.net/news/amazon-will-hold-another-exclusive-sales-event-prime-big-deals-days-on-october-10-11">Read more...</a>

## Unity claims it will be "making changes" to its per-install fee policy soon
 - [https://www.neowin.net/news/unity-claims-it-will-be-making-changes-to-its-per-install-fee-policy-soon/](https://www.neowin.net/news/unity-claims-it-will-be-making-changes-to-its-per-install-fee-policy-soon/)
 - RSS feed: https://www.neowin.net/news/rss/
 - date published: 2023-09-18T03:40:02+00:00

<div style="float: left; margin-right: 10px;"><img alt="" src="https://cdn.neowin.com/news/images/uploaded/2022/08/1660567796_10790277_(6)_medium.jpg" /></div>In an unusual late Sunday announcement, Unity says it will be &quot;making changes&quot; to its plans to put in a per-install fee for its runtime software, but it has provided no other details. <a href="https://www.neowin.net/news/unity-claims-it-will-be-making-changes-to-its-per-install-fee-policy-soon">Read more...</a>

