# Source:Wired business, URL:https://www.wired.com/feed/category/business/latest/rss, language:en-US

## The Dark Economics of Russell Brand
 - [https://www.wired.com/story/dark-economics-russell-brand/](https://www.wired.com/story/dark-economics-russell-brand/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-09-18T20:10:14+00:00

Russell Brand has built a massive following on YouTube and Rumble with conspiracy-laden videos. He says the mainstream is out to get him—but is it all just a grift?

## Explore the Ancient Aztec Capital in This Lifelike 3D Rendering
 - [https://www.wired.com/story/explore-tenochtitlan-ancient-aztec-capital-3d-render-thomas-kole/](https://www.wired.com/story/explore-tenochtitlan-ancient-aztec-capital-3d-render-thomas-kole/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-09-18T17:50:48+00:00

We spoke with Thomas Kole, a digital artist who re-created the capital of the Aztec Empire in such detail that it looks like a living metropolis.

## X Challenger Pebble Thinks AI-Generated Posts Can Help Lure Users Away From Elon Musk
 - [https://www.wired.com/story/x-challenger-pebble-thinks-ai-generated-posts-can-lure-users-elon-musk/](https://www.wired.com/story/x-challenger-pebble-thinks-ai-generated-posts-can-lure-users-elon-musk/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-09-18T13:00:00+00:00

To encourage conversation, Twitter-like platform Pebble—formerly T2—now suggests AI-generated updates for users to edit or post. It's also opening sign-ups to anyone with an account on X.

## Pay Transparency Is Sweeping Across the US
 - [https://www.wired.com/story/pay-transparency-is-sweeping-across-us/](https://www.wired.com/story/pay-transparency-is-sweeping-across-us/)
 - RSS feed: https://www.wired.com/feed/category/business/latest/rss
 - date published: 2023-09-18T11:00:00+00:00

New York joined a wave of states that require pay transparency in job ads. New data suggests most US postings now include a salary range, but they are sometimes laughably vague.

