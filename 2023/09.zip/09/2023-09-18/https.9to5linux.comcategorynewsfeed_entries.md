# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## HP Linux Imaging and Printing Drivers Now Support Fedora 38 and Ubuntu 23.04
 - [https://9to5linux.com/hp-linux-imaging-and-printing-drivers-now-support-fedora-38-and-ubuntu-23-04](https://9to5linux.com/hp-linux-imaging-and-printing-drivers-now-support-fedora-38-and-ubuntu-23-04)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-09-18T22:18:18+00:00

<p>HP Linux Imaging and Printing (HPLIP) 3.23.8 drivers are now available for download with support Fedora Linux 38, Ubuntu 23.04, and openSUSE Leap 15.5, as well as support for new printers.</p>
<p>The post <a href="https://9to5linux.com/hp-linux-imaging-and-printing-drivers-now-support-fedora-38-and-ubuntu-23-04" rel="nofollow">HP Linux Imaging and Printing Drivers Now Support Fedora 38 and Ubuntu 23.04</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

