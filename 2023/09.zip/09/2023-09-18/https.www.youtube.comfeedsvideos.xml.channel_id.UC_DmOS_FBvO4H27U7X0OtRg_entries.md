# Source:Fearless & Far, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg, language:en-US

## Ahhhh… should I stop him!? 🔪
 - [https://www.youtube.com/watch?v=IiWTffyXKBs](https://www.youtube.com/watch?v=IiWTffyXKBs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_DmOS_FBvO4H27U7X0OtRg
 - date published: 2023-09-18T15:00:09+00:00

The Mwila are an African tribe living in the country of Angola. They're most commonly known for their unique hairstyles and jewelry using cow dung, sea shells, and beads.

Watch The Full Video: https://www.youtube.com/watch?v=LPziTv654VA

