# Source:The Critical Drinker, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA, language:en-US

## Why Modern Movies Suck - Nobody Can Stay Dead!
 - [https://www.youtube.com/watch?v=QZZRP81gaiM](https://www.youtube.com/watch?v=QZZRP81gaiM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCSJPFQdZwrOutnmSFYtbstA
 - date published: 2023-09-18T21:35:11+00:00

"No one is ever truly gone." Well, that's definitely the mantra for movies these days, where death is treated more like a casual inconvenience than a permanent end for most characters. Join me as I take you on a tour of the worst offenders. 

Grab yourself a Critical Doggo plush! https://www.makeship.com/products/the-critical-doggo-plush

