# Source:Wirtualne Media, URL:https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml, language:pl-PL

## Przemysław Barszcz na czele Booksy Polska
 - [https://www.wirtualnemedia.pl/artykul/przemyslaw-barszcz-booksy-polska-country-manager](https://www.wirtualnemedia.pl/artykul/przemyslaw-barszcz-booksy-polska-country-manager)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-09-18T13:16:53.381950+00:00

Przemysław Barszcz, dotychczasowy head of sales, został country managerem w Booksy Polska. Zastępuje Łukasza Szymaka, który żegna się ze spółką.

## Rekordowy eksport zbóż w ostatnich dwóch latach
 - [https://www.wirtualnemedia.pl/artykul/rekordowy-eksport-zboz-w-ostatnich-dwoch-latach](https://www.wirtualnemedia.pl/artykul/rekordowy-eksport-zboz-w-ostatnich-dwoch-latach)
 - RSS feed: https://www.wirtualnemedia.pl/rss/wm_gospodarka.xml
 - date published: 2023-09-18T05:43:29.751662+00:00

Od stycznia ub. r. do lipca br. Polska wyeksportowała rekordową ilość zbóż - 16,8 mln ton. Tylko w pierwszych 7 miesiącach tego roku wywieziono z kraju 7,7 mln ton ziarna zbóż, o 57 proc. więcej niż przed rokiem - poinformował wiceszef KOWR Marcin Wroński.

