# Source:TVN24 Z kraju, URL:https://tvn24.pl/wiadomosci-z-kraju,3.xml, language:pl-PL

## Europejska prawica znów chce zyskać na kryzysie migracyjnym.  "To, co dzieje się na Lampedusie, to śmierć Europy"
 - [https://fakty.tvn24.pl/fakty-o-swiecie/europejska-prawica-znow-chce-zyskac-na-kryzysie-migracyjnym-to-co-dzieje-sie-na-lampedusie-to-smierc-europy-7349798?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/europejska-prawica-znow-chce-zyskac-na-kryzysie-migracyjnym-to-co-dzieje-sie-na-lampedusie-to-smierc-europy-7349798?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T20:25:54+00:00

<img alt="Europejska prawica znów chce zyskać na kryzysie migracyjnym.  " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-n0euur-1809b066x-fos-los-prawica-reuters-000281-7349783/alternates/LANDSCAPE_1280" />
    Sytuacja w Afryce nie jest wybuchowa, ona już eksplodowała - powiedział szef MSZ Włoch szukając przyczyn kryzysu na Lampedusie. Głównym czynnikiem zaostrzającym sytuację są zmiany klimatyczne i rosyjska blokada Morza Czarnego, przez którą Rosja głodzi państwa afrykańskie zależne od dostaw ukraińskiego zboża. Czy to zbieg okoliczności, że na fali kryzysu migracyjnego znów głośno słychać polityków prawicowych partii, które są mniej lub bardziej otwarcie wspierane przez Władimira Putina?

## Szef MSZ Węgier spotka się z Sergiejem Ławrowem. Zachęca też innych
 - [https://tvn24.pl/swiat/rosja-wegry-peter-szijjarto-spotka-sie-z-sergiejem-lawrowem-zacheca-do-tego-tez-innych-ministrow-europejskich-7349769?source=rss](https://tvn24.pl/swiat/rosja-wegry-peter-szijjarto-spotka-sie-z-sergiejem-lawrowem-zacheca-do-tego-tez-innych-ministrow-europejskich-7349769?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T20:17:08+00:00

<img alt="Szef MSZ Węgier spotka się z Sergiejem Ławrowem. Zachęca też innych " src="https://tvn24.pl/najnowsze/cdn-zdjecie-906fs9-szef-msz-rosji-sergiej-lawrow-7349789/alternates/LANDSCAPE_1280" />
    Spotkam się w tym tygodniu oczywiście z rosyjskim ministrem spraw zagranicznych Sergiejem Ławrowem - przyznał w poniedziałek minister spraw zagranicznych Węgier Peter Szijjarto. Dodał, że chciałby, aby jak najwięcej szefów dyplomacji zachodnioeuropejskich państw zrobiło to samo.

## Tatry. Droga do Morskiego Oka czasowo zamknięta
 - [https://tvn24.pl/tvnmeteo/polska/tatry-morskie-oko-droga-do-morskiego-oka-czasowo-zamknieta-7349704?source=rss](https://tvn24.pl/tvnmeteo/polska/tatry-morskie-oko-droga-do-morskiego-oka-czasowo-zamknieta-7349704?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T19:50:25+00:00

<img alt="Tatry. Droga do Morskiego Oka czasowo zamknięta " src="https://tvn24.pl/najnowsze/cdn-zdjecie-4f600h-beda-remontowac-droge-na-morskie-oko-7340365/alternates/LANDSCAPE_1280" />
    W poniedziałek całkowicie zamknięto kilometrowy odcinek szlaku wiodącego na Morskie Oko. Trasa wiodąca od Wodogrzmotów Mickiewicza do Włosienicy jest modernizowana, rozpoczęła się tam wymiana nawierzchni.

## Gdzie jest burza? Błyska się i grzmi w części kraju
 - [https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-1809-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7349768?source=rss](https://tvn24.pl/tvnmeteo/pogoda/gdzie-jest-burza-burze-w-polsce-w-poniedzialek-1809-sprawdz-gdzie-jest-burza-mapa-i-radar-burz-7349768?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T19:43:57+00:00

<img alt="Gdzie jest burza? Błyska się i grzmi w części kraju" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6qu1x6-burza-piorun-blyskawica-niebo-chmury-6878318/alternates/LANDSCAPE_1280" />
    Gdzie jest burza? W poniedziałek wieczorem pojawiają się nad Polską wyładowania atmosferyczne. Sprawdź, gdzie jest burza, i śledź aktualną sytuację pogodową w Polsce na tvnmeteo.pl.

## Pacjentki doktor Kubisy wzywane na przesłuchania. "Cały czas czuję wściekłość, gniew i niezgodę na to"
 - [https://fakty.tvn24.pl/zobacz-fakty/pacjentki-doktor-kubisy-wzywane-na-przesluchania-caly-czas-czuje-wscieklosc-gniew-i-niezgode-na-to-7349677?source=rss](https://fakty.tvn24.pl/zobacz-fakty/pacjentki-doktor-kubisy-wzywane-na-przesluchania-caly-czas-czuje-wscieklosc-gniew-i-niezgode-na-to-7349677?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T19:29:45+00:00

<img alt="Pacjentki doktor Kubisy wzywane na przesłuchania. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-3h4s1x-180919-kijowska-pn-002732-7349564/alternates/LANDSCAPE_1280" />
    Takie działania zniechęcające do tego, żeby chodzić do lekarza - słychać po tym, jak pacjentki dostają wezwania na przesłuchanie. Chodzi o pacjentki doktor Marii Kubisy, do której gabinetu weszły państwowe służby i zabrały dokumentację zdrowotną 6000 kobiet.

## Hiszpański minister: jestem przeciwny jednostronnym posunięciom w sprawie ukraińskiego zboża
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-zakaz-importu-zboza-hiszpania-chce-jednosci-unii-europejskiej-7349743?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-zakaz-importu-zboza-hiszpania-chce-jednosci-unii-europejskiej-7349743?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T19:27:58+00:00

<img alt="Hiszpański minister: jestem przeciwny jednostronnym posunięciom w sprawie ukraińskiego zboża" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ng49s4-ukraina-zboze-zboze-z-ukrainy-kryzys-zbozowy-kijow-7279490/alternates/LANDSCAPE_1280" />
    Większość państw członkowskich opowiedziała się za potrzebą utrzymania jedności Unii Europejskiej (UE) w związku z handlem ukraińskimi plonami rolnymi - stwierdził hiszpański minister rolnictwa Luis Planas Puchades po spotkaniu w Brukseli. Dodał, że sprzeciwia się jednostronnym posunięciom w tej sprawie - poinformował Reuters. Hiszpania sprawuje obecnie prezydencję w Radzie UE.

## Wszystkie nowe pociągi zamówione dla Kolei Mazowiecki są już na torach
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nowe-pociagi-zamowione-dla-kolei-mazowiecki-sa-juz-na-torach-7349493?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-nowe-pociagi-zamowione-dla-kolei-mazowiecki-sa-juz-na-torach-7349493?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T18:44:18+00:00

<img alt="Wszystkie nowe pociągi zamówione dla Kolei Mazowiecki są już na torach" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-h0z2kx-warszawa-wschodnia-utrudnienia-tory-kolej-koleje-mazowieckie-7308662/alternates/LANDSCAPE_1280" />
    Za ponad 2 miliardy złotych samorząd województwa mazowieckiego kupił 61 pięcioczłonowych elektrycznych zespołów trakcyjnych. W poniedziałek poinformowano, że wszystkie zakupione składy jeżdżą już po torach w barwach Kolei Mazowieckich. - Nikt przed nami nie ogłosił tak dużego i kosztownego zamówienia - mówił wicemarszałek Rafał Rajkowski.

## Dr Kubisa: W tej chwili pacjentki boją się cokolwiek powiedzieć, ja boję się cokolwiek wpisać. Jak leczyć ludzi?
 - [https://tvn24.pl/polska/szczecin-pacjentki-ginekolozki-wzywane-na-przesluchanie-dr-maria-kubisa-w-tej-chwili-pacjentki-boja-sie-cokolwiek-powiedziec-ja-boje-sie-cokolwiek-wpisac-jak-leczyc-ludzi-7349639?source=rss](https://tvn24.pl/polska/szczecin-pacjentki-ginekolozki-wzywane-na-przesluchanie-dr-maria-kubisa-w-tej-chwili-pacjentki-boja-sie-cokolwiek-powiedziec-ja-boje-sie-cokolwiek-wpisac-jak-leczyc-ludzi-7349639?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T18:35:58+00:00

<img alt="Dr Kubisa: W tej chwili pacjentki boją się cokolwiek powiedzieć, ja boję się cokolwiek wpisać. Jak leczyć ludzi?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dne2t4-fpf-1-7349658/alternates/LANDSCAPE_1280" />
    Najbardziej wyraźnie widać na moim przykładzie, jak tajemnice medyczna jest chroniona. W tej chwili pacjentki boją się cokolwiek powiedzieć, ja boję się cokolwiek wpisać. Jak leczyć ludzi? - mówiła w "Faktach po Faktach" w TVN24 dr Maria Kubisa, ginekolożka ze Szczecina. W styczniu CBA zajęło dokumentację jej pacjentek, kalendarz oraz telefon. Pacjentki ginekolog wzywane są na przesłuchanie.

## Opublikowano zdjęcia uszkodzonego rosyjskiego okrętu podwodnego. Eksperci o skali zniszczeń
 - [https://tvn24.pl/najnowsze/rosja-opublikowano-zdjecia-uszkodzonego-rosyjskiego-okretu-podwodnego-rostow-nad-donem-7349681?source=rss](https://tvn24.pl/najnowsze/rosja-opublikowano-zdjecia-uszkodzonego-rosyjskiego-okretu-podwodnego-rostow-nad-donem-7349681?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T18:22:18+00:00

<img alt="Opublikowano zdjęcia uszkodzonego rosyjskiego okrętu podwodnego. Eksperci o skali zniszczeń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-kyj2q2-tat-7349669/alternates/LANDSCAPE_1280" />
    Projekt śledczy Conflict Intelligence Team (CIT) opublikował zdjęcia uszkodzeń rosyjskiego okrętu podwodnego Rostów nad Donem w wyniku ukraińskiego ataku przeprowadzonego w nocy z 12 na 13 września. Zdaniem ukraińskiego portalu wojskowego Defence Express, charakter tych uszkodzeń oznacza "wieloletnie naprawy", których koszt sięgnie "setek milionów dolarów".

## Dinozaur Barry trafi na sprzedaż. Jego szczątki maja 150 milionów lat
 - [https://tvn24.pl/tvnmeteo/swiat/francja-dinozaur-barry-trafi-na-sprzedaz-jego-szczatki-maja-150-milionow-lat-7349503?source=rss](https://tvn24.pl/tvnmeteo/swiat/francja-dinozaur-barry-trafi-na-sprzedaz-jego-szczatki-maja-150-milionow-lat-7349503?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T17:31:36+00:00

<img alt="Dinozaur Barry trafi na sprzedaż. Jego szczątki maja 150 milionów lat" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-t0d7cb-dinozaur-7349521/alternates/LANDSCAPE_1280" />
    Prawie kompletny szkielet kamptozaura zostanie w przyszłym miesiącu sprzedany na aukcji w Paryżu. Szczątki roślinożernego dinozaura mają 150 milionów lat.

## Kolejna wioska wyzwolona. BBC o "kluczach do Bachmutu"
 - [https://tvn24.pl/swiat/bbc-o-wyzwoleniu-kliszczijiwki-klucze-do-bachmutu-7349567?source=rss](https://tvn24.pl/swiat/bbc-o-wyzwoleniu-kliszczijiwki-klucze-do-bachmutu-7349567?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T17:24:57+00:00

<img alt="Kolejna wioska wyzwolona. BBC o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-yuid7e-ukraina-wojsko-7329088/alternates/LANDSCAPE_1280" />
    Wyzwolenie wioski Kliszczijiwka w obwodzie donieckim daje siłom ukraińskim "klucze do Bachmutu" - ocenia postępy na froncie rosyjska redakcja BBC. Obok osady leżą wzgórza, które pozwalają kontrolować leżący w dole Bachmut.

## Pogoda na jutro - wtorek 19.09. Noc przyniesie deszcz, który zostanie z nami w dzień
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-1909noc-przyniesie-deszcz-ktory-zostanie-z-nami-w-dzien-7349470?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jutro-wtorek-1909noc-przyniesie-deszcz-ktory-zostanie-z-nami-w-dzien-7349470?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T16:59:20+00:00

<img alt="Pogoda na jutro - wtorek 19.09. Noc przyniesie deszcz, który zostanie z nami w dzień" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dvri6y-noc-deszcz-tramwaj-ulica-krakow-adobestock_226295332-7140738/alternates/LANDSCAPE_1280" />
    Pogoda na jutro, czyli na wtorek 19.09. Kolejne godziny przyniosą przeważnie pochmurną, deszczową aurę, miejscami zagrzmi. Deszcz i wyładowania towarzyszyć nam będą również w ciągu dnia. Na termometrach zobaczymy od 20 do 24 stopni Celsjusza.

## Miasto doszło do porozumienia z deweloperem. Prace na Wilanowie wznowione
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-miasto-doszlo-do-porozumienia-z-deweloperem-prace-na-wilanowie-wznowione-7349444?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-miasto-doszlo-do-porozumienia-z-deweloperem-prace-na-wilanowie-wznowione-7349444?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:44:14+00:00

<img alt="Miasto doszło do porozumienia z deweloperem. Prace na Wilanowie wznowione" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fkpre8-budowa-linii-tramwajowej-do-wilanowa-7165274/alternates/LANDSCAPE_1280" />
    Pod koniec sierpnia wstrzymano prace na końcowym odcinku budowy linii tramwajowej do Wilanowa. Chodzi o 500-metrowy fragment w ciągu alei Rzeczpospolitej. Powodem jest spór z deweloperem o instalację kanalizacyjną. W poniedziałek rzecznik Tramwajów Warszawskich Maciej Dutkiewicz poinformował, że osiągnięto porozumienie, a prace zostały wznowione.

## Kobiety otrzymują pierwszą pomoc znacznie rzadziej niż mężczyźni. Wyniki badań
 - [https://tvn24.pl/swiat/kanada-kobiety-otrzymuja-pierwsza-pomoc-znacznie-rzadziej-niz-mezczyzni-wyniki-badan-7349355?source=rss](https://tvn24.pl/swiat/kanada-kobiety-otrzymuja-pierwsza-pomoc-znacznie-rzadziej-niz-mezczyzni-wyniki-badan-7349355?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:36:40+00:00

<img alt="Kobiety otrzymują pierwszą pomoc znacznie rzadziej niż mężczyźni. Wyniki badań" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ohnuxv-shutterstock_1009155145-7349387/alternates/LANDSCAPE_1280" />
    Widząc osobę wymagającą resuscytacji krążeniowo-oddechowej, przechodnie podejmują działanie o 28 procent częściej w przypadku mężczyzny niż wtedy, gdy to u kobiety dojdzie do zatrzymania akcji serca - wynika z badania kanadyjskich naukowców. Jakie są tego przyczyny?

## W Strzelnie chcą rozbudować szkołę, a w Krakowie wybudować metro. Bez KPO to jednak niewykonalne
 - [https://fakty.tvn24.pl/fakty-po-poludniu/w-strzelnie-chca-rozbudowac-szkole-a-w-krakowie-wybudowac-metro-bez-kpo-to-jednak-niewykonalne-7349423?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/w-strzelnie-chca-rozbudowac-szkole-a-w-krakowie-wybudowac-metro-bez-kpo-to-jednak-niewykonalne-7349423?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:36:11+00:00

<img alt="W Strzelnie chcą rozbudować szkołę, a w Krakowie wybudować metro. Bez KPO to jednak niewykonalne" src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-exus14-skjleja-7349419/alternates/LANDSCAPE_1280" />
    Elektryczne autobusy, termomodernizacje, nowe szkoły, sale gimnastyczne, linie tramwajowe, a w Krakowie - metro. Jest wiele potrzeb, dziesiątki projektów i wciąż zero euro na KPO. Na pieniądze czekają mieszkańcy i samorządowcy.

## Duży sterowiec zawisł nad Wilanowem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duzy-sterowiec-zawisl-nad-wilanowem-do-kogo-nalezy-7349349?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duzy-sterowiec-zawisl-nad-wilanowem-do-kogo-nalezy-7349349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:17:15+00:00

<img alt="Duży sterowiec zawisł nad Wilanowem " src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ni3c4o-sterowiec-nad-wilanowem-7349431/alternates/LANDSCAPE_1280" />
    W poniedziałek na Zawadach w Wilanowie był widziany sporych rozmiarów statek powietrzny wyglądający jak sterowiec. Krótkie nagranie dokumentujące przelot otrzymaliśmy na Kontakt 24.

## Duży sterowiec zawisł nad Wilanowem. Wiemy, do kogo należy
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duzy-sterowiec-zawisl-nad-wilanowem-wiemy-do-kogo-nalezy-7349349?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-duzy-sterowiec-zawisl-nad-wilanowem-wiemy-do-kogo-nalezy-7349349?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:17:15+00:00

<img alt="Duży sterowiec zawisł nad Wilanowem. Wiemy, do kogo należy" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-ni3c4o-sterowiec-nad-wilanowem-7349431/alternates/LANDSCAPE_1280" />
    W poniedziałek na Zawadach w Wilanowie był widziany sporych rozmiarów statek powietrzny wyglądający jak sterowiec. Krótkie nagranie dokumentujące przelot otrzymaliśmy na Kontakt 24.

## Surfował z pytonem. Teraz musi zapłacić grzywnę
 - [https://tvn24.pl/tvnmeteo/swiat/australia-surfowal-z-pytonem-teraz-musi-zaplacic-grzywne-7349286?source=rss](https://tvn24.pl/tvnmeteo/swiat/australia-surfowal-z-pytonem-teraz-musi-zaplacic-grzywne-7349286?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T15:11:26+00:00

<img alt="Surfował z pytonem. Teraz musi zapłacić grzywnę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-opwx9w-pyton-bredla-morelia-bredli-zdj-przykladowe-7349278/alternates/LANDSCAPE_1280" />
    Surfowanie u wybrzeży Australii w towarzystwie pytona zakończyło się wysoką grzywną. Sytuacja, uwieczniona na popularnym w sieci nagraniu, okazała się łamać obowiązujące w stanie Queensland prawa dotyczące hodowli tego gatunku. Jak tłumaczyli eksperci, takie zachowanie może również być stresujące dla zwierzęcia.

## Rządzący wciąż bagatelizują aferę wizową. "Gdyby pan Rau nie był jedynką, to pewnie byłby odwołany"
 - [https://fakty.tvn24.pl/fakty-po-poludniu/rzadzacy-wciaz-bagatelizuja-afere-wizowa-gdyby-pan-rau-nie-byl-jedynka-to-pewnie-bylby-odwolany-7349361?source=rss](https://fakty.tvn24.pl/fakty-po-poludniu/rzadzacy-wciaz-bagatelizuja-afere-wizowa-gdyby-pan-rau-nie-byl-jedynka-to-pewnie-bylby-odwolany-7349361?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:57:32+00:00

<img alt="Rządzący wciąż bagatelizują aferę wizową. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-qdgagt-1809n234x-f16-skalska-000179-7349357/alternates/LANDSCAPE_1280" />
    Prezes PiS przekonywał w sobotę, że nie ma afery wizowej. Minister Zbigniew Rau również powtarza, że nie ma żadnej afery. On sam nie czuje się współwiny. Tym bardziej nie rozważa dymisji.

## Pięciomiesięczny chłopiec nie żyje. Rodzice usłyszeli zarzuty
 - [https://tvn24.pl/poznan/kalisz-pieciomiesieczny-chlopiec-nie-zyje-rodzice-uslyszeli-zarzuty-7349327?source=rss](https://tvn24.pl/poznan/kalisz-pieciomiesieczny-chlopiec-nie-zyje-rodzice-uslyszeli-zarzuty-7349327?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:13:50+00:00

<img alt="Pięciomiesięczny chłopiec nie żyje. Rodzice usłyszeli zarzuty" src="https://tvn24.pl/najnowsze/cdn-zdjecie484d0bfb21fc09ce0857bc410860f868-pijana-matka-z-klaja-zajmowala-sie-niemowleciem-3513337/alternates/LANDSCAPE_1280" />
    Rodzice przyznali się do braku opieki nad pięciomiesięcznym synkiem, w wyniku czego dziecko zmarło. - Usłyszeli zarzuty – przekazał w poniedziałek rzecznik prasowy Prokuratury Okręgowej w Ostrowie Wlkp. Maciej Meler.

## Jak bardzo się ochłodzi? Pogoda na 5 dni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-jan-rzadzi-pogoda-jak-bardzo-sie-ochlodzi-na-horyzoncie-burze-i-deszcz-7349160?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-5-dni-niz-jan-rzadzi-pogoda-jak-bardzo-sie-ochlodzi-na-horyzoncie-burze-i-deszcz-7349160?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:13:47+00:00

<img alt="Jak bardzo się ochłodzi? Pogoda na 5 dni " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t4pqeb-pojawia-sie-burze-7349291/alternates/LANDSCAPE_1280" />
    W nadchodzących dniach przejdzie przez Polskę chłodny front atmosferyczny. Przyniesie on spore ochłodzenie, a także opady deszczu i burze. Później znów zrobi się ciepło, temperatura sięgnie 29 stopni. W weekend znów czeka nas zmiana.

## KO sześć punktów procentowych od PiS, Konfederacja traci. Najnowszy sondaż
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-najnowszy-sondaz-poparcie-dla-pis-ko-trzeciej-drogi-lewicy-i-konfederacji-7349267?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-2023-najnowszy-sondaz-poparcie-dla-pis-ko-trzeciej-drogi-lewicy-i-konfederacji-7349267?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:08:56+00:00

<img alt="KO sześć punktów procentowych od PiS, Konfederacja traci. Najnowszy sondaż" src="https://tvn24.pl/najnowsze/cdn-zdjecie-3zvh1d-sejm-7290204/alternates/LANDSCAPE_1280" />
    Sześć punktów procentowych dzieli Koalicję Obywatelską od Prawa i Sprawiedliwości - tak wynika z najnowszego sondażu IBRiS dla "Wydarzeń" Polsatu. Według badania PiS może liczyć na 32,6 procent poparcia, a Koalicja Obywatelska - na 26,6 procent. Trzecią Drogę popiera 10,6 procent respondentów, Lewicę - 9,9 procent, a Konfederację - 9,5 procent.

## Ginekolog bez zarzutów i bez telefonu. Śledczy wzywają jej pacjentki na przesłuchania
 - [https://tvn24.pl/szczecin/ginekolog-bez-zarzutow-i-bez-telefonu-sledczy-wzywaja-jej-pacjentki-na-przesluchania-7348698?source=rss](https://tvn24.pl/szczecin/ginekolog-bez-zarzutow-i-bez-telefonu-sledczy-wzywaja-jej-pacjentki-na-przesluchania-7348698?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:08:24+00:00

<img alt="Ginekolog bez zarzutów i bez telefonu. Śledczy wzywają jej pacjentki na przesłuchania" src="https://tvn24.pl/trojmiasto/cdn-zdjecie-c9vl9z-dr-maria-kubisa-o-decyzji-sadu-7256316/alternates/LANDSCAPE_1280" />
    Kolejna pacjentka dr Marii Kubisy, ginekolożki ze Szczecina, została wezwana na przesłuchanie. W styczniu CBA zajęło dokumentację pacjentek, nie przejmując się argumentem o tajemnicy lekarskiej. Zabrano też kalendarz i telefon lekarki.

## 1,5-roczna dziewczynka weszła na jezdnię, jej 3,5-letni brat stał na chodniku. Rodzice byli pijani
 - [https://tvn24.pl/bialystok/sokolka-poltoraroczna-dziewczynka-na-jedni-jej-35-letni-brat-na-chodniku-a-w-domu-i-na-posesji-pijani-rodzice-7349305?source=rss](https://tvn24.pl/bialystok/sokolka-poltoraroczna-dziewczynka-na-jedni-jej-35-letni-brat-na-chodniku-a-w-domu-i-na-posesji-pijani-rodzice-7349305?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T14:00:35+00:00

<img alt="1,5-roczna dziewczynka weszła na jezdnię, jej 3,5-letni brat stał na chodniku. Rodzice byli pijani" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tlcugz-jedno-z-dzieci-bylo-na-jezdni-drugie-na-chodniku-zdjecie-ilustracyjne-7348986/alternates/LANDSCAPE_1280" />
    Przejeżdżający kierowcy zauważyli na jednej z ulic w Sokółce (woj. podlaskie) niespełna półtoraroczną dziewczynkę. Dziecko chodziło po jezdni. Na chodniku stał jej 3,5-letni brat. O wszystkim zostali powiadomieni policjanci, który przejeżdżali nieopodal. Zabrali do aresztu pijanych rodziców. Grozi im do pięciu lat więzienia.

## Dzieci mają WF na korytarzu. Szkoła wymaga rozbudowy. Bez KPO to niemożliwe
 - [https://tvn24.pl/trojmiasto/strzelno-malo-klas-dzieci-cwicza-na-korytarzu-szkola-wymaga-rozbudowy-ale-bez-kpo-to-niemozliwe-7349133?source=rss](https://tvn24.pl/trojmiasto/strzelno-malo-klas-dzieci-cwicza-na-korytarzu-szkola-wymaga-rozbudowy-ale-bez-kpo-to-niemozliwe-7349133?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:50:05+00:00

<img alt="Dzieci mają WF na korytarzu. Szkoła wymaga rozbudowy. Bez KPO to niemożliwe" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qmjw9z-kpo-i-remont-szkoly-7349156/alternates/LANDSCAPE_1280" />
    W Strzelnie (woj. pomorskie), małej wsi na Kaszubach, dzieciom, rodzicom oraz lokalnym władzom marzy się rozbudowa szkoły podstawowej. Najmłodsi od lat czekają na salę gimnastyczną z prawdziwego zdarzenia, tak, by w końcu nie musieli ćwiczyć na szkolnym korytarzu. Inwestycja warta 23 miliony złotych byłaby możliwa ze środków z Krajowego Planu Odbudowy. Pieniędzy jednak nie ma i nie zanosi się na to, by prędko do kraju trafiły. To z kolei opóźnia o kolejne miesiące tę ważną - z punktu widzenia mieszkańców - inwestycję.

## Gliński o dzieciach "w skrajnej biedzie za Tuska" i teraz. Zestawia złe procenty
 - [https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-glinski-o-dzieciach-w-skrajnej-biedzie-za-tuska-i-teraz-zestawia-zle-procenty-st7348074?source=rss](https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-glinski-o-dzieciach-w-skrajnej-biedzie-za-tuska-i-teraz-zestawia-zle-procenty-st7348074?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:49:17+00:00

<img alt="Gliński o dzieciach " src="https://konkret24.tvn24.pl/najnowsze/cdn-zdjecie-87vafd-piotr-glinski-o-biedzie-dzieci-7348731/alternates/LANDSCAPE_1280" />
    Minister kultury przekonywał w radiowym wywiadzie, że za rządów Donalda Tuska w skrajnej biedzie żyło 30 procent polskich dzieci, a teraz już tylko 3-4 procent. Tłumaczymy, skąd wziął takie liczby i dlaczego błędnie je interpretuje.

## Kierowca wjechał w autem w dwie działaczki podczas politycznego festynu. Sprawą zajmuje się policja
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wegrow-kierowca-wjechal-w-autem-w-dwie-dzialaczki-podczas-politycznego-festynu-sprawa-zajmuje-sie-policja-7349243?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wegrow-kierowca-wjechal-w-autem-w-dwie-dzialaczki-podczas-politycznego-festynu-sprawa-zajmuje-sie-policja-7349243?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:43:22+00:00

<img alt="Kierowca wjechał w autem w dwie działaczki podczas politycznego festynu. Sprawą zajmuje się policja" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-yn5jfc-wjechal-w-droge-zamknieta-dla-ruchu-7349244/alternates/LANDSCAPE_1280" />
    Jedna ma obrażenia pięty, bo o jej nogę zahaczyło koło. Druga upadła na mężczyznę na wózku. Dwie działaczki Platformy Obywatelskiej zostały potrącone przez kierowcę auta, który wjechał w nie na festynie w Węgrowie (woj. mazowieckie). Policja prowadzi czynności w kierunku narażenia na niebezpieczeństwo utraty życia albo ciężkiego uszczerbku na zdrowiu. Kierowca był na drodze, która została wyłączona z ruchu.

## Samochód osobowy uderzył w słup
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-samochod-osobowy-uderzyl-w-slup-na-trasie-w-z-7349185?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-samochod-osobowy-uderzyl-w-slup-na-trasie-w-z-7349185?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:21:53+00:00

<img alt="Samochód osobowy uderzył w słup" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-fsbcue-samochod-uderzyl-w-slup-na-trasie-w-z-7349195/alternates/LANDSCAPE_1280" />
    W poniedziałek w nocy samochód osobowy uderzył w słup na trasie W-Z, w pobliżu Starego Miasta. Na miejscu interweniowały służby. Jedna osoba była badana w karetce.

## Sześć dymisji jednego dnia. Ciąg dalszy przetasowań w ukraińskim resorcie obrony
 - [https://tvn24.pl/swiat/ukraina-dymisje-wiceministrow-obrony-7349147?source=rss](https://tvn24.pl/swiat/ukraina-dymisje-wiceministrow-obrony-7349147?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:21:38+00:00

<img alt="Sześć dymisji jednego dnia. Ciąg dalszy przetasowań w ukraińskim resorcie obrony " src="https://tvn24.pl/najnowsze/cdn-zdjecie-5zt3bd-hanna-malar-7348727/alternates/LANDSCAPE_1280" />
    Ukraiński rząd poinformował w poniedziałek o zdymisjonowaniu sześciorga wiceministrów obrony. Wśród nich jest Hanna Malar, która na bieżąco podawała informacje na temat przebiegu kontrofensywy przeciwko wojskom rosyjskim. To kolejne znaczące przetasowanie w ukraińskim resorcie obrony.

## Sprawa Sławomira Nowaka. Dwie grupy zarzutów zostały rozdzielone do odrębnych procesów
 - [https://tvn24.pl/polska/slawomir-nowak-sad-podzielil-sprawe-i-wylaczylz-niej-tak-zwane-polskie-watki-7349149?source=rss](https://tvn24.pl/polska/slawomir-nowak-sad-podzielil-sprawe-i-wylaczylz-niej-tak-zwane-polskie-watki-7349149?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:18:32+00:00

<img alt="Sprawa Sławomira Nowaka. Dwie grupy zarzutów zostały rozdzielone do odrębnych procesów" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d6eji5-slawomir-nowak-5099151/alternates/LANDSCAPE_1280" />
    Dwie grupy zarzutów w sprawie grupy Sławomira Nowaka zostały rozdzielone do odrębnych procesów. Z kwestii ukraińskich - na wniosek obrońców - wyłączono polskie wątki.

## Miasto czeka na pieniądze z KPO. "Dla samorządów to jest ogromna tragedia"
 - [https://tvn24.pl/katowice/cieszyn-czeka-na-pieniadze-z-kpo-to-jest-ogromna-tragedia-7349140?source=rss](https://tvn24.pl/katowice/cieszyn-czeka-na-pieniadze-z-kpo-to-jest-ogromna-tragedia-7349140?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T13:16:51+00:00

<img alt="Miasto czeka na pieniądze z KPO. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-pfi37n-cieszyn-bez-pieniedzy-z-kpo-7349117/alternates/LANDSCAPE_1280" />
    Władze Cieszyna (woj. śląskie) czekają na pieniądze z Krajowego Planu Odbudowy, dzięki którym udałoby się zrealizować aż 32 gotowe projekty. Bez pieniędzy z Unii Europejskiej samorządu nie stać na przykład na modernizację oczyszczalni ścieków, budowę sali gimnastycznej czy zakup nowych autobusów elektrycznych. - Mam nadzieję, że coś się zmieni, bo ta rezygnacja z takich ogromnych środków dla każdego z naszych samorządów to jest ogromna tragedia - mówi burmistrz Cieszyna.

## "Trwa groźna kampania mailowa". Nowe ostrzeżenie
 - [https://tvn24.pl/biznes/z-kraju/cert-polska-ostrzega-przed-mailami-od-oszustow-w-zalaczniku-zlosliwe-oprogramowanie-guloader-7349124?source=rss](https://tvn24.pl/biznes/z-kraju/cert-polska-ostrzega-przed-mailami-od-oszustow-w-zalaczniku-zlosliwe-oprogramowanie-guloader-7349124?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T12:58:33+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qakkx6-ponad-sto-ofiar-oszusta-oferowal-prace-wyludzal-dane-a-potem-bral-pozyczki-zdjecie-ilustracyjne-6878815/alternates/LANDSCAPE_1280" />
    CERT Polska ostrzega przed nowymi działaniami cyberprzestępców. "Trwa groźna kampania mailowa" - poinformowano we wpisie w mediach społecznościowych.

## Mózg czterolatki trwale uszkodzony podczas zabiegu stomatologicznego. Dentystka uznana za winną
 - [https://tvn24.pl/swiat/usa-wyrok-na-dentystke-mozg-czterolatki-uszkodzony-podczas-zabiegustomatologicznego-7349060?source=rss](https://tvn24.pl/swiat/usa-wyrok-na-dentystke-mozg-czterolatki-uszkodzony-podczas-zabiegustomatologicznego-7349060?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T12:50:58+00:00

<img alt="Mózg czterolatki trwale uszkodzony podczas zabiegu stomatologicznego. Dentystka uznana za winną" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fkkxjp-akt-oskarzenia-dla-stomatologa-6117103/alternates/LANDSCAPE_1280" />
    Była dentystka z Houston została uznana za winną nierozważnego spowodowania poważnych obrażeń ciała dziecka. Jak wykazano, podała swojej czteroletniej pacjentce lek uspokajający i przez kilka godzin nie zawiadomiła służb ratunkowych, podczas gdy dziewczynka doznawała kolejnych ataków epilepsji.

## Dramatyczna akcja ratunkowa mężczyzny uwięzionego w zalanym aucie. Nagranie
 - [https://tvn24.pl/tvnmeteo/swiat/atlanta-usa-czlowiek-utknal-w-zalanym-samochodzie-dramatyczna-akcja-ratunkowa-policji-nagranie-7348987?source=rss](https://tvn24.pl/tvnmeteo/swiat/atlanta-usa-czlowiek-utknal-w-zalanym-samochodzie-dramatyczna-akcja-ratunkowa-policji-nagranie-7348987?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T12:28:31+00:00

<img alt="Dramatyczna akcja ratunkowa mężczyzny uwięzionego w zalanym aucie. Nagranie" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-yj48uc-akcja-ratunkowa-po-podtopieniach-w-atlancie-7349105/alternates/LANDSCAPE_1280" />
    Policjanci z Atlanty uratowali mężczyznę uwięzionego w zalanym samochodzie. Moment ten zarejestrowano na nagraniu. W ubiegłym tygodniu miasto nawiedziły potężne ulewy, które spowodowały podtopienia w niektórych dzielnicach. Konieczna była nawet ewakuacja popularnych atrakcji turystycznych.

## 11-latek stracił w powodzi całą rodzinę. "Ocknąłem się na ziemi"
 - [https://tvn24.pl/swiat/derna-11-latek-stracil-w-powodzi-cala-rodzine-ocknalem-sie-na-ziemi-7348778?source=rss](https://tvn24.pl/swiat/derna-11-latek-stracil-w-powodzi-cala-rodzine-ocknalem-sie-na-ziemi-7348778?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T11:54:06+00:00

<img alt="11-latek stracił w powodzi całą rodzinę. " src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-vp40tl-zniszczone-miasto-derna-7346716/alternates/LANDSCAPE_1280" />
    11-letni Yousif jako jedyny z rodziny przeżył katastrofalną powódź w Dernie. Chłopca i jego bliskich woda porwała do morza, ale on został z powrotem wyniesiony przez fale na brzeg.  Opowiadający historię Yousifa portal Sky News pisze o "cudzie".

## Jak sprawdzić swój okręg w wyborach do Senatu?
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-okregi-wyborcze-do-senatu-jak-sprawdzic-swoj-okreg-7345283?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-okregi-wyborcze-do-senatu-jak-sprawdzic-swoj-okreg-7345283?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T11:53:36+00:00

<img alt="Jak sprawdzić swój okręg w wyborach do Senatu?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ai368b-obrady-senatu-7332407/alternates/LANDSCAPE_1280" />
    W wyborach do Senatu Polska podzielona jest na 100 okręgów, odpowiadających liczbie 100 mandatów. Jak sprawdzić jacy kandydaci startują z okręgu w naszym miejscu zamieszkania? Wyjaśniamy.

## Iga Świątek o udziale w wyborach: to obywatelski obowiązek
 - [https://tvn24.pl/polska/wybory-parlamentarne-2023-iga-swiatek-o-udziale-w-wyborach-to-obywatelski-obowiazek-7348945?source=rss](https://tvn24.pl/polska/wybory-parlamentarne-2023-iga-swiatek-o-udziale-w-wyborach-to-obywatelski-obowiazek-7348945?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T11:28:29+00:00

<img alt="Iga Świątek o udziale w wyborach: to obywatelski obowiązek " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ona29b-iga-wybory-7348872/alternates/LANDSCAPE_1280" />
    Każdy świadomy Polak powinien głosować i ogromnie do tego zachęcam - oświadczyła w poniedziałek na konferencji prasowej Iga Świątek. Tenisistka powiedziała, że weźmie udział w jesiennych wyborach parlamentarnych. Nie wyjawiła jednak, na kogo zagłosuje. - Chciałabym, żebym moim tenisem łączyła ludzi - tłumaczyła.

## Tragiczny wypadek. Kierowca stracił panowanie, uderzył w słup i dachował. Nie żyją dwie osoby
 - [https://tvn24.pl/katowice/bierun-tychy-stracil-panowanie-nad-samochodem-uderzyl-w-slup-i-dachowal-nie-zyja-dwie-osoby-7348514?source=rss](https://tvn24.pl/katowice/bierun-tychy-stracil-panowanie-nad-samochodem-uderzyl-w-slup-i-dachowal-nie-zyja-dwie-osoby-7348514?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T10:36:19+00:00

<img alt="Tragiczny wypadek. Kierowca stracił panowanie, uderzył w słup i dachował. Nie żyją dwie osoby" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9altte-tragiczny-wypadek-w-bieruniu-nie-zyja-dwie-osoby-7348435/alternates/LANDSCAPE_1280" />
    Dwie osoby zginęły, a jedna została poważnie ranna w wypadku, do którego doszło w nocy w Bieruniu (woj. śląskie). - Ze wstępnych ustaleń wynika, że kierujący samochodem marki Fiat Panda utracił panowanie nad pojazdem, w wyniku czego uderzył w słup energetyczny, a następnie dachował - informuje policja.

## Skąd wzięła się woda na Księżycu? Swój udział w tym może mieć Ziemia
 - [https://tvn24.pl/tvnmeteo/nauka/woda-na-ksiezycu-skad-sie-wziela-swoj-udzial-w-tym-moze-miec-ziemia-badania-naukowe-7348623?source=rss](https://tvn24.pl/tvnmeteo/nauka/woda-na-ksiezycu-skad-sie-wziela-swoj-udzial-w-tym-moze-miec-ziemia-badania-naukowe-7348623?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:56:38+00:00

<img alt="Skąd wzięła się woda na Księżycu? Swój udział w tym może mieć Ziemia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-tlmuuh-ksiezyc-z-pokladu-iss-7348730/alternates/LANDSCAPE_1280" />
    Woda na Księżycu może mieć ziemskie pochodzenie - przynajmniej częściowo. Jak odkryli badacze, tworzenie się lodu na powierzchni naszego satelity jest napędzane przez elektrony pochodzące także z ziemskiej magnetosfery. Poznanie tych procesów może okazać się kluczowe dla przyszłych, załogowych misji na Księżyc.

## Wyłudzali pieniądze z urzędów miast i gmin. 11 milionów strat
 - [https://tvn24.pl/lodz/lodz-grupa-przestepcza-wyludzila-pieniadze-z-urzedow-miast-i-gmin-11-milionow-strat-7348640?source=rss](https://tvn24.pl/lodz/lodz-grupa-przestepcza-wyludzila-pieniadze-z-urzedow-miast-i-gmin-11-milionow-strat-7348640?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:55:57+00:00

<img alt="Wyłudzali pieniądze z urzędów miast i gmin. 11 milionów strat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-vjgg1q-wyludzali-pieniadze-z-urzedow-miast-i-gmin-11-milionow-strat-7348621/alternates/LANDSCAPE_1280" />
    Policjanci Centralnego Biura Zwalczania Cyberprzestępczości w Łodzi rozbili grupę zajmującą się wyłudzeniami środków pieniężnych z urzędów miast i gmin w całym kraju oraz praniem brudnych pieniędzy. Straty w wyniku działalności przestępców wyniosły łącznie 11 milionów złotych.

## Policja: poranił nożem żonę i dzieci, potem wzniecił w domu pożar. Pastor z zarzutami
 - [https://tvn24.pl/swiat/usa-pastor-ranil-zone-i-dzieci-wzniecil-pozar-w-domu-twierdzi-policja-uslyszal-zarzuty-7348561?source=rss](https://tvn24.pl/swiat/usa-pastor-ranil-zone-i-dzieci-wzniecil-pozar-w-domu-twierdzi-policja-uslyszal-zarzuty-7348561?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:55:46+00:00

<img alt="Policja: poranił nożem żonę i dzieci, potem wzniecił w domu pożar. Pastor z zarzutami" src="https://tvn24.pl/najnowsze/cdn-zdjecie-r609cg-policja-6122194/alternates/LANDSCAPE_1280" />
    Pastor z Shawnee w amerykańskim stanie Kansas usłyszał sześć zarzutów - pięć usiłowania zabójstwa i jeden podpalenia z ryzykiem powstania uszczerbku na zdrowiu. Postawiono je duchownemu po tym, jak jego żona i pięcioro dzieci trafili do szpitala, informuje miejscowa policja. Oskarżony na co dzień pracuje z dziećmi. Na stronie internetowej kościoła, gdzie jest pastorem, opisano go jako "duże dziecko, które uwielbia uczyć małe dzieci o Jezusie".

## Stankiewicz: To nie tylko Wawrzyk i jego Bollywood. Patologii jest znacznie więcej, nad tym systemem nie ma żadnej kontroli
 - [https://tvn24.pl/polska/afera-wizowa-o-co-chodzi-andrzej-stankiewicz-patologii-jest-znacznie-wiecej-nad-tym-systemem-nie-ma-zadnej-kontroli-7348694?source=rss](https://tvn24.pl/polska/afera-wizowa-o-co-chodzi-andrzej-stankiewicz-patologii-jest-znacznie-wiecej-nad-tym-systemem-nie-ma-zadnej-kontroli-7348694?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:44:39+00:00

<img alt="Stankiewicz: To nie tylko Wawrzyk i jego Bollywood. Patologii jest znacznie więcej, nad tym systemem nie ma żadnej kontroli" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aa3mxz-stankiewicz-7348711/alternates/LANDSCAPE_1280" />
    To nie tylko Wawrzyk i jego Bollywood. To jeden z elementów, a patologii jest po prostu znacznie więcej. Nad tym systemem nikt nie ma żadnej kontroli - powiedział w TVN24 zastępca redaktora naczelnego Onetu Andrzej Stankiewicz, autor publikacji dotyczących nieprawidłowości przy wydaniu wiz. Jak mówił, część niespodziewanych nieobecności na listach wyborczych PiS to również skutek tej afery.

## Tyle są warte mieszkania w Polsce. Duży wzrost
 - [https://tvn24.pl/biznes/nieruchomosci/wartosc-mieszkan-w-polsce-narodowy-bank-polski-opublikowal-raport-za-2022-rok-7348610?source=rss](https://tvn24.pl/biznes/nieruchomosci/wartosc-mieszkan-w-polsce-narodowy-bank-polski-opublikowal-raport-za-2022-rok-7348610?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:40:53+00:00

<img alt="Tyle są warte mieszkania w Polsce. Duży wzrost" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xbu27f-gdansk-brzesno-mieszkania-domy-osiedle-morze-baltyk-shutterstock_2169251329-1-6056304/alternates/LANDSCAPE_1280" />
    Na koniec 2022 roku szacowana wartość majątku nieruchomości mieszkaniowych w Polsce wyniosła około 6,5 biliona złotych. Oznacza to wzrost o 12,6 procent rok do roku. Przyczyniły się do tego rosnąca powierzchnia zasobu mieszkań oraz ceny transakcyjne. Tak wynika z raportu opublikowanego przez Narodowy Bank Polski.

## W sobotę powodzie, w niedzielę trąba powietrzna
 - [https://tvn24.pl/tvnmeteo/swiat/francja-w-sobote-powodzie-w-niedziele-traba-powietrzna-wideo-7348598?source=rss](https://tvn24.pl/tvnmeteo/swiat/francja-w-sobote-powodzie-w-niedziele-traba-powietrzna-wideo-7348598?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:25:18+00:00

<img alt="W sobotę powodzie, w niedzielę trąba powietrzna" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-i165nx-traba-powietrzna-w-ernee-7348587/alternates/LANDSCAPE_1280" />
    Ten weekend w niektórych regionach Francji przyniósł niecodzienne zjawiska pogodowe. W niedzielę na zachodzie kraju pojawiła się trąba powietrzna. Zjawisko utworzyło się w pobliżu niewielkiej miejscowości Ernee. Zostało uchwycone na nagraniach. Dzień wcześniej na południu kraju doszło do powodzi.

## Wjechał do rowu i uderzył w drzewo. Dwie osoby ranne
 - [https://tvn24.pl/tvnwarszawa/ulice/dluzniewo-dk10-kierowca-uderzyl-w-drzewo-ranni-i-utrudnienia-7348535?source=rss](https://tvn24.pl/tvnwarszawa/ulice/dluzniewo-dk10-kierowca-uderzyl-w-drzewo-ranni-i-utrudnienia-7348535?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T09:05:55+00:00

<img alt="Wjechał do rowu i uderzył w drzewo. Dwie osoby ranne" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-e8u4h2-wypadek-w-miejscowosci-dluzniewo-7348500/alternates/LANDSCAPE_1280" />
    Dwie osoby zostały ranne po tym, jak kierujący autem osobowym uderzył w przydrożne drzewo w miejscowości Dłużniewo, niedaleko Płocka (Mazowieckie). Ruch na drodze krajowej numer 10 w kierunku Warszawy odbywa się wahadłowo.

## Pesa ją wyprodukowała, a Orlen testuje. Pierwsza taka w Polsce
 - [https://tvn24.pl/biznes/z-kraju/orlen-kupil-od-spolki-pesa-bydgoszcz-lokomotywe-wodorowa-trwaja-testy-7348456?source=rss](https://tvn24.pl/biznes/z-kraju/orlen-kupil-od-spolki-pesa-bydgoszcz-lokomotywe-wodorowa-trwaja-testy-7348456?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T07:42:48+00:00

<img alt="Pesa ją wyprodukowała, a Orlen testuje. Pierwsza taka w Polsce" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-p3029o-orlen-lokomotywa-na-wodor-2-7348436/alternates/LANDSCAPE_1280" />
    Orlen kupił od spółki Pesa Bydgoszcz lokomotywę wodorową - pierwszy tego typu pojazd szynowy w Polsce i rozpoczął jej testy - poinformował w niedzielę koncern.

## Wypadek podczas zlotu aut elektrycznych. Kierowca tesli potrącił fotografa
 - [https://tvn24.pl/tvnwarszawa/najnowsze/zabki-ekozlot-zlot-samochodow-elektrycznych-wypadek-tesli-ranny-fotograf-7348303?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/zabki-ekozlot-zlot-samochodow-elektrycznych-wypadek-tesli-ranny-fotograf-7348303?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T07:41:54+00:00

<img alt="Wypadek podczas zlotu aut elektrycznych. Kierowca tesli potrącił fotografa" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-exndbr-wypadek-podczas-zlotu-aut-elektrycznych-7348345/alternates/LANDSCAPE_1280" />
    W podwarszawskich Ząbkach, podczas wyścigu, który zorganizowano w ramach Zlotu Samochodów Elektrycznych, doszło do wypadku. Kierowca jednego z aut nie wyhamował na mecie i staranował fotografa. Mężczyzna z otwartym złamaniem nogi trafił do szpitala.

## Dzieci w żłobku zatrute fentanylem, jedno nie żyje. Właścicielka placówki oskarżona o morderstwo
 - [https://tvn24.pl/swiat/nowy-jork-podopieczni-zlobka-zatruci-fentanylem-nie-zyje-roczny-chlopiec-wlascicielka-placowki-oskarzona-o-morderstwo-7348431?source=rss](https://tvn24.pl/swiat/nowy-jork-podopieczni-zlobka-zatruci-fentanylem-nie-zyje-roczny-chlopiec-wlascicielka-placowki-oskarzona-o-morderstwo-7348431?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T07:40:39+00:00

<img alt="Dzieci w żłobku zatrute fentanylem, jedno nie żyje. Właścicielka placówki oskarżona o morderstwo" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5rj23u-shutterstock_1272023845-7144490/alternates/LANDSCAPE_1280" />
    36-letnia właścicielka żłobka usłyszała zarzut morderstwa po tym, jak jeden z jej podopiecznych - roczny chłopiec - zmarł, a troje innych dzieci trafiło do szpitala w wyniku prawdopodobnego zatrucia fentanylem. Trwa śledztwo w sprawie.

## Burze będą niepokoić mieszkańców części kraju. Są alerty IMGW
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-prognoza-zagrozen-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-prognoza-zagrozen-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T07:11:24+00:00

<img alt="Burze będą niepokoić mieszkańców części kraju. Są alerty IMGW" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1sc3hf-pochmurno-burze-7312862/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW ostrzegają przed groźnymi zjawiskami. W części kraju spodziewane są burze. Oprócz alertów wydano także prognozę zagrożeń. Sprawdź, gdzie wydano alarmy i gdzie mogą pojawić się kolejne.

## Możliwe alerty IMGW. Miejscami we znaki może dać się wiatr
 - [https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-prognoza-zagrozen-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss](https://tvn24.pl/tvnmeteo/pogoda/mozliwe-alerty-imgw-prognoza-zagrozen-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T07:11:24+00:00

<img alt="Możliwe alerty IMGW. Miejscami we znaki może dać się wiatr" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-g9cccn-silny-wiatr-5425475/alternates/LANDSCAPE_1280" />
    Synoptycy IMGW wydali prognozę zagrożeń. Z komunikatów wynika, że w poniedziałek i wtorek w południowych regionach Polski możliwe są silne porywy wiatru. Sprawdź, gdzie mogą pojawić się alarmy.

## 48. Festiwal Polskich Filmów Fabularnych w Gdyni. Na otwarcie "Doppelgänger. Sobowtór" Jana Holoubka
 - [https://tvn24.pl/kultura-i-styl/48-festiwal-polskich-filmow-fabularnych-w-gdyni-na-otwarcie-doppelganger-sobowtor-jana-holoubka-7348177?source=rss](https://tvn24.pl/kultura-i-styl/48-festiwal-polskich-filmow-fabularnych-w-gdyni-na-otwarcie-doppelganger-sobowtor-jana-holoubka-7348177?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T06:36:03+00:00

<img alt="48. Festiwal Polskich Filmów Fabularnych w Gdyni. Na otwarcie " src="https://tvn24.pl/najnowsze/cdn-zdjecie-aeoklz-kadr-z-filmu-doppelganger-sobowtor-7294921/alternates/LANDSCAPE_1280" />
    Filmem Jana Holoubka "Doppelgänger. Sobowtór" rozpocznie się w poniedziałek wieczorem w Teatrze Muzycznym w Gdyni 48. Festiwal Polskich Filmów Fabularnych. O Złote Lwy w Konkursie Głównym powalczy 16 filmów, które oceni jury pod przewodnictwem reżysera i scenarzysty Filipa Bajona.

## Wycofanie produktu ze znanej sieci z powodu podwyższonego poziomu ołowiu
 - [https://tvn24.pl/biznes/z-kraju/wycofanie-produktu-bransoletka-z-handm-wycofana-z-powodu-olowiu-7348329?source=rss](https://tvn24.pl/biznes/z-kraju/wycofanie-produktu-bransoletka-z-handm-wycofana-z-powodu-olowiu-7348329?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T06:34:18+00:00

<img alt="Wycofanie produktu ze znanej sieci z powodu podwyższonego poziomu ołowiu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2fvcq9-sklep-hm-lapaiirkrapai-shutterstock_2253650681-7348350/alternates/LANDSCAPE_1280" />
    Do Urzędu Ochrony Konkurencji i Konsumentów (UOKiK) wpłynęło zawiadomienie od H&amp;M ( Hennes & Mauritz sp. z o.o. z siedzibą w Warszawie) o wycofaniu ze sprzedaży bransoletki wyprodukowanej we Włoszech z powodu podwyższonej zawartości ołowiu. Była ona sprzedawana przez ponad pół roku.

## Prezydent Andrzej Duda w USA: wierzę, że Polska będzie miała drugą lub trzecią armię w Europie
 - [https://tvn24.pl/swiat/usa-andrzej-duda-spotkal-sie-z-polonia-i-odznaczyl-zasluzonych-dzialaczy-polonijnych-7348220?source=rss](https://tvn24.pl/swiat/usa-andrzej-duda-spotkal-sie-z-polonia-i-odznaczyl-zasluzonych-dzialaczy-polonijnych-7348220?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T06:11:32+00:00

<img alt="Prezydent Andrzej Duda w USA: wierzę, że Polska będzie miała drugą lub trzecią armię w Europie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-htz97u-andrzej-duda-na-ceremonii-w-christ-the-king-high-school-w-nowym-jorku-7348224/alternates/LANDSCAPE_1280" />
    Prezydent Andrzej Duda wyraził nadzieję, że Polska będzie wkrótce miała drugą lub trzecią najsilniejszą armię w Europie. - Czynimy to po to, by polski żołnierz nie musiał walczyć - powiedział w niedzielę podczas spotkania z Polonią w Nowym Jorku. Ocenił, że sytuacja Polski wyglądałaby dużo inaczej, gdyby Polonia nie wywalczyła akcesji Polski do NATO.

## Niż Jan przejmuje pogodowe stery. Przyniesie nam chmury, przelotne opady i ochłodzenie
 - [https://tvn24.pl/tvnmeteo/pogoda/niz-jan-przejmuje-pogodowe-stery-przyniesie-nam-chmury-przelotne-opady-i-ochlodzenie-7348293?source=rss](https://tvn24.pl/tvnmeteo/pogoda/niz-jan-przejmuje-pogodowe-stery-przyniesie-nam-chmury-przelotne-opady-i-ochlodzenie-7348293?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T05:59:48+00:00

<img alt="Niż Jan przejmuje pogodowe stery. Przyniesie nam chmury, przelotne opady i ochłodzenie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-fb8f8h-pochmurno-chlodniej-7348312/alternates/LANDSCAPE_1280" />
    Polska zaczyna dostawać się pod wpływ niżu Jan. Jak poinformowała synoptyk tvnmeteo.pl Arleta Unton-Pyziołek, najbliższej nocy nad naszym krajem znajdzie się chłodny front atmosferyczny. Zrobi się chłodniej, pochmurno, niewykluczone są też przelotne opady deszczu.

## Porwana ciężarówka z najnowszą kolekcją. Dyrektor domu mody mówi "o braku szacunku"
 - [https://tvn24.pl/biznes/najnowsze/francja-skradziono-najnowsza-kolekcje-francuskiego-domu-mody-balmain-7348255?source=rss](https://tvn24.pl/biznes/najnowsze/francja-skradziono-najnowsza-kolekcje-francuskiego-domu-mody-balmain-7348255?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T05:00:54+00:00

<img alt="Porwana ciężarówka z najnowszą kolekcją. Dyrektor domu mody mówi " src="https://tvn24.pl/najnowsze/cdn-zdjecie-kgoze7-wejscie-do-jednego-z-salonow-domu-mody-balmain-7348212/alternates/LANDSCAPE_1280" />
    Dyrektor kreatywny marki Balmain Olivier Rousteing poinformował w niedzielę, że ​​padł ofiarą kradzieży ponad pięćdziesięciu kreacji z jego nowej kolekcji. Miała ona zostać zaprezentowana pod koniec września w ramach Tygodnia Mody w Paryżu.

## Silne trzęsienie ziemi we Włoszech
 - [https://tvn24.pl/tvnmeteo/swiat/silne-trzesienie-ziemi-we-wloszech-7348248?source=rss](https://tvn24.pl/tvnmeteo/swiat/silne-trzesienie-ziemi-we-wloszech-7348248?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T04:57:28+00:00

<img alt="Silne trzęsienie ziemi we Włoszech" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-ogn24o-lokalizacja-epicentrum-trzesienia-ziemi-7348254/alternates/LANDSCAPE_1280" />
    Wstrząsy sejsmiczne obudziły w poniedziałek wielu mieszkańców północnych Włoszech. Na razie nie ma informacji o zniszczeniach oraz poszkodowanych.

## Członkowie ekipy ratunkowej zginęli w wypadku drogowym
 - [https://tvn24.pl/swiat/libia-wypadek-drogowy-smierc-trzech-czlonkow-greckiej-ekipy-ratunkowej-7348201?source=rss](https://tvn24.pl/swiat/libia-wypadek-drogowy-smierc-trzech-czlonkow-greckiej-ekipy-ratunkowej-7348201?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T04:25:57+00:00

<img alt="Członkowie ekipy ratunkowej zginęli w wypadku drogowym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-54i7rw-wypadek-mial-miejsce-w-libii-7348207/alternates/LANDSCAPE_1280" />
    W dotkniętej powodziami Libii w niedzielę w wypadku drogowym zginęło trzech członków greckiej ekipy ratunkowej. Władze kontrolujące wschodnią część kraju poinformowały, że do tragedii doszło wkrótce po ich przybyciu na miejsce.

## Ukraina. Najważniejsze wydarzenia ostatnich godzin
 - [https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-18-wrzesnia-2023-7348234?source=rss](https://tvn24.pl/swiat/ukraina-najwazniejsze-wydarzenia-ostatnich-godzin-18-wrzesnia-2023-7348234?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T04:13:09+00:00

<img alt="Ukraina. Najważniejsze wydarzenia ostatnich godzin" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4flmx8-ukraina-wojsko-7345797/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja na Ukrainę trwa od 572 dni. Dowódca ukraińskich sił lądowych generał Ołeksandr Syrski poinformował w niedzielę, że ukraińskie wojska wyzwoliły miejscowość Kliszczijiwka pod Bachmutem w obwodzie donieckim na wschodzie kraju. W Sewastopolu, na okupowanym przez Rosję Krymie, słychać było w niedzielę wieczorem eksplozje. Oto najważniejsze wydarzenia ostatnich godzin.

## Pięć rzeczy, które warto wiedzieć 18 września
 - [https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-18-wrzesnia-2023-7348232?source=rss](https://tvn24.pl/polska/piec-rzeczy-ktore-warto-wiedziec-18-wrzesnia-2023-7348232?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T03:27:40+00:00

<img alt="Pięć rzeczy, które warto wiedzieć 18 września" src="https://tvn24.pl/najnowsze/cdn-zdjecie-aqgofl-siatkarze-maja-powody-do-radosci-7348233/alternates/LANDSCAPE_1280" />
    W Wieruszowie, mieście nazywanym "Polską w pigułce", odbyły się prawybory. Złota reprezentacja polskich siatkarzy wróciła do kraju z mistrzostw Europy. Prezydent RP Andrzej Duda rozpoczął pięciodniową wizytę w USA. Oto pięć rzeczy, które warto wiedzieć w poniedziałek.

## Syreny alarmowe w Ukrainie. Rosyjski ostrzał zniszczył budynki mieszkalne
 - [https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-18-wrzesnia-2023-roku-7348238?source=rss](https://tvn24.pl/swiat/wojna-rosja-ukraina-relacja-na-zywo-18-wrzesnia-2023-roku-7348238?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T03:18:24+00:00

<img alt="Syreny alarmowe w Ukrainie. Rosyjski ostrzał zniszczył budynki mieszkalne" src="https://tvn24.pl/najnowsze/cdn-zdjecie-uxi729-zniszczenia-pod-charkowem-7321770/alternates/LANDSCAPE_1280" />
    Rosyjska inwazja zbrojna na Ukrainę trwa od 572 dni. Ministerstwo obrony Rosji poinformowało, że w niedzielny wieczór jego siły zestrzeliły ukraińskie drony nad południowo-zachodnim Krymem. W obwodzie charkowskim rosyjski ostrzał zniszczył budynki mieszkalne. W tvn24.pl relacjonujemy najważniejsze wydarzenia z i wokół Ukrainy.

## Pogoda na dziś - poniedziałek, 18.09. Na termometrach od 25 do 29 stopni
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-1809-na-termometrach-od-25-do-29-stopni-7348168?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-dzis-poniedzialek-1809-na-termometrach-od-25-do-29-stopni-7348168?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-z-kraju,3.xml
 - date published: 2023-09-18T00:00:00+00:00

<img alt="Pogoda na dziś - poniedziałek, 18.09. Na termometrach od 25 do 29 stopni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ldps7w-bedzie-pogodnie-5399337/alternates/LANDSCAPE_1280" />
    Pogoda na dziś. Poniedziałek 18.09 przyniesie pogodną aurę, tylko lokalnie może popadać słaby deszcz. Temperatura wyniesie od 25 do 29 stopni Celsjusza. Warunki biometeorologiczne będą przeważnie korzystne.

