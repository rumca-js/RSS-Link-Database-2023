# Source:Kuokka77, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ, language:en-US

## FastTracker music: Oxygener - Hammasharja (GUS PnP clone)
 - [https://www.youtube.com/watch?v=QLmqG1DAf6o](https://www.youtube.com/watch?v=QLmqG1DAf6o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCJKt_QVDyUbqdm3ag_py2eQ
 - date published: 2023-09-18T19:34:29+00:00

"Hammasharja [Short 4min DH98-Edit]" (1998) by Oxygener/Superstars (Jonatan Hazell).
Amiga art "Something Wicked This Way Comes" by Slayer/Ghostown, 3rd at Xenium 2023.

Open Cubic Player 2.6.0pre6 and Gravis Ultrasound PnP clone hardware mixing (InterWave).

