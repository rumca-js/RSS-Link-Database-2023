# Source:The Current, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg, language:en-US

## Kaleo play "Way Down We Go" in studio #live
 - [https://www.youtube.com/watch?v=0DmvIM-5i-s](https://www.youtube.com/watch?v=0DmvIM-5i-s)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-09-18T17:29:26+00:00

Iceland rock band @Kaleoofficial visited The Current in 2016 and "Way Down We Go" was an unmistakable highlight. All of the videos from that session are now among the most popular entries on our YouTube channel and it's easy to see why. The musical chemistry displayed by JJ Júlíusson, Rubin Pollock, Davíð Antonsson, and Daníel Kristjánsson is so powerful.

Watch the full session here: 
https://www.youtube.com/watch?v=WQMU8dYMXao

#kaleo #guitarsolo #alternativerock

## Middle Kids – studio session at The Current (music & interview)
 - [https://www.youtube.com/watch?v=Yndut1-yAE0](https://www.youtube.com/watch?v=Yndut1-yAE0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCAKcSON6PSG_JkTbXh2WdIg
 - date published: 2023-09-18T11:00:34+00:00

Australian band Middle Kids return to The Current studio to play their two latest singles — “Bootleg Firecracker” and “Highlands” — as well as a song from their 2021 album, Today We’re The Greatest.Afterwards, band members Hannah Joy, Tim Fitz and Harry Day chatted with host Jill Riley about the origins of the new songs, the making of the “Bootleg Firecracker” video, and how their friend may have coined a new name for a genre: yearncore.

At the time of their visit to The Current, Middle Kids were touring the U.S. supporting Manchester Orchestra and Jimmy Eat World, giving Middle Kids a chance to play some amazing venues, including Red Rocks in Colorado. They also got to enjoy the comfy amenities of a proper tour bus … although they did experience one leak-related mishap that, were we to sensationalize it, could be construed as a case of yellow journalism (ahem).

Watch and listen to the entire session above.

Video Segments
00:00:00 Highlands
00:03:26: Bootleg Firecracker
00:06:34 S

