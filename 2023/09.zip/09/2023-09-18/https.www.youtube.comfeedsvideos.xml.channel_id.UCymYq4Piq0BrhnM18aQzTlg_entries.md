# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## The Likely Cause of Invalid Traffic Demonetization & YouTube's Silence with @FamilyTech​
 - [https://www.youtube.com/watch?v=xGo0DqhHoEA](https://www.youtube.com/watch?v=xGo0DqhHoEA)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2023-09-18T22:45:01+00:00

Check out Sarah's channel:@FamilyTech - After doing some research I think the likely cause of YouTube's invalid traffic demonetization effort has to do with kids being tracked through "made for kids" videos. Once identified advertisers are looking for refunds on any ad the accounts in questioned consumed - even from videos not "made for kids." Unfortunately small creators seem to be the collateral damage. See more commentary like this: https://www.youtube.com/playlist?list=PLCZHp4d1HnIsJJ0Gy1ENvGjbCp7PslRyz and subscribe! http://lon.tv/s

See part 1 here: https://www.youtube.com/watch?v=cnAfCQAIqbk

VIDEO INDEX:
00:00 - Intro
00:47 - Recap
01:33 - Why is YouTube Silent on Invalid Traffic?
02:39 - Advertising Inventory Problems
07:13 - YouTube Shorts Contributing to the Problem
09:51 - Kid Targeting *Likely* Cause of Invalid Traffic Demonetization
12:51 - Google's AntiTrust Suit
13:51 - Interview with Sarah Kimmel / Familytech
20:42 - Conclusion

Visit my Blog! https://blog.lon.tv

Su

