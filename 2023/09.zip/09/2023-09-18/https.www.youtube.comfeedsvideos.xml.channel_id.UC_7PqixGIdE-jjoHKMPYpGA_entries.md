# Source:Uwaga! Naukowy Bełkot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA, language:pl-PL

## Tajemnica łupieżu - dlaczego nie wszyscy go mamy?
 - [https://www.youtube.com/watch?v=9Zkhjsdpc_4](https://www.youtube.com/watch?v=9Zkhjsdpc_4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_7PqixGIdE-jjoHKMPYpGA
 - date published: 2023-09-18T16:29:47+00:00

Kup moją nową książkę!
📚📚📚 7 CZĄSTECZEK 📚📚📚 
wejdź na https://siedem.alt.pl

👉 Patronite ► https://patronite.pl/NaukowyBelkot 
📚 Moja pierwsza książka ► https://altenberg.pl/geny/
📚 Książka dla dzieci ► https://naukowybelkot.pl/product/zestaw-ksiazek-naukowy-prezent
📚 E-book ► https://tinyurl.com/pnp-ebook
🎧 Mix audio ► http://ratstudios.pl/

Mniej więcej połowa z nas na pewnym etapie życia doświadczy łupieżu. Nie skłamię pisząc, że będzie on wywołany obecnością na naszych skalpach pewnego drożdżaka. Tylko - grzyb żyje na każdym znasz. Dlaczego więc wszyscy nie mamy ciągle łupieżu?

===
Rozkład jazdy:

0:00 Ogólnie
1:20 Dlaczego grzyb żyje na naszej głowie?
5:40 Dlaczego miewamy łupież?
8:00 A może stres...
9:10 Dlaczego tylko wybrani?
11:34 Mikrobiom

===
Źródła (wybrane):

B. Dreno i in. - Microbiome in healthy skin, update for dermatologists
Y. Meray i in. - Putting It All Together to Understand the Role of Malassezia spp. in Dandruff Etiology
E. A. Grice i in. - Host–microbe inte

