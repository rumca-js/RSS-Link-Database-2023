# Source:BBC tech, URL:http://feeds.bbci.co.uk/news/technology/rss.xml, language:en-US

## Call of Duty Warzone: Does UK esports scene need more live events?
 - [https://www.bbc.co.uk/news/newsbeat-66842867?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-66842867?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/technology/rss.xml
 - date published: 2023-09-18T12:45:29+00:00

The Call of Duty Warzone world champs were crowned in London at an interesting time for the UK scene.

