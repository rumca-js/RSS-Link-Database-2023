# Source:SAMTIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw, language:en-US

## Apple Responds to iPhone 12 Radiation Problem
 - [https://www.youtube.com/watch?v=10ORPWnBCoU](https://www.youtube.com/watch?v=10ORPWnBCoU)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCd6vEDS3SOhWbXZrxbrf_bw
 - date published: 2023-09-18T17:00:01+00:00

Apple responds to France trying to ban the iPhone 12 for having dangerous radiation levels. Turns out you might be holding it wrong!

ARTICLE: https://www.engadget.com/apple-will-release-software-update-to-address-iphone-12-radiation-concerns-173345891.html

Apple Responds PLAYLIST: https://www.youtube.com/playlist?list=PLHSLJI8oVymx9_2zl0u4pyjUwhP1lhyLd

-----------------------------------

SUPPORT: https://funkytime.tv/patriot-signup/
MERCH: https://funkytime.tv/shop/
FUNKY TIME WEBSITE: https://funkytime.tv

FACEBOOK: http://www.facebook.com/SamtimeNews
TWITTER: http://twitter.com/SamtimeNews
INSTAGRAM: http://instagram.com/samtimenews

-----------------------------------

'Escape the ordinary. Embrace the FUNKY!'

-----------------------------------

For sponsorship enquiries: samtime@bossmgmtgrp.com
For other business enquiries: business@funkytime.tv
Copyright FUNKY TIME PRODUCTIONS 2023

