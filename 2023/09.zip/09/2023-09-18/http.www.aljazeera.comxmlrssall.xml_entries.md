# Source:Aljazeera, URL:http://www.aljazeera.com/xml/rss/all.xml, language:en-US

## Netanyahu talks to Elon Musk in California about anti-Semitism on X
 - [https://www.aljazeera.com/economy/2023/9/18/netanyahu-talks-to-elon-musk-in-california-about-anti-semitism-on-x?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/18/netanyahu-talks-to-elon-musk-in-california-about-anti-semitism-on-x?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T21:01:08+00:00

Netanyahu’s high-profile visit comes at a time when Musk is facing accusations of tolerating anti-Semitism on X.

## Canada investigating possible link between India, killing of Sikh activist
 - [https://www.aljazeera.com/news/2023/9/18/canada-investigating-possible-link-between-india-killing-of-sikh-activist?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/canada-investigating-possible-link-between-india-killing-of-sikh-activist?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T19:46:42+00:00

Justin Trudeau calls on Indian government to cooperate with probe into Hardeep Singh Nijjar&#039;s killing in Canada in June.

## China’s foreign minister holds talks with Russia’s Lavrov in Moscow
 - [https://www.aljazeera.com/news/2023/9/18/chinas-foreign-minister-holds-talks-with-russias-lavrov-in-moscow?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/chinas-foreign-minister-holds-talks-with-russias-lavrov-in-moscow?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T19:45:44+00:00

Wang Yi and Sergey Lavrov share a commitment to a &#039;multipolar world&#039; in their discussion in Moscow.

## What level of risk is posed by a new wave of COVID-19 cases?
 - [https://www.aljazeera.com/program/inside-story/2023/9/18/what-level-of-risk-is-posed-by-a-new-wave-of-covid-19-cases?traffic_source=rss](https://www.aljazeera.com/program/inside-story/2023/9/18/what-level-of-risk-is-posed-by-a-new-wave-of-covid-19-cases?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T19:35:27+00:00

World Health Organization records 1.4 million new infections during July and August, up 80 percent from previous month.

## Iran-US prisoner swap: How Democrats and Republicans reacted to the deal
 - [https://www.aljazeera.com/news/2023/9/18/iran-us-prisoner-swap-how-democrats-and-republicans-reacted-to-the-deal?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/iran-us-prisoner-swap-how-democrats-and-republicans-reacted-to-the-deal?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T19:24:12+00:00

Republicans decry the exchange as US officials hail the release of detainees and warn Americans against travel to Iran.

## UK police receive sex assault allegation following Russell Brand reports
 - [https://www.aljazeera.com/news/2023/9/18/uk-police-receive-sex-assault-allegation-following-russell-brand-reports?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/uk-police-receive-sex-assault-allegation-following-russell-brand-reports?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T19:19:02+00:00

Police receive a report of a sexual assault alleged to have taken place in Soho, London, in 2003.

## ‘How do you lose an F-35?’: US military still searching for missing jet
 - [https://www.aljazeera.com/news/2023/9/18/how-do-you-lose-an-f-35-us-military-still-searching-for-missing-jet?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/how-do-you-lose-an-f-35-us-military-still-searching-for-missing-jet?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T18:59:17+00:00

US military says search for missing F-35 fighter jet centred around two large lakes near Charleston, South Carolina.

## Libyan survivors protest against authorities after flood disaster in Derna
 - [https://www.aljazeera.com/gallery/2023/9/18/libyan-survivors-protest-against-authorities-after-flood-disaster-in-derna?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/18/libyan-survivors-protest-against-authorities-after-flood-disaster-in-derna?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T18:45:48+00:00

Survivors have protested in Derna, demanding accountability one week after a flood killed thousands.

## Moroccan girls face threat of sexual assault, forced marriage after quake
 - [https://www.aljazeera.com/news/2023/9/18/moroccan-girls-face-threat-of-sexual-assault-forced-marriage-after-quake?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/moroccan-girls-face-threat-of-sexual-assault-forced-marriage-after-quake?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T18:39:22+00:00

Concerns are rife about trafficking, menstrual hygiene and securing safe childbirth.

## Bus plummets down slope, kills at least 24 passengers in Peru
 - [https://www.aljazeera.com/news/2023/9/18/bus-plummets-down-slope-kills-at-least-24-passengers-in-peru?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/bus-plummets-down-slope-kills-at-least-24-passengers-in-peru?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T18:34:53+00:00

The crash is the latest deadly accident on Peru&#039;s roadways, which have seen an increase in traffic-related fatalities.

## A day in the life of the American dream
 - [https://www.aljazeera.com/opinions/2023/9/18/a-day-in-the-life-of-the-american-dream?traffic_source=rss](https://www.aljazeera.com/opinions/2023/9/18/a-day-in-the-life-of-the-american-dream?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T16:48:35+00:00

Many who come to the US face a cruel reality of poverty and suffering; and yet the American dream delusion persists.

## Airport in Iraq’s Kurdish region hit by deadly drone attack
 - [https://www.aljazeera.com/news/2023/9/18/airport-in-iraqs-kurdish-region-hit-by-deadly-drone-attack?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/airport-in-iraqs-kurdish-region-hit-by-deadly-drone-attack?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T16:44:57+00:00

Airport near Sulaymaniyah targeted as Al Jazeera&#039;s Mahmoud Abdelwahed says the identity of the victims still not known.

## Barry Bennell, former coach and serial paedophile, dies in UK prison
 - [https://www.aljazeera.com/news/2023/9/18/barry-bennell-former-coach-and-serial-pedophile-dies-in-uk-prison?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/barry-bennell-former-coach-and-serial-pedophile-dies-in-uk-prison?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T16:34:05+00:00

The youth football coach was sentenced in 2018 on 50 counts of abusing boys between the years of 1979 and 1991.

## US-Iran prisoner swap ‘important first step’ but tensions remain: Analysts
 - [https://www.aljazeera.com/news/2023/9/18/us-iran-prisoner-swap-important-first-step-but-tensions-remain-analysts?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/us-iran-prisoner-swap-important-first-step-but-tensions-remain-analysts?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T16:09:40+00:00

A major diplomatic breakthrough between Tehran and Washington remains unlikely before 2024 US election, experts say.

## The battle for Taiwan is anything but a game
 - [https://www.aljazeera.com/gallery/2023/9/18/history-illustrated-the-battle-for-taiwan-is-anything-but-a-game?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/18/history-illustrated-the-battle-for-taiwan-is-anything-but-a-game?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T15:51:00+00:00

China, US deploy warships over Taiwan and South China Sea in what risks a military confrontation.

## Jericho’s Tell es-Sultan added to UNESCO World Heritage list
 - [https://www.aljazeera.com/gallery/2023/9/18/jerichos-tell-es-sultan-added-to-unesco-world-heritage-list?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/18/jerichos-tell-es-sultan-added-to-unesco-world-heritage-list?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T15:19:16+00:00

The ruins at Tell es-Sultan have been declared the &#039;oldest fortified city in the world&#039;.

## ‘It works like a balm’: How cricket unifies Sri Lanka in times of crisis
 - [https://www.aljazeera.com/sports/2023/9/18/how-cricket-unifies-sri-lanka-economic-crisis-civil-war?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/18/how-cricket-unifies-sri-lanka-economic-crisis-civil-war?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T14:52:12+00:00

Cricket has been a unifying force and provided respite amid civil war and political and economic crises in Sri Lanka.

## Five Americans land in Doha after release in US-Iran prisoner swap
 - [https://www.aljazeera.com/news/2023/9/18/five-americans-land-in-doha-after-release-in-us-iran-prisoner-swap?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/five-americans-land-in-doha-after-release-in-us-iran-prisoner-swap?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T14:38:14+00:00

Prisoner exchange also includes five Iranians released by the US, and $6bn in Iranian assets unfrozen.

## Amid migration crisis, Italy set to pass stricter measures on arrivals
 - [https://www.aljazeera.com/news/2023/9/18/italy-set-to-pass-stricter-measures-on-migrant-arrivals?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/italy-set-to-pass-stricter-measures-on-migrant-arrivals?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T14:24:09+00:00

Last week, almost 10,000 people arrived on the Italian island of Lampedusa.

## Who are the five American prisoners freed in the Iran-US prisoner swap?
 - [https://www.aljazeera.com/news/2023/9/18/who-are-the-five-american-prisoners-freed-in-the-iran-us-prisoner-swap?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/who-are-the-five-american-prisoners-freed-in-the-iran-us-prisoner-swap?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T14:14:04+00:00

Siamak Namazi, Emad Sharghi and Morad Tahbaz are among US prisoners being released in deal, White House confirms.

## The Libyan journalists providing information in chaos
 - [https://www.aljazeera.com/news/2023/9/18/the-libyan-journalists-providing-information-in-chaos?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/the-libyan-journalists-providing-information-in-chaos?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T14:08:29+00:00

With local media failing to deliver information, independent Libyan reporters cover the dam disaster on their own.

## Hunter Biden sues US tax agency over disclosures of personal information
 - [https://www.aljazeera.com/news/2023/9/18/hunter-biden-sues-us-tax-agency-over-disclosures-of-personal-information?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/hunter-biden-sues-us-tax-agency-over-disclosures-of-personal-information?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T13:47:07+00:00

US president&#039;s son accuses two IRS agents of wrongly sharing his tax information in effort to &#039;embarrass&#039; him.

## Ibtihaj Muhammad: I showed what Muslim women can do in sport
 - [https://www.aljazeera.com/sports/2023/9/18/ibtihaj-muhammad-fencing-olympics-muslim-women-sport?traffic_source=rss](https://www.aljazeera.com/sports/2023/9/18/ibtihaj-muhammad-fencing-olympics-muslim-women-sport?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T13:21:00+00:00

The Olympic medal-winning fencer speaks to Al Jazeera on faith, representation and Islamophobia.

## Fleeing Sudan: A refugee’s journey to Europe
 - [https://www.aljazeera.com/program/witness/2023/9/18/fleeing-sudan-a-refugees-journey-to-europe?traffic_source=rss](https://www.aljazeera.com/program/witness/2023/9/18/fleeing-sudan-a-refugees-journey-to-europe?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T13:20:44+00:00

Daba is determined to cross the English Channel and finish the journey his brother started 17 years ago.

## Russia says it has ‘nothing’ to reveal on Ramzan Kadyrov health rumours
 - [https://www.aljazeera.com/news/2023/9/18/russia-says-it-has-nothing-to-reveal-on-ramzan-kadyrov-health-rumours?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/russia-says-it-has-nothing-to-reveal-on-ramzan-kadyrov-health-rumours?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T12:55:00+00:00

Talk of the Chechen leader&#039;s health grows on social media after unconfirmed reports say he is in a coma.

## UN Sustainable Development Goals in spotlight at General Assembly
 - [https://www.aljazeera.com/news/2023/9/18/un-sustainable-development-goals-in-spotlight-at-general-assembly?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/un-sustainable-development-goals-in-spotlight-at-general-assembly?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T12:48:24+00:00

UN leaders are pushing countries to speed up action on lofty list of 17 goals, from ending poverty to boosting equality.

## Georgia’s security service accuses Ukrainian official of plotting coup
 - [https://www.aljazeera.com/news/2023/9/18/georgias-security-services-accuse-ukrainian-official-of-plotting-coup?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/georgias-security-services-accuse-ukrainian-official-of-plotting-coup?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T12:37:01+00:00

The deputy chief of Ukraine&#039;s military counterintelligence is planning an overthrow of Georgia&#039;s government, it says.

## Where do Morocco and Sudan relations stand with Israel?
 - [https://www.aljazeera.com/news/2023/9/18/where-do-morocco-and-sudan-relations-stand-with-israel?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/where-do-morocco-and-sudan-relations-stand-with-israel?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T12:09:39+00:00

After agreeing to normalise relations with Israel in 2020, Rabat and Khartoum have had varying degrees of progress.

## Truck-bus collision kills 20 people in South Africa’s Limpopo province
 - [https://www.aljazeera.com/news/2023/9/18/truck-bus-collision-kills-20-people-in-south-africas-limpopo-province?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/truck-bus-collision-kills-20-people-in-south-africas-limpopo-province?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T11:55:12+00:00

The victims were mostly workers at one of the biggest diamond mines in the country near the Zimbabwe border.

## Libya floods: Conflicting death tolls, Greek aid workers die in crash
 - [https://www.aljazeera.com/news/2023/9/18/libya-floods-conflicting-death-tolls-greek-aid-workers-die-in-crash?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/libya-floods-conflicting-death-tolls-greek-aid-workers-die-in-crash?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T11:21:45+00:00

The city of Derna in eastern Libya is still digging out and counting the dead after floods struck more than a week ago.

## India parliament meets again amid allegations gov’t ‘undermining’ democracy
 - [https://www.aljazeera.com/news/2023/9/18/india-parliament-meets-again-amid-allegations-govt-undermining-democracy?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/india-parliament-meets-again-amid-allegations-govt-undermining-democracy?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T11:09:22+00:00

Opposition says it is convinced government has &#039;surprise legislations&#039; up its sleeve as it holds special 5-day session.

## Ukraine to sue Poland, Slovakia and Hungary over grain ban: Politico
 - [https://www.aljazeera.com/news/2023/9/18/ukraine-to-sue-poland-slovakia-and-hungary-over-grain-ban-politico?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/ukraine-to-sue-poland-slovakia-and-hungary-over-grain-ban-politico?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T10:39:48+00:00

Poland, Slovakia and Hungary imposed bans after an influx of Ukrainian grain led to local  farmers&#039; protests.

## Iraq increases financial support for Kurdish autonomous region
 - [https://www.aljazeera.com/news/2023/9/18/iraq-increases-financial-support-for-kurdish-autonomous-region?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/iraq-increases-financial-support-for-kurdish-autonomous-region?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T10:30:41+00:00

Decision announced after thousands of people protest over unpaid salaries.

## Iran-US prisoner swap under way
 - [https://www.aljazeera.com/news/2023/9/18/iran-us-prisoner-exchange-under-way?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/iran-us-prisoner-exchange-under-way?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T10:22:27+00:00

Five American and five Iranian prisoners are being released in addition to Iran&#039;s assets frozen due to US sanctions.

## Ibtihaj Muhammad: Hijab and triumph at the Olympics
 - [https://www.aljazeera.com/program/generation-change/2023/9/18/ibtihaj-muhammad-hijab-and-triumph-at-the-olympics?traffic_source=rss](https://www.aljazeera.com/program/generation-change/2023/9/18/ibtihaj-muhammad-hijab-and-triumph-at-the-olympics?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T10:12:46+00:00

The fencer speaks about being the first US Olympian to compete wearing a hijab, and winning in the face of prejudice.

## Humanitarian aid enters Nagorno-Karabakh via Armenia, Azerbaijan
 - [https://www.aljazeera.com/news/2023/9/18/humanitarian-aid-enters-karabakh-via-armenia-azerbaijan?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/humanitarian-aid-enters-karabakh-via-armenia-azerbaijan?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T10:02:47+00:00

Aid supplies resume to the region after a deal between Armenian separatists and Azerbaijan, Baku and the Red Cross say.

## Photos: The earthquake in Morocco that shattered thousands of lives
 - [https://www.aljazeera.com/gallery/2023/9/18/photos-the-earthquake-in-morocco-that-shattered-thousands-of-lives?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/18/photos-the-earthquake-in-morocco-that-shattered-thousands-of-lives?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T09:14:04+00:00

The death toll stands at nearly 3,000 people and injuries number more than 5,600, according to official figures.

## ‘Nowhere else to go’: In India’s Assam, frequent floods hit river islanders
 - [https://www.aljazeera.com/gallery/2023/9/18/photos-nowhere-else-to-go-in-indias-assam-frequent-floods-hit-river-islanders?traffic_source=rss](https://www.aljazeera.com/gallery/2023/9/18/photos-nowhere-else-to-go-in-indias-assam-frequent-floods-hit-river-islanders?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T08:57:55+00:00

An estimated 240,000 people in the northeastern state are dependent on fishing and selling produce on floating islands.

## Landslide in northwest DR Congo kills at least 17 people
 - [https://www.aljazeera.com/news/2023/9/18/landslide-in-northwest-dr-congo-kills-at-least-17-people?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/landslide-in-northwest-dr-congo-kills-at-least-17-people?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T08:00:55+00:00

Congolese authorities say the toll could rise as rescuers sift through mud and rubble of collapsed homes.

## US authorities ask locals for help in finding missing F-35 jet
 - [https://www.aljazeera.com/news/2023/9/18/us-authorities-ask-locals-for-help-in-finding-missing-f-35-jet?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/us-authorities-ask-locals-for-help-in-finding-missing-f-35-jet?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T07:10:29+00:00

Authorities say they are searching for the $80m jet around two lakes in the state of South Carolina.

## Walk away, Justin Trudeau. Canada’s love affair with you is over
 - [https://www.aljazeera.com/opinions/2023/9/18/walk-away-justin-trudeau-canadas-love-affair-with-you-is-over?traffic_source=rss](https://www.aljazeera.com/opinions/2023/9/18/walk-away-justin-trudeau-canadas-love-affair-with-you-is-over?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T06:46:50+00:00

From climate change to foreign affairs, Trudeau has betrayed promises. The sad part? His alternative could be worse.

## China’s Country Garden faces payment deadline after twice dodging default
 - [https://www.aljazeera.com/economy/2023/9/18/chinas-country-garden-faces-payment-deadline-after-twice-dodging-default?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/18/chinas-country-garden-faces-payment-deadline-after-twice-dodging-default?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T05:54:45+00:00

Embattled developer faces deadline to pay $15m as China&#039;s property sector struggles with debt crisis.

## UN General Assembly: What to expect as world leaders gather this week
 - [https://www.aljazeera.com/news/2023/9/18/un-general-assembly-what-to-expect-as-world-leaders-gather-this-week?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/un-general-assembly-what-to-expect-as-world-leaders-gather-this-week?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T05:48:03+00:00

World leaders head to New York to take part in high-level United Nations talks. Here&#039;s all you need to know.

## Taiwan urges China to stop ‘continuous military harassment’
 - [https://www.aljazeera.com/news/2023/9/18/taiwan-urges-china-to-stop-continuous-military-harassment?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/taiwan-urges-china-to-stop-continuous-military-harassment?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T04:56:16+00:00

Appeal comes as 103 Chinese military aircraft and nine navy ships detected around the self-ruled island.

## Netflix, SK Broadband end dispute over network traffic costs
 - [https://www.aljazeera.com/economy/2023/9/18/south-korean-broadband-provider-announces-end-to-dispute-with-netflix?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/18/south-korean-broadband-provider-announces-end-to-dispute-with-netflix?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T04:18:37+00:00

Firms say they have reached a partnership to release joint products and cooperate on artificial intelligence.

## Turkey’s Erdogan asks Musk to build Tesla factory, state-owned media says
 - [https://www.aljazeera.com/economy/2023/9/18/turkeys-erdogan-asks-musk-to-build-tesla-factory-state-owned-media-says?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/18/turkeys-erdogan-asks-musk-to-build-tesla-factory-state-owned-media-says?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T04:02:03+00:00

Turkish president made request while in the US for United Nations General Assembly, Turkish news agency says.

## $250,000 reward offered in search for killer of California deputy sheriff
 - [https://www.aljazeera.com/news/2023/9/18/250000-reward-offered-in-search-for-killer-of-california-deputy-sheriff?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/250000-reward-offered-in-search-for-killer-of-california-deputy-sheriff?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T03:48:56+00:00

Deputy Ryan Clinkunbroomer was shot as he sat in his police car at a traffic light in Palmsdale north of Los Angeles.

## Singapore’s clean image under scrutiny amid money laundering scandal
 - [https://www.aljazeera.com/economy/2023/9/18/singapores-clean-image-under-scrutiny-amid-money-laundering-scandal?traffic_source=rss](https://www.aljazeera.com/economy/2023/9/18/singapores-clean-image-under-scrutiny-amid-money-laundering-scandal?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T03:44:21+00:00

City-state&#039;s anti-money laundering controls in spotlight after arrest of 10 foreigners and seizure of $1.3bn in assets.

## Tens of thousands rally in New York demanding end to fossil fuels
 - [https://www.aljazeera.com/news/2023/9/18/tens-of-thousands-rally-in-new-york-demanding-end-to-fossil-fuels?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/tens-of-thousands-rally-in-new-york-demanding-end-to-fossil-fuels?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T03:08:06+00:00

Organisers say 75,000 people rallied in New York, demanding action to end fossil fuels ahead of UN General Assembly.

## Ukraine recaptures Klishchiivka, second eastern village in three days
 - [https://www.aljazeera.com/news/2023/9/18/ukraine-recaptures-klishchiivka-second-eastern-village-in-three-days?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/ukraine-recaptures-klishchiivka-second-eastern-village-in-three-days?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T02:58:38+00:00

Zelenskyy welcomes breakthrough that analysts say is of &#039;strategic significance&#039; to the war in the east.

## Russia-Ukraine war: List of key events, day 572
 - [https://www.aljazeera.com/news/2023/9/18/russia-ukraine-war-list-of-key-events-day-572?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/russia-ukraine-war-list-of-key-events-day-572?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T01:39:48+00:00

As the war enters its 572nd day, these are the main developments.

## Australian state suspends human rights law to lock up more children
 - [https://www.aljazeera.com/news/2023/9/18/australian-state-suspends-human-rights-law-to-lock-up-more-children?traffic_source=rss](https://www.aljazeera.com/news/2023/9/18/australian-state-suspends-human-rights-law-to-lock-up-more-children?traffic_source=rss)
 - RSS feed: http://www.aljazeera.com/xml/rss/all.xml
 - date published: 2023-09-18T00:12:15+00:00

Experts fear &#039;irreversible harm&#039; to children in Queensland after changes to justice system leave more in detention.

