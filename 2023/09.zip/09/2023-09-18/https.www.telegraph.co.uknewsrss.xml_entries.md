# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## Roger Whittaker: Folk singer dies aged 87
 - [https://www.telegraph.co.uk/news/2023/09/18/roger-whittaker-folk-singer-dies-aged-87/](https://www.telegraph.co.uk/news/2023/09/18/roger-whittaker-folk-singer-dies-aged-87/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-18T22:35:48+00:00



## Monday evening news briefing: Russell Brand 'postpones' tour amid Met Police investigation
 - [https://www.telegraph.co.uk/news/2023/09/18/monday-evening-news-briefing-russell-brand-liz-truss-tories/](https://www.telegraph.co.uk/news/2023/09/18/monday-evening-news-briefing-russell-brand-liz-truss-tories/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-18T16:10:37+00:00



## Russell Brand latest: Comedian 'should face criminal investigation'
 - [https://www.telegraph.co.uk/news/2023/09/18/russell-brand-rape-allegations-latest/](https://www.telegraph.co.uk/news/2023/09/18/russell-brand-rape-allegations-latest/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-18T07:37:00+00:00



## UK weather: Flooded airport closes as half a month’s rain falls in one hour
 - [https://www.telegraph.co.uk/news/2023/09/18/weather-uk-half-month-rainfall-one-hour-met-office-warning/](https://www.telegraph.co.uk/news/2023/09/18/weather-uk-half-month-rainfall-one-hour-met-office-warning/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-18T06:39:40+00:00



