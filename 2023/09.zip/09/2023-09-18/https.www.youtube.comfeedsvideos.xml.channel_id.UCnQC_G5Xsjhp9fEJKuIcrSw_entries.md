# Source:Ben Shapiro, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw, language:en-US

## United Auto Workers Strike, EXPLAINED
 - [https://www.youtube.com/watch?v=ioQhN8LBGow](https://www.youtube.com/watch?v=ioQhN8LBGow)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T23:00:17+00:00

The United Auto Workers announced a strike against Ford, General Motors, and Stellantis. The union is demanding higher wages and “economic and social justice.” It's no coincidence that they're striking while Biden is in office.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1811 - https://youtu.be/lz99fXDsL8g

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Try ZipRecruiter for FREE: https://www.ziprecruiter.com/dailywire

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #UnitedAutoWorkers #Cars #Union #Strike #UAW #UnitedAutoWorkersStrike #UAWStrike #ElectricVehicles #ElectricVehicle #JoeBiden

## Media Attacks Russell Brand
 - [https://www.youtube.com/watch?v=FoXnyz8XXxI](https://www.youtube.com/watch?v=FoXnyz8XXxI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T21:30:01+00:00



## Is THIS Trump's New VP Pick?
 - [https://www.youtube.com/watch?v=Q5bMMQ-oAtI](https://www.youtube.com/watch?v=Q5bMMQ-oAtI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T21:00:09+00:00

Kristi Noem, who has been floated as a potential running mate for Donald Trump, is allegedly having an affair with longtime Donald Trump adviser Corey Lewandowski. Here are my thoughts.

1️⃣ Click here to join the member-exclusive portion of my show: https://get.dailywireplus.com/member-block/ben-shapiro

2️⃣ Become a DailyWire+ member to gain access to movies, shows, documentaries, and more: https://bit.ly/3lfVtwK 

3️⃣ Watch the full episode here: Ep.1811 - https://youtu.be/lz99fXDsL8g

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴Today's Sponsors🔴

Get 40% off for a limited time with promo code BEN. http://www.ShopBeam.com/BEN 

Shape your portfolio with Linqto today: http://www.linqto.com/ben

#BenShapiro #TheBenShapiroShow #News #Politics #DailyWire #KristiNoem #Affair #CoreyLewandowski #DonaldTrump #Republican #CPAC #SouthDakota #Controversy #TrumpNoem #Governor

## This Is Clearly Not the Apple Board
 - [https://www.youtube.com/watch?v=9g3mfxbd6xw](https://www.youtube.com/watch?v=9g3mfxbd6xw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T19:00:03+00:00



## Russell Brand Accused of Rape, Sexual Assault…Ten Years Ago
 - [https://www.youtube.com/watch?v=lz99fXDsL8g](https://www.youtube.com/watch?v=lz99fXDsL8g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T16:30:29+00:00

The Sunday Times reports that four women have accused Russell Brand of rape or sexual assault – and he comes out swinging; Joe Biden’s favorite union shuts down Detroit; and the immigration crisis continues to grow.

Ep.1811

1️⃣ Click here to join the member exclusive portion of my show:  https://bit.ly/41LQK62

2️⃣ Get your Jeremy’s Chocolate here: https://bit.ly/45uzeWf

3️⃣ Watch Episodes 1-4 of Convicting a Murderer here: https://bit.ly/3RbWBPL

👕 Get your Ben Shapiro merch here: https://bit.ly/3TAu2cw

🔴 Today's Sponsors 🔴

ExpressVPN - Get 3 Months FREE of ExpressVPN: https://expressvpn.com/ben

Beam - Get 40% off for a limited time with promo code BEN.
http://www.ShopBeam.com/BEN 

Genucel - Exclusive discount for my listeners! https://genucel.com/Shapiro  

Linqto - Shape your portfolio with Linqto today: http://www.linqto.com/ben 

ZipRecruiter - Try ZipRecruiter for FREE: https://www.ziprecruiter.com/dailywire 

- - -

#BenShapiro #TheBenShapiroShow #News #Politics #DailyW

## Taylor Swift Wins ANOTHER VMA
 - [https://www.youtube.com/watch?v=Md91Pq8cs8I](https://www.youtube.com/watch?v=Md91Pq8cs8I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCnQC_G5Xsjhp9fEJKuIcrSw
 - date published: 2023-09-18T01:00:13+00:00



