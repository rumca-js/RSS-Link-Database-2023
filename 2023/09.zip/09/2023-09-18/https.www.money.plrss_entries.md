# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## "Bezpieczny kredyt" wyhamował. Resort chce oczyścić w ten sposób statystyki
 - [https://www.money.pl/banki/bezpieczny-kredyt-wyhamowal-resort-chce-oczyscic-w-ten-sposob-statystyki-6942987087649472a.html](https://www.money.pl/banki/bezpieczny-kredyt-wyhamowal-resort-chce-oczyscic-w-ten-sposob-statystyki-6942987087649472a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T19:26:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/abab9146-29e1-4743-8170-fd4b0045638b" width="308" /> Liczba wniosków o "Bezpieczny kredyt 2 proc." zmniejszyła się w porównaniu zeszłym tygodniem. Niekoniecznie jednak musi się to wiązać ze spadkiem zainteresowania. To raczej efekt czyszczenia statystyk z "martwych dusz" – pisze "Puls Biznesu".

## W piątek rząd może dostać niepokojący sygnał. Uderzyłby w złotego
 - [https://www.money.pl/gospodarka/w-piatek-rzad-moze-dostac-niepokojacy-sygnal-uderzylby-w-zlotego-6942875202144960a.html](https://www.money.pl/gospodarka/w-piatek-rzad-moze-dostac-niepokojacy-sygnal-uderzylby-w-zlotego-6942875202144960a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T18:04:30+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/3bc84ed8-a70b-49cb-b340-29b3b6810910" width="308" /> Na piątek przegląd ratingu Polski zaplanowała agencja Moody's. Ekonomiści nie spodziewają się radykalnych zmian, ale Moody's może zwrócić uwagę na rosnący deficyt i problemy z Unią oraz opóźnieniem wypłat pieniędzy z KPO. Te wszystkie czynniki mogą podmyć złotego w 2024 r. - pada ostrzeżenie.

## Ukraina reaguje na decyzję Polaków. "Cios, którego się nie spodziewałeś"
 - [https://www.money.pl/gospodarka/ukraina-reaguje-na-decyzje-polakow-cios-ktorego-sie-nie-spodziewales-6942920609262208a.html](https://www.money.pl/gospodarka/ukraina-reaguje-na-decyzje-polakow-cios-ktorego-sie-nie-spodziewales-6942920609262208a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T17:17:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c05f1a50-7e58-49a4-b919-7a5b6baed35b" width="308" /> - Trudno jest patrzeć w oczy naszym rolnikom. I mówić, że Europa blokuje jedyne kanały sprzedaży - tak o decyzji Polski w sprawie zakazu importu zboża mówi ukraińska ministerka ds. integracji z UE. Resort rolnictwa zaś dodaje, że to "cios, którego się nie spodziewałeś".

## Ukraińskie zboże może dotrzeć do Polski pomimo buntu Morawieckiego. Zakaz niewiele zmienia
 - [https://www.money.pl/gospodarka/ukrainskie-zboze-moze-dotrzec-do-polski-pomimo-buntu-morawieckiego-zakaz-niewiele-zmienia-6942833369660032a.html](https://www.money.pl/gospodarka/ukrainskie-zboze-moze-dotrzec-do-polski-pomimo-buntu-morawieckiego-zakaz-niewiele-zmienia-6942833369660032a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T16:35:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/17efce3a-4db6-434c-a47e-1fca103d016d" width="308" /> - Tu i teraz mówię wszystkim rolnikom w całej Polsce: przedłużymy zakaz wwozu ukraińskiego zboża - grzmiał w piątek premier Mateusz Morawiecki w reakcji na decyzję KE. Tyle tylko, że zakaz może mieć marny wpływ na ceny.

## Korespondent dziwi się cenom paliw w Polsce. Rozwiązanie jest proste [OPINIA]
 - [https://www.money.pl/gospodarka/korespondent-dziwi-sie-cenom-paliw-w-polsce-rozwiazanie-jest-proste-opinia-6942869814966912a.html](https://www.money.pl/gospodarka/korespondent-dziwi-sie-cenom-paliw-w-polsce-rozwiazanie-jest-proste-opinia-6942869814966912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T16:01:48+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4b07f647-88ea-4fb5-bbb8-114b3e8cd2de" width="308" /> Korespondent zagranicznej prasy nie mógł się nadziwić spadającym cenom paliw w czasie, gdy ropa drożeje. Tymczasem rozwiązanie i znalezienie odpowiedzi na pytanie, dlaczego tak się dzieje, jest proste – pisze w komentarzu dla money.pl Piotr Kuczyński, główny analityk domu inwestycyjnego Xelion.

## Czesi i Niemcy patrzą na ceny paliwa w Polsce. "Brzmi to niewiarygodnie"
 - [https://www.money.pl/gospodarka/czesi-i-niemcy-patrza-na-ceny-paliwa-w-polsce-brzmi-to-niewiarygodnie-6942869542832768a.html](https://www.money.pl/gospodarka/czesi-i-niemcy-patrza-na-ceny-paliwa-w-polsce-brzmi-to-niewiarygodnie-6942869542832768a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T14:38:44+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5c9943d7-bb7d-4699-8862-6b519df69a4f" width="308" /> "Brzmi to niewiarygodnie, ale to prawda" - tak denik.cz pisze o cenach paliw w Polsce. Choć w Czechach, na Słowacji i w Niemczech rosną, to w Polsce nie. Czeskie i niemieckie media wyliczają, ile można zaoszczędzić na jednym baku, wybierając się do Polski. A Świnoujście potwierdza: turystyka paliwowa kwitnie.

## Polacy chcą pracować na emeryturze. Oto najnowsze badania
 - [https://www.money.pl/emerytury/polacy-chca-pracowac-na-emeryturze-oto-najnowsze-badania-6942811784121024a.html](https://www.money.pl/emerytury/polacy-chca-pracowac-na-emeryturze-oto-najnowsze-badania-6942811784121024a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T11:30:28+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5cbd2988-b8d0-4f09-a815-23af460788b7" width="308" /> Osoby, które są aktywne zawodowo, a jeszcze nie osiągnęły wieku emerytalnego, chcą kontynuować pracę zawodową. Gotowość do pracy częściej wyrażają kobiety niż mężczyźni. I chociaż najważniejszą motywacją są kwestie ekonomiczne, to ponad 40 proc. badanych wskazuje na chęć wyjścia z domu i bycia wśród ludzi. "Praca dodaje mi energii" – deklarowali pracownicy w badaniu OLX Praca i Minds&amp;Roses.

## W Niemczech narasta lęk i gniew. Tak źle nie było od 2012 r.
 - [https://www.money.pl/gospodarka/w-niemczech-narasta-lek-i-gniew-tak-zle-nie-bylo-od-2012-r-6942855899650688a.html](https://www.money.pl/gospodarka/w-niemczech-narasta-lek-i-gniew-tak-zle-nie-bylo-od-2012-r-6942855899650688a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T11:05:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/faee3f44-bdd3-42c8-ac7f-1ed5ad4dc92b" width="308" /> Niemcy muszą płacić najwięcej za swój dług od 2012 r. To jasny sygnał, że za Odrą nie dzieje się najlepiej. Gospodarka naszego sąsiada właśnie weszła w recesję, a obawy i lęki Niemców najlepiej obrazuje sondaż, jakiego niemieckie władze jeszcze nie widziały.

## Ceny ropy szaleją, a w Polsce ewenement. "Paliwo powinno kosztować 7,50 zł"
 - [https://www.money.pl/pieniadze/ceny-ropy-szaleja-a-w-polsce-ewenement-paliwo-powinno-kosztowac-7-50-zl-6942316599442048a.html](https://www.money.pl/pieniadze/ceny-ropy-szaleja-a-w-polsce-ewenement-paliwo-powinno-kosztowac-7-50-zl-6942316599442048a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T10:19:25+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cd1cb38d-0615-4862-bc26-9b10a3cea580" width="308" /> Dawid Czopek, zarządzający Polaris FIZ, sądzi, że diesel na stacjach powinien kosztować nie ok. 6 zł, jak obecnie, ale 7,50 zł. Dlaczego jest tanio? Bo m.in. Orlen obniża ceny, chociaż kurs ropy bije rekordy. - Obniżka nie jest zbyt rynkowa - mówi dr Jakub Bogucki z e-Petrol.

## Policyjne zatrzymania. Akcje chińskiego giganta zanurkowały
 - [https://www.money.pl/gospodarka/policyjne-zatrzymania-akcje-chinskiego-giganta-zanurkowaly-6942850550995584a.html](https://www.money.pl/gospodarka/policyjne-zatrzymania-akcje-chinskiego-giganta-zanurkowaly-6942850550995584a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T10:11:09+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/4a3ddb84-b5ed-477e-ab1c-c78d3be7cd69" width="308" /> Akcje China Evergrande spadły o 25 proc. po zatrzymaniu pracowników zarządzających  majątkiem spółki - informuje Reuters. Najbardziej zadłużony deweloper na świecie stał się symbolem chińskiego kryzysu na rynku nieruchomości.

## ZUS informuje o nowej aplikacji. Służy do wystawiania zwolnień
 - [https://www.money.pl/gospodarka/zus-informuje-o-nowej-aplikacji-sluzy-do-wystawiania-zwolnien-6942840007719552a.html](https://www.money.pl/gospodarka/zus-informuje-o-nowej-aplikacji-sluzy-do-wystawiania-zwolnien-6942840007719552a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T09:28:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/d3a3f2f0-8c00-4083-a8e7-4c9bc50a5711" width="308" /> MZUS dla lekarza to kolejna aplikacja mobilna Zakładu Ubezpieczeń Społecznych. Umożliwia ona szybki dostęp do procesów wystawiania i anulowania zaświadczeń lekarskich przez lekarzy i asystentów medycznych - poinformował w poniedziałek ZUS.

## Ukraina pozwie Polskę, Węgry i Słowację. "Absurdalne restrykcje"
 - [https://www.money.pl/gospodarka/ukraina-pozwie-polske-wegry-i-slowacje-absurdalne-restrykcje-6942823066630848a.html](https://www.money.pl/gospodarka/ukraina-pozwie-polske-wegry-i-slowacje-absurdalne-restrykcje-6942823066630848a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T08:19:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ecdeb360-ea3c-46c1-8ec3-2af3b0929068" width="308" /> Kijów pozwie Polskę, Węgry i Słowację w związku z odmową zniesienia zakazu na ukraińskie produkty rolne -  powiedział przedstawiciel handlowy Ukrainy Taras Kachka dla Politico.

## Mięso z próbówki coraz bliżej. Pierwsze w sprzedaży mają być parówki
 - [https://www.money.pl/gospodarka/mieso-z-probowki-coraz-blizej-pierwsze-w-sprzedazy-maja-byc-parowki-6942821594188416a.html](https://www.money.pl/gospodarka/mieso-z-probowki-coraz-blizej-pierwsze-w-sprzedazy-maja-byc-parowki-6942821594188416a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T08:13:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c242a919-d004-4d09-80a3-7c5473ea4fd1" width="308" /> Niemiecka firma The Cultivated B jest pierwszą firmą ubiegającą się o sprzedaż mięsa hodowanego komórkowo w Europie- informuje serwis innpoland.pl. W Europejskim Urzędzie ds. Bezpieczeństwa Żywności zawnioskowano o zgodę na wprowadzenie do sprzedaży parówki, która ma być połączeniem białek roślinnych z mięsem z probówki.

## Kredytobiorcy czekają na decyzję. "Ogłosimy to oczywiście przed wyborami"
 - [https://www.money.pl/podatki/kredytobiorcy-czekaja-na-decyzje-oglosimy-to-oczywiscie-przed-wyborami-6942806188174016a.html](https://www.money.pl/podatki/kredytobiorcy-czekaja-na-decyzje-oglosimy-to-oczywiscie-przed-wyborami-6942806188174016a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T07:10:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/442d6aad-4d54-408c-9db1-d7bad5f363aa" width="308" /> W ciągu najbliższych dni, przed wyborami, będzie ogłoszona decyzja dotycząca wakacji kredytowych - powiedział w poniedziałek w Polsat News wiceminister finansów Artur Soboń. Dodał, że nie wyklucza przedłużenia zerowej stawki VAT na żywność w przyszłym roku.

## KSeF: Jak zarejestrować się w systemie i rozpocząć działalność?
 - [https://www.money.pl/gospodarka/ksef-jak-zarejestrowac-sie-w-systemie-i-rozpoczac-dzialalnosc-6942800105228928a.html](https://www.money.pl/gospodarka/ksef-jak-zarejestrowac-sie-w-systemie-i-rozpoczac-dzialalnosc-6942800105228928a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T07:02:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5d57fa44-4291-46a0-9cde-dce91f8fd28a" width="308" /> Do lipca 2024 roku Krajowy System e-Faktur pozostaje dobrowolny dla podatników w Polsce, jednak można również korzystać z aplikacji KSeF i środowiska testowego, co ułatwi późniejsze wdrożenie systemu w firmie. Jak zatem zarejestrować się w KSeF i rozpocząć działalność z fakturami ustrukturyzowanymi?

## Volkswagen wstrzyma produkcję samochodów w fabryce w Dreźnie
 - [https://www.money.pl/gospodarka/volkswagen-wstrzyma-produkcje-samochodow-w-fabryce-w-dreznie-6942791726393984a.html](https://www.money.pl/gospodarka/volkswagen-wstrzyma-produkcje-samochodow-w-fabryce-w-dreznie-6942791726393984a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T06:11:47+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/a8abbea0-6d02-4780-93a3-91e9bd9d372f" width="308" /> Bloomberg informuje, że Volkswagen planuje wstrzymać produkcję samochodów w fabryce w Dreźnie. Fabryka, w której w zeszłym roku wyprodukowano 6500 elektrycznych modeli ID.3, będzie nadal działać w pewnym zakresie, a około 300 pracowników otrzyma inne zadania - donosi agencja.

## Węgry mają problem. Już znalazły winnego
 - [https://www.money.pl/gospodarka/wegry-maja-problem-juz-znalazly-winnego-6942783487531648a.html](https://www.money.pl/gospodarka/wegry-maja-problem-juz-znalazly-winnego-6942783487531648a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:38:16+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/49182719-04e9-4d5d-880d-ad16c05cf1c1" width="308" /> Jedyną alternatywą dla dostaw rosyjskiej ropy na Węgry jest rurociąg przez Chorwację, ale jego mała przepustowość i wysokie opłaty tranzytowe uniemożliwiają nam dywersyfikację – stwierdził minister spraw zagranicznych i handlu Węgier Peter Szijjarto w wywiadzie dla agencji Bloomberg.

## Nowa funkcja mObywatela. Ma ułatwić prowadzenie firmy
 - [https://www.money.pl/podatki/nowa-funkcja-mobywatela-ma-ulatwic-prowadzenie-firmy-6942781114424000a.html](https://www.money.pl/podatki/nowa-funkcja-mobywatela-ma-ulatwic-prowadzenie-firmy-6942781114424000a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:28:22+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/8c767d5c-8c2f-4cfb-9e2d-0e02a1b15b41" width="308" /> Resort cyfryzacji zapowiada, że uruchomi nowy moduł mObywatela - mBiznes. Pozwoli on wykonać wszystkie podstawowe czynności związane z prowadzeniem takiej firmy. "ZUS, podatki, zezwolenia, korespondencja z urzędami - to wszystko będzie możliwe bez wychodzenia z biura" - wskazał Janusz Cieszyński.

## PiS składa ważną obietnicę ws. emerytur. "Zostaną bardzo szybko wprowadzone"
 - [https://www.money.pl/emerytury/pis-sklada-wazna-obietnice-ws-emerytur-zostana-bardzo-szybko-wprowadzone-6942780379716224a.html](https://www.money.pl/emerytury/pis-sklada-wazna-obietnice-ws-emerytur-zostana-bardzo-szybko-wprowadzone-6942780379716224a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:25:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/5fd6989e-0c4a-4211-a10f-6abe91d9ef3d" width="308" /> - Wstępnie szacujemy, że w pierwszym roku z emerytur stażowych skorzysta 70 tys. osób - powiedział w poniedziałkowym wydaniu "Naszego Dziennika" wiceminister rodziny i polityki społecznej Stanisław Szwed.

## Zarobki Polaków na emigracji. Widać znaczącą różnicę
 - [https://www.money.pl/gospodarka/zarobki-polakow-na-emigracji-widac-znaczaca-roznice-6942775618398848a.html](https://www.money.pl/gospodarka/zarobki-polakow-na-emigracji-widac-znaczaca-roznice-6942775618398848a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:06:15+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fc6e1da1-519d-45f4-b3e7-660fb6acd7a6" width="308" /> W ubiegłym roku u średnie miesięczne wynagrodzenie brutto Polaków pracujących w Wielkiej Brytanii, Niemczech i Holandii było ponad dwukrotnie wyższe niż w Polsce  - tak wynika z najnowszego raportu przedstawionego przez Narodowy  Bank Polski.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 18.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-18-09-2023-6942774143503040a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-18-09-2023-6942774143503040a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:00:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 18.09.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.6441 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 18.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-18-09-2023-6942774143900288a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-18-09-2023-6942774143900288a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:00:20+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 18.09.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.3961 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 18.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-18-09-2023-6942774137694912a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-18-09-2023-6942774137694912a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 18.09.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.3504 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 18.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-18-09-2023-6942774135433920a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-18-09-2023-6942774135433920a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T05:00:18+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 18.09.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.8526 zł.

## Szykują się kontrole domów, ale już jest problem
 - [https://www.money.pl/gospodarka/wielka-inwentaryzacja-naszych-domow-poczeka-rzad-zapomnial-o-najwazniejszym-6942767453055616a.html](https://www.money.pl/gospodarka/wielka-inwentaryzacja-naszych-domow-poczeka-rzad-zapomnial-o-najwazniejszym-6942767453055616a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T04:32:50+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/ce327b06-885e-4238-b938-9b598198ae54" width="308" /> Wielka inwentaryzacja polskich domów musi poczekać. Na razie nikt nie zapuka do naszych drzwi i nie będzie pytać o stan techniczny budynków. Choć dziś rusza Centralna Ewidencja Emisyjności Budynków, to rząd nie zapewnił finansowania nowych zadań - wskazuje "DGP".

## Napędzili kryzys gazowy. Chevron wznawia pełną produkcję pomimo strajków
 - [https://www.money.pl/gielda/napedzili-kryzys-gazowy-chevron-wznawia-pelna-produkcje-pomimo-strajkow-6942766150527616a.html](https://www.money.pl/gielda/napedzili-kryzys-gazowy-chevron-wznawia-pelna-produkcje-pomimo-strajkow-6942766150527616a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T04:27:43+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e11d17ac-b1fe-448c-9755-b077ac11a1f9" width="308" /> Problemy w australijskich zakładach LNG odbiły się na światowych cenach gazu skroplonego. Trwające strajki oraz awaria pogłębiły niepokoje na rynkach. Australia to główny producent LNG. Chevron poinformował, że wznawia pełną produkcję

## Rząd otwiera kolejną furtkę? Polsce grozi napływ emerytalnych turystów
 - [https://www.money.pl/emerytury/turystyka-emerytalna-jesli-nie-uszczelnimy-systemu-wdepniemy-na-mine-6941835031636608a.html](https://www.money.pl/emerytury/turystyka-emerytalna-jesli-nie-uszczelnimy-systemu-wdepniemy-na-mine-6941835031636608a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-18T03:44:33+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/40455f6d-0f51-474c-9fdc-309386d15387" width="308" /> Jeśli emerytury stażowe wejdą w życie, muszą być skonstruowane tak, by zniechęcały cudzoziemców do masowej turystyki emerytalnej do Polski – ostrzega ekspert. Jednocześnie podkreśla, że nasz system wymaga natychmiastowego uszczelnienia, jak zrobiły to kraje zachodniej Europy.

