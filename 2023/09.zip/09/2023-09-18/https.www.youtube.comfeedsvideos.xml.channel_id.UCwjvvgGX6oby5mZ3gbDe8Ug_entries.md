# Source:China Insights, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug, language:en-US

## A New Sign of China Financial Crisis and the Despair Begins/Bank deposits cannot be withdrawn
 - [https://www.youtube.com/watch?v=fGG-qfCUO5A](https://www.youtube.com/watch?v=fGG-qfCUO5A)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwjvvgGX6oby5mZ3gbDe8Ug
 - date published: 2023-09-18T17:44:43+00:00

#Chinainsights#chinanews 
The Shanghai Commercial Paper Exchange releases commercial paper default data every month. It’s an important window for the outside world to observe the credit risks of Chinese banks. According to July 2023 data released in August, as of July 31, 2023, a total of 2,851 commercial bill acceptors had defaulted, an increase of about 80% from 1,554 in January. Among the defaulters of commercial bills, 271 are branches of state-owned banks and branches of local rural commercial banks, accounting for nearly one-tenth of all banks in China.  

Have questions? Do you have something to share with us about China? We want to hear from you! 
Email: Cinsights.subscription@gmail.com
Facebook www.facebook.com/EyesOnChina.

Your support allows us to produce more high-quality videos. 
Consider donating at https://www.paypal.com/paypalme/ChinaInsights

Copyright @ China Insights 2021. Any illegal reproduction of this content in any form will result in immediate action against

