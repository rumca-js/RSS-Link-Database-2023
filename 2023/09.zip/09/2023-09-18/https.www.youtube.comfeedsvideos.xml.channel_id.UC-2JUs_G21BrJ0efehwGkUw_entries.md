# Source:Scary Pockets, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw, language:en-US

## Big Yellow Taxi | @JoniMitchell | funk cover ft. @TalWilkenfeld
 - [https://www.youtube.com/watch?v=8jm1Zl2Fjd4](https://www.youtube.com/watch?v=8jm1Zl2Fjd4)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2JUs_G21BrJ0efehwGkUw
 - date published: 2023-09-18T13:00:05+00:00

Scary Pockets is headed back to Europe in 2024! Get tickets: https://www.scarypocketsfunk.com
Join the vinyl club by Sept. 30 to get "Jeff" on vinyl: http://modal.scarypocketsfunk.com/patreon
Listen on Spotify: http://modal.scarypocketsfunk.com/spotify

Tip Jar: http://modal.scarypocketsfunk.com/tips
Instagram: http://modal.scarypocketsfunk.com/instagram
Facebook: http://modal.scarypocketsfunk.com/facebook
Discord: http://modal.scarypocketsfunk.com/discord
Subscribe: http://modal.scarypocketsfunk.com/subscribe

A funk cover of Joni Mitchell's "Big Yellow Taxi" by Scary Pockets & Tal Wilkenfeld.

MUSICIAN CREDITS
Lead vocal & Bass: Tal Wilkenfeld
BGVs: DeeDee Foster, Sharlotte Gibson, Charlean Carmon
Drums: Tamir Barzilay
Prophet: Larry Goldings
Wurli: Jack Conte
Guitar: Ryan Lerman

AUDIO CREDITS
Recording Engineer: Caleb Parker
Asst. Engineer: Travis Pavur
Mixing/Mastering: Craig Polasko

VIDEO CREDITS
DP: Ricky Chavez
Camp Op/AC: Merlin Showalter
AC: Alejandro Echevarria
AC: Sammy 

