# Source:Paul Joseph Watson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg, language:en-US

## Imagine this.
 - [https://www.youtube.com/watch?v=iReNQdZRQ9E](https://www.youtube.com/watch?v=iReNQdZRQ9E)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCittVh8imKanO_5KohzDbpg
 - date published: 2023-09-18T19:23:42+00:00

Go to https://tryfum.com/PJW and use code PJW to save an additional 10% off your order today.

INTRO MUSIC: Sagittarius V - Lucidator: http://sagittariusvmusic.bandcamp.com

SUMMIT STORE: http://summit.store
DONATE: https://www.subscribestar.com/paul-joseph-watson
LOCALS (Exclusive content! Ad free): https://pauljosephwatson.locals.com/support
ROKFIN: https://rokfin.com/creator/prisonplanet
NEW MERCH: https://www.pjwshop.com/

BITCOIN WALLET: 3EMQG9EhPkoFbX5F19RTGZs8rPqGYm2mp9
BITCOIN CASH WALLET: qrxhqz9ka423v68qwc7nyqc88q3mx9ea5gcpz88a0l
LITECOIN WALLET: MSs2rWgM571WM3zUnL255gccoQAdz9L6CG
ETHEREUM WALLET: 0x21221F5da5e70F46Bbfa755f89e312daDa51f115 

Rumble: https://rumble.com/c/PJW
Odysee: https://odysee.com/@PaulJosephWatson:5
Anything Goes: https://www.youtube.com/AnythingGoesChannel
Parler: https://parler.com/profile/PJW/posts
Bitchute: https://www.bitchute.com/pauljosephwatson
Telegram: https://t.me/pjwnews
Twitter: https://twitter.com/PrisonPlanet
Minds: https://www.minds.com/

