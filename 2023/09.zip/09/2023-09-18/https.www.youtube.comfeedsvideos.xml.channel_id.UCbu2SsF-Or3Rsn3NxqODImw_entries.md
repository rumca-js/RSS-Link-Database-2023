# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## RGG Like A Dragon Direct Livestream
 - [https://www.youtube.com/watch?v=IzWccA7ygFw](https://www.youtube.com/watch?v=IzWccA7ygFw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-18T20:58:18+00:00

Tune in Sep 19 9PM PT for the latest news, trailers, and more for Like a Dragon: Infinite Wealth and Like a Dragon Gaiden.

#rggstudio #likeadragon

## The Real History of Starfield | Space Exploration
 - [https://www.youtube.com/watch?v=wQlBb0scL3U](https://www.youtube.com/watch?v=wQlBb0scL3U)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-18T19:00:19+00:00

Bethesda's latest major game, Starfield, is finally out. Starfield sees you join Constellation, the last group of space explorers who are trying to discover the purpose of alien artifacts. This is the real history behind Starfield and of space exploration.
#Starfield #RealHistoryOf #GameSpot 

While Starfield takes place in the far future, long after Humans have become a space-faring civilization, the game does take some inspiration from the real history of space exploration. Leading up to the release of Starfield, Bethesda stated the game was inspired by the US and USSR Space Race - which lead to the famous Mercury and Apollo space missions.

The team has described Starfield's aesthetic as "Nasa-Punk", inspired by the real NASA designs of the space-race era, with various space suits from Starfield bearing a resemblance to the Apollo era space suits. In this episode of The Real History Of, host Dave Klein dives deep into the full history of Space Exploration, where we're at today, an

## Payday 3 Everything To Know
 - [https://www.youtube.com/watch?v=d4ocjLObCdc](https://www.youtube.com/watch?v=d4ocjLObCdc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-18T16:30:10+00:00

Payday 3 evolves its formula with a revamped Skills and progression system, new special enemy types, and more. Here is everything you need to know about Payday 3.

Set several years after Payday 2, this third entry puts you back behind the masks of the gang that started it all. Dallas, Hoxton, Chains, and Wolf are forced out of retirement, and this time they'll be pulling off heists in New York City. Although these 4 are veterans and experts at their craft, they’ll now have to deal with cryptocurrency, the dark web and mass surveillance.

At its core, Payday 3 is a first-person team-based shooter in which you pull off heists in order to take home the big bucks. So far the series has been all about executing a plan and adapting your tactics when things inevitably go wrong. Payday 3 is looking to keep that gameplay loop going, albeit with some interesting changes for returning players as well as those who are completely new to the series.

Timestamps:
00:00 - Intro
00:16 - Story
00:59 

## Cyberpunk 2077: Phantom Liberty Everything To Know
 - [https://www.youtube.com/watch?v=exxwJppjo8w](https://www.youtube.com/watch?v=exxwJppjo8w)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-18T15:00:27+00:00

We’re on the cusp of Phantom Liberty, the one-and-only expansion planned for Cyberpunk 2077, and it promises to introduce some sweeping changes and a spy-thriller story starring Idris Elba to the game. Here’s everything you need to know about. 

Phantom Liberty is set in a new area of Night City, where you’ll go deep into the bowels of Dogtown to save the NUSA president in a high-risk mission. Dogtown is home to dangerous gangs, secrets, allies, and high-risk-high-reward gigs. Idris Elba plays FIA Agent Solomon Reed, who you connect with early in the story after the president’s ship is shot down. Keanu Reeves is back playing everyone’s favourite rocker boy Johnny Silverhand. Also joining you on your mission is Songbird, a skilled netrunner whose talents make her extremely valuable to the NUSA.

Phantom Liberty also introduces a brand new Relic skill tree and abilities, as well as over 100 items, including cars, weapons, and cyberware, on top of a plethora of new fashion options. The 

