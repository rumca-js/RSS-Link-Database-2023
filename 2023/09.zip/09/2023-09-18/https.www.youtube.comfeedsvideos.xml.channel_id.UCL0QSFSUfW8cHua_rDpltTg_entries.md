# Source:Call Me Chato, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg, language:en-US

## Ahsoka fans HATE me.
 - [https://www.youtube.com/watch?v=-DkIuwPKDMc](https://www.youtube.com/watch?v=-DkIuwPKDMc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCL0QSFSUfW8cHua_rDpltTg
 - date published: 2023-09-18T11:15:38+00:00

#FormerNetworkExec #CallMeChato #ahsoka 
Boy the Ahsoka Star Wars fans are mean.

Thanks for watching my channel. Please subscribe, SHARE and touch yourselves.

Call Me Chato T-shirt
https://my-store-6121db.creator-spring.com/listing/ppc-cartoon-t-colour

https://twitter.com/PaulChato
http://www.paulchato.com

