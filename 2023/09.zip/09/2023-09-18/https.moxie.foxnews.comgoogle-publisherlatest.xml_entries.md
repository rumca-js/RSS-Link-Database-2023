# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Thousands of minks freed from Pennsylvania fur farm in daring act of vandalism
 - [https://www.foxnews.com/us/thousands-minks-freed-pennsylvania-fur-farm-daring-act-vandalism](https://www.foxnews.com/us/thousands-minks-freed-pennsylvania-fur-farm-daring-act-vandalism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:44:45+00:00

State police in central Pennsylvania reported that one or more individuals deliberately set thousands of minks free from their enclosures at the Richard H. Stahl Sons Inc. fur farm.

## Debris reportedly found in South Carolina after F-35 stealth fighter jet disappearance
 - [https://www.foxnews.com/us/debris-reportedly-found-south-carolina-f-35-stealth-fighter-jet-disappearance](https://www.foxnews.com/us/debris-reportedly-found-south-carolina-f-35-stealth-fighter-jet-disappearance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:42:07+00:00

Debris has been found in Williamsburg County, South Carolina a day after a F-35 jet disappeared in the state on Sunday. The pilot ejected from the aircraft safely.

## Former Missouri police officer sentenced to probation for shooting at fleeing vehicle
 - [https://www.foxnews.com/us/former-missouri-police-officer-sentenced-probation-shooting-fleeing-vehicle](https://www.foxnews.com/us/former-missouri-police-officer-sentenced-probation-shooting-fleeing-vehicle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:41:54+00:00

A former Missouri police officer, Matthew Schanz, has been handed a five-year probation sentence after pleading guilty to second-degree assault.

## Canada expels top Indian diplomat amid probe into alleged links to Sikh activist's assassination
 - [https://www.foxnews.com/world/canada-expels-top-indian-diplomat-probe-alleged-links-sikh-activists-assassination](https://www.foxnews.com/world/canada-expels-top-indian-diplomat-probe-alleged-links-sikh-activists-assassination)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:40:11+00:00

Canada has taken the step of expelling a high-ranking Indian diplomat in the wake of an ongoing probe into the assassination of Sikh activist Hardeep Singh Nijjar in Canada.

## Primarily Haitian migrants force entry into southern Mexican asylum office, seeking documentation
 - [https://www.foxnews.com/world/primarily-haitian-migrants-force-entry-southern-mexican-asylum-office-seeking-documentation](https://www.foxnews.com/world/primarily-haitian-migrants-force-entry-southern-mexican-asylum-office-seeking-documentation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:38:02+00:00

A group of migrants, predominantly hailing from Haiti, forcibly entered an asylum office located in southern Mexico on Monday, as they clamored for essential documentation.

## Arkansas police suspect man shot woman before killing himself, authorities say
 - [https://www.foxnews.com/us/arkansas-police-suspect-man-shot-woman-killing-himself-authorities-say](https://www.foxnews.com/us/arkansas-police-suspect-man-shot-woman-killing-himself-authorities-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:37:13+00:00

Arkansas police suspect that a 25-year-old man fatally shot a woman before turning the gun on himself. Police found both of them dead Sunday from gunshot wounds.

## Hunter Biden lawsuit against IRS a 'frivolous smear' to discourage more whistleblowers, attorney says
 - [https://www.foxnews.com/media/hunter-biden-lawsuit-against-irs-frivolous-smear-discourage-whistleblowers-attorney](https://www.foxnews.com/media/hunter-biden-lawsuit-against-irs-frivolous-smear-discourage-whistleblowers-attorney)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:30:51+00:00

An attorney for IRS agent Gary Shapley responded on &quot;The Story&quot; to a lawsuit from Hunter Biden against the agency, alleging wrongful dissemination of tax information.

## Republicans trade jabs over stopgap spending deal that's dividing House GOP: 'You are wrong'
 - [https://www.foxnews.com/politics/republicans-stopgap-spending-deal-dividing-house-gop](https://www.foxnews.com/politics/republicans-stopgap-spending-deal-dividing-house-gop)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:30:39+00:00

A stopgap spending agreement by two factions of the House GOP made to avoid a government shutdown is exposing cracks within the conference.

## Giants' Saquon Barkley expected to be out several weeks after suffering ankle injury: reports
 - [https://www.foxnews.com/sports/giants-saquon-barkley-expected-be-out-several-weeks-suffering-ankle-injury](https://www.foxnews.com/sports/giants-saquon-barkley-expected-be-out-several-weeks-suffering-ankle-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:18:38+00:00

The New York Giants came away with a miraculous comeback against the Arizona Cardinals on Sunday, but Saquon Barkley will be shelved for weeks with an ankle injury.

## Biden admin unleashes 50-year mining, oil drilling ban across thousands of acres in New Mexico
 - [https://www.foxnews.com/politics/biden-admin-unleashes-50-year-mining-oil-drilling-ban-across-thousands-acres-new-mexico](https://www.foxnews.com/politics/biden-admin-unleashes-50-year-mining-oil-drilling-ban-across-thousands-acres-new-mexico)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:16:01+00:00

The Biden administration is proposing to block off more than 4,000 acres from future mineral development in New Mexico to protect the environment and cultural resources.

## Sinema joins GOP senators on bill to reverse Biden admin's crackdown on school hunting, archery classes
 - [https://www.foxnews.com/politics/sinema-joins-gop-senators-bill-reverse-biden-admins-crackdown-school-hunting-archery-classes](https://www.foxnews.com/politics/sinema-joins-gop-senators-bill-reverse-biden-admins-crackdown-school-hunting-archery-classes)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:12:58+00:00

FIRST ON FOX: The lawmakers who spearheaded the gun control bill President Biden signed last year are introducing legislation to ensure the administration implements it properly.

## Trump blasted online after attack on DeSantis' abortion ban: 'A terrible thing'
 - [https://www.foxnews.com/politics/trump-blasted-online-attack-desantis-abortion-ban-terrible-thing](https://www.foxnews.com/politics/trump-blasted-online-attack-desantis-abortion-ban-terrible-thing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:03:00+00:00

Former President Donald Trump blasted Florida Gov. Ron DeSantis&apos; six-week abortion ban as &quot;a terrible thing&quot; during an MSNBC interview over the weekend.

## Bill Maher reverses decision to bring back show amid strike negotiations, hopes they 'finally get this done'
 - [https://www.foxnews.com/media/bill-maher-reverses-decision-bring-back-show-amid-strike-negotiations-hopes-finally-get-done](https://www.foxnews.com/media/bill-maher-reverses-decision-bring-back-show-amid-strike-negotiations-hopes-finally-get-done)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T18:00:15+00:00

Talk show host Bill Maher has backpedaled on bringing his show back on the air because negotiations have resumed between the writers unions and studios.

## Phil Mickelson shares gambling addiction story to warn bettors during football season: 'I was so distracted'
 - [https://www.foxnews.com/sports/phil-mickelson-shares-gambling-addiction-story-warn-bettors-during-football-season](https://www.foxnews.com/sports/phil-mickelson-shares-gambling-addiction-story-warn-bettors-during-football-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:35:57+00:00

LIV Golf star Phil Mickelson shared his own gambling addiction story to warn bettors as football season, one of the busiest times to gamble during the year, is in full swing.

## Prince William praises Americans for two traits as he visits New York for environmental summit
 - [https://www.foxnews.com/entertainment/prince-william-praises-americans-two-traits-visits-new-york-environmental-summit](https://www.foxnews.com/entertainment/prince-william-praises-americans-two-traits-visits-new-york-environmental-summit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:33:23+00:00

Prince William arrived in New York on Monday for a two-day trip to the U.S. to meet with fellow environmentalists and business leaders.

## Ramaswamy's trolling of Pence for 'copying' his 'revolutionary ideas' gets called out by X fact check
 - [https://www.foxnews.com/politics/ramaswamy-trolling-pence-copying-revolutionary-ideas-called-out-x-fact-check](https://www.foxnews.com/politics/ramaswamy-trolling-pence-copying-revolutionary-ideas-called-out-x-fact-check)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:26:41+00:00

Social media platform X called out Vivek Ramaswamy&apos;s trolling of former Vice President Mike Pence for &quot;copying&quot; his &quot;revolutionary ideas&quot; about shutting down the Education Department.

## Oakland NAACP, local leaders frustrated city missed deadline to apply for retail theft funds amid crime wave
 - [https://www.foxnews.com/us/oakland-naacp-local-leaders-frustrated-city-missed-deadline-apply-retail-theft-funds-amid-crime-wave](https://www.foxnews.com/us/oakland-naacp-local-leaders-frustrated-city-missed-deadline-apply-retail-theft-funds-amid-crime-wave)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:15:55+00:00

Leaders in Oakland, California missed a deadline to apply for funds to fight retail thefts amid a crime wave in the city

## DeSantis hits back at McCarthy for saying he's not on 'same level' as Trump: 'Badge of honor'
 - [https://www.foxnews.com/politics/desantis-hits-back-mccarthy-saying-hes-not-same-level-trump-badge-honor](https://www.foxnews.com/politics/desantis-hits-back-mccarthy-saying-hes-not-same-level-trump-badge-honor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:13:46+00:00

Florida Gov. Ron DeSantis fired back at House Speaker Kevin McCarthy on spending after the Republican leader said that former President Donald Trump will be 2024 GOP presidential nominee and the two aren&apos;t on the &quot;same level.&quot;

## Florida teen attempts to rob bank wearing mask and large pink shower cap: authorities
 - [https://www.foxnews.com/us/florida-teen-attempts-rob-bank-wearing-mask-large-pink-shower-cap-authorities](https://www.foxnews.com/us/florida-teen-attempts-rob-bank-wearing-mask-large-pink-shower-cap-authorities)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:12:37+00:00

The Hillsborough County Sheriff&apos;s Office announced the arrest of a 17-year-old Black male who allegedly attempted to rob a bank on Sept. 6 while wearing a mask and pink shower cap.

## OSHA investigation finds safety violations in Georgia grain silo fatality
 - [https://www.foxnews.com/us/osha-investigation-finds-safety-violations-georgia-grain-silo-fatality](https://www.foxnews.com/us/osha-investigation-finds-safety-violations-georgia-grain-silo-fatality)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:07:10+00:00

Federal authorities have determined the death of a worker who suffocated in a grain silo in Georgia could have been prevented had their employer adhered to safety regulations.

## AI-powered bird feeder takes candid pics, identifies our feathered friends as they snack
 - [https://www.foxnews.com/lifestyle/ai-powered-bird-feeder-candid-pics-birds-identifies-friends-snack](https://www.foxnews.com/lifestyle/ai-powered-bird-feeder-candid-pics-birds-identifies-friends-snack)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:06:32+00:00

An AI-powered bird feeder called Bird Buddy takes snapshots and identifies the species of each bird that lands for a snack. CEO Franci Zidar revealed the technology and its benefits.

## Texas church experiments with AI-generated service, uses ChatGPT for worship, sermon, and original song
 - [https://www.foxnews.com/us/texas-church-experiments-ai-generated-service-uses-chatgpt-worship-sermon-original-song](https://www.foxnews.com/us/texas-church-experiments-ai-generated-service-uses-chatgpt-worship-sermon-original-song)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:03:37+00:00

A church in Austin, Texas stepped into &quot;uncharted territory&quot; last week by using artificial intelligence for worship and an original song.

## 'They were laughing': Woman viciously beaten at Seattle-area gas station over cash, cigs and candy
 - [https://www.foxnews.com/us/laughing-woman-viciously-beaten-seattle-area-gas-station-cash-cigs-candy](https://www.foxnews.com/us/laughing-woman-viciously-beaten-seattle-area-gas-station-cash-cigs-candy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T17:00:40+00:00

Surveillance video shows a brazen robbery and assault at a Seattle-area gas station. Here&apos;s what the victim says about the young suspects who are still at large.

## Hunter Biden tries to avoid in-person arraignment in federal gun charges case
 - [https://www.foxnews.com/politics/hunter-biden-tries-avoid-in-person-arraignment-federal-gun-charges-case](https://www.foxnews.com/politics/hunter-biden-tries-avoid-in-person-arraignment-federal-gun-charges-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:52:52+00:00

Hunter Biden&apos;s lawyers are pushing for him to be able to avoid showing up in-person to his arraignment on federal gun charges, a court order filed Monday shows.

## Hunter Biden suing IRS is like 'screaming at an approaching storm': Turley
 - [https://www.foxnews.com/media/hunter-biden-suing-irs-screaming-approaching-storm-turley](https://www.foxnews.com/media/hunter-biden-suing-irs-screaming-approaching-storm-turley)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:48:31+00:00

FOX News contributor Jonathan Turley tells &apos;America Reports&apos; that Hunter Biden suing the IRS will not impede House Republicans&apos; impeachment inquiry into President Biden.

## Illinois woman arrested for allegedly battering four Chicago cops: police
 - [https://www.foxnews.com/us/illinois-woman-arrested-allegedly-battering-four-chicago-cops-police](https://www.foxnews.com/us/illinois-woman-arrested-allegedly-battering-four-chicago-cops-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:43:24+00:00

Cicero, Illinois resident Esmeralda Aguilar is accused of battering four Chicago Police Department officers early on Sunday, authorities say. She was arrested shortly after the incident.

## Pro-life protestors found guilty of federal charges after invading DC reproductive health care clinic in 2020
 - [https://www.foxnews.com/politics/pro-life-protestors-found-guilty-federal-charges-invading-dc-reproductive-health-care-clinic](https://www.foxnews.com/politics/pro-life-protestors-found-guilty-federal-charges-invading-dc-reproductive-health-care-clinic)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:40:07+00:00

Three pro-life protestors were found guilty of raiding a Washington, D.C. reproductive health care facility and blocking access to the unit, by a jury on Monday.

## Michigan State announces intention to fire Mel Tucker over sexual misconduct allegations
 - [https://www.foxnews.com/sports/michigan-state-announces-intention-fire-mel-tucker-sexual-misconduct-allegations](https://www.foxnews.com/sports/michigan-state-announces-intention-fire-mel-tucker-sexual-misconduct-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:37:32+00:00

Michigan State University announced its intention to fire football coach Mel Tucker as he faces allegations of sexual misconduct involving an activist and rape survivor.

## Central figure in UK soccer child sex abuse scandal, Barry Bennell, dies in prison at age 69
 - [https://www.foxnews.com/world/central-figure-uk-soccer-child-sex-abuse-scandal-barry-bennell-dies-prison-age-69](https://www.foxnews.com/world/central-figure-uk-soccer-child-sex-abuse-scandal-barry-bennell-dies-prison-age-69)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:37:29+00:00

A prominent figure in a child sex abuse scandal that shook professional soccer in England has passed away while in prison, as confirmed by the British government&apos;s justice department.

## Airstrike on northern Iraq military airport kills 3
 - [https://www.foxnews.com/world/airstrike-northern-iraq-military-airport-kills-3](https://www.foxnews.com/world/airstrike-northern-iraq-military-airport-kills-3)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:34:31+00:00

A military airport in Iraq&apos;s semi-autonomous Kurdish region came under attack in an airstrike, resulting in three deaths, according to local officials.

## Mike Pompeo sounds alarm on Iran prisoner swap: 'Terrified' for Americans abroad
 - [https://www.foxnews.com/media/mike-pompeo-sounds-alarm-iran-prisoner-swap-terrified-americans-abroad](https://www.foxnews.com/media/mike-pompeo-sounds-alarm-iran-prisoner-swap-terrified-americans-abroad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:21:09+00:00

Former Secretary of State Mike Pompeo reacts to President Biden&apos;s prisoner swap with Iran, saying the move shows the world &quot;what the price is&quot; for Americans.

## Bills great Takeo Spikes needles team over seating placement for game vs Raiders
 - [https://www.foxnews.com/sports/bills-great-takeo-spikes-needles-team-seating-placement-game-raiders](https://www.foxnews.com/sports/bills-great-takeo-spikes-needles-team-seating-placement-game-raiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T16:07:21+00:00

Former NFL star Takeo Spikes was at the Buffalo Bills&apos; game on Sunday, but he wasn&apos;t happy with where his seats were at the stadium.

## Florida man accused of stealing more than 1,300 gallons of Wawa gas
 - [https://www.foxnews.com/us/florida-man-accused-stealing-more-1300-gallons-wawa-gas](https://www.foxnews.com/us/florida-man-accused-stealing-more-1300-gallons-wawa-gas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:58:38+00:00

Florida suspect Yerrison Perez was arrested on three felony charges of grand theft after officials accused him of stealing more than $9,000 worth of gas from Wawa locations.

## 'Real Housewives' star Shannon Beador arrested for drunken driving
 - [https://www.foxnews.com/entertainment/real-housewives-star-shannon-beador-arrested-drunken-driving](https://www.foxnews.com/entertainment/real-housewives-star-shannon-beador-arrested-drunken-driving)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:56:51+00:00

&quot;Real Housewives of Orange County&quot; star Shannon Beador was arrested and charged with a hit-and-run and a DUI following a crash on Saturday night.

## 8 tips to restore something you accidentally deleted
 - [https://www.foxnews.com/tech/8-tips-restore-something-accidentally-deleted](https://www.foxnews.com/tech/8-tips-restore-something-accidentally-deleted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:43:23+00:00

Kurt &quot;CyberGuy&quot; Knutsson shares some tips and methods on how to restore files that have been accidentally deleted on your computer or smartphone.

## LA County Sheriff Luna: DA Gascon assures aggressive prosecution of suspect in deputy's ambush killing
 - [https://www.foxnews.com/us/la-county-sheriff-luna-da-gascon-assures-aggressive-prosecution-suspect-deputy-ambush-killing](https://www.foxnews.com/us/la-county-sheriff-luna-da-gascon-assures-aggressive-prosecution-suspect-deputy-ambush-killing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:39:03+00:00

Los Angeles County Robert Luna is asking DA George Gascon to prosecute the suspected killer o his deputy

## How to recognize rampant fake tech in online marketplaces
 - [https://www.foxnews.com/tech/recognize-rampant-fake-tech-online-marketplaces](https://www.foxnews.com/tech/recognize-rampant-fake-tech-online-marketplaces)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:38:32+00:00

Kurt &quot;CyberGuy&quot; Knutsson helps you recognize fake items and fake third-party vendors on legitimate retail cites like Walmart and Amazon.

## Julie Chen Moonves turned to God after being forced to leave CBS talk show: ‘Stabbed in the back’
 - [https://www.foxnews.com/media/julie-chen-moonves-turned-god-being-forced-leave-cbs-talk-show-stabbed-back](https://www.foxnews.com/media/julie-chen-moonves-turned-god-being-forced-leave-cbs-talk-show-stabbed-back)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:30:38+00:00

Former &quot;The Talk&quot; host Julie Chen Moonves, the wife of former CBS CEO Les Moonves, credits her relationship with God for getting through a tumultuous period.

## 'The Talk' and 'The Jennifer Hudson Show' cancel premieres last minute, after Drew Barrymore caves to pressure
 - [https://www.foxnews.com/entertainment/the-talk-jennifer-hudson-show-cancel-premieres-last-minute-drew-barrymore-caves-pressure](https://www.foxnews.com/entertainment/the-talk-jennifer-hudson-show-cancel-premieres-last-minute-drew-barrymore-caves-pressure)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:29:10+00:00

After Drew Barrymore announced she was putting her show back on hold amid the ongoing WGA strike, &quot;The Talk&quot; and &quot;The Jennifer Hudson Show&quot; have done the same.

## Former ACLU employee sues organization for violating core values of 'diversity' it espouses, lawsuit alleges
 - [https://www.foxnews.com/politics/former-aclu-employee-sues-organization-violating-core-values-diversity-lawsuit-alleges](https://www.foxnews.com/politics/former-aclu-employee-sues-organization-violating-core-values-diversity-lawsuit-alleges)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:25:22+00:00

Monica Espitia, ACLU veteran, alleges discrimination and retaliation in a lawsuit against ACLU-Hawaii, claiming the organization did not uphold the values it preaches.

## California pilots identified in deadly Reno, Nevada air racing crash
 - [https://www.foxnews.com/us/california-pilots-identified-deadly-reno-nevada-air-racing-crash](https://www.foxnews.com/us/california-pilots-identified-deadly-reno-nevada-air-racing-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:24:32+00:00

The pilots who were killed at the conclusion of an air racing event in Reno, Nevada Sunday afternoon have been identified as two men from California.

## Brother of missing ex-NFL player implores him to 'please come home'
 - [https://www.foxnews.com/sports/brother-missing-ex-nfl-player-implores-him-please-come-home](https://www.foxnews.com/sports/brother-missing-ex-nfl-player-implores-him-please-come-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:24:06+00:00

The brother of missing ex-NFL player Sergio Brown put out a message on his Instagram account after their mother was found dead in an Illinois creek.

## Ohio railroad worker crushed to death by remote-controlled train
 - [https://www.foxnews.com/us/ohio-railroad-worker-crushed-death-remote-controlled-train](https://www.foxnews.com/us/ohio-railroad-worker-crushed-death-remote-controlled-train)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:12:36+00:00

An incident occurred in an Ohio CSX railyard over the weekend where a railroad worker died after being crushed between two railcars by a remote-controlled train.

## Spring tide-induced ocean waves ravage South African coast; 2 dead, several injured
 - [https://www.foxnews.com/world/spring-tide-induced-ocean-waves-ravage-south-african-coast-2-dead-several-injured](https://www.foxnews.com/world/spring-tide-induced-ocean-waves-ravage-south-african-coast-2-dead-several-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:09:54+00:00

Coastal regions of South Africa experienced large ocean waves generated by a &quot;spring tide&quot; over the weekend, resulting in two fatalities and injuries to several individuals.

## Search underway for suspects in Boston housing development shooting that injured 5
 - [https://www.foxnews.com/us/search-underway-suspects-boston-housing-development-shooting-injured-5](https://www.foxnews.com/us/search-underway-suspects-boston-housing-development-shooting-injured-5)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:06:39+00:00

Authorities are searching for suspects following a shooting incident that occurred on Sunday that resulted in injuries to five individuals, including a critically wounded teenage girl.

## Taliban detains 18 NGO staff, including foreigner, in Afghanistan amid ongoing scrutiny
 - [https://www.foxnews.com/world/taliban-detains-18-ngo-staff-including-foreigner-afghanistan-ongoing-scrutiny](https://www.foxnews.com/world/taliban-detains-18-ngo-staff-including-foreigner-afghanistan-ongoing-scrutiny)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:05:30+00:00

The Taliban have taken into custody 18 individuals, including a foreign national, who were associated with a non-governmental organization (NGO) operating in Afghanistan.

## How to protect your Mac from new MetaStealer malware
 - [https://www.foxnews.com/tech/protect-mac-new-metastealer-malware](https://www.foxnews.com/tech/protect-mac-new-metastealer-malware)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:05:00+00:00

Kurt &quot;CyberGuy&quot; Knutsson shows you how to protect your Mac computer from a new malware strain called MetaStealer that is targeting your data.

## Hundreds of climate activists shut down Federal Reserve building entrance
 - [https://www.foxnews.com/politics/hundreds-climate-activists-shut-down-federal-reserve-building-entrance](https://www.foxnews.com/politics/hundreds-climate-activists-shut-down-federal-reserve-building-entrance)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:02:24+00:00

Hundreds of climate activists swarmed the Federal Reserve Bank&apos;s New York headquarters in a protest action calling for an end to fossil fuel financing.

## Kate Middleton braces for life vest mishap during first royal outing in new military role
 - [https://www.foxnews.com/entertainment/kate-middleton-braces-life-vest-mishap-first-royal-outing-new-military-role](https://www.foxnews.com/entertainment/kate-middleton-braces-life-vest-mishap-first-royal-outing-new-military-role)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:00:49+00:00

Kate Middleton had a relatable moment when deploying a life vest at the Royal Naval Air Station Yeovilton in England, bracing for impact in new pictures.

## WSJ hammers Newsom for 'extorting' CA businesses by forcing $20/hr min. wage: ‘Who’s the real authoritarian?'
 - [https://www.foxnews.com/media/wsj-hammers-newsom-extorting-ca-businesses-forcing-20-hr-min-wage-whos-real-authoritarian](https://www.foxnews.com/media/wsj-hammers-newsom-extorting-ca-businesses-forcing-20-hr-min-wage-whos-real-authoritarian)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T15:00:32+00:00

Democrats are extorting fast-food businesses to do their bidding, a WSJ editorial board said, with a new bill requiring businesses provide workers $20 an hr minimum wage.

## Fetterman blasted by conservatives after Senate drops dress code: 'Stop lowering the bar!'
 - [https://www.foxnews.com/politics/fetterman-blasted-by-conservatives-after-senate-drops-dress-code-stop-lowering-the-bar](https://www.foxnews.com/politics/fetterman-blasted-by-conservatives-after-senate-drops-dress-code-stop-lowering-the-bar)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:53:00+00:00

Pennsylvania Sen. John Fetterman was blasted on social media after the Senate dropped its dress code, which is being referred to as the &quot;Fetterman Rule.&quot;

## Teen driver appears to intentionally hit, kill retired police chief in viral video
 - [https://www.foxnews.com/us/teen-driver-appears-intentionally-hit-kill-retired-police-chief-viral-video](https://www.foxnews.com/us/teen-driver-appears-intentionally-hit-kill-retired-police-chief-viral-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:36:47+00:00

Teenager has been charged with murder after video shows him deliberately mow down a retired police chief in fatal Las Vegas hit-and-run, local authorities allege.

## Wartime letter show Pope Pius XII may have known about Holocaust earlier than previously thought
 - [https://www.foxnews.com/world/wartime-letter-show-pope-pius-xii-may-have-known-about-holocaust-earlier-previously-thought](https://www.foxnews.com/world/wartime-letter-show-pope-pius-xii-may-have-known-about-holocaust-earlier-previously-thought)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:35:23+00:00

A letter from World War II recently discovered in the Vatican archives shows that Pope Pius XII knew about the Holocaust earlier than previously known.

## Attack on Turkish-backed opposition fighters in Syria kills 13 militants
 - [https://www.foxnews.com/world/attack-turkish-backed-opposition-fighters-syria-kills-13-militants](https://www.foxnews.com/world/attack-turkish-backed-opposition-fighters-syria-kills-13-militants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:27:08+00:00

A Kurdish-led group launched an assault on Turkish-backed opposition fighters in northern Syria on Monday, resulting in the reported deaths of at least 13 militants.

## Rebel uprising threatens to derail House GOP deal to avoid shutdown
 - [https://www.foxnews.com/politics/rebel-uprising-threatens-derail-house-gop-deal-avoid-shutdown](https://www.foxnews.com/politics/rebel-uprising-threatens-derail-house-gop-deal-avoid-shutdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:26:16+00:00

A deal struck late on Sunday to keep the government funded may be derailed by GOP opposition less than 24 hours later.

## Jeffrey Dahmer's former classmate on learning of the killer's crimes: 'I couldn't fathom what I was reading'
 - [https://www.foxnews.com/media/jeffrey-dahmers-former-classmate-learning-killers-crimes-couldnt-fathom-what-was-reading](https://www.foxnews.com/media/jeffrey-dahmers-former-classmate-learning-killers-crimes-couldnt-fathom-what-was-reading)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:25:26+00:00

Rose-Hulman professor emeritus Dr. Mike Kukral recounts being classmates with infamous serial killer Jeffrey Dahmer in an interview with FOX News Digital.

## California Gov. Newsom announces plan to sign climate bill requiring large companies to disclose gas emissions
 - [https://www.foxnews.com/politics/california-gov-newsom-announces-plan-sign-climate-bill-requiring-large-companies-disclose-gas-emissions](https://www.foxnews.com/politics/california-gov-newsom-announces-plan-sign-climate-bill-requiring-large-companies-disclose-gas-emissions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:21:12+00:00

On Sunday, Gov. Gavin Newsom, of California, said that he plans to enact two bills into law to force big corporations to tackle the climate crisis.

## Over 2,200 migrants caught on video illegally crossing border near Eagle Pass, Texas, overnight, sources say
 - [https://www.foxnews.com/us/over-2200-migrants-caught-video-illegally-crossing-eagle-pass-texas-border-overnight-sources-say](https://www.foxnews.com/us/over-2200-migrants-caught-video-illegally-crossing-eagle-pass-texas-border-overnight-sources-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:19:56+00:00

Fox News video showed more than 2,200 migrants pouring over the border from Piedras Negras, Mexico, to near Eagle, Pass, Texas, overnight.

## Washington fisherman catches massive record-breaking mahi mahi: 'Prayed for that'
 - [https://www.foxnews.com/lifestyle/washington-fisherman-catches-massive-record-breaking-mahi-mahi-prayed-for-that](https://www.foxnews.com/lifestyle/washington-fisherman-catches-massive-record-breaking-mahi-mahi-prayed-for-that)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:19:53+00:00

A Washington fisherman has set the new state record for mahi mahi after catching the 21-pound fish while out on a two-day tuna expedition. See photos of the massive, exotic catch.

## 'The View' host knocks Kristen Welker's debut 'Meet the Press' interview with Trump: 'Nobody ever wins'
 - [https://www.foxnews.com/media/the-view-host-knocks-kristen-welkers-debut-meet-press-interview-trump-nobody-ever-wins](https://www.foxnews.com/media/the-view-host-knocks-kristen-welkers-debut-meet-press-interview-trump-nobody-ever-wins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:09:31+00:00

&quot;The View&quot; co-host Ana Navarro said Monday that she wished NBC&apos;s new &quot;Meet the Press&quot; host Kristen Welker didn&apos;t debut her first show with a Donald Trump interview.

## Wisconsin resumes offering abortions following 1-year hiatus
 - [https://www.foxnews.com/politics/wisconsin-resumes-offering-abortions-following-1-year-hiatus](https://www.foxnews.com/politics/wisconsin-resumes-offering-abortions-following-1-year-hiatus)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:03:27+00:00

Planned Parenthood clinics in Madison and Milwaukee, Wisconsin, are permitted to offer abortions again following a one-year halt triggered by the Supreme Court overturning Roe v. Wade.

## Private Louisiana zoo criticizes USDA after regulators seize ailing giraffe
 - [https://www.foxnews.com/us/private-louisiana-zoo-criticizes-usda-regulators-seize-ailing-giraffe](https://www.foxnews.com/us/private-louisiana-zoo-criticizes-usda-regulators-seize-ailing-giraffe)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T14:03:00+00:00

Last week, U.S. regulators seized an ailing giraffe from Barn Hill Preserve, citing that the private zoo in Louisiana continuously failed to provide adequate veterinary care.

## Utah children's book author who allegedly poisoned husband accused of asking brother to falsely testify
 - [https://www.foxnews.com/us/utah-childrens-book-author-who-allegedly-poisoned-husband-accused-asking-brother-falsely-testify](https://www.foxnews.com/us/utah-childrens-book-author-who-allegedly-poisoned-husband-accused-asking-brother-falsely-testify)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:54:57+00:00

Kouri Richins, the Utah children&apos;s book author accused of killing her husband with a fentanyl-laced cocktail, allegedly asked her brother to give false testimony.

## GOP border hawks fear Mayorkas could be let off the hook thanks to Biden impeachment inquiry
 - [https://www.foxnews.com/politics/gop-border-hawks-fear-mayorkas-could-let-hook-thanks-biden-impeachment-inquiry](https://www.foxnews.com/politics/gop-border-hawks-fear-mayorkas-could-let-hook-thanks-biden-impeachment-inquiry)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:46:59+00:00

Homeland Security Secretary Alejandro Mayorkas may have dodged a bullet due to the impeachment inquiry into President Biden, some House Republicans fear.

## 5 Greek military rescue team members killed in Libya flood relief mission
 - [https://www.foxnews.com/world/5-greek-military-rescue-team-members-killed-libya-flood-relief-mission](https://www.foxnews.com/world/5-greek-military-rescue-team-members-killed-libya-flood-relief-mission)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:43:26+00:00

Greece&apos;s armed forces have announced a three-day period of national mourning following a road accident in flood-ravaged Libya, which killed five members of a military rescue team.

## Florida man, 78, shoots and kills neighbor who was 'trimming tree limbs' along property line: police
 - [https://www.foxnews.com/us/florida-man-78-shoots-kills-neighbor-who-was-trimming-tree-limbs-along-property-line-police](https://www.foxnews.com/us/florida-man-78-shoots-kills-neighbor-who-was-trimming-tree-limbs-along-property-line-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:41:19+00:00

A Florida man was charged with murder after shooting a neighbor who was “trimming tree limbs along the fence line&quot; of his property, police say.

## Arkansas school districts reject claims of violating a law over race, sexuality teachings
 - [https://www.foxnews.com/us/arkansas-school-districts-reject-claims-violating-law-race-sexuality-teachings](https://www.foxnews.com/us/arkansas-school-districts-reject-claims-violating-law-race-sexuality-teachings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:38:35+00:00

A couple of school districts in Arkansas, a state that banned teachings on divisive concepts, claimed that its schools did not violate the law with LGBT Pride month signs.

## Alabama high school band director stunned, arrested after telling students to keep playing music, police said
 - [https://www.foxnews.com/us/alabama-high-school-band-director-stunned-arrested-after-telling-students-keep-playing-music-police-said](https://www.foxnews.com/us/alabama-high-school-band-director-stunned-arrested-after-telling-students-keep-playing-music-police-said)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:35:58+00:00

Birmingham police stunned a high school band director with a stun gun and arrested him after he instructed his band to keep playing music in defiance of an order to stop.

## Landslide strikes northwestern Congo amid torrential rainfall, at least 17 dead
 - [https://www.foxnews.com/world/landslide-strikes-northwestern-congo-amid-torrential-rainfall-least-17-dead](https://www.foxnews.com/world/landslide-strikes-northwestern-congo-amid-torrential-rainfall-least-17-dead)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:35:05+00:00

Heavy rainfall in the Democratic Republic of the Congo triggered a landslide that left at least 17 people dead overnight, according to authorities.

## Georgia county may increase taxes to expand bus transit system
 - [https://www.foxnews.com/us/georgia-county-may-increase-taxes-expand-bus-transit-system](https://www.foxnews.com/us/georgia-county-may-increase-taxes-expand-bus-transit-system)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:33:35+00:00

Gwinnett County, Georgia, may ask its voters next year to expand its bus transit system by approving a 1-cent sales tax increase, which would fund new hires and operating costs.

## Minnesota man acquitted in St. Paul triple homicide case due to insufficient evidence
 - [https://www.foxnews.com/us/minnesota-man-acquitted-st-paul-triple-homicide-case-insufficient-evidence](https://www.foxnews.com/us/minnesota-man-acquitted-st-paul-triple-homicide-case-insufficient-evidence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:31:00+00:00

A Minnesota man accused of a triple homicide in St. Paul last year has been acquitted by a Ramsey County Judge, delivering a verdict that rested heavily on an alibi defense.

## 4 people, including 2 children, found fatally shot in suburban Chicago home
 - [https://www.foxnews.com/us/4-people-including-2-children-found-fatally-shot-suburban-chicago-home](https://www.foxnews.com/us/4-people-including-2-children-found-fatally-shot-suburban-chicago-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:30:21+00:00

Police officers in Romeoville, a suburban Chicago area, found four bodies belonging to two adults and two children who were fatally shot Sunday.

## 'It's a big lie': Max Lucado, pastor and author, admits the startling truth about those who appear 'perfect'
 - [https://www.foxnews.com/lifestyle/its-big-lie-max-lucado-pastor-author-admits-startling-truth-those-appear-perfect](https://www.foxnews.com/lifestyle/its-big-lie-max-lucado-pastor-author-admits-startling-truth-those-appear-perfect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:29:31+00:00

Pastor and bestselling author Max Lucado of Texas shared with Fox News Digital in an interview that grace and healing are available to those who admit their imperfections.

## Gunmen attack paramilitary forces in southern Iran on Mahsa Amini death anniversary
 - [https://www.foxnews.com/world/gunmen-attack-paramilitary-forces-southern-iran-mahsa-amini-death-anniversary](https://www.foxnews.com/world/gunmen-attack-paramilitary-forces-southern-iran-mahsa-amini-death-anniversary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:29:08+00:00

Gunmen carried out an attack on a group of paramilitary forces in the southern region of Iran, resulting in the death of one officer and injuries to three others.

## Alissa Turney's stepfather 'had obsession' despite acquittal in teen's presumed death: report
 - [https://www.foxnews.com/us/alissa-turney-stepfather-had-obsession-despite-acquittal-teens-presumed-death-report](https://www.foxnews.com/us/alissa-turney-stepfather-had-obsession-despite-acquittal-teens-presumed-death-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:28:51+00:00

Alissa Turney&apos;s stepfather allegedly hid cameras in his home and had &quot;an apparent obsession&quot; with his stepdaughter when she vanished in 2001, Turney&apos;s boyfriend claims.

## Massive fire engulfs 18-story building in war-torn Sudan capital
 - [https://www.foxnews.com/world/massive-fire-engulfs-18-story-building-war-torn-sudan-capital](https://www.foxnews.com/world/massive-fire-engulfs-18-story-building-war-torn-sudan-capital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:25:29+00:00

A fire engulfed an 18-story building in Khartoum, Sudan, on Sunday, as the ongoing conflict between the military and a rival paramilitary group extends into its sixth month.

## Deion Sanders: 'The kids are just as much to blame as the coaching staff' for 1-win season
 - [https://www.foxnews.com/sports/deion-sanders-kids-much-blame-coaching-staff-1-win-season](https://www.foxnews.com/sports/deion-sanders-kids-much-blame-coaching-staff-1-win-season)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:22:06+00:00

Colorado Buffaloes coach Deion Sanders says players are partly to blame for the one-win season in 2022 and suggested he gave them a tough pill to swallow.

## Karen Read, charged with murder in Boston cop boyfriend's death, learns trial start date after heated hearing
 - [https://www.foxnews.com/us/karen-read-charged-murder-boston-cop-boyfriends-death-trial-start-date-heated-hearing](https://www.foxnews.com/us/karen-read-charged-murder-boston-cop-boyfriends-death-trial-start-date-heated-hearing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:16:54+00:00

The trial for Karen Read, a Massachusetts woman charged with murder in the death of Boston cop boyfriend John O&apos;Keefe, is scheduled to begin in March 2024.

## Future 'Wheel of Fortune' host Ryan Seacrest hopes Vanna White stays on show amid reported contract dispute
 - [https://www.foxnews.com/entertainment/future-wheel-of-fortune-host-ryan-seacrest-hopes-vanna-white-stays-reported-contract-dispute](https://www.foxnews.com/entertainment/future-wheel-of-fortune-host-ryan-seacrest-hopes-vanna-white-stays-reported-contract-dispute)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:07:25+00:00

Ryan Seacrest is opening up about his upcoming role as host of &quot;Wheel of Fortune,&quot; and he hopes that Vanna White will continue on the revamped show.

## Military base abruptly cancels 'Sound of Freedom' screening, baffling producer
 - [https://www.foxnews.com/us/military-base-abruptly-cancels-sound-of-freedom-screening-baffling-producer](https://www.foxnews.com/us/military-base-abruptly-cancels-sound-of-freedom-screening-baffling-producer)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T13:02:51+00:00

Filmmakers of the blockbuster film &quot;Sound of Freedom&quot; are pushing to reschedule two screenings of the movie that were supposed to take place on a U.S. military base.

## Dolphins' Tyreek Hill rips Patriots fans over remarks: 'They are real nasty'
 - [https://www.foxnews.com/sports/dolphins-tyreek-hill-rips-patriots-fans-remarks-they-real-nasty](https://www.foxnews.com/sports/dolphins-tyreek-hill-rips-patriots-fans-remarks-they-real-nasty)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:48:27+00:00

Miami Dolphins wide receiver Tyreek Hill had five catches for 40 yards and a touchdown and was happy to get out of Foxborough, Massachusetts, when he did.

## Elderly motorist from Maine found trapped in New Hampshire woods after going missing for 2 days
 - [https://www.foxnews.com/us/elderly-motorist-maine-found-trapped-new-hampshire-woods-going-missing-2-days](https://www.foxnews.com/us/elderly-motorist-maine-found-trapped-new-hampshire-woods-going-missing-2-days)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:48:02+00:00

After going missing for two days, an elderly motorist from Maine was found stuck in mud in the woods of New Hampshire. The man was rescued and taken to a hospital.

## Iran reaps billions in payments by kidnapping Americans, Westerners: report
 - [https://www.foxnews.com/world/iran-reaps-billions-in-payments-kidnapping-americans-westerners-report](https://www.foxnews.com/world/iran-reaps-billions-in-payments-kidnapping-americans-westerners-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:39:36+00:00

The Biden administration has completed a prisoner swap to bring five Americans home. A new report claims the U.S. has paid some $15.7 billion since 1981 in hostage payments to the regime.

## Savannah to contribute half a million dollars to restore house that hosted an African-American art museum
 - [https://www.foxnews.com/us/savannah-contribute-half-million-dollars-restore-house-hosted-african-american-art-museum](https://www.foxnews.com/us/savannah-contribute-half-million-dollars-restore-house-hosted-african-american-art-museum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:31:40+00:00

The city of Savannah, Georgia, will help renovate the Kiah House, which once hosted an African American art museum, by funding the project $500,000.

## Thousands of Alabama 3rd graders at risk of being held back under new reading benchmarks
 - [https://www.foxnews.com/us/thousands-alabama-3rd-graders-risk-being-held-back-new-reading-benchmarks](https://www.foxnews.com/us/thousands-alabama-3rd-graders-risk-being-held-back-new-reading-benchmarks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:23:53+00:00

At least 10,000 third graders are at risk of falling behind under the Alabama Literacy Act, a new reading benchmark getting implemented this school year.

## GOP lawmaker aims to cut US taxpayer dollars from United Nations 'censorship' program
 - [https://www.foxnews.com/politics/gop-lawmaker-aims-cut-us-taxpayer-dollars-united-nations-censorship-program](https://www.foxnews.com/politics/gop-lawmaker-aims-cut-us-taxpayer-dollars-united-nations-censorship-program)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:23:39+00:00

Rep. Ben Cline, R-Va., is introducing a new bill aimed at stopping the flow of taxpayer dollars toward a UN program he argues is aiding censorship.

## Shaq hilariously helps Los Angeles Port Police arrest suspect in recruitment video
 - [https://www.foxnews.com/sports/shaq-hilariously-helps-los-angeles-port-police-arrest-suspect-recruitment-video](https://www.foxnews.com/sports/shaq-hilariously-helps-los-angeles-port-police-arrest-suspect-recruitment-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:17:02+00:00

Shaquille O&apos;Neal helped Los Angeles Port Police officers arrest a suspect in a hilarious recruitment video. The Big Aristotle joins the hunt.

## School claims no discrimination after Black student suspended for hairstyle
 - [https://www.foxnews.com/us/school-claims-no-discrimination-after-black-student-suspended-for-hairstyle](https://www.foxnews.com/us/school-claims-no-discrimination-after-black-student-suspended-for-hairstyle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:14:06+00:00

The CROWN Act, which took effect Sept. 1 in Texas, is intended to prohibit race-based hair discrimination and bars employers and schools from penalizing people.

## RFK Jr's vow to ban fracking met with intense criticism
 - [https://www.foxnews.com/politics/rfk-jrs-vow-ban-fracking-met-intense-criticism](https://www.foxnews.com/politics/rfk-jrs-vow-ban-fracking-met-intense-criticism)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:07:44+00:00

Democratic presidential candidate Robert F. Kennedy, Jr. promised to ban fracking as president despite its economic and energy security benefits.

## Smithsonian suspends Latino exhibit after critics call previous version ‘disgraceful’, ‘Marxist’
 - [https://www.foxnews.com/media/smithsonian-suspends-latino-exhibit-critics-call-previous-version-disgraceful-marxist](https://www.foxnews.com/media/smithsonian-suspends-latino-exhibit-critics-call-previous-version-disgraceful-marxist)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T12:00:42+00:00

A new Smithsonian Latin American exhibit has been suspended following criticism that a similar, previous exhibit was promoting a &quot;Marxist&quot; reading of history.

## Trial for 3 Washington officers accused of killing a Black man set to begin
 - [https://www.foxnews.com/us/trial-3-washington-officers-accused-killing-black-man-set-begin](https://www.foxnews.com/us/trial-3-washington-officers-accused-killing-black-man-set-begin)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:42:40+00:00

The trial for three Tacoma, Washington, police officers, Christopher Burbank, Matthew Collins, and Timothy Rankine, who were charged in the death of a 33-year-old Black man, is set to begin.

## Youth pastor allegedly tried to kill wife, 5 children before setting home on fire: police
 - [https://www.foxnews.com/us/kansas-pastor-allegedly-tried-kill-wife-5-children-setting-home-fire-police](https://www.foxnews.com/us/kansas-pastor-allegedly-tried-kill-wife-5-children-setting-home-fire-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:41:41+00:00

A Kansas youth pastor is accused of attempting to kill his wife and five children in their Shawnee home on Sept. 16 and then trying to set the house on fire.

## GOP senator latest Republican to throw hat behind Trump for president
 - [https://www.foxnews.com/politics/gop-senator-latest-republican-throw-hat-behind-trump-president](https://www.foxnews.com/politics/gop-senator-latest-republican-throw-hat-behind-trump-president)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:40:00+00:00

Republican Senator Mike Braun of Indiana, who is running to be the Hoosier State&apos;s next governor, threw his hat behind Trump for president in the 2024 race.

## UN adds Afghan crisis onto agenda after Taliban bans women and girls from school, public spaces, jobs
 - [https://www.foxnews.com/world/un-adds-afghan-crisis-agenda-taliban-bans-women-girls-school-public-spaces-jobs](https://www.foxnews.com/world/un-adds-afghan-crisis-agenda-taliban-bans-women-girls-school-public-spaces-jobs)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:34:49+00:00

The Taliban, which banned girls from attending school beyond sixth grade, is furthering its restrictions by prohibiting women from participating in social or public events.

## Peggy Noonan says Biden clinging to power, calls re-election bid 'historical mistake' in scathing column
 - [https://www.foxnews.com/media/peggy-noonan-says-biden-clinging-power-calls-re-election-bid-historical-mistake-scathing-column](https://www.foxnews.com/media/peggy-noonan-says-biden-clinging-power-calls-re-election-bid-historical-mistake-scathing-column)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:30:57+00:00

Wall Street Journal columnist Peggy Noonan argued in a new column that President Biden was making a &quot;historical mistake&quot; in running for re-election.

## Death toll from Maui fire drops to 97 after officials discover multiple DNA samples for some victims
 - [https://www.foxnews.com/us/death-toll-maui-fire-drops-97-officials-discover-multiple-dna-samples-some-victims](https://www.foxnews.com/us/death-toll-maui-fire-drops-97-officials-discover-multiple-dna-samples-some-victims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:29:47+00:00

A forensics investigation team has revealed that the initial death tally of the Maui, Hawaii, wildfire, America’s deadliest blaze in more than a century, has dropped by 18.

## James Carville sounds alarm over Biden's chances with Democrats in 2024: 'The voters don't want this'
 - [https://www.foxnews.com/media/james-carville-sounds-alarm-bidens-chances-democrats-2024-voters-dont-want](https://www.foxnews.com/media/james-carville-sounds-alarm-bidens-chances-democrats-2024-voters-dont-want)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T11:00:14+00:00

Democrats have been unable to shake Democratic voters&apos; concerns over Biden&apos;s age and vitality going into the 2024 election, and James Carville is worried.

## White House touts Iran prisoner exchange deal, says Biden is 'Making five families whole again'
 - [https://www.foxnews.com/politics/white-house-touts-iran-prisoner-exchange-deal-says-biden-making-five-families-whole-again](https://www.foxnews.com/politics/white-house-touts-iran-prisoner-exchange-deal-says-biden-making-five-families-whole-again)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:52:13+00:00

President Biden&apos;s administration touted the release of five U.S. citizens from Iranian custody, but critics condemned Iran getting $6 billion in the deal.

## Clinton Global Initiative announces new proposal to help rebuild Ukraine, provide humanitarian support
 - [https://www.foxnews.com/world/clinton-global-initiative-announces-new-proposal-help-rebuild-ukraine-provide-humanitarian-support](https://www.foxnews.com/world/clinton-global-initiative-announces-new-proposal-help-rebuild-ukraine-provide-humanitarian-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:36:37+00:00

The two-day Clinton Global Initiative started on Monday with officials revealing the CGI Ukraine Action Network, a new organization that will help rebuild Ukraine.

## NFL legend Donovan McNabb joins OutKick with new video podcast: ‘I can’t wait to get started’
 - [https://www.foxnews.com/media/nfl-legend-donovan-mcnabb-joins-outkick-new-video-podcast-cant-wait-get-started](https://www.foxnews.com/media/nfl-legend-donovan-mcnabb-joins-outkick-new-video-podcast-cant-wait-get-started)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:30:15+00:00

Longtime NFL quarterback Donovan McNabb has joined OutKick and will host a video podcast, &quot;The 5 Spot with Donovan McNabb,&quot; the company announced on Monday.

## Hunter Biden's texts, emails contradict lawyer's claim that he 'did not share' money from businesses with dad
 - [https://www.foxnews.com/politics/hunter-bidens-texts-emails-contradict-lawyers-claim-did-not-share-money-businesses-dad](https://www.foxnews.com/politics/hunter-bidens-texts-emails-contradict-lawyers-claim-did-not-share-money-businesses-dad)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:17:47+00:00

A 2019 text message from Hunter Biden claiming he was forced to fork over half his salary to his dad contradicts his lawyer&apos;s recent claim about him not sharing money with him.

## Dem Rep Jennifer Wexton will not seek re-election after 'Parkinson's on steroids' diagnosis
 - [https://www.foxnews.com/politics/dem-rep-jennifer-wexton-not-seek-reelection-after-parkinsons-on-steroids-diagnosis](https://www.foxnews.com/politics/dem-rep-jennifer-wexton-not-seek-reelection-after-parkinsons-on-steroids-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:02:40+00:00

Democrat Virginia Rep. Jennifer Wexton announced that she will not run for re-election after being diagnosed with &quot;Parkinson&apos;s on steroid.&quot;

## Anchorage, Alaska, scrambles to find housing for the homeless as winter approaches
 - [https://www.foxnews.com/us/anchorage-alaska-scrambles-find-housing-homeless-winter-approaches](https://www.foxnews.com/us/anchorage-alaska-scrambles-find-housing-homeless-winter-approaches)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:00:56+00:00

As winter nears, Anchorage, Alaska, is scrambling to house its 3,000 homeless people. The city, which was recently approved for $4 million in funds, still needs about 500 winter beds.

## What happened in New Mexico is a warning to us all
 - [https://www.foxnews.com/opinion/what-happened-new-mexico-warning-all](https://www.foxnews.com/opinion/what-happened-new-mexico-warning-all)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:00:21+00:00

New Mexico&apos;s Democrat Governor Michelle Lujan Grisham issued an emergency order suspending the right to carry guns.

## House Democrat sounds alarm on Beijing's plan to dominate tech sector
 - [https://www.foxnews.com/politics/house-democrat-sounds-alarm-beijing-plan-tech-sector](https://www.foxnews.com/politics/house-democrat-sounds-alarm-beijing-plan-tech-sector)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:00:10+00:00

A House Democrat is leading members of the China select committee to make sure Beijing does not become the next top high tech manufacturing center.

## Boston University staffers speak out against Ibram X. Kendi's center laying off employees: 'Exploitative'
 - [https://www.foxnews.com/media/boston-university-staffers-speak-out-against-ibram-x-kendis-center-laying-off-employees-exploitative](https://www.foxnews.com/media/boston-university-staffers-speak-out-against-ibram-x-kendis-center-laying-off-employees-exploitative)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T10:00:04+00:00

Boston University staffers spoke out against the decision to lay off employees at the Center for Antiracist Research founded under author Ibram X. Kendi.

## Former Colorado police officer gets probation after detaining a woman in a car that was hit by a train
 - [https://www.foxnews.com/us/former-colorado-police-officer-left-detained-woman-inside-car-parked-train-tracks-gets-probation](https://www.foxnews.com/us/former-colorado-police-officer-left-detained-woman-inside-car-parked-train-tracks-gets-probation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:50:27+00:00

Last year, a Colorado officer left a woman inside a car that was struck by a train. The former officer was sentenced to probation Friday and still faces reckless endangerment charges.

## Speaker McCarthy predicts Trump will be GOP nominee, slams DeSantis as 'not at the same level'
 - [https://www.foxnews.com/politics/speaker-mccarthy-predicts-trump-gop-nominee-slams-desantis-not-same-level](https://www.foxnews.com/politics/speaker-mccarthy-predicts-trump-gop-nominee-slams-desantis-not-same-level)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:49:19+00:00

House Speaker Kevin McCarthy bashed Florida Gov. Ron DeSantis as &quot;not at the same level&quot; as former President Trump, predicting Trump will win the primary.

## Sheryl Crow admits moving from Los Angeles to Tennessee 'saved my life'
 - [https://www.foxnews.com/entertainment/sheryl-crow-admits-moving-los-angeles-tennessee-saved-life](https://www.foxnews.com/entertainment/sheryl-crow-admits-moving-los-angeles-tennessee-saved-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:47:18+00:00

While performing in New Jersey, Sheryl Crow told her audience that her move to Nashville and immersing herself in nature ultimately saved her life.

## Arrest made in ambush killing of LA Sheriff's Deputy: sources
 - [https://www.foxnews.com/us/arrest-made-ambush-killing-la-sheriffs-deputy-sources](https://www.foxnews.com/us/arrest-made-ambush-killing-la-sheriffs-deputy-sources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:32:11+00:00

An arrest has been made in the shooting death of Los Angeles Sheriff&apos;s Deputy Ryan Clinkunbroomer, sources close to the investigation told Fox News.

## AOC joins thousands in New York climate change march with furious message for Biden
 - [https://www.foxnews.com/politics/aoc-joins-thousands-new-york-climate-change-march-furious-message-biden](https://www.foxnews.com/politics/aoc-joins-thousands-new-york-climate-change-march-furious-message-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:28:02+00:00

Protesters flooded the streets of Manhattan on Sunday for New York&apos;s Climate Week to call for the elimination of fossil fuels and to scold President Biden.

## Australia urges dating apps to improve safety standards, report says 75% Australian users experience violence
 - [https://www.foxnews.com/world/australia-urges-dating-apps-improve-safety-standards-report-75-australian-users-experience-violence](https://www.foxnews.com/world/australia-urges-dating-apps-improve-safety-standards-report-75-australian-users-experience-violence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:14:55+00:00

About 75% of Australia&apos;s dating-platform users have reportedly experienced sexual violence online. The government have called the online dating industry to improve its safety standards.

## Rhode Island man with an animal cruelty charge fatally shot by police following 20-mile car chase
 - [https://www.foxnews.com/us/rhode-island-man-charged-animal-cruelty-fatally-shot-by-police-20-mile-car-chase](https://www.foxnews.com/us/rhode-island-man-charged-animal-cruelty-fatally-shot-by-police-20-mile-car-chase)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:13:12+00:00

Michael Pinto, a 40-year-old Rhode Island man who was out on probation on an animal cruelty charge, led a police chase for miles. The authorities eventually shot and killed Pinto.

## The Constitution of the United States: Understanding the supreme law of the U.S.
 - [https://www.foxnews.com/us/us-constitution](https://www.foxnews.com/us/us-constitution)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:06:00+00:00

The U.S. Constitution is a document that was written to lay out the roles of government. The Constitution has been amended since its original drafting, starting with the Bill of Rights.

## Carly Pearce shares how Tim McGraw has stayed the same since '90s
 - [https://www.foxnews.com/entertainment/carly-pearce-shares-tim-mcgraw-stayed-same-since-90s](https://www.foxnews.com/entertainment/carly-pearce-shares-tim-mcgraw-stayed-same-since-90s)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:00:29+00:00

Carly Pearce, who is hosting the 2023 ACM Honors, praises fellow country music artist Tim McGraw, saying he is as much of a hard worker now as he was 30 years ago.

## LGBTQ community felt 'betrayal' at Muslim council voting to remove Pride flags from city buildings
 - [https://www.foxnews.com/media/lgbtq-community-felt-betrayal-muslim-council-voting-remove-pride-flags-city-buildings](https://www.foxnews.com/media/lgbtq-community-felt-betrayal-muslim-council-voting-remove-pride-flags-city-buildings)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T09:00:05+00:00

Members of the LGBTQ community in a Michigan town say they feel betrayed after an all-Muslim city council voted against Pride flags on city properties.

## Deion Sanders defends bolting Jackson State for Colorado: 'I finished the task'
 - [https://www.foxnews.com/sports/deion-sanders-defends-bolting-jackson-state-colorado-finished-task](https://www.foxnews.com/sports/deion-sanders-defends-bolting-jackson-state-colorado-finished-task)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T08:56:42+00:00

Deion Sanders defended his decision to leave Jackson State after three years for Colorado during a &quot;60 Minutes&quot; interview on Sunday night as he has the Buffaloes 3-0 to start the year.

## 9 juveniles who escaped Pennsylvania detention center after overpowering guards now captured, state police say
 - [https://www.foxnews.com/us/9-juveniles-who-escaped-pennsylvania-detention-center-riot-captured-state-police-say](https://www.foxnews.com/us/9-juveniles-who-escaped-pennsylvania-detention-center-riot-captured-state-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T08:14:01+00:00

Pennsylvania Police said all nine juveniles who escaped Abraxas Academy, a residential treatment program in Morgantown, have been captured.

## Melissa Joan Hart shares marriage success secrets after celebrating 20-year wedding anniversary
 - [https://www.foxnews.com/entertainment/melissa-joan-hart-shares-marriage-success-secrets-celebrating-20-year-wedding-anniversary](https://www.foxnews.com/entertainment/melissa-joan-hart-shares-marriage-success-secrets-celebrating-20-year-wedding-anniversary)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T08:08:14+00:00

Melissa Joan Hart praised her husband of 20 years, musician Mark Wilkerson, and said their marriage has lasted so long thanks to commitment, trust and grace.

## One big state is taxing the middle-class nationwide to give the wealthy free healthcare
 - [https://www.foxnews.com/opinion/state-taxing-middle-class-nationwide-give-wealthy-free-healthcare](https://www.foxnews.com/opinion/state-taxing-middle-class-nationwide-give-wealthy-free-healthcare)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T08:00:49+00:00

California is taxing the middle-class nationwide to give the wealthy free healthcare. Asset-rich residents get to stick the bill for nursing home stays on other Americans.

## Hunter Biden sues IRS, alleges agents tried to 'target' and 'embarrass' him
 - [https://www.foxnews.com/politics/hunter-biden-sues-irs-alleges-agents-tried-target-embarrass-him](https://www.foxnews.com/politics/hunter-biden-sues-irs-alleges-agents-tried-target-embarrass-him)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T08:00:42+00:00

Hunter Biden sued the IRS, alleging that whistleblowers Gary Shapley and Joseph Ziegler violated IRS policy to &quot;target&quot; him, among other claims.

## 4.8 magnitude earthquake strikes Italy, no damage reported so far
 - [https://www.foxnews.com/world/4-8-magnitude-earthquake-strikes-italy-no-damage-reported-so-far](https://www.foxnews.com/world/4-8-magnitude-earthquake-strikes-italy-no-damage-reported-so-far)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:57:02+00:00

On Monday, an earthquake with a magnitude of 4.8 struck Marradi, an area prone to tremors northeast of Florence, Italy. No damage or injuries were reported so far.

## 20 dead in South Africa after bus carrying miners collides into truck
 - [https://www.foxnews.com/world/20-dead-south-africa-bus-carrying-miners-collides-truck](https://www.foxnews.com/world/20-dead-south-africa-bus-carrying-miners-collides-truck)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:47:20+00:00

At least two dozen people died Monday after a bus carrying workers to a mine crashed into a truck. The construction company may offer support to the families of the deceased.

## Zelenskyy to make second trip to the US this week as Ukraine fires 6 deputy defense ministers
 - [https://www.foxnews.com/politics/zelenskyy-make-second-trip-us-this-week-ukraine-fires-6-deputy-defense-ministers](https://www.foxnews.com/politics/zelenskyy-make-second-trip-us-this-week-ukraine-fires-6-deputy-defense-ministers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:42:14+00:00

Ukrainian President Volodymyr Zelenskyy will make his second visit to the U.S., with stops including the United Nations and the White House.

## Dolphins' Mike McDaniel hilariously sprints off field after halftime interview
 - [https://www.foxnews.com/sports/dolphins-mike-mcdaniel-hilariously-sprints-off-field-halftime-interview](https://www.foxnews.com/sports/dolphins-mike-mcdaniel-hilariously-sprints-off-field-halftime-interview)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:25:51+00:00

Miami Dolphins head coach Mike McDaniel toyed with the &quot;Sunday Night Football&quot; camera crew at halftime of his game against the New England Patriots.

## World War I-era plane flips on its roof while trying to land at Massachusetts museum
 - [https://www.foxnews.com/us/world-war-i-era-plane-flips-roof-while-trying-land-massachusetts-museum](https://www.foxnews.com/us/world-war-i-era-plane-flips-roof-while-trying-land-massachusetts-museum)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:23:58+00:00

Authorities in Massachusetts say a World War I-era plane crashed and flipped over near the American Heritage Museum in Stow on Sunday.

## Crews in Turkey search for helicopter that crashed into lake while fighting forest fire
 - [https://www.foxnews.com/world/crews-turkey-search-helicopter-crashed-lake-fighting-forest-fire](https://www.foxnews.com/world/crews-turkey-search-helicopter-crashed-lake-fighting-forest-fire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:02:39+00:00

Three passengers of a helicopter that crashed into a lake while fighting a forest fire in western Turkey remain missing. The aircraft is reported to be stuck 36 feet below the surface.

## No clear spending deal as Congress inches closer to government shutdown
 - [https://www.foxnews.com/politics/spending-deal-congress-inches-closer-to-government-shutdown](https://www.foxnews.com/politics/spending-deal-congress-inches-closer-to-government-shutdown)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T07:00:23+00:00

Lawmakers are coming back to Congress on Monday with less than two weeks until a possible potential government shutdown.

## Indiana AG sues state hospital for violating privacy of girl who traveled from Ohio for abortion
 - [https://www.foxnews.com/politics/indiana-ag-sues-state-hospital-violating-privacy-girl-who-traveled-abortion](https://www.foxnews.com/politics/indiana-ag-sues-state-hospital-violating-privacy-girl-who-traveled-abortion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:58:07+00:00

Indiana Attorney General Rodd Rokita claimes doctors violated HIPPA laws by publicizing a 10-year-old girls&apos; trip from Ohio to Indiana for an abortion.

## Iran set to free 5 Americans after Biden cuts deal, Senate pivots on dress code and more top headlines
 - [https://www.foxnews.com/us/iran-set-to-free-5-americans-after-biden-cuts-deal-senate-pivots-on-dress-code-and-more-top-headlines](https://www.foxnews.com/us/iran-set-to-free-5-americans-after-biden-cuts-deal-senate-pivots-on-dress-code-and-more-top-headlines)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:34:30+00:00

Iran set to free 5 Americans after Biden cuts deal, Senate pivots on dress code and more top headlines

## Patriots' Bill Belichick delights fans with demeanor as he slams challenge flag onto ground
 - [https://www.foxnews.com/sports/patriots-bill-belichick-delights-fans-demeanor-slams-challenge-flag-ground](https://www.foxnews.com/sports/patriots-bill-belichick-delights-fans-demeanor-slams-challenge-flag-ground)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:04:09+00:00

New England Patriots coach Bill Belichick had fans rolling in laughter on Sunday night as he slammed his challenge flag down on the ground in the third quarter.

## Kim Jong Un's sister is 'the most dangerous woman in the world,' expert says: Here's why
 - [https://www.foxnews.com/world/kim-jong-uns-sister-most-dangerous-woman-world-expert-says-heres-why](https://www.foxnews.com/world/kim-jong-uns-sister-most-dangerous-woman-world-expert-says-heres-why)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:00:57+00:00

Kim Yo Jong, since her 2018 international debut, has increasingly made public statements and threats on behalf of her brother, indicating an incredible level of authority.

## Why Putin infiltrates spies and disruptors to America and why authorities struggle to catch them
 - [https://www.foxnews.com/opinion/putin-infiltrates-spies-disruptors-america-authorities-struggle-catch-them](https://www.foxnews.com/opinion/putin-infiltrates-spies-disruptors-america-authorities-struggle-catch-them)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:00:44+00:00

Russia continues to send spies to try and infiltrate US society. Analysts note that while Washington cut back on resources following the fall of the Soviet Union, Moscow never did.

## Former Special Forces soldier launches campaign in Virginia to flip swing House seat from Democrats
 - [https://www.foxnews.com/politics/former-special-forces-soldier-launches-campaign-virginia-flip-house-seat-democrats](https://www.foxnews.com/politics/former-special-forces-soldier-launches-campaign-virginia-flip-house-seat-democrats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:00:43+00:00

Former U.S. Army Special Forces soldier Derrick Anderson has joined the race to flip Virginia&apos;s 7th Congressional District, a top Republican target, from the Democrats in 2024.

## Ozzy Osbourne’s son Jack reveals what rocker refuses to do as grandparent: 'Hell no'
 - [https://www.foxnews.com/entertainment/ozzy-osbournes-son-jack-reveals-what-rocker-refuses-do-as-grandparent](https://www.foxnews.com/entertainment/ozzy-osbournes-son-jack-reveals-what-rocker-refuses-do-as-grandparent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T06:00:36+00:00

&quot;Special Forces: World&apos;s Toughest Test&quot; star Jack Osbourne revealed that his dad Ozzy Osbourne has specific limitations when it comes to babysitting his four daughters.

## 2 California inmates walked away from San Diego reentry facility, officials say
 - [https://www.foxnews.com/us/2-california-inmates-walked-away-san-diego-reentry-facility](https://www.foxnews.com/us/2-california-inmates-walked-away-san-diego-reentry-facility)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:59:37+00:00

Two female inmates walked away from a reentry program in San Diego, prompting a search effort to bring them back into custody. They were seen leaving the facility Saturday night.

## Deion Sanders names the best college football coach right now, expresses admiration for Nick Saban
 - [https://www.foxnews.com/sports/deion-sanders-names-best-college-football-coach-right-now-expresses-admiration-nick-saban](https://www.foxnews.com/sports/deion-sanders-names-best-college-football-coach-right-now-expresses-admiration-nick-saban)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:58:14+00:00

Colorado Buffaloes head coach Deion Sanders believes he is at the top of the ladder when it comes to college football coaches and has much admiration for Nick Saban.

## Pennsylvania authorities searching for 9 juveniles who escaped detention center following riot
 - [https://www.foxnews.com/us/pennsylvania-authorities-searching-9-juveniles-escaped-detention-center-riot](https://www.foxnews.com/us/pennsylvania-authorities-searching-9-juveniles-escaped-detention-center-riot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:43:10+00:00

Nine minors escaped from a juvenile detention center in Morgantown, Pennsylvania, Sunday night following a riot. The escapees were wearing white or gray T-shirts.

## 5 Americans detained to be freed Monday under prisoner swap deal, Iran Foreign Ministry says
 - [https://www.foxnews.com/world/5-americans-detained-freed-monday-prisoner-swap-deal-iran-foreign-ministry-says](https://www.foxnews.com/world/5-americans-detained-freed-monday-prisoner-swap-deal-iran-foreign-ministry-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:19:01+00:00

A senior Iranian official confirmed a prisoner swap with the United States would take place on Monday after $6 billion in frozen funds, key in the exchange, arrived in Qatar.

## California law will require judges to consider parents' stance on gender identity in custody battle
 - [https://www.foxnews.com/media/california-law-require-judges-consider-parents-stance-gender-identity-custody-battle](https://www.foxnews.com/media/california-law-require-judges-consider-parents-stance-gender-identity-custody-battle)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:57+00:00

California law will instruct judges in the state to consider whether a parent affirms a child&apos;s gender identify as a factor in custody decisions.

## New Mexico governor's gun order is 'blatantly unconstitutional,' leaves abuse victims vulnerable: Experts
 - [https://www.foxnews.com/media/new-mexico-governors-gun-order-unconstitutional-abuse-victims-vulnerable-experts](https://www.foxnews.com/media/new-mexico-governors-gun-order-unconstitutional-abuse-victims-vulnerable-experts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:57+00:00

Experts say that New Mexico Gov. Michelle Lujan Grisham&apos;s gun suspension is not only &quot;unconstitutional,&quot; but could also endanger domestic abuse victims.

## Atlanta pastor warns church's 'silence' on cultural issues will soon lead to 'godless society'
 - [https://www.foxnews.com/media/atlanta-pastor-warns-churchs-silence-cultural-issues-will-lead-godless-society](https://www.foxnews.com/media/atlanta-pastor-warns-churchs-silence-cultural-issues-will-lead-godless-society)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:41+00:00

Pastor Myles Rutherford encourages the Christian church to address hot-button topics in the culture and expect to face a level of persecution for speaking Biblical truth.

## Battle brewing in Texas town over historic Black church as member calls denial of permit a ‘real tragedy’
 - [https://www.foxnews.com/media/battle-brewing-texas-town-over-historic-black-church-leader-calls-denial-permit-real-tragedy](https://www.foxnews.com/media/battle-brewing-texas-town-over-historic-black-church-leader-calls-denial-permit-real-tragedy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:26+00:00

White Rock Chapel in Addison, Texas, says the city council denied a zoning permit to restore the damaged church that its leaders say has a rich history.

## Disney’s potential ABC sale could have major ramifications for network’s news division, high-paid anchors
 - [https://www.foxnews.com/media/disney-potential-abc-sale-major-ramifications-networks-news-division-high-paid-anchors](https://www.foxnews.com/media/disney-potential-abc-sale-major-ramifications-networks-news-division-high-paid-anchors)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:14+00:00

Some ABC newsroom employees are panicking after Disney recently “held exploratory talks&quot; with TV station operator Nexstar Media about selling off ABC, per Bloomberg.

## 3 chefs reveal their favorite after-school snacks — and each healthy bite for kids takes just minutes to prep
 - [https://www.foxnews.com/lifestyle/3-chefs-reveal-favorite-after-school-snacks-each-healthy-bite-kids-takes-minutes-prep](https://www.foxnews.com/lifestyle/3-chefs-reveal-favorite-after-school-snacks-each-healthy-bite-kids-takes-minutes-prep)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T05:00:09+00:00

With back-to-school season in full swing, three hotel chefs shared with Fox News Digital their favorite after-school snacks for kids — all are healthy and all take just minutes to prep.

## Can magnesium and vitamin D3 curb anxiety? Mental health experts weigh in on a viral TikTok claim
 - [https://www.foxnews.com/health/magnesium-d3-anxiety-mental-health-experts-viral-tiktok-claim](https://www.foxnews.com/health/magnesium-d3-anxiety-mental-health-experts-viral-tiktok-claim)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T04:00:08+00:00

A viral TikTok trend is claiming the use of magnesium and D3 supplements can help ease anxiety. Mental health experts Drs. Chris Palmer and Mary Alvord discuss the hack&apos;s validity.

## The era of Ukraine’s blank check from Congress is over
 - [https://www.foxnews.com/opinion/ukraines-blank-check-congress-over](https://www.foxnews.com/opinion/ukraines-blank-check-congress-over)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T04:00:00+00:00

The era of Ukraine’s blank check from Congress is over because America has given more military support than all of Europe. NATO must step up. The US has its own border to defend.

## Armed suspect riding bicycle in NYC kills 80-year-old man returning home from party with wife
 - [https://www.foxnews.com/us/armed-suspect-riding-bicycle-nyc-kills-80-year-old-man-returning-home-party-wife](https://www.foxnews.com/us/armed-suspect-riding-bicycle-nyc-kills-80-year-old-man-returning-home-party-wife)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T03:38:27+00:00

An 80-year-old man was shot and killed Sunday morning on a New York City street as he arrived home from a party with his wife. The suspect, who was wearing all black, fled on a bike.

## Prince William, Kate Middleton learn from King Charles and Princess Diana's marriage mistakes: author
 - [https://www.foxnews.com/entertainment/prince-william-kate-middleton-learn-king-charles-princess-dianas-marriage](https://www.foxnews.com/entertainment/prince-william-kate-middleton-learn-king-charles-princess-dianas-marriage)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T02:00:59+00:00

The paperback version of Andrew Morton&apos;s &quot;The Queen: Her Life&quot; was recently published. The bestselling author is known for being Princess Diana’s biographer.

## AI robots capable of carrying out attack on NHS that would cause COVID-like disruption, expert warns
 - [https://www.foxnews.com/world/ai-robots-capable-carrying-out-attack-nhs-would-cause-covid-like-disruption-expert-warns](https://www.foxnews.com/world/ai-robots-capable-carrying-out-attack-nhs-would-cause-covid-like-disruption-expert-warns)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T02:00:58+00:00

The rapid advancement of artificial intelligence could lead to a crippling attack on the U.K.&apos;s NHS system, causing a disruption on the scale of the COVID-19 pandemic.

## New AI offers 'personal protection' against abductions, criminal threats
 - [https://www.foxnews.com/us/new-ai-offers-personal-protection-against-abductions-criminal-threats](https://www.foxnews.com/us/new-ai-offers-personal-protection-against-abductions-criminal-threats)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T02:00:58+00:00

Protect, an artificial intelligence-powered app, analyzes video in an emergency or potential issue,like bullying, identifies “key elements&quot; within that video stream as it&apos;s coming in.

## The greatest threat to America’s power grid is not what you think
 - [https://www.foxnews.com/opinion/greatest-threat-americas-power-grid-what-think](https://www.foxnews.com/opinion/greatest-threat-americas-power-grid-what-think)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T02:00:52+00:00

The greatest threat to America’s power grid is Democrat policies. Renewable subsidies and mandates distort electricity markets, jeopardizing baseload power.

## On this day in history, September 18, 1870, Old Faithful geyser in Wyoming is documented and named
 - [https://www.foxnews.com/lifestyle/this-day-history-september-18-1870-old-faithful-geyser-wyoming-discovered-named](https://www.foxnews.com/lifestyle/this-day-history-september-18-1870-old-faithful-geyser-wyoming-discovered-named)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T00:02:35+00:00

The geyser Old Faithful was named on this day in history, September 18, 1870, after an explorer noticed the eruptions were quite &quot;faithful.&quot; It remains a popular tourist attraction.

## History of Halloween: The origins of the holiday
 - [https://www.foxnews.com/lifestyle/history-halloween-origins-holiday](https://www.foxnews.com/lifestyle/history-halloween-origins-holiday)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-18T00:00:40+00:00

Halloween celebrations may include Halloween costumes, trick-or-treating, candy and funny pranks. Here&apos;s a look at the history of the spooky holiday and how it reportedly got its start.

