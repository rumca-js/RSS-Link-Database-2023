# Source:KnowledgeHusk, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw, language:en-US

## Marvel CGI Artists Are Angry
 - [https://www.youtube.com/watch?v=zbHHOGyyXu8](https://www.youtube.com/watch?v=zbHHOGyyXu8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC2_KC8lshtCyiLApy27raYw
 - date published: 2023-09-18T19:00:23+00:00

Disney make people mad. The guys who made iron man cool are now sad. Was art itself just a fad? Found out today on….Knowledge….Rad?

VFX artists often get the short end of the stick in Hollywood, and I for one am happy to see them standing up to the house of mouse. But of course, nothing is ever so simple and clean and nice in the world of business, so that’s what I’m probably going to tag about.



Soundcloud: https://soundcloud.com/user-503704039
Patreon: https://www.patreon.com/theknowledgehub
Discord: https://discord.gg/JqG2ewhu
Second/Livestreaming Channel: https://www.youtube.com/c/Whimsu

