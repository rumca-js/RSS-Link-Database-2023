# Source:TNV24 Najważniejsze, URL:https://tvn24.pl/najwazniejsze.xml, language:pl-PL

## Kolejna kontrowersja w meczu ekstraklasy. Grad goli w Mielcu
 - [https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/stal-mielec-zaglebie-lubin-wynik-i-relacja_sto9802860/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/pko-bp-ekstraklasa/2023-2024/stal-mielec-zaglebie-lubin-wynik-i-relacja_sto9802860/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T20:12:37+00:00

<img alt="Kolejna kontrowersja w meczu ekstraklasy. Grad goli w Mielcu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6jnino-decyzja-sedziego-marcina-kochanka-ustawila-mecz-7349806/alternates/LANDSCAPE_1280" />
    Drużyna z Dolnego Śląska od 28. minuty grała w dziesiątkę. Czy słusznie?

## Reakcje w Niemczech, ustalenia hiszpańskiej agencji. Zagraniczne media o aferze wizowej
 - [https://fakty.tvn24.pl/fakty-o-swiecie/ostre-reakcje-w-niemczech-ustalenia-hiszpanskiej-agencji-prasowej-zagraniczne-media-o-aferze-wizowej-7349737?source=rss](https://fakty.tvn24.pl/fakty-o-swiecie/ostre-reakcje-w-niemczech-ustalenia-hiszpanskiej-agencji-prasowej-zagraniczne-media-o-aferze-wizowej-7349737?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T20:08:21+00:00

<img alt="Reakcje w Niemczech, ustalenia hiszpańskiej agencji. Zagraniczne media o aferze wizowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-a5j6eo-pap_20230518_0ia-7349810/alternates/LANDSCAPE_1280" />
    Zagraniczne media komentują aferę wizową.

## Galaktyka jak ze snu. W jej sercu kryje się żarłoczna bestia
 - [https://tvn24.pl/tvnmeteo/nauka/teleskop-hubble-sfotografowal-galaktyke-ngc-3156-w-jej-sercu-lezy-czarna-dziura-7349353?source=rss](https://tvn24.pl/tvnmeteo/nauka/teleskop-hubble-sfotografowal-galaktyke-ngc-3156-w-jej-sercu-lezy-czarna-dziura-7349353?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T19:02:22+00:00

<img alt="Galaktyka jak ze snu. W jej sercu kryje się żarłoczna bestia" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-b7plii-galaktyka-ngc-3156-w-obiektywie-kosmicznego-teleskopu-hubblea-7349351/alternates/LANDSCAPE_1280" />
    Uchwycił ją Kosmiczny Teleskop Hubble'a.

## Księżniczka Turandot i trzy zagadki w pytaniu z "Milionerów"
 - [https://tvn24.pl/toteraz/milionerzy-w-jakim-miescie-mandaryn-oglasza-ze-kandydat-do-ozenku-z-ksiezniczka-turandot-musi-rozwiazac-trzy-zagadki-odpowiedz-7349086?source=rss](https://tvn24.pl/toteraz/milionerzy-w-jakim-miescie-mandaryn-oglasza-ze-kandydat-do-ozenku-z-ksiezniczka-turandot-musi-rozwiazac-trzy-zagadki-odpowiedz-7349086?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T19:02:00+00:00

<img alt="Księżniczka Turandot i trzy zagadki w pytaniu z " src="https://tvn24.pl/najnowsze/cdn-zdjecie-fpzopc-ksiezniczka-turandot-i-trzy-zagadki-w-pytaniu-z-milionerow-za-piec-tysiecy-zlotych-7349069/alternates/LANDSCAPE_1280" />
    Odpowiadała pani Beata Damek z Bielska-Białej.

## "Człowiek, który powinien dostać zarzuty, zostać zdymisjonowany, jest traktowany w sposób VIP-owski"
 - [https://tvn24.pl/polska/wybuch-granatnika-w-komendzie-glownej-policji-ujawnione-zdjecia-zniszczen-marcin-kierwinski-i-magdalena-biejat-komentuja-7349516?source=rss](https://tvn24.pl/polska/wybuch-granatnika-w-komendzie-glownej-policji-ujawnione-zdjecia-zniszczen-marcin-kierwinski-i-magdalena-biejat-komentuja-7349516?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T18:49:53+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-pfkuap-kropka-7349696/alternates/LANDSCAPE_1280" />
    Posłowie Marcin Kierwiński (KO) i Magdalena Biejat (Lewica) w "Kropce nad i".

## Ryszard Jedliński nie żyje. Był medalistą mistrzostw świata
 - [https://eurosport.tvn24.pl/pilka-reczna/nie-zyje-ryszard-jedlinski.-byly-reprezentant-polski-w-pilce-recznej-mial-70-lat_sto9802723/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-reczna/nie-zyje-ryszard-jedlinski.-byly-reprezentant-polski-w-pilce-recznej-mial-70-lat_sto9802723/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T18:49:22+00:00

<img alt="Ryszard Jedliński nie żyje. Był medalistą mistrzostw świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-2bt2f9-ryszard-jedlinski-to-byly-reprezentant-polski-w-pilce-recznej-7349732/alternates/LANDSCAPE_1280" />
    Były 151-krotny reprezentant Polski w piłce ręcznej, olimpijczyk z Moskwy (1980).

## Fragment wojskowego planu w spocie Mariusza Błaszczaka. "Z całego dokumentu można wniosek odwrotny wyciągnąć"
 - [https://fakty.tvn24.pl/zobacz-fakty/fragment-wojskowego-planu-w-spocie-mariusza-blaszczaka-z-calego-dokumentu-mozna-wniosek-odwrotny-wyciagnac-7349676?source=rss](https://fakty.tvn24.pl/zobacz-fakty/fragment-wojskowego-planu-w-spocie-mariusza-blaszczaka-z-calego-dokumentu-mozna-wniosek-odwrotny-wyciagnac-7349676?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T18:12:05+00:00

<img alt="Fragment wojskowego planu w spocie Mariusza Błaszczaka. " src="https://fakty.tvn24.pl/najnowsze/cdn-zdjecie-qktuay-zalewska-000055-7349530/alternates/LANDSCAPE_1280" />
    Dokument pochodzi z wojska i dotyczy działań na wypadek wojny.

## Winiarz zginął, ratując kolegę, który stracił przytomność w kadzi
 - [https://tvn24.pl/swiat/wlochy-treviso-winiarz-zginal-probujac-ratowac-kolege-ktory-zemdlal-w-kadzi-7349553?source=rss](https://tvn24.pl/swiat/wlochy-treviso-winiarz-zginal-probujac-ratowac-kolege-ktory-zemdlal-w-kadzi-7349553?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:43:36+00:00

<img alt="Winiarz zginął, ratując kolegę, który stracił przytomność w kadzi" src="https://tvn24.pl/najnowsze/cdn-zdjecie-flm9c3-wypadek-w-winiarni-we-wloszech-7349579/alternates/LANDSCAPE_1280" />
    We Włoszech opodal Wenecji.

## Polki po historycznym meczu. "Ojej, każda z nas miała łzy w oczach"
 - [https://eurosport.tvn24.pl/pilka-nozna/amp-futbol-kobiet.-polska-usa-wynik-i-relacja.-pierwszy-mecz-w-historii-reprezentacji-polski_sto9802741/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/amp-futbol-kobiet.-polska-usa-wynik-i-relacja.-pierwszy-mecz-w-historii-reprezentacji-polski_sto9802741/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:38:27+00:00

<img alt="Polki po historycznym meczu. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-727lyb-polskie-amp-futbolistki-pokonaly-amerykanki-7349663/alternates/LANDSCAPE_1280" />
    W pierwszym międzypaństwowym meczu biało-czerwone amp futbolistki pokonały USA.

## Prokurator, która rozpracowywała rosyjskich i chińskich szpiegów, odeszła na emeryturę
 - [https://tvn24.pl/polska/prokurator-anna-karlinska-ktora-prowadzila-sprawy-rosyjskich-i-chinskich-szpiegow-odeszla-na-emeryture-7349184?source=rss](https://tvn24.pl/polska/prokurator-anna-karlinska-ktora-prowadzila-sprawy-rosyjskich-i-chinskich-szpiegow-odeszla-na-emeryture-7349184?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:31:50+00:00

<img alt="Prokurator, która rozpracowywała rosyjskich i chińskich szpiegów, odeszła na emeryturę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bua3uc-pap_20230413_0sa-1-7349586/alternates/LANDSCAPE_1280" />
    Prowadziła sprawę podejrzanego o szpiegostwo na rzecz Rosji Tomasza L., członka komisji likwidacyjnej WSI.

## MSZ podało dane. Politycy PiS dalej wolą mówić o "kilkuset wizach"
 - [https://fakty.tvn24.pl/zobacz-fakty/afera-wizowa-msz-podalo-dane-o-liczbie-wydanych-wiz-politycy-pis-dalej-wola-mowic-o-kilkuset-wizach-7349520?source=rss](https://fakty.tvn24.pl/zobacz-fakty/afera-wizowa-msz-podalo-dane-o-liczbie-wydanych-wiz-politycy-pis-dalej-wola-mowic-o-kilkuset-wizach-7349520?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:31:20+00:00

<img alt="MSZ podało dane. Politycy PiS dalej wolą mówić o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-id5e56-msz-pap_20221228_0oi-7349754/alternates/LANDSCAPE_1280" />
    MSZ podało dane o liczbie wydanych wiz, politycy PiS dalej wolą mówić o "kilkuset wizach".

## Świątek przebiła magiczną granicę
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-przekroczyla-granice-20-milionow-dolarow-zarobionych-na-korcie-od-poczatku-kariery_sto9802600/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-przekroczyla-granice-20-milionow-dolarow-zarobionych-na-korcie-od-poczatku-kariery_sto9802600/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:23:24+00:00

<img alt="Świątek przebiła magiczną granicę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-c3d9is-iga-swiatek-to-wiceliderka-swiatowego-rankingu-7349637/alternates/LANDSCAPE_1280" />
    Została 23. taką tenisistką w historii.

## Dla pięciorga Amerykanów "koszmar się skończył"
 - [https://tvn24.pl/swiat/usa-iran-pieciu-amerykanow-uwolnionych-w-ramach-porozumienia-z-iranem-w-tle-6-miliardow-dolarow-dla-teheranu-7349377?source=rss](https://tvn24.pl/swiat/usa-iran-pieciu-amerykanow-uwolnionych-w-ramach-porozumienia-z-iranem-w-tle-6-miliardow-dolarow-dla-teheranu-7349377?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T17:11:04+00:00

<img alt="Dla pięciorga Amerykanów " src="https://tvn24.pl/najnowsze/cdn-zdjecie-7hl5ld-pieciu-amerykanow-zwolnionych-w-ramach-wymiany-wiezniow-z-iranem-7349505/alternates/LANDSCAPE_1280" />
    W tle 6 miliardów dolarów dla Teheranu.

## To kluczowy sojusznik Rosji. Czy właśnie wymyka się z orbity Kremla?
 - [https://tvn24.pl/swiat/cnn-analiza-rosja-traci-armenie-najstarszego-sojusznika-na-kaukazie-poludniowym-7349346?source=rss](https://tvn24.pl/swiat/cnn-analiza-rosja-traci-armenie-najstarszego-sojusznika-na-kaukazie-poludniowym-7349346?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T16:46:58+00:00

<img alt="To kluczowy sojusznik Rosji. Czy właśnie wymyka się z orbity Kremla?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1dt7hy-shutterstock_1583471683-7349580/alternates/LANDSCAPE_1280" />
    Władze w Erywaniu coraz częściej wyrażają niezadowolenie.

## Ukraina złożyła skargę na Polskę, Węgry i Słowację do WTO
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-sklada-skarge-do-wto-na-polske-wegry-i-slowacje-za-zakaz-importu-zboz-7349554?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-sklada-skarge-do-wto-na-polske-wegry-i-slowacje-za-zakaz-importu-zboz-7349554?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T16:46:42+00:00

<img alt="Ukraina złożyła skargę na Polskę, Węgry i Słowację do WTO" src="https://tvn24.pl/najnowsze/cdn-zdjecie-j7slzo-pap_20230718_1vw-7349582/alternates/LANDSCAPE_1280" />
    Poinformował ukraiński resort gospodarki.

## Tak zwana "14. emerytura". Poseł PiS o "niedoskonałościach", jest odpowiedź ministerstwa
 - [https://tvn24.pl/biznes/dla-seniora/czternastka-2023-piotr-sak-posel-prawa-i-sprawiedliwosci-o-niedoskonalosciach-ministerstwo-rodziny-i-polityki-spolecznej-odpowiada-7349356?source=rss](https://tvn24.pl/biznes/dla-seniora/czternastka-2023-piotr-sak-posel-prawa-i-sprawiedliwosci-o-niedoskonalosciach-ministerstwo-rodziny-i-polityki-spolecznej-odpowiada-7349356?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T16:21:25+00:00

<img alt="Tak zwana " src="https://tvn24.pl/najnowsze/cdn-zdjecie-r5tggk-obietnice-minus-emerytury-stazowe-6749631/alternates/LANDSCAPE_1280" />
    W związku z sygnałami od seniorów.

## Stysiak uspokaja kibiców. "Nikt nie jest robotem, ale dam z siebie wszystko”
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-magdalena-stysiak-dla-eurosport.pl-o-formie-zespole-meczach-siatk_sto9802580/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-magdalena-stysiak-dla-eurosport.pl-o-formie-zespole-meczach-siatk_sto9802580/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T16:15:31+00:00

<img alt="Stysiak uspokaja kibiców. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-vwo9ma-magdalena-stysiak-7349527/alternates/LANDSCAPE_1280" />
    22-latka to gwiazda siatkarskiej reprezentacji Polski. Magdalena Stysiak w dwóch spotkaniach turnieju kwalifikacyjnego do igrzysk w Paryżu zdobyła 40 punktów. Teraz czas na wtorkowy mecz z Kolumbijkami. - Nie wiem, czego się spodziewać. Widzę, że to są dziewczyny dobrze zbudowane, wysokie. Na pewno dam z siebie wszystko. - mówi atakująca w rozmowie eurosport.pl.

## Morawiecki: przepraszamy za nasze grzechy
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-mateusz-morawiecki-w-narolu-przepraszamy-za-nasze-grzechy-7349428?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-mateusz-morawiecki-w-narolu-przepraszamy-za-nasze-grzechy-7349428?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T16:02:54+00:00

<img alt="Morawiecki: przepraszamy za nasze grzechy" src="https://tvn24.pl/najnowsze/cdn-zdjecie-5661ap-premier-mateusz-morawiecki-w-miejscowosci-narol-7349460/alternates/LANDSCAPE_1280" />
    Premier pojawił się w poniedziałek gospodarstwie rolnym w miejscowości Narol na Podkarpaciu.

## Poleciał na wymarzone wakacje, wrócił z chorobą Guillaine'a-Barrego
 - [https://tvn24.pl/swiat/wielka-brytania-wrocil-z-wakacji-z-zespolem-guillainea-barrego-co-to-za-choroba-7349057?source=rss](https://tvn24.pl/swiat/wielka-brytania-wrocil-z-wakacji-z-zespolem-guillainea-barrego-co-to-za-choroba-7349057?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T15:52:34+00:00

<img alt="Poleciał na wymarzone wakacje, wrócił z chorobą Guillaine'a-Barrego" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lm0mzc-bali-7331037/alternates/LANDSCAPE_1280" />
    Pierwszym objawem były problemy żołądkowe.

## Mały ZUS mocno w górę. "Historyczny wzrost"
 - [https://tvn24.pl/biznes/dlafirm/maly-zus-skladki-w-2024-roku-o-ile-wzrosna-ile-beda-placic-przedsiebiorcy-wyliczenia-7349383?source=rss](https://tvn24.pl/biznes/dlafirm/maly-zus-skladki-w-2024-roku-o-ile-wzrosna-ile-beda-placic-przedsiebiorcy-wyliczenia-7349383?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T15:44:07+00:00

<img alt="Mały ZUS mocno w górę. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ckka0e-przedsiebiorcy-moga-sprawdzic-status-wniosku-4522017/alternates/LANDSCAPE_1280" />
    Ważna informacja dla nowych przedsiębiorców.

## Co się stało na wschodzie Hiszpanii?
 - [https://tvn24.pl/tvnmeteo/swiat/hiszpania-gradobicie-bialo-jak-zima-bryly-lodu-mialy-wielkosc-orzechow-wloskich-i-pilek-tenisowych-7349028?source=rss](https://tvn24.pl/tvnmeteo/swiat/hiszpania-gradobicie-bialo-jak-zima-bryly-lodu-mialy-wielkosc-orzechow-wloskich-i-pilek-tenisowych-7349028?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T15:37:55+00:00

<img alt="Co się stało na wschodzie Hiszpanii?" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-5bxpmb-grad-7349402/alternates/LANDSCAPE_1280" />
    Nagrania.

## Ledwie wywalczył trofeum, już je oddaje. O'Sullivan "przygotowuje się na śmierć"
 - [https://eurosport.tvn24.pl/snooker/shanghai-masters/2023-2024/ronnie-o-sullivan-odda-trofeum-wywalczone-w-shanghai-masters_sto9802238/story.shtml?source=rss](https://eurosport.tvn24.pl/snooker/shanghai-masters/2023-2024/ronnie-o-sullivan-odda-trofeum-wywalczone-w-shanghai-masters_sto9802238/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T15:30:06+00:00

<img alt="Ledwie wywalczył trofeum, już je oddaje. O'Sullivan " src="https://tvn24.pl/najnowsze/cdn-zdjecie-i8l4ct-ronnie-osullivan-wygral-shanghai-masters-7349466/alternates/LANDSCAPE_1280" />
    Ronnie O’Sullivan jest snookerzystą jedynym w swoim rodzaju.

## Joanna Pacak pewna drużyny. "Nie ma problemu, którego nie da się rozwiązać"
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-joanna-pacak-dla-eurosport.pl-przed-meczem-z-kolumbia.-co-powiedz_sto9802625/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-joanna-pacak-dla-eurosport.pl-przed-meczem-z-kolumbia.-co-powiedz_sto9802625/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T15:11:10+00:00

<img alt="Joanna Pacak pewna drużyny. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-8jwbvm-joanna-pacak-7349439/alternates/LANDSCAPE_1280" />
    Reprezentacja Polski siatkarek bardzo dobrze radzi sobie w turnieju kwalifikacyjnym do igrzysk w Paryżu.

## Czterodniowy tydzień pracy w Polsce? Ekspert komentuje
 - [https://tvn24.pl/biznes/dlafirm/praca-czterodniowy-tydzien-pracy-w-polsce-branze-jacek-mecina-doradca-zarzadu-lewiatana-komentuje-7349326?source=rss](https://tvn24.pl/biznes/dlafirm/praca-czterodniowy-tydzien-pracy-w-polsce-branze-jacek-mecina-doradca-zarzadu-lewiatana-komentuje-7349326?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T14:34:59+00:00

<img alt="Czterodniowy tydzień pracy w Polsce? Ekspert komentuje " src="https://tvn24.pl/najnowsze/cdn-zdjecie-es0jae-biuro-praca-s-shutterstock1671735760-5418762/alternates/LANDSCAPE_1280" />
    Komentarz przedstawiciela organizacji zrzeszającej przedsiębiorców.

## Media: Rosja straciła ważnego dowódcę
 - [https://tvn24.pl/swiat/wojna-w-ukrainie-doniesienia-o-smierci-dowodcy-rosyjskiej-31-brygady-andrieja-kondraszkina-7348998?source=rss](https://tvn24.pl/swiat/wojna-w-ukrainie-doniesienia-o-smierci-dowodcy-rosyjskiej-31-brygady-andrieja-kondraszkina-7348998?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T14:31:49+00:00

<img alt="Media: Rosja straciła ważnego dowódcę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lbeco2-kondraszkin-7348916/alternates/LANDSCAPE_1280" />
    Poinformowała ukraińska sekcja Radia Swoboda.

## Trudny początek nie złamał Linette. Popis od drugiego seta w Kantonie
 - [https://eurosport.tvn24.pl/tenis/wta-guangzhou/2023/magda-linette-jodie-burrage-wynik-i-relacja-meczu-1.-rundy-turnieju-wta-w-kantonie-2023_sto9802468/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/wta-guangzhou/2023/magda-linette-jodie-burrage-wynik-i-relacja-meczu-1.-rundy-turnieju-wta-w-kantonie-2023_sto9802468/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T14:17:14+00:00

<img alt="Trudny początek nie złamał Linette. Popis od drugiego seta w Kantonie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-wfaoke-magda-linette-to-druga-rakieta-polski-7349344/alternates/LANDSCAPE_1280" />
    Polka awansowała do 1/8 finału.

## Jest nowy trop w sprawie zaginięcia 16-letniego Krzysztofa
 - [https://tvn24.pl/tvnwarszawa/ulice/zaginal-krzysztof-dyminski-nowe-nagranie-z-wielkopolski-7348768?source=rss](https://tvn24.pl/tvnwarszawa/ulice/zaginal-krzysztof-dyminski-nowe-nagranie-z-wielkopolski-7348768?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T13:58:02+00:00

<img alt="Jest nowy trop w sprawie zaginięcia 16-letniego Krzysztofa " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ww3xh-poszukiwany-16-letni-krzysztof-7348719/alternates/LANDSCAPE_1280" />
    "Jeśli to ty, proszę odezwij się".

## Kierowca wjechał autem w dwie działaczki podczas politycznego festynu
 - [https://tvn24.pl/tvnwarszawa/najnowsze/wegrow-kierowca-wjechal-autem-w-dwie-dzialaczki-podczas-politycznego-festynu-sprawa-zajmuje-sie-policja-7349243?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/wegrow-kierowca-wjechal-autem-w-dwie-dzialaczki-podczas-politycznego-festynu-sprawa-zajmuje-sie-policja-7349243?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T13:43:22+00:00

<img alt="Kierowca wjechał autem w dwie działaczki podczas politycznego festynu" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-cm87k2-potracone-zostaly-dwie-dzialaczki-po-7349245/alternates/LANDSCAPE_1280" />
    Sprawą zajmuje się policja.

## Polska libero pewna siebie. "Jesteśmy stworzone do tego, aby grać na wysokim poziomie"
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-maria-stenzel-po-meczu-polska-korea-poludniowa-siatkowka-kobiet_sto9802135/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-maria-stenzel-po-meczu-polska-korea-poludniowa-siatkowka-kobiet_sto9802135/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T13:40:00+00:00

<img alt="Polska libero pewna siebie. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-2kmapk-maria-stenzel-w-trakcie-meczu-z-korea-7349199/alternates/LANDSCAPE_1280" />
    Reprezentację Polski siatkarek trudno wyobrazić sobie bez Marii Stenzel.

## Łabędzie przeszły przez jezdnię mądrzej niż niejeden człowiek
 - [https://tvn24.pl/tvnmeteo/polska/wabrzezno-labedzie-przeszly-rzadkiem-przez-przejscie-dla-pieszych-wideo-7349137?source=rss](https://tvn24.pl/tvnmeteo/polska/wabrzezno-labedzie-przeszly-rzadkiem-przez-przejscie-dla-pieszych-wideo-7349137?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T13:30:25+00:00

<img alt="Łabędzie przeszły przez jezdnię mądrzej niż niejeden człowiek" src="https://tvn24.pl/tvnmeteo/najnowsze/cdn-zdjecie-siv6g6-labedzia-rodzina-z-wabrzezna-7349214/alternates/LANDSCAPE_1280" />
    Nagranie otrzymaliśmy na Kontakt 24.

## "Rozdarta" wieś "nawet przy stole". "Łatwo jest Polaka kupić za jego własne pieniądze"
 - [https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2445,S00E2445,1163839?source=rss](https://tvn24.pl/go/programy,7/czarno-na-bialym-odcinki,11367/odcinek-2445,S00E2445,1163839?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T13:01:05+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-9oddou-czarno-na-bialym-o-wsi-7349142/alternates/LANDSCAPE_1280" />
    Radomir Czarnecki pyta rolników i mieszkańców wsi, na kogo będą głosować.

## "Po wyborach przyszły, demokratyczny rząd rozliczy aferę wizową do ostatniej wizy"
 - [https://tvn24.pl/wybory-parlamentarne-2023/afera-wizowa-komentarze-politykow-trzecia-droga-chce-rozliczyc-afere-wizowa-a-ko-pociagnac-do-odpowiedzialnosci-urzednikow-i-sluzby-7348961?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/afera-wizowa-komentarze-politykow-trzecia-droga-chce-rozliczyc-afere-wizowa-a-ko-pociagnac-do-odpowiedzialnosci-urzednikow-i-sluzby-7348961?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T12:41:57+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rv62ey-politycy-sklejka-7348941/alternates/LANDSCAPE_1280" />
    Opozycja chce "rozliczyć" aferę wizową. Polityk PiS mówi o potrzebie "rąk do pracy".

## Ciała trzech noworodków zakopane w piwnicy. Jedno z dzieci urodziło się kilka tygodni temu
 - [https://tvn24.pl/trojmiasto/pomorze-ciala-trzech-noworodkow-w-piwnicy-domu-w-niedziele-odbyla-sie-sekcja-zwlok-7348725?source=rss](https://tvn24.pl/trojmiasto/pomorze-ciala-trzech-noworodkow-w-piwnicy-domu-w-niedziele-odbyla-sie-sekcja-zwlok-7348725?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T12:41:04+00:00

<img alt="Ciała trzech noworodków zakopane w piwnicy. Jedno z dzieci urodziło się kilka tygodni temu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bbspjm-ciala-trzech-noworodkow-w-piwnicy-domu-zarzuty-dla-20-latki-7346484/alternates/LANDSCAPE_1280" />
    W niedzielę odbyła się sekcja zwłok.

## Ofiara księdza pedofila wygrała przed sądem. Kuria musi wypłacić ponad milion złotych
 - [https://tvn24.pl/trojmiasto/gdansk-kujawsko-pomorskie-ofiara-ksiedza-pedofila-wygrala-przed-sadem-kuria-musi-mu-wyplacic-ponad-milion-zlotych-7348996?source=rss](https://tvn24.pl/trojmiasto/gdansk-kujawsko-pomorskie-ofiara-ksiedza-pedofila-wygrala-przed-sadem-kuria-musi-mu-wyplacic-ponad-milion-zlotych-7348996?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T12:32:14+00:00

<img alt="Ofiara księdza pedofila wygrała przed sądem. Kuria musi wypłacić ponad milion złotych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bujdsj-mariusz-milewski-3682622/alternates/LANDSCAPE_1280" />
    Wyrok zapadł w Sądzie Apelacyjnym w Gdańsku (Pomorskie).

## "Rz" o kulisach afery wizowej: współpracownik Piotra Wawrzyka był pośrednikiem w sprzedaży wiz
 - [https://tvn24.pl/polska/afera-wizowa-rzeczpospolita-wspolpracownik-piotra-wawrzyka-edgar-k-byl-posrednikiem-w-sprzedazy-wiz-7348708?source=rss](https://tvn24.pl/polska/afera-wizowa-rzeczpospolita-wspolpracownik-piotra-wawrzyka-edgar-k-byl-posrednikiem-w-sprzedazy-wiz-7348708?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T12:11:05+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-e3fgyi-shutterstock_2187010693-7349099/alternates/LANDSCAPE_1280" />
    Dziennik otrzymał z lubelskiego sądu treść zarzutów postawionych zatrzymanym.

## Inflacja bazowa w Polsce. Są nowe dane
 - [https://tvn24.pl/biznes/z-kraju/inflacja-bazowa-sierpien-2023-nbp-podal-nowe-dane-7348423?source=rss](https://tvn24.pl/biznes/z-kraju/inflacja-bazowa-sierpien-2023-nbp-podal-nowe-dane-7348423?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T12:01:17+00:00

<img alt="Inflacja bazowa w Polsce. Są nowe dane" src="https://tvn24.pl/najnowsze/cdn-zdjecie-gvzi95-pilne-5496805/alternates/LANDSCAPE_1280" />
    Komunikat NBP.

## "Kupiliśmy bilet, a zwierzęta nic nie robią". Postanowili to zmienić. Nagranie
 - [https://tvn24.pl/poznan/poznan-nowe-zoo-mezczyzna-rzucal-kamieniami-w-bizona-nagranie-7349009?source=rss](https://tvn24.pl/poznan/poznan-nowe-zoo-mezczyzna-rzucal-kamieniami-w-bizona-nagranie-7349009?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:44:07+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-lanywe-zoo-kamien-16-7348823/alternates/LANDSCAPE_1280" />
    Zoo zgłosi sprawę na policję.

## Nagrali się "w intymnej sytuacji". Po wszystkim byli szantażowani
 - [https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-rozebrali-sie-przed-kamera-po-zakonczeniu-nagrania-byli-szantazowani-7348830?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/ciechanow-rozebrali-sie-przed-kamera-po-zakonczeniu-nagrania-byli-szantazowani-7348830?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:37:23+00:00

<img alt="Nagrali się " src="https://tvn24.pl/najnowsze/cdn-zdjecie-ceo4kk-kobiety-zagrozily-ze-opublikuja-wideo-w-sieci-zdjecie-ilustracyjne-7348905/alternates/LANDSCAPE_1280" />
    Zgłosili się na policję.

## Media: Russell Brand oskarżany o napaści na tle seksualnym
 - [https://tvn24.pl/kultura-i-styl/wielka-brytania-media-russell-brand-oskarzany-o-napasci-na-tle-seksualnym-aktor-odpiera-zarzuty-7348786?source=rss](https://tvn24.pl/kultura-i-styl/wielka-brytania-media-russell-brand-oskarzany-o-napasci-na-tle-seksualnym-aktor-odpiera-zarzuty-7348786?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:32:34+00:00

<img alt="Media: Russell Brand oskarżany o napaści na tle seksualnym" src="https://tvn24.pl/najnowsze/cdn-zdjecie-t9dd00-russell-brand-7348753/alternates/LANDSCAPE_1280" />
    Gwiazdor odpiera zarzuty.

## 68-latka ukryła pod ubraniem pięć kilogramów złotych monet. Chciała je przemycić
 - [https://tvn24.pl/lublin/hrebenne-chciala-przemycic-monety-warte-blisko-15-mln-zl-najstarsza-pochodzi-z-1817-roku-przyznala-sie-do-winy-7348832?source=rss](https://tvn24.pl/lublin/hrebenne-chciala-przemycic-monety-warte-blisko-15-mln-zl-najstarsza-pochodzi-z-1817-roku-przyznala-sie-do-winy-7348832?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:26:21+00:00

<img alt="68-latka ukryła pod ubraniem pięć kilogramów złotych monet. Chciała je przemycić" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ax12tr-wszystkie-zostaly-wykonane-ze-zlota-7348847/alternates/LANDSCAPE_1280" />
    Warte były 1,5 miliona zł.

## Bezpieczny kredyt 2 procent w kolejnym dużym banku
 - [https://tvn24.pl/biznes/pieniadze/bezpieczny-kredyt-2-procent-mbank-i-pko-bp-podaly-nowe-dane-o-liczbie-wnioskow-7348934?source=rss](https://tvn24.pl/biznes/pieniadze/bezpieczny-kredyt-2-procent-mbank-i-pko-bp-podaly-nowe-dane-o-liczbie-wnioskow-7348934?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:23:58+00:00

<img alt="Bezpieczny kredyt 2 procent w kolejnym dużym banku" src="https://tvn24.pl/najnowsze/cdn-zdjecie-bdxnqc-zakup-mieszkania-7243844/alternates/LANDSCAPE_1280" />
    Podano pierwsze dane.

## "Masło czarownicy" pojawiło się w polskich lasach
 - [https://tvn24.pl/tvnmeteo/ciekawostki/wykwit-piankowaty-maslo-czarownicy-pojawilo-sie-w-polskich-lasach-7348807?source=rss](https://tvn24.pl/tvnmeteo/ciekawostki/wykwit-piankowaty-maslo-czarownicy-pojawilo-sie-w-polskich-lasach-7348807?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:13:29+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-8ddge2-wykwit-piankowaty-fuligo-septica-zdj-przykladowe-7348765/alternates/LANDSCAPE_1280" />
    Czym jest ten przedziwny organizm?

## Jak sprawdzić swój okręg w wyborach do Sejmu?
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-okregi-wyborcze-do-sejmu-jak-sprawdzic-swoj-okreg-7345195?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-okregi-wyborcze-do-sejmu-jak-sprawdzic-swoj-okreg-7345195?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T11:10:40+00:00

<img alt="Jak sprawdzić swój okręg w wyborach do Sejmu?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z5e268-komisja-wyborcza-wybory-7333465/alternates/LANDSCAPE_1280" />
    Z każdego z okręgów wybrana zostanie określona liczba posłów.

## Rosjanie nie będą zadowoleni
 - [https://eurosport.tvn24.pl/pilka-nozna/alexander-ceferin-dopusci-rosje-do-rozgrywek-po-zakonczeniu-wojny.-prezydent-uefa-o-luisie-rubialesi_sto9802286/story.shtml?source=rss](https://eurosport.tvn24.pl/pilka-nozna/alexander-ceferin-dopusci-rosje-do-rozgrywek-po-zakonczeniu-wojny.-prezydent-uefa-o-luisie-rubialesi_sto9802286/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:42:36+00:00

<img alt="Rosjanie nie będą zadowoleni" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rqlhx3-aleksander-ceferin-7348936/alternates/LANDSCAPE_1280" />
    Zdecydowane stanowisko prezydenta UEFA.

## Szóstka w Lotto. Podano, gdzie padła
 - [https://tvn24.pl/biznes/pieniadze/lask-szostka-wlotto-w-wojewodztwie-lodzkim-wyniki-losowania-lotto-160923-7348843?source=rss](https://tvn24.pl/biznes/pieniadze/lask-szostka-wlotto-w-wojewodztwie-lodzkim-wyniki-losowania-lotto-160923-7348843?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:42:12+00:00

<img alt="Szóstka w Lotto. Podano, gdzie padła" src="https://tvn24.pl/najnowsze/cdn-zdjecie-4iyl70-pieniadze-zdjecie-ilustracyjne-6884407/alternates/LANDSCAPE_1280" />
    Wiemy też, gdzie padła wysoka wygrana w Eurojackpot.

## Praworządność i sytuacja na rynku mieszkaniowym okiem wyborczych debiutantek
 - [https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wyborcze-debiutantki-aleksandra-kot-i-aleksandra-owcao-praworzadnosci-i-rynku-mieszkaniowym-7348608?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/wybory-parlamentarne-2023-wyborcze-debiutantki-aleksandra-kot-i-aleksandra-owcao-praworzadnosci-i-rynku-mieszkaniowym-7348608?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:37:29+00:00

<img alt="Praworządność i sytuacja na rynku mieszkaniowym okiem wyborczych debiutantek  " src="https://tvn24.pl/najnowsze/cdn-zdjecie-9ujc5v-18-0925-czas-decyzji-cl-0014-7348530/alternates/LANDSCAPE_1280" />
    Aleksandra Kot i Aleksandra Owca w programie "Czas Decyzji: debiuty".

## Koniec serialu "Szadź"
 - [https://tvn24.pl/kultura-i-styl/koniec-serialu-szadz-co-wiadomo-o-ostatnim-sezonie-7348629?source=rss](https://tvn24.pl/kultura-i-styl/koniec-serialu-szadz-co-wiadomo-o-ostatnim-sezonie-7348629?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:26:22+00:00

<img alt="Koniec serialu " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uh5fgz-finalowy-sezon-szadzi-7348634/alternates/LANDSCAPE_1280" />
    Trwają zdjęcia do ostatniego, czwartego sezonu. Kiedy go zobaczymy?

## Jedna ze składowych opłat za prąd. Jest propozycja minister klimatu
 - [https://tvn24.pl/biznes/pieniadze/ceny-pradu-2024-oplata-kogeneracyjna-ile-wyniesie-stawka-jest-propozycja-minister-klimatu-i-srodowiska-7348738?source=rss](https://tvn24.pl/biznes/pieniadze/ceny-pradu-2024-oplata-kogeneracyjna-ile-wyniesie-stawka-jest-propozycja-minister-klimatu-i-srodowiska-7348738?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:05:14+00:00

<img alt="Jedna ze składowych opłat za prąd. Jest propozycja minister klimatu" src="https://tvn24.pl/najnowsze/cdn-zdjecie-94m9rm-prad-listwa-zasilanie-wlacznik-wylacznik-przedluzacz-wtyczka-shutterstock_566836174-5412254/alternates/LANDSCAPE_1280" />
    Ile wyniesie stawka w 2024 roku?

## Urząd nałożył ponad 100 tysięcy złotych kary na internetowego sprzedawcę
 - [https://tvn24.pl/biznes/z-kraju/zakupy-przez-internet-uokik-nalozyl-ponad-100-tys-zl-kary-na-sklep-odziezowy-arkadiepl-7348773?source=rss](https://tvn24.pl/biznes/z-kraju/zakupy-przez-internet-uokik-nalozyl-ponad-100-tys-zl-kary-na-sklep-odziezowy-arkadiepl-7348773?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T10:00:41+00:00

<img alt="Urząd nałożył ponad 100 tysięcy złotych kary na internetowego sprzedawcę" src="https://tvn24.pl/najnowsze/cdn-zdjecie-zaxew3-laptop-zakupy-online-7194786/alternates/LANDSCAPE_1280" />
    Wprowadzał klientów w błąd.

## O planach, celach i wyborach. Wyjątkowa konferencja Igi Świątek
 - [https://eurosport.tvn24.pl/tenis/iga-swiatek-wziela-udzial-w-konferencji-prasowej.-kiedy-nastepne-mecze-jakie-sa-cele_sto9802367/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/iga-swiatek-wziela-udzial-w-konferencji-prasowej.-kiedy-nastepne-mecze-jakie-sa-cele_sto9802367/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:49:09+00:00

<img alt="O planach, celach i wyborach. Wyjątkowa konferencja Igi Świątek" src="https://tvn24.pl/najnowsze/cdn-zdjecie-qiagzy-iga-swiatek-7348776/alternates/LANDSCAPE_1280" />
    Iga Świątek z nową energią wraca do rywalizacji w WTA Tour.

## Hołownia o aferze wizowej: perfidia i bezczelność. "Rozliczymy ich do ostatniej wizy"
 - [https://tvn24.pl/go/live,1/go2,9602?source=rss](https://tvn24.pl/go/live,1/go2,9602?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:46:44+00:00

<img alt="Hołownia o aferze wizowej: perfidia i bezczelność. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-lxxiz5-trzecia-droga-7348771/alternates/LANDSCAPE_1280" />
    Konferencja liderów Trzeciej Drogi.

## Program wyborczy PiS. Te obietnice już znamy. Z poprzednich lat
 - [https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-program-wyborczy-pis-te-obietnice-juz-znamy-z-poprzednich-lat-st7348046?source=rss](https://konkret24.tvn24.pl/polityka/wybory-parlamentarne-2023-program-wyborczy-pis-te-obietnice-juz-znamy-z-poprzednich-lat-st7348046?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:32:48+00:00

<img alt="Program wyborczy PiS. Te obietnice już znamy. Z poprzednich lat" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ptrx09-analizujemy-program-wyborczy-pis-7343437/alternates/LANDSCAPE_1280" />
    Co PiS już kiedyś zapowiedział, a teraz powtarza w programie "Bezpieczna przyszłość Polaków".

## W bułgarskim kurorcie spadł uzbrojony dron. Podjęto decyzję o "kontrolowanej eksplozji"
 - [https://tvn24.pl/swiat/tiulenowo-bulgaria-w-kurorcie-nad-morzem-czarnym-spadl-dron-z-pociskiem-7348692?source=rss](https://tvn24.pl/swiat/tiulenowo-bulgaria-w-kurorcie-nad-morzem-czarnym-spadl-dron-z-pociskiem-7348692?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:18:32+00:00

<img alt="W bułgarskim kurorcie spadł uzbrojony dron. Podjęto decyzję o " src="https://tvn24.pl/najnowsze/cdn-zdjecie-56qpjt-dron-znaleziony-w-kurorcie-tiulenowo-w-bulgarii-7348680/alternates/LANDSCAPE_1280" />
    Informuje tamtejsze Ministerstwo Obrony.

## Płaskie napisy dla niewidomych
 - [https://tvn24.pl/kujawsko-pomorskie/wloclawek-absurd-na-nowym-dworcu-pkp-napisy-dla-niewidomych-bez-wypustek-7348507?source=rss](https://tvn24.pl/kujawsko-pomorskie/wloclawek-absurd-na-nowym-dworcu-pkp-napisy-dla-niewidomych-bez-wypustek-7348507?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:15:23+00:00

<img alt="Płaskie napisy dla niewidomych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-z2vruu-tablice-informacyjne-na-dworcu-nie-sa-dostosowane-do-potrzeb-osob-niewidomych-7348381/alternates/LANDSCAPE_1280" />
    Absurd na nowym dworcu.

## Amerykański myśliwiec rozbił się w trakcie ćwiczeń
 - [https://tvn24.pl/swiat/usa-mysliwiec-f-35-robil-sie-w-poblizu-bazy-w-charleston-trwaja-poszukiwania-szczatkow-maszyny-7348488?source=rss](https://tvn24.pl/swiat/usa-mysliwiec-f-35-robil-sie-w-poblizu-bazy-w-charleston-trwaja-poszukiwania-szczatkow-maszyny-7348488?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T09:08:37+00:00

<img alt="Amerykański myśliwiec rozbił się w trakcie ćwiczeń" src="https://tvn24.pl/najnowsze/cdn-zdjecie-y9gy29-f-35-7348520/alternates/LANDSCAPE_1280" />
    Śledczy nie podają na razie, co mogło być przyczyną katastrofy.

## Drugi tydzień Świątek na drugim miejscu w rankingu WTA
 - [https://eurosport.tvn24.pl/tenis/ranking-wta-poniedzialek-18-wrzesnia.-ktore-miejsce-zajmuje-iga-swiatek_sto9802305/story.shtml?source=rss](https://eurosport.tvn24.pl/tenis/ranking-wta-poniedzialek-18-wrzesnia.-ktore-miejsce-zajmuje-iga-swiatek_sto9802305/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:58:43+00:00

<img alt="Drugi tydzień Świątek na drugim miejscu w rankingu WTA" src="https://tvn24.pl/najnowsze/cdn-zdjecie-6lgrsn-iga-swiatek-7348686/alternates/LANDSCAPE_1280" />
    W poniedziałek rozpoczął się drugi tydzień panowania Aryny Sabalenki w kobiecym tenisie. Druga w rankingu WTA jest Iga Świątek, a nieznaczny spadek zanotowała Magda Linette, z 24. na 27. miejsce.

## Rząd ostrzega platformy randkowe. "Nadszedł czas, by branża podniosła standardy"
 - [https://tvn24.pl/swiat/australia-rzad-ostrzega-aplikacje-randkowe-maja-wprowadzic-nowe-standardy-bezpieczenstwa-7348473?source=rss](https://tvn24.pl/swiat/australia-rzad-ostrzega-aplikacje-randkowe-maja-wprowadzic-nowe-standardy-bezpieczenstwa-7348473?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:54:15+00:00

<img alt="Rząd ostrzega platformy randkowe. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-rfnx5b-tinder-randki-7279074/alternates/LANDSCAPE_1280" />
    Władze oczekują poprawy bezpieczeństwa użytkowników tych platform.

## Policja w siedzibie deweloperskiego giganta. Akcje zanurkowały
 - [https://tvn24.pl/biznes/ze-swiata/chiny-evergrande-zatrzymania-niektorych-pracownikow-akcje-china-evergrande-group-zanurkowaly-7348512?source=rss](https://tvn24.pl/biznes/ze-swiata/chiny-evergrande-zatrzymania-niektorych-pracownikow-akcje-china-evergrande-group-zanurkowaly-7348512?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:53:04+00:00

<img alt="Policja w siedzibie deweloperskiego giganta. Akcje zanurkowały" src="https://tvn24.pl/najnowsze/cdn-zdjecie-49x4t7-shutterstock_2048252192-7348624/alternates/LANDSCAPE_1280" />
    Wyprzedaż akcji.

## "W momencie, w którym politycy PiS dochodzą do głosu, to nie najlepiej idzie ta kampania"
 - [https://tvn24.pl/wybory-parlamentarne-2023/rozmowa-piaseckiego-czas-decyzji-bobinski-kiedy-politycy-pis-dochodza-do-glosu-to-nie-najlepiej-idzie-im-kampania-7348505?source=rss](https://tvn24.pl/wybory-parlamentarne-2023/rozmowa-piaseckiego-czas-decyzji-bobinski-kiedy-politycy-pis-dochodza-do-glosu-to-nie-najlepiej-idzie-im-kampania-7348505?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:45:50+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-rnn1d6-andrzej-bobinski-7348369/alternates/LANDSCAPE_1280" />
    Andrzej Bobiński z Polityki Insight w "Rozmowie Piaseckiego: czas decyzji".

## Zawiadomienie NIK "o podejrzeniu popełnienia przestępstwa". RMF FM: chodzi o marszałek Witek
 - [https://tvn24.pl/polska/najwyzsza-izba-kontroli-marian-banas-zawiadomil-prokurature-w-sprawie-marszalek-sejmu-elzbiety-witek-podalo-rmf-fm-7348619?source=rss](https://tvn24.pl/polska/najwyzsza-izba-kontroli-marian-banas-zawiadomil-prokurature-w-sprawie-marszalek-sejmu-elzbiety-witek-podalo-rmf-fm-7348619?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:45:04+00:00

<img alt="Zawiadomienie NIK " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uzjya9-witek-banas-7348632/alternates/LANDSCAPE_1280" />
    Działanie miało doprowadzić do uniemożliwienia funkcjonowania Kolegium NIK.

## "Ujawniam najbardziej strzeżoną tajemnicę państwa PiS. Te zdjęcia nigdy nie miały ujrzeć światła dziennego"
 - [https://tvn24.pl/polska/eksplozja-granatnika-w-komendzie-glownej-policji-senator-krzysztof-brejza-pokazal-zdjecia-wykonane-tuz-po-wybuchu-7348590?source=rss](https://tvn24.pl/polska/eksplozja-granatnika-w-komendzie-glownej-policji-senator-krzysztof-brejza-pokazal-zdjecia-wykonane-tuz-po-wybuchu-7348590?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:25:27+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ghha9p-granatnik-drv-7348612/alternates/LANDSCAPE_1280" />
    Senator Koalicji Obywatelskiej Krzysztof Brejza ujawnił w poniedziałek zdjęcia, które mają dokumentować to, co wydarzyło się osiem miesięcy temu w gmachu Komendy Głównej Policji.

## Ukraina pozwie Polskę, Węgry i Słowację za zakaz importu zbóż
 - [https://tvn24.pl/biznes/ze-swiata/ukraina-pozwie-polske-wegry-i-slowacje-za-zakaz-importu-zboz-taras-kaczka-wiceminister-gospodarki-i-rolnictwa-ukrainy-dla-politico-7348560?source=rss](https://tvn24.pl/biznes/ze-swiata/ukraina-pozwie-polske-wegry-i-slowacje-za-zakaz-importu-zboz-taras-kaczka-wiceminister-gospodarki-i-rolnictwa-ukrainy-dla-politico-7348560?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T08:17:14+00:00

<img alt="Ukraina pozwie Polskę, Węgry i Słowację za zakaz importu zbóż" src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-6ndja7-ukrainskie-zboze-5992298/alternates/LANDSCAPE_1280" />
    Wiceminister gospodarki i rolnictwa Ukrainy Taras Kaczka w wywiadzie dla "Politico.

## Wyrok na policjantkę. Umieściła kobietę w radiowozie na torach, auto staranował pociąg
 - [https://tvn24.pl/swiat/usa-wyrok-na-policjantke-umiescila-kobiete-w-radiowozie-zaparkowanym-na-torach-auto-staranowal-pociag-7348324?source=rss](https://tvn24.pl/swiat/usa-wyrok-na-policjantke-umiescila-kobiete-w-radiowozie-zaparkowanym-na-torach-auto-staranowal-pociag-7348324?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:51:10+00:00

<img alt="Wyrok na policjantkę. Umieściła kobietę w radiowozie na torach, auto staranował pociąg" src="https://tvn24.pl/najnowsze/cdn-zdjecie-ui8nhl-w-radiowozie-potraconym-przez-pociag-znajdowala-sie-kobieta-zakuta-w-kajdanki-7348406/alternates/LANDSCAPE_1280" />
    Zakuła kobietę w kajdanki i zamknęła w policyjnym pojeździe.

## "Pojazdy stanęły w płomieniach". Trzech ratowników nie żyje, dwóch zaginionych
 - [https://tvn24.pl/swiat/libia-wypadek-drogowy-smierc-pieciu-czlonkow-greckiej-ekipy-ratunkowej-7348201?source=rss](https://tvn24.pl/swiat/libia-wypadek-drogowy-smierc-pieciu-czlonkow-greckiej-ekipy-ratunkowej-7348201?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:49:00+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-54i7rw-wypadek-mial-miejsce-w-libii-7348207/alternates/LANDSCAPE_1280" />
    Wypadek Greków, którzy mieli pomagać w Libii.

## "To nie jest tylko sprawa polska, to jest już sprawa na poziomie europejskim"
 - [https://tvn24.pl/polska/afera-wizowa-w-msz-patryk-wachowiec-to-nie-jest-tylko-sprawa-polska-to-jest-juz-sprawa-na-poziomie-europejskim-7348299?source=rss](https://tvn24.pl/polska/afera-wizowa-w-msz-patryk-wachowiec-to-nie-jest-tylko-sprawa-polska-to-jest-juz-sprawa-na-poziomie-europejskim-7348299?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:28:40+00:00

<img alt="" src="https://tvn24.pl/najnowsze/cdn-zdjecie-d4sqbm-patryk-wachowiec-7348348/alternates/LANDSCAPE_1280" />
    Analityk prawny Forum Obywatelskiego Rozwoju o aferze wizowej.

## Zderzenie samolotów podczas zawodów lotniczych
 - [https://tvn24.pl/swiat/usa-zderzenie-samolotow-podczas-zawodow-lotniczych-w-reno-w-nevadzie-dwoch-pilotow-nie-zyje-7348321?source=rss](https://tvn24.pl/swiat/usa-zderzenie-samolotow-podczas-zawodow-lotniczych-w-reno-w-nevadzie-dwoch-pilotow-nie-zyje-7348321?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:16:02+00:00

<img alt="Zderzenie samolotów podczas zawodów lotniczych" src="https://tvn24.pl/najnowsze/cdn-zdjecie-tpsy4d-t-6-shutterstock_112941703-7348402/alternates/LANDSCAPE_1280" />
    Dwóch pilotów nie żyje.

## Bił tak długo, aż ofiara straciła przytomność. Nie spodziewał się zatrzymania w Polsce
 - [https://tvn24.pl/trojmiasto/powiat-starogardzki-byl-poszukiwany-za-usilowanie-zabojstwa-w-niemczech-zostal-zatrzymany-7348398?source=rss](https://tvn24.pl/trojmiasto/powiat-starogardzki-byl-poszukiwany-za-usilowanie-zabojstwa-w-niemczech-zostal-zatrzymany-7348398?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:14:11+00:00

<img alt="Bił tak długo, aż ofiara straciła przytomność. Nie spodziewał się zatrzymania w Polsce" src="https://tvn24.pl/najnowsze/cdn-zdjecie-m2hr1z-31-latek-poszukiwany-za-usilowanie-zabojstwa-w-niemczech-zatrzymany-na-pomorzu-7348382/alternates/LANDSCAPE_1280" />
    31-latek był poszukiwany za usiłowanie zabójstwa w Niemczech.

## Przybywa alertów IMGW przed groźną pogodą
 - [https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-ulewy-ulewny-deszcz-silny-wiatr-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss](https://tvn24.pl/tvnmeteo/pogoda/alerty-imgw-burze-w-polsce-ulewy-ulewny-deszcz-silny-wiatr-miejscami-we-znaki-moze-dac-sie-wiatr-7348332?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T07:11:24+00:00

<img alt="Przybywa alertów IMGW przed groźną pogodą" src="https://tvn24.pl/najnowsze/cdn-zdjecie-xhp0fc-ulewny-deszcz-deszcz-ulewy-7129147/alternates/LANDSCAPE_1280" />
    Sprawdź, gdzie należy uważać.

## Jaka będzie jesień i zima?
 - [https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jesien-i-zime-20232024-wir-polarny-i-el-nino-moga-namieszac-wstepna-prognoza-dlugoterminowa-7347669?source=rss](https://tvn24.pl/tvnmeteo/pogoda/pogoda-na-jesien-i-zime-20232024-wir-polarny-i-el-nino-moga-namieszac-wstepna-prognoza-dlugoterminowa-7347669?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T06:44:36+00:00

<img alt="Jaka będzie jesień i zima?" src="https://tvn24.pl/najnowsze/cdn-zdjecie-yudk44-pogoda-16-7347828/alternates/LANDSCAPE_1280" />
    El Nino i wir polarny mogą namieszać.

## Szczerba ujawnia dane w sprawie handlu wizami. "Firma musiała mieć autoryzację władz rosyjskich"
 - [https://tvn24.pl/polska/afera-wizowa-o-co-chodzi-michal-szczerba-o-kontroli-poselskiej-ujawnia-dokumenty-z-msz-7348300?source=rss](https://tvn24.pl/polska/afera-wizowa-o-co-chodzi-michal-szczerba-o-kontroli-poselskiej-ujawnia-dokumenty-z-msz-7348300?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T06:06:42+00:00

<img alt="Szczerba ujawnia dane w sprawie handlu wizami. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-t032gf-michal-szczerba-7348298/alternates/LANDSCAPE_1280" />
    Poseł Koalicji Obywatelskiej w "Rozmowie Piaseckiego".

## W tragedii z udziałem samolotu wojskowego zginęło dziecko. Ojciec dziewczynki zabrał głos
 - [https://tvn24.pl/swiat/wlochy-tragedia-z-udzialem-samolotu-wojskowego-pod-turynem-zginelo-dziecko-ojciec-dziewczynki-zabral-glos-7348211?source=rss](https://tvn24.pl/swiat/wlochy-tragedia-z-udzialem-samolotu-wojskowego-pod-turynem-zginelo-dziecko-ojciec-dziewczynki-zabral-glos-7348211?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T05:52:39+00:00

<img alt="W tragedii z udziałem samolotu wojskowego zginęło dziecko. Ojciec dziewczynki zabrał głos" src="https://tvn24.pl/najnowsze/cdn-zdjecie-dg90gv-tragedia-miala-miejsce-w-turynie-7348210/alternates/LANDSCAPE_1280" />
    Cytuje go dziennik "La Repubblica".

## Policja: żądał spłaty fikcyjnego długu, ofiarom groził, że obleje je kwasem
 - [https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policja-zadal-splaty-fikcyjnego-dlugu-ofiarom-grozil-ze-obleje-je-kwasem-7347654?source=rss](https://tvn24.pl/tvnwarszawa/najnowsze/warszawa-policja-zadal-splaty-fikcyjnego-dlugu-ofiarom-grozil-ze-obleje-je-kwasem-7347654?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T05:48:16+00:00

<img alt="Policja: żądał spłaty fikcyjnego długu, ofiarom groził, że obleje je kwasem" src="https://tvn24.pl/tvnwarszawa/najnowsze/cdn-zdjecie-8araal-policyjna-akcja-na-ursusie-7348279/alternates/LANDSCAPE_1280" />
    Zatrzymali podejrzanego 44-latka.

## Węgierscy rolnicy protestują. "Komisja Europejska popełniła ogromny błąd"
 - [https://tvn24.pl/biznes/ze-swiata/zboze-z-ukrainy-komisja-europejska-nie-przedluzyla-embarga-protesty-rolnikow-na-wegrzech-7348251?source=rss](https://tvn24.pl/biznes/ze-swiata/zboze-z-ukrainy-komisja-europejska-nie-przedluzyla-embarga-protesty-rolnikow-na-wegrzech-7348251?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T04:43:10+00:00

<img alt="Węgierscy rolnicy protestują. " src="https://tvn24.pl/biznes/najnowsze/cdn-zdjecie-evd329-protest-wegierskich-rolnikow-na-granicy-z-ukraina-7348249/alternates/LANDSCAPE_1280" />
    Władze Polski, Węgier i Słowacji przedłużyły embargo na import.

## Zastępca szeryfa zastrzelony w radiowozie
 - [https://tvn24.pl/swiat/usa-zastepca-szeryfa-w-los-angeles-zastrzelony-w-zasadzce-mial-30-lat-7348225?source=rss](https://tvn24.pl/swiat/usa-zastepca-szeryfa-w-los-angeles-zastrzelony-w-zasadzce-mial-30-lat-7348225?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T04:42:38+00:00

<img alt="Zastępca szeryfa zastrzelony w radiowozie" src="https://tvn24.pl/najnowsze/cdn-zdjecie-1v8gkd-clinkunbroomer-7348245/alternates/LANDSCAPE_1280" />
    W kalifornijskim mieście Palmdale.

## Niespodziewane emocje w Łodzi. "W kwadracie dla rezerwowych pojawiła się nerwowość"
 - [https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-agnieszka-korneluk-po-meczu-polska-korea-poludniowa-siatkowka-kob_sto9802023/story.shtml?source=rss](https://eurosport.tvn24.pl/siatkowka/kwalifikacje-olimpijskie-kobiet/2023/turniej-kwalifikacyjny-paryz-2024.-agnieszka-korneluk-po-meczu-polska-korea-poludniowa-siatkowka-kob_sto9802023/story.shtml?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T04:12:10+00:00

<img alt="Niespodziewane emocje w Łodzi. " src="https://tvn24.pl/najnowsze/cdn-zdjecie-uh1mvx-korneluk-i-kolezanki-z-kadry-7348246/alternates/LANDSCAPE_1280" />
    Agnieszka Korneluk w niedzielę miała odpoczywać, ale musiała pojawić się na parkiecie, gdy Polki miały problemy w starciu z Koreankami.

## Minister spraw zagranicznych przerywa milczenie w sprawie afery wizowej
 - [https://tvn24.pl/polska/afera-wizowa-minister-spraw-zagranicznych-zbigniew-rau-przerwal-milczenie-7348236?source=rss](https://tvn24.pl/polska/afera-wizowa-minister-spraw-zagranicznych-zbigniew-rau-przerwal-milczenie-7348236?source=rss)
 - RSS feed: https://tvn24.pl/najwazniejsze.xml
 - date published: 2023-09-18T04:00:32+00:00

<img alt="Minister spraw zagranicznych przerywa milczenie w sprawie afery wizowej" src="https://tvn24.pl/najnowsze/cdn-zdjecie-cce3rm-rau-in-nyc-7348242/alternates/LANDSCAPE_1280" />
    Zbigniew Rau jest w Nowym Jorku.

