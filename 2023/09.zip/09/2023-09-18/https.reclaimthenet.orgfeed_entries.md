# Source:Reclaim The Net, URL:https://reclaimthenet.org/feed/, language:en-US

## A Private and Open-Source Reddit Alternative
 - [https://reclaimthenet.org/a-private-and-open-source-reddit-alternative](https://reclaimthenet.org/a-private-and-open-source-reddit-alternative)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T17:55:00+00:00

<a href="https://reclaimthenet.org/a-private-and-open-source-reddit-alternative" rel="nofollow" title="A Private and Open-Source Reddit Alternative"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/l-red-os.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Including a self-hosted option.</p>
<p>The post <a href="https://reclaimthenet.org/a-private-and-open-source-reddit-alternative" rel="nofollow">A Private and Open-Source Reddit Alternative</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## The Pentagon Pays Researcher Who Branded Hunter Biden Laptop Story As “Disinformation”
 - [https://reclaimthenet.org/pentagon-contract-researcher-called-hunter-biden-laptop-story-disinformation](https://reclaimthenet.org/pentagon-contract-researcher-called-hunter-biden-laptop-story-disinformation)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T17:38:19+00:00

<a href="https://reclaimthenet.org/pentagon-contract-researcher-called-hunter-biden-laptop-story-disinformation" rel="nofollow" title="The Pentagon Pays Researcher Who Branded Hunter Biden Laptop Story As &#8220;Disinformation&#8221;"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/pentagon-92.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Awarded with a new contract.</p>
<p>The post <a href="https://reclaimthenet.org/pentagon-contract-researcher-called-hunter-biden-laptop-story-disinformation" rel="nofollow">The Pentagon Pays Researcher Who Branded Hunter Biden Laptop Story As &#8220;Disinformation&#8221;</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Jim Jordan Subpoenas FBI Agent Who Flagged Tweets
 - [https://reclaimthenet.org/jim-jordan-subpoenas-fbi-agent-who-flagged-tweets](https://reclaimthenet.org/jim-jordan-subpoenas-fbi-agent-who-flagged-tweets)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T17:29:05+00:00

<a href="https://reclaimthenet.org/jim-jordan-subpoenas-fbi-agent-who-flagged-tweets" rel="nofollow" title="Jim Jordan Subpoenas FBI Agent Who Flagged Tweets"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/chan-jordan.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Forced to testify.</p>
<p>The post <a href="https://reclaimthenet.org/jim-jordan-subpoenas-fbi-agent-who-flagged-tweets" rel="nofollow">Jim Jordan Subpoenas FBI Agent Who Flagged Tweets</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Hawaii Governor is Hit With First Amendment Lawsuit After Media Reporting On Wildfires is Suppressed
 - [https://reclaimthenet.org/hawaii-governor-is-hit-with-first-amendment-lawsuit-after-media-reporting-on-wildfires-is-suppressed](https://reclaimthenet.org/hawaii-governor-is-hit-with-first-amendment-lawsuit-after-media-reporting-on-wildfires-is-suppressed)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T17:25:15+00:00

<a href="https://reclaimthenet.org/hawaii-governor-is-hit-with-first-amendment-lawsuit-after-media-reporting-on-wildfires-is-suppressed" rel="nofollow" title="Hawaii Governor is Hit With First Amendment Lawsuit After Media Reporting On Wildfires is Suppressed"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/okeefe-maui.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Photo and video journalism is being restricted on "emergency" grounds.</p>
<p>The post <a href="https://reclaimthenet.org/hawaii-governor-is-hit-with-first-amendment-lawsuit-after-media-reporting-on-wildfires-is-suppressed" rel="nofollow">Hawaii Governor is Hit With First Amendment Lawsuit After Media Reporting On Wildfires is Suppressed</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Republicans Move To Prevent Bodies Like a Disinformation Governance Board From Ever Being Created
 - [https://reclaimthenet.org/republicans-block-disinformation-governance-board-attempts](https://reclaimthenet.org/republicans-block-disinformation-governance-board-attempts)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T15:26:48+00:00

<a href="https://reclaimthenet.org/republicans-block-disinformation-governance-board-attempts" rel="nofollow" title="Republicans Move To Prevent Bodies Like a Disinformation Governance Board From Ever Being Created"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/mayorkas-99.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>In response to recent attempts.</p>
<p>The post <a href="https://reclaimthenet.org/republicans-block-disinformation-governance-board-attempts" rel="nofollow">Republicans Move To Prevent Bodies Like a Disinformation Governance Board From Ever Being Created</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## Congressman Tom Emmer Reintroduces Anti-CBDC Bill
 - [https://reclaimthenet.org/congressman-tom-emmer-reintroduces-anti-cbdc-bill](https://reclaimthenet.org/congressman-tom-emmer-reintroduces-anti-cbdc-bill)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T15:12:18+00:00

<a href="https://reclaimthenet.org/congressman-tom-emmer-reintroduces-anti-cbdc-bill" rel="nofollow" title="Congressman Tom Emmer Reintroduces Anti-CBDC Bill"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/tom-emmer-o9034.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>Pushing back against CBDCs.</p>
<p>The post <a href="https://reclaimthenet.org/congressman-tom-emmer-reintroduces-anti-cbdc-bill" rel="nofollow">Congressman Tom Emmer Reintroduces Anti-CBDC Bill</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

## USA v. Google Day 3 and 4 – The Power of Defaults 2
 - [https://reclaimthenet.org/usa-v-google-day-3-and-4-the-power-of-defaults-2](https://reclaimthenet.org/usa-v-google-day-3-and-4-the-power-of-defaults-2)
 - RSS feed: https://reclaimthenet.org/feed/
 - date published: 2023-09-18T14:10:31+00:00

<a href="https://reclaimthenet.org/usa-v-google-day-3-and-4-the-power-of-defaults-2" rel="nofollow" title="USA v. Google Day 3 and 4 &#8211; The Power of Defaults 2"><img alt="" class="webfeedsFeaturedVisual wp-post-image" height="864" src="https://reclaimthenet.org/wp-content/uploads/2023/09/usa-v-google.jpg" style="display: block; margin: auto; margin-bottom: 15px;" width="1536" /></a><p>The trial that could change the internet forever.</p>
<p>The post <a href="https://reclaimthenet.org/usa-v-google-day-3-and-4-the-power-of-defaults-2" rel="nofollow">USA v. Google Day 3 and 4 &#8211; The Power of Defaults 2</a> appeared first on <a href="https://reclaimthenet.org" rel="nofollow">Reclaim The Net</a>.</p>

