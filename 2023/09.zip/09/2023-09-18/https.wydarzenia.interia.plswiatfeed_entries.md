# Source:Wydarzenia Interia - Świat, URL:https://wydarzenia.interia.pl/swiat/feed, language:pl-PL

## Absurdalne oświadczenie Rosji przed Trybunałem w Hadze
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-absurdalne-oswiadczenie-rosji-przed-trybunalem-w-hadze,nId,7033092](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-absurdalne-oswiadczenie-rosji-przed-trybunalem-w-hadze,nId,7033092)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-09-18T15:24:53+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-absurdalne-oswiadczenie-rosji-przed-trybunalem-w-hadze,nId,7033092"><img align="left" alt="Absurdalne oświadczenie Rosji przed Trybunałem w Hadze" src="https://i.iplsc.com/absurdalne-oswiadczenie-rosji-przed-trybunalem-w-hadze/000HOFG2A1CLXY3G-C321.jpg" /></a>- Ukraina twierdzi, że Rosja używa słowa &quot;ludobójstwo&quot; na określenie działań ukraińskich władz. Jednak te oświadczenia nie mogą stanowić naruszeń - przekonuje Giennadij Kuzmin. Przedstawiciel Rosji przed Międzynarodowym Trybunałem Sprawiedliwości w Hadze wygłosił przemówienie powielające propagandowy przekaz Federacji Rosyjskiej w stosunku do wojny w Ukrainie.</p><br clear="all" />

## Wypadek w Niemczech. 76-letnia Polka uwięziona w pojeździe
 - [https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-letnia-polka-uwieziona-w-pojezdzie,nId,7032775](https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-letnia-polka-uwieziona-w-pojezdzie,nId,7032775)
 - RSS feed: https://wydarzenia.interia.pl/swiat/feed
 - date published: 2023-09-18T08:43:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-letnia-polka-uwieziona-w-pojezdzie,nId,7032775"><img align="left" alt="Wypadek w Niemczech. 76-letnia Polka uwięziona w pojeździe" src="https://i.iplsc.com/wypadek-w-niemczech-76-letnia-polka-uwieziona-w-pojezdzie/000HOCX20U8MHJBX-C321.jpg" /></a>Trzy osoby zostały ranne w wypadku drogowym, który miał miejsce w niedzielę w pobliżu Coppenbrügge w Niemczech na drodze krajowej nr 1. Auto, które powinno ustąpić pierwszeństwa przejazdu, prowadziła 76-letnia Polka. Kobieta wraz ze swoim 72-letnim pasażerem oraz kierowcą drugiego pojazdu zostali przetransportowani do szpitali.</p><br clear="all" />

