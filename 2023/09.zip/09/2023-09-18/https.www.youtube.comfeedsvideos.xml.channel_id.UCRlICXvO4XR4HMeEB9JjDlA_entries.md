# Source:Thoughty2, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA, language:en-US

## Why Did This Brilliant Engineer Mysteriously Disappear?
 - [https://www.youtube.com/watch?v=30ZJjasYkr8](https://www.youtube.com/watch?v=30ZJjasYkr8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCRlICXvO4XR4HMeEB9JjDlA
 - date published: 2023-09-18T15:08:38+00:00

Install Raid for Free ✅ IOS/ANDROID/PC: https://pl.go-ga.me/oa0l0myb  and get a special starter pack with an Epic champion ⚡Tallia ⚡Available only for new players. 🎁Use the promo code JTSKIN to get the Epic champion Stag Knight and a Skin for Stag Knight designed by JonTron! Don't miss your chance, the promo code is valid until October 7th, only for new players. 📱If you are an iOS user, enter the promo code here: https://plarium.com/en/redeem/raid-shadow-legends/

Thoughty2 Audiobook: https://geni.us/t2audio
Thoughty2 Book: https://geni.us/t2book
Support Me & Get Early Access: http://bit.ly/t2club
Thoughty2 Merchandise: https://bit.ly/t2merch

Follow Thoughty2
Facebook: https://facebook.com/thoughty2
Instagram: https://instagram.com/thoughty2
Website: http://thoughty2.com

About Thoughty2
Thoughty2 (Arran) is a British YouTuber and gatekeeper of useless facts. Thoughty2 creates mind-blowing factual videos about science, tech, history, opinion and just about everything else.
#Thoughty

