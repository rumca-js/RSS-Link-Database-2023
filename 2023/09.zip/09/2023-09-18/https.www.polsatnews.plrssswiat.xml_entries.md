# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Dania: Artysta wysłał dwa czyste płótna. Muzeum chce od niego tysięcy euro
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/dania-artysta-wyslal-dwa-czyste-plotna-muzeum-chce-od-niego-tysiecy-euro/](https://www.polsatnews.pl/wiadomosc/2023-09-18/dania-artysta-wyslal-dwa-czyste-plotna-muzeum-chce-od-niego-tysiecy-euro/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T19:58:00+00:00

Duński artysta Jens Haaning musi zwrócić 67 tys. euro muzeum Kunsten w Aalborg. Artysta w 2021 roku oddał do placówki dwie swoje prace - czyste płótna, które nazwał... Bierz pieniądze i uciekaj.

## Wielka Brytania: 23-latek wrócił z Bali z rzadką chorobą. Jego organizm "atakuje" sam siebie
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/wielka-brytania-23-latek-wrocil-z-wakacji-z-choroba-guillainea-barrego-zapadl-w-spiaczke/](https://www.polsatnews.pl/wiadomosc/2023-09-18/wielka-brytania-23-latek-wrocil-z-wakacji-z-choroba-guillainea-barrego-zapadl-w-spiaczke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T19:21:00+00:00

Tom Pegg wybrał się na egzotyczny urlop na Bali, a niedługo po powrocie zaczęły mu doskwierać problemy żołądkowe. Później u 23-letniego Brytyjczyka pojawiła się opuchlizna okolic oczu i gardła. Pierwsze wnioski lekarzy były błędne - myśleli, że to alergia. Okazało się jednak, że młody mężczyzna nabawił się rzadkiej, poważnej choroby.

## Francja: Aktywiści chcieli walczyć o klimat. Zatruli rzekę
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/francja-aktywisci-chcieli-walczyc-o-klimat-zatruli-rzeke/](https://www.polsatnews.pl/wiadomosc/2023-09-18/francja-aktywisci-chcieli-walczyc-o-klimat-zatruli-rzeke/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T19:20:00+00:00

Mieszkańcy francuskiego Colmar zaalarmowali władze w sprawie śniętych ryb, które zauważyli w rzece przepływającej przez miasto. Podczas wizji lokalnej martwą rybę znalazł również burmistrz. Jak się okazuje, zwierzęta padły po proteście aktywistów, którzy zatruli wodę, wlewając do niej zielony barwnik.

## Berlin: Aktywiści klimatyczni przykleili się do ulic. Wściekły kierowca zareagował
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/aktywisci-klimatyczni-przykleili-sie-do-ulic-wsciekly-kierowca-zareagowal/](https://www.polsatnews.pl/wiadomosc/2023-09-18/aktywisci-klimatyczni-przykleili-sie-do-ulic-wsciekly-kierowca-zareagowal/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T18:14:00+00:00

Chcą, by Niemcy odeszły od paliw kopalnych co najwyżej w 2030 roku, dlatego w porannym szczycie przykleili się do berlińskich ulic w newralgicznych punktach miasta. Poniedziałkowa akcja grupy Ostatnie pokolenie nie spodobała się jednemu z kierowców. Zaatakował protestujących gazem pieprzowym. Ci sami aktywiści odpowiadają za pomalowanie kolumn Bramy Brandenburskiej.

## Ukraina skarży Polskę do Światowej Organizacji Handlu
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/ukraina-skarzy-polske-do-swiatowej-organizacji-handlu/](https://www.polsatnews.pl/wiadomosc/2023-09-18/ukraina-skarzy-polske-do-swiatowej-organizacji-handlu/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T16:40:00+00:00

Ukraina złożyła skargę na Polskę, Węgry i Słowację do Światowej Organizacji Handlu (WTO) w związku z przedłużeniem embarga na zboże. W piątek Komisja Europejska zdecydowała, by odblokować import produktów rolnych z Ukrainy. Władze w Warszawie, Budapeszcie i Bratysławie samodzielnie przedłużyły embargo.

## USA: Armia zgubiła myśliwiec F-35. Prosi obywateli o pomoc w poszukiwaniach
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-armia-zgubila-mysliwiec-f-35-prosi-obywateli-o-pomoc-w-poszukiwaniach/](https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-armia-zgubila-mysliwiec-f-35-prosi-obywateli-o-pomoc-w-poszukiwaniach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T15:06:00+00:00

Szkolenie na myśliwcu F-35 w Karolinie Południowej zakończyło się awarią. Pilot musiał się katapultować, a jego maszyny nikt do tej pory nie odnalazł. Nie wiadomo też, co dokładnie spowodowało usterkę. Amerykańscy wojskowi zwrócili się do zwykłych mieszkańców Stanów Zjednoczonych, by pomogli im odnaleźć zaginiony myśliwiec.

## Polska skrytykowała Ukrainę w Brukseli. Zawiązuje sojusz państw ws. zboża
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/polska-skrytykowala-ukraine-w-brukseli-zawiazuje-sojusz-panstw-ws-zboza/](https://www.polsatnews.pl/wiadomosc/2023-09-18/polska-skrytykowala-ukraine-w-brukseli-zawiazuje-sojusz-panstw-ws-zboza/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T14:57:00+00:00

Polska skrytykowała plan Ukrainy zakładający kontrolę eksportu zboża. Jednocześnie minister rolnictwa Robert Telus poinformował o rozmowach sojuszu pięciu państw, które sprzeciwiają się zniesieniu embarga na produkty rolne z Ukrainy. Natomiast Kijów rozważa pozwanie Warszawy do Światowej Organizacji Handlu.

## Krym: Ukraińcy zaatakowali łódź podwodną Rosji. Pokazali zdjęcia "Rostowa nad Donem"
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/krym-ukraincy-zaatakowali-lodz-podwodna-rosji-pokazali-zdjecia-rostowa-nad-donem/](https://www.polsatnews.pl/wiadomosc/2023-09-18/krym-ukraincy-zaatakowali-lodz-podwodna-rosji-pokazali-zdjecia-rostowa-nad-donem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T14:44:00+00:00

Do sieci trafiły zdjęcia zniszczonego okrętu podwodnego Rosji, w który celnie uderzyła ukraińska armia. W ubiegłym tygodniu wojsko broniącego się kraju przeprowadziło spektakularny atak na Flotę Czarnomorską w Sewastopolu. Rosjanie podnieśli jednostkę do suchego doku i jak się okazuje, zniszczenia są bardzo poważne.

## Słowacja: Robert Fico może przejąć władzę. Nie chce wysyłać broni Ukrainie
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/slowacja-robert-fico-moze-przejac-wladze-nie-chce-wysylac-broni-ukrainie/](https://www.polsatnews.pl/wiadomosc/2023-09-18/slowacja-robert-fico-moze-przejac-wladze-nie-chce-wysylac-broni-ukrainie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T13:42:00+00:00

Partia Smer przoduje w sondażach na Słowacji, a jej lider, były premier Robert Fico w ostatnim wywiadzie zaprezentował swoje prorosyjskie nastawienie do wojny w Ukrainie. Jak ocenił, konflikt zaczął się w 2014 roku, gdy ukraińscy naziści i faszyści zaczęli zabijać rosyjskich obywateli w Donbasie i Ługańsku. Uznał przy tym, że jeśli wróci do rządu, zablokuje dostarczanie broni Kijowowi.

## Niepozorne objawy nowotworu. Lekarz twierdził, że to "nadwrażliwość"
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/niepozorne-objawy-nowotworu-lekarz-twierdzil-ze-to-nadwrazliwosc/](https://www.polsatnews.pl/wiadomosc/2023-09-18/niepozorne-objawy-nowotworu-lekarz-twierdzil-ze-to-nadwrazliwosc/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T12:11:00+00:00

Opisywała objawy lekarzom i słyszała, że jest przewrażliwiona. Sherri Rollins dwukrotnie chorowała na raka jelita grubego. Choroba za każdym razem miała podobne objawy, które za każdym razem były bagatelizowane. Teraz doświadczona w walce z nowotworem kobieta ostrzega innych.

## Zostawiła zatrzymaną w aucie na torach. Policjantka usłyszała wyrok
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-zostawila-zatrzymana-na-torach-w-aucie-policjantka-uslyszala-wyrok/](https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-zostawila-zatrzymana-na-torach-w-aucie-policjantka-uslyszala-wyrok/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T11:36:00+00:00

Nadzór kuratora i 100 godzin prac społecznych - taki wyrok sądu usłyszała policjantka Jordan Steinke, która skuła w kajdanki 20-latkę i zamknęła w radiowozie zaparkowanym na przejeździe kolejowym. W auto uderzył rozpędzony pociąg towarowy.

## Białoruś gotowa na manewry z Polską? "Trzeba przyjrzeć się wrogowi"
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/bialorus-gotowa-na-manewry-z-polska-trzeba-przyjrzec-sie-wrogowi/](https://www.polsatnews.pl/wiadomosc/2023-09-18/bialorus-gotowa-na-manewry-z-polska-trzeba-przyjrzec-sie-wrogowi/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T09:39:00+00:00

- Jeśli Polacy będą gotowi przeprowadzić z nami manewry, chętnie podejmiemy taką inicjatywę i zastanowimy się, nad jakimi zagadnieniami możemy wspólnie popracować - powiedział pierwszy zastępca sekretarza stanu Rady Bezpieczeństwa Białorusi Paweł Murawiejka na antenie telewizji STV. Powiedział też, kiedy białoruskie wojska rozpoczną swoje zakrojone na szeroką skalę ćwiczenia wojskowe.

## Nie żyje Billy Miller. Amerykański aktor miał 43 lata
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-nie-zyje-billy-miller-gwiazdor-mial-43-lata/](https://www.polsatnews.pl/wiadomosc/2023-09-18/usa-nie-zyje-billy-miller-gwiazdor-mial-43-lata/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T08:34:00+00:00

Nie żyje Billy Miller. Aktor znany był z seriali takich jak Szpital miejski i Żar młodości. Miller miał 43 lata.

## Pogłoski o złym stanie zdrowia Kadyrowa. "Mogą zmniejszyć jego kontrolę nad Czeczenią"
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/pogloski-o-zlym-stanie-zdrowia-kadyrowa-isw-moga-zmniejszyc-jego-kontrole-nad-czeczenia/](https://www.polsatnews.pl/wiadomosc/2023-09-18/pogloski-o-zlym-stanie-zdrowia-kadyrowa-isw-moga-zmniejszyc-jego-kontrole-nad-czeczenia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T06:27:00+00:00

Przedłużające się obawy w Rosji o zły stan zdrowia Ramzana Kadyrowa pokazują jak zależny jest od niego Władimir Putin - stwierdza w poniedziałek amerykański Instytut Studiów nad Wojną (ISW). Wcześniej ukraiński wywiad informował, że przywódca Czeczenii zapadł w śpiączkę. Krótko później sam Kadyrow zareagował na te doniesienia. Autentyczność tej odpowiedzi jest jednak kwestionowana.

## Włochy: Trzęsienie ziemi na północy kraju. Wstrząsy miały magnitudę 4,8
 - [https://www.polsatnews.pl/wiadomosc/2023-09-18/wlochy-trzesienie-ziemi-na-polnocy-kraju-wstrzasy-mialy-magnitude-51/](https://www.polsatnews.pl/wiadomosc/2023-09-18/wlochy-trzesienie-ziemi-na-polnocy-kraju-wstrzasy-mialy-magnitude-51/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-18T05:10:00+00:00

Do trzęsienia ziemi na północy Włoch doszło w poniedziałek nad ranem. Jak przekazała włoska służba geologiczna, miało ono magnitudę 4,8. Wstrząsy były odczuwalne w rejonie prowincji Florencji.

