# Source:Ryan Reynolds, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg, language:en-US

## Official Negroni Week Celebration Video
 - [https://www.youtube.com/watch?v=LaXPxnntOOk](https://www.youtube.com/watch?v=LaXPxnntOOk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCA3-nIYWu4PTWkb6NwhEpzg
 - date published: 2023-09-18T12:34:12+00:00

Here’s a Negroni Week recipe for those who love having the taste of warm pumpkin spice nowhere near their mouth. 

Negroniweek.com

