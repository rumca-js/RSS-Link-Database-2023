# Source:KEXP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA, language:en-US

## Pahua - Full Performance (Live on KEXP)
 - [https://www.youtube.com/watch?v=SJ1BIxqXFjM](https://www.youtube.com/watch?v=SJ1BIxqXFjM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T16:00:29+00:00

http://KEXP.ORG presents Pahua performing live in the KEXP studio. Recorded July 19, 2023

Songs:
Serpiente de Oro
Travesura
El Traketeo
Flor de Jazmín 

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - El Traketeo (Live on KEXP)
 - [https://www.youtube.com/watch?v=MFn1rGx5OWc](https://www.youtube.com/watch?v=MFn1rGx5OWc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T15:44:02+00:00

http://KEXP.ORG presents Pahua performing “El Traketeo” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - Flor de Jazmín (Live on KEXP)
 - [https://www.youtube.com/watch?v=3SDaYoYUDyc](https://www.youtube.com/watch?v=3SDaYoYUDyc)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T15:44:02+00:00

http://KEXP.ORG presents Pahua performing “Flor de Jazmín” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - Travesura (Live on KEXP)
 - [https://www.youtube.com/watch?v=dk7AiPjlxvg](https://www.youtube.com/watch?v=dk7AiPjlxvg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T15:44:02+00:00

http://KEXP.ORG presents Pahua performing “Travesura” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - Travesura (Live on KEXP)
 - [https://www.youtube.com/watch?v=qh_PoXB-FkM](https://www.youtube.com/watch?v=qh_PoXB-FkM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T11:00:40+00:00

http://KEXP.ORG presents Pahua performing “Travesura” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - Serpiente de Oro (Live on KEXP)
 - [https://www.youtube.com/watch?v=maHmkYkrKSo](https://www.youtube.com/watch?v=maHmkYkrKSo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T11:00:38+00:00

http://KEXP.ORG presents Pahua performing “Serpiente de Oro” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - El Traketeo (Live on KEXP)
 - [https://www.youtube.com/watch?v=_PXVdT_Koyo](https://www.youtube.com/watch?v=_PXVdT_Koyo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T11:00:25+00:00

http://KEXP.ORG presents Pahua performing "El Traketeo" live in the KEXP studio. Recorded July 19, 2023

Songs:
Serpiente de Oro
Flor de Jazmín
Travesura
El Traketeo

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

## Pahua - Flor de Jazmín (Live on KEXP)
 - [https://www.youtube.com/watch?v=HPw8-F0wTlE](https://www.youtube.com/watch?v=HPw8-F0wTlE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC3I2GFN_F8WudD_2jUZbojA
 - date published: 2023-09-18T11:00:22+00:00

http://KEXP.ORG presents Pahua performing “Flor de Jazmín” live in the KEXP studio. Recorded July 19, 2023

Paulina Sotomayor - Vocals, Percussion pad
Martín Selasco - Guitar
Bartosz Brenes - DJ, Synths
Mike Gebhart - Percussions

Host: DJ Chilly
Audio Engineers: Julian Martlew, Jon Roberts
Audio Mixers: Ricardo Bernal, Bartosz Brenes
Mastering: Matt Ogaz
Cameras: Jim Beckmann, Carlos Cruz, Alaia D’Alessandro, Scott Holpainen
Editor: Carlos Cruz

@consulmexsea
@mexamnw

https://industriaworks.com/roster/pahua/
http://kexp.org

