# Source:Louis Rossman, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w, language:en-US

## Reflections on repair: after 15 years
 - [https://www.youtube.com/watch?v=oMPxr7I90JM](https://www.youtube.com/watch?v=oMPxr7I90JM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCl2mFZoRqjw_ELax4Yisf6w
 - date published: 2023-09-18T16:25:48+00:00

https://youtu.be/ItIKU93weGY
https://www.youtube.com/playlist?list=PLkVbIsAWN2lsHdY7ldAAgtJug50pRNQv0
https://repair.wiki/w/A1707_2016-2017_15%E2%80%9D_Touchbar_MacBook_Pro
https://www.youtube.com/playlist?list=PLkVbIsAWN2lsmovRO20_gtfUfgWi-XnnT

👉 Merchandise: https://store.rossmanngroup.com/memes-dreams.html
🔵 Cheesy mugs & t-shirts: https://bit.ly/rossmannstore

👉 Rossmann chat: https://matrix.to/#/#rossmannrepair-general:matrix.org

👉 Equipment used:
🔵 Chair: https://ebay.us/uYLTzn
🔵 Microphone: https://amzn.to/3g1hsok
🔵 Mic stand: https://amzn.to/3Vg47ZI
🔵 Audio interface: https://amzn.to/3VuKihx
🔵 Camera: https://amzn.to/3CTk1Av 
🔵 Lighting: https://amzn.to/3RSriGC

👉 Stream FAQ: https://store.rossmanngroup.com/faq.txt

👉 Affiliate:
› Buying on eBay? Support us while you shop! https://www.rossmanngroup.com/ebay
› Rossmann Repair Group Inc is a participant in the Amazon Services LLC Associates Program, an affiliate advertising program designed to provide a means for sites to ear

