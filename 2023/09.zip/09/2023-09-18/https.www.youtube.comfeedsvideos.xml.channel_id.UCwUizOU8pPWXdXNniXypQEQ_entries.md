# Source:AwakenWithJP, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ, language:en-US

## Affirm Your Kids at All Cost!
 - [https://www.youtube.com/watch?v=YCfo8l1yDgs](https://www.youtube.com/watch?v=YCfo8l1yDgs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCwUizOU8pPWXdXNniXypQEQ
 - date published: 2023-09-18T17:41:53+00:00

#shorts

