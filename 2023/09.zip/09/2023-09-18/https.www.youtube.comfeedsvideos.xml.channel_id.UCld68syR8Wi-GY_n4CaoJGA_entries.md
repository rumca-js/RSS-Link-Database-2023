# Source:Brodie Robertson, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA, language:en-US

## Don't Archive Your Repo... Give Away Commit Rights!?!
 - [https://www.youtube.com/watch?v=q4odN8N24qk](https://www.youtube.com/watch?v=q4odN8N24qk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCld68syR8Wi-GY_n4CaoJGA
 - date published: 2023-09-18T21:00:18+00:00

Tons of projects eventually get archived but what if instead of doing that a contributor came along and you just decided to give them all commit rights to the repo and just see what happens. Maybe the result will be positive.

==========Support The Channel==========
► $100 Linode Credit: https://brodierobertson.xyz/linode
► Patreon: https://brodierobertson.xyz/patreon
► Paypal: https://brodierobertson.xyz/paypal
► Liberapay: https://brodierobertson.xyz/liberapay
► Amazon USA: https://brodierobertson.xyz/amazonusa

==========Resources==========
Django Money: https://github.com/django-money/django-money
Commit Rights Blog Post: https://tech.davis-hansson.com/p/clickbait/

=========Video Platforms==========
🎥 Odysee: https://brodierobertson.xyz/odysee
🎥 Podcast: https://techovertea.xyz/youtube
🎮 Gaming: https://brodierobertson.xyz/gaming

==========Social Media==========
🎤 Discord: https://brodierobertson.xyz/discord
🎤 Matrix Space: https://brodierobertson.xyz/matrix
🐦 Twitter: https://

