# Source:Linux Today News, URL:https://www.linuxtoday.com/news/feed, language:en-US

## OpenSUSE Seeks Leap Replacement: Which Distro Will Rise to the Challenge?
 - [https://www.linuxtoday.com/developer/opensuse-seeks-leap-replacement-which-distro-will-rise-to-the-challenge/](https://www.linuxtoday.com/developer/opensuse-seeks-leap-replacement-which-distro-will-rise-to-the-challenge/)
 - RSS feed: https://www.linuxtoday.com/news/feed
 - date published: 2023-09-18T22:00:05+00:00

<p>With SUSE transitioning from its traditional enterprise distribution to its ALP container approach, openSUSE Leap&#8217;s stable base is set to disappear. Now what?</p>
<p>The post <a href="https://www.linuxtoday.com/developer/opensuse-seeks-leap-replacement-which-distro-will-rise-to-the-challenge/" rel="nofollow">OpenSUSE Seeks Leap Replacement: Which Distro Will Rise to the Challenge?</a> appeared first on <a href="https://www.linuxtoday.com" rel="nofollow">Linux Today</a>.</p>

## Coding in Rust? RustRover Is a New IDE by JetBrains
 - [https://www.linuxtoday.com/developer/coding-in-rust-rustrover-is-a-new-ide-by-jetbrains/](https://www.linuxtoday.com/developer/coding-in-rust-rustrover-is-a-new-ide-by-jetbrains/)
 - RSS feed: https://www.linuxtoday.com/news/feed
 - date published: 2023-09-18T20:00:41+00:00

<p>RustRover aims to be a feature-packed stand-alone Rust IDE set to receive regular updates, quick support, and an “out-of-the-box experience.”</p>
<p>The post <a href="https://www.linuxtoday.com/developer/coding-in-rust-rustrover-is-a-new-ide-by-jetbrains/" rel="nofollow">Coding in Rust? RustRover Is a New IDE by JetBrains</a> appeared first on <a href="https://www.linuxtoday.com" rel="nofollow">Linux Today</a>.</p>

