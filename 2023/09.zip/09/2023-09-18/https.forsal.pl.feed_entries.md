# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Jakie zagrożenia przyniosą zmiany klimatyczne? Lemke: Trzeba przemyśleć całą urbanistykę miast i gmin
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9300063,zmiany-klimatyczne-i-zagrozenia-lemke-trzeba-przemyslec-cala-urbanistyke-miast-i-gmin.html](https://forsal.pl/swiat/aktualnosci/artykuly/9300063,zmiany-klimatyczne-i-zagrozenia-lemke-trzeba-przemyslec-cala-urbanistyke-miast-i-gmin.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T22:49:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SrsktkuTURBXy81MTBiODM1Yi1hZmNkLTQ2MjEtOTlhYi03NmZmNWEwNjMyMzkuanBlZ5GTBc0BHcyg" />Minister środowiska Steffi Lemke (Zieloni) powiedziała, że konieczne będzie przygotowanie miast i gmin na zagrożenia płynące ze zmian klimatycznych – szczególnie dłuższych okresów suszy i ulewnych deszczy. „Trzeba przemyśleć całą urbanistykę miast i gmin” – podkreśliła.

## Biały Dom zabrał głos ws. polskiego embarga na ukraińskie zboże
 - [https://forsal.pl/swiat/usa/artykuly/9299843,usa-zabraly-glos-ws-polskiego-embarga-na-ukrainskie-zboze.html](https://forsal.pl/swiat/usa/artykuly/9299843,usa-zabraly-glos-ws-polskiego-embarga-na-ukrainskie-zboze.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T19:47:52+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/iUvktkuTURBXy9kMDhmZjBkNC03ZDg4LTRiYmUtYmFlMS04MTljZGY3MzA5YWMuanBlZ5GTBc0BHcyg" />Blokada importu ukraińskiego zboża na wewnętrzne rynki przez Polskę i inne kraje jest ich suwerenną decyzją i hipokryzją byłoby, gdybyśmy wymuszali na nich zmianę - powiedział w poniedziałek rzecznik Rady Bezpieczeństwa Narodowego John Kirby. Jak dodał, USA zależy jednak na powrocie do eksportu zboża przez Morze Czarne.

## Afera wizowa i wojna konsulów z Wawrzykiem. "Żądali potwierdzenia na piśmie"
 - [https://forsal.pl/gospodarka/polityka/artykuly/9299695,afera-wizowa-i-wojna-konsulow-z-wawrzykiem-zadali-potwierdzenia-na-p.html](https://forsal.pl/gospodarka/polityka/artykuly/9299695,afera-wizowa-i-wojna-konsulow-z-wawrzykiem-zadali-potwierdzenia-na-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T19:03:56+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jLTktkuTURBXy8yNzg4MmQ0Yy1jMDkyLTQ4YTAtODkwZC04MTAzNmJiZDFhYWUuanBlZ5GTBc0BHcyg" />Z informacji DGP wynika, że wiceszef MSZ sugerował konsulom liberalne podejście do kwestii karalności osób ubiegających się o wizy. Ci żądali potwierdzenia na piśmie

## Spory frankowe zatykają duże miasta. Wszystko przez zmianę przepisów
 - [https://forsal.pl/finanse/aktualnosci/artykuly/9299691,spory-frankowe-zatykaja-duze-miasta-wszystko-przez-zmiane-przepisow.html](https://forsal.pl/finanse/aktualnosci/artykuly/9299691,spory-frankowe-zatykaja-duze-miasta-wszystko-przez-zmiane-przepisow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T18:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/CJdktkuTURBXy9kMWM4ZGExNi1iOWYxLTQ5NzQtOTczYi01MjEyNzYzZDYwYzcuanBlZ5GTBc0BHcyg" />Zmiana przepisów o właściwości miejscowej sądu zahamowała napływ spraw do warszawskiego wydziału frankowego.

## Skarga Ukrainy do WTO na Polskę. Jest reakcja rządu w Warszawie
 - [https://forsal.pl/swiat/ukraina/artykuly/9299771,skarga-ukrainy-do-wto-na-polske-jest-reakcja-rzadu-w-warszawie.html](https://forsal.pl/swiat/ukraina/artykuly/9299771,skarga-ukrainy-do-wto-na-polske-jest-reakcja-rzadu-w-warszawie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T17:46:29+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2dOktkuTURBXy9hMDQyMTYyMS0yNzVlLTRkYjUtOTE4Ny04NTY1NTc1ZjMxNjIuanBlZ5GTBc0BHcyg" />Podtrzymujemy swoje stanowisko; skarga Ukrainy do WTO (Światowej Organizacji Handlu) nie robi na nas wrażenia, nie mamy zamiaru z tego powodu cofać się z embarga, które wprowadziliśmy – oświadczył w poniedziałek w Polsat News rzecznik rządu Piotr Müller.

## Ukraina złożyła skargę do WTO na Polskę, Węgry i Słowację
 - [https://forsal.pl/swiat/ukraina/artykuly/9299672,ukraina-zlozyla-skarge-do-wto-na-polske-wegry-i-slowacje.html](https://forsal.pl/swiat/ukraina/artykuly/9299672,ukraina-zlozyla-skarge-do-wto-na-polske-wegry-i-slowacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T16:46:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZARktkuTURBXy9lYzU5YTZlMi0wM2Q3LTRkMTEtODhkYi1mNmQyY2VjM2QxMDEuanBlZ5GTBc0BHcyg" />Ukraina złożyła w poniedziałek skargi do Światowej Organizacji Handlu (WTO) na Polskę, Węgry i Słowację w związku z przedłużeniem przez te kraje embarga na ukraińskie produkty rolne - poinformowała ukraińska minister gospodarki Julia Swyrydenko w komunikacie.

## Telus o decyzji KE ws. zboża z Ukrainy: Jesteśmy rozczarowani
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9299547,telus-o-decyzji-ke-ws-zboza-z-ukrainy-jestesmy-rozczarowani.html](https://forsal.pl/swiat/unia-europejska/artykuly/9299547,telus-o-decyzji-ke-ws-zboza-z-ukrainy-jestesmy-rozczarowani.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T15:47:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/d_IktkuTURBXy9kZWNmYzM0ZC04ZDRkLTQ3YWYtODRiOC0xNDc5ZjYxNGYyNTIuanBlZ5GTBc0BHcyg" />Jesteśmy rozczarowani decyzją Unii Europejskiej w sprawie nieprzedłużenia embarga na import zbóż do 5 krajów UE; wygląda na to, że Unia nie myśli o budowie mechanizmów na przyszłość - powiedział w poniedziałek w Brukseli minister rolnictwa RP Robert Telus.

## Naukowcy alarmują: Papierosy i alkohol wywołują cichą epidemię w Polsce
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9299540,naukowcy-alarmuja-papierosy-i-alkohol-wywoluja-cicha-epidemie-w-polsc.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9299540,naukowcy-alarmuja-papierosy-i-alkohol-wywoluja-cicha-epidemie-w-polsc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T15:31:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Yo-ktkuTURBXy9lZGYwNWUyMy00ZmMwLTQyNzUtODIwZS1hMWU0ZjE2NjM0M2EuanBlZ5GTBc0BHcyg" />Wzrasta w Polsce liczba zgonów wywołanych spożyciem alkoholu i paleniem papierosów. Winę za to ponosi przyzwolenie na wzrost sprzedaży „małpek” i reklamowanie zamienników papierosów jako „bezpieczniejsze dla zdrowia” – uważają naukowcy zasiadający w Komitecie Zdrowia Publicznego PAN.

## To był trudny tydzień dla złotego. Co teraz czeka polską walutę?
 - [https://forsal.pl/finanse/waluty/artykuly/9299536,to-byl-trudny-tydzien-dla-zlotego-co-teraz-czeka-polska-walute.html](https://forsal.pl/finanse/waluty/artykuly/9299536,to-byl-trudny-tydzien-dla-zlotego-co-teraz-czeka-polska-walute.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T15:23:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7LFktkuTURBXy9mNWMzNzk0OS1iNmU4LTQwN2YtOGE3OS02OWFhMWE2YmRjYzMuanBlZ5GTBc0BHcyg" />undefined

## Emilewicz o ukraińskim ministrze rolnictwa: Kiedy się spotykamy, ta narracja jest zupełnie inna
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9299530,emilewicz-o-ukrainskim-ministrze-rolnictwa-kiedy-sie-spotykamy-ta-na.html](https://forsal.pl/biznes/rolnictwo/artykuly/9299530,emilewicz-o-ukrainskim-ministrze-rolnictwa-kiedy-sie-spotykamy-ta-na.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T15:14:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NgektkuTURBXy83MGZkOTgyYS1kNDgwLTRiZjAtYmJlZi00YzIwN2VjODg1NTIuanBlZ5GTBc0BHcyg" />Nie ma kłopotu z dostarczeniem ukraińskiego zboża na rynki, na które ono ma być dostarczone - zaznaczyła w poniedziałek w rozmowie z PAP wiceminister funduszy Jadwiga Emilewicz. Jako &quot;bardzo duży błąd&quot; oceniła ewentualne skierowanie sprawy polskiego embarga do WTO.

## Wiceminister rolnictwa: Rząd ukraiński jest pod wpływem potężnych lobbystów
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9299522,wiceminister-rolnictwa-rzad-ukrainski-jest-pod-wplywem-poteznych-lobb.html](https://forsal.pl/biznes/rolnictwo/artykuly/9299522,wiceminister-rolnictwa-rzad-ukrainski-jest-pod-wplywem-poteznych-lobb.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T14:54:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/s-hktkuTURBXy8yYzE4ZThjZS02MmMxLTRjZDAtYmM2OS01M2I4NDFkNjMwOGUuanBlZ5GTBc0BHcyg" />Rząd ukraiński jest pod silnym wpływem lobbystów, którzy są właścicielami potężnych gospodarstw - powiedział w poniedziałek w Studiu PAP wiceminister rolnictwa i rozwoju wsi Rafał Romanowski.

## Polska zaproponowała dwunasty pakiet sankcji UE wobec Rosji
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9299518,polska-zaproponowala-dwunasty-pakiet-sankcji-ue-wobec-rosji.html](https://forsal.pl/swiat/unia-europejska/artykuly/9299518,polska-zaproponowala-dwunasty-pakiet-sankcji-ue-wobec-rosji.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T14:46:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/f7iktkuTURBXy83OWYyY2E2OS1kZGVjLTRkMGMtYjY2Mi03ZWU5NTcwODViYjUuanBlZ5GTBc0BHcyg" />Polska przedstawiła w Brukseli propozycję 12. pakietu sankcji Unii Europejskiej przeciw Rosji; chodzi o sankcje sektorowe i indywidualne - przekazało PAP wysokie rangą źródło unijne.

## Zgrzyt w Brukseli. Ważny krok Polski, Węgier i Słowacji ws. ukraińskiego zboża
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9299404,zgrzyt-w-brukseli-wazny-krok-polski-wegier-i-slowacji-ws-ukrainskie.html](https://forsal.pl/swiat/unia-europejska/artykuly/9299404,zgrzyt-w-brukseli-wazny-krok-polski-wegier-i-slowacji-ws-ukrainskie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T14:36:49+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/e5_ktkuTURBXy8yZWU1MDQ4ZC02NTljLTRkNDMtYmU0Mi1lZTM5NjllYzg2ZWMuanBlZ5GTBc0BHcyg" />W związku z zapowiedziami Ukrainy o wszczęciu postępowania przeciw Polsce, Węgrom i Słowacji przed Światową Organizacją Handlu (WTO), te trzy kraje UE nie będą uczestniczyć w pracach platformy ds. ukraińskiego zboża w Brukseli - poinformowało PAP źródło unijne.

## Polska skrytykowała nową propozycję Ukrainy dotyczącą zboża
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9299397,polska-skrytykowala-nowa-propozycje-ukrainy-dotyczaca-zboza.html](https://forsal.pl/swiat/unia-europejska/artykuly/9299397,polska-skrytykowala-nowa-propozycje-ukrainy-dotyczaca-zboza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T14:29:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/niJktkuTURBXy9iMGQzODcyYy0yODJjLTRmMTEtODgyNi0zY2Q5OTQ5YWQxMTMuanBlZ5GTBc0BHcyg" />Ukraina przedstawiła Komisji Europejskiej w Brukseli propozycję dotyczącą wwozu swojego zboża do krajów Unii Europejskiej, która zakłada system pozwoleń na eksport. Ostatecznie Kijów miałby decydować o tych pozwoleniach, nawet w przypadku sprzeciwu państw UE. Kraje graniczące z Ukrainą, w tym Polska, sprzeciwiły się propozycji - przekazało PAP źródło unijne.

## Zgrzyt na linii Niemcy-Chiny. Pekin złożył skargę na szefową niemieckiego MSZ
 - [https://forsal.pl/swiat/chiny/artykuly/9299338,zgrzyt-na-linii-niemcy-chiny-pekin-zlozyl-skarge-na-szefowa-niemiecki.html](https://forsal.pl/swiat/chiny/artykuly/9299338,zgrzyt-na-linii-niemcy-chiny-pekin-zlozyl-skarge-na-szefowa-niemiecki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T13:48:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/gHhktkuTURBXy80YmQ4Nzg5NS01ZjVlLTRmNWQtOTgyOS1jMTQ1NGI5ZjNiM2IuanBlZ5GTBc0BHcyg" />Określenie przywódcy ChRL Xi Jinpinga &quot;dyktatorem&quot; przez niemiecką minister spraw zagranicznych Annalenę Baerbock było &quot;skrajnie absurdalne&quot; – oświadczyła w poniedziałek rzeczniczka chińskiego MSZ Mao Ning w reakcji na słowa, które padły w trakcie wywiadu, udzielonego amerykańskiej telewizji w ubiegłym tygodniu.

## Polacy wskazali, jaki jest główny problem kraju
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9299330,polacy-wskazali-jaki-jest-glowny-problem-kraju.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9299330,polacy-wskazali-jaki-jest-glowny-problem-kraju.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T13:42:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kNwktkuTURBXy84MjliMzQwYS03ZDI3LTQzZTAtYjJhYS1hMjEwYmE3N2M3NmMuanBlZ5GTBc0BHcyg" />undefined

## Kto wygra wybory? Oto nowy sondaż wyborczy
 - [https://forsal.pl/gospodarka/polityka/artykuly/9299286,kto-wygra-wybory-oto-nowy-sondaz-wyborczy.html](https://forsal.pl/gospodarka/polityka/artykuly/9299286,kto-wygra-wybory-oto-nowy-sondaz-wyborczy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T13:04:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2ToktkuTURBXy84NGQ1YzQ4Zi1kMDg0LTQ0ZDUtOTVhZi1lMTg3OTEyZmJhYTYuanBlZ5GTBc0BHcyg" />PiS mogłoby liczyć na 32,6 proc. głosów; KO - na 26, 6 proc., Trzecia Droga na 10, 6 proc., a Lewica na 9,9 proc. - wynika z opublikowanego w poniedziałek sondażu IBRiS dla &quot;Wydarzeń&quot; Polsatu. Do Sejmu weszłaby także Konfederacja z 9,5 proc. poparciem.

## Reparacje wojenne od Niemiec. Co o tym myślą Polacy? [SONDAŻ]
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9299282,reparacje-wojenne-od-niemiec-co-o-tym-mysla-polacy-sondaz.html](https://forsal.pl/swiat/aktualnosci/artykuly/9299282,reparacje-wojenne-od-niemiec-co-o-tym-mysla-polacy-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T12:55:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8LHktkuTURBXy83YWViNDM4Ni0wODJiLTQ4M2YtYjQ4OS02NjU3NmFmMDJkNzkuanBlZ5GTBc0BHcyg" />58 proc. respondentów uważa, że Polska powinna domagać się od Niemiec reparacji za straty poniesione podczas II wojny światowej; przeciwnego zdania jest 31 proc. badanych; 11 proc. nie ma zdania na ten temat - wynika z sondażu CBOS przesłanego PAP w poniedziałek.

## Inflacja bazowa w sierpniu wciąż dwucyfrowa. NBP podał dane
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9299241,inflacja-bazowa-w-sierpniu-wciaz-dwucyfrowa-nbp-podal-dane.html](https://forsal.pl/gospodarka/inflacja/artykuly/9299241,inflacja-bazowa-w-sierpniu-wciaz-dwucyfrowa-nbp-podal-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T12:16:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VRjktkuTURBXy9lYzZmZGJiYi1lMzkxLTQ4OWItYjc2NC1kMGUzOGRkZjUyMTcuanBlZ5GTBc0BHcyg" />W sierpniu 2023 r. inflacja bazowa po wyłączeniu cen żywności i energii wyniosła 10 proc. licząc rok do roku – poinformował w poniedziałek NBP. W sierpniu inflacja wyniosła 10,1 proc.

## W Rudzie Śląskiej powstanie nowoczesna stalownia? Sasin: "Mamy taki plan". Jaki będzie koszt?
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9299227,w-rudzie-slaskiej-powstanie-nowoczesna-stalownia-sasin-mamy-taki-pl.html](https://forsal.pl/biznes/aktualnosci/artykuly/9299227,w-rudzie-slaskiej-powstanie-nowoczesna-stalownia-sasin-mamy-taki-pl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T11:55:32+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ub9ktkuTURBXy85OGJhMWRlYS01MTA4LTQxZjUtYjI1Mi03NTczOTIyYjgxOTEuanBlZ5GTBc0BHcyg" />undefined

## Niemcy złożyły pierwszy wniosek o wypłatę środków z Funduszu Odbudowy. O jaką kwotę się ubiegają?
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9299215,niemcy-zlozyly-pierwszy-wniosek-o-wyplate-srodkow-z-funduszu-odbudowy.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9299215,niemcy-zlozyly-pierwszy-wniosek-o-wyplate-srodkow-z-funduszu-odbudowy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T11:39:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hgVktkuTURBXy9jOWY3NmJiYy0yMDcyLTQ4NGUtYjQ3MS0xYWEwNzZiOGIxZjYuanBlZ5GTBc0BHcyg" />Niemcy złożyły w Komisji Europejskiej swój pierwszy wniosek o płatność w wysokości 3,97 mld euro w postaci dotacji z Funduszu Odbudowy - poinformowała KE.

## Adam Bodnar: Potrzebujemy Rzecznika Praw Polonii
 - [https://forsal.pl/gospodarka/prawo/artykuly/9299185,adam-bodnar-potrzebujemy-rzecznika-praw-polonii.html](https://forsal.pl/gospodarka/prawo/artykuly/9299185,adam-bodnar-potrzebujemy-rzecznika-praw-polonii.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T11:05:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/_EUktkuTURBXy84ZDVhM2E5NS0wNDE2LTQyYjEtOWVmMy1mNjU5OGFmMzg4NDEuanBlZ5GTBc0BHcyg" />Na potrzebę powołania nowej instytucji - Rzecznika Praw Polonii - w strukturze Senatu RP wskazywał w poniedziałek we Wrocławiu kandydat KO do Senatu w ramach paktu senackiego, były Rzecznik Praw Obywatelskich Adam Bodnar.

## Rumuńskie nadwyżki energii elektrycznej trafią na Węgry. Bukareszt inwestuje w kabel wysokiego napięcia
 - [https://forsal.pl/biznes/energetyka/artykuly/9299179,rumunskie-nadwyzki-energii-elektrycznej-trafia-na-wegry-bukareszt-inw.html](https://forsal.pl/biznes/energetyka/artykuly/9299179,rumunskie-nadwyzki-energii-elektrycznej-trafia-na-wegry-bukareszt-inw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T10:59:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/X4kktkuTURBXy9jZGI1YTk0Ni04ZjU2LTRiNTUtOWEyOS0wNmZiMjgxODllMTEuanBlZ5GTBc0BHcyg" />Rumunia zamierza zainwestować ponad 3 mld euro w kabel wysokiego napięcia, za pomocą którego będzie mogła eksportować nadwyżki energii elektrycznej m.in. na Węgry – podała agencja Bloomberga, powołując się na informacje rumuńskiego ministerstwa energii.

## Ukraina: Dymisja sześciorga wiceministrów obrony. Wśród nich Hanna Malar
 - [https://forsal.pl/swiat/ukraina/artykuly/9299085,ukraina-dymisja-szesciorga-wiceministrow-obrony-wsrod-nich-hanna-mal.html](https://forsal.pl/swiat/ukraina/artykuly/9299085,ukraina-dymisja-szesciorga-wiceministrow-obrony-wsrod-nich-hanna-mal.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T09:25:06+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dEoktkuTURBXy81NWI5NTg4OC0wM2JhLTRiM2MtOWQ1MC01MjQyZDU0YzM1M2UuanBlZ5GTBc0BHcyg" />Ukraiński rząd poinformował w poniedziałek o zdymisjonowaniu sześciorga wiceministrów obrony. Jest wśród nich Hanna Malar, która na bieżąco podawała informacje na temat przebiegu kontrofensywy przeciwko wojskom rosyjskim.

## Francja pozwoli na sprzedaż paliwa poniżej kosztów
 - [https://forsal.pl/transport/aktualnosci/artykuly/9299079,francja-pozwoli-na-sprzedaz-paliwa-ponizej-kosztow.html](https://forsal.pl/transport/aktualnosci/artykuly/9299079,francja-pozwoli-na-sprzedaz-paliwa-ponizej-kosztow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T09:21:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/MCvktkuTURBXy9jNDY5NDc5Yy02Y2U5LTRkZGMtOTZhNy03NmVlZGVjYzAxYWQuanBlZ5GTBc0BHcyg" />We Francji sprzedaż paliwa ze stratą będzie trwała przez sześć miesięcy od początku grudnia – zapowiedział w poniedziałek minister gospodarki i finansów Bruno Le Maire w stacji France 2. Rząd przygotowuje projekt ustawy zezwalającej stacjom na sprzedaż paliwa poniżej kosztów, aby ograniczyć inflację.

## Najmniejszy niskopodłogowy tramwaj w kraju. "Ma niecałe 15 metrów"
 - [https://forsal.pl/transport/aktualnosci/artykuly/9299076,najmniejszy-niskopodlogowy-tramwaj-w-kraju-ma-niecale-15-metrow.html](https://forsal.pl/transport/aktualnosci/artykuly/9299076,najmniejszy-niskopodlogowy-tramwaj-w-kraju-ma-niecale-15-metrow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T09:18:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tGpktkuTURBXy9jODQzMmVlNi01YzZiLTQ1MzYtOWQ1ZC01MGM3MmM2NzI0MGUuanBlZ5GTBc0BHcyg" />Pierwszy w Polsce jednoczłonowy, mierzący 15 m długości, w pełni niskopodłogowy tramwaj Moderus Gamma LF 05 AC zaczął w poniedziałek kursować po trasach w Poznaniu - poinformowało Miejskie Przedsiębiorstwo Komunikacyjne.

## Ile są warte polskie mieszkania? NBP podał szacunkowe dane
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9299047,ile-sa-warte-polskie-mieszkania-nbp-podal-szacunkowe-dane.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9299047,ile-sa-warte-polskie-mieszkania-nbp-podal-szacunkowe-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T08:32:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hs4ktkuTURBXy84NzgxMWRhYi1iYTIzLTQxNzYtYjRiNy1mNGFmNzQzZTdkZjYuanBlZ5GTBc0BHcyg" />Szacowana wartość majątku nieruchomości mieszkaniowych w Polsce na koniec 2022 r. wyniosła ok. 6,5 bln zł, wobec 5,8 bln zł na koniec 2021 r. – podał Narodowy Bank Polski w opublikowanym w poniedziałek raporcie.

## Solidarność po polsku. Maciej Wąsik: Ani jednego migranta nie przyjmiemy z Lampedusy
 - [https://forsal.pl/gospodarka/polityka/artykuly/9299023,solidarnosc-po-polsku-maciej-wasik-ani-jednego-migranta-nie-przyjmie.html](https://forsal.pl/gospodarka/polityka/artykuly/9299023,solidarnosc-po-polsku-maciej-wasik-ani-jednego-migranta-nie-przyjmie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T08:09:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g_uktkuTURBXy9mZjU5NTU4NS0wYTA2LTQ4YjktYTJlYS0xMDhhZjM2Njg1MTguanBlZ5GTBc0BHcyg" />Ani jednego migranta nie przyjmiemy z Lampedusy, bo polski rząd nie akceptuje propozycji, które są składane. Europa musi zmienić swoje podejście - powiedział w Salonie Politycznym Trójki wiceszef MSWiA Maciej Wąsik.

## Czy najbogatszy Polak wykupi VeloBank? Do końca września można składać niewiążące oferty
 - [https://forsal.pl/biznes/bankowosc/artykuly/9299008,czy-najbogatszy-polak-wykupi-velobank-do-konca-wrzesnia-mozna-skladac.html](https://forsal.pl/biznes/bankowosc/artykuly/9299008,czy-najbogatszy-polak-wykupi-velobank-do-konca-wrzesnia-mozna-skladac.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T07:46:14+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YU-ktkuTURBXy84OGY0Y2ViNC1mODgxLTQwOTYtYTlkMC1mODUzYTUyY2QyNGYuanBlZ5GTBc0BHcyg" />undefined

## KI Chemistry ponownie zaprosiło do sprzedaży akcji Ciechu po 54,25 zł za szt.
 - [https://forsal.pl/finanse/gielda/artykuly/9298995,ki-chemistry-ponownie-zaprosilo-do-sprzedazy-akcji-ciechu-po-5425-zl.html](https://forsal.pl/finanse/gielda/artykuly/9298995,ki-chemistry-ponownie-zaprosilo-do-sprzedazy-akcji-ciechu-po-5425-zl.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T07:28:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/D81ktkuTURBXy8yODM3N2M1NS1jNDcxLTRmMmUtOTYwYi04YjhjMjhkOGMwMzYuanBlZ5GTBc0BHcyg" />undefined

## Newag miał 14,64 mln zł zysku netto, 27,31 mln zł zysku EBIT w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9298989,newag-mial-1464-mln-zl-zysku-netto-2731-mln-zl-zysku-ebit-w-ii-kw.html](https://forsal.pl/finanse/gielda/artykuly/9298989,newag-mial-1464-mln-zl-zysku-netto-2731-mln-zl-zysku-ebit-w-ii-kw.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T07:26:13+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zQJktkuTURBXy9kYzUyYzhjNS1lYTZiLTQ5MTAtOTVkMS02MDE2NjdkMGM1ZjQuanBlZ5GTBc0BHcyg" />undefined

## Wasko miało 12,02 mln zł straty netto, 12,42 mln zł straty EBIT w II kw. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9298984,wasko-mialo-1202-mln-zl-straty-netto-1242-mln-zl-straty-ebit-w-ii-k.html](https://forsal.pl/finanse/gielda/artykuly/9298984,wasko-mialo-1202-mln-zl-straty-netto-1242-mln-zl-straty-ebit-w-ii-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T07:22:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/fhiktkuTURBXy9kNzM5MjRmZi00MGMyLTQ2ODUtOWI3YS0wNzg5ODIwMzZiMzUuanBlZ5GTBc0BHcyg" />undefined

## Czy polscy przedsiębiorcy uwierzą w jądrowe plany rządu?
 - [https://forsal.pl/biznes/energetyka/artykuly/9298971,czy-polscy-przedsiebiorcy-uwierza-w-jadrowe-plany-rzadu.html](https://forsal.pl/biznes/energetyka/artykuly/9298971,czy-polscy-przedsiebiorcy-uwierza-w-jadrowe-plany-rzadu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T07:15:46+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/NiQktkuTURBXy83ZjYzNjIxYS04MmZmLTRiY2QtYmQ1NS00NzMwZTMzZDExMzMuanBlZ5GTBc0BHcyg" />Z jednej strony rynek potencjalnie wart setki miliardów złotych, a z drugiej dużo niewiadomych oraz wysiłek, który trzeba ponieść bez gwarancji sukcesu. Mimo tego energetyka jądrowa zaczyna budzić coraz więcej nadziei u polskich firm.

## Trzęsienie ziemi we Włoszech. INGV podaje nowe informacje
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9298945,trzesienie-ziemi-we-wloszech-ingv-podaje-nowe-informacje.html](https://forsal.pl/swiat/aktualnosci/artykuly/9298945,trzesienie-ziemi-we-wloszech-ingv-podaje-nowe-informacje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:53:40+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/sqfktkuTURBXy8zYTMyMWIzOC1kMDBmLTRmOWEtYTIyMy1jMmU5NDNlYmQ1MjUuanBlZ5GTBc0BHcyg" />Trzęsienie ziemi o magnitudzie 4,8, które w poniedziałek rano nawiedziło okolice Florencji w centralnej części Włoch, nie spowodowało poważnych zniszczeń - poinformowały władze regionu Toskania i włoski Narodowy Instytut Geofizyki i Wulkanologii (INGV).

## Kiedy decyzja w sprawie wakacji kredytowych? Soboń: W ciągu najbliższych dni
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9298942,kiedy-decyzja-w-sprawie-wakacji-kredytowych-sobon-w-ciagu-najblizszy.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9298942,kiedy-decyzja-w-sprawie-wakacji-kredytowych-sobon-w-ciagu-najblizszy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:49:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/kYuktkuTURBXy8yNWEyNzljNy00N2FmLTRhOGItYWJlMy1lYjczMjg5MmYxNTkuanBlZ5GTBc0BHcyg" />W ciągu najbliższych dni, przed wyborami, będzie ogłoszona decyzja dotycząca wakacji kredytowych - powiedział w poniedziałek w Polsat News wiceminister finansów Artur Soboń. Dodał, że nie wyklucza przedłużenia zerowej stawki VAT na żywność w przyszłym roku.

## Pierwsza w Polsce lokomotywa wodorowa. Orlen rozpoczął testy
 - [https://forsal.pl/transport/kolej/artykuly/9298938,pierwsza-w-polsce-lokomotywa-wodorowa-orlen-rozpoczal-testy.html](https://forsal.pl/transport/kolej/artykuly/9298938,pierwsza-w-polsce-lokomotywa-wodorowa-orlen-rozpoczal-testy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:43:50+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GpsktkuTURBXy8wMjljZGNkMC1jYmJkLTQzOWYtYjc3My02ODgxZTI5ZGVlZTMuanBlZ5GTBc0BHcyg" />Orlen zakupił od spółki Pesa Bydgoszcz lokomotywę, która jest pierwszym w Polsce pojazdem szynowym wykorzystującym napęd wodorowy, podała spółka.

## Ile zboża wyeksportowała do lipca Polska?
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9298933,ile-zboza-wyeksportowala-do-lipca-polska.html](https://forsal.pl/biznes/rolnictwo/artykuly/9298933,ile-zboza-wyeksportowala-do-lipca-polska.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:41:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wWoktkuTURBXy80MmY5OWVlYS02N2NkLTQ4YjAtODI4OS05YmRmZmI3MWRhM2QuanBlZ5GTBc0BHcyg" />Od stycznia ub. r. do lipca br. Polska wyeksportowała rekordową ilość zbóż - 16,8 mln ton. Tylko w pierwszych 7 miesiącach tego roku wywieziono z kraju 7,7 mln ton ziarna zbóż, o 57 proc. więcej niż przed rokiem - poinformował PAP wiceszef KOWR Marcin Wroński.

## Były szef spółki z NewConnect to oszust. Marcin P. z wyrokiem więzienia w zawieszeniu
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9298929,byly-szef-spolki-z-newconnect-to-oszust-marcin-p-z-wyrokiem-wiezieni.html](https://forsal.pl/biznes/aktualnosci/artykuly/9298929,byly-szef-spolki-z-newconnect-to-oszust-marcin-p-z-wyrokiem-wiezieni.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:36:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/qK9ktkuTURBXy8yZTU1NzFhYS01NTMzLTQ5NDctYjc4MS03NGJhNmFmYWJhYWEuanBlZ5GTBc0BHcyg" />Marcin P. usłyszał prawomocny wyrok więzienia w zawieszeniu za to, że jako prezes Agtesu oszukał dwa fundusze współfinansowane przez Krajowy Fundusz Kapitałowy - podaje w poniedziałek &quot;Puls Biznesu&quot;.

## Wyłudzali pieniądze z urzędów miast i gmin. Grupa została rozbita, ile wynoszą straty?
 - [https://forsal.pl/gospodarka/aktualnosci/artykuly/9298924,wyludzali-pieniadze-z-urzedow-miast-i-gmin-grupa-zostala-rozbita-ile.html](https://forsal.pl/gospodarka/aktualnosci/artykuly/9298924,wyludzali-pieniadze-z-urzedow-miast-i-gmin-grupa-zostala-rozbita-ile.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:31:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/1D5ktkuTURBXy9iYTYzNWQwZi1iNmU5LTQzNWYtYmVlMy1lOTljZWM3YWRiMGMuanBlZ5GTBc0BHcyg" />Policjanci CBZC rozbili grupę przestępczą zajmującą się wyłudzeniami środków pieniężnych z urzędów miast i gmin w całym kraju oraz praniem brudnych pieniędzy - poinformował podkom. Krzysztof Wrześniowski z zespołu prasowego Centralnego Biura Zwalczania Cyberprzestępczości. Dodał, że straty w wyniku działalności grupy wyniosły łącznie 11 milionów złotych.

## Ponad 100 chińskich samolotów bojowych wokół Tajwanu w ciągu 24 godzin
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9298919,ponad-100-chinskich-samolotow-bojowych-wokol-tajwanu-w-ciagu-24-godzin.html](https://forsal.pl/swiat/aktualnosci/artykuly/9298919,ponad-100-chinskich-samolotow-bojowych-wokol-tajwanu-w-ciagu-24-godzin.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:28:25+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/UckktkuTURBXy83ZDIxYTU4NS05NGUzLTQ5M2QtYWU2Yy0yNzE3ZjBjZmU3YTcuanBlZ5GTBc0BHcyg" />Ministerstwo obrony Tajwanu poinformowało, że w ciągu ostatnich 24 godzin wykryło wokół wyspy 103 chińskie samoloty bojowe, &quot;co stanowi najwyższą w ostatnim czasie liczbę&quot;.

## Kursy walut: Złoty zyskał względem euro; stracił wobec dolara i franka
 - [https://forsal.pl/finanse/waluty/artykuly/9298913,kursy-walut-zloty-zyskal-wzgledem-euro-stracil-wobec-dolara-i-franka.html](https://forsal.pl/finanse/waluty/artykuly/9298913,kursy-walut-zloty-zyskal-wzgledem-euro-stracil-wobec-dolara-i-franka.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:23:38+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6c7ktkuTURBXy81YWIyMTQ5Zi1iYjI5LTQ3NzQtYTEyMy1lMmI3ZDhjMWJjZDAuanBlZ5GTBc0BHcyg" />W poniedziałek ok. godz. 7.10 polska waluta zyskała na wartości wobec euro, a straciła względem dolara amerykańskiego i franka szwajcarskiego. Euro kosztowało blisko 4,65 zł, dolar 4,35 zł, a frank szwajcarski 4,85 zł.

## W USA mocny wzrost cen ropy naftowej. Cięcia dostaw z krajów sojuszu OPEC+ zacieśniły sytuację na rynkach paliw
 - [https://forsal.pl/biznes/aktualnosci/artykuly/9298909,w-usa-mocny-wzrost-cen-ropy-naftowej-ciecia-dostaw-z-krajow-sojuszu-o.html](https://forsal.pl/biznes/aktualnosci/artykuly/9298909,w-usa-mocny-wzrost-cen-ropy-naftowej-ciecia-dostaw-z-krajow-sojuszu-o.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:19:51+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BGUktkuTURBXy81YzFhNjU3ZC04ZTVhLTQxNTMtOTI3YS00MGE5Yjk2Yzk4M2MuanBlZ5GTBc0BHcyg" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną i są powyżej 91 USD za baryłkę. Cięcia dostaw ropy z krajów sojuszu OPEC+ zacieśniły sytuację na rynkach paliw - podają maklerzy.

## Rau: Nie czuję się współwinny sprawy wizowej
 - [https://forsal.pl/gospodarka/polityka/artykuly/9298907,rau-nie-czuje-sie-wspolwinny-sprawy-wizowej.html](https://forsal.pl/gospodarka/polityka/artykuly/9298907,rau-nie-czuje-sie-wspolwinny-sprawy-wizowej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T06:17:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yz9ktkuTURBXy8wYjdlYmUzZC0zNmU2LTQ5YzAtODMwMC0xNzEzNjU5MjAzODYuanBlZ5GTBc0BHcyg" />Nie czuję się współwinny, nie rozważam podania się do dymisji i nie ma żadnej afery wizowej - powiedział w niedzielę w Nowym Jorku szef polskiego MSZ Zbigniew Rau. Minister odniósł się też do odtajnionego przez MON dokumentu o planach obronnych. Ocenił, że gdyby koncepcja obrony na linii Wisły przetrwała, &quot;mielibyśmy na wschodniej ścianie doświadczenia takie jak Bucza&quot;.

## Recesja w USA jest wciąż realna
 - [https://forsal.pl/swiat/usa/artykuly/9298780,recesja-w-usa-jest-wciaz-realna.html](https://forsal.pl/swiat/usa/artykuly/9298780,recesja-w-usa-jest-wciaz-realna.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T05:54:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/KxMktkuTURBXy83MTYzMDA4OC02MDc3LTQ1ZTktYmQ0Ny1kODgyNjNkODAyNTEuanBlZ5GTBc0BHcyg" />Bieżące dane z amerykańskiej gospodarki wskazują nawet na przyspieszenie tempa wzrostu gospodarczego, ale w perspektywie kilku miesięcy sytuacja może się gwałtownie odwrócić.

## Co dalej z inflacją w Polsce?
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9298752,co-dalej-z-inflacja-w-polsce.html](https://forsal.pl/gospodarka/inflacja/artykuly/9298752,co-dalej-z-inflacja-w-polsce.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T05:48:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/tgXktkuTURBXy83YjNkMGQzNC03MzVlLTQ3MjctOTkxOC1jYTBmMWVlM2QxOWQuanBlZ5GTBc0BHcyg" />Do końca roku wzrost cen będzie szybko spowalniał. Ale w przyszłym roku trend się wyczerpie.

## Nowa polityka Niemiec. Zeitenwende będzie ewoluować w wielką opowieść o reformie [WYWIAD]
 - [https://forsal.pl/gospodarka/polityka/artykuly/9298776,nowa-polityka-niemiec-zeitenwende-bedzie-ewoluowac-w-wielka-opowiesc-o-reformie-wywiad.html](https://forsal.pl/gospodarka/polityka/artykuly/9298776,nowa-polityka-niemiec-zeitenwende-bedzie-ewoluowac-w-wielka-opowiesc-o-reformie-wywiad.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T05:40:21+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/h7LktkuTURBXy8xZWQ0ZWM1ZC1hMjYzLTRhNWEtYWM4ZS0yMzUwOTFjMGYzYWMuanBlZ5GTBc0BHcyg" />Zeitenwende będzie wykorzystywane do modernizowania Niemiec w różnych dziedzinach. Nie tylko w energetyce czy dyplomacji.

## Przeciąganie liny ws. ukraińskiego zboża. Polska liczy się z reperkusjami ze strony KE
 - [https://forsal.pl/biznes/rolnictwo/artykuly/9298729,przeciaganie-liny-ws-zboza-z-ukrainy-polska-liczy-sie-z-reperkusjami-ze-strony-ke.html](https://forsal.pl/biznes/rolnictwo/artykuly/9298729,przeciaganie-liny-ws-zboza-z-ukrainy-polska-liczy-sie-z-reperkusjami-ze-strony-ke.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T05:22:12+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wJtktkuTURBXy9jYTU2NGRjNC03ZDcwLTRmNmQtODJlYS1iMDgwYWE1ZDhlMzQuanBlZ5GTBc0BHcyg" />Polski rząd, przedłużając jednostronnie embargo, zareagował tak, jak zapowiadaliśmy tydzień temu. Warszawa nie składa jednak broni.

## Laptopy dla czwartoklasistów. Lepiej wziąć na własność, czy wypożyczyć?
 - [https://forsal.pl/lifestyle/edukacja/artykuly/9297395,laptopy-dla-czwartoklasistow-lepiej-wziac-na-wlasnosc-czy-wypozyczyc.html](https://forsal.pl/lifestyle/edukacja/artykuly/9297395,laptopy-dla-czwartoklasistow-lepiej-wziac-na-wlasnosc-czy-wypozyczyc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T04:32:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/m_pktkuTURBXy9lZTFlNTU0Mi05NmE0LTQxYzgtOGM1Zi1hYzMzZjA5ODkxMzAuanBlZ5GTBc0BHcyg" />W ramach inicjatywy &quot;Laptop dla ucznia&quot; do końca 2023 roku do wszystkich czwartoklasistów szkół podstawowych w Polsce mają dotrzeć laptopy. Jakie komputery dostają uczniowie i na co zwrócić uwagę?

## Czy da się zaoszczędzić, odłączając ładowarkę do telefonu od prądu? [LICZBY]
 - [https://forsal.pl/finanse/finanse-osobiste/artykuly/9297237,czy-da-sie-zaoszczedzic-odlaczajac-ladowarke-do-telefonu-od-pradu-l.html](https://forsal.pl/finanse/finanse-osobiste/artykuly/9297237,czy-da-sie-zaoszczedzic-odlaczajac-ladowarke-do-telefonu-od-pradu-l.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/2DyktkuTURBXy85MTU4YjU1ZC0wMDFkLTQxYmQtYjY3NS03MTQ1MjAzMmI3MTcuanBlZ5GTBc0BHcyg" />Rosnące koszty życia dają się Polakom we znaki. W sytuacji kryzysu gospodarczego wiele osób szuka sposobów na nawet najdrobniejsze oszczędności. Powszechnie wiemy, że podłączona do gniazdka ładowarka do telefonu, nawet, jeśli aktualnie z niej nie korzystamy, „pożera” prąd. Jak duży sens ma dbanie o to, żeby za każdym razem pamiętać o odpięciu jej z gniazdka?

## Śledztwo KE ws. chińskiego rynku aut elektrycznych. Tę wojnę z Pekinem trudno będzie wygrać
 - [https://forsal.pl/motoforsal/artykuly/9298003,sledztwo-ke-ws-chinskiego-rynku-aut-elektrycznych-te-wojne-z-pekinem.html](https://forsal.pl/motoforsal/artykuly/9298003,sledztwo-ke-ws-chinskiego-rynku-aut-elektrycznych-te-wojne-z-pekinem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-18T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wemktkuTURBXy81MjFhNDdlYy1jZTRkLTQ4NWYtYjI1OS03MDQyYzI3YWRiOWIuanBlZ5GTBc0BHcyg" />Komisja Europejska wszczyna śledztwo związane z dotacjami chińskiego państwa na rzecz tamtejszego rynku aut elektrycznych. Będzie miała ciężki orzech do zgryzienia. Udowodnienie, że chińscy producenci dostają wsparcie od państwa, nie będzie łatwe. Podczas gdy europejscy producenci podnoszą ceny aut elektrycznych – chińskie firmy nie muszą tego robić. Nie mają też problemów z dostępnością do części i komponentów.

