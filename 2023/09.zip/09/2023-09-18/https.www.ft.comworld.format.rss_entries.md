# Source:Financial Times World, URL:https://www.ft.com/world?format=rss, language:en-US

## Clorox warns recent hack will have ‘material’ impact on results
 - [https://www.ft.com/content/3d5f148a-bc64-4a88-b592-5d67f67ad57e](https://www.ft.com/content/3d5f148a-bc64-4a88-b592-5d67f67ad57e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T22:28:20+00:00



## Trudeau says India may have been involved in murder of Sikh leader
 - [https://www.ft.com/content/eca1a914-33a0-498e-955f-09f1b2fe887c](https://www.ft.com/content/eca1a914-33a0-498e-955f-09f1b2fe887c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T22:13:17+00:00

Top Indian diplomat also expelled as Canada investigates possible role in fatal shooting

## FirstFT: US and Iran complete prisoner exchange in diplomatic breakthrough
 - [https://www.ft.com/content/6b139e32-ca08-4a54-bacc-4f1f7d253a24](https://www.ft.com/content/6b139e32-ca08-4a54-bacc-4f1f7d253a24)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T21:40:44+00:00

Also in today’s newsletter, China lifts temporary curbs on gold imports and the BIS warns over hedge fund bets

## SoftBank leads Mapbox fundraising as it pushes ahead on AI empire
 - [https://www.ft.com/content/ba8b07ee-5aaa-4b07-b4e0-aefbc648e281](https://www.ft.com/content/ba8b07ee-5aaa-4b07-b4e0-aefbc648e281)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T21:00:26+00:00

Son’s decision to back US mapping company in $280mn investment round comes in wake of Arm listing

## US unveils Atlantic co-operation pact
 - [https://www.ft.com/content/56706df4-f39b-4ab5-8acf-b252176d172d](https://www.ft.com/content/56706df4-f39b-4ab5-8acf-b252176d172d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T20:50:26+00:00

Partnership does not include security but comes as Washington tries to counter Chinese influence

## UK regulator finds no evidence of politicians being ‘debanked’ over  views
 - [https://www.ft.com/content/2e5481ab-808f-4c87-b52a-9424e5e9d48a](https://www.ft.com/content/2e5481ab-808f-4c87-b52a-9424e5e9d48a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T20:00:26+00:00

Financial Conduct Authority preparing to release report commissioned after Nigel Farage row

## UK offers wrongfully convicted Post Office workers £600,000 each
 - [https://www.ft.com/content/9e3e5da5-1bf4-4a6c-8753-da23def2d372](https://www.ft.com/content/9e3e5da5-1bf4-4a6c-8753-da23def2d372)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T18:20:25+00:00

Move comes as officials seek to draw partial line under long-running Horizon IT scandal

## Starmer heads to Paris for Macron talks to set out post-Brexit stall
 - [https://www.ft.com/content/b51f9fe0-4cad-45ee-aab5-1d58bd2262f6](https://www.ft.com/content/b51f9fe0-4cad-45ee-aab5-1d58bd2262f6)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T18:13:08+00:00

UK’s opposition leader pledges to repair relations with EU leaders but may find they have other priorities

## Tory MPs warn UK government against killing off northern leg of HS2
 - [https://www.ft.com/content/afb86286-aa97-4238-9169-3f2a251c4a4c](https://www.ft.com/content/afb86286-aa97-4238-9169-3f2a251c4a4c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T17:58:06+00:00

Ministers also consider option of cancelling final stretch of high-speed line into central London to cut spiralling costs

## Liz Truss makes defiant return to political fray
 - [https://www.ft.com/content/4119cd34-e0f6-4312-8788-a55e4564f54b](https://www.ft.com/content/4119cd34-e0f6-4312-8788-a55e4564f54b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T17:51:59+00:00

UK’s shortest-serving PM unbowed in speech despite disastrous legacy and attacks from within own party

## Assertive US unions pose a challenge for Joe Biden
 - [https://www.ft.com/content/9f9fe276-5c5b-4449-bc9c-1231ebf5745c](https://www.ft.com/content/9f9fe276-5c5b-4449-bc9c-1231ebf5745c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T17:25:54+00:00

Auto workers’ strike carries risks for the White House, and for labour leaders

## Ukraine war and the west’s relations with China reshape global trade
 - [https://www.ft.com/content/6690df3b-f515-4955-8583-317f14a6ef14](https://www.ft.com/content/6690df3b-f515-4955-8583-317f14a6ef14)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T17:15:26+00:00

Also in this newsletter: hedge fund warning, California sues Big Oil, Biden takes on US drugs industry

## Saudi Arabia’s energy minister says oil cuts not about ‘jacking up prices’
 - [https://www.ft.com/content/01208985-a79e-4837-b148-ef5f09afb99b](https://www.ft.com/content/01208985-a79e-4837-b148-ef5f09afb99b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T17:01:17+00:00

Prince Abdulaziz bin Salman defends lower output as crude nears $95 a barrel

## UK to appoint commissioners to run Birmingham city council
 - [https://www.ft.com/content/ce93b38d-7984-4d0f-af73-0ba9f5eae7a7](https://www.ft.com/content/ce93b38d-7984-4d0f-af73-0ba9f5eae7a7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T16:58:59+00:00

Michael Gove set to announce technical consultation period after local authority declared itself in effect bankrupt

## Israel files complaint after German ambassador attends judicial overhaul hearing
 - [https://www.ft.com/content/56186172-717b-4259-bec9-dd7211cb7943](https://www.ft.com/content/56186172-717b-4259-bec9-dd7211cb7943)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T16:50:58+00:00

Netanyahu’s government considers diplomat’s presence in Israeli court an ‘interference’ in its domestic affairs

## German companies must cut exposure to China, warns Bundesbank
 - [https://www.ft.com/content/4b7ad09a-b05c-4651-b6ff-43a448a9bd76](https://www.ft.com/content/4b7ad09a-b05c-4651-b6ff-43a448a9bd76)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T16:02:01+00:00

Central bank says operations susceptible to trade disruption as foreign minister backs Brussels’ electric vehicle probe

## Cult Shop: Bloomsbury’s connoisseurs of colour
 - [https://www.ft.com/content/0d4a2a73-e39f-42c9-9cf4-15b4c686b1b3](https://www.ft.com/content/0d4a2a73-e39f-42c9-9cf4-15b4c686b1b3)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T16:00:26+00:00

L Cornelissen & Son has been supplying artists and printmakers hues since 1855

## Autocracy not reform remains Erdoğan’s recipe for Turkey
 - [https://www.ft.com/content/254dd275-666e-43f7-8fa0-181b0b2fd4b5](https://www.ft.com/content/254dd275-666e-43f7-8fa0-181b0b2fd4b5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T15:03:30+00:00

As the 100th anniversary of the republic approaches, the west should take care not to assist in the burial of democracy

## Tactics are shifting in the war on drugs
 - [https://www.ft.com/content/2dd8dfc0-64e2-4240-9126-0368c893a9e7](https://www.ft.com/content/2dd8dfc0-64e2-4240-9126-0368c893a9e7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T14:22:14+00:00

Experimentation continues on measures to tackle addiction and fatal overdoses

## Fernando Haddad: Brazil’s plans to transform our green economy
 - [https://www.ft.com/content/fda15a48-b6ab-44fe-9bc0-1127feedaa80](https://www.ft.com/content/fda15a48-b6ab-44fe-9bc0-1127feedaa80)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T13:32:42+00:00

Despite the challenges, we see our ecological transformation proposal as an opportunity for Brazilians

## Germany leads EU condemnation of Ukraine trade curbs
 - [https://www.ft.com/content/95065470-287c-47f5-aa57-3b6b93e6966c](https://www.ft.com/content/95065470-287c-47f5-aa57-3b6b93e6966c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T13:10:03+00:00

Berlin accuses Poland, Hungary and Slovakia of ‘part-time solidarity’ with Kyiv over grain import bans

## Cristiano Ronaldo flies in to offer Iranians rare glimpse of elite football
 - [https://www.ft.com/content/4c246108-568f-4749-90a4-a6e447827007](https://www.ft.com/content/4c246108-568f-4749-90a4-a6e447827007)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:45:02+00:00

Visit by the decorated player, whose Saudi team play in Tehran, provides country’s fans with a moment to celebrate

## SoftBank/OpenAI: next bet on AI unlikely to be more successful than the last
 - [https://www.ft.com/content/d5d488dc-6b40-4b7a-b5d4-ccf7880798c7](https://www.ft.com/content/d5d488dc-6b40-4b7a-b5d4-ccf7880798c7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:34:02+00:00

Chief’s key portfolio returns have been heavily reliant on consumer internet companies, not artificial intelligence

## GB News found in breach of impartiality rules
 - [https://www.ft.com/content/a320b0c0-4e93-454e-9de0-d82b43a780ea](https://www.ft.com/content/a320b0c0-4e93-454e-9de0-d82b43a780ea)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:31:51+00:00

TV network’s interview with chancellor Jeremy Hunt by two Tory MPs broke broadcasting code, says Ofcom

## UK car industry calls for tax incentives to help switch to EVs
 - [https://www.ft.com/content/7fd5f56e-b809-4d9b-b1ad-a83e0efacb00](https://www.ft.com/content/7fd5f56e-b809-4d9b-b1ad-a83e0efacb00)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:18:35+00:00

Carmakers plea comes as they warn of weakening demand for battery models from private buyers

## German banker with links to Scholz charged in €280mn tax fraud
 - [https://www.ft.com/content/834f26ea-aeac-47e6-883c-ed1ff39298a9](https://www.ft.com/content/834f26ea-aeac-47e6-883c-ed1ff39298a9)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:13:25+00:00

Co-owner of private bank MM Warburg is on trial for his part in the cum-ex dividend scandal

## Number of people aged 100 in England and Wales hits record high
 - [https://www.ft.com/content/9ca63bbe-531c-440a-a654-688db2f77187](https://www.ft.com/content/9ca63bbe-531c-440a-a654-688db2f77187)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T12:03:21+00:00

ONS analysis finds 11,288 female and 2,636 male centenarians on back of reduced mortality

## The lawless free-for-all of greening world trade
 - [https://www.ft.com/content/140e2bba-4bc6-481d-8504-19685e8ecd52](https://www.ft.com/content/140e2bba-4bc6-481d-8504-19685e8ecd52)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T11:31:25+00:00

The WTO has little role in regulating environmental subsidies and regulations

## The real reasons for the west’s protectionism
 - [https://www.ft.com/content/0f37f540-b87b-4e95-9249-162d3fd54a1b](https://www.ft.com/content/0f37f540-b87b-4e95-9249-162d3fd54a1b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T10:50:43+00:00

The US and EU believe that it is not just their economies but their social and political stability that are at stake

## And the winner is . . .
 - [https://www.ft.com/content/2d3d0b04-e013-496c-9cac-cc348d14067a](https://www.ft.com/content/2d3d0b04-e013-496c-9cac-cc348d14067a)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T10:47:52+00:00

Drumroll

## China lifts temporary curbs on gold imports as renminbi recovers
 - [https://www.ft.com/content/b8406698-b98f-444b-b1a7-03c29f6f5779](https://www.ft.com/content/b8406698-b98f-444b-b1a7-03c29f6f5779)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T10:26:02+00:00

Spread between Shanghai spot price and London hit record $121 per troy ounce last week

## A first taste at The Cocochine – the restaurant rewriting Mayfair dining rules
 - [https://www.ft.com/content/e5cbc6aa-801a-4eaf-ad76-de77f0ab97a7](https://www.ft.com/content/e5cbc6aa-801a-4eaf-ad76-de77f0ab97a7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T10:00:26+00:00

What happens when you combine one of the world’s most powerful gallerists with one of its greatest chefs?

## Power dining: the restaurants where deals are made in Milan
 - [https://www.ft.com/content/badd3a48-e9c5-45d6-8655-c3a1d83772b5](https://www.ft.com/content/badd3a48-e9c5-45d6-8655-c3a1d83772b5)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T10:00:26+00:00

The lowdown on the top tables in the Italian finance and fashion capital

## Milan with the FT
 - [https://www.ft.com/globetrotter/milan](https://www.ft.com/globetrotter/milan)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T09:18:48+00:00

Explore • Eat and Drink • Exercise • Experience • Enlighten

## Lessons from a century of inflation shocks
 - [https://www.ft.com/content/a8b0e874-9454-45db-a0d4-ee94fab320fa](https://www.ft.com/content/a8b0e874-9454-45db-a0d4-ee94fab320fa)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T09:02:38+00:00

News you can use from the IMF

## Labour’s fudging on HS2 tells us a lot about its election priorities
 - [https://www.ft.com/content/4d85068e-646d-43cf-8831-8aa6d1382614](https://www.ft.com/content/4d85068e-646d-43cf-8831-8aa6d1382614)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T08:30:16+00:00

Starmer’s time as leader of the opposition offers the template he wants to follow in securing a mandate

## UK insurer Phoenix hails boost to retirement sector from high inflation
 - [https://www.ft.com/content/42372610-51e5-480e-90de-824411f5621e](https://www.ft.com/content/42372610-51e5-480e-90de-824411f5621e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T08:26:47+00:00

Chief executive says UK economic environment is ‘accelerating our growth’

## US and Iran to complete prisoner swap deal after months of talks
 - [https://www.ft.com/content/ed47bab4-f154-46e9-9ed8-9880dbcb9abb](https://www.ft.com/content/ed47bab4-f154-46e9-9ed8-9880dbcb9abb)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T08:15:09+00:00

Release of detainees has potential to de-escalate tensions between arch-foes

## Three US growth ‘potholes’
 - [https://www.ft.com/content/9eb41321-9d3b-4765-87b8-b4dc1774b60b](https://www.ft.com/content/9eb41321-9d3b-4765-87b8-b4dc1774b60b)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T06:03:18+00:00

But don’t blame the auto workers

## Buybacks’ moment of truth
 - [https://www.ft.com/content/56695b96-edde-4117-83fd-a441e7aa7ee1](https://www.ft.com/content/56695b96-edde-4117-83fd-a441e7aa7ee1)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T05:30:15+00:00

And waiting on wage growth

## The holy quest to agree on the EU’s new fiscal rules
 - [https://www.ft.com/content/338682f5-9b38-469b-9fff-ccc966f8f021](https://www.ft.com/content/338682f5-9b38-469b-9fff-ccc966f8f021)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T05:00:15+00:00

Also in this newsletter: an audacious criminal heist shakes Montenegro

## A historic autoworkers strike
 - [https://www.ft.com/content/95415712-68b7-43a2-9951-19324fe16e37](https://www.ft.com/content/95415712-68b7-43a2-9951-19324fe16e37)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:37+00:00

Instacart raises IPO price range after success of Arm listing

## Bank of England refines its new competitiveness mandate
 - [https://www.ft.com/content/d618e1b5-85bd-4313-a4a0-8c350ed6c36d](https://www.ft.com/content/d618e1b5-85bd-4313-a4a0-8c350ed6c36d)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Staffers provide clues on how the central bank is interpreting the goals set by UK government

## Billions of dollars in western profits trapped in Russia
 - [https://www.ft.com/content/fb0ab6e1-ab45-438e-b9a1-1bc352645647](https://www.ft.com/content/fb0ab6e1-ab45-438e-b9a1-1bc352645647)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Businesses from ‘unfriendly’ countries have amassed more than $18bn in earnings since the start of the invasion of Ukraine

## Brazil counts success with Pix payments tool
 - [https://www.ft.com/content/e1c7b0e7-4c17-40c4-8e03-16c698674efa](https://www.ft.com/content/e1c7b0e7-4c17-40c4-8e03-16c698674efa)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

State-backed instant transfer service is credited with helping to widen financial inclusion

## Germany pushes to exempt SMEs from green reporting rules
 - [https://www.ft.com/content/4c533c07-a5ae-402d-8c1d-80c2ea416970](https://www.ft.com/content/4c533c07-a5ae-402d-8c1d-80c2ea416970)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Berlin seeks to shield some of its smaller companies from EU sustainability obligations

## Higher interest rates signal end of one-stop shop banks
 - [https://www.ft.com/content/1ad35d7d-041a-464c-adb5-cf19fe60a2c8](https://www.ft.com/content/1ad35d7d-041a-464c-adb5-cf19fe60a2c8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Big lenders are starting to retreat, and in some cases exit, from consumer banking, as income becomes squeezed

## India points the way to digital access across Africa
 - [https://www.ft.com/content/3c1504ef-96f7-4656-a5cf-d474123dc31e](https://www.ft.com/content/3c1504ef-96f7-4656-a5cf-d474123dc31e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Bill Gates is among the supporters who say DPI is key to reducing poverty but critics warn civil liberties could be at risk

## Making the banking industry more inclusive for all
 - [https://www.ft.com/content/7d69da99-d4f6-4956-bd89-bcfc741a02a2](https://www.ft.com/content/7d69da99-d4f6-4956-bd89-bcfc741a02a2)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Organisations thrive in a culture where everyone feels welcome and respected, regardless of their background

## Meloni’s budget to test rocky relations with investors
 - [https://www.ft.com/content/85e282de-c0b2-40b2-abf7-da875b862810](https://www.ft.com/content/85e282de-c0b2-40b2-abf7-da875b862810)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Sharp economic slowdown increases concerns about rightwing government’s policy stance after bank tax disaster

## NHS managers need better regulation, not just more of it
 - [https://www.ft.com/content/e56f6eff-ef47-4eb4-8f17-b48b5ff3e4c8](https://www.ft.com/content/e56f6eff-ef47-4eb4-8f17-b48b5ff3e4c8)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Letby case has prompted calls for increased safeguards in UK health service — they must encourage greater transparency

## NatWest to examine Irish unit over small business loans
 - [https://www.ft.com/content/fe69e324-4118-4e86-bf6d-181bda0e1cb7](https://www.ft.com/content/fe69e324-4118-4e86-bf6d-181bda0e1cb7)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

UK bank tells regulator of ‘remediation’ plans to explore Ulster Bank customers’ allegations

## Sicily, the 49th state of America?
 - [https://www.ft.com/content/19da4854-1f57-4ff0-8e07-08b0a5b3345c](https://www.ft.com/content/19da4854-1f57-4ff0-8e07-08b0a5b3345c)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

In 1947, revolutionary Salvatore Giuliano petitioned the US to incorporate the island. He lost out to Alaska. A new photography project imagines what might have been

## The stakes of the US autoworker strike could not be higher
 - [https://www.ft.com/content/bda59c3b-3038-450d-a0e1-46cd2654a555](https://www.ft.com/content/bda59c3b-3038-450d-a0e1-46cd2654a555)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

If Joe Biden can’t bridge the gap between management and labour, Donald Trump could be the winner

## ‘Brothers to the rescue’: Libyans join search for flood survivors
 - [https://www.ft.com/content/85233cf2-9bf0-42a7-abfa-ae8366a53c0e](https://www.ft.com/content/85233cf2-9bf0-42a7-abfa-ae8366a53c0e)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:17+00:00

Rescuers continue their search in devastated city of Derna a week after Storm Daniel

## Coming soon: Can AI help us speak to animals?
 - [https://www.ft.com/content/f4029136-803b-4fc7-a70b-9cfcd2738944](https://www.ft.com/content/f4029136-803b-4fc7-a70b-9cfcd2738944)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T04:00:08+00:00

Subscribe now to the FT's Tech Tonic podcast: Some scientists believe that rapid adv…

## Bank of England expected to raise interest rates to 5.5%
 - [https://www.ft.com/content/9945bdcc-1f0d-4ebd-a1eb-aa524958c359](https://www.ft.com/content/9945bdcc-1f0d-4ebd-a1eb-aa524958c359)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T03:00:10+00:00

Markets and economists anticipate the 15th increase in this cycle by the central bank to be the last

## Keir Starmer steps on to global stage with promise of ‘progressive moment’
 - [https://www.ft.com/content/d46c1e73-b423-4ddf-8652-7b2d5b423607](https://www.ft.com/content/d46c1e73-b423-4ddf-8652-7b2d5b423607)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T03:00:10+00:00

25 years after Blair and Clinton proclaimed the ‘Third Way’, Labour leader joined centre-left counterparts at Canada summit

## Nippon Paint targets China expansion despite property market slowdown
 - [https://www.ft.com/content/9574bb90-13c2-465e-a89f-a9c4a493176f](https://www.ft.com/content/9574bb90-13c2-465e-a89f-a9c4a493176f)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T00:41:46+00:00

Co-president predicts company can make ‘good money’ even as developers wrestle with turmoil

## China’s property revival plan threatened by stand-off over old neighbourhoods
 - [https://www.ft.com/content/73b5ff78-83b0-49ee-8177-c8cfb9360d89](https://www.ft.com/content/73b5ff78-83b0-49ee-8177-c8cfb9360d89)
 - RSS feed: https://www.ft.com/world?format=rss
 - date published: 2023-09-18T00:35:07+00:00

Beijing turns to past playbook of redeveloping poorer areas in hopes of revitalising troubled sector

