# Source:Engadget, URL:https://www.engadget.com/rss.xml, language:en-US

## MS Paint just got two killer features for a '90s graphics editor
 - [https://www.engadget.com/ms-paint-just-got-two-killer-features-for-a-90s-graphics-editor-202341195.html?src=rss](https://www.engadget.com/ms-paint-just-got-two-killer-features-for-a-90s-graphics-editor-202341195.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T20:23:41+00:00

<p>After 38 years, Microsoft is updating its Paint App with support for image transparency and layers. For most of us, <a class="no-affiliate-link" href="https://www.engadget.com/2016-10-26-microsoft-paint-3d.html"><ins>MS Paint</ins></a> brings waves of nostalgia and memories of spending hours trying to be Picasso. Back then, you had a pencil, brushes, a handful of colors and not much else. Now, it seems Microsoft is beefing up its app to make it more useful for slightly more advanced image editing. In a <a class="no-affiliate-link" href="https://blogs.windows.com/windows-insider/2023/09/18/paint-app-update-adding-support-for-layers-and-transparency-begins-rolling-out-to-windows-insiders/"><ins>blog post</ins></a>, Dave Grochocki, Principal Product Manager for Windows Inbox Apps, announced the new features and "exciting" new possibilities.</p><p>"When you combine layers, transparency, and other tools in Paint, you can create exciting new images and artwork! For example, when combine

## Stanford’s upgraded X-ray laser is up and running
 - [https://www.engadget.com/stanfords-upgraded-x-ray-laser-is-up-and-running-192326869.html?src=rss](https://www.engadget.com/stanfords-upgraded-x-ray-laser-is-up-and-running-192326869.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T19:23:26+00:00

<p>The newly <a href="https://www.engadget.com/slacs-newest-laser-accelerator-is-colder-than-space-200010659.html">upgraded particle accelerator</a> at the DoE’s Stanford Linear Accelerator Center (SLAC) has <a class="no-affiliate-link" href="https://www6.slac.stanford.edu/news/2023-09-18-slac-fires-worlds-most-powerful-x-ray-laser-lcls-ii-ushers-new-era-science">produced</a> its first X-rays. The Linac Coherent Light Source (LCLS) upgrade, LCLS-II, can emit up to a million X-ray pulses per second (8,000 times more than the original) and an almost continuous beam 10,000 times brighter than its predecessor. Researchers believe it will enable unprecedented research into “atomic-scale, ultrafast phenomena” and shed new light on quantum computing, communications, clean energy and medicine.</p><p>One of the keys to the accelerator’s powerful upgrade is its cooling abilities. The original LCLS, which went online in 2009, was capped at 120 pulses per second because of the natural limits of 

## Agility Robotics is building its first bipedal robot factory in Oregon
 - [https://www.engadget.com/agility-robotics-is-building-its-first-bipedal-robot-factory-in-oregon-184436386.html?src=rss](https://www.engadget.com/agility-robotics-is-building-its-first-bipedal-robot-factory-in-oregon-184436386.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T18:44:36+00:00

<p>Agility Robotics, the creator of the <a href="https://www.engadget.com/the-next-gen-digits-robot-gets-a-head-and-hands-120001329.html"><ins>bipedal robot Digit</ins></a>, is opening a <a href="https://agilityrobotics.com/news/2023/opening-robofab-worlds-first-factory-for-humanoid-robotsnbsp"><ins>manufacturing plant</ins></a> in Salem, Oregon that will give the company the capacity to produce more than 10,000 humanoid robots a year. The 70,000 square foot factory coined “RoboFab” is set to open later this year and will employ upwards of 500 workers in Salem.</p><p>Agility Robotics says its facility will also employ its very own Digits, the iconic humanoid robot, in the new factory. The Digits will help move, load and unload warehouse goods.</p><span id="end-legacy-contents"></span><div id="35bc4627e938408d87bd65b4cfa59f5b"></div><p>The company says some customers can expect delivery of the first Digits in 2024, with general market availability in 2025. In a statement, Damion Shelt

## Panos Panay is reportedly heading to Amazon after leaving Microsoft
 - [https://www.engadget.com/panos-panay-is-reportedly-heading-to-amazon-after-leaving-microsoft-175017471.html?src=rss](https://www.engadget.com/panos-panay-is-reportedly-heading-to-amazon-after-leaving-microsoft-175017471.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T17:50:17+00:00

<p>It didn’t take long to learn Panos Panay’s new home. The industry veteran, instrumental in developing <a href="https://www.engadget.com/windows-11-review-microsoft-mindful-os-200028040.html">Windows 11</a> and the <a href="https://www.engadget.com/surface-laptop-5-13-inch-review-specs-price-a-beautiful-design-thats-almost-run-its-course-153049819.html">Microsoft Surface</a> line of 2-in-1s and laptops, has reportedly been hired by Amazon, <a href="https://www.bloomberg.com/news/articles/2023-09-18/amazon-is-poised-to-hire-departing-microsoft-product-chief">according to</a><em>Bloomberg</em>. Microsoft’s former chief product officer will lead Amazon’s division responsible for Alexa and Echo smart devices.</p><p>Panay will replace Dave Limp, the Amazon executive previously in charge of Alexa and Echo, who <a href="https://www.engadget.com/amazon-hardware-vp-dave-limp-set-to-retire-after-almost-14-years-182315587.html">announced his retirement</a> last month. Panay’s move from one Se

## watchOS 10 has arrived, bringing widgets back to the Apple Watch
 - [https://www.engadget.com/watchos-10-has-arrived-bringing-widgets-back-to-the-apple-watch-171753537.html?src=rss](https://www.engadget.com/watchos-10-has-arrived-bringing-widgets-back-to-the-apple-watch-171753537.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T17:17:53+00:00

<p>It's a big day for Apple users as the company is rolling out major operating system updates for most of its devices (Mac users need to wait a bit longer). Just ahead of the <a href="https://www.engadget.com/apple-watch-ultra-2-and-series-9-first-impressions-double-tap-is-accurate-and-tricky-203116431.html">Apple Watch Series 9 and Apple Watch Ultra 2</a> arriving later this week, the company has <a href="https://www.engadget.com/watchos-10-brings-widgets-to-your-apple-watch-on-september-18-173827349.html">released watchOS 10</a>. If you have an Apple Watch Series 4 or above, you can install it now.</p><p>The <a href="https://www.engadget.com/the-apple-watch-embraces-widgets-again-in-watchos-10-180838970.html">biggest change</a> is the introduction of widgets (which are a bit like Glances from Apple's original wearable) for every watch face, which include two new ones. You'll be able to use the Digital Crown to cycle through your widgets and see access features like timers, stopwat

## iPadOS 17 is ready to download
 - [https://www.engadget.com/ipados-17-is-ready-to-download-171507612.html?src=rss](https://www.engadget.com/ipados-17-is-ready-to-download-171507612.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T17:15:07+00:00

<p>iPadOS 17 is available now. The annual update lacks a single headline-grabbing feature, but the sum of its smaller changes enhances the experience of using Apple’s tablet. Changes include Stage Manager refinements, along with Lock Screen additions and interactive widgets to match the <a href="https://www.engadget.com/apple-ios-16-review-lock-screen-130013300.html">iPhone’s new features from a year ago</a>.</p><p>You can install iPadOS 17 on recent models. It supports the iPad Pro 12.9 (2nd-gen or later), iPad Pro 10.5, iPad Pro 11 (1st-gen or later), iPad Air (3rd gen or later), standard iPad (6th gen or later) and iPad mini (5th gen or later). If you don’t know which device you have, you can navigate to Settings &gt; General &gt; About &gt; Model Name to determine which one it is.</p><span id="end-legacy-contents"></span><p>Once you know your device is eligible, you can head to <strong>Settings &gt; General &gt; About &gt; Software Update</strong> to manually initiate the downloa

## iOS 17 is now available
 - [https://www.engadget.com/ios-17-is-now-available-171458248.html?src=rss](https://www.engadget.com/ios-17-is-now-available-171458248.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T17:14:58+00:00

<p>iOS 17 is here. Apple has made the annual update available to all users on eligible devices, meaning you can install it right now without bothering with <a href="https://www.engadget.com/apples-ios-17-ipad-os-17-and-watchos-10-public-betas-are-ready-to-download-172130524.html">beta programs</a>. The 2023 iPhone software update includes significant updates to Messages, FaceTime, the keyboard and more.</p><p>You can install iOS 17 on any iPhone from 2018 or later. Once you know your device is eligible, you can head to <strong>Settings &gt; General &gt; About &gt; Software Update</strong> to manually initiate the download and installation.</p><span id="end-legacy-contents"></span><p>This year’s iOS upgrade includes audio message transcriptions and a rethinking of the Messages app. (iMessage apps and other tools now live behind a plus button next to the text entry field.) FaceTime adds video voicemails, and you can even take calls on an Apple TV, using an iPhone or iPad as the camera.

## How social engineering takes advantage of your kindness
 - [https://www.engadget.com/how-social-engineering-takes-advantage-of-your-kindness-170043531.html?src=rss](https://www.engadget.com/how-social-engineering-takes-advantage-of-your-kindness-170043531.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T17:00:43+00:00

<p>Last week, <a href="https://www.engadget.com/mgm-resorts-hit-by-cybersecurity-issue-leading-to-massive-outage-215205561.html"><ins>MGM Resorts disclosed a massive systems issue</ins></a> that reportedly rendered slot machines, room keys and other critical devices inoperable. What elaborate methods were required to crack a nearly $34 billion casino and hotel empire? According to the hackers themselves (and seemingly confirmed by a source <a href="https://www.bloomberg.com/news/articles/2023-09-16/mgm-resorts-hackers-broke-in-after-tricking-it-service-desk"><ins>speaking with Bloomberg</ins></a>), all it took was a <a href="https://www.engadget.com/hackers-claim-it-only-took-a-10-minute-phone-call-to-shutdown-mgm-resorts-143147493.html"><ins>ten minute phone call</ins></a>.</p><p>The alleged hackers behind the MGM issue, by all appearances, gained access through one of the most ubiquitous and low-tech vectors: a social engineering attack. Social engineering psychologically manipulat

## GE is working on AI-powered ultrasounds to combat pediatric and maternal mortality rates
 - [https://www.engadget.com/ge-is-working-on-ai-powered-ultrasounds-to-combat-pediatric-and-maternal-mortality-rates-034020572.html?src=rss](https://www.engadget.com/ge-is-working-on-ai-powered-ultrasounds-to-combat-pediatric-and-maternal-mortality-rates-034020572.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T16:23:34+00:00

<p>GE Health says it plans to develop an <a href="https://www.gehealthcare.com/about/newsroom/press-releases/ge-healthcare-awarded-a-44-million-grant-to-develop-artificial-intelligence-assisted-ultrasound-technology-aimed-at-improving-outcomes-in-low-and-middle-income-countries">AI-assisted ultrasound imaging tool</a> that is so easy to use, that even healthcare providers without specialized training will be able to operate it. The device's research and development will be funded by a $44 million grant from the Bill &amp; Melinda Gates Foundation, which has <a href="https://www.gatesfoundation.org/ideas/articles/artificial-intelligence-ai-development-principles">historically invested</a> in the roll-out of new technologies in resource-poor settings to address gaps in healthcare access.</p><p>GE says the <a href="https://www.engadget.com/mit-csail-ai-medical-diagnosis-hybrid-163423281.html">AI-powered</a> imaging technology has been designed to be dispersed to low-and-middle income co

## How a pioneering mixed-gender newsroom covered the A-bomb
 - [https://www.engadget.com/how-a-pioneering-mixed-gender-newsroom-covered-the-a-bomb-160043585.html?src=rss](https://www.engadget.com/how-a-pioneering-mixed-gender-newsroom-covered-the-a-bomb-160043585.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T16:00:43+00:00

<p>Modern tech journalism would likely look far differently today, if not for the efforts of Dorothy Vaughan, Katherine Johnson and a host of other trailblazing female reporters who staffed the <a href="https://www.si.edu/spotlight/science-service"><em>Science Service</em></a> throughout the publication's history. These journalists were among the very first science communicators, making sense of the newfangled technological wonders of the 1920s through 1950s and bringing that understanding to their readers — often in spite of the personalities and institutions they were covering.&nbsp;</p><p>In <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL1dyaXRpbmctVGhlaXItTGl2ZXMtUGlvbmVlcmluZy1Kb3VybmFsaXN0cy9kcC8wMjYyMDQ4MTY3P

## The Google Nest Hub Max will no longer support two of the biggest meeting apps
 - [https://www.engadget.com/the-google-nest-hub-max-will-no-longer-support-two-of-the-biggest-meeting-apps-154550964.html?src=rss](https://www.engadget.com/the-google-nest-hub-max-will-no-longer-support-two-of-the-biggest-meeting-apps-154550964.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T15:45:50+00:00

<p>Google is continuing its shift away from smart devices by discontinuing support for both Zoom and Google Meet on its Nest Hub Max, <a href="https://9to5google.com/2023/09/18/nest-hub-max-google-meet-zoom/"><em>9to5Google</em> reported</a>. Some users have started receiving notifications that they can no longer join meetings from the device beginning September 28. The news follows Zoom's July announcement that Nest Hub Max support will end for the video calling service on September 30 — guess Google really wanted the services gone by October.</p><p>We were fans of the Google Nest Hub Max when it first came out in 2019, giving it an <a href="https://www.engadget.com/2019-09-09-google-nest-hub-max-review.html">86 in our review</a> for features like its high-quality display and sound. It initially only offered Google Duo, but the subsequent emergence of the pandemic led to the <a href="https://www.engadget.com/zoom-amazon-google-facebook-smart-displays-140048177.html">rollout of Zoom<

## Microsoft’s Panos Panay leaves company after nearly 20 years
 - [https://www.engadget.com/microsofts-panos-panay-leaves-company-after-nearly-20-years-153513258.html?src=rss](https://www.engadget.com/microsofts-panos-panay-leaves-company-after-nearly-20-years-153513258.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T15:35:13+00:00

<p>Panos Panay is leaving Microsoft after 19 years with the company, as confirmed <a href="https://twitter.com/panos_panay/status/1703776961296998693"><ins>via an official tweet.</ins></a> He’s been operating as the chief product officer with Microsoft, heading up Windows 11 development and the company’s Surface line. Rajesh Jha, Microsoft’s vice president of experience and devices, broke the news in an email to employees, <a href="https://www.theverge.com/2023/9/18/23878609/microsoft-windows-panos-panay-leaving"><ins>as reported by </ins><em><ins>The Verge.</ins></em></a></p><p>Panay was hired on by Microsoft back in 2004 as a group program manager, overseeing a number of premium products. After heading the development of the initial Surface line of tablets and hybrid laptops, he was named the company’s chief product officer in 2018. His rise continued in 2021 when he was promoted to executive vice president after a successful Windows 11 launch, eventually becoming involved in a lea

## How to watch and follow Amazon's 2023 Devices event
 - [https://www.engadget.com/how-to-watch-and-follow-amazons-2023-devices-event-153059840.html?src=rss](https://www.engadget.com/how-to-watch-and-follow-amazons-2023-devices-event-153059840.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T15:30:59+00:00

<p>It's almost time for Amazon's <a href="https://www.engadget.com/heres-everything-amazon-announced-at-its-fall-hardware-event-195138747.html">annual fall hardware event</a>, where the company typically announces a bunch of upcoming devices, including new entries for its ereader and smart speaker lines. On September 20, the company will stage Devices at its second headquarters in Arlington, Virginia. Amazon will not be streaming it to the public, but Engadget will be there to liveblog so you can follow along and read about its new products as soon as they're announced, starting at 11AM ET.&nbsp;</p><p>Last year, one of the event's main reveals was the <a href="https://www.engadget.com/amazon-kindle-scribe-review-e-ink-reader-tablet-pen-drawing-price-battery-life-140019784.html">Kindle Scribe</a>, a 10.2-inch ereader that comes with a pen that you can use to jot down notes on its 300 ppi display. It was launched with a retail price of $340 — and it still costs that much — but it's be

## Would-be X competitor T2 Social is now called Pebble (no, not that Pebble)
 - [https://www.engadget.com/would-be-x-competitor-t2-social-is-now-called-pebble-no-not-that-pebble-150021871.html?src=rss](https://www.engadget.com/would-be-x-competitor-t2-social-is-now-called-pebble-no-not-that-pebble-150021871.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T15:00:21+00:00

<p><a href="https://www.engadget.com/elon-musk-is-rebranding-twitter-to-x-and-killing-the-bird-logo-165944573.html"><ins>Just like X (formerly Twitter),</ins></a> would-be competitor <a href="https://www.engadget.com/a-new-twitter-alternative-is-trying-to-lure-users-about-to-lose-their-old-checkmark-160011153.html"><ins>T2 Social</ins></a> has a new name, and it’s one that might ring a bell. Starting today, the service is called Pebble. And no, it's not a revival of the e-ink smartwatch company of yore.</p><p>Pebble said in an email to users that T2, which is run by former X/Twitter employees, was a placeholder name. It opted for Pebble after reviewing more than 60 options. The team plumped for that one because “a tiny stone can cause ripples across a whole pond. Just like sharing your stories and insights can create waves in our community.”</p><span id="end-legacy-contents"></span><p>It’s certainly an interesting choice. Pebble (the smartwatch) <a href="https://www.engadget.com/2012

## Anker charging gear and power banks are up to 50 percent off right now
 - [https://www.engadget.com/anker-charging-gear-and-power-banks-are-up-to-50-percent-off-right-now-140338603.html?src=rss](https://www.engadget.com/anker-charging-gear-and-power-banks-are-up-to-50-percent-off-right-now-140338603.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T14:03:38+00:00

<p>We're entering the season of long scenic drives and holiday parties, which means lots of time using your devices away from home and needing a quick recharge wherever you are. Currently, this is doable for a much lower cost, with Amazon running a <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-02904efde6ea&amp;siteId=us-engadget&amp;pageId=1p-autolink&amp;featureId=text-link&amp;merchantName=Amazon&amp;custData=eyJzb3VyY2VOYW1lIjoiV2ViLURlc2t0b3AtVmVyaXpvbiIsImxhbmRpbmdVcmwiOiJodHRwczovL3d3dy5hbWF6b24uY29tL2RlYWwvZjFkMmQ5NzM_dGFnPWdkZ3QwYy1wLW8tNG41LTIwIiwiY29udGVudFV1aWQiOiI3OThkNDZlYS0wZGFmLTQyZWQtOTBjYi05YzEyNjk2ZWMxY2IifQ&amp;signature=AQAAAdjVDFkAhyZAs1dGS2UhEyzC5q6MBc2lflicTh3IEfBD&amp;gcReferrer=https%3A%2F%2Fwww.amazon.com%2Fdeal%2Ff1d2d973">sale on Anker's power banks and fast-charging plug-ins</a>. The deals include <a class="rapid-with-clickid" href="https://shopping.yahoo.com/rdlw?merchantId=66ea567a-c987-4c2e-a2ff-

## AirPods Pro Adaptive Audio preview: Automatically adjusting to your day
 - [https://www.engadget.com/airpods-pro-adaptive-audio-preview-automatically-adjusting-to-your-day-130051605.html?src=rss](https://www.engadget.com/airpods-pro-adaptive-audio-preview-automatically-adjusting-to-your-day-130051605.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T13:00:51+00:00

<p>When Apple previews the upcoming version of iOS at WWDC, we expect to see all of the new features that will improve the iPhone. However, it’s not guaranteed that the company will take that opportunity to also update its popular wireless earbuds. But, alongside the arrival of iOS 17, a firmware update adds a few new features to the <a href="https://www.engadget.com/airpods-pro-review-second-generation-130048218.html">second-gen AirPods Pro</a>, most of which <a href="https://www.engadget.com/apples-adaptive-audio-for-airpods-tunes-anc-and-transparency-to-your-environment-181218028.html">will automatically adjust to your environment</a> or activity so you don’t have to touch the earbuds or reach for your phone.</p><p>The headline addition is Adaptive Audio, a tool that automatically and “dynamically” blends transparency mode and active noise cancellation (ANC) based on your surroundings. Apple says it will change the noise control settings continuously throughout the day, making the

## Intel seems pretty excited about glass substrates
 - [https://www.engadget.com/intel-seems-pretty-excited-about-glass-substrates-130016423.html?src=rss](https://www.engadget.com/intel-seems-pretty-excited-about-glass-substrates-130016423.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T13:00:16+00:00

<p>These days when we talk about what's next for chip design, we focus on things like cramming in more cores, increasing clock speeds,  shrinking transistors and 3D stacking. We rarely think about the package substrate, which holds and connects those components. Today Intel, in the midst of <a href="https://www.engadget.com/intel-chip-roadmap-7nm-20a-210033768.html">its reinvention as a foundry company</a>, has announced it's made a major breakthrough in substrate materials—and it's all about glass.</p><p>The company says its new glass substrate, which is set to arrive in advanced chip designs later this decade, will be stronger and more efficient than existing organic materials. Glass will also allow the company to cram more chiplets and other components next to each other, something that could lead to flexing and instability with an existing silicon package using organic materials.</p><span id="end-legacy-contents"></span><p>&quot;Glass substrates can tolerate higher temperatures, 

## Sonos Move 2 review: Better sound and battery life comes at a cost
 - [https://www.engadget.com/sonos-move-2-review-better-sound-and-battery-life-comes-at-a-cost-130015983.html?src=rss](https://www.engadget.com/sonos-move-2-review-better-sound-and-battery-life-comes-at-a-cost-130015983.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T13:00:15+00:00

<p>When Sonos <a href="https://www.engadget.com/2019-09-18-sonos-move-review.html">released its first portable speaker</a>, the Move, four years ago, it was an anomaly. Previously, the company had looked down on Bluetooth as low-quality and unreliable, and all of the speakers it sold required a power outlet. The Move, on the other hand, used Bluetooth or Wi-Fi and had a 10-hour battery.</p><p>In 2023, these tricks have proliferated across the Sonos lineup. The more affordable Roam speaker brought the Move’s feature set to a much smaller device, while recent home speakers <a href="https://www.engadget.com/sonos-era-100-review-affordable-multi-room-audio-that-actually-sounds-good-130007717.html">like the Era 100</a> and 300 both support Bluetooth, as well. As such, the recently-announced Move 2 doesn’t suggest a new direction for future Sonos products — it simply brings the company’s latest tech and design cues to an existing product.</p><span id="end-legacy-contents"></span><p>And, as

## Amazon Prime Big Deal Days: Here's what to expect this October Prime Day
 - [https://www.engadget.com/amazon-prime-big-deal-days-everything-you-need-to-know-about-october-prime-day-115842532.html?src=rss](https://www.engadget.com/amazon-prime-big-deal-days-everything-you-need-to-know-about-october-prime-day-115842532.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T11:58:42+00:00

<p><a href="https://www.engadget.com/amazon-prime-day/">Amazon Prime Day</a> came and went in July, but Amazon’s not done with its membership-only sales events for 2023. The company just <a href="https://www.engadget.com/amazon-will-hold-its-prime-big-deal-days-sale-on-october-10-and-11-105533193.html">announced</a> that it will hold “Prime Big Deal Days,” another Prime Day of sorts, on October 10 and 11, mirroring what it did during the same month last year. Engadget will be surfacing all of the best tech deals we can find during the event – both on Amazon and elsewhere – but there are some important things to know ahead of time so you can get exactly what you want out of October Prime Day.</p><h2><strong>When is Prime Big Deal Days?</strong></h2><p>Amazon’s Prime Big Deal Days will take place starting on Tuesday, October 10 and will run through the end of the day on Wednesday, October 11.</p><span id="end-legacy-contents"></span><p>Just like classic Prime Day, you’ll have to be a P

## The Morning After: Apple preps software update to address iPhone 12 radiation concerns
 - [https://www.engadget.com/the-morning-after-apple-preps-software-update-to-address-iphone-12-radiation-concerns-111610283.html?src=rss](https://www.engadget.com/the-morning-after-apple-preps-software-update-to-address-iphone-12-radiation-concerns-111610283.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T11:16:10+00:00

<p>Apple is prepping a software update for the three-year-old iPhone 12s after French regulators alleged the phone exceeds proper radiation levels. France <a href="https://www.engadget.com/apple-will-release-software-update-to-address-iphone-12-radiation-concerns-173345891.html">stopped selling the smartphone</a> after recommendations from the country’s radiation watchdog (ANFR).</p><p>The software update won’t adjust radiation levels but will “accommodate the protocol used by French regulators.” (I am not sure how that works, either.) Apple believes the software patch will be enough to allow the iPhone 12s to sail through future radiation tests, saying it looks forward “to the iPhone 12 continuing to be available in France.”</p><p>Belgium and Denmark don’t have the same worries as France. Belgian minister for digitalization, Mathieu Michel, said local tests were “reassuring” and recommended against a suspension on sales. Denmark’s Safety Authority followed suit, suggesting it had no

## Amazon will hold its Prime Big Deal Days sale on October 10 and 11
 - [https://www.engadget.com/amazon-will-hold-its-prime-big-deal-days-sale-on-october-10-and-11-105533193.html?src=rss](https://www.engadget.com/amazon-will-hold-its-prime-big-deal-days-sale-on-october-10-and-11-105533193.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T10:55:33+00:00

<p>Amazon is having a second sale this fall exclusively for Prime members as it did <a href="https://www.engadget.com/best-october-prime-day-2022-deals-amazon-devices-echo-fire-tv-kindle-eero-blink-070607645.html">last year</a>, and though we knew it was <a href="https://www.engadget.com/amazon-prime-big-deal-days-heres-what-to-expect-this-october-prime-day-190035290.html">happening in October</a>, we didn't yet have an exact date. Now, Amazon has <a href="https://www.aboutamazon.com/news/retail/amazon-prime-big-deal-days-early-deals">announced</a> that the sale will happen on October 10 and 11, and even gave it a new name: Prime Big Deal Days.&nbsp;</p><p>As ever, Prime Day gives members access to thousands of deals, so many folks wait for the sale to get the best possible deals on pricey products like laptops, phones, memory cards, cameras and more. Knowing that, Amazon uses the event as a way to boost sales and, more importantly, Prime subscriber numbers. At the same time, some se

## Unity apologizes and promises to change its controversial game install fee policy
 - [https://www.engadget.com/unity-apologizes-and-promises-to-change-its-controversial-game-install-fee-policy-082408455.html?src=rss](https://www.engadget.com/unity-apologizes-and-promises-to-change-its-controversial-game-install-fee-policy-082408455.html?src=rss)
 - RSS feed: https://www.engadget.com/rss.xml
 - date published: 2023-09-18T08:24:08+00:00

<p>Last week, Unity <a href="https://www.engadget.com/unity-will-start-charging-developers-each-time-their-game-is-installed-214851801.html">dropped a bomb</a> on developers with a new runtime fee on its game engine that would be charged each time a title is installed — summed up by one developer as an &quot;abysmally catastrophic decision.&quot; Now, the company appears to be backtracking, promising changes to the policy that will be revealed shortly.</p><p>&quot;We have heard you. We apologize for the confusion and angst the runtime fee policy we announced on Tuesday caused,&quot; the company said in a <a href="https://twitter.com/unity/status/1703547752205218265">post on X</a>. &quot;We are listening, talking to our team members, community, customers, and partners, and will be making changes to the policy. We will share an update in a couple of days. Thank you for your honest and critical feedback.&quot;</p><span id="end-legacy-contents"></span><div id="a567de9c1ae343b4b95d5b82b4d

