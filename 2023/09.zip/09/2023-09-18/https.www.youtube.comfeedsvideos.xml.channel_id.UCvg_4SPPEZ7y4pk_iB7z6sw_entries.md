# Source:Whimsu, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw, language:en-US

## Unity Engine Bad, Some FTC Email Stuff
 - [https://www.youtube.com/watch?v=EUjYsQqK8AI](https://www.youtube.com/watch?v=EUjYsQqK8AI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCvg_4SPPEZ7y4pk_iB7z6sw
 - date published: 2023-09-18T19:42:00+00:00

Unity?

