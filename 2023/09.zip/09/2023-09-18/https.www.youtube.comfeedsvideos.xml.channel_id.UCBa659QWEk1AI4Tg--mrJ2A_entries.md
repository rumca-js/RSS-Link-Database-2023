# Source:Tom Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A, language:en-US

## How languages steal words from each other
 - [https://www.youtube.com/watch?v=TFpzps-DCb0](https://www.youtube.com/watch?v=TFpzps-DCb0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCBa659QWEk1AI4Tg--mrJ2A
 - date published: 2023-09-18T15:00:18+00:00

This is the only pirate reference you're getting from me. • Written with Molly Ruhl and Gretchen McCulloch. Gretchen's podcast has an episode all about this: https://lingthusiasm.com/post/684727483493384192/episode-68-tea-and-skyscrapers-when-words-get • More Language Files: https://www.youtube.com/playlist?list=PL96C35uN7xGLDEnHuhD7CTZES3KXFnwm0

Gretchen's book BECAUSE INTERNET, all about the evolution of internet language, is available:
🇺🇸 US: https://amzn.to/30tLpjT
🇨🇦 CA: https://amzn.to/2JsTYWH
🇬🇧 UK: https://amzn.to/31K8eRD

(Those are affiliate links that give a commission to me or Gretchen, depending on country!)

Graphics by William Marler: https://wmad.co.uk
Audio mix by Graham Haerther and Manuel Simon at Standard Studios: https://haerther.net

REFERENCES:
[etymologies from OED and M-W]
Sanchez, T. (2005). Constraints on structural borrowing in a multilingual contact situation. Doctoral dissertation, University of Pennsylvania. ScholarlyCommons.
https://repository.upenn

