# Source:Moon, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg, language:en-US

## Parasite Tried To Warn You
 - [https://www.youtube.com/watch?v=H6L5KI8uGKQ](https://www.youtube.com/watch?v=H6L5KI8uGKQ)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCmFeOdJI3IXgTBDzqBLD8qg
 - date published: 2023-09-18T18:34:51+00:00

Get an exclusive @Surfshark deal! Enter promo code MOONREAL for an extra 3 months free at https://surfshark.deals/moonreal

Destroy your social media addiction: https://moon.thrivecart.com/tc-qf2ix-3/

Free weekly essays written by Moon - https://mailchi.mp/3ded12821743/moon

Support the channel here (all money goes straight back into the channel):
►  Become a Patron:  https://www.patreon.com/MoonReal
► Follow my Twitter: https://twitter.com/MoonRealYT

