# Source:The Verge, URL:https://www.theverge.com/rss/index.xml, language:en-US

## Netflix ends a three-year legal dispute over Squid Game traffic
 - [https://www.theverge.com/2023/9/18/23879475/netflix-squid-game-sk-broadband-partnership](https://www.theverge.com/2023/9/18/23879475/netflix-squid-game-sk-broadband-partnership)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T21:52:45+00:00

<figure>
      <img alt="An illustration of the Netflix logo." src="https://cdn.vox-cdn.com/thumbor/wqF5GXOzYcqMf_tF_7EVWMgWKD4=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72662467/acastro_STK072_04.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="gNLQWS">Netflix and South Korean ISP SK Broadband have been locked in a legal tussle over network usage cost-sharing since 2020 when <a href="https://www.koreatechtoday.com/netflix-files-civil-lawsuit-against-sk-broadband-over-network-fees/">Netflix filed a lawsuit</a> against the provider, and SK Broadband <a href="https://www.theverge.com/2021/10/1/22704313/sk-broadband-netflix-suing-for-payment-squid-game">responded with its own suit</a>. Now the fight is over, <a href="https://about.netflix.com/en/news/sk-telecom-sk-broadband-and-netflix-establish-strategic-partnership-to">Netflix announced</a>, as the companies drop their lawsuits and instead become partne

## What’s next for Windows and Surface without Panos Panay?
 - [https://www.theverge.com/2023/9/18/23878759/microsoft-windows-panos-panay-surface-yusuf-mehdi](https://www.theverge.com/2023/9/18/23878759/microsoft-windows-panos-panay-surface-yusuf-mehdi)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T21:37:38+00:00

<figure>
      <img alt="The Surface Pro 9 in laptop mode seen from beind." src="https://cdn.vox-cdn.com/thumbor/_znEvNZvhH1VJE2aqdk-SNaGtDA=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72662404/226393_Microsoft_surface_Pro_9_Intel_AKrales_0190.0.jpg" />
        <figcaption><em>The Surface Pro 9.</em> | Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>

  <p id="kzibmJ">Panos Panay has always been the force behind Microsoft’s Surface line. He helped bring Surface to life as a secret project more than 10 years ago. He’s presented the new devices onstage at events, <a href="https://www.washingtonpost.com/business/technology/microsofts-panos-panay-previews-new-surface-mode-at-pentagon-city-mall/2013/10/18/b8b7a03a-37e3-11e3-ae46-e4248e75c8ea_story.html">showed up at malls</a> to promote Surface hardware, and has steered Microsoft’s Surface tablets to success in the years since.</p>
<p id="o0e0qh">Now, he’s leaving in <a href="https://www.thever

## Court blocks California’s online child safety law
 - [https://www.theverge.com/2023/9/18/23879489/california-age-appropriate-design-code-act-blocked-unconstitutional-first-amendment-injunction](https://www.theverge.com/2023/9/18/23879489/california-age-appropriate-design-code-act-blocked-unconstitutional-first-amendment-injunction)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T21:30:59+00:00

<figure>
      <img alt="California Governor Gavin Newsom" src="https://cdn.vox-cdn.com/thumbor/AggY7zNHcOA8otSt7ijoL_5hJgc=/0x0:8256x5504/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72662378/1258832715.0.jpg" />
        <figcaption><em>California Governor Gavin Newsom signed the CAADCA last year.</em> | Photo by Tayfun Coskun / Anadolu Agency via Getty Images</figcaption>
    </figure>

  <p id="ArwPEO">A federal judge has granted a request to block the California Age-Appropriate Design Code Act (CAADCA), a law that <a href="https://www.theverge.com/2022/9/15/23329654/california-governor-gavin-newsom-ab-2273-social-media-children-code-law-signed">requires special data safeguards</a> for underage users online. In <a href="https://netchoice.org/wp-content/uploads/2023/09/NETCHOICE-v-BONTA-PRELIMINARY-INJUNCTION-GRANTED.pdf">a ruling issued today</a>, Judge Beth Freeman granted a preliminary injunction for tech industry group NetChoice, saying the law likely violates the First 

## The cast of Baldur’s Gate 3 is doing a D&D one-shot as their in-game characters
 - [https://www.theverge.com/2023/9/18/23879408/baldurs-gate-3-cast-dnd-high-rollers-one-shot](https://www.theverge.com/2023/9/18/23879408/baldurs-gate-3-cast-dnd-high-rollers-one-shot)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T20:51:09+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/1sokut2dgL-gOq4sUApIsvZ_D9c=/300x0:3540x2160/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72662276/ss_b6a6ee6e046426d08ceea7a4506a1b5f44181543.0.jpg" />
    </figure>

  <p id="ogvyOZ">Later this week, you can watch many cast members from <em>Baldur’s Gate 3</em>, a game that is based heavily on the mechanics and universe of <em>Dungeons &amp; Dragons</em>, play the tabletop version of <em>Dungeons &amp; Dragons</em> as their characters from the video game. It sounds meta but awesome.</p>
<p id="DeHpE1">The cast members will be appearing on <em>High Rollers</em>, a live-play <em>D&amp;D</em> show that <a href="https://www.twitch.tv/highrollersdnd">streams on Twitch</a>, on Friday at 7PM BST / 2PM ET / 11AM PT. “We have very kindly been approached by [<em>Baldur’s Gate 3</em> developer] Larian Studios and some rather fine guests to run a little D&amp;D one-shot,” dungeon master Mark Hulmes said <a href="https://twi

## TMNT: Mutant Mayhem starts streaming on Paramount Plus on September 19th
 - [https://www.theverge.com/2023/9/18/23879336/teenage-mutant-ninja-turtles-mutant-mayhem-streaming-paramount-plus-release](https://www.theverge.com/2023/9/18/23879336/teenage-mutant-ninja-turtles-mutant-mayhem-streaming-paramount-plus-release)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T20:36:38+00:00

<figure>
      <img alt="A group of humanoid turtles wearing masks, standing on their hind legs, and holding an assortment of ninja weapons." src="https://cdn.vox-cdn.com/thumbor/ffN0VkL5Ing_3j39tYsS57J58-0=/509x4:2954x1634/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72662218/tmntmm110k2.0.jpeg" />
        <figcaption>Mutant Mayhem <em>comes to Paramount Plus on  September 19th.</em> | Image: Paramount</figcaption>
    </figure>

  <p id="8gPsyR">Paramount announced that<em> Teenage Mutant Ninja Turtles: Mutant Mayhem</em> <a href="https://go.redirectingat.com?id=66960X1514734&amp;xs=1&amp;url=https%3A%2F%2Fwww.paramountplus.com%2Fmovies%2Fvideo%2FzzvVWZ_qkLDj2LXltHmuZlUsX8BfdZ7U%2F&amp;referrer=theverge.com&amp;sref=https%3A%2F%2Fwww.theverge.com%2F2023%2F9%2F18%2F23879336%2Fteenage-mutant-ninja-turtles-mutant-mayhem-streaming-paramount-plus-release" rel="sponsored nofollow noopener" target="_blank">will hit Paramount Plus tomorrow</a> in the US and Canada. The CG-animated m

## Meta is shutting down three Oculus games without explanation
 - [https://www.theverge.com/2023/9/18/23879252/meta-shut-down-dead-buried-bogo-oculus-games](https://www.theverge.com/2023/9/18/23879252/meta-shut-down-dead-buried-bogo-oculus-games)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T19:19:57+00:00

<figure>
      <img alt="POV: a pair of drawn demonic pistols above a card game in a saloon." src="https://cdn.vox-cdn.com/thumbor/4iIhYrgeTrgb4YvSJXT-GkN4X2A=/178x0:1821x1095/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661892/dead_and_buried_6.0.jpg" />
        <figcaption>Dead and Buried<em> is a Wild West arena shootout multiplayer VR game.</em> | Image: Gunfire Games</figcaption>
    </figure>

  <p id="iWcVUD">Hope you didn’t enjoy playing<em> Dead and Buried</em>, <em>Dead and Buried II</em>, or <em>Bogo </em>on your Rift or Quest headsets — because Meta’s shutting them all down with no explanation, just like it already did <a href="https://www.theverge.com/2023/1/31/23580356/meta-shut-down-echo-vr-oculus-quest-arena-ready-at-down">with <em>Echo VR</em></a> (aka <em>Echo Arena</em>).</p>
<p id="xGivEM">“We are reaching out to let you know that Dead and Buried will no longer be supported as of Friday, March 15, 2024,” reads an email in my inbox. “You can continue to hu

## Microsoft Paint is finally adding some of Photoshop’s best features
 - [https://www.theverge.com/2023/9/18/23879221/microsoft-paint-testing-layers-transparency-photoshop-features](https://www.theverge.com/2023/9/18/23879221/microsoft-paint-testing-layers-transparency-photoshop-features)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T19:11:49+00:00

<figure>
      <img alt="A screenshot of Microsoft Paint on Windows using a new layers feature." src="https://cdn.vox-cdn.com/thumbor/dlyTPgTQNiXRLLHSFJCzb2H0FzE=/59x0:1922x1242/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661876/Paint_Layers.0.png" />
        <figcaption><em>Creating a simple image like this is much easier when you can work in layers.</em> | Image: Microsoft</figcaption>
    </figure>

  <p id="OQ01BX">Microsoft is on a slow-burn path to making Paint a useful tool for actual creators by finally implementing one of Photoshop’s core features: layers. As part of an <a href="https://blogs.windows.com/windows-insider/2023/09/18/paint-app-update-adding-support-for-layers-and-transparency-begins-rolling-out-to-windows-insiders/">update rolling out for testing by Windows Insiders</a> (version 11.2308.18.0, available to some people in the Canary or Dev channels), Microsoft Paint is introducing support for both layers and transparency. These features have long been t

## The smaller iPhone 16 Pro might get Apple’s new ‘tetraprism’ zoom lens
 - [https://www.theverge.com/2023/9/18/23879170/apple-iphone-16-pro-max-tetraprism-zoom-lens-telephoto](https://www.theverge.com/2023/9/18/23879170/apple-iphone-16-pro-max-tetraprism-zoom-lens-telephoto)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T19:03:28+00:00

<figure>
      <img alt="Apple iPhone 15 Pro and 15 Pro Max in white titanium." src="https://cdn.vox-cdn.com/thumbor/XF3lFM4INuP2lsu3OfpOvFARlVM=/0x0:4416x2944/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661843/DSCF3385.0.jpeg" />
        <figcaption><em>The iPhone 15 Pro Max and iPhone 15 Pro.</em> | Image: The Verge</figcaption>
    </figure>

  <p id="26iLoY">Next year’s Pro iPhones are both “expected” to have the “tetraprism” zoom lens Apple is using for the 5x telephoto camera in the iPhone 15 Pro Max, according to a new post <a href="https://medium.com/@mingchikuo/iphone-15-pro-max%E7%9A%84%E4%BA%A4%E4%BB%98%E6%99%82%E9%96%93%E5%AE%8C%E5%85%A8%E5%8F%96%E6%B1%BA%E6%96%BC%E5%A4%A7%E7%AB%8B%E5%85%89%E7%8D%A8%E5%AE%B6%E4%BE%9B%E6%87%89%E4%B9%8B%E5%9B%9B%E9%87%8D%E5%8F%8D%E5%B0%84%E7%A8%9C%E9%8F%A1-%E6%BD%9B%E6%9C%9B%E9%8F%A1-%E9%8F%A1%E9%A0%AD%E4%B9%8B%E5%87%BA%E8%B2%A8%E9%87%8F-%E5%9B%9B%E9%87%8D%E5%8F%8D%E5%B0%84%E7%A8%9C%E9%8F%A1%E9%8F%A1%E9%A0%AD%E5%96%AE%E5%83%B9%E9%

## Virtual tickets to the Code Conference are now on sale
 - [https://www.theverge.com/23879011/code-conference-2023-virtual-tickets](https://www.theverge.com/23879011/code-conference-2023-virtual-tickets)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T19:00:00+00:00

<figure>
      <img alt="The Code Conference wordmark." src="https://cdn.vox-cdn.com/thumbor/b7fykg6cgzBLV3aOqEiY0ie87V4=/149x0:917x512/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661803/406f18fd53f6cb61c6f4b27569ea09a8.Frame_2.0.jpg" />
        <figcaption>Image: Code</figcaption>
    </figure>

  <p id="Vdawpr">If you can’t make it out to attend this year’s Code Conference in person, here’s another option: <a href="https://codevirtualregistrationpublic.eventfinity.co/register">virtual tickets are now available</a>. Virtual ticket holders will be able to tune in for main-stage programming and get live access to the event’s biggest interviews, including sit-downs with X CEO <strong>Linda Yaccarino</strong>, GM CEO <strong>Mary Barra</strong>, and Max content leader <strong>Casey Bloys</strong>.</p>
<p id="xVddBz">This year’s Code Conference is hosted by <em>The Verge</em> editor-in-chief <strong>Nilay Patel</strong>, <em>Platformer</em> founder <strong>Casey Newton</strong>

## Unity plans to change its disastrous new pricing program
 - [https://www.theverge.com/2023/9/18/23879029/unity-pricing-model-change](https://www.theverge.com/2023/9/18/23879029/unity-pricing-model-change)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T18:57:19+00:00

<figure>
      <img alt="Image of Unity’s company logo." src="https://cdn.vox-cdn.com/thumbor/V6IqrOMiE8gItiNcZbMWFUkwyLg=/128x0:1073x630/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661787/Unity_1200X630.0.png" />
        <figcaption>Image: Unity</figcaption>
    </figure>

  <p id="c868wh">Unity plans to change its forthcoming pay-per-install program following widespread criticism from game developers.</p>
<p id="YJta4Q">“We apologize for the confusion and angst the runtime fee policy we announced on Tuesday caused,” <a href="https://x.com/unity/status/1703547752205218265?s=20">Unity posted on X (formerly Twitter)</a>. “We are listening, talking to our team members, community, customers, and partners, and will be making changes to the policy. We will share an update in a couple of days.”</p>
<p id="AL0yvJ">This new communication from Unity comes after nearly a week of <a href="https://x.com/unity/status/1702077049425596900?s=20">clarifications</a>, <a href="https://www.the

## How to install watchOS 10
 - [https://www.theverge.com/23879092/watchos-10-install-how-to](https://www.theverge.com/23879092/watchos-10-install-how-to)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T18:44:52+00:00

<figure>
      <img alt="Apple Watch" src="https://cdn.vox-cdn.com/thumbor/9ZavpRBFGXWtXtclfVD9uJGZKIk=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661717/HT024_smartWatches_0001.0.jpg" />
        <figcaption><em>watchOS 10 is all about the widgets — and you can try them out for yourself by downloading the public beta.</em> | Illustration by Samar Haddad / The Verge</figcaption>
    </figure>

  <p id="T5f89e">If you were intrigued by the idea of widgets on your Apple Watch at this year’s <a href="https://www.theverge.com/2023/6/5/23738826/apple-watch-watchos-10-features-updates-wwdc-2023">WWDC</a>, good news! Apple’s watchOS 10 is live and ready to download.</p>
<div class="c-float-left c-float-hang"><aside id="vIgjFA"><div></div></aside></div>
<p id="STfnOO">That said, before I tell you how to install it, there are a few things you should keep in mind. First off, watchOS 10 <em>is</em> a substantial update. Not only does it reintroduce widgets to the platfor

## The cheaper $600 Asus ROG Ally is here, and you probably shouldn’t buy it
 - [https://www.theverge.com/2023/9/18/23879024/asus-rog-ally-600-z1-gaming-handheld-steam-deck](https://www.theverge.com/2023/9/18/23879024/asus-rog-ally-600-z1-gaming-handheld-steam-deck)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T18:14:40+00:00

<figure>
      <img alt="The Asus ROG Ally PC gaming handheld in white standing upright on a wood desk and showing a Windows homescreen." src="https://cdn.vox-cdn.com/thumbor/GEhFH8Qq9nu4DpFvLOSkN3ztTz0=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661594/asus_rog_ally_vjeran_pavic_the_verge_002.0.jpeg" />
        <figcaption><em>Whether you pay $600 or $700, the Asus ROG Ally looks the same.</em> | Photo by Vjeran Pavic / The Verge</figcaption>
    </figure>

  <p id="EgE9D4">If you’ve been eying an Asus ROG Ally gaming handheld but can’t quite justify the $700 price tag... you’ll probably want to keep on waiting. Today, the company has begun selling <a href="https://howl.me/ckB1FYddA5y">a less-expensive $600 model</a> with a lower-performance AMD Z1 chip, but early reviews suggest the Windows gaming handheld is too compromised to justify the purchase.</p>
<p id="KIdOqd">Bottom line: Z1 performance is reportedly worse than the $400-and-up <a href="https://www.

## Apple’s bigger iCloud Plus plans are now available
 - [https://www.theverge.com/2023/9/18/23879087/apple-new-icloud-plus-plans-availability-pricing](https://www.theverge.com/2023/9/18/23879087/apple-new-icloud-plus-plans-availability-pricing)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T18:06:44+00:00

<figure>
      <img alt="Illustration of the Apple logo on a yellow and teal background." src="https://cdn.vox-cdn.com/thumbor/zxextlVabcB0hL76JZ3gtm9CXho=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661572/STK071_apple_K_Radtke_02.0.jpg" />
        <figcaption>Illustration: The Verge</figcaption>
    </figure>

  <p id="Kss917"><a href="https://www.apple.com/newsroom/2023/09/apple-expands-the-power-of-icloud-with-new-icloud-plus-plans/">Apple’s new iCloud Plus plans</a> offer more storage at a higher price — and they’re available to purchase now. Starting today, you can sign up for the 6TB plan at $29.99 / month or the 12TB plan for $59.99 / month.</p>
<p id="bZpZE1">Apple first revealed the new storage options <a href="https://www.theverge.com/23869728/apple-iphone-15-event-announcements-watch-ultra-airpods-pro-usb-c">during its iPhone 15 event last week</a>, which it will offer alongside the existing 50GB plan for $0.99 / month, the 200GB plan for $2.99 / m

## Microsoft’s former Surface chief Panos Panay is reportedly heading to Amazon
 - [https://www.theverge.com/2023/9/18/23879036/microsoft-panos-panay-amazon-hire-former-surface-windows-chief](https://www.theverge.com/2023/9/18/23879036/microsoft-panos-panay-amazon-hire-former-surface-windows-chief)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T17:39:45+00:00

<figure>
      <img alt="Las Vegas Hosts Annual CES Trade Show" src="https://cdn.vox-cdn.com/thumbor/F_r3ZMocV-frYbJ8Iww7HzIue9Y=/5x0:4769x3176/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661471/1454311872.0.jpg" />
        <figcaption>Photo by David Becker / Getty Images</figcaption>
    </figure>

  <p id="nBXnbP">Panos Panay is reportedly joining Amazon, <a href="https://www.bloomberg.com/news/articles/2023-09-18/amazon-is-poised-to-hire-departing-microsoft-product-chief?sref=ExbtjcSG"><em>Bloomberg </em>reports</a>. The former Windows and Surface chief <a href="https://www.theverge.com/2023/9/18/23878609/microsoft-windows-panos-panay-leaving">announced his departure from Microsoft earlier today</a>, and <em>Bloomberg</em> reports that he’s moving to Seattle’s other giant tech company to oversee Amazon’s vast hardware products.</p>
<p id="FIBUS7">Panay has been instrumental in the creation of Surface devices and much of their success and will no longer be presenting at M

## Music industry revenue hits all-time high
 - [https://www.theverge.com/2023/9/18/23878916/riaa-music-industry-revenue-all-time-high-first-half-2023](https://www.theverge.com/2023/9/18/23878916/riaa-music-industry-revenue-all-time-high-first-half-2023)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T17:08:24+00:00

<figure>
      <img alt="A photo of Sennheiser’s Momentum 4 headphones on a pillow." src="https://cdn.vox-cdn.com/thumbor/wmDiN2zDIBM0ImKnx9b5d6S8kPw=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661308/DSCF8617.0.jpg" />
        <figcaption>Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="6VspPP">The RIAA just put out <a href="https://www.riaa.com/riaa-mid-year-2023-revenue-report/">the music industry’s midyear revenue report</a>, and it’s a stark illustration of the haves / have-not divide that’s been accelerating in the streaming era. Actually, scratch that: it’s a terrific illustration of how good it is for the <em>haves: </em>retail revenue is up 9.3 percent to an all-time first half high of $8.4 billion, while wholesale revenue is up 8.3 percent to 5.3 billion. (You can read a good <a href="https://www.musicbusinessworldwide.com/why-the-riaa-still-focuses-on-retail-data-in-the-streaming-age/">explanation of retail versus wholesale her

## Apple’s widget-heavy watchOS 10 is available to download
 - [https://www.theverge.com/2023/9/18/23878532/apple-watchos-10-available-series-9](https://www.theverge.com/2023/9/18/23878532/apple-watchos-10-available-series-9)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T17:06:24+00:00

<figure>
      <img alt="Widget showing three complications in watchOS 10" src="https://cdn.vox-cdn.com/thumbor/Nt2ftbNP2cJD1HUZSrp4_Z13-0U=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661299/widgetss.0.jpg" />
        <figcaption>Photo by Victoria Song / The Verge</figcaption>
    </figure>

  <p id="IkQKBH">Along with <a href="https://www.theverge.com/e/23639744">iOS 17</a>, Apple has <a href="https://www.apple.com/newsroom/2023/09/watchos-10-is-available-today/">just released watchOS 10</a>, the newest version of its smartwatch operating system that fundamentally changes the way you interact with the Apple Watch by reincorporating widgets. This update, available on the Apple Watch Series 4 and up, comes just a few days ahead of the Apple Watch Series 9 and the Apple Watch Ultra, both of which <a href="https://www.theverge.com/23866958/apple-watch-ultra-2-series-9-hands-on-pictures-video-price">Apple will release on Friday</a> along with the four new <a href

## iOS 17 and iPadOS 17 are now available
 - [https://www.theverge.com/2023/9/18/23875703/apple-ios-17-ipados-17-now-available-iphone-ipad](https://www.theverge.com/2023/9/18/23875703/apple-ios-17-ipados-17-now-available-iphone-ipad)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T17:06:11+00:00

<figure>
      <img alt="A hand holding up an iPhone 15 Pro model" src="https://cdn.vox-cdn.com/thumbor/jkGvXZtuLJB1QhrF4KbrfQXJMlw=/0x0:5568x3712/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661296/DSC_1099.0.jpeg" />
        <figcaption>Photo by Nilay Patel / The Verge</figcaption>
    </figure>

  <p id="nEiI7g">iOS 17 and iPadOS 17, Apple’s next major updates for the iPhone and iPad, are now available to download. </p>
<p id="s8bUQ4">With <a href="https://www.apple.com/newsroom/2023/09/ios-17-is-available-today/">iOS 17</a>, some of the biggest new features come to phone calls. Apple’s <a href="https://www.theverge.com/23814601/iphone-ios-17-contact-poster-how-to">new Contact Posters</a> let you pick a photo (or Memoji) and font that fill up the screen when you give someone a call. Live Voicemail will show you a real-time transcript as someone is leaving you a message. The end call button is also in <a href="https://www.theverge.com/2023/8/15/23833689/apple-ios-17-end-ca

## You can get $500 in credit when you preorder Samsung’s 57-inch Odyssey Neo G9 gaming monitor
 - [https://www.theverge.com/2023/9/18/23878636/samsung-57-inch-odyssey-neo-g9-gaming-monitor-preorder-buy-price-release-date](https://www.theverge.com/2023/9/18/23878636/samsung-57-inch-odyssey-neo-g9-gaming-monitor-preorder-buy-price-release-date)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T16:42:33+00:00

<figure>
      <img alt="The large Samsung Odyssey Neo G9 on a white desk in a bright room near the window." src="https://cdn.vox-cdn.com/thumbor/yKqOTRVc7Z6VU-UuD-DW-2IBUUU=/0x42:1000x709/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661191/Odyssey_Neo_G9_Dual_UHD_Gaming_Monitor_Main2.0.jpg" />
        <figcaption><em>This big boi comes with a high price tag of $2,499.99.</em> | Image: Samsung</figcaption>
    </figure>

  <p id="xDSos5">After <a href="https://www.theverge.com/2023/1/2/23531399/samsung-new-odyssey-neo-g9-mini-led-8k">first making its official debut at CES 2023</a> earlier this year, Samsung’s massive 57-inch Odyssey Neo G9 gaming monitor <a href="https://howl.me/ckB0zpZn3Hc">is now available to preorder</a> in the US. You can get it for $2,499.99 when you preorder it ahead of its US release date on <a href="https://www.theverge.com/2023/8/23/23842638/samsung-57-inch-odyssey-neo-g9-dual-uhd-4k-monitor-price-release-date-specs-features">October 2nd</a> — and e

## UK antitrust regulator lays out seven AI principles
 - [https://www.theverge.com/2023/9/18/23878784/uk-anti-trust-regulator-ai-principles](https://www.theverge.com/2023/9/18/23878784/uk-anti-trust-regulator-ai-principles)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T16:28:58+00:00

<figure>
      <img alt="An image showing a graphic of a brain on a black background" src="https://cdn.vox-cdn.com/thumbor/qyk0xbHlshfDm8LKfHn_rbbyRVQ=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661137/acastro_181017_1777_brain_ai_0001.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="aJGZSz">The UK’s Competition and Markets Authority <a href="https://www.gov.uk/government/news/proposed-principles-to-guide-competitive-ai-markets-and-protect-consumers">set out specific principles</a> to help guide AI regulations and companies that develop the technology. </p>
<p id="Q7W3ot">The CMA, which acts as the primary antitrust regulator for the UK, focused its attention on foundation models: AI systems like OpenAI’s GPT-4, Meta’s Llama 2, and other large language models that form the basis for many generative AI use cases. </p>
<p id="RHLF3j">Companies making foundation models should follow seven principles. That

## This cozy Apple Arcade game consumed my entire weekend
 - [https://www.theverge.com/23878638/japanese-rural-life-adventure-apple-arcade-iphone-game](https://www.theverge.com/23878638/japanese-rural-life-adventure-apple-arcade-iphone-game)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T16:17:07+00:00

<figure>
      <img alt="A screenshot from the video game Japanese Rural Life Adventure." src="https://cdn.vox-cdn.com/thumbor/X6sXVGg6hnjD_oNuag4EHjkE25w=/350x0:4130x2520/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661094/Japanese_Rural_Life_Adventure_Screenshot_2560x1600_04.0.png" />
        <figcaption>Image: Apple</figcaption>
    </figure>

  <p id="pt7bUL">This past weekend, I spent a lot of time thinking about Mount Fuji. Not the real one, but a pixelated version of the mountain range that’s available as a sightseeing opportunity in the new Apple Arcade release <a href="https://apps.apple.com/us/app/japanese-rural-life-adventure/id1634749545"><em>Japanese Rural Life Adventure</em></a>. It’s <a href="https://www.theverge.com/2022/12/27/23523251/cozy-games-animal-crossing-stardew-world-of-warcraft-dragonflight">a cozy game</a> that’s all about making your way in a small mountainside town, giving you a long list of tasks to accomplish, with that beautiful Mount Fuji vie

## Moment’s T-Series lenses give your smartphone’s camera superpowers
 - [https://www.theverge.com/2023/9/18/23862233/moment-t-series-smartphone-lenses-hands-on-iphone-galaxy-pixel](https://www.theverge.com/2023/9/18/23862233/moment-t-series-smartphone-lenses-hands-on-iphone-galaxy-pixel)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T16:00:00+00:00

<figure>
      <img alt="A picture of the Moment lenses leaning in a row against a flower pot." src="https://cdn.vox-cdn.com/thumbor/YeHvkAgwqoNOizvngDE1Dq9k5gw=/64x399:1806x1560/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72661005/Moment_lenses.0.png" />
        <figcaption><em>Moment lenses from left to right: Macro 10x, Fisheye 14mm, Tele 58mm, Wide 18mm</em> | Photo by Wes Davis / The Verge</figcaption>
    </figure>

  <p id="4sAGoO">Moment’s smartphone lenses are, in theory, perfect for people like me. I love taking pictures and have wanted to try more serious photography for a long time, but nicer DSLR cameras are expensive, bulky, and intimidating. </p>
<p id="R4nSIT">The new T-Series lenses from Moment, <a href="https://www.theverge.com/2023/8/16/23833436/moment-smartphone-camera-t-series-lenses-iphone-android">which launched last month</a> and are now for sale, could be just the ticket for letting me take nicer pictures without investing in high-end camera gear. The

## Apple’s new AirPods Pro with USB-C charging case is already $50 off on a preorder
 - [https://www.theverge.com/2023/9/18/23878472/apple-airpods-pro-usbc-anker-magsafe-charger-cube-samsung-deal-sale](https://www.theverge.com/2023/9/18/23878472/apple-airpods-pro-usbc-anker-magsafe-charger-cube-samsung-deal-sale)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T15:52:12+00:00

<figure>
      <img alt="Apple’s second-generation AirPods Pro photographed on a reflective black surface." src="https://cdn.vox-cdn.com/thumbor/oy5xQ9mCHf6q7FdXQFcnItiLnZY=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660969/DSCF9466.0.jpg" />
        <figcaption><em>While this is technically a photo of second-gen AirPods Pro with a Lightning case, the new USB-C model will look identical.</em> | Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="2L7aEx">Apple’s <a href="https://www.theverge.com/23869728/apple-iphone-15-event-announcements-watch-ultra-airpods-pro-usb-c">biggest announcement</a> last week at its “Wonderlust” event was, without a doubt, the <a href="https://www.theverge.com/23870387/iphone-15-plus-hands-on-pictures-video-price">iPhone 15’s</a> change to USB-C, which is already having a ripple effect, as the AirPods Pro are also ditching Lightning for the port upgrade. Now, surprisingly, you can preorder the new <a href="https:/

## How to install iOS 17 on your iPhone
 - [https://www.theverge.com/23878612/ios-17-iphone-install-update-how-to](https://www.theverge.com/23878612/ios-17-iphone-install-update-how-to)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T15:33:16+00:00

<figure>
      <img alt="iPhone with icons and illustrated background" src="https://cdn.vox-cdn.com/thumbor/St9OPiwNzmjlU-dT504aBv9cmek=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660899/HT015_S_Haddad_ios_iphone_14_02.0.jpg" />
        <figcaption>Illustration by Samar Haddad / The Verge</figcaption>
    </figure>

  <p id="UYMcO9">Okay, it’s time — Apple is rolling out iOS 17 to everyone today. While it’s been possible to download the <a href="https://www.theverge.com/23758362/developer-public-beta-ios-17-how-to-install">developer and public betas of iOS 17</a> for a while, you can now download and install this latest version of Apple’s new mobile operating system, which is stable and ready to go.</p>
<p id="daXNhD">But first, an important reminder: whenever you play with your operating system, it never hurts to first <a href="https://www.theverge.com/22673693/iphone-apple-backup-ios-icloud">back up your device’s data</a> — just in case.</p>
<h2 id="ndZ4Tk"

## Loki’s second season will debut a day early
 - [https://www.theverge.com/2023/9/18/23878714/loki-second-season-premiere-date-disney-plus](https://www.theverge.com/2023/9/18/23878714/loki-second-season-premiere-date-disney-plus)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T15:24:26+00:00

<figure>
      <img alt="An image from Loki’s second season." src="https://cdn.vox-cdn.com/thumbor/5Jats5Q_WyTnwy61SIbfvQZnyC4=/102x0:1197x730/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660871/g_disneyplusoriginals_loki_s2_613_04_fc02826c.0.jpeg" />
        <figcaption>Image: Disney</figcaption>
    </figure>

  <p id="XSgt9L"><em>Loki</em> has a new premiere date. The second season of the Disney Plus show will now debut on Thursday, October 5th, at 6PM PT, <a href="https://twitter.com/DisneyPlus/status/1703786161108590875">Disney announced on Monday</a>. It was previously set to come out <a href="https://www.theverge.com/2023/5/16/23726218/loki-season-2-premiere-date-october">on October 6th</a>.</p>
<p id="5tXFn1">Disney made the announcement alongside a post on X featuring some footage of the show and interviews with people involved with the show’s production. There are some brief glimpses of what you can expect from the next season as well — though if you’re looking for

## Good Burger 2 premieres on Paramount Plus on November 22nd
 - [https://www.theverge.com/23878603/good-burger-2-paramount-plus-release-date-premiere](https://www.theverge.com/23878603/good-burger-2-paramount-plus-release-date-premiere)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T15:22:04+00:00

<figure>
      <img alt="A screenshot from the Good Burger 2 teaser showing the employees of Good Burger in the new film." src="https://cdn.vox-cdn.com/thumbor/YpZ3wC8l7yTzTaNDGrh6HNJKweA=/294x0:3459x2110/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660847/Good_Burger_2.0.png" />
        <figcaption>A screenshot from the <em>Good Burger 2</em> teaser. | Screenshot: Wes Davis / The Verge</figcaption>
    </figure>

  <p id="5Nj9ZF">I bet you forgot or, like me, had completely missed that there’s a <a href="https://www.theverge.com/2023/3/18/23646113/good-burger-2-paramount-plus-kenan-thompson-kel-mitchell"><em>Good Burger </em>sequel</a> coming out. Well, it’s <a href="https://www.paramountpressexpress.com/paramount-plus/shows/good-burger-2/releases/?view=108488-paramount-reveals-key-art-and-premiere-date-for-good-burger-2-the-all-new-movie-sequel-to-the-cult-classic-90s-film">coming to Paramount Plus <em>this Friday</em></a>, September 22nd. <em>Good Burger 2 </em>stars<em> 

## The Steve Jobs Archive is helping nine people follow in the man’s footsteps
 - [https://www.theverge.com/2023/9/18/23878397/steve-jobs-archive-fellowship-apple-financial-assistance-program](https://www.theverge.com/2023/9/18/23878397/steve-jobs-archive-fellowship-apple-financial-assistance-program)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T15:00:00+00:00

<figure>
      <img alt="Apple CEO Steve Jobs appears at Apple’s special media event to introduce the second generation iPad at the Yerba Buena Center for the Arts in San Francisco on March 2, 2011 in California" src="https://cdn.vox-cdn.com/thumbor/B2HsiJmxZACvW3UA9KCE_vili4w=/0x1335:2912x3276/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660743/109738015.0.jpg" />
        <figcaption><em>Jobs was keen to support the liberal arts alongside technological developments at Apple during his time as CEO.</em> | Image: Kimihiro Hoshino / AFP via Getty Images</figcaption>
    </figure>

  <p id="AtDBeA">Today, the Steve Jobs Archive (SJA) — an organization that collects and curates information about the late Apple founder’s life — has introduced a part-time fellowship program that aims to help a new generation of creative and technologically gifted people follow in Jobs’ footsteps. </p>
<p id="tLxVCO">The first nine SJA fellows are a group of “young creators” that includes musicians

## Windows leader Panos Panay is leaving Microsoft
 - [https://www.theverge.com/2023/9/18/23878609/microsoft-windows-panos-panay-leaving](https://www.theverge.com/2023/9/18/23878609/microsoft-windows-panos-panay-leaving)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T14:18:36+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/b_De9gah5uGrEaEH_yJh5qQ5c_c=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660621/226323_Surface_event_hands_on_0013.0.jpg" />
        <figcaption><em>Panos Panay</em> | Photo by Becca Farsace / The Verge</figcaption>
    </figure>

  <p id="PNjyfp">Panos Panay, the chief product officer at Microsoft leading Windows development and the company’s Surface line, is leaving Microsoft. In an announcement on Monday, Microsoft told employees: “After nearly 20 years at the company, Panos Panay has decided to leave Microsoft.”</p>
<p id="B0ntMA">Panay first joined Microsoft in 2004 as a group program manager. After overseeing the company’s Surface line, Panay became the company’s chief product officer in 2018, where he led the development of Windows 11.</p>
<p id="SzVc2O">You can read the full email to employees below:</p>
<blockquote>
<p id="fcPfq2">Team, </p>
<p id="3bgbNX">After nearly 20 years at the com

## The cable bundle of the future is officially here
 - [https://www.theverge.com/23868355/disney-charter-bundle-espn-abc-broadcast](https://www.theverge.com/23868355/disney-charter-bundle-espn-abc-broadcast)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T14:08:05+00:00

<figure>
      <img alt="A colorful graphical illustration of the Disney Plus logo." src="https://cdn.vox-cdn.com/thumbor/uLzMG8FWn1cVQsrMpxUm4WnN9G8=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660603/acastro_STK080_disneyPlus_02.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>


  		 <p>Disney and Charter’s historic agreement has introduced a new kind of cable bundle, and it could be the thing that saves cable TV... or destroys it.</p>
  <p>
    <a href="https://www.theverge.com/23868355/disney-charter-bundle-espn-abc-broadcast">Continue reading&hellip;</a>
  </p>

## Carrot will report the weather in your own voice on iOS 17
 - [https://www.theverge.com/2023/9/18/23878349/carrot-weather-app-ios-17-watchos-10-personal-voice](https://www.theverge.com/2023/9/18/23878349/carrot-weather-app-ios-17-watchos-10-personal-voice)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T14:00:00+00:00

<figure>
      <img alt="A screenshot of Carrot Weather on the iPhone’s StandBy mode." src="https://cdn.vox-cdn.com/thumbor/7B-eE5uFt6CZ-2lXvoZeUkOcsOk=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660520/Carrot_Weather.0.jpg" />
        <figcaption><em>You can also make the app impersonate celebrity voices if you don’t fancy hearing yourself being imitated.</em> | Image: Carrot / The Verge</figcaption>
    </figure>

  <p id="tGTClP">Carrot Weather — the forecasting app known for its hilariously snarky weather updates — is introducing some new features that make use of the <a href="https://www.theverge.com/2023/9/12/23863224/ios-17-release-date-apple-iphone-15-announcement">iOS 17</a> and <a href="https://www.theverge.com/2023/9/12/23860559/apple-watchos-10-release-date-september-features">watchOS 10</a> software updates coming today, including new weather widgets and a voice impersonation feature. </p>
<p id="LHOo7R"><a href="https://apps.apple.com/app/apple-

## Google’s Nest Hub Max is dropping support for Google Meet and Zoom
 - [https://www.theverge.com/2023/9/18/23878449/google-nest-hub-max-end-support-meet-zoom](https://www.theverge.com/2023/9/18/23878449/google-nest-hub-max-end-support-meet-zoom)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:49:34+00:00

<figure>
      <img alt="A photo showing people using Zoom on a Nest Hub Max" src="https://cdn.vox-cdn.com/thumbor/IVC5SKsuxQM7-Q2aHpvX6zUrroo=/125x0:1475x900/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660498/Zoom_on_Nest_Hub_Max.0.png" />
        <figcaption>Image: Google</figcaption>
    </figure>

  <p id="b4eAl6">Google is axing support for Google Meet and Zoom on its Nest Hub Max smart display. As <a href="https://9to5google.com/2023/09/18/nest-hub-max-google-meet-zoom/">spotted by <em>9to5Google</em></a>, some users are seeing a notice on their device that states they can no longer join meetings through Google Meet starting September 28th.</p>
<p id="R4Lxvp">Similarly, a <a href="https://support.zoom.us/hc/en-us/articles/17423126359309-Advance-notice-of-end-of-support-for-Google-Nest-Hub-Max">support page updated by Zoom in July states</a>: “All Zoom support for Google Nest Hub Max will end on September 30th, 2023.” After that date, the Zoom app will stop working, an

## We tried to make a hit song with only AI tools — and it got messy
 - [https://www.theverge.com/23878445/ai-music-tools-magenta-suno-chatgpt-vergecast](https://www.theverge.com/23878445/ai-music-tools-magenta-suno-chatgpt-vergecast)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:47:06+00:00

<figure>
      <img alt="Illustration of the Vergecast logo" src="https://cdn.vox-cdn.com/thumbor/FvQrygGxjhrcN-OXNWSUlh4lkxw=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660494/AI_Music_3000x2000.0.png" />
        <figcaption>Illustration by Samar Haddad / The Verge</figcaption>
    </figure>

  <p id="3FhkZR">With only a couple of minutes and access to YouTube, you can now make SpongeBob SquarePants sing your favorite Taylor Swift song. Or make Taylor Swift sing your favorite Drake song. Or make Drake sing <em>your </em>song. AI covers and AI-generated originals are suddenly everywhere on the internet, to the point where <a href="https://www.404media.co/harry-styles-one-direction-ai-leaked-songs/">even diehard fans don’t know</a> what’s a real leak and what’s a generated one. It’s a complicated <a href="https://www.theverge.com/2023/4/19/23689879/ai-drake-song-google-youtube-fair-use">ethical and legal mess</a> and makes being a music fan weirder than ever.<

## The Elder Scrolls VI will skip PS5 and isn’t coming until at least 2026
 - [https://www.theverge.com/2023/9/18/23878504/the-elder-scrolls-6-2026-release-xbox-exclusive](https://www.theverge.com/2023/9/18/23878504/the-elder-scrolls-6-2026-release-xbox-exclusive)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:40:45+00:00

<figure>
      <img alt="The logo for The Elder Scrolls VI." src="https://cdn.vox-cdn.com/thumbor/EcpcW3h5dCgrTNBlgUixe6MXu98=/406x0:1774x912/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660484/Screen_Shot_2023_09_18_at_9.03.06_AM.0.png" />
        <figcaption>Image: Bethesda Softworks</figcaption>
    </figure>

  <p id="LusXsi">A document released as part of the <a href="https://www.theverge.com/23768244/ftc-microsoft-activision-blizzard-case-news-announcements"><em>FTC v. Microsoft </em>case</a> confirms what <a href="https://www.theverge.com/2021/11/15/22783314/elder-scrolls-6-xbox-exclusive-pc-phil-spencer">was long expected</a>: <em>The Elder Scrolls VI</em> isn’t going to launch for a few years, and it isn’t coming to PlayStation. According to the new chart, which Microsoft produced for the FTC, the next <em>Elder Scrolls</em> game isn’t expected to launch until at least 2026 — something a Microsoft lawyer <a href="https://twitter.com/tomwarren/status/1674547360842539

## Apple made it way cheaper to repair an iPhone 15 Pro’s broken back glass
 - [https://www.theverge.com/2023/9/18/23878447/iphone-15-back-glass-repair-price-apple](https://www.theverge.com/2023/9/18/23878447/iphone-15-back-glass-repair-price-apple)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:27:11+00:00

<figure>
      <img alt="Apple iPhone 15 Pro and Pro Max in natural titanium" src="https://cdn.vox-cdn.com/thumbor/XFHHGr9JUs-3S2fdTv254qay0ZQ=/0x0:4416x2944/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660430/DSCF3357.0.jpeg" />
        <figcaption><em>iPhone 15 Pro and Pro Max.</em> | Photo: Dan Seifert / The Verge</figcaption>
    </figure>

  <p id="sYmqBT">It’s significantly cheaper to repair the back glass on an iPhone 15 Pro than it was on the iPhone 14 Pro. Apple posted <a href="https://support.apple.com/iphone/repair">price estimates</a> for its new phones over the weekend, listing a repair price of $169 for the 15 Pro and $199 for the Pro Max to replace either phone’s shattered back glass.</p>
<p id="SFjGTp">That’s up to a $350 decrease from the repair price for last year’s models. For the iPhone 14 Pro and 14 Pro Max, Apple charged $499 and $549 for back glass replacement — frankly, outlandish prices that ran more expensive than the cost of an (admittedly much low

## Protesters take over NYC streets to tell Joe Biden to ‘end fossil fuels’
 - [https://www.theverge.com/2023/9/18/23875180/protest-march-climate-change-end-fossil-fuels-new-york-city-joe-biden](https://www.theverge.com/2023/9/18/23875180/protest-march-climate-change-end-fossil-fuels-new-york-city-joe-biden)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:21:01+00:00

<figure>
      <img alt="" src="https://cdn.vox-cdn.com/thumbor/Xw-zJheiBvpJAzeSSZMHwT-AvmQ=/0x0:2700x1800/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660416/236781_March_to_end_Fossil_Fuel_AKrales_0716.0.jpg" />
        <figcaption>Photo by Amelia Holowaty Krales / The Verge</figcaption>
    </figure>


  		 <p>Demonstrators flood city streets ahead of a key United Nations climate summit with a clear message for Joe Biden: ‘end fossil fuels.’</p>
  <p>
    <a href="https://www.theverge.com/2023/9/18/23875180/protest-march-climate-change-end-fossil-fuels-new-york-city-joe-biden">Continue reading&hellip;</a>
  </p>

## Activision was briefed on Nintendo’s Switch 2 last year
 - [https://www.theverge.com/2023/9/18/23878412/nintendo-switch-2-activision-briefing-next-gen-switch](https://www.theverge.com/2023/9/18/23878412/nintendo-switch-2-activision-briefing-next-gen-switch)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:06:50+00:00

<figure>
      <img alt="A Nintendo Switch" src="https://cdn.vox-cdn.com/thumbor/dyetiYOHseJs4trYJBTggY5Z69A=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660377/jbareham_180301_2346_nintendo_switch_0034_splatoon.0.jpg" />
        <figcaption>Photo by James Bareham / The Verge</figcaption>
    </figure>

  <p id="2YigJ0">Rumors of a Nintendo Switch 2 announcement have grown recently after reports of developer demos at Gamescom last month. Now we know that Activision was briefed on a next-generation Nintendo Switch last year, thanks to internal emails from the <a href="https://www.theverge.com/23768244/ftc-microsoft-activision-blizzard-case-news-announcements"><em>FTC v. Microsoft </em>case</a>.</p>
<p id="nBtioi">Activision executives, including CEO Bobby Kotick, met with Nintendo executives in December 2022 to discuss a next-generation Switch. In an internal email chain, Chris Schnakenberg, head of Activision’s platform strategy and partner relations, prepared

## Apple’s AirPods Pro just got much better — no matter what port is on the case
 - [https://www.theverge.com/23878402/apple-airpods-pro-usb-c-adaptive-audio-conversation-awareness-test-review](https://www.theverge.com/23878402/apple-airpods-pro-usb-c-adaptive-audio-conversation-awareness-test-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:00:00+00:00

<figure>
      <img alt="Apple’s second-generation AirPods Pro pictured in a side profile photo of a woman’s head." src="https://cdn.vox-cdn.com/thumbor/idUySSZtdgztyjbNL3tL9xCAlME=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660341/226285_AIRPODS_PRO_2_cwelch_0002.0.jpg" />
        <figcaption><em>The new AirPods Pro software update is available starting today.</em> | Photo by Chris Welch / The Verge</figcaption>
    </figure>

  <p id="GoHU7g">Last week, as predicted, Apple announced that the second-generation AirPods Pro would <a href="https://www.theverge.com/2023/9/12/23860305/airpods-pro-usb-c-cases-apple-announced">start shipping with a USB-C charging case</a> instead of one using the company’s Lightning port. But surprisingly, this refresh isn’t strictly about the case: Apple also added dust resistance (on top of the existing water resistance) to the USB-C AirPods Pro. And the company announced that these AirPods Pro — and <em>not</em> the model from l

## Sonos Move 2 review: a slam-dunk sequel
 - [https://www.theverge.com/23877274/sonos-move-2-review](https://www.theverge.com/23877274/sonos-move-2-review)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T13:00:00+00:00

<p>With stereo sound, twice the battery life, and line-in playback, the Move 2 improves upon the original at every turn — unless you need Google Assistant.</p>
  <p>
    <a href="https://www.theverge.com/23877274/sonos-move-2-review">Continue reading&hellip;</a>
  </p>

## Amazon’s fall Prime Day sale is happening October 10th and 11th
 - [https://www.theverge.com/2023/9/18/23878420/amazon-october-prime-day-big-deal-days-fall-dates](https://www.theverge.com/2023/9/18/23878420/amazon-october-prime-day-big-deal-days-fall-dates)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T12:49:39+00:00

<figure>
      <img alt="Illustration showing Amazon’s logo on a black, orange, and tan background, formed by outlines of the letter “A.”" src="https://cdn.vox-cdn.com/thumbor/BOYQzwjDHjl_RDDxxLtmTotVrr4=/0x0:2040x1360/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660272/acastro_STK103__04.0.jpg" />
        <figcaption><em>It’s another sale to convince you to subscribe (or stay subscribed) to Prime.</em> | Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="JYiBKT">We knew <a href="https://www.theverge.com/2023/8/8/23824247/amazon-prime-day-part-2-bigger-and-primer">it was coming</a>, but now we can officially mark our calendars for the next Prime Day sale. Amazon has announced that its fall Prime Day is <a href="https://www.businesswire.com/news/home/20230917651463/en/Shop-Some-of-Amazon">scheduled for October 10th and 11th</a>. Last year’s fall sales event from around the same time was called the Prime Early Access Sale, and this time around, Amazon

## This is how Microsoft reacted to Sony’s PS5 announcement and price hike
 - [https://www.theverge.com/2023/9/18/23878386/microsoft-sony-ps5-playstation-reaction-price-increase-internal-emails](https://www.theverge.com/2023/9/18/23878386/microsoft-sony-ps5-playstation-reaction-price-increase-internal-emails)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T12:45:02+00:00

<figure>
      <img alt="The PlayStation 5 console on a wooden table" src="https://cdn.vox-cdn.com/thumbor/SZADxQ1caRb5943NbP12tHVPjlE=/159x0:1881x1148/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660266/vpavic_4261_20201023_0058.0.jpg" />
        <figcaption>Photo by Vjeran Pavic / The Verge</figcaption>
    </figure>

  <p id="yfNg1X">Microsoft was, as you’d expect, following Sony’s reveal of the PS5 very closely. Sony announced the full PS5 tech specs in March 2020, which prompted an Xbox executive to provide Xbox chief Phil Spencer and Microsoft CEO Satya Nadella with a summary of Sony’s console, internal emails from the <a href="https://www.theverge.com/23768244/ftc-microsoft-activision-blizzard-case-news-announcements"><em>FTC v. Microsoft </em>case</a> reveal. Then, more than two years later, Microsoft also reacted to Sony’s PS5 price increase.	</p>
<p id="Tr6CV0">The emails show Liz Hamren, former head of platform engineering and hardware at Xbox, pointing out the st

## Microsoft is planning to stream PC cloud games, internal emails reveal
 - [https://www.theverge.com/2023/9/18/23878376/microsoft-xbox-cloud-gaming-pc-games-streaming-ftc-documents](https://www.theverge.com/2023/9/18/23878376/microsoft-xbox-cloud-gaming-pc-games-streaming-ftc-documents)
 - RSS feed: https://www.theverge.com/rss/index.xml
 - date published: 2023-09-18T12:38:03+00:00

<figure>
      <img alt="Xbox logo" src="https://cdn.vox-cdn.com/thumbor/ihaxd2RZBlNKbohuiihooNLaz5M=/0x0:3000x2000/1310x873/cdn.vox-cdn.com/uploads/chorus_image/image/72660246/xboxlogo.0.jpg" />
        <figcaption>Illustration by Alex Castro / The Verge</figcaption>
    </figure>

  <p id="lKdDc3">Microsoft has been planning to stream PC games over the cloud, internal emails from the <a href="https://www.theverge.com/23768244/ftc-microsoft-activision-blizzard-case-news-announcements"><em>FTC v. Microsoft</em> case</a> show. Microsoft currently streams games through its Xbox Cloud Gaming service, but it’s limited to Xbox titles as the servers run <a href="https://www.theverge.com/2021/6/10/22527432/microsoft-xcloud-server-xbox-series-x-hardware-upgrade-game-streaming">specialized Xbox Series X chips</a>. Microsoft has been working on leveraging its Azure servers to stream PC games over Xbox Cloud Gaming.</p>
<p id="GQ3q9B">Microsoft CEO Satya Nadella emailed Xbox chief Phil Spencer,

