# Source:It's FOSS News, URL:https://news.itsfoss.com/rss/, language:en-US

## Tagger's New Update Lets You Organize and Tag Your Music Better
 - [https://news.itsfoss.com/tagger-2023-9-release/](https://news.itsfoss.com/tagger-2023-9-release/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-09-18T10:57:50+00:00

Using Tagger to tag your music? Now, it comes with new feature additions and fixes.

## Fedora 39 Features: It's Time To Talk About Them!
 - [https://news.itsfoss.com/fedora-39-features/](https://news.itsfoss.com/fedora-39-features/)
 - RSS feed: https://news.itsfoss.com/rss/
 - date published: 2023-09-18T09:38:28+00:00

Fedora 39 is coming in hot! Learn what's new here before you get it installed.

