# Source:Forbs - innovation, URL:https://www.forbes.com/innovation/feed2, language:en-US

## Google Documents Confirm New Bands For Pixel Watch 2
 - [https://www.forbes.com/sites/ewanspence/2023/09/18/pixel-watch-2-leak-metal-slim-strap-milanese-band-specs-launch-date/](https://www.forbes.com/sites/ewanspence/2023/09/18/pixel-watch-2-leak-metal-slim-strap-milanese-band-specs-launch-date/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T22:04:39+00:00

Google's FCC filings confirm a new addition to the Pixel Watch portfolio.

## IBM Expands Watsonx Platform With Watsonx.data
 - [https://www.forbes.com/sites/moorinsights/2023/09/18/ibm-expands-watsonx-platform-with-watsonxdata/](https://www.forbes.com/sites/moorinsights/2023/09/18/ibm-expands-watsonx-platform-with-watsonxdata/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T22:04:35+00:00

Vice President &amp; Principal Analyst, Enterprise Data Technologies, Robert Kramer analyzes the expansion of IBM's watsonx.data offering.

## Today’s ‘Connections’ Answers And Hints For Tuesday, September 19
 - [https://www.forbes.com/sites/krisholt/2023/09/18/todays-connections-answers-and-hints-for-tuesday-september-19/](https://www.forbes.com/sites/krisholt/2023/09/18/todays-connections-answers-and-hints-for-tuesday-september-19/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T22:00:32+00:00

Looking for some help with today's Connections groups? Some clues and the answers are right here.

## iPhone 15 Pro Max Serious Problem Highlighted By Apple Insider
 - [https://www.forbes.com/sites/davidphelan/2023/09/18/iphone-15-pro-max-serious-problem-highlighted-by-apple-insider-iphone-16-pro-leak/](https://www.forbes.com/sites/davidphelan/2023/09/18/iphone-15-pro-max-serious-problem-highlighted-by-apple-insider-iphone-16-pro-leak/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T21:50:29+00:00

Reliable analyst Ming-Chi Kuo has intriguing news about the next iPhone.

## Collina Strada Takes On AI Fashion At New York Fashion Week SS24
 - [https://www.forbes.com/sites/rosecelestin/2023/09/18/collina-strada-takes-on-ai-fashion-at-new-york-fashion-week-ss24/](https://www.forbes.com/sites/rosecelestin/2023/09/18/collina-strada-takes-on-ai-fashion-at-new-york-fashion-week-ss24/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T21:31:26+00:00

Apart from the new fashion trends unveiled at NYFW SS24, another notable trend that could potentially take the fashion world by storm is AI fashion.

## Motive Claims Superiority In Driver Dashcam Performance, Prompting Side-Eyes From Competitors
 - [https://www.forbes.com/sites/richardbishop1/2023/09/18/motive-claims-superiority-in-driver-dashcam-performance-prompting-side-eyes-from-competitors/](https://www.forbes.com/sites/richardbishop1/2023/09/18/motive-claims-superiority-in-driver-dashcam-performance-prompting-side-eyes-from-competitors/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T21:05:12+00:00

Video telematics have revolutionized trucking operations in recent years.  A new study of system efficacy has created controversy amongst the many dashcam vendors.

## Vocal Learning Skills Linked To Problem Solving Abilities And Brain Size In Birds
 - [https://www.forbes.com/sites/grrlscientist/2023/09/18/vocal-learning-skills-linked-to-problem-solving-abilities-and-brain-size-in-birds/](https://www.forbes.com/sites/grrlscientist/2023/09/18/vocal-learning-skills-linked-to-problem-solving-abilities-and-brain-size-in-birds/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T20:55:36+00:00

Songbirds with the most complex vocal learning abilities were also the best problem solvers and had the largest brains relative to body size.

## AI Startup Writer Raises $100 Million To Take On ChatGPT Enterprise
 - [https://www.forbes.com/sites/rashishrivastava/2023/09/18/ai-startup-writer-raises-100-million-to-take-on-chatgpt-enterprise/](https://www.forbes.com/sites/rashishrivastava/2023/09/18/ai-startup-writer-raises-100-million-to-take-on-chatgpt-enterprise/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T20:08:28+00:00

Firms like Spotify, Uber and Accenture use Writer’s generative AI tools to research, create and analyze content.

## The Future Of Employee Experience: 3 Trends Reshaping The Workplace
 - [https://www.forbes.com/sites/zendesk/2023/09/18/the-future-of-employee-experience-3-trends-reshaping-the-workplace/](https://www.forbes.com/sites/zendesk/2023/09/18/the-future-of-employee-experience-3-trends-reshaping-the-workplace/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:57:33+00:00

These trends not only offer insights into the future of work but also underscore the urgent need for companies to rethink how they perceive and prioritize their people.

## Canadian Ford Autoworkers Near Strike Deadline As UAW Walkout Continues
 - [https://www.forbes.com/sites/edgarsten/2023/09/18/canadian-ford-autoworkers-near-strike-deadline-as-uaw-walkout-continues/](https://www.forbes.com/sites/edgarsten/2023/09/18/canadian-ford-autoworkers-near-strike-deadline-as-uaw-walkout-continues/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:52:08+00:00

Shouts of "traitor, traitor!" came from striking workers on the picket line in front of Ford Motor Company’s Michigan Assembly Plant.

## CRKD Nitro Deck (Switch) Review: A Near-Perfect Handheld Experience
 - [https://www.forbes.com/sites/mattgardner1/2023/09/18/crkd-nitro-deck-switch-review-a-near-perfect-handheld-experience/](https://www.forbes.com/sites/mattgardner1/2023/09/18/crkd-nitro-deck-switch-review-a-near-perfect-handheld-experience/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:27:23+00:00

It took over six years to get what we wanted, but the Nitro Deck may be the ultimate option for handheld Switch gamers.

## 2 Ways ‘Weaponized Incompetence’ Might Be Hurting Your Relationship
 - [https://www.forbes.com/sites/traversmark/2023/09/18/2-ways-weaponized-incompetence-might-be-hurting-your-relationship/](https://www.forbes.com/sites/traversmark/2023/09/18/2-ways-weaponized-incompetence-might-be-hurting-your-relationship/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:17:04+00:00

How do you deal with a partner who pretends to be bad at everything you need them to do?

## Magnifying The Little Stuff With Augmented Microscopes
 - [https://www.forbes.com/sites/johnwerner/2023/09/18/magnifying-the-little-stuff-with-augmented-microscopes/](https://www.forbes.com/sites/johnwerner/2023/09/18/magnifying-the-little-stuff-with-augmented-microscopes/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:09:13+00:00

Part of what's really interesting in thinking about new computational microscopes has to do with ideas popularized many decades ago, in texts like Goethe’s Metamorphos...

## Trust: New Methods For A Confusing World
 - [https://www.forbes.com/sites/johnwerner/2023/09/18/trust-new-methods-for-a-confusing-world/](https://www.forbes.com/sites/johnwerner/2023/09/18/trust-new-methods-for-a-confusing-world/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T19:04:18+00:00

We all know that misinformation and disinformation are going to be big issues on tomorrow's Internet.

## Social Media’s Wild Conspiracy Theory: The Missing F-35 Flew To Cuba
 - [https://www.forbes.com/sites/petersuciu/2023/09/18/social-medias-wild-conspiracy-theory-the-missing-f-35-flew-to-cuba/](https://www.forbes.com/sites/petersuciu/2023/09/18/social-medias-wild-conspiracy-theory-the-missing-f-35-flew-to-cuba/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:58:26+00:00

It is impossible that the aircraft could have flown to a secret Chinese airbase outside of Havana that was built after the Chinese spy balloon crossed the USA

## Now Is A Great Time To Get Into Trail Of Cthulhu
 - [https://www.forbes.com/sites/robwieland/2023/09/18/now-is-a-great-time-to-get-into-trail-of-cthulhu/](https://www.forbes.com/sites/robwieland/2023/09/18/now-is-a-great-time-to-get-into-trail-of-cthulhu/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:53:49+00:00

Thanks to a Humble Bundle running through September 28th, a massive chunk of Trail of Cthulhu is on sale for a great price.

## Tweak Systems! Smarter Sort, Smarter Search, And More
 - [https://www.forbes.com/sites/johnwerner/2023/09/18/tweak-systems-smarter-sort-smarter-search-and-more/](https://www.forbes.com/sites/johnwerner/2023/09/18/tweak-systems-smarter-sort-smarter-search-and-more/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:22:16+00:00

At the beginning of his presentation, Tim Kraska is talking about the challenges of dealing with evolving systems when there’s no automatic doubling of processor power...

## Latest Pixel 8 Pro Leaks Reveal Google’s Exciting Decisions
 - [https://www.forbes.com/sites/ewanspence/2023/09/18/google-pixel-8-pro-leaks-tensor-g3-camera-android-updates/](https://www.forbes.com/sites/ewanspence/2023/09/18/google-pixel-8-pro-leaks-tensor-g3-camera-android-updates/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:17:49+00:00

Google's Pixel 8 Pro is set to redefine what a modern smartphone can deliver.

## AI Watching And Listening: Cross-Sensory Cognition Work
 - [https://www.forbes.com/sites/johnwerner/2023/09/18/ai-watching-and-listening-cross-sensory-cognition-work/](https://www.forbes.com/sites/johnwerner/2023/09/18/ai-watching-and-listening-cross-sensory-cognition-work/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:06:47+00:00

Sometimes we forget how much AI is really doing behind the scenes – but to be reminded, we need to look no further than so much of what came out of Imagination in Acti...

## Get Ready! AI Doctors, Musicians And More From Vinod Khosla
 - [https://www.forbes.com/sites/johnwerner/2023/09/18/get-ready-ai-doctors-musicians-and-more-from-vinod-khosla/](https://www.forbes.com/sites/johnwerner/2023/09/18/get-ready-ai-doctors-musicians-and-more-from-vinod-khosla/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T18:04:47+00:00

A lot of this was related to what we’re going to see in terms of general artificial intelligence and specialized applications in the years to come.

## Why Fighting Cancer In Low Income Countries Helps Progress In Rich Countries, Too
 - [https://www.forbes.com/video/6337374580112/](https://www.forbes.com/video/6337374580112/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T17:46:08+00:00

Cancer should be addressed "as the global health emergency that it is," Dr. Satish Gopal, director of the U.S. National Cancer Institute's Center for global health tells Forbes Editor-at-Large Russell Flannery in an interview.

## Apple iOS 17: The Dazzling All-New iPhone Software Is Here, With Cool Features And Upgrades
 - [https://www.forbes.com/sites/davidphelan/2023/09/18/apple-ios-17-the-dazzling-all-new-iphone-software-is-here-with-cool-features-and-upgrades/](https://www.forbes.com/sites/davidphelan/2023/09/18/apple-ios-17-the-dazzling-all-new-iphone-software-is-here-with-cool-features-and-upgrades/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T17:43:55+00:00

The biggest iPhone update of the year is upon us, with the all-singing, all-dancing big update landing now.

## Dr. Fauci and Colleagues Await AIDS Relief Reauthorization by Congress
 - [https://www.forbes.com/sites/davecampbell/2023/09/18/dr-fauci-and-colleagues-await-aids-relief-reauthorization-by-congress/](https://www.forbes.com/sites/davecampbell/2023/09/18/dr-fauci-and-colleagues-await-aids-relief-reauthorization-by-congress/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T17:41:59+00:00

Continuing PEPFAR will ensure millions of people access to prevention, care, and treatment for HIV/AIDS.

## AI Generated Music With Real Human Fans
 - [https://www.forbes.com/sites/charliefink/2023/09/18/ai-generated-music-with-real-human-fans/](https://www.forbes.com/sites/charliefink/2023/09/18/ai-generated-music-with-real-human-fans/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T17:29:59+00:00

Frostbite Orckings' heavy metal music is created With AI

## Nosy Be's Thriving Whale Shark Population: A Citizen Science Success Story
 - [https://www.forbes.com/sites/melissacristinamarquez/2023/09/18/nosy-bes-thriving-whale-shark-population-a-citizen-science-success-story/](https://www.forbes.com/sites/melissacristinamarquez/2023/09/18/nosy-bes-thriving-whale-shark-population-a-citizen-science-success-story/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T17:20:00+00:00

The project has left a lasting legacy of conservation and appreciation for these remarkable creatures.

## Hey Tech Lady: Promotion Pointers & How To Move Up The Ladder
 - [https://www.forbes.com/sites/katiedelgado/2023/09/18/hey-tech-lady-promotion-pointers--how-to-move-up-the-ladder/](https://www.forbes.com/sites/katiedelgado/2023/09/18/hey-tech-lady-promotion-pointers--how-to-move-up-the-ladder/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T15:45:46+00:00

What are the best steps to follow to move up the ladder? If you're ready for a promotion but are struggling to come up with a plan, read on.

## What Is Progressive Supranuclear Palsy? Lawmaker Calls Her Rare Neurological Disorder ‘Parkinson’s On Steroids.’
 - [https://www.forbes.com/sites/maryroeloffs/2023/09/18/what-is-progressive-supranuclear-palsy-lawmaker-calls-her-rare-neurological-disorder-parkinsons-on-steroids/](https://www.forbes.com/sites/maryroeloffs/2023/09/18/what-is-progressive-supranuclear-palsy-lawmaker-calls-her-rare-neurological-disorder-parkinsons-on-steroids/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T15:35:29+00:00

A representative from Virginia was first diagnosed with Parkinson’s disease, which is much more common and affects patients similarly to supranuclear palsy.

## Take These Active Approaches To Insider Risk
 - [https://www.forbes.com/sites/forrester/2023/09/18/take-these-active-approaches-to-insider-risk/](https://www.forbes.com/sites/forrester/2023/09/18/take-these-active-approaches-to-insider-risk/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T15:18:09+00:00

To turn your insiders into advocates, an active approach is needed to prevent, detect, and respond to insider incidents.

## ‘Marvel’s Avengers’ Is Days Away From Being Deleted From Storefronts Forever
 - [https://www.forbes.com/sites/paultassi/2023/09/18/marvels-avengers-is-days-away-from-being-deleted-from-storefronts-forever/](https://www.forbes.com/sites/paultassi/2023/09/18/marvels-avengers-is-days-away-from-being-deleted-from-storefronts-forever/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T15:07:22+00:00

While I know everyone always cites BioWare’s Anthem as a tragedy of the looter-shooter live genre, I think the more depressing case may be Marvel’s Avengers,

## 5 Reasons Robotics Is The Next Multi-Decade Trend To Watch
 - [https://www.forbes.com/sites/chrissmith1/2023/09/18/5-reasons-robotics-is-the-next-multi-decade-trend-to-watch/](https://www.forbes.com/sites/chrissmith1/2023/09/18/5-reasons-robotics-is-the-next-multi-decade-trend-to-watch/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:37:50+00:00

VCs are often guilty of buying into the hype - Gen AI being the current example. However, robotics is one sector with all the hallmarks of a sustainable long-term trend.

## Apple AirPods Pro With USB-C 1st Review: Familiar Design, New Features
 - [https://www.forbes.com/sites/davidphelan/2023/09/18/apple-airpods-pro-with-usb-c-1st-review-familiar-design-new-features/](https://www.forbes.com/sites/davidphelan/2023/09/18/apple-airpods-pro-with-usb-c-1st-review-familiar-design-new-features/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:33:49+00:00

The second-generation earbuds were only released a year ago.

## Do You Speak Droidish? The Pentagon Is Spending Millions On A Language For Drones
 - [https://www.forbes.com/sites/thomasbrewster/2023/09/18/droidish-ai-drone-swarms-pentagon/](https://www.forbes.com/sites/thomasbrewster/2023/09/18/droidish-ai-drone-swarms-pentagon/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:23:42+00:00

The U.S. military hopes AI drone swarms will be able to work together to carry out offensive missions with little human input. A language called Droidish might be the key.

## Here's How American Employers Are Seeking Affordable Alternatives To Obamacare
 - [https://www.forbes.com/sites/sallypipes/2023/09/18/heres-how-american-employers-are-seeking-affordable-alternatives-to-obamacare/](https://www.forbes.com/sites/sallypipes/2023/09/18/heres-how-american-employers-are-seeking-affordable-alternatives-to-obamacare/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:23:12+00:00

Self-funded health plans are not subject to most of Obamacare's rules and requirements. So employers who self-insure can opt out of the high-cost fully insured market—and create plans that are more affordable.

## ‘Virgin River’ Dethroned In Netflix’s Top 10 List By A New Show
 - [https://www.forbes.com/sites/paultassi/2023/09/18/virgin-river-dethroned-in-netflixs-top-10-list-by-a-new-show/](https://www.forbes.com/sites/paultassi/2023/09/18/virgin-river-dethroned-in-netflixs-top-10-list-by-a-new-show/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:15:39+00:00

Here's what new show has knocked Virgin River off the #1 spot in Netflix's top 10 list.

## The Metaverse: Shaping The Future Of The Internet And Business Through AI Integration
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-metaverse-shaping-the-future-of-the-internet-and-business-through-ai-integration/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-metaverse-shaping-the-future-of-the-internet-and-business-through-ai-integration/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:15:00+00:00

It's more than just an effort to expand the internet; it's a transformative shift in how we perceive and engage with the digital world.

## New Reveal Shows ‘Elder Scrolls 6’ Will Be Xbox Exclusive, Has 2026+ Release Date
 - [https://www.forbes.com/sites/paultassi/2023/09/18/new-reveal-shows-elder-scrolls-6-will-be-xbox-exclusive-has-2026-release-date/](https://www.forbes.com/sites/paultassi/2023/09/18/new-reveal-shows-elder-scrolls-6-will-be-xbox-exclusive-has-2026-release-date/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:00:24+00:00

Another week, another dump of documents from the FTC v. Microsoft case. This time a reveal may have a direct impact on players in both the PlayStation and Xbox ecosystems,

## Are Generative AI Risks Actually Impacting Your Security Posture?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/are-generative-ai-risks-actually-impacting-your-security-posture/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/are-generative-ai-risks-actually-impacting-your-security-posture/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T14:00:00+00:00

GenAI apps are open by default.

## Sidekick—The Browser Built For Work—Raises $4 million
 - [https://www.forbes.com/sites/barrycollins/2023/09/18/sidekick-the-browser-built-for-work-raises-4-million/](https://www.forbes.com/sites/barrycollins/2023/09/18/sidekick-the-browser-built-for-work-raises-4-million/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:59:57+00:00

Sidekick, the distraction-free browser designed to help you get on with your day job, raises $4 million to further drive its growth

## Is AI The Next Shadow IT?
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/is-ai-the-next-shadow-it/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/is-ai-the-next-shadow-it/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:45:00+00:00

Soon, AI will be everywhere—not just in new apps that pop up across your business.

## Starfield’s Eternal New Game Plus Loop Was Not A Good Decision By Bethesda
 - [https://www.forbes.com/sites/paultassi/2023/09/18/starfields-eternal-new-game-plus-loop-was-not-a-good-decision-by-bethesda/](https://www.forbes.com/sites/paultassi/2023/09/18/starfields-eternal-new-game-plus-loop-was-not-a-good-decision-by-bethesda/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:43:07+00:00

While I really love almost everything about Starfield, one thing I disagreed with since the start was the immense focus of not just the structure of the game, but the structure of its main storyline to be fully in service to the concept of New Game Plus.

## ‘Cyberpunk 2077’ Reveals Phantom Liberty Global Release Times
 - [https://www.forbes.com/sites/paultassi/2023/09/18/cyberpunk-2077-reveals-phantom-liberty-global-release-times/](https://www.forbes.com/sites/paultassi/2023/09/18/cyberpunk-2077-reveals-phantom-liberty-global-release-times/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:32:43+00:00

Here are the release times for Cyberpunk 2077: Phantom Liberty on September 26.

## From Idea To A Fair Deal: Inside The Venture Studio
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/from-idea-to-a-fair-deal-inside-the-venture-studio/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/from-idea-to-a-fair-deal-inside-the-venture-studio/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:30:00+00:00

In the ever-evolving entrepreneurship landscape, venture studios have emerged as dynamic innovation hubs, offering a unique and collaborative approach to building successful startups

## Art Historians Join Ecologists To Study Landscapes Of The Past
 - [https://www.forbes.com/sites/evaamsen/2023/09/18/art-historians-join-ecologists-to-study-landscapes-of-the-past/](https://www.forbes.com/sites/evaamsen/2023/09/18/art-historians-join-ecologists-to-study-landscapes-of-the-past/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:16:45+00:00

Ecologists worked with art historians to find out if it’s possible to study landscape changes by looking at art from the nineteenth century.

## How To Make Composable ERP Work For Your Business
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/how-to-make-composable-erp-work-for-your-business/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/how-to-make-composable-erp-work-for-your-business/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:15:00+00:00

As IT departments look to support executives with tech that can keep up with the speed of business change, understanding a composable model can help unlock its benefits.

## Unity Will Change Its Controversial New Pricing, But Has Lost Developer Trust
 - [https://www.forbes.com/sites/paultassi/2023/09/18/unity-will-change-its-controversial-new-pricing-but-has-lost-developer-trust/](https://www.forbes.com/sites/paultassi/2023/09/18/unity-will-change-its-controversial-new-pricing-but-has-lost-developer-trust/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:12:32+00:00

Late on Sunday night, when all good apology tweets are made, Unity posted that it apologizes "for the confusion and angst” regarding its new policy that will charge developers a per-install fee for the use of its game engine.

## Unity Will Change Its Much-Hated New Pricing, But Has Lost Developer Trust
 - [https://www.forbes.com/sites/paultassi/2023/09/18/unity-will-change-its-much-hated-new-pricing-but-has-lost-developer-trust/](https://www.forbes.com/sites/paultassi/2023/09/18/unity-will-change-its-much-hated-new-pricing-but-has-lost-developer-trust/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:12:32+00:00

Late on Sunday night, when all good apology tweets are made, Unity posted that it “apologize for the confusion and angst” regarding its new policy that will charge developers a per-install fee for the use of its game engine.

## The Science Behind Apple’s ‘State Of Mind’ Feature, Explained By A Psychologist
 - [https://www.forbes.com/sites/traversmark/2023/09/18/the-science-behind-apples-state-of-mind-feature-explained-by-a-psychologist/](https://www.forbes.com/sites/traversmark/2023/09/18/the-science-behind-apples-state-of-mind-feature-explained-by-a-psychologist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:07:42+00:00

Armed with iOS 17 and watchOS 10, iPhone 15 and a number of other Apple devices will soon be able to track your mood. Could this set off the next big trend in mental health support?

## Intel CEO Pat Gelsinger Weighs In On This Year’s Innovation 2023 Ahead Of The Conference
 - [https://www.forbes.com/sites/patrickmoorhead/2023/09/18/intel-ceo-pat-gelsinger-weighs-in-on-this-years-innovation-2023-ahead-of-the-conference/](https://www.forbes.com/sites/patrickmoorhead/2023/09/18/intel-ceo-pat-gelsinger-weighs-in-on-this-years-innovation-2023-ahead-of-the-conference/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:06:39+00:00

#1 ranked tech industry analyst Patrick Moorhead met with Intel CEO prior to its big conference, Innovation 2023, to discuss what to expect.

## AI In Clinical Research: Now And Beyond
 - [https://www.forbes.com/sites/greglicholai/2023/09/18/ai-in-clinical-research-now-and-beyond/](https://www.forbes.com/sites/greglicholai/2023/09/18/ai-in-clinical-research-now-and-beyond/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:01:25+00:00

The use of AI in clinical research is progressing and will improve the way drugs are tested

## Intel’s Breakthrough “Glass Substrate” To Massively Boost Processor Performance
 - [https://www.forbes.com/sites/antonyleather/2023/09/18/intels-breakthrough-glass-substrate-to-massively-boost-processor-performance/](https://www.forbes.com/sites/antonyleather/2023/09/18/intels-breakthrough-glass-substrate-to-massively-boost-processor-performance/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:00:36+00:00

Intel has revealed more details on its "breakthrough" glass substrate technology - a new way to manufacture processors that will dramatically boost performance

## The Sonos Move 2 Wireless Speaker Reviewed And Rated
 - [https://www.forbes.com/sites/marksparrow/2023/09/18/the-sonos-move-2-wireless-speaker-reviewed-and-rated/](https://www.forbes.com/sites/marksparrow/2023/09/18/the-sonos-move-2-wireless-speaker-reviewed-and-rated/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:00:16+00:00

This new portable and stereo wireless speaker from Sonos is a clear winner. The Move 2 has a 24 hour battery, is water resistant and sounds stunning.

## Intel’s Glass Substrates Are Essential For Future IC Development
 - [https://www.forbes.com/sites/tiriasresearch/2023/09/18/intels-glass-substrates-are-essential-for-future-ic-development/](https://www.forbes.com/sites/tiriasresearch/2023/09/18/intels-glass-substrates-are-essential-for-future-ic-development/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:00:00+00:00

IC substrates are nothing new, so why would Intel announce them now, after ten years of corporate development and years before using them in products?

## Using AI In Cybersecurity: Exploring The Advantages And Risks
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/using-ai-in-cybersecurity-exploring-the-advantages-and-risks/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/using-ai-in-cybersecurity-exploring-the-advantages-and-risks/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T13:00:00+00:00

Although cybercrime statistics are staggering, organizations fighting cybercrime now have an ally that offers ever-increasing capabilities: artificial intelligence (AI).

## Circular Solutions For Transforming The PET/Polyester Ecosystem
 - [https://www.forbes.com/sites/christophermarquis/2023/09/18/circular-solutions-for-transforming-the-petpolyester-ecosystem/](https://www.forbes.com/sites/christophermarquis/2023/09/18/circular-solutions-for-transforming-the-petpolyester-ecosystem/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:45:00+00:00

Eastman is focused on addressing the world’s plastic waste crisis in the advanced materials industry. A recent report outlines actions needed to transform the PET system.

## The Real Concern Of BEC Attacks In Real Estate
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-real-concern-of-bec-attacks-in-real-estate/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-real-concern-of-bec-attacks-in-real-estate/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:45:00+00:00

More than ever, organizations are paying greater attention to business email compromise attacks.

## Four Tips For Developing Successful MarTech Solutions
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/four-tips-for-developing-successful-martech-solutions/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/four-tips-for-developing-successful-martech-solutions/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:30:00+00:00

Don't pick the technology before you learn enough about your prospective customers and their business needs.

## Instacart Has An Incredible Opportunity To Improve Healthcare
 - [https://www.forbes.com/sites/saibala/2023/09/18/instacart-has-a-significant-opportunity-to-transform-healthcare/](https://www.forbes.com/sites/saibala/2023/09/18/instacart-has-a-significant-opportunity-to-transform-healthcare/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:30:00+00:00

The company has incredible potential in improving food accessibility, nutrition security, and healthcare outcomes.

## The Key To Digital Transformation Is People
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-key-to-digital-transformation-is-people/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-key-to-digital-transformation-is-people/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:15:00+00:00

Ultimately, business leaders can tell their employees to use new technology ad nauseum, but effective change isn’t possible unless teams are guided with a helping hand.

## Foam Bubbles To The Top Of Housing Construction
 - [https://www.forbes.com/sites/jennifercastenson/2023/09/18/foam-bubbles-to-the-top-of-housing-construction/](https://www.forbes.com/sites/jennifercastenson/2023/09/18/foam-bubbles-to-the-top-of-housing-construction/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:03:57+00:00

Expanded polystyrene is a rigid foam material making its way into housing construction and producing sustainable, resilient, affordable homes.

## To Really Impact Healthcare Costs Look Beyond Drug Prices
 - [https://www.forbes.com/sites/johnlamattina/2023/09/18/to-really-impact-healthcare-costs-look-beyond-drug-prices/](https://www.forbes.com/sites/johnlamattina/2023/09/18/to-really-impact-healthcare-costs-look-beyond-drug-prices/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:02:37+00:00

At a time when the opportunities for discovering and developing new medicines is the greatest in our history, we will be doing less. What we really should be doing is investing more in order to generate new medicines thus reducing downstream healthcare costs.

## Toyota Production Malfunction: Just-In-Time For Supply Chain Upgrade
 - [https://www.forbes.com/sites/sap/2023/09/18/toyota-production-malfunction-just-in-time-for-supply-chain-upgrade/](https://www.forbes.com/sites/sap/2023/09/18/toyota-production-malfunction-just-in-time-for-supply-chain-upgrade/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:00:20+00:00

Toyota's recent production malfunction is surprising given its world renowned "just-in-time" (JiT) principle.

## The Evolving Landscape Of Customer Experience
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-evolving-landscape-of-customer-experience/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-evolving-landscape-of-customer-experience/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:00:00+00:00

Businesses need more than mere adaptations; they require transformative strategies.

## The Joint Commission Launches Certification In Sustainability For U.S. Hospitals
 - [https://www.forbes.com/sites/brucejapsen/2023/09/18/the-joint-commission-launches-certification-in-sustainability-at-us-hospitals/](https://www.forbes.com/sites/brucejapsen/2023/09/18/the-joint-commission-launches-certification-in-sustainability-at-us-hospitals/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T12:00:00+00:00

The Joint Commission, accreditor of U.S. healthcare facilities, is rolling out a voluntary certification in sustainability as hospitals look to combat climate change.

## Hurricane Nigel Intensifies Into Category 1—It’s Expected To ‘Rapidly Strengthen’
 - [https://www.forbes.com/sites/roberthart/2023/09/18/hurricane-nigel-intensifies-into-category-1-its-expected-to-rapidly-strengthen/](https://www.forbes.com/sites/roberthart/2023/09/18/hurricane-nigel-intensifies-into-category-1-its-expected-to-rapidly-strengthen/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:59:34+00:00

Nigel could become a major Category 3 hurricane by Tuesday, forecasters predict.

## Minimizing The Impact Of Customers Finding Bugs
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/minimizing-the-impact-of-customers-finding-bugs/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/minimizing-the-impact-of-customers-finding-bugs/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:45:00+00:00

In software development, we can never overlook bad-quality code. Sooner or later, it will come back to bite us in the form of technical debt.

## Healthcare From Above: Challenges And Opportunities Of Medical Drones
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/healthcare-from-above-challenges-and-opportunities-of-medical-drones/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/healthcare-from-above-challenges-and-opportunities-of-medical-drones/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:30:00+00:00

As with any technology that offers such great promise, it’s worth diving into the challenges and opportunities drones present, and that’s exactly what we’re going to do.

## The Economics Of Addressing Climate Change, From Top White House Economist
 - [https://www.forbes.com/sites/joanmichelson2/2023/09/18/the-economics-of-addressing-climate-change-from-a-top-white-house-economist/](https://www.forbes.com/sites/joanmichelson2/2023/09/18/the-economics-of-addressing-climate-change-from-a-top-white-house-economist/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:30:00+00:00

"You have two economic problems going on at the same time,” in addressing climate change, Dr. Heather Boushey explained. Here's how and what Bidenomics does about it.

## Why There Needs To Be More Allyship Among Investors To Diversify Venture Capital
 - [https://www.forbes.com/sites/sarahkocianski/2023/09/18/why-there-needs-to-be-more-allyship-among-investors-to-diversify-venture-capital/](https://www.forbes.com/sites/sarahkocianski/2023/09/18/why-there-needs-to-be-more-allyship-among-investors-to-diversify-venture-capital/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:21:49+00:00

Allyship is becoming more widely understood and adopted in the world of VC — but more needs to be done to ensure funding is going to the best businesses.

## How To Evaluate Generative AI For The Enterprise
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/how-to-evaluate-generative-ai-for-the-enterprise/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/how-to-evaluate-generative-ai-for-the-enterprise/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:15:00+00:00

The availability of large, high-quality public training datasets was instrumental to "how we got here" from an AI perspective.

## Why Growth-Focused Distributors Are Betting Big On Business Networks
 - [https://www.forbes.com/sites/sap/2023/09/18/why-growth-focused-distributors-are-betting-big-on-business-networks/](https://www.forbes.com/sites/sap/2023/09/18/why-growth-focused-distributors-are-betting-big-on-business-networks/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:05:38+00:00

Distributors must take note: It's time to actively shape and define business networks before business partners and competitors do it for them.

## The Importance Of Personalization: A Guide For Leaders
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-importance-of-personalization-a-guide-for-leaders/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/the-importance-of-personalization-a-guide-for-leaders/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T11:00:00+00:00

Remember when the local shop owner would greet every customer by name and know their regular order?

## Adding Venture Debt As A New Strategy By Large Credit Firms And Technology-Focused Growth PE Firms
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/adding-venture-debt-as-a-new-strategy-by-large-credit-firms-and-technology-focused-growth-pe-firms/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/adding-venture-debt-as-a-new-strategy-by-large-credit-firms-and-technology-focused-growth-pe-firms/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:45:00+00:00

Let's look at the potential benefits and risks large credit funds and growth PE firms should understand when adding a venture debt capability to their existing platforms.

## Fixing Concrete & Steel Part Of Short List Of Climate Actions That Will Work
 - [https://www.forbes.com/sites/michaelbarnard/2023/09/18/fixing-concrete--steel-part-of-short-list-of-climate-actions-that-will-work/](https://www.forbes.com/sites/michaelbarnard/2023/09/18/fixing-concrete--steel-part-of-short-list-of-climate-actions-that-will-work/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:30:14+00:00

Concrete and steel are the biggest industrial products that aren’t fossil fuels, and have a massive climate footprint.

## Beyond Algorithms: The AI Era In Investment FinTech
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/beyond-algorithms-the-ai-era-in-investment-fintech/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/beyond-algorithms-the-ai-era-in-investment-fintech/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:30:00+00:00

The ethical ramifications of AI in finance extend beyond just algorithmic biases.

## How AI Is Supercharging Financial Fraud–And Making It Harder To Spot
 - [https://www.forbes.com/sites/jeffkauflin/2023/09/18/how-ai-is-supercharging-financial-fraudand-making-it-harder-to-spot/](https://www.forbes.com/sites/jeffkauflin/2023/09/18/how-ai-is-supercharging-financial-fraudand-making-it-harder-to-spot/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:30:00+00:00

From smoothly written scam texts to bad actors cloning voices and superimposing faces on videos, generative AI is arming fraudsters with powerful new weapons.

## Salesforce Shines Light On Prompt Engineering Trust Layer Advancements That Are The Future Of Generative AI
 - [https://www.forbes.com/sites/lanceeliot/2023/09/18/salesforce-shines-light-on-prompt-engineering-trust-layer-advancements-that-are-the-future-of-generative-ai/](https://www.forbes.com/sites/lanceeliot/2023/09/18/salesforce-shines-light-on-prompt-engineering-trust-layer-advancements-that-are-the-future-of-generative-ai/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:30:00+00:00

Recent Salesforce conference known as Dreamforce unveiled the Einstein 1 Platform that includes an AI trust layer and is representative of the future of generative AI.

## Re-Energizing Your Digital Transformation Initiative With Quick Wins
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/re-energizing-your-digital-transformation-initiative-with-quick-wins/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/re-energizing-your-digital-transformation-initiative-with-quick-wins/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:15:00+00:00

Organizations should assess their digital transformation progress against goals to determine if measures need to be taken to re-energize the initiative.

## In The Age Of AI, Everything Is An API
 - [https://www.forbes.com/sites/forbestechcouncil/2023/09/18/in-the-age-of-ai-everything-is-an-api/](https://www.forbes.com/sites/forbestechcouncil/2023/09/18/in-the-age-of-ai-everything-is-an-api/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T10:00:00+00:00

We stand at the crossroads of a monumental technological paradigm shift. As AI continues to advance, APIs are evolving in parallel to unlock and amplify this potential.

## World’s Largest Arabica Coffee Producer Gos Big To Grow Green
 - [https://www.forbes.com/sites/mariannelehnis/2023/09/18/worlds-largest-arabica-coffee-producer-gos-big-to-grow-green/](https://www.forbes.com/sites/mariannelehnis/2023/09/18/worlds-largest-arabica-coffee-producer-gos-big-to-grow-green/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T09:53:07+00:00

Despite the sector acting on sustainability initiatives, commercial practices still often exploit farmers with only 10% of coffee’s total value staying in the countrie...

## TikTok Hit With €345m Fine For Failing To Protect Children
 - [https://www.forbes.com/sites/emmawoollacott/2023/09/18/tiktok-hit-with-345m-fine-for-failing-to-protect-children/](https://www.forbes.com/sites/emmawoollacott/2023/09/18/tiktok-hit-with-345m-fine-for-failing-to-protect-children/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T09:51:06+00:00

After an investigation lasting two years, TikTok has been fined €345 million for a series of privacy violations relating to the way it handles children's data.

## Europe Needs Small, Cheap Electric Cars To Thwart China
 - [https://www.forbes.com/sites/neilwinton/2023/09/18/europe-needs-small-cheap-electric-cars-to-thwart-china/](https://www.forbes.com/sites/neilwinton/2023/09/18/europe-needs-small-cheap-electric-cars-to-thwart-china/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T09:13:20+00:00

Europe needs truly affordable and small EVs, not expensive behemoths. If it doesn’t wake up soon, its mass-market players will be decimated.

## Price Gap Widens Between Tesla Model 3 And Model Y — Cybertruck Culprit?
 - [https://www.forbes.com/sites/brookecrothers/2023/09/18/price-gap-widens-between-tesla-model-3-and-model-y---cybertruck-culprit/](https://www.forbes.com/sites/brookecrothers/2023/09/18/price-gap-widens-between-tesla-model-3-and-model-y---cybertruck-culprit/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T08:12:05+00:00

Tesla’s Model Y has gotten pricier but the Model 3 more affordable. That’s food for thought for buyers looking to buy an EV in the U.S.

## The 10 Most Important AI Trends For 2024 Everyone Must Be Ready For Now
 - [https://www.forbes.com/sites/bernardmarr/2023/09/18/the-10-most-important-ai-trends-for-2024-everyone-must-be-ready-for-now/](https://www.forbes.com/sites/bernardmarr/2023/09/18/the-10-most-important-ai-trends-for-2024-everyone-must-be-ready-for-now/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T06:34:28+00:00

Dive into the transformative landscape of 2024, where artificial intelligence AI permeates every facet of our lives.

## Gonorrhea: Sexually Transmitted Disease At Record Levels In U.K.
 - [https://www.forbes.com/sites/katherinehignett/2023/09/18/gonorrhea-sexually-transmitted-disease-at-record-levels-in-uk/](https://www.forbes.com/sites/katherinehignett/2023/09/18/gonorrhea-sexually-transmitted-disease-at-record-levels-in-uk/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T04:43:12+00:00

Officials urge members of the public — including college students about to begin their next semester — to use condoms when having casual sex.

## Climate Clashes With Labor: UAW Strike Reveals ESG Problems
 - [https://www.forbes.com/sites/prakashdolsak/2023/09/18/climate-clashes-with-labor-uaw-strike-reveals-esg-problems/](https://www.forbes.com/sites/prakashdolsak/2023/09/18/climate-clashes-with-labor-uaw-strike-reveals-esg-problems/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T04:33:43+00:00

The UAW strike reveals tension between climate goals and union jobs. Just transition is needed in climate-exposed sectors including fossil-fuel producing and using ones.

## Microsoft Brings Oracle Exadata to Azure in Surprise Announcement
 - [https://www.forbes.com/sites/stevemcdowell/2023/09/17/microsoft-brings-oracle-exadata-to-azure-in-surprise-announcement/](https://www.forbes.com/sites/stevemcdowell/2023/09/17/microsoft-brings-oracle-exadata-to-azure-in-surprise-announcement/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T01:04:53+00:00

Oracle and MIcrosoft jointly announce the upcoming availability of Oracle Exadata from within Azure datacenters.

## Auto Workers Change Tactics With New Strike
 - [https://www.forbes.com/sites/billkoenig/2023/09/17/auto-workers-change-tactics-with-new-strike/](https://www.forbes.com/sites/billkoenig/2023/09/17/auto-workers-change-tactics-with-new-strike/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T01:01:18+00:00

This time out, the union under new President Shawn Fain, the UAW didn’t designate a target company.

## Today’s Wordle #821 Hints, Clues And Answer For Monday, September 18th
 - [https://www.forbes.com/sites/erikkain/2023/09/17/todays-wordle-821-hints-clues-and-answer-for-monday-september-18th/](https://www.forbes.com/sites/erikkain/2023/09/17/todays-wordle-821-hints-clues-and-answer-for-monday-september-18th/)
 - RSS feed: https://www.forbes.com/innovation/feed2
 - date published: 2023-09-18T00:30:49+00:00

How to solve today's Wordle. Hints, clues and the daily Wordle answer. Also, play competitive Wordle and learn more about each day's word.

