# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Train strikes 2023: Next dates and the rail services affected
 - [https://www.telegraph.co.uk/business/2023/09/18/train-strike-dates-2023-rail-services-affected-aslef/](https://www.telegraph.co.uk/business/2023/09/18/train-strike-dates-2023-rail-services-affected-aslef/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-09-18T07:10:11+00:00



## Biden's subsidies make investing in UK 'hard to justify' - latest updates
 - [https://www.telegraph.co.uk/business/2023/09/18/ftse-100-markets-live-news-economy-inflation-latest/](https://www.telegraph.co.uk/business/2023/09/18/ftse-100-markets-live-news-economy-inflation-latest/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-09-18T05:54:44+00:00



