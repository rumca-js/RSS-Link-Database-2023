# Source:PowerfulJre, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ, language:en-US

## Ultimate Flushing Challenge - JRE Toons
 - [https://www.youtube.com/watch?v=QErqFqnhUDE](https://www.youtube.com/watch?v=QErqFqnhUDE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzQUP1qoWDoEbmsQxvdjxgQ
 - date published: 2023-09-18T21:49:42+00:00

Another hilarious moment animated by PaulyToon from the JRE MMA Show #142 with Matt Serra, Din Thoms & John Rallo ⁠https://open.spotify.com/episode/322ZqvmHZTp8FJ37OUnflf⁠

