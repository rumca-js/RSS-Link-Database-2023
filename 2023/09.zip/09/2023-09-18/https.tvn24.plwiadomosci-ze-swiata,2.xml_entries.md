# Source:TVN24 Ze świata, URL:https://tvn24.pl/wiadomosci-ze-swiata,2.xml, language:pl-PL

## Najważniejsze informacje gospodarcze w tym tygodniu. Z Polski i ze świata
 - [https://tvn24.pl/biznes/z-kraju/najwazniejsze-informacje-gospodarcze-w-tym-tygodniu-z-polski-i-ze-swiata-7348256?source=rss](https://tvn24.pl/biznes/z-kraju/najwazniejsze-informacje-gospodarcze-w-tym-tygodniu-z-polski-i-ze-swiata-7348256?source=rss)
 - RSS feed: https://tvn24.pl/wiadomosci-ze-swiata,2.xml
 - date published: 2023-09-18T05:40:51+00:00

<img alt="Najważniejsze informacje gospodarcze w tym tygodniu. Z Polski i ze świata" src="https://tvn24.pl/najnowsze/cdn-zdjecie-h581dr-warszawa-7181927/alternates/LANDSCAPE_1280" />
    W najbliższych dniach GUS opublikuje dane makro za sierpień, m.in. o dynamice płac, produkcji przemysłowej i sprzedaży detalicznej. W poniedziałek NBP przedstawi dane o inflacji bazowej, w środę BGK przeprowadzi przetarg sprzedaży obligacji. Na piątek przegląd ratingu Polski zaplanowała agencja Moody's. W tym tygodniu uwaga rynków finansowych skupi się na środowej decyzji amerykańskiej Rezerwy Federalnej.

