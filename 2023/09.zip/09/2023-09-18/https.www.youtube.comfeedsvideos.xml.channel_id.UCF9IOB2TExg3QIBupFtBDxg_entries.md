# Source:Dr. John Campbell, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg, language:en-UK

## D and K2 together
 - [https://www.youtube.com/watch?v=PZYvmZG1v34](https://www.youtube.com/watch?v=PZYvmZG1v34)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T19:02:57+00:00

Link to whole video, https://www.youtube.com/watch?v=0Ken0luasu0

Free download John’s textbooks in high res pdf.
https://drjohncampbell.co.uk

Order my Physiology Notes in hard copy if you live in the UK,
https://www.ebay.co.uk/itm/154973392319?mkcid=16&amp;mkevt=1&amp;mkrid=711-127632-2357-0&amp;ssspo=K6raxMZrQnm&amp;sssrc=2047675&amp;ssuid=&amp;widget_ver=artemis&amp;media=EMAIL

## A common deficiency
 - [https://www.youtube.com/watch?v=zKPAvNy521g](https://www.youtube.com/watch?v=zKPAvNy521g)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T16:44:28+00:00

Link to whole video, https://www.youtube.com/watch?v=0Ken0luasu0

Free download John’s textbooks in high res pdf.
https://drjohncampbell.co.uk

Order my Physiology Notes in hard copy if you live in the UK,
https://www.ebay.co.uk/itm/154973392319?mkcid=16&amp;mkevt=1&amp;mkrid=711-127632-2357-0&amp;ssspo=K6raxMZrQnm&amp;sssrc=2047675&amp;ssuid=&amp;widget_ver=artemis&amp;media=EMAIL

## Vitamin D
 - [https://www.youtube.com/watch?v=Ca4vYfXaM3o](https://www.youtube.com/watch?v=Ca4vYfXaM3o)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T16:44:17+00:00

Link to whole video, https://www.youtube.com/watch?v=0Ken0luasu0

Free download John’s textbooks in high res pdf.
https://drjohncampbell.co.uk

Order my Physiology Notes in hard copy if you live in the UK,
https://www.ebay.co.uk/itm/154973392319?mkcid=16&amp;mkevt=1&amp;mkrid=711-127632-2357-0&amp;ssspo=K6raxMZrQnm&amp;sssrc=2047675&amp;ssuid=&amp;widget_ver=artemis&amp;media=EMAIL

## Selective research
 - [https://www.youtube.com/watch?v=JMbWbsSu3ZE](https://www.youtube.com/watch?v=JMbWbsSu3ZE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T16:44:03+00:00

Link to whole video, https://www.youtube.com/watch?v=0Ken0luasu0

Free download John’s textbooks in high res pdf.
https://drjohncampbell.co.uk

Order my Physiology Notes in hard copy if you live in the UK,
https://www.ebay.co.uk/itm/154973392319?mkcid=16&amp;mkevt=1&amp;mkrid=711-127632-2357-0&amp;ssspo=K6raxMZrQnm&amp;sssrc=2047675&amp;ssuid=&amp;widget_ver=artemis&amp;media=EMAIL

## Activated Vitamin D trial
 - [https://www.youtube.com/watch?v=0Ken0luasu0](https://www.youtube.com/watch?v=0Ken0luasu0)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T16:02:34+00:00

Free download John’s textbooks in high res pdf.
https://drjohncampbell.co.uk

Order my Physiology Notes in hard copy if you live in the UK,
https://www.ebay.co.uk/itm/154973392319?mkcid=16&amp;mkevt=1&amp;mkrid=711-127632-2357-0&amp;ssspo=K6raxMZrQnm&amp;sssrc=2047675&amp;ssuid=&amp;widget_ver=artemis&amp;media=EMAIL

The effect of 1-hydroxy-vitamin D treatment in hospitalized patients with COVID-19: A retrospective study

https://www.sciencedirect.com/science/article/pii/S0261561423002790

Vitamin D deficiency is associated with elevated risk, severity, and mortality

Asthma, tuberculosis, chronic pulmonary obstructive disease (COPD), and viral respiratory infections

Consistent paper 1.

Vitamin D and its therapeutic relevance in pulmonary diseases

https://www.sciencedirect.com/science/article/abs/pii/S0955286320306033?via%3Dihub

Vitamin D essential for several cellular processes, wound healing, immunity inflammation

Studies have displayed strong inter-relations with vit D defic

## Message for men and women
 - [https://www.youtube.com/watch?v=GT3abQIHcHk](https://www.youtube.com/watch?v=GT3abQIHcHk)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCF9IOB2TExg3QIBupFtBDxg
 - date published: 2023-09-18T15:26:10+00:00

@Campbellteaching

