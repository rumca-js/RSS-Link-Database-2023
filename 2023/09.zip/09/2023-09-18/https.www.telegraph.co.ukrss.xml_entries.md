# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Doctors to be forced to work during strikes
 - [https://www.telegraph.co.uk/politics/2023/09/18/doctors-to-be-forced-to-work-during-strikes/](https://www.telegraph.co.uk/politics/2023/09/18/doctors-to-be-forced-to-work-during-strikes/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T21:30:00+00:00



## Naked Cleopatra, promiscuous Romans... Amanda Holden guides us through a 'bonkers' history of sex
 - [https://www.telegraph.co.uk/tv/2023/09/18/sex-a-bonkers-history-sky-review-amanda-holden-dan-jones/](https://www.telegraph.co.uk/tv/2023/09/18/sex-a-bonkers-history-sky-review-amanda-holden-dan-jones/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T21:00:00+00:00



## India may be behind assassination in Canada, Justin Trudeau says
 - [https://www.telegraph.co.uk/world-news/2023/09/18/canada-hardeep-singh-nijjar-killing-india-justin-trudeau/](https://www.telegraph.co.uk/world-news/2023/09/18/canada-hardeep-singh-nijjar-killing-india-justin-trudeau/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T20:22:11+00:00



## Juice, review: Mawaan Rizwan's BBC Three sitcom careers through genres with have-a-go glee
 - [https://www.telegraph.co.uk/tv/2023/09/18/juice-bbc-three-review/](https://www.telegraph.co.uk/tv/2023/09/18/juice-bbc-three-review/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T18:00:00+00:00



## How the 1922 Committee saved the Tories from oblivion
 - [https://www.telegraph.co.uk/books/what-to-read/review-1922-committee-lord-philip-norton/](https://www.telegraph.co.uk/books/what-to-read/review-1922-committee-lord-philip-norton/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T17:00:00+00:00



## An adventure in the wilds of the Amazon – without roughing it
 - [https://www.telegraph.co.uk/travel/cruises/articles/adventure-amazon-peru-without-roughing-it/](https://www.telegraph.co.uk/travel/cruises/articles/adventure-amazon-peru-without-roughing-it/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T16:00:00+00:00



## War crime investigators prepare case against Russia over food attacks
 - [https://www.telegraph.co.uk/global-health/terror-and-security/ukraine-russia-war-latest-food-grain-starvation/](https://www.telegraph.co.uk/global-health/terror-and-security/ukraine-russia-war-latest-food-grain-starvation/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T15:37:47+00:00



## The best family hotels in Greece
 - [https://www.telegraph.co.uk/travel/destinations/europe/greece/articles/the-best-family-friendly-hotels-in-greece/](https://www.telegraph.co.uk/travel/destinations/europe/greece/articles/the-best-family-friendly-hotels-in-greece/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T15:17:00+00:00



## What to consider before you get a new credit card
 - [https://www.telegraph.co.uk/money/banking/credit-cards/what-consider-applying-new-credit-card/](https://www.telegraph.co.uk/money/banking/credit-cards/what-consider-applying-new-credit-card/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T14:24:12+00:00



## Princess of Wales surprised by inflating lifejacket on Royal Navy air base visit
 - [https://www.telegraph.co.uk/royal-family/2023/09/18/princess-of-wales-kate-lifejacket-royal-navy-airbase/](https://www.telegraph.co.uk/royal-family/2023/09/18/princess-of-wales-kate-lifejacket-royal-navy-airbase/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T14:04:29+00:00



## A misfiring novel about masculinity in crisis
 - [https://www.telegraph.co.uk/books/what-to-read/review-how-to-build-boat-elaine-feeney/](https://www.telegraph.co.uk/books/what-to-read/review-how-to-build-boat-elaine-feeney/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T14:00:00+00:00



## Watch Brian Moore pick his 2023 Rugby World Cup winner with our predictor tool
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-2023-predictions-brian-moore-england/](https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-2023-predictions-brian-moore-england/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T12:46:27+00:00



## How Michael Palin’s great-uncle survived Gallipoli – then went to the Somme
 - [https://www.telegraph.co.uk/books/what-to-read/michael-palin-great-uncle-harry-review/](https://www.telegraph.co.uk/books/what-to-read/michael-palin-great-uncle-harry-review/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T12:00:00+00:00



## Watch: Australian fined for surfing with his pet python
 - [https://www.telegraph.co.uk/world-news/2023/09/18/snake-python-surfing-gold-coast-australia-pet-fined-carpet/](https://www.telegraph.co.uk/world-news/2023/09/18/snake-python-surfing-gold-coast-australia-pet-fined-carpet/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T10:09:11+00:00



## Why clean water is crucial to tackling the looming AMR crisis
 - [https://www.telegraph.co.uk/global-health/science-and-disease/amr-superbugs-antibiotics-antimicrobial-resistence-pandemic/](https://www.telegraph.co.uk/global-health/science-and-disease/amr-superbugs-antibiotics-antimicrobial-resistence-pandemic/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T09:48:10+00:00



## England v Samoa, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/england-v-samoa-rugby-world-cup-2023-when-how-watch-tv/](https://www.telegraph.co.uk/rugby-union/2023/09/18/england-v-samoa-rugby-world-cup-2023-when-how-watch-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:53:51+00:00



## Ireland v Scotland, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/ireland-v-scotland-rugby-world-cup-2023-when-how-watch/](https://www.telegraph.co.uk/rugby-union/2023/09/18/ireland-v-scotland-rugby-world-cup-2023-when-how-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:36:17+00:00



## When is the second Republican candidate debate? Start time and how to watch
 - [https://www.telegraph.co.uk/world-news/2023/09/18/republican-candidate-election-debate-date-time-how-watch/](https://www.telegraph.co.uk/world-news/2023/09/18/republican-candidate-election-debate-date-time-how-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:30:09+00:00



## England v Chile, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/england-v-chile-rugby-world-cup-2023-when-how-watch-tv/](https://www.telegraph.co.uk/rugby-union/2023/09/18/england-v-chile-rugby-world-cup-2023-when-how-watch-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:28:08+00:00



## South Africa v Ireland, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/south-africa-v-ireland-rugby-world-cup-2023-when-how-watch/](https://www.telegraph.co.uk/rugby-union/2023/09/18/south-africa-v-ireland-rugby-world-cup-2023-when-how-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:26:13+00:00



## Australia v Fiji, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/australia-v-fiji-rugby-world-cup-2023-when-how-to-watch/](https://www.telegraph.co.uk/rugby-union/2023/09/18/australia-v-fiji-rugby-world-cup-2023-when-how-to-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:25:15+00:00



## Rugby finally has a fantasy World Cup game – here is the cheat sheet you need
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-fantasy-2023-cheat-sheet-tips/](https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-fantasy-2023-cheat-sheet-tips/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T08:05:19+00:00



## A team-by-team guide to the 2023 Rugby World Cup, including coaches and best players
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/world-cup-2023-team-by-team-guide/](https://www.telegraph.co.uk/rugby-union/2023/09/18/world-cup-2023-team-by-team-guide/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T07:25:59+00:00



## What channel is the 2023 Rugby World Cup on today?
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-tv-channel-how-watch-best-commentators/](https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-tv-channel-how-watch-best-commentators/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T07:24:39+00:00



## South Africa’s World Cup 2023 fixtures and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/south-africa-world-cup-2023-fixtures-and-how-to-watch-on-tv/](https://www.telegraph.co.uk/rugby-union/2023/09/18/south-africa-world-cup-2023-fixtures-and-how-to-watch-on-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T07:23:37+00:00



## England’s Rugby World Cup 2023 fixtures, team and route to the final
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/england-rugby-world-cup-2023-fixtures-route-final-tv-watch/](https://www.telegraph.co.uk/rugby-union/2023/09/18/england-rugby-world-cup-2023-fixtures-route-final-tv-watch/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T07:20:32+00:00



## Rugby World Cup 2023: next matches, full schedule and group standings
 - [https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-2023-dates-schedule-how-watch-tv-odds/](https://www.telegraph.co.uk/rugby-union/2023/09/18/rugby-world-cup-2023-dates-schedule-how-watch-tv-odds/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T07:13:49+00:00



## Politics latest news: Starmer pledges 'closer' EU ties if Labour win power
 - [https://www.telegraph.co.uk/politics/2023/09/18/rishi-sunak-news-live-brexit-eu-starmer-labour-latest/](https://www.telegraph.co.uk/politics/2023/09/18/rishi-sunak-news-live-brexit-eu-starmer-labour-latest/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T06:59:46+00:00



## Ukraine-Russia war latest: Ukraine fighting ‘WW1 with drones’, says Zelensky
 - [https://www.telegraph.co.uk/world-news/2023/09/18/ukraine-russia-war-news-putin-bakhmut-drones-live/](https://www.telegraph.co.uk/world-news/2023/09/18/ukraine-russia-war-news-putin-bakhmut-drones-live/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-18T06:43:37+00:00



