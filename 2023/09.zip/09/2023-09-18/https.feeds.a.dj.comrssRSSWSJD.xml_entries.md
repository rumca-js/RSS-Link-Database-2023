# Source:The Wall Street - Tech, URL:https://feeds.a.dj.com/rss/RSSWSJD.xml, language:en-US

## iOS 17 Is Here. Finally, an iPhone Update for People Who Still Like Making Calls.
 - [https://www.wsj.com/articles/url-ios-17-release-new-features-apple-466fd82b?mod=rss_Technology](https://www.wsj.com/articles/url-ios-17-release-new-features-apple-466fd82b?mod=rss_Technology)
 - RSS feed: https://feeds.a.dj.com/rss/RSSWSJD.xml
 - date published: 2023-09-18T17:09:00+00:00

Live voicemail, FaceTime messages, new call screens—Apple wants you to reach out and call someone. Also coming: improved autocorrect and custom stickers.

