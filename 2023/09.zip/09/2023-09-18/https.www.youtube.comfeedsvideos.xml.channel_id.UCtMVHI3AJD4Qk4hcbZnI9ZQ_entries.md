# Source:SomeOrdinaryGamers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ, language:en-US

## Xbox Is Ruining The Video Game Industry...
 - [https://www.youtube.com/watch?v=NkywhsE0v18](https://www.youtube.com/watch?v=NkywhsE0v18)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCtMVHI3AJD4Qk4hcbZnI9ZQ
 - date published: 2023-09-18T22:43:19+00:00

Hello guys and gals, it's me Mutahar again! This time we take a look at what appears to be the topic of preserving our favourite video games. This topic is near and dear to my heart and it saddens me to see Microsoft not treat it with any sincerity despite claiming to do so. Thanks for watching!
Like, Comment and Subscribe for more videos!

Check out the newest Podcast episode: https://youtu.be/pm6sUW26knE

