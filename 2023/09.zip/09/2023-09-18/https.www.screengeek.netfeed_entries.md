# Source:ScreenGeek, URL:https://www.screengeek.net/feed/, language:en-US

## Gina Carano’s Cara Dune Makes Surprising Return
 - [https://www.screengeek.net/2023/09/18/gina-carano-cara-dune-surprising-return/](https://www.screengeek.net/2023/09/18/gina-carano-cara-dune-surprising-return/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T23:26:48+00:00

<p>The Star Wars franchise is flourishing on television with several film projects in development. There have been more than a few hiccups along the way, however, including controversies with The Mandalorian star Gina Carano who played Cara Dune. As fans know, Gina Carano was fired by Disney and blacklisted by Hollywood as a result of [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/gina-carano-cara-dune-surprising-return/" rel="nofollow">Gina Carano&#8217;s Cara Dune Makes Surprising Return</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

## Russell Brand Faces Rape And Sexual Assault Allegations
 - [https://www.screengeek.net/2023/09/18/russell-brand-rape-sexual-assault-allegations/](https://www.screengeek.net/2023/09/18/russell-brand-rape-sexual-assault-allegations/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T22:34:57+00:00

<p>It&#8217;s been confirmed that comedian Russell Brand has been accused of rape, sexual assault, and emotional abuse. The various allegations surfaced in an episode of the documentary series Dispatches as uncovered in an investigation by The Sunday Times and Channel 4. The episode of Dispatches, which is 90 minutes long, aired on September 16, 2023. [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/russell-brand-rape-sexual-assault-allegations/" rel="nofollow">Russell Brand Faces Rape And Sexual Assault Allegations</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

## Netflix To Remove 11 Major Movies From Streaming Service
 - [https://www.screengeek.net/2023/09/18/netflix-removing-11-major-movies/](https://www.screengeek.net/2023/09/18/netflix-removing-11-major-movies/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T20:07:48+00:00

<p>As is the case with streaming, many applications like Hulu and Max will curate their selections by regularly removing movies and shows. Now Netflix has announced which titles they will remove from their service by September 30 &#8211; and it includes as many as 11 major movies. Of course, it&#8217;s likely that these films can [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/netflix-removing-11-major-movies/" rel="nofollow">Netflix To Remove 11 Major Movies From Streaming Service</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

## ‘Aquaman 2’ Scene Reportedly Caused Viewer Walkouts In Test Screenings
 - [https://www.screengeek.net/2023/09/18/aquaman-2-scene-test-screenings-walkout-rumor/](https://www.screengeek.net/2023/09/18/aquaman-2-scene-test-screenings-walkout-rumor/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T16:58:44+00:00

<p>Fans have been wondering how Aquaman and the Lost Kingdom turned out amidst the various reshoots and other such production issues the movie has faced. As such, a new report has surfaced which claims viewers walked out during test screenings for DC&#8216;s Aquaman 2. As noted below, insider @MyTimeToShineH on X claims that this report [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/aquaman-2-scene-test-screenings-walkout-rumor/" rel="nofollow">&#8216;Aquaman 2&#8217; Scene Reportedly Caused Viewer Walkouts In Test Screenings</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

## ‘Brightburn’ Sequel Is Currently In Development
 - [https://www.screengeek.net/2023/09/18/brightburn-sequel-in-development/](https://www.screengeek.net/2023/09/18/brightburn-sequel-in-development/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T15:59:24+00:00

<p>Brightburn was released in 2019, and now several years later, it&#8217;s finally been confirmed that a sequel is in development. Many fans have been hoping that the story would be continued. Especially in a world where superhero movies reign supreme thanks to the likes of Marvel. Now, as shared via Deadline, the producing team behind [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/brightburn-sequel-in-development/" rel="nofollow">&#8216;Brightburn&#8217; Sequel Is Currently In Development</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

## Marvel Making A Big Change To Disney Plus Movie
 - [https://www.screengeek.net/2023/09/18/marvel-disney-plus-movie-big-change/](https://www.screengeek.net/2023/09/18/marvel-disney-plus-movie-big-change/)
 - RSS feed: https://www.screengeek.net/feed/
 - date published: 2023-09-18T15:25:29+00:00

<p>The Marvel Cinematic Universe has been expanded in some amazing ways thanks to Disney Plus. In fact, the streaming service allowed the release of Werewolf By Night, a critically acclaimed adaptation in the vein of classic Universal horror movies. As such, it was initially released in black-and-white, though Marvel is now making a major change [&#8230;]</p>
<p>The post <a href="https://www.screengeek.net/2023/09/18/marvel-disney-plus-movie-big-change/" rel="nofollow">Marvel Making A Big Change To Disney Plus Movie</a> appeared first on <a href="https://www.screengeek.net" rel="nofollow">ScreenGeek</a>.</p>

