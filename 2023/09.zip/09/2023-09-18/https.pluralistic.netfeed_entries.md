# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Biden should support the UAW (18 Sept 2023)
 - [https://pluralistic.net/2023/09/18/co-determination/](https://pluralistic.net/2023/09/18/co-determination/)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2023-09-18T16:11:41+00:00

Today's links Biden should support the UAW: Get the Democratic Party's mind right. Hey look at this: Delights to delectate. This day in history: 2003, 2008, 2013, 2018 Colophon: Recent publications, upcoming/recent appearances, current writing projects, current reading Biden should support the UAW (permalink) The UAW are on strike against the Big Three automakers. Biden should be roaring his full-throated support for the strike. Doing so would be both just and shrewd. But instead, the White House is waffling&#8230;and if recent history is any indication, they might actually come out against the strike. The Biden administration is a mix of appointees from the party's left Sanders/Warren wing, and the corporatist, "Third Way" wing associated with Clinton and Obama, which has been ascendant since the Reagan years. The neoliberal wing presided over NAFTA, the foreclosure crisis, charter schools and the bailout for the bankers &#8211; but not the people. They voted for the war in Iraq, su

