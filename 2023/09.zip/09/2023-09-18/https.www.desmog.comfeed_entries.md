# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Tens of Thousands March to the UN, Declaring a Climate Emergency
 - [https://www.desmog.com/2023/09/18/thousands-march-in-new-york-city-to-un-to-fight-fossil-fuels-climate-emergency/](https://www.desmog.com/2023/09/18/thousands-march-in-new-york-city-to-un-to-fight-fossil-fuels-climate-emergency/)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-09-18T21:34:22+00:00

<p>Climate activists marched in New York City on Sunday to demand that world leaders curb new oil and gas drilling.&#160; The March to End Fossil Fuels was the first major climate march since the start of the COVID-19 pandemic. It brought tens of thousands, young and old, from as far away as Alaska and the [&#8230;]</p>
<p>The post <a href="https://www.desmog.com/2023/09/18/thousands-march-in-new-york-city-to-un-to-fight-fossil-fuels-climate-emergency/" rel="nofollow">Tens of Thousands March to the UN, Declaring a Climate Emergency</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

