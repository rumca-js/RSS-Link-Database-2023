# Source:Ryan Long, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCzKFvBRI6VT3jYJq6a820nA, language:en-US

## Fat-phobic Ballet School
 - [https://www.youtube.com/watch?v=MZq-LqOuL8M](https://www.youtube.com/watch?v=MZq-LqOuL8M)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzKFvBRI6VT3jYJq6a820nA
 - date published: 2023-09-18T23:07:23+00:00

ON TOUR: Tacoma: Oct 6/7, Vancouver: Oct 8 Kansas City: Oct 18, Omaha, NE: Oct 19, Edmonton: Nov 2-4, Los Angeles: Nov 10, Irvine: Nov 12, San Jose: Nov 15, Phoenix: Dec 8/9, Toronto: Dec 15 tickets PerrysBurg: Feb 6, 
Columbus: Feb 7, 
Liberty: Feb 8, 
Dallas: March 1/2, 
Baltimore: March 15-16
Winnipeg: April 4-6
San Diego: April 19/20
ryanlongcomedy.com #funny #funnyshorts

## Do The Racist Accent
 - [https://www.youtube.com/watch?v=GYBDvyuLk6I](https://www.youtube.com/watch?v=GYBDvyuLk6I)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCzKFvBRI6VT3jYJq6a820nA
 - date published: 2023-09-18T17:21:20+00:00

ON TOUR: New York, Tacoma, Vancouver, Kansas City, Omaha, Edmonton, Lost Angeles, Irvine, San Jose, Phoenix, Toronto, Toledo, Columbus, Liberty, Dallas, Baltimore, Winnipeg, La Jolla, http://ryanlongcomedy.com
MY PODCAST - THE BOYSCAST: http://youtube.com/theboyscast
Support me at http://patreon.com/theboyscast 
FELLAS FELLAS MERCH: http://ryanlongstore.com
TOUR DATES: http://ryanlongcomedy.com
MY VLOG CHANNEL: http://youtube.com/ryanlongpremium
MY PODCAST AUDIO: https://podcasts.apple.com/us/podcast/the-boyscast-with-ryan-long/id1498829489
Instagram: @ryanlongcomedy
Twitter: @ryanlongcomedy
Facebook.com/ryanlongcomedy
tiktok @ryanlongcomedy

