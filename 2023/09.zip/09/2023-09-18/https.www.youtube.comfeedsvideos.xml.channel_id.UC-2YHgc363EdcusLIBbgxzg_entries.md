# Source:Joe Scott, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg, language:en-US

## There Were No Tumbleweeds In The Old West
 - [https://www.youtube.com/watch?v=xh7WjmNM9oE](https://www.youtube.com/watch?v=xh7WjmNM9oE)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC-2YHgc363EdcusLIBbgxzg
 - date published: 2023-09-18T13:17:27+00:00

Visit http://www.brilliant.org/answerswithjoe to start learning STEM for free, and the first 200 people will get 20% off their annual premium subscription.

Perhaps no other plant is as synonymous with the American West as the tumbleweed. But they’re surprisingly new to North America, in fact, they’re an invasive species that didn’t show up until the very end of the “Old West” period. And they’ve become quite a problem over the years. Today we’re looking at the tumbleweed, how it came from the steppes of Russia to become an icon of the American West.

Want to support the channel? Here's how:

Patreon: http://www.patreon.com/answerswithjoe
Channel Memberships: https://www.youtube.com/channel/UC-2YHgc363EdcusLIBbgxzg/join
T-Shirts & Merch: http://www.answerswithjoe.com/store

Check out my 2nd channel, Joe Scott TMI:
https://www.youtube.com/channel/UCqi721JsXlf0wq3Z_cNA_Ew

And my podcast channel, Conversations With Joe:
https://www.youtube.com/channel/UCJzc7TiJ2nnuyJkUpOZ8RKA

You can 

