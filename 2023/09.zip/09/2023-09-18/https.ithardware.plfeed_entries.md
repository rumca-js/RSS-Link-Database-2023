# Source:IT hardware PL, URL:https://ithardware.pl/feed, language:pl-PL

## Kiedy next-genowy Xbox? Ujawniono potencjalny rok premiery
 - [https://ithardware.pl/aktualnosci/kiedy_next_genowy_xbox_ujawniono_potencjalny_rok_premiery-29324.html](https://ithardware.pl/aktualnosci/kiedy_next_genowy_xbox_ujawniono_potencjalny_rok_premiery-29324.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T21:45:00+00:00

<img src="https://ithardware.pl/artykuly/min/29324_1.jpg" />            Obecna generacja konsol jest z nami trzy lata i nadal nie dostaliśmy lepszych wersji PlayStation 5 oraz Xbox Series X. W pierwszym przypadku podobno trwają prace nad modelem PS5 Pro, natomiast Microsoft nie widzi sensu, by na ten moment myśleć nad...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/kiedy_next_genowy_xbox_ujawniono_potencjalny_rok_premiery-29324.html">https://ithardware.pl/aktualnosci/kiedy_next_genowy_xbox_ujawniono_potencjalny_rok_premiery-29324.html</a></p>

## TikTok nakazuje powrót do biur. Pracownicy będą monitorowani
 - [https://ithardware.pl/aktualnosci/tiktok_nakazuje_powrot_do_biur_pracownicy_beda_monitorowani-29322.html](https://ithardware.pl/aktualnosci/tiktok_nakazuje_powrot_do_biur_pracownicy_beda_monitorowani-29322.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T19:50:20+00:00

<img src="https://ithardware.pl/artykuly/min/29322_1.jpg" />            Powroty do biur po długim okresie pracy zdalnej, to nie jest przyjemny temat dla pracownik&oacute;w. Niedawno IBM zaczęło wzywać do powrotu do biur, a teraz na podobny ruch zdecydował się TikTok. Chiński gigant zamierza jednak dodatkowo...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/tiktok_nakazuje_powrot_do_biur_pracownicy_beda_monitorowani-29322.html">https://ithardware.pl/aktualnosci/tiktok_nakazuje_powrot_do_biur_pracownicy_beda_monitorowani-29322.html</a></p>

## PayDay 3 bez Denuvo. Starbreeze rezygnuje z DRM
 - [https://ithardware.pl/aktualnosci/payday_3_bez_denuvo_starbreeze_rezygnuje_z_drm-29321.html](https://ithardware.pl/aktualnosci/payday_3_bez_denuvo_starbreeze_rezygnuje_z_drm-29321.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T19:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/29321_1.jpg" />            Denuvo wzbudziło kontrowersje&nbsp;ze względu na obniżanie wydajności gier. Zazwyczaj deweloperzy&nbsp;rezygnują z narzędzia po wydaniu produkcji lub jej złamaniu, nieczęsto zdarza się, aby DRM usunięto przed debiutem gry, tak jak w tym...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/payday_3_bez_denuvo_starbreeze_rezygnuje_z_drm-29321.html">https://ithardware.pl/aktualnosci/payday_3_bez_denuvo_starbreeze_rezygnuje_z_drm-29321.html</a></p>

## The Elder Scrolls 6 jednak tylko na PC i Xboxie? Tak twierdzi Microsoft
 - [https://ithardware.pl/aktualnosci/the_elder_scrolls_6_jednak_tylko_na_pc_i_xboxie_tak_twierdzi_microsoft-29320.html](https://ithardware.pl/aktualnosci/the_elder_scrolls_6_jednak_tylko_na_pc_i_xboxie_tak_twierdzi_microsoft-29320.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T18:00:00+00:00

<img src="https://ithardware.pl/artykuly/min/29320_1.jpg" />            The Elder Scrolls 6 zmierza na PC i Xboxa, chociaż nie wykluczano powstania wersji r&oacute;wnież na PlayStation 5. Sam szef marki, Xbox nie zaprzeczył, żeby produkcja miała ominąć sprzęt Sony, jednak dokumenty do jakich dotarto zdają się temu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/the_elder_scrolls_6_jednak_tylko_na_pc_i_xboxie_tak_twierdzi_microsoft-29320.html">https://ithardware.pl/aktualnosci/the_elder_scrolls_6_jednak_tylko_na_pc_i_xboxie_tak_twierdzi_microsoft-29320.html</a></p>

## GeForce RTX 5090 - mamy nowe przecieki. Taktowanie bliskie 3,0 GHz?
 - [https://ithardware.pl/aktualnosci/geforce_rtx_5090_mamy_nowe_przecieki_taktowanie_bliskie_3_0_ghz-29319.html](https://ithardware.pl/aktualnosci/geforce_rtx_5090_mamy_nowe_przecieki_taktowanie_bliskie_3_0_ghz-29319.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T17:39:50+00:00

<img src="https://ithardware.pl/artykuly/min/29319_1.jpg" />            W sieci pojawiły się nowe plotki&nbsp;na temat flagowej karty graficznej następnej generacji NVIDII. Pogłoski zdradzają informacje m.in. na temat taktowania boost, przepustowości oraz pamięci cache.

Nowe pogłoski o specyfikacji RTX...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/geforce_rtx_5090_mamy_nowe_przecieki_taktowanie_bliskie_3_0_ghz-29319.html">https://ithardware.pl/aktualnosci/geforce_rtx_5090_mamy_nowe_przecieki_taktowanie_bliskie_3_0_ghz-29319.html</a></p>

## Oto nowy wyciskacz siódmych potów dla kart graficznych. Nadchodzi FurMark 2.0
 - [https://ithardware.pl/aktualnosci/oto_nowy_wyciskacz_siodmych_potow_dla_kart_graficznych_nadchodzi_furmark_2_0-29317.html](https://ithardware.pl/aktualnosci/oto_nowy_wyciskacz_siodmych_potow_dla_kart_graficznych_nadchodzi_furmark_2_0-29317.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T16:23:40+00:00

<img src="https://ithardware.pl/artykuly/min/29317_1.jpg" />            Narzędzi do sprawdzania stabilności, temperatur i kultury pracy kart graficznych jest całkiem sporo. Mimo to, wśr&oacute;d tej grupy można wyr&oacute;żnić bardziej popularne programy. Jeden z nich, FurMark, doczeka się niedługo kolejnej...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oto_nowy_wyciskacz_siodmych_potow_dla_kart_graficznych_nadchodzi_furmark_2_0-29317.html">https://ithardware.pl/aktualnosci/oto_nowy_wyciskacz_siodmych_potow_dla_kart_graficznych_nadchodzi_furmark_2_0-29317.html</a></p>

## Unity przeprasza za zamieszanie wywołane opłatą za silnik i zapowiada zmiany
 - [https://ithardware.pl/aktualnosci/unity_przeprasza_za_zamieszanie_wywolane_oplata_za_silnik_i_zapowiada_zmiany-29318.html](https://ithardware.pl/aktualnosci/unity_przeprasza_za_zamieszanie_wywolane_oplata_za_silnik_i_zapowiada_zmiany-29318.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T15:30:00+00:00

<img src="https://ithardware.pl/artykuly/min/29318_1.jpg" />            Firma Unity odpowiadająca za silnik o tej samej nazwie wzbudziła ostatnio duże kontrowersje za sprawą opłaty za korzystanie z silnika przez określonych deweloper&oacute;w gier. W branży gamingowej zawrzało, a część tw&oacute;rc&oacute;w...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/unity_przeprasza_za_zamieszanie_wywolane_oplata_za_silnik_i_zapowiada_zmiany-29318.html">https://ithardware.pl/aktualnosci/unity_przeprasza_za_zamieszanie_wywolane_oplata_za_silnik_i_zapowiada_zmiany-29318.html</a></p>

## Dziś zadebiutuje iOS 17. O której godzinie pojawi się aktualizacja?
 - [https://ithardware.pl/aktualnosci/dzis_zadebiutuje_ios_17_o_ktorej_godzinie_pojawi_sie_aktualizacja-29316.html](https://ithardware.pl/aktualnosci/dzis_zadebiutuje_ios_17_o_ktorej_godzinie_pojawi_sie_aktualizacja-29316.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T14:00:50+00:00

<img src="https://ithardware.pl/artykuly/min/29316_1.jpg" />            Dziś, blisko tydzień po konferencji Apple, wszystkie wspierane iPhony dostaną aktualizację do nowej wersji systemu. Patrząc na dotychczasowe działania Apple, iOS&nbsp;17 powinien być dostępny do pobrania pod wiecz&oacute;r. Już teraz możemy...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/dzis_zadebiutuje_ios_17_o_ktorej_godzinie_pojawi_sie_aktualizacja-29316.html">https://ithardware.pl/aktualnosci/dzis_zadebiutuje_ios_17_o_ktorej_godzinie_pojawi_sie_aktualizacja-29316.html</a></p>

## Test i recenzja Samsung Galaxy Z Fold 5. Najwyższy czas na zmiany
 - [https://ithardware.pl/testyirecenzje/test_i_recenzja_samsung_galaxy_z_fold_5_najwyzszy_czas_na_zmiany-29309.html](https://ithardware.pl/testyirecenzje/test_i_recenzja_samsung_galaxy_z_fold_5_najwyzszy_czas_na_zmiany-29309.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T13:29:50+00:00

<img src="https://ithardware.pl/artykuly/min/29309_1.jpg" />            Czas na zakończenie trylogii składanych smartfon&oacute;w z elastycznymi wyświetlaczami, po motoroli razr 40 Ultra i Samsungu Galaxy Z Flip 5 biorę na warsztat Samsunga Galaxy Z Fold 5. Nie ukrywam, że nie mogłam się doczekać tych test&oacute;w,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/testyirecenzje/test_i_recenzja_samsung_galaxy_z_fold_5_najwyzszy_czas_na_zmiany-29309.html">https://ithardware.pl/testyirecenzje/test_i_recenzja_samsung_galaxy_z_fold_5_najwyzszy_czas_na_zmiany-29309.html</a></p>

## ASUS wypuszcza tańszą wersję konsoli ROG Ally
 - [https://ithardware.pl/aktualnosci/asus_wypuszcza_tansza_wersje_konsoli_rog_ally-29314.html](https://ithardware.pl/aktualnosci/asus_wypuszcza_tansza_wersje_konsoli_rog_ally-29314.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T11:57:30+00:00

<img src="https://ithardware.pl/artykuly/min/29314_1.jpg" />            ASUS przedstawił tańszą wersję konsoli ROG Ally. W parze z obniżką ceny idą r&oacute;wnież cięcia w specyfikacji. Bardziej przystępny cenowo model wyposażony został w podstawową wersję chipu. Zamiast Ryzena Z1 Extreme na pokładzie znajduje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asus_wypuszcza_tansza_wersje_konsoli_rog_ally-29314.html">https://ithardware.pl/aktualnosci/asus_wypuszcza_tansza_wersje_konsoli_rog_ally-29314.html</a></p>

## Huawei: Chiny muszą korzystać z lokalnych chipów, nawet jeśli są na poziomie "podstawówki"
 - [https://ithardware.pl/aktualnosci/huawei_chiny_musza_korzystac_z_lokalnych_chipow_nawet_jesli_sa_na_poziomie_podstawowki-29315.html](https://ithardware.pl/aktualnosci/huawei_chiny_musza_korzystac_z_lokalnych_chipow_nawet_jesli_sa_na_poziomie_podstawowki-29315.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T11:39:50+00:00

<img src="https://ithardware.pl/artykuly/min/29315_1.jpg" />            Prezes Huawei, Xu Zhijun, podkreślił kluczową rolę stosowania chip&oacute;w produkowanych w kraju, nawet jeśli ich wydajność pozostaje w tyle za zagranicznymi odpowiednikami.

Mimo że chińskie chipy niekoniecznie dor&oacute;wnują...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/huawei_chiny_musza_korzystac_z_lokalnych_chipow_nawet_jesli_sa_na_poziomie_podstawowki-29315.html">https://ithardware.pl/aktualnosci/huawei_chiny_musza_korzystac_z_lokalnych_chipow_nawet_jesli_sa_na_poziomie_podstawowki-29315.html</a></p>

## Odkurzacze Roborock w atrakcyjnej cenie. Na liście topowy S7 Max Ultra!
 - [https://ithardware.pl/aktualnosci/odkurzacze_roborock_w_atrakcyjnej_cenie_na_liscie_topowy_s7_max_ultra-29313.html](https://ithardware.pl/aktualnosci/odkurzacze_roborock_w_atrakcyjnej_cenie_na_liscie_topowy_s7_max_ultra-29313.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T11:11:20+00:00

<img src="https://ithardware.pl/artykuly/min/29313_1.jpg" />            Do 22 września potrwa promocja na odkurzacze Roborock, a dokładnie modele S8, Dyad Pro oraz flagowy model poprzedniej generacji, kt&oacute;ry polecaliśmy w naszym rankingu robot&oacute;w sprzątających, czyli S7 MAX...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/odkurzacze_roborock_w_atrakcyjnej_cenie_na_liscie_topowy_s7_max_ultra-29313.html">https://ithardware.pl/aktualnosci/odkurzacze_roborock_w_atrakcyjnej_cenie_na_liscie_topowy_s7_max_ultra-29313.html</a></p>

## Ryzen Threadripper 7985WX - niezapowiedziany procesor AMD już wystawiony na sprzedaż
 - [https://ithardware.pl/aktualnosci/ryzen_threadripper_7985wx_niezapowiedziany_procesor_amd_juz_wystawiony_na_sprzedaz-29307.html](https://ithardware.pl/aktualnosci/ryzen_threadripper_7985wx_niezapowiedziany_procesor_amd_juz_wystawiony_na_sprzedaz-29307.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T11:03:01+00:00

<img src="https://ithardware.pl/artykuly/min/29307_1.jpg" />            Znany specjalista od wyciek&oacute;w @YuuKi_AnS opublikował zdjęcie rzekomego procesora AMD Ryzen Threadripper Pro 7985WX w formacie pod gniazdo SP6. Chociaż ten chip nie został jeszcze wprowadzony na rynek (ani nawet oficjalnie ogłoszony), to ktoś...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/ryzen_threadripper_7985wx_niezapowiedziany_procesor_amd_juz_wystawiony_na_sprzedaz-29307.html">https://ithardware.pl/aktualnosci/ryzen_threadripper_7985wx_niezapowiedziany_procesor_amd_juz_wystawiony_na_sprzedaz-29307.html</a></p>

## Rdzenie Tensor to nie ściema. Grafiki GeForce RTX rzeczywiście korzystają z ich możliwości
 - [https://ithardware.pl/aktualnosci/rdzenie_tensor_to_nie_sciema_grafiki_geforce_rtx_rzeczywiscie_korzystaja_z_ich_mozliwosci-29306.html](https://ithardware.pl/aktualnosci/rdzenie_tensor_to_nie_sciema_grafiki_geforce_rtx_rzeczywiscie_korzystaja_z_ich_mozliwosci-29306.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T10:30:01+00:00

<img src="https://ithardware.pl/artykuly/min/29306_1.jpg" />            Odkąd NVIDIA zaprezentowała DLSS, technologię skalowania opartą na sztucznej inteligencji, dostępną wyłącznie dla kart graficznych GeForce RTX, w sieci toczy się dyskusja na temat tego, czy włączenie DLSS wymaga specjalistycznego sprzętu...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/rdzenie_tensor_to_nie_sciema_grafiki_geforce_rtx_rzeczywiscie_korzystaja_z_ich_mozliwosci-29306.html">https://ithardware.pl/aktualnosci/rdzenie_tensor_to_nie_sciema_grafiki_geforce_rtx_rzeczywiscie_korzystaja_z_ich_mozliwosci-29306.html</a></p>

## Asus pozywa Samsunga. Poszło o smartfony
 - [https://ithardware.pl/aktualnosci/asus_pozywa_samsunga_poszlo_o_smartfony-29312.html](https://ithardware.pl/aktualnosci/asus_pozywa_samsunga_poszlo_o_smartfony-29312.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T09:59:30+00:00

<img src="https://ithardware.pl/artykuly/min/29312_1.jpg" />            Asus szykuje się&nbsp;do sądowej batalii z Samsungiem, oskarżając go o naruszenie swoich patent&oacute;w z zakresu komunikacji bezprzewodowej.

Samsung nie reagował na zgłoszenia Asusa, więc sprawa trafiła do sądu.

W ramach tego sporu Asus...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/asus_pozywa_samsunga_poszlo_o_smartfony-29312.html">https://ithardware.pl/aktualnosci/asus_pozywa_samsunga_poszlo_o_smartfony-29312.html</a></p>

## Oppo prezentuje A2 Pro i startuje z programem darmowej wymiany baterii
 - [https://ithardware.pl/aktualnosci/oppo_prezentuje_a2_pro_i_startuje_z_programem_darmowej_wymiany_baterii-29305.html](https://ithardware.pl/aktualnosci/oppo_prezentuje_a2_pro_i_startuje_z_programem_darmowej_wymiany_baterii-29305.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T09:17:01+00:00

<img src="https://ithardware.pl/artykuly/min/29305_1.jpg" />            Oppo zaprezentowało w Chinach sw&oacute;j najnowszy smartfon z serii A, czyli A2 Pro. Co ciekawe, w przypadku tego modelu producent wystartował z ciekawym programem darmowej wymiany baterii.&nbsp;

Darmowa wymiana baterii przez 4 lata

Oppo A2 Pro...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/oppo_prezentuje_a2_pro_i_startuje_z_programem_darmowej_wymiany_baterii-29305.html">https://ithardware.pl/aktualnosci/oppo_prezentuje_a2_pro_i_startuje_z_programem_darmowej_wymiany_baterii-29305.html</a></p>

## Najbardziej opłacalny dysk SSD w świetnej promocji! Trzeba się spieszyć
 - [https://ithardware.pl/aktualnosci/najbardziej_oplacalny_dysk_ssd_w_swietnej_promocji_trzeba_sie_spieszyc-29311.html](https://ithardware.pl/aktualnosci/najbardziej_oplacalny_dysk_ssd_w_swietnej_promocji_trzeba_sie_spieszyc-29311.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T08:49:30+00:00

<img src="https://ithardware.pl/artykuly/min/29311_1.jpg" />            Dysk, kt&oacute;ry kosztował 839 zł teraz kosztuje 269 zł! To prawdziwa okazja zważywszy na to, że m&oacute;wimy o jednym z lepszych aktualnie dostępnych na rynku, a dokładnie o Kingstonie KC3000.

Dyski SSD i pamięci RAM to aktualnie...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/najbardziej_oplacalny_dysk_ssd_w_swietnej_promocji_trzeba_sie_spieszyc-29311.html">https://ithardware.pl/aktualnosci/najbardziej_oplacalny_dysk_ssd_w_swietnej_promocji_trzeba_sie_spieszyc-29311.html</a></p>

## Miał być hit, tymczasem studio zwalnia blisko połowę załogi
 - [https://ithardware.pl/aktualnosci/mial_byc_hit_tymczasem_studio_zwalnia_blisko_polowe_zalogi-29304.html](https://ithardware.pl/aktualnosci/mial_byc_hit_tymczasem_studio_zwalnia_blisko_polowe_zalogi-29304.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T08:35:01+00:00

<img src="https://ithardware.pl/artykuly/min/29304_1.jpg" />            Ascendant Studios, tw&oacute;rcy strzelanki pierwszoosobowej, w kt&oacute;rej zamiast strzelać z pistolet&oacute;w, wykorzystujemy magię, czyli Immortals of Aveum, zwalnia prawie połowę swojego zespołu zaledwie kilka tygodni po wydaniu gry. Dyrektor...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/mial_byc_hit_tymczasem_studio_zwalnia_blisko_polowe_zalogi-29304.html">https://ithardware.pl/aktualnosci/mial_byc_hit_tymczasem_studio_zwalnia_blisko_polowe_zalogi-29304.html</a></p>

## NVIDIA Blackwell GB100 - świeże przecieki na temat GPU nowej generacji
 - [https://ithardware.pl/aktualnosci/nvidia_blackwell_gb100_swieze_przecieki_na_temat_gpu_nowej_generacji-29308.html](https://ithardware.pl/aktualnosci/nvidia_blackwell_gb100_swieze_przecieki_na_temat_gpu_nowej_generacji-29308.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T07:53:00+00:00

<img src="https://ithardware.pl/artykuly/min/29308_1.jpg" />            Jak podaje Kopite7kimi, układy graficzne nowej generacji od NVIDII o nazwie Blackwell GB100 mają w pełni wykorzystywać chipletową budowę.&nbsp;

GB100 (Blackwell) - nowe GPU dla centr&oacute;w danych

Według najnowszej plotki Blackwell GB100...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/nvidia_blackwell_gb100_swieze_przecieki_na_temat_gpu_nowej_generacji-29308.html">https://ithardware.pl/aktualnosci/nvidia_blackwell_gb100_swieze_przecieki_na_temat_gpu_nowej_generacji-29308.html</a></p>

## Wrześniowa promocja w Geekbuying. Zgarnij sprzęt elektroniczny w super promocjach!
 - [https://ithardware.pl/aktualnosci/wrzesniowa_promocja_w_geekbuying_zgarnij_sprzet_elektroniczny_w_super_promocjach-29279.html](https://ithardware.pl/aktualnosci/wrzesniowa_promocja_w_geekbuying_zgarnij_sprzet_elektroniczny_w_super_promocjach-29279.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T07:27:10+00:00

<img src="https://ithardware.pl/artykuly/min/29279_1.jpg" />            W sklepie Geekbuying aktualnie trwa świetna promocja pod nazwą SUPER WRZESIEŃ, w kt&oacute;rej zgarnąć można przeceniony sprzęt. Jest to akcja zakrojona na szeroką skalę. Każdy znajdzie coś dla siebie!

Promocja potrwa od... wczoraj? Tak,...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/wrzesniowa_promocja_w_geekbuying_zgarnij_sprzet_elektroniczny_w_super_promocjach-29279.html">https://ithardware.pl/aktualnosci/wrzesniowa_promocja_w_geekbuying_zgarnij_sprzet_elektroniczny_w_super_promocjach-29279.html</a></p>

## Starfield działa lepiej na kartach AMD, bo te mają architektoniczną przewagę
 - [https://ithardware.pl/aktualnosci/starfield_dziala_lepiej_na_kartach_amd_bo_te_maja_architektoniczna_przewage-29303.html](https://ithardware.pl/aktualnosci/starfield_dziala_lepiej_na_kartach_amd_bo_te_maja_architektoniczna_przewage-29303.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T07:15:10+00:00

<img src="https://ithardware.pl/artykuly/min/29303_1.jpg" />            Jak mogliście dowiedzieć się z naszego testu, Starfield mocno faworyzuje karty graficzne AMD, kt&oacute;re w tym tytule wypadają wyraźnie lepiej niż sprzęt NVIDII. Teraz dowiadujemy się, dlaczego tak się dzieje.&nbsp;

Starfield faworyzuje...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/starfield_dziala_lepiej_na_kartach_amd_bo_te_maja_architektoniczna_przewage-29303.html">https://ithardware.pl/aktualnosci/starfield_dziala_lepiej_na_kartach_amd_bo_te_maja_architektoniczna_przewage-29303.html</a></p>

## HBM4 - nowa generacja pamięci do kart graficznych z dwukrotnie większą przepustowością
 - [https://ithardware.pl/aktualnosci/hbm4_nowa_generacja_pamieci_do_kart_graficznych_z_dwukrotnie_wieksza_przepustowoscia-29302.html](https://ithardware.pl/aktualnosci/hbm4_nowa_generacja_pamieci_do_kart_graficznych_z_dwukrotnie_wieksza_przepustowoscia-29302.html)
 - RSS feed: https://ithardware.pl/feed
 - date published: 2023-09-18T06:02:05+00:00

<img src="https://ithardware.pl/artykuly/min/29302_1.jpg" />            Pierwsza iteracja pamięci High-Bandwidth Memory (HBM) była nieco ograniczona i umożliwiała osiągnięcie jedynie prędkości do 128 GB/s na stos. Co więcej, karty graficzne korzystające z pierwszej generacji HBM miały limit 4 GB pamięci ze...
            <p>Pełna wersja strony <a href="https://ithardware.pl/aktualnosci/hbm4_nowa_generacja_pamieci_do_kart_graficznych_z_dwukrotnie_wieksza_przepustowoscia-29302.html">https://ithardware.pl/aktualnosci/hbm4_nowa_generacja_pamieci_do_kart_graficznych_z_dwukrotnie_wieksza_przepustowoscia-29302.html</a></p>

