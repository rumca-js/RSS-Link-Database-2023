# Source:Tracy Durnell, URL:https://tracydurnell.com/feed/, language:en-US

## Generative AI at work
 - [https://tracydurnell.com/2023/09/18/generative-ai-at-work/](https://tracydurnell.com/2023/09/18/generative-ai-at-work/)
 - RSS feed: https://tracydurnell.com/feed/
 - date published: 2023-09-18T22:57:37+00:00

The Bad The DeSantis Campaign Texted Me with a Large Language Model by Alan Johnson + Microsoft Publishes Garbled AI Article Calling Tragically Deceased NBA Player &#8220;Useless&#8221; by Victor Tangermann (Futurism) + The A.V. Club&#8217;s AI-Generated Articles Are Copying Directly From IMDb by Frank Landymore and Jon Christian + The Interesting I&#8217;m much more interested [&#8230;]

## It’s ok if not everyone gets it
 - [https://tracydurnell.com/2023/09/18/its-ok-if-not-everyone-gets-it/](https://tracydurnell.com/2023/09/18/its-ok-if-not-everyone-gets-it/)
 - RSS feed: https://tracydurnell.com/feed/
 - date published: 2023-09-18T22:37:31+00:00

This view of satire—that [it] fails if some dullard doesn’t understand it—dovetails into the popular idea of art as moral instruction in which the greatest failure a work of art can do is confuse someone about the intended message. Art isn’t osmosis. There’s no way to force everyone to absorb your intended message. Focusing on [&#8230;]

## Rethinking utilities
 - [https://tracydurnell.com/2023/09/17/rethinking-utilities/](https://tracydurnell.com/2023/09/17/rethinking-utilities/)
 - RSS feed: https://tracydurnell.com/feed/
 - date published: 2023-09-18T02:01:37+00:00

Utilities are necessary services that should be affordable and accountable to the public. My water utility sends me an annual water quality report so I can trust the tap water is safe. My use-based utilities provide meter reads in every bill to show I&#8217;m being billed for my own usage. They&#8217;re often run directly by [&#8230;]

