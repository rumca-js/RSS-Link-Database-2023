# Source:rp.pl, URL:https://www.rp.pl/rss_main, language:pl-PL

## Minister rolnictwa Niemiec krytykuje Polkę, Węgry i Słowację: Solidarność na pół etatu
 - [https://www.rp.pl/konflikty-zbrojne/art39129551-minister-rolnictwa-niemiec-krytykuje-polke-wegry-i-slowacje-solidarnosc-na-pol-etatu](https://www.rp.pl/konflikty-zbrojne/art39129551-minister-rolnictwa-niemiec-krytykuje-polke-wegry-i-slowacje-solidarnosc-na-pol-etatu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T21:08:00+00:00

Zdaniem federalnego ministra rolnictwa Cema Özdemira przedłużenie blokady ukraińskiego zboża przez Polskę, Węgry i Słowację jest niezgodne z prawem unijnym.

## Minister rolnictwa Niemiec krytykuje Polskę, Węgry i Słowację: Solidarność na pół etatu
 - [https://www.rp.pl/konflikty-zbrojne/art39129551-minister-rolnictwa-niemiec-krytykuje-polske-wegry-i-slowacje-solidarnosc-na-pol-etatu](https://www.rp.pl/konflikty-zbrojne/art39129551-minister-rolnictwa-niemiec-krytykuje-polske-wegry-i-slowacje-solidarnosc-na-pol-etatu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T21:08:00+00:00

Zdaniem federalnego ministra rolnictwa Cema Özdemira przedłużenie blokady ukraińskiego zboża przez Polskę, Węgry i Słowację jest niezgodne z prawem unijnym.

## Rosja zostanie sama w Arktyce; bez dostępu do zachodnich technologii
 - [https://www.rp.pl/gospodarka/art39129371-rosja-zostanie-sama-w-arktyce-bez-dostepu-do-zachodnich-technologii](https://www.rp.pl/gospodarka/art39129371-rosja-zostanie-sama-w-arktyce-bez-dostepu-do-zachodnich-technologii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T20:15:11+00:00

Rosja wycofała się z Euro-Arktycznej Rady Morza Barentsa. Ta organizacja od 30 lat czuwa nad racjonalnym wykorzystaniem gospodarczym Arktyki.

## Ramzan Kadyrow, poszukiwany żywy, a może martwy
 - [https://www.rp.pl/polityka/art39129381-ramzan-kadyrow-poszukiwany-zywy-a-moze-martwy](https://www.rp.pl/polityka/art39129381-ramzan-kadyrow-poszukiwany-zywy-a-moze-martwy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T20:04:14+00:00

Nie wiadomo, co dzieje się z wodzem Czeczenii Ramzanem Kadyrowem.

## Jak odbić administrację państwową od dna? Budżetówka walczy o pieniądze
 - [https://www.rp.pl/urzednicy/art39128661-jak-odbic-administracje-panstwowa-od-dna-budzetowka-walczy-o-pieniadze](https://www.rp.pl/urzednicy/art39128661-jak-odbic-administracje-panstwowa-od-dna-budzetowka-walczy-o-pieniadze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T19:18:57+00:00

Jednorazowe podwyżki nie są sposobem na eliminację niedomagań instytucji państwowych.

## Rumunia rozważy jednostronne przedłużenie embarga  na ukraińskie towary
 - [https://www.rp.pl/konflikty-zbrojne/art39129201-rumunia-rozwazy-jednostronne-przedluzenie-embarga-na-ukrainskie-towary](https://www.rp.pl/konflikty-zbrojne/art39129201-rumunia-rozwazy-jednostronne-przedluzenie-embarga-na-ukrainskie-towary)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T19:00:00+00:00

Rumunia będzie rozważać przedłużenie zakazu handlu ukraińskim zbożem, jeśli wzrośnie liczba próśb o import - powiedział w poniedziałek premier Marcel Ciolacu.

## Rzecznik rządu: Skarga Ukrainy do WTO nie robi na nas wrażenia
 - [https://www.rp.pl/polityka/art39129041-rzecznik-rzadu-skarga-ukrainy-do-wto-nie-robi-na-nas-wrazenia](https://www.rp.pl/polityka/art39129041-rzecznik-rzadu-skarga-ukrainy-do-wto-nie-robi-na-nas-wrazenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T18:11:00+00:00

- Podtrzymujemy swoje stanowisko. Taka skarga do WTO nie robi na nas wrażenia - tak rzecznik rządu Piotr  Müller skomentował fakt złożenia przez Ukrainę skargi na Polskę, Węgry i Słowację za jednostronne embargo na ukraińskie zboża.

## Ukraina zaskarżyła Polskę i inne kraje do Światowej Organizacji Handlu
 - [https://www.rp.pl/handel/art39128781-ukraina-zaskarzyla-polske-i-inne-kraje-do-swiatowej-organizacji-handlu](https://www.rp.pl/handel/art39128781-ukraina-zaskarzyla-polske-i-inne-kraje-do-swiatowej-organizacji-handlu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T17:43:10+00:00

Ukraina złożyła skargę na Polskę, Słowację i Węgry do Światowej Organizacji Handlu (WTO), bo przedłużyły embargo na ukraińskie produkty rolne.

## 300+: Rolą ZUS nie jest badanie, jak rodzice dzielą się opieką i pieniędzmi
 - [https://www.rp.pl/praca-emerytury-i-renty/art39128631-300-rola-zus-nie-jest-badanie-jak-rodzice-dziela-sie-opieka-i-pieniedzmi](https://www.rp.pl/praca-emerytury-i-renty/art39128631-300-rola-zus-nie-jest-badanie-jak-rodzice-dziela-sie-opieka-i-pieniedzmi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T17:30:17+00:00

ZUS podzieli 300+ na pół, jeśli z orzeczenia sądu wynika, że rodzice sprawują opiekę naprzemiennie. Nie ma znaczenia, że dziecko częściej mieszka u matki.

## Sztuczna inteligencja umie się już maskować. Sprytnie myli detektory
 - [https://cyfrowa.rp.pl/technologie/art39125761-sztuczna-inteligencja-umie-sie-juz-maskowac-sprytnie-myli-detektory](https://cyfrowa.rp.pl/technologie/art39125761-sztuczna-inteligencja-umie-sie-juz-maskowac-sprytnie-myli-detektory)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T17:00:00+00:00

Gdy jedne algorytmy próbują oszukać rzeczywistość, generując plagiaty, fake newsy i imitując twórczość człowieka, inne starają się wykryć treści powstające z udziałem botów. W odpowiedzi pojawiają się systemy, które mają zmylić takie detektory.

## „Koszmar prywatności”. Auta wiedzą wszystko o kierowcach, a nawet więcej
 - [https://cyfrowa.rp.pl/it/art39125781-koszmar-prywatnosci-auta-wiedza-wszystko-o-kierowcach-a-nawet-wiecej](https://cyfrowa.rp.pl/it/art39125781-koszmar-prywatnosci-auta-wiedza-wszystko-o-kierowcach-a-nawet-wiecej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T17:00:00+00:00

Samochody są coraz bardziej inteligentne i zdolne do zbierania informacji – dane z rozmaitych sensorów i systemów wysyłane są do producenta, a o skali zjawiska świadczyć może fakt, że auto jest w stanie gromadzić nawet 580 gigabajtów na godzinę.

## Polska proponuje zaostrzenie sankcji wobec Rosji.  Uderza w Białoruś
 - [https://www.rp.pl/konflikty-zbrojne/art39128151-polska-proponuje-zaostrzenie-sankcji-wobec-rosji-uderza-w-bialorus](https://www.rp.pl/konflikty-zbrojne/art39128151-polska-proponuje-zaostrzenie-sankcji-wobec-rosji-uderza-w-bialorus)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T16:48:00+00:00

Polska zaproponowała, aby w kolejnym, 12. pakiecie unijnych sankcji na Rosję znalazł się zakaz importu rosyjskich diamentów i skroplonego gazu ziemnego. Warszawa wzywa też do zrównania sankcji wobec Białorusi z sankcjami wobec Moskwy.

## „Dobrze, że żyję”. Linda Evangelista o walce z rakiem i podwójnej mastektomii
 - [https://kobieta.rp.pl/zdrowie/art39127071-dobrze-ze-zyje-linda-evangelista-o-walce-z-rakiem-i-podwojnej-mastektomii](https://kobieta.rp.pl/zdrowie/art39127071-dobrze-ze-zyje-linda-evangelista-o-walce-z-rakiem-i-podwojnej-mastektomii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T16:38:52+00:00

Linda Evangelista, słynna supermodelka, jedna z gwiazd modowych wybiegów lat 90., ujawniła w rozmowie z dziennikiem „Wall Street Journal”, że zmagała się z rakiem piersi. Konieczna była podwójna mastektomia. Zaapelowała też do kobiet, by regularnie się badały.

## Publiczne przedszkola są bezpłatne tylko w teorii
 - [https://www.rp.pl/prawo-dla-ciebie/art39127681-publiczne-przedszkola-sa-bezplatne-tylko-w-teorii](https://www.rp.pl/prawo-dla-ciebie/art39127681-publiczne-przedszkola-sa-bezplatne-tylko-w-teorii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T16:24:46+00:00

Zbieranie pieniędzy na wyprawkę czy karty pracy jest bezprawne.

## Rosja. Ciężarna żołnierka skazana na kolonię karną za dezercję
 - [https://www.rp.pl/konflikty-zbrojne/art39127671-rosja-ciezarna-zolnierka-skazana-na-kolonie-karna-za-dezercje](https://www.rp.pl/konflikty-zbrojne/art39127671-rosja-ciezarna-zolnierka-skazana-na-kolonie-karna-za-dezercje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T16:17:00+00:00

Garnizonowy sąd wojskowy we Władykaukazie na południu Rosji skazał brzemienną Madinę Kabałojewę na sześć lat kolonii karnej za dezercję.

## Dziennik Ustaw z 18 września 2023 (1899-1913)
 - [https://www.rp.pl/akty-prawne/art39126841-dziennik-ustaw-z-18-wrzesnia-2023-1899-1913](https://www.rp.pl/akty-prawne/art39126841-dziennik-ustaw-z-18-wrzesnia-2023-1899-1913)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T15:40:20+00:00



## Monitor Polski z 18 września 2023 (1018-1021)
 - [https://www.rp.pl/akty-prawne/art39126711-monitor-polski-z-18-wrzesnia-2023-1018-1021](https://www.rp.pl/akty-prawne/art39126711-monitor-polski-z-18-wrzesnia-2023-1018-1021)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T15:33:18+00:00



## Kurtyna Kobiet. Wyjątkowy projekt w Teatrze Słowackiego
 - [https://kobieta.rp.pl/kultura/art39126161-kurtyna-kobiet-wyjatkowy-projekt-w-teatrze-slowackiego](https://kobieta.rp.pl/kultura/art39126161-kurtyna-kobiet-wyjatkowy-projekt-w-teatrze-slowackiego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T15:23:52+00:00

Teatr Słowackiego z okazji 130-lecia działalności przygotował wyjątkowy projekt. Mowa o Kurtynie Kobiet, na której znajdą się 130 nazwiska krakowianek. Ich działalność zostanie upamiętniona haftami.

## Morawiecki do mieszkańców wsi "zdradzonych przez PO": Przepraszamy za nasze grzechy
 - [https://www.rp.pl/polityka/art39126701-morawiecki-do-mieszkancow-wsi-zdradzonych-przez-po-przepraszamy-za-nasze-grzechy](https://www.rp.pl/polityka/art39126701-morawiecki-do-mieszkancow-wsi-zdradzonych-przez-po-przepraszamy-za-nasze-grzechy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T15:21:00+00:00

Drodzy mieszkańcy polskiej wsi, wy tyle razy zdradzeni przez liberałów z PO, doskonale wiecie, jaka jest różnica między nami a tamtymi - mówił premier Mateusz Morawiecki na spotkaniu z sympatykami PiS w Narolu w powiecie lubaczowskim.

## #fatshamingworks nie pomaga schudnąć, raczej pogłębia chorobę otyłościową
 - [https://www.rp.pl/zdrowy-styl-zycia/art39126411-fatshamingworks-nie-pomaga-schudnac-raczej-poglebia-chorobe-otylosciowa](https://www.rp.pl/zdrowy-styl-zycia/art39126411-fatshamingworks-nie-pomaga-schudnac-raczej-poglebia-chorobe-otylosciowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T14:50:57+00:00

Umieszczanie pod zdjęciami osób, które ważą zbyt dużo, obraźliwych komentarzy nie spowoduje, że „wezmą się za siebie” i schudną – apelują lekarze w odpowiedzi na coraz powszechnie zjawisko obrażania osób otyłych w socjal mediach opatrzone hasztagiem #fatshamingworks.

## Pszczoły mają trudności z zapylaniem. Powodem zanieczyszczone powietrze
 - [https://klimat.rp.pl/klimat/art39125751-pszczoly-maja-trudnosci-z-zapylaniem-powodem-zanieczyszczone-powietrze](https://klimat.rp.pl/klimat/art39125751-pszczoly-maja-trudnosci-z-zapylaniem-powodem-zanieczyszczone-powietrze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T14:17:11+00:00

Ozon sprawia, że zmienia się zapach wydzielany przez kwiaty oraz zasięg, na jaki się on rozchodzi. Badacze są tym zaniepokojeni – prowadzi to bowiem do tego, że owady zapylające są w stanie wywęszyć kwiaty jedynie z dość bliskiej odległości.

## Dowódca elitarnej rosyjskiej jednostki powietrznodesantowej zabity na Ukrainie
 - [https://www.rp.pl/konflikty-zbrojne/art39126391-dowodca-elitarnej-rosyjskiej-jednostki-powietrznodesantowej-zabity-na-ukrainie](https://www.rp.pl/konflikty-zbrojne/art39126391-dowodca-elitarnej-rosyjskiej-jednostki-powietrznodesantowej-zabity-na-ukrainie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T14:17:00+00:00

Podczas walk na Ukrainie zginął dowódca rosyjskiej  31. Gwardyjskiej Samodzielnej Brygady Desantowo-Szturmowej płk Andriej Kondraszkin, ps. Dunaj. Brał udział  m.in. w walkach o Mariupol.

## Jędrzej Bielecki: Rumunia zawstydza Polskę. Przejmie rolę najważniejszego sojusznika Ukrainy?
 - [https://www.rp.pl/komentarze/art39125231-jedrzej-bielecki-rumunia-zawstydza-polske-przejmie-role-najwazniejszego-sojusznika-ukrainy](https://www.rp.pl/komentarze/art39125231-jedrzej-bielecki-rumunia-zawstydza-polske-przejmie-role-najwazniejszego-sojusznika-ukrainy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T14:13:20+00:00

Wbrew decyzji Brukseli polski rząd utrzymuje embargo na import ukraińskiego zboża, bo nie potrafi zabezpieczyć jego tranzytu. Bukareszt nie ma z tym problemu.

## Nowy trend: praca zdalna z siłowni. Kluby fitness kuszą ofertą hybrydową
 - [https://sukces.rp.pl/styl-zycia/art38964301-nowy-trend-praca-zdalna-z-silowni-kluby-fitness-kusza-oferta-hybrydowa](https://sukces.rp.pl/styl-zycia/art38964301-nowy-trend-praca-zdalna-z-silowni-kluby-fitness-kusza-oferta-hybrydowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:46:14+00:00

Poranny trening, a później praca przed komputerem na siłowni zamiast jazdy do pracy – coraz popularniejsze stają się fitness kluby oferujące klientem wydzielone miejsca do pracy zdalnej. Czy trend, coraz popularniejszy w USA, przyjmie się w naszym kraju?

## Gen. Waldemar Skrzypczak: USA i Chiny powinny zmusić Władimira Putina i Wołodymyra Zełenskiego do zawieszenia broni i rozmów
 - [https://www.rp.pl/konflikty-zbrojne/art39126141-gen-waldemar-skrzypczak-usa-i-chiny-powinny-zmusic-wladimira-putina-i-wolodymyra-zelenskiego-do-zawieszenia-broni-i-rozmow](https://www.rp.pl/konflikty-zbrojne/art39126141-gen-waldemar-skrzypczak-usa-i-chiny-powinny-zmusic-wladimira-putina-i-wolodymyra-zelenskiego-do-zawieszenia-broni-i-rozmow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:33:54+00:00

„Rosja, wbrew oczekiwaniom, ma się całkiem dobrze” - ocenia gen. Waldemar Skrzypczak, były dowódca Wojsk Lądowych, zwracając uwagę, że Moskwa „odbudowuje swoje wojska systematycznie”.

## Kontrofensywa: Czy dostawy amunicji z Korei Północnej zmienią sytuację na froncie?
 - [https://www.rp.pl/konflikty-zbrojne/art39126071-kontrofensywa-czy-dostawy-amunicji-z-korei-polnocnej-zmienia-sytuacje-na-froncie](https://www.rp.pl/konflikty-zbrojne/art39126071-kontrofensywa-czy-dostawy-amunicji-z-korei-polnocnej-zmienia-sytuacje-na-froncie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:33:18+00:00

- W pewnym momencie Rosja znajdzie się przed wyborem: narazić swoje wojska na okrążenie, albo wycofać się z dotychczasowych pozycji – mówi „Rzeczpospolitej” Ołeksij Melnyk, ekspert ds. bezpieczeństwa międzynarodowego kijowskiego Centrum Razumkowa.

## Rosja: Zdymisjonowany generał Siergiej Surowikin odnalazł się w Afryce. Co tam robi?
 - [https://www.rp.pl/polityka/art39125491-rosja-zdymisjonowany-general-siergiej-surowikin-odnalazl-sie-w-afryce-co-tam-robi](https://www.rp.pl/polityka/art39125491-rosja-zdymisjonowany-general-siergiej-surowikin-odnalazl-sie-w-afryce-co-tam-robi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:22:19+00:00

Generał Siergiej Surowikin, usunięty ze stanowiska po puczu Jewgienija Prigożyna, nagle znalazł się w Algierii, w środku międzynarodowych intryg.

## Badania: ponad połowa uczniów w Toruniu wymaga diagnostyki w kierunku depresji
 - [https://edukacja.rp.pl/szkoly-podstawowe-i-srednie/art39126111-badania-ponad-polowa-uczniow-w-toruniu-wymaga-diagnostyki-w-kierunku-depresji](https://edukacja.rp.pl/szkoly-podstawowe-i-srednie/art39126111-badania-ponad-polowa-uczniow-w-toruniu-wymaga-diagnostyki-w-kierunku-depresji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:14:57+00:00

Badacze z Uniwersytetu Mikołaja Kopernika w Toruniu na zlecenie tamtejszego magistratu przyjrzeli się kondycji psychicznej dzieci i młodzieży. Wyniki są zatrważające.

## Krakusi połączą online banki z windykatorami
 - [https://cyfrowa.rp.pl/biznes-ludzie-startupy/art39125771-krakusi-polacza-online-banki-z-windykatorami](https://cyfrowa.rp.pl/biznes-ludzie-startupy/art39125771-krakusi-polacza-online-banki-z-windykatorami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:12:00+00:00

Krakowski start-up BidFinance stworzył internetową platformę, która pozwala handlować wierzytelnościami na aukcjach. Innowacyjny pomysł już przyciągnął uwagę inwestorów.

## Robert Bąkiewicz przystąpił do Suwerennej Polski. „Jest już pełnoprawnym członkiem”
 - [https://www.rp.pl/polityka/art39126091-robert-bakiewicz-przystapil-do-suwerennej-polski-jest-juz-pelnoprawnym-czlonkiem](https://www.rp.pl/polityka/art39126091-robert-bakiewicz-przystapil-do-suwerennej-polski-jest-juz-pelnoprawnym-czlonkiem)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:10:53+00:00

Organizator Marszu Niepodległości Robert Bąkiewicz złożył niedawno deklarację członkowską do Suwerennej Polski i przystąpił do partii Zbigniewa Ziobry - poinformowała Wirtualna Polska.

## Jak pokonać nowotwór. Nowe leki i terapie mają raka oszukać
 - [https://cyfrowa.rp.pl/technologie/art39125821-jak-pokonac-nowotwor-nowe-leki-i-terapie-maja-raka-oszukac](https://cyfrowa.rp.pl/technologie/art39125821-jak-pokonac-nowotwor-nowe-leki-i-terapie-maja-raka-oszukac)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:05:00+00:00

Naukowcy z Uniwersytetu Purdue opracowali metodę leczenia raka, która oszukuje komórki nowotworowe, tak by wchłonęły fragment RNA, które w naturalny sposób blokuje dalszy ich podział. W fazie badań jest już dziesięć szczepionek opartych na mRNA.

## W Egipcie powstaje nowa wioska turystyczna. Buduje ją sieć hoteli
 - [https://turystyka.rp.pl/hotele/art39126081-w-egipcie-powstaje-nowa-wioska-turystyczna-buduje-ja-siec-hoteli](https://turystyka.rp.pl/hotele/art39126081-w-egipcie-powstaje-nowa-wioska-turystyczna-buduje-ja-siec-hoteli)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T13:04:18+00:00

Marsa Mares Bay ma być nowym kurortem turystycznym nad egipskim wybrzeżem Morza Czerwonego, a to za sprawą planów sieci hotelowej Jaz. W sumie firma uruchomi tam 10 obiektów.

## Iga Świątek. Dziś w PZU, jutro do Tokio
 - [https://www.rp.pl/tenis/art39125621-iga-swiatek-dzis-w-pzu-jutro-do-tokio](https://www.rp.pl/tenis/art39125621-iga-swiatek-dzis-w-pzu-jutro-do-tokio)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:54:14+00:00

Iga Świątek pojawiła się w poniedziałek w Warszawie na konferencji prasowej swego sponsora, by wesprzeć program Dobra Drużyna PZU i powiedzieć kilka słów o sobie i finale sezonu

## Generacja Z ma już dość tostów z awokado. Woli nowy „hedonistyczny” przysmak
 - [https://sukces.rp.pl/kuchnia/art39125321-generacja-z-ma-juz-dosc-tostow-z-awokado-woli-nowy-hedonistyczny-przysmak](https://sukces.rp.pl/kuchnia/art39125321-generacja-z-ma-juz-dosc-tostow-z-awokado-woli-nowy-hedonistyczny-przysmak)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:54:09+00:00

Tost z awokado do niedawna był symbolem współczesnej wielkomiejskiej klasy średniej. Generacja Z ma szansę, by to zmienić. Nowy, hedonistyczny trend kulinarny robi furorę w bistrach – oraz w mediach społecznościowych.

## Francuscy kontrolerzy nie będą strajkować do końca września 2024 roku
 - [https://www.rp.pl/transport/art39125511-francuscy-kontrolerzy-nie-beda-strajkowac-do-konca-wrzesnia-2024-roku](https://www.rp.pl/transport/art39125511-francuscy-kontrolerzy-nie-beda-strajkowac-do-konca-wrzesnia-2024-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:53:25+00:00

Francuscy kontrolerzy zobowiązali się nie strajkować przez rok do końca września 2024, czyli do zakończenia olimpiady i paraolimpiady we Francji. Dużo lotów w Europie przebiega właśnie przez ten kraj.

## Praga stawia ograniczenia elektrycznym hulajnogom. Zakaz utrudni korzystanie
 - [https://www.rp.pl/transport/art39125181-praga-stawia-ograniczenia-elektrycznym-hulajnogom-zakaz-utrudni-korzystanie](https://www.rp.pl/transport/art39125181-praga-stawia-ograniczenia-elektrycznym-hulajnogom-zakaz-utrudni-korzystanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:49:18+00:00

Władze dzielnicy Praha 1, obejmującej historyczne centrum stolicy Czech, mają dosyć elektrycznych hulajnóg blokujących chodniki i wprowadzają ograniczenia. Nie zakazują jednak jazdy.

## Gaz w Europie tanieje po wieściach z Australii
 - [https://energia.rp.pl/gaz/art39125441-gaz-w-europie-tanieje-po-wiesciach-z-australii](https://energia.rp.pl/gaz/art39125441-gaz-w-europie-tanieje-po-wiesciach-z-australii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:46:59+00:00

Od rana tanieje gaz na europejskim rynku. To pochodna wiadomości z Australii, gdzie na razie nie grozi strajk w zakładach Chevron i produkcja LNG idzie pełną parą.

## Grupa Orlen chce kupić Energop
 - [https://energia.rp.pl/paliwa/art39125401-grupa-orlen-chce-kupic-energop](https://energia.rp.pl/paliwa/art39125401-grupa-orlen-chce-kupic-energop)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:44:06+00:00

To podmiot, który z realizacji kontraktów na rzecz płockiego koncernu uzyskuje większość przychodów. Jednocześnie w ostatnich latach ponosi straty. Za ile będzie kupiony, nie podano.

## Fala zwrotów na rynku e-mody testuje logistykę
 - [https://logistyka.rp.pl/produkty-i-uslugi/art39125911-fala-zwrotow-na-rynku-e-mody-testuje-logistyke](https://logistyka.rp.pl/produkty-i-uslugi/art39125911-fala-zwrotow-na-rynku-e-mody-testuje-logistyke)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:43:36+00:00

Wartość sprzedanej w UE w tym roku przez internet odzieży sięgnie 111,6 mld dol., a za cztery lata nawet 162,2 mld. Nie obędzie się jednak bez problemów, ponieważ produkty z tej grupy generują najwyższy udział zwrotów spośród wszystkich kategorii produktowych

## Michał Szułdrzyński: W tłumaczeniach PiS afery wizowej nic się nie klei. Dlatego użyli tajnych planów obrony Polski
 - [https://www.rp.pl/komentarze/art39125721-michal-szuldrzynski-w-tlumaczeniach-pis-afery-wizowej-nic-sie-nie-klei-dlatego-uzyli-tajnych-planow-obrony-polski](https://www.rp.pl/komentarze/art39125721-michal-szuldrzynski-w-tlumaczeniach-pis-afery-wizowej-nic-sie-nie-klei-dlatego-uzyli-tajnych-planow-obrony-polski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:41:10+00:00

Ujawnienie przez PiS tajnych planów obrony Polski z czasów PO to sygnał, że władza dostrzega powagę afery wizowej. I by odwrócić od niej uwagę, gotowa jest uderzyć w swoją wiarygodności w UE i w NATO. Bo takie efekty będzie miała jej kontrofensywa kampanijna.

## Silesia Star. 1,3 tys. metrów biur wzięte
 - [https://www.rp.pl/nieruchomosci/art39125881-silesia-star-1-3-tys-metrow-biur-wziete](https://www.rp.pl/nieruchomosci/art39125881-silesia-star-1-3-tys-metrow-biur-wziete)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:36:11+00:00

Biura w budynku Silesia Star w Katowicach wynajmuje CAT LC Polska. Przeprowadzkę zaplanowano na październik.

## Przytulanie wpływa na zdrowie? Oto, dlaczego nie powinniśmy rezygnować z bliskości
 - [https://kobieta.rp.pl/psychologia/art39125451-przytulanie-wplywa-na-zdrowie-oto-dlaczego-nie-powinnismy-rezygnowac-z-bliskosci](https://kobieta.rp.pl/psychologia/art39125451-przytulanie-wplywa-na-zdrowie-oto-dlaczego-nie-powinnismy-rezygnowac-z-bliskosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:32:29+00:00

Czy przytulanie może wpłynąć na zdrowie fizyczne? Okazuje się, że tak. Naukowcy od lat pochylają się nad tematyką wpływu uścisków na samopoczucie człowieka. Doszli do ważnych wniosków: przynoszą one realne korzyści dla zdrowia.

## Nowa szczepionka na COVID przetestowana tylko na czterech szczurach? To nieprawda
 - [https://www.rp.pl/zdrowie/art39125671-nowa-szczepionka-na-covid-przetestowana-tylko-na-czterech-szczurach-to-nieprawda](https://www.rp.pl/zdrowie/art39125671-nowa-szczepionka-na-covid-przetestowana-tylko-na-czterech-szczurach-to-nieprawda)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:32:25+00:00

"USA Today" dementuje rozpowszechnianą w mediach społecznościowych informację, że zmodyfikowana, dopuszczona do użycia w USA przez FDA (Federalna Administracja Żywności i Leków) wersja szczepionki przeciw COVID-19 Pfizer/BioNTech, została przetestowana jedynie na czterech szczurach.

## Ukraiński minister odpowiada na polskie embargo zboża. Beata Szydło: Impertynenckie zachowanie
 - [https://www.rp.pl/dyplomacja/art39125801-ukrainski-minister-odpowiada-na-polskie-embargo-zboza-beata-szydlo-impertynenckie-zachowanie](https://www.rp.pl/dyplomacja/art39125801-ukrainski-minister-odpowiada-na-polskie-embargo-zboza-beata-szydlo-impertynenckie-zachowanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:31:44+00:00

Ukraina przygotuje pozew wobec Polski, Węgier i Słowacji do WTO po przedłużeniu przez te kraje zakazu importu produktów rolnych od wschodniego sąsiada. Była premier RP Beata Szydło zasugerowała, że Kijów powinien przemyśleć, jaki daje „przykład dla świata”, gdy „w taki sposób traktuje kraj, który uratował Ukrainę w najbardziej dramatycznych chwilach”.

## Inflacja bazowa nadal dwucyfrowa. NBP opublikował najnowsze dane
 - [https://www.rp.pl/dane-gospodarcze/art39125851-inflacja-bazowa-nadal-dwucyfrowa-nbp-opublikowal-najnowsze-dane](https://www.rp.pl/dane-gospodarcze/art39125851-inflacja-bazowa-nadal-dwucyfrowa-nbp-opublikowal-najnowsze-dane)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:23:02+00:00

Inflacja bazowa, a więc po wyłączeniu cen żywności i energii, wyniosła w sierpniu 10 proc. w ujęciu rocznym – podał w poniedziałek Narodowy Bank Polski.

## Bogusław Chrabota: To nie Donald Tusk zabijał po 17 września
 - [https://www.rp.pl/komentarze/art39125661-boguslaw-chrabota-to-nie-donald-tusk-zabijal-po-17-wrzesnia](https://www.rp.pl/komentarze/art39125661-boguslaw-chrabota-to-nie-donald-tusk-zabijal-po-17-wrzesnia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:08:11+00:00

Trzeba być ignorantem albo człowiekiem kompletnie nieczułym, by nie rozumieć, co data 17 września znaczy wciąż dla milionów Polaków. Jak więc skomentować słowa premiera Mateusza Morawieckiego, który nie potrafił tej daty uszanować?

## Sondaż: PiS stoi w miejscu, poparcie dla KO spadło. Konfederacja piąta
 - [https://www.rp.pl/polityka/art39125631-sondaz-pis-stoi-w-miejscu-poparcie-dla-ko-spadlo-konfederacja-piata](https://www.rp.pl/polityka/art39125631-sondaz-pis-stoi-w-miejscu-poparcie-dla-ko-spadlo-konfederacja-piata)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T12:07:58+00:00

Wybory parlamentarne zakończyłyby się zwycięstwem Prawa i Sprawiedliwości, a do Sejmu dostaliby się przedstawiciele pięciu ugrupowań - wynika z najnowszego sondażu IBRiS dla „Wydarzeń” Polsatu i Polsat News.

## Małgosia Bela twarzą kampanii YES x Ossoliński
 - [https://kobieta.rp.pl/moda/art39124851-malgosia-bela-twarza-kampanii-yes-x-ossolinski](https://kobieta.rp.pl/moda/art39124851-malgosia-bela-twarza-kampanii-yes-x-ossolinski)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:59:31+00:00

Tomasz Ossoliński, jeden z najważniejszych polskich projektantów, we współpracy z marką biżuteryjną YES stworzył kolekcję będącą hołdem dla kobiecej siły, odwagi i niezależności. Twarzą projektu została modelka Małgosia Bela.

## Małgosia Bela w kampanii YES x Ossoliński. Wyjątkowa, a jednocześnie bliska
 - [https://kobieta.rp.pl/moda/art39124851-malgosia-bela-w-kampanii-yes-x-ossolinski-wyjatkowa-a-jednoczesnie-bliska](https://kobieta.rp.pl/moda/art39124851-malgosia-bela-w-kampanii-yes-x-ossolinski-wyjatkowa-a-jednoczesnie-bliska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:59:31+00:00

Tomasz Ossoliński, jeden z najważniejszych polskich projektantów, we współpracy z marką biżuteryjną YES stworzył kolekcję będącą hołdem dla kobiecej siły, odwagi i niezależności. Twarzą projektu została modelka Małgosia Bela.

## Centra handlowe chcą płatnych parkingów. Ostry sprzeciw sklepów
 - [https://www.rp.pl/handel/art39125111-centra-handlowe-chca-platnych-parkingow-ostry-sprzeciw-sklepow](https://www.rp.pl/handel/art39125111-centra-handlowe-chca-platnych-parkingow-ostry-sprzeciw-sklepow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:53:34+00:00

Chociaż najemcy pokrywają koszty prowadzenia parkingu w ramach kosztów wspólnych, to kolejne centra wprowadzają opłaty. A to uderza w sklepy, zmniejszając liczbę potencjalnych klientów.

## Afera wizowa. „PiS zmienia strategię i usiłuje uciec do przodu”
 - [https://www.rp.pl/wybory/art39125531-afera-wizowa-pis-zmienia-strategie-i-usiluje-uciec-do-przodu](https://www.rp.pl/wybory/art39125531-afera-wizowa-pis-zmienia-strategie-i-usiluje-uciec-do-przodu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:53:07+00:00

Politycy PiS próbują wykorzystać sprawę wiz do podgrzewania emocji wokół kwestii migracji i promowania własnej opowieści w tej sprawie - mówili w kolejnym odcinku podcastu „Polityczne Michałki” Michał Kolanko i Michał Szułdrzyński.

## Zachodni kapitał utknął w Rosji
 - [https://www.rp.pl/biznes/art39125641-zachodni-kapital-utknal-w-rosji](https://www.rp.pl/biznes/art39125641-zachodni-kapital-utknal-w-rosji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:51:07+00:00

Zachodnie spółki zarobiły netto w Rosji w 2022 r. łącznie co najmniej 18 mld dol., ale mają trudności z dostępem do tych zysków.

## O kredyt hipoteczny coraz łatwiej
 - [https://pieniadze.rp.pl/planowanie-wydatkow/art39125501-o-kredyt-hipoteczny-coraz-latwiej](https://pieniadze.rp.pl/planowanie-wydatkow/art39125501-o-kredyt-hipoteczny-coraz-latwiej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:49:46+00:00

Ułatwienia w badaniu zdolności kredytowej, dopłaty do kredytów i dobra sytuacja na rynku pracy to nie wszystko. We wrześniu drogę do własnego mieszkania zaczęła ułatwiać też RPP obniżając stopy procentowe.

## Samorządy ruszają z kampanią zachęcającą do głosowania
 - [https://regiony.rp.pl/z-regionow/art39125471-samorzady-ruszaja-z-kampania-zachecajaca-do-glosowania](https://regiony.rp.pl/z-regionow/art39125471-samorzady-ruszaja-z-kampania-zachecajaca-do-glosowania)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:41:09+00:00

Samorządy i osoby publiczne włączają się w społeczną kampanię profrekwencyjną Unii Metropolii Polskich, która odbywa się pod hasłem #NieŚpijBoCięPrzegłosują.

## Małgorzata Wassermann: W Polsce nie ma takich dzielnic, gdzie boi się wjechać policja. Każdy z nas czuje się bezpiecznie
 - [https://www.rp.pl/polityka/art39125331-malgorzata-wassermann-w-polsce-nie-ma-takich-dzielnic-gdzie-boi-sie-wjechac-policja-kazdy-z-nas-czuje-sie-bezpiecznie](https://www.rp.pl/polityka/art39125331-malgorzata-wassermann-w-polsce-nie-ma-takich-dzielnic-gdzie-boi-sie-wjechac-policja-kazdy-z-nas-czuje-sie-bezpiecznie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:26:34+00:00

- To nie jest tak, że Polska jest krajem zaściankowym i każdy obcokrajowiec to u nas jest „O rany boskie, straszne zagrożenie” - przekonywała Małgorzata Wassermann, posłanka Prawa i Sprawiedliwości, komentując tzw. aferę wizową i kampanię wyborczą, w której jej partia akcentuje wątek migracji.

## Microsoft zapłaci za wyskoki sztucznej inteligencji
 - [https://www.rp.pl/internet-i-prawo-autorskie/art39124881-microsoft-zaplaci-za-wyskoki-sztucznej-inteligencji](https://www.rp.pl/internet-i-prawo-autorskie/art39124881-microsoft-zaplaci-za-wyskoki-sztucznej-inteligencji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:26:17+00:00

Zapowiedź Microsoft, który chce wesprzeć klientów pozwanych za naruszenie praw autorskich do cudzych utworów, to odpowiedź na galopujący rozwój AI.

## Koniec lata. W środę w jednym z krajów Europy może spaść śnieg
 - [https://www.rp.pl/spoleczenstwo/art39125341-koniec-lata-w-srode-w-jednym-z-krajow-europy-moze-spasc-snieg](https://www.rp.pl/spoleczenstwo/art39125341-koniec-lata-w-srode-w-jednym-z-krajow-europy-moze-spasc-snieg)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:25:17+00:00

Fińscy meteorolodzy przewidują, że w środę, w niektórych częściach centralnej i północnej Laponii, może spaść śnieg.

## Wybory 2023: głosowanie za granicą. Formalności i ważne terminy
 - [https://www.rp.pl/prawo-dla-ciebie/art39125081-wybory-2023-glosowanie-za-granica-formalnosci-i-wazne-terminy](https://www.rp.pl/prawo-dla-ciebie/art39125081-wybory-2023-glosowanie-za-granica-formalnosci-i-wazne-terminy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:16:00+00:00

Jak zagłosować za granicą? Objaśniamy formalności, podajemy kluczowe terminy.

## Europejska sieć łączy przedsiębiorców – także tych z Polski i Wielkiej Brytanii
 - [https://firma.rp.pl/wsparcie-ekspansji/art39125191-europejska-siec-laczy-przedsiebiorcow-takze-tych-z-polski-i-wielkiej-brytanii](https://firma.rp.pl/wsparcie-ekspansji/art39125191-europejska-siec-laczy-przedsiebiorcow-takze-tych-z-polski-i-wielkiej-brytanii)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:00:37+00:00

Korzystając z sieci Enterprise Europe Network można również znaleźć kontrahentów spoza Unii Europejskiej, w tym brytyjskich. Część z nich aktualnie poszukuje dostawców z Polski.

## Sondaż: Co dziewiąty Polak chce, by Robert Lewandowski odszedł z reprezentacji
 - [https://www.rp.pl/pilka-nozna/art39125161-sondaz-co-dziewiaty-polak-chce-by-robert-lewandowski-odszedl-z-reprezentacji](https://www.rp.pl/pilka-nozna/art39125161-sondaz-co-dziewiaty-polak-chce-by-robert-lewandowski-odszedl-z-reprezentacji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T11:00:35+00:00

Co czwarty ankietowany w sondażu, przeprowadzonym przez United Surveys dla Wirtualnej Polski, chce by Robert Lewandowski został pozbawiony opaski kapitańskiej w reprezentacji Polski. Co dziewiąty - by w ogóle nie grał w kadrze.

## Gen. Cieniuch: To nieprawda, że polska armia miała się bronić przed Rosjanami 10 dni
 - [https://www.rp.pl/wojsko/art39125121-gen-cieniuch-to-nieprawda-ze-polska-armia-miala-sie-bronic-przed-rosjanami-10-dni](https://www.rp.pl/wojsko/art39125121-gen-cieniuch-to-nieprawda-ze-polska-armia-miala-sie-bronic-przed-rosjanami-10-dni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:52:00+00:00

Planowanie operacyjne to jest system planów operacyjnych i ujawnienie jednego planu – dla ludzi umiejących czytać ze zrozumieniem – pozwala zrozumieć inne plany. To jest największe niebezpieczeństwo - powiedział w RMF FM gen. Mieczysław Cieniuch, były szef Sztabu Generalnego Wojska Polskiego, odnosząc się do nowego spotu wyborczego PiS.

## Zara otwiera swój największy sklep na świecie. Nadciąga era megabutików
 - [https://sukces.rp.pl/moda/art39109871-zara-otwiera-swoj-najwiekszy-sklep-na-swiecie-nadciaga-era-megabutikow](https://sukces.rp.pl/moda/art39109871-zara-otwiera-swoj-najwiekszy-sklep-na-swiecie-nadciaga-era-megabutikow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:50:00+00:00

Jesienią tego roku w Rotterdamie ruszy największy na świecie sklep Zary. Rekordowo wielki butik to nie tylko potwierdzenie świetnej kondycji finansowej firmy, ale też rozwój trendu, który można dostrzec na świecie – sklepy stają się coraz większe.

## USA-Rosja: handel najniższy od 23 lat. Amerykanie kupują trzy kategorie towarów
 - [https://www.rp.pl/handel/art39124791-usa-rosja-handel-najnizszy-od-23-lat-amerykanie-kupuja-trzy-kategorie-towarow](https://www.rp.pl/handel/art39124791-usa-rosja-handel-najnizszy-od-23-lat-amerykanie-kupuja-trzy-kategorie-towarow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:47:20+00:00

Od rosyjskiej agresji na Ukrainę obroty handlowe między Stanami Zjednoczonymi a Rosją zmniejszyły się 11-krotnie. Są najniższe od co najmniej ćwierćwiecza. Do czasu rozpętanej przez Kreml wojny, USA były piątym partnerem handlowym Rosji.

## Jacek Nizinkiewicz: PiS przegrało prawybory w Wieruszowie, ale w październiku może wygrać w całym kraju
 - [https://www.rp.pl/publicystyka/art39124801-jacek-nizinkiewicz-pis-przegralo-prawybory-w-wieruszowie-ale-w-pazdzierniku-moze-wygrac-w-calym-kraju](https://www.rp.pl/publicystyka/art39124801-jacek-nizinkiewicz-pis-przegralo-prawybory-w-wieruszowie-ale-w-pazdzierniku-moze-wygrac-w-calym-kraju)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:34:44+00:00

Partia Jarosława Kaczyńskiego wygrała cztery lata temu prawybory w Wieruszowie. Teraz je zbagatelizowała. Czy wiatr odnowy politycznej wieje z Wieruszowa?

## Wielki strajk w sektorze motoryzacji w USA. Trwają rozmowy, ale postęp nikły
 - [https://www.rp.pl/transport/art39124471-wielki-strajk-w-sektorze-motoryzacji-w-usa-trwaja-rozmowy-ale-postep-nikly](https://www.rp.pl/transport/art39124471-wielki-strajk-w-sektorze-motoryzacji-w-usa-trwaja-rozmowy-ale-postep-nikly)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:31:04+00:00

Po rozpoczęciu strajku przez związek UAW w zakładach GM, Forda i Stellantisa wznowiono rozmowy. Cała trójka koncernów poprawiła oferty podwyżek płac. Szef UAW grozi rozszerzeniem akcji strajkowej.

## Polak chciał wjechać do Estonii z prorosyjskim symbolem na aucie. Został ukarany
 - [https://www.rp.pl/spoleczenstwo/art39125021-polak-chcial-wjechac-do-estonii-z-prorosyjskim-symbolem-na-aucie-zostal-ukarany](https://www.rp.pl/spoleczenstwo/art39125021-polak-chcial-wjechac-do-estonii-z-prorosyjskim-symbolem-na-aucie-zostal-ukarany)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:24:54+00:00

Władze estońskie ukarały grzywną polskiego kierowcę samochodu, który chciał przejechać przez granicę ze wstążka św. Jerzego przyczepioną do lusterka wstecznego.

## Wywiad Ukrainy: Rosjanie rzucają do walki armię, która nie ma prawie połowy uzbrojenia
 - [https://www.rp.pl/konflikty-zbrojne/art39124961-wywiad-ukrainy-rosjanie-rzucaja-do-walki-armie-ktora-nie-ma-prawie-polowy-uzbrojenia](https://www.rp.pl/konflikty-zbrojne/art39124961-wywiad-ukrainy-rosjanie-rzucaja-do-walki-armie-ktora-nie-ma-prawie-polowy-uzbrojenia)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:22:02+00:00

Szef wywiadu wojskowego Ukrainy, Kyryło Budanow oświadczył w rozmowie z "The Economist", że rosyjska armia "nie ma rezerw strategicznych" a jedyne, czym dysponuje Rosja, zasoby ludzkie, których "jakość jest niska".

## Po kim dziedziczymy inteligencję? Naukowcy rozwiewają wątpliwości
 - [https://kobieta.rp.pl/psychologia/art39124371-po-kim-dziedziczymy-inteligencje-naukowcy-rozwiewaja-watpliwosci](https://kobieta.rp.pl/psychologia/art39124371-po-kim-dziedziczymy-inteligencje-naukowcy-rozwiewaja-watpliwosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:08:34+00:00

Inteligencja to nic innego jak zdolność pojmowania. Dzięki niej potrafimy dostrzegać otaczającą rzeczywistość, analizować ją i adaptować się do zmian otoczenia. Naukowcy od lat udowadniają, że jest ona w pewnym stopniu dziedziczna (od 50 do 80 proc.). Teraz okazuje się, że szczególnie ważną rolę w tym procesie odgrywa matka.

## Spedytorzy domagają się od Komisji Europejskiej likwidacji oligopolu armatorów
 - [https://logistyka.rp.pl/regulacje-ue/art39124971-spedytorzy-domagaja-sie-od-komisji-europejskiej-likwidacji-oligopolu-armatorow](https://logistyka.rp.pl/regulacje-ue/art39124971-spedytorzy-domagaja-sie-od-komisji-europejskiej-likwidacji-oligopolu-armatorow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:08:10+00:00

Polska Izba Spedycji i Logistyki uważa, że ważą się losy unijnego rozporządzenia wyłączającego spod unijnych zasad konkurencji wielkie alianse żeglugowe.

## Jakiej strategii rowerowej potrzebuje Polska? Sonda „Życia Regionów”
 - [https://regiony.rp.pl/rowerem-przez-polske/art39125001-jakiej-strategii-rowerowej-potrzebuje-polska-sonda-zycia-regionow](https://regiony.rp.pl/rowerem-przez-polske/art39125001-jakiej-strategii-rowerowej-potrzebuje-polska-sonda-zycia-regionow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:07:29+00:00

Promocja roweru jako najbardziej zrównoważonego i przyjaznego dla środowiska środka transportu i rekreacji jest misją „Rzeczpospolitej” jako najbardziej opiniotwórczego dziennika w Polsce.

## NBP zajrzał deweloperom do kieszeni
 - [https://www.rp.pl/nieruchomosci/art39124951-nbp-zajrzal-deweloperom-do-kieszeni](https://www.rp.pl/nieruchomosci/art39124951-nbp-zajrzal-deweloperom-do-kieszeni)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T10:06:33+00:00

14-28 proc. wynosiła marża brutto ze sprzedaży mieszkań deweloperskich w największych miastach pod koniec 2022 r.

## TUI: Obsłużyliśmy już milion klientów w tym roku
 - [https://turystyka.rp.pl/biura-podrozy/art39124671-tui-obsluzylismy-juz-milion-klientow-w-tym-roku](https://turystyka.rp.pl/biura-podrozy/art39124671-tui-obsluzylismy-juz-milion-klientow-w-tym-roku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:59:00+00:00

W tym roku wysłaliśmy na wakacje już milion klientów - poinformowało biuro podróży TUI Poland w mediach społecznościowych. To rekord w polskiej turystyce.

## Fracht i opłaty paliwowe obniżyły ceny usług w Niemczech
 - [https://www.rp.pl/dane-gospodarcze/art39124861-fracht-i-oplaty-paliwowe-obnizyly-ceny-uslug-w-niemczech](https://www.rp.pl/dane-gospodarcze/art39124861-fracht-i-oplaty-paliwowe-obnizyly-ceny-uslug-w-niemczech)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:51:10+00:00

Ceny producentów usług w Niemczech w drugim kwartale 2023 r. były o 2,8 proc. niższe niż w drugim kwartale 2022 r., spadły również o 0,6 proc. w porównaniu do pierwszego kwartału 2023 r.

## Ramzan Kadyrow jest ciężko chory? Jest komentarz Kremla
 - [https://www.rp.pl/polityka/art39124721-ramzan-kadyrow-jest-ciezko-chory-jest-komentarz-kremla](https://www.rp.pl/polityka/art39124721-ramzan-kadyrow-jest-ciezko-chory-jest-komentarz-kremla)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:49:14+00:00

Na konferencji prasowej rzecznik Kremla, Dmitrij Pieskow, odniósł się do pogłosek na temat rzekomo złego stanu zdrowia szefa republiki Czeczenii, Ramzana Kadyrowa.

## Nie żyje Billy Miller. Aktor "Żaru młodości" zmarł przed swoimi 44. urodzinami
 - [https://www.rp.pl/film/art39124771-nie-zyje-billy-miller-aktor-zaru-mlodosci-zmarl-przed-swoimi-44-urodzinami](https://www.rp.pl/film/art39124771-nie-zyje-billy-miller-aktor-zaru-mlodosci-zmarl-przed-swoimi-44-urodzinami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:47:00+00:00

W wieku 43 lat zmarł amerykański aktor filmowy i serialowy Billy Miller. Artysta znany był między innymi z produkcji takich jak "Szpital miejski" czy "Żar młodości”.

## Inflacja wymusza większą ostrożność finansową Polaków
 - [https://pieniadze.rp.pl/budzet-rodzinny/art39124761-inflacja-wymusza-wieksza-ostroznosc-finansowa-polakow](https://pieniadze.rp.pl/budzet-rodzinny/art39124761-inflacja-wymusza-wieksza-ostroznosc-finansowa-polakow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:39:44+00:00

W obliczu wysokich cen polskie społeczeństwo staje się coraz bardziej ostrożne i roztropne w swoim podejściu do wydatków.

## Jak odliczyć VAT z faktur na zakup auta
 - [https://firma.rp.pl/pit-cit-vat/art39124751-jak-odliczyc-vat-z-faktur-na-zakup-auta](https://firma.rp.pl/pit-cit-vat/art39124751-jak-odliczyc-vat-z-faktur-na-zakup-auta)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:39:34+00:00

Czy przy zakupie samochodu dla firmy w ewidencji zakupów VAT w Jednolitym Pliku Kontrolnym trzeba ująć fakturę zaliczkową i końcową, czy wystarczy tylko ostateczna?

## Prawnicy w social mediach. STOP pajacowaniu!
 - [https://kobieta.rp.pl/opinie/art39124241-prawnicy-w-social-mediach-stop-pajacowaniu](https://kobieta.rp.pl/opinie/art39124241-prawnicy-w-social-mediach-stop-pajacowaniu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:34:12+00:00

Choć zarówno prawo jak i zwyczaje, a nawet sztuki piękne, odgrywają ważną rolę w kształtowaniu wizerunku przedstawicieli wielu zawodów, nie mam wątpliwości, że obecnie pierwszorzędną rolę w kształtowaniu pośród społeczeństwa wiedzy o adwokatach odgrywa internet...

## Urodzony, by latać. Armand Duplantis znów pobił rekord świata
 - [https://www.rp.pl/lekkoatletyka/art39124591-urodzony-by-latac-armand-duplantis-znow-pobil-rekord-swiata](https://www.rp.pl/lekkoatletyka/art39124591-urodzony-by-latac-armand-duplantis-znow-pobil-rekord-swiata)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:32:56+00:00

Armand Duplantis wciąż przesuwa granice wyobraźni, bo skokiem na 6.23 m po raz siódmy w karierze pobił rekord świata. Szwed był bohaterem finału Diamentowej Ligi, ale nie jedynym.

## Roman Kuźniar: Marionetkowe MSZ. Afera wizowa to efekt systemu stworzonego przez PiS
 - [https://www.rp.pl/publicystyka/art39124601-roman-kuzniar-marionetkowe-msz-afera-wizowa-to-efekt-systemu-stworzonego-przez-pis](https://www.rp.pl/publicystyka/art39124601-roman-kuzniar-marionetkowe-msz-afera-wizowa-to-efekt-systemu-stworzonego-przez-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:28:49+00:00

W ramach systemu stworzonego przez tzw. zjednoczoną prawicę minister spraw zagranicznych jest resortowym kacykiem, który ma zarządzać częścią folwarku w taki sposób, aby realizowane były interesy osób sprawujących władzę.

## Roman Kuźniar: Megaafera ze sprzedawaniem wiz to nie wypadek przy pracy. Winny jest system PiS
 - [https://www.rp.pl/publicystyka/art39124601-roman-kuzniar-megaafera-ze-sprzedawaniem-wiz-to-nie-wypadek-przy-pracy-winny-jest-system-pis](https://www.rp.pl/publicystyka/art39124601-roman-kuzniar-megaafera-ze-sprzedawaniem-wiz-to-nie-wypadek-przy-pracy-winny-jest-system-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:28:49+00:00

W ramach systemu stworzonego przez tzw. zjednoczoną prawicę minister spraw zagranicznych jest resortowym kacykiem, który ma zarządzać częścią folwarku w taki sposób, aby realizowane były interesy osób sprawujących władzę.

## Wszyscy wiceministrowie obrony Ukrainy zdymisjonowani. Rustem Umerow: Restart
 - [https://www.rp.pl/konflikty-zbrojne/art39124641-wszyscy-wiceministrowie-obrony-ukrainy-zdymisjonowani-rustem-umerow-restart](https://www.rp.pl/konflikty-zbrojne/art39124641-wszyscy-wiceministrowie-obrony-ukrainy-zdymisjonowani-rustem-umerow-restart)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:26:00+00:00

Wiceministrowie obrony Wołodymyr Hawryłow, Rostysław Zamłyński, Hanna Malar, Denys Szarapow, Andrij Szewczenko i Witalij Deineha zostali odwołani z ukraińskiego rządu.

## Cena za neutralność klimatyczną to 2,7 biliona dolarów rocznie
 - [https://klimat.rp.pl/energia/art39124711-cena-za-neutralnosc-klimatyczna-to-2-7-biliona-dolarow-rocznie](https://klimat.rp.pl/energia/art39124711-cena-za-neutralnosc-klimatyczna-to-2-7-biliona-dolarow-rocznie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:25:37+00:00

Nowy raport ocenia, że w celu przeprowadzenia dekarbonizacji sektora energetycznego do 2050 roku, konieczne jest zwiększenie bieżących inwestycji o 150 proc.

## Gminy popegeerowskie z dużym wsparciem. 4,5 mld zł dla samorządów.
 - [https://regiony.rp.pl/budzet/art39124701-gminy-popegeerowskie-z-duzym-wsparciem-4-5-mld-zl-dla-samorzadow](https://regiony.rp.pl/budzet/art39124701-gminy-popegeerowskie-z-duzym-wsparciem-4-5-mld-zl-dla-samorzadow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:22:47+00:00

Znane są już wyniki 6 edycji Programu Inwestycji Strategicznych dla samorządów, w których działały państwowe gospodarstwa rolne.

## Elektroauta nie pojadą z braku akumulatorów
 - [https://logistyka.rp.pl/elektromobilnosc/art39124651-elektroauta-nie-pojada-z-braku-akumulatorow](https://logistyka.rp.pl/elektromobilnosc/art39124651-elektroauta-nie-pojada-z-braku-akumulatorow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:22:07+00:00

Europejski Trybunał Obrachunkowy skrytykował Komisję Europejską za zbyt powolne przygotowanie własnych fabryk akumulatorów, co zagraża elektromobilności.

## Ukraina pozwie Polskę, Słowację i Węgry. Ograniczy import naszych warzyw i owoców
 - [https://www.rp.pl/handel/art39124271-ukraina-pozwie-polske-slowacje-i-wegry-ograniczy-import-naszych-warzyw-i-owocow](https://www.rp.pl/handel/art39124271-ukraina-pozwie-polske-slowacje-i-wegry-ograniczy-import-naszych-warzyw-i-owocow)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:15:10+00:00

Pozew wobec Polski i retorsje – to efekt polskiego zakazu importu ukraińskiego zboża. Wiceminister rolnictwa Ukrainy mówi, że Kijów szykuje pozew wobec Polski, Węgier i Słowacji do WTO oraz ograniczy import naszych warzyw i owoców.

## Krzysztof Brejza ujawnia zdjęcia, które są "najbardziej strzeżoną tajemnicą państwa PiS"
 - [https://www.rp.pl/wybory/art39124521-krzysztof-brejza-ujawnia-zdjecia-ktore-sa-najbardziej-strzezona-tajemnica-panstwa-pis](https://www.rp.pl/wybory/art39124521-krzysztof-brejza-ujawnia-zdjecia-ktore-sa-najbardziej-strzezona-tajemnica-panstwa-pis)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:14:07+00:00

"Te zdjęcia nigdy nie miały ujrzeć światła dziennego" - pisze na swoim profilu w serwisie X (dawny Twitter) senator Koalicji Obywatelskiej, Krzysztof Brejza.

## Gwałtowne zamieszki na festiwalu erytrejskim w Stuttgarcie. Politycy domagają się surowych konsekwencji
 - [https://www.rp.pl/przestepczosc/art39124551-gwaltowne-zamieszki-na-festiwalu-erytrejskim-w-stuttgarcie-politycy-domagaja-sie-surowych-konsekwencji](https://www.rp.pl/przestepczosc/art39124551-gwaltowne-zamieszki-na-festiwalu-erytrejskim-w-stuttgarcie-politycy-domagaja-sie-surowych-konsekwencji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:07:31+00:00

W Stuttgarcie doszło do gwałtownych zamieszek podczas festiwalu erytrejskiego. Do podobnej sytuacji doszło w lipcu w Giessen. 26 policjantów zostało rannych. Związek zawodowy policji domaga się konsekwencji.

## Dekada Konin. Końcowe odliczanie
 - [https://www.rp.pl/nieruchomosci/art39124531-dekada-konin-koncowe-odliczanie](https://www.rp.pl/nieruchomosci/art39124531-dekada-konin-koncowe-odliczanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:02:42+00:00

Galeria w kompleksie komunikacyjno-handlowym w Koninie zostanie otwarta pod koniec października. Pierwszych podróżnych przywitał już dworzec kolejowy.

## Sąd Najwyższy wyda ważne orzeczenie ws. sędziów stanu wojennego
 - [https://www.rp.pl/sady-i-trybunaly/art39124401-sad-najwyzszy-wyda-wazne-orzeczenie-ws-sedziow-stanu-wojennego](https://www.rp.pl/sady-i-trybunaly/art39124401-sad-najwyzszy-wyda-wazne-orzeczenie-ws-sedziow-stanu-wojennego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T09:00:05+00:00

Izba Odpowiedzialności Zawodowej Sądu Najwyższego rozstrzygnie zagadnienia prawne, które mają fundamentalne znaczenie dla możliwości pociągnięcia do odpowiedzialności karnej sędziów wydających w okresie stanu wojennego niesprawiedliwe wyroki, skazujące działaczy opozycji demokratycznej  - informuje Instytut Pamięci Narodowej.

## Lustro mistrza Janusza Stannego
 - [https://www.rp.pl/kultura/art39124201-lustro-mistrza-janusza-stannego](https://www.rp.pl/kultura/art39124201-lustro-mistrza-janusza-stannego)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:57:00+00:00

Wystawa plakatów i ilustracji Janusza Stannego „Dzieciaki” zostanie otwarta 21 września w lubelskim Centrum Spotkania Kultur.

## Gruzińskie władze ujawniają „plany wywołania niepokojów społecznych” przez m.in. „młodzież szkoloną na granicy polsko-ukraińskiej”
 - [https://www.rp.pl/polityka/art39124311-gruzinskie-wladze-ujawniaja-plany-wywolania-niepokojow-spolecznych-przez-m-in-mlodziez-szkolona-na-granicy-polsko-ukrainskiej](https://www.rp.pl/polityka/art39124311-gruzinskie-wladze-ujawniaja-plany-wywolania-niepokojow-spolecznych-przez-m-in-mlodziez-szkolona-na-granicy-polsko-ukrainskiej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:53:53+00:00

Służba Bezpieczeństwa Państwowego Gruzji wydała komunikat, w którym twierdzi, że „pewna grupa ludzi, zarówno w Gruzji, jak i poza nią” organizuje spisek, mający na celu „destabilizację i wywołanie niepokojów społecznych” w tym kraju.

## Kosiniak-Kamysz: Z silną pozycją Trzeciej Drogi opozycja może przejąć rządy
 - [https://www.rp.pl/polityka/art39124351-kosiniak-kamysz-z-silna-pozycja-trzeciej-drogi-opozycja-moze-przejac-rzady](https://www.rp.pl/polityka/art39124351-kosiniak-kamysz-z-silna-pozycja-trzeciej-drogi-opozycja-moze-przejac-rzady)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:49:00+00:00

Najważniejsze, by każdy odrobił swoją lekcję. Im wynik każdego z naszych komitetów będzie lepszy, tym sukces pewniejszy. Nie powinniśmy podkładać sobie nóg – bez kuksańców, bez uszczypliwości i złośliwości. To jest prośba przede wszystkim do fanów największego ugrupowania opozycyjnego – prosimy o szacunek. To niewiele kosztuje, a daje pozytywne efekty - mówił w programie #RZECZoPOLITYCE Władysław Kosiniak-Kamysz, lider PSL.

## Nadal mało nowych inwestycji biurowych
 - [https://www.rp.pl/nieruchomosci/art39124341-nadal-malo-nowych-inwestycji-biurowych](https://www.rp.pl/nieruchomosci/art39124341-nadal-malo-nowych-inwestycji-biurowych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:46:56+00:00

Rynek biurowy szuka równowagi w trudnym otoczeniu - oceniają eksperci Walter Herz.

## Marek Kozubal: Mariusz Błaszczak ujawnia tajne plany obrony Polski. Co jeszcze może pokazać Rosjanom?
 - [https://www.rp.pl/publicystyka/art39124181-marek-kozubal-mariusz-blaszczak-ujawnia-tajne-plany-obrony-polski-co-jeszcze-moze-pokazac-rosjanom](https://www.rp.pl/publicystyka/art39124181-marek-kozubal-mariusz-blaszczak-ujawnia-tajne-plany-obrony-polski-co-jeszcze-moze-pokazac-rosjanom)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:35:25+00:00

Na potrzeby partyjnej młócki polski minister obrony narodowej pokazuje dokumenty, które przez następne lata powinny być tajne, obniża tym samą naszą wiarygodność w NATO.

## Krajowe indeksy na plusach, wbrew Europie
 - [https://www.rp.pl/gielda/art39124321-krajowe-indeksy-na-plusach-wbrew-europie](https://www.rp.pl/gielda/art39124321-krajowe-indeksy-na-plusach-wbrew-europie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:33:26+00:00

Poniedziałkowy handel na warszawskim parkiecie upływa pod znakiem dość ograniczonych zmian głównych indeksów.

## Twórcy chcą zapłaty za korzystanie z ich utworów w sztucznej inteligencji
 - [https://www.rp.pl/abc-firmy/art39124281-tworcy-chca-zaplaty-za-korzystanie-z-ich-utworow-w-sztucznej-inteligencji](https://www.rp.pl/abc-firmy/art39124281-tworcy-chca-zaplaty-za-korzystanie-z-ich-utworow-w-sztucznej-inteligencji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:31:00+00:00

Stowarzyszenie reprezentujące twórców naukowych Kopipol apeluje o wprowadzenie licencjonowania utworów wykorzystywanych w produktach sztucznej inteligencji.

## Marian Banaś składa doniesienie do prokuratury na Elżbietę Witek
 - [https://www.rp.pl/prawo-karne/art39124231-marian-banas-sklada-doniesienie-do-prokuratury-na-elzbiete-witek](https://www.rp.pl/prawo-karne/art39124231-marian-banas-sklada-doniesienie-do-prokuratury-na-elzbiete-witek)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:30:57+00:00

Prezes Najwyższej Izby Kontroli Marian Banaś złożył do prokuratury zawiadomienie o możliwości popełnienia przestępstwa przez marszałek Sejmu Elżbietę Witek. Twierdzi, że marszałek Witek swymi zaniechaniami sparaliżowała pracę NIK - donosi radio RMF FM.

## Bułgaria: Dron z materiałami wybuchowymi w nadmorskim miasteczku. Nie wiadomo skąd
 - [https://www.rp.pl/konflikty-zbrojne/art39124161-bulgaria-dron-z-materialami-wybuchowymi-w-nadmorskim-miasteczku-nie-wiadomo-skad](https://www.rp.pl/konflikty-zbrojne/art39124161-bulgaria-dron-z-materialami-wybuchowymi-w-nadmorskim-miasteczku-nie-wiadomo-skad)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:19:06+00:00

Bułgarskie Ministerstwo Obrony wysłało specjalną jednostkę, aby zbadać i rozbroić drona przenoszącego materiały wybuchowe, który pojawił się w środę wieczorem w rejonie miasteczka Tyulenowo, na bułgarskim wybrzeżu Morza Czarnego.

## Policja z Biełgorodu szuka nieznanych sprawców, którzy podpalili literę Z
 - [https://www.rp.pl/konflikty-zbrojne/art39124131-policja-z-bielgorodu-szuka-nieznanych-sprawcow-ktorzy-podpalili-litere-z](https://www.rp.pl/konflikty-zbrojne/art39124131-policja-z-bielgorodu-szuka-nieznanych-sprawcow-ktorzy-podpalili-litere-z)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T08:09:17+00:00

Rosyjska policja poszukuje nieznanych sprawców, którzy podpalili propagandową konstrukcję w kształcie litery Z w Biełgorodzie.

## Kobieta, której boi się koronawirus. Doktor Marika Turek o swoich wyjątkowych badaniach
 - [https://kobieta.rp.pl/nauka/art39123901-kobieta-ktorej-boi-sie-koronawirus-doktor-marika-turek-o-swoich-wyjatkowych-badaniach](https://kobieta.rp.pl/nauka/art39123901-kobieta-ktorej-boi-sie-koronawirus-doktor-marika-turek-o-swoich-wyjatkowych-badaniach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:58:36+00:00

Większość ludzi prawie zapomniała już o pandemii koronawirusa, a w jej pracy zawodowej zmaganie się z nią to wciąż codzienność. Naukowczyni opowiada o tym, jak leki przeciwnadciśnieniowe mogą pomóc w walce z COVID-19.

## Park logistyczny w Gdańsku w nowych rękach
 - [https://www.rp.pl/nieruchomosci/art39124121-park-logistyczny-w-gdansku-w-nowych-rekach](https://www.rp.pl/nieruchomosci/art39124121-park-logistyczny-w-gdansku-w-nowych-rekach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:57:53+00:00

W pełni wynajęty magazyn 7R City Flex Gdańsk II od spółki 7R kupuje GLP Europe.

## Kiedy dress code w firmie staje się dyskryminacją? Czego może wymagać pracodawca od pracowników w kwestii wyglądu
 - [https://kobieta.rp.pl/prawo/art39123811-kiedy-dress-code-w-firmie-staje-sie-dyskryminacja-czego-moze-wymagac-pracodawca-od-pracownikow-w-kwestii-wygladu](https://kobieta.rp.pl/prawo/art39123811-kiedy-dress-code-w-firmie-staje-sie-dyskryminacja-czego-moze-wymagac-pracodawca-od-pracownikow-w-kwestii-wygladu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:47:12+00:00

Czy pracodawca może ingerować w strój pracownika? Czy wolno mu narzucać ograniczenia dotyczące fryzury, tatuaży czy makijażu? A co w sytuacji, gdy tożsamość odczuwana przez pracownika i wyrażana w wyglądzie nie pokrywa się z oczekiwaniami pracodawcy w tym zakresie?

## Środowisko Radia Maryja krytykuje Rafała Trzaskowskiego. Przekonuje o „szkalowaniu” Tadeusza Rydzyka
 - [https://www.rp.pl/polityka/art39123951-srodowisko-radia-maryja-krytykuje-rafala-trzaskowskiego-przekonuje-o-szkalowaniu-tadeusza-rydzyka](https://www.rp.pl/polityka/art39123951-srodowisko-radia-maryja-krytykuje-rafala-trzaskowskiego-przekonuje-o-szkalowaniu-tadeusza-rydzyka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:35:43+00:00

Prezydent Warszawy Rafał Trzaskowski został skrytykowany przez Zespół Wspierania Radia Maryja za rzekome „fake newsy” dotyczące dyrektora rozgłośni, o. Tadeusza Rydzyka.

## Traveldata: Październikowe wyjazdy z biurami podróży droższe, ale tańsze
 - [https://turystyka.rp.pl/biura-podrozy/art39123981-traveldata-pazdziernikowe-wyjazdy-z-biurami-podrozy-drozsze-ale-tansze](https://turystyka.rp.pl/biura-podrozy/art39123981-traveldata-pazdziernikowe-wyjazdy-z-biurami-podrozy-drozsze-ale-tansze)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:33:57+00:00

Chociaż w ostatnim tygodniu oferty wyjazdów zagranicznych poszły nieco w górę, to i tak były dużo tańsze niż jeszcze miesiąc temu. Grecja potaniała o 1068 złotych, Bułgaria o 664 złote, a Turcja o 586 złotych – pokazuje badanie Traveldaty.

## PiS ujawnił tajne plany obrony Polski. Jarosław Kaczyński: Wygląda, jakby zgadzano się na likwidację państwa w dzisiejszych granicach
 - [https://www.rp.pl/polityka/art39123971-pis-ujawnil-tajne-plany-obrony-polski-jaroslaw-kaczynski-wyglada-jakby-zgadzano-sie-na-likwidacje-panstwa-w-dzisiejszych-granicach](https://www.rp.pl/polityka/art39123971-pis-ujawnil-tajne-plany-obrony-polski-jaroslaw-kaczynski-wyglada-jakby-zgadzano-sie-na-likwidacje-panstwa-w-dzisiejszych-granicach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:33:15+00:00

- To było skazanie wielkiej części Polski na okupację rosyjską, a może po prostu skazanie Polski na okupację - mówi Jarosław Kaczyński, prezes PiS, w rozmowie z "Gazetą Polską", komentując ujawniony przez PiS tajny plan obrony Polski przyjęty w 2011 roku w czasie, gdy władzę sprawowała koalicja PO-PSL.

## Zakończono najtrudniejszy etap budowy trasy S1
 - [https://moto.rp.pl/tu-i-teraz/art39123931-zakonczono-najtrudniejszy-etap-budowy-trasy-s1](https://moto.rp.pl/tu-i-teraz/art39123931-zakonczono-najtrudniejszy-etap-budowy-trasy-s1)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:32:15+00:00

Zakończono budowę dwóch tuneli w ramach drogi ekspresowej S1 Przybędza – Milówka. To był najtrudniejszy etap budowy trasy na południu Polski.

## Uciekające promocje i pośrednik udający sklep. UOKiK nakłada 100 tys. zł kary
 - [https://www.rp.pl/konsumenci/art39123961-uciekajace-promocje-i-posrednik-udajacy-sklep-uokik-naklada-100-tys-zl-kary](https://www.rp.pl/konsumenci/art39123961-uciekajace-promocje-i-posrednik-udajacy-sklep-uokik-naklada-100-tys-zl-kary)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:31:07+00:00

Prezes Urzędu Ochrony Konkurencji i Konsumentów nałożył ponad 100 tys. zł za nieuczciwe praktyki na stronach internetowych bigotka.pl i arkadie.pl. Urząd zarzuca brak jasnej informacji, że konsument kupuje u pośrednika. Do szybkich zakupów namawiał licznik, który codziennie od nowa zachęcał do skorzystania z tych samych ofert.

## Armia USA zgubiła samolot F-35. Prosi o pomoc w poszukiwaniach
 - [https://www.rp.pl/swiat/art39123881-armia-usa-zgubila-samolot-f-35-prosi-o-pomoc-w-poszukiwaniach](https://www.rp.pl/swiat/art39123881-armia-usa-zgubila-samolot-f-35-prosi-o-pomoc-w-poszukiwaniach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T07:12:54+00:00

Amerykańskie wojsko prosi o pomoc w odnalezieniu zaginionego myśliwca F-35 po tym, jak w wyniku „nieszczęśliwego wypadku” pilot katapultował się z maszyny.

## Tesla przegrywa z klientem w sądzie. Musi zapłacić prawie milion złotych
 - [https://moto.rp.pl/na-prad/art39123831-tesla-przegrywa-z-klientem-w-sadzie-musi-zaplacic-prawie-milion-zlotych](https://moto.rp.pl/na-prad/art39123831-tesla-przegrywa-z-klientem-w-sadzie-musi-zaplacic-prawie-milion-zlotych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T06:45:41+00:00

Pewien Norweg odmówił odbioru Tesli Model S, ponieważ nie była ona zgodna z obietnicami producenta. Sprawa swój finał znalazła w sądzie i teraz, po 5,5 latach zapadł prawomocny wyrok.

## Elon Musk skomentował postępy ukraińskiej kontrofensywy. Odpowiedział na wpis przeciwnika wsparcia dla Kijowa
 - [https://www.rp.pl/konflikty-zbrojne/art39123821-elon-musk-skomentowal-postepy-ukrainskiej-kontrofensywy-odpowiedzial-na-wpis-przeciwnika-wsparcia-dla-kijowa](https://www.rp.pl/konflikty-zbrojne/art39123821-elon-musk-skomentowal-postepy-ukrainskiej-kontrofensywy-odpowiedzial-na-wpis-przeciwnika-wsparcia-dla-kijowa)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T06:35:29+00:00

„Tak wiele śmierci za tak niewiele” - napisał na platformie X (dawniej Twitter) jej właściciel Elon Musk, komentując ukraińską kontrofensywę.

## Sondaż: Większość Polaków nie wierzy w zapewnienia PiS-u o zatrzymaniu migracji
 - [https://www.rp.pl/spoleczenstwo/art39123791-sondaz-wiekszosc-polakow-nie-wierzy-w-zapewnienia-pis-u-o-zatrzymaniu-migracji](https://www.rp.pl/spoleczenstwo/art39123791-sondaz-wiekszosc-polakow-nie-wierzy-w-zapewnienia-pis-u-o-zatrzymaniu-migracji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T06:00:31+00:00

Ponad połowa ankietowanych Polaków nie daje wiary zapewnieniom rządu o odpowiednim zabezpieczeniu granic Polski przed niekontrolowaną migracją - wynika z sondażu, przeprowadzonego po ujawnieniu tzw. afery wizowej.

## Michał Szczerba: W wydawaniu polskich wiz pośredniczyła firma z Rosji
 - [https://www.rp.pl/polityka/art39123761-michal-szczerba-w-wydawaniu-polskich-wiz-posredniczyla-firma-z-rosji](https://www.rp.pl/polityka/art39123761-michal-szczerba-w-wydawaniu-polskich-wiz-posredniczyla-firma-z-rosji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T05:53:16+00:00

- PiS obiecywał bezpieczeństwo, a stworzył zagrożenie - mówił w rozmowie z TVN24 poseł KO, Michał Szczerba.

## Szef MSZ Chin w Rosji. Przygotowuje szczyt Xi Jinping-Władimir Putin?
 - [https://www.rp.pl/dyplomacja/art39123731-szef-msz-chin-w-rosji-przygotowuje-szczyt-xi-jinping-wladimir-putin](https://www.rp.pl/dyplomacja/art39123731-szef-msz-chin-w-rosji-przygotowuje-szczyt-xi-jinping-wladimir-putin)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T05:20:55+00:00

Wang Yi, szef MSZ Chin, rozpoczął w poniedziałek czterodniową wizytę w Rosji, która może być przygotowaniem do szczytu z udziałem prezydenta Chin, Xi Jinpinga i prezydenta Rosji, Władimira Putina.

## Indeks samorządności: Głos samorządu niesłyszalny w świecie wielkiej polityki
 - [https://www.rp.pl/finanse/art39122381-indeks-samorzadnosci-glos-samorzadu-nieslyszalny-w-swiecie-wielkiej-polityki](https://www.rp.pl/finanse/art39122381-indeks-samorzadnosci-glos-samorzadu-nieslyszalny-w-swiecie-wielkiej-polityki)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T05:20:08+00:00

Polski system finansowania nie uwzględnia potrzeb małych wspólnot, a zmiany legislacyjne wprowadza się bez pytania ich o zdanie – ocenia Fundacja Batorego.

## Minister spraw zagranicznych Zbigniew Rau: Afera wizowa nie istnieje
 - [https://www.rp.pl/polityka/art39123701-minister-spraw-zagranicznych-zbigniew-rau-afera-wizowa-nie-istnieje](https://www.rp.pl/polityka/art39123701-minister-spraw-zagranicznych-zbigniew-rau-afera-wizowa-nie-istnieje)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T04:47:00+00:00

Zbigniew Rau, szef MSZ, wypowiedział się w sprawie afery wizowej w Nowym Jorku, gdzie przebywa w związku z posiedzeniem Zgromadzenia Ogólnego ONZ. Zdaniem Raua afera wizowa "nie istnieje". To pierwsza wypowiedź Raua ws. afery wizowej od momentu jej ujawnienia przez media.

## Sondaż: Afera wizowa oddala PiS od trzeciej kadencji
 - [https://www.rp.pl/wybory/art39123021-sondaz-afera-wizowa-oddala-pis-od-trzeciej-kadencji](https://www.rp.pl/wybory/art39123021-sondaz-afera-wizowa-oddala-pis-od-trzeciej-kadencji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T04:00:00+00:00

Partia Jarosława Kaczyńskiego utrzymuje pierwsze miejsce w sondażach poparcia i ma spore szanse na to, by rządzić trzecią kadencję. Czy zmieni to afera wizowa?

## Zwinny, wyrazisty i dynamiczny. SUV, który bryluje na europejskich salonach.
 - [https://moto.rp.pl/tu-i-teraz/art39114971-zwinny-wyrazisty-i-dynamiczny-suv-ktory-bryluje-na-europejskich-salonach](https://moto.rp.pl/tu-i-teraz/art39114971-zwinny-wyrazisty-i-dynamiczny-suv-ktory-bryluje-na-europejskich-salonach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T04:00:00+00:00

Tylko w pierwszym półroczu bieżącego roku sprzedano w Europie ponad 77 tysięcy egzemplarzy tego modelu (dane Yato Dynamics). Puma pozostaje SUV-em wysoko ocenianym nie tylko przez dziennikarzy, lecz również przez klientów. Doceniliśmy ją za walory jezdne, mocne silniki i praktyczną kabinę. Jak przedstawia się aktualna oferta?

## Tajwan alarmuje: W ciągu doby 103 chińskie samoloty pojawiły się w pobliżu naszych granic
 - [https://www.rp.pl/dyplomacja/art39123661-tajwan-alarmuje-w-ciagu-doby-103-chinskie-samoloty-pojawily-sie-w-poblizu-naszych-granic](https://www.rp.pl/dyplomacja/art39123661-tajwan-alarmuje-w-ciagu-doby-103-chinskie-samoloty-pojawily-sie-w-poblizu-naszych-granic)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T03:55:00+00:00

Ministerstwo Obrony Tajwanu wezwało Chiny do "powstrzymania się od destrukcyjnych, jednostronnych działań" po zaobserwowaniu "gwałtownego wzrostu" chińskiej aktywności wojskowej w pobliżu wyspy.

## Pavel Šolc, prezes zarządu VW Group Polska: Elektromobilność  nabiera dużego rozpędu
 - [https://moto.rp.pl/rozmowa-moto-rp-pl/art39123641-pavel-solc-prezes-zarzadu-vw-group-polska-elektromobilnosc-nabiera-duzego-rozpedu](https://moto.rp.pl/rozmowa-moto-rp-pl/art39123641-pavel-solc-prezes-zarzadu-vw-group-polska-elektromobilnosc-nabiera-duzego-rozpedu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T03:46:53+00:00

Jako Grupa Volkswagen mamy sporo atutów. Przede wszystkim nasze bogate know-how, długa tradycja marek, ich silny wizerunek, rozwinięte zakłady produkcyjne oraz szeroka sieć dealerska i serwisowa – mówi Pavel Šolc, prezes zarządu VW Group Polska.

## Białoruś twierdzi, że jest gotowa na wspólne ćwiczenia wojskowe z Polską
 - [https://www.rp.pl/dyplomacja/art39123631-bialorus-twierdzi-ze-jest-gotowa-na-wspolne-cwiczenia-wojskowe-z-polska](https://www.rp.pl/dyplomacja/art39123631-bialorus-twierdzi-ze-jest-gotowa-na-wspolne-cwiczenia-wojskowe-z-polska)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T03:33:49+00:00

Rada Bezpieczeństwa Białorusi ogłosiła, że jest gotowa na przeprowadzenie wspólnych ćwiczeń wojskowych z Polską.

## Donald Trump jest przekonany, że doprowadziłby do pokoju na Ukrainie. Nie chce powiedzieć jak
 - [https://www.rp.pl/dyplomacja/art39123611-donald-trump-jest-przekonany-ze-doprowadzilby-do-pokoju-na-ukrainie-nie-chce-powiedziec-jak](https://www.rp.pl/dyplomacja/art39123611-donald-trump-jest-przekonany-ze-doprowadzilby-do-pokoju-na-ukrainie-nie-chce-powiedziec-jak)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T03:14:00+00:00

- Powiedziałbym pewne rzeczy (Władimirowi) Putinowi. Powiedziałbym pewne rzeczy (Wołodymyrowi) Zełenskiemu - mówił Donald Trump w rozmowie z NBC News przekonując, iż byłby w stanie doprowadzić do zakończenia wojny Rosji z Ukrainą.

## Wojna Rosji z Ukrainą. Dzień 572
 - [https://www.rp.pl/swiat/art39123591-wojna-rosji-z-ukraina-dzien-572](https://www.rp.pl/swiat/art39123591-wojna-rosji-z-ukraina-dzien-572)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T02:44:40+00:00

24 lutego 2022 roku Rosja rozpoczęła pełnowymiarową inwazję na Ukrainę. W swoim wystąpieniu, w niedzielę wieczorem, prezydent Ukrainy, Wołodymyr Zelenski, podziękował ukraińskim przeciwlotnikom i Siłom Powietrznym za coraz większą liczbę strącanych rosyjskich rakiet.

## Zderzenie samolotów na wyścigach lotniczych w USA. Piloci zginęli
 - [https://www.rp.pl/wypadki/art39123571-zderzenie-samolotow-na-wyscigach-lotniczych-w-usa-piloci-zgineli](https://www.rp.pl/wypadki/art39123571-zderzenie-samolotow-na-wyscigach-lotniczych-w-usa-piloci-zgineli)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T02:06:33+00:00

Ostatnie w historii wyścigi lotnicze w amerykańskim Reno (Reno Air Races) zakończyły się tragedią - dwa samoloty klasy T-6 zderzyły się podczas lądowania. Piloci - zwycięzcy wyścigu - zginęli. Okoliczności katastrofy są badane.

## 100 dolarów za baryłkę ropy? Jeśli tak, to nie na długo
 - [https://energia.rp.pl/ropa/art39123191-100-dolarow-za-barylke-ropy-jesli-tak-to-nie-na-dlugo](https://energia.rp.pl/ropa/art39123191-100-dolarow-za-barylke-ropy-jesli-tak-to-nie-na-dlugo)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Polityka Rosji i Arabii Saudyjskiej wywindowała ceny ropy. Jednak zdaniem większości finansistów ustabilizują się one poniżej pułapu 100 dol. za baryłkę, bo z czasem niedobory rynkowe będą ustępować.

## Czemu zachodni biznes ociąga się z opuszczeniem Putina?
 - [https://www.rp.pl/biznes/art39123141-czemu-zachodni-biznes-ociaga-sie-z-opuszczeniem-putina](https://www.rp.pl/biznes/art39123141-czemu-zachodni-biznes-ociaga-sie-z-opuszczeniem-putina)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Niektóre spółki nie chcą wychodzić z rynku rosyjskiego, licząc, że za jakiś czas konflikt zostanie zamrożony. Inne znalazły się w pułapce. Ryzykują, że zostaną wywłaszczone, jeśli będą próbowały sprzedać aktywa po dobrej cenie.

## Ekstra bonus na pożegnanie pracownika
 - [https://www.rp.pl/rynek-pracy/art39123151-ekstra-bonus-na-pozegnanie-pracownika](https://www.rp.pl/rynek-pracy/art39123151-ekstra-bonus-na-pozegnanie-pracownika)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Większość pracodawców, którzy wspierają zwalnianych pracowników programami outplacementu, oferuje im także dodatkową odprawę.

## Festiwal Polskich Filmów Fabularnych. Powrót służb specjalnych PRL
 - [https://www.rp.pl/film/art39122231-festiwal-polskich-filmow-fabularnych-powrot-sluzb-specjalnych-prl](https://www.rp.pl/film/art39122231-festiwal-polskich-filmow-fabularnych-powrot-sluzb-specjalnych-prl)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

„Doppenganger. Sobowtór” Jana Holoubka o powikłanych polsko-niemieckich losach z II wojną światową w tle otworzy 18 września wieczorem Festiwal Polskich Filmów Fabularnych.

## Import zboża z Ukrainy znów podzielił Unię
 - [https://www.rp.pl/handel/art39123201-import-zboza-z-ukrainy-znow-podzielil-unie](https://www.rp.pl/handel/art39123201-import-zboza-z-ukrainy-znow-podzielil-unie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Bruksela znosi embargo na ukraińskie zboże. Polska, Węgry i Słowacja zakaz utrzymują, a nawet rozszerzają.

## Jacek Nizinkiewicz: Wszystkie kłamstwa PiS o aferze wizowej
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39122041-jacek-nizinkiewicz-wszystkie-klamstwa-pis-o-aferze-wizowej](https://www.rp.pl/opinie-polityczno-spoleczne/art39122041-jacek-nizinkiewicz-wszystkie-klamstwa-pis-o-aferze-wizowej)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Partia Jarosława Kaczyńskiego traci wiarygodność w temacie bezpieczeństwa i migrantów. Piotr Wawrzyk nie był jedyną osobą z rządu zamieszaną w proceder.

## Jak pensje nauczycieli liczy minister Przemysław Czarnek? Sytuacja pedagogów wcale się nie poprawi
 - [https://edukacja.rp.pl/oswiata/art39122051-jak-pensje-nauczycieli-liczy-minister-przemyslaw-czarnek-sytuacja-pedagogow-wcale-sie-nie-poprawi](https://edukacja.rp.pl/oswiata/art39122051-jak-pensje-nauczycieli-liczy-minister-przemyslaw-czarnek-sytuacja-pedagogow-wcale-sie-nie-poprawi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Niskie płace w oświacie ani nie zachęcają do podejmowania pracy w szkole, ani nie motywują nauczycieli do rozwoju zawodowego.

## Kolej na bezpieczną energię
 - [https://www.rp.pl/biznes/art39123551-kolej-na-bezpieczna-energie](https://www.rp.pl/biznes/art39123551-kolej-na-bezpieczna-energie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Wymagania przewoźników kolejowych w zakresie dostaw energii ciągle rosną. Sektor potrzebuje stabilnych dostaw, nowoczesnej infrastruktury i coraz więcej zielonej energii. Tego samego domagają się też pasażerowie. PGE Energetyka Kolejowa dostarcza rozwiązań, które spełniają te oczekiwania.

## Marek A. Cichocki: Przyszłość nie należy do młodych
 - [https://www.rp.pl/opinie-polityczno-spoleczne/art39123011-marek-a-cichocki-przyszlosc-nie-nalezy-do-mlodych](https://www.rp.pl/opinie-polityczno-spoleczne/art39123011-marek-a-cichocki-przyszlosc-nie-nalezy-do-mlodych)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Wystarczy zestawić statystyki uczestnictwa w wyborach po 1989 r. ludzi młodych i starszych, aby się przekonać, że nasze nadzieje dotyczące sprawczości młodych w polityce rozmijają się z rzeczywistością.

## Mercosur: demokratyczna alternatywa wobec Chin i Rosji
 - [https://www.rp.pl/swiat/art39122081-mercosur-demokratyczna-alternatywa-wobec-chin-i-rosji](https://www.rp.pl/swiat/art39122081-mercosur-demokratyczna-alternatywa-wobec-chin-i-rosji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Po przeszło dwóch dekadach negocjacji Unia Europejska i Mercosur (Brazylia, Argentyna, Paragwaj i Urugwaj) są u progu zawarcia umowy o utworzeniu największego porozumienia o wolnym handlu na świecie.

## Niemcy konkurują z Tajlandią jako cel turystyki seksualnej. Policja jest bezsilna
 - [https://www.rp.pl/spoleczenstwo/art39122221-niemcy-konkuruja-z-tajlandia-jako-cel-turystyki-seksualnej-policja-jest-bezsilna](https://www.rp.pl/spoleczenstwo/art39122221-niemcy-konkuruja-z-tajlandia-jako-cel-turystyki-seksualnej-policja-jest-bezsilna)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Mimo rosnącej krytyki instytucji UE nie widać nad Łabą chęci zmiany najbardziej w Europie liberalnego prawa dotyczącego prostytucji.

## Niemiłe zaskoczenie dla rządu przed wyborami
 - [https://www.rp.pl/handel/art39123211-niemile-zaskoczenie-dla-rzadu-przed-wyborami](https://www.rp.pl/handel/art39123211-niemile-zaskoczenie-dla-rzadu-przed-wyborami)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Polska wprowadziła zakaz wwozu towarów rolnych z Ukrainy samodzielnie, krytykuje też UE za decyzje polityczne „na szkodę Polski”. Ale to właśnie embargo Warszawy jest wynikiem przedwyborczej walki o głosy rolników.

## Polscy siatkarze mistrzami Europy. Drużyna to jest siła
 - [https://www.rp.pl/siatkowka/art39122981-polscy-siatkarze-mistrzami-europy-druzyna-to-jest-sila](https://www.rp.pl/siatkowka/art39122981-polscy-siatkarze-mistrzami-europy-druzyna-to-jest-sila)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Polacy pokazali podczas mistrzostw Europy, że to nie jednostki zdobywają medale. Widzieliśmy to zarówno w trakcie meczów, jak i poza boiskiem.

## Płaca minimalna nie dla nauczycieli. „Do grupy poniżej niej dołączą nauczyciele mianowani”
 - [https://edukacja.rp.pl/oswiata/art39123031-placa-minimalna-nie-dla-nauczycieli-do-grupy-ponizej-niej-dolacza-nauczyciele-mianowani](https://edukacja.rp.pl/oswiata/art39123031-placa-minimalna-nie-dla-nauczycieli-do-grupy-ponizej-niej-dolacza-nauczyciele-mianowani)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Nawet jeśli ich wynagrodzenia wzrosną o zapowiedziane 12,3 proc., to i tak będą zarabiać mniej niż najniższa krajowa.

## Rośnie jakość życia cyfrowego w Polsce. Ale dobrze nie jest
 - [https://www.rp.pl/biznes/art39123221-rosnie-jakosc-zycia-cyfrowego-w-polsce-ale-dobrze-nie-jest](https://www.rp.pl/biznes/art39123221-rosnie-jakosc-zycia-cyfrowego-w-polsce-ale-dobrze-nie-jest)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Na miesięczną opłatę za stacjonarny internet szerokopasmowy musimy pracować cztery razy dłużej niż Rumuni, a mobilne łącza internetowe mamy o 38 procent wolniejsze niż Litwini.

## Studenci znajdą mentorów także na rynku mody
 - [https://www.rp.pl/rynek-pracy/art39123181-studenci-znajda-mentorow-takze-na-rynku-mody](https://www.rp.pl/rynek-pracy/art39123181-studenci-znajda-mentorow-takze-na-rynku-mody)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Już pięć ścieżek tematycznych będą mieli do wyboru młodzi ludzie z Polski i Ukrainy, którzy wezmą udział w VII edycji programu mentoringowego firmy Boston Consulting Group.

## Trudna integracja młodych uchodźców. Poczucie inności i wyobcowania między uczniami polskimi i ukraińskimi
 - [https://www.rp.pl/spoleczenstwo/art39122061-trudna-integracja-mlodych-uchodzcow-poczucie-innosci-i-wyobcowania-miedzy-uczniami-polskimi-i-ukrainskimi](https://www.rp.pl/spoleczenstwo/art39122061-trudna-integracja-mlodych-uchodzcow-poczucie-innosci-i-wyobcowania-miedzy-uczniami-polskimi-i-ukrainskimi)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Polscy i ukraińscy uczniowie funkcjonują nie razem, ale obok siebie. Problemem jest język, kultura i poczucie tymczasowości lub uprzywilejowania – wskazuje raport o młodych uchodźcach w polskich szkołach.

## Wizy za łapówki. Kulisy afery w MSZ
 - [https://www.rp.pl/kraj/art39122031-wizy-za-lapowki-kulisy-afery-w-msz](https://www.rp.pl/kraj/art39122031-wizy-za-lapowki-kulisy-afery-w-msz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Edgar K. jako kluczowy pośrednik w załatwianiu wiz, hinduski biznesmen wśród tych, którzy za nie płacili.

## Wojenka wokół przekopu mierzei i portu w Elblągu
 - [https://www.rp.pl/transport/art39123231-wojenka-wokol-przekopu-mierzei-i-portu-w-elblagu](https://www.rp.pl/transport/art39123231-wojenka-wokol-przekopu-mierzei-i-portu-w-elblagu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Wartość zakontraktowanych wydatków na przekopanie mierzei oraz modernizację toru wodnego na Zalewie Wiślanym i rzece Elbląg sięgnęła już 1,97 mld zł. Na razie to dosłownie utopione pieniądze.

## Wracamy do pracy do biur, ale nie na stałe
 - [https://www.rp.pl/rynek-pracy/art39123161-wracamy-do-pracy-do-biur-ale-nie-na-stale](https://www.rp.pl/rynek-pracy/art39123161-wracamy-do-pracy-do-biur-ale-nie-na-stale)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

Większość firm chciałaby przywrócić pełną pracę stacjonarną, lecz opór pracowników często ogranicza takie zapędy.

## Zuzanna Dąbrowska: Korepetycje z rachunków dla ministra Przemysława Czarnka
 - [https://www.rp.pl/komentarze/art39123001-zuzanna-dabrowska-korepetycje-z-rachunkow-dla-ministra-przemyslawa-czarnka](https://www.rp.pl/komentarze/art39123001-zuzanna-dabrowska-korepetycje-z-rachunkow-dla-ministra-przemyslawa-czarnka)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

W kampanii wyborczej wszystko przelicza się na głosy. Rząd PiS robi dużo, żeby te rachunki wypadły dla niego jak najlepiej, dając sobie szanse na kolejną kadencję. Ale z poparcia nauczycieli chyba już na dobre zrezygnował.

## „Rymkiewicz. Encyklopedia”. Jarosław Marek Rymkiewicz na własnych zasadach
 - [https://www.rp.pl/literatura/art39122241-rymkiewicz-encyklopedia-jaroslaw-marek-rymkiewicz-na-wlasnych-zasadach](https://www.rp.pl/literatura/art39122241-rymkiewicz-encyklopedia-jaroslaw-marek-rymkiewicz-na-wlasnych-zasadach)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T01:00:00+00:00

„Rymkiewicz. Encyklopedia” w Muzeum Literatury w Warszawie to pierwsza obszerna prezentacja dorobku, zmarłego przed rokiem, poety.

## Prokuratorskie wnioski o areszt sąd akceptuje bez refleksji
 - [https://www.rp.pl/prawo-karne/art39123311-prokuratorskie-wnioski-o-areszt-sad-akceptuje-bez-refleksji](https://www.rp.pl/prawo-karne/art39123311-prokuratorskie-wnioski-o-areszt-sad-akceptuje-bez-refleksji)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:05:00+00:00

Z impasu nie da się wyjść, nie zmieniając prawa i praktyki. Liczba aresztów może jeszcze wzrosnąć.

## Megaproste podatki? Doradca podatkowy: możliwe, ale nie od razu
 - [https://www.rp.pl/podatki/art39123091-megaproste-podatki-doradca-podatkowy-mozliwe-ale-nie-od-razu](https://www.rp.pl/podatki/art39123091-megaproste-podatki-doradca-podatkowy-mozliwe-ale-nie-od-razu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:02:00+00:00

Przed wyborami politycy licytują się, kto bardziej uprości i obniży podatki. Nie da się jednak zmienić całego systemu z dnia na dzień. Potrzebna jest ewolucja, bo rewolucja może przynieść więcej szkody niż pożytku – mówi Arkadiusz Łagowski, doradca podatkowy.

## Co nowego można uznać za koszt uzyskania przychodu
 - [https://www.rp.pl/podatki/art39113891-co-nowego-mozna-uznac-za-koszt-uzyskania-przychodu](https://www.rp.pl/podatki/art39113891-co-nowego-mozna-uznac-za-koszt-uzyskania-przychodu)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Urzędy podchodzą coraz bardziej swobodnie do kwestii wydatków zaliczanych do kosztów przez podatników, luźniej traktując warunek ich związku z prowadzoną działalnością gospodarczą.

## Inwestycje kapitałowe fundacji mogą być zwolnione z CIT
 - [https://www.rp.pl/podatki/art39113941-inwestycje-kapitalowe-fundacji-moga-byc-zwolnione-z-cit](https://www.rp.pl/podatki/art39113941-inwestycje-kapitalowe-fundacji-moga-byc-zwolnione-z-cit)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Fundacje rodzinne mogą inwestować w udziały w spółkach z o.o., akcje spółek akcyjnych, certyfikaty funduszy inwestycyjnych, inne papiery wartościowe, instrumenty pochodne i prawa o podobnym charakterze. O czym należy pamiętać?

## Jak rozliczyć zaliczkę na firmowy samochód
 - [https://www.rp.pl/podatki/art39113961-jak-rozliczyc-zaliczke-na-firmowy-samochod](https://www.rp.pl/podatki/art39113961-jak-rozliczyc-zaliczke-na-firmowy-samochod)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Przedsiębiorca może odliczyć VAT z faktur na zakup auta. Eksperci radzą wpisać do ewidencji obie: zaliczkową i końcową.

## Kiedy powstaje przychód od opłaty dodatkowej za parkowanie
 - [https://www.rp.pl/podatki/art39113951-kiedy-powstaje-przychod-od-oplaty-dodatkowej-za-parkowanie](https://www.rp.pl/podatki/art39113951-kiedy-powstaje-przychod-od-oplaty-dodatkowej-za-parkowanie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Opłaty dodatkowej za parkowanie nie należy traktować jako kary umownej, lecz jako wynagrodzenie za świadczoną usługę.

## Pobyt za kratami bez wyroku musi mieć granicę czasową. Debata w "Rz"
 - [https://www.rp.pl/prawo-karne/art39122391-pobyt-za-kratami-bez-wyroku-musi-miec-granice-czasowa-debata-w-rz](https://www.rp.pl/prawo-karne/art39122391-pobyt-za-kratami-bez-wyroku-musi-miec-granice-czasowa-debata-w-rz)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Aby ukrócić patologie z długotrwałymi aresztami, trzeba prawnie określić maksymalny czas ich trwania i odważyć się na wprowadzenie nowych środków, np. dozoru elektronicznego – uważają eksperci.

## Prowizja od udzielenia kredytu to pośredni koszt podatkowy
 - [https://www.rp.pl/podatki/art39113971-prowizja-od-udzielenia-kredytu-to-posredni-koszt-podatkowy](https://www.rp.pl/podatki/art39113971-prowizja-od-udzielenia-kredytu-to-posredni-koszt-podatkowy)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Koszty prowizji zapłaconej na rzecz instytucji finansowej mogą zostać podatkowo rozpoznane jednorazowo w dacie ich poniesienia, niezależnie od ich ujęcia w księgach rachunkowych. Moment uznania wydatku za koszt podatkowy nie jest bowiem uzależniony od uznania go za taki koszt w znaczeniu bilansowym.

## Reorganizacje transgraniczne pod kontrolą Szefa KAS
 - [https://www.rp.pl/podatki/art39113881-reorganizacje-transgraniczne-pod-kontrola-szefa-kas](https://www.rp.pl/podatki/art39113881-reorganizacje-transgraniczne-pod-kontrola-szefa-kas)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

15 września weszła w życie nowelizacja kodeksu spółek handlowych. Zmienione przepisy przewidują obowiązek uzyskania potwierdzenia organu podatkowego, że zamierzone działania nie stanowią nadużycia. A tu mogą pojawić się komplikacje.

## Rozliczenia w nettingu wyłączone z podzielonej płatności
 - [https://www.rp.pl/podatki/art39113901-rozliczenia-w-nettingu-wylaczone-z-podzielonej-platnosci](https://www.rp.pl/podatki/art39113901-rozliczenia-w-nettingu-wylaczone-z-podzielonej-platnosci)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

W przypadku regulowania salda – w kompensatach wielostronnych – wyliczanego na podstawie faktur dokumentujących czynności objęte obowiązkowym mechanizmem podzielonej płatności nie ma obowiązku dokonywania rozliczeń z zastosowaniem tego mechanizmu.

## Tomasz Pietryga: Sądy zbyt łatwo decydują o areszcie
 - [https://www.rp.pl/opinie-prawne/art39123101-tomasz-pietryga-sady-zbyt-latwo-decyduja-o-areszcie](https://www.rp.pl/opinie-prawne/art39123101-tomasz-pietryga-sady-zbyt-latwo-decyduja-o-areszcie)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

W Polsce zbyt często stosuje się tymczasowe aresztowanie, a jego przedłużanie to norma. Przestało być w ten sposób środkiem zapobiegawczym, a stało się karą bez wyroku.

## Ulgę rozlicza się w zeznaniu rocznym
 - [https://www.rp.pl/podatki/art39113931-ulge-rozlicza-sie-w-zeznaniu-rocznym](https://www.rp.pl/podatki/art39113931-ulge-rozlicza-sie-w-zeznaniu-rocznym)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Przedsiębiorca nie może uwzględnić wydatków na wspieranie kultury w trakcie roku – przy obliczaniu zaliczki na PIT.

## Wspieranie kultury pozwala na obniżenie podatku
 - [https://www.rp.pl/podatki/art39113911-wspieranie-kultury-pozwala-na-obnizenie-podatku](https://www.rp.pl/podatki/art39113911-wspieranie-kultury-pozwala-na-obnizenie-podatku)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Przedsiębiorca, który sfinansował wystawę lub koncert, oprócz zaliczenia tych wydatków do kosztów uzyskania przychodów, uzyska prawo do dodatkowej preferencji poprzez odliczenie połowy tych kwot od podstawy obliczenia PIT/CIT.

## Świadczenia muszą być wzajemne
 - [https://www.rp.pl/podatki/art39113921-swiadczenia-musza-byc-wzajemne](https://www.rp.pl/podatki/art39113921-swiadczenia-musza-byc-wzajemne)
 - RSS feed: https://www.rp.pl/rss_main
 - date published: 2023-09-18T00:00:00+00:00

Wartość świadczeń i towarów przekazywanych przez przedsiębiorcę na podstawie zawartych umów barterowych powinna odpowiadać wartości działań promocyjnych i reklamowych świadczonych przez sponsorowanego.

