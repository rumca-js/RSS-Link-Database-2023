# Source:PC world, URL:https://www.pcworld.com/index.rss, language:en-US

## How to register your own domain name
 - [https://www.pcworld.com/article/477298/how-to-register-your-own-domain-name.html](https://www.pcworld.com/article/477298/how-to-register-your-own-domain-name.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T19:06:22+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>One of the many reasons the internet is so powerful is because it gives nearly anyone the ability to share their voice and knowledge with the rest of the world. A particularly popular way to make yourself known is to set up a website. You get full control over the platform, unlike with social media.</p>



<p>These days many services, such as WordPress or Blogger, offer websites on commercial domains, but in a lot of cases it makes more sense to have your website on your own domain&mdash;a personal place on the internet where you are in complete control of what&rsquo;s published and how it looks. Here&rsquo;s how to register your own domain name.</p>



<p>When setting up your personal domain name, you have a lot of options and many vendors to choose from. You can search around to see what works best for you and your needs&mdash;or look over our suggestions belo

## As Microsoft’s consumer champion departs, so does its soul
 - [https://www.pcworld.com/article/2073226/as-microsofts-consumer-champion-steps-down-so-does-its-soul.html](https://www.pcworld.com/article/2073226/as-microsofts-consumer-champion-steps-down-so-does-its-soul.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T18:02:22+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>&ldquo;Panos Panay&rdquo; may not be an anagram for &ldquo;passion,&rdquo; but at Microsoft, it was pretty darn close. </p>



<p>Panos Panay, the chief product officer for Microsoft, unexpectedly <a href="https://www.pcworld.com/article/2073037/surface-creator-panos-panay-leaves-microsoft.html">stepped down</a> on Tuesday, after serving nearly twenty years at the company. Panay rose to the ranks of chief product officer, overseeing the development of Windows and its complementary Surface PC line. Interestingly, Panay gave no specific reason for leaving, and at press time had only posted a single message announcing his departure on Twitter/X.</p>



<p>Even more interestingly, Panay had originally <a href="https://go.redirectingat.com/?id=111346X1569483&amp;url=https://www.linkedin.com/feed/update/urn:li:activity:7101950708345667584/&amp;xcust=2-1-2073226-1-0-0&

## Surface mastermind and Windows chief Panos Panay leaves Microsoft
 - [https://www.pcworld.com/article/2073037/surface-creator-panos-panay-leaves-microsoft.html](https://www.pcworld.com/article/2073037/surface-creator-panos-panay-leaves-microsoft.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T16:00:14+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Though it&rsquo;s had its ups and downs, Microsoft&rsquo;s Surface line of tablets and laptops is generally viewed as a big success for the company, helping to shape both its own identity and the premium PC market over the last decade. The man in charge of it all is Panos Panay, a nearly 20-year veteran of Microsoft&rsquo;s executive group and a huge part of the Surface and Windows teams. Microsoft has announced that he&rsquo;s leaving the company as of today. His current plans aren&rsquo;t known. </p>



<p>Panay&rsquo;s ultimate title at Microsoft was &ldquo;Chief Product Officer,&rdquo; and he was a constant presence at the company&rsquo;s product announcements for both in-person and video events. Though he&rsquo;s an effective brand ambassador and hype man, he&rsquo;s also been an essential member of the company&rsquo;s higher-ups, credited with leading the 

## Microsoft wants to stream PC Game Pass games, too
 - [https://www.pcworld.com/article/2072865/microsoft-wants-to-stream-pc-game-pass-games-too.html](https://www.pcworld.com/article/2072865/microsoft-wants-to-stream-pc-game-pass-games-too.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T14:49:58+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Xbox Game Pass&rsquo;s <a href="https://www.pcworld.com/article/394418/microsoft-xbox-cloud-gaming-opens-to-all-game-pass-ultimate-subscribers-on-pc-and-ios.html">streaming powers are remarkable</a>, but so far they&rsquo;ve been limited to titles that have been released on Xbox consoles. Game Pass includes a ton of PC games (and plenty that are available on both), but in order to play them, you have to download the files locally and play them on a gaming PC. According to recently-revealed court documents, Microsoft was planning on adding PC games to the Game Pass streaming setup, competing directly with services like Nvidia&rsquo;s GeForce Now. </p>



<p>The info is not official, even though it was scrounged from internal Microsoft documents. As with a lot of corporate revelations as of late, you can thank a lawsuit for the news. This tidbit was revealed in an

## Seagate Ultra Touch external HDD review: Storage, services, and sustainability
 - [https://www.pcworld.com/article/2054924/seagate-ultra-touch-hdd-review.html](https://www.pcworld.com/article/2054924/seagate-ultra-touch-hdd-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T14:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Password protection with hardware encryption</li><li>30 percent recycled plastic and aluminium</li><li>Rescue service included</li><li>Trial subscriptions for Mylo Photos, Dropbox Backup Plan</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>Only Type-C to C cable supplied</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">A flexible external HDD for the environmentally conscious who need a lot of c

## How to test and change your motherboard’s CMOS battery
 - [https://www.pcworld.com/article/2072879/to-test-and-change-the-cmos-battery-of-the-mainboard.html](https://www.pcworld.com/article/2072879/to-test-and-change-the-cmos-battery-of-the-mainboard.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T14:17:55+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>When you disconnect your computer&rsquo;s power supply from the wall, it jumps in to save your BIOS or UEFI settings in your motherboard&rsquo;s CMOS-RAM (Complementary Metal-Oxide-Semiconductor). But even the most reliable battery only has a certain lifespan. Over time, a CMOS battery&rsquo;s performance can degrade and, in the worst case, can up the ghost before your motherboard is ready to say goodbye. </p>



<p>If that happens, the CMOS memory chip can no longer hold your BIOS settings between power cycles, resulting in a full BIOS reset. Gross. To counteract this, it&rsquo;s helpful to check the CMOS battery periodically. And the good news is you don&rsquo;t need highly specialized equipment to do it. </p>



<p>A simple method is to disconnect the PC from main power overnight. The next morning, if your computer does not require you to reset the date and t

## Amazon’s second Prime Day starts October 10th
 - [https://www.pcworld.com/article/2072738/amazons-second-prime-day-of-the-year-starts-october-10th.html](https://www.pcworld.com/article/2072738/amazons-second-prime-day-of-the-year-starts-october-10th.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T13:46:37+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Amazon&rsquo;s master plan has been laid bare. By the year 2300, every single day on the calendar will be Amazon Prime Day. Every month will be Amazon Prime Month, it will always be the year of the Amazon, and our homes will be entirely built of smiling cardboard boxes. Amazon hasn&rsquo;t officially stated that this is its plan, but the seeds of this future have been planted with a second Amazon Prime Day for 2023, now confirmed to be occurring on October 10th and 11th. The sale starts at 3 a.m. Eastern US time. </p>



<p>Technically the event is called &ldquo;Prime Big Deal Days,&rdquo; but we all know what it really is: An attempt by Amazon to create a second (er, third) retail holiday on the scale and breadth of Black Friday, but associated almost exclusively with its brand. <a href="https://www.pcworld.com/article/1963008/amazon-prime-day-2023-everything-y

## How to open Windows’ awesome Snipping Tool with a single key press
 - [https://www.pcworld.com/article/2065638/windows-10-11-how-to-open-the-snipping-tool-via-the-print-key.html](https://www.pcworld.com/article/2065638/windows-10-11-how-to-open-the-snipping-tool-via-the-print-key.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T13:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>You can take a screenshot of the entire screen in Windows using the Print key; the key combination Alt+Print captures an image of the currently open window. However, you can also set the Print key to call up the Snipping tool, i.e. the integrated screenshot app of Windows 10 and 11.</p>



<p>In Windows 10, call up <em>Settings</em> via the Start menu and open <em>Ease of Access</em>. Now scroll down in the column on the left and click on <em>Keyboard</em>. In the following window, scroll down again and set the switch for <em>Use the PrtScn button to open screen snipping</em> to <em>On</em>.</p>


<div class="extendedBlock-wrapper block-coreImage undefined"><figure class="wp-block-image size-large"><img alt="Windows 11 Snipping tool " class="wp-image-2065664" height="639" src="https://b2c-contenthub.com/wp-content/uploads/2023/09/snipping-tool.jpg?quality=50&amp

## 9 free AI tools that run locally on your PC
 - [https://www.pcworld.com/article/2064105/9-free-ai-tools-that-run-locally-on-the-pc.html](https://www.pcworld.com/article/2064105/9-free-ai-tools-that-run-locally-on-the-pc.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T11:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>It&rsquo;s no coincidence that many programs using artificial intelligence techniques are open source and thus completely free. This is because the early approaches originated in academia, where free licences for software are common practice in order to promote collaboration and further development.</p>



<p>Here, however, it is not about frameworks and libraries for forms of AI, but about tangible and useful applications of artificial intelligence for your own computer. The term AI encompasses various methods such as neural networks, machine learning, deep learning, or natural language processing. In the following compilation, all these approaches are represented.</p>



<blockquote class="wp-block-quote">
<p><strong>Further reading:</strong> <a href="https://www.pcworld.com/article/788422/how-to-get-started-with-ai-art-dall-e-mini-ai-dungeon-and-more.html">Ho

## Lemokey L3 review: Keychron’s first gaming keyboard misses the mark
 - [https://www.pcworld.com/article/2061339/lemokey-l3-gaming-keyboard-review.html](https://www.pcworld.com/article/2061339/lemokey-l3-gaming-keyboard-review.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T10:30:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>


<div class="review" id="review-body"><span class="review-title">At a glance</span><h3 class="review-subTitle" id="experts-rating">Expert's Rating</h3><div class="starRating"></div>
<div><div class="review-columns"><div class="review-column"><h3 class="review-subTitle" id="pros">Pros</h3><ul class="pros review-list"><li>Typical Keychron build quality</li><li>Bluetooth and 2.4GHz wireless</li><li>Lots of extras</li></ul></div><div class="review-column"><h3 class="review-subTitle" id="cons">Cons</h3><ul class="cons review-list"><li>No per-game programming </li><li>No adjustable typing angle</li><li>Takes forever to disassemble</li></ul></div></div></div><h3 class="review-subTitle review-subTitle--borderTop" id="our-verdict">Our Verdict</h3><p class="verdict">The Lemokey L3 offers a lot of what we love from a Keychron board, such as top-notch build quality and customiza

## Microsoft Office is just $34.97 right now
 - [https://www.pcworld.com/article/2071622/microsoft-office-is-just-34-97-right-now.html](https://www.pcworld.com/article/2071622/microsoft-office-is-just-34-97-right-now.html)
 - RSS feed: https://www.pcworld.com/index.rss
 - date published: 2023-09-18T08:00:00+00:00

<div id="link_wrapped_content">
<section class="wp-block-bigbite-multi-title"><div class="container"></div></section>



<p>Microsoft Office has stayed on top of the office suite pile despite the emergence of multiple competitors over recent years. The comprehensive suite is an outstanding resource for entrepreneurs, analysts, designers, and virtually anyone who works in a professional environment. Right now, however, you can get<a href="https://shop.pcworld.com/sales/microsoft-office-home-business-for-mac-2021-lifetime-license-6?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=microsoft-office-home-business-for-mac-2021-lifetime-license-6&amp;utm_term=scsf-579257&amp;utm_content=a0xRn0000000SM5IAM&amp;scsonar=1" rel="noreferrer noopener" target="_blank"> Microsoft Office for Mac</a> or <a href="https://shop.pcworld.com/sales/microsoft-office-professional-plus-2021-for-window?utm_source=pcworld.com&amp;utm_medium=referral&amp;utm_campaign=microsoft-office-professional-

