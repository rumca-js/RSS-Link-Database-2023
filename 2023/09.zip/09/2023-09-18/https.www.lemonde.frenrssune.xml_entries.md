# Source:Le Monde, URL:https://www.lemonde.fr/en/rss/une.xml, language:en-US

## Republicans react after Trump calls DeSantis 6-week abortion ban 'a terrible mistake'
 - [https://www.lemonde.fr/en/international/article/2023/09/19/republicans-react-after-trump-calls-desantis-6-week-abortion-ban-a-terrible-mistake_6137647_4.html](https://www.lemonde.fr/en/international/article/2023/09/19/republicans-react-after-trump-calls-desantis-6-week-abortion-ban-a-terrible-mistake_6137647_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T22:25:22+00:00

Speaking Sunday, September 17, on NBC's 'Meet the Press,' Donald Trump repeatedly declined to say whether he would support a federal ban on abortion.

## Hunter Biden sues US tax service after agents' disclosure to Congress
 - [https://www.lemonde.fr/en/international/article/2023/09/19/hunter-biden-sues-us-tax-service-after-agents-disclosure-to-congress_6137646_4.html](https://www.lemonde.fr/en/international/article/2023/09/19/hunter-biden-sues-us-tax-service-after-agents-disclosure-to-congress_6137646_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T22:20:10+00:00

The son of US President Joe Biden claims that two agents from the Internal Revenue Service wrongly shared his personal information in their testimony before Congress.

## Russia summons French ambassador citing 'Russophobic' actions
 - [https://www.lemonde.fr/en/russia/article/2023/09/18/russia-summons-french-ambassador-citing-russophobic-actions_6137605_140.html](https://www.lemonde.fr/en/russia/article/2023/09/18/russia-summons-french-ambassador-citing-russophobic-actions_6137605_140.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T19:19:08+00:00

Moscow claimed the French organizers of a press conference in India refused access to Russian journalists and attempted to confiscate their phones.

## US real estate on the brink of crisis
 - [https://www.lemonde.fr/en/economy/article/2023/09/18/us-real-estate-on-the-brink-of-crisis_6137601_19.html](https://www.lemonde.fr/en/economy/article/2023/09/18/us-real-estate-on-the-brink-of-crisis_6137601_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T19:06:01+00:00

Sales of commercial premises are collapsing, dragging fragile operators like coworking promoter WeWork down with them. The residential sector is holding up for the time being, but the ingredients for a catastrophe seem to be in place.

## Niger: The coveted oil windfall and its starring role in the coup
 - [https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/niger-the-coveted-oil-windfall-and-its-starring-role-in-the-coup_6137594_124.html](https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/niger-the-coveted-oil-windfall-and-its-starring-role-in-the-coup_6137594_124.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T17:55:56+00:00

According to those close to President Mohamed Bazoum, rivalries over the sharing of future oil revenues were a key factor in the July 26 putsch.

## Libya flooding: UN warns disease outbreak could be 'second devastating crisis'
 - [https://www.lemonde.fr/en/natural-disasters/article/2023/09/18/libya-flooding-un-warns-disease-outbreak-could-be-second-devastating-crisis_6137560_225.html](https://www.lemonde.fr/en/natural-disasters/article/2023/09/18/libya-flooding-un-warns-disease-outbreak-could-be-second-devastating-crisis_6137560_225.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T17:13:28+00:00

A number of aid agencies are worried about the risk of a serious disease outbreak after sanitary conditions collapsed following the flash floods that ravaged Libya last week.

## Paris park renamed in memory of Iranian Mahsa Amini
 - [https://www.lemonde.fr/en/international/article/2023/09/18/paris-park-renamed-in-memory-of-iranian-mahsa-amini_6137522_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/paris-park-renamed-in-memory-of-iranian-mahsa-amini_6137522_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T13:46:48+00:00

From September 16, the Villemin Garden in the 10th arrondissement of Paris will bear the name of Mahsa Jina Amini. The death of the 22-year-old a year ago after her arrest by Tehran's morality police had led to nationwide protests.

## Thirty years after the wolf's return to France, coexistence with farmers remains a challenge
 - [https://www.lemonde.fr/en/environment/article/2023/09/18/thirty-years-after-the-wolf-s-return-to-france-coexistence-with-farmers-remains-a-challenge_6137519_114.html](https://www.lemonde.fr/en/environment/article/2023/09/18/thirty-years-after-the-wolf-s-return-to-france-coexistence-with-farmers-remains-a-challenge_6137519_114.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T13:39:58+00:00

With an estimated population of 1,104 animals, France is still struggling to find a formula for peaceful coexistence.

## In Italy, Marine Le Pen chooses Salvini over Meloni
 - [https://www.lemonde.fr/en/european-union/article/2023/09/18/in-italy-marine-le-pen-chooses-salvini-over-meloni_6137516_156.html](https://www.lemonde.fr/en/european-union/article/2023/09/18/in-italy-marine-le-pen-chooses-salvini-over-meloni_6137516_156.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T13:16:49+00:00

The French far-right leader reiterated her support for her embattled ally, appearing alongside the Lega Nord leader near Bergamo on Sunday. She also promoted her idea of a 'declaration of the rights of nations and peoples' to target the EU.

## Iran releases five Americans in prisoner swap
 - [https://www.lemonde.fr/en/international/article/2023/09/18/iran-releases-five-americans-in-prisoner-swap_6137515_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/iran-releases-five-americans-in-prisoner-swap_6137515_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T13:15:22+00:00

Frozen funds totalling nearly $6 billion were transferred to Qatari banks before the five US prisoners were flown out of Tehran on Monday.

## Nicaragua, a new pathway to the US for Senegalese would-be emigrants
 - [https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/nicaragua-a-new-pathway-to-the-us-for-senegalese-would-be-emigrants_6137511_124.html](https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/nicaragua-a-new-pathway-to-the-us-for-senegalese-would-be-emigrants_6137511_124.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T12:46:36+00:00

Less dangerous than the journey to Europe via the Canary Islands, this new route is generating a lot of interest in Senegal.

## The French – and Jean Dujardin – certainly embraced the clichés for the Rugby World Cup opening ceremony. Does anyone care?
 - [https://www.lemonde.fr/en/m-le-mag/article/2023/09/18/the-french-and-jean-dujardin-certainly-embraced-the-cliches-for-the-rugby-world-cup-opening-ceremony-does-anyone-care_6137510_117.html](https://www.lemonde.fr/en/m-le-mag/article/2023/09/18/the-french-and-jean-dujardin-certainly-embraced-the-cliches-for-the-rugby-world-cup-opening-ceremony-does-anyone-care_6137510_117.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T12:39:41+00:00

The opening ceremony of the Rugby World Cup at the Stade de France on September 8 unfolded with a very French style of fanfare.

## In Lampedusa, EU's von der Leyen unveils 'a European response' to migration crisis
 - [https://www.lemonde.fr/en/european-union/article/2023/09/18/in-lampedusa-eu-s-von-der-leyen-unveils-a-european-response-to-migration-crisis_6137399_156.html](https://www.lemonde.fr/en/european-union/article/2023/09/18/in-lampedusa-eu-s-von-der-leyen-unveils-a-european-response-to-migration-crisis_6137399_156.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T10:02:56+00:00

The European Commission president, accompanied by Italian Prime Minister Giorgia Meloni, presented an emergency plan on the Mediterranean island on Sunday to help Rome manage a record flow of migrants.

## The transparent backpack aimed at preventing school shootings
 - [https://www.lemonde.fr/en/international/article/2023/09/18/the-transparent-backpack-aimed-at-preventing-school-shootings_6137366_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/the-transparent-backpack-aimed-at-preventing-school-shootings_6137366_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T10:00:13+00:00

Some products, born in the United States, are spreading around the globe. Le Monde tested the transparent backpack, designed to prevent pupils from bringing guns to school.

## 'Fed up with the French system,' increasing numbers of French students are choosing Montréal
 - [https://www.lemonde.fr/en/campus/article/2023/09/18/fed-up-with-the-french-system-increasing-numbers-of-french-students-are-choosing-montreal_6137296_11.html](https://www.lemonde.fr/en/campus/article/2023/09/18/fed-up-with-the-french-system-increasing-numbers-of-french-students-are-choosing-montreal_6137296_11.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T09:00:10+00:00

This year 3,400 French students started the new academic year at the University of Montréal, Canada's largest French-language university.

## French interior minister to travel to Rome over migration crisis
 - [https://www.lemonde.fr/en/europe/article/2023/09/18/french-interior-minister-to-travel-to-rome-over-migration-crisis_6137262_143.html](https://www.lemonde.fr/en/europe/article/2023/09/18/french-interior-minister-to-travel-to-rome-over-migration-crisis_6137262_143.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T08:28:12+00:00

Thousands of people arrived on the Italian island of Lampedusa last week, prompting European Commission president Ursula von der Leyen to travel there Sunday to announce an emergency action plan.

## In Belgium, several schools set on fire after extremist campaign against sex education
 - [https://www.lemonde.fr/en/international/article/2023/09/18/in-belgium-several-schools-set-on-fire-after-extremist-campaign-against-sex-education_6137195_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/in-belgium-several-schools-set-on-fire-after-extremist-campaign-against-sex-education_6137195_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T08:10:08+00:00

The incidents have occurred at a time when the Walloon government's educational program is under attack from radical religious and conspiracy circles.

## UNESCO adds two Ukrainian sites to World Heritage in Danger list
 - [https://www.lemonde.fr/en/culture/article/2023/09/18/unesco-adds-two-ukrainian-sites-to-world-heritage-in-danger-list_6137159_30.html](https://www.lemonde.fr/en/culture/article/2023/09/18/unesco-adds-two-ukrainian-sites-to-world-heritage-in-danger-list_6137159_30.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T07:34:06+00:00

At its meeting in Riyadh, Saudi Arabia, the organization classified buildings threatened by war in Kyiv and Lviv, which will allow for further financial and technical aid.

## Was Brexit's impact on the UK's economy ultimately negligible?
 - [https://www.lemonde.fr/en/economy/article/2023/09/18/was-brexit-s-impact-on-the-uk-s-economy-ultimately-negligible_6137084_19.html](https://www.lemonde.fr/en/economy/article/2023/09/18/was-brexit-s-impact-on-the-uk-s-economy-ultimately-negligible_6137084_19.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T03:30:17+00:00

Revised economic statistics portray the United Kingdom as experiencing weak growth, affected by the departure from the European single market, but far from collapse.

## Taiwan detects over 100 Chinese warplanes around its island
 - [https://www.lemonde.fr/en/china/article/2023/09/18/taiwan-detects-over-100-chinese-warplanes-around-its-island_6137079_162.html](https://www.lemonde.fr/en/china/article/2023/09/18/taiwan-detects-over-100-chinese-warplanes-around-its-island_6137079_162.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T03:07:47+00:00

China’s military sent 103 warplanes toward Taiwan in a 24-hour period in what the island’s defense ministry said Monday was the most for a day in recent times.

## Ghanaian cocoa farmers remain trapped in poverty
 - [https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/ghanaian-cocoa-farmers-remain-trapped-in-poverty_6137078_124.html](https://www.lemonde.fr/en/le-monde-africa/article/2023/09/18/ghanaian-cocoa-farmers-remain-trapped-in-poverty_6137078_124.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T03:00:12+00:00

Despite the industry's promises, farmers in the world's second-largest cocoa producer continue to suffer misery.

## Rédoine Faid's escape trial: The embarrassing inertia of the prison administration
 - [https://www.lemonde.fr/en/france/article/2023/09/18/redoine-faid-s-escape-trial-the-embarrassing-inertia-of-the-prison-administration_6137075_7.html](https://www.lemonde.fr/en/france/article/2023/09/18/redoine-faid-s-escape-trial-the-embarrassing-inertia-of-the-prison-administration_6137075_7.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T02:08:01+00:00

Despite several explicit warnings and a request to transfer the French gangster to a different facility to prevent any escape risks, no action was taken in the weeks leading up to his 2018 breakout from Réau prison in central France.

## Russian exiles in Serbia face expulsion threats
 - [https://www.lemonde.fr/en/international/article/2023/09/18/russian-exiles-in-serbia-face-expulsion-threats_6137072_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/russian-exiles-in-serbia-face-expulsion-threats_6137072_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T00:58:39+00:00

Serbian authorities, aligned closely with Moscow, have labeled certain Russian citizens exiled in Belgrade since the onset of the war in Ukraine as potential 'national security' risks.

## Armand Duplantis shatters pole vault world record as Gudaf Tsegay sets women's 5,000m world record
 - [https://www.lemonde.fr/en/international/article/2023/09/18/armand-duplantis-shatters-pole-vault-world-record-as-gudaf-tsegay-sets-women-s-5-000m-world-record_6137070_4.html](https://www.lemonde.fr/en/international/article/2023/09/18/armand-duplantis-shatters-pole-vault-world-record-as-gudaf-tsegay-sets-women-s-5-000m-world-record_6137070_4.html)
 - RSS feed: https://www.lemonde.fr/en/rss/une.xml
 - date published: 2023-09-18T00:20:41+00:00

The Swedish star raised the bar yet again, breaking his own pole vault world record with a phenomenal leap of 6.23m at the Diamond League finals while the Ethiopian ace obliterated the women's 5,000m world record in a blistering time of 14:00.21.

