# Source:LMG Clips, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA, language:en-US

## Piracy Doesn’t Pay
 - [https://www.youtube.com/watch?v=SPWiCm5tT7Y](https://www.youtube.com/watch?v=SPWiCm5tT7Y)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-09-18T22:43:16+00:00

Plex will ban hosting Plex servers via Hetzner in a move to distance themselves from piracy.

Watch the full WAN Show: https://www.youtube.com/watch?v=xXXQ9LaEONM

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## United Against Unity
 - [https://www.youtube.com/watch?v=6CDXejwnXy8](https://www.youtube.com/watch?v=6CDXejwnXy8)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-09-18T22:43:09+00:00

Unity Technologies announces a per download fee that applies retroactively to Unity-based games, leading to backlash and indie devs discussing pulling games from sale and migrating game engines.

Watch the full WAN Show: https://www.youtube.com/watch?v=xXXQ9LaEONM

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

## The Internet of Hot Garbage
 - [https://www.youtube.com/watch?v=3-_pR6RuXzw](https://www.youtube.com/watch?v=3-_pR6RuXzw)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCFLFc8Lpbwt4jPtY1_Ai5yA
 - date published: 2023-09-18T16:00:04+00:00

G/O Media fire Spanish editorial team of Gizmodo En Espanol, replaces them with machine translation.

Watch the full WAN Show: https://www.youtube.com/watch?v=HHKZTFGUZS0

► GET MERCH: https://lttstore.com
► LTX 2023 TICKETS AVAILABLE NOW: https://lmg.gg/ltx23
► GET EXCLUSIVE CONTENT ON FLOATPLANE: https://lmg.gg/lttfloatplane
► SPONSORS, AFFILIATES, AND PARTNERS: https://lmg.gg/partners
► OUR WAN PODCAST GEAR: https://lmg.gg/wanset
 
FOLLOW US ON SOCIAL
---------------------------------------------------  
Twitter: https://twitter.com/linustech
Facebook: http://www.facebook.com/LinusTech
Instagram: https://www.instagram.com/linustech
TikTok: https://www.tiktok.com/@linustech
TikTok (LMG Clips): www.tiktok.com/@_lmgclips_
Twitch: https://www.twitch.tv/linustech

