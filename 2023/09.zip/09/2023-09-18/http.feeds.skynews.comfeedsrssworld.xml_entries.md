# Source:Sky News, URL:http://feeds.skynews.com/feeds/rss/world.xml, language:en-US

## Lampedusa nurse says 'welcome everyone' - as residents complain they have to wait for care
 - [https://news.sky.com/story/lampedusa-migrant-crisis-nurse-says-welcome-everyone-as-islands-residents-complain-they-have-to-wait-for-care-12964630](https://news.sky.com/story/lampedusa-migrant-crisis-nurse-says-welcome-everyone-as-islands-residents-complain-they-have-to-wait-for-care-12964630)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T21:30:00+00:00

His sweat-stained scrubs caught our eyes as he made his way along the crowded dock on the Italian island of Lampedusa.

## Canada claims Indian government assassinated Sikh leader
 - [https://news.sky.com/story/canada-claims-indian-government-assassinated-sikh-leader-12964595](https://news.sky.com/story/canada-claims-indian-government-assassinated-sikh-leader-12964595)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T19:55:00+00:00

Prime Minister Justin Trudeau has said there are "credible allegations" that the Indian government was behind the assassination of a Sikh leader in Canada earlier this summer.

## Black bear on the loose at Disney World forces parts of theme park to shut down
 - [https://news.sky.com/story/disney-world-black-bear-on-the-loose-forces-parts-of-florida-theme-park-to-shut-down-12964515](https://news.sky.com/story/disney-world-black-bear-on-the-loose-forces-parts-of-florida-theme-park-to-shut-down-12964515)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T17:31:00+00:00

Parts of Disney World in Florida have been forced to shut down after reports of a black bear on the loose.

## Hermoso left out of Spain squad 'to protect her' after World Cup kiss scandal
 - [https://news.sky.com/story/womens-world-cup-jenni-hermoso-left-out-of-spain-squad-to-protect-her-after-kiss-scandal-12964479](https://news.sky.com/story/womens-world-cup-jenni-hermoso-left-out-of-spain-squad-to-protect-her-after-kiss-scandal-12964479)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T16:24:00+00:00

Spanish footballer Jenni Hermoso, who was kissed on the lips by ex-federation president Luis Rubiales after her side won the Women's World Cup, has not been picked for the first squad named since the scandal erupted.

## Hope remains Libya flood survivors can be found as 'cries heard' beneath rubble
 - [https://news.sky.com/story/libya-floods-hope-remains-survivors-can-found-after-derna-dam-disaster-as-cries-heard-beneath-rubble-12964448](https://news.sky.com/story/libya-floods-hope-remains-survivors-can-found-after-derna-dam-disaster-as-cries-heard-beneath-rubble-12964448)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T15:37:00+00:00

Everyone in Derna is desperate for good news right now after days and days of utter misery and collective, searing suffering.

## Experts warned about state of Libya dams 'for almost 40 years'
 - [https://news.sky.com/story/libya-floods-experts-warned-about-derna-dams-for-nearly-40-years-state-prosecutor-says-12964391](https://news.sky.com/story/libya-floods-experts-warned-about-derna-dams-for-nearly-40-years-state-prosecutor-says-12964391)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T14:11:00+00:00

Experts warned about the structural integrity of the Derna dams for almost 40 years, a Libyan state prosecutor said, as the search continues for bodies after last week's devastating floods.

## Bus carrying diamond mine workers crashes, killing 20 people
 - [https://news.sky.com/story/20-people-killed-after-bus-carrying-diamond-mine-workers-crashes-in-south-africa-12964306](https://news.sky.com/story/20-people-killed-after-bus-carrying-diamond-mine-workers-crashes-in-south-africa-12964306)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T11:31:00+00:00

Twenty people have been killed in a crash involving a truck and a bus that was carrying workers to a diamond mine in South Africa.

## Women less likely to be given CPR in public than men
 - [https://news.sky.com/story/women-less-likely-to-be-given-cpr-in-public-than-men-12964235](https://news.sky.com/story/women-less-likely-to-be-given-cpr-in-public-than-men-12964235)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T09:50:00+00:00

Women are less likely to be given CPR if they have a cardiac arrest in public than men, according to new study.

## Man who took pet snake surfing fined
 - [https://news.sky.com/story/australia-man-who-took-pet-snake-surfing-fined-12964218](https://news.sky.com/story/australia-man-who-took-pet-snake-surfing-fined-12964218)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T09:23:00+00:00

A man who went viral after he was filmed surfing with his pet python has been fined more than 2,000 Australian dollars for taking the reptile out in public.

## How ships bombed at Pearl Harbor could help scientists understand climate change
 - [https://news.sky.com/story/how-ships-bombed-at-pearl-harbor-could-help-scientists-understand-climate-change-12964195](https://news.sky.com/story/how-ships-bombed-at-pearl-harbor-could-help-scientists-understand-climate-change-12964195)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T08:42:00+00:00

Ships bombed at Pearl Harbor more than 80 years ago have provided weather data that could help understand climate change.

## Girl killed after plane crashes into car, sending fireball into air
 - [https://news.sky.com/story/girl-5-killed-as-aerobatic-plane-crashes-into-familys-car-in-italy-12964193](https://news.sky.com/story/girl-5-killed-as-aerobatic-plane-crashes-into-familys-car-in-italy-12964193)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T08:39:00+00:00

A five-year-old girl has died after a military aerobatic plane crashed into her family's car in Italy.

## Girl, 5, killed after plane crashes into car
 - [https://news.sky.com/story/girl-5-killed-as-acrobatic-plane-crashes-into-familys-car-in-italy-12964193](https://news.sky.com/story/girl-5-killed-as-acrobatic-plane-crashes-into-familys-car-in-italy-12964193)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T08:39:00+00:00

A five-year-old girl has died after a military acrobatic plane crashed into her family's car in Italy.

## Two female students in hospital after university stabbing
 - [https://news.sky.com/story/two-female-students-in-hospital-after-university-stabbing-in-australia-12964190](https://news.sky.com/story/two-female-students-in-hospital-after-university-stabbing-in-australia-12964190)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T08:26:00+00:00

Two female students are in hospital - one in critical condition - after being stabbed at the Australian National University in Canberra.

## Living outside natural habitats can affect the bodies and behaviours of giant pandas
 - [https://news.sky.com/story/living-outside-natural-habitats-can-affect-the-bodies-and-behaviours-of-giant-pandas-12964144](https://news.sky.com/story/living-outside-natural-habitats-can-affect-the-bodies-and-behaviours-of-giant-pandas-12964144)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T06:39:00+00:00

Living in zoos outside their natural environment may disrupt the bodies and behaviour of giant pandas, new research suggests.

## Five freed from detention in Iran land in Doha after &#163;4.8bn deal
 - [https://news.sky.com/story/briton-morad-tahbaz-and-four-americans-freed-from-iran-detention-land-in-doha-after-16348bn-deal-12964115](https://news.sky.com/story/briton-morad-tahbaz-and-four-americans-freed-from-iran-detention-land-in-doha-after-16348bn-deal-12964115)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T05:39:00+00:00

A British national and four Americans who were released from detention by Iran in exchange for $6bn (&#163;4.8bn) and a prisoner swap are now free after landing in Doha.

## Iran to release five detainees including British citizen in prisoner swap
 - [https://news.sky.com/story/iran-to-release-five-detainees-including-british-citizen-morad-tahbaz-in-prisoner-swap-12964115](https://news.sky.com/story/iran-to-release-five-detainees-including-british-citizen-morad-tahbaz-in-prisoner-swap-12964115)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T05:39:00+00:00

Iran will release a British national and four Americans held in the country in exchange for $6bn (&#163;4.8bn) and a prisoner swap.

## US military search for missing F-35 warplane after 'mishap'
 - [https://news.sky.com/story/us-military-search-for-missing-f-35-warplane-after-mishap-12964112](https://news.sky.com/story/us-military-search-for-missing-f-35-warplane-after-mishap-12964112)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T05:29:00+00:00

The US military is searching for a missing F-35 warplane after its pilot ejected during a "mishap".

## 'Frenzied, chaotic mess': Fears grow over spread of disease after deadly Libya floods
 - [https://news.sky.com/story/frenzied-chaotic-mess-fears-grow-over-spread-of-disease-after-deadly-libya-floods-12964085](https://news.sky.com/story/frenzied-chaotic-mess-fears-grow-over-spread-of-disease-after-deadly-libya-floods-12964085)
 - RSS feed: http://feeds.skynews.com/feeds/rss/world.xml
 - date published: 2023-09-18T00:52:00+00:00

The aid effort in the flood-ravaged city of Derna in east Libya has ramped up considerably in the past 48 hours. But while there are increased numbers of people on the ground helping, much of it still seems a frenzied, chaotic mess.

