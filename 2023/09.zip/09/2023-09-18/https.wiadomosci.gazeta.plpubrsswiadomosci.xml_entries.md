# Source:Wiadomosci - Gazeta.pl, URL:https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml, language:pl-PL

## Ostaszewska komentuje słowa Ziobry: To, co się dzieje, jest paskudne i obrzydliwe. To atak na wolność słowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203740,ostaszewska-komentuje-slowa-ziobry-to-co-sie-dzieje-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203740,ostaszewska-komentuje-slowa-ziobry-to-co-sie-dzieje-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T19:36:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/cb/1c/z30195710M,Maja-Ostaszewska.jpg" vspace="2" />- Jako wolontariuszka Grupy Granica byłam w lesie i spojrzałam w wiele oczu. Znalazłam w nich morze cierpienia - mówiła Maja Ostaszewska w rozmowie z WP. Aktorka odniosła się także do słów Zbigniewa Ziobry, który porównał twórczość Agnieszki Holland do filmów propagandowych III Rzeszy.

## Działaczki KO potrącone przez 73-latka. "Człowiek z zaciśniętymi zębami i widoczną agresją"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203638,dzialaczki-ko-potracone-przez-73-latka-czlowiek-z-zacisnietymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203638,dzialaczki-ko-potracone-przez-73-latka-czlowiek-z-zacisnietymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T19:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/cd/1c/z30203709M,Incydent-w-Wegrowie.jpg" vspace="2" />Kandydatka w wyborach do Sejmu Marzena Cendrowska i towarzysząca jej działaczka KO Małgorzata Dąbrowska zostały potrącone przez 73-letniego mężczyznę podczas festynu w Węgrowie. Działaczki są przekonane, że incydent miał podłoże polityczne. Policja na ten moment tego nie potwierdza.

## Śledczy wzywają pacjentki ginekolożki na przesłuchania. "Pytają, czy przepisywała jakieś tabletki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203541,sledczy-wzywaja-pacjentki-ginekolozki-na-przesluchania-pytaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203541,sledczy-wzywaja-pacjentki-ginekolozki-na-przesluchania-pytaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T18:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/9d/1c/z30007008M,Dr-Maria-Kubisa.jpg" vspace="2" />Kolejna pacjentka dr Marii Kubisy, ginekolożki ze Szczecina, została wezwana na przesłuchanie - informuje TVN24. 9 stycznia 2023 roku CBA i Prokuratura Regionalna w Szczecinie zabezpieczyła w jej gabinecie 30-letnią dokumentację medyczną, zabrano jej telefon i kalendarz.

## ''Mogłabym żyć i pod Putinem, byleby mi było dobrze''. Co nad Odrą mówi się o wyborach?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30199268,moglabym-zyc-i-pod-putinem-byleby-mi-bylo-dobrze-co-nad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30199268,moglabym-zyc-i-pod-putinem-byleby-mi-bylo-dobrze-co-nad.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T18:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fe/cc/1c/z30199294M,Jeden-z-licznych-bannerow-Janusza-Kowalskiego-na-O.jpg" vspace="2" />Będą głosować na mniejsze zło lub wcale. Narzekają na słabą opozycję, drogie leki, a po wyborach spodziewają się rozpierduchy. Oto kilka historii z pogranicza Opolszczyzny i Dolnego Śląska.

## Gniezno. Potrącił swoje 15-miesięczne dziecko. Rzeczniczka policji: Miał ponad dwa promile alkoholu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203488,gniezno-potracil-swoje-15-miesieczne-dziecko-rzeczniczka-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203488,gniezno-potracil-swoje-15-miesieczne-dziecko-rzeczniczka-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T18:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/cd/1c/z30203524M,Do-potracenia-15-miesiecznego-dziecka-doszlo-w-Gni.jpg" vspace="2" />W Gnieźnie miało miejsce niebezpieczne zdarzenie z udziałem 15-miesięcznego dziecka. Podczas przeparkowywania samochodu dziewczynka została potrącona przez swojego ojca. - Badanie wykazało, że w chwili zdarzenia ojciec dziecka miał ponad dwa promile alkoholu - przekazała rzeczniczka gnieźnieńskiej policji.

## Afera wizowa. Edgar K. wymazany z rządowych stron. "Ktoś niszczy dowody na powiązania z politykami PiS"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203504,afera-wizowa-edgar-k-wymazany-z-rzadowych-stron-ktos-niszczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203504,afera-wizowa-edgar-k-wymazany-z-rzadowych-stron-ktos-niszczy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T17:47:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a5/cd/1c/z30203557M,KPRM--Zdjecie-ilustracyjne.jpg" vspace="2" />Edgar K., były współpracownik byłego wiceszefa MSZ Piotra Wawrzyka, zniknął ze stron rządowych. Jak ujawniła posłanka Lewicy Agnieszka Dziemianowicz-Bąk, nazwisko mężczyzny zostało wprost usunięte z jednego z artykułów. Edgar K. to jeden z bohaterów ostatnich medialnych publikacji ws. tzw. afery wizowej.

## Prezydent Zełenski gorzko o kontrofensywie: Będę z wami całkowicie szczery
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203393,prezydent-zelenski-gorzko-o-kontrofensywie-bede-z-wami-calkowicie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203393,prezydent-zelenski-gorzko-o-kontrofensywie-bede-z-wami-calkowicie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T17:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/20/ca/1c/z30191392M,Prezydent-Ukrainy-Wolodymyr-Zelenski.jpg" vspace="2" />- Będziemy w stanie przełamać rosyjską obronę. To się stanie, jestem tego pewien. Nie mogę powiedzieć, gdzie to się stanie najszybciej. Przebijemy się potężnie - mówił Wołodymyr Zełenski w rozmowie z amerykańską stacją telewizyjną CBS, odpowiadając na pytanie o powolną kontrofensywę.

## Niemiecki minister oburzony decyzją polskiego rządu ws. ukraińskiego zboża. Podsumował to krótko
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203382,niemiecki-minister-oburzony-decyzja-polskiego-rzadu-ws-ukrainskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203382,niemiecki-minister-oburzony-decyzja-polskiego-rzadu-ws-ukrainskiego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T16:39:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/53/cd/1c/z30203475M,Cem-Ozdemir.jpg" vspace="2" />- Kiedy ci to odpowiada, jesteś solidarny, a kiedy ci to nie odpowiada, nie jesteś - tak decyzję m.in. polskiego rządu ws. zakazu importu ukraińskiego zboża skomentował szef resortu rolnictwa Niemiec Cem Özdemir. Według RMF FM większość unijnych państw popiera decyzję Komisji Europejskiej o nieprzedłużeniu embarga.

## Działacz Lewicy zaskoczył polityka PiS na dożynkach. "Czy tutaj da się kupić polską wizę?"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203241,dzialacz-lewicy-zaskoczyl-polityka-pis-na-dozynkach-czy-tutaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30203241,dzialacz-lewicy-zaskoczyl-polityka-pis-na-dozynkach-czy-tutaj.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T16:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f0/cd/1c/z30203376M,Kandydat-Lewicy-zadal-politykowi-PiS-pytanie-o-afe.jpg" vspace="2" />Łukasz Michnik, działacz Lewicy związany z Olsztynem, zaskoczył swoim pytaniem Błażeja Pobożego - podsekretarza stanu z MSWiA. Kandydaci do Sejmu spotkali się podczas dożynek warmińsko-mazurskich. W trakcie nagrywanej rozmowy Michnik niespodziewanie poruszył temat afery wizowej. Polityk PiS odszedł bez udzielenia odpowiedzi. Później ich rozmowa przeniosła się do mediów społecznościowych.

## F-35 wybrał wolność. Maszyna bez pilota zaginęła i jest poszukiwana
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200862,amerykanie-zgubili-f-35-pilot-sie-katapultowal-samolot-polecial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200862,amerykanie-zgubili-f-35-pilot-sie-katapultowal-samolot-polecial.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T16:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/96/cd/1c/z30200982M,F-35B-lotnictwa-Korpusu-Piechoty-Morskiej.jpg" vspace="2" />Wojsko USA pilnie poszukuje zaginionego samolotu wielozadaniowego F-35B, który udał się w trudnym do ustalenia kierunku. Pilot katapultował się z niego z powodu jakiejś awarii, a pozbawiona kontroli maszyna utrzymała się w powietrzu i poleciała dalej. Nie ma pewności gdzie.

## Afera wizowa. Hindusi zostali oszukani. "Rodzice sprzedali ziemię, zapożyczyli się"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203187,afera-wizowa-hindusi-zostali-oszukani-rodzice-sprzedali-ziemie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30203187,afera-wizowa-hindusi-zostali-oszukani-rodzice-sprzedali-ziemie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T16:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/cf/29/1a/z27434959M,Indie---zdjecie-ilustracyjne.jpg" vspace="2" />Trzech obywateli Indii, którzy skorzystali z usług pośredników i nielegalnie zdobyli polskie wizy, opowiedziało w rozmowie z ''Gazetą Wyborczą" jak przebiegał cały proceder. - Na emigrację do Polski zrzuciła się cała moja rodzina. Zastawiliśmy dom, wydaliśmy ostatnie oszczędności - relacjonował jeden z mężczyzn.

## Znamy godzinę startu Marszu Miliona Serc. "Koalicja Obywatelska załatwi ci transport"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202812,znamy-godzine-startu-marszu-miliona-serc-koalicja-obywatelska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202812,znamy-godzine-startu-marszu-miliona-serc-koalicja-obywatelska.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T15:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/cd/1c/z30202935M,Marsz-4-czerwca-w-Warszawie.jpg" vspace="2" />Zapowiedziany w lipcu przez Donalda Tuska Marsz Miliona Serc zbliża się wielkimi krokami. Wraz ze zbliżającym się terminem zgromadzenia pojawiają się kolejne informacje od jego organizatorów. O której godzinie rozpocznie się marsz i jak można skorzystać z transportu oferowanego przez Koalicję Obywatelską?

## Zaginęła 23-letnia Aneta Szubryt. Policja prosi o pomoc
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203195,zaginela-23-letnia-aneta-szubryt-policja-prosi-o-pomoc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203195,zaginela-23-letnia-aneta-szubryt-policja-prosi-o-pomoc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T15:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/cd/1c/z30203237M,Aneta-Szubryt.jpg" vspace="2" />Wrocławscy policjanci poszukują 23-letniej Anety Szubryt. Kobieta zaginęła w czwartek, do tej pory nie skontaktowała się z bliskimi. Funkcjonariusze opublikowali zdjęcia 23-latki.

## Wojciech Mann zażartował z funkcji Kurskiego w Banku Światowym. Oberwało się też Glapińskiemu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202813,wojciech-mann-zazartowal-z-funkcji-kurskiego-w-banku-swiatowym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202813,wojciech-mann-zazartowal-z-funkcji-kurskiego-w-banku-swiatowym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T15:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/cd/1c/z30203041M,Wojciech-Mann.jpg" vspace="2" />Wojciech Mann skrytykował w żartobliwym tonie funkcję Jacka Kurskiego w Banku Światowym. Były prezes zarządu TVP objął intratne stanowisko po tym, jak jego kandydatura została zgłoszona przez Adama Glapińskiego. W swoim wpisie dziennikarz zażartował, że sam posiada kompetencje zbliżone do Kurskiego i zapytał ironicznie prezesa NBP, czy ten nie znalazłby dla niego podobnej posady.

## Błaszczak o odtajnieniu dokumentów w spocie PiS. "Planowali oddać pół Polski w ręce Rosji"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202179,blaszczak-o-odtajnieniu-dokumentow-w-spocie-pis-planowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202179,blaszczak-o-odtajnieniu-dokumentow-w-spocie-pis-planowali.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T15:07:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/cd/1c/z30202374M,Minister-obrony-narodowej-Mariusz-Blaszczak.jpg" vspace="2" />Mariusz Błaszczak mówił w TVP Info, dlaczego zdjęcia ściśle tajnych dokumentów wojskowych znalazły się w najnowszym spocie wyborczym PiS-u. Powołał się na "prawdę historyczną" oraz "elementarną uczciwość". - PO to hipokryci, którzy wyraźnie chcieli oddać pół Polski Rosji - powiedział minister obrony narodowej, któremu wysokiej rangą wojskowi zarzucają zdradę NATO i utratę wiarygodności w oczach Sojuszu.

## Tusk zaprasza na Marsz Miliona Serc. "Stajemy do walki ze złem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30203035,tusk-zaprasza-na-marsz-miliona-serc-stajemy-do-walki-ze-zlem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30203035,tusk-zaprasza-na-marsz-miliona-serc-stajemy-do-walki-ze-zlem.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:56:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/22/cd/1c/z30203170M,Screen-ze-spotu.jpg" vspace="2" />- Stajemy do walki ze złem, twarzą w twarz, rozliczyć tę władzę, żeby Polska znowu była wolna od kłamstwa, od nienawiści i złodziejstwa - mówi w najnowszym spocie przewodniczący PO Donald Tusk, zapraszając do udziału w Marszu Miliona Serc. Wydarzenie ma odbyć się w niedzielę 1 października.

## KO wygrała prawybory w Wieruszowie. "Część wyborców może w ostatniej chwili wybrać tę partię"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201362,ko-wygrala-prawybory-w-wieruszowie-czesc-wyborcow-moze-w-ostatniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201362,ko-wygrala-prawybory-w-wieruszowie-czesc-wyborcow-moze-w-ostatniej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:46:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/37/05/1a/z27286071M,To-zdjecie-z-2010-roku---Jaroslaw-Kaczynski-i-Dona.jpg" vspace="2" />Koalicja Obywatelska wygrała, PiS zajął drugie miejsce, a trzecie przypadło Trzeciej Drodze - to wyniki prawyborów w Wieruszowie. Co z nich wynika? - Mniejsze partie opozycyjne muszą wyciągnąć wnioski. Część wyborców może po prostu w ostatniej chwili wybrać PO, jako najsilniejszego po tej stronie barykady - mówi politolog prof. Rafał Chwedoruk w rozmowie z Gazeta.pl.

## Sąd nałożył na TVP "bezwzględny zakaz". Chodzi o sondaże wyborcze
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202917,sad-nalozyl-na-tvp-bezwzgledny-zakaz-chodzi-o-sondaze-wyborcze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202917,sad-nalozyl-na-tvp-bezwzgledny-zakaz-chodzi-o-sondaze-wyborcze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/82/bb/1a/z28030338M,Danuta-Holecka-TVP--Wiadomosci-.jpg" vspace="2" />Sąd apelacyjny w Legnicy przystał na odwołanieTelewizji Polskiej ws. wyroku nakazującego w trybie wyborczym przeproszenie i zamieszczenie sprostowania materiału pomijającego notowania komitetu Bezpartyjni Samorządowcy. Mimo korekty telewizja publiczna nadal musi przeprosić, dostała też zakaz publikacji sondaży wyborczych nieuwzględniających BS - informuje Press.

## Razem chce zapobiegać mobbingowi w swoich szeregach. Wprowadzono specjalne procedury
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30197286,razem-chce-zapobiegac-mobbingowi-w-swoich-szeregach-wprowadzono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30197286,razem-chce-zapobiegac-mobbingowi-w-swoich-szeregach-wprowadzono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/f7/cc/1c/z30197751M,Razem--Zdjecie-ilustracyjne.jpg" vspace="2" />Partia Lewica Razem przyjęła procedury dotyczące przyjmowania i analizy zgłoszeń ws. mobbingu - dowiedział się portal Gazeta.pl. Stało się to rok po publikacji głośnego tekstu Gazeta.pl. Pisaliśmy w nim o oskarżeniach, jakie kilkoro działaczy ugrupowania skierowało publicznie wobec swoich partyjnych koleżanek i kolegów.

## Sondaż: spadło poparcie dla KO i Konfederacji. Opozycja o włos od większości w Sejmie
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30202666,sondaz-spadlo-poparcie-dla-ko-i-konfederacji-opozycja-o-wlos.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30202666,sondaz-spadlo-poparcie-dla-ko-i-konfederacji-opozycja-o-wlos.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:15:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/4a/cd/1c/z30202954M,Jaroslaw-Kaczynski.jpg" vspace="2" />Prawo i Sprawiedliwość na czele, ale bez większości w Sejmie - takie wnioski można wysnuć z najnowszego sondażu IBRiS dla Polsat News. Czteropunktowy spadek zaliczyła Koalicja Obywatelska, mniejsze poparcie odnotowuje również Konfederacja.

## Jak wyszła na jaw zbrodnia w Czernikach? Ktoś podejrzał SMS-y córki i ojca. "I co robi?". "Ciągle ryczy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202180,jak-wyszla-na-jaw-zbrodnia-w-czernikach-ktos-podejrzal-sms-y.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202180,jak-wyszla-na-jaw-zbrodnia-w-czernikach-ktos-podejrzal-sms-y.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T14:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/cd/1c/z30202519M,Czerniki--Dom--w-ktorym-odnaleziono-zwloki-trojga-.jpg" vspace="2" />W sprawie tragicznej zbrodni we wsi Czerniki prokuratura prowadzi śledztwo. 54-letni Piotr G. oraz jego 20-letnia córka Paulina przebywają w areszcie. Mają postawione zarzuty kazirodztwa oraz morderstwa trójki noworodków. Sprawa mogłaby nigdy nie wyjść na jaw, gdyby nie SMS-y, które podejrzała jedna z kobiet pracujących w cukierni z Pauliną G.

## "Córka traktowała go jak Boga", "odbierał wszystkie porody". Po zbrodni wieś Czerniki mówi o Piotrze G.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201526,szatan-w-ludzkim-ciele-ktorego-corka-traktowala-jak-boga.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201526,szatan-w-ludzkim-ciele-ktorego-corka-traktowala-jak-boga.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T13:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/cd/1c/z30201947M,Dom-rodziny-G-.jpg" vspace="2" />Zbrodnia we wsi Czerników. Według relacji mieszkańców niemal wszyscy z otoczenia rodziny G. wiedzieli, co dzieje się za zamkniętymi drzwiami jednego z kaszubskich domów. To tam policjanci odnaleźli szczątki trzech noworodków, które mieli pozbawić życia 54-letni Piotr G. i jego 20-letnia córka Paulina. Mieli też dopuszczać się kazirodztwa. O 20-latce mówi się, że była jedną z ofiar, która "miała wpojone, że spanie z ojcem jest normalne".

## Strzelanina pod Częstochową. Prokuratura ujawnia nowe fakty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202696,strzelanina-pod-czestochowa-prokuratura-ujawnia-nowe-fakty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202696,strzelanina-pod-czestochowa-prokuratura-ujawnia-nowe-fakty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T13:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/cc/1c/z30198182M,Strzelanina-pod-Czestochowa--Jedna-z-ofiar-miala-k.jpg" vspace="2" />Prokuratura w Myszkowie prowadzi śledztwo dotyczące sobotniej strzelaniny w Podlesiu pod Częstochową, gdzie zginęło dwóch mężczyzn. Okazuje się, że 52-latek i 44-latek poróżnili się o kobietę.

## Zdjęcia granatnika w KGP. "Owocna wizyta w Ukrainie", "to musi być głośnik"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202341,zdjecia-granatnika-w-kgp-owocna-wizyta-w-ukrainie-to-musi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30202341,zdjecia-granatnika-w-kgp-owocna-wizyta-w-ukrainie-to-musi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T13:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/35/cd/1c/z30200885M,Zdjecia-po-wybuchu-granatnika-w-Komendzie-Glownej-.jpg" vspace="2" />"Przebijalność stropów betonowych naprawdę imponująca", "Co tam jeden granatnik. Komendant Policji miał dwa (dla ochrony osobistej)", "Zakładamy, że to był wypadek przy 'zabawie bronią' Komendanta Gł. Policji" - to tylko kilka z wielu komentarzy, które pojawiły się w mediach społecznościowych w poniedziałek. Jest to reakcja na publikację przez senatora Krzysztofa Brejzę tajnych fotografii, pokazujących skalę zniszczeń po wybuchu granatnika w Komendzie Głównej Policji.

## Tajwan wzywa Chiny do "natychmiastowego powstrzymania się". "103 samoloty i dziewięć okrętów"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30202130,tajwan-wzywa-chiny-do-natychmiastowego-powstrzymania-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30202130,tajwan-wzywa-chiny-do-natychmiastowego-powstrzymania-sie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T13:10:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/6f/cd/1c/z30202479M,Tajwan--ilustracyjne-.jpg" vspace="2" />Ministerstwo Obrony Tajwanu poinformowało, że Chiny zwiększają potencjał swoich sił powietrznych w pobliżu wyspy. Wezwało Pekin do "powstrzymania się od destrukcyjnych, jednostronnych działań".

## Uzbrojony dron znaleziony u wybrzeży Bułgarii w Tiulenowie. Władze domyślają się, do kogo może należeć
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30201876,uzbrojony-dron-znaleziony-u-wybrzezy-bulgarii-w-tiulenowie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30201876,uzbrojony-dron-znaleziony-u-wybrzezy-bulgarii-w-tiulenowie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T12:44:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/da/cd/1c/z30202074M,Dron-znaleziony-w-Bulgarii.jpg" vspace="2" />W Bułgarii u wybrzeża miejscowości Tiulenowo odnaleziono uzbrojonego drona. Zdaniem tamtejszego ministra obrony należał on do jednej ze stron wojny w Ukrainie i został już zneutralizowany.

## Rzecznik PO Jan Grabiec: Cały czas można kupować wizy. PiS urządził nam Lampedusę razy sto
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30201771,rzecznik-po-jan-grabiec-caly-czas-mozna-kupowac-wizy-pis-urzadzil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30201771,rzecznik-po-jan-grabiec-caly-czas-mozna-kupowac-wizy-pis-urzadzil.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T12:38:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/eb/19/z27180633M,Jan-Grabiec.jpg" vspace="2" />Choć PiS robi wszystko, by opinia publiczna na temat afery wizowej wiedziała jak najmniej, temat podsycają coraz to nowsze doniesienia. Rzecznik Platformy Obywatelskiej Jan Grabiec informuje, że proceder wciąż trwa: - PiS urządził nam Lampedusę razy 100. Próbują teraz zwalić na kogoś innego winę.

## Nowe informacje ws. zbrodni w Czernikach. W przeszłości służby zajmowały się Piotrem G.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202055,nowe-informacje-ws-zbrodni-w-czernikach-w-przeszlosci-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202055,nowe-informacje-ws-zbrodni-w-czernikach-w-przeszlosci-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T12:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/cd/1c/z30201949M,Ciala-noworodkow-odnalezione-w-domu-w-Czernikach.jpg" vspace="2" />- Z danych systemu wynika, że w przeszłości było prowadzonych kilka postępowań wobec Piotra G. - przekazała Onetowi prok. Grażyna Wawryniuk, rzeczniczka prasowa Prokuratury Okręgowej w Gdańsku. W domu 54-latka służby znalazły zwłoki trzech noworodków. Mężczyźnie postawiono pięć zarzutów dot. zabójstwa i kazirodztwa.

## Liderzy Trzeciej Drogi nie wezmą udziału w marszu Tuska. Hołownia tłumaczy i podaje przykład Wieruszowa
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201460,liderzy-trzeciej-drogi-nie-wezma-udzialu-w-marszu-tuska-holownia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201460,liderzy-trzeciej-drogi-nie-wezma-udzialu-w-marszu-tuska-holownia.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T11:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/ad/90/1c/z29952685M,Szymon-Holownia--Wladyslaw-Kosiniak-Kamysz.jpg" vspace="2" />- My nie mieliśmy żadnego telefonu, żadnego zaproszenia na ten warszawski marsz, jak dotąd nie było żadnych rozmów organizacyjnych - powiedział Szymon Hołownia, informując, że ani jego, ani Władysława Kosiniaka-Kamysza nie będzie na Marszu Miliona Serc. - Uważamy, że tak będzie najlepiej, żebyśmy się podzielili pracą. Dzielimy się nie partyjnie, ale bardziej geograficznie: jedni jadą do tej Polski lokalnej, drudzy są w Polsce centralnej. (...) Myślę, że jak się podzielimy sensownie tą pracą, to wspólny efekt będzie taki, jak w Wieruszowie - stwierdził lider Polski 2050.

## Śmierć Kamila z Częstochowy. Są ustalenia kuratorium i decyzje ws. placówek, w których przebywał
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201368,smierc-kamila-z-czestochowy-sa-ustalenia-kuratorium-i-decyzje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201368,smierc-kamila-z-czestochowy-sa-ustalenia-kuratorium-i-decyzje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T11:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/60/1c/z29754969M,13-maja-2023--cmentarz-Kule-w-Czestochowie--Pogrze.jpg" vspace="2" />Śląskie Kuratorium Oświaty w Katowicach przeprowadziło wizytację placówek, w których przebywał 8-letni Kamil z Częstochowy, a które nie odnotowały żadnych sygnałów, że chłopiec jest maltretowany. Według urzędników nie doszło do żadnych nieprawidłowości. Mimo to przed szkołą, do której uczęszczał chłopiec, odbędzie się kolejny protest.

## Komenda Główna Policji reaguje na wyciek zdjęć granatnika. Mówi o "sensacji"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201869,komenda-glowna-policji-reaguje-na-wyciek-zdjec-granatnika-mowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201869,komenda-glowna-policji-reaguje-na-wyciek-zdjec-granatnika-mowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T11:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />- Zdjęcia te nie wnoszą nic nowego, o czym nie było mowy wcześniej i czego nie przekazywano opinii publicznej - powiedział rzecznik Komendanta Głównego Policji. Mariusz Ciarka odniósł się w ten sposób do opublikowanych przez Krzysztofa Brejzę zdjęć, które miały zostać zrobione po wybuchu granatnika w KGP. - W wypowiedziach pana senatora padło wiele nieprawdziwych informacji, aby nadać sprawie charakter sensacji - dodał funkcjonariusz.

## "Nie ma drugiego elektoratu, który tak elastycznie pracuje jak Konfederaci"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30199549,nie-ma-drugiego-elektoratu-ktory-tak-elastycznie-pracuje-jak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30199549,nie-ma-drugiego-elektoratu-ktory-tak-elastycznie-pracuje-jak.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T11:19:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/1a/cd/1c/z30201626M,Sroczynski-na-wybory.jpg" vspace="2" />Wielu wyborców Konfederacji tak naprawdę chciałoby porządnych usług publicznych, ale widzisz to dopiero wtedy, jak się pobawisz w psychoanalityka - z socjologiem Przemysławem Sadurą, autorem raportu "Nowy negacjonizm klimatyczny" rozmawia Grzegorz Sroczyński

## Co się dzieje z Ramzanem Kadyrowem? Czeczeński opozycjonista mówi o śmierci, konwoje pod szpitalem
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200477,co-sie-dzieje-z-ramzanem-kadyrowem-czeczenski-opozycjonista.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200477,co-sie-dzieje-z-ramzanem-kadyrowem-czeczenski-opozycjonista.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T10:49:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7b/cd/1c/z30201467M,Ramzan-Kadyrow.jpg" vspace="2" />Pogłoski o pogarszającym się stanie zdrowia Ramzana Kadyrowa, przywódcy Czeczenii i bliskiego współpracownika Putina krążyły w mediach od kilku tygodni. Ostatnio zaczęły pojawiać się doniesienia, że Kadyrow zapadł w śpiączkę. A w niedzielę Abubakar Yangulbajew, lider czeczeńskiej opozycji napisał w komunikacie: "Kadyrow nie żyje". W tym czasie pod szpitalem, w którym miał leczyć się Kadyrow, pojawiły się sznury luksusowych aut należących do czeczeńskiej elity.

## Spadek powołań. "Takiej katastrofy jeszcze nie było". Kandydatów na księży odstrasza abp Jędraszewski?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200767,spadek-powolan-takiej-katastrofy-jeszcze-nie-bylo-kandydatow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200767,spadek-powolan-takiej-katastrofy-jeszcze-nie-bylo-kandydatow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T10:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a8/d6/1b/z29188520M,Abp-Marek-Jedraszewski.jpg" vspace="2" />Rekrutacja do Wyższego Seminarium Duchownego Archidiecezji Krakowskiej, która uchodzi za centrum polskiego życia religijnego, dobiegła końca. Do drugiej tury dopuszczono zaledwie kilka osób. Nie wiadomo jednak ilu z nich pozytywnie przeszło egzaminy. - W kurii popłoch, bo takiej katastrofy jeszcze nie było - skomentował proboszcz z podkrakowskiej parafii w rozmowie z "Gazetą Wyborczą".

## Chcą Trybunału Stanu dla szefa MON Mariusza Błaszczaka za odtajnienie dokumentów. Już szykują wniosek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201136,rzecznik-po-przygotujemy-wniosek-o-trybunal-stanu-dla-blaszczaka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30201136,rzecznik-po-przygotujemy-wniosek-o-trybunal-stanu-dla-blaszczaka.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T09:35:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/35/1c/z29578105M,WAZNE.jpg" vspace="2" />- Za odtajnienie ściśle tajnych dokumentów w celach wyborczych grozi Trybunał Stanu. To odpowiedzialność, którą poniesie minister Błaszczak - zapowiedział rzecznik Platformy Obywatelskiej. Chodzi o ujawnione przez PiS dokumenty, z których wynika, że za czasów rządów PO-PSL plan obrony Polski rozpoczynał się od linii Wisły. - Tego będziemy się domagać i przygotujemy wniosek - podkreślił Jan Grabiec.

## Czy afera wizowa wpłynie na wynik PiS w wyborach? Są nowe sondaże
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200389,czy-afera-wizowa-wplynie-na-wynik-pis-w-wyborach-sa-nowe-sondaze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200389,czy-afera-wizowa-wplynie-na-wynik-pis-w-wyborach-sa-nowe-sondaze.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T09:29:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/58/cb/1c/z30192984M,Jaroslaw-Kaczynski--prezes-PiS--przy-granicy-polsk.jpg" vspace="2" />Większość Polaków nie wierzy w zapewnienia PiS ws. zabezpieczenia granic - pokazuje sondaż United Surveys dla Wirtualnej Polski. Afera wizowa jednak nie wpłynie znacząco na rezultat PiS w wyborach parlamentarnych. Jak wynika z badania IBRiS dla "Rzeczpospolitej" i RMF FM, tylko 30 proc. respondentów uważa, że może osłabić poparcie dla PiS.

## Wybuch granatnika w KGP. Brejza pokazuje zdjęcia. "Najbardziej strzeżona tajemnica państwa PiS"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200779,wybuch-granatnika-w-kgp-brejza-pokazuje-zdjecia-najbardziej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200779,wybuch-granatnika-w-kgp-brejza-pokazuje-zdjecia-najbardziej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T09:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/64/cd/1c/z30200932M,Wybuch-granatnika-w-KGP--Brejza-pokazuje-zdjecia.jpg" vspace="2" />Krzysztof Brejza opublikował zdjęcia, które miały zostać wykonane po wybuchu granatnika w Komendzie Głównej Policji. "Ujawniam najbardziej strzeżoną tajemnicę państwa PiS" - podkreślił senator.

## Gniezno. Pijany ojciec potrącił 15-miesięczną córkę. Dziecko zabrał helikopter LPR
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200601,gniezno-pijany-ojciec-potracil-15-miesieczna-corke-dziecko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200601,gniezno-pijany-ojciec-potracil-15-miesieczna-corke-dziecko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T08:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/a8/1c/z30050442M,Raczka-niemowlecia---zdjecie-ilustracyjne.jpg" vspace="2" />W Gnieźnie 15-miesięczna dziewczynka została potrącona przez samochód. Pojazdem kierował jej nietrzeźwy ojciec. Dziecko zostało zabrane do szpitala przez śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Szef NIK Marian Banaś zawiadamia prokuraturę w związku działaniami Elżbiety Witek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200766,szef-nik-marian-banas-zawiadamia-prokurature-w-zwiazku-dzialaniami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200766,szef-nik-marian-banas-zawiadamia-prokurature-w-zwiazku-dzialaniami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T08:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/35/1c/z29578105M,WAZNE.jpg" vspace="2" />Prezes Najwyższej Izby Kontroli Marian Banaś złożył w prokuraturze zawiadomienie o możliwości popełnienia przestępstwa przez marszałkini Sejmu Elżbietę Witek - poinformowało RMF FM. Zdaniem szefa NIK marszałek Witek swoimi zaniechaniami doprowadziła do pozbawienia Izby możliwości działania i podejmowania decyzji.

## Sikorski: Błaszczak zrobił Rosji prezent, jak Macierewicz, który odtajnił raport z weryfikacji WSI
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200466,sikorski-ostro-o-odtajnieniu-planow-operacyjnych-wojska-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200466,sikorski-ostro-o-odtajnieniu-planow-operacyjnych-wojska-po.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T08:31:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/09/cd/1c/z30200585M,Radoslaw-Sikorski-w--Porannej-rozmowie-Gazeta-pl--.jpg" vspace="2" />- Ruską rakietę minister Błaszczak utajnił, a fakt istnienia wariantowego planu samodzielnej obrony Polski, na wypadek gdyby spóźniali się sojusznicy, to tę kwestię ujawnił. Zrobił coś skandalicznego! Tak Radosław Sikorski ocenił ostatni spot PiS, w którym szef resortu obrony pokazał odtajnione dokumenty dotyczące obrony Polski w razie agresji. Zdaniem gościa "Porannej rozmowy Gazeta.pl" dla partii Kaczyńskiego nie ma żadnych świętości.

## Prawybory w Wieruszowie. "Zaczniemy proces stawiania tego kraju z głowy na nogi" [KOMENTARZE]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200358,komentarze-po-prawyborach-w-wieruszowie-zaczniemy-proces-stawiania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200358,komentarze-po-prawyborach-w-wieruszowie-zaczniemy-proces-stawiania.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T08:09:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/cd/1c/z30200573M,Prawybory-w-Wieruszowie.jpg" vspace="2" />Nie cichną komentarz po prawyborach przeprowadzonych w Wieruszowie. - Ta wygrana to znak nadziei, nie gwarancja zwycięstwa. Wszystko w naszych rękach! - komentował Donald Tusk, lider KO. Wygrała je Koalicja Obywatelska, zdobywając 34 procent głosów, drugie miejsce zajęło Prawo i Sprawiedliwość.

## Spot PiS to "zdrada" NATO. Gen. Skrzypczak: To dowód, że jesteśmy zdolni do wszystkiego
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200258,spot-pis-to-zdrada-nato-gen-skrzypczak-to-dowod-ze-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200258,spot-pis-to-zdrada-nato-gen-skrzypczak-to-dowod-ze-jestesmy.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T07:53:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7f/88/1c/z29917567M,General-Waldemar-Skrzypczak.jpg" vspace="2" />PiS, aby uderzyć w swoich przeciwników politycznych, a dokładnie Donalda Tuska, w swoim najnowszym spocie opublikował fragment dokumentu, który jeszcze do lipca miał klauzulę "ściśle tajne". - Ja nie wiem, czy jest jakieś słowo, które określiłoby to, co zrobiono - skomentował gen. Waldemar Skrzypczak. - Ten dokument jest konsekwencją dokumentów doktrynalnych NATO-wskich, jego ujawnienie jest ujawnieniem części filozofii NATO, czyli to zdrada - ocenił.

## Jaka będzie pogoda na koniec września? Czeka nas spore zaskoczenie. Upał, grad i burze, a to nie koniec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200255,jaka-bedzie-pogoda-na-koniec-wrzesnia-czeka-nas-spore-zaskoczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200255,jaka-bedzie-pogoda-na-koniec-wrzesnia-czeka-nas-spore-zaskoczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T07:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/a0/1c/z30016657M,Pogoda--zdjecie-ilustracyjne-.jpg" vspace="2" />Pogoda w kolejnym tygodniu września przywita nas ciepłą, wręcz upalną pogodą. W najbliższych dniach możemy się spodziewać wysokiej temperatury, jednak wystąpią również gwałtowne burze. Mimo chwilowego ochłodzenia ostatnie dni września będą ciepłe i słoneczne.

## Awantura o ukraińskie zboże. Ukraina pozwie Polskę, Słowację i Węgry. Zapowiada też restrykcje
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200497,awantura-o-ukrainskie-zboze-ukraina-pozwie-polske-slowacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200497,awantura-o-ukrainskie-zboze-ukraina-pozwie-polske-slowacje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T07:17:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/06/cd/1c/z30200582M,Ukrainskie-zboze.jpg" vspace="2" />Kijów pozwie Polskę, Węgry i Słowację do Światowej Organizacji Handlu - zapowiedział wiceminister rolnictwa Ukrainy. Kraje te odmówiły bowiem zniesienia zakazu importu ukraińskich produktów rolnych.

## Silne trzęsienie ziemi w okolicach Florencji we Włoszech. Jest oświadczenie gubernatora Toskanii
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200309,silne-trzesienie-ziemi-w-okolicach-florencji-we-wloszech-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200309,silne-trzesienie-ziemi-w-okolicach-florencji-we-wloszech-jest.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T06:52:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/2f/cd/1c/z30200367M,Silne-trzesienie-ziemi-w-okolicach-Florencji-we-Wl.jpg" vspace="2" />Silne trzęsienie ziemi w poniedziałek rano obudziło mieszkańców środkowych Włoch. Wstrząsy o magnitudzie 4,8 pojawiły się w rejonie Florencji. Włoskie władze informują, że nie odnotowano znaczących szkód, nie ma też informacji o poszkodowanych.

## Nowy wątek w aferze wizowej. Chodzi o Piotra Glińskiego. Prasa: "Naciskał na Wawrzyka"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200265,nowy-watek-w-aferze-wizowej-chodzi-o-piotra-glinskiego-prasa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200265,nowy-watek-w-aferze-wizowej-chodzi-o-piotra-glinskiego-prasa.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T06:37:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/7a/c7/1c/z30176378M,Minister-Piotr-Glinski.jpg" vspace="2" />Edgar K., który w kwietniu został zatrzymany z powodu afery wizowej, to człowiek ministra kultury - twierdzą źródła "Gazety Wyborczej". "Wedle korytarzowych informacji, na Piotra Wawrzyka - o wydanie wiz dla tzw. filmowców - naciskał Piotr Gliński, ówczesny wicepremier, który lubi podkreślać, że rządzi i jest ważną personą" - przekazał informator "GW". Gliński zaprzecza.

## Afera wizowa. Rozbawiony Sikorski tłumaczy komunikat MSZ: Moje nazwisko dopisano na kolanie na Nowogrodzkiej
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200129,radoslaw-sikorski-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200129,radoslaw-sikorski-gosciem-porannej-rozmowy-gazeta-pl.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T06:21:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/44/cd/1c/z30200132M,Radoslaw-Sikorski-gosciem--Porannej-rozmowy-Gazeta.jpg" vspace="2" />- Wszystkie umowy outsourcingowe były zawierane w czasie rządów Prawa i Sprawiedliwości - mówił w poniedziałek w "Porannej rozmowy Gazeta.pl" jest Radosław Sikorski, europoseł i były szef MSZ.

## Jak poradzicie sobie z quizem politycznym? Komplet punktów dla najlepszych!
 - [https://wiadomosci.gazeta.pl/wiadomosci/13,129662,18701,jak-poradzicie-sobie-z-quizem-politycznym-komplet-punktow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/13,129662,18701,jak-poradzicie-sobie-z-quizem-politycznym-komplet-punktow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T06:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/d5/5a/1c/z29729749M,Grafika-do-quizu-politycznego.jpg" vspace="2" />Dacie radę prawidłowo odpowiedzieć na wszystkie pytania?

## Szef MSZ powtarza hasła PiS o aferze wizowej. Rau jednoznacznie o ewentualnej dymisji
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200254,szef-msz-powtarza-hasla-pis-u-o-aferze-wizowej-rau-jednoznacznie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114884,30200254,szef-msz-powtarza-hasla-pis-u-o-aferze-wizowej-rau-jednoznacznie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T05:54:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/b6/ca/1c/z30191286M,Minister-spraw-zagranicznych-Polski-Zbigniew-Rau-.jpg" vspace="2" />"Kaskada fake newsów" - tak minister spraw zagranicznych Zbigniew Rau określił informacje na temat afery wizowej. Jego zdaniem żadnej afery nie ma. - Nie czuję się współwinny, nie rozważam podania się do dymisji i nie ma żadnej afery wizowej - stwierdził szef polskiej dyplomacji zapytany w Nowym Jorku o proceder wydawania polskich wiz migrantom z Azji i Afryki.

## Adam Michnik: PiS gra antyniemiecką kartą
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30200227,adam-michnik-pis-gra-antyniemiecka-karta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,127561,30200227,adam-michnik-pis-gra-antyniemiecka-karta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T05:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/be/da/18/z26060478M,Adam-Michnik--redaktor-naczelny--Gazety-Wyborczej-.jpg" vspace="2" />Były polski opozycjonista Adam Michnik ostro krytykuje antyniemiecką propagandę uprawianą przez Prawo i Sprawiedliwość (PiS). Jego zdaniem rząd kanclerza Olafa Scholza zerwał ostatecznie więzi z Rosją.

## Polityczka oskarżała osoby LGBT o "seksualizację". Wyrzucono ją z teatru za obmacywanie przy dzieciach
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200127,polityczka-oskarzala-osoby-lgbt-o-seksualizacje-wyrzucono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,114881,30200127,polityczka-oskarzala-osoby-lgbt-o-seksualizacje-wyrzucono.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T05:00:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/62/cd/1c/z30200162M,Lauren-Boebert.jpg" vspace="2" />Członkini amerykańskiej Izby Reprezentantów republikanka Lauren Boebert została wyrzucona z teatru po tym jak paliła, robiła zdjęcia z fleszem i przeszkadzała innym podczas musicalu "Beetlejuice". Gdy polityczka nie zdobyła się na przeprosiny i zaprzeczała swojemu zachowaniu, ujawniono, że główną przyczyną usunięcia jej z sali - choć wymienione wcześniej również są prawdziwe - było intensywne obłapianie się Boebert i towarzyszącego jej mężczyzny.

## Kandydaci ze świata "Z archiwum X". "Przyszły Sejm będzie tego ucieleśnieniem"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30193724,kandydaci-ze-swiata-z-archiwum-x-przyszly-sejm-bedzie-tego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30193724,kandydaci-ze-swiata-z-archiwum-x-przyszly-sejm-bedzie-tego.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T04:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9e/b8/1c/z30115486M,Janusz-Korwin-Mikke-na-konwencji-Konfederacji-w-Wa.jpg" vspace="2" />Dżentelmeni z Konfederacji marginalizują Brauna, wycinają z plakatów, blokują kandydatów na listach. Celem jest przekształcenie całej formacji z partii radykałów i postrzeleńców w ugrupowanie głównego nurtu. To trudne z człowiekiem, który uważa, że Żydzi sterują Polską z podziemnego bunkra - rozmowa z Przemysławem Witkowskim.

## Na wierzchu spójna, w środku trzeszczy od różnic. Po wyborach w Konfederacji będzie "Gra o tron"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30188764,na-wierzchu-spojna-w-srodku-trzeszczy-od-roznic-po-wyborach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30188764,na-wierzchu-spojna-w-srodku-trzeszczy-od-roznic-po-wyborach.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T04:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/fd/cb/1c/z30192125M,Liderzy-Konfederacji.jpg" vspace="2" />Konfederacja nie jest monolitem. Zaaranżowane z rozsądku małżeństwo łączy wolnorynkowych konserwatystów z narodowcami o twarzy merytorycznego Krzysztofa Bosaka. Na użytek kampanii wyborczej różnice pochowano, a niewygodnego Grzegorza Brauna z antysemicką drużyną zepchnięto w cień. Pytanie, jak długo wizerunek spójnej formacji uda się utrzymać.

## Prawybory w Wieruszowie wygrała Koalicja Obywatelska. Donald Tusk: Wszystko w naszych rękach!
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200215,prawybory-w-wieruszowie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,143907,30200215,prawybory-w-wieruszowie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T04:25:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/9c/cd/1c/z30200220M,Prawybory-w-Wieruszowie-wygrala-Koalicja-Obywatels.jpg" vspace="2" />Niespełna 20 procent uprawnionych do głosowania uczestniczyło w prawyborach w Wieruszowie, w województwie łódzkim. W niedzielę przeprowadzono tam prawybory, które wygrała Koalicja Obywatelska, zdobywając 34 procent głosów. Cztery lata temu w wyborach parlamentarnych w Wieruszowie wygrało Prawo i Sprawiedliwość z poparciem 45 procent.

## Horoskop dzienny - poniedziałek 18 września [Baran, Byk, Bliźnięta, Rak, Lew, Panna, Waga, Skorpion, Strzelec, Koziorożec, Wodnik, Ryby]
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30196581,horoskop-dzienny-poniedzialek-18-wrzesnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882](https://wiadomosci.gazeta.pl/wiadomosci/7,168571,30196581,horoskop-dzienny-poniedzialek-18-wrzesnia-baran-byk-bliznieta.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10199882)
 - RSS feed: https://wiadomosci.gazeta.pl/pub/rss/wiadomosci.xml
 - date published: 2023-09-18T03:30:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/99/cc/1c/z30196633M,Horoskop-dzienny-na-poniedzialek.jpg" vspace="2" />Poniedziałek niespodziewanie przyniesie wiele nowości dla Wag i Baranów. Z kolei dla Bliźniąt i Wodników będzie to szczególnie udany dzień. Co czeka pozostałe znaki zodiaku? Odpowiedzi udziela horoskop dzienny na poniedziałek.

