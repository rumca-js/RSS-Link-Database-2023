# Source:Bankier, URL:https://www.bankier.pl/rss/wiadomosci.xml, language:pl-PL

## Ukraina złożyła skargę do WTO na Polskę, Węgry i Słowację
 - [https://www.bankier.pl/wiadomosc/Ukraina-zlozyla-skarge-do-WTO-na-Polske-Wegry-i-Slowacje-8613360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-zlozyla-skarge-do-WTO-na-Polske-Wegry-i-Slowacje-8613360.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T17:36:42.983262+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/cbfcb8d0d35d84-948-568-10-140-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina złożyła w poniedziałek skargi do Światowej Organizacji Handlu (WTO) na Polskę, Węgry i Słowację w związku z przedłużeniem przez te kraje embarga na ukraińskie produkty rolne - poinformowała ukraińska minister gospodarki Julia Swyrydenko w komunikacie.</p>

## Wydano decyzję o lokalizacji pierwszej elektrowni jądrowej w Polsce
 - [https://www.bankier.pl/wiadomosc/Wydano-decyzje-o-lokalizacji-pierwszej-elektrowni-jadrowej-w-Polsce-8613338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wydano-decyzje-o-lokalizacji-pierwszej-elektrowni-jadrowej-w-Polsce-8613338.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T17:20:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/5/d788fa3d50ec9a-948-568-0-281-4443-2666.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wojewoda pomorski Dariusz Drelich wydał decyzję o wskazaniu lokalizacji inwestycji - budowy obiektu energetyki jądrowej - poinformowano na stronie Pomorskiego Urzędu Wojewódzkiego w Gdańsku. Pierwsza w Polsce Elektrownia Jądrowa o mocy elektrycznej do 3750 MWe powstanie na obszarze gminy Choczewo.</p>

## Szeroka przecena spółek z WIG20. Odbicie upadającego BAH i zdejmowanego z GPW Kernela
 - [https://www.bankier.pl/wiadomosc/Szeroka-przecena-spolek-z-WIG20-Odbicie-upadajacego-BAH-i-zdejmowanego-z-GPW-Kernela-8613299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Szeroka-przecena-spolek-z-WIG20-Odbicie-upadajacego-BAH-i-zdejmowanego-z-GPW-Kernela-8613299.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T16:30:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/7/a08000e3dccc09-945-567-7-7-3000-1800.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Początek tygodnia, w którym rynki finansowe mają do przejścia maraton decyzji banków centralnych w sprawie stóp procentach, rozpoczął się od cofnięcia WIG20, wpisującego się w sentyment na innych rynkach europejskich. Pod presją szczególnie był sektor bankowy, ale słabo radziły sobie też energetyka, górnictwo i sektor paliwowy. Mocne odbicie zaliczyły kursy spółek, które ostatnio najmocniej traciły.</p>

## Znaczący spadek produkcji stali w Polsce. Jesteśmy w tyle Europy
 - [https://www.bankier.pl/wiadomosc/Znaczacy-spadek-produkcji-stali-w-Polsce-Jestesmy-w-tyle-Europy-8613276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Znaczacy-spadek-produkcji-stali-w-Polsce-Jestesmy-w-tyle-Europy-8613276.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T16:15:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/8/f8b6984868a119-948-568-0-31-1773-1063.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W pierwszym półroczu br. polska produkcja stali zmniejszyła się wobec pierwszego półrocza 2022 o ok. 20 proc. (w samym czerwcu o 33 proc.), a krajowe zużycie wyrobów stalowych spadło o 19 proc. - wynika z danych Hutniczej Izby Przemysłowo-Handlowej. Największym wyzwaniem dla branży są ceny energii - ocenia Izba.</p>

## Polska chce kolejnych sankcji przeciw Rosji i Białorusi. Oto propozycja 12. pakietu
 - [https://www.bankier.pl/wiadomosc/Polska-chce-kolejnych-sankcji-przeciw-Rosji-Oto-propozycja-12-pakietu-8613258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-chce-kolejnych-sankcji-przeciw-Rosji-Oto-propozycja-12-pakietu-8613258.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T16:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/d/dfa639595ddf16-948-568-0-113-3500-2099.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska przedstawiła w Brukseli propozycję 12. pakietu sankcji Unii Europejskiej przeciw Rosji; chodzi o sankcje sektorowe i indywidualne - przekazało PAP wysokie rangą źródło unijne.</p>

## Spór o zboże nadal trwa. Polska, Węgry i Słowacja podjęły wspólną decyzję
 - [https://www.bankier.pl/wiadomosc/Spor-o-zboze-trwa-Polska-Wegry-i-Slowacja-podjely-decyzje-8613243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spor-o-zboze-trwa-Polska-Wegry-i-Slowacja-podjely-decyzje-8613243.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T15:26:45.289460+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/e/d1d94e8b6df9a4-948-568-24-0-1812-1087.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W związku z zapowiedziami Ukrainy o wszczęciu postępowania przeciw Polsce, Węgrom i Słowacji przed Światową Organizacją Handlu (WTO), te trzy kraje UE nie będą uczestniczyć w pracach platformy ds. ukraińskiego zboża w Brukseli - poinformowało PAP źródło unijne.</p>

## Ukraina przedstawiła w Brukseli propozycję dotyczącą wwozu zboża do krajów UE
 - [https://www.bankier.pl/wiadomosc/Ukraina-przedstawila-w-Brukseli-propozycje-dotyczaca-wwozu-zboza-do-krajow-UE-8613204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ukraina-przedstawila-w-Brukseli-propozycje-dotyczaca-wwozu-zboza-do-krajow-UE-8613204.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T14:21:15.751657+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/0/4ffc7e7109117d-948-568-288-28-3552-2131.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ukraina przedstawiła w Brukseli propozycję dotyczącą wwozu swojego zboża do krajów UE, która zakłada system pozwoleń na eksport; państwa UE graniczące z Ukrainą uznały, że jest niewystarczająca.</p>

## Xi Jinping nazwany dyktatorem. Pekin składa skargę do rządu Niemiec
 - [https://www.bankier.pl/wiadomosc/Xi-Jinping-nazwany-dyktatorem-Pekin-sklada-skarge-do-rzadu-Niemiec-8613174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Xi-Jinping-nazwany-dyktatorem-Pekin-sklada-skarge-do-rzadu-Niemiec-8613174.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T14:11:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/a/0797157167385e-945-560-0-0-1500-899.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Określenie przywódcy ChRL Xi Jinpinga "dyktatorem" przez niemiecką minister spraw zagranicznych Annalenę Baerbock było "skrajnie absurdalne" – oświadczyła w poniedziałek rzeczniczka chińskiego MSZ Mao Ning w reakcji na słowa, które padły w trakcie wywiadu, udzielonego amerykańskiej telewizji w ubiegłym tygodniu.</p>

## Sporej części Polaków żyje się gorzej. Niewielkie nadzieje na pozytywne zmiany
 - [https://www.bankier.pl/wiadomosc/Sporej-czesci-Polakow-zyje-sie-gorzej-Niewielkie-nadzieje-na-pozytywne-zmiany-8613166.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sporej-czesci-Polakow-zyje-sie-gorzej-Niewielkie-nadzieje-na-pozytywne-zmiany-8613166.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T14:02:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/e/01ef9afed0de68-945-567-315-0-3016-1810.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Zmian poziomu bezrobocia w Polsce nie spodziewa się 69 proc. badanych, ale co piąty prognozuje jego wzrost - wynika z opublikowanego w poniedziałek badania firmy Ipsos.</p>

## Sasin: Tam, gdzie jest kwestia bezpieczeństwa, tam nie może być niewidzialnej ręki rynku
 - [https://www.bankier.pl/wiadomosc/Sasin-Tam-gdzie-jest-kwestia-bezpieczenstwa-tam-nie-moze-byc-niewidzialnej-reki-rynku-8613155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sasin-Tam-gdzie-jest-kwestia-bezpieczenstwa-tam-nie-moze-byc-niewidzialnej-reki-rynku-8613155.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T13:15:02.430296+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/a/fb49e827e76e90-948-568-0-67-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Tam, gdzie jest kwestia bezpieczeństwa, tam nie może być niewidzialnej ręki rynku - stwierdził w poniedziałek minister aktywów państwowych Jacek Sasin podczas 10. edycji konferencji "Śląski ład", mówiąc o polskim górnictwie.</p>

## Pierwsza kobieta skazana za unikanie służby wojskowej. Była w ciąży i opiekowała się dzieckiem
 - [https://www.bankier.pl/wiadomosc/Pierwsza-kobieta-skazana-za-unikanie-sluzby-wojskowej-Byla-w-ciazy-i-opiekowala-sie-dzieckiem-8613115.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pierwsza-kobieta-skazana-za-unikanie-sluzby-wojskowej-Byla-w-ciazy-i-opiekowala-sie-dzieckiem-8613115.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T13:01:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/d/1ce239e7ef0d8e-948-568-0-57-3800-2279.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sąd w Rosji skazał na karę sześciu lat pozbawienia wolności za unikanie służby wojskowej kapral Madinę Kabałojewą; to pierwszy w kraju taki wyrok orzeczony wobec kobiety - podała w poniedziałek niezależna rosyjska telewizja Nastojaszczeje Wriemia,  zaznaczając, że Kabałojewa jest w ciąży, a ponadto opiekuje się pięcioletnim dzieckiem.</p>

## Inflacja bazowa znów spadła. Jednak wciąż pozostaje bardzo wysoka
 - [https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-sierpien-2023-8613106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Inflacja-bazowa-w-Polsce-sierpien-2023-8613106.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/3/349ff6235a9e40-948-568-0-110-3990-2393.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Sierpień przyniósł dalszy spadek inflacji bazowej w Polsce – wynika z danych NBP. Problem w tym, że siła krajowej presji inflacyjnej pozostaje zbyt silna, aby oczekiwać szybkiego osiągnięcia 2,5-procentowego celu inflacyjnego.</p>

## VeloBank na sprzedaż, a kupiec może być sporym zaskoczeniem
 - [https://www.bankier.pl/wiadomosc/VeloBank-zostanie-w-polskich-rekach-Solowow-zainteresowany-przejeciem-8613095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/VeloBank-zostanie-w-polskich-rekach-Solowow-zainteresowany-przejeciem-8613095.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T13:00:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/5/8fa52e5553f35b-948-568-69-200-3414-2048.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niemal rok po utworzeniu VeloBanku nie milkną spekulacje o nowym nabywcy dawnego Getin Banku należącego do Leszka Czarneckiego. Nowy gracz w branży może być sporym zaskoczeniem, ale za to bank pozostałby w polskich rękach.</p>

## Votum spodziewa się mocnego IV kw. Chce wprowadzić nowy produkt
 - [https://www.bankier.pl/wiadomosc/Votum-spodziewa-sie-mocnego-IV-kw-w-X-chce-wprowadzic-nowy-produkt-8613085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Votum-spodziewa-sie-mocnego-IV-kw-w-X-chce-wprowadzic-nowy-produkt-8613085.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T12:10:02.578837+00:00

<p>Votum spodziewa się mocnego czwartego kwartału tego roku - poinformował prezes Votum Bartłomiej Krupa. W październiku firma chce wprowadzić do oferty nowy produkt, związany z dochodzeniem roszczeń z tytułu sankcji kredytu darmowego.</p>

## LPP kontynuuje ekspansję. Reserved debiutuje w stolicy mody
 - [https://www.bankier.pl/wiadomosc/LPP-otworzylo-pierwszy-salon-Reserved-we-Wloszech-8613111.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/LPP-otworzylo-pierwszy-salon-Reserved-we-Wloszech-8613111.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T12:10:02.551321+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/c/60ce77ee1a9f5b-948-568-70-6-2389-1433.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />LPP otworzyło pierwszy salon Reserved we Włoszech, w Mediolanie - poinformowała grupa w komunikacie prasowym. W planach są już następne otwarcia – w Mediolanie i miastach północnych Włoch, gdzie poza Reserved pojawią się pierwsze salony Mohito.</p>

## Konto mieszkaniowe niewypałem? PKO BP podał statystyki za pierwszy miesiąc
 - [https://www.bankier.pl/wiadomosc/Konto-mieszkaniowe-niewypalem-PKO-BP-podal-statystyki-za-pierwszy-miesiac-8613046.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Konto-mieszkaniowe-niewypalem-PKO-BP-podal-statystyki-za-pierwszy-miesiac-8613046.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T11:51:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/3/5/45b3ebeae85d95-948-568-0-310-2702-1621.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu pierwszego miesiąca założono ponad 900 Kont Mieszkaniowych w ramach Programu Pierwsze Mieszkanie - poinformował w poniedziałek PKO Bank Polski. Klienci wpłacili na tego typu rachunki średnio 1,9 tys. zł.</p>

## "Tu żarty się kończą". Błaszczak odtajnia dokumenty NATO do spotu wyborczego
 - [https://www.bankier.pl/wiadomosc/Tu-zarty-sie-koncza-Blaszczak-odtajnia-dokumenty-NATO-do-spotu-wyborczego-8613033.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Tu-zarty-sie-koncza-Blaszczak-odtajnia-dokumenty-NATO-do-spotu-wyborczego-8613033.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T11:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/8/f/e324f559b89012-948-568-570-52-2340-1403.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Minister obrony narodowej Mariusz Błaszczak publikuje spot wyborczy, w którym omawia dokładnie plany obrony NATO, a "na Kremlu otwierają szampany" - komentuje dla "Faktu" gen. Waldemar Skrzypczak, były dowódca Wojsk Lądowych. </p>

## "Przemysł stalowy kluczowy dla gospodarki". Sasin zapowiada inwestycje
 - [https://www.bankier.pl/wiadomosc/Przemysl-stalowy-kluczowy-dla-gospodarki-Sasin-zapowiada-inwestycje-8613039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przemysl-stalowy-kluczowy-dla-gospodarki-Sasin-zapowiada-inwestycje-8613039.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T11:04:56.635271+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/c/d/79887de78df108-945-560-0-250-4560-2735.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Przemysł stalowy, obok energetyki, jest kluczowy dla rozwoju polskiej gospodarki – ocenił podczas inauguracji Europejskiego Kongresu Stalowego w Katowicach minister aktywów państwowych Jacek Sasin. Zapowiedział odbudowę, wsparcie i rozwój części hutnictwa, pozostającej w domenie Skarbu Państwa.</p>

## Pushbacki napędzały handel wizami? Pośrednicy z MSZ zarejestrowani w Moskwie
 - [https://www.bankier.pl/wiadomosc/Pushbacki-napedzaly-handel-wizami-Posrednicy-z-MSZ-zarejestrowani-w-Moskwie-8612986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pushbacki-napedzaly-handel-wizami-Posrednicy-z-MSZ-zarejestrowani-w-Moskwie-8612986.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T11:04:56.622127+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/42c874e7bec37d-948-568-465-262-2535-1520.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />- Kiedy służby graniczne używały tzn. pushbacków, zrzucały osoby z polskiej granicy na teren Białorusi, to te osoby mogły później za łapówkę w Mińsku, a być może w Moskwie, otrzymać polską wizę i wjechać jakby nic do Polski - o procederze poseł Koalicji Obywatelskiej Michał Szczerba w rozmowie w tvn24. </p>

## Spółka FreeMind zadebiutowała na NewConnect
 - [https://www.bankier.pl/wiadomosc/Spolka-FreeMind-zadebiutowala-na-NewConnect-8612994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Spolka-FreeMind-zadebiutowala-na-NewConnect-8612994.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T10:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/4/c924d8358f24dc-948-568-353-0-1339-803.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Spółka FreeMind, należąca do grupy PlayWay, zadebiutowała na NewConnect. Do obrotu na rynku zostało dopuszczonych łącznie 1,107 mln akcji.</p>

## Trybunał Stanu dla Mariusza Błaszczaka? PO szykuje wniosek
 - [https://www.bankier.pl/wiadomosc/Trybunal-Stanu-dla-Mariusza-Blaszczaka-PO-szykuje-wniosek-8612963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trybunal-Stanu-dla-Mariusza-Blaszczaka-PO-szykuje-wniosek-8612963.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T09:59:55.019642+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/720c2c18998510-945-567-70-19-1841-1105.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Za odtajnienie ściśle tajnych dokumentów w celach wyborczych grozi Trybunał Stanu. To odpowiedzialność, którą poniesie szef MON Mariusz Błaszczak. Będziemy się domagać i przygotujemy wniosek - zapowiedział w poniedziałek w radiu Zet rzecznik PO Jan Grabiec.</p>

## Sprzedaż paliwa poniżej kosztów. Tak Francja chce walczyć z inflacją
 - [https://www.bankier.pl/wiadomosc/Sprzedaz-paliwa-ponizej-kosztow-Tak-Francja-chce-walczyc-z-inflacja-8612972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Sprzedaz-paliwa-ponizej-kosztow-Tak-Francja-chce-walczyc-z-inflacja-8612972.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T09:59:55.014538+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/e/85775876aee5a5-948-568-11-99-2189-1313.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Francuski rząd przygotowuje projekt ustawy zezwalającej stacjom na sprzedaż paliwa poniżej kosztów, aby ograniczyć inflację. Sprzedaż paliwa ze stratą będzie trwała przez sześć miesięcy od początku grudnia – zapowiedział w poniedziałek minister gospodarki i finansów Bruno Le Maire w stacji France 2.</p>

## NFZ pokazał, ile wydał na leczenie "najdroższych" pacjentów
 - [https://www.bankier.pl/wiadomosc/NFZ-pokazal-ile-wydal-na-leczenie-najdrozszych-pacjentow-8612970.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/NFZ-pokazal-ile-wydal-na-leczenie-najdrozszych-pacjentow-8612970.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T09:59:55.004722+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/3/403e634645ff45-945-560-113-37-1641-984.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />80 proc. budżetu na świadczenia i leki jest przeznaczane dla 20 proc. najbardziej potrzebujących pacjentów – wynika z najnowszego raportu NFZ, który podsumował koszty leczenia w 2022 r.</p>

## Nadchodzi zima z hotelarstwie. Pierwszy spadek liczby ogłoszeń o pracę od 10 miesięcy
 - [https://www.bankier.pl/wiadomosc/Coraz-mniej-ogloszen-o-prace-Nadchodzi-zima-z-hotelarstwie-8612956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Coraz-mniej-ogloszen-o-prace-Nadchodzi-zima-z-hotelarstwie-8612956.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T09:43:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/7/ce0c00dbe0e8fa-948-568-0-99-1732-1039.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Liczba ogłoszeń o pracę w hotelarstwie w sierpniu zmalała po raz pierwszy od 10 miesięcy - wynika z opublikowanego w poniedziałek Barometru Ofert Pracy. Zwrócono uwagę na "stosunkowo dobrą" sytuację w kategorii ofert dla pracowników niewykwalifikowanych.</p>

## Deweloperzy utrzymali wysoką marżę na mieszkaniach. NBP pokazuje nowe dane
 - [https://www.bankier.pl/wiadomosc/Deweloperzy-utrzymali-wysoka-marze-na-mieszkaniach-NBP-pokazuje-nowe-dane-8612945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Deweloperzy-utrzymali-wysoka-marze-na-mieszkaniach-NBP-pokazuje-nowe-dane-8612945.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T08:54:53.093321+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/e/c6e396364d8382-948-568-0-133-1978-1186.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />NBP szacuje, że udział zysku deweloperskiego w cenie netto mieszkań wynosi ok. 22 proc. - podał NBP w raporcie poświęconym rynkowi nieruchomości. Deweloperom udawało się w znaczącym stopniu przerzucić na nabywców rosnące koszty budowy mieszkań - dodano.</p>

## Klienci UPC Polska skarżą Play do UOKiK
 - [https://www.bankier.pl/wiadomosc/Klienci-UPC-Polska-skarza-Play-do-UOKiK-8612883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Klienci-UPC-Polska-skarza-Play-do-UOKiK-8612883.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T08:54:53.086619+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/d/e212b00cb7f71e-948-568-0-181-2989-1793.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Po fuzji Play i UPC Polska do Urzędu Ochrony Konkurencji i Konsumentów wpłynęło kilka skarg. Klienci informują o spadku jakości usług oraz sprzecznych informacjach otrzymywanych od konsultantów firm.</p>

## Aresztowania w Evergrande i zjazd akcji. Chińskie indeksy coraz niżej
 - [https://www.bankier.pl/wiadomosc/Chinska-policja-aresztowala-pracownikow-Evergrande-8612901.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chinska-policja-aresztowala-pracownikow-Evergrande-8612901.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T08:54:53.079540+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/c/e525cc6b5deffc-948-568-12-0-970-582.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Chińska policja aresztowała pracowników działu zarządzania majątkiem Evergrande Group - najbardziej zadłużonego dewelopera na świecie. Chiński sektor nieruchomości ma też inne, być może poważniejsze problemy, potęgujące nieufność do akcji z Państwa Środka, których indeksy znajdują się w pobliżu tegorocznych dołków.</p>

## "Lewe" liczniki naganiały na zakupy. UOKiK ukarał 2 strony internetowe
 - [https://www.bankier.pl/wiadomosc/Lewe-liczniki-naganialy-na-zakupy-UOKiK-ukaral-bigotka-pl-i-arkadie-pl-8612909.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Lewe-liczniki-naganialy-na-zakupy-UOKiK-ukaral-bigotka-pl-i-arkadie-pl-8612909.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T08:31:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/a/05fcd272da9401-945-567-108-269-1218-731.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Prezes UOKiK nałożył ponad 100 tys. zł kary na spółkę Bak Drop za nieuczciwe praktyki na stronach internetowych bigotka.pl i arkadie.pl - poinformował w poniedziałek Urząd Ochrony Konkurencji i Konsumentów. Wyjaśnił, że brakowało jasnej informacji, że konsument kupuje u pośrednika.</p>

## Złoty pozostaje osłabiony. Kurs euro zagościł powyżej 4,60 zł
 - [https://www.bankier.pl/wiadomosc/Zloty-pozostaje-oslabiony-Kurs-euro-zagoscil-powyzej-4-60-zl-8612900.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Zloty-pozostaje-oslabiony-Kurs-euro-zagoscil-powyzej-4-60-zl-8612900.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T07:49:56.132251+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/d/e0cf908023d65b-948-568-52-59-2947-1768.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Polska
waluta pozostaje słaba od dnia „gołębiej” wolty w wykonaniu Rady Polityki Pieniężnej.
Ekonomiści są sceptycznie nastawieni do dalszych perspektyw złotego.</p>

## "Stopa bezrobocia powinna wzrosnąć o 40-50 proc." Oto recepta milionera na poprawę sytuacji w gospodarce
 - [https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-powinna-wzrosnac-o-40-50-proc-Oto-recepta-milionera-na-poprawe-sytuacji-w-gospodarce-8612876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Stopa-bezrobocia-powinna-wzrosnac-o-40-50-proc-Oto-recepta-milionera-na-poprawe-sytuacji-w-gospodarce-8612876.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T07:49:56.129440+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/9/0/8765a1bb9d87a2-948-568-18-4-1664-998.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />"Stopa bezrobocia powinna wzrosnąć o 40-50%, aby ludzie ponownie uświadomili sobie, że pracują dla swoich szefów, a nie odwrotnie".
 To słowa jednego z najbogatszych Australijczyków - Tima Gurnera. O 
Gurnerze, biznesmenie i milionerze, zrobiło się głośno kilka dni temu, 
kiedy to podzielił się swoimi zaskakującymi przemyśleniami podczas 
panelu dyskusyjnego podczas szczytu dotyczącego nieruchomości Financial Review Property Summit. </p>

## Praca Polaków za granicą. Nawet dwukrotne różnice w zarobkach
 - [https://www.bankier.pl/wiadomosc/Praca-Polakow-za-granica-Nawet-dwukrotne-roznice-w-zarobkach-8612891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Praca-Polakow-za-granica-Nawet-dwukrotne-roznice-w-zarobkach-8612891.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T07:49:56.110991+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/a/924a3a11fdb1da-945-567-286-242-3180-1908.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad dwa
razy więcej zarabiali Polacy pracujący w Niemczech, Wielkiej Brytanii i
Niderlandach od rodaków wykonujących swoje obowiązki w kraju - wynika z raportu "Polacy pracujący za granicą w 2022
r." przygotowanego przez Narodowy Bank Polski. Duże różnice widać zwłaszcza w transporcie,
budownictwie oraz gastronomii i hotelarstwie.</p>

## Wakacje kredytowe i zerowy VAT na żywność przedłużone? Soboń komentuje
 - [https://www.bankier.pl/wiadomosc/Wakacje-kredytowe-i-zerowy-VAT-na-zywnosc-przedluzone-Sobon-komentuje-8612873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Wakacje-kredytowe-i-zerowy-VAT-na-zywnosc-przedluzone-Sobon-komentuje-8612873.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T07:39:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/c/78ee0f147cafe7-948-568-3-0-1496-897.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu najbliższych dni, przed wyborami, będzie ogłoszona decyzja dotycząca wakacji kredytowych - powiedział w poniedziałek w Polsat News wiceminister finansów Artur Soboń. Dodał, że nie wyklucza przedłużenia zerowej stawki VAT na żywność w przyszłym roku.</p>

## Ropa wciąż drożeje. Cięcia Arabii Saudyjskiej i Rosji rządzą rynkiem
 - [https://www.bankier.pl/wiadomosc/Ropa-wciaz-drozeje-Ciecia-Arabii-Saudyjskiej-i-Rosji-rzadza-rynkiem-8612853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ropa-wciaz-drozeje-Ciecia-Arabii-Saudyjskiej-i-Rosji-rzadza-rynkiem-8612853.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T06:46:47.012386+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/e/af26799598de3a-948-568-0-247-3000-1799.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ceny ropy na giełdzie paliw w Nowym Jorku rosną i są powyżej 91 USD za baryłkę. Cięcia dostaw ropy z krajów sojuszu OPEC+ zacieśniły sytuację na rynkach paliw - podają maklerzy.</p>

## 1 mld zł na 500+ dla obcokrajowców. ZUS podsumował półrocze
 - [https://www.bankier.pl/wiadomosc/1-mld-zl-na-500-dla-obcokrajowcow-ZUS-podsumowal-polrocze-8612857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/1-mld-zl-na-500-dla-obcokrajowcow-ZUS-podsumowal-polrocze-8612857.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T06:46:46.978963+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/6/3/bf076c6981d215-948-568-0-9-1980-1187.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ponad 2 mln świadczeń w ramach programu „Rodzina 500+” Zakład Ubezpieczeń Społecznych wypłacił obcokrajowcom – informuje Business Insider. 90 proc. z nich trafiło do Ukraińców.
</p>

## KO wygrała prawybory w Wieruszowie. Dobry wynik Trzeciej Drogi
 - [https://www.bankier.pl/wiadomosc/KO-wygrala-prawybory-w-Wieruszowie-Dobry-wynik-Trzeciej-Drogi-8612846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/KO-wygrala-prawybory-w-Wieruszowie-Dobry-wynik-Trzeciej-Drogi-8612846.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T06:40:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/7/5/463529a2c440aa-948-568-0-419-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />KO przed PiS-em, za nimi Trzecia Droga. Tak prezentują się wyniki 
prawyborów, które jak co roku odbyły się w Wieruszowie, nazywanym 
"Polską w pigułce".</p>

## Home office odchodzi do lamusa. Firmy ściągają pracowników do biur
 - [https://www.bankier.pl/wiadomosc/Home-office-odchodzi-do-lamusa-Firmy-sciagaja-pracownikow-do-biur-8612829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Home-office-odchodzi-do-lamusa-Firmy-sciagaja-pracownikow-do-biur-8612829.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:41:44.097598+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/2/b/c5c7b81cefc54f-948-567-10-52-990-593.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Większość firm chciałaby przywrócić pełną pracę stacjonarną, lecz opór pracowników często ogranicza takie zapędy - czytamy w poniedziałkowym wydaniu "Rzeczpospolitej".</p>

## Polacy "rzucą się" na emerytury stażowe? Minister pokazuje szacunki
 - [https://www.bankier.pl/wiadomosc/Polacy-rzuca-sie-na-emerytury-stazowe-Minister-pokazuje-szacunki-8612834.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polacy-rzuca-sie-na-emerytury-stazowe-Minister-pokazuje-szacunki-8612834.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:41:44.095332+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/b/c4f3850668d0b8-948-567-0-10-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Wstępnie szacujemy, że w pierwszym roku z emerytur stażowych skorzysta 70 tys. osób - powiedział w poniedziałkowym wydaniu "Naszego Dziennika" wiceminister rodziny i polityki społecznej Stanisław Szwed.</p>

## Polska bije rekordy eksportu zbóż. Głównie przez porty w Gdańsku, Gdyni i w Świnoujściu
 - [https://www.bankier.pl/wiadomosc/Polska-bije-rekordy-eksportu-zboz-Glownie-przez-porty-w-Gdansku-Gdyni-i-w-Swinoujsciu-8612820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Polska-bije-rekordy-eksportu-zboz-Glownie-przez-porty-w-Gdansku-Gdyni-i-w-Swinoujsciu-8612820.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:41:44.085215+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/e/9/cbfcb8d0d35d84-948-568-10-140-1990-1193.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Od stycznia ub. r. do lipca br. Polska wyeksportowała rekordową ilość zbóż - 16,8 mln ton. Tylko w pierwszych 7 miesiącach tego roku wywieziono z kraju 7,7 mln ton ziarna zbóż, o 57 proc. więcej niż przed rokiem - poinformował PAP wiceszef KOWR Marcin Wroński.</p>

## Przstępcy wyłudzili miliony złotych od urzędów miast i gmin. Robili to tak
 - [https://www.bankier.pl/wiadomosc/Przstepcy-wyludzili-miliony-zlotych-od-urzedow-miast-i-gmin-Robili-to-tak-8612832.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Przstepcy-wyludzili-miliony-zlotych-od-urzedow-miast-i-gmin-Robili-to-tak-8612832.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:41:44.082993+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/d/1/30d049ca382fad-937-562-0-0-937-562.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />11 mln zł strat - To wstępne szacunki policjantów z Centralnego Biura Zwalczania Cyberprzestępczości. Gang zdobył je, oszukując samorządy i zajmując się praniem brudnych pieniędzy. </p>

## Chiny z chrapką na tytuł hegemona. Mają nawet datę detronizacji USA
 - [https://www.bankier.pl/wiadomosc/Chiny-z-chapka-na-tytul-hegemona-Maja-nawet-date-detronizacji-USA-8612825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Chiny-z-chapka-na-tytul-hegemona-Maja-nawet-date-detronizacji-USA-8612825.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:41:44.078448+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/1/9/cab6ae91d96d41-948-568-45-0-2725-1635.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />W ciągu ostatnich 30 lat Chiny błyskawicznie rozwinęły się gospodarczo i politycznie, chcąc zagrozić hegemonii Stanów Zjednoczonych. Państwo Środka prowadzi też coraz bardziej asertywną politykę na arenie międzynarodowej, wykorzystując organizacje międzynarodowe do budowania swoich wpływów i lobbowania. - Chińczycy stawiają sobie 2049 rok - czyli stulecie utworzenia Chińskiej Republiki Ludowej - jako pewnego rodzaju cel strategiczny- mówi dr Tomasz Smura, członek zarządu Fundacji im. Kazimierza Pułaskiego.</p>

## Skutki palenia papierosów i niezdrowego trybu życia obciążeniem dla systemu ochrony zdrowia
 - [https://www.bankier.pl/wiadomosc/Skutki-palenia-papierosow-i-niezdrowego-trybu-zycia-obciazeniem-dla-systemu-ochrony-zdrowia-8612817.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Skutki-palenia-papierosow-i-niezdrowego-trybu-zycia-obciazeniem-dla-systemu-ochrony-zdrowia-8612817.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:35:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/b/2/54bfa50abae8e6-945-567-0-256-1725-1035.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Niezdrowy tryb życia - alkohol, zła dieta, stres czy palenie papierosów - jest jedną z głównych przyczyn chorób cywilizacyjnych i wywołanych nimi przedwczesnych zgonów. Eksperci wskazują...</p>

## Trzęsienie ziemi we Włoszech. Jest nowy komunikat władz
 - [https://www.bankier.pl/wiadomosc/Trzesienie-ziemi-we-Wloszech-w-prowincji-Florencja-8612814.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Trzesienie-ziemi-we-Wloszech-w-prowincji-Florencja-8612814.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T05:24:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/5/6aa6d54ae62f32-948-567-0-62-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Trzęsienie ziemi o magnitudzie 5,1 zarejestrowano w poniedziałek nad ranem na północy Włoch - podała amerykańska służba geologiczna USGS. Nie spowodowało ono jednak poważnych zniszczeń - poinformowały władze regionu Toskania i włoski Narodowy Instytut Geofizyki i Wulkanologii (INGV).</p>

## „Bezpieczny kredyt 2 proc.” zakorkował banki. Ekspert radzi: zachowajmy cierpliwość, sytuacja się poprawia
 - [https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-zakorkowal-banki-Ekspert-radzi-zachowajmy-cierpliwosc-sytuacja-sie-poprawia-8611744.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Bezpieczny-kredyt-2-proc-zakorkowal-banki-Ekspert-radzi-zachowajmy-cierpliwosc-sytuacja-sie-poprawia-8611744.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T04:36:41.314454+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/f/0/4fc7eb8547af22-948-568-0-207-3081-1848.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Rząd chce, by do końca tego roku
banki obsłużyły 50 tys. wniosków dotyczących „Bezpiecznego kredytu 2 proc.”. Na
razie, od lipca, udało się wydać około 6 tys. decyzji. W mailach do redakcji
pytają Państwo, dlaczego banki tak długo analizują wnioski. Ekspert radzi, by
uzbroić się w cierpliwość i wskazuje, z czego wynikają kolejki.</p>

## Górnicy, państwo i drobni akcjonariusze JSW w kolejce po zyski. Nie wszystkim po równo
 - [https://www.bankier.pl/wiadomosc/Pracownicy-panstwo-i-drobni-akcjonariusze-JSW-w-kolejce-po-zyski-spolki-8611484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Pracownicy-panstwo-i-drobni-akcjonariusze-JSW-w-kolejce-po-zyski-spolki-8611484.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T04:36:41.311747+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/5/7/d45cb815b417e4-948-568-0-25-2048-1228.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Brak dywidendy od JSW to jeden z najgorętszych giełdowych tematów w 2023 r. Uchwała w tej sprawie jest już dawno podjęta, ale temperatura wciąż nie opada. Realia są jednak takie, że w kolejce do zysków są zbierający podatki państwo, znów państwo jako główny akcjonariusz, górnicy, a na końcu mniejszościowi akcjonariusze.</p>

## Hipoteki ruszyły – oprocentowanie zdecydowanie spada
 - [https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-wrzesien-2023-najlepsze-kredyty-hipoteczne-8611913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ranking-kredytow-hipotecznych-wrzesien-2023-najlepsze-kredyty-hipoteczne-8611913.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T04:36:41.306212+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/4/375883ba36dfa3-948-567-0-2-1000-599.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Pierwsza od lat obniżka stóp procentowych już zaczyna być widoczna w cennikach kredytów. To jednak zapewne dopiero początek poważniejszych przesunięć w ofertach stałoprocentowych hipotek. Sprawdzamy, jak prezentują się stawki w pierwszych dniach po rynkowych zawirowaniach.</p>

## Ponad 100 chińskich samolotów aktywnych w pobliżu Tajwanu
 - [https://www.bankier.pl/wiadomosc/Ponad-100-chinskich-samolotow-aktywnych-w-poblizu-Tajwanu-8612801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci](https://www.bankier.pl/wiadomosc/Ponad-100-chinskich-samolotow-aktywnych-w-poblizu-Tajwanu-8612801.html?utm_source=RSS&utm_medium=RSS&utm_campaign=Wiadomosci)
 - RSS feed: https://www.bankier.pl/rss/wiadomosci.xml
 - date published: 2023-09-18T03:46:00+00:00

<p><img align="left" alt="" class="webfeedsFeaturedVisual" height="560" src="http://galeria.bankier.pl/p/0/1/247be14686bf7b-948-568-0-170-2522-1513.jpg" style="display: block; margin-bottom: 5px; clear: both;" width="945" />Ministerstwo obrony Tajwanu poinformowało, że w ciągu ostatnich 24 godzin wykryło wokół wyspy 103 chińskie samoloty bojowe, "co stanowi najwyższą w ostatnim czasie liczbę".</p>

