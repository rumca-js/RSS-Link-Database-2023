# Source:Rotten Tomatoes Trailers, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA, language:en-US

## Butcher's Crossing Trailer #1 (2023)
 - [https://www.youtube.com/watch?v=0WpU8wQhOXo](https://www.youtube.com/watch?v=0WpU8wQhOXo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-09-18T19:07:08+00:00

Check out the official trailer for Butcher's Crossing starring Nicolas Cage! 
► Sign up for a Fandango FanAlert for Butcher's Crossing: http://www.fandango.com/?cmp=Trailers_YouTube_Desc

Subscribe to the channel and click the bell icon to be notified of all the hottest trailers: http://bit.ly/2CNniBy 

► Shop Rotten Tomatoes: http://bit.ly/3KvCU1M

US Release Date: October 20, 2023
Starring: Fred Hechinger, Nicolas Cage, Rachel Keller
Director: Gabe Polsky
Synopsis: An Ivy League dropout travels to the Colorado wilderness, where he joins a team of buffalo hunters on a journey that puts his life and sanity at risk.
► Learn more: https://www.rottentomatoes.com/m/butchers_crossing?cmp=Trailers_YouTube_Desc 

Watch More:  
► Rotten Tomatoes Originals: http://bit.ly/2D3sipV    
► Fresh New Clips: https://bit.ly/3mJePrv    
► Hot New Trailers: http://bit.ly/2qThrsF   
► New TV This Week: https://bit.ly/3Or3I2w   
 
Rotten Tomatoes TRAILERS delivers hot new trailers, exclusive content, and

## 'Saw X' Movie Clip - Eyeball Trap
 - [https://www.youtube.com/watch?v=yZTdaO4laZM](https://www.youtube.com/watch?v=yZTdaO4laZM)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCi8e0iOVk1fEOogdfu4YgfA
 - date published: 2023-09-18T17:46:35+00:00

Check out the new clip for Saw X starring Tobin Bell! #shorts 
Watch the full trailer: https://youtu.be/Y5Ga60ytUfU
► Learn more: https://www.rottentomatoes.com/m/saw_x?cmp=RTYT_YouTube_Desc

