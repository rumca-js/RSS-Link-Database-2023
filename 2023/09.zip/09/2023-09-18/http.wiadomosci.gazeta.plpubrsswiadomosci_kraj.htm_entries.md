# Source:wiadomości.gazeta.pl, URL:http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm, language:pl-PL

## Działaczki KO potrącone przez 73-latka. "Człowiek z zaciśniętymi zębami i widoczną agresją"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203638,dzialaczki-ko-potracone-przez-73-latka-czlowiek-z-zacisnietymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203638,dzialaczki-ko-potracone-przez-73-latka-czlowiek-z-zacisnietymi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T19:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/3d/cd/1c/z30203709M,Incydent-w-Wegrowie.jpg" vspace="2" />Kandydatka w wyborach do Sejmu Marzena Cendrowska i towarzysząca jej działaczka KO Małgorzata Dąbrowska zostały potrącone przez 73-letniego mężczyznę podczas festynu w Węgrowie. Działaczki są przekonane, że incydent miał podłoże polityczne. Policja na ten moment tego nie potwierdza.

## Śledczy wzywają pacjentki ginekolożki na przesłuchania. "Pytają, czy przepisywała jakieś tabletki"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203541,sledczy-wzywaja-pacjentki-ginekolozki-na-przesluchania-pytaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203541,sledczy-wzywaja-pacjentki-ginekolozki-na-przesluchania-pytaja.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T18:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/e0/9d/1c/z30007008M,Dr-Maria-Kubisa.jpg" vspace="2" />Kolejna pacjentka dr Marii Kubisy, ginekolożki ze Szczecina, została wezwana na przesłuchanie - informuje TVN24. 9 stycznia 2023 roku CBA i Prokuratura Regionalna w Szczecinie zabezpieczyła w jej gabinecie 30-letnią dokumentację medyczną, zabrano jej telefon i kalendarz.

## Gniezno. Potrącił swoje 15-miesięczne dziecko. Rzeczniczka policji: Miał ponad dwa promile alkoholu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203488,gniezno-potracil-swoje-15-miesieczne-dziecko-rzeczniczka-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203488,gniezno-potracil-swoje-15-miesieczne-dziecko-rzeczniczka-policji.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T18:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/84/cd/1c/z30203524M,Do-potracenia-15-miesiecznego-dziecka-doszlo-w-Gni.jpg" vspace="2" />W Gnieźnie miało miejsce niebezpieczne zdarzenie z udziałem 15-miesięcznego dziecka. Podczas przeparkowywania samochodu dziewczynka została potrącona przez swojego ojca. - Badanie wykazało, że w chwili zdarzenia ojciec dziecka miał ponad dwa promile alkoholu - przekazała rzeczniczka gnieźnieńskiej policji.

## Zaginęła 23-letnia Aneta Szubryt. Policja prosi o pomoc
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203195,zaginela-23-letnia-aneta-szubryt-policja-prosi-o-pomoc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30203195,zaginela-23-letnia-aneta-szubryt-policja-prosi-o-pomoc.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T15:24:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/65/cd/1c/z30203237M,Aneta-Szubryt.jpg" vspace="2" />Wrocławscy policjanci poszukują 23-letniej Anety Szubryt. Kobieta zaginęła w czwartek, do tej pory nie skontaktowała się z bliskimi. Funkcjonariusze opublikowali zdjęcia 23-latki.

## Wojciech Mann zażartował z funkcji Kurskiego w Banku Światowym. Oberwało się też Glapińskiemu
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202813,wojciech-mann-zazartowal-z-funkcji-kurskiego-w-banku-swiatowym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202813,wojciech-mann-zazartowal-z-funkcji-kurskiego-w-banku-swiatowym.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T15:11:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a1/cd/1c/z30203041M,Wojciech-Mann.jpg" vspace="2" />Wojciech Mann skrytykował w żartobliwym tonie funkcję Jacka Kurskiego w Banku Światowym. Były prezes zarządu TVP objął intratne stanowisko po tym, jak jego kandydatura została zgłoszona przez Adama Glapińskiego. W swoim wpisie dziennikarz zażartował, że sam posiada kompetencje zbliżone do Kurskiego i zapytał ironicznie prezesa NBP, czy ten nie znalazłby dla niego podobnej posady.

## Jak wyszła na jaw zbrodnia w Czernikach? Ktoś podejrzał SMS-y córki i ojca. "I co robi?". "Ciągle ryczy"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202180,jak-wyszla-na-jaw-zbrodnia-w-czernikach-ktos-podejrzal-sms-y.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202180,jak-wyszla-na-jaw-zbrodnia-w-czernikach-ktos-podejrzal-sms-y.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T14:08:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/97/cd/1c/z30202519M,Czerniki--Dom--w-ktorym-odnaleziono-zwloki-trojga-.jpg" vspace="2" />W sprawie tragicznej zbrodni we wsi Czerniki prokuratura prowadzi śledztwo. 54-letni Piotr G. oraz jego 20-letnia córka Paulina przebywają w areszcie. Mają postawione zarzuty kazirodztwa oraz morderstwa trójki noworodków. Sprawa mogłaby nigdy nie wyjść na jaw, gdyby nie SMS-y, które podejrzała jedna z kobiet pracujących w cukierni z Pauliną G.

## "Córka traktowała go jak Boga", "odbierał wszystkie porody". Po zbrodni wieś Czerniki mówi o Piotrze G.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201526,szatan-w-ludzkim-ciele-ktorego-corka-traktowala-jak-boga.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201526,szatan-w-ludzkim-ciele-ktorego-corka-traktowala-jak-boga.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T13:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5b/cd/1c/z30201947M,Dom-rodziny-G-.jpg" vspace="2" />Zbrodnia we wsi Czerników. Według relacji mieszkańców niemal wszyscy z otoczenia rodziny G. wiedzieli, co dzieje się za zamkniętymi drzwiami jednego z kaszubskich domów. To tam policjanci odnaleźli szczątki trzech noworodków, które mieli pozbawić życia 54-letni Piotr G. i jego 20-letnia córka Paulina. Mieli też dopuszczać się kazirodztwa. O 20-latce mówi się, że była jedną z ofiar, która "miała wpojone, że spanie z ojcem jest normalne".

## Strzelanina pod Częstochową. Prokuratura ujawnia nowe fakty
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202696,strzelanina-pod-czestochowa-prokuratura-ujawnia-nowe-fakty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202696,strzelanina-pod-czestochowa-prokuratura-ujawnia-nowe-fakty.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T13:42:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a6/cc/1c/z30198182M,Strzelanina-pod-Czestochowa--Jedna-z-ofiar-miala-k.jpg" vspace="2" />Prokuratura w Myszkowie prowadzi śledztwo dotyczące sobotniej strzelaniny w Podlesiu pod Częstochową, gdzie zginęło dwóch mężczyzn. Okazuje się, że 52-latek i 44-latek poróżnili się o kobietę.

## Nowe informacje ws. zbrodni w Czernikach. W przeszłości służby zajmowały się Piotrem G.
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202055,nowe-informacje-ws-zbrodni-w-czernikach-w-przeszlosci-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30202055,nowe-informacje-ws-zbrodni-w-czernikach-w-przeszlosci-sluzby.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T12:27:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/5d/cd/1c/z30201949M,Ciala-noworodkow-odnalezione-w-domu-w-Czernikach.jpg" vspace="2" />- Z danych systemu wynika, że w przeszłości było prowadzonych kilka postępowań wobec Piotra G. - przekazała Onetowi prok. Grażyna Wawryniuk, rzeczniczka prasowa Prokuratury Okręgowej w Gdańsku. W domu 54-latka służby znalazły zwłoki trzech noworodków. Mężczyźnie postawiono pięć zarzutów dot. zabójstwa i kazirodztwa.

## Śmierć Kamila z Częstochowy. Są ustalenia kuratorium i decyzje ws. placówek, w których przebywał
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201368,smierc-kamila-z-czestochowy-sa-ustalenia-kuratorium-i-decyzje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201368,smierc-kamila-z-czestochowy-sa-ustalenia-kuratorium-i-decyzje.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T11:40:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/59/60/1c/z29754969M,13-maja-2023--cmentarz-Kule-w-Czestochowie--Pogrze.jpg" vspace="2" />Śląskie Kuratorium Oświaty w Katowicach przeprowadziło wizytację placówek, w których przebywał 8-letni Kamil z Częstochowy, a które nie odnotowały żadnych sygnałów, że chłopiec jest maltretowany. Według urzędników nie doszło do żadnych nieprawidłowości. Mimo to przed szkołą, do której uczęszczał chłopiec, odbędzie się kolejny protest.

## Komenda Główna Policji reaguje na wyciek zdjęć granatnika. Mówi o "sensacji"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201869,komenda-glowna-policji-reaguje-na-wyciek-zdjec-granatnika-mowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30201869,komenda-glowna-policji-reaguje-na-wyciek-zdjec-granatnika-mowi.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T11:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/57/82/1b/z28845911M,Pilne.jpg" vspace="2" />- Zdjęcia te nie wnoszą nic nowego, o czym nie było mowy wcześniej i czego nie przekazywano opinii publicznej - powiedział rzecznik Komendanta Głównego Policji. Mariusz Ciarka odniósł się w ten sposób do opublikowanych przez Krzysztofa Brejzę zdjęć, które miały zostać zrobione po wybuchu granatnika w KGP. - W wypowiedziach pana senatora padło wiele nieprawdziwych informacji, aby nadać sprawie charakter sensacji - dodał funkcjonariusz.

## Spadek powołań. "Takiej katastrofy jeszcze nie było". Kandydatów na księży odstrasza abp Jędraszewski?
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200767,spadek-powolan-takiej-katastrofy-jeszcze-nie-bylo-kandydatow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200767,spadek-powolan-takiej-katastrofy-jeszcze-nie-bylo-kandydatow.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T10:32:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/a8/d6/1b/z29188520M,Abp-Marek-Jedraszewski.jpg" vspace="2" />Rekrutacja do Wyższego Seminarium Duchownego Archidiecezji Krakowskiej, która uchodzi za centrum polskiego życia religijnego, dobiegła końca. Do drugiej tury dopuszczono zaledwie kilka osób. Nie wiadomo jednak ilu z nich pozytywnie przeszło egzaminy. - W kurii popłoch, bo takiej katastrofy jeszcze nie było - skomentował proboszcz z podkrakowskiej parafii w rozmowie z "Gazetą Wyborczą".

## Wybuch granatnika w KGP. Brejza pokazuje zdjęcia. "Najbardziej strzeżona tajemnica państwa PiS"
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200779,wybuch-granatnika-w-kgp-brejza-pokazuje-zdjecia-najbardziej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200779,wybuch-granatnika-w-kgp-brejza-pokazuje-zdjecia-najbardziej.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T09:03:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/64/cd/1c/z30200932M,Wybuch-granatnika-w-KGP--Brejza-pokazuje-zdjecia.jpg" vspace="2" />Krzysztof Brejza opublikował zdjęcia, które miały zostać wykonane po wybuchu granatnika w Komendzie Głównej Policji. "Ujawniam najbardziej strzeżoną tajemnicę państwa PiS" - podkreślił senator.

## Gniezno. Pijany ojciec potrącił 15-miesięczną córkę. Dziecko zabrał helikopter LPR
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200601,gniezno-pijany-ojciec-potracil-15-miesieczna-corke-dziecko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200601,gniezno-pijany-ojciec-potracil-15-miesieczna-corke-dziecko.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T08:59:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/8a/a8/1c/z30050442M,Raczka-niemowlecia---zdjecie-ilustracyjne.jpg" vspace="2" />W Gnieźnie 15-miesięczna dziewczynka została potrącona przez samochód. Pojazdem kierował jej nietrzeźwy ojciec. Dziecko zostało zabrane do szpitala przez śmigłowiec Lotniczego Pogotowia Ratunkowego.

## Szef NIK Marian Banaś zawiadamia prokuraturę w związku działaniami Elżbiety Witek
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200766,szef-nik-marian-banas-zawiadamia-prokurature-w-zwiazku-dzialaniami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200766,szef-nik-marian-banas-zawiadamia-prokurature-w-zwiazku-dzialaniami.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T08:34:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/79/35/1c/z29578105M,WAZNE.jpg" vspace="2" />Prezes Najwyższej Izby Kontroli Marian Banaś złożył w prokuraturze zawiadomienie o możliwości popełnienia przestępstwa przez marszałkini Sejmu Elżbietę Witek - poinformowało RMF FM. Zdaniem szefa NIK marszałek Witek swoimi zaniechaniami doprowadziła do pozbawienia Izby możliwości działania i podejmowania decyzji.

## Jaka będzie pogoda na koniec września? Czeka nas spore zaskoczenie. Upał, grad i burze, a to nie koniec
 - [https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200255,jaka-bedzie-pogoda-na-koniec-wrzesnia-czeka-nas-spore-zaskoczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636](https://wiadomosci.gazeta.pl/wiadomosci/7,114883,30200255,jaka-bedzie-pogoda-na-koniec-wrzesnia-czeka-nas-spore-zaskoczenie.html?utm_source=RSS&utm_medium=RSS&utm_campaign=10663636)
 - RSS feed: http://wiadomosci.gazeta.pl/pub/rss/wiadomosci_kraj.htm
 - date published: 2023-09-18T07:22:00+00:00

<img align="left" hspace="4" src="https://bi.im-g.pl/im/91/a0/1c/z30016657M,Pogoda--zdjecie-ilustracyjne-.jpg" vspace="2" />Pogoda w kolejnym tygodniu września przywita nas ciepłą, wręcz upalną pogodą. W najbliższych dniach możemy się spodziewać wysokiej temperatury, jednak wystąpią również gwałtowne burze. Mimo chwilowego ochłodzenia ostatnie dni września będą ciepłe i słoneczne.

