# Source:The Washington Post - Tech, URL:https://feeds.washingtonpost.com/rss/business/technology, language:en-US

## Judge blocks California law meant to increase online safety for kids
 - [https://www.washingtonpost.com/technology/2023/09/18/california-online-child-safety-law/](https://www.washingtonpost.com/technology/2023/09/18/california-online-child-safety-law/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-18T21:21:26+00:00

The California Age-Appropriate Design Code probably violates the First Amendment, the judge wrote.

## Netanyahu, Musk meet at Tesla factory to discuss AI
 - [https://www.washingtonpost.com/technology/2023/09/18/netanyahu-musk-meeting-x-live/](https://www.washingtonpost.com/technology/2023/09/18/netanyahu-musk-meeting-x-live/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-18T16:36:04+00:00

Tech magnate Elon Musk and Israeli Prime Minister Benjamin Netanyahu are meeting in California to discuss AI as each looks to the other to fend off criticism.

## Regulators struggle to rein in Amazon on safety for warehouse workers
 - [https://www.washingtonpost.com/technology/2023/09/18/amazon-working-conditions-safety-osha-doj/](https://www.washingtonpost.com/technology/2023/09/18/amazon-working-conditions-safety-osha-doj/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-18T14:00:34+00:00

After a decade of worker complaints, Amazon’s safety record is under scrutiny from a litany of state and federal regulators. But so far, the company has faced few consequences.

## Should you update your iPhone to iOS 17? 5 new features to check out
 - [https://www.washingtonpost.com/technology/2023/09/18/ios-17-iphone-upgrade-features/](https://www.washingtonpost.com/technology/2023/09/18/ios-17-iphone-upgrade-features/)
 - RSS feed: https://feeds.washingtonpost.com/rss/business/technology
 - date published: 2023-09-18T10:00:00+00:00

Apple’s latest iPhone update, iOS 17, will be available for download today. Here’s a look at the new features and if you should upgrade.

