# Source:Gizmodo, URL:https://gizmodo.com/rss, language:en-US

## The Original X-Men Are Coming Back, but Only One Is Staying
 - [https://gizmodo.com/original-x-men-first-five-return-marvel-comics-2024-1850850377](https://gizmodo.com/original-x-men-first-five-return-marvel-comics-2024-1850850377)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T22:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/c70b0dfcf5e45c6087092bff828a7163.jpg" /><p>The X-Men turn 60 this year, and Marvel is celebrating in style by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/marvel-x-men-hellfire-gala-2023-spoilers-fall-of-x-1850683260">killing a bunch of them</a> in a horrifying terrorist attack, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/x-men-25-hellfire-gala-kitty-pryde-shadowkat-marvel-1850705735">kickstarting the downfall</a> of an age of Mutant progress, and now by returning to an idea they first did a decade ago. Sounds about right for the heroes forever fighting for a world that hates and…</p><p><a href="https://gizmodo.com/original-x-men-first-five-return-marvel-comics-2024-1850850377">Read more...</a></p>

## Space Drugs Factory Denied Reentry to Earth
 - [https://gizmodo.com/space-pharmaceuticals-varda-regulations-faa-1850850528](https://gizmodo.com/space-pharmaceuticals-varda-regulations-faa-1850850528)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T21:17:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/635fe02fa3788f20cd846d42b6f4747e.jpg" /><p>After manufacturing crystals of an HIV drug in space, the first orbital factory is stuck in orbit after being denied reentry back to Earth due to safety concerns. </p><p><a href="https://gizmodo.com/space-pharmaceuticals-varda-regulations-faa-1850850528">Read more...</a></p>

## 15 Fascinating Facts in the Guardians of the Galaxy Vol. 3 Making-of Documentary
 - [https://gizmodo.com/guardians-of-the-galaxy-3-making-of-disney-plus-gunn-1850843435](https://gizmodo.com/guardians-of-the-galaxy-3-making-of-disney-plus-gunn-1850843435)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T21:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/802f5e9f397565249622170eba8d0923.jpg" /><p>There was a time when it didn’t seem like Guardians of the Galaxy Vol. 3 would ever happen. Or, maybe it would happen, but without <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/james-gunn-interview-guardians-3-marvel-dc-adam-warlock-1850392940">James Gunn directing</a> it. Thankfully, after all sorts of ups and downs, Gunn not only made the film, he made it his, and his team’s, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/guardians-3-spoiler-i-am-groot-gamora-marvel-studios-1850396729">farewell to Marvel Studios</a>, all in one package.</p><p><a href="https://gizmodo.com/guardians-of-the-galaxy-3-making-of-disney-plus-gunn-1850843435">Read more...</a></p>

## Tropical Storm Nigel Has Intensified Into a Hurricane
 - [https://gizmodo.com/tropical-storm-nigel-has-intensified-into-a-hurricane-1850850658](https://gizmodo.com/tropical-storm-nigel-has-intensified-into-a-hurricane-1850850658)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T21:00:24+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/890b497a87a4c31c14065dd1298edfba.png" /><p>Tropical storm Nigel formed in the Atlantic Ocean late last week and has quickly intensified into a category 1 hurricane. The storm system is not currently a threat to any community as it is far out in the middle of the ocean.</p><p><a href="https://gizmodo.com/tropical-storm-nigel-has-intensified-into-a-hurricane-1850850658">Read more...</a></p>

## Amazon Reportedly Hiring Microsoft's Product Chief, Just Hours After He Resigned
 - [https://gizmodo.com/amazon-hiring-microsofts-product-chief-resignation-1850850633](https://gizmodo.com/amazon-hiring-microsofts-product-chief-resignation-1850850633)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T20:39:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/bd9bf70e7b22af56646ec36e0a25ddd1.jpg" /><p>Amazon will reportedly hire Microsoft’s departing Product Chief Panos Panay, mere hours after he left the company. Panay will be heading Amazon’s devices group, which is in charge of the Alexa voice assistant, Echo smart speakers, and Fire TV streaming services, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.bloomberg.com/news/articles/2023-09-18/amazon-is-poised-to-hire-departing-microsoft-product-chief#xj4y7vzkg" rel="noopener noreferrer" target="_blank">Bloomberg</a> first reported.</p><p><a href="https://gizmodo.com/amazon-hiring-microsofts-product-chief-resignation-1850850633">Read more...</a></p>

## In Quantum Leap Season 2, Dr. Ben Song Returns to Pinball Between Decades
 - [https://gizmodo.com/quantum-leap-reboot-s2-trailer-nbc-time-travel-sci-fi-1850850525](https://gizmodo.com/quantum-leap-reboot-s2-trailer-nbc-time-travel-sci-fi-1850850525)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T20:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/febf6053d3d114f6af24291626786cc8.jpg" /><p>Like <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/quantum-leap-reboot-no-scott-bakula-1849550163">Scott Bakula</a>’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/the-14-weirdest-quantum-leap-episodes-of-all-time-1785484622">Dr. Sam Beckett</a> before him, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/quantum-leap-reboot-review-nbc-time-travel-sci-fi-1849532850">Quantum Leap’s Dr. Ben Song</a> (Raymond Lee) is <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/quantum-leap-nbc-peacock-reboot-sequel-time-travel-1849752380">a time-traveler with purpose</a>—<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/quantum-leap-reboot-sequel-series-nbc-i

## Doctor Who's Chris Chibnall Would've Done Things Differently With Its 'Unrequited' Romance
 - [https://gizmodo.com/doctor-who-thasmin-kiss-chris-chibnall-yaz-13th-doctor-1850850246](https://gizmodo.com/doctor-who-thasmin-kiss-chris-chibnall-yaz-13th-doctor-1850850246)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T19:47:31+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/82e2bebe14e50be38eb845a50fc4b0af.jpg" /><p>Although the unique bond between the two was clear almost from the get-go of Chris Chibnall’s <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-power-of-the-doctor-recap-jodie-whittaker-1849695272">tenure on Doctor Who</a>, it took until <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-legend-of-the-sea-devils-recap-1848804342">the penultimate episode</a> of Jodie Whittaker’s<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/doctor-who-russell-t-davies-jodie-whittaker-erasure-1850838258"> time as the Doctor</a> to explicitly dive into her incarnation’s romantic feelings for Yaz—only for that romance to be cut short with her…</p><p><a href="https://gizmodo.com/doctor-who-thasmin-kiss-chris-chibnall-yaz

## Activision Hashed Out Details on a Nintendo Switch 2 In Closed-Door Meeting
 - [https://gizmodo.com/microsoft-activision-nintendo-switch-2-documents-1850850105](https://gizmodo.com/microsoft-activision-nintendo-switch-2-documents-1850850105)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T19:19:23+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/eb08d835fc8d0f50ac31012d636d61fb.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/microsoft-activision-acquisition-cloud-ubisoft-1850761615">The ongoing FTC v. Microsoft court battle</a> over the tech giant’s $68.7 billion Activision merger isn’t going the way the Federal Trade Commission nor antitrust activists would necessarily like it to, but the attempt to block the merger has also allowed some juicy bits of gossip to leak down to us about some moves the…</p><p><a href="https://gizmodo.com/microsoft-activision-nintendo-switch-2-documents-1850850105">Read more...</a></p>

## SpaceX Fires Back Against DOJ Hiring Discrimination Case With a Lawsuit of Its Own
 - [https://gizmodo.com/spacex-lawsuit-doj-bias-hiring-practices-discrimination-1850849870](https://gizmodo.com/spacex-lawsuit-doj-bias-hiring-practices-discrimination-1850849870)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T19:08:55+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/de53626c258f1f84a5521e6cf84f53af.jpg" /><p>In response to a lawsuit accusing SpaceX of hiring discrimination, the private space company is seeking dismissal of the case filed by the Justice Department for being unconstitutional. </p><p><a href="https://gizmodo.com/spacex-lawsuit-doj-bias-hiring-practices-discrimination-1850849870">Read more...</a></p>

## Rick and Morty's Season 7 Credits Absolutely Don't Address the Elephant in the Room
 - [https://gizmodo.com/rick-and-morty-adult-swim-season-7-opening-credits-1850850119](https://gizmodo.com/rick-and-morty-adult-swim-season-7-opening-credits-1850850119)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T19:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/b3c9ba78bdce2b54ecdabb5deceb0a5d.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/rick-and-morty-season-7-anime-spinoff-sdcc-2023-1850653624">Rick and Morty</a> fans know that the show’s opening credits are always some variety of “two truths and a lie.” Some of the wild scenarios glimpsed in the sequence are clipped from the new season, and some are just surreal misdirections. If you’re hoping <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/rick-and-morty-adult-swim-season-7-premiere-october-15-1850767637">season seven</a>’s credits will offer any hints about the Adult Swim…</p><p><a href="https://gizmodo.com/rick-and-morty-adult-swim-season-7-opening-credits-1850850119">Read more...</a></p>

## California Sues Big Oil Over Climate Deception
 - [https://gizmodo.com/california-sues-big-oil-over-climate-deception-1850848887](https://gizmodo.com/california-sues-big-oil-over-climate-deception-1850848887)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T18:09:56+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/ac0ca051c13bfe1077c55b97195c179d.jpg" /><p>California is suing some of the largest oil and gas companies in the world for years of climate science denialism while worsening extreme weather related to the climate crisis.</p><p><a href="https://gizmodo.com/california-sues-big-oil-over-climate-deception-1850848887">Read more...</a></p>

## Disney World Shut Down Half of Magic Kingdom After Actual Bear Snuck In
 - [https://gizmodo.com/wild-bear-sighting-at-walt-disney-world-florida-1850849790](https://gizmodo.com/wild-bear-sighting-at-walt-disney-world-florida-1850849790)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T18:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/6d249cf804481becc196cf258207363b.png" /><p>The Country Bear Musical Jamboree recently announced some changes for a new show in 2024—and apparently word got out to the bear community, because a real life black bear made a surprise appearance at Frontierland at <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/disney-parks-halloween-holiday-guides-frozen-land-china-1850832438">Walt Disney World</a>’s Magic Kingdom. </p><p><a href="https://gizmodo.com/wild-bear-sighting-at-walt-disney-world-florida-1850849790">Read more...</a></p>

## Elon Musk Reportedly Looking to Deepen His Ties With Saudi Arabia
 - [https://gizmodo.com/report-saudi-arabia-woos-musk-for-tesla-factory-1850849493](https://gizmodo.com/report-saudi-arabia-woos-musk-for-tesla-factory-1850849493)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T17:46:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/cc27513cddb6fbaa512a971572a498be.jpg" /><p>Tesla CEO Elon Musk is reportedly discussing opening a new manufacturing facility in Saudi Arabia, according to a <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.wsj.com/business/autos/tesla-saudi-arabia-in-early-talks-for-ev-factory-240cd075" rel="noopener noreferrer" target="_blank">report</a> on Monday, which cited numerous sources close to the matter. Reports of the potential collaboration come only hours after Musk and Turkey’s President Recep Tayyip Erdoğan met in New York to discuss…</p><p><a href="https://gizmodo.com/report-saudi-arabia-woos-musk-for-tesla-factory-1850849493">Read more...</a></p>

## TikTok Employees Recoil at Return-to-Office Tracker App
 - [https://gizmodo.com/tiktok-return-to-office-tracker-app-myrto-1850849466](https://gizmodo.com/tiktok-return-to-office-tracker-app-myrto-1850849466)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T17:35:31+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/33e4a51629a4cfec67f9a7e956bea5c8.jpg" /><p>TikTok is reportedly deploying a new employee badge monitoring app as part of a renewed effort to pressure its workers to spend more days in the office, <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://www.nytimes.com/2023/09/15/business/tiktok-return-to-office-tracking-tools.html" rel="noopener noreferrer" target="_blank">according to</a> a recent New York Times report. The attendance app comes as other big players in tech like Meta and Google similarly <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/meta-instagram-remote-work-work-from-home-facebook-1850287137">continue to clamp down</a> on <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/amazon-ceo-tells-workers-to-return-to-office-or-fired-1850783235">flexible…</a></p><p><a hr

## Alien Feet Inflict Freaky Terror in Eerie No One Will Save You Clip
 - [https://gizmodo.com/no-one-will-save-you-clip-hulu-aliens-kaitlyn-dever-1850849564](https://gizmodo.com/no-one-will-save-you-clip-hulu-aliens-kaitlyn-dever-1850849564)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T17:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/308d6969b322c51dc255fdea3adca783.jpg" /><p>Based on what we see in this clip, the dissonant sound design for <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/no-one-will-save-you-trailer-kaitlyn-dever-aliens-hulu-1850804517">No One Will Save You</a>—<a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fall-movie-preview-2023-horror-scifi-animation-comics-1850772160">an upcoming Hulu release</a> about a lone woman (Booksmart’s Kaitlyn Dever) facing an <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/monsters-of-california-trailer-blink-182-tom-delonge-1850836491">extraterrestrial</a> home invasion—is enough to set you on edge, but holy Tarantino, those alien feet are nightmares come to life.</p><p><a href="https://gizmodo.com/no-one-will-save-you-clip-hulu-aliens-kai

## Chucky's New Season 3 Trailer Promises 'the Bloodiest Halloween Yet'
 - [https://gizmodo.com/chucky-s3-trailer-horror-white-house-jennifer-tilly-1850849264](https://gizmodo.com/chucky-s3-trailer-horror-white-house-jennifer-tilly-1850849264)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T16:45:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/e3009b6741ccb3281995e311a76d835c.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/chucky-s3-horror-series-first-teaser-white-house-dc-1850789490">Chucky’s invasion of Washington, DC</a> commences in early October—and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/chucky-season-2-review-childs-play-don-mancini-horror-1849610078">his namesake show</a> will keep the murderous vibes going into election year. A new trailer for season three of Chucky gives us our best look yet at <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/chucky-universal-studios-halloween-horror-nights-2023-1850810299">the killer doll</a>’s latest power-grab scheme, and the “Kids in America” who will try to stop him.</p><p><a href="https://gizmodo.com/chucky-s3-trailer-horror-white-

## The Sea Brings Peril in Rebecca Roanhorse's Final Between Earth and Sky Book
 - [https://gizmodo.com/rebecca-roanhorse-fantasy-trilogy-earth-and-sky-excerpt-1850844118](https://gizmodo.com/rebecca-roanhorse-fantasy-trilogy-earth-and-sky-excerpt-1850844118)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T16:18:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/6b532112765e1b76f9f47f5b755cb2ab.jpg" /><p><a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/november-62-new-scifi-fantasy-books-nk-jemisin-1849625697">Rebecca Roanhorse</a>’s blockbuster Between Earth and Sky <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/fantasy-book-excerpt-romance-wolves-a-k-mulford-1850804596">fantasy trilogy</a>—“inspired by the civilizations of the Pre-Columbian Americas and woven into a tale of celestial prophecies, political intrigue, and forbidden magic”—began with 2021's Black Sun, and continued earlier this year with Fevered Star. Conclusion Mirrored…</p><p><a href="https://gizmodo.com/rebecca-roanhorse-fantasy-trilogy-earth-and-sky-excerpt-1850844118">Read more...</a></p>

## Google Quietly Removes ‘Written By People’ From Suggestions for Website Owners
 - [https://gizmodo.com/google-search-written-by-people-helpful-content-update-1850848956](https://gizmodo.com/google-search-written-by-people-helpful-content-update-1850848956)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T16:04:51+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/cabb2ace8f65a2cbc7e0f1115a972d85.jpg" /><p>Google quietly removed the suggestion that the text of a website should be “written by people” from its guidance for site owners who want to do better in search results, a change first spotted by <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://searchengineland.com/google-september-2023-helpful-content-system-update-rolling-out-431978" rel="noopener noreferrer" target="_blank">Search Engine Land</a>. The change will likely accelerate the deluge of AI-generated content that’s already beginning to spread…</p><p><a href="https://gizmodo.com/google-search-written-by-people-helpful-content-update-1850848956">Read more...</a></p>

## Upgraded Linear Accelerator in California Achieves First Light, Poised to Transform X-Ray Science
 - [https://gizmodo.com/upgrade-linear-accelerator-slac-lcls-ii-x-rays-1850848767](https://gizmodo.com/upgrade-linear-accelerator-slac-lcls-ii-x-rays-1850848767)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T15:37:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/206b238b10df658cb1c9543d3e166754.jpg" /><p>Engineers who have toiled on the world’s most powerful X-ray laser for over a decade have finally achieved first light with the instrument, meaning that science with the newly energized machine is nearly upon us.<br /></p><p><a href="https://gizmodo.com/upgrade-linear-accelerator-slac-lcls-ii-x-rays-1850848767">Read more...</a></p>

## With a Small Hop, SpaceX Rival Edges Closer to Developing the World's First Fully Reusable Rocket
 - [https://gizmodo.com/stoke-space-spacex-rival-hop-test-reusable-hopper2-1850848589](https://gizmodo.com/stoke-space-spacex-rival-hop-test-reusable-hopper2-1850848589)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T15:15:10+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/68f9c517b029b357d5c209abe5488451.jpg" /><p>During a 15-second test flight, Stoke Space launched Hopper2 and landed the prototype upper stage in what is a major milestone in the company’s plans to develop a fully reusable rocket.</p><p><a href="https://gizmodo.com/stoke-space-spacex-rival-hop-test-reusable-hopper2-1850848589">Read more...</a></p>

## Loki Season 2 Will Now Air on Thursday Nights
 - [https://gizmodo.com/loki-season-2-premiere-date-thursday-marvel-disney-plus-1850848811](https://gizmodo.com/loki-season-2-premiere-date-thursday-marvel-disney-plus-1850848811)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T15:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/f84dca80f745b78fe866610913d267b3.png" /><p>When <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/loki-season-2-footage-disney-plus-marvel-tom-hiddleston-1850802356">Loki returns</a> for a second season next month, it’s doing so a couple of hours earlier than expected. Disney has now confirmed that the sophomore season of the Marvel series will air on Thursday nights, starting October 5.<br /></p><p><a href="https://gizmodo.com/loki-season-2-premiere-date-thursday-marvel-disney-plus-1850848811">Read more...</a></p>

## Military Loses F-35 Stealth Fighter Jet, Asks Public for Help Finding It
 - [https://gizmodo.com/military-loses-f-35-stealth-fighter-jet-asks-for-help-1850848499](https://gizmodo.com/military-loses-f-35-stealth-fighter-jet-asks-for-help-1850848499)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T14:37:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/ae6afc179da507b64a882ce5989e864c.jpg" /><p>The Marine Corps lost an F-35B Lightning II fighter jet following a training “mishap” on Sunday. Military personnel are asking for help locating the F-35 jet after the pilot ejected himself from the F-35 and parachuted safely to the ground around 2 p.m. near Charleston, South Carolina.</p><p><a href="https://gizmodo.com/military-loses-f-35-stealth-fighter-jet-asks-for-help-1850848499">Read more...</a></p>

## Updates From Our Flag Means Death, Saw X, and More
 - [https://gizmodo.com/our-flag-means-death-season-2-new-pictures-1850847450](https://gizmodo.com/our-flag-means-death-season-2-new-pictures-1850847450)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T14:15:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/2fda5277e15430a82f03dcf60fe7889e.png" /><p>John Carpenter has high hope for the Christine remake. Get ready for spooky season with a trio of horror trailers. Plus, what’s coming on FLCL Grunge. Spoilers, away!<br /></p><p><a href="https://gizmodo.com/our-flag-means-death-season-2-new-pictures-1850847450">Read more...</a></p>

## Funko's New York Comic-Con Star Wars Exclusives Are a Galactic Gaming Treat
 - [https://gizmodo.com/nycc-2023-funko-star-wars-exclusive-loungefly-maul-1850847712](https://gizmodo.com/nycc-2023-funko-star-wars-exclusive-loungefly-maul-1850847712)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T13:30:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/c88e29dc038c357463e5d0ef9ca1c6e3.jpg" /><p>New York Comic-Con is almost upon us and <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/halloween-netflix-wednesday-merch-drop-jenna-ortega-1850844531">Funko has exclusively shared</a> some of their Star Wars <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://funko.com/" rel="noopener noreferrer" target="_blank">Pop! and Loungefly lineup</a> with io9.<br /></p><p><a href="https://gizmodo.com/nycc-2023-funko-star-wars-exclusive-loungefly-maul-1850847712">Read more...</a></p>

## 10 Subtle iOS 17 Features We're Excited About
 - [https://gizmodo.com/iphone-ios-17-apple-10-subtle-features-excited-about-1850848084](https://gizmodo.com/iphone-ios-17-apple-10-subtle-features-excited-about-1850848084)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T13:17:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/2642aac7625f27a15e9c62e22ef70e52.jpg" /><p>Just in time for the <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/apple-iphone-15-hands-on-upgrade-1850832173">iPhone 15</a> to go on sale later this week, Apple has officially released <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://gizmodo.com/best-ios-17-features-iphone-apple-wwdc-2023-1850506161">iOS 17</a> today. The new operating system version is compatible with every device released after the iPhone XR, including the iPhone SE (2nd-gen or later). If you buy the new <a class="sc-1out364-0 dPMosf sc-145m8ut-0 lcFFec js_link" href="https://howl.me/ckzQoA7af2t" rel="sponsored noopener noreferrer nofollow noskim" target="_blank">iPhone 15</a>, it will arrive with iOS 17 preloaded right…</p><p><a href="https://gizmodo.com/iphone-ios-17-apple-10-subtle-features

## Unity Backpedals on Its Horrible Plan for Game Install Fees Amid Developer Backlash
 - [https://gizmodo.com/unity-backpedals-on-its-plan-for-game-install-fees-1850848364](https://gizmodo.com/unity-backpedals-on-its-plan-for-game-install-fees-1850848364)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T13:15:24+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/daf4c1b41336e106818fafff029d3d8a.jpg" /><p>Less than a week after the cross-platform game engine maker Unity announced its big plan to charge developers based on the number of installations and revenue, the company said it’s rolling back its plans to some extent, though developers may already be too burned to even consider what limp olive branch the company…</p><p><a href="https://gizmodo.com/unity-backpedals-on-its-plan-for-game-install-fees-1850848364">Read more...</a></p>

## Las Vegas Authorities Want to Know How Much Water Companies Use Before Letting Them Move In
 - [https://gizmodo.com/las-vegas-wants-to-know-how-much-water-companies-use-1850844134](https://gizmodo.com/las-vegas-wants-to-know-how-much-water-companies-use-1850844134)
 - RSS feed: https://gizmodo.com/rss
 - date published: 2023-09-18T13:00:00+00:00

<img class="type:primaryImage" src="https://i.kinja-img.com/gawker-media/image/upload/c_fit,fl_progressive,q_80,w_636/4b0c72792080083aa109f1f109173886.jpg" /><p>If a business wants to move or expand to Las Vegas, it’s going to have to shell out information on its proposed water usage.</p><p><a href="https://gizmodo.com/las-vegas-wants-to-know-how-much-water-companies-use-1850844134">Read more...</a></p>

