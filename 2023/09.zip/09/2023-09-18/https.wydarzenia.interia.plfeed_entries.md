# Source:Wydarzenia Interia, URL:https://wydarzenia.interia.pl/feed, language:pl-PL

## Prezydent spotkał się z szefem ONZ. Wśród tematów zboże z Ukrainy
 - [https://wydarzenia.interia.pl/zagranica/news-prezydent-spotkal-sie-z-szefem-onz-wsrod-tematow-zboze-z-ukr,nId,7033467](https://wydarzenia.interia.pl/zagranica/news-prezydent-spotkal-sie-z-szefem-onz-wsrod-tematow-zboze-z-ukr,nId,7033467)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T22:24:06+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prezydent-spotkal-sie-z-szefem-onz-wsrod-tematow-zboze-z-ukr,nId,7033467"><img align="left" alt="Prezydent spotkał się z szefem ONZ. Wśród tematów zboże z Ukrainy " src="https://i.iplsc.com/prezydent-spotkal-sie-z-szefem-onz-wsrod-tematow-zboze-z-ukr/000HOGYVIVY5UWY4-C321.jpg" /></a>Eksport ukraińskiego zboża i rosyjska inwazja na Ukrainę były głównymi tematami spotkania prezydenta Andrzeja Dudy z sekretarzem generalnym ONZ Antonio Guterresem. O spotkaniu poinformowała w mediach społecznościowych Kancelaria Prezydenta.</p><br clear="all" />

## Zełenski w Nowym Jorku. W planach m.in. spotkania z Bidenem i Dudą
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-w-nowym-jorku-w-planach-m-in-spotkania-z-bidenem-i-,nId,7033455](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-w-nowym-jorku-w-planach-m-in-spotkania-z-bidenem-i-,nId,7033455)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T20:54:36+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-w-nowym-jorku-w-planach-m-in-spotkania-z-bidenem-i-,nId,7033455"><img align="left" alt="Zełenski w Nowym Jorku. W planach m.in. spotkania z Bidenem i Dudą" src="https://i.iplsc.com/zelenski-w-nowym-jorku-w-planach-m-in-spotkania-z-bidenem-i/000GT1SVQN2DOAD3-C321.jpg" /></a>Wołodymyr Zełenski przyleciał do Stanów Zjednoczonych. Prezydent Ukrainy poinformował w poniedziałek, że jest w Nowym Jorku, gdzie weźmie udział w sesji Zgromadzenia Ogólnego ONZ, a w Waszyngtonie spotka się z prezydentem USA Joe Bidenem. Podczas pobytu za oceanem będzie rozmawiał też z prezydentem Andrzejem Dudą.</p><br clear="all" />

## Tragedia na górskiej drodze w Peru. Co najmniej 24 osoby nie żyją
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-na-gorskiej-drodze-w-peru-co-najmniej-24-osoby-nie-,nId,7033447](https://wydarzenia.interia.pl/zagranica/news-tragedia-na-gorskiej-drodze-w-peru-co-najmniej-24-osoby-nie-,nId,7033447)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T20:06:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-na-gorskiej-drodze-w-peru-co-najmniej-24-osoby-nie-,nId,7033447"><img align="left" alt="Tragedia na górskiej drodze w Peru. Co najmniej 24 osoby nie żyją" src="https://i.iplsc.com/tragedia-na-gorskiej-drodze-w-peru-co-najmniej-24-osoby-nie/000HOGS146KBWME4-C321.jpg" /></a>Co najmniej 24 osoby zginęły, a 35 zostało rannych w wypadku autokaru w peruwiańskich Andach Środkowych. Przeciążony pojazd spadł do głębokiego na 200 metrów wąwozu. To już kolejna taka tragedia, do której doszło w tym regionie w ostatnich miesiącach.</p><br clear="all" />

## Wybory 2023. Donald Tusk opublikował nowy spot. "To jest nasz czas"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-donald-tusk-opublikowal-nowy-spot-to-jest-nasz-c,nId,7033444](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-donald-tusk-opublikowal-nowy-spot-to-jest-nasz-c,nId,7033444)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T20:00:59+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-wybory-2023-donald-tusk-opublikowal-nowy-spot-to-jest-nasz-c,nId,7033444"><img align="left" alt="Wybory 2023. Donald Tusk opublikował nowy spot. &quot;To jest nasz czas&quot;" src="https://i.iplsc.com/wybory-2023-donald-tusk-opublikowal-nowy-spot-to-jest-nasz-c/000HOGOSU9QXHLMB-C321.jpg" /></a>- Tysiące ludzi z Polską w sercach, którzy nie dali się złamać - mówi Donald Tusk w spocie Koalicji Obywatelskiej. Tymi słowami przewodniczący PO zaprasza na Marsz Miliona Serc, który przejdzie ulicami Warszawy dwa tygodnie przed wyborami parlamentarnymi.</p><br clear="all" />

## Nowa transza niemieckiej pomocy. Nie wyślą Ukrainie tego, o co prosiła
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-transza-niemieckiej-pomocy-nie-wysla-ukrainie-tego-o-co,nId,7033435](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-transza-niemieckiej-pomocy-nie-wysla-ukrainie-tego-o-co,nId,7033435)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T19:59:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-nowa-transza-niemieckiej-pomocy-nie-wysla-ukrainie-tego-o-co,nId,7033435"><img align="left" alt="Nowa transza niemieckiej pomocy. Nie wyślą Ukrainie tego, o co prosiła" src="https://i.iplsc.com/nowa-transza-niemieckiej-pomocy-nie-wysla-ukrainie-tego-o-co/000HOGMJOXQXE8Y8-C321.jpg" /></a>Niemcy ogłosiły kolejny wojskowy pakiet pomocy dla Ukrainy. Najnowsza transza pomocy zawierać będzie amunicję, pojazdy opancerzone czy systemy usuwania min, a także odzież i generatory prądu i ciepła. W wycenianym na 400 milionów euro pakiecie próżno szukać jednak pocisków manewrujących Taurus, o które prosiła Ukraina. Niemiecki minister obrony Boris Pistorius przekazał, że zanim do tego dojdzie, &quot;trzeba wyjaśnić wiele aspektów&quot;.</p><br clear="all" />

## Biznesman ma kłopoty. Eksportował do Rosji nietypowe produkty
 - [https://wydarzenia.interia.pl/zagranica/news-biznesman-ma-klopoty-eksportowal-do-rosji-nietypowe-produkty,nId,7033377](https://wydarzenia.interia.pl/zagranica/news-biznesman-ma-klopoty-eksportowal-do-rosji-nietypowe-produkty,nId,7033377)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T19:36:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-biznesman-ma-klopoty-eksportowal-do-rosji-nietypowe-produkty,nId,7033377"><img align="left" alt="Biznesman ma kłopoty. Eksportował do Rosji nietypowe produkty" src="https://i.iplsc.com/biznesman-ma-klopoty-eksportowal-do-rosji-nietypowe-produkty/000HOGF0J3SSLNIJ-C321.jpg" /></a>Fiński sąd nakazał aresztowanie francuskiego biznesmana. Gabriel Temin, mimo obowiązujących sankcji, eksportował do Rosji produkty, które mogą być wykorzystywane przez wojsko. Zarządzane przez niego firmy zostały umieszczone na &quot;czarnej liście&quot; amerykańskiego Departamentu Stanu. Finowie obawiają się, że biznesman może zniszczyć dowody przestępstwa.</p><br clear="all" />

## Pył saharyjski nad Polską. W drobinkach są promieniotwórcze izotopy
 - [https://wydarzenia.interia.pl/kraj/news-pyl-saharyjski-nad-polska-w-drobinkach-sa-promieniotworcze-i,nId,7033410](https://wydarzenia.interia.pl/kraj/news-pyl-saharyjski-nad-polska-w-drobinkach-sa-promieniotworcze-i,nId,7033410)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T19:27:48+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-pyl-saharyjski-nad-polska-w-drobinkach-sa-promieniotworcze-i,nId,7033410"><img align="left" alt="Pył saharyjski nad Polską. W drobinkach są promieniotwórcze izotopy" src="https://i.iplsc.com/pyl-saharyjski-nad-polska-w-drobinkach-sa-promieniotworcze-i/000HOGIK8MFB9D5L-C321.jpg" /></a>Nad Polskę dotarł pył znad Sahary - potwierdza rzecznik IMGW Grzegorz Walijewski. Największe stężenie pyłu wystąpi w zachodniej i południowej części kraju. Choć w drobinkach piasku zidentyfikowano m.in. promieniotwórcze izotopy, to jest ich na tyle mało, że nie stanowią zagrożenia dla życia i zdrowia.</p><br clear="all" />

## Niemiecki minister uderza w Polskę. "Solidarni, kiedy im to odpowiada"
 - [https://wydarzenia.interia.pl/zagranica/news-niemiecki-minister-uderza-w-polske-solidarni-kiedy-im-to-odp,nId,7033371](https://wydarzenia.interia.pl/zagranica/news-niemiecki-minister-uderza-w-polske-solidarni-kiedy-im-to-odp,nId,7033371)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T19:26:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiecki-minister-uderza-w-polske-solidarni-kiedy-im-to-odp,nId,7033371"><img align="left" alt="Niemiecki minister uderza w Polskę. &quot;Solidarni, kiedy im to odpowiada&quot;" src="https://i.iplsc.com/niemiecki-minister-uderza-w-polske-solidarni-kiedy-im-to-odp/000HOGDHF338VSDH-C321.jpg" /></a>- Jesteście solidarni wtedy, kiedy wam to odpowiada. Kiedy wam to nie pasuje, nie jesteście - ocenił surowo niemiecki minister rolnictwa i polityki żywnościowej Cem Özdemir, komentując decyzję Polski i innych krajów o jednostronnym przedłużeniu embarga na ukraińskie produkty rolne. Zaznaczył też, iż w tym czasie niezbędne jest solidarne działanie, a nie rozgrywanie kryzysów przeciwko innym krajom. Wszystkie inne decyzje w tej sprawie nazwał &quot;grą na korzyść Putina&quot;.</p><br clear="all" />

## Hunter Biden kontratakuje. Syn prezydenta USA złożył pozew
 - [https://wydarzenia.interia.pl/zagranica/news-hunter-biden-kontratakuje-syn-prezydenta-usa-zlozyl-pozew,nId,7033372](https://wydarzenia.interia.pl/zagranica/news-hunter-biden-kontratakuje-syn-prezydenta-usa-zlozyl-pozew,nId,7033372)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T19:06:35+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-hunter-biden-kontratakuje-syn-prezydenta-usa-zlozyl-pozew,nId,7033372"><img align="left" alt="Hunter Biden kontratakuje. Syn prezydenta USA złożył pozew" src="https://i.iplsc.com/hunter-biden-kontratakuje-syn-prezydenta-usa-zlozyl-pozew/000HOG9QVNK074V7-C321.jpg" /></a>Hunter Biden pozwał amerykański urząd podatkowy (Internal Revenue Service). Według prawników reprezentujących syna urzędującego prezydenta USA agenci IRS nielegalnie ujawnili informacje zawarte w jego zeznaniu podatkowym oraz nie zapewnili ochrony jego danych osobowych.</p><br clear="all" />

## Chaos w ośrodku dla migrantów na Sycylii. Kilkaset osób uciekło
 - [https://wydarzenia.interia.pl/zagranica/news-chaos-w-osrodku-dla-migrantow-na-sycylii-kilkaset-osob-uciek,nId,7033398](https://wydarzenia.interia.pl/zagranica/news-chaos-w-osrodku-dla-migrantow-na-sycylii-kilkaset-osob-uciek,nId,7033398)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T18:51:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-chaos-w-osrodku-dla-migrantow-na-sycylii-kilkaset-osob-uciek,nId,7033398"><img align="left" alt="Chaos w ośrodku dla migrantów na Sycylii. Kilkaset osób uciekło" src="https://i.iplsc.com/chaos-w-osrodku-dla-migrantow-na-sycylii-kilkaset-osob-uciek/000HOGG8EKNJTKAR-C321.jpg" /></a>Chaos w ośrodku dla migrantów w mieście Porto Empedocle na Sycylii. W miejscu do którego trafiają osoby, które nielegalnie przypłynęły na włoską wyspę Lampedusę, brakuje wody i jedzenia. W ciągu ostatnich kilkunastu godzin z ośrodka uciekło ponad 100 osób - poinformowały włoskie media. Burmistrz miasteczka uważa jednak, że uciekinierów jest dużo więcej.</p><br clear="all" />

## Premier o majątku narodowym i polityce inwestycji: Nie dla wyprzedaży
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-majatku-narodowym-i-polityce-inwestycji-nie-dla-wy,nId,7033382](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-majatku-narodowym-i-polityce-inwestycji-nie-dla-wy,nId,7033382)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T18:27:16+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-o-majatku-narodowym-i-polityce-inwestycji-nie-dla-wy,nId,7033382"><img align="left" alt="Premier o majątku narodowym i polityce inwestycji: Nie dla wyprzedaży" src="https://i.iplsc.com/premier-o-majatku-narodowym-i-polityce-inwestycji-nie-dla-wy/000HOG93N2BE10XR-C321.jpg" /></a>- Zobaczcie, jak propaganda Tuska wbija się głęboko ludziom do głów. Ci ludzie przecież na pewno też dobrze chcą dla Polski. Skoro tak, to dlaczego uwierzyli w te brednie, że nasza polityka społeczna odciąga ludzi od rynku pracy? - pytał podczas wizyty w tarnobrzeskich Zakładach Chemicznych &quot;Siarkopol&quot; premier Morawiecki. Podkreślał też, że to dzięki PiS i polityce inwestycji w takie zakłady, przedsiębiorstwo przetrwało, mimo że za czasów PO było w stanie likwidacji. - &quot;Nie&quot; dla wyprzedaży, &quot;tak&quot; dla inwestycji (...), Stop z bezrobociem...</p><br clear="all" />

## Duda na szczycie ONZ. "Polska pokazała odporność"
 - [https://wydarzenia.interia.pl/zagranica/news-duda-na-szczycie-onz-polska-pokazala-odpornosc,nId,7033367](https://wydarzenia.interia.pl/zagranica/news-duda-na-szczycie-onz-polska-pokazala-odpornosc,nId,7033367)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T18:04:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-duda-na-szczycie-onz-polska-pokazala-odpornosc,nId,7033367"><img align="left" alt="Duda na szczycie ONZ. &quot;Polska pokazała odporność&quot;" src="https://i.iplsc.com/duda-na-szczycie-onz-polska-pokazala-odpornosc/000HOG7T3RO4KGKI-C321.jpg" /></a>- Chcielibyśmy podzielić się tym, jak można przyspieszyć progres ekonomiczny - powiedział w poniedziałek Andrzej Duda podczas otwarcia szczytu dotyczącego Celów Zrównoważonego Rozwoju w siedzibie ONZ w Nowym Jorku. Prezydent stwierdził też, że &quot;Polska pokazała odporność na kryzysy swoją niezwykłą pomocą uchodźcom z Ukrainy&quot;.</p><br clear="all" />

## Nowe drony przestały docierać do Rosji. Winny kluczowy sojusznik Putina
 - [https://wydarzenia.interia.pl/zagranica/news-nowe-drony-przestaly-docierac-do-rosji-winny-kluczowy-sojusz,nId,7033340](https://wydarzenia.interia.pl/zagranica/news-nowe-drony-przestaly-docierac-do-rosji-winny-kluczowy-sojusz,nId,7033340)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T17:50:34+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowe-drony-przestaly-docierac-do-rosji-winny-kluczowy-sojusz,nId,7033340"><img align="left" alt="Nowe drony przestały docierać do Rosji. Winny kluczowy sojusznik Putina" src="https://i.iplsc.com/nowe-drony-przestaly-docierac-do-rosji-winny-kluczowy-sojusz/000HOG4YDPG6FO4K-C321.jpg" /></a>Jeden z największych sojuszników Federacji Rosyjskiej - Chiny - z dniem 1 września wprowadził nowe regulacje dotyczące eksportowania dronów i niezbędnych do ich tworzenia komponentów. Jak zauważają obserwatorzy, poważnie skomplikowało to dostawy UAV do Rosji, jednak krajowi producenci zdążyli podobno zgromadzić zapasy. Te mogą jednak nie wystarczyć, bo nowe procedury jawią się jako czasochłonne i skomplikowane. Tymczasem jeden z naukowców uważa, że ruch Chin to tylko &quot;pozorne działanie&quot;, by uniknąć sankcji Zachodu.</p><br clear="all" />

## F-35 rozbił się w USA. Armia wystosowała apel
 - [https://wydarzenia.interia.pl/zagranica/news-f-35-rozbil-sie-w-usa-armia-wystosowala-apel,nId,7033344](https://wydarzenia.interia.pl/zagranica/news-f-35-rozbil-sie-w-usa-armia-wystosowala-apel,nId,7033344)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T17:36:29+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-f-35-rozbil-sie-w-usa-armia-wystosowala-apel,nId,7033344"><img align="left" alt="F-35 rozbił się w USA. Armia wystosowała apel" src="https://i.iplsc.com/f-35-rozbil-sie-w-usa-armia-wystosowala-apel/000HOG21KOODVBVJ-C321.jpg" /></a>Amerykańska armia szuka samolotu F-35, który rozbił się w niedzielę po południu w Karolinie Południowej. Pilot katapultował się i bezpiecznie wylądował. Wojskowi z prośbą o pomoc w odnalezieniu wraku zgłosili się do obywateli.</p><br clear="all" />

## TVP przeprasza Bezpartyjnych na antenie. Opublikowali niepełny sondaż
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tvp-przeprasza-bezpartyjnych-na-antenie-opublikowali-niepeln,nId,7033183](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tvp-przeprasza-bezpartyjnych-na-antenie-opublikowali-niepeln,nId,7033183)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T17:25:40+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-tvp-przeprasza-bezpartyjnych-na-antenie-opublikowali-niepeln,nId,7033183"><img align="left" alt="TVP przeprasza Bezpartyjnych na antenie. Opublikowali niepełny sondaż" src="https://i.iplsc.com/tvp-przeprasza-bezpartyjnych-na-antenie-opublikowali-niepeln/000HOG3940OG9XVO-C321.jpg" /></a>W zeszłym tygodniu Bezpartyjni Samorządowcy oskarżyli Telewizję Publiczną o celowe pomijanie ich komitetu w publikacjach o wynikach sondażu wyborczego. Sąd rozpatrzył ich pozew w trybie wyborczym i przyznał politykom rację. Na antenie TVP Info wyemitowano nakazane wyrokiem przeprosiny. Wcześniej partia zagroziła pozwem także telewizji TVN. </p><br clear="all" />

## Wystąpiła w popularnym programie. Tak posłanka KO wyglądała jako 19-latka
 - [https://wydarzenia.interia.pl/kraj/news-wystapila-w-popularnym-programie-tak-poslanka-ko-wygladala-j,nId,7033168](https://wydarzenia.interia.pl/kraj/news-wystapila-w-popularnym-programie-tak-poslanka-ko-wygladala-j,nId,7033168)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T17:14:40+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wystapila-w-popularnym-programie-tak-poslanka-ko-wygladala-j,nId,7033168"><img align="left" alt="Wystąpiła w popularnym programie. Tak posłanka KO wyglądała jako 19-latka" src="https://i.iplsc.com/wystapila-w-popularnym-programie-tak-poslanka-ko-wygladala-j/000HOFQAT30QRKMC-C321.jpg" /></a>Barbara Nowacka znana jest jako polityk i działaczka feministyczna. Mimo że działalnością społeczną zajmuje się od lat, pierwsze medialne kroki stawiała, występując w popularnym programie &quot;5-10-15&quot;. Jej zdjęcie z tamtych czasów trafiło do sieci.</p><br clear="all" />

## Ukraina składa skargę na Polskę. Chodzi o embargo na zboże
 - [https://wydarzenia.interia.pl/zagranica/news-ukraina-sklada-skarge-na-polske-chodzi-o-embargo-na-zboze,nId,7033353](https://wydarzenia.interia.pl/zagranica/news-ukraina-sklada-skarge-na-polske-chodzi-o-embargo-na-zboze,nId,7033353)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T16:42:12+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraina-sklada-skarge-na-polske-chodzi-o-embargo-na-zboze,nId,7033353"><img align="left" alt="Ukraina składa skargę na Polskę. Chodzi o embargo na zboże" src="https://i.iplsc.com/ukraina-sklada-skarge-na-polske-chodzi-o-embargo-na-zboze/000HOG4E77GMT9TF-C321.jpg" /></a>Ukraina złożyła skargę do Światowej Organizacji Handlu (WTO) na Polskę, Węgry i Słowację w związku z przedłużeniem przez te kraje embarga na ukraińskie produkty rolne - przekazało ukraińskie ministerstwo gospodarki. Władze w Kijowie dodały, że postrzegają restrykcje jako &quot;naruszenie zobowiązań międzynarodowych&quot;. Na ruch Ukrainy zareagował rzecznik polskiego rządu Piotr Müller zapewniając, że skarga &quot;nie robi na Polsce wrażenia&quot;.</p><br clear="all" />

## Polska chce nałożenia nowych sankcji na Rosję i Białoruś
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-polska-chce-nalozenia-nowych-sankcji-na-rosje-i-bialorus,nId,7033191](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-polska-chce-nalozenia-nowych-sankcji-na-rosje-i-bialorus,nId,7033191)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T16:38:40+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-polska-chce-nalozenia-nowych-sankcji-na-rosje-i-bialorus,nId,7033191"><img align="left" alt="Polska chce nałożenia nowych sankcji na Rosję i Białoruś" src="https://i.iplsc.com/polska-chce-nalozenia-nowych-sankcji-na-rosje-i-bialorus/000HOG159GH57NOF-C321.jpg" /></a>Polska przedstawiła w Brukseli propozycję kolejnego pakietu sankcji Unii Europejskiej przeciw Rosji. Chodzi m.in. o zakaz importu rosyjskich diamentów - poinformował Reuters. Jednocześnie nasz kraj domaga się wprowadzenia kolejnych sankcji wobec Białorusi.</p><br clear="all" />

## Premier przeprasza. "Za błędy, potknięcia, grzechy"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-przeprasza-za-bledy-potkniecia-grzechy,nId,7033149](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-przeprasza-za-bledy-potkniecia-grzechy,nId,7033149)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T16:22:46+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-premier-przeprasza-za-bledy-potkniecia-grzechy,nId,7033149"><img align="left" alt="Premier przeprasza. &quot;Za błędy, potknięcia, grzechy&quot;" src="https://i.iplsc.com/premier-przeprasza-za-bledy-potkniecia-grzechy/000HOFM4ODSYF7SE-C321.jpg" /></a>- Przepraszamy za nasze błędy, za nasze potknięcia, za nasze grzechy - powiedział premier Mateusz Morawiecki podczas kolejnego spotkania z wyborcami. Szef polskiego rządu zwracał uwagę jednak na to, jak PiS &quot;broniło interesów polskiej wsi wobec Brukseli, Kijowa i Berlina&quot;, a także Tuska, który &quot;chciał zaorać polskie rolnictwo&quot;. - Wy, tyle razy zdradzeni przez liberałów z Platformy Obywatelskiej, doskonale wiecie, jaka jest różnica między nami a tamtymi - podkreślał w Narolu (woj. podkarpackie) Morawiecki.</p><br clear="all" />

## Pościg za Ukraińcem przy granicy. Nie opanował auta
 - [https://wydarzenia.interia.pl/podlaskie/news-poscig-za-ukraincem-przy-granicy-nie-opanowal-auta,nId,7033179](https://wydarzenia.interia.pl/podlaskie/news-poscig-za-ukraincem-przy-granicy-nie-opanowal-auta,nId,7033179)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T16:21:09+00:00

<p><a href="https://wydarzenia.interia.pl/podlaskie/news-poscig-za-ukraincem-przy-granicy-nie-opanowal-auta,nId,7033179"><img align="left" alt="Pościg za Ukraińcem przy granicy. Nie opanował auta" src="https://i.iplsc.com/poscig-za-ukraincem-przy-granicy-nie-opanowal-auta/000HOFQ23LTDCM4Q-C321.jpg" /></a>Obywatel Ukrainy nie zatrzymał się do kontroli strażników granicznych i próbował uciec. Okazało się, że w aucie przewoził Syryjczyków, którzy nielegalnie przekroczyli polską granicę. Pościg zakończył się na ogrodzeniu jednego z domów.</p><br clear="all" />

## Niemiecka minister nazwała Xi Jinpinga "dyktatorem". Pekin reaguje
 - [https://wydarzenia.interia.pl/zagranica/news-niemiecka-minister-nazwala-xi-jinpinga-dyktatorem-pekin-reag,nId,7033097](https://wydarzenia.interia.pl/zagranica/news-niemiecka-minister-nazwala-xi-jinpinga-dyktatorem-pekin-reag,nId,7033097)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T16:08:54+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niemiecka-minister-nazwala-xi-jinpinga-dyktatorem-pekin-reag,nId,7033097"><img align="left" alt="Niemiecka minister nazwała Xi Jinpinga &quot;dyktatorem&quot;. Pekin reaguje" src="https://i.iplsc.com/niemiecka-minister-nazwala-xi-jinpinga-dyktatorem-pekin-reag/000HOFL9PEU547PX-C321.jpg" /></a>Szefowa niemieckiego resortu spraw zagranicznych Annalena Baerbock nazwała chińskiego przywódcę Xi Jinpinga &quot;dyktatorem&quot;. Jej słowa wywołały oburzenie w Pekinie. Przedstawicielka chińskiego MSZ nazwał je &quot;prowokacją polityczną&quot;.</p><br clear="all" />

## Potężne uderzenie w Rosjan. Jednego dnia stracili setki żołnierzy
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezne-uderzenie-w-rosjan-jednego-dnia-stracili-setki-zolni,nId,7033147](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezne-uderzenie-w-rosjan-jednego-dnia-stracili-setki-zolni,nId,7033147)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T15:50:49+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezne-uderzenie-w-rosjan-jednego-dnia-stracili-setki-zolni,nId,7033147"><img align="left" alt="Potężne uderzenie w Rosjan. Jednego dnia stracili setki żołnierzy" src="https://i.iplsc.com/potezne-uderzenie-w-rosjan-jednego-dnia-stracili-setki-zolni/000HOFLVHLK1IGQD-C321.jpg" /></a>Ponad 300 &quot;zneutralizowanych&quot; rosyjskich okupantów, zniszczone wozy bojowe, systemy arytleryjskie i drony. Takim &quot;dziennym&quot; bilansem chwali się ukraińskie wojsko, które w ramach kontrofensywy uderzyło w Rosjan w obwodach zaporoskim i donieckim. Według Ukraińców Rosjanie przeprowadzili nieudane akcje ofensywne.</p><br clear="all" />

## Impreza w Węgrowie. 73-latek wjechał w działaczki Koalicji Obywatelskiej
 - [https://wydarzenia.interia.pl/mazowieckie/news-impreza-w-wegrowie-73-latek-wjechal-w-dzialaczki-koalicji-ob,nId,7033116](https://wydarzenia.interia.pl/mazowieckie/news-impreza-w-wegrowie-73-latek-wjechal-w-dzialaczki-koalicji-ob,nId,7033116)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T15:38:04+00:00

<p><a href="https://wydarzenia.interia.pl/mazowieckie/news-impreza-w-wegrowie-73-latek-wjechal-w-dzialaczki-koalicji-ob,nId,7033116"><img align="left" alt="Impreza w Węgrowie. 73-latek wjechał w działaczki Koalicji Obywatelskiej" src="https://i.iplsc.com/impreza-w-wegrowie-73-latek-wjechal-w-dzialaczki-koalicji-ob/000HOFMZ7R8ULHKF-C321.jpg" /></a>Na Mazowieckim Święcie Chleba i Sera w Węgrowie na Mazowszu musiała interweniować policja. Wszystko przez 73-letniego kierowcę, który wjechał autem w dwie kobiety związane z Koalicją Obywatelską. - Pokrzywdzona i towarzysząca jej osoba miały ubranie wskazujące, że są sympatyczkami opozycji - powiedział Interii podkom. Marcin Góral z węgrowskiej policji. Mężczyzna twierdzi, że nie pamięta zdarzenia.</p><br clear="all" />

## Rosjanka odeszła z wojska, bo była w ciąży. Bezlitosny wyrok sądu
 - [https://wydarzenia.interia.pl/zagranica/news-rosjanka-odeszla-z-wojska-bo-byla-w-ciazy-bezlitosny-wyrok-s,nId,7033096](https://wydarzenia.interia.pl/zagranica/news-rosjanka-odeszla-z-wojska-bo-byla-w-ciazy-bezlitosny-wyrok-s,nId,7033096)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T15:21:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rosjanka-odeszla-z-wojska-bo-byla-w-ciazy-bezlitosny-wyrok-s,nId,7033096"><img align="left" alt="Rosjanka odeszła z wojska, bo była w ciąży. Bezlitosny wyrok sądu" src="https://i.iplsc.com/rosjanka-odeszla-z-wojska-bo-byla-w-ciazy-bezlitosny-wyrok-s/000HOFHOJD979OOE-C321.jpg" /></a>Sześć lat pozbawienia wolności - taki wyrok usłyszała ciężarna rosyjska wojskowa, która zrezygnowała z pełnienia służby po tym, jak otrzymała od lekarza stosowne zaświadczenie medyczne. Według władz wojskowych Rosjanka nie miała prawa do takiego działania i bez uzasadnionego powodu po prostu nie stawiła się na służbę. Skazana żołnierka przekonywała z kolei, że myślała, iż dokument wystawiony przez medyka jest wystarczający, a lekarze przekażą dowództwu decyzję o jej zwolnieniu z uwagi na ciążę.</p><br clear="all" />

## Próbował uratować kolegę, który wpadł do kadzi z prosecco. Sam zginął
 - [https://wydarzenia.interia.pl/zagranica/news-probowal-uratowac-kolege-ktory-wpadl-do-kadzi-z-prosecco-sam,nId,7033067](https://wydarzenia.interia.pl/zagranica/news-probowal-uratowac-kolege-ktory-wpadl-do-kadzi-z-prosecco-sam,nId,7033067)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T15:05:30+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-probowal-uratowac-kolege-ktory-wpadl-do-kadzi-z-prosecco-sam,nId,7033067"><img align="left" alt="Próbował uratować kolegę, który wpadł do kadzi z prosecco. Sam zginął" src="https://i.iplsc.com/probowal-uratowac-kolege-ktory-wpadl-do-kadzi-z-prosecco-sam/000HOFGL0CQPBF7S-C321.jpg" /></a>Włoski winiarz został znaleziony martwy w kadzi z prosecco. Wcześniej próbował uratować kolegę, który wpadł do tego samego zbiornika. Mężczyznę zabiły toksyczne opary, który powstają podczas procesu fermentacji. Uratowany współpracownik trafił do szpitala. Zdarzenie na nowo spowodowało dyskusję nad standardami bezpieczeństwa w branży produkcji żywności i napojów we Włoszech.</p><br clear="all" />

## USA i Iran wymieniają więźniów. Bezprecedensowa umowa
 - [https://wydarzenia.interia.pl/zagranica/news-usa-i-iran-wymieniaja-wiezniow-bezprecedensowa-umowa,nId,7033085](https://wydarzenia.interia.pl/zagranica/news-usa-i-iran-wymieniaja-wiezniow-bezprecedensowa-umowa,nId,7033085)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T14:46:31+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-usa-i-iran-wymieniaja-wiezniow-bezprecedensowa-umowa,nId,7033085"><img align="left" alt="USA i Iran wymieniają więźniów. Bezprecedensowa umowa" src="https://i.iplsc.com/usa-i-iran-wymieniaja-wiezniow-bezprecedensowa-umowa/000HOFFDNPLWTDEV-C321.jpg" /></a>Pięciu amerykańskich więźniów wyleciało z terytorium Iranu i wylądowało w katarskiej Ad-Dausze. W zamian Stany Zjednoczone uwolnią pięciu Irańczyków. To efekt międzynarodowego porozumienia między obydwoma krajami, które poprzedziło osiem tur negocjacji. Dodatkowo Teheran odzyska 6 miliardów dolarów zamrożonych funduszy.</p><br clear="all" />

## Antypolski film na Białorusi. Ujawniono, jak walczą o "dobrą" frekwencję
 - [https://wydarzenia.interia.pl/zagranica/news-antypolski-film-na-bialorusi-ujawniono-jak-walcza-o-dobra-fr,nId,7033027](https://wydarzenia.interia.pl/zagranica/news-antypolski-film-na-bialorusi-ujawniono-jak-walcza-o-dobra-fr,nId,7033027)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T14:34:24+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-antypolski-film-na-bialorusi-ujawniono-jak-walcza-o-dobra-fr,nId,7033027"><img align="left" alt="Antypolski film na Białorusi. Ujawniono, jak walczą o &quot;dobrą&quot; frekwencję" src="https://i.iplsc.com/antypolski-film-na-bialorusi-ujawniono-jak-walcza-o-dobra-fr/000HOEPQ9PV9MDYR-C321.jpg" /></a>Kina mają świecić pustkami, a na seanse &quot;prawie nikt nie chodzi dobrowolnie&quot; - oceniają niezależne białoruskie media, opisując losy antypolskiej produkcji &quot;Na drugim brzegu&quot;, która zadebiutowała w Domu Kina w Mińsku w ubiegłym tygodniu. Co ciekawe, dziennikarze dopatrzyli się zastanawiających ruchów dotyczących rezerwacji miejsc, które mogą wskazywać, że wyjścia do kin były w wielu placówkach resortowych czy medycznych organizowane odgórnie. </p><br clear="all" />

## Decyzja w sprawie Nowaka. "Podwójne" problemy byłego ministra
 - [https://wydarzenia.interia.pl/news-decyzja-w-sprawie-nowaka-podwojne-problemy-bylego-ministra,nId,7033025](https://wydarzenia.interia.pl/news-decyzja-w-sprawie-nowaka-podwojne-problemy-bylego-ministra,nId,7033025)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T14:15:32+00:00

<p><a href="https://wydarzenia.interia.pl/news-decyzja-w-sprawie-nowaka-podwojne-problemy-bylego-ministra,nId,7033025"><img align="left" alt="Decyzja w sprawie Nowaka. &quot;Podwójne&quot; problemy byłego ministra" src="https://i.iplsc.com/decyzja-w-sprawie-nowaka-podwojne-problemy-bylego-ministra/000HOFHGA5V0CPKQ-C321.jpg" /></a>Warszawski sąd okręgowy podjął w poniedziałek decyzję o podzieleniu sprawy korupcyjnej tzw. grupy Sławomira Nowaka na dwa osobne postępowania. Były minister oskarżony jest m.in. o korupcję i kierowanie grupą przestępczą, których dopuścił się, pełniąc oficjalne funkcje w Polsce i w Ukrainie. Na wniosek obrońców ze sprawy dotyczącej kwestii ukraińskich wyłączono wątki dotyczące domniemanych przestępstw popełnionych w naszym kraju.</p><br clear="all" />

## Zapowiedź pozwu Ukrainy wobec Polski. Politycy oburzeni
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zapowiedz-pozwu-ukrainy-wobec-polski-politycy-oburzeni,nId,7032994](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zapowiedz-pozwu-ukrainy-wobec-polski-politycy-oburzeni,nId,7032994)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:59:28+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zapowiedz-pozwu-ukrainy-wobec-polski-politycy-oburzeni,nId,7032994"><img align="left" alt="Zapowiedź pozwu Ukrainy wobec Polski. Politycy oburzeni" src="https://i.iplsc.com/zapowiedz-pozwu-ukrainy-wobec-polski-politycy-oburzeni/000HOEND0OHB71KT-C321.jpg" /></a>Ukraiński wiceminister rolnictwa Taras Kaczka w wywiadzie zapowiedział, że Kijów pozwie Polskę, Węgry i Słowację do Światowej Organizacji Handlu w związku z ich odmową zniesienia zakazu importu ukraińskich produktów rolnych. Zapowiedź pozwu sprowokowała liczne, nieprzychylne komentarze wśród polityków, zwłaszcza obozu władzy oraz Konfederacji. &quot;Wiceminister gospodarki Ukrainy Taras Kaczka zachowuje się impertynencko, pouczając Polskę ws. zboża&quot; - oceniła była premier Beata Szydło.</p><br clear="all" />

## Bruksela. Spór o zboże. Ukraina przedstawiła nową propozycję
 - [https://wydarzenia.interia.pl/zagranica/news-bruksela-spor-o-zboze-ukraina-przedstawila-nowa-propozycje,nId,7033104](https://wydarzenia.interia.pl/zagranica/news-bruksela-spor-o-zboze-ukraina-przedstawila-nowa-propozycje,nId,7033104)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:54:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bruksela-spor-o-zboze-ukraina-przedstawila-nowa-propozycje,nId,7033104"><img align="left" alt="Bruksela. Spór o zboże. Ukraina przedstawiła nową propozycję" src="https://i.iplsc.com/bruksela-spor-o-zboze-ukraina-przedstawila-nowa-propozycje/000HOFGZAGH30PKP-C321.jpg" /></a>Ukraina przedstawiła w Brukseli propozycję dotyczącą wwozu swojego zboża do krajów UE, która zakłada system pozwoleń na eksport. Państwa UE graniczące z Ukrainą uznały, że jest niewystarczająca - poinformowała PAP powołując się na swoje źródła w Brukseli.</p><br clear="all" />

## Tajemnicze zaginięcie Anety. 23-latki szuka policja
 - [https://wydarzenia.interia.pl/dolnoslaskie/news-tajemnicze-zaginiecie-anety-23-latki-szuka-policja,nId,7033046](https://wydarzenia.interia.pl/dolnoslaskie/news-tajemnicze-zaginiecie-anety-23-latki-szuka-policja,nId,7033046)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:34:08+00:00

<p><a href="https://wydarzenia.interia.pl/dolnoslaskie/news-tajemnicze-zaginiecie-anety-23-latki-szuka-policja,nId,7033046"><img align="left" alt="Tajemnicze zaginięcie Anety. 23-latki szuka policja" src="https://i.iplsc.com/tajemnicze-zaginiecie-anety-23-latki-szuka-policja/000HOEO3DBHI58PV-C321.jpg" /></a>23-letnia Aneta Szubryt w czwartek wyszła ze swojego mieszkania przy ul. Zachodniej we Wrocławiu. Od tamtej pory nie ma z nią kontaktu. O pomoc w poszukiwaniach kobiety apelują policjanci. Kobietę można rozpoznać m.in. po charakterystycznych tatuażach.</p><br clear="all" />

## Potężny wybuch w Doniecku. Pocisk trafił w siedzibę władz okupacyjnych
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-wybuch-w-doniecku-pocisk-trafil-w-siedzibe-wladz-oku,nId,7033019](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-wybuch-w-doniecku-pocisk-trafil-w-siedzibe-wladz-oku,nId,7033019)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:30:06+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-potezny-wybuch-w-doniecku-pocisk-trafil-w-siedzibe-wladz-oku,nId,7033019"><img align="left" alt="Potężny wybuch w Doniecku. Pocisk trafił w siedzibę władz okupacyjnych" src="https://i.iplsc.com/potezny-wybuch-w-doniecku-pocisk-trafil-w-siedzibe-wladz-oku/000HOEPJDOAHI7DC-C321.jpg" /></a>Kłęby czarnego dymu od kilkudziesięciu minut unoszą się nad budynkiem okupacyjnych władz samozwańczej Donieckiej Republiki Ludowej. W budynku miało odbywać się spotkanie przedstawicieli najwyższych władz regionu.</p><br clear="all" />

## Mewy przejmują miasto? Turyści zostali ostrzeżeni
 - [https://wydarzenia.interia.pl/zagranica/news-mewy-przejmuja-miasto-turysci-zostali-ostrzezeni,nId,7033080](https://wydarzenia.interia.pl/zagranica/news-mewy-przejmuja-miasto-turysci-zostali-ostrzezeni,nId,7033080)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:27:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-mewy-przejmuja-miasto-turysci-zostali-ostrzezeni,nId,7033080"><img align="left" alt="Mewy przejmują miasto? Turyści zostali ostrzeżeni" src="https://i.iplsc.com/mewy-przejmuja-miasto-turysci-zostali-ostrzezeni/000HOF1NLD3BDU9O-C321.jpg" /></a>W jednym z najsłynniejszych turystycznych miast świata mają miejsce sceny rodem z filmu &quot;Ptaki&quot; Alfreda Hitchcocka. Ludzie atakowani są przez agresywne mewy, które starają się wyrwać im z rąk jedzenie. Problem staje się na tyle duży, że w mieście ustawiono specjalne znaki postrzegające przed zagrożeniem. Już wcześniej z ptakami próbowano sobie poradzić na wiele, często niezwykłych sposobów. Wykorzystywano między innymi pistolety na wodę i szukano pomocy u sokolników. Mewy nie dają jednak za wygraną.</p><br clear="all" />

## Jerycho na Liście Światowego Dziedzictwa. "Cynicznie wykorzystali UNESCO"
 - [https://wydarzenia.interia.pl/zagranica/news-jerycho-na-liscie-swiatowego-dziedzictwa-cynicznie-wykorzyst,nId,7033018](https://wydarzenia.interia.pl/zagranica/news-jerycho-na-liscie-swiatowego-dziedzictwa-cynicznie-wykorzyst,nId,7033018)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:13:32+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-jerycho-na-liscie-swiatowego-dziedzictwa-cynicznie-wykorzyst,nId,7033018"><img align="left" alt="Jerycho na Liście Światowego Dziedzictwa. &quot;Cynicznie wykorzystali UNESCO&quot;" src="https://i.iplsc.com/jerycho-na-liscie-swiatowego-dziedzictwa-cynicznie-wykorzyst/000HOEO0559XY195-C321.jpg" /></a>Starożytne ruiny Jerycha zostały wpisane na Listę Światowego Dziedzictwa UNESCO. Decyzja rozgniewała Izrael. Ministerstwo Spraw Zagranicznych tego kraju uznało, że akcja to &quot;kolejna oznaka cynicznego wykorzystywania UNESCO przez Palestyńczyków i upolitycznienia tej organizacji&quot;.</p><br clear="all" />

## Proszą kobiety, by nie robiły makijażu w pociągach. Burza w Chinach
 - [https://wydarzenia.interia.pl/zagranica/news-prosza-kobiety-by-nie-robily-makijazu-w-pociagach-burza-w-ch,nId,7032950](https://wydarzenia.interia.pl/zagranica/news-prosza-kobiety-by-nie-robily-makijazu-w-pociagach-burza-w-ch,nId,7032950)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T13:00:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-prosza-kobiety-by-nie-robily-makijazu-w-pociagach-burza-w-ch,nId,7032950"><img align="left" alt="Proszą kobiety, by nie robiły makijażu w pociągach. Burza w Chinach" src="https://i.iplsc.com/prosza-kobiety-by-nie-robily-makijazu-w-pociagach-burza-w-ch/000HOEH9G6KD4I6D-C321.jpg" /></a>W serii promocyjnych filmów chińska kolej państwowa instruowała pasażerów, jak powinni zachowywać się w pociągach. Jeden ze spotów, skierowany do kobiet, wywołał oburzenie. Na nagraniu poproszono panie, aby powstrzymały się od nakładania makijażu podczas podróży. &quot;Czy następnym posunięciem będzie raz na zawsze zakazanie kobietom wsiadania do pociągów?&quot; - czytamy w jednym z komentarzy pod kontrowersyjnym filmem. Chińscy urzędnicy bronią nagrania, a państwowe media wzywają obywateli, aby nie &quot;nadinterpretowali&quot; reklamy.</p><br clear="all" />

## Aresztowaną potrącił pociąg. Policjantka nie pójdzie do więzienia
 - [https://wydarzenia.interia.pl/zagranica/news-aresztowana-potracil-pociag-policjantka-nie-pojdzie-do-wiezi,nId,7032937](https://wydarzenia.interia.pl/zagranica/news-aresztowana-potracil-pociag-policjantka-nie-pojdzie-do-wiezi,nId,7032937)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T12:48:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-aresztowana-potracil-pociag-policjantka-nie-pojdzie-do-wiezi,nId,7032937"><img align="left" alt="Aresztowaną potrącił pociąg. Policjantka nie pójdzie do więzienia" src="https://i.iplsc.com/aresztowana-potracil-pociag-policjantka-nie-pojdzie-do-wiezi/000HOE62SO4JB17X-C321.jpg" /></a>Sąd w Amerykańskim stanie Kolorado zdecydował o karze 30 miesięcy okresu próbnego pod nadzorem kuratora dla byłej policjantki, która zostawiła podejrzaną w aucie patrolowym zaparkowanym na torach. W samochód uderzył pociąg, a znajdująca się w środku 20-latka doznała rozległych obrażeń. W ramach zadośćuczynienia była funkcjonariuszka ma również odbyć sto godzin prac społecznych. </p><br clear="all" />

## Zatrzymaną potrącił pociąg. Policjantka nie pójdzie do więzienia
 - [https://wydarzenia.interia.pl/zagranica/news-zatrzymana-potracil-pociag-policjantka-nie-pojdzie-do-wiezie,nId,7032937](https://wydarzenia.interia.pl/zagranica/news-zatrzymana-potracil-pociag-policjantka-nie-pojdzie-do-wiezie,nId,7032937)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T12:48:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zatrzymana-potracil-pociag-policjantka-nie-pojdzie-do-wiezie,nId,7032937"><img align="left" alt="Zatrzymaną potrącił pociąg. Policjantka nie pójdzie do więzienia" src="https://i.iplsc.com/zatrzymana-potracil-pociag-policjantka-nie-pojdzie-do-wiezie/000HOES5JVP1YQU3-C321.jpg" /></a>Sąd w amerykańskim stanie Kolorado zdecydował o karze 30 miesięcy okresu próbnego pod nadzorem kuratora dla byłej policjantki, która zostawiła podejrzaną w aucie patrolowym zaparkowanym na torach. W samochód uderzył pociąg, a znajdująca się w środku 20-latka doznała rozległych obrażeń. W ramach zadośćuczynienia była funkcjonariuszka ma również odbyć sto godzin prac społecznych. </p><br clear="all" />

## Tysiące Rosjan wydalonych z kraju. Nie zdali egzaminu językowego
 - [https://wydarzenia.interia.pl/zagranica/news-tysiace-rosjan-wydalonych-z-kraju-nie-zdali-egzaminu-jezykow,nId,7032979](https://wydarzenia.interia.pl/zagranica/news-tysiace-rosjan-wydalonych-z-kraju-nie-zdali-egzaminu-jezykow,nId,7032979)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T12:17:13+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tysiace-rosjan-wydalonych-z-kraju-nie-zdali-egzaminu-jezykow,nId,7032979"><img align="left" alt="Tysiące Rosjan wydalonych z kraju. Nie zdali egzaminu językowego" src="https://i.iplsc.com/tysiace-rosjan-wydalonych-z-kraju-nie-zdali-egzaminu-jezykow/000HOEDCMXR35I42-C321.jpg" /></a>Blisko 3600 obywateli Rosji będzie musiało, w ciągu trzech miesięcy, opuścić terytorium Łotwy - informuje Maira Roze. Przedstawicielka Urzędu ds. Obywatelstwa i Migracji potwierdziła medialne doniesienia o tysiącach osób, które otrzymają zakaz dalszego pobytu w kraju.</p><br clear="all" />

## Gajewska na spotkaniu Jakiego mówiła o aferze wizowej. "Przyszłam pokojowo"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-gajewska-na-spotkaniu-jakiego-mowila-o-aferze-wizowej-przysz,nId,7032913](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-gajewska-na-spotkaniu-jakiego-mowila-o-aferze-wizowej-przysz,nId,7032913)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T12:12:41+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-gajewska-na-spotkaniu-jakiego-mowila-o-aferze-wizowej-przysz,nId,7032913"><img align="left" alt="Gajewska na spotkaniu Jakiego mówiła o aferze wizowej. &quot;Przyszłam pokojowo&quot;" src="https://i.iplsc.com/gajewska-na-spotkaniu-jakiego-mowila-o-aferze-wizowej-przysz/000HOE372H7MINT4-C321.jpg" /></a>Posłanka Koalicji Obywatelskiej Kinga Gajewska przekazała w mediach społecznościowych, że wzięła udział w spotkaniu europosła PiS Patryka Jakiego z wyborcami. W tym czasie pokrótce poruszyła temat afery wizowej, prosząc także zgromadzonych, aby dowiedzieli się więcej na ten temat. Jak potem przekazała na platformie X, &quot;będzie na spotkaniach kandydatów PiS grzecznie informowała o aferze wizowej i apelowała o krytycyzm&quot;. &quot;Jak zobaczyłem, że Kinga Gajewska przyszła na spotkanie, osobiście dałem jej mikrofon&quot; - skomentował całe zdarzenie Jaki,...</p><br clear="all" />

## Kupił mięso w popularnym sklepie. Uderzył go straszny smród
 - [https://wydarzenia.interia.pl/lubelskie/news-kupil-mieso-w-popularnym-sklepie-uderzyl-go-straszny-smrod,nId,7032918](https://wydarzenia.interia.pl/lubelskie/news-kupil-mieso-w-popularnym-sklepie-uderzyl-go-straszny-smrod,nId,7032918)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T11:49:48+00:00

<p><a href="https://wydarzenia.interia.pl/lubelskie/news-kupil-mieso-w-popularnym-sklepie-uderzyl-go-straszny-smrod,nId,7032918"><img align="left" alt="Kupił mięso w popularnym sklepie. Uderzył go straszny smród " src="https://i.iplsc.com/kupil-mieso-w-popularnym-sklepie-uderzyl-go-straszny-smrod/000HOE1RNU8OPHA2-C321.jpg" /></a>Mieszkaniec Lublina, robiąc zakupy w popularnym sklepie, upolował prawdziwą okazję, udało mu się kupić dwa opakowania wołowiny w promocyjnej cenie. Jego zadowolenie nie trwało jednak zbyt długo. Kiedy chciał przygotować obiad, otwierając jedno z pudełek, uderzył go potworny zapach. - Okazało się, że mięso cuchnie - opisywał pan Tomasz.</p><br clear="all" />

## Stan zdrowia Ramzana Kadyrowa. Jest komunikat z Kremla
 - [https://wydarzenia.interia.pl/zagranica/news-stan-zdrowia-ramzana-kadyrowa-jest-komunikat-z-kremla,nId,7032914](https://wydarzenia.interia.pl/zagranica/news-stan-zdrowia-ramzana-kadyrowa-jest-komunikat-z-kremla,nId,7032914)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T11:35:25+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-stan-zdrowia-ramzana-kadyrowa-jest-komunikat-z-kremla,nId,7032914"><img align="left" alt="Stan zdrowia Ramzana Kadyrowa. Jest komunikat z Kremla" src="https://i.iplsc.com/stan-zdrowia-ramzana-kadyrowa-jest-komunikat-z-kremla/000HOE386GQEQLS7-C321.jpg" /></a>Sekretarz prasowy Kremla Dmitrij Pieskow poinformował, że nie ma obecnie żadnych informacji o możliwej chorobie Ramzana Kadyrowa. Jednocześnie rzecznik zdementował doniesienia o rzekomych spotkaniach przywódcy Czeczenii z Władimirem Putinem.</p><br clear="all" />

## Żył 40 milionów lat przed dinozaurami. "Budził postrach u wszystkich"
 - [https://wydarzenia.interia.pl/zagranica/news-zyl-40-milionow-lat-przed-dinozaurami-budzil-postrach-u-wszy,nId,7032850](https://wydarzenia.interia.pl/zagranica/news-zyl-40-milionow-lat-przed-dinozaurami-budzil-postrach-u-wszy,nId,7032850)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T11:15:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zyl-40-milionow-lat-przed-dinozaurami-budzil-postrach-u-wszy,nId,7032850"><img align="left" alt="Żył 40 milionów lat przed dinozaurami. &quot;Budził postrach u wszystkich&quot;" src="https://i.iplsc.com/zyl-40-milionow-lat-przed-dinozaurami-budzil-postrach-u-wszy/000HODZT3DN7YAJU-C321.jpg" /></a>W Brazylii naukowcy dokonali zdumiewającego odkrycia. W São Gabriel znaleziono liczące 265 milionów lat doskonale zachowane skamieniałości. Należą one do przerażającego drapieżnika, który żył w Ameryce Południowej 40 milionów lat przed dinozaurami. Jak twierdzą badacze, Pampaphoneus biccai był największym mięsożercą swoich czasów, który budził postrach we wszystkim, co stanęło mu na drodze.</p><br clear="all" />

## Idzie po władzę na Słowacji. Mówi o końcu pomagania Ukrainie
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-idzie-po-wladze-na-slowacji-mowi-o-koncu-pomagania-ukrainie,nId,7032895](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-idzie-po-wladze-na-slowacji-mowi-o-koncu-pomagania-ukrainie,nId,7032895)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T11:13:57+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-idzie-po-wladze-na-slowacji-mowi-o-koncu-pomagania-ukrainie,nId,7032895"><img align="left" alt="Idzie po władzę na Słowacji. Mówi o końcu pomagania Ukrainie" src="https://i.iplsc.com/idzie-po-wladze-na-slowacji-mowi-o-koncu-pomagania-ukrainie/000HOE29BRXE8WUL-C321.jpg" /></a>- Jeśli partia Smer będzie tworzyć rząd, Słowacja wycofa się ze wsparcia militarnego dla Ukrainy - zapowiedział lider ugrupowania Robert Fico. Polityk pod koniec sierpnia powiedział, że wojna na Ukrainie &quot;zaczęła się w 2014 r., kiedy ukraińscy naziści i faszyści zaczęli mordować obywateli Rosji w Donbasie i Ługańsku&quot;.</p><br clear="all" />

## Papież miał wiedzieć o obozach zagłady. Ujawniono zaginiony list
 - [https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-o-obozach-zaglady-ujawniono-zaginiony-l,nId,7032774](https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-o-obozach-zaglady-ujawniono-zaginiony-l,nId,7032774)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:54:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-o-obozach-zaglady-ujawniono-zaginiony-l,nId,7032774"><img align="left" alt="Papież miał wiedzieć o obozach zagłady. Ujawniono zaginiony list" src="https://i.iplsc.com/papiez-mial-wiedziec-o-obozach-zaglady-ujawniono-zaginiony-l/000HODGXA9IRB9BV-C321.jpg" /></a>Papież Pius XII miał mieć świadomość zbrodni popełnionych przez Niemców w obozach zagłady już w 1942 r. - wynika z listu znalezionego w archiwach watykańskich. Reuters zwraca uwagę, że podważa to oficjalne i dotychczasowe stanowisko Stolicy Apostolskiej. &quot;Mamy do czynienia z fundamentalnym dowodem na istnienie przepływu wiadomości o nazistowskich zbrodniach, które docierały do Stolicy Apostolskiej w tym samym czasie&quot; - pisze dziennik &quot;Corriere della Sera&quot;. </p><br clear="all" />

## Papież miał wiedzieć. Ujawniono sensacyjny list w archiwach Watykanu
 - [https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-ujawniono-sensacyjny-list-w-archiwach-w,nId,7032774](https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-ujawniono-sensacyjny-list-w-archiwach-w,nId,7032774)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:54:59+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-papiez-mial-wiedziec-ujawniono-sensacyjny-list-w-archiwach-w,nId,7032774"><img align="left" alt="Papież miał wiedzieć. Ujawniono sensacyjny list w archiwach Watykanu" src="https://i.iplsc.com/papiez-mial-wiedziec-ujawniono-sensacyjny-list-w-archiwach-w/000HODGXA9IRB9BV-C321.jpg" /></a>Papież Pius XII miał mieć świadomość zbrodni popełnionych przez Niemców w obozach zagłady już w 1942 r. - wynika z listu znalezionego w archiwach watykańskich. Reuters zwraca uwagę, że podważa to oficjalne i dotychczasowe stanowisko Stolicy Apostolskiej. </p><br clear="all" />

## "Doszliśmy do przełomowego punktu w stosunkach niemiecko-rosyjskich"
 - [https://wydarzenia.interia.pl/zagranica/news-doszlismy-do-przelomowego-punktu-w-stosunkach-niemiecko-rosy,nId,7032845](https://wydarzenia.interia.pl/zagranica/news-doszlismy-do-przelomowego-punktu-w-stosunkach-niemiecko-rosy,nId,7032845)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:53:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-doszlismy-do-przelomowego-punktu-w-stosunkach-niemiecko-rosy,nId,7032845"><img align="left" alt="&quot;Doszliśmy do przełomowego punktu w stosunkach niemiecko-rosyjskich&quot; " src="https://i.iplsc.com/doszlismy-do-przelomowego-punktu-w-stosunkach-niemiecko-rosy/000HOE2LG1U7EESW-C321.jpg" /></a>Niemiecka polityka energetyczna poniosła klęskę. Skutki odczuje cała Europa. Ale powrotu do tego, co przed wojną, nie będzie - przekonuje Interię Stefan Meister, ekspert Niemieckiego Towarzystwa Polityki Zagranicznej. </p><br clear="all" />

## Przetasowania w sondażu IBRiS dla "Wydarzeń". Konfederacja traci podium
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/sondaze/news-przetasowania-w-sondazu-ibris-dla-wydarzen-konfederacja-trac,nId,7032902](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/sondaze/news-przetasowania-w-sondazu-ibris-dla-wydarzen-konfederacja-trac,nId,7032902)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:50:27+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/sondaze/news-przetasowania-w-sondazu-ibris-dla-wydarzen-konfederacja-trac,nId,7032902"><img align="left" alt="Przetasowania w sondażu IBRiS dla &quot;Wydarzeń&quot;. Konfederacja traci podium" src="https://i.iplsc.com/przetasowania-w-sondazu-ibris-dla-wydarzen-konfederacja-trac/000HOE0NUURBAIOW-C321.jpg" /></a>Prawo i Sprawiedliwość mogłoby liczyć na poparcie 32,6 proc. głosujących, jeśli wybory parlamentarne odbywały się w najbliższą niedzielę - wynika z najnowszego sondażu IBRiS dla &quot;Wydarzeń&quot; Polsatu. Na podium znalazła się Koalicja Obywatelska z rezultatem 26,6 proc. W przypadku formacji Jarosława Kaczyńskiego wynik jest minimalnie wyższy niż przed miesiącem, z kolei partia Donalda Tuska zanotowała czteropunktową stratę. Spada też poparcie Konfederacji, która z podium spada na piątą pozycję.
</p><br clear="all" />

## Gruzja na granicy zamachu stanu. Służby znalazły polski wątek
 - [https://wydarzenia.interia.pl/zagranica/news-gruzja-na-granicy-zamachu-stanu-sluzby-znalazly-polski-watek,nId,7032871](https://wydarzenia.interia.pl/zagranica/news-gruzja-na-granicy-zamachu-stanu-sluzby-znalazly-polski-watek,nId,7032871)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:20:16+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-gruzja-na-granicy-zamachu-stanu-sluzby-znalazly-polski-watek,nId,7032871"><img align="left" alt="Gruzja na granicy zamachu stanu. Służby znalazły polski wątek" src="https://i.iplsc.com/gruzja-na-granicy-zamachu-stanu-sluzby-znalazly-polski-watek/000HODSKPFYK0AD3-C321.jpg" /></a>- W trosce o bezpieczeństwo państwa i pokojowe współistnienie obywateli informujemy, że (...) pewna grupa osób działających na terytorium Gruzji i poza nim planuje zorganizowanie destabilizacji i zamieszek obywatelskich w Gruzji - poinofmorwał przedstawiciel Służby Bezpieczeństwa. Zdaniem śledczych na przełomie października i grudnia planowane jest przeprowadzenie powtórki z &quot;euromajdanu&quot; na Ukrainie.</p><br clear="all" />

## Nowa era przestępczości w Belgii. "Granat kupisz za 50 euro"
 - [https://wydarzenia.interia.pl/zagranica/news-nowa-era-przestepczosci-w-belgii-granat-kupisz-za-50-euro,nId,7032745](https://wydarzenia.interia.pl/zagranica/news-nowa-era-przestepczosci-w-belgii-granat-kupisz-za-50-euro,nId,7032745)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:10:21+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nowa-era-przestepczosci-w-belgii-granat-kupisz-za-50-euro,nId,7032745"><img align="left" alt="Nowa era przestępczości w Belgii. &quot;Granat kupisz za 50 euro&quot;" src="https://i.iplsc.com/nowa-era-przestepczosci-w-belgii-granat-kupisz-za-50-euro/000HOCUHL8E960L0-C321.jpg" /></a>- Nie możemy powiedzieć, że walka ze zorganizowanymi grupami przestępczymi jest skuteczna - powiedział w wywiadzie Michel Claise. Główny sędzia Belgii ostrzegł, że w przyszłości skutki nielegalnej działalności mogą być &quot;katastroficzne&quot;, a na ulicach coraz częściej będą ginąć niewinne osoby.</p><br clear="all" />

## Rewolucja na kolei w Czechach? Pociągi docierałyby do Polski
 - [https://wydarzenia.interia.pl/zagranica/news-rewolucja-na-kolei-w-czechach-pociagi-docieralyby-do-polski,nId,7032797](https://wydarzenia.interia.pl/zagranica/news-rewolucja-na-kolei-w-czechach-pociagi-docieralyby-do-polski,nId,7032797)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T10:01:37+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-rewolucja-na-kolei-w-czechach-pociagi-docieralyby-do-polski,nId,7032797"><img align="left" alt="Rewolucja na kolei w Czechach? Pociągi docierałyby do Polski" src="https://i.iplsc.com/rewolucja-na-kolei-w-czechach-pociagi-docieralyby-do-polski/000HODIMBBPLVLC0-C321.jpg" /></a>Czechy zastanawiają się nad decyzją o wprowadzeniu nowych połączeń kolejowych. Pociągi miałyby kursować przez siedmiokilometrowy tunel pod przełęczą, a szacuje się, że same maszyny mogłyby osiągnąć prędkość nawet do 150 km/h. Co więcej, zmiany na kolei objęłyby również trasę do Polski. Podróżujący jechaliby z Zabrehu przez Szumperk i Jesionik, a następnie docieraliby do granicy z naszym krajem.</p><br clear="all" />

## Na nartach już tu nie pojeżdżą. Wszystko przez globalne ocieplenie
 - [https://wydarzenia.interia.pl/zagranica/news-na-nartach-juz-tu-nie-pojezdza-wszystko-przez-globalne-ociep,nId,7032879](https://wydarzenia.interia.pl/zagranica/news-na-nartach-juz-tu-nie-pojezdza-wszystko-przez-globalne-ociep,nId,7032879)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:44:58+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-na-nartach-juz-tu-nie-pojezdza-wszystko-przez-globalne-ociep,nId,7032879"><img align="left" alt="Na nartach już tu nie pojeżdżą. Wszystko przez globalne ocieplenie" src="https://i.iplsc.com/na-nartach-juz-tu-nie-pojezdza-wszystko-przez-globalne-ociep/000HODSLMUGQCGCB-C321.jpg" /></a>Z narciarskiej mapy Europy znika popularny ośrodek narciarski. Wszystko z powodu niedoboru śniegu. Straty generowane przez działalność tego miejsca sięgały setek tysięcy euro rocznie, więc zdecydowano o jego zamknięciu. To kolejny francuski resort, który przegrywa z globalnym ociepleniem. Ocenia się, że w całym kraju w ciągu dwóch dekad zlikwidowano kilkadziesiąt wyciągów, a ponad sto obecnie nie funkcjonuje. Rosnące temperatury sprawiają, że sezon narciarski robi się coraz krótszy.</p><br clear="all" />

## Wojsko przejmuje drogę wojewódzką. Rozpoczyna się akcja ROUTE 604
 - [https://wydarzenia.interia.pl/kraj/news-wojsko-przejmuje-droge-wojewodzka-rozpoczyna-sie-akcja-route,nId,7032828](https://wydarzenia.interia.pl/kraj/news-wojsko-przejmuje-droge-wojewodzka-rozpoczyna-sie-akcja-route,nId,7032828)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:42:49+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wojsko-przejmuje-droge-wojewodzka-rozpoczyna-sie-akcja-route,nId,7032828"><img align="left" alt="Wojsko przejmuje drogę wojewódzką. Rozpoczyna się akcja ROUTE 604" src="https://i.iplsc.com/wojsko-przejmuje-droge-wojewodzka-rozpoczyna-sie-akcja-route/000HODD759XY1978-C321.jpg" /></a>Odcinek drogi wojewódzkiej nr 604 pomiędzy miejscowościami Ruskowo i Przeździęk Wielki na Warmii i Mazurach zostanie zamknięty do 3 października. Blokada związana jest z ćwiczeniami wojskowymi pod kryptonimem ROUTE 604.</p><br clear="all" />

## Tragedia na pokazie lotniczym. Nie żyje dwóch pilotów
 - [https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokazie-lotniczym-nie-zyje-dwoch-pilotow,nId,7032782](https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokazie-lotniczym-nie-zyje-dwoch-pilotow,nId,7032782)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:28:44+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-tragedia-na-pokazie-lotniczym-nie-zyje-dwoch-pilotow,nId,7032782"><img align="left" alt="Tragedia na pokazie lotniczym. Nie żyje dwóch pilotów" src="https://i.iplsc.com/tragedia-na-pokazie-lotniczym-nie-zyje-dwoch-pilotow/000HOD8YVPXITKFF-C321.jpg" /></a>Dwóch pilotów zginęło podczas zawodów lotniczych w USA. Do wypadku doszło podczas lądowania po zakończonym wyścigu. Organizator wydarzenia poinformował, że żaden z obecnych na miejscu widzów nie został ranny. Służby ustalają przyczyny tragedii. Wiadomo, że zmarli byli doświadczonymi i utytułowanymi lotnikami.</p><br clear="all" />

## Ukraina: Fala dymisji w ministerstwie obrony
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-fala-dymisji-w-ministerstwie-obrony,nId,7032844](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-fala-dymisji-w-ministerstwie-obrony,nId,7032844)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:16:25+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-ukraina-fala-dymisji-w-ministerstwie-obrony,nId,7032844"><img align="left" alt="Ukraina: Fala dymisji w ministerstwie obrony" src="https://i.iplsc.com/ukraina-fala-dymisji-w-ministerstwie-obrony/000HODEP1RRIAVJ6-C321.jpg" /></a>Rząd w Kijowie zdecydował odwołać ze stanowiska obrony narodowej wiceminister Hannę Malar oraz innych pięciu sekretarzy w resorcie - ustalił Reuters. To już kolejna dymisja w kluczowym z punktu widzenia kontrofensywy ministerstwie.   </p><br clear="all" />

## Zwrot w sprawie zaginięcia Michała po 23 latach. Minister daje słowo
 - [https://wydarzenia.interia.pl/podkarpackie/news-zwrot-w-sprawie-zaginiecia-michala-po-23-latach-minister-daj,nId,7032840](https://wydarzenia.interia.pl/podkarpackie/news-zwrot-w-sprawie-zaginiecia-michala-po-23-latach-minister-daj,nId,7032840)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:16:10+00:00

<p><a href="https://wydarzenia.interia.pl/podkarpackie/news-zwrot-w-sprawie-zaginiecia-michala-po-23-latach-minister-daj,nId,7032840"><img align="left" alt="Zwrot w sprawie zaginięcia Michała po 23 latach. Minister daje słowo" src="https://i.iplsc.com/zwrot-w-sprawie-zaginiecia-michala-po-23-latach-minister-daj/000HODCV1JORTVX0-C321.jpg" /></a>Wiceminister sprawiedliwości Marcin Warchoł zwróci się do prokuratura generalnego o zbadanie sprawy zaginięcia 16-letniego Michała Karasia. Nastolatek 23 lata temu wyszedł z domu i od tamtej pory nikt go nie widział. Prokuratura mimo upływu lat nigdy nie wszczęła postępowania w tej sprawie. - Jeśli tylko jest szansa wyjaśnić, co się stało z Michałem, to należy podjąć działania - mówi polityk w rozmowie z Interią. Historię zaginięcia chłopca opisaliśmy w Interii w sobotę.</p><br clear="all" />

## Ukraina odpowiada na przedłużenie embarga. Pozwie Polskę
 - [https://wydarzenia.interia.pl/zagranica/news-ukraina-odpowiada-na-przedluzenie-embarga-pozwie-polske,nId,7032820](https://wydarzenia.interia.pl/zagranica/news-ukraina-odpowiada-na-przedluzenie-embarga-pozwie-polske,nId,7032820)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T09:09:14+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-ukraina-odpowiada-na-przedluzenie-embarga-pozwie-polske,nId,7032820"><img align="left" alt="Ukraina odpowiada na przedłużenie embarga. Pozwie Polskę" src="https://i.iplsc.com/ukraina-odpowiada-na-przedluzenie-embarga-pozwie-polske/000HODDRXQV7FJGN-C321.jpg" /></a>Wiceminister ds. rozwoju gospodarczego i przedstawiciel Ukrainy w Światowej Organizacji Handlu Taras Kaczka zapowiedział, że jego kraj zamierza podjąć kroki prawne wobec Polski, Słowacji i Węgier - krajów, które jednostronnie przedłużyły zakaz importu ukraińskiego zboża. Procedura przed Światową Organizacją Handlu ma się rozpocząć jeszcze w poniedziałek 18 września.</p><br clear="all" />

## Dron z ładunkiem wybuchowym runął z nieba. Uderzył w bułgarskie wybrzeże
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-z-ladunkiem-wybuchowym-runal-z-nieba-uderzyl-w-bulgarsk,nId,7032830](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-z-ladunkiem-wybuchowym-runal-z-nieba-uderzyl-w-bulgarsk,nId,7032830)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:47:50+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-dron-z-ladunkiem-wybuchowym-runal-z-nieba-uderzyl-w-bulgarsk,nId,7032830"><img align="left" alt="Dron z ładunkiem wybuchowym runął z nieba. Uderzył w bułgarskie wybrzeże" src="https://i.iplsc.com/dron-z-ladunkiem-wybuchowym-runal-z-nieba-uderzyl-w-bulgarsk/000HODBCHREPFWD3-C321.jpg" /></a>Dron z ładunkiem wybuchowym spadł na wybrzeże jednego z kurortów w Bułgarii. O sprawie poinformowało tamtejsze Ministerstwo Obrony Narodowej. Nie wiadomo, czy bezzałogowiec należał do sił zbrojnych Ukrainy czy Rosji. Na miejscu pracuje jednostka saperska, która ma dezaktywować ładunek.</p><br clear="all" />

## Wypadek w Niemczech. 76-latka Polka uwięziona w pojeździe
 - [https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-latka-polka-uwieziona-w-pojezdzie,nId,7032775](https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-latka-polka-uwieziona-w-pojezdzie,nId,7032775)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:43:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wypadek-w-niemczech-76-latka-polka-uwieziona-w-pojezdzie,nId,7032775"><img align="left" alt="Wypadek w Niemczech. 76-latka Polka uwięziona w pojeździe" src="https://i.iplsc.com/wypadek-w-niemczech-76-latka-polka-uwieziona-w-pojezdzie/000HOCX20U8MHJBX-C321.jpg" /></a>Trzy osoby zostały ranne w wypadku drogowym, który miał miejsce w niedzielę w pobliżu Coppenbrügge w Niemczech na drodze krajowej nr 1. Auto, które powinno ustąpić pierwszeństwa przejazdu, prowadziła 76-letnia Polka. Kobieta wraz ze swoim 72-letnim pasażerem oraz kierowcą drugiego pojazdu zostali przetransportowani do szpitali.</p><br clear="all" />

## Białoruska propaganda o wyborach w Polsce. Wskazują na Polonię
 - [https://wydarzenia.interia.pl/zagranica/news-bialoruska-propaganda-o-wyborach-w-polsce-wskazuja-na-poloni,nId,7032783](https://wydarzenia.interia.pl/zagranica/news-bialoruska-propaganda-o-wyborach-w-polsce-wskazuja-na-poloni,nId,7032783)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:31:00+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-bialoruska-propaganda-o-wyborach-w-polsce-wskazuja-na-poloni,nId,7032783"><img align="left" alt="Białoruska propaganda o wyborach w Polsce. Wskazują na Polonię" src="https://i.iplsc.com/bialoruska-propaganda-o-wyborach-w-polsce-wskazuja-na-poloni/000HOD34XCWK4U1I-C321.jpg" /></a>- Po raz kolejny wybory (w Polsce - red.) zostaną sfałszowane - twierdzi Daniel Mikusek. Polak, przedstawiany przez białoruskie media reżimowe jako politolog, kolejny raz skomentował nadchodzące wybory parlamentarne i ich &quot;prawdopodobny&quot; wynik. </p><br clear="all" />

## NIK zawiadamia prokuraturę. Chodzi o działania Elżbiety Witek
 - [https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-chodzi-o-dzialania-elzbiety-witek,nId,7032805](https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-chodzi-o-dzialania-elzbiety-witek,nId,7032805)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:16:05+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nik-zawiadamia-prokurature-chodzi-o-dzialania-elzbiety-witek,nId,7032805"><img align="left" alt="NIK zawiadamia prokuraturę. Chodzi o działania Elżbiety Witek" src="https://i.iplsc.com/nik-zawiadamia-prokurature-chodzi-o-dzialania-elzbiety-witek/000HOD9WC4KIUQ4E-C321.jpg" /></a>Prezes Najwyższej Izby Kontroli Marian Banaś złożył zawiadomienie do prokuratury o możliwości popełnienia przestępstwa przez marszałek Sejmu Elżbietę Witek - podało RMF FM. W komunikacie NIK zaznaczono, że działania doprowadziły do &quot;uniemożliwienia funkcjonowania kolegium&quot;.</p><br clear="all" />

## Nie czekali ani sekundy. Plażowicze uratowali rekina
 - [https://wydarzenia.interia.pl/zagranica/news-nie-czekali-ani-sekundy-plazowicze-uratowali-rekina,nId,7032736](https://wydarzenia.interia.pl/zagranica/news-nie-czekali-ani-sekundy-plazowicze-uratowali-rekina,nId,7032736)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:09:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-nie-czekali-ani-sekundy-plazowicze-uratowali-rekina,nId,7032736"><img align="left" alt="Nie czekali ani sekundy. Plażowicze uratowali rekina" src="https://i.iplsc.com/nie-czekali-ani-sekundy-plazowicze-uratowali-rekina/000HOCU5LAL8C3DM-C321.jpg" /></a>Dwumetrowy rekin utknął na plaży na Florydzie w USA. Plażowicze, którzy zauważyli miotające się w panice zwierzę, ruszyli na pomoc. &quot;Mimo obaw z powodu wcześniejszych ataków, nie mogli pozostać obojętni&quot; - komentuje serwis Nature Realm, który udostępnił nagranie z dramatycznej akcji ratunkowej.</p><br clear="all" />

## Wybuch granatnika Jarosława Szymczyka. Ujawniono zdjęcia
 - [https://wydarzenia.interia.pl/kraj/news-wybuch-granatnika-jaroslawa-szymczyka-ujawniono-zdjecia,nId,7032793](https://wydarzenia.interia.pl/kraj/news-wybuch-granatnika-jaroslawa-szymczyka-ujawniono-zdjecia,nId,7032793)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T08:05:06+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-wybuch-granatnika-jaroslawa-szymczyka-ujawniono-zdjecia,nId,7032793"><img align="left" alt="Wybuch granatnika Jarosława Szymczyka. Ujawniono zdjęcia" src="https://i.iplsc.com/wybuch-granatnika-jaroslawa-szymczyka-ujawniono-zdjecia/000HOD9NHGV0E0T5-C321.jpg" /></a>&quot;Ujawniam najbardziej strzeżoną tajemnicę państwa PiS. Te zdjęcia nigdy nie miały ujrzeć światła dziennego&quot; - napisał w mediach społecznościowych senator KO Krzysztof Brejza. Polityk zamieścił cztery fotografie pokazujące zniszczenia w budynku Komendy Głównej Policji po eksplozji z grudnia 2022 r. Widać na nim granatnik, a także zniszczone pomieszczenie.
</p><br clear="all" />

## Francuska kandydatka oszukała wyborców? Na plakacie jest nie do poznania
 - [https://wydarzenia.interia.pl/zagranica/news-francuska-kandydatka-oszukala-wyborcow-na-plakacie-jest-nie-,nId,7032749](https://wydarzenia.interia.pl/zagranica/news-francuska-kandydatka-oszukala-wyborcow-na-plakacie-jest-nie-,nId,7032749)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:52:23+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-francuska-kandydatka-oszukala-wyborcow-na-plakacie-jest-nie-,nId,7032749"><img align="left" alt="Francuska kandydatka oszukała wyborców? Na plakacie jest nie do poznania" src="https://i.iplsc.com/francuska-kandydatka-oszukala-wyborcow-na-plakacie-jest-nie/000HOCXFNUEESRKI-C321.jpg" /></a>Kandydatka do francuskiego Senatu poprosiła sztuczną inteligencję o taki retusz jej zdjęcia, by było bardziej atrakcyjne dla proeuropejskich wyborców z klasy średniej. Efekt? Natychmiastowy wzrost poparcia w sondażach.</p><br clear="all" />

## Trzecia Droga rezygnuje z marszu 1 października. "Nie ma co konkurować"
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-trzecia-droga-rezygnuje-z-marszu-1-pazdziernika-nie-ma-co-ko,nId,7032779](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-trzecia-droga-rezygnuje-z-marszu-1-pazdziernika-nie-ma-co-ko,nId,7032779)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:52:04+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-trzecia-droga-rezygnuje-z-marszu-1-pazdziernika-nie-ma-co-ko,nId,7032779"><img align="left" alt="Trzecia Droga rezygnuje z marszu 1 października. &quot;Nie ma co konkurować&quot;" src="https://i.iplsc.com/trzecia-droga-rezygnuje-z-marszu-1-pazdziernika-nie-ma-co-ko/000HOCX9NNCQN4NW-C321.jpg" /></a>Liderzy Trzeciej Drogi Władysław Kosiniak-Kamysz oraz Szymon Hołownia nie wezmą udziału w zapowiadanym na 1 października &quot;Marszu miliona serc&quot;. Demonstrację w centrum Warszawy przygotowuje Koalicja Obywatelska. - Nie ma co konkurować, jeżeli ktoś sobie organizuje wspaniałe wydarzenie, to trzeba to uszanować - mówi prezes Ludowców. </p><br clear="all" />

## Sukces Ukraińców. Dowódca elitarnej jednostki zginął w walkach
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukraincow-dowodca-elitarnej-jednostki-zginal-w-walkac,nId,7032723](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukraincow-dowodca-elitarnej-jednostki-zginal-w-walkac,nId,7032723)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:43:52+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-sukces-ukraincow-dowodca-elitarnej-jednostki-zginal-w-walkac,nId,7032723"><img align="left" alt="Sukces Ukraińców. Dowódca elitarnej jednostki zginął w walkach" src="https://i.iplsc.com/sukces-ukraincow-dowodca-elitarnej-jednostki-zginal-w-walkac/000HOCOCHI6DBHGW-C321.jpg" /></a>Pojawiły się doniesienia o śmierci pułkownika Andrieja Kondraszkina, dowódcy elitarnej 31. Powietrznodesantowej Brygady Szturmowej. Rosyjski wojskowy odegrał kluczową rolę w krwawym podboju Mariupola przez Rosję w 2022 r. Według pojawiających się informacji Kondraszkin zginął w wyniku ukraińskiego uderzenia. Przed śmiercią dowodził odpieraniem ataków sił ukraińskich na południe od wsi Andrijiwka.</p><br clear="all" />

## Wyjątkowe odkrycie archeologów. Złote monety sprzed ery wikingów
 - [https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-odkrycie-archeologow-zlote-monety-sprzed-ery-wikin,nId,7032761](https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-odkrycie-archeologow-zlote-monety-sprzed-ery-wikin,nId,7032761)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:42:19+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-wyjatkowe-odkrycie-archeologow-zlote-monety-sprzed-ery-wikin,nId,7032761"><img align="left" alt="Wyjątkowe odkrycie archeologów. Złote monety sprzed ery wikingów" src="https://i.iplsc.com/wyjatkowe-odkrycie-archeologow-zlote-monety-sprzed-ery-wikin/000HOCS0AHI57LC0-C321.jpg" /></a>35 złotych monet pochodzących z okresu Merowingów, czyli około 550 roku naszej ery, odkryli norwescy archeolodzy w pobliżu miejscowości Vingrom pod Lillehammer. Jak podkreślono, odkrycie obala część mitów dotyczących historii tamtejszych miejsc kultu.</p><br clear="all" />

## "Tajemnicze zgony" wśród rosyjskich żołnierzy. Znów w Mariupolu
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tajemnicze-zgony-wsrod-rosyjskich-zolnierzy-znow-w-mariupolu,nId,7032716](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tajemnicze-zgony-wsrod-rosyjskich-zolnierzy-znow-w-mariupolu,nId,7032716)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:31:21+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-tajemnicze-zgony-wsrod-rosyjskich-zolnierzy-znow-w-mariupolu,nId,7032716"><img align="left" alt="&quot;Tajemnicze zgony&quot; wśród rosyjskich żołnierzy. Znów w Mariupolu" src="https://i.iplsc.com/tajemnicze-zgony-wsrod-rosyjskich-zolnierzy-znow-w-mariupolu/000AUSPJ3RLON87A-C321.jpg" /></a>Siły rosyjskie odnotowały straty w swoich szeregach w Mariupolu, gdzie &quot;tajemniczą śmierć&quot; poniosło 11 żołnierzy, w tym dwóch oficerów. Powodem śmierci okupantów miało być nagłe zatrzymanie krążenia, a strona rosyjska podejrzewa, że mogło dojść do otrucia. To nie pierwszy raz, kiedy z Mariupola napływają informacje o &quot;tajemniczych&quot; zgonach.</p><br clear="all" />

## Amerykański pilot zgubił F-35. Nie ma śladu po maszynie
 - [https://wydarzenia.interia.pl/zagranica/news-amerykanski-pilot-zgubil-f-35-nie-ma-sladu-po-maszynie,nId,7032740](https://wydarzenia.interia.pl/zagranica/news-amerykanski-pilot-zgubil-f-35-nie-ma-sladu-po-maszynie,nId,7032740)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:08:56+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-amerykanski-pilot-zgubil-f-35-nie-ma-sladu-po-maszynie,nId,7032740"><img align="left" alt="Amerykański pilot zgubił F-35. Nie ma śladu po maszynie " src="https://i.iplsc.com/amerykanski-pilot-zgubil-f-35-nie-ma-sladu-po-maszynie/000HOCM9GTQ95X8C-C321.jpg" /></a>W Karolinie Południowej trwają poszukiwania myśliwca F-35B Lightning II, który uległ &quot;nieszczęśliwemu wypadkowi&quot;. Pilot zdążył się katapultować, jednak do tej pory nie udało się odnaleźć maszyny. Zaapelowano do lokalnej społeczności, aby osoby &quot;posiadające jakiekolwiek informacje&quot; pomogły w zlokalizowaniu samolotu.</p><br clear="all" />

## Nowy trop w sprawie Krzysztofa Dymińskiego. Matka publikuje film
 - [https://wydarzenia.interia.pl/kraj/news-nowy-trop-w-sprawie-krzysztofa-dyminskiego-matka-publikuje-f,nId,7032756](https://wydarzenia.interia.pl/kraj/news-nowy-trop-w-sprawie-krzysztofa-dyminskiego-matka-publikuje-f,nId,7032756)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T07:08:36+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-nowy-trop-w-sprawie-krzysztofa-dyminskiego-matka-publikuje-f,nId,7032756"><img align="left" alt="Nowy trop w sprawie Krzysztofa Dymińskiego. Matka publikuje film" src="https://i.iplsc.com/nowy-trop-w-sprawie-krzysztofa-dyminskiego-matka-publikuje-f/000HOCQ99QYL4SMS-C321.jpg" /></a>Niedługo miną cztery miesiące od momentu zaginięcia 16-letniego Krzysztofa Dymińskiego. Przez cały ten czas rodzice nastolatka robią wszystko, by sprowadzić syna do domu. W ostatnich dniach w sprawie pojawił się nowy trop. Matka Krzysztofa Dymińskiego dostała nagranie, które przedstawia osobę łudząco podobną do nastolatka. Kobieta zwróciła się także z apelem do internautów.</p><br clear="all" />

## Zwrot Węgier ws. Szwecji w NATO: Nie potrzebujemy takiego sojusznika
 - [https://wydarzenia.interia.pl/zagranica/news-zwrot-wegier-ws-szwecji-w-nato-nie-potrzebujemy-takiego-soju,nId,7032708](https://wydarzenia.interia.pl/zagranica/news-zwrot-wegier-ws-szwecji-w-nato-nie-potrzebujemy-takiego-soju,nId,7032708)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T06:52:27+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zwrot-wegier-ws-szwecji-w-nato-nie-potrzebujemy-takiego-soju,nId,7032708"><img align="left" alt="Zwrot Węgier ws. Szwecji w NATO: Nie potrzebujemy takiego sojusznika" src="https://i.iplsc.com/zwrot-wegier-ws-szwecji-w-nato-nie-potrzebujemy-takiego-soju/000HOCD8YUGQCIKD-C321.jpg" /></a>Budapeszt może jeszcze bardziej opóźnić akcesję Sztokholmu do Sojuszu Północnoatlantyckiego. - Nie jest pewne, że musimy głosować za przystąpieniem Szwecji do NATO - ocenił marszałek Zgromadzenia Krajowego Laszlo Kover w telewizyjnym wywiadzie. I krytykuje Skandynawów za publikację filmiku zwracającego uwagę na problemy z demokracją nad Dunajem.</p><br clear="all" />

## Zaskakująca oferta z Białorusi. Proponują wspólne ćwiczenia z Polską
 - [https://wydarzenia.interia.pl/zagranica/news-zaskakujaca-oferta-z-bialorusi-proponuja-wspolne-cwiczenia-z,nId,7032697](https://wydarzenia.interia.pl/zagranica/news-zaskakujaca-oferta-z-bialorusi-proponuja-wspolne-cwiczenia-z,nId,7032697)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T06:28:45+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-zaskakujaca-oferta-z-bialorusi-proponuja-wspolne-cwiczenia-z,nId,7032697"><img align="left" alt="Zaskakująca oferta z Białorusi. Proponują wspólne ćwiczenia z Polską" src="https://i.iplsc.com/zaskakujaca-oferta-z-bialorusi-proponuja-wspolne-cwiczenia-z/000HOCA54B8AQTW6-C321.jpg" /></a>Zastępca szefa Rady Bezpieczeństwa Białorusi twierdzi, że Mińsk wspólnie z Warszawą mogłyby przeprowadzić ćwiczenia wojskowe. - Z radością podjęlibyśmy taką inicjatywę - powiedział Paweł Murawiejko. Tymczasem Alaksandr Łukaszenka ocenił, że Polska &quot;nie doceniła szlachetnego pragnienia życia w pokoju&quot;.</p><br clear="all" />

## Zełenski o kontrofensywie Ukrainy. "Będę z wami całkowicie szczery"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-o-kontrofensywie-ukrainy-bede-z-wami-calkowicie-szc,nId,7032727](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-o-kontrofensywie-ukrainy-bede-z-wami-calkowicie-szc,nId,7032727)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T06:19:49+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-zelenski-o-kontrofensywie-ukrainy-bede-z-wami-calkowicie-szc,nId,7032727"><img align="left" alt="Zełenski o kontrofensywie Ukrainy. &quot;Będę z wami całkowicie szczery&quot;" src="https://i.iplsc.com/zelenski-o-kontrofensywie-ukrainy-bede-z-wami-calkowicie-szc/000HOCHSFO2CHH0I-C321.jpg" /></a>- Zatrzymaliśmy rosyjską ofensywę i przystąpiliśmy do kontrofensywy. A mimo to nie jest ona zbyt szybka - mówił Wołodymyr Zełenski. Prezydent Ukrainy skomentował powolne postępy trwającej ukraińskiej kontrofensywy i pojawiające się negatywne komentarze dotyczące sposobu walki Sił Zbrojnych Ukrainy.</p><br clear="all" />

## Kłęby dymu w stolicy Sudanu. Najsłynniejszy wieżowiec stolicy w ogniu
 - [https://wydarzenia.interia.pl/zagranica/news-kleby-dymu-w-stolicy-sudanu-najslynniejszy-wiezowiec-stolicy,nId,7031341](https://wydarzenia.interia.pl/zagranica/news-kleby-dymu-w-stolicy-sudanu-najslynniejszy-wiezowiec-stolicy,nId,7031341)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T06:11:02+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-kleby-dymu-w-stolicy-sudanu-najslynniejszy-wiezowiec-stolicy,nId,7031341"><img align="left" alt="Kłęby dymu w stolicy Sudanu. Najsłynniejszy wieżowiec stolicy w ogniu" src="https://i.iplsc.com/kleby-dymu-w-stolicy-sudanu-najslynniejszy-wiezowiec-stolicy/000HOCCXBL1F0S0M-C321.jpg" /></a>Jeden z najbardziej charakterystycznych wieżowców stolicy Sudanu stanął w niedzielę w ogniu. Greater Nile Petroleum Oil Company w Chartumie zapłonął prawdopodobnie na skutek walk toczonych między armią a Siłami Szybkiego Wsparcia.</p><br clear="all" />

## Najnowszy sondaż o aferze wizowej. Czy zaszkodzi PiS?
 - [https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-najnowszy-sondaz-o-aferze-wizowej-czy-zaszkodzi-pis,nId,7032704](https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-najnowszy-sondaz-o-aferze-wizowej-czy-zaszkodzi-pis,nId,7032704)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T06:00:29+00:00

<p><a href="https://wydarzenia.interia.pl/raport-wybory-parlamentarne-2023/news-najnowszy-sondaz-o-aferze-wizowej-czy-zaszkodzi-pis,nId,7032704"><img align="left" alt="Najnowszy sondaż o aferze wizowej. Czy zaszkodzi PiS?" src="https://i.iplsc.com/najnowszy-sondaz-o-aferze-wizowej-czy-zaszkodzi-pis/000HB0UFA88HQA62-C321.jpg" /></a>Prawie 40 proc. badanych uważa, że tzw. afera wizowa nie będzie miała wpływu na wynik PiS w wyborach - wynika z najnowszego sondażu IBRiS. O tym, że sprawa wpłynie negatywnie na wynik, jest przekonanych ponad 30 proc. respondentów. 21,4 proc. badanych przyznało z kolei, że nie słyszało nic o tzw. aferze wizowej.</p><br clear="all" />

## Prezydent w Nowym Jorku. "Możemy mieć drugą armię w Europie"
 - [https://wydarzenia.interia.pl/kraj/news-prezydent-w-nowym-jorku-mozemy-miec-druga-armie-w-europie,nId,7031357](https://wydarzenia.interia.pl/kraj/news-prezydent-w-nowym-jorku-mozemy-miec-druga-armie-w-europie,nId,7031357)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T05:06:16+00:00

<p><a href="https://wydarzenia.interia.pl/kraj/news-prezydent-w-nowym-jorku-mozemy-miec-druga-armie-w-europie,nId,7031357"><img align="left" alt="Prezydent w Nowym Jorku. &quot;Możemy mieć drugą armię w Europie&quot;" src="https://i.iplsc.com/prezydent-w-nowym-jorku-mozemy-miec-druga-armie-w-europie/000HOB37XD27UP1X-C321.jpg" /></a>- Wierzę, że Polska będzie wkrótce miała drugą lub trzecią najsilniejszą armię w Europie - powiedział prezydent Andrzej Duda podczas spotkania z Polonią w Nowym Jorku. Przekonywał, że nasz kraj jest nie tylko odbiorcą militarnego wsparcia, ale także je zapewnia. </p><br clear="all" />

## Szef MSZ o aferze wizowej: Nie czuję się współwinny, nie rozważam dymisji
 - [https://wydarzenia.interia.pl/zagranica/news-szef-msz-o-aferze-wizowej-nie-czuje-sie-wspolwinny-nie-rozwa,nId,7032695](https://wydarzenia.interia.pl/zagranica/news-szef-msz-o-aferze-wizowej-nie-czuje-sie-wspolwinny-nie-rozwa,nId,7032695)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T04:31:36+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-szef-msz-o-aferze-wizowej-nie-czuje-sie-wspolwinny-nie-rozwa,nId,7032695"><img align="left" alt="Szef MSZ o aferze wizowej: Nie czuję się współwinny, nie rozważam dymisji" src="https://i.iplsc.com/szef-msz-o-aferze-wizowej-nie-czuje-sie-wspolwinny-nie-rozwa/000HOC7HUMJTI3YJ-C321.jpg" /></a>- Nie czuję się współwinny, nie rozważam podania się do dymisji i nie ma żadnej afery wizowej - mówił przebywający w Nowym Jorku szef MSZ Zbigniew Rau, odnosząc się do afery wizowej. - Jeśli to jest afera stulecia, to ja wolę mówić o kaskadzie fake newsów - dodał. Rau został również zapytany o kwestię dokumentu, który w niedzielę został odtajniony przez ministra obrony narodowej Mariusza Błaszczaka.</p><br clear="all" />

## Trump dostał pochwały od Putina. "Podoba mi się to"
 - [https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trump-dostal-pochwaly-od-putina-podoba-mi-sie-to,nId,7031330](https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trump-dostal-pochwaly-od-putina-podoba-mi-sie-to,nId,7031330)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T04:24:54+00:00

<p><a href="https://wydarzenia.interia.pl/raport-ukraina-rosja/news-trump-dostal-pochwaly-od-putina-podoba-mi-sie-to,nId,7031330"><img align="left" alt="Trump dostał pochwały od Putina. &quot;Podoba mi się to&quot;" src="https://i.iplsc.com/trump-dostal-pochwaly-od-putina-podoba-mi-sie-to/000HOAOTEG7MKY6Y-C321.jpg" /></a>Były prezydent Donald Trump udzielił wywiadu dla telewizji NBC News. Polityk wyraził uznanie dla słów, jakie skierował pod jego adresem Władimir Putin. - Bo to oznacza, że ​​to, co mówię, jest prawdą. Zabrałbym go do pokoju. Zabrałbym Zełenskiego do pokoju. Potem zebrałbym ich i miałbym wynegocjowaną umowę - mówił Trump o swoim planie zakończenia konfliktu na Ukrainie.</p><br clear="all" />

## Niespokojnie wokół Tajwanu. Ponad 100 chińskich samolotów "nękało" wyspę
 - [https://wydarzenia.interia.pl/zagranica/news-niespokojnie-wokol-tajwanu-ponad-100-chinskich-samolotow-nek,nId,7032691](https://wydarzenia.interia.pl/zagranica/news-niespokojnie-wokol-tajwanu-ponad-100-chinskich-samolotow-nek,nId,7032691)
 - RSS feed: https://wydarzenia.interia.pl/feed
 - date published: 2023-09-18T03:49:10+00:00

<p><a href="https://wydarzenia.interia.pl/zagranica/news-niespokojnie-wokol-tajwanu-ponad-100-chinskich-samolotow-nek,nId,7032691"><img align="left" alt="Niespokojnie wokół Tajwanu. Ponad 100 chińskich samolotów &quot;nękało&quot; wyspę" src="https://i.iplsc.com/niespokojnie-wokol-tajwanu-ponad-100-chinskich-samolotow-nek/0007DSJLBCT2RSO1-C321.jpg" /></a>W ciągu ostatnich 24 godzin wokół Tajwanu wykryto 103 chińskie samoloty bojowe, &quot;co stanowi najwyższą w ostatnim czasie liczbę&quot;. Zaobserwowano również dziewięć okrętów. Ministerstwo obrony wyspy podało, że 40 maszyn przekroczyło medianę Cieśniny Tajwańskiej, a działania Chin nazwano &quot;nękaniem&quot;.</p><br clear="all" />

