# Source:GameSpot, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw, language:en-US

## Historian & Armor Expert Reacts to Warhaven's Arms & Armor
 - [https://www.youtube.com/watch?v=S7oyXIeJWHg](https://www.youtube.com/watch?v=S7oyXIeJWHg)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-25T16:00:30+00:00

In this episode of Expert Reacts, brought to you by Warhaven, Armour Expert Toby Capwell breaks down some of the weapons and armor featured in Nexon's new free-to-play medieval-fantasy warfare game. 
Warhaven is launching into Early Access on Steam for Windows PCs on September 20 at 6pm PST / September 21st 3am CEST / 10am KST.

Intro: 00:00
Opening Cutscene: 0:29
Blade: 3:16
The Lionhearted: 7:01
Darkgale: 7:47
Guardian: 9:25
Hush: 11:37
Martyr: 12:10
Smoke: 14:19
Spike: 15:32
Warhammer: 18:39
__

Toby's Instagram: https://www.instagram.com/tobiascapwell/ 

Check out Toby's books: https://www.olympiaauctions.com/about-us/publications/armour-of-the-english-knight-1400-1450-by-tobias-capwell/
 https://www.olympiaauctions.com/about-us/publications/armour-of-the-english-knight-1450-1500-by-tobias-capwell/
 https://www.olympiaauctions.com/about-us/publications/armour-of-the-english-knight-continental-armour-in-england-1435-1500-by-tobias-capwell/ 

All about Tobias: https://independent.a

## Cyberpunk 2077: Phantom Liberty — Official Launch Trailer
 - [https://www.youtube.com/watch?v=jCo-Fc3PGGo](https://www.youtube.com/watch?v=jCo-Fc3PGGo)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-25T13:53:28+00:00

Gear up, Agents! It’s time for the Cyberpunk 2077: Phantom Liberty Launch Trailer!

Get ready to play — and try not to get played.

#PhantomLiberty is an upcoming spy-thriller expansion for #Cyberpunk2077. Return as cyber-enhanced mercenary V and embark on a high-stakes mission of espionage and intrigue to save the NUSA President. In the dangerous district of Dogtown, you must forge alliances within a web of shattered loyalties and sinister political machinations. Do you have what it takes to survive?

Cyberpunk 2077: Phantom Liberty is available for Xbox Series X|S, PlayStation 5, and PC.

## Cyberpunk 2077: Phantom Liberty - 12 Things I Wish I Knew
 - [https://www.youtube.com/watch?v=wYge81fU5co](https://www.youtube.com/watch?v=wYge81fU5co)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCbu2SsF-Or3Rsn3NxqODImw
 - date published: 2023-09-25T11:00:45+00:00

Phantom Liberty and the Cyberpunk 2.0 patch offer a lot of new cyberware, quickhacks, vehicles, skills, and high-tier loot for you to play with. Here’s what you should know before entering Night City’s new area, Dogtown.

Cyberpunk 2077: Phantom Liberty is an essential expansion earning a 10/10 on GameSpot. That means your new adventure with Idris Elba as Solomon Reed, Keanu Reeves as Johnny Silverhand, and expert netrunner Songbird is going to be great. There is a ton to catch you up on with a new relic-based skill tree, changes or enhancements to cyberware such as monowire and mantis blades, and a new car combat system. 
In this video, we’re going over how to start Phantom Liberty from the base game regardless of whether you’ve completed the main story or fired up a new playthrough. We’re covering how to navigate the new relic tree and what gear and skills to pair together for powerful builds. We’ll tell you how to immediately find high-tiered loot at emergency caches and around ar

