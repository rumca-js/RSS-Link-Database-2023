# Source:Forsal.pl, URL:https://forsal.pl/.feed, language:pl-PL

## Rządowy dekret o pomocy w wysokości 1,3 mld euro dla włoskich rodzin w ramach walki z drożyzną
 - [https://forsal.pl/swiat/artykuly/9307307,rzadowy-dekret-o-pomocy-w-wysokosci-13-mld-euro-dla-wloskich-rodzin-w.html](https://forsal.pl/swiat/artykuly/9307307,rzadowy-dekret-o-pomocy-w-wysokosci-13-mld-euro-dla-wloskich-rodzin-w.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T19:35:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/uuWktkuTURBXy9hODIzZGUxMC1jY2IzLTQ1MGQtOGZhYS1iNTU4NTM5NjQyZTQuanBlZ5GTBc0BHcyg" />Rząd Włoch przyjął pakiet pomocy w wysokości 1,3 mld euro w ramach wsparcia dla rodzin w związku z podwyżkami cen energii oraz paliw, a także w celu wzmocnienia siły nabywczej pieniądza i ochrony oszczędności - poinformowała Ansa po poniedziałkowym posiedzeniu gabinetu.

## Dwa myśliwce F-35 w Polsce zostały poderwane. Musiały przechwycić niezidentyfikowane samoloty
 - [https://forsal.pl/swiat/bezpieczenstwo/artykuly/9307177,dwa-mysliwce-f-35-w-polsce-zostaly-poderwane-musialy-przechwycic-niez.html](https://forsal.pl/swiat/bezpieczenstwo/artykuly/9307177,dwa-mysliwce-f-35-w-polsce-zostaly-poderwane-musialy-przechwycic-niez.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T17:45:42+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/w0NktkuTURBXy81MzhjOTlmZi0wMTQ2LTQwYzQtYmM3OC05MjdlOGFiY2E1OTkuanBlZ5GTBc0BHcyg" />Dwa myśliwce F-35 sił powietrznych Włoch, stacjonujące w Polsce w ramach operacji zabezpieczenia przestrzeni powietrznej państw NATO, zostały poderwane, by przechwycić niezidentyfikowane samoloty, prawdopodobnie rosyjskie - poinformowała w poniedziałek agencja Ansa. Jak wyjaśniła, zdarzenie to miało miejsce 21 września.

## Wojna w Ukrainie. Ukraińcy odparli rosyjskie kontrataki
 - [https://forsal.pl/swiat/ukraina/artykuly/9307081,wojna-w-ukrainie-ukraincy-odparli-rosyjskie-kontrataki.html](https://forsal.pl/swiat/ukraina/artykuly/9307081,wojna-w-ukrainie-ukraincy-odparli-rosyjskie-kontrataki.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T16:49:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/vFektkuTURBXy83NDU4N2JmZC0zNmIyLTQ3MTEtOTU5Mi01OWQ2MTZmNzE5OWIuanBlZ5GTBc0BHcyg" />W ostatnim tygodniu siły rosyjskie podjęły skoordynowane próby przeprowadzenia lokalnych kontrataków przeciw nacierającym siłom ukraińskim w sektorach Orichiwa i Bachmutu, ale Ukraińcy je odparli i utrzymali niedawno wyzwolone tereny - podało w poniedziałek brytyjskie ministerstwo obrony.

## Tusk: Jesteśmy dzisiaj w momencie zwrotnym. Rozstrzyga się znowu los Polski w tej części świata
 - [https://forsal.pl/gospodarka/polityka/artykuly/9307080,tusk-jestesmy-dzisiaj-w-momencie-zwrotnym-rozstrzyga-sie-znowu-los-p.html](https://forsal.pl/gospodarka/polityka/artykuly/9307080,tusk-jestesmy-dzisiaj-w-momencie-zwrotnym-rozstrzyga-sie-znowu-los-p.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T16:47:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yyJktkuTURBXy9jZjc4MDg4Zi1mZTVmLTRkYmUtOWI1MS1jNDVhNzE1MmZhMzYuanBlZ5GTBc0BHcyg" />My jesteśmy dzisiaj w momencie zwrotnym. Dzisiaj, na te trzy tygodnie przed wyborami, rozstrzyga się znowu los Polski w tej części świata - powiedział w poniedziałek podczas spotkania z mieszkańcami Otwocka (woj. mazowieckie) przewodniczący PO Donald Tusk.

## Korea Płn. otworzyła swoje granice po trzech latach izolacji spowodowanej Covid-19
 - [https://forsal.pl/swiat/artykuly/9307076,korea-pln-otworzyla-swoje-granice-po-trzech-latach-izolacji-spowodowa.html](https://forsal.pl/swiat/artykuly/9307076,korea-pln-otworzyla-swoje-granice-po-trzech-latach-izolacji-spowodowa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T16:45:37+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/WzUktkuTURBXy82NmIxNDZmMC1iMTUzLTQyMzUtODQ5MS1mMWMxNWQ0NWU0YjIuanBlZ5GTBc0BHcyg" />Korea Północna zdecydowała się otworzyć swoje granice po trzech latach izolacji kraju, spowodowanej pandemią Covid-19 – podała w poniedziałek chińska telewizja państwowa CCTV.

## Gaz na europejskim rynku w poniedziałek drożeje w granicach 11 proc.
 - [https://forsal.pl/finanse/notowania/artykuly/9306967,gaz-na-europejskim-rynku-w-poniedzialek-drozeje-w-granicach-11-proc.html](https://forsal.pl/finanse/notowania/artykuly/9306967,gaz-na-europejskim-rynku-w-poniedzialek-drozeje-w-granicach-11-proc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T15:47:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hWRktkuTURBXy84MWFkNGQ2Mi1hNjEwLTRmNDQtYTg4MC1lYTRmZWU3ZTA0ZWQuanBlZ5GTBc0BHcyg" />Gaz w holenderskim hubie TTF w poniedziałek drożeje. Najbardziej, o ponad 11 proc. podrożały kontrakty na gaz z dostawą w październiku, wyceniane na ponad 44 euro za MWh.

## MON podpisał umowę offsetową z Lockheed Martin w ramach zakupu śmigłowców Apache
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306966,mon-podpisal-umowe-offsetowa-z-lockheed-martin-w-ramach-zakupu-smiglow.html](https://forsal.pl/gospodarka/polityka/artykuly/9306966,mon-podpisal-umowe-offsetowa-z-lockheed-martin-w-ramach-zakupu-smiglow.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T15:45:30+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/HP-ktkuTURBXy9iM2MyYWMzYS0wZjIzLTRjNTctYWVhYy02ZGU0NmZiNjE1YjEuanBlZ5GTBc0BHcyg" />Minister obrony Mariusz Błaszczak podpisał w poniedziałek w Mesie w stanie Arizona umowę offsetową z koncernem Lockheed Martin, związaną z zakupem śmigłowców Apache. Umowa zakłada powstanie centrum serwisowego śmigłowców w Bydgoszczy.

## USA pożyczyły Polsce 2 mld dol. Skorzysta wojsko
 - [https://forsal.pl/gospodarka/artykuly/9306952,usa-pozyczyly-polsce-2-mld-dol-skorzysta-wojsko.html](https://forsal.pl/gospodarka/artykuly/9306952,usa-pozyczyly-polsce-2-mld-dol-skorzysta-wojsko.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T15:10:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Q9AktkuTURBXy9jNzQ2MDk1ZC03NDBhLTRjMzctYWJiYS0yNmI4ZjJjOWJlZDQuanBlZ5GTBc0BHcyg" />Stany Zjednoczone udzieliły w poniedziałek Polsce pożyczki bezpośredniej o wartości 2 miliardów dolarów w ramach zagranicznego finansowania wojskowego (FMF) w celu wsparcia modernizacji polskiej obronności - poinformował Departament Stanu USA.

## MF podnosi marże obligacji 2-letnich pomimo obniżenia stóp przez NBP
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9306928,mf-podnosi-marze-obligacji-2-letnich-pomimo-obnizenia-stop-przez-nbp.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9306928,mf-podnosi-marze-obligacji-2-letnich-pomimo-obnizenia-stop-przez-nbp.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T14:33:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/jsEktkuTURBXy8zODczMWE2NS0zYzc1LTQxMjUtOGY1Yi0wNTZhZTA4ZDU5MDAuanBlZ5GTBc0BHcyg" />Ministerstwo Finansów podniosło preferencyjną marżę październikowych obligacji 2-letnich, których oprocentowanie wynika ze stopy referencyjnej NBP i marże dla obligacji 4-, 6-, 10 i 12-letnich, których oprocentowanie uzależnione jest od inflacji - poinformował w poniedziałek resort.

## Okrutne tortury Rosjan w Ukrainie. Ofiary zamęczone na śmierć
 - [https://forsal.pl/swiat/ukraina/artykuly/9306922,okrutne-tortury-rosjan-w-ukrainie-ofiary-zameczone-na-smierc.html](https://forsal.pl/swiat/ukraina/artykuly/9306922,okrutne-tortury-rosjan-w-ukrainie-ofiary-zameczone-na-smierc.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T14:28:33+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/-HzktkuTURBXy84MGUzNzNhZC0yODQ5LTRmODUtOWE5Zi1lMWJlODZlYzJmZmYuanBlZ5GTBc0BHcyg" />Stosowane przez Rosjan metody tortur na okupowanych przez nich terytoriach Ukrainy były tak brutalne, że niektóre z ofiar zamęczono na śmierć - oświadczył w poniedziałek w Genewie Erik Mose, przewodniczący komisji śledczej ds. Ukrainy działającej pod mandatem ONZ.

## Ukraina: W naszych atakach na Sewastopol zginął dowódca Floty Czarnomorskiej
 - [https://forsal.pl/swiat/ukraina/artykuly/9306866,ukraina-w-naszych-atakach-na-sewastopol-zginal-dowodca-floty-czarnomo.html](https://forsal.pl/swiat/ukraina/artykuly/9306866,ukraina-w-naszych-atakach-na-sewastopol-zginal-dowodca-floty-czarnomo.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T13:27:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/aXHktkuTURBXy9mZDBhNzIyMS03YjgyLTRiMjgtOTJhZC1jNTdiMzU0OWZmOTYuanBlZ5GTBc0BHcyg" />W wyniku ostatnich operacji ukraińskich sił specjalnych wymierzonych w cele w Sewastopolu na zajmowanym przez Rosjan Krymie zginęło 96 okupantów, w tym dowódca Floty Czarnomorskiej admirał Wiktor Sokołow; zniszczono też okręt desantowy Mińsk - przekazały w poniedziałek Siły Operacji Specjalnych ukraińskiej armii.

## Akcjonariusze Archicomu zdecydowali o emisji do łącznie 10 mln akcji serii D i E
 - [https://forsal.pl/finanse/gielda/artykuly/9306861,akcjonariusze-archicomu-zdecydowali-o-emisji-do-lacznie-10-mln-akcji-s.html](https://forsal.pl/finanse/gielda/artykuly/9306861,akcjonariusze-archicomu-zdecydowali-o-emisji-do-lacznie-10-mln-akcji-s.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T13:22:28+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/pFsktkuTURBXy8xZGFiMmY3Mi1hYjZhLTRjNDEtODBkYS1iYTRkMDdlMTU5OTYuanBlZ5GTBc0BHcyg" />undefined

## Orban: Nie będziemy wspierać Ukrainy w żadnej sprawie, dopóki nie przywróci praw Węgrów na Zakarpaciu
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306850,orban-nie-bedziemy-wspierac-ukrainy-w-zadnej-sprawie-dopoki-nie-przy.html](https://forsal.pl/gospodarka/polityka/artykuly/9306850,orban-nie-bedziemy-wspierac-ukrainy-w-zadnej-sprawie-dopoki-nie-przy.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T13:02:53+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/i_gktkuTURBXy81ZTQxZWYyMC1iMjE0LTQ2ZDUtOGVhNS02NjQzMWUxMjUxMTEuanBlZ5GTBc0BHcyg" />Nie będziemy wspierać Ukrainy w żadnej sprawie na arenie międzynarodowej, dopóki rząd w Kijowie nie przywróci praw mniejszości węgierskiej na Zakarpaciu – powiedział w poniedziałek premier Węgier Viktor Orban podczas inauguracji jesiennej sesji parlamentu.

## Afera z dwiema wieżami spółki Srebrna powraca. PiS bagatelizuje sprawę, KO chce wyjaśnień od Kaczyńskiego
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306829,afera-z-dwiema-wiezami-spolki-srebrna-powraca-pis-bagatelizuje-sprawe.html](https://forsal.pl/gospodarka/polityka/artykuly/9306829,afera-z-dwiema-wiezami-spolki-srebrna-powraca-pis-bagatelizuje-sprawe.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T12:46:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/zd7ktkuTURBXy9mZDE2ODRhMS0yNzgwLTRmOTUtYmZlYi1iM2NkZDY3Zjg0NzUuanBlZ5GTBc0BHcyg" />Z uwagi na brak programu i propozycji merytorycznych opozycja próbuje &quot;kręcić kolejną wydmuszkę&quot; - powiedział w poniedziałek rzecznik PiS Rafał Bochenek, komentując doniesienia medialne związane ze sprawą spółki Srebrna. Politycy KO domagają się wyjaśnień od prezesa PiS Jarosława Kaczyńskiego.

## Zełenski: Dotarły już do nas pierwsze czołgi Abrams z USA
 - [https://forsal.pl/swiat/ukraina/artykuly/9306825,zelenski-dotarly-juz-do-nas-pierwsze-czolgi-abrams-z-usa.html](https://forsal.pl/swiat/ukraina/artykuly/9306825,zelenski-dotarly-juz-do-nas-pierwsze-czolgi-abrams-z-usa.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T12:44:44+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6nIktkuTURBXy9jNjQ3MDkyOS1iMTVmLTRmMzQtYTc4My0zYTZiMzkwMjRkNmIuanBlZ5GTBc0BHcyg" />Pierwsza partia amerykańskich czołgów Abrams dotarła na Ukrainę - poinformował w poniedziałek prezydent tego kraju Wołodymyr Zełenski w mediach społecznościowych.

## Jakie perspektywy mają gospodarki USA i Chin? To Pekin ma większy problem
 - [https://forsal.pl/gospodarka/artykuly/9306821,jakie-perspektywy-maja-gospodarki-usa-i-chin-to-pekin-ma-wiekszy-prob.html](https://forsal.pl/gospodarka/artykuly/9306821,jakie-perspektywy-maja-gospodarki-usa-i-chin-to-pekin-ma-wiekszy-prob.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T12:42:11+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BKhktkuTURBXy8xNmZiMjUxZi1kMzA2LTQwNTItODU5Yi04MzgzNzJlMmZiYzMuanBlZ5GTBc0BHcyg" />Perspektywy dla amerykańskiej gospodarki na najbliższe kwartały są umiarkowanie pozytywne, choć wciąż nie można wykluczyć recesji - uważają uczestnicy XXXII debaty PAP Biznes „Strategie rynkowe TFI”. Ryzykiem dla globalnej gospodarki jest sytuacja w Chinach - w dłuższej perspektywie kraj ten może doświadczyć istotnego kryzysu. Ryzykiem jest też utrzymanie się inflacji na podwyższonym poziomie przez dłuższy czas.

## Zainteresowani zakupem VeloBanku składają oferty. Wśród nich są trzy amerykańskie fundusze inwestycyjne
 - [https://forsal.pl/biznes/bankowosc/artykuly/9306745,zainteresowani-zakupem-velobanku-skladaja-oferty-wsrod-nich-sa-trzy-a.html](https://forsal.pl/biznes/bankowosc/artykuly/9306745,zainteresowani-zakupem-velobanku-skladaja-oferty-wsrod-nich-sa-trzy-a.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T11:52:39+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/YU-ktkuTURBXy84OGY0Y2ViNC1mODgxLTQwOTYtYTlkMC1mODUzYTUyY2QyNGYuanBlZ5GTBc0BHcyg" />undefined

## Sadoś: Chcemy transparentności w temacie rozmów KE-Ukraina dotyczących zboża
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9306694,sados-chcemy-transparentnosci-w-temacie-rozmow-ke-ukraina-dotyczacych.html](https://forsal.pl/swiat/unia-europejska/artykuly/9306694,sados-chcemy-transparentnosci-w-temacie-rozmow-ke-ukraina-dotyczacych.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T11:16:57+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/g6YktkuTURBXy9jNjg4Y2M4ZS1kYTVjLTQ2NmQtYWMxNy1lNzI0Yjg4NDVjODguanBlZ5GTBc0BHcyg" />Polska złoży we wtorek w Brukseli wniosek o przedstawienie 27 państwom członkowskim UE przez Komisję Europejską informacji na temat rozmów z Ukrainą w sprawie zboża - poinformował PAP Stały Przedstawiciel Polski przy UE Andrzej Sadoś.

## Politico: "Międzynarodowa" armia Rosji szuka nowych rekrutów. Na ukraiński front trafiają Kubańczycy
 - [https://forsal.pl/swiat/rosja/artykuly/9306681,politico-miedzynarodowa-armia-rosji-szuka-nowych-rekrutow-na-ukrai.html](https://forsal.pl/swiat/rosja/artykuly/9306681,politico-miedzynarodowa-armia-rosji-szuka-nowych-rekrutow-na-ukrai.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T11:01:22+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/xeZktkuTURBXy9kOWIwZmFhYy0wYzg1LTQ1MTUtYWFmYy04ZmQ5OTJkYTkzYjguanBlZ5GTBc0BHcyg" />Brukselski portal Politico opisuje w poniedziałek, jak Rosja próbuje werbować na Kubie najemników na wojnę przeciwko Ukrainie. Desperacja młodych Kubańczyków jest tak duża, że decydują się na służbę w rosyjskiej armii - czytamy w artykule.

## Autobusy miejskie ograniczą emisje do zera? Rada UE zaakceptowała projekt normy Euro 7 i szykuje się do negocjacji z PE
 - [https://forsal.pl/biznes/energetyka/artykuly/9306663,autobusy-miejskie-ogranicza-emisje-do-zera-rada-ue-zaakceptowala-proj.html](https://forsal.pl/biznes/energetyka/artykuly/9306663,autobusy-miejskie-ogranicza-emisje-do-zera-rada-ue-zaakceptowala-proj.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:43:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/7U8ktkuTURBXy9iYTIwMDAyNy05ZDc3LTQwOTMtYjMxMi0wZDc2MzE3MzQ0NjkuanBlZ5GTBc0BHcyg" />Rada UE (państwa członkowskie) przyjęła w poniedziałek swoje stanowisko negocjacyjne w sprawie projektu rozporządzenia dotyczącego homologacji pojazdów i silników. Chodzi o wprowadzenie normy Euro 7. Celem projektu jest obniżenie emisji substancji zanieczyszczających powietrze w transporcie drogowym.

## Które partie wejdą do Sejmu? Najnowszy sondaż
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306658,wybory-2023-nowy-sondaz-ktore-partie-wejda-do-sejmu.html](https://forsal.pl/gospodarka/polityka/artykuly/9306658,wybory-2023-nowy-sondaz-ktore-partie-wejda-do-sejmu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:34:18+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PaCktkuTURBXy81ZWEzMTE2MC05MzRkLTRkMTUtYjEyMy03MGQwMDAzMTQ5ZjAuanBlZ5GTBc0BHcyg" />Na Zjednoczoną Prawicę chce obecnie głosować 33,8 proc. ankietowanych; na KO - 28,1 proc.; na Trzecią Drogę - 9 proc.; na Konfederację - 8,8 proc., a na Lewicę - 8,7 proc. - wynika z opublikowanego w poniedziałek sondażu United Surveys dla Wirtualnej Polski.

## Selvita otrzymała zlecenia o wartości ponad 15 mln zł od firmy farmaceutycznej
 - [https://forsal.pl/finanse/gielda/artykuly/9306657,selvita-otrzymala-zlecenia-o-wartosci-ponad-15-mln-zl-od-firmy-farmace.html](https://forsal.pl/finanse/gielda/artykuly/9306657,selvita-otrzymala-zlecenia-o-wartosci-ponad-15-mln-zl-od-firmy-farmace.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:31:23+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/yfaktkuTURBXy9jN2E5ZTliNS05MWE0LTRlNzgtYjVjZS04ZTdkNDdkMDRjMzQuanBlZ5GTBc0BHcyg" />undefined

## Dekpol miał 25,55 mln zł zysku netto, 47,2 mln zł zysku EBITDA w I poł. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9306656,dekpol-mial-2555-mln-zl-zysku-netto-472-mln-zl-zysku-ebitda-w-i-pol.html](https://forsal.pl/finanse/gielda/artykuly/9306656,dekpol-mial-2555-mln-zl-zysku-netto-472-mln-zl-zysku-ebitda-w-i-pol.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:28:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/dk1ktkuTURBXy84ZDM4M2FkNC02OTczLTQ3MjUtYmI5MC00NDk1NjlhNGRiMTguanBlZ5GTBc0BHcyg" />undefined

## Wojas miał 7,81 mln zł zysku netto, 10,49 mln zł zysku EBIT w I poł. 2023 r.
 - [https://forsal.pl/finanse/gielda/artykuly/9306652,wojas-mial-781-mln-zl-zysku-netto-1049-mln-zl-zysku-ebit-w-i-pol-2.html](https://forsal.pl/finanse/gielda/artykuly/9306652,wojas-mial-781-mln-zl-zysku-netto-1049-mln-zl-zysku-ebit-w-i-pol-2.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:26:48+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3EHktkuTURBXy82ZmY3MmVlMC1mODRhLTQzOTgtOWQ5Yy0yOGM0MGYwNWQ4ZTguanBlZ5GTBc0BHcyg" />undefined

## Rynek nieruchomości czeka boom? W rok ceny transakcyjne mieszkań wzrosną o 10-15 proc.
 - [https://forsal.pl/nieruchomosci/mieszkania/artykuly/9306645,rynek-nieruchomosci-czeka-boom-w-rok-ceny-transakcyjne-mieszkan-wzros.html](https://forsal.pl/nieruchomosci/mieszkania/artykuly/9306645,rynek-nieruchomosci-czeka-boom-w-rok-ceny-transakcyjne-mieszkan-wzros.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:23:02+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/hs4ktkuTURBXy84NzgxMWRhYi1iYTIzLTQxNzYtYjRiNy1mNGFmNzQzZTdkZjYuanBlZ5GTBc0BHcyg" />undefined

## Polacy rezygnują z kosmetyków ekologicznych. Wybierają marki własne i promocji
 - [https://forsal.pl/biznes/handel/artykuly/9306634,polacy-rezygnuja-z-kosmetykow-ekologicznych-wybieraja-marki-wlasne-i.html](https://forsal.pl/biznes/handel/artykuly/9306634,polacy-rezygnuja-z-kosmetykow-ekologicznych-wybieraja-marki-wlasne-i.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T10:05:41+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/PXIktkuTURBXy8wZTU0NzJlNC1hN2M5LTRmYWMtOThkNC02ZTM5ZjUwMmUwZWIuanBlZ5GTBc0BHcyg" />Wartość sektora kosmetyków ekologicznych, organicznych i bio wynosi 224 mln zł, co oznacza spadek o 9 proc. rdr. - wynika z badania firmy GfK. Natomiast wartość całego rynku kosmetyków rośnie; najlepiej sprzedają się marki własne i oferowane w promocji - dodano.

## KRD wskazał najbardziej zadłużone miasta powiatowe w Polsce. Gdzie mieszka najwięcej dłużników?
 - [https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9306621,krd-wskazal-najbardziej-zadluzone-miasta-powiatowe-w-polsce-gdzie-mie.html](https://forsal.pl/gospodarka/finanse-publiczne/artykuly/9306621,krd-wskazal-najbardziej-zadluzone-miasta-powiatowe-w-polsce-gdzie-mie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T09:53:17+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/8UOktkuTURBXy83OWJiZWI1ZC1iNDA2LTRmMjEtOGM0Mi1kMzcyNWJiNTU5YzQuanBlZ5GTBc0BHcyg" />Wałbrzych jest najbardziej zadłużonym miastem w Polsce na prawach powiatu, średnia zaległość jednego dłużnika to 23,7 tys. zł. W pierwszej trójce są też Bytom i Świętochłowice - wynika z rankingu KRD. W czołówce powiatów z największym długiem są: nowodworski, sztumski i malborski.

## Rynek pracy: Analitycy PIE spodziewają się niewielkich zmian poziomu bezrobocia w nadchodzących miesiącach
 - [https://forsal.pl/praca/bezrobocie/artykuly/9306581,rynek-pracy-analitycy-pie-spodziewaja-sie-niewielkich-zmian-poziomu-b.html](https://forsal.pl/praca/bezrobocie/artykuly/9306581,rynek-pracy-analitycy-pie-spodziewaja-sie-niewielkich-zmian-poziomu-b.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T09:13:26+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/DuvktkuTURBXy9iMWRlZmVjOC1mYmVkLTQ3NjAtYTkxNC02ZjhhNjljOTA3YTMuanBlZ5GTBc0BHcyg" />Stopa bezrobocia do listopada powinna się wahać w niewielkim stopniu - ocenił Polski Instytut Ekonomiczny w komentarzu do poniedziałkowych danych Głównego Urzędu Statystycznego. Według PIE bezrobocie na początku przyszłego roku może wzrosnąć do 5,5 proc.

## Rumuńsko-austriackie tarcia polityczne z blokadą strefy Schengen i NATO w tle
 - [https://forsal.pl/swiat/unia-europejska/artykuly/9306558,rumunsko-austriackie-tarcia-polityczne-z-blokada-strefy-schengen-i-nat.html](https://forsal.pl/swiat/unia-europejska/artykuly/9306558,rumunsko-austriackie-tarcia-polityczne-z-blokada-strefy-schengen-i-nat.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T08:48:15+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/taektkuTURBXy84NTg2N2RmYi1lZjAyLTQ3MDQtOGM1ZC0wNmMzNzQ2ZTY5YjUuanBlZ5GTBc0BHcyg" />Bukareszt blokuje akredytację austriackich wysłanników przy NATO w reakcji na weto Wiednia w sprawie akcesji Rumunii do strefy Schengen – piszą austriackie i rumuńskie media. Eurodeputowany Raresz Bogdan powiedział telewizji Digi24, że „jest to jedyne rozwiązanie”.

## Koronawirus w Polsce: 13 zakażeń, nie było przypadków śmiertelnych [DANE Z 25.09]
 - [https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-13-zakazen-nie-bylo-przypadkow-smiertelnych-da.html](https://forsal.pl/artykuly/1458115,koronawirus-w-polsce-13-zakazen-nie-bylo-przypadkow-smiertelnych-da.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T08:39:55+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/3QYktkuTURBXy9lNjE1ZGFlZC02OTg5LTQzNzItOTg5OS1jZWEzOWVhODg4OWYuanBlZ5GTBc0BHcyg" />Minionej doby badania potwierdziły 13zakażeń koronawirusem. Z powodu COVID-19 nie zmarł żaden pacjent – poinformowano w poniedziałek na stronach rządowych. Wykonano 349 testów w kierunku SARS-CoV-2.

## ISW: Szojgu dostał mniej niż dwa tygodnie na zatrzymanie ukraińskiej kontrofensywy
 - [https://forsal.pl/swiat/rosja/artykuly/9306541,isw-szojgu-dostal-mniej-niz-dwa-tygodnie-na-zatrzymanie-ukrainskiej-k.html](https://forsal.pl/swiat/rosja/artykuly/9306541,isw-szojgu-dostal-mniej-niz-dwa-tygodnie-na-zatrzymanie-ukrainskiej-k.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T08:28:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ezfktkuTURBXy8zZjEzYTM3OC03YzFjLTQxZjgtODc2Yy0zYmU5MTg5NTJiNzYuanBlZ5GTBc0BHcyg" />Władimir Putin miał dać ministrowi obrony Rosji Siergiejowi Szojgu czas do początku października na zatrzymanie ukraińskiej kontrofensywy i przejęcie inicjatywy na froncie – pisze w najnowszej analizie amerykański Instytut Studiów nad Wojną (ISW).

## Bezrobocie w Polsce. GUS podał najnowsze dane
 - [https://forsal.pl/praca/bezrobocie/artykuly/9306647,bezrobocie-w-polsce-gus-podal-najnowsze-dane.html](https://forsal.pl/praca/bezrobocie/artykuly/9306647,bezrobocie-w-polsce-gus-podal-najnowsze-dane.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T08:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BoSktkuTURBXy81ODJiNzRkNC1hOGViLTRjMGYtYWE0Mi00MmU3OTM2ZjhiNmEuanBlZ5GTBc0BHcyg" />Stopa bezrobocia w sierpniu 2023 r. wyniosła 5,0 proc. wobec 5,0 proc. miesiąc wcześniej - podał Główny Urząd Statystyczny.

## Koniec strajku scenarzystów. Protestujący porozumieli się wstępnie z głównymi studiami filmowymi
 - [https://forsal.pl/swiat/usa/artykuly/9306444,koniec-strajku-scenarzystow-protestujacy-porozumieli-sie-wstepnie-z-g.html](https://forsal.pl/swiat/usa/artykuly/9306444,koniec-strajku-scenarzystow-protestujacy-porozumieli-sie-wstepnie-z-g.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T07:01:09+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/GSwktkuTURBXy8zNjhhY2YxYy03Yzk0LTQwNDMtYjBiYS02YzI5NTBmNGJiY2IuanBlZ5GTBc0BHcyg" />Amerykańska Gildia Scenarzystów (WGA) doszła w niedzielę do wstępnego porozumienia z głównymi wytwórniami filmowymi. Umowa ma zakończyć trwający od 2 maja strajk scenarzystów, który doprowadził do wstrzymania wielu produkcji i miliardowych strat amerykańskiego przemysłu filmowego.

## Komu Polacy ufają najbardziej, a komu najmniej? Oto nowy sondaż
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306433,komu-polacy-ufaja-najbardziej-a-komu-najmniej-oto-nowy-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9306433,komu-polacy-ufaja-najbardziej-a-komu-najmniej-oto-nowy-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:49:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/IUUktkuTURBXy9jYzBjM2YzNC1mMDQxLTQ5ZDAtYTYyMy03YWVhNmQxMTE4YTcuanBlZ5GTBc0BHcyg" />Andrzej Duda wyprzedził Rafała Trzaskowskiego i powrócił na pierwsze miejsce w rankingu zaufania do osób publicznych. Swoje notowania poprawili premier Mateusz Morawiecki i lider Platformy Obywatelskiej Donald Tusk, kolejny raz walcząc o ostatnie miejsce na podium — wynika z najnowszego sondażu IBRiS dla Onetu.

## Kto wygra wybory? Jest nowy sondaż
 - [https://forsal.pl/gospodarka/polityka/artykuly/9306419,kto-wygra-wybory-2023-jest-nowy-sondaz.html](https://forsal.pl/gospodarka/polityka/artykuly/9306419,kto-wygra-wybory-2023-jest-nowy-sondaz.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:37:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VF8ktkuTURBXy8zMGIxYzAxNS1kNzM3LTQ1YTEtYjljOC1iMDFlZjk2NTQ3NTIuanBlZ5GTBc0BHcyg" />W najnowszym sondażu wyborczym Instytutu Badań Pollster wykonanym dla &quot;Super Expressu” liderem pozostaje Zjednoczona Prawica (36,76 proc. głosów), a na drugim miejscu utrzymuje się Koalicja Obywatelska (30,44 proc.).

## Mięso z laboratorium? Jego produkcja jest coraz tańsza
 - [https://forsal.pl/lifestyle/nauka/artykuly/9306410,mieso-z-laboratorium-jego-produkcja-jest-coraz-tansza.html](https://forsal.pl/lifestyle/nauka/artykuly/9306410,mieso-z-laboratorium-jego-produkcja-jest-coraz-tansza.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:32:36+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/6F2ktkuTURBXy9kNGQ3ZWI1Ny0xMzRmLTQyYTUtOTA4Ni00ZDc3YjM1YzRmZjMuanBlZ5GTBc0BHcyg" />Pierwszy &quot;sztuczny&quot; burger wytworzony 10 lat temu, kosztował 250 tys. dolarów, obecnie szaszłyk z kurczaka można kupić już za 14 dolarów. Na całym świecie coraz więcej firm angażuje się w produkcję mięsa komórkowego. W tym wyścigu bierze udział też polska firma LabFarm.

## Surowce. Miedź w Londynie tanieje
 - [https://forsal.pl/finanse/notowania/artykuly/9306409,surowce-miedz-w-londynie-tanieje.html](https://forsal.pl/finanse/notowania/artykuly/9306409,surowce-miedz-w-londynie-tanieje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:31:59+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/K8VktkuTURBXy8xYjA3NjVkZS1mNzQ5LTQwOTAtOWYzNy05OWE3NDQ2NjRjMzQuanBlZ5GTBc0BHcyg" />Ceny miedzi na giełdzie metali LME w Londynie nieznacznie spadają na początku nowego tygodnia handlu. Metal na LME jest wyceniany niżej o 0,2 proc. wobec 8.222,00 USD za tonę notowanych na zakończenie poprzedniej sesji - informują maklerzy.

## Partia Macrona traci. Są wstępne wyniki francuskich wyborów do Senatu
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9306403,partia-macrona-traci-sa-wstepne-wyniki-francuskich-wyborow-do-senatu.html](https://forsal.pl/swiat/aktualnosci/artykuly/9306403,partia-macrona-traci-sa-wstepne-wyniki-francuskich-wyborow-do-senatu.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:25:35+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/u9dktkuTURBXy8yNTRmYjA1NC0xYTQwLTQwNjUtYTJiNy00NmJmZTk1YTM2NDkuanBlZ5GTBc0BHcyg" />W częściowych wyborach do Senatu w niedzielę prawica utrzymuje liczbę mandatów, lewica się wzmacnia, Zjednoczenie Narodowe powraca do izby, zaś partia prezydenta Emmanuela Macrona zostaje osłabiona - ocenia agencja AFP.

## Surowce. Wahania na rynku ropy naftowej: Brent tanieje, WTI drożeje
 - [https://forsal.pl/finanse/notowania/artykuly/9306398,surowce-wahania-na-rynku-ropy-naftowej-brent-tanieje-wti-drozeje.html](https://forsal.pl/finanse/notowania/artykuly/9306398,surowce-wahania-na-rynku-ropy-naftowej-brent-tanieje-wti-drozeje.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:23:54+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/BGUktkuTURBXy81YzFhNjU3ZC04ZTVhLTQxNTMtOTI3YS00MGE5Yjk2Yzk4M2MuanBlZ5GTBc0BHcyg" />W poniedziałek po godz. 8 notowania baryłki ropy Brent na giełdzie w Londynie spadły o 1,13 proc., do 92,22 dol. Notowania baryłki amerykańskiej ropy WTI na giełdzie w Nowym Jorku wzrosły o 0,31 proc., do 90,31 dol.

## Wzrost nowych zębów? Trwają prace nad przełomowym lekiem
 - [https://forsal.pl/lifestyle/zdrowie/artykuly/9306397,wzrost-nowych-zebow-trwaja-prace-nad-przelomowym-lekiem.html](https://forsal.pl/lifestyle/zdrowie/artykuly/9306397,wzrost-nowych-zebow-trwaja-prace-nad-przelomowym-lekiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:19:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SolktkuTURBXy81ZDFhZGUwYy01YzhhLTQ5MDMtYTk4Ny05NDVmNjAyZTNhZTIuanBlZ5GTBc0BHcyg" />Japoński startup farmaceutyczny pracuje nad pierwszym na świecie lekiem, stymulującym wzrost nowych zębów. Ma pomóc dzieciom z wrodzoną wadą uzębienia, a w przyszłości także zastępować zęby wyrwane osobom dorosłym – podała w niedzielę agencja Kyodo.

## Wzrost nowych zębów? Trwają prace nad przełomowym lekiem
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9306607,wzrost-nowych-zebow-trwaja-prace-nad-przelomowym-lekiem.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9306607,wzrost-nowych-zebow-trwaja-prace-nad-przelomowym-lekiem.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:19:19+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/SolktkuTURBXy81ZDFhZGUwYy01YzhhLTQ5MDMtYTk4Ny05NDVmNjAyZTNhZTIuanBlZ5GTBc0BHcyg" />Japoński startup farmaceutyczny pracuje nad pierwszym na świecie lekiem, stymulującym wzrost nowych zębów. Ma pomóc dzieciom z wrodzoną wadą uzębienia, a w przyszłości także zastępować zęby wyrwane osobom dorosłym – podała w niedzielę agencja Kyodo.

## Geopolityczny dramat Ormian. Co się stało w Górskim Karabachu? [OPINIA]
 - [https://forsal.pl/swiat/aktualnosci/artykuly/9306059,geopolityczny-dramat-ormian-co-sie-stalo-w-gorskim-karabachu-opinia.html](https://forsal.pl/swiat/aktualnosci/artykuly/9306059,geopolityczny-dramat-ormian-co-sie-stalo-w-gorskim-karabachu-opinia.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:11:20+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/wwXktkuTURBXy8zNWE3MGIyOC0yNzcwLTQ2OTgtYjAwOC0zYzEyMmJmZTcyMzIuanBlZ5GTBc0BHcyg" />Azerbejdżanowi wystarczyła doba, by zmusić samozwańczą Republikę Górskiego Karabachu, zwaną także Arcachem, do kapitulacji. Miejscowe władze zaczęły się już rozbrajać, po czym same zostaną rozwiązane, a region – zintegrowany z Azerbejdżanem.

## Kto odpowiada za oszustwa VAT? Wiemy już więcej
 - [https://forsal.pl/gospodarka/artykuly/9305845,kto-odpowiada-za-oszustwa-vat-wiemy-juz-wiecej.html](https://forsal.pl/gospodarka/artykuly/9305845,kto-odpowiada-za-oszustwa-vat-wiemy-juz-wiecej.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T06:05:58+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ffiktkuTURBXy81NDYwMGZjOC05NWI4LTQwYmUtYTlhYS05MmIwYzQ0YTZlZWQuanBlZ5GTBc0BHcyg" />Nieuczciwy pracownik, który wykorzystał dane pracodawcy bez jego wiedzy i zgody, powinien zapłacić VAT z wystawionych przez siebie pustych faktur – uważa rzecznik generalna TSUE. A co, gdy oszustem jest odbiorca towaru?

## Ile wynosi inflacja w Polsce? Polacy wskazali wartości [SONDAŻ DGP I RMF]
 - [https://forsal.pl/gospodarka/inflacja/artykuly/9306036,ile-wynosi-inflacja-w-polsce-polacy-wskazali-wartosci-sondaz-dgp-i-r.html](https://forsal.pl/gospodarka/inflacja/artykuly/9306036,ile-wynosi-inflacja-w-polsce-polacy-wskazali-wartosci-sondaz-dgp-i-r.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T05:48:08+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/VRjktkuTURBXy9lYzZmZGJiYi1lMzkxLTQ4OWItYjc2NC1kMGUzOGRkZjUyMTcuanBlZ5GTBc0BHcyg" />Spada skala postrzeganego wzrostu cen – pokazuje sondaż United Surveys dla DGP i RMF FM. Pytaliśmy w nim, ile zdaniem ankietowanych wynosi obecnie inflacja.

## Berlin przewerbował Zełenskiego. "Zaskoczyła nas skala dogadania z Niemcami"
 - [https://forsal.pl/swiat/ukraina/artykuly/9305997,berlin-przewerbowal-zelenskiego-zaskoczyla-nas-skala-dogadania-z-nie.html](https://forsal.pl/swiat/ukraina/artykuly/9305997,berlin-przewerbowal-zelenskiego-zaskoczyla-nas-skala-dogadania-z-nie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T05:42:01+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/N_1ktkuTURBXy83YWNhNDQ1OC0xZGI2LTRiZjktOWU2MC1lNGQ2NTY5YWQzNmYuanBlZ5GTBc0BHcyg" />Zełenski wbija ostatni gwóźdź do trumny przyjaźni z Dudą. Polska szykuje symetryczną odpowiedź na czas po wyborach. Po ofensywie prezydenta Ukrainy i „przejeździe” przez Lublin Kijów ma zerową wiarygodność w polskim rządzie i w Pałacu Prezydenckim. Odtwarzamy kulisy rozmów ukraińsko-niemieckich.

## Warszawa: Zakaz palenia węglem. Co powinieneś wiedzieć? Terminy, kary, dofinansowanie
 - [https://forsal.pl/lifestyle/aktualnosci/artykuly/9303621,warszawa-zakaz-palenia-weglem-co-powinienes-wiedziec-terminy-kary.html](https://forsal.pl/lifestyle/aktualnosci/artykuly/9303621,warszawa-zakaz-palenia-weglem-co-powinienes-wiedziec-terminy-kary.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T04:30:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/ZhmktkuTURBXy9mODY2ZTk1YS00MDhjLTQ4ZjgtYTgxZC1iMzNjNWZkYjU0OGQuanBlZ5GTBc0BHcyg" />W Polsce wraz z pierwszymi chłodniejszymi dniami oraz sezonem grzewczym rozpoczyna się nowy rozdział w walce z paleniem węglem. Warszawa staje się tym samym kolejnym punktem na mapie kraju, który przygotowuje się do wprowadzenia restrykcyjnych zakazów. Choć aktualnie już wiele miejsc na terenie Polski surowo zabrania spalania tego surowca, to stolica staje przed wyzwaniem ograniczenia jego używania.

## Rozpoczął się nowy rok szkolny. Popularność ChatGPT ponownie rośnie
 - [https://forsal.pl/lifestyle/technologie/artykuly/9303367,rozpoczal-sie-nowy-rok-szkolny-popularnosc-chatgpt-ponownie-rosnie.html](https://forsal.pl/lifestyle/technologie/artykuly/9303367,rozpoczal-sie-nowy-rok-szkolny-popularnosc-chatgpt-ponownie-rosnie.html)
 - RSS feed: https://forsal.pl/.feed
 - date published: 2023-09-25T04:00:00+00:00

<img align="right" hspace="5" src="https://ocdn.eu/pulscms-transforms/1/Ay9ktkuTURBXy9lYmRmNjQxNy05MzYyLTQxYzAtOWI4ZC03YTM3Y2Y4ZWRkZWIuanBlZ5GTBc0BHcyg" />Jak wynika z nowych szacunków firm analitycznych, po spadku w okresie letnim obecnie użycie ChatGPT ponownie rośnie. To jest być może najwyraźniejszy dowód na to, że kalendarz szkolny w USA ma bezpośredni wpływ na wykorzystanie chatbota.

