# Source:Daily Wire, URL:https://www.dailywire.com/feeds/rss.xml, language:en-US

## Top Credit Rating Agency Warns Government Shutdown Would Make U.S. Look Weak
 - [https://www.dailywire.com/news/top-credit-rating-agency-warns-government-shutdown-would-make-u-s-look-weak](https://www.dailywire.com/news/top-credit-rating-agency-warns-government-shutdown-would-make-u-s-look-weak)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T18:41:02+00:00

The only member of the &#8220;Big Three&#8221; agencies that has not downgraded the U.S. credit rating from &#8220;AAA&#8221; status warned that another government shutdown would make the United States look weak compared to other top-rated nations. Moody’s Investors Service sounded the &#8220;credit negative&#8221; alarm in a note on Monday as Congress scrambles to reach a ...

## ‘View’ Host Ana Navarro Calls Allegations Against Friend Bob Menendez ‘Serious’ And ‘Troubling’
 - [https://www.dailywire.com/news/view-host-ana-navarro-calls-allegations-against-friend-bob-menendez-serious-and-troubling](https://www.dailywire.com/news/view-host-ana-navarro-calls-allegations-against-friend-bob-menendez-serious-and-troubling)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T18:28:40+00:00

&#8220;The View&#8221; host Ana Navarro called the allegations against long-time friend Sen. Bob Menendez (D-NJ) &#8220;serious&#8221; and &#8220;troubling&#8221; as she explained that he&#8217;s &#8220;entitled to a presumption of innocence&#8221; amid multiple corruption charges. The ABC talk show host wrote to her 1.9 million followers on Monday in a post on X about how she knows ...

## MSNBC Guest Says Biden’s Age Is A Benefit. Seriously.
 - [https://www.dailywire.com/news/msnbc-guest-says-bidens-age-is-a-benefit-seriously](https://www.dailywire.com/news/msnbc-guest-says-bidens-age-is-a-benefit-seriously)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T18:23:27+00:00

MSNBC political analyst Cornell Belcher claimed over the weekend that President Joe Biden&#8217;s age was not only not a concern, but a benefit. Belcher attempted to take a page from the playbook of former President Ronald Reagan — who also faced criticism about his age when he ran for president — and equate Biden&#8217;s age ...

## Democratic El Paso Mayor Charters Five Buses To Take Migrants To New York, Chicago, Denver
 - [https://www.dailywire.com/news/democratic-el-paso-mayor-charters-five-buses-to-take-migrants-to-new-york-chicago-denver](https://www.dailywire.com/news/democratic-el-paso-mayor-charters-five-buses-to-take-migrants-to-new-york-chicago-denver)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T18:21:01+00:00

The Democratic mayor of El Paso, Texas says the city has reached &#8220;a breaking point&#8221; with floods of migrants coming in every day and said the city chartered five buses to take migrants to New York, Chicago, and Denver over the weekend. El Paso is seeing more than 2,000 migrants per day, pushing the border ...

## The Institution Of Marriage Is Under Attack From All Sides
 - [https://www.dailywire.com/news/the-institution-of-marriage-is-under-attack-from-all-sides](https://www.dailywire.com/news/the-institution-of-marriage-is-under-attack-from-all-sides)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T18:00:46+00:00

I have spent a lot of time in my career defending the institution of marriage. I defend it because it is the bedrock of civilization, so it deserves defending. And I defend it because it is under constant attack, so it needs defending. One of the most troubling developments in recent years — which we’ve ...

## Border Patrol Agent Allegedly Bloodied By Migrant With ‘RAT’ Written On Forehead
 - [https://www.dailywire.com/news/border-patrol-agent-allegedly-bloodied-by-migrant-with-rat-written-on-forehead](https://www.dailywire.com/news/border-patrol-agent-allegedly-bloodied-by-migrant-with-rat-written-on-forehead)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T17:19:27+00:00

Gruesome photos show a Border Patrol agent covered in blood after he was allegedly attacked by a migrant cartel informer, a former Texas Republican lawmaker said. The graphic photos were shared on Instagram on Saturday by former Texas congresswoman Mayra Flores, who is married to a Border Patrol agent. &#8220;This is the type of violence ...

## After Canada’s Parliament Cheers Nazi Veteran, ‘Upset’ Trudeau Warns Against ‘Russian Propaganda’
 - [https://www.dailywire.com/news/after-canadas-parliament-cheers-nazi-veteran-upset-trudeau-warns-against-russian-propaganda](https://www.dailywire.com/news/after-canadas-parliament-cheers-nazi-veteran-upset-trudeau-warns-against-russian-propaganda)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T17:13:29+00:00

After his country’s parliament gave a World War II Ukrainian veteran an ovation, only to learn later that he was part of the 14th Waffen Grenadier Division of the SS, the military wing of the Nazi Party, Canadian Prime Minister Justin Trudeau spent time focusing on “Russian propaganda” and “Russian disinformation.” The ovation for Yaroslav ...

## Legendary Actress Sophia Loren Hospitalized After Fall
 - [https://www.dailywire.com/news/legendary-actress-sophia-loren-hospitalized-after-fall](https://www.dailywire.com/news/legendary-actress-sophia-loren-hospitalized-after-fall)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T17:01:55+00:00

Legendary screen star Sophia Loren underwent emergency surgery on Sunday after a bad fall at her home in Switzerland and remains hospitalized. A source confirmed to the Hollywood Reporter that the 89-year-old Italian star is recovering after having hip surgery. Loren sustained several fractures after falling in her bathroom, including one to her femur. The ...

## George Jones’ Widow Opens Up About Husband Nearly Losing His Life During Addiction Battle
 - [https://www.dailywire.com/news/george-jones-widow-opens-up-about-husband-nearly-losing-his-life-during-addiction-battle](https://www.dailywire.com/news/george-jones-widow-opens-up-about-husband-nearly-losing-his-life-during-addiction-battle)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T16:55:43+00:00

George Jones&#8217; widow, Nancy Jones, opened up about the late-country star nearly losing his life during his lengthy battle with cocaine and alcohol addiction in her new memoir titled, &#8220;Playin&#8217; Possum: My Memories of George Jones.&#8221; Jones told Fox News why she wrote the book and talked about the near-fatal car accident the late country ...

## Verdict Delivered In Death Of Ethan Liming, Teen Beaten To Death Outside I PROMISE School
 - [https://www.dailywire.com/news/verdict-delivered-in-death-of-ethan-liming-teen-beaten-to-death-outside-i-promise-school](https://www.dailywire.com/news/verdict-delivered-in-death-of-ethan-liming-teen-beaten-to-death-outside-i-promise-school)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T16:36:13+00:00

Defendants in the beating death of 17-year-old Ethan Liming have so far evaded any manslaughter charges, a jury decided Monday. Deshawn Stafford Jr., 21, and his brother Tyler Stafford, 20, were both found not guilty of involuntary manslaughter in Liming&#8217;s death. Deshawn was found guilty of aggravated assault and assault and a mistrial was declared ...

## Michael Wolff Claims Tucker Carlson Was Behind Ron DeSantis Dog Story; Carlson Fires Back
 - [https://www.dailywire.com/news/michael-wolff-claims-tucker-carlson-was-behind-ron-desantis-dog-story-carlson-fires-back](https://www.dailywire.com/news/michael-wolff-claims-tucker-carlson-was-behind-ron-desantis-dog-story-carlson-fires-back)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T16:09:40+00:00

Controversial author Michael Wolff claimed in an interview this week that Tucker Carlson was the source of his reporting that alleged Florida Governor Ron DeSantis kicked Carlson’s dog while meeting with Carlson and his wife, Susie Carlson. Carlson rejected the claims in &#8220;The Fall: The End of Fox News and the Murdoch Dynasty&#8221; last week, ...

## DOJ Clears Hunter Biden Prosecutor For Testimony In ‘Near Term’
 - [https://www.dailywire.com/news/doj-clears-hunter-biden-prosecutor-for-testimony-in-near-term](https://www.dailywire.com/news/doj-clears-hunter-biden-prosecutor-for-testimony-in-near-term)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T16:03:08+00:00

The Department of Justice (DOJ) indicated that special counsel David Weiss will soon be allowed to testify to Congress about his investigation of Hunter Biden, the son of the president. Assistant Attorney General Carlos Uriarte sent a letter on Friday telling the House Judiciary Committee that the DOJ &#8220;reaffirms its commitment&#8221; to make Weiss available ...

## Actress Kerry Washington Says Parents Didn’t Tell Her She Was Conceived Via Sperm Donation Until 2018
 - [https://www.dailywire.com/news/actress-kerry-washington-says-parents-didnt-tell-her-she-was-conceived-via-sperm-donation-until-2018](https://www.dailywire.com/news/actress-kerry-washington-says-parents-didnt-tell-her-she-was-conceived-via-sperm-donation-until-2018)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T15:54:26+00:00

Actress Kerry Washington recently discussed her reaction to finding out that the man who raised her was not her biological father, but she was conceived via sperm donation instead. The “Scandal” star revealed how she learned the truth while promoting her new memoir, “Thicker Than Water.” Washington told the New York Times that she realized ...

## ‘Too Skinny’: Sharon Osbourne Admits She Took Weight Loss Too Far After Taking Ozempic
 - [https://www.dailywire.com/news/too-skinny-sharon-osbourne-admits-she-took-weight-loss-too-far-after-taking-ozempic](https://www.dailywire.com/news/too-skinny-sharon-osbourne-admits-she-took-weight-loss-too-far-after-taking-ozempic)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T15:43:17+00:00

Sharon Osbourne admitted she took weight loss too far after taking the diabetes drug Ozempic to drop some pounds and said she&#8217;s now &#8220;too skinny&#8221; and didn&#8217;t intend to get so thin. During her recent appearance on &#8220;Piers Morgan Uncensored,&#8221; the 70-year-old television personality told the host that her looks have changed and not for ...

## Texas GOP Passes Unanimous Resolution Calling For Special Legislative Session On Colony Ridge
 - [https://www.dailywire.com/news/texas-gop-passes-unanimous-resolution-calling-for-special-legislative-session-on-colony-ridge](https://www.dailywire.com/news/texas-gop-passes-unanimous-resolution-calling-for-special-legislative-session-on-colony-ridge)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T14:55:22+00:00

The Republican Party of Texas unanimously passed a resolution calling on Governor Greg Abbott to convene a special legislative session to address Colony Ridge, the massive housing development north of Houston that’s become a hub for illegal immigrants. The resolution, which passed by a vote of 61-0, says a special legislative session must be convened ...

## Cuban Embassy In D.C. Targeted With Molotov Cocktails In ‘Terrorist Attack,’ Diplomat Says
 - [https://www.dailywire.com/news/cuban-embassy-in-d-c-targeted-with-molotov-cocktails-in-terrorist-attack-diplomat-says](https://www.dailywire.com/news/cuban-embassy-in-d-c-targeted-with-molotov-cocktails-in-terrorist-attack-diplomat-says)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T14:37:03+00:00

The Cuban embassy in Washington, D.C., was the target of a “terrorist attack” after two Molotov cocktails were thrown at the building on Sunday evening, according to Cuba’s Minister of Foreign Affairs.  Cuban diplomat Bruno Rodríguez said in a statement on X that the embassy had been attacked when someone threw multiple makeshift incendiary devices ...

## New California Law Requires Schools To Have Gender Neutral Restroom
 - [https://www.dailywire.com/news/new-california-law-requires-schools-to-have-gender-neutral-restroom](https://www.dailywire.com/news/new-california-law-requires-schools-to-have-gender-neutral-restroom)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T14:32:26+00:00

A new California law will require all of the state&#8217;s public schools to soon have a gender-neutral bathroom. Democratic Governor Gavin Newsom signed the law on Saturday. Under the new bathroom law, public schools teaching first through 12th grade must have at least one gender-neutral bathroom available for students by 2026. California already requires K-12 ...

## Investigator Working For Fulton County DA Willis Accidentally Shoots Herself, Authorities Say
 - [https://www.dailywire.com/news/investigator-working-for-fulton-county-da-willis-accidentally-shoots-herself-authorities-say](https://www.dailywire.com/news/investigator-working-for-fulton-county-da-willis-accidentally-shoots-herself-authorities-say)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T13:50:38+00:00

An investigator working for Georgia&#8216;s Fulton County District Attorney Fani Willis accidentally shot and wounded herself with a firearm, according to authorities. The Fulton County Sheriff&#8217;s Office said on Friday it was gathering information on a &#8220;shooting incident&#8221; at the Fulton County Courthouse and that there was no active threat. A follow-up post to X ...

## She Had A Rare Medical Condition But Hospital Staff Suspected Abuse. Her Family’s Lawsuit Just Went To Court.
 - [https://www.dailywire.com/news/she-had-a-rare-medical-condition-but-hospital-staff-suspected-abuse-her-familys-lawsuit-just-went-to-court](https://www.dailywire.com/news/she-had-a-rare-medical-condition-but-hospital-staff-suspected-abuse-her-familys-lawsuit-just-went-to-court)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T13:39:40+00:00

A woman whose childhood medical condition and hospital treatment were featured in the tragic Netflix documentary “Take Care of Maya” is finally getting her day in court. Maya Kowalski was just nine years old when she started having asthma attacks and headaches. Her symptoms soon evolved to include lesions on her arms and legs, and ...

## Bob Menendez Explains Why He Had $480,000 In Cash At His Home
 - [https://www.dailywire.com/news/bob-menendez-explains-why-he-had-480000-in-cash-at-his-home](https://www.dailywire.com/news/bob-menendez-explains-why-he-had-480000-in-cash-at-his-home)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T12:59:39+00:00

Sen. Bob Menendez (D-NJ) held a press conference on Monday to address the federal corruption charges by prosecutors from the Southern District of New York who accused him of accepting bribes. The federal indictment was unsealed on Friday, and it accused the senator and his wife of accepting bribes from three business people in exchange ...

## Mother Gets Just 30 Days In Jail For Waterboarding Baby, Putting Him In Freezer To Get Man’s Attention
 - [https://www.dailywire.com/news/mother-gets-just-30-days-in-jail-for-waterboarding-baby-putting-him-in-freezer-to-get-mans-attention](https://www.dailywire.com/news/mother-gets-just-30-days-in-jail-for-waterboarding-baby-putting-him-in-freezer-to-get-mans-attention)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T12:17:38+00:00

An Oregon woman who waterboarded her infant son and put him in a freezer was sentenced to 30 days in jail for the crime. Sharday McDonald, 30, admitted to police that she had tortured her 13-month-old son “out of spite” to “test” the loyalty of the boy’s father, Law &amp; Crime reported. The boy survived ...

## California Library Shuts Down Moms For Liberty Event Over Misgendering Trans Athletes
 - [https://www.dailywire.com/news/california-library-shuts-down-moms-for-liberty-event-over-misgendering-trans-athletes](https://www.dailywire.com/news/california-library-shuts-down-moms-for-liberty-event-over-misgendering-trans-athletes)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T11:48:33+00:00

Throughout history, the greatest threat to free speech has always been authoritarian governments seeking to suppress dissent. That is still true today, even in America. Thankfully, a robust First Amendment has proved a necessary and valuable bulwark against censorious government autocrats. Historically, those on the political Left have proven to be some of the fiercest ...

## Mom Who Killed Her 2 Daughters Sentenced To 78 Years In Prison
 - [https://www.dailywire.com/news/mom-who-killed-her-2-daughters-sentenced-to-78-years-in-prison](https://www.dailywire.com/news/mom-who-killed-her-2-daughters-sentenced-to-78-years-in-prison)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T11:08:24+00:00

A Virginia mom who killed her two daughters to spite her ex-husband has been sentenced to 78 years in prison. Veronica Youngblood, 38, of McLean, Virginia, was convicted in March of murdering her daughters, 15-year-old Sharon and 5-year-old Brooklynn, nearly five years earlier. The next day, the jury recommended she serve 78 years in prison ...

## Taylor Swift Spotted Leaving Chiefs Game With Travis Kelce
 - [https://www.dailywire.com/news/taylor-swift-spotted-leaving-chiefs-game-with-travis-kelce](https://www.dailywire.com/news/taylor-swift-spotted-leaving-chiefs-game-with-travis-kelce)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T10:21:44+00:00

Pop icon Taylor Swift accepted NFL star Travis Kelce’s invitation to attend a game at Arrowhead Stadium in Kansas City to watch him play. The 33-year-old singer was caught on video leaving the venue on Sunday with the Kansas City Chiefs tight end walking closely by her side. The video appeared to show Swift saying ...

## Writers Strike Could Be Ending As WGA Reaches Tentative Deal With Studios
 - [https://www.dailywire.com/news/writers-strike-could-be-ending-as-wga-reaches-tentative-deal-with-studios](https://www.dailywire.com/news/writers-strike-could-be-ending-as-wga-reaches-tentative-deal-with-studios)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T09:56:55+00:00

The Hollywood writers strike could be finally coming to an end as the WGA (Writers Guild of America) came to a tentative agreement with the AMPTP on Sunday. &#8220;WGA has reached a tentative agreement with the AMPTP (Alliance of Motion Picture and Television Producers),&#8221; the guild said in a statement, per NBC News. &#8220;This was ...

## Weekend Media Wrap, Vol. 10: What You Missed If You Weren’t Glued To The Sunday Shows
 - [https://www.dailywire.com/news/weekend-media-wrap-vol-10-what-you-missed-if-you-werent-glued-to-the-sunday-shows](https://www.dailywire.com/news/weekend-media-wrap-vol-10-what-you-missed-if-you-werent-glued-to-the-sunday-shows)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T09:55:00+00:00

Every Sunday morning, legacy media outlets are taken over by elected officials, aspiring elected officials, administration insiders, and the usual collection of talking heads — all of whom are there to discuss specific policies, push talking points, or simply promote their own campaigns. For those who don&#8217;t spend their Sunday mornings glued to the television ...

## ‘60 Minutes’ Segment: U.S. Taxpayers ‘Subsidizing’ Ukraine’s Economy, Paying All Of Their First Responders
 - [https://www.dailywire.com/news/60-minutes-segment-u-s-taxpayers-subsidizing-ukraines-economy-paying-all-of-their-first-responders](https://www.dailywire.com/news/60-minutes-segment-u-s-taxpayers-subsidizing-ukraines-economy-paying-all-of-their-first-responders)
 - RSS feed: https://www.dailywire.com/feeds/rss.xml
 - date published: 2023-09-25T08:23:40+00:00

A &#8220;60 Minutes&#8221; segment broadcast on Sunday caused an uproar after the show reported that American taxpayers are &#8220;subsidizing&#8221; Ukraine&#8217;s economy and paying for all of Ukraine&#8217;s first responders. The news comes as a recent Fox News poll found that 56% of Republicans say the U.S. should be sending less support to Ukraine. A recent ...

