# Source:Money PL, URL:https://www.money.pl/rss/, language:pl-PL

## Nie dostaną przelewu z MEiN. "Rozumiemy rozgoryczenie"
 - [https://www.money.pl/pieniadze/nie-dostana-przelewu-z-mein-rozumiemy-rozgoryczenie-6945446298721120a.html](https://www.money.pl/pieniadze/nie-dostana-przelewu-z-mein-rozumiemy-rozgoryczenie-6945446298721120a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T19:28:27+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/36a3522a-6e5a-4ff2-87bd-717a81334d34" width="308" /> Z okazji 250. rocznicy utworzenia Komisji Edukacji Narodowej nauczyciele dostaną w tym roku nagrody specjalne. Na dodatkowe pieniądze nie mogą jednak liczyć pracownicy administracji i obsługi w szkołach. Głos w tej sprawie zabrał Związek Nauczycielstwa Polskiego.

## Kierowcy polskiej firmy strajkują. Tiry stoją. "Problem się rozleje"
 - [https://www.money.pl/gospodarka/kierowcy-polskiej-firmy-strajkuja-tiry-stoja-problem-sie-rozleje-6945365495237376a.html](https://www.money.pl/gospodarka/kierowcy-polskiej-firmy-strajkuja-tiry-stoja-problem-sie-rozleje-6945365495237376a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T17:57:59+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/11957258-6fc0-4235-a007-fb95558baf9d" width="308" /> Od ponad dwóch miesięcy w Niemczech trwają protesty kierowców pracujących dla polskiej grupy spedycyjnej Mazur. Kilka dni temu rozpoczął się strajk głodowy. Kierowcy domagają się, jak przekonują, zaległych wynagrodzeń. Chodzi o ponad 500 tys. euro. Firma nie ma sobie nic do zarzucenia.

## Znamy wysokość przeciętnej emerytury. Zaskoczenie w wykresie
 - [https://www.money.pl/emerytury/znamy-wysokosc-przecietnej-emerytury-zaskoczenie-w-wykresie-6945394600778496a.html](https://www.money.pl/emerytury/znamy-wysokosc-przecietnej-emerytury-zaskoczenie-w-wykresie-6945394600778496a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T15:42:42+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/fd95fc65-c49d-4e82-9dad-e278f2940211" width="308" /> Przeciętna miesięczna nominalna emerytura i renta brutto w sierpniu br. była o 18,3 proc. wyższa niż rok wcześniej - podał GUS. Ile wynosi świadczenie?

## Kolejne wahania złotego, nagły wzrost kursu dolara. Co się stało?
 - [https://www.money.pl/pieniadze/kolejne-wahniecie-zlotego-i-nagly-wzrost-wartosci-dolara-6945407693196128a.html](https://www.money.pl/pieniadze/kolejne-wahniecie-zlotego-i-nagly-wzrost-wartosci-dolara-6945407693196128a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T15:36:12+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/774f557c-53cf-48e4-bba9-7daf378924b6" width="308" /> W poniedziałek po południu dolar zaczął wyraźnie drożeć. Amerykańska waluta wzmocniła się wobec złotego o 0,7 proc. Po kilku godzinach wzrostu tempo wyraźnie osłabło.

## Wynagrodzenia w jednej branży o 53 proc. wyższe od średniej. Ponad 11 tys. zł
 - [https://www.money.pl/pieniadze/wynagrodzenia-w-jednej-branzy-o-53-proc-wyzsze-od-sredniej-ponad-11-tys-zl-6945383600716544a.html](https://www.money.pl/pieniadze/wynagrodzenia-w-jednej-branzy-o-53-proc-wyzsze-od-sredniej-ponad-11-tys-zl-6945383600716544a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T14:02:52+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/1a661f57-cc83-48e9-8bc2-bb645c5e7da7" width="308" /> Przeciętne miesięczne wynagrodzenie brutto w sektorze przedsiębiorstw w sierpniu br. wyniosło 7368,97 zł. Ale w jednej branży jest o ponad 50 proc. wyższe - informuje GUS.

## Kiedy zacząć oszczędzać, by zostać milionerem? Eksperci obliczyli odpowiedni wiek
 - [https://www.money.pl/pieniadze/kiedy-zaczac-oszczedzac-by-zostac-milionerem-eksperci-obliczyli-odpowiedni-wiek-6945357276220256a.html](https://www.money.pl/pieniadze/kiedy-zaczac-oszczedzac-by-zostac-milionerem-eksperci-obliczyli-odpowiedni-wiek-6945357276220256a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T12:11:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/0891272d-f6ac-4ff7-9541-d57f5df72343" width="308" /> O byciu milionerem marzy każdy. Osiągnięcie tego celu może być według ekspertów od inwestowania stosunkowo proste. "Wystarczy" 100 dolarów tygodniowo. Kiedy jednak trzeba zacząć?

## Podatek Belki drenuje kieszenie Polaków. Fiskus ściągnął ponad 5 mld zł
 - [https://www.money.pl/podatki/podatek-belki-drenuje-kieszenie-polakow-fiskus-sciagnal-ponad-5-mld-zl-6945312583834432a.html](https://www.money.pl/podatki/podatek-belki-drenuje-kieszenie-polakow-fiskus-sciagnal-ponad-5-mld-zl-6945312583834432a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T10:08:01+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b9df0fe5-88e5-41c2-9786-8883347c79b7" width="308" /> Wpływy z podatku Belki poszły mocno w górę. W pierwszej połowie 2023 r. wzrosły o 28,7 proc. i wyniosły ponad 5 mld zł. Wzrost wpływów z podatku Belki odnotowano w warunkach wysokiej inflacji - podaje serwis MondayNews.

## Są najnowsze dane o bezrobociu w Polsce. Wykres stanął w miejscu
 - [https://www.money.pl/pieniadze/sa-najnowsze-dane-o-bezrobociu-w-polsce-wykres-stanal-w-miejscu-6945291797134144a.html](https://www.money.pl/pieniadze/sa-najnowsze-dane-o-bezrobociu-w-polsce-wykres-stanal-w-miejscu-6945291797134144a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T08:04:37+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/bfb09262-a322-4f27-8902-25829dd0ff94" width="308" /> Bezrobocie w sierpniu wyniosło 5 proc. - wynika z najnowszego komunikatu opublikowanego przez Główny Urząd Statystyczny. Stopa bezrobocia utrzymuje się na identycznym poziomie kolejny miesiąc.

## Integracja KSeF z innymi systemami księgowymi: Co trzeba wiedzieć?
 - [https://www.money.pl/gospodarka/integracja-ksef-z-innymi-systemami-ksiegowymi-co-trzeba-wiedziec-6945289526520640a.html](https://www.money.pl/gospodarka/integracja-ksef-z-innymi-systemami-ksiegowymi-co-trzeba-wiedziec-6945289526520640a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T07:45:00+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/955bcfa9-e8bd-47aa-8cbb-600537cb07fc" width="308" /> Wielu przedsiębiorców obawia się, że wraz ze wprowadzeniem obowiązku korzystania z KSeF (Krajowego Systemu e-Faktur) przy wystawianiu i odbieraniu ustrukturyzowanych faktur przybędzie im dodatkowych obowiązków. Przede wszystkim zamiast używania dotychczasowych programów i systemów księgowych, pojawi się konieczność wykorzystywania KSeF. Od kiedy to nastąpi? Co trzeba wiedzieć na temat KSeF i jego integracji z innymi systemami księgowymi?

## Emerytury stażowe. Alarmują: uderzy w całe społeczństwo
 - [https://www.money.pl/emerytury/emerytury-stazowe-pomysl-rodem-z-czasow-panszczyznianych-6945249050446592a.html](https://www.money.pl/emerytury/emerytury-stazowe-pomysl-rodem-z-czasow-panszczyznianych-6945249050446592a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:22:31+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c371a65c-9700-4b9d-b7d2-0235c643da1e" width="308" /> Po wygranych wyborach PiS chce wprowadzić emerytury stażowe. Eksperci ostrzegają: to krok w złym kierunku, bo w praktyce oznacza obniżenie wieku emerytalnego, podczas gdy ten powinien rosnąć.

## Kursy walut 25.09.2023. Poniedziałkowy kurs funta, euro, dolara i franka szwajcarskiego
 - [https://www.money.pl/pieniadze/kursy-walut-25-09-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6945252623493952a.html](https://www.money.pl/pieniadze/kursy-walut-25-09-2023-poniedzialkowy-kurs-funta-euro-dolara-i-franka-szwajcarskiego-6945252623493952a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:05:14+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/f25df134-ca5f-469f-b693-7773e001842b" width="308" /> Kursy walut - 25.09.2023. W poniedziałek za jednego dolara (USD) zapłacimy 4,32 zł. Cena jednego funta szterlinga (GBP) to 5,29 zł, a franka szwajcarskiego (CHF) 4,76 zł. Z kolei euro (EUR) możemy zakupić za 4,60 zł.

## Ile kosztuje funt? Kurs funta do złotego PLN/GBP 25.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-25-09-2023-6945251428211456a.html](https://www.money.pl/pieniadze/ile-kosztuje-funt-kurs-funta-do-zlotego-pln-gbp-25-09-2023-6945251428211456a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:00:26+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/c374eefc-9e8b-424a-aaa7-91759b47d116" width="308" /> Kurs funta szterlinga - 25.09.2023. W poniedziałek za jednego funta brytyjskiego (GBP) trzeba zapłacić 5.2895 zł.

## Ile kosztuje frank szwajcarski? Kurs franka do złotego PLN/CHF 25.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-25-09-2023-6945251419646720a.html](https://www.money.pl/pieniadze/ile-kosztuje-frank-szwajcarski-kurs-franka-do-zlotego-pln-chf-25-09-2023-6945251419646720a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:00:24+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/b1c04e3f-7bce-4c35-b03c-7a8d7b0adc65" width="308" /> Kurs franka szwajcarskiego - 25.09.2023. W poniedziałek za jednego franka (CHF) trzeba zapłacić 4.7594 zł.

## Ile kosztuje euro? Kurs euro do złotego PLN/EUR 25.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-25-09-2023-6945251410041600a.html](https://www.money.pl/pieniadze/ile-kosztuje-euro-kurs-euro-do-zlotego-pln-eur-25-09-2023-6945251410041600a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:00:21+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/cf3a8300-d9c9-461f-9fbc-2f314332a28c" width="308" /> Kurs euro - 25.09.2023. W poniedziałek za jedno euro (EUR) trzeba zapłacić 4.6014 zł.

## Ile kosztuje dolar? Kurs dolara do złotego PLN/USD 25.09.2023
 - [https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-25-09-2023-6945251400698624a.html](https://www.money.pl/pieniadze/ile-kosztuje-dolar-kurs-dolara-do-zlotego-pln-usd-25-09-2023-6945251400698624a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T05:00:19+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/e0ba71a8-9c02-482d-85dd-ebac5362ee3b" width="308" /> Kurs dolara - 25.09.2023. W poniedziałek za jednego dolara (USD) trzeba zapłacić 4.3208 zł.

## Fiskus chce od właścicielki stacji paliw 20 mln zł. "Nie zauważył, że zostałam uniewinniona"
 - [https://www.money.pl/podatki/fiskus-chce-od-wlascicielki-stacji-paliw-20-mln-zl-nie-zauwazyl-ze-zostalam-uniewinniona-6945250990410560a.html](https://www.money.pl/podatki/fiskus-chce-od-wlascicielki-stacji-paliw-20-mln-zl-nie-zauwazyl-ze-zostalam-uniewinniona-6945250990410560a.html)
 - RSS feed: https://www.money.pl/rss/
 - date published: 2023-09-25T04:58:34+00:00

<img src="https://i.wpimg.pl/308x/filerepo.grupawp.pl/api/v1/display/embed/eb3c34f0-ad3f-43bf-b77b-8fd1df59edd7" width="308" /> Właścicielka stacji paliw od 15 lat walczy z zarzutami fiskusa, który nałożył na nią domiar, wynoszący z odsetkami około 20 mln zł - pisze "Puls Biznesu". Bo choć w sprawie karnej sąd ją uniewinnił, to toczy się kilkadziesiąt spraw ze skarbówką w sądzie administracyjnym. Interwencję podjął rzecznik MŚP.

