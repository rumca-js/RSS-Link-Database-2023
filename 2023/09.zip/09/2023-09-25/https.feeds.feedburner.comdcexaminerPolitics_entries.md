# Source:Washington Examiner - politics, URL:https://feeds.feedburner.com/dcexaminer/Politics, language:en-US

## UAW strike: Where the 2024 candidates stand on the historic work stoppages
 - [https://www.washingtonexaminer.com/policy/economy/uaw-strike-where-2024-candidates-stand-work-stoppages](https://www.washingtonexaminer.com/policy/economy/uaw-strike-where-2024-candidates-stand-work-stoppages)
 - RSS feed: https://feeds.feedburner.com/dcexaminer/Politics
 - date published: 2023-09-25T17:32:36+00:00

The 2024 presidential candidates are wading into the strike against the “Big Three” automakers. Here is where they stand on the strike and negotiations.

