# Source:9to5Linux News, URL:https://9to5linux.com/category/news/feed, language:en-US

## LMDE (Linux Mint Debian Edition) 6 “Faye” Is Now Available for Download
 - [https://9to5linux.com/lmde-linux-mint-debian-edition-6-faye-is-now-available-for-download](https://9to5linux.com/lmde-linux-mint-debian-edition-6-faye-is-now-available-for-download)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-09-25T21:48:35+00:00

<p>LMDE (Linux Mint Debian Edition) 6 “Faye” is now available for download based on the Debian GNU/Linux 12 "Bookworm" operating system series. Here's what's new!</p>
<p>The post <a href="https://9to5linux.com/lmde-linux-mint-debian-edition-6-faye-is-now-available-for-download" rel="nofollow">LMDE (Linux Mint Debian Edition) 6 “Faye” Is Now Available for Download</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

## Firefox 118 Is Now Available for Download with Built-In Translation for Websites
 - [https://9to5linux.com/firefox-118-is-now-available-for-download-with-built-in-translation-for-websites](https://9to5linux.com/firefox-118-is-now-available-for-download-with-built-in-translation-for-websites)
 - RSS feed: https://9to5linux.com/category/news/feed
 - date published: 2023-09-25T14:46:38+00:00

<p>Mozilla Firefox 118 open-source web browser is now available for download with built-in translation feature for websites and other changes.</p>
<p>The post <a href="https://9to5linux.com/firefox-118-is-now-available-for-download-with-built-in-translation-for-websites" rel="nofollow">Firefox 118 Is Now Available for Download with Built-In Translation for Websites</a> appeared first on <a href="https://9to5linux.com" rel="nofollow">9to5Linux</a> - do not reproduce this article without permission. This RSS feed is intended for readers, not scrapers.</p>

