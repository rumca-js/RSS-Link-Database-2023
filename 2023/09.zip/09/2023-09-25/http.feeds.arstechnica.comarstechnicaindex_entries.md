# Source:ArsTechnica, URL:http://feeds.arstechnica.com/arstechnica/index/, language:en-US

## Bob Smith is finally gone from Blue Origin—his replacement comes from Amazon
 - [https://arstechnica.com/?p=1970954](https://arstechnica.com/?p=1970954)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T22:04:17+00:00

"I am confident that Blue Origin's greatest achievements are still ahead of us."

## Ford pauses work on $3.5 billion battery factory in Michigan
 - [https://arstechnica.com/?p=1970975](https://arstechnica.com/?p=1970975)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T21:30:53+00:00

The site was going to make lithium iron phosphate cells for electric vehicles.

## SEC obtains Wall Street firms’ private chats in probe of WhatsApp, Signal use
 - [https://arstechnica.com/?p=1970944](https://arstechnica.com/?p=1970944)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T21:03:03+00:00

Execs' "messages discussing business have been handed to the SEC," report says.

## The first foldable PC era is unfolding
 - [https://arstechnica.com/?p=1970796](https://arstechnica.com/?p=1970796)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T18:51:00+00:00

LG's 17-inch foldable OLED arrives October 4 for 4.99 million won (~$3,726).

## ChatGPT update enables its AI to “see, hear, and speak,“ according to OpenAI
 - [https://arstechnica.com/?p=1970737](https://arstechnica.com/?p=1970737)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T18:38:26+00:00

Image recognition and voice features aim to make the AI bot's interface more intuitive.

## Pixel 8 leak promises 7 years of OS updates—even more than an iPhone
 - [https://arstechnica.com/?p=1970816](https://arstechnica.com/?p=1970816)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T18:27:04+00:00

Just about everything has leaked about the $699 Pixel 8 and $999 8 Pro.

## Supreme Court considers limits on White House contacts with social media
 - [https://arstechnica.com/?p=1970846](https://arstechnica.com/?p=1970846)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T17:40:37+00:00

Controversial injunction stayed until Wednesday while SCOTUS mulls US motion.

## The 2024 BMW i7 M70—electric luxury turned up to 11
 - [https://arstechnica.com/?p=1970815](https://arstechnica.com/?p=1970815)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T17:28:03+00:00

Adding more power often adds little to the EV experience, but we like this one.

## Donna Noble is back and ready for a fight in trailer for Doctor Who specials
 - [https://arstechnica.com/?p=1970740](https://arstechnica.com/?p=1970740)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T16:29:07+00:00

"I don't believe in destiny, but if destiny exists, then it is heading for Donna Noble."

## Getty Images subscribers to get access to AI image generator
 - [https://arstechnica.com/?p=1970745](https://arstechnica.com/?p=1970745)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T13:38:16+00:00

Getty will indemnify customers against lawsuits and pay artists on "recurring basis."

## A partial car substitute? Trek’s new cargo bike, reviewed
 - [https://arstechnica.com/?p=1968104](https://arstechnica.com/?p=1968104)
 - RSS feed: http://feeds.arstechnica.com/arstechnica/index/
 - date published: 2023-09-25T11:30:48+00:00

A pricey but feature-rich offering from Trek had me pedaling for my groceries.

