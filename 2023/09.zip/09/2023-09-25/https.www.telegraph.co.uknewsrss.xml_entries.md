# Source:The Telegraph News, URL:https://www.telegraph.co.uk/news/rss.xml, language:en-UK

## David McCallum, star of hit TV series The Man From U.N.C.L.E. and NCIS, dies at 90
 - [https://www.telegraph.co.uk/news/2023/09/25/david-mccallum-ncis-actor-death/](https://www.telegraph.co.uk/news/2023/09/25/david-mccallum-ncis-actor-death/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T22:57:16+00:00



## Gatwick to restrict flights all week after Covid outbreak
 - [https://www.telegraph.co.uk/news/2023/09/25/gatwick-forced-to-restrict-flights-all-week-after-covid-out/](https://www.telegraph.co.uk/news/2023/09/25/gatwick-forced-to-restrict-flights-all-week-after-covid-out/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T17:58:26+00:00



## Monday evening news briefing: Shona Robison ‘disrespects’ Princess Royal
 - [https://www.telegraph.co.uk/news/2023/09/25/monday-evening-news-briefing-shona-robison-disrespects-prin/](https://www.telegraph.co.uk/news/2023/09/25/monday-evening-news-briefing-shona-robison-disrespects-prin/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T16:58:18+00:00



## Met Police investigating allegations of sexual assault following Russell Brand claims
 - [https://www.telegraph.co.uk/news/2023/09/25/russell-brand-met-police-allegations-sexual-assault-london/](https://www.telegraph.co.uk/news/2023/09/25/russell-brand-met-police-allegations-sexual-assault-london/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T16:05:53+00:00



## Motorcyclist killed after police pursuit in central London
 - [https://www.telegraph.co.uk/news/2023/09/25/motorcyclist-dies-police-chase-tottenham-court-road-london/](https://www.telegraph.co.uk/news/2023/09/25/motorcyclist-dies-police-chase-tottenham-court-road-london/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T13:43:07+00:00



## Lucy Letby to face retrial over attempted baby murder charge
 - [https://www.telegraph.co.uk/news/2023/09/25/lucy-letby-to-face-retrial-attempted-murder-allegation/](https://www.telegraph.co.uk/news/2023/09/25/lucy-letby-to-face-retrial-attempted-murder-allegation/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T11:03:20+00:00



## Lucy Letby to face retrial over attempted murder allegation
 - [https://www.telegraph.co.uk/news/2023/09/25/lucy-letby-to-face-retrial-attempted-murder-allegation0/](https://www.telegraph.co.uk/news/2023/09/25/lucy-letby-to-face-retrial-attempted-murder-allegation0/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T10:39:23+00:00



## Rapists will serve full prison sentences under new crime reforms
 - [https://www.telegraph.co.uk/news/2023/09/25/convicted-rapists-early-release-prison-sentence-rishi-sunak/](https://www.telegraph.co.uk/news/2023/09/25/convicted-rapists-early-release-prison-sentence-rishi-sunak/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T06:47:17+00:00



## In full: Mark Rowley's letter to Suella Braverman demanding legal protection for armed officers
 - [https://www.telegraph.co.uk/news/2023/09/25/mark-rowley-armed-met-police-chris-kaba-suella-braverman/](https://www.telegraph.co.uk/news/2023/09/25/mark-rowley-armed-met-police-chris-kaba-suella-braverman/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T06:43:23+00:00



## Man arrested after woman with 'horrific injuries' found dead inside flat
 - [https://www.telegraph.co.uk/news/2023/09/25/man-arrested-alison-dodds-found-dead-blackpool-flat/](https://www.telegraph.co.uk/news/2023/09/25/man-arrested-alison-dodds-found-dead-blackpool-flat/)
 - RSS feed: https://www.telegraph.co.uk/news/rss.xml
 - date published: 2023-09-25T04:08:34+00:00



