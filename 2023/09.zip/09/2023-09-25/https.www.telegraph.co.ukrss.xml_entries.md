# Source:The Telegraph Top Stories, URL:https://www.telegraph.co.uk/rss.xml, language:en-UK

## Who Killed Jill Dando? Netflix review: case that gripped Britain is still no closer to being solved
 - [https://www.telegraph.co.uk/tv/2023/09/26/who-killed-jill-dando-netflix-review/](https://www.telegraph.co.uk/tv/2023/09/26/who-killed-jill-dando-netflix-review/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T23:01:00+00:00



## Trump campaign backtracks on claim ex-president bought a gun as it could have broken law
 - [https://www.telegraph.co.uk/world-news/2023/09/25/trump-campaign-backtracks-on-claim-ex-president-bought-gun/](https://www.telegraph.co.uk/world-news/2023/09/25/trump-campaign-backtracks-on-claim-ex-president-bought-gun/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T22:34:35+00:00



## Pete Doherty, Who Killed My Son? review: a compelling plea for police to reopen this cold case
 - [https://www.telegraph.co.uk/tv/0/pete-doherty-who-killed-my-son-channel-4-review/](https://www.telegraph.co.uk/tv/0/pete-doherty-who-killed-my-son-channel-4-review/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T22:00:00+00:00



## Suella Braverman: ‘Absurd’ global refugee rules need radical reform
 - [https://www.telegraph.co.uk/politics/2023/09/25/suella-braverman-global-refugee-rules-need-radical-reform/](https://www.telegraph.co.uk/politics/2023/09/25/suella-braverman-global-refugee-rules-need-radical-reform/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T21:30:00+00:00



## What is a recession and how do I protect my savings and investments?
 - [https://www.telegraph.co.uk/money/consumer-affairs/what-recession-coming-uk-protect-savings-investments-2022/](https://www.telegraph.co.uk/money/consumer-affairs/what-recession-coming-uk-protect-savings-investments-2022/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T18:42:00+00:00



## Intense card game in Indonesia wins international photography competition
 - [https://www.telegraph.co.uk/world-news/2023/09/25/cewe-photo-award-2023-contest-winner-ariani-dikye-indonesia/](https://www.telegraph.co.uk/world-news/2023/09/25/cewe-photo-award-2023-contest-winner-ariani-dikye-indonesia/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T18:04:08+00:00



## Libya’s catastrophic flooding is turning into a rolling emergency
 - [https://www.telegraph.co.uk/global-health/climate-and-people/libyas-climate-catastrophe-flooding-disease/](https://www.telegraph.co.uk/global-health/climate-and-people/libyas-climate-catastrophe-flooding-disease/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T16:27:43+00:00



## England v Samoa, Rugby World Cup 2023: when is it and how to watch on TV
 - [https://www.telegraph.co.uk/rugby-union/2023/09/25/england-v-samoa-rugby-world-cup-2023-when-how-watch-tv/](https://www.telegraph.co.uk/rugby-union/2023/09/25/england-v-samoa-rugby-world-cup-2023-when-how-watch-tv/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T15:20:04+00:00



## Ryder Cup hole-by-hole guide: Marco Simone Golf and Country Club
 - [https://www.telegraph.co.uk/golf/2023/09/25/ryder-cup-2023-hole-by-hole-guide-marco-simone-golf-rome/](https://www.telegraph.co.uk/golf/2023/09/25/ryder-cup-2023-hole-by-hole-guide-marco-simone-golf-rome/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T12:53:46+00:00



## Ryder Cup 2023 tee times and schedule in full
 - [https://www.telegraph.co.uk/golf/2023/09/25/ryder-cup-2023-full-schedule-tee-times/](https://www.telegraph.co.uk/golf/2023/09/25/ryder-cup-2023-full-schedule-tee-times/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T12:51:06+00:00



## Experts fear mass wipe-out of penguins as Antarctica braces for bird flu
 - [https://www.telegraph.co.uk/global-health/science-and-disease/bird-flu-penguin-antarctica-virus-pandemic-argentina/](https://www.telegraph.co.uk/global-health/science-and-disease/bird-flu-penguin-antarctica-virus-pandemic-argentina/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T12:39:30+00:00



## Real American life, in a series of (very) brief encounters
 - [https://www.telegraph.co.uk/books/what-to-read/review-our-strangers-lydia-davis-ben-markovits/](https://www.telegraph.co.uk/books/what-to-read/review-our-strangers-lydia-davis-ben-markovits/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T11:00:00+00:00



## Why did 92,000 people turn up to watch a college volleyball game in Nebraska?
 - [https://www.telegraph.co.uk/womens-sport/2023/09/25/92000-people-college-volleyball-game-nebraska-cornhuskers/](https://www.telegraph.co.uk/womens-sport/2023/09/25/92000-people-college-volleyball-game-nebraska-cornhuskers/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T10:45:20+00:00



## Migrants help double amputee cross Rio Grande with daughter
 - [https://www.telegraph.co.uk/world-news/2023/09/25/rio-grande-migrants-us-crossing-joe-biden/](https://www.telegraph.co.uk/world-news/2023/09/25/rio-grande-migrants-us-crossing-joe-biden/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T10:35:08+00:00



## How to become a landlord: What you need to know before taking on tenants
 - [https://www.telegraph.co.uk/money/property/buy-to-let/how-become-landlord-rent-property-tenants/](https://www.telegraph.co.uk/money/property/buy-to-let/how-become-landlord-rent-property-tenants/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T09:07:54+00:00



## Ukraine-Russia war live: Odesa port damaged by Russian missile strikes
 - [https://www.telegraph.co.uk/world-news/2023/09/25/ukraine-russia-war-live-odesa-port-missile-attack-black-sea/](https://www.telegraph.co.uk/world-news/2023/09/25/ukraine-russia-war-live-odesa-port-missile-attack-black-sea/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T07:57:57+00:00



## Politics latest news: Scrapping HS2 would be 'act of huge economic self-harm', Heseltine and Osborne warn
 - [https://www.telegraph.co.uk/politics/2023/09/25/rishi-sunak-latest-news-live-hs2-osborne-heseltine-shapps/](https://www.telegraph.co.uk/politics/2023/09/25/rishi-sunak-latest-news-live-hs2-osborne-heseltine-shapps/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T07:22:41+00:00



## Canada House speaker apologises for honouring Nazi-linked veteran during Zelensky's visit
 - [https://www.telegraph.co.uk/world-news/2023/09/25/canada-house-speaker-sorry-zelensky-honouring-nazi/](https://www.telegraph.co.uk/world-news/2023/09/25/canada-house-speaker-sorry-zelensky-honouring-nazi/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T06:00:00+00:00



## Notorious Italian Mafia boss Matteo Messina Denaro dies in hospital
 - [https://www.telegraph.co.uk/world-news/2023/09/25/italian-mafia-boss-matteo-messina-denaro-dies/](https://www.telegraph.co.uk/world-news/2023/09/25/italian-mafia-boss-matteo-messina-denaro-dies/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T04:28:39+00:00



## Screenwriters reach tentative deal with Hollywood studios to end strike
 - [https://www.telegraph.co.uk/world-news/2023/09/25/screenwriters-reach-tentative-deal-hollywood-studios-strike/](https://www.telegraph.co.uk/world-news/2023/09/25/screenwriters-reach-tentative-deal-hollywood-studios-strike/)
 - RSS feed: https://www.telegraph.co.uk/rss.xml
 - date published: 2023-09-25T02:49:30+00:00



