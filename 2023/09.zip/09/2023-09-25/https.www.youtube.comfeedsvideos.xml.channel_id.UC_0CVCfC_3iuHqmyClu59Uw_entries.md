# Source:ETA PRIME, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw, language:en-US

## World‘s First Direct-Drive Pi Powered Self-Balancing Wheeled-Leg Robot! Diablo
 - [https://www.youtube.com/watch?v=S5PoZ8aNwvs](https://www.youtube.com/watch?v=S5PoZ8aNwvs)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UC_0CVCfC_3iuHqmyClu59Uw
 - date published: 2023-09-25T14:06:01+00:00

In this video we take look at Diablo! The World‘s First Direct-Drive Self-Balancing Wheeled-Leg Robot Powered by the Raspberry Pi 4! This little Or Medium Sized robot is amazing! Its Programmable &amp;has an Open-Development Platform so you can add your own modules.

https://shop.directdrive.com/products/diablo-world-s-first-direct-drive-self-balancing-wheeled-leg-robot

Follow Me On Twitter: https://twitter.com/theetaprime
Follow Me On Instagram: https://www.instagram.com/etaprime/

30% Code for software: ETA
Windows 10 Pro OEM Key($15): https://biitt.ly/KpEmf
Windows 11 Pro Key($21): https://biitt.ly/RUZiX
Windows10 Home Key($14): https://biitt.ly/2tPi1
Office 2019 pro key($46): https://biitt.ly/o0OQT
Office 2021 pro key($59): https://biitt.ly/iDMHc

Equipment I Use:
Monitor: Pixio 277 Pro On Amazon: https://amzn.to/3PGUBwe
Elgato HD60 X Screen Capture Device: https://amzn.to/3GkP2AL
Tool Kit: https://amzn.to/3Wo8bpX
Camera: https://amzn.to/3XJfFoI

DISCLAIMER: This video and descr

