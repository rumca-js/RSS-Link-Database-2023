# Source:Fox News, URL:https://moxie.foxnews.com/google-publisher/latest.xml, language:en-US

## Charlamagne Tha God labels Biden 'Donkey of the day' for referring to rapper LL Cool J as 'boy'
 - [https://www.foxnews.com/media/charlamagne-tha-god-labels-biden-donkey-day-referring-rapper-ll-cool-j-boy](https://www.foxnews.com/media/charlamagne-tha-god-labels-biden-donkey-day-referring-rapper-ll-cool-j-boy)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T23:00:38+00:00

Radio show host Charlamagne The God slammed Joe Biden on a podcast episode after the president made multiple gaffes during an award ceremony for a rapper.

## Late Model stock car teams brawl during qualifying at Martinsville
 - [https://www.foxnews.com/sports/late-model-stock-car-teams-brawl-qualifying-martinsville](https://www.foxnews.com/sports/late-model-stock-car-teams-brawl-qualifying-martinsville)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T22:57:03+00:00

Late Model stock car team members brawled in the garage area of Martinsville Speedway in Virginia on Sunday. The scuffle damaged another vehicle.

## Virginia man blames wife after TSA finds 'troubling' discovery in carry-on bag at Reagan National
 - [https://www.foxnews.com/us/virginia-man-blames-wife-tsa-finds-troubling-discovery-carry-bag-reagan-national](https://www.foxnews.com/us/virginia-man-blames-wife-tsa-finds-troubling-discovery-carry-bag-reagan-national)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T22:23:40+00:00

A Virginia man claimed his wife placed a loaded handgun in his carry-on bag after it was found by TSA officials on Sept. 21 Reagan National Airport.

## Tourists trespassing, blocking roads to take selfies, frustrate Vermont town: 'So much disrespect'
 - [https://www.foxnews.com/media/tourists-trespassing-blocking-roads-take-selfies-frustrate-vermont-town-disrespect](https://www.foxnews.com/media/tourists-trespassing-blocking-roads-take-selfies-frustrate-vermont-town-disrespect)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T22:00:03+00:00

A scenic Vermont town has been flooded with social media influencers taking photos every fall, prompting the town government to close roads to outside traffic.

## Security forces rescue 14 Nigerian students abducted by gunmen
 - [https://www.foxnews.com/world/security-forces-rescue-14-nigerian-students-abducted-gunmen](https://www.foxnews.com/world/security-forces-rescue-14-nigerian-students-abducted-gunmen)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:57:54+00:00

Security forces have rescued 14 of at least 20 Federal University Gusau students, who were abducted from the northwestern Nigerian school by gunmen last week.

## David McCallum, 'NCIS' actor, dead at 90
 - [https://www.foxnews.com/entertainment/david-mccallum-ncis-actor-dead-90](https://www.foxnews.com/entertainment/david-mccallum-ncis-actor-dead-90)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:54:34+00:00

David McCallum died of natural causes on Monday in New York. The Scottish-born actor was known for starring on &quot;NCIS&quot; for more than 400 episodes.

## Mexico, Biden admin considering program with UN to process 40,000 more migrants: report
 - [https://www.foxnews.com/us/mexico-biden-admin-considering-program-un-process-migrants-report](https://www.foxnews.com/us/mexico-biden-admin-considering-program-un-process-migrants-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:50:20+00:00

Mexico, the Biden Administration and the United Nations car considering a partnership to implement a program to pre-screen migrants from certain countries looking to enter the U.S.

## Menendez ripped by critics after 'shameless' defense of keeping over $400K in cash in his home: 'So corrupt'
 - [https://www.foxnews.com/politics/menendez-ripped-critics-shameless-defense-keeping-cash-home-corrupt](https://www.foxnews.com/politics/menendez-ripped-critics-shameless-defense-keeping-cash-home-corrupt)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:44:17+00:00

Sen. Bob Menendez, D-N.J., was blasted on social media Monday after he claimed that the nearly $500,000 in cash found at his home was from his personal bank account.

## Ex-Albanian environment minister gets almost 7 years in bribery case
 - [https://www.foxnews.com/world/ex-albanian-environment-minister-7-years-bribery-case](https://www.foxnews.com/world/ex-albanian-environment-minister-7-years-bribery-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:43:21+00:00

Former Albanian Environment Minister Lefter Koka has been sentenced to six years and eight months in prison for his role in a bribery scheme.

## Davante Adams on Raiders' early season struggles: 'I don’t got time to wait around'
 - [https://www.foxnews.com/sports/davante-adams-raiders-early-season-struggles-dont-got-time-to-wait-around](https://www.foxnews.com/sports/davante-adams-raiders-early-season-struggles-dont-got-time-to-wait-around)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:41:42+00:00

Davante Adams might be having a great start to the 2023 campaign, but the Las Vegas Raiders have lost their last two games despite his efforts.

## Kansas House Judiciary Committee head to step down
 - [https://www.foxnews.com/politics/kansas-house-judiciary-committee-head-step-down](https://www.foxnews.com/politics/kansas-house-judiciary-committee-head-step-down)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:40:59+00:00

Republican Kansas state Rep. Fred Patton, the chairman of the state&apos;s House Judiciary Committee, has announced his intent to vacate his seat next month.

## House Republicans announce first Biden impeachment inquiry hearing to be held this week
 - [https://www.foxnews.com/politics/house-republicans-announce-first-biden-impeachment-inquiry-hearing-held-this-week](https://www.foxnews.com/politics/house-republicans-announce-first-biden-impeachment-inquiry-hearing-held-this-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:30:26+00:00

The House Oversight Committee announced it will hold its first impeachment inquiry into President Biden on Thursday, where all evidence will be presented.

## Third suspect charged in connection to NYC daycare facility drug operation, resulting in death of 1-year-old
 - [https://www.foxnews.com/us/third-suspect-charged-connection-nyc-daycare-facility-drug-operation-resulting-death](https://www.foxnews.com/us/third-suspect-charged-connection-nyc-daycare-facility-drug-operation-resulting-death)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:25:48+00:00

The Department of Justice said a third suspect was charged in connection to a New York City daycare facility where a 1-year-old boy died of fentanyl exposure.

## Dengue fever: What you need to know about the mosquito-borne illness sweeping Jamaica
 - [https://www.foxnews.com/health/dengue-fever-what-you-need-know-mosquito-borne-illness-sweeping-jamaica](https://www.foxnews.com/health/dengue-fever-what-you-need-know-mosquito-borne-illness-sweeping-jamaica)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:21:47+00:00

Amid the outbreak of dengue fever currently sweeping Jamaica, health experts are warning about the dangers of the mosquito-borne illness. Here&apos;s what to know.

## 18-year-old tree trimmer killed after log rolls off trailer in northeast Indiana
 - [https://www.foxnews.com/us/18-year-old-tree-trimmer-killed-log-rolls-trailer-northeast-indiana](https://www.foxnews.com/us/18-year-old-tree-trimmer-killed-log-rolls-trailer-northeast-indiana)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:20:52+00:00

Braeden Depew, an 18-year-old tree-trimming service employee from Kokomo, Indiana, has been reported dead after being struck by a log that fell from a trailer.

## 3 dead after high-speed crash in rural Maine
 - [https://www.foxnews.com/us/3-dead-high-speed-crash-rural-maine](https://www.foxnews.com/us/3-dead-high-speed-crash-rural-maine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:18:24+00:00

A vehicle veered off a road in Glenburn, Maine, early Sunday morning, crashing into a culvert, rolling over, and killing all three of its occupants.

## Biden allies say White House finds 3rd party candidates 'pretty f---ing concerning'
 - [https://www.foxnews.com/media/biden-allies-say-white-house-finds-3rd-party-candidates-pretty-f-ing-concerning](https://www.foxnews.com/media/biden-allies-say-white-house-finds-3rd-party-candidates-pretty-f-ing-concerning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T21:00:31+00:00

President Biden is reportedly &quot;worried&quot; about third-party spoilers in 2024 with people close to the White House saying it&apos;s &quot;pretty f---ing concerning.&quot;

## Ford's Theatre tickets from night of Lincoln assassination sell for $262.5K at auction
 - [https://www.foxnews.com/us/fords-theatre-tickets-night-lincoln-assassination-sell-262-5k-auction](https://www.foxnews.com/us/fords-theatre-tickets-night-lincoln-assassination-sell-262-5k-auction)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:53:22+00:00

Two front-row balcony tickets to Ford&apos;s Theatre for April 14, 1865 — the night John Wilkes Booth assassinated President Abraham Lincoln — sold at auction for $262,500.

## PA state trooper accused of abusing position to forcibly commit ex-girlfriend to psych ward
 - [https://www.foxnews.com/us/pa-state-trooper-accused-abusing-position-forcibly-commit-ex-girlfriend-psych-ward](https://www.foxnews.com/us/pa-state-trooper-accused-abusing-position-forcibly-commit-ex-girlfriend-psych-ward)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:51:50+00:00

Ronald Davis, a Pennsylvania state trooper, has been charged on several criminal counts for using his position to involuntarily commit his ex-girlfriend to a psychiatric facility.

## Michigan woman gets up to 5 years for sons' drowning deaths in icy pond crash
 - [https://www.foxnews.com/us/michigan-woman-5-years-sons-drowning-deaths-icy-pond-crash](https://www.foxnews.com/us/michigan-woman-5-years-sons-drowning-deaths-icy-pond-crash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:50:14+00:00

Leticia Gonzales has been sentenced to up to five years in prison for leaving her three young sons to drown in an icy pond after a Holland Township, Michigan, car crash.

## Bahraini officer and soldier killed in drone attack on Yemeni-Saudi border
 - [https://www.foxnews.com/world/bahraini-officer-soldier-killed-drone-attack-yemeni-saudi-border](https://www.foxnews.com/world/bahraini-officer-soldier-killed-drone-attack-yemeni-saudi-border)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:48:32+00:00

A drone strike launched by Yemeni rebels resulted in the deaths of a Bahraini officer and a soldier while they were patrolling the Yemeni-Saudi border.

## Megan Rapinoe maintains national anthem protest before final USWNT match
 - [https://www.foxnews.com/sports/megan-rapinoe-maintains-national-anthem-protest-final-uswnt-match](https://www.foxnews.com/sports/megan-rapinoe-maintains-national-anthem-protest-final-uswnt-match)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:47:42+00:00

Megan Rapinoe maintained her national anthem protest on Sunday before her final match for the U.S. women&apos;s national team against South Africa.

## JetBlue flight encounters severe turbulence during Florida landing, injuring 7 passengers, 1 crew member
 - [https://www.foxnews.com/us/jetblue-flight-encounters-severe-turbulence-florida-landing-injuring-7-passengers-1-crew-member](https://www.foxnews.com/us/jetblue-flight-encounters-severe-turbulence-florida-landing-injuring-7-passengers-1-crew-member)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:45:40+00:00

A JetBlue flight originating from Ecuador and bound for Fort Lauderdale encountered severe turbulence during its landing in Florida, resulting in eight injuries.

## Ex-NASCAR driver Austin Theriault launches GOP bid for battleground House seat
 - [https://www.foxnews.com/politics/ex-nascar-driver-austin-theriault-launches-gop-bid-battleground-house-seat](https://www.foxnews.com/politics/ex-nascar-driver-austin-theriault-launches-gop-bid-battleground-house-seat)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:44:04+00:00

Republican Maine state Rep. Austin Theriault, a former NASCAR driver, has announced his bid to represent the state&apos;s rural north in Congress.

## Bruce Willis’ FTD battle: Expert shares warning signs, what to know about the condition
 - [https://www.foxnews.com/health/bruce-willis-ftd-battle-expert-warning-signs-what-know-condition](https://www.foxnews.com/health/bruce-willis-ftd-battle-expert-warning-signs-what-know-condition)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:39:55+00:00

The Association for Frontotemporal Degeneration CEO Susan Dickinson joined the &apos;TODAY&apos; show to speak about actor Bruce Willis&apos; health status and details of the disease.

## Republicans send letter to Jake Sullivan demanding 'total figures' for Ukraine aid
 - [https://www.foxnews.com/politics/republicans-send-letter-jake-sullivan-demanding-total-figures-ukraine-aid](https://www.foxnews.com/politics/republicans-send-letter-jake-sullivan-demanding-total-figures-ukraine-aid)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:38:39+00:00

GOP lawmakers demand clarity from national security adviser Jake Sullivan on Ukraine aid, citing a $31.1 billion discrepancy in reported figures.

## Portland police to pay nearly $700,000 to former official who pushed to defund department
 - [https://www.foxnews.com/us/portland-police-pay-nearly-700000-former-official-pushed-defund-department](https://www.foxnews.com/us/portland-police-pay-nearly-700000-former-official-pushed-defund-department)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:30:25+00:00

Police in Portland, Oregon, agreed to pay a former city commissioner $680,000 to settle claims that they leaked information falsely implicating her in a crime.

## European Union member states weaken proposal to lower vehicle emissions
 - [https://www.foxnews.com/world/european-union-member-states-weaken-proposal-lower-vehicle-emissions](https://www.foxnews.com/world/european-union-member-states-weaken-proposal-lower-vehicle-emissions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:20:03+00:00

European Union member states have diluted the European Commission&apos;s proposal to update pollution standards for new combustion engine vehicles.

## Journalist and police officer killed in crossfire in northern Mexico border town, 3 others injured
 - [https://www.foxnews.com/world/journalist-police-officer-killed-crossfire-northern-mexico-border-town-3-others-injured](https://www.foxnews.com/world/journalist-police-officer-killed-crossfire-northern-mexico-border-town-3-others-injured)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:18:41+00:00

A journalist running a community news page on Facebook passed away in the northern Mexican border town of San Luis Rio Colorado on Monday.

## South Carolina high school mourns loss of 3 students in weekend shooting
 - [https://www.foxnews.com/us/south-carolina-high-school-mourns-loss-3-students-weekend-shooting](https://www.foxnews.com/us/south-carolina-high-school-mourns-loss-3-students-weekend-shooting)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:16:34+00:00

A South Carolina high school is grappling with grief following a shooting over the weekend that claimed the lives of three teenage students.

## Arizona woman fired shots at 2 juveniles in Walmart parking lot drive-by, police say
 - [https://www.foxnews.com/us/arizona-woman-fired-shots-2-juveniles-walmart-parking-lot-drive-by-police-say](https://www.foxnews.com/us/arizona-woman-fired-shots-2-juveniles-walmart-parking-lot-drive-by-police-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:14:48+00:00

An Arizona woman allegedly shot at two juveniles at a Walmart parking lot after getting into an altercation with the pair, Goodyear police said Monday.

## Smithsonian's planned Latino museum is woke move designed to radicalize US Hispanics
 - [https://www.foxnews.com/opinion/smithsonians-planned-latino-museum-woke-move-designed-radicalize-us-hispanics](https://www.foxnews.com/opinion/smithsonians-planned-latino-museum-woke-move-designed-radicalize-us-hispanics)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:08:46+00:00

The outcry over plans for the Smithsonian&apos;s Latino Museum continues to grow. The leadership of the organization wants to focus on the evils of capitalism and victimhood.

## White House weighs in on Bob Menendez charges, declines to call for resignation
 - [https://www.foxnews.com/politics/white-house-weighs-bob-menendez-charges-declines-call-resignation](https://www.foxnews.com/politics/white-house-weighs-bob-menendez-charges-declines-call-resignation)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:06:34+00:00

The White House weighed in on the charges against Sen. Bob Menendez on Monday, saying it was a &quot;serious matter&quot; but declining to call for his resignation.

## Video shows overcrowding at Eagle Pass, Texas border processing facility; Dem mayor blames Biden
 - [https://www.foxnews.com/us/video-shows-overcrowding-eagle-pass-texas-border-processing-facility-dem-mayor-blames-biden](https://www.foxnews.com/us/video-shows-overcrowding-eagle-pass-texas-border-processing-facility-dem-mayor-blames-biden)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:03:59+00:00

A migrant processing center in Eagle Pass, Texas was overwhelmed over the weekend as over 4,000 migrants were waiting to be processed in a tent made for 1,000.

## 'The View' co-host urges Biden to take bad polling seriously, not take any votes 'for granted'
 - [https://www.foxnews.com/media/the-view-co-host-urges-biden-take-polling-seriously-not-take-votes-granted](https://www.foxnews.com/media/the-view-co-host-urges-biden-take-polling-seriously-not-take-votes-granted)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T20:00:47+00:00

Ana Navarro said Monday during &quot;The View&quot; that President Biden should &quot;learn&quot; from the results of an &quot;off-the-charts&quot; ABC/Washington Post poll showing him losing in 2024.

## WATCH: Karine Jean-Pierre dodges when pressed on Biden's sour approval rating, age, mental fitness
 - [https://www.foxnews.com/politics/karine-jean-pierre-dodges-pressed-biden-sour-approval-rating-age-mental-fitness](https://www.foxnews.com/politics/karine-jean-pierre-dodges-pressed-biden-sour-approval-rating-age-mental-fitness)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:50:50+00:00

White House press secretary Karine Jean-Pierre dodged questions on President Biden&apos;s underwater approval rating during the daily White House press briefing.

## Driver involved in Treat Williams' fatal accident pleads not guilty, faces 15 years in prison
 - [https://www.foxnews.com/entertainment/driver-involved-treat-williams-fatal-accident-pleads-not-guilty-faces-15-years-prison](https://www.foxnews.com/entertainment/driver-involved-treat-williams-fatal-accident-pleads-not-guilty-faces-15-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:44:24+00:00

The driver involved in the crash that killed actor Treat Williams pleaded not guilty to a charge connected to the accident. The &quot;Blue Bloods&quot; star died June 12.

## NFL MVP shoots down Jets' speculation amid quarterback woes: 'No interest in doing that right now'
 - [https://www.foxnews.com/sports/nfl-mvp-shoots-down-jets-speculation-quarterback-woes-no-interest-doing-right-now](https://www.foxnews.com/sports/nfl-mvp-shoots-down-jets-speculation-quarterback-woes-no-interest-doing-right-now)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:42:04+00:00

The New York Jets may be in the market for a veteran quarterback, but former league MVP Matt Ryan won&apos;t be their guy. Ryan shot down the idea Monday.

## At least 3 dead, 15 missing after Guatemala landslide
 - [https://www.foxnews.com/world/3-dead-15-missing-guatemala-landslide](https://www.foxnews.com/world/3-dead-15-missing-guatemala-landslide)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:35:20+00:00

A landslide in Guatemala&apos;s capital was triggered early Monday amid heavy rains, leaving at least three people dead and 15 others unaccounted for.

## Mexican president addresses town isolation due to drug cartel turf battles in Chiapas
 - [https://www.foxnews.com/world/mexican-president-addresses-town-isolation-due-drug-cartel-turf-battles-chiapas](https://www.foxnews.com/world/mexican-president-addresses-town-isolation-due-drug-cartel-turf-battles-chiapas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:25:21+00:00

Drug cartel conflicts have led to the isolation of several towns in the southern Mexican state of Chiapas, near the Guatemala border, as acknowledged by Mexico&apos;s President.

## Commercial building blaze south of Benin's capital kills at least 35 people
 - [https://www.foxnews.com/world/commercial-building-blaze-south-benins-capital-kills-least-35-people](https://www.foxnews.com/world/commercial-building-blaze-south-benins-capital-kills-least-35-people)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:23:10+00:00

A fire occurred in a commercial building situated south of Benin&apos;s capital, resulting in the loss of a minimum of 35 lives, as confirmed by authorities.

## Japan's Kishida teases new economic package amid waning support for conservative government
 - [https://www.foxnews.com/world/japans-kishida-teases-new-economic-package-waning-support-conservative-government](https://www.foxnews.com/world/japans-kishida-teases-new-economic-package-waning-support-conservative-government)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:20:59+00:00

Right-wing Japanese Prime Minister Fumio Kishida on Monday revealed the general idea behind a new economic package, which comes as his Cabinet grapples with dwindling support.

## Coal mine fire claims 16 lives in southern China despite industry safety improvements
 - [https://www.foxnews.com/world/coal-mine-fire-claims-16-lives-southern-china-despite-industry-safety-improvements](https://www.foxnews.com/world/coal-mine-fire-claims-16-lives-southern-china-despite-industry-safety-improvements)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:18:41+00:00

A coal mine fire in southern China resulted in the loss of 16 lives on Sunday, as reported by local authorities. The incident occurred at the Shanjiaoshu coal mine located in Panguan.

## Poland's foreign minister accuses Germany of interference over visa allegations
 - [https://www.foxnews.com/world/polands-foreign-minister-accuses-germany-interference-visa-allegations](https://www.foxnews.com/world/polands-foreign-minister-accuses-germany-interference-visa-allegations)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:16:50+00:00

Poland&apos;s foreign minister accused Germany of meddling in country&apos;s internal affairs after chancellor urged Poland to clarify allegations of Polish consulates in Africa and Asia selling temporary work visas to migrants for substantial sums.

## Off-duty Texas trooper shoots neighbor he believed was trying to break into his apartment
 - [https://www.foxnews.com/us/off-duty-texas-trooper-shoots-neighbor-he-believed-was-trying-break-apartment](https://www.foxnews.com/us/off-duty-texas-trooper-shoots-neighbor-he-believed-was-trying-break-apartment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:15:58+00:00

An off-duty Texas trooper suspect a man who he believed was trying to break into his Houston apartment unit early Monday morning and wounded him once, police said.

## Florida deputies fatally shoot armed individual after threats and gunfire incident
 - [https://www.foxnews.com/us/florida-deputies-fatally-shoot-armed-individual-threats-gunfire-incident](https://www.foxnews.com/us/florida-deputies-fatally-shoot-armed-individual-threats-gunfire-incident)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:13:35+00:00

Florida sheriff&apos;s deputies fatally shot an individual who had been brandishing a firearm at passing vehicles during the early hours of Sunday.

## Leslie Jones shares more details on racist Ghostbusters backlash, 'death threats': report
 - [https://www.foxnews.com/media/leslie-jones-shares-more-details-racist-ghostbusters-backlash-death-threats-report](https://www.foxnews.com/media/leslie-jones-shares-more-details-racist-ghostbusters-backlash-death-threats-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:06:34+00:00

Actress Leslie Jones, who starred in the 2016 &quot;Ghostbusters&quot; reboot, shared details in her memoir about the backlash against her role in the iconic movie series.

## Mali junta postpones 2024 election, delaying return to democratic rule
 - [https://www.foxnews.com/world/mali-junta-postpones-2024-election-delaying-return-democratic-rule](https://www.foxnews.com/world/mali-junta-postpones-2024-election-delaying-return-democratic-rule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:01:26+00:00

Mali&apos;s military-run government has delayed its planned February 2024 presidential election for &quot;technical reasons,&quot; postponing an expected return to civilian rule.

## Republicans likely to pursue Biden's personal bank records in impeachment inquiry, Comer says
 - [https://www.foxnews.com/media/republicans-likely-pursue-bidens-personal-bank-records-impeachment-inquiry-comer-says](https://www.foxnews.com/media/republicans-likely-pursue-bidens-personal-bank-records-impeachment-inquiry-comer-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T19:00:04+00:00

House Oversight Chairman Rep. James Comer details his request for unredacted Biden emails from the National Archives and the president&apos;s personal records.

## Amusement park guests left 75 feet upside down for nearly 30 minutes on 'Lumberjack' ride
 - [https://www.foxnews.com/world/amusement-park-guests-left-feet-upside-down-nearly-minutes-lumberjack-ride](https://www.foxnews.com/world/amusement-park-guests-left-feet-upside-down-nearly-minutes-lumberjack-ride)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:58:03+00:00

Guests at Canada&apos;s Wonderland amusement park on Saturday were left upside down on a ride for almost 30 minutes, according to a park spokesperson.

## GOP bill to safeguard US agriculture from China advances with heavy bipartisan support
 - [https://www.foxnews.com/politics/republican-bill-safeguard-us-agriculture-china-advances-heavy-bipartisan-support](https://www.foxnews.com/politics/republican-bill-safeguard-us-agriculture-china-advances-heavy-bipartisan-support)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:37:56+00:00

Republican-led legislation to empower the Department of Agriculture in decisions over national security threats is advancing through the House with heavy bipartisan support.

## British university employees stage another round of strikes as new term begins
 - [https://www.foxnews.com/world/british-university-employees-stage-round-strikes-new-term-begins](https://www.foxnews.com/world/british-university-employees-stage-round-strikes-new-term-begins)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:29:50+00:00

Staff at 40 U.K. universities have staged another round of strike action, the latest in an ongoing dispute over compensation and work conditions.

## Fugitive using dead man's ID cackles after he's finally nabbed: video
 - [https://www.foxnews.com/us/fugitive-using-dead-mans-id-cackles-after-finally-nabbed-video](https://www.foxnews.com/us/fugitive-using-dead-mans-id-cackles-after-finally-nabbed-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:29:20+00:00

Greg Lawson, now 63, was convicted of attempted murder in 1991, but fled the courtroom before the jury&apos;s guilty verdict and vanished for over three decades.

## Egypt sets December presidential election date
 - [https://www.foxnews.com/world/egypt-sets-december-presidential-election-date](https://www.foxnews.com/world/egypt-sets-december-presidential-election-date)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:28:16+00:00

Egypt has scheduled a presidential election that will be held over three days in December, and will likely result in incumbent Abdel Fattah el-Sissi retaining power.

## Biologists race to help North America’s largest and rarest tortoise species
 - [https://www.foxnews.com/us/biologists-race-help-north-americas-largest-rarest-tortoise-species](https://www.foxnews.com/us/biologists-race-help-north-americas-largest-rarest-tortoise-species)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:26:03+00:00

Conservationists are pushing the U.S. government to craft a recovery plan for America’s Bolson tortoises, the largest and rarest tortoise species in the county.

## Indianapolis police kill man, injure woman after one of the 2 suspects fired at officers
 - [https://www.foxnews.com/us/indianapolis-police-kill-man-injures-woman-one-2-suspects-fired-officers](https://www.foxnews.com/us/indianapolis-police-kill-man-injures-woman-one-2-suspects-fired-officers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:14:44+00:00

Police and an armed robbery suspect exchanged gunfire Friday night. The police in Indianapolis, Indiana, fatally shot a man and injured a woman.

## Burmese army ambush kills 2 dozen local resistance force fighters
 - [https://www.foxnews.com/world/burmese-army-ambush-kills-2-dozen-local-resistance-force-fighters](https://www.foxnews.com/world/burmese-army-ambush-kills-2-dozen-local-resistance-force-fighters)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:04:06+00:00

Approximately two dozen members of local resistance forces in Burma have reportedly been killed in an army ambush, media and anti-government forces claim.

## Oklahoma authorities arrest suspect after gunshots erupt at State Fair
 - [https://www.foxnews.com/us/oklahoma-authorities-arrest-suspect-after-gunshots-erupt-state-fair](https://www.foxnews.com/us/oklahoma-authorities-arrest-suspect-after-gunshots-erupt-state-fair)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:02:40+00:00

A suspect tied to a shooting that broke out at the Oklahoma State Fair on Sunday has been arrested. One wounded person was also taken to the hospital with critical injuries.

## UAW Strike: Biden has started a war Democrats can't win. It's greens vs. unions
 - [https://www.foxnews.com/opinion/uaw-strike-biden-started-war-democrats-win-greens-unions](https://www.foxnews.com/opinion/uaw-strike-biden-started-war-democrats-win-greens-unions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:02:39+00:00

The UAW strike has revealed something very important about the state of today&apos;s Democratic Party. Joe Biden has pitted the labor wing of his party against the greens. How does it end?

## All eyes on NJ Gov Murphy if Menendez changes course and resigns unexpectedly
 - [https://www.foxnews.com/politics/all-eyes-nj-gov-murphy-menendez-changes-course-resigns-unexpectedly](https://www.foxnews.com/politics/all-eyes-nj-gov-murphy-menendez-changes-course-resigns-unexpectedly)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T18:01:10+00:00

Sen. Bob Menendez is facing growing calls to resign from the Senate following corruption charges. Here is what happens if he were to step down.

## Sean Hannity to moderate groundbreaking debate between Governors Newsom, DeSantis
 - [https://www.foxnews.com/media/sean-hannity-moderate-groundbreaking-debate-between-governors-newsom-desantis](https://www.foxnews.com/media/sean-hannity-moderate-groundbreaking-debate-between-governors-newsom-desantis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:56:38+00:00

Sean Hannity will moderate a debate between Florida Governor Ron DeSantis and Democrat California Governor Gavin Newsom, FOX News Media announced on Monday.

## UN experts uncover ongoing war crimes by Russian forces in Ukraine
 - [https://www.foxnews.com/us/un-experts-uncover-ongoing-war-crimes-russian-forces-ukraine](https://www.foxnews.com/us/un-experts-uncover-ongoing-war-crimes-russian-forces-ukraine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:56:27+00:00

Human rights experts backed by the United Nations announced on Monday that they have uncovered ongoing evidence of war crimes committed by Russian forces in the Ukraine conflict.

## Former New Mexico deputy faces federal charges in alleged sexual assault case
 - [https://www.foxnews.com/us/former-new-mexico-deputy-faces-federal-charges-alleged-sexual-assault-case](https://www.foxnews.com/us/former-new-mexico-deputy-faces-federal-charges-alleged-sexual-assault-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:54:29+00:00

A former county sheriff&apos;s deputy in New Mexico is currently facing federal charges that stem from an alleged sexual assault and carry the potential for a life sentence.

## More and more schools across the US adopt 4-day learning weeks
 - [https://www.foxnews.com/us/more-more-schools-across-us-adopt-4-day-learning-weeks](https://www.foxnews.com/us/more-more-schools-across-us-adopt-4-day-learning-weeks)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:52:43+00:00

Hundreds of school systems across the U.S. are adopting four-day learning weeks despite students already struggling to catch up academically post-pandemic.

## Shooting in South Carolina's capital claims lives of 3 teenagers
 - [https://www.foxnews.com/us/shooting-south-carolinas-capital-claims-lives-3-teenagers](https://www.foxnews.com/us/shooting-south-carolinas-capital-claims-lives-3-teenagers)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:52:16+00:00

A shooting incident took place on Sunday afternoon in Columbia, South Carolina, resulting in the deaths of three teenagers and injuries to another individual.

## Washington Commanders 'fitting name for oppressors' Native American group claims in new federal lawsuit
 - [https://www.foxnews.com/sports/washington-commanders-fitting-name-oppressors-native-american-group-claims-new-federal-lawsuit](https://www.foxnews.com/sports/washington-commanders-fitting-name-oppressors-native-american-group-claims-new-federal-lawsuit)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:50:21+00:00

The Native American Guardians Association filed a lawsuit against the Washington Commanders on Sept. 25, 2023 accusing it of contributing to cultural oppression.

## Renewed clashes erupt in Ethiopia's Amhara region over disarmament dispute
 - [https://www.foxnews.com/world/renewed-clashes-erupt-ethiopias-amhara-region-disarmament-dispute](https://www.foxnews.com/world/renewed-clashes-erupt-ethiopias-amhara-region-disarmament-dispute)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:49:57+00:00

Clashes erupted in the second-largest city of Ethiopia&apos;s tumultuous Amhara region as militiamen clashed with the military over the government&apos;s intentions to disarm local armed groups.

## Pakistani journalist advocating for jailed ex-Prime Minister Imran Khan finally freed from captivity
 - [https://www.foxnews.com/world/pakistani-journalist-advocating-jailed-ex-prime-minister-imran-khan-finally-freed-captivity](https://www.foxnews.com/world/pakistani-journalist-advocating-jailed-ex-prime-minister-imran-khan-finally-freed-captivity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:48:25+00:00

A Pakistani television journalist who had been missing for over four months following his arrest has been released and returned home, according to law enforcement officials.

## In Libya, 8 officials detained after the collapse of 2 dams that caused thousands of deaths
 - [https://www.foxnews.com/world/libya-8-officials-detained-collapse-2-dams-caused-thousands-deaths](https://www.foxnews.com/world/libya-8-officials-detained-collapse-2-dams-caused-thousands-deaths)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:48:17+00:00

On Sept. 11, two dams collapsed during Mediterranean Storm Danial and sent a wave of water that caused thousands of deaths. Officials managing the dam were arrested over negligence.

## Kate Beckinsale slams haters and their ‘fairly constant… bullying’
 - [https://www.foxnews.com/entertainment/kate-beckinsale-slams-haters-fairly-constant-bullying](https://www.foxnews.com/entertainment/kate-beckinsale-slams-haters-fairly-constant-bullying)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:45:40+00:00

Kate Beckinsale blasted her social media followers who contribute to the &quot;bullying&apos; she receives while also voicing her appreciation for those who stay positive.

## 'Zombie apocalypse': San Francisco on track to crush overdose death record as addicts die in the streets
 - [https://www.foxnews.com/us/zombie-apocalypse-san-francisco-track-crush-overdose-death-record-addicts-die-streets](https://www.foxnews.com/us/zombie-apocalypse-san-francisco-track-crush-overdose-death-record-addicts-die-streets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:37:39+00:00

Fentanyl-related overdose deaths in San Francisco have skyrocketed since 2017. With over 500 fatalities already, 2023 is on track to be the deadliest year yet.

## Locals in Hawaii return to sites of homes wrecked by August’s Lahaina wildfire
 - [https://www.foxnews.com/world/hawaii-locals-return-sites-homes-wrecked-augusts-lahaina-wildfire](https://www.foxnews.com/world/hawaii-locals-return-sites-homes-wrecked-augusts-lahaina-wildfire)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:22:01+00:00

Authorities in Hawaii have begun allowing residents of Lahaina to return to their historic town following one of America’s deadliest wildfires that scorched the region last month.

## Russia puts International Criminal Court president on wanted list: reports
 - [https://www.foxnews.com/world/russia-puts-international-criminal-court-president-wanted-list-reports](https://www.foxnews.com/world/russia-puts-international-criminal-court-president-wanted-list-reports)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:19:37+00:00

International Criminal Court President Piotr Hofmanski was placed on Russia&apos;s wanted list, joining several other judges and prosecutors with the court.

## How to easily connect headphones to your TV for great sound
 - [https://www.foxnews.com/tech/easily-connect-headphones-tv-great-sound](https://www.foxnews.com/tech/easily-connect-headphones-tv-great-sound)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:12:27+00:00

Kurt &quot;CyberGuy&quot; Knutsson shows your how to enjoy watching television shows and movies by connecting your wireless headphones to your TV.

## Jury selection to begin in New Mexico after authorities find remains of a 3-year-old in underground tunnel
 - [https://www.foxnews.com/us/jury-selection-begin-new-mexico-after-authorities-find-remains-3-year-old-underground-tunnel](https://www.foxnews.com/us/jury-selection-begin-new-mexico-after-authorities-find-remains-3-year-old-underground-tunnel)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:07:59+00:00

A trial is set to begin against members of an extended family tied to a missing 3-year-old whose remains were found in New Mexico raid of their squalid encampment.

## Braves mascot channels Derrick Henry with brutal stiff arm on youth football player during Vikings halftime
 - [https://www.foxnews.com/sports/braves-mascot-channels-derrick-henry-brutal-stiff-arm-youth-football-player-vikings-halftime](https://www.foxnews.com/sports/braves-mascot-channels-derrick-henry-brutal-stiff-arm-youth-football-player-vikings-halftime)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:02:30+00:00

Blooper, the Atlanta Braves official mascot, went viral on social media Sunday night after his performance against a youth football team during halftime of the Vikings-Chargers game.

## San Francisco left-wing official lashes out at Elon Musk after billionaire calls for his firing
 - [https://www.foxnews.com/media/san-francisco-left-wing-official-lashes-elon-musk-billionaire-calls-his-firing](https://www.foxnews.com/media/san-francisco-left-wing-official-lashes-elon-musk-billionaire-calls-his-firing)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T17:00:34+00:00

A San Francisco County Supervisor fired back at Elon Musk after the billionaire claimed Dean Preston was likely responsible for the &quot;destruction&quot; of the city.

## 2 dead, 2 injured near Honolulu after shooting breaks out at boat harbor
 - [https://www.foxnews.com/us/2-dead-2-injured-honolulu-shooting-breaks-boat-harbor](https://www.foxnews.com/us/2-dead-2-injured-honolulu-shooting-breaks-boat-harbor)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T16:51:08+00:00

An early morning shooting at a boat harbor near Honolulu, Hawaii, has left two dead and two others injured. Authorities are still searching for a suspect.

## Lions' Sam LaPorta makes NFL history in win over Falcons
 - [https://www.foxnews.com/sports/lions-sam-laporta-makes-nfl-history-win-falcons](https://www.foxnews.com/sports/lions-sam-laporta-makes-nfl-history-win-falcons)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T16:47:29+00:00

Detroit Lions rookie tight end Sam LaPorta is already in the history books and it took him three games to do it. He had a touchdown on Sunday vs the Falcons.

## Democrat Rep Eric Swalwell calls House Republicans' impeachment inquiry a 'continuation of the insurrection'
 - [https://www.foxnews.com/politics/democrat-rep-eric-swalwell-calls-house-republicans-impeachment-inquiry-continuation-insurrection](https://www.foxnews.com/politics/democrat-rep-eric-swalwell-calls-house-republicans-impeachment-inquiry-continuation-insurrection)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T16:46:55+00:00

Rep. Swalwell accuses House GOP&apos;s President Biden impeachment inquiry of being a &quot;Jan. 6 insurrection continuation&quot; and criticizes their loyalty to former President Trump.

## Never lose track of text messages again by pinning them
 - [https://www.foxnews.com/tech/never-lose-track-text-messages-again-pinning](https://www.foxnews.com/tech/never-lose-track-text-messages-again-pinning)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T16:40:42+00:00

Kurt &quot;CyberGuy&quot; Knutsson helps you to keep track of those important texts that you may want to keep track of for both iPhone and Android users.

## UN says Russian troops torturing Ukrainians to death, reveals 1 survivor suffered shocks for ‘an eternity’
 - [https://www.foxnews.com/world/un-says-russian-troops-torturing-ukrainians-death-reveals-one-survivor-suffered-shocks-eternity](https://www.foxnews.com/world/un-says-russian-troops-torturing-ukrainians-death-reveals-one-survivor-suffered-shocks-eternity)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T16:36:31+00:00

A commission ordered by the U.N. is detailing what it says is &quot;continued evidence&quot; that Russian troops are &quot;committing war crimes&quot; in Ukraine.

## Democrat Gov. Kathy Hochul calls in National Guard amid New York's worsening migrant crisis
 - [https://www.foxnews.com/politics/democrat-gov-kathy-hochul-calls-national-guard-new-yorks-worsening-migrant-crisis](https://www.foxnews.com/politics/democrat-gov-kathy-hochul-calls-national-guard-new-yorks-worsening-migrant-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:33:12+00:00

Democratic New York Gov. Kathy Hochul is calling in the National Guard as more than 116,000 migrants have arrived in New York City.

## Mom who killed daughters to spite ex-husband declares she was 'good' parent
 - [https://www.foxnews.com/us/mom-who-killed-daughters-spite-ex-husband-declares-she-was-good-parent](https://www.foxnews.com/us/mom-who-killed-daughters-spite-ex-husband-declares-she-was-good-parent)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:31:05+00:00

A northern Virginia woman, who gave her children melatonin-laced gummies before shooting them to death, was hit Friday with nearly eight decades in prison.

## Dem congressman won't rule out 2024 challenge to Biden: 'I'm concerned'
 - [https://www.foxnews.com/politics/dem-congressman-wont-rule-out-2024-challenge-biden-concerned](https://www.foxnews.com/politics/dem-congressman-wont-rule-out-2024-challenge-biden-concerned)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:28:32+00:00

Democratic Rep. Dean Phillips refused to rule out launching a primary challenge against President Biden as questions continue to mount about his age.

## University of Alabama fraternity sued for hazing after student suffers traumatic brain injury
 - [https://www.foxnews.com/us/university-alabama-fraternity-sued-hazing-student-suffers-traumatic-brain-injury](https://www.foxnews.com/us/university-alabama-fraternity-sued-hazing-student-suffers-traumatic-brain-injury)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:28:26+00:00

Sigma Alpha Epsilon, a fraternity at the University of Alabama, has been sued for allegedly hazing a student to the point where the minor lost consciousness.

## Michigan siblings reunite with their 3-year-old brother after his 6-month hospital stay for cancer treatment
 - [https://www.foxnews.com/lifestyle/michigan-siblings-reunite-3-year-old-brother-after-6-month-hospital-stay-cancer-treatment](https://www.foxnews.com/lifestyle/michigan-siblings-reunite-3-year-old-brother-after-6-month-hospital-stay-cancer-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:16:30+00:00

A Michigan family reunited after the youngest child visited home during a break in his stay in the hospital where he has been fighting a rare brain cancer.

## New York Post columnist wearing 'full Fetterman get-up' details being denied entry into restaurants
 - [https://www.foxnews.com/media/new-york-post-columnist-wearing-full-fetterman-getup-details-denied-entry-restaurants](https://www.foxnews.com/media/new-york-post-columnist-wearing-full-fetterman-getup-details-denied-entry-restaurants)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:08:24+00:00

A New York Post reporter joined &quot;FOX &amp; Friends&quot; on Monday to discuss his attempts to enter New York City restaurants while wearing &quot;full Fetterman get-up.&quot;

## 'Wheel of Fortune's' Ryan Seacrest feeling 'pressure' before taking over for Pat Sajak
 - [https://www.foxnews.com/entertainment/wheel-of-fortunes-ryan-seacrest-feeling-pressure-taking-over-pat-sajak](https://www.foxnews.com/entertainment/wheel-of-fortunes-ryan-seacrest-feeling-pressure-taking-over-pat-sajak)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:03:20+00:00

Ryan Seacrest is feeling the &quot;pressure&quot; of taking over Pat Sajak&apos;s hosting duties on &quot;Wheel of Fortune.&quot; The radio host will begin his new role in 2024.

## Georgia man, who spent 22 years in prison, gets murder charges dropped
 - [https://www.foxnews.com/us/georgia-man-who-spent-22-years-prison-murder-charges-dropped](https://www.foxnews.com/us/georgia-man-who-spent-22-years-prison-murder-charges-dropped)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T12:02:05+00:00

Following a decades-long battle to get exonerated, Georgia man Joey Watkins was able to get his murder charge dropped in the 2000 slaying of Isaac Dawkins.

## Police appear to threaten girl, 11, with child porn charges after father's call for help
 - [https://www.foxnews.com/us/police-appear-threaten-girl-11-child-porn-charges-after-fathers-call-help](https://www.foxnews.com/us/police-appear-threaten-girl-11-child-porn-charges-after-fathers-call-help)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:52:17+00:00

A Columbus, Ohio, police officer appeared to threaten an 11-year-old girl with child pornography charges after her father says an adult coerced her into sending photos online.

## Good Samaritan killed helping crash victim in Arizona: ‘Worst-case scenario’
 - [https://www.foxnews.com/us/good-samaritan-killed-helping-crash-victim-arizona-worst-case-scenario](https://www.foxnews.com/us/good-samaritan-killed-helping-crash-victim-arizona-worst-case-scenario)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:48:53+00:00

A good Samaritan was hit and killed by a vehicle Sunday after stopping to render aid to the victim of a freeway crash, authorities said.

## GOP moves to axe USDA proposal pressuring public schools to adopt Biden admin's LGBTQ 'social experiments'
 - [https://www.foxnews.com/politics/republicans-move-axe-usda-rule-proposal-pressuring-public-schools-adopt-biden-admins-lgbtq-social-experiments](https://www.foxnews.com/politics/republicans-move-axe-usda-rule-proposal-pressuring-public-schools-adopt-biden-admins-lgbtq-social-experiments)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:46:09+00:00

Republicans in both chambers of Congress are moving to strike down a USDA rule proposal that they say pressures schools to adopt the Biden administration&apos;s &quot;woke agenda.&quot;

## Raiders' Josh McDaniels faces scrutiny over late-game decision to opt for field goal
 - [https://www.foxnews.com/sports/raiders-josh-mcdaniels-faces-scrutiny-late-game-decision-opt-field-goal](https://www.foxnews.com/sports/raiders-josh-mcdaniels-faces-scrutiny-late-game-decision-opt-field-goal)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:41:03+00:00

Las Vegas Raiders coach Josh McDaniels came under scrutiny Sunday for kicking a field goal while down eight points against the Pittsburgh Steelers.

## Capitol protester, who attacked AP photographer and threw flagpole at police, gets 5 years in prison
 - [https://www.foxnews.com/us/capitol-protester-attacked-ap-photographer-threw-flagpole-police-gets-5-years-prison](https://www.foxnews.com/us/capitol-protester-attacked-ap-photographer-threw-flagpole-police-gets-5-years-prison)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:40:12+00:00

Rodney Milstreed, a 56-year-old Maryland man who hurled a wooden club disguised as a flagpole at Capitol police officers on Jan. 6, was sentenced to five years in prison.

## Sen. Bob Menendez makes announcement on political future, insists he'll be exonerated on federal indictment
 - [https://www.foxnews.com/politics/sen-bob-menendez-makes-announcement-political-future-insists-exonerated-federal-indictment](https://www.foxnews.com/politics/sen-bob-menendez-makes-announcement-political-future-insists-exonerated-federal-indictment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:39:50+00:00

Sen. Bob Menendez, D-N.J., indicted for a years-long bribery scheme to benefit the government of Egypt, said Monday he expects to be exonerated.

## New Jersey man gets life in prison again in retrial of 2011 slaying of aspiring NY rapper
 - [https://www.foxnews.com/us/new-jersey-man-gets-life-prison-again-retrial-2011-slaying-aspiring-ny-rapper](https://www.foxnews.com/us/new-jersey-man-gets-life-prison-again-retrial-2011-slaying-aspiring-ny-rapper)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:36:44+00:00

Randy Manning, a New Jersey man accused of killing a 33-year-old Brooklyn man, was sentenced to life imprisonment again in a retrial of Rhian Stoute’s slaying.

## States expand Medicaid programs to provide dental care to low-income adults
 - [https://www.foxnews.com/us/states-expand-medicaid-programs-provide-dental-care-low-income-adults](https://www.foxnews.com/us/states-expand-medicaid-programs-provide-dental-care-low-income-adults)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:32:43+00:00

More and more states across the U.S., including Tennessee and New Hampshire, are expanding health coverage for its poorest residents by offering dental treatment.

## Man arrested after fight with father-in-law takes gruesome, deadly turn
 - [https://www.foxnews.com/world/man-arrested-after-fight-father-in-law-takes-gruesome-deadly-turn](https://www.foxnews.com/world/man-arrested-after-fight-father-in-law-takes-gruesome-deadly-turn)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:21:04+00:00

An American man from San Francisco was arrested in Indonesia after fatally stabbing his father-in-law and &quot;beheading&quot; him, according to authorities.

## AOC contradicts Biden, says economy in 'crisis' during union workers speech
 - [https://www.foxnews.com/politics/aoc-contradicts-biden-says-economy-crisis-union-workers-speech](https://www.foxnews.com/politics/aoc-contradicts-biden-says-economy-crisis-union-workers-speech)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:13:55+00:00

Rep. Alexandria Ocasio-Cortez seemingly contradicted President Biden and his allies&apos; narrative of the U.S. economy in a speech to union workers over the weekend.

## Bob Menendez enlists Hunter Biden’s defense attorney in bribery case
 - [https://www.foxnews.com/politics/bob-menendez-enlists-hunter-bidens-defense-attorney-bribery-case](https://www.foxnews.com/politics/bob-menendez-enlists-hunter-bidens-defense-attorney-bribery-case)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:03:22+00:00

Sen. Bob Menendez, D-N.J., has hired attorney Abbe Lowell to defend him against his bribery charges, the same lawyer enlisted by Hunter Biden.

## Bruce Willis' wife says 'it's hard to know' if actor understands his dementia diagnosis
 - [https://www.foxnews.com/entertainment/bruce-willis-wife-says-hard-know-actor-understands-dementia-diagnosis](https://www.foxnews.com/entertainment/bruce-willis-wife-says-hard-know-actor-understands-dementia-diagnosis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T11:01:18+00:00

Bruce Willis&apos; wife Emma Heming is opening up about her husband&apos;s condition after he was diagnosed with frontotemporal dementia and stepped away from the limelight.

## NFL fans sideswipe Brittany Mahomes as Taylor Swift appears at Chiefs game
 - [https://www.foxnews.com/sports/nfl-fans-sideswipe-brittany-mahomes-taylor-swift-appears-chiefs-game](https://www.foxnews.com/sports/nfl-fans-sideswipe-brittany-mahomes-taylor-swift-appears-chiefs-game)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:48:13+00:00

NFL fans took shots at Brittany Mahomes as Taylor Swift made an appearance at the Kansas City Chiefs&apos; game on Sunday as the team took on the Chicago Bears.

## Historians race to locate Great Lake shipwrecks before invasive mussels destroy sites
 - [https://www.foxnews.com/us/historians-race-locate-great-lake-shipwrecks-before-invasive-mussels-destroy-sites](https://www.foxnews.com/us/historians-race-locate-great-lake-shipwrecks-before-invasive-mussels-destroy-sites)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:44:09+00:00

The invasive quagga mussels, which produce acid that corrodes metal, have spread throughout the lower Great Lakes, placing once-well-preserved shipwrecks in jeopardy.

## New Jersey Dems see Biden migrant housing plan as election issue while GOP gains ground on crisis from NYC
 - [https://www.foxnews.com/politics/new-jersey-dems-see-biden-migrant-housing-plan-election-issue-gop-gains-ground-crisis-nyc](https://www.foxnews.com/politics/new-jersey-dems-see-biden-migrant-housing-plan-election-issue-gop-gains-ground-crisis-nyc)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:23:06+00:00

New Jersey Democrats and Republicans rejected a Biden administration proposal to house NYC migrants at Atlantic City International Airport, as election consequences loom.

## Dock worker at center of wild brawl in Montgomery, Alabama, says he was ‘just in shock’ when he was attacked
 - [https://www.foxnews.com/us/dock-worker-center-wild-brawl-montgomery-alabama-shock-attacked](https://www.foxnews.com/us/dock-worker-center-wild-brawl-montgomery-alabama-shock-attacked)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:21:53+00:00

The dock worker at the center of a viral video capturing a brawl that erupted in Montgomery, Alabama, describes what led up to the wild fight.

## California border officers arrest Mexican man hiding 400 pounds of cocaine in cucumber shipment
 - [https://www.foxnews.com/us/california-border-officers-arrest-mexican-man-hiding-400-pounds-cocaine-cucumber-shipment](https://www.foxnews.com/us/california-border-officers-arrest-mexican-man-hiding-400-pounds-cocaine-cucumber-shipment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:17:30+00:00

A 33-year-old Mexican citizen was arrested trying to smuggle hundreds of pounds of cocaine concealed within cucumber boxes into the U.S., officials said.

## Illegal immigrant bites off police sergeant's finger after DUI bust: sources
 - [https://www.foxnews.com/us/illegal-immigrant-bites-off-police-sergeants-finger-after-dui-bust-sources](https://www.foxnews.com/us/illegal-immigrant-bites-off-police-sergeants-finger-after-dui-bust-sources)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:03:52+00:00

The 28-year-old Brooklyn DWI suspect accused of biting off an NYPD sergeant&apos;s finger Wednesday is an illegal immigrant, according to law enforcement sources.

## South Carolina Republican demands media cover 'open' border crisis that 'nobody can deny'
 - [https://www.foxnews.com/media/south-carolina-republican-demands-media-cover-open-border-crisis-nobody-can-deny](https://www.foxnews.com/media/south-carolina-republican-demands-media-cover-open-border-crisis-nobody-can-deny)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:03:06+00:00

CNN&apos;s Jim Acosta accused Rep. Ralph Norman of &quot;throwing rhetoric around&quot; during a discussion about the southern border crisis and a potential government shutdown.

## Steelers plane makes emergency landing in Missouri after win in Las Vegas
 - [https://www.foxnews.com/sports/steelers-plane-makes-emergency-landing-missouri-win-las-vegas](https://www.foxnews.com/sports/steelers-plane-makes-emergency-landing-missouri-win-las-vegas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T10:02:52+00:00

The Pittsburgh Steelers suffered a scare in the air on Sunday night as they tried to return home following their win over the Las Vegas Raiders.

## All New York students injured in Thursday’s bus crash expected to recover, superintendent says
 - [https://www.foxnews.com/us/all-new-york-students-injured-thursdays-bus-crash-expected-recover-superintendent-says](https://www.foxnews.com/us/all-new-york-students-injured-thursdays-bus-crash-expected-recover-superintendent-says)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:54:40+00:00

Last week, a bus carrying 40 students from Long Island’s Farmingdale High School crashed in upstate New York. The superintendent said the injured students are expected to recover.

## San Francisco Italian restaurant is closing as 'bleeding' businesses continue to suffer in city's downtown
 - [https://www.foxnews.com/media/san-francisco-italian-restaurant-closing-businesses-continue-suffer-downtown-sf-bleeding](https://www.foxnews.com/media/san-francisco-italian-restaurant-closing-businesses-continue-suffer-downtown-sf-bleeding)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:30:57+00:00

An Italian restaurant owner announced that he was closing his eatery after over a decade of business in downtown San Francisco, per a recent Instagram post.

## First US-made Abrams tanks arrive in Ukraine months ahead of schedule
 - [https://www.foxnews.com/world/first-us-made-abrams-tanks-arrive-ukraine-months-ahead-schedule](https://www.foxnews.com/world/first-us-made-abrams-tanks-arrive-ukraine-months-ahead-schedule)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:22:11+00:00

The first U.S. M1 Abrams tanks have arrived in Ukraine in time to assist with the country&apos;s ongoing counteroffensive, the country announced Monday.

## Ohio boy found comfort in Legos, YouTube videos during yearslong treatment for leukemia
 - [https://www.foxnews.com/lifestyle/common-cancers-children-support-diagnosis-treatment](https://www.foxnews.com/lifestyle/common-cancers-children-support-diagnosis-treatment)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:20:08+00:00

Leukemia, brain or spinal cord tumors and lymphoma are among the common types of cancer seen in children. If your child receives a diagnosis, there are several ways to show support.

## Florida police identify woman killed in ‘alligator attack’ as daughter describes 'unbearable pain': report
 - [https://www.foxnews.com/us/florida-police-identify-woman-killed-alligator-attack-daughter-describes-unbearable-pain-report](https://www.foxnews.com/us/florida-police-identify-woman-killed-alligator-attack-daughter-describes-unbearable-pain-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:14:41+00:00

Police identified Sabrina Peckham as being the woman whose body was found in the jaws of an alligator late last week in Largo, Florida, according to reports.

## Convicted Mafia boss Matteo Messina Denaro, who was Italy’s No. 1 fugitive for years, dies in hospital
 - [https://www.foxnews.com/world/convicted-mafia-boss-matteo-messina-denaro-italys-no-1-fugitive-years-dies-hospital](https://www.foxnews.com/world/convicted-mafia-boss-matteo-messina-denaro-italys-no-1-fugitive-years-dies-hospital)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T09:00:40+00:00

The convicted mastermind of some of Sicilian Mafia’s most heinous slayings, Matteo Messina Denaro, has died. His death comes only months after being captured as Italy’s No. 1 fugitive.

## Bill Belichick remarks on Taylor Swift-Travis Kelce romance: 'Would be the biggest' catch of his career
 - [https://www.foxnews.com/sports/bill-belichick-remarks-taylor-swift-travis-kelce-romance-biggest-catch-career](https://www.foxnews.com/sports/bill-belichick-remarks-taylor-swift-travis-kelce-romance-biggest-catch-career)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T08:47:31+00:00

New England Patriots coach Bill Belichick was asked about Taylor Swift showing up to the Kansas City Chiefs game, seemingly to see Travis Kelce.

## Chairman of Hong Kong Journalist Association found guilty of obstructing police
 - [https://www.foxnews.com/world/chairman-hong-kong-journalist-association-found-guilty-obstructing-police](https://www.foxnews.com/world/chairman-hong-kong-journalist-association-found-guilty-obstructing-police)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T08:47:28+00:00

Ronson Chan, the chairman of the Hong Kong Journalist Association who allegedly refused to show the plainclothes officer his identity card, has been found guilty of obstruction.

## Vikings' Kirk Cousins says crowd noise contributing factor on team's bizarre final sequence
 - [https://www.foxnews.com/sports/vikings-kirk-cousins-says-crowd-noise-contributing-factor-teams-bizarre-final-sequence](https://www.foxnews.com/sports/vikings-kirk-cousins-says-crowd-noise-contributing-factor-teams-bizarre-final-sequence)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T08:26:04+00:00

Minnesota Vikings quarterback Kirk Cousins explained why there was so much time taken off the clock before the final play of Sunday&apos;s loss to the Los Angeles Chargers.

## Thousands of Armenians flee Nagorno-Karabakh as Azerbaijan reclaims separatist region
 - [https://www.foxnews.com/world/thousands-armenians-flee-nagorno-karabakh-azerbaijan-reclaims-separatist-region](https://www.foxnews.com/world/thousands-armenians-flee-nagorno-karabakh-azerbaijan-reclaims-separatist-region)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T08:16:53+00:00

Armenians in Nagorno-Karabakh are fleeing the region after authorities of the separatist region announced ideas of reintegrating into Azerbaijan.

## 3 reasons why college is worth the price tag
 - [https://www.foxnews.com/opinion/3-reasons-college-worth-price-tag](https://www.foxnews.com/opinion/3-reasons-college-worth-price-tag)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T08:00:57+00:00

Here are three reasons why your student should consider getting a college degree.

## Broncos' Garett Bolles distraught after blow out loss: 'All I’ve done is lost
 - [https://www.foxnews.com/sports/broncos-garett-bolles-distraught-blow-out-loss-all-done-lost](https://www.foxnews.com/sports/broncos-garett-bolles-distraught-blow-out-loss-all-done-lost)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:33:25+00:00

Denver Broncos veteran offensive lineman Garett Bolles appeared to be distraught after the team&apos;s demoralizing 70-20 loss to the Miami Dolphins.

## After fire leaves 9 dead, Taiwanese golf ball manufacturer fined for storing hazardous material
 - [https://www.foxnews.com/world/after-fire-leaves-9-dead-taiwanese-golf-ball-manufacturer-fined-storing-hazardous-material](https://www.foxnews.com/world/after-fire-leaves-9-dead-taiwanese-golf-ball-manufacturer-fined-storing-hazardous-material)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:31:49+00:00

Following a fatal fire that erupted on Friday, a Taiwanese manufacturer was fined $75,000 for storing 3,000 tons of organic peroxides on site, 30 times the hazardous material allowed.

## William Byron punches ticket to Round of 8 with victory at Texas
 - [https://www.foxnews.com/sports/william-byron-punches-ticket-round-8-victory-texas](https://www.foxnews.com/sports/william-byron-punches-ticket-round-8-victory-texas)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:30:56+00:00

William Byron took the lead with six laps to go and held on for the victory at Texas Motor Speedway to punch a ticket to the Round of 8 in the playoffs.

## Death toll rises in Florida train versus SUV crash, victims identified
 - [https://www.foxnews.com/us/death-toll-rises-florida-train-versus-suv-crash-victims-identified](https://www.foxnews.com/us/death-toll-rises-florida-train-versus-suv-crash-victims-identified)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:28:04+00:00

Six people have died and one remains in critical condition after a train versus SUV collision in Plant City, Florida, Saturday night. Officials have released identities.

## Jets' Sauce Gardner claims Patriots' Mac Jones delivered dirty shot to his 'private parts'
 - [https://www.foxnews.com/sports/jets-sauce-gardner-claims-patriots-mac-jones-delivered-dirty-shot-private-parts](https://www.foxnews.com/sports/jets-sauce-gardner-claims-patriots-mac-jones-delivered-dirty-shot-private-parts)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:26:57+00:00

New York Jets star Sauce Gardner alleged New England Patriots quarterback Mac Jones hit him in his &quot;private parts&quot; after a heated play in the fourth quarter.

## Simone Biles says 'racism' in viral video from Irish gymnastics event 'broke my heart'
 - [https://www.foxnews.com/sports/simone-biles-says-racism-viral-video-irish-gymnastics-event-broke-my-heart](https://www.foxnews.com/sports/simone-biles-says-racism-viral-video-irish-gymnastics-event-broke-my-heart)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:22:10+00:00

Simone Biles said she sent a video to a Black girl who was not given a medal at a gymnastics event in Ireland last year, an act she said was racist that broke her heart.

## NC hiker falls 150 feet to death from waterfall overlook
 - [https://www.foxnews.com/us/nc-hiker-falls-150-feet-death-waterfall-overlook](https://www.foxnews.com/us/nc-hiker-falls-150-feet-death-waterfall-overlook)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:19:22+00:00

A woman died in a 150-foot fall from a waterfall overlook along the scenic Blue Ridge Parkway in western North Carolina on Saturday, officials said.

## Molotov cocktails thrown at Cuban embassy in Washington in ‘terrorist attack,’ minister claims
 - [https://www.foxnews.com/politics/molotov-cocktails-thrown-cuban-embassy-washington-terrorist-attack-minister-claims](https://www.foxnews.com/politics/molotov-cocktails-thrown-cuban-embassy-washington-terrorist-attack-minister-claims)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:16:51+00:00

Cuban diplomat Bruno Rodríguez Parrilla says an unknown individual has thrown a pair of Molotov cocktails at his country’s embassy in Washington, D.C.

## Sophia Loren recovering from emergency surgery after suffering fall, multiple fractures at Swiss home
 - [https://www.foxnews.com/entertainment/sophia-loren-recovering-emergency-surgery-suffering-fall-multiple-fractures-swiss-home](https://www.foxnews.com/entertainment/sophia-loren-recovering-emergency-surgery-suffering-fall-multiple-fractures-swiss-home)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:16:35+00:00

Sophia Loren, one of the last surviving stars from Hollywood&apos;s golden era, suffered a bad fall at her Geneva home on Sunday. Her sons Carlo and Edoardo are by her side at the hospital.

## Thailand receives 1st wave of Chinese visitors under new tourism-booting visa-free policies
 - [https://www.foxnews.com/world/thailand-receives-1st-wave-chinese-visitors-under-new-tourism-boosting-visa-free-policies](https://www.foxnews.com/world/thailand-receives-1st-wave-chinese-visitors-under-new-tourism-boosting-visa-free-policies)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:13:15+00:00

About 300 Chinese tourists have arrived in Bangkok on the first day of Thailand’s visa-free program meant to boost tourism. The visa-free policy will expire on Feb. 29.

## Super Bowl champ Jim McMahon sums up Bears' performance against Chiefs in 1 word
 - [https://www.foxnews.com/sports/super-bowl-champ-jim-mcmahon-sums-up-bears-performance-against-chiefs-one-word](https://www.foxnews.com/sports/super-bowl-champ-jim-mcmahon-sums-up-bears-performance-against-chiefs-one-word)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:10:32+00:00

Super Bowl champion quarterback Jim McMahon summed up the Chicago Bears&apos; performance in one word on social media. The Bears lost to the Kansas City Chiefs.

## Indicted Dem teases political future, Clinton sends election warning and more top headlines
 - [https://www.foxnews.com/us/hillary-clinton-issues-election-warning-gop-senator-demands-answers-migrant-crisis](https://www.foxnews.com/us/hillary-clinton-issues-election-warning-gop-senator-demands-answers-migrant-crisis)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:02:36+00:00

Indicted Dem teases political future, Clinton sends election warning and more top headlines

## Tennessee family faces deportation 15 years after fleeing Germany to homeschool kids: A 'well-founded' fear
 - [https://www.foxnews.com/media/tennessee-family-deportation-15-years-fleeing-germany-homeschool-kids-well-founded-fear](https://www.foxnews.com/media/tennessee-family-deportation-15-years-fleeing-germany-homeschool-kids-well-founded-fear)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T07:00:33+00:00

Hannelore and Uwe Romeike, who face deportation 15 years after moving to the U.S. to homeschool their children, are afraid they will face the same persecution if they return to Germany.

## Bob Menendez to announce re-election bid in New Jersey during 1st public appearance post-indictment: report
 - [https://www.foxnews.com/politics/bob-menendez-announce-re-election-bid-new-jersey-1st-public-appearance-post-indictment-report](https://www.foxnews.com/politics/bob-menendez-announce-re-election-bid-new-jersey-1st-public-appearance-post-indictment-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T06:52:10+00:00

Sen. Bob Menendez, D-N.J., is reportedly expected to reveal plans for a re-election campaign in 2024 Monday after his latest federal indictment on corruption charges.

## You could get in big trouble for throwing these items in trash
 - [https://www.foxnews.com/lifestyle/dont-throw-away-items-in-trash](https://www.foxnews.com/lifestyle/dont-throw-away-items-in-trash)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T06:44:40+00:00

Throwing certain items in the trash can be extremely harmful to the environment. Make sure to double check before throwing particular items in the bin.

## Los Angeles police pursue shirtless man driving stolen golf cart with dog on his lap, video shows
 - [https://www.foxnews.com/us/los-angeles-police-pursue-shirtless-man-driving-stolen-golf-cart-dog-lap-video](https://www.foxnews.com/us/los-angeles-police-pursue-shirtless-man-driving-stolen-golf-cart-dog-lap-video)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T06:36:05+00:00

A Los Angeles man was apprehended after allegedly stealing a golf cart and leading police on a brief pursuit Sunday night while a dog was sitting on his lap.

## Chiefs' Andy Reid jokes about setting up Taylor Swift, Travis Kelce
 - [https://www.foxnews.com/sports/chiefs-andy-reid-jokes-setting-up-taylor-swift-travis-kelce](https://www.foxnews.com/sports/chiefs-andy-reid-jokes-setting-up-taylor-swift-travis-kelce)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:59:37+00:00

Kansas City Chiefs star Andy Reid made a joke about Taylor Swift&apos;s supposed relationship with Travis Kelce following the team&apos;s win on Sunday.

## Taylor Swift, Travis Kelce appear to leave stadium together after Chiefs win
 - [https://www.foxnews.com/sports/taylor-swift-travis-kelce-appear-leave-stadium-together-chiefs-win](https://www.foxnews.com/sports/taylor-swift-travis-kelce-appear-leave-stadium-together-chiefs-win)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:55:11+00:00

Travis Kelce and Taylor Swift appeared to leave Arrowhead Stadium together after the pop star came to watch the Kansas City Chiefs beat the Chicago Bears.

## Prince Philip kept '70s erotic manual on bookshelf, Queen Elizabeth once dropped F-bomb, insiders claim
 - [https://www.foxnews.com/entertainment/prince-philip-kept-70s-erotic-manual-bookshelf-queen-elizabeth-dropped-f-bomb-insiders](https://www.foxnews.com/entertainment/prince-philip-kept-70s-erotic-manual-bookshelf-queen-elizabeth-dropped-f-bomb-insiders)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:30:16+00:00

Queen Elizabeth II, Britain&apos;s longest-reigning monarch, passed away on Sept. 8, 2022, at age 96. Prince Philip, the longest-serving British consort, died on April 9, 2021, at age 99.

## Less than half of nurses are ‘fully engaged’ at work, while many are ‘unengaged,' new report reveals
 - [https://www.foxnews.com/health/less-half-nurses-fully-engaged-work-many-unengaged-report](https://www.foxnews.com/health/less-half-nurses-fully-engaged-work-many-unengaged-report)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:15:30+00:00

Less than half of U.S. nurses say they are “fully engaged&quot; while on the job, according to the 2023 National Nursing Engagement Report from PRC, which surveyed 1,923 RNs from 37 U.S. hospitals.

## Biden’s urban bureaucracy fails Blacks by ignoring devastating problem
 - [https://www.foxnews.com/opinion/bidens-urban-bureaucracy-fails-blacks-ignoring-devastating-problem](https://www.foxnews.com/opinion/bidens-urban-bureaucracy-fails-blacks-ignoring-devastating-problem)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:59+00:00

Biden’s urban bureaucracy fails Blacks by ignoring devastating problem. HUD Secretary Fudge and other Biden Democrats won&apos;t discuss the decline of the Black family.

## Pro-life leader denounces FBI, DOJ's prosecution of activists: 'It's a different America'
 - [https://www.foxnews.com/media/pro-life-leader-denounces-fbi-dojs-prosecution-activists-different-america](https://www.foxnews.com/media/pro-life-leader-denounces-fbi-dojs-prosecution-activists-different-america)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:59+00:00

Life Issues Institute President Bradley Mattes spoke with Fox News Digital on recent federal charges against pro-life activists by the Department of Justice.

## Viral exchange between Portnoy and Wash Post reporter shows 'sad state of American journalism,' critics say
 - [https://www.foxnews.com/media/viral-exchange-between-portnoy-wash-post-reporter-shows-sad-state-american-journalism-critics-say](https://www.foxnews.com/media/viral-exchange-between-portnoy-wash-post-reporter-shows-sad-state-american-journalism-critics-say)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:59+00:00

Critics said the reporting on display against Dave Portnoy by the Washington Post showed a preference for a pre-conceived narrative rather than the truth.

## Sen. Blackburn sends scathing letter to HHS secretary demanding answers on unaccompanied migrant children
 - [https://www.foxnews.com/politics/sen-blackburn-sends-scathing-letter-hhs-secretary-demanding-answers-unacommpanied-migrant-children](https://www.foxnews.com/politics/sen-blackburn-sends-scathing-letter-hhs-secretary-demanding-answers-unacommpanied-migrant-children)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:57+00:00

Sen. Marsha Blackburn, R-Tenn., is questioning HHS Secretary Xavier Becerra in a letter about the handling of unaccompanied minors at the southern border.

## Legal experts weigh in on Menendez indictment, suggest 'monster' charges point to likely conviction
 - [https://www.foxnews.com/politics/legal-experts-weigh-menendez-indictment-suggest-monster-charges-point-likely-conviction-trial](https://www.foxnews.com/politics/legal-experts-weigh-menendez-indictment-suggest-monster-charges-point-likely-conviction-trial)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:50+00:00

Legal experts suggest the “monster&quot; indictment and strong evidence presented against Sen. Bob Menendez, D-N.J., last week is likely to result in a conviction at trial.

## The border is a national security issue. Let’s treat it like one
 - [https://www.foxnews.com/opinion/border-national-security-issue-lets-treat-like](https://www.foxnews.com/opinion/border-national-security-issue-lets-treat-like)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:41+00:00

The border is a national security issue. The Senate has been treating it like one, passing the national defense bill. That should help make Biden fix the border.

## George Jones' widow admits country music star had to face death to kick crippling cocaine, alcohol addiction
 - [https://www.foxnews.com/entertainment/george-jones-widow-admits-country-music-star-face-death-kick-crippling-cocaine](https://www.foxnews.com/entertainment/george-jones-widow-admits-country-music-star-face-death-kick-crippling-cocaine)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:26+00:00

George Jones, known for “He Stopped Loving Her Today&quot; and &quot;Choices,&quot; died in 2013 at age 81. He was married to &quot;Stand By Your Man&quot; singer Tammy Wynette.

## It’s time to resurrect statues of heroes torn down by the mob. They are our national treasures
 - [https://www.foxnews.com/opinion/ime-resurrect-statues-heroes-torn-down-they-national-treasures](https://www.foxnews.com/opinion/ime-resurrect-statues-heroes-torn-down-they-national-treasures)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:25+00:00

It’s time to resurrect statues of heroes torn down by the mob. Bringing back these national treasures sends a powerful message to those who tear down our culture.

## AL West teams vie for final wild-card spot, NL race heats up as MLB season enters final week
 - [https://www.foxnews.com/sports/al-west-teams-vie-final-wild-card-spot-nl-race-heats-up-mlb-season-enters-final-week](https://www.foxnews.com/sports/al-west-teams-vie-final-wild-card-spot-nl-race-heats-up-mlb-season-enters-final-week)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:24+00:00

It may be football season, but the Major League Baseball season is reaching its pinnacle as postseason races are heating up in the final week.

## OutKick’s Donovan McNabb dishes on his new NFL podcast, dreams guests and getting ‘back in the groove’
 - [https://www.foxnews.com/media/outkicks-donovan-mcnabb-dishes-nfl-new-podcast-dreams-guests-getting-back-groove](https://www.foxnews.com/media/outkicks-donovan-mcnabb-dishes-nfl-new-podcast-dreams-guests-getting-back-groove)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:15+00:00

Former NFL star and Philadelphia Eagles icon Donovan McNabb explains why he wanted to host an OutKick podcast, his dream guests and how he&apos;ll &quot;keep it real&quot; on fellow players.

## What Republican presidential hopefuls stand to gain — or lose — at second primary debate
 - [https://www.foxnews.com/politics/republican-presidential-hopefuls-gain-lose-second-primary-debate](https://www.foxnews.com/politics/republican-presidential-hopefuls-gain-lose-second-primary-debate)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:14+00:00

What&apos;s on the line at Wednesday&apos;s second GOP presidential nomination debate for each of the Republican White House candidates on the stage.

## This day in sports history: Vince Carter throws down dunk heard around the world
 - [https://www.foxnews.com/sports/this-day-sports-history-vince-carter-throws-down-dunk-heard-around-world](https://www.foxnews.com/sports/this-day-sports-history-vince-carter-throws-down-dunk-heard-around-world)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:10+00:00

Vince Carter made a memory that will last a lifetime and transcend sports. He dunked over 7-foot-2 Frenchman Frederic Weis during the Olympics on Sept. 25, 2000.

## Former Yale student trying to restore career, life after alleged false accusation of rape led to expulsion
 - [https://www.foxnews.com/media/former-yale-student-trying-restore-career-life-after-alleged-false-accusation-rape-led-expulsion](https://www.foxnews.com/media/former-yale-student-trying-restore-career-life-after-alleged-false-accusation-rape-led-expulsion)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:09+00:00

Ex-Yale student Saifullah Khan discusses his legal battle against the school after being accused of sexual assault under Obama-era Title IX interpretations.

## Anglican minister slams progressive Christians as 'fake,' calls notion an oxymoron
 - [https://www.foxnews.com/media/anglican-minister-slams-progressive-christians-fake-calls-notion-oxymoron](https://www.foxnews.com/media/anglican-minister-slams-progressive-christians-fake-calls-notion-oxymoron)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:07+00:00

Free Church of England minister Deacon Calvin Robinson argued that progressive Christianity isn&apos;t possible, calling it &quot;fake&quot; in a new interview.

## Ramaswamy campaign defends former CEO’s ‘awakening’ on China after 2018 partnership with CCP-backed firm
 - [https://www.foxnews.com/politics/ramaswamy-campaign-defends-former-ceos-awakening-china-2018-partnership-ccp-backed-firm](https://www.foxnews.com/politics/ramaswamy-campaign-defends-former-ceos-awakening-china-2018-partnership-ccp-backed-firm)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:06+00:00

Republican presidential candidate Vivek Ramaswamy is taking a hawk-like approach to China after previously doing business in the Communist state as the CEO of Roivant.

## College kids are 'hungry' for Christianity on campus, Pepperdine leader says: 'Central' to school life
 - [https://www.foxnews.com/lifestyle/college-kids-hungry-christianity-campus-pepperdine-leader-central-school-life](https://www.foxnews.com/lifestyle/college-kids-hungry-christianity-campus-pepperdine-leader-central-school-life)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:03+00:00

Tim Spivey, associate vice president for spiritual life at Pepperdine University in California, told Fox News Digital about the state of faith and Christianity among the college kids on campus.

## Top Republicans launch probe into Leonardo DiCaprio-funded blue state lawsuits against Big Oil
 - [https://www.foxnews.com/politics/top-republicans-launch-probe-leonardo-dicaprio-funded-blue-state-lawsuits-against-big-oil](https://www.foxnews.com/politics/top-republicans-launch-probe-leonardo-dicaprio-funded-blue-state-lawsuits-against-big-oil)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T05:00:03+00:00

Sen. Ted Cruz and Rep. James Comer sent a letter to law firm Sher Edling over its extensive climate litigation and relationship with a top Biden administration official.

## Safety experts warn of deadly risk schools keep taking with kids as bus crashes keep piling up
 - [https://www.foxnews.com/us/safety-experts-warn-deadly-risk-schools-keep-taking-kids-bus-crashes-keep-piling](https://www.foxnews.com/us/safety-experts-warn-deadly-risk-schools-keep-taking-kids-bus-crashes-keep-piling)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:45:18+00:00

School bus safety advocates are calling for change as around 17,000 kids are being injured in school bus crashes per year, according to government data.

## Tom Hanks will do anything to go to space: 'I'll clean the toilet'
 - [https://www.foxnews.com/entertainment/tom-hanks-anything-go-space-clean-toilet](https://www.foxnews.com/entertainment/tom-hanks-anything-go-space-clean-toilet)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:30:42+00:00

Tom Hanks, who is promoting his new art exhibition &quot;The Moonwalkers,&quot; jokes that he would do anything from cleaning toilets to washing dishes for a ride to the Moon.

## Would-be burglars armed with 'billy club' pick the wrong farmer to try to rob: 'I will shoot'
 - [https://www.foxnews.com/us/would-be-burglars-armed-billy-club-pick-wrong-farmer-rob-i-will-shoot](https://www.foxnews.com/us/would-be-burglars-armed-billy-club-pick-wrong-farmer-rob-i-will-shoot)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:30:06+00:00

Washington state farmer Sam Krautscheid was forced to use his firearm to thwart two suspected burglars and held them at gunpoint until deputies arrived.

## Ex-CIA officer accused of drugging, raping women taps celebrity memory experts for defense
 - [https://www.foxnews.com/us/ex-cia-officer-accused-drugging-raping-women-taps-celebrity-memory-experts-defense](https://www.foxnews.com/us/ex-cia-officer-accused-drugging-raping-women-taps-celebrity-memory-experts-defense)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:30:00+00:00

A former CIA officer charged with sexually abusing and photographing more than two dozen unconscious women has tapped a pair of trial experts who specialize in false memories.

## California officials dragged feet investigating China-linked biolab, documents suggest
 - [https://www.foxnews.com/us/california-officials-dragged-feet-investigating-china-linked-biolab-documents-suggest](https://www.foxnews.com/us/california-officials-dragged-feet-investigating-china-linked-biolab-documents-suggest)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:00:53+00:00

Newly disclosed public records suggest that California officials knew early on about suspicious activity at a China-backed biolab, but failed to follow up on leads.

## AOC grilled on her non-union electric vehicle while supporting UAW strike
 - [https://www.foxnews.com/media/aoc-grilled-non-union-electric-vehicle-while-supporting-uaw-strike](https://www.foxnews.com/media/aoc-grilled-non-union-electric-vehicle-while-supporting-uaw-strike)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:00:39+00:00

Rep. Alexandria Ocasio-Cortez, D-N.Y., agreed that she owns a non-union made vehicle despite supporting the UAW strike because it was purchased during the pandemic.

## New York veteran, 105, shares her secret to a fulfilling life: Faith, family and 'no regrets'
 - [https://www.foxnews.com/lifestyle/new-york-veteran-105-shares-secret-fulfilling-life-faith-family-no-regrets](https://www.foxnews.com/lifestyle/new-york-veteran-105-shares-secret-fulfilling-life-faith-family-no-regrets)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:00:38+00:00

New York veteran Susan Rossetti turned 105 and is sharing what she feels are the key ways to live a fulfilling life: family, faith and trying everything without saying &quot;no.&quot;

## ‘Duck Dynasty’ stars’ new movie shows family’s origin and faith: Without God ‘we would not be sitting here'
 - [https://www.foxnews.com/entertainment/duck-dynasty-stars-new-movie-shows-familys-origin-faith](https://www.foxnews.com/entertainment/duck-dynasty-stars-new-movie-shows-familys-origin-faith)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T04:00:21+00:00

&quot;Duck Dynasty&apos;s&quot; Willie Robertson and wife Korie Robertson spoke with Fox News Digital about their new film, &quot;The Blind,&quot; which follows Phil Robertson&apos;s journey to finding faith.

## Man charged after woman found dead inside truck at Costco distribution center in Maryland
 - [https://www.foxnews.com/us/man-charged-woman-found-dead-inside-truck-costco-distribution-center-maryland](https://www.foxnews.com/us/man-charged-woman-found-dead-inside-truck-costco-distribution-center-maryland)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T03:16:22+00:00

A New Jersey man was charged with first and second-degree murder after a woman was found dead inside his truck at a Costco distribution center in Monrovia, Maryland.

## NASA reveals latest weapon to 'search the heavens' for UFOs, aliens
 - [https://www.foxnews.com/us/nasa-reveals-latest-weapon-search-heavens-ufos-aliens](https://www.foxnews.com/us/nasa-reveals-latest-weapon-search-heavens-ufos-aliens)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T02:00:37+00:00

Artificial intelligence is going to be key if NASA is going to find scientifically provable alien life and the existence of UFOs, according to a NASA study.

## GOP primary debate moderator Dana Perino says the economy is critical to key issues ‘worrying Americans’
 - [https://www.foxnews.com/media/gop-primary-debate-moderator-dana-perino-economy-critical-key-issues-worrying-americans](https://www.foxnews.com/media/gop-primary-debate-moderator-dana-perino-economy-critical-key-issues-worrying-americans)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T02:00:27+00:00

Dana Perino, who will co-moderate Wednesday&apos;s Republican presidential primary debate in Simi Valley, Calif., expects a wide-ranging examination of the candidates.

## Cowboys roll out AI-powered version of Jerry Jones inside AT&T Stadium to take on fan questions
 - [https://www.foxnews.com/sports/cowboys-roll-out-ai-powered-version-jerry-jones-inside-att-stadium-take-fan-questions](https://www.foxnews.com/sports/cowboys-roll-out-ai-powered-version-jerry-jones-inside-att-stadium-take-fan-questions)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T02:00:24+00:00

The AI iteration of longtime Dallas Cowboys owner and general manger Jerry Jones at the team&apos;s stadium has the capability to answer questions from football fans and tourists.

## AI bias might not be a threat and here’s why
 - [https://www.foxnews.com/opinion/ai-bias-might-threat-heres-why](https://www.foxnews.com/opinion/ai-bias-might-threat-heres-why)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T02:00:14+00:00

AI bias might not be a threat and here’s why. Amazon, Google dominated their markets, but there will likely be many AI platforms with none of them having that kind of power.

## On this day in history, September 25, 1890, Congress establishes Sequoia National Park in California
 - [https://www.foxnews.com/lifestyle/this-day-history-september-25-1890-congress-establishes-sequoia-national-park-california](https://www.foxnews.com/lifestyle/this-day-history-september-25-1890-congress-establishes-sequoia-national-park-california)
 - RSS feed: https://moxie.foxnews.com/google-publisher/latest.xml
 - date published: 2023-09-25T00:02:33+00:00

Sequoia National Park, America&apos;s second national park, was established on this day in history, Sept. 25, 1890. The aim of the park was to protect the sequoia tree.

