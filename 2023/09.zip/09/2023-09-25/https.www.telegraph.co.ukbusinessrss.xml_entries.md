# Source:The Telegraph Business, URL:https://www.telegraph.co.uk/business/rss.xml, language:en-UK

## Electric car makers face £3.7bn bill over EU tariffs - latest updates
 - [https://www.telegraph.co.uk/business/2023/09/25/ftse-100-markets-news-live-eu-electric-cars-brexit-acea/](https://www.telegraph.co.uk/business/2023/09/25/ftse-100-markets-news-live-eu-electric-cars-brexit-acea/)
 - RSS feed: https://www.telegraph.co.uk/business/rss.xml
 - date published: 2023-09-25T06:29:00+00:00



