# Source:Popular Science, URL:https://www.popsci.com/feed/, language:en-US

## Grizzlies are getting killed by roads, but the risks are bigger than roadkill
 - [https://www.popsci.com/environment/mammals-mortalities-roads/](https://www.popsci.com/environment/mammals-mortalities-roads/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T22:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Grizzly bear mom and cubs crossing road in Yellowstone National Park" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="811" src="https://www.popsci.com/uploads/2023/09/25/grizzly-bear-road-yellowstone-national-park.jpg?auto=webp&amp;width=1440&amp;height=811.44" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">Roadside encounters with grizzly bears can be dangerous, but not in the way you'd think. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/grizzly-bear-wild-386512376.html">Deposit Photos</a></span></div></div><p>From highways to scenic backcountry routes, America's vast network of roads poses a slew of dangers to bears, mountain lions, and moose.</p>
<p>The post <a href="https://w

## The best 3D modeling software in 2023
 - [https://www.popsci.com/gear/best-3d-modeling-software/](https://www.popsci.com/gear/best-3d-modeling-software/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T21:55:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--productTable">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The best 3D modeling software brings characters, animations, art, models, and more to life." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="936" src="https://www.popsci.com/uploads/2023/09/25/best-3d-modeling-software.jpg?auto=webp&amp;width=1440&amp;height=936" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div></div><p>From filmmaking to medicine, this software help creators and designers bring characters and prototypes to life.</p>
<p>The post <a href="https://www.popsci.com/gear/best-3d-modeling-software/" rel="nofollow">The best 3D modeling software in 2023</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

## The Air Force’s big new electric taxi flies at 200 mph
 - [https://www.popsci.com/technology/joby-aviation-edwards-air-force-base/](https://www.popsci.com/technology/joby-aviation-edwards-air-force-base/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T20:30:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="The Joby aircraft at Edwards Air Force Base. " class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/25/joby-aircraft-edwards-air-force-base.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">The Joby aircraft at Edwards Air Force Base. <span class="orgnc-SingleImage-credit">Joby</span></div></div><p>The flying machine from Joby Aviation is now on site at Edwards Air Force Base in California, and it could be used to patrol the base's perimeter.</p>
<p>The post <a href="https://www.popsci.com/technology/joby-aviation-edwards-air-force-base/" rel="nofollow">The Air Force’s big new electric taxi flies at 200 mph</a> appeared first on 

## Lego’s plan for eco-friendly bricks has fallen apart
 - [https://www.popsci.com/technology/lego-brick-pet/](https://www.popsci.com/technology/lego-brick-pet/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T19:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Pile of colorful Lego bricks" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/25/Depositphotos_457187650_L.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">The company had been testing its recycled plastic alternative for two years. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/editorial/lots-colorful-lego-pieces-lego-background-selective-focus-minsk-belarus-457187650.html">Deposit Photos</a></span></div></div><p>Recycled plastic bottles failed them, but the company plans to use other sustainable materials by 2032.</p>
<p>The post <a href="https://www.popsci.com/technology/lego-brick-pet/" rel="n

## Earth’s stinkiest flower is threatened with extinction
 - [https://www.popsci.com/environment/earths-stinkiest-flower-extinction/](https://www.popsci.com/environment/earths-stinkiest-flower-extinction/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T18:15:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Rafflesia kemumu in the rainforest of Sumatra." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/25/rafflesia-kemumu-corpse-flower.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">Rafflesia kemumu in the rainforest of Sumatra. Flowers in the Rafflesia genus are some of the world's largest, but also smelliest. <span class="orgnc-SingleImage-credit">Chris Thorogood</span></div></div><p>Rafflesia, which smells like rotting flesh, is facing habitat loss.</p>
<p>The post <a href="https://www.popsci.com/environment/earths-stinkiest-flower-extinction/" rel="nofollow">Earth’s stinkiest flower is threatened with extinction</a> appear

## Substance use disorder may be connected to a specific brain circuit
 - [https://www.popsci.com/health/brain-network-addiction-substance-use-disorder/](https://www.popsci.com/health/brain-network-addiction-substance-use-disorder/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T16:30:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="An MRI scan of a human brain on a screen. Scanning the brain can help clinicians find abnormalities and the links between them." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/25/brain-scan-addiction.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">An MRI scan of a human brain on a screen. Scanning the brain can help clinicians find abnormalities and the links between them. <span class="orgnc-SingleImage-credit">Getty Images</span></div></div><p>he network includes five primary areas of the brain and could inform future clinical treatments for drug addiction.</p>
<p>The post <a href="https://www.popsci.com/health/brain-net

## ChatGPT can now see, hear, and talk to some users
 - [https://www.popsci.com/technology/chatgpt-voice-pictures/](https://www.popsci.com/technology/chatgpt-voice-pictures/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T15:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="chatgpt shown on a mobile phone" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/08/31/chatgpt-mobile.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">Examples included creating and reading its own children's bedtime story. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photos/chatgpt.html?filter=all&amp;qview=627314912">Deposit Photos</a></span></div></div><p>OpenAI's program can analyze pictures and speak with premium subscribers.</p>
<p>The post <a href="https://www.popsci.com/technology/chatgpt-voice-pictures/" rel="nofollow">ChatGPT can now see, hear, and talk to some users</a> appeared first on

## The deepest known ocean virus lives under 29,000 of water
 - [https://www.popsci.com/environment/deepest-virus/](https://www.popsci.com/environment/deepest-virus/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T13:30:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A high-density field of corals, including the spiraling Iridogorgia magnispiralis. Image courtesy of the NOAA Office of Ocean Exploration and Research, 2016 Deepwater Exploration of the Marianas." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/25/mariana-trench-floor.png?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">A high-density field of corals, including the spiraling Iridogorgia magnispiralis. Image courtesy of the NOAA Office of Ocean Exploration and Research, 2016 Deepwater Exploration of the Marianas. <span class="orgnc-SingleImage-credit">NOAA</span></div></div><p>The newly discovered virus vB_HmeY_H4907 lurks in th

## These subscriptions help you make wiser real estate investments
 - [https://www.popsci.com/sponsored-content/mashvisor-property-ai-investment-app/](https://www.popsci.com/sponsored-content/mashvisor-property-ai-investment-app/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T13:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="A pair of keys next to a miniature house." class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="800" src="https://www.popsci.com/uploads/2023/09/25/image.png?auto=webp" style="display: block; margin: auto; margin-bottom: 5px;" width="1067" /></div><div class="orgnc-SingleImage-caption"><span class="orgnc-SingleImage-credit">Stack Commerce</span></div></div><p>Dive into accurate market data and save time and money.</p>
<p>The post <a href="https://www.popsci.com/sponsored-content/mashvisor-property-ai-investment-app/" rel="nofollow">These subscriptions help you make wiser real estate investments</a> appeared first on <a href="https://www.popsci.com" rel="nofollow">Popular Science</a>.</p>

## Driving a McLaren at 200 mph is a thrilling, dangerous experience
 - [https://www.popsci.com/technology/mclaren-artura-200-mph/](https://www.popsci.com/technology/mclaren-artura-200-mph/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T11:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Mclaren artura" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="810" src="https://www.popsci.com/uploads/2023/09/22/mclaren-artura-idaho.jpg?auto=webp&amp;width=1440&amp;height=810" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">The hybrid McLaren Artura is a $289,000 mid-engine supercar. <span class="orgnc-SingleImage-credit">McLaren</span></div></div><p>The McLaren Artura is a 671-horsepower supercar, and operating it at these speeds is not something you do without a helmet and a closed course.</p>
<p>The post <a href="https://www.popsci.com/technology/mclaren-artura-200-mph/" rel="nofollow">Driving a McLaren at 200 mph is a thrilling, dangerous experience</a> appeared first on <a href="https://www.popsci.com" r

## What is matter? It’s not as basic as you’d think.
 - [https://www.popsci.com/science/what-is-matter/](https://www.popsci.com/science/what-is-matter/)
 - RSS feed: https://www.popsci.com/feed/
 - date published: 2023-09-25T10:00:00+00:00

<div class="Article-thumbnail orgnc-SingleImage orgnc-SingleImage--center orgnc-SingleImage--hasCaption">
                    <div class="orgnc-SingleImage-wrapper"><img alt="Gold atom with nucleus and floating particles to depict what is matter" class="orgnc-SingleImage-image webfeedsFeaturedVisual wp-post-image" height="829" src="https://www.popsci.com/uploads/2023/09/22/what-is-matter-atom-illustration.jpg?auto=webp&amp;width=1440&amp;height=829.44" style="display: block; margin: auto; margin-bottom: 5px;" width="1440" /></div><div class="orgnc-SingleImage-caption">An atom consists of protons, neutrons, electors, and a nucleus. But matter consists of a whole lot more. <span class="orgnc-SingleImage-credit"><a href="https://depositphotos.com/photo/atom-particle-85617780.html">Deposit Photos</a></span></div></div><p>Matter makes up nearly a third of the universe, but is still shrouded in secrets.</p>
<p>The post <a href="https://www.popsci.com/science/what-is-matter/" rel="nofollow"

