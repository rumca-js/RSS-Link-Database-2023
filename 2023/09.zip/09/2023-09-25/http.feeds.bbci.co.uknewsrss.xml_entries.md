# Source:BBC, URL:http://feeds.bbci.co.uk/news/rss.xml, language:en-US

## School strikes: Support staff to walk out at 24 Scottish councils
 - [https://www.bbc.co.uk/news/uk-scotland-66916699?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-scotland-66916699?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T21:47:47+00:00

Thousands of pupils will stay at home on day one of Unison's three-day strike in a dispute over pay.

## Coventry City 1-1 Huddersfield Town: Darren Moore's Terriers snatch late draw
 - [https://www.bbc.co.uk/sport/football/66839975?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66839975?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T21:29:18+00:00

Michal Helik's injury-time equaliser earns Darren Moore's Huddersfield a draw at Coventry in his first game as Terriers boss.

## Burnley: Andros Townsend says he broke down in tears after move to Clarets collapsed
 - [https://www.bbc.co.uk/sport/football/66918026?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66918026?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T21:02:05+00:00

Andros Townsend says he broke down in tears after a free transfer move to Burnley collapsed over the summer.

## Taylor Swift attends Kansas City Chiefs game
 - [https://www.bbc.co.uk/news/entertainment-arts-66919232?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66919232?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T20:59:47+00:00

Swift attended the game on invitation of Chiefs player Travis Kelce and watched it seated next to his mother.

## ICEC report: Ebony Rainford-Brent says cricket can become UK's most inclusive sport
 - [https://www.bbc.co.uk/sport/cricket/66902424?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66902424?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T20:40:56+00:00

Following the publication of the ECB's response to the ICEC report, former England international and broadcaster Ebony Rainford-Brent says cricket can become the most inclusive sport in the country.

## Gatwick cancels 82 flights due to staff shortage
 - [https://www.bbc.co.uk/news/business-66917138?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66917138?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T17:20:13+00:00

The airport will cancel some flights over the coming week after Covid hits air traffic controllers.

## Watch elderly man air rescued after cliff fall
 - [https://www.bbc.co.uk/news/world-us-canada-66918551?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66918551?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T17:19:42+00:00

Authorities responded to a hiker who had fallen from a cliff next the Golden Gate Bridge in San Francisco.

## Over 340 first responders have died from 9/11 illnesses
 - [https://www.bbc.co.uk/news/world-us-canada-66917700?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66917700?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T17:08:21+00:00

As many have now died from complications as died in the attacks, the Fire Department of New York says.

## Rugby World Cup: Gareth Anscombe hopes to reunite with Dan Biggar in Wales campaign
 - [https://www.bbc.co.uk/sport/rugby-union/66912992?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/66912992?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T17:00:35+00:00

Fly-half Gareth Anscombe outlines how important the injured Dan Biggar is to Wales' World Cup campaign.

## Irish university to offer degree in influencing
 - [https://www.bbc.co.uk/news/articles/c03e8478plzo?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/articles/c03e8478plzo?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:37:51+00:00

The bachelors course at Southeast Technical University in Carlow is due to start in September 2024.

## Lib Dem members defy leadership on housing target
 - [https://www.bbc.co.uk/news/uk-politics-66917374?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66917374?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:36:55+00:00

Members vote to keep a pledge to build 380,000 homes a year in England, after calls from the Young Liberals group.

## More than a million appointments hit by NHS strikes
 - [https://www.bbc.co.uk/news/health-66918525?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/health-66918525?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:34:12+00:00

There are calls for both sides to end the doctors' pay row, ahead of joint strike action next week.

## Police probe after Brand sexual offence claims
 - [https://www.bbc.co.uk/news/uk-66918331?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66918331?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:16:03+00:00

The Met will investigate allegations of "non-recent" offences following news reports about Brand.

## Bob Menendez: 'I will be exonerated' on fraud charges
 - [https://www.bbc.co.uk/news/world-us-canada-66917894?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66917894?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:08:34+00:00

The Democratic senator from New Jersey says he will run for re-election in the face of federal charges.

## Hollywood strikes: UK film industry workers hit by US dispute
 - [https://www.bbc.co.uk/news/entertainment-arts-66871083?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66871083?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T16:07:41+00:00

Despite a tentative deal between writers and studios bosses, UK workers continue to suffer.

## Amazon takes on Microsoft as invests billion in Anthropic
 - [https://www.bbc.co.uk/news/technology-66914338?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66914338?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T15:46:07+00:00

Amazon is in a race among big tech firms to exploit the potential of artificial intelligence.

## Jermaine Jenas apologises after posting criticism about referee Rob Jones
 - [https://www.bbc.co.uk/sport/football/66914216?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66914216?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T15:43:23+00:00

Football pundit Jermaine Jenas has apologised for criticising referee Rob Jones saying he "got it wrong".

## Ajax v Feyenoord: Abandoned De Klassieker to be completed behind closed doors on Wednesday
 - [https://www.bbc.co.uk/sport/football/66916168?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66916168?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T15:01:23+00:00

Ajax's abandoned match at home to rivals Feyenoord will be completed behind closed doors on Wednesday, the Dutch FA confirm

## James Cracknell: Olympic rower chosen as Conservative candidate
 - [https://www.bbc.co.uk/news/uk-england-essex-66917147?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-essex-66917147?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T14:51:26+00:00

Mr Cracknell is said to be the "clear choice" of Conservative party members in Colchester.

## Cat missing for 11 years reunited with owner
 - [https://www.bbc.co.uk/news/uk-wales-66913831?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66913831?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T14:12:59+00:00

Sian Sexton says she is "still in shock" after a surprise phone call saw her reunited with pet cat Daisy.

## In pictures: Northern Lights make lively display
 - [https://www.bbc.co.uk/news/uk-66913766?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66913766?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T14:02:36+00:00

Chances of seeing aurora increase as the Sun nears the peak of its 11-year cycle.

## Nissan to go all-electric by 2030 despite petrol ban delay
 - [https://www.bbc.co.uk/news/business-66915440?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66915440?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T13:57:33+00:00

The carmaker moves ahead with its plan despite delays to the UK's ban on new petrol and diesel cars.

## Motorcyclist killed in central London police-chase crash
 - [https://www.bbc.co.uk/news/uk-england-london-66915896?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-london-66915896?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T13:49:19+00:00

The man failed to stop for officers and crashed into a taxi and street furniture on Monday morning.

## Kamila Valieva: American skater Vincent Zhou criticises anti-doping system before Russian's hearing
 - [https://www.bbc.co.uk/sport/winter-sports/66910302?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/winter-sports/66910302?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T13:28:42+00:00

American figure skater Vincent Zhou says the global anti-doping system is "failing athletes" before Russian Kamila Valieva's doping case hearing begins on Tuesday.

## French family planning agency turns to British TV show Sex Education
 - [https://www.bbc.co.uk/news/world-europe-66913308?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66913308?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T12:22:42+00:00

Le Planning Familial says it is working with Netflix to promote its free sex education phone line.

## HS2: What is the route and why could part of it be cancelled?
 - [https://www.bbc.co.uk/news/uk-16473296?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-16473296?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T12:06:33+00:00

The high-speed railway between London, the Midlands and North of England could be scaled back.

## Gymnastics Ireland issues unreservedly apology to black girl not given medal at event ceremony
 - [https://www.bbc.co.uk/sport/gymnastics/66913866?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/gymnastics/66913866?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T12:02:51+00:00

Gymnastics Ireland issues unreserved apology to the family of a black girl who was not given a medal at an events ceremony.

## ECB publishes response to ICEC report and says it wants to 'change the game'
 - [https://www.bbc.co.uk/sport/cricket/66902420?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/cricket/66902420?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T12:01:31+00:00

The England and Wales Cricket Board says it is "on a journey to change the game" as it publishes a response to a report detailing racism, sexism, classism and elitism in the sport.

## Debt: What should I pay first and what can I do?
 - [https://www.bbc.co.uk/news/business-64291327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-64291327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:59:01+00:00

What help and options are available to people struggling with debt repayments?

## Hundreds of Met armed officers hand in guns as Army on standby
 - [https://www.bbc.co.uk/news/uk-66909729?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66909729?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:58:48+00:00

The Met insists the vast majority of armed officers remain on duty, despite calling in extra police.

## Eddie Jones: Australia sacking under-fire coach is 'the worst thing' they can do, says Stirling Mortlock
 - [https://www.bbc.co.uk/sport/rugby-union/66914086?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/66914086?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:31:09+00:00

Sacking Eddie Jones would be "the worst thing" Australia could do despite their troubles at the Rugby World Cup, says former captain Stirling Mortlock.

## Sophia Loren: Italian star has emergency surgery after fall
 - [https://www.bbc.co.uk/news/entertainment-arts-66913653?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66913653?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:30:14+00:00

The 89-year-old Italian actress fell at her Swiss home and sustained "serious fractures".

## Australian lethal mushroom mystery survivor leaves hospital
 - [https://www.bbc.co.uk/news/world-australia-66913549?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-australia-66913549?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:13:26+00:00

Erin Patterson cooked a meal using mushrooms which killed three relatives, but one has survived.

## Child serial killer Lucy Letby to face retrial over attempted murder charge
 - [https://www.bbc.co.uk/news/uk-england-merseyside-66910521?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-merseyside-66910521?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T11:07:09+00:00

The former nurse will stand trial next year on one count of the attempted murder of a baby girl.

## Chris Mason: Big decisions await as HS2 row simmers on
 - [https://www.bbc.co.uk/news/uk-politics-66912097?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66912097?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T10:43:08+00:00

The PM might have hoped to make an HS2 announcement later this autumn - but that timetable has slipped.

## Dozens of vintage cars on show at Weston-super-Mare vintage car rally
 - [https://www.bbc.co.uk/news/uk-england-somerset-66912032?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-somerset-66912032?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T10:32:12+00:00

Classic car enthusiasts flock to airfield for annual wheels event.

## 'Royal butler isn't me!' BBC host on doppelganger
 - [https://www.bbc.co.uk/news/uk-66910327?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66910327?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T10:20:56+00:00

BBC Breakfast host Sally Nugent is left in stitches after spotting Jon Kay's lookalike next to King Charles in Paris.

## Louise Redknapp pulls out of Eternal reunion over LGBTQ row
 - [https://www.bbc.co.uk/news/entertainment-arts-66910604?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66910604?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T09:51:52+00:00

The singer drops out of a tour amid accusations that two bandmates refused to play Pride events.

## Lib Dems drop pledge to raise income tax by 1p
 - [https://www.bbc.co.uk/news/uk-politics-66910334?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66910334?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T09:23:40+00:00

Sir Ed Davey sets out plans to woo voters in Conservative held seats ahead of a general election.

## Lego axes plan to make bricks from recycled bottles
 - [https://www.bbc.co.uk/news/business-66910573?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66910573?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T09:13:15+00:00

The toy giant finds that the new crude oil-free material did not cut carbon emissions.

## Maddy Cusack: Police not treating Sheffield United midfielder's death as suspicious
 - [https://www.bbc.co.uk/sport/football/66912191?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66912191?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T09:10:02+00:00

The death of Sheffield United player Maddy Cusack is not being treated as suspicious, police have said.

## Liverpool 2.0 reminds me of Jurgen Klopp’s best Reds teams - Shay Given analysis
 - [https://www.bbc.co.uk/sport/football/66906582?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66906582?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T08:44:15+00:00

Jurgen Klopp's remodelled Reds team is a reminder of what his best Liverpool sides have always been like, says MOTD2 pundit Shay Given.

## Usher to perform 2024 Super Bowl half-time show
 - [https://www.bbc.co.uk/news/entertainment-arts-66910599?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/entertainment-arts-66910599?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T08:42:49+00:00

The star, whose hits include Yeah! and Confessions, follows Rihanna in taking the coveted slot.

## Match of the Day 2 Good 2 Bad: Darwin Nunez's stunning miss and goal, goalkeeper celebrations and a referee fumble
 - [https://www.bbc.co.uk/sport/av/football/66908409?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/av/football/66908409?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T08:37:26+00:00

Watch 2 Good 2 Bad from Match of the Day 2, featuring a bad miss and stunning goal by Liverpool's Darwin Nunez, goalkeeper celebrations and a referee fumble.

## Freshers' week: Tips for surviving uni first year
 - [https://www.bbc.co.uk/news/newsbeat-66867417?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/newsbeat-66867417?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T08:28:23+00:00

What are the best ways to make friends, budget, study and look after your mental health at university?

## Storm Agnes: What do you need to know?
 - [https://www.bbc.co.uk/news/uk-66909872?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-66909872?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T08:27:53+00:00

The first named storm of the 2023-24 season is likely to bring some impacts from strong winds and rain.

## HS2: Backlash against scrapping Manchester link grows
 - [https://www.bbc.co.uk/news/business-66909732?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66909732?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T07:15:29+00:00

Manchester Mayor Andy Burnham said abandoning the extension risked creating a "north-south chasm".

## Watch: Passengers left upside down as Canada ride malfunctions
 - [https://www.bbc.co.uk/news/world-us-canada-66910324?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66910324?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T07:05:48+00:00

The park's maintenance team brought the passengers safely to the ground after 30 minutes.

## How Wales went from team in disarray to World Cup pacesetters
 - [https://www.bbc.co.uk/sport/rugby-union/66909078?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/66909078?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T06:44:01+00:00

Wales will head to Marseille for a World Cup quarter-final following a record 40-6 win over Australia in Lyon.

## The lone away fan who led his club to glory
 - [https://www.bbc.co.uk/sport/football/66888695?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/football/66888695?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T06:34:05+00:00

Tiago Rech had a moment of global fame as the only away fan to attend an FC Santa Cruz game. It was just the beginning of his remarkable story.

## Messina Denaro: Notorious Italian Mafia boss dies
 - [https://www.bbc.co.uk/news/world-europe-66909616?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66909616?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T06:30:12+00:00

The 61-year-old, who spent decades on the run, boasted that he could "fill a cemetery" with his victims.

## Shopping habits have changed for good, says Aldi
 - [https://www.bbc.co.uk/news/business-66905403?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66905403?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T06:22:38+00:00

Consumers are buying cheaper own-label goods due to living costs, according to the supermarket.

## Rugby World Cup: Wales fans' joy after Australia rout
 - [https://www.bbc.co.uk/news/uk-wales-66907380?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66907380?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:43:36+00:00

Wales fans are elated as the team hammer Australia to march into the Rugby World Cup quarter-finals.

## Rugby World Cup: What happened in week three at the tournament?
 - [https://www.bbc.co.uk/sport/rugby-union/66902916?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/rugby-union/66902916?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:38:53+00:00

There's a big injury concern for France while Ireland see off the defending champions - here are the main headlines from week three of the Rugby World Cup.

## BBC Green Sport Awards: Nominees announced for 2023 awards
 - [https://www.bbc.co.uk/sport/66845485?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/sport/66845485?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:20:00+00:00

Meet the sportspeople and organisations who are using the power of sport to help create a more sustainable future.

## Devon and Cornwall hosepipe ban officially lifted
 - [https://www.bbc.co.uk/news/uk-england-cornwall-66877893?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-england-cornwall-66877893?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:11:56+00:00

South West Water says recent rainfall and reviews of reservoir levels are behind the decision.

## Santander: Frozen bank card forces disabled man to borrow for food
 - [https://www.bbc.co.uk/news/uk-wales-66890530?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-wales-66890530?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:06:07+00:00

More than £3,200 in unauthorised withdrawals is taken from the disabled ex-police officer's account.

## Richest oil states should pay climate tax, says Gordon Brown
 - [https://www.bbc.co.uk/news/uk-politics-66906395?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/uk-politics-66906395?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:00:05+00:00

The former Labour PM wants the wealthiest oil producers to help poorer nations tackle climate change.

## How the fall of the 'King of Crypto' cost one British man millions
 - [https://www.bbc.co.uk/news/technology-66892685?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/technology-66892685?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T05:00:03+00:00

As Sam Bankman-Fried awaits trial for fraud, his former investors wonder if they will ever recoup their losses.

## Hollywood writers in deal to end US studio strike
 - [https://www.bbc.co.uk/news/world-us-canada-66909250?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-us-canada-66909250?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T03:51:39+00:00

Screenwriters hail an "exceptional" tentative deal to end a strike that has halted film and TV production.

## State-owned British Business Bank makes £147m annual loss
 - [https://www.bbc.co.uk/news/business-66909104?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/business-66909104?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T03:28:08+00:00

The bank says wider economic problems led to a drop in the valuation of businesses it has invested in.

## Kosovo and Serbia row over monastery gun battle
 - [https://www.bbc.co.uk/news/world-europe-66908955?at_medium=RSS&at_campaign=KARANGA](https://www.bbc.co.uk/news/world-europe-66908955?at_medium=RSS&at_campaign=KARANGA)
 - RSS feed: http://feeds.bbci.co.uk/news/rss.xml
 - date published: 2023-09-25T00:59:03+00:00

A Kosovan policeman and three ethnic Serb gunmen are dead after a siege of a monastery in Kosovo.

