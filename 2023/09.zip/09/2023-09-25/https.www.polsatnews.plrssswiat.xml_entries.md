# Source:Polsat News, URL:https://www.polsatnews.pl/rss/swiat.xml, language:pl-PL

## Biden walczy z Chinami. Uznaje nowe państwa
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/biden-walczy-z-chinami-uznaje-nowe-panstwa/](https://www.polsatnews.pl/wiadomosc/2023-09-25/biden-walczy-z-chinami-uznaje-nowe-panstwa/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T19:56:00+00:00

Prezydent Stanów Zjednoczonych Joe Biden ogłosił, że jego kraj uzna położone na Pacyfiku Niue i Wyspy Cooka za niepodległe państwa. Zapowiedział również, że na obu terytoriach otwarte zostaną amerykańskie ambasady. Decyzja, ogłoszona podczas spotkania z liderami państw członkowskich Forum Wysp Pacyfiku, jest częścią rywalizacji Stanów Zjednoczonych z Chinami o wpływy w regionie.

## Spotkanie po latach. Kotka wróciła do domu po ponad dekadzie
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/spotkanie-po-latach-kotka-wrocila-do-domu-po-ponad-dekadzie/](https://www.polsatnews.pl/wiadomosc/2023-09-25/spotkanie-po-latach-kotka-wrocila-do-domu-po-ponad-dekadzie/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T19:53:00+00:00

Szczęśliwa mieszkanka walijskiego Caerphilly odnalazła swoją kotkę po 11 latach od zaginięcia. Zwierzę zachorowało na kocią grypę i trafiło do weterynarza, gdzie zostało zidentyfikowane dzięki mikroczipowi. Teraz czeka je spokojna starość w towarzystwie siostry i dwóch młodszych kotów.

## Wielka Brytania. Policja wszczyna dochodzenie po zarzutach wobec Russella Branda
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/wielka-brytania-policja-wszczyna-dochodzenie-po-zarzutach-wobec-russella-branda/](https://www.polsatnews.pl/wiadomosc/2023-09-25/wielka-brytania-policja-wszczyna-dochodzenie-po-zarzutach-wobec-russella-branda/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T19:44:00+00:00

Londyńska policja wszczęła dochodzenie w sprawie zarzutów dotyczących napaści seksualnej, których miał dopuścić się Russell Brand. Brytyjskie media w połowie września opublikowały zeznania ofiar - czterech anonimowo wypowiadających się w tej sprawie kobiet. Brand zaprzecza i twierdzi, że do wszystkich zbliżeń dochodziło za obopólną zgodą.

## Australia. 68-latek przypadkowo zjadł śmiertelnie groźny posiłek. Cudem przeżył
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/australia-68-latek-przypadkowo-zjadl-smiertelnie-grozny-posilek-cudem-przezyl/](https://www.polsatnews.pl/wiadomosc/2023-09-25/australia-68-latek-przypadkowo-zjadl-smiertelnie-grozny-posilek-cudem-przezyl/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T18:05:00+00:00

68-letni Ian Wilkinson z miasteczka Leongatha w Australii wyszedł ze szpitala. Spędził w nim dwa miesiące po tym, jak w lipcu zjadł danie z trującym grzybem. Posiłek spożyli także inni członkowie jego rodziny, a trójka z nich zmarła.

## Wkrótce będą nam rosły nowe zęby? To nie science fiction
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/wkrotce-beda-nam-rosly-nowe-zeby-to-nie-science-fiction/](https://www.polsatnews.pl/wiadomosc/2023-09-25/wkrotce-beda-nam-rosly-nowe-zeby-to-nie-science-fiction/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T15:10:00+00:00

Japońscy naukowcy pracują nad lekiem, który ma sprawić, że ludziom będą rosły nowe zęby. Do tej pory środek okazał się być skuteczny u myszy i fretek. Na 2024 roku zaplanowane są eksperymenty kliniczne, które sprawdzą, czy lek jest bezpieczny dla ludzi. Do powszechnego użytku lek może trafić już z końcem dekady.

## Napięcie na linii Węgry-Ukraina. Viktor Orban stawia warunki w kwestii Zakarpacia
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/napiecie-na-linii-wegry-ukraina-viktor-orban-stawia-warunki-w-kwestii-zakarpacia/](https://www.polsatnews.pl/wiadomosc/2023-09-25/napiecie-na-linii-wegry-ukraina-viktor-orban-stawia-warunki-w-kwestii-zakarpacia/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T15:02:00+00:00

- Węgry nie będą wspierać Ukrainy w żadnej kwestii w stosunkach międzynarodowych, dopóki ta nie przywróci dawnych praw etnicznym Węgrom na swoim terytorium - powiedział w poniedziałek parlamentowi premier Viktor Orban, mając na myśli Zakarpacie.

## Skandal w Rosji. Zniknęły pomniki upamiętniające polskich zesłańców
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/skandal-w-rosji-zniknely-pomniki-upamietniajace-polskich-zeslancow/](https://www.polsatnews.pl/wiadomosc/2023-09-25/skandal-w-rosji-zniknely-pomniki-upamietniajace-polskich-zeslancow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T14:42:00+00:00

W Jakucku nieznani sprawcy zabrali pomniki upamiętniające Polaków. Pięć głazów zostało zdemontowanych i wywiezionych w nieznanym kierunku. Wcześniej zniknęły z nich tablice pamiątkowe. Próby ich zabezpieczenia zakończyły się niepowodzeniem.

## Modernizacja polskiej armii. USA udzieliły kluczowej pożyczki
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/modernizacja-polskiej-armii-usa-udzielily-kluczowej-pozyczki/](https://www.polsatnews.pl/wiadomosc/2023-09-25/modernizacja-polskiej-armii-usa-udzielily-kluczowej-pozyczki/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T14:32:00+00:00

Departament Stanu USA poinformował, że Stany Zjednoczone udzieliły Polsce pożyczki bezpośredniej w kwocie dwóch miliardów dolarów. Pieniądze trafią do Polski w ramach zagranicznego funduszu wojskowego w celu wsparcia modernizacja polskiego wojska.

## Młody Władimir Putin. Fińska telewizja opublikowała unikatowe nagranie
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/finlandia-telewizja-yle-opublikowala-unikalne-nagranie-z-wladimirem-putinem-na-wakacjach/](https://www.polsatnews.pl/wiadomosc/2023-09-25/finlandia-telewizja-yle-opublikowala-unikalne-nagranie-z-wladimirem-putinem-na-wakacjach/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T14:27:00+00:00

Fińska telewizja Yle opublikowała nagranie, na którym obecny prezydent Rosji Władimir Putin wraz z rodziną i znajomymi spędzał urlop. Media oceniają film jako unikatowy, bo będący poza kontrolą rosyjskiego autokraty, który w obiektywie kamer pojawia się tylko po to, żeby wzmocnić swój wizerunek. Materiał pochodzi z początku lat 90., kiedy Putin był bliskim współpracownikiem mera Petersburga.

## Niewidoma panna młoda zasłoniła oczy gościom, a nawet panu młodemu. Nagranie bije rekordy
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/niewidoma-panna-mloda-zaslonila-oczy-gosciom-a-nawet-panu-mlodemu-nagranie-bije-rekordy/](https://www.polsatnews.pl/wiadomosc/2023-09-25/niewidoma-panna-mloda-zaslonila-oczy-gosciom-a-nawet-panu-mlodemu-nagranie-bije-rekordy/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T13:16:00+00:00

Lucy Edwards, która jest niewidoma od 17. roku życia, wyraziła szczególne życzenie z okazji swojego ślubu - zasłoniła oczy gościom weselnym i mężowi. Chciałam, aby wszyscy zrozumieli, co czuję każdego dnia. Popularne wideo umieściła na TikToku z komentarzem: To jest ich reakcja, gdy przez chwilę byli na moim miejscu.

## Wielka Brytania zakaże palenia papierosów? Chodzi o pewną grupę obywateli
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/wielka-brytania-zakaze-palenia-papierosow-chodzi-o-pewna-grupe-obywateli/](https://www.polsatnews.pl/wiadomosc/2023-09-25/wielka-brytania-zakaze-palenia-papierosow-chodzi-o-pewna-grupe-obywateli/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T12:23:00+00:00

Jak dowiedział się The Guardian, brytyjski premier Rishi Sunak rozważa wprowadzenie środków podobnych do tych w Nowej Zelandii z grudnia ubiegłego roku. Obejmowałyby one stałe podwyższanie wieku legalnego palenia, tak aby tytoń nigdy nie był sprzedawany osobom urodzonym 1 stycznia 2009 roku lub później.

## Chwile grozy w parku rozrywki. Przez pół godziny wisieli do góry nogami
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/chwile-grozy-w-parku-rozrywki-przez-pol-godziny-wisieli-do-gory-nogami/](https://www.polsatnews.pl/wiadomosc/2023-09-25/chwile-grozy-w-parku-rozrywki-przez-pol-godziny-wisieli-do-gory-nogami/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T12:06:00+00:00

W parku rozrywki Canadas Wonderland awarii uległa jedna z kolejek górskich. Kilkanaście osób utknęło w powietrzu, przez pół godziny wisząc głową w dół. Po naprawieniu maszyny dwoje z gości parku wymagało pomocy lekarskiej, a inne osoby odczuwały skutki silnego stresu.

## Jamajka: Gorączka denga szaleje. Blisko 100 potwierdzonych przypadków
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/jamajka-goraczka-denga-szaleje-blisko-100-potwierdzonych-przypadkow/](https://www.polsatnews.pl/wiadomosc/2023-09-25/jamajka-goraczka-denga-szaleje-blisko-100-potwierdzonych-przypadkow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T11:34:00+00:00

Rząd Jamajki poinformował o ogniskach gorączki denga. U setek osób potwierdzono albo podejrzewa się tę groźną chorobę. Ministerstwo Zdrowia zapowiedziało specjalne działania na wypadek wybuchu epidemii.

## Słowacja: Ratownicy górscy poszukują Polaka. Nie ma z nim łączności od ponad doby
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/slowacja-ratownicy-gorscy-poszukuja-polaka-nie-ma-z-nim-lacznosci-od-trzech-dni/](https://www.polsatnews.pl/wiadomosc/2023-09-25/slowacja-ratownicy-gorscy-poszukuja-polaka-nie-ma-z-nim-lacznosci-od-trzech-dni/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T11:05:00+00:00

Słowaccy TOPR-owcy usiłują odnaleźć polskiego turystę, który doznał poważnej kontuzji podczas schodzenia z Lodowego Szczytu w Tatrach. Na pomoc czeka już ponad dobę, jednak nie wiadomo, gdzie dokładnie się znajduje. Poszukiwań nie ułatwiają trudne warunki pogodowe. Ratownicy muszą wspomagać się dronami.

## Szef rosyjskiej Dumy Wiaczesław Wołodin: Ukraina przyjmie warunki Moskwy, albo przestanie istnieć
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/szef-rosyjskiej-dumy-wiaczeslaw-wolodin-ukraina-przyjmie-warunki-moskwy-albo-przestanie-istniec/](https://www.polsatnews.pl/wiadomosc/2023-09-25/szef-rosyjskiej-dumy-wiaczeslaw-wolodin-ukraina-przyjmie-warunki-moskwy-albo-przestanie-istniec/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T10:47:00+00:00

Ukraina albo skapituluje na warunkach Moskwy, albo przestanie istnieć jako państwo - powiedział Wiaczesław Wołodin, szef rosyjskiej Dumy Państwowej, cytowany przez TASS. Zdaniem kremlowskiego polityka Zachód zmaga się z brakiem amunicji i problemami gospodarczymi, a Ukraina ma chylić się ku upadkowi z powodu ostatecznego bankructwa i katastrofy demograficznej.

## Kanada: Weteran SS-Galizien oklaskiwany w parlamencie podczas wizyty Zełenskiego. Są przeprosiny
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/kanada-weteran-ss-galizien-oklaskiwany-w-parlamencie-podczas-wizyty-zelenskiego-sa-przeprosiny/](https://www.polsatnews.pl/wiadomosc/2023-09-25/kanada-weteran-ss-galizien-oklaskiwany-w-parlamencie-podczas-wizyty-zelenskiego-sa-przeprosiny/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T09:27:00+00:00

Marszałek parlamentu Kanady Anthony Rota przeprosił za uhonorowanie Jarosława Hunki, który podczas II wojny światowej - jako ochotnik - służył w Waffen SS-Galizien. Członkowie tego podległego Niemcom oddziału, sformowanego zwłaszcza z Ukraińców, mordowali Polaków i Żydów. Mimo to w piątek 98-latka nazwano bohaterem, otrzymał też oklaski na stojąco od m.in. prezydenta Ukrainy i premiera Kanady.

## Strajk scenarzystów w Hollywood zakończony. Zawarto "wyjątkową umowę"
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/strajk-scenarzystow-w-hollywood-zakonczony-zawarto-wyjatkowa-umowe/](https://www.polsatnews.pl/wiadomosc/2023-09-25/strajk-scenarzystow-w-hollywood-zakonczony-zawarto-wyjatkowa-umowe/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T08:46:00+00:00

Hollywoodzcy scenarzyści po 146 dniach protestów ustalili wstępne porozumienie z wytwórniami filmowymi. Strajkowali, bo domagali się m.in. podwyżek pensji i uregulowania wykorzystywania sztucznej inteligencji. Obawiali się, że umiejąca wymyślać fabuły AI pozbawi ich pracy. W ocenie przedstawicieli scenarzystów zawarta umowa daje protestującym znaczne korzyści.

## Policzyli, ilu żołnierzy Kremla zginęło podczas wojny. Rosjan zdradził ich zwyczaj
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/policzyli-ilu-zolnierzy-kremla-zginelo-podczas-wojny-rosjan-zdradzil-ich-zwyczaj/](https://www.polsatnews.pl/wiadomosc/2023-09-25/policzyli-ilu-zolnierzy-kremla-zginelo-podczas-wojny-rosjan-zdradzil-ich-zwyczaj/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T08:26:00+00:00

Rosjanie ukrywają prawdziwą liczbę żołnierzy, którzy ponieśli śmierć na froncie w Ukrainie. Dziennikarze The Moscow Times odkryli jednak istotną poszlakę, która może wskazywać, jakie są prawdziwe straty Kremla. Z danych na temat zamówień instytucji państwowych wynika, że w ostatnim półroczu wyprawiono prawie 100 tys. wojskowych pogrzebów.

## USA: Ogromna kumulacja w Powerball. Pula rośnie od lipca
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/usa-gigantyczna-kumulacja-do-wygrania-szansa-wygrania-w-powerball-wynosi-1-do-292-milionow/](https://www.polsatnews.pl/wiadomosc/2023-09-25/usa-gigantyczna-kumulacja-do-wygrania-szansa-wygrania-w-powerball-wynosi-1-do-292-milionow/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T08:06:00+00:00

Kumulacja w amerykańskiej loterii Powerball osiągnęła 785 milionów dolarów - to czwarta najwyższa pula w historii. Jeśli w poniedziałkowym losowaniu nikt nie skreśli właściwych liczb, możliwa stanie się jeszcze większa i najpewniej przekroczy miliard dolarów. Szansa, aby wytypować właściwą kombinację, wynosi mniej więcej 1 do 292 milionów.

## Sophia Loren trafiła do szpitala. 89-letnia ikona Hollywood miała wypadek
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/sophia-loren-trafila-do-szpitala-89-letnia-ikona-hollywood-miala-wypadek/](https://www.polsatnews.pl/wiadomosc/2023-09-25/sophia-loren-trafila-do-szpitala-89-letnia-ikona-hollywood-miala-wypadek/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T06:15:00+00:00

Słynna włoska aktorka Sophia Loren przewróciła się w łazience w swojej rezydencji we Szwajcarii. Doznała poważnych obrażeń, w tym złamania kości udowej. Na razie lekarze zachowują ostrożny optymizm co do powrotu 89-latki do zdrowia. Przy jej łóżku czuwają dwaj synowie artystki.

## Włochy: Matteo Messina Denaro nie żyje. Szef cosa nostry ukrywał się 30 lat
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/wlochy-matteo-messina-denaro-nie-zyje-szef-cosa-nostry-ukrywal-sie-30-lat/](https://www.polsatnews.pl/wiadomosc/2023-09-25/wlochy-matteo-messina-denaro-nie-zyje-szef-cosa-nostry-ukrywal-sie-30-lat/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T06:02:00+00:00

Był odpowiedzialny za śmierć dziesiątek osób. Gdy w końcu go schwytano, po pół roku zmarł na raka okrężnicy. Matteo Messina Denaro, stojący na czele cosa nostry - mafii z Sycylii - zmarł w wieku 61 lat. Jeszcze za życia nadano mu miano ostatniego ojca chrzestnego.

## Niger: Junta uderza we Francję. Zamknięta przestrzeń powietrzna, ambasador zakładnikiem
 - [https://www.polsatnews.pl/wiadomosc/2023-09-25/niger-junta-uderza-we-francje-zamknieta-przestrzen-powietrzna-ambasador-zakladnikiem/](https://www.polsatnews.pl/wiadomosc/2023-09-25/niger-junta-uderza-we-francje-zamknieta-przestrzen-powietrzna-ambasador-zakladnikiem/)
 - RSS feed: https://www.polsatnews.pl/rss/swiat.xml
 - date published: 2023-09-25T05:20:00+00:00

Reżim wojskowy rządzący w Nigrze zamknął przestrzeń powietrzną swojego kraju dla francuskich samolotów. Prezydent Emmanuel Macron podjął decyzję o zakończeniu współpracy wojskowej z tym państwem. Kilka dni temu poinformował, że francuski ambasador został wzięty za zakładnika.

