# Source:BleepingComputer, URL:https://www.bleepingcomputer.com/feed/, language:en-US

## BORN Ontario child registry data breach affects 3.4 million people
 - [https://www.bleepingcomputer.com/news/security/born-ontario-child-registry-data-breach-affects-34-million-people/](https://www.bleepingcomputer.com/news/security/born-ontario-child-registry-data-breach-affects-34-million-people/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-09-25T17:31:41+00:00

The Better Outcomes Registry & Network (BORN), a healthcare organization funded by the government of Ontario, has announced that it is among the victims of Clop ransomware's MOVEit hacking spree. [...]

## Google is retiring its Gmail Basic HTML view in January 2024
 - [https://www.bleepingcomputer.com/news/security/google-is-retiring-its-gmail-basic-html-view-in-january-2024/](https://www.bleepingcomputer.com/news/security/google-is-retiring-its-gmail-basic-html-view-in-january-2024/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-09-25T16:08:04+00:00

Google is notifying Gmail users that the webmail's Basic HTML view will be deprecated in January 2024, and users will require modern browsers to continue using the service. [...]

## Xenomorph Android malware now targets U.S. banks and crypto wallets
 - [https://www.bleepingcomputer.com/news/security/xenomorph-android-malware-now-targets-us-banks-and-crypto-wallets/](https://www.bleepingcomputer.com/news/security/xenomorph-android-malware-now-targets-us-banks-and-crypto-wallets/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-09-25T15:16:02+00:00

Security researchers discovered a new campaign that distributes a new version of the Xenomorph malware to Android users in the United States, Canada, Spain, Italy, Portugal, and Belgium. [...]

## Mixin Network suspends operations following $200 million hack
 - [https://www.bleepingcomputer.com/news/security/mixin-network-suspends-operations-following-200-million-hack/](https://www.bleepingcomputer.com/news/security/mixin-network-suspends-operations-following-200-million-hack/)
 - RSS feed: https://www.bleepingcomputer.com/feed/
 - date published: 2023-09-25T13:23:16+00:00

Mixin Network, an open-source, peer-to-peer transactional network for digital assets, has announced today on Twitter that deposits and withdrawals are suspended effective immediately due to a $200 million hack the platform suffered on Saturday. [...]

