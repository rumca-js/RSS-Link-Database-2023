# Source:Pluralistic: Daily links from Cory Doctorow, URL:https://pluralistic.net/feed, language:en-US

## Pluralistic: Podcasting "How To Think About Scraping" (25 Sept 2023)
 - [https://pluralistic.net/2023/09/25/deep-scrape/](https://pluralistic.net/2023/09/25/deep-scrape/)
 - RSS feed: https://pluralistic.net/feed
 - date published: 2023-09-25T18:08:07+00:00

Today's links Podcasting "How To Think About Scraping": How to preserve the benefits of web-scraping while targeting the real harms. Hey look at this: Delights to delectate. This day in history: 2003, 2008, 2013, 2018, 2022 Colophon: Recent publications, upcoming/recent appearances, current writing projects, current reading Podcasting "How To Think About Scraping" (permalink) This week on my podcast, I read my recent Medium column, "How To Think About Scraping: In privacy and labor fights, copyright is a clumsy tool at best," which proposes ways to retain the benefits of scraping without the privacy and labor harms that sometimes accompany it: https://doctorow.medium.com/how-to-think-about-scraping-2db6f69a7e3d?sk=4a1d687171de1a3f3751433bffbb5a96 What are those benefits from scraping? Well, take computational linguistics, a relatively new discipline that is producing the first accounts of how informal language works. Historically, linguists overstudied written language (because it wa

