# Source:LonTV, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg, language:en-US

## Big News: LG to Drop ATSC 3.0 Tuners on New TVs
 - [https://www.youtube.com/watch?v=THLN_AgY7sI](https://www.youtube.com/watch?v=THLN_AgY7sI)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCymYq4Piq0BrhnM18aQzTlg
 - date published: 2023-09-25T22:30:02+00:00

See more ATSC 3 commentary: https://www.youtube.com/playlist?list=PLCZHp4d1HnItSSUpA-DskfKKKrQ_LQYwP - LG, one of the co-developers of the ATSC 3.0 over the air tv standard, announced today that they are dropping support for the new standard on new televisions due to a patent lawsuit they lost. Subscribe for more! http://lon.tv/s

VIDEO INDEX:
00:00 - Intro
00:21 - Cord Cutters News Story : lon.tv/lg925
01:03 - LG's FCC filing
02:12 - ATSC 3 Related Patents
04:21 - LG's ATSC 3 Patent Lawsuit
07:14 - Possible Future Litigation?
08:03 - Follow me on Twitter : lon.tv/twitter
08:31 - Conclusion

Visit my Blog! https://blog.lon.tv

Subscribe to my email lists! 
Weekly Breakdown of Posted Videos:  - https://lon.tv/email
Daily Email From My Blog Posts! https://lon.tv/digest

See my second channel for supplementary content : http://lon.tv/extras

Follow me on Amazon too! http://lon.tv/amazonshop

Join the Facebook group to connect with me and other viewers! 
http://lon.tv/facebookgroup

Visi

