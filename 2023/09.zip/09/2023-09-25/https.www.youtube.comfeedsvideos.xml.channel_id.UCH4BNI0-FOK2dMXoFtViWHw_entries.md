# Source:Be Smart, URL:https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw, language:en-US

## This Beetle Uses Polarized Light as Camouflage
 - [https://www.youtube.com/watch?v=5t6EmSuKWYY](https://www.youtube.com/watch?v=5t6EmSuKWYY)
 - RSS feed: https://www.youtube.com/feeds/videos.xml?channel_id=UCH4BNI0-FOK2dMXoFtViWHw
 - date published: 2023-09-25T17:25:18+00:00



