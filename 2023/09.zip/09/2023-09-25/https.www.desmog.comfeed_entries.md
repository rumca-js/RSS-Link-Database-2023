# Source:DeSmog, URL:https://www.desmog.com/feed/, language:en-US

## Italian Oil Giant Eni Knew About Climate Change More Than 50 Years Ago, Report Reveals
 - [https://www.desmog.com/2023/09/24/italian-oil-giant-eni-knew-about-climate-change-more-than-50-years-ago-report-reveals/](https://www.desmog.com/2023/09/24/italian-oil-giant-eni-knew-about-climate-change-more-than-50-years-ago-report-reveals/)
 - RSS feed: https://www.desmog.com/feed/
 - date published: 2023-09-25T04:00:00+00:00

<p>Italian oil major Eni knew of the climate impacts of fossil fuel extraction since 1970, according to a report by Greenpeace Italy and advocacy group ReCommon shared with DeSmog.</p>
<p>The post <a href="https://www.desmog.com/2023/09/24/italian-oil-giant-eni-knew-about-climate-change-more-than-50-years-ago-report-reveals/" rel="nofollow">Italian Oil Giant Eni Knew About Climate Change More Than 50 Years Ago, Report Reveals</a> appeared first on <a href="https://www.desmog.com" rel="nofollow">DeSmog</a>.</p>

